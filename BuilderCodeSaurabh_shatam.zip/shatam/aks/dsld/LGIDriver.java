package com.shatam.aks.dsld;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.jboss.netty.handler.codec.replay.ReplayingDecoder;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class LGIDriver extends AbstractScrapper{
	CommunityLogger LOGGER;
	static int repeat =0;
	int i = 0;
	WebDriver driver=null;
	public int inr = 0;
	static int duplicates = 0;
	ArrayList<String[]> set =new ArrayList<String[]>();
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new LGIDriver();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"LGI Homes.csv", a.data().printAll());
		U.log("duplicate::"+duplicates);
	}

	public LGIDriver() throws Exception {

		super("LGI Homes", "https://www.lgihomes.com/");
		LOGGER = new CommunityLogger("Lgi Homes");
		
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver=new ChromeDriver();
		String url = "https://www.lgihomes.com/";
		String html = U.getHTML(url);
		String comsec[]=U.getValues(html, "{\"Name\":", "\"Boost\""); 
//		U.log(comsec.length);
		for(String c:comsec) {
//			U.log(c);
			String itemurl1="https://www.lgihomes.com"+U.getSectionValue(c, "\"ItemUrl\":\"", "\"");
			
			String commname=U.getSectionValue(c, "\"", ",");
			
			String[]d=itemurl1.split("/");
		//	U.log(d.length);
			
			
			  if(d.length==5) {
				
				getcommunity(itemurl1,driver);
			  
			  
			  }
		}
		LOGGER.DisposeLogger();
	}

	

	private void getcommunity(String itemurl1, WebDriver driver) throws Exception {

		String html=getHtml(itemurl1, driver);
		
		String commsec[]=U.getValues(html, "<div class=\"coveo-card-layout CoveoResult\">", "View Community");
		

		
		U.log(itemurl1+"============="+commsec.length);
		for(String a:commsec) {
			String url="https://www.lgihomes.com"+U.getSectionValue(a, "href=\"", "\"");
			
			addDetails(url,html);
			
			
		}
		
	}
	private void addDetails(String itemurl,String reghtml1) throws Exception {
	//	if(!itemurl.contains("https://www.lgihomes.com/arizona/phoenix/segovia-at-estrella"))return;
		
		if (data.communityUrlExists(itemurl)){
			LOGGER.AddCommunityUrl(itemurl+ "***************************Repeated Url");
			return;
		}
		U.log(itemurl);

		String html=U.getHTML(itemurl);
		String comnamesec=U.getSectionValue(html, "<title>", "/title>");
		String comname=U.getSectionValue(comnamesec, "-", "<");
		if(comname==null) {
			comname=U.getSectionValue(html, "<h3 class=\"title\">", "</h3>");
		}
		U.log(comname+"================="+i);
		//======= Note ===========
		
				String note=U.getnote(html);

				
				//========= Address ========
			//	String geoCode = "False";
				
				String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
				String geo="FALSE";
				
				
				
				if(itemurl.contains("https://www.lgihomes.com/georgia/atlanta/bunn-farms")) {
					//,, AL 35761
					add[0]="171 County Lake Rd";
					add[1]=" New Market";
					add[2]="AL";
					add[3]="35761";
					latLong=U.getlatlongGoogleApi(add);
					
					
					geo="TRUE";
					
				}
				else {
				String addsec[]=U.getValues(html, "<span class=\"address\">", "</span>");
				
				add[0]=addsec[0];
				
				String ads[]=addsec[1].split(",");
				add[1]=ads[0];
				
				String ads1[]=ads[1].split(" ");
			//	U.log(Arrays.toString(ads1));
				add[2]=ads1[1];
				add[3]=ads1[2];
				
				
				U.log(Arrays.toString(add));
				
				
				
				
				
				String latlagsec=U.getSectionValue(html, "<a class=\"link action-communityoverview-direction\" ", "Get Directions");
				// href="https://www.google.com/maps/place/LGI+Homes+-+Brinley+Manor/@35.83543,-78.518727,595m/
				
				
				if(latlagsec!=null) {
				latLong[0]=U.getSectionValue(latlagsec, "/@", ",");
				latLong[1]="-"+U.getSectionValue(latlagsec, ",-", ",");
				}
				else {
					latLong=U.getlatlongGoogleApi(add);
					geo="TRUE";
				}
				U.log(Arrays.toString(latLong));
				
				}
				
				
				if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
					latLong = U.getlatlongGoogleApi(add);
					if (latLong == null)
						latLong = U.getlatlongHereApi(add);
//					latlag=U.getBingLatLong(add);

					geo = "TRUE";
				}
				if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
					add = U.getAddressGoogleApi(latLong);
					if (add == null)
						add = U.getAddressHereApi(latLong);
					geo = "TRUE";
				}
				if (add[3] == null && latLong[0] != ALLOW_BLANK) {
					String[] add1 = U.getAddressGoogleApi(latLong);
					if (add1 == null)
						add1 = U.getAddressHereApi(latLong);

					add[3] = add1[3];
					add1 = null;
					geo = "TRUE";
				}
			if(add[2].length()<2)
			{
				add=U.getAddressGoogleApi(latLong);
				geo="TRUE";
			}


				U.log("GEO: "+geo);	
				
		//==============================floorplans=====================================================
				String floorplansec=U.getSectionValue(html, "\"@type\": \"OfferCatalog\"", "</script>");
				String floorhtml=null;
				String floorpricesec = ALLOW_BLANK;
				
				String floorplandetails=ALLOW_BLANK;
				String floorplandesc=null;
				if(floorplansec!=null) {
				String floorurls[]=U.getValues(floorplansec, "\"@id\": \"", "\",");
				
			
				for(String fu:floorurls) {
					String floorurl="https://www.lgihomes.com"+fu;
					
					floorhtml=U.getHTML(floorurl);	
					floorpricesec += U.getSectionValue(floorhtml, "<span class=\"starting-price\">", "</span>");
					
					floorplandetails +=U.getSectionValue(floorhtml, " <ul class=\"floorplan-details\">", "</ul>");
					
					floorplandesc += U.getSectionValue(floorhtml, "floorplan-content", "<div class=\"floorplan-right\">");
					
				}
				}
				
				
		
		//===========================prices=====================================================
				
				String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
				String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
				
				String minPrice=ALLOW_BLANK;
				String maxPrice=ALLOW_BLANK;
				String minsqft=ALLOW_BLANK;
				String maxsqft=ALLOW_BLANK;
				
				
				
				prices=U.getPrices(html+floorpricesec, "From \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
				
				minPrice=prices[0];
				maxPrice=prices[1];
				
				
				U.log(Arrays.toString(prices));
				
				sqft=U.getSqareFeet(html+floorplandetails, "\\d{1},\\d{3} SF", 0);
				
				minsqft=sqft[0];
				maxsqft=sqft[1];
				
				U.log(Arrays.toString(sqft));
			
		//==========================communitytype===========================
				
				String commdesc=U.getSectionValue(html, "margin-bottom: 0.0001pt; text-align: justify;","</p>");
				String amenitiesection=U.getSectionValue(html, "amenities-list", "</ul>");
				String comdes1=U.getSectionValue(html, "Additional Community Info", "floorplansearch");
				
				
				String ctype=U.getCommType(commdesc+amenitiesection+comdes1);
				U.log(ctype);
		//===========================propertytype===============================
				String ptype=U.getPropType(floorplandesc+commdesc+amenitiesection+comdes1);
				U.log(ptype);
		//============================dtype==========================
				String dtype=U.getdCommType(floorplandesc+floorplandetails+comdes1+commdesc);
				
				U.log(dtype);
				
				//=========================pstatus============================
				html=html.replace("kept up-to-date on the Grand Opening of Huntington Pointe", "");
				String regs[]=U.getValues(reghtml1, "coveo-card-layout CoveoResult", "<div class=\"result-top\">");
				String regst=null;
				
				for(String df:regs) {
					String u=U.getSectionValue(df, "href=\"", "\"");
					
					if(itemurl.contains(u)) {
						
						regst=U.getSectionValue(df, "<div class=\"result-status\">", "</div>");
						
						if(regst!=null) {
							regst=regst.replace("Immediate Move-in", "Move-in Ready");
						}
						
					}
					
					
				}
				
				if(floorplandesc!=null) {
					floorplandesc=floorplandesc.replaceAll("now available|now selling|Available now|quick move-in at Ghost Hollow Estates located in Casa Grande|available for quick move-in.", "");
				}
			
				String commim=U.getSectionValue(html, "<div class=\"hero-content\">", "</div>");
			String resec=U.getSectionValue(html, "How Can I Own a New Home Today?", "</script>");
			String asf=null;
			if(resec!=null) {
				
				 asf=(commdesc+amenitiesection+comdes1+floorplandesc).replace(resec, "").replaceAll(" premier features that make these homes move-in ready|Upgraded and Move-in Ready||Additionally, coming soon to the community|kept up-to-date on the Grand Opening|", "");
			}
			
				String as=(asf).replaceAll("Floor Plans Available|This picturesque community features beautiful, move-in ready homes", "");
				String pstatus=U.getPropStatus((as+regst+commim).replace("Additionally, coming soon to the community", "").replace("to be kept up-to-date on the Grand Opening of Huntington Pointe", "").replace("premier features that make these homes move-in ready.", ""));
				U.log("MMMMMMMMMMMMM "+Util.matchAll(as, "[\\s\\w\\W]{30}Grand Opening[\\s\\w\\W]{30}", 0));
				
				U.log(pstatus);
				
				
				
				if(latLong[0]==null || latLong[1]==null)
				{
					latLong=U.getlatlongGoogleApi(add);
					geo="TRUE";
				}
					if(minPrice==null)minPrice=ALLOW_BLANK;
					if(maxPrice==null)maxPrice=ALLOW_BLANK;
					
					if(minsqft==null)minsqft=ALLOW_BLANK;
					if(maxsqft==null)maxsqft=ALLOW_BLANK;
					
					if(itemurl.contains("https://www.lgihomes.com/texas/houston/windsor-estates")) {
						comname="Windsor Estates";
					}
					if(itemurl.contains("https://www.lgihomes.com/texas/houston/el-tesoro")) {
						comname="El Tesoro";
					}
					if(itemurl.contains("https://www.lgihomes.com/arizona/phoenix/segovia-at-estrella")) {
						comname="Segovia at Estrella";
					}
						if(itemurl.contains("https://www.lgihomes.com/texas/houston/sterling-lakes-estates")) {
							comname="Sterling Lakes Estates";
						}
						if(itemurl.contains("https://www.lgihomes.com/north-carolina/charlotte/the-reserve-at-canyon-hills")) {
							comname="The Reserve At Canyon hills";
						}
					if(itemurl.contains("https://www.lgihomes.com/north-carolina/charlotte/the-reserve-at-canyon-hills"))
						pstatus="New Section Now Open";
if(itemurl.contains("https://www.lgihomes.com/north-carolina/jacksonville/mimosa-bay")) {
	ctype=ctype+", Master Planned";
}
						
if(itemurl.contains("https://www.lgihomes.com/arizona/phoenix/segovia-at-estrella"))
    pstatus=pstatus.replace(", New Section Coming Soon, Move-in Ready", "");
    
    
    if(itemurl.contains("https://www.lgihomes.com/arizona/phoenix/ghost-hollow-estates"))
    	pstatus=pstatus.replace("Quick Move-in,", "");
    
    
					LOGGER.AddCommunityUrl(itemurl);	
					
				data.addCommunity(comname.replaceAll("LGI Homes|Varina, NC -|Salem -|New Community", ""),itemurl, ctype);
				data.addAddress(add[0].replace("@",""), add[1], add[2].trim(), add[3]);
				data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
				data.addPropertyType(ptype, dtype);
				data.addPropertyStatus(pstatus.replace(", , ", ", ").replace("Ready For Move-in, Move-in Ready", "Move-in Ready").replaceAll("Move-in Ready Homes", "Move-in Ready").replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon, "));
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minsqft, maxsqft);
				data.addNotes(note);
				
				
				
				i++;
	}

	private String getHtml(String url,WebDriver driver) throws IOException, InterruptedException {
		int i = 1;
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					
					driver.manage().window().maximize();
					driver.get(url);
					//U.log("after::::"+url);
					
					
					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}

}
