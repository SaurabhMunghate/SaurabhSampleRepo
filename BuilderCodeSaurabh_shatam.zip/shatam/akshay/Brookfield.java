package com.shatam.akshay;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class Brookfield extends AbstractScrapper{
	CommunityLogger LOGGER;

	public Brookfield() throws Exception {

		super("Brookfield Residential Properties", "www.brookfieldrp.com");
		LOGGER = new CommunityLogger("Brookfield Residential Properties");
	}

	int i=0;
	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new Brookfield();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Brookfield Residential Properties.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
	
		String regionHtml = U.sendPostRequestAcceptJson("https://www.brookfieldresidential.com/sitecore/api/ssc/BrookfieldResidential-Web-Areas-BRP-Controllers-Api/additionalsearch", "{\"MinLongitude\":0,\"MinLatitude\":0,\"MaxLongitude\":0,\"MaxLatitude\":0,\"homebaths\":null,\"homebedrooms\":null,\"minimum_neighborhood_footage\":null,\"maximum_neighborhood_footage\":null,\"minimum_neighborhood_price\":null,\"maximum_neighborhood_price\":null,\"GroupMapPins\":false,\"isDefaultSearch\":false,\"ResultType\":\"FYHExperience\"}");//U.sendPostRequestAcceptJson("https://www.brookfieldresidential.com/sitecore/api/ssc/BrookfieldResidential-Web-Areas-BRP-Controllers-Api/FYHSearchTerm", "{\"itemId\":\""+stateid+"\"}");//U.getHtml("https://www.brookfieldresidential.com/new-homes?searchId="+stateid+"&searchText="+name+",United States", driver);
		//U.log(regionHtml);
		String communityData[] = U.getValues(regionHtml, "\"UniqueId\":{\"id\":\"", "\"maximumResidenceBaths\""); 
		U.log(communityData.length);
		U.setUpChromePath();
		WebDriver driver=new ChromeDriver();
		for(String cd:communityData) {
			
		
			
			
			
			String communityurl=U.getSectionValue(cd, "\"Url\":\"", "\"");
			
			
			if(communityurl.contains("alberta")||communityurl.contains("ontario/greater-toronto-area"))continue;
			//	U.log(cd);
			
			adddetails(cd,communityurl,driver);
			
		//	U.log("=============");
		}
		
		
	}
	public void adddetails(String jsonData,String comUrl,WebDriver driver) throws Exception {
		
		comUrl="https://www.brookfieldresidential.com"+comUrl;
		
		//if(!comUrl.contains("https://www.brookfieldresidential.com/new-homes/colorado/denver/brighton/brighton-crossings/villa"))return;
		
		U.log(comUrl+"============="+i);
		
		String comHtml=U.getHtml(comUrl, driver);
		
		U.log(jsonData);
		String comName=U.getSectionValue(jsonData, "\"mpcName\":\"", "\"");
		
		U.log(comName);
		
		String cType=ALLOW_BLANK;
		cType=U.getCommType(jsonData+comHtml);
		
		U.log(cType);
		
		String [] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String latlong[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		 latlong[0]=U.getSectionValue(jsonData, "\"latitude\":", ",");
		 latlong[1]=U.getSectionValue(jsonData, "\"longitude\":", ",");
		
		U.log(Arrays.toString(latlong));
		
		if(comUrl.contains("https://www.brookfieldresidential.com/new-homes/texas/austin-area/san-marcos/blanco-vista")) {
			
			add[0]="4040 Trail Ridge Pass";
			add[1]="San Marcos";
			add[2]="TX";
			add[3]="78666";
			latlong=U.getlatlongGoogleApi(add);
			
		}
		
		if(latlong[0].equals("0.0")) {
			if(comUrl.contains("texas") && comUrl.contains("austin")) {
			add[1]="Austin";
			add[2]="TX";
			latlong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlong);
			
			}
		}
		add=U.getAddressGoogleApi(latlong);
		U.log(Arrays.toString(add));
		String geo="TRUE";
		
		
		String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		prices =U.getPrices(comHtml+jsonData, "from \\$\\d{3},\\d{3}", 0);
		U.log(Arrays.toString(prices));

		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		sqft =U.getSqareFeet(comHtml+jsonData, "\\d,\\d{3} ft|\\d,\\d{3}-\\d,\\d{3} ft", 0);
		
		U.log(Arrays.toString(sqft));
		String pType=ALLOW_BLANK;
		
		 pType=U.getPropType(comHtml+jsonData);
		 U.log(pType);
			
			String dType=ALLOW_BLANK;
			
			 dType=U.getdCommType(comHtml+jsonData);
			 U.log(dType);
				String pStatus=ALLOW_BLANK;
				
				pStatus=U.getPropStatus(comHtml+jsonData); 
				U.log(pStatus);
				
				
				if(prices[0]==null)prices[0]=ALLOW_BLANK;
				if(prices[1]==null)prices[1]=ALLOW_BLANK;
				if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
				if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
				
				
				
				LOGGER.AddCommunityUrl(comUrl);
				data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
				data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
				data.addPrice(prices[0], prices[1]);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(sqft[0], sqft[1]);
				data.addPropertyType(pType, dType);
				data.addPropertyStatus(pStatus);
				data.addNotes(U.getnote(comHtml));
				
				
				
				
				
		
	i++;
	}
}
