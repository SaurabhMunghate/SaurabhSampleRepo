package com.shatam.akshay;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Scanner;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

import au.com.bytecode.opencsv.CSVWriter;

public class ButteCountyFromEsriArcGis {

	static StringWriter sw = new StringWriter();
	static CSVWriter writer = new au.com.bytecode.opencsv.CSVWriter(sw);
	static int i=0;
	public static void main(String[] args) throws Exception {
		
		String[] header = {"owner","APN","subDist","zone","book","page","Parcel","APN_BLDG_F",
				"CityStZIP","Owner_Add","ACRES","TaxCode","TRA_NUM","Latitude",
				"Longitude","Shape_STAr","Shape_STLe",
				"OBJECTID","GlobalID","STArea","STLength","geo"};
		writer.writeNext(header);
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions ();
	options.addExtensions (new File("/home/shatam-10/snap/skype/common/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));

	DesiredCapabilities capabilities = new DesiredCapabilities ();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);


		ChromeDriver driver = new ChromeDriver(capabilities);
		Thread.sleep(8000);
		String jsonFilePath="/home/shatam-10/buttejsonurls.txt";
		
		File f=new File(jsonFilePath);
		
		BufferedReader br = new BufferedReader(new FileReader(f));
		  
		  String st="";
		  Scanner sc = new Scanner(f);
		  
		    while (sc.hasNextLine())
		     st+=sc.nextLine();
	
	String jsonUrls[]=U.getValues(st, "http", "outSR=102100");
	
	
	for(String jsonU:jsonUrls) {
		
		String jsonUrl="http"+jsonUrls[0]+"outSR=102100";
	//	U.log(jsonUrl);
		String jsonData=U.getHTML(jsonUrl);
		U.log(U.getCache(jsonUrl));
	String dataSections[]=U.getValues(jsonData, "{\"attributes\":", "}},");

		for(String dS:dataSections) {
			if(i<=10000) {
			
		String	Apncheck=U.getSectionValue(dS, "\"APN\":\"", "\"");
			U.log(Apncheck);
			
			
			String owner=U.getSectionValue(dS, "\"Owner\":\"", "\"");
			U.log(owner);
			String APN=U.getSectionValue(dS, "\"APN\":\"", "\"");
			U.log(APN);
			
			
	
			
			String subDist=U.getSectionValue(dS, "\"SupDist\":", ",");
			U.log(subDist);
			String zone=U.getSectionValue(dS, "\"Zone\":\"", "\"");
			U.log(zone);
			String book=U.getSectionValue(dS, "\"Book\":\"", "\"");
			U.log(book);
			
			String page=U.getSectionValue(dS, "\"Page\":\"", "\"");
			U.log(page);
			
			String Parcel=U.getSectionValue(dS, "\"Parcel\":\"", "\"");
			U.log(Parcel);
			
			String APN_BLDG_F=U.getSectionValue(dS, "\"APN_BLDG_F\":\"", "\"");
			U.log(APN_BLDG_F);
			
			String CityStZIP=U.getSectionValue(dS, "\"CityStZIP\":\"", "\"");
			U.log(CityStZIP);
			
			String Owner_Add=U.getSectionValue(dS, "\"Owner_Add\":\"", "\"");
			U.log(Owner_Add);
			
			String ACRES=U.getSectionValue(dS, "\"ACRES\":", "\"");
			U.log(ACRES);
			
			String TaxCode=U.getSectionValue(dS, "\"TaxCode\":\"", "\"");
			U.log(TaxCode);
			
			String TRA_NUM=U.getSectionValue(dS, "\"TRA_NUM\":\"", "\"");
			U.log(TRA_NUM);
			
			String Latitude=U.getSectionValue(dS, "\"Latitude\":", ",");
			U.log(TaxCode);
			
			String Longitude=U.getSectionValue(dS, "\"Longitude\":", "\"");
			U.log(Longitude);
			
			String Shape_STAr=U.getSectionValue(dS, "\"Shape_STAr\":", ",");
			U.log(Shape_STAr);
			
			String Shape_STLe=U.getSectionValue(dS, "\"Shape_STLe\":", ",");
			U.log(Shape_STLe);
			
			String OBJECTID=U.getSectionValue(dS, "\"OBJECTID\":", ",");
			U.log(OBJECTID);
			
			String GlobalID=U.getSectionValue(dS, "\"GlobalID\":\"{", "}");
			U.log(GlobalID);
			
			String STArea=U.getSectionValue(dS, "\"Shape.STArea()\":", ",");
			U.log(STArea);
			
			String STLength=U.getSectionValue(dS, "\"Shape.STLength()\":", "}");
			U.log(STLength);
			
			String geo=U.getSectionValue(dS, "\"geometry\":{\"rings\":[", "]]]")+"]]";
			U.log(geo);
			
			String[] write = {owner,APN,subDist,zone,book,page,Parcel,APN_BLDG_F,CityStZIP,Owner_Add,ACRES,TaxCode,TRA_NUM,Latitude,
					Longitude,Shape_STAr,Shape_STLe,
					OBJECTID,GlobalID,STArea,STLength,geo};
			writer.writeNext(write);
		}
			}
		
	}
	
	
	
	i++;
	
	
	FileUtil.writeAllText(U.getCachePath()+"ButteCounty.csv", sw.toString());
}
}

