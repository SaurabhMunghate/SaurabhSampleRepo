package com.shatam.akshay;

import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;


import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

import au.com.bytecode.opencsv.CSVReader;

public class ConvertLatexToMathML {
	static StringWriter sw = new StringWriter();
	static au.com.bytecode.opencsv.CSVWriter writer = new au.com.bytecode.opencsv.CSVWriter(sw);
	
	public static void main(String[] args) throws IOException {
		
		CSVReader reader=new CSVReader(new FileReader("D:\\Questions\\VirtualClassRoomCache\\completdd\\studyadda\\physicsstudyadda\\alternating-current.csv"));
		
		String header[]= {"Srno","Question","options","Rightoption"};
		writer.writeNext(header);
		String nextRecord[];
		
		int i=1;
		
		 while ((nextRecord = reader.readNext()) != null) {
			 
			
			 

			String ex=nextRecord[1];
			String ex1=nextRecord[2];
			String rop=nextRecord[3];
			
			
			if(ex.equals("QUESTION"))continue;
			
			String rightOption=getCorrectAnswerNo(ex1,rop);
			
			if(rightOption.equals(""))continue;
			
			
			ex=convertEx(ex);
			ex1=convertEx(ex1);
			
			 U.log(ex);
			 U.log(ex1);
			U.log(rop);
			U.log("========"+i);
			
			String[] write = { i + "",ex, ex1,
					rightOption };
			writer.writeNext(write);
			
			
			
			 i++;
		}
	
			 
			FileUtil.writeAllText(U.getCachePath() + "Alternating Current.csv",  sw.toString());	 
			 
	}
	
	public static String  getCorrectAnswerNo(String ex1,String rop) {
		
		String c="";
		
		String options[]=ex1.split(";;");
				
				if(options[0].equals(rop))c="1";
				if(options[1].equals(rop))c="2";
				if(options[2].equals(rop))c="3";
				if(options[3].equals(rop))c="4";
		
				
		
		
		return c;
	}
	
	public static String convertEx(String ex) throws IOException {
		
		 String latex[]=U.getValues(ex, "[", "]");
		 
			// U.log(Arrays.toString(latex));
			 String latexHtml="";
			 String convertedEx="";
			 String mathMl[]=new String [latex.length];
			 for(int i=0;i<latex.length;i++) {
			 String convertionUrl="https://www.wiris.net/demo/editor/latex2mathml?latex="+latex[i];
			 
			 latexHtml=U.getHTML(convertionUrl);
			 
			mathMl[i]="<math xmlns"+U.getSectionValue(latexHtml, "<math xmlns", "</math>")+"</math>";
			 
			 
			 
			 }
			 
			 for(int j=0;j<latex.length;j++) {
				 
				 ex=ex.replace(latex[j], mathMl[j]);
				 
			 }
			 
			 ex=ex.replaceAll("\\[", "").replace("\\", "");
			 
			 
			 return ex;
	}

}
