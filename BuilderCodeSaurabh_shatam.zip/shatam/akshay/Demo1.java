package com.shatam.akshay;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class Demo1 {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		getGeo();
	}
	public static void getGeo() throws IOException, InterruptedException {
		
		for(int i=25000;i<=25400;i++) {
		String html=getHTML("https://app.regrid.com/us/ca/lassen/big-valley/"+i+".json");
		
     //  U.log(U.getCache("https://utility.arcgis.com/usrsvcs/servers/03342ae7580845ba858e3dd7f843fd03/rest/services/AGO/Parcels/MapServer/6/query?f=json&where=UPPER(Long_PID)%20LIKE%20%2701%25%27&returnGeometry=true&spatialRel=esriSpatialRelIntersects&outFields=*&outSR=4326"));
		U.log(html.length());
		Thread.sleep(3000);
		}
	}
	
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);
		U.log(url);
		String html = null;

		// chk responce code

//		int respCode = CheckUrlForHTML(path);
//		 U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"181.215.130.32", 3128));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language",
					"en-us,en;q=0.5");
	//		urlConnection.addRequestProperty("set-cookie", "srv_id_prd2_nginx_gis_services=72530c7cc91d68ef8e88dd9fd6d8cdac; expires=Mon, 09-Aug-21 05:31:47 GMT; max-age=3600; domain=.oakgov.com; httponly; secure; path=/");
		urlConnection.addRequestProperty("x-csrf-token", "UofdORqVdqxzE7lJMQ3NN2aOemTJ1a3ZoREK5yUmfZPn8yMqbWfiAXFnQCFNnR2qvaCChq9nEeLup42qSs7DlQ==");		
	urlConnection.addRequestProperty("referer", "https://gis.bisclient.com/sanpatriciocad/");
	urlConnection.setRequestProperty("authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzM4NCIsImp0aSI6ImR0dnZnaFAyeWNROStKcGZuZXB5cE5rODZWakpOOVwvK1JZQ2dwTFU2ZlAxUFhZaGJSbmlSQjY2cUpDV0NVU00yIn0.eyJpc3MiOiJodHRwczpcL1wvbXlkYXNoZ2lzLmNvbVwvU2llcnJhQ291bnR5UHVibGljIiwic3ViIjoiZDI5YWZlYWQtMDEwZC00ZTUyLWJhMjEtYTU2NDg3MzExYzY3IiwiYXVkIjoiaHR0cHM6XC9cL215ZGFzaGdpcy5jb21cL1NpZXJyYUNvdW50eVB1YmxpYyIsImp0aSI6ImR0dnZnaFAyeWNROStKcGZuZXB5cE5rODZWakpOOVwvK1JZQ2dwTFU2ZlAxUFhZaGJSbmlSQjY2cUpDV0NVU00yIiwiaWF0IjoxNjI5NTIxNDMyLCJuYmYiOjE2Mjk1MjE0MzIsImV4cCI6MTYyOTUzNzYzMiwicHJlZmVycmVkX3VzZXJuYW1lIjoic2NwIiwicm9sZXMiOiJbXCJndWVzdFwiXSJ9.mNayDKwd9SERU8y4_xASC-5pTCr-q38Aogu5GMlTbTVIHtWPNk7owuIEZdWAHyGl");
//      connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/70.0.3538.77 Chrome/70.0.3538.77 Safari/537.36");
	urlConnection.setRequestProperty("cookie", "_ga=GA1.2.229113375.1626870381; intercom-id-iumjbczf=d15433c8-6ff2-4db8-969a-f7356ae5fa83; _session_id=eb35df3b59fd524efc133dc5dd064d6b; intercom-session-iumjbczf=; hubspotutk=4ed7b41a8265addc7b4f58949b97bc15; _gac_UA-15180627-12=1.1629292066.CjwKCAjw3_KIBhA2EiwAaAAlijz1i5qv6pOB3S-PIcwyceR6bqmOm8SBHHGfD5jcyQrFL3srPoEpMhoCdtQQAvD_BwE; __hstc=243024157.4ed7b41a8265addc7b4f58949b97bc15.1629269190454.1629269190454.1629292066929.2; __cfruid=1ad8ef50e7d5df6ceb05881e7ad5884ff7384bd3-1629450252; _gid=GA1.2.1271072408.1629450258; _gat=1");
//      connection.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
	urlConnection.setRequestProperty("origin", "https://mydashgis.com");
	urlConnection.setRequestProperty("referer", "https://app.regrid.com/us/ca/lassen");
	//	urlConnection.addRequestProperty("origin", "https://gis.bisclient.com");
		//urlConnection.addRequestProperty("x-frame-options", "SAMEORIGIN");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
//		    U.log(html);

			// final String html = toString(inputStream);
			inputStream.close();
			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	

}
