package com.shatam.akshay;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class DreesHomes extends AbstractScrapper{

	CommunityLogger LOGGER;
	final String BASE_URL = "https://www.dreeshomes.com";
	int j = 0;
	WebDriver driver=null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new DreesHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Drees Homes.csv", a.data().printAll());
	}

	public DreesHomes() throws Exception {
		super("Drees Homes", "https://www.dreeshomes.com/");
		LOGGER = new CommunityLogger("Drees Homes");
	}

	String RegionCode[]= {"AUST","CINCI","CLEVE","DALL","HOUS","INDI","JAX","NASH","RALE","WASH"};
	
	
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver=new ChromeDriver();
		// TODO Auto-generated method stub
		int i=0;
		do {
		String regHtml=U.getHTML("https://dhp.dreeshomes.com/prod/communities?code="+RegionCode[i]);
				
		String commurls[]=U.getValues(regHtml, "\"details_url\":\"", "\"");
		for(String commUrl:commurls) {
			//	U.log(commUrl);
				addDetails(commUrl);
				
		}
				i++;
		}	
		while(i<10);
	}

	public void addDetails(String url) throws Exception {
		//if(j==0) {
		String comHtml=U.getHtml(url,driver);
		
		
		String communityname=U.getSectionValue(comHtml, "<h1 data-v-4feebad0=\"\">", "</h1>");
		U.log(communityname+"======"+j);
		if(communityname==null) {
			communityname=U.getSectionValue(comHtml, "active nuxt-link-active\">", "</a>");
		}
		String commdesc="";
		
		commdesc=U.getSectionValue(comHtml, "gutter-bottom flex-content", "container-fluid gutter-top");
		
		String comType=U.getCommType(commdesc);
		U.log(comType);
		
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addressSec[]=U.getValues(comHtml, "<p data-v-fcc0551c=\"\" class=\"margin-left-20 addrtext\">", "</p>");
	
		add[0]=addressSec[0];
		String address[]=addressSec[1].split(",");
		add[1]=address[0];
		
		String zipstate[]=address[1].split(" ");
		//U.log(zipstate.length);
		add[2]=zipstate[1];
		add[3]=zipstate[2];
		U.log(Arrays.toString(add));
		
		String directionhtml=U.getHtml(url+"#show-community-map",driver);
		String latlngsec=U.getSectionValue(directionhtml, "href=\"https://www.google.com/maps/dir/?api=1&amp;destination", "\"");
		latLong[0]=U.getSectionValue(latlngsec, "=", ",");
		latLong[1]=U.getSectionValue(latlngsec, ",", "&");
		
		U.log(Arrays.toString(latLong));
		
		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);
		
//		String commpricesec=U.getSectionValue(comHtml, "", "");
//		String floorplanpricesec=U.getSectionValue(comHtml, "<p class=\"no-margin\" data-v-6db3f4f7>", "</p>");
		
		String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		prices=U.getPrices(comHtml, "\\$\\d{3},\\d{3}", 0);
		
		U.log(Arrays.toString(prices));
		//String floorplansqftsec=U.getSectionValue(comHtml, "col-xs-12 col-md-6 col-lg-4 list-complete-item", "");
		
		
		sqft=U.getSqareFeet(comHtml, "\\d{1},\\d{3}", 0);
		
		U.log(Arrays.toString(sqft));
		
//		String remSec[]=U.getValues(comHtml, "{\"id", "community_amenity");
//		U.log(remSec.length);
//		for(String rem:remSec) {
//		comHtml=comHtml.replaceAll(rem, "");
//		}
		
		String pType=U.getPropType(comHtml.replaceAll("worked for Drees Custom Homes in Dallas|Richland is a charming craftsman style home|The plan can be modified for multi-generational living b|data-v-bd1b2650=\"\">Drees Custom Homes,", ""));
		U.log(pType);
		
		String dcommType=U.getdCommType(comHtml.replaceAll("branch|is_ranch", ""));
		U.log(dcommType);
		
		String pstatus=U.getPropStatus(comHtml.replaceAll("\"status\":\"Coming Soon\"|\"special_message\":\"Limited Home Sites Remain\"},", ""));
		U.log(pstatus);
		
		String maxPrice=prices[0];
		String minPrice=prices[1];
		
		String minsqft=sqft[0];
		String maxsqft=sqft[1];
		
		
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url + "*************repeated************");

			return;
		}
		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (comType == null)
			comType = ALLOW_BLANK;

		LOGGER.AddCommunityUrl(url);
		data.addCommunity(communityname.replace("&#x27;s", " &"), url, comType);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		//U.log(pstatus.length());
		data.addPropertyType(pType, dcommType);
		data.addPropertyStatus(pstatus);
		data.addNotes(U.getnote(comHtml));

		
		
		
		
		
		
		
		
		j++;
		//}
	}
	
	
	
}
