package com.shatam.akshay;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractDSLDcache extends AbstractScrapper {

	CommunityLogger LOGGER;

	public ExtractDSLDcache() throws Exception {

		super("DSLD Homes", "https://www.dsldhomes.com");
		LOGGER = new CommunityLogger("Dsld homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractDSLDcache();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "DSLD Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainhtml = U.getHTML("https://www.dsldhomes.com/communities");

		String communtiesection[] = U.getValues(mainhtml, "<a class=\"col-10 mr-auto CommunityCard_title px-0\"",
				"View Detail");
		int i = 0;

		for (String commurl : communtiesection) {
			// if(i==1)
			// break;
			String communityurl = "https://www.dsldhomes.com/" + U.getSectionValue(commurl, "href=\"/", "\"");
			U.log(communityurl + "=====" + i);

			String commhtml = U.getHTML(communityurl);

			adddetails(commhtml, communityurl);

			i++;
		}
	}

	public void adddetails(String commhtml, String communityurl) throws Exception {

		// for single community run
		// if(!communityurl.contains("https://www.dsldhomes.com/communities/louisiana/covington/audubon-trail"))
		// return;

		// =====================communityname==============================================
		String commName = U.getSectionValue(commhtml, "property=\"og:title\" content=\"", "\"");

		U.log(commName);

		String sectioncomm = U.getSectionValue(commhtml, "</script><script data-react-helmet=\"true\"",
				"</head><body><noscript>");

		String commdesc = U.getSectionValue(commhtml, "</script><script data-react-helmet=", "</script>");
		// U.log(sectioncomm);

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";

		String addresssection = U.getSectionValue(commhtml, "class=\"CommunityDetail_section mb-3\"",
				"</span></hgroup>");

		U.log(addresssection);
		if (addresssection != null) {
			addresssection = addresssection.replaceAll(
					"data-reactid=\"\\d+\"><b data-reactid=\"\\d+\">|Selling From|Model Home Address|</b><span data-reactid=\"\\d+\">",
					"").replaceAll("</span><span data-reactid=\"\\d+\">", ",");
			add = U.getAddress(addresssection);
		}

		/*
		 * add[0]=U.getSectionValue(addresssection, "\"streetAddress\":\"", "\"");
		 * add[1]= add[2]= add[3]=
		 */

		// 2207 Bald, Cypress Dr, Baton Rouge, LA 70816, USA

		U.log(add[0] + "    " + add[1] + "    " + add[2] + "     " + add[3]);
		U.log(Arrays.toString(add));

		String latlongsection = U.getSectionValue(commhtml, "<img src=\"/images/icons/share.svg\" ",
				" class=\"CommunityDetail_map\"");

		String lat = U.getSectionValue(latlongsection, "<a href=\"https://www.google.com/maps/place/", "/@");
		U.log(lat);

		latLong = lat.split(",");

		U.log(Arrays.toString(latLong));

		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);

		// ===============================available plans
		// section================================
		/*
		 * String availplans=communityurl+"#available-plans";
		 * 
		 * String availplanshtml=U.getHTML(availplans);
		 */
		String availurls[] = U.getValues(commhtml, "<a class=\"col-10 mr-auto PlanCard_title px-0\" ", "View Detail");
		String storysection = null;
		String planspricesection = null;
		String sqftsec = null;

		String plandesc = null;
		for (String a1 : availurls) {
			String planurls = "https://www.dsldhomes.com" + U.getSectionValue(a1, "href=\"", "\"");

			// String planhtml=U.getHTML(planurls);
			try {
				a1 = a1.replaceAll("=\"\\d{3}\"|=\"\\d{4}\"", "");
				String planname = U.getSectionValue(a1, "data-reactid>", "</a>");
				U.log(planname);
				String s = U.getSectionValue(commhtml, "\"caption\":\"" + planname + " ", "}]},");

				// U.log(s);

				storysection += U.getSectionValue(s, "\"stories\":", ",").replace("1", "1 Story")
						.replace("2", "2 Story").replace("3", "3 Story");
				;

				planspricesection += U.getSectionValue(a1, "class=\"px-3 px-lg-4 py-3 PlanCard_price \"",
						"</div></div>");

				sqftsec += U.getSectionValue(a1, "style=\"background-image:url(/images/icons/sqft.svg);\"",
						"</li></ul><ul class=");

				plandesc += U.getSectionValue(commhtml, "", "");
			} catch (NullPointerException ne) {

			}

		}

		// =============================available quick
		// section===================================

		/*
		 * String availquick=communityurl+"#available-homes";
		 * 
		 * String availquickhtml=U.getHTML(availquick);
		 */

		String availquickurls[] = U.getValues(commhtml, "<a class=\"col-10 mr-auto HomeCard_title px-0\"",
				"View Detail");

		String quickstorysection = null;
		String quickpricesection = null;
		String desquic = null;
		String quicksqftsec = null;
		String quickdesc = null;
		String quicname = null;
		for (String quicksec : availquickurls) {

			// U.log("======dsl"+a3);
			String quickurls = "https://www.dsldhomes.com"
					+ U.getSectionValue(quicksec, "href=\"", "<span class=\"HomeCard_subtitle\"");
			quickurls = quickurls.replaceAll(": \\d{4}", "");
			String quicnames = U.getSectionValue(commhtml, "<span class=\"HomeCard_tour \"", "</span></span>");

			if (quicnames != null)
				quicname = U.getSectionValue(quicnames, "alt=\"", "\"");

			if (quicnames == null) {
				String asd = U.getSectionValue(commhtml, "<a class=\"col-10 mr-auto HomeCard_title px-0\"",
						"<span class=\"HomeCard_subtitle\"").replaceAll(": \\d{4}", "");

				// U.log(asd);
				quicname = U.getSectionValue(asd, "<!-- react-text -->", "<!-- /react-text -->");
			}

			U.log(quicname);
			// <!-- react-text -->115 GENTLE CRESCENT LN.<!-- /react-text -->
			// "streetAddress":"115 GENTLE CRESCENT LN
			// String quickhtml=U.getHTML(quickurls);
			desquic = U.getSectionValue(commhtml, "\"streetAddress\":\"" + quicname + "", "\"postalCode\":\"");

			// U.log("jjjjjjjjjjjjjjjjjjjjjj"+desquic);

			try {
				quickstorysection += U.getSectionValue(desquic, "\"stories\":", ",").replace("1", "1 Story")
						.replace("2", "2 Story").replace("3", "3 Story");
				;

				quickpricesection += U.getSectionValue(quicksec, "<div class=\"px-3 px-lg-4 py-3 HomeCard_price\"",
						"</div></div>");

				quicksqftsec += U.getSectionValue(quicksec, "style=\"background-image:url(/images/icons/sqft.svg);\"",
						"</li></ul>");

				quickdesc += U.getSectionValue(desquic, "\"description\":", "\",\"elevation");

			}

			catch (NullPointerException ne) {

			}

		}
		// ======================================prices======================================

		String pricemain = U.getSectionValue(commhtml, "<span class=\"CommunityPrice_address\"",
				"</span></div><ul class=\"list-");

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		prices = U.getPrices(pricemain + quickpricesection + planspricesection, "\\$\\d{3},\\d{3}", 0);

		minPrice = prices[0];
		maxPrice = prices[1];

		U.log(Arrays.toString(prices));
		// ==========================sqft======================================
		String sqftmain = U.getSectionValue(commhtml, "style=\"background-image:url(/images/icons/sqft.svg);\"",
				"<ul class=\"list-unstyled d-flex\"");
		U.log(sqftmain);
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		sqft = U.getSqareFeet(sqftmain + quicksqftsec + sqftsec, ">\\d{1},\\d{3}|- \\d{1},\\d{3}<", 0);

		minsqft = sqft[0];
		maxsqft = sqft[1];

		U.log(Arrays.toString(sqft));

		// ====================================communtiytype=======================================
		String commtype = null;

		// U.log(commdesc);

		if (commdesc != null)
			commtype = U.getCommType(commdesc);
		U.log(commtype);

		// ====================================property
		// type=================================

		String comenu = U.getSectionValue(commhtml, "Community Menu</a><ul class=\"CommunityPageMenu_list",
				"CommunityPageMenu_contact\"");
		String hoa = ALLOW_BLANK;

		hoa = U.getSectionValue(commhtml, "<li class=\"CommunityPageMenu_listItem\"",
				"</style><div class=\"css-1na4j8c\"");

		String ptype = U.getPropType(commdesc + quickdesc + comenu + hoa);

		U.log(ptype);
		// ==================dtype=========================

		// U.log("======================"+quickstorysection);
		// U.log("////////////////////"+storysection);

		String dtype = U.getdCommType(commdesc + quickstorysection + storysection + quickdesc);

		U.log(dtype);

		// =====================pstatus=================================

		String ssec = U.getSectionValue(commhtml, "<li class=\"flex-fill CommunityPrice_homes pt-4\"",
				"<li class=\"flex-fill CommunityPrice_homes pt-4 ");
		if (ssec != null)
			ssec = ssec.replaceAll("</span><!-- react-text: \\d{3} -->", "");
		ssec = ssec.replaceAll("0 Quick Move-In", "");
		U.log("-------" + ssec);
		String ima = U.getSectionValue(commhtml, "<span class=\"flex-fill HomeCard_status\"", "</span><div");
		if (ima != null)
			ima = ima.replaceAll("Under Construction -", "");
		String regi = U.getSectionValue(commhtml, "class=\"CommunityDetail_section flex-row flex-wrap mb-3\"",
				"</hgroup><hgroup");
		if (regi != null)
			regi = regi.replaceAll("</b><!-- react-text: \\d{3} -->|Active", "");

		String pstatus = U.getPropStatus(commdesc + regi + ssec);

		U.log(pstatus);
		if (pstatus.contains("Move-in Ready Homes") || pstatus.contains("Move-in Ready")) {
			pstatus = "Quick Move-in";
		}
		if (pstatus.contains(", Move-in Ready Homes") || pstatus.contains(", Move-in Ready")) {
			pstatus = ", Quick Move-in";
		}

		if (data.communityUrlExists(communityurl)) {
			LOGGER.AddCommunityUrl(communityurl + "*************repeated************");

			return;
		}
		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (commtype == null)
			commtype = ALLOW_BLANK;

		LOGGER.AddCommunityUrl(communityurl);
		data.addCommunity(commName.replace("&#x27;s", " &"), communityurl, commtype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);

	}
}
