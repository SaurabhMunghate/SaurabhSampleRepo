package com.shatam.akshay;

import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractForino extends AbstractScrapper {
	private static String builderName = "Forino";
	private static String builderUrl = "https://www.forino.com/";
	static int j = 0 ;
	CommunityLogger LOGGER;
	ExtractForino() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractForino();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Forino.csv",
				a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String baseUrl = "https://www.forino.com/";
		String baseHtml =  U.getHTML(baseUrl);
	//	String regSec = U.getSectionValue(baseHtml, "Find Your New Home</a></li>", "SC Communities</a></li>");
//		U.getHTML(path)
		String[] regUrls = {"https://www.forino.com/pennsylvania/communities/","https://www.forino.com/south-carolina/communities/"};//U.getValues(regSec, "<a href=\"", "\"");

		for (String regUrl : regUrls) {
			U.log("regUrl : "+regUrl);
			String regHtml = U.getHTML(regUrl);
			
			String[] comSec =null;
			if(regUrl.contains("carolina")) {
			comSec= U.getValues(regHtml, "fwpl-row el-heg1y", "VIEW MOVE IN READY");
			}
			else {
				comSec=U.getValues(regHtml, "fwpl-row el-wrdoin", "</a>");
			}
		//	U.log(comSec.length);
			for(String cSec : comSec){
				//U.log(cSec);
				String cUrl = U.getSectionValue(cSec, "<a href=\"https:", "\"");
			//	U.log("cUrl : "+cUrl);
				addDetails("https:"+cUrl,cSec,regUrl);
				//break;
			}
			
		}
		LOGGER.DisposeLogger();
	}

	//TODO ::
	private void addDetails(String comUrl ,String comInfo,String regUrl) throws Exception {
	//	if(j==3)
	//	if(!comUrl.contains("https://www.forino.com/south-carolina/communities/ridgeland-lakes/")) return;
		{
			U.log(j+"\tcomUrl :"+comUrl);
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "*********************** Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			//U.log(comInfo);
	
			U.log(U.getCache(comUrl));
			String comHtml=U.getHTML(comUrl);
	String comName=U.getSectionValue(comHtml,"uabb-infobox-title-prefix", "</h2>").replace("\">", "").toLowerCase();
	comName=U.getCapitalise(comName);
	U.log(comName);
	
	String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
	String latLong[]= {ALLOW_BLANK,ALLOW_BLANK};
	String geo="FALSE";
	
	
	String addSec=U.getSectionValue(comHtml, "<div class=\"fl-module fl-module-heading fl-node-602dab5c911f1\"", "</h6>");
	if(addSec==null) {
		addSec=U.getSectionValue(comHtml, "fl-module fl-module-heading fl-node-602db5a032aef", "</h6>");
	}
	
	//U.log(addSec);
	//latLong[0]=U.getSectionValue(addSec, "", "");
	//latLong[1]=U.getSectionValue(addSec, "", "");
	
	add=U.getAddress(U.getSectionValue(addSec, "<span class=\"fl-heading-text\">", "</span>"));
	U.log(Arrays.toString(add));
	
	
	latLong=U.getlatlongGoogleApi(add);
	U.log(Arrays.toString(latLong));
	
	
	
	String floorplanUrl=regUrl.replace("/communities", "")+"floorplans/?_communty_list="+comName.replace(" ", "-").toLowerCase();
	
	U.log(floorplanUrl);
	
	String floorhtml=U.getHTML(floorplanUrl);
	
	
	String moveTabUrl=regUrl.replace("/communities", "")+"move-in-ready/?_communty_list="+comName.replace(" ", "-").toLowerCase();
	
	U.log(moveTabUrl);
	
	String moveHtml=U.getHTML(moveTabUrl);
	
	String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
	String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
	
	U.log(comInfo);
	comInfo=comInfo.replace("0's", "0,000");
	
	prices=U.getPrices(floorhtml+moveHtml+comInfo, "\\$\\d{3},\\d{3}", 0);
	
	sqft=U.getSqareFeet(floorhtml+moveHtml, "Square Feet: \\d{1},\\d{3}", 0);
	
	U.log(Arrays.toString(prices));
	U.log(Arrays.toString(sqft));
	
	String cType=U.getCommType(comHtml);
	
	String pType=U.getPropType(comHtml+floorhtml);
	U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}HOA[\\w\\s\\W]{30}", 0));
	String dType=U.getdCommType(floorhtml+moveHtml+comHtml);
	
	String pstatus=U.getPropStatus(comHtml);
	
	
			U.log("===================");
			
			
	if(prices[0]==null)prices[0]=ALLOW_BLANK;
	if(prices[1]==null)prices[1]=ALLOW_BLANK;
	
	if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
	if(sqft[1]==null)sqft[1]=ALLOW_BLANK;		
	
	
		if(comUrl.contains("https://www.forino.com/pennsylvania/communities/glen-ridge-estate/"))pstatus=ALLOW_BLANK;
	if(comUrl.contains("https://www.forino.com/pennsylvania/communities/mcintosh-farms-ii/")) {pType+=", Traditional Homes";dType+=", Ranch";}
	if(comUrl.contains("https://www.forino.com/pennsylvania/communities/pine-vista-estates/"))pType+=", Loft, Craftsman Style Homes";
	if(comUrl.contains("https://www.forino.com/south-carolina/communities/ridgeland-lakes/")||comUrl.contains("https://www.forino.com/south-carolina/communities/mossy-oaks/")||comUrl.contains("https://www.forino.com/pennsylvania/communities/temple-terrace/"))pType+=", Patio Homes";
		if(comUrl.contains("https://www.forino.com/south-carolina/communities/academy-park/"))prices[0]="$400,000";
	
		
		data.addCommunity(comName, comUrl, cType);
		data.addLatitudeLongitude(latLong[0], latLong[1], geo);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addPrice(prices[0], prices[1]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyStatus(pstatus.replace("Move-in Ready", "Move-in Ready Homes"));
		data.addPropertyType(pType, dType);
		data.addNotes(U.getnote(comHtml));

		}
		j++;
	}

	
}