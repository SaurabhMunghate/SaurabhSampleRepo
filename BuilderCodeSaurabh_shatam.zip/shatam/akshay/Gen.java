package com.shatam.akshay;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.utils.U;

import au.com.bytecode.opencsv.CSVReader;

public class Gen {
	
	static WebDriver driver=null;
	
	public static void main(String[] args) throws InterruptedException, IOException {
		U.setUpChromePath();
		driver=new ChromeDriver();
		String url="http://www.genericartmedicine.com/franchisee/";
		driver.get(url);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"txtShopCode\"]")).sendKeys("GMMH0366");
		driver.findElement(By.xpath("//*[@id=\"txtPass\"]")).sendKeys("123456");
		driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
		Thread.sleep(3000);
		
		driver.get("http://www.genericartmedicine.com/franchisee/medicine-survey.aspx?action=new");
		Thread.sleep(2000);
		String pg=driver.getPageSource();
		Thread.sleep(3000);
		
		
		
		CSVReader reader=new CSVReader(new FileReader("G:\\SURVEY.csv"));
		
		 String[] nextRecord; 
		 
	        while ((nextRecord = reader.readNext()) != null) {

	    		
	      
	        	
	        	if(nextRecord[3].length()==10) {
	        		driver.get("http://www.genericartmedicine.com/franchisee/medicine-survey.aspx?action=new");
	        		Thread.sleep(2000);
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMobNo\"]")).sendKeys(nextRecord[3]);
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_btnProceed\"]")).click();
	        		
	        		Thread.sleep(2000);
	        		String pg1=driver.getPageSource();
	        		if(pg1.contains(" You have already done survey of this client"))continue;
	        		if(pg1.contains("nter Valid Mobile No")) {
		    			continue;
		    		}
	        		  try {
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtWhatsapp\"]")).sendKeys(nextRecord[3]);
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtHeadName\"]")).sendKeys(nextRecord[1]);
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtAddr\"]")).sendKeys(nextRecord[2]);
	        		
	        		String [] medicine=nextRecord[4].split("");
	        		String med=""+medicine[0]+medicine[1]+medicine[2]+medicine[3];
	        		
	        		
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(med);
	        		Thread.sleep(2000);
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(Keys.ARROW_DOWN);
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(Keys.ENTER);
	        		
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMonthly\"]")).sendKeys("3");
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_ddrMedUnit\"]")).sendKeys("Strip");
	        		
	        		
	        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_btnAdd\"]")).click();
	        		Thread.sleep(2000);

	        	
	        		if(driver.getPageSource().contains("Enter Medicine Name, Monthly Requirement and Present Cost")) {
	        			driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys("Vogli");
		        		Thread.sleep(2000);
		        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(Keys.ARROW_DOWN);
		        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(Keys.ENTER);
		        		
		        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMonthly\"]")).sendKeys("3");
		        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_ddrMedUnit\"]")).sendKeys("Strip");
		        		
		        		
		        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_btnAdd\"]")).click();
		        		Thread.sleep(2000);

	        		}
	        		  }
	        		  catch(UnhandledAlertException uae) {
	        			 
	        			 // Alert a=new Al
	        			  if(isAlertPresent()) {
	        			  driver.switchTo().alert().accept();
	        			  }
	        			  driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).clear();
	        			  driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys("Vogli");
			        		Thread.sleep(2000);
			        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(Keys.ARROW_DOWN);
			        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMedicine\"]")).sendKeys(Keys.ENTER);
			        		
			        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_txtMonthly\"]")).sendKeys("3");
			        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_ddrMedUnit\"]")).sendKeys("Strip");
			        		
			        		
			        		driver.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder2_btnAdd\"]")).click();
			        		Thread.sleep(2000);

	        			  
	        			  
	        			  
	        			  
	        		  }
	        		U.log(nextRecord[0]+" "+nextRecord[1]+" "+nextRecord[2]+" "+nextRecord[3]+" "+nextRecord[4]);
	        		
	        		
	        	
	        		
	        		
	        		
	        		
	        	}
	    		
	        }
		
	}
	 public static boolean isAlertPresent() 
	  { 
	      try 
	      { 
	          driver.switchTo().alert(); 
	          return true; 
	      }   // try 
	      catch (NoAlertPresentException Ex) 
	      { 
	          return false; 
	      }   // catch 
	  } 
}
