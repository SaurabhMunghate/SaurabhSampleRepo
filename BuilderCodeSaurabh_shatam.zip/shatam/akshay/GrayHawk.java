package com.shatam.akshay;

import java.io.File;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.shatam.b_161_180.ExtractGrayHawkHomes;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class GrayHawk extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	private static String baseUrl = "https://www.grayhawkhomes.com/";

	WebDriver driver=null;
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new GrayHawk();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Grayhawk Homes.csv", a.data().printAll());
		//U.log("duplicates"+duplicates);
	}

	public GrayHawk() throws Exception {

		super("Grayhawk Homes", "https://www.grayhawkhomes.com/");
		LOGGER = new CommunityLogger("Grayhawk Homes");
	}

	public void innerProcess() throws Exception {
		  U.setUpChromePath(); 
//		  driver = new ChromeDriver();
		 
		
		ChromeOptions options = new ChromeOptions ();

		options.addExtensions (new File("C:\\Users\\mark2\\Cache\\Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));

		//DesiredCapabilities capabilities = new DesiredCapabilities ();

		//capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(options); //capabilities
		Thread.sleep(6000);
		int total = 0;
		U.log(baseUrl);
		Thread.sleep(6000);
		driver.get(baseUrl);
		Thread.sleep(3000);
		String html = U.getHtml(baseUrl,driver);//manual add vpn and change region from browser to get cache 
	//	U.log(html);
		String regUrlSections = U.getSectionValue(html, "Find Your Home", "Build On Your Land");
		String [] regionUrls = U.getValues(regUrlSections, "<a href=\"", "\">");
		for(String regionUrl : regionUrls){
			U.log("Reg Url=="+regionUrl);
			String regionHtml = U.getHtml(regionUrl,driver);	
			if(regionUrl.contains("/georgia-new-home-communities/south-columbus-new-homes-sale/"))
			{
				regionHtml = regionHtml.replace("</span></div></div></div></div></section>", "");
			}
			
			String[] comSections = U.getValues(regionHtml, "https://www.grayhawkhomes.com/new-home-communities", "View Community");
//			U.log(comSections.length);
			LOGGER.AddRegion(regionUrl, comSections.length);
			total += comSections.length;
			for(String c : comSections){
				U.log(c);
				String comUrl = "https://www.grayhawkhomes.com/new-home-communities/"+U.getSectionValue(c, "/", "\"");
				String html1 = U.getHtml(comUrl,driver);
				if(comUrl != null){
					comUrl = comUrl.replace("/iowa-new-home-communities/","/iowa/");
					U.log("comUrl :: "+comUrl);
					
					findCommunityDetails(comUrl,html1);
				}
			}//eof for inner

		}//eof for outer
		U.log("Total community ::"+total);
		LOGGER.countOfCommunity(total);
		LOGGER.DisposeLogger();
	}		
	
	public void findCommunityDetails(String comurl,String html) throws Exception {
		
		
		
	//	if(!comurl.contains("https://www.grayhawkhomes.com/new-home-communities/midland-ga-new-homes-charleston-place"))return;
		LOGGER.AddCommunityUrl(comurl);
		String comsec=U.getSectionValue(html, "<h1 class=\"title", "/h3>");
		
		String comname=U.getSectionValue(comsec, "\">", "</h1>");
		U.log(comname);
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		String minsqft=ALLOW_BLANK;
		String maxsqft=ALLOW_BLANK;
		comsec=comsec.replace("<br />", ",");
		comsec=comsec+"end";
		U.log(comsec);
		String addsec=U.getSectionValue(comsec, "<h3>", "<end");
		U.log(addsec);
		
		String address[]=addsec.split(",");
		U.log(addsec.length()+"======"+Arrays.toString(address));
		add[0]=address[0].trim();
		add[1]=address[1].trim();
		add[2]=address[2].trim();
		
		String latlongsec=U.getSectionValue(html, "https://www.google.com/maps", "\"");
		
		latlong[0]=U.getSectionValue(latlongsec, "/@", ",");
		latlong[1]="-"+U.getSectionValue(latlongsec, ",-", ",");
		U.log(Arrays.toString(latlong));
		
		if(add[3]==ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latlong);
			geo="TRUE";
		}
		
		
		html=html.replace("306's", "360,000").replace("0's", "0,000");
		
//		String floorhtml="";
//		String availhtml="";
//		try {
//			floorhtml=U.getHtml(comurl, driver);
//		}
//		catch(Exception e) {}
//		
//		
//		
		
		String modelhtml="";
		try {
			String modelurl[]=U.getValues(html, "<a href=\"https://www.grayhawkhomes.com/home-builder-plans", "\"");
			for(String durl:modelurl) {
				String murl="https://www.grayhawkhomes.com/home-builder-plans"+durl;
				U.log(murl);
				modelhtml+=U.getHtml(murl,driver);
			}
		
		
		}
		catch(Exception ne) {
			
		}
		
		String availhtml="";
		try {
			String availurl[]=U.getValues(html, "https://www.grayhawkhomes.com/new-homes-for-sale", "\"");
			for(String aurl:availurl) {
				String avaurl="https://www.grayhawkhomes.com/new-homes-for-sale"+aurl;
				U.log(avaurl);
				availhtml+=U.getHtml(avaurl,driver);
			}
		
		
		}
		catch(Exception ne) {
			
		}
		U.log(modelhtml.length());
		String prices[]=U.getPrices(html+modelhtml, "From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|Priced From the Mid \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}", 0);
		
		minPrice=prices[0];
		maxPrice=prices[1];
		
		String sqft[]=U.getSqareFeet(html+modelhtml, "\\d{4} SqFt", 0);
		minsqft=sqft[0];
		maxsqft=sqft[1];
		html=html.replaceAll("boats, stone cottages|Auburn new homes are now available|center;\">Coming Soon</h2>|The Lakeside Village outlets are only|<h2>Lakeside</h2>", "");
		String comtype=U.getCommType(html);
		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}lakeside[\\w\\s\\W]{30}", 0));
		String ptype=U.getPropType(html+modelhtml);
		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}cottage[\\w\\s\\W]{30}", 0));
		
	
		
		availhtml=availhtml.replace("1st Floor", "1 Story").replace("2nd Floor", "2 Story");
		
		modelhtml=modelhtml.replace("1st Floor", "1 Story").replace("2nd Floor", "2 Story");
		String dtype=U.getdCommType(html+modelhtml+availhtml);
		String pstatus=U.getPropStatus(html);
		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}now available[\\w\\s\\W]{30}", 0));
		
		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (comtype == null)
			comtype = ALLOW_BLANK;
	//	if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/homes-smiths-station-al-smiths-walk"))ptype+="Patio Homes";
	//	if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/homes-auburn-al-donahue-ridge"))ptype="Patio Homes";
//		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/homes-auburn-al-donahue-ridge"))dtype="2 Story";
//		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/midland-ga-new-homes-charleston-place"))dtype="1 Story, 2 Story";
//		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/homes-fortson-ga-ivy-park"))dtype="1 Story, 2 Story";
		data.addCommunity(comname, comurl, comtype);
		data.addAddress(add[0].replaceAll("Off Site Sales Center|,", "").replace("** ", ""), add[1].trim(), add[2], add[3]);
		data.addLatitudeLongitude(latlong[0], latlong[1], geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(U.getnote(html));
		
		U.log("=================="+j);
		j++;
	}
	
	
	
}
