package com.shatam.akshay;

import java.util.Arrays;

public class Sort {
public static void main(String[] args) {
	int a[]=new int[]{5,56,16,26,16,161,6};
	int temp;
	for(int i=0;i<a.length;i++) {
		for(int j=i+1;j<a.length;j++) {
			if(a[i]>a[j]) {
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			
			
		}
	}
	System.out.print(Arrays.toString(a));
	
	
}
}
