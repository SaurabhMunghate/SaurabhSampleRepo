package com.shatam.akshay;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.bcel.generic.CPInstruction;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class Taylormorrison extends AbstractScrapper {
	// private static String string;
	CommunityLogger LOGGER;
	static int i = 0;

	public Taylormorrison() throws Exception {

		super("Taylor Morrison Homes", "https://www.taylormorrison.com");
		LOGGER = new CommunityLogger("Taylor Morisson homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper as = new Taylormorrison();
		as.process();
		FileUtil.writeAllText(U.getCachePath() + "Taylor morrison.csv", as.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String mainhtml = U.getHTML("https://www.taylormorrison.com");
		String regurlssec = U.getSectionValue(mainhtml, "\"Search Homes\",\"state\":", "\"bedrooms\"");
		Set s = new HashSet();
		String curl1 = null;
		String regurls[] = U.getValues(regurlssec, "\"value\":\"", "\"}");
		// U.log(regurls.length);
		 int k=0;
		for(String reg:regurls) {
			//U.log(reg);
			String commurls[]=U.getValues(U.getHTML("https://www.taylormorrison.com"+reg), "\"communityDetailLink\":", "community");
			//U.log(commurls.length);
			for(String commurl:commurls) {
				
			//	U.log(k);
				k++;
			//	U.log(commurl.length()+commurl.length());
				adddetails("https://www.taylormorrison.com"+U.getSectionValue(commurl, "\"Url\":\"", "\""),commurl);
			}
		}
		
		LOGGER.DisposeLogger();
		//U.log(s.size());
	}

	public void adddetails(String commurl, String curl) throws Exception {
		
		// if(!commurl.contains("https://www.taylormorrison.com/az/phoenix/glendale/stonehaven-expedition-collection"))return;

		U.log(commurl + "====================" + i);
		
		
		
		if (data.communityUrlExists(commurl)) {
			LOGGER.AddCommunityUrl("*****************REPEATED**************" + commurl);
			
			return;
		}
		
		LOGGER.AddCommunityUrl(commurl);
		
		String commhtml = U.getHTML(commurl);
		
		
		
		String communityname = U.getSectionValue(commhtml, "\"communityName\":\"", "\"");
		
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/vacaville/farmstead"))communityname="Farmstead Square";
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/orinda/wilder-canyon"))communityname="Wilder Canyon";
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/sunnyvale/ov8tion"))communityname="Ov8tion";
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/napa/pear-tree"))communityname="Pear Tree";
		communityname=communityname.replace("- Age Restricted 55+ Community", "");
		communityname=communityname.replace("55+", "").replace("Coach Homes", "").replace("Cottages", "");
		communityname=communityname.replace("s,", "s -");
		
		
		
		U.log(communityname);

		// ======================address============================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";
		// "address":{"address1":"17 Bethesda Church
		// Road","address2":"","city":"Lawrenceville","state":"GA","zip":"30044"},
		String addsec = U.getSectionValue(commhtml, "\"address\":", "},");

		
		if (addsec != null) {
			addsec = addsec.replace("Florida", "FL");
			addsec = addsec.replace("Tx", "TX");
		}
		U.log(addsec);

		// String address[]=addsec.split("+");
		String add12 = U.getSectionValue(addsec, "\"address1\":\"", "\"");
		
		if (add12 != null) {
			add[0] = add12;
		} else {
			String add21 = U.getSectionValue(addsec, "\"address2\":\"", "\"");
			add[0] = add21;
		}

		
		add[1] = U.getSectionValue(addsec, "\"city\":\"", "\"");
		add[2] = U.getSectionValue(addsec, "\"state\":\"", "\"");
		add[3] = U.getSectionValue(addsec, "\"zip\":\"", "\"");

		U.log(Arrays.toString(add));

		// ================================latlagsec=============================================

		U.log(curl);
		String latlagsec = U.getSectionValue(curl, "\"latLng\":{", ",\"photos\":");
		latLong[0] = U.getSectionValue(latlagsec, "\"lat\":", ",");
		latLong[1] = U.getSectionValue(latlagsec, "\"lng\":", "}");

		U.log(Arrays.toString(latLong));
		if(commurl.contains("avalon-at-friendswood") || commurl.contains("avalon-at-friendswood-60s-venture")) {
			add[1]="Houston";
			add[2]="TX";
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(commurl.contains("https://www.taylormorrison.com/ca/southern-california/san-pedro/harbor-pointe")) {
			add[1]="San Pedro";
			add[2]="CA";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		// =============geo===================================

		
		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			
			add[1]=U.getSectionValue(commhtml, "\"city\":\"", "\"");
			add[2]=U.getSectionValue(commhtml, "\"state\":\"", "\"");
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
			
			
		
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);

		// ===================================floorplansection========================================
		String floorplansec = null;

		String floorplanhtml = U.getHTML(commurl + "/floor-plans");

		if (floorplanhtml != null) {

			floorplansec = U.getSectionValue(floorplanhtml, "\"floorPlansListDataArray\":", "</script");

		}

		// ==================================available
		// home=====================================

		String availablehomesec = null;
		String avaialablehomehtml = U.getHTML(commurl + "/available-homes");

		if (avaialablehomehtml != null) {

			availablehomesec = U.getSectionValue(avaialablehomehtml, "availablePlansList\":", "</script");

		}

		// =====================================================prices==============================================================

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		String priceSec="";
		priceSec=U.getSectionValue(commhtml, "\"pricing\":\"", "\"");
		
		priceSec=priceSec.replace("0s", "0,000");
		U.log(priceSec);
		commhtml = commhtml.replace("0s", "0,000").replace("\"pricing\":\"Low $200&#39;s\"",
				"\"pricing\":\"Low $200,000\"");
		prices = U.getPrices(priceSec+availablehomesec + floorplansec + commhtml,
				"\\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\"minPrice\":\\d{6}|Priced From the Mid \\$\\d{3},\\d{3}|\"price\":\\d{6}", 0);
		minPrice = prices[0];
		maxPrice = prices[1];
		U.log(Arrays.toString(prices));

		// ==================================sqft=====================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		sqft = U.getSqareFeet(availablehomesec + floorplansec + commhtml,
				" features \\d{4} square feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\"text\":\"Sq. Ft.\",\"value\":\"\\d{4}\"}|\"minSqFt\":\\d{4}",
				0);
		minsqft = sqft[0];
		maxsqft = sqft[1];
		U.log(Arrays.toString(sqft));

		// ============================communitytype=================================
		String subTitle="";
		subTitle=U.getSectionValue(commhtml, "\"title\":\"", "\"description");
		String commdesc = U.getSectionValue(commhtml, "\"description\":\"", "</community-about>");

		String ctype = null;

		ctype = U.getCommType(subTitle+commdesc);

		U.log(ctype);

		if (ctype == null)
			ctype = ALLOW_BLANK;

		// ============================propertytype====================================

		String ptype = U.getPropType(commdesc + availablehomesec + floorplansec);
		U.log(ptype);

		// ========================dpropertytype========================================
		String derivedpropSection = (commdesc + availablehomesec + floorplansec).replace("Single story", "1 Story")
				.replace("{\"text\":\"Story\",\"value\":\"3\"}", "3 Story")
				.replace("{\"text\":\"Story\",\"value\":\"1\"}", "1 Story")
				.replace("{\"text\":\"Story\",\"value\":\"2\"}", "2 Story");
		String dtype = U.getdCommType(derivedpropSection);
		U.log(dtype);
		// ================================pstatus=========================================
		U.log("===0"+U.getCache(commurl));
		String statusSec="";
		statusSec=U.getSectionValue(commhtml, "\"community\":{\"status\":\"", "\"");
		String bannerTitle="";
		bannerTitle=U.getSectionValue(commhtml,"\"bannerTitle\":\"", "\"");
		
		
		//U.log(subTitle);
	//	U.log("?MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(floorplansec, "[\\s\\w\\W]{30}opening soon[\\s\\w\\W]{30}", 0));
		//U.log("======"+statusSec);
		String pstatus = U.getPropStatus((subTitle+bannerTitle+statusSec+commdesc + availablehomesec + floorplansec).replaceAll("plan is opening soon|Grand Opening event|Grand Opening and other special events|we get closer to our Grand Opening", ""));

		
	//	if(commurl.contains("https://www.taylormorrison.com/co/denver/loveland/the-city-collection-at-lakes-at-centerra"))pstatus+=", Now Selling";
		
		
		U.log(pstatus);
		if (minPrice == null)
			minPrice = ALLOW_BLANK;
		if (maxPrice == null)
			maxPrice = ALLOW_BLANK;
		if (minsqft == null)
			minsqft = ALLOW_BLANK;
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;

		if (commurl.contains("https://www.taylormorrison.com/co/denver/castle-pines/timberline-50s"))
			add[2] = "CO";


		if(add[0].contains("Unnamed Road")||add[0].contains("Sold Out Community")||add[0].contains("By Appointment Only")||add[0].contains("SOLD OUT")||add[0].contains("TBD") || add[0].contains("Coming Soon") || add[0].contains("To Be Determined") || add[0].contains("Coming Soon To") || add[0].contains("For GPS Purposes") || add[3].length()==0) {
			
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(latLong[0].length()<4 || latLong[1].length()<4) {
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		//https://www.taylormorrison.com/tx/houston/friendswood/avalon-at-friendswood-90s-regency
		if(commurl.contains("https://www.taylormorrison.com/sc/charlotte/indian-land/covington-estates"))add[0]="Barberville Rd";
		if(commurl.contains("https://www.taylormorrison.com/or/portland/tigard/eastridge-legacy-series"))add[0]="16870 SW Rockhampton Ln";
		if(commurl.contains("https://www.taylormorrison.com/fl/sarasota/lakewood-ranch/park-east-at-azario")) {
			add[0]="";
			add[1]="Bradenton";
			add[2]="FL";
			latLong=U.getlatlongGoogleApi(add);
		    add=U.getAddressGoogleApi(latLong);
		    geo="TRUE";
		   }
		
		if(ptype.contains(", Townhouse") && ptype.contains(", Townhome"))ptype=ptype.replace(", Townhouse", "");
		if(ptype.contains("Townhouse, ") && ptype.contains(", Townhome"))ptype=ptype.replace("Townhouse, ", "");
		
		pstatus=pstatus.replaceAll("Move-in Ready Homes,|Move-in Ready Homes|, Move-in Ready|Move-in Ready", "");
		pstatus=pstatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon").replace("Now Open, Opening Soon", "Now Open").replace("Opening Late Spring 2021, Opening Soon", "Opening Late Spring 2021").replace("Opening Early 2021, Opening Soon", "Opening Early 2021");
		if(pstatus.length()==0)pstatus=ALLOW_BLANK;
		
		
		
		
		
		
		data.addCommunity(communityname.replace(" | Affordable Housing", ""), commurl, ctype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("Annie&#39;s", "Annie's").replace(",", ""), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype.replace("Townhouse, Townhome", "Townhome"), dtype);
		data.addPropertyStatus(pstatus.replace(", Move-in Ready Homes", ", Quick Move-in"));
		data.addNotes(note);

		i++;
}
	

}
