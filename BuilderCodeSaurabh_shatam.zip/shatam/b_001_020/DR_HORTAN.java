package com.shatam.b_001_020;
//package com.shatam.drhorton;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class DR_HORTAN	 extends AbstractScrapper {
	CommunityLogger LOGGER;
	static String HOME_URL = "https://www.drhorton.com/";
	static String BUILDER_NAME = "D.R. Horton";
	static HashSet<String> uniqUrl=null;
	static int dup=0;
	static int err=0;
	public DR_HORTAN() throws Exception {
		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}
	private void getCountUsingDriver() throws Exception {
		WebDriver driver = null;
		U.setUpChromePath();
		driver = new ChromeDriver();
		String html = U.getHTML(HOME_URL);
		ArrayList<String> states = Util.matchAll(html, "<a href=\"(.*?)\"><path class=\"active-state\" id=\"", 1);
		for(String state : states){
			state = "https://www.drhorton.com"+state;
			String stateHtml = getHtml(state,driver);
			stateHtml = U.removeComments(stateHtml);
			String resultCount = Util.match(stateHtml, "<strong>(\\d+)</strong> results for <strong>", 1);
			writeLogger(state, resultCount);
		}
		driver.quit();
		closeLogger();
	}
	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new DR_HORTAN();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"D.R. Horton.csv", a.data().printAll()); 
		U.log("Total Community::"+uniqUrl.size());
		U.log("Total Community ERR::"+err);
		U.log("Total Duplicate::"+dup);
		
	}

	private StringBuffer _writer = new StringBuffer();
	
	private void writeLogger(String url,String actualCount){
		_writer.append("URL :"+url).append(" : Actual : "+actualCount).append("\n");
	}
	
	private void closeLogger() throws IOException{
		FileUtil.writeAllText(U.getCachePath()+"D.R. Horton Logger_COUNT1.txt", _writer.toString());
		U.log(".......... Logger written.");
		_writer = null;
	}
	static boolean gotCommunity = false;
	HashMap<String, String>regionUrlMap=new HashMap<String,String>() {{
		put("/hawaii", "/hawaii");//1
		put("/florida", "/florida");//2
		put("/south-carolina", "/south-carolina");//3
		put("/georgia", "/georgia");//4
		put("/alabama", "/alabama");//5
		put("/tennessee", "/tennessee");//6
		put("/new-jersey", "/New-Jersey/New-Jersey");//7
		put("/pennsylvania", "/Pennsylvania/Pennsylvania");//8
		put("/delaware", "/delaware");//9
		put("/maryland", "/Maryland/Maryland");//10
		put("/washington", "/washington");//11
		put("/texas", "/texas");//12
		put("/california", "/california");//13
		put("/arizona", "/arizona");//14
		put("/nevada", "/nevada");//15
		put("/utah", "/Utah/Salt-Lake-City");//16
		put("/colorado", "/colorado");//17
		put("/new-mexico", "/new-mexico");//18
		put("/oregon", "/oregon");//19
		put("/louisiana", "/louisiana");//20
		put("/virginia", "/virginia");//21
		put("/illinois", "/illinois");//22
		put("/oklahoma", "/oklahoma");//23
		put("/minnesota", "/minnesota");//24
		put("/north-carolina", "/north-carolina");//25
		put("/mississippi", "/mississippi");//26
		put("/west-virginia", "/west-virginia");//27
		put("/ohio", "/ohio");//28
		put("/iowa", "/iowa");//29
		put("/indiana", "/indiana");//30
		put("/nebraska", "/nebraska");//31
	}};
	@Override
	protected void innerProcess() throws Exception {
//		getCountUsingDriver();
		long startTime = System.nanoTime();
		String mainHtml=U.getHTML("https://www.drhorton.com/");
		String mainSec=U.getSectionValue(mainHtml, "<g id=\"g5\">", "</g>");
		String regions[]=U.getValues(mainSec, "<a ", "</a>");
		U.log(regions.length);
		int regCount=0;
		uniqUrl=new HashSet<>();
		for (String regio : regions) {
			String regionUrl=U.getSectionValue(regio, "href=\"", "\"");
			U.log("https://www.drhorton.com"+regionUrl);
			String regUrl="https://www.drhorton.com"+regionUrl;
			if(regionUrl.contains("arkansas"))continue;
			String redirectedUrl="";
			if(regionUrlMap.containsKey(regionUrl)) {
				redirectedUrl="https://www.drhorton.com"+regionUrlMap.get(regionUrl);
			}else {
			//	U.log("https://www.drhorton.com"+regionUrl);
				
				if(regionUrl.contains("kentucky")) {
					redirectedUrl="https://www.drhorton.com/kentucky";
				}
				else {
					U.log(">>>>>>>>>>");
			
				redirectedUrl=U.getRedirectedURL("https://www.drhorton.com", "https://www.drhorton.com"+regionUrl);
				
				U.log(redirectedUrl);
				
				}
			}
			//U.log((regCount++)+" --> "+redirectedUrl);
			String state = regionUrl.replace("/", "");
			state =state.substring(0, 1).toUpperCase() + state.substring(1);
			if(state.contains("-")) {
				String stateval[] = state.split("-");
				state = stateval[0]+"-"+stateval[1].substring(0,1).toUpperCase()+stateval[1].substring(1);
			}
			

			String regHtml=U.getHTML(redirectedUrl);
//			String dataUri=U.getSectionValue(regHtml, "data-sc-item-uri='", "'");
			String dataUri=U.getSectionValue(regHtml, "data-sc-item-uri=\"", "\"");
			if(dataUri==null)dataUri = U.getSectionValue(regHtml, "data-sc-item-uri='", "'");
			String lat=U.getSectionValue(regHtml, "data-latitude=\"", "\"");
			String lon=U.getSectionValue(regHtml, "data-longitude=\"", "\"");
		//	String postURlReg="https://www.drhorton.com/coveo/rest/v2?sitecoreItemUri="+URLEncoder.encode(dataUri, StandardCharsets.UTF_8.toString())+"&siteName=website&authentication";
//			String payload="actionsHistory=%5B%5D&referrer="+redirectedUrl+"&visitorId=ae87296d-28dc-4eaa-b92a-a28eb6c9c82a&isGuestUser=false&aq=(%24qf(function%3A'dist(%40fcoordinatesz32xlatitude51359%2C%20%40fcoordinatesz32xlongitude51359%2C%20"+lat+"%2C%20"+lon+")'%2C%20fieldName%3A%20'distance'))%20(%40distance%3C352891.0153256759)&cq=(%40fcoordinatesz32xlatitude51359)%20(%40fz95xlanguage51359%3D%3Den)%20(%40fz95xlatestversion51359%3D%3D1)&queryFunctions=%5B%5D&numberOfResults=5000&fieldsToInclude=%5B%22%40fcommunitythumbnail51359%22%2C%22%40furllink51359%22%2C%22%40factivationstate51359%22%2C%22%40fbrandlogo51359%22%2C%22%40fmarketingname51359%22%2C%22%40fpricemin51359%22%2C%22%40fcallforprice51359%22%2C%22%40fsqftmin51359%22%2C%22%40fsqftmaz120x51359%22%2C%22%40fismultigen51359%22%2C%22%40famenitylistfordisplay51359%22%2C%22%40fid51359%22%2C%22%40sysuri%22%2C%22%40fcoordinatesz32xlatitude51359%22%2C%22%40fcoordinatesz32xlongitude51359%22%2C%22%40fcity51359%22%2C%22%40fstate51359%22%2C%22%40fz122xip51359%22%2C%22%40source%22%2C%22%40collection%22%2C%22%40urihash%22%5D&pipeline=allresults&searchHub=&term=";
		//	String payload = "actionsHistory=%5B%5D&referrer=&visitorId=7940a4f1-3072-4b59-86b0-307daeb35064&isGuestUser=false&aq=(%24qf(function%3A'dist(%40fcoordinatesz32xlatitude10354%2C%20%40fcoordinatesz32xlongitude10354%2C%20"+lat+"%2C%20"+lon+")'%2C%20fieldName%3A%20'distance'))%20(%40distance%3C361900.8490411431)&cq=(%40fcoordinatesz32xlatitude10354)%20(%40fz95xlanguage10354%3D%3Den)%20(%40fz95xlatestversion10354%3D%3D1)&queryFunctions=%5B%5D&numberOfResults=5000&fieldsToInclude=%5B%22%40fcommunitythumbnail10354%22%2C%22%40furllink10354%22%2C%22%40factivationstate10354%22%2C%22%40fbrandlogo10354%22%2C%22%40fmarketingname10354%22%2C%22%40fpricemin10354%22%2C%22%40fcallforprice10354%22%2C%22%40fsqftmin10354%22%2C%22%40fsqftmaz120x10354%22%2C%22%40fismultigen10354%22%2C%22%40famenitylistfordisplay10354%22%2C%22%40fid10354%22%2C%22%40sysuri%22%2C%22%40fcoordinatesz32xlatitude10354%22%2C%22%40fcoordinatesz32xlongitude10354%22%2C%22%40fcity10354%22%2C%22%40fstate10354%22%2C%22%40fz122xip10354%22%2C%22%40fpropertytype10354%22%2C%22%40fbrand10354%22%2C%22%40famenitylist10354%22%2C%22%40fnumberofbathroomsmin10354%22%2C%22%40fnumberofbedroomsmin10354%22%2C%22%40fnumberofgaragesmin10354%22%2C%22%40fnumberofstoriesmin10354%22%2C%22%40source%22%2C%22%40collection%22%2C%22%40urihash%22%5D&pipeline=allresults&searchHub="+state+"&term=";	
//			U.log(payload);
//			U.log(lat+"::"+lon);
			U.log("state: "+state+" >"+dataUri);
			//String postURlReg="https://www.drhorton.com/coveo/rest/v2?sitecoreItemUri="+URLEncoder.encode(dataUri, StandardCharsets.UTF_8.toString())+"&siteName=website";
		//	String payload = "actionsHistory=%5B%5D&referrer=&visitorId=7940a4f1-3072-4b59-86b0-307daeb35064&isGuestUser=false&aq=(%24qf(function%3A'dist(%40fcoordinatesz32xlatitude10354%2C%20%40fcoordinatesz32xlongitude10354%2C%20"+lat+"%2C%20"+lon+")'%2C%20fieldName%3A%20'distance'))%20(%40distance%3C361900.8490411431)&cq=(%40fcoordinatesz32xlatitude10354)%20(%40fz95xlanguage10354%3D%3Den)%20(%40fz95xlatestversion10354%3D%3D1)&queryFunctions=%5B%5D&numberOfResults=5000&fieldsToInclude=%5B%22%40fcommunitythumbnail10354%22%2C%22%40furllink10354%22%2C%22%40factivationstate10354%22%2C%22%40fbrandlogo10354%22%2C%22%40fmarketingname10354%22%2C%22%40fpricemin10354%22%2C%22%40fcallforprice10354%22%2C%22%40fsqftmin10354%22%2C%22%40fsqftmaz120x10354%22%2C%22%40fismultigen10354%22%2C%22%40famenitylistfordisplay10354%22%2C%22%40fid10354%22%2C%22%40sysuri%22%2C%22%40fcoordinatesz32xlatitude10354%22%2C%22%40fcoordinatesz32xlongitude10354%22%2C%22%40fcity10354%22%2C%22%40fstate10354%22%2C%22%40fz122xip10354%22%2C%22%40fpropertytype10354%22%2C%22%40fbrand10354%22%2C%22%40famenitylist10354%22%2C%22%40fnumberofbathroomsmin10354%22%2C%22%40fnumberofbedroomsmin10354%22%2C%22%40fnumberofgaragesmin10354%22%2C%22%40fnumberofstoriesmin10354%22%2C%22%40source%22%2C%22%40collection%22%2C%22%40urihash%22%5D&pipeline=allresults&searchHub="+state+"&term=";	
			String	postURlReg="https://www.drhorton.com/coveo/rest/v2?sitecoreItemUri="+URLEncoder.encode(dataUri, StandardCharsets.UTF_8.toString())+"&siteName=website";
			String payload = "actionsHistory=%5B%5D&referrer=&visitorId=620c3530-937a-4d24-9430-bf56052b0eb0&isGuestUser=false&aq=(%40fz95xtemplatename18184%3D%3D%22Community%20Landing%22)%20(%24qf(function%3A'dist(%40fcoordinatesz32xlatitude18184%2C%20%40fcoordinatesz32xlongitude18184%2C%20"+lat+"%2C%20"+lon+")'%2C%20fieldName%3A%20'distance'))%20(%40distance%3C377252.7243962764)&cq=(%40fcoordinatesz32xlatitude18184)%20(%40fz95xlanguage18184%3D%3Den)%20(%40fz95xlatestversion18184%3D%3D1)&queryFunctions=%5B%5D&numberOfResults=5000&fieldsToInclude=%5B%22%40fcommunitythumbnail18184%22%2C%22%40furllink18184%22%2C%22%40factivationstate18184%22%2C%22%40fbrandlogo18184%22%2C%22%40fmarketingname18184%22%2C%22%40fpricemin18184%22%2C%22%40fcallforprice18184%22%2C%22%40fsqftmin18184%22%2C%22%40fsqftmaz120x18184%22%2C%22%40fismultigen18184%22%2C%22%40famenitylistfordisplay18184%22%2C%22%40fid18184%22%2C%22%40sysuri%22%2C%22%40fcoordinatesz32xlatitude18184%22%2C%22%40fcoordinatesz32xlongitude18184%22%2C%22%40fcity18184%22%2C%22%40fstate18184%22%2C%22%40fz122xip18184%22%2C%22%40fpropertytype18184%22%2C%22%40fbrand18184%22%2C%22%40famenitylist18184%22%2C%22%40fnumberofbathroomsmin18184%22%2C%22%40fnumberofbedroomsmin18184%22%2C%22%40fnumberofgaragesmin18184%22%2C%22%40fnumberofstoriesmin18184%22%2C%22%40source%22%2C%22%40collection%22%2C%22%40urihash%22%5D&pipeline=allresults&searchHub="+state+"&term=";
		  //  U.log(payload);
			String postHtml=sendPostRequestAcceptJson(postURlReg, payload); 
//			if(state.contains("Hawaii")) {
//				 postURlReg="https://www.drhorton.com/coveo/rest/v2?sitecoreItemUri="+URLEncoder.encode(dataUri, StandardCharsets.UTF_8.toString())+"&siteName=website";
//				 payload = "actionsHistory=%5B%5D&referrer=&visitorId=620c3530-937a-4d24-9430-bf56052b0eb0&isGuestUser=false&aq=(%40fz95xtemplatename18184%3D%3D%22Community%20Landing%22)%20(%24qf(function%3A'dist(%40fcoordinatesz32xlatitude18184%2C%20%40fcoordinatesz32xlongitude18184%2C%2022.5%2C%20-157.5)'%2C%20fieldName%3A%20'distance'))%20(%40distance%3C377252.7243962764)&cq=(%40fcoordinatesz32xlatitude18184)%20(%40fz95xlanguage18184%3D%3Den)%20(%40fz95xlatestversion18184%3D%3D1)&queryFunctions=%5B%5D&numberOfResults=5000&fieldsToInclude=%5B%22%40fcommunitythumbnail18184%22%2C%22%40furllink18184%22%2C%22%40factivationstate18184%22%2C%22%40fbrandlogo18184%22%2C%22%40fmarketingname18184%22%2C%22%40fpricemin18184%22%2C%22%40fcallforprice18184%22%2C%22%40fsqftmin18184%22%2C%22%40fsqftmaz120x18184%22%2C%22%40fismultigen18184%22%2C%22%40famenitylistfordisplay18184%22%2C%22%40fid18184%22%2C%22%40sysuri%22%2C%22%40fcoordinatesz32xlatitude18184%22%2C%22%40fcoordinatesz32xlongitude18184%22%2C%22%40fcity18184%22%2C%22%40fstate18184%22%2C%22%40fz122xip18184%22%2C%22%40fpropertytype18184%22%2C%22%40fbrand18184%22%2C%22%40famenitylist18184%22%2C%22%40fnumberofbathroomsmin18184%22%2C%22%40fnumberofbedroomsmin18184%22%2C%22%40fnumberofgaragesmin18184%22%2C%22%40fnumberofstoriesmin18184%22%2C%22%40source%22%2C%22%40collection%22%2C%22%40urihash%22%5D&pipeline=allresults&searchHub="+state+"&term=";
//				 postHtml=sendPostRequestAcceptJson(postURlReg, payload);
//				//String commSecs[]=U.getValues(postHtml, "{\"title\":", "\"attachments\":");
//				//U.log("Community count::::"+commSecs.length);
//				break;
//			}
			//U.log(postHtml);
			String commSecs[]=U.getValues(postHtml, "{\"title\":", "\"attachments\":");
			//U.log("Community count::::"+commSecs.length);
			LOGGER.AddSubRegion(redirectedUrl, commSecs.length);
			for (String comSecs : commSecs) {
				String comUrl=U.getSectionValue(comSecs, "\"furllink18184\":\"", "\"");//U.getSectionValue(comSecs, "\"furllink10354\":\"", "\"");//;
				//U.log(comUrl);
				if(uniqUrl.add(comUrl)) {
					if (!comUrl.startsWith("https://")) {
						comUrl="https://www.drhorton.com"+comUrl;
//						U.log(">>>>>>>"+comUrl);
					}
					
						addDetails(comUrl,comSecs);////////
					
//						if(gotCommunity)return;
//					break;
				}else {
					if(data.communityUrlExists(comUrl)){
						LOGGER.AddCommunityUrl(comUrl+"::::::::Repeated:::::::::::");
					
					}
					dup++;
				}
			}
//			break;
		}
//		U.log("TotalComm: "+urls.size());
//		U.log("Duplicates: "+dup);
		
		LOGGER.DisposeLogger();
		
		long stopTime = System.nanoTime();
		System.out.println(stopTime - startTime);
	}
//	@Override
//	protected void innerProcess() throws Exception {
////		getCountUsingDriver();
//		long startTime = System.nanoTime();
//		String mainHtml=U.getHTML("https://www.drhorton.com/");
//		String mainSec=U.getSectionValue(mainHtml, "<g id=\"g5\">", "</g>");
//		String regions[]=U.getValues(mainSec, "<a ", "</a>");
//		U.log(regions.length);
//		int regCount=0;
//		uniqUrl=new HashSet<>();
//		for (String regio : regions) {
//			String regionUrl=U.getSectionValue(regio, "href=\"", "\"");
//			U.log("https://www.drhorton.com"+regionUrl);
//			String redirectedUrl=U.getRedirectedURL("https://www.drhorton.com", "https://www.drhorton.com"+regionUrl);
//			U.log((regCount++)+" --> "+redirectedUrl);
//			
//			String regHtml=U.getHTML(redirectedUrl);
//			String dataUri=U.getSectionValue(regHtml, "data-sc-item-uri='", "'");
//			String lat=U.getSectionValue(regHtml, "data-latitude=\"", "\"");
//			String lon=U.getSectionValue(regHtml, "data-longitude=\"", "\"");
//			String postURlReg="https://www.drhorton.com/coveo/rest/v2?sitecoreItemUri="+URLEncoder.encode(dataUri, StandardCharsets.UTF_8.toString())+"&siteName=website&authentication";
//			String payload="actionsHistory=%5B%5D&referrer="+redirectedUrl+"&visitorId=ae87296d-28dc-4eaa-b92a-a28eb6c9c82a&isGuestUser=false&aq=(%24qf(function%3A'dist(%40fcoordinatesz32xlatitude51359%2C%20%40fcoordinatesz32xlongitude51359%2C%20"+lat+"%2C%20"+lon+")'%2C%20fieldName%3A%20'distance'))%20(%40distance%3C352891.0153256759)&cq=(%40fcoordinatesz32xlatitude51359)%20(%40fz95xlanguage51359%3D%3Den)%20(%40fz95xlatestversion51359%3D%3D1)&queryFunctions=%5B%5D&numberOfResults=5000&fieldsToInclude=%5B%22%40fcommunitythumbnail51359%22%2C%22%40furllink51359%22%2C%22%40factivationstate51359%22%2C%22%40fbrandlogo51359%22%2C%22%40fmarketingname51359%22%2C%22%40fpricemin51359%22%2C%22%40fcallforprice51359%22%2C%22%40fsqftmin51359%22%2C%22%40fsqftmaz120x51359%22%2C%22%40fismultigen51359%22%2C%22%40famenitylistfordisplay51359%22%2C%22%40fid51359%22%2C%22%40sysuri%22%2C%22%40fcoordinatesz32xlatitude51359%22%2C%22%40fcoordinatesz32xlongitude51359%22%2C%22%40fcity51359%22%2C%22%40fstate51359%22%2C%22%40fz122xip51359%22%2C%22%40source%22%2C%22%40collection%22%2C%22%40urihash%22%5D&pipeline=allresults";
//			String postHtml=sendPostRequestAcceptJson(postURlReg, payload);
//			String commSecs[]=U.getValues(postHtml, "{\"title\":", "\"attachments\":");
//			LOGGER.AddSubRegion(redirectedUrl, commSecs.length);
//			for (String comSecs : commSecs) {
//				String comURl=U.getSectionValue(comSecs, "\"furllink51359\":\"", "\"");
//				if(uniqUrl.add(comURl)) {
//					if (!comURl.startsWith("https://")) {
//						comURl="https://www.drhorton.com"+comURl;
//					}
//					
//					//	addDetails(comURl,comSecs);
//					
////						if(gotCommunity)return;
////					break;
//				}else {
//					if(data.communityUrlExists(comURl)){
//						LOGGER.AddCommunityUrl(comURl+"::::::::Repeated:::::::::::");
//					
//					}
//					dup++;
//				}
//			}
////			break;
//		}
////		U.log("TotalComm: "+urls.size());
////		U.log("Duplicates: "+dup);
//		
//		LOGGER.DisposeLogger();
//		
//		long stopTime = System.nanoTime();
//		System.out.println(stopTime - startTime);
//	}

	int count=0;
	private void addDetails(String comUrl, String comSecs) throws Exception {
		//TODO :
	//	try{ 
//			 if(count>230 && count<=500)//
//				 if(count>990 && count<=1000)//d

//			if (count > 1120)//1600 d
//				if (count > 1500)
//					if (count > 1490)
//					
			
		{
		
			//======================================== SINGLE RUN ======================================================================================================
			//TODO :
//			if (!comUrl.equals("https://www.drhorton.com/alabama/mobile/mobile/burlington-estates")) return;
		
			//comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/medford/hawthorne-estates")||
		//|| comUrl.contains("https://www.drhorton.com/north-carolina/greensboro-winston-salem/whitsett/brightwood-farm")
		if(comUrl.contains("https://www.drhorton.com/arizona/phoenix/maricopa/homestead-n-pcls-10-11") 
				|| comUrl.contains("https://www.drhorton.com/california/sacramento/roseville/express-manchester") 
				|| comUrl.contains("https://www.drhorton.com/washington/south-sound/puyallup/rainier-ridge-liberty") 
				|| comUrl.contains("https://www.drhorton.com/illinois/chicago/arlington-heights/arlington-heights-homes") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/raleigh---durham/new-bern/bayberry-park-at-carolina-colours") 
				|| comUrl.contains("https://www.drhorton.com/washington/greater-seattle/lynnwood/westlake-townhomes") 
				|| comUrl.contains("https://www.drhorton.com/oregon/portland/portland/north-bethany-commons") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/greensboro-winston-salem/greensboro/ashcroft-park") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/raleigh---durham/wendell/express-edgemont-landing") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/raleigh---durham/garner/creekside") 
				|| comUrl.contains("https://www.drhorton.com/washington/north-sound/lake-stevens/brookwood") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/raleigh---durham/rocky-mount/carriage-pond") 
				|| comUrl.contains("https://www.drhorton.com/south-carolina/charleston/mount-pleasant/center-park-north-at-park-west") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/greensboro-winston-salem/greensboro/finley-ridge")
				|| comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/marlton/berkshire-woods") 
				||comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/medford/carriages-at-hawthorne-estates") 
//				|| comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/burlington/capital-crossing") 
				|| comUrl.contains("https://www.drhorton.com/north-carolina/charlotte/mount-holly/emerald-stonewater") 
				|| comUrl.contains("https://www.drhorton.com/louisiana/lake-charles-lafayette/rayne/country-lakes")
				|| comUrl.contains("https://www.drhorton.com/georgia/atlanta/mcdonough/greystone-manor-at-farris-park") //19-Aug-20
				|| comUrl.contains("https://www.drhorton.com/south-carolina/greenville/greer/hartwood-lake") //19-Aug-20
//				|| comUrl.contains("https://www.drhorton.com/texas/dallas/aubrey/winn-ridge") //19-Aug-20
				|| comUrl.contains("https://www.drhorton.com/north-carolina/charlotte/charlotte/highland-knoll")// 13-Oct-20
			|| comUrl.contains("https://www.drhorton.com/washington/south-sound/lacey/gateway-ii-express")// 12-jan-21
			|| comUrl.contains("https://www.drhorton.com/louisiana/lake-charles-lafayette/lafayette/bayou-tortue-manor")
			|| comUrl.contains("https://www.drhorton.com/florida/west-central-florida/ocala/huntington-ridge"))
		{
			
			LOGGER.AddCommunityUrl(comUrl+"::::::::Redirected:::::::::::");
			return;//redirect to region page
		}

//		if(comUrl.contains("https://www.drhorton.com/florida/central-florida/haines-city/charles-cove-express")||comUrl.contains("https://www.drhorton.com/florida/southeast-florida/florida-city/keys-pointe")||comUrl.contains("https://www.drhorton.com/florida/central-florida/new-smyrna-beach/glenbrooke")){
//			LOGGER.AddCommunityUrl(comUrl+"::::::::Redirected:::::::::::");
//			return;//redirect to region page
//		}
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"::::::::Repeated:::::::::::");
			return;
		}
		
	
		if (comUrl.contains("greenville/duncan/myers-park") || comUrl.contains("florida/pensacola/pace/ashley-plantation")) {
			LOGGER.AddCommunityUrl(comUrl+"::::::::Returned:::::::::::"); 
			return;
		}
		
		if (comUrl.contains("https://www.drhorton.com/oregon/portland/happy-valley/the-trails-at-rock-creek-townhomes") || comUrl.contains("https://www.drhorton.com/oregon/portland/happy-valley/the-trails-at-rock-creek") 
			||comUrl.contains("https://www.drhorton.com/florida/tampa/spring-hill/bayport-place") || comUrl.contains("https://www.drhorton.com/oregon/portland/beaverton/westmont") || 
				comUrl.contains("https://www.drhorton.com/mississippi/gulf-coast/biloxi/belle-creek")) {
			LOGGER.AddCommunityUrl(comUrl+"::::::::Returned to Region:::::::::::"); 
			return;
		}
//		gotCommunity = true;
		
		U.log("-------------------------------");
		U.log(count+": comUrl: "+comUrl);
//		String fileName=U.getCache(comUrl);
//		U.deleteFile(fileName);
		String commHtml=U.getHTML(comUrl);
		String[] sqftSecArr=U.getValues(commHtml,"<div class=\"home-sqft\">","</div>");
		String sqftSec=ALLOW_BLANK;
		for(String sec:sqftSecArr) {
			sqftSec+=" "+sec;
		}
	//	U.log(U.getCache(comUrl));
		if (commHtml.contains("<title>Find Homes for sale in")||commHtml.contains("<strong></strong> results for <strong></strong>")||commHtml.contains("<title>Document Moved</title>")) {
			LOGGER.AddCommunityUrl(comUrl+"::::::::Redirected:::::::::::");
			return;//redirect to region page
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		
		//============== NearBy Communities ================
		String nearBy = U.getSectionValue(commHtml, "Nearby Communities", "</section>");
		if(nearBy!=null)
			commHtml = commHtml.replace(nearBy, "");
		
	//	U.log("comSec"+comSecs);
		String geo="FALSE";
		String note=ALLOW_BLANK;
		String commId=U.getSectionValue(commHtml, "data-communityid=\"", "\"");
		U.log("COMM iD"+commId);
		
		//--------------------------------------------------------------------COMMUNITY Name---------------------------------------------------------------
		String commName=U.getSectionValue(commHtml, "data-community-name=\"", "\"");
		commName=commName.replaceAll("Wellington Farms Seagoville|Wellington Farms Dallas", "Wellington Farms").replace("Bridges on Lake Houston LAKE FRONT LIVING", "Bridges on Lake Houston").replace("Stonewater Single Family Ranch", "Stonewater")
				.replace("South Gulf Cove Homes", "South Gulf Cove")
				.replace("The Ponds – Village Collection", "The Ponds - Village Collection")
				.replaceAll(" PH II", "");
		U.log("==="+commName);
		if(commName==null || commName.length()<2) {
			commName = U.getSectionValue(commHtml, "<li><a href=\""+comUrl.replace("https://www.drhorton.com", "")+"\">", "<");
		}
		if(commName != null) commName = commName.replace("@", "At").replaceAll("Single Family Homes|Townhomes|Twinhomes|\\| Alley Homes|\\|", "").trim();
		commName = commName.replaceAll("^&#160;|&#160;$| - Waxahachie| - Farmersville| - Townhomes$| - Cottages| - D\\.R\\. Horton$| D\\.R\\. Horton$|Ranch Townhomes and Duplexes|Ranch Homes|- SF| - FS", "");
		
		if(commName != null) commName = commName.replace("|", "").replace("| Milpitas, California | D.R. Horton", "");
		
		commName=commName.replace("Milpitas, California  D.R. Horton", "").replace("Paired Patio Homes", "")
				.replaceAll("by$|- Algonquin$|- DR Horton|Neo-Traditional$|55\\+$|New Homes in|Lifestyle Detached| Phase \\d|- Patio Homes|Patio Homes|Horton$|of St\\. John", "");
		if(commName.endsWith(":"))commName = commName.replace(":", "");
//		U.log("--->"+commName);
		if(commName == null||commName.length()==0) commName =U.getSectionValue(comSecs, "\"fmarketingname51359\":\"", "\"");
		
		commName = commName.replace("Pioneer Point - Eagle Mt. Saginaw ISD", "Pioneer Point").replace("Horizon Uptown Paired","Horizon Uptown").replace("Inspiraci&#243;n", "Inspiracion").replace("‘Iliahi at Ho&#39;opili", "Iliahi at Hoopili")
				.replace("Camino &#225; Lago", "Camino A Lago").replaceAll("by$|MODERN|Modern", "").replace(" - Grand Prairie / Midlothian ISD", "")
				.replace("Monta&#241;a", "Montana");
		//--------------------------------------------------------------------FLOOR PLANS DATA--------------------------------------------------------------
		String floorPostUrl="https://www.drhorton.com/api/drh/floorplandetailapi/getrelated";
		String floorPostData="ItemId=%7B"+commId+"%7D&StartIndex=0&Count=8";
		U.log("floorPostData==="+floorPostData);
		String availPostData=floorPostData;
		String floorSec=U.getSectionValue(commHtml, "<div id=\"floorplans\" class=\"", "<h2 class=\"medium-component-header\">Floor Plans");
		String allFloorHomesData="";
		if (floorSec!=null) {
			String totalFloorPlans=U.getSectionValue(floorSec, "data-totalitems=\"", "\"");
			int currentCount=4;
			String floorPostHtml=sendPostRequestAcceptJson(floorPostUrl, floorPostData);
		//	U.log(floorPostHtml);
			if (Integer.parseInt(totalFloorPlans)>currentCount) {
				while (currentCount<=Integer.parseInt(totalFloorPlans)) {
					floorPostData="ItemId=%7B"+commId+"%7D&StartIndex="+currentCount+"&Count=8";
					currentCount=(currentCount+8);
					floorPostHtml+=sendPostRequestAcceptJson(floorPostUrl, floorPostData);
				}
			}
			String floorSecs[]=U.getValues(floorPostHtml, "<div class=\\\"home-info\\\">", "data-compare-id=");//"Compare</button>");
			if (floorSecs!=null) {
				List<String > uniqfloorSecs=Arrays.asList(floorSecs).stream().distinct().collect(Collectors.toList());
				for (String floorHome : uniqfloorSecs) {
					String floorHomeUrl="https://www.drhorton.com"+U.getSectionValue(floorHome, "href=\\\"", "\\\"");
					U.log("Floor Home Data: "+floorHomeUrl);
					String floorHtml=U.getHTML(floorHomeUrl);
					allFloorHomesData+=U.getSectionValue(floorHome, "data-communitytype=\\\"Floor Plan Detail\\\"", " data-compare-type="); //"ul class=\\\"specs\\\">");
					allFloorHomesData+=U.getSectionValue(floorHtml, "<p class=\"home-name\">", ">Directions</a>")+U.getSectionValue(floorHtml, "<div class=\"community-details\">", "</section>");
				}
//				allFloorHomesData=floorPostHtml;//
				U.log("FloorPlansCount: "+totalFloorPlans+" :: "+uniqfloorSecs.size());
			}
			
		}
		//--------------------------------------------------------------------AVAILABLE HOME DATA--------------------------------------------------------------
		String allAvailHomesData="";
		
		String availHomeSec=U.getSectionValue(commHtml, "<div id=\"relatedmovein\"", "<h2 class=\"medium-component-header\">Available Homes");
		String areaInfo=U.getSectionValue(commHtml, "<h2>Area Information</h2>", "</section>");
		String mainData=U.getSectionValue(commHtml, "<div class=\"bottom-bar\">", ">Directions</a>")+U.getSectionValue(commHtml, "<div class=\"property-carousel\">", "<div class=\"carousel-nav\">")+U.getSectionValue(commHtml, "<div class=\"community-details\">", "</section>");
		if (availHomeSec!=null) {
			String totalPlans=U.getSectionValue(availHomeSec, "data-totalitems=\"", "\"");
			String moveInReadyPostUrl="https://www.drhorton.com/api/drh/moveinreadyapi/getrelated";
			String availPostHtml=sendPostRequestAcceptJson(moveInReadyPostUrl, availPostData);
	
			int currentCount=4;
			if (Integer.parseInt(totalPlans)>currentCount) {
				while (currentCount<=Integer.parseInt(totalPlans)) {
					availPostData="ItemId=%7B"+commId+"%7D&StartIndex="+currentCount+"&Count=8";
					currentCount=(currentCount+8);
					availPostHtml+=sendPostRequestAcceptJson(moveInReadyPostUrl, availPostData);
				}
			}
			
			String availSecs[]=U.getValues(availPostHtml, "<div class=\\\"home-info\\\">", "<div class=\\\"home-actions"); //\\\">
			
			if (availSecs!=null) {
				List<String > uniqAvailSec=Arrays.asList(availSecs).stream().distinct().collect(Collectors.toList());
				
				int contractHome = 0;
				int sold = 0;
				U.log("MoveInPlansCount: "+totalPlans+" :: "+uniqAvailSec.size());

				for (String availHome : uniqAvailSec) {
					
					if(availHome.contains("Under Contract"))
						contractHome++;
					else if(availHome.contains("\\tSold\\r")) sold++;
//					U.log(availHome);
					allAvailHomesData+=availHome;
					String availHomeUrl="https://www.drhorton.com"+U.getSectionValue(availHome, "href=\\\"", "\\\"");
				//	U.log("Avail Home URl: "+availHomeUrl);
					String availHtml=U.getHTML(availHomeUrl);//Text Inside is similar to community text description
					if (availHtml!=null) {
						allAvailHomesData+=U.getSectionValue(availHtml, "<div class=\"bottom-bar\">", ">Directions</a>");
						allAvailHomesData+=U.getSectionValue(availHtml, "<div class=\"community-details\">", "</div>");
					}
				}
				U.log("sold home :"+sold);
				U.log("contractHome :"+contractHome);
				U.log("uniqAvailSec :"+uniqAvailSec.size());
				if (uniqAvailSec.size()>0 && contractHome+sold<uniqAvailSec.size() ||contractHome+sold>uniqAvailSec.size())
					if(sold != uniqAvailSec.size())
						mainData+="  Status Quick-Move In Homes"; //Considering Available Homes as Move-In ready Homes
			}
			
			
		}
		
		
		
//		String floorSec=U.getSectionValue(commHtml, "<h2 class=\"medium-component-header\">Floor Plans <span class=\"count\">", "<div id=\"nearbycommunities\" class=\"nearby-communities\"");
		comSecs=correctData(comSecs);
		//-------------------------------------------------------------------------Note-------------------------------------------------------------------------------
//		String wrongNote = "39C104\",\"factivationstate51359\":\"Now Pre-Selling\",\"fcity51359\":\"Ha";
		String wrongNote = ",\"factivationstate51359\":\"Now Pre-Selling\",\"fcity51359\":";
		//U.log("comSecs :::"+allFloorHomesData);

		note=U.getnote((mainData+comSecs.replaceAll(wrongNote, "").replaceAll("factivationstate\\d+\":\"Now Pre-Selling\"", "")+areaInfo).replaceAll("pre-sales by appointment only|alt=\"Open For Sales\">|open for sales! Conveniently|-PreSelling-|Now_Pre-selling", ""));
		//----------------------------------------------------------------------Latitude & Longitude---------------------------------------------------------------
		String lat=U.getSectionValue(commHtml, "data-latitude=\"", "\"");
		String lon=U.getSectionValue(commHtml, "data-longitude=\"", "\"");
		String Latlon[]= {lat,lon};
		U.log("LatLon --> "+Arrays.toString(Latlon));
		//----------------------------------------------------------------------------Address----------------------------------------------------------------------
		String addSec=U.getSectionValue(commHtml, "data-community-address=\"", "\"");
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addStausSec = addSec;
		addSec  =addSec.replace("601 Apollo Lane 535 Walker Drive", "601 Apollo Lane").replace("26927 Spyglass Drive Canal Road &amp; Griffith Marina Road", "26927 Spyglass Drive").replace("CA 93638, Fresno, CA 93722", "CA 93638").replace("Cragstone Rd at Rockland Rd, Stonecrest, GA 30058, Lithonia, GA 30038", "Cragstone Rd, Lithonia, GA 30038").replace("sales office: pine forest -", "")
				.replace(" Glenncrest Lanenw", " Glenncrest Lane NW").replace("Shannon Green Dr 5552 Bamberg Drive", "5552 Bamberg Drive").replace(". PSL FL 34984&#160; OR 2844 SW Savona Blvd., Port St. Lucie, FL 34953", ", Port St. Lucie, FL 34984").replace("6001 Royal Port Court Saufley Field Road", "6001 Royal Port Court")
				.replaceAll("MODEL COMING SUMMER 2021|Now Taking Appointments|COMING WINTER 2021|Coming Late Summer 2021|Coming Winter 2021|COMING SUMMER 2021|Coming Summer 2022|Coming 2022|Coming Winter 2021|Coming Summer 2021|COMING FALL 2021|Coming Spring 2022|OPENING IN FALL 2021|Coming Early 2022|Please Visit River&#39;s Bend at Pecan Park Sales Office|Big Poplar|Visit Cantarra Meadow Sales Office| Visit D.R. Horton Model|Model Coming Summer 2021|Homes Throughout Poinciana &amp; Kissimmee|Models Coming February 2021| GPS use Bettis Academy Rd &amp; Flat Rock Ln|GPS use Bettis Academy Rd &amp; Weldon Way|Model Coming January 2021!|Model Coming this January!|Closing Out|Model Coming Summer 2021|Coming Fall 2021|Now Preselling from Anna Town Square|Call for information|Model Coming Winter 2020|Temporarily Closed Due To Hurricane Laura|Coming Fall 2020!|New Phase|Phase 2 Coming Fall/Winter 2020|MODEL LOCATED AT SHANNON FARMS |Express Homes Coming Soon|Currently selling from Information Center|TBD|GPS use Evans Mill Rd &amp; Browns Mill Rd \\| |GPS use:|Model Coming Fall 2020|Town Homes|Coming Summer 2020| Off of Boat Race Road| \\(GPS use 1135 Sigman Rd NE\\) |GPS use 1137 Sigman Road| \\(gps Use 1135 Sigman Rd Ne\\)| \\(gps Use 1135 Sigman Rd Ne\\)|Pineland|Model Coming Summer 2020|Model Coming February 2020|Model Coming May 2020|Model Coming August 2020!|Selling from (Camden Parc,|Winchester Crossing,)|- Phase 2|Now Pre-Selling!|By Appointment( Only)?|Model(ing)? Coming Early Spring 2020!| Off Fort Morgan Road|GPS use Powderhouse Road at Kirkwood Drive|New Model", "");
		U.log(addSec);
		if (addSec!=null) {
			add=U.getAddress(addSec);
		}
				
/*		if(comUrl.contains("https://www.drhorton.com/texas/san-antonio/san-antonio/langdon")) {
			add[1]="San Antonio";
			add[2]="TX";
			add[3]="78261";
			String ll[]= U.getlatlongGoogleApi(add);
			add[0]= U.getAddressGoogleApi(ll)[0];
			geo="True";
		}*/
		
		//------------Format street address------------------------
		add[0] = U.getCapitalise(add[0].toLowerCase());
		if(add[1].length()<3)add[1]="-";
		if(add[0].equals(U.getCapitalise(add[1].toLowerCase())))
		add[0] = add[0].replace(U.getCapitalise(add[1].toLowerCase()), "-");
		add[0]=add[0].replace("10232 Greenwood, Victoria Lakes Ct", "10232 Greenwood Victoria Lakes Ct")
				.replace("2890 South Mill Road Heber", "2890 South Mill Road")
				.replace("| Hickory Tree Road", "Hickory Tree Road")
				.replace("4311 Newland Street | Gps Use 2574 Tobacco Road", "4311 Newland Street")
				.replace("167 Heritage Brook Drive Nw, Madison, Al 35757", "167 Heritage Brook Drive Nw");
		
		if(add[0].contains("Coming Soon")||add[0].contains("Coming Winter 2023")||add[0].contains("Coming Summer 2023"))add[0]=ALLOW_BLANK;
		if(comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/medford/autumn-park")) add[0]="22 Evesboro Rd";
		U.log("Street Address ::::::::::>" + add[0]+"<:::::::::::");
		add[0] = add[0].replace("| Airport Road", "Airport Road").replaceAll("^&#160;|&#160;$", "")
				.replace("| N Clyde Morris Blvd", "N Clyde Morris Blvd")
				.replace("&#160;", " ")
				.replace("&#39;", "'")
				.replace("| Mccormick Road","Mccormick Road")
				.replace("| E Palmetto Ave", "E Palmetto Ave")
				.replace("Coming Fall 2022 | West Ponkan Road","West Ponkan Road")
				.replaceAll(",$", "").replace("&amp;", "&").replace("Celina, Tx 75009", "")
				.replaceAll(" Selling From Our Palm Bay Sales Office|Sales Center Coming Soon!|Opening January 2021! Starting Mid \\$300s|Model Located At Misty Meadows|Model Coming Winter 2020|Model(s)? Coming Early 2021!?|Coming Early 2021|One-level Villas|Now Preselling From Winchester Crossing|Call For Information|Hickory Creek|Now Selling From Lakewood Trails|Now Selling From Anna Town Square|Gps Use 2026 Post Grove Rd I|\\.$", "")
				.replaceAll("Starting Mid \\$\\d{3}s", "");
		//------to remove GPS Address----------
		add[0] = add[0].replaceAll("\\s*\\(*[g|G]*ps\\s*([A|a]*ddress)*\\:.*?\\)*\\s*$", "");
		//---remove bracket address-----
		add[0] = add[0].replaceAll("\\s*\\(+.*?\\)+\\s*$", "");

		//-----remove numbers----------------
		add[0] = add[0].replace("Throughout Spring Hill", "3449 Jason Rd").replaceAll("\\s*\\(*\\d+\\)*\\s*[-]*\\s*\\d+-\\d+$", "");
		if (add[0].equals("0000")) {
			add[0]=ALLOW_BLANK;
		}
		//------to remove status form Address----------
		add[0] = add[0].replaceAll("Coming Soon Pre-sell|Click On Directions|Selling From (Waterleaf|Verandah|(The )?Hillstone Pointe Model)|Please See Detailed Directions Below|Call For An Appointment - |New Homes, Now Selling!!|​|Model Coming Early Spring 2020|This Model Is Temporarily Closed|New Model Coming Soon|See Ronda For Information|New Phase |Cal Ashley For Information| Gps Use 1137 Sigman Road|(GPS Address: 200 James Road)|GPS use 1137 Sigman Road|Please Call For Additional Information|Model Coming Winter 2019|Model Coming Summer 2019!|Model Coming Soon! |(GPS Address: 134 Furr Road)&#160;|Sales Office: Woodbury Park - |Sales Office: Pine Forest -|Model Home Coming Soon|Please Call For Appointment$|Please Call For Information$|\\* Model Home Coming Soon \\* |\\*\\* Model Opening Soon \\*\\*\\s*|\\*\\*\\s*[M|m]?odel\\s*[O|o]?ffsite\\s*\\*\\*", "");
		
		add[0] = add[0].replaceAll("Visit Mager Meadows Sales Office|New Homes In Spencer Mountain Village \\|Call Us For More Information| Dallas, North Carolina \\| Express Homes|In Close-out!\\s*|By Appointment Only E-mail Us At: Pohakalasales@drhorton.com|^By Appointment Only$|^Address Coming Soon$| By Appointment Only$| Please Call For Info$| Model Not Open\\s*[Yet]*$|\\s*Call For\\s*([A|a]*n)*\\s*Appointment$|Call For Locations$|Call For An Appointment Close Out Community$|Call Ronda For Information[!]*$|Northstar Call Ronda For Information!| Model Opening Soon$| Model Home Now Open$|Model Anticipated For Fall 2020", "");
		
		add[0]  =  add[0].replaceAll("^"+commName+"$|^Selling From[:]*\\s*|^Tbd$|^\\s*Now Preselling$|^Now Selling[!]*\\s*|Model Coming Soon[!]*$|Model Coming Spring 2019[!]*$|^Model Now Open[!]*\\s*|Coming Soon[!]*$|Coming Spring 2019!\\s*|Coming Summer 2018|Model Coming Spring 2020!|Model Coming Winter 2020!|Sold Out", "");
		add[0] = add[0].replaceAll("New Homes In Apple Creek \\| Dallas, North Carolina \\| Express Homes|New Homes, Now Selling|Coming Soon Early 2021|Coming Summer 2020!|Call Us For More Information|Call Or Email To Join Vip List|Pre-selling From Camden Parc Anna At | Off Hwy 64, East Of Pollard|Antioch, Tn|Ashland City, Tn| Model Offsite| &nbsp;", "").replace("26893 Spyglass Drive Canal Road & Griffith Marina Road", "26893 Spyglass Drive");
		add[0]=add[0].replace("Lake Rd&nbsp;", "Lake Rd ").replace("Silver&nbsp;ridge", "Silver ridge").replace("5201 Mills Drive 5420 Connally Drive", "5201 Mills Drive").replace("No Sales Model. Call For Appointment 843.226.6097", "").replace("(gps Use 1137 Sigman Rd)", "").replace("Model Coming Soon -", "").replaceAll("By Appointment Only!|Call For More Information|Model Coming Early Winter 2020!|Model Coming Fall 2019|Model Now Open|- Please Call|Please|Gps Use ", "")
				.replace("Coming 2020!", "")
				.replaceAll(" \\(.*?\\)", "").replace(" – ", " - ");
		add[0]=add[0].replace("2437 Sand Gables Trail Selling From Evergreen & Evergreen Estates", "2437 Sand Gables Trail")
				.replace("170 Pullin Road | 104 Cranapple Lane", "170 Pullin Road")
				.replace("Grist Mill Drive Rincon, Ga 31326", "Grist Mill Drive")
				.replace("Wrightsboro Rd & Deer Hollow Run 405 Roebuck Pass", "Wrightsboro Rd & Deer Hollow Run");
		
		if(add[0].contains("Coming Winter 2022") || add[0].contains("Email For Availability")|| 
				add[0].contains("Coming December 2021")|| add[0].contains("Coming Early 2022") ||
				add[0].contains("Coming Fall 2022")||add[0].contains("Now Pre Selling!")||add[0].contains("Model")|| add[0].contains("Coming 2023")|| add[0].contains("Pre-selling Now"))add[0]=ALLOW_BLANK;
		
		if(comUrl.contains("greenville/greenville/tanglewood-townes"))add[0]="1860 S-23-50";
		add[0]=add[0].replace("2645 Howland Blvd. & Surrounding Areas","2645 Howland Blvd");
		U.log("Formatted Street Address ::::::::::>" + add[0]+"<::::::::::::");
		
		if ((add[0]==null||add[0].length()<4) && (Latlon[0]!=null||Latlon[0].length()>3)) {
			add=U.getGoogleAddressWithKey(Latlon);
			geo="TRUE";
		}
		if ((add[0]!=null||add[0].length()>3) && (Latlon[0]==null||Latlon[0].length()<3)) {
			Latlon=U.getGoogleLatLngWithKey(add);
			geo="TRUE";
		}
		
		
		add[0]=add[0].replace("8319 Ecr 113, Midland", "8319 Ecr 113").replace("&#39;", "");
		U.log("\n********"+add[0]+"********"+add[1]+"********"+add[2]+"********"+add[3]+"********");
		U.log("Address --> "+Arrays.toString(add));
		//----------------------------------------------------------------------------Price------------------------------------------------------------------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		allFloorHomesData = allFloorHomesData.replaceAll("s</strong>", ",000</strong>").replaceAll("00’s|00s|00's|00'S|00&rsquo;s", "00,000").replaceAll("0's|0s", "0,000").replace("0’s.", "0,000").replace("the mid 200's", "the mid \\$200,000").replace("$1.8m", "$1,800,000").replace("$1.9m", "$1,900,000")
				.replaceAll("<strong>\\$(\\d)\\.(\\d)m</strong>", "<strong>\\$$1,$200,000</strong>");
		allAvailHomesData = allAvailHomesData.replace("<span class=\"price\">$466,660</span> ", "").replaceAll("s</strong>", ",000</strong>").replaceAll("00’s|00s|00's|00'S|00&rsquo;s", "00,000").replaceAll("0's|0s", "0,000").replace("0’s.", "0,000").replace("the mid 200's", "the mid \\$200,000");
		comSecs = comSecs.replace("prices in the $170�s", "prices in the $170,000").replaceAll("s</strong>", ",000</strong>").replaceAll("00’s|00s|00's|00'S|00&rsquo;s", "00,000").replaceAll("0's|0s", "0,000").replace("0’s.", "0,000").replace("the mid 200's", "the mid \\$200,000").replace("Nature Trails\",\"fismultigen51359\":\"0\",\"fpricemin\":320,000,", "").replace(",\"fismultigen51359\":\"0\",\"fpricemin\":288,000,", "").replace(",\"fpricemin51359\":192,000,", "").replace("\"fsqftmaz120x51359\":2320.0,\"fsqftmin51359\":1712.0,", "").replace("\"fpricemin\":202,000,\"f", "").replace("brandlogo-express.ashx\",$395,000:\"North Las Vegas","");
		mainData = mainData.replace("from the $275s-$550s", "from the $275,000-$550,000")
				.replace("from the <strong>$319,000</strong>","$319,000").replace(" in the 200s", " in the $200,000").replace("From the 240's", "From the $240,000").replace("THE MID $400',000", "THE MID $400,000").replace("prices in the $170’s", "prices in the $170,000").replace("THE MID $300's", "THE MID $300,000").replace("upper $", "upper ").replace("low-$300s", "in the low-$300,000 and").replace("$1.8m", "$1,800,000").replace("Starting in the 190’s", "Starting in the 190’s").replace("$1.9m", "$1,900,000").replace("in the low-$300,000s and", "in the low-$300,000 and").replaceAll("s</strong>", ",000</strong>").replaceAll("00’s|00s|00's|00'S|00&rsquo;s", "00,000").replaceAll("0's|0s", "0,000").replace("0’s.", "0,000").replace("the mid 200's", "the mid \\$200,000").replace(",\"fpricemin\":192,000,\"", "");
	//	U.log(">>>>>>"+Util.matchAll(mainData+allAvailHomesData+allFloorHomesData+comSecs+commHtml, "[\\w\\s\\W]{30}382,890[\\w\\s\\W]{30}", 0));
		U.log(U.getCache(comUrl));
		comSecs = comSecs.replace("\"fpricemin18184\":", "$").replace(".0,\"fcity18184\"", ",000").replaceAll("... \\$\\d{3},\\d{3} ...", "");
		String availPrice="";
				availPrice=U.getSectionValue(commHtml, "<span class=\"price\"", "</span>");
		U.log("========"+availPrice);
		
     //  U.log("CommSEc   \n"+comSecs);
       comSecs=comSecs.replaceAll("brandlogo-drh.ashx\",$478,000:\"Fredericksburg\"|brandlogo-express.ashx\",$395,000:\"North Las Vegas\"","");

//       U.log(">>>>>>>>>>>>>>>>"+allFloorHomesData);
       String prices[]=U.getPrices((mainData+allAvailHomesData+allFloorHomesData+comSecs+availPrice).replaceAll("brandlogo-express.ashx\",$395,000:\"North Las Vegas\"|brandlogo-drh.ashx\",$478|Excerpt\":\"$366,990|$366,000:\"Austin|excerpt\":\"$366,990|Brands/brandlogo-drh.ashx\",$849,000:\"MONROE", "").replaceAll("\\$466,660</span>|\\$467,040</span>|\\$289,900</span>", "").replaceAll("s</strong>", ",000").replace("THE MID $400',000", "THE MID $400,000"), 
				"\\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|ashx\",\\$\\d+,\\d+:|ashx\",\\$\\d+,\\d+:\"|From the \\$\\d{3},\\d{3}|prices in the \\$\\d{3},\\d{3}|THE MID \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|Starting in the <strong>\\$\\d,\\d{3},\\d{3}</strong>|priced from the \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3},|in the low-\\$\\d{3},\\d{3} and|(From|Starting in the) <strong>\\$\\d{3},\\d{3}</strong>|mid(-|\\s)\\$\\d{3},\\d{3}|upper \\d{3},\\d{3}|the \\$\\d{3},\\d{3}|low \\$?\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\"fpricemin\":\\d{3},\\d{3},|<p class=\"home-price\">\\s+\\$\\d{3},\\d{3}\\s+<a|span class=\"lead\">From</span>\\$\\d{3},\\d{3}<a|<p class=\\\"price\\\">\\$\\d{3},\\d{3}</p>|class=\"from\">From</span>\\$\\d{3},\\d{3}|<div class=\"home-price\">\\s+<div>\\$\\d{3},\\d{3}</div>|From</span><div>\\$\\d{3},\\d{3}</div>", 0);
//		U.log("MMMMMMM "+Util.matchAll(availPrice  , "[\\s\\w\\W]{200}\\$347,200[\\s\\w\\W]{200}", 0));

		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		if(comUrl.contains("https://www.drhorton.com/north-carolina/raleigh---durham/durham/nichols-farm"))maxPrice="$478,535";
		if(comUrl.contains("https://www.drhorton.com/georgia/atlanta/mcdonough/lake-iris")) {minPrice="$351,000"; maxPrice="$400,000";}
		if(comUrl.contains("austin/austin/parker-station")) {minPrice="$388,990";}
		if(comUrl.contains("https://www.drhorton.com/virginia/northern-virginia/fredericksburg/ashleigh-ridge")) {maxPrice="$556,000";}
        if(comUrl.contains("https://www.drhorton.com/nevada/las-vegas/north-las-vegas/aries-pointe-at--valley-vista")) {minPrice="$398,000";}
        	
		U.log("MinPrice --> "+minPrice+"\tMaxPrice --> "+maxPrice);
		//-------------------------------------------------------------------------Square Feet----------------------------------------------------------------------
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		comSecs = comSecs.replace("fsqftmin51359", "fsqftmin").replace("fsqftmaz120x51359", "fsqftmaz");
		comSecs = comSecs.replaceAll("fsqftmaz120x18184\":|\"fsqftmin18184\":", "SQFT ");
		
//		U.log("MMMMMMM "+Util.matchAll(mainData+allAvailHomesData+allFloorHomesData+comSecs  , "[\\s\\w\\W]{30}2,700[\\s\\w\\W]{100}", 0));
        
//        if(sqftSec!=null)
//         sqftSec=U.getNoHtml(sqftSec);
		//U.log("Sf"+sqftSec);
	//	U.log("CHHH"+Util.matchAll(mainData,"[\\w\\W\\s]{30}1,600[\\w\\W\\s]{30}",0));
		String sqft[]=U.getSqareFeet((mainData+allAvailHomesData+allFloorHomesData+comSecs+sqftSec).replaceAll("This beautiful home sits on an amazing lot that is 10,499 sq. ft|half bath plan with over 2,700 square feet|reaching to over 3,600|gatehouse and a 9,000 sq. ft. community clubhouse|lots starting 7,000 sq. ft. ", ""), 
				"\\d,\\d{3} to a generous \\d,\\d{3} sq. ft.|start at \\d,\\d{3} and range up to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3}</strong> sq. ft|offering \\d,\\d{3} sq. ft. - \\d,\\d{3}\\+ sq. ft.|ranging from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq ft|start at \\d,\\d{3} and range up to \\d,\\d{3} square feet|\\d,\\d{3} sq. ft - \\d,\\d{3}\\+ sq. ft|\\d,\\d{3} - \\d,\\d{3}</div><p> sq.ft|\\d,\\d{3} - \\d,\\d{3} sq.ft.|size from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq ft|ranging in size from \\d{4} sq. ft. to \\d,\\d{3} sq. ft.|from \\d,\\d{3} sq\\. feet to over \\d,\\d{3} sq\\. feet|from \\d{4} SF to \\d{4} SF|\\d,\\d+ to over \\d,\\d+ square feet|\\d{1},\\d{3} SQ FT to \\d{1},\\d{3} SQ FT|\\d{1},\\d{3} -\\d{1},\\d{3} square feet|\\d{1},\\d{3} sq. feet to \\d{1},\\d{3} sq. feet|from \\d,\\d{3} sq ft – \\d,\\d{3} sq ft|range from \\d{4} sq. ft. – \\d{4} sq. ft|ranging from \\d{1},\\d{3} to \\d{1},\\d{3}|ranging from over \\d{1},\\d{3} - \\d{4} square feet|range from \\d{1},\\d{3} - \\d{1},\\d{3} Sq Ft|ranging from \\d{1},\\d{3} to \\d{4} square feet|range from \\d{3} sq. ft|to \\d{4} square foot|homes up to \\d{1},\\d{3} sq.ft.| \\d{4} square feet on|Plan square footage ranges in the \\d,\\d{3}|from \\d,\\d{3} -\\d,\\d{3} sf|from \\d{4} square feet to over \\d{4} square| approximately \\d,\\d{3}-\\d,\\d{3} square foot|<div>\\d,\\d{3} - \\d,\\d{3}</div><p> sq.ft|series \\d,\\d{3}\\+ SQFT|range from \\d,\\d{3} sq ft\\. to \\d,\\d{3} sq ft\\.|approx\\. \\d,\\d{3}-\\d,\\d{3} sq ft\\.|Ranging from \\d,\\d{3} - \\d,\\d{3} sq. ft.|ranging from \\d,\\d{3} – \\d,\\d{3} sq. ft.|[r|R]anging from \\d,\\d{3} – \\d,\\d{3} square feet|homes from \\d{4} sq. ft. - \\d{4} sq. ft., |homes from \\d{4} sq\\. ft\\. - \\d{4} sq\\. ft\\., ge|homes at \\d{4} square feet|homes at \\d{4} square feet|from \\d,\\d{3}-\\d,\\d{3} sq|\\d,\\d{3} to \\d,\\d{3}\\+ square feet|\\d,\\d{3} to \\d,\\d{3} sq|\\d{4} to \\d{4} SF| \\d,\\d{3} to \\d,\\d{3} square feet| \\d,\\d{3}-\\d,\\d{3} square feet| \\d,\\d{3} square feet|\\d,\\d{3} sf to \\d,\\d{3} sf|from \\d,\\d{3} to \\d,\\d{3} st|<strong>\\d{3} - \\d,\\d{3}</strong> sq ft|square footage from \\d,\\d{3} to over \\d,\\d{3}|\\d{4} sq ft to \\d{4} sq ft|\\d,\\d{3} - \\d{1,2},\\d{3}</strong> sq ft|<strong>\\d,\\d{3}</strong> sq ft</li>|<strong>\\d,\\d{3}</strong> sq\\. ft\\.|\"fsqftmin\":\\d{3,4},|\\d,\\d{3} sq\\. ft|\"fsqftmaz\":\\d{3,4},|(fsqftmin|fsqftmaz)\":\\d{3,4}\\.0,|\\d,\\d{3} - \\d,\\d{3}</div><p>\\s?sq\\.ft\\.|\\d{3} - \\d,\\d{3}</div><p> sq.ft|\\d,\\d{3} - \\d,\\d{3} square feet|ranging from \\d,\\d{3} to \\d,\\d{3}qft|\\d{3} - \\d{3}</div><p> sq.ft.|SQFT \\d{4}", 0);
		
		if(comUrl.contains("https://www.drhorton.com/nevada/las-vegas/las-vegas/bella-manor"))
			sqft[1]="2758";

			
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft --> "+minSqft+"\tMaxSqft --> "+maxSqft);
		//-------------------------------------------------------------------------Prop Status-----------------------------------------------------------------------
		
		mainData = mainData.replace("new phase is coming in 2022", "new phase coming 2022").replace("Coming in 2022", "Coming 2022")
				.replaceAll("acre lots available|Grand Opening and Special Incentives|Coming Spring 2020 to Modesto|Pomegranate in Newark\\.\\s+Coming Fall|MOVE-IN|Models Coming|Express Homes are now selling|cabana coming soon|Model Coming Winter|MODEL COMING WINTER|Coming soon to New Port|Coming Soon NEW Amenitie|log cabin where he|coming soon to Coolidge|coming soon to Manahawkin| it’s now selling in Tioga Ridge|AMENITY CENTER COMING SOON|model homes coming soon| pricing and grand opening i|ready|Ready|<strong>Only 1 Remaining!</strong>|urrently selling from Information |Cottage Shops|CLOSE OUT phase of our exclusive|orton homes are now available|[p|P]ool - [c|C]oming|[h|H]ouse - [c|C]oming [s|S]oon|[m|M]odel [c|C]oming|New phase now open! Affordable|Pavillion Coming Soon|COMING SOON:|Now Selling from the Walnut Creek Clubhouse|Model Coming Winter|Model Coming Summer|approximately \\d+ available homesites|under construction and selling now|Allen Park coming this Winter to Ayden|Now selling quickly, this incredible|Now Selling by Appointment|move in homes and start living|move in homes and see for yourself|Few opportunities remain! Top|Meadows are coming soon|<li>Pool \\(Coming|coming soon new home community in Hampstead|<li>Model Home Coming Soon|Coming Soon!\">Coming Soon!|move-in ready buyer|homes available now from the low \\$\\d+,\\d+ in Thornton|limited opportunity pass you|quick move-in|local grand opening|shopping will be coming|and move-in ready homes available in Charles Cove|fire pit. Coming Soon! Dock and gazebo|ommunitytype=\"Move-In Ready Detail\"|value=\"Move-In Ready Detail\"|17-Acre City Park-Coming Summer 2019|pavilion is now open|New Phase coming in 2020! Be First to Kno|ickerington is now available and under constructio|Model Row Now Open|Ready takes on|story lots|opportunities to invest|opening events", "")
				.replace("waterfront lots and wooded tree lots available now", "waterfront lots available now").replaceAll("soon in Ruskin|new phase opens in late summer|center (coming soon|opening)|Status Move-In Ready Homes|homes are coming soon|amenity coming soon|(Oaks is|which are|center is|Ridge is) coming|Amenities COMING|(Playground|Courts|Park –|New Community) Coming|now open and we|SPRING 2020! Riverbend|_blank\">Coming|<li>\\*\\*\\*NEW SECTION NOW|fountains \\(coming|CENTER NOW|until new phase|updates on grand", "")
				.replace(" new phase is coming soon", " new phase coming soon").replace("New, affordable floor plans are available now", "New floor plans are available now")
				.replace("Phase Two is now open and selling fast", "Phase Two now open and selling fast").replace("New phase coming Spring of 2021", "New phase coming Spring 2021")
				.replace("new phase of Brightwood Farm coming Late", "new phase coming Late").replace("Final phase featuring exclusive lake side homesites now selling", "Final phase now selling")
				.replace("New Phase coming this summer", "New Phase coming summer").replace("Phase 2 in Close-Out", "Phase 2 Close-Out").replace("New section is NOW OPEN", "New section NOW OPEN")
				.replace("new phase is now open and selling", "new phase now selling").replace("Only 22 home sites remain in this final phase", "Only 22 home sites remain in final phase")
				.replace("Grand Opening Coming Soon", "Grand Opening").replaceAll("Water\\s+front lots are available", "Water front lots are available")
				.replace("NOW SELLING IN FINAL SECTIONS", "NOW SELLING FINAL SECTIONS").replace("Limited opportunities are available", "Limited opportunities available")
				.replace("New Phase Coming in 2022", "New Phase Coming 2022").replace("NEW PHASE COMING IN SUMMER 2021", "NEW PHASE COMING SUMMER 2021").replace("Second Phase of Homesites Now Selling", "Second Phase Homesites Now Selling").replace("Clubhouse *Coming Soon*", "").replace("New Phase of homes is now available", "New Phase now available");
		comSecs = comSecs.replaceAll("Model Coming|have been selling fast|[p|P]ool - [c|C]oming|[h|H]ouse - [c|C]oming [s|S]oon|factivationstate\\d+\":\"New Section Open|move in homes and start living|move in homes and see for yourself|factivationstate\\d+\":\"Final Opportunities\"|Few opportunities remain! Top|Meadows are coming soon|<li>Pool \\(Coming|coming soon new home community in Hampstead|<li>Model Home Coming Soon|Coming Soon!\">Coming Soon!|move-in ready buyer|homes available now from the low \\$\\d+,\\d+ in Thornton|1766EB\",\"factivationstate51359\":\"Coming Soon\",\"fcity51359\":\"North|572BA\",\"factivationstate51359\":\"Coming Soon\",\"fcity51|5F959\",\"factivationstate51359\":\"Coming Soon\",|022\",\"factivationstate51359\":\"Coming Soon\",|8B4\",\"factivationstate51359\":\"Coming Soon\"|46CED\",\"factivationstate51359\":\"Coming Soon\",|A7FA\",\"factivationstate51359\":\"Now Selling\",\"fci|FDC0\",\"factivationstate51359\":\"Coming Soo|D2FE\",\"factivationstate51359\":\"Coming Soo|E9CB4\",\"factivationstate51359\":\"Coming Soon\",\"fcity5|EA134\",\"factivationstate51359\":\"Sold Out\",","");
//		
		addStausSec = addStausSec.replaceAll("Center Coming|Coming Soon,|Model Coming|MODEL COMING|Models Coming", "");
		mainData = mainData.replace("Coming Fall-Late 2021", "Coming Fall Late 2021")
				.replace("Phase 2 is COMING SOON", "Phase 2 COMING SOON").replaceAll("Homes Now Selling in Valencia on the Lake|other communities now selling in Los Banos|grand opening dates|Grand Opening Dates|Now Selling in North|beautiful home sites available late Summer 2021|<dt>Amenities</dt>\n\\s+<dd>\n\\s+<ul>\n\\s+<li>New Phase Now Selling</li>|Freedom Homes is now selling|number NOW AVAILABLE|Models Opening|variety of Quick Move|Grove, the “Coming|amenity area coming|alt=\"Phase II Coming Soon|Many water front home sites available|Model is Coming|Coming soon is D.R.|Coming soon to Lakewood|Model Coming", "")
				.replace("Oversized Lots &amp; Lake Lots Available", "Oversized Lots & Lake Lots Available").replace("Preumium", "Premium").replaceAll("-CLOSEOUT.ashx|Phase Opening Soon! Contact|Our final home available|Opening Weekend|Re-opening|Townhomes are SOLD", "");
		
		
		U.log(mainData.contains("quick") +"==="+ addStausSec.contains("quick") );

//		U.log(">>>>>>propo"+Util.matchAll(addStausSec + mainData, "[\\w\\s\\W]{30}now open[\\w\\s\\W]{30}", 0));
//		U.log(">>>>>>\n"+addStausSec);
//		U.log("\n>>>>>>\n"+comSecs);
		comSecs=comSecs.replaceAll("latest on New Communities, New Phases, and New Model|the latest on New Communities, New Phases and New Model", "");
		String desc=U.getSectionValue(commHtml, "<div class=\"community-details\">", "Community Information</h2>");
		String propStatus=U.getPropStatus((desc+comSecs+mainData+addStausSec ).replace("floorplans, pricing and grand opening", "")
				.replace("Our final phase is sold out", "Our final phase sold out")
				.replace("receive updates on new communities/new phases", "")
				.replace("Opening is Fall 2021", "Opening Fall 2021")
				.replace("phase 2 is Coming Soon", "phase 2 Coming Soon")
				.replace("50% SOLD OUT of Phase 2", "50% SOLD OUT Phase 2")
				.replace("current phase is sold out", "current phase sold out")
				.replace("just a few homes left", "just few homes left")
				.replace("newest phase is open", "newest phase open")
				.replace(" USDA 100% financing is also available", " USDA 100% financing available")
				.replace("Phase 8 sold out. New phase coming soon", "New phase coming soon. Phase 8 sold out")
				.replaceAll("Now selling with more home sites coming soon! Amberglen|a new phase is anticipated this summer.|interest list is now open|Cabana Coming Soon|limited number NOW AVAILABLE|Currently selling from nearby community|Models are now open|Models are now open at our new community|(coming soon)|Community swimming pool and cabana are coming soon|More information will be coming soon|MODELS COMING|[i|I]mmediate [m|M]ove|including special pricing, grand openings and more.|New Community in Baton Rouge Coming Soon!|Community information coming soon!|MODEL COMING SOON!|We are currently selling  homes in Greenwood|Edgewater community currently selling in Waterford|appointment before we are Sold Out!|beautiful lots with lake lots available|This opportunity will be selling fast|Quick Move in Homes Available|PHASE NOW OPEN|Quick Move In Homes Available|homes are now selling|Preserve. OPENING SOON|- Coming Soon| coming soon to |Coming Soon to |selling fast. Get everything|amenity center is now open|Team is currently selling|Now selling in Modesto at Roselle |have been selling fast|With homes selling fast, be | Now Available! Welcome to Riposa |home sites coming soon|New Single-Family Homes Coming Soon to Palm Bay| coming soon to Coolidge, Arizona|New Inventory Homes Coming Soon|100% USDA financing available! D.R. Horton has|Close Out - Limited Opportunities|Currently selling by appointment only", "").replace("NEW PHASE & NEW MODEL COMING IN FALL 2021", "New Phase Coming Fall 2021").replace("New sections of Wagnalls Run coming soon", "New Section Coming Soon").replace("New D.R. Horton Phase coming soon", "New Phase Coming Soon").replace("final phase of Bellah Landing is open but selling fast!", "Final Phase Selling fast").replace("Current Phase is Sold Out", "Current Phase Sold Out").replaceAll("amenity site will be coming soon|now available in Saratoga!|the district, now open|for our coming soon townhome community|Coming soon to North|This opportunity will be selling fast", "").replace("waterfront lots and wooded tree lots available", "Waterfront and wooded tree lots available").replace("<li>Closing Out</li>", "").replace("just a few homes left", "Just a few homes left")); //addsec is taken, becoz there are prop. status that are present at address but not in community content.
		U.log("Prop Status: "+propStatus);
//		U.log("MMMMMMMMMMMMMMMMMM propStatus  "+Util.matchAll((comSecs  ),"[\\s\\w\\W]{100}New Phase[\\s\\w\\W]{100}", 0));
//		U.log("MMMMMMMMMMMMMMMMMM propStatus  "+Util.matchAll((desc),"[\\s\\w\\W]{100}New Phase[\\s\\w\\W]{100}", 0));

		propStatus=propStatus.replace("Move In Ready Home", "Quick-move In Homes");
		//-------------------------------------------------------------------------Prop Type-------------------------------------------------------------------------
		mainData = mainData.replace("Craftsman and Farmhouse", "Craftsman homes and Farmhouse style")
				.replaceAll("traditional and modern, this elevation", "");
		if(areaInfo!=null)
		areaInfo=areaInfo.replaceAll("Cottage Shops", "");
		if (comUrl.contains("https://www.drhorton.com/alabama/baldwin/spanish-fort/emerald-stonebridge")) mainData+=", luxury homes";
//		U.log(Util.match(areaInfo, ".*Cottage.*"));
		
		
		
   //     U.log("prp::"+Util.matchAll(mainData+comSecs+allAvailHomesData+allFloorHomesData+areaInfo,"[\\w\\W\\s]{40}Single Family[\\w\\W\\s]{40}", 0));
		String propType=U.getPropType((mainData+comSecs+allAvailHomesData+allFloorHomesData+areaInfo).replaceAll("Northshore-Cottage|known for its participation in the arts| log cabin where he|- Patio Homes\"", "")
				.replaceAll("fpropertytype18184\":[\"Townhome\"]|2711 Condor", "")
				.replaceAll(" large and luxurious| luxury is everywhere in these 4 homes", "luxury homes")
				.replace("multigenerational living with a separate living space", "Multi-Gen Living Space")
				.replaceAll("Multi-Gen Feature Sheet", "Multi-Generational Home")
				.replace("From the custom floor-to-ceiling", "From a custom-quality floor-to-ceiling")
				.replaceAll("across the Twin Cities Metropolitan Area feature single-family, townhomes|craftsmanship|Woodbridge-Glen-Cottages|Greystone_Farmhouse-Sink.ashx|New Duplexes in Cedarhome|\"Find a duplex home|duplexes\">|\"fpropertytype18184\":\\[\"Single Family\"\\]|Square Duplexes|-duplexes|New Bethel - Patio Homes|-Duplex|SQUARE DUPLEXES|TANGIPAHOA|Tangipahoa|No HOA|craftsman style elevation|Valley Single-Family Homes", "")
				.replaceAll("Prairie and Farmhouse|Prairie, and Farmhouse", "Prairie, Farmhouse"));
		propType=(propType.contains("Townhome")&&propType.contains("Townhouse"))?propType.replaceAll("[, ]?Townhouse[,]?", "").replaceAll("^, ", ""):propType;
		U.log("Prop Type: "+propType);
//			U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(mainData+comSecs+allAvailHomesData+allFloorHomesData+areaInfo, "[\\s\\w\\W]{30}Condo[\\s\\w\\W]{30}", 0));

		//-------------------------------------------------------------------------Derived Prop Type------------------------------------------------------------------

		//+areaInfo
		if(allAvailHomesData != null) allAvailHomesData = allAvailHomesData.replaceAll("<strong>(\\d.?\\d?)</strong> Story", "<strong> $1 Story </strong>");
		if(allFloorHomesData != null) allFloorHomesData = allFloorHomesData.replaceAll("<strong>(\\d.?\\d?)</strong> Story", "<strong> $1 Story </strong>");
		
//		U.log(allFloorHomesData);
	
//		U.writeMyText(allFloorHomesData);
		String dPropType=U.getdCommType((mainData+comSecs+allAvailHomesData+allFloorHomesData).replace("1-Story", "1 Story").replace("</strong> Story", " Story")
				.replace("featuring one, one-and-a-half, and two story homes ", "featuring one story, one-and-a-half story, and two story homes ")
				.replace("one-, two-, and three-story", " 1 Story  2 story  3 Story ")
				.replace("single, split level, 2 or even 3-story designs", " 1 Story  split level 2 Story 3 Story ")
				.replace("single and two-story", " 1 Story  2 Story ").replaceAll("</strong>(<span>)? Story(</span>)?</li>", " Story</li>")
				.replaceAll("\\d bed|SQUARE DUPLEXES|rancho| 24 Story </strong>|storybrook|Freeman Ranch Street|Rancho Palos|Rancho|Silverado-1-5-Story-Model|new phase opens in late summer|Luckey Ranch Elementary|Redbird Ranch|-ranch\"|Storybrook|3-bedroom home|/6124-Story-Rd-197|Colonial (Promenade|Golf)|multi-level brick|(B|b)ranch|Sanctuary at Bull Valley Ranch Homes|ValleyRanch", ""));
		U.log("Derived Prop Type: "+dPropType);
	//	U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(mainData+comSecs+allAvailHomesData+allFloorHomesData+areaInfo, "[\\s\\w\\W]{30}6055[\\s\\w\\W]{30}", 0));

		//-------------------------------------------------------------------------Community Type---------------------------------------------------------------------
		mainData = mainData.replace("adults 55 years", "55+ Community").replace("Congressional 55+","55+ Community");
		comSecs = comSecs.replace("Congressional 55+","55+ Community").replace("adults 55 years", "55+ Community").replaceAll("listfordisplay\\d+\":\"Active Adult, HOA\"", "");
		
		String commType=U.getCommType((mainData+comSecs+areaInfo).replaceAll("street from Midland Country Club|designs in a lakefront village|ome have gated entries while|Resort-Style-Pool| jogging paths to a golf course and even |Red Oak Valley Golf Club|playing golf, or with the family at one of |from young professionals to active adults.</p>|Mooresville Golf Club|playing a round of golf or|or a round of golf|beautiful beaches and quality golf courses|from the Colonial Golf &(amp;)? Country Club|Nearby Golf", ""));
//			U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(mainData+comSecs+areaInfo, "[\\s\\w\\W]{30}Golf Course[\\s\\w\\W]{30}", 0));

		U.log("Comm Type: "+commType);
		
		if(comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/moorestown/congressional"))
			commType="Active Adult, 55+ Community";
		
		//=================================================================================================================================================================
		if(comUrl.contains("https://www.drhorton.com/texas/fort-worth/aledo/morningstar")) {
			commName="Morningstar";
		}
		
		if(commName.endsWith("Estates") && !propType.contains("Estate")) {
			if(propType.length()>1)
				propType=propType+", Estate-Style Homes";
			else
				propType ="Estate-Style Homes";
		}
		if(propType.contains("Townhouse") && propType.contains("Townhomes")) {
			propType=propType.replace("Townhouse", "").trim().replaceAll("^,|,$", "");
			propType = propType.replace(", ,", ",").trim();
			
		}
		if(comUrl.contains("-twinhomes") && !propType.contains("Twin")) {
			propType =propType+", Twin Homes";
		
		}
		
		U.log("Community Name: "+commName);
		commName = commName.replaceAll("and Duplexes$|- Lifestyle Detached Patio Homes|, Phase II?|-The Villas$|Twin Villas$| Villas$| Villas Estates$", "").trim();
		commName=commName.endsWith("-")?commName.replaceAll("-$", ""):commName;
		
		
		if(comUrl.contains("https://www.drhorton.com/south-carolina/greenville/piedmont/express-willow-grove")) {
			add[0]="Willow Grove Way";
		}
		
		if(comUrl.contains("https://www.drhorton.com/south-carolina/greenville/easley/james-lake")) {
			add[0]="James Lake Way";
		}
		
		if(comUrl.contains("drhorton.com/florida/central-florida/tavares/verandah-park")) {
			add[0]="15429 Old Us Hwy 441";
		}
		//From Img
		if(comUrl.contains("hammond-ponchatoula/ponchatoula/southern-pines"))propStatus="Coming Soon";
		
		
//		if (comUrl.contains("https://www.drhorton.com/washington/spokane/spokane-valley/the-orchards")) minPrice = ALLOW_BLANK;
		//if (comUrl.contains("/texas/fort-worth/glenn-heights/magnolia-meadows")) propStatus = "New Phase Open";
		if(comUrl.contains("https://www.drhorton.com/florida/pensacola/milton/whisper-creek-new")) geo = "True"; //address not visible on pg
		if(comUrl.contains("https://www.drhorton.com/florida/central-florida/haines-city/charles-cove-express")) { add[1]="Davenport";geo = "True";}
		
 
		if(comUrl.contains("https://www.drhorton.com/florida/central-florida/edgewater/oak-leaf-preserve-freedom"))propType+=", Coastal Style Homes"
				+ "";
		if(comUrl.contains("m/california/central-valley/los-banos/the-villas"))commName="The Villas";
		propStatus = propStatus.replace("New Phase Coming Soon, New Phase Coming Spring 2020", "New Phase Coming Spring 2020");
		propStatus = propStatus.replace("Final Opportunities, Last Opportunities", "Final Opportunities")
				.replace("New Phase Now Open, New Phase Open", "New Phase Now Open")
				.replace("New Section Open, Quick-move In Homes, New Section Now Open", "Quick-move In Homes, New Section Now Open").replace("New Section Now Open, New Section Open", "New Section Now Open")
				.replace("New Phase Coming Fall 2022, New Phase Coming Soon, Sold Out", "New Phase Coming Fall 2022, Sold Out")
				.replace("Phase Two Coming Summer 2022, Coming Soon","Phase Two Coming Summer 2022");
		
		if (mainData.contains("DRH-Coming-Soon.ashx")) {
			if (propStatus.length()>2&&!propStatus.contains("Coming Soon")) {
				propStatus+=", Coming Soon";
			}else if (propStatus.length()<2&&!propStatus.contains("Coming Soon")) {
				propStatus="Coming Soon";
			}
		}
		U.log("Prop Status: "+propStatus);

		
		add[0] = add[0].trim().replace("1207 Brookstone Circle Ne", "1207 Brookstone Circle NE").replace("Dr -", "Dr");
		if(add[0].trim().endsWith("-"))	add[0]= add[0].replaceAll("-$", "");
		if(comUrl.contains("https://www.drhorton.com/ohio/columbus/delaware/springer-woods") ||comUrl.contains("/houston/katy/ventana-lakes"))propStatus+=", New Plans Now Available";
		if(comUrl.contains("https://www.drhorton.com/nevada/las-vegas/north-las-vegas/nova-pointe-at-valley-vista"))propStatus="New Plans Now Available";
		if(comUrl.contains("https://www.drhorton.com/florida/tampa/zephyrhills/express-silverado") && !propStatus.contains("Final Opportunities")) 
			propStatus = "Final Opportunities, "+propStatus; //From Region page Image //Added @ 13 Feb 2021
		
		propStatus = propStatus.replace("New Phase Open, New Phase Now Open", "New Phase Open");
		if(comUrl.contains("richmond/new-kent/arbors-at-farms-of-new-kent---express"))propStatus="New Plans Now Available";
		if (comUrl.contains("https://www.drhorton.com/minnesota/minneapolis/lakeville/cedar-crossing-express"))
			propStatus = propStatus.replace(", New Phase Now Open", "");
		
		
			if (comUrl.contains("https://www.drhorton.com/texas/dallas/forney/governors-lots"))
				propStatus = "Coming Soon, Lots Coming Soon";
			
			if (comUrl.contains("minnesota/minneapolis/lakeville/cedar-crossing-express"))
				propStatus += ", Now Selling";
			
			if (comUrl.contains("https://www.drhorton.com/georgia/atlanta/newnan/heritage-ridge"))
				propStatus = "Final Phase Sold Out";
			
//			if (comUrl.contains("south-sound/puyallup/rainier-ridge-horton"))
//				propStatus = propStatus.replace("New Phase", "New Phase Coming Soon");
			
//			if (comUrl.contains("https://www.drhorton.com/alabama/mobile/mobile/burlington-estates"))
//				propStatus += ", New Phase Now Open";
		
		if(comUrl.contains("https://www.drhorton.com/georgia/atlanta/hampton/crystal-lake"))commName="Crystal Lake";
		
		if(propStatus.contains("New Phase Open") && propStatus.contains("New Phase Now Open"))
			propStatus = propStatus.replaceAll("New Phase Open,|, New Phase Open|New Phase Open", "");
		if(propStatus.contains("Usda 100% Financing Available")&&propStatus.contains("New Phase Coming Soon")&&propStatus.contains("New Phase Coming 2022"))
			propStatus="New Phase Coming 2022, Usda 100% Financing Available";
		propStatus = propStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		propStatus = propStatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		propStatus = propStatus.replace("Coming Summer 2022, Phase 2 Coming Summer 2022", "Phase 2 Coming Summer 2022");
		propStatus=propStatus.replace("New Phase Coming Soon, New Phase Coming In 2022", "New Phase Coming In 2022");
		/* Added @ 13 Feb 21
		 * For Repeated status
		 */
		if(commHtml.contains("This beautiful community is coming soon")) {
			if(propStatus.length()>4)
			propStatus+=", Coming Soon";
			else
				propStatus="Coming Soon";
		}
		U.log("Prop Status: "+propStatus);

		
		if(propStatus.contains("Final Phase Selling Fast") && propStatus.contains(", Final Phase"))propStatus = propStatus.replace(", Final Phase", "");
		if(propStatus.contains("Phase Two Now Open And Selling Fast, Selling Fast"))propStatus =propStatus.replace("Phase Two Now Open And Selling Fast, Selling Fast", "Phase Two Now Open And Selling Fast");
		if(propStatus.equals("Only 1 Opportunity Remains, Only 1 Opportunity Remain, Closing Out, Quick-move In Homes, 1 Opportunity Remains"))propStatus="Only 1 Opportunity Remains, Closing Out, Quick-move In Homes";
//		if(propStatus.contains("New Phase Coming Soon") && 
//				(propStatus.contains("New Phase Coming Spring") || propStatus.contains("New Phase Opening Spring"))){
//			propStatus = propStatus.replace("New Phase Coming Soon", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
//		}
		//New Phase Opening Late 2021/early 2022, New Phase Coming Soon
		if(propStatus.contains("New Phase Opening Late 2021/early 2022, New Phase Coming Soon"))propStatus=propStatus.replace("New Phase Opening Late 2021/early 2022, New Phase Coming Soon", "New Phase Opening Late 2021/early 2022");
        if(propStatus.contains("New Phase Coming Summer 2021, New Phase Coming Soon"))propStatus=propStatus.replace("New Phase Coming Summer 2021, New Phase Coming Soon", "New Phase Coming Summer 2021");
		if(comUrl.contains("https://www.drhorton.com/south-carolina/charleston/summerville/the-ponds")) {
			add[0]="105 Bright Meadow Road";
		}
		if(comUrl.contains("https://www.drhorton.com/florida/north-florida/st-marys/bartram-place")) {
			Latlon=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if(add[0].contains("Call For Availability")||add[0].contains("Model Closed")||add[0].contains("New Model")||add[0].contains("See Agent")) {
			add=U.getAddressGoogleApi(Latlon);
			geo="TRUE";
		}
		if(comUrl.contains("https://www.drhorton.com/texas/houston/league-city/westwood"))minPrice="$319,000";
		if(comUrl.contains("https://www.drhorton.com/new-jersey/new-jersey/egg-harbor-township/autumn-lane"))geo="FALSE";
		if(comUrl.contains("https://www.drhorton.com/texas/fort-worth/arlington/rockingham-estates"))propStatus+=", Now Selling";//img
		if(comUrl.contains("north-carolina/charlotte/matthews/chase-view"))propStatus=propStatus.replace("Sold Out", "Currently Sold Out");
		if(comUrl.contains("https://www.drhorton.com/tennessee/knoxville/knoxville/governors-landing"))propStatus="New Phase Coming Soon, Quick-move In Homes";
		propStatus=propStatus.replace("Wooded Homesites Just Released, Quick-move In Homes, New Plans Now Available", "Wooded Homesites Just Released").replace("New Phase Coming In 2022, Coming Soon", "New Phase Coming In 2022").replace("New Phase Opening Spring/summer 2021, Coming Soon", "New Phase Opening Spring/summer 2021").replace("New Phase Coming Summer 2021, Coming Soon", "New Phase Coming Summer 2021").replace("Coming Soon, New Phase Coming Summer 2021", "New Phase Coming Summer 2021").replace("Final 10 Opportunities Coming Late Spring, Final Opportunities", "Final 10 Opportunities Coming Late Spring");
		if(comUrl.contains("https://www.drhorton.com/florida/west-central-florida/newberry/oak-park"))minPrice="$264,990";
		if(comUrl.contains("https://www.drhorton.com/florida/tampa/riverview/freedom-waterleaf"))minPrice="$328,330";
		propStatus = propStatus.replace("Final Phase Now Selling, Final Phase", "Final Phase Now Selling").replace("Final Opportunities, Coming Late Spring", "Final 10 Opportunities Coming Late Spring");
		propStatus=propStatus.replace("Quick-move In Homes", "Quick Move In Homes").replace("New Phase Coming June 2021, New Phase Coming Soon", "New Phase Coming June 2021").replace("Current Phase Sold Out, Sold Out", "Current Phase Sold Out").replace("Currently Sold Out, Sold Out", "Currently Sold Out");
		if (comUrl.contains("https://www.drhorton.com/texas/houston/houston/princeton"))propStatus =propStatus.replace(propStatus, "New Phase Coming Soon"); 
		if(comUrl.contains("/columbia/chapin/woodland-crossing"))propStatus ="New Phase Coming Soon";//Img
		if(comUrl.contains("/illinois/chicago/woodstock/sanctuary-at-bull-valley-ranch-homes"))propType=propType.replace("Single Family, Patio Homes", "Patio Homes");
		if(comUrl.contains("/arizona/phoenix/laveen-village/prior-ridge"))propStatus= propStatus.replace("Sold-out", "Temporarily Sold Out");
		add[0]=add[0].replace("Carleton Place 1204", "Carleton Place").replace("W Cross Ave & W - Ave", "W Cross Ave & W Tulare Ave").replace("3120 Evermore North Blvd I Hwy 78 At Evermore North Blvd", "3120 Evermore North Blvd").replace(" Durham, Nc 27703", "").replace("Glenncrest Lanenw", "Glenncrest Lane NW");
		if(comUrl.contains("sutton-fields---express-homes"))propStatus= "Final Opportunities, "+propStatus;
		if(comUrl.contains("fishers/overlook-at-white-river"))propStatus=propStatus.replace("Final Opportunities", "Sold Out");
		if(comUrl.contains("dallas/celina/chalk-hill"))propStatus= propStatus.replace("Final Opportunities, Closing Out", "New Phase Coming Late 2022");
		if(comUrl.contains("forney/travis-ranch-marina"))propStatus= propStatus.replace("Closing Out", "New Phase Coming Mid-2022, Coming Soon");
		if(comUrl.contains("https://www.drhorton.com/north-carolina/raleigh---durham/hillsborough/collins-ridge"))propStatus= propStatus.replace("Coming Early 2022, New Phase Coming Soon", "New Phase Coming Early 2022");
		if(comUrl.contains("pennsylvania/allentown/devonshire") || comUrl.contains("savannah/the-pines-at-new-hampstead"))propStatus= propStatus.replace("Coming Soon, ","");
		if(comUrl.contains("https://www.drhorton.com/georgia/atlanta/senoia/heritage-pointe-classic"))propStatus= propStatus.replace("New Phase Coming Soon", "New Phase Coming 2022");
		if(comUrl.contains("https://www.drhorton.com/texas/fort-worth/fort-worth/trails-of-elizabeth-cree"))propStatus ="Coming Soon, Phase 8 Sold Out, New phase coming soon";
		if(comUrl.equals("https://www.drhorton.com/illinois/chicago/wonder-lake/stonewater"))propStatus="Quick Move In Homes, Now Open, Now Selling";
		propStatus=propStatus.replace("Coming Fall 2021, New Phase Coming Soon", "Coming Fall 2021").replace("Sold-out", "Sold Out")
				//.replace("New Phase Opening Summer 2022, New Phase Coming Soon", "New Phase Opening Summer 2022")
//				.replace("New Phase Coming Summer 2022, New Phase Coming Soon", "New Phase Coming Summer 2022")
				.replace("New Phase Coming Fall-late 2021, New Phase Coming Soon", "New Phase Coming Fall-late 2021")
				.replace("Coming Winter 2021, Coming Soon", "Coming Winter 2021").replace("New Phase Coming Soon, New Phase Coming Winter 2021", "New Phase Coming Winter 2021")
				.replace("Now Open And Selling, ", "")
				.replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon");
		if(propStatus.contains("Only Two Homes Left,") && propStatus.contains(", Two Homes Remain"))
			propStatus = propStatus.replaceAll(", Two Homes Remain", "");
		if(propStatus.contains("Final Close Out,") && propStatus.contains(", Sold Out"))
			propStatus = propStatus.replaceAll("Final Close Out,", "");
		propStatus = propStatus.replaceAll("Coming Soon, Coming Soon", "Coming Soon");
		
		propStatus = propStatus.replaceAll("New Phase Coming Soon, New Phase", "New Phase Coming Soon")
				.replace("New Phase Coming Winter 2022, New Phase", "New Phase Coming Winter 2022")
				.replace("New Phase Now Open, Now Open,", "New Phase Now Open,")
				.replaceAll("Now Available, Final Opportunities", "Final Opportunities Now Available");
		if(propStatus.equals("Coming Soon, New Phase Coming Soon"))
			propStatus = propStatus.replaceAll("Coming Soon, New Phase Coming Soon", "New Phase Coming Soon");
			
		if(propStatus.contains("Final Phase,") && propStatus.contains("50% Sold Out Of Final Phase")) propStatus=propStatus.replace("Final Phase, ", "");
		if(propStatus.contains("Coming Early 2022, Coming 2022"))
			propStatus = propStatus.replaceAll(", Coming 2022", "");
		
		//================================================================================================================================================================
		data.addCommunity(commName.replaceAll("D.R.Horton|-Anna|Townhomes And Duplexes|Cottages$|Luxury Homes ", ""), comUrl, commType);
		data.addAddress(add[0].replace("9 Autumn Ln", "Autumn Ln").replace("Surveyor Avenue Ne", "Surveyor Avenue NE").replace("&nbsp;", " ").trim(), StringUtils.capitalize(add[1].toLowerCase()), add[2], add[3]);			
		data.addLatitudeLongitude(Latlon[0], Latlon[1], geo);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);			
		data.addPropertyType(propType, dPropType);
		data.addPropertyStatus(propStatus.replace("New Phase Opening Summer 2021, New Phase Coming Soon", "New Phase Opening Summer 2021").replace("New Phase Coming Soon, New Phase Coming Fall 2021", "New Phase Coming Fall 2021").replace("New Phase New Phase Coming Summer 2021", "New Phase Coming Summer 2021").replace("New Phase Now Selling, Now Selling", "New Phase Now Selling").replace("New Phase Coming Soon, New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon").replace("Ii", "II"));
		data.addNotes(note);
		}
		count++;
		
		
		
	//}catch (Exception e) {}
		

	}
private static String correctData(String comSecs) {
	ArrayList<String>pricess=Util.matchAll(comSecs, "\"fpricemin51359\":\\d{3}\\.\\d,", 0);
	for (String pric : pricess) {
		comSecs=comSecs.replace(pric, pric.replace(".0", ",000").replace("fpricemin51359\"", "fpricemin\""));
	}
//	ArrayList<String>sqfts=Util.matchAll(comSecs, "\"fsqftmaz120x51359\":\\d{3,4}\\.\\d,|\"fsqftmin51359\":\\d{3,4}\\.\\d", 0);
//	for (String sqft : sqfts) {
//		//comSecs=comSecs.replace(sqft, sqft.replace(".0", "").replace("fsqftmaz120x51359\"", "fsqftmaz\"").replace("fsqftmin51359\"", "fsqftmin\""));
////		U.log(sqft);
//	}
	return comSecs;
}
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//U.log("MMMMMMMMMM"+fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/70.0.3538.77 Chrome/70.0.3538.77 Safari/537.36");
	        connection.setRequestProperty("cookie", "SC_ANALYTICS_GLOBAL_COOKIE=d2a3df9a9a40499ca9fc0bdca2a2d6f4|True; visitor=7940a4f1-3072-4b59-86b0-307daeb35064; coveo_visitorId=7940a4f1-3072-4b59-86b0-307daeb35064; _gcl_au=1.1.1629283570.1594566895; _ga=GA1.2.643240240.1594566896; _fbp=fb.1.1594566901476.1799223876; com.silverpop.iMAWebCookie=5c601a83-940e-7c47-6a42-42a3bb195c85; ASP.NET_SessionId=qpleekg5l11iqnou4z1mwwo4; __RequestVerificationToken=jO2Qxe2pdYrdgjut8TCD3tmpDo3pCR4zMdfA_hjA4Dv1gpalBy9YHl78_Y9Z6qra0IrQHr4Gjq-afF5BxgF51fr0zQG2ExnhiaUe4N1XQ2Q_6Q--BY6B7FfAPrR_KZcr1CwiNOC0tl7tJHgIWRF6nw2; _gid=GA1.2.718453826.1594725336; _evidon_consent_cookie={\"consent_date\":\"2020-07-14T11:15:46.137Z\",\"consent_type\":1}");
	        connection.setRequestProperty("Accept", "*/*");
//	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
//	        connection.setRequestProperty("Content-Length", "1312");
//	        connection.setRequestProperty("Accept", "*/*");
//	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=\"UTF-8\"");
//	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=\"UTF-8\"");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	    	try {
	            throw new RuntimeException(e.getMessage());
	    	}
	    	catch(RuntimeException re) {}
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName.replace(".txt", "ForCount.txt");

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
		}
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(3000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
}
