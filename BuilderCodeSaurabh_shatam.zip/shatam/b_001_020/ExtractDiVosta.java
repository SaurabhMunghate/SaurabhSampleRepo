/**
 * @author Upendra Singg
 * @date 19/04/2018
 */
package com.shatam.b_001_020;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
//import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractDiVosta extends AbstractScrapper {

	static String BUILDER_NAME = "Pulte Group - DiVosta Homes";
	public int i = 0;
	static int count = 0;
	public int inr = 0;
	public int dup = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	String status;
	List comData = new ArrayList<>();
	//private static LatencyCounter LATENCY = null;
	static String Builder_Url = "https://www.divosta.com";

	public ExtractDiVosta() throws Exception {
		super(BUILDER_NAME, "https://www.divosta.com/");
		LOGGER = new CommunityLogger("Pulte Group - DiVosta Homes");
	}

	public static void main(String[] args) throws Exception {
		
		
		/*LATENCY = new LatencyCounter();
		 * 
		LATENCY.start("Time");*/
		AbstractScrapper a = new ExtractDiVosta();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Pulte Group - DiVosta Homes.csv", a.data().printAll());
		U.log("count==" + count);
		/*LATENCY.end("Time");
		U.log(LATENCY);*/
	}

	public void innerProcess() throws Exception {

		String MainHtml = U.getHTML(Builder_Url);

		String regionState = U.getSectionValue(MainHtml, "<select class=\"form-control State\"", "</select>");
//		 U.log(regionState);
		String[] state = U.getValues(regionState.replaceAll("<option value=\"\">", ""), "<option value=\"", "\">");
		for (String string : state) {
			//if(string.contains("<option value=\"\">"))continue;
			U.log("string ::::::: "+string);
			String stateHtml = U.getHTML(
					Builder_Url+"/api/marker/mapmarkers?brand=DiVosta&state=" + string + "&qmi=false");
			String stateData = U.getHTML(Builder_Url+"/API/community/Search?qmi=false&brand=DiVosta&state="
					+ string + "&productType=community&pageSize=99&pageNumber=0&flag=state&data=" + string);
			String[] comdata1 = U.getValues(stateData, "<hr class=\"visible-xs\" />", "<hr class=\"visible-xs\">");
			String[] comdata = U.getValues(stateHtml, "{\"Id\":", "\"exact\"");
			// U.log(comdata.length);
			// U.log(comdata1.length);
			for (int i = 0; i < comdata.length; i++) {
				comData.add(comdata1[i] + comdata[i]);
			}
		}
		U.log(comData.size());
		Iterator<String> ite = comData.iterator();
		while (ite.hasNext()) {
			String data = ite.next();
			String url = Builder_Url + U.getSectionValue(data, "<a href=\"", "\"");
			addDetails(data, url);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comSec, String comUrl) throws Exception {
//	if (j >=5 && j<=8)
//		if (j >8 && j<=10)
//			if (j >20 )
		
		//TODO:
		{
//			if(!comUrl.contains("https://www.divosta.com/homes/florida/palm-beach/lake-worth/the-fields-209699"))return;
//			if(!comUrl.contains("https://www.divosta.com/homes/florida/treasure-coast/port-st-lucie/veranda-gardens-209291"))return;
//			if(!comUrl.contains("https://www.divosta.com/homes/florida/treasure-coast/vero-beach/lakes-at-waterway-village-209612"))return;

			
			
			
			U.log("count:::::" + j + "\ncomUrl::" + comUrl);
			//U.log("Path::" + U.getCache(comUrl));
			String comHtml = U.getHTML(comUrl);
			String dabout=ALLOW_BLANK;

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.pulte.com"))) {
				LOGGER.AddCommunityUrl("*****************PulteHomes**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.delwebb.com/"))) {
				LOGGER.AddCommunityUrl("*****************DelWebbHomes**************" + comUrl);
				dup++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			//U.log(comSec);

			// ======================================= remove
			// Sec==================================
			String statusSec = U.getSectionValue(comHtml, "<h4 class=\"CommunityHero__status\"", "</h4>");
			String rem = U.getSectionValue(comHtml, "nearbyMarkers =", "</script>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "community-name\">", "<");
			U.log("Com Name::::::::" + comName);
			if(comName ==null) {
				comName = U.getSectionValue(comSec, "community-name|DiVosta\">", "<");
				U.log("Com Name::::::::" + comName);
			}

			
			String lotCount=ALLOW_BLANK;
			int lottotal=0;
			if(comHtml.contains("Homesite Map")) {
				String lotpart="";
				lotpart=U.getSectionValue(comHtml, "https://apps.alpha-vision.com/alphamap/index.html?OLAId=", "\"");
				if(lotpart != null)	lotpart = lotpart.replace("&amp;languageId=1", "").replace("&amp;languageId=", "");
				if(lotpart==null)
				lotpart=U.getSectionValue(comHtml, "http://vps1.alpha-vision.com/ola/nexGenOLA.html?OLAId=","&amp");	
				U.log("lotpart :"+lotpart);
				if(lotpart != null)	lotpart = lotpart.replace("&amp;languageId=1", "");
				lotpart=URLEncoder.encode(lotpart, "UTF-8");
				String lotUrl="https://apps.alpha-vision.com/olajson/"+lotpart.trim()+".json";		
				if(lotUrl.contains("+"))
				{
					lotUrl=lotUrl.replace("+","");
				}
				U.log("lotUrl :"+lotUrl);
				String lothtml=U.getPageSource(lotUrl);
//				U.log("lothtml "+lothtml);
				FileUtil.writeAllText("/home/shatam-100/Cache/Data.txt", lothtml);
				String[]lotCounts=U.getValues(lothtml, "\"LotCount\":", ",\"");
				U.log("lotCounts :"+lotCounts.length);
				for(String lot:lotCounts) {
					U.log("lot==="+lot);
					lottotal +=Integer.parseInt(lot);
				}
				U.log("lottotal :"+lottotal);
				lotCount=Integer.toString(lottotal);
				if(lotCount.equals("0")) {
					String guiIDUrl="https://services.alpha-vision.com/api/apiola/IsAlphamapActive?olaId="+lotpart.trim();
					U.log("guiIDUrl :"+guiIDUrl);
					String guiIDHtml=U.getPageSource(guiIDUrl);
//					U.log("guiIDHtml :"+guiIDHtml);
					U.log("guiIDUrl....."+U.getCache(guiIDUrl));
					String guiID=U.getSectionValue(guiIDHtml, "\"GUID\":\"", "\",");
					U.log("guiID :"+guiID);
					if(guiID==null) {
						guiID=U.getSectionValue(guiIDHtml, "<GUID>", "</GUID>").trim();
					}
					lotUrl="https://apps.alpha-vision.com/olajson/"+guiID+".json";
					U.log("lotUrl >>"+lotUrl);
					lothtml=U.getPageSource(lotUrl);
					U.log("guiIDUrl....."+U.getCache(lotUrl));
//					U.log("MMM=="+Util.match(lothtml,"LotCount"));

					lotCounts=U.getValues(lothtml, "\"LotCount\":", ",\"");
					U.log("lotCounts :"+lotCounts.length);
					for(String lot:lotCounts) {
						U.log(lot);
						lottotal +=Integer.parseInt(lot);
					}
					U.log("lottotal :"+lottotal);
					lotCount=Integer.toString(lottotal);
				}
			}
			
			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			add[0] = U.getSectionValue(comSec, "Street1\":\"", "\"").replace("Off Oil Well Rd. 2 Miles from Immokalee Rd.", "Oil Well Road").replace("0.2 Miles East from US-1 on Bridge Boulevard", "Bridge Boulevard");
			U.log("????????   Street1  "+add[0]);
			if(add[0].contains("9 miles west of I-95, at the intersection of North"))add[0]=add[0].replace("9 miles west of I-95, at the intersection of North", "9 miles west of I-95");
//			if(add[0].contains("Off Oil Well Rd 2 Miles From Immokalee Rd")) add[0]=add[0].replace("Off Oil Well Rd 2 Miles From Immokalee Rd", "Oil Well Road");
			add[1] = U.getSectionValue(comSec, "City\":\"", "\"");
			add[2] = U.getSectionValue(comSec, "State\":\"", "\"");
			add[3] = U.getSectionValue(comSec, "ZipCode\":\"", "\"");
			add[0]=add[0].replace("Off US 441, ", "").replace("9 miles west of I-95, ", "");
			U.log(add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latlong[0] = U.getSectionValue(comSec, "Latitude\":\"", "\"");
			latlong[1] = U.getSectionValue(comSec, "Longitude\":\"", "\"");

			if (add[0] == null && latlong[0] != null) {

				add = U.getAddressGoogleApi(latlong);
				if(add == null) add = U.getGoogleAddressWithKey(latlong);
				geo = "TRUE";
			}
			if (add[0] != null && latlong[0] == null) {

				latlong = U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getGoogleLatLngWithKey(add);
				geo = "TRUE";
			}
			// ==============================================================Price &&
			// SF============================================

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comHtml = comHtml.replaceAll(" sales price of \\$500,000, loan amount of \\$400,000 with a 20% down payment", "").replaceAll("$800,000 category.</p>|no-empty-collapse stat-line\">\\s*\\$\\d+,\\d+|700,000 category|in the Single Family Homes \\$600,001-\\$700,000 category|standard cost of \\$\\d{3},\\d{3}|Save up to \\$50,000|\\$100,000 and \\$50,000&nbsp", "");
			comSec = comSec.replaceAll("0s|0S|0's|0&#39;s", "0,000").replace("700,000 category.", "");
			comHtml = comHtml.replaceAll("0s|0S|0's|0&#39;s", "0,000").replace("low $300 to $700,000", "low $300,000 to $700,000").replace("Low $1.1M&#39;s", "$1,100,000");
			//U.log("=="+comHtml);
			comHtml=comHtml.replace("Single Family Homes $700,001-$800,000 category.</p>", "").replace("ComingPriceRange\":\"$300,000", "").replace("400,000", "");
			comSec = comSec.replace("ComingPriceRange\":\"$300\\u0027s", "").replace("400,000", "");
//			U.log("MMM"+Util.match(comHtml + comSec,"$540,990"));
			String[] prices = U.getPrices(comHtml + comSec, "\\$\\d+,\\d+\n\\s*</div>\n\\s*<div class=\"CommunityHero__startingAtLabel\">Starting At</div>|\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
			
			
			//U.log("<<<<"+Util.matchAll(comSec+comHtml, "[\\w\\s\\W]{30}\\$\\d{3},\\d{3}[\\w\\s\\W]{30}",0));
//			U.log("comSec   "+comSec);
			
			
			//if(comUrl.contains("/beachwalk-by-manasota-key-210435"))prices[0]="$333,990";
			//if(comUrl.contains("https://www.divosta.com/homes/florida/treasure-coast/port-st-lucie/veranda-gardens-209291"))prices[0]="$387,990";

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
            
			
			
			String[] sqft = U.getSqareFeet(comHtml.replace("Clubhouse with 11,000+ Square Feet Under Roof", ""),
					"\\d,\\d{3}\n*\\s*\n*\\s*</div>\n*\\s*<div class=\"data-label\">Sq|\\d,\\d{3} � \\d,\\d{3} square feet|\\d,\\d{3}– \\d,\\d{3} sq. ft.|<div class=\"td\">\\d,\\d{3}</div>|from \\d,\\d{3}–\\d,\\d{3} sq.ft.|\\d{1},\\d{3} to more than \\d{1},\\d{3} Sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} Sq.Ft.|\\d{4}-\\d{4} SF|\\d{1},\\d{3}–\\d{1},\\d{3} sq. ft.|<h4>\\d{1},\\d{3}</h4>|<h4>\\d{3,4}</h4>|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}\\+ Square Feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+\\+ sq. ft.|\\d,\\d+ to \\d,\\d+\\+ square feet|\\d,\\d+-\\d,\\d+\\+ Sq. Ft.|\\d+ - \\d+\\+ Square Feet|\\d,\\d+-\\d,\\d+\\+Square Feet|\\d,\\d+-\\d,\\d+\\+Sq. Ft.|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+\\+ Sq. Ft.|\\d{1},\\d{3} Square Feet|\\d,\\d+-\\d,\\d+ S.F.|\\d{4}-\\d{4} sq ft|From \\d{1},\\d{3} sq. ft|<h4>\\s*\\d,\\d{3}\\+*\\s*</h4>|ranging from \\d,\\d{3}-\\d,\\d{3} sq ft|homesite, at least \\d+,\\d{3} sf",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);

			// ==============================================================Community
			// type============================================
			String floorplandesc=ALLOW_BLANK;
			String designurl[]=U.getValues(comHtml,"<div class=\"HomeDesignCompact__title\">","</div>");
			String ddesc=null;
			for(String du:designurl) {
				String durl="https://www.divosta.com/"+U.getSectionValue(du,"<h2><a href=\"","\"");
				
//				U.log("durl: "+durl);
				dabout=U.getHTML(durl);
				if(dabout!=null) {
				floorplandesc += U.getSectionValue(dabout, "data-description=\"", "\"");
				//U.log("---"+floorplandesc);
				ddesc=ddesc+U.getSectionValue(dabout,"data-description=\"","\"").replaceAll("luxurious", "");
				//U.log(ddesc);
				}
			}
			
			String footerSec  = U.getSectionValue(comHtml, "<div class=\"Disclaimer container-fluid\">", "</script>");
			if(footerSec != null)
				comHtml = comHtml.replace(footerSec, "");
			

			String communityAbout = U.getSectionValue(comHtml, " <div class=\"CommunityHero__about\">", "  </div>");
			comHtml=comHtml.replaceAll("/resort-style-living\"|<div class=\"StatusTag\">Last Chance</div>|gated natural gas|<div class=\"StatusTag\">Sold Out</div>|<p>Temporarily Sold Out</p>|data-automation=\"\">Sold Out</div>", ""); //|Gated Natural Gas
			//U.log(Util.matchAll(comSec + comHtml+communityAbout, "[\\w\\s\\W]{30}sold[\\w\\s\\W]{30}",0));
			comHtml = comHtml.replaceAll("categoryLinkName pb-3\">Resort Lifestyle</a>|class=\"GlobalNav-v2-categoryLinkName\">Resort Lifestyle</a>", "");
//			U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}Resort style[\\w\\s\\W]{30}",0));
			comHtml=U.removeSectionValue(comHtml, "<section id=\"HomeSummaryGlance\"", "data-analytics-zone=\"Area Details\">");

			comHtml = U.getNoHtml(comHtml);
			String comType = ALLOW_BLANK;

			comHtml = comHtml.replace("Lake &amp; Wetland Homesite Views", " lakeside living &amp; Wetland Homesite Views")
					.replaceAll("single-family new homes for sale offer lake and preserve views", "single-family new homes for sale offer <li>Lakefront Views</li> and preserve views")
					.replace("entry plus lake and", " lakeside community")
					.replace("Gated Natural Gas Community with Ap", "with approximately 97");
			
			comType = U.getCommType((comHtml + comSec).replaceAll("Heron Creek Golf and Country Club|Poinciana Golf Club|PGA National Golf and Country Club|The Jupiter Country Club|Oak Ford Golf Club|round of golf at|Golf Rd|golfing|golf cart storage|Lakefront Event Lawn|shot for Pulte 55 active adult\"|Pulte Homes&#174; Active Adult|renowned beaches and golf courses|golf cart garage", "").replaceAll("golf cart garage", "").replace("participation", "").replaceAll("golf cart garage", ""));
			U.log("comType ==== "+comType);
			//U.log(":::::::::::::::::::"+Util.matchAll((comHtml + comSec).replaceAll("golfing|golf cart storage|Lakefront Event Lawn|shot for Pulte 55 active adult\"|Pulte Homes&#174; Active Adult|renowned beaches and golf courses|golf cart garage", "").replaceAll("golf cart garage", "").replace("participation", "").replaceAll("golf cart garage", ""), "[\\s\\w\\W]{50}golf[\\s\\w\\W]{30}",0));
			// ==============================================================Property
			// type============================================
			
			comHtml = comHtml.replaceAll("detached \\d-car garage|Ranch Trail|/Lakewood-Ranch|Branch|at Lakewood Ranch|Lakewood Ranch|Park at Lakewood Ranch|lakewood-ranch|palmer-ranch|LakewoodRanch|Palmer Ranch|Lakewood Ranch Medical Center|participation|on Palmer Ranch,| Mallory Park at Lakewood Ranch|DelWebbLakewoodRanch|luxurious owner's suite|luxury maple cabinets", "")
					.replace("coastal-inspired new home", "coastal style homes").replace("luxurious new construction", "luxurious");
			comSec=comSec.replaceAll("palmer-ranch|Palmer Ranch|Lakewood Ranch Medical Center|Park at Lakewood Ranch|lakewood-ranch|Lakewood Ranch|LakewoodRanch|luxurious owner's suite|luxury maple cabinets|luxurious", "");
			
			String propType = ALLOW_BLANK;

			propType = U.getNewPropType((comHtml + comSec+ddesc).replace("upstairs loft", "")
					.replace("in the loft", "").replace("Luxurious owner&#39", "")
					.replace("patio space|patio option", ""));
			
			
//			U.log(">>>>>>>>>>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}hoa[\\w\\s\\W]{30}",0));
			U.log("propType: "+propType);
			// ==============================================================Property
			//  d-type============================================
			String dType = ALLOW_BLANK;
			comHtml=comHtml.replaceAll("Lakewood-Ranch", "");
			if(dabout!=null)
			dabout=dabout.replaceAll("Lakewood Ranch|Palmer Ranch", "");
			dType = U.getNewdCommType((comHtml + ddesc+comSec+dabout+floorplandesc).replaceAll("Lakewood Ranch|/Lakewood-Ranch|Branch|(Palmer|Taylor) Ranch|-ranch-", "")+comName);
			//dType = U.getNewdCommType((dabout).replace("Lakewood Ranch", ""));
//			U.log("KKKKKKK"+Util.matchAll(comHtml + ddesc+comSec+dabout+floorplandesc , "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}",0));
//			U.log("KKKKKKK"+Util.matchAll(comSec, "[\\w\\s\\W]{30}Ranch[\\w\\s\\W]{30}",0));
//			U.log("KKKKKKK"+Util.matchAll(dabout, "[\\w\\s\\W]{30}Ranch[\\w\\s\\W]{30}",0));
//			U.log("KKKKKKK"+Util.matchAll(floorplandesc, "[\\w\\s\\W]{30}Ranch[\\w\\s\\W]{30}",0));

			
			U.log("dtype: "+dType);

			// ==============================================================Property
			// Status============================================
			if(comUrl.contains("/hammock-preserve-on-palmer-ranch-209606")) {
			comSec = comSec.replace("</span> Home Designs Available", " Home Designs Available").replaceAll("\"CommunityStatus\":\"Coming Soon\",\"D|Price Coming Soon", "");
//			comSec = comSec.replaceAll("100 Homes Remaining|100 Homes Remain", "");
			comHtml = comHtml.replaceAll(" Coming Soon |COMING SOON! Phase 2 |\"CommunityStatus\":\"Coming Soon\",\"D|Price Coming Soon|Second Amenity Coming Soon!|Coming soon to Sarasota|Limited opportunity to select finishes|<div class=\"StatusTag\">Last Chance</div>|data-automation=\"\">Sold Out</div>|Coming Soon: Phase|<div class=\"StatusTag\">Sold Out</div>|100 homes remaining|coming Fall 2019 featuring|all homes sold|<p>Temporarily Sold Out</p>|Clubhouse- Now Open|Quick Move|quick move|Center Grand Opening|41 coming Fall 2019 featuing a Publix|(Courts|expansion|Marketplace) (c|C)oming| Amenity Center Grand Opening Event|grand opening of our new amenit| Amenity Center Now open", "");
			}else {
				comSec = comSec.replaceAll("quick move-ins|Quick Move-Ins", "")
						.replace("</span> Home Designs Available", " Home Designs Available"); //.replaceAll("\"CommunityStatus\":\"Coming Soon\",\"D|Price Coming Soon", "")
				comHtml = comHtml.replaceAll("grand opening events and more| Coming Soon |COMING SOON! Phase 2 |data-automation=\"\">Sold Out</div>|Second Amenity Coming Soon!|Coming soon to Sarasota|available in the first release|Limited opportunity to select finishes|<div class=\"StatusTag\">Last Chance</div>|Coming Soon: Phase|<div class=\"StatusTag\">Sold Out</div>|100 homes remaining|coming Fall 2019 featuring|all homes sold|<p>Temporarily Sold Out</p>|Clubhouse- Now Open|Quick Move|quick move|Center Grand Opening|41 coming Fall 2019 featuing a Publix|(Courts|expansion|Marketplace) (c|C)oming| Amenity Center Grand Opening Event|grand opening of our new amenit| Amenity Center Now open", "");
			}
			//U.log("++++++++++++++++"+comSec+"++++++++++++++++++++");
			
			String propertyStatus = U.getNewPropStatus((comSec + comHtml+communityAbout+statusSec).replace("100 Homes", "").replaceAll("We are currently selling offsite at our community|We are currently selling offsite at our Lakes at Water|We are currently selling offsite at our PulteGroup division headquarters in West Palm Beach", "").replaceAll("quick move-in|Quick Move-In|Quick move-in", ""));
//			U.log(Util.matchAll(comSec +comHtml+communityAbout, "[\\w\\s\\W]{30}quick move-in[\\w\\s\\W]{30}",0));

			//comHtml = comHtml.replace("Patio.jpg", "");
			
			U.log("propertyStatus: "+propertyStatus);
			
//			if(comName.contains("Ranch") && !dType.contains("Ranch")) {
//				if(dType.length()<4) {
//					dType ="Ranch";
//				}else {
//				dType = dType+", Ranch";
//				}
//			}
//			if(comUrl.contains("https://www.divosta.com/homes/florida/naples/naples/winding-cypress-209285")) {
//				propType+=", Loft";
//				dType ="1 Story";
//				}

			String notes = U.getnote(comHtml);
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]).trim();
			}

			if(comUrl.contains("https://www.divosta.com/homes/florida/treasure-coast/vero-beach/lakes-at-waterway-village-209612")) {
				propertyStatus="Sold Out";
				
			}
			
			add[0] = add[0].replace("Off Indiantown Rd, 2 miles north on Island Way", "Off Indiantown Rd").replace("3.5 Miles South of US-41,", "");
//			if(comUrl.contains("https://www.divosta.com/homes/florida/palm-beach/palm-beach-gardens/avondale-at-avenir-210634")) {
////				add[0]="Coconut Blvd";
//			geo="TRUE";
//			}
//			String lotCount=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDT=ALLOW_BLANK;	
			
			
			//======================================================
//			if(comUrl.contains("https://www.divosta.com/homes/florida/palm-beach/palm-beach-gardens/avondale-at-avenir-210634")) dType = "1 Story, 2 Story";
//			if(comUrl.contains("https://www.divosta.com/homes/florida/treasure-coast/vero-beach/harbor-isle-210851")) propType = "Flex Homes, Single Family, Coastal Homes";
//			if(comUrl.contains("https://www.divosta.com/homes/florida/palm-beach/jupiter/sonoma-isles-209518")) propType = "Flex Homes, Single Family, Loft";
//			if(comUrl.contains("https://www.divosta.com/homes/florida/treasure-coast/vero-beach/lakes-at-waterway-village-209612")) propType = "Flex Homes, Single Family, Villas, Mediterranean Style Home";

			//======================================================
			
			
			
			
			
			add[0] = add[0].replace("4894 Overton Cir, Vero Beach, FL 32967", "4894 Overton Cir");
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(notes);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(startDt,endDT);
		}
		j++;
	}

}

