/*
 * Author:Rakesh
 * date:09/29/2015
 */
package com.shatam.b_001_020;

import java.sql.Connection;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import sqliteTest.testSqlite;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
//import org.openqa.selenium.browserlaunchers.locators.Firefox2Locator;

public class ExtractPhillipsBuilder extends AbstractScrapper {

	public static String HOME_URL = "http://www.thephillipsbuilders.com";

	static String BUILDER_NAME = "Meritage Homes - Phillips Builders";
	CommunityLogger LOGGER;
	Connection con;
	static int j=0;
	WebDriver driver = new FirefoxDriver();

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractPhillipsBuilder();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Meritage Homes - Phillips Builders.csv", a.data()
						.printAll());
	}

	public ExtractPhillipsBuilder() throws Exception {

		super("Meritage Homes - Phillips Builders",
				"http://www.thephillipsbuilders.com");
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	@Override
	protected void innerProcess() throws Exception {
		con = testSqlite.ConnectDatabase();
		String html = U
				.getHtml(
						"http://www.thephillipsbuilders.com/search/nashville-tn#.VZvJu_mqqko",
						driver);
		// U.log(html);
		String sec = U.getSectionValue(html, "Our Communities",
				"<li id=\"nav-about\">");
		String commLinks[] = U.getValues(sec, "href=\"", "/\">");// http://www.thephillipsbuilders.com/search/nashville-tn/copper-creek-55s/#.VTn1FVWqpBc
		for (String commLink : commLinks) {
			U.log("=====" + commLink);
			// commLink=commLink.replace("=\"", "");
			commLink = "http://www.thephillipsbuilders.com" + commLink;
//			U.log("__________________" + commLink);
			addDetails(commLink);
		}
		
		//addDetails("http://www.thephillipsbuilders.com/search/nashville-tn/The-Park-at-Bridgemore-Village");
		driver.quit();
		LOGGER.DisposeLogger();
		testSqlite.closeconnectionconn(con);
      
	}

	private void addDetails(String commUrl) throws Exception {
		
		//if(j==13)
		{

		// ==================Community Name=================
		U.log(commUrl);
	//	if(!commUrl.contains("http://www.thephillipsbuilders.com/search/nashville-tn/bent-creek"))return;
		String commHtml = U.getPageSource(commUrl);
		// U.log(commHtml);
		String commHtmlSec = U.getSectionValue(commHtml,
				"<div class=\"community-info\">",
				"COMMUNITY, PLAN NAME, PURCHASE PRICE:");
		
		// ====================Address======================

		String addSec1 = U.getSectionValue(commHtmlSec,
				"<div id=\"live-work-play-map\" ", "<p><span");
		String addSec = ALLOW_BLANK;

		U.log("???????????????????" + addSec1);
		if (addSec1 == null) {
			getDetails(commUrl);
		} else {

			addSec = U.getSectionValue(addSec1, "<p", "/p>");
			String commName = U.getSectionValue(addSec1, "<h2>", "</h2>");
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			addSec = addSec.replace("<br>", ",").replace("TN", "TN,")
					.replaceAll("\\s+", " ").trim()
					.replace("By Appointment Only", "");
			U.log("Comm_Url : " + commUrl);
			U.log("Comm_Name : " + commName);
			U.log("Complete_Add : " + addSec);
			String addr[] = addSec.split(",");
			if (addr.length >= 3) {
				add[0] = addr[0];
				add[1] = addr[1];
				add[2] = addr[2];

				if (addSec.endsWith(","))
					add[3] = ALLOW_BLANK;
				else
					add[3] = addr[3];
			}

			add[3] = add[3].replace("<", "");
			add[0] = add[0].replace(">", "");
			U.log("Street : " + add[0] + "    City : " + add[1]
					+ "      State : " + add[2] + "     Zip : " + add[3]);

			// ================Latitude & Longitude==============
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;
			String latLng[] = null;

			latLng = testSqlite.findlatitudelongitude(con, add);
			lat = (latLng[0] != null) ? latLng[0] : ALLOW_BLANK;
			geo = "FALSE";
			lng = (latLng[1] != null) ? latLng[1] : ALLOW_BLANK;

			U.log("Latitude : " + lat + "       Longitude : " + lng);

			// ========== Community and Property Type============
			String propType = ALLOW_BLANK, commType = ALLOW_BLANK;
			commHtmlSec = commHtmlSec.replaceAll("includes the HOA at| Creek Townhomes</option>|and HOA fees are subject| luxurious bathroom", "");
			commHtmlSec=commHtmlSec.replace("townhomes on the golf course in", "");
			commType = U.getCommunityType(commHtmlSec.replace("resort-style pool", ""));
			
			propType = U.getPropType(commHtmlSec.replaceAll("New single family homes|Village|village|HOA|clubhouse patio", ""));
			U.log("Comm_Type : " + commType);
			U.log("Prop_Type : " + propType);
			
			// =========Property & Derived Property Status=======
			String propStatus = ALLOW_BLANK, derPropStatus = ALLOW_BLANK;
			String remove = "Price Range: Coming Soon!";
			
			propStatus = U.getPropStatus(commHtmlSec.replace(remove, ""));
			derPropStatus = U.getdCommType(commHtmlSec);
			
			U.log("Prop_Status : " + propStatus);
			U.log("Der_Prop_Status : " + derPropStatus);

			String priceSec = U.getSectionValue(commHtml, "</head>",
					"id=\"footer\">");

			// ======================Price========================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			commHtmlSec = commHtmlSec.replaceAll("0�s|0's", "0,000");
		
			String Price[] = U.getPrices(priceSec,
					"low \\$\\d+,\\d+|From \\$\\d+,\\d+|\\$\\d+,\\d+", 0);
			minPrice = (Price[0] == null) ? ALLOW_BLANK : Price[0];
			maxPrice = (Price[1] == null) ? ALLOW_BLANK : Price[1];
			U.log("MinPrice : " + minPrice + "         MaxPrice : " + maxPrice);

			// ====================Square Feet=====================2,600</span>
		//	 U.log("My Section: " +priceSec);
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String sqFt[] = U
					.getSqareFeet(
							commHtml,
							"\\d,\\d+ sq. ft.| ranging from \\d,\\d+ - \\d,\\d+ sq. ft.,",
							0);
			minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			U.log("MinSqf : " + minSqf + "      MaxSqf : " + maxSqf);

			String noteVar = ALLOW_BLANK;

			U.log("aaa" + add[3]);
			//Replace not required symbol in Address.
			add[0] = add[0].replace(": ", "");
			add[0] = add[0].replace("Coming Soon", "");
			U.log("==================================================================================");
			if (add[3] == ALLOW_BLANK && lat != ALLOW_BLANK) {
				String addrs[] = testSqlite.findaddress(con, latLng);

				add[3] = addrs[3];
			}
			if(add[0].length()<2){
				//if(add[0]==ALLOW_BLANK && lat!=ALLOW_BLANK){
					add = U.getAddressGoogleApi(new String[]{lat,lng});
					geo= "TRUE"; 
				//}
			}
			
		

			if (add[0].length() < 4) {

				String[] adde = testSqlite.findaddress(con, latLng);
				add[0] = adde[0];
				U.log("sss" + add[0]);
				geo = "TRUE";

			}

			
			
			
			LOGGER.AddCommunityUrl(commUrl);
			data.addCommunity(commName, commUrl, commType);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(propType, derPropStatus);

			data.addPropertyStatus(propStatus);
			data.addNotes(noteVar);
		}
		}j++;
	}

	private void getDetails(String commUrl) throws Exception {
		U.log("Priti::"+commUrl);
		//if(!commUrl.contains("http://www.thephillipsbuilders.com/search/nashville-tn/copper-creek-70s"))return;
		String commHtml = U.getPageSource(commUrl);
		String commName = U.getSectionValue(commHtml,
				"<h1 class=\"tk-crimson-ss\">", "</h1>");
		String addSec1 = U.getSectionValue(commHtml, "Sales Center", "</p>");
		addSec1=addSec1.replace("<br/>", ",").replace("</h5>", "").replace("<p>", "");
		U.log("addSec1"+addSec1);
		String addr[] = addSec1.split(",");
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		add[0]=addr[0];
		add[1] = addr[1];

		add[2] = Util.match(addr[2], "\\w{2}");
		add[3] = Util.match(addr[2], "\\d{5}");

		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;
		String latLn = U
				.getSectionValue(commHtml, ".maps.LatLng(", ")");
		String[] latLng = latLn.split(",");

		lat = (latLng[0] != null) ? latLng[0] : ALLOW_BLANK;
		geo = "FALSE";
		lng = (latLng[1] != null) ? latLng[1] : ALLOW_BLANK;
		lat = lat.trim();
		lng = lng.trim();
		U.log("Street::"+add[0]+"lat"+lat+"::lng::"+lng);
		
		
		
        commHtml = commHtml.replaceAll("includes the HOA at| Creek Townhomes</option>|and HOA fees are subject", "");       
		String propType = ALLOW_BLANK, commType = ALLOW_BLANK;
		commHtml=commHtml.replaceAll("luxurious bathroom|available now and|low-maintenance townhomes|Cabin Run|New single family homes |townhomes on the golf course in|luxurious master bath|Stirling Cottage|Stirling_Cottage|clubhouse patio|Bent Creek Townhomes\\W+</o", "");
		commType = U.getCommunityType(commHtml);
		//U.log("result::"+Util.match(commHtml, ".*?luxur.*?"));
		propType = U.getPropType(commHtml);
		U.log("Comm_Type : " + commType);
		U.log("Prop_Type : " + propType);
		
		// =========Property & Derived Property Status=======
		String propStatus = ALLOW_BLANK, derPropStatus = ALLOW_BLANK;
		if(commHtml.contains("http://www.thephillipsbuilders.com/search/nashville-tn/bridge-mill")){
			U.log("Hello");
			commHtml = commHtml.replaceAll("Coming soon|community are coming soon", "");
		}
		String remAddSec=U.getSectionValue(commHtml, "Get Updates", "Add to Favorites");
		commHtml = commHtml.replace(remAddSec, "");
		commHtml=commHtml.replaceAll("completion-date\">\\s+Now Available", "");
		String remove = "Model Home Now Available|New Homes Coming Soon|Quick|:description=\"NOW SELLING|Price Range: Coming Soon!|addthis:description=\"COMING WINTER 2015\"|COMING WINTER 2015|COMING FALL 2015|OPENING FALL 2015";
		propStatus = U.getPropStatus(commHtml.replaceAll(remove, ""));
		//U.log("result::"+Util.match(commHtml, ".*?Now Available.*?"));
		derPropStatus = U.getdCommType(commHtml.replace("pagerAnchorBuilder", ""));
		//No Quick Move-Ins available at this time
		
		if(commHtml.contains("No Quick Move-Ins available at this time")){
			if(propStatus.length()>2)
			{
			propStatus=propStatus+",No Quick Move-Ins available";	
			}
			else
			{
				propStatus="No Quick Move-Ins available";	
			}
		}
		else{
			if(propStatus.length()>2)
			{
			propStatus=propStatus+",Quick Move-Ins available";	
			}
			else
			{
				propStatus="Quick Move-Ins available";	
			}	
		}
		if(commUrl.contains("http://www.thephillipsbuilders.com/search/nashville-tn/the-oaks-at-burberry-glen"))propStatus=propStatus.replace("Coming Soon,", "");
		U.log("Prop_Status : " + propStatus);
		U.log("Der_Prop_Status : " + derPropStatus);

		String priceSec = U.getSectionValue(commHtml, "<head>",
				"class=\"disclaimers\">");

		// ======================Price========================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		commHtml = commHtml.replaceAll("0�s|0's", "0,000");
		String rem = U.getSectionValue(priceSec, "flexible home plans", "Build");
		if(rem!=null)priceSec = priceSec.replace(rem, "");
		//priceSec = priceSec.replace("flexible home plans from \\$\\d{3},\\d{3}", "");
		//priceSec=priceSec.replaceAll("$370,900|$269,900|\\$314,900","");
		String Price[] = U.getPrices(priceSec,
				"low \\$\\d+,\\d+|From \\$\\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (Price[0] == null) ? ALLOW_BLANK : Price[0];
		maxPrice = (Price[1] == null) ? ALLOW_BLANK : Price[1];
		U.log("MinPrice : " + minPrice + "         MaxPrice : " + maxPrice);

		// ====================Square Feet=====================2,600</span>
//		 U.log(priceSec);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String sqFt[] = U.getSqareFeet(priceSec, "\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d{1},\\d{3} - \\d{1},\\d{3} sq. ft.|\\d,\\d+ sq. ft|\\d,\\d+ sqft.", 0);
		minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("MinSqf : " + minSqf + "      MaxSqf : " + maxSqf);
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]+ " Z:" + add[3]);


	
		add[0] =add[0].replaceAll("\\s{3,}", "");
		add[0] = add[0].replace("Coming Soon", "");
		add[0]=add[0].replace("By Appointment Only", "");
		U.log("Address: " + add[0]);
		U.log("My Address Length: " + add[0].length());
		
		
		if(add[0].length()<=2){
			//if(add[0]==ALLOW_BLANK && lat!=ALLOW_BLANK){
				add = U.getAddressGoogleApi(new String[]{lat,lng});
				geo= "TRUE"; 
			//}
		}
		if(commUrl.contains("http://www.thephillipsbuilders.com/search/nashville-tn/arrington-retreat"))
		{minPrice=ALLOW_BLANK;}
		add[0] = add[0].replace(":", "").trim();
		LOGGER.AddCommunityUrl(commUrl);
		String noteVar = ALLOW_BLANK;

		data.addCommunity(commName, commUrl, commType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),
				add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(propType, derPropStatus);

		data.addPropertyStatus(propStatus);
		data.addNotes(noteVar);

	}
}
