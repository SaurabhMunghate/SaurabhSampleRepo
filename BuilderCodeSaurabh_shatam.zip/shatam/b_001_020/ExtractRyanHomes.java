package com.shatam.b_001_020;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRyanHomes extends AbstractScrapper {
	int i = 1;
	CommunityLogger LOGGER;
	static String BASE_URL = "https://www.ryanhomes.com";
	
	public ExtractRyanHomes() throws Exception {
		super("NVR - Ryan Homes", "https://www.ryanhomes.com");
		LOGGER = new CommunityLogger("NVR - Ryan Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractRyanHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "NVR - Ryan Homes.csv", a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String findHtml = U.getHTML("https://www.ryanhomes.com/find-your-home");
		String marketSec = U.getSectionValue(findHtml, "Browse New Homes By Market", "Browse New Homes By County");
		String[] values = U.getValues(marketSec, "<div class=\"find-all-search-results-copy\">", ">");
		int count = 1;
		
		for(String value:values) {
			String marketLink = U.getSectionValue(value, "<a href=\"", "\"");
			marketLink = "https://www.ryanhomes.com"+marketLink;
			//U.log("marketLink: "+marketLink);
			
			String marketHtml = U.getHTML(marketLink);
			String cardSec = U.getSectionValue(marketHtml, "Clear Filters</button>", "<div class=\"search-results-map\">");
			
			if(cardSec == null) continue;
			String[] comSection =  U.getValues(cardSec, "<div class=\"communities-near-cards\">", "<div class=\"search-results-city-state\">");
			//U.log("comm.count: "+comSection.length); 
			
			for(String com:comSection) {
				String comLink = U.getSectionValue(com, "<a href=\"", "\">");
				String url = "https://www.ryanhomes.com"+comLink;
				//U.log(count+".  comUrl: "+comUrl);
				count++;
				getUrls(url, com);
			}
		}
		LOGGER.DisposeLogger();
	}
	
	public void getUrls(String url, String com) throws Exception {
		
		if(url.contains("https://www.ryanhomes.com/new-homes/communities/10222120151838/virginia/chester/centraliastation")) {
			LOGGER.AddCommunityUrl(url+ "---------------------------------ERROR 404");
			return;
		}
			
		//================ Community Url
		String comHtml = ALLOW_BLANK;
		String comUrl = ALLOW_BLANK;
		String comSec = ALLOW_BLANK;
		
		String Html = U.getHTML(url);
		//For SubComm
//		if(url.contains("aftongreen"))
		{
//			U.log("comurl: "+url);
//			U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Communities Available[\\w\\s\\W]{30}", 0));

		if(Html.contains("Communities Available")) {
			String[] comAvailable =  U.getValues(Html, "<div class=\"search-results-price-display\">", "<img class=\"card-img-top\"");
			//U.log("comAvailable: "+comAvailable.length);
			
			for(String comAva:comAvailable) {
				String comLink = U.getSectionValue(comAva, "<a href=\"", "\">");
				
				String comurl = "https://www.ryanhomes.com"+comLink;
				//U.log("comurl: "+comurl);
				String html = U.getHTML(comurl);
				//U.log(U.getCache(comurl));
				comUrl = comurl;
				comHtml = html;
				comSec = com;
//				try {
//				U.log(" comUrl=="+comUrl);
					getDetails(comUrl, comSec, comHtml);
//				} catch (Exception e) {}
				//U.log(" ");
			}
			//LOGGER.DisposeLogger();
		}
		else {
			comHtml = Html;
			comUrl = url;
			comSec = com;
//			try {
				getDetails(comUrl, comSec, comHtml);
//			} catch (Exception e) {}
//			U.log(" comUrl=="+comUrl);
			//LOGGER.DisposeLogger();
		}
		}
	}
	
	public void getDetails(String comUrl, String comSec, String comHtml) throws Exception {
		
//SINGLE EXECUTION		
//		if(!comUrl.contains("https://www.ryanhomes.com/new-homes/communities/10222120151479/pennsylvania/lansdale/andalegreen/24")) return;
//		if(i>=45 && i<100)////count 602
//		if(i>=175 && i<200)
//			if(i>=200 && i<300)//d
//				if(i>=300 && i<400)//d
//		0-49=d    50-100=d  100-200=dd     200-300=dd     300-400=d   400-500=     500-600=     >600=d  tc 651
//			if(i>=486 && i<=500)//d
//		if(i>=441)
//			if(i>=600)
//		if(i>=37)
//		try
		{
		
//		U.log("COMSEC==="+comSec);
		
		
		if(data.communityUrlExists(comUrl)) { 
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Repeated");
			return; 
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		 
		
		U.log(""+i+" comUrl: "+comUrl);
		U.log(U.getCache(comUrl));
		//if(i>550 && i<591) {
		//if(i>550 && i<591) {
		
		//================ Community Name
		
		comHtml = comHtml.replaceAll("- 55&#x2B; Active Adult|55&#x2B; Ranch Homes|55&#x2B;|Villas 55&#x2B;|- 55 Plus|55 Plus", "")
				.replaceAll("Condo Flats Condos and Main-Level Owner&#x27;s Suite Homes for Sale|Condos Condos and Main-Level Owner&#x27;s Suite Homes for Sale|Condos and Main-Level Owner&#x27;s Suite Homes for Sale", "")
				.replaceAll("Villas Villas and Main-Level Owner&#x27;s Suite Homes for Sale|Villas and Main-Level Owner&#x27;s Suite Homes for Sale", "")
				.replaceAll("Villas - Active Adult|Villas Villas for Sale|Villas for Sale ", "").replace("Townhome Condos Condos for Sale", "").replace("2-Story Townhomes Townhomes for Sale", "")
				.replaceAll("Carriage Homes Townhomes, Villas, and Main-Level Owner&#x27;s Suite Homes for Sale|Townhomes, Villas, and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "1-Story Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "2-Level Condos Condos for Sale|, 1st Floor Owner&#x27;s Townhomes Townhomes, Villas, and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "Villas Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|- All Ages Single Family Homes Single-Family Homes for Sale|"
						+ "by Asbury Farms Urban Renewal LLC Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "Villas Townhomes, Villas, and Main-Level Owner&#x27;s Suite Homes for Sale|Townhome Villas, 1st Floor Owner&#x27;s Suites Townhomes and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "Cottages Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|Estate Homes Single-Family Homes for Sale|"
						+ "1st Floor Living Townhomes, Villas, and Main-Level Owner&#x27;s Suite Homes for Sale|Ranches Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "2-Story Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|Villas Ranches Single-Family Homes and Main-Level Owner&#x27;s Suite Homes for Sale|"
						+ "2-Story Single-Family Homes for Sale", "");
		
		comHtml = comHtml.replace("Timothy Branch Single Family Homes Single-Family Homes for Sale", "Timothy Branch");
		
		String rem_Sec=U.getSectionValue(comHtml, " <div id=\"communitiesNearby\">", "<script>");
		if(rem_Sec!=null)
		{
			comHtml = comHtml.replace(rem_Sec, "");
		}
		
		String comName = U.getSectionValue(comHtml, "<title>", "|");
		if(comName.contains("Single-Family")) {
			comName = U.getSectionValue(comHtml, "<title>", " Single-Family");
		}
		comName = comName.replaceAll("&#x2B;|for Sale|&#x27;s", "");
//		comName=comName..replaceAll("Villas  and", "")
		comName = comName.replaceAll(" \\d-Car Garage| 1st Floor Living | Twin Homes| by Haddon Point Urban Renewal II, LLC|Townhomes and Main-Level Owner Suite Homes|Villas|Townhomes|- Single Family Homes 55| Ranches  |Single Family Homes 55","").replaceAll("Rolling Hills   and ", "Rolling Hills")
				.replace("Ridgely Forest   and", "Ridgely Forest")
				.replaceAll("Greenwich Walk Condos  Condos", " Greenwich Walk")
				.replace("Emory Park Ranches", "Emory Park");
			
		U.log("comName: "+comName);
			
		//================ Address  &  latLng
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
	
		
				String llSec = U.getSectionValue(comHtml, "staticmap?center", "amp");
				latLng[0] = U.getSectionValue(llSec, "=", ",");
				latLng[1] = U.getSectionValue(llSec, ",", "&");
				

				if(latLng[0] == null) {

					
					latLng[0] = U.getSectionValue(comSec, "data-lat=\"", "\"");
					latLng[1] = U.getSectionValue(comSec, "data-lng=\"", "\"");
				}
//				U.log("LAT:"+lat+"  LNG:"+lng);
				
				U.log("LAT:"+latLng[0]+"  LNG:"+latLng[1]);
				
				
				
		
		
		
		
		
		if(comHtml.contains("/>Directions")) {
			String link = "https://www.ryanhomes.com"+ U.getSectionValue(comHtml, "var url = '", "';");
			U.log("link: "+link);
			String dirHtml = U.getHTML(link);
			U.log(U.getCache(link));
			
//			String addSec = U.getSectionValue(dirHtml, "ADDRESS</div>", "<div class=\"address-button");
			String addSec=U.getSectionValue(dirHtml, "ADDRESS</div>", " </div>\n" + 
					"                    </div>");
			if(addSec == null)
				addSec = U.getSectionValue(dirHtml, "ADDRESS</div>", "<div class=\"col-6 model-hours\">");

//			U.log("addSec: "+addSec);
			String[] addVal = U.getValues(addSec, "<div class=\"row no-wrap address-padding\">", "</div>");

			add[0] = addVal[0];
			String[] temp = addVal[1].split(",");
			add[3] = Util.match(temp[1], "\\d{5}");
			add[2] = temp[1].replaceAll("\\d{5}", "");
			add[1] = temp[0];
			
			U.log("address: "+add[0].trim()+", "+add[1].trim()+", "+add[2].trim()+", "+add[3].trim());
			U.log("geo: "+geo);
		}
		
		else 
		{
			String addSec = U.getSectionValue(comHtml, "<span class=\"community-name-info\">", "</div>\n" + 
					"</div>");
			addSec=addSec.replaceAll("</span>\n" + 
					"            <span class=\"community-name-info\">", ", ").replaceAll("</span>|</div>", "");
			 U.log("addSec ::"+addSec);
			 add=U.getAddress(addSec);
			 if(add[3].contains("-") && !add[0].contains("-")) {
					add[3]=U.getAddressGoogleApi(latLng)[3];
					U.log("address1111: "+add[0].trim()+", "+add[1].trim()+", "+add[2].trim()+", "+add[3].trim());

					if(add == null)add[3] = U.getAddressHereApi(latLng)[3];
					geo="TRUE";
				}
//			String newAddSec=U.getSectionValue(addSec, "<span class=\"community-name-info\">", "<span class=\"community-name-info-right\">");
//			String newAddSec=U.getSectionValue(addSec, "info\">", "</div>");
//			newAddSec=U.getNoHtml(newAddSec).replaceAll("\\s* Dover,", ", Dover,").replaceAll("\\s*Clayton,", ", Clayton,");
			
//			if(newAddSec!=null) {
//			newAddSec=newAddSec.replaceAll("</span>\n" + 
//					"            <span class=\"community-name-info\">", ", ").replaceAll("</span>", "");
//			U.log("addSec: "+newAddSec);
//			add=U.getAddress(newAddSec);
//			U.log("addSec:add   "+add[0]);
//			
//			if(add[3].contains("-") && !add[0].contains("-")) {
//				add[3]=U.getAddressGoogleApi(latLng)[3];
//				U.log("address1111: "+add[0].trim()+", "+add[1].trim()+", "+add[2].trim()+", "+add[3].trim());
//
//				if(add == null)add[3] = U.getAddressHereApi(latLng)[3];
//				geo="TRUE";
//			}
//			geo = "TRUE";
//		}
		}
		
		
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLng);
			if(add[0]==null)
				add = U.getAddressHereApi(latLng);
			geo = "TRUE";
			U.log("address: "+Arrays.toString(add));
			U.log("geo: "+geo);
		} 
		
		
		U.log("address: "+add[0].trim()+", "+add[1].trim()+", "+add[2].trim()+", "+add[3].trim());

		U.log("geo==="+geo);
		
		//================ Homes Data
		String homeData = ALLOW_BLANK;
		String[] uniqueHome = U.getValues(comHtml, "<div class=\"card\">", "<img class=\"card-img-top\""); 
		//U.log("uniqueHome: "+uniqueHome.length);
		
		for(String home:uniqueHome) {
			String homeLink = U.getSectionValue(home, "<a href=\"", "\">");
			homeLink = "https://www.ryanhomes.com"+homeLink;
			U.log("homeLink: "+homeLink);
			try
			{
			String homeHtml= U.getHTML(homeLink);
			String remove=U.getSectionValue(homeHtml, "<div id=\"communitiesNearby\">", "<script>");
			if(remove!=null) {
				homeHtml=homeHtml.replace(remove, "");
			}
			homeData+=homeHtml;
		}catch(Exception e) {}
		}
		
		//============ Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeData, "[\\s\\w\\W]{10}from the low \\$600[\\s\\w\\W]{30}", 0));
		
		comHtml = comHtml
				.replaceAll("00s", "00000").replaceAll("0s", "0000").replace("$1.03 Million", "$1,300,000").replace("$1.04 Million", "$1,040,000")
				.replaceAll("From \\$\\d{3},\\d{3}&#x2B","From \\$\\d{3},\\d{3} ");
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeData, "[\\s\\w\\W]{10}from the low \\$600[\\s\\w\\W]{30}", 0));

		comHtml = comHtml.replace("priced from the low $600000 to the $800000+", "priced from the low $600000 to the $800000");
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeData, "[\\s\\w\\W]{10}from the low \\$600[\\s\\w\\W]{30}", 0));

		
		String[] price = U.getPrices(comHtml+homeData, "priced from the low \\$\\d{6} to the \\$\\d{6}|<div class=\"center\">\\$\\d{3},\\d{3}</div>|From \\$d,\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|from the Upper \\$\\d{6}|from the Mid \\$\\d{6}|from the Low \\$\\d{6}|"
					+ "from the \\$\\d,\\d{3},\\d{3}|upper \\$\\d{6}|Mid \\$\\d{6}|From \\$\\d{3},\\d{3}|from the \\$\\d{6}|from \\$\\d{6}|low \\$\\d{6}|mid \\$\\d{6}|Low \\$\\d{6}", 0);
				
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
				
		//============ Square Feet
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			comHtml=comHtml.replace("+ sq. ft.", " sq. ft.")
					.replace("have 2,000-5,500+ sq. ft.", "have 2,000-5,500 sq. ft.")
					.replace("2200-3600+ square feet", "2200-3600 square feet");
		String[] sqft = U.getSqareFeet(comHtml+homeData, "\\d,\\d{3} finished sq. ft.| over \\d{4} sq. ft.|up to \\d,\\d{3}\\+sq.ft|\\d,\\d{3} square feet|\\d{4}-\\d{4} square feet|UP TO \\d,\\d{3} SQ. FT|\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d,\\d{3} sq. ft. of living space.|\\d,\\d{3}&#x2B; sq.ft|\\d,\\d{3} sq.ft", 0);
				
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeData, "[\\s\\w\\W]{10}finished sq. ft.[\\s\\w\\W]{30}", 0));
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);
		
		//================ cType
		String cType = U.getCommType(comHtml);
		U.log("cType: "+cType);
		
		//============ pType
		
		String rem=U.getSectionValue(comHtml, "<div id=\"communitiesNearby\">", "<script>");
				String rem2	=U.getSectionValue(comHtml, " <article id=\"reviews-list-content\">", "<div class=\"row image-container\">");
//				rem+=rem2;
		if(rem!=null) {
			comHtml=comHtml.replace(rem, "");
		}
		if(rem2!=null) {
			comHtml=comHtml.replace(rem2, "");
		}
		
		comHtml=comHtml.replace("with lawn mowing included with your HOA", "with lawn mowing included with HOA");
		String pType = U.getPropType((comHtml+homeData).replaceAll("luxury with a<strong>&nbsp;walk-in closet", "luxury with a walk-in closet"));

		U.log("pType: "+pType);
		
		//============ dType
		String dType = U.getdCommType(comHtml+homeData);
		U.log("dType: "+dType);
		
		//============ Status
		
		comHtml = comHtml.replaceAll("Tours of Quick Move-In Homes available|\"Quick Move In\"|>Quick Move-In<|Quick Move In Box|quick-links|a quick drive to|/quick-move-in|"
				+ "data-status=\"Coming Soon\"|overlay\">Coming Soon</span>|Prices Coming Soon|>Grand Opening</span>|data-status=\"Grand Opening\"|"
				+ "will be ready for move-in day with&nbsp|A NEW building is now available!|October Move-In Dates Now Available|1/2 acre homesite now available|"
				+ "Limited homesite availability in our current phase|backing to woods now available|Lookout basements now available|Your home will be move-in ready from day one|"
				+ "alt='MOVE-IN READY HOMES|<h5>MOVE-IN READY HOMES</h5|“in the know” via emai|let us know more abou|first to know about all| homes are now&nbsp;open|"
				+ "about the day you move in|installed the day you move in|Move-in ready with all appliances included|move-in ready homes available|delivered move-in ready with all kitchen|"
				+ "when you move in|move in fast?|plus our move-in ready Juniper|Just Released! Be the first to choose from|NEW SECTION NOW OPEN!|>Quick Move in Homes Available<|"
				+ "<!--Quick Move In Box-->", "");
		
		comHtml = comHtml.replace("Just Released! 6 new homesites have just been released", "New Homesites Just Released")
				.replace("Summer Move-ins Available","Quick Move-In").replace("Wooded Homesite Available","Wooded Homesites Available")
				.replace("Basements sites remaining in the Manor","2 Basements sites remaining").replaceAll(">Quick Move-Ins</p>", "Quick Move-In")
				.replaceAll("QUICK MOVE-IN HOME|quick move in available|Quick Move-In Home|Quick Move in Homes", "Quick Move-In")
				.replaceAll("Final McPherson Homesites Just Released", "6 Homesites Available").replaceAll("NEW PHASE OF HOMESITES AVAILABLE", "New Phase Homesites Available");
		
		comHtml = comHtml.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">Townhomes already sold! </div>", " $1 Townhomes already sold ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">Wooded Homesites Remaining</div>", " $1 Wooded Homesites Remaining ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">cul-de-sac homesites remaining</div>", " $1 cul-de-sac homesites remaining ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">Oversized Homesite Remains!</div>", " $1 Oversized Homesite Remains")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">Waterfront Cul-De-Sac Homesite Remains!</div>", " $1 Waterfront Cul-De-Sac Homesite Remains")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">homesites remain including cul-de-sac &amp; treelined!</div>", " $1 homesites remain ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">Wooded Homesites Available</div>", " $1 Wooded Homesites Available ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">townhomes already sold in new phase!</div>", " $1 townhomes already sold in new phase ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">Remaining Homesites! Come in Today!</div>", " $1 Homesites Remaining ")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">opportunity available! Homesite #121</div>", " $1 opportunity available ");
		
		
		
		comHtml=comHtml.replaceAll("Designer Clubhouse Now Available.&nbsp;|Quick Move-Ins Ready This Spring|Quick Move-In Homes Ready This Spring|We are opening&nbsp;spring&nbsp;2022|100% financing options available|amenity&nbsp;center coming soon|RESORT-STYLE AMENITIES COMING SOON|Each home is built move-in ready|over 1/2-acre homesites now available|opening in the fall of 2019|cul-de-sac or backing to open space is now open|You don't want to miss out on this beautiful new phase|and you&rsquo;re ready to move in|and you’re ready to move in|The brand-new Texas Roadhouse and Grotto Pizza are now open", "")
				.replaceAll(" 3\n" + 
						"                                    </div>\n" + 
						"                                    <div class=\"fomo-block-option1-description\">homesites available!</div>", "3 homesites available!</div>")
				.replace("this community their new home! The final phase is now selling", "this community their new home! The final phase now selling")
				.replace("new townhome homesites now available", "New homesites now available")
				.replace("New homesites are coming soon in Phase Two", "New homesites coming soon in Phase Two")
				.replaceAll("\\s+</div>\n\\s+<div class=\"fomo-block-option1-description\">", " ")
				.replaceAll("(alt='|<h5>)Quick Move-in Home|we have quick move-in|(alt='|<h5>)Quick move-in home available!|text\"Quick Move-In", "")
				.replaceAll("(alt='|<h5>)NEW SECTION COMING SOON", "")
				.replaceAll("(alt='|<h5>)Basements available", "")
				.replaceAll("(alt='|<h5>)Quick move-in opportunities", "")
				.replaceAll("(alt='|<h5>)QUICK MOVE-IN|recent Quick Move-In opportunities|1 Quick Move-In Grand|Quick Move-In Opportunity","")
				.replaceAll("Our final homesite is now available", "final homesite now available")
				.replaceAll("Wooded &amp; cul-de-sac homesites available", "Wooded & cul-de-sac homesites available")
				.replaceAll("Private, wooded homesites remain", "Private wooded homesites remain")
				.replaceAll("wooded, riverfront homesites", "wooded riverfront homesites")
				.replaceAll("Quick Move-In&#x27;s|alt='Quick Move-InS", "Quick Move-Ins")
				.replaceAll("(Q|q)uick move-in", "Quick Move-Ins")
				.replaceAll("Quick Move-Ins homes|FOR A QUICK MOVE-IN","")
				.replaceAll("\\s*</div>\n" + 
						"                                    <div class=\"fomo-block-option1-description\">Wooded Homesites Remain</div>", " Wooded Homesites Remain</div>")
				.replaceAll("(alt='|<h5>)1 Move-in-ready home|released a move-in-ready|1 Move-in ready home available</div>|own a move-in-ready", "")
				.replaceAll("  <h5>1 Summer move-ins available! </h5>|Join the VIP List</strong></a> to be one of the first to know about new homesite releases!|YOUR NEW HOME IS MOVE-IN READY WITH INCLUDED LAWN AND LANDSCAPING|This means you will be ready for move-in&nbsp;day with no additional costs|LIMITED HOMESITES ARE BEING RELEASED EVERY MONTH|Flex Cash on limited homesites!|we are selling out quickly. Make sure to <a href=\"#visit\">schedule a visit today|We are&nbsp;currently selling&nbsp;our final Quick Move-Ins home|lifestyle to one of our brand new move-in ready homes|Community Playground - Coming Fall 2022|Coming Soon &#x2013; community playground|Coming Soon – community playground", "")
				.replace("community playground (coming summer 2022)", "")
				.replaceAll("3\n" + 
						"                                    </div>\n" + 
						"                                    <div class=\"fomo-block-option1-description\">Walk-out Basement Homes Remain</div>", "3 Walk-out Basement Homes Remain</div>")
				.replace("1 Move-In Ready Home Available</div>", "1 Quick Move-In Home Available</div>")
				.replaceAll("\\s*</div>\n" + 
						"                                    <div class=\"fomo-block-option1-description\">", " ");
		
		String quicksts=U.getSectionValue(comHtml, "<div class=\"qmi-header-subtext2\">", "</div>");
		
		String Status = U.getPropStatus(comHtml.replace("Large wooded homesites remain", "wooded homesites remain")
				.replace("New Section of&nbsp;Fawn Lake now open", "New Section now open")
				
				.replaceAll("<div class=\"personalized-description bodyCopyFont\">\n" + 
						"         wooded homesites now available. \n" + 
						"    </div>|COMMUNITY AMENITIES - NOW OPEN!|before we're sold out|appointment today to secure yours before we're sold out|The final phase of homesites has been released at Westtown Village|Coming Soon &#x2013; community playground|Coming Soon – community playground|playground (coming summer 2022)|This means&nbsp;you will&nbsp;be&nbsp;ready for move-in&nbsp;day|\">Quick Move-Ins Available!</div>|15 Quick Move-Ins Available</div>|Columbia Quick Move-In|columbia quick move-in|desktop' Quick Move-Ins|several quick move-in homes|2 Quick Move-Ins Available!</div>|units now available!|1 quick move-in home available|Finished Basements Available( ' />|</h5>)|Only 1 home remaining for 2022 move-in|text\"Quick Move-In|Many quick move-in homes|townhomes are move-in ready|\">Limited availability|Meadows.&nbsp;Limited opportunity|wooded homesites available.</p>|school coming soon.</p>", "")
				.replaceAll("(\\d)(.*?)Oversized, Premium Homesite Available", "$1 Oversized Premium Homesite Available").replaceAll("Wooded, walkout homesite remains", "Wooded walkout homesite remains")
				.replaceAll("newest phase is opening soon", "newest phase opening soon").replaceAll("<p>Coming Soon this|is ready to move into ","").replaceAll("2 Summer Move-Ins Available!( </h5>|  ' />)", "").replaceAll("Quick Move-in","Quick Move-ins")
				+quicksts); //.replaceAll("(\\d)(.*?)Corner Homesites Available", "$1 Corner Homesites Available"))
		U.log("Status: "+Status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{100}final phase[\\s\\w\\W]{100}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{100}move-in ready[\\s\\w\\W]{100}", 0));

		//============ Note
		comHtml = comHtml.replace("Opening for sales to VIPs Early 2022", "");
		
		if(pType.contains("Townhouse") && pType.contains("Townhome")) {
			pType=pType.replaceAll("Townhouse,|,Townhouse,|,Townhouse", "");
		}
		
		
				String note = U.getnote(comHtml);
		U.log("note: "+note);
				
		String count=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		Status=Status.replace("Summer Move-ins Available, ", "")
				.replace("One Home Remaining, 1 Homesite Remaining", "1 Homesite Remaining")
				.replaceAll("\\d Quick Move-in Available|\\d Quick Move-in Home|Quick Move In Homes", "Quick Move-Ins").replaceAll("Quick Move-in", "Quick Move-Ins");
		
		
		
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyStatus(Status.replaceAll("Move-in Ready Homes|Quick Move-in Homes", "Quick Move-in"));
		data.addPropertyType(pType, dType);
		data.addNotes(note);
		data.addUnitCount(count);
		data.addConstructionInformation(startDt,endDt);
		}
//		catch(Exception e) {U.log(e);}
		
		i++;
//		}
		//else
			//i++;
	}

}
