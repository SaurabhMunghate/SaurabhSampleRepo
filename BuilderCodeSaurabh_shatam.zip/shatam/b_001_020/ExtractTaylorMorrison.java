package com.shatam.b_001_020;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.bcel.generic.CPInstruction;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTaylorMorrison extends AbstractScrapper {
	// private static String string;
	CommunityLogger LOGGER;
	static int i = 0;
	WebDriver driver;

	public ExtractTaylorMorrison() throws Exception {

		super("Taylor Morrison", "https://www.taylormorrison.com");
		LOGGER = new CommunityLogger("Taylor Morisson");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper as = new ExtractTaylorMorrison();
		as.process();
		FileUtil.writeAllText(U.getCachePath() + "Taylor Morrison.csv", as.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String mainhtml = U.getHTML("https://www.taylormorrison.com");
		String regurlssec = U.getSectionValue(mainhtml, "\"Search Homes\",\"state\":", "\"bedrooms\"");
		Set s = new HashSet();
		String curl1 = null;
		String regurls[] = U.getValues(regurlssec, "\"value\":\"", "\"}");
//		 U.log(regurls.length);
		 int k=0;
		for(String reg:regurls) {
//			U.log(reg);
			String commurls[]=U.getValues(U.getHTML("https://www.taylormorrison.com"+reg), "\"communityDetailLink\":", "community");
			//U.log(commurls.length);
			for(String commurl:commurls) {
				
			//	U.log(k);
				k++;
			//	U.log(commurl.length()+commurl.length());
				
//				try {
					adddetails("https://www.taylormorrison.com"+U.getSectionValue(commurl, "\"Url\":\"", "\""),commurl);
//				}catch(Exception e) {}
				
				
			}
		}
		
		LOGGER.DisposeLogger();
		//U.log(s.size());
	}

	//TODO:
	public void adddetails(String commurl, String curl) throws Exception {
		
		
//		if(!commurl.contains("https://www.taylormorrison.com/az/phoenix/surprise/christopher-todd-communities-at-paradisi"))return;
//		if(!commurl.equals("https://www.taylormorrison.com/tx/austin/georgetown/parkside-on-the-river-45s")) return;
		
		
	//	try{
		U.log( "====================" + i+"\n"+commurl);
	//	if(i>=400 && i<=500)
//		if(i>=300)
//		if(i<=50)
//		if(i>=320)
		{
		
//		U.log("Curl"+curl);
		
		if (data.communityUrlExists(commurl)) {
			LOGGER.AddCommunityUrl("*****************REPEATED**************" + commurl);
			
			return;
		}
		if (commurl.contains("https://www.taylormorrison.com/az/phoenix/surprise/los-cielos-at-rancho-mercado") || commurl.contains("queen-creek/victoria-heights-discovery-collection")) {
			LOGGER.AddCommunityUrl("*****************Not found on page**************" + commurl);
			
			return;
		}
		if(commurl.contains("https://www.taylormorrison.com/nc/raleigh/durham/creekside-at-bethpage")) {
          
			LOGGER.AddCommunityUrl("*****************Not found on Region page**************" + commurl);
			
			return;
		}
		
		LOGGER.AddCommunityUrl(commurl);
		
		String commhtml = U.getHTML(commurl);
		U.log(U.getCache(commurl));
		
		// ------------------ For Iframe -------------------
		String frameUrl = ALLOW_BLANK;
		if(commhtml.contains("\"mapSrc\":\"")) {
			U.log("iframe Present");
			
			frameUrl = U.getSectionValue(commhtml, "\"mapSrc\":\"", "\"");
			U.log("frameUrl: "+frameUrl);
		}
		else {
			U.log("iframe Absent");
		}
		// -------------------------------------------------	
		
		commhtml = commhtml.replace("Final FIVE Homes are NOW AVAILABLE", "Final FIVE Homes NOW AVAILABLE")
				.replaceAll("New Homes Now Available|NC is now available|Plan .* Homes Now Available","");
		
		String newDesc = ALLOW_BLANK;
		if(commhtml.contains("<a rel=\\\"noopener noreferrer\\\" rel=\\\"noopener noreferrer\\\""))
			{
				String newComUrl = U.getSectionValue(commhtml, "<a rel=\\\"noopener noreferrer\\\" rel=\\\"noopener noreferrer\\\" href=\\\"", "\\\" title=");
				if(newComUrl!=null&&!newComUrl.contains("<script")) {
				U.log("new com url:"+newComUrl);
				commhtml+=U.getHTML(newComUrl);
				newDesc= U.getSectionValue(commhtml, "<section id=\"\" class=\"title-description ", "</section>");
				}
				
			}
		
		String communityname = U.getSectionValue(commhtml, "\"communityName\":\"", "\"");
		
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/vacaville/farmstead"))communityname="Farmstead Square";
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/orinda/wilder-canyon"))communityname="Wilder Canyon";
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/sunnyvale/ov8tion"))communityname="Ov8tion";
		if(commurl.contains("https://www.taylormorrison.com/ca/bay-area/napa/pear-tree"))communityname="Pear Tree";
		communityname=communityname.replace("- Age Restricted 55+ Community", "").replaceAll(" -  Townhome Series$", "");
		communityname=communityname.replace("55+", "").replace("Coach Homes", "").replace("Cottages", "");
		communityname=communityname.replace("s,", "s -").replaceAll("- Darling|- Age Restricted|Condos$", "");
		
		communityname=communityname.replace("Reedy Reserve Townhomes", "Reedy Reserve")
				.replace("Lakeside At Crabapple Townhomes", "Lakeside At Crabapple")
				.replace("Bethesda Townhomes", "Bethesda")
				.replace("Sunridge Townhomes", "Sunridge");
		
		U.log("communityname==="+communityname);

		// ======================address============================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		
		
		String geo = "FALSE";
		// "address":{"address1":"17 Bethesda Church
		// Road","address2":"","city":"Lawrenceville","state":"GA","zip":"30044"},
		String addsec = U.getSectionValue(commhtml, "\"address\":", "},");

		
		if (addsec != null) {
			addsec = addsec.replace("Florida", "FL").replace("Sales Center Open By Appointment", "").replace("Selling from Townsend at Ashford Park", "");
			addsec = addsec.replace("Tx", "TX").replaceAll("35\\.086309, -80\\.61869|MODEL COMING SOON|Model Closed|Virtual Appointments Only", "");
		}
		if(addsec==null)addsec=ALLOW_BLANK;
		U.log("addsec: "+addsec);

		// String address[]=addsec.split("+");
		String add12 = U.getSectionValue(addsec, "\"address1\":\"", "\"");
	
		
		if (add12 != null) {
			add[0] = add12;
		} else {
			String add21 = U.getSectionValue(addsec, "\"address2\":\"", "\"");
			add[0] = add21;
		}
//		U.log("AA"+add[0]);
		if(add[0]==null||add[0]==ALLOW_BLANK||add[0].isEmpty()) 
			add[0] = U.getSectionValue(addsec, "\"address\":\"", "\"");
		U.log("add[0]: "+add[0]);
		
		if(add[0] != null && add[0].contains("Temporary Location: 4968 Summerfaire Drive")) {
			add[0] = add[0].replace("Temporary Location: 4968 Summerfaire Drive", "4968 Summerfaire Drive");
		} 	

		
//		U.log("BB"+add[0]);
		add[1] = U.getSectionValue(addsec, "\"city\":\"", "\"");
		add[2] = U.getSectionValue(addsec, "\"state\":\"", "\"");
		add[3] = U.getSectionValue(addsec, "\"zip\":\"", "\"");
		
		U.log("MY 1st Address"+Arrays.toString(add));
		if(add[0]!=null)
        add[0]=add[0].replace(" and New Hill Olive Chapel Road", "");
		
		
		
		if((addsec==null || addsec==ALLOW_BLANK) && commhtml.contains("https://goo.gl/maps/")) {
			addsec=U.getSectionValue(commhtml, "<p><a href=\"https://goo.gl/maps/", "</p>");
			if(addsec!=null) {
			addsec = U.getSectionValue(addsec, "target=\"_blank\">", "</a");
			U.log("M ADDSEC"+addsec);
			add= U.findAddress(addsec);
			}
		}
		
		if(commurl.contains("https://www.taylormorrison.com/or/portland/wilsonville/clermont")) {
			add[1] = "Wilsonville";
			add[2] = "OR";
		}

		U.log(Arrays.toString(add));

		// ================================latlagsec=============================================

		U.log(curl);
		String latlagsec = U.getSectionValue(curl, "\"latLng\":{", ",\"photos\":");
		latLong[0] = U.getSectionValue(latlagsec, "\"lat\":", ",");
		latLong[1] = U.getSectionValue(latlagsec, "\"lng\":", "}");

		U.log("M LATLNG"+Arrays.toString(latLong));
		
//		if(add[0]!=null && add[0].contains("Coming Soon"))
//		add[0]=add[0].replaceAll("Coming Soon", "");
		
		
		U.log(">>>>>>>>>"+ addsec.length());
		if(add[0]!=null)
		add[0]=add[0].replaceAll("Intersection of Blue Oaks Blvd and |Intersection Of Blue Oaks Blvd And |Coming Soon to N. Main Street|Coming Soon to Loop Rd|Coming Soon|6 Offices Across Dallas|Temporarily Sold Out|35.287611, -80.670624", "");
		
		if( add[0]=="" && add[1]!=null && add[2]!=null && add[3]!=null) {

			//latLong=U.getlatlongGoogleApi(add);
			add[0]=U.getAddressGoogleApi(latLong)[0];
			geo="TRUE";
		}
		if(addsec==ALLOW_BLANK && latLong[0].length()>1 && latLong[1].length()>1) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}
		
		if(latLong[0].contains("0.0") && add[0].length()<1 && add[3].length()<1) {
			String[] add1={"",add[1],add[2],""};
			latLong=U.getlatlongGoogleApi(add1);
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}
		
		
		
		if(commurl.contains("avalon-at-friendswood") || commurl.contains("avalon-at-friendswood-60s-venture")) {
			add[1]="Houston";
			add[2]="TX";
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
//		if(commurl.contains("https://www.taylormorrison.com/ca/southern-california/san-pedro/harbor-pointe")) {
//			add[1]="San Pedro";
//			add[2]="CA";
//			
//			latLong=U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latLong);
//			geo="TRUE";
//		}
		if(commurl.contains("https://www.taylormorrison.com/az/phoenix/mesa/christopher-todd-communities-at-ellsworth")) {
			add[1]="Mesa";
			add[2]="AZ";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(commurl.contains("https://www.taylormorrison.com/nv/las-vegas/las-vegas/crested-canyon-in-summerlin")) {
			add[1]="Mesa";
			add[2]="NV";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
//		if(commurl.contains("https://www.taylormorrison.com/az/phoenix/phoenix/christopher-todd-communities-at-mcdowell")) {
//			add[1]="Phoenix";
//			add[2]="AZ";
//			
//			latLong=U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latLong);
//			geo="TRUE";
//		}
		if(commurl.contains("https://www.taylormorrison.com/az/phoenix/surprise/christopher-todd-communities-at-paradisi")) {
			add[1]="Surprise";
			add[2]="AZ";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(commurl.contains("https://www.taylormorrison.com/tx/dallas/grand-prairie/christopher-todd-communities-at-dechman")) {
			add[1]="Grand Prairie";
			add[2]="TX";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(commurl.contains("https://www.taylormorrison.com/tx/houston/cypress/bridgeland-70s-affinity")) {
			add[1]="Cypress";
			add[2]="TX";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(commurl.contains("https://www.taylormorrison.com/tx/houston/cypress/bridgeland-parkland-village-55s-sanctuary")) {
			add[1]="Cypress";
			add[2]="TX";
			add[3]="77433";
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}

		
		
		if (commurl.contains("https://www.taylormorrison.com/co/denver/castle-pines/timberline-50s"))
			add[2] = "CO";

		if(add[0]!=null)
		if(add[0].contains("Unnamed Road")||add[0].contains("Sold Out Community")||add[0].contains("By Appointment Only")||add[0].contains("SOLD OUT")||add[0].contains("TBD") || add[0].contains("Coming Soon") || add[0].contains("To Be Determined") || add[0].contains("Coming Soon To") || add[0].contains("For GPS Purposes") || add[3].length()==0) {
			
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(latLong[0].length()<4 || latLong[1].length()<4) {
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		//https://www.taylormorrison.com/tx/houston/friendswood/avalon-at-friendswood-90s-regency
		if(commurl.contains("https://www.taylormorrison.com/sc/charlotte/indian-land/covington-estates"))add[0]="Barberville Rd";
		if(commurl.contains("https://www.taylormorrison.com/or/portland/tigard/eastridge-legacy-series"))add[0]="16870 SW Rockhampton Ln";
		if(commurl.contains("https://www.taylormorrison.com/fl/sarasota/lakewood-ranch/park-east-at-azario")) {
			add[0]="";
			add[1]="Bradenton";
			add[2]="FL";
			latLong=U.getlatlongGoogleApi(add);
		    add=U.getAddressGoogleApi(latLong);
		    geo="TRUE";
		   }
		
		
		
		// =============geo===================================

		
		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if (add[0]!=null)
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			
			add[1]=U.getSectionValue(commhtml, "\"city\":\"", "\"");
			add[2]=U.getSectionValue(commhtml, "\"state\":\"", "\"");
			
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
			
			
		
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if(add[2]!=null)
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}
		
		
			

		U.log("GEO: " + geo);

		// ===================================floorplansection========================================
		String floorplansec = null;

		String floorplanhtml = U.getHTML(commurl + "/floor-plans");

		if (floorplanhtml != null) {

			floorplansec = U.getSectionValue(floorplanhtml, "\"floorPlansListDataArray\":", "</script");

		}
		if(floorplansec!=null)floorplansec = floorplansec.replaceAll("\"minPrice\":\\d+,\"priceOverrideText\":\"Inventory Homes Only\"|\"minPrice\":\\d+,\"priceOverrideText\":\"Call For Pricing\"|\"minPrice\":\\d+,\"priceOverrideText\":\"Sold Out\"|\"minPrice\":\\d+,\"priceOverrideText\":\"Price Coming Soon\"|\"minPrice\":\\d+,\"priceOverrideText\":\"Interest List Forming\"", "");
		// ==================================available
		// home=====================================
		String avaialablehomehtml=ALLOW_BLANK;
		String availablehomesec = null;
		String availableHomeUrl= U.getSectionValue(commhtml,"\"viewAllHomesLink\":","AVAILABLE HOMES</a>");
		if(availableHomeUrl==null) availableHomeUrl= U.getSectionValue(commhtml,"\"viewAllHomesLink\":","Available Homes</a>");
//		if(availableHomeUrl==null) availableHomeUrl= U.getSectionValue(commhtml,"\"viewAllHomesLink\":","Available Homes</a>");
		
		U.log("availableHomeUrl: "+availableHomeUrl);	
		
		if (availableHomeUrl == null)availableHomeUrl="";
		
		if(availableHomeUrl!=null) {
			avaialablehomehtml = U.getHTML("https://www.taylormorrison.com" + U.getSectionValue(availableHomeUrl, "href=\\\"", "\\\""));
		}
			 
		
		if(commurl.equals("https://www.taylormorrison.com/tx/austin/austin/sweetwater-65s")) {
			avaialablehomehtml = U.getHTML("https://www.taylormorrison.com/tx/austin/austin/sweetwater-65s/available-homes");
		}
//U.log("avaialablehomehtml    "+avaialablehomehtml);
		if (avaialablehomehtml != null) {

			availablehomesec = U.getSectionValue(avaialablehomehtml, "availablePlansList\":", "</script");

		}
//		U.log("this is available::::::::::;"+availablehomesec.length());

		// =====================================================prices==============================================================

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		String priceSec="";
		priceSec=U.getSectionValue(commhtml, "\"pricing\":\"", "\"");
		
		
		if(priceSec==null)priceSec="";
		commhtml = commhtml.replace("Low $2M&#39;s", "Low $2,000,000").replace("High $1M&#39;s", "High $1,000,000")
				.replace("from $1.7 million", "from $1,700,000 million")
				.replace("$550k-$650k", "\\$550,000-\\$650,000").replaceAll("\\d+,\\d+\",\"priceOverrideText\":\"Showcase Homes Only", "").replace("$1 Million", "$1,000,000").replace("2.4 Millions", "$2,400,000").replaceAll("\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Call For Pricing\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Sold Out\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Price Coming Soon\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Interest List Forming\"|price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Showcase Homes Only\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Price To Be Determined\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Temporarily Sold Out\"", "");
		
		priceSec=priceSec.replace("$1MM", "$1,000,000").replace("0s", "0,000").replace("3M", "$3,000,000").replace("0&#39;s", "0,000").replace("$1M&#39;s", "$1,000,000").replace("$2M", "$2,000,000");
		String priceSec2=U.getSectionValue(commhtml,"\"price\":\"", "\",");
		if(priceSec2!=null) {
		priceSec2=priceSec2.replaceAll("0's|0'S|0s","0,000");
		priceSec2=priceSec2.replace("$1MM", "$1,000,000").replace("$2M's", "2,000,000");
		priceSec2=priceSec2.replace("mid $800,000 to $1+ million","mid $800,000 to $1,000,000");
		}
		U.log("priceSec: "+priceSec);
		
		
//	
		if(availablehomesec!=null)availablehomesec=availablehomesec.replaceAll("\"price\":943990", "");
		if(floorplansec!=null) floorplansec=floorplansec.replaceAll("\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Call For Pricing\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Sold Out\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Price Coming Soon\"|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Interest List Forming\"|price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Showcase Homes Only\"|\"minPrice\":\\d+,\"priceOverrideText\":\"Price To Be Determined|\"price\":\"\\$\\d+,\\d+\",\"priceOverrideText\":\"Price To Be Determined\"", "").replaceAll("\"minPrice\":\\d+,\"priceOverrideText\":\"Showcase Homes Only|\"minPrice\":\\d+,\"priceOverrideText\":\"Temporarily Sold Out\"", "");
		if(floorplansec==null)floorplansec=ALLOW_BLANK;
		
		commhtml = commhtml.replace("$2M's","$2,000,000").replace("$1.5 million", "$1,500,000").replace("$1.5M", "$1,500,000").replace("0s", "0,000").replace("\"pricing\":\"Low $200&#39;s\"",
				"\"pricing\":\"Low $200,000\"").replace("upper $200","Low $200,000").replace("the high $700&#39;s", "the high $700,000");
		
		String priceSecTop = ALLOW_BLANK; //prices from top the page
		
		if(commhtml.contains("\"subTitle\":\"\",\"pricingText") && commhtml.contains("communityIcon\"")) {
			priceSecTop = U.getSectionValue(commhtml, "subTitle\":\"\",\"pricingText", "communityIcon\"");
			priceSecTop = priceSecTop.replace("Mid $2M&#39;s", "Mid $2,000,000")
					.replaceAll("00&#39;s", "00,000");
			
			U.log("priceSecTop: "+priceSecTop);
		}
			
		
		prices = U.getPrices((priceSecTop+priceSec2+priceSec+availablehomesec +newDesc+floorplansec)
				.replaceAll("floorPlanName\":\"\\w+\\s*\\w+\",\"minPrice\":\\d+", ""),//removing json prices from floorplans
				"the high \\$\\d{3},\\d{3}|\"minPrice\":\\d{7}|mid \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\"minPrice\":\\d{7},|\"minPrice\":\\d{6},|Priced From the Mid \\$\\d{3},\\d{3}|\"price\":\\d{6},|,\"price\":\\d{7},", 0);
		minPrice = prices[0];
		maxPrice = prices[1];
		U.log(Arrays.toString(prices));
		
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(priceSecTop+priceSec2+priceSec,"[\\s\\w\\W]{50}611[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(availablehomesec +newDesc+floorplansec,"[\\s\\w\\W]{50}461[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(commhtml,"[\\s\\w\\W]{50}Final[\\s\\w\\W]{50}", 0));
		
		// ==================================sqft=====================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;
		commhtml=commhtml.replace("{\"text\":\"Sq. Ft.\",\"value\":\"", "Sq. Ft. ").replace("features\":[Sq. Ft. 650 - 993", "650 - 993 Square feets")
				.replace("features\":[Sq. Ft. 742 - 1054\"}", "742 - 1054 Square feet").replace("features\":[Sq. Ft. 742 - 1254\"", "742 - 1254 Square feet");
		
	//	U.log("GGG"+Util.matchAll(availablehomesec +commhtml,"[\\w\\s\\W]{30}2600[\\w\\s\\W]{30}", 0));
		
		sqft = U.getSqareFeet(availablehomesec + floorplansec + commhtml, 
				"\\d{3} - \\d{4} Square feet|from \\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d{3} - \\d{3} Square feets|from \\d,\\d{3} Sq. Ft. - \\d,\\d{3} Sq. Ft|from \\d{3} to \\d,\\d{3} sq. ft.|\\d,\\d{3} to over \\d,\\d{3} square footage|Sq. Ft. \\d{4} - \\d{4}|features \\d{4} square feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\"text\":\"Sq. Ft.\",\"value\":\"\\d{4}\"}|\"minSqFt\":\\d{4}|\\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} sq. ft.|Sq. Ft. \\d{4}",
				0);
		//Sq. Ft. \\d{3} - \\d{3}
		minsqft = sqft[0];
		maxsqft = sqft[1];
		U.log(Arrays.toString(sqft));
		
//		U.log(">>>>>>>>"+Util.matchAll(commhtml,"[\\w\\s\\W]{30}742[\\w\\s\\W]{30}", 0));
//		U.log(">>>>>>>>"+Util.matchAll(floorplansec,"[\\w\\s\\W]{30}200[\\w\\s\\W]{30}", 0));
		
		// ============================communitytype=================================
		String subTitle="";
		subTitle=U.getSectionValue(commhtml, "\"title\":\"", "\"description");
	//	U.log("SUB TITLe"+subTitle);
		String commdesc = U.getSectionValue(commhtml, "\"description\":\"", "</community-about>");
		commdesc+=newDesc;
		String mySubTitle=U.getSectionValue(commhtml, "\"subTitle\":\"","\"description\":");
		
		String ctype = null;

		ctype = U.getCommType((subTitle+commdesc).replaceAll("Summerlin is home to an incredible ten golf courses! TPC Las Vegas, Highland Falls Golf Club, Angel Park Golf Club, Canyon Gate Country Club and The Arroyo Golf Club are all located within a short drive of the community", "")
				.replaceAll("elongated|-golf-and-country-club-", "").replace("lakeside access", "lakeside living"));

		U.log("ctype=="+ctype);

		if (ctype == null)
			ctype = ALLOW_BLANK;

		// ============================propertytype====================================
		String ptype = U.getPropType((commdesc + availablehomesec + floorplansec)
				.replace("traditionally charming and spacious homes", "traditional homes")
				.replace("Home Owners&nbsp;Association (HOA)", "Home Owners Association (HOA)")
				.replace("Superbly crafted, these homes will provide an unparalleled", "Superbly craftsman style, these homes will provide an unparalleled")
				.replaceAll("luxury finishes and more|What are the HOA dues|Collection, homeowners will owe monthly HOA dues of approximately|Occupational|Parc townhomes, condos or apartments|a Custom Home Builder|-6-plex|townhouse a light|-cottage-|6-plex_", ""));
		
		U.log("ptype=="+ptype);
		//U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(commdesc + availablehomesec + floorplansec,"[\\s\\w\\W]{50}courtyard[\\s\\w\\W]{50}", 0));

		// ========================dpropertytype========================================
		
		String[] rem1=U.getValues(commdesc, "Are Additional Home Collections", "<p>Warning:");
		if(rem1.length>0)
		{
			for(String rem:rem1 )
			{
				commdesc=commdesc.replace(rem, "");
			}
		}
		
		
		String derivedpropSection = (commdesc + availablehomesec + floorplansec).replace("{\"text\":\"Story\",\"value\":\"1 - 1.5\"}", "1 story, One and a half-story").replace("\"text\":\"Story\",\"value\":\"1 - 2\"", "1 story, 2 story").replace("Single story", "1 Story")
				.replace("one to two-story", "1 story, 2 story").replace("\"maxStory\":1.5,", "One and a half-story").replace("{\"text\":\"Story\",\"value\":\"3\"}", "3 Story")
				.replace("{\"text\":\"Story\",\"value\":\"1\"}", "1 Story").replace("\"Story\",\"value\":\"3 - 4\"", "3 story, 4 story")
				.replaceAll("\"Story\",\"value\":\"2 - 3\"", "2 story, 3 story")
				.replace("\"maxStory\":\"2.5\"", "2.5 stories")
				.replace("\"maxStory\":2.5", "2.5 stories")
				.replace("{\"text\":\"Story\",\"value\":\"2\"}", "2 Story").replace("\"minStory\":2.0", "2 Story")
				.replace("\"Story\",\"value\":\"1 - 2.5\"", "1 story , 2.5 stories").replace("1.5-story", "One and a half-story")
				.replace("\"Story\",\"value\":\"1 - 3\"", "1 story, 3 story")
				.replace("\"Story\",\"value\":\"2 - 3\"", "2 story, 3 story");
		
		derivedpropSection = derivedpropSection.replaceAll("Third Floor Highlights|Optional third floor allowing", "");
		
		String dtype = U.getdCommType(derivedpropSection.replaceAll("14617 Storyteller Lane|14617-storyteller|to see our full selection of one- and two-story house designs|45' floor plans|floor|rancho|\\d bedroom|Ranch Gate|\\d-\\d bedroom|Rancho", ""));
		
//		U.log("MMMMMMMM"+Util.matchAll(derivedpropSection  ,"[\\w\\s\\W]{30}17-story[\\w\\s\\W]{30}",0));
//		U.log("MMMMMMMM"+Util.matchAll(derivedpropSection  ,"[\\w\\s\\W]{30}7 Story[\\w\\s\\W]{30}",0));

		U.log("dtype=="+dtype);
		// ================================pstatus=========================================
		U.log("===0"+U.getCache(commurl));
		String statusSec="";
		statusSec=U.getSectionValue(commhtml, "\"community\":{\"status\":\"", "\"");
		String bannerTitle="";
		bannerTitle=U.getSectionValue(commhtml,"\"bannerTitle\":\"", "\"");
		String quickSec ="";
		if(availablehomesec!=null)
			quickSec = U.getSectionValue(availablehomesec, "\"qmiLabel\":\"", "\"");
		
//		U.log(quickSec);
	//	
		U.log("======"+statusSec);
//		U.log("MMM"+Util.matchAll(mySubTitle+commdesc+bannerTitle+subTitle+statusSec,"[\\w\\W\\s]{60}grand opening[\\w\\W\\s]{40}",0));
//		if(subTitle.contains("Coming Soon")&&bannerTitle.contains("New Homesites Coming Soon"))
//		{
//			subTitle=subTitle.replace("Coming Soon", "");
//		}
		commdesc=commdesc.replaceAll("Release Coming Soon|Models Opening Soon|A Home With More - Coming Late 2022</h2>","");
	
		String pstatus = U.getPropStatus((mySubTitle+commdesc+bannerTitle+subTitle+statusSec).replace("Final opportunities remain within Esplanade","Final opportunities within Esplanade")
				.replace("New phase coming soon in early 2023", "New phase coming soon early 2023")
				.replace("Pre-sales coming Summer 2022", "Pre-sales")
				.replaceAll("We are now selling out of our|we are selling out of our Silverleaf|to learn more about the new opportunities now selling|Granite Hills Discovery and then we will be completely sold out|coming soon to Aurora|coming soon to a vibrant|We are now selling the Landmark collection out of the Capstone|We are now selling Legado Landmark Collection out of", "")
				.replaceAll("status\":\"Coming Soon\",\"statusValue\":4|Next Section Coming Soon in Late 2022</h2>", "")
				.replaceAll("Limited homesites remain|Hill Country\",\"bannerSubTitle\":\"Now Open|<p>Now selling, Emory Crossing 50,000 offers|<p>Now Selling&nbsp;in Williamson County|<p>Now selling, Emory Crossing 50s offers|<p>Now Selling, explore our unique garden style floor|<p>Now Selling in Williamson County, Texas|Best Offer release coming soon", "")
				.replace("Grand Opening is currently scheduled for Spring 2022", "")
				.replace("when we start selling out", "").replace("style=\\\"color:#d31245;\\\">We are now sold out", "")
				.replace("Now OpenGrand Opening<h2>Two", "Grand Opening<h2>Two")
				.replace("Phase 2 opening in early 2022", "Phase 2 opening early 2022")
				.replace("FINAL 10 home sites are coming soon", "FINAL 10 home sites coming soon")
				.replace("Final Opportunity! Limited Homesite Availability", "Final Opportunity! Limited Homesites Available")
				.replaceAll("Limited homesite availability</h2>|Limited homesites remain|Plans selling now at The Ridge|Inventory Homes Now Selling|Inventory Homes Coming Soon|wide selection of home designs and best-selling floor plans|Canyon are now available|Settle at the top with luxury homes now selling in Castle Pines, Colorado|We also want to note with the exception of one Rockford showcase home, we are now sold out|Esplanade at Northgate is scheduled to open early 2022|Model Homes Coming Soon|once this model is sold we will be sold out|plan to have more home sites available|Wilder community are limited and selling quickly|selling now from our|Opening soon, Innovate|updates and our Grand Opening|Selling now, Caraway|Grand Opening is scheduled for|Highest and Best Offer Coming Soon|Opening soon, Washington County|homes coming soon|Are you currently selling|brand new community coming soon|Now selling sophisticated luxury homes|information on Phase 3 coming soon|Opening soon in Washington County|New Homes Coming Late Summer|Offer Release Coming Soon|bannerTitle\":\"Now Open\"|community's Grand Opening|With homesites coming soon|Model Now Open|Home: Now Open|Showcase Homes Coming Soon|fire pit coming soon|limited opportunity to build|Now open in Tarrant County|now selling beautiful homes|Now selling fashionable, upscale homes|amenity center is now open|selling now at our|Meadow View is selling out of our Eastridge|ctive lifestyle selling now|Now selling from our nearby Eastridge|will be sold out of the Eastridge| homes selling now|floor plans selling now|Coming soon to Williamson| coming soon amenities|Series home is coming soon|to have more lots available|models are now available|we have lots available|including the lots available|experience is now available|New community Kroger now open|regarding grand opening festivities| and grand opening invitations|plan is opening soon|available to quick move-in|Grand Opening event|Grand Opening and other special events|we get closer to our Grand Opening|for the quick move-in| Facing Lots Available|New houses selling now|Release Coming Soon|Are you Currently Selling|Series Coming Soon|Models Coming Soon|\"New Homesites Coming Soon\",\"name\":\"Hunton Forest|gym will be coming soon|may have limited availability|updates and grand opening|offers the limited opportunity|Now selling in the Kaufman|more home sites available in| last chance to be a resident|Coming soon community parks| know about our Grand Opening|The Grand Opening for Manning|regarding grand opening details| grand opening details|Models Now Open|models are now open|Now open in Riverside County|New Ponte Vista Homes Opening Winter 2021|As a coming soon community|Florida and is now available in California|communities is now available|coming soon to the West Valley|Now selling in the Riverside County|Community Temporarily Sold Out|estaurants coming soon|don't miss out on the final opportunity|Our Six Models are Now Open|Are Finished Basements Available|Now open in Mecklenburg County|more are now open|Now open in|models are NOW OPEN|MODELS ARE NOW OPEN|school opening Fall 2021|Now Open and Selling in San Marcos, TX|Final Opportunity in Camburn Coming Soon|Sales Center are coming soon|spacious homes selling now|life is selling now|We are open daily and selling now|Clubhouse is NOW OPEN|Clubhouse is now open|Now open for sales, Ascent Village|model home will be opening soon", ""))
				.replace("Grand Opening is currently scheduled for Spring 2022","");

//		U.log("MMMMMMMM"+Util.matchAll(subTitle+statusSec,"[\\w\\s\\W]{30}Selling Out[\\w\\s\\W]{30}",0));
//		U.log("MMMMMMMM"+Util.matchAll(mySubTitle ,"[\\w\\s\\W]{50}Selling Out[\\w\\s\\W]{50}",0));
//		U.log("MMMMMMMM"+Util.matchAll(commdesc ,"[\\w\\s\\W]{50}Selling Out[\\w\\s\\W]{50}",0));
//		U.log("MMMMMMMM"+Util.matchAll(bannerTitle  ,"[\\w\\s\\W]{50}Coming Late[\\w\\s\\W]{50}",0));

	//	if(commurl.contains("https://www.taylormorrison.com/co/denver/loveland/the-city-collection-at-lakes-at-centerra"))pstatus+=", Now Selling";
		
		
		U.log("pstatus=="+pstatus);
		if (minPrice == null)
			minPrice = ALLOW_BLANK;
		if (maxPrice == null)
			maxPrice = ALLOW_BLANK;
		if (minsqft == null)
			minsqft = ALLOW_BLANK;
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;

		
		if(commurl.contains("las-vegas/las-vegas/castellana-in-summerlin/"));

		if(ptype.contains(", Townhouse") && ptype.contains(", Townhome"))ptype=ptype.replace(", Townhouse", "");
		if(ptype.contains("Townhouse, ") && ptype.contains(", Townhome"))ptype=ptype.replace("Townhouse, ", "");
		
		pstatus=pstatus.replaceAll("Move-in Ready Homes,|Move-in Ready Homes|, Move-in Ready|Move-in Ready", "");
		pstatus=pstatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon").replace("Now Open, Opening Soon", "Now Open").replace("Opening Late Spring 2021, Opening Soon", "Opening Late Spring 2021").replace("Opening Early 2021, Opening Soon", "Opening Early 2021");
		if(pstatus.length()==0)pstatus=ALLOW_BLANK;
		
//		if(commurl.contains("/tx/austin/leander/horizon-lake-45s"))pstatus = pstatus+", New Homes Coming Late Summer/Early Fall 2021";
	//	pstatus = pstatus.replaceAll("Quick Move-in Homes|Quick Move-ins Available|Quick Move-in", "Homes Available Now").replace("Homes Available Now, Now Available", "Homes Available Now");
		
		
		if(add[0]!=null)
		add[0]=add[0].replace("Far Hills Ave + Fox Hill Dr", "Far Hills Ave and Fox Hill Dr").replace("&amp;", "&").replace("Ct'", "Ct");
		//======= NOTE ================================================================
		commhtml = commhtml.replace("Now VIP Pre-Selling", "Now Pre-Selling");
		
		
		communityname = communityname.replaceAll(" - Townhome Series", "");
		if(commhtml.contains("See all Available Homes</a>\",\"hasHomes\":false"))
		{
			if(pstatus.length()>4 && pstatus.contains(","))pstatus=pstatus.replaceAll(", Homes Available Now|Homes Available Now, |Homes Available Now", "");
			else pstatus=pstatus.replace("Homes Available Now", "-");
		} else if(commhtml.contains("See all Available Homes</a>\",\"hasHomes\":true")) {
			
			if(!pstatus.contains("Homes Available Now") && availablehomesec.length()>10)
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-ins";
				else
					pstatus+=", Quick Move-ins";
		}
		//14th Jul 21 from images
//		if(commurl.contains("https://www.taylormorrison.com/nc/charlotte/indian-trail/esplanade-at-north-gate"))pstatus=pstatus+", Coming Soon";
		//if(commurl.contains("https://www.taylormorrison.com/nc/raleigh/wake-forest/cascades-at-stonemill-falls"))maxPrice="$500,000";
		//repeated status 14th jul 21
		
		pstatus= pstatus
				.replace("Quick Move-in Home", "Quick Move-ins")
				.replace("Temporarily Sold Out, Sold Out", "Temporarily Sold Out")
				.replace("Limited Homesite Available, Limited Homesite", "Limited Homesite Available")
				.replace("Final Opportunities, Limited Opportunity", "Final Opportunities")
				.replace("New Phase Coming Soon Fall 2021, New Phase Coming Soon", "New Phase Coming Soon Fall 2021").replace("Final Phase Now Selling, Final Phase", "Final Phase Now Selling").replace("Homes Available Now, New Homes Now Available", "New Homes Now Available").replace("Coming Soon Winter 2021, Coming Soon", "Coming Soon Winter 2021");
		if(add[0]!=null)
		add[0]=add[0].replace("10397 NW 291ST AVE", "10397 NW 291st Ave").replace("5403 St. David&#39;s Court","5403 St. David's Court");
	//	 if(commurl.contains("https://www.taylormorrison.com/az/phoenix/glendale/falcon-ridge-encore-collection"))note = note.replace("Preselling", "Now Pre-Selling");
		
		 if(commurl.contains("https://www.taylormorrison.com/tx/houston/friendswood/avalon-at-friendswood-90s-regency")) note="Now Pre-Selling";
		 //17Aug21 from images
		// if(commurl.contains("https://www.taylormorrison.com/nc/charlotte/harrisburg/farmington"))pstatus=pstatus+", Coming Soon";
		if(!latLong[1].contains("-"))latLong[1]="-"+latLong[1];
//		String remSec=U.getSectionValue(commhtml, "dataLayer = [{","</script>");
//		commhtml=commhtml.replace(remSec, "");
//		String remSec2=U.getSectionValue(commhtml, "<script id=\"model208c403650c645af824d554d08a97945\"","</script>");
//		commhtml=commhtml.replace(remSec2, "");
		
//		U.log(Util.matchAll(commhtml, "[\\s\\W\\w]{50}Pre-grand Opening[\\s\\W\\w]{50}", 0));
		commhtml = commhtml.replace("community-status\":\"PRESELLING", "");
		
		note = U.getnote(commhtml.replaceAll("invitation to our VIP Pre-Sales|advantage of pre-grand opening pricing|plus an invitation to our private VIP Pre-Sale", ""));
		
		U.log("note=="+note);
		//U.log(Util.matchAll(commhtml, "[\\s\\W\\w]{50}Preselling[\\s\\W\\w]{50}", 0));
		
		//------------- Number Of Units -------------------------------------------------------//
		
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		String mapData = ALLOW_BLANK;
		int count = 0;
		
		if(frameUrl == ALLOW_BLANK) frameUrl = null;
		U.log("frameUrl: "+frameUrl);
 		
		if(frameUrl != null) {
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData != null) {
				
				if(mapData.contains("<polygon id=\"")) {
					
					String[] polygon = U.getValues(mapData, "<polygon id=\"", "\"");
					U.log("polygon: "+polygon.length);
					count = count + polygon.length;
				}
				
				if(mapData.contains("<rect id=\"")) {
					
					String[] rect = U.getValues(mapData, "<rect id=\"", "\"");
					U.log("rect: "+rect.length);
					count = count + rect.length;
				}
				
				if(mapData.contains("<path id=\"")) {
					
					String[] path = U.getValues(mapData, "<path id=\"", "\"");
					U.log("path: "+path.length);
					count = count + path.length;
				}
				
				if(mapData.contains("<polyline id=\"")) {
					
					String[] polyline = U.getValues(mapData, "<polyline id=\"", "\"");
					U.log("polyline: "+polyline.length);
					count = count + polyline.length;
				}
				
				U.log("Total count : "+count);
				units = String.valueOf(count);
			}
		}
		
		
				
		//---------------------------------------------------------------------------------------//
		
		data.addCommunity(communityname.replace(" | Affordable Housing", ""), commurl, ctype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("Annie&#39;s", "Annie's").replace(",", ""), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype.replace("Townhouse, Townhome", "Townhome"), dtype);
		data.addPropertyStatus(pstatus.replace(", Move-in Ready Homes", ", Quick Move-in").replace("Final Opportunities", "Final Opportunity"));
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		//.}catch(Exception e) {}
		
		}i++;
//	}catch(Exception e) {}
}
	

}
