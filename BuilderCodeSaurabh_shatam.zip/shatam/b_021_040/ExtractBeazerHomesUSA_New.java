/**
@author: Priti Chaulkar
@Date : Feb 2018
 */
package com.shatam.b_021_040;

/*
sagar
*/
import java.util.ArrayList;
import java.util.Arrays;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBeazerHomesUSA_New extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i=0;
	final static String BASEURL="https://www.beazer.com/";
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractBeazerHomesUSA_New();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Beazer Homes USA.csv", a.data().printAll());
	}
	public ExtractBeazerHomesUSA_New() throws Exception {
		super("Beazer Homes USA", BASEURL);
		LOGGER = new CommunityLogger("Beazer Homes USA");
	}
	ArrayList<String> cityUrlsSec = new ArrayList<String>();
	public void innerProcess() throws Exception {
		String reghtml =U.getHTML("https://www.beazer.com/site-map");
		String regUrlSec = U.getSectionValue(reghtml, ">Favorites</a></li>", "<footer >");
//		cityUrlsSec=Util.matchAll(regUrlSec, "<li><a href=\"/(.*?)\">(.*?) Homes</a></li>",1);
		U.log(">>>>>"+regUrlSec.length());
		String cityurls[]=U.getValues(regUrlSec, "<li><a href=\"/search", "\">");
		
		for(String cityUrl:cityurls) {
			cityUrl=BASEURL+"/search"+cityUrl;
//			U.log(">>>>>>>>>>"+cityUrl);
			String cityHtml = U.getHTML(cityUrl);
			String comSection[] = U.getValues(cityHtml, "{\"@context\":\"https://schema.org\",\"@type\":\"ListItem\",\"item\":{\"@type\":\"Place\"", "telephone\":\"");
			for(String comSec :comSection) {
				String comUrl = U.getSectionValue(comSec, "\"url\":\"", "\",");
//				U.log(">>>>>>>>>>"+comUrl);
				String comhtml = U.getHTML(comUrl);
				comhtml=U.getSectionValue(comhtml, "</title>", "</main>");
				if(comhtml.contains("Explore Plans")) {
				String subSec =U.getSectionValue(comhtml, "<div id=\"homeSeries\" class=\"palegrey padded bzh_views_view\">", "<div id=\"quickMoveIns\"");
				if(subSec!=null) {
					String[] subcommSection =U.getValues(subSec, "class=\"card_list_item", "<div class=\"footer\">");
//					U.log("Subcom length :"+subcommSection.length);
					if(subcommSection.length>0) {
						for(String subComSec:subcommSection) {
							String subComUrl =U.getSectionValue(subComSec, "<h2 class=\"font24 bold OneLinkNoTx\"><a href=\"", "\"");
							subComUrl=BASEURL+subComUrl.replaceAll("^/", "");//   ^/--->starts with
							
//							U.log(">>>>>>>>>>"+subComUrl);
							String subComHtml  = U.getHTML(subComUrl);
							subComHtml=U.getSectionValue(subComHtml,"</title>","</main>");
//							U.log("***********"+subSec);
							String subComSection = U.getSectionValue(subComHtml, "{\"@context\":\"https://schema.org\",\"@type\":\"SingleFamilyResidence\"", "\"telephone\":");
							addDetails(subComSection+subComSec, subComUrl, subComHtml); 
//							break;
						}
					}
				}
				}
				else {
//					U.log(comUrl);
					addDetails(comSec, comUrl, comhtml);
				}
			}
		}
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comSec, String comUrl, String comhtml) throws Exception {
//		if(i>=50) {
		U.log("Count :"+i);
		LOGGER.AddCommunityUrl(comUrl);
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl + "*********REPEATED**********");
			return;
		}
		
		//======================================== SINGLE RUN ======================================================================================================

//		if (!comUrl.contains("https://www.beazer.com/orlando-fl/gatherings-of-lake-nona")) return;
		
		U.log(U.getCache(comUrl));
		
//		U.log("subSec==="+comSec);
		U.log("community URL :"+comUrl);
		if (comUrl.contains("https://www.beazer.com/nashville-tn/osborne-estates/osborne-estates/dogwood")) {
		LOGGER.AddCommunityUrl(comUrl + "\t*********Return******\t");
		return;
	    }
		comhtml=comhtml.replace("&#39;s", "'s").replace("&#174;", "");
		String comName = U.getSectionValue(comhtml,"<h1 class=\"font40 bold uppercase OneLinkNoTx\">","</h1>");
		
		if(comName.contains("Two-Story")) {
			comName = comName.replace(" Two-Story","");
		}
		if(comName.contains(" Villas")) {
			comName = comName.replace(" Villas","");
		}
		if(comName.equals("Windrose Sevilla at IronWing")) {
			comName = "Windrose Sevilla at Ironwing";
		}
		
		U.log("commmunity Name:"+comName);
		//======ADDRESS & LAT-LNG==========
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String note=ALLOW_BLANK;

		add[0]=U.getSectionValue(comSec, "streetAddress\":\"", "\"},");
		add[0]=add[0].replace(" On Boggy Creek Road just West of Tindall Acres Road", "On Boggy Creek Road");
		add[1]=U.getSectionValue(comSec, "addressLocality\":\"", "\",");
		add[2]=U.getSectionValue(comSec, "addressRegion\":\"", "\",");
		if(add[2]==null)
		add[2]=U.getSectionValue(comSec, "addressCountry\":\"", "\",");
		add[3]=U.getSectionValue(comSec, "postalCode\":\"", "\",");
		U.log(Arrays.toString(add));

		
		latlng[0] = U.getSectionValue(comhtml,"data-map-latitude=\"","\""); 
		latlng[1] = U.getSectionValue(comhtml,"data-map-longitude=\"","\"");
		U.log(Arrays.toString(latlng));
		//========AVAILABLE HOMES=========
		String homehtml="";
		String homePlansData="";
		if(comhtml.contains("View Plan")) {
				String avaHomeSec =U.getSectionValue(comhtml, "<div id=\"homeDesigns\" class=\"no-padding\">", "<div class=\"card_list_index\"><span>");
				String[] avaHomes = U.getValues(avaHomeSec, "<h2 class=\"font24 bold\">", "View Plan</a>");
				for(String avaHome:avaHomes) {
					String homeurl=U.getSectionValue(avaHome, "<a href=\"/", "\"");
					homeurl=BASEURL+homeurl;
					U.log("homeurl==="+homeurl);
					homehtml =U.getHTML(homeurl);
					if(homehtml!=null)
					homePlansData +=U.getSectionValue(homehtml, "OVERVIEW</p>", "<div class=\"background-image margin-xlarge\"><");
				}
		}
		//=========Quick MOVE-IN==========
		String QuickhomeSec=U.getSectionValue(comhtml, "<div id=\"quickMoveIns\" class=\"no-padding\">", "</section>");
		String quickhtml="";
		String quickhtmldata="";
		if(QuickhomeSec!=null) {
		String[] QuickHomes=U.getValues(QuickhomeSec, "class=\"info\"", "View Home</a>");
		for(String quickhome:QuickHomes) {
			String quickUrl=U.getSectionValue(quickhome, "<h2 class=\"font24 bold\"><a href=\"/", "\"");
			quickUrl=BASEURL+quickUrl;
			quickhtml =U.getHTML(quickUrl);
			if(quickhtml!=null)
				quickhtmldata +=U.getSectionValue(quickhtml, "OVERVIEW</p>", "<div class=\"background-image margin-xlarge\"><");
//			quickhtmldata=quickhtmldata+quickhome;
		}
		}
		//================ PRICES ==============
		String minPrice =ALLOW_BLANK, maxPrice =ALLOW_BLANK;
		comhtml=comhtml.replace("0s", "0,000").replace(" - ", " - ");
		String [] price = U.getPrices(homePlansData+comhtml+comSec+quickhtmldata, 
				"margin-large\">\\$\\d{3},\\d{3}</div>|Starting from the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}</p>|From \\$\\d,\\d{3},\\d{3}|from \\$\\d{3},\\d{3}</div>|Starting from Low \\$\\d{3}\\d{3}</div>|"
				+ "from Low \\$\\d{3},\\d{3}|from the high \\$\\d{3},\\d{3}|from the mid \\$\\d{3},\\d{3}|from mid \\$\\d{3},\\d{3} to mid \\$\\d{3},\\d{3}|"
				+ "from upper \\$\\d{3},\\d{3}", 0);
		
		minPrice = (price[0]==null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1]==null) ? ALLOW_BLANK : price[1];
//		U.log("MMMMMMM "+Util.matchAll(homePlansData+comhtml+comSec+quickhtmldata  , "[\\s\\w\\W]{200}\\$548,078[\\s\\w\\W]{200}", 0));

		U.log(minPrice + " :: "+ maxPrice);
		//========SQ.FT========
		String minsq =ALLOW_BLANK, maxsq =ALLOW_BLANK;
		comhtml = comhtml.replaceAll("<span class='lbl'>Sq. Ft.", "Sq. Ft.");
		homePlansData=homePlansData.replace("&nbsp;", "").replace(" - ", " - ");
		String [] sqft = U.getSqareFeet((homePlansData+comhtml+comSec+quickhtmldata), "\"sqft\">\\d,\\d{3} Sq. Ft.</span>|</span>\\d,\\d{3} - \\d,\\d{3} Sq. Ft.</span>|</span>\\d,\\d{3} - \\d,\\d{3} Sq. Ft.</li>|</span>\\d,\\d{3} - \\d,\\d{3} Sq. Ft.</div>|\\d2,\\d{3} Sq. Ft.</div>|</span>\\d,\\d{3}|\\d,\\d{3} Sq Ft\"", 0);
		minsq = (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
		maxsq = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
//		U.log("MMMMMMM "+Util.matchAll(comhtml  , "[\\s\\w\\W]{200}1,529[\\s\\w\\W]{200}", 0));

		U.log("minsq: "+minsq+" maxsq: "+ maxsq);
		//============== Derived Community Type ====================
		comhtml=U.removeSectionValue(comhtml, "{\"@context\":\"https://schema.org\",\"@type\":\"SingleFamilyResidence\"", "</script>");
		comhtml = comhtml.replace("charming lake-side community offering", "charming lakeside community offering")
				.replaceAll("&amp; Country Club|Brookstone Golf and Country Club|Pinetree Country Club|"
						+ "Canyon Crest Country Club|&amp; Country Club|Rivertowne Country Club|Dunes West Golf and Country Club|Forest Country Club|Belle Meade Country Club", "");
		
		String ctype = U.getCommunityType(comhtml.replaceAll("Ballard Green [C|c]ommunity|Canyon Crest Country Club|Bentwater Yacht &amp; Country Club|any access gate|gated content form|\"Gated\">|icon gated-community|_gated_container\">|elongated glass", ""));
		U.log("ctype :: "+ ctype);
//		U.log("MMMMMMM "+Util.matchAll(comhtml  , "[\\s\\w\\W]{30}Green Community[\\s\\w\\W]{30}", 0));
		//============== Derived Property Type ====================
		quickhtmldata = quickhtmldata.replace("an open kitchen, and a 2nd-level loft", "an open kitchen, and a two-story loft");
		
		String dType = U.getdCommType((homePlansData.replace("single-story", "One Story")+comhtml+quickhtmldata).replaceAll("exterior rendering of 2-story condos coming soon|SCL - Spanish Colonial|Spanish Colonial A\" class|Valley Ranch|Blackhorse Ranch",""));
//		U.log("MMMMMMM "+Util.matchAll(quickhtmldata  , "[\\s\\w\\W]{200}2nd-level[\\s\\w\\W]{200}", 0));

		U.log("dType :: "+ dType);
		//=============== Property Type ==================
		
		String propType = U.getPropType(homePlansData+comhtml);
		
		U.log("propType :: "+ propType);
//		U.log("MMMMMMM "+Util.matchAll(homePlansData+comhtml, "[\\s\\w\\W]{10}lake[\\s\\w\\W]{10}", 0));
		
		//=============== Property Status =====================
//		comhtml = comhtml.replaceAll(">Coming Soon</span>|Coming Soon</p>|for coming soon|Out Coming Soon\"|Center Coming Soon\"|Park Coming Soon\"|Coming Soon</div>", "")
		comhtml = comhtml.replace("COMING Summer 2022", "Coming Summer 2022")
				.replaceAll("\"value\":\"Coming Soon\"},\"number|\"no-margin\">Coming Soon</p>|(image-flag\">|bold\">)COMING SOON</div>|dates, coming|(More Information|home-price\"></span>) Coming|>Coming Soon\\s*</li>|are now open during|for coming soon|right;\">Coming Soon</span>|Out Coming Soon\"|Center Coming Soon\"|Park Coming Soon\"|(The Lookout|The Hangout|Harvest Park)\\s*Coming Soon</div>|>Coming Soon</span>|-flag\">COMING Summer 2022</div>|bold\">COMING Summer 2022</div>|pool sized lots available</li>|quick-move-ins\" rel|\"#quickMoveIns\">|Quick Move-ins 0|in a closed position", "");
//		String pStatus = U.getPropStatus(comhtml.replaceAll("(description\":\"\\*SOLD OUT\\*|container\">\\s*\\*SOLD OUT\\*|description\">\\*SOLD OUT\\*)\\s*Provence has sold its final|<li>We are sold out!</li>|<p>We are sold out at Provence!|no-margin\">Close Out</p>|(image-flag\">|font13 bold\">|)CLOSE OUT</div>|SERIES CLOSING OUT</div>|home-price\"></span>Close Out</li>|(image-flag\">|font13 bold\">)COMING Spring 2022</div>|\"value\":\"Coming Soon\"}|(top\">|bottom\">)NOW SELLING</h3>|<img alt=\"NOW SELLING\"|(horiz-header\">|vert-header\">)Limited Availability</p>", ""));
		String pStatus = U.getPropStatus((comSec+comhtml.replaceAll("(description\":\"\\*SOLD OUT\\*|container\">\\s*\\*SOLD OUT\\*|description\">\\*SOLD OUT\\*)\\s*Provence has sold its final|<li>We are sold out!</li>|<p>We are sold out at Provence!|(image-flag\">|font13 bold\">)COMING Spring 2022</div>|\"value\":\"Coming Soon\"}|(top\">|bottom\">)NOW SELLING</h3>|<img alt=\"NOW SELLING\"|(horiz-header\">|vert-header\">)Limited Availability</p>", ""))
				.replaceAll("header\">Limited Availability<|brick-front townhomes coming spring 2022|Woodside Place brick-front townhomes coming spring 2022\" /> |</span>Plano Gateway Townhomes Coming Soon</div>|Coming soon - community clubhouse|Jasper Point coming May 2022|pool and pavilion coming soon|More Information Coming Soon|More information on pricing, plans, amenities and launch dates, coming soon", ""));	
		U.log("pStatus :: "+ pStatus);
//		U.log("MMMMMMM "+Util.matchAll(comhtml  , "[\\s\\w\\W]{30}COMING FALL 2022[\\s\\w\\W]{30}", 0));
		
		//------------- Number Of Units -------------------------------------------------------//
		
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		note=U.getnote(homePlansData+comhtml);
		data.addCommunity(comName, comUrl,ctype);
		data.addAddress(U.getNoHtml(add[0]).trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minsq, maxsq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPropertyType(propType,dType );
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		i++;
	}
	//}
}
