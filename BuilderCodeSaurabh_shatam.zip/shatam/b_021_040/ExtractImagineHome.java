package com.shatam.b_021_040;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.jxpath.ri.compiler.Step;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractImagineHome extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	Connection con;
	static int j = 0;
	private static final String builderUrl = "https://www.imaginehomessa.com";

	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new ExtractImagineHome();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Beazer Homes USA - Imagine Homes.csv", a.data().printAll());
	}

	public ExtractImagineHome() throws Exception {
		super("Beazer Homes USA - Imagine Homes  ", "https://www.imaginehomessa.com/");
		LOGGER = new CommunityLogger("Beazer Homes USA - Imagine Homes");
	}

	public void innerProcess() throws Exception {
		// con = testSqlite.ConnectDatabase();
		//String html = U.getHTML("http://www.imaginehomessa.com/neighborhoods.php");
/*		String html=U.getHTML("http://www.imaginehomessa.com");
		//String htmlPart = U.getSectionValue(html, "neighborhoodmap", "Do you already");
          String htmlPart=U.getSectionValue(html,"Overview</a></li>","<li><a href=\"/n-build-green-");
		// U.log(htmlPart);
		//htmlPart = htmlPart.replace("From the 300s</a></p>", "From the 300s</a></p><br>");
		String[] communitiesInfo = U.getValues(htmlPart, "<li><a href=", "</a>");
		// int totalComm = communitiesInfo.length / 2;
		// LOGGER.countOfCommunity(communitiesInfo.length);
		U.log(communitiesInfo.length);
*/		
		String html = U.getHTML("https://www.imaginehomessa.com/n-all-neighborhoods.php");
		String section = U.getSectionValue(html, "class=\"neighborhoodmap\"", "</p>");
		
//		String[] rem = U.getValues(section, "<!--", "-->");
//		
//		for(String remove : rem) {
//			
//			section = section.replace(remove, "");
//		}
//		
//		section = section.replace("<!---->", "");

		String communitiesInfo[] = section.split("<br>");
		
		for (String communityInfo : communitiesInfo) {
			if(!communityInfo.contains("href")) continue;

			  if(communityInfo.contains("<!--4.  CARLSON PARK - <a href=\"/n-carlson-park.php\">Pre-Construction Pricing from $330s.</a> Call 214-733-2669 for information")) { 
				  //System.out.println("Skipped");
				  continue; 
			  }
			  if(communityInfo.contains("<a href=\"n-tobin-hill.php\">From the $450s</a> &mdash; Call 210-805-6232 for information.")) { 
				  //System.out.println("Skipped");
				  communityInfo = "<a href=\"n-tobin-hill.php\">From the $550s</a> &mdash; Call 210-805-6232 for information";
			  }
			
			  String comUrl = U.getSectionValue(communityInfo, "\"", "\"");

			 
			 if(comUrl != null && comUrl.startsWith("/")) comUrl = builderUrl + comUrl;
			 else if(comUrl != null && !comUrl.startsWith("/")) comUrl = builderUrl +"/"+ comUrl;
			 else continue;

			 U.log(comUrl);

			 addDetails(comUrl, communityInfo);
		}
		// testSqlite.closeconnectionconn(con);
		LOGGER.DisposeLogger();
	}

	 
	
	//TODO: Add details here
	private void addDetails(String communityUrl, String communityInfo) throws Exception {
//	if(j==6)
		{
			
	//if(!communityUrl.contains("https://www.imaginehomessa.com/n-highland-estates.php")) return;
			
	//singlke run
//	if (!communityUrl.contains("https://www.imaginehomessa.com/n-highland-estates.php"))return;
	

//			String communityUrl = "http://www.imaginehomessa.com/" + U.getSectionValue(communityInfo, "\"", "\">");
			
			 
			U.log("Hello " + communityInfo);
			
			if (communityUrl.contains("https://www.imaginehomessa.com/n-olympia-hills.php")||communityUrl.contains("n-cottages-at-mahncke-park.php")|| communityUrl.contains("n-monteverde.php"))	return;
			communityUrl=communityUrl.replace(".com//", ".com/");
			
			if (data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl("------------REPEATED-------" + communityUrl);
				return;
			}		
			LOGGER.AddCommunityUrl(communityUrl);
			
			
			
			U.log("\nPAGE :" + communityUrl);


			String html = U.getHTML(communityUrl);

			//============== Community Name ==================
			String commName = U.getSectionValue(html, "<h1 class=\"pagetitle\">", "</h1>");
			commName = commName.replace("New Homes For Sale in ", "");
			U.log(commName);
			
			String rem = U.getSectionValue(html, "<div style=\"display:none;\">", "</div>");
			if(rem != null) html = html.replace(rem, "");
			
			
			//============== Price =======================
			
			String broHtml = "";
			String comm = communityInfo;
			comm = comm.replace("0s", "0,000").replaceAll("from the $400s","from the $400,000");
			html = U.removeComments(html);
			
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;
			String[] price = { ALLOW_BLANK, ALLOW_BLANK };

			String avlUrl = builderUrl + "/available-homes.php";
									
			String avlHtml = U.getHTML(avlUrl);
//			U.writeMyText(avlHtml);
			List<String> sections = matchAll(avlHtml,commName+"</a></td>(.*)</tr>",0);//
			U.log("section--->"+sections.size());
			
			String homeSecs = sections.toString();
			//String homeSecs=U.getSectionValue(avlHtml, "<table id=\"AvailableHomes\"", "</table>");
			communityInfo=communityInfo.replace("Coming Soon!</a>", "").replaceAll("<a href=\"/n-monteverde.php\">From the \\$380,000</a>", "");

			
//						U.log(">>>>>>>>>>>>>"+homeSecs);
			
			
			html=html.replace("will start in the $300", "will start in the $300,000");
		//	U.log("H DSEC+++++++++++++"+comm+"\n==============");
			U.log(Util.matchAll(html + comm+homeSecs, "[\\w\\s\\W]{50}450[\\w\\s\\W]{50}", 0));
			price = U.getPrices(html + comm+homeSecs, "td align=\"center\">\\$\\d{3},\\d{3}</td>|from the \\$\\d{3},\\d{3}|\\$\\d+,\\d+|From the \\d+,\\d+|will start in the \\$\\d{3},\\d{3}|<td>\\$\\d,\\d{3},\\d{3}</td>", 0);
//			U.log(Util.matchAll(html + comm+homeSecs, "[\\w\\s\\W]{10}1812[\\w\\s\\W]{10}", 0));
			U.log("minprice:-"+price[0] + "  " +"maxprice:-"+ price[1]);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//			if(communityUrl.contains("https://www.imaginehomessa.com/n-carlson-park.php"))
//				maxPrice=maxPrice.replace("$513,820","$310,900");

			//============ SQft ============
			
			String AvailableHomehtml=U.getHTML("https://www.imaginehomessa.com/available-homes.php");
			
			String[] homedata=U.getValues(AvailableHomehtml, "<tr valign=\"top\">", "</td>\n" + 
					"            </tr>");
			U.log("homedata = "+homedata.length);
			String Homedata=null;
			
			for(String hdata :homedata)
			{
				if(hdata.contains(commName))
				{
					Homedata +=Homedata;
				}
					
			}
			
			
			
			
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
			
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}2528[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(homeSecs, "[\\w\\s\\W]{30}2528[\\w\\s\\W]{30}", 0));

//			U.log("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"+"\n");
//			U.log(html);
//			U.log("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"+"\n");
			
			
			
			/////////////////////////AVAILABLE FLOOR PLANS Section//////////////////////////////////////////
			
//			U.log("mmmmmm"+Util.matchAll(commhtml+floorplanSec, "[\\w\\s\\W]{30}condo[\\w\\s\\W]{30}", 0));
			//individual homesData
			String availableFloorplan=null;
			String home = null;
			String homeHtml[];
			
			availableFloorplan=U.getSectionValue(html, "<p class=\"internalheader\">AVAILABLE FLOOR PLANS</p>", "</table>");
			//U.log("html: "+html);
			//U.log("AFP: "+availableFloorplan);
			
			if (communityUrl.contains("https://www.imaginehomessa.com/n-tobin-hill.php")) {
				availableFloorplan=U.getSectionValue(html, "MOVE-IN READY HOMES IN THIS NEIGHBORHOOD</p>", "</table>");  
				String[] sectionHome = U.getValues(availableFloorplan, "<tr>", "</tr>");
				  for(String sec : sectionHome) { 
					  if(sec==null)
						  continue;
					  home += sec; 
					  //U.log("home --: "+home);
					  } 
				 }
			  
				if (communityUrl.contains("https://www.imaginehomessa.com/n-palacios-in-cibolo-canyons.php")) {
				  String[] sectionHome = U.getValues(availableFloorplan, "<tr>", "</tr>");
				  for(String sec : sectionHome) { 
					  if(sec==null)
						  continue;
					  home += sec; 
					  //U.log("home --: "+home);
					  } 
				 }
			 
			String[] sectionHome = U.getValues(availableFloorplan, "<tr>", "</tr>");
			for(String sec : sectionHome) {
				String homeUrl = U.getSectionValue(sec, "<a href=\"", "\"");
				if(homeUrl == null)
					continue;
				//U.log("HU: "+homeUrl);
				home += U.getHTML(builderUrl + "/" +homeUrl);
			}
			 
			
			String AvailableFloorplan=null;
			if(communityUrl.contains("highland-estates.php")) //|communityUrl.contains("tobin")
			{
				AvailableFloorplan=U.getSectionValue(html, "<p class=\"internalheader\">AVAILABLE FLOOR PLANS</p> ", " </table>");
				sqft = U.getSqareFeet(AvailableFloorplan+homeSecs, "<td>\\d{4}</td>|<td >\\d{4}</td>|</a></td>\n\\s*<td>\\d+</td>", 0);
			}
			else
			sqft = U.getSqareFeet(html+Homedata, "<td>\\d{4}</td>|<td >\\d{4}</td>|</a></td>\n\\s*<td>\\d+</td>", 0);

			if (sqft[0] == null) sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null) sqft[1] = ALLOW_BLANK;
			if (minSqft == null) minSqft = ALLOW_BLANK;
			if (maxSqft == null) maxSqft = ALLOW_BLANK;
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			
			U.log("******************SQ.FT--->" + minSqft + " " + maxSqft);
			

			//============== Property Status =====================
			
			
			
			// U.log(sqft[0]+" "+sqft[1]);
			String badSec = U.getSectionValue(html, "<table class=\"availablehomes\"", "<p class=\"internalheader\"");
			if (badSec != null)
				html = html.replace(badSec, "");
			if(communityUrl.contains("https://www.imaginehomessa.com/n-palacios-in-cibolo-canyons.php")) {
				html=html.replace("Homes Ready for Immediate Move In", ""); 
			}
			html = html.replace("Ranch Rd", "");
			communityInfo=communityInfo.replace("Coming Soon!</a>", "").replaceAll("Last Opportunity to Own|<a href=\"/n-monteverde.php\">From the \\$380,000</a>", "");
			comm=comm.replaceAll("Coming Soon!</a>", "");
			
			if(html.contains("<table class=\"availablehomes\">")) {
				html = html.replace("<table class=\"availablehomes\">", "MOVE-IN READY");
			}
				
			
			
			String propertyStatus = U.getPropStatus(html.replaceAll("Homes Ready for Immediate Move In","").replaceAll("footerheader\"Move-in Ready Homes|move-in ready homes.\"|Move In Ready Homes in San|Coming Soon!</a>|Plans and pricing coming soon|View available homesites|ready for move-in", "")
					.replaceAll("MOVE-IN READY HOMES IN THIS NEIGHBORHOOD", "").replaceAll("reference\\s+our move-in ready homes.","")
					+ (communityInfo + comm).replaceAll("Last Opportunity to Own",""));
			
			
			
//			propertyStatus = propertyStatus.replaceAll("Coming Soon", "Coming Late Summer 2018");
			/*
			 * if (html.contains("no move-in ready homes")) {
			 * propertyStatus=propertyStatus.replace("Move-in Ready Homes",
			 * "No Move-in Ready Homes"); }
			 */
			
			U.log("STATUS:-------"+propertyStatus);
		//	U.log(Util.matchAll( html+communityInfo+comm, "[\\w\\s\\W]{30}Move-in Ready[\\w\\s\\W]{30}", 0));
			
			/*
			 * if (homeSecs.contains(commName)&&(!propertyStatus.contains("Move-in Ready")))
			 * { if (propertyStatus.length()>2) { propertyStatus+=", Move-in Ready Homes";
			 * }else propertyStatus="Move-in Ready Homes"; }
			 */
			
			html = html.replaceAll("Cottages at Mahncke Park|n-cottages-at", "");
			String[] propSec = U.getValues(html, "<tr valign=\"top\">", "/></a></td>");

			for (String proSec : propSec) {
				// U.log("ProSec=="+proSec);
				String proSec1 = U.getSectionValue(proSec, "<td><a", "target=\"_blank\"");
				// U.log("ProSec1=="+proSec1);
				String broUrl = U.getSectionValue(proSec1, "href=\"", "\"");
				U.log("broUrl" + broUrl);
				broHtml = U.getHTML(broUrl) + broHtml;
				broHtml = broHtml.replace("Resort and TPC Golf Courses", "resort-style and TPC Golf Courses");

			}
			
			
				
			
				
			// U.log("result::"+Util.match(broHtml,".*?hoa.*?"));
			
			
			//============ Property Type =================
			
			
			String remSection = U.getSectionValue(html, "Neighborhoods</a>", "</ul>");
			if(remSection != null) html = html.replace(remSection, "");
			
			html = html.replace("<td valign=\"middle\">Custom</td>", "<td valign=\"middle\">Custom Homes</td>");
			
			String ptype = U.getPropType((homeSecs+html + broHtml + home).replaceAll("commitment to quality and craftsmanship will|Custom Homes San", "")
					.replaceAll("Cottages at Mahncke Park|/n-cottages-at-mahncke", "").replaceAll("<th>Loft</th>", ""));
			//U.log("==="+Util.matchAll((homeSecs+html + broHtml + home), "[\\w\\s\\W]{30}loft[\\s\\w\\W]{30}",0));
			html = html.replace("<li><a href=\"/n-willis-ranch.php\">Willis Ranch</a></li>", "");
			broHtml = broHtml.replace("</strong> <span id=\"stories\">", " ").replaceAll(" 3 bedroom home", "");

			U.log("::::::::::::::::::::::::::::::::"+ptype);
			
			//=================== Derived Property Type =======================
			ArrayList<String> floorList = Util.matchAll(html, "<td>(\\d)</td>\\s+<td>\\$\\d{3},\\d{3}</td>", 1);
			if(floorList.size() == 0) floorList = Util.matchAll(html, "<td>(\\d)</td>Depends on lot</td>", 1);
			//else if(floorList.size() == 0) floorList = Util.matchAll(html, "<td>(\\d)</td>Depends on lot</td>", 1);
			U.log("floorList ::"+floorList);
			
			
			//if(communityUrl.contains("https://www.imaginehomessa.com/n-sunday-creek-at-kinder-ranch.php")) {
				
			//}
			
			String dataHomes = home.replaceAll("<td>2</td>", "2 Story")
									.replaceAll("<td>1</td>", "1 Story");
			 
			if (communityUrl.contains("https://www.imaginehomessa.com/n-palacios-in-cibolo-canyons.php")) 						
				  dataHomes = home.replace("<td>1.5</td>", "1.5 Story").replaceAll("<td>2</td>", "2 Story")
							.replaceAll("<td>1</td>", "1 Story");	

			Set<String> uniqueFloor = new HashSet<>(floorList);
			String floorStoriesConversion = "";
			if(uniqueFloor.size() > 0){
				for(String str : uniqueFloor) floorStoriesConversion += str+" Story, "; 
			}
//			U.log(Util.matchAll( html+communityInfo+comm, "[\\w\\s\\W]{30}resort[\\w\\s\\W]{30}", 0));
			String dtype = U.getdCommType((html + broHtml + dataHomes)
					.replaceAll("Ladera Ranch|floor|Kinder Ranch Elementary|Cable Ranch Rd|Willis Ranch|Sunday Creek at Kinder Ranch|-ranch.php|Kinder Ranch|KINDER RANCH", "")+floorStoriesConversion);
					

			//=================== Community Type =======================
			html=html.replace("Country Resort", "resort-inspired living");
			String commtype = U.getCommunityType(html);

			// ============================= Notes ================
			String note = ALLOW_BLANK;
			
			note = U.getnote(html);
			
			//============================= Address ================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "False";
			String[] latlong = { ALLOW_BLANK, ALLOW_BLANK };
			html = U.removeComments(html);

			if(communityUrl.contains("https://www.imaginehomessa.com/n-carlson-park.php"))
			{
				add[0]="30 Serena Vista";
				add[1]="San Antonio";
				add[2]="TX";
				add[3]="78254";
				geo="TRUE";
				latlong=U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
				
			}
			if(communityUrl.contains("/n-madera-in-cibolo-canyons")){
				add[0] = "24719 Resort Parkway";
				add[1] = "San Antonio";
				add[2] = "TX";
				add[3] = "78261";
			//	note = "Street Is Taken From Neighborhoods Map";
				geo="TRUE";
				latlong=U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getGoogleLatLngWithKey(add);
			}
			
			if(communityUrl.contains("/n-tobin-hill.php")) //|| communityUrl.contains("/n-madera-cibolo-canyons.php")
			{
//				add[0] = "E Courtland Pl & McCullough Ave";
//				add[1] = "San Antonio";
//				add[2] = "TX";
//				add[3] = "78212";
				//note = "Street Is Taken From Neighborhoods Map";
				add[0]="311 E. Evergreen #1";add[1]="San Antonio";add[2]="TX";//add[3]="78205";
				latlong=U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latlong);
				geo="TRUE";
			}
/*			// address section
			String addsec = U.getSectionValue(html, "</h1>", "View available homesites");
			U.log("adddSec::" + addsec + "::adddSec");
			if (addsec != null) {
				addsec = addsec.replace("<span class=\"required\">Limited Availability!</span> <br>", "");
				if (addsec.contains("target=\"_blank")) {
					addsec = U.getSectionValue(addsec, "target=\"_blank\">", "&");
				}
				addsec = addsec.replaceAll(
						"</a>|&#8226; \\(210\\) 807-3560<br>|<p>|<em>|&#8226; \\(210\\) 497-6114 • <span class=\"required\">Now Open!</span><br>",
						"");
				U.log("adddSec::" + addsec + "::adddSec");
				String[] aaa = addsec.trim().split(",");
				if (aaa.length == 3) {
					add[0] = aaa[0];
					add[1] = aaa[1];
					add[2] = Util.match(aaa[2], "\\w+");
					add[3] = Util.match(aaa[2], "\\d+");
				}

				U.log("my address is::" + Arrays.toString(aaa));
			}
*/
			String mapSec = U.getSectionValue(html, ">DIRECTIONS", "</p>");
			U.log("MapSection====\n" + mapSec);
			if (mapSec != null && !mapSec.contains("<span style=\"display:none;\">")) {
				String mapUrl = U.getSectionValue(mapSec, "href=\"", "\" target=");
				U.log("MapUrl====" + mapUrl);
				if (mapUrl != null) {
					String mapHtml = U.getHTML(mapUrl);
					geo="TRUE";
					String latlngSection = U.getSectionValue(mapUrl, "/@", ",18z/");
					
					if (communityUrl.contains("https://www.imaginehomessa.com/n-amorosa.php")) {
						latlngSection = U.getSectionValue(mapHtml, "db2\",", ",0,1]");
						latlngSection = U.getSectionValue(latlngSection, "[null,null,", "]");
						U.log(latlngSection);
					}
					U.log("latlong===" + Arrays.toString(latlong));
					if (latlngSection != null) {
						latlong = latlngSection.split(",");
						U.log(Arrays.toString(latlong));

						add = U.getAddressGoogleApi(latlong);
						if(add == null) add = U.getAddressHereApi(latlong);
					} else {
						latlngSection = U.getSectionValue(mapUrl + mapHtml, "sll=", "&amp");

						if (latlngSection != null)
							latlong = latlngSection.split(",");
						U.log("======Latiude-longitude=====" + Arrays.toString(latlong)+"\n");
						if (latlngSection == null) {
							latlngSection = Util.match(mapUrl, "!3d\\d{2}.\\d{6}!4d-\\d{2}.\\d{6}");
							if (latlngSection != null) {
								latlngSection = latlngSection.replaceAll("!3d", "");
								latlngSection = latlngSection.replaceAll("!4d", ",");
								U.log("lat-long-section::::::" + latlngSection);
								latlong = latlngSection.split(",");
							}else{
								latlngSection = Util.match(mapHtml, "\\+USA/@(\\d{2}.\\d{3,},-\\d{2}.\\d{3,}),",1);
								U.log("latlngSection ==>"+latlngSection);
								latlong = latlngSection.split(",");
							}
						}
					}
					if (latlong[0] == null) {
						latlngSection = U.getSectionValue(mapUrl + mapHtml, "/@", ",17z/");
						if (latlngSection != null)
							latlong = latlngSection.split(",");
						U.log("======Latiude-longitude=====" + Arrays.toString(latlong)+"\n");
						// latlong[0] = ALLOW_BLANK;
						// latlong[1] = ALLOW_BLANK;
					}

					if (latlong[0].contains("37.06")) {
						add[0] = "9022 Summit Lake";
						latlong = U.getlatlongGoogleApi(add);
						if(latlong == null) latlong = U.getlatlongHereApi(add);
						geo = "TRUE";
					}
					if (latlong[0].contains("29.558835")) {
						add[0] = "25902 Turquoise Sky";
						latlong = U.getlatlongGoogleApi(add);
						if(latlong == null) latlong = U.getlatlongHereApi(add);
						geo = "TRUE";
					}
					U.log("\n=========LatLong=========" + latlong[0]+"\n");
					U.log(U.getCache(mapUrl));
/*					if (latlong[0].length() > 4 && add[0].length() < 4) {
						add = U.getAddressGoogleApi(latlong);
						geo = "TRUE";
					}
*/				}
			}

			U.log("street::" + add[0].length() + "::lat::" + latlong[0]);
			if (add[0].length() < 4) {

				// String[] add = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
				String addSec = U.getSectionValue(html, "<h1 class=\"pagetitle\"", "</p>");
				U.log("----------address-section-------" + addSec+"\n");
				String addLine = U.getSectionValue(addSec, "<p>", "&");
				if (addLine != null)
					addLine = addLine.replaceAll("<.*?>|<a href=\"http://goo.gl/maps/fd4Dx\" target=\"_blank\">|</a>|<a href=\"https://goo.gl/maps/gvEf2kJx41S2\" target=\"_blank\">",
							"");
				
				U.log("\naddress line---------" + addLine);
/*				if (addLine == null) {
					addLine = "11467 Huebner Road,San Antonio, TX 78230";
					note = "Address Taken From Contact";
				}
*/				String[] addr = addLine.split(",");
				U.log(Arrays.toString(addr));
				if (addr.length < 3) {
					add[1] = addr[0];
					add[3] = Util.match(addr[1], "\\d{5}");
					add[2] = Util.match(addr[1], "\\w+");
					// add[2] = USStates.abbr(add[2]);
				} else {
					add[0] = addr[0];
					add[1] = addr[1];
					add[2] = Util.match(addr[2], "\\w+");
					add[3] = Util.match(addr[2], "\\d{5}");
					// add[2] = USStates.abbr(add[2]);
				}
				if (add[3] == null) {
					if (addr.length > 3)
						add[3] = addr[3];
				}
				U.log("\nAddress ::"+Arrays.toString(add)+"\n");
//				if(communityUrl.contains("/n-cielos-in-cibolo-canyons.php")){
//					add[0] = "3650 TPC Pkwy"; //address taken from hidden google url from community page
//				}
				/**
				 * address taken from contact us page
				 * @date 20 Dec 2018
				 */
				if(add[0] == ALLOW_BLANK && add[1] != ALLOW_BLANK){
					String contactPage = U.getHTML("https://www.imaginehomessa.com/contact.php");
					contactPage = U.removeComments(contactPage);
					String addressContactSection = U.getSectionValue(contactPage, "Our Neighborhoods</h2>", "</article>");
//					U.log(addressContactSection);
					String [] communityAddressFromContact = U.getValues(addressContactSection, "<h3>", "<br><br>");
					for(String section : communityAddressFromContact){
//						U.log("==> "+section);
						if(section.contains(commName)){
							U.log("==> "+section);
							String street = Util.match(section, "</h3><br>\\s+(.*?)<br>\\s+(.*?)<br>",1);
							String cityZipState = Util.match(section, "</h3><br>\\s+(.*?)<br>\\s+(.*?)<br>",2);
							U.log("Street ::"+street);
							U.log("City ::"+cityZipState);
							if(street != null && cityZipState != null)
								add = U.getAddress(street+", "+cityZipState);
							U.log("Contact Address ::"+Arrays.toString(add));
						}
					}
					
				}
				if(latlong[0].length() < 2 || latlong[0] == ALLOW_BLANK || latlong[0].trim().isEmpty()){
					if(add[0] != ALLOW_BLANK && add[1] != ALLOW_BLANK){
						latlong = U.getlatlongGoogleApi(add);
						if(latlong == null) latlong = U.getlatlongHereApi(add);
						U.log("\n----Google ---lat==" + Arrays.toString(latlong)+"\n");
						geo = "TRUE";
					}
					
				}
				if(latlong[0].length() < 2 || latlong[0] == ALLOW_BLANK || latlong[0].trim().isEmpty()){
					if(add[0] == ALLOW_BLANK && add[1] != ALLOW_BLANK){
						latlong = U.getlatlongGoogleApi(add);
						if(latlong == null) latlong = U.getlatlongHereApi(add);
						U.log("----Google ---lat==" + Arrays.toString(latlong));
						geo = "TRUE";
					}
					
				}
				
/*				if (add[0] == null || add[0] == ALLOW_BLANK) {
					add = U.getAddressGoogleApi(latlong);
				}
*/			}
			// the distance exceeded
	/*		if (latlong[0].length() < 3) {
				latlong = U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
				geo = "TRUE";
				U.log(add[0]);
			}
	*/		
			if (add[3] == null) {
				String add1[] = U.getAddressGoogleApi(latlong);
				if(add1 == null) add1 = U.getAddressHereApi(latlong);
				add[3] = add1[3];
				geo = "TRUE";
			}
			if (communityUrl.contains("https://www.imaginehomessa.com/n-willis-ranch.php")) {
				dtype = dtype + ", 2.5 Story";
			}
			if (communityUrl.contains("/n-madera-in-cibolo-canyons.php")) {
				propertyStatus = propertyStatus + ", Only A Few Homes Available";
			}
			/*
			 * if (communityUrl.contains(
			 * "https://www.imaginehomessa.com/n-sunday-creek-at-kinder-ranch.php")) { dtype
			 * = dtype.replace(", 1.5 Story", "");//dtype = dtype + ", 1 Story"; }
			 */
			if (communityUrl.contains("https://www.imaginehomessa.com/n-estancia.php")||communityUrl.contains("n-highland-estates.php") || communityUrl.contains("n-madera-in-cibolo-canyons.php")) {
				dtype = "1 Story, 2 Story";
			}
			if (communityUrl.contains("https://www.imaginehomessa.com/n-amorosa.php")) {
				ptype = ptype.replace("Garden Home,Luxury Homes,Patio Homes,HOA", "Luxury Homes, Patio Homes");
			}

			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]);
			}

			if (communityUrl.contains("https://www.imaginehomessa.com/n-monteverde.php")) {
				minPrice = "$412,864";
				dtype = "1 Story, 2 Story";
			}
			if(communityUrl.contains("https://www.imaginehomessa.com/n-highland-estates.php")) {
				propertyStatus=propertyStatus.replaceAll(", Move-in Ready Homes", "");
			}
						
			
			data.addCommunity(commName, communityUrl, commtype);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(ptype, dtype);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
			inr++;

		}
		j++;
	}
	
	public static ArrayList<String> matchAll(String html, String expression, int groupNum) {

        Matcher m = Pattern.compile(expression, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(html);


        ArrayList<String> list = new ArrayList<String>();

        while (m.find()) {
            //Util.log(m.group(groupNum));
            list.add(m.group(groupNum).trim());
        }
        return list;

    }
}
