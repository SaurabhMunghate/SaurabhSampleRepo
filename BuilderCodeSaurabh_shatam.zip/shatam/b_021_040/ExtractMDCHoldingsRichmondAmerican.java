/*
 * @ Modification Aditya
 * Date- 20-07-2015
 */

package com.shatam.b_021_040;

import java.io.*;
import java.util.ArrayList;

import org.apache.jasper.tagplugins.jstl.core.Catch;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.SetupApi.SP_DEVICE_INTERFACE_DATA;

public class ExtractMDCHoldingsRichmondAmerican extends AbstractScrapper {
	CommunityLogger LOGGER;
	public static String HOME_URL = "https://www.richmondamerican.com";

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractMDCHoldingsRichmondAmerican();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "M.D.C. Holdings (Richmond American).csv", a.data().printAll());
	}

	public ExtractMDCHoldingsRichmondAmerican() throws Exception {
		super("M.D.C. Holdings (Richmond American)", HOME_URL);
		LOGGER = new CommunityLogger("M.D.C. Holdings (Richmond American)");
	}

	int count = 0;

	public void innerProcess() throws Exception {
		int totalCount = 0;
	//	String html = U.getHTML("https://www.richmondamerican.com/");
		String html = U.getPageSource("https://www.richmondamerican.com/");
	//	U.bypassCertificate();
	//	 U.log(html);
	//	String regionsec = U.getSectionValue(html, "Find a home <i class=\"", "<li><a href=\"");
		// String regionLink[] = U.getValues(regionsec, "<a tabindex=\"-1\" href=\"",
		// "\"");
		String regionsec = U.getSectionValue(html,"Find a home","<a href=\"/design-a-home\">");
//		ArrayList<String> regionLink = Util.matchAll(regionsec, "<li><a tabindex=\"-1\" href=\"(.*?)\">(.*?)</a></li>",
//				1);
		String[] regionLink=U.getValues(regionsec, "<a tabindex=\"-1\" href=\"", "\">");
		U.log("reg links"+regionLink.length);
		for (String region : regionLink) {
			// region = HOME_URL + region;
			U.log(region);
			// U.log(U.getCache(region));
			// if(!region.contains("https://www.richmondamerican.com/"))continue;
			String regionHtml = ALLOW_BLANK;
			//regionHtml = U.getHTML(region);
			regionHtml=U.getPageSource(region);
			
			// String dataSec=U.getSectionValue(regionHtml, "<div
			// class=\"master-plan-wrapper\"", "<div class=\"circlebar top-buffer");
			// U.log("dataSec::"+dataSec);
			String[] links = U.getValues(regionHtml, "<div id=\"community-", "\"compare-info hidden\">");
			U.log("no.s of link:" + links.length);
			totalCount += links.length;
			for (String linkSec : links) {
				// String comUrl = HOME_URL
				// + U.getSectionValue(lin, "<a href=\"", "\"");
				if(linkSec.contains("<div class=\"card-info hidden\">"))linkSec= U.removeSectionValue(linkSec, "<div class=\"card-info hidden\">", "<div class=\"data-status\">");
				
				addDetails(linkSec);
					

			}
			// break;
		}
		LOGGER.DisposeLogger();
		 U.log(totalCount);
	}

	public void addDetails(String linkSec) throws Exception {
//		try {
//		if(count >= 43 && count<=100) //d
//		if(count >100 && count<=200) /s/d
//		if(count >207 && count<=300)//d
//		if(count >=87)
			

			{
				String comUrl = U.getSectionValue(linkSec, "<a href=\"", "\"");
				// TODO : ADd details	
//if(!comUrl.contains("https://www.richmondamerican.com/oregon/portland-metro-new-homes/hillsboro/reed's-crossing"))return;


				if (comUrl.contains(
						"https://www.richmondamerican.com/colorado/northern-colorado-new-homes/fort-collins/mail-creek-crossing")
						|| comUrl.contains("https://www.richmondamerican.com/arizona/phoenix-new-homes/mesa/estates-at-eastmark")
//						||comUrl.contains("https://www.richmondamerican.com/california/inland-empire-new-homes/murrieta/seasons-at-spencer&#39;s-crossing")
						|| comUrl.contains("https://www.richmondamerican.com/colorado/denver-metro-new-homes/thornton/fairfield")
						|| comUrl.contains("https://www.richmondamerican.com/california/inland-empire-new-homes/valley-center/seasons-at-park-circle")) {
					
					LOGGER.AddCommunityUrl(comUrl + "---------------------------------returned");
					return;
				}
				if (comUrl.contains(
						"https://www.richmondamerican.com/colorado/colorado-springs-new-homes/peyton/meridian-ranch-seasons")) {
					comUrl = "https://www.richmondamerican.com/colorado/colorado-springs-new-homes/peyton/seasons-at-meridian-ranch";
				}

				U.log(count + "::::::::::");
				// comUrl = HOME_URL + comUrl;
				U.log(comUrl+"\n"+U.getCache(comUrl));

//				 U.log("linkSec::"+linkSec);
			//	U.log("ComUrl::" + comUrl);
				// U.log(U.getCache(comUrl));
				if (comUrl.contains("&#39;")) {
					comUrl = comUrl.replace("&#39;", "'");
				}

				if (data.communityUrlExists(comUrl)) {
					LOGGER.AddCommunityUrl(comUrl + "---------------------------------repeat");
					return;
				}

//				 if(!comUrl.contains("vegas-new-homes/henderson/legato-at-cadence"))return;

			//	String html = U.getHTML(comUrl);
				String html=U.getPageSource(comUrl);
				
				String comInfo=U.getSectionValue(html, "<h2 class=\"display-font\">\n" + 
						"                        Community information\n" + 
						"                      </h2>", "</div>");

				String headStatus = U.getSectionValue(html, "<p class=\"community-flag\">", "</p>");

				if (html == null) {
					U.log("HTML NULL-----");
					LOGGER.AddCommunityUrl(comUrl + "------------------->RETURN URL");
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);

				String commName = U.getSectionValue(linkSec, "<a href", "/a>");
				commName = U.getSectionValue(commName, "\">", "<").trim();
//				if(!commName.contains("Mayberry at Stewartstown"))return;
				commName=commName.replaceAll(" in Dixon|in Maricopa", "");
				U.log(commName + "---");
				if (commName.contains("Meridian Ranch Seasons"))
					commName = "Seasons at Meridian Ranch";

				String minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;

				// =============================================================================================================================================
				String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
				String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
				
				
				//=====================================================================
				String amenities = U.getSectionValue(html, " <h4>Amenities:</h4>", " </div>");

				// ================== Address =============================
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String addSec = U.getSectionValue(html, "var commJson = [{\"geometry\":{\"", "}]");
				//U.log("adSec::" + addSec);
				
				
//				U.log("MMMMMMMM "+Util.matchAll( html   ,
//						 "[\\s\\w\\W]{30}1804 N. Midland Boulevard[\\s\\w\\W]{30}", 0));
				

				if (addSec != null) {

					addSec = U.getSectionValue(addSec, "</a><br/>\\r\\n ", "<br/><br/>\\r\\n");
					if (addSec != null) {
						addSec = addSec.replace("6589 Grotto Lane, Unit 1", "6589 Grotto Lane").replace("<br/>", ",");
						U.log(addSec);
						addSec=addSec.replace("849 W. Levoy Drive, Suite 220", "849 W. Levoy Drive Suite 220");

						add = addSec.split(",");
						// U.log("result::"+Arrays.toString(add));
						street = add[0].trim();
						city = add[1].trim();
						state = Util.match(add[2], "\\w+");
						if (state.trim().length() > 2)
							state = USStates.abbr(state);
						zip = Util.match(add[2], "\\d+");
//						if(comUrl.contains("st.-george-new-homes/st.-george/black-ridge-cove"))
//						street=street.replace("849 W. Levoy Drive, Suite 220", "849 W. Levoy Drive Suite 220");
						
						U.log("my address is ::" + street + "::" + city + "::" + state + "::" + zip);
					}
				}

				// ================ LatLng ======================
				// String add[] = { street, city, state, zip };
				String latlng[] = { ALLOW_BLANK, ALLOW_BLANK };
				String Geo = "FALSE";
				String latlngSec=U.getSectionValue(html, "href=\"https://maps.google.com?layer=t&amp;q=", "\" target");
				U.log("latlngSec==="+latlngSec);
				if(latlngSec!=null) {
				latlng=latlngSec.split(",");
				U.log("latlng[0] ==="+latlng[0]+ "   "+latlng[1]);
				}
				else if(latlngSec==null) {
				
				latlng[0] = U.getSectionValue(html, "community_latitude =", ";");
				if (latlng[0] == null)
					latlng[0] = ALLOW_BLANK;
				else
					latlng[0] = latlng[0].trim();
				latlng[1] = U.getSectionValue(html, "community_longitude =", ";");
				if (latlng[1] == null)
					latlng[1] = ALLOW_BLANK;
				else
					latlng[1] = latlng[1].trim();
				}
				
				if (add[0] != ALLOW_BLANK && add[1] != ALLOW_BLANK && latlng[0] == ALLOW_BLANK) {
					latlng = U.getlatlongGoogleApi(add);
					if (latlng == null)
						latlng = U.getlatlongHereApi(add);
					Geo = "TRUE";
				}
				if (latlng[0].contains("0.000000")) {
					latlng = U.getlatlongGoogleApi(add);
					if (latlng == null)
						latlng = U.getlatlongHereApi(add);
					Geo = "TRUE";
				}
				

				if (comUrl.contains(
						"https://www.richmondamerican.com/arizona/phoenix-new-homes/san-tan-valley/skyline-ranch/")) {
					// distance exceeded so taken address using latlng
					add = U.getAddressGoogleApi(latlng);
					if (add == null)
						add = U.getAddressHereApi(latlng);
					street = add[0].trim();
					city = add[1].trim();
					state = add[2].trim();
					zip = add[3].trim();
					Geo = "TRUE";
				}
				
				if(add[0].length()<3 || street.length()<3) {
					
					add = U.getAddressGoogleApi(latlng);
					if (add == null)
						add = U.getAddressHereApi(latlng);
					street = add[0].trim();
					city = add[1].trim();
					state = add[2].trim();
					zip = add[3].trim();
					Geo = "TRUE";
				}
				

				
				
				
				// ============ Notes =================
				String noteVar = U.getnote(html);

				// ============ Address ================
				String addrs[] = { street, city, state, zip };

				if (street != null)
					street = street.replace("<div style=\"padding-bottom:10px;\">", "");

				String remove = "&amp;|&#189;|&#39;s";
				if (street != null)
					street = street.replaceAll(remove, "");

				if (latlng[0] == ALLOW_BLANK && street != ALLOW_BLANK && zip != ALLOW_BLANK) {
					String addrss[] = { street, city, state, zip };
					latlng = U.getlatlongGoogleApi(addrss);
					if (latlng == null)
						latlng = U.getlatlongHereApi(add);
					Geo = "TRUE";
				}
				if (street == ALLOW_BLANK && latlng[0] != ALLOW_BLANK) {
					String[] addrss = U.getAddressGoogleApi(latlng);
					if (addrss == null)
						addrss = U.getAddressHereApi(latlng);
					street = addrss[0];
					city = addrss[1];

					state = addrss[2];

					zip = addrss[3];
					Geo = "TRUE";
				}
//				if(comUrl.equals("https://www.richmondamerican.com/idaho/boise-new-homes/star/urban-collection-at-norterra"))
//				{
//					latlng = U.getlatlongHereApi(add);
//					Geo = "TRUE";
//					
//				}
					if (street != null)
					street = street.replaceAll(remove, "");
				U.log("latlng:::" + latlng[0] + ":::" + latlng[1]);
				if (latlng[1] == null) {
					latlng[0] = ALLOW_BLANK;
					latlng[1] = ALLOW_BLANK;
				}
				if (!latlng[1].contains("-"))
					latlng[1] = "-" + latlng[1];

				// ============= Remove Meta tag ==========================
				// Some prices coming from meta tag.
				String headContent = U.getSectionValue(html, "<head>", "</head>");
				if (headContent != null)
					html = html.replace(headContent, "");

				// *****************************Price*********************************************
				String modelHomeDataSecs[] = U.getValues(html,
						"<div class=\"data-card col-xs-12 col-sm-6 col-md-4 selectProduct\"",
						"<div class=\"image-card\">");
				String allHomesData = "";
				for (String modelHomeDataSec : modelHomeDataSecs) {
					// U.log(modelHomeDataSec);
					String modelHomeURl = U.getSectionValue(modelHomeDataSec, "href=\"", "\"");
					if (modelHomeURl.trim().length() == 0) {
						continue;
					}
				//	U.log(modelHomeURl);
					
					if (modelHomeURl.length() > 30) {
					//	String tempHtml = U.getHTML(modelHomeURl);
						String tempHtml=U.getPageSource(modelHomeURl);
						allHomesData += U.getSectionValue(tempHtml, "<div class=\"data-info-col data-plan\">","<div class=\"community-actions\">")
								+U.getSectionValue(tempHtml, "<h2 class=\"col-xs-12 display-font\">\n" + 
										"                  Plan information\n" + 
										"                </h2>", " <div id=\"recentlyViewedList\">");
					}
				}
//				sU.log(allHomesData);
				String[] Prices = { ALLOW_BLANK, ALLOW_BLANK };
				html = html.replace("PlanBasePrice\">Base price: $661", "").replace("$1.5 million+", "$1,500,000")
						.replace("Coronado: $661,075", "").replace("ing-type-id=\"MFS\">Coronado: $661,075", "")
						.replaceAll(
								"Finished sq. ft. 1,790|providing 24,200 sq. ft.|42,000 sq. ft. rec|more from the mid \\$200s|from the upper \\$200s",
								"")
						.replace("$2.2 million", "$2,200,000<br /><span>Base price");
				html = html.replaceAll("0s", "0,000").replace("$1.1 million", "$1,100,000 million").replace("$1 million+", "$1,000,000")
						.replace("1.3 million", "1,300,000").replace("$1.2 million+", "$1,200,000 million+");

				html = html.replace("\r\n", " ");
				linkSec = linkSec.replace("\r\n", "");
				linkSec = linkSec.replace("00s", "00,000");
				html = html.replaceAll("itemprop=\"price\">", "itemprop=\"price\">\\$").replaceAll("communityMinPrice = '\\$\\d+,\\d+';|communityMinPrice = 'Mid \\$\\d+,\\d+'", "").replaceAll("\\s{2,}", "");

				String quick = U.getSectionValue(html, "<section class=\"inner nostyle\">",
						"<div class=\"paymentDisclaimers\">");
				String floorplan= U.getSectionValue(html, "<ul class=\"floorplans top-buffer\">", "<div class=\"clearfix\"></div>");
				String disc = U.getSectionValue(html, "<meta name=\"description\"", "<link rel=\"canonical\"");
				if (disc != null)
					html = html.replace(disc, "");
				// U.log("ressult:::"+U.getSectionValue(html, "Plans starting at:",
				// "<span>Bed</span>"));
				// U.log("Region Sec:::"+linkSec);
				
				if(comUrl.contains("tucson-new-homes/tucson/high-mesa"))
					html=html.replace("communityMinPrice = 'Upper $300,000", "");
				

//				if(comUrl.contains("baltimore-metro-new-homes/odenton/the-heritage-at-two-rivers"))
//					linkSec=linkSec.replaceAll("<div class=\"col-xs-12\">\n\\s*Low $800,000", "");
				
				
					
				
				String[] price = U.getPrices(html + linkSec + quick+floorplan, "\\$\\d,\\d{3},\\d{3} million\\+|:\\s+\\$\\d{3},\\d{3}|\\$[\\d,]*\\d{3},\\d{3}|Base price: \\$\\d{3},\\d{3}|: \\$\\d{3},\\d{3}",
						0);
				
//				if(comUrl.contains("baltimore-metro-new-homes/odenton/the-heritage-at-two-rivers"))price[0]=ALLOW_BLANK;

				
//				U.log("MMMMMMMM "+Util.matchAll( quick   ,
//						 "[\\s\\w\\W]{30}800[\\s\\w\\W]{30}", 0));
				
				// Base price:
				// \\$\\d,\\d{3},\\d{3}|\\s*:\\s*\\$\\d{3},\\d{3}\\s*</a>|\\$\\d,\\d{3},\\d{3}\\s*<br\\s*/><span>Base
				// price|Base
				// price\\s*[:]*\\s*\\$(1,)*\\d{3},\\d{3}|\\$(1,)*\\d{3},\\d{3}<br/><span>Base
				// price|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}<br /><span>Base price|Base price:
				// \\$\\d{3},\\d{3}
				Prices[0] = (price[0] == null) ? ALLOW_BLANK : price[0];
				Prices[1] = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:" + Prices[0] + "\tmaxPirce:" + Prices[1]);

				//
				// *****************************************SQUAREFEET**************************************************************

				// U.log("sqftSEC===" + U.getSectionValue(html, "Approx", "span>"));
				html = html.replaceAll("Approx. sq. ft.<br />\n*\\s+", "Approx. sq. ft.<br />")
						.replaceAll("Finished sq\\. ft\\. 1,790|\\d+,\\d+ sq\\. ft\\. clubhouse", "");
				String sqFt[] = U.getSqareFeet(
						(linkSec+html + quick).replaceAll("communitySquareFeet = '\\d,\\d{3} - \\d,\\d{3}';|Approx\\. 23,200 sq\\. ft|4,600 sq. ft. community center", "")
								.replace("Fitness, a 10,000 sq. ft.", "").replace("6,000 sq. ft. rec center", ""),
						"\\d,\\d+ to \\d,\\d+ square feet|Approx. \\d,\\d+ - \\d,\\d+|Approx\\. \\d,\\d{3} sq\\. ft|Approx. sq. ft.<br />\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}\\s+<br/><span>Approx. sq. ft.</span>|\\d,\\d+ - \\d,\\d+\\s*<br />\\s*<span>\\s*Approx. sq. ft.</span>|\\d,\\d{3} - \\d,\\d{3}\\s*<br /><span>Approx. sq. ft.</span>|Approx. \\d+,\\d+ – 0 sq. ft.|Approx. \\d+,\\d+ – \\d+,\\d+ sq. ft.|Approx. \\d+,\\d{3} – \\d+,\\d{3} sq. ft.|\\d+,\\d+ to \\d+,\\d+ sq. ft|\\d+,\\d+ sq. ft|<span class=\"\">\\d+,\\d+<|Approx\\. <span>.*?</span>|\\d+,\\d+ � \\d+,\\d+ sq. ft|\\d+,\\d+\\s*-\\s*\\d+,\\d+<br/><span>Approx. sq. ft.|\\d,\\d+\\s*<br /><span>Approx. sq. ft| approx. \\d,\\d{3} sq. ft|communitySquareFeet = '\\d,\\d{3} - \\d,\\d{3}'|communitySquareFeet = \'\\d,\\d{3}\'|up to approximately \\d,\\d{3} square feet",
						0);
//				U.log("?MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(linkSec , "[\\s\\w\\W]{30}Approx. 2[\\s\\w\\W]{50}", 0));

				minSq = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
				maxSq = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
				U.log("minSq:" + minSq + "\tmaxSq:" + maxSq);
				
				// *******************************************************************************************************

				String propertyType = ALLOW_BLANK;
				String remove1 = U.getSectionValue(html, "<input id=\"autoCompleteData", "<div class=\"nav-holder\">");

				if (remove1 != null) {
					html = html.replace(remove1, "");
					U.log("::::::::remove1:::::::::::::");
				}

				// U.log(temp);
				// ==================== Property Status =====================
				String pStatus = ALLOW_BLANK;
				// html = U.getHTML(comUrl);

				html = html.replaceAll(
						"div class=\"col-xs-12 col-sm-10\">Base price<br/>\\s+Coming soon\\s+</div>|The following models are open or coming soon:|available for a limited time only|Act fast—limited|: Coming soon|models are open or coming|price: Coming|Model home</a> now open|Currently selling from our Sales Center|ready for move in:</h4>|find quick move in homes in|Grand opening April |ncallout\">Coming soon|This move-in ready|Quick|Price coming soon|Grand Opening BBQ in Green Valley|Community Grand Opening in Jacksonville|Grand Opening celebration at Providence",
						"");

				String ComDetails = U.getSectionValue(html, "<div class=\"col-sm-8 left-column-holder\">",
						"<input type=\"hidden\" data-category=\"Community");
				if(ComDetails == null) ComDetails = U.getSectionValue(html, "<div class=\"col-sm-8 left-column-holder communityPage\">",
						"<input type=\"hidden\" data-category=\"Community");

				linkSec = linkSec.replace("Price coming soon", "")
						.replaceAll("<div class=\"col-xs-12\">\n*\\s*\\n*Coming soon", "");
		

				linkSec = linkSec.replaceAll(
						"find quick move in home in Phoenix|<p>\\s*Coming soon\\s*</p>|<div class=\"data-details\">\\s*Coming soon|quick move in homes in Phoenix",
						"");
				String remData = "Now selling out of of |<div class=\"data-status\">\\s*<p>\\s*Sold out!\\s*</p>|Coming soon bed|Coming soon sq. ft.|: Coming soon|>Coming soon\\s*<br/>\\s*<span>\\s*Base price\\s*</span>| Approx. Coming soon|Base price: Coming soon|Model coming soon|Model coming soon|NOW AVAILABLE: Plans|Currently selling from another location|Coming soon sq\\. ft|: Coming soon|Grady: Coming soon</a>|data-status\">\\s*Coming soon\\s*</div>|Lance: Coming soon|data-details col-sm-12\">Coming soon|<div class=\"data-details\">\\s*Coming soon|Coming soon<br/><span>Base price|Model coming soon</div>|Coming soon<br /><span>Base price|Base price: Coming soon|Greenbelt lots available|find quick move in homes in|Move-in ready with backyard landscaping|Price coming soon|Grand opening April|are currently selling|Ready to move-in|Final opportunity plan|>Limited Availability<|Grand Opening BBQ in Catonsville|Sales center now open|Model now open|Sales Center now open|2 Community Grand Openings|move-in";
				if (ComDetails != null) {
					ComDetails = ComDetails.replaceAll(remData, "");
					linkSec = linkSec.replaceAll(remData, "");
					ComDetails = ComDetails.replaceAll(
							"The following models are open or coming soon:|>Limited availability!<|open or coming soon|Coming soon<br|Sales Center coming soon|communityMinPrice = 'Coming soon'|<div class=\"data-details\">\\s*Coming soon|<p>\\s*Coming soon\\s*</p>|with floor plans now",
							"").replace("Selling out ly</p>", "Selling out quickly</p>");
				} else {
					ComDetails = "";
				}
				// U.log(ComDetails);
				String homeStatusSec[] = U.getValues(html, "<div class=\"data-status\">", "</div>");
				for (String stat : homeStatusSec) {
					ComDetails = ComDetails.replaceAll(stat, "");
				}
			
				

				String details = U.getSectionValue(html, "Community information", "</button>");
				
//==================================================================================New homesites available in early 2022
				

//				ComDetails=ComDetails.replace("New homesites available in early 2022", "New homesites available early 2022");

				pStatus = U.getPropStatus((ComDetails + linkSec + headStatus + details.replace("Selling ly", "Selling quickly"))
						.replaceAll("Limited-time offer|<p class=\"community-flag\">\\s*Limited-time offer\\s*</p>|communityStatusDescription:\\s*'Limited-time offer'|Bed count<br/>Coming soon|with a pool, coming soon!|Base price<br/>Coming soon</div>|Models for sale coming soon|New homesites coming Winter 2021|<h3>Limited-time offer in Commerce City|pool, coming soon|otherwise sold-out|Now selling&nbsp;<a hre|Final opportunity plan|Now selling from <a href|<div class=\"data-status\"><p>Sold out!</p>|Model homes are coming soon|updates for Vista Del Verde II, coming soon|status changes\\. Now selling from|Models coming Spring|[Q|q]uick [M|m]ove|<p class=\"community-flag\">\\s*Limited-time offer\\s*</p>|<div class=\"col-xs-12 col-sm-10\">(Base price|Bed count)<br\\s?/>\\s+Coming soon</div>|<div class=\"data-status\"><p>Limited availability</p>|contemporary floor plans &amp; our limited-time offer|<p class=\"PlanBasePrice\">Limited availability!</p>|is now open, and includes a community|nt/1599\"><h3>Community Grand Opening in Renton</h3>| <p class=\"PlanBasePrice\">(.*?)</p>|Collection™ now selling|open or coming|clubhouse is coming|Model coming|Coming soon bed|class=\"data-status\">\\s*<p>\\s*Coming soon|homes open for|this community is currently",
								"")
						.replace("or coming soon", "")
						.replace("New phase of homesites now selling", "New phase now selling"));
			
				pStatus=pStatus.replace("New Homesites Coming Soon, New Homesites Coming Spring 2022", "New Homesites Coming Spring 2022");
				U.log("prop Status=="+pStatus);
//				 U.log(">>>>>>>>>>>>>>>>"+Util.matchAll(ComDetails + linkSec + headStatus + details,"[\\s\\w\\W]{50}2022[\\s\\w\\W]{50}",0));

				html = U.getHTML(comUrl);

//				String quickSec = U.getSectionValue(html,
//						"<div role=\"tabpanel\" class=\"tab-pane fade\" id=\"QMIsSection\">", "<div class=\"circlebar");
//				U.log("pStatus.length()"+pStatus.length());
				
//				String quickSec = U.getSectionValue(html,
//						"<!--QMIS-->","<div class=\"clearfix\"></div>");
				String quickSec = U.getSectionValue(html,"id=\"QMIsSection\">","<div class=\"clearfix\">");
			//	U.log("QQQ>>>>>>>>"+quickSec);
				String[] quicksec=null;
				if(quickSec!=null) {
					quicksec=U.getValues(quickSec, "<div class=\"data-title\">", "View Home Details");
			        U.log("LENGTH:::::::::::"+quicksec.length);
				}
				else
					quickSec=null;
				
				
//				if (!pStatus.contains("Quick ")) {
//
//					if (html.contains("Quick move-in homes (0)")|| html.contains("move-in homes (0)")
//							|| !html.contains("<a class=\"tab3 btn btn-default\" href=\"#QMIsSection\"")) {//
//						pStatus=pStatus;
////						if (pStatus.length() > 2)
////							pStatus = pStatus + ", No Quick move In homes";
////						else
////							pStatus = "No Quick move In homes";
//
//					} else  {
//						if (pStatus.length() > 4)
//							pStatus = pStatus + ", Quick move In homes";
//						else
//							pStatus = "Quick move In homes";
//					}
//				}
			if( quicksec!=null && quicksec.length>0 ) {
			if (pStatus.length() > 4)
				pStatus = pStatus + ", Quick move In homes";
			else
				pStatus = "Quick move In homes";
			}
			
			

				//
				if (pStatus.contains("Quick Move-in Homes")) {
					pStatus = pStatus.replace("Quick Move-in Homes", "Quick move In homes");
				}
				// =============== Community Type ========================
				String communityType = ALLOW_BLANK;

				String script = U.getSectionValue(html, "var commJson = [{", "</htm");

				String rem = U.getSectionValue(headContent, "var community_name", "</script>");
				if (rem != null)
					html = html.replace(rem, "");
				String imput = U.getSectionValue(html, "<input id=\"autoCompleteData\" type=\"hidden\" value=\"",
						"<script");
				String remove2 = "south salt lake community|bonney lake community|masterplan&quot|masterplan\"|anthem country club|golf club</span>|golf club\"|pinery country club|country club\"|country club<|blackstone country club|golf course</span>|golf course\"|gran lake community|(prado|foxtail|carlton|gallery|tree|pines) golf|the golf club|golf course dr|crossing masterplan";
				
				if(comUrl.contains("baltimore-metro-new-homes/owings-mills/red-run-reserve")) {
					html=html.replaceAll("Francis Scot Key Golf Club|Green Spring Valley Hunt Club Golf Course", "");
					allHomesData=allHomesData.replaceAll("Francis Scot Key Golf Club|Green Spring Valley Hunt Club Golf Course", "");
				}
				
				communityType = U.getCommunityType(comInfo+
						(ComDetails + linkSec + comUrl + amenities + html.replace(imput, "").replace(script, "")).replaceAll(
								"\\| Plumas Lake Community|Topgolf|Boasting miles of beautiful lakefront|Southlands Mall and area golf courses|content=\"Enjoy lakeside living at Southshore|master suite|master-planned amenities|masterplan&",
								"").toLowerCase().replaceAll(remove2, "")
								.replace("gated, master-planned new home community ",
										"gated community, master-planned new home community "));
				U.log("communityType==="+communityType);
				
				// ================= Property Type =======================
				// TODO : Property Type
				
				html = html.replaceAll(" spacious loft | roomy loft|versatile loft ", "Loft Homes");
				String remSection = U.getSectionValue(html, "<input id=\"autoCompleteData",
						"<div class=\"nav-holder\">");
				if (remSection != null)
					html = html.replace(remSection, "");
				String remContent = " 'Loft in| alt=\"Loft|ernateText: 'New duplexes |,\"name\":\"Streetscape-SerenityRidge Duplex\"|aption\":\"Streetscape-SerenityRidge Duplex\"|\"description\":\"New duplexes at The Park at Serenity Ri|alt=\"New duplexes|no HOA fees!|<li>No HOA fee</li>|&quot;Villa Point|&quot;Stirling Manor|alt=\"Loft|Villa City Road|(V|v)illas&quot|(V|v)illas (a|A)t|Villas</a>|Village|Duplex-|Traditional School|(V|v)illage|luxurious deluxe|luxury master suite|luxurious bath|luxurious gourmet kitchen|uxurious upper-level master bedroom|MYD-Patio|Villa (Par|Nueva)"
						+ "|Chandler(-|\\s)Traditional|Estates\"|estates\'|Estates</a>|real-?estate|-estates\\/|Stirling Manor";
				html = html.replaceAll(remContent, "").replaceAll("<meta (name|property)=(.*?)>", "");
//				 U.log(Util.matchAll(html.replaceAll("Legacy-Traditional-Schools|Legacy Traditional Schools|co_patio|'Loft in| alt=\"Loft|description\":\"Loft in", ""), ".*Traditional.*", 0));
				if(comUrl.contains("washington-dc-metro-new-homes/capitol-heights/gateway-park"))
					html=html.replaceAll("Country Club at Woodmore", "");
				
				html=html.replace("\"title\": \"Green Valley Ranch Resort and Spa|  <span class='infoBoxTitle'>Green Valley Ranch Resort and Spa</span>", "");
				html=html.replaceAll("new-homes/florence/crestfield-manor-ii'>Crestfield Manor II</a><br/>|\"title\":\"Crestfield Manor II", "");
				propertyType = U.getPropType(
						(html.replace("This unique line-up of paired-home floor plans offers versatility", "This unique line-up of paired home floor plans offers versatility")
								.replace(" luxurious new community", "luxuries new community") + allHomesData.replace("enjoy an airy loft", "enjoy an airy lofts and") + commName.replaceAll("(V|v)illage", "")).replaceAll("No HOA fee|title\":\"Crestfield Manor II|Legacy-Traditional-School|Legacy Traditional School|co_patio|'Loft in| alt=\"Loft|description\":\"Loft in|alt=\"Patio ", ""));
			
				if(comUrl.contains("baltimore-metro-new-homes/owings-mills/red-run-reserve")) propertyType=ALLOW_BLANK;

				
//				 U.log(">>>>>>>>>>>>>>>>"+Util.matchAll(html.replace(" luxurious new community", "luxuries new community") + allHomesData + commName,"[\\s\\w\\W]{30}paired-home floor plans offers versatility[\\s\\w\\W]{50}",0));

				
				 U.log("propertyType=="+propertyType);
				// ============== Derived Property Type ===========================
				String derivedPType = ALLOW_BLANK;
//				 U.log("aaaaaaa"+Util.match(html, ".*? <i class=\"ico ico-floors\"></i> Ranch</li>"));

				String remNearByCom = U.getSectionValue(html, "$(\".NearbyCommunitiesMap", "</script>");
				if (remNearByCom != null) {
					html = html.replace(remNearByCom, "");
					U.log(":::::::::::remNearByCom:::::::::::");
				}
				html = U.removeSectionValue(html, "<input id=\"autoCompleteData", "<div class=\"nav-holder\">");

				html = html.replace("<i class=\"ico ico-floors\"></i> Ranch</li>", "ranch condominium")
						.replaceAll(
						"12587 Eagle Ranch Pkwy|Eagle Ranch Park|Highlands Ranch|highlands ranch|ranch and two-story floor plans with hundreds of exciting options.\" />|alt=\"Patio |&quot;Highlands Ranch|[R|r]anch&quot|Ranch III&quot|Ranch North&quot|with first floor recreation|single-floor| single-floor appeal|plan's single-floor|Grand Opening in Lehi: Newman Ranch</h3>|Rogers Ranch|Craig Ranch Regional Park|Highlands Ranch|Rancho|Ranch&quot|Rio Ranch|Vail Ranch|Timnath Ranch|Rhodes Ranch|Rancho| ranch&|Cottonwood Ranch|Tamaron Ranch|-ranch-|rancho",
						"");
//				U.log("?MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html + commName, "[\\s\\w\\W]{30}ranch[\\s\\w\\W]{30}", 0));

//				U.log(Util.match(html, ".*Ranch.*"));
				derivedPType = U.getdCommType(html + commName);

				// U.log(html+" kkkk");
				commName = commName
						.replaceAll(" by Richmond American|Country Club|<span id=\"headerLocation\">|</span>|\\.", "");
				street = street.replaceAll("\\.", "");

				// if(count==237)propertyType=propertyType.replace("Villas,", "");

				// city missmatchd using page latlong
				if (comUrl.contains(
						"http://www.richmondamerican.com/Florida/Jacksonville-new-homes/Orange-Park/Forest-Hammock-at-Oakleaf-Plantation/")) {
					latlng = U.getlatlongGoogleApi(addrs);
					if (latlng == null)
						latlng = U.getlatlongHereApi(addrs);
					Geo = "TRUE";

				}
				/**
				 * @date 20 Dec 2018
				 */
				/*
				 * if (comUrl.contains(
				 * "https://www.richmondamerican.com/colorado/denver-metro-new-homes/aurora/estates-at-inspiration"
				 * )) pStatus = pStatus + ", Now Selling";
				 */
				U.log("************" + pStatus);
				if (html.contains("t/campaigns/media-28839.png") && !pStatus.contains("Grand Opening")) {
					pStatus += ", Grand Opening";
				}
				pStatus = pStatus.trim();

				pStatus = pStatus.replace("New Lots Coming Soon, Coming Soon", "New Lots Coming Soon");
				
				//if(comUrl.contains("https://www.richmondamerican.com/arizona/tucson-new-homes/tucson/rancho-cascabel"))pStatus = pStatus.replace("Coming Soon", "Coming This Summer");;
				// commName=commName.replace("Villas","");
				if (pStatus.length() < 5)
					pStatus = ALLOW_BLANK;
//				if(comUrl.contains("washington-dc-metro-new-homes/capitol-heights/gateway-park"))communityType=ALLOW_BLANK;
//				if(comUrl.contains("vegas-new-homes/henderson/legato-at-cadence"))communityType=communityType.replace("Resort Style, ", "");

//				if(comUrl.contains("https://www.richmondamerican.com/arizona/phoenix-new-homes/florence/crestfield-manor-ii"))pStatus = pStatus+", Final Opportunity";
//				if(pStatus.contains("Coming Winter 2021, New Homesites Coming Soon"))pStatus="New homesites coming Winter 2021";

				data.addCommunity(commName.replace("Sales Center",""), comUrl, communityType);
				data.addAddress(street.replaceAll("/", " ").toLowerCase().trim(), city.trim(), state.trim().toUpperCase(), zip.trim());
				data.addSquareFeet(minSq, maxSq);
				data.addPrice(Prices[0], Prices[1]);
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), Geo);
				data.addPropertyType(propertyType, derivedPType);
				data.addPropertyStatus(pStatus);
				data.addNotes(noteVar);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);

			}

			count++;

//		} catch (Exception e) {}
	}
}
