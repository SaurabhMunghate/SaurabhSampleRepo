/*
 * @Modified MJS
 * @date 21/08/19
 * Modification Sahil...
 */

package com.shatam.b_021_040;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.bcel.generic.DDIV;
import org.apache.regexp.recompile;
//import org.openqa.jetty.html.Link;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;


public class ExtractWilliamLyonHomes extends AbstractScrapper {
	public static CommunityLogger LOGGER;
	public static int i;
	static String  cUrl=null;
	static HashSet<String> set=new HashSet<String>();
	
	public ExtractWilliamLyonHomes() throws Exception {
		// TODO Auto-generated constructor stub
		super("William Lyon Homes","https://lyonhomes.com");
		LOGGER= new CommunityLogger("William Lyon Homes");
	}
	
	
	

	public static void main(String[] args) throws Exception{
		AbstractScrapper a= new ExtractWilliamLyonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"William Lyon Homes.csv", a.data().printAll());
		U.log("Repeated-->"+i);
		LOGGER.DisposeLogger();
	}

	public static String getRedirectedURLConnection(String url) throws IOException{
		String newUrl=null;
		URL obj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
		int status = conn.getResponseCode();
		if (status != HttpURLConnection.HTTP_OK) {
			if (status == HttpURLConnection.HTTP_MOVED_TEMP
				|| status == HttpURLConnection.HTTP_MOVED_PERM
					|| status == HttpURLConnection.HTTP_SEE_OTHER){
				newUrl = conn.getHeaderField("Location");
			}
			return newUrl;
		}
		else
		return url;

	}
	
	public static String getHardcodedAddress(String comUrl)
			throws Exception {
		cUrl = comUrl;
		String newFile = System.getProperty("user.home")+"/Harcoded Builders/Lyon Homes.csv";
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {
			if (count > 0) {
				// U.log(newCsvRow.size());
				// builderName=newCsvRow.get(1);
				String aaa = getBuilderObj(newCsvRow);
				if (aaa != null){
					return aaa;
				}
			}
			count++;
		}

		newFileReader.close();
		return null;
	}

	public static String getBuilderObj(List<String> newCsvRow) {

		if (cUrl.equals(newCsvRow.get(4).trim())) {
	
				return (
				      newCsvRow.get(5).trim() + ","+ newCsvRow.get(6).trim() + "," 
				      + newCsvRow.get(7).trim() + ","+ newCsvRow.get(8).trim() + "," 
				      + newCsvRow.get(9).trim() + "," + newCsvRow.get(10).trim()+ "," +newCsvRow.get(11).trim()
						);
		}
		return null;

	}

	public static String formatMillionPrices(String html){
		Matcher millionPrice = Pattern.compile("\\$\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
		
			Matcher millionPrice1 = Pattern.compile("\\$\\d.\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice1.find()){
			U.log(millionPrice1.group());
			String floorMatch = millionPrice1.group().replace(" Millions", "00,000").replace(".", ",");  //$1.3 M
			U.log(floorMatch);
			html	 = html.replace(millionPrice1.group(), floorMatch);
			}//end millionPrice
			while(millionPrice.find()){
//				U.log(mat.group());
				String floorMatch = millionPrice.group().replace("Millions", "000,000").replace(" ", ",");  //$1.3 M
				html	 = html.replace(millionPrice.group(), floorMatch);
				}//end millionPrice
		return html;
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String cityName = ALLOW_BLANK;
		String cityUrl = ALLOW_BLANK;
		String mainHtml=U.getHTML("https://lyonhomes.com");
		String citySec=U.getSectionValue(mainHtml, "Select a Location</h2>", "<div class=\"modal-body");
		String[] cities=U.getValues(citySec,"<div class=","</div>");
		for(String city:cities){
			//U.log(city);
			if(city.contains("nav-item nav-link-plus map-region collapsed"))continue;
			cityUrl="https://lyonhomes.com"+U.getSectionValue(city, "<a href=\"", "\"");
			cityName=Util.match(city, "<a href=.*?>(.*?)</a>$",1);//U.getSectionValue(city, ">", "</a");
			U.log(cityUrl+"\t"+cityName);
//			if(cityName.contains("HOUSTON"))
				getCityHtml(cityUrl,cityName);
		}
	}
	
	public static void getCityHtml(String url,String name)throws Exception{
		String cityHtml=ALLOW_BLANK;
		String comHtml=ALLOW_BLANK;
		String comUrl1= ALLOW_BLANK;
		String getHomes;
		cityHtml=U.getHTML(url);
		U.log(url);
		//cityHtml=cityHtml.replaceAll("</ul>\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "endSection");
		//cityHtml=U.removeSectionValue(cityHtml, "<div class=\"region-filters clearfix\">", "<div class=\"container neigbhorhoods-listings\"");
		String[] Communities=U.getValues(cityHtml, "<div class=\"row neigbhorhoods","<div class=\"row neighborhood-buttons d");
		U.log(Communities.length);
		String sec=U.getSectionValue(cityHtml, "regionNeighborhoods =", "}];");
		for(String comm:Communities){
			comm=comm.replace("Currently Selling From the", " ");
			//U.log(comm);
			String temp=U.getSectionValue(comm, "<h3><a href=\"", "\"");
			U.log(temp);
			temp = temp.replace("mont-blanc-at-villebois-lbg7sitixmdl", "mont-blanc-at-villebois");
			if(set.contains(temp))continue;
			if(!temp.contains("http")){
				
				comUrl1="https://lyonhomes.com"+temp;
				
				//TODO : Exec for single community
//				if(comUrl1.contains("https://lyonhomes.com/southern-california/braeburn"))
				{
					comHtml=U.getHTML(comUrl1);
					comHtml=comHtml.replaceAll("<li>COMING SOON </li>", "-");
					
//					try {
						getDetails(comHtml,comUrl1,comm,sec);
//					} catch (Exception e) {
//						// TODO: handle exception
//					}
					 
				}
			
			}
			else{
				
				if(comUrl1.contains("https://lyonartisan.com"))comUrl1="http://lyonartisan.com";
				comUrl1=getRedirectedURLConnection(temp);
/*				if(comUrl1.contains("https://OvationMeridian.com/"))
				{
					LOGGER.AddCommunityUrl(comUrl1 + ":::::::::::: Site not Open::::::::::::::");// Please check. Date 18/5/2019
					return;
				}
*/				
				//TODO : Exec for Single community
//				if(comUrl1.contains("https://lyonlagovista.com"))
				{
					if(comUrl1.contains("http://www.ovationmeridian.com")) comUrl1 = "https://www.ovationmeridian.com/";
					if(comUrl1.contains("http://ovationmountainfalls.com")) comUrl1 = "https://ovationmountainfalls.com/";
					comHtml=U.getHTML(comUrl1);
			//	if(comUrl1.contains("https://OvationMeridian.com/"))return;
					comHtml=comHtml.replaceAll("<li>COMING SOON </li>", "-");
//					try {
					getDetailsOfCommunities(comUrl1,comHtml,comm);
//					} catch (Exception e) {
						// TODO: handle exception
//					}
				}
			}	
			set.add(temp);

		}

	}
	public static String getQuickHomes(String comm,String name)throws Exception {
		//getting Quick delivery homes
		String allQuickHomesHtml=ALLOW_BLANK;
		//U.log(comm);
		name=name.replace("á", "a");
		if(comm.contains("Quick")){
			String quickMoveInMainHtml=ALLOW_BLANK;
			U.log("<---------------Fetching Quick delivery homes-------------->");
			String quickMoveinSec=Util.match(comm, "(.*?)quick-move-in-homes(.*?)\"");
//			U.log(Util.match(comm, "(.*?)quick-move-in-homes(.*?)\""));
			if(quickMoveinSec!=null){
				U.log("https://lyonhomes.com"+ U.getSectionValue(quickMoveinSec,"href=\"", "\""));
				 quickMoveInMainHtml=U.getHTML("https://lyonhomes.com"+U.getSectionValue(quickMoveinSec, "href=\"", "\""));
			String[] quickMoveInHomes=U.getValues(quickMoveInMainHtml, "class=\"neigbhorhoods-listing clearfix", "class=\"btn btn-secondary pull-right");
			for(String home:quickMoveInHomes){
				home=home.replace("á", "a");
				String[] availHomes=U.getValues(home, "href=\"", "\"");
				for(String value:availHomes){
//				U.log(home);
				if(home.contains(name)){
				allQuickHomesHtml += U.getHTML("https://lyonhomes.com"+value);
				}
				}
			}}
		}
		return allQuickHomesHtml;
	}
	
	public  static void getDetailsOfCommunities(String comUrl,String comHtml,String comm)throws Exception{
//		if(!comUrl.contains("https://ovationoaktree.com/"))return;
		U.log("==================Fetching Details=================");
		
		String comName=ALLOW_BLANK;
		comHtml=comHtml.replaceAll("</li>\\s*</ul>\\s*</div>", "endSec");
		comHtml=comHtml.replace("Two Brand New Single-Story Residences Now Available", " "); 
		comHtml=comHtml.replace("<p>Models are now open! Be among the first to get exciting news and stay tuned to what is happening at Ovation at Mountain Falls. Wonderful things are coming your way!</p>", " " );
		comHtml=comHtml.replace("SALES GALLERY NOW OPEN ", " ");
		comm=comm.replace("SALES GALLERY NOW OPEN ", " ");

		//=============================Community Url===========================
			comUrl = comUrl.replace("http:", "https:");  
			if(comUrl.contains("https://lyonartisan.com"))comUrl="http://lyonartisan.com";
			if(comUrl.contains("https://lyonthegrandmonarch.com"))comUrl="http://lyonthegrandmonarch.com";

			//if(!comUrl.contains("https://lyonlagovista.com"))return;
			U.log("comUrl-->"+comUrl);			
			
		//=============================Community Name=========================================
			 
			String tempName=U.getSectionValue(comm, "<h3>","</h3>");
			comName=U.getSectionValue(tempName, "target=\"_blank\">","</a");
			comName = Util.match(comm, "\">(.*?)</a></h3>",1);
//			U.log(comName);
			U.log("ComName-->"+comName);
		//=============================Community address=========================================
			String allNavMenuHtml=ALLOW_BLANK;String resihtml=ALLOW_BLANK;
			String note=ALLOW_BLANK;
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
			
			if(comUrl.contains("https://www.ovationmeridian.com/")){ 
				U.log("getting data from Ovation at Meridian");
					String[] addressToGetLatLng={"","Queen Creek","Arizona",""};
					latlng =U.getlatlongGoogleApi(addressToGetLatLng);
					if(latlng == null) latlng = U.getlatlongHereApi(addressToGetLatLng);
					
					U.log("By Geocoding--->"+latlng[0]+"  "+latlng[1]);
					add=U.getAddressGoogleApi(latlng);
					if(add == null) add = U.getGoogleAddressWithKey(latlng);
					if(add == null) add = U.getAddressHereApi(latlng);
					geo="TRUE";
					note="Address Calculated using City,state.";		
			}
			else{
		//<---------------NavBar Data------------>
			String navSec;				
			String mapHtml=ALLOW_BLANK;

			if(comName.equals("Ovation at Flora Park"))
				navSec=U.getSectionValue(comHtml, "<div class=\"collapse", "endSec");
			else if(comName.equals("Silver Ridge")||comName.equals("Ovation at Mountain Falls"))
				navSec=U.getSectionValue(comHtml, "<div class=\"menu-main-nav-container", "endSec");
			else if(comName.equals("Lago Vista"))
					navSec=U.getSectionValue(comHtml, "<div class=\"menu-menu-1-container", "</nav>");
			else if(comName.equals("Ovation at Meridian"))
				navSec=U.getSectionValue(comHtml, "menu-main-nav-container", "</nav>");
			else if(comName.equals("Artisan Collection at Covenant Hills"))
				navSec=U.getSectionValue(comHtml, "<ul class=\"nav navbar-nav\">", "<!--/.nav-collapse -->"); 
			else if(comName.equals("Ovation at Mountain Falls"))
				navSec=U.getSectionValue(comHtml, "<div class=\"menu-main-nav-container", "</nav>");
			else
				
				navSec=U.getSectionValue(comHtml, "<div class=\"navbar-collapse", "endSec"); 
			
			/*if(navSec == null)
				navSec = U.getHtmlSection(comHtml, "<ul class=\"sub-menu\">", "</ul>");//</nav>
*/			
			U.log("SSSSSSSSSSSS"+navSec);
				navSec=navSec.replace("_blank", " ");
			
				navSec=U.removeSectionValue(navSec, "menu-item-205\">", "<");
				navSec=U.removeSectionValue(navSec, "id=\"menu-item-233", "Mountain Falls");
				navSec=U.removeSectionValue(navSec, "	<li id=\"menu-item-365\"", "<");
				navSec=U.removeSectionValue(navSec, "class=\"interest-list hidden-sm\">", "height=\"11\">");
				
				String[] navMenus;
				if(comName.equals("Artisan Collection at Covenant Hills"))
					navMenus=U.getValues(navSec,"<li >", "</a");
				else
					navMenus=U.getValues(navSec,"<li", "</a");
				
			U.log("MMMM"+navMenus.length);
			for (String menu : navMenus) {
				U.log("==" + menu);
		
				// if(!menu.contains("http")) continue;
				//U.log("MMM");
				//if (!menu.contains("<li role="))continue;
				if (!menu.contains("http") || !menu.contains("https")) {
					U.log(U.getSectionValue(menu, "<a href=\"", "\""));

					String a = U.getHTML(comUrl + U.getSectionValue(menu, "<a href=\"", "\""));
					if (a != null)
						allNavMenuHtml += a;
				} else if (comName.equals("Lago Vista")) {
				
					//U.log("SSS"+U.getSectionValue(menu, "href=\"", "\""));
					String a =  U.getHTML(U.getSectionValue(menu, "href=\"", "\""));//comUrl + 
					if (a != null)
					allNavMenuHtml += a;
				} else {

					allNavMenuHtml += U.getHTML(U.getSectionValue(menu, "href=\"", "\""));
				}

				// Visit_US page data
				if (menu.contains("/visit-us") && !menu.contains(comUrl)) {
					mapHtml = U.getHTML(comUrl + U.getSectionValue(menu, "href=\"", "\""));
					U.log("map ::" + mapHtml.contains("https://www.google.com/maps"));
				}
				if (menu.contains("/contact/") && !menu.contains(comUrl)) {
					//if(comName.equals("The Grand Monarch"))
					mapHtml = U.getHTML(comUrl + U.getSectionValue(menu, "href=\"", "\""));
					U.log("map1 ::" + mapHtml.contains("https://www.google.com/maps"));
				}
				if (menu.contains("/contact-us/") && !menu.contains(comUrl)) {
					String contactUrl = U.getSectionValue(menu, "href=\"", "\"");
					if(!contactUrl.contains("http")) contactUrl = comUrl + contactUrl;
					mapHtml = U.getHTML(contactUrl);
					U.log("map2 ::" + mapHtml.contains("https://www.google.com/maps"));
				}
			}

				allNavMenuHtml=allNavMenuHtml.replaceAll("<h3>Now Open</h3>","");
				comHtml=comHtml.replace("<p>Models are now open!", "");
				comm=comm.replace("NOW OPEN! - Three Collections","");
				
				if(comUrl.contains("https://ovationoaktree.com/")){
					String residenceshtml=U.getHTML("https://ovationoaktree.com/residences/the-beech");
					String sec=U.getSectionValue(residenceshtml, "<ul class=\"nav subnav\">", "Home Features");
					String residencesUrl[]=U.getValues(sec, "href=\"", "\"");
					for(String home:residencesUrl){
						String a = U.getHTML("https://ovationoaktree.com"+home);
						if(a!= null)
							resihtml+= a;
					}
				}
			
			String address=ALLOW_BLANK;
			//<-----------Address from hardcoded csv------------>
			String addSec=U.getSectionValue(mapHtml, "https://www.google.com/maps/place/", "\"");
			if(addSec!=null) {
				addSec=addSec.replace("+", " ");
				add=U.findAddress(addSec);
				String latString=U.getSectionValue(addSec, "/@", "/data");
				U.log(latString);
				latlng[0]=Util.match(addSec, "\\d{2,3}\\.\\d+");
				latlng[1]=Util.match(addSec, "-\\d{2,3}\\.\\d+");
			}
			else if(comUrl.contains("https://ovationmountainfalls.com/")) {
				addSec=U.getSectionValue(U.getHTML("https://www.ovationmountainfalls.com/contact-us/"), "Wednesdays</p>", "</p>");
				add=U.findAddress(addSec);
				latlng=U.getlatlongGoogleApi(add);
				if(latlng == null)
					latlng = U.getlatlongHereApi(add);
				geo="True";
			}
			else if(comUrl.contains("https://ovationflorapark.com/")) {
				addSec=U.getSectionValue(U.getHTML("https://ovationflorapark.com/visit/"), "<p>Open Daily 10AM to 5PM</p>\n" + 
						"<p>", "</p>");
				U.log(addSec = addSec.replace("<br />", ",").replace("(714) 761-7931", ""));
				add=U.findAddress(addSec);
				String latString=U.getSectionValue(U.getHTML("https://ovationflorapark.com/visit/"), "src=\"https://www.google.com/maps/embed?pb=", "\"");
				U.log(latString);
				latlng[0]=U.getSectionValue(latString, "3d", "!");//Util.match(addSec, "\\d{2,3}\\.\\d+");
				latlng[1]=U.getSectionValue(latString, "!2d", "!");//Util.match(addSec, "-\\d{2,3}\\.\\d+");
//				latlng=U.getlatlongGoogleApi(add);
//				geo="True";
			}
			else if(comUrl.contains("https://lyonlagovista.com")) {
				addSec=U.getSectionValue(U.getHTML("https://lyonlagovista.com/contact-us/"), "<p class=\"p1\">", "</p>");
				U.log(addSec);
				add=U.findAddress(addSec);
				String latString=U.getSectionValue(U.getHTML("https://lyonlagovista.com/contact-us/"), "href=\"https://www.google.com/maps/embed?pb=", "\"");
				U.log(latString);
				latlng[0]=U.getSectionValue(latString, "3d", "!");//Util.match(addSec, "\\d{2,3}\\.\\d+");
				latlng[1]=U.getSectionValue(latString, "!2d", "!");//Util.match(addSec, "-\\d{2,3}\\.\\d+");
//				latlng=U.getlatlongGoogleApi(add);
//				geo="True";
			}
			else if(comUrl.contains("https://ovationoaktree.com/")) {
				addSec=U.getSectionValue(U.getHTML("https://ovationoaktree.com/contact-us"), "Ovation at Oak Tree Sales Gallery</strong></li>", "</ul>");
				U.log(addSec);
				add[0] = "8929 36th Ct SE ";
				add[1] = "Lacey";
				add[2] = "WA";
				add[3] = "98513";
				String latString=U.getSectionValue(U.getHTML("https://ovationoaktree.com/contact-us"), "src=\"https://www.google.com/maps/embed?pb=", "\"");
				U.log(latString);
				latlng[0]=U.getSectionValue(latString, "3d", "!");//Util.match(addSec, "\\d{2,3}\\.\\d+");
				latlng[1]=U.getSectionValue(latString, "!2d", "!");//Util.match(addSec, "-\\d{2,3}\\.\\d+");
//				latlng=U.getlatlongGoogleApi(add);
//				geo="True";
			}
			else if(comUrl.contains("http://lyonthegrandmonarch.com")) {
				addSec=U.getSectionValue(U.getHTML("http://lyonthegrandmonarch.com/contact/"), "Sales Gallery</strong></span><br />", "<br />");
				U.log(addSec);
				add=U.findAddress(addSec);
				latlng=U.getlatlongGoogleApi(add);
				if(latlng == null)
					latlng = U.getlatlongHereApi(add);
				geo="True";
			}
			else {
				address=getHardcodedAddress(comUrl);
				U.log(address);
				add=address.split(",");
				add[0]=add[0].trim();
				add[1]=add[1].trim();
				add[2]=add[2].trim();
				add[3]=add[3].trim();
				latlng[0]=add[4];
				latlng[1]=add[5];
				geo=add[6];
			}
			
			if(comUrl.contains("https://lyonhomes.com/washington/sunridge-townhomes"))
				add[0]=add[0].replace("Visit Brightview Sales Gallery for Sunridge Information:   ", "").replace("Kent WA 98031", "").trim();
			
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
	
			
			
			U.log("LatLng---->"+latlng[0]+" "+latlng[1]);

		
			U.log("Geocode---->"+geo);
			}
			//============================================Price and SQ.FT======================================================================
			comHtml=formatMillionPrices(comHtml);
			comm=formatMillionPrices(comm);
			comHtml=comHtml.replace("$3 Millions", "$3,000,000");
			allNavMenuHtml=formatMillionPrices(allNavMenuHtml);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String prices[] = U.getPrices(comHtml+comm+allNavMenuHtml+resihtml,
					"\\$\\d{1},\\d{3},\\d*|\\$\\d{3}\\,\\d*",
//					"Low \\$\\d{3}\\,\\d*|Mid \\$\\d{3}\\,\\d*|High \\$\\d{3}\\,\\d*|From the \\$\\d{3}\\,\\d*|From the Low \\$\\d{3}\\,\\d*|From the Mid \\$\\d{3}\\,\\d*|From the High \\$\\d{3}\\,\\d*|\\$\\d{3}\\,\\d*|\\$\\d{1},\\d{3},\\d*|Low \\$\\d{1},\\d{3},\\d*|Mid \\$\\d{1},\\d{3},\\d*|High \\$\\d{1},\\d{3},\\d*|the \\$\\d{1},\\d{3},\\d*",
					0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Prices----->"+minPrice+ " "+maxPrice);
			
			//====================Sq.ft=====================
			
			String[] sqft = U.getSqareFeet(comHtml+comm+allNavMenuHtml+resihtml,"\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|Approx. \\d{1},\\d{3}-\\d{1},\\d{3} Sq. Ft.|Approx. \\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3}-\\d{1},\\d{3} Sq.Ft.</li>|\\d{1},\\d{3} Sq. Ft.",0);
				
			minSqft = (sqft[0] == null)	? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);

			//================================================community type========================================================
			
			String commType=U.getCommType(comm+comHtml);
			U.log("community type---->"+commType);
			
			//==========================================================Property Type================================================
			comHtml=comHtml.replace(" luxury interior features", "custom luxury");
//			U.log(Util.matchAll(allNavMenuHtml,"loft",0));
			String propType=U.getPropType(comHtml+comm+allNavMenuHtml);
			U.log("Property type---->"+propType);

			//==================================================D-Property Type======================================================
			String dPropType=U.getdCommType((comHtml+comm+allNavMenuHtml).replaceAll("[B|b]ranch|Ladera [R|r]anch|ladera-ranch|Ladera\\+Ranch", ""));
			U.log("Derived Property type---->"+dPropType);
			
			//==============================================Property Status=========================================================
		
			comm=comm.replace("3&nbsp;Quick&nbsp;Move-In Homes&nbsp;Available&nbsp;&gt;&gt;", "3 Quick Move-In Homes")
					.replaceAll("Designer Homes Available Now|Now Open Daily", "");
			comHtml=comHtml.replace(" and unlimited opportunities await.", "").replaceAll("<br>Move-in Ready,|--\\s*<h4>Now Selling!\\s*</h4>\\s*-->|Coming Late 2018|<h3>Now Open!\\s*</h3>\\s*<p>| of any one of our&nbsp; move-in ready homes.&nbsp;|Three Brand New Residences Now Available|Coming soon to Cypress", "");
			U.log(comm);
			String propStatus=U.getPropStatus(comHtml+comm.replace("MOVE-IN READY HOME</a>", "MOVE-IN READY HOMEs</a>").replaceAll("Golf Course Lots Available|Move-in Ready|Models Coming Late 2018|--\\s*<h4>Now Selling!\\s*</h4>\\s*-->", ""));
			
			if(propStatus.contains("3 Quick Move-in Homes"))propStatus=propStatus.replaceAll("3 Quick Move-in Homes", "Quick Move-in Homes");
			if(comUrl.contains("https://ovationflorapark.com/")) propStatus = propStatus.replace(", Move-in Ready Homes", "");
			if(comUrl.contains("https://lyonlagovista.com")) propStatus = propStatus.replace("Lots Available", "lakeside lots available");
			//U.log("MMMMMMMM "+Util.matchAll(comHtml+comm, "[\\s\\w\\W]{30}Lots Available[\\s\\w\\W]{30}", 0));
			U.log("Property Status---->"+propStatus);
			
			//============================================note====================================================================
			
			
			if(data.communityUrlExists(comUrl))
			{
				LOGGER.AddCommunityUrl(comUrl+"*********repeated***********");
				i++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
				
				
				U.log(add[2]);
				if(add[2].length()>2){
					add[2]=USStates.abbr(add[2]);
				}
				U.log(Arrays.toString(add));
				add[2]=add[2].toUpperCase();
				add[2]=add[2].replace(",","").trim();
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				data.addCommunity(comName,comUrl, commType);
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, dPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note); 
				
			
	}
	
	
	public static void getDetails(String comHtml,String comUrl,String commSec,String dataSec) throws Exception{
//		if(!comUrl.contains("https://lyonhomes.com/texas/perennial-collection-at-bridge-creek"))return;    
			U.log(U.getCache(comUrl));
			U.log("==================Fetching Details=================+");
			String comName=ALLOW_BLANK;
			String floorPlansHtml=ALLOW_BLANK;
			String qhome = "";
			comHtml=U.removeSectionValue(comHtml, "<head>", "</head>");
			comHtml=U.removeSectionValue(comHtml, "class=\"navbar hidden-print", "</nav>");
			comHtml=U.removeSectionValue(comHtml, "<h4>Directions to Sales Gallery:", "</div>");
			U.log(commSec);
			
			String qUrlSec = U.getSectionValue(comHtml, "Save Time. Schedule An Appointment", "MOVE-IN READY HOMES");
		if (qUrlSec != null) {
			String qUrl = U.getSectionValue(qUrlSec, "<a href=\"", "\" ");

			qhome = U.getHTML("https://lyonhomes.com" + qUrl);
		}

		//=============================Community Url===========================
			U.log("comUrl-->"+comUrl);
		//=============================Community Name========================================= 
			String tempName=U.getSectionValue(commSec, "<h3>","</h3>");
			if(tempName.contains("Townhomes")){
				tempName=tempName.replace("Townhomes", "");
			}
			comName = Util.match(commSec, "\">(.*?)</a></h3>",1).replaceAll("ō", "o").replaceAll("é", "e").replaceAll("á", "a").replace("–", "-");
			comName = comName.replaceAll(" - Last Chance!$|-SOLD OUT$|-\\s?Sold Out$", "");

			U.log("ComName-->"+comName);
//			U.log(commSec);
			String homes=getQuickHomes(commSec,comName);
		//=============================Community address=========================================
			String note="";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
//			String[] add1={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
			
		
			String address = "";
			address = U.getSectionValue(comHtml, "sales-gallery-address\">", "</p>").replace("<br class=\" hidden-print\" />", ",");
			add = U.getAddress(U.getNoHtml(address));
			
			if(add[0]!=null)add[0]=add[0].replaceAll("(Shown )?By Appointment Only|shown by appointment only|sunridge sales gallery:|SOLD OUT", "");
			U.log("Address---->"+add[0]+", "+add[1]+", "+add[2]+", "+add[3]);
			
			String cityState[] = U.getSectionValue(commSec,"<p>", "</p>").split(",");//from main page
			U.log(Arrays.toString(cityState));
			if(add[2]==null && add[1]!=null){
				if(add[1].equalsIgnoreCase(cityState[0]))add[2]=cityState[1].trim();
			}
			U.log(add[2]);
			//=============================LatLng=========================================
			latlng=U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/dir//", "\"").split(",");
			if(comName.equals("Towne38")){
				add=U.getAddressGoogleApi(latlng);
				if (add==null) {
					add=U.getGoogleAddressWithKey(latlng);
				}
				geo="TRUE";
				//note="Address Calculated using City,state.";
			}
			U.log("LatLng---->"+latlng[0]+" "+latlng[1]);
			U.log("GeoCoding---->"+geo);
			U.log(Arrays.toString(add));
			if((add[0].trim().isEmpty() || add[0].equals(ALLOW_BLANK)) && add[3].length()>4){
				if(latlng[0].length() > 4 && latlng[1].length()>4){
					String add1[] = U.getAddressGoogleApi(latlng);
					if(add1 == null)
						add1 = U.getGoogleAddressWithKey(latlng);
					if(add1 == null)
						add1 = U.getAddressHereApi(latlng);
					add[0] = add1[0];
					geo="TRUE";
					add1 = null;
				}
			}
			//========getting Floorplans for data==========
				comHtml=comHtml.replaceAll("</li>\\s*</ul>\\s*</div>", "endSec");
				String[] floorPlans=U.getValues(comHtml, "neigborhood-floorplans-list margin-bottom-medium\">", "Floorplan</a>");
				for(String value:floorPlans){
					
					U.log("https://lyonhomes.com"+U.getSectionValue(value , "href=\"", "\""));
					floorPlansHtml+=U.getHTML("https://lyonhomes.com"+U.getSectionValue(value , "href=\"", "\""));
					if(floorPlansHtml != null)
					floorPlansHtml=floorPlansHtml.replaceAll("<header(.*?)</header>", " ");
					

				}
			//============================================Price and SQ.FT======================================================================
			comHtml=comHtml.replaceAll("0's|0s|0&#39;s","0,000").replace("$1 Millions","$1,000,000").replaceAll("&rsquo;s", ",000");
			commSec=commSec.replace("$300,00s", "$300,000").replaceAll("0's|0s","0,000").replace("$1 Millions","$1,000,000");
	

			comHtml=formatMillionPrices(comHtml);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			U.log(homes);
			String prices[] = U.getPrices(comHtml+commSec+homes+floorPlansHtml+ qhome,
					"description\">\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d*|Low \\$\\d{1},\\d{3},\\d*|Mid \\$\\d{1},\\d{3},\\d*|High \\$\\d{1},\\d{3},\\d*|\\$\\d{1},\\d{3},\\d*|Low \\$\\d{1},\\d{3},\\d*|from the \\$\\d{3},\\d{3} to the \\$\\d{3},\\d{3}|Mid \\$\\d{3}\\,\\d*|High \\$\\d{3}\\,\\d*|From the \\$\\d{3}\\,\\d*|From the Low \\$\\d{3}\\,\\d*|From the Mid \\$\\d{3}\\,\\d*|From the High \\$\\d{3}\\,\\d*|\\$\\d{3}\\,\\d*",
					0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
//			if(comUrl.contains("https://lyonhomes.com/southern-california/parkside---last-chance")) maxPrice = "$349,900";
			//U.log("MMMMM "+Util.matchAll((comHtml+commSec+homes+floorPlansHtml+ qhome), "[\\s\\w\\W]{30}$709,990[\\s\\w\\W]{30}", 0));
			U.log("Prices----->"+minPrice+ " "+maxPrice);
			
			//====================Sq.ft=====================
//			U.log(commSec);
		
		 	
			String[] sqft = U.getSqareFeet(comHtml+commSec+homes+floorPlansHtml + qhome,"\\d{3,4}-square foot |Approx. \\d,\\d{3} - \\d,\\d{3} Sq.Ft|Approx. \\d{3} - \\d,\\d{3} Sq. Ft.|from \\d,\\d{3} to&nbsp;\\d,\\d{3} square feet|Approx Sq. Ft</div>\\n*\\s*<div class=\"description\">\\d{3}|Approx Sq. Ft</div>\\n*\\s*<div class=\"description\">\\d,\\d{3}|from \\d{3} to \\d,\\d{3} sq. ft.|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|<li>Approx. \\d{1},\\d{3} – \\d{1},\\d{3} Sq. Ft.</li>|<li>Approx. \\d{1},\\d{3}-\\d{1},\\d{3}</li>|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}-\\d{1},\\d{3} Sq.Ft.</li>|Approx. \\d{1},\\d{3} Sq\\. Ft\\.|\\d,\\d{3} Sq\\. Ft\\.|\\d{1},\\d{3} Sq\\. Ft\\.|Approx. \\d{3} Sq. Ft.",0);
				
			minSqft = (sqft[0] == null)	? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
			
			//================================================community type========================================================
			//comHtml=comHtml.replace("Ovation<br><small>55+ Active Lifestyle", "");
			String commType=U.getCommType(comHtml+commSec);
			U.log("community type---->"+commType);
			
			//==========================================================Property Type================================================
			comHtml=comHtml.replace("multi-generational", "multi-generational suite").replace(" luxury of Tuscan Cliffs", "luxury home").replace("Traditional Texas Hill Country architectural styles", "Traditional homes").replaceAll("luxurious details found", "luxury homes");
			String propType=U.getPropType((comHtml+commSec+homes+floorPlansHtml).replaceAll("<img(.*?)>|- Patio|11394 Villa Bellagio Drive|HOA disclaimer|left on Villa Bellagio|alt=\"Patio\"| Patio\\s*</div>", ""));
			U.log("Property type---->"+propType);
			
			//==================================================D-Property Type======================================================
			commSec=commSec.replaceAll("Valley Ranch Blvd", "");
			
			floorPlansHtml=floorPlansHtml.replace("<h3>Third Floor</h3>", "<h3>3 Story</h3>").replace("<h3>Second Floor</h3>", "<h3>2 Story</h3>").replace("<h3>First Floor</h3>", "<h3>1 Story</h3>").replaceAll("Building Levels 1,2&nbsp;&amp; 3", "1 Story,story 2,story 3").replaceAll("Building Levels 2 &amp; 3", "story 2,story 3").replaceAll("Building Level[s]*", "story");
			homes=homes.replaceAll("Building Level", "story").replace("single or split-level ", "single story or split-level ")
					.replaceAll("2<sup>nd</sup> Floor", "2 story").replaceAll("3<sup>rd</sup> floor", "3 story").replaceAll("1st Floor| first-floor", "1 story");
			comHtml=comHtml.replace(" 3- and 4-level ", "3 story and 4 story").replace(" one- and two-story designs", " 1 Story  2 Story ").replace("1-to&nbsp;3-level", "1 story,story 3").replace( "2- and 3-level plans", "story 2,story 3");
			String dPropType=U.getdCommType((comHtml+commSec+homes.replaceAll("Floor|Stonewall\\s*Ranch|\\+Ranch|Stillwater\\s*Ranch|Valley Ranch Blvd|Rex Ranch|rancho-mission-viejo|Rancho|Rancho Mission Viejo", "")+floorPlansHtml.replaceAll("Floor|rancho-mission-viejo|Rancho|Rancho Mission Viejo|Valley Ranch", "")).replaceAll("[B|b]ranch|[R|r]ancho|Rancho|rancho|Ladera Ranch|Murphy Ranch|murphy-ranch|<img(.*?)>", ""));
		
			U.log("Derived Property type---->"+dPropType);
			//==============================================Property Status=========================================================
//			U.log("Hollaaaaaaaaaaaaa"+Util.matchAll(comHtml+commSec+homes+floorPlansHtml+ qhome, "[\\w\\s\\W]{30}selling[\\w\\s\\W]{30}", 0));
			String headLine = U.getSectionValue(comHtml, "<h2 class=\"openSans16 neighborhood-headline\">", "</h2>");
			comHtml=comHtml.replace("Opening in 2019", "Opening 2019").replaceAll("COMING SOON IN APRIL 2019", "COMING SOON APRIL 2019");
			comHtml=comHtml.replaceAll("<h3>Move-In Ready Homes|<!-- <h4>NOW SELLING! </h4> -->| <!-- <h4>NOW SELLING!</h4> -->|<!-- <h4>Last Chance - Few Homes Remain!</h4> |Alder at Summerly - Last Chance|Move-in Ready| <!-- <h4>New Phase Now Open. New Floorplans!</h4> -->| <!-- <h4>Now Selling!\\s*</h4> -->|<div class=\"description\">\\$Temporarily Sold Out|Sales Hub Now Open|target=\"_blank\">Move-In Ready</a>|<li>SOLD OUT|<h4>Move-In Ready Homes!\\s*</h4>| - Move-In Ready|SOLD OUT endSec|Currently Selling [F|f]rom|Model Homes Coming Soon|>\\s*Coming Soon\\s*<|alt=\"Grand Opening \"|Temporarily Sold Out\\s*endSec|Gallery:</h4>\\s*<p>Coming Soon!</p>|Coming Soon to The Cliffs Village|Coming Soon endSec|MODELS COMING LATE 2018|/Coming_soon_1000x600_thumbnail_1.jpg|</li>\\s*<li>\\s*SOLD OUT\\s*</li>|Model Homes Selling Now|Sales Gallery Hours Coming Soon|Seven stunning models are now open|Models and Welcome Center Now Open!|Move-In Ready Homes on the Golf Course Available!|any one of our  move-in ready homes.|alt=\"Final Homes", "");
			commSec=commSec.replaceAll("Move-in Ready|<h4>Move-In Ready Homes!\\s*</h4>|<!-- <h4>NOW SELLING! </h4> -->| <!-- <h4>NOW SELLING!</h4> -->|<!-- <h4>Last Chance - Few Homes Remain!</h4> | <!-- <h4>New Phase Now Open. New Floorplans!</h4> -->| <!-- <h4>Now Selling!\\s*</h4> -->| - Move-In Ready|>\\s*Coming Soon\\s*<|4 Bedroom Homes Coming Soon |Coming Soon to The Cliffs Village|Pool Opening in 2019|Models Coming Late 2018|Designer Homes Available Now|COMMUNITY POOL NOW OPEN FOR MERIDIAN HOMEOWNERS|Close Out of Final Homes at The Grand Collection at Sterling Ridge!|Move In Ready Homes Available|Models and Welcome Center Now Open!|<!-- <h4>NEW PHASE OPEN|Models Homes Just|Model Grand Opening", "");
			commSec = U.removeComments(commSec);
			comHtml = U.removeComments(comHtml);
//			U.log(commSec);
			String propStatus=U.getPropStatus((commSec+comHtml+headLine).replaceAll("presidio-x---sold-out\"|Presidio X - Sold Out|redwood---sold-out\"|Redwood - Sold Out|rosa---sold-out\"|Santa Rosa - Sold Out|acadia---sold-out\"|Acadia - Sold Out|augusta---sold-out|kendall---sold-out|Kendall - Sold Out|santa-rosa---sold-out|Santa Rosa - Sold Out|lassen---closeout|Lassen - Closeout!|athens-sold-out|<h4>FINAL 3 HOMES - LAST CHANCE!</h4> -->", ""));//+commSec+homes+floorPlansHtml);
			
			
			
			if(comUrl.contains("https://lyonhomes.com/southern-california/echo-at-novel-park") || comUrl.contains("https://lyonhomes.com/southern-california/fringe-at-novel-park") || comUrl.contains("https://lyonhomes.com/southern-california/verge-at-novel-park"))
				propStatus = propStatus.replace(", Quick Move-ins Available", "");
			
			U.log("Property Status---->"+propStatus);
			if(propStatus.contains("Only 4 Homes Left")&& propStatus.contains("Only 4 Homes Remain"))propStatus=propStatus.replaceAll(", Only 4 Homes Remain", "");
			//============================================note====================================================================	
			if(note.length()<1){
				note=U.getnote(comHtml+commSec); 
			}
			if(propStatus.contains("Quick Move-ins") || propStatus.contains("Move-in Ready"))propStatus=propStatus.replaceAll("Move-in Ready Homes|Quick Move-in Homes|Quick Move-ins|Move-in Ready", "Move-in Ready Homes");
			if(comName.endsWith("Estates"))propType=propType+", Estate-Style Homes";
			
			
			if(data.communityUrlExists(comUrl))
			{
				LOGGER.AddCommunityUrl(comUrl+"*********repeated***********");
				i++;
				return;
			}
				LOGGER.AddCommunityUrl(comUrl);
			
				
				if(add[2].length()>2){
					add[2]=USStates.abbr(add[2]);
				}
				if(add[0].length()<4  && latlng[0].length()>4) {
					add=U.getAddressGoogleApi(latlng);
					if(add == null) add = U.getGoogleAddressWithKey(latlng);
					if(add == null) add = U.getAddressHereApi(latlng);
					geo="TRUE";
				}
				
				add[0]=add[0].replace("LN", "Ln").replace("&nbsp;", "");
				add[2]=add[2].toUpperCase();
				add[2]=add[2].replace(",","").trim();
			
				if(comUrl.contains("https://lyonhomes.com/washington/sunridge-townhomes")) {
					add[0]=add[0].replace("Visit Brightview Sales Gallery for Sunridge Information:   ", "").replace("Kent, WA 98031", "").trim();}
				
				if(comUrl.contains("https://lyonhomes.com/arizona/harmony-at-meridian"))maxPrice = "$344,990";    
				if(comUrl.contains("https://lyonhomes.com/northern-california/front"))maxPrice = "$702,990";      
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				data.addCommunity(comName.toLowerCase(),comUrl, commType);
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, dPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note); 
				
		}
	
	
	
	
}