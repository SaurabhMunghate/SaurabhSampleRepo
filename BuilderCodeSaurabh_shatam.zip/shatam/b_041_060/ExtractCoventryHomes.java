/**
 * @author Parag Humane 
 * @date 10/3/2012
 * Modification Aditya..
 */
package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;
import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import java.net.Proxy;
import java.io.InputStream;
import java.net.InetSocketAddress;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCoventryHomes extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	String str;
	String city;
	String zip;
	String state;
	public int inr = 0;
	String geo="FALSE";
	String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
	static ArrayList<String> extraComm = new ArrayList<String>();

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCoventryHomes();
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "MHI-McGuyer Homebuilders - Coventry Homes.csv", a.data().printAll());
		U.log(extraComm.size());
		for (int i = 0; i < extraComm.size(); i++) {
			U.log(extraComm.get(i));
		}
	}

	public ExtractCoventryHomes() throws Exception {

		super("MHI-McGuyer Homebuilders - Coventry Homes", "https://www.coventryhomes.com/");
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Coventry Homes");
	}

	public void innerProcess() throws Exception {
		String regsApiUrl="https://app.mhinc.com/api/DBAMetros/?DBACode=cov";
		String regionAPiHTml=getHTML(regsApiUrl);
		String regions[]=U.getValues(regionAPiHTml, "{", "}");
		for (String region : regions) {
			//U.log(region);
			//https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid=h&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=990.99&zipcode=&zipcoderadius=&amenities=&projectid=
			String metroid=U.getSectionValue(region, "\"metroid\":\"", "\"");
			String metroUrl=U.getSectionValue(region, "\"metroseourlname\":\"", "\"").toLowerCase()+"/";
			String commDataAPI=getHTML("https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid="+metroid.toLowerCase()+"&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=990.99&zipcode=&zipcoderadius=&amenities=&projectid=");
//			U.log(commDataAPI);
			String commDataSecs[]=U.getValues(commDataAPI, "\"rowindex\":", ",\"Waitlist\":\"");
//			U.log(commDataSecs.length);
			for (String comData : commDataSecs) {
//					U.log(comData);	
					String subComms[]=U.getValues(comData, "{\"ProjectId\"", "\"PriceSeriesSeoUrlName\"");
					for (String subComm : subComms) {
						//U.log(subComm);
						String seoTracker=U.getSectionValue(subComm, "\"CommunitySeoUrlName\":\"", "\"");
						String comUrl="https://www.coventryhomes.com/"+metroUrl+seoTracker;
						//U.log(comUrl);
						String comAPIURL="https://app.mhinc.com/api/CommunityDetails?DBACode=cov&metroid="+metroid.toLowerCase()+"&CommunitySeoUrlName="+seoTracker;
						addDetails(comUrl, subComm,comAPIURL);
					//	break;
					}
				
			//	break;
			}
			//break;
		}
		LOGGER.DisposeLogger();
		//U.log(regionAPiHTml);
	}
	private void addDetails(String comUrl, String subComm, String comAPIURL) throws Exception {
		// TODO Auto-generated method stub
		//Single Run
//		if(!comUrl.contains("https://www.coventryhomes.com/dallas-ft-worth/southpointe-50ft-homesites-midlothianisd"))return;
		
		
		
		
		
		if(comAPIURL.contains("https://app.mhinc.com/api/CommunityDetails?DBACode=cov&metroid=h&CommunitySeoUrlName=merion-at-midtown-park"))return;
		U.log("comAPIURL: "+comAPIURL);
		String comHtmlAPI=getHTML(comAPIURL);

		String comHtmlAPI1 = comHtmlAPI;
		
		U.log("====="+comHtmlAPI);
		if(comHtmlAPI.contains("Projects\":[{\"rowindex"))
		comHtmlAPI = U.getSectionValue(comHtmlAPI, "{\"", "Projects\":[{\"rowindex");
		
		U.log("====="+comHtmlAPI);
		U.log(subComm+"\n"+comUrl);


if(data.communityUrlExists(comUrl)) {
	LOGGER.AddCommunityUrl(comUrl+"==========repeated");
	return;
	
}
		if (comUrl.contains("https://www.coventryhomes.com/dallas-ft-worth/dominionofpleasantvalley-50ft-homesites-garlandisd")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-50ft-homesites")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-60ft-homesites")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-50ft-homesites")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-60ft-homesites")
				||comUrl.contains("https://www.coventryhomes.com/dallas-ft-worth/sandbrockranch")
				||comUrl.contains("https://www.coventryhomes.com/austin/the-estates-at-flintrock")) {
			LOGGER.AddCommunityUrl(comUrl + "==========Return");
			return;

		}
		LOGGER.AddCommunityUrl(comUrl);
		String comName=U.getSectionValue(comHtmlAPI, "\"SubdivisionName\":\"", "\"");
		String add[]=new String[]{ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		add[0]=U.getSectionValue(comHtmlAPI, "\"Address\":\"", "\"");
		if(add[0].contains("<br>"))add[0]=add[0].replace("<br>", "");
		add[1]=U.getSectionValue(comHtmlAPI, "\"City\":\"", "\"");
		add[2]=U.getSectionValue(comHtmlAPI, "\"State\":\"", "\"");
		add[3]=U.getSectionValue(comHtmlAPI, "\"Zip\":\"", "\"");
		
		if(add[0]!=null)
		add[0]=add[0].replace("\\t", "").replaceAll("Visit us at our 65’ model:  |Visit us at our 60’ model:  |Visit us in Harvest Green:  ", "")
					 .replace("2500 Forest Creek Drive, #2502", "2500 Forest Creek Drive")
					 .replaceAll("Please Visit Us at Coastal Point:|Visit us in Hidden Lakes: <br>|Visit us in Harvest Green: <br> |We're available to meet you at any of our area model homes\\.", "");
		String latLng[]=new String[] {ALLOW_BLANK,ALLOW_BLANK};
		U.log(Arrays.toString(add));
		
//		U.log("mmmmmm"+Util.matchAll(comHtmlAPI, "[\\w\\s\\W]{30}29.7851890000[\\w\\s\\W]{30}", 0));
		latLng[0]=U.getSectionValue(comHtmlAPI, "\"Latitude\":\"", "\"");
		latLng[1]=U.getSectionValue(comHtmlAPI, "\"Longitude\":\"", "\"");
		U.log(Arrays.toString(latLng));
		
		if(add[0].length()==0) {
			add=U.getAddressGoogleApi(latLng);
			geo="TRUE";
		}
		
//		geo="TRUE";
		
		String descSec=U.getSectionValue(comHtmlAPI, "\"Description\":\"", "\",")+U.getSectionValue(comHtmlAPI, "\"PriceRangeMin\":\"", "\"");
//		U.log("descSec: "+descSec);
		String amenitiesSec=U.getSectionValue(comHtmlAPI, "\"Amenities\":[{", "],");
//		U.log(amenitiesSec);
		
		String availData="";
		String floorData="";
		try {
		String avaiSecs=U.getSectionValue(comHtmlAPI, "\"HomeItems\":[", "]");
		String availHomes[]=U.getValues(avaiSecs, "{\"JobId\":", "\"Scale\":null");
		for (String availHome : availHomes) {
			U.log("availHome::");
			availData+=availHome;
		}
		
		String floorPlanSecs=U.getSectionValue(comHtmlAPI, "\"Plans\":[{", "]");
		String floorPlans[]=U.getValues(floorPlanSecs,"{\"ProjectId\":", "\"PortfolioItemId\":null");
	
		for (String floorHome : floorPlans) {
			U.log("floorHome::");
		floorData+=floorHome;
		}
		}
		catch(NullPointerException ne) {
			
		}
//		U.log("&&&&&&&&&&&&&&"+Util.matchAll(comHtmlAPI+floorData+amenitiesSec+descSec+availData,"[\\w\\s\\W]{50}$470[\\w\\s\\W]{20}",0));

		comHtmlAPI=comHtmlAPI.replace("0's", "0,000").replace("0s", "0,000");
		
	//	U.log("&&&&&&&&&&&&&&"+Util.matchAll(comHtmlAPI+floorData+amenitiesSec+descSec+availData,"[\\w\\s\\W]{50}400[\\w\\s\\W]{50}",0));
		String prices[]=U.getPrices((comHtmlAPI+floorData+amenitiesSec+descSec+availData).replaceAll("FullPrice\":\"\\d+\",\"IsDiscounted\":\"1\"", ""), "From the \\d{3},\\d{3}|Upper \\d+,\\d+|SuggestedPrice\":\"\\d+|\\$\\d{3},\\d{3}|FullPrice\":\"\\d+\"|\"PriceRangeMin\":\"From the \\$\\d{3},\\d{3}|\"BasePrice\":\"\\d{6}\"", 0);
		U.log(Arrays.toString(prices));
		String sqft[]=U.getSqareFeet(floorData+amenitiesSec+descSec+availData, "\"SqFt\":\"\\d{4}\"", 0);
		U.log(Arrays.toString(sqft));
		
		
		
		String cType=ALLOW_BLANK;
		String descShortSec="";
		
		descShortSec=U.getSectionValue(comHtmlAPI, "\"DescriptionShort\":\"", "\"")
				+U.getSectionValue(comHtmlAPI, "\"PriceRangeMin\":\"", "\"");
		U.log(descShortSec);
		
		
		cType=U.getCommType((descSec+amenitiesSec+descShortSec).replace("beautiful waterfront","Waterfront Community"));
		
		String pType=ALLOW_BLANK;
		String[] imgSliderTxt = U.getValues(comHtmlAPI, "\"AltText\":\"", "\"");
		for(String img : imgSliderTxt)
			descSec+=img;
		if(comHtmlAPI.contains("\"HOA\":\""))
			descSec+=" HOA ";
		pType=U.getPropType((descSec+amenitiesSec+floorData+availData).replace("coastal experience", "coastal homes"));
		
//		

//		U.log("&&&&&&&&&&&&&&"+Util.matchAll(descSec+floorData+availData+amenitiesSec,"[\\w\\s\\W]{50}patio[\\w\\s\\W]{40}",0));
		String dType=ALLOW_BLANK;
		dType=U.getdCommType((descSec+floorData+availData+amenitiesSec).replace("\"Stories\":\"1.0\"", "1 Story").replace("\"Stories\":\"2.0\"", "2 Story")
				.replaceAll("Graham Branch Creek|fabulous one-and-a-half story home is perfect", ""));
		
		U.log("dprop type:::::::::::"+dType+"\n");
		
		String pStatus=ALLOW_BLANK;
		
		String[] sec = U.getValues(comHtmlAPI, "\"DescriptionShort\":\"", "\"");
		for(String s : sec) {
			U.log(s);
			descShortSec+=s.replace("Opportunities |", "Opportunities \\|");
		}
		U.log(descShortSec);
		

		
		if(descShortSec!=null)
			descShortSec = descShortSec.replace("Move-In Ready Homes Available Now", "Move-In Ready Homes");
		pStatus=U.getPropStatus((descShortSec+descSec+amenitiesSec).replace("high school (opening fall 2022)", "")
				.replace("Lake View & Oversized Homesites Available", "Lake View Oversized Homesites Available")
				.replace("Now Selling in Final Section", "Now Selling Final Section")
				.replaceAll("proximity is now available|school is now open|Lake House Now Open|Adventure Cove is coming in 2022|Coming Soon- The Grove will include|new adventure is coming soon|Learn more about the spacious new homes available in the prestigious|learn more about the new homes available in|Learn more about the family-friendly new homes available in|learn more about the new homes available in Paloma Lake|Elementary School Now Open|Camp Coming|Coming soon — a|Coming soon will|Dock \\(Coming|\"Amenity\":\"Coming|ConstructionStageText\":\" Coming|Coming Soon - The Dock|Coming 2021! The Grove|wetlands and coming|New Model Coming Soon|Coming Soon!Elev|school \\(opening fall 2021|Village \\(Coming|High \\(Coming Fall| Elementary, now open|Great selection of wooded and oversized lots available", ""));
		
//		U.log(Util.matchAll(descShortSec+descSec+amenitiesSec+subComm,"[\\w\\s\\W]{20}Coming Soon[\\w\\s\\W]{10}",0));
		if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
		if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
		
		if(prices[0]==null)prices[0]=ALLOW_BLANK;
		if(prices[1]==null)prices[1]=ALLOW_BLANK;
//		if(comUrl.contains("https://www.coventryhomes.com/houston/kleinorchard"))pStatus+=", New Section Now Open";
		if(comUrl.contains("https://www.coventryhomes.com/houston/thehighlands-60ft-homesites") || comUrl.contains("https://www.coventryhomes.com/houston/thehighlands-45ft-homesites"))
		if(!comName.contains("The Highlands"))
			comName = "The Highlands "+comName;
			
//		if(comUrl.contains("https://www.coventryhomes.com/houston/sienna-45ft-homesites"))pType+=", Patio Homes";
		
//		if(comUrl.contains("https://www.coventryhomes.com/houston/firethornewest-60ft-homesites")||comUrl.contains("https://www.coventryhomes.com/houston/firethorne-west-70ft-homesites")) {
//			pStatus="Temporarily Sold Out";
//		}
		
//		if(comUrl.contains("https://www.coventryhomes.com/houston/pomona-60ft-homesistes"))pStatus+=", Limited Opportunities Available";
//		if(comUrl.contains("https://www.coventryhomes.com/houston/pomona-65ft-homesites"))pStatus+=", Lake Lots Available";
//		if(comUrl.contains("https://www.coventryhomes.com/houston/pomona-75ft-homesites"))pStatus+=", Limited Opportunities Available, Lake Lots Available";
		//if(comUrl.contains("/austin/sonomaheights"))pStatus="Coming Summer/Fall 2021";
		
		if(comName.contains("Inventory"))
		{
			comName=comName.replace("Inventory", "");
		}
		if(pStatus.equals("New Homes Available, Now Available"))
		{
			pStatus=pStatus.replace("New Homes Available, Now Available", "Homes Now Available");
		}
		
			
		comName=comName.replace("Ii", "II");
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0],add[1].replace("Spring/Conroe", "Conroe"), add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPrice(prices[0], prices[1]);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replaceAll("Move-in Ready Homes|Move-in Ready", "Quick Move-in Homes"));
		data.addNotes(U.getnote(comHtmlAPI));
		data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		U.log("=============");
		
		
		j++;
		
	}

	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"216.169.73.65",34679));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language","en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			urlConnection.addRequestProperty("authorization", "Basic Y292Ym95bDo3OEJGMDQ4Ri04OEY5LTREQTMtODdBNS1FRUY0NkE2NzVBRkU6RkRFN0ZDM0YtMTM1Qi00OENFLUFDMDQtMjhBRTQ4QTQ2QTcz");
			urlConnection.addRequestProperty("referer", "https://www.coventryhomes.com/");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			
			U.log("gethtml expection: "+e);
			

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
//================================================================================================================================================================================================
	// TODO : Extract community details here
//	private void addDetails(String comLink, String commSec) throws Exception {
//
////	if(!comLink.contains("https://www.coventryhomes.com/austin/sonomaheights"))return;
//		// 1 Opportunity Remaining
//		if (comLink.contains("https://www.coventryhomes.com/houston/edgewater-50ft-homesites")) {
//			LOGGER.AddCommunityUrl(comLink + "==========Redirected to Region");
//			return;
//		}
//		if (comLink.contains("http://www.buildonyourlot-texas.com/locations/houston")) {
//			LOGGER.AddCommunityUrl(comLink + "==========Redirected to Region");
//			return;
//		}
//		if (comLink.contains("https://www.coventryhomes.com/houston/avalonatspringgreen-70ft-homesites")
//				|| comLink.contains("https://www.coventryhomes.com/dallas-ft-worth/sandbrockranch")
//				|| comLink.contains("https://www.coventryhomes.com/austin/parksideontheriver-50ft-homesites")
//				|| comLink.contains("https://www.coventryhomes.com/austin/parksideontheriver-60ft-homesites")
//				||comLink.contains("https://www.coventryhomes.com/dallas-ft-worth/dominionofpleasantvalley-50ft-homesites-garlandisd")) {
//			LOGGER.AddCommunityUrl(comLink + "==========Redirected to Region");
//			return;
//		}
////	U.log(commSec);
//		if (comLink.contains("https://buildonyourlot.coventryhomes.com")
//				|| comLink.contains("https://www.coventryhomes.com/dallas-ft-worth/dal-boyl-program-specs")
//				|| comLink.contains("https://www.coventryhomes.com/designcenter")
//				|| comLink.contains("http://www.buildonyourlot-texas.com/locations/sanantonio")
//				|| comLink.contains("http://www.buildonyourlot-texas.com/locations/austin")
//				|| comLink.contains("https://www.coventryhomes.com/houston/meadowsatimperialoaks-section3"))
//			return;
//
//		//if(!comLink.contains("thehighlands-60ft-homesites"))return;
////		if(j >= 120)
//		{
//			String commHtml = getHtml(comLink, driver);
//			String comm = commHtml;
//			U.log("Count: " + j + "---->url::> " + comLink);
//			// U.log(commHtml);
//			U.log("comSec=====================================================================> " + commSec);
//
//			// ----remove footer---
//			commHtml = U.removeSectionValue(commHtml, "<footer _ngcontent", "</html>");
//			
//			  String name=U.getSectionValue(commHtml, "</h5><h1>","</h1>");
//			  U.log("name::::::::::::::::"+name);
//			 
//			/*
//			 * if(name==null) { name=U.getSectionValue(commHtml, "</h5><h1>","</h1>" ); }
//			 */
//			String commName =name; 
//
//			commName=commName.replaceAll("amp; 70'|amp;", "");
//			U.log(":::::::" + commName);
//			
//			commName = commName.replace("Wolf Ranch South Fork Wolf Ranch", "Wolf Ranch");
//			U.log(j + "\tComName::::::::" + commName + "::::::::::::;");
//
//			String slider = U.getSectionValue(commHtml, "<ngx-slick-carousel class=\"carousel\">",
//					"</ngx-smart-modal>");
//
//			commName = commName
//					.replaceAll("Build on Your Lot - |- Gated|Build Your Dream Home|- Traditional| Patio Homes$", "")
//					.replaceAll("Kinder Ranch Kinder Ranch Prospect Creek", "Kinder Ranch Prospect Creek")
//					.replace("Timarron Lakes Timarron Lakes", "Timarron Lakes");
//			commName = commName.replaceAll("Rough Hollow Highland Terrace at Rough Hollow",
//					"Highland Terrace at Rough Hollow");
//			commName = commName.replaceAll("Rough Hollow Canyon Ridge at Rough Hollow", "Canyon Ridge At Rough Hollow");
//			if (comLink.contains("/houston/boylprogramspecs"))
//				commName = "Houston City Living";
//
//			U.log("comName=========================================================================> " + commName);
//			String mainSec = U.getSectionValue(commHtml, "<div class=\"contentWrapper", "</community>");
//			if (mainSec == null)
//				mainSec = "";
//
//			// -------------------------------------------------Address Latlon
//			// Sec---------------------------------
//			String detailAddSec = U.getSectionValue(commHtml, "mapaddress", "</p>");
//
//			U.log("Debug:\t" + detailAddSec);
//
//			String latlonSec = null;
//			String addSec = null;
//			if (detailAddSec != null) {
//				detailAddSec = detailAddSec.replace("<br>Spring/Conroe,", ", Conroe,")
//						.replace("Visit our sales office in<br>Cinco Ranch for more information<br>", "");
//				latlonSec = U.getSectionValue(detailAddSec, "?q=", "&amp;");
//				addSec = U.getSectionValue(detailAddSec, "<span class=\"fas fa-map-marker\">", "</a>");
//
//				if (addSec == null) {
//					addSec = U.getSectionValue(detailAddSec, "<span class=\"fa fa-map-marker\">", "</a>");
//				}
//			} else {
//				addSec = U.getSectionValue(commHtml, "id=\"nomap\">", "</p>");
//			}
//			if (addSec == null) {
//				addSec = U.getSectionValue(commHtml, "id=\"nomap\"", "</p>");
//			}
//			U.log("detailsAddSec====================> " + detailAddSec);
//			U.log("AddSec====================> " + addSec);
//			/**
//			 * @date 21 Dec 2018
//			 */
//			if (latlonSec == null && detailAddSec != null && detailAddSec.contains("href=\"")) {
//				U.log("Debug-1\t" + U.getSectionValue(detailAddSec, "href=\"", "\""));
//				String googleMapHtml = U.getHTML(U.getSectionValue(detailAddSec, "href=\"", "\""));
//				//FileUtil.writeAllText(U.getCachePath() + "/delete5.txt", googleMapHtml);
//				latlonSec = Util.match(googleMapHtml, "USA/@(\\d{2}\\.\\d{2,},-\\d{2}\\.\\d{2,}),", 1);
//				if (latlonSec == null) {
//					latlonSec = Util.match(googleMapHtml, "United\\+States/@(\\d{2}\\.\\d{2,},-\\d{2}\\.\\d{2,}),", 1);
//				}
//				if (latlonSec == null) {
//					latlonSec = U.getSectionValue(commHtml, "http://maps.google.com/maps?q=", "&a;");
//				}
//			}
//			U.log("latlng section ::" + latlonSec);
//
//			String latlon[] = { ALLOW_BLANK, ALLOW_BLANK };
//			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//			String note = ALLOW_BLANK;
//			String geo = "FALSE";
//			if (latlonSec != null) {
//				latlon = latlonSec.split(",");
//				geo = "TRUE";
//			}
//
//			if (addSec != null) {
//				addSec = addSec.replaceAll(
//						"style=\"font-size:1.25em\"><span>|We're available to meet you at any of our area model homes|Visit our Sales Office in Grayson Woods:<br>|Visit our Plantation Homes model:<br>",
//						"");
//				addSec = addSec.replaceAll(
//						"Visit the model in <br>Timarron Lakes:<br>|<span>Visit us in Hidden Lakes: <br> |Visit our models <br>in Artavia: <br>15231 Deseo Drive <br>|<span>Please visit us in Sienna Plantation|</span><span>Visit us in Harper's Preserve: <br>|class=\"address ng-star-inserted\" style=\"font-size: 1.25em;\">",
//						"");
//
//				addSec = addSec.replaceAll("</span>|<span>", "").replace("<br>", ",");
//				U.log("addSec :" + addSec);
//				add = U.getAddress(addSec);
//				U.log(Arrays.toString(add));
//			}
//			if (detailAddSec == null && addSec == null) {
//				detailAddSec = U.getSectionValue(commHtml, "<p id=\"nomap", "</p>");
//				U.log(detailAddSec);
//				if (detailAddSec != null)
//					add = U.findAddress(detailAddSec);
//			}
//			if (add == null)
//				add = new String[] { "-", "-", "-", "-" };
//			note = U.getnote(commHtml.replaceAll(
//					" Pre-Selling Final Section \\| Limited Lots Available&q;,&q;|&q;Pre-Grand Opening|DescriptionShort&q;:&q;Now Pre-Selling - Visit Us in The Woods of Boerne|Coventry Homes Begins Pre-Sales in|homes-begins-presales-|under construction, while presales are being held from Coventry Homes|Pre-sales of the seven will |Pre-sales of the seven|Presales are slated",
//					""));
//
//			if (comLink.contains("https://www.coventryhomes.com/houston/fulshearcreekcrossing-90ft-homesites")) {
//				add[1] = "Fulshear";
//				add[2] = "TX";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//				note = "Address and LatLng Taken From City and State";
//				geo = "True";
//			}
//			if (comLink.contains("https://www.coventryhomes.com/houston/boylprogramspecs")) {
//				add[1] = "Houston";
//				add[2] = "TX";
//				add[3] = "77024";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//				geo = "True";
//			}
//			if (comLink.contains("https://www.coventryhomes.com/houston/firethorne-west-70ft-homesites")
//					|| comLink.contains("houston/firethornewest-60ft-homesites")) {
//				add[1] = "Katy";
//				add[2] = "TX";
//				add[3] = "77494";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//				geo = "True";
//			}
//
////		if(comLink.contains("https://www.coventryhomes.com/houston/graysonwoods60")||comLink.contains("https://www.coventryhomes.com/houston/graysonwoods70")){
////			add[1]="Katy City";
////			add[2]="TX";
////			latlon=U.getGoogleLatLngWithKey(add);
////			add=U.getGoogleAddressWithKey(latlon);
////			note="Address and LatLng Taken From City and State";
////			geo="True";
////		}
//
///*			if (comLink.contains("https://www.coventryhomes.com/austin/the-hollows")) {
//				add[1] = "Jonestown";
//				add[2] = "TX";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//				note = "Address and LatLng Taken From City and State";
//				geo = "True";
//			}*/
//			if (comLink.contains("https://www.coventryhomes.com/sanantonio/stillwaterranch-45ft-homesites")) {
//				add[0] = "7646 Goldstrike Dr";
//				add[1] = "San Antonio";
//				add[2] = "TX";
//				add[3] = "78254";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//
//			}
//			if (comLink.contains("https://www.coventryhomes.com/sanantonio/stillwaterranch-50ft-homesites")) {
//				add[0] = "7646 Goldstrike Dr";
//				add[1] = "San Antonio";
//				add[2] = "TX";
//				add[3] = "78254";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//
//			}
///*			if (comLink
//					.contains("https://www.coventryhomes.com/austin/new-homes-georgetown-tx-wolf-ranch-46ft-patio")) {
//				add[1] = "Georgetown";
//				add[2] = "TX";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//				note = "Address and LatLng Taken From City and State";
//				geo = "True";
//			}
//*/			if (comLink.contains("https://www.coventryhomes.com/austin/buildonyourlot-gabrielsgrove")) {
//				add[1] = "Austin City";
//				add[2] = "TX";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//				note = "Address and LatLng Taken From City and State";
//				geo = "True";
//			}
//			// ||comLink.contains("https://www.coventryhomes.com/sanantonio/arborsatfairoaksranch-80ft-homesites")
//			if (comLink.contains("https://www.coventryhomes.com/sanantonio/arborsatfairoaksranch-90ft-homesites")) {
//				add[1] = "Boerne City";
//				add[2] = "TX";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//
//				if (note.length() < 2) {
//					note = "Address and LatLng Taken From City and State";
//				} else {
//					note = note + ", Address and LatLng Taken From City and State";
//				}
//				geo = "True";
//			}
//			// https://www.coventryhomes.com/austin/sonomaheights
//
//			if (comLink.contains("https://www.coventryhomes.com/austin/sonomaheights")) {
//				add[1] = "Round Rock";
//				add[2] = "TX";
//				latlon = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latlon);
//
//				if (note.length() < 2) {
//					note = "Address and LatLng Taken From City and State";
//				} else {
//					note = note + ", Address and LatLng Taken From City and State";
//				}
//				geo = "True";
//			}
//
//			String lat = latlon[0];
//			String lng = latlon[1];
//			U.log("::::::::::::" + lat + "," + lng);
//			if (add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK) {
//				if (latlon[0].length() > 3 && latlon[1].length() > 4) {
//					add[0] = U.getGoogleAddressWithKey(latlon)[0];
//					geo = "TRUE";
//				}
//			}
//
//			if (add[0] == ALLOW_BLANK && latlon[0] != null && latlon[0] != ALLOW_BLANK) {
//				if (!lng.contains("-"))
//					lng = "-" + lng;
//				;
//				add = U.getGoogleAddressWithKey(latlon);
////				add=U.getBingAddress(lat, lng);
//				geo = "TRUE";
//				U.log(Arrays.toString(add));
//			}
//			if (add[0].length() > 4 && lat.length() < 4) {
//				latlon = U.getlatlongGoogleApi(add);
//				if (latlon == null)
//					latlon = U.getGoogleLatLngWithKey(add);
//				lat = latlon[0];
//				lng = latlon[1];
//				geo = "TRUE";
//			}
//			if (add[1].length() > 3 && lat.length() < 4) {
//				latlon = U.getlatlongGoogleApi(add);
//				if (latlon == null)
//					latlon = U.getGoogleLatLngWithKey(add);
//				U.log("ffffffff1" + Arrays.toString(latlon));
//				lat = latlon[0];
//				lng = latlon[1];
//				geo = "TRUE";
//			}
//			if (add[0].length() < 4 && lat.length() > 4) {
//				String[] latlon1 = { lat, lng };
//				add = U.getAddressGoogleApi(latlon1);
//				if (add == null)
//					add = U.getGoogleAddressWithKey(latlon1);
//				U.log("ffffffff" + Arrays.toString(add));
//				geo = "TRUE";
//			}
//
//	/*		if (comLink.contains("https://www.coventryhomes.com/sanantonio/arborsatfairoaksranch-80ft-homesites")) {
//				add[0] = "Boerne City Park";
//				add[1] = "Boerne";
//				add[2] = "TX";
//				add[3] = "78006";
//				// latlon=U.getGoogleLatLngWithKey(add);
//				// add=U.getGoogleAddressWithKey(latlon);
//				geo = "True";
//			}*/
//
//			// -------------------------------------------------PriceSec---------------------------------
//
//			String rem1 = U.getSectionValue(commHtml, "<html style=", "</app-footer>");
//			// U.log(rem1);
//			if (rem1 != null) {
//				U.log("hhhhhh");
//				commHtml = rem1;
//			}
//
//			String remSecc = U.getSectionValue(commHtml, "<script src=\"runtime", "</body>");
//			if (remSecc != null) {
//				commHtml = commHtml.replace(remSecc, "");
//			}
//
//			commHtml = commHtml.replace("q;HOA", "").replaceAll(
//					"Homes are priced from the \\$\\d{3},\\d{3}|Savings of up to \\$\\d{3},\\d{3}|priced from the \\$\\{3},\\d{3}|Homes are priced from the \\$\\d{3},\\d{3}s| \\$\\d+,\\d{3} in savings|revenue of more than \\$\\d+ million|offers homes from the \\$\\d{3},\\d{3}s to \\$\\d{3},\\d{3}s|homes priced from the \\$\\d{3},\\d{3}s to the \\$\\d{3},\\d{3}s|Designs priced from \\$\\d{3},\\d{3}s to the \\$\\d{3},\\d{3}s",
//					"");
//
//			String price[] = { ALLOW_BLANK, ALLOW_BLANK };
//			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			
//			commHtml = U.removeSectionValue(commHtml, "<h3>Promotions</h3>", "<mortgagecalc").replaceAll(
//					"<span class=\"strikethrough ng-star-inserted\">\\$\\d,\\d{3},\\d{3}</span>|<span class=\"strikethrough ng-star-inserted\">\\$\\d{3},\\d{3}</span>",
//					"");
//
//			commHtml = U.removeSectionValue(commHtml, "<div class=\"calculatorResults\">",
//					"<div class=\"disclaimer\">");
//			commHtml = U.removeSectionValue(commHtml, "<label>Mobile Phone</label>",
//					"<p><input class=\"button full\" name=\"submit\" value=\"Send\" type=\"submit\"></p>");
//			mainSec = mainSec.replace("0's", "0,000").replace("$1.05 Million", "$1,050,000 Million");
//			commHtml = commHtml.replaceAll("Up to \\$\\d+,\\d+ in savings on move-in ready homes", "");
//			
//			
//			String remSec = U.getSectionValue(commHtml, "<h3>Nearby Communities</h3>",
//					"<div class=\"tabItem mediumWeight\" data-id=\"content_promotions\">");
//			// U.log(remSec);
//			if (remSec != null)
//				commHtml = commHtml.replace(remSec, "");
//			// mainSec=mainSec.replace("From the $380's", "From the $380,000");
//			commHtml = commHtml.replaceAll("0's|0’s|0&s;s&q;", "0,000").replace("$1.05 Million", "$1,050,000 Million")
//					.replaceAll(
//							" value=\"\\$\\d{3},\\d{3} \\+\">\\$\\d{3},\\d{3} \\+</option>|value=\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</option>",
//							"");
////			U.log(commHtml);
////			U.writeMyText(commHtml);
//			rem1 = U.getSectionValue(commHtml, "class=\"whereWeBuild\"", "tabItem mediumWeight");
//			if(rem1 == null) rem1 = U.getSectionValue(commHtml, "class=\"whereWeBuild\"", "<form ngnativevalidate=");
//			if(rem1 != null)commHtml = commHtml.replace(rem1, "");
//			
//			// --remove all strikethrough prices---
////			U.log(commHtml);
//			if(commHtml == null) commHtml = ALLOW_BLANK;
//			commHtml = commHtml.replaceAll("strikethrough\">\\$(\\d,)*\\d+,\\d+", "");
////		U.log(Util.match(commHtml, ".*440.*"));
//			commSec = commSec.replace("From the $229's", "From the $229,000");
//
//			price = U.getPrices(commSec + commHtml,
//					"From the Lower \\d{3},\\d{3}|from the mid \\$?\\d{3},\\d{3}|<div class=\"price\"> \\$\\d{3},\\d{3}</div>|\\$\\d{1},\\d{3},\\d{3} Million|From \\$\\d{1},\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}",
//					0);
//			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
//			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//
//			// -----------------------------------------------Sqft-----------------------------------------
//
//			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//
//			String[] sqft = U.getSqareFeet(mainSec + commSec,
//					"\\d,\\d{3} - \\d,\\d{3} SQ. FT|\\d{4} TO \\d{4} SQ. FT.|\\d,\\d{3} to \\d,\\d{3} square footage|\\d,\\d{3} to \\d,\\d{3} square-feet|\\d{4} to \\d{4} Sq.Ft.|\\s+\\d{4} sqft\\s+|enjoy a \\d,\\d{3}-square-foot|\\d{4} sqft ",
//					0);
//
//			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
//			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			U.log("Min Sq :" + minSqf + " Max Sq :" + maxSqf);
//
//			if (comLink.contains("https://www.coventryhomes.com/houston/townelake-70-and-80ft-homesites")) {
//				minSqf = "3190";
//				maxSqf = "4584";
//			}
//
//			// ---------------------------------------com
//			// type---------------------------------
//			commHtml = commHtml.replaceAll(
//					"Valley Ranch|Cypress Ranch|Rita Ranch|Ranch Rd|Stillwater Ranch|Oaks Ranch|ranchosantafe|ranch\\d+|Wolf Ranch|[r|R]anch\\s*\"|oventry Homes design in the gated and well-located Alden Woods is..|Cinco Ranch for more information|Fair Oaks Ranch Golf and Country Club|and active adults",
//					"");
//			
//			//U.log(commHtml);
//			
//			String dPropType = U.getdCommType(commHtml + commSec);
//			U.log("dPropType:::::: " + dPropType);
////		U.log("MMMMMMM "+Util.matchAll(commHtml+commSec, "[\\s\\w\\W]{30}Ranch[\\s\\w\\W]{30}", 0));
//			String remSecNews = U.getSectionValue(commHtml, "class=\"tabContainer\"", "</footer>");
//			if (remSecNews != null) {
//				commHtml = commHtml.replace(remSecNews, "");
//			}
////		remSecNews=U.getSectionValue(commHtml, "newstype=N&q;:{", "}]");
////		U.log(remSecNews);
//			String Type = U.getCommunityType(commHtml.replaceAll("master planned community on Lake Travis", ""));
//			U.log(Type);
//
//			// ------------Derived Type-----------------
//
//			// ----HomesData----
//			String allAvailHomesData = ALLOW_BLANK;
//			for (String availUrl : U.getValues(commHtml,
//					"<!----><a href=\"" + comLink.replace("https://www.coventryhomes.com", "") + "/home/", "\">")) {
//
//				availUrl = comLink + "/home/" + availUrl;
//				U.log("availUrl : " + availUrl);
//				String availHtml = getHtml(availUrl, driver);
//				allAvailHomesData += U.getSectionValue(availHtml, "class=\"details\"", "</p>");
//			}
//
//			// --------------------property type----------
//			String proptype;
//			commHtml = commHtml.replaceAll(
//					"craftsmanship|Estimated dues|Homeowner Services</a></span>|homeowners association fees|feedback of every homeowner",
//					"");
//			commHtml = commHtml.replaceAll("<img(.*?)>", "").replaceAll("Classical and Mediterranean",
//					"mediterranean-style");
//			String rem = "value=\"zh-TW\">(\\s+)?Chinese \\(Traditional";
//			// U.log(commHtml);
//			if (remSec != null) {
//				allAvailHomesData = allAvailHomesData.replace(remSec, "");
//			}
//			proptype = U.getPropType(commSec + (commHtml + allAvailHomesData).replaceAll(rem, ""));
//
//			// ---------------------prop status----------------
//			String propStatus = ALLOW_BLANK;
//
//			String[] r = U.getValues(commHtml, "DescriptionShort", "!");
//			for (String rr : r) {
//				commHtml = commHtml.replace(rr, "");
//			}
//			commSec = commSec.replace("Close-Out Specials!", "Close-Out");
//			commSec = commSec.replace("now Selling Functional", "Now Selling")
//					.replaceAll("\\d+' Homesites Now Available|\\d+’ Homesites Now Available|price for a limited time|Floor plans coming soon|New Community Coming Soon", "");
//			commHtml = commHtml.replace("q;Floor Plans Coming Soon", "")
//					.replaceAll(" Pre-Selling Final Section \\| Limited Lots Available&q;,&q;|\\d+' Homesites Now Available|\\d+’ Homesites Now Available|Coventry Homes is now available|Coming soon — a chance|\\(Coming Soon\\)|Coming Soon - The Hive|Coming Soon - The Dock|ready for sale in Round|Model Now Open|Elementary, now open|Coming 2021! The Grove|Camp Coming Soon|clubhouse coming May 2020|The Backyard \\(coming soon\\)|about the new homes|price for a limited time|Now open, The Backyard|model home now open|Coming soon, Pomona will be introduci|New Model Coming Soon| School set to open Fall 2020|Elementary - Coming Fall 2020|On Site Prosper ISD Coming 2020|roximity is now available in the new|Coming Soon! - A|Lake House is coming|Twilight Park - Coming|Twilight Park - Coming|Mystic Pond - Coming|select move-in ready homes|Floor plans coming soon|The Backyard Coming Fall 2019|Mystic Pond - Coming Soon! Enjoy a|Coming Soon - Paperback Park|2  Acre Lots Available|Frisky Biscuit Dog Park - Coming Soon|The Lake House additions are coming soon|Twilight Park - Coming Soon|Learn more about the spacious new homes availabl|community's Public Grand Opening event|community's Grand Opening event|Grand Opening and Sales informatio|before the community's Grand Opening|in savings on move-in ready homes|New Community Coming Soon!|receive Grand Opening and |Coming Soon Contact|Grand Opening Event|Grand Opening and Sales|Coming Soon Contact|is now open in the Prosper community|Edgestone at Legacy Now Open|Home Now Open in Star Trail|Coming May 2018!|<div class=\"movein\">|\"bannerHeadline\">Move-In Ready Homes Available!|\"movein\"><span>|now open!|new homes available in Pomona|new homes available in the prestigious|new homes available in Grand Mesa at Crystal|grand opening of its newest Aus...|oversized lots available"
//							+ "|School - Opening|\\(Coming Fall |\\(opening fall |Backyard Coming Spring|Additionally, coming Spring|Additionally, coming soon|nder construction or ready for move-in","").replace("New Sections &amp; Floor Plans Now Available",	"New Sections & Floor Plans Now Available");
////		U.log(Util.match(commSec, ".*lots available.*"));
//
////			U.writeMyText(commHtml + commSec);
//			propStatus = U.getPropStatus((commHtml + commSec)
//					.replaceAll("Trails Now Open|Elementary Now Open|elementary school is now open|New Model Now Open", "").replaceAll("Move-In Ready Homes Available( Now)?", "Move-In Ready Homes")
//					.replaceAll("Now Selling In Final Section|Now Selling In Our Final Sections", "Now Selling Final Section")
//					.replace("Ii", "i"));
//			U.log("MMMMMMMMMMMMMMMMMMm "+Util.matchAll(commHtml + commSec,"[\\w\\s\\W]{30}Move-[\\w\\s\\W]{30}",0));
//			/*if (comm.contains("JobNumber")) {
//
//				if (propStatus.contains("Move"))
//					propStatus = propStatus.replace("Move-in Ready Homes", "Quick Move-in Homes");
//				
//				if (!propStatus.contains("Quick") && propStatus.length() > 2)
//					propStatus = propStatus + ", Quick Move-in Homes";
//				else if (propStatus.length() < 2)
//					propStatus = "Quick Move-in Homes";
//
//			}*/
//
//			if (comLink.contains("https://www.coventryhomes.com/dallas-ft-worth/dominionofpleasantvalley-60ft-homesites-garlandisd"))
//				if (propStatus.length() > 3)
//					propStatus += ", New Plans Now Available";
//				else
//					propStatus = "New Plans Now Available";
//			
//			if (comLink.contains("https://www.coventryhomes.com/austin/new-homes-san-marcos-tx-la-cima-70ft") 
//					|| comLink.contains("https://www.coventryhomes.com/sanantonio/new-homes-cibolo-foxbrook-65ft-homesites")
//					|| comLink.contains("https://www.coventryhomes.com/sanantonio/new-homes-cibolo-foxbrook"))
//				if (propStatus.length() > 3)
//					propStatus += ", Greenbelt Homesites Available";
//				else
//					propStatus = "Greenbelt Homesites Available";
//
////			if (comLink.contains("https://www.coventryhomes.com/austin/the-hollows-60ft"))
////				if (propStatus.length() > 3)
////					propStatus += ", Homesites Available";
////				else
////					propStatus = "Homesites Available";
//			
//			propStatus = propStatus.replace("Quick Move-in Homes Available", "Quick Move-in Homes");
//			commName = commName
//					.replaceAll("The Estates at Woods of Boerne The Woods of Boerne", "The Estates At Woods Of Boerne")
//					.replaceAll(" - New Section$", "");
//			if (comLink.contains("/dallas-ft-worth/waterbrook-65ft-homesites"))
//				propStatus = propStatus.replace(", Quick Move-in Homes", "");
//			add[0] = U.getCapitalise(add[0].toLowerCase());
////https://www.coventryhomes.com/austin/sonomaheights	
//			if (propStatus.length() < 4)
//				propStatus = ALLOW_BLANK;
//			if (data.communityUrlExists(comLink)) {
//				LOGGER.AddCommunityUrl("ALL READT EXIT =====" + comLink);
//				return;
//			}
//
//			/*if (comLink.contains("https://www.coventryhomes.com/austin/the-hollows-60ft")) {
//				commName = "The Hollows On Lake Travis 60";
//				note = ALLOW_BLANK;
//			}*/
//			/*if (comLink.contains("https://www.coventryhomes.com/austin/the-hollows")) {
//				commName = "The Hollows On Lake Travis 80";
//				note = ALLOW_BLANK;
//			}*/
//			if (comLink.contains("https://www.coventryhomes.com/houston/jordanranch")) {
//				proptype = proptype.replace(", Patio Homes", "");
//			}
//			if (comLink.contains("https://www.coventryhomes.com/austin/the-hollows-60ft") || comLink.contains("https://www.coventryhomes.com/austin/new-homes-san-marcos-tx-la-cima-60ft") || comLink.contains("https://www.coventryhomes.com/austin/new-homes-san-marcos-tx-la-cima-70ft")) {
//				propStatus = propStatus.replaceAll("Homesites Now Available,|Homesites Now Available|, Homesites Now Available", "");
//			}
//			
//			// https://www.coventryhomes.com/houston/pomona-60ft-homesites
//			if (comLink.contains("https://www.coventryhomes.com/houston/pomona-60ft-homesites")) {
//				propStatus = propStatus.replace(", Move-in Ready Homes", "");
//			}
//			if (comLink.contains("https://www.coventryhomes.com/austin/new-homes-round-rock-tx-paloma-lake-65ft")) {
//				propStatus = propStatus.replace(", Quick Move-in Homes", "");
//			}
//			if (comLink.contains("https://www.coventryhomes.com/dallas-ft-worth/mustanglakes-74ft-homesites")
//					|| comLink.contains("https://www.coventryhomes.com/austin/new-homes-san-marcos-tx-la-cima-50ft"))
//				propStatus = propStatus.replace("Now open,", "");
//
//			if (propStatus.contains("Coming Fall 2020,"))
//				propStatus = propStatus.replace("Coming Fall 2020,", "New Homesites Coming Fall 2020,");
//			if (propStatus.contains("Coming Winter 2020,"))
//				propStatus = propStatus.replace("Coming Winter 2020,", "New Homes Coming Winter 2020,");
//			if(comLink.contains("thehighlands-45ft-homesites")||comLink.contains("thehighlands-60ft-homesites"))commName="The Highlands "+commName;
//			
//			if(propStatus.length()<3)
//				propStatus = ALLOW_BLANK;
//
//			LOGGER.AddCommunityUrl(comLink);
//			data.addCommunity(commName.replaceAll(
//					"New Homes Georgetown Tx|New Homes|New Homes Pflugerville Tx|New Homes Round Rock Tx|New Homes Kyle Tx|New Homes San Marcos|New Homes Lago Tx|New Homes Liberty Hill Tx|New Homes San Antonio Tx|New Homes San Antonio",
//					""), comLink, Type);
//			data.addAddress(add[0], add[1], add[2], add[3]);
//			data.addSquareFeet(minSqf, maxSqf);
//			data.addPrice(minPrice, maxPrice);
//			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
//			data.addPropertyType(proptype, dPropType);
//			data.addPropertyStatus(propStatus);
//			data.addNotes(note);
//
//		}
//		j++;
//	}

	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;
		U.log(url);

		String host = new URL(url).getHost();
		host = host.replace("www.", "");

		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();

		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.get(url);
					// U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,800)", "");
					Thread.sleep(15000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}
