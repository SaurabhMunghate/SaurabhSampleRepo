/**
 * @author saurabh
 * @date Sap 2022
 * 
 */
package com.shatam.b_041_060;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDSLD_Homes extends AbstractScrapper {

	int i = 0;
	static int j = 0, count = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	private static final String BASEURL = "https://www.dsldhomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractDSLD_Homes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "DSLD Homes.csv", a.data().printAll());
	}

	// WebDriver driver=new FirefoxDriver();
	// private String commType;
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String,String>();
	public ExtractDSLD_Homes() throws Exception {

		super("DSLD Homes", BASEURL);
		LOGGER = new CommunityLogger("DSLD Homes");
	}

	public void innerProcess() throws Exception {
		String basehtml = U.getHTML(BASEURL);

		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(basehtml, "__PRELOADED_STATE__ =", "</script>");
//		U.log(removeScript.length());
//		if (removeScript == null)
//			removeScript = "";
		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
//		U.log(jobj.size());
//		String redirecrSec=U.getSectionValue(removeScript, "\"redirects\":", "]");
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities").getAsJsonObject().get("5702af75f410954eb27ce27a");
		JsonArray comJsonData = (JsonArray) commJson.getAsJsonObject().get("data");
//		U.log(comJsonData);
		U.log("Total communities are = "+comJsonData.size());
		U.log("comJsonData"+comJsonData.size());
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans").getAsJsonObject().get("5702af75f410954eb27ce27a");
		JsonArray planJsonData = (JsonArray) planJson.getAsJsonObject().get("data"); U.log("planJsonData"+planJsonData.size());
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes").getAsJsonObject().get("5702af75f410954eb27ce27a");
		JsonArray homeJsonData = (JsonArray) homeJson.getAsJsonObject().get("data"); U.log("homeJsonData"+homeJsonData.size());
		
		String comm[] = U.getValues(comJsonData.toString(), "{\"@type\":\"GatedResidenceCommunity", "\"type\":\"community\"}"); U.log(comm.length);
		
		String plans[] = U.getValues(planJsonData.toString(), "{\"@type\":\"ProductModel\"", "\"planType\":\"Single Family\"}"); U.log(plans.length);

		String homes[] = U.getValues(homeJsonData.toString(), "{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}"); U.log(homes.length);
		
		
		for (String home : homes) {
			String comunityIn = U.getSectionValue(home, "\"containedIn\":\"", "\",");
//			U.log(comunityIn);
			homesData.put(comunityIn, home);
		}
//		U.log(homes[0]);
		for (String plan : plans) {
				String comunityIn = U.getSectionValue(plan, "\"community\":\"", "\",");
//				U.log(comunityIn);
				plansData.put(comunityIn, plan);
		}
		U.log("homesData="+homesData.size());
		U.log("plansData="+plansData.size());
      
		String mainhtml = U.getHTML("https://www.dsldhomes.com/communities");

		String communtiesection[] = U.getValues(mainhtml, "<a class=\"col-10 mr-auto CommunityCard_title px-0\"",
				"View Detail");
		U.log("communtiesection ::"+communtiesection.length);
//		int i = 0;
		HashMap<String, String> url = new HashMap<>();
		for (String commurl : communtiesection) {
			
			String communityurl = "https://www.dsldhomes.com/" + U.getSectionValue(commurl, "href=\"/", "\"")+"0";
			String communityurl1 = U.getSectionValue(communityurl, "ities/", "0")+"0";
			String communityurl2 = U.getSectionValue(communityurl1, "/", "0")+"0";
			String communityurl3 = U.getSectionValue(communityurl2, "/", "0");
//            U.log(communityurl3);
			String comName = U.getSectionValue(commurl, "-->", "<!--");
//			U.log(comName);
			url.put(communityurl3, communityurl);
			

		}
		U.log(url.size());

        int i = 0;
		for (JsonElement comJsonData1 : comJsonData) {
			String uu = U.getSectionValue(comJsonData1.toString(), "\"sharedName\":", "\",").replace("\"", "").toLowerCase();
//			String cooname = U.getSectionValue(comJsonData1.toString(), " \"metaTags\": {","\"title\":"); U.log(cooname);
			String commUrl = url.get(uu).replace("0", "");
//            U.log(i+":::"+commUrl);
i++;
			addDetails(commUrl , comJsonData1);
//			//break;			
		}
//		U.log(">>>>>" + comSection.length);
//		U.log(count);
		LOGGER.DisposeLogger();
	}
	private void addDetails(String cUrl, JsonElement cSec) throws Exception {
		// TODO Auto-generated method stub
//		if(j>=15)
	//	{
//	try	{
  
		
//		if(!cUrl.contains("https://www.dsldhomes.com/communities/alabama/huntsville/crystal-creek"))return;
//		U.log("csectip&&&&&&&&&&&&&"+cSec.toString());
//			if(!cUrl.contains("14"))return;
			LOGGER.AddCommunityUrl(cUrl);
			String add[] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
			String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
			String note = ALLOW_BLANK;
			String geo = "FALSE";
			String comId = U.getSectionValue(cSec.toString(), "\"_id\":\"", "\"");
			JsonParser jparser = new JsonParser();
//			JsonArray jobj = (JsonArray) jparser.parse(cSec).getAsJsonArray();
//			U.log(jsonData);
//			String comName=cSec.getAsJsonObject().get("com_name").toString().replace("\"", "");
//			String id=cSec.getAsJsonObject().get("com_id").toString().replace("\"", "");
			String streetAddress=cSec.getAsJsonObject().get("address").toString().replace("\"", "");
//			String streetAddress1=cSec.getAsJsonObject().get("highSchool").toString().replace("", "");
//			streetAddress1 = U.getHtmlSection(streetAddress1, "address", "city").replace("\\n", "");
			U.log(streetAddress);
//			U.log(streetAddress1);
//			.matches(".*\\d.*");
			
			
			
//			add = U.getAddress(streetAddress1);
			
//			streetAddress = U.removeSectionValue(streetAddress, "\"addressCountry\":\"", "\"},\"addressCounty\":\"");
			add[0] = U.getSectionValue(streetAddress, "streetAddress:", "}");  U.log(add[0]);
			add[1] = U.getSectionValue(streetAddress, "addressLocality:", ","); U.log(add[1]);
			add[2] = U.getSectionValue(streetAddress, "addressRegion:", ","); U.log(add[2]);
			add[3] = U.getSectionValue(streetAddress, "postalCode:", ","); U.log(add[3]);
            U.log(cSec.toString());
			String geoIndexed=cSec.getAsJsonObject().get("geoIndexed").toString().replace("", ""); U.log(geoIndexed);
//			latlag[0] = U.getSectionValue(cSec.toString(), "\"lat\":\"", "\",");  U.log(latlag[0]);
//			latlag[1] = U.getSectionValue(cSec.toString(), "\"lon\":\"", "\","); U.log(latlag[1]);
			U.log(geoIndexed);
			latlag[1] = U.getSectionValue(geoIndexed, "[",",");
			latlag[0] = U.getSectionValue(geoIndexed, ",","]");
//			U.log("geoIndexed"+latlag[0]+" "+latlag[1]); 
			//===================================================================================================

			if(latlag[0]==ALLOW_BLANK || latlag[0] == null || latlag[0].length()==0) {
//				latLng=U.getGoogleLatLngWithKey(add);
				latlag=U.getlatlongGoogleApi(add);
//				geo="True";
//				note="lat long Taken From add";
//				U.log("geo"+latlag[0]+" "+latlag[1]); 
			}
//			if(add[0]==ALLOW_BLANK&&latlag[0]!=ALLOW_BLANK) {
//				add=U.getAddressGoogleApi(latlag);
//				geo="True";
//			}
			//===================================================================================================
			U.log("cSeccSeccSec"+cSec.toString());
            //===================================================================================================
			
			ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId);
			String homesecs = ALLOW_BLANK;
			if (homeData != null) {
				for (String home : homeData) {
					homesecs += home;
				}
			}
			String storySec=ALLOW_BLANK;
			ArrayList<String> planData = (ArrayList<String>) plansData.get(comId);
			String plansecs = ALLOW_BLANK;
			if (planData != null) {
				for (String plan : planData) {
					plansecs += plan;
				}
				
			}
			String[] price = U.getPrices( cSec.toString() +plansecs +homesecs ,
					"\"priceLow\":\\d{6},|\"priceHigh\":\\d{6},", 0);
			U.log("price=="+price[0] + " " + price[1]);
			if(price[1] == null) {
				price[1] = ALLOW_BLANK;
			}
			if(price[0] == null) {
				price[0] = ALLOW_BLANK;
			}
			
			String[] sqft = U.getSqareFeet(cSec.toString() +plansecs +homesecs 
					, "\"sqftHigh\":\\d{4},|\"sqftLow\":\\d{4},", 0);
			U.log("sqft==="+sqft[0] + " " + sqft[1]);
			if(sqft[1] == null) {
				sqft[1] = ALLOW_BLANK;
			}
			if(sqft[0] == null) {
				sqft[0] = ALLOW_BLANK;
			}
           
			//===================================================================================================
			
			String comName = U.getSectionValue(cSec.toString(), "filename", "pdf").replace(":", "");
			comName = U.removeSectionValue(comName, "-", ".").replace("-.", "").replace("\"\"", "").replace(".", "").replace("Ph 3", "").replace("Ph 6", "").replace("Ph 2", "");
			
			U.log(comName);
			String comType = U.getCommunityType(cSec.toString()+plansecs+homesecs);
			U.log("comType=="+comType);
			String propStatus = U.getPropStatus(cSec.toString()+plansecs+homesecs);
			U.log("propStatus=="+propStatus);
			String propType = U.getPropType(cSec.toString()+plansecs+homesecs);
			U.log("propType=="+propType);
			String dpType = U.getdCommType(cSec.toString()+plansecs+homesecs);
			U.log("dpType=="+dpType);
//			U.log(cUrl);
//			U.log(add[0]);
//			U.log(add[1]);
//			U.log(add[2]);
//			U.log(add[3]);
			
			//===================================================================================================


			data.addCommunity(comName, cUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim() , add[3].trim());
			data.addLatitudeLongitude(latlag[0].trim().replace("[", ""), latlag[1].trim().replace("]", ""), geo);
			data.addPrice(price[0], price[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
//		}
		j++;
		i++;
//		}
//
//	}catch (Exception e) {}
}

	public static String getNoHtml(String html) {
		String noHtml = null;
		noHtml = html.toString().replaceAll("\\<.*?>", " ");
		return noHtml;
	}
}
