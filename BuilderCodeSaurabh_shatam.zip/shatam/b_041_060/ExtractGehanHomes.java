/**
l * @author Rakesh Chaudhari
 * @date 22 Jun 2015
 * 
 */
/**
 * @author Rakesh Chaudhari
 * @date 22 Jun 2015
 * 
 */
package com.shatam.b_041_060;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGehanHomes extends AbstractScrapper {
	CommunityLogger Logger;
	static int i = 0;
	public static int k=0;
	public int inr = 0;
	public static int duplicates = 0;
	String latlngs[];
	static WebDriver driver = null;
	

	public static void main(String[] args) throws Exception {

		
		AbstractScrapper a = new ExtractGehanHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Gehan Homes.csv", a.data().printAll());
		U.log(duplicates);
		U.log(i);
	}

	public ExtractGehanHomes() throws Exception {

		super("Gehan Homes", "https://www.gehanhomes.com/");
		Logger = new CommunityLogger("Gehan Homes");
		
	}

	public void innerProcess() throws Exception {
				
		//U.setUpGeckoPath();
		DesiredCapabilities capabilities = DesiredCapabilities.firefox(); 
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("permissions.default.image", 2);
		capabilities.setCapability("firefox_profile", profile);
		//driver = new FirefoxDriver(capabilities);

		//		driver=new FirefoxDriver();
	    U.setUpChromePath();
	    driver = new ChromeDriver();
		String html = U.getHtml("https://www.gehanhomes.com/", driver);
		
		String sec = U.getSectionValue(html, "homeLocationsNav footerNav setActiveNav", "</ul>");
		String regUrl[] = U.getValues(sec, " href=\"", "\"");
		
		for (String region : regUrl) {
			U.log("----------Start region" + region + "---------------");
			//U.log("https://www.gehanhomes.com" + region);
			if (region.contains("estate")){
			     	U.log("+++++++++++++++++++++DUPLICATES"+region);
				//html = U.getHTML(region);
				continue;
				}
			//html = U.getHTML("https://www.gehanhomes.com" + region);
			
			html = U.getHtml("https://www.gehanhomes.com" + region, driver);
				
			
			
			String commLinksSec[] = U.getValues(html, " viewCommunityOnMap \">", "</li>");
			U.log("no. of com url:"+commLinksSec.length);
			
			for (String commSec : commLinksSec) {
				
				String url = U.getSectionValue(commSec, "<a href=\"", "\"");
				
				if (this.data.communityUrlExists("https://www.gehanhomes.com"+url)) {
					duplicates = duplicates + 1;
					U.log("+++++++++++123++++++++++DUPLICATES"+duplicates);
					continue;
				}
				addDetails("https://www.gehanhomes.com" + url, commSec);
				//U.log("com Link: "+link);
				inr++;
			
				i++;
			}
			
			inr = 0;
		}
		Logger.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}
	//TODO : Extact communities detail here
	private void addDetails(String url, String commSec) throws Exception {

//		try{
			
		//Single Run
//		if(!url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/green-meadows/")) return;

		
//		if(k >=81)	
		{
			
//			U.log(commSec);
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/houston/midtown-at-magnolia/")) {
			Logger.AddCommunityUrl("=======Page Not found======"+url);
			return;
		}
		
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/green-oaks-preserve/")) {
			Logger.AddCommunityUrl("======Redirecting to region page======="+url);
			return;
		}
		String geo = "False";
		U.log("\n\n:::::::::community no:::::::::"+k+"::::::::::::::::\n");
		
		/*//check whether the community cache file exist
		isUrlAlreadyExist(url);*/
		
		String html = U.getHtml(url, driver);
		String quik=html;
		
//		Logger.AddCommunityUrl(url);
		
		// Comm Name
		String commName = U.getSectionValue(html, "data-community-name=\"", "\"");
	    
		
		U.log("url::::::::::"+url);
//		U.log("community no ::::::"+k);
		
		U.log("Comm Name:" + commName);
		commName = commName.replace("0?", "0'");
		commName = commName.replace("–", "-").replace("�", "-").replace("?", "-");
		U.log("Comm Name:" + commName);
		
		
		html = html.replaceAll("Now Pre-Selling</h2>|Advantage of Pre-Grand Opening Pricing ", "");
		
		String notes=U.getnote(U.getNoHtml(html).replace("now pre-selling in our new phase", "Now Pre-Selling New Phase")
				.replaceAll("series now pre|(r|R)anch (n|N)ow (p|P)re|(g|G)H (h|N)ow (p|P)re", ""));
		if (html.contains("90123.png")||html.contains("-190416.png")) {
			notes="Now Pre-Selling";//img
		}
		// Address
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		String addressSec=U.getSectionValue(html, "<div class=\"communityAddress\">", "</address>");
//		U.log("addressSec::"+addressSec);
		String street = U.getSectionValue(addressSec, "<span class=\"addressStreet\">", "<");
		U.log("Street::"+street);
		if(street!=null)
		{
			street=street.replace("Too new for online maps. See directions from the Builder.  ,","").replace("No Sales Office ins this location- Please visit The Vineyards., No Sales Office-Call/Text for Appointment!", "");
			street=street.replace("Closed Out!, (No Model Home) ", "").replace("Sales Office Coming Soon-Call/Text By Appointment Only!", "").replace("Call For An Appointment!, (No Model Home) ", "").replace(", (Model Home Closed) ", "").replace("NOW SELLING!, Now Selling from our Castle Point Community! ", "").replace(", (Model Home Temporarily Closed) ", "").replace(", (Call for Showing Instructions) ", "");
			street=street.replaceAll("Litchfield Park\\s*$|\\s*No Sales Office - Call/Text For More Information!\\s*|Currently Selling from The Vineyards Community|MODEL COMING SOON!|Visit Siena Model, |Visit Sunfield Model, |Too new for online maps.  Please see directions from Builder|Too new for online maps.  See Directions from Builder., |Too new for online maps. See Directions from Builder.| Deer Park, TX | Grand Opening! | Open Daily! |Coming Soon! Call for Appointment.|By Appointment Only, Call for Information |Please Call or Text for Appointment! |, (Model Home Closed) |NOW SELLING!, Now Selling from our Castle Point Community! |, (Model Home Temporarily Closed) |, (Call for Showing Instructions) ", "");
			street = street.replaceAll("No Sales Office!, Call/Text For More Information|,  Please Call/Text for Details!|, Please Call/Text to Schedule Appointments!|No Sales Office in this Location, (Please |No Sales Office-)Call/Text for Appointment!|\\s*No Sales Office in this Location Please Call/Text for Appointment!||Now Selling!|NOW SELLING!|Please Call/Text for Appointment!", "")
					.replace("1621 Cedar Crest Drive, 1621 Cedar Crest Drive", "1621 Cedar Crest Drive")
					.replaceAll(", Model Home Coming Soon!", "");
			
			add[0] = street.trim();
			add[1] = U.getSectionValue(addressSec, "<span class=\"addressCity\">", "<").trim();
			add[2] = U.getSectionValue(addressSec, "<span class=\"addressState\">", "<").trim();
			add[3] = U.getSectionValue(addressSec, "<span class=\"addressZipCode\">", "<").trim();
	
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);
			geo="FALSE";
		}
		// Lat Long
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		lat = Util.match(html, "Latitude:</span> (.*?)<", 1);
		lng = Util.match(html, "Longitude:</span> (.*?)<", 1);
		lat = (lat != null) ? lat : ALLOW_BLANK;
		lng = (lng != null) ? lng : ALLOW_BLANK;
		U.log("Lat:" + lat + " Long:" + lng);
		String latlngs[] = { lat, lng };
		
		add[0]=add[0].replaceAll("Too new for online maps.  See Directions from the Builder.|COMING SOON!|Too new for online maps. See Directions from the Builder.", "");
		
		if (add[0] == ALLOW_BLANK) {
			String latLong[]={ lat, lng };
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getGoogleAddressWithKey(latLong);
			if(addr == null) addr = U.getAddressHereApi(latLong);
			
			add[0] = addr[0];
			lat=latLong[0];
			lng=latLong[1];
			
			geo = "TRUE";
		}
		
		// Price
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		String[] price = { ALLOW_BLANK, ALLOW_BLANK };
		
		
		// if (minPrice == ALLOW_BLANK) {
		html = html.replace("&#39;s", ",000").replace("Up To $100,000 in Savings", "").replace("low 200's", "low $200,000").replace("'s", ",000").replace("Schertz starting at $211,990","");
		
		html=html.replaceAll("previousPrice\">\\$\\d{3},\\d{3}", "");
//		U.log(Util.match(html, ".*low 200.*"));
		
		price = U.getPrices(html, "starting in the low \\$\\d{3},\\d{3}|Priced at \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d,\\d{3},\\d{3}|Starting at\\s+\\$\\d+,\\d+|\\$\\d{3},\\d+",
				0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		// }
		// Square Feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html,
				"\\d,\\d{3}–\\d,\\d{3} sq. ft.|<li class=\"area\">\\d{1},\\d{3} - \\d{1},\\d{3} SQ FT</li>|\\d{4} to \\d{4} sq. ft|\\d+,\\d+ - \\d+,\\d+ Square Feet|\\d,\\d+ sq ft|\\d+,\\d+ sq. ft. - \\d+,\\d+ sq. ft.|[0-9]{1},[0-9]{3} sq. ft. Square Feet|[0-9]{1},[0-9]{3} Square Feet|[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3}  Square Feet|\\d,\\d{3}\\+ SQ FT", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		if (commName.contains("LaCima"))
			add[1] = "Prosper";
		if (commName.contains("Valley Ridge"))
			add[1] = "Fort Worth";
		html=html.replaceAll("Luxury and convenience", "").replace("offering you luxury ", "offering you luxury home");
		
		
		//-----Homes details page data for finding property type-------
		String homeDetailsSec[] = U.getValues(html, "<h3 class=\"xCommunityNameHeader\">", "</h3>");
		U.log("Total Home : " + homeDetailsSec.length);		
		String allHomeData =ALLOW_BLANK;
		int k=0;
		if(homeDetailsSec !=null){
			for(String homeDet : homeDetailsSec){
				k++;
				String homeUrl = U.getSectionValue(homeDet, "<a href=\"","\"");
			//	U.log("homeUrl:::::::::"+"https://www.gehanhomes.com"+homeUrl);
				//try {
				String homeHtml = U.getHTML("https://www.gehanhomes.com/"+homeUrl);
				allHomeData = U.getSectionValue(homeHtml, "<div class=\"caption-title\">", "Community Details</h2>")+allHomeData;
				if(k>6)break;
				//}catch(Exception e) {}
			}
		}
		allHomeData =allHomeData.replaceAll("Village|village|VILLAGE", "");
		allHomeData =allHomeData.replaceAll("luxurious", "");
		allHomeData =allHomeData.replaceAll("Villanova|villanova|imagepatio|-patio", "");
		allHomeData = allHomeData.replace("| Loft |", " Loft Homes")
									.replaceAll("<li>\\s*Loft\\s*</li>", " Loft Homes");
		allHomeData = allHomeData.replace("Beauty, luxury, comfort and space", "Beauty, luxury home, comfort and space")
									.replace("traditional in design", "traditional home design");
		
		String propSection = U.getSectionValue(html, "<h2>Community Details</h2>", "community-button-wrap");
		
		
		
		String commType = U.getPropType((allHomeData+propSection+commName).replaceAll("Village|VILLAGE|Villagio |imagepatio|legacytraditional|Traditional School|townhouse", "")
						.replace("walk-in closets and luxury interiors", "walk-in closets and luxury homes"));
		//U.log("reult::"+Util.match(homeHtml, ".*?patio.*?"));
		U.log("prop Type: "+commType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(allHomeData+propSection+commName, "[\\s\\w\\W]{30}coming[\\s\\w\\W]{30}", 0));
		if (commType == ALLOW_BLANK)//
//			commType = "Single Family";
			
		U.log("proptype :" + commType);
		commType=commType.replace(",Townhomes", "");
		// Property Status
		
		String pStatus = ALLOW_BLANK;
		String remData = U.getSectionValue(html, "<header id=\"header\">",
				"id=\"main\"");
		 //U.log(remData);
		// Thread.sleep(1000000);
		String remove=U.getSectionValue(html, "subNavRight", " </ul>");
		if(remove!=null)html=html.replace(remData, "");
		html = html.replaceAll("<span>QUICK MOVE-IN HOMES AVAILABLE|Quick Move-in Homes|QUICK MOVE- IN HOMES|MOVE|Move|move", "");
		html = html.replace("Now Selling in our New Phase", "Now Selling New Phase").replace("\"QUICK MOVE-IN HOMES AVAILABLE", "");
		html=html.replaceAll("The on-site elementary school is now open.|Model Home, NOW OPEN|Photos Coming Soon!|Model Home Coming Soon|Model Home, NOW OPEN,|Coming soon to Midlothian","");

		
		remove = "Katy Lakes Classic is coming soon to|tipCloseout|Only 1 Home site remaining in Katy Trails|Sales Office OPENING SOON|Final Opportunity_Commons|Office COMING SOON|Model Home, NOW OPEN, and NOW|Coming soon to Midlothian|Office Coming Soon|NOW OPEN, and NOW SELLING! Coming soon|Join us as we celebrate the grand opening of our brand new model home|promoTitle\">Grand Opening!</h2>|pricing coming soon|Quick Move-in: up to|quick move-in save up|Wrapper\">Coming Early 2017|Model Home Coming Soon|New Model Now OPEN|We are CLOSED OUT|Sales Office Coming Soon|New Model, Now Open in Castle Point|join us for food, drinks, and prizes at the grand opening|Mason Hills Grand Opening|Coming Soon!|New Model NOW OPEN and NOW SELLING|Home will be Coming Soon|Big on ALL Quick Move-in Homes|Model Coming Soon|MODEL HOME COMING SOON|Forney and is coming soon|Big on ALL Quick Move-in Homes|Training Facility that is coming soon| Under Construction|NEW MODEL NOW OPEN|<p class=\"mt10 updatedMT10\">.*?</p>|The Kingwood Town Center Opening 2015|<span>QUICK MOVE-IN HOMES AVAILABLE|\"QUICK MOVE-IN HOMES AVAILABLE|section of Cypress Trails is now Open|\"Coming Soon";
		String stSec = html.toLowerCase().replaceAll(remove.toLowerCase(), "");
		stSec = stSec.replace(remData, "");
		
		stSec =stSec.replace("homesites coming soon", "Homesites Coming Soon");
		commSec=commSec.replaceAll("model is coming|Sales Office COMING SOON|Office Coming Soon|Sales Office Now Open and Model Home Coming Soon", "");
				
		commSec=commSec.replace(" alt=\"Misty Woods\" ", " alt=\"Misty Woods now Selling\" ");//now selling from reg img
		commSec = commSec.replace("21921561-170325.jpg", "Now Selling");//now selling from reg img
		
		//U.log("result:"+Util.match(commSec, ".*?coming soon.*?"));
		//U.log("12 "+stSec);
		
		stSec=stSec.replace("new section  westwood offers", "New Section Coming Soon! Westwood offers").replace("Now Selling in New Phase", "Now Selling New Phase")
				.replace("now selling in new phase", "now selling new phase ").replaceAll("(school|(P|p)hotos|(T|t)our) (C|c)oming|available now in the beautiful|lots available!", "")
				.replace("limited homesites are selling out quickly", "limited homesites selling out quickly");

		//pStatus=pStatus.replace("Closeout", "Close Out");
//		U.log(stSec);
		commSec=commSec.replace("https://wacdn-img5.secure.footprint.net/media/57730/fo_banner.png?v=636966978940000000", "Final Opportunity");
	//	U.log("MMMMMMMMMM "+Util.matchAll(stSec+commSec, "[\\s\\w\\W]{50}Coming Soon[\\s\\w\\W]{50}",0));
		pStatus = U.getPropStatus(((stSec+commSec).replaceAll("ingDescription\">Final Quick Move-in Opportunities Coming Soon</p>|final quick -in opportunities coming soon", "ingDescription\">final Quick Move-in Opportunities Coming Soon</p>").replace("Only 60' Lots Remaining", "Only 60 Lots Remaining").replaceAll("promotext\">grand opening of new section|limited time only! we are buying|coming soon on the left-hand", "").replace("/fo_banner.png", "Final Opportunity"))
				.replaceAll("num-qmi\">\\d+ Quick Move-in Homes Available</div>|item marketingDescription\">Homes Ready Now!</p>|<h3 class=\"marketheadline\">homes ready now!</h3>|school \\(coming|looking for quick move in homes|Model Townhomes Now Open|model townhomes now open|opening soon: 13-acre |School \\(Coming|qmi\">2 Quick Move-in Homes Available</div>|inventory homes now|pearland are now selling|center coming|bar w ranch go2 now selling|Only 1 Home site remaining in Katy Trails|tipCloseout|new lots coming 2019|New Lots Coming 2019|Quick Move In Homes| Model Home Coming Soon|school coming soon|5 Quick Move-in Homes Ready|Model Coming Soon|new model will be coming soon|Sale+Office+Coming+Soon|Model Home is COMING SOON|Model will be COMING SOON|Model Home Coming Soon|model home is coming soon|Model Home Coming Soon|Model Home is COMING SOON|Model Home is COMING SOON|Model Home Coming Soon|Model Home Coming Soon|Model Home is COMING SOON|Model Home Coming Soon|Model will be COMING SOON", "").replaceAll("Close-out", "Close-Out").replaceAll(" Closeout", "Close-Out"));
		pStatus = pStatus.replace("!", "");
		U.log("Property Status:::: "+pStatus);
		//Status fro  image
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/houston/east-meadow-place/")){
			pStatus = "Now Selling";
		}
		
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/viridian/"))pStatus="Final Opportunities Coming Soon";
//		U.log("MMMMMMMMMM "+Util.matchAll(stSec+commSec, "[\\s\\w\\W]{30}/fo_banner.png[\\s\\w\\W]{30}",0));
		
		
		
		
		
		// Derived Type
		String derivedPType = ALLOW_BLANK;
		String commHtml = U.getHTML(url);
		commHtml=commHtml.replaceAll("personalizationRegisterAnchor", "");
		//U.log(commHtml);
		commHtml = commHtml.replace("single and 2-story", " 1 Story and 2-story")
				.replaceAll("branch|Rancho Siena Elementary|Ranch Parkway and turn right|city of Fair Oaks Ranch| at Fair Oaks Ranch|McKinney Ranch Parkway| Mountain Ranch Marketplace| Ranch Elementary School|Morton Ranch High School|Ranch Rd|Ranch Pflugerville|Windmill Ranch|20Ranch%20|Branch|Ranch High|Ranch Road|Rancho", "");
		derivedPType = U.getdCommType(commHtml);

		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		if (url.contains("https://www.gehanhomes.com/Community.aspx?SiteMarketId=5&BuilderId=16908&MarketId=18&CommunityId=66576"))
			add[0] = "11520 N 156 Lane";
		
		

		if (add[0] == ALLOW_BLANK && lat != null || add[1] == ALLOW_BLANK
				&& lat != null) {
			String a[] = U.getAddressGoogleApi(latlngs);
			if (a == null) {
				a = U.getGoogleAddressWithKey(latlngs);
			}
			if (a == null) {
				a = U.getAddressHereApi(latlngs);
			}
			add[0] = a[0];
			geo = "TRUE";
		}

		if (add[0].length() < 4 && lat.length() > 4) {
			add = U.getAddressGoogleApi(latlngs);
			if(add == null) add = U.getGoogleAddressWithKey(latlngs);
			if(add == null) add = U.getAddressHereApi(latlngs);
			geo ="TRUE";
		}

		// Special Case for address Here...

		add[0] = add[0].replace(", (Sales Trailer)", "")
				.replace(", (Model Coming Soon)", "")
				.replace("Coming Soon!", "").replace("Please Call/Text for More Information!", "")
				.replace("3625 White Wing Lane , Deer Park", "3625 White Wing Lane");
		
		if (add[0].length() < 2) {
			add[0] = ALLOW_BLANK;
		}

		add[1] = add[1].replace(",", "");
		if((add[0]==null||add[0]==ALLOW_BLANK)&&(lat!=null||lat!=ALLOW_BLANK)){
			String[] latlng={lat,lng};
			String[] addr=U.getAddressGoogleApi(latlng);
			if(addr == null) addr = U.getGoogleAddressWithKey(latlng);
			if(addr == null) addr = U.getAddressHereApi(latlng);
			if(addr[2].contains(add[2])||add[2].contains(addr[2])){
				add=addr;
				geo="TRUE";
			}
		}
		
		if(add[1]==ALLOW_BLANK||add[0].equals("By Appointment Only")||add[0].contains("Starting at the")||add[0].contains("Please Call for Appointment")||add[0].contains("Selling From our")||add[0].contains("Closed Out!")||add[0].contains("Model"))
		{
			add=U.getAddressGoogleApi(latlngs);
			if(add == null) add = U.getAddressHereApi(latlngs);
			geo="TRUE";
		}
		
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/austin/flintrock-falls")){
			String ad[]={"Austin","TX","78704"};
			latlngs=U.getlatlongGoogleApi(ad);
			if(latlngs == null) latlngs = U.getGoogleLatLngWithKey(ad);
			if(latlngs == null) latlngs = U.getlatlongHereApi(ad);
			lat=latlngs[0];
			lng=latlngs[1];
			add=U.getAddressGoogleApi(latlngs);
			if(add == null) add = U.getGoogleAddressWithKey(latlngs);
			if(add == null) add = U.getAddressHereApi(latlngs);
		}
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/springfield-commons")){
			add[0]="3309 Rough Creek Drive";
			geo="FALSE";
		}
		commHtml = commHtml.replace("CommunityTypeGated\">Gated", "Gated Community")
				.replaceAll("Heath Golf and Yacht Club", "Heath Golf Course And Yacht Club");
		String Type = U.getCommunityType(commHtml.replaceAll("Nearby Golf Clubs|Nearby Parks and Golf Courses", ""));
		//U.log(commHtml);
		
		U.log("Comm type:: "+Type);
		//==================hardcoded image section from front=============
		
		//=========
		
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/austin/mason-hills")){
			commType = U.getPropType("Luxury Homes "+allHomeData);
		}
		
		
		add[0]=add[0].toLowerCase().replaceAll("Appointment Only!|, |,|homesites model home|Homesites Model Home", "");
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/carillon/")){
			add[0]="836 Lake Carillon Laneby";
		}
		
		pStatus=pStatus.replaceAll("\\d+ Quick Move-in Home", "Quick Move-in Home");
		if(quik.contains("Quick Move-in Homes</h2>")&&!pStatus.contains("Quick Move-in Home"))
		{
			pStatus = pStatus.replace(", Quick Move-in", "");
			if(pStatus.length()>4)
			{
				pStatus=pStatus+", Quick Move-in Home";
			}else
			{
				pStatus="Quick Move-in Home";
			}
		}
		//From image
		if(notes.contains("Now Pre-selling New Phase 3") || notes.contains("Now Pre-selling New Phase"))pStatus=pStatus.replaceAll("Selling New Phase,|, Selling New Phase", "");
//		if(url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/waterbrook/") ||url.contains("https://www.gehanhomes.com/find-your-new-home/houston/newport/")  ||url.contains("/dallas-fort-worth/mercer-crossing/")|| url.contains("wellington-premier-50-lots/") || url.contains("/dallas-fort-worth/fireside-park/"))
//			notes="Now Pre-Selling";
		
//		if(url.contains("https://www.gehanhomes.com/find-your-new-home/austin/homestead/"))
//			notes="Now Pre-Selling New Section";
		//if(url.contains("find-your-new-home/dallas-fort-worth/aspen-meadows/")) {pStatus = "Coming Soon, "+pStatus;}
		
		pStatus=pStatus.replace("Coming Soon, Final Opportunities Coming Soon, Quick Move-in Home", "Final Opportunities Coming Soon, Quick Move-in Home");
		pStatus=pStatus.replace("Quick Move-in, Quick Move-in Home", "Quick Move-in Home").replace("Quick Move In Homes, Quick Move-in Home", "Quick Move-in Home").replace("Quick Move-in Homes", "Quick Move-in Home").replace("Coming Soon Fall 2021, Coming Soon", "Coming Soon Fall 2021").replace("New Phase Coming Soon Fall 2021, New Phase Coming Soon", "New Phase Coming Soon Fall 2021").replace("Coming Summer 2021, New Section Coming Summer 2021", "New Section Coming Summer 2021").replace("Actively Selling","Now Selling").replace("Only Quick Move-in Homes Remain", "Quick Move-in Home");
		pStatus=pStatus.replaceAll("Final Quick Move-in Opportunities Coming Soon, Quick Move-in","Final Opportunity");
		 

		
		int noOfUnit=0;
		String comId=U.getSectionValue(html, "data-community-id=\"", "\"");
		
		
		String noOfUnits=ALLOW_BLANK;
		String siteMapUrl="https://salesarchitect.exsquared.com/api/Lotv2/getbybdxcommunityid/?bdxCommunityId="+comId+"&communityNumber=";
		U.log("SiteMapUrl=: "+siteMapUrl);
		String siteMapHtml=U.getPageSource(siteMapUrl);
		
		if(siteMapHtml!=null&&(!siteMapHtml.contains("Error fetching Lots by Community Id"))) {
			U.log("path"+U.getCache(siteMapUrl));
			String lotDataSec=U.getSectionValue(siteMapHtml, "<d2p1:LotData>", "</d2p1:LotData>");
			String[] lots=U.getValues(lotDataSec, "<d2p1:SiteOverviewLot>","</d2p1:SiteOverviewLot>");
			noOfUnit=lots.length;
		}
		noOfUnits=Integer.toString(noOfUnit);
		  if(noOfUnits.equals("0"))
			  noOfUnits=ALLOW_BLANK;
		  U.log("NO Of Units="+noOfUnits);
		
		  add[0]=add[0].replaceAll("Yale,", "");

		  
		commName = commName.replaceAll("Villas$|In Bourne", "");
		data.addCommunity(commName.replace("�", "-").replace("’", "").replace(" � "," ").replace("�", "'"), url, Type);
		Logger.AddCommunityUrl(url);
		Logger.countOfCommunity(i);
		data.addAddress(U.getCapitalise(add[0].toLowerCase()), add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(commType, derivedPType);
		data.addPropertyStatus(pStatus);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);

		}
k++;

//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
	
	
	public boolean isUrlAlreadyExist(String url){
		String cacheFilePath=ALLOW_BLANK;
		cacheFilePath = U.getCacheFileName(url);
		File f = new File(cacheFilePath);
		if(f.exists()){
		 f.delete();
		 return true;
		 
		}
		return false;


		}

	

}




