/**
 * @author Sawan
 * @date 19/01/2017
 * 
 */
package com.shatam.b_041_060;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.*;
//import org.eclipse.jdt.internal.compiler.lookup.UpdatedMethodBinding;
import java.net.URL;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPlantationHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j = 0;
	static int dupli = 0;
	ArrayList<String> commList = new ArrayList<String>();
	CommunityLogger LOGGER;
	static WebDriver driver = null;
	private String baseUrl = "https://www.plantationhomes.com";
	public static void main(String[] args) throws Exception {
//		U.setUpGeckoPath();
//		
//		Proxy p=new Proxy();
//		p.setHttpProxy("35.238.13.121:3128");
//		DesiredCapabilities cap=new DesiredCapabilities();
//		cap.setCapability(CapabilityType.PROXY, p);
//		driver=new ChromeDriver(cap);
		AbstractScrapper a = new ExtractPlantationHomes();
		a.process();
//		a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"MHI-McGuyer Homebuilders - Plantation Homes.csv", a.data().printAll());
		U.log(dupli);
	}

	public ExtractPlantationHomes() throws Exception {

		super("MHI-McGuyer Homebuilders - Plantation Homes","https://www.plantationhomes.com/");
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Plantation Homes");
	}

	public void innerProcess() throws Exception {
		
		
		String html = U.getHTMLwithProxy(baseUrl);
//		U.log(html);
//		String regionSection = U.getSectionValue(html, "<ul class=\"locationBoxes container\">", "</ul>");
//		U.log(regionSection);
//		String regionUrls[] = U.getValues(regionSection, "href=\"", "\">");
//		for(String regionUrl : regionUrls){
//			findCommunity(baseUrl+regionUrl);
//		}
//		
		findCommunity("https://www.coventryhomes.com/houston");
		
//		driver.quit();
//		LOGGER.DisposeLogger();
	}
	private void findCommunity(String regionUrl)throws Exception{
		U.log("RegionUrl::"+regionUrl);
		String regHtml = U.getHTMLwithProxy(regionUrl.replace(".com//", ".com/"));
//		U.log(regHtml);
//		
//		String seccomList = U.getSectionValue(regHtml, "<div class=\"inventoryContainer whereWeBuild\">","</wherewebuild>");
//		U.log(seccomList);
//		U.log(Util.match(regHtml, ".*rowindex.*"));
		String commSecs[] = U.getValues(regHtml.replaceAll("&q;", "\""), "{\"rowindex\"", "\"}");
		String commsec1="";
		for (String commSec : commSecs) {
//			U.log(commSec);
			String comLink=U.getSectionValue(commSec, "\"ProjectUrl\":\"", "\"");
			if (comLink==null) continue;
			U.log("comLink : "+comLink);
//			if(!comLink.contains("parkside-west"))continue;
			
			if (comLink.endsWith("/communities")) {
				
				
//				U.log("SUBREGION =====================================================================> :" + baseUrl+comLink);
				
				if((baseUrl+comLink).contains("dallas-ft-worth/parkside-west/communities")) {
					commsec1=commSec;
					continue;}
				
				regHtml=U.getHTMLwithProxy((baseUrl+comLink).replace(".com//", ".com/"));
//				String subCommunitySec=U.getSectionValue(regHtml.replaceAll("&q;", "\""), "{\"ProjectId\":", "PriceSeriesSeoUrlName");
				String subCommSecs[]=U.getValues(regHtml.replaceAll("&q;", "\""), "{\"ProjectId\":", "PriceSeriesSeoUrlName");
				for (String subCommSec : subCommSecs) {
//					U.log("::::"+subCommSec);
					comLink=(regionUrl+"/"+U.getSectionValue(subCommSec, "\"CommunitySeoUrlName\":\"", "\"")).replace(".com//", ".com/");
//					U.log("--------------------------------------"+i+"---------------------------------------");
	//				U.log("Sub comLink=====================================================================> "+comLink);
//					try {
						findCommunityDetails(comLink,subCommSec+commSec);
//					} catch (Exception e) {
						// TODO: handle exception
//					}
					
					i++;
//					break;
				}
			}else {
				U.log("--------------------------------------"+i+"---------------------------------------");
				//U.log(comLink);
//				try {
				if (comLink.startsWith("https://")||comLink.startsWith("http://")) {
					findCommunityDetails(comLink.replaceAll("http:", "https:"),commSec);
				}else
					findCommunityDetails(baseUrl+comLink,commSec);
//				} catch (Exception e) {
					// TODO: handle exception
//				}
				
				
				i++;
			}
			
			
//			break;
		}
		
		regHtml=U.getHTMLwithProxy((baseUrl+"/dallas-ft-worth/parkside-west/communities").replace(".com//", ".com/"));
//		String subCommunitySec=U.getSectionValue(regHtml.replaceAll("&q;", "\""), "{\"ProjectId\":", "PriceSeriesSeoUrlName");
		String subCommSecs[]=U.getValues(regHtml.replaceAll("&q;", "\""), "{\"ProjectId\":", "PriceSeriesSeoUrlName");
		for (String subCommSec : subCommSecs) {
//			U.log("::::"+subCommSec);
			
			String comLink=(regionUrl+"/"+U.getSectionValue(subCommSec, "\"CommunitySeoUrlName\":\"", "\"")).replace(".com//", ".com/");
//			U.log("--------------------------------------"+i+"---------------------------------------");
//				U.log("Sub comLink=====================================================================> "+comLink);
//			try {
			if(comLink.contains("dallas-ft-worth/parksidewest")) {
				U.log("gggggg"+comLink);
				findCommunityDetails(comLink,subCommSec+commsec1);
			}
				
//			} catch (Exception e) {
				// TODO: handle exception
//			}
			
			i++;
//			break;
		}
		
		
		U.log(i);
	}
	//TODO : Extract Communities details here
	private void findCommunityDetails(String comLink, String commSec)throws Exception{
//		if(!comLink.contains("parksidewest-50ft-homesites"))return;
//		if(j== 33 )
//		try{
		{
			U.log(j+"==="+comLink);
			if(comLink.contains("https://www.buildonyourlot-texas.com/locations/houston")) return; // redirect to another builder
			if(comLink.contains("https://buildonyourlot.coventryhomes.com/locations/dallas-ft-worth")) return; // redirect to another builder
			if(data.communityUrlExists(comLink.replace(".com//", ".com/"))) {
				LOGGER.AddCommunityUrl(comLink+":::::::::::::::::::::::::::::::repeated");
				return;
			}

			LOGGER.AddCommunityUrl(comLink);
			
		String commHtml=U.getHTMLwithProxy(comLink).replace("&q;", "\"");
//		U.log(commSec);
//		U.log("comSec=====================================================================> "+commSec);
		
		

		
		String commName=U.getSectionValue(commSec.replace("&s;", "'"), "\"SubdivisionName\":\"", "\"");
		String n;
		U.log("ComName::::::::"+commName+"::::::::::::;");
		if(commName == null){
			commName =U.getSectionValue(commSec, "\">", "</a>");
		}
//		U.log(Util.match(commHtml, ".*SubdivisionName.*"));
		if(commName == null){
			commName =U.getSectionValue(commHtml.replace("&a;","").replace("&s;", "'"), "\"SubdivisionName\":\"", "\"");
			
		}
//		U.log("SSSS "+commSec);
		String parentComName= U.getSectionValue(commSec.replace("&a;","").replace("&s;", "'"), "\"ProjectName\":\"", "\",");
		if(parentComName!=null){
			
			parentComName=parentComName.replaceAll("<a id=\"project\">|</a>", "")
					.replaceAll("40'|50'|60'|70'|55'|65'","").replace(" &amp;", "").trim();
//			U.log(parentComName);
			if(!commName.startsWith(parentComName)&&!parentComName.contains("Build On Your Lot Sales Center"))commName=parentComName+" "+commName;
			//commName = commName.replace("null", "");
		}
		U.log("parentComName : "+parentComName+":");
		if(commName.contains("Unit"))
		{
			U.log("====================================================================================================================================0000000009999999999");
			commName="Kinder Ranch"+" "+commName;
		}
		commName=commName.replace("\\t", "").replaceAll(" - Patio Homes|- Gated|- Traditional","").replace("\t", "");
		
		
		
		U.log("comName=========================================================================> "+commName);
//		String mainSec=U.getSectionValue(commHtml, "<div class=\"contentWrapper\">", "</community>");
		
		//----------RemoveNearByCOmmunities--------
//		commHtml = U.removeSectionValue(commHtml, "<h3>Nearby Communities</h3>", "<h3>Promotions");
		
		//---------Newz Section-----------
//		commHtml = U.removeSectionValue(commHtml, "container featuredSliderContainer", "<div _ngcontent-c0=\"\" class=\"social\">");
		
		//-------------------------------------------------Address Latlon Sec---------------------------------
//		String detailAddSec=U.getSectionValue(commHtml, "mapaddress", "</p>");
//	
//		U.log("detailsAddSec====================> "+detailAddSec);
//		
//		
//		
//		if(detailAddSec!=null){
//				
//			latlonSec=U.getSectionValue(detailAddSec, "?q=", "&amp;");
//			 addSec=U.getSectionValue(detailAddSec,"<span class=\"fas fa-map-marker\">", "</a>");
//				
//				if (addSec==null)
//				{
//					addSec=U.getSectionValue(detailAddSec,"<span class=\"fa fa-map-marker\">","</a>");
//
//				}
//				if(latlonSec == null){
//					String googleMapUrl = U.getSectionValue(detailAddSec, "href=\"", "\"");
//					String googleMapHtml = U.getHTML(googleMapUrl);
////					FileUtil.writeAllText("/home/glady/filename_1.txt", googleMapHtml);
//					latlonSec = Util.match(googleMapHtml, "USA/@(\\d{2}\\.\\d{3,},-\\d{2}\\.\\d{3,}),", 1);
//				}
//				
//		}
		String latlon[]= {ALLOW_BLANK,ALLOW_BLANK};
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String note=ALLOW_BLANK;
		String geo="FALSE";
//		if (latlonSec!=null) {
//			latlon=latlonSec.split(",");
//		}
		
	
//		addSec=addSec.replace("Visit our Plantation Homes model:<br>","");
//		addSec=addSec.replace("<span>Please visit us in Sienna Plantation","");
//		if (addSec!=null) {
//			addSec=addSec.replace("Visit our Plantation Homes model:<br>","");
//			addSec=addSec.replace("<span>Please visit us in Sienna Plantation","");
//			addSec =addSec.replace("Visit our sales office in Jordan Ranch:<br>", "");
//			addSec=addSec.replaceAll("</span>|<span>", "").replace("<br>", ",");
//			U.log("addSec" +addSec);
//			add=U.getAddress(addSec);
//			U.log(Arrays.toString(add));
//		}
			add[0]=U.getSectionValue(commHtml, "\"Address\":\"", "\"").replaceAll("Visit the Coventry Homes model at: &l;br&g;|Visit our Coventry&l;br&g; models in Artavia: &l;br&g;15231 Deseo Drive &l;br&g;", "");
			add[1]=U.getSectionValue(commHtml, "\"City\":\"", "\"");
			add[2]=U.getSectionValue(commHtml, "\"State\":\"", "\"");
			add[3]=U.getSectionValue(commHtml, "\"Zip\":\"", "\"");
		U.log("Add ::"+Arrays.toString(add));
		if(add[0] !=null) add[0] = add[0].replace("\\t", "");
		String lat = U.getSectionValue(commHtml, "\"Latitude\":\"", "\"");
		String lng = U.getSectionValue(commHtml, "\"Longitude\":\"", "\"");
		U.log("::::::::::::"+add[0].length());
		U.log("::::::::::::"+lat+","+lng);
		latlon[0]=lat;
		latlon[1]=lng;
		if (add[0]==null||add[0].length()==0) {
			add[0]=ALLOW_BLANK;
		}
		if (add[0]==ALLOW_BLANK&&lat!=null&&lat!=ALLOW_BLANK)
		{
			if(!lng.contains("-"))
				lng="-"+lng;;
			add=U.getGoogleAddressWithKey(latlon);
//				add=U.getBingAddress(lat, lng);
			geo="TRUE";
			U.log("--"+Arrays.toString(add));
		}
//		U.log(add[0]);
		if(lat.length()<4 && add[0].length()>4 ){
			latlon = U.getlatlongGoogleApi(add);
			lat=latlon[0];
			lng=latlon[1];
			geo="TRUE";
		}
//		
		String availhomeSections=U.getSectionValue(commHtml, "\"HomeItems\":[", "]");
		String floorPlanSec=U.getSectionValue(commHtml, "\"Plans\":[", "]");
		//-------------------------------------------------PriceSec---------------------------------

		String price[]= {ALLOW_BLANK,ALLOW_BLANK};
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commHtml=U.removeSectionValue(commHtml, "{&q;G.https://app.mhinc.com/api/","</html>");
		commHtml=U.removeSectionValue(commHtml, "class=\"promoContainer container","</footer>");

		//U.log(commHtml);
		commHtml=U.removeSectionValue(commHtml, "<div class=\"calculatorResults\">","<div class=\"disclaimer\">");
		commHtml=U.removeSectionValue(commHtml, "<label>Mobile Phone</label>","<p><input class=\"button full\" name=\"submit\" value=\"Send\" type=\"submit\"></p>");
		commHtml = commHtml.replaceAll("Up to \\$\\d+,\\d+ in savings on move-in ready homes", "");
		String remSec=U.getSectionValue(commHtml,"<h3>Nearby Communities</h3>", "<div class=\"tabItem mediumWeight\" data-id=\"content_promotions\">");
		//U.log(remSec);
		if (commName.contains("Signature Series")) {
			commSec=commSec.replace("From the $200's |", "$200,000</div>");
		}else if (commName.contains("Executive Series")) {
			commSec=commSec.replace("$250's</div>", "$250,000</div>");
		}
		if(remSec!=null)
			commHtml=commHtml.replace(remSec,"");
		//mainSec=mainSec.replace("From the $380's", "From the $380,000");
		commHtml=commHtml.replace("0's","0,000").replace("$1.05 Million","$1,050,000 Million").replaceAll(" value=\"\\$\\d{3},\\d{3} \\+\">\\$\\d{3},\\d{3} \\+</option>|value=\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</option>|<span class=\"strikethrough\">\\$\\d{3},\\d{3}</span>", "");
		//U.log(commHtml);
//		U.log(availhomeSections);
		String headerPrice = Util.match(commHtml, "PriceRangeCalc\":\"(\\d+)\"",1);
		if(headerPrice != null && headerPrice.length()==3)
			headerPrice = "PriceRangeCalc\":"+headerPrice+",000";
		price=U.getPrices(commSec+availhomeSections+floorPlanSec+headerPrice,
				"\\$\\d{3},\\d{3}\\s+</div>|mid \\d{3},\\d{3}|PriceRangeCalc\":\\d{3},\\d{3}|SuggestedPrice\":\"\\d{6,7}\"|\"BasePrice\":\"\\d{6,7}\"|\\$\\d{3},\\d{3}</div>|<div class=\"price\"> \\$\\d{3},\\d{3}</div>|\\$\\d{1},\\d{3},\\d{3} Million|From \\$\\d{1},\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		if(comLink.contains("https://www.plantationhomes.com/dallas-ft-worth/pecansquare-60ft-homesites"))
			minPrice = "$300,000";
		
		
		
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		//-----------------------------------------------Sqft-----------------------------------------
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(commSec+availhomeSections+floorPlanSec,
				"\"SqFt\":\"\\d{4}\"|\\d{4} to \\d{4} sq. ft.|\\d{4} to \\d{4} Sq.Ft.|\\s+\\d{4} sqft\\s+", 0);
		
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("Min Sq :" + minSqf + " Max Sq :" + maxSqf);
		
		
		//---------------------------------------com type---------------------------------
		commHtml=commHtml.replaceAll("top-ranked master-planned communities throughout Texas|The Augusta Pines Golf Club and Willow Creek Golf Club are nearby|master plan also calls|major master plans|Northlake Community|country club|Country Club|pools including a gated toddler pool|Fair Oaks Ranch Golf and Country Club| office in Jordan Ranch", "");
		String Type = U.getCommunityType(commHtml.replace(" Golf Center", " golf, "));
		
		U.log(Type);
		
		//------------Derived Type-----------------

		String dPropType = U.getdCommType((commHtml+commSec).replaceAll("marinecreekranchphase|Marine Creek Ranch|marinecreekranch&q|Marine Creek Ranch&l|one-story Avery design", "")) ;
		U.log(dPropType);
		
		
		//--------------------property type----------	
		//U.log(commSec);
		//commSec.replace("<div class=\"movein\">","");
		String proptype;
		
	
commSec = commSec.replaceAll("Viridian Executive Series|VIRIDIAN EXECUTIVE SERIES", "");
commHtml=commHtml.replaceAll("VIRIDIAN EXECUTIVE SERIES| Executive Officer|Executive Series From the |he custom home during|the custom home price|Estimated dues|content=\"New homes for sale|<title>New Homes for Sale|content=\"The new homes for sale|Homeowner Services</a></span>|homeowners association fees|feedback of every homeowner|Chinese \\(Traditional","");
		//U.log(commHtml);


		String hoaAmt = Util.match(commHtml, "HOAAnnualAmt\":\"(\\d+)",1);
		String hoaType = "";
		if(hoaAmt != null  && Integer.parseInt(hoaAmt.trim()) > 0)
			hoaType = " Homeowners Association";
		
		commHtml = commHtml.replace("luxurious one-story", "luxury homes");
		
		proptype = U.getPropType(commHtml+commSec+hoaType);
		commHtml=commHtml.replace("Now Selling in Final Section", "Now Selling Final Section");
		//---------------------prop status----------------
		String propStatus = ALLOW_BLANK;
		
		String firsTag = U.getSectionValue(commHtml, "DescriptionShort", "!");

		String[] r = U.getValues(commHtml, "DescriptionShort", "!");
		for(String rr : r) {
		commHtml = commHtml.replace(rr, "");
		}
		commSec=commSec.replace("Close-Out Specials!","Close-Out");
		commSec=commSec.replace("now Selling Functional","Now Selling")
				.replaceAll("nShort\":\"New Floor Plans Available|ionShort\":\"New Lots Available|Ready Homes Now Available|New Community Coming Soon", "");
		commHtml=commHtml.replace("q;Final Opportunities", "").replace("&q;New Available Lots", "").replace("q;Now Selling Phase", "").replace("community&s;s Grand Opening event", "").replace("&q;New Floor Plans Available", "").replace("&q;Coming September", "").replace("&q;Now Selling Phase 4!&q;", "")
				.replaceAll("Elementary, now open|Coming 2021! The Grove|\"New Section Now Open|Move-In Ready Homes Now Available|Available!\",\"Latitude\":|is now selling in more than 20 Houston-area developments|The Backyard \\(coming soon\\)|:&q;Move-In Ready Homes|:\"Move-In Ready Homes|last-chance-to-build|Last Chance to Build|receive Grand Opening|nShort\":\"New Floor Plans Available|nShort\":\"New Lots Available|Backyard Coming Fall 2019|tionShort\":\"Now Selling Final Sectio|ionShort\":\"Coming Soon!\"|nShort\":\"New Floor Plans Available|new home designs available from Plantation|DescriptionShort\":\"Coming September 2019|about the new homes available|New Model Now Open\\!| Elementary, now open,|Explore the new homes available from Plantation|now available in the popular|under construction or ready for move-in|before the community's Grand Opening|in savings on move-in ready homes|New Community Coming Soon!|receive Grand Opening and |Coming Soon Contact|Grand Opening Event|Grand Opening and Sales|Coming Soon Contact|is now open in the Prosper community|Edgestone at Legacy Now Open|Home Now Open in Star Trail|Coming May 2018!|<div class=\"movein\">|\"bannerHeadline\">Move-In Ready Homes Available!|\"movein\"><span>|now open!|new homes available in Pomona|new homes available in the prestigious|new homes available in Grand Mesa at Crystal|grand opening of its newest Aus...|oversized lots available|Backyard (- )?Coming Spring|Additionally, coming","");
		
//		U.log("MMM "+Util.matchAll(commSec+commHtml, "[\\s\\w\\W]{30}final[\\s\\w\\W]{30}", 0));

		propStatus=U.getPropStatus(commSec+firsTag+commHtml.replace("Ii","i").replaceAll("\" Coming|&q; Coming|&q;Coming|New Lots Available in Coppell|q;Final Opportunities|Limited Opportunities|New Homesites Available", ""));

		U.log("propStatus== "+propStatus);
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(commHtml+commSec+firsTag, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
//		if(commHtml.contains("JobNumber")) {
//			
//			if(propStatus.contains("Quick")) {
//				propStatus = propStatus.replace("Quick Move-in Homes", "Move-in Ready Homes");
//			}
//			else if(propStatus.length()>2 && !propStatus.contains("Ready Now")&& !propStatus.contains("Move"))
//					propStatus = propStatus + ", Homes Ready Now";
//			else if(propStatus.length()<2)
//					propStatus = "Homes Ready Now";
//					
//		}
		
		if(propStatus.contains("Quick")) {
			propStatus = propStatus.replace("Quick Move-in Homes", "Move-in Ready Homes");
		}
		
		if(comLink.contains("https://www.plantationhomes.com/dallas-ft-worth/wildridge-60"))
			propStatus = propStatus.replace("New Phase Now Open,", "");
		
		
		if(comLink.contains("https://www.plantationhomes.com//houston/villasatkingsharbor"))commName="Villas At King Harbor";
		if(comLink.contains("https://www.plantationhomes.com//dallas-ft-worth/churchtract"))commName="Parkside East Homesites";
//		if(comLink.contains("https://www.plantationhomes.com/dallas-ft-worth/seventeenlakes-60ft-homesites")) propStatus = propStatus+", Phase 4 Now Open";
		
		
		
		note=U.getnote(firsTag+commHtml.replaceAll("Plantation Homes Starts Presales In|homes-starts-presales-in-tomball| Presales are slated ", "").replace("content=\"The new homes for sale|", ""));
		if(comLink.contains("firethorne")) {
			add[1]="Katy";
			add[2]="TX";
			add[3]="77494";
			latlon=U.getlatlongGoogleApi(add);
			if(latlon == null)
				latlon = U.getlatlongGoogleApi(add);
			lat=latlon[0];
			lng=latlon[1];
			String add1[] = U.getAddressGoogleApi(latlon);
			if(add1 == null)
				add1 = U.getAddressGoogleApi(latlon);
			add[0] = add1[0];
			//add[0]=U.getAddressGoogleApi(latlon)[0];
			geo="TRUE";
			note="Address take from City,State & Zip";
		}
		
		
		//====================new code===================
		String ccName=comLink.replace("https://www.plantationhomes.com/", "");
		String[] realComName=ccName.split("/");
		ccName=realComName[1];
		ccName=ccName.replace("-", " ");
		//ccName=ccName.replace("pecansquare", "Pecan square").replace("marinecreekranchphase2", "MARINE CREEK RANCH 50' HOMESITES").replace("southpointe", "South pointe").replace("thevinyards", "The vinyards").replace("unionpark", "Union park").replace("trinityfalls", "Trinity falls").replace("townelake", "Towne lake").replace("kleinorchard", "Klein orchard").replace("grovelanding", "Grove landing").replace("jordanranch", "Jordan ranch").replace("summerlakes ", "Summer lakes").replace("harvestgreen", "Harvest green").replace("grandmission", "GRAND MISSION ESTATES").replace("grandmissionestates", "GRAND MISSION ESTATES").replace("hiddenlakes", "Hidden lakes").replace("avalonterrace Pla", "AVALON TERRACE").replace("villasatkingsharbor", "KINGS HARBOR VILLAS AT KINGS HARBOR").replace("imperialoakspark themeadows", "THE MEADOWS AT IMPERIAL OAKS").replaceAll("harperspreserve section\\d 55", " HARPER'S PRESERVE 55' HOMESITES").replace("dominionofpleasantvalley", " DOMINION OF PLEASANT VALLEY").replace("seventeenlakes", "seventeen lakes").replace("northwestparkcolony", "northwest park colony").replace("parksidewest", "parkside west");
		
		if(comLink.contains("https://www.plantationhomes.com/houston/grandmissionestates-40ft-homesites"))
			ccName="Grand Mission Estates 40ft Homesites";
		
		if(comLink.contains("https://www.plantationhomes.com/houston/grandmission-60ft-homesites")) note = "Now Pre-Selling Final Section";

		commName = commName.replace("avalon terrace tvalon terrace", "avalon terrace").replace("aliana aliana", "Aliana").replace("harvest green harvest green", "Harvest Green").replace("veranda veranda", "Veranda").replace("firethorne firethorne west 50'", "Firethorne West 50'").replace("jordan ranch jordan ranch", "Jordan Ranch").replace("dellrose dellrose", "Dellrose").replace("grove landing grove landing", "Grove Landing").replace("klein orchard klein orchard", "Klein Orchard").replace("northwest park colony northwest park colony", "Northwest Park Colony").replace("towne lake towne lake", "Towne Lake Towne Lake").replace("viridian viridian chalet series", "Viridian Chalet Series").replace("auburn hills auburn hills", "Auburn Hills").replace("somerset somerset", "Somerset").replaceAll("trinity falls trinity falls ", "Trinity Falls ").replace("union park union park", "Union Park")
				.replace("dominion of pleasant valley dominion of pleasant valley 50's", "Dominion Of Pleasant Valley 50's").replace("the vineyards the vineyards", "The Vineyards").replace("pecan square pecan square", "Pecan Square").replace("trailwood trailwood", "Trailwood");
		
		if (availhomeSections.contains("Ready Now")) {
			if (propStatus.length()>2&& !propStatus.contains("Move-in Ready")) {
				propStatus+=", Move-in Ready Homes";
			}else if (!propStatus.contains("Move-in Ready")) {
				propStatus="Move-in Ready Homes";
			}
			
		}
		
		if(comLink.contains("aliana-plantation-homes-windsor-62ft-homesites"))note = "Now Pre-Selling Final Section";
		if(comLink.contains("meridiana-40ft-homesites"))commName = "Meridiana 40'";
		if(comLink.contains("meridiana-60ft-homesites"))commName = "Meridiana 60'";
		
		//=========================================================================================
		data.addCommunity(commName.replace("\"", ""), comLink.replace("com//", "com/"), Type);
		data.addAddress(add[0],add[1],add[2],add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(proptype, dPropType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		}
		j++;
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
		
	
	private static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;
		
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					Thread.sleep(15000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
//			driver.quit();
			return html;

		}

		// else{
		// return null;
		// }
	}

}

