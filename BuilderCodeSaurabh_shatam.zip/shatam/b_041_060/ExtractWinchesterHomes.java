/** 
 */
/*

package com.shatam.b_010_019;

import java.util.ArrayList;

import bsh.util.Util;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;

public class ExtractWinchesterHomes extends AbstractScrapper {

public static void main(String[] ar) throws Exception {

	AbstractScrapper a = new ExtractWinchesterHomes();
	a.process();
	a.data().printAll();
	FileUtil.writeAllText("/home/shatam3/cache/Weyerhaeuser - Winchester Homes.csv", a.data().printAll());
	
}

public ExtractWinchesterHomes() throws Exception {

	super("Weyerhaeuser - Winchester Homes", "http://www.winchesterhomes.com");
}

public void innerProcess() throws Exception {
	String lat=ALLOW_BLANK;
	String lng=ALLOW_BLANK;
	String html = U
			.getHTML("http://www.winchesterhomes.com/communities-styles/community-locations");
	//U.log(html);
	String[] communityRows = U
			.getValues(
					html,
					"<div class='view-content view-content-communities-map'><table>",
					"<tr class=", "</tr>");
	
	String communitySec=U.getSectionValue(html, "<div class=\"brand-communities\">", "<div class=\"community-table\">");
	String [] communityRows=U.getValues(communitySec, "<td class=\"col-right\">", "<li class=\"type\">");
	for (String communityRow : communityRows) {
		String comSec=U.getSectionValue(communityRow,"<div class=\"title\">","</div>");
		String nameUrl = U.getSectionValue(comSec, "<a href=\"",
				"</a>");
		
		U.log("communityUrl::::::::;;"+nameUrl);
if(nameUrl.contains("class=\"active"))continue;
		String communityUrl = "http://www.winchesterhomes.com"
				+ nameUrl.substring(0, nameUrl.indexOf("\""));
		
		

		String communityName = nameUrl.substring(nameUrl.indexOf(">") + 1);
		String cn=communityName;
		U.log(communityName);
		if (communityName.contains(",")) {
			communityName = communityName.substring(0,
					communityName.indexOf(","));

		}
		if (communityName.contains("- Sold Out!")) {
			communityName = communityName.substring(0,
					communityName.indexOf("- Sold Out!"));
			
		}
		if(communityName.contains("-"))
			communityName=communityName.split("-")[0];
		communityName=communityName.replace("|", "");
		
		
		String propertyType = U.getSectionValue(communityRow,
				"<td class=\"view-field view-field-term-node-5-name\">",
				"</td>");
		if (propertyType.contains(",")) {
			propertyType = propertyType.substring(0,
					propertyType.indexOf(","));
		}
		String comUrl=U.getSectionValue(communityRow,"<a href=\"","\"");
		//U.log(communityUrl);
		
		if(communityUrl.contains("http://www.winchesterhomes.com/community/glenmere-brambleton-0"))continue;
		U.log(communityUrl);
           String comHtml=U.getHTML(communityUrl);
           
		String propertyType =U.getPropType(comHtml);		//U.log(communityUrl);
		
		U.log(propertyType);
		String html1 = null;
		try{
		 html1 = U.getHTML(communityUrl);
		}catch(java.io.FileNotFoundException ex){
			U.log("Unable to Load");
			continue;
		}
		
		String propertyStatus = ALLOW_BLANK;
		String sectionStatus = cn+U.getSectionValue(html1, "<div class=\"feature-top\">", "id=\"community-detail-buttons\">");
		propertyStatus=U.getPropStatus(sectionStatus);
		U.log(propertyStatus);
	//	propertyType=U.getCommType(html1);
		String minPrice = U.getSectionValue(communityRow,
				"<td class=\"view-field view-field-node-created\">",
				"</td>");
		
		String lat = U.getSectionValue(communityRow,
				"<td class=\"view-field view-field-location-latitude\">",
				"</td>");
		String lng = U.getSectionValue(communityRow,
				"<td class=\"view-field view-field-location-longitude\">",
				"</td>");
         
         if(lat.contains("0.000000")){
         	lat=ALLOW_BLANK;
         			lng=ALLOW_BLANK;}
         String	 minPrice = ALLOW_BLANK; String maxPrice = ALLOW_BLANK;
  		// String secScript = U.getSectionValue(html1, "var home_styles = new Array();", "</script>");
  		 
  		// if(secScript!=null){
  			 ///secPrice =secScript +secPrice ;
  			  //U.log("length"+secScript.length());
         //U.log(comHtml);
         String pricesec=U.getSectionValue(comHtml, "<div class=\"pane-content\">", "<div class=\"sidebar\">");
  		String[] price = U.getPrices(pricesec,"\\$\\d+,\\d+", 0);
  		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
  		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
  		U.log("minprice="+minPrice);
  		U.log("maxprice="+maxPrice);
  		// }
		
		 finding address 
		
		String address=ALLOW_BLANK, city=ALLOW_BLANK,state=ALLOW_BLANK,zip=ALLOW_BLANK, street=ALLOW_BLANK;
		String completeAddress = U.getSectionValue(html1,
				"class=\"address\">", "</div>");
		if(completeAddress!=null){
		 address = U.getSectionValue(completeAddress, "<br/>",
				"<br/>");
			address  = completeAddress.substring(
				completeAddress.lastIndexOf("<br/>") + 5,
				completeAddress.lastIndexOf(","));
			String []cityStreet=address.trim().split("<br />");
			 street=cityStreet[0];
			city=cityStreet[1].trim();
		 state = completeAddress.substring(
				completeAddress.lastIndexOf(",") + 1).trim();
		String[] sz = state.split(" ");
		state = sz[0];
		 zip = sz[1];
		 if(address.length()<5)
			 address=ALLOW_BLANK;
		 
		}
		U.log("address="+address);
		U.log("street="+street);
		U.log("city="+city);
		U.log("state="+state);
		U.log("zip="+zip);
		
		
		if(lat==ALLOW_BLANK){
			
			
			String[] addr = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
					ALLOW_BLANK };
			addr[0]=street;
			addr[1]=city;
			addr[2]=state;
			addr[3]=zip;
			//if(latitude.length()==1)
			//{
			
				String latLong[]=null;
				if (addr[0] != ALLOW_BLANK && addr[3] != ALLOW_BLANK)
				{	latLong = U.getGlatlng(addr);
				lat= (latLong[0] != null) ? latLong[0] : ALLOW_BLANK;
				lng = (latLong[1] != null) ? latLong[1] : ALLOW_BLANK;
				U.log("lat :" + lat + " longi :" + lng);
				}
				//latitude=ALLOW_BLANK;
				//longitude=ALLOW_BLANK;
				U.log("lat :" + lat + " longi :" + lng);
			//}
	//	}
		 finding area 
		// Square Feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html1,
				"\"\\d{1},\\d+|\"\\d{4}",0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		if(minSqf==ALLOW_BLANK){
	    sqft = U.getSqareFeet(html1,
				"Square Footage.\\s*<[^>]+>(\\d{4})", 1);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	
		}
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		
		
		
         if(address.contains("Coming Soon"))
         {
         	address=ALLOW_BLANK;
         }
         
         String derivedPType = ALLOW_BLANK;
		derivedPType = U.getdCommType(html1);
		
		if(derivedPType==ALLOW_BLANK)
			derivedPType=U.getdCommType(html1);
		if(derivedPType==ALLOW_BLANK)
			derivedPType="Single Family Residence";
		

		if(minPrice==ALLOW_BLANK){
			String minP=com.shatam.utils.Util.match(html1, "\\$\\d+,\\d+");
			if(minP!=null)
				minPrice=minP.trim();
		}
		
		//Notes info variable
        String noteVar=ALLOW_BLANK;
        
        
        if(communityUrl.contains("http://www.winchesterhomes.com/communities-styles/community/reserve-timber-lake")){
        	//38.876289,-77.346260
        	lat="38.876289";
        	lng="-77.346260";
        }
        
        if(communityUrl.contains("http://www.winchesterhomes.com/communities-styles/community/forest-park-founders-bridge") ||
        		communityUrl.contains("http://www.winchesterhomes.com/communities-styles/community/glenmere-brambleton")){
        	lat=lng=ALLOW_BLANK;
        }
        if(communityUrl.contains("http://www.winchesterhomes.com/communities-styles/community/west-park-at-brambleton")){
        	minSqf="3430";
        	maxSqf="4157";
        }
        
		String communityType = U.getCommunityType(html1);
		data.addCommunity(communityName, communityUrl,communityType);
		data.addAddress(street, city, state, zip);

		if(lat==ALLOW_BLANK)
			data.addLatitudeLongitude(lat, lng,ALLOW_BLANK);
		else
		data.addLatitudeLongitude(lat, lng,"false");

		data.addPropertyType(propertyType,derivedPType);
		data.addPropertyStatus(propertyStatus);

		data.addPrice(minPrice, maxPrice);

		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(noteVar);
	}
}

}
 */

package com.shatam.b_041_060;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;

//import org.openqa.selenium.internal.seleniumemulation.GetHtmlSource;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWinchesterHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractWinchesterHomes();
		a.process();
		FileUtil.writeAllText("c:/cache/Weyerhaeuser - Winchester Homes.csv", a
				.data().printAll());
	}

	public ExtractWinchesterHomes() throws Exception {

		super("Weyerhaeuser - Winchester Homes",
				"http://www.yourhomeyourway.com/");
	}

	public void innerProcess() throws Exception {
		String url = "http://www.winchesterhomes.com/winchester?qt-brand_winchester=1%23qt-brand_winchester/";
		
		String base = "http://www.firsttexashomes.com/";
		U.log("Done");
		String html = U.getHTML(base);
		String section = U.getHtmlSection(html,
				"<div id=\"searchBtns\">",
				"</div>");
		// U.log(section);
		String[] valus = U.getValues(section, "href=\"",
				"\"");
		int totalComm = valus.length / 2;
		// addDetails("http://www.camberleyhomes.com//communities-styles/community/poplar-run-centennial");
		for (String itom : valus) {
			 U.log(base+itom);
			/*String commurlSec = U.getSectionValue(itom, "<a", "/a>");
			String commUrl = base
					+ U.getSectionValue(commurlSec, " href=\"", "\"");
			String comName = U.getSectionValue(commurlSec, ">", "<");*/
			// if(i<2)
			 String commUrl = base+itom;
			String comHtml = U.getHTML(commUrl);

			if (comHtml.contains("<section class=\"region-content clearfix\">")) {
				String subcomm[] = U.getValues(comHtml,
						"<div class=\"title\">", "<div class=\"brands\">");
				for (String sec : subcomm) 
				{
					String subcomUrl = base
							+ U.getSectionValue(sec, "<a href=\"", "\"");
					String subComName = U.getSectionValue(sec, "<a href=\"",
							"/a>");
					subComName = U.getSectionValue(subComName, ">", "<");

					addDetails(subcomUrl, subComName, sec);
				}

			} else {

				// if(inr==0||inr==totalComm||inr==totalComm+1||inr==valus.length-1)

				//addDetails(commUrl, comName, itom);
			}
			inr++;
			i++;
			// addDetails("http://www.camberleyhomes.com//communities-styles/community/reserve-waples-mill");
		}
		//
		// String
		// comUrl="http://www.yourhomeyourway.com/community/cabin-branch-community";
		// String
		// html1=U.getHTML("http://www.yourhomeyourway.com/community/cabin-branch-community");
		// String sec[]=U.getValues(html1, "", "");

	}

	private void addDetails(String url, String name, String commInfo)
			throws Exception {

		String base = "http://www.yourhomeyourway.com/";

		String html;
		U.log("URL==" + url);
		html = U.getHTML(url);

		U.log("url==" + url);
		String section = U.getHtmlSection(html,
				"id=\"community-summary-wrapper\">",
				" id=\"rightcolumnwrapper\">");

		String tempurl = url;
		String comm[] = tempurl.split("/");

		String commName = name;
         if(commName.contains("At")){
        	 commName=commName.substring(0, commName.toLowerCase().indexOf("At"));
         }
		commName=commName.replace("&#039;s", " ");
		String addSec = U.getSectionValue(commInfo,
				"<div class=\"address-1\">", "<ul class=");
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK }, street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK, latitude = ALLOW_BLANK, longitude = ALLOW_BLANK;
		;
		if (addSec == null) {
			addSec = U.getSectionValue(html, "<div class=\"address\">",
					"</div>");
			U.log(addSec);
			addSec = addSec.replace("<br />", ",");
			U.log(addSec);
			String kk[] = addSec.split(",");
			street = kk[0];
			city = kk[1];
			state = kk[2].replaceAll("\\d+", "");
			zip = Util.match(kk[2], "\\d+");
			String latlong[] = U.getGooleLatLong(add);
			U.log("hi=" + latlong[0]);
			latitude = latlong[0];
			longitude = latlong[1];

		} else {
			street = U.getSectionValue(addSec, "item\">", "<");
			String[] citystateZip = U
					.getSectionValue(
							addSec,
							"<div class=\"city-state-zip\"><div class=\"form-item form-type-item\">",
							"<").split(",");
			U.log(citystateZip[0]);

			city = citystateZip[0];
			state = citystateZip[1];
			zip = citystateZip[2];
			add[0] = street;
			add[1] = city;
			add[2] = state;
			add[3] = zip;

			U.log("hi=" + add[0]);
			String latlong[] = U.getGooleLatLong(add);
			U.log("hi=" + latlong[0]);
			latitude = latlong[0];
			longitude = latlong[1];
		}
		/*
		 * section = U .getHtmlSection(html,
		 * "<script type=\"text/javascript\">var home_styles", "</script>");
		 * String valus[] = U.getValues(section, "new home_style(\"",
		 * "\"/home-style-elevations?");
		 */

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;

		String secScript = U.getSectionValue(html,
				"var home_styles = new Array();", "</script>");
		html = html.replace("Save Up to $100,000", "");

		// /secPrice =secScript +secPrice ;
		// U.log("length"+secScript.length());
		String[] price = U.getPrices(secScript + commInfo + html,
				"\\$\\d{3,},\\d+|\\$\\d,\\d+,\\d+| From  \\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		// U.log("hi="+maxPrice);
		// 4,126-5,004
		// <span id="square_footage0">4,006-4,803 sq.ft.
		// Square Footage: <span id="square_footage2">5,995</span>
		// Square Footage: <span id="square_footage2">4157</span>
		html = html.replaceAll("square_footage(\\d+)", "square_footageR");
		String sec = U
				.getSectionValue(html, "<td class=\"col-right\">",
						"<div class=\"views-field views-field-field-sb-community-amenities-txt\">");
		String viewdetail[] = U
				.getValues(
						html,
						"<div class=\"views-field views-field-view-node\"><span class=\"field-content\"><a href=\"",
						"\"");
		String viewhtml = ALLOW_BLANK;
		if (!url.contains("http://www.yourhomeyourway.com//community/hallman-grove")) {
			for (String vd : viewdetail) {
				U.log("vd=" + vd);

				viewhtml += U.getHTML("http://www.yourhomeyourway.com" + vd);
			}
		}
		// http://www.yourhomeyourway.com/homestyle/paxton-0
		String[] SqFt = U.getSqareFeet(html + viewhtml, "\\d+,\\d+ sq ft", 0);
		U.log("hi=" + maxPrice);
		// String[] SqFt = U.getSqareFeet(html,
		// "\\d,\\d+\\s*-\\s*(\\d,\\d+) sq|id=\"square_footage.\">(\\d,\\d+)|id=\"square_footage.\">(\\d{4})",
		// 0);
		minSq = (SqFt[0] == null) ? ALLOW_BLANK : SqFt[0];
		maxSq = (SqFt[1] == null) ? ALLOW_BLANK : SqFt[1];

		
		U.log("minSq :" + minSq + " maxSq:" + maxSq);
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		// squarefeet
		String propertyType = ALLOW_BLANK;
		propertyType = U.getCommType(html);
		// Property Status
		String pStatus = ALLOW_BLANK;
		/*
		 * String secP = U.getSectionValue(html, "<h1>",
		 * "<div class=\"detail-buttons\"");
		 */
		pStatus = U.getPropStatus(html);

		propertyType = U.getPropType(html);
		if (propertyType == ALLOW_BLANK) {
			propertyType = "Single Family";
		}

		String communityType = ALLOW_BLANK;
		communityType = U.getCommunityType(html);
		if (latitude.contains("0.000000")) {
			String latv[] = U.getBingLatLong(new String[] { street, city,
					state, zip });
			latitude = latv[0];
			longitude = latv[1];
		}
		commName = commName.replace("Selling", "").replace("Now", "")
				.replace("selling", "").replace("now", "");
		if (url.contains("poplar")) {
			if (!commName.toLowerCase().contains("poplar")) {
				commName = "Poplar " + commName;
			} else {
				commName = commName + " Village";
			}
		}
		String geo = "True";
		/*
		 * if(url.contains(
		 * "http://www.yourhomeyourway.com//community/glenmere-brambleton")){
		 * latitude=longitude=geo=ALLOW_BLANK; }
		 */
		pStatus=pStatus.replaceAll("Information Center now open|Cabin Branch Clubhouse \\(Coming Soon| Move-in Ready Homes|move-in ready homes", "");
		if(latitude.contains("37.06"))
		{
			String adds[]={street,city,state,zip};
		String latlngs[]=U.getlatlongGoogleApi(adds);	
		latitude=latlngs[0];
		longitude=latlngs[1];
		}
		if (this.data().communityUrlExists(url))
			return;
		data.addCommunity(commName, url, communityType);
		data.addAddress(street, city.trim(), state.trim(), zip.trim());
		data.addSquareFeet(minSq, maxSq);
		data.addPrice(minPrice, maxPrice);
		 data.addLatitudeLongitude(latitude, longitude, geo);
		data.addPropertyType(propertyType, ALLOW_BLANK);
		data.addPropertyStatus(pStatus);
		data.addNotes(ALLOW_BLANK);
	}

}

// Your code here
