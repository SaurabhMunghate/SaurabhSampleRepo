package com.shatam.b_061_080;

import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class AmericanLegendHomes extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static String Builder_name = "American Legend Homes";
	static String HOME_URL = "https://www.amlegendhomes.com";
	CommunityLogger LOGGER;
	static int j=0;
	WebDriver driver=null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new AmericanLegendHomes();
		//U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"American Legend Homes.csv", a.data()
				.printAll());
	}

	public AmericanLegendHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER=new CommunityLogger(Builder_name);
	}

	
	public void innerProcess() throws Exception {
		//System.setProperty("webdriver.chrome.driver",	"/home/mypremserver/Downloads/chromedriver");
		/*System.setProperty("webdriver.chrome.driver",	"/home/glady/chromedriver");
		if (driver == null)
		 driver = new ChromeDriver();*/
		
		/*
		 * U.setUpChromePath(); driver = new ChromeDriver();
		 * driver.manage().window().maximize();
		 */
		//String html = U.getHTML("https://www.amlegendhomes.com/communities/colorado"); 
		String html = U.getHTML("https://www.amlegendhomes.com/communities/texas")+U.getHTML("https://www.amlegendhomes.com/communities/colorado");

		String sec[] = U.getValues(html,"<div class=\"mx-3 my-2 css-1v51qao\"","</span></div></div></div></div></div></div>");
		U.log("sec.length :- "+sec.length);
		
		for (String sec1 : sec) {
			String url =  U.getSectionValue(sec1, "<a class=\"\" href=\"", "\"");
			
			if(!url.contains("http")){
				url = HOME_URL+U.getSectionValue(sec1, "<a class=\"\" href=\"", "\"");
				U.log(url);
			}
			adDetails(url, sec1);
//			break;
		}
		//driver.close();
		//try{driver.quit();}catch(Exception e){};
		LOGGER.DisposeLogger();
	}

	public void adDetails(String url, String comsec) throws Exception {
		//TODO :
//		if(j >= 12)
		{

		U.log(j+"::::"+url);

//	if(!url.contains("https://www.amlegendhomes.com/communities/colorado/windsor/raindance"))return;
	
	 U.log(comsec);
		String html = U.getHTML(url);
			/*
			 * if(html.contains("Load More Plans</span>")) {
			 * System.err.println("LOAD BUTTON Not CLICKEd"); //
			 * U.deleteFile(U.getCache(url)); html=null; html=getHtml(url, driver); }
			 */
		
		U.log("Count: "+j);
		String detailsSec=U.getSectionValue(html, "class=\"CommunityDetails_content\"", "<div class=\"CommunityDetails_btnWrapper\"")+U.getSectionValue(html, "div class=\"css-1ybt9lw MapView_wrapper\"", ">Read More</button>")
		+U.getSectionValue(html, "div class=\"css-1ybt9lw MapView_wrapper\"", ">Show Less</button>");
		U.log(U.getCache(url));
		if(url.contains("http://www.belclairehomes.com")){
			LOGGER.AddCommunityUrl(url+"::::::::::::::Redirecting to belclairehomes");
			addBelclaireDetails(url,comsec);
			return;
		}
		
		if(data.communityUrlExists(url))
			{
			LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
			return;
			
			}
		LOGGER.AddCommunityUrl(url);
		comsec=comsec.replaceAll(" data-reactid=\"\\d+\"", "");
		U.log("comsec:: "+comsec);
		
		html = U.removeSectionValue(html, "window.__PRELOADED_STATE__", "</script>");
		html = U.removeSectionValue(html, "<head>", "</head>");
		
		//============================================Community name=======================================================================
				String communityName=U.getNoHtml(U.getSectionValue(comsec, "<div class=\"CommunityCard_title p-3\">","</a")).replaceAll(" - Townhomes", "").replace("The Villas","");
				communityName=communityName.replace("The Grove Frisco", "The Grove");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				String addSec=U.getSectionValue(html, "Sales Center Locations</h4>","<a href=\"tel:");
				U.log("addSec =="+addSec);
				
				if(addSec != null){
					
					String rem = U.getSectionValue(addSec, "Hours: </b><", "<");
				if(rem!=null)
					addSec  = addSec.replace(rem, "");
					addSec=addSec.replaceAll("<span role=\"button\" tabindex=\"0\" class=\"false\" data-reactid=\"\\d+\">(All|Lakeside|Parkside)</span>| - By Appointment Only|<span role=\"button\" tabindex=\"0\" class=\"false\" data-reactid=\"\\d+\">\\d+</span>|Mon-Sat 10AM-7PM; Sun 12PM-7PM|Hours:&nbsp;|By Appointment Only|Model Coming Soon|Model|Models Under Construction|Model Under Construction|Closed","").replace("&amp;","&");
					String address = U.getNoHtml(addSec).replace("Street McKinney", "Street, McKinney").replace(" Street Berthoud", " Street, Berthoud").replace("Drive Loveland", "Drive, Loveland").replace("Court Windsor", "Court, Windsor").replace("Ridge Oak Point", "Ridge, Oak Point").replace("lvd. Little Elm", "lvd., Little Elm").replace(" Wembley The Colony", " Wembley, The Colony").replace("Road Irving", "Road, Irving").replace("Avenue Celina", "Avenue, Celina").replace("Way McKinney", "Way, McKinney").replace(" Lewisville", ", Lewisville").replace(" Lace Lane Northlake", " Lace Lane, Northlake").replace(" Fort Worth", ", Fort Worth").replace(" Prosper", ", Prosper").replace(" Frisco", ", Frisco")
							.replace(" Winnipeg Court Aurora", " Winnipeg Court, Aurora")
							.replace("Parkway Timnath", "Parkway, Timnath")
							.replaceAll("No Opportunities Currently Available\\s*-", "").replaceAll("Hours:  |Mon-Tues, |Fri-Sat \\d+AM-\\d+PM; Sun \\d+PM-\\d+PM|Monday - Saturday \\d+AM - \\d+PM; Sunday Noon - \\d+PM", "")
							.replaceAll("(Mon|Wed)-Sat 1\\d(A|P)M-\\dPM; Sun 1\\dPM-\\dPM", "");
					U.log(address);
					add = U.getAddress(address.replace(",,", ","));
					
					U.log("Add ::"+Arrays.toString(add));
				}
				add[0]=add[0].replaceAll("Sold Out - Has Closed|Model Under Construction|Under Construction|Coming Soon!?|coming soon!|model coming soon","");
				U.log("address:--->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				String latlngSec=U.getSectionValue(html, "www.google.com/maps/place/", "/@");
				U.log("latlngSec::"+latlngSec);
				if(latlngSec!=null){
					latlag = latlngSec.split(",");
				}
				U.log("lat::"+latlag[0]+" lng::"+latlag[1]);
				if(latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getGoogleLatLngWithKey(add);
					geo="TRUE";
				}
				if(add[0].length()<4)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					geo="TRUE";
				}
				if(url.contains("http://www.amlegendhomes.com/neighborhoods/texas/prosper/lilyana"))add[0]="4408 Sunflower Lane";
		//==============================================home data=============================================================================
				String floorplandata =U.getSectionValue(html, "<h3 class=\"CommunityPlans_title d-none d-lg-flex flex-column Underdog_center\"", "</a></div></div></div>");
				String availhomedata =U.getSectionValue(html, "<div class=\"CommunityHomes_list\"", "</a></div></div></div></div>");
				String allHomes[] = U.getValues(html, "<a class=\"HomeCard_imageWrapper\"", "alt=\"Arrow Right Icon\"");
				String allPlans[] =	U.getValues(html, "<a class=\"PlanCard_imageWrapper\"", "alt=\"Arrow Right Icon\"");
				String allHomeData =ALLOW_BLANK;
				int i=0;
//				String hoQhtml="";
				for(String home:allHomes) {
					if((i++)==6)break;
					String hurl =  U.getSectionValue(home, "href=\"", "\"");
					U.log(i+" https://www.amlegendhomes.com"+hurl);
					String homeData=U.getHTML("https://www.amlegendhomes.com"+hurl);
//					hoQhtml+=homeData;
					if(homeData != null)
						allHomeData += U.getSectionValue(homeData, "<div class=\"HomeDetails_content\"", "<div class=\"ContactModal_wrapper")+U.getSectionValue(homeData, "<div class=\"AccordionToggle_content\"", "<div class=\"AccordionToggle_content\"");
				}
				i=0;
				for(String plan:allPlans) {
					if((i++)==6)break;
					String purl =  U.getSectionValue(plan, "href=\"", "\"");
					U.log(i+" https://www.amlegendhomes.com"+purl);
					String homeData=U.getHTML("https://www.amlegendhomes.com"+purl);
//					allHomeData += U.getHTML("https://www.amlegendhomes.com"+purl);
					if(homeData != null)
						allHomeData += U.getSectionValue(homeData, "<div class=\"HomeDetails_content\"", "<div class=\"ContactModal_wrapper")+U.getSectionValue(homeData, "<div class=\"AccordionToggle_content\"", "<div class=\"AccordionToggle_content\"");
				}
		//		U.log(allHomeData);
		//============================================Price and SQ.FT======================================================================
				
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				html=html.replaceAll("\\$80,000 TO OVER \\$100,000","");
				detailsSec=detailsSec.replaceAll("0s|0's|0'S|0S","0,000")
						.replaceAll("Drive\" li=\"\\$846|Lane\" li=\"\\$680", "")
						.replaceAll("<favorite sref=\"(.*?)>", "");
				comsec=comsec.replaceAll("0s|0's|0'S|0S","0,000");
//				U.log(Util.match(availhomedata, ".*367,640.*"));
//				U.log(availhomedata);
				String prices[] = U.getPrices((detailsSec+comsec+floorplandata+availhomedata+html).replace("CommunityCard_sqft\">From the $720,000</span><span class=\"CommunityC", ""),
						"\\$\\d,\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</b></span>|>\\$\\d{3},\\d{3}</span>|low \\$\\d{3},\\d{3} with|>\\$\\d{3},\\d{3}</strong>|>\\$\\d{3},\\d{3}</b>|From the high \\$\\d{3},\\d{3}|From the low \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|ng-scope\">\\$\\d{3},\\d{3}|ng-scope\">Priced From \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}", 0); //\\$\\d,\\d+,\\d+ |mid $(\\d,)?\\d{3},\\d{3}
				
			//	U.log(Util.match((detailsSec+comsec+floorplandata+availhomedata), "[\\s\\w\\W]{20}\\$500,000[\\s\\w\\W]{100}"));
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Min Price: "+minPrice+"\tMaxPrice: "+maxPrice);
				//U.log(Util.match((detailsSec+comsec+floorplandata+availhomedata), "[\\s\\w\\W]{30}720,000[\\s\\w\\W]{30}"));
		//======================================================Sq.ft===========================================================================================		
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				html=html.replace("4,000-square-foot community center","").replace("–", "-")
						.replaceAll("range from 1,800 to over 3,300 square feet","from 1,800 square feet - 3,300 square feet");
				//Baths</b></li>.*?(\\d,\\d+).*?Sqft</b>
				
//				U.log(Util.match((detailsSec+comsec+floorplandata+availhomedata), "[\\s\\w\\W]{30}from 2,500 to[\\s\\w\\W]{30}"));
				
				String[] sqft = U.getSqareFeet((html +detailsSec+comsec+floorplandata+availhomedata).replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->| data-reactid=\"\\d+\"", "").replace("–", "-"),
								"From \\d,\\d{3} Sqft|From \\d,\\d{3} Sqft|from \\d,\\d{3} to \\d,\\d{3} square feet|from \\d,\\d{3} square feet - \\d,\\d{3} square feet|range from \\d,\\d{3} to over \\d,\\d{3} square feet|from \\d,\\d{3} � \\d,\\d{3} square feet|range from \\d,\\d{3} to\n\\s*\\d,\\d{3} square feet|from \\d,\\d{3} to over \\d,\\d{3} square|from \\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d+-\\d,\\d+\\+ square feet|from \\d+,\\d+ - \\d+,\\d+\\+ square feet|from \\d,\\d+ to over \\d,\\d+ square feet| ranging from \\d,\\d{3} to \\d,\\d{3}-plus square feet|anging from \\d,\\d{3} - \\d,\\d{3} square feet|From \\d,\\d{3} Sqft<|\">\\d,\\d{3} <b>Sqft</b>|ranging from \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} plus square feet|\\d,\\d{3} to more than \\d,\\d{3}|Ranging from \\d,\\d{3} – \\d,\\d{3}|\\d,\\d{3} to \\d{1},\\d{3}- plus square feet|range from \\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d+ to \\d,\\d+-plus square feet |\\d+ - \\d,\\d+ sq ft|\\d,\\d+ to \\d,\\d+(\\+)* square|\\d,\\d{3} to \\d,\\d{3} plus square feet|\\d,\\d+ - \\d,\\d+ sq ft|\\d,\\d+ sq ft|\\d,\\d{3} square feet|binding\">\\d,\\d{3}</span>",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				
				U.log("Min Sqft: "+minSqft+"\t Max Sqft: "+maxSqft);
				//U.log("MATCH--- "+Util.match(html, "[\\s\\w\\W]{30}range from 1,800[\\s\\w\\W]{30}"));
		//========================remove section===========================
				String rem="price_status\":\"Sold Out\"|<div class=\"price ng-binding\">Sold Out</div>|banner sold-out ng-binding ng-scope\" ng-switch-when=\"Sold Out\">Sold Out</div>|Opportunities Now Available|Information Coming Soon|Elongated Toilet|MODELS OPENING SOON|<a href=\"/coming-soon/|Pricing To Be Determined\">Coming Soon<|<div class=\"price ng-binding\">Temporarily Sold|banner temporarily-sold-out ng-binding ng-scope\" ng-switch-when=\"Temporarily Sold Out\">Temporarily Sold Out</div>|price_status\":\"Temporarily Sold|Temporarily Sold Out\" class=\"banner temporarily-sold-out|\"/coming-soon/| pricing-to-be-determined\">Coming Soon</div>|'coming-soon'|lower-content\">\\s+Coming Soon|ng-switch-default=\"\">Coming Soon</div>";
				html=html.replaceAll(rem, "");
				html=U.removeComments(html);
			
		//================================================community type========================================================
				html = html.replace("Top Golf,", "Top Golf Course").replace("Hilltop at Inspiration 55+", "Hilltop at Inspiration 55+ community");
				
				String communityType=U.getCommType((detailsSec+communityName).replace(" Hilltop at Inspiration 55+", "55+ Community").replace("resort-inspired community", "resort community"));
				//communityType=communityType.replace(",55+ Community", "");
		//==========================================================Property Type================================================
//				detailsSec = detailsSec.replaceAll("American Legend Homes introduces the latest in low-maintenance luxury living –luxury townhomes located in Castle Hills", "");
				detailsSec = detailsSec.replaceAll("Patio w/ Deck<|Patio</label>|shapartments|apartments.png", "");
				detailsSec=detailsSec.replace("\"single family","");
	
				
				String propType=U.getPropType((detailsSec+allHomeData).replaceAll("custom designed fireplace", ""));
				
				if(url.contains("https://www.amlegendhomes.com/communities/texas/oak-point/wildridge"))propType="Single Family";
		//==================================================D-Property Type======================================================
				html = html.replaceAll("floor|Floor", "").replace("<span ng-bind=\"(plan.stories|number)\" class=\"ng-binding\">1.5</span>", "1.5 story");
				html=html.replace("<span ng-bind=\"(plan.stories|number)\" class=\"ng-binding\">1</span>", "1 Stories").replace("<span ng-bind=\"(plan.stories|number)\" class=\"ng-binding\">2</span>", "</span>2 Story</span>");

//				U.writeMyText(allHomeData+availhomedata+floorplandata);
				
				String description = U.getSectionValue(html, "data-reactid=\"171\"", "</span></p></div></div><button");
				//U.log(description);
//				
				String dType=U.getdCommType((description+detailsSec+allHomeData+availhomedata+floorplandata).replaceAll("story \\d{4} square|branch|ranch-|Lowbranch|lowbranch|Lovely ranch|<!-- react-text: \\d+ -->|<!-- /react-text -->| data-reactid=\"\\d+\"", "")
						.replaceAll("Stuber Ranch Elementary |3 bedroom|Stubber Ranch Elementary|story 4|Long Branch Way|watters-branch-at-craig-ranch|lowbranch|Watters Branch at Craig Ranch|Windsong Ranch|windsong-ranch|long-branch-way-little-elm-tx|Branch Independent School District|Ranchview High School|ranchview-high-school","").replace(">1.5 <b>Stories</b>", ">1.5 Stories</b>").replace(">1 <b>Stories</b>", ">1 Stories</b>").replace(">2 <b>Stories</b>", ">2 Stories</b>")
						.replace("several one and two story plans","1 story, 2 story"));
				U.log("dType: "+dType);
				U.log(">>>>>>>>>>>"+Util.match((description+detailsSec+allHomeData+availhomedata+floorplandata), "[\\w\\s\\W]{300}several one and two story plans[\\w\\s\\W]{300}", 0));
				
				U.log(communityName);


				if(communityName.contains("Ranch") && !dType.contains("Ranch")) {
					if (dType.length()>2) {
						dType=dType+", Ranch";
					}else {
						dType="Ranch";
					}
				}
		//==============================================Property Status=========================================================
				detailsSec = detailsSec.replace("Oversized and greenbelt home sites are also available", "Oversized and greenbelt home sites available");
				
				//U.writeMyText(html);
				html = html.replaceAll("- Coming Soon|>Coming Soon|to open summer of 2017|our Quick Move-In Homes|American Legend Homes 76-foot lots are coming Spring 2018 in Windsong Ranch in Prosper! ", "");
//				U.log(comsec);
				detailsSec=detailsSec.replace("react-text: 114 -->Coming Soon! Aurora, CO 80016<!-- /react", "");
				comsec = comsec.replace("New Phase Coming Fall of 2021", "New Phase Coming Fall 2021");
				String pStatus="";
				pStatus=U.getPropStatus((detailsSec+comsec.replace("CommunityCard_headline\">Sold Out!</span>", "").replace("New Phase Coming in 2022", "New Phase Coming 2022").replace("Coming Spring of 2019", "Coming Spring 2019")).replace("We will be selling our next phase in Fall of 2021.", "New Phase Coming Fall 2021")
						.replaceAll("limited availability in this community| Coming soon is a wonderful amenity|has a new phase coming soon!| amenity opening soon|, and move-in ready homes for sale", ""));
				
				U.log("pStatus: "+pStatus);
				//U.log(">>>>>>>>>>>>>>>>"+Util.matchAll((detailsSec+comsec), "[\\w\\s\\W]{30}Coming 2022[\\w\\s\\W]{30}",0));

				
				if(allHomes.length>0&&!pStatus.contains("Quick")) {
					for (String home : allHomes) {
						if(!home.contains("SOLD")) 
						{
							if (pStatus.length()>2) {
								pStatus+=", Quick Move In Homes";
							}else {
								pStatus="Quick Move In Homes";
							}
							break;
						}
					}
				}
				if(url.contains("https://www.amlegendhomes.com/communities/texas/prosper/parkside")) {
					add[0]="";
					add=U.getAddressGoogleApi(latlag);
					geo="TRUE";
					pStatus+=", Quick Move In Homes";
				}
//				if(url.contains("https://www.amlegendhomes.com/communities/colorado/aurora/hilltop-55-at-inspiration"))maxPrice="$795,548";
//				if(url.contains("https://www.amlegendhomes.com/communities/texas/fort-worth/wellington")) {
//					minPrice="$418,565";
//					maxPrice="$462,165";
//				}
				if(url.contains("https://www.amlegendhomes.com/communities/texas/lewisville/castle-hills-northpointe-townhomes"))dType=dType.replace(", 1 Story","" );
		
				if(url.contains("https://www.amlegendhomes.com/communities/texas/prosper/parkside"))pStatus=pStatus.replace(", Quick Move In Homes", "");
				
				//============================================note====================================================================
				if(url.contains("https://www.summerhillhomes.com/coming-soon/tanglewood"))pStatus=ALLOW_BLANK;
				if(url.contains("https://www.amlegendhomes.com/neighborhoods/texas/lewisville/castle-hills-northpointe"))propType = propType + ", Loft";
				String note=U.getnote(detailsSec);
				communityName=communityName.replaceAll("- The Villas","");
				
				add[0] = add[0].replaceAll("Mon-Sun 12PM-5PM \\(Tours \\) |� No Opportunities Currently Available \\-*|Hours:\\s*Mon-Sat\\s*\\d+AM-\\d+PM;\\s*Sun\\s*\\d+PM-\\d+PM|Hours:�\\(\\)|Hours:|\\s* ()\\s| \\- ", "").trim();
				add[0]=add[0].replaceAll("�\\(\\)|�No Opportunities Currently Available-\\(\\)|�No Opportunities Currently AvailableMon-Sun 12PM-5PM \\(Tours \\)|�No Opportunities Currently Available\\s?|�\\-|\\(\\)|No Opportunities Currently Available\\s*|Mon-Sun 12PM-5PM\\s*\\(Tours\\)", ""); 
				add[0]=add[0].replace("�9725", "9725").replace("�4113", "4113").replace("�3900", "3900").replace("�3733", "3733").replace("�13607", "13607").replace("�5104", "5104").replace("�1605", "1605").replace("�9704", "9704").replace("�534", "534").replace("�2128", "2128").replace("�4456", "4456");
				
				if(url.contains("colorado/timnath/kitchel-lake-at-serratoga-falls")) {
				add[0]=add[0].replace("Pkwy", "Parkway");
//				geo="FALSE";
				//dType+=", 3 Story";
				}
				U.log("add>>>"+add[0]);
				if(pStatus.contains("Coming Soon, Coming Soon, New Phase Coming 2022"))pStatus=pStatus.replace("Coming Soon, Coming Soon, ", "");
//				if(url.equals("https://www.amlegendhomes.com/communities/colorado/aurora/hilltop-55-at-inspiration"))communityType+=", 55+ Community";
					data.addCommunity(communityName,url.replace("http:", "https:"), communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].replace("Sugar HillsFestival", "").trim(), add[1], add[2], add[3]);
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(propType, dType);
					data.addPropertyStatus(pStatus);
					data.addNotes(note);
				    data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				    data.addUnitCount(ALLOW_BLANK);
		}
		j++;
	}
	
	public void addBelclaireDetails(String url,String comsec) throws Exception {
//		if(!url.contains("castle-hills-northpointe-80s"))return;
		String comurl=url;
		
		if(data.communityUrlExists(url))
		{
		LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
		return;
		
		}
		LOGGER.AddCommunityUrl(url);
	
		String communityHtml = U.getHTML(comurl);
//		---comm name---
		String comName = U.getSectionValue(communityHtml," <div class=\"comm_header_row01_left\"><h1>", "<");
		U.log(comName);
//		-----address-----
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addressec = U.getSectionValue(communityHtml, "<div class=\"comm_header_row02_col01\">", "<span>PH");
		add= U.findAddress(addressec);
		U.log(Arrays.toString(add));
//		---latlng---
		String latsec= U.getSectionValue(communityHtml, "<li><a target=\"_blank\" href=\"http://maps.google.com/maps?q=", "\"");
		latlag = latsec.replace("+", "").split(",");
		U.log(Arrays.toString(latlag));
//		---homedata & floorplans---
		String allavailableHomedata="";
		String allfloorpalndata="";
//		String availurl = url+"-available-homes";
		//String floorurl = url+"-floor-plans";
		String floorplandata =U.getSectionValue(communityHtml, "<h3 class=\"CommunityPlans_title d-none d-lg-flex flex-column Underdog_center\"", "</a></div></div></div>");
		String availhomedata =U.getSectionValue(communityHtml, "<div class=\"CommunityHomes_list\"", "</a></div></div></div></div>");
		String allHomes[] = U.getValues(communityHtml, "<a class=\"HomeCard_imageWrapper\"", "alt=\"Arrow Right Icon\"");
		String allPlans[] =	U.getValues(communityHtml, "<a class=\"PlanCard_imageWrapper\"", "alt=\"Arrow Right Icon\"");
		for(String home:allHomes) {
			String hurl =  U.getSectionValue(home, "href=\"", "\"");
			allavailableHomedata += U.getHTML("http://www.belclairehomes.com"+hurl);
		}
		for(String plan:allPlans) {
			String purl =  U.getSectionValue(plan, "<h4><a href=\"", "\"");
			allfloorpalndata += U.getHTML("http://www.belclairehomes.com"+purl);
		}
//		--price--
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		communityHtml = communityHtml.replace("0s", "0,000").replace("0's", "0,000");
		String prices[] = U.getPrices(availhomedata+floorplandata+communityHtml+comsec,">Priced From \\d+</h4>|From the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{4}|the \\$\\d{3},\\d{3}|<h4> \\$\\d{3},\\d{3} </h4>",0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
//		---sqft--
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(communityHtml+floorplandata+allavailableHomedata+comsec,
						"from \\d,\\d+ to \\d,\\d+-plus square feet|\\d,\\d{3} - \\d,\\d{3} square feet|SQ FT:</span> \\d,\\d{3}</h5>",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
	//-----commtype----
		String communityType=U.getCommType(communityHtml);
    //=====proptype===
		communityHtml = communityHtml.replaceAll("(b|B)ranch|Ranchview High", "");
		String propType=U.getPropType(communityHtml+allavailableHomedata+allfloorpalndata);
	//--dtype--
		String dType=U.getdCommType(communityHtml+allavailableHomedata+allfloorpalndata);
	//status=======.
		communityHtml=communityHtml.replaceAll("Castle Hills Northpointe - Coming Soon!</a>|water amenity opening soon.|Selling!</a>", "");
		comsec = comsec.replace("New Phase Coming Fall of 2021", "New Phase Coming Fall 2021");
		String pStatus =U.getPropStatus((communityHtml+comsec));

		data.addCommunity(comName,comurl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("Sugar HillsFestival", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(U.getnote(communityHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);

	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {
					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					/*
					 * driver.manage() .addCookie( new
					 * Cookie("visid_incap_612201",
					 * "gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"
					 * ));
					 */
					driver.get(url);
					// Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); // y value '400' can
					// be
					/*

					 */
					////*[@id="header"]/div[2]/div[9]/div[2]/div[3]/div/div/div[2]/div[2]/span[2]
					try {
						WebElement moreBtn = driver
								.findElement(By
										.xpath("/html/body/div[1]/div/div/div/div[2]/div[9]/div[2]/div[3]/div/div/div[2]/div[2]/span[2]")); // click
																							// more
																							// button
																							// ---Bay
																							// Area
																							// region
						moreBtn.click();
						U.log("click success");
//						Thread.sleep(1000);
//						moreBtn.click();
//						U.log("click success");
//						Thread.sleep(1000);
//						moreBtn.click();
//						U.log("click success");
//						Thread.sleep(1000);

						Thread.sleep(15000);
					} catch (Exception e) {
						 U.log(e.toString());
						U.log("click unsuccess");
						Thread.sleep(15000);
					}
					////*[@id="header"]/div[2]/div[8]/div[2]/div[3]/div/div/div[2]/div[2]/span[2]
					try {
						WebElement moreBtn = driver
								.findElement(By
										.xpath("//*[@id=\"header\"]/div[2]/div[9]/div[2]/div[3]/div/div/div[2]/div[2]/span[2]")); 
						moreBtn.click();
						U.log("click success");
					} catch (Exception e) {
						 U.log(e.toString());
						U.log("click unsuccess");
					}
					Thread.sleep(15000);

					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}

	}
}