/**@Modificattion Aditya. 
	Parag Humane
 * Date:30/11/2013
 * 
 */
package com.shatam.b_061_080;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtaractDanRyanBuilders extends AbstractScrapper {
	int i = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtaractDanRyanBuilders();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Dan Ryan Builders.csv", a.data()
				.printAll());
	}

	public ExtaractDanRyanBuilders() throws Exception {

		super("Dan Ryan Builders", "https://www.danryanbuilders.com");
		LOGGER = new CommunityLogger("Dan Ryan Builders");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://www.danryanbuilders.com/communities/");

//		String section =U.getSectionValue(html, "regionDrop dropDownLevel2Style", "<nav id=");	
//		//U.log(section);
//		if(section!=null){
//			String[] regionSections = U.getValues(section, "<ul>", "</ul>");
//			//U.log("Total region::::::::::"+regionSections.length);
//			for(String regSec : regionSections){
//				//Sub region
//				String[] subRegUrls = U.getValues(regSec, "<a class=\"thirdLevelAnchor\" href=\"", "\"");
//				//U.log("total sub region::::::::::::"+subRegUrls.length);
//				for(String subRegUrl : subRegUrls){
//					U.log("subRegUrl::::::::::::"+"https://www.danryanbuilders.com"+subRegUrl);
//					String subRegHtml =U.getHTML("https://www.danryanbuilders.com"+subRegUrl);
//					String[] comSections= U.getValues(subRegHtml, "hproduct marketPage communityDataInformation mapFeatureItem  bdxApiLogEventInformation", "See on Map");
//					U.log("Total com ::::"+comSections.length);
//					for(String cSec : comSections){
//						String cUrl ="https://www.danryanbuilders.com"+U.getSectionValue(cSec, "<a href=\"", "\"");
//						//U.log(cUrl);
//						addDetails(cUrl ,cSec);
//						
//					}
//				}
//				
//			}
//			
//		}
		String comSec[] = U.getValues(html, "<li class=\"hproduct marketPage communityDataInformation", "SEE DETAILS");
		U.log(comSec.length);
		for(String sec: comSec) {
			String url = "https://www.danryanbuilders.com"+U.getSectionValue(sec, " <a href=\"", "\"");
//			U.log("url===="+url);
//			try {
				addDetails(url, sec);
//			} catch (Exception e) {}
			
		};
		LOGGER.DisposeLogger();

	}

	private void addDetails(String url ,String comSec) throws Exception {
		// +-
//		 U.log("\nPAGE:" + url);
//       if (!url.contains("https://www.danryanbuilders.com/communities/chesterfield-single-family-homes/")) return; 
        	
//try
//		if(j>=70)
  //   {
		{
			if(url.contains("https://www.danryanbuilders.com/communities/weaver-s-pond/") || url.contains("https://www.danryanbuilders.com/communities/woodlief/")) {
				LOGGER.AddCommunityUrl(url+"==========repeated============");
				return;
				
			}
			if(data.communityUrlExists(url) ){
				LOGGER.AddCommunityUrl(url+"==========Redirected============");
				return;
				
			}
			if(url.contains("/north-carolina/charlotte-metro/masons-bend/") ||url.contains("/north-carolina/charlotte-metro/paddlers-cove/") || url.contains("/north-carolina/charlotte-metro/paddlers-cove-townhomes/")){
				LOGGER.AddCommunityUrl(url+"========== Return ============");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			
			U.log(j+"\nPAGE:" + url);
			//U.log(comSec);
			comSec=comSec.replace("closeout.png", " Closeout ");
			
			//U.log("comSec : "+comSec);
			
			
			
			String html = U.getHTML(url);
			U.log(U.getCache(url));	
			
			html = html.replaceAll("<!--[^-]+-->", "").replace("New Phase of Townhomes Now Open", "new phase Now Open").replace("new phase that is now open", "new phase Now Open");
			//.replace("new phase that is now open", "new phase now open")
//			U.log(comSec);
			String Psec=U.getSectionValue(html, "<div class=\"item description address\">","<div id=\"gallery\">");
		//	U.log("PRice Sec"+Psec);
			html=html.replace("In fact, we have already sold out of one of our home plans, Buy Now Don’t Miss Out!.", "");
			U.log("Mzsatach"+Util.match(html,"1,577,901"));
			
			
					
			// community name
			String commuName = U.getSectionValue(comSec,
					"data-community-name=\"", "\"");
			commuName =commuName.replace("/the", "/The");
			
			commuName = commuName.toLowerCase();
			commuName = commuName.replaceAll("–|-", "");
			commuName =commuName.replace("townhomes", "").replaceAll("cottages$", "").replace(" iii", " III").replace("???", "-").replace(" ll", " II").replace("’", "'");
//			U.log("ComName :" + commuName);
			if(commuName.endsWith("single family homes"))commuName=commuName.replaceAll(" - single family homes|single family homes", "");
			if(commuName.endsWith("single family"))commuName=commuName.replaceAll("-\\s*single family|single family", "");
			if(commuName.endsWith("townhomes"))commuName=commuName.replaceAll(" villas and townhomes|-townhomes| - townhomes", "");
			//if(commuName.endsWith("townhomes"))commuName=commuName.replace(" - townhomes", "");
			commuName = commuName.replace(" 55+ active adult homes", "");
			U.log("ComName :" + commuName);
			
			
			
			String activeAdultHtml = U.getHTML("https://www.danryanbuilders.com/active-adult-living/");
			String[] adultCommunitySections = U.getValues(activeAdultHtml, "class=\"callout standardTextCallout", "View Community</a>");
			
			for(String sec : adultCommunitySections){
				if(sec.contains(url.replace("https://", ""))){
					html = html + " ACTIVE ADULT LIVING " + sec;
				}
			}

			// Address
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK,
					ALLOW_BLANK, ALLOW_BLANK };

			add[0] = U.getSectionValue(html, "<span class=\"addressStreet\">",
					"<");
			if (add[0] == null || add[0].contains("Carriage Run"))
				add[0] = ALLOW_BLANK;
			add[1] = U.getSectionValue(html, "<span class=\"addressCity\">",
					"<").trim();
			add[2] = U.getSectionValue(html, "<span class=\"addressState\">",
					"<").trim();
			add[3] = U.getSectionValue(html, "<span class=\"addressZipCode\">",
					"<").trim();
			add[0] = add[0]
					.replaceAll(", McDonough, Georgia| Selling from the Market Square Model Home at 2820 Shearwater Lane|Gum Spring Kiln Terrace| For GPS use: Walkersville Community Park|\\(GPS Address\\)|selling off site from sheridan estates |call now for more information on this coming soon community and to join our customer vip list!,|See Driving Directions.|Mill Run Model Home/ GPS |Lanham, MD 20706 |TBD ",
							"").replace("???", "").replace("&#39;", "'").replace("Clover", "").replace("&amp;", "&").replace( "(across From Flint Wood Farms)", "");
			
			
			
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]
					+ " Z:" + add[3]);

			
			// Lat Long
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geoCode = ALLOW_BLANK;
			lat = U.getSectionValue(html, " data-center-latitude=\"", "\"").trim();
			lng = U.getSectionValue(html, "data-center-longitude=\"", "\"").trim();
//			U.log("Lat:" + lat + " Long:" + lng);
			if (lat != ALLOW_BLANK)
				geoCode = "False";
			U.log("Lat:" + lat + " Long:" + lng);
			String[] latlng1= {lat,lng};
			
			
			
			if(add[0].length()<4) {
//				U.log(">>>>>>>>>>>");
				 add[0]=U.getAddressGoogleApi(latlng1)[0];
				 geoCode="True";
			}
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]
					+ " Z:" + add[3]);
			
			
			// Price
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String priceSec = U.getSectionValue(html, "communityDescription",
					"</p>");
			if(priceSec != null)
				priceSec = priceSec.replaceAll("0's|0s|0’s", "0,000");
			
			comSec = comSec.replaceAll("0's|0s|0’s", "0,000");
			U.log(Util.matchAll(html+priceSec+comSec,"[\\w\\s\\W]{30}\\$20[\\w\\s\\W]{30}",0));
			
			html = html.replace("$300's<br>500 White Oak Rd", "").replace("0's", "0,000");
			html = html.replace("0s", "0,000");
			html = html.replace("0&#39;s", "0,000");
//			U.log("Mzsatach"+Util.match(Psec,".*\\$1,577,901.*"));
//			U.log("PriceSec2"+Arrays.toString(U.getPrices(Psec,"\\$\\d,\\d{3},\\d{3}", 0)));
			String[] price = U
					.getPrices(
							html+priceSec+comSec+Psec,
							">\\$\\d{3},\\d{3}<|From the Mid \\s*\\d{3},\\d{3}|Upper \\$\\d{3},\\d{3} |Starting at \\$\\d+,\\d+|high \\$\\d+,\\d+|start in the \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",//|description price\">[^\\$]+\\$\\d+,\\d+
							0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
			
//			U.log(">>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{10}616,990[\\w\\s\\W]{10}", 0));
//			U.log(">>>>>>>>>"+Util.matchAll(priceSec, "[\\w\\s\\W]{10}616,990[\\w\\s\\W]{10}", 0));


			// Square Feet
			
			html=html.replace("5500+ square feet", "5500 square feet");
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							html+comSec,
							"\\d,\\d{3} Sq. Ft|from \\d{4}-\\d{4} square feet|square footage ranging from \\d,\\d{3} up to \\d,\\d{3}|and \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+ Sq Ft|\\d+- \\d+ sq ft.|\\d+ -\\d+ square feet|\\d{4} square feet|\\d+- \\d+ square feet|\\d+ – \\d+ square feet|\\d+-\\d+ sq ft homes|\\d{4}-\\d{4} square feet |Up to \\d{4}\\+ Sq Ft|\\d,\\d+ - \\d,\\d+ Sq Ft|\\d,\\d+\\s*-\\d,\\d+ square feet|\\d,\\d+ Sq Ft",
							0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			U.log(">>>>>>>>>"+Util.matchAll(priceSec, "[\\w\\s\\W]{10}square footage[\\w\\s\\W]{30}", 0));


			//---------
			html =html.replace("exceptional craftsmanship", "Craftsman Style Homes");
			html = html.replace("Settler’s Cabin Park and Wave", "");
			
			//-----------Property Type-----------
			//---Fetch single family from individual plan page
			
			String descripsec= U.getSectionValue(html, "<div class=\"community-discription\">", "</");
		//	String descripsec= U.getSectionValue(html, "<div class=\"communityDescription bdxRTEWrapper\">", "</div>");
			if(descripsec==null) {
				descripsec=U.getSectionValue(html, "<div class=\"communityDescription", "</div>");
			}
			String allPlanData = getPlanData(html);
			//U.log(allPlanData);
			
			allPlanData  = allPlanData.replace("shows like a custom home", "").replaceAll("Loft, |\\& loft ", "& loft homes").replace("traditional arrangement", "traditional home arrangement")
					.replaceAll("(V|v)illage|VILLAGE", "");
			html=html.replace("both natural and traditional", "Traditional exterior").replaceAll("Morning Dove Estates Single Family Homes|shows like a custom home|morning-dove-estates-single-family-homes|Builders now selling|(V|v)illage|VILLAGE","");
//			U.log(comSec);
//			U.log(descripsec);
			String propType = U.getPropType((html+allPlanData+descripsec+comSec).replace("Dining Area with Tray Ceiling and Modern Farmhouse D&#233;cor in Berkeley Lakes\" />", "").replace("craftsman and farmhouse style elevations", "").replaceAll("alt=\"Spacious loft area ideal for customizing to fit your family&#39;s needs|footerAnchorBackgroundColor|patio restaurant seating|(B|b)asement (h|H)omesite|luxurious owner’s bath|construction and craftsmanship|luxurious owner's bath|Floorplans Just Released|No HOA|Luxury Vinyl Plank flooring|"
					+ " With craftsman and brick front style elevations|estates-single-family-homes|estates-single-family|luxury vinyl plank flooring", ""));

//			U.log(">>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{30}Single[\\w\\s\\W]{30}", 0));

			
			if(propType.contains("Townhouse") && propType.contains("Townhomes")){
				propType = propType.replace("Townhouse", "").trim().replaceAll(",$|^,", "").trim().replace(", ,", ",");
			}
			//if(url.contains("https://www.danryanbuilders.com/communities/freedom-manor-single-family-homes/"))propType=propType.replace("Single Family, ","");
			
			U.log("pType: "+propType);
			
			
			html = html.replaceAll("Sold Out, Call for Details|maintenance included! Quick Move|move in now!|\\(coming soon|trees are now|convenience - Now|closing out-|selling out of our", "");
			String statusSec = html;

			statusSec=statusSec.replaceAll("coming early in 2020|Coming early in 2020", "coming early 2020");
			
			String remove = "has almost sold out in less than 2 years|New townhomes coming mid 2020 in Clover|Move-In|with limited homesites available! Come |errace Ready For Move In|Now available at WestRidge at Westphalia| trees are now available| temporarily selling out of the Clubhouse |marketingDescription\">\\s*COMING THIS FALL! |Coming This Fall! Homesite|COMING FALL 2019! End Unit |Less Than 25 Homesites Remaining|townhomes ready to move in now!|now closing out- just |Homes Ready Now</a></li>|Homes Ready Now|all Quick Move In Homes OR|New homes Coming Fall 2018|>30% Off Options on Quick Move-In Homes|Model Coming Soon| Coming in Fall of 2018, pricing|30% off options on quick delivery homes|Currently selling off-site at |Call to qualify for 100% financing today|Move In Ready Homes|\\(coming soon|Now Available!  Dan Ryan Builders| BASEMENT HOMESITES AVAILABLE|The Kenwood model is opening soon|New Home Available Soon!|quick move-in located|Ready - Tour|trails are now|Soon! From 8|Opportunity to Own|Lidl - Now Open|cabana will be opening|Move In 3-Bedroom";
			statusSec = statusSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
			comSec =comSec.replaceAll("Floorplans Just Released|Now available at WestRidge at Westphalia|Coming This Spring in Duncan| Last Opportunity! Hurry In!|Ready for Quick Move-In!|Less Than 25 Homesites Remaining|Beach! Coming 2019|Floorplan Now Available|Homes Available Now|Homes Ready Now|Executive Homes Now Available|More Details Coming Soon|\\(Coming Soon|Gorgeous model home now available|now open for Pre-sales|Spacious Basement Homesites Available|More Details Coming Soon|Only One Home Remains for Immediate Delivery|Garage Townhomes Now|Us About Homes|Immediate Delivery Available. By|Summer in Duncan|Quick Move-In|Soon in This Sought", "")
					.replace("Only a  Couple", "Only a Couple");
			(comSec+ statusSec+descripsec).replace("New Single Family homes COMING SOON", "New Homes Coming soon");
			
			
//			U.log(statusSec);
//			U.log(comSec);
//			U.log(descripsec);
			
			if(comSec!=null)
				comSec  =comSec.replace("New Phase of Townhomes Now Open", "New Phase Now Open")
						.replace("NEW PHASE OF HOMESITES COMING SOON", "New Homesites Coming Soon")
						.replace("Comming Spring of 2022", "Coming Spring 2022")
						.replace("\"This Community is Coming Soon!\"", "Coming Soon")
				.replace("New Homesites Coming Mid-2021", "New Homesites Coming Mid 2021");
//			U.log(statusSec);
			
			String[] rem = U.getValues(statusSec, "<li class=\"hproduct", "</li>");
			for(String rr : rem)
				statusSec = statusSec.replace(rr, "");
			if(descripsec==null)descripsec=ALLOW_BLANK;
			statusSec=statusSec.replace("New Single Family homes COMING SOON","New Homes Coming Soon");
			statusSec=statusSec.replaceAll("new phase coming dec. 1, 2021", "")
					.replaceAll("recreation center is coming soon|will be selling out", "");
		descripsec=descripsec.replaceAll("NEW PHASE COMING DEC. 1, 2021|Recreation Center is coming soon|Will be selling out", "");
		descripsec=descripsec.replace("an affordable Townhome (coming soon!)", "an affordable Townhome coming soon!");
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(statusSec+descripsec+comSec, "[\\s\\w\\W]{30}Coming soon[\\s\\w\\W]{30}", 0));
		String status = U.getPropStatus(((statusSec+descripsec+comSec).replaceAll("Coming This Summer! Easy Access|Grand Re-Opening|alt=Coming Soon|NEW PHASE OF HOMESITES NOW SELLING|2 QUICK MOVE-INS AVAILABLE FOR SPRING 2022|Final Opportunity, One Home Left|Villa Designed Homes! New Move-In Ready Homes Now Available|Stunning Views! 3 QUICK MOVE-INS AVAILABLE FOR SPRING 2022|tipComingSoon tipBa|coming-soon.png|munity is Coming Soon!|Backing to Treeline Area are Now Available", "")
					.replaceAll("Model coming spring 2022|model coming spring 2022|Final Opportunity, One Home Left|Backing to Treeline Area are Now Available|[c|C]urrently selling off-site by appointment|building now available|included! Quick Move-In Homes|Before Close Out!</p>|\">currently selling|Designs Coming Soon!|coming-soon|Quick Move-in pricing starting|tipCloseout|tipComingSoon|building almost sold|Now selling by appointment|now selling by appointment|currently selling offsit|Currently selling offsite|coming soon\\!\\s*wide|now available! craftsman|Ask About \\d+% Financing|homesite availability is limited|trees are now available|New townhomes coming mid 2020|Lawn maintenance included! Quick Move In|[C|c]urrently sold out, but great news|now selling offsite by appoi|Just One Move In Ready Home Remains in this Sought|move in ready home remains at marshall", "")));
			
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+statusSec+descripsec, "[\\s\\w\\W]{30}Now Selling[\\s\\w\\W]{30}", 0));
		
		status = status.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
	
		U.log("status====="+status);

			
			if(status!=null) {
				status = status.replace("New Phase Coming, New Phase Coming Summer 2021", "New Phase Coming Summer 2021")
				.replace("Basement Homesites Available, Basements Available", "Basement Homesites Available")
				.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon").replace("Homes Available Now, Now Available", "Homes Available Now")
			    .replace("Final 4 Opportunities, 4 Opportunities Remain","Final 4 Opportunities Remain");
			  
			}
			if(url.contains("https://www.danryanbuilders.com/communities/aspria-estates/"))status="Now Selling";
			
			if(status.equals("Final Opportunity, Closeout, Final Opportunity Now Selling")) {
				status = "Closeout, Final Opportunity Now Selling";
			}
			
			
			String availableHomeSection = U.getSectionValue(html, "Homes Available Now</h3>", "<div id=\"direction\">");
			int countOfAvailableHome = 0;
			if(availableHomeSection != null){
				countOfAvailableHome = U.getValues(availableHomeSection, "<li class=\"hproduct homeDataInformation", "</h3>").length;
			}
			U.log("-=-=-"+countOfAvailableHome);

			String noteVar = ALLOW_BLANK;

			add[0] = add[0]
					.toLowerCase()
					.replaceAll(
							"selling off site from sheridan estates |selling offsite from spruce hill north:br&gt;|-|selling offsite from summers ridge community|selling offsite at the point|selling off site by appointment. please call to set up an appointment!",
							"");
			add[0] = add[0]
					.toLowerCase()
					.replaceAll(
							"selling off site by appointment. please call to set Up an appointment!|selling off site,please contact sales consultants for details|selling offsite from boyds crossing,|selling offsite from boyds crossing,|selling offsite from the ridges of tuscarora,|selling Off-site From|Selling Off-site From|&#39;|Now Selling Off Site At Westphalia Row, Presidential Parkway|, 39.621434,|call now for more information on this coming soon community and to join our customer vip list!,|selling off site by appointment. please call to set up an appointment!|now selling!, pine tree road|selling off site,|visit our sales center, ",
							"");
			add[0] = add[0].replace("107 fitzgerald street gerrardstown, wv ", "107 fitzgerald street gerrardstown")
					.replace("4202 nc210", "4202 Nc-210")
					.replace("995 ga85", "995 Ga-85");
			add[1] = add[1].replaceAll(",", "");
			
			U.log("STREET:>>> :" + Arrays.toString(add));
			if(html.contains("ranch style")||html.contains("ranch home")||html.contains("style ranch")||html.contains("Style Ranch")||html.contains("Ranch Style")) {
				comSec=comSec+" ranch style ";
			}
			
			html=html.replaceAll("Ranch|RANCH|Colonial Drive|First Floor Owner|alt=\"2-Story single fa|alt=\"2-Story home|alt=\"2-Story Single fa|alt=\"2-story townhomes|"
					+ "alt=\"2 story townhome|1st Floor Guest Suite|1st Floor Owner|First Floor Homeowner","")
					.replaceAll("main living is on the second floor with an expansive|study or bonus room on the first floor","");
			comSec = comSec.replaceAll("Colonial Drive", "");
			//U.log(html);
			U.log("MTVH"+Util.matchAll((commuName).replaceAll("footerAnchorBackgroundColor|alt=\"2-car garage, ranch style home with stone water table and colonial blue exterior|1st Floor Homeowner&#39;s|1st Floor Bedroom|First Floor Bedroom|1st Floor Owner’s Suite|with 1st Floor Bedroom|1st Floor Guest Suite|Impressive First Floor Living|First Floor Owner&#39;s|First Floor Owner's|first floor owner’s|first floor owner|Floor Plan with 1st Floor Owner|Beautiful Open Floor Plan with 1st Floor Owner's Suite and Loft","")
					,".*ranch style chesterfield.*", 0));
			
			if(url.contains("https://www.danryanbuilders.com/communities/rosewood-village-villas/")) {
				html=html.replaceAll("[f|F]irst floor owner’s suite|First Floor Owner's Suite", "");
			}
			html=html.replaceAll("Home with 1st Floor Guest Room|with 1st Floor Bedroom and Media Room|Luxurious 1st Floor Homeowner|First floor owner's suite available|Gorgeous Study on First Floor|Beautiful Home with 1st floor Owner", "");
			
			String dType = U.getdCommType((html.replaceAll("Rendering of 3 level home|1st Floor Homeowner|second level in Butler, PA", "")
					.replaceAll(" 4th floor |First Floor Guest Suite Option|alt=\"2-story, single family model home with partial stone front and covered front porch with metal roof", "").replace("Eleanora will offer ranch", "Eleanora will offer 1 ranch")+comSec+commuName).replaceAll("Beautiful Modern Townhome with Finished Lower Level and 4th Floor Loft Option!|alt=\"2-car garage, ranch style home with stone water table and colonial blue exterior|1st Floor Homeowner&#39;s|1st Floor Bedroom|First Floor Bedroom|1st Floor Owner’s Suite|with 1st Floor Bedroom|1st Floor Guest Suite|Impressive First Floor Living|First Floor Owner&#39;s|First Floor Owner's|first floor owner’s|first floor owner|Floor Plan with 1st Floor Owner|Beautiful Open Floor Plan with 1st Floor Owner's Suite and Loft",""));
			
			U.log("dType===="+dType);
			

			
			if (commuName.contains("Riverside Villages"))
				dType = "3 Story";
			if(url.contains("https://www.danryanbuilders.com/communities/chesterfield-single-family-homes/"))dType=ALLOW_BLANK;

			add[0] = add[0].trim().replace("’", "'");
			if (add[0].contains("appointment!"))
				add[0] = ALLOW_BLANK;
			add[0] = add[0].toLowerCase();
//			U.log("STREET::" + add[0]);
			add[0] = add[0]
					.replaceAll(
							", shepherdstown, wv, community located in|selling offsite from the village of washington trail,|selling offsite from summers ridge community,",
							"");

			String latlng[] = { lat, lng };
			
			if (add[0].length() < 2) {
				String address[] = U.getAddressGoogleApi(latlng);
				if(address == null)
					address = U.getGoogleAddressWithKey(latlng);
				add[0] = address[0];
				geoCode = "TRUE";
			}
			add[0]=add[0].replace("(across from flint wood farms)", "");
			U.log("STREET::" + Arrays.toString(add));
			status = status.toLowerCase();
			status = status.replace("closeout", "close out");
			
			html=html.replace("NowPreSelling", "Now Pre-Selling");
			U.log("Note: "+U.getnote(comSec+html));
			
			status=status.replace("only 1 opportunity remains, only 1 opportunity remain, close out, 1 opportunity remains", "only 1 opportunity remain");
			
			U.log("XXX"+Util.match((comSec+ statusSec+descripsec), "coming soon"));
			
			U.log("status:::::::::::::::::::"+status);
			status=status.replace("quick move-in homes", "Homes Ready Now").replace(" move in ready home, Homes Available Now"," Homes Available Now").replace(" move-in ready, Homes Available Now"," Homes Available Now").replace("ready to move in, Homes Available Now","Homes Available Now").replace(" quick move-in, Homes Available Now"," Homes Available Now").replace(" now available, Homes Available Now"," Homes Available Now");
		
			
			html =html.replace("play a round golf,", "play a round golf course").replace("golf and hiking ", "golf course")
					.replaceAll("Anchor\">ACTIVE ADULT|Homes\\s?-\\s?Active Adult|<a href=\"/active-adult|classes to 55", "");
			
			commuName=commuName.trim().replace("townhomes$","");
			
			status = status.replace("iii ", "III ").replace("Ii", "II").replace("only one opportunity remains, one opportunity remaining,", "Only One Opportunity Remains, ");

			//status=U.getPropStatus(status);
			if (url.contains("/morgantown/canterbury-woods-townhomes/"))propType=propType+", Single Family";
			U.log(commuName);
			if(commuName.endsWith("villas"))
			commuName=commuName.replace("villas", "");
			
			if(html.contains("<h3 class=\"\">Homes Available Now</h3>") && !status.contains("Homes Now Available")&&!status.contains("homes now available")) {
				if(status.length()<=1)status ="Homes Available Now";
				else
					status =status+ ", Homes Available Now";

			}
			
			if(propType.contains("Townhome") && propType.contains("Townhouse"))
				propType = propType.replaceAll("Townhouse,|, Townhouse|Townhouse", "");
			
			if (url.contains("https://www.danryanbuilders.com//communities/ashton-market/"))status = "Grand Opening";//Img
			if(url.contains("https://www.danryanbuilders.com/communities/breckenridge/"))status="Limited Homes Available Now";
			
			
			add[0] = add[0].replace("1969819600 ", "19698-19600 ");
			
		
			//Repeated Status(DT 17 Jul 21)
			status = status.replace("Ii", "II").replace("new homesites available, Homes Available Now", "Homes Available Now").replace("only 1 opportunity remains, 1 opportunity remains", "only 1 opportunity remains");
			//formatting status
			if(url.contains("/tuscarora-creek-single-family-homes"))
			status = status.replace("coming soon, final opportunity", "Final Opportunity Coming Soon");
//			U.log(comSec);
			
			if(url.contains("https://www.danryanbuilders.com/communities/canterbury-station-townhomes"))add[0]="Monocacy Blvd";
			
			if(url.contains("https://www.danryanbuilders.com/communities/strabane-manor"))status= "Only 1 Opportunity Remains, Homes Available Now";
			if(url.contains("https://www.danryanbuilders.com/communities/meadows-at-twin-lakes/"))status="Grand Opening, Now Selling";
			if(url.contains("https://www.danryanbuilders.com/communities/fairchild-heights/"))status="Homes Available Now";
			
			
			String remfrComtype=U.getSectionValue(comSec, "<p class=\"item marketingDescription\">","</p>");
			U.log("REMMM -"+remfrComtype);
		//	comSec=comSec.replace(remfrComtype,"");
		//	U.log("CHK"+Util.matchAll(comSec, "[\\w\\W\\s]{50}Resort Style Amenities[\\w\\W\\s]{50}",0));
			String CommType=U.getCommunityType(comSec+html.replaceAll("entry pool, private lake", ""));
			if(url.contains("https://www.danryanbuilders.com/communities/grandview-estates/"))CommType=ALLOW_BLANK;
			if(url.contains("https://www.danryanbuilders.com/communities/stonebridge-townhomes-at-charles-pointe/"))commuName="Stonebridge Townhomes At Charles Pointe";
			//if(url.contains("danryanbuilders.com/communities/harvest-ridge/"))status=status+", Coming Soon";
//			if(url.contains("danryanbuilders.com/communities/weavers-pond-estates/"))status=status+", New Phase Coming Soon"; 
			if((url.contains("https://www.danryanbuilders.com/communities/meadow-view/"))) { 
				status = status + ", Coming Soon"; //from img. dattaraj 17 feb.
			}
			if(url.contains("https://www.danryanbuilders.com/communities/freedom-manor-single-family-homes/"))status="Close Out, Townhome coming soon";
			if(url.contains("https://www.danryanbuilders.com/communities/berkeley-lakes/"))status="Now Selling Next Section, Homes Available Now";
			
			//from img - 18 may 2022
			if(url.contains("https://www.danryanbuilders.com/communities/the-village-at-cabin-branch/") ||
					url.contains("https://www.danryanbuilders.com/communities/saddleridge/") ||
							url.contains("https://www.danryanbuilders.com/communities/mill-pond/")) {
						
						status=status + ", Coming Soon";
					}   
				
			data.addCommunity(commuName.replace("/the", "/The").replace("  and ", ""), url,CommType);
			data.addAddress(add[0].replace(",",""), add[1], add[2], add[3]);
			data.addLatitudeLongitude(lat, lng, geoCode);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(status.replace("New Section Coming Soon, Coming Soon", "New Section Coming Soon").replace("Ii", "II").replace("Iii", "III"));
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(U.getnote(comSec+html).replace("Now Pre-selling, Preselling", "Now Pre-selling"));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
		
		}	j++;
	//}catch(Exception e) {}
	}
	private String getPlanData(String cHtml) throws IOException{
		String planData=ALLOW_BLANK;
		String[] planUrls =U.getValues(cHtml, "<a class=\"image-box\" href=\"", "\""); 
		U.log("Total Plans :::::::::"+planUrls.length);
		int y =0 ;
		for(String planUrl : planUrls){
			if(y<=10)
			{
				planUrl ="https://www.danryanbuilders.com"+ planUrl;
//				U.log("planUrl:::"+planUrl);
				String planHtml =U.getHTML(planUrl);
				planData += U.getSectionValue(planHtml, "RTETextWrapper breadcrumbs", "Submit</button>");
				//break;
			}
			y++;
			
		}
		
		return planData;
	}
}