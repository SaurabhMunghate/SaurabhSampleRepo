/**
 * @author Aditya..
 */

package com.shatam.b_061_080;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractMHIMcGuyerHomebuilders extends AbstractScrapper {
	private static String BULIDER_NAME = "MHI-McGuyer Homebuilders - Build on your lot by Coventry Homes";
	private static String HOME_URL = "https://buildonyourlot.coventryhomes.com/";
	String geoCode = "FALSE";
	CommunityLogger LOGGER;

	public ExtractMHIMcGuyerHomebuilders() throws Exception {
		super(BULIDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Build on your lot by Coventry Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractMHIMcGuyerHomebuilders();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"MHI-McGuyer Homebuilders - Build on your lot by Coventry Homes.csv",
				a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		String homeHtml = U.getHTML(HOME_URL);
//		String regSec = U.getSectionValue(homeHtml,"<div id=\"build-locations\">", "</select>");
		String[] regSec = U.getValues(homeHtml,"<span class=\"ng-star-inserted\"><a ngx-ql=\"\" title=\"", "/a>");
		for(String regUrl:regSec) {
			regUrl="https://buildonyourlot.coventryhomes.com"+U.getSectionValue(regUrl, "href=\"", "\"");
//			U.log(regUrl+"=="+regName);
			getDetails(regUrl);
			
		}
//		U.log("regSec: "+regSec);
//		String[] regUrl = U.getValues(regSec, "value=\"/", "\">");
//		ArrayList<String> URL_LIST = new ArrayList<String>();
//
//		for (String rUrl : regUrl) {
//			URL_LIST.add(rUrl);
//		}
//	//	LOGGER.countOfCommunity(URL_LIST.size());
//		for (String rUrl : URL_LIST) 
//		{
//			String regionUrl = HOME_URL + rUrl;
//			U.log("Region Url::" + regionUrl);
//			getDetails(regionUrl);
//
//		}
		LOGGER.DisposeLogger();

	}

	private void getDetails(String regionUrl) throws Exception {
		
		//if(!regionUrl.contains("https://buildonyourlot.coventryhomes.com/locations/houston"))return;
		String regHtml = U.getHTML(regionUrl);
//		String communitySec = U.getSectionValue(regHtml, "<h1 style", "h1>");
		String communityName = U.getSectionValue(regHtml, "<h4>Overview of ", "</h4>");
		U.log("Community NAme::" + communityName);
		//regHtml=regHtml.replaceAll("Stories:", "Story");
		
		String derivedPropertyType = U.getdCommType(regHtml);
		if (data.communityUrlExists(regionUrl)) {
			LOGGER.AddCommunityUrl(regionUrl + "\t*********Repeated******\t");
			
			return;
		}
		LOGGER.AddCommunityUrl(regionUrl);

		// ******************Community Prices****************************

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		regHtml=regHtml.replaceAll("<span class=\"strikethrough\">\\W+\\$\\d,\\d+,\\d+</span>","" );
		String availHome=U.getSectionValue(regHtml, "<h2>Available Homes</h2>", "pageLoad_CommunitySide");
		
		
	//	U.log("available homes :"+availHome);
		
		regHtml = regHtml.replaceAll("0's|0's", "0,000");
		
		String[] price = U.getPrices(regHtml, "\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice);
		U.log(maxPrice);

		// ******************Community Area [SqrFeet]******************

		String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(regHtml, "\\d+ sf|\\d+ sqft", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log(minSqFeet);
		U.log(maxSqFeet);

		String street = ALLOW_BLANK;
		String city = ALLOW_BLANK;
		String state = ALLOW_BLANK;
		String zip = ALLOW_BLANK;
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String geo="True";
		if (regionUrl
				.equals("https://buildonyourlot.coventryhomes.com/locations/austin")) {
			street="5306 Marsh Creek Dr";
			city = "Austin";
			state = "TX";
			zip = "78759";
			lat="30.369913";
			lng="-97.7425754";
					
		}
		if (regionUrl
				.equals("https://buildonyourlot.coventryhomes.com/locations/dallas-ft-worth")) {
			street="2722 Lawtherwood Ct";
			city = "Dallas";
			state = "TX";
			zip = "75234";
			lat="32.8206646";
			lng="-96.7313396";
		}
		if (regionUrl
				.equals("https://buildonyourlot.coventryhomes.com/locations/houston")) {
			street="7676 Woodway Drive";
			city = "Houston";
			state = "TX";
			zip = "77063";
			lat="29.751778";
			lng="-95.5061799";
			geo="False";
		}
		if (regionUrl
				.equals("https://buildonyourlot.coventryhomes.com/locations/sanantonio")) {
			street="1209 Vintage Way";
			city = "San Antonio";
			state = "TX";
			lat="29.7785832";
			lng="-98.2625709";
		}

		
		
		regHtml=regHtml.replaceAll("Luxurious garden |Luxurious Baths","");
		String propertyType = U.getPropType(regHtml);
		
		
		regHtml=regHtml.replaceAll("phContent1_Noseminars\">\\W+Coming Soon!", "").replace("home is under construction", "");
		String propertyStatus = U.getPropStatus(regHtml);
		
		regHtml=regHtml.replaceAll("Elongated commode", "");
		String communityType = U.getCommunityType(regHtml);
		
	//	U.log(regHtml);
		U.log(derivedPropertyType);
		zip=U.getAddressGoogleApi(new String[]{lat, lng})[3];

		data.addCommunity(communityName, regionUrl, communityType);
		data.addAddress(street, city, state, zip);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(propertyType, derivedPropertyType);
		data.addPropertyStatus(propertyStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFeet, maxSqFeet);
		data.addNotes(ALLOW_BLANK);

	}

}
