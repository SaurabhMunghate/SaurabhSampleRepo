package com.shatam.b_061_080;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.json.JSONObject;

import com.gargoylesoftware.htmlunit.javascript.host.Symbol;
import com.gargoylesoftware.htmlunit.javascript.host.file.File;
import com.google.gson.JsonObject;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class MungoDemo extends AbstractScrapper {
       public static String builderUrl="https://www.mungo.com";
       static String builderName="Mungo Homes";
       
       CommunityLogger LOGGER;
	
	
	public MungoDemo() throws Exception {
		super(builderName, builderUrl);
	    LOGGER=new CommunityLogger(builderName);
	    	
	}

	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		long start = System.currentTimeMillis();
		
		AbstractScrapper a=new MungoDemo();
		 a.process();
		 FileUtil.writeAllText(U.getCachePath()+"Mungo Homes.csv", a.data().printAll());
		 
		 long end  = System.currentTimeMillis();
		 System.out.println("Total execution time :"+(end-start)+"ms.");
	     
	}

	@Override
	protected void innerProcess() throws Exception {
		
////		   
//	
//		
//	     
//	   
		
//		
		
		
			
		String mainHtml=U.getHTML("https://www.mungo.com/communities");
		//String communityData=U.getSectionValue(mainHtml, "\"requestedOnServer\":true,\"data\":[{", "\"unpublished\":");//FROM HTML//it will take first occurenece og data:[{@type":gattedResidenceCommunity
		String[] communityInfo=U.getValues(mainHtml,"{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");//FROM JSON
		//U.log("Total communities are "+communityInfo.length);
		int count=0;
		
		String comUrl=ALLOW_BLANK;
		
		
		
		String regInfos[]=U.getValues(mainHtml,"<div class=\"CommunityCard_wrapper\"", "<div class=\"CommunityCard_detailButton\"");
		
		U.log("total communities are: "+regInfos.length);
		int count1=0;
		String comName=ALLOW_BLANK;
	
		HashMap<String,String> hm=new HashMap<String,String>();
		for(String regInfo:regInfos) {
			 comUrl=U.getSectionValue(regInfo, "<a class=\"\" href=\"", "\" ");
			U.log("COMURL 11"+comUrl); 
			
			 
			 
			if(!comUrl.contains("http")) 
  			   comUrl=builderUrl+comUrl;
  		  U.log("COMURL 21"+comUrl);    
			
			
			
  		    	String comNameSec=U.getSectionValue(regInfo, "<!-- react-text:", "react-text -->");
 	    		 comName=(U.getSectionValue(comNameSec, "-->", "<!-- /")).trim();
 	    		// U.log("before removng html"+comNameSec);
 	    		
 	    		if(comName.isEmpty()) {
 	    			comNameSec=U.getSectionValue(regInfo, "class=\"CommunityCard_name", "class=\"CommunityCard_city");
 	    			comNameSec=U.getNoHtml(comNameSec);
 	    			
 	    			comNameSec.replaceAll("data-reactid=\"\\d{3}\">","");
 	    			comNameSec=U.getSectionValue(comNameSec, ">", "<span").trim();
 	    		
 	    			comName=comNameSec.trim();
 	    			
 	    			
 	    			
 	    		  }
 	    		
 	    		U.log("community Name from HTML is: "+comName);
// 	    		
//  			
 	    		comName= comName.replace("Available Sovereign Homes","Sovereign Scattered");
 	    		comName=comName.replace("Cypress Village","Cypress Bay");
 	    		comName=comName.replace("Ascot Woods","Ascot Woods Sovereign");
 	    		comName=comName.replace("The Preserve at Kitchin Farms","Kitchin Farms");
 	    		comName=comName.replace("The Grove", "Grove at Woodcreek");
 	    		comName=comName.replace("Mills Gate","Millsgate");
 	    		
 	    		comName=comName.replace("The Preserve at Stone Ridge", "Stone Ridge");
 	    		comName=comName.replace("Sherrill Place Village", "Sherrill Place");
 	    		comName=comName.replace("The Cottages at Carolina Park", "Cottages at Carolina Park");
 	    		if(comUrl.contains("https://www.mungo.com/communities/greenville-spartanburg/anderson/breckenridge-gr"))
 	    		  comName=comName.replace("Breckenridge","Breckenridge-GR");
 	    		if(comUrl.contains("https://www.mungo.com/communities/the-triad/thomasville/breckenridge-gb"))
 	    		 comName=comName.replace("Breckenridge","Breckenridge-GB");
 	    		comName=comName.replace("Parsons Mill Farm","Parsons Mill");
 	    		comName=comName.replace("Greenbriar","Greenbriar-SA");
// 	    		//comName=comName.trim();
 	    		//comName=comName.replaceAll("\\s+$", "");
 	    		char[] arr=new char[comName.length()];
 	    		for(int i=0;i<arr.length;i++) {
 	    			arr[i]=comName.charAt(i);
 	    			//U.log("comname in array"+arr[i]);
 	    			if((int)arr[i]==160){
 	    				arr[i]=32;
 	    			}


 	    		}
 	    	    comName=String.valueOf(arr);
 	    	   comName=comName.trim();
 	    	   
 	    	     
// 	    		
// 	    		
 	    		hm.put(comName,comUrl);
 	    		Set<String> keys=hm.keySet();
 	    		Iterator<String> it = keys.iterator();
// 	    		while(it.hasNext()) {
// 	    			U.log("keys are: "+it.next());
// 	    		}
// 	    		
// 	    		
 	    		
 	    	}
//		
		for(String comInfo:communityInfo) {
 				
			
 				String comNameSecV=U.getSectionValue(comInfo, "\"modifier_email\":", "\"outOfCommunity\":");
 				if(comNameSecV==null) {
 					comNameSecV=U.getSectionValue(comInfo, "\"modifier_email\":","\"\"photos\":");
 					String temp2=comNameSecV;
 					if(temp2==null) {
 						comNameSecV=U.getSectionValue(comInfo, "\"geoIndexed\":[", "\",\"pin\":");
 					}
 				}
 				 String temp2=ALLOW_BLANK;
 				
 			
//// 				
 				 if(comNameSecV==null) {
 					
 					 continue;//bcz without name that comInfo section is of no use....
 				 }
 				 String comNameV=U.getSectionValue(comNameSecV, "\"name\":\"", "\",");//FROM JSON
 				 comNameV=comNameV.trim();
// 				 comNameV=comNameV.replaceAll("\\s+$", "");
 				 
 				char[] arr=new char[comNameV.length()];
 	    		for(int i=0;i<arr.length;i++) {
 	    			arr[i]=comNameV.charAt(i);//for replacing special character from name which look like space bt ascii code is 160(space ascii code is 32)
 	    			
 	    			if((int)arr[i]==160){
 	    				arr[i]=32;
 	    			}


 	    		}
 	    	    comNameV=String.valueOf(arr);
 	    	   comNameV=comNameV.trim();
 	    	
				 if(hm.containsKey(comNameV)) {
					 String url=hm.get(comNameV);
//					 if(url==null&&comNameV.contains(comName)) {
//						 comNameV=comName;
//						 url=hm.get(comName);
//					 }
					 url=url.replace(" : Wellesley", "");
					 U.log("hash map url "+url);
					 addDetails(comNameV,url,comInfo,mainHtml);
					  }
 				  
				  }
 		
				  
				  
		
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comName,String comUrl,String comInfo,String mainHtml) throws Exception {
  //  if(!comUrl.contains("https://www.mungo.com/communities/columbia/southeast-downtown/kings-parish")) return;

			if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"REPEATED");
		return;
		}
		if(comUrl.contains("https://www.mungo.com/communities/wilmington/wilmington/middle-sound-village")) {
			LOGGER.AddCommunityUrl(comUrl+"PAGE NOT FOUND");
		}
		
	//	U.log("COMINFO"+comInfo);
		
		U.log("Community Name from addDetails"+comName);
		U.log("community url from ADD deatails"+comUrl);
		
		comName= comName.replace("Sovereign Scattered","Sovereign Homes");
 		comName=comName.replace("Cypress Bay","Cypress Village");
 		comName=comName.replace("Ascot Woods Sovereign","Ascot Woods");
 		comName=comName.replace("Kitchin Farms","The Preserve at Kitchin Farms");
 		comName=comName.replace("Grove at Woodcreek","The Grove");
 		comName=comName.replace("Millsgate","Mills Gate");
 		
 		comName=comName.replace("Stone Ridge","The Preserve at Stone Ridge");
 		comName=comName.replace("Sherrill Place Village","Sherrill Place");
 		comName=comName.replace("Cottages at Carolina Park","The Cottages at Carolina Park");
 		//if(comUrl.contains("/communities/greenville-spartanburg/anderson/breckenridge-gr"))
 		  comName=comName.replace("Breckenridge-GR","Breckenridge");
 		U.log("Namre"+comName);
 		//if(comUrl.contains("https://www.mungo.com/communities/greenville-spartanburg/anderson/breckenridge-gb"))
 		//if(comUrl.contains("/communities/the-triad/thomasville/breckenridge-gb"))	
 		 comName=comName.replace("Breckenridge-GB","Breckenridge");
		comName=comName.replace("Greenbriar SA","Greenbriar");
				
 		U.log("name after replacement"+comName);
		U.log("comURL IN ADD DEtail"+comUrl);
		
 		U.log("COMINFO"+comInfo);
	
			//*********Address***********
		    String note=ALLOW_BLANK;
			String address[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String value=ALLOW_BLANK;
			String latlngSec;
			
			String comId=U.getSectionValue(comInfo, "\"_id\":\"", "\",");
			U.log("Id "+comId);
			
			latlngSec=U.getSectionValue(comInfo, "\"geoIndexed\":", ",\"headline\":");
			 if(latlngSec==null||latlngSec=="[],") {
					latlngSec=U.getSectionValue(comInfo, "\"geoIndexed\":", "\"hide_plan_pricing");
					U.log("1st"+latlngSec);
					//String latlngSec1=latlngSec;
					if(latlngSec==null||latlngSec.equals("[],")) {
						latlngSec=U.getSectionValue(comInfo, "\"geoIndexed\":", ",\"hours\":");
						U.log("2nd"+latlngSec);
						}
						if(latlngSec==null||latlngSec.equals("[],")) {
							latlngSec=U.getSectionValue(comInfo,"\"geoIndexed\":", "}");
							
							//latlngSec1=latlngSec;
							U.log("3rd"+latlngSec);
						}
						
						if(latlngSec==null||latlngSec.equals("[],"))
							latlngSec=U.getSectionValue(comInfo, "\"geoIndexed\":", ",\"gradeSchool\":");
					}
					U.log("latlng beforte removing is:"+latlngSec);	
			
			// U.log("latlng beforte removing is:"+latlngSec);
			latlng[1]=U.getSectionValue(latlngSec,"[", ",");
			
			latlng[0]=U.getSectionValue(latlngSec,",", "]");
			String latlngSec1=U.removeSectionValue(latlngSec,"[", ",");
			//U.log("lat lng aftr removing "+latlngSec1);
			U.log("Lat is"+latlng[0]+" longitude is"+latlng[1]);
			

			//String addSec1=U.getSectionValue(comInfo, "\"outOfCommunity\":{\"address\":{", "\"photos\"");
			
			//U.log("AddSec1"+addSec1 );
			//if(addSec==null) {
				String addSec=U.getSectionValue(comInfo,"\"address\":{\"@type\":\"PostalAddress\"","\"agents\":");
				U.log("AddSec from If com info"+addSec);
			//}
			String num=ALLOW_BLANK;
			int number=0;
			if(addSec.contains("\"order\":")) {
			U.log("Add Sec is:"+addSec);
			num=U.getSectionValue(addSec, "\"order\":",",");
			num=num.trim();
			}
			
			
			address[0]=U.getSectionValue(addSec, "\"streetAddress\":\"", "\"}");
			address[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\",");
			addSec=addSec.replace("N/","NE");
			address[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\",");
			address[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\",");
			
			if(address[0].contains(num)) {
				geo="FALSE";
			}
			else {
				address[0]="-";
				address[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\",");
				address[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\",");
				address[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\",");
				

				if(latlng[0]==null||latlng[1]==null) {
					latlng=U.getlatlongGoogleApi(address);
					if(latlng[0]==null||latlng[1]==null)
					 latlng=U.getGoogleLatLngWithKey(address);
					if(latlng[0]==null||latlng[1]==null)
						latlng=U.getlatlongHereApi(address);
					
				}
				
				if(latlng[0]!=null&&latlng[1]!=null&&address[0]==ALLOW_BLANK) {
					address=U.getAddressGoogleApi(latlng);
					if(address==null) {
						address=U.getAddressHereApi(latlng);
					
					//note="latlong taken from city state given in webpage";
					
				      }
					//geo="TRUE";
				}				
				geo="TRUE";
			}
			

			
//		    number=Integer.parseInt(num);
//		    
//		    }
//			if(number>0) {
//			
//			address[0]=U.getSectionValue(addSec, "\"streetAddress\":\"", "\"}");
//			address[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\",");
//			addSec=addSec.replace("N/","NE");
//			address[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\",");
//			address[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\",");
//			U.log("address is from orede>0  given AT WEB PAGE"+Arrays.toString(address));
//			geo="FALSE";// Address taken from Json
//			}else if(number==0){
//		    	address[0]="-";
//				address[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\",");
//				address[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\",");
//				address[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\",");
//				
//
//				if(latlng[0]==null||latlng[1]==null) {
//					latlng=U.getlatlongGoogleApi(address);
//					if(latlng[0]==null||latlng[1]==null)
//					 latlng=U.getGoogleLatLngWithKey(address);
//					if(latlng[0]==null||latlng[1]==null)
//						latlng=U.getlatlongHereApi(address);
//					
//				}
//				
//				
//				if(latlng[0]!=null&&latlng[1]!=null&&address[0]==ALLOW_BLANK) {
//					address=U.getAddressGoogleApi(latlng);
//					if(address==null) {
//						address=U.getAddressHereApi(latlng);
//					
//					//note="latlong taken from city state given in webpage";
//					
//				      }
//					//geo="TRUE";
//				}				
//				geo="TRUE";
//				U.log("address is from order<0 not given at web page"+Arrays.toString(address));;
//			}
			if(latlng[0]==null||latlng[1]==null) {
				latlng=U.getlatlongGoogleApi(address);
				if(latlng[0]==null||latlng[1]==null)
				 latlng=U.getGoogleLatLngWithKey(address);
				if(latlng[0]==null||latlng[1]==null)
					latlng=U.getlatlongHereApi(address);
				geo="TRUE";
			}
			
			
//			
			
			
			 String add1[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			 String add2[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
				
				   
				 
			//******price**********
			
			//String comUrlPart=U.getSectionValue(comUrl, "com", "");
			String comUrlPart=Util.match(comUrl, "com.*");
			U.log("comUrlPart"+comUrlPart);
			comUrlPart=comUrlPart.replace("com/communities/", "communities/");
			
		//	U.log("comUrlPart"+comUrlPart);
			
			String priceInfos[]=U.getValues(mainHtml,"<div class=\"CommunityCard_wrapper\"","<div class=\"CommunityCard_detailButton\"");
			String minPrice=ALLOW_BLANK;
			String maxPrice=ALLOW_BLANK;
			
			String priceSec1=ALLOW_BLANK;
			for(String priceInfo:priceInfos) {
				//U.log("PriceInfo"+priceInfo);
				
				if(priceInfo.contains(comName)&&priceInfo.contains(comUrlPart)) {
			      priceSec1=U.getSectionValue(priceInfo, "<span class=\"CommunityCard_priceValue\"", "</span></li>");
			      //priceSec1=U.getSectionValue(priceSec, "-->", "<!-- ");
			      U.log("price sec1"+priceSec1);
			      if(priceSec1==null) {
			    	  priceSec1=ALLOW_BLANK;
			    	}
			      priceSec1=priceSec1.replace("0s","0,000");
			     // U.log("matching price "+Util.matchAll(priceSec1, "[\\w\\W\\s]{30}366[\\w\\W\\s]{30}", 0));
				}
			}
			String zip=address[3];
			String homeData[]=U.getValues(mainHtml,"{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}");
			String homesPriceNsqft=ALLOW_BLANK;
			String floorData=ALLOW_BLANK;
			String homeDesc=ALLOW_BLANK;
			for(String homes:homeData) {
				//U.log("home"+homes);
				//String postalCode=U.getSectionValue(homes, "\"postalCode\":\"", "\"");
				String IdinHomes=U.getSectionValue(homes, "\"containedIn\":\"", "\",");
				
				if(IdinHomes.equals(comId)){
					String[] cmngSoonHomes=U.getValues(homes, "\"plan\":", "\"uniqueName\":");
					String[] homeDescription=U.getValues(homes, "\"description\"", "\"elevationPhotos\"");
					for(String SoonHomes:cmngSoonHomes) {
						homesPriceNsqft=homesPriceNsqft+SoonHomes;
						U.log("cmg soon homes"+SoonHomes);
						
					}
					for(String descriptn:homeDescription) {
						homeDesc=homeDesc+descriptn;
					}
					//U.log("cmg soon homes"+homesPriceNsqft);
					//homesPriceNsqft=homesPriceNsqft+U.getSectionValue(homes, "\"plan\":", "\"uniqueName\":");
				}
			}
			
			String descr2=ALLOW_BLANK;
			
			String floorDataArray[]=U.getValues(mainHtml, "\"@type\":\"ProductModel\"", "\"type\":\"plan\"}");
			U.log("flooe ddata Array sizw"+floorDataArray.length);
			
			for(String floorDataArr:floorDataArray) {
				
		//	String comIdV[]=U.getValues(floorDataArr, "\"communities\":[{\"community\":\"", "\",");
				String comIdV[]=U.getValues(floorDataArr, "\"community\":\"", "\",");
				
				
				
			for(String comIdVs:comIdV) {
				//U.log("comId V"+comIdVs);
				//U.log(comIdV.equals(comId));
			if(comIdVs.equals(comId)) {
			
				
				String flr[]=U.getValues(floorDataArr,"\"community\":\""+comIdVs+"\",\"communityModelProperties\":", "\"elevationPhotos\":");
				U.log("total floor plan"+flr.length);
				//floorData=floorData+floorDataArr;
				for(String flrs:flr) {
				floorData=floorData+" "+flrs;
				descr2=descr2+U.getSectionValue(flrs, "\"description\":\"","");
				U.log("Hello");
				}
				U.log("d3esc"+descr2);
				
			}
			
			}
			//U.log("floor"+floorData);
			}
			
//		
		
//			//U.log("mmmmmm"+Util.matchAll(combinedPriceSec, "[\\w\\s\\W]{30}471[\\w\\s\\W]{30}", 0));	
            comInfo=comInfo.replace("0s", "0,000");
         
       
            String rem=U.getSectionValue(comInfo,"\"CommunityID\":\"GR-WDC0\",", "{\"ID\":\"Text_SectFS-Arc-MasterCling\"");
            String rem2=ALLOW_BLANK;
            if(rem==null) {
            	rem=U.getSectionValue(comInfo,"\"Value\":\"The Vanguard Collection in Catawba Hill features nine homes ranging from 1,675- 4,000+ SF.\"}", "{\"ID\":\"Text_SectFS-Ass-HomeMaint\"");
            	U.log("r4emSection"+rem);
            	if(rem==null) {
            		rem=U.getSectionValue(comInfo, "{\"ID\":\"Text_SectMktDescr\",\"Value\":\"The Magnolia Collection in Wellesley features three distinct homes ranging from 1,900-2,600+ SF.\"}","{\"ID\":\"Text_SectMktName\",\"Value\":\"Magnolia Collection\"}");
            	 rem2=U.getSectionValue(comInfo, "\"Name\":\"Wellesley\",\"ObjectFID\":\"0.-1.1063\"", "{\"ID\":\"Text_SectMktDescr\",\"Value\":\"The Cadence Collection in Wellesley");
            		//rem=rem+rem2;
            		U.log("r4emSection"+rem);
            		if(rem==null) {
                		rem=U.getSectionValue(comInfo, "\"marketing_name\":\"Avendell\"", "\"title\":\"Avendell | New Homes for Sale in Easley SC\"}");
                	if(rem==null) {
                		rem=U.getSectionValue(comInfo,"\"marketing_name\":\"Evans Park\"", "title\":\"Evans Park | New Homes for Sale in Murrells Inlet SC\"}");
                        }
            		
            		}
            		
            	}
            	
            	
            }
           // U.log("rem"+rem);
            if(rem!=null)  //for woodland chase min price
             comInfo=comInfo.replace(rem,"");
            if(rem2!=null)
            	comInfo=comInfo.replace(rem2, "");
//            String homeDescr=U.getSectionValue(floorData,"\"description\":\"", "\",");
//            U.log("flr proptype desc"+homeDescr);
//            
           // U.log("matching price "+Util.matchAll(comInfo,"[\\w\\W\\s]{40}200,000[\\w\\W\\s]{40}", 0));
          String[] prices2=U.getPrices(priceSec1+comInfo+homesPriceNsqft+floorData,"\\$\\d{3},\\d{3}|\"price\":\\d{6}|\"Price\":\\d{6}.\\d{2}|\"LotPremium\":\"$\\s \\d,\\d{3}.\\d{2}\"|Starting at \\$\\d{3},\\d{3}|\"price\":\\d{6}|\"Price:\"\\d{6}|\\$\\d{3},\\d{3}|:\\$\\d{6}|New homes from the \\$\\d{3},\\d{3}|:\\$\\d{6}|:\\$\\d{3},\\d{3}|\\$\\d{1},\\d{3}|\\$\\d{1},\\d{3}|low \\$\\d{3},d{3}|mid \\$\\d{3},\\d{3}|high \\$\\d{3},d{3}|Mid \\$\\d{3},d{3}|Low \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|\"price\":\\d{5}|\\$\\d,\\d{3}.\\d{2}|\"LotPremium\":\"\\$ \\d,\\d{3}.\\d{2}",0);
			if(prices2[0]==null){
				prices2[0]=ALLOW_BLANK;
			}
			
			if(prices2[1]==null) {
				prices2[1]=ALLOW_BLANK;
			}
			minPrice=prices2[0];
			maxPrice=prices2[1];
			
//			
			U.log("minPrice: "+minPrice+"max price"+maxPrice);
			
			
			
			  String minsqft=ALLOW_BLANK,maxsqft=ALLOW_BLANK;
			   String []sqft= {ALLOW_BLANK,ALLOW_BLANK};
//			   sqft=U.getSqareFeet(comInfo, "\"sqft\":\"\\d{4}\"|\"sqftHigh\":\\d{4}|\"sqftLow\":\\d{4}|sqftHigh|sqftLow|from \\d,\\d{3} to\\s\\d,\\d{3} square feet|up to \\d,\\d{3} square feet|range from \\d,\\d{3} to more than \\d,\\d{3} square feet"
//				 		+ "|Ranging from \\d,\\d{3} to more than \\d{4} square feet|Ranging up to \\d,\\d{3} square feet",0);
//			   if(sqft[0]==null||sqft[1]==null) {
				  // String exInfo=U.getSectionValue(comInfo, "\"description\":", ",\"geoIndexed\"");
			   U.log("JJ"+Util.match(comInfo, "range to more than 4,900 square feet"));
			   		
				   sqft=U.getSqareFeet(comInfo+homesPriceNsqft+floorData,"upto\\s*\\d,\\d{3}\\s*square\\s*feet|Ranging up to\\s*\\d{1},\\d{3}\\s*square feet|range to more than\\s*\\d,\\d{3}\\s*square feet|\\d,\\d{3} SQ FT|\"sqft\":\\d{4}|\"sqftHigh\":\\d{4}|\"sqftLow\":\\d{4}|sqftHigh|sqftLow|from \\d,\\d{3} to\\s\\d,\\d{3} square feet|up to \\d,\\d{3} square feet|range from \\d,\\d{3} to more than \\d,\\d{3} square feet|ranges from \\d,\\d{3} to more than \\d,\\d{3} square feet|Ranging from \\d,\\d{3} to more than \\d,\\d{3} square feet|Ranging from \\d,\\d{3} to more than \\d{4} square feet|Ranging up to \\d,\\d{3} square feet|range from \\d,\\d{3} to a generous \\d,\\d{3} square feet|Ranging from \\d{4} to more than \\d,\\d{3} square feet|range to more than \\d,\\d{3} square feet| range from \\d{1},\\d{3} to more than \\d{1},\\d{3}",0);
			        if(sqft[0]==null||sqft[1]==null) {
			        sqft[0]=ALLOW_BLANK;
			        sqft[1]=ALLOW_BLANK;
				   
				   }
			  // }
			  
				 minsqft=sqft[0];
				 maxsqft=sqft[1];
		
		U.log("sqft are: "+minsqft+" "+maxsqft);	      
			  
		  
		  
		  comInfo=comInfo.replace("Check out the available floor plans and quick move-in homes", "");
		 comInfo=comInfo.replace("Choose a floorplan or pick a quick move-in home today", "");
			 
			 String propStatus=ALLOW_BLANK;
			 propStatus=U.getPropStatus(comInfo.replace("Opportunities Limited", "Limited Opportunities"));
			// propStatus=propStatus.replace("Quick Move-in","");
			 if(propStatus.length()==0)
				 propStatus=ALLOW_BLANK;
			 
			 String propType=ALLOW_BLANK;
			 
			 
			 String propTypeSec=U.getSectionValue(comInfo, "\"description\":\"", "\"elevationPhotos\"");
			// U.log("PropT"+Util.matchAll(propTypeSec,"[\\w\\W\\s] {30}loft[\\w\\W\\s] {30}",0));
			 U.log("peoptypeSewc"+descr2);
				propType=U.getPropType(comInfo+propTypeSec+descr2+homeDesc);
			if(comUrl.contains("https://www.mungo.com/communities/the-triad/kernersville/stillwood")) propType="Common Area, Loft";
			if(comUrl.contains("https://www.mungo.com/communities/wilmington/leland/park-west-at-brunswick-forest"))propType=propType.replace(" Garden Home,", "");
					
			
			String commType=ALLOW_BLANK;
			 comInfo=comInfo.replace("Elongated","");
			 commType=U.getCommType(comInfo);
			
				String dCommType=ALLOW_BLANK;
				dCommType=U.getdCommType(comInfo+homeDesc);
				
				
				
				
			 LOGGER.AddCommunityUrl(comUrl);
			 data.addCommunity(comName, comUrl, commType);
			 data.addAddress(address[0].trim(),address[1].trim(),address[2].trim(),address[3].trim());
			 data.addLatitudeLongitude(latlng[0],latlng[1],geo);
			 data.addPrice(minPrice, maxPrice);
			 data.addPropertyStatus(propStatus);
			 data.addSquareFeet(minsqft, maxsqft);
			 data.addPropertyType(propType, dCommType);
			
			 data.addNotes(U.getnote(comInfo));
			 
			 
			 
			 
				
}
}	


	
		
	
			

