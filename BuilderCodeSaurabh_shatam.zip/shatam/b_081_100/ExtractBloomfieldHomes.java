/**

 * Modification Priti
 * layout changed
 * @date 24/01/2016
 */
/**Modification Aditya..
 *  @author Kushal Kadu
 * 
 *  @date 10/18/2014 
 */

package com.shatam.b_081_100;

import java.io.IOException;

import java.util.Arrays;
import java.util.HashMap;

import org.apache.regexp.recompile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBloomfieldHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicates = 0;
	private static final String builderUrl = "https://bloomfieldhomes.com/";
	//WebDriver driver = new FirefoxDriver();
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;

	HashMap<String, String> latLngList = new HashMap<>();
	
	public static void main(String ar[]) throws Exception {

		AbstractScrapper a = new ExtractBloomfieldHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Bloomfield Homes.csv",
				a.data().printAll());
		
	}

	public ExtractBloomfieldHomes() throws Exception {

		super("Bloomfield Homes", builderUrl);
		LOGGER = new CommunityLogger("Bloomfield Homes");
	}
	
	public void innerProcess() throws Exception {
		//Fetching communities section from locations page
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
//		
		String locUrl="https://www.bloomfieldhomes.com/";
		
		String locHtml=U.getHtml(locUrl,driver);
		U.bypassCertificate();
		
		String[] comSections=U.getValues(locHtml, "<div id=\"card_header_comm", "See Details</span>");
		U.log("comSections=="+comSections.length);
		
		for(String comSection : comSections){
			String url=U.getSectionValue(comSection, "<a href=\"/", "\">");
			String commUrl = "https://www.bloomfieldhomes.com/" +url;
			U.log("commUrl=="+commUrl);
			addMyDetails(commUrl,comSection);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	//TODO : Extract Community Details Here
	private void addMyDetails(String commUrl,String comSec) throws Exception {
//	if(j>=40)

	//if(!commUrl.contains("https://www.bloomfieldhomes.com/community-detail/Paloma-Creek-102636"))return;
	{
		
//		U.log("comSec=======\n"+comSec);
		
		U.log("\n================================\ncount : "+j+"\n"+"commUrl==="+commUrl);
		
		if(commUrl.contains("https://bloomfieldhomes.com/locations/kentsdale-farm/")){
			LOGGER.AddCommunityUrl(commUrl+"------------ Redirected");
			return;
		}

		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"------------repeated");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);

		String comHtml=U.getHtml(commUrl,driver);
		U.bypassCertificate();

		String comHtml1 = comHtml;
		String com_Sec=U.getSectionValue(comHtml, "<html", "<div class=\"gallery-viewport\">");
		U.log("Cache==="+U.getCache(commUrl));
	//--------Com NAme------------
//		U.log(commUrl);
		String comName=U.getSectionValue(comSec, "communityUrlInfo\">", "</a>");
		if (comName!=null) {
			comName=comName.replace("&amp;", "&").replaceAll(" - Coming Soon!| - COMING SOON!", "");
		}
		else {
			comName=U.getSectionValue(comHtml, "<title>", "</title>").trim().replace(" - Pre-Selling From Steadman Farms!", "");
			
		}
		
		U.log("comName::"+comName);
		
		//------------remove dropdown section-------------
		String remDrop = U.getSectionValue(comHtml, "ainNav setActiveNav mainNavCount6", "data-level-2-id=\"level-2-7\"  >");
		if(remDrop!=null){
			U.log("success remdrop");
			comHtml=comHtml.replace(remDrop, "");
		}
		remDrop = U.getSectionValue(comHtml, "<head>", "</head>");
		if(remDrop != null) comHtml = comHtml.replace(remDrop, "");
		
		comHtml=comHtml.replaceAll("Ranch Rd.|footerAnchorBackgroundColor|personalizationRegisterAnch|water feature coming soon| MOVE-IN READY!", "");
		//U.log("result::"+Util.match(comHtml, ".*?ranch.*?"));
		
		//--------Community Type, 
		String comType=ALLOW_BLANK;
		comHtml=comHtml.replaceAll("Golf Course\"|Prosper Lake Community Video|512 Cottage Place|Lakes of Cross Oak Ranch|Lone Star Ranch|Left on Country Club Road","");
		comHtml=comHtml.replace("disc golf,","");
		
		String desc=U.getSectionValue(com_Sec, "<div class=\"api-text-container\"", "Request More Information</button> ")+
				U.getSectionValue(com_Sec, "Community Details</span></h2>", "</div> \n" + 
						"</div> \n" + 
						"</div>");;
//		U.log("desc::"+desc);
		comType=U.getCommunityType(desc.replace("Top Golf</span>", ""));
		
		
		U.log("comType::"+comType);
		
		//-----------Property Type
		String propType=ALLOW_BLANK;
		
		String allPlanData=getPlanData(comHtml);
		
		String remove = "Star Ranch|Ridge Ranch|locations/lewis-ranch|Stone Ranch|stone-ranch|Oak Hill Ranch|personalizationRegisterAnchor|RANCH</a>|lewis-ranch|OAK HILL RANCH|-ranch\" |RIDGE RANCH|RANCH</a>|ridge-ranch|oak-hill-ranch|LEWIS RANCH| Bison Ranch|Craig Ranch|Sky Creek Ranch|512 Cottage Place|Byrd Ranch Road|\\+Cottage\\+Place|Twin Creeks Park |TPC Craig Ranch|Ridgeview Ranch|Cottage(\\+|\\s)Place";
//		U.log("allPlanData::"+allPlanData);	
		
		propType=U.getPropType((com_Sec+allPlanData).replaceAll(remove, ""));
		
		U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{100}HOA[\\w\\s\\W]{100}", 0));

		
		U.log("propType::"+propType);
		
		//-------------Derived Type------------

		String dType=ALLOW_BLANK;
		dType=U.getdCommType(comName+comHtml.replaceAll(remove, "")+allPlanData); 
		U.log("dType::"+dType);
		
		//------------Status-----------
		String pStatus=ALLOW_BLANK;
//U.log(comHtml);
		comSec = comSec.replaceAll("New Phase Coming Spring 2021|Phase 2 Coming Winter of 2020-2021 Soon!\">|New Phase Coming Summer 2021|tipCloseout", "");
		comSec = comSec.replace("flagcloseout.png?", " Last Chance ");
		comHtml = comHtml.replace("flagcloseout.png?", " Last Chance ")
				.replace("Final Opportunities remaining in the current phase", "Final Opportunities remaining current phase")
				.replace("Next Phase coming Summer 2022", "Next Phase coming Summer 2022")
				.replace("Phase 1 of the Parks at Panchasarp Farms is Sold Out", "Phase 1 Sold Out")
				.replace("6/1/21 Final Opportunities for current phase", "Final Opportunities")
				.replace("Next Phase Coming in 2022", "Next Phase Coming 2022")
				.replace("Coming Soon | Fall 2021", "Coming Soon Fall 2021")
				.replaceAll("marketingDescription\">\n\\s*IMMEDIATE MOVE-IN|content=\"Coming Soon| More details on Oak Hill Ranch coming soon| Coming Soon Fishing Pond|menityHolder\">\\s*<h3>Coming Soon</h3>|Coming soon to R|quick move-in homes for sale in Prosper|Now announcing the new phase grand opening|premium greenbelt home sites|>View Quick Move In Homes </span>", "")
				.replaceAll("tipCloseout|alt=\"Coming Soon |selling from our New Model|Half acre lots available and", "")
				.replaceAll("Phase 2 Coming Winter of 2020-2021 Soon!\">|Phase 2 - Coming Winter of 2020-2021|coming-soon-replace|=\"This Community is Coming|Phase 2</h1>\\s+<h2 class=\"rte-embed-code\">Coming Winter 2020-2021", "Phase 2 Coming Winter of 2020-2021")
				.replaceAll("New Phase opens December 11th|Coming Fall 2021|Coming Winter of 2020-2021-2021\\.png|Updated \\d/\\d{2}/\\d{2}", "")
				.replace("8/19/21 Final Opportunities for current phase", "Final Opportunities current phase").replace("Next Phase", "Next phase").replace("Current phase is sold out", "Current phase sold out").replace("Final Opportunities Remaining in the current phase.", "Final Opportunities Remaining in current phase.").replace("Final Opportunities in the current phase", "Final Opportunities in current phase");
//				.replaceAll("[L|l]imited [a|A]vailability|Limited Availability. Join our Interest List to receive email updates|Limited Availability.  Join our Interest List to receive email updates|alt=\"Limited Availability Coming Soon\"|limited availability- click here to join our interest list|Limited [a|A]vailability. Join our [i|I]nterest [l|L]ist to receive email updates|[limited availability|Limited Availability] - [c|C]lick here to join our interest list|Limited Availability Click Here to Join Our Interest List|Limited [A|a]vailability. Please join our interest list to receive email updates", "");
		
			String status_Sec=U.getSectionValue(comSec, "<img class=\"card_comm_status_image\"", "\">");
			U.log("status_Sec::"+status_Sec);
			if(status_Sec!=null) {
				status_Sec=status_Sec.replace("coming-soon-", "coming soon")
						.replace("Opening-flag", "Grand Opening")
						.replace("Close-flag", "Closeout");
				comSec=comSec+status_Sec;
			}
		
			pStatus=U.getPropStatus((com_Sec+comSec).replaceAll("QUICK MOVE-IN|The next phase is anticipated to open Summer 2022|Coming Fall 2021|Phase 2 Coming Winter of 2020-2021 Soon!\">", ""));
			pStatus=pStatus.replaceAll("Quick Move-in|, Quick Move-in|Quick Move-in,","");
		
//		U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{100}Limited Availability[\\w\\s\\W]{100}", 0));

		U.log("pStatus::"+pStatus);
		
		//Take status from "Homes Available Now" string
		if(comHtml.contains("<h3 class=\"\">Homes Available Now</h3>")){
			if(!pStatus.contains("Homes Available Now")){
				if(pStatus.length()<5)
					pStatus="Homes Available Now";
				else
					pStatus=pStatus+", Homes Available Now";
			}
		}
		
		String quick_sec = U.getSectionValue(comHtml, ">Quick Move-Ins</span></h2>", "Plans Available to Build</span></h2> ");
      //  U.log("QUIVK:: "+quick_sec);
		if(quick_sec!=null){
			String[] quick_data = U.getValues(quick_sec, "<div id=\"card_header", "See Details");
			U.log("quick_data.length::"+quick_data.length);
			if(quick_data.length>0) {
			if(!pStatus.contains("Quick Move-Ins")){
				if(pStatus.length()<5)
					pStatus="Quick Move-Ins";
				else
					pStatus=pStatus+", Quick Move-Ins";
			}
			}
		}
//		else {
//			U.log("::::::::::::??????????");
//		}
		U.log("pStatus-2::"+pStatus);

		//-------------Address---------------
		String[] address={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
		String geo="False";

		String addsec=U.getSectionValue(comHtml, "<span class=\"address-text\">", "</span>");
		U.log("addsec=="+addsec);
		if(addsec==null) {
			addsec=U.getSectionValue(comHtml, "Visit Our Community Sales Office</h3>","</a>");
		}
		addsec = addsec.replace("&#39;", "'")
				.replace("On E. Davis Ave. between Santa Fe. St. and Lopez Dr. Directly across from Alvarado Elementary school", "E. Davis Ave");
//		address[0]=U.getSectionValue(addsec, "<span class=\"addressStreet\">", "</span>");
//		//address[]=null;
//		U.log("address[0]::::::::"+address[0]);
//		address[1]=U.getSectionValue(addsec, "<span class=\"addressCity\">", "</span>");
//		address[2]=U.getSectionValue(addsec, "<span class=\"addressState\">", "</span>");
//		address[3]=U.getSectionValue(addsec, "<span class=\"addressZipCode\">", "</span>");
		address=U.getAddress(addsec);
		U.log("Address is ::::"+Arrays.toString(address) );
		
		//Street Name from Model Homes Address
		if(address[0] == null && address[1] != null ){
			String modelAdd = U.getSectionValue(comHtml, "hl=en&amp;authuser=0\" target=\"_blank\">", "</a>");
			if(modelAdd !=null)
			{	
				modelAdd = U.formatAddress(modelAdd);
				//U.log("modelAdd : "+modelAdd);
				if(modelAdd.contains(address[1])){
					address[0] = modelAdd.substring(0,modelAdd.indexOf(","));
				//	U.log("Model Street : " + address[0]);
				}
			}
		}
//		latlng[0]=U.getSectionValue(comHtml, "Latitude:</span> ", "</span>");
//		latlng[1]=U.getSectionValue(comHtml, "Longitude:</span> ", "</span>");
		String latlngSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/", "\" target=");
			if(latlngSec!=null) {
				latlng=latlngSec.split(",");
			}
		
		if (latlng[0]==null) {
			latlng[0]=U.getSectionValue(comHtml, "data-center-latitude=\"", "\"");
			latlng[1]=U.getSectionValue(comHtml, "data-center-longitude=\"", "\"");
		}
		
		U.log("latlng is ::::"+Arrays.toString(latlng) );
		
		if(address[0] == null) address[0] = ALLOW_BLANK;
		address[1] = address[1].replace(",", "");
		
		U.log("Street::"+address[0]+"::Street");
		if(address[0].length()<4){
			address=U.getAddressGoogleApi(latlng);
			if(address == null) address = U.getAddressHereApi(latlng);
			geo="True";
		}		
		//U.log(comSec);
		//----------------Price-------------------------
		
       String removeSec=U.getSectionValue(comHtml, "let priceRangeMapping = {", "return priceRangeMapping[priceRange];");
       comHtml=comHtml.replace(removeSec, "");
		
		String minPrice=ALLOW_BLANK, maxPrice=ALLOW_BLANK;
		comHtml=comHtml.replaceAll("$660,000s to $1,000,000s </h2>", "$660,000 to $1,000,000 </h2>");
		comHtml=comHtml.replace("000s", "000");
		comHtml = comHtml.replaceAll("0s", "0,000");
		String[] prices=U.getPrices(comHtml+comSec, "from \\$\\d{3},\\d{3} to the \\$\\d{3},\\d{3}|to \\$\\d,\\d{3},\\d{3} </h2>|\"dealPrice\">\\$\\d{3},\\d{3}</span>|from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} to the \\$\\d{3},\\d{3}|dealPrice\">\\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|data-price=\"\\d{6,7}\"|<span class=\"dealPrice\">\\$\\d{3},\\d{3}</span>|from the \\$\\d{3},\\d{3}s to Mid-\\$\\d{3},\\d{3}s</h2>|\\$\\d{3},\\d{3}s to \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}s to \\$\\d{3},\\d{3}s|\\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|to \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}", 0); 
		minPrice= (prices[0]==null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
		
		U.log("min price::"+minPrice);
		U.log("max price::"+maxPrice);
//		U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{20}554,470[\\w\\s\\W]{20}", 0));
//		U.log(Util.matchAll(comSec, "[\\w\\s\\W]{20}554,470[\\w\\s\\W]{20}", 0));

		//----------Square Feet--------------
		String minSqFt=ALLOW_BLANK, maxSqFt=ALLOW_BLANK;
		String headerSqft = U.getSectionValue(comHtml, "</h1>", "</h2>")+U.getSectionValue(comHtml, "<h1>", "</span></p>")+U.getSectionValue(comHtml, "</h1>", "Square Feet</div>")+"Square Feet</div>";
		
		if(headerSqft != null){
			headerSqft = headerSqft.replaceAll("</span>\\s*<span>|<span>\\s*</span>|<span>|</span>", "");
		}
		
		comHtml = comHtml.replaceAll("<span id=\"suffix-text-\\d+_\\d+-\\d+-\\d+\" class=\"suffix-api-text\">Sq. Ft.", " Sq. Ft.")
				.replaceAll("<span>,</span><span>(\\d+)</span>", ",$1")
				.replaceAll("<span>(\\d),</span><span>(\\d+)</span>", "$1,$2");


		String[] sqft=U.getSqareFeet(headerSqft+comHtml+comSec+com_Sec, "from \\d{4} to over \\d{4} Square Feet|\\d{4} Sq. Ft.|\\d{4} - \\d{4}</span>\\s*Sq. Ft.|\\d{4}-\\d{4} Square Feet|\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d,\\d{3} - </span><span>\\d,\\d{3}</span><span> Square Feet|\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d{1},\\d{3} - \\d{1},\\d{3} Square Feet| \\d,\\d{3} - \\d,\\d{3} Square Feet|\\d{1},\\d{3} - \\d{1},\\d{3} Square Feet|\\d{1},\\d{3}\\s*-\\s*\\d{1},\\d{3}\\s*Square Feet|\\d{1},\\d{3}\\s*-\\s*\\d{1},\\d{3}\\s*Square Feet|\\d{1},\\d{3} Square Feet", 0); 
		minSqFt= (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
		maxSqFt = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
//		U.log(comHtml.contains("1,840 "));
//		U.log(">>>>>>>>>"+Util.matchAll(headerSqft+comHtml+comSec, "[\\w\\s\\W]{20}2240[\\w\\s\\W]{20}", 0));

		U.log("min SqFT::"+minSqFt);
		U.log("max SqFt::"+maxSqFt);
		
		//----------notes----------
		String notes=ALLOW_BLANK;
		notes=U.getnote(comSec+comHtml.replace("Pre-Sales have opened for Phase 2", "Pre-Sales for Phase 2"));
		

		
		if(commUrl.contains("https://bloomfieldhomes.com/locations/hardeman-estates/")){
			address[0]="9928 Chrysalis Dr";
			address[1]="Fort Worth";
			address[2]="TX";
			address[3]="76131";
		}
		if(pStatus.length()==0){
			pStatus=ALLOW_BLANK;
		}

		address[0]=address[0].replace(", Mansfield, TX 75054", "");
//		if(commUrl.contains("/somerset/"))pStatus = pStatus.replace("New Phase Coming Soon", "Coming Soon");
//		if(commUrl.contains("https://bloomfieldhomes.com/locations/paloma-creek/"))pStatus = pStatus+", New Phase Coming Soon"; //from img
//		if(commUrl.contains("https://bloomfieldhomes.com/locations/dove-chase/"))pStatus = "Next Phase Coming Soon";
		//if(commUrl.contains("https://bloomfieldhomes.com/locations/country-lakes/"))pStatus = pStatus+", New Phase";
		//if(commUrl.contains("https://bloomfieldhomes.com/locations/parks-at-panchasarp-farms/"))pStatus = pStatus.replace(", New Phase Coming Late 2021", "");
		if(commUrl.contains("com/community-detail/North-Grove-117826"))propType=propType+", Common Area";
		comName=comName.replaceAll("<br />\\$280,000s to \\$420,000s| Pre-Selling Now!| NOW PRE-SELLING!", "");
		//Add in csv
		if(commUrl.contains("https://bloomfieldhomes.com/locations/clairmont-estates/"))address[0]="Schluter Rd";
		
		
//		pStatus=pStatus.replace("Quick Move-in, Quick Move-Ins", "").replace("Coming Soon, Final Opportunities Remain, New Phase Coming Summer 2021, Coming Soon, New Phase Coming Fall 2021", "Coming Soon, Final Opportunities Remain, New Phase Coming Summer 2021");
//		pStatus=pStatus.replace("Quick Move-in, Quick Move-Ins", "Quick Move-in");
		if(commUrl.contains("community-detail/Arcadia-Trails-167876"))pStatus="Coming Soon";
		
		//from Model image dt 21Aug21
		if(commUrl.contains("https://bloomfieldhomes.com/locations/plantation/"))pStatus="New Phase Coming Soon, "+pStatus;//from img
		if(commUrl.contains("/locations/paloma-creek/"))pStatus=pStatus.replace("New Phase", "New Phase Coming Soon");//from img
		if(commUrl.contains("/locations/willow-wood/"))pStatus=pStatus.replace("Coming Soon", "New Phase Coming Soon");
		
		if(pStatus!=null)
			pStatus = pStatus.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling")
			.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon")
			.replace("Quick Move-in, Quick Move-Ins", "Quick Move-in")
			.replace("Coming Winter 2022, Coming Soon", "Coming Winter 2022");
		
		data.addCommunity(comName, commUrl, comType);
		data.addAddress(address[0].replace("-", " ").trim(), address[1], address[2].trim(),
				address[3].trim());
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(notes.replace("Ii", "II"));
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		
		
	}
	j++;
	
	}
	
	public String getPlanData(String cHttml) throws IOException{
		String planData=ALLOW_BLANK;
		int x=0;
		String plan_Sec= U.getSectionValue(cHttml, ">Plans Available to Build</span></h2> ", ">Gallery</span></h2>");
		String[] planUrls=U.getValues(plan_Sec, "<div id=\"card_header_plan", "See Details</span>");
		U.log("total planUrls:::"+planUrls.length);
		for(String plan_Data: planUrls){
//			if(x<=10){
			
			String planUrl="https://www.bloomfieldhomes.com"+U.getSectionValue(plan_Data, "<a class=\"card_anchor\" href=\"", "\">");
			U.log("plan Url::"+planUrl);
			try{
			String planHtml=U.getHtml(planUrl,driver);
//			if(planHtml.contains("common")) {
//				U.log("FOUND");
//			}
			planData += U.getSectionValue(planHtml, "Overview</a>", "Request More Information</button>"); //"<div id=\"sign-in-pop\"")+planData;
			}
			catch(Exception e){
				U.log(e);
			}
			//U.log("planData::"+planData);
			//break;
			/*if(planData!=null && planData.contains("SINGLE FAMILY")){
				U.log("Success SINGLE FAMILY");
				break;
			}*/
//			x++;
//			}
		}
		
		return planData;
	}
	
}