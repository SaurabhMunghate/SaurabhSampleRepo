package com.shatam.b_081_100;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringEscapeUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class ExtractCastlerockCommunities extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int i=1;
	static int j=0;
	
	public static void main(String[] args) throws Exception {
			
		AbstractScrapper a = new ExtractCastlerockCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"CastleRock Communities.csv", a.data().printAll());
	}
	
	static MultiValueMap homesDataMap = new MultiValueMap();
	static MultiValueMap plansDataMap = new MultiValueMap();
	
	public ExtractCastlerockCommunities() throws Exception {

		super("CastleRock Communities", "https://www.c-rock.com/");
		LOGGER = new CommunityLogger("CastleRock Communities");
	}
	@Override
	public void innerProcess() throws Exception {
		long startTime = System.currentTimeMillis();
		
		String[] regions = { "Austin", "Dallas", "Houston", "San%20Antonio" };
		//String[] regions = { "Dallas" };
		
		for(String region:regions) {
			String regionComUrl = "https://www.c-rock.com/_dm/s/rt/actions/sites/069fba31/collections/"+ region +"%20Comms/ENGLISH";
			String regionComData = U.getHTML(regionComUrl);
			regionComData = regionComData.replace("\\\"", "\"");
			regionComData = StringEscapeUtils.unescapeJava(regionComData);
			regionComData = regionComData.replace("\"[", "[").replace("]\"", "]");
			//U.log("regionComData: "+regionComData);
			//U.log("regionComUrl: "+regionComUrl);     //for all communities json data in region
			
			JsonParser json = new JsonParser();
			JsonObject objJsonCom = (JsonObject)json.parse(regionComData); 
		
			JsonArray valueArray = new JsonArray();		
			valueArray = (JsonArray)objJsonCom.getAsJsonArray("value");			//array of all communities data in a region
			
			//U.log("objJsonCom: "+objJsonCom.toString());					
			//FileUtil.writeAllText("/home/shatam-10/Desktop/data/san.txt", objJsonCom.toString());
			U.log("Community count in "+region+" : "+valueArray.size());
			
			//homes data in region
			homesData(region);
			
			//plans data in region
			plansData(region);
			
			for(int i=0; i<valueArray.size(); i++) {
				String comJsonData = valueArray.get(i).toString();
//				try {
					addDetails(comJsonData, region);
//				} catch (Exception e) {}
			}
			//break;
		}
		LOGGER.DisposeLogger();		
		long timeMillis = System.currentTimeMillis() - startTime;
		U.log("Time Taken: "+timeMillis);
		long seconds = (timeMillis / 1000);
		U.log("Time Taken in seconds: "+seconds);
		long mins = (seconds / 60);
		U.log("Time Taken in mins: "+mins);
	}


	private void addDetails(String comJsonData, String region) throws Exception {

//		if(i>=100 ) {
		//================ Duda Community Url
		String dudaUrl = U.getSectionValue(comJsonData, "\"DudaUrl\":\"", "\",");
		U.log("dudaUrl: "+dudaUrl);
		
		//================ Community Url
		String comUrl = U.getSectionValue(comJsonData, "\"CommunityUrl\":\"", "\",");
		
		if(comUrl == null || comUrl.isEmpty()) {		
			comUrl = "https://www.c-rock.com/"+ region.toLowerCase() +"-community-detail/" + dudaUrl;
		}
		U.log(+i+". comUrl: "+comUrl);

//SINGLE EXECUTION
//		if(!comUrl.equals("https://www.c-rock.com/austin-community-detail/Canopy-at-Hudson-Bend-75937")) return;
		
		//================ Community Logger
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"----------------------------------------Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//================ Community Name
		String comNameSec = U.getSectionValue(comJsonData, "\"BrHi\"", "\"Desc");
		String comName = U.getSectionValue(comNameSec, "\"Name\":\"", "\",");
		U.log("comName: "+comName);
		
		//================ Address and latLng
		String add[]= { ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK };
		String latlng[]= { ALLOW_BLANK,ALLOW_BLANK };
		String geo="FALSE";
		
		latlng[0] = U.getSectionValue(comJsonData, "\"Lat\":\"", "\",");
		latlng[1] = U.getSectionValue(comJsonData, "\"Lng\":\"", "\",");
		U.log(Arrays.toString(latlng));
		
		add[0] = U.getSectionValue(comJsonData, "\"Addr\":\"", "\",");
		
		if(add[0] == null ) {
			add[0] = ALLOW_BLANK;
		}
		if(add[0].contains("Coming Soon")) {
			add[0] = add[0].replace("Coming Soon", ALLOW_BLANK);
		}
		if(add[0].contains("- 9504 Petrichor Blvd.")) {
			add[0] = add[0].replace("- 9504 Petrichor Blvd.", "9504 Petrichor Blvd.");
		}
		add[0] = add[0].replaceAll("Canopy at Hudson Bend by CastleRock Communities|The Preserve at Lakeway by CastleRock Communities|"
				+ "Newport by CastleRock Communities|Hudson Reserve By CastleRock Communities", ALLOW_BLANK);
		
		add[1] = U.getSectionValue(comJsonData, "\"City\":\"", "\",");
		add[2] = U.getSectionValue(comJsonData, "\"State\":\"", "\",");
		add[3] = U.getSectionValue(comJsonData, "\"Zip\":\"", "\",");
		U.log("ADDRESS: "+Arrays.toString(add)+" GEO: "+geo);
		
		if(comName.equals("Summerwood Trails")) {
			latlng[0]= ALLOW_BLANK;   //improper latLng on web
			latlng[1]= ALLOW_BLANK;
			latlng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlng);
			geo="TRUE";
			U.log("ADDRESS GEOCODED: "+Arrays.toString(add)+" GEO: "+geo);
		}
		
		if(add[0].equals(ALLOW_BLANK) && latlng[0] != ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latlng);
			geo="TRUE";
			U.log("ADDRESS GEOCODED: "+Arrays.toString(add)+" GEO: "+geo);
		}
		
		//================ Homes Data
		int homesCount = 0; 
		String homesInfo = ALLOW_BLANK;
		
		ArrayList<String> homes = (ArrayList<String>) homesDataMap.get(dudaUrl);
		if(homes != null) {
			for(String home:homes) {
				
//				String specSale = U.getSectionValue(home, "\"SpecSaleStatus\":", ",\"");   //for removing homes with "sold" image. Use this json flag.
//				//U.log("specSale: "+specSale);
//				if(specSale.equals("\"S\"")) {
					
//				}else {
					homesCount++;
//				}
				//U.log("home: "+home);
				homesInfo += home;
			}
			U.log("homes.size(): "+homes.size());
		}
		
		U.log("homesCount: "+homesCount);
		
		//================ Plans Data
		int plansCount = 0; 
		String plansInfo = ALLOW_BLANK;
				
		ArrayList<String> plans = (ArrayList<String>) plansDataMap.get(dudaUrl);
		if(plans != null) {
			for(String plan:plans) {
				plansInfo += plan;
			}
			U.log("plansCount: "+plans.size());
		}
				
		//================ Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String price [] = {ALLOW_BLANK,ALLOW_BLANK};
		
		price = U.getPrices(comJsonData+plansInfo+homesInfo, "\"PrHi\":\\d{6}|\"PrLo\":\\d{6}|\"PriceHi\":\"\\d{6}|\"PrLo\":\"\\d{6}", 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comJsonData+plansInfo+homesInfo, "[\\s\\w\\W]{30}478[\\s\\w\\W]{30}", 0));
		if(comUrl.equals("https://www.c-rock.com/houston-community-detail/Fairwater-147004")) minPrice = "$365990";
		
		//=========== SQFT
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String sqft[] = {ALLOW_BLANK,ALLOW_BLANK};
				
		sqft = U.getSqareFeet(comJsonData+plansInfo+homesInfo, "\"SftLo\":\\d{4}|\"SftHi\":\\d{4}", 0);
				
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homeData, "[\\s\\w\\W]{30}1720[\\s\\w\\W]{30}", 0));
		
		//=========== cType
		String description = U.getSectionValue(comJsonData, "\"Desc\":\"", "\",\"");
		String headline = U.getSectionValue(comJsonData, "\"MarketingHeadline\":\"", "\",");
		headline = headline.replace("Lakeside Master-Plan Community", "lakeside living Master-Plan Community");
		//U.log("description: "+description);
		
		String ctype=U.getCommType(description+headline);
		U.log("ctype: "+ctype);
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(description+headline, "[\\s\\w\\W]{30}golf[\\s\\w\\W]{30}", 0));
		
		//=========== pType
		String customAmeneties = U.getSectionValue(comJsonData, "\"CustomAmenities\":[", "\"DudaUrl\"");
		
		description = description.replace("luxury standard features", "luxury living standard features");
		
		String pType = U.getPropType(customAmeneties+description+plansInfo+homesInfo);
		U.log("pType: "+pType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(customAmeneties, "[\\s\\w\\W]{30}luxury[\\s\\w\\W]{30}", 0));
			
		//=========== dType
		
		String dType=U.getdCommType(description+plansInfo+homesInfo);
		U.log("dType: "+dType);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homesInfo, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));
		
		//=========== Status
		String status = ALLOW_BLANK;			
		comJsonData = comJsonData.replace("and available quick move-in homes", "")
				.replace("New lots are coming soon", "New lots coming soon")
				.replace("Coming Soon Winter '23", "Coming Soon Winter 23")
				.replace("Coming Soon December '22", "Coming Soon December 22")
				.replaceAll("quickly selling out with only one home|Addr\":\"Coming Soon|Directions\":\"Coming Soon|Address\":\"Coming Soon", "");
		
		status=U.getPropStatus(comJsonData);
				
		if(homesCount > 0) {
			if(status == ALLOW_BLANK)
				status = "Quick Move-Ins";
			else if(status != ALLOW_BLANK)
				status = status + ", Quick Move-Ins";	
		}
			
		status = status.replace("Coming Soon, Coming Soon Winter 23", "Coming Soon Winter 23")
				.replace("$0 Down Payment", "0 Down Payment");
		
		if(status.equals("Coming Soon, Coming Soon December 22")) status = "Coming Soon December 22";
		
		
		U.log("Status: "+status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comJsonData, "[\\s\\w\\W]{50}One Home Left[\\s\\w\\W]{30}", 0));
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				
		
		
		data.addCommunity(comName, comUrl, ctype);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(comJsonData));
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
				
		U.log("");
//	}
		i++;
	
	}
	
	public static void homesData(String region) throws IOException {
		
		String allHomesData = ALLOW_BLANK;
		
		String homesData = U.getHTML("https://www.c-rock.com/_dm/s/rt/actions/sites/069fba31/collections/"+ region +"%20Homes/ENGLISH");
		homesData = homesData.replace("\\\"", "\"");
		homesData = StringEscapeUtils.unescapeJava(homesData);
		homesData = homesData.replace("\"[", "[").replace("]\"", "]");
		//U.log("homesData: "+homesData.toString());
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/sa.txt", homesData.toString());
		
		JsonParser json = new JsonParser();
		JsonObject objHomes = (JsonObject)json.parse(homesData); 
	
		JsonArray homesArray = new JsonArray();		
		homesArray = (JsonArray)objHomes.getAsJsonArray("value");			//array of all homes in a region
		
		//U.log("objJsonCom: "+objJsonCom.toString());					
		FileUtil.writeAllText("/home/shatam-10/Desktop/data/austinhomes.txt", objHomes.toString());
		U.log("Homes count in "+region+" : "+homesArray.size());	
		
		for(int i=0; i<homesArray.size(); i++) {
			String homeJsonData = homesArray.get(i).toString();
			String dudaCommUrl = U.getSectionValue(homeJsonData, "\"DudaCommUrl\":\"", "\"");
			//U.log("dudaCommUrl: "+dudaCommUrl);
			
			homesDataMap.put(dudaCommUrl, homeJsonData);
		}
	}
	
	public static void plansData(String region) throws IOException {
		
		String allPlansData = ALLOW_BLANK;
		
		String plansData = U.getHTML("https://www.c-rock.com/_dm/s/rt/actions/sites/069fba31/collections/"+ region +"%20Plans/ENGLISH");
		plansData = plansData.replace("\\\"", "\"");
		plansData = StringEscapeUtils.unescapeJava(plansData);
		plansData = plansData.replace("\"[", "[").replace("]\"", "]");
		//U.log("plansData: "+plansData.toString());
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/austinplans.txt", plansData.toString());
		

		JsonParser json = new JsonParser();
		JsonObject objPlans = (JsonObject)json.parse(plansData); 
		
		JsonArray plansArray = new JsonArray();		
		plansArray = (JsonArray)objPlans.getAsJsonArray("value");			//array of all homes in a region
		
		//U.log("objJsonCom: "+objJsonCom.toString());					
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/houston.txt", objJsonCom.toString());
		U.log("Plans count in "+region+" : "+plansArray.size());	
		
		for(int i=0; i<plansArray.size(); i++) {
			String planJsonData = plansArray.get(i).toString();
			String dudaCommUrl = U.getSectionValue(planJsonData, "\"DudaCommUrl\":\"", "\"");
			//U.log("dudaCommUrl: "+dudaCommUrl);
			
			plansDataMap.put(dudaCommUrl, planJsonData);
		}
		
	}
		
		
}



