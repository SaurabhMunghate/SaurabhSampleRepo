/**
 * @author Rakesh Chaudhari
 * @date 12/08/2015
 * 
 */
package com.shatam.b_081_100;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.jetty.html.Break;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractIvoryHomes extends AbstractScrapper {
	int k = 0;
	static int dup = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractIvoryHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ivory Homes.csv", a.data().printAll());
		U.log(dup);

	}

	public ExtractIvoryHomes() throws Exception {
		super("Ivory Homes", "https://www.ivoryhomes.com/");
		LOGGER = new CommunityLogger("Ivory Homes");
	}
	

	
	public void innerProcess() throws Exception {
	U.setUpChromePath();
	driver = new ChromeDriver();
		int count = 0;
//		setProxy();
		
		String commpage = getHtml("https://ivoryhomes.com/location", driver);
		String mhtml=commpage;
		commpage = U.removeComments(commpage);
	  
/*
//		String sec[]=U.getValues(commpage, "</li> <li><a href=", "/a></li>");
		String sec[]=U.getValues(commpage, "<div class=\"col-sm-3 col-md-2 col-lg-2 col-xs-12\"><div class=\"boder-line\">", "</button></a>");//U.getValues(commpage, "<div class=\"box_property-new-loaction\">", "</div></a>");
		U.log("No. of community::"+sec.length);
		
		for (String subSec : sec) {
		//	U.log("subSec:::"+subSec);
			String url = U.getSectionValue(subSec, "href=\"", "\"");
			String CommName = U.getSectionValue(subSec, "<h4>", "</h4>");
//			U.log(CommName+ "  >>>>>>>>>>."+url);
			
			addDetails(url, CommName);
//			break;
		}*/

		String comUrlSec=U.getSectionValue(mhtml, "<option value=\"\" selected=\"\">Choose a Community</option>", "</select><button type=\"button\"");
		String sec[]=U.getValues(comUrlSec,"<option","option>");
		U.log("No. of community::"+sec.length);
		
		for (String subSec : sec) {
		//	U.log("subSec:::"+subSec);
//			String url = U.getSectionValue(subSec, "href=\"", "\"");
			String url = "https://www.ivoryhomes.com"+U.getSectionValue(subSec," value=\"","\">");
//			String CommName = U.getSectionValue(subSec, "<h4>", "</h4>");
			String CommName = U.getSectionValue(subSec, "\">", "</");
			U.log(CommName+ "  >>>>>>>>>>."+url);
			
			addDetails(url, CommName);
//			break;
		}

		driver.quit();
		
		LOGGER.DisposeLogger();
	}

	
	int m = 0;

	public static ArrayList<String> matchAll(String html, String expression,
			int groupNum) {

		Matcher m = Pattern.compile(expression, Pattern.CASE_INSENSITIVE)
				.matcher(html);

		ArrayList<String> list = new ArrayList<String>();

		while (m.find()) {

			list.add(m.group(groupNum));
		}
		return list;

	}

	//TODO :
	public void addDetails(String url, String commNamefromSec) throws Exception {
		//41
//		if(j>=25)
//		if(j>=21 && j<=30)
//			if(j>=62)
		 {
			 
//TODO:
		 if(!url.contains("community-details/cranefield-estates"))return;	 
		

	 
	 U.log("Page Url:  "+j+"  " + url);
	 
		
		if (url.contains("https://ivoryhomes.com/locations")||url.contains(" url "))
			return;
		if (url.contains("https://ivoryhomes.com/community_details/East+Side+SL+County&tab=fp/"))
			return;
		if (url.contains("https://ivoryhomes.com/community_details/Broadview+Shores+Cottages&tab=fp/") ) {
			LOGGER.AddCommunityUrl("**********Returned****************"+url);
			return;
		}
		if (url.contains("https://ivoryhomes.com/community_details/Garden+Park+Lakeside+Towns&tab=fp/")) {
			LOGGER.AddCommunityUrl("**********Returned****************"+url);
				return;
		}
		if (url.contains("https://ivoryhomes.com/community-details/bingham-court")) {
			LOGGER.AddCommunityUrl("**********Redirect****************"+url);
				return;
		}

		url = url.replace("\" target=\"_blank", "");

        if(data.communityUrlExists(url)){
        	LOGGER.AddCommunityUrl("**********REPEAT****************"+url);
            return;
        }
		LOGGER.AddCommunityUrl(url);
		
		
		String html = getHtml(url,driver);
	//	Thread.sleep(2000);
//		U.log("html:"+html);
		if(html==null)
		{
		File f = new File(U.getCache(url));
		f.delete();
			html = U.getHtml(url, driver);
		}
		
		String dumyUrl = url+"11";
		if(dumyUrl.contains("/juniper-estates"))dumyUrl="https://ivoryhomes.com/community-details/juniper-estates";
		dumyUrl =dumyUrl.replace("/11", "&tab=mh/");
		U.log(dumyUrl+"\n"+U.getCache(dumyUrl));
		String modelHtml = U.getHTML(dumyUrl);
		
	//	String commName = U.getSectionValue(html, "<title>", "</");
		String commName = U.getSectionValue(html, "<div class=\"title-1 text-white\">", "</div>");
		if(commName==null) {
			commName = commNamefromSec;
		}
		if (commName.length() == 0) {
			commName = ALLOW_BLANK;
		}
		commName=commName.replaceAll(" Cottage Homes| Villas|Garden Homes|Twin Homes|Patio Homes| Garden Villas$|Cottages$|Cottage$", "");
		String commType = ALLOW_BLANK, pType = ALLOW_BLANK, dPtype = ALLOW_BLANK, note = ALLOW_BLANK;
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK }, latlng = {
				ALLOW_BLANK, ALLOW_BLANK }, sqFt = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		int mmm = 0;

		html = html.replaceAll(
				"(estate homes, townhomes, condos and luxury homes)", "")
				.replaceAll("(including active adult)", "");
		commType = U.getCommunityType(html);

		note = U.getnote(html);
		String combineHtml = ALLOW_BLANK;
		html =html.replace(">Gallery</a></", "Map</a>");
		String sqftMax=ALLOW_BLANK;
		String communityID = U.getSectionValue(html, "id=\"communityID\" value=\"", "\"");
		
		/*
		 * Json Home Data Extraction
		 */
		//String homeDesignJsonURl = "https://ivoryhomes.com/Dynamic/homeDesignFetchData?page=1&community="+communityID;
		
		String homeDesignHtml = null;
		String homesData=ALLOW_BLANK;
	
		String [] homeDesign=U.getValues(html, "<div class=\"homeWrapper locate locAdj2\">", "</div></div></a>");
		for(String homeDes:homeDesign) {
			homesData+=" "+homeDes;
			String homeUrl=U.getSectionValue(homeDes, "<a href=\"","\">");
			homeDesignHtml+=U.getHTML(homeUrl);
		
		}
		//For more than one page
		
/*dd		
		for(int k =1; k <= 2; k++){
//			String homeDesignHtml = U.getHTML(homeDesignJsonURl);
			String homeDesignJsonUrl = "https://ivoryhomes.com/Dynamic/homeDesignFetchData?page="+k+"&community="+communityID;
			U.log("Home Design Url :"+homeDesignJsonUrl);
			String homeHtml = U.getHTML(homeDesignJsonUrl);
			
			if (homeHtml != null && !homeHtml.contains("\"des_id\":0}")) {
				homeDesignHtml += homeHtml;
				
				//U.log(homeHtml);
				String homesData[]=U.getValues(homeHtml, "{\"des_id\"", "\"design_tot_bed_finsih\":");
				for(String homesUrl : homesData){
					homesUrl = StringEscapeUtils.unescapeJson(U.getSectionValue(homesUrl, "\"des_url\":\"", "\""));
					homesUrl = homesUrl.replaceAll("-$|\\(|\\)", "");
					U.log("homesUrl : "+homesUrl);
					String mhtml = U.getHTML(homesUrl);
					combineHtml += U.getSectionValue(mhtml, "<div class=\"home-de-content scroll-me\">", "<div id=\"homedesignval\">");
					
				}
			}
		}//eof for
		*///dd
//		String moveInJsonURl = "https://ivoryhomes.com/Dynamic/moveInReadyFetchData?page=1&community="+communityID;
		//String moveDataHtml = null;
		int moveInCount = 0;int soldCount =0,newmovecount=0, nomoveIncnt=0;
		//For more than one page
/*		for(int k = 1; k <= 2; k++){
			
			String moveInJsonUrl = "https://ivoryhomes.com/Dynamic/moveInReadyFetchData?page="+k+"&community="+communityID;
			//String moveDataHtml=U.getHTML(moveInJsonURl);
			U.log("move url1 :"+moveInJsonUrl);
			String moveHtml=U.getHTML(moveInJsonUrl);
			if(moveHtml == null) continue;
			newmovecount = newmovecount + 1;
			moveDataHtml += moveHtml;
			String moveData[]=U.getValues(moveHtml, "{\"design_style\":\"", "is_workforce\"");
			moveInCount += moveData.length;
	//		String[] moveUrls = U.getValues(html, "<div id=\"mv-lt\">", "<div");
			U.log("Toatal move in Home : "+moveData.length);
			for(String moveUrl : moveData){
				if(moveUrl.contains("soldout.png\",\"sold_alt\":\"sold\""))moveInCount--;
				
				moveUrl = StringEscapeUtils.unescapeJson(U.getSectionValue(moveUrl, "\"url\":\"", "\""));
				U.log("moveUrl2 : "+moveUrl);
				String mhtml = U.getHTML(moveUrl);
				combineHtml += U.getSectionValue(mhtml, "overview-property\">", "Community</button>"); //U.getSectionValue(mhtml, "Close Menu</a>", "<div id=\"mvd-gall\">");
			}
		}
		*///junedd
		
		
		String moveDataHtml=ALLOW_BLANK;
		
		
		try {
	//	String moveValue[]= U.getValues(html, "<a href=\"https://ivoryhomes.com/moveready-detail/", "class=\"car-parking\" />");
		
		String moveInSec=U.getSectionValue(html, "<div class=\"row row-cols-1 row-cols-sm-1 row-cols-lg-2 row-cols-xl-3 overflow-hidden\" id=\"moveInReady\">", "<button type=\"button\" class=\"btn btnRed f-16\" id=\"allMoveInReady\" onclick=");	
	    String moveValue[]= U.getValues(moveInSec, "<div class=\"homeWrapper locate locAdj\">", "</a></div></div></div>");
		newmovecount=moveValue.length;
		soldCount= Util.matchAll(html,"<div class=\"box_property\">\\s*<div class=\"sold-img\">\\s*<img src=\"https://ivoryhomes.com/ui/img/soldout.png\"",0).size();
		U.log("moveValue.length= "+moveValue.length+"::::::::Sold= "+soldCount);
		for(String moveInHome:moveValue) {
			moveInCount++;
//			U.log("moveInHome==="+moveInHome);
			if(moveInHome.contains("Sale Pending")) {
				nomoveIncnt++;
			}
			String mvInUrl=U.getSectionValue(moveInHome, "href=\"", "\">");
			U.log("mvInUrl== "+mvInUrl);
//			String moveDataHtml=U.getHTML(mvInUrl);
			moveDataHtml+=" "+U.getHTML(mvInUrl);
		
		}
		
		}catch (Exception e) {
			// TODO: handle exception
		}

		
		
		
		
		
		
//		U.log(Util.matchAll(html,"<div class=\"box_property\">\\s*<div class=\"sold-img\">",0)+":::::this is sold count");
		//==========================================
		
		String latLngSection = U.getSectionValue(html, "www.google.com/maps/@", "/");
//		String latLngSection = U.getSectionValue(html, "1&amp;destination=", "/");

		
		U.log(">>>>>>>>>>11111"+latLngSection);
		if(latLngSection == null) {
//			latLngSection = U.getSectionValue(html, "href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\" class=\"");
			latLngSection = U.getSectionValue(html, "href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "target=\"_blank\">");

		}			
		U.log(">>>>>>>>>>"+latLngSection);
		if(latLngSection!=null)
		{
			latlng = latLngSection.split(",");
			if (latlng[0].length() > 2) {
				if (latlng[0].trim().startsWith("-")) {
					String temp=latlng[0].trim();
					latlng[0] = latlng[1].trim();
					latlng[1] = temp;
				}else {
					latlng[0] = latlng[0].trim();
					latlng[1] = latlng[1].trim();
				}
			} else {
				latlng[0] = ALLOW_BLANK;
				latlng[1] = ALLOW_BLANK;
			}
		}
		
	U.log("latlng[0]==="+latlng[0]+":::::::::::"+"latlng[1]====="+latlng[1]);
	String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
	
//	String ad = U.getSectionValue(html, "class=\"map_links\" target=\"_blank\">", "</p>");
	html = html.replace("class=\"map_links\"", "class=\"map_linksother\"").replaceAll("forDevLogin\" style=\"\\s*\" target=\"_blank\">", "");

	String ad ="f";
	
	ad= U.getSectionValue(html, "class=\"map_linksother\" target=\"_blank\">", "</p>");
	if(ad==null)
		ad=U.getSectionValue(html, "src=\"https://ivoryhomes.com/public/assets/images/locationLg.png\" alt=\"Image\" />", "</p>");


	
	 U.log("ad::::"+ad.length());
	 
	 U.log("ad::::"+ad);
	
	 
	 if (ad != null) {
		 	ad=ad.replace("10987 S. Gresham Dr. South Jordan, UT 84009, South Jordan, Utah.", "10987 S. Gresham Dr., South Jordan, UT 84009").replace("UT 84009,South Jordan, Utah.", "UT 84009");
			ad=ad.replace("UT,", "UT").replace("Utah.","UT").replace("</a>", "").replace("lehi,								Lehi,", " Lehi,").replace(", lehi,Lehi,", ",Lehi,").replace("lehi, Lehi", " Lehi").replace(",,", ",").replace("8000 S, 6700 W", "8107 S 6700 W")
					.replaceAll("<.*?>", "");
			
			String a[] = ad.split(",");
			U.log(ad);
			add[0]=a[0].trim();
			if(add[0]!=null){
				add[0] = add[0].replaceAll("<a target=\"(.*?)\">", "");
			}
			if(add[1]!=null && add[1].length()>3)
			add[1]=a[1].trim();
			if(add[2]!=null && add[2].length()>3)
			add[2]=a[2].trim();
			if (Util.match(add[2], "\\d{5}")!=null) {
				add[3]=Util.match(add[2], "\\d{5}");
				add[2]=add[2].replaceAll("\\d{5}", "");
			}
			if(add[1]==ALLOW_BLANK && ad!=null) {
				add = U.getAddress(ad);
			}
		}
	 
	 
	 U.log("Address is " + Arrays.toString(add));
	 if(add[0]!=null && add[1]!=null && add[2]!=null && add[3]==ALLOW_BLANK)
	 {
		 add[3]=U.getAddressGoogleApi(latlng)[3];
		 geo = "TRUE";
	 }
	 
	
		if (add[2] == ALLOW_BLANK || add[1].length()==0 || add[0] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latlng);
			if(addr == null) addr = U.getGoogleAddressWithKey(latlng);
			if(addr == null) addr = U.getAddressHereApi(latlng);
			
			
			if(add[0] == ALLOW_BLANK) add[0] = addr[0];
			if(add[1] == ALLOW_BLANK) add[1] = addr[1];
			if(add[2] == ALLOW_BLANK) add[2] = addr[2]; 
			if(add[3] == ALLOW_BLANK) add[3] = addr[3];
//			add = addr;
			U.log(":::::::::::::::"+add[3]);
			geo = "TRUE";
		}
		
		
		if(add[2].length()>1 && latlng[0].length()<4) {
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			geo="TRUE";
		}

		
		if(url.contains("https://ivoryhomes.com/community-details/sagewood-village-collection"))
		{
			add[3]="84074";
			geo="TRUE";
			
		}
		if(url.contains("https://ivoryhomes.com/community_details/Newport+Village&amp;tab=fp/")){
			//newport
			add[0]="100 S 920 W St";
			add[1]="Spanish Fork";
			add[2]="UT";
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getGoogleAddressWithKey(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			geo="TRUE";
		}

		if(url.contains("https://ivoryhomes.com/community_details/Tuscan+Estates&amp;tab=fp/")){
			//newport
			add[0]="1406 E 5550 S";
			add[1]="South Ogden";
			add[2]="UT";
			add[3]="84403";
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		
		if(url.contains("https://ivoryhomes.com/community_details/Park+Vista&amp;tab=fp/")){
			//newport
			add[0]="7088 Harding Dr S";
			add[1]="West Valley City";
			add[2]="UT";
			add[3]="84128";
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		//Model Homes
		String modelHomesHtml=ALLOW_BLANK;
		if(url.contains("/Hidden+Valley+Estates&tab=fp/")){
			String modelHomesHtmlSec=U.getSectionValue(html, "Model Home</h4>", "VIEW FLOOR PLAN");
//		U.log("modelHomesHtmlSec====="+modelHomesHtmlSec);
			if(modelHomesHtmlSec!=null)
		 modelHomesHtml=U.getHtml(U.getSectionValue(modelHomesHtmlSec, "href=\"", "\""), driver);
		}	
		
		
		
		if(url.contains("community-details/hyde-point")||url.contains("community-details/cloverleaf-fields")){
			String modelHomesHtmlSec=U.getSectionValue(html, "</tbody>", "View Floor Plan</button>");
//		U.log("modelHomesHtmlSec====="+modelHomesHtmlSec);
			if(modelHomesHtmlSec!=null)
		 modelHomesHtml=U.getHtml(U.getSectionValue(modelHomesHtmlSec, "<a href=\"", "\""), driver);
		}
		
		String modelHomesSec=ALLOW_BLANK;
		modelHomesSec=U.getSectionValue(html, "Model Home Hours</div>", "View Floor Plan");
		if(modelHomesSec!=null) {
			modelHomesHtml=U.getHtml(U.getSectionValue(modelHomesSec, "<a href=\"", "\""), driver);
		}
		
		
		
		// Price Section Here...

		
		
		
		
		String headrPriceSection = U.getSectionValue(html,
				"<div class=\"col-sm-12 text-center overview-property\">", "call-button-click\"");
		
//		U.getSectionValue(html, "<h6 class=\"title-4 mb-2\">", "");

		if (headrPriceSection != null) {
			headrPriceSection = headrPriceSection.replace("'s", ",000MyPrice");
		}
		//U.log(headrPriceSection);

		String sectionOver = U
				.getSectionValue(html, "class=\"hotel-detail-overview\">",
						"<h1 class=\"sub-tittle\">");
		
		if (sectionOver != null) {
			sectionOver = sectionOver.replace("0's", "0,000MyPrice");
			sectionOver = sectionOver.replace("0s", "0,000");
		}
		
			//Prices from move ready page
		
		
		//U.log(Util.match(combineHtml, ".*?645,000"));
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html =html.replace("$200k", "$200,000").replaceAll("0s|0's|0's", "0,000");
		html=html.replace("$500’s", "$500,000");
		html=html.replace("300's", "300,000");
		
		String price[] = U.getPrices((headrPriceSection + combineHtml
				+ sectionOver+html+homeDesignHtml+modelHomesHtml+moveDataHtml).replace("$ 450,000 - 550,000", "$ 450,000 - $550,000"), 
				"\\$ \\de{3},\\d{3} - \\$\\d{3},\\d{3}|\\$ \\d{3},\\d{3}|\\$ \\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|<span>From</span> \\$\\s?\\d{3},\\d{3} - To \\$\\s?\\d{1},\\d{3},\\d{3}|<span>From</span> \\$\\s?\\d{3},\\d{3} - To \\$\\s?\\d{3},\\d{3}|<span>From</span> \\$ \\d{3},\\d{3}</button>|From</span> \\$ \\d,\\d{3},\\d{3}</button>|<h3 class=\"price_Value\">\\$\\d,\\d{3},\\d{3}</h3>|price_Value\">\\$\\d,\\d{3},\\d{3}|From</span> \\$\\d,\\d{3},\\d{3}|price_Value\">\\$\\d{3},\\d{3}|span>From</span> \\$\\d{3},\\d{3}</button>|span>From</span> \\$ \\d{3},\\s{3}</button>|\"price\":\"\\$\\d{3},\\d{3}\"|<li> \\$\\d,\\d{3},\\d+</li>|price_tag\">\\s+\\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|starting in the high \\d{3},\\d{3}|start in the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</li>|\\$\\d+,\\d+</td>|\\$\\d{3},\\d{3}MyPrice|\\$\\d{3,}</td>|upper \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}", 0);
//		U.log("KKKKKKKKKK"+Util.matchAll((headrPriceSection + combineHtml
//				+ sectionOver+html+homeDesignHtml+modelHomesHtml+moveDataHtml), "[\\w\\s\\W]{30}580,000[\\w\\s\\W]{30}", 0));

		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

		U.log(minPrice+"\t"+maxPrice);
		
		String minSqft = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
		combineHtml = combineHtml.replace("4393", "");
		
		
//combineHtml
		sqFt = U.getSqareFeet(html+modelHomesHtml+homeDesignHtml+moveDataHtml+modelHomesHtml, 
				"\\d{4} Square Feet|TOTAL SQ.FT</p><span>\\d+</span>|\\d{1},\\d{3}-\\d{1},\\d{3} sq. ft|ranging from \\d,\\d{3} - \\d,\\d{3} sq. ft.|lot_total_sqft\":\"\\d{3}\"|\\d{4} Total|\\d{4}\\s*Total|up to \\d{4} square feet|<p>TOTAL SQ.FT</p>\\s*<h4>\\d{4} </h4|TOTAL SQ.FT</p><span>\\d{4}", 0);

		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		
//		U.log("modelHomesHtml====\n"+modelHomesHtml);
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((modelHomesHtml),"[\\s\\w\\W]{30}3011[\\s\\w\\W]{30}", 0));

		U.log(minSqft+"\t"+maxSqFt);
		
		//========== Combined Home Htmls ==================
		String combineHomeHtmls = null;
		int x = 0;
		String homeSection = U.getSectionValue(html, "<section class=\"container-fluid\">", "</section>");
		if(homeSection != null){
			String [] homeUrlSection = U.getValues(homeSection, "<div class=\"max-ht-hd\" id=\"mv-lt\">", "</div>");
			for(String homeUrlSec : homeUrlSection){
				String homeUrl = U.getSectionValue(homeUrlSec, "<a href=\"", "\">");
				String homeHtml = U.getHTML(homeUrl);
				U.log("homeUrl::"+homeUrl);
				combineHomeHtmls += U.getSectionValue(homeHtml, "<div class=\"cm-dt\">", "</div>");
				if(x ==6)break;
				x++;
			}
		}
		
		
		//========= Property Status ================
		
		String section = U.getSectionValue(html, "id=\"community\">", "</section>");
//		U.log(section);
		if(section == null) section = ALLOW_BLANK;
		section = section.replace("lots are already selling quickly", "lots selling quickly")
				.replace("Evergreen Farms are selling so quickly", "Evergreen Farms are selling quickly")
				.replace("Phase 6 of this community has just been released", "Phase 6 just released")
				.replace(" release eight new lots in the final phase", "eight New Lots Released in Final Phase")
				.replace("Just released: Phase 3 ", "Phase 3 Just released")
				.replace("Just Released: Final phase", "Final phase Just Released")
				.replace("Nine large lots are available", "Nine large lots available")
				.replace("Just released: four lots", "four lots Just released ")
				.replace("released with 25 new lots", "25 new lots released")
				.replaceAll("8 large new signature home lots just released|Just released: 8 large lots", "8 large lots just released").replace("Just Released: 32 lots", "32 lots Just Released").replace("Just Released: 40 large lots", "40 large lots just released:").replace("lots range from 13,000-16,000 sq. ft. and are selling fast", "lots selling fast");
		
		
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((section),"[\\s\\w\\W]{30}selling so quickly[\\s\\w\\W]{30}", 0));

		String propStatus = U.getPropStatus(section.replace("selling so quickly!", "selling quickly")
				.replace("Just released: Phase 3", "Phase 3 just released")
				.replace("Just Released: 32 lots", "32 lots just released")
				.replace("Just Released: Final phase", "final phase just released").replace("Nine large lots are available", "Nine large lots available").replaceAll("Just released: four lots", "Four lots just released"));

		//dtjune
		propStatus=propStatus.replace("Move-In Ready Homes, |, Move-In Ready Homes|Move-In Ready Homes", "");
		
		
		
		html=html.replaceAll("gallery clearfix pull-center\">\\s+No Results to Display", "");
		U.log("moveInCount=="+moveInCount);
//	if (moveInCount > 0) {
		if(moveInCount>nomoveIncnt) {
			if(propStatus == ALLOW_BLANK) propStatus = "Move-In Ready Homes";
			else propStatus = propStatus +", Move-In Ready Homes";
		}	
	
	U.log("propStatus===="+propStatus);

		//U.log(html);
		// Property Type
		html=html.replaceAll("and no HOA fees|Custom Homes&lt;/option|Apartment equity|Custom Homes</option>", "");  //|Cottage/\">|Piedmont Cottage
		html=html.replace("and multi-level vanity", "").replace("Colonial, Victorian and Craftsman", "Colonial, Victorian and Craftsman style homes")
				.replace("Craftsman</p>", "Craftsman style homes</h3>").replace("3000 Colonial ", "including Colonial");
		html =html.replaceAll("luxury, lakeside townhome|offering luxury |luxury package featuring", " luxury home")
				.replace(" luxurious, lakeside townhome", " luxury homes, lakeside townhome")
				.replace("detached casita", "detached home casita").replaceAll("StyleThe Colonial|&nbsp;The Colonial</p>|2200 Craftsman|Heather Craftsman|Chadwick Craftsman", "Craftsman-style home").replaceAll("Hartford Colonial|2000 Colonial 2|The Poplar Colonial", "The Colonial");
		
		
		//=====================================================================================================
	//	U.log("::::::::::::::::::::::;"+Util.matchAll(combineHtml + html , "[\\w\\s\\W]{30}villa[\\w\\s\\W]{30}", 0));
//homesData+homeDesignHtml june
		pType = U.getPropType((combineHtml + html+moveDataHtml+homesData+homeDesignHtml).replaceAll("<option value=\"Custom Homes\">Custom Homes</option>|<option value=\"Custom Homes\">", "").replace("new homes being built here are custom", "Custom Homes").replaceAll("VILLAGE|village|Village", "").replace("estate home lots", "Estate Style Living home lots")
				.replace("new homes being built here are custom and pristine", "new homes being built here are a custom-quality and pristine")
				.replaceAll("Occupational Therapy|Charleston Traditional|Sequoia (Traditional)", "Traditional exterior")
				.replaceAll("<option value=\"Custom Homes\">Custom Homes</option>|no HOA|courtyard garage|is a luxury rambler|Oakmont exudes luxury and space|Bask in the luxury of a gourmet|you'd expect in a luxury home|a luxury owner's bedroom|desire in a luxury home|living with a luxury owner's bedroom|you could desire in a luxury home!|A luxurious master suite provides|you'd expect in a luxury home|Bask in the luxury of a gourmet|the Oakmont exudes luxury|living with a luxury owner's suite.|San Marino Craftsman Overview|San Marino Craftsman|San_Marino_Craftsman-page-003", ""));
		combineHtml = combineHtml.replaceAll("This single story plan has a beautiful", "");
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(combineHtml+ html+moveDataHtml , "[\\s\\w\\W]{100}Custom Homes[\\s\\w\\W]{100}", 0));

		
		
		if( html.contains("Traditional") && !pType.contains("Traditional")) {
			if(pType.length()<2)
				pType="Traditional Homes";
			else
				pType=pType+", Traditional Homes";
		}
//		if( html.contains("Farmhouse")) {
//			if(pType.length()<2)
//				pType="Farmhouse Style Homes";
//			else
//				pType=pType+", Farmhouse Style Homes";
//		}
		U.log("pType::::::::::::::;;;;;"+pType);
		
		//============================================== Derived Propery Type==================================
		if(combineHtml != null)
			combineHtml = combineHtml.replace("Rambler</h5>|rambler home|Rambler", "Rancher Series");
		html = html.replace("Rambler</h5>|Rambler</span>|Rambler</h5>|rambler home|Rambler", "Rancher Series");
		
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((combineHtml+combineHomeHtmls + html+moveDataHtml),"[\\s\\w\\W]{30}Rancher Series[\\s\\w\\W]{30}", 0));

		
		dPtype = U.getdCommType((combineHtml+combineHomeHtmls + html+moveDataHtml+homesData+homeDesignHtml+modelHomesHtml)
				.replace("Rambler</h5>", "Rancher Series")
				.replaceAll("alt=\"Multi Level|New Haven Colonial|New Haven Colonial Overview|new-haven-colonial|Ranch Rd|Ranches Academy|Branch|branch|Ranches Pkwy|Branch|Ranches Academy|A luxurious master suite provides options for a grand|Ranches P|single level|Single Level|floor|Floor|multi-level vanity", ""));
		U.log("dPtype::::::::::::::;;;;;"+dPtype);

//		if(url.contains("https://www.ivoryhomes.com//community-details/christensen-farm")) {dPtype="Ranch"; minSqft="5682"; }
//		if(url.contains("/park-city-heights-homesteads"))dPtype="Ranch";
//		if(url.contains("/cranefield-estates")||url.contains("/big-willow-creek-estates")||url.contains("/monte-bella")||url.contains("/whisper-creek-hollow")||url.contains("/ivory-ridge-park-estates"))dPtype=dPtype+", Ranch";
//		if(url.contains("/the-terraces-at-green-springs"))pType=pType+", Custom Home";
		//if(url.contains("/park-city-heights-homesteads"))pType=pType+", Custom Home";
		// Note Is here..
		note = U.getnote(combineHtml + html);

		// Community Type
		
		commType = U.getCommType(html+modelHtml);
		
//		if(url.contains("https://ivoryhomes.com/community-details/east-orchard") )propStatus="No Move-In Ready Homes";
		//if(url.contains("https://ivoryhomes.com/community-details/garden-park-lakeside")) {dPtype="Colonial";}
//		if(url.contains("https://ivoryhomes.com/community-details/the-terraces-at-green-springs")) {dPtype="Ranch";pType=pType+", Patio Homes";}


           if(sqftMax!=ALLOW_BLANK){
	          maxSqFt=sqftMax;
             }


add[0]=add[0].replaceAll("\\([0-9 a-zA-z]*\\)","");
add[0]=add[0].replaceAll("&amp; ","And ");


if(add[3]==ALLOW_BLANK || add[3]==null) {
	try {
	add=U.getAddressGoogleApi(latlng);
	}catch (Exception e) {
		if(add == null) add = U.getGoogleAddressWithKey(latlng);
	}
	
	geo="TRUE";
}
//if(url.contains("https://ivoryhomes.com/community-details/garden-park-daybreak-condos")) {
//		add[0]="11181 S Oakmond Rd";
//      add[1]="South Jordan";
//		add[2]="UT";
//		add[3]="84009";
//		geo="TRUE";
//		latlng=U.getlatlongGoogleApi(add);
//		
//		if(latlng  == null) latlng = U.getGoogleLatLngWithKey(add);
//}

if(propStatus.contains(" Just Released") && propStatus.contains(", Just Released"))
	propStatus = propStatus.replaceAll(", Just Released", "");


	if(combineHtml!=null) {
		
		if(combineHtml.contains("Craftsman Overview") && !pType.contains("Craftsman")){
			if(pType.length() < 2) pType = "Craftsman-Style Homes";
			else pType += ", Craftsman-Style Homes";
		}
		
		if(combineHtml.contains("Farmhouse Overview") && !pType.contains("Farmhouse")){
			if(pType.length() < 2) pType = "Farmhouse-Style Homes";
			else pType += ", Farmhouse-Style Homes";
			
		}
			
	}
if(url.contains("https://ivoryhomes.com/community-details/escondido")) {
	pType+=", Traditional Homes, Luxury Homes, Villas";
	dPtype="2 Story";
}

U.log("pType::::::::::::::;;;;;"+pType);
if(url.contains("https://www.ivoryhomes.com//community-details/haven-parkway-collection"))maxPrice="$675,000";

if(url.contains("https://ivoryhomes.com/community-details/gabler-s-grove-cottages")) maxPrice = ALLOW_BLANK;

if(url.contains("community-details/marina-village-at-daybreak")) propStatus=propStatus.replace("Just Released, Final Phase,", "Final Phase Just Released, ");

	if(url.contains("https://ivoryhomes.com/community-details/juniper-estates")) propStatus=propStatus.replace("Final Phase Just Released, Final Phase", "Final Phase Just Released");
	if(url.contains("https://ivoryhomes.com/community-details/christensen-farm"))minSqft = "5682";
	if(url.contains("community-details/christensen-farm")) {
		if(propStatus.contains("Just Released, Five Large Lots Just Released"))
			propStatus=propStatus.replace(propStatus, "Five Large Lots Just Released");
		
	}



		data.addCommunity(commName, url, commType);
		data.addAddress(U.getNoHtml(add[0].replace("@", "")), U.getNoHtml(add[1]), U.getNoHtml(add[2].trim()), add[3]);
		data.addSquareFeet(minSqft, maxSqFt);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPropertyType(pType, dPtype);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
			}
		j++;

	 }

	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		


		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(1000);
					/*
					 * ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					 * Thread.sleep(5000); U.log("Current URL:::" + driver.getCurrentUrl());
					 * ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					 * Thread.sleep(5000); U.log("Current URL:::" + driver.getCurrentUrl());
					 * ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					 * U.log("Current URL:::" + driver.getCurrentUrl()); ((JavascriptExecutor)
					 * driver).executeScript("window.scrollBy(0,400)", ""); Thread.sleep(5000);
					 * U.log("Current URL:::" + driver.getCurrentUrl()); ((JavascriptExecutor)
					 * driver).executeScript("window.scrollBy(0,400)", ""); Thread.sleep(2000);
					 * ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					 * Thread.sleep(5000); U.log("Current URL:::" + driver.getCurrentUrl());
					 * ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					 * Thread.sleep(2000); ((JavascriptExecutor)
					 * driver).executeScript("window.scrollBy(0,400)", ""); Thread.sleep(5000);
					 * U.log("Current URL:::" + driver.getCurrentUrl()); ((JavascriptExecutor)
					 * driver).executeScript("window.scrollBy(0,400)", "");
					 */
					
//					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					if(isElementPresent(By.className("btn btnRed f-16"))) {
						driver.findElement(By.className("btn btnRed f-16")).click();
						U.log("::::::::::::::Cilck Success:::::::::::::");
					}
					if(isElementPresent(By.className("btn btnRed f-16"))) {
						driver.findElement(By.className("btn btnRed f-16")).click();
						U.log("::::::::::::::Cilck Success:::::::::::::");
					}
//					if(isElementPresent(By.name("View All"))) {
//						driver.findElement(By.name("View All")).click();
//						U.log("::::::::::::::Cilck Success:::::::::::::");
//					}
//					driver.findelement (by.name(“password”).click();


//					(by.class.name(“View All”)).click();

					
					
					Thread.sleep(10000);
					html = driver.getPageSource();

//					Thread.sleep(5000);
					Thread.sleep(10000);

					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

	private static boolean isElementPresent(By className) {
		// TODO Auto-generated method stub
		return false;
	}
}