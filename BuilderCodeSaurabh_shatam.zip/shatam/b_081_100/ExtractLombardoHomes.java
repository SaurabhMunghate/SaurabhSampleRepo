/**
 * @author Parag Humane 
 * @date 16/04/2012
 * 
 */
package com.shatam.b_081_100;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLombardoHomes extends AbstractScrapper {
	static int dup=0;
	CommunityLogger LOGGER;
	
	WebDriver driver = null;
	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new ExtractLombardoHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Lombardo Homes.csv", a.data()
				.printAll());
//		U.log(dup);
	}

	public ExtractLombardoHomes() throws Exception {

		super("Lombardo Homes", "https://www.lombardohomes.com/");
		LOGGER = new CommunityLogger("Lombardo Homes");
	}

	public void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHTML("https://lombardohomes.com/");
		String StateMIjson = U.getHTML("https://lombardohomes.com/wp-admin/admin-ajax.php?action=fetch_communities&page=1&state=MI&city=&communityId=&school=&sqftMin=1200&sqftMax=5500&priceMin=150000&priceMax=750000&modelAvailable=false&priceFilterToggle=&county=");
		String StateMOjson = U.getHTML("https://lombardohomes.com/wp-admin/admin-ajax.php?action=fetch_communities&page=1&state=MO&city=&communityId=&school=&sqftMin=1200&sqftMax=5500&priceMin=150000&priceMax=750000&modelAvailable=false&priceFilterToggle=&county=");
		String dataMI[] = U.getValues(StateMIjson, "{\"ID\"", "\"limited\":false}");
		String dataMO[] = U.getValues(StateMOjson, "{\"ID\"", "\"limited\":false}");

		U.log(StateMOjson);
		String comurls[]=U.getValues(html, "/lombardohomes.com\\/community\\", "\\/&quot;");
		for(String comurl:comurls) {
			String url="https://lombardohomes.com/community"+comurl;
			String comhtml=U.getHtml(url,driver);
			String stateSec ="";
			for(String data: dataMI) {
				if(data.contains(comurl)) {
					stateSec = data;
				}
			}
			for(String data: dataMO) {
				if(data.contains(comurl)) {
					stateSec = data;
				}
			}
			U.log(url);
			addDetails(url, "", comhtml, stateSec);
		}
		
		
		driver.quit();
		LOGGER.DisposeLogger();
	}
//		String stateLinksSec = U.getSectionValue(html,"<section class=\"mm-graphics block-section--small\">", "</section>");
//		String[] stateLinks = U.getValues(stateLinksSec, "<a href=\"","\"");
//		U.log(Arrays.toString(stateLinks));
//		for (String stateLink : stateLinks) {
//			String stateLinkHtml = U.getHtml(stateLink,driver);
////			String section = U.getHtmlSection(stateLinkHtml,"<div class=\"row listing-template--row block-section\">", "View Community");
////			U.log(section);
//			String comm[] = U.getValues(stateLinkHtml,"<div class=\"row listing-template--row block-section\">", "View Community");
//			ArrayList<String> links = new ArrayList<String>();
//			String url, name;
//			U.log(comm.length);
//			for (String item : comm) {
//				if (!links.contains(item)) {
//					url = U.getSectionValue(item, "href=\"", "\"");
//					name = U.getNoHtml(Util.match(item, "/\">.*</a></h2>")).replace("/\">", "");
//					addDetails(url, name,item);
//					// ;
//				}
//			}
//		}
//		addDetails("https://lombardohomes.com/new-homes-in-st-louis/winterbrooke-nature-series/", "WINTERBROOKE ESTATES","");
//		addDetails("https://lombardohomes.com/new-homes-in-michigan/wayne-county-canton-sheldon-estates/","SHELDON ESTATES" ,"");
//		addDetails("https://lombardohomes.com/new-homes-in-st-louis/cranbrook-custom-homes-camelot/", "CRANBROOK","");


		// Code to Extract Data of Apartment Communities in Michigan
		
//		String apartmentLink = U.getSectionValue(html,"-custom menu-item-19342\"><a href=\"", "/\">");
//		if(apartmentLink == null) {
//			
//		if(apartmentLink.contains("https://lombardohomes.com/new-homes-in-st-louis/cranbrook-custom-homes-camelot/"))return;
//			
//		String apartmentHtml = U.getHTML(apartmentLink);
//		String[] apartCommSecs = U.getValues(apartmentHtml,"<img class=\"alignleft wp-image-", ".com</a>");
//		for (String apartCommSec : apartCommSecs) {
//			addApartDetails(apartCommSec);
//			// break;
//		}
//		}
		
		


	
	//TODO :
	int i = 0;
	private void addDetails(String url, String commName, String comsec, String stateData) throws Exception {
	//	if(!url.contains("https://lombardohomes.com/community/anywhere-lombardo-michigan"))return;
//		if(i>=35)
		{
		U.log(i+" PAGE :" + url);
		
		if(url.contains("https://lombardohomes.com/new-homes-in-michigan/build-on-your-lot") || url.contains("https://lombardohomes.com/new-homes-in-st-louis/cranbrook-custom-homes-camelot/")
				)return;
//		|| url.contains("https://lombardohomes.com/community/anywhere-lombardo/")
		
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"::::::::::::::repeated::::::::::");
			return;
		}
//		if(url.equals("https://lombardohomes.com/community/anywhere-lombardo-st-louis-county") || url.equals("https://lombardohomes.com/community/anywhere-lombardo")) {
//			LOGGER.AddCommunityUrl(url+"::::::::::::::Not present in region page::::::::::");
//			return;
//		}
		LOGGER.AddCommunityUrl(url);
   //U.log("comSec:: "+comsec);
		
		commName=U.getSectionValue(comsec, "<h1>", "</h1>");
		
		commName=commName.replace(" &#8211; ", "-");
		commName=commName.replace("Anywhere Lombardo – Columbia","Anywhere - Lombardo Columbia");
		commName=commName.replace("Anywhere Lombardo – Michigan","Anywhere Lombardo - Michigan");
		
		String tempCommName=ALLOW_BLANK;
		tempCommName=commName;
//		U.log("=========="+comsec);
		String html = U.getHtml(url,driver);
		U.log(">>>>"+U.getCache(url));

		
		String commName1=U.getSectionValue(html,"aria-current=\"page\">","<");
		
//		U.log("=========="+Util.matchAll(comsec, "now open", 0));
		
		html = U.removeSectionValue(html, "<head>", "</head>");
		// =============== Address==================
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		
		//-------Community Address-------------
		String addressSec = ALLOW_BLANK;
		String comAddSec = U.getSectionValue(html,"<h4>Community Info</h4>","</a>");
		String salesAddSec=U.getSectionValue(html, "<h4>Sales Office</h4>", "</a>");
		
		//----------Sales office address----------
		if(comAddSec !=null)
		{
			addressSec = comAddSec; //comAddress
//			U.log("if section comAddSec : "+comAddSec);
		}
		else{
			addressSec = salesAddSec; //salesAddress
			U.log("else salesAddSec : "+salesAddSec);
		}
//		U.log("addressSec : "+addressSec);
		if(addressSec!=null) {
			
		String addressSec1 = U.getSectionValue(addressSec, "<address>", "</address>");
		addressSec1 = U.getNoHtml(addressSec1).replace("Drive, Suite", "Drive Suite");
		addressSec1 = addressSec1.replaceAll("Your Location,", "");
		String[] addr = addressSec1.split(",");
		try {
		add[0] = addr[0].trim();
		add[1] = addr[1].trim();
		String[] stateZip = addr[2].trim().split(" ");
		add[2] = stateZip[0];
		
		add[3] = stateZip[1];
		}catch (Exception e) {
			// TODO: handle exception
		}
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"
				+ add[3]);
		}
		// ============Lat & Lng===============
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		// String latlngs[] = { ALLOW_BLANK, ALLOW_BLANK };

		// LatLng Section
		String comLatLngSection = U.getSectionValue(addressSec,
				"<a href=\"", ">");
		// /
		if(comLatLngSection!=null)
		{
			//U.log("comlatLngSection :  " + comLatLngSection);
		String lat = Util.match(comLatLngSection, "(@)(sll=)?\\d{2}\\.\\d{5,}");
		if(lat==null) {
			lat=Util.match(comLatLngSection, "(=en&ll=)?\\d{2}\\.\\d{5,}");
			if(lat!=null)
			lat=Util.match(lat, "\\d{2}\\.\\d{5,}");
		}
		String lng = Util.match(comLatLngSection, "-\\d{2}\\.\\d{5,}");
		if(lng==null) {
			lat =U.getSectionValue(comsec, "data-map-lat=\"", "\"");
			lng =U.getSectionValue(comsec, "data-map-lng=\"", "\"");

		}
		U.log("Lat:::: " + lat);
		U.log("Lng:::: " + lng);
		if(lat == null) {
			comLatLngSection = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");
			if(comLatLngSection!=null) {
			comLatLngSection = U.getSectionValue(comLatLngSection, "@", ",17z");
			U.log("latlng::::"+comLatLngSection);
			if(comLatLngSection!=null) {
				latLong = comLatLngSection.split(",");
				lat = latLong[0] ;
				lng=latLong[1] ;
				}
			}
		}

		latLong[0] = (lat == null) ? ALLOW_BLANK : lat;
		latLong[1] = (lng == null) ? ALLOW_BLANK : lng;

		latLong[0] = latLong[0].replace("sll=", "");
		latLong[1] = latLong[1].replace("sll=", "");
		latLong[0] = latLong[0].replace("@", "");
		}
		U.log("My LatLng : " + latLong[0] + "        Lng : " + latLong[1]);

		
		//--------consider sale office lat lng when com lat-lng & address is not present
		String salesLatLng= U.getSectionValue(addressSec, "<a href=\"", ">");
		U.log("salesLatLng : "+salesLatLng);
		
		if(comAddSec == null && comLatLngSection == null){
			if(salesLatLng != null){
				String tempLatlng = Util.match(salesLatLng, "/@(.*?),\\d{2}[a-z]*/data",1);
				if(tempLatlng!=null)
				latLong = tempLatlng.split(",");
			}
			U.log("Sales:  Lat : " + latLong[0] + "        Lng : " + latLong[1]);
		}
		
		
//		if(url.contains("http://lombardohomes.com/new-homes-in-michigan/wayne-county-flat-rock-falkirk/")){
//			latLong[0] = "42.0946194";
//			latLong[1] = "-83.3453592";
//			geo = "TRUE";
//		}
		String note=ALLOW_BLANK;
		if(url.equals("https://lombardohomes.com/community/anywhere-lombardo")){
			commName="Anywhere Lombardo - St. Charles County";
			add = "111 Downview Drive,O�Fallon,MO,63368".split(",");
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null)
				latLong = U.getlatlongHereApi(add);
			note="Address Is Taken From Sales Office";
			geo = "TRUE";
		}
		if(url.equals("https://lombardohomes.com/community/anywhere-lombardo-st-louis-county")) {
			commName="Anywhere Lombardo - St. Louis County";
			add = "103 Westleigh Manor Dr,Wentzville,MO,63385".split(",");
			
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null)
				latLong = U.getlatlongHereApi(add);
			note="Address Is Taken From Sales Office";
			geo = "TRUE";
		}
		if(url.contains("https://lombardohomes.com/new-homes-in-michigan/build-on-your-lot/")){
			add[0]="13001 23 Mile Road";
			add[1]="Shelby Township";
			add[2]="MI";
			add[3]="48315";
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null)
				latLong = U.getlatlongHereApi(add);
			note="Address Taken From Contact";
			geo = "TRUE";
			String avialbleHomes=U.getHTML("https://anywherelombardo.com/michigan/available-homes/");
			String avialbleHomesites=U.getHTML("https://anywherelombardo.com/michigan/available-homesites/");
			String floorPlans=U.getHTML("https://anywherelombardo.com/michigan/floorplans/");
			html+=avialbleHomes+avialbleHomesites+floorPlans;
		}
		
		if(url.contains("https://lombardohomes.com/community/oakland-hunt/"))add[3]="48363";
		if(url.contains("https://lombardohomes.com/community/the-heights-at-elkow-farms/"))add[3]="48178";
		
			if (latLong[0] == ALLOW_BLANK && latLong[0] != null) {
				
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null)
					latLong = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			
			if(add[3] == ALLOW_BLANK || add[3]==null || add[0]==null || add[0]==ALLOW_BLANK) {
				
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getGoogleAddressWithKey(latLong);
				geo = "TRUE";
			}
		

		// =================Price=====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replaceAll("0s", "0,000MyPrice").replaceAll("<span class=\"community-attributes--attribute\">\n\\s*", "<span class=\"community-attributes--attribute\">");
		String[] price = U
				.getPrices(
						html,
						"price\">\\$\\d{3},\\d{3}</span>|<p>\\$\\d{3},\\d{3}<br />|>\\$<span>\\d{3},\\d{3}</span></div>|<li>\\$\\d+,\\d+</li>|center\">\\$\\d+,\\d+</td>|\\$\\d{3},\\d{3}MyPrice",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		if (maxPrice.equals(minPrice))
			maxPrice = ALLOW_BLANK;
		
		if(url.contains("https://lombardohomes.com/community/oakland-county-rochester-hills-cumberland-pointe"))minPrice=ALLOW_BLANK;
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// =============== Square Feet================
		html=html.replace("1,300 &#8211; ", "1,300 - ");
//				.replaceAll("\\d+,\\d+ sq\\. ft\\. of living space", "");
		
		comsec=comsec.replaceAll("\\d+,\\d+ sq\\. ft\\. of living space", "")
				.replaceAll("2,700+ sq. ft.", "2,700 sq. ft.");
		html=html.replace("2,750+ sq. ft", "2,750 sq. ft").replace("2,700+ sq. ft.", "2,700 sq. ft.").replace("2,000 – 3,200+ sq ft", "2,000 – 3,200 sq ft");
		comsec=comsec.replace("2,700+ sq. ft.", "2,700 sq. ft.");
//		U.log(">>>>>>>>"+Util.matchAll("\n"+comsec, "[\\w\\s\\W]{30}1,300 [\\w\\s\\W]{30}", 0));
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		.replace("&#8211;", "-").replace(" 2.400 sq. ft.", " 2,400 sq. ft.").replaceAll("starting from 1,300 – 2,700+ sq. ft", "starting from 1,300 – 2,700 sq. ft."),
		String[] sqft = U
				.getSqareFeet(
						(html+comsec),
						"more than \\d,\\d{3} sq. ft|more than \\d,\\d{3} sq. ft.|\\d,\\d{3} – \\d,\\d{3} sq ft|starting from \\d,\\d+ – \\d,\\d+ sq. ft.|<span class=\"community-attributes--attribute\">\\d,\\d{3}-\\d,\\d{3}|from \\d,\\d{3} – \\d,\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq. ft. |range from \\d,\\d{3} - \\d,\\d{3} sq. ft and|range from \\d,\\d{3} – \\d,\\d{3} sq. ft and|Sq. Feet: \\d,\\d{3}<br />|[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3}\\+ sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq ft|colonials from [0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}\\+ sq. ft.|\\d,\\d+ sq. ft. to \\d,\\d+ sq. ft.|\\d,\\d+ to \\d,\\d+ sq. ft.|\\d,\\d+ sq. ft. to \\d,\\d+ sq. ft. |from \\d,\\d+ to \\d,\\d+ sq. ft.|\\d,\\d+ sq ft|\\d,\\d+ sq. ft|\\d,\\d+ to \\d,\\d+ sq. ft|<div class=\"info-item\">\\d,\\d{3}-\\d,\\d{3}",
						
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// =========Property Type, Community Type, Property Status============
		String comType = ALLOW_BLANK;
		html = html.replace("55+ buyer!\" />", "");
		comType = U.getCommunityType(html.replace(" golf facilities ", "golf course").replaceAll("55\\+ buyer!\" />|Looking for an active adult lifestyle|membership to Lake Forest Golf &amp; Country Club|Lake Forest Country Club. And finally", ""));
		
		//==fetch homes data========
		String comBine = getHomes(url);
		comBine =comBine.replace("first floor", " first story").replace("second floor", " second story");
		//U.log(comBine);
		//=======Property TYpe
		html=html.replace("amazing views, legendary craftsmanship", "").replace("1.5-story", "one and a half story").replaceAll("Duplex_Front|merges custom home |Apartment Communities</a>|apartment-communities-in-michigan/\"|Villanueva|villanueva|Custom", "");
			
		String pType = ALLOW_BLANK;
		pType = U.getPropType((commName+html+comBine).replace("103 Westleigh Manor Dr", "").replace("Stoneybrooke+Apartments!8m2!3d42.3495299!4d-", ""));

		//=====Derived Type=========
		String dPropStatus = ALLOW_BLANK;

		String derived = U.getSectionValue(html, "<section class=\"content-slider flex-row-reverse\">",
				"</div>	");

		html = html.replaceAll("alt=\"Coming Soon\"|Information Coming Soon|details on our next phase grand opening|about the new sites available:|-template--sold-out|Coming-Soon|Grand opening September 14|/inverness/\">Now Open!</a>", "");

		
		
		dPropStatus = U.getdCommType(derived+comBine);

		U.log(dPropStatus);
		
		//Thread.sleep(10000);
		
		String pStatus = ALLOW_BLANK;
		String statSec = html;
		U.log("KKK"+Util.match(statSec,"sold out"));
		String remove = "LEADING UP TO THE GRAND|Hours: </span>COMING SOON!|details on our next phase grand opening|closeout-header|Cambridge Falls Final Closeout|<li>COMING SOON!|-template--sold-out| available homesites are cul-de-sac |Available homesites at Woods |COMING SOON!</a></li>|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|private bath. Limited opportunities|Display Now Open|information coming|Name: </span>COMING";
		statSec = statSec.replace("Phase I at Enclave a Legacy Estates is sold out", "Phase I sold out")
				.replace("NEW HOMES COMING SATURDAY, OCTOBER 19", "NEW HOMES COMING OCTOBER 19").toLowerCase().replaceAll(remove.toLowerCase(), "");
		statSec = statSec.replaceAll("only one quick close home remains",
				"Only one home remains");
		
		pStatus = U.getPropStatus((statSec+comsec).replaceAll("grand opening is highly anticipated|grand opening week|office grand|details on our next phase grand opening|LEADING UP TO THE GRAND|Information Coming Soon|about our final opportunities|advantage of the final opportunities|-template--sold-out|updates on this exciting grand", "")
				.replace("Only ONE immediate occupancy hom", " ONLY ONE HOME REMAINING "));
		U.log("=========="+Util.matchAll((statSec+comsec), "[\\w\\s\\W]{30}final[\\w\\s\\W]{30}", 0));
//     
//		U.log("=========="+Util.matchAll((statSec), "now open", 0));

		
		U.log("PropStatus:"+pStatus);
		if(html.contains("Quick Close <span>Homes</span></h3><ul class=\"models\">") || html.contains("font-main\">View Quick Close Home</a>")){
			if(pStatus.length()<4){
				pStatus="Quick Close Homes";
			}
			else{
				pStatus=pStatus+", Quick Close Homes";
			}
		}
		
		if(url.contains("https://lombardohomes.com/community/oakland-county-rochester-hills-cumberland-pointe"))pStatus="Sold Out";
//		else{
//			if(pStatus.length()<4){
//				pStatus="No Quick Close Homes";
//			}
//			else{
//				pStatus=pStatus+", No Quick Close Homes";
//			}
//		}
//		pStatus = pStatus.replace("Opening Fall 2017, Grand Opening", "Grand Opening Fall 2017");
		
		U.log(stateData);
		
		pStatus = pStatus.replace("Grand Opening, Opening Fall 2020", "Grand Opening Fall 2020");
//		U.log("=========================================");
		if (url.contains("http://lombardohomes.com/new-homes-in-michigan/macomb-county-macomb-township-wolverine-country-club-")
				|| url.contains("http://lombardohomes.com/new-homes-in-st-louis/st-charles-county-st-charles-estates-at-talbridge/"))
			geo = "False";
		commName = commName.toLowerCase().replace(
				"Tead Estates At Wildwood".toLowerCase(),
				"Homestead Estates At Wildwood");
		if(url.contains("https://lombardohomes.com/community/the-heights-at-elkow-farms"))pStatus="Cul-de-sac Homesites Available";
		if (data.communityUrlExists(url)){
			dup++;
			return;
		}
		if (latLong[0] == null) {
			latLong[0] = ALLOW_BLANK;
			latLong[1] = ALLOW_BLANK;
		}

		if (url.contains("wildwood")) {
			commName = "Homestead Estates at Wildwood";
		}
		 
		if (url.contains("https://lombardohomes.com/community/washtenaw-county-ypsilanti-township-majestic-ponds/")) pStatus += ", Limited Opportunity";
				
		add[0] = add[0].replace("Dr.", "Dr").replace("Ct.", "Ct")
				.replace("Rd.", "Rd").replace("Ave.", "Ave");
		add[1]= add[1].replace("O�Fallon","O'Fallon");
		if(url.contains("http://lombardohomes.com/new-homes-in-st-louis/st-charles-county-st-charles-estates-at-timberleaf/"))
		{
			dPropStatus=dPropStatus.replace("1.5 Story,", "");
			geo="FALSE";
		}
		U.log("GEocode::"+geo);

		U.log(">>"+commName);
		if(commName.endsWith("custom homes")){
			commName=commName.replace("custom homes", "");
		}
//		commName = commName.replace(" of ann arbor", "");
		
		//getting status from statedata: (Now Open)
		
		String[] datas = U.getValues(stateData, "\"post_author\":\"", "\"phone_link\":\"");
		for(String data : datas)
			
//			if(stateData.contains(commName) && stateData.contains("\"now_open\":true") && !pStatus.contains("Now Open")) 

		if(stateData.contains("\"now_open\":true") && !pStatus.contains("Now Open")) 
		{
			if(pStatus.length()<2) {pStatus = "Now Open";}
			else {
				pStatus = "Now Open, "+pStatus;
			}
		}
		
		
//		====================================================================================
		U.log("commName::"+commName1);
		String count=ALLOW_BLANK,noOfUnits=ALLOW_BLANK;
		int s=0;
		
		String[] lot_data=null;
/*mmm		String iframe_linkSec= U.getSectionValue(html, "<div class=\"community-iframe","</iframe>");
if(iframe_linkSec!=null) {
	String iframe_link= U.getSectionValue(iframe_linkSec, "src=\"","\"");
	U.log("iframe_link::"+iframe_link);
	if(iframe_link!=null) {
		String iframe_linkHtml=U.getHtml(iframe_link, driver);
		U.log("iFrame link HTML Path= "+U.getCache(iframe_link));
		if(iframe_linkHtml!=null) {
			//dt 20 may String countSec= U.getSectionValue(iframe_linkHtml, "<span class=\"MuiTypography-root MuiListItemText-primary MuiTypography-body1 MuiTypography-displayBlock\">","</span>");
			
			String countSec=U.getSectionValue(iframe_linkHtml, "<div class=\"MasterSiteplanLegend-root css-oycpsg\">", "<div class=\"InteractiveMasterSiteplan-zoomButton\">");
			
			//if(countSec!=null) { 
			String countSections[]= U.getValues(iframe_linkHtml, "<h6 class=\"MasterSiteplanLegend-typographyLotCount MuiTypography-root MuiTypography-subtitle2 css-1dlhfnb\">","</h6>");
			if(countSections.length<=0) {
				countSections= U.getValues(iframe_linkHtml, "<span class=\"LotLegend-typographyStandard LotLegend-inlineItem MuiTypography-root MuiTypography-overline css-1i29yre\">","</span>");
				
			}
			
			for(String section:countSections) {
			section=U.getNoHtml(section);
			U.log("map Section== "+section);
			count=Util.match(section, "\\d+");
			s+=Integer.parseInt(count);
			}
			
			
		//	}
			if(s==0&& count==null) {
				lot_data=U.getValues(iframe_linkHtml, "<span class=\"jss135\">", "</span>");
				for(String lot_Data : lot_data) {
					String c=Util.match(lot_Data, "\\d+");
					U.log("count::"+c);
					 s+=Integer.parseInt(c);
					
				}
		//dt		noOfUnits=Integer.toString(s);
	//dt 20 ,may			count=Integer.toString(s);
//				count+=Util.match(iframe_linkHtml, "\\d+ homesite");
//				count+=Util.match(count, "\\d+");
			}
		//	if(count==null && iframe_linkHtml!=null) {
			if(noOfUnits==null && iframe_linkHtml!=null) {
				lot_data=U.getValues(iframe_linkHtml, "id=\"lotListItem", "\">");
				if(lot_data.length>0) {
					noOfUnits=Integer.toString(lot_data.length);
					 U.log("lotCount2=="+noOfUnits);
					}
			}
			noOfUnits=Integer.toString(s);
			if(noOfUnits.equals("0"))
				noOfUnits=ALLOW_BLANK;
			U.log("noOfUnits::= "+noOfUnits);
		}
	}
}*///mmm
//		String map_data=sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetSiteplanLots\",\"variables\":{\"clientName\":\"lombardo\",\"communityName\":\"The Gates\"},\"query\":\"query GetSiteplanLots($clientName: String!, $communityId: Int, $communityName: String, $siteplanName: String) {\\n  siteplan(clientName: $clientName, communityId: $communityId, communityName: $communityName, siteplanName: $siteplanName, active: true) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    hotspots {\\n      id\\n      siteplanId\\n      name\\n      x\\n      y\\n      width\\n      height\\n      description\\n      thumb\\n      assets {\\n        id\\n        listIndex\\n        src\\n        description\\n        __typename\\n      }\\n      __typename\\n    }\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");

		if(url.contains("/community/columbia-mo-the-gates"))minSqf = "2300";
		
		pStatus=pStatus.replace("Ii", "II");
		
		if(url.contains("https://lombardohomes.com/community/anywhere-lombardo-michigan"))tempCommName="Build On Your Lot - MI";
      
		if(html.contains("siteplan")) {
		String map_data=sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetCommunityByNameLite\",\"variables\":{\"clientName\":\"lombardo\",\"communityName\":\""+tempCommName+"\"},\"query\":\"query GetCommunityByNameLite($clientName: String!, $communityName: String!) {\\n  communityByName(clientName: $clientName, communityName: $communityName) {\\n    ...CommunityFields\\n    siteplans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      lotMetric\\n      src\\n      geoInfo(clientName: $clientName) {\\n        id\\n        __typename\\n      }\\n      lotLegend(clientName: $clientName) {\\n        id\\n        code\\n        name\\n        hex\\n        __typename\\n      }\\n      __typename\\n    }\\n    stdFeatureCategories(clientName: $clientName) {\\n      id\\n      name\\n      features(clientName: $clientName, communityName: $communityName) {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment CommunityFields on Community {\\n  id\\n  name\\n  thumb\\n  bonafide\\n  buildYourLot\\n  caption\\n  colormtd\\n  description\\n  pricing\\n  logo\\n  longitude\\n  latitude\\n  address\\n  sortType\\n  sortOrder\\n  primarySiteplan(clientName: $clientName, active: true) {\\n    id\\n    lotMetric\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    __typename\\n  }\\n  cityLocation(clientName: $clientName) {\\n    id\\n    name\\n    customName\\n    stateCode\\n    zip\\n    postCode\\n    __typename\\n  }\\n  agents(clientName: $clientName) {\\n    id\\n    email\\n    phone\\n    firstName\\n    lastName\\n    picture\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
       U.log("Path: "+U.getCache("https://nexus.anewgo.com/api/graphql_gateway"));
       
       
     //  U.log("Map Data::"+map_data);
       
       String commId=U.getSectionValue(map_data, "{\"communityByName\":{\"id\":", ",");
       U.log("commId="+commId);
       
       String lotData=sendPostRequestAcceptJson2("https://nexus.anewgo.com/api/graphql_gateway","{\"operationName\":\"GetSiteplanLiteByCommunityId\",\"variables\":{\"clientName\":\"lombardo\",\"communityId\":"+commId+"},\"query\":\"query GetSiteplanLiteByCommunityId($clientName: String!, $communityId: Int!) {\\n  activeSiteplanByCommunityId(clientName: $clientName, communityId: $communityId, master: false) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    ...HotspotsFields\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      garagePosition\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    subSiteplans(clientName: $clientName, active: true) {\\n      id\\n      name\\n      info(clientName: $clientName) {\\n        siteplanId\\n        thumb\\n        fontSize\\n        x\\n        y\\n        whiteLabel\\n        showsThumb\\n        __typename\\n      }\\n      lots(clientName: $clientName) {\\n        id\\n        communityId\\n        salesStatus\\n        inventory(clientName: $clientName) {\\n          id\\n          communityId\\n          lotId\\n          planId\\n          elevationId\\n          __typename\\n        }\\n        excludedPlanElevations(clientName: $clientName) {\\n          planId\\n          elevationId\\n          planName\\n          planDisplayName\\n          elevationCaption\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment HotspotsFields on Siteplan {\\n  hotspots {\\n    id\\n    siteplanId\\n    name\\n    x\\n    y\\n    description\\n    thumb\\n    assets {\\n      id\\n      listIndex\\n      src\\n      description\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
    	U.log("Path2:"+U.getCache("https://nexus.anewgo.com/api/graphql_gateway"));	   
	
    	String lotDataSec=U.getSectionValue(lotData, "\"lots\":", "\"subSiteplans\":");
    	String[] lotArr=U.getValues(lotDataSec,"{\"lotId\":", "\"__typename\":\"Lot\"}");
    	int num=0;
    	num=lotArr.length;
    	noOfUnits=Integer.toString(num);
		}
		if(noOfUnits.equals("0"))
			noOfUnits=ALLOW_BLANK;
    	U.log("no Of Units:: "+noOfUnits);    	
    	
		data.addCommunity(commName, url, comType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPropertyType(pType, dPropStatus);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(noOfUnits);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		i++;
	}
	
	
	
	
	
	
	
	

	private String getHomes(String url) throws IOException {
		String combineHtml = ALLOW_BLANK;
		String html = U.getHTML(url);

		String sectionHomes = U.getSectionValue(html,
				"Available <span>Home Plans", "class=\"right-side\">");
		String links[] = U.getValues(html, "class=\"model-image\"><a href=\"",
				"\"");
		for (String link : links) {
            U.log("Home Url: " + link);
            String homeHtml =U.getHTML(link);
            
			combineHtml = U.getSectionValue(homeHtml, "<h3 class=\"overview\">", "REQUEST INFORMATION")+combineHtml;
 
		}

		
		return combineHtml;

	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	   //     connection.setRequestProperty("commonConfig", "%7B%22brand%22%3A%22wix%22%2C%22BSI%22%3A%2265c9492d-6abb-4ac5-b8e2-703455567d4b%7C1%22%7D");
	        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1MzEyNzYyOCwiZXhwIjoxNjUzMTcwODI4fQ.ctUUSFTd8p0UJSzMnJhjq3FVSjO2Zb_k9WN7Kscyloc");
	        connection.setRequestProperty("User-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36");
	     //   connection.setRequestProperty("Referer", "https://myhome.anewgo.com/client/lombardo/community/South%20Wind/siteplan");
	        connection.setRequestProperty("Accept", "*/*");
	       // connection.setRequestProperty("path", "/api/graphql_gateway");
	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
	        connection.setRequestProperty("content-length", "1708");

	       // connection.setRequestProperty("accept-encoding", "gzip");
	        connection.setRequestProperty("Content-Type", "application/json");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

	
	public static String sendPostRequestAcceptJson2(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	   //     connection.setRequestProperty("commonConfig", "%7B%22brand%22%3A%22wix%22%2C%22BSI%22%3A%2265c9492d-6abb-4ac5-b8e2-703455567d4b%7C1%22%7D");
	        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1MzEyNzYyOCwiZXhwIjoxNjUzMTcwODI4fQ.ctUUSFTd8p0UJSzMnJhjq3FVSjO2Zb_k9WN7Kscyloc");
	        connection.setRequestProperty("User-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36");
	     //   connection.setRequestProperty("Referer", "https://myhome.anewgo.com/client/lombardo/community/South%20Wind/siteplan");
	        connection.setRequestProperty("Accept", "*/*");
	       // connection.setRequestProperty("path", "/api/graphql_gateway");
	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
	        connection.setRequestProperty("content-length", "2593");

	       // connection.setRequestProperty("accept-encoding", "gzip");
	        connection.setRequestProperty("Content-Type", "application/json");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*private void addApartDetails(String apartCommSec) throws Exception {
		String url = U.getSectionValue(apartCommSec, "or visit <a href=\"","\"");
	//	if(!url.contains("http://www.springhavenapartments.com"))return;
		U.log(url);
		if(url.contains("http://www.thepreserves.com"))return;//This site can’t be reached
		
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"::::::::::::::repeated::::::::::");
			return;
		}
		
		LOGGER.AddCommunityUrl(url);
		
		//if(url.contains("http://www.theenclaveapartments.com")) return;
		String commName = U.getSectionValue(apartCommSec, "alt=\"", "\"");
		//U.log(apartCommSec);
		String apartUrlHtml = U.getHTML(url);
		if (apartUrlHtml == null) {
			url = RedirectedURL(url);
			apartUrlHtml = U.getHTML(url);
		}
		if(commName== null || commName.isEmpty()){
			commName = U.getSectionValue(apartUrlHtml, "welcome-title\">", "</h1>");
		}
		if(commName != null)
			commName = commName.trim().replaceAll("Welcome to|(Apartment(s)?)$", "");
		U.log("commName ::"+commName);

		apartUrlHtml=apartUrlHtml.replace("resort-like lifestyle", "resort-style like lifestyle");
//		U.log(apartUrlHtml);
		String comType = ALLOW_BLANK;
		comType = U.getCommunityType(apartCommSec + apartUrlHtml);

		String pType = ALLOW_BLANK;
		pType = U.getPropType(apartCommSec + apartUrlHtml);

		String dPropStatus = ALLOW_BLANK;
		dPropStatus = U.getdCommType(apartCommSec + apartUrlHtml);
//		announcement">Now Open" +
				apartCommSec=apartCommSec.replace("announcement\">Now Open", "");
				apartUrlHtml=apartUrlHtml.replace("announcement\">Now Open", "");
				String note=U.getnote(apartCommSec+apartUrlHtml);
		String pStatus = ALLOW_BLANK;
		pStatus = U.getPropStatus((apartCommSec + apartUrlHtml).replace("NEW HOMES COMING SATURDAY, OCTOBER 19", "NEW HOMES COMING OCTOBER 19").replace("Only ONE immediate occupancy hom", " ONLY ONE HOME REMAINING "));

		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };

		
		add[0]=U.getSectionValue(apartUrlHtml, "class=\"street-address\">", "</span>");
		U.log(add[0]);
		add[1]=U.getSectionValue(apartUrlHtml, "class=\"locality\">", "</span>");
		U.log(add[1]);
		add[2]=U.getSectionValue(apartUrlHtml, "class=\"region\">", "</span>");
		if(add[2]!=null)
			add[2]=add[2].trim();
		U.log(add[2]);
		add[3]=U.getSectionValue(apartUrlHtml, "class=\"postal-code\">", "</span>");
		String addSec = U.getSectionValue(apartUrlHtml, "<h3>Address</h3>","</address>");
		if (addSec != null) {
			addSec = addSec.replaceAll("\\s+", " ").replace("&#160;", "").replaceAll("<br>", ",");
			add = addSec.split(",");
		}
		

		U.log("Street : " + add[0] + "     City : " + add[1] + "    State : "+ add[2] + "    Zip : " + add[3]);

		// =========Sqft=========
		apartUrlHtml = apartUrlHtml.replaceAll("\\s+", " ");
		String AmenitiesLink = U.getSectionValue(apartUrlHtml,"<h2> <a href=\"", "\"> Amenities </a> </h2>");
		String AmenitiesHtml = "";
		if (AmenitiesLink != null)
			AmenitiesHtml = U.getHTML(AmenitiesLink);
		AmenitiesHtml = AmenitiesHtml.replaceAll("\\s+", " ");
		String floorPlanLink = "", floorPlanHtml = "";
		
		floorPlanLink = U.getSectionValue(AmenitiesHtml,"Overview </span> </a> </li> <li > <a href=\"","\" title=\"Floor Plans\"");
//		U.log(">>>>>>"+floorPlanLink);
		if (floorPlanLink != null)
			floorPlanHtml = U.getHTML(floorPlanLink);
		
		String navigateSection = U.getSectionValue(apartUrlHtml, "role=\"menubar\">", "</ul>");
		if(navigateSection != null){
			String[] menuUrls = U.getValues(navigateSection, "href=\"", "\"");
			for(String menuUrl : menuUrls){
				if(floorPlanLink == null){
					if(menuUrl.contains("property_info")){
						floorPlanHtml = U.getHTML(menuUrl);
						U.log(menuUrl);
					}
				}
			}
		}
		U.log(">>>>>>"+floorPlanLink);
		
//		U.log(apartUrlHtml);
		//String sqfsec=U.getSectionValue(apartUrlHtml, "floorplans\"><a class=\"header-nav-link\" href=\"", "\" data");
		//U.log("----->"+sqfsec);
	//	String sqfhtml="";
	//	if(sqfsec!=null)
		// sqfhtml=U.getHTML(sqfsec);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sqft = U
				.getSqareFeet(
						apartCommSec + apartUrlHtml + floorPlanHtml,
						"Sq. Feet</span><span class=\"fp-col-text\">\\d,\\d{3}|\\d+  Sq. Ft.|\\d to \\d,\\d+ square feet|\\d+ square foot|\\d,\\d+ square feet|\\d,\\d+ sq ft|\\d,\\d+ sq. ft|\\d,\\d+ sq. ft|\\d,\\d+ to \\d,\\d+ sq. ft",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		if (url.contains("http://www.thepreserves.com")) {//this is hardcoded coz site not providing access to source where sqf is given
			minSqf = "890";
			maxSqf = "1910";
			dPropStatus=ALLOW_BLANK;
			
		}
		if (url.contains("http://www.sterlingcommonsapartments.com/"))
		{
			pType="Townhomes,Apartment Home";
			minSqf = "1200";
		}
		if (url.contains("http://www.theenclaveapartments.com")) {
			minSqf = "640";
			maxSqf = "1100";
			pType="Townhomes";
		}
		if(url.contains("http://www.kirkwayapartments.com/"))
		{
			pType="Townhomes";
			minSqf="1020";
			maxSqf="1552";
		}
		if (url.contains("www.aberdeenofbrighton")) {
			minSqf = "1149";
			maxSqf = "1740";
			pType="Luxury Homes,Apartment Home";
		}
		if (url.contains("www.sterlingcommonsapartme")) {
			minSqf = "1200";
			maxSqf = "1300";
			pType="Townhomes,Apartment Home";
		}
		if(url.contains("springhavenapartments")){
			commName = "Spring Haven";
		}
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// ========MinPrice============
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		

		if (url.contains("http://www.thepreserves.com")) {
			add[0] = "3737 Cherry Creek Lane";
			add[1] = "Sterling Heights";
			add[2] = "MI";
			add[3] = "48314";
			comType="Resort Style";
			minPrice="$550,000";
			
		}
		
		// ============Lat, Long & Geo===============
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };

		String geo = "FALSE";
		if (add[0] != ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
		}
		if (latLong[0] == null) {
			latLong[0] = ALLOW_BLANK;
			latLong[1] = ALLOW_BLANK;
		}
		if (url.contains("enclaveapartments")) {
			add[0] = "8442 Stanford North";
			add[1] = "Washington Township";
			add[2] = "MI";
			add[3] = "48094";
			latLong[0] = "42.771967";
			latLong[1] = "-83.024368";
			geo = "FALSE";
			minSqf = "640";
			maxSqf = "1250";
		}
		// http://lombardohomes.com/new-homes-in-michigan/brampton/

		U.log("Lat : " + latLong[0] + "        Lng : " + latLong[1]);
		add[0] = add[0].replace("Dr.", "Dr").replace("Ct.", "Ct")
				.replace("Rd.", "Rd").replace("Ave.", "Ave").toLowerCase();
		add[1] = add[1].toLowerCase();
		
		if (url.contains("http://www.kirkwayapartments.com/")) {
			minSqf = "1020";
			maxSqf = "1812";
			pType="Townhomes,Apartment Home";
		}
		if(url.contains("/community/inverness/"))note = "Now Open For Sales";
		commName = commName.replace("Apartments", "");
		if(url.contains("http://www.thepreserves.com")){
			pType="Luxury Homes,Apartment Home";
			geo = "TRUE";
		}
		U.log("Ptype::"+pType);
		
		data.addCommunity(commName.replace("Anywhere Lombardo �", "-"), url, comType);
		data.addAddress(add[0], add[1].replace(",", ""), add[2], add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].replace(" ", "").trim(), latLong[1].trim(), geo);
		data.addPropertyType(pType, dPropStatus);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		
	}
	*/

	public String RedirectedURL(String url) throws Exception {
		URLConnection con = new URL(url).openConnection();
		// System.out.println( "orignal url: " + con.getURL() );
		
		con.connect();
		// System.out.println( "connected url: " + con.getURL() );
		InputStream is = con.getInputStream();
		// System.out.println( "redirected url: " + con.getURL().toString() );
		String RedUrl = con.getURL().toString();
		is.close();
		return RedUrl;

	}
}
