package com.shatam.b_081_100;

import java.io.*;
import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.PropertyStatus;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNormandyhomes extends AbstractScrapper {
	static String BASEURL = "https://normandyhomes.com";
	CommunityLogger LOGGER;
	static int i = 0;
	static int duplicates = 0;
	WebDriver driver = null;
//================================================================================================================================================================
	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractNormandyhomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+ "Green Brick Partners - Normandy Homes.csv", a.data().printAll());
		U.log(duplicates);
	}
//============================================================================================================================================

	public ExtractNormandyhomes() throws Exception {

		super("Green Brick Partners - Normandy Homes", BASEURL);
		LOGGER = new CommunityLogger("Green Brick Partners - Normandy Homes");
	}
//============================================================================================================================================
	public void innerProcess() throws Exception {
		String html = U.getHTML("https://normandyhomes.com/our-communities/");		//whole find homes page url 
		// U.log("html is::::"+html);
       U.setUpChromePath();
       driver=new ChromeDriver();
		String section[] = U.getValues(html, "<div class=\"home-wrap", "View Community</a>");		//get perticullar section
		U.log("total comm"+section.length);
		
		for (String sec : section) {
//			String url = U.getSectionValue(sec, "<p class=\"text-left\"><a class=\"\" href=\"",
//					"\"");
			String url = U.getSectionValue(sec,"<a class=\"d-block w-100\" href=\"","\"");
			U.log("Urls::============================================>" + url);
			String communityname = U.getSectionValue(sec,
					"<h3>", "</h3>");
			U.log("community names::" + communityname);

			addDetails(url, communityname,sec);
		}
		driver.quit();
		LOGGER.DisposeLogger();
		
	}
//================================================================================================================================================================AddDetails
	public void addDetails(String url, String commName,String comSec) throws Exception {
		//TODO:
//			 if(!url.contains("https://normandyhomes.com/communities/south-haven/"))return;
	//if(i == 0)
		{
		//	U.log("Count: "+i +"\t"+comSec);
			U.log("count"+i);
			if (this.data.communityUrlExists(url)) {
				duplicates++;
				return;
			}
			
			//=======================================take the Html of the URl============================
			String html = U.getHTML(url);
			U.log("commName===========================> "+commName);
//			U.log(html);
			String geo = "FALSE";
		
			
			// -----Lattitude and Longitude-----

			String latSec = U.getSectionValue(comSec, "href=\"https://www.google.com/maps/dir/?api=1&destination=", "\"");
			
			if(latSec==null) latSec = ALLOW_BLANK;
			String latLong[] = latSec.split(",");
			if(latSec==null)
			U.log("lat::" + latLong[0] + " lng::" + latLong[1]);
			U.log("Url===========================> "+url);
			
			
			// -----Addresses------

			String addSec = U.getSectionValue(comSec,
					"title=\"Opens Google Map Directions\" target=\"_blank\">", "<i class=\"fa fa-location-arrow\">");

			// U.log("-----------------" + addSec);
			String street = ALLOW_BLANK;
			String city = ALLOW_BLANK;
			String state = ALLOW_BLANK;
			String zip = ALLOW_BLANK;
			// U.log("Address value:::"+addSec);
			
			if(addSec!=null)
			addSec = U.getNoHtml(addSec).replace("Coming Soon!", "");
			U.log("Address value:::=================================================> "+addSec);
			String address[] = U.findAddress(addSec.replaceAll(" &amp; ", " and ").replace("Coming Soon!", "").replace("SOLD OUT", ""));
			U.log("Address :::======================================================> "+ Arrays.toString(address));
			//
			// for (String string : address) {
			// System.out.println(":::::"+string);
			// }
			
			if (address != null) {
				U.log("Result::" + Arrays.toString(address));
				street = address[0];
				city = address[1];
				state = address[2];
				// state=USStates.abbr(state);
				zip = address[3];
				// }

				U.log("street::" + street + " city::" + city + " zip::" + zip
						+ " state::" + state);

			}
			else if(addSec.contains("<span class=\"addressStreet\">")){
				street = U.getSectionValue(html, "addressStreet\">", "<").replace("SOLD OUT", "");
				city = U.getSectionValue(html, "addressCity\">", "<").replaceAll(",|\\s*", "");
				state = U.getSectionValue(html, "addressState\">", "<");
				zip = U.getSectionValue(html, "addressZipCode\">", "<").trim();
				
			}else {
			

				if(url.contains("https://www.normandyhomes.com/find-new-homes/estates-at-shaddock-park/")) {
					street = "14345 Regents Park";
					city = "Frisco";
					state = "TX";
					zip = "75035";
				}
				else {
				String add[] = U.getAddressGoogleApi(latLong);
				street = add[0];
				city = add[1];
				state = add[2];
				zip = add[3];
				geo = "TRUE";
				}

			}
			
			street = street.replaceAll("Coming Soon!|Now Selling from Reserve on Parker!", "");
			U.log("Street is ==========================================================>: " + street);
			if (street.length() < 4) {
				String[] addr = U.getAddressGoogleApi(latLong);
				street = addr[0];
				geo = "true";
			}

			if (zip == ALLOW_BLANK) {
				String[] addr = U.getAddressGoogleApi(latLong);
				city = addr[1];
				state = addr[2];
				zip = addr[3];
				geo = "true";
			}

			if (street.length() == 0) {
				String addr[] = U.getAddressGoogleApi(latLong);
				street = addr[0];
				geo = "TRUE";
			}
			
			if(street.contains("Model Coming Soon")){
				String[] addr = U.getAddressGoogleApi(latLong);
				street = addr[0];
				geo="true";
								
			}
			street = street.toLowerCase().replace(city.toLowerCase(), "")
					.replace(zip, "").replace("texas", "").replace(".,", "").replace(",", "");
			U.log("street::" + street);
			
			if(latLong[0]==null || latLong[0]==ALLOW_BLANK) {
				String add[] = {street, city, state, zip};
				latLong = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			
			// ------Community Type --------
			String communitytype = U.getCommunityType(html.replaceAll("WestRidge Golf Course|and Country Club R", ""));
			U.log("communitytype:" + communitytype);

			// -----------Derived Type-------------

			String dtype = U.getdCommType(html.replaceAll("one and a half",
					"1.5 story").replaceAll("Owner's Suite on First Floor|Owner's & Guest Suite on First Floor|rAnchor|[B|b]*ranch|[C|c]*raig [R|r]*anch", ""));
			U.log("dtype:" + dtype);
			// -------------Property Type-----------------
			String allHomeData = getHomeData(html);
//			U.writeMyText(allHomeData);
			String proptype = U.getPropType((html + allHomeData).replaceAll("-village-at-twin-|villas-at|Villas at|Villas At|Village|villas-at-southgate|Discover what sets our luxury custom homes apart today", "").replace("This luxury Normandy Homes", "This luxury homes")+commName);
		
			U.log("proptype:" + proptype);

			// ----------Property Status-----------------
			 /*
		     * Count of Homes available == count of Move In ready homes
		     */
			int moveIncount = 0;
		    String homeAvailableSec = U.getSectionValue(html, "Available Homes</h2>", "</section>");
		    if(homeAvailableSec != null){
		    	moveIncount = U.getValues(homeAvailableSec, "href=\"", "\"").length;
		    	U.log("moveInCount::"+moveIncount);
		    }
		    
		    html = html.replaceAll("(M|m)ove-(i|I)n (R|r)eady</a>", "");
		    html=html.replaceAll("<img(.*?)>", " ");
		    
		    comSec = comSec.replace("_communitybuttons-06.png?v=637103730240000000", " Close Out ");
//		    U.log(comSec);
			String propstatus = U.getPropStatus((html+comSec).replaceAll("Selling out of Estates at Shaddock Model|Site Map Coming Soon|[M|m]ove-[I|i]n|class=\"tipCloseout|Quick Move-In|now selling in the brand new model|Currently selling from our Viridian model|>Move-In Ready<|Now Selling from Watters Branch|Anchor\">Move-In Ready</a>| Currently selling|, Currently selling NEW SECTION|Currently Selling Phase 6|Currently Selling|, Currently Selling ", ""));
			if(moveIncount>0){
				if(propstatus != ALLOW_BLANK) propstatus +=", Quick Move-In Homes";
				else propstatus = "Quick Move-In Homes";
			}
//			U.log("url:::" + url);
			propstatus=propstatus.replace("Sold Out, Sold-out","Sold Out" );
			U.log("property Status=======================================================> "+propstatus);

			//==========================prices============================================================----------	
			if (allHomeData != null) {
				allHomeData = allHomeData.replace("0's", "0,000").replace("cul-de-sac lot over 11,400 sq. ft.", "");
			}
			
			html = html.replace("0's", "0,000").replace("$340s", "$340,000");
			html = html.replace("0's", "0,000");
			String prices[] = U.getPrices(allHomeData + html,
					"white\">\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3} </h5>|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|<h4>$390,990 - $390,990 </h4>|<h4>\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3} </h4>|<h5>\\$\\d{3},\\d{3}</h5>|<h5>From \\$\\d{3},\\d{3}</h5>|From\\$\\d{3},\\d{3}|Starting at \\$*\\d{3},\\d{3}|STARTING FROM \\$\\d{3},\\d{3}|Priced at \\$*\\d{3},\\d{3}|dealPrice\">\\$\\d{3},\\d{3}", 0);
			String minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			String maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Min Price::" + minPrice+"and Max Price::" + maxPrice);
//			U.log("mmmmmm"+Util.matchAll(allHomeData + html, "[\\w\\s\\W]{30}886[\\w\\s\\W]{30}", 0));

			// ===========================================================================================================square feet
			//U.log(Util.matchAll(allHomeData + html,".*1400.*",0));
			String sqft[] = U.getSqareFeet(allHomeData + html,
					"Sq. Ft. <span>\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} Sq. Ft.|>\\d,\\d{3} - \\d,\\d{3} Sqft|\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3}\\s*Sq.\\s*Ft.|\\d,\\d{3} Sqft</li>", 0);
			String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			street=street.replace("&amp;", "&");
			if(propstatus.contains("Homes Ready Now, Move-In Ready Homes"))propstatus="Move-In Ready Homes";
			
//			if(url.contains("https://normandyhomes.com/communities/edgewood/"))proptype = "Patio Homes";
//			if(url.contains("https://normandyhomes.com/our-communities/the-village-at-twin-creeks/") || url.contains("/our-communities/essex-park/"))propstatus=propstatus+", New Phase Now Selling";//Image
			if(url.contains("https://normandyhomes.com/our-communities/reserve-on-parker/"))propstatus=propstatus+", Limited Opportunities Remain";//Image
			propstatus = propstatus.replace("Now Selling, New Phase Now Selling", "New Phase Now Selling");
			if(url.contains("https://normandyhomes.com/communities/bretton-woods/"))dtype=ALLOW_BLANK;
			// =========================================================================================================adding in csv
			String sitePlanSec=U.getSectionValue(html, "<h2 class=\"text-center py-md-3\">Site Map</h2>", "</section>");
			String noOfUnits=ALLOW_BLANK;
			
			if(sitePlanSec!=null) {
			String siteUrl=U.getSectionValue(sitePlanSec, "src='", "'");
			if(siteUrl!=null) {
			String siteMapData=U.getHtml(siteUrl, driver);
			String [] lotData=U.getValues(siteMapData, "<g id=\"lot_", "\">");
			int lotCount=lotData.length;
			noOfUnits=Integer.toString(lotCount);
			
			U.log("No. of units"+noOfUnits);
			}
		}
		
			
			U.log(U.getCache(url));
			LOGGER.AddCommunityUrl(url);
			data.addCommunity(commName, url, communitytype);
			data.addAddress(street, city, state.trim(), zip);
			data.addLatitudeLongitude(latLong[0], latLong[1].trim(), geo);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(propstatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(U.getnote(html.replace("PRE-CLOSE OUT",
					"Pre Close Out")));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(noOfUnits);
		}
		i++;
	
	}
//================================================================================================================================================================
	private String getHomeData(String cHtml) throws IOException {
		String homeData = ALLOW_BLANK;

		cHtml = cHtml.replace("&amp;", "&");
		String plansAvailable = U.getSectionValue(cHtml, "Floorplans</h2>",
				"</section>");
		// U.log(plansAvailable);
		if (plansAvailable != null) {
			String homesDataSec[] = U.getValues(plansAvailable,
					"<div class=\"home-wrap", "View Plan</a>");

			for (String homedataSec : homesDataSec) {
				String homeDataUrl = U.getSectionValue(homedataSec,
						"href=\"", "\"");
				
				String homeUrl = null;
				if(homeDataUrl!=null)
				if(homeDataUrl.contains("http"))
					homeUrl =  homeDataUrl;
				else
					homeUrl = BASEURL + homeDataUrl;
				
				//U.log("Home url::" + homeUrl);
				
				String homeHtml = null;
				if (homeHtml == null) {
					homeHtml = U.getHTML(homeUrl);
					// U.log(U.getSectionValue(homeHtml,
					// "<div class=\"homeName\">",
					// "<h2 class=\"bdxTitle \">Community Details</h2>"));
					homeData = homeData + U.getSectionValue(homeHtml, "<section id=\"homeOverview\"", "</section>")
							+ U.getSectionValue(homeHtml, "<section id=\"homeDescription\">", "</section>");
				}

				// break;
			}

		}
		return homeData;
	}
}
