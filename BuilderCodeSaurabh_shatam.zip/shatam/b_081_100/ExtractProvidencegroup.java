package com.shatam.b_081_100;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractProvidencegroup extends AbstractScrapper {
	static int j = 0;
	static String BASEURL = "https://theprovidencegroup.com";
	WebDriver driver =null;
	String geo;
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractProvidencegroup();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Green Brick Partners - The Providence Group.csv", a.data().printAll());
	}

	public ExtractProvidencegroup() throws Exception {

		super("Green Brick Partners - The Providence Group", BASEURL);
		LOGGER = new CommunityLogger("Green Brick Partners - The Providence Group");
	}

	public void innerProcess() throws Exception {
		
		/*FirefoxProfile profile1=new FirefoxProfile();
		File pathToBinary=new File("/home/mypremserver/Downloads/firefox/firefox");
		FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
		profile1.setPreference("permissions.default.image", 2);
		driver=new FirefoxDriver(ffBinary,profile1);*/
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		U.setUpChromePath();
		driver = new ChromeDriver();
		String html = U.getHtml("https://theprovidencegroup.com/new-homes/", driver);
//				"http://theprovidencegroup.com/communities/atlanta/", driver);
//		html=html.replaceAll("</a></div></div><hr />", "endsec");
//		String[] secs = U.getValues(html, "<div class=\"item oi-map-item location-map-item", "</p></a></div></div>"); //"endsec");
//		String[] secs = U.getValues(html, "<div class=\"item oi-map-item location-map-item loc-card", "</a></div></div><hr></div>"); //"endsec");
		
		String[] secs = U.getValues(html, "<div class=\"thumbnail card list-card row py-4\">", "</div></div></div></div>");
		U.log(secs.length);
		
		for (String sec : secs) {
			
//			 U.log("=============" + sec);
			String url = BASEURL+ U.getSectionValue(sec,"<a class=\"text-dark-cyan\" href=\"", "\"");
			 U.log(url);
			addDetails(url, sec);
//break;
//			 U.log("=============" + sec);
		}

		try{driver.close();	driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	//TODO : Extraction for single community 
	public void addDetails(String url, String sec) throws Exception {
//		if (j >= 10)
//		try{
		{
			if(url.contains("http:")) url = url.replace("http:", "https:");

//	if(!url.contains("https://theprovidencegroup.com/new-homes/ga/alpharetta/the-maxwell/6822/"))return;
		
			if(data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+":::::::::::::repeated::::::::::");
				return;
				
			}
//			if(url.contains("https://theprovidencegroup.com/new-homes/ga/suwanee/suwanee-towneship/6821/")){
//				LOGGER.AddCommunityUrl(url+":::::::::::::Return::::::::::");
//				return;
//			}
			
			LOGGER.AddCommunityUrl(url);
			
			 U.log("::::::"+j+":::::::\n"+url + "\n"+U.getCache(url));
			
			String html = U.getHtml(url, driver);
//			U.log("MMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{100}two-story[\\s\\w\\W]{100}", 0));
			
			String tHtml=html;

			String priceSec=U.getSectionValue(html, "Available Homes</a> <a class=\"py-1", "Want to learn more about");
//			U.log("priceSec=="+priceSec);
			if(priceSec==null)
				priceSec=U.getSectionValue(html, "title text-gray mb-5", "Phone:");
			
//			U.log("priceSec=="+priceSec);
			
			
			String remove = U.getSectionValue(html, "Other Communities You May Love", "</span></div></div></div></div>");
			
			if(remove!=null)
				html = html.replace(remove, "");
			
			String commName = U.getSectionValue(html, "<span class=\"flex-fill\">", "</span>");//Util.match(sec, Util.match(sec,"community-name padding\" data-col=\"0\">(.*?)</a>", 1));
			U.log("commName: "+commName);
			//U.log(html);
			String statushtm=html;
			
			String rmsec=U.getSectionValue(html, "Other Communities You May Love", "</htm");
			html = html.replaceAll("Save Up To \\$\\d+,\\d+", "");
			
			if(rmsec!=null)
				html = html.replace(rmsec, "");
			
			String rep = U.getSectionValue(html, "SEARCH AVAILABLE HOMES",
					"Main Level Owner Suite</label>");
			if(rep!=null)
			html = html.replace(rep, "");
			
			if(html.contains("No Quick Move-In Homes"))
			{
				html = html.replace("QUICK MOVE-IN HOMES", "");
			}
			String drop1 = U.getSectionValue(html, "<!DOCTYPE HTML>",
					"<section id=\"community-info\">");
			if (drop1 != null)
				html = html.replace(drop1, "");
			String drop2 = U
					.getSectionValue(html,
							"<div class=\"neighborhood_map_container row\">",
							"</html>");
			if (drop2 != null)
				html = html.replace(drop2, "");
			String drop3 = U.getSectionValue(sec,
					"<option value=\"\">Price (max)</option>", "</footer>");
			if (drop3 != null)

				sec = sec.replace(drop3, "");
			html = html
					.replaceAll(
							"  <option value=\"Townhouse\" >Townhouse</option>|Playground Equipment, Patio Furniture and|  <h2>Sewell Farm Hoa</h2> ",
							"");
			String communitytype = U.getCommType(html);
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
//			String dirHtml = U.getHtml(url + "/directions", driver);
			
			//U.log(dirHtml);
			String addSec = U.getSectionValue(sec,"<div class=\"model-address\">", "</span>"); //gps address
			addSec=addSec.replaceAll("<br />\\s*", ", ");
			addSec=U.getNoHtml(addSec);
			U.log("addSec:::::::::::::"+addSec+"::::::::::::::::::::::");

			
//			U.log("addSec:::::::::::::"+addSec+"::::::::::::::::::::::");
			
			if(addSec!=null){
				addSec=addSec.replaceAll("</strong>|Address and Model Home Address:&nbsp;|Address:&nbsp;|Address: |�|Address:�|Address and Model Address:Â |and Model |Address and Model Home |Address:Â |Address:ï¿½|Address: |Address |for Bellmoore Park: ", "");
				addSec =addSec.replaceAll("<br />|,&nbsp;", ",").replace("3387&nbsp;", "3387 ").replace("371 Pratt Drive, Unit 208", "371 Pratt Drive Unit 208")
						.replace("<br> ", ", ");
				if(!addSec.contains(",")){
					addSec=U.formatAddress(addSec);
				}
				if(!addSec.contains(", GA ")){
					addSec=addSec.replace(" GA ", ", GA ");
					
					if(addSec.endsWith("GA"))
					addSec = addSec.replace(" GA", ", GA");
				}
			}
			if(addSec!=null && addSec.contains("Rd. ")) {
				addSec=addSec.replace("Rd. ", "Rd.,");
			}
			if(addSec!=null && addSec.contains("Rd ")) {
				addSec=addSec.replace("Rd ", "Rd,");
			}
			if(addSec!=null && addSec.contains("Overlook  ")) {
				addSec=addSec.replace("Overlook  ", "Overlook, ");
			}
			if(addSec!=null && addSec.contains("Street  ")) {
				addSec=addSec.replace("Street  ", "Street, ");
			}
			if(addSec!=null && addSec.contains("Road  ")) {
				addSec=addSec.replace("Road  ", "Road, ");
			}
			if(addSec!=null && addSec.contains("Lane  ")) {
				addSec=addSec.replace("Lane  ", "Lane, ");
			}
			if(addSec!=null && addSec.contains("Highway  ")) {
				addSec=addSec.replace("Highway  ", "Highway, ");
			}
			if(addSec!=null && addSec.contains("Drive  ")) {
				addSec=addSec.replace("Drive  ", "Drive, ");
			}
			if(addSec!=null && addSec.contains("Circle SE  ")) {
				addSec=addSec.replace("Circle SE  ", "Circle SE, ");
			}
//			if(url.contains("https://theprovidencegroup.com/pratt-stacks")) {
//				addSec="1039 Grant St SE, Atlanta, GA 30315 ";
//			}
//			if(url.contains("https://theprovidencegroup.com/westside-village")) {
//				addSec="2260 Marietta Blvd NW , Atlanta, GA 30318";
//			}
			U.log("formated addSec:::::::::::::"+addSec+"::::::::::::::::::::::");
			
			add=U.getAddress(addSec);
			
//			String[] addr = addSec.split(",");
//			add[0] = addr[0].replace(" ", " ");
//			add[1] = addr[1].replace(" ", "");
//			add[2] = Util.match(addr[2], "\\w{2}");
//			add[3] = Util.match(addr[2], "\\d{5}");

			
			
			//String lat1[] = U.getlatlongGoogleApi(add);
			//String lat = lat1[0].trim();
			//String lng = lat1[1].trim();
			
			String lat =U.getSectionValue(sec, "data-latitude=\"","\"");
			String lng =U.getSectionValue(sec, "data-longitude=\"","\"");
			U.log(lat+":::::::::::"+lng);
			
			
			
			if(add[3] == null || add[3] == ALLOW_BLANK) {
				String[] latlng = {lat,lng}; 
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				U.log("Google Address: "+Arrays.toString(add));
				geo="True";
			}
			
			if(add[1] != null && add[2] != null && lat == null) {
				String[] latlng = U.getlatlongGoogleApi(add);
				U.log("Google latlng: "+Arrays.toString(latlng));
				lat = latlng[0];
				lng = latlng[1];
				geo="True";
			}
			
			String quickSec = U.getSectionValue(html, "<div class=\"location-specs-for-sale swiper-nav\"", "<div class=\"location-active-plan-slider");		
			String qSec[]=U.getValues(html, "card spec-card swiper-card\">", "home-type font-small\">");
			String qHtml="";
			int countq=0;
			int quickCount = 0;
			for (String url1 : qSec) {
				
				if(url1.contains("Quick Move-In"))
					quickCount++;
				
				url1=U.getSectionValue(url1, "href=\"","\"");
				U.log("Quick Move-In: "+BASEURL+url1);
				String tempHtml=U.getHTML(BASEURL+url1);
//				if(tempHtml.contains("914,905"))
//				{
//					U.log("FOUND");
//				}
				tempHtml=U.getSectionValue(tempHtml, "<div class=\"container-fluid position-relative\">", "</span></div></div></div></div>")+U.getSectionValue(tempHtml, "<div class=\"container-fluid position-relative\">", "Download Flyer</a>")+U.getSectionValue(tempHtml, "<div class=\"model-sub-menu", "</div></div></div></div>")+
						U.getSectionValue(tempHtml, "<div class=\"model-stats", "</div></div></div></div>");
//				U.log(rmse1c);
				
				qHtml=qHtml+tempHtml;
				countq++;
				if(countq>5)break;
			}
			
			///AvailSec
			String allAvailHomesData =ALLOW_BLANK;

			String availSec=U.getSectionValue(html, "<div class=\"location-active-plan-slider", "<div id=\"contact-loc-detail\">");
//			U.log(" availSec "+availSec);
			if(availSec!=null){
				String[] availSecUrl=U.getValues(availSec, "<a href=\"", "\"");
				
				for(String homeUrl :availSecUrl ) {
					U.log("homeUrl====="+BASEURL+homeUrl);
					String tempHtml=U.getHTML(BASEURL+homeUrl);
//					if(tempHtml.contains("914,905"))
//					{
//						U.log("FOUND");
//					}
					allAvailHomesData+=U.getSectionValue(tempHtml, "<div class=\"col plan-name text", "Download Flyer</a>")+"\n\n\n";
				}
				
				
			}
			
			String allAvailUrl[] = U.getValues(html, "<a class=\"text-dark-cyan\" href=\"", "\"");
			for(String homeUrl :allAvailUrl ) {
				U.log("new Availurl:::::"+BASEURL+homeUrl);
				String tempHtml=U.getHTML(BASEURL+homeUrl);
//				if(tempHtml.contains("914,905"))
//				{
//					U.log("FOUND");
//				}
				allAvailHomesData+=U.getSectionValue(tempHtml, "<div class=\"container-fluid position-relative\">", "Download Flyer</a>")+ U.getSectionValue(tempHtml, "<div class=\"container-fluid position-relative\">", "</span></div></div></div></div></div>")+U.getSectionValue(tempHtml, "<div class=\"model-sub-menu", "</div></div></div></div>")+
						U.getSectionValue(tempHtml, "<div class=\"model-stats", "</div></div></div></div>")+U.getSectionValue(tempHtml, "<section class=\"dyn-content-block py-5\">", "Your Recommendations</div>");
			}
			String extraSec=U.getSectionValue(html, "blog-roll", "</ul>");
//			U.log(extraSec);
			if (extraSec!=null) html=html.replace(extraSec, "");
			
			html = html.replaceAll(">(single-family|condominium|traditional|townhomes?\\.?\\,?)</span>", "")
					.replace("Lush luxury is yours behind the gates", "Lush luxury homes is yours behind the gates")
					.replace("Traditionally inspired exterior designs", "Traditional homes inspired exterior designs")
					.replace("traditionally-inspired townhomes", "traditional homes townhomes")
					.replace("Carriage collections of single-family homes", "The Carriage Collection of single-family homes");
			html = html.toLowerCase().replaceAll("two and three story",
					"2 story & 3 story").replace("upscale single family","").replaceAll("luxury living|luxury townhome| everyday luxury", "luxury homes");
			
			if(qHtml!=null)
				qHtml = qHtml.replaceAll("luxury living|luxury townhome| everyday luxury", "luxury homes");
			
			if(allAvailHomesData!=null)
				allAvailHomesData = allAvailHomesData.replaceAll("luxury living|luxury townhome| everyday luxury", "luxury homes");
			
			sec = sec.toLowerCase().replaceAll("two and three story",
					"2 story & 3 story").replaceAll("townhomes2_7|single family home\">single family home| value=\"townhouse\">townhouse","");
		
			
			html=html.replace("home is meant to be a luxurious sanctuary", "home is meant to be a luxurious pool sanctuary")
					.replace("carriage, meadowview collections", "Carriage Home, meadowview collections");
			
			String proptype = U.getPropType((priceSec+html+sec+allAvailHomesData+qHtml)
					
					.replaceAll("craftsmanship|value=\"single family home\">single family home</option>|data-filter=\"single family home\"><span></span>single family home</label>|(condominium|townhome)\" data-filter=\"(condominium|townhome)\"><span></span>(condominium|townhome)</label>|<input id=\"filterplan(condominium|townhome)\" name=\"filterplans\" type=\"radio\">|<label for=\"filterspec(condominium|townhome)\" data-filter=\"(condominium|townhome)\"><span></span>(condominium|townhome)</label>|<input id=\"filterspec(condominium|townhome)\" name=\"filterspecs\" type=\"radio\">|<option value=\"(condominium|townhome)\">(condominium|townhome)</option>|for=\"filterquickhomes(condominium|townhome)\" data-filter=\"(condominium|townhome)\"><span></span>(condominium|townhome)</label>|id=\"filterquickhomes(condominium|townhome)\"|value=\"(Condominium|Townhome|Single Family Home)\">(Condominium|Townhome|Single Family Home)</option>|<input id=\"filterSpec(Condominium|Townhome)\"|<option value=\"(Condominium|Townhome|Single Family Home)\">(Condominium|Townhome|Single Family Home)</option>|id=\"filterQuickHomes(Condominium|Townhome|Single Family Home)\"|for=\"filterQuickHomes(Condominium|Townhome|Single Family Home)\"|id=\"filterPlan(Condominium|Townhome|Single Family Home)\"|data-filter=\"(Condominium|Townhome|Single Family Home)\">|<span></span>(Condominium|Townhome|Single Family Home)</label>|low maintenance design and craftsmanship.", ""));
			
//			U.log("MMMMMMMMM "+Util.matchAll(priceSec+html+sec+allAvailHomesData+qHtml, "[\\s\\w\\W]{100}The owner’s suite in your Towns on Thompson home is meant to be a luxurious sanctuary[\\s\\w\\W]{100}", 0));

			if (proptype.contains("")&&proptype.contains("")) {
				proptype = proptype.replaceAll("^Townhouse,| Townhouse,|, Townhouse", "");
			}
			U.log("proptype=="+proptype);
			html = html.replaceAll("<img alt=\"stories\".*\" /><span>3\\.0</span>", "Story 3");
			
			String dtype = U.getdCommType((html.replaceAll("multi-level town home complex surrounded by trees with a row of shops and parking in front&quot;|<span m=\"\\d+\" id=\"\\d{2}_\\d+\">two-story</span>", "") + sec + allAvailHomesData+qHtml).replace("3story", "3 Story").replaceAll("4-sided| Floor|floor", ""));
//			U.log("MMMMMMMMM "+Util.matchAll(allAvailHomesData, "[\\s\\w\\W]{30}two-story[\\s\\w\\W]{30}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll(qHtml+sec, "[\\s\\w\\W]{30}two-story[\\s\\w\\W]{30}", 0));
			U.log("Derived type::" + dtype);
			
			if (html.contains("No Quick Move-In Homes"))
			{
				html = html
						.replaceAll(
								"<option value=\"Townhouse\" >Townhouse</option>| <p>Coming Soon! <a href=\"|<p>coming soon! <a href=\"|no-padding\">\\s*coming soon|QUICK MOVE-IN HOMES</a></li>|<label for=\"moveInHomes\"><span></span>QUICK MOVE-IN HOMES ONLY</label>",
								"");
			}
			html=html.replace("Final Phase! Only 10 Townhomes Remain!", "Final Phase, Only 10 Townhomes Remain")
					.replace("New Home Sites Released in our Final Phase", "New Home Sites Released in Final Phase")
					.replace("new home sites released in our final phase", "new home sites released in final phase")
					.replaceAll("coming soon community in duluth|Single Family Phase II Coming Soon|vip grand|homes reflect|homes or to schedule", "");
			html = html.replace("information on grand openings", "")
					.replaceAll("basements home sites available", "Basement homesites available");

			html = html.toLowerCase().replaceAll("only 2townhomes remain", "only 2 townhomes remain")
					.replace("Coming Soon - 2022", "Coming soon 2022")
					.replace("limited spring move in opportunities","limited opportunities")
					.replaceAll("only 6townhomes remain", "only 6 townhomes remain").replace("townhomes sold out", "")
					.replaceAll("class=\"model-flag bg-blue-cyan\">(.*)?</div>|<li>move in ready homes!�</li>|hickory flat locationmove in ready homes!|our final homes are|incentives and new phase releases|#quickmoveinhomes\">quick move-in hom|news and final opportunities|final homes are open daily for tours|title=\"final phase now selling\"|<p>coming soon! <a href=\"|no-padding\">\\s*coming soon||<br>townhomes sold out!|pre-sale home site|single family phase ii coming soon|title=\"phase ii selling fast\" |townhomes selling fast|our move in ready homes|move-in ready homes has been|on our coming soon home sites and|ew Phase Coming Soon at|Johns Creek will be coming soon|Please register online for details on our coming soon home|amenity grand opening dates|quickMoveInHomes|QUICK MOVE-IN HOMES ONLY|select quick move in ready|move in ready homes,|are sold out|now open|soon to the highly|no quick move-in|move in ready homes", "");
//			priceSec=priceSec.replaceAll("", "");
			
			if(priceSec!=null)
				priceSec = priceSec.replaceAll("To receive ongoing updates on new phases ", "")
				.replaceAll("class=\"model-flag bg-blue-cyan\">(.*)?</div>","");
			html=html.replace("To receive ongoing updates on new phases", "")
					.replaceAll("new homes coming soon to alpharetta - 2022|new homes coming soon to gwinnett - 2022", "New homes coming soon 2022");
			String propstatus = U.getPropStatus((html+priceSec+sec)
					.replaceAll("\"[c|C]oming|sold out in current phase|>New homes coming soon 2022!|meta content=\"New homes coming soon 2022|Sold Out in Current Phase|[b|B]uilding [j|J]ust [r|R]eleased|</li><li>Move In Ready Homes!�</li><li>|<li>move in ready homes!�</li>|hickory flat locationmove in ready homes!|\\d Available Homes|Limited Spring Move In Ready Homes Available|lender on our Final Phase| Move in ready homes late Spring 2021|<li>Move In Ready Homes!</li>|<li>Move In Ready Homes! </li>|Limited Quick Move in Homes Available|Move In Ready Homes!&nbsp|quick move in homes|move in ready homes|\\d+ available homes|final chance to call|Final Chance To Call|<br /> \\d+ available homes</div>|new phase releases and special events|New Phase Coming Soon to Bellmoore|townhomes coming soon|townhomes \\(sold out\\) and courtyard designs \\(sold", ""));
			propstatus=propstatus.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
			propstatus=propstatus.replace("Coming 2022, Coming Soon", "Coming 2022");
			
			U.log("propstatus== "+propstatus);
//			U.log(sec);
//			U.log(Util.matchAll(html, "[\\s\\w\\W]{100}Coming soon[\\s\\w\\W]{100}",0));

		//U.writeMyText(html);0
//			U.log(propstatus);
			
			
			
			// info =
			
			
//			U.log("priceSec==="+priceSec);
			String rem = U.getSectionValue(html,"<p>SEARCH AVAILABLE HOMES</p>","<div class=\"small-12 columns\">");
			// U.log(html);
			html=html.replace("johns creek homes from the $300", "");
			if (rem != null)
				html = html.replace(rem, "");
			html = html.replace("0s", "0,000").replace("899k", "899,000").replace("0k", "0,000").replace("$1 million","$1,000,000").replace("$1 Million", "$1,000,000");
			if(priceSec!=null)
				priceSec=priceSec.replace("0's","0,000" ).replace("0s", "0,000").replace("$358K", "$358,000");
			
			if(allAvailHomesData!=null) {
				allAvailHomesData=allAvailHomesData.replaceAll("Priced At <span class=\"text-dark-cyan\">$", "Priced At $");
			}
			if(html.contains("<link href=\"https://assets.calendly.")) {
				String remSec = U.getSectionValue(html, "<link href=\"https://assets.calendly.", "<script type=\"text/javascript\" id=\"\">webVitals");
				html = html.replace(remSec, "");
			}
			
		
			String[] prices = U.getPrices(priceSec+sec+qHtml+allAvailHomesData,"\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+", 0);

			
//			U.log("MMMMMMMMM "+Util.matchAll( priceSec, "[\\s\\w\\W]{80}538,445[\\s\\w\\W]{80}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll( sec, "[\\s\\w\\W]{50}538,445[\\s\\w\\W]{30}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll( qHtml, "[\\s\\w\\W]{50}538,445[\\s\\w\\W]{30}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll( allAvailHomesData, "[\\s\\w\\W]{50}538,445[\\s\\w\\W]{30}", 0));

			String minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			String maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log(prices[0]+"\t"+prices[1]);

			String sqft[] = U
					.getSqareFeet(
							html + sec+allAvailHomesData+qHtml,
							"<span>\\d,\\d{3}-\\d,\\d{3}</span>|<span>\\d,\\d{3}</span>|<span>\\d,\\d{3} - \\d,\\d{3}</span>|[s|S]quare [ft|FT]*\\.\\s*-\\s*<span data-col=\"0\">\\d,\\d{3}\\s*–\\s*\\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}</span></li>|Square FT. - <span data-col=\"1\">\\d,\\d{3}|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} square feet|Square FT. - <span data-col=\"0\">\\d,\\d{3}</span>",
							0);
			String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			String note = U.getnote((html + sec).replaceAll("title=\".*\"| presale events", ""));
			
			propstatus=propstatus.replaceAll("Iii", "III");
		
/*			if(quickCount>0){
				
				propstatus=propstatus+", Quick Move-In Home";
				propstatus=U.getPropStatus(propstatus);
			}
*/			if(html.contains("<div class=\"model-flag bg-dark-cyan\">quick move-in</div>")){
				if(propstatus == ALLOW_BLANK) propstatus = "Quick Move In Homes";
				else if(propstatus != ALLOW_BLANK && !propstatus.contains("Quick Move")) propstatus += ", Quick Move In Homes";
			}
			System.out.println("Property Status:" + propstatus);
			propstatus = propstatus.replace("Quick Move-in", "Quick Move In Homes");
			
			if(url.contains("https://theprovidencegroup.com/new-homes/ga/alpharetta/central-park-at-deerfield-township/6808/")) 
				propstatus = "New Home Sites Released In Final Phase";
	
			
			if(url.contains("/roswell-towneship"))propstatus ="Sold Out";
			if(url.contains("ga/johns-creek/bellmoore-park/6807/"))propstatus =ALLOW_BLANK;
			add[0]=add[0].replaceAll("&nbsp;", " ");
			
			if(propstatus!=null)
				propstatus = propstatus.replace("Just Released, New Home Sites Just Released", "New Home Sites Just Released")
				.replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon")
				.replace("New Home Sites Released, New Home Sites Released In Final Phase", "New Home Sites Released In Final Phase");
			if(url.contains("https://theprovidencegroup.com/new-homes/ga/duluth/evanshire/8519/") )propstatus="Coming Soon 2022";
			if(url.contains("new-homes/ga/johns-creek/bellmoore-park/6807/"))proptype=proptype+", Courtyard Home";

			//--------------------- Number of Units -------------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			String totalUnits = ALLOW_BLANK;
			
			if(tHtml.contains("position-absolute border rounded-circle")) {
				
				String[] getCount = U.getValues(tHtml, "<div class=\"position-absolute border rounded-circle", ">");
				U.log("getCount.length: "+getCount.length);
				totalUnits = String.valueOf(getCount.length); 
			}
			
			units = totalUnits;
			U.log("Units Count: "+units);
			
			data.addCommunity(commName.trim(), url, communitytype);
			data.addAddress(add[0].trim(), add[1].replaceAll("ïº�","").trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(propstatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;
//		}catch(Exception e) {}
	}
}