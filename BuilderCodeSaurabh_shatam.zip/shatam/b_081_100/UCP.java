package com.shatam.b_081_100;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class UCP extends AbstractScrapper {
	public int k = 0;
	static int j = 0;
	public int inr = 0;
	static String Builder_name = "UCP - Benchmark Communities";
	static String HOME_URL = "http://www.unioncommunityllc.com/";
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new UCP();
		a.process();
		a.data().printAll();
		FileUtil.writeAllText(	U.getCachePath()+"UCP - Benchmark Communities.csv", a.data()	.printAll());
	}

	public UCP() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger(Builder_name);
	}

	ArrayList<String> comm = new ArrayList<String>();

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://benchmarkcommunities.com/");
		U.log("hello2");
		String region[] = U.getValues(html,"<li class=\"dropdown-submenu\"><a href=\"", "\">");
		U.log("hello3" + region.length);
		for (String regionUrl : region) {
//			 U.log("Region Url : " + regionUrl);
			//U.log("hello1");
			if (regionUrl.contains("Our-Team"))continue;
			
			String regionHtml = U.getHTML(regionUrl);
			//U.log( "ggggg" + regionUrl);
			String sectionCommunities = U.getSectionValue(regionHtml,	"Our Communities</", "id=\"dnn_TopPaneFull\"");
			//U.log(sectionCommunities);
			
			sectionCommunities = sectionCommunities.replace("End_Module",	"<script type");
			String sectionComms[] = U.getValues(sectionCommunities,	"community_marker ui-draggable", "<script type");

			 U.log("Region Community: " + sectionComms.length);
			for (String sec1 : sectionComms) {

				String url = U.getSectionValue(sec1, "<a href=\"", "\"");
//				 U.log(url);
				comm.add(url);
				adDetails(url, sec1);
			}
			// break;s
		}

	}

	public void adDetails(String url, String commSec) throws Exception {
		// for (String url : comm) {
		// if(j==30)
		{
			U.log("::::::::::::"+j+"::::::::");
			
			
		//	 if(!url.contains("https://KensingtonPark.BenchmarkCommunities.com"))return;
		

			url = url.replace("http", "https");
			url=url.replace("https://elements.benchmarkcommunities.com", "http://elements.benchmarkcommunities.com");
			//U.log(commSec);

			U.log(url);
			String html = U.getHTML(url);
			
			ArrayList<String> purl=null;
			if(html.contains("Floorplans")){
				purl = com.shatam.utils.Util.matchAll(html,	"<li><a href=\"(" + url+ "/Plans/[Floorplans|Directions]*(.*?))\"", 1);
			}

			String priceHtmlData = "";
			String directionUrl = "";
			for (String priceUrl : purl) {
				// U.log("========" + priceUrl);
				if (!priceUrl.contains("Features"))
					if (!priceUrl.contains("Gallery")) {
						 U.log("Price Url: " + priceUrl);
						String priceHtml = U.getHTML(priceUrl);
						priceHtmlData += U.getSectionValue(priceHtml, "<h1>", "Back to plans");
					}
			}
			String floorPlan = url;
			if (html.contains("Plans/Floorplans")) {
				floorPlan = floorPlan + "/Plans/Floorplans";
			}
			String name;
			String floorHtml = U.getHTML(floorPlan);
			// http://glenmoor.benchmarkcommunities.com/Plans/Floorplans
			if (url.contains("https://SymphonyRidge.BenchmarkCommunities.com")) {
				name = U.getSectionValue(html, "<title>", "-").trim();
			} else {
				name = U.getSectionValue(html, "<title>", "|");
			}
			String quick = Util.match(html, "<a href=\"(" + url+ "/Quick-Delivery-Homes)\">Quick Delivery Homes</a></li>",	1);

			String quickHtml = ALLOW_BLANK;
			if (quick != null) {
				// U.log("Quick====" + U.getCache(quick));
				quickHtml = U.getHTML(quick);
			}
			if (quickHtml != null)
				quickHtml = quickHtml.replaceAll("Oversized\\s+\\d,\\d+", "");
			
			
			 //============ Plans Collection =======================
			 String planCollectionHtmls = null;
//			 if(url.contains("https://eastgarrison.benchmarkcommunities.com")){
				 String planSec = U.getSectionValue(html, "class=\"dropdown-toggle\">Plans", "<li class=\"dropdown\">");
				 if(planSec != null){
					 String [] planCollectionUrls = U.getValues(planSec, "submenu\"><a href=\"", "\"");
					 for(String planCollectionUrl : planCollectionUrls){
						 if(planCollectionUrl.contains("/Floorplans"))continue;
						 if(planCollectionUrl.contains("/Gallery"))continue;
						 U.log(">>>>>>"+planCollectionUrl);
						String planCollectionHtml = U.getHTML(planCollectionUrl);
						planCollectionHtmls += U.getSectionValue(planCollectionHtml, "class=\"Normal\">", "</ul>");

					 }
				 }
//			 }
			
				 //============ Floor Plan Collection=======================
				 String floorPlanHtmls = null;
				 planSec = U.getSectionValue(html, "class=\"dropdown-toggle\">Plans", "<li class=\"dropdown\">");
				 if(planSec != null){
					 String [] floorPlanCollectionUrls = U.getValues(planSec, "submenu\"><a href=\"", "\"");
					 for(String floorPlanCollectionUrl : floorPlanCollectionUrls){
						 if(floorPlanCollectionUrl.contains("/Gallery"))continue;
						 if(!floorPlanCollectionUrl.endsWith("/Floorplans"))continue;
						
						 U.log("Floor-->>>>>>>"+floorPlanCollectionUrl);
						String floorPlanHtml = U.getHTML(floorPlanCollectionUrl);
						floorPlanHtmls += U.getSectionValue(floorPlanHtml, "_XModPro_ctl00_ctl01__UP\">", "<div class=\"container\">");
					 }
				 }
			String planHtml = com.shatam.utils.Util.match(html,"<li class=\"dropdown\"><a href=\"(" + url	+ "/Plans[/Floorplans]*)\"", 1);

			if (planHtml != null)
				planHtml = U.getHTML(planHtml);

			String badContain = U.getSectionValue(html,"<h5>Other Benchmark Communities In The Area</h5>",	"<footer>");
			if (badContain != null)
				html = html.replace(badContain, "");
			html = html + commSec;
			html = html.replaceAll("0&rsquo;s", "0,000");
			html = html.replaceAll("0s", "0,000");
			quickHtml = quickHtml.replaceAll("Includes \\$\\d{2},\\d{3} in upgrades!|16,399 sq. ft. homesite", "");
			String pHtml = html + quickHtml + floorHtml;
		
			commSec = commSec.replace("0's", "0,000");
			// U.log("###########3"+pHtml);
			
			//================ Price ==========================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U.getPrices(pHtml + commSec+floorPlanHtmls,	
					"\\$\\d{1},\\d{3},\\d{3}|at \\$\\d{3},\\d{3}|\\$\\d{3}\\,\\d+|\\$\\d{3},\\d+|\\$\\d{3}\\,\\d+", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			//==================== Sqft ==========================
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;

			String[] sq = U.getSqareFeet(html + quickHtml + planHtml + priceHtmlData + commSec+planCollectionHtmls+floorPlanHtmls,
							"from \\d,\\d{3} \\&ndash; \\d,\\d{3} sq. ft|strong>\\d,\\d{3} sq. ft.|from \\d,\\d{3} to \\d,\\d{3} sq. ft.|nearly \\d,\\d{3} square feet|\\d,\\d+ sq. ft|\\d+,\\d+ to over \\d+,\\d+ square feet|\\d+,\\d+ sq ft|\\d+,\\d+ square feet|\\d+,\\d+ sq. ft.|\\d,\\d+ to \\d,\\d+ sq. ft",
							0);
			minSqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
			maxSqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			//-----------Address-----------------
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };

			String geo = "FALSE";
			url = url.replace("com/", "com");
			directionUrl = Util.match(html, "<li><a href=\"(" + url+ "/Location/Directions-Hours)\">", 1);
			U.log("sfjlksjadflkj\n" + directionUrl);
			String dirHtml = U.getHTML(directionUrl);

			String adds = U.getSectionValue(dirHtml,	"<div class=\"frame\"><iframe", "</div>");

			if (adds == null) {
				// U.log(U.getCache(directionUrl));

				adds = U.getSectionValue(dirHtml,	"<div class=\"frame\"><iframe", "\"");
			}

			// U.log("My log");
			dirHtml = dirHtml.replace("Antioch TN", "Antioch,TN");
			String address = U.getSectionValue(dirHtml,"class=\"mapaddress\">", "</p>");

			if (address == null) {

				address = U.getSectionValue(dirHtml, "Address:</strong><br />",	"</p>");

			}
			if (address == null) {
				address = U.getSectionValue(dirHtml, "lass=\"mapaddress\">",	"</a></p>");
			}
			if(address == null){
				address=U.getSectionValue(dirHtml, "class=\"map address\">", "</a></p>");
			}
			
			if(address == null){
				address=U.getSectionValue(dirHtml, "class=\"map address\">", "</a><br />");
			}
			
			U.log("My log: " + address);
			

			if (address != null) {
				//address=address.replace("<a class=\"mapaddress\" href=\"https://maps.google.com?saddr=Current+Location&amp;daddr=7001+E Clinton+Ave,+Fresno,+CA+93727\">","");
				String remLink=Util.match(address, "<a class=\"mapaddress\" href=\"(.*?)\">");
				if(remLink!=null){
					U.log("Suucess remLink");
					address=address.replace(remLink, "");
				}
				
				address = address.replace("<br />", ",");
				address = address.replace("</a>", "");
				if(!address.contains(", CA")){
					address = address.replace(" CA ", ", CA ");
				}
				// add[0]=address;
				U.log("address Sec::"+address);
				String addse[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,	ALLOW_BLANK };
				address = address.replace("TN,", "TN").replace("24571 Silver Cloud Court, Suite 102", "24571 Silver Cloud Court");

				addse = U.findAddress(address);
				U.log("Addrresssss::"+Arrays.toString(addse));
				if (addse != null)
					add = addse;

				if (add[0] == ALLOW_BLANK) {
					String addse1[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
					addse1 = U.getAddress(address);
					if (addse1 != null)
						add = addse1;
				}
			}
			//----address from maps link--------
			if(add[0]==ALLOW_BLANK && dirHtml.contains("saddr=")){
				String mapAddSec = U.getSectionValue(dirHtml, "<a href=\"https://maps.google.com?saddr=Current+Location&amp;daddr=", "\"");
				if(mapAddSec!=null){
					mapAddSec = mapAddSec.replace("+", " ");
					add = U.getAddress(mapAddSec);
					U.log("mapAddSec::::::"+Arrays.toString(add));
				}
			}
			
			if (adds != null) {
				// U.log("***********" + U.getPageSource(directionUrl));

				adds = adds.replace("%21", "!");
				String lng = U.getSectionValue(adds, "2d", "!");
				String lat = U.getSectionValue(adds, "3d", "!");

				if (lat != null && (add[0] == ALLOW_BLANK || add[0].equalsIgnoreCase("Coming Soon"))) {
					latlng[0] = lat;
					latlng[1] = lng;
					add = U.getAddressGoogleApi(latlng);
					geo = "TRUE";
				}

				latlng[0] = (lat == null) ? ALLOW_BLANK : lat;
				latlng[1] = (lng == null) ? ALLOW_BLANK : lng;

			}

			

			if (latlng[0] == ALLOW_BLANK && add[0] != ALLOW_BLANK) {
				latlng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}

			if (add[3].length() < 5) {
				String[] addr = U.getAddressGoogleApi(latlng);
				add[3] = addr[3];
				geo = "TRUE";
			}

			
			
			  if (url.contains("https://HarvestGrove.BenchmarkCommunities.com"))
			 { minPrice = "$200,000"; 
			 
			 } // http://TheEstates.BenchmarkCommunities.com
			 
			 if (url.contains("https://diamondcrest.benchmarkcommunities.com")) {
			 minPrice = "$400,000";maxSqf = "3364"; }
			 
			 if (url.contains("https://TheHeights.BenchmarkCommunities.com"))
			 { minPrice = "$300,000"; }
			 
			 if(url.contains("https://cerrato.benchmarkcommunities.com")){
				 minPrice = "$400,000"; //from image
			 }
			 
			 if(url.contains("https://keenelanddowns.benchmarkcommunities.com")) {
			 minPrice = "$100,000"; } 
			 if(url.contains("https://cantera.benchmarkcommunities.com")) {
			  minSqf = "2791"; } 
			 if(url.contains("https://Sundance.BenchmarkCommunities.com")) {
				  minPrice = "$200,000";  }
			 if(url.contains("https://TheEstates.BenchmarkCommunities.com")) 
			 {
			 maxSqf = "3701"; }
			 
			 if(url.contains("https://PhoenixCrest.BenchmarkCommunities.com"))
			 {
				 minPrice="$700,000"; //from image
			 }
			
			
			 //================ Derived Community Type ==================
			html = html.replaceAll(	"Ranch Elevation|Ranch\"/>|Ranch</div>|announce the Grand Opening| model home is now under construction","");
			html = html.replaceAll("luxury.jpg", "");

			quickHtml=quickHtml.replace("Single-story"," 1 story ");
			html=html.replace("single and two story"," 1 story , 2 story ");
			
			String dType = U.getdCommType((html+quickHtml+planCollectionHtmls+priceHtmlData).replaceAll("Ranch Elevation|Rancho",""));

			//================= Property Status ============================
			html = html.replace("just released our final phase", "just released final phase");
			html  = html.replaceAll("CommunitiesInAreaSubtitle\">Now Selling!</div>|built homes are sold out|last opportunity to purchase|model sales release have sold out | upcoming grand opening |Wooded home sites available", "");
			
			String status = U.getPropStatus(html+ commSec.replaceAll("Wooded home sites available|<div class=\"CommunitiesInAreaSubtitle\">Coming Soon!</div>|Priority List is now open|announce the Grand Opening|about our Grand Opening",""));
			String html2 = U.getHTML(url + "/Quick-Delivery-Homes");
			//U.log(html);
			if (!html2.contains("<section id=\"delivery-homes\">")) {
				U.log("Success quick");
				status = status.replaceAll("Quick Delivery Homes", "No Quick Delivery Homes");
			}
			 if(url.contains("https://MastersView.BenchmarkCommunities.com")){
				 status = status + ", Final Opportunity";
			 }
			//================ Note ============================
			String note=U.getnote(html);
		//	status=status.replaceAll("Sold Out|Coming Soon","");
			if(status.length()<4)
				status=ALLOW_BLANK;
			U.log("address:- "+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			
			//============== Property Type ========================
			html=html.replaceAll("VILLAGE|Village|Villlage|village|Zero HOA|zero HOA|No HOA", "");
			floorHtml = floorHtml.replaceAll(" loft | opt. loft", " opt. loft home");
			//U.log(html);
			String propType=ALLOW_BLANK;
			propType=U.getPropType((html+floorHtml+quickHtml+planCollectionHtmls+priceHtmlData+floorPlanHtmls).replaceAll("VILLAGE|Village|Villlage|village|_Cottage_", ""));  //
			if(propType.contains("Townhouse") && propType.contains("Townhome")){
				propType=propType.replace("Townhouse,", "");
			}
			propType=propType.replace("Townhouse,Townhome", "Townhome");
			
			html = html.replace("restaurants, golf and the famed", "restaurants, golf course and the famed");
			
			data.addCommunity(name, url, U.getCommunityType(html));
			data.addAddress(add[0].replace(".", "").replace(",", ""), add[1],add[2].trim(), add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(status.replace("Ii", "II"));
			data.addNotes(note);
			// break;
		}
		j++;
	}
}
