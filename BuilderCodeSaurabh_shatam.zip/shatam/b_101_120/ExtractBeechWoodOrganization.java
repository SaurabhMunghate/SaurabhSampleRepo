/** @author Priti
 *  @date Sept/2016
 */

package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.james.mime4j.codec.EncoderUtil.Usage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractBeechWoodOrganization extends AbstractScrapper {
	int k = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractBeechWoodOrganization();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Beechwood Homes.csv", a.data().printAll());
	}

	public ExtractBeechWoodOrganization() throws Exception {

		super("Beechwood Homes", "https://www.beechwoodhomes.com/");
		LOGGER = new CommunityLogger("Beechwood Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHtmlHeadlessFirefox("https://beechwoodhomes.com/", driver);
		String remove=U.getSectionValue(html, "<section class=\"elementor-section elementor-top-section elementor-element elementor-element-f0385df elementor-section-boxed elementor-section-height-default elementor-section-height-default\" data-id=\"f0385df\"", "</section>");
		//String comSec[] = U.getValues(html, "<h3 class=\"h3",	"</h3>");//"<h3 class=\"mb-2\">");
		if(remove!=null)
		html=html.replace(remove, "");
		//String comSec[] = U.getValues(html, "<a class=\"elementor-cta",	"</h4>");
		String comSec[] = U.getValues(html, "<a class=\"elementor-cta\"",	"</a>");
		U.log("No. of communities:" + comSec.length);
//		String latlngSections[] = U.getValues(html, "\"comm\":\"", "id\":");
//		U.log("latlngSections length::" + latlngSections.length);

		for (String comInfo : comSec) {
			comInfo = comInfo.replaceAll("href=\"javascript:", "");
			//String comName = U.getSectionValue(comInfo, "<h4 class=\"elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow\">", "</h4>");
			String comName = U.getSectionValue(comInfo,"<h4 class=\"elementor-cta__title elementor-cta__content-item elementor-content-item\">","</h4>");
			//U.log(comName);
			if(comName != null)
				comName = comName.replaceAll("<br> |<a href=(.*)?\">|</a>", "");
//			U.log(">>"+comInfo);
//			for (String latlngSec : latlngSections) {
////				U.log(latlngSec);
//				if (latlngSec.contains(comName)) {
//					addInfo(comName, comInfo, latlngSec);
//				} 
///*				else {
//					latlngSec
//					addInfo(comName, comInfo, ALLOW_BLANK);
//				}
//*/			}
			// break;
			
			String comUrl = U.getSectionValue(comInfo, "href=\"", "\""); 
			if(!comUrl.contains("www.beechwoodhomes.com")) {
				comUrl="https://www.beechwoodhomes.com/"+comUrl;
			}
			if(comUrl.contains("https://www.oakridgebeechwood.com/")) {
				comUrl="https://www.oakridgebeechwood.com/";
			}
			if(comUrl.contains("https://www.beechwoodcarolinas.com/"))
				comUrl="https://www.beechwoodcarolinas.com/";
			if(comUrl.contains("https://beechwoodhomes.com/the-selby/"))
				comUrl="https://beechwoodhomes.com/the-selby/";
//				U.log(">>"+comInfo);
			U.log(comName);
				U.log(comUrl);
			String quickHtml=U.getHTML("https://www.beechwoodhomes.com/quick-move-in/")	;
				
			//if(comUrl.contains("/meadows"))comName = "Country Pointe Meadows Yaphank";
			//+U.getSectionValue(comInfo, "<h2 class=\"modal-title\"><a href=\"", "\"");
			
		//	LOGGER.AddCommunityUrl("https://beechwoodhomes.com/plainview/retail"+":::::Redirect to plainview retail page");
			
			if(comUrl.contains("https://www.beechwoodcarolinas.com/")) {
				
				addInfo("https://www.beechwoodcarolinas.com/ferncliff/", "Ferncliff At Cotswold", comInfo,quickHtml);
				addInfo("https://www.beechwoodcarolinas.com/lakeside-pointe/", "Lakeside Pointe", comInfo,quickHtml);
				addInfo("https://www.beechwoodcarolinas.com/weddington-glen/", "Weddington Glen", comInfo,quickHtml);
				addInfo("https://www.beechwoodcarolinas.com/broadmoor/", "Broadmoor", comInfo,quickHtml);
				
			}else
				addInfo(comUrl, comName, comInfo,ALLOW_BLANK);
		}
///		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private void addInfo(String comUrl, String comName, String comInfo,String quickHtml) throws Exception {
//		if(j >= 7)
		{
			// ------Com Url and Com Html----------
//			if(comUrl.contains("countrypointeridge"))
//				comUrl = "https://countrypointeridge.com/";
//			if(comUrl.contains("tidesnyc"))
//				comUrl = "https://tidesnyc.com";
//			if(comUrl.contains("oakridgebeechwood"))
//				comUrl = "https://oakridgebeechwood.com/";
			
//			TODO:Single-exe
		//if(!comUrl.contains("marina-pointe")) return;  //-------- Single com execution
				
//			U.log(comInfo);
			if(comUrl.contains("https://www.beechwoodhomes.com/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjI4NzE3IiwidG9nZ2xlIjpmYWxzZX0%3D")) {
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Redirected to main page");
				return;
			}
			if(comUrl.contains("https://www.beechwoodhomes.com/country-pointe-plainview/retail/")||comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/community/")) {
				LOGGER.AddCommunityUrl(comUrl+"=========Retail");
				return;
			}
			
			comName=comName.replace("Country Pointe Meadows | Yaphank", "Country Pointe Meadow");
			 comName=comName.replace("Oak Ridge | Saratoga NY", " Oak Ridge");
			 comName=comName.replace("Meadowbrook Pointe Gardens | East Meadow", "Meadowbrook Pointe Gardens");
			 comName=comName.replace("Oneck Landing | Westhampton Beach","Oneck Landing");
			 comName=comName.replace("The Vanderbilt | Westbury", "The Vanderbilt");
			 comName=comName.replace("The Selby | Westbury", "The Selby");
			 comName=comName.replace("The Latch | Southampton Village", "The Latch");
			 comName=comName.replace("Meadowbrook Pointe East Meadow","Meadowbrook Pointe");
			 comName=comName.replace("Marina Pointe East Rockaway", "Marina Pointe")
					 .replace("Country Pointe Estates<br> Westhampton Beach", "Country Pointe Estates");
				U.log("comName: "+comName);
//			if(comUrl.contains("/the-selby") || comUrl.contains("/latch"))return;//redirect
			if(comUrl.contains("/find/?id=8361") || comUrl.contains("null") || comUrl.contains("javascript"))return; //redirect
			 
					 
					 
			U.log("\n\nStarted Here:::::::::::::;; "+comUrl+" j = "+j);
			
			if (this.data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "------repeated-----");

				return;
			}
			
			LOGGER.AddCommunityUrl(comUrl);
			
			//comUrl = comUrl.replace(".com//", ".com/");
			String comHtml = U.getHtml(comUrl, driver);
			comHtml = U.removeComments(comHtml);
			String contactUrl=ALLOW_BLANK;
			String contactHtml=ALLOW_BLANK;
			String addSec;
			ArrayList <String> al=new ArrayList<>();
			String quick[]=U.getValues(quickHtml,"<h3 class=\"elementor-heading-title elementor-size-xl\">","<div class=\"elementor-button-wrapper\">");
//			for(String quickHome:quick) {
//				al.add(quickHome);
//			}
			//U.log("QUICK SIZE"+al.size());
			//-----------allHomesData----------
			String allHomesData = ALLOW_BLANK;
			String homeHtml=ALLOW_BLANK;
			String lifestyle=ALLOW_BLANK;
			 HashSet<String> set=new HashSet<String>(); 
			 HashSet<String> set2=new HashSet<String>(); 
			 String navUrl;
			 String floordata=ALLOW_BLANK;
			 String homesData=ALLOW_BLANK;
//			String navSec = U.getSectionValue(comHtml,"data-element_type=\"section\" id=\"od-menu\"","<span class=\"elementor-screen-only\">Menu</span>");
//			//String navSec[] = U.getValues(comHtml, "<li class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item", "\">");
//			if(navSec==null) {
//				navSec=U.getSectionValue(comInfo,"<nav class=\"elementor-nav-menu--dropdown elementor-nav-menu__container\" role=\"navigation\" aria-hidden=\"true\">","</nav>");
//			}
//			
//			
//			
//			
//			U.log(navSec);
//			if(navSec!=null)
			String[] navUrls=U.getValues(comHtml, "href=\"", "\"");
			//U.log("comHtml: "+comHtml);
			U.log("navUrl : "+navUrls.length);
			for(String Url:navUrls) {
				
				set.add(Url);
			}
			U.log("SIZE"+set.size());
					 
			Iterator<String> itr=set.iterator(); 
			 while(itr.hasNext()) {
				navUrl= itr.next();
				
				if(navUrl.contains("apartments")||navUrl.contains("/homes")||navUrl.contains("homes/")|| navUrl.contains("apartments")||
						navUrl.contains("condominium-collection")||navUrl.contains("villas")||navUrl.contains("/carriage-homes")){
					
//					U.log("HomenabvUrl"+navUrl);	
//					if(!navUrl.contains("https://beechwoodhomes.com"))
//					homeHtml += U.getHTML("https://beechwoodhomes.com"+navUrl);
//					else {
						homeHtml+= U.getHTML(navUrl);
						
						 HashSet<String>homes=new HashSet<String>();
						 
						 String homesUrl[]=U.getValues(homeHtml, "<a href=\"","\"");
						 for(String homeUrl:homesUrl) {
//							 U.log("homeUrl: "+homeUrl);
							 if(homeUrl.contains("model/")||homeUrl.contains("/homes")||homeUrl.contains("homesite"))
							 homes.add(homeUrl);
						 }
						 Iterator<String> itr2=homes.iterator();
						 while(itr2.hasNext()) {
							 String home=itr2.next();
							 floordata = U.getHTML(home);
							//only homes data
							 if(home.contains("/homes")||home.contains("/homesite")) {
								 homesData += U.getHTML(home);
							// U.log("MMMMMMM "+Util.matchAll((homesData), "[\\s\\w\\W]{30}2 Levels[\\s\\w\\W]{30}", 0));
							 }
						 	}
						 }
				
					
				
				
				if(navUrl.contains("/lifestyle")||navUrl.contains("amenities")||navUrl.contains("the-clubhouse")){
					
  				U.log("lifestyle url"+ navUrl);
//					if(!homeUrl.contains("https://beechwoodhomes.com"))
//						lifestyle += U.getHTML("https://beechwoodhomes.com"+navUrl);
//					else
						lifestyle += U.getHTML(navUrl);
				//}
				}
				
				
				if(navUrl.contains("/contact")||navUrl.contains("/contact-us")) {
					U.log("CONTACT Url"+navUrl);
					contactUrl=navUrl;
					if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/"))
						contactUrl="https://www.beechwoodhomes.com/tidesnyc/contact/";
					
					
//					if(contactUrl.contains(comUrl)) {
//					  contactHtml=U.getHTML(contactUrl);
//					  
//					}
//					else {
						//contactUrl=comUrl+contactUrl;
						contactHtml+=U.getHTML(contactUrl);
					//}
				}
				
				
			 }
			
                ///Price
			 String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			 String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			 String[] price= {ALLOW_BLANK,ALLOW_BLANK};
			 String lat= ALLOW_BLANK;
			 String lng= ALLOW_BLANK;
			 comHtml=comHtml.replace("0s", "0,000").replace("1million", "1,000,000").replace("4million", "4,000,000");
			 U.log(comHtml.matches("Home Price: $5,749,000"));
			 homeHtml = (homeHtml).replace("Home Price: $7,500,000 to 9,900,000", "");
			 U.log("LLLLL"+Util.matchAll(homeHtml, "[\\w\\W\\s]{50}1,815,000[\\w\\W\\s]{50}",0));
			 homeHtml=homeHtml.replace("Lower Corner Villa | ","Lower Corner Villa $");
			 U.log("LLLLL2"+Util.match(homeHtml, "$729,000"));
			 price=U.getPrices((comHtml+homeHtml+floordata).replace("Priced from the upper <sup>$</sup>1mil to <sup>$</sup>1.8mil</p>", "Priced from the upper $1,000,000 to $1,800,000"),"Home Price: \\$\\d{1},\\d{3},\\d{3}|Starting at \\$\\d{3}\\d{3}|Priced From: \\$\\d,\\d{3},\\d{3}|"
			 		+ "Starting From <sup>\\$</sup>\\d{6}|Starting From <sup>\\$</sup>\\d{3},\\d{3}|STARTING FROM <SUP>\\$</SUP>\\d,\\d{3},\\d{3}</strong>|Starting at \\$\\d,\\d{3},\\d{3}|Priced from the upper \\$\\d,\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|Priced from the low \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|Priced from the low \\$\\d{3},\\d{3} to \\$\\d{3}\\d{3}|Leases starting from \\$\\d,\\d{3}|Home Price: \\$\\d,\\d{3}\\d{3}|"
			 		+"<strong>\\d{3},\\d{3}</strong>|Offered at \\d,\\d{3},\\d{3}|"
			 		+ "Priced From: \\$\\d{6}|Priced From: \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3} – \\$\\d,\\d{3},\\d{3}|Offered at \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d,\\d{3},\\d{3}", 0);
			 minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			 maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
 
			 U.log("Prices min  "+price[0]+" max  "+price[1]);
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeHtml+floordata, "[\\s\\w\\W]{30}Priced From: \\$\\d,\\d{3},\\d{3}[\\s\\w\\W]{30}", 0));
			 
			 //SQFT
			 String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			 U.log("ssss"+Util.match(homeHtml+comHtml,"4792 Sq. Ft."));
			
			 String[] sqft=U.getSqareFeet((homeHtml+floordata+comHtml).replaceAll("1498", "1,498"),
					 "\\d{4} – \\d{4} sq ft |from \\d,\\d{3} – \\d,\\d{3} sq. ft|The spacious \\d{4} – \\d{4} sq.ft.|\\|\\s+\\d,\\d{3} Sq. Ft.|spacious \\d{4} – \\d{4} sq\\.ft|\\d{3} – \\d{3} Sq. Ft.|\\d{5}+ sf floorplans|"
			 		+ "\\d{4} Sq\\. Ft\\.|\\d{4} SQ\\. FT\\.|\\d{1},\\d{3} Sq Ft|\\d{4} Sq\\. Ft\\.|"
			 		+"at \\d,\\d{3}\\+ square feet|"
			 		+ "<div class=\"elementor-widget-container\">\\s+\\d,\\d{3}\\s+</div>|\\d,\\d{3} – over \\d,\\d{3} square feet",0); //|\\d{3} Sq. Ft
			
			// String[] sqft = U.getSqareFeet((comHtml+homeHtml+floordata).replaceAll("<span class=\"no-decoration\">2,878 sq ft</span>", ""),
			//			"\\d,\\d{3} sq ft|>\\d,\\d+ sq ft</span>|\\d,\\d{3} sq.ft. Living|from \\d{3,}\\+ sq ft to \\d,\\d{3}\\+ sq ft|\\d,\\d{3}\\+ sq ft to \\d,\\d{3}\\+ sq ft.|align-middle living\">\\d{3}\\+</td>|align-middle living\">\\d,\\d{3}\\+</td>|Grand Total: <span><strong>\\d{4}|\\d+,\\d{3}	sq. ft.|Total Sq.Ft.<strong>\\d{4}|total\">\\d{4}|\\d{1},\\d{3} square feet|\\d{3,4} Sq. Ft|Total - \\d+,\\d{3} sq. ft|\\d,\\d{3} sq.ft|>\\d{3} sq.ft.|living\">\\d,\\d{3}|living\">\\d{3}|\\d{3} – \\d{3} Sq. Ft.",0);
			 
			 minSqf = (sqft[0] == null)? ALLOW_BLANK :sqft[0];
			 maxSqf = (sqft[1] == null)? ALLOW_BLANK :sqft[1];
//			 
			 U.log("SQFT "+sqft[0]+" "+sqft[1]);
			 
		//	 U.log(">>>>>>>>>>>>"+Util.matchAll(homeHtml+floordata+comHtml, "[\\s\\w\\W]{30}3100[\\s\\w\\W]{30}", 0));
			 
			//// ------Property Status
			 String status=ALLOW_BLANK;
			 
			 comHtml = comHtml.replaceAll("JUNIPER RESTAURANTS - NOW OPEN|information on this limited opportunity", "")
					 .replaceAll(">More Info Coming Soon<", "");
			comInfo = comInfo.replaceAll(">More Info Coming Soon<", "");
					 
			String MyStatusSec=U.getSectionValue(comInfo, "<div class=\"elementor-ribbon-inner\">","</div>");	
			if(MyStatusSec != null) {
				MyStatusSec = MyStatusSec.replace("1 Home Remaining", "Only 1 Home Remaining");
			}
			U.log("my stat sec"+MyStatusSec);
			comHtml=comHtml.replace("JUNIPER RESTAURANT - NOW OPEN","");
			 status=U.getPropStatus(comInfo+comHtml+MyStatusSec);
			U.log("MMMMMMM "+Util.matchAll((comInfo+comHtml+MyStatusSec), "[\\s\\w\\W]{30}COMING SOON[\\s\\w\\W]{30}", 0));
			 
			 Iterator<String> iter = set2.iterator();
			 for(String quickHome:quick) {
				 set2.add(quickHome);
				 //U.log(quickHome);
				 }
			 U.log("total"+set2.size());
			// while(iter.hasNext()) {
			 for(String setid:set2) {
				// U.log("inside"+iter.next());
				// U.log("inside"+setid);
				 if(setid.contains(comName)) {
					 if(!status.contains("Quick Move-in Homes"))
					 status="Quick Move-in Homes";
					// U.log("XX");
				 }else {
					 status=U.getPropStatus(comHtml);
				 }
			 }
			 //status=status+", "+U.getPropStatus(comInfo+comHtml);
			 
			 
			 status = status.replace("1 Home Remaining", "Only 1 Home Remaining");
			 
			 U.log("prop Status: "+status);
			// if(comUrl.contains("https://beechwoodhomes.com/the-selby/"))status="Coming Soon";//from Image
			 
			 //commType
			//comHtml=comHtml.replace("A 62+ ACTIVE ADULT COMMUNITY","62+ Community");
			String comType=ALLOW_BLANK;
			comHtml=comHtml.replace("waterfront","waterfront community");
			U.log("PPP"+Util.match(comHtml, "A 62+ ACTIVE ADULT COMMUNITY"));
			
			comType= U.getCommType(comHtml+comInfo+lifestyle);
			
			U.log("community type"+comType);
			
			if(comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-east-meadow/"))
				comType="62+ Community, Resort Style";
				
				
				//	U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+lifestyle), "[\\s\\w\\W]{30}ACTIVE ADULT[\\s\\w\\W]{30}", 0));
			/*
			 * if(comUrl.contains(
			 * "https://www.beechwoodhomes.com/meadowbrook-pointe-east-meadow/"))
			 * comType="62+ Community, Resort";
			 */
			 //propTypen& derved			
			String propType = ALLOW_BLANK;
			String dType = ALLOW_BLANK;
	//		 U.log("HHH"+Util.matchAll(comHtml+comInfo+homeHtml+floordata,"[\\w\\W\\s]{50}Cabin[\\w\\W\\s]{50}",0));
			propType = U.getPropType((comHtml+comInfo+homeHtml+floordata).replaceAll("%7CCabin%3A100%|craftsmanship|Townhouses|Townhouse-8-kitchen", ""));
			
			
			U.log("propType::" + propType);
			
//			if(comUrl.contains("https://www.oakridgebeechwood.com/"))
//			 propType="Single Family";
			if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/"))propType="Condominium, Apartment Homes, Patio Homes";
	//		U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+homeHtml+floordata), "[\\s\\w\\W]{30}Townhouse[\\s\\w\\W]{30}", 0));
			
			comHtml = comHtml.replaceAll("second floor primary suites", "");
			homesData = homesData.replace(" | 2 Levels | ", " | two story | ").replace(" | 1 Levels | ", " | one story | ").replaceAll("first &amp", "first floor")
					.replace("3 Levels", "three story");
			
			U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+homeHtml+floordata+homesData), "[\\s\\w\\W]{30}first floor[\\s\\w\\W]{30}", 0));
			dType=U.getdCommType((comHtml+comInfo+homeHtml+floordata+homesData).replace("branch", "").replace("2 Levels", "two story").replace("1 Levels", "one story"));
            U.log("Derived prop tyupr"+dType);
 //           U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+homeHtml+floordata+homesData), "[\\s\\w\\W]{30}level[\\s\\w\\W]{30}", 0));
            
            //Address
            String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
            String geo = "FALSE";
            
            String latLng[]= {ALLOW_BLANK,ALLOW_BLANK};
            addSec=Util.match(contactHtml,"href=\"https://goo.gl/maps.*</a>");
            comHtml=comHtml.replace("New York","NY");
			 U.log("Addsec"+addSec);
			 
//			 U.log("MMMMMMM "+Util.matchAll((contactHtml), "[\\s\\w\\W]{30}5 Atlantic Avenue East[\\s\\w\\W]{80}", 0));
			 
			
			 
			 if(addSec!=null) {
			 addSec = U.getNoHtml(addSec.replaceAll("\\.|\\s+\\,|<br>|<span class=\"nowrap\">", ",")).replaceAll(".*>", "");
			 addSec=addSec.replaceAll("\\s+\\,","");
			 addSec=addSec.replace("190 Beach 69th Street  Arverne, NY 11692   888 500 5480 ", "190 Beach 69th Street, Arverne, NY 11692, USA");
			 addSec=addSec.replace("New York","NY");
			// addSec=addSec.replace(",,", ",");
			 U.log("NEW ADD SEC"+addSec);
			 add=U.getAddress(addSec);
			 U.log("Address"+Arrays.toString(add));
			 
			 }else {
				String addSection=U.getSectionValue(contactHtml, "<div class=\"elementor-custom-embed\">", "aria-label=");
				
				 if(addSection == null && comName.contains("The Vanderbilt")) {
					String addSectionHere =  U.getSectionValue(contactHtml, "EJtARmMgYS82\"", "</h2>");
					 U.log("From here: "+addSectionHere);
					 add[0] = U.getSectionValue(addSectionHere, ">", "<br>");
					 String sec = U.getSectionValue(addSectionHere, "<br>", "</a>");
					 sec = sec.replace("New York", "NY,");
					 String[] split = sec.split(",");
					 add[1] = split[0];
					 add[2] = split[1];
					 add[3] = split[2];
					 
					 U.log("ADDRESS INSIDE: "+Arrays.toString(add));
				 }
				 if(comName.equals("The Selby")) {
						String addSectionHere =  U.getSectionValue(contactHtml, "Address</strong><br />", "</p>");
						addSectionHere = addSectionHere.replace("New York", "NY,");
						 U.log("From here: "+addSectionHere);
						 String[] split = addSectionHere.split(",");
						 add[0] = split[0];
						 add[1] = split[1];
						 add[2] = split[2];
						 add[3] = split[3];
						 
						 U.log("ADDRESS: "+Arrays.toString(add));
					 }
				
				if(addSection!=null) {
				addSection = addSection.replace("845 East Meadow Avenue East Meadow, New York 11554", "845 East Meadow Avenue, East Meadow, New York 11554");	
				addSec=U.getSectionValue(addSection, "title=\"","\"");
				add=U.getAddress(addSec);
				U.log("LL"+addSection);
				
				}else {
					addSec=U.getSectionValue(comHtml,"<h2 class=\"h3\">Address</h2><p>","</p><section");
					if(addSec!=null) {
						add=U.getAddress(addSec);
					U.log("MM"+addSec);
					}
				}
				
				//else
//				{
//				 addSection=U.getSectionValue(contactHtml, "<a href=\"https://beechwoodhomes.com/latch/contact\">", "</span></a></p");
//				 addSec=addSec.replace(" <span class=\"nowrap\">", "");
//				 addSec=addSec.replace("101 Hill Street", "101 Hill Street,");
//				 add=U.getAddress(addSec);
//				U.log("JJJ");
//				}
			 }
			 
			 /*
			  * Lat-Lng is getting at iFrame Html
			  */
			 if(comUrl.equals("https://www.beechwoodhomes.com/country-pointe-estates-westhampton/")) {
				 String section = U.getSectionValue(comHtml, "<iframe loading", "width");
				 U.log("section: "+section);
				 String frameUrl = U.getSectionValue(section, "data-lazy-src=\"", "\"");
				 if(frameUrl != null) frameUrl = frameUrl.replace("amp;", "");
				 U.log("frameUrl: "+frameUrl);
				 String frameData = U.getHTML(frameUrl); 
//				 FileUtil.writeAllText("/home/shatam-10/Desktop/data/frame.txt", frameData);
//				 U.log("MMMMMMM "+Util.matchAll((frameData), "[\\s\\w\\W]{30}86 Depot Rd[\\s\\w\\W]{80}", 0));
				 
				 String latlngSec = U.getSectionValue(frameData, "[[null,[", "]],");
				 U.log("latlngSec ::"+latlngSec);
				 if(latlngSec != null && latlngSec.contains(","))
					 latLng = latlngSec.split(",");
				 
				 if(latLng[0] != null) {
					 add=U.getAddressGoogleApi(latLng);
					lat=latLng[0];
					lng=latLng[1];
					geo="TRUE";
				 }
			 }
			 
			 if(comUrl.contains("https://www.beechwoodhomes.com//oneck-landing-westhampton")) {
				 add[1]="Westhampton";
				 add[2]="NY";
				 latLng=U.getlatlongGoogleApi(add);
				 if(latLng==null) {
					 latLng=U.getlatlongHereApi(add);
				 }
					add=U.getAddressGoogleApi(latLng);
					lat=latLng[0];
					lng=latLng[1];
					geo="TRUE";
			 }
			 
			 
			 if(comUrl.contains("https://www.beechwoodhomes.com//the-latch-southampton-village/")) {
				 add[0]="101 Hill Street";
				 add[1]="Southampton";
				 add[2]="NY";
				 add[3]="11968";
						 
			 }
			 if(comUrl.contains("https://www.oakridgebeechwood.com/")) {
				 add[0]="527 Oak Ridge Boulevard";
				 add[1]="Saratoga Springs";
				 add[2]="NY";
				 add[3]="12866";
				 latLng=U.getlatlongGoogleApi(add);
				 U.log("LL"+Arrays.toString(latLng));
				 if(latLng==null)
					 latLng=U.getlatlongHereApi(add);
				 lat=latLng[0];
				 lng=latLng[1];
				 geo="TRUE";
				 status=ALLOW_BLANK;
			 }
			 if(comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-east-meadow/")) {
				 add[0]="123 Merrick Avenue";
				 add[1]="East Meadow";
				 add[2]="NY";
				 add[3]="11554";
				
			 }
			 if(comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-gardens-east-meadow/")) {
				 add[0]="845 East Meadow Avenue";
				 add[1]="East Meadow";
				 add[2]="NY";
				 add[3]="11554";
				 
			 }
			 
			 //latlng
			
				
				if(comUrl.contains("https://www.beechwoodcarolinas.com/")) {
					comInfo=comInfo.replace("North Carolina","NC" );
				
					add[1]="Chapel Hill";
					add[2]="NC";
			        latLng=U.getlatlongGoogleApi(add);
					add=U.getAddressGoogleApi(latLng);
					lat=latLng[0];
					lng=latLng[1];
					geo="TRUE";
					}
				
			
			 if((lat==ALLOW_BLANK||lng==ALLOW_BLANK) && addSec!=null || add[0] != ALLOW_BLANK) { 
				 latLng=U.getlatlongGoogleApi(add); 
				 geo="TRUE"; 
				 lat=latLng[0];
				 lng=latLng[1]; 
			 }
			 
				add[0]=add[0].replace("The Vanderbilt 990 Corporate Dr","990 Corporate Dr");
				add[0]=add[0].replace("The Tides at Arverne by the Sea 190 Beach 69th St","190 Beach 69th St");
				add[0]=add[0].replace("1 Charles B Wang Blvd,","1 Charles B Wang Blvd").trim();
				add[0]=add[0].replace("298 Silver Timber Drive ,", "298 Silver Timber Drive").trim();
				
//				if(comUrl.contains("https://www.oakridgebeechwood.com/")) {
//					minPrice="$975000";
//					maxSqf="5000";
//				}
					
				if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/")) {
					add[0]="190 Beach 69th Street";
					add[1]="Queens";
					add[2]="NY";
					add[3]="11692";
				}
//				if(add[0]==null||add[0]==ALLOW_BLANK) {
//					add=U.getAddressGoogleApi(latLng);
//					if(add[0]==null||add[0]==ALLOW_BLANK) {
//						add=U.getAddressHereApi(latLng);
//					}
//				}
				comHtml = comHtml.replace("now pre leasing","now pre-leasing");
				
				String note=U.getnote(comHtml.replaceAll("Lot For Sale: ", ""));
//				if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/"))
//				 note="Building 2 is Now Leasing";
//				U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Now Pre Leasing[\\s\\w\\W]{30}", 0));
			U.log("m add"+Arrays.toString(add));
			
				data.addCommunity(comName, comUrl.replace(".com//", ".com/"),comType);
				data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),add[3].trim());
				data.addLatitudeLongitude(lat, lng, geo);
				data.addNotes(note);
				data.addPrice(minPrice,maxPrice);
				data.addPropertyStatus(status);
				data.addPropertyType(propType, dType);
				data.addSquareFeet(minSqf,maxSqf);
				data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);
				
				
				
				
				// U.log("latlngSec::"+latlngSec);
//				lat = U.getSectionValue(latlngSec, "lat\":\"", "\"");
//				lng = U.getSectionValue(latlngSec, "lng\":\"", "\"");
			  
			 
			 
			 
			 
			}
			 
		//	for(String navUrl : navUrls) {
			
			//if(navSec!= null){
			//for(String navSecN:navSec) {
				//U.log(navSecN);
			//	String[] navUrls = U.getValues(navSecN, "href=\"", "\"");
				//U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>: "+Arrays.toString(navUrls));
			//	for(String navUrl : navUrls){
					//U.log("Nav URL"+navUrl);
//					homeUrl =  navUrl;
//					if(navUrl.contains("apartments")||navUrl.contains("/homes")|| navUrl.contains("apartments")||navUrl.contains("condominium-collection")||navUrl.contains("villas")){
//						
//						U.log("HomenabvUrl"+navUrl);
//						if(!navUrl.contains("https://beechwoodhomes.com"))
//						homeHtml += U.getHTML("https://beechwoodhomes.com"+navUrl);
//						else {
//							homeHtml+= U.getHTML(navUrl);
//						}
//					}
//					if(navUrl.contains("/lifestyle")||navUrl.contains("amenities")||navUrl.contains("the-clubhouse")){
//						
//						U.log("lifestyle url"+ navUrl);
//						if(!homeUrl.contains("https://beechwoodhomes.com"))
//							lifestyle += U.getHTML("https://beechwoodhomes.com"+navUrl);
//						else
//							lifestyle += U.getHTML(navUrl);
//					}
//					if(navUrl.contains("/contact")||navUrl.contains("/contact-us")) {
//						U.log("COMNTACT Url"+navUrl);
//						contactUrl=navUrl;
//						if(contactUrl.contains(comUrl)) {
//						  contactHtml=U.getHTML(contactUrl);
//						  
//						}
//						else {
//							//contactUrl=comUrl+contactUrl;
//							contactHtml+=U.getHTML(navUrl);
//						}
//					}
//				
//				}
//			 addSec=Util.match(contactHtml, "href=\"https://goo.gl/maps.*</a>");
//			 U.log("Addsec"+addSec);
//			 addSec = U.getNoHtml(addSec.replaceAll("\\.|\\s+\\,|<br>|<span class=\"nowrap\">", ",")).replaceAll(".*>", "");
//			 addSec=addSec.replaceAll("\\s+\\,","");
//			 U.log("NEW ADD SEC"+addSec);
		//	}

			//if(navSec== null){
//				String[] navUrls = U.getValues(comHtml, "href=\"", "\"");
//				U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>: "+Arrays.toString(navUrls));
//				for(String navUrl : navUrls){
//					if(navUrl.contains("/homes")|| navUrl.contains("apartments")){
//						homeUrl =  navUrl;
//						U.log("HomeUrl :https://beechwoodhomes.com"+ navUrl);
//						homeHtml += U.getHTML("https://beechwoodhomes.com"+navUrl);
//					}
//					if(navUrl.contains("/lifestyle")){
//						homeUrl =  navUrl;
//						U.log("lifestyle :https://beechwoodhomes.com"+ navUrl);
//						if(!homeUrl.contains("https://beechwoodhomes.com"))
//						lifestyle += U.getHTML("https://beechwoodhomes.com"+navUrl);
//						else
//							lifestyle+=U.getHTML(homeUrl);
//					}
//				}
//			
			
//			if(comUrl.contains("https://www.beechwoodhomes.com/vanderbilt"))
//				homeHtml = U.getHTML("https://vanderbiltli.com/apartments");
//			
//			if(comUrl.contains("https://www.beechwoodhomes.com/latch"))
//				homeHtml = U.getHTML("https://beechwoodhomes.com/latch/homes");
			
//			if(comUrl.contains("https://www.beechwoodhomes.com/meadows"))
//				homeHtml += U.getHTML("https://beechwoodhomes.com/meadows//homes/qmi/");
			
/*			if(comUrl.contains("https://www.beechwoodhomes.com/oak-ridge")) {
				
				String[] homeSec = U.getValues(homeHtml, "<li class=\"m-0 model-card", "</li>") ;
				
				for(String home : homeSec) {
					
					home = U.getSectionValue(home, "href=\"", "\"");
					String h = U.getHTML("https://beechwoodhomes.com"+home);
					
					String rem = U.getSectionValue(h, "<h2>See our other home styles</h2>", "</html>");
					if(rem!=null)
						h = h.replace(rem, "");
					homeHtml+=h;
					
				}
				
				
			}
			

			ArrayList<String> homeUrls = Util.matchAll(homeHtml, "card col-12 col-md-6 col-lg-4 \" id=\"card-(.*?)href=\"(.*?)\" data-type=\"condominiumsuite\"><div class=\"card\"><div class=\"card-img-top prop-", 2);
			if(homeUrls.size()==0) {
				homeUrls = Util.matchAll(homeHtml,"href=\""+homeUrl+"/(.*?)\"", 1);
			}
						
			U.log("Total Homes : "+homeUrls.size());
			for(String homeUrln : homeUrls){
				if(!homeUrln.contains("homes")|| homeUrln
						.contains("-homes"))homeUrln = homeUrl+"/"+homeUrln;
				U.log("https://beechwoodhomes.com"+homeUrln);
				String hhHtml = U.getHTML("https://beechwoodhomes.com"+homeUrln);
				allHomesData += U.getSectionValue(hhHtml, "<h1 class=\"m-0\">", "<br></span></p><div")+U.getSectionValue(hhHtml, "class=\"price\">", "</span>")
				+U.getSectionValue(hhHtml, "<ul class=\"model-icons", "</ul>")+U.getSectionValue(hhHtml, "</ul></div></section>", "</section>")
						+U.getSectionValue(hhHtml, "<div class=\"main-container", ">View Other Home Styles")+U.getSectionValue(hhHtml, "<div class=\"container\">", "</h2></div></div></div></div></div>");
				if(comUrl.contains("/oak-ridge"))allHomesData+=hhHtml;
			}
			allHomesData = allHomesData.replace(">1 Level</span>", " Story 1 ").replace(" Level<", " story <");
			
			comHtml = comHtml
					.replaceAll(
							"quick-move-in/\">Available Quick Move-In Homes|Quick Move|this new Master Plan community combines|Future Site of Pool &amp; Patio|in our beautifully custom designed home|Applications are now available|of Two-Family|arverne-master-plan-copy|arverne master plan|show_aggregated|North Fork Builders Closeout|Models Now Open|AHoAY|Townhomes-Back-1|Townhomes-Front|Starting At \\$2,000,000|pond-condo|Final Phase furnished",
							"");
			comHtml = comHtml.replace("<span>Loft</span>", "<span>Loft Homes</span>").replace("E Model Loft", "E Model Loft Homes")
					.replace("Luxury rental apartments", "Luxury Homes rental apartments");
			 //U.log(comHtml);
			// ------com Name, community type, property type and derived
			// type----------
			String comType = ALLOW_BLANK;
			String propType = ALLOW_BLANK;
			String dType = ALLOW_BLANK;

			comName = comName.replace("Club &#038; Spa", "Club & Spa");
			if(comName != null) {
				comName = U.getNoHtml(comName);
				comName=comName.replace(" • ", " ").replaceAll(" �|East Rockaway|East Meadow|Plainview Shops|Smithtown|Yaphank|Saratoga|Southampton Village", "");
			}
			U.log("commName :::"+comName);
			// remove common section
			String drop = U.getSectionValue(comHtml,
					"<div id=\"other-communities\">",
					"SWAP ADDRESS FUNCTION END");
			if (drop != null)
				comHtml = comHtml.replace(drop, "");

			comHtml = comHtml.replace(" blend of luxury ",
					" blend of luxury home");
			comHtml=comHtml.replace("Condominium Suites","");
			

			
			comType = U.getCommType((comHtml + comInfo+lifestyle).replace("55 and over community", "").replaceAll("Swamp Road, this new Master Plan|content=\"Oak Ridge is a luxurious new master-planned|The Boulevard Master Plan|Resort-Style, Riverfront|close to golf","").replace("Condominium Suites",""));
		
		//	
			U.log("comType::" + comType);

			comHtml=comHtml.replace("luxury and convenience", "luxury homes and convenience")
					.replaceAll("Chinese \\(Traditional|-condo-|Single-Family|enclave of four estate homes|Condominium, 123 Merrick Avenue|Condominium, 845 E. Meadow Avenue","");
			
			if(homeHtml!=null)
				homeHtml = homeHtml.replace("Condominium Suites", "condominium homes");
			propType = U.getPropType(comHtml + comInfo+homeHtml);
			U.log("propType::" + propType);

			comHtml=comHtml.replace("First Floor"," 1 Story ").replaceAll("Two level|Second Floor"," 2 Story ");
			homeHtml = homeHtml.replaceAll("Two level"," 2 Story ").replace(" first & second floor master suites", " first floor & second floor master suites");
			dType = U.getdCommType(comHtml + comInfo + allHomesData + homeHtml);
			U.log("dType::" + dType);

			// ------Property Status
			String propStatus = ALLOW_BLANK;
			//U.log(comInfo);
			comHtml=comHtml.replaceAll("Coming Soon, A Community-Wide|Restaurant (C|c)oming|Marseille Now|Galleries are now|important;\"><strong>Now","");
			
			propStatus = U.getPropStatus((comHtml + comInfo).replaceAll(
					"Juniper Restaurant - Now Open|Bar Marseille Now Open| Resaurant - Now Open|<strong>Now Open!</strong></p></button>|Galleries are now|Now Open: The Vanderbilt Market|Grand Opening|Models Now Open|Now Open - 8|Only 2 Homes Remaining</em></h3>|†Limited availability.</p>", ""));
			U.log("Status::" + propStatus);
			
			U.log("MMMMMMMMM"+Util.matchAll(allHomesData, "[\\s\\w\\W]{50}multi-level homes[\\s\\w\\W]{30}", 0));

			//			U.log(allHomesData);	
//			if(comUrl.contains("https://www.beechwoodhomes.com/smithtown")) {
//				propStatus="Quick Move-in Homes";
//			}
			// ------------Price------------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String price[] = { ALLOW_BLANK, ALLOW_BLANK };
			comHtml = comHtml.replace("1.95M", "$1,950,000").replace("1.73M", "$1,730,000");
			comInfo = comInfo.replace("1.7M", "1,700,000");
			comHtml = comHtml.replace("3.95M", "3,950,000");
			comHtml = comHtml.replace("3.5M", "$3,500,000");

			if(homeHtml!=null) {
				
				String[] remSec = U.getValues(homeHtml, "<li class=\"m-0 model-card", "</li>");
				
				for(String rem :remSec)
					if(rem.contains("Sold")) {
						
						homeHtml = homeHtml.replace(rem, "");
					}
			}

			
			if(homeHtml!=null)
				homeHtml = homeHtml
				.replaceAll("Sold Out</div></div><div.*></div><div class=\"card-body-contain\"><div class=\"card-body bg-light text-secondary\"><h3 class=\"card-title bg-primary\"><span class=\"no-decoration\">.*</span></h3><div class=\"type\"><span class=\"no-decoration\">.*</span></div><div class=\"sqft\"><span class=\"no-decoration\">\\d,\\d+ sq ft</span></div><div class=\"price\"><span class=\"no-decoration\">Priced From \\$\\d+,\\d+\\*</span>"
						+ "|Sold Out</div></div><div.*><div class=\"card-body bg-light text-secondary\"><h3 class=\"card-title bg-primary\"><span class=\"no-decoration\">.*</span></h3><div class=\"type\"><span class=\"no-decoration\">Lower Corner Villa</span></div><div class=\"sqft\"><span class=\"no-decoration\">\\d,\\d+ sq ft</span></div><div class=\"price\"><span class=\"no-decoration\">Priced From \\$\\d,\\d+,\\d+\\*</span>", "");
			
			String homesec=U.getSectionValue(comHtml, "aria-controls=\"nav-homes-dropdown\">Homes", ">About</a>");
			String prisec=null;
			if(homesec!=null) {
				U.log(":::ENTER:::");
				String hur[]=U.getValues(homesec, "<a href=\"", "\"");
				for(String d:hur) {
					String dhtml=U.getHtml("https://beechwoodhomes.com"+d, driver);
					String psec[]=U.getValues(dhtml, "m-0 model-card col-12 col-md-6 col-lg-4 ", "View Home");
					for(String df:psec) {
						if(!df.contains("Sold Out"))
							prisec+=df;
					}
				}
			}
			
			
			int quickHomeCount = 0;
			String quickData =ALLOW_BLANK;
			String quickHtml  = U.getHTML("https://beechwoodhomes.com/quick-move-in/");
			String quickHomes[] = U.getValues(quickHtml, "<li class=\"box card", "</li>");
			for(String quickHome : quickHomes){
				String quickHomeName = U.getSectionValue(quickHome, "<h4 class=\"mt-3 mb-0\">", "<");
				if(quickHomeName.toLowerCase().trim().contains(comName.toLowerCase().trim())){
					quickHomeCount++;
					quickData+=quickHome;
					U.log("::::::quick home found:::::::");
				}
			}
			U.log(quickData);
			
			price = U.getPrices(comHtml + comInfo+homeHtml+prisec+allHomesData,
							"Priced From \\$\\d{3},\\d{3}|Priced from the Lower \\$\\d{3},\\d{3}|Priced From \\$\\d,\\d{3},\\d{3}\\*</span>|\\$\\d,\\d+,\\d{3}|Priced from \\d,\\d+,\\d{3}|Priced At \\$\\d{3},\\d{3}|priced from &#36;\\d,\\d+,\\d{3}|Available At \\d,\\d+,\\d{3}|Starting At \\$\\d{3},\\d{3}|Priced from the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d+|the Mid \\$\\d{3},\\d{3}|Pricing From &#36;\\d+,\\d{3}|Priced from <strong>&#36;\\d+,\\d{3}|the Upper \\$\\d{3},\\d+|From Mid  \\$\\d{3},\\d{3}|Upper  \\$\\d{3},\\d{3}|From Low  \\$\\d{3},\\d{3}|Starting At &#36;\\d{3},\\d{3}|Mid  \\$\\d{3},\\d{3}|Upper \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}",
							0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("minPrice:: " + minPrice + " maxPrice::" + maxPrice);
			//U.log(Util.matchAll(comHtml + comInfo+homeHtml+prisec, "[\\s\\w\\W]{30}\\$2,750,000[\\s\\w\\W]{30}", 0));
			
			// ---------Square Feet-----------

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			comHtml = comHtml.replace("sq.ft. Clubhouse", "");
			String[] sqFt = U.getSqareFeet((comHtml + comInfo+homeHtml+prisec+quickData).replaceAll("<span class=\"no-decoration\">2,878 sq ft</span>", ""),
							"\\d,\\d{3} sq ft|>\\d,\\d+ sq ft</span>|\\d,\\d{3} sq.ft. Living|from \\d{3,}\\+ sq ft to \\d,\\d{3}\\+ sq ft|\\d,\\d{3}\\+ sq ft to \\d,\\d{3}\\+ sq ft.|align-middle living\">\\d{3}\\+</td>|align-middle living\">\\d,\\d{3}\\+</td>|Grand Total: <span><strong>\\d{4}|\\d+,\\d{3}	sq. ft.|Total Sq.Ft.<strong>\\d{4}|total\">\\d{4}|\\d{1},\\d{3} square feet|\\d{3,4} Sq. Ft|Total - \\d+,\\d{3} sq. ft|\\d,\\d{3} sq.ft|>\\d{3} sq.ft.|living\">\\d,\\d{3}|living\">\\d{3}|\\d{3} – \\d{3} Sq. Ft.",
							0);
			minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			U.log("minSqft::" + minSqf + " max Sqft::" + maxSqf);
			

			// -----latitude and longitude--------Address---------
			String lat = ALLOW_BLANK;
			String lng = ALLOW_BLANK;
			String geo = "FALSE";
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			// U.log("latlngSec::"+latlngSec);
//			lat = U.getSectionValue(latlngSec, "lat\":\"", "\"");
//			lng = U.getSectionValue(latlngSec, "lng\":\"", "\"");

//			String contactHtml = ALLOW_BLANK;
//			String navContactUrl = U.getSectionValue(comHtml, "nav-contactus\"><a class=\"nav-link \" href=\"", "\"");
//			if(navContactUrl == null)navContactUrl = U.getSectionValue(comHtml, "\"nav-contact\"><a class=\"nav-link \" href=\"", "\"");
//			
//			if(navContactUrl!=null){
//				U.log("Contact::: "+navContactUrl);
//				if(comUrl.contains("https://tidesnyc.com"))
//					contactHtml = U.getHtml("https://tidesnyc.com"+navContactUrl,driver);
//				else if(comUrl.contains("https://www.beechwoodhomes.com/vanderbilt"))
//					contactHtml = U.getHtml("https://vanderbiltli.com"+navContactUrl,driver);
//				else
//					contactHtml = U.getHtml("https://beechwoodhomes.com"+navContactUrl,driver);
//			}
//			
//			if(contactHtml.length()>4){
//				String addSec = Util.match(contactHtml, "<p><a href=\"https://goo.gl/maps/.*</span></a></p>");
//				
//				if(addSec ==null)
//					addSec = Util.match(contactHtml, "href=\"https://goo.gl/maps/.*</a>");
//				U.log("addSec:: "+addSec);
//				
//				addSec = U.getNoHtml(addSec.replaceAll("<br>|<span class=\"nowrap\">", ",")).replaceAll(".*>", "");
//				
//				U.log("addSec:::: "+addSec);
//				
				
				
				if(addSec!=null) {
			//		
				addSec  =addSec.replace("    888 500 5480  Hours of Operation:,We are open from ,10am–5pm,  ,7 Days  ,a week    Our Leasing office is located at the corner of  Beach 67th and Rockaway Beach Blvd.", "").replace("    888 500 5480  Hours of Operation:,We are open from ,10am�5pm,  ,7 Days  ,a week    Our Leasing office is located at the corner of  Beach 67th and Rockaway Beach Blvd.","").replace("<br>", ",").replace("New York", "NY");
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
				if(add[2].trim().length()>2)add[2]=USStates.abbr(add[2].trim());
				}
				String latLngSec;
//				if(comUrl.contains("https://www.beechwoodhomes.com/vanderbilt")) {
//					
//					latLngSec=U.getSectionValue(contactHtml, "<div class=\"embed-responsive embed-responsive-16by9\"><iframe src=\"", "\"");
//					U.log("latLngSec:: "+latLngSec);
//				
//				}else {
				latLngSec=U.getSectionValue(contactHtml, "href=\"https://maps.google.com/maps?ll=", "&");
//				}
				U.log("latLngSec:: "+latLngSec);
				if(latLngSec==null) {
					String embedMapHtml = U.getHTML("https://beechwoodhomes.com"+U.getSectionValue(contactHtml, "<div class=\"embed-responsive embed-responsive-16by9\"><iframe src=\"", "\""));
					U.log("https://beechwoodhomes.com"+U.getSectionValue(contactHtml, "<div class=\"embed-responsive embed-responsive-16by9\"><iframe src=\"", "\""));
					if(embedMapHtml!=null) {
						String mapSec[] = U.getValues(embedMapHtml, "<div class=\"point\" ", "</p></a></div>");
						U.log(mapSec.length);
						for(String sec:mapSec) {
							if(sec.toLowerCase().trim().contains(comName.toLowerCase().trim())) {
								latLngSec = sec;
								U.log(sec);
							}
						}
					}
				}	
				if(latLngSec!=null) {
					lat=Util.match(latLngSec, "\\d{2,3}\\.\\d+");
					lng=Util.match(latLngSec, "-\\d{2,3}\\.\\d+");
					}
				if(latLngSec!=null && lat==null) {
				lat=Util.match(latLngSec, "\\d{2,3},\\d+");
				lng=Util.match(latLngSec, "-\\d{2,3},\\d+");
				}
				U.log("latLngSec:: "+lat+"\t"+lng);
			}
			else {
				try {
				add=U.findAddress(U.getSectionValue(comInfo, "Address</h3>", "</p>").replaceAll("New York", "NY"));
				}catch (Exception e) {
					// TODO: handle exception
				}
			}
			if(add[0]==ALLOW_BLANK) {
				
				String adds = U.getSectionValue(comInfo, "Address</h3>", "</p>");
				if(adds!=null)
				add=U.findAddress(adds.replaceAll("New York", "NY"));		

			}
			U.log("Street:: " + add[0] + " city::" + add[1].trim() + " State::"	+ add[2] + " Zip::" + add[3]);
			String note = ALLOW_BLANK;
			if(comUrl.contains("https://www.beechwoodhomes.com/vanderbilt")) {
				lat="40.73899187932893";
				lng="-73.60322528459423";
				
				
			}
			
			
			if(comUrl.contains("oakridgebeechwood")){
				add = U.getAddress("527 Oak Ridge Boulevard ,Saratoga Springs, NY 12866");
				String latLng[]=U.getlatlongGoogleApi(add);
				geo = "True";
				minSqf="2,737";
				maxSqf ="4,397";
				minPrice="$1,275,000";
				maxPrice=" $2,200,000";
				propType ="Single Family";
				dType = "2 Story";
			}
			if(comUrl.contains("https://www.beechwoodhomes.com/westhampton")) {
				
				add[1] = "Moriches Bay,";
				add[1] = "NY";
				
				String latLng[]=U.getlatlongGoogleApi(add);
				geo = "True";
				add = U.getAddressGoogleApi(latLng);
				
			}
			
			if(lat == ALLOW_BLANK || lat == null){
				U.log("----------------------------------------------------");
				if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK){
					String latLng [] = {lat,lng};
					latLng = U.getlatlongGoogleApi(add);
					if(latLng == null) latLng = U.getlatlongHereApi(add);
					lat=latLng[0];
					lng=latLng[1];
					geo = "True";
				}
			}

			if (comUrl.contains("http://www.marinapointehomes.com")) {
				minSqf = "1050";
				maxSqf = "1698";
				propType = propType + ", Duplex";
				dType = "3 Story";
			}
			/*if (comUrl.contains("http://bishopsgrant.com")) {
				note = "Address Is Manually Taken From Site Map Image";
			}*/

	/*U		if (comUrl.contains("http://meadowbrookpointelinks.com/"))
				dType = "2 Story";
			

			if (comUrl.contains("http://beechwoodhighlands.com")) {
				comType = "Golf Course,Resort Style";
				propType = propType + ", Luxury Homes";
			}

			if (comUrl.contains("http://www.countrypointenorthbellmore.com")) {
				maxSqf = "4924";
				propStatus = "95% Sold, Only 1 Home Remaining";
			}
			if (comUrl.contains("http://www.countrypointeridge.com")) {
				propStatus = "Over 50% Sold";
				add[0]="3 Wildflower Drive";
				geo="false";
			}
			if (comUrl.contains("http://www.arvernebythesea.com")) {
				minSqf = "2700";
				maxSqf = "3739";
				minPrice = "$720,000";
				maxPrice = "$975,000";
			}
			if(comUrl.contains("http://thevillasmp.com/")){
				propType = propType + ", Luxury Homes";
				comType = comType + ", Country Club";
			}
			if(comUrl.contains("http://tidesnyc.com/")){minSqf = "557";maxSqf="1354";}
			
			
			
			if(quickHomeCount>0) {
				if(propStatus.length()<4) {
					propStatus="Quick Move-In Homes";
				}else {
					propStatus=propStatus+",Quick Move-In Homes";
				}
			}
		
			// ===add data
		//if(comUrl.contains("https://www.beechwoodhomes.com/plainview"))propStatus=ALLOW_BLANK;
			if(comUrl.contains("https://www.beechwoodhomes.com/latch")) {
			add[0] = "101 Hill Street";
			add[1] = "Southampton";
			add[2] = "NY";
			add[3] = "11968";

			lat="40.8845565";
			lng="-72.3963626";
			geo = "False";
			
			
			} 
			if(comUrl.contains("https://www.beechwoodhomes.com/meadows")) {
				propStatus = "Quick Move-in Homes";
//				maxPrice="$699,000";
			}
			if(comUrl.contains("https://tidesnyc.com"))propStatus = "Now Open";
			
			comName = comName.replace(add[1], "");
			
			if(comUrl.contains("https://www.beechwoodhomes.com/oak-ridge"))
				comName="Oak Ridge";
			
//			if(comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-east-meadow"))
//				comType+=", 62+ Community";

			if (comUrl.contains("https://www.beechwoodhomes.com/smithtown")) {
				propStatus = "Only One Home Remaining" ;//img
				minSqf="2,145";
				maxSqf="2,395";
			}
//			if(comUrl.contains("https://www.beechwoodhomes.com/marina")) {
//				maxPrice=ALLOW_BLANK;
//				minPrice=ALLOW_BLANK;
//				minSqf=ALLOW_BLANK;
//				maxSqf=ALLOW_BLANK;
//				//comType +=", Waterfront Community";
//			}

			
			if(comUrl.contains("https://tidesnyc.com")) {
				add[0]="190 Beach 69th Street";
				add[1]="Arverne";
				add[2]="NY";
				add[3]="11692";
				
				String ll[]=U.getlatlongGoogleApi(add);
				lat=ll[0];
				lng=ll[1];
				geo="TRUE";
			}
			if(comUrl.contains("https://tidesnyc.com"))comName="The Tides At Arverne By The Sea";
//			if(comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-gardens")) {
//				minPrice="$640,000";
//				maxPrice="$659,000";
//			}
			
		
			data.addCommunity(comName.replace("�", ""), comUrl, comType);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(),add[3].trim());

			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);

			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);

			data.addPrice(minPrice.trim(), maxPrice.trim());

			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			*/
		
		j++;
	}

	static String commUrl = ALLOW_BLANK;

	public static String getBuilderObj(List<String> newCsvRow) {
		// U.log("Hello1");
		if (commUrl.contains(newCsvRow.get(1).trim())) {

			return (newCsvRow.get(2) + "," + newCsvRow.get(3) + ","
					+ newCsvRow.get(4) + "," + newCsvRow.get(5) + ","
					+ newCsvRow.get(6) + "," + newCsvRow.get(7) + ","
					+ newCsvRow.get(8) + "," + newCsvRow.get(9) + "," + newCsvRow
						.get(13)

			);
		}
		return null;

	}

	public static String getHardcodedAddress(String comUrl) throws Exception {
		commUrl = comUrl.trim();
		String newFile = System.getProperty("user.home")+"/Harcoded Builders/"+ "Hardcode_BeechwoodOrganization" + ".csv";
		// U.log("Suucess=============");
		CsvListReader newFileReader = new CsvListReader(new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {

				String aaa = getBuilderObj(newCsvRow);

				if (aaa != null)
					return aaa;
			}
			count++;
		}

		newFileReader.close();
		return null;
	}
}