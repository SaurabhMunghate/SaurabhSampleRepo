/**
 * @modified by : Priti
 * @Date :1st Sept 2017
 * 
 */
package com.shatam.b_101_120;

import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
//import org.openqa.selenium.internal.seleniumemulation.IsVisible;

public class ExtractEssexHomes extends AbstractScrapper {
	int i = 0;
	static int duplicates = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractEssexHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Essex Homes.csv", a.data()	.printAll());
		U.log(duplicates);
	}

	public ExtractEssexHomes() throws Exception {

		super("Essex Homes", "https://www.essexhomes.net/");
		LOGGER = new CommunityLogger("Essex Homes");
	}

	public void innerProcess() throws Exception {

		String basehtml=U.getHTML("https://www.essexhomes.net/");
		//String regSec=U.getSectionValue(basehtml,"Neighborhoods</a><div class='menu-children","</ul></div></li>");
		String regVals[]=U.getValues(basehtml,"div class=\"card-section","Neighborhoods"
				+ "");
		U.log("regVals:::"+regVals.length);
		
		for(String regVal:regVals ){
			
			regVal = U.getSectionValue(regVal, "href=\"", "\"");
			if(!regVal.contains("https://www.essexhomes.net/"))regVal = "https://www.essexhomes.net"+regVal;
			U.log(regVal);
			findCommunity(regVal);
		}
		
		
		
		LOGGER.DisposeLogger();
	}
	
	public void findCommunity(String regUrl) throws Exception {
	//	regUrl=regUrl;
		String regHtml=U.getHTML(regUrl);
		
		
		String comVals[]=U.getValues(regHtml,"<div class=\"card card--horizontal card--community\">","View Details");
		//U.log("comLength of "+regUrl+":::::::::::"+comVals.length);
		LOGGER.AddRegion("https://www.essexhomes.net/"+regUrl, comVals.length);
		for(String comVal:comVals ){
			String url=U.getSectionValue(comVal,"href=\"","\"");
			
			String name=U.getSectionValue(comVal,"class=\"card-title\">","<");
			
			name=name.replaceFirst("Covington ", "");
			//name=name.replaceFirst("Covington", "");
			addDetails(comVal,url,name);
			
		}
		
	}
	
	//TODO :
	public void addDetails(String comSec,String url,String communityName) throws Exception {
		
		//if(j== 41)
//		try{
	{	
//		if(!url.contains("https://www.essexhomes.net/neighborhoods/the-villas-at-covington-covington-south"))return;
		
		//String url="https://www.essexhomes.net"+url;
		String html=U.getHTML(url);
		U.log(j+"::::::::::"+url);
		
		
		
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url+"<<================ Repeat");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		String bannerSec=U.getSectionValue(html, "<div class=\"banner-text\">", "</div>");
		//U.log(bannerSec);
	
	
		
		
		
		//-----------------------latlong----------//
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "var centerPosition = new ",");");
		if (latLongsec != null) {

			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		
		if(latLongsec == null) {
			
			latLong[0] = U.getSectionValue(html, "data-lat=\"", "\"");
			latLong[1] = U.getSectionValue(html, "data-lng=\"", "\"");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		
		communityName = communityName.replace("&#039;", "'");
		U.log("name*********"+communityName);
		
		//----------------------Adress--------------------------------- 
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;

		String ad = U.getSectionValue(html,"rel=\"noopener\">", "<");
		
		/*if(ad == null || ad.length()<4) {
			ad = U.getSectionValue(html, "Corporate Office<br/>", "</a>").replace("<br/>", ",");
		ad = U.removeSectionValue(ad, "<a title", "\">").replace("<a title\">", "").trim();
		String add1[] = ad.split(",");
		ad = Arrays.toString(add1);
		}*/
		
		ad = ad.replaceAll("TBD|-8103", "");
		U.log("ad:::::::::::::"+ad);
	
		if(ad != null && ad.contains("<br>")){
			//ad = ad.trim().replaceAll("^(?!\\((.*?)\\))", "");
			ad = ad.trim().replace("<br>", ",").replace("TBD", "").replaceAll("Model Address: 104 Milkweed Road,|GPS Address: 6504 Hawfield Road,|GPS address: Old Barnwell Rd and Enterprise Parkway|&nbsp;|1226 Marthan Road|1840 Felts Parkway|Pineview Road|Knollside Drive|Needle Leaf Drive", " ").trim()
					.replaceAll("1071 Waterlily Drive,9537 Possum Hollow Drive", "1071 Waterlily Drive")
					.replace("Across from ", "").replace("887 Centennial Drive,Pinnacle", "Pinnacle");
		
			if(ad.startsWith("(")){
				ad = ad.replaceAll("\\(|\\)|:|GPS Address", "");
			}else
				ad =ad.replaceAll("\\((.*?)\\)", "");
			ad = ad.replace(",,", ",");
			U.log(ad);		
			add = U.getAddress(ad);
		}else if(ad != null && !ad.contains("<br>")){
			
			add = ad.split(",");
			if(add.length == 4)
				add = add;
			else
				add = U.getAddress(ad);
			/*ad = ad.replace("&nbsp;", " ");
			String[] vals = ad.split(",");
			add[1] = vals[0];
			if(vals[1].length() > 3){
				add[2] = vals[1].trim().split(" ")[0];
				add[3] = vals[1].trim().split(" ")[1];
			}else
				add[2] = vals[1].trim();*/
		}
		if(add[2] == null)add[2] = ALLOW_BLANK;

		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			if(latLong[0] != ALLOW_BLANK && latLong[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				geo = "TRUE";
			}
		}
		U.log("Add ::"+Arrays.toString(add));
		if (add[0] == ALLOW_BLANK || add[0].length()<4) {
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressHereApi(latLong);
			add[0] = addr[0];
			geo = "TRUE";
		}
		
		if (add[2] == ALLOW_BLANK ||add[2].length()==0) {
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressHereApi(latLong);
			add[2] = addr[2];
			geo = "TRUE";
		}
		if (add[3] == ALLOW_BLANK ||add[3].length()<3) {
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressHereApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		
		U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
				+ " add[3] " + add[3]);
		
		//---------sec for communities-------------
		String sec=ALLOW_BLANK;
		sec=U.getSectionValue(html,"<div id=\"details\" class=\"small-12 medium-6 columns end\">","<div class=\"small-8 left columns\">");
		 sec = sec + U.getSectionValue(html, "<p>", "</p>");
		//----------------------available homes--------------//	
		String allAvailData=ALLOW_BLANK;
		//ArrayList<String> availUrls = Util.matchAll(html, "<li><a href=\"(.*?)\">View\\s*Plan\\s*Details</a></li>",1);
		String main = U.getSectionValue(html, "<h1>Available <span class=\"text-blue\">Floor Plans", "<h1>Community <span class=\"heading--accent\">Area Map");
		if(main ==null)main = "";
		String[] availUrls = U.getValues(main, "<div class=\"card card--horizontal", "View Details");//U.getHTML(url+"#available-floor-plans")
		U.log("Total available Homes " + availUrls.length);	
			for(String availUrl : availUrls ){
				availUrl = U.getSectionValue(availUrl, "<a href=\"", "\"");
				U.log("availUrl : "+availUrl+"**********");
				String availHtml = U.getHTML(availUrl);
				if(availHtml!=null)
				allAvailData += U.getSectionValue(availHtml, "<div class=\"ribbon\">", "<div class=\"cell large-3\">");
		}
		
		allAvailData = allAvailData.replaceAll("<li>Stories: <span>", "<li>Stories: ");
		//U.log(allAvailData);
		//--------------quick move in -------------
		String quickMove=ALLOW_BLANK;
		String quick=url+"#quick-move-in-homes";
		quickMove=U.getHTML(quick);
		if(sec!=null)sec=sec.replace("everyday luxury", "luxury homes").replace("Patio Homes</div>", "Covered Patio");
		String allQuickData=ALLOW_BLANK;
		String mainSec = U.getSectionValue(html, "<h1>Move-In Ready <span class=\"text-blue\">Homes</span></h1>", "<h1>Available <span class=\"text-blue\">Floor Plans</span></h1>");
	if(mainSec == null) mainSec = U.getSectionValue(html, "<h1>Move-In Ready <span class=\"text-blue\">Homes</span></h1>", " </section>");
		String[] quickSec=U.getValues(mainSec, "<div class=\"card card--horizontal","View Details");
		//ArrayList<String> quickUrls= Util.matchAll(quickSec, "<a href=\"(.*?)\">Learn",1);
		
		U.log("Total quick Url : " + quickSec.length);
	
		for(String quickUrl : quickSec )
		{
			try {
			quickUrl  = U.getSectionValue(quickUrl, "<a href=\"", "\"");
			U.log("Quick Url : "+quickUrl);
			String quickHtml = U.getHTML(quickUrl);
			allQuickData += U.getSectionValue(quickHtml, "<div class=\"ribbon\">", "<div class=\"cell large-3\">");
			}
			catch(Exception e) {}
			}
		allQuickData = allQuickData.replaceAll("<li>Stories: <span>", "<li>Stories: ")
				.replaceAll("split design |Split plan so", "split floor plan ");
		//--------------------neighbourhood feature----------
		
		String neigbourFea=ALLOW_BLANK;
		String neighbour=url+"#neighborhood_features";
		String neighbour1=U.getHTML(neighbour);
		if(neighbour1 ==null) neighbour1 = "";
		neigbourFea=U.getSectionValue(neighbour1,"<div class=\"small-8 column display_list\">"," <div class=\"content\" id=\"neighborhood_map\">");
		
		// ---------community type,property type,property status,derived,
		
		String overview = U.getSectionValue(html, " <section id=\"overview", " <div class=\"community-info\">");
		if(overview != null)
			overview = overview.replace("New&nbsp;phase, now selling", "New Phase Now Selling");
		
		//===========Community type---------//
		
		String commType = U.getCommunityType((overview+sec+bannerSec+comSec).replaceAll("Barr Lake community", ""));
		
		
		//==================== Property Type ===================
		 html=html.replace("New Phase, Now Open", "New Phase Now Open")
				 .replaceAll("Insulated Carriage style|Carriage style garage|Carriage lights|Carriage style insulated","");
		 if(neigbourFea!=null)
          neigbourFea=neigbourFea.replaceAll("Insulated Carriage style|Carriage style garage|Carriage lights|Carriage style insulated","");
		String propType = U.getPropType((comSec+overview+sec+neigbourFea+allQuickData+allAvailData).replaceAll("luxurious bath|Luxury Vinyl Plank|luxury plank|luxury and convenience of hardwoods|height of luxury|luxury bath|craft room|Craftsman style entry door|watercraft|Craftsmen Style front door", "")
				.replaceAll("villas-at-mount-vintage|20Villas|Villas at Mount Vintage|residential luxury", "luxury homes"));

		//=============== Derived Type ===============
		String dpType = U.getdCommType((overview+sec+neigbourFea+allQuickData+allAvailData).replace("two-story", "2 Story"));
		
		
		//==================== Property Status ==================
	//U.log(sec);
		sec = sec.replaceAll("in ready house|10 Opportunities Remaining|Move-in ready homes available", "")
				.replace("New Phase, Now Open", "New Phase Now Open").replace("New phase, now selling", "New Phase Now Selling");
		if(bannerSec != null)
			bannerSec = bannerSec.replaceAll("Coming soon", "");
		
		if(overview != null)
			overview = overview
			.replace("Now Selling in New Phase", "Now Selling New Phase").replace("Now Selling, Final Phase", "Now Selling Final Phase")
					.replace("New Phase, Now Open", "New Phase Now Open")
					.replace("New phase to start Summer 2020", "New phase start Summer 2020");
		
		String commStatus = U.getPropStatus((overview+bannerSec+sec).replaceAll(" move-in ready house a home|Lake Wylie Marina Coming 2020|Pricing: Coming Soon|banner-text\">Coming soon</div>|Hours: Coming Soon|Move-in Ready Homes Available|gated community are selling fast|No quick move-in homes available|Quick Move-In Homes</a></li>|Quick Move-In Homes\\s*</option>|Limited opportunities await the discerning homebuyer i|to take advantage of the limited opportunities that remain|selection of one of the 19|Amenities are now open|selling fast!</p>", ""));
		U.log("MMMMMMMMMM "+commStatus);
		
		if(quickSec.length == 0){
			if(commStatus.length()<4)
				commStatus="No Move-In Ready Homes";
			else
				commStatus=commStatus+", No Move-In Ready Homes";
		}
		else if(!commStatus.contains("Quick")){
			if(commStatus.length()<4 )
				commStatus="Move-In Ready Homes";
			else
				commStatus=commStatus+", Move-In Ready Homes";
		}
		commStatus = commStatus.replace("Only 9 Opportunities Remain, Only 9 Homes Remain", "Only 9 Opportunities Remain")
				.replace("2 Opportunities Left, Two Opportunities Remain", "2 Opportunities Left")
				.replace("2 Opportunities Left, Only 2 Opportunities Remain", "2 Opportunities Left").replace("Only 5 Opportunities Remain, Only 5 Homes Remain", "Only 5 Opportunities Remain");

		// --prices---//
		
		String headSec = U.getSectionValue(html, "<div class=\"ribbon\">", "</div>");
		//U.log("HHHHHHHHHHHHHHHHHH "+headSec);
		if(headSec == null) headSec = "";
		html=html.replace("0's","0,000");
		html=html.replaceAll("[0-9][s|S]|0s|0S|0’s","0,000");
		headSec=headSec.replaceAll("[0-9][s|S]|0s|0S|0’s","0,000");
		String[] price = U.getPrices((html+allAvailData+quickMove+headSec),
				"mid \\$\\d+,\\d+|<span>\\$\\d+,\\d+ - \\$\\d+,\\d+</span>|<span>\\$\\d+,\\d+</span>|<h2 class=\"text-blue\">\\$\\d+,\\d+|<h2 class=\"card-title\">\\$\\d+,\\d+|Pricing: \\$\\d+,\\d+|Pricing: \\d+,\\d+|High \\d+,\\d+|From the \\$\\d+,\\d+|Upper \\$\\d+,\\d+|High \\$\\d+,\\d+|Mid \\$\\d+,\\d+|Starting in the \\d+,\\d+|<li>Price: <span>\\$\\d{3},\\d+|Reduced Price: <span>\\$\\d+,\\d+|mid \\d{3},\\d{3}|the \\$\\d{3},\\d{3}|Low \\$\\d+,\\d+|Reduced Price:\\n*\\s*<span>\\$\\d{3},\\d{3}", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		allQuickData=allQuickData.replaceAll("<li>Square Feet: 4,911</li>", "");
		allAvailData=allAvailData.replaceAll("<li>Square Feet: 4,911</li>", "");
		html=html.replace("<li>Square Feet: 4,911</li>", "");
		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet((html+allAvailData+quickMove+headSec).replaceAll(" \\d+,\\d+ square feet of living space", "").replace("&nbsp;",""),
				"\\d,\\d{3} - \\d,\\d{3} Square Feet|<i class=\"fas fa-ruler-combined fa-fw \"></i>\\d,\\d+ - \\d,\\d+|\\d,\\d+ Square Feet|over \\d,\\d{3} to nearly \\d,\\d{3} square feet|Square Feet: \\d{1},\\d{3}|Sq. Ft. Range:  \\d{1},\\d{3} - \\d{1},\\d{3}|SQ FT: \\d{1},\\d{3}|Sq. Ft. Range: \\d{1},\\d{3} - \\d{1},\\d{3}|Sq. Ft. Range: 0 - \\d,\\d+", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		
		communityName=communityName.replaceAll(" - spacious homesites| - half acre, wooded homesites| Cottages$","");
		
		add[0]=add[0].replace("(GPS Address: 10900 Robinson Church Rd.)","10900 Robinson Church Rd");
		add[0]=add[0].replace("(GPS Address: 1226 Marthan Road)","1226 Marthan Road");
		add[0]=add[0].replace("(GPS Address: 7749 Garners Ferry Road)","7749 Garners Ferry Road");
		add[0]=add[0].replace(",", "");
		//if(url.contains("the-garden-at-hitchcock-crossing"))propType="Patio Homes";
	//	if(url.contains("the-terrace-at-longview"))commStatus=commStatus.replace("Now Selling", "New Phase Now Selling");
		//if(url.contains("manors-at-white-knoll")) commStatus = commStatus + ", Now Selling";
		
		add[0] = add[0].replaceAll("Across from|Pineview Road|1226 Marthan Road|Model Home Address.*|GPS.*|\\(gps.*|\\(", "").replace("&amp;", "&");
		
		if(url.contains("https://www.essexhomes.net/neighborhoods/timberwood"))commStatus = commStatus.replace("Quick Move-in", "Quick Move-in Homes");
		// ---notes-----//

		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus.replace("Quick Move-in Homes Home", "Quick Move-in Homes"));
		data.addNotes(U.getnote(html));

		
	}
	j++;
//	}catch (Exception e) {
//		// TODO: handle exception
//	}
	}
	
}