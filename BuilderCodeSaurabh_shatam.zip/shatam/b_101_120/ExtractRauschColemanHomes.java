/*
 * Modification Pallavi.
 */

package com.shatam.b_101_120;
import java.io.*;
import java.util.Arrays;

/*
 * Parag Humane
 * Date:31/07/2013
 * 
 */

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import org.apache.commons.lang.ArrayUtils;

public class ExtractRauschColemanHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	private static String BASEURL ="https://www.rauschcolemanhomes.com";
	
	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new ExtractRauschColemanHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Rausch Coleman Homes.csv", a.data().printAll());

	}

	public ExtractRauschColemanHomes() throws Exception {
		super("Rausch Coleman Homes", "https://www.rauschcolemanhomes.com");
		LOGGER = new CommunityLogger("Rausch Coleman Homes");
	}

	public void innerProcess() throws Exception{
		String html =U.getHTML("https://www.rauschcolemanhomes.com/find-your-home");
		U.log(html.length());
		int j = 0;
			String[] comSections =U.getValues(html, "<div class=\"CommunityCard_media\" data-reactid=", "View Details");
			
			for(String comUrlSec:comSections) { 
//				U.log("comUrlSec :"+comUrlSec);
				String comUrl=U.getSectionValue(comUrlSec, "href=\"", "\" data-reactid=\"");
				comUrl=BASEURL+comUrl; 
//				U.log("comUrl :"+j+":"+comUrl); j++;
				String comName =U.getSectionValue(comUrlSec,"class=\"CommunityCard_address\" data-reactid=\"","</h4>").replaceAll("\\d", "").replace("\">", "");
//				U.log("comName :"+comName);
//				comName=comName.replace("&#039;s", "'s").replace("Homestead of the GAP", "Homestead of the Gap");
//				U.log("regURL :"+regURL);
//				try {
//				U.log(comUrl);
//				U.log(comName);
//				U.log("count::::::::::::::::::::::::::::::::::::::"+j);
//				U.log(comUrlSec);
				j++;
				comUrlSec = comUrlSec.replaceAll("text: \\{4}", "");
//				U.log(comUrlSec); i++;
					addDetails(comUrl,comName,comUrlSec); 
//				} catch (Exception e) {}
				
			}
		
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comUrl,String comName,String comUrlSec) throws Exception {
//		if(i>=60) 
		{
		comUrl = comUrl.replace("\" data-reactid=\"176", "");
		LOGGER.AddCommunityUrl(comUrl);
		if(data.communityNameExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"*****************REPEATED***************");
			return;
		}
		
//		if(!comUrl.contains("https://www.rauschcolemanhomes.com/communities/arkansas/northwest-arkansas/432-walnut-hill"))return;
		//https://www.rauschcolemanhomes.com/communities/oklahoma/oklahoma-city-ok/323-robertsons-landing
		U.log(comUrl);
//		U.log("comUrlSec :"+comUrlSec);

		String comhtml =U.getHTML(comUrl);
		comhtml=comhtml.replace("&#x27;s", "'s");
		U.log(U.getCache(comUrl)); U.log("one");
		U.log(comhtml.length());
		String comData = comhtml;
		comName=comName.replace("Robertson&#x;s Landing", "Robertson's Landing");
		String comhtml1=U.getSectionValue(comhtml, "<h1 class=\"DetailHeader_heading\"", "class=\"ContactModal_btn btn btn-small");
		U.log("comhtml::"+comhtml.length());
		U.log("Community Name :"+comName);
		U.log("comUrl::"+comUrl);
	//================Address & Lat-Lng====================
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
		String note="";
		String geo="FALSE";
		
		
		
		latlng[0]=U.getSectionValue(comhtml1, "com/maps/place/", ",");
		latlng[1]=U.getSectionValue(comhtml1, ",", "/@");

		
		U.log("latlng[0] ::"+latlng[0]+"latlng[1] ::"+latlng[1]);
		U.log(comUrlSec);
//		U.log(comhtml);
//		String addSection = U.getSectionValue(comhtml, "<!-- react-text: 120 -->", "</span></div></h");
//		U.log(addSection);
		
//		if(addSection == null) {
//			 addSection = U.getSectionValue(comhtml, "", "");
//			 U.log(addSection);
//		}
		
		String addd = U.getSectionValue(comUrlSec, "\"><h4 class=\"CommunityCard_address\" data-reacti", "/span></div></h4></a>");
		U.log("addd"+addd);
		if(addd== null) {
			add=U.getAddressGoogleApi(latlng);
			U.log(Arrays.toString(add));
			geo="TRUE";
		}
		String a = addd;
		if(addd == null) {
			addd = ALLOW_BLANK;
		}
		if(geo != "TRUE") {
			a = a.replaceAll("data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
			a = a.replace("<div class=\"CommunityCard_city\" >", ",");
			a = a.replaceAll("</span><span >", ",");
			a = a.replaceAll("</span>,<span >", ",");
			a = a.replaceAll("<span >", "");
			a = U.getSectionValue(a, "CommunityCard_address", "<");
			a = a.replaceAll(",\\,", ",");
			add = a.split(",");
			U.log("comhtml2::"+a);
			
		}
	
		add[0] = add[0].replaceAll("\" >", "");
		U.log("Address ::"+add[0]+"//"+add[1]+"//"+add[2]+"//"+add[3]);
		String streetSec=U.getSectionValue(comhtml, "Located off of", "in Tuscaloosa");
		U.log("street"+streetSec);
		
		if(streetSec!=null && add[0].length()==0 && add[1]!=null && add[3]!=null && comUrl.contains("https://www.rauschcolemanhomes.com/communities/alabama/birmingham-al/379-the-ledges") ) {
			add[0]=streetSec.trim();
			U.log("Address sec ::"+add[0]+"//"+add[1]+"//"+add[2]+"//"+add[3]);
		}
		
		
		if(add[0].length() == 0) {
			add=U.getAddressGoogleApi(latlng);
			U.log(Arrays.toString(add));
			geo="TRUE";
		}
		if(add[0]== null | add[1] == null |add[2] ==null|add[3]==null) {
			add=U.getAddressGoogleApi(latlng);
			U.log(Arrays.toString(add));
			geo="TRUE";
		}
		if(add[2]== null) {
			add=U.getAddressGoogleApi(latlng);
			U.log(Arrays.toString(add));
			geo="TRUE";
		}
		if(add[0]!=null) {
			add[0]=add[0].replace("Settler&#x27;s", "Settler's");
		}
	
		
		
		if(latlng[0]==null && latlng[1]==null) {
			add[0]=ALLOW_BLANK;
			add[1]="Blue Springs";
			add[2]="MO";
			add[3]=ALLOW_BLANK;
			latlng=U.getlatlongGoogleApi(add);
			note="Street and Lat-Lng taken from city and State";
		}
		U.log(Arrays.toString(latlng));
		String addSec=U.getSectionValue(comhtml, "</a></strong>", "</p>");

		//==============HOME DATA===========
		String homehtml="";
		String moveinhtml="";
//		if(comhtml.contains("Home Designs") || comhtml.contains("Move-in Ready")) {
		U.log("comhtml::"+comhtml.length());
		
		if(comhtml.contains(">Available Floor Plans")) {
		String[] homesData=U.getValues(comhtml, "<h4 class=\"PlanCard_address", "View Details");
		U.log("Total floor plans :: "+homesData.length);
		for(String homeUrlSec :homesData) {
			String homeUrl=U.getSectionValue(homeUrlSec, "\" href=\"", "\"");
			homeUrl=BASEURL+homeUrl;
			U.log("homeUrl"+homeUrl);
			homehtml +=U.getHTML(homeUrl);
		}
		}
	//============MOVE-IN-READY==============
		
		int nomvin=0; int quickcount=0;
		int qCount=0;
		if(comhtml.contains(">Move-In Ready Homes")) {
//		String[] moveinData=U.getValues(moveinSec, "<div class=\"columns\">", "</ul>");
			String[] moveinData=U.getValues(comhtml, "<div class=\"HomeCard_planBtn\"", "View Details");
			U.log("Total floor plans :: "+moveinData.length);
			qCount=moveinData.length;
			quickcount=moveinData.length;
		for(String moveinUrlSec:moveinData) {
//			if(moveinUrlSec.contains("10487"))
//			  U.log("mmmm  "+moveinUrlSec);
			if(moveinUrlSec.contains("image-col sold-1")) {
				nomvin++;
			}
			String moveinUrl=U.getSectionValue(moveinUrlSec, " href=\"", "\"");
			moveinUrl=BASEURL+moveinUrl;
			U.log(moveinUrl);
			moveinhtml +=U.getHTML(moveinUrl);
//			 
		}
		}
		
//		U.log("MMMM"+Util.matchAll(comDataSqFt,"[\\w\\W\\s]{50}1,990[\\w\\W\\s]{50}", 0));

	//===========PRICE==============
		String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
		
		comData = comData.replaceAll("<p class=\"monthly-price\">starting at <span class=\"price\">\\$\\d{3},\\d{3}</span></p>", "");
		
		String[] price=U.getPrices(comData+moveinhtml+homehtml, "\\d,\\d{3}</b>|class=\"price\">\\$\\d{3},\\d{3}</p>|price\">\\$\\d{3},\\d{3}</span>|\\$\\d{3},\\d{3}</span>", 0);
		minPrice =(price[0]==null) ? ALLOW_BLANK:price[0];
		maxPrice =(price[1]==null) ? ALLOW_BLANK:price[1];
		U.log("minPrice :"+minPrice+ " : "+"minPrice :"+maxPrice);
		
//		U.log("MMMM"+Util.matchAll(comData,"[\\w\\W\\s]{50}1075[\\w\\W\\s]{50}", 0));
		
	//===========SQFT==============
		String minSqf=ALLOW_BLANK,maxSqf=ALLOW_BLANK;
		String[] sqft=U.getSqareFeet(comData+moveinhtml+homehtml, " \\d{4} sq/ft</li>|\\d{4} sq/ft|\\d{1},\\d{3} SQFT|\\d,\\d{3}</b><!-- react-text: ", 0);
		minSqf =(sqft[0]==null) ? ALLOW_BLANK:sqft[0];
		maxSqf =(sqft[1]==null) ? ALLOW_BLANK:sqft[1];
		U.log("minSqf :"+minSqf+ " : "+"maxSqf :"+maxSqf);
		
//		U.log("MMMM"+Util.matchAll(comData,"[\\w\\W\\s]{50}sq/ft[\\w\\W\\s]{50}", 0));
		
	//==========Community-Type============
		comhtml = comhtml.replace("about the Lakeside Cottages community", "about the Lakeside community Cottages community");
		
		String ctype=U.getCommType(comhtml);
//		String ctype=U.getCommType("");
		//U.log("MMMM"+Util.matchAll(comhtml,"[\\w\\W\\s]{50}lakeside[\\w\\W\\s]{50}", 0));
	//==========Property-Type============
		//U.log("MMMM"+Util.matchAll(comhtml,"[\\w\\W\\s]{50}cottage[\\w\\W\\s]{50}", 0));
//		U.log("MMMM"+Util.matchAll(homehtml,"[\\w\\W\\s]{50}villa[\\w\\W\\s]{50}", 0));
		
		//=+++++++++++++++++++++++++++++++++
//		String ptype=U.getPropType(("").replaceAll("Village|village|HOA fees are not included|cottages-at-lane",""));

		String ptype=U.getPropType((moveinhtml+homehtml+comhtml).replaceAll("Lakeside Cottages|lakeside cottages|Lakeside cottages|lakeside-cottages|Lakeside-Cottages", "").replaceAll("Village|village|HOA fees are not included|cottages-at-lane",""));
	//==========D Property-Type============
//		U.log("MMMM"+Util.matchAll(moveinhtml+homehtml+comhtml,"[\\w\\W\\s]{50}cottages[\\w\\W\\s]{50}", 0));
//		U.log("MMMM"+Util.matchAll(homehtml,"[\\w\\W\\s]{50}ranch[\\w\\W\\s]{50}", 0));
//		String dtype=U.getdCommType(("").replaceAll("franchot-fields|redstone-ranch|still-creek-ranch", ""));
		String dtype=U.getdCommType((moveinhtml+homehtml).replaceAll("franchot-fields|redstone-ranch|still-creek-ranch", ""));

	//==========Property Status============	
//		String pstatus=U.getPropStatus(("").replace("Phase 2 pricing coming soon", ""));
		String pstatus=U.getPropStatus((comhtml+comUrlSec).replace("Phase 2 pricing coming soon", ""));
		U.log(comUrlSec);
//		if(comhtml.contains("div class=\"image-col sold-1\"")) {
//			pstatus = pstatus.replaceAll("Move-in Ready|, Move-in Ready", ALLOW_BLANK);
		
//		}
		
		
		pstatus=pstatus.replaceAll(", Move-in Ready|Move-in Ready, |Move-in Ready", "");
		pstatus = pstatus.replace("Coming Soon-", "Coming Soon")
				.replace("Closeout-", "Closeout");
		
		U.log("pstatus111: "+pstatus);
		
		U.log("q1qqq "+quickcount);
		U.log("WQQQQ "+nomvin);
		
		if(qCount>0) {
			if(pstatus.length()>3 && pstatus!=ALLOW_BLANK ){
				pstatus=pstatus+", Move-in Ready";
			}
			else{
				pstatus="Move-in Ready";
			}
		}
		if(pstatus.isEmpty()) {
			pstatus=ALLOW_BLANK;
		} 
		
		U.log("pstatus: "+pstatus);
		
//	if(comUrl.contains("https://www.rauschcolemanhomes.com/division/find/oklahoma-city/mustang-farms"))
//		pstatus="Coming Soon";
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comhtml+comUrlSec, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));
		
		//=================== Note ========================
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comhtml, "[\\s\\w\\W]{30}move-in[\\s\\w\\W]{30}", 0));
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		 
		 
	
 		String notes = U.getnote(comhtml);
		data.addCommunity(comName, comUrl, ctype);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(notes);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
	}
		i++;
		
	}
}