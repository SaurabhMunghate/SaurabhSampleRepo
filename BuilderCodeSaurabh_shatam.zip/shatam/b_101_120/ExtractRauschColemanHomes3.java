/**
 * @author Priti
 * @date April 2018
 * 
 */
package com.shatam.b_101_120;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRauschColemanHomes3 extends AbstractScrapper {

	int i = 0;
	static int j = 0, count = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	private static final String BASEURL = "https://www.rauschcolemanhomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractRauschColemanHomes3();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Extract Rausch Coleman Homes.csv", a.data().printAll());
	}

	// WebDriver driver=new FirefoxDriver();
	// private String commType;
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String,String>();
	public ExtractRauschColemanHomes3() throws Exception {

		super("Extract Rausch Coleman Homes", "https://www.rauschcolemanhomes.com");
		LOGGER = new CommunityLogger("Extract Rausch Coleman Homes");
	}

	public void innerProcess() throws Exception {
		String basehtml = U.getHTML(BASEURL);
		String commumitylistHtml=U.getHTML("https://www.rauschcolemanhomes.com/communities");
		String comunityListMain=U.getSectionValue(commumitylistHtml, "<h2 class=\"CommunityResults_count\"", "<div class=\"CTA_wrapper\"");
		String communityList[]=U.getValues(comunityListMain, "class=\"CommunityCard_wrapper\"", "class=\"CommunityCard_detailButton\"");
		U.log("Total communities are="+communityList.length);
		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(commumitylistHtml, "__PRELOADED_STATE__ =", "</script>");
		if (removeScript == null)
			removeScript = "";
		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
		String redirecrSec=U.getSectionValue(removeScript, "\"redirects\":", "]");
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities");
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans");
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes");
		String plans[] = U.getValues(planJson.toString(), "{\"@type\":\"ProductModel", "\"type\":\"plan\"}");

		String homes[] = U.getValues(homeJson.toString(), "{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}");
		for (String home : homes) {
			String comunityIn = U.getSectionValue(home, "\"containedIn\":\"", "\"");
			homesData.put(comunityIn, home);
		}
		for (String plan : plans) {
			String[] comms = U.getValues(plan, "{\"community\"", "}]}");
			for (String com : comms) {
				String comunityIn = U.getSectionValue(com, ":\"", "\"");
				plansData.put(comunityIn, com);
			}
		}
		U.log(homesData.size());
		U.log(plansData.size());
		String comSection[] = U.getValues(
				U.removeSectionValue(commJson.toString(), "\"unpublished\":[", "receivedAt\":"),
				"{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");

		for (String comSec : comSection) {
			commDatas.put(U.getSectionValue(comSec, "\"sharedName\":\"", "\","), comSec);
			//break;
		}
		for (String commSec : communityList) {
			String commUrl="https://www.mungo.com"+U.getSectionValue(commSec, "href=\"", "\"");
			String sharedName=commUrl.split("/")[6];
			commSec=commDatas.get(sharedName)+commSec;
			addDetails(commUrl, commSec);
			//break;
		}
		U.log(">>>>>" + comSection.length);
		U.log(count);
		LOGGER.DisposeLogger();
	}
	private void addDetails(String cUrl, String cSec) throws Exception {
		// TODO Auto-generated method stub
	//	if(j>=61)
	//	{
//	try	{
//			if(!cUrl.contains("https://www.mungo.com/communities/wilmington/leland/park-west-at-brunswick-forest"))return;
			LOGGER.AddCommunityUrl(cUrl);
			
			U.log("Count== "+j+":::::::::::"+cUrl);
			String cDesc=U.getSectionValue(cSec, "<div class=\"CommunityCard_inner\" ", "<li class=\"CommunityCard_list2Item\"");
			String comName = U.getSectionValue(cSec, "\"MarketingName\":\"", "\"");//369,683
			if (comName.length() < 2)
				comName = U.getSectionValue(cSec, "\"MarketingName\":\"\",\"Name\":\"", "\"");
			String comId = U.getSectionValue(cSec, "\"_id\":\"", "\"");
			comName=comName.replaceAll("^Available ", "");
			U.log("comId=="+comId);
			U.log("comName=="+comName);
//			U.log("cSec==="+cSec);
			
//			U.log("MATCH========"+Util.matchAll(cSec, "\"ID\":\"Bool_CommSlsOfficeOffSite\",\"Value\":\"True\"", 0));

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec = U.getSectionValue(cSec, "\"address\":{\"@type\":\"PostalAddress\"", "},\"");
			String directions=U.getSectionValue(cSec, "\"outOfCommunity\"", ",\"photos\"");
			
			if (addSec != null&&(!(directions.contains("\"order\":0,"))))  {
				
              add[0] = U.getSectionValue(addSec, "\"streetAddress\":\"", "\"");
				
				String salesOffice=U.getSectionValue(cSec, ",\"SalesOfficeStreet\":\"", "\"");
				U.log(salesOffice+"    "+add[0]);
				if(!salesOffice.trim().equals(add[0].trim()))
					add[0]=ALLOW_BLANK;
				add[1] = U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
				add[2] = U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
				add[3] = U.getSectionValue(addSec, "\"postalCode\":\"", "\"");
//				add[0] = U.getSectionValue(addSec, "\"streetAddress\":\"", "\"");
//				add[1] = U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
//				add[2] = U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
//				add[3] = U.getSectionValue(addSec, "\"postalCode\":\"", "\"");
			}
			if (add[0].length() < 2) {
				add[0] = ALLOW_BLANK;
			}
			String note=ALLOW_BLANK;
			U.log(Arrays.toString(add));
			String latLngSec = U.getSectionValue(cSec, "\"geoIndexed\":[", "],\"");
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			if (latLngSec != null && latLngSec.length() > 5) {
				U.log(latLngSec);
				String[] tempLnf = latLngSec.split(",");
				latLng[0] = tempLnf[1];
				latLng[1] = tempLnf[0];
			}
			String geo = "False";
			U.log(Arrays.toString(latLng));
			if(add[0]==ALLOW_BLANK&&latLng[0]==ALLOW_BLANK&&add[1]!=ALLOW_BLANK&&add[2]!=ALLOW_BLANK) {
				latLng=U.getGoogleLatLngWithKey(add);
				add=U.getAddressGoogleApi(latLng);
				geo="True";
				note="Address And LatLng Taken From City And State";
			}
			if(add[0]==ALLOW_BLANK&&latLng[0]!=ALLOW_BLANK) {
				add=U.getAddressGoogleApi(latLng);
				geo="True";
			}
			String hradLine=U.getSectionValue(cSec, "\"headline\":\"", "\",");
			String comDesc = U.getSectionValue(cSec, "\"Description\":\"", "\",\"");
			String amenites[] = U.getValues(cSec, "{\"ID\":\"Text_Comm", "}");
			String ammenityStry = ALLOW_BLANK;
			String ammenitySec=U.getSectionValue(cSec, "\"amenities\":[","]");
			//U.log(amenites.length);
			for (String am : amenites) {
				// U.log(am);
				ammenityStry = ammenityStry + " , " + U.getSectionValue(am, "\"Value\":\"", "\"");
				// break;
			}
			// U.log(ammenityStry);
			String comType = U.getCommunityType((cSec+comDesc + ammenityStry).replaceAll("Elongated", ""));
			U.log("comType=="+comType);
			

			
			String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId);
			String homesecs = ALLOW_BLANK;
			if (homeData != null) {
				for (String home : homeData) {
					homesecs += home;
				}
			}
			String storySec=ALLOW_BLANK;
			ArrayList<String> planData = (ArrayList<String>) plansData.get(comId);
			String plansecs = ALLOW_BLANK;

			if (planData != null) {
				for (String plan : planData) {
					plansecs += plan;
				}
				
			}
//			storySec=plansData.get(stories);MMMMMMMMM
			 U.log("homesecs::::::::::::::::: \n"+homesecs);

			String[] sqft = U.getSqareFeet(comDesc +  cSec +plansecs + homesecs,
					"\\d,\\d{3} to an ample \\d,\\d{3} square feet|range from \\d{1},\\d{3} to over \\d{1},\\d{3} square feet|\\d{1},\\d{3} to more than \\d{1},\\d{3} square feet|from \\d,\\d{3} to over \\d,\\d{3} square. feet.|\\d,\\d{3} to more than \\d{4} square feet|\\d{4} to more than \\d,\\d{3} square feet|\\d,\\d{3} to a generous \\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} to more than \\d,\\d{3}|\\d,\\d{3} square feet|\"sqft\":\\d{4},|\"sqftLow\":\\d{4},|\"sqftHigh\":\\d{4},|\\d,\\d{3} to more than \\d,\\d{3} square feet.",
					0);
			U.log("sqft==="+sqft[0] + " " + sqft[1]);
			minSqFt = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqFt = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			String metatagSec=U.getSectionValue(cSec, "\"metaTags\":{","\"title\"");
			if(metatagSec!=null)
			 cSec=cSec.replace(metatagSec,"");
			String[] mktngTagLine=U.getValues(cSec, "{\"ID\":\"Text_SectMktTagline\",\"Value\"","}");
			if(mktngTagLine!=null) {
			U.log(Arrays.toString(mktngTagLine));
			for(String val:mktngTagLine){
				cSec=cSec.replace(val, "");
			}
			}
			String[] price = U.getPrices((comDesc + cSec.replace("00s", "00,000") + plansecs + homesecs).replace("Choose from 7 floorplans starting in the high $200s.", ""),
					"Mid \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\"Price\":\\d{6},\"RatifiedDate\":\"", 0);
			//U.log(plansecs);
		//	U.log(homesecs);


			
			U.log("price=="+price[0] + " " + price[1]);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			String stsSec=U.getSectionValue(cSec, "\"status\"", ",")+U.getSectionValue(cSec, "<div class=\"CommunityCard_headlineBanner\" ", "</div>");
 
//			U.log("MMMMMMMMM"+Util.match(cDesc, "[\\s\\w\\W]{50}new phase[\\s\\w\\W]{10}", 0));
//			U.log("MMMMMMMMM"+Util.match(comDesc, "[\\s\\w\\W]{50}1,600[\\s\\w\\W]{50}", 0));
//			U.log("MMMMMMMMM"+Util.match(comDesc + plansecs + homesecs, "[\\s\\w\\W]{50}Stories[\\s\\w\\W]{50}", 0));
			String propStatus = U.getPropStatus((cDesc+comDesc+hradLine+stsSec).replace("Opportunities Limited", "Limited Opportunities"));
			U.log("propStatus=="+propStatus);
			
			cSec=cSec.replaceAll("\"ID\":\"Text_SectMktName\",\"Value\":\"Garden Collection\"", "");
			
			String propType = U.getPropType((cSec+comDesc + plansecs + homesecs+ammenityStry+ammenitySec+comName)
					.replace("designated home office, flex or bonus room", "designated home office, Flex Room or bonus room")
					.replaceAll("\"Value\":\"Garden Collection", "")
					.replace("Merrill%20Villas%20", "Merrill-Villas %20").replaceAll("\"Value\":\"Entrance & Common Area Maintenance\"|Luxury vinyl plank flooring|luxury vinyl plank flooring|Luxury Vinyl Plank in Foyer",""));

			U.log("propType=="+propType);
			String dpType = U.getdCommType((comDesc + plansecs + homesecs).replace("The one and one-half story Carson plan", "The one story and one-half story Carson plan"));
//			U.log("MMMMMMMMM"+Util.match(comDesc + plansecs + homesecs, "[\\s\\w\\W]{50}one and one-half story[\\s\\w\\W]{50}", 0));

			U.log("dpType=="+dpType);
			if(note.length()>0) {
				String tempNote=U.getnote(comDesc);
				if(tempNote.length()>1)
					note +=", "+tempNote; 
			}else {
				note = U.getnote(comDesc);
			}
			
			U.log("propStatus=="+propStatus);
			propStatus=propStatus.replace("New Phase Now Open, Now Open", "New Phase Now Open")
					.replace("New Phase, New Phase Coming Spring 2022", "New Phase Coming Spring 2022")
					.replace("New Phase, Now Selling New Phase", "Now Selling New Phase");
//			if(cSec.contains("\"ID\":\"Bool_CommSlsOfficeOffSite\",\"Value\":\"True\""))
//			{
//				geo="True";
//			}
			comName=comName.replace("Merrill Villas", "Merrill");
			
			data.addCommunity(comName, cUrl, comType);
			data.addAddress(add[0].replace("StartPoint", ""), add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
	//	}
		j++;
	//	}
//
//	}catch (Exception e) {}
}

	public static String getNoHtml(String html) {
		String noHtml = null;
		noHtml = html.toString().replaceAll("\\<.*?>", " ");
		return noHtml;
	}
}
