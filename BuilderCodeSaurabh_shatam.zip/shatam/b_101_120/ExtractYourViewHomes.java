/*
 * @author : Pallavi
 * @date : 27/04/2019
 */
package com.shatam.b_101_120;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractYourViewHomes extends AbstractScrapper{
	int i = 0;
	public static CommunityLogger LOGGER;
	public ExtractYourViewHomes() throws Exception {
		super("View Homes", "https://yourviewhome.com/");
		LOGGER = new CommunityLogger("View Homes");

	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractYourViewHomes();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"View Homes.csv", a.data()
						.printAll());
		LOGGER.DisposeLogger();	
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String html = U.getHTML("https://yourviewhome.com/");
		
		String regUrlSections=U.getSectionValue(html, "<div class=\"section--regions\">", "</section>");
		
//		U.log("Region Sec ::: "+regUrlSections);
		String[] regUrls=U.getValues(regUrlSections, "<a href=\"", "\"");
		for(String url : regUrls){
			U.log("Region Url ::: "+url);
			if(url.contains("armadillohomes"))continue;
			String regHtm=U.getHTML(url);
			regHtm=regHtm.replaceAll("</div>\\s*</div>\\s*</div>", "end of community");
			String comSec[]=U.getValues(regHtm, "<h2 class=\"community_", "end of community");
			for(String comm:comSec) {
				String cUrl=U.getSectionValue(comm, "<a href=\"", "\"");
				addDetails(cUrl ,comm);
			}
			//addDetails(cUrl ,comSec, html);
			//break;
		}
	}
	
	public void addDetails(String url,String comSec) throws Exception {
		{		
//			if(!url.contains("https://yourviewhome.com/san-antonio/preserve-singing-hills"))return;
			U.log(i+"::::::::::communityUrl:::::::::::::::::"+url);
			String comHtml = U.getHTML(url);
			//==========com Name ===========
			String comName=U.getSectionValue(comSec, "<h2 class=\"community__name\">", "</h2>");
			comName = comName.replaceAll("&#039;", "'").replaceAll(" - Close Out Opportunities!$| at TRP$", "");
			U.log("comName::"+comName+"::");
			
			//==============Address ======================
			
			U.log("comSec::::::::"+comSec);
			
			String add[] ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addSec=U.getSectionValue(comSec, "\">", " </a>");
			U.log("addSec :: "+addSec);
			if(addSec!=null){
				addSec=addSec.replace("<br />", ",");
				addSec = addSec.replace("Monument CO", "Monument, CO");
				String[] tempAdd=addSec.split(",");
				U.log("Temp Address is ::::::"+ Arrays.toString(tempAdd));
				if(tempAdd.length==3){
					add[0]=tempAdd[0].trim();
					add[1]=tempAdd[1].trim();
					add[2]=Util.match(tempAdd[2],"\\w+");
					add[3]=Util.match(tempAdd[2],"\\d+");
				}
				if(add[3]==null) add[3]=ALLOW_BLANK;
				add[0]=U.getNoHtml(add[0]);
			}
			if(addSec == null || add[0] == ALLOW_BLANK) {
				
				addSec = U.getSectionValue(comHtml, "located at", ".");
				if(addSec == null)
					addSec = U.getSectionValue(comHtml, "Model Home Address:", "<");
				
				U.log("Model Address: "+ addSec);
				
				if(addSec != null) {
					addSec = addSec.replace("Texas,", "Texas");
					add = U.getAddress(addSec);
				}
			}
			U.log("Address is ::::::"+ Arrays.toString(add));
			//==================Lat-Lng==================
			String latLngSec=ALLOW_BLANK;
			String geo="FALSE";
			String[] latLng= {ALLOW_BLANK,ALLOW_BLANK};
			
			//fetch latlng from comm sec
			String llsec = U.getSectionValue(comSec, ";destination=", "\">");
			latLng=llsec.split("%2C");
			U.log(Arrays.toString(latLng));
			if(add[3].length()<3 && latLng[0].length()>4){
				add[3]=U.getAddressGoogleApi(latLng)[3];
				geo="TRUE";
			}
			if(add[0].length()<4 && latLng[0].length()>4){
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
			
			
			
			
			//===========Available and floor Home Plans=======
			String allAvailAndPlanHtml=ALLOW_BLANK;
			int quickcount = 0;
			if(comHtml.contains(">Home Designs</h1>")){
				String[] allplanurl=U.getValues(comHtml, "<a class=\"card--asset\" title=\"", ">");
				U.log("homePlanUrl::::::::"+allplanurl.length);
				for(String hurl:allplanurl){
//					U.log(hurl);
					hurl = U.getSectionValue(hurl, "href=\"", "\"");
					U.log(hurl);
					try{String homhtm =U.getHTML(hurl);
					allAvailAndPlanHtml+=U.getSectionValue(homhtm, "<h1 class=\"heading--color-primary\">", "Gallery</h1>");
					}catch(Exception e){}
					if(hurl.contains("available-homes"))
						quickcount++;	
					
				}
			}
			//U.log(allAvailAndPlanHtml);
			//========Prices================
			String minPrice = ALLOW_BLANK,maxPrice=ALLOW_BLANK;
			comHtml = comHtml.replaceAll("the \\$230s. Colorado", "").replace("high $240s", "low $240,000");
			 comHtml=comHtml.replaceAll("00s|00’s|00's|00s", "00,000").replace("30s", "30,000").replace("0s", "0,000");
			String[] prices=U.getPrices(comHtml+allAvailAndPlanHtml, "the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|price\">\\d{3},\\d{3}</span>|From the \\$\\d{3},\\d{3}from the low \\$\\d{3},\\d{3}|from the high \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}| mid \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|price--banner\">\\s*\\$\\d{3},\\d{3}|<strong>\\$\\d{3},\\d{3}</strong>|plan-price--value\">\\$\\d{3},\\d{3}</span>", 0);
			
			
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("minPrice:"+minPrice+ " maxPrice::"+maxPrice);
			
			//=========Squarefeet===========
			String minSqft=ALLOW_BLANK,maxSqft=ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							comHtml+allAvailAndPlanHtml,
							"\\d,\\d{3} to \\d,\\d{3} square feet|sqft\">\\d{4}</span> SQFT|and \\d,\\d+ sq ft|\\d,\\d{3} Sqft.|Up to <strong>\\d,\\d{3}</strong>",0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft--->"+minSqft+"  maxSqft-->"+maxSqft);

//			//=======community Type,Property Type, dType PropStatus=======
//					//U.log(comHtml);
			String comType=ALLOW_BLANK,propType=ALLOW_BLANK,dType=ALLOW_BLANK,PropStatus=ALLOW_BLANK;
//			
			//--------remove section----------
			comHtml=comHtml.replace("Villa Sport", "");
			
			comType=U.getCommType(comHtml);
			U.log("comType:::"+comType);
			propType=U.getPropType(comHtml+allAvailAndPlanHtml);
			U.log("propType:::"+propType);
			String note="";
			
			dType=U.getdCommType((comHtml+allAvailAndPlanHtml));
			U.log("dType:::"+dType);
			
//			//------------status-----------
			comHtml = U.removeComments(comHtml);
			comHtml=comHtml.replaceAll("Now selling from the Rain Dance model|Details Coming Soon|Selling out of our Hidden Valley Model|href=\"#quick-move-in-homes|including move-in ready|Move-in Ready|<section id=\"quick-move-in-homes\"|--color-primary\">Quick Move-In Homes</h1>| Quick Move-In Homes\\s*</a", "");
			comHtml = comHtml.replace("Coming Soon, Fall 2019", "Coming Soon Fall 2019").replace("Coming Soon, Summer 2019", "Coming Soon Summer 2019");
			//U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}Move-in Ready[\\w\\s\\W]{50}",0));
			PropStatus=U.getPropStatus(comHtml);
			U.log("PropStatus:::"+PropStatus);
	
			/*if(quickcount>0){
				PropStatus=PropStatus.replaceAll("Move-in Ready,", "");
				if(PropStatus != ALLOW_BLANK){
					PropStatus =PropStatus + ", Quick Move-in Homes";
				}
				else{
					PropStatus = "Quick Move-in Homes";
				}
			}*/
			if(url.contains("https://yourviewhome.com/las-cruces/elks-view"))PropStatus=PropStatus.replace("Coming Soon Fall 2019, Coming Soon","Coming Soon Fall 2019");
//			if(url.contains("https://yourviewhome.com/el-paso/peyton-estates"))PropStatus= "Coming Soon";//Img
			
			add[0]=add[0].replaceAll("target=(.*?)>", "");
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "\t*********Repeated******\t");
				return;
			}
			
			note = U.getnote(comHtml);
			if(note == null) note = "";
			
			LOGGER.AddCommunityUrl(url.replace("http://", "https://"));
			data.addCommunity(comName,url.replace("http://", "https://"), comType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].toLowerCase().trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(PropStatus);
			data.addNotes(note); 
			
		}i++;
	}
	
}
