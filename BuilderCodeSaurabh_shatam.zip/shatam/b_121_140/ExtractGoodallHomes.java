/**
 * @author saurabh
 * @date Sap 2022
 * 
 */
package com.shatam.b_121_140;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGoodallHomes extends AbstractScrapper {

	int i = 0;
	static int j = 0, count = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	private static final String BASEURL = "https://www.goodallhomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractGoodallHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Goodall Homes.csv", a.data().printAll());
	}

	
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String,String>();
	public ExtractGoodallHomes() throws Exception {

		super("Goodall Homes", BASEURL);
		LOGGER = new CommunityLogger("Goodall Homes");
	}

	public void innerProcess() throws Exception {
		String basehtml = U.getHTML(BASEURL);
		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(basehtml, "__PRELOADED_STATE__ =", "</script>");

		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
//		U.log(jobj.size());
//		String redirecrSec=U.getSectionValue(removeScript, "\"redirects\":", "]");
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities").getAsJsonObject().get("5702b629f410954eb27cef94");
		JsonArray comJsonData = (JsonArray) commJson.getAsJsonObject().get("data");
//		U.log(comJsonData);
		U.log("Total communities are = "+comJsonData.size());
		U.log("comJsonData"+comJsonData.size());
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans").getAsJsonObject().get("5702b629f410954eb27cef94");
		JsonArray planJsonData = (JsonArray) planJson.getAsJsonObject().get("data"); U.log("planJsonData"+planJsonData.size());
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes").getAsJsonObject().get("5702b629f410954eb27cef94");
		JsonArray homeJsonData = (JsonArray) homeJson.getAsJsonObject().get("data"); U.log("homeJsonData"+homeJsonData.size());
		
		String comm[] = U.getValues(comJsonData.toString(), "{\"@type\":\"GatedResidenceCommunity", "\"type\":\"community\"}"); U.log(comm.length);
		
		String plans[] = U.getValues(planJsonData.toString(), "{\"@type\":\"ProductModel\"", "\"planType\":\"Single Family\"}"); U.log(plans.length);

		String homes[] = U.getValues(homeJsonData.toString(), "{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}"); U.log(homes.length);
		
		
		for (String home : homes) {
			String comunityIn = U.getSectionValue(home, "\"containedIn\":\"", "\",");
			homesData.put(comunityIn, home);
		}
//		U.log(homes[0]);
		for (String plan : plans) {
				String comunityIn = U.getSectionValue(plan, "\"containedIn\":\"", "\",");
				plansData.put(comunityIn, plan);
		}
		U.log("homesData"+homesData.size());
		U.log("plansData"+plansData.size());
        int i = 0;
       
        String baseHtml = U.getHTML("https://www.goodallhomes.com/communities");
		String comSections[] = U.getValues(baseHtml, "<div class=\"CommunityCard_wrapper\"", "Visit Community");
		U.log("comSectionscomSections"+comSections.length);
//		HashMap<String, String> url = new HashMap<>();
//		for (String comSec : comSections) {
////			String comUrl = "https://www.goodallhomes.com" + U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");
//			String communityurl = "https://www.goodallhomes.com/" + U.getSectionValue(comSec, "href=\"/", "\"")+"0";
//			String communityurl1 = U.getSectionValue(communityurl, "ities/", "0")+"0";
//			String communityurl2 = U.getSectionValue(communityurl1, "/", "0")+"0";
//			String communityurl3 = U.getSectionValue(communityurl2, "/", "0").replace("-", "");
////			U.log(communityurl);
//			url.put(communityurl3.replace("0", ""), communityurl.replace("", ""));
//			
//		}
      
		for (JsonElement comJsonData1 : comJsonData) {
			String u2 = U.getSectionValue(comJsonData1.toString(), "\"sharedName\":", "\",").replace("\"", "").toString().toLowerCase();
			String streetAddress=comJsonData1.getAsJsonObject().get("address").toString().replace("\"", "").toLowerCase(); 
//			U.log(streetAddress.toString());
			String u1 = U.getSectionValue(streetAddress.toString(), ",addresslocality:", ",").toLowerCase(); 
//			U.log(u1);
			String commUrl = "https://www.goodallhomes.com/communities/"+"area/"+u1+"-tn"+"/"+u2;
			U.log(commUrl);
//			String uu = U.getSectionValue(comJsonData1.toString(), "\"sharedName\":", "\",").replace("\"", "").replace("-", "").toLowerCase();
//			U.log(uu);
//			String commUrl = url.get(uu);
			
//			commUrl = commUrl+"";
//            U.log(i+"::::"+commUrl);
//            U.log(comJsonData1.toString());
//            String UUU = U.getSectionValue(comJsonData1.toString(), "\"sharedName\": \"", "\",");
//            U.log(UUU);
//            break;
//i++;
			addDetails(commUrl.replace(" ", "-") , comJsonData1);	
			
//			//break;
		}
//		U.log(">>>>>" + comSection.length);
//		U.log(count);
		LOGGER.DisposeLogger();
	}
	

	private void addDetails(String cUrl, JsonElement cSec) throws Exception {
		// TODO Auto-generated method stub
	//	if(j>=61)
	//	{
//	try	{
//			if(!cUrl.contains("https://www.goodallhomes.com/communities/waters-edge"))return;
			LOGGER.AddCommunityUrl(cUrl);
			String add[] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
			String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
			String note = ALLOW_BLANK;
			String geo = "FALSE";
			String comId = U.getSectionValue(cSec.toString(), "\"_id\":\"", "\"");
			JsonParser jparser = new JsonParser();

			String streetAddress=cSec.getAsJsonObject().get("address").toString().replace("\"", ""); U.log(streetAddress);
			add[0] = U.getSectionValue(streetAddress, "streetAddress:", "}");  U.log(add[0]);
			add[1] = U.getSectionValue(streetAddress, "addressLocality:", ","); U.log(add[1]);
			add[2] = U.getSectionValue(streetAddress, "addressRegion:", ","); U.log(add[2]);
			add[3] = U.getSectionValue(streetAddress, "postalCode:", ","); U.log(add[3]);

			String geoIndexed=cSec.getAsJsonObject().get("geoIndexed").toString().replace("", ""); U.log(geoIndexed);
			U.log(geoIndexed);
			latlag[1] = U.getSectionValue(geoIndexed, "[",",");
			latlag[0] = U.getSectionValue(geoIndexed, ",","]");
			U.log("geoIndexed"+latlag[0]+" "+latlag[1]); 

			
			//===================================================================================================

			if(latlag[0]==ALLOW_BLANK || latlag[0]==null  || latlag[0].length()==0) {
//				latLng=U.getGoogleLatLngWithKey(add);
				latlag=U.getlatlongGoogleApi(add);
//				geo="True";
//				note="lat long Taken From add";
				U.log(latlag[0]+" "+latlag[1]); 
			}
//			if(add[0]==ALLOW_BLANK&&latlag[0]!=ALLOW_BLANK) {
//				add=U.getAddressGoogleApi(latlag);
//				geo="True";
//			}
			//===================================================================================================
			
			ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId);
			String homesecs = ALLOW_BLANK;
			if (homeData != null) {
				for (String home : homeData) {
					homesecs += home;
				}
			}
			U.log("homesecshomesecs"+homesecs);
			String storySec=ALLOW_BLANK;
			ArrayList<String> planData = (ArrayList<String>) plansData.get(comId);
			String plansecs = ALLOW_BLANK;
			if (planData != null) {
				for (String plan : planData) {
					plansecs += plan;
				}
				
			}
			U.log("plansecsplansecs"+plansecs);
			
			//===================================================================================================
//			U.log(cSec.toString());
			String[] price = U.getPrices( cSec.toString() +plansecs +homesecs ,
					"\"priceLow\":\\d{6},|\"priceHigh\":\\d{6},|priceLow\":\\d{6},|priceHigh\":\\d{6},", 0);
			U.log("price=="+price[0] + " " + price[1]);
			if(price[1] == null) {
				price[1] = ALLOW_BLANK;
			}
			if(price[0] == null) {
				price[0] = ALLOW_BLANK;
			}
			
			String[] sqft = U.getSqareFeet(cSec.toString() +plansecs +homesecs 
					, "\"sqftHigh\":\\d{4},|\"sqftLow\":\\d{4},|sqftHigh\":\\d{4},|sqftLow\\\":\\d{4},", 0);
			U.log("sqft==="+sqft[0] + " " + sqft[1]);
			if(sqft[1] == null) {
				sqft[1] = ALLOW_BLANK;
			}
			if(sqft[0] == null) {
				sqft[0] = ALLOW_BLANK;
			}
			//===================================================================================================
			String comName = U.getSectionValue(cSec.toString(), "\"sharedName\":", "\",").replace("\"", "").toString();	
//			String comName = U.getSectionValue(cSec.toString(), "com\",\"name\":\"", "\","); 
			U.log(comName);
			String comType = U.getCommunityType(cSec.toString()+plansecs+homesecs);
			U.log("comType=="+comType);
			String propStatus = U.getPropStatus(cSec.toString()+plansecs+homesecs);
			U.log("propStatus=="+propStatus);
			String propType = U.getPropType(cSec.toString()+plansecs+homesecs);
			U.log("propType=="+propType);
			String dpType = U.getdCommType(cSec.toString()+plansecs+homesecs);
			U.log("dpType=="+dpType);
			
			//===================================================================================================


			data.addCommunity(comName, cUrl, comType);
			data.addAddress(add[0], add[1], add[2] , add[3]);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(price[0], price[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
//	//	}
		j++;
	//	}
//
//	}catch (Exception e) {}
}

//	public static String getNoHtml(String html) {
//		String noHtml = null;
//		noHtml = html.toString().replaceAll("\\<.*?>", " ");
//		return noHtml;
//	}
}
