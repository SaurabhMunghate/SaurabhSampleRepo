/**modified by : Priti
 * Date :27 Nov 2018
 * 
 */

package com.shatam.b_121_140;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.bcel.generic.AALOAD;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractHomesbyWestbay extends AbstractScrapper {
	static CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver=null;
	public static String HOME_URL = "https://www.homesbywestbay.com/";

	public ExtractHomesbyWestbay() throws Exception {
		super("Homes by Westbay", HOME_URL);
		LOGGER = new CommunityLogger("Homes by Westbay");
	}

	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		AbstractScrapper a = new ExtractHomesbyWestbay();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Homes by Westbay.csv", a.data().printAll());
		LOGGER.DisposeLogger();
	}

	ArrayList<String> comm = new ArrayList<String>();

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.homesbywestbay.com/find/where-we-build");
		String[] sections = U.getValues(html, "Base Price</th>", "</table>");
		U.log("sections" + sections.length);
		
		String[] subSecs = U.getValues(html, "<td class=\"item grid__cell\"><a href", "</tr>");
		U.log("subSecs" + subSecs.length);
		for (String comSec : subSecs) {
			//U.log("comSec: "+comSec);
			comm.add(comSec);
		}
		//U.log("size: "+comm.size());
//		try {
			addDetail();
//		} catch (Exception e) {}
		
	}

	public void addDetail() throws Exception {
		int c=1;
		for (String comSec : comm) {
//			 U.log(comSec);
			String comUrl = HOME_URL + U.getSectionValue(comSec, "=\"", "\">");
			U.log(+c+" comUrl : " + comUrl);
			c++;
			String comHtml = U.getHtml(comUrl,driver);
			
//			U.log("comUrl ===>"+comUrl);
			addComDetails(comSec, comHtml, comUrl);
		}
		
		try{
			driver.close();
			driver.quit();
		}catch(Exception e){}
	}

	public void addComDetails(String comSec, String comHtml, String communityUrl) throws Exception {
		//TODO: For Single Community Execution

//		try{
//		if(j>=11)
		{
//			if(!communityUrl.contains("https://www.homesbywestbay.com//lithia/creek-ridge-preserve-artisan-community"))return;
			
			// ******************Community Name***************************
//			U.log("comSec==="+comSec);
			//----Remove Header Section----
//			U.log(comHtml.length());
			comHtml = U.removeSectionValue(comHtml, "<header>", "</header>");
			
			//-------Remove Community List-----
//			comHtml = U.removeSectionValue(comHtml, "<h2>Homes by WestBay Communities</h2>", "Join the Vip List");
//			String communityName = U.getSectionValue(comSec, "<p class=\"community-name\">", "</p>");
			
			String communityName = U.getSectionValue(comHtml, "<h1 class=\"micro__title\">", "</h1>");
			U.log("communityName"+communityName);
//			communityName = communityName.replace("&#039;", "'").replaceAll("Villas$", "");
			U.log(j+"\t :: " +communityUrl + "\t :: " + communityName);

			// ******************Community Address***************************
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String geoCode = "FALSE";
			String addrs = U.getSectionValue(comHtml, "<h4 class=\"title\">Sales Office</h4>", "</a>");
			U.log("addrs: "+addrs);
			
			String ss = "";
			if (addrs != null) {
				addrs = addrs.replaceAll("<p>Closed on Christmas Eve and Christmas Day</p>|COMING SOON", "");
				ss = U.getSectionValue(addrs, "</p>", "<br />");
				if(ss==null) {
					ss = U.getSectionValue(addrs, "</p> <p>", "<br>");
				}
				if(ss==null) {
					ss = U.getSectionValue(addrs, "<p>", "<br>");
				}
				U.log("ss from here: "+ss);
				if(ss==null) {
					ss = U.getSectionValue(comHtml, "<h3 class=\"micro__price\">", "</h3>");
					if(ss!=null) {
						if(ss.contains("Coming Soon to San Antonio, FL (2023)")) 
							ss = ss.replace("Coming Soon to San Antonio, FL (2023)", " ,San Antonio, FL, ");
					}
				}
				if(ss==null) {
					ss = U.getSectionValue(comHtml, "<h4 class=\"title\">Sales Office</h4>", "<br />");

					U.log("ss One: "+ss);
				}

			
//			U.log("addrs:::::::::::"+addrs.trim());
			if (ss != null) {
				ss = ss.replaceAll("\n|<p>", " ").replace("Coming Soon to Parrish", " ,Parrish, FL, ");
//				.replace("4620 Ballantrae Blvd, Land O' Lakes, FL 34638", "4620 Ballantrae Blvd, Land O' Lakes, FL, 34638")
				U.log("ss :"+ss);
				String address[] = ss.split(",");
				U.log("Address >>>>> "+Arrays.toString(address));
				if (address.length > 2) {
					add[0] = address[0].trim();
					if(add[0].contains("COMING SOON"))
						add[0] = ALLOW_BLANK;
					
					add[1] = address[1].replace("O&#039;", "O'").trim();
					add[2] = address[2].replaceAll("\\d+", "").trim();
					add[3] = Util.match(address[2], "\\d+");
//					U.log("===>"+add[2]);
					if(add[2].length() > 2)
						add[2] = USStates.abbr(add[2]);
					if(add[3] == null)
						add[3] = ALLOW_BLANK;
					
					U.log("add >>>>> "+Arrays.toString(add)+" geoCode:"+geoCode);
				}
			}

			// *************************Lat and Lng********************************
						U.log(Arrays.toString(add));
						String latsec = U.getSectionValue(addrs, "href=\"https://maps.google.com/maps?daddr=", "\"");
						U.log("latsec: "+latsec);
						
						if(latsec == null) {
							latsec = U.getSectionValue(addrs, "href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
							U.log("latsec from here: "+latsec);
						}
						
						
						if(latsec == null && communityUrl.contains("//mirada/mirada-community")) {
							latsec = U.getSectionValue(comHtml, "mirada\\/mirada-community", "plan_ids");
						}
						
						if (latsec != null) {
							lat = Util.match(latsec, "\\d{2,3}.\\d{3,}");
							lng = Util.match(latsec, "-\\d{2,3}.\\d{3,}");
						}
						
						U.log(" From here latLng: lat :"+lat+"\tlng :"+lng);
			
			
			
			
//			if(add[0].isEmpty() || add[0] == ALLOW_BLANK &&  add[3].isEmpty() || add[3] == ALLOW_BLANK 
//					&& add[1] != null || add[1] != ALLOW_BLANK && add[2] != null)
			
			if(add[0] == ALLOW_BLANK) {
				
				String[] latlon = U.getlatlongGoogleApi(add);
				if(latlon == null) latlon = U.getlatlongHereApi(add);
				lat = latlon[0];
				lng = latlon[1];
				add = U.getAddressGoogleApi(latlon);
				if(add == null) add = U.getAddressHereApi(latlon);
				//note = "Address and Latlong Taken From City And State";
				geoCode="True";
				U.log("From iNside: "+Arrays.toString(add));
			}
			
			String note = ALLOW_BLANK;
			if (communityUrl.contains("https://www.homesbywestbay.com/wesley-chapel/union-park-65s-community")
					|| communityUrl
							.contains("https://www.homesbywestbay.com/wesley-chapel/union-park-75s-community")) {
				add[1] = "Wesley Chapel";
				add[2] = "FL";
				String[] latlon = U.getlatlongGoogleApi(add);
				if(latlon == null) latlon = U.getlatlongHereApi(add);
				lat = latlon[0];
				lng = latlon[1];
				add = U.getAddressGoogleApi(latlon);
				if(add == null) add = U.getAddressHereApi(latlon);
				note = "Address and Latlong Taken From City And State";
				geoCode="True";
			}
//			if(communityUrl.contains("hawkstone-innovation") || communityUrl.contains("hawkstone-inspiration")) {
////				add[1] = "Lithia";
////				add[2] = "FL";
////				String[] latlon = U.getlatlongGoogleApi(add);
//				lat = "27.817399";
//				lng = "-82.231738";
//				add = U.getAddressGoogleApi(new String[] {lat,lng});
//				if(add == null) add = U.getAddressHereApi(new String[] {lat,lng});
//				note = "Address Taken From City And State";
//				geoCode="True";
//			}
			
//			if(communityUrl.contains("https://www.homesbywestbay.com/valrico/grove-woods-community")){
//				//Exceed Current Page LatLng
//				String[] latlon = U.getlatlongGoogleApi(add);
//				if(latlon == null) latlon = U.getNewBingLatLong(add);
//				lat = latlon[0];
//				lng = latlon[1];
//				geoCode="True";
//			}
			if(communityUrl.contains("https://www.homesbywestbay.com/parrish/brightwood-at-north-river-ranch-community")){
				String addressSec=U.getSectionValue(comHtml, "Sales Office</h4> <p>", "br> <a href");
				add=U.getAddress(addressSec);
//				U.log(addressSec);
			}
			U.log(lat+"\t"+lng);
			if (add[2] == null)add[2] = ALLOW_BLANK;

			add[0] = add[0].replaceAll("\\s{2,}", "");

			if (add[0].length() == 0)add[0] = ALLOW_BLANK;
			if (add[3] == null)add[3] = ALLOW_BLANK;
			if(add[0]==ALLOW_BLANK && lat!=null) {
				add=U.getAddressGoogleApi(new String [] {lat,lng});
				if(add == null) add = U.getAddressHereApi(new String[] {lat,lng});
				geoCode="TRUE";
			}
			add[1] = add[1].replaceAll("\\d+", "");
			add[2] = "FL";
			
			// *************************Area in Sqft********************************
//		U.log(comSec);
		String comId=Util.match(comHtml, "\"community_id\":(\\d+)",1);
		U.log(comId);
		
		
		String tempHtml =U.removeSectionValue(comHtml, "JsonData =", "</html>");
		if(tempHtml != null) comHtml = tempHtml;
		
		tempHtml=U.removeSectionValue(comHtml, "Download Site Map", "<div class=\"content\">");
		if(tempHtml != null) comHtml = tempHtml;
		
		
		//--------Quick Data-----------------
		String quickData=U.getHTML("https://www.homesbywestbay.com/find/quick-move-in?community="+comId.trim());
		U.log(">>>>>>>"+"https://www.homesbywestbay.com/find/quick-move-in?community="+comId.trim());
		//------- quick page ----
		int quickCount = 0;
		String quickPrice = "";
		try {
		String quickHtml = U.getHTML("https://www.homesbywestbay.com/find/quick-move-in?community="+comId+"&json=true");
		String quickHomes [] = U.getValues(quickHtml, "<div class=\"qmi-card\">", "<div is=\"qmi-card\"");
		
		for(String quickHome : quickHomes){
			
			if(quickHome.contains(communityUrl.replace("https://www.homesbywestbay.com/", "")))
			{
				U.log("::::::::Found Quick Home::::::::::");
				quickCount++;
				quickPrice += quickHome;
			}
		}	
		}catch (Exception e) {
			// TODO: handle exception
		}
		
//				U.log(U.getSectionValue(comHtml, "JsonData =", "</html>"));
			String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(comHtml,
					"</svg>(\\s*|\\n)\\d,\\d{3} - \\d,\\d{3}</div>|</svg>(\\s*|\\n)\\d,\\d{3}</div>",
					0);
			minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("Square Feet : "+minSqFeet+"\t"+maxSqFeet);
			
//			U.log("MMMMMMMMM "+Util.matchAll(comHtml, "[\\w\\s\\W]{10}2,427 - 2,761[\\w\\s\\W]{10}", 0));
	

			// *************************Community Prices****************************

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			492
			comHtml=comHtml.replaceAll("0’s|0'S|0's", "0,000").replaceAll("<td.*?</td>|<option.*?</option>", "");
//			String[] price = U.getPrices((comHtml +comSec+quickData + quickPrice).replace("$882,431", ""),
//					 "to over \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>|"
//					 + ">\\$\\d,\\d{3},\\d{3}</span>", 0);
			
			String[] price = U.getPrices((comHtml +comSec),"\\$\\d{1},\\d{3},\\d{3}|from \\$\\d{1},\\d{3},\\d{3}|List Price: <strong>\\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|List Price: <strong>\\$\\d{3},\\d{3}</strong>", 0);
			
			U.log("price : "+ Arrays.toString(price));
//		U.log("comSec: "+comSec);
//			U.log("MMMMMMMMM "+Util.matchAll(comSec, "[\\w\\s\\W]{10}\\$594[\\w\\s\\W]{10}", 0));

			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log(minPrice+"\t"+maxPrice);
			
			//--------Homes Data-----------------
			String[] plnsCommSec = U.getValues(comHtml, "<div class=\"floorplan-card \">", "view details");
			String allPlansData = "";
			
			for (String planUrl : plnsCommSec) {
				planUrl =  U.getSectionValue(planUrl,"<h2 class=\"city\">", "</h2>").toLowerCase()
						.replace(" with sunroom", "").replace(" ", "-");
				planUrl = communityUrl+"/"+planUrl+"-detail";
				U.log("planUrl : "+planUrl);
				//try{
				String plansHtml = U.getHTML(planUrl);
				if(plansHtml == null) continue;
				allPlansData += U.getSectionValue(plansHtml, "residence-detail__sub-header-title", "qmi-detail__content-right\">");
				//}catch(Exception e){}
			}
//			allPlansData = allPlansData.replaceAll("image-title\">\\s*Craftsman ", "Craftsman-style home ");
		
			
			// *************************Adding Data********************************		
			
			
			//-----Community Type------
			comHtml = comHtml.replace("lakefront and wetland homesites", "Lakefront community and wetland homesites").replaceAll("Lakefront and Neighborhood Parks", "");
			String communityType = U.getCommunityType(comHtml.replace("elongated", ""));

			//------Derived Type-------
			String descSec=U.getSectionValue(comHtml, "\"welcome_copy\":\"", "/p>")+U.getSectionValue(comHtml, "\"neighborhood_description\":\"", "}");
			//----Remove Script Section---------
//			comHtml =U.removeSectionValue(comHtml, "let JsonData = {", "</html>");	
			
			comHtml = comHtml.replace("one- and two- story homes", " 1 story ,  2 Story homes")
					.replace("two-story", "2 Story");
			U.log(descSec);
			String derivedPropertyType = U.getdCommType( (comHtml + communityName +descSec + allPlansData).replaceAll("First floor concrete block|colonial baseboards", "")
					.replace("one- and 2 Story homes", "one story- and 2 Story homes"));
			
			//-------Property Type------
			comHtml = comHtml.replace("ygrounds, common area, gates", "").replace("Luxury, enduring ", "Luxury Homes, enduring ").replace("luxurious gated community", "luxury homes gated community");
			String propertyType = U.getPropType((descSec+comHtml+allPlansData)
					.replace("Bridgeport - Mediterranean", "")
					.replace("<div class=\"image-title\">Mediterranean", "mediterranean-style").replace("<div class=\"image-title\">Craftsman", "Craftsman style details").replaceAll("split courtyard garages", "").replace("is a traditional", "Traditional exterior"));
			
//			U.log("MMMMMMMMM "+Util.matchAll(descSec+comHtml+allPlansData, "[\\w\\s\\W]{10}HOA Fee[\\w\\s\\W]{10}", 0));
			
			
			//------Property Status-----
			comHtml = comHtml.replace("See homes available now", "");			
			comHtml=comHtml.replaceAll("coming soon to Valrico|COMING SOON,\n\\s*Valrico|homesites available for sale on a first-come|<p class=\"disclaimer\">(.*?)</p>|community coming soon to Lithia|New Communities Coming Soon!", "");
			comHtml=comHtml.replaceAll("</p> <p>\n" + 
					"COMING SOON,", "");
			String propertyStatus = U.getPropStatus((comHtml).replaceAll("Pricing Coming Soon|Bexley coming|coming soon to Lithia|COMING SOON,\n\\s*Parrish|Ranch - Coming Soon|Florida \\(coming|promotions, grand openings|model grand opening|Built and current Quick Move-In homes|</h4>\\s*<p>\\s*COMING SOON|FL. Coming soon.|Quick Move-In</a>|<h2>Quick Move-Ins</h2>|>\\s*Quick Move-In\\s*<|Community App coming in 2015|<p>See homes available now</p>|Quick Move-In homes may differ from the|New Communities Coming Soon|Park 65's are these Quick|Only \\d Quick Move|Florida \\(coming soon\\)|New Communities Coming Soon", "").replace("(Opening 2017)", ""));

			
			U.log("property status : "+communityUrl);
		if(communityUrl.contains("https://www.homesbywestbay.com//brandon/the-sanctuary-community")) {
			propertyStatus = propertyStatus.replace("Coming Soon", ALLOW_BLANK);
		}
//			if(comHtml.contains("div class=\"availability-banner new-section\">New Phase</div>"))
//			{
//				if(propertyStatus.length()<3)
//					propertyStatus = "New Phase";
//				else
//					propertyStatus += ", New Phase";
//			}
//			
//			
			
			U.log("quickCount : "+quickCount);
			if(comHtml.contains("Quick Move-Ins</button>"))
			{
				//propertyStatus=propertyStatus.replaceAll("Quick Move-in,|, Quick Move-in", "");
//				if(propertyStatus.length()<4) propertyStatus="Quick Move-Ins";
//				else propertyStatus="Quick Move-Ins, "+propertyStatus;
//				U.log(Util.match(propertyStatus, "[\\w\\s\\W]{5}Quick[\\w\\s\\W]{10}"));

			}
		//	if(communityUrl.contains("https://www.homesbywestbay.com/lithia/hawkstone-innovation-50s-community"))propertyStatus="New Phase";
			if(communityUrl.contains("https://www.homesbywestbay.com/parrish/brightwood-at-north-river-ranch-community"))add[0]="97th St E";
			if(communityUrl.contains("https://www.homesbywestbay.com/odessa/starkey-ranch-inspiration-community")) {
				propertyType = "Loft";
				
			}
//			if(communityUrl.contains("starkey-ranch-avenue-community")) {
//				//adding descriptive status
//				propertyStatus = "New Phase Coming Soon";//changed coming soon to new phae coming soon
//			}
//			if(quickCount==0)propertyStatus=propertyStatus.replaceAll(", Quick Move-in|Quick Move In,", "");
			// ----Logger------------
			if (data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl(communityUrl + "*******repeated*********");
				return;
			}
			LOGGER.AddCommunityUrl(communityUrl);
			// ---------------
			if (add[0] == ALLOW_BLANK) {
				String lati[] = { lat, lng };
				add = U.getAddressGoogleApi(lati);
				if(add == null) add = U.getAddressHereApi(lati);
				geoCode = "TRUE";
			}
			if(propertyStatus!=null)
			propertyStatus=propertyStatus.replace("", "")
			.replace("New Phase Release Coming Soon, Coming Soon", "New Phase Release Coming Soon")
			.replace(" One Homesite Left, Only One Homesite Left", " Only One Homesite Left").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			
//			if(communityUrl.contains("land-o-lakes/bexley-avenue-community") || communityUrl.contains("/land-o-lakes/bexley-innovation-community"))
//				if(propertyStatus==ALLOW_BLANK)
//					propertyStatus="New Phase";
//				else
//					propertyStatus=propertyStatus+", New Phase";
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
			
			if(note==ALLOW_BLANK)note =U.getnote(comHtml);
			add[0] = add[0].toLowerCase().replace("just a few opportunities remain!", "");
			data.addCommunity(communityName, communityUrl, communityType);
			data.addAddress(U.getNoHtml(add[0]).trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(lat, lng, geoCode);
			data.addPropertyType(propertyType, derivedPropertyType);
			data.addPropertyStatus(propertyStatus.replace("Coming Soon, New Phase", "New Phase"));
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);	
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFeet, maxSqFeet);
			data.addNotes(note);

		}
		j++;
//		}catch(Exception e) {}
	}
}
}
	
	
	
	
	
	