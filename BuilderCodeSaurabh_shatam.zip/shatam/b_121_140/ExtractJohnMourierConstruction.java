/*
 * @author piyush..
 */
package com.shatam.b_121_140;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
public class ExtractJohnMourierConstruction extends AbstractScrapper {
	private static String BASE_URL = "https://www.jmchomes.com/";
	private static String BUILDER_NAME = "John Mourier Construction";
	CommunityLogger LOGGER;
	static int j=0;

	public ExtractJohnMourierConstruction() throws Exception {
		super(BUILDER_NAME, BASE_URL);
		LOGGER = new CommunityLogger("John Mourier Construction");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractJohnMourierConstruction();
		//U.logDebug(true);
		a.process();


		FileUtil.writeAllText(U.getCachePath()+"John Mourier Construction.csv", a
				.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {

		String baseHtml = U.getHTML(BASE_URL);
		ArrayList<String> REG_LIST = new ArrayList<String>();
		String urlSec = U.getSectionValue(baseHtml, "footer-nav-cities",
				"</ul>");
		// U.log(urlSec);
		String regUrl[] = U.getValues(urlSec, "<a href=\"/", "\">");

		for (String rurl : regUrl) {
			REG_LIST.add(rurl);
		}

		for (String urlAry : REG_LIST) {
			String regionUrl = BASE_URL + urlAry;
			U.log(regionUrl);
//			try {
				extractHtml(regionUrl);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}

	private void extractHtml(String regionUrl) throws Exception {
		ArrayList<String> COM_LIST = new ArrayList<String>();
		U.log("Inside::" + U.getCache(regionUrl));
		String regHtml = U.getHTML(regionUrl);
		String[] latLonArray=U.getValues(regHtml, "{\"type\":\"point\"", "cssClass");
		//U.log(latLonArray.length);
		
		String[] dataSec = U.getValues(regHtml, "<div class=\"row clearfix\">",
				"</div></div>");
		// LOGGER.countOfCommunity(dataSec.length);
		for (String cData : dataSec) {
			//U.log(cData);
			COM_LIST.add(cData);
		}
		// COM_LIST.add("<a href=\"https://www.jmchomes.com/communities/legends-morgan-creek\"");
		for (String dataSc : COM_LIST) {
			// U.log(dataSc);

			addDetails(dataSc,latLonArray);

		}
	}

	//TODO :
	private void addDetails(String dataSc,String[] latLonArray) throws Exception {
//	if(j==10)
		//try{
		{
//		U.log(dataSc);
		String communityUrl = U.getSectionValue(dataSc, "<a href=\"/", "\">");
		
//		U.log(communityUrl);

		String comHtml = ALLOW_BLANK;
		if (communityUrl == null) {
			communityUrl = "communities/retreat-fiddyment-farm";
		}

		String latDataSec="";
		
		
		for (String latLonSec : latLonArray) {
			latLonSec=latLonSec.replaceAll("\\\\u0022\\\\", "'");
			latLonSec=latLonSec.replaceAll("\\\\", "");
			String temp=U.getSectionValue(latLonSec, "'", "'");
			
			//U.log("-----"+temp);
			if (temp.contains(communityUrl)) {
				latDataSec=latLonSec;
			}
			//U.log(latLonSec);
		}
//		U.log(dataSc);

			// ******************Community Url***************************

			communityUrl = BASE_URL + communityUrl;
			
			//TODO:
//			if (!communityUrl.contains("https://www.jmchomes.com/communities/edgefield-place-whitney-ranch")) return;
			
			if (data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl(communityUrl
						+ "\t*********Repeated******\t");
				return;
			}
			LOGGER.AddCommunityUrl(communityUrl);
			
			
			comHtml = U.getHTML(communityUrl);
			
			String lotJsonPart=U.getSectionValue(comHtml,"jQuery.extend(Drupal.settings,","</script>");

			
			U.log("Community Url::" + communityUrl);
			String nameSec = U.getSectionValue(dataSc, "<h3><span", "/span>");
			
			// ******************Community Name***************************

			String communityName = U.getSectionValue(nameSec, "\">", "<");
			U.log("Community Name::" + communityName);

			// ******************Community Prices****************************

			String replcSec = U.getSectionValue(comHtml, "Any Price<",
					"Up</option>");
			String pHtml = comHtml.replace(replcSec, "");
			replcSec = U.getSectionValue(pHtml, "</footer>", "</body>");
			pHtml = pHtml.replace(replcSec, "");

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U.getPrices(dataSc + pHtml,
					"From \\$\\d{3},\\d{3}|>From \\$\\d,\\d+,\\d+</span>|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log(minPrice);
			U.log(maxPrice);
//			U.log(dataSc);
			// ******************Community Area [SqrFeet]******************
			String geo = "False";
			String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
			
//			U.log(dataSc);
			String[] sqft = U
					.getSqareFeet(
							dataSc + comHtml,
							"ranging from \\d,\\d{3}-\\d,\\d{3} sq. ft|ranging from \\d,\\d{3} to \\d,\\d{3} sq.  ft|from \\d,\\d{3} to \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} sq. ft|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+ Sq. Ft|\\d{1},\\d{3} square feet",
							0);
			minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log(minSqFeet);
			U.log(maxSqFeet);

			// ******************Community Address************************

			String addSec = U.getSectionValue(comHtml, "adr\">", "<div");
			String[] address = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
					ALLOW_BLANK };
			if (addSec != null) {
				addSec = addSec.replace("<br />", ",").replace("&#039;s ", "'s ").trim();
				address = U.getAddress(addSec);

			}
			U.log(address[0]);
			U.log(address[1]);
			U.log(address[2]);
			U.log(address[3]);
			String lat = ALLOW_BLANK;
			String lng = ALLOW_BLANK;
			if (latDataSec!=null) {
				U.log(latDataSec);
				lat=U.getSectionValue(latDataSec, "lat\":", ",");
				lng=U.getSectionValue(latDataSec, "lon\":", ",");
			}
			
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			if (address[0] != ALLOW_BLANK&&lat==ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(address);
				if(latLng == null) latLng = U.getlatlongHereApi(address);
				lat = latLng[0];
				lng = latLng[1];
				geo = "TRUE";
			}
			
			// ******************Adding Data*****************
			comHtml = comHtml.replaceAll("[h|H]omes [a|A]re [s|S]elling [q|Q]uickly", "").replaceAll("from-price\">\\s*Coming Soon", "");
			
			//U.log("::::::::"+Util.match(comHtml,".*?Grand Opening.*?"));
			//-----------Property Status-----------
//			U.log("============"+dataSc);
			String propertyStatus = U.getPropStatus((dataSc+comHtml).replaceAll("\">Move-In Ready</span>", ""));
//			U.log("propertyStatus::"+propertyStatus);
			propertyStatus=propertyStatus.replace("Move-in Ready, ", "");
			if(propertyStatus.length() < 4) propertyStatus = ALLOW_BLANK;
			
			

			
			
//			propertyStatus=U.getPropStatus(propertyStatus);
			U.log("propertyStatus::"+propertyStatus.length());
			//----------Property Type----------
			dataSc = dataSc.replaceAll("amenities available in our luxury communities|luxurious selection of new homes", "luxury homes");
			String allHomeData=getHomeData(comHtml);
			
//			U.log(allHomeData);
			comHtml=U.removeSectionValue(comHtml, "<script>jQuery", "</html>");
			String combine=dataSc+comHtml.replace("Detached-Car", "")+allHomeData;
			combine=combine.replaceAll("private courtyard forms|: Cottage|Cottage Elevation|Craftsman Elevation|French Villa Elevation|B: Craftsman|: Craftsman</p>|village|>City Loft|Village|Esta Villa Cottage Brown|-desc\">Dal Esta Villa|desc\">Esta Villa Cottage|2x8 Brickwork Patio", "");
			
			String propertyType = U.getPropType(combine);
			
			
			
			//----------Community Type---------------
			String communityType = U.getCommunityType(dataSc + comHtml);
			
			
			//fetch homes data
			
			
			String derivedPropertyType = U.getdCommType((comHtml+dataSc+allHomeData).replaceAll(": Ranch","").replace("Whitney+Ranch+by", "").replace("active\">2ND FLOOR", "2-story homes").replace("1ST FLOOR", "1 story homes").replace("active\">1ST FLOOR", " Story 1 "));
			//
				
			if (communityUrl.contains("wild-oak-whitney-ranch")) {
				propertyType="Executive Style Homes";
			}
			String notes=U.getnote(comHtml);
			
			//U.log(dataSc+"data Sec");

			//From Img
//			if(communityUrl.contains("https://www.jmchomes.com/communities/prominence-whitney-ranch")){
//				propertyStatus = getStatus(propertyStatus, "Grand Opening");
//			}
			
			
//			if(communityUrl.contains("https://www.jmchomes.com/communities/palisade-village-sierra-vista") ||
//					communityUrl.contains("https://www.jmchomes.com/communities/westview-whitney-ranch")){
//				propertyStatus = getStatus(propertyStatus,"Grand Opening");
//			}
			
			
		//============= UnitCount ========
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			U.log("lotJsonPart ::"+lotJsonPart);
			
			lotJsonPart=StringEscapeUtils.unescapeJava(lotJsonPart);
			U.log("lotJsonPart ::"+lotJsonPart);
			int lotCount=0;
			String[] lotSection=U.getValues(lotJsonPart, "{\"type\":\"point", "icon\":false},");
			for(String lotSec:lotSection) {
				lotCount++;
			}
			counting=Integer.toString(lotCount);
			U.log("counting ::"+counting);
		//================================
			
//			if(communityName.endsWith("Lakeside"))
//				communityType = "Lakeside Community";
//		
//			if(communityUrl.contains("communities/meadowbrook-fiddyment-farm")
//					||communityUrl.contains("communities/fairbrook-fiddyment-farm")
//					||communityUrl.contains("communities/sagebrook-fiddyment-farm")) {
//				if(propertyStatus==ALLOW_BLANK)
//					propertyStatus = "Grand Opening";
//				else
//					propertyStatus=propertyStatus+", Grand Opening";    //From IMG
//			}
			
			if(propertyStatus.length()<4)
				propertyStatus=ALLOW_BLANK;
			//if(communityUrl.contains("https://www.jmchomes.com/communities/sycamore-creek"))propertyStatus+=", New Release";//Img 24Oct2021
//			
//			if(communityUrl.contains("https://www.jmchomes.com/communities/meadowbrook-fiddyment-farm") ||
//					communityUrl.contains("https://www.jmchomes.com/communities/fairbrook-fiddyment-farm") 
//					|| communityUrl.contains("https://www.jmchomes.com/communities/sagebrook-fiddyment-farm"))
//				notes = "Presale";
			
		//status from image - 20 may 2022 dattaraj
			if (communityUrl.contains("https://www.jmchomes.com/communities/edgefield-place-whitney-ranch")) propertyStatus = "Now Selling";
			
			data.addCommunity(communityName, communityUrl, communityType);
			data.addAddress(address[0].replace(".", ""), address[1], address[2], address[3]);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(propertyType, derivedPropertyType);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFeet, maxSqFeet);
			data.addNotes(notes);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);

		}

		j++;
		
		//}catch (Exception e) {}
	}

	
	public String getHomeData(String cHtml) throws IOException{
		U.log("Homes Success");
		String homesData=ALLOW_BLANK;
		
		String[] homeUrls=U.getValues(cHtml, "views-field views-field-nothing","<div class=\"special_feature\">");
		
		for(String homeUrlSe: homeUrls){
			String	homeUrl=U.getSectionValue(homeUrlSe, "field-content\"><a href=\"", "\"");
			
			if (homeUrl==null) {
				homeUrl=U.getSectionValue(homeUrlSe, "<a href=\"", "\"");
			}
			U.log("homeUrl::"+homeUrl);
			String htmlTemp=U.getHTML("https://www.jmchomes.com"+homeUrl);
		
		
		
			String tempData=U.getSectionValue(htmlTemp, "<div class=\"views-field views-field-field-homesite-youtube-video\"> ", "<p><span class=\"feature\">");
			
			if (tempData==null) {
				tempData=U.getSectionValue(htmlTemp, "views-field views-field-field-homesite-youtube-video\">", "<div class=\"floorplan-print-icon\">")
					+U.getSectionValue(htmlTemp, "<div  id=\"quicktabs-floors", "</li>")
					+U.getSectionValue(htmlTemp, "<div class=\"views-field views-field-field-homesite-youtube-video\"> ", "</aside>");
			}
			
			homesData += tempData;
			
			String[] floor = U.getValues(htmlTemp, "<div  id=\"quicktabs-floors", "<div id=\"quicktabs-container-floors");
		
			for(String f : floor) {
				homesData += f;
			}
			
			floor = U.getValues(htmlTemp, "field-homesite-photos-headline\">", "</li>");
			
			for(String f : floor) {
				homesData += f;
			}
			
		}//eof outer for
		
		return homesData;
	}
	
	private String getStatus(String pStatus, String ImgStatus){
		if(pStatus == ALLOW_BLANK) pStatus = ImgStatus;
		else if(pStatus != ALLOW_BLANK) pStatus += ", "+ImgStatus;
		return pStatus;
	}
}
