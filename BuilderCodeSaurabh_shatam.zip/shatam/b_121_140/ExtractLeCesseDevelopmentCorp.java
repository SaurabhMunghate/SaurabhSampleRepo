/**
 * @author Ranjna Sharma 
 * @date 01/2017
 * 
 */
package com.shatam.b_121_140;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;

import org.apache.commons.lang.StringEscapeUtils;
import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLeCesseDevelopmentCorp extends AbstractScrapper{
    static WebDriver driver=null;
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	
	private static String builderUrl = "https://www.lecesse.com"; 
	
	public ExtractLeCesseDevelopmentCorp()	throws Exception {
		super("LeCesse Development Corp","https://www.lecesse.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("LeCesse Development Corp");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractLeCesseDevelopmentCorp();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"LeCesse Development Corp.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
		
	}

	@Override
	protected void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();

		
//		//========== ApartmentSection ===============
		String apartmentRegionUrls[] = {
				"https://www.lecesse.com/apartments/mn/",
				"https://www.lecesse.com/apartments/pa/",
				"https://www.lecesse.com/apartments/ny/",
				"https://www.lecesse.com/apartments/nj/",
				"https://www.lecesse.com/apartments/ma/",
				"https://www.lecesse.com/apartments/nh/",
				"https://www.lecesse.com/apartments/fl/",

		};
		
		String nwRegUrl="https://www.lecesse.com/legacy-2";
		String nwRegHtml=U.getHTML(nwRegUrl);
		String [] legacyCom=U.getValues(nwRegHtml, "<p><a href=\"", "</a></p>");
		for(String nwComUrl:legacyCom) {
		
			if(nwComUrl.contains("https://www.grandevilleapts.com/")) {
				addMyDetails("https://www.grandevilleapts.com/",nwComUrl);
		}
			}
		
		
		for(String apartmentRegionUrl : apartmentRegionUrls){

			String html = U.getHTML(apartmentRegionUrl);
			String locationSection = U.getSectionValue(html, "\"addresses\":", "</script>");
			String apartmentUrlSections[] = U.getValues(html, "<p class=\"h-adr p-adr adr\">", "</p>");
			U.log(apartmentUrlSections.length);
			for(String apartmentUrlSec : apartmentUrlSections){
				String apartmentUrl = U.getSectionValue(apartmentUrlSec, "<a href=\"", "\"");
				U.log("apartmentUrl======"+apartmentUrl);

				extractApartments(apartmentUrl, apartmentUrlSec, locationSection);//dt
			}
		}
		
		//=========== Communities Section ====================
		String html = U.getHTML("https://www.lecesse.com/communities");
		String urlSections[] = U.getValues(html, "<div class=\"photo-card\">", "target=\"_blank\">");
		U.log(urlSections.length);
		for(String urlSection : urlSections){
//			U.log("COMMSEC:::::::::::::-->");
			String comUrl = U.getSectionValue(urlSection, "<a href=\"", "\"");
			if(!comUrl.startsWith("http"))continue;
			U.log("comUrl===="+comUrl);
		//	if(!comUrl.contains("https://www.morgancommunities.com/apartments/ny/malta/grandeville-at-malta/"))continue;
//				if(!comUrl.contains("https://www.grandevilleapts.com/"))continue;

			addDetails1(comUrl, urlSection);////dt
			U.log("comUrl======"+comUrl);
		}
		
		try{driver.quit();}catch(Exception e) {};
		LOGGER.DisposeLogger();
	}

	private void addMyDetails(String url, String nwComSec) throws Exception {
		
		
		
		U.log("commmUrl"+url);
		String html=U.getHTML(url);
		String comName=U.getSectionValue(html, "<title>", "</title>");
		comName=comName.replace(" | Apartments in Orange City, FL", "");
		String addSec=U.getSectionValue(html, "<div itemprop=\"address\">", "<span class=\"sr-only\">Opens in a new tab</span>");
	    String geo="True";
		
		
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng= {ALLOW_BLANK,ALLOW_BLANK};
	    add[0]=U.getSectionValue(addSec, "<div data-selenium-id=\"address_street\">", "</div>").trim();
	    add[1]=U.getSectionValue(addSec, "<span data-selenium-id=\"address_city\">", "</span>").trim();
	    add[2]=U.getSectionValue(addSec, "<span data-selenium-id=\"address_state\">", "</span>").trim();
	    add[3]=U.getSectionValue(addSec, "<span data-selenium-id=\"address_zip\"> ", "</span>").trim();
	    U.log("Address===> "+Arrays.toString(add));
	    
	    String latlngSec=U.getSectionValue(html, " \"geo\": {", "},");
	    latlng[0]=U.getSectionValue(latlngSec, "\"latitude\": \"", "\",");
	    latlng[1]=U.getSectionValue(latlngSec, " \"longitude\": \"", "\"");
	    U.log("LatLong===>"+Arrays.toString(latlng));

	    String floorplanUrl=url+"floorplans";
	    String amenUrl=url+"amenities" ; 
	    String floorHtml=U.getHtml(floorplanUrl,driver);
	    String amenHtml=U.getHtml(amenUrl, driver);
	    
	    String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	    String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
	    
	    String[] sqft = U.getSqareFeet(html+floorHtml,
				"\\d,\\d{3} Sq.Ft.|\\d{3} Sq.Ft.",
				0);

		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		String pType=ALLOW_BLANK,dType=ALLOW_BLANK,cType=ALLOW_BLANK;
		pType=U.getPropType(html+floorHtml+amenHtml);
		
		U.log("pType="+pType);
		dType=U.getdCommType(html+floorHtml+amenHtml);
		U.log("dType= "+dType);
		cType=U.getCommType(html+amenHtml);
		U.log("cType= "+cType);
		String propStatus=U.getPropStatus(html);
		U.log("propStatus= "+propStatus);
        String note=ALLOW_BLANK; https://www.lecesse.com/apartments/pa/king-of-prussia/skye-750/
		note=U.getnote(html);
	    
		data.addCommunity(comName, url, cType);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note); 
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
	}

	int i  = 0;
	private void extractApartments(String apartmentUrl, String section, String locationSection) throws Exception{
		//if(i == 10)
//try{
		{
			
			U.log(i+"\tapartmentUrl :"+apartmentUrl);
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/ma/maryland/17/"))return; //URL not opening
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/fl/boynton-beach/500-ocean/"))return; //URL not opening
			if(apartmentUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return; //URL not opening
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/ny/rochester/north-village/"))return; //URL not opening
//			if(apartmentUrl.contains("https://www.vintyapartments.com/vinty"))return; 

//DT 20 MAY			apartmentUrl = U.getRedirectedURL(builderUrl, apartmentUrl);
//			U.log("Redirect URL :https://www.villagrandeonsaxon.com/apartments/fl/orange-city/floor-plans"+apartmentUrl);
//			
			
		
			
			
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/mn/burnsville/23/")||apartmentUrl.contains("https://www.lecesse.com/apartments/nj/elizabeth/21/")||apartmentUrl.contains("https://www.lecesse.com/in-development")||apartmentUrl.contains("https://www.lecesse.com/apartments/mn/minnetonka/18/")){
				LOGGER.AddCommunityUrl("apartmentUrl ::"+apartmentUrl+"-----------> URL redirected");
				return;
			}
			if(apartmentUrl.contains("https://www.vintyapartments.com/vinty")||apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/19/")){
				LOGGER.AddCommunityUrl("apartmentUrl ::"+apartmentUrl+"-----------> Repeated");
				k++;
				return;
			}
			
			//TODO :: For single community execution
			
		//	if(!apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/maitland-park/"))return;
//			U.log("APARTMENT========");
			String html = U.getHTML(apartmentUrl);
			
			if(html == null 
					||apartmentUrl.contains("https://www.lecesse.com/apartments/pa/king-of-prussia/skye-750/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/ny/clifton-park/landings/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/ny/rochester/north-village/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/ny/west-henrietta/bennington-hills/")
					|| apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/20/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/maitland-park/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/maitland-park/")
					|| apartmentUrl.contains("https://www.lecesse.com/apartments/nh/merrimack/22/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/fl/key-largo/key-lake/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orange-city/grande-saxon/")
//					|| apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/19/")
					|| apartmentUrl.contains("https://www.500oceanapartments.com/")
					
					){
				LOGGER.AddCommunityUrl("apartmentUrl ::"+apartmentUrl+"-----------> URL Not Open");
				return;
			}
			if(data.communityUrlExists(apartmentUrl)){
				LOGGER.AddCommunityUrl("apartmentUrl ::"+apartmentUrl+"------------>Repeated");
				return;
			}
			LOGGER.AddCommunityUrl("apartmentUrl ::"+apartmentUrl);
			
			

//			U.getRedirectedURL(mainDomain, url)
			
			//=========== Community Name =============
			String comName = U.getSectionValue(section, "p-name notranslate\">", "</strong>");
			comName = comName.replace("North Village Rochester", "North Village");
			U.log("ComName :"+comName);
			locationSection = StringEscapeUtils.unescapeJava(locationSection);
//			U.log(locationSection);
			
			String[] locationVals = U.getValues(locationSection, "[", "]");
			String addressLatLngSection = null;
			for(String locationVal : locationVals){
				if(locationVal.contains(comName)){
					addressLatLngSection = locationVal;
					break;
				}
			}
			U.log(addressLatLngSection);
			
			//============== Address ================
			String add[] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
			String geo = "False";
			String addSec = U.getSectionValue(addressLatLngSection, "\"", "\",\"<p>");
			add = U.getAddress(addSec);
			U.log("Add :"+Arrays.toString(add));
			
			//============ LatLng =====================
			String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
			latLng[0] = U.getSectionValue(addressLatLngSection, "\"latitude\":", ",");
			latLng[1] = U.getSectionValue(addressLatLngSection, "\"longitude\":", "}");
			U.log("latLng ::"+Arrays.toString(latLng));
			
			String floorHtml = null;
			if(apartmentUrl.contains("http://www.benningtonhillsapartments.com")){
				floorHtml = U.getHTML("http://www.benningtonhillsapartments.com/floorplans.html");
			}
			if(apartmentUrl.contains("keyslakevillas")){
				floorHtml = U.getHtml("https://www.keyslakevillas.com/apartments/fl/key-largo/floor-plans#/",driver);
			}
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/lee-vista/")){
				floorHtml = U.getHtml("https://www.grandreserveatleevista.com/apartments/fl/orlando/floor-plans#/categories/all/floorplans", driver);
			}
			if(apartmentUrl.contains("https://www.grandreserveatmaitland.com/")){
				floorHtml = U.getHtml("https://www.grandreserveatmaitland.com/apartments/fl/orlando/floor-plans", driver);
			}
			if(apartmentUrl.contains("https://www.grandevilleatmalta.com/")){
				floorHtml = U.getHtml("https://www.grandevilleatmalta.com/apartments/ny/malta/floor-plans#/categories/all/floorplans", driver);
			}
			if(apartmentUrl.contains("https://www.thelandingsapartments.com/")){
				floorHtml = U.getHtml("https://www.thelandingsapartments.com/apartments/ny/clifton-park/floor-plans#/categories/all/floorplans", driver);
			}
			if(apartmentUrl.contains("https://www.rizeongrand.com/rize-on-grand-burnsville-mn")){
				floorHtml = U.getHTML("https://www.rizeongrand.com/rize-on-grand-burnsville-mn/floorplans");
			}
			if(apartmentUrl.contains("benningtonhillsapartments")){
				floorHtml = U.getHtml("https://www.benningtonhillsapartments.com/apartments/ny/west-henrietta/floor-plans#/categories/all/floorplans",driver);
			}
			if(apartmentUrl.contains("bellanovaatjubileepark")){
				floorHtml = U.getHTML("https://www.bellanovaatjubileepark.com/bellanova-at-jubilee-park-orlando-fl/floorplans");
			}
			if(apartmentUrl.contains("https://cortland.com/apartments/")){
				floorHtml = U.getHTML("https://cortland.com/apartments/cortland-on-orange/floorplans/");
			}
			if(apartmentUrl.contains("grandreserveatleevista")){
				floorHtml = U.getHtml("https://www.grandreserveatleevista.com/apartments/fl/orlando/floor-plans#/categories/all/floorplans",driver);
			}
			if(apartmentUrl.contains("skye750apartments")){
				floorHtml = U.getHtml("https://www.skye750apartments.com/floorplans",driver);
			}
			if(apartmentUrl.contains("https://www.grandreserveatmaitland.com/")){
				floorHtml = U.getHtml("https://www.grandreserveatmaitland.com/apartments/fl/orlando/floor-plans#/categories/all/floorplans",driver);
			}
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/ny/west-henrietta/bennington-hills/"))
			{
				floorHtml = U.getHtml("https://www.benningtonhillsapartments.com/apartments/ny/west-henrietta/floor-plans#/categories/all/floorplans",driver);
			}
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/fl/key-largo/key-lake/")) {
				floorHtml=U.getHtml("https://www.keyslakevillas.com/apartments/fl/key-largo/floor-plans#/", driver);
			}
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/ny/clifton-park/landings/")) {
				floorHtml=U.getHtml("https://www.thelandingsapartments.com/apartments/ny/clifton-park/floor-plans#/categories/all/floorplans", driver);
			}
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orange-city/grande-saxon/")) {
				floorHtml=U.getHtml("https://www.villagrandeonsaxon.com/apartments/fl/orange-city/floor-plans#/categories/all/floorplans", driver);
			}
			if(apartmentUrl.contains("https://www.lecesse.com/apartments/fl/orlando/maitland-park/")) {
				floorHtml=U.getHtml("https://www.grandreserveatmaitland.com/apartments/fl/orlando/floor-plans#/categories/all/floorplans", driver);
			}
			//====================Price and SQ.FT====================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	
		    String prices[] = U.getPrices(html,
		    		"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Price--->"+minPrice+" "+maxPrice);
			
			//===============Sq.ft============
			
			
			
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			if(floorHtml!=null)floorHtml=floorHtml
					.replaceAll("600 - 1,600 sq ft</button>", "");
			
//			U.log(Util.matchAll(floorHtml, "[\\w\\s\\W]{50}Sqft[\\w\\s\\W]{30}", 0));

			
			html = html.replaceAll(" \\(\\d+ with sun room\\)", "");
			html=html.replace("Square Feet644-1,372 SQ FT", "Square Feet 644-1,372 SQ FT");
			String[] sqft = U.getSqareFeet(html+floorHtml,
					"Square Feet \\d{3}-\\d,\\d{3} SQ FT|'square-foot'>\\d,\\d{3}</span>|'square-foot'>\\d{3}</span>|square-foot\">\\d{3}</span>|square-foot\">\\d{1},\\d{3}</span>|unit-size\">\\d,\\d{3} Sq. Ft.</div>|\"unit-size\">\\d{3,4} Sq. Ft.|class=\"sqft\">\\d,\\d{3} Sq. Ft.|class=\"sqft\">\\d{3,4} Sq. Ft.|\\d{4} Sq. Ft.|\\d{3} Sq. Ft.|\\d,\\d{3} Sq.Ft|\\d{3} Sq.Ft|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet|\"square_feet\":\\d{3,4}",
					0);

			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
			
			//========== Property Type ===============
			html = html.replace("features and custom finishes", "features and custom homes ");
			String pType = U.getPropType(html.replaceAll("Keys Lake Villas| content=\"(.*)\"", ""));
			if (pType.contains("Townhouse")&&pType.contains("Townhome")) {
				pType=pType.replaceAll("^Townhouse, ", "");
			}
			//=========== Derived Property Type ===============
			String dType = U.getdCommType(html.replace("2-Story+Fitness", "").replaceAll("2-Story Fitness Center|2-story fitness center", ""));
			
//			U.log(Util.matchAll(html, "[\\w\\s\\W]{300}Now open[\\w\\s\\W]{30}", 0));
			//============ Community Type ==========
			html=html.replaceAll("alt=\"Resort-style pool|Birnamwood Golf Course|alt=\"Resort Style Pool|alt=\"Resort style pool|title=\"Resort Style Poo|alt=\"Resort-Style Pool|title=\"Resort-Style Pool", "");
			String comType = U.getCommunityType(html);
			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{300}Golf Course[\\w\\s\\W]{30}", 0));

			
			//=============== Property Status ===============
			html = html.replaceAll("Portal Coming|information coming| Coming soon to Maynard Crossing ", "");
			html = html.replaceAll("getting ready to move in|Fitness coming soon|Preview Center NOW OPEN|Now Open by Appointment|\\s*<p>\\s*NOW OPEN!\\s*|Now Open!</li>|apply\\.\\s*Limited time|pply\\.  Limited Time Offer| Coming soon to Maynard Crossing |- Coming Soon</li>|Restriction may apply. Limited time offer.</p>|Portal Coming Soon", "");
			String propStatus = U.getPropStatus(html); 
			
			String note = U.getnote(html);
			
			
			
			
			if(apartmentUrl.contains("http://www.thelandingsapartments.com")) {
				
				//note = "Leasing Fast";//img
			}
			if(apartmentUrl.contains("http://www.northvillagerochester.com")) {
				dType = "1 Story, 2 Story";
				minSqft = "891";maxSqft = "1000";
			}
			
			if(apartmentUrl.contains("https://www.villagrandeonsaxon.com/")) {
				
				pType = pType + ", Patio";
//				comType = "Gated Community";
			}
			if(apartmentUrl.contains("livevinty")) {
				geo="True";
			}
			if( apartmentUrl.contains("https://www.grandreserveatmaitland.com/"))pType = pType + ", Patio";
			if(apartmentUrl.contains("http://www.keyslakevillas.com"))pType = "Coastal Style Homes, Garden Home";
		
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
		U.log("Note"+note);
			
			data.addCommunity(U.getCapitalise(comName.replaceAll(" Apartments$| Villas$", "").toLowerCase()), apartmentUrl, comType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note); 
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		i++;
//		}catch (Exception e) {}
	}
	
	protected void innerProcess1() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();		
		String  mainHtml=U.getPageSource("https://www.lecesse.com/communities");
		String[] comSec=U.getValues(mainHtml, "<div class=\"photo-card\">"," <div class=\"photo-card-caption\">");
		for(String com:comSec)
		{		
		//	U.log(com);
			String comUrl=U.getSectionValue(com,"href=\"","\"");
			U.log("comUrl : "+comUrl);
			if(comUrl==null)continue;
/*			if(comUrl.contains("https://www.citywalkatwoodbury.com/") ||comUrl.contains("https://ancoraapartments.com/") ||comUrl.contains("https://www.500oceanapartments.com/"))
				addDetails1(comUrl,com);
			if(comUrl.contains("https://www.grandreserveatmaitland.com/") ||comUrl.contains("https://www.grandreserveatleevista.com/"))			
				addDetails2(comUrl,com);
			if(comUrl.contains("https://www.grandevilleatjubileepark.com/"))
				addDetails3(comUrl, com);
			if(comUrl.contains("http://www.keyslakevillas.com"))
				addDetails4(comUrl, com);
			if(comUrl.contains("http://www.villagrandeonsaxon.com/"))
				addDetails5(comUrl, com);
			if(comUrl.contains("https://www.maynardluxuryapartments.com") ||comUrl.contains("https://www.rizeatopuspark.com")|| comUrl.contains("http://www.skye750apartments.com")||comUrl.contains("https://www.eccoonorange.com")||comUrl.contains("https://www.bellanovaatjubileepark.com/") || comUrl.contains("https://cortland.com/apartments/cortland-jubilee-park/"))
				addDetailsNewCommunities(comUrl, com);
*/			
//			if(comUrl.contains("https://www.morgancommunities.com/apartments/ny/malta/grandeville-at-malta/"))getMorganCommunities();

		}
		driver.quit();//dt
		//driver.close();
		U.log(comSec.length);
		LOGGER.DisposeLogger();
	}
	private void addDetails1(String comUrl, String commData) throws Exception {
		
//		try {
		U.log("************************************************************");
		U.log("commUrl-->"+comUrl);
        if(comUrl.contains("https://www.grandevilleatjubileepark.com/"))return; //URL Not Opening
        if(comUrl.contains("https://www.maynardluxuryapartments.com/"))return; //URL Not Opening
        if(comUrl.contains("https://www.vueatmaynardcrossing.com/the-vue-at-maynard-crossing-maynard-ma/"))return; //URL Not Opening
        if(comUrl.contains("https://www.rizeatopuspark.com/rize-at-opus-park-minnetonka-mn"))return; //URL Not Opening
        if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;

        if(comUrl.contains("https://www.morgancommunities.com/apartments/ny/malta/grandeville-at-malta/"))
        	comUrl = "https://www.grandevilleatmalta.com/";
        
        if(comUrl.contains("http://www.villagrandeonsaxon.com/"))comUrl=comUrl.replace("http:","https:");
        if(comUrl.contains("http://www.skye750apartments.com/"))comUrl = "https://www.skye750apartments.com/skye-750-king-of-prussia-pa";
        if(comUrl.contains("https://www.rizeatopuspark.com"))comUrl = "https://www.rizeatopuspark.com/rize-at-opus-park-minnetonka-mn";
        if(comUrl.contains("https://bellanovaatjubileepark.com") || comUrl.contains("https://www.bellanovaatjubileepark.com/"))comUrl = "https://www.bellanovaatjubileepark.com/bellanova-at-jubilee-park-orlando-fl";
        if(comUrl.contains("https://www.eccoonorange.com"))comUrl = "https://www.eccoonorange.com/ecco-on-orange-orlando-fl";
        
		if(comUrl.contains("http://www.keyslakevillas.com/"))comUrl = comUrl.replaceAll("/$", "");
		comUrl = comUrl.replace("http:", "https:");

		if(comUrl.contains("rize-on-grand-burnsville-mn"))comUrl="https://www.rizeongrand.com/rize-on-grand-burnsville-mn";
      
		
		
		if(comUrl.contains("https://www.grandreserveatmaitland.com/")||comUrl.contains("https://www.grandreserveatleevista.com/")) return;//dt 21 not prtesent on region page
		if(comUrl.contains("keyslakevillas.com")||comUrl.contains("villagrandeonsaxon")) {
        	LOGGER.AddCommunityUrl(comUrl+"============> Repeated");
			k++;
			return;
        }
		//TODO : For Single Community Execution
	//	if(!comUrl.contains("rize-on-grand-burnsville-mn"))return;
//		U.log("IIIIIIIIIII");

		
		String html=U.getPageSource(comUrl);
		U.log("commUrl-->"+comUrl);

        if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov"))return;
        
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"============> Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
//		U.log(commData);
			
        //------Community name--------
        String communityName=U.getSectionValue(commData, "<h3>","</h3>");
        if(communityName == null)
        	communityName=U.getSectionValue(commData, "<p class=\"paragraph-title\">","<");
        if(communityName == null)
        	communityName=U.getSectionValue(html, "main-content-section\">","</p>");
        if(communityName == null)
        	communityName=U.getSectionValue(html, "<title>",",");
        if(communityName == null)
        	communityName=U.getSectionValue(commData, "<p class=\"paragraph-title\">","<");
        communityName=communityName.replaceAll("<meta name=\"description\" content=\"Welcome to BellaNova at JubiLee Park|</title>|Villas$|Apartments\\s*$|<p>|Apartments Near Lake Nona \\|","");
        
        if(comUrl.contains("https://www.vintyapartments.com/vinty-elizabeth-nj")) {
        	communityName="Vinty";
        }
        communityName=communityName.replace("RiZE on Grand Apartments | Burnsville", "Rize On Grand");
        
        U.log("community Name---->"+communityName);
        //-----------Urls--------------
        String flrUrl=ALLOW_BLANK;
		String floorHtml=ALLOW_BLANK;
		String amenitiesUrl=ALLOW_BLANK;
		String amenitiesHtml=ALLOW_BLANK;
		String flrhtml1=ALLOW_BLANK;
		String mapUrl=ALLOW_BLANK;
		
    	if(comUrl.contains("https://www.citywalkatwoodbury.com/")) {
			flrUrl="https://www.citywalkatwoodbury.com/apartments/mn/woodbury/floor-plans#/categories/all/floorplans";
			amenitiesUrl="https://www.citywalkatwoodbury.com/apartments/mn/woodbury/amenities";
			mapUrl="https://www.citywalkatwoodbury.com/apartments/mn/woodbury/map-directions";
		}
		if(comUrl.contains("https://www.500oceanapartments.com/")) {
			flrUrl="https://www.500oceanapartments.com/apartments/fl/boynton-beach/floor-plans#/categories/all/floorplans";
			amenitiesUrl="https://www.500oceanapartments.com/apartments/fl/boynton-beach/amenities";
			mapUrl="https://www.500oceanapartments.com/apartments/fl/boynton-beach/map-directions";
		}
		
		if(comUrl.contains("https://www.keyslakevillas.com")) {
			flrUrl="https://www.keyslakevillas.com/apartments/fl/key-largo/floor-plans";
		}
	
		
		if(comUrl.contains("https://ancoraapartments.com/")) {
			flrUrl="https://www.ancoraapartments.com/apartments/fl/orlando/floor-plans#/categories/all/floorplans";
			amenitiesUrl="https://www.ancoraapartments.com/apartments/fl/orlando/amenities";
			mapUrl="https://www.ancoraapartments.com/apartments/fl/orlando/directions";
		}
		if(comUrl.contains("https://www.grandreserveatleevista.com/")){
			mapUrl="https://www.grandreserveatleevista.com/apartments/fl/orlando/map-directions";
			flrUrl="https://www.grandreserveatleevista.com/apartments/fl/orlando/floor-plans";
			amenitiesUrl="https://www.grandreserveatleevista.com/apartments/fl/orlando/amenities";
		}
		if(comUrl.contains("https://www.grandreserveatmaitland.com/")){
			mapUrl="https://www.grandreserveatmaitland.com/apartments/fl/orlando/map-directions";
			flrUrl="https://www.grandreserveatmaitland.com/apartments/fl/orlando/floor-plans";
			amenitiesUrl="https://www.grandreserveatmaitland.com/apartments/fl/orlando/amenities";
		}
		if(comUrl.contains("https://www.villagrandeonsaxon.com/")){
			comUrl="https://www.villagrandeonsaxon.com/";
			mapUrl="https://www.villagrandeonsaxon.com/apartments/fl/orange-city/map-directions";
			flrUrl="https://www.villagrandeonsaxon.com/apartments/fl/orange-city/floor-plans";
			amenitiesUrl="https://www.villagrandeonsaxon.com/apartments/fl/orange-city/amenities";
		}
		if(comUrl.contains("https://www.grandevilleatmalta.com/")){
			communityName="GrandeVille at Malta";
			mapUrl="https://www.grandevilleatmalta.com/apartments/ny/malta/directions";
			flrUrl="https://www.grandevilleatmalta.com/apartments/ny/malta/floor-plans#/categories/all/floorplans";
			amenitiesUrl="https://www.grandevilleatmalta.com/apartments/ny/malta/amenities";
		}
		if(comUrl.contains("https://www.bellanovaatjubileepark.com/")){
			mapUrl="https://www.bellanovaatjubileepark.com/bellanova-at-jubilee-park-orlando-fl/contact";
			flrUrl="https://www.bellanovaatjubileepark.com/bellanova-at-jubilee-park-orlando-fl/floorplans";
			amenitiesUrl="https://www.bellanovaatjubileepark.com/bellanova-at-jubilee-park-orlando-fl/amenities";
		}
		
		if (comUrl.contains("http://www.keyslakevillas.com")) {
			mapUrl = "http://www.keyslakevillas.com/location-area-map-gulf-mexico-key-largo-apartments-apt-best-new-rent.html";
			flrUrl = "http://www.keyslakevillas.com/floor-plans-key-largo-apartment-rent-2-3-bedroom-beach-apt-keys-fl.html";
//			amenitiesUrl = "https://www.bellanovaatjubileepark.com/bellanova-at-jubilee-park-orlando-fl/amenities";
		}
		
		if(comUrl.contains("grandevilleatmalta")) {
			flrUrl="https://www.grandevilleatmalta.com/apartments/ny/malta/floor-plans#/categories/all/floorplans";
		}
		
		if(comUrl.contains("https://www.vintyapartments.com/vinty-elizabeth-nj")) {
			flrUrl="https://www.vintyapartments.com/vinty-elizabeth-nj/floorplans";
		}
		
        //-----------Address Section----------
    	String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		U.log("mapUrl ::"+mapUrl);
		String mapHtml= null;
		if(mapUrl != ALLOW_BLANK)
			mapHtml = U.getPageSource(mapUrl);
		if(mapHtml == null)mapHtml = ALLOW_BLANK;
		
		String addlatlogSec=U.getSectionValue(mapHtml, "<div class=\"directions widget clearfix\"","</script>");
		if(addlatlogSec == null)addlatlogSec=U.getSectionValue(mapHtml, "<div class=\"directions widget ","</script>");
//		U.log("addlatlogSec:: "+addlatlogSec);
		
//		if(comUrl.contains("http://www.keyslakevillas.com")) {
//			
//			addlatlogSec=U.getSectionValue(mapHtml, "http://maps.google.com/maps?hl=en&amp;q=","</a>");
//			
//			String addsec = U.getSectionValue(addlatlogSec, "hl=en&amp;q=", "&amp;");
//			
//			if(addsec!=null) {
//				
//				addsec = addsec.replace("+", " ").replace("-", ",");
//				add = U.getAddress(addsec);
//				U.log("Address:: "+Arrays.toString(add));
//				
//				String latSec = U.getSectionValue(addlatlogSec, "ll=", "&amp;");
//				
//				if(latSec!=null)
//					latlag = latSec.split(",");
//				
//			}
//			
//		}
		
		
//		U.log("addlatlogSec:: "+addlatlogSec);
		if(addlatlogSec == null)addlatlogSec = ALLOW_BLANK;
		String addSec=U.getSectionValue(addlatlogSec, "\"address\": \"","\",");
		if(addSec!=null){
			U.log(addSec+"==");
			add=U.getAddress(addSec);			
		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		if(add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			add[0] = U.getSectionValue(html, "itemprop=\"streetAddress\">", "</span>");
			add[1] = U.getSectionValue(html, "itemprop=\"addressLocality\">", "</span>");
			add[2] = U.getSectionValue(html, "itemprop=\"addressRegion\">", "</span>");
			add[3] = U.getSectionValue(html, "itemprop=\"postalCode\">", "</span>");
		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		if(add[0] == null && add[1] == null && add[3] == null){
			add[0] = U.getSectionValue(html, "itemprop=\'streetAddress\'>", "</span>");
			add[1] = U.getSectionValue(html, "itemprop=\'addressLocality\'>", "</span>");
			add[2] = U.getSectionValue(html, "itemprop=\'addressRegion\'>", "</span>");
			add[3] = U.getSectionValue(html, "itemprop=\'postalCode\'>", "</span>");
		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		//--------------------------------------------------latlng----------------------------------------------------------------
		String lat=null,log=null;
//		Commented because latlong not shown on commpage but shown in pagesource  
//==
//		String lat=Util.match(addlatlogSec, "lat\"\\s*:\\s*\"(.*?)\"",1);//U.getSectionValue(addlatlogSec, "\"lat\" : \"","\",");
//        String log=Util.match(addlatlogSec, "lon\"\\s*:\\s*\"(.*?)\"",1);//U.getSectionValue(addlatlogSec, "\"lon\" : \"","\",");
//        if(lat != null && log != null) {
//        	latlag[0]=lat.trim();
//        	latlag[1]=log.trim();
//        }		
//==
		if(add[0]==ALLOW_BLANK  && latlag[0].trim()!=ALLOW_BLANK){
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getGoogleAddressWithKey(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(latlag[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK){
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		if((add[3]==null||add[3] == ALLOW_BLANK )&& latlag[0] != ALLOW_BLANK){
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getGoogleAddressWithKey(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo = "True";
		}			
		//============================================Price and SQ.FT======================================================================				
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String flrarr[] = U.getValues(html, "<li class=\"cta-item cta-item-1\">", "</li>");		
		
		if(comUrl.contains("https://www.citywalkatwoodbury.com/")) {
			floorHtml = U.getHtml(flrUrl,driver);
			flrhtml1=U.getHtml(flrUrl+"?page=2",driver);
	        floorHtml=floorHtml+flrhtml1;
		}else if(flrUrl != ALLOW_BLANK) {
		
			U.log("fleUrl:::::"+flrUrl);
			floorHtml = U.getHtml(flrUrl,driver);
		}

		
    	String prices[] = U.getPrices(html+ floorHtml,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
			//	===================================================Sq.ft===========================================================================================								
       	html = html.replaceAll("65,000 square", "");
       	
       	floorHtml=floorHtml.replaceAll("<h2>Sqft</h2>\\s*<span class=\"square-foot\">", "<h2>Sqft</h2>");
//		U.log("MMMMMMMMMMM "+Util.matchAll(floorHtml, "[\\s\\w\\W]{30}Sqft</h2>[\\s\\w\\W]{30}", 0));

       	
		String[] sqft = U.getSqareFeet(html+floorHtml,
						"<h2>Sqft</h2>\n<span class='square-foot'>\\d,\\d{3}</span>|<h2>Sqft</h2>\n<span class='square-foot'>\\d{3}</span>|<h2>Sqft</h2>\\d,\\d{3}|<h2>Sqft</h2>\\d{3}|<span class=\"square-foot\">\\s+(\\d,)?\\d{3}\\s+</span>|>\\d,\\d{3} Sq\\.Ft<|>\\d{3} Sq\\.Ft<|\\d{4} Sq. Ft.|\\d{4} Sq. Ft.|\\d{3} Sq. Ft.|\\d,\\d{3} Sq. Ft.|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);

		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		//================================================community type========================================================
		if(amenitiesUrl != ALLOW_BLANK)
			amenitiesHtml=U.getPageSource(amenitiesUrl);	
		String remMeta = U.getSectionValue(html, "<meta name=\"Keywords\" content=\"", "\"");
		if(remMeta != null)html = html.replace(remMeta, "");	
		if(amenitiesHtml != null) amenitiesHtml = amenitiesHtml.replace("resort-style amenities", "resort style");
		String communityType=U.getCommType((html+amenitiesHtml).replaceAll("title=\"Dubsdread Golf|blank\">Dubsdread Golf|Dubsdread Golf|dubsdread-golf|Birnamwood Golf Course", ""));				

		U.log("MMMMMMMMMMM "+Util.matchAll(html+floorHtml, "[\\s\\w\\W]{30}Golf Course[\\s\\w\\W]{300}", 0));

		//==========================================================Property Type================================================		
		html = html.replace("features and custom finishes", "features and custom homes ");
		String proptype=U.getPropType((html+floorHtml+amenitiesHtml).replaceAll("title\">Carriage House&nbsp;<|garden-style community in Key Largo, Florida|luxurious lifestyle\\.\"|luxury lifestyle\\.\"/>|luxury living in Key Largo, FL\"/>| content=\"(.*)\"", ""));				
		
		if(proptype.contains("Townhouse") && proptype.contains("Townhome")){
			proptype = proptype.replaceAll("Townhouse,|Townhouse", "");
		}
		U.log("proptype: "+proptype);
//==================================================D-Property Type======================================================				
		String dtype=U.getdCommType((html+floorHtml+amenitiesHtml).replaceAll("Two-Story Health Club | two-story health club", ""));				
//==============================================Property Status=========================================================
		html = html.replaceAll("Fitness  coming soon|Now Open by Appointment|Office Hours\n\\s*</h5>\n\\s*<p>\n\\s*NOW OPEN!|Now Open!</li>| Coming soon to Maynard Crossing |apply\\.\\s*Limited time|pply\\.  Limited Time Offer|- Coming Soon</li>|Restriction may apply. Limited time offer.</p>|Portal Coming Soon", "");
		String pstatus=U.getPropStatus(html);
//		U.log("MMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{300}NOW OPEN[\\s\\w\\W]{300}", 0));
//============================================note====================================================================				
		 note=U.getnote(html);
		
		add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
		
		if(comUrl.contains("http://www.thelandingsapartments.com")) {
			
			proptype = proptype + ", Luxury Homes";//img
			//note = "Leasing Fast";//img
		}
		if(comUrl.contains("http://www.keyslakevillas.com")||comUrl.contains("https://www.grandevilleatmalta.com/")) {
			//because latlong not shown on page ubut inside pageSource
			latlag=U.getGoogleLatLngWithKey(add);
			geo="true";
		}
		//
		if(comUrl.contains("http://www.keyslakevillas.com"))proptype = proptype.replace(", Villas", "");  //because it come from comm name
		if(comUrl.contains("https://www.villagrandeonsaxon.com/"))geo="TRUE";
		if(comUrl.contains("grandreserveatleevista")) {
			minSqft="851";
			maxSqft="1550";
		}
		if(comUrl.contains("grandreserveatmaitland")) {
			minSqft="765";
			maxSqft="1550";
		}
		if(comUrl.contains("bellanova-at-jubilee-park-orlando-fl")){
			//From Floor Plan Img
			minSqft="792";
			maxSqft = "1501";
		
		}
		
		 if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;
		
		 	String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
		 
		 
		data.addCommunity(U.getCapitalise(communityName.toLowerCase()),comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
		
		j++;	
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
	
	private void addDetails2(String comUrl, String commData) throws Exception {
		U.log("commUrl-->"+comUrl);
		String html=U.getPageSource(comUrl);
		 if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;
        if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov") ||comUrl.contains("https://www.morgancommunities.com/apartments/ny/malta/grandeville-at-malta/") )return;
        //------Community name--------
        String communityName=U.getSectionValue(commData, "<h3>","</h3>");
        communityName=communityName.replace("Villas","");
        U.log("community Name---->"+communityName);
        //-----------Urls--------------
        String flrUrl=ALLOW_BLANK;
		String floorHtml=ALLOW_BLANK;
		String amenitiesUrl=ALLOW_BLANK;
		String amenitiesHtml=ALLOW_BLANK;
		String flrhtml1=ALLOW_BLANK;
		String mapUrl=ALLOW_BLANK;
		String urlSections =U.getSectionValue(html, "<ul class=\"top-nav location-nav\">", "</nav>");
		String Urls[]=U.getValues(urlSections, "<a href=\"", "\">");
		for (String url : Urls) {
		    if(url.contains("floor-plans")){
		    	U.log("url::"+url);
		    	if(url.contains("floor-plans-pricing")) {
				flrUrl=comUrl+"floor-plans-pricing#/categories/all/floorplans";
		    	}
		    	else
		    		flrUrl=comUrl+url;
			}			
			if(url.contains("amenities")) {
				if(url.contains("features-amenities"))
					amenitiesUrl=comUrl+"features-amenities";
				else
				amenitiesUrl=comUrl+url;			
			}
			if(url.contains("map-directions")) {
				if(url.contains("grandeville-at-malta"))
					mapUrl=comUrl+"map-directions";
				else
					mapUrl=comUrl+url;
			}			
		} 	
        //-----------Address Section----------
    	String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		U.log("mapUrl ::"+mapUrl);
		String mapHtml=U.getPageSource(mapUrl);
		String addlatlogSec=U.getSectionValue(mapHtml, "<div class=\"directions widget clearfix\"","</script>");
		String addSec=U.getSectionValue(addlatlogSec, "\"address\": \"","\",");
		if(addSec!=null){
			U.log(addSec+"==");
			add=U.getAddress(addSec);			
		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);		
		//--------------------------------------------------latlng----------------------------------------------------------------
		String lat=Util.match(addlatlogSec, "lat\"\\s*:\\s*\"(.*?)\"",1);//U.getSectionValue(addlatlogSec, "\"lat\" : \"","\",");
        String log=Util.match(addlatlogSec, "lon\"\\s*:\\s*\"(.*?)\"",1);//U.getSectionValue(addlatlogSec, "\"lon\" : \"","\",");
        if(lat != null && log != null) {
	            	latlag[0]=lat.trim();
	            	latlag[1]=log.trim();
	            }			
				if(add[0]==ALLOW_BLANK  && latlag[0].trim()!=ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(latlag[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK){
					latlag=U.getlatlongGoogleApi(add);
					if (latlag==null) U.getlatlongHereApi(add);
					geo="TRUE";
				}				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				if(add[3] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo = "True";
				}				
				//============================================Price and SQ.FT======================================================================			
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String flrarr[] = U.getValues(html, "<li class=\"cta-item cta-item-1\">", "</li>");	
				 floorHtml = U.getHtml(flrUrl,driver);
				String prices[] = U.getPrices(floorHtml,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);			
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];				
				U.log("Price--->"+minPrice+" "+maxPrice);
			//	===================================================Sq.ft===========================================================================================		
            	String[] sqft = U
				.getSqareFeet(
						floorHtml.replaceAll("sq. ft. (E)", ""),
						"(\\d,)*\\d{3} Sq. Ft.|\\d{4} Sq. Ft.|\\d+ Sq. Ft.|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);
		U.log("prices::::::::::"+sqft[0]+":::::::::::");
		if(sqft[0].length() <3)
			{U.log("inside if");
			sqft[0]="808";}		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+","+maxSqft);
		//================================================community type========================================================
		amenitiesHtml=U.getPageSource(amenitiesUrl);	
		String remMeta = U.getSectionValue(html, "<meta name=\"Keywords\" content=\"", "\"");
				if(remMeta != null)html = html.replace(remMeta, "");				
				String communityType=U.getCommType(html+amenitiesHtml);			
		//==========================================================Property Type================================================				
				String proptype=U.getPropType((html+floorHtml+amenitiesHtml).replace("about our garden style apartments", "").replace("content=\"Looking for garden", "").replace("Vista we offer garden style 1", ""));				
				if(proptype.contains("Townhome") && proptype.contains("Townhouse")){
					proptype = proptype.replaceAll(",Townhouse", "");
				}
		//==================================================D-Property Type======================================================			
				String dtype=U.getdCommType(html+floorHtml+amenitiesHtml);				
		//==============================================Property Status=========================================================
				String pstatus=U.getPropStatus(html);			
		//============================================note====================================================================				
				 note=U.getnote(html);
				if(data.communityUrlExists(comUrl)){
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
					}
				U.log("minSqft:::::::"+minSqft+"::::::");		
				U.log("minSqft:::::::"+minSqft);
				add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
					data.addCommunity(communityName.trim(),comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
				j++;		
	}
	private void addDetails3(String comUrl, String commData) throws Exception {
		U.log("commUrl-->"+comUrl);
		if(comUrl.contains("https://www.grandevilleatjubileepark.com/"))return;
		 if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;
		String html=U.getPageSource(comUrl);
        if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov"))return;
        //------Community name--------
        String communityName=U.getSectionValue(commData, "<h3>","</h3>");
        communityName=communityName.replace("Villas","");
        U.log("community Name---->"+communityName);
        //-----------Urls--------------
        String flrUrl="http://www.grandevilleatjubileepark.com/floorplans/#rockwell-1-bed-1-bath";
		String floorHtml=ALLOW_BLANK;
		String amenitiesUrl="http://www.grandevilleatjubileepark.com/amenities/";
		String amenitiesHtml=ALLOW_BLANK;
	    String mapUrl="http://www.grandevilleatjubileepark.com/map/";    	
        //-----------Address Section----------
    	String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String mapHtml=U.getPageSource(mapUrl);
		String addlatlogSec=U.getSectionValue(mapHtml, "<span itemprop=\"address\"","</div>");
		U.log("addlatlogSec:::::::::"+addlatlogSec);
		if(addlatlogSec!=null){
			add[0]=U.getSectionValue(addlatlogSec, "\"api-address\">","</span>");
			add[1]=U.getSectionValue(addlatlogSec, "addressLocality\">", ", </span>");
			add[2]=U.getSectionValue(addlatlogSec, "addressRegion\">", " </span>");
			add[3]=U.getSectionValue(addlatlogSec, "postalCode\">", "</span>");			
		}
		U.log("Address----add[0]>"+add[0]+"add[1]: "+add[1]+"add[2]:: "+add[2]+"add[3]:: "+add[3]);		
		//--------------------------------------------------latlng----------------------------------------------------------------
				String lat=U.getSectionValue(addlatlogSec, "<meta itemprop=\"longitude\" content=\"","\">");
	            String log=U.getSectionValue(addlatlogSec, "<meta itemprop=\"latitude\" content=\"","\">");
	            if(lat != null && log != null) {
	            	latlag[0]=lat.trim();
	            	latlag[1]=log.trim();
	            }				
				if(add[0]==ALLOW_BLANK  && latlag[0].trim()!=ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(latlag[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK){
					latlag=U.getlatlongGoogleApi(add);
					if (latlag==null) U.getlatlongHereApi(add);
					geo="TRUE";
				}			
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				if(add[3] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo = "True";
				}				
				//============================================Price and SQ.FT======================================================================				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;				
				 floorHtml = U.getHtml(flrUrl,driver);
				String prices[] = U.getPrices(floorHtml,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];				
				U.log("Price--->"+minPrice+" "+maxPrice);
			//	===================================================Sq.ft===========================================================================================		
			html = html.replaceAll("65,000 square", "");
		floorHtml=floorHtml.replaceAll("</th>\\s*\\n*\\s*<td class=\"footage\">", "").replaceAll(".is_townhome ?", "").replace("fp.is_townhome ? \" Townhome \"", "").replace("_townhome' :", "").replace("Townhome \" :", "");
		String[] sqft = U
				.getSqareFeet(
						floorHtml,
						"<th>Sq. Ft.:\\d{4}</td>|<th>Sq. Ft.:\\d{3}</td>|\\d{4} Sq. Ft.|\\d+ Sq. Ft.|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);

		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		//================================================community type========================================================
		amenitiesHtml=U.getPageSource(amenitiesUrl);	
		String remMeta = U.getSectionValue(html, "<meta name=\"Keywords\" content=\"", "\"");
				if(remMeta != null)html = html.replace(remMeta, "");
				String communityType=U.getCommType(html+amenitiesHtml);		
		//==========================================================Property Type================================================
			String proptype=U.getPropType(html+floorHtml+amenitiesHtml);				
				if(proptype.contains("Townhome") && proptype.contains("Townhouse")){
					proptype = proptype.replaceAll(",Townhouse", "");
				}
		//==================================================D-Property Type======================================================				
				String dtype=U.getdCommType(html+floorHtml+amenitiesHtml);				
		//==============================================Property Status=========================================================
				String pstatus=U.getPropStatus(html);				
		//============================================note====================================================================		
				 note=U.getnote(html);
			if(data.communityUrlExists(comUrl)){
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
					}
				add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
				j++;		
	}
	private void addDetails4(String comUrl, String commData) throws Exception {
		U.log("commUrl-->"+comUrl);
		String html=U.getPageSource(comUrl);
		 if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;
        if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov"))return;
        //------Community name--------
        String communityName=U.getSectionValue(commData, "<h3>","</h3>");
        communityName=communityName.replace("Villas","");
        U.log("community Name---->"+communityName);
        //-----------Urls--------------
        String flrUrl="http://www.keyslakevillas.com/floor-plans-key-largo-apartment-rent-2-3-bedroom-beach-apt-keys-fl.html";
		String floorHtml=ALLOW_BLANK;
		String amenitiesUrl="http://www.keyslakevillas.com/apartments-fl-keys-lake-villas-florida-best-new-key-largo-gulf-coast-apt.html";
		String amenitiesHtml=ALLOW_BLANK;
		String mapUrl="http://www.keyslakevillas.com/location-area-map-gulf-mexico-key-largo-apartments-apt-best-new-rent.html";    	
        //-----------Address Section----------
    	String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String mapHtml=U.getPageSource(mapUrl);
		String googel=U.getSectionValue(mapHtml, "ie=UTF8&amp;hq=&amp;hnear=","&amp;t=h&amp;");		
		googel=googel.replace(".+",",").replace("Dr+", "Dr,").replace("Street+", "Street,");
		googel=googel.replace("+"," ");	
		googel=googel.replace("%2C",",").replace("Florida","FL,");
		U.log("Googe-->"+googel);
		String[] add1=googel.split(",");
		if(add1.length>3){
			add[0]=add1[0];
			add[1]=add1[1];
			if(add1[2].contains(" FL 3")){
				add[2]=Util.match(add1[2], "\\w+");
				add[3]=Util.match(add1[2], "\\d+");
			}
			else{
				add[2]=add1[2].trim();
				add[3]=add1[3];
			}
			U.log("<--------------first Address---->"+add[0]+"city"+add[1]+"state "+add[2]+"pin "+add[3]+"<----------------");		
		}
		U.log("Address----add[0]>"+add[0]+"add[1]: "+add[1]+"add[2]:: "+add[2]+"add[3]:: "+add[3]);		
		//--------------------------------------------------latlng----------------------------------------------------------------
				if(mapHtml.contains("ll=")){
					String latLngSec = U.getSectionValue(mapHtml, "ll=", "&amp;spn=0");
					U.log("latLngSec One::::::::::::::"+latLngSec);
					if(latLngSec!=null){
						latlag = latLngSec.split(",");					
					}
				}				
				U.log("lat : "+latlag[0] + "\tlng : "+latlag[1]);			
				if(add[0]==ALLOW_BLANK  && latlag[0].trim()!=ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(latlag[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK){
					latlag=U.getlatlongGoogleApi(add);
					if (latlag==null) U.getlatlongHereApi(add);
					geo="TRUE";
				}				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				if(add[3] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo = "True";
				}				
				//============================================Price and SQ.FT======================================================================			
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				 floorHtml = U.getHtml(flrUrl,driver);
				String prices[] = U.getPrices(floorHtml,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);			
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];			
				U.log("Price--->"+minPrice+" "+maxPrice);
			//	===================================================Sq.ft===========================================================================================		
		 html = html.replaceAll("65,000 square", "");
		String[] sqft = U
				.getSqareFeet(
						floorHtml,
						"\\d+,\\d{3} square feet.|\\d{3} square feet.|\\d{4} Sq. Ft.|\\d+ Sq. Ft.|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		//================================================community type========================================================
		amenitiesHtml=U.getPageSource(amenitiesUrl);	
		String remMeta = U.getSectionValue(html, "<meta name=\"keywords\"", "/>");
				if(remMeta != null)html = html.replace(remMeta, "");	
				amenitiesHtml=U.removeSectionValue(amenitiesHtml, "<meta name=\"keywords\"", "/>");
				String communityType=U.getCommType(html+amenitiesHtml);			
		//==========================================================Property Type================================================
				String proptype=U.getPropType(html+floorHtml+amenitiesHtml);				
				if(proptype.contains("Townhome") && proptype.contains("Townhouse")){
					proptype = proptype.replaceAll(",Townhouse", "");
				}
		//==================================================D-Property Type======================================================				
				String dtype=U.getdCommType(html+floorHtml+amenitiesHtml);				
		//==============================================Property Status=========================================================
				String pstatus=U.getPropStatus(html);				
		//============================================note====================================================================				
				 note=U.getnote(html);
			if(data.communityUrlExists(comUrl))
					{
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
					}
				add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
				j++;		
	}
	private void addDetails5(String comUrl, String commData) throws Exception {
		U.log("commUrl-->"+comUrl);
		comUrl="https://www.villagrandeonsaxon.com";
		String html=U.getHtml(comUrl,driver);
		 if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;
//		html=U.removeSectionValue(html, "<meta name=\"description\" content=\"", "<meta name=\"page-topic\"");
//		U.log(html);
        if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov"))return;
        //------Community name--------
        String communityName=U.getSectionValue(commData, "<h3>","</h3>");
        communityName=communityName.replace("Villas","");
        U.log("community Name---->"+communityName);
        //-----------Urls--------------
        String flrUrl="https://www.villagrandeonsaxon.com/apartments/fl/orange-city/floor-plans#/categories/all/floorplans";
		String floorHtml=ALLOW_BLANK;
		String amenitiesUrl="https://www.villagrandeonsaxon.com/apartments/fl/orange-city/amenities";
		String amenitiesHtml=ALLOW_BLANK;
	    String mapUrl="https://www.villagrandeonsaxon.com/apartments/fl/orange-city/map-directions";
	    String apartmentUrl="http://www.villagrandeonsaxon.com/apartment_apartments_senior_community_orange_city_florida_best_orlando.html";  	
        String ContentFromImg="Gated community, crafting, patio,Immediate Availabilty,golf courses";
	    
	    //-----------Address Section----------
    	String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String mapHtml=U.getPageSource(mapUrl);
//		String googel=U.getSectionValue(mapHtml, "Villa Grande on Saxon <span class=\"style80\">I</span> "," <span");
		String googel = "450 Alessandra Circle, Orange City Florida 32763 ";
		googel=googel.replace("%2C",",").replace(" Florida",", FL,");
		U.log("Googe-->"+googel);
		String[] add1=googel.split(",");
		if(add1.length>3){
			add[0]=add1[0];
			add[1]=add1[1];
			if(add1[2].contains(" FL 3")){
				add[2]=Util.match(add1[2], "\\w+");
				add[3]=Util.match(add1[2], "\\d+");
			}
			else{
				add[2]=add1[2].trim();
				add[3]=add1[3];
			}
			U.log("<--------------first Address---->"+add[0]+"city"+add[1]+"state "+add[2]+"pin "+add[3]+"<----------------");		
		}
		U.log("Address----add[0]>"+add[0]+"add[1]: "+add[1]+"add[2]:: "+add[2]+"add[3]:: "+add[3]);		
		//--------------------------------------------------latlng----------------------------------------------------------------
			   if(mapHtml.contains("ll=")){
					String latLngSec = U.getSectionValue(mapHtml, "ll=", "&amp;spn=0");
					U.log("latLngSec One::::::::::::::"+latLngSec);
					if(latLngSec!=null){
						latlag = latLngSec.split(",");						
					}
				}				
				U.log("lat : "+latlag[0] + "\tlng : "+latlag[1]);				
				if(add[0]==ALLOW_BLANK  && latlag[0].trim()!=ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(latlag[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK){
					latlag=U.getlatlongGoogleApi(add);
					if (latlag==null) U.getlatlongHereApi(add);
					geo="TRUE";
				}				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				if(add[3] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK){
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getGoogleAddressWithKey(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo = "True";
				}			
				//============================================Price and SQ.FT======================================================================
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				floorHtml = U.getHtml(flrUrl,driver);
				floorHtml=U.removeSectionValue(floorHtml, "<meta name=\"keywords\" content=\"", "/>");
				if(floorHtml==null)floorHtml=ALLOW_BLANK;
				String prices[] = U.getPrices(floorHtml,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				U.log("Price--->"+minPrice+" "+maxPrice);
			//	===================================================Sq.ft===========================================================================================		
				U.log(html);
//				html = html.replaceAll("65,000 square", "");
                String[] sqft = U
				.getSqareFeet(
						floorHtml,
						"\\d+,\\d{3} square feet.|\\d{3} square feet.|\\d{4} Sq. Ft.|\\d+ Sq. Ft.|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//		minSqft = "940";
//		maxSqft = "1438";
		//================================================community type========================================================
		amenitiesHtml=U.getPageSource(amenitiesUrl);	
		amenitiesHtml=U.removeSectionValue(amenitiesHtml, "<meta name=\"keywords\" content=\"", "/>");
		String remMeta = U.getSectionValue(html, "<meta name=\"Keywords\" content=\"", "\"");
				if(remMeta != null)html = html.replace(remMeta, "");				
				String communityType=U.getCommType(html+amenitiesHtml+ContentFromImg);				
		//==========================================================Property Type================================================
				String proptype=U.getPropType(html.replaceAll("living_community_condos_", "")+floorHtml+amenitiesHtml+ContentFromImg);				
				if(proptype.contains("Townhome") && proptype.contains("Townhouse")){
					proptype = proptype.replaceAll(",Townhouse", "");
				}
		//==================================================D-Property Type======================================================				
				String dtype=U.getdCommType(html+floorHtml+amenitiesHtml);				
		//==============================================Property Status=========================================================
				String pstatus=U.getPropStatus(html+ContentFromImg);		
		//============================================note====================================================================
				 note=U.getnote(html);
			       if(data.communityUrlExists(comUrl)){
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
					}
				add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
				j++;		
	}
	
	
	private void addDetailsNewCommunities(String comUrl, String commData) throws Exception {
		U.log("commUrl-->"+comUrl);
//		if(!comUrl.contains("https://www.maynardluxuryapartments.com"))return;
        if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov"))return;
        if(comUrl.contains("www.eccoonorange.com"))return;//please check before next execution
        if(comUrl.contains("https://www.maynardluxuryapartments.com"))comUrl="https://www.vueatmaynardcrossing.com/the-vue-at-maynard-crossing-maynard-ma/";
		String html=U.getHtml(comUrl,driver);
		 if(comUrl.contains("https://www.eccoonorange.com/ecco-on-orange-orlando-fl"))return;
        //------Community name--------
        U.log(commData);
        String communityName=U.getSectionValue(commData, "<h3>","</h3>").trim();
        communityName=communityName.replaceAll("Villas$|Apartments\\s*$","");
        U.log("community Name---->"+communityName);

//        //-----------Address Section----------
    	String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";

		String addSec=U.getSectionValue(html, "address=",", USA");
		if(addSec!=null){
			U.log(addSec+"==");
			add=U.getAddress(addSec);	
			if(add==null)add[0]=ALLOW_BLANK;
		}else if (html.contains("<h5>Address</h5>")) {
			add[0]=U.getSectionValue(html, "streetAddress\">","<");
			add[1]=U.getSectionValue(html, "addressLocality\">","<");
			add[2]=U.getSectionValue(html, "addressRegion\">","<");
			add[3]=U.getSectionValue(html, "postalCode\">","<");
		} 
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);		
//		//--------------------------------------------------latlng----------------------------------------------------------------
				String[] lat_long=U.getValues(html, "{\"id\":","},");
				String laSec="";
				for (String string : lat_long) {
					if(string.contains(communityName)) {
						laSec=string;
						break;
					}
				}
				String lat=U.getSectionValue(laSec, "latitude\":",",");;//U.getSectionValue(addlatlogSec, "\"lat\" : \"","\",");
	            String log=U.getSectionValue(laSec, "longitude\":",",");//U.getSectionValue(addlatlogSec, "\"lon\" : \"","\",");
	            if(lat==null) {
	            	String ss=U.getSectionValue(html, "googleMap.html?language=en&amp;","\"");
	            	if(ss!=null) {
	            	lat=U.getSectionValue(ss, "lat=","&amp;");
	            	log=U.getSectionValue(ss, "long=", "&amp;");
	            	}
	            	else {
	            		lat=U.getSectionValue(html, "\"latitude\":",",");
		            	log=U.getSectionValue(html, "\"longitude\":", ",");
	            	}
	            }
	            U.log(lat+":::::::::::"+log);
				if(add[0]==ALLOW_BLANK  && lat.trim()!=ALLOW_BLANK){
					U.log("hellllllllllooo");
					add=U.getAddressGoogleApi(new String[] {lat,log});
					if(add == null) add = U.getGoogleAddressWithKey(new String[] {lat,log});
					if(add == null) add = U.getAddressHereApi(new String[] {lat,log});
					geo="TRUE";
				}
		
//				//============================================Price and SQ.FT======================================================================				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			    String prices[] = U.getPrices(html,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
			//	===================================================Sq.ft===========================================================================================								
       	html = html.replaceAll("65,000 square", "");
		String[] sqft = U
				.getSqareFeet(
						html,
						"\\d{4} Sq. Ft.|\\d{4} Sq. Ft.|\\d+ Sq. Ft.|\\d,\\d{3} Sq. Ft.|square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);

		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//		//================================================community type========================================================
//		amenitiesHtml=U.getPageSource(amenitiesUrl);	
//		String remMeta = U.getSectionValue(html, "<meta name=\"Keywords\" content=\"", "\"");
//				if(remMeta != null)html = html.replace(remMeta, "");				
				String communityType=U.getCommType(html);				
//		//==========================================================Property Type================================================		
				String proptype=U.getPropType(html.replaceAll("offers luxury apartments|- Luxury Apartments ", ""));				
//				if(proptype.contains("Townhome") && proptype.contains("Townhouse")){
//					proptype = proptype.replaceAll(",Townhouse", "");
//				}
//		//==================================================D-Property Type======================================================				
				String dtype=U.getdCommType((html).replaceAll("Two-Story Health Club | two-story health club", ""));				
//		//==============================================Property Status=========================================================
				String pstatus=U.getPropStatus(html.replaceAll("\"anchorName\":\"COMING SOON\"|Resident Portal Coming Soon", ""));				
//		//============================================note====================================================================				
				 note=U.getnote(html);
				 if(comUrl.contains("https://bellanovaatjubileepark.com"))add[0]="7800 JubiLee Park Boulevard";
				 if(comUrl.contains("maynardluxuryapartments") )geo="True";
				 if(comUrl.contains("bellanovaatjubileepark")) {
					 minSqft="792";
					 maxSqft="1501";
				 }
	  			if(data.communityUrlExists(comUrl)){
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
				}
				add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(lat.trim(), log.trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
				j++;		
	}
	
	private void getMorganCommunities() throws Exception {
		String mainHtml = U.getHTML("https://www.morgancommunities.com/our-communities");
		String stateList = U.getSectionValue(mainHtml, "\"selectedRegions\": [", "]");
//		U.log(stateList);
		String statesValues [] = stateList.split(",");
		for(String state:statesValues) {
				state = state.replace("\"", "");
				U.log(state);
				String stateHtml = U.getHTML("https://www.g5api.com/api/v0/corporate_location_search?client_id=1673&page=1&per_page=20&state="+state.trim());
				String storeSec = U.getSectionValue(stateHtml, "{\"stores\":[", "\"amenities\"");
				U.log("https://www.g5api.com/api/v0/corporate_location_search?client_id=1673&page=1&per_page=20&state="+state.trim());
				String comSecs[] =U.getValues(storeSec, "{", "}");
//				U.log(comSecs.length);
				extractData(comSecs);
				
		}
	}
	private void extractData(String comSecs[]) throws Exception{
		for(String commData:comSecs) {
			String comUrl = U.getSectionValue(commData, "page_url\":\"", "\"");
			U.log(commData);
			if(comUrl.contains("www.clients-must-have-primary-domains-for-stores-without-domains.com"))comUrl="https://www.morgancommunities.com/apartments/oh/toledo/steeplechase-apartments-townhomes/";
			if(comUrl.contains("oldecoach"))comUrl="https://www.morgancommunities.com/apartments/ny/queensbury/olde-coach-manor/";//page 404
			comUrl = U.getRedirectedURL("https://www.morgancommunities.com", comUrl);
//			if(!comUrl.contains("fairport/village-heights-senior-apartments/"))continue;
			String html=U.getHtml(comUrl,driver);
			String floorHtml = U.getHTML(comUrl+"/floor-plans-pricing#/categories/all/floorplans")+U.getHTML("https://inventory.g5marketingcloud.com/api/v1/apartment_complexes/"+U.getSectionValue(html, "\"G5_STORE_ID\": \"", "\"")+"/floorplans");
			U.log("https://inventory.g5marketingcloud.com/api/v1/apartment_complexes/"+U.getSectionValue(html, "\"G5_STORE_ID\": \"", "\"")+"/floorplans");
			String amenityHtml = U.getHTML(comUrl+"/features-amenities");
			if(amenityHtml==null)amenityHtml ="";

	        //------Community name--------
	        U.log(commData);
	        String communityName=U.getSectionValue(commData, "branded_name\":\"","\"").trim();
	        communityName=communityName.replaceAll("Villas$|Apartments\\s*$","");
	        U.log("community Name---->"+communityName);

//		        //-----------Address Section----------
	    	String note="";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo="False";

			
			add[0]=U.getSectionValue(commData, "\"street\":\"","\"");
			add[1]=U.getSectionValue(commData, "\"city\":\"","\"");
			add[2]=U.getSectionValue(commData, "\"state\":\"","\"");
			add[3]=U.getSectionValue(commData, "\"zip\":\"","\"");
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);		
//				//--------------------------------------------------latlng----------------------------------------------------------------
					
			String lat=U.getSectionValue(commData, "latitude\":\"","\",");
		    String log=U.getSectionValue(commData, "longitude\":\"","\",");
//				//============================================Price and SQ.FT======================================================================				
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			String prices[] = U.getPrices(html,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|Starting at \\$\\d{4}", 0);
					
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
					
			U.log("Price--->"+minPrice+" "+maxPrice);
//			U.log(floorHtml);
				//	===================================================Sq.ft===========================================================================================								
			String[] sqft = U
					.getSqareFeet(
							html+floorHtml,
							"\\d{3}-\\d{3} sq. ft.|\"sqft\":\\d{3,4}|\\d{3} square feet to \\d{3} square feet|\\d{3} sq. ft. to \\d,\\d{3} sq. ft.|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet|\"sqft\": \\d{3,4}|\\d{4} Sq. Ft.|\\d{4} Sq. Ft.| \\d{3} sq. ft.",
							0);

			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//				//================================================community type========================================================
		
			String communityType=U.getCommType(html+amenityHtml);				
//				//==========================================================Property Type================================================		
			String proptype=U.getPropType((html+floorHtml+amenityHtml).replaceAll("offers luxury apartments|- Luxury Apartments |alt=\".*\"", ""));				

//				//==================================================D-Property Type======================================================				
			String dtype=U.getdCommType((html+floorHtml+amenityHtml).replaceAll("Two-Story Health Club | two-story health club", ""));				
//				//==============================================Property Status=========================================================
			String pstatus=U.getPropStatus(html.replaceAll("\"anchorName\":\"COMING SOON\"", ""));				
//				//============================================note====================================================================				
			note=U.getnote(html);
			U.log(Util.matchAll(html+floorHtml+amenityHtml , "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}", 0));

			if(comUrl.contains("https://www.morgancommunities.com/apartments/pa/york/the-view-at-mackenzi/"))minSqft ="1,008";
		  	if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl);
				k++;
				return;
			}
		  	
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
		  	
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(lat.trim(), log.trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
			
			j++;	
		
	}
	}
	private void addDetails(String comUrl, String commData) throws Exception {
		// TODO Auto-generated method stub
	//if(!comUrl.contains("http://www.lecesse.com/villa-grande-saxon-apartments-senior-orange-city-florida-fl.html"))return;
		
	//		if(comUrl.contains("http://www.lecesse.com/legacy-apartments-properties-developers-fl-tx-ny-va-mn-ri.html"))return;
			
			U.log("commUrl-->"+comUrl);
						String html=U.getPageSource(comUrl);
		if(comUrl.contains("http://www.lecesse.com/http://www.hud.gov"))return;
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(commData, "<h3>","</h3>");
		communityName=communityName.replace("Villas","");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		String webUrl=U.getSectionValue(html, "middle\"><a href=\"","\"");
		String websiteHtml=null;
		String florUrl=null;
		if(webUrl!=null)
		{
			websiteHtml=U.getPageSource(webUrl);
			
//-----------------------------------------------------------------------------------------------------------
			U.log("WebUrl-->"+webUrl);
			switch(webUrl)
			{
			case "http://www.uptownatcitywalk.com":
			{
				florUrl="https://www.citywalkatwoodbury.com/apartments/mn/woodbury/floor-plans";
				break;
			}
			case "http://www.citywalkatwoodbury.com" :
			{
				florUrl="http://www.citywalkatwoodbury.com/apartments/mn/woodbury/floor-plans";
				break;
			}
			case "http://www.rizeatwintersprings.com" :
			{
				florUrl="http://www.rizeatwintersprings.com/apartments/fl/winter-springs/apartments#/bedrooms";
				break;
			}
			case "http://www.keyslakevillas.com" :
			{
				florUrl="http://www.keyslakevillas.com/floor-plans-key-largo-apartment-rent-2-3-bedroom-beach-apt-keys-fl.html";
				break;
			}

			case "http://www.skyeatarborlakes.com" :
			{
				florUrl="https://www.skyeatarborlakes.com/apartments/mn/maple-grove/floor-plans#/categories";
				break;
			}
			case "http://www.500oceanapartments.com" :
			{
				//plan not present
				break;
			}
			case "http://www.grandevilleatjubileepark.com" :
			{
				florUrl="http://www.grandevilleatjubileepark.com/floorplans/#rockwell-1-bed-1-bath";
				break;
			}
			case "http://www.lecesse.com/ancora-international-drive-apartments-orlando-florida-fl.html" :
			{
				////plan not present
				break;
			}
			case "http://www.lecesse.com/grandeville-park-place-apartments-malta-ny.html" :
			{
			////plan not present
				break;
			}
			case "http://www.lecesse.com/union-station-apartments-ashland-ma.html" :
			{
			////plan not present
				break;
			}
			case "http://www.villagrandesarasota.com" :
			{
				florUrl="http://www.liveoverture.com/sarasota-grandoaks/floor-plans";
				break;
			}
			case "http://www.villagrandeonsaxon.com" :
			{
				florUrl="http://www.villagrandeonsaxon.com/floorplans_senior_community_orange_city_florida_near_orlando_fl.html";
				break;
			}
			case "http://www.benningtonhillsapartments.com" :
			{
				florUrl="http://www.benningtonhillsapartments.com/floorplans.html";
				break;
			}
			case "http://www.thelandingsapartments.com" :
			{
				florUrl="http://www.thelandingsapartments.com/floor-plans-landings-ny-apartments-1-2-3-bedroom.html";
				break;
			}
			case "http://www.grandreserveatleevista.com" :
			{
				florUrl="http://www.grandreserveatleevista.com/floor-plans-orlando-apartments-1-2-3-4-bedroom-best.html";
				break;
			}
			case "http://www.grandreserveatmaitland.com" :
			{
				florUrl="http://www.grandreserveatmaitland.com/floor-plans-maitland-orlando-apartments-1-2-3-4-bedroom.html";
				break;
			}
			case "http://www.countryplaceapartmentsorlando.com" :
			{
				florUrl="http://www.luxuryorlandoapts.com/floorplans";
				break;
			}
			
			}
//---------------------------------------------------------------------------------------------------------				
		}
		
		String florHtml="";
		if(florUrl!=null)
			{
			florHtml=U.getPageSource(florUrl);
			}
		String addSec=U.getSectionValue(html, "style30\">I</span>","<span");
		if(addSec != null && addSec.length() > 100)
			addSec=U.getSectionValue(html, "valign=\"bottom\" class=\"style3\">","</td>");
		if(comUrl.contains("http://www.lecesse.com/rize-winter-springs-apartments-near-orlando-florida-fl.html"))
			addSec = "150 Bear Springs Drive,Winter Springs, FL 32708";
		if(comUrl.contains("http://www.lecesse.com/ancora-international-drive-apartments-orlando-florida-fl.html"))
			addSec = "International Drive,Orlando, FL";
		if(comUrl.contains("http://www.lecesse.com/union-station-apartments-ashland-ma.html"))
			addSec = "W. Union Street, Ashland, Massachusetts";
		if(addSec!=null)
		{
			U.log(addSec+"==");
			addSec=addSec.replace(", Suite"," Suite").replaceAll("<span class=\"style30\">", "");
			addSec=addSec.replace("-",",").replace("</span>", ",");
			
			String[] add1=addSec.split(",");
			if(add1.length>2)
			{
				add[0]=add1[0];
				add[1]=add1[1];
				add[3]=Util.match(add1[2],"\\d{4,}");
				if(add[3]!=null)
				{
				add[2]=add1[2].replace(add[3],"").trim();
				add[2]=add[2].replace("'","").replace("\"","").trim();
				}
				else
				{
					add[2]=add1[2].replace("'","").replace("\"","").trim();
				}
			}
		}
		
		addSec=U.getSectionValue(html, "style29\">I</span>","<span");
		if(add[1]==ALLOW_BLANK && addSec!=null)
		{
			
			U.log(addSec+"==");
			addSec=addSec.replace("-",",").replace(" 450 Altamonte"," 450, Altamonte");
			U.log(addSec+"==");
			String[] add1=addSec.split(",");
			if(add1.length>2)
			{
				add[0]=add1[0];
				add[1]=add1[1];
				add[3]=Util.match(add1[2],"\\d{4,}");
				if(add[3]!=null)
				{
				add[2]=add1[2].replace(add[3],"").trim();
				add[2]=add[2].replace("'","").replace("\"","").trim();
				}
				else
				{
					add[2]=add1[2].replace("'","").replace("\"","").trim();
				}
			}
			
		}
		if(add[3] == null)
			add[3] = ALLOW_BLANK;
		U.log(add[0]+"==");
		add[0] = add[0].replaceAll(" I$", "");
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
//--------------------------------------------------latlng----------------------------------------------------------------
		String latSec=null;
		if(websiteHtml!=null)
		{
		latSec=U.getSectionValue(websiteHtml, "https://www.google.com/maps/place","\"");
		}
		if(latSec!=null)
		{
			U.log(latSec);
			String lat=Util.match(latSec, "@\\d{2,3}.\\d+");
			String lng=Util.match(latSec, "-\\d{2,3}.\\d+");
			latlag[0]=lat.replace("@","");
			latlag[1]=lng;
		}
		if(add[0]==ALLOW_BLANK  && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getGoogleAddressWithKey(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(latlag[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			if (latlag==null) U.getlatlongHereApi(add);
			geo="TRUE";
		}
		
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		if(add[3] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK){
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getGoogleAddressWithKey(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo = "True";
		}
//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0&#8217;s|0s","0,000");
		String prices[] = U.getPrices(html+websiteHtml+florHtml,"the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		
//						U.log(florHtml);
		html = html.replaceAll("65,000 square", "");

		String[] sqft = U
				.getSqareFeet(
						html+websiteHtml+florHtml,
						"square-footage\">\\s+\\d?,?\\d{3}|[1-9]\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ to [1-9],\\d+ square feet|[1-9],\\d+ square feet|[ 1-9]\\d{3} square feet|size from \\d{3,4} to \\d{4} square feet|approximately \\d{3} to<br />\\s+\\d,\\d{3} square feet| approximately \\d,\\d{3} square feet.|start at \\d{3,4} square feet|at \\d?,?\\d{3} square feet|with \\d{3,4} square feet.|up to \\d{3,4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet",
						0);

		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		String remMeta = U.getSectionValue(html, "<meta name=\"Keywords\" content=\"", "\"");
		if(remMeta != null)html = html.replace(remMeta, "");
		
		String communityType=U.getCommType(html+websiteHtml);
		
//==========================================================Property Type================================================
		//html=U.getNoHtml(html);
		if(websiteHtml != null)
			websiteHtml = websiteHtml.replaceAll("on patio and with signed agreement|_townhomes_|Gated Community Coming Soon|Fitness Center Coming Soon|2 & 3 Bedroom Townhomes Coming Soon|soon for our one", "");
			
		String proptype=U.getPropType(html+websiteHtml);
		
		if(proptype.contains("Townhome") && proptype.contains("Townhouse")){
			proptype = proptype.replaceAll(",Townhouse", "");
		}
//==================================================D-Property Type======================================================
		
		String dtype=U.getdCommType(html+websiteHtml);
		
//==============================================Property Status=========================================================
		String pstatus=U.getPropStatus((html+websiteHtml).replaceAll("Fitness coming soon",""));
		
//============================================note====================================================================
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		
		 note=U.getnote(html);
		add[2] = add[2].replace("New York", "NY");
		
		if(comUrl.contains("grandeville-jubilee-park-lee-vista-apartments-orlando-florida-fl.html"))maxSqft = "1,523";
		
		if(data.communityUrlExists(comUrl))
			{
			LOGGER.AddCommunityUrl(comUrl);
			k++;
			return;
			}
		add[2]=add[2].replace("Florida","FL").replace("Mn","MN");
			data.addCommunity(communityName.trim(),comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		j++;
	}
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		 FirefoxProfile profile = new FirefoxProfile();
		 profile.setPreference("network.proxy.type", 1);//"104.248.2.111",8080
		 profile.setPreference("network.proxy.socks", "104.248.2.111");
		 profile.setPreference("network.proxy.socks_port", 8080);

		 driver = new FirefoxDriver(profile);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					Thread.sleep(3000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}


}