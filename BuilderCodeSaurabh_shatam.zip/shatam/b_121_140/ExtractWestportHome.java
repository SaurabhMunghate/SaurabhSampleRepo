/**
 * @author Priti
 * @date 01/08/2018
 * 
 */
package com.shatam.b_121_140;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWestportHome extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int duplicates = 0;
	static int j = 0;
	// WebDriver driver = new FirefoxDriver();

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractWestportHome();
		// U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "Westport Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public ExtractWestportHome() throws Exception {

		super("Westport Homes", "https://www.westport-home.com/");
		LOGGER = new CommunityLogger("Westport Homes");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://www.westport-home.com/");

		String section = U.getSectionValue(html, "Locations</a>", "</ul>");
		String[] values = U.getValues(section, "<a href=\"", "\">");

		for (String item : values) {
			// U.log("region:::" + item);
			
			String regionHtml = U.getHTML(item);
			regionHtml = StringEscapeUtils.unescapeJava(regionHtml);
			String sec = U.getSectionValue(regionHtml, "window.onload = function () { city_map", "</script>");
			//U.log(sec);
			String getCommSec[] = U.getValues(sec, "[\"<div class=\"map_info_heading", "br />\"]");
			LOGGER.AddRegion(item, getCommSec.length);

			//U.log(getCommSec.length);
			for (String comSec : getCommSec) {
				
				String comUrl = U.getSectionValue(comSec, "<a href=", "/>");
				String comName = U.getSectionValue(comSec, "/>", "</a></div>").trim();
				String latLngSec = U.getSectionValue(sec, comName+"\",\"", "\",\"http");
				
				addDetails(comSec,comUrl,comName, latLngSec);
				//break;
			}
		}
		// driver.close();
		LOGGER.DisposeLogger();
	}

	//TODO : Extract Communities details here
	private void addDetails(String comSec, String comUrl,String comName, String latLngSec) throws Exception {

		//if (j == 6 )
		{
//			if(!comUrl.contains("https://westport-home.com/communities/the-overlook-at-white-river"))return;
			U.log(j + "== PAGE " + comUrl +"\t"+comName);

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("return===>" + comUrl);
				duplicates++;
				return;
			}
			LOGGER.countOfCommunity(i);
			String comHtml = U.getHTML(comUrl);
			
			//------format comname
			comName = comName.replaceAll(" - Lifestyle Paired Patio Homes| - Patio Homes", "");
			
			
			//------Please check community latlng with model home latlng then only consider model address for community address and geo- false
			//-----_Address---
			String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
			//------latLng-------
			String comlatLng [] ={ALLOW_BLANK,ALLOW_BLANK};
			comlatLng = latLngSec.split("\",\"");
			U.log("Community latLng : " +Arrays.toString(comlatLng));
			
			//---Model Home Latlng
			String modellatLng [] ={null,null};
			String modelLatLngSec = U.getSectionValue(comHtml, "var modellat = {", ";");
			if(modelLatLngSec!=null){
				modellatLng[0] = U.getSectionValue(modelLatLngSec, "lat: ", ",");
				modellatLng[1] = U.getSectionValue(modelLatLngSec, "lng: ", "}");
			}
			U.log("Model latLng : " +Arrays.toString(modellatLng));
			
			
			if(modellatLng[0]!=null){
			if((comlatLng[0].substring(0, 5)).matches(modellatLng[0].substring(0, 5))){//match 8 digit of both latlng values
				String addSec = Util.match(comHtml, "<a href=\"https://www.google.com/maps/place/(.*?)/@",1);
				
				if(addSec==null){
					addSec = U.getSectionValue(comHtml, "<address><p>", "</address>");		
				}
				
				U.log("model address : "+addSec);
				if(addSec!=null){
					addSec = addSec.replace("+", " ").replaceAll("<br />", ",").replace(", USA", "").replaceAll("^[a-zA-Z ]+</p>\\s*<p>", "").replaceAll("</p>\\s*<p>&nbsp;</p>", "")
							.replaceAll("<p>The brand new.*?!!!</p>", "");
					addSec = U.getNoHtml(addSec);
					add = U.getAddress(addSec);
					geo="FALSE";
				}
			}
			else{
				add = U.getAddressGoogleApi(comlatLng);
				geo = "TRUE";
			}
			}
			else{
				add = U.getAddressGoogleApi(comlatLng);
				geo = "TRUE";
			}
			
			
			if(add[0].length()<4 && comlatLng[0].length()>4){
				add = U.getAddressGoogleApi(comlatLng);
				geo = "TRUE";
			}
			U.log("add : " +Arrays.toString(add));
			
			
			//----------All floor and move-in data------------
			String allHomesData = ALLOW_BLANK;
			ArrayList<String> homeUrls = Util.matchAll(comHtml, "<a href=\"(.*?)\"\\s*class=\"comm-detail-img col-lg-4 col-sm-6\">", 1);
			for(String homeUrl : homeUrls){
				U.log("homeUrl : "+homeUrl);
				String homeHtml = U.getHTML(homeUrl);
				allHomesData +=U.getSectionValue(homeHtml, " <div class=\"col-sm-12 info-home text-center\">", "<h2 class=\"text-center\">You May Also Like:");
			}
			//---------prices--------
			String minPrice = ALLOW_BLANK, maxPrice  = ALLOW_BLANK;
			comHtml = comHtml.replaceAll("0\\s*s</h3>|0’s", "0,000</h3>");
			String prices[] = U.getPrices(comSec+comHtml, "\\$\\d{3},\\d{3}", 0);
			minPrice = (prices[0]==null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
			U.log(minPrice+"\t"+maxPrice);
			
			//--------sqft-----------
			String minSqft = ALLOW_BLANK, maxSqft  = ALLOW_BLANK;
			comHtml = comHtml.replace("0s</h3>", "0,000</h3>");
			String sqft[] = U.getSqareFeet(comSec+comHtml, "\\d{4} Sq ft – \\d{4}\\+ Sq ft|\\d{4} sq ft|\\d{4}\\s*sq ft", 0);
			minSqft = (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
			U.log(minSqft+"\t"+maxSqft);
			
			//-------comType-----
			String comType = ALLOW_BLANK;
			comType = U.getCommunityType(comHtml+comSec);
			
			//---PropType---------
			String propType = ALLOW_BLANK;
			propType = U.getPropType(comHtml+comSec+allHomesData);
			
			//----dType--------
			String dType = ALLOW_BLANK;
			dType = U.getdCommType((comHtml+comSec+allHomesData).replaceAll("floor", ""));
			
			//----propStatus-----
			comHtml  = comHtml.replace("NOW SELLING – NEW SECTION", "NOW SELLING NEW SECTION").replace("NOW SELLING &#8211; ", "NOW SELLING ")
					.replaceAll("VIP and Grand Opening details|choose your move-in ready home|Model-Now Open", "");
			String propStatus = U.getPropStatus(comHtml+comSec);
			
			if(comHtml.contains("<a href=\"https://westport-home.com/properties")){
				if(propStatus.length()>4)
				propStatus = propStatus + ", Move-in Ready";
				else
					propStatus = "Move-in Ready";
			}
			
			
			U.log("community name>>>> "+comName);
			comName=comName.replace("- Lifestyle Paired Patio Homes", "");
			data.addCommunity(comName, comUrl, comType);
			data.addLatitudeLongitude(comlatLng[0].trim(), comlatLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].toLowerCase().trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(U.getnote(comHtml));
		}
		j++;

	}

	

}
