package com.shatam.b_141_160;

import java.io.*;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class EastbrookHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int k=0;
	WebDriver driver = null;

	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		AbstractScrapper a = new EastbrookHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Eastbrook Homes.csv", a.data().printAll());
	}

	public static String homeUrl = "https://www.eastbrookhomes.com";

	public EastbrookHomes() throws Exception {
		super("Eastbrook Homes", homeUrl + "/");
		LOGGER = new CommunityLogger("Eastbrook Homes");
	}

	int count = 0, a = 0, b = 0, CHK = 0;

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		
		String html = U.getPageSource("https://eastbrookhomes.com/community-map/");
//		String [] regionSec = U.getValues(html, "<a class=\"et_pb_button", "</a>");
//		for(String regSec : regionSec){
//			String regUrl = U.getSectionValue(regSec, "href=\"", "\"").replace("amp;", "");
//			if(regUrl.contains("/community-map/") || regUrl.contains("/our-covid-19-response/"))continue;
//			U.log("RegUrl ===="+regUrl);
//			String regHtml = U.getPageSource(regUrl);
			String [] commSections = U.getValues(html, "\"geometry\": {", "\"communityid\":"); //"class=\"flyout-trigger-id");
			U.log(commSections.length);
			for(String commSec : commSections){
				String commUrl = U.getSectionValue(commSec, "\"communityLink\": \"", "\",");
//				U.log("========="+commUrl);
				findCommunityDetails(commUrl,commSec);
				count++;
//			}
		}
		U.log("Count Community---->"+count);

		LOGGER.DisposeLogger();
		//driver.close();
		try{
//			driver.quit();
		}catch(Exception e){}
	}
	int i = 0;
	public void findCommunityDetails(String commUrl,String commSec)throws Exception{
	//TODO : For Single Community Execution
//	if( i >= 20)
//		try{
		{

//			if (!commUrl.contains("https://eastbrookhomes.com/community/college-fields/")) return;			
			U.log("count== "+i );
//			U.log("commSec===="+commSec);
			U.log("=="+commUrl);
			
			
			String html = U.getHTML(commUrl);
			
			String note =ALLOW_BLANK;
			note=U.getnote(html);
			if (data().communityUrlExists(commUrl)) {
				LOGGER.AddCommunityUrl(commUrl + "==========>Repeated");
				return;
			}
			
			//=========== Community Name ==================
			String commName = U.getSectionValue(commSec, "\"title\": \"", "\",");
//			commName=commName.replace("�s", "'s").replace("Condominiums", "");
//			commName=commName.replace("�", "'").replace("Condominiums", "");
			commName=commName.replace("The Villas at Spring Lake CC", "The Villas at Spring Lake");
			U.log("CommName:::"+commName);
			
			//=============Address =============
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "False";
			String latLong [] = {ALLOW_BLANK,ALLOW_BLANK};
			String addsec=ALLOW_BLANK;
			if(html.contains("<span class=\"ihf-grid-result-address\">") && commUrl.contains("/community/the-preserve/")){
				addsec=U.getSectionValue(html, "<span class=\"ihf-grid-result-address\">", "</span>");
				add=U.findAddress(addsec.toLowerCase());
			}	
			
			U.log("addsec: "+addsec);
			String latlngSec=U.getSectionValue(html, "<ul class=\"community__introButtons\">", "Directions</a></li>");
//			latLong[1] = U.getSectionValue(latlngSec, "[", ",");
//			latLong[0] = U.getSectionValue(latlngSec, ",", "]");
			
//			if(latLong[0]==null) {
//				String latlSec=U.getSectionValue(commSec, "coordinates\":", "]");
				latLong[0] = Util.match(latlngSec, "\\d{2,3}\\.\\d+");
				latLong[1] = Util.match(latlngSec, "-\\d{2,3}\\.\\d+");
//			}
			U.log("latlong=="+latLong.length+Arrays.toString(latLong));
			if(addsec==ALLOW_BLANK) {
				addsec=U.getSectionValue(html, "<p>Clubhouse Address:", "<");
				U.log("addsec: "+addsec);
			if(addsec!=null)
				add=U.findAddress(addsec.toLowerCase());
				
			}	
			U.log("add[0]="+add[0]);
			
			if((add[0].length()==0||(add[0]==ALLOW_BLANK&&add[1]!=ALLOW_BLANK)) && (latLong.length==2&&latLong[0]!=null)) {
				add=U.getAddressGoogleApi(latLong);
				
//				note="Address taken from city and state";
				geo = "TRUE";
			}
			if((add[3]==null||add[3]==ALLOW_BLANK) && (latLong.length==2&&latLong[0]!=null)) {
				add=U.getAddressGoogleApi(latLong);
				
//				note="Address taken from city and state";
				geo = "TRUE";
			}
				
			
			U.log(Arrays.toString(add));
			if(add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && latLong[0]==null) {
				add[1]=U.getSectionValue(html, "<strong>City: ", "<");
				add[2]="MI";
				latLong=U.getGoogleLatLngWithKey(add);
				add=U.getAddressGoogleApi(latLong);
				geo = "TRUE";
				note="Address taken from city and state";
				
			}
//			if ((latLong.length<2 ||latLong[0]== ALLOW_BLANK||latLong[0]==null ) && add[3].length()>3) {
//				U.log("hello in here");
//				latLong = U.getlatlongGoogleApi(add);
//				if (latLong==null) {
//					latLong = U.getGoogleLatLngWithKey(add);
//				}
//				geo = "TRUE";
//			}
			
			//========== LatLng =============
//			String latLong [] = {ALLOW_BLANK,ALLOW_BLANK};
			
			
			
			if (commUrl.contains("https://eastbrookhomes.com/community/rockford-highlands/")) {
				
				latLong[0] = "43.1212459";
				latLong[1] = "-85.5828343";
			}
			
			U.log("latLong : "+Arrays.toString(latLong));
			
			
			if(latLong[0] ==null ){
				String address = getHardcodedAddress(commUrl);
				U.log("address==="+address);
				if(address != null){
					add = address.split(",");
					U.log(Arrays.toString(add));
				}
			}
			else{
				if(add[0].length()<=1) {
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				geo="TRUE";
			}
			}
					
			if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK && latLong[0]==null){
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				geo = "True";
			}

			/*// community Url redirected to another url
			if(commUrl.contains("https://eastbrookhomes.com/community/tannery-bay/"))
				commUrl = "http://tannerybay.com/";*/
			//=========== Tannery Bay community================
			String aboutPage = ALLOW_BLANK;
			String availableHomePage = ALLOW_BLANK;
			String homePlanHtml = ALLOW_BLANK;
					
			if(commUrl.contains("http://tannerybay.com/")){
				aboutPage = U.getPageSource("http://tannerybay.com/about/the-community");
				homePlanHtml = U.getPageSource("http://tannerybay.com/home-plans");
				availableHomePage = U.getHtmlHeadlessFirefox("http://tannerybay.com/available-homes",driver);
			}
			//==========Available Homes==============
			
			int q=0;
			
			String[] availUrl= U.getValues(html, "<img class=\"listing__listImg\"", ">View Details");
			for(String url:availUrl) {
				String homeDataurl=U.getSectionValue(url, "<div class=\"listing__listCta\">\n" + 
						"						<a href=\"", "\"");
				U.log("\navailUrl===="+homeDataurl);
				String availHtm = U.getHTML(homeDataurl);
				if(!availHtm.contains("Estimated Move In Date")) {
					q++;
				}
//				String availSec = U.getSectionValue(availHtm, "<div id=\"listing-description\"", "<div id=\"listing-gallery\"> ");
				availableHomePage+=availHtm+"\n"; 
			}
		//	U.log(availableHomePage);
			//=========== Home Plan ==================
			String combinedHomePlanHtml = null;
			
			String homePlanSec = U.getSectionValue(html, "Looking To Build", "Get In Touch");
//			U.log("homePlanSec : "+homePlanSec);
			if(homePlanSec == null)
				homePlanSec  =U.getSectionValue(html, "et_pb_section et_pb_section_5 et_section_regular", "Get In Touch");
			if(homePlanSec == null)
				homePlanSec  =U.getSectionValue(html, "t_pb_module et_pb_text et_pb_text_5 et_pb_bg_layout_light", "floor-plan-options");
			if(homePlanSec != null){
				String [] homePlanUrls = U.getValues(homePlanSec, "href=\"", "\"");
				U.log("Home Plan="+homePlanUrls.length);
				int x = 0;
				HashSet<String> listHome = new HashSet<>();
				for(String homePlanUrl : homePlanUrls){
					if(homePlanUrl.contains("eastbrook-home-plans/")|| homePlanUrl.contains("start-dreaming-of-summer-at-tannery-bay")
							|| homePlanUrl.contains("tannery-bay-q-and-a-with-don-and-kim")|| homePlanUrl.contains("sales-team/bob-dykstra/")|| homePlanUrl.contains("my-home-login"))continue;
					if(homePlanUrl.contains("ihomefinder"))continue;
					if(homePlanUrl.contains("#"))continue;
					if(homePlanUrl.isEmpty())continue;
					
					if(listHome.contains(homePlanUrl))continue;
					listHome.add(homePlanUrl);
//					U.log("homePlanUrl : "+i+"\t"+homePlanUrl);
					
					String homehtml= U.getPageSource(homePlanUrl);
					
					combinedHomePlanHtml+=U.getSectionValue(homehtml, "<div class=\"entry-content\">", "<div id=\"3dtours\"");
					
					
					
					/*if(x==5)break;
					x++;*/
				}
			}

			
			
		//	==================Plan Html=============================
			
			String[] planUrlSec=U.getValues(html, "<a class=\"related__button button\" href=\"", "\">View Home Plan</a>");	
			String planHtml="";
			
			for(String planurl : planUrlSec) {
				planHtml+=U.getHTML(planurl);
			}
			
			
			
			//============== Sqft =====================
			
			planHtml=planHtml.replace("</span><span class=\"listing__statLabel\">SQFT", " SQFT");
			
			if(combinedHomePlanHtml!=null)
			combinedHomePlanHtml=combinedHomePlanHtml.replaceAll("1st Floor|Floors: 1"," 1 Story ").replace("Floors: 2", " 2 Story ");
			html=html.replaceAll("\\s*</b>\\s*<br/>\\s*SqFt", " SQFT").replaceAll("</span>\\s*<span class=\"listing__statLabel\">Square Feet", " Square Feet");
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet((planHtml+html+combinedHomePlanHtml+homePlanHtml+availableHomePage).replace("Interior Designers in our 4000 sq. ft ", "") ,"\\d{4} SQFT|<li class=\"sqft\">\\d{4}<span>|\\d,\\d{3} SQFT|>\\s*<p>\\s*\\d,\\d{3} sq. ft.|>\\s*<p>\\s*\\d{4} sq. ft.|<span class=\"left\">\\d{4} SQFT|\\d{4} Square Feet",0);
//							"sqf\">\\s+<p>\\s+\\d,\\d{3} sq. ft.\\s+</p>|\\d{4} to \\d{4} sq. ft|Square Footage: \\d,\\d{3}|\\d,\\d{3} Square Feet|\\d,\\d+</strong> <span>sf|\\d{4}SQFT|\\d,\\d+ SQFT|\\d,\\d+ Square Feet",	0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			//=========== Price ================//$200�s
			html = html.replace("<span class=\"currency-symbol\">&#36;</span>", "$").replace("&#8217;s", "'s").replace("the $280’s", "the $280,000").replace("0’s,", "0,000").replace("0's", "0,000").replace("0�s", "0,000");
			commSec=commSec.replaceAll("0's|0s|0S", "0,000");
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			//html=html.replaceAll("price\">\\d{3},\\d{3}", "price\">\\$\\d{3},\\d{3}");
			String[] price = U.getPrices(html+homePlanHtml+availableHomePage+commSec,
					"  <span class=\"listing-price\">\\s*\\d{3},\\d{3}\\s*</span>|listing-price\">\\d{3},\\d{3}|price\"> \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",	0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			//============ Community Type =============
			html=html.replace("golfing", "Golf Club");
			String commType = U.getCommunityType(html+aboutPage);
			
			//=========== Property Type =================
			html = html.replace("Detached Villa Condominiums", " detached villa")
					.replaceAll("listing-property-type\">MultiFamily</span>| <span class=\"listing-property-type\">\\s*MultiFamily\\s*</span>", "<li>Multi-Family</li>").replaceAll("Series:</strong> Detached|Detached</strong>", "Detached homes");
			
			String seriesTypes[] = U.getValues(html, "<strong>Series:", "</p>");
			
			String propType = U.getPropType((html.replaceAll("executive-style|an executive community|executive style community", "Executive-level living")+homePlanHtml+availableHomePage+combinedHomePlanHtml+seriesTypes+planHtml)
					.replace("contemporary villa", "contemporary  Villas</th")
					.replace("feature executive ", "Executive home office ")
					.replace("blend luxury into", "luxury homes").replaceAll("elevation options, which range from traditional to modern|mejs.chinese-traditional\":\"Chinese|\\(Traditional\\)\"|-CraftsmanSingleFamily|craftsman-square|Executive Homes</li></ul><p>Interested|Craftsman Square|CRAFTSMAN-SQUARE-DRIVE|cottage-lane|the-villas-at|The Villas at Spring Lake|-CraftsmanTNDPatioHomePlans-TownhomesSin|Cottage-Lane|Cottage Lane|Craftsman Square Drive|[c|C]raftsmanship|Custom|custom|(v|V)illage|No HOA Dues|SingleFamilyHomesCondominiums|CraftsmanTND",""));
			/*if(combinedHomePlanHtml!=null && combinedHomePlanHtml.contains("loft")) {
				if(propType.length()>2)
					propType=propType+", Loft";
				else propType="Loft";
			}*/
			
			
			propType = propType.replace("Townhouse, Townhome", "Townhome");
			
			if(propType.contains("Townhouse")&& propType.contains("Townhome"))propType = propType.replace(" Townhouse,", "");
			
			if(html.contains("Homeowner Association (HOA)") && !propType.contains("Homeowner")) {
				if(propType.length()>4) {
					propType+=", Homeowner Association";
				}
				else {
					propType="Homeowner Association";
				}
			}
			
			
//			U.log("mmm=="+Util.matchAll(seriesTypes, "[\\w\\s\\W]{30}villa[\\w\\s\\W]{30}", 0));

			
			U.log("propType: "+propType);
			
			//=========== Property Status ===============
//			U.log(commSec);
			html = html.replaceAll("<p>\\s+Only 2 Home Sites and", "Only 2 Home Sites Remaining").replace("Only 1 Home Site and 1 Showcase Home Remaining","Only 1 Home Site Remaining");
			commSec = commSec.replace("Only 1 Home &amp; 1 Home Site Remaining", "Only 1 Home Site Remaining").replace("New Condo Phase Coming Soon", "New Phase Coming Soon").replace("New Single Family Phase Coming Soon", "New Phase Coming Soon").replace("Condos Coming Soon", "").replace("New Single Family Phase is Selling Fast", "New Phase Selling Fast");
			html=html.replace("New Single Family Phase Coming Soon", "New Phase Coming Soon").replaceAll("New Single Family Phase is Selling Fast", "New Phase Selling Fast")
					.replace("Only 1 Home &amp; 1 Home Site Remaining", "Only 1 Home Site Remaining").replace("New Condo Phase Coming Soon", "New Phase Coming Soon").replaceAll("popular phase is SOLD OUT|Condos Coming Soon!|Condos Now Available|More Options Coming Soon|Grand Opening of our new Green Ash Homes", "").replaceAll("limited number of home sites available", " limited homesites available");
			html=html.replace("Only 3 Home Sites and 2 Showcase Homes remaining", "Only 3 Homesites remaining")
					.replace("Few Patio Home Sites Remaining!", "Few HomeSites Remaining!")
					.replace("Townhomes (Coming in Spring of 2022)", "Townhomes")
					.replace("Townhomes (SOLD OUT)</p>", "Townhomes");
			
//			String[] StatusSecs=U.getValues(regHtml, "<a class=\"eb-prev-title-a", "<div class=\"eb-column-4 eb-ft-info-btm fav in-content");
//			String regStatus=ALLOW_BLANK;
//			for(String statusSec:StatusSecs) {
//				if(statusSec.contains(commUrl)) {
//					regStatus=statusSec;
//				}
//			}

			
			
			
			String propStatus = U.getPropStatus((commSec+html)
					.replaceAll("NOW OPEN: Preservation Lakes", "")
					.replace("Only 5 Villa Home Sites Remaining!", "Only 5 homesites Remaning")
					.replaceAll("New Single Family Phase Now Open!|New Estates Phase Now Open!", "New Phase Now Open")
					.replace("New Condo Phase Coming Soon", "New Phase Coming Soon").replace("New Single Family Phase Coming Soon", "New Phase Coming Soon").replaceAll("Only 1 Home &amp; 1 Home Site Remaining|Only 1 Home & 1 Home Site Remaining", "Only 1 Home Site Remaining")
					.replaceAll("(SOLD OUT)</p>|Discover Wolven Ridge’s New Phase|Auburn offers two new phases|and our new Phase 4|The new phase offers home |next 3 homes sold|Virtual Grand Opening|Condos Now Available|Join us for our New Phase Grand Opening!|Closeout Special Incentive!|Join us for Grand Opening!", ""));
			
			propStatus=propStatus.replaceAll("Only 2�home Sites Remaining", "Only 2 Home Sites Remaining");
			propStatus=propStatus.replace("Only 1�home Sites Remaining", "Only 1 Home Sites Remaining");
//			if(commUrl.contains("community/trillium-ridge/"))propStatus="Grand Opening Coming Soon";
			if(commUrl.contains("community/placid-waters/"))propStatus="Waterfront Condos Available";
			propStatus=propStatus.replace("Selling Fast, New Phase", "New Phase Selling Fast!");
			
			String availbleHmSec=U.getSectionValue(html,"<section class=\"community__listings\">", "</section>");
				if(availbleHmSec==null)availbleHmSec=ALLOW_BLANK;
				
				U.log("count: "+q);
				if(q>0)
					if(propStatus!=null&&propStatus!=ALLOW_BLANK) {
						propStatus="Move In Homes, "+propStatus;
					}else {
						propStatus="Move In Homes";
					}
//				}
//			}
				U.log("propStatus: "+propStatus);
			//========== Derived Community Type ==============
			html=html
					.replace("1st Floor", "1 story")
					.replace("Floors: 2", "2 story").replaceAll(" Floors: 1", " Story 1 ");
		//	U.log(combinedHomePlanHtml);
			if(combinedHomePlanHtml!=null)
			combinedHomePlanHtml=combinedHomePlanHtml.replace("1st Floor", "1 story");
			if(planHtml!=null) {
			planHtml=planHtml.replace("1st Floor", "1 story")
					.replace("</span><span class=\"listing__statLabel\">Floor", " story ");
			planHtml=planHtml.replaceAll("</span><span class=\"listing__statLabel\">Floor", " Story");
			}
			String dType = U.getdCommType((planHtml+html+combinedHomePlanHtml+homePlanHtml+availableHomePage)
					.replace("</span><span class=\"listing__statLabel\">Floor", " story ")
					.replaceAll("Floors:\\s*</td>\\s*<td>\\s*2", "2 story").replaceAll("and multi-level Townhomes", ""));
//			.replaceAll("</span><span class=\"listing__statLabel\">Floor", " Story")

			
			
			U.log("dtype: "+dType);
			//========== Notes ==================
			
			if (commUrl.contains("https://eastbrookhomes.com/community/saddlebrook/")) propType = propType+", Villas";
			if(propStatus!=null)
			propStatus = propStatus.replaceAll("\\d Move-in Home,|\\d Move-in Home", "")
			.replace("New Phase Coming, New Townhome Phase Coming Soon", "New Townhome Phase Coming Soon").replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon")
			.replace("Limited Homesites, Limited Homesites Available", "Limited Homesites Available").replace("Coming Soon, Final Phase Coming Soon", "Final Phase Coming Soon");

			if (commUrl.contains("https://eastbrookhomes.com/community/preservation-lakes/"))
				propStatus = propStatus.replace(", Selling Fast", ", New Phase Selling Fast");
			
			if(html.contains("<div class=\"et_pb_text_inner\">Executive Final Phase!</div>"))
				if(!propStatus.contains("Final Phase"))
					if(propStatus == ALLOW_BLANK)
						propStatus = "Final Phase";
					else
						propStatus+= ", Final Phase";
			
			add[0]=add[0].replace("3RD Villa Ct", "3rd Villa Ct");
			add[1] = add[1].replaceAll("\\(.*\\)", "");
			commName=commName.replaceAll("\\s{2,}", "").replace("’s", "'s");
			
//			if (commUrl.contains("community/harvest-meadows/"))propStatus=propStatus+", New Phase";
			if(html.contains("New Phase at "+commName)||html.contains("New Phase at Cook's Crossing")) {
				if(propStatus.length()>0) {
					propStatus=propStatus+", New Phase";
				}
				else
					propStatus="New Phase";
			}
			String lotHtm = U.getPageSource("http://eastbrook.salessimplicity.net/topo?"+U.getSectionValue(html, "<a href=\"http://eastbrook.salessimplicity.net/topo?", "\"").replace("&#038;", "&"));
			int lotCount = Util.matchAll(lotHtm, "\"LotNum\":\"", 0).size();
			LOGGER.AddCommunityUrl(commUrl);
			data.addCommunity(commName, commUrl,commType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLong[0].trim(),latLong[1],geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf,maxSqf);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus.replaceAll("!", ""));
			data.addUnitCount(lotCount+"");
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addNotes(note);
		}
		i++;
		
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
	public static String getHardcodedAddress(String comUrl)throws Exception {
		comUrl = comUrl.trim();
		String newFile = U.getHardCodedPath()+"Hardcode_EastbrookHomes" + ".csv";
		//U.log("Suucess=============");
		CsvListReader newFileReader = new CsvListReader(new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {
			if (count > 0) {
				String aaa = getBuilderObj(newCsvRow,comUrl);
				if (aaa != null)
					return aaa;
			}
			count++;
		}
		newFileReader.close();
		return null;
	}
	public static String getBuilderObj(List<String> newCsvRow,String comUrl) {
		//U.log("Hello1");
		if (comUrl.contains(newCsvRow.get(4).trim())) {		
			return (newCsvRow.get(6) + "," + newCsvRow.get(7) + ","
					+ newCsvRow.get(8) + "," + newCsvRow.get(9) );
		}
		return null;
	}


	public static String getHardCodedPath(){
		String Regex="Harcoded Builders";
		String Filename=System.getProperty("user.home");
		if(Filename.contains("/")){
			Regex="/Harcoded Builders/";
		}
		else{
			Regex="\\Harcoded Builders\\";
		}
		Filename=Filename.concat(Regex);
		if(!Filename.equals(Regex))	{
			Regex=Regex.toLowerCase();
		}
		return Filename;
	}	
	
	public int checkURL(String my_url) throws Exception {
		URL urlT = new URL(my_url);
		HttpURLConnection http = (HttpURLConnection) urlT.openConnection();
		int statusCode = http.getResponseCode();
		//U.log(statusCode);
		return statusCode;
	}
}