/**
 * @author : Pallavi
 * @date : 21-2-2020
 */
package com.shatam.b_141_160;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
public class ExtractCenturyComplete extends AbstractScrapper {

	
	public int inr = 0,j=0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://centurycompletehomes.com";
	HashSet<String> communityUrls=new HashSet<String>();
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCenturyComplete();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Century Complete.csv", a.data().printAll());
    }
	public ExtractCenturyComplete() throws Exception {
		super("Century Complete", builderUrl);
		LOGGER = new CommunityLogger("Century Complete");
		// TODO Auto-generated constructor stub
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String html = U.getHTML(builderUrl);
		String section = U.getSectionValue(html, "var wadeMapData = [", "]");
		String stateUrls[] = U.getValues(section, "Link: \"", "\"");
		int comRegCount=0,comSecCityCount=0;
		for(String stateUrl:stateUrls){
			String statedata = U.getHTML(stateUrl);
			String [] subRegurls = U.getValues(statedata, "<h2 class=\"h2\"><a class=\"community-link\" href=\"", "\"");

			if(subRegurls.length==0) {
				subRegurls=U.getValues(statedata, "<h2 class=\"newHomesIn\"><a href=\"", "\"");
			}
//			U.log("Subregion length"+subRegurls.length);
			for(String subreg:subRegurls) {		
				//U.log(subreg);
				String subRegHtml = ALLOW_BLANK;
					if(!subreg.contains("http"))subreg=builderUrl+subreg; 
					U.log(subreg);
					if(subreg.contains("/new-homes/michigan/detriot"))subreg ="https://centurycompletehomes.com/new-homes/michigan/detriot/";

					subRegHtml=U.getHTML(subreg);
					String cityUrls[]=U.getValues(subRegHtml, "<h2 class=\"h2\"><a class=\"community-link\" href=\"", "\"");
					if(cityUrls.length==0) {
						cityUrls=U.getValues(subRegHtml, "<h2 class=\"newHomesIn\"><a href=\"", "\"");
					}
					for(String cityUrl:cityUrls) {
						U.log(cityUrl);
						if(!cityUrl.contains("http"))cityUrl=builderUrl+cityUrl; 
						String cityHtml=U.getHTML(cityUrl);
						//String[] comSecFromCity = U.getValues(cityHtml, "<div class=\"marker\" data-lat=\"", "View Community");
						String[] comSecFromCity = U.getValues(cityHtml, "<div class=\"community-list-item item\">", "View Community");
						if(comSecFromCity.length==0) {
							comSecFromCity=U.getValues(cityHtml, "<div class=\"community-search__item", "View Community");
						}
						//U.log(comSecFromCity.length);
						LOGGER.AddRegion(cityUrl, comSecFromCity.length);		
						comSecCityCount+=comSecFromCity.length;
						for(String comSec : comSecFromCity){
							String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
							if(comUrl == null)comUrl=U.getSectionValue(comSec, "community-search__title\" href=\"", "\"");
							communityUrls.add(comUrl);
							String comName = U.getSectionValue(comSec, "<h3 class=\"h3 title\">", "<");
							if(comName == null)comName=U.getSectionValue(comSec, "<a class=\"community-search__title\" href=\""+comUrl+"\">", "<");
							//U.log(comUrl+" ::: "+comName);
		//					String latlngSec = Util.match(cityHtml, "<div class=\"marker\"(.*?)\\s*<h3 class=\"marker-heading\">"+comName,1);
							//U.log("latlngSec : "+latlngSec);
		//					String comHtml = U.getHTML(comUrl);
		
							findCommunityDetails(comUrl,comName, comSec);
						}
						
					}//eof for
					}
		}
		LOGGER.DisposeLogger();

	}
	
	private void findCommunityDetails(String comUrl,String comName, String comSec)throws Exception{
		// TODO Auto-generated method stub

//	if(j >=150 && j<=200)
//	if(j >= 200)
		//https://centurycompletehomes.com/new-homes/texas/texas-southeast/conroe/crockett-reserve
	if(!comUrl.contains("https:"))comUrl=builderUrl+comUrl;

//	if(!comUrl.contains("https://centurycompletehomes.com/new-homes/indiana/indiana/new-castle/landmark"))return;
	{
		U.log(j+ " <===>"+comUrl);
		
		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
	
	
		String html = U.getHTML(comUrl);
		html=html.replaceAll("content=\".*\" />|\"promoprice\":\"\\$\\d{3},\\d{3}\\.\\d+\"|\"lot_price\":\"\\$\\d+,\\d+\\.\\d+|\"totalprice\":\"\\$\\d+,\\d+\\.\\d+\"", "");
		U.log(U.getCache(comUrl));
		//============ Community Name ==================
		if(comName != null)
			comName = comName.trim();
		if(comName==null)
			comName=U.getSectionValue(html, " <h1 class=\"search-results__title\">", "<");
		if(comName==null)
			comName=U.getSectionValue(html, " class=\"search-results__title\">", "</h1>");
		if(comName==null)
			comName=U.getSectionValue(html, "<h1>", "</h1>");
		
		comName = comName.replaceAll("& Cottages", "");
		U.log("comName =="+comName+"==========");
		
		html = U.removeSectionValue(html, "<footer>", "</footer>");
		//============= Address ======================
		String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] add1=null;
		String geo = "False";

		String addSection = U.getSectionValue(html, "<p class=\"search-results__address\">", "</span>");
		if(addSection == null)
			addSection = U.getSectionValue(html, "Community Address:", "</h5>");
		if(addSection == null)
			addSection = U.getSectionValue(html, "<address>", "</address>");
		
		//U.log("aaaaaaa"+addSection);
		if(addSection != null){
			addSection = addSection.replaceAll("<.*?>|Lot 1, ", "").replace("Texas", "TX").replace("Indiana", "IN").replace("Arizona", "AZ").replace("Alabama", "AL").replaceAll("Iowa", "IA").replace("South Carolina", "SC").replace("North Carolina", "NC").replace("Michigan", "MI").replace("Ohio", "OH").replace("Georgia", "GA").replace(", Suite", " Suite").replaceAll("Florida (\\d{5})", "FL $1")
					.replaceAll("Conroe TX|Brooksville FL|Casa Grande AZ|Located in Newcastle|Locted In|Newport MI|Located in Tipton IN|Located in New Castle IN|Located in Cherryville NC|Located in Salisbury|Located in Grand Blanc MI|LOCATED IN|Located In:|Located In|Studio InformationStudio: GreenvillePhone Number: 864-509-9195Address:| \\(Mile 6 N\\)", "");
			U.log(addSection);
			add1=addSection.split(",");
			U.log(Arrays.toString(add1)+"this is address");
			if(add1.length>2)
			{
				//---Street----
				add[0]=add1[0].trim();
				U.log(add1.length);
				
				//---State-
				add[2]=Util.match(add1[2].trim(), "\\w+").trim();
				
				if(!add1[1].trim().equals(add1[2].trim()))
					add[1]=add1[1].trim();
				else
					add[1]=ALLOW_BLANK;
				
				//-----Zip----
				U.log("KKKKKKK "+add1[2]+" ::::::::::::");
				if(add1.length>3) {
					add1[3]=add1[3].replaceAll("USA", "");
				if(add[2] !=null && add1[3].length()<4) 
					add[3]=Util.match(add1[2], add[2]+"\\s*(\\d{5})",1);
				else if (add[3].length()<3) 
					add[3]=add1[3];
				else
					add[3]=ALLOW_BLANK;
				}

				add[3]=Util.match(addSection.replace(add[0], ""), "\\d{5}");
				
			}
		}
		if(add[2].length()>2)
			add[2]=USStates.abbr(add1[2]);
		if(comUrl.contains("north-carolina/charlotte/salisbury/greystone-village")) {
			addSection = U.getSectionValue(html, "<p><em><strong>Model Home ", "</strong></em></p>");
			U.log(addSection+":::new addsection");
			add= U.getAddress(addSection.replace("&ndash; ", ""));
		}

		U.log("Add :::"+Arrays.toString(add));
		add[0] = add[0].replace("Located in Wickenburg AZ", "");
		add[0] = add[0].replace("Located in Citrus Springs FL", "");
		add[0] = add[0].replace("Des Moines", "");
		//
		//
		//================ LatLng ===================
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String latLngSec = U.getSectionValue(html, "https://www.google.com/maps", "z/data");
		if(latLngSec != null){
			latLngSec = latLngSec.replaceAll("@|/", "");
			String vals[] = latLngSec.split(",");
			latLng[0] = vals[0];
			latLng[1] = vals[1];
			U.log("LatLng1 ==="+Arrays.toString(latLng));
		}
		
		if(latLng[0]==ALLOW_BLANK){
			latLng[0] =U.getSectionValue(comSec, "data-lat=\"", "\"");
			latLng[1] =U.getSectionValue(comSec, "data-lng=\"", "\"");
			U.log("LatLng2 ==="+Arrays.toString(latLng));
		}
		if(latLng[0]==null || latLng[0]==ALLOW_BLANK){
			latLng[0] =U.getSectionValue(html, "\"latitude\":\"", "\"");
			latLng[1] =U.getSectionValue(html, "\"longitude\":\"", "\"");
			if(latLng[1]!=null)latLng[1] = latLng[1].replace(",", "."); 
			U.log("LatLng3 ==="+Arrays.toString(latLng));
		}
		if(latLng[0]==null || latLng[0]==ALLOW_BLANK){
			latLng[0] =U.getSectionValue(html, "var baseLat = ", ";");
			latLng[1] =U.getSectionValue(html, "var baseLon = ", ";");
			if(latLng[1]!=null)latLng[1] = latLng[1].replace(",", ".");
			U.log("LatLng3 ==="+Arrays.toString(latLng));
		}
		if(comUrl.contains("/powers-court/")){
			add[2]="GA";
			geo="True";
		}
		if(comUrl.contains("/lexington/")){
			add[0]=ALLOW_BLANK;
			add[1]="Phenix City";
			add[2]="AL";
			add[3]="36869";
		}
		if(comUrl.contains("/country-club-hills/")){
			add[0]="Pine Needles Drive";
			add[1]="Winson-Salem";
			add[2]=ALLOW_BLANK;
			add[3]=ALLOW_BLANK;
		}if(comUrl.contains("/minas-place/"))
			add[2]="NC";
		if(comUrl.contains("/judson-mills-village/")){add[0]=ALLOW_BLANK;add[1]="Judson Mills Village";add[2]="SC";add[3]=ALLOW_BLANK;}
		if(comUrl.contains("/yorktown-meadows-coming-soon") || comUrl.contains("/emerald-pointe/")) {
			String ad[]={"-","Muncie","IN","-"};
			latLng=U.getlatlongGoogleApi(ad);
			if(latLng == null) latLng = U.getlatlongHereApi(ad);
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo="TRUE";
		}


		//============ Home Studio to Find LatLng & Address ============
		if(latLng[0] == ALLOW_BLANK){
			String homeStudioSec = U.getSectionValue(html, "et_pb_button_module_wrapper et_pb_module\">", "</a>");
			if(homeStudioSec != null){
				U.log(homeStudioSec);
				String studioUrl = U.getSectionValue(homeStudioSec, "href=\"", "\"");
				U.log("Studio Url=="+builderUrl+studioUrl);
				String studioHome = null;
				if(!studioUrl.startsWith("http"))
					studioHome = U.getHTML(builderUrl+studioUrl);
				else
					studioHome = U.getHTML(studioUrl);
				String latLngSec1 = U.getSectionValue(studioHome, "wjInitMap()", "</script>");
				if(latLngSec1 != null){
					latLng[0] = U.getSectionValue(latLngSec1, "lat:", ",");
					latLng[1] = U.getSectionValue(latLngSec1, "lng:", "};");
				}
				if(latLng[0] != null) latLng[0] = latLng[0].trim();
				else latLng[0] = ALLOW_BLANK;
				if(latLng[1] != null) latLng[1] = latLng[1].trim();
				else latLng[1] = ALLOW_BLANK;
				
				/*
				 * Compare address from studio page and main page. If they are same then we will take latlng from studio page.
				 * If not then we will find latlng from googleapis.
				 */
				String addrs[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String addSec = U.getSectionValue(studioHome, "Address:</strong>", "<p><strong>");
				U.log("AddSec From Studio==="+addSec);
				if(addSec != null){
					addSec = addSec.replace(", Unit", " Unit").replace(", Suite", " Suite");
					addrs = U.getAddress(addSec);
					if(!add[0].contains(addrs[0])){
						try{
							latLng = U.getlatlongGoogleApi(add);
							
						}catch (Exception e) {
							latLng = U.getBingLatLong(add);
						}
						geo = "True";
					}
				}
				U.log("Add From Studio=="+Arrays.toString(addrs));
			}
			
			if(latLng[1]!=null)latLng[1] = latLng[1].replace(",", ".");
			U.log("LatLng3 ==="+Arrays.toString(latLng));
		}
		String Note=ALLOW_BLANK;
		if(comUrl.contains("https://www.wadejurneyhomes.com/community/hopewell-heights-coming-soon/")) {
			add[0]="";
			add[1]="Chillicothe";
			add[2]="OH";
			add[3]="";
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			String add2[] = U.getAddressGoogleApi(latLng);
			if(add2 == null) add2 = U.getGoogleAddressWithKey(latLng);
			if(add2 == null) add2 = U.getAddressHereApi(latLng);
			add[0]= add2[0];
			add[3]=add2[3];
			geo = "True";
			Note="Address taken from city and state";
		}
		
		if(comUrl.contains("new-homes/indiana/indiana/marion/villas-of-fox-run")) {
			add[0]="";
			add[1]="Marion";
			add[2]="Indiana";
			add[3]="46952";
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			String add2[] = U.getAddressGoogleApi(latLng);
			if(add2 == null) add2 = U.getGoogleAddressWithKey(latLng);
			if(add2 == null) add2 = U.getAddressHereApi(latLng);
			add[0]= add2[0];
			add[3]=add2[3];
			geo = "True";
		}
		
		if(latLng[0]==null|| latLng[0].length()<3) {latLng[0]=ALLOW_BLANK;latLng[1]=ALLOW_BLANK;}
		
		if(latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK || latLng[0]==null  ){
			if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK){
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				geo = "True";
			}
		}
		

		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK  || add[3]==null){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getGoogleAddressWithKey(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "True";
			}
		}
	

		if(add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){

				String add2[] = U.getAddressGoogleApi(latLng);
				if(add2 == null) add2 = U.getGoogleAddressWithKey(latLng);
				if(add2 == null) add2 = U.getAddressHereApi(latLng);
				
				add[0] = add2[0];
				geo = "True";
			}
		}
		if(add[0] != ALLOW_BLANK && (add[3] == ALLOW_BLANK || add[3].trim().length()<3)){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getGoogleAddressWithKey(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "True";
			}
		}
		if(add[2]==null && latLng[0]!=ALLOW_BLANK){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "True";
		}
		
		if(add[0].length()<3 && latLng[0]!=ALLOW_BLANK){
			U.log("======"+Arrays.toString(add));

			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			if(add == null || add[0].contains("Unnamed Road")) add = U.getAddressHereApi(latLng);
			geo = "True";
		}
//		if(add1[2]==null && latLng[0]!=ALLOW_BLANK){
//			add = U.getAddressGoogleApi(latLng);
//			geo = "True";
//		}
		if(comUrl.contains("https://www.wadejurneyhomes.com/community/poinciana-village/")) {
			add[0]="Saint Tropez Court";
			add[1]="Poinciana";
			add[2]="FL";
			add[3]="";
			latLng=U.getlatlongGoogleApi(add);
			if(latLng ==  null) latLng = U.getlatlongHereApi(add);
			String add2[] = U.getAddressGoogleApi(latLng);
			if(add2 == null) add2 = U.getGoogleAddressWithKey(latLng);
			if(add2 == null) add2 = U.getAddressHereApi(latLng);
			add[3]=add2[3];
			geo = "True";
			//Note="Address taken from city and state";
		}
		if(comUrl.contains("/community/maplewood/"))add[0]="118 Yellow Pine Drive";
		U.log("Add :::"+Arrays.toString(add));
		String paginationSec=U.getSectionValue(html, "<ul class='bx_pagination'>", "</div>");
//		U.log(paginationSec);
		if (paginationSec!=null&&paginationSec.contains("class='' href='")) {
			U.log(builderUrl+U.getSectionValue(paginationSec, "class='' href='", "'"));
			String tempHtml=U.getHTML(builderUrl+U.getSectionValue(paginationSec, "class='' href='", "'"));
			html+=tempHtml;
		}
		//============ Home Available Section ============
//		String homeSection = U.getSectionValue(html, "<div class=\"bx_plans row moveinready\">", "<h4>Community Details</h4");
		
		//U.log("homeSec"+homeSection);
		//============== Homes Html =======================
		String combineHomeHtmls = ALLOW_BLANK;
		int homeAvailableCnt = 0;
//		if(homeSection != null){
			String [] homeUrls = U.getValues(html, "<div class=\"item lot-item\">", "<div class=\"list-button\">");
			U.log("Home count=="+homeUrls.length);
			if(homeUrls.length == 0) {
				homeUrls = U.getValues(html, "<figure class=\"bx_listing_fig\">", "<a id=\"appointment\" ");
			}
			homeAvailableCnt = homeUrls.length;
			int x = 0;
			for(String homeUrl : homeUrls){
				if(homeUrl.contains("btn-appointment"))homeUrl = U.getSectionValue(homeUrl,"<a class=\"btn btn-appointment\" href=\"","\"");
				else homeUrl = U.getSectionValue(homeUrl,"<a href=\"","\"");
				U.log("homeUrl="+homeUrl);
				String homeHtml = ALLOW_BLANK;
				if(!homeUrl.contains("https"))homeUrl=builderUrl+homeUrl;
				homeHtml=U.getHTML(homeUrl);
				if(homeHtml!=null) {
				combineHomeHtmls += homeHtml;//U.getSectionValue(homeHtml, "id=\"IDX-detailsHead\">", "<div id=\"IDX-description\">"); //"<div id=\"IDX-BankRateTool");
					if (homeHtml.contains("Traditional")) {
						U.log("Found");
					}
				}
				if(x == 6)break;
				x++;
			}
//			U.log(combineHomeHtmls);
//		}
		//=========== Price =============
		html=html.replaceAll("<br>Lot Size:*?<br>", "");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replaceAll("Financing example is based on a sales price of \\$\\d{3},\\d{3}|loan in the amount of \\$\\d{2},\\d{3}|\\$\\d{2},\\d{3}", "").replace("'s", ",000").replace("0’s", "0,000").replace("0s", "0,000").replaceAll("&#39;s|'s|0s", "0,000")
				.replaceAll("\\$(\\d+,)?\\d+/mo <span>Payment", "").replaceAll("<li class=\"price\">\n*\\s*\n*\\s*Or", "<li class=\"price\">Or");
		comSec = comSec.replaceAll("&#39;s|'s|0s", "0,000").replace("in the 100s", "in the $100,000");
//		U.log(combineHomeHtmls);
		String price[] = U.getPrices((html.replace("\"totalprice\":\"$162,990.00\",\"", "")+comSec+combineHomeHtmls).replaceAll("Promo Price:\\$\\d{2},\\d{3}\\.\\d+", ""), 
				"the \\$\\d{3},\\d{3}|<li class=\"price\">Or \\$\\d{3},\\d{3}|class=\"price\">Or \\$\\d{3},\\d{3}|showcasePrice\">\\$\\d{3},\\d{3}|homes start from \\$\\d{3},\\d{3}|Starting at \\$\\d{2,3},\\d{3}|<h5 class=\"price-sm\">\\$\\d{2,3},\\d{3}|the low \\d{3},\\d{3}|Starting from \\$\\d{3},\\d{3}|Promo Price :</b> \\$\\d{2,3},\\d{3}.00|the \\$\\d{3},\\d{3}|Starting from \\$\\d{2,3},\\d{3}|IDX-detailsPrice\">\\$\\d{2,3},\\d{3}|IDX-showcasePrice\">\\s+\\$\\d{3},\\d{3}|Total Price:</b>\\s+\\$\\d{2,3},\\d{3}|totalprice\":\"\\$\\d{3},\\d{3}|(the mid|in the) \\$\\d{3},\\d{3}|Starting at \\d{6}|Total Price:\\s*\\$\\d{2,3},\\d{3}\\.\\d+ |<li class=\"price\">\\s*Or \\$\\d{2},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice:" + minPrice + " MaxPrice:" + maxPrice);

		
		
		//=========== Sqft =====================
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
	
//		U.log(comSec);
		combineHomeHtmls=combineHomeHtmls.replaceAll("</span> <span class=\"IDX-fieldLabel\">", " ");
		html= html.replace("<small><strong>sqft", " sqft").replaceAll("option-detail\">\\d+</span>", "");
		comSec = comSec.replace("<small><strong>sq ft", " sq ft").replace("</strong></small>", "");
//		U.log(comSec);
		String[] sqft = U.getSqareFeet(combineHomeHtmls+html+comSec,
				"\\d{4} sq. ft. to \\d{4} sq. ft. |\\d{3,4} – \\d{3,4} square feet|\\d{4} to \\d{4} square feet|\\d{4} square foot to \\d{4} square foot|homes are between \\d{4} and \\d{4} square feet|square footage of \\d{4} to \\d{4}|lotsize\">\\d,\\d{3}sqft - \\d,\\d{3}sqft|from \\d{4} to \\d{4} square feet|/i> \\d,\\d{3} sqft</span>|size from \\d{4}-\\d{4} square feet|ranging from \\d{4} to \\d{4} square feet|homes are between \\d{4}-\\d{4} square feet|homes range from \\d{3,4}-\\d{3,4} square feet|search__size\">\\d{4}-\\d{4}|\\d{3} or \\d{3} square feet|\\d{4} – \\d{4} sq ft|community-search__size\">\\d{3,4}-\\d{3,4}</span>|<span class=\"option-detail\">\\d{3,4}</span>\\s+<span class=\"option-title\">sqft</span>|search__size\">\\d{3,4} sq. ft.</span>|community-search__size\">\\d{3,4} sq ft</span>|to over \\d,\\d{3} square feet|\\d{3,4}-\\d{4} sq ft|\\d{3,4}–\\d{3,4} sq ft|\\d,\\d+-\\d,\\d+ sq ft|SQFT:</span>\\s+<span class=\"option-detail\">\\d{3,4}<|IDX-fieldData\">\\d,\\d{3}|square footage ranging from \\d{3,4}+ to \\d{3,4}|\\d,\\d{3} sq ft - \\d,\\d{3} sq ft|from \\d{4} - \\d{4}|than \\d,\\d{3} square feet|ranging from \\d,?\\d{3}-\\d,?\\d{3} square feet|Square feet: \\d{4}\\s?(–|-)\\s?\\d{4}|DX-fieldData\">\\d,\\d{3}</span>|Lot SqFt:</strong>\\s+<span class=\"IDX-fieldData\">\\s+\\d{4,}|\\d{4}\\+ sq ft|\\d{4}\\s?(–|-)\\s?\\d{4} sq. ft.|\\d{4}\\s?-\\s?\\d{4} sq(.)? ft(.)?|<p> \\d{4} – \\d{4} sq ft </p>|<p> \\d{4}\\+ sq </p>|<p> \\d{4}-\\d{4} </p>|option-detail\">\\d{4}</span>|search__size\">\\d{4} sq ft|<p> \\d{4} </p>|up to \\d{4} sq|\\d,\\d{3} sqft"
				, 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
//		U.log(Util.matchAll(combineHomeHtmls+html+comSec, "[\\s\\w\\W]{30}71[\\s\\w\\W]{30}", 0));
		//================ Community Type =============
		String comDetailSection = U.getSectionValue(html, "Details</h3>", "</h3>");
		String comType = U.getCommType((comDetailSection+html).replaceAll("golf at one of the near|Copperhead Golf Course|rom miniature golf|Lake community|lake community|Lake Community in Jones ", "").replace("Lake community in the vibrant", ""));
		
		//=================== Property Type =============
			combineHomeHtmls = combineHomeHtmls.replace("<div class=\"image-title\">Craftsman", "Craftsman style details").replaceAll("Area Maintenance|(F|f)loor|FLOOR|(v|V)illage", "");
		
		String remSec = U.getSectionValue(html, "<h2>Nearby Communities", "<div class=\"footer");
		if(remSec != null)
			html = html.replace(remSec, "");
		
		html = html.replaceAll("(v|V)illage|Vistanna Villa", "");
		String pType = U.getPropType((combineHomeHtmls+html).replaceAll("featuring new duplex homes for sale|Traditional Plans and Cottages - Plan|Duplex for Sale in Punta|<span class=\"BX_lot-fieldData\">Traditional Plans</span>|content=\".*\"|single family home in Flin|single-family homes in Lapeer|Villa Rica|villa-rica|no HOA fees|HOA assessments are additional", ""));

		if(pType.contains("Townhouse") && (pType.contains("Townhomes") || pType.contains("Townhome")))
			pType = pType.replaceAll(",Townhouse", "");

		//================= Property Status ============
		html = html.replaceAll("Homes Available Now|Coming Soon!</span>|garage homes available", "");
		String titleLine=U.getSectionValue(html, "<title>", "</title>");
		if(!titleLine.contains("Coming")) {
			titleLine=U.getSectionValue(comUrl, "community/", "/");
			if(titleLine != null)
				titleLine=titleLine.replaceAll("-", " ");
		}

		html = U.removeSectionValue(html, "<head>", "</head>");
		String pStatus = U.getPropStatus((comSec+comDetailSection+html+titleLine).replaceAll("-soon|garage homes available", "")); //.replaceAll("Coming Soon|coming soon", "")
		
		
		//================= Derived Type =================
		html = html.replaceAll("STORIES:</span>\\s+<span class=\"option-detail\">1<",  " 1 Story<");
		
		
		String dType = U.getdCommType((combineHomeHtmls+html).replaceAll("ranch-style designs|content=\".*\"","").replace("second floor", "2 Story"));
		
		//============ Notes ==============
		if(pType.contains("Townhouse, Townhome"))pType="Townhome";

		if(add[2].length()>2){
			add[2]=USStates.abbr(add[2]);
		}
		if(comUrl.contains("-coming-soon"))pStatus = pStatus.replace("Coming Soon", "-");
		
		if(comUrl.contains("new-homes/south-carolina/upstate-sc-south-carolina/columbia/washington-heights")) {
			minPrice = "$100,000";
			maxPrice = "$113,790";
		}
				
		if(comUrl.contains("/community/vistanna-villas/")) {add[3]="27410";geo ="TRUE";}
		comName=comName.replaceAll("- Coming soon!$| &#8211; Coming Soon!| – Coming Soon!", "").replaceAll("&#8217;", "'").replace(" &#8211; ", "-").replaceAll("Townhomes|#038;", "");
		add[0]=add[0].replace(" (Mile 6 N)", "");
		add[0] = add[0].replace("Community located near", "");
		add[0] = add[0].replace("Community near ", "");
		U.log("add[0]:"+add[0]+", add[1]: "+add[1]+" add[2] :"+add[2]+ ",add[3] :" +add[3]);

		
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0].replace(" @ ", " ").trim(), add[1].replace("�", "").trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(Note);
		
	}
	j++;
	}
	}

