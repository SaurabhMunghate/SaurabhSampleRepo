/**
 *@modified By Priti Chaulkar
 * @date 07/2017
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_141_160;

import java.awt.Container;
import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractLincolnPropertyCompany extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public ExtractLincolnPropertyCompany()
			throws Exception {
		super("Lincoln Property Company","https://www.lincolnapts.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Lincoln Property Company");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractLincolnPropertyCompany();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Lincoln Property Company.csv",
				a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
		
	}

	//WebDriver driver=new FirefoxDriver();
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
		//driver=new FirefoxDriver(U.getFirefoxBinary(),U.getFirefoxProfile());

		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		String mainHtml=U.getHtml("https://www.lincolnapts.com/search#?search=",driver);
		
	String[] comSections  = U.getValues(mainHtml, "<div class=\"row collapse align-center prop-data\">", "<span>Learn More</span>");
	U.log(comSections.length);
	for(String cSec : comSections){
		//U.log(comSec);
		String cUrl = U.getSectionValue(cSec, "<a href=\"", "\">");
//		U.log("cUrl===== "+cUrl);
		addDetails(cUrl , cSec);
	//	break;
	}
		LOGGER.DisposeLogger();
		
//		try{driver.quit();}catch (Exception e) {}
	}

	private void addDetails(String comUrl, String comSec) throws Exception {
		// TODO Auto-generated method stub
		//try{
//		if(j>=0 && j<=100)
//		if(j>=327)
		{

		comUrl = "https://www.lincolnapts.com"+comUrl;
		
//		if(!comUrl.contains("waterfront-at-the-strand-kingston-ny"))return;
		
		U.log(j+"  commUrl-->"+comUrl);
		//20 Dec 21
		if(comUrl.contains("https://www.lincolnapts.com/properties/hudson-lights-new-jersey")||
				comUrl.contains("https://www.lincolnapts.com/properties/the-overlook-apartments-camp-hill-pa")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::::: Return - No Data :::::::::::::::::::");
			return;
		}
		//25 Feb 21
		if(comUrl.contains("https://www.lincolnapts.com/properties/chicago-outreach-committee-chicago-il")
				|| comUrl.contains("https://www.lincolnapts.com/properties/the-westside-collection-los-angeles-ca")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::::: Return - No Data:::::::::::::::::::");
			return;
		}
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+":::::::::::Reapeated:::::::::::::::::::");
			return;
		}
		if(comUrl.contains("https://www.lincolnapts.com/properties/the-domaine-plano-tx")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::::: Redirect :::::::::::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
				String html=U.getPageSource(comUrl);
				
				U.log(U.getCache(comUrl));
				//javax.net.ssl.SSLHandshakeException: Received fatal alert: unrecognized_name
				/*String rem=U.getSectionValue(html, "<head>","$919,990");
				html=html.replace(rem,"");*/
				//============================================Community name=======================================================================
				html=html.replace("prop-top-name'>", "prop-top-name\">");
				String communityName=null;
				if(comUrl.contains("https://www.lincolnapts.com/properties/eryngo-hills-austin-tx")) {
					communityName=U.getSectionValue(html, "<h1 data-selenium-id=\"SID_PropertyName\">","</h1>").trim();

				}else {
				communityName=U.getSectionValue(html, "prop-top-name\">","</h2>").trim();
				}
				if(communityName!=null) {
				communityName=communityName.replace("AurÃ©lien","Aurelien").replace("aur�lien","Aurelien").replace(" ", " ").replace("The St.John", "The St. John");
				communityName=communityName.replace("+","").replaceAll("Phase II| by Lincoln Property Company|Lofts$|Apartments$|Dallas| - Delray Beach|Active Adult Living|Mt. Laurel| Luxury Condominiums$|Villas$","");
				communityName=communityName.replace("The Aventine Greenville", "The Aventine").replaceAll("Aur�lien|Aurélien", "Aurelien").replace("V�LO", "Velo").trim();//||
				}

				if (comUrl.contains("https://www.lincolnapts.com/properties/mirasol-at-celebration-condominiums-celebration-fl")) {
					communityName=communityName.replace("Condominiums", "");
				}
				if (communityName.contains("Discovery Palms Condo") || communityName.contains("Residence Sabal Point Condo")) {
					communityName=communityName.replace("Condo", "");
				}
				if(communityName.endsWith("Apartment Homes") || communityName.endsWith("Apartment Villas") || communityName.endsWith("Apartments") || communityName.endsWith("Apartment")){
					communityName=communityName.replaceAll("Apartment Homes|Apartments|Apartment", "");
				}
				
				if(comUrl.contains("https://www.lincolnapts.com/properties/1016-lofts-atlanta-georgia"))
					communityName = "1016 LOFTS";
				if(comUrl.contains("https://www.lincolnapts.com/properties/one-seven-apartments-evanston-il"))
					communityName = "1717 APARTMENTS";
				communityName=communityName.replace("Parkline Chicago", "Parkline");
				U.log("community Name---->"+communityName +"::::::::");
			/*	if(j==6)
					communityName="Aurelien";*/
		//================================================Address section===================================================================
				String note="";
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				String addSec=U.getSectionValue(html, "http://maps.google.com/maps?q=","target=");
				U.log("addSec :: "+addSec);
				if(addSec!=null)
				{
					addSec=addSec.replace("301414", "30141").replace("016+Lofts,1016+Howell+Mill+Rd.", "016+Lofts 1016+Howell+Mill+Rd.").replace("301066", "30106").replace("Parkway,,", "Parkway,").replace("473,+477,+479,+&amp;+","").replace("AND+1129,+1131,","").replace("+Unit+177,","+Unit+177").replace("%23105,","%23105");
					U.log(addSec);
					addSec=addSec.replace("+"," ").replace("%23","#").replaceAll("%E2%80%8B|Unit 177|#105","").replace("14199 N, I-35", "14199 N I-35");
					addSec=addSec.replace("New Jersey","NJ");
					addSec = addSec.replace(",,", ",");
					U.log(addSec+"::this is add");
					String[] add1=addSec.split(",");
					if(add1.length>2 && add1.length!=4)
					{
						add[0]=add1[0];
						add[1]=add1[1];
						add[3]=Util.match(add1[2],"\\d{4,}");
						if(add[3]!=null)
						{
						add[2]=add1[2].replace(add[3],"").trim();
						add[2]=add[2].replace("'","").replace("\"","").trim();
						}
						else
						{
							add[2]=add1[2].replace("'","").replace("\"","").trim();
						}
					}else if(add1.length>2 && add1.length==4) {
						add[0]=add1[1];
						add[1]=add1[2];
						add[3]=Util.match(add1[3],"\\d{4,}");
						if(add[3]!=null)
						{
						add[2]=add1[3].replace(add[3],"").trim();
						add[2]=add[2].replace("'","").replace("\"","").trim();
						}
						else
						{
							add[2]=add1[3].replace("'","").replace("\"","").trim();
						}
						
					}
					//add=U.findAddress(addSec);
				}
				else if(html.contains("<span data-selenium-id=\"address")) {
					add[0]=U.getSectionValue(html, "<span data-selenium-id=\"address_street\">", "</span>").trim();
					add[1]=U.getSectionValue(html, "<span data-selenium-id=\"address_city\">", "</span>").trim();
					add[2]=U.getSectionValue(html, "<span data-selenium-id=\"address_state\">", "</span>").trim();
					add[3]=U.getSectionValue(html, "<span data-selenium-id=\"address_zip\">", "</span>").trim();
					latlag[0] = U.getSectionValue(html, "var latitude = \"", "\";");
					latlag[1] = U.getSectionValue(html, "var longitude = \"", "\";");
				
				}
				else {
					 addSec=U.getSectionValue(html, "var propData = {\"","};");
//U.log(">>>>>>>>>>>"+addSec);
					 add[0]=U.getSectionValue(addSec, "\"address\":\"", "\",").trim();
					 add[1]=U.getSectionValue(addSec, "\"city\":\"", "\",").trim();
					 add[2]=U.getSectionValue(addSec, "\"state\":\"", "\",").trim();
					 add[3]=U.getSectionValue(addSec, "\"zip\":\"", "\",").trim();
					 latlag[0] = U.getSectionValue(addSec, "\"lat\":", ",");
					 latlag[1] = U.getSectionValue(addSec, "\"long\":", "}");

				}
				
				U.log("Address---->"+add[0]+" :: "+add[1]+" :: "+add[2]+" :: "+add[3]);
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				add[0]=add[0].trim();
//				U.log("latlag[0].length()====="+latlag[0].length());
				if(latlag[0].length()<3) {
				latlag[0]=U.getSectionValue(html, "\"lat\":",",");
				latlag[1]=U.getSectionValue(html, "\"long\":",",");
				}
				if(latlag[0].contains("null")){
					latlag[0]=ALLOW_BLANK;
					latlag[1]=ALLOW_BLANK;
				}
				if(latlag[1].length()>20) {
					latlag[1]= U.getSectionValue(latlag[1],"-", "}");
					latlag[1]="-"+latlag[1];
				}
				if(latlag[1] != null && !latlag[1].contains("-") ) latlag[1] ="-"+latlag[1];
				if(comUrl.contains("https://www.lincolnapts.com/properties/amberlake-village-duluth-ga"))
					latlag[1] = "-84.1001768";
				if(comUrl.contains("https://www.lincolnapts.com/properties/skyhouse-frisco-tx"))
					latlag[1] = "-96.8299028";
				
//				if(comUrl.contains("https://www.lincolnapts.com/properties/amberlake-village-duluth-ga"))
//				{
//					latlag[0] = U.getSectionValue(html, "var latitude = \"", "\";");
//					latlag[1] = U.getSectionValue(html, "var longitude = \"", "\";");
//				}
				
				
				
				U.log("latlng--->"+latlag[0]+"  "+latlag[1] );
				if(latlag[0] != null && latlag[0].contains("7712.0"))
					latlag[0] = latlag[1] = ALLOW_BLANK;
				if(add[0].length()>4 && (latlag[0]==ALLOW_BLANK || latlag[0].length() < 4))
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null)
						latlag = U.getlatlongHereApi(add);
					U.log(":::::::::::::::::::::::::::::::::::::::::::::::::::");
					geo="TRUE";
				}
				if(add[0]==ALLOW_BLANK && latlag[0].length()>4)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null)
						add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				
				if(add[3]==null || add[3]==ALLOW_BLANK)
				{
					String add1[]=U.getAddressGoogleApi(latlag);
					if(add1 == null)
						add1 = U.getAddressHereApi(latlag);
					add[3] = add1[3];
					geo="TRUE";
					add1 = null;
				}
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				if(latlag[1].contains("-null") && add[0]!=null) {
					latlag = U.getlatlongGoogleApi(add);
				}
		//============================================Price and SQ.FT======================================================================
				String amenitisHtml= ALLOW_BLANK, floorHtml = ALLOW_BLANK;
/*				U.log("Amenities ::"+comUrl+"/amenities");
				String amenitisHtml=U.getPageSource(comUrl+"/amenities");
				U.log("floor ::"+comUrl+"/floorplans");
				String floorHtml=U.getPageSource(comUrl+"/floorplans");
				
*/		
				
/*				String floorUrlSec =U.getSectionValue(html,"<div class=\"floorplan-buttons\">","title=\"Check Availability\">");
				U.log(floorUrlSec+":::::::::::urlsec");
				if(floorUrlSec!=null) {
					if(floorUrlSec.contains("href=\"//")){
						floorUrlSec = floorUrlSec.replace("href=\"//", "href=\"https://");
					}
					String floorUrl=U.getSectionValue(floorUrlSec, "href=\"", "\"");
					if(!floorUrl.contains("#") && floorUrl.contains("http")) {
					U.log("floorUrl ::"+floorUrl);
					floorHtml =U.getPageSource(floorUrl);	
					if((!floorUrlSec.contains("floor")|| !floorUrlSec.contains("Floor")) &&floorUrl.contains("?") && floorUrl.contains("502626")) {
						String suburl="https"+U.getSectionValue(floorUrl, "https", "?");
						try {
							suburl= U.getRedirectedURL("", suburl);
							floorHtml =U.getPageSource(suburl+"floorplans");
						}catch(Exception e) {}
					}
					}
				}
*/				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//				U.log("comsec====="+comSec);
				html=html.replaceAll("0s|0's|0&#8217;s|0s","0,000")
						.replaceAll("\\d,\\d{3} square foot fitness center|\\d,\\d{3} Square Foot Common Area|\\d,\\d+ sq\\. ft\\. State of the Art Fitness", "");
				String prices[] = U.getPrices(html+floorHtml,"\\$\\d+,\\d+ - \\$\\d+,\\d+|\\$\\d+,\\d+</a>", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
//				U.log(Util.matchAll(html+floorHtml, "[\\w\\s\\W]{10}97[\\w\\s\\W]{10}", 0));
//				U.log(Util.matchAll(floorHtml+html, "\\d{3,4} Sq. Ft|\\d{3,4}\\+ Sq. Ft|\\d{3,4}\\.0 Sq. Ft.|\\d{3,4} - 0 Sq. Ft.|\\d{3} sq ft to \\d{4} sq ft|\\d{4} - \\d{4} Sq. Ft.|\\d{3}-\\d{3} Sq. Ft.|\\d+,\\d+ - \\d+,\\d+ Sq. Ft.|[1-9]\\d{2,} - [1-9]\\d{2,} Sq. Ft.|[1-9]\\d{2,} Sq. Ft.|(\\d,)*\\d+ Sq. Ft.|  \\d,\\d{3}\\+ Sq. Ft.|_sqft\">\\d,\\d{3}|Sq.Ft. \\d,\\d{3}| \\d,\\d{3} square foot|Sq.Ft. \\d{3}|_sqft\">\\d{3}",0));
				
				if(floorHtml!=null)
					{
					floorHtml=floorHtml.replaceAll("Sq.Ft.</strong></td><td data-selenium-id =\"Sqft_\\d\">", "Sq.Ft. ");
					}
				String[] sqft = U
						.getSqareFeet(
								html+floorHtml,
								"from \\d+ to \\d,\\d{3} square feet|from \\d+-\\d+ square feet|\\d{3,4} Sq. Ft|\\d{3,4}\\+ Sq. Ft|\\d{3,4}\\.0 Sq. Ft.|\\d{3,4} - 0 Sq. Ft.|\\d{3} sq ft to \\d{4} sq ft|\\d{4} - \\d{4} Sq. Ft.|\\d{3}-\\d{3} Sq. Ft.|\\d+,\\d+ - \\d+,\\d+ Sq. Ft.|[1-9]\\d{2,} - [1-9]\\d{2,} Sq. Ft.|[1-9]\\d{2,} Sq. Ft.|(\\d,)*\\d+ Sq. Ft.|  \\d,\\d{3}\\+ Sq. Ft.|\\d,\\d{3} square foot|_sqft\">\\d,\\d{3}|Sq.Ft. \\d,\\d{3}|Sq.Ft. \\d{3}|_sqft\">\\d{3}",0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		//===============remove section=============
				html=html.replaceAll("-Town-Homes-| own private balcony or patio|private patios and balconies| multi-level Parking Garage|multi-level parking garage|two-story health|Two-Story Health & Fitness |two-story health and fitness studio|two-level fitness studio|Two-story health club|Bi-Level Swimming|Gated Parking Garage| luxurious bathrooms", "");
				if(amenitisHtml!=null){
					amenitisHtml=amenitisHtml.replaceAll("Gated dog area|Multi-Level Access Parking |Multi-level access parking|Multi-story Atrium|Multi level parking garage|Multi-level fitness|Multi-Level Parking Garage|-Town-Homes-| own private balcony or patio|private patios and balconies| multi-level Parking Garage|multi-level parking garage|Two-Story Health|two-story health|Two-Story Health & Fitness |two-story health and fitness studio|two-level fitness|Two-story health club|Bi-Level Swimming|Gated Parking Garage| luxurious bathrooms|Bi-level state", "");
				}
				
				//U.log(html);
		//================================================community type========================================================
				html=html.replace("community lake, waterfront", "waterfront community")
						.replaceAll("Resort Style Swimming Pool|lakefront pool", "");
				String communityType=U.getCommType((html+amenitisHtml).replaceAll("directions\":\"Gated|irections\":\"Gated Acc|lakefront pool|community is located", ""));

				//==========================================================Property Type================================================
				html = html.replace("loft", "Loft Home").replace("Savor Manor Apartments", "Savor Manor homes Apartments")
						.replace("residents can bask in the luxury", "residents can bask in the luxury residential")
						.replace("luxury rental community", "luxury residential rental community")
						.replaceAll("level of luxury|luxuries in a serene|luxury fixtures|luxury to your open layout|Luxury Lakewood", "luxury homes").replaceAll("luxury comes first|luxury offerings", "luxury residential");
				String proptype=ALLOW_BLANK;
				proptype = U.getPropType((html+amenitisHtml.replace("luxuries in a serene", "luxury homes"))
						.replaceAll("crafted|craftsmanship|Property Company apartment home today! Explore apartments|Village|THEVILLAGEDALLAS.COM|village", ""));
				
		//==================================================D-Property Type======================================================
			    html = html
			    		.replace("two_story", "two-story").replace("sixth floor", "6-story")
			    		.replace("First Floor ", "Story 1.00").replace("8th-floor", "8 story")
			    		.replace("12th floor", "12 Story");
				String dtype=U.getdCommType(communityName+comUrl+(html+floorHtml+amenitisHtml).replace("our 32-story", "32 story")
						.replaceAll("shops conveniently located on the first floor|Two level fitness|Bi-Level 24-Hour|story Garage|30th Floor|Colonial Boulevard|22 Story High-Rise in|Colonial Panel|Colonial Fort| two-story fitness|Third Floor|multi-level swimming|Greenbriar 2nd Floor|Greenbriar - 2nd Floor|Two-Story Fitness Center|first floor of the public garage|There is a four-level public garage located directly across the street |first floor of the parking garage|5 Story Gated Private Garage Parking|Two-story town home|2-story clubhouse|two Story club space|Multi-level limited access parking |Multi-Level Access Parking |Multi-level garage parking|Multi Level Garage|Multi-level Parking |Multi level parking |Multi-level parking garage|Three-Story Elevator|BA 2nd Floor | two-story health|Complimentary multi-level | Multi|Level Retail|two-level consisting|story controlled access|story Fitness|ranch|Ranch|two-level fitness",""));
//				U.log("MMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}8th-floor[\\s\\w\\W]{30}", 0));
/*				if(comUrl.contains("https://www.lincolnapts.com/properties/the-stahlman-nashville-tn"))
					dtype = dtype.replace("2 Story,", "");
*/		//==============================================Property Status=========================================================
				String remove="Area \\(Coming|Park\\s+<em>\\s+Coming| Canton is now available|unlimited opportunities for| Amenities Coming Soon| Coming Soon!|Hours Coming Soon|Soon (Newly Redesigned|Brand New|Electric Car)|(Interiors|List|Green-|Trail) Coming|entirely move-in|designed and move-in|office_hours\":\"COMING|TOURS NOW AVAILABLE|swimming pool, coming soon|today! Limited time|hours\":\"Coming|office is temporarily closed|Upgraded apartments now available|Resident links coming soon|multi-level swimming|\\(coming soon\\)| plots available|Upgraded Interiors Now Available| Interiors Now Available |\\(Limited Availability\\)|Center Coming Soon|<li>Coming Soon|amenity-list text-center\">\\s+<p>\\s+Coming";
				if(amenitisHtml!=null)amenitisHtml=amenitisHtml.replaceAll("Coming|COMING","");
				String pstatus=U.getPropStatus((html+amenitisHtml).replace("office_hours\":\"***Coming Soon!***\"", "").replaceAll(remove,""));
				
		//============================================note====================================================================
				
				html = html.replaceAll("_Pre-Leasing_|learn about pre-leasing opportunities", "");
				 note=U.getnote(html);
				 
				 U.log("NOTE===="+note);
				
				if(add[2].length()>2)
				{
				add[2] = USStates.abbr(add[2]);
				}
				if(add[3].length()==4)
				{
					add[3]="0"+add[3];
				}
				if (proptype.contains("Townhouse")&&proptype.contains("Townhome")) {
					proptype=proptype.replaceAll("Townhouse,|Townhouse", "");
				}
				if(add[2]!=null)add[2]=add[2].replace("Tx","TX").replaceAll("Suite 109", "");
				if(add[1]!=null)add[1]=add[1].replaceAll("Suite 109", "");
				communityName=communityName.replace("San Montego TX","San Montego");
				communityName=communityName.replaceAll("condominiums$|and townhomes$|apartments$|condo$|courtyards$|townhomes$| villas$","")
						.toLowerCase();
				
				U.log(communityName+":::::::::::::");
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				//if(dtype.contains("12 Story") || dtype.contains("32 Story"))dtype=dtype.replaceAll("2 Story,", "");
				U.log(dtype);
				dtype = dtype.replace("12 Story, 2 Story", "12 Story");
				dtype = dtype.replace("32 Story, 2 Story", "32 Story");

				if(comUrl.contains("/properties/treviso-grand-venice-fl")){
					minSqft="574";
					maxSqft = "1,252";
				}
			//	String geosec=U.getSectionValue(html, "<a class='map' href='https://maps.google.com?q", "title='Map it'>");
				
				
//					geo="TRUE";
				
				if(comUrl.contains("https://www.lincolnapts.com/properties/canyon-springs-austin-tx"))
					add[0]=add[0].replace("Of Texas Hw", "");
				

				
					add[0] = add[0].replace("V%C3%ADa", "Via").replace("1016 Lofts ", "");
					add[1] = add[1].replace("Dalas", "Dallas");
					data.addCommunity(communityName.trim(),comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].toLowerCase().trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addUnitCount(ALLOW_BLANK);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
				j++;
		//}catch (Exception e) {}
						
	}

}