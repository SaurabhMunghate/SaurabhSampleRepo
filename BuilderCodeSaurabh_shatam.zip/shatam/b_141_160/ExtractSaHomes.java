package com.shatam.b_141_160;
import java.io.*;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSaHomes extends AbstractScrapper 
{
 int i=0;
 public int inr=0;
 static int j=0;
 WebDriver driver = null;
 CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception 
	{

		AbstractScrapper a = new ExtractSaHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"S&A Homes.csv", a.data().printAll());
		
	}

	public ExtractSaHomes() throws Exception 
	{
		super("S&A Homes", "https://www.sahomebuilder.com/");
		LOGGER=new CommunityLogger("S&A Homes");
	}

	public void innerProcess() throws Exception 
	{
		U.setUpGeckoPath();
		//driver=new FirefoxDriver(U.getFirefoxBinary(),U.getFirefoxProfile());
		driver = new FirefoxDriver();
		String url = "https://www.sahomebuilder.com/";
		String html = U.getHTML(url);
//		U.log(html);
		String sction = U.getSectionValue(html, "<ul class=\"home__locations-list\">", "</ul>");
		 //U.log(sction);
		String regionval[] = U.getValues(sction, "<a href=\"", "\"");
		U.log("total count"+regionval.length);
		for (String itom : regionval) 
		{
			U.log(" region :" + url + itom);
			findComUrl(url + itom);
			
		}
		LOGGER.DisposeLogger();
		driver.close();
		try { driver.quit(); } catch (Exception e) {}
	}

	private void findComUrl(String pageUrl) throws Exception 
	{
//		if(!pageUrl.contains("steeplechase/overview"))return;  //single region
		String html = U.getHtml(pageUrl, driver);
		U.log("pageUrl: "+pageUrl);
		String url = "https://www.sahomebuilder.com";
//		U.log(html);
		String comUrls[] = U.getValues(html,"<a class=\"thumbnail ng-scope\"","VISIT THIS COMMUNITY");
		int totalComm=comUrls.length;
		U.log("Total:- "+totalComm);
//		Thread.sleep(5000);
		for (String itom : comUrls) 
		{
          String comUrl = U.getSectionValue(itom, "ng-href=\"", "\"");
			addDetails(url + comUrl, itom);
			inr++;
			i++;// break;
		}
		
	}
	

	private void addDetails(String comUrl, String comSec) throws Exception 
	{
	//TODO: For Single Community Execution
//	if(j == 16)
		//try{
		{
			
//			if(!comUrl.contains("https://www.sahomebuilder.com/pennsylvania/carlisle-chambersburg-shippensburg/chesterfield"))return;
			U.log("\ncount :" + j);
			U.log("\nPAGE :" + comUrl);
			
		String html = U.getHtml(comUrl, driver);
		
		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		U.log(U.getCache(comUrl));
		String fhtml=html;
		String url = "https://www.sahomebuilder.com";

		
		// community name
		String comm[] = U.getValues(html, "<h2 class=\"promo-title\">", "</h2>");
		// String commName=comm[0];
		String commName = ALLOW_BLANK;
		commName = U.getSectionValue(html, "  <h3>","<");
		commName = commName.replace("&#039;", "'");
		U.log("communityname+++++"+commName);
		if(commName.contains("Foxfield"))commName.toLowerCase().replace("village at", "");
	//	U.log("communityname+++++"+commName);

		
		// property type
		String propertyType = ALLOW_BLANK;
		

		// Lat Long
		String geoFlag = ALLOW_BLANK;
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
//		String dirHtm = U.getHTML(comUrl.replace("/overview","/map-and-directions"));
		String lat = U.getSectionValue(html, "community-latitude\" value=\"", "\"/>");
		String lon = U.getSectionValue(html, "community-longitude\" value=\"", "\"/>");
		latLong[0] = (lat == null) ? ALLOW_BLANK : lat;
		latLong[1] = (lon == null) ? ALLOW_BLANK : lon;
		
	    U.log("Lat :" + latLong[0] + " Long :" + latLong[1]+"geo :"+geoFlag);
	    if(latLong[0] == ALLOW_BLANK && latLong[1] == ALLOW_BLANK){
	    	String latLngSec = U.getSectionValue(html, "https://maps.google.com/maps?ll=", "&");
	    	if(latLngSec != null){
	    		String[] vals = latLngSec.split(",");
	    		latLong[0] = vals[0];
	    		latLong[1] = vals[1];
	    		U.log(Arrays.toString(latLong));
	    	}
	    }
	    if (latLong[0] != ALLOW_BLANK)
			geoFlag = "FALSE";
	    // Address
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
 //       String mapAddress=comUrl.replace("/overview", "/map-and-directions");
        //U.log("mapaddress======="+mapAddress);
      
        String sec = U.getSectionValue(html, " <address class=\"cad-card__address\">", "</address>");//U.getSectionValue(html, "<strong>COMMUNITY</strong><br>", "</p>");
        sec = sec.replaceAll("<br>|<br />", ",");
        String latLngSec= U.getSectionValue(sec, " <a data-override=\"true\" href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
        if(latLngSec!=null) {
        	latLong = latLngSec.split(",");
        }
        if(sec!=null)sec = U.getSectionValue(sec, "class=\"cad-card__address-link\">", "<");
 //       U.log("sec======="+sec);
        String[] addd ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};

        addd = U.getAddress(sec);

		if (addd != null){
			add = addd;
			U.log(add[0]);}
		else{
			addd=sec.split(",");
			String []stateZip=addd[2].split(" ");
			U.log("0"+stateZip[0]);
			U.log(stateZip[1]);
			U.log(stateZip[2]);
			add[0]=addd[0];
			add[1]=addd[1];
			add[2]=stateZip[1];
			add[3]=stateZip[2];
			
		}
		if(add[0].contains(", PA"))add[0]=add[0].replace(", PA", "");
		U.log("***********"+Arrays.toString(add));
	
		geoFlag = "FALSE";
		if (add[0] == ALLOW_BLANK) {
			add[0] = U.getSectionValue(html, "<p class=\"address locality\">",
					"</p>");
			String ad = U.getSectionValue(html, "<p class=\"city-state-zip\">",
					"</p>");
			String adr[] = ad.split(",");
			add[1] = adr[1];
			adr[1] = adr[1].trim();
			adr = adr[1].split(" ");
			add[2] = adr[0];
			add[3] = adr[1];
		}
		
		if (latLong[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK) 
		{
			String[] latiLong = U.getlatlongGoogleApi(add);
			if(latiLong == null) latiLong = U.getlatlongHereApi(add);
			latLong[0] = (latiLong[0] == null) ? ALLOW_BLANK : latiLong[0];
			latLong[1] = (latiLong[1] == null) ? ALLOW_BLANK : latiLong[1];
			geoFlag = "True";
				
		}
		if(add[1]!=null)
		add[1] = add[1].replace("&amp;", "&");
		if(add[0]!=null)
		add[0] = add[0].replace("00 Brandy Lane", "Brandy Lane");
        add[0]=add[0].replace("00 Phoebe Road", "Phoebe Road");
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"+ add[3]);

		// U.log(floorSec)
	    html=html.replace("0s", "0,000").replace("0's", "0,000").replace("&#039;s", ",000");
	    html = html.replace(" Starting from $280,900", "").replaceAll("New Building Coming Soon", "");
	   // U.log(floorSec);
	    String statSec = U.getSectionValue(html, "<main id=\"main\"", "</html>");
		String remove = "more about the grand opening release|/coming-soon\">Coming Soon</a></li>|title=\"QUICK DELIVERY HOMES|we add new Quick Delivery Homes,|limited time pre-construction pricing|<h3>Quick Delivery</h3>|quick delivery homes ready now|Model Home Now Open|Schools Coming Soon|preview party and grand opening release|The Montgomery, Now Open";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		String quickdHomes = U.getHtml("https://www.sahomebuilder.com/quick-delivery", driver); 
		//String[] quickSep = U.getValues(quickdHomes, " <div class=\"col-sm-4 info text-left\">", " <div class=\"col-sm-12 snapshot-wrap dark hidden-xs\">");
		//String[] quickSep = U.getValues(quickdHomes, " <div class=\"col-sm-4 info text-left\">", "<i class=\"fa fa-angle-right\"></i>");
		String[] quickSep = U.getValues(quickdHomes, " <div class=\"col-sm-4 info text-left\">", "<div class=\"col-xs-4 baths ng-binding\">");
		String quickInnfo="";
		int quick_count=0;
		for(String quickSe:quickSep)
		{	
			quickSe=quickSe.replace("SQ.", "SQ. Ft<div>");
			if(quickSe.contains(commName.toUpperCase().trim())) {
				U.log("Hello");
//				U.log("quickSe:::::::::::::::::::"+quickSe);
//				if(!quickSe.contains("Under Construction")) {
					quick_count++;
//				}
				quickInnfo=quickInnfo+" "+quickSe;
			}
				
		}
		U.log("quick_count==="+quick_count);
		
		if( comUrl.contains("hunters-chase-bridgeport-west-virginia"))
		{
			statSec = statSec.replace("class=\"block\">view quick delivery homes", "");// same comm name
		}
		if(quick_count>0)
		{
			
			statSec = statSec.replace("class=\"block\">view quick delivery homes", "");
		}
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		U.log("MAR+TCH+"+Util.matchAll(quickInnfo+html, "[\\w\\W\\s]{50}\\$500[\\w\\W\\s]{50}", 0));
		String[] price = U.getPrices(html+quickInnfo,"Mid-\\$\\d{3},\\d{3}|Price: </span>\\$\\d{3},\\d{3}|\\$\\d{3},\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("Min-Price :"+minPrice+"\tMax-Price :"+maxPrice);
		
		//-------fetching homes data---------
		String allPlanData = ALLOW_BLANK;
		String[] planUrls = U.getValues(html, "<h4 class=\"ng-binding\">", "</h4>");
		U.log("Toatl plan : "+planUrls.length);
		for(String planUrl : planUrls){
			U.log("planUrl : "+planUrl.toLowerCase());
			String planHtml = U.getHTML("https://www.sahomebuilder.com/pick-a-plan/plan-details/"+planUrl.toLowerCase()+"-floorplan");
			if(planHtml != null)
				allPlanData += U.getSectionValue(planHtml, "title=\"DOWNLOAD BROCHURE\"", "<table class=\"table table-bordered\">")+U.getSectionValue(planHtml, "<div id=\"overview\"", "</div>"); 
		}
		
		html=html.replaceAll("436 Country|liding patio door|home that surpassed their|village|Village","")
				.replaceAll("high end luxuries|High end luxuries", "luxury home").replace("with traditional,", "traditional homes ")
				.replace("3 story townhome with vinyl siding", "");
		if(allPlanData != null) allPlanData = allPlanData.replace("traditional and craftsman designs", "traditional homes and craftsman designs")
				.replaceAll("first-floor bedrooms|first-floor laundry|first-floor owner’s suite", " 1 Story ");
		propertyType = U.getPropType((comSec+allPlanData+html).replaceAll("Craftsman style home with full front|home with Craftsman style front|Just past existing multi-family homes on the right is|custom home-builder started in 1968|- Single Family|upstairs apartment|2 Story wheat|Patio Slider|Country Club Rd|patio doors", ""));
		
		U.log(Util.matchAll(comSec, "[\\w*\\s*\\W*]{19}Ranch[\\w*\\s*\\W*]{15}", 0));
		comSec = comSec.replace("Aspen C single family ranch home", "").replace("3 story townhome with vinyl siding", "");
		allPlanData = allPlanData.replaceAll("the three-story Alexandria is the community|the third level features an impressive owner","");
		
		String dtype=U.getdCommType(comSec.replace("<li>Ranch &amp", "Ranch")+html.replaceAll("3 story townhome with vinyl siding|Show only 1st Floor|Five unit building - two story|Colonial MDF|Colonial&nbsp;MDF|SHOW ONLY 1ST FLOOR|2 Story Wheat|Branch Water|create the perfect ranch","")+allPlanData.replaceAll("3 story townhome with vinyl siding|floor|First Floor", ""));
//		U.log("MMMMMMMMMMMMMMMM"+Util.matchAll(comSec, "[\\s\\w\\W]{30}third level[\\s\\w\\W]{30}", 0));
        
//        String floreHtml=U.getHtml(florUrl,driver);
		// 1,200-2,300 sq. ft.
		
        html=html.replace("1,450 - 2,300 SQ.FT.</div>", "");
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet((html+quickInnfo+allPlanData).replaceAll("Lot Size Sq Ft: 22,749|22,749 sq. ft,", ""), 
				"\\d,\\d{3} SQ\\.FT| \\d,\\d{3}<span class=\"hidden-xs\"> SQ. FT| \\d{4} - \\d{4}\\+ sq. ft.|\\d,\\d{3} - \\d,\\d{3} SQ.FT. |\\d,\\d+-\\d,\\d+|\\d{1},\\d{3} SQ. Ft|\\d,\\d{3} sq. ft.| \\d,\\d{3} SQ.FT.|\\s+\\d,\\d{3}\\s+SQ. FT.", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		if (minSqf == ALLOW_BLANK) {
			sqft = U.getSqareFeet(html, "<li class=\"odd sqr\">\\s*.*", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		}

		U.log("minSqf :"+minSqf+"\tmaxSqf :"+maxSqf);
		
		String status = ALLOW_BLANK;
		statSec = statSec.replace("new phase of single family homes now selling", "New Phase Now Selling").replace("Only a few homesites are available", "Only a few homesites available")
				.replace("new townhome and single family home phases coming soon", "New Phases Coming Soon").replace("new phase of single family homes now available", "New Phase Now Available")
				.replace("new phase of townhomes coming soon", "New Phase Coming Soon");
	    statSec = statSec.replaceAll("new building now selling|New Building Now Selling|Coming Soon! \\d{3} Barnwood,| coming soon!</p>|<a href=\"/coming-soon\">Coming Soon</a>|>Coming Soon</a></li>|a href=\"/coming-soon\">Coming Soon</a></li>|<p>coming soon!</p><a href=|coming soon</a></li>|col-md-12&quot;&gt;&lt;p&gt;coming soon|this community's available homesites|are feet / move-in ready|Tours Now Available|tours now available|now selling from|/coming-soon\">coming soon|information coming soon|model home - coming soon|a - coming soon|bayberry c coming soon", "")
	    		.replaceAll("time move-in|suite plan now selling|and only a few homesites remain in the current phase|affordable move-in|move-in|Move-in|coming soon to|Coming Soon</a>|plan to view available homesites|suite now", "")
	    		.replace("phase i homesites are selling quickly", "Phase I homesites selling quickly")
	    		.replace("only 4 homesites and 2 quick delivery homes", "only 4 homesites remain and 2 quick delivery homes").replaceAll("<li(.*?)</li", "")
	    		;	
//	    U.log(Util.matchAll(statSec, "\\s*\\W*\\s*[c|C]oming [s|S]oon",0));
	    statSec += U.getSectionValue(html.replace("<div class=\"block\">view quick delivery homes</div>", "").replaceAll("quick|Quick", ""), "<div id=\"welcome\">", "</div>");
	    statSec = statSec.replace("new single family homesites coming soon", "new homesites coming soon")
	    		.replaceAll("view quick delivery homes</div>|quick delivery home coming soon|Quick Delivery Home Coming Soon", "")
	    		.replaceAll("New Buildings Coming Soon|new buildings coming soon|new townhome buildings coming soon|New Townhome Buildings Coming Soon|home phase coming soon|home -coming soon|Home Phase Coming Soon|tours are now available|Home Tours are Now Available", "").replace("only one home remains in the current phase,", "One Home Remains in Current Phase").replace(" Home Tours Now", "");
	  
	    statSec=statSec.replaceAll("image coming soon|new townhome buildings are now selling!&nbsp|new townhome buildings now selling!&nbsp", "");
	    status = U.getPropStatus(statSec.replaceAll("quick delivery|quick delivery home starting construction soon|Pricing coming soon|pricing coming soon|Coming Soon!  The Bayberry B plan|current and final phase of cannon ridge has|Rosewood - Coming Soon|banner coming-soon&quot;>Coming Soon</p>|<p>Quick Delivery Coming Soon - Sign up on the Interest|view quick delivery homes|new townhome buildings are now selling!&nbsp;|grand opening date|floorplan details coming soon|floorplans will be coming soon|Home Phase Coming Soon|model home -coming soon|home phase coming soon|tours are now available|Tours are Now Available|ome tours are now available|bayberry c - coming soon|Last Chance to Tour|tours now available|Tours Now Available| only a&nbsp;few homesites remain|>coming soon|>Coming Soon</a></li>| >Coming Soon! 226 Barnwood| >Coming Soon! 228 Barnwood| >Coming Soon</a></li>|<a href=\"/coming-soon\">Coming Soon</a>|Coming soon!  The Madison|NEW BUILDING NOW AVAILABLE|Last Homesite at Saybrook - Now Available!|avalon elevation c - coming soon!|homes in Phase 1 are SOLD|family homes coming|Coming Soon</a>|coming soon(&quot;)?</p>".toLowerCase(), ""));
	    status=status.replaceAll("Closeout!", "Close Out").replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
       
	    
//	    if(html.contains("VIEW QUICK DELIVERY HOMES")) {
	    if(quick_count>0) {
	    	if(status.length()<4) {
	    		status="Quick Delivery Homes";
	    	}
	    	else
	    		status+=", Quick Delivery Homes";
	    
	    }
	    
	    

		/**/
	    U.log(">>>>>>>"+status);
		html=html.replaceAll("2 &amp; 3-story","2 story ,3 story").replace("first-floor owner", "1 story");
		html=html.replaceAll("Branch|Elongated|elongated","");
		html = html.replace("best golf", "golf club");
		//U.log("result::"+Util.match(html, "one stor"));
		String communityType = U.getCommunityType(html.replaceAll("Penn State Golf Courses|Toftrees Golf Resort are also nearby", ""));
		if(commName.toLowerCase().contains("village at"))commName.toLowerCase().replace("village at", "");
	
		if(comUrl.contains("https://www.sahomebuilder.com/pennsylvania/carlisle-chambersburg-shippensburg/stonehedge/overview"))
			status = status.replace(", Now Selling", "");
		if(comUrl.contains("https://www.sahomebuilder.com/pennsylvania/altoona-huntingdon/rolling-hills-north"))status=status.replace("Coming Soon, ", "");
		
		
		if(comUrl.contains("https://www.sahomebuilder.com//pennsylvania/shippensburg/deerfield/overview"))
		{
			propertyType=propertyType+", Custom Homes";
		}// Only One Home Remains, Only One Homesite Remains
		if(status.contains("Only One Home Remains") && status.contains("Only One Homesite Remains"))status=status.replace("Only One Home Remains, Only One Homesite Remains", " Only One Homesite Remains");

		if(status.contains("One Home Remains") && status.contains("Only One Homesite Remains"))status=status.replace(", One Home Remains, Only One Homesite Remains", ", Only One Homesite Remains");
		if(propertyType.contains("Townhouse") && propertyType.contains("Townhome")) {
			propertyType =propertyType.replace("Townhouse", "");
		}
		status = status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon")
				.replace("Quick Delivery Home Available", "Quick Delivery Home")
				.replace("New Phase Coming Soon, Only One Homesite Remains, New Phase", "New Phase Coming Soon, Only One Homesite Remains").replace("New Phases Coming Soon, New Phase", "New Phases Coming Soon").replace("Community Closeout", "Closeout").replace("Oversized Homesites","Oversized Homesites Available");
//		if(comUrl.contains("/state-college-bellefonte/deerhaven/overview"))status = status.replace("Only One Home Remains", "One Home Remains in Current Phase");
				
		
		if(comUrl.contains("https://www.sahomebuilder.com/pennsylvania/state-college-bellefonte/steeplechase/overview"))status = "﻿New Ranch Plans Now Available";
		
		if(comUrl.contains("state-college-bellefonte/hampton-hills") || comUrl.contains("pennsylvania/state-college-bellefonte/village-at-canterbury"))
			status="Quick Delivery Home";
		if(quick_count==0 && status.contains("Quick Delivery Home"))
		{
			status=status.replaceAll(", Quick Delivery Home|Quick Delivery Home,|Quick Delivery Home", "");
		}
		
		if(status.length()==0)
		{
			status=ALLOW_BLANK;
		}
		
		
		String end_Date=ALLOW_BLANK;
		
		if(comUrl.contains("/state-college-bellefonte/hampton-hills")) {
			end_Date="2022/12/01";
		}
		
//		=================================================================================
		String lotCount=ALLOW_BLANK;
		String[] lotData=U.getValues(html, "<div class=\"lot-map-pin", "</div>");
		if(lotData.length>0) {
			lotCount=Integer.toString(lotData.length);
		}
		U.log("lotCount>>>>>>>"+lotCount);
		
		data.addCommunity(commName, comUrl, communityType);
		data.addAddress(add[0].replace("00 Gwenedd Lane", "Gwenedd Lane"), add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geoFlag);
		data.addPropertyType(propertyType,dtype);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
	//	U.log("3333333333333"+U.getSectionValue(fhtml, "can take advantage of our limited", "opportunities"));
		data.addNotes(U.getnote(fhtml.replaceAll("take advantage of pre-construction", "")));
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, end_Date);
	}
		j++;
		//}catch (Exception e) {}
	//U.log("commm:="+inr);
	}
	
	
	public static String getHtml(String url,WebDriver driver) throws IOException, InterruptedException {

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// int respCode = CheckUrlForHTML(url);

				// if(respCode==200)
				{
					
					if (!f.exists()) {
						
							BufferedWriter writer = new BufferedWriter(new FileWriter(f));
							driver.get(url);
							((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
							html = driver.getPageSource();
							try {
							WebElement e=driver.findElement(By.xpath("//*[@id=\"contact-and-direction\"]/div/div[2]/div[1]/form/ul/li[2]/input"));
							Thread.sleep(1000);
							e.click();
							U.log(":::::::::::::::click success::::::::::::::::");
							Thread.sleep(1000);
							html = driver.getPageSource();
							}catch(Exception e) {}
							//U.log("Current Url : "+ driver.getCurrentUrl());
							Thread.sleep(2000);
							writer.append(html);
							writer.close();
						
						
					} else {
						if (f.exists()) {
							html = FileUtil.readAllText(fileName);
							U.log("Reading done");
						}
					}
					
					return html;
				}
		
	}// //
	
}