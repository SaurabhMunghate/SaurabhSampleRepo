/* 
 *Author Priti Chaulkar
 * 
 * Date 30/01/17
 */

package com.shatam.b_161_180;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTilesonHomes extends AbstractScrapper {
	int i=0;
	public int inr=0;
	WebDriver driver=null;
	CommunityLogger LOGGER = null;
	
	
	private static String builderUrl = "https://www.tilsonhomes.com";
	 public static void main(String[] args) throws Exception {

	        AbstractScrapper a = new ExtractTilesonHomes ();
	        a.process();
	        FileUtil.writeAllText(U.getCachePath()+"Tilson Homes.csv", a.data()
					.printAll());
	    }

	    public ExtractTilesonHomes () throws Exception {
	    	super("Tilson Homes", "https://www.tilsonhomes.com"); ///
	    	LOGGER = new CommunityLogger("Tilson Homes");
	    }
	    
	    public void innerProcess() throws Exception {
//	    	U.setUpGeckoPath();
//	    	driver = new FirefoxDriver();
	    	
	    	
	    	String url="https://www.tilsonhomes.com/where-we-build/";
	    	String html=U.getHTML(url);
	    	
//	    	U.log(html);
	    	String section=U.getSectionValue(html, "<span class=\"d-block\">Design Centers</span>", "Have Questions? Ask Us!</h3>");
//	    	U.log("section:::"+section);
	    	String[] comSections=U.getValues(section, "<div class=\"card-body text-center\">", "LEARN MORE</a>"); 
	    	U.log("comSec length:::"+comSections.length);
	    	for(String comSec: comSections){
	    		//U.log("comSec:::"+comSec);
	    		addDetails(comSec,driver);
	    	}
//	    	addDetails("vintage-oaks");
//	    	addDetails("texas-grand-ranch");
	    	LOGGER.DisposeLogger();
//	    	try{driver.quit();}catch (Exception e) {}
	    }

		private void addDetails(String comSec,WebDriver driver) throws Exception{
//			if(i>=10)
			{
//			https://www.tilsonhome.com/sales-center/waxahachie
//			U.log("comSec==="+comSec);
			String comUrl =U.getSectionValue(comSec, "href=\"", "\"");
			// TODO Auto-generated method stub
			U.log("comUrl Sec==="+comUrl);
			comUrl = builderUrl+comUrl;
			if (comUrl.contains("/1353-merlot") || comUrl.contains("/479-curvatura") ) {
				//homeurls
				return;
			}
//			if(!comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/melissa/mckinney/5010/"))return;

			
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "----------repeat");
				return;
			}
			
//			if (comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/huntsville/texas-grand-ranch/5219/")){
//				LOGGER.AddCommunityUrl(comUrl+ "----------Return");
//				return;
//			}
			
			LOGGER.AddCommunityUrl(comUrl);
			//U.log(U.getCache(comUrl));
			
//			if(!comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/angleton/angleton/5004/"))return;
			U.log("Count:::::=======> "+i);
			U.log("comUrl:::::=======> "+comUrl);
			String html=U.getHtml(comUrl,driver);
			//U.log(html);
			String commName=U.getSectionValue(html, "model-name-bg m-0 p-3\">", "</h3>");
			U.log("commName==="+commName);
			if (commName==null) {
				commName=U.getSectionValue(comSec, "f-gotham-bold text-color text-uppercase\">", "<");
				commName = commName.replaceAll("Ranch$| Design Studio", "");
			}
			commName = commName.replaceAll("Ranch$| Design Studio", "");
			U.log("commName ::::::========>  "+commName);

			
			//Address
			html=html.replaceAll("<span class=\"line-break\">\\(West bound side of IH-10\\)</span>|<span class=\"line-break\">\\(Exit #406\\)</span>", "");
			
			String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String ad=U.getSectionValue(html, "<div class=\"model-address f-gotham-book text-medium\">", "</div><div class=\"mt-3 mb-1 f-gotham-bold\">HOURS");//U.getSectionValue(html, "gmapaddress-mobile\">", "</span>");
//			String ad=U.getSectionValue(html, "<div class=\"model-address f-gotham-book text-medium\">", "</div>");	
			
//			U.log("ad::"+ad);
			if(ad!=null){
				ad= ad.replace("</div><div class=\"f-gotham-book\">", ",");
				add= U.getAddress(ad);
			}
			else {
			ad=U.getSectionValue(html, "<div class=\"model-address f-gotham-book text-medium", "div></div>");//U.getSectionValue(html, "gmapaddress-mobile\">", "</span>");
			ad=ad.replaceAll("</div>\\s*<div class=\"f-gotham-book\">", ", ");
			U.log("ad11::"+ad);
			
			if(add[0]==null || add[0]==ALLOW_BLANK && ad!=null){
				String ad1= U.getSectionValue(ad, ">", "</div>");
				U.log(ad);
				if(ad==null) {
					ad= U.getSectionValue(ad, ">", "<");
				}
				add= U.getAddress(ad);
			}
//			else {
//				ad= U.getSectionValue(ad, ">", "</");
//				add= U.findAddress(ad);
//			}
			
		
			}
			if(add[0]==ALLOW_BLANK && ad!=null) {
				ad=U.getSectionValue(html, " data-gmapaddress=\"", ">");
				String city=U.getCityFromZip(Util.match(ad, "\\d{5}"));
				if(ad.toLowerCase().contains(city))ad=ad.toLowerCase().replace(city, ","+city);
				add=U.getAddress(ad);
			}
//			U.log("add[0]==="+add[0]);
				add[0]=add[0].replace("(Exit #406)", "").replaceAll("\">", "");
			
			U.log("street:  " + add[0] + " City:  " + add[1] + " ST:  " + add[2] + " Z:  "	+ add[3]);
			
			
			
			// lat long values
			String lat=ALLOW_BLANK;
			String lng=ALLOW_BLANK;
			String[] latLng ={ALLOW_BLANK,ALLOW_BLANK};
			String geo="False";
			
//			//Fetching latlng fro address iframe link
//			String iFrameLink=U.getSectionValue(html, "<iframe id=\"map\" src=\"", "\"");
//			U.log("iFrameLink::::========================================================>"+iFrameLink);
//			
//			if(iFrameLink!=null){
//				iFrameLink=iFrameLink.replace("&amp;", "&");
//				U.log("iFrameLink:::::::::===============================================> "+iFrameLink);
//				String iFrameHtml=U.getHTML(iFrameLink);
//				String latlngSec =U.getSectionValue(iFrameHtml, add[3]+", USA\",[", "]");
//				U.log("latlngSec:::========================================================> "+latlngSec);
////				
//			if(latlngSec==null)
//			{
//				latlngSec=ALLOW_BLANK;
//			}
			String latlngSec = U.getSectionValue(html, "<a href=\"//maps.google.com/maps?q=", "\"");
			if(latlngSec!=null && latlngSec.length()>6){
					U.log("latlngSec::::::::::::"+latlngSec);
					latLng[0] = Util.match(latlngSec, "\\d{2}\\.\\d+");
					latLng[1] = Util.match(latlngSec, "-\\d+.\\d+");
					U.log("latlong" +latLng[0] );
					U.log("latlong" + latLng[1] );
					lat=latLng[0];
					lng=latLng[1];
					geo = "FALSE";
			}
			String note=ALLOW_BLANK;
			if (comUrl.contains("https://www.tilsonhome.com/texas-grand-ranch")) {
				add[0]="107 Dedication Trail";
				add[1]="New Waverly";
				add[2]="TX";
				add[3]="77340";
				note="Address Taken From Community Description";
				lat=null;
			}
			if(lat==null || lat==ALLOW_BLANK){
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				 lat= latLng[0];
				 lng=latLng[1];
				 geo="True";
			}
			if(comUrl.contains("https://www.tilsonhome.com/vintage-oaks")){
				add = new String[]{"1110 Vintage Way", "New Braunfels", "TX", "78132"};
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				lat= latLng[0];
				lng=latLng[1];
				note="Address Taken From Community Description";
				geo = "TRUE";
			}
			String plandata=ALLOW_BLANK;
//			String modeldata= U.getSectionValue(html, "<div class=\"py-lg-5 py-3\" id=\"model-home\">", ">EasyBuy℠ Financing</div>");
			String plans[] = U.getValues(html, "<div class=\"row no-gutters pt-4\">", "See Details <i class=");
			for(String sec :plans) {
				String purl = U.getSectionValue(sec, "regular\" href=\"", "\"");
				U.log("plandata"+purl);
				String planHtml = U.getHTML("https://www.tilsonhomes.com"+purl); 
				plandata += U.getSectionValue(planHtml, "ADD TO FAVORITES</span>", "SCHEDULE A MODEL TOUR</span>");
			}
			//floorplanpricesqftseccol-md-6 col-lg-4 pb-4
			String floorurls[]=U.getValues(html, "col-md-6 col-lg-4 pb-4", "VIEW FLOOR PLAN");
			String secf=null;
			if(floorurls!=null) {
			for(String f:floorurls) {
				String furl="https://www.tilsonhomes.com"+U.getSectionValue(f, "<a href=\"", "\"");
//				U.log("floordata ::"+furl);
				String fhtml=U.getHtml(furl, driver);
				String rmSec = U.getSectionValue(fhtml, "<h6 class=\"sub-head\">Plans You May Love</h6>", "</html");
//				U.log(rmSec.length());
				fhtml = fhtml.replace(rmSec, "");
				fhtml = U.removeSectionValue(fhtml, "<h6 class=\"sub-head\">Plans You May Love</h6>", "</html");
				secf+=U.getSectionValue(fhtml, "<div class=\"col-sm-12 col-lg-4 model-detail-bg d-flex align-items-center text-center justify-content-center pt-5 pb-5 px-1\"", "<a aria-label=\"Change County\"");
				
			}
			}
			
			String secre=U.getSectionValue(html, "<div class=\"model-stat py-2\">", "</div>");
			if(secre!=null) {
				html=html.replace(secre, "");
				plandata =plandata.replace(secre, "");
				secf=secf.replace(secre, "").replaceAll("\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</div>", "");
			}
			// sqfeet values
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			U.log(html.contains("1,331 Sq. Ft."));
			html= html.replace("2,000 Sq. Ft. of Concrete", "");
			//U.log("MMMMM"+Util.matchAll(html, "[\\w\\s\\W]{30}1,425[\\w\\s\\W]{30}", 0));
			String[] sqft = U.getSqareFeet((html), "\\d{1},\\d{3} Sq.Ft.|\\d{4} Sq.Ft.|\\d,\\d{3} Sq.Ft.|\\d,\\d{3} Sq. Ft.", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			
//			if(comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/georgetown/georgetown/5007/")
//					||comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/bryan/bryan/5006/")||
//					comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/san-marcos/san-marcos/5011/")
//					||comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/weatherford/weatherford/5014/"))minSqf="1224";
			
			
			//pricessection
			String minPrice=ALLOW_BLANK;
			String maxPrice=ALLOW_BLANK;
			String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			if(secf!=null) {
			U.log("secf :" +secf); 
			prices=U.getPrices(secf, "\\$\\d{3},\\d{3} |- \\$\\d{3},\\d{3}", 0);
			}
			minPrice=prices[0];
			maxPrice=prices[1];
			
			
			if(comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/georgetown/georgetown/5007/")) {
				minPrice=ALLOW_BLANK;
				maxPrice=ALLOW_BLANK;
			}
//				if(comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/spring/spring/5012/"))minSqf="1394";	
			if(minPrice==null)minPrice=ALLOW_BLANK;
			if(maxPrice==null)maxPrice=ALLOW_BLANK;
			if(minSqf==null)minSqf=ALLOW_BLANK;
			U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(secf, "[\\s\\w\\W]{30}\\$2[\\s\\w\\W]{30}", 0));

			
			// Type, pType and dType
			//html=U.getNoHtml(html);
//			html=html.replaceAll("ranch|Ranch", "");
			String Type=U.getCommunityType(html);
			
			String newsSec[] = U.getValues(html, "<h2>Latest News from Tilson</h2>", "</div>");
			
			for(String news : newsSec) {
				
				html = html.replace(news, "");
			}
			
			String pType=U.getPropType(U.getNoHtml(html).replaceAll("Builder For Your Custom Home|Custom Home Builder|BUILDER FOR YOUR CUSTOM HOME|Right Builder for Your Custom Home|builder for your custom home", ""));
			U.log("pType=="+pType);
			String dType=U.getdCommType((html+commName).replace("builder in Texas Grand Ranch. ", ""));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html+commName, "[\\s\\w\\W]{30}ranch[\\s\\w\\W]{30}", 0));
			U.log("dType=="+dType);
			
			if(commName.contains("Texas Grand"))commName="Texas Grand Ranch";
			add[0]=add[0].replace(" (Exit #406)", "");
 	           	if(comUrl.contains("https://www.tilsonhomes.com/new-homes/tx/huntsville/texas-grand-ranch/5219/")) dType = "Ranch";

 	       	String counting=ALLOW_BLANK;
 			String startDt=ALLOW_BLANK;
 			String endDt=ALLOW_BLANK;  	
 	           	
			data.addCommunity(commName, comUrl,ALLOW_BLANK);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice.trim(),maxPrice.trim());
			data.addLatitudeLongitude(lat.trim(), lng.trim(),geo);
			data.addPropertyType(pType,dType);
			data.addPropertyStatus(ALLOW_BLANK);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
			i++;
			
		}  
		} 

}
