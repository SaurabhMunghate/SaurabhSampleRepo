package com.shatam.b_161_180;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.sun.jna.platform.win32.COM.COMUtils;

public class TropicanaHomes extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static int j = 0;
	String geo;
	static CommunityLogger LOGGER;
	static String Builder_name = "Tropicana Homes";
	static String HOME_URL = "https://www.tropicanahomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new TropicanaHomes();
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "Tropicana Homes.csv", a
				.data().printAll());
	}

	public TropicanaHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER=new CommunityLogger(Builder_name);
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.tropicanahomes.com/communities");
/*		String sec = U.getSectionValue(html, "<div class=\"community-listing\">",
						"<div class=\"clearboth\">");
		String region[] = U.getValues(sec, "href=", "/p>");
*/		String region[] = U.getValues(html, "<div class='community-listing'>", "VISIT COMMUNITY PAGE</a>");
		
		for (String sec1 : region) {
			adDetails(sec1);
		}
		LOGGER.DisposeLogger();
	}

	public void adDetails(String sec) throws Exception {
//		if (j == 2) 
		{
			U.log("Count :"+j);
//			U.log(sec);
			String url = HOME_URL + U.getSectionValue(sec, "\"", "\"");
			U.log(url);
			
			//TODO:
		//	if(!url.contains("https://www.tropicanahomes.com/tres"))return;
			
			String name = U.getSectionValue(sec, "'community-listing__title'>", "</h3>").replace("ñ", "n").replace("Sue??os", "Suenos").toLowerCase();
			name=name.replace("Tres", "Tres Suneos");
			U.log("name :"+name);
			String commHtml = U.getHTML(url);
			String address = U.getSectionValue(commHtml, "</b><br/>",
					"</div><div");

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			if (address != null) {
//U.log(address);
				address = address.replaceAll("N/A - Coming Soon", "").replace("Woolstone, 79928<br/>", "Woolstone,");
				String adds[] = address.replace("<br/>", ",").split(",");
				add[0] = adds[0];
				add[1] = adds[1];
				add[2] = adds[2].replaceAll("[^\\x00-\\x7F]", "")
						.replaceAll("\\d+|�|\\s+", "").toUpperCase();
				add[3] = com.shatam.utils.Util.match(adds[2], "\\d{5}");
				if (add[2].trim().length() > 2) {
					add[2] = USStates.abbr(add[2]);
				}
			}
			U.log(Arrays.toString(add));
			commHtml = commHtml.replace("106.1961", "-106.1961");
			String latsec = U.getSectionValue(commHtml, "LatLng(", ")");
			U.log("latsec::" + latsec);
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			if (latsec != null)
				latLong = latsec.split(",");
			geo = "False";
			commHtml = commHtml.replace("&#8217;", "'");
			commHtml = commHtml.replaceAll("0&#39;s|0k’s", "0,000");
			commHtml = commHtml.replace("0s", "0,000");

			commHtml = commHtml.replaceAll("0's|0’s", "0,000");

			// U.log("****************"+U.getCache(commHtml));
//			 if(!url.contains("https://www.tropicanahomes.com/peyton-estat"))return;
			sec = sec.replaceAll(" \\$(\\d{3})K\\+", " \\$$1,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U
					.getPrices(
							commHtml+sec,
							"\\$\\d+,\\d+|low \\d+,\\d+| starting from the \\d+,\\d+|to the mid \\d+,\\d+| in the \\d+,\\d+|living from the \\d+,\\d+",
							0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String plansHtml = "";
			String[] plansUrls = U.getValues(commHtml,
					"<a href=\"/floorplans/", "\"");
			for (String planurl : plansUrls) {
				//U.log("planurl : " + planurl);
				String tempHtml=U.getHTML("https://www.tropicanahomes.com/floorplans/"
						+ planurl);
				plansHtml = plansHtml
						+ U.removeSectionValue(tempHtml, "name=\"keywords\"", "\">");

			}

			String[] sq = U.getSqareFeet(commHtml + plansHtml+sec,
					"\\d{4}\\+ square feet|\\d+,\\d+ sq. ft. to over \\d+,\\d+|\\d{4} Sq. Ft.", 0);
			minSqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
			maxSqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			if (add[2].length() < 2)
				add[2] = ALLOW_BLANK;
			if (add[3] == null)
				add[3] = ALLOW_BLANK;
			U.log(latLong[0]);

			if (add[1] == ALLOW_BLANK)
				geo = ALLOW_BLANK;
			if (add[0].length() < 4)
				add[0] = ALLOW_BLANK;

			if ((add[3] == ALLOW_BLANK || add[0] == ALLOW_BLANK)
					&& latLong[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLong);
				if(add1 == null) add1 = U.getAddressHereApi(latLong);
				if(add[3] == ALLOW_BLANK) add[3] = add1[3];
				if(add[0] == ALLOW_BLANK) add[0] = add1[0];
				geo = "True";
			}
			if (add[2] == ALLOW_BLANK)
				add[2] = "TX";
			if (url.contains("signature")) {
				add[0] = "HWY 375";
				add[1] = "East El Paso";
				latLong = U.getlatlongGoogleApi(add);
				String[] addr = U.getAddressGoogleApi(latLong);
				add[3] = addr[3];
				geo = "true";
			}

			commHtml = commHtml
					.replaceAll(
							"Ranch'>|Ranch</option>|Ranch&quo|Dessert Golf Course<br>|Cinemark Theatre now open|_Traditional",
							"");
			// U.log(commHtml);
			String remMeta = U.getSectionValue(commHtml,
					"<meta name=\"keywords\"", "\">");
			// U.log("=="+remMeta);
			commHtml = commHtml.replace(remMeta, "");
			commHtml=U.removeSectionValue(commHtml, " <meta name=\"keywords\"", "\">");
			
			commHtml = commHtml.replaceAll("<p>Traditional </p>|<p>Traditional</p>", "<p>Traditional Homes </p>");
			String propType = ALLOW_BLANK;
			propType = U.getPropType((commHtml + plansHtml).replaceAll("loft\"|Estilo Villa Ahumada|Tampachoa", ""));

			U.log("Property type:::" + propType);
			//propType = propType + "Traditional Homes";
			String propStatus = U.getPropStatus(commHtml + plansHtml+sec);

			// ====================from image patio and loft adding in property
			// type============
			if (url.contains("https://www.tropicanahomes.com/emerald")
					|| url.contains("https://www.tropicanahomes.com/puesta")
					|| url.contains("https://www.tropicanahomes.com/horizonhills")||url.contains("https://www.tropicanahomes.com/mesquite")||url.contains("https://www.tropicanahomes.com/tres")) {
				if (propType.contains("Traditional Homes")) {
					propType = propType + ",Patio homes";
				}
			}
			if(url.contains("https://www.tropicanahomes.com/horizonhills")||
					url.contains("https://www.tropicanahomes.com/sierradelpuerte"))propStatus="Few Homes Available";
			if(url.contains("leonor-estates"))propStatus = "Now Open";
			
			if(url.contains("https://www.tropicanahomes.com/emerald-heights")) propStatus = "Coming Soon"; //From Image
			
//			if(url.contains("https://www.tropicanahomes.com/hidden-village")) propStatus = "Coming Soon, Grand Opening";
			U.log("Property type:::" + propType);
			add[1]=add[1].replace("Near Clint High School", "Clint");
			if(data.communityUrlExists(url))
			{
				k++;
				LOGGER.AddCommunityUrl("Repeated************"+url);
				return;
			}
			if(url.contains("https://www.tropicanahomes.com/tres"))name="Tres Suenos";
			String dtype=U.getdCommType(commHtml);
			if(Arrays.toString(plansUrls).contains("weston"))
				dtype ="1 Story, 2 Story";
			
			
			LOGGER.AddCommunityUrl(url);
			data.addCommunity(name, url, U.getCommunityType(commHtml));
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPropertyType(propType,
					dtype); //+" 2 stories "
			data.addPropertyStatus(propStatus);
			data.addNotes(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
			
		}
		j++;
	}
}