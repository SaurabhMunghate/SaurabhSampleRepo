/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_181_200;

import java.io.IOException;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractBaldwinSons extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractBaldwinSons()
			throws Exception {
		super("Baldwin & Sons","www.baldwinsons.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Baldwin & Sons");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractBaldwinSons();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Baldwin & Sons.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("http://www.baldwinsons.com/");
		String[] sec=U.getValues(mainHtml,"views-field views-field-title","/h5>");
		for(String aSec:sec)
		{
			String url="http://www.baldwinsons.com"+U.getSectionValue(aSec, "<a href=\"","\"");
			addDetail(url,aSec);
		}
		
	}

	private void addDetail(String comUrl,String dataSec) throws Exception {
		// TODO Auto-generated method stub
		//if(!comUrl.contains("http://www.baldwinsons.com/portfolio/enclave-otay-ranch-apartments"))return;
		
				U.log("commUrl-->"+comUrl);
						String html=U.getHTML(comUrl);
						/*String rem=U.getSectionValue(html, "project_next one columns\">","</body>");
						html=html.replace(rem,"");*/
						//============================================Community name=======================================================================
						String communityName=U.getSectionValue(dataSec, "<h5>","<");
						communityName = communityName.replaceAll("Apartments$", "");
						U.log("community Name---->"+communityName);
						
				//================================================Address section===================================================================
						String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
						String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
						String geo="FALSE";
						String note="";
						String addSec=U.getSectionValue(html, "Sales Office</a>","<li><strong>");
						
						if(addSec!=null)
						{
						addSec=addSec.replace("<li>|</li>","");
						add=U.findAddress(addSec);
//						note="Address Taken From Home";
						}
						else
						{
							add[0]="20 Corporate Plaza ";
							add[1]="Newport Beach";
							add[2]="CA";
							add[3]="92660";
							geo="TRUE";
							note="Address Taken From Contact";
						}
						
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
						
				//--------------------------------------------------latlng----------------------------------------------------------------
						// Given address is home address not community address so geo code is true
						String latLngSec = U.getSectionValue(html, "https://www.google.com/maps/place/", "\"");
						if(latLngSec == null)
							latLngSec = U.getSectionValue(html, "https://www.google.com/maps?", "\"");
						if(latLngSec != null){
							String latLngVals = U.getSectionValue(latLngSec, "@", ",17z");
							if(!latLngSec.contains("@"))
								latLngVals = U.getSectionValue(latLngSec, "ll=", "&amp;z");
							latlng = latLngVals.split(",");
						}else{
							latlng=U.getlatlongGoogleApi(add);
							geo="TRUE";      
						}
						U.log("hhhh--->"+latlng[0]+"  "+latlng[1]);
						
						
					
				//============================================Price and SQ.FT======================================================================
							
						String url=U.getSectionValue(html, "button color launch\"","Visit Website");
						String webHtml="";
						String homeGHtml="";
						if(url!=null)
						{
							U.log(url);
							url=U.getSectionValue(url, "href=\"","\"");
							U.log(url);
							webHtml=U.getHTML(url);
							homeGHtml=U.getHTML(url+"/available-homes");
						}
						String homeHtml="";
						if(homeGHtml!=null)
						{
							String[] hUSec=U.getValues(homeGHtml, "<div class=\"three columns item\">","<div class=\"item-info\">");
							for(String hu:hUSec)
							{
								homeHtml=homeHtml+U.getHTML(url+U.getSectionValue(hu,"<a href=\"","\""));
							}
						}
						
						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
						
						html=html.replaceAll("0�s|0's|0&#8217;s","0,000");
						String prices[] = U.getPrices(html+homeHtml+homeGHtml,"\\$\\d+,\\d+ range|from \\$\\d+,\\d+", 0);
						
						minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
						maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
						
						U.log("Price--->"+minPrice+" "+maxPrice);
						
				//======================================================Sq.ft===========================================================================================		
						
						
						String[] sqft = U
								.getSqareFeet(
										html+homeHtml+homeGHtml,
										"\\d+,\\d+ to \\d+,\\d+ square feet|\\d+,\\d+ sq. ft",
										0);
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						U.log("SQ.FT--->"+minSqft+" "+maxSqft);
						
				//================================================community type========================================================
						html = html.replaceAll("&amp; Apartment Communities", "");
						String communityType=U.getCommType(html+homeGHtml+homeHtml);
						
				//==========================================================Property Type================================================
						
						String proptype=U.getPropType(html+homeGHtml);
						
				//==================================================D-Property Type======================================================
						
						String dtype=U.getdCommType(html+homeGHtml+homeHtml);
						
				//==============================================Property Status=========================================================
						html=html.replace("Release:</strong> Summer 2017","Release Summer 2017");
						String pstatus=U.getPropStatus(html);
						
				//============================================note====================================================================
						
						// note=U.getnote(html);

						
						if(data.communityUrlExists(comUrl))
							{
							LOGGER.AddCommunityUrl(comUrl);
							k++;
							return;
							}
							data.addCommunity(communityName,comUrl, communityType);
							data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(proptype, dtype);
							data.addPropertyStatus(pstatus);
							data.addNotes(note);
						j++;
	}

}
