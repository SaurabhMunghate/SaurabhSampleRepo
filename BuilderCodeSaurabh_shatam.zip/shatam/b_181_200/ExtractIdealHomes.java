/** @author Rakesh
 *  @date 02/08/2013 
 */

package com.shatam.b_181_200;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractIdealHomes extends AbstractScrapper {
	int i = 0;
	static int j=0;
	static int k = 0;
	public int inr = 0;
	private WebDriver driver = null;
	CommunityLogger LOGGER ;


	public static void main(String[] ar) throws Exception {
		

		AbstractScrapper a = new ExtractIdealHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ideal Homes.csv", a.data().printAll());
	}

	public ExtractIdealHomes() throws Exception {
		super("Ideal Homes", "https://www.idealhomes.com/");
		LOGGER = new CommunityLogger("Ideal Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHtml("http://www.idealhomes.com/new-homes", driver);
		
//		html = U.getSectionValue(html, "<div class=\"fyh-filters\">", "map id=\"communities\"");
//		
//		String[] communitiesUrl = U.getValues(html, "<li ng-repeat=\"com in communitiesService", "</ul></div>");
		String[] communitiesUrl = U.getValues(html, "<div class=\"css-hm9jf4", "</div></div></div></div></div>");
		U.log(communitiesUrl.length);
		
		for (String communitySec : communitiesUrl) {
			
			String communityUrl = "http://www.idealhomes.com/"
						+ U.getSectionValue(communitySec, "href=\"/","\"");
				communityUrl=communityUrl.replace("&amp;", "&");
				
//				try {
					addInfo(communityUrl, communitySec);
//				} catch (Exception e) {}
				
//				break;
		}
		
		LOGGER.DisposeLogger();	
    	driver.quit();
		
	}		
			
	//===============================New code by upendra=================================
	
	private void addInfo(String communityUrl, String comInfo) throws Exception{
		
//		if(j >=12)
//		if(!communityUrl.contains("borhoods/harrah/the-woodlands")) return;

	{
//	{
		
		//TODO :
		U.log("Count "+j+"==== communityUrl -->"+communityUrl);
	
		
		
		
		
		
		if(data.communityUrlExists(communityUrl)){
			LOGGER.AddCommunityUrl(communityUrl+"<=========== Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(communityUrl);
		
		//U.log(communityUrl);
		String html = U.getHtml(communityUrl, driver);
		String Desc=U.getSectionValue(html, "Description</h3>", "</div></div>");//</p></div>
		String newDesc=U.getSectionValue(html, "Floor Plans</h3>", "Photo Gallery</h3>");
	//	if(Desc!=null)
//		Desc=Desc.replaceAll("</span><span class=\"PlanCard_iconListLabel\"", "&");
		Desc=Desc+newDesc;
//		U.log(newDesc);
		
		
		communityUrl = U.getRedirectedURL("http://www.idealhomes.com/",communityUrl);
		
//		if(!communityUrl.contains("https://www.idealhomes.com/neighborhoods/moore/featherstone"))return;
		
		U.log("Count :"+j);
		
		
		U.log("Final Url : "+communityUrl);
	//==========================Community name========================================
//		String communityName = U.getSectionValue(comInfo,"<h4 class=\"ng-binding\">", "</h4>");
		String communityNameSec = U.getSectionValue(comInfo,"<h4 class=\"CommunityCard_name\" data-reactid=", "!-- /react-text -->");
//		U.log(communityNameSec);
		String communityName = U.getSectionValue(communityNameSec,"-->", "<");
		U.log(communityName);
		
		
		
		String remove = U.getSectionValue(html, "window.__PRELOADED_STATE__", "</script>");
		if(remove != null){
			U.log("******** Script removed **********");
			html = html.replace(remove, "");
		}
//		U.log(Desc);
//		U.log("MMMMMMM "+Util.matchAll(Desc, "[\\s\\w\\W]{300}Featherstone features a playground[\\s\\w\\W]{30}", 0));
	//===============================address section + Latlong Sction====================================
		html=html.replaceAll("scope\">model home:", "");
		//U.log(html);
		String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
		String latlngSec="";
		String geo = "FALSE";
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//		String latlngSec=U.getSectionValue(html,"\"geo\":{\"@type\"","hasMap");
//		U.log("latlng:::"+latlngSec.length());
//		if(latlngSec.length()<4)
		latlngSec=U.getSectionValue(comInfo, "<a href=\"https://www.google.com/maps/place/", "/@");
		U.log("latlng:::"+latlngSec);
		if(latlngSec!=null)
		{
//			U.log("latlngSec:::"+latlngSec);
//			latlng[0]=U.getSectionValue(latlngSec,"latitude\":\"", "\"");
//			latlng[1]=U.getSectionValue(latlngSec, "longitude\":\"","\"");
//			if(latlng[0].length()<4) {
//				latlng[0]=Util.match(latlngSec, "\\d{2}.\\d{5,}");
//				latlng[1]=Util.match(latlngSec, "-\\d{2}.\\d{5,}");
//			}
			latlng=latlngSec.split(",");
//			String addSec=U.getSectionValue(html, "model home", "<");
			String addSec=U.getSectionValue(html, ">Model Home:", "<a href=\"#map\""); // //>Map</a>
			U.log("addSec::::::"+addSec);
			if(addSec!=null && !html.contains("<div ng-show=\"descriptioned\" class=\"popup ng-hide\">")){
				addSec=addSec.replaceAll("2629 NW 186th Street, 19232 Blanco Drive and |in Fountain Grass today, at | in Buffalo Grove today at |today, at |In Somers Pointe | in Sundance today at | in Traden Heights ", "");
				addSec = addSec.replaceAll(" in Somers Pointe|s at 2116 NW 182nd Street, 2629 NW 186th Street, 19232 Blanco Drive and|s at 2116 NW 182nd Street,| 19232 Blanco Drive and 2664 NW 181st Street in |s at ", "");
				addSec = addSec.replace(" in Edmond", ", Edmond");
				U.log("if addSec::::::"+addSec);
//				addSec=addSec.replace(" in�",",");
				addSec=addSec.replaceAll("</strong>|<!-- react-text: \\d{3} -->|<!-- /react-text -->", "").replace(" | ", ",");
				U.log("if addSec::::::"+addSec);
				add=U.getAddress(addSec);
//				String[] myAdd=addSec.split(",");
//				if(myAdd.length==3){
//					add[0]=myAdd[0];
//					add[1]=myAdd[1];
//					add[2]=Util.match(myAdd[2], "\\w+");
//					add[3]=Util.match(myAdd[2], "\\d+");
//					
//					if(add[2].trim().length()>2){
//						add[2]=USStates.abbr(add[2]);
//					}
//				}
			}
			else{
				add=U.getAddressGoogleApi(latlng);
				if(add == null) add =U.getAddressHereApi(latlng);
				geo="TRUE";
			}
			U.log("My add :::"+Arrays.toString(add));
		}
		
		else
		{
			comInfo=comInfo.replaceAll("<span ng-if=\"com.address.addressRegion\" class=\"ng-binding ng-scope\">","");
			comInfo=U.removeComments(comInfo);
			comInfo=comInfo.replace("<!-- end--><!---->,","");
			U.log("new cominfo "+comInfo);
			
			
			add[1]=U.getSectionValue(comInfo, "class=\"ng-binding ng-scope\">","</span>");
			add[2]=U.getSectionValue(comInfo, "</span>","</span>");
			latlng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlng);
			if(add == null) add =U.getAddressHereApi(latlng);
			
			U.log("latlong : "+latlng[0]+"  "+latlng[1]);
			U.log("address : "+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			geo="TRUE";
		}
		
		if(add[1].length()<4)
		{
			add=U.getAddressGoogleApi(latlng);
			if(add == null) add =U.getAddressHereApi(latlng);
			geo="true";
		}
		if(communityUrl.contains("https://www.idealhomes.com/neighborhoods/norman/little-river-trails"))
		add[0]="N Porter Ave";
		//==================Individual Move in Home Data==============
		String movePlanHtml="";
				int checkMoveCount = 0;
				String allMoveInData = ALLOW_BLANK;
				String[] movePlanurls = U.getValues(html, "<div class=\"HomeCard_wrapper\"", "</div></div></div>"); //U.getValues(html, "class=\"result-wrapper\" href=\"", "\"");
				U.log("total move in homes :: " + movePlanurls.length);
				int notSoldCount = 0;
				for(String movePlanUrlSec : movePlanurls){
					String movePlanUrl = U.getSectionValue(movePlanUrlSec, "<a class=\"\" href=\"", "\"");
					movePlanUrl = "http://www.idealhomes.com"+movePlanUrl.replace("&amp;", "&");
//					U.log("movePlanUrl:::::::::::::::"+movePlanUrl);
					if(movePlanUrl.contains("p=13&inv")){
						checkMoveCount++;
						if(movePlanUrlSec.contains("\" alt=\"\" "))notSoldCount++;
					}
					movePlanHtml = U.getHtml(movePlanUrl, driver);
					if(movePlanHtml==null)movePlanHtml=ALLOW_BLANK;
					String ss=U.getSectionValue(movePlanHtml, "<div class=\"AccordionToggle_content", "</div></div></div>")
							+U.getSectionValue(movePlanHtml, "<div class=\"DetailOverview\"", "</div></div></div>");
					
					if (ss!=null && ss.contains("Luxurious Master Suite")) {
					
						U.log("FOND");
						
					}
					allMoveInData = U.getSectionValue(movePlanHtml, "<div class=\"AccordionToggle_content", "</div></div></div>")
							+U.getSectionValue(movePlanHtml, "<div class=\"DetailOverview\"", "</div></div></div>")+allMoveInData;
				}
		
//				================================All Homes data=================================
				String homeHtml="";
				String avaHomeHtml="";
				String allhomeData="";
				String homedataSec=U.getSectionValue(html, ">Plans to Build</h3>", ">Photo Gallery</h3>")+U.getSectionValue(html, ">Homes Available Soon</h3>", ">Photo Gallery</h3>");
			//	U.log(homedataSec);
				String[] homeUrls=U.getValues(html, "<div class=\"PlanCard_wrapper\"", "</div></div></div>");
				U.log("Total build Homes:"+homeUrls.length);
					 for(String homeUrl:homeUrls) {
							homeUrl="https://www.idealhomes.com"+U.getSectionValue(homeUrl, "<a class=\"\" href=\"", "\"");
							U.log("homeUrl: "+homeUrl);
							homeHtml=U.getHtml(homeUrl, driver);
							homeHtml=homeHtml.replaceAll("This 4 bedroom home with a split floorplan and large", "").replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">", " ");         //.replace("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=", "");
							allhomeData+=U.getSectionValue(homeHtml, "<h1 class=\"DetailOverview_heading\"", "</li></ul><div")
									+U.getSectionValue(homeHtml, ">Description</h3>", "</p>");
//							allhomeData=allhomeData.replace("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">", " ");
							
						}
					 if(html.contains(">Homes Available Soon</h3>")) {
						 String[] avahomeUrls=U.getValues(homedataSec, "<div class=\"HomeCard_media\" data-reactid=", "data-reactid");
						U.log("Total availHomes:"+avahomeUrls.length);
							 for(String homeUrl:avahomeUrls) {
									homeUrl="https://www.idealhomes.com"+U.getSectionValue(homeUrl, " href=\"", "\"");
									U.log("homeUrl: "+homeUrl);
									avaHomeHtml=U.getHtml(homeUrl, driver);
									avaHomeHtml=avaHomeHtml.replaceAll("This 4 bedroom home with a split floorplan and large", "").replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">", " ");         //.replace("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=", "");
									allhomeData+=U.getSectionValue(avaHomeHtml, "<div class=\"AccordionToggle_content", "</div></div></div>")+U.getSectionValue(avaHomeHtml, "<div class=\"DetailOverview\"", "</div></div></div>");
//									allhomeData=allhomeData.replace("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">", " ");
									
								}
					 }
						
						
						
//======================================price Sectioin================================
		String priceSqftSec=U.getSectionValue(html, "<div class=\"col-lg-6 col-xl-5 order-lg-1\" data-reactid=", "<div class=\"DetailOverview_sectionWrapper DetailOverview_sectionWrapper-btns\" data-reactid=")
				+U.getSectionValue(html, ">Homes Available Soon</h3>", ">Photo Gallery</h3>")
		+U.getSectionValue(html, "</script><script data-react-helmet=\"true\"", "address\":");
//		if(html.contains(">Homes Available Soon</h3>")) {
//			priceSqftSec=priceSqftSec+U.getSectionValue(html, ">Homes Available Soon</h3>", ">Photo Gallery</h3>");
//		}
		
		//U.log(priceSqftSec);
		String price[] ={ALLOW_BLANK,ALLOW_BLANK};
		html = html.replace("type\":\"GatedResidenceCommunity", "");
		remove = U.getSectionValue(html, "Similar Communities</h3>", "<div class=\"Footer_nav\"");
		if(remove != null) html = html.replace(remove, "");
		
		price= U.getPrices(html+comInfo, "\\$\\d+,\\d+",
				0);
		String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice);
		U.log(maxPrice);
		
//=====================================SqFt Section=================================
		
		String sqft[]={ALLOW_BLANK,ALLOW_BLANK};
		
		String sec1="";
		
		
		
		sec1=U.getSectionValue(html, "\"DetailOverview_sectionWrapper\"", "</span></div></div>");
		if(sec1 != null) sec1 = sec1.replaceAll("SqFt: <!-- /react-text --><!-- react-text: \\d+ -->(\\d?,?\\d{3})<!-- /react-text -->", "SqFt: $1 ");
		
//		U.log("&&&&&&&&&&&&&&&&&&&&&&&&"+newDesc);
		
//		Desc=Desc.replaceAll("data-reactid=\"\\d+\">", "").replace("</span><span class=\"PlanCard_iconListLabel\" ", "");
		sqft = U.getSqareFeet((sec1+priceSqftSec+comInfo+allMoveInData+Desc),
				"\\d,\\d{3} sq ft of living space to \\d,\\d{3}|Sqft: \\d{3}|\\d{3}</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">SQ FT|SqFt: (\\d,)?\\d{3} |-->\\d{1},\\d{3}<!-- /react-text -->|-->(\\d,)?\\d{3}<!--|>\\d,\\d{3}</span><span|\\d,\\d{3} to \\d,\\d{3} square feet|SqFt:</span> \\d,\\d{3}|SqFt:</span> \\d+|SqFt <strong class=\"ng-binding\">\\d,\\d{3}|SqFt <strong class=\"ng-binding\">\\d{3}", 0);
		
	String	minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
	String	maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];https://www.idealhomes.com/neighborhoods/
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//----homeSec------//
		String home=U.getSectionValue(html,"","");

		
//===================================Status Section=================================
		

		html = html.replaceAll("most premiere lots available|status == 'Sold Out' --><ul|Move|move|community.status \\=\\= 'Coming Soon'\">Coming Soon</div>|community.status \\=\\= 'Coming Soon'", "").replace("lots are selling fast", "lots selling fast");
		String status=ALLOW_BLANK;
		html=html.replace("community.status == 'Coming Soon'", "");
		html=html.replace("new section will be coming soon (Spring 2022) ","new section coming soon Spring 2022");
		comInfo=comInfo.replaceAll("<!-- ngIf: com.status == '(.*?)' -->|'Coming Soon'", "");
		String htm=U.getSectionValue(html, "</script><script data-react-helmet=\"true\"", "address\":");
		
		Desc=Desc.replace("New homes are available now", "New homes now available").replace("New homesites are now</b><b>&nbsp;available", "New homesites now available");
//		U.log(Desc);
		String CommDesc=U.getSectionValue(html, "<div class=\"col-lg-8 mb-5 mx-auto\" data-reactid=\"898\"><div data-reactid=\"899\">", "");
		
		
		Desc =Desc.replace("new section will be coming soon (Spring 2022) ", "new section coming soon Spring 2022").replace("New homes and homesites are now available","New homesites are now available").replace("New homesites are now available", "New homesites now available").replace("New homes are currently available", "New homes currently available");
		

		
		status = U.getPropStatus((comInfo+htm+Desc+CommDesc)
				.replace("New section of home sites for you to custom build coming soon!", "New section coming soon")
				.replace("New homes in Harrah are coming Spring 2022", "")
				.replace("new homesites coming later in 2022", "new homesites coming in 2022")
				.replace("new section is coming soon", "new section coming soon").replace("cul-de-sac  are now available", "cul-de-sac now available").replace("New homes are now available", "New homes now available").replaceAll("Bison Creek is Coming Soon", ""));
		
		U.log("status: "+status);
//		U.log("MMMMMMM "+Util.matchAll(comInfo+htm+Desc+CommDesc, "[\\s\\w\\W]{30}Home Sites[\\s\\w\\W]{30}", 0));
//		if(communityUrl.contains("borhoods/harrah/the-woodlands")) {
//			status="coming spring 2022";
//		}
//		if(communityUrl.contains("mustangyukon/somers-pointe")) {
//			status="New Section Coming Soon";
//		}//frm image
		//if(communityUrl.contains("https://www.idealhomes.com/neighborhoods/harrah/the-woodlands"))status="Coming Soon";//frm Image				}
		U.log("notSoldCount :"+notSoldCount);
		U.log("checkMoveCount :: "+checkMoveCount);
		if(notSoldCount == 0) checkMoveCount = 0;
		if(checkMoveCount > 0){
			if(status.length()<4){
				 status = "Move-in Ready Homes";
			}
			else{
				status = status + ", Move-in Ready Homes";
			}
		}
		
		
		
//================================Propety Type section=================================
		
		
		
//		U.log(Util.matchAll(html, ".*apartment.*",0));
//		String htm=U.getSectionValue(html, "</script><script data-react-helmet=\"true\"", "address\":");
		
		//|Orwell Farmhouse
//		U.log("MMMMMMM "+Util.matchAll(Desc, "[\\s\\w\\W]{30}custom[\\s\\w\\W]{30}", 0));borhoods/harrah/the-woodlands
		Desc=Desc.replace("custom build", "Custom Home");
		
		if(allMoveInData!=null)
			allMoveInData = allMoveInData.replace("Craftsman style 3 bedroom home", "Craftsman-style homes 3 bedroom home").replace("Mountain Cottage", "Cottage").replace(">Craftsman</strong>", "Craftsman Style Homes");
		allhomeData=allhomeData.replaceAll(">Mountain Cottage<|>Craftsman</", "");
//		htm = htm.replace("Farmhouse</div>", "classic farmhouse design");
		String rem = "We threw out traditional|Quinlan Farmhouse|Abernathy Farmhouse|Jacobson Farmhouse|Prescott Farmhouse|Farmhouse elevation|Farmhouse feel|Gillcrest Farmhouse";
		String pType=U.getPropType((htm+comInfo+allMoveInData+allhomeData+Desc).replace("Traditional</strong>", "Traditional exterior").replace("Farmhouse</strong>", "classic farmhouse design").replaceAll(rem, "").replaceAll("traditional feel|The traditional 2-car|We threw out traditional|taste is more traditional|more traditional |This plan is perfect for transitioning from apartment dwelling|participation|more traditional (feel|or)|traditional to modern",""));
	//	U.log("MMMMMMM "+Util.matchAll(htm+comInfo+allMoveInData+allhomeData+Desc, "[\\s\\w\\W]{30}Traditional[\\s\\w\\W]{30}", 0));
		U.log(":::::::::::::::::::::::::::::::::::::::::::"+pType);

		
		//==================================Community type=================================
		
		String CType=U.getCommunityType(htm+comInfo);
		
//===================================D-Prop- Type===============================
//		String dtype=U.getdCommType(html.replaceAll("Canyon Ranch", "")+comInfo);
		
//		String htm=U.getSectionValue(html, "</script><script data-react-helmet=\"true\"", "address\":");
		if(allMoveInData != null) 
			allMoveInData = allMoveInData.replaceAll(">(\\d)</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">Story</span>", " $1 Story ");
//		U.log("allMoveInData ::"+allMoveInData);
		String dtype=U.getdCommType(htm+comInfo+allhomeData + allMoveInData);
//====================================Notes======================================
		
		String note=U.getnote(html);
		
		//---------------------hardcoded because value nt present in cache------------------//
		
		if(communityUrl.contains("http://www.idealhomes.com/page.php?p=3&com=5702a904f410954eb27cd990")){
			pType="Patio Homes";
			status="Move-in Ready Homes";
			minSqf="2026";
		}
		
		if(communityUrl.contains("http://www.idealhomes.com/page.php?p=3&com=5702a903f410954eb27cd986")){
			pType="Patio Homes";
			minSqf="1127";
			maxSqf="2136";		
			}
		if(communityUrl.contains("http://www.idealhomes.com/page.php?p=3&com=5702a905f410954eb27cd993")){
			dtype="Ranch";	
			}
		if(communityUrl.contains("https://www.idealhomes.com/neighborhoods/norman/trail-woods"))minSqf="994";
		//if(communityUrl.contains("/neighborhoods/blanchard/oasis-ranch"))note="New Homes For Sale";
		if(data.communityNameExists(communityUrl)) {
			LOGGER.AddCommunityUrl(communityUrl+"==============Repeated==================");
			return;
		}
		
		
//		if(communityUrl.contains("https://www.idealhomes.com/neighborhoods/norman/trail-woods"))
//			status=ALLOW_BLANK;https://www.idealhomes.com/neighborhoods/
		
		LOGGER.AddCommunityUrl(communityUrl);
		
		  // ------------------ No. of units ------------------------
	     String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addCommunity(communityName, communityUrl, CType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latlng[0], latlng[1],geo);
		data.addPropertyType(pType,dtype);
		data.addPropertyStatus(status);https://www.idealhomes.com/neihttps://www.idealhomes.com/neighborhoods/ghborhoods/
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
	}	
		j++;
	}
//}
	
}
	
	
	
	