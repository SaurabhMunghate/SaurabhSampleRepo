/** @author
 *  @date 2/07/2012 
 */

package com.shatam.b_181_200;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPayneFamilyHome extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	private final static String builderUrl = "https://www.paynefamilyhomes.com"; 
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractPayneFamilyHome();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Payne Family Homes.csv", a.data()
				.printAll());

	}

	public ExtractPayneFamilyHome() throws Exception {

		super("Payne Family Homes", "https://www.paynefamilyhomes.com/");
		LOGGER = new CommunityLogger("Payne Family Homes");
	}

	public void innerProcess() throws Exception {

		String html = U
				.getPageSource("https://www.paynefamilyhomes.com/neighborhood/");
		U.log(U.getCache("https://www.paynefamilyhomes.com/neighborhood"));
		String temp=U.getSectionValue(html, "<section class=\"slam_section bg-beige \">", "</section>");
		//U.log(temp);
		String values[] = U.getValues(html, "<div class=\"bux_single_sub col-xs-12 col-sm-4 col-md-3 bx_plan\" ", "</dl>");
		//U.log(Arrays.toString(values)+"$$$$$$$$$$$$$");
	U.log(values.length);
		//int totalComm = values.length / 2;
		for (int i = 0; i < values.length; i++) {
			//U.log(values[i]);
			String url = U.getSectionValue(values[i], "href=\"", "\" ");
			url= url.replace("&amp;", "&");
			if(!url.startsWith("http"))
				url = "https://www.paynefamilyhomes.com"+url;
			
			addDetails(url, values[i]);
			k++;
			inr++;
		}
		LOGGER.DisposeLogger();
	}

	//TODO:
	private void addDetails(String url, String info) throws Exception {
//		if(j == 15)
		{
		//	if(!url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Pinewoods-Estates"))return;
		
			//if(url.contains("http://www.paynefamilyhomes.com/comm_overview.php?com=52"))return;
			U.log(j+"\nPAGE :" + url);
			String html = U.getPageSource(url);
			String rmsec = U.getSectionValue(html, "console.log({\"subdivision_id\":", "})</script>");
			if(rmsec!=null)html = html.replace(rmsec, "").replaceAll("\\d Story\\s*</op", "");
			if(data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+"<=========== Repeated");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(url);
			
//			U.log("info is:" + info);
			// commName
			String commName = U.getSectionValue(html, "vanity_name_label\">", "<");
//			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/the-villages-of-provence/"))commName ="The Villages of Provence";
			String note = ALLOW_BLANK;// U.getCommNotes(html);
			
			commName = commName.replaceAll("- Final Closeout|-Final Closeout|- Closeout| Villas", "");
			
			U.log(commName);
		
			if(commName.contains(",")){
				String name1 = commName.substring(commName.indexOf(",")+1);
				String name2 = commName.substring(0, commName.indexOf(","));
				commName = name1+" "+name2;
			}
			
			
			//---------------------- address
			
			
			
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "False";
			// U.log("visiting ::" + "http://www.paynefamilyhomes.com" + dHtml);
		
			String ad = U.getSectionValue(html, "Address:", "<br/>");

			// U.log(ad);
			if (url.contains("comm_overview.php?com=56"))
				ad = "7 Reservoir Ct" + ",Eureka, MO, 63025";
			if (ad != null) {
				//U.log(ad);
				ad=ad.replace("Traveling E or W on Hwy 364, take exit 2 to Bryan Road. You'll see Cordoba at the roundabout", "");
				ad=ad.replaceAll("Sold From Konert Lake Estates( in Fenton)?|Display:|Sold from Shady Creek|Sold from Montrachet|Sold from Bella Vista|Selling from our Newest Community, Riverdale!|Sold from","");
				
				ad = U.formatAddress(ad);
				
				ad = ad.replace("Ct,.", "Ct").replace(",,",",").replace("Street, Crossing", "Street Crossing").replace("Rd. Arnold", "Rd, Arnold").replace(",.", "")
						.replaceAll("Sold fromHuntleigh Ridge", "");
				ad=ad.replace("O'Fallon,",",O'Fallon,");
				ad=ad.replaceAll(",\n,|,\\s+,",",").replace(", 0", ", ,");
				U.log("AddSec::"+ad);
				if(ad.split(",").length > 3)
					add = ad.split(",");
				if(ad.split(",").length==3) {
					add=U.findAddress(ad);
				
				}
			}
			
			if(add[0]==ALLOW_BLANK) {
				ad=U.getSectionValue(html, "Directions", "</b>");
				ad=ad.replace("Cottleville", "Cottleville,").replaceAll("MO,", "MO ").replace("103 Stone Arch Street, St Charles 63301", "103 Stone Arch Street, St Charles, MO 63301").replace("Eureka MO ", "Eureka, MO ").replace("Display:", "").replaceAll(" Sold from |Shady Creek|at|Main Street Crossing", "");
				U.log("adresssection::::::::::::"+ad);
				add=U.findAddress(ad);
			}//3550 W Clay St, St Charles, MO 63301, USA
			if(add==null) {
				add=new String[]{ ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			}
			if(url.contains("/pinewoods-estates/")) {
				ad=U.getSectionValue(html, "Directions", "Hours");
				ad=ad.replace("Cottleville", "Cottleville,").replace("Wentzville", "Wentzville,").replaceAll("MO,", "MO ").replaceAll(" Sold from |Shady Creek|at|Main Street Crossing|Display: ", "");
				//U.log("adresssection::::::::::::"+ad);
				add=U.findAddress(ad);
			}
			if(url.contains("/alexander-woods/")) {
				
				ad = U.getSectionValue(html, "<a href=\"https://goo.gl/maps/WM7Mrgpbiin\">", "</a>").replace("<br>", ",");
				add=U.findAddress(ad);
				geo = "TRUE";
			}
			U.log("Add:"+Arrays.toString(add));

			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				String addSec = U.getSectionValue(html, "address\":\"", "\",");
				if(addSec != null){
					addSec = addSec.replace("<br>", ",");
					add = U.getAddress(addSec);
					//U.log("Add:"+Arrays.toString(add));

				}
			}
			// lat
			
			String lat = U.getSectionValue(html, "lat: ", ",");
			String lng = U.getSectionValue(html, "lng: ", "}");
			
			U.log(lat + "," + lng);
			if(add[1].length()<4 && lat != ALLOW_BLANK){
				String lats[]= {lat,lng};
				add=U.getAddressGoogleApi(lats);
				if(add == null) add = U.getAddressHereApi(lats);
				geo="TRUE";
			}
			
			// price
			// price
			String homeSec = U.getSectionValue(html, "<h3 class=\"section-title text-center\">",	"</section>");
			String homeHtml="";
			String check="";
			if(homeSec!=null)
			check=Util.match(homeSec, "\\s*\\n*\\s*<a href=.*\\s*\\n*\\S*\" title");
			//U.log("lllllllll"+check);
			if(check!=null)
			{
			String url1=U.getSectionValue(check, "<a href=\"","\"");
			//U.log("lllllllll"+url1);
			if(url1!=null)
			homeHtml=homeHtml+U.getHTML(url1);
			}
		
			String florUrl = U.getSectionValue(html, "<li class=\"plans\"><",	">");
			
			florUrl = U.getSectionValue(html, "a href=\"", "\"");
			//U.log("florUrl : "+florUrl);
			String floorHtml = U.getSectionValue(html, "Quick Move Homes\n" + 
					"                </h3>", "<div id=\"viewHome\"");
			if(floorHtml != null){
				String[] floorUrls = U.getValues(floorHtml, "<a href=\"", "\"");
				for(String floorUrl : floorUrls){
					String fHtml = U.getHTML(floorUrl);
				}
					
			}
//			===============================Homes====================================
			String homeUrl[] = U.getValues(html, "<a class=\"link-to-card-detail\" href=\"",	"\"");
			U.log(homeUrl.length);
			String quickHomeData=ALLOW_BLANK;
			if(html.contains("<a class=\"link-to-card-detail\" href=\"")){
				for(String hurl : homeUrl){
						U.log(hurl);
					 quickHomeData += U.getSectionValue(U.getHTML(hurl.replace("&amp;", "&")), "<div id=\"new_description_link\">", "</div>")+U.getSectionValue(U.getHTML(hurl.replace("&amp;", "&")), "<div class=\"row clearfix bx_lot_row\">", "<div class=\"bux_single_sub clearfix");
				}
					
			}
//			U.log(quickHomeData);
			String[] priHtml=U.getValues(homeHtml, "<div class=\"mod_text\">","<div class=\"mod_btns\">");
			String currectPrice="";
			for(String sec:priHtml)
			{
				if(sec.contains("Reduced Price:"))
				{
					sec=sec.replace("&#36;", "$");
					sec=sec.replaceAll("<span>\\s+Price:\\s*</span>\\s*\\$\\d{3},\\d{3}\\s*</h5>","");
				}
				currectPrice=currectPrice+sec;
			}
//			U.log(info);
			quickHomeData=quickHomeData.replace("314,058", "").replace("514,608", "").replace("759,801", "").replace("409,262", "").replace("714,514", "").replace("231,233", "").replace("171,853", "").replace("713,090", "").replace("$497,354", "").replace("$367,387", "").replace("$760,276", "");
			html=html.replace("757,829", "").replace("314,058", "").replace("514,608", "").replace("759,801", "").replace("409,262", "").replace("714,514", "").replace("231,233", "").replace("171,853", "").replace("713,090", "").replace("$453,267", "").replace("0k's", "0,000").replace("$500k", "from the mid $500,000").replaceAll("Base Price:\\s*</dt>\\s*<dd>\\s*\\$\\d{3},\\d{3}|class='strikethrough'>\\s*\\$\\d{3},\\d{3}\\s*</dd>|class=\"strike-price\">\\s+<dt>\\s+Price:\\s+</dt>\\s+<dd>\\s+\\$\\d{3},\\d+", "").replaceAll("0's", "0,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			String[] price = U
					.getPrices(
							(currectPrice+ html + info+quickHomeData).replace("upper $500k's", "upper $500,000").replaceAll("class='strikethrough'>\\s*\\$\\d{3},\\d{3}\\s*</dd>", "").replace(
									"&#36;", "$"),
							"upper \\$\\d{3},\\d{3}|from the Low \\$\\d{3},\\d{3}|from the Low $200k's|>\\s*\\$\\d{3},\\d{3}\\s*-\\s*\\$\\d{3},\\d{3}\\s*<|from the mid \\$\\d{3},\\d{3}|Price:\\n*\\s*</strong>\\n*\\s*\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Red. Price</dt><dd>\\$\\d{3},\\d{3}|Base Price\\n*</dt>\\n*\\s*<dd>\\n*\\s*\\$\\d{3},\\d{3}| the \\$\\d{3},\\d{3}|priced from the \\$\\d+,\\d+|\\$\\d+,\\d+ - \\$\\d+,\\d+|Price:\\s*</span>\\s*\\$\\d{3},\\d{3}\\s*</h5>|Price Range:\\s*</span>\\s*\\$\\d+,\\d+ to \\$\\d+,\\d+|Reduced Price:\\s*</span>\\s*\\$\\d{3},\\d{3}\\s*</h5>|<dd>\\s*\\$\\d{3},\\d{3}\\s*</|Reduced Price:\\s*</dt>\\s*<dd>\\s*\\$ \\d{3},\\d{3}|reduced_price_value\">\\s*\\$\\d{3},\\d{3}\\s*</dd>",0);
			//U.log(">>>>>>>>>>>"+Util.matchAll(quickHomeData, "[\\s\\w\\W]{50}497,354[\\s\\w\\W]{50}",0));
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							floorHtml + html + homeHtml+info,
							"<dd>\\s*\\d,\\d{3} - \\d,\\d{3}\\s*</dd>|Sq. Footage:\\s*</strong>\\s*\\d{4}\\s*-\\s*\\d{4}|from \\d,\\d{3} – \\d,\\d{3} square feet|Square Footage:\\n*\\s*</strong>\\n*\\s* \\d,\\d{3} to \\d,\\d{3}|Square Footage:\\n*\\s*</strong>\\n*\\s*\\d,\\d{3} - \\d,\\d{3}|ranging from \\d,\\d{3} sq. ft. to over \\d,\\d{3} sq. ft.|\\d,\\d+ to over \\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ square feet|\\d,\\d+ to nearly \\d,\\d+ sq|\\d{1}\\,\\d{3} to \\d{1}\\,\\d{3} sq.ft. The Villages|\\d{1}\\,\\d{3} to \\d{1}\\,\\d{3} sq.ft. for more information|\\d,\\d+ to nearly \\d,\\d+ sq. ft|\\d,\\d+ to nearly \\d,\\d+ sq. ft|from \\d,\\d+ to just over \\d,\\d+ square feet|\\d,\\d+-\\d,\\d+|\\d+,\\d+ to nearly \\d+,\\d+ square feet|Square Feet:\\s*</span>\\s*\\d+,\\d+|\\d+ to nearly \\d+ sq. ft|from \\d+,\\d+ to nearly \\d+,\\d+ sq. ft|Sq. Ft.:\\s*</span>\\s*\\d+,\\d+|SQFT Range:\\s*</span>\\s*\\d+,\\d+ to \\d+,\\d+|from \\d+,\\d+ to upwards of \\d+,\\d+ square feet|data-sq_ft=\"\\d{4}|data-sqft=\"\\d{4}\"|Sq Ft:\\s+</dt>\\s+<dd>\\s+\\d,\\d{3}",
							0);
			
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			U.log("lat :" + lat + " longi :" + lng);
			html=html.replace("luxurious, convenient,", "luxury home").replaceAll("detached\\s*<strong>\\s*carefree villas", "detached carefree villas");
			String pType = U.getPropType((html.replaceAll("lfloor-condo|Pointe Villas|uxury options|consisting of luxury|Each luxurious", "many luxury features").replace("custom build", "custom-style homes") + floorHtml+quickHomeData).replaceAll("floor-condo|village|Village|hoa|quality and craftsmanship", "")).replaceAll("^Townhouse, ", "");
			html=html.replace("frac12"," 1.5 Story ");
			
			//U.log(html);
			html=html.replaceAll("one-and-a-half or two-story|:</strong>\\s*Closeout|one and half and two-story"," 1.5 Story  2 Story ");
			homeHtml=homeHtml.replace("Stories:</span> 1"," 1 Story ");
			String dType = U.getdCommType((html + floorHtml+homeHtml+quickHomeData).replaceAll("\\d Story\\s*</option>|floor-ranch|Ranch Homes for Sale|colonial wainscot|floor|Floor|content=\".*\"", ""));
			U.log(Util.matchAll(html + floorHtml+homeHtml+quickHomeData, "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}", 0));
			String Type = U.getCommunityType(U.getNoHtml(html));

			//=========== Property Status ==============
			String status = ALLOW_BLANK;
			html = U.getPageSource(url);
			
			String statSec = html + info;
			statSec = statSec.replace("New Display Now Open", "Now Open")
					.replace("final 4 Quick Close Homes are now available", "final Homes now available");
			String remove = ":</strong> \n\\s+Closeout|Final Closeout is underway|rapidly selling|Guarantee Now|Bordeaux Condominiums in Cottleville Selling Fast|Just Released!\"|Currently Sold from Pinewoods|ust 3 Phase II Home Sites Available|To-be-built home sites are sold out|oods Coming Soon\"|content=\"coming soon\"|nt=\"Coming soon to Chesterfield|Now Open and selling fast! Learn more\"|our Homes Ready now |Bella Vista - Final Closeout|Final Closeout\"|Bella Vista &#8211; Final Closeout|Display: Coming Soon!|Now Available in St|content=\"coming soon|nnounce Village Point, coming soon!|Copper Creek - Closeout|content=\"Coming Soon|<b>\\s*Coming Soon|Learn more about this limited|garages home sites are available|your final opportunity|Decorated Display Home Now Open| during the Grand Opening|condos coming soon|Stunning Move[-| ]*In Ready Home[s]*|\"move in ready homes\"|Homes Ready Now|homes ready now|Car Garage Home Sites Now Available!|on the final opportunities|Ready Home Available for Immediate|Coming soon... new community pool|2 New Display Homes NOW OPEN|Display Now Open|Display now open|text-link-pop\"><span>Coming Soon!<|We will be hosting our Grand Opening in April|Vintage Grove-Coming Soon!|DISPLAY NOW OPEN|Now Selling!</a>|-Now Selling|Now Selling!\\s*</h|Heritage Crossing-SOLD OUT!|Belleau Creek-Now Selling!|we have move in ready|lots|CONSTRUCTION COMING|link-pop\">\\s+<span>\\s+Coming|Hours: </span>Coming|ontent=\"Now Selling! P|Newly Released Home Sites Selling Quickly at Invernes|Sold from Alexande";
			
			statSec = statSec.replaceAll(remove, "").replaceAll("Decorated Displays Now Open|FINAL CLOSEOUT UNDERWAY|</strong>\\s*Closeout|Move-In Ready Hamilton|townhomes are now available|Currently Sold from Inverness in Dardenne|Take your pick of \\d+ new home sites just released and selling fast|The Streets of Caledonia Coming Soon|cursive;\">\n\\s+<span>\n\\s+Coming Soon|</h2>|Coming Soon! The Streets|</strong>\n\\s+\n\\s+Closeout|<dd>\n\\s+Closeout\n\\s+</dd>|Priced from: </strong> Closeout <br/> <strong>|Closeout\\s+</p>|Fexciting grand|Valley - Closeout|Vista - Final Closeout|Copper Creek - Closeout| Knoll-Final Closeout|Closing Out", "").replaceAll("e, ing Phase  3|Now Selling Phase  3", "Now selling phase 3");
			statSec = statSec.replace("are available", "available").replace("choice home sites available", "").replace("grand opening of our new", "").replace(
					"Phase III lots now open", "Phase III now open").replace("Coming 2018... new community pool!", "").replace(" Final Close Out", "FINAL CLOSE OUT")
					.replaceAll("Now Selling Phase  3", "Now Selling Phase 3").replace("final phase of this community is", "final phase").replaceAll("Phase I home sites are now available", "Phase I homesites now available");
			
			U.log(">>>>>>>>>>>"+Util.matchAll(statSec, "[\\s\\w\\W]{150}Now Open[\\s\\w\\W]{150}",0));
			
			status = U.getPropStatus(statSec + commName).replace("is rapidly selling out", "Selling Out");
			U.log("status : " + status);
			status=status.replace("Iii","III");
			status=status.replace("Ii","II");
//			U.log(Util.match(html, ".*Phase  3.*"));
			if(add[0].contains("Selling from The Grove at Belleau Creek!") || add[0].contains("By Appointment Only"))
			{
				add[0]=ALLOW_BLANK;
			}
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Pevely-Farms"))commName="Pevely Farms";
			String latlng[] = { lat, lng };
			if (add[0] == ALLOW_BLANK || add[2].length()<2) {

				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo="True";
			}
			
			if (add[0].length() < 3)
				add[0] = ALLOW_BLANK;
			
			if (html.contains("<a class=\"link-to-card-detail\" href=\"")) {
				status=status.replace(", Move-in Ready Homes Available", "").replace(", Move-in Ready", "");
				if (status == ALLOW_BLANK) {
					status = "Quick Move In";
				} else {
					status = status + ", Quick Move In";
				}
			} else {
				/*if (status == ALLOW_BLANK) {
					status = "Quick Move In";
				} else {
					status = status + ", Quick Move In";
				}*/
			}
			if(homeHtml.contains("There are no inventory found at this time"))
			{
				if(html.contains("Coming Soon!"))
				{
					status=status.replace(", No Quick Move In", "");
				}
				
			}

			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]
					+ " Z:" + add[3]);
			add[0]=add[0].toLowerCase().replaceAll("Sold by Consulting Team|Selling From Pevely Farms!".toLowerCase(), ALLOW_BLANK);
			add[3]=add[3].replace("Hours: Mon: 11:30-5; Tues-Sat: 10-5; Sun: 11-5", "");
			if (lat != ALLOW_BLANK && (add[0] == ALLOW_BLANK|| add[0].length()<4)) {
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo="True";
			}
			if(lat.length()<4) {
				String ll[]=U.getlatlongGoogleApi(add);
				lat=ll[0];
				lng=ll[1];
				geo="True";
			}
			status=status.replace("Move-in Ready, Quick Move In", "Quick Move In");
			if(url.contains("/shady-creek/")) {status= status.replaceAll("Now Available", "Phase II Now Available");}
			LOGGER.AddCommunityUrl(url);
			add[0]=add[0].replace(".","");
			statSec = statSec.replace("amp;", "");
			
//			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Talamore-Square"))status += ", Grand Opening";
			
			if(url.contains("ttps://www.paynefamilyhomes.com/neighborhood/village-point/"))status=status+", Now Selling";		
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/copper-creek-manor/"))status=status.replace("Closeout", "Final Close Out");		
			String notes = U.getnote(statSec);
			if(url.contains("/?action=detail&sid=4959")) {
				status = status.replace("Home Sites Available", "Phase II Home Sites Available").replaceAll("Now Selling", "Now Selling Phase 3");
			}
			U.log(add[0].contains("Point St.")+add[0]);
			if(add[0].contains("point st") || add[0].contains(" street st") || add[0].contains(" drive st")) {
				U.log("hllooooooooooo i am in");
				add[0]=add[0].replace(" drive St", " drive").replace(" street st", " street").replace(" point st", " point");
				add[1]="St. "+add[1];
			}
			if(html.contains("(ranch, 1.5 and 2 story homes") && !dType.contains("Ranch"))dType=dType+", Ranch";
			status = status.replace("Move-in Ready, Limited Availabilities Remain, Quick Move In", "Limited Availabilities Remain, Quick Move In")
					.replace("Newly Released Home Sites, Selling Fast", "Newly Released Home Sites Selling Fast")
					.replace("Final Opportunities Now Available, Now Available", "Final Opportunities Now Available");
			if(status.contains("New Home Sites Just Released, Just Released"))status=status.replace("New Home Sites Just Released, Just Released", "New Home Sites Just Released");
			
			
			if(status.contains("Final Opportunities Now Available, Final Opportunities,"))
			status=status.replace("Final Opportunities,", "Final Opportunities Now Available,");
			//notes = notes.replace("Pre-construction Pricing Now Available", "Pre-construction Pricing");
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Bordeaux"))
				status += ", FHA Financing Available, Final Opportunities Remain";
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Pinewoods-Estates"))status+=", 32 New Homesites Just Released";
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Sandfort-Farm"))
				pType +=",  Homeowner Association";
//			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/The-Bluff"))
//				status=status+", Final Closeout";
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Legends-Pointe"))
				if(!pType.contains("Detached Home"))
			pType=pType+", Detached Home, Villas";
			status=status.replace("Final Opportunities Remain, Quick Move In, FHA Financing Available, Final Opportunities Remain", "Final Opportunities Remain, Quick Move In, FHA Financing Available");
			status = status.replaceAll("Just Released, New Home Sites Just Released", "New Home Sites Just Released").replace("Just Released, 30 New Home Sites Just Released", "30 New Home Sites Just Released");
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/detail/Cordoba"))minPrice=ALLOW_BLANK;
			pType=pType.replace(", Townhouse, Townhome", ", Townhome");
			data.addCommunity(commName.trim().toLowerCase(), url, Type);
			data.addAddress(add[0].replace(",", "."), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status.replace("Final Opportunities Now Available, Final Opportunities Now Available", "Final Opportunities Now Available").replace("-,", ""));
			data.addNotes(notes);
			// TODO Auto-generated method stub
		}
	j++;
	}
}