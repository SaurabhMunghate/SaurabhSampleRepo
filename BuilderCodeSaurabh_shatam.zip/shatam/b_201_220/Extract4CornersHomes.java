/** @author 
 *  @date 10/05/2012 
 */
package com.shatam.b_201_220;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import javax.swing.text.FlowView;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class Extract4CornersHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int k = 0;
	public int inr = 0;
	static int duplicates = 0;
	static int j = 0;
	WebDriver driver = null;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new Extract4CornersHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/4Corners Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public Extract4CornersHomes() throws Exception {
		super("4Corners Homes", "https://www.4cornershomes.com/");
		LOGGER = new CommunityLogger("4Corners Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
//		if (driver == null){
//		 driver = new ChromeDriver();
//		}
//		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
//		String html = U.getHtmlWithChromeBrowser("https://www.4cornershomes.com/",driver);
		String html = U.getHtml("https://www.4cornershomes.com/",driver);
		
		String[] regionUrl = U.getValues(html, "<div class=\"cyl-text\">", "<div class=\"ng-binding\">");
		
		for(String regionUrls:regionUrl) {
			  regionUrls=U.getSectionValue(regionUrls, "href=\"", "\"");
			  regionUrls="https://www.4cornershomes.com"+regionUrls+"/communities";
//		  U.log("regionurls===================================================================================> "+regionUrls); 
			  String regionHtml=U.getHtml(regionUrls, driver);
			  String commURLS[]=U.getValues(regionHtml, "<div class=\"comm-thumb\">", "ui-sref=\"");
			  String regionPriceHtml = U.getHTML("https://api2.mybuildercloud.com/api/v1/communities?where={%22published%22:true,%22builder%22:%22570d21eaf410954eb27d3e22%22}&max_results=9999");
			  		  U.log(regionPriceHtml);
			  U.log(commURLS.length);
			  for (String commURL : commURLS) {
				  commURL="https://www.4cornershomes.com"+U.getSectionValue(commURL, "href=\"", "\"");
	//2			  U.log(commURL);
				//  U.log(U.getCache(commURL));
				  addDetails(commURL,regionPriceHtml);
			  }
			  LOGGER.AddRegion(regionUrls, commURLS.length);
		}
		LOGGER.DisposeLogger();	
		driver.quit();
	}

	//TODO ::
	private void addDetails(String commURL, String regionPrice) throws Exception {
//	if(j == 13)
		{	
			//if (!commURL.contains("https://www.4cornershomes.com/find-your-home/oklahoma-city/communities/siena")) return;
			U.log(U.getCache(commURL));
			//if(commURL.equals("https://www.4cornershomes.com/find-your-home/oklahoma-city/communities"))return;
//			if(commURL.contains("https://www.4cornershomes.com/find-your-home/tulsa/communities"))return;
			U.log(j+" Community URL: "+commURL);
			 
			if(data.communityUrlExists(commURL)){
				LOGGER.AddCommunityUrl(commURL+"****************repeated*************");
				return;
			}
			LOGGER.AddCommunityUrl(commURL);
			
			String commHtml=getHtml(commURL, driver);
			U.log(U.getCache(commURL));
			String geo="FAlSE";
			String note=ALLOW_BLANK;
			String commSec=U.getSectionValue(commHtml, "<div class=\"modal-dialog \">", "modal-backdrop");
		//U.log(commSec);
			String commName=U.getSectionValue(commSec, "<h3 class=\"ng-binding\">", "</h3>");
			U.log("Community Name: "+commName);
			String lat=null,lon=null;
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			if (commSec.contains("<span>Get</span> Directions</a>")) {
				String latlonSec=U.getSectionValue(commSec, "maps.google.com", "target");
				lat=U.getSectionValue(latlonSec, "?q=", ",");
				lon=U.getSectionValue(latlonSec, ",", "\"");
				//U.log(latlonSec);
			}
			String addSec=U.getSectionValue(commSec, "</h3><span class=\"ng-binding\">", "</span></div>");
			U.log(addSec);
			add=U.getAddress(addSec.replace("Kansas City", ", Kansas City").replace("Broken Arrow", ", Broken Arrow").replace("Oklahoma City", ", Oklahoma City"));
			if (add[0]==ALLOW_BLANK&&commHtml.contains("Visit Furnished Model")) {
				addSec=U.getSectionValue(commHtml, "Visit Furnished Model <span class=\"ng-binding\">", "</span>");
				add=U.getAddress(addSec.replace("<br>", ","));
			}
			U.log(Arrays.toString(add));
			U.log(lat+"    "+lon);
			if (lat!=ALLOW_BLANK&&add[1]==ALLOW_BLANK) {
				String[] latlng={lat,lon};
				add=U.getAddressGoogleApi(latlng);
//				if(add == null) add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo="TRUE";
			}
			if (lat!=ALLOW_BLANK&&add[0]==ALLOW_BLANK) {
				String[] latlng={lat,lon};
				String add1 [] = U.getAddressGoogleApi(latlng);
				
				if(add1 == null) add1 = U.getAddressHereApi(latlng);
				add[0]=add1[0];
				geo="TRUE";
			}
			U.log(Arrays.toString(add));
			String availHTML=ALLOW_BLANK;
			String availHomeSec=U.getSectionValue(commSec, "<h4>Available Homes</h4>", "Floor Plans");
			//U.log(availHomeSec);
			if (availHomeSec!=null) {
				String[] availHomes=U.getValues(availHomeSec, "ng-repeat=\"chome in community.homes ", "</li>");
				U.log(availHomes.length);
				for (String availHome : availHomes) {
					String availUrl=U.getSectionValue(availHome, "href=\"", "\"");
					availUrl="https://www.4cornershomes.com"+availUrl;
					U.log("Available Homes URl "+availUrl);
					String temphtml=U.getHtmlWithChromeBrowser(availUrl, driver);
					availHTML+=U.getSectionValue(temphtml, "<div class=\"modal-dialog \">", "modal-backdrop");
					if (availHTML.contains("patio")) {
						U.log("FOUND");
					}
				}
			}
			String floorHTML=ALLOW_BLANK;
			String floorHomeSec=U.getSectionValue(commSec, "<h4>Floor Plans</h4>", "community.sitePlan");
			if (floorHomeSec!=null) {
				String[] floorHomes=U.getValues(floorHomeSec, "<div class=\"floor-thumb\">", "</a>");
				U.log(floorHomes.length);
				for (String floorHome : floorHomes) {
					String floorUrl=U.getSectionValue(floorHome, "href=\"", "\"");
					floorUrl="https://www.4cornershomes.com"+floorUrl;
					U.log("Floor Homes URL "+floorUrl);
					//U.log(U.getCache(floorUrl));
					String temphtml=U.getHtmlWithChromeBrowser(floorUrl, driver);
					floorHTML+=U.getSectionValue(temphtml, "<div class=\"modal-dialog \">", "modal-backdrop");
				}
			}
			String minPrice,maxPrice, price[]={ALLOW_BLANK,ALLOW_BLANK};
			String minSqft,maxSqft,sqft[]={ALLOW_BLANK,ALLOW_BLANK};//ng-scope">$284,800</span>
			
			U.log(regionPrice);
			String[] priceSec = U.getValues(regionPrice, "\"@type\": \"GatedResidenceCommunity\",", "\"sitePlan\": {");
			String mapPrice =  "";
			for(String pp : priceSec ) {
				
				if(pp.contains(commName)) {
					mapPrice = pp;
					break;
				}
			}
			
			price=U.getPrices(mapPrice+floorHTML+commSec.replace("00's", "00,000").replace("0s", "0,000")+availHTML, "\"priceLow\": \\d{6}|From:  \\$\\d{3},\\d{3}</li>|range from \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|class=\"ng-binding\">\\$\\d{3},\\d{3}|binding\">\\$\\d{3},\\d{3}|ng-scope\">\\$\\d{3},\\d{3}</span>", 0);
			
			sqft=U.getSqareFeet(floorHTML+commSec+availHTML, "\">\\d,\\d{3} SQ. FT</span>|ng-binding\">\\d,\\d{3} sqft</span>| \\d,\\d{3}\\+ square feet", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log(minPrice+"  "+maxPrice);
			U.log(minSqft+"  "+maxSqft);
			//U.log(floorHTML);
			add[0]=add[0].toLowerCase();
			String pstatus=U.getPropStatus(commSec.replaceAll("The Meredith - Coming Soon|The Clayton - Coming Soon|Community Sports Court - Coming Soon", ""));
			String commtype=U.getCommunityType(commHtml+commSec);
			
			//==============Dtype from PDF===========================================
			
			
			String dType=U.getdCommType(floorHTML.replaceAll("Reverse 1.5 Story|REVERSE 1.5 STORY", "Reverse-one-half-Story")+commSec+availHTML);
//			if(commURL.contains("/des-moines/communities/wilkie-place")||commURL.contains("/communities/heritage-at-grimes"))dType=dType+", 2 Story";
			
			
			
			note=U.getnote(commSec);
			commSec = commSec.replace("Estate Series</div>", "Estate Homes Series</div>")
					.replace("HOA: $", " HOA : $");
			
			if(floorHTML != null) floorHTML = floorHTML.replace("luxury space with", "luxury homes space with");
//			U.log(floorHTML);
			String proptype=U.getPropType((commSec+availHTML+floorHTML).replaceAll("multi-generational bonus|luxury (kitchen|countertops|counters|backsplash)|trash bin this luxury space", "").replaceAll("on traditional style and architecture", "traditional-style brick homes"));
			if(commURL.contains("ty/communities/cambria-heights")) {proptype=proptype.length()>2?proptype+", Craftsman Style Homes":"Craftsman Style Homes";}//Img
//			if (commURL.contains("https://www.4cornershomes.com/find-your-home/oklahoma-city/communities/the-lakes-at-westminster")) pstatus = "Coming Soon";//Img
			if(commURL.contains("/communities/riverstone")) {minSqft="2400";maxSqft="2440";}
			
			
			if(commURL.contains("https://www.4cornershomes.com/find-your-home/oklahoma-city/communities/cambria-heights"))
				proptype=proptype.replace(", Craftsman Style Homes", "");
			

			if(commURL.contains("https://www.4cornershomes.com/find-your-home/oklahoma-city/communities/talavera"))
				proptype=proptype+", Patio Homes";
			
			
			

			data.addCommunity(commName.replace("-",""),commURL, commtype);
			data.addLatitudeLongitude(lat, lon,geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dType);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
		}
		j++;
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new ChromeDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));/*
					driver.manage()
							.addCookie(
									new Cookie("visid_incap_612201",
											"gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"));*/
					driver.get(url);
					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); // y value '400' can
					// be
					try {
					Thread.sleep(2000);
					 WebElement click =driver.findElement(By.className("read_more"));//.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[2]/div/div[5]/div/a[1]"));
					Thread.sleep(2000);
					 click.click();
					Thread.sleep(2000);
					}catch (Exception e) {
						// TODO: handle exception
					}

					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}
