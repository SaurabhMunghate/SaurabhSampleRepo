/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_201_220;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.http.client.params.AllClientPNames;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractComstock extends AbstractScrapper{

	public ExtractComstock()
			throws Exception {
		super("Comstock","https://comstockhomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Comstock");
	}

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractComstock();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Comstock.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}
	HashMap<String, String> mapData=new HashMap<>();
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://comstockhomes.com/");
	
		//--------communities from header-----------------
		String[] headerComSections = U.getValues(mainHtml, "class=\"sub-menu-item", "</a></li");
		U.log(headerComSections.length);
		for(String headSec : headerComSections){
			String cUrl = U.getSectionValue(headSec, "<a href=\"", "\"");
			String name=U.getSectionValue(headSec, "sub-menu-link\">", "<");
			addDetails(cUrl,name,headSec);
			mapData.put(cUrl, headSec);
		}
				
		
		//------------All communities from footer--------------
		String[] footerComSec = U.getValues(mainHtml, "<div class=\"footer_two_", "</div>");
		//U.log(footerComSec.length);
		for(String footSec : footerComSec){
			String commonStatus = U.getSectionValue(footSec, "<h2>", "</h2>");
			//U.log(commonStatus);
			String[] comSections = U.getValues(footSec, "<li><a ", "br />");
			//U.log(comSections.length);
			for(String comSec : comSections){
				String  comUrl = U.getSectionValue(comSec, "href=\"", "\"");
				
				String comName = U.getSectionValue(comSec, "\">", "<");
				//U.log("Community name::::::::::::"+comName);
				//U.log(comUrl +"<--------------->"+comName);
				addDetails(comUrl,comName,commonStatus);
				
			}
		}
		LOGGER.DisposeLogger();
		
	}

	private void addDetails(String comUrl, String comName,  String comStatus) throws Exception {
		// TODO Auto-generated method stub
//	try{
	{
		//if(!comUrl.contains("https://comstockhomes.com/property/totten-mews/"))return;
		
		if(comUrl.contains("https://comstockhomes.com/immediate-deliveries/"))return;//404 Error
		if(data.communityUrlExists(comUrl))	{
			LOGGER.AddCommunityUrl(comUrl+"********repeated*************");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		U.log(j+"  ComUrl=="+comUrl);
		U.log("comStatus-->"+comStatus);
		String html=ALLOW_BLANK;
		if(comUrl.contains("https://comstockhomes.com/property/the-towns-at-1333/"))html=U.getHTML("https://comstockhomes.com/property/the-towns-at-1333/");
		else html=U.getHTML(comUrl);
//		U.log("========== "+html);
		String rem=U.getSectionValue(html, "<head>","News</a></li>");
		if(rem != null)
			html=html.replace(rem,"");
		String rem1=U.getSectionValue(html, "<div class=\"footer\">","</body>");
		if(rem1!=null)html=html.replace(rem1,"");
	//============================================Community name=======================================================================
		String communityName=comName.toLowerCase();
		communityName = communityName.replace(" – now open!", "").replace(" – closeout","").replace(" – sold", "").replace(" – affordable rental residences", "");
		if(communityName.endsWith("condos"))communityName = communityName.replace("condos", "");
		if(communityName.endsWith("apartments"))communityName = communityName.replace("apartments", "");
		
		U.log("community Name---->"+communityName);
	//============================================note====================================================================
		//======================================Immidiate delivery Data======================================================
		//String immidiatedeliPage=U.getHTML("https://comstockhomes.com/immediate-deliveries/");
		//String statsec=U.getSectionValue(immidiatedeliPage, "<div class=\"immediate_information\">", "</table>");
		String note=U.getnote(html);				
//================================================Address section===================================================================

		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		String addSec=U.getSectionValue(html, "townes_hampshires_l_update\">","</div>");
	
		//U.log("addSec : "+addSec);
		
		if(addSec!=null)
		{
			addSec=addSec.replaceAll("<br />\\s*\\n*\\s*\\d*\\.\\d*\\.\\d*","").replaceAll("<br />\\s*\\n*\\s*<br />","</h3>").replace("COMING SOON!<br />", "</h3>").replace("<h3>SOLD OUT!<br />", "</h3>");
			//U.log("community Name---->"+communityName);
			addSec = addSec.replace("<h3>3013 ", "</h3>3013 ");
			
			addSec=U.getSectionValue(addSec, "</h3>","</h3>");
		//	U.log(addSec);
	
			if(addSec!=null)
			{
			addSec=addSec.replace("<br />",",");
			String[] add1=addSec.split(",");
			if(add1.length>2)
			{
				add[0]=add1[0];
				add[1]=add1[1];
				add[3]=Util.match(add1[2],"\\d+");
				U.log(add[3]+":::::::::::Zip");
				if(add[3]!=null){
					add[2]=add1[2].replace(add[3],"").trim();
				}
				
			}
			
			}
		}
		
		if(addSec == null && html.contains("maps/dir")){
			String myAddSec  = U.getSectionValue(html, "https://www.google.com/maps/dir//", "/@");
			U.log(myAddSec);
			if(myAddSec !=null){
				myAddSec = myAddSec.replace("%2C", ",").replace("+", " ");
				//String[] tempAdd = myAddSec.split(",");
				add = U.findAddress(myAddSec);
				
			}
		}
		
		U.log("Address---->"+add[0]+"::"+add[1]+"::"+add[2]+"::"+add[3]);
		
	
//--------------------------------------------------latlng----------------------------------------------------------------
		String latSec=U.getSectionValue(html, "https://www.google.com/maps","\"");
		U.log(latSec);
		if(latSec!=null)
		{
			String lat=Util.match(latSec, "@\\d{2,3}.\\d+");
			String lng=Util.match(latSec, "-\\d{2,3}.\\d+");
			latlag[0]=lat.replace("@","");
			latlag[1]=lng;
		}
		else{
			latSec = U.getSectionValue(html, "ll=", "&");
			if(latSec!=null){
				latlag = latSec.split(",");
				U.log(":::::::::::"+Arrays.toString(latlag)+"::::::::::::::::::");
			}
		}
		if(html.contains("var property_lat")) {
			latlag[0]=U.getSectionValue(html, "var property_lat =", ";");
			latlag[1]=U.getSectionValue(html, "var property_lng =", ";");
		}
		if(comUrl.contains("http://www.bellacollinacomstock.com/")){
			add[1] = "Montverde";
			add[2] = "FL";
			latlag = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlag);
			geo = "True";
			note = "Address & Lat-Lng Is Taken From City & State";
		}
			
		if(latlag[0] == null)latlag[0] = ALLOW_BLANK;
		if(latlag[1] == null)latlag[1] = ALLOW_BLANK;	
		
	//----------latlng from address-----------
		if(latlag[0].length()<4 && add[0].length()>4 && add[3].length()>4)
		{
			latlag = U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
	//-----------address from latlng------------
		if(add[3]==ALLOW_BLANK && latlag[0]!=null)
		{
			add[3]=U.getAddressGoogleApi(latlag)[3];
			geo="TRUE";
		}
		
		U.log("latlng is --->"+latlag[0]+"  "+latlag[1]);
	
	//---------retriving price from hashmap which contains main page data----------------
		String mainData = mapData.get(comUrl);
		U.log("mainPrice:::::::::::::"+mainData+"::::::::::::::::::");
		
//============================================Price and SQ.FT======================================================================
		
	
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html=html.replaceAll("0s|0's|0&#8217;s|0s","0,000");
		comStatus=comStatus.replace("$500s", "$500,000");
		ArrayList<String> prLst=new ArrayList<String>();
//		statsec=statsec.replaceAll("<s style=\"text-decoration: line-through\">\\$\\d{3},\\d{3}</s><", "");
//		String sec[]=U.getValues(statsec, "<td><a href=\"", "</tr");
//		for(String s:sec) {
//			U.log(s.toLowerCase()+communityName.toLowerCase().replace("the", ""));
//			if(s.toLowerCase().contains(communityName.toLowerCase().replace("the", "").trim())) {
//				prLst.add("the "+Util.match(s, "\\$\\d{3},\\d{3}"));
//			}
//		}
		U.log(prLst);
		String priceH=U.getSectionValue(html, " main-menu-link\">Immediate Deliveries</a></li>","<div class=\"footer\">");
		U.log(comStatus);
		String prices[] = U.getPrices(priceH+mainData+comStatus+prLst,"from the upper \\$\\d+,\\d+|the upper \\$\\d+,\\d+|the mid \\$\\d+,\\d+|From \\$\\d+,\\d+|high \\$\\d+,\\d+|low \\$\\d{3},\\d+|the \\$\\d{3},\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
	
//======================================================Sq.ft===========================================================================================		
	
	
		String[] sqft = U
				.getSqareFeet(
						html+mainData,
						"\\d+,\\d+ to \\d+,\\d+ square feet|up to \\d,\\d{3} square feet| with \\d,\\d{3} square feet|\\d,\\d{3} Gross Square Feet",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
	
//================================================community type========================================================
		html =  html.replace("Elongated", "");
		
		String communityType=U.getCommType(html);
	
//==========================================================Property Type================================================
		html = html.replace("Loft with optional ", " loft homes with optional ");
		String proptype=U.getPropType(html.replaceAll("The Villas at Two Rivers|villas-at-two-rivers|luxurious bath|man style garage",""));
//		U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(html , "[\\w\\s\\W]{30}luxur[\\w\\s\\W]{30}", 0));

//==================================================D-Property Type======================================================
//		html=html.replace(" fourth floor loft", " 4 story loft").replace("Spacious 3rd floor ", "Spacious 3 story floor ").replaceAll("three levels|Three-level","3 Story").replace("Four level","4 Story").replaceAll("two-level buildings| to Second floor| to second floor|off second floor|and second floors| on second floor", " 2 Story").replaceAll("ceilings on first floor|1st floor owner suites ", " 1 Story");
		//U.log(html);
		String dtype=U.getdCommType(html.replaceAll("floor|Floor|level", ""));
	
//==============================================Property Status=========================================================
		html =html.replace("<h3>SOLD OUT<br />", "");
		U.log("comStatus : "+comStatus);
		String pstatus=U.getPropStatus(comStatus+html.replaceAll("East – Closeout| – Closeout",""));
	if(comUrl.contains("https://comstockhomes.com/property/condominiums-at-richmond-station/"))
	{
		communityName="Condominiums At Richmond Station";
	}
		if(comUrl.contains("/property/woods-at-spring-ridge/"))geo="TRUE";
//		U.log(statsec.toLowerCase().contains(communityName.toLowerCase()));
//		if(statsec.toLowerCase().contains(communityName.toLowerCase().trim()) || prLst.size()>1) {
//			if(pstatus.length()>4)pstatus=pstatus+",Immediate Deliveries";
//			else pstatus="Immediate Deliveries";
//		}
		U.log("Property type::::"+proptype);
		U.log("Community type::::"+communityType);

		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
	}
	j++;
//	}catch(Exception e){}
	}

}