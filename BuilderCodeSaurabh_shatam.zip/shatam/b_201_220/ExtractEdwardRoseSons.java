/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_201_220;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;


public class ExtractEdwardRoseSons extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractEdwardRoseSons()throws Exception {
		super("Edward Rose & Sons","https://www.edwardrose.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Edward Rose & Sons");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractEdwardRoseSons();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Edward Rose & Sons.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		String mainHtml=U.getHTML("https://www.edwardrose.com/searchlisting.aspx?ftst=&txtDistance=10&cmbBeds=-1&cmbBaths=-1&renewpg=1&PgNo=1&");
		String lastPage =Util.match(mainHtml, "ResultsMap\\('paginationClick',(\\d)\\)\">Last",1);
		//U.log(lastPage);
		if(lastPage!=null)
		for(int i=2;i<=Integer.parseInt(lastPage);i++) {
			mainHtml += U.getHTML("https://www.edwardrose.com/searchlisting.aspx?ftst=&txtDistance=10&cmbBeds=-1&cmbBaths=-1&renewpg=1&PgNo="+i+"&");
		}
		String propertySec[]=U.getValues(mainHtml, "<div itemscope=\"\"", "<!-- PROP- CONTENT -->");
		U.log(propertySec.length);
		for(String prop:propertySec) {
			String comUrl =U.getSectionValue(prop, "<a href='", "?");
			String comName = U.getSectionValue(prop, "title='", "'");
			addDetails(comUrl,comName,prop);
			//U.log(comUrl);
		}
		LOGGER.DisposeLogger();
	}
	
	//TODO :
	private void addDetails(String comUrl, String communityName,String prop) throws Exception {
//		if(j >= 63)
	//	try{

		{
			
			if(comUrl==null) {
				LOGGER.AddCommunityUrl(comUrl+"**************************No Url******************"+communityName);return;
				}
			if(comUrl.contains("http:"))comUrl = comUrl.replace("http:", "https:");
			
			//======================== Single Run ===============================
		//	if(!comUrl.contains("https://www.alexandriacarmel.com"))return;

			
			
			U.log(comUrl);
			U.log(U.getCache(comUrl));
			if(comUrl.contains("www.latitudesapartments.com"))comUrl="https://www.latitudesapartments.com";

			if(comUrl.contains("javascript:void(0)")||comUrl.contains("-regional-office")){
				LOGGER.AddCommunityUrl(comUrl+"**************************Regional Offices or No Url");
				return;
			}
			if(comUrl.contains("sunscaperoanoke")) {
				LOGGER.AddCommunityUrl(comUrl+"**************************Redirected too many times");
				return;
			}
			U.log(j+"  comUrl1::::::::::::"+comUrl);
			
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+"**************************repeat");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			String html=U.getHTML(comUrl);
			
		//============================================Community name=======================================================================
			communityName = communityName.replaceAll("– Avon| – Beachwood$| – Carmel$| – Clinton Township$| Villas - Avon$", "");
			U.log("community Name---->"+communityName);
		//================================================Address section===================================================================
			//U.log(prop);
			String note="";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String mapHtml=ALLOW_BLANK;
			mapHtml = U.getHTML(comUrl+"/mapsanddirections.aspx");
			
			String addSec=U.getSectionValue(mapHtml,"<a class='address-link' ","<span class=\"phoneNumber\"");

//==
			if(addSec==null) 
				addSec=U.getSectionValue(html,"<address class=\"ysi-address\">","</address>");
//==
//			U.log("AddSec :"+addSec);
			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				add[0] = U.getSectionValue(mapHtml,"selenium-id='address_street'>" , "</span>");
				add[1] = U.getSectionValue(mapHtml, "selenium-id='address_city'>", "</span>");
				add[2] = U.getSectionValue(mapHtml, "selenium-id='address_state'>", "</span>");
				add[3] = U.getSectionValue(mapHtml, "selenium-id='address_zip'>", "</span>");
			}
//==
			if((add[0] == ALLOW_BLANK||add[0]==null) && (add[3] == ALLOW_BLANK||add[3]==null)){
				add[0] = U.getSectionValue(addSec,"selenium-id=\"address_street\">" , "</div>");
				add[1] = U.getSectionValue(addSec, "selenium-id=\"address_city\">", "</span>");
				add[2] = U.getSectionValue(addSec, "selenium-id=\"address_state\">", "</span>");
				add[3] = U.getSectionValue(addSec, "selenium-id=\"address_zip\">", "</span>");
			}
//==
			if(comUrl.contains("/copper-creek-apartment-homes"))add[0]=ALLOW_BLANK;
			if(add[1] != null) add[1] = add[1].trim().replaceAll(",", "");
			if(add[0] != null) add[0] = add[0].replaceAll("\\(Clubhouse\\)|&nbsp;", "").replace(", S,E,", " SE");
			U.log("Address---->"+add[0]+": "+add[1]+": "+add[2]+": "+add[3]);
	//--------------------------------------------------latlng----------------------------------------------------------------

			if(add[1]==null||add[2]==null) {
				add[0]=ALLOW_BLANK;
				add[1]=ALLOW_BLANK;
				add[2]=ALLOW_BLANK;
				add[3]=ALLOW_BLANK;
			}
			//U.log(mapHtml.contains("longitude"));
			latlag[0]=U.getSectionValue(mapHtml, "var latitude=\"", "\"");
			latlag[1]=U.getSectionValue(mapHtml, "var longitude=\"", "\"");
			if(latlag[0] == null){
				latlag[0]=U.getSectionValue(mapHtml, "var latitude = \"", "\"");
				latlag[1]=U.getSectionValue(mapHtml, "var longitude = \"", "\"");
			}
			if(latlag[0] == null){
				latlag[0]=U.getSectionValue(mapHtml, "latitude: \"", "\"");
				latlag[1]=U.getSectionValue(mapHtml, "longitude: \"", "\"");
			}
			if(latlag[0]==ALLOW_BLANK|| latlag[1]==null) {
				latlag[0]=U.getSectionValue(prop, "<span class=propertyLat>", "<");
				latlag[1]=U.getSectionValue(prop, "<span class=propertyLng>", "<");
			}
			U.log(Arrays.toString(latlag));
			if(add[0]==ALLOW_BLANK && latlag[0]!=null)
			{
				add=U.getAddressGoogleApi(latlag);
				if(add == null) add =U.getGoogleAddressWithKey(latlag);
				if(add == null) add =U.getAddressHereApi(latlag);
			}
			if(add[0]!=null && latlag[0]==null)
			{
				latlag=U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				if(latlag == null){
//					latlag = U.getNewBingLatLong(add);
					String googleMap = U.getSectionValue(addSec, "href='", "'");
					U.log(googleMap);
					if(googleMap != null){
						String googleMapHtml = U.getPageSource(googleMap);						
						String latLngSec = Util.match(googleMapHtml, "\\[\\[\\d{4}\\.\\d{4,}+,(-\\d{2,3}\\.\\d{2,}\\s?,\\s?\\d{2}\\.\\d{2,})\\]", 1);
						if(latLngSec != null){
							String[] vals = latLngSec.split(",");
							latlag = new String[]{ALLOW_BLANK, ALLOW_BLANK};
							latlag[0] = vals[1];
							latlag[1] = vals[0];
						}
						U.log(latLngSec);
					}
				}
				geo="TRUE";
			}
			if(add[0]==ALLOW_BLANK && latlag[0]==null)
			{
				latlag=U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getGoogleLatLngWithKey(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latlag);
				if(add == null) add =U.getGoogleAddressWithKey(latlag);
				if(add == null) add =U.getAddressHereApi(latlag);
				geo="TRUE";
			}
			if(comUrl.contains("/copper-creek-apartment-homes")) {
				String add1[] = U.getAddressGoogleApi(latlag);
				if(add1 == null) add =U.getGoogleAddressWithKey(latlag);
				if(add1 == null) add1 =U.getAddressHereApi(latlag);
				add[0] = add1[0];
			}

			U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
		//============================================Price and SQ.FT======================================================================
			
			String floorPlansData =ALLOW_BLANK;
			if(html.contains("/	"))
				floorPlansData = U.getHTML(comUrl+"/floorplans.aspx");
			
			
			if(floorPlansData!=null) {
				floorPlansData =floorPlansData
						.replaceAll("SQ.FT.</strong></td><td data-selenium-id =\"Sqft_\\d\">", "SQ.FT. ")
						.replaceAll("-<span class='sr-only'>to</span>", "-")
						.replaceAll("Sq.Ft.</strong></td><td data-selenium-id =\"Sqft_\\d+\">", "SQ.FT. ");
				
			}
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			html=html.replaceAll("0�s|0's|0&#8217;s|0s","0,000");
			String prices[] = U.getPrices(html+floorPlansData,"\\$\\d+,\\d+ - \\$\\d+,\\d+|\\d{3} -<span class=sr-only>to</span> \\d{4} sq.ft|\\d{3} -To \\d{4} Sq.Ft|\\$\\d+,\\d+</a>", 0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
	//		U.log(prop);
			floorPlansData = floorPlansData.replaceAll("propMinSqft: \\d+|Ranging from 700 square feet to 1050 square feet|propMaxSqft: \\d+", "").replaceAll("</strong></td><td data-selenium-id =\"Sqft_\\d+\">", "</strong></td><td data-selenium-id =\"Sqft");
			html=html.replaceAll("propMinSqft: \\d+|Ranging from 700 square feet to 1050 square feet|propMaxSqft: \\d+", "");
			
			
			String[] sqft = U.getSqareFeet(html+floorPlansData+prop,
					"Square Feet</span>\\d{3,4}\\s*-<span class='sr-only'>to</span>\\s*\\d{3,4}\\s*<span>|>\\d{3}-\\d{3} SqFt|>\\d,\\d+ to \\d,\\d+ Sqft</li>|SqFt\">\\d,\\d{3} to \\d,\\d{3}|SqFt\">\\d{3}|SqFt\">\\d,\\d{3}|>\\d+ to \\d,\\d+ Sqft</li>|>\\d+ to \\d+ Sqft</li>|>\\d,\\d+ Sqft</li>|>\\d+ Sqft</li>|>\\d{3,4}</td>| \\d{3,4} square feet,|SQ.FT. \\d{3,4} - \\d{3,4}|\\d{3,4} -<span class=sr-only>to</span> \\d{3,4} sq.ft|SQ. FT.\">\\d{3,4} - \\d{3,4}|from \\d{3,4} to \\d{3,4} square feet|square-footage\">\\s*\\d{3,4}|SQ.FT. \\d{3,4}|SQ. FT.\">\\d{3,4}|sqft: \\d{3,4}|Sqft \\d,\\d{3}|SQ.FT. \\d,\\d{3}|Up to \\d{3} <span class=\"fp-sqft\">sq. ft.|sqft: \"\\d{3,4}|sqft: \"\\d,\\d{3}\"",0);

			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}560[\\s\\w\\W]{30}", 0));
	//================================================community type========================================================
			String aminityHtml =U.getHTML(comUrl+"/amenities.aspx");
			html=html.replace("Municipal Golf Course", "").replaceAll("lakeside floor plans|lakeside views", "lakeside community").replaceAll("ityli9\">Private lakefront patio or balcony<im", "")
					.replace("WaterFront Apartments", "Waterfront community Apartments").replaceAll("Topgolf|\"Resort Style", "");
			
			String communityType=U.getCommType((html+aminityHtml).replaceAll("Gated Dog Park|title=\"Gated Outdoor Swimming Pool|gated dog park|Topgolf|\"Resort Style", ""));
	
//			U.log("KKKKKKKKKKKK"+Util.matchAll(html+aminityHtml, "[\\w\\s\\W]{30}gated[\\w\\s\\W]{30}", 0));

	//==========================================================Property Type================================================
			String propType = ALLOW_BLANK;
			html =html.replaceAll("aria-label=\"Luxurious Amenities|Private Multi-Level Garage|Townhomes\"|-townhomes|Lakes Townhomes</strong>|Courtyard\"|Courtyard%", "").replaceAll("Traditional One Bedroom", "traditional home").replace("custom designed one", "custom home design");
			html =html.replace("offers luxury", "offers luxury homes").replace("both garden and balcony styles", "garden style community")
					.replace("rent bring luxury and comfort", "rent bring luxury homes and comfort").replace("most luxurious ones", "luxury homes").replace("Luxurious. Quiet. Convenient", "Luxury homes Quiet. Convenient");
			propType = U.getPropType(html+aminityHtml+floorPlansData);
			if(propType.contains("Townhome")  && propType.contains("Townhouse")){
				propType = propType.replace("Townhouse,", "");
			}
	//==================================================D-Property Type======================================================
			String dtype=ALLOW_BLANK;
			aminityHtml = aminityHtml.replace("Multi-Level Garage", "")
					.replaceAll("Ceilings on the Third Floor", "");
			if(floorPlansData!=null)floorPlansData = floorPlansData.replace(" 2nd/3rd Floor", "2 story, 3 story")
					.replaceAll("third-floor cathedral |Third-Floor Cathedral|third-floor unit", "Third Floor Cathedral");
			
			html = html.replace("three-level", "three story").replace("1st, 2nd, or 3rd Floor Options", "1 story , 2 story, or 3 story Floor Options")
					.replace("first floor apartment home", "1 story apartment home")
					.replaceAll("third-floor apartments| third floor apartment ", " 3 story apartment ")
					.replaceAll("third-floor cathedral |Third-Floor Cathedral|third-floor unit", "Third Floor Cathedral");
			
			dtype=U.getdCommType((html+aminityHtml+floorPlansData.replace("the third-floor", ""))
					.replaceAll("Third Floor Cathedral Ceilings|multi-level|hance to live one level above the rest. G| one level above|title=\"First Floor|/first floor", ""));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(aminityHtml, "[\\s\\w\\W]{30}Third Floor[\\s\\w\\W]{30}", 0));
//		
	//==============================================Property Status=========================================================
			html=html.replace("Opening in Summer 2020", "Opening Summer 2020")
					.replace("Limited August Availability", "Limited Availability")
					.replace("coming soon","").replace("bark park (Coming Summer 2017).","").replaceAll("Bedrooms Just Released|s Already Sold Out|Now Available for Same ", "")
					.replaceAll("Kentwood opening soon|New apartment homes just released from construction|now available fo|COMING SOON TO BLOOMFIELD|both opening soon|Coming soon is a 24-hour| park now available|Bedrooms Now Available|63px;\">Now Available! The |(/)?Sold Out(\\.png)?|(Bath|Bedroom) Floor Plan(s)? Now|choice is now|Just Released! Same Day|units now|Bedroom Now Available|Bedroom - Now Availab|Bedroom Is Now Open", "")
					.replaceAll("(aria-label|data-original-title)=\"Coming|Hurry, Selling Out Fast - Available for Immediate Move-In!|Selling Out Fast - Available for Immediate Move-In|Immediate Move-In Options Now Available|Opening</a>|Bedroom Now Available |Day Move-Ins Now Available!", "")
					.replace("Open now in Avon", "Now Open in Avon")
					.replace("New Apartment Homes Coming Soon", "New Homes Coming Soon")
					.replace("<u>OPENING</u> <u>LATE</u> <u>SUMMER!</u>", "OPENING LATE SUMMER")
					.replaceAll("Hurry, Limited Availability|Respond Quickly - Limited|Coming soon we will feature|READY TO MOVE IN?|\"Coming|\\(Coming Soon|Recycling Coming|selling out fast!</p>|Selling Out Fast</p>|Selling Out Fast! Call|Hurry in, Selling|Hurry - Selling Out Fast|Now Available for Immediate Move|Wi-Fi Coming Soon|Layout Now Available|Privacy Now Available|Madison Now Available|Now Available! 1 BR 1 BA|Amazon Coming|spa coming|gym coming", "");
		
			communityName = communityName.replaceAll(" Apartments & Townhomes| Apartments And Townhomes| Townhomes| Apartment Homes| Apartments|Bedroom Now Available", "");
			if(communityName.endsWith("and")) {
				communityName=communityName.replace(" and", "");
			}

//			U.writeMyText(html);
			String pstatus=U.getPropStatus(html.replace("new luxury apartments opening soon!", "").replaceAll("Ready to Move In This Week|Immediate Move-Ins Available on the 2 BR 1 BA Spruce Layout|Same Day Move-Ins Now Available|Same Day Move-In Now Available|Move-In Options Now Available", "").replace("Brand New Apartment Homes Coming Soon!", "New Homes Coming Soon"));
//				U.log("KKKKKKKKKKKK"+Util.matchAll(html, "[\\w\\s\\W]{30}Ready To Move[\\w\\s\\W]{30}", 0));

			U.log("pstatus: "+pstatus);
	//============================================note====================================================================
			 note=U.getnote(html.replaceAll("\\s*Pre-Lease New Apartments|building and are leasing NOW|Now leasing brand-new|pre-lease a premier|pre-leasing a premier|our pre-lease list", ""));
			

			 if(comUrl.contains("https://www.meadowbrookerentals.com"))pstatus += ", Opening This Fall";
//				 if(pstatus == ALLOW_BLANK) pstatus = "Coming Summer 2020";
//				 else pstatus += ", Coming Summer 2020";
//			 }
			 if(comUrl.contains("https://carmel.roseseniorliving.com")) {
				 communityType="55+ Community";
				 maxSqft = "1203";
			 }
			 if(comUrl.contains("https://www.enclaverichmond.com"))maxSqft="1352";
			 if(comUrl.contains("https://www.avenueatpolaris.com"))communityType = "Resort Style"; 
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);

			
			data.addCommunity(communityName.replace(" – ", " - "),comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				
		}
		j++;
	//	}catch(Exception e){}
		}
	
	/*private void addDetails(String comUrl, String communityName) throws Exception {
	//if(j == 124)
	{
		String comUrl1="https://www.edwardrose.com"+comUrl;
		//if(!comUrl1.contains("https://www.edwardrose.com/communities/copper-creek-apartment-homes"))return;
		if(comUrl1.contains("https://www.edwardrose.com/communities/none")||comUrl1.contains("-regional-office")){
			LOGGER.AddCommunityUrl(comUrl+"**************************Regional Offices or No Url");
			return;
		}
		U.log(j+"  comUrl1::::::::::::"+comUrl1);
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"**************************repeat");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHTML("https://www.edwardrose.com"+comUrl);
		String fSec=ALLOW_BLANK;
		fSec=U.getSectionValue(html,"<script>jQuery","<script type=\"text/javascript\">");
		if(fSec==null)
			fSec=ALLOW_BLANK;
			
		if(fSec!=null)
			html=html.replace(fSec,"");

		html=html.replace("Courtyard%20Screen%20Grab.jpg\">","");
		html=html.replace("IN Courtyard\">","");
		html=html.replace("Multi-Level Garage","");
		html=html.replace("</dl>","<dt>");
	//============================================Community name=======================================================================
			//U.log("community Name---->"+communityName);
	//================================================Address section===================================================================
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html,"<dt>Address</dt>","<dt>");
		U.log(addSec);
		if(addSec!=null){
			addSec=addSec.replace("(Clubhouse)","");
			addSec=addSec.replace("<dd><span>","");
			addSec=addSec.replace("<span>","");
			addSec=addSec.replace(",","").replace(" KS ", ",KS ");
			addSec=addSec.replace("</span></dd>","").replace("West Des Moines  IA</span>", "West Des Moines</span>IA</span>").replace("  OH</span>", "</span>OH</span>");
			addSec=addSec.replaceAll("Maize\\s*Kansas", "Maize</span>Kansas");
			U.log(addSec);
			String a[]=null;
			a = addSec.split("</span>");
			add[0]=a[0].trim();
			add[1]=a[1].trim();
			U.log(add[2]+":::::::::::"+add[2].length());
			if (add[2].length() > 2) {
				add[2] = USStates.abbr((a[2].trim()));
			}
			else{
				add[2]=a[2];
				if(a[2].length()>2)
					a[2]=USStates.abbr(a[2]);
				add[2]=a[2];
			}
			add[3]=a[3].trim();
		}
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			add[0] = U.getSectionValue(html,"streetAddress\">" , "</span>");
			add[1] = U.getSectionValue(html, "addressLocality\">", "</span>");
			add[2] = U.getSectionValue(html, "addressRegion\">", "</span>");
			add[3] = U.getSectionValue(html, "postalCode\">", "</span>");
		}
		if(comUrl.contains("/copper-creek-apartment-homes"))add[0]=ALLOW_BLANK;
		if(add[1] != null) add[1] = add[1].trim().replaceAll(",", "");
		if(add[0] != null) add[0] = add[0].replaceAll("\\(Clubhouse\\)", "").replace(", S,E,", " SE");
		 add[0] = add[0].trim();
		U.log("Address---->"+add[0]+": "+add[1]+": "+add[2]+": "+add[3]);
//--------------------------------------------------latlng----------------------------------------------------------------

		String latSec=U.getSectionValue(html,"google.maps.LatLng(",")");
		if(latSec!=null)
		{
			latlag=latSec.split(",");
			latlag[0]= Util.match(latSec, "\\d{2}.\\d+");
			latlag[1]=Util.match(latSec, "-\\d+.\\d+");
			geo="FALSE";
		}
		if(add[0]==ALLOW_BLANK && latlag[0]!=null)
		{
			add=U.getAddressGoogleApi(latlag);
			if (add==null)add=U.getGoogleAddressWithKey(latlag);
		}
		if(add[0]!=null && latlag[0]==null)
		{
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if(add[0]==ALLOW_BLANK && latlag[0]==null)
		{
			latlag=U.getlatlongGoogleApi(add);
			if (latlag==null) latlag=U.getGoogleLatLngWithKey(add);
			add=U.getAddressGoogleApi(latlag);
			if (add==null)add=U.getGoogleAddressWithKey(latlag);
			geo="TRUE";
		}
		if(comUrl.contains("/copper-creek-apartment-homes")) {
			add[0]=U.getGoogleAddressWithKey(latlag)[0];
		}

		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
			
	//============================================Price and SQ.FT======================================================================
			
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0&#8217;s|0s","0,000");
		String prices[] = U.getPrices(html,"\\$\\d+,\\d+ - \\$\\d+,\\d+|\\$\\d+,\\d+</a>", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
			
	//======================================================Sq.ft===========================================================================================		
		String[] sqft = U.getSqareFeet(html,"from \\d{3,4} to \\d{3,4} square feet|square-footage\">\\s*\\d{3,4}",0);
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		String communityType=U.getCommType(html.replaceAll("Topgolf|\"Resort Style", ""));
		
//==========================================================Property Type================================================
		String propType = ALLOW_BLANK;
		html =html.replaceAll("Private Multi-Level Garage|Townhomes\"|-townhomes|Lakes Townhomes</strong>|Courtyard\"|Courtyard%", "").replaceAll("Traditional One Bedroom", "traditional home").replace("custom designed one", "custom home design");
		html =html.replace("offers luxury", "offers luxury homes");
		propType = U.getPropType(html);
		//U.log(fhtml);
		if(propType.contains("Townhome")  && propType.contains("Townhouse")){
			propType = propType.replace("Townhouse,", "");
		}
//==================================================D-Property Type======================================================
		String dtype=ALLOW_BLANK;
		html = html.replace("three-level", "three story").replace("1st, 2nd, or 3rd Floor Options", "1 story , 2 story, or 3 story Floor Options")
				.replace("first floor apartment home", "1 story apartment home")
				.replace(" third floor apartment ", " 3 story apartment ")
				.replaceAll("third-floor cathedral |Third-Floor Cathedral", "Third Floor Cathedral");
		dtype=U.getdCommType(html);
			
//==============================================Property Status=========================================================
		html=html.replace("coming soon","").replace("bark park (Coming Summer 2017).","").replaceAll("Bedrooms Just Released|s Already Sold Out|Now Available for Same ", "")
				.replaceAll("Respond Quickly - Limited|\"Coming|\\(Coming Soon|Coming soon is a 24-hour| park now available|Bedrooms Now Available|63px;\">Now Available! The |(/)?Sold Out(\\.png)?|(Bath|Bedroom) Floor Plan(s)? Now|choice is now|Just Released! Same Day|units now", "");
	
		communityName = communityName.replaceAll(" Apartments & Townhomes| Apartments And Townhomes| Townhomes| Apartment Homes| Apartments", "");
		if(communityName.endsWith("and")) {
			communityName=communityName.replace(" and", "");
		}
		String pstatus=U.getPropStatus(html.replace("Open now in Avon", "Now Open in Avon").replaceAll("luxury apartments opening soon|\"Coming|\\(Coming Soon",""));
		
		//pstatus=pstatus.replace("Now Available",ALLOW_BLANK);
		
//============================================note====================================================================
		 note=U.getnote(html);
		

		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);

		
		data.addCommunity(communityName,comUrl1, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
	}
	j++;
	}
	*/
}
