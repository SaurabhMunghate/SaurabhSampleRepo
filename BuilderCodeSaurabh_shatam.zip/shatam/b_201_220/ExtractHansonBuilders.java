/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_201_220;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractHansonBuilders extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractHansonBuilders()
			throws Exception {
		super("Hanson Builders","www.hansonbuilders.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Hanson Builders");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractHansonBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Hanson Builders.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("http://www.hansonbuilders.com/find-a-home/neighborhoods/");
		String section=U.getSectionValue(mainHtml,"<a class=\"cs-btn cs-btn-sm\"","</section>");
		String[] secValue=U.getValues(section, "href=\"","\"");
		for(String sec:secValue)
		{
			sec="http://www.hansonbuilders.com"+sec;
			U.log(sec);
			String mPHtml=U.getHTML(sec);
			String[] comSec=U.getValues(mPHtml,"neighborhood-features-small\">","Learn More");
			U.log(comSec.length);
			for(String com:comSec)
			{
				String comUrl=U.getSectionValue(com, "\" href=\"","\"");
				if(comUrl!=null)
				{
				if(!comUrl.contains("http"))
				{
					comUrl="http://www.hansonbuilders.com"+comUrl;
				}
				//U.log("url-->"+comUrl);
				addDetails(comUrl,com);
			}
			}
			
		}
	}

	private void addDetails(String comUrl, String mData) throws Exception {
		// TODO Auto-generated method stub
		//if(!comUrl.contains("http://www.hansonbuilders.com/find-a-home/neighborhoods/preserve-at-oak-view/"))return;
		
				U.log("commUrl-->"+comUrl);
				
				if(comUrl.contains("http://www.hansonbuilders.com/find-a-home/neighborhoods/terra-vista/"))return;//404 status
						String html=U.getHTML(comUrl);
						/*String rem=U.getSectionValue(html, "project_next one columns\">","</body>");
						html=html.replace(rem,"");*/
						//============================================Community name=======================================================================
						String communityName=U.getSectionValue(html, "header-content\">","<");
						if(communityName==null)
						{
							communityName=U.getSectionValue(html, "page-title\">","<").replace("_"," ");
						}
						U.log("community Name---->"+communityName);
						
				//================================================Address section===================================================================
						String note="";
						String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
						String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
						String geo="FALSE";
						
						String addSec=U.getSectionValue(html, "https://www.google.com/maps","\"");
						if(addSec!=null)
						{
							U.log(addSec);
							String sec=U.getSectionValue(addSec,"!2s","!5e");
							if(sec!=null)
							{
							U.log(sec);
							sec=sec.replaceAll("!3m2!1d45.1045683!2d-93.05428429999999","");
							sec=sec.replace("+"," ").replace("%2C",",");
							add=U.findAddress(sec);
							}
						}
						
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
						
				//--------------------------------------------------latlng----------------------------------------------------------------
						if(addSec!=null)
						{
							String latSec=U.getSectionValue(addSec, "!2d","!2m");
							if(latSec!=null)
							{
								String[] lat1=latSec.split("!3d");
								latlag[0]=lat1[1];
								latlag[1]=lat1[0];
								//U.log(latSec);
							}
						}
						
						U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
						if(add[0]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
						{
							add=U.getAddressGoogleApi(latlag);
							geo="TRUE";
						}
						if(add[2]==ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
						{
							add[0]="13432 Hanson Boulevard NW";
							add[1]="Andover";
							add[2]="MN";
							add[3]="55304";
							latlag=U.getlatlongGoogleApi(add);
							geo="TRUE";
							note="Address Taken From Contact";
						}
						
				//============================================Price and SQ.FT======================================================================
							
						String[] homeUrlSec=U.getValues(html, "property-box property-box-right property-content","</a></h3>");
						String homeUrlHtml="";
						for(String urlSec:homeUrlSec)
						{
							homeUrlHtml=homeUrlHtml+U.getHTML(U.getSectionValue(urlSec, "<a href=\"","\""));
						}
						
						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
						html=html.replace("1M","1,000,000");
						html=html.replaceAll("0�s|0's|0&#8217;s|0&#8217;s|0k","0,000");
						html=html.replace("0-","0,000-");
						String prices[] = U.getPrices(html+homeUrlHtml+mData,"over \\$\\d{1},\\d+,\\d+|to \\$\\d,\\d+,\\d+|from \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|the \\$\\d{3},\\d+|<p>\\$\\d+,\\d+|from \\$\\d{3},\\d+|f00;\">&#36;\\d{3},\\d+|page-price\">&#36;\\d{3},\\d+|page-price\">&#36;\\d,\\d{3},\\d{3}|the high \\$\\d{3},\\d{3}", 0);
						
						minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
						maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
						
						U.log("Price--->"+minPrice+" "+maxPrice);
						
				//======================================================Sq.ft===========================================================================================		
						
						
						String[] sqft = U
								.getSqareFeet(
										html+homeUrlHtml+mData,
										"\\d+,\\d+ Square Feet|\\d{1},\\d+ Finished SF|custom-class\">\\d{1},\\d+",
										0);
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						U.log("SQ.FT--->"+minSqft+" "+maxSqft);
						
				//================================================community type========================================================
						html=U.getNoHtml(html);
						String communityType=U.getCommType(html);
						
				//==========================================================Property Type================================================
						
						html=html.replaceAll("Custom Homes","");
						String proptype=U.getPropType(html);
						
				//==================================================D-Property Type======================================================
						
						String dtype=U.getdCommType(html+homeUrlHtml);
						
				//==============================================Property Status=========================================================
						html=html.replace("reservations open now","");
						String pstatus=U.getPropStatus(html);
						
				//============================================note====================================================================
						
						// note=U.getnote(html);
						
						
						if(data.communityUrlExists(comUrl))
							{
							LOGGER.AddCommunityUrl(comUrl);
							k++;
							return;
							}
							data.addCommunity(communityName,comUrl, communityType);
							data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(proptype, dtype);
							data.addPropertyStatus(pstatus);
							data.addNotes(note);
						j++;
	}

}
