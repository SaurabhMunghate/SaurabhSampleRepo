/*
 *Author Priti
 *Date: 31Jan2017 
 */

package com.shatam.b_201_220;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKeystoneHomes extends AbstractScrapper{
	
	WebDriver driver = null;
	static String baseUrl="https://www.gokeystone.com/";
	CommunityLogger LOGGER;
	
	
	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a =new ExtractKeystoneHomes(); 
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Keystone Homes.csv", a.data()
						.printAll());
	}
	
	
	public ExtractKeystoneHomes() throws Exception {

		super("Keystone Homes", "https://www.gokeystone.com/");
		LOGGER=new CommunityLogger("Keystone Homes");
	}
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String mainHtml=U.getHtml("https://www.gokeystone.com/Communities.aspx",driver);
		//U.log(mainHtml);
		
		String[] comSections=U.getValues(mainHtml, "<table class=\"ItemTable\">", "</table>");
		U.log(comSections.length);
		
		for(String comSec : comSections){
		//	U.log(comSec);
			String cUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
			cUrl=baseUrl+cUrl;
			addDetails(cUrl,comSec);
			//break;
		}
		LOGGER.DisposeLogger();

		driver.quit();
	}

	int j= 0;
	//TODO :
	public void addDetails(String url, String comSec) throws Exception{

//	if(j>5)
	{
		U.log("Count :"+j);
		//===========comUrl=============
		String comUrl=url;
//		if(!comUrl.contains("https://www.gokeystone.com/Gibsonville-Savannah-Glen"))return;
		
		U.log("comUrl:::"+comUrl);
		U.log(U.getCache(comUrl));
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"---------repeated---------------");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
	//	U.log(comSec);
		String comHtml=U.getHtml(comUrl,driver);
		
		U.log(Util.match(comHtml, "from \\$270's"));
		
		//===========Community Name=============
		String comName = U.getSectionValue(comHtml, "titleMain\">", "</span>");
		U.log("comName:::"+comName);
		
		
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latLng={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		//==================Address ==================
		String addSec=U.getSectionValue(comHtml, "SalesOffice\">", "</span></p>");
		
		U.log("addSec:::"+addSec);
		
		if(addSec!=null){
			addSec=addSec.replace("Coming Soon ", "");
			addSec = addSec.replace("Dr Graham", "Dr, Graham").replace("Crossing High Point", "Crossing, High Point")
					.replace("Rd. High Point", "Rd., High Point").replace("Rd. Colfax", "Rd, Colfax").replace("Terrace  Trinity", "Terrace, Trinity").replace("Way  Burlington", "Way, Burlington");
			addSec = formatAdrees(addSec);
			add = U.findAddress(addSec);
			U.log("findAddress:::"+addSec);
		}
		U.log("My Address::"+Arrays.toString(add));
		
		//=============LAtLNG============
		String latlngSec=U.getSectionValue(comHtml, "https://www.google.com/maps/place/", "\"");
		if(latlngSec!=null){
			latLng=latlngSec.split(",");
			
		}
		U.log("My latLng::"+Arrays.toString(latLng));
		
		if(add==null && latLng[0].length()>4){
			add=U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getGoogleAddressWithKey(latLng);
			geo="TRUE";
		}
		if(add[2]==null && latLng[0].length()>4){
			add=U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getGoogleAddressWithKey(latLng);
			geo="TRUE";
		}
		
		//============Price=================
		String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
		
		comSec=comSec.replace("0's", "0,000");
		U.log(Util.match(comHtml, "from  \\$270’s"));
		comHtml=comHtml.replaceAll("0's|0’s", "0,000");//.replace("From the 210,000-270,000</span>", "")
		
		String[] prices=U.getPrices((comHtml+comSec), "From the \\d{3},\\d{3}-\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|From \\d{3},\\d{3} to \\d{3},\\d{3}|From the [\\$]*\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}</span>", 0);
//		U.log(">>>>>>>>>>>"+Util.matchAll(comHtml+comSec, "[\\s\\w\\W]{50}270,000[\\s\\w\\W]{50}",0));
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log(minPrice + "," + maxPrice);
		
		//============Square feet=================
		String minSqFt=ALLOW_BLANK,maxSqFt=ALLOW_BLANK;
		
		comSec=comSec.replace("0's", "0,000");
//		U.log(comSec);
//		U.log(">>>>>>>>>>>"+Util.matchAll(comHtml+comSec, "[\\s\\w\\W]{50}3600[\\s\\w\\W]{50}",0));

		comHtml=comHtml.replace("up to  3600+ sq. ft", "up to  3600 sq. ft");
		String[] sqFt=U.getSqareFeet(comHtml+comSec, "range from \\d{4} sq. ft. to \\d{4} sq. ft.|up to  \\d+ sq. ft|ranging from \\d{4} sq. ft. to over \\d{4} sq. ft| over \\d{4} sq. ft. to over \\d{4} sq. ft.|Sq Footage:\\s+<span>\\d{1},\\d{3}</span>|\\d,\\d{3} square feet", 0);
		
		minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log(minSqFt + "," + maxSqFt);
		
		//---------------removed data--------------
		int quickCount = 0;
		String quickMoveInSection[] = U.getValues(comHtml, "<span class=\"moveinDropCont", "communityBold\">More<br");
		for(String quickMoveSec : quickMoveInSection){
			//U.log("-------->"+quickMoveSec);
			if(!quickMoveSec.contains("Sold.png"))quickCount++;
		}
		U.log("quick count :"+quickMoveInSection.length);
		comHtml=comHtml.replaceAll("Quick Move-in<| to that coming soon|right on Lakeside", "");
		
		//================================================community type========================================================
		
		String communityType=U.getCommType(comHtml+comSec);
		
		
//==============================================Property Status=========================================================
		comHtml =comHtml.replace("USDA- Eligible- 100% Financing", "USDA Eligible 100% Financing");
//				.replace("USDA 100% Financing Eligible Community", "100% USDA Eligible");
		comHtml =comHtml.replaceAll("style=\"display: none;\">\n\\s*MOVE IN READY HOME|Available_Homes\">MOVE IN READY HOMES|<h1 class=\"mobileHideOnly\">\n\\s*Move in Ready Homes|and Grand Opening|Coming Soon|about new homes available|mainButton\">\\s+MOVE IN READY","");
		String pstatus=ALLOW_BLANK;
//		U.writeMyText(comHtml);
//		comHtml=comHtml.replace("https://www.gokeystone.com/Walkertown-High-Knoll", "");
//		comSec=comSec.replace("https://www.gokeystone.com/Walkertown-High-Knoll","");
		pstatus=U.getPropStatus(comHtml+comSec);
		U.log("pstatus is:"+pstatus);
/*		if(!comHtml.contains("<span class=\"moveinDropContent\">")){
			U.log("hello------>");
			if(pstatus.contains("Move In Ready Home") && pstatus.length()<3){
				pstatus=pstatus.replace("Move In Ready Home", ALLOW_BLANK);
			}
			else{
				pstatus=pstatus.replaceAll(", Move In Ready Home|Move In Ready Home,", "");
			}
		}
*/		//U.log(comHtml);
//		if( quickCount > 0){
//			U.log("LLLLLL");
//    			if(pstatus.length()>4) {
//    				if(pstatus.length()>4 && !pstatus.contains("Move")) {
//    				pstatus+=", Quick Move-in";
//    				}
//    			}
//    			else {
//    				pstatus="Quick Move-in";
//    			}
//    		}
//		if(comUrl.contains("https://www.gokeystone.com/Walkertown-High-Knoll||https://www.gokeystone.com/Browns-Summit-Brooke-Meadows"))
//			pstatus=pstatus.replace("Quick Move-in","");
//		U.log("=="+pstatus);
		//==================================================D-Property Type======================================================
				comHtml = comHtml.replaceAll("(Second|First) Floor|FIRST FLOOR|first floor|Branch", "");
				comHtml=comHtml.replaceAll("Stories:\n*\\s*\n*<span>"," ")
						.replace("1 &amp; 2 stories", "1 story, 2 stories").replace(" one- or two-level", " 1 Story or 2 Story ");
				String dtype=U.getdCommType(comHtml);
				
		
//==========================================================Property Type================================================
		String remSec = U.getSectionValue(comHtml, "<span id=\"Label5\">", "</span>");

		if(remSec != null) comHtml = comHtml.replaceAll(remSec, "");
		
		comHtml=U.getNoHtml(comHtml);
		comHtml=comHtml.replaceAll("No HOA|our custom home","").replace("more traditional layout", "traditional family homes")
				.replace("twin-town homes ", "Twin Home");
		
		String proptype=U.getPropType((comHtml+comSec).replace("by the Homeowners’ Association", "HOA dues").replaceAll("This plan also offers a loft|similar to apartments|Loft\">|_Loft\\.jpg\"|Loft\"|loft with skylights an|Loft\\D+.jpg\"|find a large loft with|craftsmanship ", ""));  //
		//U.log(Util.match("::::::::::::::"+comHtml, ".*?luxurious.*?"));


//============================================note====================================================================
		String note =ALLOW_BLANK;
		comHtml=comHtml.replace("first to receive Pre-grand opening prices and", "");
		note =U.getnote(comHtml);
		U.log("note=="+note);


		if(comUrl.contains("https://www.gokeystone.com/Greensboro-Westridge-Forest"))
			pstatus="Sold Out";//from image
		
		
		data.addCommunity(comName,comUrl, communityType);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);	
	}
		j++;
	}
	
	public String formatAdrees(String add){
		String address=add;
		
		if(address.contains("Court ")&& !address.contains("Court,"))
			address=address.replace("Court ", "Court, ");
		if(address.contains("Drive -Lot 47 ")&& !address.contains("Drive -Lot 47,"))
			address=address.replace("Drive -Lot 47 ", "Drive -Lot 47, ");
		if(address.contains("Oak Drive. ")&& !address.contains("Oak Drive.,"))
			address=address.replace("Oak Drive.", "Oak Drive,");
		
		address=address.replace("201 Carter Ridge Drive -Lot 47", "201 Carter Ridge Drive Lot 47")
				.replace("Circle Burlington", " Circle, Burlington");
		
		return address;
	}
}