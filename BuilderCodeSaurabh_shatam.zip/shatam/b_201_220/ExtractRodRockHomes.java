
/*sampada santosh*/
package com.shatam.b_201_220;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractRodRockHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String BASEURL = "https://rodrockhomes.com/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractRodRockHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Rodrock Homes.csv", a.data().printAll());

	}

	public ExtractRodRockHomes() throws Exception {

		super("Rodrock Homes", "https://rodrockhomes.com/");
		LOGGER = new CommunityLogger("Rodrock Homes");
	}

	
	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
		String basehtml = U.getHTML("https://rodrockhomes.com/where-we-build/");
		//String mainSec=  U.getSectionValue(basehtml, "<div class=\"entry-content\" itemprop=\"text\"><p>", "</p>");
		String values[] = U.getValues(basehtml, "<h2 class=\"entry-title\">", "See more");
		U.log(values.length);
		for (String value : values) {
			String url =  U.getSectionValue(value, "href=\"", "\">");
			addDetails(url,value);
		}
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}

	//TODO :
	public void addDetails(String url,String mainSec) throws Exception {
//	try{
//		if(j>=10)
	{
		U.log(j+"======"+url);
		String html = U.getHTML(url);
		U.log(U.getCache(url));
		String ownUrl = U.getSectionValue(html, "<div class=\"community-web\"><h4><a href=\"","\"");
		U.log(ownUrl);
		String ownUrlHtml = ALLOW_BLANK;
		String ownFloorPlanHtml = ALLOW_BLANK;
		String ownAvailableHtml = ALLOW_BLANK;
		String allAvilHomes[]= {};
		if(ownUrl!=null) {
			if(!ownUrl.contains("rodrockhomes.com")) {
				LOGGER.AddCommunityUrl("============ :Community from Rodroch development builder: ============"+ownUrl);
			}
			else {
				ownUrlHtml = U.getHtml(ownUrl,driver);
			}
			if(ownUrl.contains("liveatchapelhill")) {
				ownFloorPlanHtml = U.getHtml(ownUrl+"/plans", driver);
				ownAvailableHtml = U.getHtml(ownUrl+"/homes", driver);
				allAvilHomes = U.getValues(ownAvailableHtml, "h4 class=\"result-title ng-binding\">", ">View Detail</a>");
			}
//			if(ownUrl.contains("gleasonglen.com")) {
//				ownFloorPlanHtml = U.getHtml(ownUrl+"/floor-plans/", driver);
//			}
			if(ownUrl.contains("ridgestonemeadowskc.com")) {
				ownFloorPlanHtml = U.getHtml(ownUrl+"/featured-listings/", driver);
				ownFloorPlanHtml= ownFloorPlanHtml.replaceAll("<!-- /react-text --><!-- react-text: \\d+ -->&nbsp;sq&nbsp;ft", " sq ft");
			}
			if(ownUrl.contains("summerwoodop.com")) {
				ownFloorPlanHtml = U.getHtml(ownUrl+"/homes-for-sale.html", driver)+", $164,950";
			}
			if(ownUrl.contains("terrybrookfarms")) {
				ownFloorPlanHtml = U.getHtml(ownUrl+"/floor-plans", driver);
				ownAvailableHtml = U.getHtml(ownUrl+"/available-homes", driver);
				String plans[] = U.getValues(ownFloorPlanHtml, "data-testid=\"richTextElement\"><h2 class=\"font_2\" style=\"font-size:18px; text-align:center\">", "Floor Plans</span><span class=\"StylableButton1881452515__icon\"");
				for(String data:plans) {
					String pageUrl = U.getSectionValue(data, "<a data-testid=\"linkElement\" href=\"", "\"");
					U.log(pageUrl);
					if(pageUrl!=null)
					ownFloorPlanHtml+= U.getHtml(pageUrl, driver);
				}
			}
			if(ownUrl.contains("thewillowskc.com")) {
				ownFloorPlanHtml = U.getHtml(ownUrl+"floor-plans.html", driver);
				ownAvailableHtml = U.getHtml(ownUrl+"homes-for-sale.html", driver);
			}
			if(ownUrl.contains("timberrockks.com")) {
				ownFloorPlanHtml = U.getHtml(ownUrl+"floor-plans.html", driver);
				ownAvailableHtml =U.getHtml(ownUrl+"available-homes.html", driver);
			}
			
		}
		
		
		//TODO:
//============= SINGLE EXECUTION
//		if(!url.contains("https://rodrockhomes.com/communities/terrybrook-farms/"))return;
		
		//U.log(mainSec);
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl("============ :Repeated: ============"+url);
			U.log("community repeated");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		// ----------community name----------//

		String communityName = U.getSectionValue(html, "<title>", "</title>");
		communityName = communityName.replaceAll("- Rodrock Homes| - a New Home Community in south Overland Park", "");
		U.log("communityName::::::::"+communityName);
		// --------latlong------------//
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "<div class=\"marker\"",
				"<");
		if (latLongsec != null) {

			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}

		// --------adress----------//
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;

			
			String ad1 = U.getSectionValue(html,
					"<li class=\"cross-streets\">", "<li class=\"school");
			U.log("ad1::::" + ad1);
			
			if (ad1 != null) {
				ad1=ad1.replace("<li class=\"city\">","");

				String a1[] = ad1.split("</li>");
				add[0] = a1[0].trim().replaceAll("\\s+", " ");
				String adr[] = a1[1].split(",");
				add[1] = adr[0].trim();
				
				add[2] = adr[1].trim().toUpperCase();
				if (add[2].length() > 2) {
					add[2] = USStates.abbr((adr[1].trim()));
				}
				

			}
			if(add[3].length()<4) {
				ad1=U.getSectionValue(html, "<div class=\"office-address\"><p>", "</p>");
				U.log(ad1);
				if(ad1!=null && ad1.length()>7 && Util.match(ad1, "\\d{5,6}")!=null) {
					ad1=ad1.replace("</li>", ",").replace("Overland Park", ",Overland Park");
					ad1=ad1.replace("<br /> ,", ",").replace("<br> ", ",")
							.replace(",,", ", ");
					U.log("kkk==="+ad1);
				add=U.findAddress(ad1);
				}
			}
//			U.log(add[3]);
		if (latLong[0] == ALLOW_BLANK) {

			latLong = U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "TRUE";
		}
//		U.log("LLLLLLLLL=="+Arrays.toString(add));
		
		if (add[3]==null || add[3] == ALLOW_BLANK || add[3].length()<5) {
			String add1[] = U.getAddressGoogleApi(latLong);
			if(add1 == null) add1 = U.getAddressHereApi(latLong);
			add[3] = add1[3];
			geo = "TRUE";
		}
		
		
		U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
				+ " add[3] " + add[3]);

		// ---------community type,property type,property status,derived,
		// property type---------//
		//html = html.replace(" private lake", " private lake")
		String commType = U.getCommunityType(html);
//		U.log(Util.matchAll(html+mainSec, "[\\w\\s\\W]{30}home sites[\\w\\s\\W]{20}", 0));
		
		html = html.replace(" estate experience", " estate homes");
		
		String floorUrls[] = U.getValues(html, "<div class=\"floorplan-thumbnail\"><a href=\"", "\"");
		String combinedFloorHtmls = null;
		U.log("Total floor :"+floorUrls.length);
		int x = 0;
		for(String floorUrl : floorUrls){
			U.log("floorUrl :"+floorUrl);
			combinedFloorHtmls += U.getSectionValue(U.getHTML(floorUrl), "<ul class=\"floorplan-info\">", "<div class=\"where-we-build\">");
			//if(x++ == 3)break;
		}
		
		
		String floorData = ALLOW_BLANK;
//		if(html.contains("<a href=\"https://rodrockhomes.com/floor-plans/\"><span >Floor Plans</span></a></li>")) {
			
			String floorHtml = U.getHtml("https://rodrockhomes.com/available-new-homes/", driver);
			int c = 1;
			String[] floorSec = U.getValues(floorHtml, "spec-home status-publish entry", "</article>");
			U.log("floorUrls.length:"+floorSec.length);
			for(String floor : floorSec) {
				
				if(floor.contains(communityName.trim())) {
					String link = U.getSectionValue(floor, "info-heading\"><a href=\"", "\">");
					U.log("Fllor Link "+link);
					String floordata = U.getHtml(link, driver);
					floorData += floordata+floor;
					
				//	U.log(+c+"Available "+link);
					c++;
				}
					
			}
			
//		}
		//U.log("floorData: "+floorData);
		String homeData = ALLOW_BLANK;
		String homesHtml=U.getHTML("http://homesforsale.rodrockhomes.com/i/rodrockhomeskc?per=25&start=1")+U.getHTML("http://homesforsale.rodrockhomes.com/i/rodrockhomeskc?per=25&start=2");
		String homesData[] = U.getValues(homesHtml, "<div id=\"IDX-results-row-content\" class=\"IDX-row-content\">", "View Details</a>");

		//url not present in page Dt 23 jul 21 please check next month
		//		for(String data:homesData) {
////			U.log(data.contains(communityName.trim()));
//			if(data.contains(communityName.trim())) {
//				homeData+=data;
//			}
//		}
		homesHtml=U.getHTML("https://rodrockhomes.com/available-homes/");
		homesData = U.getValues(homesHtml, "<div class=\"spec-home-address\">", "<div class=\"spec-home-image\">");
		for(String data:homesData) {
//			U.log(data.contains(communityName.trim()));
			if(data.contains(communityName.trim())) {
				String homeUrl=U.getSectionValue(data, "<li class=\"info-heading\"><a href=\"", "\">");
//				U.log("URL+++++++++++++==="+homeUrl);
				String homeHtml=U.getHTML(homeUrl);
				String homeSec=U.getSectionValue(homeHtml, "<div class=\"gallery-extender\">", "Contact Us</button>");
				homeData+=data+homeSec;
			}
		}
		
	//	U.log("homedata: "+homeData);
		U.log("combinedFloorHtmls: "+combinedFloorHtmls);
		ownAvailableHtml=ownAvailableHtml.replace("These beautiful luxury manors", "");
		html=html.replace("Comprised of The Estates", "Estate Series").replace("villas for sale", "villas homes for sale");
		if(combinedFloorHtmls!=null)
		combinedFloorHtmls = combinedFloorHtmls.replace("luxury to work from home", "luxury homes");
		String propType = U.getPropType((html+homeData+mainSec+combinedFloorHtmls+floorData+ownUrlHtml+ownFloorPlanHtml+ownAvailableHtml).replaceAll("James Engle Custom Homes,|James Engle Custom Homes|Covenant Custom Homes| fine custom homes in many communities|Custom Design Experience|Rodrock Homes builds fine custom homes|craftsmanship|your custom home. James Engle Custom Homes|Rodrock Homes builds custom homes|Rodrock Homes builds fine custom homes", ""));
		
//		U.log(">>>>>>"+Util.matchAll(ownAvailableHtml, "[\\w\\s\\W]{30}Custom Homes[\\w\\s\\W]{20}", 0));

		
		
		ownFloorPlanHtml=ownFloorPlanHtml.replace(" reverse 1.5 story ", "Reverse-one-half-Story");
		
		html=html.replace("Two Story, 1.5 Story and Reverse 1.5 Story floor plans which can be built", "").replace("<li class=\"style\">1&frac12; Story", " 1.5 Story ")
				.replace("<li class=\"style\">Reverse 1&frac12; Story</li>", "Reverse-one-half-Story");
		//U.log(html);
		String dpType = U.getdCommType((html+homeData+floorData+ownUrlHtml+ownFloorPlanHtml+ownAvailableHtml).replace("1&frac12; Story", "one-and-one-half story").replaceAll("1.5-story", "one-and-one-half story").replaceAll("Mission Ranch|floor",""));
		mainSec = mainSec.replace("coming online soon", "coming soon");
		String commStatus = U.getPropStatus(html + mainSec.replaceAll("walkout home sites available|ith new homes sites coming", ""));
		//.replaceAll("walkout home sites available|home sites available","")
		html=html.replace("$ 2 million", "$2,000,000").replace("1.5 million", "1,500,000").replace("(", "").replace(")", "").replace("0s", "0,000");
		if(homeData!=null)homeData=homeData.replaceAll("SqFt:</span>\\s*<span class=\"IDX-resultsText\">", "SqFt: ");
		ownAvailableHtml=ownAvailableHtml.replace("&nbsp;Sq. Ft.", " Sq. Ft.").replace("$1.995m", "$1,995,000").replaceAll("option value=\".*</option>", "");
		ownFloorPlanHtml = ownFloorPlanHtml.replace("00-$", "00,000-$").replace("$2M+</span>", "$2,000,000</span>").replace("00K", "00,000").replace("&nbsp;Sq. Ft.", " Sq. Ft.");
//		U.log(ownFloorPlanHtml);
		
		
		// --prices---//
		
		floorData=floorData.replace("0s", "0,000")
				.replace("$1.2 million+", "$1,200,000")
				.replace("$1.0 million+", "$1,000,000")
				.replace("$1.1 million+", "$1,100,000");
//		U.log(Util.matchAll(floorData, "[\\w\\s\\W]{50}million[\\w\\s\\W]{50}", 0));
		String[] price = U.getPrices(html+floorData, "\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|price\">\\$\\d,\\d{3},\\d{3}|from the \\d+,\\d+|\\$\\d,\\d+,\\d+ |\\$\\d+,\\d+ |\\$\\d+,\\d+", 0);
		//+homeData+ownFloorPlanHtml+ownAvailableHtml
	
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html+floorData, "\\d,\\d{3} square feet|\\d+,\\d+ sq.ft|SqFt: \\d,\\d{3}|\\d{4} sq.ft|SQFT:</span> \\d,\\d{3}|\\d,\\d{3} Sq. Ft.|\\d{4} sq.ft.|\\d{4} sq ft", 0);
		//+homeData+ownFloorPlanHtml+ownAvailableHtml
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

//		if(url.contains("https://rodrockhomes.com/communities/timber-rock/"))propType+=", Homeowner Association";
		if(url.contains("https://rodrockhomes.com/communities/terrybrook-farms/"))propType+=", Estate-Style Homes";
		if(url.contains("https://rodrockhomes.com/communities/chapel-hill/")) {propType="Villas";
		minPrice = "$505,970"; maxPrice = "$776,560";
		minSqf = "2020"; maxSqf = "3700";
		}
		if(url.contains("https://rodrockhomes.com/communities/timber-rock/")) {
			minPrice="$600000";
			maxPrice="$1093704";
			propType=ALLOW_BLANK;
		}
		
		
		// ---notes-----//
		if(url.contains("/communities/hills-of-forest-creek/"))
		commStatus ="Few Walkout Home Sites Available";
		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0].replace("&amp;", "&"), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));
        data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
        data.addUnitCount(ALLOW_BLANK);
	}
	j++;
//	}catch(Exception e){}
	}

}