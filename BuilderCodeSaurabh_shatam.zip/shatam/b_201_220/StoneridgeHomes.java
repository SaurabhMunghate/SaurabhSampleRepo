/**
 * @author Sagar Meshram
 * @date 15 March 2022
 */
package com.shatam.b_201_220;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class StoneridgeHomes extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static String Builder_name = "Stoneridge Homes";
	static String HOME_URL = "https://www.stoneridgehomesinc.com";
	CommunityLogger LOGGER;
	WebDriver driver=null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new StoneridgeHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Stoneridge Homes.csv", a.data()
				.printAll());
		
	}

	public StoneridgeHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger(Builder_name); 
	}

	HashMap<String,String> addresSec = new HashMap<String,String>();
	public void innerProcess() throws Exception{
		System.setProperty("webdriver.chrome.driver", "/home/shatam-10/chromedriver");
		driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		String maphtml = getHtml("https://www.stoneridgehomesinc.com/community-map",driver);
//		U.log(maphtml);
//			String[] addSec = U.getValues(maphtml,"<div class=\"card-body\"","<div class=\"col-10 ml-1 p-0\"");
//			for(String addS : addSec) {
//				String comName = U.getSectionValue(addS, "style=\"font-size: 16px;\">", "</h5></div></div><div");
//				comName = comName.replace("INTEREST LIST FORMING!", "").replace("SOLD OUT!", "").replace("NOW SELLING!", "").replace(" - NEW RELEASES", "").replace(" -", "").trim();
//			U.log("Community Name :-"+comName);
//				String addSec1 = U.getSectionValue(addS, "class=\"col-12\" style=\"font-size: 13px;\">", "</div></div><div class=\"mb-1");
//				addSec1=addSec1.replace("Alabama,", "Alabama");
//				addSec1 = addSec1.trim();
//				U.log(addSec1);
//				addresSec.put(comName, addSec1);		
//					U.log(comUrl);		
//			}
//			driver.quit();
		
		HashMap<String, String> comUrls = new HashMap();
		HashSet<String> urls = new HashSet();
			
		
			String comhtml = U.getHTML("https://www.stoneridgehomesinc.com/communities");
			
			//---------------------------FLOW 1
			String section = U.getSectionValue(comhtml, "OUR COMMUNITIES", "Contact");
			//U.log("section: "+section);
			//String[] communitySec = U.getValues(comhtml, "<div role=\"gridcell\"","Available Homes</span>");
			String[] communitySec = U.getValues(section, "<div class=\\\"caption-container u_","Explore More");
			U.log("communitySec: "+communitySec.length);
			U.log("---FLOW 1---");
			
			String sectionOne = U.getSectionValue(comhtml, "Community Map<span", "/about/our-design-center");
			//U.log("section: "+section);
				//String[] communitySec = U.getValues(comhtml, "<div role=\"gridcell\"","Available Homes</span>");
				String[] communitySecOne = U.getValues(sectionOne, "unifiednav__item-wrap","</span> \\n</span>");
				U.log("communitySec: "+communitySec.length);
				U.log("---FLOW 2---");
				
					for(String comSec:communitySecOne) {
						
						//U.log("comSec: "+comSec);
						String comUrl = "https://www.stoneridgehomesinc.com" + U.getSectionValue(comSec, "href=\\\"", "\\\"");
						
						U.log("comUrl: "+comUrl);
						comUrls.put(comUrl, comSec);
						urls.add(comUrl);
						
						//comDetails(comUrl,comSec);
//					break;
					}
			

				
			//-----------------------------FLOW 2
					for(String comSec:communitySec) {
						
						//U.log("comSec: "+comSec);
						String comUrl = "https://www.stoneridgehomesinc.com" + U.getSectionValue(comSec, "href=\\\"", "\\\"");
						
						U.log("comUrl: "+comUrl);
						comUrls.put(comUrl, comSec);
						urls.add(comUrl);
						
						//comDetails(comUrl,comSec);
//					break;
					}
				
					U.log("comUrls Size: "+comUrls.size());
					U.log("urls Size: "+urls.size());
					
					
					for(String comurl:urls) {
						U.log("comurl from hashSet: "+comurl);
						
						String regionSec = comUrls.get(comurl);
						U.log("regionSec: "+regionSec);
						//break;
						
						comDetails(comurl,regionSec);
					}
					
//				driver.quit();
				LOGGER.DisposeLogger();
	}

	public void comDetails(String Url, String Sec) throws Exception {
		
//		if(!Url.contains("https://www.stoneridgehomesinc.com/communities/riverton-preserve")) return;
		
		U.log("Count :"+inr);
//		U.log(Url);
		
		if (data.communityUrlExists(Url)) {
			LOGGER.AddCommunityUrl(Url + "\t*********Repeated******\t");
			return;
		}
		
		
		String commhtml = U.getHtml(Url,driver);
		U.log(U.getCache(Url));
		
		String commName=U.getSectionValue(commhtml, "<title>", "|");
		
//		if(commName != null) {
//			commName = commName.replace("Community", "").replace("&#39;", "'").replace("in Sanctuary Cove", "").replace("The Retreat Townhomes","The Retreat at Goose Creek Townhomes").trim();
//		}
		if(Url.contains("/communities/cherokee-ridge")) commName = "Cherokee Ridge";
		if(Url.contains("/communities/bailey-park")) commName = "Bailey Park";
		if(Url.contains("/communities/the-willows-at-sanctuary-cove")) commName = "The Willows";
		
		U.log("Community Name :"+commName);
		String addSec=addresSec.get(commName);

//		if (Url.contains("https://www.stoneridgehomesinc.com/riverton-preserve-coming-soon")) {
//			LOGGER.AddCommunityUrl(Url + "\t*********Return******\t");
//			return;
//		}
//		if (Url.contains("https://www.stoneridgehomesinc.com/moores-creek")) {
//			
////			driver.get(Url);
////			Thread.sleep(1000);
////			driver.findElement(By.xpath("//*[@id=\"comp-jpsqdr7t\"]/a/span")).click();
////			Thread.sleep(5000);
////			String address = driver.getPageSource();
////			String moadd = U.getSectionValue(address, "Model Home Address:</span></span></p>", "<div id=\"comp-jt21v93u\"");
////			moadd = moadd.replaceAll("\\s+\n","").replace("<p class=\"font_8\" style=\"font-size:17px;\"><span style=\"font-size:17px;\">","").replace("</span></p></div>","").replace("</span></p>","");
////			U.log("$$$$$$$$$$$$$$$$$$$$$$$ "+moadd);
//		}
		if(Url.contains("tel"))
			return;
		LOGGER.AddCommunityUrl(Url);
		
		
//		if(addSec==null) {
//		commhtml = getHtml(Url,driver);
//		addSec = U.getSectionValue(commhtml, "Model Home Address:</span></span></p>", "<div id=\"comp-jt21v93u\"");
//		addSec = addSec.replaceAll("\\s+\n","").replace("<p class=\"font_8\" style=\"font-size:17px;\"><span style=\"font-size:17px;\">","").replace("</span></p></div>","").replace("</span></p>","");
//	    U.log("$$$$$$$$$$$$$$$$$$$$$$$ "+addSec);
//	    addresSec.put("Moore's Creek", addSec);
//		}
		
		
	
			
		//========== CommunityName ==========
		//String commName = U.getSectionValue(commhtml, "<title>", "|");
		
		
//		if(addSec==null) {
//			driver.get("https://www.stoneridgehomesinc.com/moores-creek");
//			driver.findElement(By.xpath("//*[@id=\"comp-jpsqdr7t\"]/a/span")).click();
////			String mooreadd = driver.getPageSource();
//		}
//		U.log("addSec========="+addSec);

//		commhtml =  U.removeSectionValue(commhtml, "<head>", "</head>");
		//========== Address & LatLng ==========
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
		String note = ALLOW_BLANK;
		String geocode = "FALSE";
		
		if(Url.contains("/communities/the-meadows")) {
			
			String addSection = U.getSectionValue(commhtml, "Model Home", "Get Directions")
					.replace("<div class=\"u_1960910725 dmNewParagraph\" data-element-type=\"paragraph\" id=\"1960910725\" data-version=\"5\" data-uw-styling-context=\"true\" data-styletopreserve=\"{\" background-image\":\"\"}\"=\"\"><p class=\"m-size-19\" style=\"line-height: 1.6em;\"><span class=\"m-font-size-19\" style=\"font-weight: normal; display: initial;\">", "")
					.replace("", "");
			U.log("addSection: "+addSection);
			
			String[] sections = U.getValues(addSection, "display: initial;\">", "</span>");
			for(String sec:sections) {
				U.log("SEC: "+sec);
			}
			String addressCom = sections[0] + " " + sections[1];
			U.log("addressCom: "+addressCom);
			
			add = U.getAddress(addressCom);
			U.log("ADDRESS: "+Arrays.toString(add));
			
			String geoSec = U.getSectionValue(commhtml, "<iframe src=\"https://www.google.com/maps/embed", "</iframe>");
			U.log("geoSec: "+geoSec);
			
			latlng[0] = Util.match(geoSec, "\\!3d\\d{2}.\\d{5}").replace("!3d", "");
			latlng[1] = Util.match(geoSec, "\\!2d-\\d{2}.\\d{5}").replace("!2d", "");
			
			U.log("LATLONG: "+Arrays.toString(latlng));
		}
		
		if(Url.contains("/communities/carroll-green")) {
			
			//U.log("Sec: "+Sec);
			
			String addSection = U.getSectionValue(Sec, "p class=\\\"rteBlock\\\">", "</p></div>");  
			U.log("addSection: "+addSection);
			
			add = U.getAddress(addSection);
			U.log("ADDRESS: "+Arrays.toString(add));
			
			String geoSec = U.getSectionValue(commhtml, "<iframe src=\"https://www.google.com/maps/embed", "</iframe>");
			U.log("geoSec: "+geoSec);
			
			latlng[0] = Util.match(geoSec, "\\!3d\\d{2}.\\d{5}").replace("!3d", "");
			latlng[1] = Util.match(geoSec, "\\!2d-\\d{2}.\\d{5}").replace("!2d", "");
			
			U.log("LATLONG: "+Arrays.toString(latlng));
		}
		
		if(Url.contains("/communities/riverton-preserve")) {
			
			String addSection = U.getSectionValue(Sec, "p class=\\\"rteBlock\\\">", "</p></div>");  
			U.log("addSection: "+addSection);
			
			add = U.getAddress(addSection);
			U.log("ADDRESS: "+Arrays.toString(add));

			latlng = U.getlatlongGoogleApi(add);
			//add = U.getAddressGoogleApi(latlng);
			
			U.log("ADDRESS API: "+Arrays.toString(add));
			U.log("LATLONG API: "+Arrays.toString(latlng));
			geocode = "TRUE";
		}
		
		if(Url.contains("/communities/the-willows-at-sanctuary-cove")) {
			
			String addSection = U.getSectionValue(commhtml, "Directions", "HOA Information")
					.replace("unset;\">By Appointment Only", "");  
			//U.log(addSection);
			String address = U.getSectionValue(addSection, "display: unset;\">", ".</span></p>");
			U.log("address: "+address);
			
			add = U.getAddress(address);
			U.log("ADDRESS: "+Arrays.toString(add));
			
			latlng = U.getlatlongGoogleApi(add);
			U.log("LATLONG API: "+Arrays.toString(latlng));
			geocode = "TRUE";
		}
		
		if(Url.contains("/communities/cherokee-ridge")) {
			
			String addSection = U.getSectionValue(commhtml, "Sales Office", "Open Directions")
					.replace("unset;\">By Appointment Only", "");
			U.log("addSection: "+addSection);
			
			String[] lines = U.getValues(addSection, "font-weight: normal;\">", "</span></p>");
			for(String line:lines) {
				U.log("line: "+line);
			}
			String addLine = lines[0] + lines[1];
			U.log("addLine: "+addLine);
			
			add = U.getAddress(addLine);
			U.log("ADDRESS: "+Arrays.toString(add));
			
			String geoSec = U.getSectionValue(commhtml, "<iframe src=\"https://www.google.com/maps/embed", "</iframe>");
			U.log("geoSec: "+geoSec);
			
			latlng[0] = Util.match(geoSec, "\\!3d\\d{2}.\\d{5}").replace("!3d", "");
			latlng[1] = Util.match(geoSec, "\\!2d-\\d{2}.\\d{5}").replace("!2d", "");
			
			U.log("LATLONG: "+Arrays.toString(latlng));
		}
		
		if(Url.contains("/communities/the-retreat-at-goose-creek-townhomes")) {
			
			//U.log("Sec: "+Sec);
			
			add[1] = "Owens Cross Roads";
			add[2] = "AL";
			latlng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlng);
			
			U.log("ADDRESS API: "+Arrays.toString(add));
			U.log("LATLONG API: "+Arrays.toString(latlng));
			geocode = "TRUE";

		}
		
		if(Url.contains("/communities/bailey-park")) {
			
			String geoSec = U.getSectionValue(commhtml, "<iframe src=\"https://www.google.com/maps/embed", "</iframe>");
			U.log("geoSec: "+geoSec);
			
			latlng[0] = Util.match(geoSec, "\\!3d\\d{2}.\\d{5}").replace("!3d", "");
			latlng[1] = Util.match(geoSec, "\\!2d-\\d{2}.\\d{5}").replace("!2d", "");
			
			U.log("LATLONG: "+Arrays.toString(latlng));
		}
		
		U.log("Address ==== "+Arrays.toString(add));
		
		//for address using google API
		if(latlng[0] != ALLOW_BLANK && add[0] == ALLOW_BLANK) {
			
			add = U.getAddressGoogleApi(latlng);
			if(add==null) add = U.getAddressHereApi(latlng);
			geocode = "TRUE";
			
			U.log("ADDRESS API: "+Arrays.toString(add));
		}
		

		
		
		//========== Available and Floor ===========
		String avaUrl = U.getSectionValue(commhtml, "class=\"_2kLdM\"><a data-testid=\"linkElement\" href=\"", "Available Homes</span></a>");
		String avahtml=ALLOW_BLANK;
		String homedtail=ALLOW_BLANK;
		
		if(avaUrl!=null) {
			avaUrl = avaUrl.replace("\" target=\"_self\" class=\"_6lnTT\" aria-disabled=\"false\"><span class=\"wQYUw\">", "")
					.replace("\" target=\"_self\" class=\"_6lnTT\" aria-disabled=\"false\" tabindex=\"-1\" data-restore-tabindex=\"0\"><span class=\"wQYUw\">", "").trim();
			U.log("--------------"+avaUrl);
			avahtml = getHtml(avaUrl,driver);
			String[] homeUrl = U.getValues(avahtml, "<a href=\"", "\" target=\"_blank\"");
			
			for(String hUrl : homeUrl) {
				if(hUrl.contains("tel"))
					continue;
				String comhomehtml = U.getHTML(hUrl);
//				homedtail += U.getSectionValue(comhomehtml, "<div class=\"row align-items-center\">", "<div id=\"IDX-fieldsWrapper\"");
				homedtail += U.getSectionValue(comhomehtml, "<div class=\"row align-items-center\">", "<div class=\"col col-md-4");
				U.log(U.getCache(hUrl));
				
//				if(hUrl.contains("https://stoneridgehomesinc.idxbroker.com/idx/details/listing/c143/1795462/8021-Deer-Crossing-Circle-Owens-Cross-Roads-AL-35763?widgetReferer=true")) {
//					U.log("%%%%%%%%%"+homedtail);
//				}
				
			}	
		
			
			}
		//========== Price =============	
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices(commhtml+homedtail+Url+Sec+avahtml, "\\$ \\d{3},\\d{3}|\\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d+,\\d+|\\$\\d{6}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
//================== Sqft =====================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		commhtml =commhtml.replace("&nbsp;", " ").replace(" - ", " - ");
//		String newHtml = U.getSectionValue(U.getHTML(Url), " <!-- Sentry -->", "  <!-- preloading pre-scripts -->");
		String[] sq = U.getSqareFeet(Sec+commhtml+avahtml+homedtail,
				"\\d,\\d{3} SF|\\d,\\d{3} - \\d,\\d{3} Square Feet|ranging from \\d,\\d{3} - \\d,\\d{3} square feet|\">\\d,\\d{3} - \\d,\\d{3}</span></h4></div>|\\d,\\d{3} SQFT||Square Feet: \\d,\\d{3} sf - \\d,\\d{3} sf|Range:</span>\\d,\\d+ - \\d,\\d+</p>|</strong> \\d+ - \\d+</span>|"
				+ "SQ FT:</strong> \\d+-\\d+</span>|ranging from \\d,\\d{3} - \\d,\\d{3} SQ Ft|Sq. Foot Range:</span>\\d+ - \\d+</p>|SQ FT:</strong> \\d+<|\\d,\\d+ square|Approx. SQ FT: \\d{4}|SQ FT:</strong> \\d,\\d{3}|\\d,\\d+ minimum square|\\d{4} square feet minimum",0);
		
		minSqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
		maxSqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(avahtml+homedtail+Sec+commhtml, "[\\s\\w\\W]{30}1,435[\\s\\w\\W]{30}", 0));
//	U.log(homehtml);
//============== Derived Community Type ====================
		String ctype = U.getCommunityType(commhtml + Sec);
		
//============== Derived Property Type ====================
		String dType = U.getdCommType((commhtml+homedtail+avahtml).replaceAll("one- and two-story homes", "").replaceAll("\\d Level", "").replaceAll("One and One Half", "1.5 Story").replaceAll("Three Or More\\s*</span>", "third level").replaceAll("(Levels)</span><span class=\"IDX-text\">\\s*(One)", "$2 $1"));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(avahtml+commhtml+homedtail, "[\\s\\w\\W]{30}one story![\\s\\w\\W]{100}", 0));
//=============== Property Type ===================
		String propType = U.getPropType((Sec+commhtml+homedtail).replaceAll(", custom home\"|custom home&quot;|HOA Information|Carriage Style Garage Doors|HOA Info|hoa-|HOA is|"
				+ "maintenance-free living in the townhomes at The Retreat. Enjoy the|-townhome\"|townhomes-|townhomes\"|Townhomes\",|Townhomes</a><|Townhomes Google|TownhomesLogo-|Townhomes home|"
				+ "our craftsman-style townhomes|Creek Townhomes<|Townhome Pricing|Creek Townhomes|townhomes settled|Available Townhomes|townhome with|Retreat Townhomes|townhomes that|this townhome comes|Townhomes map|Townhomes IDX|cottage-|"
				+ "cottages\"|Cottage and|Cottages\"|Cottages Google|Cottages map|Cottages main|Cottage Series|cottage home",""));
		//=============== Property Status =====================
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		commhtml = commhtml.replace("Phases 2 and 3 are selling now", "Phases 2 and 3 selling now")
				.replace("Phase 4 is coming this summer", "Phase 4 coming summer");
		
		String pStatus = U.getPropStatus((Sec+commhtml).replaceAll("Coming Soon\"", "").replace("opening of The Meadows Phase III!", "Opening Phase III")
				.replaceAll(" - Coming Soon&#10| - Coming Soon", ""));
		
		U.log("pStatus: "+pStatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commhtml, "[\\s\\w\\W]{30}opening summer[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commhtml, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
		
		
		note=U.getnote(commhtml+Sec);
		U.log("note: "+note);
		
		
		
		//-------- Removing for oudated date event
		if(Url.contains("https://www.stoneridgehomesinc.com/communities/riverton-preserve")) pStatus = pStatus.replace("Grand Opening", ALLOW_BLANK);
		
		//-----------------------------------------------------------------------
		
		data.addCommunity(commName, Url,ctype);
		data.addAddress(U.getNoHtml(add[0]).trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0], latlng[1], geocode);
		data.addPropertyType(propType,dType );
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
		inr++;
		
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
		}
		{
			if (!f.exists()) {
				synchronized (driver) {
					BufferedWriter writer = new BufferedWriter(new FileWriter(f));
					Thread.sleep(5000);
					driver.get(url);
					Thread.sleep(10000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); // y value '400' can
					Thread.sleep(5000);
					if(url.contains("community-map")||url.endsWith("idx")) {
						driver.switchTo().frame(0); // community map
						U.log("Inside");
					}else if(driver.getPageSource().contains("Directions")) {
						//driver.findElement(By.xpath("//*[@id=\"comp-jpsqdr7t\"]/a")).click();
					}
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();
				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			  }
			return html;
		}	
	}
}