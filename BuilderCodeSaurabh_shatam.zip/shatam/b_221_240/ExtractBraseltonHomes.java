/**
 * @new code : By Priti 
 * @Date Oct2016
 * @author Parag Humane 
 * @date 16/04/2012
 * 
 */
package com.shatam.b_221_240;



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBraseltonHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int j=0;
	WebDriver driver = null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractBraseltonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Braselton Homes.csv", a.data() 
				.printAll());
	}

	public ExtractBraseltonHomes() throws Exception {
		super("Braselton Homes", "http://www.braseltonhomes.com/");
		LOGGER = new CommunityLogger("Braselton Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
//		U.setUpChromePath();
		driver = new ChromeDriver();  //U.getFirefoxCapabilities()
		//New Code-Oct2016
		String mainUrl="http://www.braseltonhomes.com/";
		String mainHtml = U.getHtml(mainUrl,driver);
		String comUrlSec=U.getSectionValue(mainHtml, "<li>NEIGHBORHOODS", "<!-- <li>");
		U.log(comUrlSec);
		comUrlSec = U.removeComments(comUrlSec);
		String[] urls=U.getValues(comUrlSec, "<li>", "</li>");
		U.log(urls.length);
		for(String url:urls){
		
		//com name
		String name=U.getSectionValue(url, "\">", "</a>");
		//U.log("name::"+name);
		
		//com url
		url=U.getSectionValue(url, "<a href=\"", "\">");
		String comUrl=ALLOW_BLANK;	
		if(!url.contains("http")){
			comUrl=mainUrl+url;
		}
		else{
				comUrl=url;
		}
		

		addDetails(comUrl,name);
		
		}
		
		
		 LOGGER.DisposeLogger();
		 driver.quit();
		// try{ driver.quit();}catch(SessionNotCreatedException e ){}
	}
	
	
	//--New Code --by Priti
	private void addDetails(String url,String name) throws Exception {
		//TODO : For Single Community Execution
//		if(j==0)
		{
		String comHtml=ALLOW_BLANK;
		U.log("url : "+url+"\nname::"+name);
		U.log(U.getCache(url));
		
		LOGGER.AddCommunityUrl(url);
		
		comHtml=getHtml(url, driver);
		
		
		String comName=ALLOW_BLANK;
		comName=name;
		
		comName=comName.replace(" Country Club", "");
		
		//Drop left layout which is common for all communities
		
		String dropleft=U.getSectionValue(comHtml, "<div class=\"col-xs-12 col-md-4 nopadding leftColumn\">", "<div class=\"homeImage\">");
		
		if(dropleft==null){
			dropleft=U.getSectionValue(comHtml, "<div class=\"col-xs-12 col-md-4 nopadding leftColumn\">", "col-xs-12 col-md-8 nopadding rightColumn");
		}
		
		if(dropleft!=null)comHtml=comHtml.replace(dropleft, "");		
		
		
		String notes=ALLOW_BLANK;
		notes=U.getnote(comHtml);
		
		//lat-lng
		
		String latlngsec=U.getSectionValue(comHtml, "ll=", "&amp;"); 
		if(latlngsec==null) {
			latlngsec=U.getSectionValue(comHtml, "https://www.google.com/maps/embed?pb=","\"");
			latlngsec=U.getSectionValue(latlngsec, "!2d", "!2m");
		}
		U.log(latlngsec);
		
		String latLng[]={ALLOW_BLANK,ALLOW_BLANK};
		String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo="False";
		if(latlngsec!=null){
			String[] latl=	latlngsec.split("!3d");
			latLng[0]=latl[1];
			latLng[1]=latl[0];
		}
		U.log(latLng[0]);
		U.log(latLng[1]);
		
		if(url.contains("http://www.braseltonhomes.com/KH.html")){
			add[1]="Kitty Hawk";
			add[2]="NC";
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo="true";
			notes="Lat-Lng and Address Taken From City And State";
		}
		
		//fetch the address from the lat-lng, as address wasn't present of page 
		if(latLng.length==2){
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo="True";
		}
		
		//Available homesites plans
		String availHtml=ALLOW_BLANK;
		String[] availHomeUrls =  U.getValues(comHtml, "<iframe width=\"660\" height=\"690\" frameborder=\"0\" src=\"", "\"");
		U.log("Total Home :"+availHomeUrls.length);
		for(String availUrl:availHomeUrls){
			availUrl=availUrl.replace("&amp;", "&");
			U.log("Hello::::::::"+availUrl+"Hello");
			if(availUrl.length()!=0){
			availHtml=availHtml+U.getHTML(availUrl);
			}
			
		}
		
		//======== Available Homesite Image Sqft & price ====================
		String[] iframeUrlSection = U.getValues(comHtml, "<iframe id=\"topoIframe", "</iframe>");
		String iframeHtml = ALLOW_BLANK;

		for(String iframeUrlSec : iframeUrlSection){
				String iframeUrl = U.getSectionValue(iframeUrlSec, "src=\"", "\"");
					
					if(iframeUrl.isEmpty() || iframeUrl == null)continue;
					iframeUrl = iframeUrl.replaceAll("amp;", "");
					U.log("======"+iframeUrl);
					iframeHtml += U.getHtml(iframeUrl, driver);
				
		}
			
		String allIFrameHomesdata = ALLOW_BLANK;
		String [] iframeHomes = U.getValues(iframeHtml, "\"LotStatus\":", "\"URL\":null");
		for(String iframeHom : iframeHomes) {
			if(!iframeHom.contains("\"Closed\",")&& !iframeHom.contains("\"Sold\","))
			allIFrameHomesdata += iframeHom;
		}
		
		
		//Square feet
		
		String minSqft=ALLOW_BLANK, maxSqft=ALLOW_BLANK;
		
		String[] sqft=U.getSqareFeet(comHtml+availHtml+iframeHtml, "\\d+ sqft|\\d{4} Sq. Ft. to \\d,\\d{3} Sq. Ft.", 0); 
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqft:"+minSqft+" maxsqft::"+maxSqft);
		
		//Price
		comHtml=U.removeComments(comHtml);
		comHtml=comHtml.replace("0's.", "0,000");
		comHtml = comHtml.replace("$160's", "$160,000");
		comHtml = comHtml.replace("$170's", "$170,000");
		//U.log("iframeHtml:::::::::"+iframeHtml);
		String minPrice=ALLOW_BLANK, maxPrice=ALLOW_BLANK;
		String price[]=U.getPrices(comHtml+availHtml+allIFrameHomesdata, "\\$\\d{3},\\d{3}| starting from the \\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice:"+minPrice+" maxPrice::"+maxPrice);
		
		//comType, propType, dType status
		String comType=ALLOW_BLANK;
		String propType=ALLOW_BLANK;
		String dType=ALLOW_BLANK;
		String status=ALLOW_BLANK;
		
		comType=U.getCommunityType(comHtml);
		String remExeCon=U.removeSectionValue(comHtml, "<div class=\"executiveSeries margin-bottom-15\" style=\"display:none;\">", "</div>");
		String remTradCon=U.removeSectionValue(remExeCon, "<div class=\"traditionalSeries margin-bottom-15\" style=\"display:none;\">", "</div>");
		comHtml=remTradCon.replaceAll("class=\"cottageSeries|<div class=\"col-md-12 floorPlanHeading\">\\s*Bungalow Series\\s*</div>|floorPlanHeading\">\\s+Cottages Series|Corpus Christi single family homes|TRADITIONAL|custom home", "");
		
		comHtml = comHtml.replace("luxury estate living", "luxury living estate living")//.replaceAll("col-md-12 floorPlanHeading\">\\s+Traditional", "")
				.replace("Traditional Series", "Traditional Homes")
				.replaceAll("class=\"traditional", "");
		
		comHtml=U.removeComments(comHtml);
		propType=U.getPropType(comHtml);
		if(url.contains("http://www.braseltonhomes.com/neighborhood.html?neighborhood_id=Oso%20View") || url.contains("http://www.braseltonhomes.com/neighborhood.html?neighborhood_id=Village%20Rancho"))propType=ALLOW_BLANK;
		comHtml=comHtml.replace("Story:</strong>", "Story");
		
		comHtml=comHtml.replaceAll("Rancho|Rancho|=Rancho|rancho", "")
				.replace("lakeside, and bayfront homesites available", "lakeside and bayfront homesites available");
		
		comHtml=comHtml.replace("Story:</strong> 1", "Stories: 1").replace("</span> Available Homesites", " Available Homesites");
		//U.log(comHtml);
		dType=U.getdCommType(comHtml.replaceAll("\\.00|Rancho|rancho", ""));
		dType=dType.replace("Ranch,","");
		status=U.getPropStatus(comHtml);
		
		
		
		if(status.equals("0 Available Homesites")){
			status=status.replace("0 Available Homesites",ALLOW_BLANK);
		}
		if(url.contains("http://www.braseltonhomes.com/neighborhood.html?neighborhood_id=Northshore"))
			comType+=", Lakefront Community";
		if(status.length()>4) {
			status+=", New Floor Plans Coming Soon";
		}
		else {
			status="New Floor Plans Coming Soon";
		}
		data.addCommunity(comName, url, comType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addNotes(notes);
		
		}j++;
		
		
		
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		//int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
//					driver.manage().addCookie(new Cookie("visid_incap_612201", "gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"));	
					driver.get(url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,4000)", ""); // y value '400' can
													// be
					Thread.sleep(2000);
					try{
					WebElement click = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[3]/div[3]/div[1]/div[2]/div")); //available floorplan //html/body/div/div/div[2]/div[3]/div[3]/div[1]/div[2]/div
					click.click();
					Thread.sleep(5000);
					U.log("success1");
					}
					catch(Exception e){
						U.log(e.toString());
					}
					try{
						WebElement click = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[3]/div[3]/div[1]/div[3]/div")); //available homesite //html/body/div/div/div[2]/div[3]/div[3]/div[1]/div[2]/div
						click.click();
						U.log("success2");
						Thread.sleep(5000);
						}
						catch(Exception e){
							U.log(e.toString());
						}
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,4000)", ""); 
					Thread.sleep(10000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		
	}
	
}
	