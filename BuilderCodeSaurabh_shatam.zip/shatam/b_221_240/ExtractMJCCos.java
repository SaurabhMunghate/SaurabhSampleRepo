package com.shatam.b_221_240;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMJCCos extends AbstractScrapper {
	static String BASEURL = "https://www.mjccompanies.com";
	CommunityLogger LOGGER;
	static int j = 0;
	static int i;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractMJCCos();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"MJC Companies.csv", a.data().printAll());
	}

	public ExtractMJCCos() throws Exception {

		super("MJC Companies", BASEURL);
		LOGGER = new CommunityLogger("MJC Companies");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML(BASEURL);
		String section = U.getSectionValue(html, "<ul class=\"nav primary\">",	"<ul class=\"nav top");
		String links[] = U.getValues(section, "href=", ">");
		for (String link : links) {
			String mainurl = U.getSectionValue(link, "\"", "\"");
			if(mainurl.contains("quick-occupancy/"))continue;
			mainurl = BASEURL + mainurl;

			findcommunitydetails(mainurl);
		}
		LOGGER.DisposeLogger();
	}

	public void findcommunitydetails(String mainurl) throws Exception {
		String html = U.getHTML(mainurl);
		U.log("mainurl:::"+mainurl);
		
		//U.log(html);
		String community_section[] = U.getValues(html, "<a href=\"https:",
				"</div>");
//		U.log(community_section.length);
		for (String sec : community_section) {

			addDetails(sec);
		}
	}

	public void addDetails(String sec) throws Exception {
//	if(j == 9)
		{

			//U.log("Count :"+j);
			
			// .......................community url.......
			
			String url = U.getSectionValue(sec, "mjccompanies.com", "\"");
			if (url == null)
				return;
//			 U.log(sec);
			

			url = "https://mjccompanies.com" + url;
			U.log(j+"\tComm Url ==" + url);

/// Single Run
//			if(!url.contains("https://mjccompanies.com/properties/single-family-homes/wolverine-country-club")) return;// Single Run
			
			String newhtml = U.getHTML(url);


			
			//U.log("======"+U.getCache("https://mjccompanies.com/properties/single-family-homes/woodland-crossing"));
//			U.log(newhtml);
			
			if(url.contains("https://mjccompanies.com/properties/apartments/barrington-apartment-homes")){
				newhtml = newhtml.replace("<h3>Quick Occupancy Homes", "")
						.replaceAll("Sales Price</div>\\$\\d+|>Patio</span>", "");
			}
			
			if(url.contains("https://mjccompanies.com/properties/apartments/manors-at-knollwood")){
				newhtml = newhtml+U.getHTML("https://www.manorsatknollwood.com")+U.getHTML("https://www.manorsatknollwood.com/floor-plans");

			}
			
			if(url.contains("https://mjccompanies.com/properties/apartments/huntley-manor-apartments")){
				newhtml = newhtml+U.getHTML("https://huntleymanor.com")+U.getHTML("https://huntleymanor.com/floor-plans/");
				String quicksec = U.getSectionValue(newhtml,
						"<h3>Quick Occupancy Homes</h3>", "<div class=\"right\">");
				newhtml=newhtml.replace(quicksec, "");
			}
			
			if(url.contains("https://mjccompanies.com/properties/apartments/shearwater-apartments")){
				newhtml = newhtml+U.getHTML("https://rentshearwater.com")+U.getHTML("https://rentshearwater.com/floor-plans/");
				String quicksec = U.getSectionValue(newhtml,
						"<h3>Quick Occupancy Homes</h3>", "<div class=\"right\">");
				newhtml=newhtml.replace(quicksec, "").replace("$223,900", "");
			}
			
			

			String commName = U.getSectionValue(newhtml.replace("Huntley Manor", "Huntley"), "<title>", "|");
			U.log("===========" + commName);
			if (commName.contains(".")) {
				commName = commName.split("\\. ")[0];
			}
			if(commName.trim().endsWith("Villas"))commName=commName.replace("Villas", "");
			if(commName.trim().endsWith("Apartments"))commName=commName.replace("Apartments", "");
			commName =commName.trim().replaceAll("Condos$|Apartment Homes$", "");
			commName=commName.replace("Country Club Estates", "");
			
			U.log("===========" + commName + "Hello");

			// ................ comunity type,property type, property
			// status.................................
			
		//	U.log(sec);
		
			newhtml=newhtml.replace("1 1/2 story home plans", "1 1/2 storyhome plans");
			newhtml = newhtml.replace("residents the luxury of choice", "luxury homes of choice");
			
			
			newhtml = newhtml.replace(
					"<a href=\"/properties/condominiums/\">Condominiums</a>",
					"");
			newhtml = newhtml
					.replaceAll(
							"properties/single-family-homes/\">Single Family Homes</a><|Closeout Incentives: |apartments/\">Apartments</a></li>|Villager|Move in Ready Homes at this site have been sold",
							"");
			newhtml = newhtml.replace("Each home is custom", " and custom homes")
					.replaceAll("(V|v)illage", "");
			//U.log(newhtml);
			String quicksec = U.getSectionValue(newhtml,
					"<h3>Quick Occupancy Homes</h3>", "<div class=\"right\">");
			//U.log(quicksec);
			String quickhtml = ALLOW_BLANK;
			String[] quickUrls=null;
			if(quicksec!=null) {
				 quickUrls = U.getValues(quicksec, "<a href=\"", "\">");
				for (String quickUrl : quickUrls) {
					U.log(quickUrl+":::::::::::::::quick url:::::::::");
					quickhtml = quickhtml	+ U.getHTML("https://mjccompanies.com" + quickUrl);
				}
			}
			newhtml=newhtml.replaceAll("Level:</span>\\d+-Carriage", "Level: The Carriage Collection")
					.replace("Coming Soon - Spring 2020", "Coming Soon Spring 2020")
					.replace("bathed in luxury and", "bathed in luxury homes and")
					.replaceAll("Cottage Lane", "");
			
			String proptype = U.getPropType((newhtml+quickhtml).replaceAll("Level:</span>carriage homes</span>|Craftsman%29\\.jpg\">|raftsman\\.jpg\"|Coventry_Farmhouse.jpg|\\d{2}Craftsman|\\d{2}Farmhouse|Wheatland Estates|Estate-Sized homesites |<option value=\".*\">.*</option|<a href=\".*\">.*</a|<a class=\".*\">.*</a", ""));
			U.log("=============================" + proptype);
			
			
			
		//	U.log("sEC= "+sec);
			String propstatus = U.getPropStatus((newhtml + sec).replaceAll("uppercase\">NOW OPEN!|p>Wixom</p>\\s*<p>Coming Soon|<span style=\"font-size:43px\">NOW OPEN!</span>", ""));

			U.log(propstatus);

			// .........................address and latitude and
			// longitude and Notes.................................
			String note=U.getnote((newhtml+sec).replaceAll(" <h4>Contact</h4>\\s*<p>Coming Soon Spring 2020<br />", ""));
			String geo = "FALSE";
			//U.log(U.getSectionValue(newhtml, "<div id=\"map\"></div>", "</script>"));
			String latsec = U.getSectionValue(newhtml, "{initialize(", ", '");
			U.log("latsec: "+latsec);
			String latlng[] = latsec.split(",");
			if(latlng[0] == null || latlng[0].isEmpty())
				latlng[0] = latlng[1] = ALLOW_BLANK;
			 U.log(latlng[0]+"================="+latlng[1]);
					
			//------------------adress---------------//
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
						
			String addSec = ALLOW_BLANK;
			addSec=U.getSectionValue(newhtml, "https://www.google.com/maps", "a>");
			
			if(addSec!=null) {
				if(latlng[0] == ALLOW_BLANK && latlng[1] ==  ALLOW_BLANK){
					latsec = U.getSectionValue(addSec, "/@", ",15z/");
					latlng = latsec.split(",");
				}
			}
			
			
			
			if(addSec!=null) {
				addSec=U.getSectionValue(addSec.replaceAll("<br(.*?)/>", ","), ">", "<");
				add=U.getAddress(addSec);
			}
			if(url.contains("https://mjccompanies.com/properties/single-family-homes/paint-creek-estates")) {
				addSec = "756 Lindenhill Lane, Oakland Twp, MI 48363";
				add=U.getAddress(addSec);
			}
			if(add[3].length()<2 && newhtml.contains("/maps/place/")) {
				String zip=U.getSectionValue(newhtml, "+"+add[2]+"+", "/");
				if(zip!=null)
					add[3]=zip;
			}
			
			
			
			
			if(addSec==null) {
					addSec = U.getSectionValue(newhtml, "<a href=\"http://maps.google.com/maps?saddr=&amp;daddr=", "\"");
					
				U.log("addSec :::::::::  "+addSec);
				if(addSec!=null){
					addSec  = U.formatAddress(addSec);
					addSec = addSec.replace("48377 Commonview Shelby", "48377 Commonview Drive, Shelby").replace("Washington Township", "Washington");
					
					if(!addSec.contains(", MI"))addSec = addSec.replace(" MI", ", MI");
					U.log("::::::::::::DIRECTION_ADDRESS:::::::::::::::::"+addSec);
					add = U.getAddress(addSec);
					U.log(Arrays.toString(add));
				}	
			}
			
			if(url.contains("https://mjccompanies.com/properties/single-family-homes/Bradbury-at-Stony-Creek")) {
				addSec = U.getSectionValue(newhtml, "<a href=\"http://maps.google.com/maps?saddr=&amp;daddr=", "\"");
			U.log("addSec :::::::::  "+addSec);
			if(addSec!=null){
				addSec  = U.formatAddress(addSec);
				addSec = addSec.replace("48377 Commonview Shelby", "48377 Commonview Drive, Shelby").replace("Washington Township", "Washington");
				
				if(!addSec.contains(", MI"))addSec = addSec.replace(" MI", ", MI");
				U.log("::::::::::::DIRECTION_ADDRESS:::::::::::::::::"+addSec);
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}	
		}

			if(url.contains("https://mjccompanies.com/properties/condominiums/midtown-crossing")) {
				addSec = U.getSectionValue(newhtml, "<a href=\"http://maps.google.com/maps?saddr=&amp;daddr=", "\"");
				
			U.log("addSec :::::::::  "+addSec);
			if(addSec!=null){
				
				addSec = addSec.replace("986 , Troy, MI 48084", "986 Cottage Lane, Troy, MI 48085");
				if(!addSec.contains(", MI"))addSec = addSec.replace(" MI", ", MI");
				U.log("::::::::::::DIRECTION_ADDRESS:::::::::::::::::"+addSec);
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}	
		}
			
			if(url.contains("https://mjccompanies.com/properties/single-family-homes/preston-corners-manors")) {
				add[0] = ALLOW_BLANK;
				add[1] = "Shelby Township";
				add[2] = "MI";
				add[3] = ALLOW_BLANK;
				latlng = U.getlatlongGoogleApi(add);
			}
			U.log("ADD :::"+Arrays.toString(add));
			
			if(add[3].length()<4 && newhtml.contains("Sales Center")){
				U.log("::::::::::::ADDRESS_SALE_CENTER:::::::::::::::::");
				if(newhtml.contains("Sales Center")){
					newhtml = newhtml.replace("Sales Center Located at", "Sales Center:");
					addSec = U.getSectionValue(newhtml, "Sales Center:", "Open Daily");
					if(addSec!= null) {
					addSec = addSec.replaceAll("<a href=\".*?\">|</strong><br />", "").replaceAll("<br(.*?)/>\\s*", ",");
					addSec = addSec.replace(",1315 Waterside", "1315 Waterside")
							.replaceAll(",Addison Crossing Model,", "")
							.replaceAll("^,", "");
					
					
					U.log(addSec);
					add = U.getAddress(addSec);
					
					U.log(Arrays.toString(add));}

				}
			}
//			if(url.contains("https://mjccompanies.com/properties/single-family-homes/white-oaks")) {
//				String sec1= "41745 Midtown Circle, Novi, Michigan 48375, USA";
//				add=U.getAddress(sec1);
//				latlng[0]="42.480106";
//				latlng[1]="-83.452266";
//			}
			
			//if(url.contains("/properties/condominiums/boulder-pointe"))add[0] = "6833 Boulder Pointe Drive";
			if(add[0].length()<4 || add[3].length()<4){
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add =U.getAddressHereApi(latlng);
				geo="TRUE";
			}
			
		
			add[1] = add[1].replace("Twp.", "Twp");

//			newhtml = newhtml.replaceAll("first floor master suites|First floor master suites", " 1 story master suites");
			if(quickhtml != null)
				quickhtml = quickhtml.replaceAll("value=\"(Colonial|Split Level|floor|Floor|Upper Ranch)\">(Colonial|Split Level|Upper Ranch)", "");
			
			if(url.contains("https://mjccompanies.com/properties/apartments/shearwater-apartments"))
				newhtml += U.getHTML("https://rentshearwater.com/floor-plans/").replace("Floor", "story");
			
			String dtype = U.getdCommType((newhtml + sec+quickhtml).replace("value=\"Two-Story\">Two-Story</option>", "").replace("\"Split-Level\">Split-Level", ""));
			U.log(Util.matchAll(newhtml + sec+quickhtml,"[\\w\\s\\W]{30}Two-Story[\\w\\s\\W]{30}",0));
			if(quickhtml.contains("gated community")) {
				newhtml=newhtml+" gated community ";
			}

			String communtiyPage=U.getHTML(url+"/community");
			communtiyPage=communtiyPage.replace(U.getSectionValue(communtiyPage, "<div id=\"footer\">", "</html"),"");
			if(url.contains("shearwater-apartments"))
				communtiyPage=U.getHTML("https://rentshearwater.com/features/");
			if(url.contains("/huntley-manor-apartment"))
				communtiyPage=U.getHTML("https://huntleymanor.com/features/");
			communtiyPage=communtiyPage.replaceAll("Lakeside Circle|Lakeside+Mall|Lakeside_Mall.jpg|Lakeside Mall", "");
			communtiyPage=communtiyPage.replaceAll("www.shop-lakesidemall.com", "");
			communtiyPage = communtiyPage.replace("Picturesque lakefront views", "serene waterfront community");
			
			newhtml = newhtml.replace("lakefront views", "lakefront community views");
			
			
			String communitytype = U.getCommunityType((newhtml + sec+communtiyPage).replaceAll("Resort-like Pool|resort-style pool|www.shop-lakesidemall.com|Picturesque lakefront views|resort-inspired|Lyon Oaks Golf Course|Taylor Golf Course", "").replace("gated community //mjccompanies.com/", ""));
			
			// ..............................prizes..............................
		//	U.log("==========" + sec);
			
			sec = sec.replaceAll("0s|0's|0's", "0,000").replaceAll("Leasing from the \\$1,400|Leasing from the $1,700", "");
			newhtml = newhtml.replace("0&#39;s", "0,000");
			String price[] = U.getPrices(newhtml+quickhtml+sec,
					"\\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log(minPrice);
			U.log(maxPrice);

			// ............................ square
			// feet..........................................
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String floorsection = U.getSectionValue(newhtml,
					"<table class=\"models", "</table>");
			
			String floorHtml = "";
			String quickHtml = "";
if(url.contains("huntley-manor-apartments")) {
	U.log("hello i am in");
	floorHtml = U.getHTML("https://huntleymanor.com/floor-plans/");
	quickHtml = U.getHTML("https://huntleymanor.com/availabilities/");
	dtype = U.getdCommType(floorHtml.replace("1st floor", "first floor").replace("2nd floor", "second floor")+quickHtml);
}
			
			String sqft[] = U
					.getSqareFeet(
							newhtml + quickhtml+floorHtml+quickHtml,
							"class=\"column-\\d+\">\\d,\\d{3}</td>|\\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d{3} sf – \\d,\\d{3} sf|Sq. Ft.:</span>\\d,\\d+|\\d,\\d+ sq. ft.|Size:</span> \\d,\\d+</li>|\\d,\\d{3}\\.\\d SQ FT|<td class=\"column-4\">\\d,\\d{3}</td>",
							0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			// }
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			if (data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			commName = commName.replace("&#8217;", "").replace("MJC", "");
			
			U.log("===========" + commName);
			if(quickUrls != null && quickUrls.length >0) {
				if(propstatus.length()<4)
				propstatus  = "Quick Occupancy Homes";
			   if(propstatus.length()>4 && !propstatus.contains("Quick Occupancy Homes"))
				  propstatus  = propstatus+", Quick Occupancy Homes";
			}

			if(url.contains("https://mjccompanies.com/properties/apartments/shearwater-apartments")) proptype = proptype.replace("Carriage Home,", "");
			if(url.contains("properties/single-family-homes/golf-lake-estates"))propstatus="Final Lots Close Out, "+propstatus;
		//	if(url.contains("properties/condominiums/midtown-crossing")) propstatus="Now Open";//Img
		//	if(url.contains("https://mjccompanies.com/properties/single-family-homes/stonegate-village")) propstatus="Now Open, "+propstatus;
			
//			if(url.contains("https://mjccompanies.com/properties/apartments/barrington-apartment-homes")) propstatus="Now Open";
			
			if(url.contains("/properties/condominiums/boulder-pointe")){
				if(propstatus==ALLOW_BLANK)propstatus="Close Out";
				else if(propstatus!=ALLOW_BLANK)propstatus+=", Close Out";
			}
//			if(url.contains("https://mjccompanies.com/properties/single-family-homes/woodland-crossing")){
//				minPrice="$490,900";
//				maxPrice="$520,900";
//			}
			if(url.contains("https://mjccompanies.com/properties/apartments/harvard-place-apartments"))	{
				minPrice=ALLOW_BLANK;
				maxPrice=ALLOW_BLANK;
			}
			if(url.contains("https://mjccompanies.com/properties/apartments/manors-at-knollwood"))	{
				minSqf="930";
				maxSqf="1450";
				minPrice= maxPrice = ALLOW_BLANK;
			}
			if(url.contains("/manors-at-knollwood")) propstatus=ALLOW_BLANK;// redirecting to diff url
			if(url.contains("/huntley-manor-apartments"))propstatus ="Now Open";
			if(url.contains("/barrington-apartment-home"))proptype="Apartment Homes, Luxury Homes, Patio Homes";
			add[1] = add[1].replaceAll(" \\(.*\\)", "");
			// ...........................adding in
			// csv............................................
			data.addCommunity(commName, url, communitytype);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1].trim(), geo);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(propstatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
		}
		j++;
	}
}