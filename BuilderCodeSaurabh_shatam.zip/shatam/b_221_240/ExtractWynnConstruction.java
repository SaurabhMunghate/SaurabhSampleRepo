

package com.shatam.b_221_240;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWynnConstruction extends AbstractScrapper {

	CommunityLogger LOGGER;
	static int j = 0;
	WebDriver driver = null;
	final String BUILDER_URL = "http://www.wynnhomes.com";
	int count = 0;

	public ExtractWynnConstruction() throws Exception {

		super("Wynn Construction", "http://www.wynnhomes.com/");
		LOGGER = new CommunityLogger("Wynn Construction");
	}

	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		AbstractScrapper a = new ExtractWynnConstruction();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Wynn Construction.csv", a.data()
				.printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		String homeUrl = "http://www.wynnhomes.com/communities";
		String homeHtml = U.getHtml(homeUrl, driver);
		String comSec = U.getSectionValue(homeHtml, "</info-window></div>",
				"</div><style></style></main>");

		String comUrlSec[] = U.getValues(comSec,
				"<div class=\"result-media\">",
				"Visit Community</a></div></li>");
		String latLongSec[] = U.getValues(homeHtml, "<marker id=\"",
				"></marker>");
		for (String urlSec : comUrlSec) {
			U.log(":::::::::::::::"+count+":::::::::::");
			getComDetails(urlSec, latLongSec[count]);
			count++;

		}
		driver.close();
		try {
		driver.quit();
		}catch (Exception e) {
		}
	}

	private void getComDetails(String urlSec, String latLongSec)
			throws Exception {
		//if(j==2)
		{
		// *********************Community Url******************
		String communityUrl = U.getSectionValue(urlSec, "<a ng-href=\"", "\"");
		communityUrl = BUILDER_URL + communityUrl;
		U.log(communityUrl);
		U.log(U.getCache(communityUrl));
		//if(!communityUrl.contains("http://www.wynnhomes.com/wyndwater"))return;

		// ******************Community Name*********************
		String CommunityName = U.getSectionValue(urlSec, "title ng-binding\">",
				"</h4>");
		if(CommunityName.endsWith("Townhomes"))CommunityName=CommunityName.replace("Townhomes", "");
		U.log(CommunityName+":::::::::::::");

		String comHtml = U.getHtml(communityUrl, driver);
		String avlHomeUrl = communityUrl + "-homes";
		String floorPlnUrl = communityUrl + "-rendered-plans";
		U.log("floorPlnUrl::::::::"+floorPlnUrl);
		U.log(avlHomeUrl);
		U.log(floorPlnUrl);
		String avlHtml = U.getHtml(avlHomeUrl, driver);
		String remSec = U.getSectionValue(avlHtml, "Filter by Community",
				"</select></div><div");
		if(remSec!=null)
		avlHtml = avlHtml.replace(remSec, "");
		String floorHtml = U.getHtml(floorPlnUrl, driver);
        
		
		// ******************Community Prices*******************

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices(avlHtml, "\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice::"+minPrice+"  maxPrice::"+maxPrice);
		

		// ******************Community SQFT*********************

		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(floorHtml + avlHtml+comHtml,
				"\\d{4} Sqft|\\d+ -\\d+ Sqft |\\d,\\d+ <span>SQFT|SQFT: \\d,\\d+|\\d,\\d+ - \\d,\\d+ sq. ft.|\\d,\\d+ to \\d,\\d+ square feet|\\d,\\d+ – \\d,\\d+ sq. ft.|\\d,\\d+ square feet", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// ******************Community Address*******************
		String geo="False";
		String street = ALLOW_BLANK;
		String city = ALLOW_BLANK;
		String state = ALLOW_BLANK;
		String zip = ALLOW_BLANK;
		street=U.getSectionValue(comHtml,"LOCATION</h5><li class=\"ng-binding\">","</li>");
		city = U.getSectionValue(comHtml,
				"city_name\" class=\"ng-binding ng-scope\">", "</span>");
		state = U.getSectionValue(comHtml,
				"state_code\" class=\"ng-binding ng-scope\">,", "</span>");
		if(state!=null)state=state.trim();
		zip = U.getSectionValue(comHtml,"com_zip\" class=\"ng-binding ng-scope\">", "</span>");
		
		U.log("Street:: "+street+" City:: "+city+"  State:: "+state+"  Zip:: "+zip);
		// ******************Community LatLong*******************
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String lat = ALLOW_BLANK;
		String lng = ALLOW_BLANK;
		String latSec = U.getSectionValue(latLongSec, "position=\"", "\"");
		String latlng[] = latSec.split(",");
		lat = latlng[0].trim();
		lng = latlng[1].trim();
		U.log(lat+":::::::::::::"+lng);
		
		if(street==ALLOW_BLANK || street.length()<4)
		{
		add = U.getAddressGoogleApi(latlng);
		street = add[0];
		city=add[1];
		state=add[2];
		geo="True";
		
		}
		//------------if zip is not present ----------
		if(zip.length()<4){
			add = U.getAddressGoogleApi(latlng);
			zip=add[3];
			geo="TRUE";
		}
		
		// ******************Community Details*******************
		
		String rem = "half acre homesites available in a |Outdoorpatio|_outdoorpatio|community.com_HOA.length|ng-if=\"community.com_HOA.length\" class=\"hoa\"><h4>HOA Information</h4><div|-html=\"community.com_HOA\" class=\"textbox\"></div>|master-planned-community\">";
		comHtml = comHtml.replaceAll(rem, "");
		comHtml=comHtml.replaceAll("village|Village|VILLAGE","");
		comHtml=comHtml.replace("view homesites are available", "view homesites available").replace("1st Floor Living Areas", "1 Story Living Areas");
	
		//--status from image--------
		comHtml = comHtml.replace("_now_selling.jpg", " now selling ").replace("_sold_out.jpg", " sold out ");
		
		String propStatus = U.getPropStatus(comHtml);
		propStatus=propStatus.replace("Coming in 2016", "Coming in 2016");
		
		//dtype from indivdual plans present in floor plan url
		String allFloorhtml=ALLOW_BLANK;
		if(!floorHtml.contains("No plans match this criteria")){
			U.log("Success");
			String[] allFloorUrls=U.getValues(floorHtml, "<a class=\"btn\" ng-href=\"", "\"");
			for(String allFlrUrl :allFloorUrls){
				allFlrUrl=BUILDER_URL+allFlrUrl;
				U.log("allFlrUrl::"+allFlrUrl);
				allFloorhtml=U.getHtml(allFlrUrl,driver)+allFloorhtml;
			}
		}
		//dtype from indivdual homes present in available home 
		String allAvlHtml=ALLOW_BLANK;
		if(!avlHtml.contains("Please check back again soon for new home listings")){
			U.log("Success2");
			String[] allHomeUrls=U.getValues(avlHtml, "result-col-btn", "View Detail");
			for(String allHomeUrl :allHomeUrls){
				String url=U.getSectionValue(allHomeUrl, "<a ng-href=\"","\"");
				U.log("URL :::::::"+url);
				allHomeUrl=BUILDER_URL+url;
				String aHtml = U.getHtml(allHomeUrl,driver);
				U.log("avlHomeUrl::"+allHomeUrl);
				allAvlHtml += U.getSectionValue(aHtml	, "<h1>Home Details</h1>"	, "l-detail-aside");
		}
		}
		String propType = U.getPropType(comHtml+allAvlHtml);
		//U.log(allAvlHtml);
//		propType=propType.replace("Homeowner Association,","");
//		propType=propType.replace("Homeowner Association","");
		allAvlHtml = allAvlHtml.replace(">2 Story</li>", "> 2 Stories </li>");
		allAvlHtml = allAvlHtml.replaceAll("1st floor master suite|1st Flr Master & 1st Flr Guest Suite", " 1 story ");
		String derType = U.getdCommType(floorHtml + avlHtml+comHtml+allFloorhtml+allAvlHtml);
		
		comHtml=comHtml.replaceAll("gated","Gated Community");
		String comType = U.getCommunityType(comHtml);
		
		U.log("Street:: "+street+" City:: "+city+"State:: "+state+"Zip:: "+zip);
		if(zip==null){
			zip=ALLOW_BLANK;
		}
		
		if(propType.length()==0){
			propType=ALLOW_BLANK;
		}
		
		String note=U.getnote(comHtml);
		// ******************Add Community Details****************
		data.addCommunity(CommunityName, communityUrl, comType);
		data.addAddress(street, city.trim(), state.trim(), zip.trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(propType, derType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
	}j++;
	}
}