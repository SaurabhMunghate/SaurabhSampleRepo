package com.shatam.b_241_260;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBaesslerHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://www.baesslerhomes.com/communities";
	WebDriver driver = null;
	private String builderUrl = "https://www.baesslerhomes.com";
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractBaesslerHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Baessler Homes.csv", a.data().printAll());
	}

	public ExtractBaesslerHomes() throws Exception {

		super("Baessler Homes", "https://www.baesslerhomes.com");
		LOGGER = new CommunityLogger("Baessler Homes");
	}

	public void innerProcess() throws Exception {

		U.setUpGeckoPath();
		driver  = new FirefoxDriver(U.getFirefoxCapabilities());
//		U.setUpChromePath();
//		driver = new ChromeDriver();

		String basehtml = U.getHtml("https://www.baesslerhomes.com/communities", driver);

//		String section = U.getSectionValue(basehtml, "comResetButton\" ng-click=\"clearComs()",	"<div class=\"communities-map\">").replaceAll("<h4 data-reactid=\"\\d{3,4}\">", "<h4>");
		String values[] = U.getValues(basehtml, "<div class=\"card CommunityCard\"", "</a></div></div></li>");
		U.log("length" + values.length);

		for (String commSec : values) {
			
//			commSec=commSec.replaceAll("<h4 data-reactid=\"\\d{3,4}\">", "<h4>");
			String name = U.getSectionValue(commSec, "<h4", "<");
//			name = name.replace("-", " ");
			String commUrl = "https://www.baesslerhomes.com"+U.getSectionValue(commSec, " href=\"", "\"");
//			U.log(commUrl);
//			U.log(name);
//			U.log(commSec);
			addDetails(commUrl, name,commSec);
//			break;
			
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	//TODO :
	public void addDetails(String url, String communityName,String commSec) throws Exception {
//	try{
	{
		U.log("Count::"+j);
		url = url.replace("\"", "");
//
		
//		if (!url.contains("https://www.baesslerhomes.com/communities/wiggins/kiowa-park"))return;
//		url="https://www.baesslerhomes.com" + url;
		
		commSec = commSec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
//		U.log(">>>>>>"+communityName);
		communityName=communityName.replace("Townhomes", "");
		U.log("url:::" + url);
		String html = U.getHtml(url, driver);
		
		
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl("Repeated ===="+url);
			U.log("repeated community");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		// -----latlong-------//
		String geo = "FALSE";
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "https://www.google.com/maps/place/",
				"@");

		if (latLongsec != null) {
			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong " + latLong[0]);
			U.log("latlong " + latLong[1]);
			//geo = "TRUE";
		}
		
		String remSec=U.getSectionValue(html, "<script>window.__PRELOADED_STATE", "</script>");
//		/U.log(remSec);
		if (remSec!=null) {
			U.log("REMOVED");
			html=html.replace(remSec, "");
		}
		// -----------adress----------//
		String notes=ALLOW_BLANK;
		notes=U.getnote(html);
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
//			add[0]=U.getSectionValue(commSec, "\"com_street1\":\"", "\"");
//			add[1]=U.getSectionValue(commSec, "\"city_name\":\"", "\"");
//			add[2]=U.getSectionValue(commSec, "\"state_code\":\"", "\"");
//			add[3]=U.getSectionValue(commSec, "\"com_zip\":\"", "\"");
//		U.log("Address ::"+Arrays.toString(add));
		
		if(add[0] ==null) {
			
			String addSec = U.getSectionValue(html, "Sales Office</h4>", "</p>");
			
//			if (url.contains("https://www.baesslerhomes.com/communities/wiggins/kiowa-park"))
//				addSec = U.getSectionValue(html, "NEW MODEL HOME AT THIS LOCATION:&nbsp;", "Kiowa Park");
			
//			if (url.contains("https://www.baesslerhomes.com/communities/ault/conestoga") && !url.contains("https://www.baesslerhomes.com/communities/ault/conestoga-townhomes"))
//				addSec = U.getSectionValue(html, "NEW MODEL HOME NOW OPEN -", "!");
			
			if(addSec!=null) {
				
				addSec = addSec.replaceAll("<br data-reactid=\"\\d+\">", ",").replace("Ave.", "Ave,").replace("701 Oregon Trail", "701 Oregon Trail,");
				addSec = U.getNoHtml(addSec);
				add = U.getAddress(addSec);
				U.log("Address:: "+Arrays.toString(add));
				U.log("addres11");
			}
		}
		
		
		if(latLong[0] == null || latLong[0]==ALLOW_BLANK) {
		latLong[0]=U.getSectionValue(commSec, "\"com_lat\":", ",");
		latLong[1]=U.getSectionValue(commSec, "\"com_lng\":", ",");
		}
/*		if (add[3] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo="true";
		}
*/		if (add[0] == ALLOW_BLANK || add[3] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressHereApi(latLong);
			if(add[3] == ALLOW_BLANK) add[3] = addr[3];
			if(add[0] == ALLOW_BLANK) add[0] = addr[0];
			if(add[2] == ALLOW_BLANK) add[2] = addr[2];
			if(add[1] == ALLOW_BLANK) add[1] = addr[1];
//			add = addr;
			geo="true";
		}

		if (latLong[0] == ALLOW_BLANK) {

			latLong = U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "TRUE";
		}
		
		if (add[0] == ALLOW_BLANK || add[0] == null) {

			add = U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			U.log("Address:::: " + Arrays.toString(add));
			geo = "TRUE";
		}
		
		
		//============= Available Home Section =============
		String combinedAvailableHtml = null;
			String [] availableUrlSec = U.getValues(html, "<div class=\"HomeCard\"", "<div class=\"HomeCard_footer\"");
			U.log(":::::::::::::::::::::"+availableUrlSec.length);
			for(String availableSec : availableUrlSec){
				String availableUrl = U.getSectionValue(availableSec, "href=\"", "\"");
				U.log("Quick "+availableUrl);
				String tempHtml=U.getHtml(builderUrl+availableUrl, driver);
				combinedAvailableHtml += U.getSectionValue(tempHtml, "<div class=\"container\"", "</p>");
//				U.log(combinedAvailableHtml);
			}
			availableUrlSec = U.getValues(html, "<div class=\"PlanCard\"", "<div class=\"PlanCard_communityListLabel");
			U.log(":::::::::::::::::::::"+availableUrlSec.length);
			for(String availableSec : availableUrlSec){
				String availableUrl = U.getSectionValue(availableSec, "href=\"", "\"");
				U.log("FloorPlans "+availableUrl);
				String tempHtml=U.getHtml(builderUrl+availableUrl, driver);
				combinedAvailableHtml += U.getSectionValue(tempHtml, "<div class=\"container\"", "</p>");
			}

		//============ Remove Section ==================
		String remSeca = U.getSectionValue(html, "var MapLoader=", "</script>");
		if(remSeca != null)
			html = html.replace("<strong>estate home</strong>", " estate home ").replace(remSeca, "");
		// ---------community type,property type,property status,derived,
		// property type---------//
		if(combinedAvailableHtml != null)
			combinedAvailableHtml = combinedAvailableHtml.replaceAll("luxurious five piece master bathroom|luxurious bathroom|Farmhouse Elevation", "");
		String commType = U.getCommunityType(html);
		html=html.replace("Farmhouse Elevation", "").replace("Farmhouse Exterior", "");
		U.log("KK"+Util.matchAll((html), "[\\w\\W\\s]{40}farmhouse[\\w\\W\\s]{40}", 0));
		combinedAvailableHtml=combinedAvailableHtml.replace("Craftsman Elevation", "");
		String propType = U.getPropType((html+combinedAvailableHtml).replace("luxurious split master", "luxury home").replaceAll("Farmhouse Evelation|craftsmanship", ""));
		
		//=========== Derived Community Type ================
		html = html.replace("1/Ranch", "1 story Ranch ").replaceAll("<div class=\"mr-3\" data-reactid=\"\\d+\"><!-- react-text: \\d+ -->Stories: <!-- /react-text --><strong data-reactid=\"\\d+\">", "<div class=\"mr-3\">Stories ");
//		U.log(Util.match(html, ".*Stories.*"));
		
		String remove = U.getSectionValue(html, "window.__PRELOADED_STATE__", "</script>");
			if (remove == null)
				remove = "";
		
		String dpType = U.getdCommType((html.replace(remove, "")+combinedAvailableHtml).replaceAll("Poudre River Ranch|\"The Radke Family | Eaton, CO - Governors Ranch\"", ""));
		U.log(Util.matchAll(html+combinedAvailableHtml, "[\\w\\s\\W]{100}ranch[\\w\\s\\W]{100}", 0));

		//=========== Property Status ===============
		commSec = commSec.replaceAll("0</span> Quick Move-In Homes|family homes now selling|\"com_status\":\"Closeout\"|Homes Now Selling in Evan|odel Home Grand Opening|grand_opening_1|geTitle\":\"Grand Opening|Model Home Grand Opening|several lots available|loser to the Grand Opening|homes\">Quick|setContent\\('Opening|Soon'\\);", "");

		html = html.replaceAll("\\(Coming Soon|Plans coming|family homes now selling|\"com_status\":\"Closeout\"|Homes Now Selling in Evan|odel Home Grand Opening|grand_opening_1|geTitle\":\"Grand Opening|Model Home Grand Opening|several lots available|loser to the Grand Opening|homes\">Quick|setContent\\('Opening|Soon'\\);", "");
//		U.log("KK"+Util.matchAll((html), "[\\w\\W\\s]{40}coming soon[\\w\\W\\s]{40}", 0));
		html=html.replace("\"streetAddress\":\"Coming Soon\"","");
		String commStatus = U.getPropStatus(html+commSec);
		
		
//		U.log(commSec);
		// --prices---//
		String[] price = U
				.getPrices(	html+commSec,
						"\\$\\d+,\\d+|Priced from \\$\\d+,\\d+|Starting at \\$\\d+ ",
						0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		//consider finished sq ft values
//		U.log("<<<<<<<< "+Util.match(html.replaceAll("</strong><br data-reactid=\"\\d+\"/>| data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->", ""), "[\\s\\w\\W]{30}1,587[\\s\\w\\W]{30}"));
		String[] sqft = U
				.getSqareFeet(html.replaceAll("</strong><br data-reactid=\"\\d+\"/>| data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->", "")+commSec,
						"<strong>\\d,\\d{3}</strong><br />SQFT|>\\d,\\d{3}SQFT|>\\d,\\d{3}-\\d,\\d{3} SQ FT<|\\d,\\d{3}</strong><br>SQFT|\"com_sqftLow\":\\d{4},|>\\d,\\d{3}</strong><br/>SQFT|>SQ FT: \\d,\\d+ - \\d,\\d+</li>|Finished SQ FT from \\d,\\d+|\\d,\\d+ Finished SQ FT|\\d,\\d{3} Max SQ FT",
						0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
	
		// ---notes-----//
		communityName=communityName.replaceAll("data-reactid=\"\\d+\">|villas|Villas","");
//		if (url.contains("https://www.baesslerhomes.com/communities/fort-lupton/lupton-village-townhomes"))dpType = dpType.replace("Ranch,", "");
//		if(url.contains("https://www.baesslerhomes.com/communities/fort-lupton/fulton-village"))commStatus="Now Open";
		if(commStatus.contains("Quick Move-in Homes"))commStatus = commStatus.replaceAll("Quick Move-in Homes|, Quick Move-in Homes|Quick Move-in Homes", "");
//		if(url.contains("/communities/greeley/river-run-at-poudre-river-ranch")) maxSqf = "1,587"; //Region Page
		if(commStatus==null||commStatus.length()<1)commStatus=ALLOW_BLANK;
		
		
//		=======================================================================
		int s=0;
		String lotCount=ALLOW_BLANK;
		
		String map_sec=U.getSectionValue(html, "Community Map</h3>", "</iframe>");
		if(map_sec!=null) {
		String mapLink=U.getSectionValue(map_sec, "<iframe src=\"", "\">");
		U.log("mapLink :::" +mapLink);
		if(mapLink!=null) {
			String map_Html=U.getHtml(mapLink, driver);
			String data_Sec=U.getSectionValue(map_Html, "Sales Status<a href=\"", "<script>");
//			U.log("data_Sec :::" +data_Sec);
			String[] count_Sec=U.getValues(data_Sec, "<div class=\"legend_data_content\">", "</div>");
			for(String count : count_Sec) {
				count=U.getNoHtml(count).trim();
//				U.log("count :::" +count);
				count=Util.match(count, "\\d+");
				
				s+=Integer.parseInt(count);
				
			}
			U.log("ddddddd :::" +s);
			lotCount=Integer.toString(s);
		}
		}
	    if(url.contains("conestoga")) {
	    	geo = "FALSE";
	    }
	    if(url.contains("kiowa")) {
	    	geo = "FALSE";
	    }
	    if(url.contains("https://www.baesslerhomes.com/communities/wiggins/kiowa-park")) {
	    	add[0] = "403 11th Ave";
	    	add[1] = "Wiggins";
	    	add[2] = "CO";
	    	add[3] = "80654";
		}
		
		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(notes);
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

	}j++;
//	}catch(Exception e){}
	}
}