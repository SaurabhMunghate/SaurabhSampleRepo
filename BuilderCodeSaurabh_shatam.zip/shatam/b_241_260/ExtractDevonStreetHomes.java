/** @author 
 *  @date 25/07/2012 
 */

package com.shatam.b_241_260;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDevonStreetHomes extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractDevonStreetHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Devon Street Homes.csv", a.data()
				.printAll());
	}

	public ExtractDevonStreetHomes() throws Exception {

		super("Devon Street Homes", "https://www.devonstreethomes.com/");
		LOGGER=new CommunityLogger("Devon Street Homes");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://www.devonstreethomes.com/Communities");
		String[] communityUrls = U.getValues(html,
				"<li id=\"community", "</li>");
		///U.log(Arrays.toString(communityUrls));
		HashSet<String> comunitySet = new HashSet<String>();
		for (String communityUrl : communityUrls) {
			comunitySet.add(communityUrl);
		}
		
		int totalComm = comunitySet.size() / 2;
		for (String community : comunitySet) {
		//TODO :
			
//			if(j==1)
			{
				
				  //======  Single Run ================================
//			if(!community.contains("https://www.devonstreethomes.com/community/mill-creek-north-2000-series/"))continue;//single execution
				
			  U.log("communitySec::"+community);
			  String communityName = U.getSectionValue(community, "</span>", "</a>");
			  U.log(communityName);
			  String communityUrl = U.getSectionValue(community, "<a href=\"", "\"");
			  
			
			  
			  
			  if(data.communityUrlExists(communityUrl)){
				LOGGER.AddCommunityUrl(communityUrl+"========>Repeated");
				continue;
			  }
			  LOGGER.AddCommunityUrl(communityUrl);
			
			U.log("communityUrl :" + communityUrl);
			U.log("communityName :" + communityName);
			String communityHtml = U.getHTML(communityUrl);
			//--------Prices--------------
			community = community.replace("0's", "0,000");
			
			U.log(">>>>>>>>>>> "+communityHtml.length());
			
			String floorplans[]= null;
			
			try {
				
				
				floorplans = U.getValues(communityHtml, " <div class=\"col-xs-6 col-lg-3 floorplan-column\">", "More Information");
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			if(floorplans == null)
				floorplans  = U.getValues(communityHtml, " <div class=\"col-xs-6 col-lg-3 floorplan-column\">", "</dl>");	
			
			String allHomeHtml="";
			String AvailHomes[] = U.getValues(communityHtml, " <div class=\"col-xs-6 col-lg-3 home-column\">", "View Home<span");
			for(String hme:AvailHomes) {
				String specialPrice = Util.match(hme, "Special Price: </dt>\\s*<dd>\\$\\d+,\\d+", 0);
				U.log("-->"+specialPrice);
				if(specialPrice!=null) {
					hme=hme.replaceAll("<dt>Price: </dt>\\s*<dd>\\$\\d+,\\d+", "");
					allHomeHtml +=hme; 
				}else if(Util.match(hme, "Price: </dt>\\s*<dd>\\$\\d+,\\d+", 0)!=null && specialPrice==null){
					allHomeHtml +=hme; 
				}
			}
			String fHtml="";
			for (String floor : floorplans) {
				fHtml+=floor;
			}
//			U.log(Util.match(community, ".*186,990.*"));
/*			
			ArrayList<String> prices = Util.matchAll(allHomeHtml+floorplans+community+fHtml,
					"<dt>\\s+Base Price: </dt>\\s+<dd>\\$\\d{3},\\d{3}</dd>|\\$\\d{3},\\d{3}", 0);
//			U.log(prices);
			String[] minMaxPrice = GetLink.getMaxMin(prices);
			U.log("prices :" + prices);
			if (prices.isEmpty()) {
				minMaxPrice[0] = minMaxPrice[1] = ALLOW_BLANK;
			}
			else {
				minMaxPrice[0] = GetLink.inPriceFormat(minMaxPrice[0]);
				minMaxPrice[1] = GetLink.inPriceFormat(minMaxPrice[1]);
			}
			
			if(minMaxPrice[0].equals(minMaxPrice[1]))
				minMaxPrice[1] = ALLOW_BLANK;
			U.log("minPrice :" + minMaxPrice[0]);
			U.log("MaxPrice :" + minMaxPrice[1]);
*/			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			
			
			community=community.replaceAll("0's","0,000");
			communityHtml=communityHtml.replace("0's","0,000");
			U.log(community);
						
			String prices[] = U.getPrices(community+ communityHtml,
					"\\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}\\s*-\\s*\\$\\d{3},\\d{3}| <dt>(Base )?Price: </dt>\\s+<dd>\\$\\d{3},\\d{3}</dd>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Price--->"+minPrice+" "+maxPrice);


			//--------Area-----------------

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String sqft[] = U.getSqareFeet(communityHtml,
					"ranging from \\d{4} square feet to over \\d{4} square feet|<dd>\\d{4} - \\d{4}</dd>|&nbsp;\\d+&nbsp;|small;\">\\d{4} - \\d{4}</span>|\\d{4}</span></td>|<dd>[0-9]{4}-[0-9]{4}</dd>|<dd>[0-9]{4}</dd>", 0);

			minSqft = sqft[0];
			maxSqft = sqft[1];

			//-----------propertyType---------------

			// Address///Phone:
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, "TX",
					ALLOW_BLANK };
			

			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String geo = "FALSE";
			//-------------Address-----------
			String addressSec = U.getSectionValue(communityHtml, "<address>", "</address>");
			if(addressSec != null){
				addressSec = addressSec.replace("<br>", ",").replaceAll("Model Coming Soon:|Sales Model is CLOSED|Model Info Coming Soon|MODEL SOLD/CLOSED|Model Now CLOSED.|- In Walnut Creek Community, SUMMER LAKES MODEL HAS BEEN SOLD/CLOSED. |Sales Model Coming Soon!,|Kodiak Crossing(!)?,|Enclave At Riverpark Community Lakes,\\s*Sales Model Located in Summer|\\(McCrary Meadows Model\\)|\\(Enclave at Riverpark Model Home\\)|- Woodhaven Forest Sales Model| - Model Coming Soon|- Woodhaven Forest Model Home|- Model Home Coming Soon!|- River's Mist GPS Reference Point|346 American Black Bear Dr. - Sales Model in|- NEW Stewart's Forest Sales Office|- Sales Model in Lakes of Savannah ,|Sierra Vista Model Coming Soon!|Devon Street Homes in Stewart's Forest - \\d Homes? Left!!,|Sales Office Located in McCrary Meadows,|Stewart's Forest Model Now SOLD/CLOSED|Devon Street Homes in Stewart's Forest", "");
				U.log(addressSec);
				add = U.getAddress(addressSec);
				U.log("Address : " + Arrays.toString(add));
			}
			lat = U.getSectionValue(communityHtml, "data-lat=\"", "\"");
			lng = U.getSectionValue(communityHtml, "data-lng=\"", "\"");
			U.log(lat + "::::::::::" +lng);
			
			if(lat==null && add[0].length()>4){
				String[] LL = U.getlatlongGoogleApi(add);
				lat = LL[0];
				lng = LL[1];
				geo = "TRUE";
			}
			if(communityUrl.contains("/community/bakers-reserve/")){
				 addressSec=U.getSectionValue(communityHtml, " <div class=\"acf-map\">", "Get Directions");
				 addressSec=U.getSectionValue(addressSec, "<address>", "</address>");
				 addressSec=addressSec.replaceAll("<br>", ",");
				 add=U.getAddress(addressSec);		
			}
			add[0]=add[0].replaceAll("Sales Model Coming Soon!|MODEL SOLD/CLOSED|SUMMER LAKES MODEL HAS BEEN SOLD/CLOSED.|Enclave at Riverpark Community, Sales Model Located in Summer Lakes|Woodhaven Forest, Sales Office Located in Stewart's Forest|- In Walnut Creek Community|, SUMMER LAKES MODEL CURRENTLY CLOSED|- Model Now CLOSED|\\.", "");
			U.log(add[0]);
			if(add[0].length()<2 && lat.length()>2) {
//				add[0]=U.getAddressGoogleApi(new String[] {lat,lng})[0];
//				geo = "TRUE";
				addressSec =U.getSectionValue(communityHtml, "located at: <span style=\"text-decoration: underline;\">", "</span>");
				
				if(addressSec!= null) {
				 addressSec=addressSec.replaceAll("Dr.", "Dr.,");
				 add=U.getAddress(addressSec);	
				}
			}
			
			if(add[0] == ALLOW_BLANK || add[0]== null) {
				
				String[] latlng = {lat,lng};
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo = "TRUE";
			}
			
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]
					+ " Z:" + add[3]);

			
			//============ Available Homes ===============
			String combinedAvailHtmls = null;
			String availableUrls[] = U.getValues(communityHtml, "<figcaption><a href=\"", "\"");
			U.log("Available Home =="+availableUrls.length);
			for(String availableUrl :  availableUrls){
				U.log("avilUrl::"+availableUrl);
				String availableHtml = U.getHTML(availableUrl);
				combinedAvailHtmls += U.getSectionValue(availableHtml, "</h1></header>", "class=\"downloads\">");
			}
			
			String pType = U.getPropType((communityHtml+combinedAvailHtmls).replaceAll("4311 Thetford Manor T|-manor-trail|Carriage Style Garage|Luxury Lighting|Luxury Vinyl Plank Floors", ""));
//			U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(communityHtml+combinedAvailHtmls, "[\\w\\s\\W]{30}manor[\\w\\s\\W]{30}", 0));

		//	communityHtml=communityHtml.replace("<dd>2</dd>", "two");
			//U.log("@@@"+communityHtml+"@@");
			communityHtml = communityHtml.replaceAll("Stories: </dt>\\W+<dd>", "Story ");
			communityHtml = communityHtml.replaceAll("Stories: </dt>\\W+<dd>", "Story ");
			communityHtml = communityHtml.replaceAll("&nbsp;", " ").replace("&frac12;", ".5").replace("1 - 1 1/2", "1.5").replace("1 1/2","1.5");
			//U.log(communityHtml);

			communityHtml=communityHtml.replaceAll("Stories:\\s*</dt>\\s*<dd>2", "2 story").replace("Story 1.5", "one and a half story");
			String dType = U.getdCommType(communityHtml);

			String Dtype = ALLOW_BLANK;

			String values[] = U.getValues(communityHtml, "<tr>", "</tr>");
			HashSet<String> dval = new HashSet<String>();
			for (String s : values) {
				String[] valdtype = U.getValues(s, "font-size: small;\">", "<");
			//	U.log("::::::::::::::dtype:::::::::::::"+s);
				if (valdtype.length == 6) {
					dval.add(valdtype[3].trim());

				}
			}
			for (String d : dval) {
				
				if (Dtype == ALLOW_BLANK && d.trim().length() > 0
						&& !d.contains("3 1/2"))
					Dtype = d + " Story";
				else if (d.trim().length() > 0)
					Dtype += "," + d + " Story";
			}

			Dtype = Dtype.replaceAll("&nbsp;", " ").replace("&frac12;", ".5").replace("1 - 1 1/2", "1.5").replace("1 1/2","1.5");
			Dtype = Dtype.replace("3 1/2 Story,", "");

			// propertyStatus
			String propertyStatus = ALLOW_BLANK;
			String statSec = communityHtml.replace("ONLY <span style=\"text-decoration: underline;\">FOUR</span> DEVON STREET HOMES REMAIN", "ONLY FOUR HOMES REMAIN").replaceAll("series are coming soon|Sales Model coming soon|\\+Model\\+Coming\\+Soon|ce-range\">Coming So|Sales Model Coming Soon!|range\">Coming Soon|Model Info Coming Soon", "");
			String remove = "current close-out\" />|Sales Model coming soon|Sales Model Coming Soon|range\">Coming Soon|current close-out pricing|lose out </strong><strong>pricing|Opening Soon!\\s+</div>|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|WE ARE NOW SELLING FROM|Currently selling from our |close out pricing";
//			U.log(Util.matchAll(statSec+community, "[\\w\\s\\W]{20}coming[\\w\\s\\W]{10}", 0));
			statSec = statSec.replace("OUR SALES OFFICE IS NOW OPEN", "").toLowerCase() //.replace("USDA Loans available", "USDA Available")
					.replaceAll(remove.toLowerCase(), "")
					.replace("community close out", "community closeout");
			community=community.replace("OUR SALES OFFICE IS NOW OPEN", "").replaceAll("Model Info Coming Soon|series are coming soon", "");
			propertyStatus = U.getPropStatus((statSec+community).replace("OUR SALES OFFICE IS NOW OPEN", "").replace("range\">Coming Soon", ""));
			
			if(combinedAvailHtmls!=null && combinedAvailHtmls.contains("MOVE IN READY")) {
				if(propertyStatus.length()<3) {
					propertyStatus="MOVE IN READY".toLowerCase();
				}
				else {
					propertyStatus=propertyStatus+", MOVE IN READY".toLowerCase();
				}
			}
			if(communityUrl.contains("coming-soon")) {
				if(propertyStatus==ALLOW_BLANK)
					propertyStatus="Coming Soon";
					else
					propertyStatus +=", Coming Soon";
			}
//			U.log(">>>>>>>>>>>>"+Util.matchAll(statSec, "[\\s\\w\\W]{30}close out[\\s\\w\\W]{30}", 0));

			if (data.communityUrlExists(communityUrl))
			{
				continue;
			}
			if (propertyStatus.length()==0){
				propertyStatus = "";
			}
			if(communityName.contains("River Run - River Mist"))
			{
				communityName="River's Run - River's Mist";
			}
			add[2]=add[2].trim().replace("Texas", "TX");
			communityHtml = communityHtml.replaceAll("title='Country Club Manor'|country-club-", "");
			
			if(maxSqft==null)maxSqft=ALLOW_BLANK;
			if(minSqft==null)minSqft=ALLOW_BLANK;
			add[0]=add[0].replaceAll("422 Honeysuckle Vine Dr. - River's Mist GPS Reference Point", "422 Honeysuckle Vine Dr").replace(",", "");
		
			
			String noteVar = U.getnote(communityHtml);
			
			if(communityUrl.contains("https://www.devonstreethomes.com/community/audubon-coming-soon")) {
				add[0]="40211 Bay Warbler Court";
			
				
			}
			
//			if(communityUrl.contains("-coming-soon") && !propertyStatus.contains("Coming Soon")){
//				if(propertyStatus == ALLOW_BLANK) propertyStatus="Coming Soon";
//				else if(propertyStatus != ALLOW_BLANK) propertyStatus +=", Coming Soon";
//			}
			
/*				if(	communityUrl.contains("https://www.devonstreethomes.com/community/rosehill-meadow-coming-soon/"))propertyStatus="Coming Soon";
//			if(communityUrl.contains("https://www.devonstreethomes.com/community/audubon-coming-soon-2/"))propertyStatus ="Coming Soon";
			if(communityUrl.contains("https://www.devonstreethomes.com/community/anderson-lakes-coming-soon"))
				propertyStatus=ALLOW_BLANK;
*//*			if(communityUrl.equals("https://www.devonstreethomes.com/community/lakes-of-savannah-2/"))minMaxPrice[0]="$280,000";
			if(communityUrl.equals("https://www.devonstreethomes.com/community/lakes-of-savannah/"))minMaxPrice[0]="$390,000";
*/				String counting=ALLOW_BLANK;
				String startDt=ALLOW_BLANK;
				String endDt=ALLOW_BLANK;
			
			data.addCommunity(communityName, communityUrl, U.getCommunityType(communityHtml));
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addNotes(noteVar);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);

			// inr++;}
		}j++;
		}
		LOGGER.DisposeLogger();
	}
}