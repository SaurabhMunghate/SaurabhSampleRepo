/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_241_260;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMcKelveyHome extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.mckelveyhomes.com";
	public ExtractMcKelveyHome() throws Exception {
		super("McKelvey Home",builderUrl);
		LOGGER=new CommunityLogger("McKelvey Home");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractMcKelveyHome();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McKelvey Home.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	WebDriver driver=null;
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String mainHtml=U.getHtml("http://www.mckelveyhomes.com/communities", driver);
		String moveInHtml=U.getHtml("https://www.mckelveyhomes.com/homes", driver);
		String[] comSec=U.getValues(mainHtml, "<div class=\"CommunityCard_inner\"","</div></div></div></div>");
		
		U.log("Community Count: "+comSec.length);
		for(String comData:comSec)
		{
			String comUrl=builderUrl+U.getSectionValue(comData, "href=\"","\"").replace("-homes","");
			addDetails(comUrl,comData,moveInHtml);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData, String moveIn) throws Exception {
		// TODO Auto-generated method stub

//		if(!comUrl.contains("/the-preserve"))return;
		
//		if(j >=4)
		{
			if(comUrl.contains("https://www.mckelveyhomes.com/the-preserve-carefree")) comUrl="https://www.mckelveyhomes.com/the-preserve-carefree-homes-homes"; // not open
			
			if(comUrl.equals("https://www.mckelveyhomes.com/communities/affton-mo/the-preserve-cottage"))
				comUrl="https://www.mckelveyhomes.com/communities/affton-mo/the-preserve-cottage-homes";
			
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+"----------> Repeated");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			U.log(j+"   commUrl-->"+comUrl);
			U.log(U.getCache(comUrl));
			
			String html=U.getHtml(comUrl, driver);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{100}Inverness<!-- /react-text -->[\\s\\w\\W]{100}", 0));

			html=html.replace("ng-href=\"/luxury-series-photo-gallery\"","").replace("Three plans from our Classic Series are now available ", "");
			html=html.replace("\">Luxury Series","").replaceAll(" data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
			html=html.replace("href=\"/luxury-series-photo-gallery","");
			html=U.removeSectionValue(html, "<header", "</header>");
			html=html.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
			html=U.removeSectionValue(html, "window.__PRELOADED_STATE", "</body>");

			comData=comData.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
//		U.log("comData==="+comData);
	//============================================Community name=======================================================================

		String communityName=U.getSectionValue(html, "<h2 class=\"DetailOverview_heading\"","</h2>");
if(communityName!=null) {
	communityName=communityName.replaceAll("data-reactid=\"\\d+\">", "")
.replace("&#8217;","")
.replaceAll("<span class=\"DetailOverview_subheading\">Cottleville, MO 63304</span>|>", "")
.replaceAll("<span class=\"DetailOverview_subheading\"Affton, MO 63123</span", "")
.replaceAll("<span class=\"DetailOverview_subheading\"Chesterfield, MO 63017</span", "");
}
			U.log("community Name---->"+communityName);
			
	//================================================Address section===================================================================
			
			
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
//			U.log(comData);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{100}MO 63304[\\s\\w\\W]{30}", 0));

			String addSec=U.getSectionValue(html, "<span class=\"DetailsPage_h2\">","</span>");
//			if(addSec.equals(", , ")) addSec = null;
			U.log("addSec==="+addSec);
			if(addSec!=null ) {
				
			addSec=addSec.replace(" | ", ", ");
			U.log("addSec==="+addSec);
			add=U.getAddress(addSec);
			
			U.log("first addd Sec: "+Arrays.toString(add));
			}
			
			
			
	//--------------------------------------------------latlng----------------------------------------------------------------
			
			String latSec=U.getSectionValue(comData, "https://www.google.com/maps/place/","\"");
			U.log("latSec=="+latSec);
			
			/*
			 * if(latSec == null) { latSec=U.getSectionValue(html,
			 * "https://maps.google.com/?q=","\""); }
			 */
			 
			
			if(latSec!=null)
			{
				latSec=U.getSectionValue(latSec, "@","z");
				U.log("latSec=="+latSec);
				latlag=latSec.split(",");
//				latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
//				latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
			}
			U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
			
			if(addSec==null) {
				addSec=U.getSectionValue(comData, "<span class=\"CommunityCard_city\"","</span>");
//				U.log("addSec-1==="+addSec);
				if(addSec!=null ) {
					
					addSec=addSec.replaceAll("data-reactid=\"\\d+\">", "");
					U.log("addSec==="+addSec);
					String zip=Util.match(addSec, "\\d{5}");
					addSec=addSec.replace(zip, ", "+zip);
					String[] add1;
					add1=addSec.split(",");
					add[0]=ALLOW_BLANK;
					add[1]=add1[0];
					add[2]=add1[1];
					add[3]=add1[2];
//					add=U.getAddress(addSec);
					add[0]=U.getAddressGoogleApi(latlag)[0];
					geo="TRUE";
//					U.log("first addd Sec: "+Arrays.toString(add));
					}
			}
			
			
			if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
			{
				latlag=U.getlatlongGoogleApi(add);
				
				geo="TRUE";
			}
			if((add[0]==null || add[0]==ALLOW_BLANK ||add[0].length()<4|| add[3]==null) && latlag[0]!=ALLOW_BLANK)
			{
				add=U.getAddressGoogleApi(latlag);
				if(add == null) add = U.getAddressHereApi(latlag);
				geo="TRUE";
			}
			
			
			
			
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
	//--------------------------- floor home details-----------------------
			String flooreHtml=U.getHtml(comUrl+"#plans", driver);
			flooreHtml=U.removeSectionValue(flooreHtml, "window.__PRELOADED_STATE", "</body>");

			U.log(U.getCache(comUrl+"#plans"));
			
//			String floordetailsSec=U.getSectionValue(flooreHtml, "<div class=\"PlanCard_wrapper\"", "</div></div></div></div></div>");
			String floorHomesDetailsHtml=ALLOW_BLANK;
//			U.log("floordetailsSec::::::::"+floordetailsSec);
//			if(floordetailsSec!=null) {
			String floorHomesDetailsLink []=U.getValues(flooreHtml ,"<div class=\"PlanCard_wrapper\"", "</div></div></div></div></div>");
			for (String string : floorHomesDetailsLink) {
				String url=U.getSectionValue(string, "href=\"", "\"") ;
				U.log("floorUrl::::"+builderUrl +url);
				  floorHomesDetailsHtml=U.getHTML(builderUrl +url);
				 floorHomesDetailsHtml=U.removeSectionValue(floorHomesDetailsHtml, "window.__PRELOADED_STATE", "</body>");
				 floorHomesDetailsHtml+=U.getSectionValue(floorHomesDetailsHtml, "<div class=\"Carousel_h2Wrapper\"", "Photo Gallery</h3>")+string;

//			}
			}
			
	//============================================Price and SQ.FT======================================================================
			
//			String home_Html="";
//			Thread.sleep(1000);
//			String homeHtml=U.getHtml(comUrl+"#homes", driver);
			String homeHtml=ALLOW_BLANK;

//			if(homeHtml!=null) {
//				homeHtml=U.removeSectionValue(homeHtml, "window.__PRELOADED_STATE", "</body>");
			String []homes=U.getValues(html, "<div class=\"HomeCard_content\"", "</div></div></div>");
			U.log("homes==="+homes.length);
			for(String homeData : homes) {
			String homeUrl="https://www.mckelveyhomes.com"+U.getSectionValue(homeData, "href=\"", "\"");
//			if(!homeUrl.contains(null)) {
			U.log("homeUrl==="+homeUrl);
			String hh=U.getHTML(homeUrl);
			hh=U.removeSectionValue(hh, "window.__PRELOADED_STATE", "</body>");
			homeHtml+=U.getSectionValue(hh, "<div class=\"Carousel_h2Wrapper\"", "Photo Gallery</h3>");
//			}
//				if(home_Html.contains("Story and a half")) {
//					U.log("FOUND");
//				}
			}
//			}
			
			
//			String floorHtml=U.getHtml(comUrl+"-floorplans", driver);
//			if(floorHtml!=null)
//				floorHtml=U.removeSectionValue(floorHtml, "window.__PRELOADED_STATE", "</body>");

			
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k|0’s","0,000").replace("$1 million","$1,000,000");
			comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
			String prices[] = U.getPrices(html+comData+homeHtml+floorHomesDetailsHtml,"\\$\\d{1},\\d{3},\\d+|\\$\\d{3},\\d+", 0);
			
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(floorHtml, "[\\s\\w\\W]{100}1,162,456[\\s\\w\\W]{100}", 0));

			U.log("Price--->"+minPrice+" "+maxPrice);

	//======================================================Sq.ft===========================================================================================		
		html=html.replace("<span class=\"DetailOverview_listItemLabel\">", " ");
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comData
//				, "[\\s\\w\\W]{100}PRELOADED_STATE[\\s\\w\\W]{100}", 0));

			String[] sqft = U
					.getSqareFeet(
							html+comData+floorHomesDetailsHtml,
							"\\d,\\d{3} - \\d,\\d{3}</span> Sq Ft|ranging from \\d,\\d{3}-\\d,\\d{3}\\+ sq\\. ft|SQFT Range: \\d+,\\d+ to \\d+,\\d+|SQFT:</span> \\d+,\\d+|\\d+,\\d+ SQFT",
							0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
	
	//=============== Market Homes Html =====================
			String [] homeUrls = U.getValues(homeHtml, "<a title=\"\" ng-href=\"", "\" href=");
			String combinedHomeHtml = null;
			for(String homeUrl : homeUrls){
				U.log("homeUrl ::"+builderUrl+homeUrl);
				String homeHtmls = U.getHtml(builderUrl+homeUrl, driver);
				homeHtmls=U.removeSectionValue(homeHtmls, "window.__PRELOADED_STATE", "</body>");

				combinedHomeHtml += U.getSectionValue(homeHtmls, "<h1>Home Details", "</article>");
			}
	//================================================community type========================================================

			String communityType=U.getCommType(html+comData);
			
	//==========================================================Property Type================================================
			String rem = "LaSalle Optional Covered Deck Patio|Covered Patio of Muirfield Manor Display|Optional Covered Deck Patio|craftsmanship|Loft Area Leading|Loft Area Madison|Available Custom|process\">Custom";
//			html = html.replaceAll("Available Custom|process\">Custom", "");

			String quickData = ALLOW_BLANK;
			if(moveIn.toLowerCase().contains(communityName.toLowerCase())){
				
				String [] val = U.getValues(moveIn, "<li class=\"result ng-scope\"", "</favorite></li>");
				
				
				for (String urlData : val) {
					if (urlData.toLowerCase().contains(communityName.toLowerCase())) {
						
						try {
							String qurl = U.getSectionValue(urlData, "<a ng-href=\"", "\"");

							U.log("qurl: " + qurl);
							String qhtml = U.getHtml("https://www.mckelveyhomes.com"+qurl, driver);
							// try {
							quickData += U.getSectionValue(qhtml, "<article ng-if=\"home.inv_description\"",
									"</article>");
						} catch (Exception e) {
							// TODO: handle exception
						}

					}
				}
				
			}
			
			
			if(combinedHomeHtml != null)
				combinedHomeHtml = combinedHomeHtml.replace("uxury standard features", "luxury home designs");

			if(combinedHomeHtml != null)
				combinedHomeHtml = combinedHomeHtml.replace("uxury standard features", "luxury home designs")
				.replaceAll("(L|l)uxurious (M|m)aster (B|b)ath|-photo-gallery\">Luxury|carriage style door|luxury_master_bath", "");
			html=html.replace("custom options ", "custom-built home options ").replace("red brick farmhouse", "red brick Farmhouse Collection").replaceAll("craftsmen style exterior", "craftsman style exterior");
			String proptype=U.getPropType((quickData).replaceAll("ntry courtyard style garages| Valley Estates features designs|-photo-gallery\">Luxury|Scheussler Valley Estates", "").replace("title=\"Loft", "").replace("patio.jpg", "").replaceAll(rem, ""));
//			U.log("MMMMM "+Util.matchAll((floorHomesDetailsHtml), "[\\s\\w\\W]{30}Manors[\\s\\w\\W]{30}", 0));

	//==================================================D-Property Type======================================================
			
			floorHomesDetailsHtml=floorHomesDetailsHtml
					.replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">Story", " Story");

			homeHtml=homeHtml.replace("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"174\">Story", " Story");
			if(flooreHtml!= null) flooreHtml = flooreHtml.replaceAll(" 1 1/2 Stories|Home Style:</span> 1 1/2 Stories", "1.5 Story");
			html = html.replace("2nd floor", "2-story").replaceAll(" 1 1/2 Stories|1½-story", "1.5 Story").replace("1.5-story", "one-and-one-half story")
					.replace("2-stoy plans", "2-story plans");
			String dtype=U.getdCommType((html+comData+homeHtml+floorHomesDetailsHtml).replaceAll("split bedbroom floorplan|First floor|first floor|First Floor", "")); //.replace("split floor plan", "")
//			U.log("mmmmmm"+Util.matchAll(floorHomesDetailsHtml, "[\\w\\s\\W]{50}stories[\\w\\s\\W]{50}", 0));
//			U.log("mmmmmm"+Util.matchAll(floorHomesDetailsHtml, "[\\w\\s\\W]{100}story[\\w\\s\\W]{100}", 0));

	//==============================================Property Status=========================================================
			html = html.replace("href=\"/homes\">Quick Move-In Homes", "")
					.replace("80 homesites are available", "80 homesites available").replaceAll(" now open daily|third and final|Display Home now open|Grand Opening of our newly designed Turnberry|display is now|Display Now", "");
			//U.log("ComData:::::::::"+comData);
			
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}QUICK MOVE-IN HOMES[\\w\\s\\W]{30}", 0));
			
			String pstatus=U.getPropStatus(html.replace("80 homesites are available", "80 homesites available").replaceAll("== 'Coming Soon'\"", "").replace("!= 'Coming Soon'\"", "").replaceAll("!= 'Coming Soon'", "").replaceAll("== 'Coming Soon'", "").replace("Move In Ready Home", " ")+comData);
			
			//Reg. pg Img
			if(comUrl.contains("/the-villages-at-montrachet") || comUrl.contains("/schuessler-valley-estates")) 
				pstatus = getStatus(pstatus, "Final Opportunities");
			
			if(comUrl.contains("/sommerlin"))pstatus=pstatus.replace("Now Open And Selling, Selling Fast", "Phase 2 is Now open and selling fast");
//			if(comUrl.contains("/sommerlin"))pstatus = pstatus+", Now Open";
			//============================================note====================================================================
			String note= U.getnote(html.replaceAll("Stayed tuned for more information regarding presales coming soon|Presales are anticipated| Display is now For Sale", "")); //.replaceAll("Pre-construction pricing", "")

				
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			//from Image re Dt: 24 jul 21
			if(comUrl.contains("https://www.mckelveyhomes.com/inverness")) {
				proptype = "Luxury Homes";
				
				//from img on com.page - 24 Jan
				pstatus = pstatus + ", Phase 3 Coming Soon";     
			}
			
			if(comUrl.contains("https://www.mckelveyhomes.com/the-preserve-the-villas"))communityName="The Preserve";
//			if(comUrl.contains("https://www.mckelveyhomes.com/the-preserve-the-glen")) pstatus = pstatus+", Coming Soon";  //from img on comm. page - 24 Jan
			
			if(comUrl.contains("https://www.mckelveyhomes.com/the-preserve-carefree-living"))pstatus = pstatus+", Coming Soon";  //from img on comm. page
			add[0]=add[0].replace(",", "");
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
			j++;
		
	}

	
	private String getStatus(String status, String imgStatus){
		if(status == ALLOW_BLANK) status = imgStatus;
		else if(status != ALLOW_BLANK) status = status +", "+ imgStatus;
		return status;
	}
}
