/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */

package com.shatam.b_241_260;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPeachtreeResidentialProperties extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.peachtreeresidential.com/";

	public ExtractPeachtreeResidentialProperties() throws Exception {
		super("Peachtree Residential Properties","https://www.peachtreeresidential.com/");
		LOGGER = new CommunityLogger("Peachtree Residential Properties");
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractPeachtreeResidentialProperties();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Peachtree Residential Properties.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	WebDriver driver=null;
	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver  = new FirefoxDriver(U.getFirefoxCapabilities());
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML(builderUrl);
		String section=U.getSectionValue(mainHtml, "Find Your Home</a>","</ul>");
		String[] cityUrl=U.getValues(section, "<a href=\"","\"");
		for(String url:cityUrl)
		{
			String cityHtml=U.getHTML(url);
			String[] comSec=U.getValues(cityHtml, "grid-30 hide-on-mobile\">","<div class=\"clear\"></div>");
			for(String comData:comSec)
			{
				String comUrl=U.getSectionValue(comData, "<a href=\"","\"");
//				U.log(comUrl);
				addDetails(comUrl,comData);
			}
		}
		driver.quit();
		//try{driver.quit();}catch(SessionNotCreatedException e){}
		LOGGER.DisposeLogger();
}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//Single Run
//	if(!comUrl.contains("https://www.peachtreeresidential.com/communities/fairfax/"))return;

	{
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHtml(comUrl, driver);
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"==========> Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "\">","<");
		
		U.log("community Name---->"+communityName);
//	=======================================Inventory Homes==============================================================================
		String invenHtmurl=ALLOW_BLANK;
		String invenHtm=ALLOW_BLANK;
		if(html.contains("Inventory")) {
			invenHtmurl=U.getSectionValue(html, "https://www.newhomemarketingsolutions.com/", "\"");
//	try{
		if(invenHtmurl!=null)
		{
			invenHtmurl=invenHtmurl.replace("&amp;", "&");
			U.log(invenHtmurl);
			invenHtm=U.getHtml("https://www.newhomemarketingsolutions.com/"+invenHtmurl, driver);
		}
		else {
			invenHtmurl=U.getSectionValue(html, "https://atlantanewhomesdirectory.com", "\"");
			if(invenHtmurl!=null) {
			invenHtmurl=invenHtmurl.replace("&amp;", "&");
			invenHtm=U.getHtml("https://www.atlantanewhomesdirectory.com/"+invenHtmurl, driver);
			}
		}
		U.log("https://www.newhomemarketingsolutions.com/"+invenHtmurl);
//		}catch(Exception e){}
	}
//================================================Address section===================================================================
		
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		
		String addSec=U.getSectionValue(html, "<h3>Call","<p><span");
		if(addSec!=null )
		{
			U.log("addSec::::::::::::"+addSec);
				
					addSec = U.getSectionValue(addSec, "<h3>", "</").replaceAll("<br>|<br />", ",");
					U.log(":::::::::::::::"+addSec+":::::::::::::::::::");
					String [] tempAdd = addSec.split(",");
					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2], "\\w+");
					add[3] =Util.match(tempAdd[2], "\\d+");
					U.log("else address is :::" + Arrays.toString(add));
				
				
		}
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
//--------------------------------------------------latlng----------------------------------------------------------------
		String latSec=U.getSectionValue(html, "https://maps.googleapis.com/maps/api","\"");
		U.log("latSec:::>"+latSec);
		//34.1447334,-84.2877242

		latlag[0]=Util.match(latSec, "\\d{2,3}[.]{1}\\d+");
		latlag[1]=Util.match(latSec, "-\\d{2,3}[.]{1}\\d+");
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		if(latlag[0]==null) {
			latSec = U.getSectionValue(html, "<a href=\"https://google.com/maps/?q=", "\"");
			U.log(latSec);
			if(latSec!=null && latSec.contains(",") && !latSec.trim().equals(","))
			latlag =latSec.split(",");
		}
//-----------------LatLng from Address when latlng is not present on page---------------
		U.log("--------- "+latlag[0]);
		if(add[1]!=ALLOW_BLANK && (latlag[0]==null || latlag[0]==ALLOW_BLANK || latlag[0].length()<3 ))
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
//-----------------Address from LatLng  when Address is not present on page---------------
		if((add[0]==ALLOW_BLANK || add[3]==null) && (latlag[0]!=ALLOW_BLANK && latlag[0]!=null))
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		
		add[2]=add[2].replace("North Carolina","NC");
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		//=== For a particular community
//		if(comUrl.contains("https://www.peachtreeresidential.com/communities/sycamore-farms/")) {
//			
//
//			add[0]=U.getAddressGoogleApi(latlag)[0];
//			if(add == null)add[0] = U.getAddressHereApi(latlag)[0];
//			geo="TRUE";
//		
//	}
		
//============================================Price and SQ.FT======================================================================
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html = html.replace("mid $500,000s", "mid $500,000").replace("0’s", "0,000");
		html =html.replaceAll("img title=\"\\$\\d+,\\d+|/NBA%20\\$\\d+,\\d+%20Grant%20Ceremony%20BANNER.jpg", "");
		html=html.replaceAll("0�s|0's|0&#8217;s|0s|0s|0k's|0k|0's,","0,000").replace("$1 million","$1,000,000").replace("$1.2M", "$1,200,000").replace(" 1 Million", "$1,000,000");
		comData=comData.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k|0's,","0,000").replace("$1 million","$1,000,000").replace(" 1 Million", "$1,000,000");
		html=html.replace("and $800�s", "$800,000");
		String prices[] = U.getPrices(html+comData+invenHtm,"and \\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|\\$\\d{3},\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================	
		
		String[] sqft = U
				.getSqareFeet(
						html+comData,
						"square footage from \\d{4} to \\d{4}\\+ square feet|around \\d,\\d{3} square feet|\\d{4} sq ft|around \\d,\\d{3} square feet|\\d,\\d{3} – \\d,\\d{3} square feet|\\d{4}-\\d{4} square ft|\\d,\\d+ to almost \\d,\\d+ square feet|[0-9]{4} - [0-1]{4} Sqft|[0-9]{4} Sqft|from \\d{4} to \\d{4} square feet|from \\d,\\d{3} to \\d,\\d{3} square feet|<li>\\d{4} SF ",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//		U.log("MMMMMMMMMMM "+Util.matchAll(html+comData, "[\\s\\w\\W]{30}selling fast[\\s\\w\\W]{30}", 0));
		
//==================================================Homes Data===========================
		String allAvailHomeData = ALLOW_BLANK;
		String [] homeSections = U.getValues(html, "<div class=\"comm_listing_images\">", "</a>");
		for(String homeSec : homeSections){
			//U.log(homeSec);
			String homeUrl = U.getSectionValue(homeSec, "<a href=\"", "\"");
			homeUrl = homeUrl.replace("&amp;", "&");
			homeUrl = builderUrl + homeUrl;
			U.log("homeUrl :"+homeUrl);
			String homeHtml = U.getHTML(homeUrl);
			allAvailHomeData += U.getSectionValue(homeHtml, "<p class=\"listingdesc\">", "</div>");
		}
//	U.log(allAvailHomeData);	
//================================================community type========================================================
		html = html.replace(" unique location at Lakeside", "lakeside living");
		html = U.removeSectionValue(html, "<h2>Area Information", "<h2>Contact for more information");
		String communityType=U.getCommType(html+comData);
		
//==========================================================Property Type================================================
		html = U.removeComments(html);
		U.log(allAvailHomeData);
		html=html.replace("Executive 3-4  car garage homes", "executive home sites").replace("employing traditional detailing", "Traditional exterior").replace("Estate living with ", "Estate Residences")
				.replace("craftsmanship", "Craftsman Style Homes").replace("Hickory-Manor.jpg", "Hickory-The Manors.jpg")
				.replace("/tremont-manor/", "/tremont-manor house/").replace("optional flex space and upgrades", "optional flex room space and upgrades")
				.replace("a flex gathering area, grilling and activity", "a flex room gathering area, grilling and activity");
		
		String proptype=U.getPropType(html+comData+allAvailHomeData);
		U.log("Property type:::"+proptype);
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(html+comData+allAvailHomeData, "[\\s\\w\\W]{30}flex[\\s\\w\\W]{30}", 0));
//==================================================D-Property Type======================================================
		
		String dtype=U.getdCommType((html+comData+allAvailHomeData).replaceAll("first floor owner|first and second floor owner", ""));
		
//==============================================Property Status=========================================================
		html = html.replaceAll("COMING SOON NEW GOLF|will be basement|COMING SOON NEW GOLF|Move-in Ready! Homesite |our move-in ready home|<p><strong>Coming Soon|neighborhood with only 14 opportunities|Only 14 opportunities with wooded acreage|<p><strong>Coming Soon\\s*\\|\\s*FMLS|two new homes move-in ready|New homes available to view on Enter|Hours</h3>\\s+<p>Coming|Directions\"></span></p>\\s+<p>Coming|and ready to move in", "");
		html =  html.replace("Only A Few Lots Remain", "Only few lots remain").replace("for&nbsp;a New Peachtree Residential Home Remains", " Home Remains");
		String pstatus=U.getPropStatus(html+comData);
		//U.log(html);
//============================================note====================================================================
		html =html.replaceAll("decorator allowance on presales|Upgrades on presales| on presales!</strong></p>", "");
		
		note=U.getnote(html); //.replace("Now Preselling Final Townhome Building", "")
/*		 if(comUrl.contains("/communities/muirfield-park/")) {
//			 note=note.replaceAll("Pre-sale", "Pre-sale - 2 Available Homesites");
			 pstatus=pstatus.replaceAll("2 Available Homesites,", "");
		 }*/

//		if(comUrl.contains("/communities/the-summit-at-river-run/") || comUrl.contains("https://www.peachtreeresidential.com/communities/garden-park"))pstatus = "Only 28 Opportunities";
		
	
		U.log("Property status:::"+pstatus);
		
		
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		
	}
		j++;
//	}catch(Exception e){}
	}
	
}
