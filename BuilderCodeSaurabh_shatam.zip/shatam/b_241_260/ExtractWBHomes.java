/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_241_260;

import java.io.IOException;
import java.util.HashMap;

import org.apache.commons.collections.MultiHashMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractWBHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver;
	public ExtractWBHomes()
			throws Exception {
		super("WB Homes","https://www.wbhomesinc.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("WB Homes");
	}
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractWBHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"WB Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}
	
	HashMap<String, String> latList=new HashMap<>();
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
		String mainHtml=U.getHTML("https://www.wbhomesinc.com/neighborhoods/");
		//------------------------------------------------------------------------------------------------------------------------------
		
		//--------------------------------------------------------------------------------------------------------------------------------	
		String[] comSec=U.getValues(mainHtml, "<article class=","Get Directions");
		for(String comData:comSec)
		{
			String comUrl=U.getSectionValue(comData, "<a href=\"","\"");
			addDetails(comUrl,comData);
		}
		LOGGER.DisposeLogger();	
//		driver.quit();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.wbhomesinc.com/neighborhoods/bexley/")) return;
		
		if(comUrl.contains("#newCommModal"))return;//redirect on main page
		if(comUrl.contains("#arlingtonCommModal"))return;//redirect on main page	
//	try{
	{
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"=====>Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHTML(comUrl);
		U.log(U.getCache(comUrl));	
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "data-name=\"","\"");
		communityName=communityName.replace("| Twins &#038;", "").replace("| Single-Family Homes", "").replaceAll("In Collegeville, PA| in Collegeville, PA", "");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		
		String note=ALLOW_BLANK;
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
	
		String addSec=U.getSectionValue(comData, "data-address=\"","\"");
		U.log(addSec);
		if(addSec!=null)
		{
			addSec=addSec.replace("Model Home Address,", "");
			addSec = U.formatAddress(addSec);
			U.log(addSec);
			String tempAdd[] = addSec.split(",");
			add[0] = tempAdd[0].trim();
			add[1] = tempAdd[1];
			add[2] =Util.match(tempAdd[2], "\\w+");
			add[3] = Util.match(tempAdd[2], "\\d+");

		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
		
		
		if(comData!=null)
		{
			latlag[0]=U.getSectionValue(comData, "data-lat=\"","\"");
			latlag[1]=U.getSectionValue(comData, "data-lng=\"","\"");
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null)latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if((add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
//			add[3]="";
			add[3]=U.getAddressGoogleApi(latlag)[3];
			if(add == null)add[3] = U.getAddressHereApi(latlag)[3];
			geo="TRUE";
		}
		
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		//========================UNIT COUNT=======
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		String lotHtml;
		if(html.contains("Launch Interactive Site Plan") ||
				html.contains("Launch Interactive Site Map")) {
			
		String siteUrlPart=U.getSectionValue(html, "<div class=\"site-map-wrap col-lg-12 col-sm-12\">", "</p>");
		String lotUrl=U.getSectionValue(siteUrlPart, "href=\"", "\"");
		U.log("lotUrl ::"+lotUrl);
		lotHtml=U.getHtml(lotUrl,driver);
		U.log(U.getCache(lotUrl));
		String[] lotSection=U.getValues(lotHtml, "<g id=\"v.1.opt", "\">");	
		counting=Integer.toString(lotSection.length);
		U.log("counting ::"+counting);
		}
//============================================Price and SQ.FT======================================================================
		
		int quickcount = 0 ;
		String[] quickUrls=U.getValues(html, "quick_move_in type-quick_move_in status-","</div>");//home-type__link\">");
		String allQuickData="";
		for(String quickUrl : quickUrls)
		{
		
			String check = quickUrl;
			quickUrl=U.getSectionValue(quickUrl, "<a href=\"","\"");
			U.log("quickUrl::::"+quickUrl);
			String quickHtml =U.getHTML(quickUrl);
			allQuickData += U.getSectionValue(quickHtml, "<h1>", "</aside>");
			
			
			if(!quickHtml.contains("<h3>SALE PRICE: SOLD!</h3>") && !check.contains("-model-sold-"))
				quickcount++;
		}
		
		//=========== Homes Plan ====================
		String [] homeUrlSec = U.getValues(html, "home_type type-home_type status-publish", "<div class=");
		String combinedHomeHtml = null;
		for(String homeUrl : homeUrlSec){
			homeUrl = U.getSectionValue(homeUrl, "<a href=\"", "\"");
			U.log("::homeUrl::"+homeUrl);
			String homeHtml = U.getHTML(homeUrl);
			combinedHomeHtml += U.getSectionValue(homeHtml, "<article class=", "</aside>");
		}
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000")
				.replace("Large 35,000 sq", "");
		comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
		String prices[] = U.getPrices(html+comData,"\\$\\d{1},\\d{3},\\d+|\\$\\d{3},\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+comData, "[\\w\\s\\W]{30}$600[\\w\\s\\W]{30}", 0));

//======================================================Sq.ft===========================================================================================		
		String[] sqft = U
				.getSqareFeet(
						html+comData,
						"<div class=\"home-type-detail__value\">\\s+\\d{4}&nbsp&ndash;&nbsp\\d{4} sq ft\\s+</div>|from \\d{1},\\d+ to \\d{1},\\d+|\\d{1},\\d+ S.F|Total Living - \\d{1},\\d+ S.F.|\\d{1},\\d+ sq.ft.|\\d{1},\\d+ Sq Ft|\\d{1},\\d+ sq. ft|\\d{4} sq ft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================remove sectio=================
		String remSec = U.getSectionValue(html, "<section class=\"callout callout--advisor \">", "<div class=\"container-fluid neighborhood-directions");
		if(remSec!=null){
			html = html.replace(remSec, "");
			U.log(":::::::::remSec");
		}
		html = html.replaceAll("Elongated|elongated|Luxurious Bathrooms|Country Club Road| Country Club\"|Spring Ford Country Club", "");
//================================================community type========================================================
//		U.log(comData);
		String communityType=U.getCommType((html+comData).replace("Country Club Road ", ""));
		
//==========================================================Property Type================================================
		html=html.replaceAll("farmhouse exterior elevation|Luxurious Bathroom|homeowners/\">Happy Homeowners|patio door|Townhomes in|carriage style garage|liding patio door","").replace("custom home builders", "semi-custom homes");
		allQuickData = allQuickData.replace("loft area", "loft home").replace("3rd floor finished", "3 story finished")
				.replace("Craftsman railing", "with Craftsman Style railing");
		
		String proptype=U.getPropType((html+comData+allQuickData+combinedHomeHtml)
				.replace("Kitchens® premium Carriage House furniture quality", "").replace("Kitchens® Carriage House high profile", "")
				.replaceAll("Luxurious owner’s suite|Craftsman rails|carriage style garage|craftsman styled facade</li>|_Craftsman_|Craftsman posts|Monterey Craftsman|Augusta Craftsman", ""));
		if(proptype.contains("Townhome") && proptype.contains("Townhouse"))
			proptype = proptype.replaceAll("Townhouse,|,Townhouse", "");
		
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+comData+allQuickData+combinedHomeHtml, "[\\w\\s\\W]{60}carriage[\\w\\s\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+comData+allQuickData+combinedHomeHtml, "[\\w\\s\\W]{60}luxury[\\w\\s\\W]{30}", 0));
//==================================================D-Property Type======================================================
		html=html.replaceAll(" 1st or 2nd floor |first or second floor"," 1 Story 2 Story ")
				.replace("Second Floor Laundry", " 2 Story Laundry").replaceAll("2-and 3-story|2 and 3-story", " 2 Story 3 Story ");
		
		String dtype=U.getdCommType(html.replace("floor", "")+comData+(combinedHomeHtml+allQuickData).replaceAll("floor", ""));
		
//==============================================Property Status=========================================================
		//html=html.replaceAll("Quick Move-ins</a>|Quick Move-in Homes|","");
		html=html.replaceAll("map-item__text\">\n\\s+Coming Spring 2021|name=\"coming|title=\"Coming|Grand Opening! Visit us to tour|\">Quick Move-ins</a>|quick-move-ins\">Quick Move-in Homes</option>| Coming soon!\\s*</dd>|Information Center Hours\\s*</dt>\\s*<dd>\\s*Coming soon|Coming soon\\s+</dd>|Coming Soon! |Ask about special CLOSE-OUT Incentives!|Quick Move","");
		String pstatus=ALLOW_BLANK;
	//	U.log(comData);
		pstatus = U.getPropStatus((html+comData).replaceAll(" Over 75% sold out!\\s*</div>|model grand opening|official grand opening.</p>|homes are now available in Ambler","")).replace("basement homesites", "Basement Homesites Available");
		
		U.log("pstatus: "+pstatus);
		
		if(!pstatus.contains("Quick") && quickcount>0){
			if(pstatus == ALLOW_BLANK)pstatus = "Quick Move-Ins";
			else if(pstatus != ALLOW_BLANK) pstatus = pstatus +", Quick Move-Ins";	
		}
		
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+comData, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));

//============================================note====================================================================
		if(latlag[0].length()<4) {
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null)latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		
		communityName=communityName.replaceAll("Club View At Spring Ford In Royersford, Pennsylvania", "Club View At Spring Ford");
//		if(comUrl.contains("https://www.wbhomesinc.com/neighborhoods/homes-doylestown-pa-the-preserve-at-burke-farm/"))pstatus = pstatus.replace("Basement Homesites,", "Basement Homesites Available,");
		
		
//		if(comUrl.contains("https://www.wbhomesinc.com/neighborhoods/overlook-at-gwynedd/")) {
//			add[1]="Lower Gwynedd";
//			add[3]="19002";
//		}
		add[0]=add[0].replace("126-152 Country ", "126 Country ");
		
		if(comUrl.contains("https://www.wbhomesinc.com/neighborhoods/homes-collegeville-pa-the-courts-at-brynwood/"))dtype = "3 Story, 2 Story";//Img
		note = U.getnote(html+comData);
		U.log("Address---->"+add[0]+" city: "+add[1]+" state :"+add[2]+" :zip:"+add[3]);

		if(comUrl.contains("https://www.wbhomesinc.com/neighborhoods/collegeville-pa-homes-founders-estate-at-providence/")) {
			if(pstatus!=ALLOW_BLANK)
				//pstatus += ", Coming Soon";
				//minPrice ="$400,000";
				dtype +=", 3 story";
		}
		
			data.addCommunity(communityName.trim(),comUrl.trim(), communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("&amp;","and").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Ii", "II"));
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
	}
			j++;
//	}catch(Exception e){}
		
	}

}
