//Modified By:: Sawan
//Date :: 02-02-2017
package com.shatam.b_241_260;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class MayberryHomes extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	String Geo;
	static int j =0;
	static String Builder_name = "Mayberry Homes";
	static String HOME_URL = "https://www.mayberryhomes.com/";
	CommunityLogger LOGGER;
	WebDriver driver;
	private String builderUrl = "https://www.mayberryhomes.com";
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new MayberryHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Mayberry Homes.csv", a.data()
				.printAll());
	}

	public MayberryHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger(Builder_name);
		
	}
	
	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.mayberryhomes.com/API/communities.json");
		U.log("Extracted communities");
		String availableHomes = U.getHTML("https://www.mayberryhomes.com/API/homes.json");
		U.log("Extracted available homes");
		String floorPlanHomes = U.getHTML("https://www.mayberryhomes.com/API/models.json");
		U.log("Extracted floor plans");
		
		String[] comSections = U.getValues(html, "{\"com_id\":", "\"timestamp\"");
		
		U.log(comSections.length);
		for(String comSec : comSections){
//			U.log(comSec);
			comSec = comSec.replace("\\", "");
			String comUrl = U.getSectionValue(comSec, "\"url\":\"", "\",");
			comUrl = builderUrl + comUrl;
	//		U.log(comUrl);
			String comName = U.getSectionValue(comSec, "\"com_name\":\"", "\",");
			
			//U.log(comSec);
			String id = Util.match(comSec, "^\\d+,");
			U.log("id ::"+id);
			String availableHtml = "";
			String availableSections[] = U.getValues(availableHomes, "\"inv_community\":"+id, "\"timestamp\"");
			U.log(availableSections.length+":::::::::avail");
			for(String sec : availableSections)
				availableHtml += sec;
			
			String floorHtml = "";
			String floorSections[] = U.getValues(floorPlanHomes, "\"cmod_communityId\":"+id, "\"timestamp\"");
			U.log(floorSections.length+":::::::::avail");
			for(String sec : floorSections)
				floorHtml += sec;
//			try { 
				findCommunityDetails(comUrl,comName,comSec, availableHtml, floorHtml); 
//				} catch (Exception e) {}
			
		}
		LOGGER.DisposeLogger();

	}
	
//	WebDriver driver=null;

	
	private void findCommunityDetails(String commUrl, String communityName, String commSec, String availableHomeHtml,
			String floorPlanHtml)throws Exception {
//		if(j == 3)
	{
		
//		if(!commUrl.contains("https://www.mayberryhomes.com/perry-lakes")) return;
		
		LOGGER.AddCommunityUrl(commUrl);
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl("Repeated ===="+commUrl);
			return;
		}
		U.log("Count::"+j);
		U.log(commUrl);
		U.log(U.getCache(commUrl));
		U.log("CommName===>"+communityName);
		
		//U.log("commSec: "+commSec);
		
		//================= No. of units ===========
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		String comHtml = U.getHtml(commUrl, driver);
		units = getUnits(comHtml, commUrl, driver);
		U.log("Total Units : "+units);
		
				
		//=============== LatLng Section ==============
		String latLong[] = {ALLOW_BLANK,ALLOW_BLANK};
		latLong[0] = U.getSectionValue(commSec, "com_lat\":", ",\"");
		latLong[1] = U.getSectionValue(commSec, "com_lng\":", ",\"");
		U.log(Arrays.toString(latLong));
		//============= Address =====================
		String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "False";
		
		if(latLong[0] != ALLOW_BLANK && latLong[1] != ALLOW_BLANK){
			add = U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getGoogleAddressWithKey(latLong);
			U.log(Arrays.toString(add));
			geo = "True";
		}

		
		//=============== Price Section =========================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commSec = commSec.replace("0's", "0,000").replace("0’s", "0,000").replaceAll("0K's|0K's", "0,000");
	    if(floorPlanHtml!=null)floorPlanHtml=floorPlanHtml.replaceAll("basePriceDisplay\":\"\\$\\d{6}\"", "").replaceAll("inv_priceDisplay\":\"\\$\\d+,\\d+", "");
	    
	    
		String[] price = U.getPrices((commSec+availableHomeHtml+ floorPlanHtml).replace("$209,900", ""),
				"Low \\$\\d{3},\\d{3}|mid \\$\\d+,\\d+|inv_priceDisplay\":\"\\$\\d+,\\d+|\"mod_basePriceDisplay\":\"\\$\\d{6}\"|From the \\$\\d+,\\d+|From the \\d+,\\d+|high \\$\\d{3},\\d{3}| low \\$\\d{3},\\d{3}|(mid|High)-\\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		//U.log("MMMMMMMM "+Util.matchAll(floorPlanHtml, "[\\w\\s\\W]{30}375[\\w\\s\\W]{30}",0));
		U.log("MinPrice :" + minPrice + " MaxPrice:"+ maxPrice);

		//================== Sqft ==========================
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sq = U.getSqareFeet(commSec+availableHomeHtml+floorPlanHtml.replace("inv_sqft\":1494", ""),
						"inv_sqft\":\\d+|\\d,\\d+ Sq.Ft.|mod_sqft\":\\d{4}|\\d,\\d{3} Sq. Ft.|Sq. Ft.:</strong> \\d+,\\d+<|Sq. Foot: </strong>\\d+,\\d+<| House with its \\d,\\d+ square feet ",
						0);
		minSqft = (sq[0] == null) ? ALLOW_BLANK : sq[0];
		maxSqft = (sq[1] == null) ? ALLOW_BLANK : sq[1];
		
		
//		U.log("pp"+Util.matchAll(floorPlanHtml,"[\\w\\W\\s]{40}1494[\\w\\W\\s]{40}", 0));

		U.log("minSqf :" + minSqft + " maxSqf:" + maxSqft);
		
		//=============== Community Type ===================
		commSec = commSec.replace("Welcome to Lakeside Preserve", "Welcome to Lakeside community Preserve");
//				.replace("Explore Waterfront", "Explore Waterfront community");
		String communityType = U.getCommunityType(commSec);
		//U.log(">>>>>>>>>>>> "+Util.matchAll(commSec,"[\\w\\W\\s]{40}Lakefront[\\w\\W\\s]{40}", 0));
		
		//=============== Property Status ==================
		commSec = commSec.replace("Now selling brand","Now Selling").replace("Phase I is now selling", "Phase I now selling").replace("Walk out home sites are still available", "Walk out home sites available")
				.replaceAll("with 50 home sites available|park view lots|com_image\":7603,\"com_status\":\"Coming Soon\"", "").replace("Only a few home sites left", "Only few home sites left")
				.replace("\"com_status\":\"Coming Soon\"", "");
				
//		
		String pStatus=U.getPropStatus(commSec.replace("50 home sites now available", "50 homesites now available"));
		U.log("pStatus :"+pStatus);
		//U.log(">>>>>>>>>>>> "+Util.matchAll(commSec,"[\\w\\W\\s]{40}Lakefront and wooded[\\w\\W\\s]{40}", 0));
		
		//================ Property Type ==================
		commSec = commSec.replace("Luxury Golf Course", "Luxury Homes Golf Course");
		commSec = commSec.replace("neo-traditional, pedestrian-friendly community ", "Traditional exterior");
		String propType = U.getPropType(commSec);
			U.log(commSec);	
		//================= Derived Community Type ==========
	
		ArrayList<String> storiesList = Util.matchAll(availableHomeHtml, "mod_stories\":(\\d\\.?\\d?)", 1);
		storiesList.addAll(Util.matchAll(floorPlanHtml, "mod_stories\":(\\d\\.?\\d?)", 1));
		String stories = "";
		for(String story : storiesList){
			stories = stories + story+ " Story, ";
		}

		String dType = U.getdCommType((commSec+floorPlanHtml+availableHomeHtml+stories).replace("1.5-Story", "one-half story").replaceAll("ranch home has|\"mod_type\":\"Ranch\"|floor", ""));
		
	//	U.log("MMMMMMMM "+Util.matchAll(commSec+floorPlanHtml+availableHomeHtml+stories, "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}",0));
		U.log("Dtype::"+dType);
		//================== Notes =======================
	
//		if(commUrl.contains("https://www.mayberryhomes.com/fieldstone-farms")) {maxPrice=ALLOW_BLANK;pStatus=ALLOW_BLANK;}
		if(commUrl.contains("https://www.mayberryhomes.com/aspen-gardens"))minPrice="$200,000";
		if(commUrl.contains("/silverstone-estates"))pStatus=pStatus.replace(", Coming Soon", "");
		String note = U.getnote(commSec);
		
		
//		if(commUrl.contains("https://www.mayberryhomes.com/fieldstone-farms"))
//		maxPrice="$415,500";
		if(commUrl.contains("https://www.mayberryhomes.com/falcon-pointe-west"))minPrice="$295,500";
		if(commUrl.contains("https://www.mayberryhomes.com/copper-creek"))pStatus +=", Now Selling";
/*		if(commUrl.contains("/copper-creek")) {
			pStatus = pStatus+", 50 Home Sites Available";
		}
*/		
		

				

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);		
		data.addCommunity(communityName.trim(),commUrl, communityType);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note); 
	}
	j++;
	}
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("Community Map</a>")) {
			U.log("MAP PRESENT");
			
			mapLink = comUrl + "-map";
			U.log("mapLink: "+mapLink);
			
			mapData = U.getHtml(mapLink, driver);
			
			if(mapData.contains("<div class=\"im_point\"")) {
				
				ArrayList<String> dots = Util.matchAll(mapData, "<div class=\"im_point\"", 0);
				U.log("Count dots: "+dots.size());
				totalUnits = String.valueOf(dots.size());
			}
			
		}else {
			U.log("MAP NOT PRESENT");
		}
		
		
		return totalUnits;
	}
	
}