/**
 * @author saurabh
 * @date Sap 2022
 * 
 */
package com.shatam.b_261_280;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractAntaresHomes extends AbstractScrapper {

	int i = 0;
	static int j = 0, count = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	private static final String BASEURL = "https://www.antareshomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractAntaresHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Antares Homes.csv", a.data().printAll());
	}

	
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String,String>();
	public ExtractAntaresHomes() throws Exception {

		super("Antares Homes", BASEURL);
		LOGGER = new CommunityLogger("Antares Homes");
	}

	public void innerProcess() throws Exception {
		String basehtml = U.getHTML(BASEURL);

		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(basehtml, "__PRELOADED_STATE__ =", "</script>");

		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
//		U.log(jobj.size());
//		String redirecrSec=U.getSectionValue(removeScript, "\"redirects\":", "]");
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities").getAsJsonObject().get("5702c349f410954eb27d0480");
		JsonArray comJsonData = (JsonArray) commJson.getAsJsonObject().get("data");
//		U.log(comJsonData);
		U.log("Total communities are = "+comJsonData.size());
		U.log("comJsonData"+comJsonData.size());
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans").getAsJsonObject().get("5702c349f410954eb27d0480");
		JsonArray planJsonData = (JsonArray) planJson.getAsJsonObject().get("data"); U.log("planJsonData"+planJsonData.size());
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes").getAsJsonObject().get("5702c349f410954eb27d0480");
		JsonArray homeJsonData = (JsonArray) homeJson.getAsJsonObject().get("data"); U.log("homeJsonData"+homeJsonData.size());
		
		String comm[] = U.getValues(comJsonData.toString(), "{\"@type\":\"GatedResidenceCommunity", "\"type\":\"community\"}"); U.log(comm.length);
		
		String plans[] = U.getValues(planJsonData.toString(), "{\"@type\":\"ProductModel\"", "\"planType\":\"Single Family\"}"); U.log(plans.length);

		String homes[] = U.getValues(homeJsonData.toString(), "{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}"); U.log(homes.length);
		
		
		for (String home : homes) {
			String comunityIn = U.getSectionValue(home, "\"containedIn\":\"", "\",");
			homesData.put(comunityIn, home);
		}
		U.log(homes[0]);
		for (String plan : plans) {
				String comunityIn = U.getSectionValue(plan, "\"containedIn\":\"", "\",");
				plansData.put(comunityIn, plan);
		}
		U.log("homesData"+homesData.size());
		U.log("plansData"+plansData.size());
      
       


		for (JsonElement comJsonData1 : comJsonData) {
			String u2 = U.getSectionValue(comJsonData1.toString(), "\"sharedName\":", "\",").replace("\"", "").toLowerCase();
			String streetAddress=comJsonData1.getAsJsonObject().get("address").toString().replace("\"", ""); 
			String u1 = U.getSectionValue(streetAddress, "addressLocality:", ",").toLowerCase();
            String commUrl = "https://www.antareshomes.com/neighborhoods/"+u1+"/"+u2;
            U.log(i+"::"+commUrl);
i++;
			addDetails(commUrl.replace(" ", "-") , comJsonData1);
//			//break;
		}
//		U.log(">>>>>" + comSection.length);
//		U.log(count);
		LOGGER.DisposeLogger();
	}
	private void addDetails(String cUrl, JsonElement cSec) throws Exception {
		// TODO Auto-generated method stub
	//	if(j>=61)
	//	{
//	try	{
		
			if(!cUrl.contains("https://www.antareshomes.com/neighborhoods/forney/lovers-landing"))return;
			U.log("csewction :: "+cSec.toString());
			LOGGER.AddCommunityUrl(cUrl);
			String add[] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
			String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
			String note = ALLOW_BLANK;
			String geo = "FALSE";
			String comId = U.getSectionValue(cSec.toString(), "\"_id\":\"", "\"");
			JsonParser jparser = new JsonParser();

			String streetAddress=cSec.getAsJsonObject().get("address").toString().replace("\"", ""); U.log(streetAddress);
			add[0] = U.getSectionValue(streetAddress, "streetAddress:", "}");  U.log(add[0]);
			add[1] = U.getSectionValue(streetAddress, "addressLocality:", ","); U.log(add[1]);
			add[2] = U.getSectionValue(streetAddress, "addressRegion:", ","); U.log(add[2]);
			add[3] = U.getSectionValue(streetAddress, "postalCode:", ","); U.log(add[3]);

			String geoIndexed=cSec.getAsJsonObject().get("geoIndexed").toString().replace("", ""); U.log(geoIndexed);
//			latlag[0] = U.getSectionValue(cSec.toString(), "\"lat\":\"", "\",");  U.log(latlag[0]);
//			latlag[1] = U.getSectionValue(cSec.toString(), "\"lon\":\"", "\","); U.log(latlag[1]);
			U.log(geoIndexed);
			latlag[1] = U.getSectionValue(geoIndexed, "[",",");
			latlag[0] = U.getSectionValue(geoIndexed, ",","]");
			U.log("geoIndexed"+latlag[0]+" "+latlag[1]); 
			//===================================================================================================

			if(latlag[0]==ALLOW_BLANK ||latlag[0] == null|| latlag[0].length()==0) {
				latlag=U.getGoogleLatLngWithKey(add);
//				geo="TRUE";
//				note="lat long Taken From add";
				U.log(latlag[0]+" "+latlag[1]); 
			}
//			if(add[0]==ALLOW_BLANK&&latlag[0]!=ALLOW_BLANK) {
//				add=U.getAddressGoogleApi(latlag);
//				geo="True";
//			}
			
            //===================================================================================================
			
			ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId);
			String homesecs = ALLOW_BLANK;
			if (homeData != null) {
				for (String home : homeData) {
					homesecs += home;
				}
			}
			String storySec=ALLOW_BLANK;
			ArrayList<String> planData = (ArrayList<String>) plansData.get(comId);
			String plansecs = ALLOW_BLANK;
			if (planData != null) {
				for (String plan : planData) {
					plansecs += plan;
				}
				
			}
			//===================================================================================================
//			U.log(")))))))))))))))))))))))"+homesecs);
//			U.log("2222222222222222222"+plansecs);
			String[] price = U.getPrices( cSec.toString() +plansecs +homesecs ,
					"\"price\":\\d{6},|\"inv_price\":\\d{6},|\"com_priceHigh\":\\d{6}\\,|\"com_priceLow\":\\d{6}\\,", 0);
			U.log("price=="+price[0] + " " + price[1]);
			if(price[1] == null) {
				price[1] = ALLOW_BLANK;
			}
			if(price[0] == null) {
				price[0] = ALLOW_BLANK;
			}
			
			String[] sqft = U.getSqareFeet(cSec.toString()+plansecs +homesecs
					, "\"sqft\":\\d{4},|\"sqftHigh\":\\d{4},|\"sqft\":\\d{4}/,|\"sqftHigh\":\\d{4}/,|\"sqftLow\":\\d{4}/,", 0);
			U.log("sqft==="+sqft[0] + " " + sqft[1]);
			if(sqft[1] == null) {
				sqft[1] = ALLOW_BLANK;
			}
			if(sqft[0] == null) {
				sqft[0] = ALLOW_BLANK;
			}
            
			//===================================================================================================
			
			String comName = U.getSectionValue(cSec.toString(), "com\",\"name\":\"", "\",");
			U.log(comName);
			String comType = U.getCommunityType(cSec.toString()+plansecs+homesecs);
			U.log("comType=="+comType);
			String propStatus = U.getPropStatus(cSec.toString()+plansecs+homesecs);
			U.log("propStatus=="+propStatus);
			String propType = U.getPropType(cSec.toString()+plansecs+homesecs);
			U.log("propType=="+propType);
			String dpType = U.getdCommType(cSec.toString()+plansecs+homesecs);
			U.log("dpType=="+dpType);
			U.log(add[0]);
			U.log(add[1]);
			U.log(add[2]);
			U.log(add[3]);
			U.log(latlag[0]);
			U.log(latlag[1]);
			//===================================================================================================


			data.addCommunity(comName, cUrl, comType);
			data.addAddress(add[0], add[1], add[2] , add[3]);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(price[0], price[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
//	//	}
		j++;
	//	}
//
//	}catch (Exception e) {}
}

	public static String getNoHtml(String html) {
		String noHtml = null;
		noHtml = html.toString().replaceAll("\\<.*?>", " ");
		return noHtml;
	}
}
