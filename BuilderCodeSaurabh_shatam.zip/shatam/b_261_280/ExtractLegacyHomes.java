/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLegacyHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	public ExtractLegacyHomes()
			throws Exception {
		super("Legacy Homes of Alabama","https://www.legacyhomesal.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Legacy Homes of Alabama");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractLegacyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Legacy Homes of Alabama.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver=new ChromeDriver();
		String mainHtml=U.getHtml("https://www.legacyhomesal.com/communities", driver);
		String[] comSec=U.getValues(mainHtml, "<div class=\"comm-list-info\">","</a></div>");
		U.log(comSec.length);
		for(String comData:comSec)
		{
			U.log(comData);
			String comUrl="https://www.legacyhomesal.com"+U.getSectionValue(comData, "<a ng-href=\"","\"");
			System.out.println(U.getCachePath());
			addDetails(comUrl,comData);
		//	break;
		}
		
		LOGGER.DisposeLogger();
	}	
	
	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
		
		//if(!comUrl.contains("https://www.legacyhomesal.com/cedar-brook"))return;
		
	//	if(!comUrl.contains("https://www.legacyhomesal.com/pennington-freedom-series" ))return;
		U.log(j+"   commUrl-->"+comUrl);
				String html=U.getHtml(comUrl,driver);
				
				/*String rem=U.getSectionValue(html, "<head>","class=\"dropdown-menu\">");
				html=html.replace(rem,"");*/
		//============================================Community name=======================================================================
				//U.log(comData);
				String communityName=U.getSectionValue(comData, "class=\"ng-binding\"","/a>");
				communityName=U.getSectionValue(communityName, "\">","<");

				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				
				
				String note="";
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";

				if(comData!=null)
				{
					add[1]=U.getSectionValue(comData, "<span ng-if=\"com.city_name\" class=\"ng-binding ng-scope\">","</span>");
					add[2]=U.getSectionValue(comData, "<span ng-if=\"com.state_code\" class=\"ng-binding ng-scope\">,","</span>");
				}

				
				
				if(add[0].length()<4) {
					
					String addSec = U.getSectionValue(html, "Model Home:</strong>", "</h1>");
					if(addSec!=null)
					add = U.getAddress(addSec);
					
				}
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		//--------------------------------------------------latlng----------------------------------------------------------------
				
				String latSec=U.getSectionValue(html, "https://www.google.com/maps/","\"");
				U.log(latSec+"hello");
				if(latSec!=null)
				{
					latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
					latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
				}
				if(latSec==null) {
					
					latSec = U.getSectionValue(html, "<ng-map center=\"", "\"");
					String[] l = latSec.split(",");
					latlag[0] = l[0];
					latlag[1] = l[1];
				}
				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					
					geo="TRUE";
				}
				if((add[0].trim().length()<2 || add[0]==ALLOW_BLANK ||add[2]==null)&& latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					geo="TRUE";
				}
				if(add[3]==null && latlag[0]!=ALLOW_BLANK)
				{
					add[3]=U.getAddressGoogleApi(latlag)[3];
					geo="TRUE";
				}
				
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				
		//============================================Price and SQ.FT======================================================================
				
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				
				
		//======================================================Sq.ft===========================================================================================		
				html = html.replace("sq. ft.", "square feet");
				String[] sqft = U
						.getSqareFeet(
								html+comData,
								" \\d,\\d{3} square feet|\\d{1},\\d+ to \\d{1},\\d{3} sq ft|model.mod_sqft\">\\d+,\\d+|",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
		//================================================community type========================================================
	
				String communityType=U.getCommType((html+comData).replaceAll("TopGolf|recreation-golf|Jones Golf|Ledges Golf|rtjgolf|Colonial Golf Course", ""));
				
		//==========================================================Property Type================================================
				
				String floorPlandSec = U.getSectionValue(html, "<span>Floor Plans</span>", "<span>Features</span>");
				
				String clickButton[] =U.getValues(floorPlandSec, "ng-click=\"setCurrent(pageNumber)\" class=\"ng-binding\">", "</a>");
				System.out.println(clickButton.length);
							
				String floLinks[] = U.getValues(floorPlandSec, "ng-class=\"{'link': model.url, 'nolink': !model.url}\" ng-href=\"", "\"");
				List<String[]> list = new ArrayList<>();				
				list.add(floLinks);
				String fhtml = "";
				for(int i=0;i<clickButton.length; i++) 
				{		
					j = i+2;
					String path = U.getCachePath()+"legacyhomesal.com/"+communityName+""+j+".txt";
					File f = new File(path);
					String newHtml ="";
					if(f.exists()) {
						fhtml = fhtml + FileUtil.readAllText(path);
						newHtml = FileUtil.readAllText(path);
					}
					else
					{
						driver.findElement(By.xpath("//*[@id=\"plans\"]/div/div[3]/dir-pagination-controls/ul/li["+j+"]/a")).click();						
						fhtml = fhtml + driver.getPageSource();
						newHtml = driver.getPageSource();
						FileUtil.writeAllText(U.getCachePath()+"legacyhomesal.com/"+communityName+""+j+".txt", newHtml);
					}
					
					floorPlandSec = U.getSectionValue(newHtml, "<span>Floor Plans</span>", "<span>Features</span>");
					floLinks= U.getValues(floorPlandSec, "ng-class=\"{'link': model.url, 'nolink': !model.url}\" ng-href=\"", "\"");
					list.add(floLinks);										
				}
				
				
				for(String links[] : list)
				{
					String base = "https://www.legacyhomesal.com";	
					for(int i=0;i<links.length;i++) 
					{
						String fpageLink = base + links[i];
						String path = U.getCache(fpageLink);
						String html1 = FileUtil.readAllText(path);
						if(html1.contains("Uh oh, looks like that page you were looking for isn't here.")) {
							new File(path).delete();							
						}
						fhtml = fhtml +U.getHtml(fpageLink,driver);
						
					}
				}
				
				String fData = "";
				String[] floorSec = U.getValues(html, "title=\"\" href=\"", "\">");
				for(String s : floorSec) {					
					String data = U.getHtml("https://www.legacyhomesal.com"+s, driver);
					fData += data;					
				}
								
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");				
				comData=comData.replaceAll("0&#8217;s|0�s|0's|0s","0,000");				
				String prices[] = U.getPrices(html+comData+fData+fhtml,"\\$\\d{1},\\d+,\\d+|\\$\\d+,\\d+", 0);
				//prices = U.getPrices(fhtml,"\\$\\d{1},\\d+,\\d+|\\$\\d+,\\d+|Base Price $\\d+,\\d+", 0);
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
//=====================================================================================				
				comData = comData.replace("Colonial Pointe", "").replace("colonial-pointe", "");
				html = comData.replace("Colonial Pointe", "").replace("colonial-pointe", "");
				String proptype=U.getPropType((html+comData+fData).replaceAll("Colonial Pointe|colonialpointe|PhaseName=Colonial|golfatcolonial|Colonial Dr|Colonial Golf Course|<span >Coming Soon</span>|'Coming Soon' -->|dalton_craftsman|NORFOLK- Craftsman|Dalton Craftsman|craftsman__|Craftsman elevations|Cambridge Craftsman|winston_cottage|Winston Cottage", "").replace("craftsman.jpg", ""));
				
		//==================================================D-Property Type=========================================TopGolf=============
				html=html.replace("Stories <span class=\"value\">", "Story ");
				
				
				String dtype=U.getdCommType(html+comData+fData + fhtml);
				
		//==============================================Property Status=========================================================
				U.log(comData);
				comData=comData.replaceAll("com.com_status != 'Coming Soon'|com.com_status == 'Coming Soon' ", "");
				comData=comData.replaceAll("Coming Soon Community</li>", "Coming Soon");
				System.out.println(html);
				String html1 =U.getHtml(comUrl,driver);
				String pstatus=U.getPropStatus((html1+comData).replaceAll("<span >Coming Soon</span>|'Coming Soon' -->","").replace("status != 'Coming Soon'\"", ""));
				
		//============================================note====================================================================
				
				
				
				
				if(data.communityUrlExists(comUrl))
					{
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
					}
				add[2]=add[2].replace(",","").trim();
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					j++;
	}

}
