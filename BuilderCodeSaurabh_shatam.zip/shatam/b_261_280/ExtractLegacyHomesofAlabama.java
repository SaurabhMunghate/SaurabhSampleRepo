/**
 * @author saurabh
 * @date Sap 2022
 * 
 */
package com.shatam.b_261_280;

import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.b_061_080.ExtractMungo;
import com.shatam.scrapper.AbstractScrapper;

import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLegacyHomesofAlabama extends AbstractScrapper{

	

		public ExtractLegacyHomesofAlabama() throws Exception {
//		super(builderName, builderUrl);
		super("Legacy Homes of Alabama","https://www.legacyhomesal.com");
		LOGGER = new CommunityLogger("Legacy Homes of Alabama");
	}

//		int i = 0;
//		static int j = 0, count = 0;
		CommunityLogger LOGGER;
//		WebDriver driver = null;
//		private static final String BASEURL = "https://www.legacyhomesal.com/API/communities.json";

		public static void main(String[] args) throws Exception {

			AbstractScrapper a = new ExtractLegacyHomesofAlabama();
			a.process();
			FileUtil.writeAllText(U.getCachePath() + "Legacy Homes of Alabama.csv", a.data().printAll());
		}

		MultiValueMap plansData = new MultiValueMap();
		MultiValueMap homesData = new MultiValueMap();
		MultiValueMap modelData = new MultiValueMap();
		HashMap<String, String> commDatas = new HashMap<String,String>();

		public void innerProcess() throws Exception {
			//--------------------------communities.json
			String baseJsonurl = U.getHTML("https://www.legacyhomesal.com/API/communities.json");
			JsonParser jparser = new JsonParser();
			JsonArray communitiesJson = (JsonArray) jparser.parse(baseJsonurl).getAsJsonArray();
			U.log(communitiesJson.size());
			//---------------------------homes.json
			String homeData1 = U.getHTML("https://www.legacyhomesal.com/API/homes.json");
			JsonParser jparser1 = new JsonParser();
			JsonArray homeJson = (JsonArray) jparser1.parse(homeData1).getAsJsonArray();
			U.log(homeJson.size());
			//---------------------------homes.json
			String modelsData1 = U.getHTML("https://www.legacyhomesal.com/API/models.json");
			JsonParser jparser2 = new JsonParser();
			JsonArray modelsJson = (JsonArray) jparser2.parse(modelsData1).getAsJsonArray();
			U.log(modelsJson.size());
			//---------------------------home
//            String homedata = communitiesJson.toString();
//							U.log(homeData);
            
//            JsonObject commJson = (JsonObject) communitiesJson.getAsJsonObject().get("");
//    		JsonObject planJsonL = (JsonObject) jobj.getAsJsonObject().get("plans");
//    		JsonObject homeJsonL = (JsonObject) homeJson.getAsJsonObject().get("");
//    		String plans[] = U.getValues(planJsonL.toString(), "{\"@type\":\"ProductModel", "\"type\":\"plan\"}");

//            String plans[] = U.getValues(planJson.toString(), "{\"@type\":\"ProductModel", "\"type\":\"plan\"}");
			
			String communities[] = U.getValues(baseJsonurl.toString(), "com_id\"", "timestamp");
    		U.log("communities ::"+communities.length);
    		for (String communitie : communities) {
//    			U.log(communitie);
    			String comunityIn = U.getSectionValue(communitie, ":", ",");
//    			U.log(comunityIn);
    			if(comunityIn == null ) {
    				continue;
    			}
//    			U.log(comunityIn);
//    			U.log(home);
//    			homesData.put(comunityIn, home);
//    			break;
    		}
    		
    		
    		String homes[] = U.getValues(homeJson.toString(), "inv_id", "timestamp");
    		U.log("homes"+homes.length);
    		for (String home : homes) {
    			String comunityIn = U.getSectionValue(home, "com_id\":", ",");
    			if(comunityIn == null ) {
    				continue;
    			}
//    			U.log(comunityIn);
//    			U.log(home);
    			homesData.put(comunityIn, home);
//    			break;
    		}
    		U.log(homesData.size());
    		
    		
    		String models[] = U.getValues(modelsJson.toString(), "mod_description", "timestamp");
    		U.log(models.length);
    		for (String model : models) {
    			String comunityIn = U.getSectionValue(model, "com_id\":", ",");
    			if(comunityIn == null ) {
    				continue;
    			}
//    			U.log(comunityIn);
//    			U.log(home);
    			modelData.put(comunityIn, model);
//    			break;
    		}
    		U.log(modelData.size());
    		
    		
    		//===========================================
//    		String homedata = "";
    		int i = 0;
			for(JsonElement jsonData:communitiesJson) {
				
//				for(String communitie :communities) {
//					String comunityIn = U.getSectionValue(jsonData.toString(), ":", ",");
//	    			U.log("Com Id ::: "+comunityIn);
	    			
					
//				communitiesJson = (JsonArray) modelData.get(comId);
//				U.log(jsonData);
//				String jsonData1 = jsonData.toString();
//				homedata = "";
				
//				String idd = baseJsonurl.toString();
//				idd = U.getSectionValue(idd, "com_id\":", ",");
//				U.log("iddiddidd"+idd);
				
//				homedata=homesData.get(comunityIn).toString()+modelData.get(comunityIn).toString();
//						+commDatas.get(comunityIn).toString();
//				U.log(homedata);
				U.log("=========================================="+ i );
				String homedata = null;
				addDetails(baseJsonurl, jsonData);
				i++;
//				break;
			}
//			}
		}
		private void addDetails(String baseJsonurl, JsonElement jsonData) throws Exception {
			
			String url=jsonData.getAsJsonObject().get("url").toString().replace("\"", "");
			String cUrl = "https://www.legacyhomesal.com"+url;
			U.log(cUrl);
//			if(!cUrl.contains("https://www.legacyhomesal.com/abbington"))return;
			
			String comunityIn = U.getSectionValue(jsonData.toString(), ":", ",");
			U.log("Com Id ::: "+comunityIn);
			
			U.log("==========================================");
			ArrayList<String> homeData1 = (ArrayList<String>) homesData.get(comunityIn);
			String homesecs = ALLOW_BLANK;
			if (homeData1 != null) {
				for (String home : homeData1) {
					homesecs += home;
				}
			}
			String storySec=ALLOW_BLANK;
			ArrayList<String> modelData1 = (ArrayList<String>) modelData.get(comunityIn);
			String modelsecs = ALLOW_BLANK;

			if (modelData1 != null) {
				for (String model : modelData1) {
					modelsecs += model;
				}
				
			
			
			String geo = "False";
			
			JsonParser jparser = new JsonParser();
			JsonArray jobj = (JsonArray) jparser.parse(baseJsonurl).getAsJsonArray();
//			U.log(jsonData);
			String comName=jsonData.getAsJsonObject().get("com_name").toString().replace("\"", "");
			String id=jsonData.getAsJsonObject().get("com_id").toString().replace("\"", "");
			String zip=jsonData.getAsJsonObject().get("com_zip").toString().replace("\"", "");
			String state_code=jsonData.getAsJsonObject().get("state_code").toString().replace("\"", "");
			String street= ALLOW_BLANK;
//			street = jsonData.getAsJsonObject().get("com_street1").toString().replace("\"", "");
			String lat=jsonData.getAsJsonObject().get("com_lat").toString().replace("", "");
			String lng=jsonData.getAsJsonObject().get("com_lng").toString().replace("", "");
//			String gmap_url_address=jsonData.getAsJsonObject().get("ccf_text").toString();
//			U.log(gmap_url_address);
			
			//=====================================================================================================

			U.log(comName+comName);
			U.log("id"+id);
			
			U.log("Street"+street);
			U.log(""+state_code);
			U.log("zip"+zip);
			
			U.log(lat);
			U.log(lng);
			
            String hoData = U.getSectionValue(jsonData.toString(), "com_id", "authDomain");
			String com_priceLow=jsonData.getAsJsonObject().get("com_priceLow").toString().replace(" - N", "");
			String com_priceHigh=jsonData.getAsJsonObject().get("com_priceHigh").toString().replace("", "");
			String com_sqftLow=jsonData.getAsJsonObject().get("com_sqftLow").toString().replace("", "");
			String com_sqftHigh=jsonData.getAsJsonObject().get("com_sqftHigh").toString().replace("", "");
//			String com_description=jsonData.getAsJsonObject().get("com_description").toString().replace(" - N", "");
//			String ccf_text=jsonData.getAsJsonObject().get("ccf_text").toString().replace("\"", "");
			//=========================================Price============================================================
			String[] minmaxPrice = {ALLOW_BLANK ,  ALLOW_BLANK};
//			minmaxPrice[0] = com_priceLow.toString();
//			minmaxPrice[1] = com_priceHigh.toString();
			U.log("priceLow "+minmaxPrice[0]);
			U.log("priceHigh "+minmaxPrice[1]);
//			if(minPrice == "0" ) {
//				minPrice = ALLOW_BLANK;
//			}
//			if(minmaxPrice[1].length() == 1 ) {
//				minmaxPrice[1] = ALLOW_BLANK;
//			}
			if(homesecs.contains("279900")) {
				U.log("com_priceLow\":279900");
//				U.log(U.getSectionValue(homesecs, "inv_price\":", ",\""));
			}
//			U.log(homesecs+modelsecs);
			minmaxPrice = U.getPrices((homesecs+modelsecs+hoData).replace("", ""),
					"\"com_priceLow\":\\d{6},|mod_basePrice\":\\d{6},|inv_price\":\\d{6}|cmod_basePrice\":\\d{6}\\,|\"inv_price\":\\d{6}//,|\"com_priceHigh\":\\d{6}\\,|com_priceLow\":d{6}|\\$\\d{3}|\\$\\d{3},\\d{3}", 0);
			U.log("priceLow "+minmaxPrice[0]);
			U.log("priceHigh "+minmaxPrice[1]);
			
			if(minmaxPrice[0] == null) {
				minmaxPrice[0] = ALLOW_BLANK;
			}
			if(minmaxPrice[1] == null) {
				minmaxPrice[1] = ALLOW_BLANK;
			}
						
			//=========================================Squft============================================================
			String[] minmaxSqFt = { ALLOW_BLANK , ALLOW_BLANK};
			minmaxSqFt[0] = com_sqftLow.toString();
			minmaxSqFt[1] = com_sqftHigh.toString();
			U.log("sqftLow "+minmaxSqFt[0]);
			U.log("sqftHigh "+minmaxSqFt[1]);
//			if(minSqFt == "0" ) {
//				minSqFt = ALLOW_BLANK;
//			}
//			if(maxSqFt == "0" ) {
//				maxSqFt = ALLOW_BLANK;
//			}
//			if(homesecs.contains("com_sqftHigh")) {
//				U.log("com_sqftHigh");
//			}
//			minmaxSqFt = U.getSqareFeet( homesecs+modelsecs+hoData ,
//					"com_sqftLow\"://d{4},|com_sqftHigh\"://d{4},",0);
//			U.log("sqftLow "+minmaxSqFt[0]);
//			U.log("sqftHigh "+minmaxSqFt[1]);
			
			//========================================LatLong=============================================================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			
			latLng[0] = lat;
			latLng[1] = lng;
			
			
			//========================================Address=============================================================

			add[0] = street.toString();
//			add[1] = street;
			add[2] = state_code;
			add[3] = zip;
			String note = ALLOW_BLANK;
			if(add[0]==ALLOW_BLANK&&latLng[0]==ALLOW_BLANK&&add[1]!=ALLOW_BLANK&&add[2]!=ALLOW_BLANK) {
//				latLng=U.getGoogleLatLngWithKey(add);
				add=U.getAddressGoogleApi(latLng);
				geo="True";
				note="Address Taken From Zip And State";
			}
			if(add[0]==ALLOW_BLANK&&latLng[0]!=ALLOW_BLANK) {
				add=U.getAddressGoogleApi(latLng);
				geo="True";
			}
			
			//=====================================================================================================

			
			
			U.log("modelsecs :: "+modelsecs.length());
			U.log("homesecs :: "+homesecs.length());
			//			homeData = homeData.toString();
			String comType = U.getCommunityType(homesecs+modelsecs+hoData);
			U.log("comType=="+comType);
			String propStatus = U.getPropStatus(homesecs+modelsecs+hoData);
			U.log("propStatus=="+propStatus);
            if(homesecs.contains("\"inv_status\":\"Active\"")) {
            	propStatus = propStatus+", Quick Move-In";
			}
            U.log("propStatus2=="+propStatus);
			String propType = U.getPropType(homesecs+modelsecs+hoData);
			U.log("propType=="+propType);
			String dpType = U.getdCommType(homesecs+modelsecs+hoData);
			U.log("dpType=="+dpType);
            
			

			//			
			
			
			//=====================================================================================================
			
				data.addCommunity(comName, cUrl, comType);
				data.addAddress(add[0], add[1], add[2].trim(), add[3]);
				data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
				data.addPrice(minmaxPrice[0], minmaxPrice[1]);
				data.addSquareFeet(minmaxSqFt[0], minmaxSqFt[1]);
				data.addPropertyType(propType, dpType);
				data.addPropertyStatus(propStatus.replace("-, ", ""));
				data.addNotes(note);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);
			}
				
		}
		
	}
