/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMcKeeHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	WebDriver driver=null;

	private static final String BUILDER_URL = "https://www.mckeehomesnc.com";
	CommunityLogger LOGGER;
	//WebDriver driver = new FirefoxDriver();
	public ExtractMcKeeHomes() throws Exception {
		super("McKee Homes","https://www.mckeehomesnc.com");
		LOGGER=new CommunityLogger("McKee Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractMcKeeHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McKee Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {

		U.setUpChromePath();
		driver = new ChromeDriver();
		String mainHtml=U.getHTML("https://www.mckeehomesnc.com");
		//String regSec = U.getSectionValue(mainHtml, "Find Your Home</a>", "Design Your Home</a>");
		String regSec = U.getSectionValue(mainHtml, "Find Your Home</h4>", "Design Your Home</h4>");
	//	String[] regVal=U.getValues(regSec, "<a class=\"dropdown-item\" href=\"", "\"");//U.getValues(mainHtml, "<area shape=\"rect\" href=\"","\"");
		String[] regVal=U.getValues(regSec, "<li><a href=\"", "\"");
		for(String reg:regVal)
		{
		//	U.log(reg);
			U.log("https://www.mckeehomesnc.com"+reg);
			String regHtml=U.getHTML("https://www.mckeehomesnc.com"+reg);
//			
		//	String[] comSec=U.getValues(regHtml, "<div class=\"card card-horizontal","</p></div></div></div></div>");
			String[] comSec=U.getValues(regHtml, "<div class=\"card card-horizontal oi-map-item mb-3\"","View Details</a>");
			U.log("total"+comSec.length);
			for(String comData:comSec)
			{
				//U.log("ComDatra"+comData);
				String comUrl="https://www.mckeehomesnc.com"+U.getSectionValue(comData, "href=\"","\"");
				U.log("Url::"+comUrl);
				if(comUrl.contains("floorplans/"))
					continue;
				String html=U.getHTML(comUrl);
				html = U.removeComments(html);
				addDetails(html, comUrl, comData);
//				String subCommunitySection = U.getSectionValue(html, "id=\"community-subs\">", "<section id=\"footer");
//				if(subCommunitySection != null){
//					String subCommunityUrls [] = U.getValues(subCommunitySection, " <div class=\"sub-photo\">", "View Details ");
//					LOGGER.AddSubRegion(comUrl, subCommunityUrls.length);
//					
//					for(String suComUrl : subCommunityUrls){
//						String suburl= U.getSectionValue(suComUrl, "<a href=\"", "\"");
//						if(!suburl.startsWith("http")) suburl = BUILDER_URL+ suburl;
//						//U.log("subUrl :"+suComUrl);
//						
//						String subHtml = U.getHTML(suburl);
//						addDetails(subHtml, suburl,suComUrl);
//					}
//				}else{
////					addDetails(html, comUrl,comData);
//				}
			}
			//U.log(comSec.length);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String html, String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.mckeehomesnc.com/new-homes/nc/aberdeen/aberdeen-grande/8777"))return;
//		try{
	{
		U.log(j+"   commUrl-->"+comUrl);

		if(data.communityUrlExists(comUrl)) {
			
			LOGGER.AddCommunityUrl(comUrl+"==============Repeated============");
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		html = U.removeComments(html);

//============================================Community name=======================================================================
		String communityName=U.getSectionValue(html, "<h1 class=\"p-0 m-0 hero-detail-title text-uppercase text-white\">","<");
		communityName=communityName.replace("Plantation Pointe at ", "");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
	
		String addSec=U.getSectionValue(html, "Sales Office:</span><p class=\"mb-0\">","<a class=\"");
		if(addSec==null|| addSec.contains("</div>"))addSec=U.getSectionValue(html, "Sales Office:</span><p class=\"mb-0\">","</p></div></div>");
        if(addSec==null)
        	addSec=U.getSectionValue(html, ">Sales Office: </span>", "<a class=\"oi-click-to-call d-block\"");
        if(addSec==null || addSec.trim().length()<1) {
        	addSec= U.getSectionValue(html, "<span class=\"sales-hours-title text-uppercase d-block\">", "<a class=\"oi-click-to-call d-block");
        	if(addSec!=null)
        	addSec = U.getSectionValue(addSec,"target=\"_blank\">","</a");
        }
        U.log(addSec);
		if(addSec!=null){
			addSec=addSec.replaceAll("<br />|<br/>",",").trim();
			add=U.findAddress(addSec);
			if(add==null)add= U.getAddress(addSec);
			U.log(Arrays.toString(add));
		}
		else {
			addSec = U.getSectionValue(html,"Sales Office:","</p><p");
			if(addSec!=null){
				addSec = U.getSectionValue(html,"target=\"_blank\">","</a>");
				if(addSec!=null) {
				addSec=addSec.replace("<br/>", ", ");
				add=U.getAddress(addSec);
				}
				
			}
			 U.log("addSec=="+addSec);
		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
		String latSec=null;//please check latlong present or not in page
	//	latSec=U.getSectionValue(html, " oi-directions-click\" href=\"https://maps.google.com/maps?q=","\"");
		latSec=U.getSectionValue(html, "href=\"https://maps.google.com/maps?q=", "\"");
		U.log("latSec : "+latSec);
		if(latSec!=null) {
			latlag[0]=Util.match(latSec, "\\d{2,3}.\\d{4,}");
			latlag[1]=Util.match(latSec, "-\\d{2,3}.\\d{4,}");
		}
		
	if(add[1].length()>4 && latlag[0].length()<4){
			//try{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getGoogleLatLngWithKey(add);
			geo="TRUE";
	}
	//------------latlng from map iframe url sources-------
	if(add[0].length()<4 && latlag[0].length()<4){
		U.log("::::::::::::::::");
			latSec = U.getSectionValue(html, "\"googlemap\">", "</iframe>");
			if(latSec != null){
			String iframeHtml = U.getHTML(U.getSectionValue(latSec, "src=\"", "\""));
			U.log("iframe : "+U.getSectionValue(latSec, "src=\"", "\""));
			latSec = U.getSectionValue(iframeHtml, "https://mt.googleapis.com", "\\n,[0,0]");
			if(latSec != null){
					latSec = Util.match(latSec, "\\d{2,}\\.\\d{3,},-\\d{2,}\\.\\d{3,}");	
			}
			if(latSec!=null){
					latlag=latSec.split(",");
					add = U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
			}
		}
	}
		
		if((add[0]==ALLOW_BLANK || add[3]==null || add[3]==ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK){
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		
		add[0]=add[0].replace("Foxcroft Road, at Michael Road", "Foxcroft Road At Michael Road").replaceAll(",|/|at Elliot Bridge Rd|at Purfoy Rd", "");
		
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		
		
		boolean notFoundQuickMove = false; // set flag is quick move in section is removed
		//@ 1 March 2021
		//This section is used to check if page is showing quick move in section, if it is not then it will removed the section of quick homes.
		String tabSection = U.getSectionValue(html, "nav nav-pills nav-stacked\">", "</div>");
		U.log("tabSec :"+tabSection);
		if(tabSection != null && !tabSection.contains("href=\"#community-homes\">Quick Move-In Homes</a>")){
			String remQuickSec = U.getSectionValue(html, "id=\"community-homes\">", "<div role=\"tabpanel\"");
			if(remQuickSec != null){
				html = html.replace(remQuickSec, "");
				notFoundQuickMove = true;
			}
		}
		
//============================================Price and SQ.FT======================================================================
		
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html = html.replaceAll("\\$300’s\\.\\s*\">", "").replace("high 100's", "high $100's");
		html=html.replaceAll("00’s|00's", "00,000");

		html=html.replaceAll("0s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
		comData=comData.replaceAll("0&#8217;s|0s|0's|0s","0,000");
		String prices[] = U.getPrices(html+comData,"From the \\$\\d{3},\\d{3}|homes starting from the \\$\\d+,\\d+|Price:</strong> \\$\\d{3},\\d+|the low \\d{3},\\d+|low \\$\\d{3},\\d+|mid \\$\\d{3},\\d+|high \\$\\d{3},\\d+|Base Price: <span class=\"bold\">\\$\\d{3},\\d{3}|<div class=\"price\">\\$\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
	//	U.log("thids is comdata"+comData);
//======================================================Sq.ft===========================================================================================		
		String[] sqft = U.getSqareFeet(html.replace(".", ",")+comData,
						"\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d,\\d+-\\d,\\d+</span> sq ft</li>|\\d,\\d{3} to \\d,\\d{3}</strong> sq ft|\\d{4} to \\d{4}</span> sq ft|\\d,\\d{3}-\\d,\\d{3}</strong> sq ft|\\d{4}-\\d{4}</span> sq ft|\\d,\\d{3}-\\d,\\d{3}</span> sq ft|SQFT</div>\\d{4}|\\d{4}</span> base sq ft|<span>\\d{4}|<span>\\d,\\d{3}",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
	
//============remove footer==============
		String remFooter=U.getSectionValue(html, "<footer>", "</footer>");
		if(remFooter!=null){
			html=html.replace(remFooter, "");
			U.log("remove footer");
		}
		//removed head tag
		remFooter=U.getSectionValue(html, "<head>", "</head>");
		if(remFooter!=null)html=html.replace(remFooter, "");
//============common navigation bar data============
		String remNav=U.getSectionValue(html, "\"dropdown\">Find Your Home<", "Privacy Policy</a></li> </ul></li>");
		if(remNav!=null){
			html=html.replace(remNav, "");
			U.log("remove dropdown");
		}
		

		
//===========fetch individual plan data of Available Homes =================
		String allPlanData=ALLOW_BLANK,planHtml=ALLOW_BLANK;
		String[] planUrls = U.getValues(html, "<div class=\"card oi-map-item ", "<div class=\"card-body\">");
		int tmpcnt =0;
		U.log("Total available homes(planUrls.length) ::::::: "+planUrls.length);
		int quickCount = 0;
		for(String planUrl : planUrls ){
			String Url = U.getSectionValue(planUrl, "href=\"", "\"");
			if(Url.contains("/toggle")) {
				Url = U.getSectionValue(planUrl, "<a class=\"card-thumb\" href=\"", "\"");
			if(Url==null) {
			String urlSec=U.getSectionValue(planUrl, "<div class=\"oi-aspect four-three\">","class=\"card-thumb\">");
			Url=U.getSectionValue(urlSec, "<a href=\"", "\"");
			}
		}
		
			planUrl="https://www.mckeehomesnc.com"+Url;
			U.log("planUrl:::"+planUrl);
			planHtml = U.getHTML(planUrl);
			
			if(planHtml!=null)
			allPlanData += U.getSectionValue(planHtml, "<h1 class=\"p-0 m-0 hero-detail-title", "</section>");
		}
//===========fetch individual plan data of Available Floorplans =================
		String combinedFloorplanHtml =  ALLOW_BLANK;
//		String floorplanSec = U.getSectionValue(html, "<div class=\"card plan-card w-100 oi-map-", "View Details</a>");
		String floorPlanData=ALLOW_BLANK, floorplanHtml=ALLOW_BLANK;
//		if(floorplanSec != null){
			String[] floorplanUrls = U.getValues(html,"<div class=\"card plan-card w-100 oi-map-", "View Details</a>");
			int floorplancnt =0;
			U.log("Total floorplans ::::::: "+floorplanUrls.length);
			for(String floorplanUrl : floorplanUrls ){
				floorplanUrl = U.getSectionValue(floorplanUrl, "href=\"", "\"");
				floorplanUrl="https://www.mckeehomesnc.com"+floorplanUrl;
				U.log("floorplanUrl:::"+floorplanUrl);
				floorplanHtml = U.getHTML(floorplanUrl);
				combinedFloorplanHtml += U.getSectionValue(floorplanHtml, "<h1 class=\"p-0 m-0 hero-detail-title", "</section>");
			}
//		}
		
//================================================community type========================================================
		html=html.replaceAll("resort-style pool and pool house|Golf Communities|high ridge 55\\+ community|mckee homes active adult", "");
		String communityType=U.getCommType(html+comData);
		
//==========================================================Property Type================================================
		html = html.replaceAll("Craftsman elevation| a cozy cottage appearance|coastal living|Craftsman Collection elevations|alt=\"Courtyards|epcon floorplans, coastal living, north carolina coastal new homes|<h3><p>Craftsman Collect", "");
		allPlanData = allPlanData.replace("Craftsman<br />", "Craftsman-Style Homes<br />").replaceAll("Craftsman elevation|coastal living| a cozy cottage appearance|_craftsman|Clark Craftsman|craft room|Floor Plan:</strong>.* Craftsman</li>", "");
		if(combinedFloorplanHtml!=null)combinedFloorplanHtml=combinedFloorplanHtml.replaceAll("cozy cottage appearance", "");
//		U.log("KKKKKKKKKK"+Util.matchAll(comData+allPlanData+combinedFloorplanHtml, "[\\s\\w\\W]{30}flex[\\s\\w\\W]{30}", 0));
		//String proptype=U.getPropType(U.getHTML(comUrl).replace("coastal living", "")+comData+allPlanData+combinedFloorplanHtml); 
		String proptype=U.getPropType(html+comData+allPlanData+combinedFloorplanHtml).replace("den/flex room", "Flex Room").replace("Promenade 2020 Craftsman floor plan with", "Promenade 2020 Craftsman Style with");
		
		if(proptype.contains("Townhomes") && proptype.contains("Townhouse"))
			proptype = proptype.replaceAll(",Townhouse", "");
//		U.log("KKKKKKKKKK"+Util.matchAll(U.getHTML(comUrl)+comData+allPlanData+combinedFloorplanHtml
//				, "[\\s\\w\\W]{30}craftsman[\\s\\w\\W]{30}", 0));
		//U.log(allPlanData);
//==================================================D-Property Type======================================================
		html=html.replaceAll("building single-story...</p>|/single-story-homes\">|Single Story Homes</a></li>", "");
		allPlanData=allPlanData.replaceAll("Large open ranch floor plan|McKee Homes is building single-story", "");
		allPlanData=allPlanData.replace("Stories:</strong> 3", "3 story").replace("Stories:</strong> 2", "2nd story").replace("Stories:</strong>", "Stories: ");
		if(combinedFloorplanHtml!=null)combinedFloorplanHtml=combinedFloorplanHtml
				.replace("first-floor owner’s suite", "first Story owner’s suite").replace("second floor boasts two additional bedrooms", "second Story boasts two additional bedrooms")
				.replaceAll("third floor|Finished Third Floor", "");
		String dtype=U.getdCommType((html+comData+allPlanData+combinedFloorplanHtml).replaceAll("Floor|floor", "")).replace("Timberland Ranch", "Timberland");
//==============================================Property Status=========================================================
		html = html.replaceAll("Move-In Ready!|Move-In Ready|MOVE-IN READY|move-in homes. Signup|scheduled to open fall 2019<br />|alt=\"Enclave at Legacy Lakes now open\" |New phase opened in 201|4>New Phase Coming Soon! Signup to receive e|Coming soon to the Cottages|but lots are selling quickly.|Ready Homes|tab to see move-in|fitness area coming soon|>Quick Move-In Homes</a></li>", "").replace("Now selling in the new phase", "Now selling new phase");
				html=html.replaceAll("Mallory Retreat is a new phase", "")
						.replace("New phase and model now open", "New phase now open")
						.replaceAll("Current Phase Sold Out|<div class=\"col-sm-12\">coming soon</div>|MLS#: Coming Soon|coming soon\"|currently sold out. Next phase coming Spring 2019|is sold out as of|model home coming", "");
		String pstatus=U.getPropStatus(html+comData);
		U.log("property Status"+pstatus);
//============================================note====================================================================
//		U.log("result:::::::::::::"+Util.match(html+comData, ".*?move-in.*?"));
		if(html.contains("MLS#:") && !pstatus.contains("Quick")) {
			String quickUrlSection[] = U.getValues(html, "<div class=\"home-photo\"><a href=\"", "<div class=\"floorplan\">");
			int soldCount = 0;
			for(String quickUrlSec : quickUrlSection){
				if(quickUrlSec.contains(">sold</div>"))soldCount++;
			}
//			ArrayList<String> list=Util.matchAll(html, "MLS#:", 0);
			//Quick Move Not Found
			U.log("notFoundQuickMove ::"+notFoundQuickMove);
//			if(!notFoundQuickMove){
				
//			}
		}
		
		
		if(comUrl.contains("https://www.mckeehomesnc.com/new-homes/nc/lillington/oakmont/8747/"))proptype=proptype.replace("Single Family, ", "");//present in pagesource bt not on webpage 
		if(comUrl.contains("/find-a-home/fayetteville/fairfield-farms"))pstatus=pstatus.length()>2?pstatus+", New Phase Coming Soon":"New Phase Coming Soon";//image
		if(comUrl.contains("/raleigh/summerwind-plantation"))pstatus=pstatus.length()>2?pstatus+", New Phase Now Selling":"New Phase Now Selling";//image
		//status from image
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/wilmington/winds-harbor")||
				comUrl.contains("https://www.mckeehomesnc.com/find-a-home/fayetteville/river-glen")||
				comUrl.contains("https://www.mckeehomesnc.com/find-a-home/pinehurst/cabin-branch")||comUrl.contains("https://www.mckeehomesnc.com/find-a-home/pinehurst/sinclair")||
				comUrl.contains("https://www.mckeehomesnc.com/find-a-home/pinehurst/foxcroft"))pstatus= pstatus+", Final Opportunities";
		
		
		if(comUrl.contains("/find-a-home/raleigh/gateway-commons")|| comUrl.contains("/find-a-home/raleigh/highridge")|| comUrl.contains("/find-a-home/pinehurst/aberdeen-grande"))pstatus="Coming Soon";//Img
		pstatus=pstatus.replaceAll("\\d+ Quick Move-in Home(s)?", "Quick Move In Homes");
		//if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/raleigh/johns-pointe"))pstatus="New Phase Coming 2020";//Img
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/fayetteville/braxton-village")
				|| comUrl.contains("https://www.mckeehomesnc.com/find-a-home/raleigh/heather-glen"))pstatus=pstatus+", Final Opportunities";//Img				
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/wilmington/courtyards-at-scotts-hill-village")) pstatus="Coming Soon";//Img		
		if(comUrl.contains("/find-a-home/pinehurst/legacy-lakes"))pstatus ="New Phase Now Selling";
		
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/fayetteville/oakmont"))pstatus = "New Phase Coming Soon, New Phase Opening Soon";//Img
		

		//From Image
				
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/pinehurst/sandy-springs"))
			pstatus= getProperImageStatus(pstatus, "New Phase Coming Soon");
		
		if(	comUrl.contains("find-a-home/pinehurst/mid-south-club"))pstatus= getProperImageStatus(pstatus, "New Phase Coming 2022");
		
			/*
			 * if(html.
			 * contains(" Limited Release Opportunities\" class=\"img-responsive\" />"))
			 * pstatus = getProperImageStatus(pstatus, "Limited Release Opportunities");
			 */
		if(html.contains(" coming soon\" class=\"img-responsive\" />"))
			pstatus = getProperImageStatus(pstatus, "Coming Soon");
		
		if(comUrl.contains("/find-a-home/raleigh/copper-pond") 
				|| comUrl.contains("/fayetteville/anderson-creek-club"))pstatus= getProperImageStatus(pstatus, "Final Opportunities");

		
//		pstatus = pstatus.replace("Final Opportunity", "Final Opportunities");
		note = U.getnote(html.replaceAll("pre-sale homes.<br>A pre-sale|otified when lots and presales ", ""));
//		note = note.replace("Presale", "");
		//if(comUrl.contains("https://www.mckeehomesnc.com/new-homes/nc/bolivia/new-south-bridge/8792/"))pstatus="Quick Move-in";
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/wilmington/the-courtyards-at-scotts-hill-village"))pstatus= getProperImageStatus(pstatus, "Final Opportunities");
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/raleigh/summerwind")) pstatus = "Final Opportunity, Sold Out, "+pstatus;
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/pinehurst/sandy-springs"))pstatus = "New Phase Coming 2022, "+pstatus;
		if(comUrl.contains("bedford/midlands-at-bedford")|| comUrl.contains("bedford/highlands-at-bedford"))pstatus= getProperImageStatus(pstatus, "Limited Release Opportunities");
		if(comUrl.contains("/wilmington/colbert-place")||comUrl.contains("/raleigh/high-ridge"))pstatus="Coming Soon";
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/pinehurst/the-brownstones-on-bennett"))pstatus="Final Opportunities";
		if(comUrl.contains("https://www.mckeehomesnc.com/find-a-home/raleigh/highridge")) dtype = "1 Story"; // from image
		if(comUrl.contains("https://www.mckeehomesnc.com/new-homes/nc/wilmington/the-courtyards-at-scotts-hill-village/8795/"))
			proptype+=", Cottage";
		if(note.length()<3)
			note = ALLOW_BLANK;
		//formatting status
		pstatus = pstatus.replace("New Phase Coming 2022, Coming 2022", "New Phase Coming 2022")
				.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		if(add[0].length()>3)
			add[0] = add[0].replaceAll("Colbert Place Drive at|, NC \\d+", "");
		add[1]=add[1].replace("Fuquay-Varina", "Fuquay Varina");
		
		add[0]=add[0].replace("NC HWY 211Calloway Road","Nc Hwy 211 Calloway Road");
		
		
		if(planUrls.length > 0 && !pstatus.contains("Quick")){
			if(pstatus.length()<4)pstatus="Quick Move In Homes";
			else pstatus=pstatus+", Quick Move In Homes";
		}//**date jan2022
		String updatedName = "";
		if(comUrl.contains("communities/chesterfield/harpers-mill-glen-royal#detail")) {
			updatedName ="Harpers Mill";
		}else {
			updatedName = communityName;
		}
		U.log(updatedName);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(planData, "[\\s\\w\\W]{30}Presale[\\s\\w\\W]{30}", 0));		
//		String lotMapData = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetSiteplan\",\"variables\":{\"clientName\":\"mckee\",\"communityName\":\""+updatedName.trim()+"\"},\"query\":\"query GetSiteplan($clientName: String!, $communityName: String!, $siteplanName: String) {\\n  siteplan(clientName: $clientName, communityName: $communityName, siteplanName: $siteplanName, active: true) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    unreleasedLotsHandle\\n    showUnreleasedLotNumber\\n    ...SiteplanSVGFields\\n    geoInfo(clientName: $clientName) {\\n      id\\n      siteplanId\\n      neLatitude\\n      neLongitude\\n      swLatitude\\n      swLongitude\\n      geoJson\\n      __typename\\n    }\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    hotspots {\\n      id\\n      siteplanId\\n      name\\n      x\\n      y\\n      width\\n      height\\n      description\\n      thumb\\n      assets {\\n        id\\n        listIndex\\n        src\\n        videoUrl\\n        description\\n        __typename\\n      }\\n      __typename\\n    }\\n    lots(clientName: $clientName) {\\n      ...LotFields\\n      geoJson\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      excludedPlanElevations(clientName: $clientName) {\\n        planId\\n        elevationId\\n        planName\\n        planDisplayName\\n        elevationCaption\\n        __typename\\n      }\\n      inventory(clientName: $clientName) {\\n        ...InventoryFields\\n        photos(clientName: $clientName) {\\n          id\\n          src\\n          listIndex\\n          __typename\\n        }\\n        plan(clientName: $clientName) {\\n          ...PlanFields\\n          __typename\\n        }\\n        elevation(clientName: $clientName) {\\n          ...ElevationFields\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment PlanFields on Plan {\\n  id\\n  displayName\\n  name\\n  communityId\\n  defaultElevationId\\n  description\\n  bed\\n  bath\\n  cost\\n  size\\n  videoUrl\\n  interactiveInteriorIds(clientName: $clientName)\\n  bedRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  bathRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  costRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  sizeRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment ElevationFields on Elevation {\\n  id\\n  mirrorElevationId\\n  mirrorRolePrimary\\n  communityId\\n  planName\\n  planDisplayName\\n  planId\\n  caption\\n  thumb\\n  bed\\n  bath\\n  size\\n  cost\\n  defaultFloor\\n  description\\n  svgMirroring\\n  garagePosition\\n  defaultGaragePosition\\n  bedRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  bathRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  costRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  sizeRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  tags(clientName: $clientName) {\\n    categoryName\\n    tagName\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment LotFields on Lot {\\n  id\\n  communityId\\n  dataName\\n  name\\n  salesStatus\\n  premium\\n  externalId\\n  address\\n  size\\n  cityName\\n  stateCode\\n  zip\\n  postCode\\n  geoJson\\n  availableSchemes(clientName: $clientName) {\\n    id\\n    name\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment InventoryFields on Inventory {\\n  id\\n  lotId\\n  planId\\n  elevationId\\n  communityId\\n  price\\n  sqft\\n  beds\\n  baths\\n  features\\n  constructionStatus\\n  closingDate\\n  mlsId\\n  garageType\\n  garageCapacity\\n  floors\\n  schemeId\\n  photoFolder\\n  plan(clientName: $clientName) {\\n    id\\n    communityId\\n    name\\n    displayName\\n    __typename\\n  }\\n  sgtData(clientName: $clientName) {\\n    id\\n    sgtVendorId\\n    sgtExternalId\\n    sgtData\\n    __typename\\n  }\\n  appointmentsEnabled\\n  reserveHomeUrl\\n  garagePosition\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
//		U.log(lotMapData);
//		JsonParser parser = new JsonParser();
		String lotIds=ALLOW_BLANK;
//		if(!lotMapData.contains("INTERNAL_SERVER_ERROR") && !lotMapData.contains("\"siteplan\":null")){
//			JsonObject jobj = (JsonObject)parser.parse(lotMapData);
//			lotIds = jobj.get("data").getAsJsonObject().get("siteplan").getAsJsonObject().get("lots").getAsJsonArray().size()+"";
//			U.log(lotIds);
//		}
		
		
		String mapLink=U.getSectionValue(html, "<iframe allowfullscreen=\"\" class=\"embed-responsive-item\" src=\"", "\">");
		U.log("mapLink==="+mapLink);
		if(mapLink!=null) {
			String mapHtml=U.getHtml(mapLink, driver);
			if(mapHtml!=null) {
				lotIds=Util.getUnitsByMatch(mapHtml);
			}
		}
		
		
		if(lotIds.equals("0") || lotIds.length()<1)lotIds=ALLOW_BLANK; 	
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(U.getCapitalise(add[0].toLowerCase()).trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		
	}
		j++;
//		}catch(Exception e){}
	}
	
	public static String getProperImageStatus(String propStatus, String imgStatus){
		if(propStatus.length() < 4) propStatus = imgStatus;
		else if(propStatus.length() > 4 && !propStatus.contains(imgStatus)) propStatus = propStatus +", "+imgStatus;

		return propStatus;
	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1MDY5MTM2OCwiZXhwIjoxNjUwNzM0NTY4fQ.oNHxUfohb6XpNS5gyoiujEGrcL8rmuRPYHhdmhpHYLs");
//	        connection.setRequestProperty("Content-Length", "1824");
	        connection.setRequestProperty("Content-Type", "application/json");
	        connection.setRequestProperty("Origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("Referer", "https://myhome.anewgo.com/");
//	        connection.setRequestProperty("Sec-Fetch-Dest", "empty");
//	        connection.setRequestProperty("Sec-Fetch-Mode", "cors");
//	        connection.setRequestProperty("Sec-Fetch-Site", "same-site");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");

	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

}