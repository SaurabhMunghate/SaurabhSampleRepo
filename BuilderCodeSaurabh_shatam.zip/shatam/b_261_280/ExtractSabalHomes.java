/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * @modify : Sawan
 * @date : 06/11/2017
 */
package com.shatam.b_261_280;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSabalHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public ExtractSabalHomes()throws Exception {
		super("Sabal Homes","https://www.sabalhomessc.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Sabal Homes");
	}
 
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a=new ExtractSabalHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Sabal Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String mainHtml=U.getHTML("https://www.sabalhomessc.com/our-homes/regions/");
		String section=U.getSectionValue(mainHtml, "class=\"communities-area-list light-gray\">","</section>");
		//U.log(section);
		String[] comSec=U.getValues(section, "<a","</a>");
		String latLngSection = U.getSectionValue(mainHtml, "var points =", "</script>");
		U.log(comSec.length);
		for(String comData:comSec)
		{
		//U.log(comData);	
		String comUrl=U.getSectionValue(comData,"href=\"","\">");
		//U.log(comUrl);
		addDetails(comUrl,comData,latLngSection);
		}
		addDetails("https://www.sabalhomessc.com/charleston/johnston-pointe-phase-ii-johns-island-sc/","", latLngSection);
		driver.close();
		try{driver.quit();}catch(Exception e) {}
		LOGGER.DisposeLogger();
	}


	private void addDetails(String comUrl, String comData, String latLngSection) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.sabalhomessc.com/myrtle-beach/carolina-courtyards-at-longwood-bluffs-murrells-inlet-sc/"))return;
	//if(j == 10)	
	{	
		if(comUrl.contains("https://www.sabalhomessc.com/charleston/johnston-pointe-phase-ii-johns-island-sc/"))return;
		U.log(j+"   commUrl-->"+comUrl);
		String html=ALLOW_BLANK;
		html= getHtml(comUrl,driver);
		String rmSec=U.getSectionValue(html, "<div class=\"review-menublock\">", "</footer>");
		if(rmSec!=null)html=html.replace(rmSec, "");
		U.log(comData);
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "community-name\">","<");
		if(communityName==null){
			communityName=U.getSectionValue(html, "<title>", "|");
		}
		communityName=communityName.replaceAll("&#039;|Phase II| in James Island, SC", "");
		U.log("community Name---->"+communityName);
	
//================================================Address section===================================================================
	
		String note=U.getnote(html);
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
	
		String addSec=U.getSectionValue(html, "https://maps.google.com?daddr=","\"");
		
		U.log("ffffff"+addSec);
		if(addSec!=null)
		{
			addSec=addSec.replace("+"," ").replace("%2C",",")
					.replace("Rd Simpsonville", "Rd, Simpsonville").replace("Coming Soon%21", ",")
					.replace("Street Greer", "Street, Greer").replace("Avenue Greer", "Avenue, Greer").replace("Summerville",", Summerville")
					.replace(" Johns Island",", Johns Island")
					.replace("Lane Moncks Corner", "Lane, Moncks Corner")
					.replace("Road Simpsonville", "Road, Simpsonville").replace("Rd Greer", "Rd, Greer")
					.replaceAll("Call to schedule a private tour.", "").replace("Drive Murrells Inlet", "Drive, Murrells Inlet")
					.replace("%E2%80%99", "'");
			addSec  =U.formatAddress(addSec);
			U.log("New addsec ::::::::: "+addSec+"==");
			
			String[] add1=addSec.split(",");
		
			if(add1.length>2)
			 {
				 add[0]=add1[0];
				 add[1]=add1[1];
				 add[3]=Util.match(add1[2],"\\d{4,}");
				 if(add[3]!=null)
				 {
				 add[2]=add1[2].replace(add[3],"").trim();
				 }
				 else
				 {
					 add[2]=add1[2];
				 }
			 }
		}
		if(addSec == null)
		addSec=U.getSectionValue(html, "Model Home Info:</h4><p> <span>","</span>");
		if(addSec != null){
			addSec =  addSec.replaceAll("Models Opening Fall 2017|Call for more information|<h4>Model Home Info</h4>|Call to schedule a private tour.|Model Coming Soon!", "").replace("<br>", ",").replaceAll("6101 Chadderton Circle Myrtle Beach", "6101 Chadderton Circle,Myrtle Beach");
			U.log(addSec);
			add = U.getAddress(addSec);
			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				String vals [] = addSec.split(",");
				U.log(vals.length);
				if(vals.length == 2){
					Matcher mat = Pattern.compile("\\d{5}$",Pattern.CASE_INSENSITIVE).matcher(vals[1].trim());
					if(mat.find()){
	//					U.log("FOoooooooooo");
						add[2] = vals[1].trim().split(" ")[0];
						add[3] = vals[1].trim().split(" ")[1];
					}
					add[1] = vals[0].trim();
				}
			}
		}
	
		U.log("Address1---->"+add[0]+", "+add[1]+", "+add[2]+", "+add[3]);
	
	
//--------------------------------------------------latlng----------------------------------------------------------------
		U.log(latLngSection);

		String [] latlngSec = U.getValues(latLngSection, "\"name\":", "}");
		for(String latLngSec : latlngSec){
			if(latLngSec.contains(communityName)){
				U.log("RegPgae::::"+latLngSec);
				latlag[0]=U.getSectionValue(latLngSec, "lat\":\"","\"");
				latlag[1]=U.getSectionValue(latLngSec.replace("-82.2807733,17", "-82.2807733"), "lon\":\"","\"");
					
				if(latlag[0] == null){
					latlag[0] = ALLOW_BLANK;
					latlag[1] =  ALLOW_BLANK;
				}
			}
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			try{
				latlag=U.getlatlongGoogleApi(add);
			}catch(Exception e){
				latlag = U.getBingLatLong(add);
			}
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]!=ALLOW_BLANK) && latlag[0]==ALLOW_BLANK)
		{
			latlag = U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		}
		
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
	
//============================================Price and SQ.FT======================================================================
		//--------------All homes data of feature home page--------------
		String combinedQuickHtml = null;
		String[] quickUrls = U.getValues(html, "<div class=\"floorplan-title\">", "class=\""); 
		U.log("Quick Count=="+quickUrls.length);
		for(String quickUrl : quickUrls){
//			U.log(homeUrl);
			quickUrl = U.getSectionValue(quickUrl, "href=\"", "\"");
			U.log("quickUrl:: "+quickUrl);
			if(quickUrl != null){
				String homeHtml = U.getHTML(quickUrl);
				combinedQuickHtml += U.getSectionValue(homeHtml, "<h2 class=\"this-page-title\">", "class=section-pa");
			}
		}
		//U.log(combinedQuickHtml);
	//============= floor Html ================
		U.log("floorUrl::"+comUrl+"?filter_by=dyh");
		String floorHtml = U.getHTML(comUrl+"?filter_by=dyh") + U.getHTML(comUrl+"?filter_by=dyh&pg=2");
		String combinedFloorHtml = null;
		if(floorHtml != null){
			String[] flooromeSec = U.getValues(floorHtml, "class=\"floorplan-title\">", "</a>");
			U.log("floor count=="+flooromeSec.length);
			for(String floorHome : flooromeSec){
				String floorUrl = U.getSectionValue(floorHome, "<a href=\"", "\"");
				U.log("floorUrl::"+floorUrl);
				try{String floorHomeHtml = U.getHTML(floorUrl);
				combinedFloorHtml += U.getSectionValue(floorHomeHtml, "<h2 class=\"this-page-title\">", "<section class=");
				}catch(Exception e){}
			}
		}
//	U.log(combinedFloorHtml);
	//--------------Price-------------
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replaceAll("original_price\">\\$\\d{3},\\d{3}", "");
		html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
		if(floorHtml != null)
		{
			floorHtml=floorHtml.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
			floorHtml = floorHtml.replaceAll("original_price\">\\$\\d{3},\\d{3}", "");
		}
		if(combinedFloorHtml!=null)
		{
			combinedFloorHtml=combinedFloorHtml.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000");
			combinedFloorHtml = combinedFloorHtml.replaceAll("original_price\"><h4>\\$\\d{3},\\d{3}", "");
		}
		comData=comData.replaceAll("0&#8217;s|0�s|0's|0s","0,000");
		//U.log(U.getSectionValue(combinedFloorHtml, "08 Ashby Street", "$429,900"));
		String prices[] = U.getPrices(html+comData+floorHtml+combinedFloorHtml,
				"sale_price\">(<h4>)?\\$\\d{3},\\d{3}|class=\"stat_row\">\\s+<h4>\\$\\d{3},\\d{3}|border\">\\s+\\$\\d{3},\\d{3}|<h4>\\$\\d{3},\\d{3}|<div class=\"spec-col\">\\s+\\$\\d+,\\d+|mid \\d+,\\d+|Mid \\$\\d+,\\d+|the \\$\\d+,\\d+|Price: \\$\\d+,\\d+|Low \\$\\d+,\\d+|the \\d{3},\\d{3}|high \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
	
//======================================================Sq.ft===========================================================================================
//		U.log(combinedQuickHtml);
		//U.log("floorHtml:::::::::"+floorHtml);
		String[] sqft = U
				.getSqareFeet(
						html+comData+floorHtml+combinedQuickHtml,
						" size from \\d{4} to \\d{4} square feet, three to|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|starting at \\d,\\d{3} square feet|\\d{4} <small>Sq. Ft|\\d{4} Sq. Ft.|\\d{1},\\d+ - \\d{1},\\d+ sq ft|ranging from \\d{1},\\d+ to \\d{1},\\d+|\\d{4} sq ft|\\d{1},\\d+ sq ft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
	
//================================================community type========================================================
		html=html.replace(" golf,", "golf course").replaceAll(" elongated water save|Elongated water saver|Elongated|irrigated", "");
		String communityType=U.getCommType(html+comData);
	
//==========================================================Property Type================================================
		String headersec=U.getSectionValue(html, "<header", "</header>");
		html=html.replace(headersec, "");
		String proptype=U.getPropType((html+comData+combinedQuickHtml+combinedFloorHtml).replaceAll("Craftsman Trim upgrade|Craftsman Style Trim", "").replace("Craftsman Trim Package", "").replace("craftsman trim", "").replace("Craftsman Trim", "").replace("Craftsman trim", "").replace("/Cottage-", ""));
		//U.log("MMMMMMMMM "+Util.matchAll((html+comData+combinedQuickHtml+combinedFloorHtml).replace("Craftsman Trim Package", "").replace("craftsman trim", "").replace("Craftsman Trim", "").replace("Craftsman trim", ""), "[\\s\\w\\W]{30}Craftsman[\\s\\w\\W]{30}", 0));
//==================================================D-Property Type======================================================
		html=html.replace("Stories <span class=\"value\">", "Story ");
		String dtype=U.getdCommType((html+comData+floorHtml+combinedFloorHtml).replaceAll("floor|Floor", ""));
	
//==============================================Property Status=========================================================
		html=html.replaceAll(" Pool coming 2019|value=\"Move-in Ready\"|Move-in Quick</label>|Move in Ready Homes Available!</strong></p>|value=\"Move-in Ready\" > <label for=\"status_sort_move_in_ready|value=\"Move-in Ready\"  >Move-in Ready</option>", "")
				.replaceAll("Models Opening Fall 2017|<span>Coming Soon!<br>Powdersville|Coming Soon!,Powdersville|>Coming Soon! Powdersville", "")
				.replace("Final Phase is Selling Out", "Final Phase Selling Out").replace("Only 3 Sabal Homes Available", "Only 3 Homes Available");
		comData = comData.replaceAll("Starting Price: Coming Soon", "");
		
		String pstatus=U.getPropStatus(html.replaceAll("6 New Homes Coming Soon!|Lakeside Closeout| value=\"Move-in Ready\"", "")+comData);
		pstatus=pstatus.replace("6 Available Homes Coming Soon, 6 Available Homes","6 Available Homes Coming Soon");
		//U.log(html);
//		U.log(Util.matchAll(html+comData+combinedQuickHtml+combinedFloorHtml,"[\\w\\s\\W]{30} Move-in Ready[\\w\\s\\W]{30}",0));

//----Fetching move-in ready status from feature home Page--------------
		if(quickUrls.length > 0 && quickUrls[0].contains("https") && !pstatus.contains("Quick")){
			if(pstatus == ALLOW_BLANK ){
				pstatus = "Quick Delivery Homes";
			}else if(pstatus != ALLOW_BLANK && !pstatus.contains("Quick")){
				pstatus = pstatus + ", Quick Delivery Homes";
			}
		}
		if(comUrl.contains("https://www.sabalhomessc.com/charleston/palmetto-walk-at-cane-bay-plantation-summerville-sc/"))
			pstatus = pstatus.replace("Coming Soon, 6 ", "Coming Soon 6 ");
	
	//if(comUrl.contains("https://www.sabalhomessc.com/greenville/chastain-glen-at-five-forks-simpsonville-sc"))pstatus = pstatus+",Now Selling";//img
//============================================note====================================================================

	
		communityName=communityName.replace("O&#039;Neal Village","O Neal Village");
	
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl);
			k++;
			return;
		}
		add[2]=add[2].replace(".","");
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		

		if(comUrl.contains("https://www.sabalhomessc.com/myrtle-beach/clear-pond-myrtle-beach-sc/"))dtype = "1.5 Story,2 Story,1 Story";
		//====================== From image =======================
		if (comUrl.contains("https://www.sabalhomessc.com/charleston/bennetts-bluff-james-island-sc/")) {
			pstatus=pstatus+", Now Selling";
		}
		
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus.replace("Final Phase, Selling Out Quickly", "Final Phase is Selling Out Quickly"));
		data.addNotes(note); 
	}
	j++;

	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					//Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					
					try {
						WebElement option = null;

						option = driver.findElement(By.xpath("//*[@id=\"post-187\"]/section[2]/div/div/div[3]/h3[1]"));
						option.click();
						
						Thread.sleep(1000);
						U.log("click succusfull1");
					}catch(Exception ex) {
						U.log("click unsuccusfull1");
					}
					
					html = driver.getPageSource();
					//Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}


}