/**
 * @author Upendra Singh 
 * @date 27/01/2017
 * 
 */
package com.shatam.b_261_280;


import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.File;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U; 
import com.shatam.utils.Util;

public class ExtractSableHomes extends AbstractScrapper{
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	//WebDriver driver= new FirefoxDriver();
	public ExtractSableHomes() throws Exception {
		super("Sable Homes","https://www.sablehomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Sable Homes");
	}
	

	/**
	 * @param args
	 * @throws Exception 
	 */
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractSableHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Sable Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.sablehomes.com/communities/");
		String comSec=U.getSectionValue(mainHtml, "id=\"bwg_thumbnails_0\"","<style>");
		U.log(comSec);
		String[] comValues=U.getValues(comSec, "href=\"","\"");
				U.log(comValues.length);
		for(String comUrl:comValues)
				{
					comUrl="https://www.sablehomes.com/communities"+comUrl;
					addDetails(comUrl);
				}
		
	
		LOGGER.DisposeLogger();
	}

	// TODO : Extract Community Details here
	private void addDetails(String comUrl) throws Exception {
	//
	//	if(!comUrl.contains("https://www.sablehomes.com/communities/country-meadows-2/"))return;
//		try{
		{	
	//	if(comUrl.contains("https://www.sablehomes.com/communities/byron-glen/"))return; //404Error
		U.log(j+"   commUrl-->"+comUrl);
		
		
		if(data.communityUrlExists(comUrl))
		{
		LOGGER.AddCommunityUrl(comUrl+"+++++++++++Repeated+++++++++++");
		k++;
		return;
		}
	LOGGER.AddCommunityUrl(comUrl);
	
				String html=U.getHTML(comUrl);

		//============================================Community name=======================================================================
				String communityName=U.getSectionValue(html, "<h1 class=\"page-title\">","</h1>");
				U.log("community Name---->"+communityName);
				
		//====================latlng from main page====================
				
				
		//================================================Address section===================================================================
				
				String note="";
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				add[1]=U.getSectionValue(html, "Area:</strong>","<strong>").replace("�","").replace(", Cedar Springs","").replaceAll("<a(.*?)>", "");

				add[2]=U.getSectionValue(html, "County:</strong>","</p>").replace("�","");
				
//				if(comUrl.contains("https://www.sablehomes.com/communities/country-meadows-2"))
//				{
//					String addsec=U.getSectionValue(html, "<i class=\"fa fa-map-marker\"></i>", "</p>");
//					addsec=addsec.replaceAll("Sparta, MI 49345", ",Sparta, MI 49345").replace("Lot 79 ", "");
//					
//					add=U.getAddress(addsec);
//				}
				if(comUrl.contains("https://www.sablehomes.com/communities/country-meadows-2")){
					add[0] = "Tentree St";
					add[1] = "Sparta";
					add[2] = "MI";
				}
					
				U.log("Add ::"+Arrays.toString(add));
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				String latlngData=getlatlng(communityName);
				U.log(latlngData);
					
				
				if(latlngData!=null){//latlag!=null && 
					latlag[0]=U.getSectionValue(latlngData, "lat\":\"", "\",");
					latlag[1]=U.getSectionValue(latlngData, "lng\":\"", "\",");//\",
					
					if(latlag[0] == null) {
						latlag[0]=U.getSectionValue(latlngData, "lat\":", ",");
						latlag[1]=U.getSectionValue(latlngData, "lng\":", ",");
					}
				}
				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK || latlag[0] == null)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					
					geo="TRUE";
				}
				if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					//note="Address Taken From City And State";
					geo="TRUE";
				}
				if((add[3]==ALLOW_BLANK || add[0]==null) && latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					//note="Address Taken From City And State";
					geo="TRUE";
				}
				/*if(comUrl.contains("https://www.sablehomes.com/communities/country-meadows-2/")) {
					latlag[0] = "43.1541518272";
					latlag[1] = "-85.6963849068";
				}*/
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				
				
//				String latLngData = sendPostRequestAcceptJson("https://www.sablehomes.com/wp-admin/admin-ajax.php", "action=hugeit_maps_get_info&map_id=4");
//				String[] Sec=U.getValues(latLngData, "{id:", "}");
//				for(String sec : Sec) {
//					if(sec.contains(communityName)) {
//						U.log(sec);
//					}
//				}
				
				if(comUrl.contains("https://www.sablehomes.com/communities/byron-glen/")) {
					add[0]="353 Cutler St";
					add[1]="Allegan";
					add[2]="MI";
					add[3]="49010";
				}
		//-------------------available homes data----------------
				String availHomeData=ALLOW_BLANK;
				availHomeData = getAvailHomes(html);
				availHomeData = availHomeData.replaceAll("<span class=\"price\">\\$223,500.00</span>|<span class=\"price\">\\$399,950.00</span>","");
				String featureProp = U.getSectionValue(availHomeData, ">Featured Properties<", "</aside>");
				//availHomeData = availHomeData.replace(featureProp, "");
				//U.log("### "+availHomeData+"##$$#$");
		
		//-------------------found Property data----------------
				String propHtml=ALLOW_BLANK;
				if(!html.contains("No Property Found")){
					String propsec=U.getSectionValue(html, "<article class=\"property-listing-simple property-listing-simple-1", " </div><!-- .property-thumbnail -->");
					propHtml+=U.getHTML(U.getSectionValue(propsec, "href=\"", "\""));
					propHtml = U.removeSectionValue(propHtml, "/* Property Detail Page ", "initialize_property_map();");
				}
				
		//============================================Price and SQ.FT======================================================================
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
/*				html=html.replace("$185,00", "$185,000")
						.replace("$185,0000", "$185,000");
*/				//U.log(html);
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
				String prices[] = U.getPrices(html+availHomeData,"Homes Start at:</strong> \\$\\d{3},\\d{3}|\\$\\d{1},\\d+,\\d+|\\$\\d{3},\\d+", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
				String[] sqft = U
						.getSqareFeet(
								html+availHomeData,
								"Nearly \\d{4} square feet|over \\d{3} square feet|meta-item-value\">\\d{1},\\d+| features \\d{4} square feet|\\d{4} Sq Ft</dd>|\\d{4} square feet",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
		//================================================community type========================================================
	
				String communityType=U.getCommType(html);
				
		//==========================================================Property Type================================================
				html=html.replaceAll("Sable Homes proposes the Karolynn 2 story, executive home|Macondo", "");
				availHomeData=availHomeData.replaceAll("Sable Homes proposes the Karolynn 2 story, executive home|Water Estates Features over 2230|Water Estates offers 2242|/single-family-home-map", "");
				if (availHomeData.contains("single")) {
					U.log("FOUND");
				}
				String proptype=U.getPropType((html+propHtml+availHomeData));
//				U.log("MMMMMMMM "+Util.matchAll(html+propHtml+availHomeData, "[\\s\\w\\W]{50}and a loft[\\s\\w\\W]{30}", 0));
		//==================================================D-Property Type======================================================
				html=html.replace("Stories <span class=\"value\">", "Story ").replaceAll("(2-Story)","two-stories");
				html=html.replaceAll("Rancho|Ranchers| our Charlotte two story", "").replace("(Ranch)", " Ranch ");
				//U.log(availHomeData);
				//U.log(Util.matchAll(html+availHomeData, "[\\w\\s\\W]{30}Bi-Level[\\w\\s\\W]{30}",0));
				String dtype=U.getdCommType((html+availHomeData).replaceAll("is a bi-level|\\(Bi-Level\\)|ranch MOVE IN READY |Rancho|Ranchers", ""));
				
		//==============================================Property Status=========================================================
				String pstatus=ALLOW_BLANK;
				html = html.replaceAll("ocated in our sold|BRAND NEW MOVE IN READY HOME|our new phase ", "").replace("wooded areas with lots available", "Wooded lots available");
				pstatus = U.getPropStatus(html);
				U.log(pstatus);
				if(!pstatus.contains("Move") && (html.contains("Active, Move-In-Ready") || html.contains("Move-In-Ready, Pending") || html.contains("<p>MOVE-IN-READY"))){ //|| availHomeData.contains("Active, Move-In-Ready")
					U.log("===Found ===");
					if(pstatus.length()<5){
						pstatus = "Move In Ready";
					}
					else{
						pstatus = pstatus + ", Move In Ready";
					}
				}
				
				
		//============================================note====================================================================
		
				
				pstatus=pstatus.replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
				

				add[2]=add[2].replace(".","");
				
				if(note.length()<3) note =  ALLOW_BLANK;
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					data.addCommunity(communityName.replace("&#8211; New Phase Coming Soon!", ""),comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
					data.addUnitCount(ALLOW_BLANK);
	}
		j++;
//		}catch(Exception e){}
	}

	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
//		log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("accept", "application/json, text/javascript, */*; q=0.01");
	        connection.setRequestProperty("content-type", "application/x-www-form-urlencoded; charset=UTF-8");
	        connection.setRequestProperty("authority", "www.sablehomes.com");
	        connection.setRequestProperty("path", "/wp-admin/admin-ajax.php");
	       
	        
	       // connection.setRequestProperty("cookie", "_gcl_au=1.1.1456012046.1640343807; _fbp=fb.1.1640343807463.1591705095; fpestid=ZKfAVP-LrBfP4AutDuFbz0Lj4DhoHr2uPK5HBD1bvGZlYy3IjqrmFv5zY8MrqJ9AX381Qg; _ga=GA1.2.1701821622.1640343812; _gid=GA1.2.2086167152.1640343812");
	        connection.setRequestProperty("origin", "https://www.sablehomes.com");
	        connection.setRequestProperty("referer", "https://www.sablehomes.com/communities/");

	        connection.setRequestProperty("x-requested-with", "XMLHttpRequest");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}


	private String getAvailHomes(String cHtml) throws IOException{
		String availHtml=ALLOW_BLANK;
		
		String availSec=U.getSectionValue(cHtml, "<strong>Available Homes:</strong>", "</p>");
		if(availSec!=null && availSec.contains("href")){
			String[] allAvailUrl =U.getValues(availSec, "<a href=\"", "\"");
			for(String availUrl : allAvailUrl){
				availUrl="https://www.sablehomes.com"+availUrl;
				U.log("availUrl::"+availUrl);
				
				
				availHtml=U.getHTML(availUrl)+availHtml;
				availHtml = U.removeSectionValue(availHtml, "/* Property Detail Page ", "initialize_property_map();");
				String dropcomSec=U.getSectionValue(availHtml, "Property Type", "form-submit-btn\">");
				
				if(availHtml.contains("\">Show Details")){
					String homeDetail=U.getSectionValue(availHtml, "<a class=\"btn-default\" href=\"", "\"");
					U.log("homeDetail::"+homeDetail);
					String temp = U.getHTML(homeDetail);
					temp = U.removeSectionValue(temp, "/* Property Detail Page ", "initialize_property_map();");
					availHtml+=temp;
				}
				if(dropcomSec!=null){
					U.log("Suucess drop");
					availHtml=availHtml.replace(dropcomSec, "");
				}
				if (availHtml.contains("single-family")) {
					U.log("single-family FOUND");
				}
			}
		}
		return availHtml;
	}
	
	private String getlatlng(String comName){
		comName=comName.replace("Ridge Water Estates", "Ridge Water");
//		String postData=U.sendPostRequestAcceptJson("https://www.sablehomes.com/wp-admin/admin-ajax.php", "action=hugeit_maps_get_info&map_id=4");
//		U.log(postData);
		U.log(comName);
		final String FileName = U.getHardCodedPath()+"sablehomes_addressData.txt";
		String data=ALLOW_BLANK;
		try {
			BufferedReader read = new BufferedReader(
					new FileReader(FileName));
			String sCurrentLine =null;
			
			//StringBuilder output = new StringBuilder();
			
			while ( ( sCurrentLine = read.readLine( ) ) != null ) {
				data=sCurrentLine+data;
				}
			read.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		U.log("comName"+comName);
		String latlngData =U.getSectionValue(data, comName, "description");
		
		return latlngData;
	}
	
}