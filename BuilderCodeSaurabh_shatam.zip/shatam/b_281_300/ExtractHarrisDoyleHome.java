package com.shatam.b_281_300;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHarrisDoyleHome extends AbstractScrapper{
	
	static String builderName="Harris Doyle Home";
	static String builderUrl="https://harrisdoyle.com/";
	CommunityLogger logger;
	static int dupli=0;
	WebDriver driver = null;
	static int i=0;
	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
//		try {
			AbstractScrapper abS=new ExtractHarrisDoyleHome();
			abS.process();
			FileUtil.writeAllText(U.getCachePath()+"Harris Doyle Home.csv", abS.data().printAll());
//		} catch (Exception e) {
//			e.printStackTrace();
		}
	
	public ExtractHarrisDoyleHome()
			throws Exception {	
		super(builderName, builderUrl);
		logger=new CommunityLogger(builderName);
	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
	
		String mainHtml=U.getHTML(builderUrl+"communities");
//		U.log(builderUrl+"communities");
		String[] comSec=U.getValues(mainHtml, "class=\"CommunityCard_informationSection", ">View Details</span>");
		U.log(builderUrl+"communities");
		U.log(comSec.length);
//		String legacySec=U.getSectionValue(mainHtml, "<h1 class=\"title\">Legacy Communities  - Sold Out</h1>", "</section>");
		int i=0;
		//U.log(legacySec);
		//String[] communites=U.getValues(comSec, "<div class=\"row\">", "VIEW DETAILS</a>");
		for (String community : comSec) {
			//U.log("-----------------------------------"+i+"-------------------------------------");
			//U.log(community);
			String commName=U.getSectionValue(community, "<h3 class=\"CommunityCard_name pr-1\"", "</h3>");
//			if (legacySec.contains(commName)) {
//				U.log("-----------------------------------"+i+"-------------------------------------");
//				U.log("SoldOUt");
//				//U.log(commName);
//				community = community+"Statues:::Sold Out";
//			}
			commName = commName.replaceAll("data-reactid=\"\\d+\">", "");
			
			String commURL=U.getSectionValue(community, "href=\"", "\"");
			if(commURL==null) return;
			if(!commURL.startsWith("http"))
				commURL=builderUrl+commURL.replace("/communities", "communities");

			
//			U.log(commURL);
			String subCommName="";
		if(commURL!=null) {
			U.log("Main comm Url=="+commURL);
			String commHtml=U.getHtml(commURL, driver); 
			U.log("commUrl cachee path:: "+U.getCache(commURL));//dt may 2022
			if(commHtml.contains("<div class=\"CommunityCard_statusText\"")) {
				String subCommSections[]=U.getValues(commHtml, "<div class=\"CommunityCard_statusText\"", "View Details");
			   U.log("Sub Comm in "+commName+"=====>"+subCommSections.length);
				for(String subCommSeec:subCommSections) {
				   String subCommUrl=U.getSectionValue(subCommSeec, "<a class=\"CommunityCard_btn CommunityCard_visit\" href=\"", "\"");
				   subCommUrl=builderUrl+subCommUrl.replace("/communities", "communities");
				   U.log("sub comm Url=="+subCommUrl);
                   String subCommNameSec=U.getSectionValue(subCommSeec, "<h3 class=\"CommunityCard_name pr-1", "<h5 ");
                  
                   if(subCommNameSec!=null)
                	   subCommName=U.getSectionValue(subCommNameSec, "\">", "</h3>");
                   if(subCommUrl.contains("https://harrisdoyle.com/communities/auburn/mimms-trail-11#detail"))
                   {
                	   subCommName="Mimms Trail 11";
                   }
                   if(subCommUrl.contains("https://harrisdoyle.com/communities/birmingham/the-brayfield-single-family-homes-at-liberty-park#detail"))
                   {
                	   subCommName="The Brayfield Single Family Homes At liberty park";
                   }   
                   String  subCommHtml=U.getHtml(subCommUrl, driver);
                   U.log("sub comm subCommName=="+subCommName); 
                   
                  String []oldData=U.getValues(subCommHtml, "<div class=\"CommunityCard_statusText\"", "View Details");
                  for(String old:oldData) {
            	  subCommHtml=subCommHtml.replace(old, "");
                  }
                  
                   addDetails(subCommSeec, subCommName, subCommUrl, subCommHtml);		   
			       i++;
			   }
			
			
			}
			
		else {	
			U.log("comm Url=="+commURL);
		     addDetails(community,commName,commURL,commHtml);
			i++;
		}
		}
		}
		
		U.log("Total comm= "+i);
		logger.DisposeLogger();
		driver.quit();
	}
	 int j=0;
	private void addDetails(String community, String commName, String commURL,String commHtml) throws Exception {
//		U.log("====="+commURL);
		
//	if(!commURL.contains("https://harrisdoyle.com/communities/auburn/augusta#detail")) return; 

		
		//if(j>=0 && j<21)
	//	if(j>=37 && j<=44)
		{
			
		U.log("count --->"+ j);
		U.log("commURL--->"+commURL);

		if (data.communityUrlExists(commURL)) {
			logger.AddCommunityUrl(commURL+"***********************repeated");
			dupli++;
			return;
		}
		if (commURL.contains("https://harrisdoyle.com/communities/birmingham/the-brayfield-single-family-homes-at-liberty-park#detail")) {
			logger.AddCommunityUrl(commURL+"********************Not Opening");
		//	dupli++;
			return;
		}
		
		
		logger.AddCommunityUrl(commURL);

			
	//	String commHtml= getHtml(commURL, driver);//U.getHTML(builderUrl+commURL);
		U.log(U.getCache(commURL));
		
		/*if(commHtml.contains("alt=\"Dilworth Homes\"")) {
			logger.AddCommunityUrl("=====Dilworth Homes===Return===== " + commURL);
			return;
		}*/
		
		String rmsec = U.getSectionValue(commHtml, "window.__PRELOADED_STATE__ =", "</script>");
		if(rmsec!=null)
		commHtml = commHtml.replace(rmsec, "");
			

			U.log(commURL);
			//U.log("@#@#"+community);
			String add1[]=null;
		String Geo="True";//Address taken from source but zip Missing on page
		String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,};
		String adsec= U.getSectionValue(commHtml, "\"additionalType\":[\"http://www.productontology.org/id/Subdivision", "},");
		if(commURL.contains("/communities/auburn/mimms-trail")) {
			adsec = adsec.replace("\"addressLocality\":\"AUBURN\",\"addressRegion\":\"AL\",\"postalCode\":\"36832\",\"streetAddress\":\"325 BARKSDALE LANE\"", 
					"\"addressLocality\":\"Auburn\",\"addressRegion\":\"AL\",\"postalCode\":\"36832\",\"streetAddress\":\"325 Barksdale Lane\"");
		}
		
		U.log("addSec==="+adsec);
		if(adsec!=null) {
		add[0]=U.getSectionValue(adsec, "\"streetAddress\":\"", "\"");
		add[1]=U.getSectionValue(adsec, "\"addressLocality\":\"", "\"");
		add[2]=U.getSectionValue(adsec, "\"addressRegion\":\"", "\"");
		add[3]=U.getSectionValue(adsec, "\"postalCode\":\"", "\"");
		}
		else {
			U.log(">>>>>>>>>");
			 adsec= U.getSectionValue(community, "class=\"CommunityCard_location\"", "</h5></div>");
			 U.log("adsec====="+adsec);
			 adsec=adsec.replaceAll("data-reactid=\"\\d+\">", "");
			 adsec=U.getNoHtml(adsec);
			 U.log("adsec====="+adsec);
			 add1=adsec.split(",");
		}
//		if(add[0]==null)add[0]=ALLOW_BLANK;
		U.log("Street: "+add[0]+" City: "+add[1]+" State: "+add[2]+" Zip: "+add[3]);
		//"latitude":33.713639,"longitude":-86.817638,
		String latLon[]={ALLOW_BLANK,ALLOW_BLANK};
		String latSec = U.getSectionValue(commHtml, "\"https://www.google.com/maps/place/", "/");
		if(latSec!=null) {
		latLon[0]=latSec.split(",")[0];//U.getSectionValue(latSec, "latitude\":", ",");
		latLon[1]=latSec.split(",")[1];//U.getSectionValue(latSec, "longitude\":", "}");
		}
		U.log("latitude: "+latLon[0]+" longitude: "+latLon[1]);
		
		
		if(add[0]==ALLOW_BLANK||add[1]==ALLOW_BLANK||add[2]==ALLOW_BLANK||add[3]==ALLOW_BLANK && latLon[0]==ALLOW_BLANK) {
			String add2[]= {"",add1[0],add1[1],""};
			U.log("========"+add2.toString());
			latLon=U.getlatlongGoogleApi(add2);
			add=U.getAddressGoogleApi(latLon);
			Geo = "True";
		}
		
		if (add[0]==ALLOW_BLANK||add[1]==ALLOW_BLANK||add[2]==ALLOW_BLANK||add[3]==ALLOW_BLANK||add[0].trim().length()==0||add[1].trim().length()==0||add[2].trim().length()==0||add[3].trim().length()==0) {
			add=U.getAddressGoogleApi(latLon);
			Geo = "True";
		}
		if (latLon[0]==ALLOW_BLANK||latLon[1]==ALLOW_BLANK) {
			latLon=U.getlatlongGoogleApi(add);
			Geo = "True";
		}
		
		
//		U.log("latitude: "+latLon[0]+" longitude: "+latLon[1]);
		
		//String detail=U.getSectionValue(community, "<p>", "<\\/p>");
		community=community.replace("$200\\u2019s", "$200,000");
		community=community.replace("$200's", "$200,000");
		community=community.replace("$300's", "$300,000");
		community=community.replace("$400's", "$400,000");
		community=community.replace("0k", "0,000");
		community=community.replace("$500k", "$500,000");
		
		String allHomesData="";
		String homeurls[] = U.getValues(commHtml, "<li class=\"Results_listItem m-3\"", "View Details</span></div></div>"); 
		
		if(homeurls==null)
		    homeurls = U.getValues(commHtml, "<div class=\"CommunityCard_statusText\"", "View Details</span></div></div>"); 

		U.log("homeurls ::"+homeurls.length);
		int quick=0;
		int underConsr=0;
		for(String home : homeurls) {
			//String hurl = U.getSectionValue(home, "imageWrapper\" href=\"", "\"");
		//	U.log("hOM E:: "+home);
			if(home.contains("<div class=\"HomeCard_status\""))
				quick++;
			if(home.contains("Under Construction"))
				underConsr++;
			String hurl = U.getSectionValue(home, "CommunityCard_visit\" href=\"", "\"");
             if(hurl==null)
            	 hurl = U.getSectionValue(home, "imageWrapper\" href=\"", "\"");
			hurl=hurl.replace("/homes", "homes").replace("/plan", "plan");
			U.log("homeUrl :"+builderUrl+hurl);
			String hhtml = U.getHTML(builderUrl+hurl.replace("/communities", "communities"));
			
			allHomesData +=U.getSectionValue(hhtml, ">Home Description</h3>", "</div></div></div></div></div>");
			String features = U.getSectionValue(hhtml, "Home Features</h3>", "Built In These Neighborhoods</h3>");
			if(features!=null)
			allHomesData +=features;
		}
		
		
		
		
		
		
		
		
		
		//		U.log(" <a href=\""+commURL+"/plan/");
//		if (commHtml.contains(" <a href=\""+commURL+"/plan/")) {
//			String[] planUrls=U.getValues(commHtml, "<a href=\""+commURL+"/plan/", "\"");
//			for (String planURL : planUrls) {
//				//U.log(builderUrl+commURL+"/plan/"+planURL);
//				planHtml=planHtml+U.getHTML(builderUrl+commURL+"/plan/"+planURL);
//			}
//		}
//		//<a href="/cypress-point/move-in-ready/
//		//U.log("MoveIn  <a href=\""+"/"+commURL+"/move-in-ready/" );
//		if (commHtml.contains(" <a href=\""+"/"+commURL+"/move-in-ready/")) {
//			String[] moveInUrls=U.getValues(commHtml, "<a href=\""+"/"+commURL+"/move-in-ready/", "\"");
//			for (String moveInURL : moveInUrls) {
//				//U.log(builderUrl+commURL+"/move-in-ready/"+moveInURL);
//				moveInHtml=moveInHtml+U.getHTML(builderUrl+commURL+"/move-in-ready/"+moveInURL);
//			}
//		}
		//U.log(commHtml);<p>SqFt: 2880</p><p>Base Price: $354,000</p>SqFt: 2490 - 2450
		community = community.replaceAll("</h3><h5 class=\"CommunityCard_label center\" data-reactid=\"\\d+\">Sq. Ft.", " Sq. Ft.")
				.replaceAll("</span><span class=\"Card_label\" data-reactid=\"\\d+\"> Sq. Ft.", " Sq. Ft.");
		commHtml= commHtml.replace("</h3><h5 class=\"CommunityCard_label center\" data-reactid=\"\\d+\">Sq. Ft.", " Sq. Ft.").replaceAll("</span><span class=\"Card_label\" data-reactid=\"\\d+\"> Sq. Ft.</span>", " Sq. Ft.").replace("2,046 - 0</b><!-- react-text: 229 --> Sq. Ft.", "2,046 - 0 Sq. Ft.");
		String[] sqFt=U.getSqareFeet(commHtml+community, "from \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3}-\\d,\\d{3}</h3><h5 class=\"CommunityCard_label center\" data-reactid=\"\\d+\">Sq. Ft.|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d{4} Sq. Ft.|\\d,\\d{3}\\s*-\\s*0 Sq. Ft.|\\d{4} – \\d{4} sq. ft.|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|between \\d,\\d{3} – \\d,\\d{3} square feet|\\d{4}- \\d{4} square feet|<p>SqFt:\\s+\\d{4}</p>|SqFt:\\s+\\d{4}\\s+-\\s+\\d{4}|\\d{4}  Sq. Ft.|\\d{4} � \\d{4} sq. ft", 0);
		String minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		String maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		
		U.log("Sqft: min "+minSqFt+" max "+maxSqFt);
		
//   	U.log("mmmmmm"+Util.matchAll(community+commHtml, "[\\w\\s\\W]{50}coming soon[\\w\\s\\W]{30}", 0));

		
//		String remHeader = U.getSectionValue(commHtml, "id=\"header\">", "</header>");
//		commHtml = commHtml.replace(remHeader, "");
//		planHtml = planHtml.replace(remHeader, "");
//		moveInHtml = moveInHtml.replace(remHeader, "");
		
		community = community.replaceAll("0k|0's|0�s", "0,000").replace("$1M+", "$1,000,000");
		commHtml = commHtml.replaceAll("0's|0’s|0�s", "0,000").replace("$1M+", "$1,000,000");
		
		String[] price=U.getPrices(community+commHtml, "<p>Base\\s+Price:\\s+\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
		String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("Price Min: "+price[0]+" Max: "+price[1]);

		
		
		commHtml = commHtml.replace("Base Price: Coming Soon", "").replace("Townhomes, Now Available,", "").replace("lots are already selling", "lots are selling").replace("Now Selling in Phase II", "Now Selling Phase II").replaceAll("<p>COMING SOON! New-home", "")
				.replace("second phase is only minutes away and is", "second phase ").replaceAll("Golf Course Lots Available", "")
			     ;
		commHtml = commHtml.replace("now selling in Phase 2B", "Now Selling Phase 2B")
				.replace("only have two homes left", "only two homes left")
				.replace("Phase I is now SOLD OUT", "Phase I SOLD OUT")
				.replaceAll(", Now Available,", "")
				.replace("Coming Summer of 2022", "Coming Summer 2022")
				.replace("Phase I is now selling", "Phase I Now Selling")
				.replace("\"Legacy Communities  - Sold Out", "")
				.replace("New Smart Homes Now Available", "")
				.replace("Phase 11 is planned for release in Spring 2022", "Phase 11 coming Spring 2022")
				.replace("Phase-II has 21 homesites available", "Phase-II 21 homesites available")
				.replace("Phase I in Simms Landing is currently sold out.", "Phase I is currently sold out");

		

		community = community.replace("Townhomes, Now Available,", "").replace("Now Selling in Phase II", "Now Selling Phase II")
				.replaceAll("\"Legacy Communities  - Sold Out|status\":\"Sold", "")
				.replace("Pebble Hill Townhomes Coming Soon", "").replaceAll("sc\":\"COMING SOON! Ne| townhomes coming Fall 2021", "");

//		U.log(community);
		
		commHtml=commHtml.replaceAll("\">Sold Out</div>|Coming Soon</div>|COMING SOON</h3></div>", "").replaceAll("New homes are now selling", "New homes now selling");
		//String status=U.getPropStatus(community.replace("only six homes left in Phase II", "Only Six Homes Left in Phase II").replaceAll("\"Coming Soon\"|\"Sold Out|\"mega_menu_desc\":\"NOW AVAILABLE!", "")+(commHtml).replace("only six homes left in Phase II", "Only Six Homes Left in Phase II").replaceAll("Move-In Ready Homes</h3>|Move-in Ready Homes</a>Pebble Hill Townhomes Coming Soon|<p>COMING SOON! New-home|<p>NOW AVAILABLE! New-home community|, Now Available,", ""));
        String status = U.getPropStatus((community+commHtml).replace("almost a sold out", "almost sold out").replace("New homes in SweetBay are coming soon", "New homes coming soon").replace("only six homes left in Phase II", "Only Six Homes Left in Phase II")
        		.replaceAll("data-reactid=\"181\">Coming Soon<|data-reactid=\"184\">COMING SOON</h3>|reactid=\"136\">Quick Move-In Homes</a>|reactid=\"230\">Sold Out</div>|--> Quick Move-In Homes<|Coming Soon<!-- /react-text --></span>|coming Winter 2021|\"Coming Soon\"|single-family homes are selling fast|\"Sold Out|\"mega_menu_desc\":\"NOW AVAILABLE!|Move-In Ready Homes</h3>|Move-in Ready Homes</a>|Pebble Hill Townhomes Coming Soon|<p>COMING SOON! New-home|<p>NOW AVAILABLE! New-home community|now avail|Now Avail", ""));
		
        U.log("status1 --->"+status);  
        
        status=status.replaceAll("Quick Move-In Homes|Quick Move-In Homes, |, Quick Move-In Homes|quick move-in homes|Quick Move-in Homes, |, Quick Move-in Homes|Quick Move-in Homes", "");
       
        U.log("quick counr"+quick);
        U.log("underConsr"+underConsr);

        if(quick>underConsr) {
        	if(status.length()<4&&!status.contains("Quick Move-in Homes")) {
        		status="Quick Move-in Homes"; 
        	}
        	else {
        		status=status+", Quick Move-in Homes";
        	}
    }//else {
//            status=status.replace("Quick Move-in Homes, |, Quick Move-in Homes|Quick Move-in Homes", );
//
//        }
//        
        U.log("mmmmmm"+Util.matchAll(community+commHtml, "[\\w\\s\\W]{50}quick move-in homes[\\w\\s\\W]{30}", 0));

        
        int count = 0;  //for quick status
        commHtml = commHtml.replaceAll("-->(\\d)<!-- /react-text --><!-- react-text: \\d{3} --> Quick Move-In Homes<",
        		" $1 Quick Move-In Homes<");
        
   /*     String quickNumber = Util.match(commHtml, " \\d Quick Move-In Homes<");
        if(quickNumber != null) {
        	String quickCount = Util.match(quickNumber, "\\d");
            count = Integer.parseInt(quickCount);
            U.log("count: "+count);
        }
        
       
   	if(count > 0) {
		if(status == ALLOW_BLANK)
			status = "Quick Move-In Homes";
		else if(status != ALLOW_BLANK && !status.contains("Quick"))
			status = status + ", Quick Move-In Homes";	
   	}
       */
       
       U.log("status --->"+status);
       commHtml = commHtml.replaceAll("Level 1 Cabinets", "");
       
//     U.log("mmmmmm"+Util.matchAll(community+commHtml, "[\\w\\s\\W]{50}Homesites Available[\\w\\s\\W]{30}", 0));
 //  	U.log("mmmmmm"+Util.matchAll(commHtml, "[\\w\\s\\W]{50}Quick Move-in[\\w\\s\\W]{30}", 0));
   	
		commHtml = commHtml.replace("Level 1-3", "Story 1 , story 3").replace("Level 1", "Story 1 ").replaceAll("1 - 2</b><!-- react-text: \\d{3} --> Stories", "1 Story, 2 Story")
				.replaceAll("<b>(\\d)\\s*-\\s*(\\d)</b><!-- react-text: \\d+ --> Stories<", "<b> $1 Story , $2 Story <")
				.replaceAll("<b>(\\d)</b><!-- react-text: \\d+ --> Stories<", "<b> $1 Story <").replaceAll("\\d</b><!-- react-text: \\d{3} --> Stories", "2 Story");
		
//		U.log("mmmmmm"+Util.matchAll(community+commHtml+allHomesData, "[\\w\\s\\W]{30}2 Stories[\\w\\s\\W]{30}", 0));
		
		String dtype=U.getdCommType((community+commHtml+allHomesData).replaceAll("visit the Colonial", ""));
		U.log("****"+dtype);

		commHtml = commHtml.replace("Low-maintenance luxury ", "luxury home").replaceAll("\"Townhomes\"|-townhomes.", "");
		
		
		String propType=U.getPropType((community+commHtml+allHomesData).replaceAll("Traditional Slab|marker-single-family-homes.png|case \"Single Family Homes\"", ""));
		commHtml = commHtml.replace("lake living", "Lakefront Series")
				.replace("secluded lakeside setting", "secluded lakeside community setting");
		
		String commType=U.getCommunityType(community+commHtml.replace("gated bowl", ""));
		String notes=U.getnote(community+commHtml);
		commName = commName.replace("Mimm&#x27;s Trail", "Mimm's Trail");
		if(latLon[0].length()<4 && add[1].length()>1) {
			latLon=U.getlatlongGoogleApi(add);
			Geo="TRUE";
		}
		add[1]=add[1].replace(", AL", "");
		if(!commHtml.contains("Move-In Ready Homes</h3></div></div><div class=\"AccordionToggle_content\" ")) {
			status= status.replaceAll("Move-in Ready Homes,", "").replace(", Move-in Ready Homes", "").replace("Move-in Ready Homes", "-");
		}
		if((builderUrl+commURL).contains("https://harrisdoyle.com/liberty-park"))
			status = status.replace("Now Available", "New Townhomes Now Available");
		if((builderUrl+commURL).contains("https://harrisdoyle.com/the-nest-at-mimms-trail"))
			status = status.replace("Now Available", "New Homes Now Available");
		
		status=status.replaceAll("Ii|ii", "II");

		
/*		if((builderUrl+commURL).contains("https://harrisdoyle.com/communities/lake-martin/talisi-cove"))
		{
			status="Lots Are Now Selling";
		}
*/
		
//		if(commURL.contains("/pike-road/penn-meadows"))
//			status="Coming Soon, Coming Winter 2021";//IMG
//		
		if((builderUrl+commURL).contains("https://harrisdoyle.com/communities/birmingham/simms-landing"))
		{
//			status +=", Coming In Spring 2020";
			propType +=", Multi-Gen Homes";
		}
		//
		
//		//https://harrisdoyle.com/communities/auburn/the-nest-at-mimms-trail
//		https://harrisdoyle.com/communities/auburn/the-nest-at-mimms-trail
//			https://harrisdoyle.com/communities/auburn/the-nest-at-mimms-trail
//		if((builderUrl+commURL).contains("/birmingham/liberty-park-townhomes"))status = status.replace("Coming Soon,", "");
		status=status.replaceAll(", Move-in Ready Homes|Move-in Ready Homes,|Move-in Ready Homes|Move-in Ready,|, Move-in Ready|Move-in Ready", "");//.replaceAll("Homes, |Homes", "");
//dt		if(commHtml.contains("<a class=\"HomeCard_imageWrapper\"")) {
//			if(status.length()<2 && !status.contains("Quick"))status ="Quick Move-In Homes";
//	dt may		else if(status.length()>2 && !status.contains("Quick")) status = status+", Quick Move-In Homes";
//		}
		if(status.length()==0)status=ALLOW_BLANK;
		status =status.replace("Phase 2b", "Phase 2B");
		if(status.contains("Selling Fast Homes"))
		{
			status=status.replace("Selling Fast Homes", "Selling Fast");
		}
		if(commURL.contains("farmville-lakes-townhomes"))commName="Farmville Lakes";
		if(commURL.contains("liberty-park-townhomes"))commName="Liberty Park";
		commName=commName.replace("Margaritaville Beach Cottages and Resort","Margaritaville Beach");
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(commName.replace("&#x27;s", "s"), commURL, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLon[0].trim(), latLon[1].trim(), Geo);
		data.addPropertyType(propType, dtype);
		data.addPropertyStatus(status);
		data.addNotes(notes);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
		//U.log(detail);
		
		}
		j++;
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(3000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,4000)", "");
					U.log("Current URL:::" + driver.getCurrentUrl());
					try{
						WebElement load;
						while(driver.getPageSource().contains("Load More "))
						{
						if(driver.getPageSource().contains("Load More Ready")){
							load = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[3]/div[6]/div/div[3]/div/div/div[4]/span"));//load communities
						}
						else {
							load = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[3]/div[7]/div/div[3]/div/div/div[4]/span"));//load floor plans
						}

							load.click();
							U.log(":::::::Click Success:::::::::::");
							Thread.sleep(5000);
						}
					
					}
					catch(Exception e){
						U.log(":::::::Click UnSuccess:::::::::::");
					}
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}

}