/** @Author Parag Humane
 * @Date 5/7/2013
 * @Mofify By Sawan
 * @date 23 Oct 2019
 */
package com.shatam.b_281_300;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.net.Proxy;


import javax.swing.text.html.HTML;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSaratogaHomes extends AbstractScrapper {
	// int i=0;
	public int inr = 0;
	static int j = 0;
	static ArrayList<String> latLongList = new ArrayList<String>();
	WebDriver driver = null;
	CommunityLogger LOGGER;

	private static final String builderUrl = "https://saratogahomestexas.com";
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractSaratogaHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Saratoga Homes.csv", a.data().printAll());
	}

	public ExtractSaratogaHomes() throws Exception {

		super("Saratoga Homes", builderUrl);
		LOGGER = new CommunityLogger("Saratoga Homes");
	}

//	static String proxyIp = "162.144.106.161";
//	static int port  = 3838;
	public void innerProcess() throws Exception {
		
		//set cookie for extraction
//		=========================================
		
		
		
//		String html = U.getHTMLwithProxy(builderUrl);
//		U.setUpChromePath();
//		ChromeOptions options = new ChromeOptions();
//		options.addExtensions (new File("/home/shatam-50/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
//		
//		 Proxy proxy = new Proxy();
////		 proxy.setHttpProxy("45.145.150.50:3128");
////		 proxy.setSslProxy("138.197.209.229:3128"); 
//		 DesiredCapabilities capabilities = new DesiredCapabilities();
//		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//			//driver = new ChromeDriver(capabilities);
//		 //capabilities.setCapability("proxy", proxy);
//		 driver = new ChromeDriver(capabilities);
		Thread.sleep(10000);
		int count = 0;
//		String html = U.getHtml(builderUrl, driver);
		String html =getHTM(builderUrl);


		String section = U.getSectionValue(html, "Find Your Home</div>", "</ul>");
		//String [] regUrls = U.getValues(section, "<a href=\"", "\"");
		String[] regUrlSection = U.getValues(section, "<li class=\"sidebar-nav__block\">", "</a>");
		for(String regUrlSec : regUrlSection){
//			regUrlSec=regUrlSec;
			String regUrl = U.getSectionValue(regUrlSec, "href=\"", "\"");
			U.log("===============\n"+regUrlSec);
			U.log("regUrl ::"+regUrl);
//			String regHtml = U.getHtml(regUrl, driver);
			String regHtml = getHTM(regUrl);

			String[] comSections = U.getValues(regHtml, "<li class=\"grid__item regions__community animated", "</a>");
			U.log("com. Count :"+comSections.length);
			
			String regionName = U.getSectionValue(regUrlSec, "brick-link-bottom\">", "</span>");
			U.log(regionName);
//			String regionNumberSection = U.getSectionValue(regHtml, "<select name=\"selected_regions", "</select>");
//			if(regionName!=null) {
//			String regionNumber = Util.match(regionNumberSection, "<option value=\"(\\d)\">"+regionName.trim()+"</option>", 1);
			regionName=regionName.toLowerCase().replace("el paso", "el-paso");
			U.log("regionName: "+regionName);
			String quickUrl = "https://saratogahomestexas.com/regions/"+regionName+"/quick-move-ins";
			U.log("QuickUrl :"+quickUrl);
//			String quickHtml = U.getHtml(quickUrl,driver);
			String quickHtml =getHTM(quickUrl);

			quickHtml = StringEscapeUtils.unescapeJava(quickHtml);
			if(quickHtml!=null) {
				quickHtml=quickHtml.replace("&lt;", "<").replace("&gt;", ">");
			}
		//
		//	U.log(quickHtml);
			String quickHomeSection[] = U.getValues(quickHtml, "<div class=\"qmi-card__detail", "clazy-load>");//"<div class=\"cta__text\">");
			U.log(quickHomeSection.length);
			
			
			for(String comSec : comSections){
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
//				U.log("comUrl : "+comUrl);
				
				if(!comUrl.startsWith("http")) comUrl = builderUrl + comUrl;
				U.log(">>>>>>> comUrl : "+comUrl);
//				U.log("count : "+count);
//				count++;
				extractCommunityDetails(comUrl, comSec, quickHomeSection);
			}
		}
//		}
//		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private static String priceRegex[] = {"Price: \\$\\d{3},\\d{3}",
			"(mid|low|upper|the) \\$\\d{3},\\d{3}",
			"price\">Price:(&nbsp;|\\s)\\$\\d{3},\\d{3}</p>|Homes from the \\$\\d{3},\\d{3}"
	};
	
	private static String sqftRegex[] = {
			"snap\">(\\d,\\d{3}\\s?-\\s?)?\\d,\\d{3} Sq\\.Ft\\.",
			"range from \\d,\\d{3} sq\\.ft\\.\\s?(-|–)\\s?\\d,\\d{3} sq\\.\\s?ft\\.|\\d,\\d{3} sq.ft. - \\d,\\d{3} sq. ft",
			"class=\"sqft\">\\d,\\d{3} Sq. Ft.</li>"
	};
	
	//TODO : Extract Community Details here
	private void extractCommunityDetails(String comUrl, String comSec, String quickHomeSection[]) throws Exception {
//	try{
//		if(j<=5)
	{
		
		U.log("Count ::"+j);
		U.log(comUrl);
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "----------------- Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		
//		if(!comUrl.contains("https://saratogahomestexas.com/new-home-communities/houston/lago-mar"))return;
		
		
//		String html = U.getHtml(comUrl,driver);
		String html = getHTM(comUrl);
//		U.log("html ::"+html);
		
		//=========== Community Name ==============
		String comName = U.getSectionValue(comSec, "community-card__title\">", "</span>");
		U.log("comName ::"+comName);
		
		//============== Note ===============
		String notes = U.getnote(html);
		
		//=========== Address ==============
		String[] add = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		String geo = "False";
		String addSec = U.getSectionValue(html, "<div class=\"community-contact__address-section\">", "MAP</a>");
		U.log("addSec ::"+addSec);
		
//		if(addSec != null) {
//			addSec = U.getSectionValue(addSec, "</p><br />", "<a");
//			U.log("addSec ::"+addSec);
//		}
		//exception in this community
		if(addSec.contains(" Socorro, TX 79927"))
				addSec = U.getSectionValue(html, "office at ", " or");
		
		//U.log("addSec ::"+addSec);
		if(addSec != null && addSec.contains("COMING")) {
			addSec = U.getSectionValue(html, "</p><br />", "&nbsp;&nbsp;");
			if(addSec!= null)
				addSec = addSec.replaceAll("<br />", ",");
		//	U.log("MMMMMMMMMMMM "+addSec);
		}
		if(addSec != null)
			addSec = U.getSectionValue(addSec, " center=\"", "\"");
		if(addSec != null){
			addSec = addSec.replace("12464 Chamberlain,", "12464 Chamberlain Drive,");
			add = U.getAddress(addSec);
		}
		if((add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) || comUrl.contains("/el-paso/valley-creek")){
			addSec = U.getSectionValue(html, "Visit our sales office at", "or call");
			if(addSec != null){
				add = U.getAddress(addSec);
			}
		}

		U.log("addSec ::"+addSec);
		U.log("Add :"+Arrays.toString(add));
		
		//============= Lat-Lng ===================
		String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
		latLng[0] = U.getSectionValue(html, "latitude\":", ",");
		latLng[1] = U.getSectionValue(html, "longitude\":", "}");
		U.log("Lat-Lng ::"+latLng[0]+"\t"+latLng[1]);
		
		if(add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK && (latLng[0] != ALLOW_BLANK || latLng[0] != null)){
			String[] add1 = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			add[0] = add1[0];
			geo = "True";
		}
		if(comUrl.contains("/houston/townsen-landing")) geo ="True";
		
		//Distance Exceed
		if(comUrl.contains("/el-paso/valley-creek")){
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			U.log(Arrays.toString(latLng));
		}
		
		//=========== Quick-Move In Ready ====================
		String combinedQuickHome = null;
		int quickCount = 0;
		for(String quickSec : quickHomeSection){
			String comNameOfQuickHome = Util.match(quickSec, "<a href=\"/new-home-communities/.*\">(.*?)</a>", 1);
			
			if(comNameOfQuickHome != null && comName.equalsIgnoreCase(comNameOfQuickHome.trim())){
				combinedQuickHome += quickSec;
				quickCount++;
			}
		}
		
	 //======= Quick Details ==========
		if(combinedQuickHome == null)
			combinedQuickHome = "";
		String[] quickUrls = U.getValues(combinedQuickHome, "<a href=\"tel", "class=\"cta cta--secondary");
		String quickData = "";

		for(String quickUrl : quickUrls) {
	
			try {
				String qurl = "https://saratogahomestexas.com"+U.getSectionValue(quickUrl, "href=\"", "\"");
			//	U.log("Quick URL:" + qurl);
				String quickHtml = U.getHtml(qurl,driver);
				quickData += U.getSectionValue(quickHtml, "<article class=\"qmi-detail__article\">", "</article>");
				
			}catch (Exception e) {
				System.out.println("Exception....");
			}
		}
		
		U.log("quickCount :::"+quickCount);
		//============ Price =====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		comSec = comSec.replaceAll("0s|0's", "0,000");
		html = html.replaceAll("0s|0's|0’s", "0,000");
		
		String[] price = U.getPrices(html, String.join("|", priceRegex), 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		//U.log(Util.matchAll(html, "[\\w\\s\\W]{30}515,950[\\w\\s\\W]{30}", 0));
		
		//=============== Sqft ===================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		U.log("SQDR"+Util.matchAll(comSec + html,"[\\w\\W\\s]{50}1,645[\\w\\W\\s]{50}", 0));
		String[] sqft = U.getSqareFeet(comSec + html , String.join("|", sqftRegex), 0);
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//============= Community Type ============
		html = html.replaceAll("lakeside or parkside view| lakes in the community", "lakeside community or parkside view");
//			 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}lake[\\w\\s\\W]{30}", 0));

		String comType = U.getCommunityType(html);
		
		//============ Floor Html ===============
		String combinedFloorHtmls = null;
		String[] floorUrls = U.getValues(html, "<a class=\"grid grid--column floorplan-card\"", "</li>");
		U.log("floor plan count :"+floorUrls.length);
		for(String floorUrlSec : floorUrls){
			String floorUrl=U.getSectionValue(floorUrlSec, "href=\"", "\"");
			if(!floorUrl.startsWith("http")) floorUrl = builderUrl + floorUrl;
			U.log("floorUrl ::"+floorUrl);
//			String floorHtml = U.getHTMLwithProxy(floorUrl);

			String floorHtml = getHTM(floorUrl);

//			String floorHtml = U.getHtml(floorUrl,driver);

			combinedFloorHtmls += U.getSectionValue(floorHtml, "<div class=\"content-wrapper", "<button class=\"gallery");
		}
		//============= Property Type ==============
		html = html.replaceAll("combination of traditional values", "combination of traditional style values");
		String propType = U.getPropType((html + combinedFloorHtmls+quickData).replace("flex/tech room.", "Flex Room"));
		
		//=============== Derived Property Type ===========
		String dType = U.getdCommType((html + combinedFloorHtmls+quickData).replace("two story swim-up", ""));
//		U.log(Util.matchAll(html, "[\\w\\s\\W]{30}Two story[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll(combinedFloorHtmls, "[\\w\\s\\W]{30}Two story[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll(quickData, "[\\w\\s\\W]{30}Two story[\\w\\s\\W]{30}", 0));

		//============= Property Status ===========
		String rem = "quick-move-ins\"|Quick Move|center=\"COMING\\+SOON%2C|We are currently|Lagoon coming|footer\">Coming|[M|m]ove(-)?[I|i]n";
		html = html.replaceAll("\\d{3}\\W Financing - USDA", "USDA 100% Financing");
		comSec= comSec.replaceAll(rem, "");
		
		String pStatus = U.getPropStatus((comSec + html).replaceAll("We are currently selling this community from Cielo Del Rio at|We are currently selling this community from Pueblos|/quick-move-ins|View Quick Move-ins in|item-title\">Quick Move-Ins</span>|move-in ready model", "")
				.replace(">Now Selling</em>","Now Selling"));
		if(pStatus.contains("Usda")&&pStatus==ALLOW_BLANK) pStatus = "USDA 100% Financing";
		U.log("STATUS: "+pStatus);
//		U.log("Match==="+Util.matchAll(comSec + html, "[\\w\\W\\s]{50}Currently Selling[\\w\\W\\s]{50}",0));
		
		
//		pStatus=pStatus.replace("", newChar)
		
		if(quickCount > 0 && !pStatus.contains("Quick Move")){
			if(pStatus == ALLOW_BLANK) pStatus = "Quick Move-Ins";
			else if(pStatus != ALLOW_BLANK) pStatus += ", Quick Move-Ins";
		}
		
		if(comUrl.contains("communities/el-paso/peyton-estates")) {
			if(propType.length()>0) {
				propType+=", Estate-Style Homes";
			}
			else
				propType="Estate-Style Homes";
		}//=====remm
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(notes);
	}
	j++;
//	}catch(Exception e){}
	}
	
	public static String getHTM(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName =U. getCache(path);
//		deleteFile(fileName);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode =U. CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
			.addRequestProperty("User-Agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");
	urlConnection.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
	urlConnection.addRequestProperty("Accept-Language",
			"en-US,en;q=0.9,es;q=0.8,fr;q=0.7");
	urlConnection.addRequestProperty("Cookie", "_gcl_au=1.1.705601345.1658810691; ga=GA1.2.1227172195.1658810691; gid=GA1.2.105781370.1658810691; STITrackingID=5f6e1926-3ecd-476a-aaca-1a8f9e51956c; cf_clearance=6IPNNQvv4USjl36S.hCWAg927XjbgdZDmcw.9Ru67R8-1658820507-0-150; _gat_UA-39875153-1=1; XSRF-TOKEN=eyJpdiI6ImkxeCtYaDBPXC9uWTg5cUFhOHIyTGV3PT0iLCJ2YWx1ZSI6IjRkeEFlRnFGV2pGMzBPWTZsUnZQYVcwaU9TbEJuQU05OVM0c0NhUm53VHZBYUFMK0hiYWxGdGZ5eUJJaWU5Z2wiLCJtYWMiOiJmYmQzZjAyYmEwNDIwNmRhNWRiYjliNzk4Y2RiMjgzYzc2NmFiYzM2OTJmMTViM2Q5ZDEwYThkMTgyZmZjODhlIn0%3D; laravel_session=eyJpdiI6IlQzcjRYeEVYZm1hUDBKblA5MldRUEE9PSIsInZhbHVlIjoibG1mNFBrRmhmaHIrYWxBMjhDT21uMU5hbkZoanFnaFdcL0o2MXgyYVBzdVllSjNQRUc3UFVQK1diQ1FFbmJ4NFciLCJtYWMiOiI1ODYxZmU0OTEyZGM2NDJjOWNlMzNkYjA0ZjU0N2UzNWRmMDg3NTZiYTdjNWQzZmM2NjFjYThiNjM4NTdlNmVjIn0%3D; sc_is_visitor_unique=rx10851498.1658820551.5C3D869F9FE74FF69E6B657F5F88133E.3.2.1.1.1.1.1.1.1");
//	urlConnection.addRequestProperty("Cache-Control", "max-age=0");
	urlConnection.addRequestProperty("Authority", "saratogahomestexas.com");

			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	
	
	
	
	
/*	private void addInfo(String CUrl, String CName, String info, String regHtml, String regUrl) throws Exception {
		// TODO Auto-generated method stub
//		 if (j == 1)
		{
			
//			if(!CUrl.contains("http://saratogahouston.com/lp/kendall-lakes/website"))return;
			//U.log("count::" + j + ":::");
			info = info.replace(" Mike Godwin El Paso", " Mike Godwin, El Paso");
			info = info.replace("Rosenbergm TX 77471", "Rosenbergm, TX 77471");
			info = info.replace("<h4 class=\"et_pb_module_header\">", "h4>");
			//String url = U.getSectionValue(info, "<a href=\"", "\"");
			//String commName = U.getSectionValue(info, "\">", "<");
			String url = CUrl;
			String commName = CName;
			//U.log("url::" + info);

//			 if(!url.contains("townsenlanding"))return;
			 
			U.log("url::" + url);
			if (url.contains("http://killeen.saratogahomestexas.com/communities-and-floorplans/trimmier-estates/"))
				return;// 404 Error

			if (url.contains("http://saratogahomestexas.com/lp/KendallLakes/email.php")) {
				url = "http://houston.saratogahomestexas.com/communities-and-floorplans/kingdom-heights/";
			}
			
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "----------repeated-------");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			
			U.log("info::" + info);
			// ----Special case for com name;
			if (commName.contains("Unit")) {
				String[] cName = commName.split(" Unit ");
				commName = cName[0];
			}
			U.log(commName);

			String html = U.getHTMLwithProxy(url);
			U.log("::::>"+U.getCache(url));
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlong = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "False";
			String addrsec = U.getSectionValue(info.replaceAll("Wood Ridge Forest<br>", ""), "<p>", "</p>");
			if(addrsec == null) 
				addrsec = U.getSectionValue(html, "Model Home Address:</strong>", "<strong>Phone:");
			if(addrsec != null){
				addrsec = addrsec.replaceAll("Kendall lakes<br>", "");
			
				if (addrsec.contains(",") && (addrsec.contains("TX") || addrsec.contains("Tx"))) {
					addrsec = addrsec.replace("Humble Tx", "Humble, TX").replace("Porter Tx", "Porter, TX")
							.replaceAll("TX,", "TX");
					addrsec = addrsec.replace("TX, 77538", "TX 77538").replace(" Wellington, TX", " Wellington,El Paso, TX")
							.replace("Porter Tx", "Porter, Tx").replace(" Tx 78628 ", " TX 78628 ")
							.replaceAll("Kendall lakes<br />|Wood Ridge Forest<br />|Woodridge Forest<br />|\\(Coming Soon!\\)", "").replace("Lago Mar<br />", "")
							.replaceAll("<.*?>", "");
					U.log("addrsec::" + addrsec);
	
					String[] addr = addrsec.split(",");
	
					add[0] = addr[0].toLowerCase();
					add[0] = U.getCapitalise(add[0]);
					add[1] = addr[1];
	
					if (addr.length > 2) {
						add[2] = Util.match(addr[2], "\\w{2}");
						add[3] = Util.match(addr[2], "\\d{5}");
					}
					if (addr.length == 4) {
						add[2] = Util.match(addr[2], "\\w{2}");
						add[3] = Util.match(addr[3], "\\d{5}");
					}
					U.log("Address:" + Arrays.toString(add));
				} else {
					addrsec = U.getSectionValue(info, "<br />", "<br />");
					if (addrsec != null) {
						addrsec = addrsec.replace("Porter Tx", "Porter, TX");
						add = U.getAddress(addrsec);
					}
				}
			}
			U.log(commName + "::::::::::::");
			regHtml = regHtml.replace("Black Hawk", "Blackhawk");
			String latsec = U.getSectionValue(regHtml, "\"title\":\"" + commName.trim(), "\"anim\"");
			
			U.log("latsec is " + latsec + "\n::::::::::::" + commName + ":::::::::::");
			if (latsec != null) {
				latlong[0] = U.getSectionValue(latsec, "lat\":\"", "\"");
				latlong[1] = U.getSectionValue(latsec, "lng\":\"", "\"");
				if (!latsec.contains("lat\":\"")) {
					latsec = U.getSectionValue(latsec, "address\":\"", "\"");
					latlong = latsec.split(",");
				}
				geo = "false";
			}
			U.log(latlong[0] + ":::::::::" + latlong[1]);
			if (latlong[0] == ALLOW_BLANK && latlong[1] == ALLOW_BLANK) {
				String latLngSec = U.getSectionValue(html, "www.google.com/maps/embed", "\"");
				if (latLngSec != null) {
					U.log(latLngSec);
					latlong[0] = U.getSectionValue(latLngSec, "3d", "!");
					latlong[1] = U.getSectionValue(latLngSec, "!2d", "!");
				}
				U.log(Arrays.toString(latlong));
				if (latlong[0] == null || latlong[1] == null)
					latlong[0] = latlong[1] = ALLOW_BLANK;
			}
			if(url.contains("http://elpaso.saratogahomestexas.com/valley-creek/")){
				latlong[0] = "31.796464";
				latlong[1] = "-106.268030";
			}
			if (add[0].length() < 4 && latlong[0].length() > 4) {
				add = U.getAddressGoogleApi(latlong);
				if(add == null) add = U.getAddressHereApi(latlong);
				geo = "true";
			}
			if (add[0].length() > 4 && latlong[0].length() < 4) {
				latlong = U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
				geo = "true";
			}

			// ----------
			U.log("reg is::" + regUrl);
			U.log(html);
			String InventoryUrl = "";
			if (html.contains("/inventory")) {
				InventoryUrl = regUrl + "/inventory";
			}
			U.log("InventoryUrl::" + InventoryUrl);
			String inventorydetails = "";
			String key = commName.replaceAll("Highlands", "")
					.replaceAll(" At Portofino Estates", "").replace("Lakeshore Harbour", "Lake Shore Harbour").trim();
			U.log(key + "::Name");
			if (InventoryUrl.length() > 4) {
				String InventoryHtml = U.getHTMLwithProxy(InventoryUrl);
				U.log("inven path:" + U.getCache(InventoryUrl));
				String[] comTab = U.getValues(InventoryHtml, "<td class=\"column-1\">", "</tr>");
				for (int k = 0; k < comTab.length; k++) {
					if(comTab[k].contains(key)){
						U.log("==Found =="+ comTab[k]);
						inventorydetails += comTab[k];
					}
				}
				U.log("inventorydetails:" + inventorydetails);

			}
			// -----------
			String plansHtml = ALLOW_BLANK;
			for(String planSec : U.getValues(html, "floorplans/plan", "\"")){
				U.log(regUrl+"/floorplans/plan"+planSec);
				plansHtml += U.getHTMLwithProxy(regUrl+"/floorplans/plan"+planSec);
			}
			if(url.contains("http://elpaso.saratogahomestexas.com/valley-creek/")){
				String planUrlSection[] = U.getValues(html, "<h2 class=\"et_pb_module_header\">", "</a>");
				for(String planUrlSec : planUrlSection){
					String planUrl = U.getSectionValue(planUrlSec, "<a href=\"", "\"");
					U.log(planUrl);
					String planHtml = U.getHTMLwithProxy(planUrl);
					inventorydetails += U.getSectionValue(planHtml, "<div id=\"main-content\">", "gform_body");
				}
			}

			// U.log("result"+U.getSectionValue(plansHtml, "Bathrooms</p>", "</div>"));
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replace("&#8217;s", ",000").replaceAll("0’s|0's|0s|&rsquo;s", "0,000")
					.replaceAll(" #NewMexico. We have #NewHomes starting at \\$119,950 to \\$369,950. |just \\$199,950|BA \\$292,950. Seller", "");
			info=info.replace("0's", "0,000");
			html = html.replace("just $121,950 and we build all", "");
			String[] price = U.getPrices(html  + plansHtml + inventorydetails+info,
					"\\$\\d+,\\d+|column-3\">\\d{6}|column-3\">\\$\\d{6}|<p>\\d{4} sq. ft.</p>|<h2>\\$ \\d{3},\\d{3}</h2>|column-4\">\\d{6}</td>", 0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			html = html.replace("&#8211;", "-");
			info = info.replace("&#8211;", "-");
			plansHtml = plansHtml.replace("&#8211;", "-");
			plansHtml = plansHtml.replaceAll("&nbsp;sq. ft.", " sq. ft.");
			// U.log("#############" + plansHtml);
			String[] sqft = U.getSqareFeet(html + info + inventorydetails + plansHtml+info,
					" \\d,\\d{3}-\\d,\\d{3} sq.ft.|<span>\\d,\\d{3}<br />Sq. Ft.|\\d,\\d{3}<br>Sq. Ft.|\\d{4} sq. ft. - \\d{4} sq. ft|\\d{1},\\d{3} sq. ft. – \\d{1},\\d{3} sq. ft|\\d{4} sq. ft. – \\d,\\d{3} sq. ft|Sq. Ft.: \\d{1},\\d{3} – \\d{1},\\d{3}|[0-9]{1},[0-9]{3} sq. ft. to [0-9]{1},[0-9]{3} sq.|Sq. Ft.: [0-9]{1},[0-9]{3}-[0-9]{1},[0-9]{3}|Sq. Ft.: [0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3}|Sq. Ft.: [0-9]{1},[0-9]{3}\\-[0-9]{1},[0-9]{3}|Sq. Ft.: [0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3}|Sq. Ft.: [0-9]{1},[0-9]{3}|\\d{4} sq\\. ft\\.|Sq. Ft.: \\d,\\d+\\-\\d,\\d+|\\d,\\d+ Sq. Ft|Sq. Ft.: \\d,\\d+|<p>\\d{4} sq. ft.</p>|<p>\\d,\\d+ - \\d,\\d+ sq ft</p>|column-7\">\\d{4}|<p>\\d{1},\\d{3} sq ft</p>|<p>\\d{1},\\d{3} sq ft</p>",
					0);
			// U.log(sqft.);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			html = html.replaceAll(
					"Ready To Move|ready to move in homes|Ask about our Move In Ready Homes|move in ready homes available its time|Elongated commode|Tierra De Este, Villa|Villas del Valle</a></li>|/villas-del-valle/\">Villas|category-villas-del-valle|No more apartment","")
					.replace("\"Single Family Home\"}", "");
			html = html.replaceAll(
					"traditional value[s]* and cutting-edge technology|traditional values and cutting edge technology",
					"traditional homes  values and cutting edge technology");
			if( html.contains("<h2>EXPLORE OUR INVENTORY:</h2>"))html = html+"Inventory Homes Avaiable";
			 U.log("result::"+Util.match(html, ".*Move-in.*"));
			
			if(inventorydetails.length()>4)html += "Inventory Homes Avaiable";
			
			String ptype = U.getPropType(html+info);
			
			html = html.replaceAll("Quick Move|quick-move-ins\"|(r|R)eady to move|[M|m]ove(-)?[I|i]n", "");
			String status = U.getPropStatus(html);
			U.log("Status::: "+status);
			U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "\\w+ 100% Financing - USDA \\w+", 0));
			
			// -------------------------
			html = html.replaceAll("RANCH|ranch|Ranch|1 Story</option>|2 Story</option>", "").replace("1 - 2 Story ", "1 story 2 story");
			String dtype = U.getdCommType(U.getNoHtml(html) + commName +info);
			html = html.replaceAll("show_aggregated|Springs Golf Club", "").replace("lakes in the community", "lakeside living");
			info=info.replace("lakes in the community", "lakeside living");
			String ctype = U.getCommType(html+info);
//				 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+info, "[\\w\\s\\W]{30}lake[\\w\\s\\W]{30}", 0));

			String note = ALLOW_BLANK;

			// ============================================contact us section

			if (add[0].length() < 4 && latlong[0].length() < 4) {
				U.log("Here::");
				String officeaddHtml = U.getHTMLwithProxy("http://saratogahomestexas.com/contact/?city=El%20Pasoo");// http://saratogahomestexas.com/contact/?city=El%20Paso
				String[] offSec = U.getValues(officeaddHtml, "<h3 class=\"widget-title\"><span class=\"widget-inner\">",
						"</div>");
				for (String off : offSec) {
					U.log("Here::");
					String reg = U.getSectionValue(url, "http://", ".");
					if(reg!=null) {
					reg = reg.replace("elpaso", "el paso");
					if (off.contains(reg.toUpperCase())) {
						U.log(off);
						String addrs = U.getSectionValue(off, "<hr />", "<a href=\"");
						U.log(addrs);
						addrs = addrs.replace("<br />", ",");
						String[] ad = addrs.split(",");
						add[0] = ad[0].replaceAll("<p class=\"widget-title\">|<p>", "");
						add[1] = ad[1];
						add[2] = Util.match(ad[2], "\\w{2}");
						add[3] = Util.match(ad[2], "\\d{5}");
						latlong = U.getlatlongGoogleApi(add);
						if(latlong == null) latlong = U.getlatlongHereApi(add);
						note = "Address Is Taken From Contact Us";
						geo = "true";
					}
					}
				}
			}

			if (add[1].contains("Rosenberg TX 77471")) {
				add[1] = "Rosenberg";
				add[2] = "TX";
				add[3] = "77471";
			}
			
			if (url.contains("https://www.townsenlanding.com/website/")) {
				add[0]="";
				add[1] = "Humble";
				add[2] = "TX";
				add[3] = "";
				latlong=U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latlong);
				if(add == null) add = U.getAddressHereApi(latlong);
				geo="TRUE";
				note="Address Taken From City And State";
			}
//			if(url.contains("http://austin.saratogahomestexas.com/communities-and-floorplans/Blackhawk"))
			if (url.contains("http://saratogahomestexas.com/lp/Microsite/lake-shore/website.html"))
				minPrice = "$300,000";// from img
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);	
			data.addCommunity(commName, url, ctype);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(ptype, dtype);
			data.addPropertyStatus(status);
			data.addNotes(note);


		}
		j++;
	}
	*/

//	private String getHtml(String url, WebDriver driver) throws Exception {
//		// WebDriver driver = new FirefoxDriver();
//
//		String html = null;
//		String Dname = null;
//
//		String host = new URL(url).getHost();
//		host = host.replace("www.", "");
//		int dot = host.indexOf("/");
//		Dname = (dot != -1) ? host.substring(0, dot) : host;
//		File folder = null;
//
//		folder = new File(U.getCachePath() + Dname);
//		if (!folder.exists())
//			folder.mkdirs();
//
//		String fileName = U.getCacheFileName(url);
//
//		fileName = U.getCachePath() + Dname + "/" + fileName;
//
//		File f = new File(fileName);
//		if (f.exists()) {
//			return html = FileUtil.readAllText(fileName);
//			// U.log("Reading done");
//		}
//
//		// if(respCode==200)
//		{
//
//			if (!f.exists()) {
//				synchronized (driver) {
//
//					BufferedWriter writer = new BufferedWriter(new FileWriter(f));
//
//					driver.get(url);
//					// U.log("after::::"+url);
//					Thread.sleep(20000);
//					// ((JavascriptExecutor) driver).executeScript(
//					// "window.scrollBy(0,400)", "");
//					Thread.sleep(2000);
//					U.log("Current URL:::" + driver.getCurrentUrl());
//					html = driver.getPageSource();
//					Thread.sleep(5000);
//					writer.append(html);
//					writer.close();
//
//				}
//			} else {
//				if (f.exists()) {
//					html = FileUtil.readAllText(fileName);
//					U.log("Reading done");
//				}
//			}
//			return html;
//		}
//		// else{
//		// return null;
//		// }
//	}

	
	
	
	
	
	
}