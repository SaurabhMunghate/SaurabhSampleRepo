/*
 * Modification Aditya
 */
package com.shatam.b_281_300;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractkolterUrban extends AbstractScrapper {
	static int i = 1;
	static String BASEURL = "http://www.kolterurban.com/";
	static String BASEURL2 = "https://www.kolterhomes.com";
	CommunityLogger LOGGER;
	static int j = 0;
	String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

	// String[] add=new String[3];
	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */

	// http://www.kolterurban.com/
	WebDriver driver= new FirefoxDriver();
	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractkolterUrban();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Kolter Residential - Kolter Urban.csv",
				a.data().printAll());
	}
	
	public ExtractkolterUrban() throws Exception {

		super("Kolter Residential - Kolter Urban", BASEURL);
		LOGGER = new CommunityLogger("Kolter Residential - Kolter Urban");
	}

	public void innerProcess() throws Exception {
		String html = U.getHtml(BASEURL,driver);
		U.log(U.getCache(BASEURL));
		
		
	
		List<String> list = new ArrayList<String>();
		
		String comSectionForNameAddress  = U.getSectionValue(html, "<div class=\"wow fadeInDown\">", "</section>");
		String [] comUrlSections1= U.getValues(comSectionForNameAddress, "<a target=\"_blank\"", "</a></div>");
		for(String comUrlSec : comUrlSections1){
			list.add(comUrlSec);
		}
		Set<String> set=new HashSet<>(list);   //This is remove duplicate values
		U.log(set.size());
		
		String comSection = U.getSectionValue(html, "<div class=\"owl-stage-outer\">", "</section>");
		String [] comUrlSections = U.getValues(comSection, "<a target=\"_blank\"", "</a></div>");
		for(String comUrlSec : comUrlSections){
			String comUrl = U.getSectionValue(comUrlSec, "href=\"", "\"");
//			U.log(comUrl);
			for(String comSec : set){
				String comUrl1 = U.getSectionValue(comSec, "href=\"", "\"");
				if(comUrl.equals(comUrl1)){
					String commName = U.getSectionValue(comSec, "<h5>", "<small>");
//					U.log("Found"+commName);
					String html1 = U.getPageSource(comUrl1);
					if (this.data.communityUrlExists(comUrl1))	return;
					addDetails(comUrl1, commName, comUrlSec+comSec);

				}
			}
		}
		
/*		
		html=U.removeComments(html);
		String urlsection = U.getSectionValue(html,
				"<div id=\"owl-demo\" class=\"owl-carousel owl-theme\">",
				"<a class=\"next\">");
		// U.log(urlsection);
		String urls[] = U.getValues(urlsection, "<div class=\"item col-building co1\">", "</div>");
		// LOGGER.countOfCommunity(urls.length);
		for (String j : urls) {
			// U.log(j);
			String url = U.getSectionValue(j, "<a href=\"", "\"");
			String commName = U.getSectionValue(j, "title=\"View", "\"");
			commName = commName.replaceAll("\\s{3}", "");

			

//			addDetails(url, commName, j);
			i++;
		}
*/	
		LOGGER.DisposeLogger();
		driver.close();
	}

	public void addDetails(String url, String commName, String info)	throws Exception {
//		if(j==2)
		{
		
	//	if(!url.contains("https://www.moderneboca.com/?referer=KolterUrban.com")){return;}
		U.log("info:::::::::::"+info);

			U.log("url:-"+url);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK, minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		String html = U.getPageSource(url);
		String communitytype = U.getCommunityType(html + info);
		// U.log(communitytype);
		String dtype = U.getdCommType(html.replace("41-","41")+ info);
		// U.log(dtype);
		html=html.replaceAll("Under|under|participation|Participation|villa residences|Villa Residences|villa.php|Gallery Grand Opening","");
		String url2=url.replace("/?referer=KolterUrban.com", "");
		String featur=U.getHTML(url2+"/residences/features");
		String featur1=ALLOW_BLANK;
		if(featur!=null)
		featur1=U.getSectionValue(featur,"<main class=\"wrap-block content-page\" role=\"main\">", "<footer class=\"wrap-block\">");
		String proptype = U.getPropType(html +featur1+ info.replace("participation",""));
		// U.log(proptype);
		html = html.replaceAll("Tower Just Released|SOLD OUT\\s+</a>", "");
		String propstatus = U.getPropStatus(html + info.replace("Under",""));
		// U.log(propstatus);

		if (this.data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl("******Repeated******" + url);
			return;
		}
		LOGGER.AddCommunityUrl("Community Url::" + url);
		String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE"; 
		
		String addSec = U.getHardcodedAddress("Hardcode_KolterUrban", url);
		U.log("AddSec==="+addSec);
		String vals[] = addSec.split(",");
		add[0] = vals[0];
		add[1] = vals[1];
		add[2] = vals[2];
		add[3] = vals[3];
		latLng[0] = vals[4];
		latLng[1] = vals[5];
		geo = vals[6];
		if(latLng[0].isEmpty() && latLng[1].isEmpty()){
			latLng = U.getlatlongGoogleApi(add);
		}
		
		if(url.contains("https://www.theresidencessarasota.com/?referer=KolterUrban.com"))
		{
			
			minSqf="2707";
			maxSqf="4753";			
			dtype = "19 Story";
		}

		if(url.contains("https://www.waterclubliving.com/north-palm/?referer=KolterUrban.com"))
		{
			
			minPrice ="$900,000";
			maxPrice = "$3,000,000";
			minSqf = "1728";
			maxSqf = "4338";
			communitytype="Golf Course, Country Club, "+communitytype;
			proptype +=",Single Family,Loft";
			dtype = "2 Story,3 Story,20 Story";
		}
		if(url.contains("https://www.onestpetersburg.com/?referer=KolterUrban.com"))
		{
			
			minSqf = "1572";
			maxSqf = "4873";
			minPrice = "$600,000";
		}
		
		if(url.contains("https://www.vuesarasotabay.com/?referer=KolterUrban.com"))
		{
			
			minPrice = "$1,500,000";
//			maxPrice = "$3,400,000";
			minSqf = "1515";
			maxSqf = "3415";
			communitytype="Resort Style";
			
		}
	

		if(url.contains("https://www.5000nocean.com/?referer=KolterUrban.com"))
		{
		minSqf = "3211";
			maxSqf = "6314";
			minPrice = "$2,000,000";
		}
		if(url.contains("https://www.themarksarasota.com/?referer=KolterUrban.com"))
		{
			communitytype = "Resort Style";
			minSqf = "1437";
			maxSqf = "2969";
			minPrice="$600,000";
			dtype = "5 Story";
		}
		if(url.contains("https://www.moderneboca.com/?referer=KolterUrban.com"))
		{
			minSqf="2128";
			maxSqf="2890";
			minPrice = "$500,000";
			maxPrice = "$625,000";
			proptype = "Townhomes,Luxury Homes";
		}
		if(url.contains("onehundredlasolas")){
			minPrice="$800,000";
			minSqf="1501";
			maxSqf="3522";
		}
		data.addCommunity(commName.toLowerCase(), url, communitytype);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(ALLOW_BLANK);
	}j++;
	}
}



