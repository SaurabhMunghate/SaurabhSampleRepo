
package com.shatam.b_281_300;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class SaintAubynHomes extends AbstractScrapper {
	
	int i=0;
	static int duplicates=0;
	int j=0;
	  public int inr=0;
	  WebDriver driver = null;
	  String baseUrl="https://www.saintaubynhomes.com";
	  CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new SaintAubynHomes();
		//U.logDebug(true);
		a.process();
		
		FileUtil.writeAllText(U.getCachePath()+"Saint Aubyn Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public SaintAubynHomes() throws Exception {

		super("Saint Aubyn Homes", "https://www.saintaubynhomes.com/");
		LOGGER=new CommunityLogger("Saint Aubyn Homes");
	}

	public void innerProcess() throws Exception
	{
		//U.setUpGeckoPath();
		U.setUpChromePath();
		driver = new ChromeDriver();//new FirefoxDriver();
		ArrayList<String> CommSec=new ArrayList<String>();
		String CommSec1[]=null;
		String html=U.getHtml("https://saintaubynhomes.com/", driver);
		String sec=U.getSectionValue(html,"Neighborhoods</span><span class=\"w-nav-arrow\"></span>", "</ul>");
		U.log("sec::::::"+sec);
		//ArrayList<String> regionUrl=Util.matchAll(sec, "href=\"(.*?)\"", 1);
		String regionUrl[]=U.getValues(sec,"href=\"","\">");
		
		//U.log(regionUrl.size());
		
		for(String region:regionUrl)
		{
			U.log("region:::::::"+region);
			String regnHtml=U.getHtml(region, driver);
			regnHtml = regnHtml.replace("<a href=\" https:", "<a href=\"https:");
			CommSec1=U.getValues(regnHtml,"<a class=\"neighborhoods\"","Find Your New Home</a></p>");
			if(CommSec1.length == 0)
				CommSec1=U.getValues(regnHtml,"href=\"", "\"");//Util.matchAll(regnHtml, "<li class=\"cat-list-row(.*?)</span>",0);
			U.log(CommSec1.length);
			for(String commuinity:CommSec1)
			 {
//				U.log("commuinity:::::::::::"+commuinity);
//				
				 addDetails(commuinity);
			 }
		}
		LOGGER.DisposeLogger();
		driver.quit();
	}
	
	public void addDetails(String commsec) throws Exception
	{
		
	if(j>=5)
		{
		String commUrl=U.getSectionValue(commsec, "href=\"","\">");
			U.log(commUrl);
		U.log(j+":::::::::::::::"+commsec);
		if(commUrl.contains("https://saintaubynhomes.com/2017/03/16/like-a-good-neighbor-saint-aubyn-is-there/"))return; //---not a community url---
		
		//========= Single Run ===========================================================
	//	if(!commUrl.contains("https://tralonhomes.com/mountains-edge"))return;
		
        if (data.communityUrlExists(commUrl)){
        	LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
        	return;
        }
        LOGGER.AddCommunityUrl(commUrl);
        
		String html = U.getHtml(commUrl, driver);
		U.log("-------------->"+U.getCache(commUrl));
		//U.log(html);
		html = html.replace("town homey atmospher", "");
		String commName = U.getSectionValue(html, "<h1>", "<");
		String comNameSec = U.getSectionValue(html, "\"itemListElement\": [", "]");
		if(comNameSec!=null) {
			comNameSec = U.getSectionValue(comNameSec, "\"position\": 2,", "}");
			commName = U.getSectionValue(comNameSec, "\"name\": \"", "\"");
		}
		commName=commName.replace("Saint Aubyn Homes | Premiere Colorado Home Builder |", "").replace("saint aubyn homes | premiere home builder |\\|St Aubyn Homes", "");
		
		commName=commName.replace("Mountain�s Edge", "Mountains Edge").replace("- St Aubyn Homes","").replaceAll("New Homes in|Homes for Sale|Colorado Springs \\| Saint Aubyn Homes| \\| Saint Aubyn Homes \\| Colorado Home Builder| \\| St Aubyn Homes", "").replace("Star Ranch Colorado Springs", "Star Ranch").trim();
		
		U.log(commName);
		
		//Html
		String commHtml=U.getHTML(commUrl);	
		
		if(commUrl.contains("/the-ridge/"))
			commHtml=commHtml.replace("mid-300s", "the mid 300,000").replace("prices start in the high 300�s", "prices start in the high 300,000");
		
		String priceSec=U.getSectionValue(commHtml, "<p><span class=\"firstletter\">", "</p>");	
		if(priceSec!=null)
		priceSec=priceSec.replace("0s", "0,000 ");
//		priceSec=priceSec.replace("the mid-$400,000", "the mid-$400,000");
		U.log(priceSec);
		//----------------------Price---------------------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		commHtml=commHtml.replace("0s", "0,000").replace("0’s", "0,000").replace("0�s","0,000").replace("0K�s","0,000").replace("00K’s","00,000" );
//		U.log(commHtml);
		U.log(commUrl);
		ArrayList<String> plans = Util.matchAll(commHtml, "IDX-showcaseContainer\" style=\"height: \\d+px;\"><a href=\"(.*?)\"",1);
		/*if(plans.length==0)
		{
			plans=U.getValues(html, "class=\"IDX-showcaseContainer\" style=\"height: 158px;\"><a href=\"", "\"");
			//U.log(plans[0]);
		}
		if(plans.length==0)
			plans=U.getValues(html, "</div>        </a><a href=\"", "\"");*/
		
		String allPlanData = "";
		for(String plan : plans)
		{
			if(!plan.startsWith("https:"))plan=plan.replace("http:", "https:");
			U.log("planUrl ::"+plan);
			
			String plnsHtml = U.getHtml(plan,driver);
			
			String one = U.getSectionValue(plnsHtml, "Listing ID</span>", "Contact - Listing");
			
			String two = "";
			if(one == null)
			 two = U.getSectionValue(plnsHtml, "Listing ID</span>", "<script type=\"application/ld+json\">")+U.getSectionValue(plnsHtml, "\"listingID\":\"924747\",", ",\"idxID\"")+U.getSectionValue(plnsHtml, "<div class=\"idx-details__main\">", "CLEAR</button>");
			
			allPlanData +=  one + two;
		}
		
		//priced from the mid-300s to the mid-400s
//		U.log(allPlanData);
		
//		
		commHtml=commHtml.replace("400s", "mid $400,000");
		commHtml=commHtml.replace("mid-300s", "the mid 300,000").replace("0s", "0,000").replace("0�s","0,000");
		String[] price = U.getPrices((commHtml.replace("mid 400�s", "mid $400,000")+allPlanData+priceSec), "mid \\$\\d{3},\\d{3}|the mid\\-\\$\\d{3},\\d{3}|the mid\\-\\$\\d{3},\\d{3}|\\d,\\d{3}\r\n\\s+</span><span class=\"IDX-label\">SqFt|\\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+|low [0-9]{3},[0-9]{3}|start in the \\d+,\\d+|the mid( |-)\\d{3},\\d{3}|the high \\d{3},\\d{3}|priced from the mid-\\d{3},\\d{3}|priced in the mid-\\d{3},\\d{3}", 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log(Util.matchAll(commHtml, "[\\s\\w\\W]{30}priced from the mid[\\s\\w\\W]{30}", 0));
		
		//---------------------Sqft-----------------------------
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		
		if(allPlanData !=null)
			allPlanData = allPlanData.replaceAll("\n\\s+</span><span class=\"IDX-label\">SqFt", "SqFt").replaceAll("\\d+ sq ft unfinished basement|\\d+ sq ft unf bsmt", "");
			
//		U.log(planHtml);
		String[] sqft = U.getSqareFeet(commHtml+allPlanData, 
				"\\d{4} total sq ft|\\d{4} sq ft|\\d{4} finished sq ft<br>|\\d{4} total sq ft.|\\d,\\d{3}SqFt|SqFt</span><span class=\"IDX-text\">\\s+\\d,\\d{3}|sqft\">\\d{1,},\\d+|Sq. Ft.: </strong>\\d,\\d+|\\d+ and \\d+.</p>|<span class=\"IDX-detailsSpecText\">\\d,\\d{3}<|Square Feet</span><span class=\"IDX-text\">\\W+\\d,\\d{3}|\\d{4} sq ft |\\d{4} total SQF|\\d{4} Sq Ft", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//		U.log(Util.matchAll(allPlanData, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));
		
		//=============note==================
		String note = ALLOW_BLANK;
		
		//==============Adrress && LatLng=========================
		String latLong[]={ALLOW_BLANK,ALLOW_BLANK};
		String[] address={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};		
		String geoCode = "False";
 		
		String addressSec=U.getSectionValue(html, "strong>Location:"," href=");
		if(addressSec == null)
			addressSec=U.getSectionValue(html, "<b>Location:</b>","<a");
		if(addressSec == null)
			addressSec=U.getSectionValue(html, "Model:</strong>","</p>");
		U.log("addressSec1 : "+addressSec);
		if(addressSec!=null){
			addressSec = addressSec.replaceAll("</p>|<p>|<a rel=\"noopener noreferrer\" target=\"_blank\"|<u>|</u>", "");
			addressSec = addressSec.replace("<br />", ",");//.replace(", CO ", ", CO, ");
			if(addressSec.contains("Directions"))
			{
				addressSec=U.getSectionValue(addressSec, "</strong>","Directions");
			}
			addressSec=addressSec.replace("Court","Court,").replace(" Street", " Street,").replaceAll("(Drive|Dr)<br>", "$1,").replace("Colorado Springs CO", "Colorado Springs, CO")
					.trim().replaceAll("^<br>|<br>$", "").trim();
			addressSec=addressSec.replace("<br>", ",").replace(",,", ",");

			U.log("addressSec2 : "+addressSec);
			if(addressSec.length() >150){
				addressSec = U.getSectionValue(addressSec, "<div>", "<div class=\"");
			}
			addressSec = addressSec.replaceAll("</div> </div>|<strong>|<a", "").replace("(By Appointment Only)", "").replaceAll("</div>\\s+<div>", ",");
			U.log("----->"+addressSec);
			address = U.findAddress(addressSec);
			if(address==null)address = U.getAddress(addressSec);
			
		}
		if(addressSec!=null && address==null) {
			address = new String[]{ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			addressSec= addressSec.replace("(By Appointment Only)", "");
			if(addressSec.split(",").length == 3) {
				address[0]=addressSec.split(",")[0];
				address[1]=addressSec.split(",")[1];
				address[2]=addressSec.split(",")[2];
				latLong = U.getlatlongGoogleApi(address);
				if(latLong == null) latLong = U.getlatlongHereApi(address);
				String add[] = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				address[3] = add[3];
				geoCode="TRUE";
			}
		}
		U.log("Add ---->"+Arrays.toString(address));
		
		String latLngSec = Util.match(html, "https://www.google.com/maps/place/(.*?)/@(.*?),\\d+z/data",2);
		if(latLngSec != null){
			latLong = latLngSec.split(",");
		}
		U.log("LatLng--->"+latLong[0]+" "+latLong[1]);
	
		
		/*	if address & lat-lng both are not present on community page
		then consider address of sales offices*/
		
		if(address[0].length()<4 && latLong[0].length()<4){
			addressSec = U.getSectionValue(commHtml, "Sales Office:", "<a href=\"");
			U.log("Sales of Address : "+addressSec);
			if(addressSec !=null)
			{
				addressSec  =addressSec.replace("<br>", ",").replaceAll("Drive\\s*Colorado Springs\\s*CO", "Drive, Colorado Springs, CO").replaceAll("Heritage Ridge ", "").replaceAll("</strong><br>|<br></strong>", "");
				address = U.findAddress(addressSec);
				String ad[]=address;
				U.log(address[0]);
				ad[0]=ad[0].replace("5614 carmon", "carmon");
				latLong = U.getlatlongGoogleApi(ad);
				if(latLong == null) latLong = U.getlatlongHereApi(ad);
				geoCode = "TRUE";
				U.log("Sales add--------------->"+Arrays.toString(address)+"kkkkk");
			}
			else{
				address[0] = U.getSectionValue(commHtml, "IDX-showcaseAddress IDX-showcaseAddressElement\">", "<");
				address[1] = U.getSectionValue(commHtml, "showcaseAddressElement IDX-showcaseCity\"> ", "<");
				address[2] = U.getSectionValue(commHtml, "showcaseAddressElement IDX-showcaseStateAbrv\">", "<");
				address[3] = U.getSectionValue(commHtml, "AddressElement IDX-showcaseZipcode\"> ", " <");
			}
		}
		if(commUrl.contains("https://saintaubynhomes.com/the-ridge-at-sand-creek/")) {
			addressSec= U.getSectionValue(commHtml, "<p><strong>Model:", "<a href=\"");
			U.log(addressSec);
			if(addressSec!=null)
				{
					addressSec= addressSec.replaceAll("<br>\\s*</strong>Visit us at Lorson Ranch to tour models of these new homes:<br>", "");
					addressSec= addressSec.replace("<br>", ",").replace("Colorado Springs CO 80925,", "Colorado Springs, CO 80925");
					address= U.getAddress(addressSec);
				}
		}
		//-------Address taken from contact us page----------
		if( commUrl.contains("https://saintaubynhomes.com/thompson-crossing/")){
			address[0] = "212 N Wahsatch Ave # 201";
			address[1] = "Colorado Springs";
			address[2] = "CO";
			address[3] = "80903";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null)latLong = U.getlatlongHereApi(address);
			geoCode = "TRUE";
			note = "Address Taken From Contact Us Page";
		}
		if(commUrl.contains("/hidden-valley-farm/")) {
			address[0] = "1287 Bakers Pass St";
			address[1] = "Severance";
			address[2] = "CO";
			address[3] = "80550";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null)latLong = U.getlatlongHereApi(address);
			geoCode = "TRUE";
		}
		if(commUrl.contains("bradley")){
			address[0] = "-";
			address[1] = "Colorado Springs";
			address[2] = "CO";
			address[3] = "-";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null)latLong = U.getlatlongHereApi(address);
			address =U.getAddressGoogleApi(latLong);
			if(address == null) address = U.getAddressHereApi(latLong);

			geoCode = "TRUE";
			note = "Address & Lat-Lng Taken From City & State";

		}
		if(commUrl.contains("mountains-edge")){
			address[0] = "-";
			address[1] = "Fort Collins";
			address[2] = "CO";
			address[3] = "-";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null)latLong = U.getlatlongHereApi(address);
			address =U.getAddressGoogleApi(latLong);
			if(address == null) address = U.getAddressHereApi(latLong);

			geoCode = "TRUE";
			note = "Address & LatLong Taken From City & State";

		}
		if(commUrl.contains("sorrento")){
			address[0] = "-";
			address[1] = "Mead";
			address[2] = "CO";
			address[3] = "-";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null)latLong = U.getlatlongHereApi(address);
			address =U.getAddressGoogleApi(latLong);
			if(address == null) address = U.getAddressHereApi(latLong);

			geoCode = "TRUE";
			note = "Address & LatLong Taken From City & State";

		}
		if(commUrl.contains("kitchel-lake")){
			address[0] = "1520 Larimer Ridge Parkway";
			address[1] = "Timnath";
			address[2] = "CO";
			address[3] = "80547";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null) latLong = U.getlatlongHereApi(address);
			geoCode = "TRUE";
			

		}
		
		if(commUrl.contains("meridian-ranch") || commUrl.contains("star-ranch") || commUrl.contains("paint-brush-hills")|| commUrl.contains("the-sands")){
			address[0] = "-";
			address[1] = "Colorado Springs";
			address[2] = "CO";
			address[3] = "-";
			latLong = U.getlatlongGoogleApi(address);
			if(latLong == null)latLong = U.getlatlongHereApi(address);
			address =U.getAddressGoogleApi(latLong);
			if(address == null) address = U.getAddressHereApi(latLong);
			geoCode = "TRUE";
			note = "Address & LatLong Taken From City & State";

		}
		
		if(address[0] != ALLOW_BLANK && address[3] != ALLOW_BLANK){
			if(latLong[0] == ALLOW_BLANK && latLong[1] == ALLOW_BLANK){
				latLong = U.getlatlongGoogleApi(address);
				if(latLong == null)latLong = U.getlatlongHereApi(address);
				geoCode = "True";
			}
		}
		if(address[0] != ALLOW_BLANK && address[3] == ALLOW_BLANK){
			if(latLong[0] == ALLOW_BLANK && latLong[1] == ALLOW_BLANK){
				latLong = U.getlatlongGoogleApi(address);
				if(latLong == null)latLong = U.getlatlongHereApi(address);
				address=U.getAddressGoogleApi(latLong);
				geoCode = "True";
			}
		}
		
		//========Status===============
		commHtml = commHtml.replaceAll("Hours:</strong><br>\\s+Coming|</strong><br />\\s*Coming Soon</p>|NEW HOME READY NOW!|Model opening October|NOW SELLING! Within minutes| Coming soon a swimming pool|Remarks\">Only 22 lots left! The S|<div class=\"IDX-showcaseRemarks\">Only 28 lots left in Star Ranch|rks\">Only 22 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 22 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 28 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 22 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 22 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 22 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 22 lots left in Star Ranch, with both spec, \"IDX-showcaseRemarks\">Only 22 lots left! The Summi|owcaseRemarks\">Only 22 lots left in Star |COMPLETED HOME, MOVE|The last 30 lots are now available a| in Lorson Ranch for opening Fall 2019", "");
		String pStatus=U.getPropStatus(commHtml);
//		if(commUrl.contains("mountains-edge"))commName="Mountain's Edge";

		commHtml=commHtml.replaceAll("Carriage Hills|carriage-hills|Star Ranch|star-ranch", "");
		U.log(commName+"::::::::::::commName");

		commName = commName.toLowerCase().replace(address[1].toLowerCase(),"").replace(",", "").replace("saint aubyn homes | premiere home builder |","")
				.replaceAll("  from st aubyn homes| at harmony road", "").replaceAll("star ranch  in", "star ranch");
		commName = commName.replace("  co | new", "").replace(" farm  co", "").replace("saint aubyn homes | colorado home builder | ", "");
		String pType=U.getPropType((commHtml+allPlanData).replace("Patio Description", "Patio-style home").replaceAll(" traditional subdivision|Stone Cottage Grove|-Cottage-", ""));
		
		if(pType.contains("Townhome") && pType.contains("Townhouse"))
			pType = pType.replaceAll("Townhouse,|Townhouse", "");
		
		if(allPlanData!=null)
			allPlanData = allPlanData.replace("Stories</strong>: 1", " Story 1 ");
		
		String dType=U.getdCommType((commHtml+allPlanData+commUrl).replaceAll("ranch|Ranch|RANCH", " Ranch "));
		if(commUrl.contains("https://saintaubynhomes.com/meridian-ranch/"))pType ="Single Family, Patio Homes";

//		
		U.log(commName.contains("ranch"));
		if(!commName.contains("ranch"))dType=dType.replace("Ranch", ALLOW_BLANK);
		if(commUrl.contains("https://saintaubynhomes.com/mountains-edge/"))	minPrice="$400,000";
			
		allPlanData = allPlanData.replace("town homey atmospher", "");
		address[0]=address[0].replace("Location", "");
		
		if(commUrl.contains("https://tralonhomes.com/mountains-edge/")) {minPrice="$400,000";maxPrice="$429,500";}
		
		data.addCommunity(commName, commUrl,U.getCommunityType(commHtml+allPlanData));
		data.addAddress(address[0], address[1],address[2].trim(),address[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(),latLong[1].trim(),geoCode);
		data.addPropertyType(pType,dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);

	}j++;
	}

	
}
