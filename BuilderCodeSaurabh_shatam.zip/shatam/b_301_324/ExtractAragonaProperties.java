/**
 * @author Upendra Singh 
 * @date 07/2017
 * 
 */
package com.shatam.b_301_324;

import java.io.IOException;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractAragonaProperties extends AbstractScrapper{
	private static String builderUrl = "http://aragonaproperties.com/";
	private static String builderName = "Aragona Properties";
	private static String fileUrl = U.getCachePath()+"Aragona Properties.csv";
	private CommunityLogger LOGGER;
	int j = 0;
	private String propertType;

	public ExtractAragonaProperties() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractAragonaProperties();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Aragona Properties.csv", a.data()	.printAll());
	}

	@Override
	protected void innerProcess() throws Exception { 
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("http://apartments.aragonaproperties.com/listings");
		String [] commSec=U.getValues(mainHtml,"<div class=\"rl-title\">","<div class=\"rl-favorite\">");
		U.log("Total Community--->"+commSec.length);
		for(String sec:commSec)
		{
			String url="http://apartments.aragonaproperties.com"+U.getSectionValue(sec, "<h2><a href=\"","\"");
			//U.log(sec);
			String comName=U.getSectionValue(sec, "\">","</a>");
			addDetails(url,comName,sec);
		}
		LOGGER.DisposeLogger();
	}
	private void addDetails(String commUrl, String comName, String mainSec) throws Exception {
		// TODO Auto-generated method stub
		
	//if(!commUrl.contains("http://apartments.aragonaproperties.com/1454-N-Rochester-Rd-Rochester-Hills-MI-48307"))return;
		String html=U.getHTML(commUrl);
		
	//===========================================Community Name==============================================
		String communityName=comName.replace("Apartments &amp; Townhomes","").trim();
		if(communityName.endsWith("Apartments"))communityName = communityName.replace("Apartments", "");
		U.log("community name--->"+communityName+"<-----------");
		
	//==========================================Address Sec==================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latLong={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html, "Address:</h3>","</p>");
		add[0]=U.getSectionValue(addSec, "\">","<br />");
		addSec=U.getSectionValue(addSec, "<br />","<br />");
		String[] tempAdd=addSec.split(",");
		if(tempAdd.length==2)
		{
			add[1]=tempAdd[0];
			add[3]=Util.match(tempAdd[1],"\\d{4,6}");
			add[2]=tempAdd[1].replace(add[3],"").trim();
		}
		U.log("Addtress-->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		String latSec=U.getSectionValue(html, "google.maps.LatLng(",")");
		latLong=latSec.split(",");
		U.log("LatLong---->"+latLong[0]+" "+latLong[1]);
		
	//==================================================Price Sec================================================
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		String[] price=U.getPrices(mainSec+html,"\\$\\d{3},\\d{3}",0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
	//=====================================================Sq.FT Sec============================================
		String minSqf=ALLOW_BLANK;
		String maxSqf=ALLOW_BLANK;
		String[] sqft=U.getSqareFeet(mainSec+html,"\\d,\\d{3} sq ft|\\d{3,4} sq ft",0);
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
	//==================================================CommunityType=============================================
//		html=html.replace("3 floor levels"," 3 Story ");
//		html=html.replace("5-8 stories", " 5 Story, eight-story ");
		String communityType=U.getCommunityType(mainSec+html);
	
	//==================================================D Property Type============================================
		html=html.replaceAll("lofts|Lofts|floor","").replace("1-4 stories"," 1 Story,  2 Story,  3 Story, 4 Story ")
				.replace("5-8 stories", " 5 Story, 6 Story, 7 Story, 8 Story ");
		String dPType=U.getdCommType(mainSec+html);
//		U.log("MMMMMMMMM "+Util.matchAll(html+mainSec,"[\\s\\w\\W]{300}7 Story[\\s\\w\\W]{300}", 0));
	//================================================== Property Type============================================
		html = html.replace("Six Luxury One &amp; Two Bedroom Apartments", "luxury homes and apartment home").replaceAll("alt=\"Custom Designer|title=\"Custom Designer|Caption\":\"Custom Designer Closet Systems\"|cozy courtyards", "");
		String section = U.getSectionValue(html, "<div class=\"aspNetHidden\">", "<div align=\"center\">") + U.getSectionValue(html, "<div class=\"aspNetHidden\">", "Google Maps</a>")+U.getSectionValue(html, "var amenitiesList =", "}]}};");
		String pType=U.getPropType((mainSec+section).replace("amenityName\":\"Patio", "Patio Home").replaceAll("City Loft", ""));
		
	//==================================================Status Sec================================================
		//U.log(mainSec);
		String pStatus=U.getPropStatus((mainSec+html));
		
	//===============================================Note=========================================================
		String note=U.getnote(html);
		
		if(data.communityUrlExists(commUrl)){
			j++;
			LOGGER.AddCommunityUrl("repeated**********"+commUrl);
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(communityName.replace("South Main", "").toLowerCase(), commUrl, communityType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(),geo);
		data.addPropertyType(pType, dPType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}
	
	

}
