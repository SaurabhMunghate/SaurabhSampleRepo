package com.shatam.b_301_324;

import java.io.IOException;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;

/*
 * 
 * @author : Ranjna Sharma
 * @date : 29/05/2019
 * 
 */

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractColinaHomes extends AbstractScrapper {
	static String builderName = "Colina Homes";
	static String builderUrl = "https://www.colinahomes.com"; //https://colinahomes.com/";
	CommunityLogger logger;
	static int dupli = 0;
//	WebDriver driver = null;

	public static void main(String[] args) {
		try {
			AbstractScrapper abS = new ExtractColinaHomes();
			abS.process();
			FileUtil.writeAllText(U.getCachePath() + builderName + ".csv", abS.data().printAll());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ExtractColinaHomes() throws Exception {
		super(builderName, builderUrl);
		logger = new CommunityLogger(builderName);
	}

	@Override
	protected void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		WebDriver driver = new FirefoxDriver();
//		
//		String mainhtml=U.getHtml("https://www.colinahomes.com/communities", driver);
		
	String html = U.getHTML("https://apps.elfsight.com/p/boot/?w=59933c44-dd4d-41dd-beb1-e0d232abacf5");
	String comSec = U.getSectionValue(html, "\"markers\":[", "]");
		String [] sections = U.getValues(comSec, "{", "}");
		U.log(sections.length);
		for(String sec : sections){
			
			sec = sec.replace("\\/", "/");
			//U.log("sec: "+sec);
			String commURL= U.getSectionValue(sec, "\"infoSite\":\"", "\"");
			U.log(commURL);
			if(commURL!=null) {
					if(!commURL.contains("http://www."))	
						commURL = "https://www."+commURL;
				String commName =U.getSectionValue(sec,"\"infoTitle\":\"", "\"");
				String comPriceSec = U.getSectionValue(sec, "\"infoDescription\":\"", "\"").replaceAll("s&nbsp;|s", ",000");
				if(commURL.contains("/w-35th-st"))commName="W 35th Street";
			
//				try {
					addDetails(commURL, commName, comPriceSec, sec);
//				} catch (Exception e) {}
				
			}
		}
		//addDetails("https://www.colinahomes.com/avondale", "Avondale", "","");
		addDetails("https://www.colinahomes.com/jacquelyn", "Jacquelyn Drive", "","");
		logger.DisposeLogger();
//		driver.quit();
	}

	int i = 0;

	private void addDetails(String commURL, String commName,String comPriceSec, String baseHtml) throws Exception {
	
//		if(i >= 12)
		{
			
			commURL = commURL.replace("http:", "https:")
					.replace("https://www.https", "https");
//
			if(commURL.contains("https://www.har.com/houston/realestate/for_sale?streetaddress=5845+E+Post+Oak+Lane")) 
				commURL = "https://www.colinahomes.com/uptown-north";
			
			//TODO : For Single Community Execution
//		if(!commURL.contains("https://www.colinahomes.com/marlow-lake"))return;
			
			if(commURL.contains("https://www.colinahomes.com/herons-landing")|| commURL.contains("/sterling-lakes")||commURL.contains("/uptown-north")
					||commURL.contains("/balmoral-1")|| commURL.endsWith("https://www.") || commURL.contains("https://www.colinahomes.com/millcreek")||commURL.contains("https://www.colinahomes.com/arbor-trails")
					||commURL.contains("https://www.colinahomes.com/glendale-lakes") || commURL.contains("https://www.colinahomes.com/avondale")
					|| commURL.contains("https://www.colinahomes.com/balmoral")||commURL.contains("https://www.colinahomes.com/hidden-creek-preserve")||
					commURL.contains("https://www.colinahomes.com/tidwell-lakes"))
			{
				logger.AddCommunityUrl(commURL+"....Page not found");
				return; //not open
			}
			
			
			if(data.communityUrlExists(commURL)) {
				logger.AddCommunityUrl(commURL+">>>>>>>Repeated>>>>>>>>");
				return;
			}
			logger.AddCommunityUrl(commURL);
			
			
			U.log(i + " ] : url*********" + commURL);
			U.log(U.getCache(commURL));
			//U.log(baseHtml);
			U.log(comPriceSec);
			U.log(commName);
			String html = U.getHTML(commURL);
			// ----------------------------- geo code-----------------------------
			String geo = "False";
			// U.log(html);
			// ----------------------------- Community address-----------------------------
			// String address = ALLOW_BLANK;
			String notes = ALLOW_BLANK;
			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String latLon[] = {ALLOW_BLANK,ALLOW_BLANK};
			String lat = ALLOW_BLANK, lon = ALLOW_BLANK;
			
				
				//================== address from ,map ==========
			String addSec = U.getSectionValue(baseHtml, "\"position\":\"", "\"");
			
			
				if(add[0]==ALLOW_BLANK || add[0]==null) {
					if(commURL.contains("https://www.colinahomes.com/mill-creek") || commURL.contains("https://www.colinahomes.com/avondale")) 
						addSec = U.getSectionValue(html, "Model home address:<br></strong>", "</p>");
//					if(commURL.contains("https://www.colinahomes.com/avondale")) addSec = "6433 Macroom Meadows, Houston, TX 77048";
					if(commURL.contains("https://www.colinahomes.com/spring-branch"))
					addSec = "9002 Lonestar River Ln, Houston, TX 77080";
					
					if(commURL.contains("https://www.colinahomes.com/jacquelyn"))
						addSec = "7711 Rainbow Close Ln, Houston, TX 77055";
						if(commURL.contains("https://www.colinahomes.com/mill-creek"))
							addSec = "10005 Ocelot Court, Magnolia, TX 77354";
					U.log("Add sec"+addSec);
					if(addSec!=null) {
						
						U.log(">>>>>>>>>>> "+addSec);
						addSec = addSec.replace("Splendora", ", Splendora").replace("Pasadena", ", Pasadena")
								.replace("Katy", ",  Katy").replace("Rosharon", ",  Rosharon").replace("Texas City", ",  Texas City").replace("Dickinson", ",  Dickinson").replace("Conroe", ",Conroe").replace("Humble", ", Humble").replace(" Houston", ",  Houston").replace(",,", ",")
								.replace("Houston TX", "Houston, TX").replace("<br>", ",").replace("2723\\u00a0Bayrose\\u00a0Drive", "13217 Anchor Bay Drive");
						addSec = addSec.replaceAll("<.*?>", "");
						U.log("addSec ::"+addSec);
						add = U.getAddress(addSec.replaceAll(",\\s+,\\s+", ", "));
						U.log("Map Address:::: "+Arrays.toString(add));
						}
					String latlng = U.getSectionValue(baseHtml, "\"coordinates\":\"", "\"");
					if(latlng == null){
						addSec = U.getSectionValue(html, "Model home address:<br></strong>", "</p>");
						if(addSec != null){
							latlng = U.getSectionValue(addSec, "/@", ",17z/");
							U.log("latlngSec ::"+latlng);
						}
					}
					if(latlng!=null) {
						
						latLon = latlng.split(",");
						U.log("Map Latlng:::: "+Arrays.toString(latLon));
					}
					
				}
			
				if(add[3] == ALLOW_BLANK) {
					
					add = U.getAddressGoogleApi(latLon);
					if(add == null) add = U.getAddressHereApi(latLon);
					geo = "TRUE";
				}
				if(latLon[0] == ALLOW_BLANK){
					latLon = U.getlatlongGoogleApi(add);
					if(latLon == null)latLon = U.getlatlongHereApi(add);
					
					geo="TRUE";
				}
			// ----------------------------- Community min and max SqFt, min and max
			// price ----------------------------		
				U.log("ddddddd"+commURL);
			String buildHtml = U.getHTML(
					commURL.replace("our-communities", "build-a-home").replace("tidwell-lakes-2", "tidwell-lakes").replace("wedgewoodforest", "wedgewood-forest"));
			U.log(U.getCache(commURL));
			if (commURL.contains("https://colinahomes.com/etteridge/")) {
				U.log("Build Url : " + U.getSectionValue(html,
						"<div style=\"width: auto; text-align: center; margin: 15px auto;\"><a href=\"", "\""));
				buildHtml = U.getHTML(U.getSectionValue(html,
						"<div style=\"width: auto; text-align: center; margin: 15px auto;\"><a href=\"", "\""));// plz
																												// check
																												// if
																												// any
																												// update
			}
			String floorHtml=ALLOW_BLANK;
//			U.log(o);
		//	String[] Urlsec=U.getValues(html, "data-button-size=\"medium\">", "</div></div></div>");
			if(Util.match(html, "Floor Plans\\s+</a>")!=null||html.contains("floor plan</a>")||html.contains("Floor plans</a>")||html.contains("Floor Plan</a>") || html.contains("Floor Plans</a>") || html.contains(">floor plans</a>")) 
			{
				String urls[]=U.getValues(html, "class=\"sqs-block-button-container sqs-block-button-container", "</a>");
				for (String u : urls) {
					if(u.contains("Floor Plans")) {
						String floorUrl = U.getSectionValue(u, "href=\"", "\"");
						if(!floorUrl.startsWith("http")) floorUrl = builderUrl + floorUrl;
						U.log("FloorPlan:\t" + floorUrl);
						U.log(U.getCache(floorUrl));
						floorHtml=U.getHTML(floorUrl.trim());
						

					}
				}
				
//				U.log(">>>>>>>>>>>>>>>>>>"+Util.matchAll(floorHtml, "[\\s\\w\\W]{30}266[\\s\\w\\W]{30}", 0));
			}

			if(commURL.contains("https://www.colinahomes.com/cobblestone"))
				floorHtml = U.getHTML("https://www.colinahomes.com/cobblestone-floor-plans");
  
			String InventrySec=U.getSectionValue(html, "INVENTORY", "</div></div>");
			if(InventrySec == null) InventrySec=U.getSectionValue(html, ">Inventory", "</section>");
//			U.log("InventrySec::::::::::::::"+InventrySec);

			String combinedInventory = null;
			if(InventrySec != null){
				InventrySec=InventrySec.replace("&nbsp;", " ");
				
				String inventoryHomeUrls[] = U.getValues(InventrySec, "<h4 style=\"white-space:pre-wrap;\"><a href=\"", "\"");
				for(String inventoryHomeUrl : inventoryHomeUrls){
					if(inventoryHomeUrl.length() > 100) continue;
					if(!inventoryHomeUrl.startsWith("http"))continue;
					U.log("inventoryHomeUrl ::"+inventoryHomeUrl);
					String inventoryHtml = U.getHTML(inventoryHomeUrl);
					if(inventoryHtml != null)
						combinedInventory += U.getSectionValue(inventoryHtml, "<div id=\"DetailPage\"", "<div id=\"EnergyOrge\">");
				}
			}
			
			
			String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
			String sqFt[], price[];
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;
			String propType = ALLOW_BLANK;
			
			
			//================= SQFT =====================================================
				sqFt = U.getSqareFeet(U.getSectionValue(buildHtml, "<table", "</table>")
						+ U.getSectionValue(buildHtml, "</table>", "</table>")+InventrySec+floorHtml+html, 
						"\\d{4} Square Feet|\\d,\\d{3} Square Feet|\\d,\\d{3}&nbsp;Square Feet", 0);
				minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
				maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
				U.log("Min Sqft " + minSqFt);
				U.log("Max Sqft " + maxSqFt);
				
				html = html.replace("starting in the $200s-300s", "starting in the $200,000-$300,000")
						.replaceAll("0s", "0,000");
		
				baseHtml=baseHtml.replaceAll("description\":\"\\$100 - \\$200 - South", "").replaceAll("0's|0s|0S|0’s", "0,000").replaceAll("00+", "00,000");
				if(comPriceSec!=null)comPriceSec = comPriceSec.replace("Starting in the $270,000 &nb,000p", "")//check next time
						.replace("0&#39;s", "0,000").replace("0's+", "0,000");
				//U.log(comPriceSec);
			//	String pdata=U.getSectionValue(buildHtml, "<p>Model Home Address:", "</table>");
				price = U
						.getPrices(floorHtml
									+U.getSectionValue(buildHtml, "<table ", "</table>")+ " "+U.getSectionValue(buildHtml,"<td bgcolor=\"#ffffff\" align=\"center\">,</td>", "(\\$\\d{3},\\d{3})")
									+" "+ U.getSectionValue(buildHtml, "</table>", "</table>")+InventrySec+html+comPriceSec+floorHtml,
								"<strong>Starting at \\$\\d{3},\\d{3}</strong>|starting in the \\d{3},\\d{3}|the \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|<strong>\\$\\d{3},\\d{3}<|Starting at\\s+\\$\\d+,\\d+</em>|starting in the \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</td>|(\\$\\d{3},\\d{3})|description\":\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}<br />|description\":\"\\$\\d{3},\\d{3}|&nbsp; \\$\\d{3},\\d{3}|<td>\\$\\d{3},\\d{3}</td>|\\$\\d{3},\\d{3}", 0);

				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				///U.log(baseHtml);
				U.log("Min price " + minPrice);
				U.log("Max price " + maxPrice);

//				U.log(">>>>>>>>>>>"+Util.matchAll(buildHtml+floorHtml+InventrySec+html+comPriceSec, "[\\w\\s\\W]{30}220[\\w\\s\\W]{30}", 0));
				
				String buildUrl = U.getSectionValue(buildHtml,
						"<li id=\"menu-item-595\" class=\"menu-item menu-item-type-taxonomy menu-item-object-category menu-item-595\"><a href=\"",
						"\">");
				if (buildUrl != null) {
					
					U.log("gggggggggggggggg");
					propType = U.getHTMLwithProxy(buildUrl);
				}

				String[] homeSec = U.getValues(html, "<a href=\"https://www.har.com", "\"");
				String desData = ALLOW_BLANK;
				for(String home : homeSec) {
					try {
						U.log("homelinks: "+home);
						desData += U.getSectionValue(U.getHTML("https://www.har.com"+home), "<div class=\"prop_item status-active\">", "<div class=\"clearfix\"></div>")
								+ U.getSectionValue(U.getHTML("https://www.har.com"+home), "<div id=\"GENERALDESCRIPION\"", "<!-- ReportProblem -->")
								+ U.getSectionValue(U.getHTML("https://www.har.com"+home), "Listing Status", "Maintenance Fee");
					}catch (Exception e) {
						// TODO: handle exception
					}
				}
				buildHtml=buildHtml.replace("custom home features", "exceptional custom home");
				propType = U.getPropType((desData+propType+buildHtml).replaceAll("featuring modern, luxurious|luxury vinyl flooring", "luxury home"
						+ "").replaceAll("Villa|No HOA|craftsmanship", "")+commName+combinedInventory);
				// U.log(propType);
				
			//}
			// ----------------------------- Community property
			// status-----------------------------
			String prpStatus=ALLOW_BLANK;
			html = html.replace(">— COMING SOON —<", "")
					.replace("COMMUNITY CLOSOUT", "COMMUNITY CLOSEOUT")
					.replace("over 85% are sold in section II", "over 85% sold in section II");
			
			
			buildHtml = buildHtml.replace("New Home sites just released for sale in Section III", "New Homesites just released in Section III");
			
			if (commURL.contains("https://colinahomes.com/our-communities/black-oak/")) {
				 U.log("state ---> 1");
				prpStatus = U.getPropStatus(buildHtml/* +" Coming Soon " */ + html);
			} else {
				U.log("state ---> 2");
				prpStatus = U.getPropStatus((buildHtml + html).replaceAll("immediate move-in|<strong>Coming Soon</strong>|<strong>Coming Soon!</strong|Coming Soon in Mid 2015|center, coming| Inventory Homes ready for move-in|development will be coming|Lagoon coming summer", ""));
			}
			U.log(">>>>>>>>>>>>prpStatus: "+prpStatus);
//			U.log(">>>>>>>>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}community clo[\\s\\w\\W]{30}", 0));
			
			if (commURL.contains("https://colinahomes.com/page/cobblestone")) {
				prpStatus ="Fall/Winter 2018";
			}

			if (commURL.contains("https://colinahomes.com/our-communities/herons-landing/")) {
				propType = propType.replace(",Villas", "");
			}

			if (commURL.contains("https://colinahomes.com/our-communities/enclave-at-dobbin/")) {
				add = U.getAddress("1314 North Durham Drive, Houston, TX 77008");
				String latLng[] = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				lat = latLng[0];
				lon = latLng[1];
				geo = "True";
				notes = "Address Is Taken From Contact Us";
			}
			
			if(propType==null)propType=ALLOW_BLANK;
			
			//commuity type
			String cType = U.getCommunityType((html + buildHtml));
			U.log("Com Type: "+cType);
			// ----------------------------- writing Community data to file-----------------------------
			if(commURL.contains("bayou-maison")) {
				minSqFt="1427";
				maxSqFt="2176";
			}
			if(commURL.contains("https://www.colinahomes.com/herons-landing"))
				maxSqFt="2201";
			
			if(commURL.contains("https://www.colinahomes.com/jacquelyn"))
				propType+=", Single Family, Traditional Homes";
			
			if(propType.contains("Townhouse") && propType.contains("Townhome"))
				propType = propType.replaceAll("Townhouse,|Townhouse", "");				
			
			if(combinedInventory != null) combinedInventory = combinedInventory.replaceAll("\\d bedroom", "");
			String dtype= U.getdCommType((desData+html + buildHtml+floorHtml+combinedInventory)
					.replaceAll("[B|b]ranch|branching|Ranch Shopping|Ranch Town Center|(r|R)ancho|value=\"One Story Homes\">|4 bedrooms/ 3 BATH HOME|<span>One Story Homes</span>|"
							+ "pre-wrap;\">One story homes", ""));
			// U.log("floorHtml:::::::::::::"+floorHtml);
		
			//U.log(">>>>>>>>>>>>>>>>>>"+Util.matchAll(desData+html + buildHtml+floorHtml+combinedInventory, "[\\s\\w\\W]{30}story 4[\\s\\w\\W]{30}", 0));
			
			//villages-of-heritage-point
			if(commURL.contains("/arbor-trails"))minPrice ="$170,000"; // from Img
			if(commURL.contains("/splendora-fields"))minPrice="$220,000";
			
			if(commURL.contains("https://www.colinahomes.com/south-meadow-place"))
				add[0] = "6433 Macroom Meadows Lane";
			if(prpStatus!=null)
			prpStatus=prpStatus.replace("Iii", "III").replace("Ii", "II").replace("Just Released, New Home Sites Just Released", "New Home Sites Just Released").replace("New Home Sites Just Released, New Homesites Just Released", "New Homesites Just Released");
			
			if(commURL.contains("bayou-maison"))propType=propType.replace(", Homeowner Association", "");
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(commName, commURL, cType);
			data.addAddress(add[0].replaceAll("|,", "").replace("-", " "), add[1], add[2], add[3]);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLon[0].trim(), latLon[1].trim(), geo);
			data.addPropertyType(propType,dtype);
			data.addPropertyStatus(prpStatus);
			data.addNotes(notes);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		i++;
	}
}
