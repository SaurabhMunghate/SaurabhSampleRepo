/**@modify Sawan
 * @date 2 March 2021
 * @author Pankaj Malode
 * date 10/8/2015
 */
package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFieldStoneHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	static int j=0;
	public int inr = 0;

	private static final String BUILDER_URL = "https://www.fieldstonehomes.com";
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractFieldStoneHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"FieldStone Homes.csv", a.data().printAll());
	}

	public ExtractFieldStoneHomes() throws Exception {

		super("FieldStone Homes", "https://www.fieldstonehomes.com");
		LOGGER = new CommunityLogger("FieldStone Homes");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://www.fieldstonehomes.com/new-homes/");
		
		String[] sections = U.getValues(html, "<div class=\"card oi-map-item location-map-item", "Details</a>");
		
		U.log(sections.length);
		
		for(String sec : sections){
			String comUrl =  U.getSectionValue(sec, "\" href=\"", "\"");
			//U.log(comUrl);
			if(!comUrl.startsWith("http")) comUrl = BUILDER_URL +comUrl;
			String name = U.getSectionValue(sec, "lato-bold\">", "</span>");
			//U.log(name);
			
			//U.log(price);
			addDetails(name, comUrl,sec);
		}
		

		LOGGER.DisposeLogger();
	}
	
	//TODO :
	private void addDetails(String name,String url,String sec)throws Exception{
//	try{
	{
//	if(!url.contains("https://www.fieldstonehomes.com/new-homes/ut/layton/the-park/7497/"))return;

			
			
		if (data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		U.log(url);
		U.log(name);
		U.log(sec);

		

		
		String commhtml = U.removeComments(U.getHTML(url));
		commhtml = U.removeSectionValue(commhtml, "<head>", "</head>");
		U.log(U.getCache(url));
		String cType = U.getCommType(commhtml.replaceAll("Wasatch Golf Course|Hollow Golf Course",""));
		
		String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,"UT",ALLOW_BLANK};
		String geo = "FALSE";
		
		
		String addSec = U.getSectionValue(commhtml, "Community Address</h5>", "</p>");
		if(addSec == null )addSec = U.getSectionValue(commhtml, "Design Center</a><br />", "</p>");
			
		U.log(addSec);
		
//		if(url.contains("scenic-mountain-townhomes/7490")) {
//			addSec="4754 north topaz drive, Eagle Mountain, UT, 84005";
////			add[0]="4754 north topaz drive";
//			add[1]="Eagle Mountain";
//			add[2]="UT";
////			add[3]="84005";
//			geo="TRUE";
//		}
		if(addSec != null ){
			//U.log(add);
			addSec = addSec.replaceAll("<br /><a href=\"https://goo.gl/maps/x6KtwaHNUohrNWHj7\">|Driving Directions", "")
					.replaceAll("<br/>|<br />", ",");
			addSec=U.getNoHtml(addSec);
			add = U.getAddress(addSec);
		}
		
		U.log("Address is  : "+Arrays.toString(add));
		
		latlng[0]=U.getSectionValue(sec, "data-latitude=\"", "\"");
		latlng[1]=U.getSectionValue(sec, "data-longitude=\"", "\"");
		
		if(latlng[0]==null || latlng[0]==ALLOW_BLANK || latlng[0].isEmpty()) {
			String latLngSec = U.getSectionValue(commhtml, "//maps.google.com/maps?", "Get Directions");
			if(latLngSec==null) {
				String directionUrl=Util.match(commhtml, "ID 83455<br />\\s*<a href=\"(.*)\">Driving Directions</a></p>", 1);
				U.log("direction === "+directionUrl);
				String directionHtml=U.getHTML(directionUrl);
//				U.log(directionHtml);
				latLngSec=U.getSectionValue(directionHtml, "+USA/@", "/data\\");
//				if(latLngSec != null)
//					latLngSec =Util.match(commhtml, "\\d{2}\\.\\d{2,},-\\d{3}\\.\\d{2,}");
				
			}
			
			U.log(latLngSec);
			if(latLngSec != null)
				latLngSec =Util.match(latLngSec, "\\d{2}\\.\\d{2,},-\\d{3}\\.\\d{2,}");
			
			U.log("latLngSec : "+latLngSec);
			if(latLngSec != null){
				latlng = latLngSec.split(",");
			}
		}
		
		
		U.log("LatLng ::"+Arrays.toString(latlng));

		if((latlng[0]==null||latlng[0]==ALLOW_BLANK||latlng[0].length()<3)&&add[0]!=null&&add[0].length()>5){
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null)latlng = U.getlatlongHereApi(add);
			if(latlng == null)latlng = U.getNewBingLatLong(add);
			geo="TRUE";
		}
		
		String note=U.getnote(commhtml);
		U.log(add[0] +"::::"+ add[3]);
		
		if(add[0]==ALLOW_BLANK&&add[1]==ALLOW_BLANK) {
			if(url.contains("scenic-mountain-townhomes/7490")||url.contains("scenic-mountain-west-townhomes/7990")) {
				//	addSec="4754 north topaz drive, Eagle Mountain, UT, 84005";
					add[0]="4754 north topaz drive";
					add[1]="Eagle Mountain";
					add[2]="UT";
				    add[3]="84005";
					geo="TRUE";
				}
			else {	
			String citystate=U.getSectionValue(commhtml, "<p class=\"p-0 m-0 text-uppercase mb-4\">", "<");
			String[] cs=citystate.split(",");
			U.log(Arrays.toString(cs));
			add[1]=cs[0];
			if(add[2]==ALLOW_BLANK)
				add[2]=cs[1];
			U.log(add[2]);
			latlng=U.getGoogleLatLngWithKey(add);
			add=U.getGoogleAddressWithKey(latlng);
			geo="true";
			note="address taken from city and state";
			}
		}
		int quickCount=0;
		String combinedQuickHtml = null;
		/*
		 * For https://tetonreserve.com community
		 */
		String quickSection = U.getSectionValue(commhtml, "Quick Delivery homes</h2>", "<h2>Community Photo");
		if(quickSection != null){
			String quickUrlSection[] = U.getValues(quickSection, "<div class=\"fl-photo-content", "temprop=\"url\">");
			U.log("quick count :"+quickUrlSection.length);
			for(String quickUrlSec : quickUrlSection){
				String quickUrl = U.getSectionValue(quickUrlSec, "<a href=\"", "\"");
				U.log("quickUrl :"+quickUrl); 
//				U.log(quickUrlSection);
				String quickHtml = U.getHTML(quickUrl);
				combinedQuickHtml += U.getSectionValue(quickHtml, "<rs-slides>", "FLOOR PLAN LAYOUTS</span>");
				quickCount++;
			}
		}else{
			quickSection = U.getSectionValue(commhtml, "Quick <b>Move-Ins</b>", "Neighborhood</h1>");
			if(quickSection != null){
				String quickUrlSection[] = U.getValues(quickSection, "<a class=\"oi-aspect", "</a>");
				U.log("quick count :"+quickUrlSection.length);
				for(String quickUrlSec : quickUrlSection){
					String quickUrl = U.getSectionValue(quickUrlSec, " href=\"", "\"");
					if(!quickUrl.startsWith("http")) quickUrl = BUILDER_URL + quickUrl;
					U.log("quickUrl Sold Out:"+quickUrl); 
//					U.log(quickUrlSec);
					String quickHtml = U.getHTML(quickUrl);
					combinedQuickHtml += U.getSectionValue(quickHtml, "<h1>About this <span>", "Download Brochure<");
					if(!quickHtml.contains("Status:</p><p class=\"mb-1\">Under Construction"))
						quickCount++;
				}
				
			}
		}
		
		//============ Floor Plans ==================
		String combinedFloorHtmls = null;
		String floorUrls[] = U.getValues(commhtml, "<a class=\"card-thumb\" href=\"", "\"");
		U.log("total floor homes ::"+floorUrls.length);
		for(String floorUrl : floorUrls){
			if(!floorUrl.startsWith("http")) floorUrl = BUILDER_URL + floorUrl;
			
			U.log("floorUrl :"+floorUrl);
			String floorHtml = U.getHTML(floorUrl);
			if(floorHtml != null)
				combinedFloorHtmls += U.getSectionValue(floorHtml, "<h1 class=\"text-uppercase", "data-fancybox=");
		}
		//------------Prices from reg page, community page and section from quick move in page---------
		String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
		commhtml=commhtml.replace("</span><span class=\"unit\">'s", ",000");
		commhtml=commhtml.replace("</span><span class=\"value\">", "");
		commhtml = commhtml.replace("mid 200&#8217;s ", "mid $200,000 ").replace("$200's", "$200,000").replace("&#8217;", "'")
				.replaceAll("0s|0K's", "0,000");
		

		commhtml=commhtml.replaceAll("0's|0’s","0,000").replace("0K’s", "0,000");
		commhtml=commhtml.replace("0’s","0,000");
		String[] price =U.getPrices(sec+commhtml+combinedQuickHtml, 
				"home starting in the lower \\$\\d{3},\\d{3}|>\\$\\d,\\d{3},\\d{3}<|from the (mid|low|high) \\$\\d+,\\d+ |from the upper \\$\\d+,\\d+|from the mid \\d+,\\d+|\\$\\d{3},\\d{3}", 0);
		minPrice = (price[0]==null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1]==null) ? ALLOW_BLANK : price[1];
		U.log(minPrice + " :: "+ maxPrice);
//		 U.log("<<<<<<<<<<<< "+Util.matchAll(commhtml,"[\\s\\w\\W]{50}Ranch[\\s\\w\\W]{30}", 0));
		
		String[] sqft = U.getSqareFeet(commhtml, 
				"</div><p>\\d,\\d{3}</p></div>|range of \\d,\\d{3} to \\d,\\d{3} total square feet|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d,\\d{3} Total Sq. Ft. |from \\d,\\d{3} to \\d,\\d{3} square feet|starting at \\d,\\d{3} total square feet|\\d,\\d{3} Total Sq Ft|from \\d,\\d{3}( )?-( )?\\d,\\d{3} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d{3} Total Sq Ft l \\d,\\d{3} Finished Sq Ft|\\d,\\d{3} square feet|font-size: 14px;\">\\d,\\d{3} Total Sq Ft|\\d,\\d{3} sqft</span>|\\d,\\d{3} Total Sq Ft|total_sqft-2\"><span class=\"value\">\\d{4}</span>", 0);
		
		
		
		if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
		if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
		U.log("SQFT::: "+Arrays.toString(sqft));
		
		
		
		commhtml = commhtml.replaceAll("-Farmhouse|farmhouse elevat|between a craftsman|-Craftsman|_Farmhouse|_Craftsman|Craftsman and Farmhouse Elevations", "").replaceAll("find where we are currently|(Quick Move-(i|I)ns|QUICK MOVE-INS)</a>|Quick Delivery|either Move-in", "");
//		if(commhtml.contains("Under Construction")) {
//			commhtml=commhtml.replace("Quick Move-Ins", "");
//		}
		String status=U.getPropStatus(commhtml.replaceAll("future lots are available|Pricing coming soon|Pricing coming soon. </span>|bryleefarms/\">BRYLEE FARMS &#8211; COMING SOON</a>|>GRAND OPENING HIGHLIGHTS<|COMING SOON</a></li>|Trail is currently selling|Legacy Farms New Phase Release in Spanish Fork|purchase a Quick", ""));
		
		if(quickCount > 0 && !status.contains("Quick")){
			if(status == ALLOW_BLANK) status = "Quick Move-Ins";
			else if(status != ALLOW_BLANK) status += ", Quick Move-Ins";
		}

		if(combinedFloorHtmls!=null)
		combinedFloorHtmls=combinedFloorHtmls.replaceAll("Craftsman Elevation|Farmhouse Elevation", "");
		if(combinedQuickHtml!=null)	combinedQuickHtml=combinedQuickHtml.replace("FARMHOUSE EXTERIOR ELEVATION", "");
	//	commhtml.replace("-townhomes|Creek Townhome", "");
//		Trio Farmhouse|trending farmhouse|farmhouse|elevations
		String propertyType = U.getPropType((commhtml+combinedFloorHtmls + combinedQuickHtml)
			.replaceAll("Townhouse|Arrowhead Cottages|arrowhead-cottages|Farmhouse Exterior Elevation|Farmhouse [E|e]levation|Fieldstone Townhomes|Mountain T|-townhomes|Creek Townhome|creek-townhomes|mountain-townhomes|mountain-townhomes|/+Townhomes/+|arrowhead-cottages|mountain-townhomes|Farmhouse Style Homes|MOUNTAIN TOWNHOMES|Townhomes West Gallery|Townhomes</a>", "")); 
//		if((commhtml+combinedFloorHtmls + combinedQuickHtml).contains("elevations")){
//			propertyType=propertyType.replace("Farmhouse Style Homes", "");
//		}
	//	 U.log("<<<<<<<<<<<< "+Util.matchAll(commhtml,"[\\s\\w\\W]{50}craftsman[\\s\\w\\W]{30}", 0));
	//
	//	U.log("<<<<<<<<<<<< "+Util.matchAll(commhtml,"[\\s\\w\\W]{50}farmhouse[\\s\\w\\W]{30}", 0));
		//derived types
		String dtype = U.getdCommType((commhtml+combinedFloorHtmls + combinedQuickHtml).replaceAll("floor|Floor|Arrowhead Ranch|arrowhead-ranch", ""));
	if(url.contains("https://www.fieldstonehomes.com/new-homes/ut/eagle-mountain/scenic-mountain-west-townhomes/7990/")) {
		latlng=U.getlatlongGoogleApi(add);
		geo="TRUE";
	}
	
//	if(url.contains("https://tetonreserve.com"))dtype="1 Story, 2 Story";
	
		String lotCount=ALLOW_BLANK;
	//	String lot_Sec=U.getSectionValue(comhtml, "usemap=\"#platmap_map\"/>", "<div class=\"sitemap-key\">");
	//	if(lot_Sec!=null) {
		String[] lot_data=U.getValues(commhtml, "<div=\"\" class=\" oi-isp-key-sold quick-filters point \"", "</div>");
			if(lot_data.length>0) {
			lotCount=Integer.toString(lot_data.length);
			 U.log("lotCount=="+lotCount);
			}
	//	}
			
//			if(url.contains("homes/ut/layton/the-park/7497/")) status = "Sold Out";
//			if(url.contains("tetonreserve")) status = status.replace("Quick Move-Ins", ALLOW_BLANK);
			
		U.log("propertyType=="+propertyType);
		name=name.replaceAll("Cottages$", "");
		data.addCommunity(name, url, cType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPropertyType(propertyType, dtype);
		data.addPropertyStatus(status);
		data.addPrice(minPrice,maxPrice);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addNotes(note);
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
	j++;
//	}catch(Exception e){}
	}
}