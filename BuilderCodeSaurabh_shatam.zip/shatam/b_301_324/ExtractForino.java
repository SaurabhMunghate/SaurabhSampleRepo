package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractForino extends AbstractScrapper {
	private static String builderName = "Forino";
	private static String builderUrl = "https://www.forino.com/";
	static int j = 0 ;
	CommunityLogger LOGGER;
	ExtractForino() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractForino();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Forino.csv",
				a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String baseUrl = "https://www.forino.com/";
		String baseHtml =  U.getHTML(baseUrl);
	//	String regSec = U.getSectionValue(baseHtml, "Find Your New Home</a></li>", "SC Communities</a></li>");
//		U.getHTML(path)
		String[] regUrls = {"https://www.forino.com/pennsylvania/communities/","https://www.forino.com/south-carolina/communities/"};//U.getValues(regSec, "<a href=\"", "\"");

		for (String regUrl : regUrls) {
			U.log("regUrl : "+regUrl);
			String regHtml = U.getHTML(regUrl);
			
			String[] comSec =null;
			if(regUrl.contains("carolina")) {
			comSec= U.getValues(regHtml, "fwpl-row el-heg1y", "VIEW MOVE IN READY");
			}
			else {
				comSec=U.getValues(regHtml, "fwpl-row el-wrdoin", "</a>");
			}
		//	U.log(comSec.length);
			for(String cSec : comSec){
				//U.log(cSec);
				String cUrl = U.getSectionValue(cSec, "<a href=\"https:", "\"");
			//	U.log("cUrl : "+cUrl);
//				try {
					addDetails("https:"+cUrl,cSec,regUrl);
//				} catch (Exception e) {}
				//break;
			}
			
		}
		LOGGER.DisposeLogger();
	}

	//TODO ::
	private void addDetails(String comUrl ,String comInfo,String regUrl) throws Exception {
	//	if(j==3)
//		if(!comUrl.contains("https://www.forino.com/south-carolina/communities/academy-park/")) return;
		{
			U.log(j+"\tcomUrl :"+comUrl);
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "*********************** Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			//U.log(comInfo);
	
			U.log(U.getCache(comUrl));
			String comHtml=U.getHTML(comUrl);
	String comName=U.getSectionValue(comHtml,"uabb-infobox-title-prefix", "</h2>").replace("\">", "").toLowerCase();
	comName=U.getCapitalise(comName);
	U.log(comName);
	
	String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
	String latLong[]= {ALLOW_BLANK,ALLOW_BLANK};
	String geo="FALSE";
	
	
	String addSec=U.getSectionValue(comHtml, "<div class=\"fl-module fl-module-heading fl-node-602dab5c911f1\"", "</h6>");
	if(addSec==null) {
		addSec=U.getSectionValue(comHtml, "fl-module fl-module-heading fl-node-602db5a032aef", "</h6>");
		U.log(addSec);
		if(addSec.contains("SC 29940, USA"))
			addSec = addSec.replace("SC 29940, USA", "SC 29940");
	}
	
	//U.log(addSec);
	//latLong[0]=U.getSectionValue(addSec, "", "");
	//latLong[1]=U.getSectionValue(addSec, "", "");
	
	add=U.getAddress(U.getSectionValue(addSec, "<span class=\"fl-heading-text\">", "</span>"));
	U.log(Arrays.toString(add));
	
	
	latLong=U.getlatlongGoogleApi(add);
	U.log(Arrays.toString(latLong));
	
	
	
	String floorplanUrl=regUrl.replace("/communities", "")+"floorplans/?_communty_list="+comName.replace(" ", "-").replace("-Townhomes", "").toLowerCase();
	
	U.log("floor url "+floorplanUrl);
	
	String floorhtml=U.getHTML(floorplanUrl);
	U.log(U.getCache(floorplanUrl));
	
	String homeHtml=ALLOW_BLANK;
	//U.log("FLOOR HTML"+floorhtml);
     String homes[]=U.getValues(floorhtml,"<h4 class=\"item-title\">","</button>");
	for(String home:homes) {
		String homeUrl=U.getSectionValue(home, "<a href=\"","\">");
		homeHtml+=U.getHTML(homeUrl);
	}
	
	
	
	String moveTabUrl=regUrl.replace("/communities", "")+"move-in-ready/?_communty_list="+comName.replace(" ", "-").replace("-Townhomes", "").toLowerCase();
	String moveData = ALLOW_BLANK;  //quick move in homes data
	U.log("moveTabUrl==="+moveTabUrl);
	
	String moveHtml=U.getHTML(moveTabUrl);
	String[] moveLinks = U.getValues(moveHtml, "\"item-block\"", "<img width=");
	U.log("moveLinks==="+moveLinks.length);
	for(String sec:moveLinks) {
		String moveUrl = U.getSectionValue(sec, "<a href=\"","\">");
		U.log(moveUrl);
		moveData += U.getHTML(moveUrl); 
	}
	U.log(moveLinks.length);
	//U.log("mmmmmm"+Util.matchAll(moveData, "[\\w\\s\\W]{30}cottage designs[\\w\\s\\W]{30}", 0));
	
	String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
	String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
	
	U.log(comInfo);
	comInfo=comInfo.replace("0's", "0,000");
	
	prices=U.getPrices(floorhtml+moveHtml+comInfo, "\\$\\s*\\d{3},\\d{3}", 0);
//	U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Low \\$500[\\w\\s\\W]{30}", 0));

	sqft=U.getSqareFeet(floorhtml+moveHtml, "over \\d,\\d{3} square feet|Square Feet: \\d,\\d{3}-\\d,\\d{3}|Square Feet: \\d,\\d{3}-\\d,\\d{3}|Square Feet: \\d{1},\\d{3}", 0);
	
	U.log(Arrays.toString(prices));
	U.log(Arrays.toString(sqft));
//	U.log("mmmmmm"+Util.matchAll(floorhtml+moveHtml, "[\\w\\s\\W]{30}1,700[\\w\\s\\W]{30}", 0));
	
	
	String cType=U.getCommType(comHtml.replaceAll("Irrigated|irrigated", ""));
	U.log("CHK"+homeHtml.contains("loft"));
	
	//moveData = moveData.replace("Country cottage designs", "Cottage")
	
	String pType=U.getPropType((comHtml+floorhtml+homeHtml+moveData).replaceAll("cottage-style custom crown molding|[C|c]ottage-style crown molding|Craftsman style door|Craftsman style front door|Style: Traditional<br />", "Style: traditional layout<br />"));
	
//	U.log("mmmmmm"+Util.matchAll(comHtml+floorhtml+homeHtml+moveData, "[\\w\\s\\W]{30}cottage[\\w\\s\\W]{30}", 0));
	
	String dType=U.getdCommType((floorhtml+moveHtml+comHtml+homeHtml).replaceAll("[F|f]loor", "").replace(" emphasis on first floor living", ""));
	//U.log("mmmmmm"+Util.matchAll(comHtml+floorhtml+homeHtml, "[\\w\\s\\W]{30}ranch-style home[\\w\\s\\W]{30}", 0));
	
	String pstatus=U.getPropStatus(comHtml.replaceAll("<span class=\"fl-heading-text\">Move-in Ready Homes</span>|Move-In Ready Homes Available|Move-In Ready homes available", ""));
	
	
//			U.log("===================");
	if(comUrl.contains("communities/temple-terrace")||comUrl.contains("communities/pine-vista-estates"))pstatus=ALLOW_BLANK;
	if(comUrl.contains("communities/mcintosh-farms-ii"))pstatus="Grand Opening";
			
	if(prices[0]==null)prices[0]=ALLOW_BLANK;
	if(prices[1]==null)prices[1]=ALLOW_BLANK;
	
	if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
	if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
	
	
	
	U.log("pstatus=="+pstatus);
	pstatus = pstatus.replaceAll("Move-in Ready Homes|Move-in Ready", "Move-in Ready Homes");
	U.log("pstatus.length()=="+pstatus.length());
	if(moveLinks.length>0 && !pstatus.contains("Move-in Ready")) {
		if(pstatus.length()>2) {
			pstatus = pstatus+", Move-in Ready Homes";
		}
		else {
			pstatus = "Move-in Ready Homes";
		}
	}
	
	if(comUrl.contains("https://www.forino.com/pennsylvania/communities/mcintosh-farms-ii/"))pType+=", Luxury Homes";
		if(comUrl.contains("https://www.forino.com/pennsylvania/communities/glen-ridge-estate/"))pstatus=ALLOW_BLANK;
	if(comUrl.contains("https://www.forino.com/pennsylvania/communities/mcintosh-farms-ii/")) {pType+=", Traditional Homes";}
	if(comUrl.contains("https://www.forino.com/pennsylvania/communities/pine-vista-estates/"))pType+=", Loft, Craftsman Style Homes";
	if(comUrl.contains("https://www.forino.com/south-carolina/communities/ridgeland-lakes/")||comUrl.contains("https://www.forino.com/south-carolina/communities/mossy-oaks/"))pType+=", Patio Homes";
	if(comUrl.contains("https://www.forino.com/south-caroá�¬ina/communities/academy-park/"))pType+=", Luxury Homes";
		
		data.addCommunity(comName, comUrl, cType);
		data.addLatitudeLongitude(latLong[0], latLong[1], geo);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addPrice(prices[0], prices[1]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyStatus(pstatus);
		data.addPropertyType(pType, dType);
		data.addNotes(U.getnote(comHtml));
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

		}
		j++;
	}

	
}