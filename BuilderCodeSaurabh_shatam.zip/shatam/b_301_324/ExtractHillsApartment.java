/* @ SKC*/
package com.shatam.b_301_324;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.regexp.recompile;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractHillsApartment extends AbstractScrapper {
	public int inr = 0;
	WebDriver driver = new FirefoxDriver();
	String mainHtml="";
	String Fhtml="";
	static int j=0;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractHillsApartment();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Hills Communities - Apartment.csv", a.data().printAll());
	}

	public ExtractHillsApartment() throws Exception {
		super("Hills Communities - Apartment","http://www.myhillsapartment.com/");
		LOGGER=new CommunityLogger("Hills Communities - Apartment");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("http://www.myhillsapartment.com/");
		String section = U.getSectionValue(html, "Find a Home</a>","testimonials.html");
		String regUrls[] = U.getValues(section, "<a href=\"", "\"");
		ArrayList<String> list = new ArrayList<String>();

		//
		for (String rgn : regUrls) {

			boolean flag = rgn.equalsIgnoreCase("/apartments.html");
			if (!flag) {
				rgn = "http://www.myhillsapartment.com" + rgn;
				U.log("reg:"+ rgn);
				String rgnhtml = U.getHTML(rgn);

				// Communities Section..
				U.log("reg rgn: " + rgn);
				String secSub = U.getSectionValue(rgnhtml,"id=\"apartment-table\"", "</table>");
				String commUrls[] = U.getValues(secSub, "<a href=\"", "\"");
				//U.log(commUrls.length);
				String latLngs[] = U.getValues(rgnhtml, "{\"lat\"", "\"}");
				for (String commUrl : commUrls) {
					commUrl = "http://www.myhillsapartment.com" + commUrl;

					if (!list.equals(commUrl)) {

					//	U.log("Community URl: " + commUrl);
						list.add(commUrl);
						addDetails(commUrl, latLngs , rgnhtml);

					}
				}
			}
		}
		LOGGER.DisposeLogger();
		U.log("Total Community Count: " + list.size());
		driver.quit();
	}
	

	private String[] getSqft(String url) throws Exception {
		
		if (driver == null) {
			driver = new FirefoxDriver();
		}
		U.log(url+"*************");
		
		String html = U.getHTML(url);
		// String html = U.getHtml(url, driver);
		String secAddress = U.getSectionValue(html,"class=\"text-center hide-for-large-up\">", "Visit Website");
		
		U.log("Section : " + secAddress+"$$$$$$$$$$");

		//
		String minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;
		if (secAddress != null) {
			secAddress = U.getSectionValue(secAddress, "<a href=\"", "\"");
			
			{
			String mainPage = U.getHtml(secAddress,driver);
           mainHtml=mainPage;
           String secFloorPlan="";
           if(mainPage!=null)
           {
        	   secFloorPlan = U.getSectionValue(mainPage, "id=\"nav\">","Floor");
           }
			if (secFloorPlan == null)
			{
				//U.log(mainPage);
				if(mainPage.contains("<ul class=\"top-nav")&&mainPage.contains("<li class")){
					secFloorPlan = U.getSectionValue(mainPage,"<ul class=\"top-nav", "<li class");
					
				}
				
			U.log("::::" + secFloorPlan);
			}
			if(secFloorPlan!=null){
				secFloorPlan=secFloorPlan.replace("<li><a href=\"/\" class=\"active\">Home</a></li>", "");
				secFloorPlan = U.getSectionValue(secFloorPlan, "<li><a href=\"/", "\"");
			}
			

			U.log("Floor Plan:  " + secFloorPlan);
			//U.log("Floor Plan:  " + U.getCacheFileName(secFloorPlan));
			if(secFloorPlan==null)
				secFloorPlan = ALLOW_BLANK;
			if (!secFloorPlan.contains("http"))
				secFloorPlan = secAddress + secFloorPlan;
			if(!secAddress.contains("com/")){
				secAddress =secAddress+"/";
			}
			U.log("Floor url =="+secFloorPlan);
			String htmlFloor = U.getHtml(secFloorPlan, driver);
			String floorUrlSec = Util.match(htmlFloor,	"<a id=(.*)?>View All</a>");
			U.log("====>"+floorUrlSec);
			String floorHtml = null;
			if(floorUrlSec != null){
				String floorUrl = secFloorPlan+U.getSectionValue(floorUrlSec, " href=\"", "\"");
				floorHtml = U.getHtml(floorUrl, driver);
				U.log("floorUrl========"+floorUrl);
			}
			
			
			if(htmlFloor.contains("ember-view iui-cards-view-all")){
				U.log("secFloorPlan::"+secFloorPlan);
				Fhtml=U.getHtml(secFloorPlan+"#/bedrooms/all/floorplans", driver);
			}
          
			String sqFt[] = U.getSqareFeet(htmlFloor+Fhtml+floorHtml,
					"SQ. FT.\">\\d+\\-\\d+</td>|<td data-label=\"SQ. FT.\">\\d+</td>|SQ. FT.\">\\d+ -\\d+|\\d{4} Sq. Ft.|>\\d{3} Sq. Ft|\"SQ. FT.\">\\d+", 0);
			minSq = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSq = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			U.log("minSq:"+minSq);
			// Thread.sleep(100000);
		}
		return new String[] { minSq, maxSq };

	}
		return null;
	}
	private void addDetails(String comUrl, String latLngsList[] , String regHtml) throws Exception {
//		if(j==0)
		{
			
		String url = "http://www.myhillsapartment.com";
		String commName = null, street = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK, city = ALLOW_BLANK, latitude = ALLOW_BLANK, longitude = ALLOW_BLANK, minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;
		String pType = ALLOW_BLANK, status = ALLOW_BLANK, maxPrice = ALLOW_BLANK, minPrice = ALLOW_BLANK;
		U.log("Page Community:" + comUrl+"%%%%%%%%%%%%");
	//	if(!comUrl.contains("http://www.myhillsapartment.com/apartments/greater-cincinnati/49-hundred-blue-ash-ohio.html"))return;
		
		String comHtml = U.getHTML(comUrl);
		
		//========== Community Name ==========================
		commName = U.getSectionValue(comHtml, "<h1>", "</h1>");
		
		//=========== Address ====================
		String add[] = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
	//	U.log(commName);
		String addSec = U.getSectionValue(comHtml, "<span class=\"adr\">",	"<span class=\"phone visible-desktop\">");
		//U.log(addSec);
		// if (addSec != null) {
		add[0] = U.getSectionValue(comHtml, "class=\"street-address\">","</li>").trim();
		add[1] = U.getSectionValue(comHtml, "<span class=\"locality\">","</span>").trim();
		add[2] = U.getSectionValue(comHtml, "<span class=\"state\">", "</span>").trim();
		add[3] = U.getSectionValue(comHtml, "<span class=\"zip\">", "</span>").trim();
		if (add[2].length() > 2)
			add[2] = USStates.abbr(add[2]);

		U.log(commName + "," + comUrl);
		U.log("STREET: " + add[0] + " CITY: " + add[1] + " STATE " + add[2]+ " ZIP " + add[3]);
		String florplan = U.getSectionValue(comHtml,"<li class=\"first\"><a  class=\"top-level\" href=\"", "\">");

		String florHtml = ALLOW_BLANK;
		if (florplan != null)
		{
			florHtml = U.getHTML(florplan);
			U.log(U.getCache("hhhhh----->"+florplan));
		}
		String sqft[] = U
				.getSqareFeet(
						florHtml,
						"\\d+ square feet|<div class=\"sqft\">([^<])+|<span class=\"sqft\">.*|Q. FT.\">1000",
						0);
		minSq = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSq = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		String price[] = U.getPrices(florHtml,
				"<td>\\$\\d+|<td>\\$\\d+ - \\$\\d+</td>", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
	//	U.log(price[0] + "," + price[1]);
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		for (String seclatlng : latLngsList) {
			String tempCommName = U.getSectionValue(seclatlng, "\"title\":\"",
					"\"");
			if (tempCommName.equalsIgnoreCase(commName)) {
				latLng[0] = Util.match(seclatlng, "\\d{2}\\.\\d{3,}");
				latLng[1] = Util.match(seclatlng, "-\\d{2}\\.\\d{3,}");
			}
			// if(seclatlng)
		}

		if (add[0] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
			latLng = U.getlatlongGoogleApi(add);
			geo = "TRUE";
		}

	
		// Property Status
		String pStatus =U.getPropStatus(comHtml);

		sqft = getSqft(comUrl);
		U.log("result::::::::::::::::"+Arrays.toString(sqft));
		minSq = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSq = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log(commName+"<<<<<<<<");
		
		//-----property type---------------
		//Follow code is to fetch the community description present of region page
		String temp=commName+"</td>";
		String regComdesc = U.getSectionValue(regHtml, temp, "Read More</a>"); 
		U.log("regComdesc"+regComdesc);
		//--------------------------
		mainHtml=mainHtml.replaceAll("multifamily-multi-family-iui-|Multifamily IUI|multi|Multi|three and four story elevator buildings", "");
		Fhtml=Fhtml.replaceAll("multifamily-|multi-family-iui-|Multifamily IUI|multi|Multi", "");
		comHtml= comHtml.replace("three and four story elevator buildings", "");
		
		pType = U.getPropType(comHtml+mainHtml+Fhtml+regComdesc);
		
		pType=pType.replace("Townhouse,Townhome,", "Townhome,");
		
		String dType = U.getdCommType((Fhtml+comHtml+mainHtml).replaceAll("three and four story"," 3 story , 4 story"));
		
		
		if (data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+" =======>Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		String communityType = U.getCommType(comHtml);
		//U.log(U.getSectionValue(comHtml, "living to suit your unique lifestyle", "Intermediate Schools"));
		 communityType = U.getCommunityType(comHtml+mainHtml);
		data.addCommunity(commName, comUrl, communityType);
		data.addAddress(add[0], add[1].replace("Township",""), add[2], add[3]);
		data.addSquareFeet(minSq, maxSq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(ALLOW_BLANK);

	}j++;
}
	
}