package com.shatam.b_301_324;

/**
 * @author Rakesh Chaudhari
 * @date 08-07-2015
 * 
 */
import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHomeSouthCommunities extends AbstractScrapper {
	static String BASEURL = "http://homesouthcommunities.com/";
	static int j = 0;

	/**
	 * @param args
	 * @throws Exception
	 */
	String dhtml = ALLOW_BLANK;
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractHomeSouthCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Home South Communities.csv", a.data().printAll());
	}

	public ExtractHomeSouthCommunities() throws Exception {

		super("Home South Communities", BASEURL);
		LOGGER = new CommunityLogger("Home South Communities");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("http://homesouthcommunities.com/our-communities/");

		String comSections[] = U.getValues(html, "<article id=\"portfolio-","</article>");
		for (String comSec : comSections) {
			//U.log(url_name);
			String url = U.getSectionValue(comSec, "<a href=\"", "\"");
			String communityUrl = url;
			communityUrl = communityUrl.toLowerCase();
			// U.log(communityUrl+":::::::::::::"+comSec);
			addDetails(communityUrl,comSec);
		}
		LOGGER.DisposeLogger();
	}

	private String[] getSqft(String commUrl) throws IOException {

		String[] sqFt = { ALLOW_BLANK, ALLOW_BLANK };
	
		
		String html = U.getHTML(commUrl); // 3,300 to 4,000 square feet
		U.log(commUrl);
		
		String flrUrl = commUrl.replace(".html", "/floor-plans.html");
	    String flrHtml = U.getHTML(flrUrl);
		flrHtml = U.removeComments(flrHtml);
		flrUrl=BASEURL+flrUrl;
		 
		
		String plnSec = U.getSectionValue(flrHtml, "<td align", "</table>");
		//U.log("plnSec::"+plnSec);
		
		String[] plnUrl = null;
		String plnHtml = "";

		if (plnSec != null) 
		{
			plnUrl = U.getValues(plnSec, "<a href=\"", "\"");

			for (String pln : plnUrl) 
			{
				U.log(pln);
				String planeUrl = BASEURL + pln;
				plnHtml += U.getHTML(planeUrl);

			}
		}
		html=html.replaceAll("offer 2,800-4,000", "");
		dhtml = plnHtml;
		sqFt = U.getSqareFeet(html+plnHtml,"\\d{4}\\+ square feet of|\\d,\\d+ square feet|\\d,\\d+ or \\d,\\d+ Square Feet|\\d,\\d+-\\d,\\d+ square feet|\\d+ to over \\d+ square feet|\\d+ to \\d+ square feet|\\d+,\\d+ to \\d+,\\d+ square feet|Sq. Ft.: \\d,\\d+-\\d,\\d+|Sq. Ft.: \\d,\\d+ – \\d,\\d+|Sq. Ft.: \\d,\\d+|Sq. Ft.: \\d,\\d+|\\d+  to over \\d+  square feet|\\d,\\d+ to \\d,\\d+ square feet|\\d{4}  square feet of living space|SqFt.: \\d,\\d{3}|Sqft: \\d,\\d{3}",
				0);

		sqFt[0] = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		sqFt[1] = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		return sqFt;

	}

	private String extractThreeDigitPrice(String section) {
		// From the $220s

		String section1 = U.getSectionValue(section, "class=\"subtitle\">",
				"</span>");

		String price = Util.match(section1, "\\$\\d+");
		if (price == null) {
			return ALLOW_BLANK;
		}
		if (price.length() == 4) {
			price = price + ",000";
		}
		return price;
	}

	private String[] getLatLng(String commUrl) throws IOException {

		String html = U.getHTML(commUrl);
		html = html.replace("5&#039;52.4%22N+84%C2%B002&#039;38.0%22", "");
		String secMap = U.getSectionValue(html, "https://www.google.com/maps",
				"target");
	//	U.log("sdsd  " + html);
		
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		if (secMap != null) {
			lat = Util.match(secMap, "\\d+\\.\\d+");
			lng = Util.match(secMap, "-\\d+\\.\\d+");
		}
		return new String[] { lat, lng };
	}

	public void addDetails(String commUrl,String commSec) throws Exception {
		
//		if(j==1)
		{
		// ............................Community Url...........................
		U.log("Page Url: " + commUrl);
		U.log(commSec);
		if(commUrl.trim().length()==0)return;
		// ...........................Community Name...........................
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"::::::::::::::REPEATED");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		String html = U.getHTML(commUrl);
		U.log("Chache ======      "+U.getCache(commUrl));

		// comm Name
		String commName = ALLOW_BLANK;

		commName = U.getSectionValue(html, "<title>", " -");
		commName=commName.replace("&#039;s", "'s");

		U.log(commName);

		html = html.replace("building 32 new townhomes priced from the high $150,000s", "").replace("priced from the high $600,000s, including several basement home sites", "");
		html = html.replace("Other Communties", "Other Communities");
		String priceSec = U.getSectionValue(html, "<html", "Other Communities");
		{priceSec = priceSec.replaceAll("0s|0’s", "0,000").replaceAll("<del>\\&#36;\\d{3},\\d{3}</del>", "")
				.replace("0's", "0,000");
		}
			commSec=commSec.replaceAll("0s|0’s", "0,000");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String price[] = U.getPrices(priceSec+commSec , "Price: &#36;\\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

		// Sqft

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sqFt = getSqft(commUrl);
		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		// LatLng

		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		// String gMapLink = commUrl + "directions-a-maps.html";
		latLng = getLatLng(commUrl);
		if (latLng[0] == null) {
			
			latLng[0]=U.getSectionValue(html, "data-lat=\"","\"");
			latLng[1]=U.getSectionValue(html, "data-lng=\"","\"");
		}
		if (latLng[0] == null) {
			latLng[0] = ALLOW_BLANK;
			latLng[1] = ALLOW_BLANK;
		}

		// Add
		String flag = "FALSE";

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String note=ALLOW_BLANK;
		
		String addSec = U.getSectionValue(html, "https://www.google.com/maps/place/", "/@");
		if(addSec == null)addSec = U.getSectionValue(html, "https://www.google.com/maps/dir//", "/@");
		U.log(addSec);
		if(commUrl.contains("amberly-mill/")) {
			add[0]="";
			add[1]="Lawrenceville";
			add[2]="GA";
			add[3]="";
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null)latLng = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			note="Address & LatLng taken from City State";
			flag = "TRUE";

		}
		if(addSec != null && addSec.length()>10){
			U.log(addSec);
			addSec  =addSec.replace("+", " ");	
			String test=Util.match(addSec, "\\d{5}");
			if(test!=null)
			add = U.getAddress(addSec);
		}
		U.log("Hello Address::"+Arrays.toString(add));
		if (latLng[1] != ALLOW_BLANK && add[0].length()<4) {
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			flag = "TRUE";
		}
		
		
		
		

		// Community Type
		html=html.replace(" Hamilton Mill Golf Club", "");
		String communitytype = U.getCommunityType(html);
		

		// Property Type
		String dropSec=U.getSectionValue(html, "Other Communities", "actual homes built");
		if(dropSec!=null){
		html =html.replace(dropSec, "");
		}
		
		html=html.replaceAll("Luxury Island|townhomes\">|luxury-townhome-community|Luxury Townhome Community|New Luxury Townhome Community|Luxurious Master Suite|Luxurious Master On Main", "");
		html =html.replace("expansive Village Center,", "").replace("Traditional</li>", "Traditional, and");
		html=html.replace("convenience and luxury", "convenience and luxury home"); //for Blackwell Manor
//		html =html.replace("| Townhouse", "| Townhome");
		//U.log(U.getSectionValue(html, "<html", "Bellwood Floor Plan"));
		//html = html.replaceAll("Craftsman,Traditional", "Beautiful Craftsman Home,Traditional Home");
		String remo=U.getSectionValue(html, "Other Communities","<footer id=\"eut-footer");
		html=html.replace(remo,"").replace("executive style townhomes", "Executive Series,townhomes");
		html=U.getNoHtml(html);
		html=html.replace("Craftsman,Traditional", "Craftsman style homes,Traditional homes").replaceAll("Townhouse,Traditional", "Townhouse,Traditional homes")
				.replace("basement home sites", "");
		
		String proptype = U.getPropType(html );
		if(proptype.contains("Townhome") && proptype.contains("Townhouse"))
			proptype = proptype.replaceAll(",Townhouse|Townhouse,", "");
		// Derive Prop

		html=html.replace("2 & 3 Story"," 2 Story 3 Story ").replace("2nd Level", "2 Story");
		String dtype = U.getdCommType(html.replace("Branch", "").replace(
				"Willoughby Cove, ranch,", "")
				+ dhtml);

		// Status
	
		html = html.replaceAll("eut-light\">COMING SOON|strings: [\"Coming Soon.\"],|Grand Opening of Blackwell| Builder Closeou|Move-in Ready! Kitchen", "");
		html = html.replace("[\"Coming Soon.\"]", "");
		html = html.replace("[\"Coming Soon\"]", "");
		html = html.replaceAll("Last Chance! The Hawthrone| Ready Early 2017|<span>Grand Opening</span>|the Grand Opening of the Blackwell Manor Model Home|Tour Coming Soon", "");
		//U.log(html);
		String propstatus = U.getPropStatus(commSec+html.replaceAll(" Selling Fast\"|Selling Fast</a>|Builder Close-out|Builder Closeout|Chance! Final",""));
//		if(commUrl.contains("http://homesouthcommunities.com/communities/parkside-landing/")) {
//			//propstatus=propstatus.replaceAll("Sold Out,", "New Townhomes Sold Out,");
//			propstatus=propstatus+", Quick Move-in";
//		}
		if(propstatus.contains("Only A Few Homes Remaining") && propstatus.contains("Only 1 Home Remaining"))
			propstatus = propstatus.replace(", Only 1 Home Remaining", "");
		// Add All
		U.log(add[0]);
		U.log(add[1]);
		U.log(add[2]);
		U.log(add[3]);
		if(add[2]==null)
			add[2] = add[3] = ALLOW_BLANK;
		
		propstatus =propstatus.replaceAll("Now Selling New Townhome|Now Selling New Homes", "Now Selling");
		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0], latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}j++;
	}
}