package com.shatam.b_301_324;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHomesByWhittaker extends AbstractScrapper{
	static String builderName="Homes By Whittaker", builderUrl="https://www.homesbywhittaker.com/";
	WebDriver driver =null;
	private CommunityLogger LOGGER;
	public ExtractHomesByWhittaker() throws Exception {
		super(builderName, builderUrl);
		LOGGER=new CommunityLogger(builderName);
	}
	public static void main(String[] args) throws Exception {
		ExtractHomesByWhittaker abs=new ExtractHomesByWhittaker();
		abs.process();
		FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abs.data().printAll());
	}
	@Override
	protected void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String mainHtml=U.getHtml(builderUrl,driver);
		String navUrls[]=U.getValues(mainHtml, "<a data-testid=\"", ">");
		for (String nav : navUrls) {
			if(nav.contains("missouri-bluffs-phase-one"))continue;
			if (nav.contains("missouri-bluffs")) {
//				try {
					addDetails(nav);
//				} catch (Exception e) {}
			}
			U.log(nav);
		}
		LOGGER.DisposeLogger();
		driver.quit();
	}
	private void addDetails(String nav) throws Exception {
		
//		try {
		String commUrl=U.getSectionValue(nav, "href=\"", "\"").replace("./", "");
		if(!commUrl.startsWith("http"))
			commUrl = builderUrl+commUrl;
		U.log("commUrl: "+commUrl);
		String commHtml=U.getHtml(commUrl,driver);
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addSec=U.getSectionValue(commHtml, "<div id=\"comp-k6cyhjju\" class=\"_1Z_nJ\" data-testid=\"richTextElement\">", "Pre Construction Lot Sales");
		U.log("AddSec: "+addSec);
		if(addSec != null){
			addSec=U.getNoHtml(addSec).replaceAll("\\s+", " ").replace("Circle St Charles MO", "Circle, St Charles, MO");
			add=U.getAddress(addSec);
		}
		
		
		
		
		
		
		String map=U.getSectionValue(commHtml, "<a data-testid=\"linkElement\" ", "\">View Map");
		
			String mapUrl=U.getSectionValue(map, "href=\"", "\"");
			String maphtml = U.getHtml(mapUrl,driver);
		
//		U.log(map);
		String geo="FALSE";
		String lalon[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK){
			lalon=U.getlatlongGoogleApi(add);
			if(lalon == null) lalon = U.getlatlongHereApi(add);
		}

		
		String commType=U.getCommType(commHtml);
		String communityName=U.getSectionValue(commHtml, "<span style=\"font-family:peaches-and-cream-regular-w00,script;\">", "</span>").replace("&nbsp;", " ");
		String propStatus=U.getPropStatus(commHtml);
		commHtml = commHtml.replaceAll("name\":\"Custom", "");
		String proptype=U.getPropType(commHtml);
		commHtml=U.removeSectionValue(commHtml, "var serviceTopology = ", "</script>");
		commHtml = U.removeSectionValue(commHtml, "window.viewerModel = ", "</script>");
		
		commHtml = commHtml.replaceAll("story-and-a-half|title\":\"Story and a Half|SEO\":\"two-story|title\":\"Ranch Plans|ranch-pl|czcd\":\"Story and a Half|c1miu\":\"Ranch Plans|\"Two Story Plans\"|/story-and-a-half\"|/two-story-plans\"|(Two Story|Ranch) Plans</a>|Story and a Half</a>", "");
		
		String dervPropType=U.getdCommType(commHtml);
		
		U.log("dervPropType: "+dervPropType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{30}Story and a Half[\\s\\w\\W]{30}", 0));

		
		
		
		String prices[]=U.getPrices(commHtml, "Prices Starting at \\$\\d{3},\\d{3}", 0);
		String minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		String maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		String[] sqFt=U.getSqareFeet(commHtml, "\\d+ � \\d+ sq. ft.|\\d+,\\d+ � \\d+,\\d+ square feet|\\d{4} – \\d{4} sq. ft.|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|between \\d,\\d{3} – \\d,\\d{3} square feet|\\d{4}- \\d{4} square feet|<p>SqFt:\\s+\\d{4}</p>|SqFt:\\s+\\d{4}\\s+-\\s+\\d{4}|\\d{4}  Sq. Ft.", 0);
		String minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		String maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		
//		add[0]="18 Research Park Circle";
				
//			add[1]=	"St Charles"; 
//			add[2]="MO";
//			add[3]="63304";
		
			
			lalon=U.getlatlongGoogleApi(add);
//			lalon[0] = "38.694654";
//			lalon[1] = "-90.675987";
			/*		if(commUrl.contains("https://www.homesbywhittaker.com/missouri-bluffs-phase-one")){
			lalon = "38.694654,-90.675987".split(",");
			add = U.getAddressGoogleApi(lalon);
			if(add == null) add = U.getAddressHereApi(lalon);
		}*/
			
//		if(commUrl.contains("https://www.homesbywhittaker.com/missouri-bluffs")) {
			
			//propStatus = "Grand Opening";
//			minPrice = "$149,500";
			
//		}
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(communityName, commUrl, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(lalon[0], lalon[1], geo);
		data.addPropertyType(proptype, dervPropType);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyStatus(propStatus);
		data.addNotes(U.getnote(commHtml));
		//U.log(addSec);
//		}catch(Exception e){}
	}

}
