/*
 * @author : Pallavi
 * @date : 2/03/2019
 */

package com.shatam.b_301_324;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMarkTaylor extends  AbstractScrapper{
	CommunityLogger LOGGER;
	static String builderName = "Mark-Taylor";
	static String builderUrl = "https://www.mark-taylor.com";
	static int i = 0;
	static WebDriver driver=null;
	public static void main(String[] args) throws Exception{
		AbstractScrapper abs=new ExtractMarkTaylor();
		abs.process();
		FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abs.data().printAll());
	}
	
	public ExtractMarkTaylor()  throws Exception{
		super(builderName, builderUrl);
		LOGGER=new CommunityLogger(builderName);
	}

	public void innerProcess() throws Exception{
		JsonParser parser = new JsonParser();
		
		String link1="https://inventory.g5marketingcloud.com/api/v1/locations?client_id=1184&exclude_locs_from_search_override=true&multifamily=true&page=1&per_page=60&search_radius=16&search_units=mi&sort_by=state_then_city";
		String link2="https://inventory.g5marketingcloud.com/api/v1/locations?client_id=1184&exclude_locs_from_search_override=true&multifamily=true&page=2&per_page=60&search_radius=16&search_units=mi&sort_by=state_then_city";
		String html1=U.getHTML(link1);
		String html2=U.getHTML(link2);
		html1=html1+html2;
//		U.log(html1);
		String comSection =U.getSectionValue(html1, "{\"locations\":[", "null,\"per_page\":60}}");
		String[] comUrlSections=U.getValues(comSection, "\"urn\":\"", "]}");
		U.log(comUrlSections.length);
		for(String comSec :comUrlSections) {
			String comUrl = U.getSectionValue(comSec,"home_page_url\":\"","\"");
//			try {
				addDetails(comUrl,comSec, parser);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
		
	}
	public void addDetails(String comUrl,String comSec, JsonParser parser) throws Exception {
//		if(i>=40) {
		LOGGER.AddCommunityUrl(comUrl);
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("************REPEATED*********");
			return;
		}
		
//		if(!comUrl.contains("https://www.mark-taylor.com/apartments/az/surprise/terra-lane-on-cotton/"))return;
		U.log("Count :"+i);
		U.log("comUrl: "+comUrl);
		
		String comhtml=U.getHTML(comUrl);
		String comHtml = comhtml;
	
//		comhtml=U.getSectionValue(comhtml, "</title>", "<div class=\"col col-2\" id=\"drop-target-2-column-11550402\"");
//		if(comhtml==null)
//		if(comhtml!=null)
//		comhtml=U.getSectionValue(comhtml, "</title>", "<div class=\"flexslider-container\">");
//		else if(comhtml==null)
		comhtml=U.getSectionValue(comhtml, "</title>", "class=\"content row-halves\"");

//		U.log("..........."+comhtml);
		String comName=U.getSectionValue(comSec, "name\":\"", "\"");
		comName=comName.replace(" Apartments", "");
		U.log("Community Name :"+comName);
		//===================ADDRESS & Lat-Lng======================
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		add[0]=U.getSectionValue(comSec, "street\":\"", ",");
		add[1]=U.getSectionValue(comSec, "city\":\"", "\",");
		add[2]=U.getSectionValue(comSec, "state\":\"", "\",");
		add[3]=U.getSectionValue(comSec, "postal_code\":\"", "\",");
		U.log(Arrays.toString(add));
		
		latlng[0]=U.getSectionValue(comSec, "latitude\":", ",");
		latlng[1]=U.getSectionValue(comSec, "longitude\":", ",");
		U.log(Arrays.toString(latlng));
		//=================Amenities=====================
		
		String storeId = U.getSectionValue(comhtml, "\"G5_STORE_ID\": \"", "\"");
		U.log("StoredId ::"+storeId);

		String amenities=U.getSectionValue(comhtml, "<li class=\"has-subnav\">", "Amenities</a><ul class=\"subnav\">");
//		U.log(amenities);
		
		if(amenities==null) {
			amenities=U.getSectionValue(comhtml, " <div class=\"photo-card-wrapper\">", "<p class=\"paragraph-title\">Amenities</p>");
		}
		String amenUrl =U.getSectionValue(amenities, "<a href=\"/", "\">");
//		
		amenUrl=builderUrl+ "/" +amenUrl;
		U.log(amenUrl);
//		if(amenUrl==null)
//			amenities=builderUrl +"/amenities";

//		U.log(amenUrl);
		String amenhtml=U.getHTML(amenUrl);
		
		//=================FLOOR-PLANS===================
		String floorJson = null;
		
		if(storeId != null)
			try {
//			floorJson = U.sendPostRequestAcceptJson("https://inventory.g5marketingcloud.com/graphql", 
//				"{\"operationName\":\"ApartmentComplex\",\"variables\":{\"locationUrn\":\"" + storeId + "\",\"moveInDate\":\"\",\"unitsLimit\":9},\"query\":\"query ApartmentComplex($floorplanId: Int, $beds: [Int!], $baths: [Float!], $sqft: Int, $startRate: Int, $endRate: Int, $floorplanGroupId: [Int!], $amenities: [Int!], $locationUrn: String!, $moveInDate: String!, $unitsLimit: Int, $dateFlexibility: Int) {\\n  apartmentComplex(locationUrn: $locationUrn) {\\n    id\\n    showUnits\\n    showNumberOfAvailableUnits\\n    showLeaseTerms\\n    showBestValue\\n    floorplanGroupDescription\\n    pricingDisclaimer\\n    hasAllowableMoveInDays\\n    hasApartmentSpecials\\n    hasFloorplanSpecials\\n    singularUnitLabel\\n    firstAvailableMoveInDate\\n    lastAvailableMoveInDate\\n    brochurePdfLabel\\n    virtualTourLabel\\n    floorplans(id: $floorplanId, beds: $beds, baths: $baths, sqft: $sqft, startRate: $startRate, endRate: $endRate, floorplanGroupId: $floorplanGroupId, amenities: $amenities, moveInDate: $moveInDate, dateFlexibility: $dateFlexibility) {\\n      id\\n      altId\\n      externalIds\\n      name\\n      totalAvailableUnits\\n      unitsAvailableByFilters(moveInDate: $moveInDate, dateFlexibility: $dateFlexibility, amenities: $amenities, minPrice: $startRate, maxPrice: $endRate, limit: $unitsLimit)\\n      allowableMoveInDays\\n      beds\\n      baths\\n      sqft\\n      sqftDisplay\\n      rateDisplay\\n      startingRate\\n      imageUrl\\n      imageUrls\\n      locationCode\\n      virtualImageUrl\\n      depositDisplay\\n      floorplanGroupIds\\n      brochurePdf\\n      hasSpecials\\n      floorplanSpecial {\\n        id\\n        name\\n        __typename\\n      }\\n      floorplanAmenities {\\n        id\\n        name\\n        __typename\\n      }\\n      floorplanCta {\\n        name\\n        url\\n        actionType\\n        redirectUrl\\n        redirectUrlActionType\\n        ownerType\\n        vendorKey\\n        redirectVendorKey\\n        isExternal\\n        __typename\\n      }\\n      __typename\\n    }\\n    floorplanFilters {\\n      beds\\n      baths\\n      sqftMax\\n      sqftMin\\n      lastAvailableDate\\n      floorplanGroups {\\n        id\\n        description\\n        __typename\\n      }\\n      amenities {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}");
//				U.log("Inside");
				
			//GET THE JSON LINK FROM COMMUNITY PAGE	
			floorJson = sendPostRequestAcceptJson("https://inventory.g5marketingcloud.com/graphql", 
						"{\"operationName\":\"ApartmentComplex\",\"variables\":{\"locationUrn\":\"" + storeId + "\",\"moveInDate\":\"\",\"unitsLimit\":9},\"query\":\"query ApartmentComplex($floorplanId: Int, $beds: [Int!], $baths: [Float!], $sqft: Int, $startRate: Int, $endRate: Int, $floorplanGroupId: [Int!], $amenities: [Int!], $locationUrn: String!, $moveInDate: String!, $unitsLimit: Int, $dateFlexibility: Int) {\\n  apartmentComplex(locationUrn: $locationUrn) {\\n    id\\n    showUnits\\n    showNumberOfAvailableUnits\\n    showLeaseTerms\\n    showBestValue\\n    floorplanGroupDescription\\n    pricingDisclaimer\\n    hasAllowableMoveInDays\\n    hasApartmentSpecials\\n    hasFloorplanSpecials\\n    singularUnitLabel\\n    firstAvailableMoveInDate\\n    lastAvailableMoveInDate\\n    brochurePdfLabel\\n    virtualTourLabel\\n    floorplans(id: $floorplanId, beds: $beds, baths: $baths, sqft: $sqft, startRate: $startRate, endRate: $endRate, floorplanGroupId: $floorplanGroupId, amenities: $amenities, moveInDate: $moveInDate, dateFlexibility: $dateFlexibility) {\\n      id\\n      altId\\n      externalIds\\n      name\\n      totalAvailableUnits\\n      unitsAvailableByFilters(moveInDate: $moveInDate, dateFlexibility: $dateFlexibility, amenities: $amenities, minPrice: $startRate, maxPrice: $endRate, limit: $unitsLimit)\\n      allowableMoveInDays\\n      beds\\n      baths\\n      sqft\\n      sqftDisplay\\n      rateDisplay\\n      startingRate\\n      imageUrl\\n      imageUrls\\n      locationCode\\n      virtualImageUrl\\n      depositDisplay\\n      floorplanGroupIds\\n      brochurePdf\\n      hasSpecials\\n      floorplanSpecial {\\n        id\\n        name\\n        __typename\\n      }\\n      floorplanAmenities {\\n        id\\n        name\\n        __typename\\n      }\\n      floorplanCta {\\n        name\\n        url\\n        actionType\\n        redirectUrl\\n        redirectUrlActionType\\n        ownerType\\n        vendorKey\\n        redirectVendorKey\\n        isExternal\\n        __typename\\n      }\\n      __typename\\n    }\\n    floorplanFilters {\\n      beds\\n      baths\\n      sqftMax\\n      sqftMin\\n      lastAvailableDate\\n      floorplanGroups {\\n        id\\n        description\\n        __typename\\n      }\\n      amenities {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}");
			
			U.log("floorJson: "+floorJson);
			
			}catch(RuntimeException e) {
				U.log("Page Not Found for floor JSON");
			}
		String allFloorDetails = ALLOW_BLANK;
		if(floorJson != null) {
			JsonObject floorObj = (JsonObject) parser.parse(floorJson).getAsJsonObject().get("data").getAsJsonObject().get("apartmentComplex").getAsJsonObject();
			U.log(floorObj);
	
	//		JsonArray floorArray = floorObj.get("floorplans").getAsJsonArray();
	//		U.log("Total Floors ::"+floorArray.size());
		
			allFloorDetails = floorObj.get("floorplans").toString(); 
		}
		U.log(allFloorDetails);
		//======================PRICE===========================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices(allFloorDetails, "", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
 		//=====================SQ.FT============================
 		String minSqf=ALLOW_BLANK, maxSqf=ALLOW_BLANK;
 		String[] sqft=U.getSqareFeet(allFloorDetails, "sqftDisplay\":\"\\d{3}|sqftDisplay\":\"\\d,\\d{3}|sqftDisplay\":\"From \\d{3}|sqftDisplay\":\"From \\d,\\d{3}", 0);
 		minSqf =(sqft[0]==null)? ALLOW_BLANK:sqft[0];
 		maxSqf =(sqft[1]==null)? ALLOW_BLANK:sqft[1];
 		U.log("minsq :"+minSqf+"::"+" maxSqf :"+maxSqf);
 		//=====================Community Type====================
 		comHtml=comHtml.replace("lakefront lifestyle", "lakefront community");
 	
 		String ctype=U.getCommType((comHtml+amenhtml).replaceAll("S Country Club Dr", "").replace("Resort-Worthy Swimming Pool", "Resort Style"));
 		U.log("ctype :"+ctype);
 		//U.log(">>>>>>>>>>>>"+Util.matchAll(amenhtml, "[\\s\\w\\W]{30}resort[\\s\\w\\W]{30}", 0));
 		//=====================Property Type=====================
 		String proptype=U.getPropType(comHtml+amenhtml);
 		
 		U.log("proptype :"+proptype);
 		//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}resort[\\s\\w\\W]{30}", 0));
 		//====================Derived Property Type=============
 		String dtype=U.getdCommType(comhtml+amenhtml);
 		//=====================Property Status===================
// 		comhtml=comhtml.replace("Now open for in-person tours! Schedule yours today.", "Now Open");
 		String pStatus=U.getPropStatus((comhtml).replaceAll("Now open for in-person|center\">Coming Soon </h2>", "").replace("Open Summer 2022", "OPENING SUMMER 2022").replace("Coming to Surprise in Spring 2022", "Coming in Spring 2022"));
 		U.log("pStatus :"+pStatus);
// 		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Now open[\\s\\w\\W]{30}", 0));
 		
 		//.replace("Now open for in-person", "NOW OPEN")
 		//=================== Note ========================
 		String notes = U.getnote(comhtml.replaceAll("Now Pre-Leasing|pre-lease", "Now Pre-Leasing")
 				.replace("Leasing, Reimagined", "Now Leasing, Reimagined"));
 		
 		U.log("notes :"+notes);
 		
// 		U.log(">>>>>>>>>>>>"+Util.matchAll(comhtml, "[\\s\\w\\W]{30}lease[\\s\\w\\W]{30}", 0));
// 		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}lease[\\s\\w\\W]{30}", 0));	
 		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
 				data.addCommunity(comName, comUrl,ctype);
 				data.addAddress(U.getNoHtml(add[0]).trim(), add[1].trim(), add[2].trim(), add[3].trim());
 				data.addSquareFeet(minSqf, maxSqf);
 				data.addPrice(minPrice, maxPrice);
 				data.addLatitudeLongitude(latlng[0], latlng[1], geo);
 				data.addPropertyType(proptype,dtype );
 				data.addPropertyStatus(pStatus);
 				data.addNotes(notes);
 				
//	}
		i++;
	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
	        connection.setRequestProperty("origin", "https://www.mark-taylor.com");
	        connection.setRequestProperty("referer", "https://www.mark-taylor.com/");
	        connection.setRequestProperty("sec-fetch-mode", "cors");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/70.0.3538.77 Chrome/70.0.3538.77 Safari/537.36");
	        connection.setRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
	        connection.setRequestProperty("content-type", "application/json");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	
	
	
	
}