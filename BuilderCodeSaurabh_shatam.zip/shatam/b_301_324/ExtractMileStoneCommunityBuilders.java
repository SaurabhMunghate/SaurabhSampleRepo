/**
 * @author Sampada Santosh*/

package com.shatam.b_301_324;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMileStoneCommunityBuilders extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://www.mymilestone.com";
	WebDriver driver = null;
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractMileStoneCommunityBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"MileStone Community Builders.csv", a.data().printAll());

	}
	public ExtractMileStoneCommunityBuilders() throws Exception {

		super("MileStone Community Builders", "https://www.mymilestone.com/");
		LOGGER = new CommunityLogger("MileStone Community Builders");
	}

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
		U.setUpChromePath();
		driver = new ChromeDriver();
		String baseHtml=U.getHtml("https://www.mymilestone.com", driver);
		
		String regSec=U.getSectionValue(baseHtml,"CURRENT COMMUNITIES","coming soon communities");
		
		String comUrlSection[] = U.getValues(regSec,"<li ng-repeat=\"community in region.communities", "</li>");
		U.log("Total comm. :"+comUrlSection.length);
		for(String comUrlSec : comUrlSection){
			
			String comUrl = U.getSectionValue(comUrlSec, "<a ng-href=\"", "\"");
			if(!comUrl.startsWith("http")) comUrl = BASEURL+ comUrl;
			U.log(comUrl);
			String cs = Util.match(comUrlSec, "\">(.*?)</a>");
//			try {
				addDetails(comUrl, comUrlSec,cs, driver);
//			} catch (Exception e) {}
		}
		
//		String regSecUrls[]=U.getValues(regSec,"<p class=\"h4\"><a ng-href=\"","\" ");
		//U.log("hiii");
//		U.log("length=="+regSecUrls.length);
		//for(String regSecUrl:regSecUrls){
			//addDetails(val);
			//String regSecUrlCombine= "https://www.mymilestone.com/find-your-home"+regSecUrl;
			
			//U.log(regSecUrlCombine);
			
			//String regHtml=U.getHtml(regSecUrlCombine, driver);
/*			String h=U.getHtml("https://www.mymilestone.com/buda-and-kyle",driver);
			String comsection[]=U.getValues(h, "ng-attr-target=\"&lt;% community.url_override ? '_blank' : undefined %&gt;\" class=\"ng-binding\"", "/a>");
				U.log(comsection.length);
			for(String cs:comsection) {
			U.log(cs);
			
			if(cs.contains("https://www.mymilestone.com/round-rock/the-meadows-at-quick-ranch"))	
			{
String comUrl1="https://www.mymilestone.com/round-rock/the-meadows-at-quick-ranch";				
				U.log(comUrl1);
			String comsec12=U.getHtml(comUrl1, driver);
			String comsec1=U.getSectionValue(comsec12, "<div class=\"section-description hidden-xs\">", "</p></div>");
		addDetails(comUrl1, comsec1,cs, driver);
			}
			else {
				String comUrl="https://www.mymilestone.com/"+U.getSectionValue(cs, "href=\"/", "\"");
				
				U.log(comUrl);
			String comsec21=U.getHtml(comUrl, driver);
			String comsec2=U.getSectionValue(comsec21, "<div class=\"section-description hidden-xs\"><p>", "</p></div>");
		addDetails(comUrl, comsec2,cs, driver);
			}
		}
		*/
		
		driver.quit();
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comUrl, String comSec, String cs, WebDriver driver) throws Exception {	
			
//		if(j>=10 && j<=20)
//		if(j>3)
		{	
			
//TODO:
			U.log(j+"\tcomUrl=="+comUrl);
			
			//=============== RUN ==========================
//		if(!comUrl.contains("wilson-trace"))return;
//		if(!comUrl.contains("https://www.mymilestone.com/leander-and-liberty-hill/bonnet")) return;
			
			
			if (data.communityUrlExists(comUrl)){
	        	LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
	        	return;
	        }
			LOGGER.AddCommunityUrl(comUrl);
			
			if(comUrl.contains("https://www.mymilestone.com/cedar-park/wilson-trace")) {
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------NOT SHOWING UP ON REGION");
				return;
			}
			
			
			String communityHtml=U.getHtml(comUrl, driver);
			U.log(U.getCache(comUrl));
    		String priceSec = U.getSectionValue(communityHtml, "<h2 class=\"no-fade\" split-at=\"\">", "</p");

			String pcHtml=communityHtml;
			
			String imgState = U.getSectionValue(communityHtml, "<h2 class=\"no-fade\"", "</div>");
    		
			
			//String commsecScript=U.getSectionValue(communityHtml, " community: {\"id\"", "\"pivot\":{\"");
			String commsecScript=U.getSectionValue(communityHtml, " community: {\"id\"", "\"description_nearby_communities\"");
//			commsecScript=commsecScript.replace("luxury","");
//			commsecScript=commsecScript.replace("Covered patio","");
//			commsecScript=commsecScript.replace("patio", "");
//			commsecScript=commsecScript.replace("one- and two-story", "");
//			commsecScript=commsecScript.replace("Single Family Homes ", "");
//			commsecScript=commsecScript.replace("traditional home", "");
    		
		     String removeSection=U.getSectionValue(communityHtml, "var _MicrositeDataCache", "</script>");
			
			
			if(removeSection!=null)
			{
				U.log("fffffffffff    ");
				communityHtml=communityHtml.replace(removeSection,"");
				
			}
//			U.log("XX"+communityHtml);
			String description[]=U.getValues(communityHtml, "\"description_coming_soon\":", "\"description_gallery\"");
			for(String desc:description) {
				communityHtml=communityHtml.replace(desc,"");
			}
			String remContact=U.getSectionValue(communityHtml, "Contact Info</h2>", "QUICK SIGN UP");
    		if(remContact!=null) {
    			
    			U.log("ggggggggggg");
    			communityHtml=communityHtml.replace(remContact, "");
    		}
    		
			communityHtml=communityHtml.replace("Selling our model", "");
			communityHtml=communityHtml.replaceAll("<span>Coming soon</span>|coming soon communities|delivery homes</a>","");
			communityHtml=communityHtml.replace("sold-out","");
			communityHtml=communityHtml.replace("Temporarily Sold Out","");
			communityHtml=communityHtml.replace("move-in","");

			
			// href="/downtown-south-austin/the-hills-of-bear-creek">The Hills of Bear Creek<
		    String communityName=U.getSectionValue(cs,"\">","<");
		    if(communityName != null) communityName = communityName.replaceAll("<.*?>", "").replace("BY M SIGNATURE", "").trim();
		   // U.log("communityName ::"+communityName);
		    String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			
			String addressSection = U.getSectionValue(communityHtml, "<div class=\"col-xs-12 col-sm-12 col-lg-12\">", ">GET DIRECTIONS<");
			String address="";
			String geo = "FALSE";
			
    		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
    		String latLongsec = U.getSectionValue(communityHtml, "https://maps.google.com/maps?daddr=","\"");
    	
    		
    		if (latLongsec != null) {
    			latLongsec=latLongsec.replace("%2C+", ",");
    		latLong=latLongsec.split(",");
    		
    		//U.log(Arrays.toString(latLong));
    		}
    		
		    if(addressSection!=null)
		    {
            address=U.getSectionValue(addressSection, "<p><i class=\"fa fa-map-marker\"></i>", "</span></p>");	
            address=address.replaceAll("<br /><span>|<br><span>","").replace("Road, #22", "Road #22");
           // U.log("address=="+address);
            add=address.split(",");
            
            add=U.getAddress(address);
            add[0]=add[0].replaceAll("15187 Turtle Rock, Austin, TX 78729","15187 Turtle Rock");
		    }
		    if(addressSection==null)
		    {
		    	address=U.getSectionValue(communityHtml, "</h3><h3 class=\"text-align-center\">", "</h3>");	
		    	if(address!=null)
		    	{	    		
		    	add=address.split(",");
	            add=U.getAddress(address);
	            latLong[0]=U.getSectionValue(communityHtml, "\"mapLat\":", ",");
	            latLong[1]=U.getSectionValue(communityHtml, "\"mapLng\":", ",");
	            
	            if(latLong[0]==ALLOW_BLANK&&latLong[1]==ALLOW_BLANK)
	            {
	            	latLong=U.getAddressGoogleApi(add);
	            	geo="TRUE";
	            }
		    	}
		    	else
		    	{
		    	address=U.getSectionValue(communityHtml, "center;\">–", "–</h2>");	
		    	//U.log(address);
		    	if(address!=null)
			    {	    		
			     address=address.replace("Austin Texas","Austin ,TX");
		         add=U.getAddress(address);
		            
		            if(add[3]==ALLOW_BLANK&& latLong[0]!=null)
		            {		            	
		            	add[3]=U.getAddressGoogleApi(latLong)[3];
		            	geo="TRUE";
		            }
		           
			    }
		    	}
		    }
            
    		String floorHtml=ALLOW_BLANK;
    		String commId = U.getSectionValue(communityHtml, "ng-model=\"signup.communities[0]\" ng-value=\"", "\"");
    		//U.log("ComId::::"+commId);
    		try {
    		String residences[] = U.getValues(U.getHtml(comUrl, driver), "\"community_id\":"+commId+",\"residence_series_id\":", "\"you_tube_url\":\"");
			for(String residence : residences) {
				if(residence.contains("Temporarily Sold Out") || residence.contains("Sold"))continue;
				floorHtml+=residence;
			}
    		}
    		catch(NullPointerException ne) {}
    		
    		//U.log("floorHtml: "+floorHtml);
    		//----------Move in ready Status--------------
    		String moveHtml = ALLOW_BLANK;
//    		String[] moveUrls = {"/north-austin-cedar-park","/downtown-south-austin","/buda-and-kyle","/round-rock","/leander-and-liberty-hill","/cedar-park"}; //,"/buda","/hill-country"
    		String[] moveUrls = {"/leander-and-liberty-hill","/downtown-south-austin","/buda-and-kyle","/dripping-springs","/round-rock","/cedar-park"}; //,"/buda","/hill-country"

    		int countMoveHomes = 0;
    		String moveData = ALLOW_BLANK;
    	
    		for(String moveUrl : moveUrls){
    			moveUrl = "https://www.mymilestone.com/quick-delivery-homes" + moveUrl ;
    			U.log("moveUrl : "+moveUrl);
    			moveHtml += U.getHtml(moveUrl, driver);
    		}
    		//U.writeMyText(moveHtml);
    		String[] moveHomes = U.getValues(moveHtml, "<div class=\"title-container\">", "</ul>"); 	
    		U.log("moveHomes : "+moveHomes.length);
    		
    		for(String moveHome : moveHomes){
//    			U.log(moveHome.contains(comUrl.replace("https://www.mymilestone.com", "").trim()));
    			//if(moveHome.contains(communityName.trim()))
    			if(moveHome.contains(comUrl.replace("https://www.mymilestone.com", "").trim()))	
    			{
//    				U.log("moveHtml kkk"+moveHome.contains("568,000"));
    				moveData += moveHome;
    				countMoveHomes++;
    			}
    		}
    		moveData = moveData.replace("k</span>", ",000</span>");
    		//U.log(moveData);
    		// ---------community type,property type,property status,derived, property type---------//

    	//String comSec=ALLOW_BLANK;
//    		if(communityHtml.contains("\"property_type\":\"single family home\""))
//    			communityHtml=U.getSectionValue(communityHtml,"\">Welcome to</p>","<h2 class=\"text-center\"> Nearby ")+":: Single Family";
    		communityHtml=U.getSectionValue(communityHtml,"\">Welcome to</p>","<h2 class=\"text-center\"> Nearby ");
    		/*if(comSec==null){https://www.mymilestone.com/round-rock/the-meadows-at-quick-ranch
    			comSec=communityHtml;
    		}*/
    		
//    		communityHtml = communityHtml.replaceAll("first floor|1st floor", " 1 story ").replace("2nd floor ", " 2 story ");
//    		communityHtml = communityHtml.replaceAll("_Courtyard|isSecondOpen", "");
    		
    		//------------ComTYpe-----------------
    		String commType = U.getCommunityType(comSec+communityHtml);
    				
    		//----------Property Type------------------

//			String	 statusSection=U.getSectionValue(communityHtml, "<div class=\"section-wrap\">", "Click here</a>");

    		
    		
//    		communityHtml = communityHtml.replace("luxurious neighborhood", " luxury home").replace("farm-house exterior", "Farmhouse-style exteriors");
    		String propType = ALLOW_BLANK;
    		propType = U.getPropType((communityHtml+comSec+commsecScript)
    				.replace("The homes at Wilson Trace are luxury made livable", "The homes at Wilson Trace are luxury residential made livable")
    				.replace("luxurious lineup features", "luxury homes")
    				.replaceAll("isSecondOpen|Thoughtfully Designed Town Homes in South|headline ng-binding\">Single Family Homes|property_type\":\"townhouse|without the luxury prices? ", ""));

    		U.log("propType:::::::::"+propType);
    		
    		
    		
    		//-----------derived Property Type------------
    		
//    		communityHtml=communityHtml.replaceAll("Sauls Ranch|ranch_|sauls-ranch|11750 Ranch to|5200 Cypress Ranch","").replace("1 and 2-story", " 1 Story  2 Story ");
    		String dpType = U.getdCommType(communityHtml+commsecScript);
    		U.log("OK");
    		//---------Community Type------------
    		String commStatus = ALLOW_BLANK;
    		String comStatusSection = ALLOW_BLANK;
    		comStatusSection = U.getSectionValue(communityHtml, "<p class=\"h4\">Welcome to</p>", "</section")+U.getSectionValue(communityHtml, "section-description\">", "/div>")+U.getSectionValue(communityHtml, "<div class=\"carousel-caption\">", "</p>");
    		U.log(comStatusSection+"comStatusSectioncomStatusSection");
    		
    		if(comStatusSection == null )comStatusSection = ALLOW_BLANK;
    		else
    			comStatusSection = comStatusSection.replace("currently sold out of Phases 1", "currently sold out Phases 1").replace("Phase 6 is coming later in 2021", "Phase 6 coming later 2021").replace("currently sold out of Phases 1", "currently sold out Phases 1");
    	
//    		String statusSection="";
//    		U.log("comStatusSectioncomStatusSection"+comStatusSection);
    		commStatus = U.getPropStatus((comStatusSection+comSec+imgState)
    				.replace("PHASES 12 & 13 ARE NOW OPEN", "PHASES 12 & 13 NOW OPEN")
    				.replace("The final phase of homes at The Hills of Bear Creek is coming soon!", "final phase coming soon").replace("Phase 6 is coming later in 2021", "Phase 6 coming later 2021").replace("currently sold out of Phases 1", "currently sold out Phases 1")
    				.replaceAll("including information on phase 5 homes selling|'Sold Out'\"|homes are now available|\"price_status\":\"Sold Out\"|quick move-in</div>|perfect ready to move in home|homes are ready to move in|<strong>QUICK MOVE-IN</strong>", ""));	
    		
//    		U.log("commStatus: "+commStatus);
    		
//			U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comStatusSection+comSec+imgState, "[\\w\\s\\W]{30}now selling[\\w\\s\\W]{30}", 0));
    		
//    		U.log("countMoveHomes : "+countMoveHomes);
    		
    			
    				
    				// --prices---//
    		String floor1=U.getHtml(comUrl+"/floorplans",driver);
    		String availableHomes=U.getHtml(comUrl+"/available-homes",driver);
    		
    		
    		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

    		communityHtml=communityHtml.replaceAll("00's", "00,000")
    				.replace(" High $400s", " High $400,000").replace("0s","0,000").replace("Starting at $768,990", "").replace("0&#039;s", "0,000").replace("0Ks", "0,000").replace("0's", "0,000").replace("0’s","0,000");
    		
    		comSec = comSec.replace("0's", "0,000");
    		floor1=floor1.replace("0s","0,000");
    		if(priceSec!=null)priceSec=priceSec.replaceAll("0's|0's|0Ks|0s", "0,000");
//    		U.log(priceSec+"::::::::pricesec");
    		
    		String[] price = {};
    		String communityHtml1=U.getSectionValue(communityHtml, "<div class=\"section-wrap\">", "Contact Info</h2>");
    		floor1=U.getSectionValue(floor1, "<div class=\"section-wrap\">", "Contact Info</h2>");
    		availableHomes=U.getSectionValue(availableHomes, "<div class=\"section-wrap\">", "Contact Info</h2>");
    		price =U.getPrices(priceSec + floor1 + availableHomes + communityHtml1, "Mid \\d{3},\\d{3} - \\d{3},\\d{3}|From The \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|the (high|mid|low) \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);

    		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
    		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];


    		//U.log("<<<<<<<<<<<< "+Util.matchAll(communityHtml,"[\\s\\w\\W]{50}\\$878[\\s\\w\\W]{30}", 0));

    		
    		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
    				// -----------sqreft-----------//
    		
    		communityHtml = communityHtml.replaceAll("(\\d,\\d{3} - \\d,\\d{3})\\s+<br /> square feet", " $1 square feet ");
    				
    		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK; //\\d,\\d{f360-embed-container3}\\s*\\n*\\s*SQFT
    		String[] sqft = U.getSqareFeet((comSec+floorHtml+communityHtml+floor1).replace("499,542", ""), "from \\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} square feet|\\d+ Square Feet</h2>|\\d{3} - \\d{3}<br> square feet|<span>\\d{1},\\d{3} - \\d{1},\\d{3}<br /> square feet|<span>\\d{1},\\d{3} - \\d{1},\\d{3}<br> square feet|\\d+,\\d+ SQ FT.|<span>​\\d+ Sq. Ft.|\\d{3} \\- \\d{3}<br\\s*/>\\s*square feet|<br />​\\d+ Sq. Ft.|\\d{4} Square Feet|\\d{3} sq fT|\\d{1},\\d{3} sq fT", 0);

    		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
    		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
    		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
    		
//    		U.log("<<<<<<<<<<<< "+Util.matchAll(communityHtml,"[\\s\\w\\W]{300}2,920[\\s\\w\\W]{300}", 0));
    		
//    		if(comUrl.contains("https://www.mymilestone.com/dripping-springs/skyridge"))
//    			maxPrice="$1,079,086";
    				
//    		if(comUrl.contains("https://www.1306west.com")){
//    					minPrice = "$400,000";
//    					maxPrice = "$600,000";
//    					minSqf= "731";
//    					maxSqf = "1129";
//    				}
    		if(countMoveHomes >0 && !commStatus.contains("move") &&  moveData.contains(communityName)||comUrl.contains("skyridge")){
    			
    			
//        		if(commStatus.length()>4){
//        		commStatus = commStatus + ", Quick Delivery Homes";
//        		}
//        		else
//        		{
//        		commStatus = "Quick Delivery Homes";
//        		}
        	}

//    		if(comUrl.contains("/downtown-south-austin/7300-south-congress"))commStatus ="Sold Out";
//    		if(comUrl.contains("https://www.mymilestone.com/north-austin-cedar-park/the-enclave-at-leander-station"))commStatus +=", Sold Out";
    		
//    		if(comUrl.contains("https://www.mymilestone.com/downtown-south-austin/the-hills-of-bear-creek"))
//    			commStatus=commStatus+", New Homes Coming Soon";
//    		if(comUrl.contains("https://www.mymilestone.com/downtown-south-austin/summerrow/"))https://www.mymilestone.com/round-rock/the-meadows-at-quick-ranch
//    			propType=ALLOW_BLANK;
//    		if(comUrl.contains("https://www.mymilestone.com/cedar-park/trento"))
//    			propType +=", Estate Style homes";
    		
//    			if(comUrl.contains("https://www.mymilestone.com/cedar-park/wilson-trace")) {
//        			propType="Farmhouse Style Homes";
//        			//minPrice="$768,990";
//    			}
//    		if(comUrl.contains("https://www.mymilestone.com/downtown-south-austin/summerrow"))
//    			propType=ALLOW_BLANK;
//    		if(comUrl.contains("leander-and-liberty-hill/bonnet"))propType+=", Estate Style homes";
//    		if(comUrl.contains("leander-and-liberty-hill/larkspur"))commStatus=commStatus.replace("Now Open", "Phases 12 & 13 Now Open");
//    		if(comUrl.contains("the-meadows-at-quick-ranch"))add[0]=add[0].replace("Drive,", "Drive");
    		
    		
//    		=======================================================================
    		String lotCount=ALLOW_BLANK;
    		String[] lot_data=null;
    		String  mapLink = ALLOW_BLANK;
    		mapLink=U.getSectionValue(communityHtml, "<iframe class=\"f360-embed-iframe\" src=\"", "\"");
    		U.log("mapLink=="+mapLink);
    		
    		if(mapLink!=null) {
    			String mapHtml=U.getHtml(mapLink, driver);
    			if(mapHtml!=null) {
    				 lot_data=U.getValues(mapHtml, "<g id=\"lot", "</g>");
    				U.log("lotCount=="+lot_data.length);
    				if(lot_data.length>0) {
    					lotCount=Integer.toString(lot_data.length);
    					 U.log("lotCount1=="+lotCount);
    				}
    			}
    		}
//    		else if(communityHtml.contains("<div class=\"site-plan-pins\">")) {
//    				lot_data=U.getValues(communityHtml, "<div class=\"site-plan-pins\">", "/>");
//    				if(lot_data.length > 0) {
//        			lotCount=Integer.toString(lot_data.length);
//    				 U.log("lotCount2=="+lotCount);}
//    			
//    		}
    		else if(communityHtml.contains("<div class=\"site-plan-pins\">")) {
    				lot_data=U.getValues(communityHtml, "<div class=\"site-plan-pin ng-scope\"", "}");
    				if(lot_data.length > 0) {
        			lotCount=Integer.toString(lot_data.length);
    				 U.log("lotCount3=="+lotCount);
    				}
    		}
    		
    		if(add[0].contains(",")) {
    			add[0] = add[0].replace(",", "");
    		}
    		if(comUrl.contains("/leander-and-liberty-hill/bonnet")) {
    			commStatus = "Quick deliver home";
    		}
    		if(comUrl.contains("round-rock/the-meadows-at-quick-ranch")) {
    			commStatus = "Now Selling Final Opportunities";
    		}
    		if(comUrl.contains("om/leander-and-liberty-hill/bonnet")) {
    			commStatus = "Quick Deliver Homes";
    		}
    		
    		data.addCommunity(communityName, comUrl, commType);
			data.addAddress(add[0].trim(), add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(commStatus.replace(", Ready To Move In", ""));
			data.addNotes(U.getnote(communityHtml));
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		
			j++;
		
		
	}
}