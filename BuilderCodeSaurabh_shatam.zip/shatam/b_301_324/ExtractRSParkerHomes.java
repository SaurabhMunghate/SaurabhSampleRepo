/**
 * @Author Name-Sampada Santosh
 * modified By : Priti
 * Date: Aug 2017
 */
package com.shatam.b_301_324;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractRSParkerHomes extends AbstractScrapper {
	static String BASEURL = "https://www.rsparkerhomes.com/";
	CommunityLogger LOGGER;
	int i;
	WebDriver driver= null;
	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRSParkerHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"RS Parker Homes.csv", a.data()
				.printAll());
	}

	public ExtractRSParkerHomes() throws Exception {

		super("RS Parker Homes", BASEURL);
		LOGGER = new CommunityLogger("RS Parker Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver =new FirefoxDriver(U.getFirefoxCapabilities());
		String baseUrl=U.getHtml("https://www.rsparkerhomes.com/find-a-home/", driver);
		
		String Vals[]=U.getValues(baseUrl,"\"house-image\">","</span></span></p>");
		
		U.log("CommLength::::::::"+Vals.length);
		
		for(String Val:Vals){
			
			String url=U.getSectionValue(Val,"<a href=\"","\">");
			
			addDetails(Val,url);
			
		}
		driver.close();
	}
	
	public void addDetails(String comSec,String url) throws Exception {
//	if(i == 20)
	{
		String html=U.getHtml(url, driver);
		//if(!url.contains("https://www.rsparkerhomes.com/neighborhood/arrowhead-grand/"))return;
		//-------------CommName------------------------// 
		
		
		String communityName=U.getSectionValue(html,"<title>","</title>");
		communityName=communityName.replace(" - R.S. Parker","");
		U.log("comName::::::::::::::"+communityName);
		
		//--------------Latlong-------------------//
		
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "/maps.google.com?daddr","\">");
		if (latLongsec != null) {
			
			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			
		}
		
		
		//---------------adresss------------//
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String ad1 = U.getSectionValue(html, "<div class=\"google-map-container\">", "<a target=\"_blank\" href=");
		String ad=U.getSectionValue(ad1,"<p>","</p>");

		if (ad != null) {
			
			ad=ad.replace("Conway", ",Conway");
			ad=ad.replace("Drive Myrtle Beach", "Drive ,Myrtle Beach");
			ad=ad.replace("Longs",",Longs");
			ad=ad.replace("North Myrtle Beach",",North Myrtle Beach");
			ad=ad.replace(" S ,North Myrtle Beach"," S North Myrtle Beach");
			ad=ad.replace("Loop Calabash","Loop ,Calabash");
			ad=ad.replace("Little River",",Little River");
			ad=ad.replace("Lewisville",",Lewisville");
			ad=ad.replace("1901 Pine Cone Lane, ,Longs","1901 Pine Cone Lane,Longs");
			
			U.log("adressss:::::::::"+ad+"***************************");
			add = U.getAddress(ad);
			geo="FALSE";
		}
		
		
	
		if (add[3] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		
		if (add[2] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[2] = addr[2];
			geo = "TRUE";
		}
		
		if (add[1] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[1] = addr[1];
			geo = "TRUE";
		}
		
		if (add[0] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[0] = addr[0];
			geo = "TRUE";
		}
		
		U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
				+ " add[3] " + add[3]);

		//----------Avaiable Homes data---------------
		String mainAvailUrl = Util.match(html, "<li><a href=\"(.*?)\">Available Homes</a></li>",1);
		U.log("mainAvailUrl : "+mainAvailUrl);
		String mainAvailHtml = U.getHtml(url+mainAvailUrl,driver);
		
		String allAvailHomeData = ALLOW_BLANK;
		String[] availUrls = U.getValues(mainAvailHtml, "</p><a class=\"view-more\" href=\"", "\">View</a>");
		U.log("Available Url::"+availUrls.length);
		for(String availUrl : availUrls){
			U.log("availUrl : "+availUrl);
			String availHtml = U.getHTML(availUrl);
			String avalSec = U.getSectionValue(availHtml, "<div class=\"section-content\">", "<div class=\"slider-gallery\">");
			if(avalSec == null)
				avalSec = U.getSectionValue(availHtml, "<div class=\"section-content\">", "<footer class=");
			
			allAvailHomeData +=  avalSec;
		}
		allAvailHomeData = allAvailHomeData.replace("on first floor", " 1 story ");
		
		//--------All floorPlanData-----------
		String mainFloorUrl = Util.match(html, "<li><a href=\"(.*?)\">Floor Plans</a></li>",1);
		U.log("mainFloorUrl : "+mainFloorUrl);
		String mainFloorHtml = U.getHtml(url+mainFloorUrl,driver);
		
		String allFloorPlanData = ALLOW_BLANK;
		String[] floorUrls = U.getValues(mainFloorHtml, "</p><a class=\"view-more\" href=\"", "\">View</a>");
		
		for(String flrUrl : floorUrls){
			U.log("flrUrl : "+flrUrl);
			String floorHtml = U.getHTML(flrUrl);
			allFloorPlanData += U.getSectionValue(floorHtml, "<h2>", "slider-floor-options\">"); 
		}
		allFloorPlanData = allFloorPlanData.replace("1 Level Home|on first floor", " 1 story ");
		allFloorPlanData = allFloorPlanData.replace("<li>Loft</li>", "<li>Loft Homes</li>");
		allFloorPlanData = allFloorPlanData.replace(" Courtyard Garage</li>", "");
		
		// ---------community type,property type,property status,derived,
		// property type---------//
		
		String sec=ALLOW_BLANK;
		sec = U.getSectionValue(html," property=\"og:title\" />","property=\"og:site_name\" />");
		
		sec += U.getSectionValue(html, "<div id=\"overview\" class=\"", "</div>");
		U.log(sec);
		sec = sec.replace("More information coming soon", "");
		String commType = U.getCommunityType(sec);
		String propType = U.getPropType(sec+allAvailHomeData+allFloorPlanData);

		String dpType = U.getdCommType(sec+allAvailHomeData+allFloorPlanData);
		String commStatus = ALLOW_BLANK;
		commStatus = U.getPropStatus(sec);
		
		if(mainAvailHtml.contains("rgb(221, 51, 51);\">Move In Ready ") && !commStatus.contains("Move")){
			if(commStatus.length()<4 ){
				commStatus = "Move In Ready";
			}
			else{
				commStatus = commStatus +", Move In Ready";
			}
		}

		// --prices---//
		String[] price = U.getPrices(comSec, "\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}<br />", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(comSec+html, "\\d{4} square feet to \\d{4} square feet|\\d{1},\\d{3} - \\d{1},\\d{3} <span>", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		add[0] = add[0].toLowerCase();
		add[1] = add[1].toLowerCase();

		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));

	}	
	i++;
	}
	
	
	
	
}