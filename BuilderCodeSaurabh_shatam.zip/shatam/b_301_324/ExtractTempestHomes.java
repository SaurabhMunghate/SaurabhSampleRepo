/** Modification Sawan.
 *  @date 11/03/2017 
 */

package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTempestHomes extends AbstractScrapper {

	CommunityLogger LOGGER;
	private static String builderUrl = "http://tempesthomes.com";
	private static String builderName = "Tempest Homes";
			
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractTempestHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"/Tempest Homes.csv", a.data().printAll());
	}

	public ExtractTempestHomes() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("http://www.tempesthomes.com/communities");
		String sec = U.getSectionValue(html,"<ul class=\"nav community-nav\">", "</ul>");
		String[] communitiesInfo = U.getValues(sec, "<li><a ", "</li>");
		String latLongSec = U.getSectionValue(html, "function initialize()", "function");
//		U.log(latLongSec);
		for (String communityInfo : communitiesInfo) {
//			U.log(communityInfo);

			String communityUrl = U.getSectionValue(communityInfo, "href=\"", "\"");

//			U.log("comUrl---" + communityUrl);
			String communityName = U.getSectionValue(communityInfo, "\">",	"</a>");
//			U.log(communityName);
			String latLng = Util.match(latLongSec, ""+"setMarker\\((.*)?"+communityUrl);
//			U.log("==="+latLng);
			addDetails(builderUrl+communityUrl,communityName,latLng);
		}
		LOGGER.DisposeLogger();
	}
	int j = 0;
	private void addDetails(String comUrl, String commName, String latLng) throws Exception {
//	if(j == 2)
	{

		U.log("count =:"+j);
		U.log("=="+comUrl);
		
		String htm = U.getHTML(comUrl);

		if (this.data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		// Taking prop status from Community name
		U.log("Community Name :" + commName);
		
		String proStatusSec = commName;
		//=========== Community Name ===================
		commName = commName.replaceAll(" - (.*)?", "");
		U.log("Community Name :" + commName);

		//=============  Price ===================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String html = U.getHTML(comUrl);
		// htm=htm.replaceAll("( )(\\d+'s)", "$1\\$$2").replaceAll("(\\d)'s",
		// "$1,000s");
		html = html.replaceAll("0's", "0,000");
		String[] price = U	.getPrices(html,
						"from \\$\\d+,\\d+|low \\d+,\\d+|\\$\\d+,\\d+s|\\$\\d+,\\d+|from the \\d+,\\d+",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		//=========== Square Feet ========================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(htm,
				"<td>\\s*\\d{4}\\s*</td>|Sqft: \\d+", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		//=========== Propert Status ====================
		String status = ALLOW_BLANK;
		String statSec = htm;
		String remove = "Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|<li><a href=\"/move-in-ready\">Move In Ready</a></li>";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		remove = U.getSectionValue(html, "header-navbar", ">Contact");

		statSec = statSec.replace(remove, "");
		remove = U.getSectionValue(html, "container text", " Rights Reserved");
		statSec = statSec.replace(remove, "");
		String statusSec = U.getSectionValue(htm, "Information</a>","information\">");
		

//		U.log("proStatusSec::"+proStatusSec);
		status = U.getPropStatus(proStatusSec);
		String addStatus = U.getPropStatus(statusSec);
		
		U.log("PStatus ==="+status);


		String ad=ALLOW_BLANK;
		if (htm.contains("Move In Ready Homes") && htm.contains("<div class=\"col-sm-4\" st")) {

			if (status == ALLOW_BLANK) {
				status = "Move In Ready Homes";
			} else{
				if(!status.contains("New Lots Now Available"))
				status += ",Move In Ready Homes";
				else
					ad="2 Story";
			}
		}
		else{
			if (status == ALLOW_BLANK) {
				status = "No Move In Ready Homes";
			} else{
				if(!status.contains("New Lots Now Available"))
				status += ",No Move In Ready Homes";
				else
					ad="2 Story";
			}
		}
		
		status = status.replace("-,", "");
		status=status.replace("Phase Iii Now Open", "Phase III Now Open");
		// ===========Address and Lat, Long============
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		
		String add [] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		String geo="False";
		
		String addSection = U.getSectionValue(html, "<div class=\"well well-sm\">", "</div>");
//		U.log("=="+addSection);
		if(addSection != null){
			String addSec = U.getSectionValue(addSection, "</strong></p>", "</p>");
//			U.log(addSec);
			if(addSec == null)
				addSec = U.getSectionValue(addSection, "<p><strong>","</strong></p>");
			if(addSec != null){
				addSec = addSec.replaceAll("<p>", "").replaceAll("<br>", ", ");
				U.log(addSec);
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}
		}
//		U.log(latLng);
		
		if(latLng != null){
			latLng = U.getSectionValue(latLng, "(", ", \"");
			U.log(latLng);
			String latLong [] = latLng.split(",");
			lat = latLong[0];
			lng = latLong[1];
		}
		U.log("Lat : "+lat+"  Lng : "+lng);
		if(add[0] == ALLOW_BLANK && add[3] ==ALLOW_BLANK){
			if(lat != ALLOW_BLANK && lng != ALLOW_BLANK){
				String latLong [] = {lat,lng};
				add = U.getAddressGoogleApi(latLong);
				geo = "True";
			}
		}
		U.log("Add ::"+add[0]+"=="+add[1]+"=="+add[2]+"=="+add[3]);

		ArrayList<String> COM_TYPE = new ArrayList<String>();
		COM_TYPE = Util.matchAll(htm,
				"<td>.*?</td>\\s+<td>(.*?)</td>\\s+<td>.*?</td>", 1);
		String comType = ALLOW_BLANK;

		for (String com : COM_TYPE) {
			String addc = com + " Story ";
			U.log(addc);
			comType = comType + addc;
			
		}
		
		comType = U.getdCommType(comType+html);
		U.log("comType::"+comType);

		if(ad!=ALLOW_BLANK)
			comType=ad+", "+comType;
		

//		commName = commName.toLowerCase().replaceAll(names.toLowerCase(), "");	
		html=html.replace("Filled Patio Door", "");
		
		data.addCommunity(commName, comUrl, U.getCommunityType(htm));
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(lat.trim(), lng.trim(),geo);
		data.addPropertyType(U.getPropType(html.replace("Patio Door", "")), comType);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(ALLOW_BLANK);
	
	}
	j++;
	}
}