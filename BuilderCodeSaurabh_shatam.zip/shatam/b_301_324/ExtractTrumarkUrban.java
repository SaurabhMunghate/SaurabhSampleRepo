/*
 * @ author Aditya.
 */
package com.shatam.b_301_324;

import java.io.IOException;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTrumarkUrban extends AbstractScrapper {

	private static String builderName = "Trumark Companies - Trumark Urban";
	private static String builderUrl = "http://trumarkurban.com/";
	static int j = 0 ;
	CommunityLogger LOGGER;
	ExtractTrumarkUrban() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractTrumarkUrban();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Trumark Companies - Trumark Urban.csv",
				a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String baseUrl = "http://trumarkurban.com/portfolio/";
		String baseHtml =  U.getHTML(baseUrl);
//		U.getHTML(path)
		String[] comUrl = U.getValues(baseHtml, "<div class=\"tile tile-ro tile", "<img src=\"");
		U.log(comUrl.length);
		for (String urlInfo : comUrl) {
			if(urlInfo.contains("past\">"))continue;
			addDetails(urlInfo);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String urlInfo) throws Exception {
//		if(j==6)
//		if(!urlInfo.contains("http://trumarkurban.com/portfolio/the-pacific/"))return;
		{
			
		String comUrl = U.getSectionValue(urlInfo, "<a href=\"", "\"");
		U.log(comUrl);
		if (data.communityUrlExists(comUrl)){
        	LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
        	return;
        }
		LOGGER.AddCommunityUrl(comUrl);
		
		String comName = U.getSectionValue(urlInfo, "tile-text\">", "</div>");
		String comHtml =  U.getHTML(comUrl);
		String streetSec = U.getSectionValue(comHtml, "<p><em>", "</em><br />");
		String add[] = { ALLOW_BLANK, ALLOW_BLANK };
		if (streetSec != null) {
			add = streetSec.split(",");
		} else {
			streetSec = U.getSectionValue(comHtml, "Properties", "br />");
			U.log("-----" + streetSec);
			if (streetSec != null) {
				streetSec = streetSec
						.replaceAll(
								"<i><span style=\"font-weight: normal \\!msorm;\">",
								"");
				streetSec = U.getSectionValue(streetSec, "<p>", "<");

				U.log(streetSec + "---");

				add = streetSec.split(",");
			}
		}
		U.log(U.getCache(comUrl));
		
		//----------------------- Pacific Data -------------------------
		String pacificInfo = ALLOW_BLANK;
		
		if(urlInfo.contains("/portfolio/the-pacific/") && comHtml.contains("thepacificheights.com</a></p>")) {
			
			String pacificHtml = U.getHTML("http://thepacificheights.com");
			if(pacificHtml != null) {
				
				String urlsSec = U.getSectionValue(pacificHtml, "<nav id=\"menu-overlay\">", "</nav>");
				U.log("urlsSec: " + urlsSec);
				
				String[] links = U.getValues(urlsSec, "<a href=\"", "\"");
				U.log("Total links: " + links.length);
				
				for(String link:links) {
					
					if(link.contains("#")) continue;
					U.log("link: "+link);
					
					String pacificData = U.getHTML(link);
					pacificInfo += pacificData;
					
				}
 			}
			
		} 
		
		
		String street = add[0];
		String city = add[1];
		String state = "CA";
		String zip = ALLOW_BLANK;
		String lat = ALLOW_BLANK;
		String lng = ALLOW_BLANK;
		
		
		String pstatus = U.getPropStatus(comHtml+pacificInfo);
		pstatus = pstatus.replace("Sold-out", "Sold Out");
		
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		
		//----Square feet------------------
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;
		String sqftsec=U.getSectionValue(comHtml, "<h3>Square feet:</h3>", "</p>");
		sqftsec = sqftsec.replace("Approx. 157,170 residential", "").replace("Approx. 171,517 residential; 5,820 commercial,", "");
		U.log("===================="+sqftsec);
		comHtml = comHtml.replace("1,000 to 2,500 square feet feature professional", "")
				.replace("Approx. 157,170 residential", "").replace("Approx. 171,517 residential; 5,820 commercial,", "");
				
		String[] sqFt = U.getSqareFeet(comHtml+sqftsec+pacificInfo, "\\d{3},\\d{3} residential|\\d{1},\\d{3} commercial|Approx. \\d{2},\\d{3} residential|\\d{3} commercial|approximately \\d,\\d{3} to \\d,\\d{3} square feet|Approx. \\d+,\\d+ residential", 0);
		
		minsqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxsqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("SQFT: "+minsqft+" -  "+ maxsqft);
		
		String noteVar=U.getnote(comHtml);
		String geo="TRUE";
		if(street!=ALLOW_BLANK){
			String address[]={street,city,state,zip};
			String latlng[]=U.getlatlongGoogleApi(address);
			if(latlng == null) latlng = U.getlatlongHereApi(address);
			lat=latlng[0];
			lng=latlng[1];
			String adds[]=U.getAddressGoogleApi(latlng);
			if(adds == null) adds = U.getAddressHereApi(latlng);
			zip=adds[3];
		}
		if(comUrl.contains("http://trumarkurban.com/portfolio/923-folsom")) {
			street=add[0]="923 Folsom St";
			city="San Francisco";
			zip="94107";
			String address[]={street,city,state,zip};
			String latlag[]= {ALLOW_BLANK,ALLOW_BLANK};
			latlag=U.getlatlongGoogleApi(address);
			lat=latlag[0];
			lng=latlag[1];
			geo="TRUE";
		}
		
		//San Francisco, CA 
	if(comUrl.contains("http://trumarkurban.com/portfolio/pine-street")) {
		street=add[0]="1545 Pine St";
		city="San Francisco";
		zip="94109";
		String address[]={street,city,state,zip};
		String latlag[]= {ALLOW_BLANK,ALLOW_BLANK};
		latlag=U.getlatlongGoogleApi(address);
		lat=latlag[0];
		lng=latlag[1];
		geo="TRUE";
	}
	if(comUrl.contains("http://trumarkurban.com/portfolio/1554-market-street")) {
		street=add[0]="1554 Market St";
		city="San Francisco";
		zip="94102";
		String address[]={street,city,state,zip};
		String latlag[]= {ALLOW_BLANK,ALLOW_BLANK};
		latlag=U.getlatlongGoogleApi(address);
		lat=latlag[0];
		lng=latlag[1];
		geo="TRUE";
	}
	//
	//San Francisco, CA 94102
		if(add[0]==ALLOW_BLANK)
		{
			String aaaa=U.getHardcodedAddress1("Hardcode_TrumarkCompanies-TrumarkUrban", comUrl);
		    U.log("------->"+aaaa);
		    if(aaaa!=null){
		    	aaaa=aaaa.replace(", Suite", " Suite");
		    String[] aaa=aaaa.split(",");
		    U.log(aaa.length);
		    street=aaa[0];
		    city=aaa[1];
		    state=aaa[2];
		    String address[]={street,city,zip};
		    String[] latl=U.getlatlongGoogleApi(address);
		    if(latl == null) latl = U.getlatlongHereApi(address);
		    lat=latl[0];
		    lng=latl[1];
		    
		    noteVar=aaa[aaa.length-1];
		    String[] latlng={lat,lng};
		    String[] aa=U.getAddressGoogleApi(latlng);
		    if(aa == null) add = U.getAddressHereApi(latlng);
		    zip=aa[3];
		    street=aa[0];
		    geo="true";
		    }
		}
		
		//U.log(comHtml);
		
		comHtml = comHtml.replace("luxury and modern city", "luxury home and modern city");
		comHtml=comHtml.replace("25-story ", "25 Stories").replace("4-5 floors"," 4 story 5 story ").replace(" 4 &amp; 9 floors", " 4 story and 9 story ");
		city=city.replace("Downtown","");
	
		comHtml = comHtml.replaceAll(">Flashy Condos|Heights condo|-condo|Preps 5 Condo|-5-condo-projects", "");
		String propType = U.getPropType(comHtml+pacificInfo);
		
//		U.log("MMMMMMMMMMM "+Util.matchAll(pacificInfo, "[\\s\\w\\W]{50}row[\\s\\w\\W]{50}",0));
//		U.log("MMMMMMMMMMM "+Util.matchAll(pacificInfo, "[\\s\\w\\W]{50}garden[\\s\\w\\W]{50}",0));
		
		if(propType.contains("Townhome") && propType.contains("Townhouse"))
			propType = propType.replaceAll("Townhouse,|,Townhouse", "");
		
		//dType
		
		comHtml = comHtml.replace("two-story grand penthouses", "");
		String dtype=U.getdCommType(comHtml+pacificInfo);
//		if(comUrl.contains("http://trumarkurban.com/portfolio/the-pacific"))dtype+=", 2 Story";
		//if(comUrl.contains("http://trumarkurban.com/portfolio/knox"))minsqft="575";
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		
		U.log(comName);
		data.addCommunity(comName.toLowerCase(), comUrl, U.getCommType(comHtml));
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addAddress(street, city, state, zip);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyStatus(pstatus);
		data.addPropertyType(propType, dtype);
		data.addNotes(noteVar);

		}j++;
	}

	
}