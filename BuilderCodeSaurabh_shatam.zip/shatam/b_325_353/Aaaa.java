package com.shatam.b_325_353;
//import java.io.IOException;
//import java.io.Reader;
import java.util.Arrays;

//import org.json.JSONObject;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class Aaaa extends AbstractScrapper {
	CommunityLogger LOGGER;
	public Aaaa() throws Exception {
		super("Robert Thomas Homes", "https://www.robertthomashomes.com/beautiful-communities/");
		LOGGER = new CommunityLogger("S3 Robert Thomas Homes");
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new Aaaa();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"S3RobertThomasHomes.csv", a.data().printAll());
	}
		
		@Override
		protected void innerProcess() throws Exception {
			// TODO Auto-generated method stub
			String regHtml=U.getHTML("https://www.robertthomashomes.com/");
//			String[] comSecs=U.getValues(regHtml, "<div class=\"community-info\">", "details</a>");
//			String commSec[]=U.getValues(regHtml, "<li id=\"menu-item-", "</a></li>");
			String subMenuComSec = U.getSectionValue(regHtml, "<ul class=\"sub-menu\">", "</ul>");
			String commSec[]=U.getValues(subMenuComSec, "<li id=\"menu-item-", "</li>");
//			String login = U.getHTML("https://www.robertthomashomes.com/beautiful-communities");
		     
			for(String comSec:commSec) { 
//				U.log(comSec); 
			String comUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
			comUrl=""+comUrl;
			U.log(comUrl);
			String commName=U.getSectionValue(comUrl, "communities/", "/");
			U.log(commName);
			
			addDetails(comUrl,comSec,commName);
//			break;
			}
			LOGGER.DisposeLogger();
		}
		
		private void addDetails(String comUrl, String comSec, String comName) throws Exception {
			// TODO Auto-generated method stub
			
			//======Single run=====
			if(!comUrl.contains("huntersbrook"))return;
			
			U.log("communityURL=====> "+comUrl);
			String comHtml = U.getHTML(comUrl);
//			U.log(comHtml);
			
			U.log("comName==============================================> "+comName);
			LOGGER.AddCommunityUrl(comUrl);
			
			
			comUrl = comUrl+"#driving-directions";
			
			
			String note=ALLOW_BLANK;
			note= U.getnote(comHtml);
			
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
			String geo="False";
			
			
			latLong[0]=U.getSectionValue(comHtml, "\"map_start_lat\":\"", "\"");
			latLong[1]=U.getSectionValue(comHtml, "\"map_start_lng\":\"", "\"");
			U.log("Latitude :"+latLong[0]+", Longitude :" +latLong[1]);
			
//			String aa=U.getSectionValue(comHtml, "</h1></div><div class=\"community-address\">", "</div></div><div style");
//			U.log("aa>>>>>>>>"+aa);
//			add=U.getAddress(aa);
			
			if(latLong != null){
			  add = U.getGoogleAddressWithKey(latLong);
			  geo="True";
			}
			
			
			U.log("Address::==================================="+Arrays.toString(add));
			U.log("Note>:===================================="+note);
			
			
			//------Url for Available FloorplansShowcase, Model HomesQuick, Move-in Homes ------------
			String UrlDataSS="";
			comUrl = comUrl.replace("#driving-directions", "");
			String urldata=U.getHTML(comUrl);
			U.log(comUrl);
			
			String urlData=U.getSectionValue(urldata, "<span>About</span></a>", "Quick Move-in Homes</span></a></div></nav></di");
//			U.log(urlData);
			U.log("lenght"+urlData.length());
			String[] urlDataa=U.getValues(urlData, "<a href=\"", "\"");
			String quickhomeHtml="";
			String quickUrl = "";
			String UrlData1 = "";
			for(String quick : urlDataa)
			{
				U.log("URlforData:===="+quick);
//				quick = U.getHTML(quick);
//				quickUrl=U.getSectionValue(quick, "class=\"theme-button-wrap textcenter wpex-clr\"", "View Details");
				
				String sau2 = U.getHTML(quick);
				if(quick.contains("floorplans/")) {
					String sau3=U.getSectionValue(sau2, "id=\"homecollectionnav\">", "id=\"homecollectionaccordian\">");
					String[] sau1=U.getValues(sau3, "<a href=\"", "\"");
//					U.log("URL================"+Arrays.toString(sau1));
					for(String newdata1 : sau1)
					{
						U.log(newdata1);
						if(newdata1.contains("https://www.robertthomashomes.com/floorplan")) {
							UrlData1+=U.getHTML(newdata1);
						}
					}
				}
				
				
//				quickUrl+=U.getHTML(quickUrl);
				UrlDataSS+=U.getHTML(quick);
//				U.log("URlforData1:"+quickUrl);
//				quickhomeHtml=U.getHTML(urlData);
				
			}
			// ----------------- Community Sqft-----------------------
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet((comHtml+quickhomeHtml+UrlDataSS+UrlData1).replace("Sq. Ft. 1757</div>|Sq. Ft. 1506</div>||[ ]*(sqft|sq ft)", ""),"\\d{4} Sq. Ft.|\\d{4}</div><div class=\"featuretext\">Sq Feet|\\d,\\d{3} Sq.Ft.|\\d,\\d{3} Sq. Ft|\\d,\\d{3} to \\d,\\d{3} square feet|Sq. Ft. \\d{4}", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
			
			// ----------------- Community Price-----------------------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String price[] = U.getPrices((comHtml+quickhomeHtml+UrlDataSS+UrlData1), ">\\$\\d{3},\\d{3}<|\">\\$\\d{3},\\d{3}</h3>|Starting at \\$\\d{3},\\d{3}", 0);
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
			
		
			//====================================Property Status ======================================
			String propType = ALLOW_BLANK;
			String propStatus = ALLOW_BLANK;
			String drvPropType = ALLOW_BLANK;
			String commType = ALLOW_BLANK;

			
			//============================================ Property Type =========================================================================
			
			propType=U.getPropType(comHtml+quickhomeHtml+UrlDataSS+quickUrl+UrlData1);
			U.log("PropertyType=>:::"+propType);
		
			//=========================================== Community Type ==========================================================================
			
			commType = U.getCommType(comHtml+quickhomeHtml+UrlDataSS);
			U.log("CommunityType=>:::"+commType);
			
			//============================================ dProp Type =========================================================================
			
			drvPropType=U.getdCommType(comHtml+quickhomeHtml+UrlDataSS);
			U.log("DERIVED_PROPERTY_TYPE=>:::"+drvPropType);
			
			//====================================Property Status ======================================
//			String login = U.getHTML("https://www.robertthomashomes.com/beautiful-communities");
//			propStatus=U.getSectionValue(login, "<div class=\"tilebody\">", "<div class=\"wpb_raw_code wpb_content_element wpb_raw_html\" >");
//			if(propStatus.contains(comName)) {
//				propStatus=U.getSectionValue(propStatus, "<p class=\"tilecontent-text\"><strong>", "</strong></p>");
////				System.out.println(propStatus);
//			}else {
//				System.out.println("");
//			}
						
			U.log("PStatus=>:::"+propStatus);
			
			//===========================================================================================
		
//		// ----------------- Community Data-----------------------
		data.addCommunity(comName.toLowerCase(), comUrl, commType);
		data.addLatitudeLongitude(latLong[0], latLong[1], geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, drvPropType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
	}
}
