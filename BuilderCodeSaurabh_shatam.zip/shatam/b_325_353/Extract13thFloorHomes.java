package com.shatam.b_325_353;

import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class Extract13thFloorHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	HashMap<String, String>hm=new HashMap<>();
	public Extract13thFloorHomes() throws Exception {
		super("13th Floor Homes", "https://www.13thfloorhomes.com/");
		LOGGER = new CommunityLogger("13th Floor Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new Extract13thFloorHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"13th Floor Homes.csv", a.data().printAll());

	}
	@Override
	protected void innerProcess() throws Exception {
		String regHtml=U.getHTML("https://www.13thfloorhomes.com/our-communities");
		String addHtml=U.getHTML("https://www.13thfloorhomes.com/contact");
		String[] latlngUrl = {};
		String addSec=U.getSectionValue(addHtml, "addresses: [", "],");
		String[] arr = U.getValues(addSec, "{", "}");
		for (String latlngSec : arr) {
			latlngSec = StringEscapeUtils.unescapeJava(latlngSec);
//			 U.log(latlngSec);
			 latlngUrl = latlngSec.split("\",\"");
//			 U.log(Arrays.toString(latlngUrl));
//			 U.log(latlngUrl[1]);
			 latlngUrl[1]=latlngUrl[1].replace("infobox_content\":\"", "").trim();
//			 U.log(latlngUrl[1]);
			 String key=latlngUrl[1];;
//			 U.log(key.length());
			 String val=latlngSec;
			 hm.put(key, val);
		}

		String[] comSecs=U.getValues(regHtml, "<i class=\"fusion-li-icon fa-map-marker-alt fas\" style=\"color:#5a9bc1;\"", "<span class=\"fusion-column-inner-bg-image\" style=\"background-color:#ffffff;");
		U.log(comSecs.length);
		for(String comSec:comSecs) {
//			U.log(comSec);
			String comurl=U.getSectionValue(comSec, "<a href=\"", "\"");
			if(!comurl.contains("13thfloorhomes")) {
				comurl="https://www.13thfloorhomes.com"+comurl;
			}
			String commName=U.getSectionValue(comSec, "<span class=\"fusion-button-text\">Learn More About", "<");
			commName=commName.replace("CENTRAL", "Central").replace("AVALON TRAILS", "Avalon Trails").replace("ARBOR PARC", "Arbor Parc").replace("HIDDEN TRAILS", "Hidden Trails");
			U.log(comurl+" name: "+commName);
			addDetails(comurl,commName,comSec);
//			break;
		}
		LOGGER.DisposeLogger();

	}

	private void addDetails(String comUrl, String comName, String comSec) throws Exception {
		// TODO Execute for single community
		//if(!comUrl.contains("https://www.13thfloorhomes.com/hidden-trails/"))return;
//		U.log(">>>>>>>\n"+comSec);
		
		// ----------------- Community Url-----------------------
		U.log("communityURL========================================================> "+comUrl);
		String comHtml = U.getHTML(comUrl);
		
		
		// ----------------- Community Name-----------------------
		U.log("comName========================================================> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				comName=comName.trim();
				String cName="";
//				U.log(comName);U.log(comName.length());
				String commname=comName.toLowerCase();
				String [] arr=commname.split(" ");
				for(String s : arr) {
//					U.log(">>>>>>>"+s);
					
					cName=cName+s.charAt(0);
//					U.log(">>>>"+cName);
					
				}
				
				

//				else {
				String communitie="";
//				U.log(hm.get(comName));
				if(hm.get(comName) != null) {
					U.log("=====================================================================");
					communitie=hm.get(comName);
					U.log(communitie);
					String addSec=U.getSectionValue(U.getHTML("https://www.13thfloorhomes.com/contact"),cName+".png 350w\"" , "</div></div></div><div");
					U.log("addSec>>>>>>>"+addSec);
					if(addSec!=null) {
						
					String addsec=U.getSectionValue(addSec, "center;\">", "</p>").replace("<br />", ", ");
					add=U.getAddress(addsec);
						
						
					}
				
					
					else if(communitie.contains(comName)) {
						add=U.getAddress(U.getSectionValue(communitie, "\"address\":\"", "\""));
					}
						latLong[0]=U.getSectionValue(communitie, "latitude\":\"", "\"");
						latLong[1]=U.getSectionValue(communitie, "longitude\":\"", "\"");
//					}
				
				}
				U.log("Address ::"+Arrays.toString(add));
				U.log("Latlong ::"+Arrays.toString(latLong));
//				U.log(comSec);
				
				if(add[0]==ALLOW_BLANK&& latLong[0]==ALLOW_BLANK) {
					String cityState=U.getSectionValue(comSec, "<p style=\"text-align: left;\">", "</p></div>");
					String[] citStat= {ALLOW_BLANK,ALLOW_BLANK};
					citStat=cityState.split(",");
					add[1]=citStat[0];
					add[2]=citStat[1];
					latLong=U.getGoogleLatLngWithKey(add);
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
					note="Address & LatLong Taken From City and State";
					U.log("===Address ::"+Arrays.toString(add));
					U.log("Latlong ::"+Arrays.toString(latLong));
					
				}
//				
//				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
				String homeData="";
				String homeSec="";
				String[] homeUrls= {};
				if(!comUrl.contains("https://www.13thfloorhomes.com/arbor-parc/")) {
					U.log(">>>>>>>>>>>>>>>>>>>>");
					if(comUrl.contains("manor-parc")) 
					{
						U.log("<<<<<<<");
						homeSec=U.getSectionValue(comHtml, "<span class=\"menu-text\">Floor Plans</span></a>", "</span></a></li></ul></li></ul></li>");//</span></a></li></ul></li>
//						homeSec=homeSec.replaceAll("<a  href=\"https://www.13thfloorhomes.com/manor-parc/meadow-collection/\"|<a  href=\"https://www.13thfloorhomes.com/manor-parc/village-collection/\"", "");
//						U.log("==== "+homeSec);
					}else {
						homeSec=U.getSectionValue(comHtml, "<span class=\"menu-text\">Floor Plans</span></a>", "</span></a></li></ul></li>");
//						U.log("homeSec     >>    "+homeSec);
					}
					if(homeSec!=null)
					homeUrls=U.getValues(homeSec, "<a  href=\"", "\"");
					int c=0;
					for(String homeUrl:homeUrls) {
						c++;
	//					homeUrl="https://www.forsail.com"+homeUrl;
						U.log(c+"== "+homeUrl);
						homeData+=U.getHTML(homeUrl);
					}
				}
				
				//------------------Floorplan Data-----------------------
				String floorplanData=null;
				String[] fpData=U.getValues(comHtml, "style=\"font-size:18px;line-height:23px", "</span></a></span></div>"); 
				if(fpData.length>0) {
					for(String fpdata: fpData)
					{
						String url=U.getSectionValue(fpdata, "<a href=\"", "\"");
						U.log(">>>>>>>"+url);
						String fpHtml=U.getHTML(url);
						floorplanData+=fpHtml;
					}
			
				}
//				U.log(">>>>>>"+floorplanData.length());
					
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml+homeData+floorplanData,	"<p>\\d,\\d+ Square Feet</p>|\\d,\\d{3} Square Feet|up to \\d,\\d{3} square feet|\\d,\\d{3} A/C Sq. Ft.", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
//				<<<<<<<
//				U.log("mmmmmm"+Util.matchAll(floorplanData, "[\\w\\s\\W]{100}558[\\w\\s\\W]{100}", 0));
//				U.log("mmmmmm"+Util.matchAll(homeData, "[\\w\\s\\W]{100}1,558[\\w\\s\\W]{100}", 0));
				
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				
				
				comHtml=comHtml.replace("low as the mid $300’s.", "low as the mid $300,000").replace("Starting in the low $300’s", "Starting in the low $300,000");
//				homeData=homeData.replaceAll("STARTING FROM \\$348,400</p>", "").replace(">9STARTING FROM $395,990</p>", "");
				
				String price[] = U.getPrices(floorplanData+comHtml+homeData, "low \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|Starting From \\$\\d{3},\\d{3}", 0);  //|Starting From \\$\\d{3},\\d{3}
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
//				U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}381,990[\\w\\s\\W]{100}", 0));
//				U.log("mmmmmm"+Util.matchAll(homeData, "[\\w\\s\\W]{100}381,990[\\w\\s\\W]{100}", 0));

				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				propType=U.getPropType((comHtml+homeData+comSec).replaceAll("Single Family Homes in Palm Beach|Mediterranean Concrete Tile Roof|Mediterranean S-Style Concrete Tile Roof", ""));
				
//				U.log("mmmmmm"+Util.matchAll(comHtml+homeData+comSec, "[\\w\\s\\W]{30}Townhomes[\\w\\s\\W]{30}", 0));
	
				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
				comHtml=comHtml.replace("ACTIVE ADULT COMMUNITIES", "");
				commType = U.getCommType(comHtml.replace("lakeside neighborhood", "lakeside living neighborhood").replace("Offering 6 spacious floorplan options your perfect home awaits in this gated", ""));
				
//				U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}lakeside[\\w\\s\\W]{30}", 0));

				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType(comHtml+homeData);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
		
				comHtml=comHtml.replaceAll("1 Quick Move-In Costa Remaining|quick_movein", "");
				propStatus=U.getPropStatus(comHtml);
//				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}move[\\w\\s\\W]{30}", 0));
				U.log("PStatus========>:::"+propStatus);
				
				if(comUrl.contains("https://www.13thfloorhomes.com/avalon-trails/")) {
					minPrice="$343,990";
					maxPrice="$376,990";
				}
				if(comUrl.contains("manor-parc"))maxSqft="2816";   //2816 is wrong 
				propStatus = propStatus.replace("Sold-out", "Sold Out");
				
//				if(comUrl.contains("https://www.13thfloorhomes.com/hidden-trails/"))add[0]="4802 NW 48th Terrace";
//				if(comUrl.contains("https://www.13thfloorhomes.com/manor-parc"))add[0]="4802 NW 48th Terrace";
				if(!comUrl.contains("communities/central-parc"))
				note="Address & LatLong Taken From Builder Contact-Us Page";
//				geo="TRUE";
				
				
				U.log(">>>>>>>>>>>>>"+maxPrice);
				if(comUrl.contains("https://www.13thfloorhomes.com/hidden-trails/"))commType=ALLOW_BLANK;
				// ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);	
		
	}


}
