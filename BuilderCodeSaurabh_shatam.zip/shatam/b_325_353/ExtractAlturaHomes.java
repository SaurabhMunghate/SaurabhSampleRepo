package com.shatam.b_325_353;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author MJS
 * @date 01/04/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractAlturaHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://www.alturahomes.com";
	WebDriver driver;

	public ExtractAlturaHomes() throws Exception {
		super("Altura Homes", builderUrl);
		LOGGER = new CommunityLogger("Altura Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractAlturaHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Altura Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.alturahomes.com/communities/");
		String[] mainSec = U.getValues(html, "<li class=\"hproduct marketPage", "</li>");
		
		for(String main : mainSec) {
			
			String comUrl = U.getSectionValue(main, "<a href=\"", "\"");
			U.log(comUrl);
//			try {
				getDetail(builderUrl+comUrl, main);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//	if(!comUrl.contains("https://www.alturahomes.com/communities/meadows-at-morgan-creek/")) return;
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			
			if (comUrl.contains("Hunter-Lakes")) {
				LOGGER.AddCommunityUrl("Return to region======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			
			// ------------------ UNITS COUNT ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, comUrl, driver);
			U.log("Total Units : "+units);
			
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, "communityUrlInfo\">","<");
			if(communityName==null)
				communityName = U.getSectionValue(com,"data-community-name=\"", "\"");
			
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("80’s", "80's").replace("&#8217;", "'");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String addsec = U.getSectionValue(html, "<div class=\"communityAddress \">", "</div>").replace("By Appointment", "");
			add[0] = U.getSectionValue(addsec, "<span class=\"addressStreet\">", "<");
			add[1] = U.getSectionValue(addsec, "<span class=\"addressCity\">", "<");
			add[2] = U.getSectionValue(addsec, "<span class=\"addressState\">", "<");
			add[3] = U.getSectionValue(addsec, "<span class=\"addressZipCode\">", "<");
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
			latLng[0] = U.getSectionValue(html, "Latitude:</span>", "<");
			latLng[1] = U.getSectionValue(html, "Longitude:</span>", "<");
			
				
					
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}
			if(add[0]!=null)
				add[0]=add[0].replace("by Appointment", "");

			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//====== Available Plans ================================
			String floorPart = U.getSectionValue(html, "xCommunityHomesWrappercustom_plan_homes\">", "</ul>");
			if(floorPart==null)
				floorPart = "";
			String[] floorSec = U.getValues(floorPart, "<li class=\"hproduct homeDataInformation", "</li>");
			String floorData = ALLOW_BLANK;
			for(String floor : floorSec) {
				
				floor = U.getSectionValue(floor, "<a href=\"", "\"");

				floorData += U.getSectionValue(U.getHTML(builderUrl+floor), "<div class=\"homeDetailBox", " <h3 class=\"bdxTitle \">Get Driving Directions</h3>");
//				U.log(floorData);

			}
			//====== Available Homes ================================
			String homePart = U.getSectionValue(html, "xCommunityHomesWrappercustom_available_now_homes\">", "</ul>");
			if(homePart==null)
				homePart = "";
			String[] homeSec = U.getValues(homePart, "<li class=\"hproduct homeDataInformation", "</li>");
			String homeData = ALLOW_BLANK;
			for(String home : homeSec) {
				
				home = U.getSectionValue(home, "<a href=\"", "\"");
//				U.log(home);
				homeData += U.getSectionValue(U.getHTML(builderUrl+home), "<div id=\"bodyContainer\">", "<div class=\"mapAndDirections\">");
			}
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("0s", "0,000");
			String prices[] = U.getPrices(com + html + floorData + homeData, "<span class=\"dealPrice\">\\$\\d{3},\\d{3}</span>|Starting at \\$\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html + floorData + homeData,
					"\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft|\\d,\\d{3} Sq\\. Ft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replace("attractions, proximity to lakes", "attractions, proximity to Lakefront")
					.replaceAll("Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================

			html = html.replace("crafted homes feature Mediterranean", "crafted homes feature Mediterranean-Style Homes")
					.replace("features Mediterranean", "features Mediterranean-Style Homes")
					.replace("Mediterranean and Craftsman styles", "Mediterranean-Style Homes and Craftsman styles")
					.replace("Mediterranean, Tuscan and traditionally styled exterior designs", "Mediterranean-Style Homes, Tuscan and traditionally styled exterior designs");
			String proptype = U.getPropType((html + com + floorData + homeData).replaceAll("-townhomes/\"|Cedars Townhomes</a>", ""));
//			U.log(Util.matchAll(html + com + floorData, "[\\s\\w\\W]{30}lakes[\\s\\w\\W]{30}", 0));

			// ==================================================D-Property
			// Type======================================================
			String dtype = U.getdCommType((html + com + floorData + homeData)
					.replaceAll("\\d bdrm|5 bedroom|\\d+ bedroom|\\d bedroom|Anchor|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
					+ communityName);
//			U.log(Util.matchAll((html + com + floorData + homeData).replaceAll("5 bedroom|\\d+ bedroom|\\d bedroom|Anchor|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", ""), "[\\s\\w\\W]{30}story 5[\\s\\w\\W]{30}", 0));
			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("Coming soon, neuhouse", "");
			com=com.replace("Quick Move-In Homes", "");
			String pstatus = U.getPropStatus((html + com).replace("Sold Out! Join Interest List for Back-up Wait-list", ""));
			
//			if(html.contains("<h3 class=\"\">Homes Available Now</h3>")) {
//				
//				if(pstatus==ALLOW_BLANK)
//					pstatus = "Quick Move-In Homes";
//				else if(!pstatus.contains("Quick Move-In Homes")) 
//					pstatus += ", Quick Move-In Homes";
//			}
			
			U.log("pstatus: "+pstatus);
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			boolean date = false;
			for (String val : homeSec) {
				//U.log("-----------------"+val);
				if (Util.match(val.replaceAll("Available \\d+/\\d+", ""), "Available") != null)
					date = true;
			}
//			if(date == true) 
//				if(pstatus==ALLOW_BLANK)
//					pstatus = "Quick Move-In Homes";
//				else if(!pstatus.contains("Quick Move-In Homes")) 
//					pstatus += ", Quick Move-In Homes";
			

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon").replace("Phase 3 Coming, Coming Soon", "Phase 3 Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
//			if(comUrl.contains("https://www.alturahomes.com/communities/cottonwood/")||comUrl.contains("https://www.alturahomes.com/communities/elizabeth-estates/")) pstatus+=", Quick Move-In Homes";
			//=========================================================================================================================
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].replace(",", "").trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);

		}
		j++;

	}
	
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("<h3>Community Lot Map</h3>")) {
			
			String frameSec = U.getSectionValue(comHtml, "<h3>Community Lot Map</h3>", "target=\"_blank\">");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "<a href=\"", "\""); 
				U.log("frameUrl: "+frameUrl);
				
				mapData = U.getHtml(frameUrl, driver);
				
				if (frameUrl.contains("Summerwood%20Estates")) {
					
					//getting iframeUrl from the map page.
					String iframeUrl = U.getSectionValue(mapData, "https://alturahomes.lotvue.com", "\"");
					iframeUrl = "https://alturahomes.lotvue.com" + iframeUrl;
					U.log("iframeUrl: "+iframeUrl);
					
					String iframeData = U.getHtml(iframeUrl, driver);
					
					if(iframeData.contains("id=\"IL_040_")) {
						
						ArrayList<String> pins = Util.matchAll(iframeData, "id=\"IL_040_", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}
					
				}
				else if(mapData.contains("id=\"IL_040_")) {
					
					ArrayList<String> pins = Util.matchAll(mapData, "id=\"IL_040_", 0);
					U.log("Count Pins: "+pins.size());
					totalUnits = String.valueOf(pins.size());
				}
			}
			

			
		}
		return totalUnits;
	}

}
