package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBerksHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver;
	static int j = 0;

	public ExtractBerksHomes() throws Exception {

		super("Berks Homes", "https://www.berkshomes.com/");
		LOGGER = new CommunityLogger("Berks Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractBerksHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Berks Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();

		String mainHtml = U.getHTML("https://www.berkshomes.com/");
		String findHomeSec = U.getSectionValue(mainHtml, "col-sm-6 col-lg-3 bg-nav-region p-0 text-right region-wrap",
				"On Your Land");
		String regUrls[] = U.getValues(findHomeSec, "href=\"", "\"");

		for (String rUrl : regUrls) {
			String regUrl = "https://www.berkshomes.com" + rUrl;
			U.log(regUrl);
			if (regUrl.contains("https://www.berkshomes.com/on-your-land"))
				continue;
			String regHtml = U.getHTML(regUrl);
			String comSections[] = U.getValues(regHtml,
					"class=\"col-md-6 col-lg-4 mb-3 mb-md-5\"", "VIEW COMMUNITY");
			// U.log(comSections.length);
			for (String comSec : comSections) {
//				try {
					addDetails(comSec);
//				} catch (Exception e) {}
			}

		}
		driver.quit();
		LOGGER.DisposeLogger();

	}

	public void addDetails(String comSec) throws Exception {
    //try
	//	if(j>=8)
		{

			String comUrl = "https://www.berkshomes.com" + U.getSectionValue(comSec, "href=\"", "\"");
			
			//TODO:
			// if(!comUrl.contains("https://www.berkshomes.com/new-homes/pa/york/summerset-meadows-singles/4070/"))return;

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			String comHtml = U.getHTML(comUrl);
			String mapHtml = getHtml(comUrl, driver);

			U.log(comUrl + "=========================" + j);
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(mapHtml, comUrl, driver);
			U.log("Total Units : "+units);
			// ---------------------------------------------------------
			
			
			//U.log(comSec);
			comSec=comSec.replaceAll("- Starting in the Low $400's", "");
			String comName = U.getSectionValue(comSec, "<b>", "</b>");
			comName=comName.replaceAll("Villas$", "");
		
			// ================================address
			// section================================================

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };	
			String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(comSec, "<div class=\"csz cp pb-1\">", "</div>");
			U.log(addSec);
			
			 if(comUrl.contains("/new-homes/pa/carlisle/dickinson-place-singles/7814/")) {
				 addSec = U.getSectionValue(comHtml, "<b>Sales Office:</b>", "cp oi-directions");
				 addSec = addSec.replace("</p><p class=\"m-0\">", ",").replace("</p><a class=\"", "");
				 U.log("addSec: "+addSec);
			 }
			
			
			add = U.getAddress(addSec);
			U.log("ADDRESS: "+Arrays.toString(add));
			
			if(comHtml.contains("<b>Sales Office:</b>") && (addSec==null||add[0]==ALLOW_BLANK)) {
				//addSec= U.getSectionValue(comHtml, "<b>Sales Office:</b>", "</p>");
			    addSec= U.getSectionValue(comHtml, "<b>Sales Office:</b>", "/p><a class=\"cp oi-directions-click\"").replace("</p>", ",");
				U.log("addSec"+addSec);
				addSec=U.getNoHtml(addSec);
				U.log("addSec22"+addSec);
				add=U.getAddress(addSec);
				String latlngSec=U.getSectionValue(comHtml, "https://maps.google.com/maps?q", "target=\"_blank\">");
			
				latlag[0] = U.getSectionValue(latlngSec, "=", ",");
				latlag[1] = U.getSectionValue(latlngSec, ",", "\"");
			}
			
			
			if(latlag[0]==ALLOW_BLANK||latlag[0]==null) {
			latlag[0] = U.getSectionValue(comSec, "data-latitude=\"", "\"");
			latlag[1] = U.getSectionValue(comSec, "data-longitude=\"", "\"");
			}
			
			if(comUrl.contains("/pa/reading/pathfinder-meadows/8464/")) {
				add[1]="Reading";
				add[2]="PA";
				add[3]="19606";
				latlag= U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlag);
				geo = "TRUE";
			}
			if(comUrl.contains("pa/see-individual-lots-for-location-info/scattered-lots/8502/")) {
				add[1]="Cumberland County";
				add[2]="PA";
				latlag= U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlag);
				geo = "TRUE";
			}
			if(comUrl.contains("baldwin-heights-at-winding-hills/8950") ||comUrl.contains("the-estates-at-spring-view/8949")) {
				add[1]="Mechanicsburg";
				add[2]="PA";
				latlag= U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlag);
				geo = "TRUE";
			//	note="Address Taken From City And State";
			}
			if (add[0] == ALLOW_BLANK || add[0] == null) {
				add = U.getAddressGoogleApi(latlag);
				geo = "TRUE";
			}
			U.log(Arrays.toString(add));
			U.log(Arrays.toString(latlag));
			U.log(geo);
			
			// =====================================floorplans==================================================
            String[] Floorpart=U.getValues(comHtml, "class=\"col-md-6 col-lg-4 py-2 py-lg-4\"", "VIEW FLOORPLAN");
            String floorHtml = "";
            for(String floorSec:Floorpart) {
//			String floormainurl = comUrl + "#model-plans";
//			String floormainhtml = U.getHTML(floormainurl);
//			String floorsContent = U.getValues(floorSec, "model-card clearfix match-height-wrap h-100 pr",
//					"view floorplan");
			
//			for (String floorData : floorsContents) {
				// U.log(floorData);
            	String floorUrl =U.getSectionValue(floorSec, "href=\"/", "\"");
            	floorUrl="https://www.berkshomes.com/"+floorUrl;
//				String floorUrl = "https://www.berkshomes.com" + U.getSectionValue(floorSec, "href=\"", "\">");
				 U.log(floorUrl);
				floorHtml += U.getHTML(floorUrl);
//			}
            }
			// ==============================prices===============================================================

			String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
			comSec = comSec.replace("the-low-400s", "the-low-$400,000").replace("0s", "0,000");
			comHtml=comHtml.replace("0's", "0,000");
			//U.log("pp"+Util.matchAll(comHtml + floorHtml, "[\\w\\s\\W]{100}268[\\w\\s\\W]{60}",0));
			prices = U.getPrices((comSec + comHtml + floorHtml).replaceAll("&lt;div class=\"plan-price fs-half\"&gt;\n" + 
					"                        \\$268,990|model-price quasi bold fs-2\">From \\$399,990", ""), "From the Low \\$\\d{3},\\d{3}|the-low-\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);

			U.log(Arrays.toString(prices));
			floorHtml=floorHtml.replaceAll("has more than 2000 sqft, 3 bedrooms|1,000 sq\\s*ft to play", "");
			String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
			sqft = U.getSqareFeet(floorHtml + comHtml, "From \\d,\\d{3} Sq.Ft|\\d{1},\\d{3} Sq. Ft.|From \\d{1},\\d{3} Sq.Ft|\\d{4} sqft|\\d,\\d{3}\\+ sq ft|\\d,\\d{3}\\+ sqft|\\d{4}\\+ sqft|\\d,\\d{3} sq ft|\\d,\\d{3} sqft", 0);

			U.log(Arrays.toString(sqft));
			U.log("mm "+Util.matchAll(floorHtml + comHtml, "[\\w\\s\\W]{30}2000[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll(floorHtml, "[\\w\\s\\W]{30}2000[\\w\\s\\W]{30}",0));
			
			String cType = U.getCommType(comHtml);
			U.log(cType);

			String pType = ALLOW_BLANK;
			comHtml=comHtml.replaceAll("estates-duplexes/9426/\">|Estates Duplexes</a>|glen-duplexes/7701/\">|Glen Duplexes</a>|avenue-duplexes/7907/\">|Avenue Duplexes</a>", "");
			pType = U.getPropType((comHtml + floorHtml).replace("where luxury awaits ", "luxury home awaits ").replaceAll("paradise-village-duplexes/|Paradise Village Duplexes</a>|g-townhomes/9360/\">Morgan's Crossing Townhomes</a>|Village|village|Place Villa|-villas|Oak Avenue Duplexes|oak-avenue-duplexes|Nittany Glen Duplexe|nittany-glen-duplexes|townhomes/9426/\">Stone Mill Estates Townhomes</a>|logan-greene-townhomes/9288/\">Logan Greene Townhomes</a>", ""));
//			 U.log(Util.matchAll(comHtml+ floorHtml, "[\\w\\s\\W]{80}duplex[\\w\\s\\W]{80}",0));
			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;

			dType = U.getdCommType((comHtml + floorHtml).replaceAll("floor|Floor", ""));
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;
			comHtml = comHtml.replaceAll("m-0\">COMING SOON!</p>|text-center\">COMING SOON!</p>|<p>Aldi\\s*\\(Coming Soon!\\) </p><p>|m-0\">Coming Soon!</p>|center\">Coming Soon!</p>|Hours Coming","")
					.replace("COMING SOON!  EARLY FALL 2021", "COMING SOON EARLY FALL 2021").replaceAll(">Coming Soon<|/quick-move-ins/\">|See Quick Move-Ins|and quick move-in homes to your favorites", "");
			pStatus = U.getPropStatus(comHtml.replace("COMING SOON!  EARLY FALL 2021", "COMING SOON EARLY FALL 2021") + comSec);

//            U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}coming[\\s\\w\\W]{30}", 0));
			U.log("status:::::::" + pStatus);

			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/morgantown/oak-grove-starting-in-the-low-400s/6299/")) {
				comName="Oak Grove";
				pStatus="Now Selling";
				pType+=", Luxury Homes";
			}
		
//			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/harrisburg/creekvale/5000/"))sqft[0]="1500";
			if(comUrl.contains("/the-townes-of-orrs-bridge/7191/"))pStatus="Sold Out";
			
			if(comUrl.contains("the-estates-at-spring-view/8949/"))pStatus +=", Now Selling";
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			if(comUrl.contains("/oak-avenue/7892/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/morgantown/oak-grove/6299/"))pStatus="Now Selling";//img
//			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/duncannon/stone-mill-estates-townhomes/9426/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/carlisle/morgans-crossing-townhomes/9360/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/halifax/lenker-estates/9362/"))pStatus="Coming Soon";//img Jan 27
			if (comUrl.contains("https://www.berkshomes.com/new-homes/pa/state-college/nittany-glen/4059/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/dover/the-seasons/7478/"))
				pStatus = "New Phase Coming Soon";// img
			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/abbottstown/paradise-village/5760/"))pStatus = "Phase II Coming Soon";// img Jan 27
			if (comUrl.contains("https://www.berkshomes.com/new-homes/pa/mechanicsburg/baldwin-heights-at-winding-hills/8950/") ||
					comUrl.contains("https://www.berkshomes.com/new-homes/pa/halifax/lenker-estates/9362/")||
					comUrl.contains("https://www.berkshomes.com/new-homes/pa/carlisle/morgans-crossing-townhomes/9360/")||
					comUrl.contains("https://www.berkshomes.com/new-homes/pa/milton/sunland-meadows/9374/"))
//					comUrl.contains("https://www.berkshomes.com/new-homes/pa/bellefonte/logan-greene-singles/9290/")||
//					comUrl.contains("https://www.berkshomes.com/new-homes/pa/bellefonte/logan-greene-townhomes/9288/"))
//				if(pStatus==ALLOW_BLANK)
//				pStatus = "Now Selling";// img
//				else
//					pStatus += ", Now Selling";
			
			if(comHtml.contains("<h2 class=\"model-title\">Quick Move-ins</h2>")) {
				
				if(pStatus.length()<4)pStatus="Quick Move-Ins";
				else pStatus+=", Quick Move-Ins";
				
			}
//			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/duncannon/stone-mill-estates-duplexes/9426/") ||
			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/duncannon/stone-mill-estates/9256/")) {
				if(pStatus==ALLOW_BLANK)
					pStatus = "Now Open";// img
					else
						pStatus += ", Now Open";
			}
//			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/mifflinburg/oak-avenue-duplexes/7907/") ||
//					comUrl.contains("https://www.berkshomes.com/new-homes/pa/mifflinburg/oak-avenue-singles/7892/")) {
//						if(pStatus==ALLOW_BLANK)
//							pStatus = "Grand Opening";// img
//							else
//								pStatus += ", Grand Opening";
//			}
			
//			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/state-college/nittany-glen-singles/4059/")) {
//				pStatus = getImageStatus(pStatus, "New Homesites Available");
//			}
			

			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/harrisburg/eastvale-grove/9699/")||
					comUrl.contains("https://www.berkshomes.com/new-homes/pa/bloomsburg/sunland-preserve/9383/")	) {
				pStatus = getImageStatus(pStatus, "Coming Soon");
			}
			pStatus = pStatus.replace("Quick Move-in, Quick Move-Ins", "Quick Move-Ins");
			
			//Status from images - 27 April 2022
			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/bridgeport/merion-heights-townhomes/10115/")) pStatus = "Coming Soon";
			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/bloomsburg/sunland-preserve-singles/9383/")) pStatus = "Coming Soon";
            
			if(comUrl.contains("https://www.berkshomes.com/new-homes/pa/york/summerset-meadows-singles/4070/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/bridgeport/merion-heights-townhomes/10115/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/halifax/lenker-estates-singles/9362/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/halifax/lenker-estates-singles/9362/")||comUrl.contains("https://www.berkshomes.com/new-homes/pa/abbottstown/paradise-village-duplexes/5760/"))
	          pStatus = "Coming Soon";
			//frm img 
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(comName.replace("- Starting In The Low $400's", "").replace("&#x27;s", " &"), comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(comHtml));

		} //catch(Exception e) {}
		j++;

	}
	
	public static String getUnits(String mapHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(mapHtml.contains("<h2 class=\"model-title\">Community Map</h2>")) {
			
			if(mapHtml.contains("<div class=\"point oi-isp-key")) {
				
				ArrayList<String> red = Util.matchAll(mapHtml, "<div class=\"point oi-isp-key", 0);
				U.log("Count Red: "+red.size());
				totalCount = totalCount + red.size();
			}
			
			if(mapHtml.contains("<div class=\"point pop oi-isp-key")) {
				
				ArrayList<String> green = Util.matchAll(mapHtml, "<div class=\"point pop oi-isp-key", 0);
				U.log("Count Green: "+green.size());
				totalCount = totalCount + green.size();
			}
			
			 
			totalUnits = String.valueOf(totalCount);
		}
		
		return totalUnits;
	}
	
	
	private static String getImageStatus(String pStatus, String imageStatus) {
		if(pStatus==ALLOW_BLANK) pStatus = imageStatus;
		else pStatus += ", "+imageStatus;
		
		return pStatus;
	}
	
	// --------- PLEASE NOTE -------------------
	// The below methods are changed to get the data for the same builder with simple getHTML method and with selenium webdriver both.
	// Data for the maps will be read from filename "CacheMaps". Create folder "CacheMaps" alongside "Cache". 
	
	
	public static String getCachePath(){
		String Regex="CacheMaps";
		String Filename=System.getProperty("user.home");
		//U.log(Filename+"filename");
		if(Filename.contains("/")){
			Regex="/CacheMaps/";
		}
		else 
		{
			Regex="\\CacheMaps\\";
		}
		Filename=Filename.concat(Regex);
		//U.log("filename :::"+Filename);
		if(!Filename.equals(Regex))
		{
			Regex=Regex.toLowerCase();
		}
		return Filename;
	}
	

	public static String getCache(String path) throws MalformedURLException {

		String Dname = null;
		String host = new URL(path).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;

		File folder = new File(getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = getCacheFileName(path);
		fileName = getCachePath() + Dname + "/" + fileName;
		return fileName;
	}
	
	public static String getCacheFileName(String url) {

		String str = url.replaceAll("http://", "");
		str = str.replaceAll("www.", "");
		str = str.replaceAll("[^\\w]", "");
		if (str.length() > 200) {
			str = str.substring(0, 100) + str.substring(170, 190)
					+ str.length() + "-" + str.hashCode();

		}

		try {
			str = URLEncoder.encode(str, "UTF-8");
			// U.log(str);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();

		}
		return str + ".txt";
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = getCacheFileName(url);

		fileName = getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					Thread.sleep(10000);
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(10000);
				//	((JavascriptExecutor) driver).executeScript(
				//			"window.scrollBy(0,400)", ""); 
					Thread.sleep(5000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

}
