package com.shatam.b_325_353;
import java.util.Arrays;

/**
 * @author MJS
 * @date 01/04/2021 
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEsperanzaHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.esperanzahomes.com";

	public ExtractEsperanzaHomes() throws Exception {
		super("Esperanza Homes", builderUrl);
		LOGGER = new CommunityLogger("Esperanza Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractEsperanzaHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Esperanza Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.esperanzahomes.com/new-homes/");
		String[] mainSec = U.getValues(html, "<div class=\"col-lg-6 col-md-6 mb-4", "View Community");
		
		for(String main : mainSec) {
			
			String comUrl = U.getSectionValue(main, "href=\"", "\"");
			getDetail(builderUrl+comUrl, main);
			
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/san-juan/sioux-coves/8659/"))return;
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHtml(comUrl, driver);
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, "<h4 class=\"bold m-0 pb-2 text-white text-uppercase text-center\">","<");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'").replace("ñ", "n").replace("So�ador Coves", "So�ador Coves");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<div class=\"location-contact-card card border-0\">", "Get Driving Directions</a>");
			if(addSec!=null) {
				
				String addVal = U.getSectionValue(addSec, "<span class=\"d-inline-block\">", "<span class=\"location");
				if(addVal!=null)
					addVal = addVal.replaceAll("<span class=\"d-inline-block mb-3\">", ",")
					.replaceAll("NC,", "NC ").replace("3612 Harvard Ave, McAllen, TX 78504 ,McAllen, TX 78504", "3612 Harvard Ave, McAllen, TX 78504")
					.replace("SC,", "SC ")//.replace("<span class=\"d-inline-block mb-3\">McAllen, TX 78504</span>", "")
					.replace("Ave McAllen", "Ave, McAllen")
					.replaceAll("</span>", "");
				
				U.log(addVal);
				add = U.getAddress(addVal);
			}
			if(add[0]!=null)
			add[0]=add[0].replace("3612 Harvard Ave, McAllen, TX 78504", "3612 Harvard Ave");
			U.log("Address---->" + add[0] + " >" + add[1] + " >" + add[2] + " >" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			if(addSec!=null) {
				
				String latSec = U.getSectionValue(addSec, "http://maps.google.com/maps?q=", "\"");
				latLng = latSec.split(",");
			}
			
			
//			U.log(addSec);
			U.log(Arrays.toString(latLng));
			if(latLng.length==0) {
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				
				if (add[3] == null||add[3].length() < 5)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//====== Floor Plans ================================
//			String floorPart = U.getSectionValue(html, "<section class=\"py-5\" id=\"activeplans\">", "</section>");
			String floorPart = U.getSectionValue(html, "<div class=\"container-fluid card-container\">", "</section>");
//			U.log("........."+floorPart);
			if(floorPart==null)
				floorPart = "";
			String[] floorSec = U.getValues(floorPart, "<div class=\"col-lg-4 col-md-6 mb-4\">", "View Home Details");
			U.log("floorSec :"+floorSec.length);
			String floorData = ALLOW_BLANK;
			int i = 0;
			for(String floor : floorSec) {
//				U.log(floor);
				floor = U.getSectionValue(floor, "<a href=\"", "\"");
				String floorHtml=U.getHtml(builderUrl+floor, driver);
				String remSec=U.getSectionValue(floorHtml, "EXPLORE THIS HOME", "button type=\"button\" class=\"next-arrow slick-arrow\"");
				
				if(remSec!=null) {
					floorHtml=floorHtml.replace(remSec, "");
				}
				floorData += U.getSectionValue(floorHtml, "<div class=\"container py-5\">", "</div></div></div>");
//				if(i>5)
//					break;
//				else
//					i++;
					
			}
			//====== Available Homes ================================
			//String homePart = U.getSectionValue(html, "<section id=\"availablehomes", "</section>");
			String homePart = U.getSectionValue(html, "Quick Move-In Homes</h2>", "</section>");
			if(homePart==null)
				homePart = "";
			boolean avail = false;
			
			String[] homeSec = U.getValues(homePart, "<div class=\"col-lg-4 col-md-6 col-sm-12 mb-4\">", "View Home Details");
			String homeData = ALLOW_BLANK;
			int k = 0;
			for(String home : homeSec) {
//				U.log(home);
//			if(home.contains("Available Now!")||home.contains(">Available jun 2021")||home.contains("Available jul 2021"))     //if(home.contains("<strong>Available "))	
					avail = true;
				home = U.getSectionValue(home, "data-link=\"", "\"");
				homeData += U.getSectionValue(U.getHtml(builderUrl+home, driver), "<div class=\"container py-5\">", "</div></div></div>");

			}
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replace("mid 100�s", "mid $100,000").replace("mid 200�s", "mid $200,000").replace("low 300�s", "low $300,000").replace("180’s", "$180,000").replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
				
					.replace("</strong>   &#36;", " $");
			html=html.replace("starting from the low 300’s", "starting from the low 300,000")
					.replace("starting at the mid 200’s", "starting at the mid 200,000");
			
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("starting at the mid 100’s", "starting at the mid $100,000").replaceAll("0’s|0s", "0,000").replace("from the low 300’s", "from the low $300,000").replace("prices from the 180’s", "prices from the $180,000").replace("starting at the mid 200’s", "starting at the mid $200,000");
			String prices[] = U.getPrices(com + html + floorData + homeData, "starting from the low \\d+,\\d+|starting at the mid \\d+,\\d+|starting at the high \\d{3},\\d{3}|starting at the mid \\$\\d+,\\d+|prices from the \\$\\d+,\\d+|from the low \\$\\d{3},\\d{3}|Homes from the \\$\\d{2},\\d{3}|mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|<h3 class=\"price\">\\$\\d{2},\\d{3}</h3>|prices from the \\d{3},\\d{3}|Homes priced from the \\$\\d{3},\\d{3}|<h3 class=\"price text-secondary\">\\$\\d{3},\\d{3}</h3>|<h3 class=\"price\">\\$\\d{3},\\d{3}</h3>|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}", 0);

	
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html + floorData.replace("Total living 1287 sq. ft", "") + homeData,
					"</span>\\d{3} - \\d,\\d{3} SQ.FEET|total living of \\d+ sq ft|\\d{1},\\d{3} - \\d{1},\\d{3} SQ FT|from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft.|Total living \\d+ sq. ft.|<li>\\d+ - \\d,\\d{3} SQ FT\\.</li>|</span>\\d,\\d{3} Sq\\. Ft\\.</li>|\\d,\\d{3} - \\d,\\d{3} SQ\\.FEET",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			U.log("kkkkkkkkkk "+Util.matchAll(com + html + floorData, "[\\s\\w\\W]{100}4,119[\\s\\w\\W]{100}", 0));

			

			// ================================================community
			// type========================================================
			
			String communityType = U.getCommType((html + com).replaceAll("Elongated|Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================
			U.log("kkkkkkkkkk"+Util.matchAll(html + com+ floorData + homeData, "[\\s\\w\\W]60}villa[\\s\\w\\W]{60}", 0));
			String proptype = U.getPropType((html + com + floorData + homeData).replaceAll("Village|village|villas-on-freddy|Villas on Freddy|farmhouse|Farmhouse|FARMHOUSE","").replaceAll("FARMHOUSE_HARDIE|\\d+ <br>Single Family</p>|Villas on Freddy|villas-on-|Villas On Freddy", ""));
//			U.log("kkkkkkkkkk "+Util.matchAll(html + com, "[\\s\\w\\W]{100}patio[\\s\\w\\W]{100}", 0));
//			U.log("kkkkkkkkkk "+Util.matchAll(homeData+floorData, "[\\s\\w\\W]{100}patio[\\s\\w\\W]{100}", 0));
			// ==================================================D-Property
			// Type======================================================
			String dtype = U.getdCommType((html + com + floorData + homeData).replaceAll("Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor|<li>Tri-level (T|t)errace</li>", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
//			U.log(com);
			html = html.replaceAll("coming soon!|>Coming Soon</a>|=coming-soonlocations coming soon|McAllen now open|Quick Delivery|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("coming soon!|>Coming Soon</a>|=coming-soon|locations coming soon|Quick Delivery|Coming soon, neuhouse|Price<br/> Coming Soon", "");
			
//			U.log("kkkkkkkkkk "+Util.matchAll(html + com, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{100}", 0));

			
			String pstatus = U.getPropStatus((html + com).replace("Coming soon to San Juan", "").replaceAll("\\s*Coming Soon",""));
//			U.log("kkkkkkkkkk "+Util.matchAll(html + com, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{100}", 0));

			// ============================================note====================================================================

			//========== Hard Code Data ==================================price from slider img
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/campo-de-suenos/7016/"))
					minPrice = "$100,000";
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/cascada-at-tres-lagos/7147/"))
				minPrice = "$200,000";
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/ensenada-at-tres-lagos/4108/"))
				minPrice = "$300,000";
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mission/rio-plata-at-bentsen-palm/6924/"))
				minPrice = "$160,000";
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/villas-on-freddy/5529/"))
				minPrice = "$200,000";

			if(homeSec!=null && homeSec.length>0 && avail == true)
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-In Homes";
				else if(!pstatus.contains("Quick"))
					pstatus += ", Quick Move-In Homes";
			
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");

			note=U.getnote(html);

			//below pstatus come from image source
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/brownsville/palo-alto-groves/7522/")) pstatus ="phase I sold out, phase II coming soon, Quick Move-In Homes";
			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mission/sendero-at-bentsen-palm/9628/"))pstatus="Coming Summer 2022";//frm image
			U.log(">>>>>>>>"+add[0]+">>>"+add[1]+">>>"+add[2]+">>>"+add[3]);
			//if(comUrl.contains("mcallen/aqualina-at-tres-lagos/8658/"))pstatus="Coming January 2022";

			
			
			//======Site Map======
			int lotCount=0;
			String noOfUnits=ALLOW_BLANK;
			if(html.contains("Interactive Lot Map")|| html.contains("Interactive Site Map")) {
				noOfUnits=getUnits(html);
				/*String frameSec=U.getSectionValue(html, "<iframe allowfullscreen=", "</iframe>");
				String siteMapUrl=U.getSectionValue(frameSec, "src=\"", "\">");
				U.log("siteMapUrl:: "+siteMapUrl);
				String siteMapHtml=U.getHtml(siteMapUrl,driver);
				U.log("SSS"+U.getCache(siteMapUrl));
				String lotData[]=U.getValues(siteMapHtml, "<span class=\"legend_text \"", "</div>");
				for(String lots:lotData) {
					String lot=U.getNoHtml(lots);
			//		U.log("lot= "+lot);
					String lotNum=Util.match(U.getSectionValue(lot, "(", ")"), "\\d+");
				//	U.log("Num "+lotNum);
					lotCount+=Integer.parseInt(lotNum);
				}
				noOfUnits=Integer.toString(lotCount);
				
				
			*/
			}
			
			U.log("no. 0f Units= "+noOfUnits);
			//=========================================================================================================================
			data.addCommunity(communityName.replace("So�ador Coves", "Sonador Coves").replace(",", ""), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());//.replace(",", "")
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
	        data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	        data.addUnitCount(noOfUnits);

		}
		j++;
	}

	private String getUnits(String html) throws Exception {
		String frameSec=U.getSectionValue(html, "<iframe allowfullscreen=", "</iframe>");
		String siteMapUrl=U.getSectionValue(frameSec, "src=\"", "\">");
		U.log("siteMapUrl:: "+siteMapUrl);
		String siteMapHtml=U.getHtml(siteMapUrl,driver);
		U.log("SSS"+U.getCache(siteMapUrl));
		String lotData[]=U.getValues(siteMapHtml, "<span class=\"legend_text \"", "</div>");
		int lotCount=0;
		String noOfUnits=ALLOW_BLANK;
		for(String lots:lotData) {
			String lot=U.getNoHtml(lots);
	//		U.log("lot= "+lot);
			String lotNum=Util.match(U.getSectionValue(lot, "(", ")"), "\\d+");
		//	U.log("Num "+lotNum);
			lotCount+=Integer.parseInt(lotNum);
		}
		noOfUnits=Integer.toString(lotCount);
		
		if(noOfUnits.equals("0"))
			return ALLOW_BLANK;
		else
			return
				noOfUnits;
	}
	}
