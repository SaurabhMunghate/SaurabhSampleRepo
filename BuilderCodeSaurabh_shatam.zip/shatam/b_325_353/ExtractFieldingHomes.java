package com.shatam.b_325_353;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFieldingHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractFieldingHomes() throws Exception {
		super("Fielding Homes", "https://www.fieldinghomes.com/");
		LOGGER = new CommunityLogger("Fielding Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractFieldingHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Fielding Homes.csv", a.data().printAll());
	}
	@Override
	protected void innerProcess() throws Exception {
		
		String regHtml=U.getHTML("https://www.fieldinghomes.com/");
		String regUrlsSec=U.getSectionValue(regHtml, "<div class='subnav'><div class='flex'><ul class='sub-menu'>", "</ul></div></div>");
//		U.log(regUrlsSec);
		String[] regUrls=U.getValues(regUrlsSec, "<a  href=\"", "\"");
		for(String regUrl:regUrls) {
			U.log("RegUrl: "+regUrl);
			String rHtml=U.getHTML(regUrl);
			
			String[] comSecs=U.getValues(rHtml, "<div class=\"listing-img img-bg\" ", "Learn More <i class=\"");
			for(String comSec:comSecs) {
	//			U.log(comSec);
				String commName="";
				String comurl=U.getSectionValue(comSec, "<a href=\"", "\"");
				String commNameSec=U.getSectionValue(comSec, "<h6 class=\"text-white\">", "/h6>");
//				commName=U.getSectionValue(commNameSec, "</span>AT ", "<");
				commName=U.getSectionValue(comSec, "<h6 class=\"text-white\">", " <span ");
				if(commName==null)
					commName=U.getSectionValue(commNameSec, ">", " AT");
				commName=commName.replace("HOLLINS GROVE", "Hollins Grove").replace("MASONS BEND", "Masons Bend").replace("PADDLERS COVE", "Paddlers Cove").replace("LINDEN", "Linden").replace("FOREST RIDGE", "Forest Ridge").replace("TRINITY CREEK", "Trinity Creek").replace("MACKINTOSH ON THE LAKE", "Mackintosh On The Lake");

				//U.log(comurl+" name: "+commName);
				String commAddress=U.getSectionValue(comSec, "<p>Location: ", "</p>");
//				U.log(commAddress);
				comSec=comSec.replace("0s", "0,000");
//				try {
					addDetails(comurl,commName,comSec,commAddress);
//				} catch (Exception e) {}
	//			break;
			}
		}
		LOGGER.DisposeLogger();

	}

	private void addDetails(String comUrl, String comName, String comSec, String commAddress) throws Exception {
		// TODO Execute for single community
		
//	if(!comUrl.contains("https://www.fieldinghomes.com/communities/paddlers-cove/"))return;
		
		if(comUrl.contains("s/mackintosh-on-the-lake/")) return;
		
		if(comUrl.contains("https://www.fieldinghomes.com/communities/hollins-grove/")) {
			LOGGER.AddCommunityUrl(comUrl+ "--------------------------------- PAGE NOT FOUND");
			return;
		}
		
//		U.log(comSec);
		
		
		// ----------------- Community Url-----------------------
		U.log("communityURL========================================================> "+comUrl);
		String comHtml = U.getHTML(comUrl);
		comHtml=comHtml.replace("0s", "0,000");
		
		// ----------------- Community Name-----------------------
		U.log("comName========================================================> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				add=U.getAddress(commAddress);
				U.log("Address ::"+Arrays.toString(add));
				latLong=U.getGoogleLatLngWithKey(add);
				geo="true";
				U.log("Latlong ::"+Arrays.toString(latLong));
				

//				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
				String homeData="";
				String homeSec="";
				String[] homeUrls= {};
			
				homeSec=U.getSectionValue(comHtml, "<div class=\"section subsects\">", " <div class=\"section body lower\">").replaceAll("<h4>\\s*<a", "<h4><a");
				
				homeSec=homeSec.replace(">Forest Ridge Homes", ">The Forest Ridge Homes");
//				U.log(homeSec);
				homeUrls=U.getValues(homeSec, "<h4><a href=\"", "\"");
//					int c=0;
					for(String homeUrl:homeUrls) {
//						c++;
						U.log("== "+homeUrl);
						String homeHtml=U.getHTML(homeUrl);
						homeHtml=homeHtml.replace("0s","0,000");
						String[] fplanSecs=U.getValues(homeHtml, "<div class=\"gallery\">", "<span class=\"details\">View Details");
//						int co=0;
						for(String floopSec:fplanSecs) {
							
							String floorPlanUrl=U.getSectionValue(floopSec, "<a href=\"", "\"");
//							co++;
//							if(floorPlanUrl.contains("floorplans/")) {
								floorPlanUrl=homeUrl+"/"+floorPlanUrl;
								U.log("===>>> "+floorPlanUrl);
								homeData+= U.getSectionValue(U.getHTML(floorPlanUrl),"<div class=\"details\">","Download Floor Plan</a>") +
										 U.getSectionValue(U.getHTML(floorPlanUrl),"<div class=\"description\">","</div>") +homeHtml;
//								if(homeData.contains("661,820"))U.log("FOUND");
//							}
						}
					}
				
					
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml+homeData+comSec,	"Square Feet</strong> \\d{4}</|\\d{4} sq. ft.<br>|\\d{4} to \\d{4} sq. ft.", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

				String price[] = U.getPrices(comHtml+homeData+comSec, "S<span>Starting at: \\$\\d{3},\\d{3}</span></h4>|\\$\\d{3},\\d{3}</span>|\\$\\d{3},\\d{3}<br>|mid \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}</span>", 0);  //|Starting From \\$\\d{3},\\d{3}
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
//				U.log(Util.matchAll(comSec, "[\\s\\w\\W]{30}\\$661[\\s\\w\\W]{30}", 0));

				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				homeData=homeData.replaceAll("farmhouse|Farmhouse", "");
				propType=U.getPropType(comSec + (comHtml+homeData).replace("Bedroom 5 ILO Loft", "Bedroom 5 ILO the loft").replaceAll("Covered-Patio-Fireplace.jpg|Plank-Cottage|Craftsman|Plank_Cottage|Plank Cottage|Upcountry Farmhouse|-Farmhouse|Plank Cottage|-Cottage|Craftsman\\s*</div>|/Craftsman|_Craftsman|Craftsman-Ele|Craftsman \\d-\\d+|alt=\"Covered Patio\"", ""));
//				U.log(Util.matchAll(homeData, "[\\s\\w\\W]{30}loft[\\s\\w\\W]{30}", 0));
//				U.log(Util.matchAll(comHtml, "[\\s\\w\\W]{30}loft[\\s\\w\\W]{30}", 0));
//				U.log(Util.matchAll(comSec, "[\\s\\w\\W]{30}loft[\\s\\w\\W]{30}", 0));

				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
//				comHtml=comHtml.replace("", "");
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType((comHtml+homeData).replace("Stories</strong>", "Story"));
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
		
				comHtml=comHtml.replaceAll("homesite availability|Quick Move-in|Model Grand Opening Coming Soon|quick_movein|quick move-in options", ""); //because quickhomes are sold
				propStatus=U.getPropStatus(comHtml);
				
				U.log("PStatus========>:::"+propStatus);
//				if(comUrl.contains("https://www.fieldinghomes.com/communities/trinity-creek"))propStatus="Quick Move-in";

				
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				
				// ----------------- Community Data-----------------------
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
				data.addCommunity(U.getNoHtml(comName), comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);	
				
				
				
				
	}


}
