
package com.shatam.b_325_353;

import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFlorsheimHomesSaurabh extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractFlorsheimHomesSaurabh() throws Exception {
		super("Florsheim Homes", "https://florsheimhomes.com/");
		LOGGER = new CommunityLogger("Florsheim Homes");
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractFlorsheimHomesSaurabh();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Florsheim Homes.csv", a.data().printAll());

	}
	@Override
	protected void innerProcess() throws Exception {
//		String regHtml=U.getHTML("https://florsheimhomes.com/#latest-communities");
		
		String regHtml=U.getHTML("https://florsheimhomes.com/current-communities/");
		
		regHtml = U.removeComments(regHtml);
//		U.log(regHtml);
		regHtml = regHtml.replace("<div class=\"link_6\">", "");
		String[] comSecs = U.getValues(regHtml, "class=\"florsheim-column current_cmmunity","VIEW</a>"); //U.getValues(regHtml, "<div class=\"link_","VIEW COMMUNITY</a>"); //"<div class=\"col-sm-3 nav_logo\">", "</div>");

		U.log(comSecs.length);
		for(String comSec:comSecs) {
//			U.log(comSec);
			String comurl=U.getSectionValue(comSec, "\" href=\"", "\""); // "<a href=\"", "\"");
//			U.log("comurl ::"+comurl);
			addDetails(comurl,comSec);
		}
		LOGGER.DisposeLogger();
	}
	
	private void addDetails(String comUrl, String comSec) throws Exception {
		// TODO Execute for single community
//		if(!comUrl.contains("https://florsheimhomes.com/community/epic-founders-point/"))return;
		
		// ----------------- Community Url-----------------------
		U.log("communityURL========================================================> "+comUrl);
		String comHtml = U.getHTML(comUrl);
		
		
		// ----------------- Community Name-----------------------
		String comName = U.getSectionValue(comHtml, "<html><head><title>", "<");
		comName=comName.replaceAll(" &#8211; ICON", "");
		U.log("comName========================================================> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		if (comUrl.contains("https://florsheimhomes.com/community/icon-at-inspiration/")) {
			LOGGER.AddCommunityUrl("-------past community-------" + comUrl);
			return;
		}
		if (comUrl.contains("https://florsheimhomes.com/community/icon-passage/")) {
			LOGGER.AddCommunityUrl("-------past community-------" + comUrl);
			return;
		}
		if (comUrl.contains("https://florsheimhomes.com/community/valley-vista/")) {
			LOGGER.AddCommunityUrl("-------past community-------" + comUrl);
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				comHtml=comHtml.replaceAll("<strong>MODEL LOCATION:</strong><br/>Model homes are located at Icon at Inspiration: |<strong>FUTURE MODEL LOCATION:</strong><br/>|<strong>MODEL LOCATION:</strong><br>", "");
				comHtml=comHtml.replace("Aveneue<br>", "Aveneue, ").replace("3112 Vintage Drive Modesto", "3112 Vintage Drive, Modesto");
				add=U.getAddress(U.getSectionValue(comHtml, "<p class=\"sales_address\">", "<br"));
				
				if(comUrl.contains("/community/calaveras-place-ii/")) {
					String addsec = U.getSectionValue(comHtml, "<strong>DISPLAY HOME LOCATION:</strong><br>", "<br>Corner of Fargo Street");
					addsec = addsec.replace("<br>", ",");
					add=U.getAddress(addsec);
				}
				U.log("Address ::"+Arrays.toString(add));
				if(add[3]==ALLOW_BLANK && add[0]!=ALLOW_BLANK) {
					latLong=U.getGoogleLatLngWithKey(add);
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
				}
				if(add[0]!=ALLOW_BLANK && latLong[0]==ALLOW_BLANK) {
					latLong=U.getGoogleLatLngWithKey(add);
					geo="True";
				}

				U.log("Latlong ::"+Arrays.toString(latLong));
				
				U.log("Note========>:::"+note);
				//------------------Plan Data-----------------------
				int hm=0;
				String HomeSec="";
				String hmHtml="";
				String[] HomUrls=U.getValues(comHtml, "<div class=\"plan-community-info\"> ", "Learn More</a>");
				for(String homeUrl:HomUrls) {
					hm++;
					homeUrl=U.getSectionValue(homeUrl, "<a href=\"", "\"");
					U.log(hm+"=== "+homeUrl);
					hmHtml+=U.getHTML(homeUrl);
				}
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comSec + comHtml+hmHtml,	"\\d{4} SF|\\d{4} - \\d{4} SF|\\d{4} TO \\d{4} SF|</br>\\d{4} SF|From \\d{4} to \\d{4} SF|From \\d{4} SF TO \\d{4} SF", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String price[] = U.getPrices(comHtml, "Mid's \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|LOW \\$\\d{3},\\d{3}|HIGH \\$\\d{3},\\d{3}", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				
				hmHtml=hmHtml.replaceAll("title=\"5C COTTAGE\"></a>|COTTAGE\">Enlarge</a></div>|Cottage exteriors</li>", "");
				hmHtml=hmHtml.replace("1C", "cottage");
				propType=U.getPropType((hmHtml+comHtml).replaceAll("Cabinet|cabinets|/cabin;source", "").replace("Cottage and Traditional elevations", "").replace("LOFT", "with Loft "));
				
//				U.log(">>>  "+Util.matchAll(hmHtml, "[\\s\\w\\W]{30}cabin[\\s\\w\\W]{30}", 0));
//				U.log(">>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}cabin[\\s\\w\\W]{30}", 0));

				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
				
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				comHtml=comHtml.replaceAll("one and two- story", "one story and two- story");
				drvPropType=U.getdCommType(comHtml+hmHtml);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
				if(comUrl.contains("http://florsheimhomes.com/community/icon-at-inspiration/")) {
					comHtml=comHtml.replaceAll("soldout-communities|class=\"sold_out\"|Now open for information", "");
				}else {
				comHtml=comHtml.replaceAll("soldout-communities|class=\"sold_out\"|nav-logos/sold-out.png|Now open for information", "");
				}
				propStatus=U.getPropStatus(comHtml);
				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}Coming Summer 2019[\\w\\s\\W]{30}", 0));
				U.log("PStatus========>:::"+propStatus);
			if(comUrl.contains("https://florsheimhomes.com/community/icon-at-bridle-ridge/") || comUrl.contains("https://florsheimhomes.com/community/icon-at-inspiration/")||comUrl.contains("http://florsheimhomes.com/community/icon-at-bridle-ridge/"))
				propStatus="Sold Out";
				
				comName = comName.replace("&#8211; ", "- ");
				if(propStatus.equals("Coming Summer 2019")) 
				{https://florsheimhomes.com/community/epic-founders-point/
					propStatus=ALLOW_BLANK;
				}
				else
				propStatus=propStatus.replace("Coming Summer 2019", "");
				
				if(comUrl.contains("https://florsheimhomes.com/community/epic-founders-point/")||
						comUrl.contains("https://florsheimhomes.com/community/trails-walk/")) {
					add[0]="2821 Hawaiian Petrel Ave";
					add[1]="Modesto";
					add[2]="CA";
					add[3]="95355";
					latLong=U.getlatlongGoogleApi(add);
					geo="TRUE";
				}
				if(comUrl.contains("https://florsheimhomes.com/community/trails-walk/")){
					propStatus="sold out";
				}
					
				// ----------------- Community Data-----------------------
				data.addCommunity(comName.toLowerCase(), comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);
	}

	

}