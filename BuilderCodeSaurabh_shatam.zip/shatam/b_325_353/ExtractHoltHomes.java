package com.shatam.b_325_353;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHoltHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver = null;
	public ExtractHoltHomes() throws Exception {

		
		super("Holt Homes", "https://www.holthomes.com/");
		LOGGER = new CommunityLogger("Holt Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractHoltHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Holt Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
		String mainHtml=U.getHTML("https://www.holthomes.com/");

		String comSections[]=U.getValues(mainHtml, "<div class=\"organism image-grid-w-overlay-content\"", "</section>");
//		String comSections[]=U.getValues(mainHtml, "<div class=\"item\" >", "");
		for(String comSec:comSections) {
			
			String[] comUrlSec = U.getValues(comSec, "<a href=\"", "\"");
			U.log(comUrlSec.length);
			for(String comUrl : comUrlSec)
				addDetails(comUrl);
		}
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comUrl) throws Exception {
		
		if(!comUrl.contains("http"))
		comUrl="https://www.holthomes.com"+comUrl;
	
		comUrl = comUrl.replace("http:", "https:");
		U.log(comUrl);
		
		//TODO:
//		if(!comUrl.contains("https://holthomes.com/communities/middlebrook/")) return;
		
/*		if(comUrl.contains("communities/towns-at-crossroads/")) {
			
			LOGGER.AddCommunityUrl("======== Given on page but page showing 404 thus comm is return ============"+comUrl);
			return;
		}*/
 
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml=U.getHTML(comUrl);
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		
//		U.log("***********"+comHtml);
		String comName=U.getSectionValue(comHtml, "<div class=\"community-title title\">", "</div>");
		if(comName == null)
			comName=U.getSectionValue(comHtml, "<title>", "</title>");
		
		if(comName!=null)
			comName=U.getNoHtml(comName).replaceAll("New homes coming soon to| in Ridgefield, WA| in Camas, WA|Troutdale, OR", "")
			.replace("[Coming Soon]", "").replaceAll("-sherwood-oregon|Sherwood Oregon","");
		
		if(comName!=null && comName.trim().isEmpty()) {
			comName=U.getSectionValue(comHtml, "<iframe title=\"Holt Homes", "Community Map\"");
		}
//		if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")) comName="Stones Throw";
		U.log("comName ::"+comName);
		
		String note=U.getnote(comHtml.replace("receive presale pricing", ""));

		//======================address===============================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		String addSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps?sll", "\"");
		U.log("addSec: "+addSec);
		if(addSec == null )addSec=U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "/@");
		if(addSec!=null){
			addSec = addSec.replaceAll(",\\+United\\+States", "").replace("+Camas", ", Camas").replace("+", " ");
			U.log(addSec);
			add=U.getAddress(addSec);
			}
		if(addSec!=null && addSec.contains("&amp;q=")) {
			addSec = U.getSectionValue(addSec, "&amp;q=", "&amp;z=");
			if(addSec!=null){
			addSec = addSec.replaceAll(",\\+United\\+States", "").replace("12568+SE+162nd+Ave,+Happy+Valley,+OR+97086", "12568+Southeast+162nd+Avenue,Happy+Valley,+OR,+97086").replace("+Happy+Valley",", Happy+Valley").replace("+Camas", ", Camas").replace("+", " ");
			U.log(addSec);
			add=addSec.replace("12568 Southeast 162nd Avenue Happy Valley, OR, 97086", "12568 Southeast 162nd Avenue, Happy Valley, OR, 97086").split(",");
			}
		}
		
		if(addSec==null) {
			addSec=U.getSectionValue(comHtml, "Model Home Address:</dt>"," </dd>");
			if(addSec!=null) {
			addSec=addSec.replace("<dd>","").replace("<br>",",");
			add=U.getAddress(addSec);
			}
		}
		if(comUrl.contains("https://lp.holthomes.com/new-homes-estacada-faraday-hills-or")) {
			
			comName = "Faraday Hills";
			add[1]="Estacada";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		
/*		else if(comUrl.contains("https://lp.holthomes.com/new-homes-troutdale-or-gateway-landing")) {
			
			comName = "Gateway Landing";
			add[1]="Troutdale";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			
		}*/
		
//		else if(comUrl.contains("https://lp.holthomes.com/new-homes-lafayette-hearth-at-millican-creek")) {
//			
//			comName = "The Hearth at Millican Creek";
//			add[1]="Lafayette";
//			add[2]="OR";
//			latlag=U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latlag);
//			geo="TRUE";
//			
//		}
		else if(comUrl.contains("https://lp.holthomes.com/new-homes-ridgefield-washington-greely-farms")) {
//			comName = "ridgefield-washington-greely-farms";
			add[1]="Ridgefield";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		else if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-ramble-creek-ridgefield-wa")) {
			comName = "ramble creek";
			add[1]="Ridgefield";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
/*		else if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-middlebrook-sherwood-oregon")) {
			comName = "middlebrook";
			add[1]="sherwood";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}*/
		else if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")) {
			comName="Stones-Throw";
			add[1]="Vancouver";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		

		else {
			latlag[0]=U.getSectionValue(comHtml, "\"lat\": ", ",");
	//		U.log("JJJ");
			latlag[1]=U.getSectionValue(comHtml, "\"lng\": ", "}");
			U.log(">>>>>>>lat  ::"+latlag[0]+"\tlng :"+latlag[1]);
		}
		if(latlag[0] == null && latlag[1] == null) {
			String latlngSec = U.getSectionValue(comHtml, "https://www.google.com/maps/embed/", "\"");
			if(latlngSec != null)latlngSec = Util.match(latlngSec, "\\d{2}\\.\\d{2,},-\\d{3}\\.\\d{2,}");
			if(latlngSec != null && latlngSec.contains(","))
				latlag = latlngSec.split(",");
		}
		
		if((add[0]==null||add[0]==ALLOW_BLANK) && latlag[0] != null) {	
			add=U.getAddressGoogleApi(latlag);
			U.log("LL");
			geo="TRUE";
		}

		
		add[0]=add[0].replace("NW Graham/257th & W Columbia River Hwy", "257th & W Columbia River Hwy");
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		
		
		//==========================floorplans===========================================
		
		String mainfloorUrl="https://holthomes.com/floorplans";
		String mainfloorHtml=U.getHtml(mainfloorUrl,driver);
		String floorHtml="";
		//U.log(U.getCache(mainfloorUrl));
		String floorSec=U.getSectionValue(mainfloorHtml, "<option value=\"\">Community</option>", "</select>");
		String floorJsonKey[]=U.getValues(floorSec, "value=\"", "\"");
		String floorValueOfKey[]=U.getValues(floorSec, "\">", "<");
	//	U.log(Arrays.toString(floorJsonKey));
	//	U.log(Arrays.toString(floorValueOfKey));
		for(int i=0;i<floorJsonKey.length;i++) {
			String keyUrl="https://holthomes.com/floorplans?fwp_community="+floorJsonKey[i];
			
			
			if(floorValueOfKey[i].contains(comName)) {
				String keyUrlHtml=U.getHTML(keyUrl);
				String floorUrls[]=U.getValues(keyUrlHtml, "<a href=\"https://holthomes.com/floorplans", "\">");
				for(String fu:floorUrls) {
					String floorUrl="https://holthomes.com/floorplans"+fu;
					floorHtml+=U.getHTML(floorUrl);
				}
			}
			
			
		}
		
		String[] florSec = U.getValues(comHtml, "<div class=\"grid-item\">", "</div>");
		for(String floor : florSec) {
			
			floor = U.getSectionValue(floor, " <a href=\"", "\"");
			floorHtml+=U.getHTML(floor);
		}
		//========================available hoemss 
		
		String availhomesurl="https://holthomes.com/available-homes/";
		String availhtml=U.getHTML(availhomesurl);
		
		String homesurls[]=U.getValues(availhtml, "grid-item", "View Details")	;
		String availaurlhtml="";
for(String hu:homesurls) {
	//U.log(hu);
	String aurls=U.getSectionValue(hu, "href=\"", "\"");
	U.log(aurls);
	try {
	String ahtml=U.getHTML(aurls);
	String cname=U.getSectionValue(U.getSectionValue(ahtml, "Communities:", "</div"),"<a href=\"\">","</").trim();
//	U.log("==="+cname);
//	U.log("====="+comName.trim());
	if(cname.contains(comName.trim())) {
	//	U.log("=dsfdg==="+comName);
		availaurlhtml+=ahtml;
	}
	}catch(Exception e) {}
	
	
}
		
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
	    
	   
			prices=U.getPrices(comHtml+floorHtml+availaurlhtml, "\\$\\d{3},\\d{3}", 0);
			
			U.log(Arrays.toString(prices));
			
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(comHtml+floorHtml, "\\d{4} Sq. Ft.|\\d{4}-\\d{4} SF|<dd>\\d{4}</dd>", 0);//floorHtml
			
			
			U.log(Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comHtml);
			U.log(cType);
			
			
			String pType=ALLOW_BLANK;
			pType = U.getPropType((comHtml+floorHtml+availaurlhtml).replaceAll("Villages|villages", ""));
//			 U.log(Util.matchAll(comHtml+floorHtml+availaurlhtml, "[\\w\\s\\W]{30}villa[\\w\\s\\W]{30}",0));
			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			
			dType = U.getdCommType(comHtml+floorHtml);
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================
			

			String pStatus = ALLOW_BLANK;
			
			comHtml=comHtml.replace("[Coming 2023]","").replace("[Coming Soon]", "").replaceAll(">Move-In Ready<|\"Move-In Ready\"|in-ready-overview", "");
			floorHtml=floorHtml.replace("[Coming 2023]","").replace("[Coming Soon]", "").replaceAll(">Move-In Ready<|\"Move-In Ready\"|in-ready-overview", "");
			
			
			pStatus = U.getPropStatus((comHtml+floorHtml).replaceAll("New phase of homes</strong> opening soon", "New phase opening soon").replaceAll("Homes Coming Soon to Troutdale|homes coming soon to Troutdale",""));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+floorHtml, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));

			if(comUrl.contains("https://www.holthomes.com/communities/83/"))pStatus="Now Selling";
			if(comUrl.contains("https://www.holthomes.com/communities/laurel-woods/")) note="Now Pre-Selling";
//			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-ramble-creek-ridgefield-wa")) pStatus="Summer 2022";
			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")) pStatus="Coming 2023, Coming Soon";
//			if(comUrl.contains("https://lp.holthomes.com/new-homes-camas-washington-glades-green-mountain")||
//			comUrl.contains("https://lp.holthomes.com/new-homes-ridgefield-washington-greely-farms"))
//				if(pStatus==ALLOW_BLANK)
//					pStatus = "Spring 2022";// img
//					else
//						pStatus += ", Spring 2022";
//			if(comUrl.contains("https://www.holthomes.com/greely-farms/"))pStatus=pStatus+", Spring 2022";
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			
			
			
			//======================image status=================
		//	if(comUrl.contains("/communities/creekside-heights/"))pStatus="New Phase Coming Aug 2021";
//			if(comUrl.contains("communities/greely-farms/"))pStatus="Almost Sold Out";
//			if(comUrl.contains("https://holthomes.com/communities/teal-crest/")) {pStatus=pStatus+", Almost Sold Out";}
			
		
			
			
		
	//		if(comUrl.contains("/new-homes-lafayette-hearth-at-millican-creek"))pStatus="Coming July 2021, "+pStatus;
			pStatus=pStatus.replace("Homes Are Selling Quickly, Selling Quickly", "Homes Are Selling Quickly");
			
			//from image dt:27 jul 21
			if(comUrl.contains("https://www.holthomes.com/communities/the-glades-at-green-mountain/")) {
			pStatus+=", New Phase Coming Winter 2022";}
			if(comUrl.contains("/pleasant-valley-villages"))pStatus="Now Selling";
			//if(comUrl.contains("/new-homes-troutdale-or-gateway-landing"))pStatus="Coming October 2021";
//			if(comUrl.contains("/communities/laurel-woods"))note="New Pre-Selling";
			if(comUrl.contains("https://www.holthomes.com/communities/east-mountain/")||
					comUrl.contains("communities/ponderosa-ridge/") ||
					comUrl.contains("/communities/faraday-hills/")) {
				pStatus="Now Selling";
			}
			if(comUrl.contains("https://holthomes.com/communities/middlebrook/")) {
				pStatus="Coming In 2022";
			}
			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-middlebrook-sherwood-oregon"))pStatus=pStatus+", Spring 2022";
//			if(comUrl.contains("https://holthomes.com/communities/creekside-heights/")) {
//				note="Now Pre-Selling";			
			//prices[0]="$500,960";
		//	prices[1]="$515,960";
			
		//	}
//			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-middlebrook-sherwood-oregon"))
//				pStatus+=", Coming 2022"	;		
				add[0] =add[0].replace("1011 Ne 13th St", "1011 NE 13th St");
				//if(comUrl.contains("https://www.holthomes.com/communities/83/")) note="Now Pre-Selling";	
				
			data.addCommunity(comName.replace("&#x27;s", " &").trim(), comUrl, cType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(U.getCapitalise(add[0].replace(",", "").toLowerCase()).trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon"));
			data.addNotes(note);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
			
			
			j++;
			U.log("=================================="+j);
	}
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("<div id=\"site-map\" class=\"site-map\">")) {
			
			String frameSec = U.getSectionValue(comHtml, "<div id=\"site-map\" class=\"site-map\">", "<div class=\"community-column sidebar\">");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "href=\"", "\">"); 
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.contains("contradovip.com")) {
					
					mapData = U.getHtml(frameUrl, driver);
					
					if(mapData.contains("<g id=\"v.1.opt.")) {
						
						ArrayList<String> lots = Util.matchAll(mapData, "<g id=\"v.1.opt.", 0);
						U.log("Count Pins: "+lots.size());
						totalUnits = String.valueOf(lots.size());
					}
					
				}
				
			}
		}
			return totalUnits;
	}
	
	
	
	
	
	
}
