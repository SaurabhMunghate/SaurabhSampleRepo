package com.shatam.b_325_353;

import java.util.Arrays;
import java.util.Map.Entry;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRodRockDevelopment extends AbstractScrapper{
	static int k = 0;
	static int j = 0;
	WebDriver driver = null;
	CommunityLogger LOGGER;
	static MultiValueMap lotDataMap = new MultiValueMap();
	static MultiValueMap communityData = new MultiValueMap();


	static String builderUrl = "https://www.rodrock.com";
	public ExtractRodRockDevelopment() throws Exception {
		super("Rodrock Development", builderUrl);
		LOGGER = new CommunityLogger("Rodrock Development");
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRodRockDevelopment();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Rodrock Development.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		// TODO Auto-generated method stub
		String mainHtml = U.getHTML("https://www.rodrock.com/communities");
		String lot_data=ALLOW_BLANK;
		JsonParser jparser = new JsonParser();
//		String arr[]=null;
		String dataSec=U.getSectionValue(mainHtml, "window.__PRELOADED_STATE__ = ", "</script>");
		JsonObject jobj = (JsonObject) jparser.parse(dataSec).getAsJsonObject().get("cloudData");
//		JsonObject lotJson = (JsonObject) jobj.getAsJsonObject().get("lots");
		JsonArray lotJson = (JsonArray)jobj.getAsJsonObject().get("lots").getAsJsonObject().get("571e7800371e2f07643d1681").getAsJsonObject().get("data").getAsJsonArray();
		JsonArray commJson = (JsonArray) jobj.getAsJsonObject().get("communities").getAsJsonObject().get("571e7800371e2f07643d1681").getAsJsonObject().get("data").getAsJsonArray();
		 String lotString="";
		
		
		for(int i=0;i<commJson.size();i++) {
			String id=U.getSectionValue(commJson.get(i).toString(), "\"_id\":\"", "\",");
//			U.log("++++++++++++++++++\n"+id);
//			arr[i]=id;
			for(JsonElement ele:lotJson) {
//				U.log("++++++++++++++++++\n"+ele);
				JsonObject jobj1 = ele.getAsJsonObject();
				if(jobj1.toString().contains(id)) {
					lot_data+="\n"+jobj1;
				}
				
				
			}
//			break;
		}
		
		String comSecs[] = U.getValues(mainHtml, "<div class=\"CommunityCard_content\"", "<span class=\"CommunityCard_detailButton\"");
		U.log(comSecs.length);
		for(String com: comSecs) {
			com=com.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->| data-reactid=\"\\d+\"", "");
			String url = U.getSectionValue(com, "<a class=\"d-flex flex-column\" href=\"", "\"");
			String comName = U.getSectionValue(com, "<a class=\"d-flex flex-column\" href=\""+url+"\">", "<");
//			U.log(url);
//			U.log(com);
//			U.log(comName);
			
			
			
			
			getDetail(builderUrl+url,comName,com);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	private void getDetail(String comUrl,String comName, String com) throws Exception {
		// TODO Auto-generated method stub
		
//	if(j>=6)
//		 if(!comUrl.contains("https://www.rodrock.com/communities/overland-park-ks/sundance-ridge-big-sky"))return;
		{
					
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			U.log("Count: " + j + "\t" + comUrl);
			
			String html = U.getHtml(comUrl,driver);
			String remSec = U.getSectionValue(html, "window.__PRELOADED_STATE__ ", "</html>");
			if(remSec!=null)
			html=html.replace(remSec, "");
			html=html.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->| data-reactid=\"\\d+\"", "");
            

			// ============================================Community
			// name=======================================================================
//			U.log(">>>>>>>>>>>>>>>"+com);
			//FileUtil.writeAllText("/home/shatam-50/Desktop/jsoncom.txt", com);

			String communityName = comName;
			
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'");
			U.log("community Name---->" + communityName);

//			// ================================================Address
//			// section===================================================================
//
			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			
			String addSec = U.getSectionValue(html, ",\"name\":\""+communityName.replace("Greens Of Chapel Creek", "Greens of Chapel Creek")+"\"", "}}</script>");
			if(addSec!=null) {
				U.log(addSec);
				add[0]=U.getSectionValue(addSec, "\"streetAddress\":\"", "\"");
				add[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
				add[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
				add[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\"");
			}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
			
			
			
			
//
//			// --------------------------------------------------latlng----------------------------------------------------------------
			String latlngSec = U.getSectionValue(com, "href=\"https://www.google.com/maps/place/", "/@");
			if(latlngSec!=null)latLng=latlngSec.split(",");

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);
//
//			//====== Floor Plans ================================
			String[] floorSec = U.getValues(html, "<div class=\"PlanCard_headlineBanner\" ", "class=\"PlanCard_detailButton\"");
			String floorData = ALLOW_BLANK;

			for(String floor : floorSec) {
				floor = U.getSectionValue(floor, "<a class=\"d-flex\" href=\"", "\"");
				U.log("floorUrl --->"+floor);
				U.getSectionValue(U.getHTML(builderUrl+floor).replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->| data-reactid=\"\\d+\"", ""), "<div class=\"DetailOverview_wrapper\" ", "Floor Plan</h3>");				
			}
//			
//		
//			//====== Available Homes ================================
			String[] homeSec = U.getValues(html, "<div class=\"HomeCard_headlineBannerContent\"", ">View Home Detail</span>");
			U.log("total homes"+homeSec.length);
			
			String homeData = ALLOW_BLANK;
			for(String home : homeSec) {
//				U.log(home);
				home = U.getSectionValue(home, "<a class=\"d-flex flex-column\" href=\"", "\"");
				if(home.contains("google"))continue;
				U.log("homeUrl -->"+home);
				homeData += U.getSectionValue(U.getHTML(builderUrl+home).replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->| data-reactid=\"\\d+\"", ""), "<div class=\"DetailSection\"", "Nearby Available Homes</h3>");
			}
//			
//			// ============================================Price and
//			// SQ.FT======================================================================
			String remSec2=U.getSectionValue(html, "type=\"application/ld+json\">{\"", "}}</script>");
//            U.log(remSec2);
            if(remSec2!=null)
            	html=html.replace(remSec2, "");
//
//			U.log("homeData: "+homeData);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replace("$1 million", "$1,000,000").replaceAll("0s|0's", "0,000")
					.replace("array of choices, priced from $440,000 to $700,000.", "")
					.replace("$450,000 to", "")
					.replace("$450,000 and", "");
			
			String prices[] = U.getPrices(com + html + floorData + homeData, 
					"\"price\":\\d{6},|>\\$\\d,\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}<|upper \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|<span class=\"DetailOverview_priceValue\">\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|prices ranging from \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|priced from \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|priced from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|<span class=\"DetailOverview_priceValue\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|<span class=\"DetailOverview_priceValue\">\\$\\d{3},\\d{3}|class=\"HomeCard_priceValue\">\\$\\d{3},\\d{3}|the low \\$\\d{3},\\d{3}|<span class=\"DetailOverview_priceValue\">\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3},\\d{3}</span>|<span class=\"HomeCard_priceValue\">\\$\\d,\\d{3},\\d{3}|the mid \\$\\d{3},\\d{3}", 0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];


			U.log("Price--->" + minPrice + " " + maxPrice);

            if(comUrl.contains("https://www.rodrock.com/communities/olathe-ks/stonebridge-meadows"))minPrice="$500,000";//bcz diff price given in page and cache
//			// ======================================================Sq.ft===========================================================================================
			html = html.replaceAll("Home sizes will range from 1,900 square feet and up|</span><span class=\"PlanCard_iconListLabel\">SQ FT", " SQ FT").replaceAll("</span><span class=\"HomeCard_iconListLabel\">SQ FT", " SQ FT");
			String[] sqft = U.getSqareFeet((com + html + floorData + homeData).replaceAll("flex-column\"><b>SQFT</b>3,465</li><li class=\"d-flex", ""),
					"\"sqft\":\\d{4}|range from \\d,\\d{3} square feet|SQFT</b>\\d,\\d{3}|\\d,\\d{3} SQ FT",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//
//			// ================================================community
//			// type========================================================
			
			
			
			html =html.replace("merge luxury", "luxury homes").replace("Resort-level", "resort style pool");
			String communityType = U.getCommType((html + com).replaceAll("Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));
//
//			// ==========================================================Property
//			// Type================================================
//
//						html=html
			String proptype = U.getPropType((html.replace("estate experience", "Estate Residences experience") + com + floorData + homeData).replaceAll("Heritage Manor Declarations|Manor Street|-manor-street", "").replaceAll("James Engle Custom Homes|George Custom Homes", ""));
//			U.log(">>>>>>>>"+Util.matchAll( homeData, "[\\w\\s\\W]{100}manor[\\w\\s\\W]{100}",0));

//		
//			// ==================================================D-Property
//			// Type======================================================
			String dtype = U.getdCommType((html + com + floorData + homeData).replace("two story 3,171 sq. ft. plan", "").replace("Reverse 1.5</div>", "Reverse 1.5 story</div>").replaceAll("franchisee|branch|BRANCH|(f|F)loor", "")
					+ communityName);
//			// ==============================================Property
//			// Status=========================================================
//	
			html =html.replace("&quot;Coming Soon&quot;", "").replaceAll("2-Story . . . COMING SOON|Coming Soon 1.5 story|Coming Soon. . . Ranch|Coming Soon. . .  Reverse|Coming Soon.. . . 2-story|Prieb Home Info Coming Soon|Riverstone is now open to approved|More coming soon|community, is now open|Middle School is now open|to grow, with new lots available|Pool Coming Soon", "");
			String pstatus = U.getPropStatus(
					(html + com).replaceAll("Pricing coming soon....|More info coming soon|Coming Soon....|Price coming soon......|New Plan by New Mark Homes Coming Soon!|headlineBannerContent\">Coming soon!|New Mark Homes- Coming soon!|headlineBannerContent\">Beautiful New Mark Homes Plan Coming Soon!|Additional info coming soon!|more info coming soon!|More information coming soon|More Info. Coming Soon!|dlineBannerContent\">More info coming soon!|More info coming soon!|headlineBannerContent\">Coming Soon|Coming Soon.. . . 2-story home built|- More Information coming soon.", "").replace("The Augusta Reverse can be ready to move into November 1st!", ""));
//			U.log("\n");
//			// ============================================note====================================================================
		//	if(comUrl.contains("https://www.rodrock.com/communities/olathe-ks/stonebridge-pointe"))proptype=proptype+", Patio Homes";
//
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
//			
//			//========== Hard Code Data ==================================
//
////			int contract = 0;
////			for (String val : homeSec) {
////				if (val.contains("Under Contract</h3>"))//
////					contract++;
////			}
////			if(homeSec != null && homeSec.length>contract)
////				if(pstatus==ALLOW_BLANK)
////					pstatus = "Quick Move-In Homes";
////				else if(!pstatus.contains("Quick Move-In Homes")) 
////					pstatus += ", Quick Move-In Homes";
//			
//			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon")
//					.replace("Sold-out", "Sold Out");
//			if(add[0]!=null)
//				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
//			
			
//			===================================================================================
			
			String lotCount=ALLOW_BLANK;
			String lotSec=U.getSectionValue(html, "<g>", "</g>");
			if(lotSec!=null) {
			String[] lotData=U.getValues(lotSec, "<path class=\"leaflet-interactive", ">");
			U.log("lotData.length=="+lotData.length);
			lotCount=Integer.toString(lotData.length);
			}
			if(lotCount.equals("0")) {
				lotCount=ALLOW_BLANK;
			}
			U.log("lotCount=="+lotCount);
			
			
	
//			if(comUrl.contains("communities/olathe-ks/grayson-place")) {
//				dtype = dtype.replace("2 Story,", "");
//			}
//			dtype = dtype.replace(", 5 Story", "");
			
//			//=========================================================================================================================
			// ----------------- Community LOGGER-----------------------
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("TH ST", "th St").replace(",", "").replace("&", "And").replace("&amp;", "And").trim(), add[1].replace(",", "").trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace(", Only Three Homes Remain", ""));
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;

	}

}