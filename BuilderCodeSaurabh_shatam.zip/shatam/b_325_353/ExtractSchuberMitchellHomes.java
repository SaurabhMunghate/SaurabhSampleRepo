package com.shatam.b_325_353;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.AddSelection;

/**
 * @author MJS
 * @date 30/03/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class ExtractSchuberMitchellHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://schubermitchell.com";
	WebDriver driver = null;

	public ExtractSchuberMitchellHomes() throws Exception {
		super("Schuber Mitchell Homes", builderUrl);
		LOGGER = new CommunityLogger("Schuber Mitchell Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSchuberMitchellHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Schuber Mitchell Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
//		U.setUpChromePath();
//		driver=new ChromeDriver();

		String html = U.getHtml("https://www.schubermitchell.com/missouri",driver) + 
				U.getHtml("https://www.schubermitchell.com/arkansas",driver);
		
		String[] nowSellComSec = U.getValues(html, "<div class=\"card_row card-row-3 \"", "</span></button></a></div></div>");
		U.log(nowSellComSec.length);
		for(String comSec : nowSellComSec) {
//		U.log("comSec==="+comSec);
			String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
//			U.log("comUrl==="+comUrl);
			getDetail(comUrl, comSec+" Now Selling ");
//			break;
		}
		
		String[] comingComSec = U.getValues(html, "<div class=\"dmRespCol small-12 u_", "See Details</span>");
		U.log(comingComSec.length);
		for(String comSec : comingComSec) {
			
			String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
			if(comUrl.equals("#"))continue;
//			U.log("comUrl22==="+comUrl);
			
			getDetail(comUrl, comSec+" Coming Soon ");
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void getCommunity(String regionUrl) throws Exception {
		// TODO Auto-generated method stub
		
		regionUrl = U.getSectionValue(regionUrl, "<a href=\"", "\"");
		
		String html = U.getHtml(builderUrl+regionUrl,driver);
		String[] mainSec = U.getValues(html, "<div class=\"card_row card-row-3", "</span></button></a></div></div>");
		
		for(String main : mainSec) {
			
			String comUrl = U.getSectionValue(main, " href=\"", "\"");
			U.log(comUrl);
//			getDetail(builderUrl+comUrl, main);
		}
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
		
//		if(j>=9)
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			
			if(data.communityUrlExists(comUrl))
			return;
			LOGGER.AddCommunityUrl(comUrl);
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			//TODO:
//			if(!comUrl.contains("https://schubermitchell.com/community-detail/Avalon-163867")) return;
			
			U.log("Count: " + j + "\t" + comUrl);
			
			if(comUrl.contains("foxhaven"))comUrl="https://info.schubermitchell.com/foxhaven";

			String html = getHtml(comUrl,driver);//U.getHTML(comUrl);
			U.log(U.getCache(comUrl));
			
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, "<span class=\"card_title \" card_link\"=\"\">", "</span></a>");
			if(communityName==null)
				communityName = U.getSectionValue(com, "font-weight: bold; display: unset;\">", "<");
			if(communityName==null)
				communityName = U.getSectionValue(html, "<title>", "</title>");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'")
					.replaceAll("- Be The First To Know About This Pea Ridge Community!|Phase 6 In Carl Junction Is Coming Soon!", "");
			U.log("community Name---->" + communityName);
//
//			// ================================================Address
//			// section===================================================================
//
			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
//
//			
//			add[0] = ALLOW_BLANK;
//		//U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.SalesOfficeAddress\">", "<");
//			add[1] = U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.City\">", "<");
//			add[2] = U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.State\">", "<");
//			add[3] = U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.Zip\">", "<");
			String city = U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.City\">", "<");
			String addressSec = U.getSectionValue(html, "<div class=\"win_column win_body\"><div>", "</div></div></div></div></div></div>");
			
			U.log("addressSec here: "+addressSec);
			
			if(addressSec!=null) {
				addressSec =addressSec.replace(city, ","+city);
				String spans[]=U.getValues(addressSec, "<span>", "</span>");
				if(!spans[1].contains("Starting"))
					addressSec=spans[0]+spans[1];
				else
					addressSec=""+spans[1];
				U.log("addressSec: "+addressSec);
				add = U.getAddress(addressSec);

			}
			
			
//			U.log(com);
			
			if(addressSec==null && html.contains("Visit Our Sales Office") && html.contains("info@schubermitchell.com")
					&& comUrl.contains("/community-detail/Joplin-Metro-98810")) {
				
				String section = U.getSectionValue(html, "Visit Our Sales Office", "info@schubermitchell.com");
				//U.log(section);
				
				add[0] = U.getSectionValue(section, "SalesOfficeAddress\">", "</span>");
				add[1] = U.getSectionValue(section, "SalesOfficeCity\">", "</span>");
				add[2] = U.getSectionValue(section, "SalesOfficeState\">", "</span>");
				add[3] = U.getSectionValue(section, "SalesOfficeZip\">", "</span>");
				U.log("Address From Here---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
			}
			
			if(add[0]==null || add[0]==ALLOW_BLANK) {
				
				addressSec = U.getSectionValue(com, "<div class=\"card_address card_text\">", "</span>");
				U.log("addsec:------ "+addressSec);
//				if(addressSec==null)addressSec = U.getSectionValue(com, "<span style=\"display: unset; font-weight: bold; color: rgb(0, 103, 56); font-style: normal;\" class=\"m-font-size-13 font-size-16\">", "<");
				
				if(addressSec==null) {
					addressSec = U.getSectionValue(com, "<p class=\"m-size-13 size-16\">", "</span>");
					addressSec=U.getNoHtml(addressSec);
					U.log("addsec111:::::"+addressSec);
				}
				
				addressSec=U.getNoHtml(addressSec).trim();
				addressSec=addressSec.replace("Webb City,", ",Webb City,").replace("Carl Junction,", ",Carl Junction,")
						.replace("Joplin,", ", Joplin,").replace("Oronogo,", ", Oronogo,")
						.replace(" Duenweg,", ", Duenweg,").replace("Pea Ridge,", ", Pea Ridge,")
						.replace("Gentry,", ", Gentry,").replace("Neosho,", ", Neosho,")
						.replace("Siloam Springs,", ", Siloam Springs,").replace("Bentonville,", ", Bentonville,");
				
				U.log("addsec:::::"+addressSec);
				
				com = com.replace("bold; color: rgb(0, 103, 56);\">"+communityName, "");
				if(addressSec==null)
					addressSec = U.getSectionValue(com, "color: rgb(0, 103, 56);\">", "<");
				if(addressSec==null)
					addressSec = U.getSectionValue(com, "color: rgb(0, 103, 56); font-style: normal;\">", "<");
				if(addressSec==null)
					addressSec = U.getSectionValue(com, "font-weight: 700; display: unset;\">", "<");
//				U.log(com+">>>>>>>>>>>>>>>"+addressSec);
				if(addressSec!=null) {
					addressSec = addressSec.replace(" Centerton", ", Centerton").replace(" Carl Junction", ",Carl Junction").replace(" Oronogo", ", Oronogo")
							.replace(" Duenweg", ", Duenweg");
					add = U.getAddress(addressSec);
				}
				
			}
			
//			if(html.contains("Visit Our Sales Office</h2>")) {
//				add[0]=U.getSectionValue(html, "SalesOfficeAddress\">", "<");
//				add[1]=U.getSectionValue(html, "SalesOfficeCity\">", "<");
//				add[2]=U.getSectionValue(html, "SalesOfficeState\">", "<");
//				add[3]=U.getSectionValue(html, "SalesOfficeZip\">", "<");	
//			}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
//
//			// --------------------------------------------------latlng----------------------------------------------------------------
//			
//		
			latLng[0] = U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.Lat\">", "<");
			latLng[1] = U.getSectionValue(html, "data-inline-binding=\"dynamic_page_collection.Lng\">", "<");
		
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);
			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

//				geo = "TRUE";
			}
//
//			
			if ((add[0]==null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
//				if (add[0]==null || add[0].length() < 4)
//					add[0] = add1[0];
//				if (add[3] == null)
//					add[3] = add1[3];
				add=add1;
				geo = "TRUE";
			}
//			if(comUrl.contains("foxhaven")) {
//				add[1]="CENTERTON";
//				add[2]="AR";
//				latLng = U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latLng);
//				geo = "TRUE";
//				note = "Address & LatLng Taken From City & State";
//			}
			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);
//
//			//========== Move In Homes ==================================================
			String addHomeData = ALLOW_BLANK;
			String movPart = U.getSectionValue(html, "Quick Move-Ins</h2>", "<div class=\"dmRespRow");
			if(movPart==null)
				movPart = "";
			String[] movSec = U.getValues(movPart, "<div class=\"card_row card-row-3", "</span></button></a></div></div>");
//			
			String moveData = ALLOW_BLANK;
			for(String data : movSec){
				
					String url = U.getSectionValue(data, "href=\"", "\"");
					U.log("movUrl: "+url);
					String movData = getHtml(builderUrl+url,driver);
					
					//adding home descrotion
					if(movData.contains("BDX Favorites") && movData.contains("Request More Information")) {
						addHomeData = U.getSectionValue(movData, "BDX Favorites", "Request More Information");
					}
					
					String mhtml = addHomeData + U.getSectionValue(movData, "<h2 class=\"u_", "<li class=\"feature-list-title\">Interactive Media</li>");		
					moveData += mhtml;
				}
			
			//========== Floor Homes ==================================================
			
			String floorPart = U.getSectionValue(html, "Plans Available to Build</h2>", "<div class=\"dmRespColsWrapper\"");
			if(floorPart==null)
				floorPart = "";
			String[] floorSec = U.getValues(floorPart, "<div class=\"card_row card-row-3 \"", "</span></button></a></div></div>");
			String floorData = ALLOW_BLANK;
			if(floorSec!=null)
			for (String data : floorSec) {

				String url = U.getSectionValue(data, "href=\"", "\"");
				U.log(url);
				String fhtml = U.getSectionValue(U.getHtml(builderUrl+url,driver), "<h2 class=\"u_", "Elevations</h3> ");//U.getSectionValue(U.getHtml(builderUrl+url,driver), "div class=\"detailPage", " <h2 class=\"title\">Request More Info</h2>");
				floorData += fhtml;
			}
			
			//========================== MOdel HOME DATA =================
			String modelData = ALLOW_BLANK;
//			
//			if(html.contains("Model Homes")) {
//				
//				String modelSec = U.getSectionValue(html, "Model Homes", "Visit Our Sales Office");
//				//U.log("modelSec: "+modelSec);
//				//FileUtil.writeAllText("/home/shatam-10/Desktop/data/modelSec.txt", modelSec);
//				
//				String[] models = U.getValues(modelSec, "<div class=\"card_row card-row-3", "See Details</span>");
//				U.log("MODEL HOMES: "+models.length);
//				
//			}
			
			if(comUrl.contains("https://schubermitchell.com/community-detail/Fox-Spur-149008")) {
				modelData = U.getHtml("https://www.schubermitchell.com/home-detail/2300KI-Series-1991427", driver);
			}
			
//			// ============================================Price and
//			// SQ.FT======================================================================
//
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replaceAll("</span>\\s*<span id=\"suffix-text-\\d_\\d+-\\d+-\\d+\" class=\"suffix-api-text\">Sq. Ft.</span> ", " Sq. Ft.");
			//U.log(Util.matchAll(html, "[\\w\\s\\W]{30}1393[\\w\\s\\W]{30}", 0));
			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#39;s|0&#8217;s|0s|0's", "0,000").replace("&#39;s", ",000");
			
			html = html.replace("0s", "0,000");
			String prices[] = U.getPrices(com + html , "<span class=\"dealPrice\">\\$\\d{3},\\d{3}</span>|Starting from the \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|Priced at \\$\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//
//			// ======================================================Sq.ft===========================================================================================
//		
			String[] sqft = U.getSqareFeet(modelData + com + html+moveData,
					"\\d{4} - \\d{4} Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft|With over \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft|\\d,\\d{3} Sq\\. Ft|\\d{4} Sq. Ft.",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(com + html+moveData, "[\\s\\w\\W]{50}2,300[\\s\\w\\W]{50}", 0));
			
//			// ================================================community
//			// type========================================================
//
			if(floorData!=null)floorData = floorData.replace(" split bedroom design", " split level bedroom design");
			String rem[]=U.getValues(html, "<script>", "</script>");
			for(String s:rem) {
				html=html.replace(s, "");
			}
			html=html.replaceAll("\"Master Planned\";|\"Green Community\";", "");
			String communityType = U.getCommType((html + com).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf|config\\.Gated|IsGated|systemAggregated|aggregated", ""));

			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html + com, "[\\s\\w\\W]{30}Green Community[\\s\\w\\W]{30}", 0));

			
			// ==========================================================Property
			// Type================================================

			String proptype = U.getPropType((html + com + moveData + floorData ).replaceAll("luxury of a larger floor", "luxury home"));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html + com, "[\\s\\w\\W]{30}patio[\\s\\w\\W]{30}", 0));

			// ==================================================D-Property
			// Type======================================================
			String dtype = U.getdCommType((html + com + moveData + floorData).replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
			html=U.removeSectionValue(html, "function setCommunityStatusImage(result, position) {", "}");
//			U.log(Util.matchAll(html+com, "[\\w\\s\\W]{10}now selling[\\w\\s\\W]{10}", 0));
			html = html.replaceAll("homes coming|[Q|q]uick [M|m]ove|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Homesites are available now", "Homesites available now").replace("Phase 1 of Piper Glen is selling out fast", "Phase 1 selling out fast").replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available")
					.replace("Now selling in Phase 2", "Now selling Phase 2")
					.replace("Phase 8 is now selling", "Phase 8 now selling")
					.replace("Phase 6 in Carl Junction is Coming Soon", "Phase 6 Coming Soon")
					.replace("closeoutFlag|IsCloseOut)", "");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			String pstatus = U.getPropStatus((com).replaceAll("See Details Now Selling|closeoutFlag|IsCloseOut", ""));
//			FileUtil.writeAllText("/home/shatam-10/Desktop/data/com.txt", com);
			
			U.log("pstatus: "+pstatus);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html + com, "[\\s\\w\\W]{50}Now selling[\\s\\w\\W]{50}", 0));

//	
//			// ============================================note====================================================================
//
//
			add[0]=add[0].replace("&amp;", "&");
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
			
		
			
			boolean date = false;
			for (String val : movSec) {
				//U.log(val);
				if (Util.match(val, "Available") != null)
					date = true;
			}
			if(date == true)
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-In Homes";
				else if(!pstatus.contains("Quick Move-In Homes")) 
					pstatus += ", Quick Move-In Homes";
			
				
//			if(comUrl.contains("/community-detail/The-Pines-at-Orchard-Park-151506"))pstatus=pstatus+", Grand Opening";
//			if( comUrl.contains("/community-detail/Briarwood-152612"))pstatus = "Grand Opening, "+pstatus;
			if(comUrl.contains("/community-detail/Southwind-Trail-151847"))pstatus="Grand Opening, "+pstatus;
			//=========================================================================================================================
	        String counting=ALLOW_BLANK;
	        String startDt=ALLOW_BLANK;
	        String endDt=ALLOW_BLANK;
			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;

	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		//{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					Thread.sleep(10000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,8000)", ""); 
				//	System.exit(1);
					Thread.sleep(2000);
//					try {
//						WebElement close=driver.findElement(ByXPath.xpath("//*[@id=\"map\"]/div/div/div[1]/div[3]/div/div[3]/div[2]/img"));
//						U.log(close);
//						close.click();
//						
//					}catch ( Exception e) {
//						U.log("***********  Failed Click Element ***"+e);
//					}
					Thread.sleep(2000);
					//U.log("Current URL:::" + driver.getCurrentUrl());
					html += driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				
			} 
			return html;
		}
			return html;
	
	}
}
