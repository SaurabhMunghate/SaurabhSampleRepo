package com.shatam.b_325_353;

import java.util.Arrays;

import org.apache.http.impl.BHttpConnectionBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractStonehollowHomes extends AbstractScrapper {
	WebDriver driver = null;
	public ExtractStonehollowHomes() throws Exception {
		super("Stonehollow Homes", "https://www.stonehollowhomes.com/");
		LOGGER = new CommunityLogger("Stonehollow Homes");
		
	}

	CommunityLogger LOGGER;
	
	
	
	
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
	//	String regHtml=U.getHTML("https://www.stonehollowhomes.com/");
	//	String[] comSecs=U.getValues(regHtml, "class=\"js-subpage fp-el\">", "/a></li>");
		String regHtml=U.getHTML("https://www.stonehollowhomes.com/communities");
		String[] comSecs=U.getValues(regHtml, "div class=\"CommunityCard_media\"", "<ul class=\"CommunityCard_list2");
		U.log("total comm"+comSecs.length);
		
		for(String comSec:comSecs) {
			String commNameSec=U.getSectionValue(comSec, "<h4 class=\"CommunityCard_name\"", "<span class=\"CommunityCard_city");
			commNameSec=commNameSec.replaceAll("data-reactid=\"\\d+\">","");
			String commName=U.getSectionValue(commNameSec, ">","<br").replace("<!-- /react-text -->","");
		
			String comurl=U.getSectionValue(comSec, "href=\"", "\"");
			comurl="https://www.stonehollowhomes.com"+comurl;
			U.log("URL "+comurl+" name: "+commName);
			addDetails(comurl,commName);
//			break;
		}
		driver.quit();
		LOGGER.DisposeLogger();

	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractStonehollowHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Stonehollow Homes.csv", a.data().printAll());

	}
	private void addDetails(String comUrl, String comName) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.stonehollowhomes.com/communities/sherman/austin-landing"))return;
		// ----------------- Community Url-----------------------
		U.log("communityURL====> "+comUrl);
		String comHtml = U.getHtml(comUrl,driver);
		
		
		// ----------------- Community Name-----------------------
		U.log("comName===> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		if (comUrl.contains("series")) {
			LOGGER.AddCommunityUrl("-------FloorPlan Urls-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		U.log("chk"+comHtml.contains("}}}}</script>"));
		String remvJsn=U.getSectionValue(comHtml,"__PRELOADED_STATE__ = {\"","</html>");
     	comHtml=comHtml.replace(remvJsn, "");
		//U.log("ComHt,ml"+comHtml);
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
//				String mapHtml=U.getHTML("https://www.stonehollowhomes.com/location-map");
//				String[] addSecs=U.getValues(mapHtml, "<div id=\"ctl01_pSpanDesc\" class=\"t-edit-helper\">", "<input type=\"hidden\"");
//				for(String addSec:addSecs) {
////					U.log("=== "+addSec);
//					if(addSec.contains(comName)) {
//						String address="";
////						U.log("=== "+addSec);
//						U.log("======");
//						if(comName.contains("Sutton Fields")||comName.contains("Timineri Estates")) {
//							address=U.getSectionValue(addSec, "</span></p><p class=\"fp-el\" class=\"fp-el\">", "</p><p class=\"fp-el\" class=\"fp-el\">Phone");
//							if(address!=null) {
//							address=address.replace("</p><p class=\"fp-el\" class=\"fp-el\">", " ").replace("447 Princeton", "447, Princeton");
//							}
//							latLong[0]=Util.match(addSec, "\\d{2,3}\\.\\d{5,}");
//							latLong[1]=Util.match(addSec, "-\\d{2,3}\\.\\d{5,}");
//							geo="True";   //currect latlong not able to see on page
//						}
//						else if(comName.contains("Camden Parc")){
//							address=U.getSectionValue(addSec, "</h3><p class=\"fp-el\" class=\"fp-el\">", "<p class=\"fp-el\" class=\"fp-el\">Phone").replace("</p><p class=\"fp-el\" class=\"fp-el\">", ",").replaceAll("\\+|\\?q\\=|</p>|/place/", " ").replace("USA/@", "USA /@").replace("&h", " &h").replace("TX75092", "TX 75092").replace("DrSherman", "Dr, Sherman");
//							U.log(address);
//						}else {
//							if(addSec!=null)
//								address=U.getSectionValue(addSec, "<a href=\"https://www.google.com/maps", "\"").replaceAll("\\+|\\?q\\=|/place/", " ").replace("USA/@", "USA /@").replace("&h", " &h").replace("TX75092", "TX 75092").replace("DrSherman", "Dr, Sherman");
////							if(comName.contains("Austin Landing")) {
////								latLong[0]="33.599725";    //it sows in map but not in pagesource
////								latLong[1]="-96.64415";
////							}
////							if(comName.contains("Parkhaven")) {
////								latLong[0]="33.599725";    //it sows in map but not in pagesource
////								latLong[1]="-96.64415";
////							}
//						}
//						U.log("address: "+address);
	
				String addrSec=U.getSectionValue(comHtml, "<span class=\"DetailOverview_subheading\"","</span>");
				U.log("ADDR Sec befr"+addrSec);
				addrSec=addrSec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replaceAll("data-reactid=\"\\d+\">","").replace("</span>\n" + 
						"                            </h2>\n" + 
						"                            <div ", "").replace("|",",");
				U.log("ADDR Sec Aftr===="+addrSec);
				
				
						if(addrSec!=null)
						add=U.getAddress(addrSec);
				U.log("ADDRESS=="+Arrays.toString(add));	
//					break;
              String latlngSec=U.getSectionValue(comHtml,"https://www.google.com/maps/place","\"");
               latLong[0]=U.getSectionValue(latlngSec, "/",",");
               latLong[1]=U.getSectionValue(latlngSec,",", "/");
				
				if(add[0]!=ALLOW_BLANK && latLong[0]==ALLOW_BLANK) {
					latLong=U.getGoogleLatLngWithKey(add);
					geo="True";
				}
				if(add[2]==null && latLong[0]!=ALLOW_BLANK) {
					add=U.getGoogleAddressWithKey(latLong);
					geo="True";
				}
				
				if(add[3]==ALLOW_BLANK && latLong[0]!=ALLOW_BLANK) {
					
					add=U.getAddressGoogleApi(latLong);
					geo="True";
				}
				
				U.log("Address ::"+Arrays.toString(add));
				U.log(Arrays.toString(latLong));
				
				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
//				String homeData="";String[] homeSecs= {};
//				String hmHtml=U.getHTML("https://www.stonehollowhomes.com/available-homes");
//				if(hmHtml!=null) 
//				 homeSecs=U.getValues(hmHtml, "<div class=\"testimonial-head\">", "StonehollowHomes.com</span>");
//				if(homeSecs!=null) {
//				for(String homeSec:homeSecs) {
////					U.log("==========>>>>>>");
////					U.log(homeSec);
//					if(homeSec.contains(comName)){
////						U.log(homeSec);
//						homeData=homeSec;
//						U.log("==========");
//					}
////					break;
//				}
//				}
				String homeSec[]=U.getValues(comHtml, "<div class=\"PlanCard_wrapper\"","<ul class=\"PlanCard_list1");
				String homeHtml=ALLOW_BLANK;
				
				for(String home:homeSec) {
					String homeUrl=U.getSectionValue(home,"href=\"","\"");
					String homeHtml2=U.getHTML("https://www.stonehollowhomes.com"+homeUrl);
					String remJsn=U.getSectionValue(homeHtml2, ">window.__PRELOADED_STATE__ = {\"","</html>");
					homeHtml2=homeHtml2.replace(remJsn, "");
					homeHtml+=homeHtml2;
				}
				
				
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				homeHtml=homeHtml.replace("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"280\">","").replaceAll("</span><span class=\"Carousel_listItemLabel\" data-reactid=\"\\d+\">","");
				String[] sqft = U.getSqareFeet(comHtml+homeHtml,"\\d,\\d{3}Sq Ft|\\d,\\d{3}sqft|\\d{4} sqft", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String price[] = U.getPrices(comHtml+homeHtml, "\\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|LOW \\$\\d{3},\\d{3}|HIGH \\$\\d{3},\\d{3}", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
				
				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				
				//String remJsn=U.getSectionValue(homeHtml, ">window.__PRELOADED_STATE__ = {\"","}}}}</script>");
				//U.log("UUU"+Util.matchAll(comHtml,"[\\w\\W\\s]{50}craftsman[\\w\\W\\s]{50}",0));
//				comHtml=comHtml.replace("alt=\"First Floor\"","").replace("alt=\"Second Floor","");
//				homeHtml=homeHtml.replace("alt=\"First Floor\"","").replace("alt=\"Second Floor","");
				comHtml=comHtml.replace("By combining innovative technology with classical craftsmanship","").replace("reputation for high quality construction and custom design","");
				homeHtml=homeHtml.replace("By combining innovative technology with classical craftsmanship","").replace("reputation for high quality construction and custom design","");
				propType=U.getPropType(comHtml+homeHtml);
	
				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
				
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				homeHtml=homeHtml.replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">Story", " Story")
						.replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories",  " Stories");
				drvPropType=U.getdCommType((comHtml+homeHtml).replaceAll("Ranch-Elementary|Ranch Elementary", ""));
				U.log(Util.matchAll(homeHtml, "[\\w\\s\\W]{100}stories[\\w\\s\\W]{100}", 0));
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
			
				comHtml=comHtml.replace("Coming Soon-Phase 2", "PHASE 2 COMING SOON").replaceAll("Model home coming soon|Model: Coming Soon!|Coming Soon!</a>|Coming Soon!|coming-soon\"", "");
				
				propStatus=U.getPropStatus(comHtml);
//				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}coming[\\w\\s\\W]{30}", 0));
				U.log("PStatus========>:::"+propStatus);
				//from floorplan images
//				if(comUrl.contains("http://www.stonehollowhomes.com/green-meadows"))
//				{
//					minPrice="$430,900";
//					maxPrice="$634,900";
//					minSqft="1649";
//					maxSqft="3858";
//					drvPropType ="1 Story, 1.5 Story, 2 Story";
//				}
//				if(comUrl.contains("/parkhaven"))
//				{
//					drvPropType ="1 Story, 2 Story";
//					propType = "Patio Homes";
//				}
//				if(comUrl.contains("/sutton-fields"))
//				{
//					minSqft="1609";
//					maxSqft="4231";
//					drvPropType ="1 Story, 1.5 Story, 2 Story";
//					propType = "Loft";
//				}
//				if(comUrl.contains("/timineri-estates"))
//				{
//					minSqft="1609";
//					maxSqft="2582";
//					minPrice ="$337,990";
//					maxPrice = "$431,990";
//					
//				}
//				if(comUrl.contains("camden-parc")) {
//					minSqft="1609";
//					maxSqft="3481";
//					minPrice ="$327,990";
//					maxPrice = "$475,990";
//				}
//				if(comUrl.contains("/parkhaven")) {
//					minSqft="1501";
//					maxSqft="2444";
//					minPrice ="$283,990";
//					maxPrice = "$342,990";
//				}
				//comUrl = comUrl.replace("http:", "https:");
				
				String lotcount=ALLOW_BLANK;
				String[] lotdata=U.getValues(comHtml, "<path class=\"leaflet-interactive\"", ">");
				if(lotdata.length>0) {
					lotcount=Integer.toString(lotdata.length);
				}
				
				U.log("lotcount==="+lotcount);
				
				
				
				
				
				
				
				// ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
				data.addUnitCount(lotcount);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}


}
