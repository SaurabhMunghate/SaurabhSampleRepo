package com.shatam.drhorton;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDRHorton extends AbstractScrapper {
	static int x = 0;
	final static String HOME_URL = "https://www.drhorton.com/";
	final static String BUILDER_NAME = "D.R. Horton";

	int counter = 0;
	
	static WebDriver driver = null;
	static CommunityLogger LOGGER;
	
	static public ArrayList<String> setofcomm = new ArrayList<String>();

	public ExtractDRHorton() throws Exception{

		super("D.R. Horton", "https://www.drhorton.com/");
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		if(driver==null)
		{
			driver=new FirefoxDriver();
		}
		long startTime = System.currentTimeMillis();
//		U.logDebug(false);
		AbstractScrapper a = new ExtractDRHorton();
		a.process();
		
		SplitDRHorton splitDRHorton = new SplitDRHorton(data, setofcomm, 0, setofcomm.size(), driver, LOGGER);
		ForkJoinPool pool = new ForkJoinPool();
		pool.invoke(splitDRHorton);
		
		LOGGER.DisposeLogger();
		driver.close();
		try{
			driver.quit();
		}
		catch(Exception e){
			
		}
		FileUtil.writeAllText(U.getCachePath()+"D.R. Horton.csv", a.data().printAll());
		
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("Total time in milliSecond=="+totalTime);
		
		System.out.printf("******************************************\n");
		System.out.printf("Main: Parallelism: %d\n", pool.getParallelism());
		System.out.printf("Main: Active Threads: %d\n", pool.getActiveThreadCount());
		System.out.printf("Main: Task Count: %d\n", pool.getQueuedTaskCount());
		System.out.printf("Main: Steal Count: %d\n", pool.getStealCount());
		System.out.printf("******************************************\n");
	}

	@Override
	protected void innerProcess() throws Exception {
		
		String html = U.getHTML(HOME_URL);
		int tempCnt = 0,cnt=0;
		ArrayList<String> states = Util.matchAll(html, "<a href=\"(.*?)\"><path class=\"active-state\" id=\"", 1);
		U.log("Total State :::::: "+states.size());
		for(String state : states){
			U.log("https://www.drhorton.com"+state);
			state = "https://www.drhorton.com"+state;
			String stateHtml = getHtml(state,driver);
			stateHtml = U.removeComments(stateHtml);
			String[] comSections = U.getValues(stateHtml, "<div class=\"coveo-list-layout CoveoResult\">", "Compare</button>");
			cnt += comSections.length;
			LOGGER.AddSubRegion(state, comSections.length);
			U.log(comSections.length);
			for(String comSec : comSections){
				setofcomm.add(comSec);
			}
			//break;
		}
		U.log("Total Size==" + setofcomm.size());
/*		Thread.sleep(2000);
		{
			calladdDetail(setofcomm);
		}
*/		
	}
	private String getHtml(String url, WebDriver driver) throws IOException, InterruptedException {
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{
			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,800)", ""); 
					
					try{
					WebDriverWait wait = new WebDriverWait(driver, 10);
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"CoveoSearchResults\"]/div[2]/div/div[1]/div/section/div/div/button"))));

					WebElement loadBtn = driver.findElement(By.xpath("//*[@id=\"CoveoSearchResults\"]/div[2]/div/div[1]/div/section/div/div/button"));//--------//load more button
					loadBtn.click();
					U.log(":::::::::::::CLick Success:::::::::::::::");
					}
					catch(Exception e){
						U.log(":::::::::::::CLick UnSuccess:::::::::::::::"+e.getMessage());
					}
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
}
