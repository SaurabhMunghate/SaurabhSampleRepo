package com.shatam.drhorton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.RecursiveAction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;

import com.shatam.b_001_020.DR_HORTAN;
import com.shatam.utils.CommunityList;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.Util;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
public class SplitDRHorton extends RecursiveAction{ 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<String> listOfCommunity = null;
	private int start = 0;
	private int end = 0;
	private CommunityList data = null;
	private WebDriver driver = null;
	CommunityLogger LOGGER;
	static int j=0;
	
	protected static final String ALLOW_BLANK = "-";
	final static String HOME_URL = "http://www.drhorton.com/";
	final static String BUILDER_NAME = "D.R. Horton";
	
	public SplitDRHorton(CommunityList data, ArrayList<String> listOfCommunity, int start, int end, WebDriver driver, CommunityLogger LOGGER) {
		this.data = data;
		this.listOfCommunity = listOfCommunity;
		this.start = start;
		this.end = end;
		this.driver = driver;
		this.LOGGER = LOGGER;
	}
	
	@Override
	protected void compute() {
		int thresold = listOfCommunity.size()/3;
		if(end-start < thresold){
			
			for(int i = start; i < end; i++){
				
				
				String comSec = listOfCommunity.get(i);
				comSec = comSec.replaceAll("\\s*\\n+\\s*", " ");
				//U.log(comSec);
				String cUrl = "https://www.drhorton.com" + U.getSectionValue(comSec, "<a href=\"", "\"");
				U.log("comUrl : "+cUrl);
				String cHtml;
				try {
					cHtml = U.getHTML(cUrl);
					cHtml = StringEscapeUtils.unescapeJava(cHtml);
					addDetails(cUrl, cHtml,comSec);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}else{
			int middle = (end + start) / 2;
			SplitDRHorton splitDRHorton1 = new SplitDRHorton(data,listOfCommunity, start, middle, driver, LOGGER);
			SplitDRHorton splitDRHorton2 = new SplitDRHorton(data,listOfCommunity, middle, end, driver, LOGGER);
			
			invokeAll(splitDRHorton1,splitDRHorton2);
		}
	}
	
	private void addDetails(String comUrl, String comHtml, String comSec) throws Exception {
		//if(j>=1947 && j<=2000)
				{	
					
					//U.log(":::::::::::::"+j+"::::::::::::::::::");
					//U.log(comUrl);
					
					if(data.communityUrlExists(comUrl)){
						LOGGER.AddCommunityUrl(comUrl+"::::::::Repeated:::::::::::");
						return;
					}
					LOGGER.AddCommunityUrl(comUrl);
					
					//if(!comUrl.contains("https://www.drhorton.com/arizona/tucson/marana/saguaro-bloom"))return;
					
					//-----------Remove Near By Communtiies sec-------------
					comHtml = U.removeSectionValue(comHtml, "Nearby Communities", "</section>");
					
					//-----------_CommunityName--------------------
					//U.log(comSec);
					String comName = U.getSectionValue(comHtml, "data-community-name=\"", "\"").trim();
					comName = comName.replaceAll("^&#160;|&#160;$| - Waxahachie| - Townhomes$| - D\\.R\\. Horton$| D\\.R\\. Horton$", "");
					if(comName.length()==0){
						comName = U.getSectionValue(comSec, "CoveoResultTitle\"> <a href=\""+comUrl.replace("https://www.drhorton.com", "")+"\">", "<").replace("-", " ");
						//comName=ALLOW_BLANK;
					}
					//U.log(comSec);
					String add[] = {"","","",""};
					String geo = "FALSE";
							
					String latLng [] = {"",""};
					String addressSec = U.getSectionValue(comHtml, "data-community-address=\"", "\"");
					addressSec  =addressSec.replace("CA 93638, Fresno, CA 93722", "CA 93638")
							.replace(". PSL FL 34984&#160; OR 2844 SW Savona Blvd., Port St. Lucie, FL 34953", ", Port St. Lucie, FL 34984");
					add = U.getAddress(addressSec);
					U.log("address is "+Arrays.toString(add));
					
					latLng[0] = U.getSectionValue(comHtml, "data-latitude=\"", "\""); 
					latLng[1] = U.getSectionValue(comHtml, "data-longitude=\"", "\""); 
					if(latLng[0].startsWith("0"))latLng = new String[]{ALLOW_BLANK,ALLOW_BLANK};
					U.log("latLng is "+Arrays.toString(latLng));
					
					if(add[0]==null || add[1]==null || add[2]==null || add[3]==null){
						if(latLng[0]!=null || latLng[0].length()>4){
							add = U.getAddressGoogleApi(latLng);
							geo= "TRUE";
						}
					}
					
					//------------Format street address------------------------
					add[0] = U.getCapitalise(add[0].toLowerCase());
					U.log("Street Address ::::::::::>" + add[0]+"<:::::::::::");
					add[0] = add[0].replaceAll("^&#160;|&#160;$", "")
							.replace("&#160;", " ")
							.replace("&#39;", "'")
							.replaceAll(",$", "").replace("&amp;", "&").replaceAll("\\.$", "");
					//------to remove GPS Address----------
					add[0] = add[0].replaceAll("\\s*\\(*[g|G]*ps\\s*([A|a]*ddress)*\\:.*?\\)*\\s*$", "");
					//---remove bracket address-----
					add[0] = add[0].replaceAll("\\s*\\(+.*?\\)+\\s*$", "");

					//-----remove numbers----------------
					add[0] = add[0].replaceAll("\\s*\\(*\\d+\\)*\\s*[-]*\\s*\\d+-\\d+$", "");
					
					//------to remove status form Address----------
					add[0] = add[0].replaceAll("Please Call For Appointment$|Please Call For Information$|\\* Model Home Coming Soon \\* |\\*\\* Model Opening Soon \\*\\*\\s*|\\*\\*\\s*[M|m]?odel\\s*[O|o]?ffsite\\s*\\*\\*", "");
					
					add[0] = add[0].replaceAll("In Close-out!\\s*|By Appointment Only E-mail Us At: Pohakalasales@drhorton.com|^By Appointment Only$|^Address Coming Soon$| By Appointment Only$| Please Call For Info$| Model Not Open\\s*[Yet]*$|\\s*Call For\\s*([A|a]*n)*\\s*Appointment$|Call For Locations$|Call For An Appointment Close Out Community$|Call Ronda For Information[!]*$|Northstar Call Ronda For Information!| Model Opening Soon$| Model Home Now Open$", "");
					
					add[0]  =  add[0].replaceAll("^Selling From[:]*\\s*|^Tbd$|^\\s*Now Preselling$|^Now Selling[!]*\\s*|Model Coming Soon[!]*$|Model Coming Spring 2019[!]*$|^Model Now Open[!]*\\s*|Coming Soon[!]*$|Coming Spring 2019!\\s*|Coming Summer 2018", "");
					add[0] = add[0].replaceAll("Antioch, Tn|Ashland City, Tn", "");
					U.log("Formatted Street Address ::::::::::>" + add[0]+"<::::::::::::");
					
					if(add[0].length()<4 && latLng[0].length()>4)
					{
						add[0] = U.getAddressGoogleApi(latLng)[0];
						geo ="TRUE";
					}
					add[1]  =U.getCapitalise(add[1]);
					
					if(comUrl.contains("https://www.drhorton.com/iowa/des-moines/ankeny/villas-at-willow-run-twin")){
						add = new String[]{"202 NW Greenwood St", "Ankeny", "IA" ,"50023"};
						latLng = U.getlatlongGoogleApi(add);
						geo="TRUE";
					}
					if(comUrl.contains("https://www.drhorton.com/alabama/huntsville/huntsville/wilson-cove")){
						add = new String[]{"199 Sectionline St","Gurley","AL","35748"};
						latLng = U.getlatlongGoogleApi(add);
						geo="TRUE";
					}
					
					//---------------Price-------------------
					String minPrice = ALLOW_BLANK,maxPrice = ALLOW_BLANK;
					comHtml = comHtml.replaceAll("s</strong>", ",000</strong>").replace("0s", "0,000");
					String prices[] = U.getPrices(comHtml+comSec, "\\$\\d{3},\\d{3}", 0);//<strong>\\$\\d{3},\\d{3}<|price\">\\$\\d{3},\\d{3}<
					minPrice = (prices[0]==null)?ALLOW_BLANK : prices[0];
					maxPrice = (prices[1]==null)?ALLOW_BLANK : prices[1];
					//U.log("minPrice "+minPrice);
					//U.log("maxPrice "+maxPrice);
					
					//---------------sqft-------------------
					String minSqft = ALLOW_BLANK,maxSqft = ALLOW_BLANK;
					String sqft[] = U.getSqareFeet(comHtml+comSec, "[\\d,]*\\d+\\s*-\\s*[\\d,]*\\d+\\s*square feet|[\\d,]*\\d+\\s*-\\s*[\\d,]*\\d+</strong>\\s*sq\\.?\\s*ft|>\\d,\\d+</strong>\\s*sq\\.?\\s*ft", 0);
					minSqft = (sqft[0]==null)?ALLOW_BLANK : sqft[0];
					maxSqft = (sqft[1]==null)?ALLOW_BLANK : sqft[1];
					//U.log("minSqft "+minSqft);
					//U.log("maxSqft "+maxSqft);
					
					
					//------------comType---------
					String comType = ALLOW_BLANK;
					comType = U.getCommunityType(comSec+comHtml);
					//U.log("comType "+comType);
					
					//------------propType---------
					String propType = ALLOW_BLANK;
					comHtml = comHtml.replace("no HOA Fees", "");
					propType = U.getPropType(comSec+comHtml);
					//U.log("propType "+propType);
					
					
					//------------dType---------
					String dType = ALLOW_BLANK;
					comHtml = comHtml.replaceAll("</strong> Story</li>", " Stories </li>");
					dType = U.getdCommType(comSec+comHtml);
					//U.log("dType "+dType);
					
					
					//------------status---------
					String status = ALLOW_BLANK;
					comHtml  = comHtml.replaceAll("[Q|q]*uick\\s*[-]*\\s*[M|m]*ove|Quick delivery home|data-sales-office-message=\"(.*?)\"", "")
							.replaceAll("status\">\\s*Coming Soon|Amenities - Coming Soo|- Coming Soon\">|address\">Coming Soon|/maps/search/Coming Soon", "")
							.replaceAll("move-in ready houses waiting| several move-in ready homes available|ready to move|Move-in Ready Homes</a>|data-tab-title=\"Move-In Ready Homes|move-in-ready-tab\">Move-In Ready Homes", "");
					comHtml = comHtml.replaceAll("coming soon and will feature|miss out on the last opportunity|New homes available in Deer Trail|selling fast so come see|about the new homes available|floor plans, and grand opening|amenities are coming soon|Coming soon to Alachua|alt=\"Coming Soon|MODEL COMING WINTER 201|Model Coming Fall 2018|cabana \\(coming soon|grand opening events|Ashton Park is Selling Out of|local grand opening|School \\(opening August 2018", "");
					status = U.getPropStatus(comSec+comHtml);
					//U.log("status "+status);
					
					
					
					data.addCommunity(comName, comUrl, comType);
					data.addAddress(add[0].trim(), add[1], add[2], add[3]);			
					data.addLatitudeLongitude(latLng[0], latLng[1], geo);
					data.addSquareFeet(minSqft, maxSqft);
					data.addPrice(minPrice, maxPrice);			
					data.addPropertyType(propType, dType);
					data.addPropertyStatus(status);
					data.addNotes(U.getnote(comHtml));

				}
				j++;
		
	}

}
