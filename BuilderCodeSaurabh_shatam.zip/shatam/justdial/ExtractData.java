package com.shatam.justdial;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractData {
	static int id = 1;
	static ArrayList<String> allTitles = new ArrayList<String>();

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String url = "http://justdial.com/NAGPUR/Hospital";
		String html = U.getHTML(url);
		String section = U.getSectionValue(html, "<li class=\"jsel\">",
				"<li class=\"jaujf\">");
		// U.log(section);
		// Hospital Links
		String hospiLinks[] = U.getValues(section, "<a href=\"", "\"");
		ArrayList<String> allLinks = new ArrayList<String>();
		for (String item : hospiLinks) {
			allLinks.add(item);
			String[] otherUrls = getNextPageLink(item);
			for (String urls : otherUrls) {
				if (!allLinks.contains(urls)) {
					allLinks.add(urls);
				}
			}

		}
		U.log(allLinks.size());
		String categ[] = null;
		for (String lnUrl : allLinks) {
			U.log(lnUrl);
			categ = lnUrl.split("/");
			U.log(categ[4]);
			addDetails(lnUrl, categ[4].replace("-", " "));

		}

	}

	private static void addDetails(String hospiLink, String categ)
			throws Exception {
		// TODO Auto-generated method stub
		U.log(hospiLink);
		String html = U.getHTML(hospiLink);
		String[] secValues = U.getValues(html, "<span class=\"jcn\">",
				"<a class=\"jblu\"");

		for (String item : secValues) {
			findDetails(item, categ);

		}
		U.log("=========##Hospi End##===========");
		// String nextUrl=getNextPageLink(hospiLink);

	}

	private static void findDetails(String section, String categ)
			throws Exception {
		// TODO Auto-generated method stub

		String subSec = Util.match(section, "<a href=\".*.</a>+\\s+</span>");
		U.log(subSec);
		String linkUrl = U.getSectionValue(subSec, "<a href=\"", "\"");
		U.log("LinkUrl::" + linkUrl);
		String subTitle = U.getSectionValue(subSec, "title='", "'");
		U.log("SubTitle::" + subTitle);
		String title = U.getSectionValue(subSec, "' >", "</");
		U.log("Title::" + title);

		if (title.contains("www.icliniq.com"))
			return;
		if (!allTitles.contains(title))
			allTitles.add(title);
		else
			return;
		if (title.contains("(Not Practicing)"))
			return;

		// Getting address and contact details from Clinic data
		String adSec = U.getSectionValue(section, "<section class=\"jbc\">",
				"</a>");
		// U.log("AdSec:::" + adSec.trim());
		String address = null;
		if (adSec.contains("|"))
			address = U.getSectionValue(adSec, "<p>", "|");
		else
			address = adSec.substring(adSec.indexOf("<p>") + 3);

		U.log("AdSec:::" + address.trim());
		if (address.contains("<b>")) {
			String adr[] = address.split("<b>");
			address = adr[0];
		}
		if (address.contains("Call</span>:")
				|| address.contains("<a class=\"clogo\"")) {
			address = "";
		}

		if (address.contains("<"))
			address = null;

		U.log(address.trim());

		// /Getting Contact Details
		String conDetails = U.getSectionValue(section,
				"<p><span class=\"Gray\">Call</span>:", "</p>");
		if (conDetails != null) {
			U.log("conSec::::" + conDetails.trim());
			String landLineNum = "", mobileNum = "";
			ArrayList<String> contNumbrs = Util.matchAll(conDetails, "\\d{12}",
					0);
			if (contNumbrs.size() > 0)
				landLineNum = contNumbrs.get(0);
			U.log("LandLineNum::" + landLineNum);
			if (contNumbrs.size() > 1)
				mobileNum = contNumbrs.get(1);
			U.log("mobileNum::" + mobileNum);
			String keyWords = getOtherDetails(linkUrl);
			U.log("keyWords::" + keyWords);
			ArrayList<String> timeAvailability = getTimings(linkUrl);
			String verifiFlag = getVerified(linkUrl);
			U.log("Verified::" + verifiFlag);
			categ = categ.replace("Hospital Dental", "Dentists");
			categ = categ.replace("ENT Hospitals", "ENT Doctors");
			categ = categ.replace("Hospital Orthooaedic",
					"Orthooaedic Hospital");
			/*
			 * addDataToDatabase(linkUrl, subTitle, title, address.trim(),
			 * landLineNum, mobileNum, keyWords, timeAvailability, verifiFlag,
			 * categ);
			 */

			U.log("==========###Clinic End###============");
		}

	}

	private static String getVerified(String linkUrl) throws Exception {
		String html = U.getHTML(linkUrl);
		String flag = "False";
		if (html
				.contains("<a href=\"javascript:void(0);\" onClick=\"return openDiv('jvrp');\" class=\"jdv\">")) {
			flag = "True";
		}
		// TODO Auto-generated method stub
		return flag;
	}

	private static void addDataToDatabase(String linkUrl, String subTitle,
			String title, String address, String landLineNum, String mobileNum,
			String keyWords, ArrayList<String> timeAvailability,
			String verifyFlag, String categ) throws Exception {
		// TODO Auto-generated method stub
		if (landLineNum.length() == 0)
			landLineNum = "0";
		if (mobileNum.length() == 0)
			mobileNum = "0";
		long landLine = Long.parseLong(landLineNum);
		long mobile = Long.parseLong(mobileNum);
		String dbPath = "D://DocDb.db";
		Connection conn = getDBConnection(dbPath);
		U.log(conn);
		U.log(timeAvailability.size());
		String query = "INSERT INTO Details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(query);
		pstmt.setString(1, categ);
		pstmt.setInt(2, title.hashCode());
		pstmt.setString(3, title.trim());
		pstmt.setString(4, subTitle.trim());
		pstmt.setString(5, linkUrl.trim());
		pstmt.setString(6, address.trim());
		pstmt.setLong(7, landLine);
		pstmt.setLong(8, mobile);
		pstmt.setString(9, keyWords.trim());
		pstmt.setString(10, verifyFlag.trim());
		pstmt.setString(11, timeAvailability.get(0).trim().replace("Monday:",
				"").replace("<br>", " , ").replace("05:30 am", "05:30 pm"));
		pstmt.setString(12, timeAvailability.get(1).trim().replace("Tuesday:",
				"").replace("<br>", " , ").replace("05:30 am", "05:30 pm"));
		pstmt.setString(13, timeAvailability.get(2).trim().replace(
				"Wednesday:", "").replace("<br>", " , ").replace("05:30 am",
				"05:30 pm"));
		pstmt.setString(14, timeAvailability.get(3).trim().replace("Thursday:",
				"").replace("<br>", " , ").replace("05:30 am", "05:30 pm"));
		pstmt.setString(15, timeAvailability.get(4).trim().replace("Friday:",
				"").replace("<br>", " , ").replace("05:30 am", "05:30 pm"));
		pstmt.setString(16, timeAvailability.get(5).trim().replace("Saturday:",
				"").replace("<br>", " , ").replace("05:30 am", "05:30 pm"));
		pstmt.setString(17, timeAvailability.get(6).trim().replace("Sunday:",
				"").replace("<br>", " , ").replace("05:30 am", "05:30 pm"));
		pstmt.executeUpdate();
		conn.close();
	}

	public static Connection getDBConnection(String dbPath) throws Exception {
		Class.forName("org.sqlite.JDBC");
		Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
		return conn;
	}

	private static ArrayList<String> getTimings(String linkUrl)
			throws Exception {
		// TODO Auto-generated method stub
		String html = U.getHTML(linkUrl + "/moreInfo");
		String section = U.getSectionValue(html, "Hours of Operation",
				"</tbody>");
		ArrayList<String> clinicTimings = new ArrayList<String>();
		U.log(section);
		if (section != null) {
			String values[] = U.getValues(section, "<td>", "</td>");
			U.log(values.length);
			String days[] = new String[] { "", "", "", "", "", "", "" };
			String timing[] = new String[] { "", "", "", "", "", "", "" };
			int j = 0, k = 0;
			for (int i = 0; i < values.length; i++) {
				if (i % 3 == 0) {
					days[j] = values[i];
					j++;
				}
				if (i % 3 == 2) {
					timing[k] = values[i];
					k++;
				}

			}
			U.log(timing[0]);
			U.log(timing[1]);
			U.log(timing[2]);
			U.log(timing[3]);
			U.log(timing[4]);
			U.log(timing[5]);
			U.log(timing[6]);

			U.log(days[0]);
			U.log(days[1]);
			U.log(days[2]);
			U.log(days[3]);
			U.log(days[4]);
			U.log(days[5]);
			U.log(days[6]);
			clinicTimings.add(days[0] + ":" + timing[0]);
			clinicTimings.add(days[1] + ":" + timing[1]);
			clinicTimings.add(days[2] + ":" + timing[2]);
			clinicTimings.add(days[3] + ":" + timing[3]);
			clinicTimings.add(days[4] + ":" + timing[4]);
			clinicTimings.add(days[5] + ":" + timing[5]);
			clinicTimings.add(days[6] + ":" + timing[6]);

		}
		return clinicTimings;
	}

	private static String getOtherDetails(String linkUrl) throws Exception {
		String html = U.getHTML(linkUrl);
		String section = U.getSectionValue(html, "<h3>Also Listed In</h3>",
				"</section>");
		U.log(section);
		String keyWords[] = U.getValues(section, "\">", "</a>");
		String allKeyWords = "";
		for (int i = 0; i < keyWords.length; i++) {
			if (keyWords[i].length() > 0) {
				if (i == 0)
					allKeyWords = keyWords[i];
				else
					allKeyWords = allKeyWords + "," + keyWords[i];
			}

		}
		// U.log("KEY:::" + allKeyWords);
		// TODO Auto-generated method stub
		return allKeyWords;
	}

	private static String[] getNextPageLink(String url) throws Exception {
		// TODO Auto-generated method stub
		String html = U.getHTML(url);
		String section = U.getSectionValue(html, "id=\"srchpagination\">",
				"</div>");
		String otherUrl[] = null;
		if (section != null)
			otherUrl = U.getValues(section, "<a href='", "'");
		if (otherUrl == null)
			otherUrl = new String[] { url };

		return otherUrl;
	}

}
