package com.shatam.justdial;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.shatam.utils.U;

public class ExtractYellowPages {
	static int count = 0;

	public static void main(String[] args) throws Exception {
		String url = U.getHTML("http://nagpur.yellowpages.co.in/Doctors");
		String section = U.getHtmlSection(url,
				"<li class=\"serpLftLinkFloat\"><h2><a title=\"Apron",
				"<!--end of Menu -->");
		// U.log(section);
		String values[] = U.getValues(section, "href=\"", "\"");
		String titleValues[] = U.getValues(section, "title=\"", "\"");

		for (int i = 0; i < titleValues.length; i++) {
			GetHospipage("http://nagpur.yellowpages.co.in" + values[i],
					titleValues[i]);
			U.log("Link::" + "http://nagpur.yellowpages.co.in" + values[i]
					+ "::::::" + titleValues[i]);
			//break;

		}

	}

	private static void GetHospipage(String link, String Category)
			throws Exception {

		String html = U.getHTML(link);
		String section = U.getSectionValue(html, "<li class=\"active\">",
				"1</a>");

		if (section != null) {
			int val = Integer.parseInt(U.getSectionValue(section,
					"Page&nbsp;1&nbsp;of&nbsp;", " "));
			String trcid = U.getSectionValue(section, "trc=", "\"");
			// U.log(val);
			for (int i = 2; i < val; i++) {
				allHospis(link + "?trc=" + trcid + "&page=" + i);
				//break;

			}

		}

	}

	private static void allHospis(String listUrl) throws Exception {
		// TODO Auto-generated method stub
		try {
			// U.log(listUrl);
			String htm = U.getHTML(listUrl);

			String section = U.getSectionValue(htm,
					"<div class=\"serpListDn\">",
					"style='display:none' class=\"paidBizBox\">");
			if (section == null)
				section = U
						.getSectionValue(htm, "<div class=\"serp_tp_list \"",
								"class=\"paidBizBox\">");

			if (section != null) {
				String values[] = U.getValues(section, " href=\"", "\"");
				for (String itom : values) {
					if (!itom.contains("void")) {
						U.log(itom);
						addDetails("http://nagpur.yellowpages.co.in" + itom);
						//break;
					}
				}
			}
		} catch (FileNotFoundException f) {
		}
		// U.log(section);
	}

	private static void addDetails(String url) throws Exception {
		try {
			String html = U.getHTML(url);
			U.log("**********************" + count++
					+ "******************************");
			U.log(url);
			String address = U.getSectionValue(html, "<h3 class=\"location\">",
					"</h3>");
			address=address.replaceAll("<a href=.*.?</a>,", "");
			address=address.replace("  ", "");
			U.log(address);

		} catch (IOException e) {
		}
		// TODO Auto-generated method stub

	}

}
