package com.shatam.main;

import java.io.File;

import com.shatam.utils.U;

public class RenameFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path = "/home/shatam-3/Cache/c-rock.com/";
		File location = new File(path);
		int count  = 0;     
		for (File file : location.listFiles()) {
			U.log(file.getName());

		/*if(!file.getName().startsWith("https")){
			file.renameTo(new File(path+"https"+file.getName()));
			count++;
			U.log(file.getName());
			
		}*/
			break;
		}       
		 U.log("Total files:::"+location.listFiles().length);    
		    U.log("Total rename files :::"+count);
	}
	}

