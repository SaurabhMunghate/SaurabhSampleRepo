package com.shatam.main;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;

import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class TestGMapApiWithKey {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String add[] = {"154 Seneca Place","Marshall Township","PA","16046"};
		getGoogleLatLong(add);
	}
	private static String getDomain(String path) throws MalformedURLException{
		String host = new URL(path).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		return ((dot != -1) ? host.substring(0, dot) : host);
	}
	public static String getCache(String path) throws MalformedURLException {

		String Dname = getDomain(path);

		File folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(path);
		fileName = U.getCachePath() + Dname + "/" + fileName;
		return fileName;
	}
	public static String [] getGoogleLatLong(String add[]) throws IOException{
		String addr = add[0] + "," + add[1] + "," + add[2];
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address="
				+ URLEncoder.encode(addr, "UTF-8");
	//	log(addr);
	//	log(U.getCache(addr));
		String html = getGoogleHTML(addr);

		String sec = U.getSectionValue(html, "location", "status");

		String lat = U.getSectionValue(sec, "\"lat\" :", ",");
		if (lat != null)
			lat = lat.trim();
		
		String lng = U.getSectionValue(sec, "\"lng\" :", "}");
		if (lng != null)
			lng = lng.trim();
		
		String latlng[] = {"", ""};
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		if(status.trim().equals("OK")){
			latlng[0] = lat;
			latlng[1] = lng;
			return latlng;
		}else
			return latlng;
	}
	
	public String[] getGoogleAddress(String latLng[]) throws IOException{
		
		String st = latLng[0].trim() + "," + latLng[1].trim();
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+ st;

		String html = getGoogleHTML(addr);
		U.log(html);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		
		if(status.trim().equals("OK")){
			String txt = U.getSectionValue(html, "formatted_address\" : \"", "\"");
			U.log("txt:: " + txt);
			if (txt != null)
				txt = txt.trim();
			txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "").replace("50 Biscayne, 50", "50");
			txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
			txt = txt
					.replaceAll(
							"Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,",
							"");
			String[] add = txt.split(",");
			add[3] = Util.match(add[2], "\\d+");
			add[2] = add[2].replaceAll("\\d+", "").trim();
			
			return add;
		}else{
			return new String[]{"","","",""};
		}
	}
		
	private static boolean isValidFileSize(String path) throws MalformedURLException{
		
		File cacheFile = new File(getCache(path));
		if (cacheFile.exists()){
			if(cacheFile.length() > 400)
				return true;
		}
		return false;
	}
	
	private static String readFile(String fileName) throws IOException {
		return FileUtil.readAllText(fileName);
	}
	/*
	 * List of Google keys
	 */
	private static List<String> googleKeys = new ArrayList<String>(){
		{
			add("AIzaSyDhsO7Ska4s4zUW_68R1n8OhRHJuZP5gm8"); //priti			
			add("AIzaSyBgHZxKFTDWDtBszK4OnSJi2tyd_Td2Wdw"); //sawan
		}
	};
	private static String checkGoogleKeys(String path) throws IOException{
		String pathWithKey = null;	
		int i = 0;
		//check if cache is exist or not
		for(String key : googleKeys){
			i++;
			String tempPath = path + "&key=" + key;
			String temFileName = getCache(tempPath);
			File tempCacheFile = new File(temFileName);
			if (tempCacheFile.exists()){
				if(i != googleKeys.size()){
					if(tempCacheFile.length() < 400)continue;
				}
				pathWithKey = tempPath;
				break;
			}
		}
		
		return pathWithKey;
	}
	
	
	private static String getGoogleHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		
		String fileName = getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists()){
			if(cacheFile.length() > 400){
				U.log(fileName);
				return FileUtil.readAllText(fileName);
			}
		}
		
		//without google key
		String html = extractHtml(path, fileName);
		
		boolean validSize = isValidFileSize(path);
		if(validSize){
			U.log(fileName);
			return html;
		}
		
		//with google key
		String tempPath = checkGoogleKeys(path);
		
		validSize = isValidFileSize(tempPath);
		if(validSize){
			U.log(getCache(tempPath));
			return readFile(getCache(tempPath));
		}
		
		//extract with google key 
		for(String key : googleKeys){
			tempPath = path + "&key=" + key;
			String temFileName = getCache(tempPath);
			html = extractHtml(tempPath, temFileName);
			
			validSize = isValidFileSize(tempPath);
			
			if(validSize){
				U.log(temFileName);
				return readFile(getCache(tempPath));
			}
		}
		
		return null;
	}
	
private static String extractHtml(String path,String fileName) throws IOException{
		
		URL url = new URL(path);
		String html = null;

//		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("70.169.70.88",	80));
		
		final URLConnection urlConnection = url.openConnection();  //proxy

		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language",
					"en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			FileUtil.writeAllText(fileName, html);
			
		} catch (Exception e) {
			U.log(e);
		}
		return html;
	}
}
