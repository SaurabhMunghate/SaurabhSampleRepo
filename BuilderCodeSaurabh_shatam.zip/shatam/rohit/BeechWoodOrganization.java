package com.shatam.rohit;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.b_325_353.ExtractBoulderCreekNeighborhoods;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class BeechWoodOrganization extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver = null;

	public BeechWoodOrganization() throws Exception {
		super("Beechwood Homes", "https://beechwoodhomes.com/");
		LOGGER = new CommunityLogger("Beechwood Homes");
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new BeechWoodOrganization();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Beechwood Homes.csv", a.data().printAll());
	}
	
	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHtmlHeadlessFirefox("https://beechwoodhomes.com/", driver);
		String CommSection=U.getSectionValue(html, "Our Communities</h2>", "Beechwood Retail<hr>");
		String comSecs[] = U.getValues(CommSection, "<h3 class=\"h3",	"</h3>");//"<h3 class=\"mb-2\">");
		U.log("No. of communities:" + comSecs.length);
		for(String comSec:comSecs) {
//			U.log(comSec);
			String comUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
			String comNameSec=U.getSectionValue(comSec, "class=", "/a>");
			if(comNameSec==null) {
				comUrl=U.getSectionValue(html, " data-google-event-action=\"", "/a>").replace(" �", "");
//				U.log(comUrl);
				comUrl=U.getSectionValue(comUrl, "href=\"", "\"");
				comNameSec=U.getSectionValue(comSec, "class=", "/button>");
			}
			String comName=U.getSectionValue(comNameSec, ">", "<").replace(" �", "");
			if(!comUrl.contains("https:"))
				comUrl="https://beechwoodhomes.com"+comUrl;
//			U.log(comUrl+" Name: "+comName);
			LOGGER.AddCommunityUrl("https://beechwoodhomes.com/plainview/retail"+":::::Redirect to plainview retail page");
			addDetails(comUrl,comName,comSec);
//			break;
		}
		
		driver.quit();
		LOGGER.DisposeLogger();
	}
	private void addDetails(String comUrl, String comName, String comSec) throws Exception {
		// TODO Execute for single community
//				if(!comUrl.contains("https://beechwoodhomes.com/meadows"))return;
//		if(!comUrl.contains("https://beechwoodhomes.com/plainview"))return;
				// ----------------- Community Url-----------------------
				U.log("communityURL========================================================> "+comUrl);

//				String comHtml = U.getHTML(comUrl);
				String comHtml = U.getHtml(comUrl, driver);
				
				// ----------------- Community Name-----------------------
				U.log("comName========================================================> "+comName);
				
				// ----------------- Community LOGGER-----------------------
				if (data.communityUrlExists(comUrl)) {
					LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				
				//====================================Note ======================================
				String note=ALLOW_BLANK;
				note= U.getnote(comHtml);
				
				// ----------------- Community Address-----------------------
						String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
						String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
						String geo="False";
//						String[] cityState= {ALLOW_BLANK,ALLOW_BLANK};
						String latLonSec="";
						if(comHtml.contains("nav-contact")) {
							String addUrl=comUrl+"/contact";
							String addressSec="";
							String addHtml=U.getHtml(addUrl, driver).replace("fa font-36 mb-3 fa-map-marker", "fa font-36 fa-map-marker");
						if(addUrl.contains("tidesnyc")||comUrl.contains("the-selby")) {
							if(addUrl.contains("tidesnyc")) {
								addressSec=U.getSectionValue(addHtml, "<p class=\"address\">", "/a>").replace("<br>", " ,");
								latLonSec=U.getSectionValue(addHtml, "https://www.google.com/maps/", "!3m2!");
								U.log(latLonSec);
								latLong[0]=Util.match(latLonSec, "3d\\d{2}.\\d{5,}").replace("3d", "");
								latLong[1]=Util.match(latLonSec, "-\\d{2}.\\d{5,}");
								add=U.getAddress(U.getSectionValue(addressSec, ">", "<"));
							}
							
							if(comUrl.contains("the-selby")) {
								addressSec=U.getSectionValue(comHtml, "<h2 class=\"h3\">Address</h2><p", "/p>").replace("New York", "NY");
//								U.log(addressSec);
								add=U.getAddress(U.getSectionValue(addressSec, ">", "<"));
								latLong=U.getGoogleLatLngWithKey(add);
								geo="true";
							}
							
							
						}else {
							addressSec=U.getSectionValue(addHtml, "<i class=\"fa font-36 fa-map-marker\" aria-hidden=\"true\"></i>", "/a>").replace(" <span class=\"nowrap\">", ", ");
	//						U.log(addressSec);
							addressSec=U.getSectionValue(addressSec, ">", "pan><").replace("New York", "NY");
//							U.log(addressSec);
							if(addressSec.contains("href"))
								addressSec=addressSec.replace(U.getSectionValue(addressSec, "<", ">"), "").replace("<>", "");
								add=U.getAddress(addressSec);
							}
						}
						
						if(add[0]==ALLOW_BLANK && add[2]==ALLOW_BLANK && latLong[0]==ALLOW_BLANK) {
							add[1]="Westhampton Beach";
							add[2]="NY";
							latLong=U.getGoogleLatLngWithKey(add);
							add=U.getGoogleAddressWithKey(latLong);
							geo="true";
							note="Address takenn from city and state";
						}
						if(add[0]!=ALLOW_BLANK && add[2]!=ALLOW_BLANK && latLong[0]==ALLOW_BLANK) {
							latLong=U.getGoogleLatLngWithKey(add);  //laglong given in commContact page but not in PageSource
						}
						U.log("Address ::"+Arrays.toString(add));
						U.log("Latlong ::"+Arrays.toString(latLong));
						

//						U.log("Note========>:::"+note);
//						//------------------Available Home Data-----------------------
//						
//						String homeData="";
//						String homeSec="";
//						String collSec="";

						//-----------allHomesData----------
						String allHomesData = ALLOW_BLANK;
						String homeHtml=ALLOW_BLANK, homeUrl ="";
						String lifestyle=ALLOW_BLANK;
						String navSec = U.getSectionValue(comHtml, "<ul class=\"navbar-nav", "</nav>");
//						U.log(comHtml);
						if(navSec!= null){
							String[] navUrls = U.getValues(navSec, "href=\"", "\"");
//							U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>: "+Arrays.toString(navUrls));
							for(String navUrl : navUrls){
								if(navUrl.contains("/homes")|| navUrl.contains("apartments")){
									homeUrl =  navUrl;
//									U.log("HomeUrl :https://beechwoodhomes.com"+ navUrl);
									homeHtml += U.getHTML("https://beechwoodhomes.com"+navUrl);
								}
								if(navUrl.contains("/lifestyle")){
									homeUrl =  navUrl;
//									U.log("lifestyle :https://beechwoodhomes.com"+ navUrl);
									lifestyle += U.getHTML("https://beechwoodhomes.com"+navUrl);
								}
							}
						}
						if(navSec== null){
							String[] navUrls = U.getValues(comHtml, "href=\"", "\"");
							U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>: "+Arrays.toString(navUrls));
							for(String navUrl : navUrls){
								if(navUrl.contains("/homes")|| navUrl.contains("apartments")){
									homeUrl =  navUrl;
//									U.log("HomeUrl :https://beechwoodhomes.com"+ navUrl);
									homeHtml += U.getHTML("https://beechwoodhomes.com"+navUrl);
								}
								if(navUrl.contains("/lifestyle")){
									homeUrl =  navUrl;
//									U.log("lifestyle :https://beechwoodhomes.com"+ navUrl);
									lifestyle += U.getHTML("https://beechwoodhomes.com"+navUrl);
								}
							}
						}
						if(comUrl.contains("/vanderbilt"))
							homeHtml = U.getHTML("https://vanderbiltli.com/apartments");
						
						if(comUrl.contains("https://www.beechwoodhomes.com/latch"))
							homeHtml = U.getHTML("https://beechwoodhomes.com/latch/homes");
						
						if(comUrl.contains("https://www.beechwoodhomes.com/meadows"))
							homeHtml += U.getHTML("https://beechwoodhomes.com/meadows//homes/qmi/");
						
						if(comUrl.contains("https://www.beechwoodhomes.com/oak-ridge")) {
							
							String[] homeSec = U.getValues(homeHtml, "<li class=\"m-0 model-card", "</li>") ;
							for(String home : homeSec) {
								home = U.getSectionValue(home, "href=\"", "\"");
								String h = U.getHTML("https://beechwoodhomes.com"+home);
								
								String rem = U.getSectionValue(h, "<h2>See our other home styles</h2>", "</html>");
								if(rem!=null)
									h = h.replace(rem, "");
								homeHtml+=h;
							}
						}
//						U.log(homeHtml);
						String HomesSecData="";
						String hmpUrl="";
						String hhHtml="";
						String HomesHtml="";
						if(!comUrl.contains("/marina")) {
						String[] homeUrls=U.getValues(homeHtml, "<h3 class=\"card-title bg", "View Home</a>");
						for(String homeUrln : homeUrls){
//							U.log(homeUrln);
							HomesSecData+=homeUrln;
							if(homeUrln.contains("href"))
								hmpUrl=U.getSectionValue(homeUrln, "href=\"", "\"");
//							U.log(hmpUrl);
							hhHtml = U.getHTML("https://beechwoodhomes.com"+hmpUrl);
							HomesHtml+=U.getSectionValue(hhHtml, "<h1 class=\"m-0\">", "</span></p></div");
//							allHomesData += U.getHTML("https://beechwoodhomes.com"+hmpUrl);
							allHomesData += U.getSectionValue(hhHtml, "<h1 class=\"m-0\">", "</span></p><div")+U.getSectionValue(hhHtml, "<div class=\"main-container", "See our other home styles</h2>")+U.getSectionValue(hhHtml, "<div class=\"container\">", "</div></div></div></div></div>");
							if(comUrl.contains("/smithtown"))allHomesData+=homeHtml;
//							
						}
						}
//						allHomesData = allHomesData.replace(" Level<", " story <");
					if(!comUrl.contains("/vanderbilt"))
						homeHtml=U.getSectionValue(homeHtml, "<h1 class=\"m-0\">", "</span></span></li>");
//							U.log(comSec);
						
							// ----------------- Community Sqft-----------------------
							String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
							String[] sqft = U.getSqareFeet(comHtml+allHomesData+HomesSecData+homeHtml, "<td class=\"align-middle living\">\\d,\\d{3}</td>|<p>\\d{3,4} � \\d{3,4} Sq. Ft.|\\d,\\d{3} <span class=\"nowrap\">Sq Ft", 0);
							minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
							maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
							U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
							
							
							// ----------------- Community Price-----------------------
							String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
							String price[] = U.getPrices(comHtml+allHomesData+HomesSecData+homeHtml, "Priced From \\$\\d,\\d{3},\\d{3}|Priced From \\$\\d{3},\\d{3}", 0);  //|Starting From \\$\\d{3},\\d{3}
							minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
							maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
							U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
//						
//						
//						
							// ----------------- Community Data-----------------------
							String propType = ALLOW_BLANK;
							String propStatus = ALLOW_BLANK;
							String drvPropType = ALLOW_BLANK;
							String commType = ALLOW_BLANK;
							
							//============================================ Property Type =========================================================================
							propType=U.getPropType(comHtml+allHomesData+homeHtml);
				
							U.log("PType========>:::"+propType);
							
							//=========== Community Type ========================
//							comHtml=comHtml.replace("", "");
							commType = U.getCommType(comHtml+comSec);
							
							U.log("commType========>:::"+commType);
							//============================================ dProp Type =========================================================================
							drvPropType=U.getdCommType(comHtml+allHomesData+homeHtml);
				
							U.log("PdrvType========>:::"+drvPropType);
							
							//====================================Property Status ======================================
							String remsec="";
							remsec=U.getSectionValue(comHtml, "<div class=\"corp-footer text-center\">", "2021 Beechwood Homes</div>");
							if(remsec!=null)
								comHtml=comHtml.replace(remsec, "");
							comHtml=comHtml.replaceAll("Quick Move-In Ready Homes Available|Our Sales Galleries are now open|Quick Move-In Homes|New Restaurant Coming Soon|New Restaurant coming soon", ""); 
							propStatus=U.getPropStatus(comHtml+comSec);

//							U.log(HomesHtml);
//							U.log(Util.matchAll(allHomesData, "[\\w\\s\\W]{30}Quick Move[\\w\\s\\W]{30}", 0));
							if(HomesHtml.contains("Quick Move-In Home ")) {  
								if(propStatus.length()<4) {
									propStatus="Quick Move-in Homes";
								}else {
									propStatus=propStatus+", Quick Move-in Homes";
								}
								
							}
							//because status present in  https://beechwoodhomes.com/quick-move-in/#all
							if(comUrl.contains("/meadows")||comUrl.contains("/smithtown"))propStatus="Quick Move-in Homes";
							U.log("PStatus========>:::"+propStatus);
							// ----------------- Community Data-----------------------
							data.addCommunity(comName, comUrl, commType);
							data.addLatitudeLongitude(latLong[0], latLong[1], geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0], add[1], add[2], add[3]);
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(propType, drvPropType);
							data.addPropertyStatus(propStatus);
							data.addNotes(note);	
		
	}

	

}
