package com.shatam.rohit;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.httpclient.util.EncodingUtil;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.james.mime4j.codec.EncoderUtil.Encoding;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractVanDaeleHomes extends AbstractScrapper {
	static String BASEURL = "https://www.vandaele.com";
	WebDriver driver = null;
	static int j=0;
	CommunityLogger LOGGER;
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractVanDaeleHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Van Daele Homes.csv", a.data()
				.printAll());
	}

	public ExtractVanDaeleHomes() throws Exception {

		super("Van Daele Homes", BASEURL);
		LOGGER = new CommunityLogger("Van Daele Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
//		String html = U.getHTMLwithProxy("https://www.vandaele.com/");
		String html = U.getHTML("https://www.vandaele.com/");
		//String region = U.getSectionValue(html, "Communities</span></a><ul class=\"sub-menu\">",		"<a  href=\"#\">");
		//U.log(region);
		String regionurls[] = U.getValues(html, "<div class='fusion-megamenu-title'><a href=\"https://www.vandaele.com/", "\"");
		U.log(regionurls.length);
		for (String regionurl : regionurls) {
			U.log("regionurl::::::::;"+regionurl+":::::::::::::::::::");
			String homeFinderUrl="https://www.vandaele.com/"+regionurl+"homefinder/";
			addregionDetails(regionurl,homeFinderUrl);
}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	public void addregionDetails(String regionurl,String homeFinderUrl) throws Exception {
		String regHtml = U.getHTML("https://www.vandaele.com/wp-json/wp/v2/"+regionurl+"/?per_page=100");
		U.log("https://www.vandaele.com/wp-json/wp/v2/"+regionurl+"/?per_page=100");
		regHtml = org.apache.commons.lang.StringEscapeUtils.unescapeJava(regHtml);
		//U.log(regHtml);
		U.log("FinderUrl: "+homeFinderUrl);
		String comSections[] = U.getValues(regHtml,	"\"slug\":\"","\"_links\":{\"");
		U.log(comSections.length);
		for (String comSec : comSections) {
			//U.log("%%%%"+comSec);
			String url = U.getSectionValue(comSec, "\"link\":\"", "\"");
			//U.log("url::::::::::"+url);
			addCommunityDetails(url, comSec, homeFinderUrl);
//			break;
		}

	}

	public void addCommunityDetails(String cUrl, String comData, String homeFinderurl) throws Exception {
		//TODO ::
//		if(!cUrl.contains("https://www.vandaele.com/southern_california/community/ridgepointe-at-deerlake-ranch/"))return;
		
		
		if (data.communityUrlExists(cUrl)){
			LOGGER.AddCommunityUrl(cUrl+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(cUrl);
		
		String comHtml = U.getHTML(cUrl);
		U.log("cUrl::::::::::"+cUrl);
		U.log(U.getCache(cUrl));
		
//		U.log(comData);
		
		//------------community name------------------
		String comName = U.getSectionValue(comData, "title\":{\"rendered\":\"", "\"");
		U.log("comName:::::::"+comName);
		
		String floorUrl= U.getSectionValue(comHtml, "<li class=\"\"><a href=\"https://www.vandaele.com/floor-plans/", "\"");
//		U.log("comData : "+comData);
		
				
		String floordata = U.getHTML("https://www.vandaele.com/floor-plans/"+floorUrl);
		
		
//==		
		//------------------HomeFinder data by request post method----------------
				String HomeFinderHtml="";
				if(homeFinderurl.contains("southern")) {
					HomeFinderHtml=U.sendPostRequestAcceptJson("https://twix.newhomesource.com/Homes/Default", "{\"request\":{\"PartnerId\":765,\"SiteUrl\":\"vandaelehomessoca\",\"State\":\"\",\"MarketIds\":\"\",\"Cities\":\"\",\"CommunityIds\":\"\",\"Type\":\"Default\",\"BrandIds\":\"\",\"Facets\":{\"NumberOfBedrooms\":-1,\"NumberOfBathrooms\":-1,\"NumberOfGarages\":-1,\"MinimumPrice\":-1,\"MaximumPrice\":-1,\"Builder\":0,\"Community\":0,\"Builders\":[4423]}}}");
				}
				else {
					HomeFinderHtml=U.sendPostRequestAcceptJson("https://twix.newhomesource.com/Homes/Default", "{\"request\":{\"PartnerId\":766,\"SiteUrl\":\"vandaelehomesnca\",\"State\":\"\",\"MarketIds\":\"\",\"Cities\":\"\",\"CommunityIds\":\"\",\"Type\":\"Default\",\"BrandIds\":\"\",\"Facets\":{\"NumberOfBedrooms\":-1,\"NumberOfBathrooms\":-1,\"NumberOfGarages\":-1,\"MinimumPrice\":-1,\"MaximumPrice\":-1,\"Builder\":0,\"Community\":0,\"Builders\":[4423]}}}");
				}
//				U.log(HomeFinderHtml);
				String finderPriceSec="";
				String[] finderSecs=U.getValues(HomeFinderHtml, "{\"ResultFacets", "},");
				U.log(finderSecs.length);
				for(String finderSec:finderSecs) {
//					U.log(finderSec);
					if(finderSec.contains(comName)) {
						finderPriceSec+=finderSec;
					}
				}
				U.log("========"+finderPriceSec);
//==
		//------------Square Feet-------------------------
		
		String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
		
		String[] sqFt = U.getSqareFeet(comHtml+comData+floordata, "baths and \\d,\\d{3} square feet|approx\\. \\d,\\d{3} square feet|approximately \\d{1},\\d{3} to \\d{1},\\d{3} square feet|sf_range_[max|min]*\":\"\\d,\\d+|approximately \\d,\\d+ square feet", 0);
		
		minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("minSqFt :" + minSqFt + " maxSqFt:" + maxSqFt);
		
		//-----------Prices-------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comData = comData.replace(" $900,000's", " $900,000").replace("$1 Millions", "$1,000,000 Millions").replace("$1.3", "$1,300,000").replace("mid $700's", "$700,000").replaceAll("\\$400s|\\$400's", "\\$400,000").replaceAll("00’s|00's", "00,000");//.replace("$900,000", "");
		//U.log("#$#$ "+comData+"#$#$");
		//U.log(comData);
		
		String sitePlanUrl = U.getSectionValue(comHtml, "https://www.vandaele.com/site-plan/", "\"");
		String siteHtml = U.getSectionValue(U.getHTML("https://www.vandaele.com/site-plan/"+sitePlanUrl),"<div id=\"availability-list-outer\">","<!-- END availability-list -->");
		
		String[] price = U.getPrices(comHtml + comData + siteHtml+finderPriceSec, "PriceRange\":\"\\$\\d,\\d{3},\\d{3}\"|PriceRange\":\"\\$\\d{3},\\d{3}\"|<h4>Price: \\$\\d,\\d{3},\\d{3}</h4>|From the Low \\$\\d{1},\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|low \\$\\d{1},\\d{3},\\d{3}|\\$\\d+,\\d+|From the \\$\\d,\\d{3},\\d{3}|pricing_info_[short|long]*\":\"\\d{3},\\d{3}\"|low \\$\\d{3},\\d{3}|(High|Mid) \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
		
		//-------feature data-----------
		String feaSec = ALLOW_BLANK;
		String feaUrl = Util.match(comHtml, "<a href=\"(.*?)\">Features",1);
		//U.log(feaUrl);
		if(feaUrl != null){
			String feaHtml = U.getHTML(feaUrl);
			//U.log(U.getCache(feaUrl));
			feaSec = U.getSectionValue(feaHtml, "<span class=\"entry-title\" ", "<div class=\"disclaimer");
			if(feaSec!=null)
			feaSec = feaSec.replace("carriage style garage doors", "");
		}
		
		//------virtual toour-----
        String nowSellingSection[] = U.getValues(comHtml, "Now Selling</span></a>", "Coming Soon</span></a>");

		String virTourSec = ALLOW_BLANK;
		String virTourUrl = Util.match(comHtml, "<h3 class=\"title-heading-center\" data-fontsize=\"22\" data-lineheight=\"27\"><a href=\"(.*?)\"",1);
		if(virTourUrl !=null){
		String virHtml = U.getHTML(virTourUrl);
		virTourSec = U.getSectionValue(virHtml, "carousel-inner feature_slider", "<!--");
		}
		//----------remove sectiom-----------
		String remFooter =U.getSectionValue(comHtml, "<footer id=\"footer\"", "</html>");
		if(remFooter!=null){
			comHtml = comHtml.replace(remFooter, "");
		}
		String remNavigation  = U.getSectionValue(comHtml, "<nav class=\"fusion-main-menu", "Toggle mobile menu\"></a>");
		if(remNavigation!=null){
			comHtml = comHtml.replace(remNavigation, "");
		} 
		
		//-----------community type--------------
		comHtml=comHtml.replace("resort-inspired recreation", "resort-class lake living");
        String comType = U.getCommunityType(comHtml + comData); 
        U.log("comType: "+comType);
		//-----------property type--------------------
       // U.log(comHtml);
        String propType = U.getPropType(comHtml + comData + feaSec);
//        U.log("mm"+Util.matchAll(comHtml + comData + feaSec, "[\\w\\s\\W]{30}Colonial & Farmhouse[\\w\\s\\W]{30}", 0));
        U.log("propType: "+propType);
		//U.log(comData);
		//--------derived type------------------------
        comData=comData.replaceAll("Two & Three-Story", " 2 Story and 3 Stories ");
        String dType = U.getdCommType((comHtml + comData +virTourSec).replaceAll("Floor|floor|Rancho Cucamonga", ""));
        U.log("dType: "+dType);
		//---------Status-------------------------
        
        

        
        String remove = "PRESALE OPENING EARLY 2021|available please contact|fusion-megamenu-bullet\"></span>Now Selling</sp|Models Open - Now Selling!</div>|</span>Coming|information on our final home|Pricing coming|Rate Now|REDUCTIONS ON MOVE-|message\">MOVE-IN READY|promo\":\"MOVE-IN READY";
        comHtml= comHtml.replace("QUICK MOVE-INS NOW SELLING", " NOW SELLING");
        comData = comData.replace("QUICK MOVE-INS NOW SELLING", " NOW SELLING").replaceAll("temporarily closed and only one home remains", "");
        
        String propStatus = U.getPropStatus((comHtml + comData).replaceAll(remove, ""));
        U.log("propStatus: "+propStatus);
        
        for(String nowSellingSec : nowSellingSection){
   //     	U.log("nowSellingSec==>"+nowSellingSec);
        	
        	if(!propStatus.contains("Now Selling") && nowSellingSec.contains(cUrl)){
        		if(propStatus == ALLOW_BLANK) propStatus = "Now Selling";
        		if(propStatus != ALLOW_BLANK) propStatus += ", Now Selling";
        		break;
        	}
        }
        //--------notes-----------
//        U.log(comData);
        String notes = U.getnote(comHtml + comData);
        U.log("notes: "+notes);
		
		//-----------------Address && latlng---------------------------
        String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
        String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
        String geo= "FALSE";
   
        latLng[0] = U.getSectionValue(comData, "\"lat\":\"", "\"");
        latLng[1] = U.getSectionValue(comData, "\"lng\":\"", "\"");
        U.log("Latlng : " + Arrays.toString(latLng));
        
        
        String addSec = U.getSectionValue(comData, "sales_address\":\"", "\"");
    ///    U.log("addSec : "+addSec);
        if(addSec != null){
        	addSec = addSec.replace("<br />", ",")
        			.replaceAll("\\| Near 6th Street (and|&) Milliken Avenue", "").trim();
        	add = U.getAddress(addSec);
        }
        U.log("add : " + Arrays.toString(add));
        
        if((add[0].length()<4 || add[3].length()<4 )&& latLng[0]!=null){
        	add = U.getAddressGoogleApi(latLng);
        	if(add == null) add = U.getAddressHereApi(latLng);
        	geo = "TRUE";
        }
        
        if(latLng[0]==null && add[0].length()>4){
        	latLng = U.getlatlongGoogleApi(add);
        	if(latLng == null) latLng = U.getlatlongHereApi(add);
        	geo = "TRUE";
        }
        //if(cUrl.contains("https://www.vandaele.com/northern_california/community/latitude-at-river-islands/"))propStatus += ", Now Selling";
        if(cUrl.contains("https://www.vandaele.com/northern_california/community/summer-house-at-river-islands/")
        		|| cUrl.contains("https://www.vandaele.com/northern_california/community/castaway-at-river-islands/"))minPrice = ALLOW_BLANK;
        if(cUrl.contains("https://www.vandaele.com/southern_california/community/enliven-at-the-resort"))
        	propStatus=propStatus.replace(", Now Selling", "");
        
        if(cUrl.contains("https://www.vandaele.com/southern_california/community/ridgepointe-at-deerlake-ranch")) {
//        	maxPrice="$1,525,990"; //present in homefinder but no in pagesource
        	propStatus=propStatus.replace("Coming Soon,", "");
        	
        }
        if(cUrl.contains("https://www.vandaele.com/southern_california/community/alicante"))
        	propStatus=propStatus.replace("Sold Out,", "");
        comName = comName.replace("Ridgepointe at Deerlake Ranch Test", "Ridgepointe at Deerlake Ranch in Chatsworth");
		data.addCommunity(comName, cUrl, comType);
		data.addAddress(add[0].replace(",", ""), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addNotes(notes);
	

	}
}
