package com.shatam.rohit;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.b_081_100.ExtractProvidencegroup;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class GreenBrickPartners_TheProvidenceGroup extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver =null;
	public GreenBrickPartners_TheProvidenceGroup() throws Exception {
		super("Green Brick Partners - The Providence Group", "https://theprovidencegroup.com/");
		LOGGER = new CommunityLogger("Green Brick Partners - The Providence Group");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new GreenBrickPartners_TheProvidenceGroup();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Green Brick Partners - The Providence Group.csv", a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String[] latlng= {ALLOW_BLANK,ALLOW_BLANK};
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String html = U.getHtml("https://theprovidencegroup.com/new-homes/", driver);
//		String[] comSecs=U.getValues(html, "<div class=\"row justify-content-between align-items-start\">", "</p></a></div>");
		String[] comSecs=U.getValues(html, "<div class=\"item oi-map-item location-map-item", "</p></a></div>");
		//<div class=\"col-12 pt-2 pb-1 align-self-start\">
		U.log(comSecs.length);
//		String[] latlongSecs=U.getValues(html, "<div class=\"item oi-map-item location-map-item", "");
		int c=0;
		for(String comSec:comSecs) {
//			U.log("======"+comSec);
			c++;
			String comName=U.getSectionValue(comSec, "<div class=\"col model-name\">", "</div>");
			String comUrl=U.getSectionValue(comName, "href=\"", "\"");
			comName=U.getSectionValue(comName, ">", "<");
			comUrl="https://theprovidencegroup.com"+comUrl;
//			U.log(c+"== "+comUrl+" name: "+comName);
			latlng[0]=U.getSectionValue(comSec, "data-latitude=\"", "\"");
			latlng[1]=U.getSectionValue(comSec, "data-longitude=\"", "\"");
			String address=U.getSectionValue(comSec, "<div class=\"model-address\"><span>", "</span>").replace("<br />", ",");
			add=U.getAddress(address);
			comSec=comSec.replace("0's", "0,000");
			addDetails(comUrl,comName,comSec,html,latlng,add);
//			break;
		}
		driver.close();
		driver.quit();
		LOGGER.DisposeLogger();
		
	}

	private void addDetails(String comUrl, String comName, String comSec, String regHtml, String[] latlng, String[] add) throws Exception {
		//TODO : Extraction for single community 
		//if(!comUrl.contains("https://theprovidencegroup.com/new-homes/ga/alpharetta/central-park-at-deerfield-township/6808/"))return;
	//	if(!comUrl.contains("https://theprovidencegroup.com/new-homes/ga/canton/idylwilde/6816/"))return;
	//	if(!comUrl.contains("https://theprovidencegroup.com/new-homes/ga/atlanta/pratt-stacks-ii/8475/")) return;
		
				// ----------------- Community Url-----------------------
				U.log("communityURL========================================================> "+comUrl);

				String comHtml = U.getHtml(comUrl, driver);
				
				// ----------------- Community Name-----------------------
				U.log("comName========================================================> "+comName);
				
				// ----------------- Community LOGGER-----------------------
				if (data.communityUrlExists(comUrl)) {
					LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				
				//====================================Note ======================================
				String note=ALLOW_BLANK;
				note= U.getnote(comHtml);
				
				// ----------------- Community Address-----------------------
				String geo="False";
				U.log("Address:"+Arrays.toString(add));
				U.log("Latlong:"+Arrays.toString(latlng));
				

//				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
				
				String homeData="";
				String homeHtml="";
				String collSec="";
				if(comHtml.contains(">Available Homes</div>")) {
					String[] homeSecs=U.getValues(comHtml, "<div class=\"px-0 card ", "</div><div class=\"col text");
//					String[] homeSecs=U.getValues(comHtml, "<div class=\"px-0 card spec-card swiper-card\">", "</div><div class=\"col text-uppercase ls-1 home-type font-small\">");
					
					U.log(homeSecs.length);
					for(String homeSec:homeSecs) {
					//	U.log("HOMESECTION : "+homeSec);
						collSec+=homeSec;
						String homeurl="https://theprovidencegroup.com"+U.getSectionValue(comSec, "href=\"", "\"");
					//	U.log(homeurl);
						homeHtml=U.getHTML(homeurl);
						homeHtml=U.getSectionValue(homeHtml, "<div id=\"content\">", "<div class=\"section-title text-gray pb-5 pb-lg-0\">");
	//					U.log(homeHtml);
						homeData+=homeHtml;
//						break;
					}
				}	
				comHtml=U.getSectionValue(comHtml, "<div id=\"content\">", "<div class=\"section-title text-gray pb-5 pb-lg-0\">");
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml+homeData+comSec, ">\\d,\\d{3}-\\d,\\d{3}</span>|>\\d,\\d{3}</span>", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				
				// ----------------- Community Price-----------------------
				comHtml=comHtml.replace("0's", "0,000");
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String price[] = U.getPrices(comHtml+homeData+comSec, ">From the \\$\\d{3},\\d{3}</div>|>From \\$\\d{3},\\d{3}</p>|>\\$\\d{3},\\d{3}</div>|>\\$\\d{3},\\d{3}</span>", 0);  
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
//			
//			
				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
		 		
				String inspectData = U.getSectionValue(comHtml, "lg-6 no-gutters", "100 position");

				if(inspectData != null)
		 			U.log("data in inspect: "+inspectData);
				propType=U.getPropType(comHtml+homeData+inspectData);
					
				if(comUrl.contains("https://theprovidencegroup.com/new-homes/ga/canton/idylwilde/6816")) { 
					propType="Single Family, Townhomes, Farmhouse Style Homes";
					String comPageData = U.getSectionValue(comHtml, "Mason main", "");
					comPageData = "Mason main Townhomes and Spacious Loft";
					propType=U.getPropType(comHtml+homeData+inspectData+comPageData);
				}
				if(comUrl.contains("https://theprovidencegroup.com/new-homes/ga/alpharetta/central-park-at-deerfield-township/6808/") || comUrl.contains("https://theprovidencegroup.com/new-homes/ga/alpharetta/atley/6806/")) {
					String line="leading to a great covered patio";
					propType=U.getPropType(comHtml+homeData+line);
				}
				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
//				comHtml=comHtml.replace("", "");
				 
				comHtml.replace("TownhomesSwim Club CommunityEvanshire", "Swim Community Evanshire");
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				String storySec[] = U.getValues(comHtml, "Stories\"", "</span>");
				String stories=ALLOW_BLANK;
				for(String s:storySec) {
				 String st = s.replaceAll("<span>3.0", "Three Story")
						 	.replaceAll("<span>1.0", "One Story")
						 	.replaceAll("<span>2.0", "two Story");
				 stories += st;
				 U.log(st);
				}
				drvPropType=U.getdCommType(comHtml+homeData+stories);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
//				String comStatHtml=U.getSectionValue(comHtml, "<div id=\"content\">", ">Get Directions</a>");
				comHtml=comHtml.replaceAll("> \\d Available Homes</div>", "")
						.replaceAll("Coming Soon - \\d{4}!", "Coming Soon - 2022!");
				String regionpageStatus[] = U.getValues(regHtml,"model-flag bg-blue-cyan", "</div>");
				String statusRegion = ALLOW_BLANK;
				for(String st:regionpageStatus) {
					String si = st.replaceAll("COMING\\s\\w+\\s\\d{4}", "COMING JANUARY 2022");
					statusRegion += si;
				}
				inspectData = inspectData.replace("updates on new phases", "New Phase Coming Soon")
										.replace("Limited Spring Move In Opportunities", "Limited Opportunities")
										.replace("50% Sold Out in Phase I!", "50% Sold Out in Phase I");
				inspectData = inspectData.replace("Ask About Our New Home Sites Released in our Final Phase!", "New Home Sites Released in our Final Phase");
				propStatus=U.getPropStatus(comHtml+comSec+inspectData);
				
				if(propStatus.contains("Coming 2022, Coming Soon"))
					propStatus = "Coming Soon 2022";
				if(comUrl.contains("https://theprovidencegroup.com/new-homes/ga/suwanee/ellington/6811/"))
					propStatus = "Now Selling";
				if(comUrl.contains("https://theprovidencegroup.com/new-homes/ga/johns-creek/bellmoore-park/6807/"))
					propStatus = propStatus.replace("Limited Opportunities, Coming January 2022, Coming 2022, Sold Out, Coming Soon", "Limited Opportunities, New Phase Coming Soon");
				if(comUrl.contains("https://theprovidencegroup.com/new-homes/ga/atlanta/pratt-stacks-ii/8475/") || comUrl.contains("https://theprovidencegroup.com/new-homes/ga/alpharetta/ecco-park/6810/")) {
					propStatus=U.getPropStatus(comHtml+comSec+inspectData+statusRegion);
				}

				
		/*
		 * if(comUrl.contains(
		 * "https://theprovidencegroup.com/new-homes/ga/alpharetta/ecco-park/6810/") &&
		 * propStatus.contains("Coming Soon 2022")) propStatus =
		 * "Coming Soon 2022, Sold Out";
		 */

//				U.log(HomesHtml);
//				U.log(Util.matchAll(allHomesData, "[\\w\\s\\W]{30}Quick Move[\\w\\s\\W]{30}", 0));
//				if(HomesHtml.contains("Quick Move-In Home ")) {  
//					if(propStatus.length()<4) {
//						propStatus="Quick Move-in Homes";
//					}else {
//						propStatus=propStatus+", Quick Move-in Homes";
//					}
//					
//				}
				//because status present in  https://beechwoodhomes.com/quick-move-in/#all
//				if(comUrl.contains("/meadows")||comUrl.contains("/smithtown"))propStatus="Quick Move-in Homes";
				U.log("PStatus========>:::"+propStatus);
				
		
		
		  
		
		 
				// ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latlng[0], latlng[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);	
		
	}

	

}
