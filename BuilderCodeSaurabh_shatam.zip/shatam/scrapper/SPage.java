/*package com.shatam.scrapper;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.WebClient;
import com.shatam.utils.Util;

public class SPage {

    public static String html(ChromeDriver driver, WebElement element) {

        JavascriptExecutor je = (JavascriptExecutor) driver;
        String contents = (String) je.executeScript("return arguments[0].innerHTML;", element);
        return contents;
    }


    public static void setHtml(ChromeDriver driver, WebElement element, String html) {

        JavascriptExecutor je = (JavascriptExecutor) driver;
        je.executeScript("arguments[0].innerHTML='" + html + "';", element);
    }


    public static WebElement bySelector(ChromeDriver driver, String selector) {

        try {
            return driver.findElement(By.cssSelector(selector));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            return null;
        }
    }


    public static void waitForSelector(final ChromeDriver driver, final String[] selectors,
            final String lookForString) {

        Util.log("waitForSelector " + selectors[0] + " on " + driver.getCurrentUrl());

        (new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver d) {

                try {
                    WebElement table = null;

                    for (String selector : selectors) {
                        table = bySelector(driver, selector);
                        if (table != null)
                            break;
                    }
                    if (table == null) {
                        Util.log("selectors "+selectors.length+" not found");
                        return false;
                    }

                    //Util.log("Found id element:" + table.getTagName() + " - " + table.getText());

                    String html = SPage.html(driver, table);
                    //Util.log(html);
                    boolean b = html.contains(lookForString);
                    //if (!b)
                    Util.log(lookForString + ":" + b);
                    return b;

                } catch (Exception ex) {
                    Util.log("Catching exception in my try catch");
                    ex.printStackTrace();
                }
                return false;

            }
        });
    }// waitFor()    


    public static void waitFor(final ChromeDriver driver, final String lookForId, final String lookForString) {

        Util.log("Waiting for id " + lookForId + " on " + driver.getCurrentUrl());
        (new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver d) {

                WebElement table = driver.findElementById(lookForId);
                if (table == null) {
                    Util.log(lookForId + " not found");
                    return false;
                }
                String html = SPage.html(driver, table);
                //Util.log(html);
                boolean b = html.contains(lookForString);
                Util.log(lookForString + ":" + b);
                return b;
            }
        });
    }// waitFor()


    public static void waitFor(final HtmlUnitDriver driver, final String id) {

        (new WebDriverWait(driver, 120)).until(new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver d) {

                WebElement table = driver.findElementById(id);
                return table != null;
            }
        });
    }// waitForGridLoad()


    public static ChromeDriver getChromeDriver(String url) throws InterruptedException {

        ChromeDriver driver = new ChromeDriver();
        Logger logger = Logger.getLogger("");
        logger.setLevel(Level.OFF);

        Thread.sleep(1 * 1000);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(url);
        Thread.sleep(2 * 1000);
        return driver;
    }


    public static HtmlUnitDriver getDriver(String url) throws InterruptedException {

        HtmlUnitDriver driver = new HtmlUnitDriver() {

            @Override
            protected WebClient modifyWebClient(WebClient client) {

                WebClient webClient = super.modifyWebClient(client);
                webClient.setJavaScriptEnabled(true);
                webClient.setThrowExceptionOnScriptError(false);
                webClient.setCssEnabled(true);
                webClient.setRedirectEnabled(true);

                return webClient;
            };
        };
        Logger logger = Logger.getLogger("");
        logger.setLevel(Level.OFF);

        Thread.sleep(5 * 1000);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(url);

        driver.setJavascriptEnabled(true);

        return driver;
    }


    public static WebElement get(ChromeDriver driver, String id) {

        WebElement ele = null;
        ele = driver.findElementById(id);

        if (ele != null)
            return ele;

        try {
            ele = driver.findElementByName(id);
        } catch (Exception ex) {
        }
        return ele;
    }


    public static void sleep(HtmlUnitDriver driver, int seconds) {

        try {
            (new WebDriverWait(driver, seconds)).until(new ExpectedCondition<Boolean>() {

                public Boolean apply(WebDriver d) {

                    return d.getTitle().toLowerCase().startsWith("cheese!");
                }
            });
        } catch (Exception ex) {
        }
    }


    public static WebElement getElementsByAttr(WebElement parentEle, String tagName, String attName,
            String attValue) {

        attValue = attValue.trim().toLowerCase();
        for (WebElement tagEle : parentEle.findElements(By.tagName(tagName))) {

            String v = tagEle.getAttribute(attName);
            if (v == null)
                continue;
            v = v.trim().toLowerCase();

            if (v.contains(attValue))
                return tagEle;
        }//for tagEle

        return null;

    }//getElementsByAttr()


    public static void goBack(ChromeDriver driver) {

        JavascriptExecutor je = (JavascriptExecutor) driver;
        je.executeScript("history.go(-1);");
    }
}
*/