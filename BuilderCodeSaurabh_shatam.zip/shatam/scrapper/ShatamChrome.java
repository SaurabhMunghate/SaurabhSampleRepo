package com.shatam.scrapper;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.utils.Util;


public class ShatamChrome {

    private ChromeDriver        driver   = null;

    //Singleton instance
    private static ShatamChrome instance = null;


    public synchronized static ShatamChrome getInstance() throws Exception {

        if (instance == null)
            instance = new ShatamChrome();
        return instance;
    }


    private ShatamChrome() throws Exception {

        driver = new ChromeDriver();
        Logger logger = Logger.getLogger("");
        logger.setLevel(Level.OFF);

        Thread.sleep(1 * 1000);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("about:blank");
        Thread.sleep(2 * 1000);
        //return driver;
    }


    public List<WebElement> getAll(String selector) {

        List<WebElement> allLinks = driver.findElements(By.cssSelector(selector));
        return allLinks;
    }


    public WebElement getOne(String selector) {

        return driver.findElement(By.cssSelector(selector));
    }


    public List<WebElement> byOutsideInside(String outsideSelector, String insideSelector) {

        WebElement outerEle = driver.findElement(By.cssSelector(outsideSelector));
        List<WebElement> allLinks = outerEle.findElements(By.cssSelector(insideSelector));

        Util.log("for '" + outsideSelector + "' found " + allLinks.size() + " inside selectors "
                + insideSelector);
        return allLinks;
    }


    public WebElement byAny(String[] selectors) {

        for (String selector : selectors) {

            WebElement table = null;
            try {
                table = getOne(selector);
            } catch (Exception e) {
            }
            if (table != null)
                return table;
        }//for selector

        return null;
    }


    public String getHtml(WebElement element) {

        JavascriptExecutor je = (JavascriptExecutor) driver;
        String contents = (String) je.executeScript("return arguments[0].innerHTML;", element);
        return contents;
    }
    public String getHtml() {
        WebElement element = getOne("html");
        JavascriptExecutor je = (JavascriptExecutor) driver;
        String contents = (String) je.executeScript("return arguments[0].innerHTML;", element);
        return contents;
    }

    public WebElement getLastItemWaitedOn() {

        return lastItemWaitedOn;
    }

    private WebElement lastItemWaitedOn = null;


    public void wait(final String selector) throws InterruptedException {

        wait(new String[]{selector}, "");
    }


    public void wait(final String selector, String containsString) throws InterruptedException {

        wait(new String[]{selector}, containsString);
    }


    public void wait(final String[] selectors, final String containsString) throws InterruptedException {

        Util.log("waitForSelector " + selectors[0] + " on " + driver.getCurrentUrl());

        (new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver d) {

                try {
                    lastItemWaitedOn = byAny(selectors);

                    if (lastItemWaitedOn == null) {
                        Util.log(selectors[0] + " not found");
                        return false;
                    }

                    //Util.log("Found id element:" + table.getTagName() + " - " + table.getText());

                    String html = getHtml(lastItemWaitedOn);

                    boolean b = html.contains(containsString);
                    if (!b)
                        Util.log("html: " + html);
                    Util.log(containsString + ":" + b);
                    
                    if (!b){
                        //Thread.sleep(1000);
                    }
                    return b;

                } catch (Exception ex) {
                    Util.log("Catching exception in my try catch");
                    ex.printStackTrace();
                }
                return false;

            }
        });

    }


    public void open(String url) throws InterruptedException {

        driver.get(url);
        Thread.sleep(2*1000);
    }
 

    public void setHtml(WebElement element, String html) {

        JavascriptExecutor je = (JavascriptExecutor) driver;
        je.executeScript("arguments[0].innerHTML='" + html + "';", element);


    }


    public void close() throws InterruptedException {


        driver.close();
        Thread.sleep(3000);        
    }
}
