package com.shatam.utils;

import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

import au.com.bytecode.opencsv.CSVWriter;



public class CommunityList {

    public static final String ALLOW_BLANK        = "-";
    private ArrayList<String>  communityUrls      = new ArrayList<String>();
    private ArrayList<String>  communityNames     = new ArrayList<String>();
    private ArrayList<String>  CommunityType      = new ArrayList<String>();
    
    private ArrayList<String>  addressList        = new ArrayList<String>();
    private ArrayList<String>  cityList           = new ArrayList<String>();
    private ArrayList<String>  stateList          = new ArrayList<String>();
    private ArrayList<String>  zipList            = new ArrayList<String>();

    private ArrayList<String>  latitudeList       = new ArrayList<String>();
    private ArrayList<String>  longitudeList      = new ArrayList<String>();
    
    private ArrayList<String>  propertyTypeList   = new ArrayList<String>();
    private ArrayList<String>  DERIVED_PROPERTY_TYPE   = new ArrayList<String>();
   //DERIVED_PROPERTY_TYPE
    private ArrayList<String>  propertyStatusList = new ArrayList<String>();
    
   // private ArrayList<String>  priceList          = new ArrayList<String>();
    private ArrayList<String>  MinPrice           = new ArrayList<String>();
    private ArrayList<String>  MaxPrice           = new ArrayList<String>();
    //private ArrayList<String>  squareFeetList     = new ArrayList<String>();
    private ArrayList<String>  MinSquareFeet      = new ArrayList<String>();
    private ArrayList<String>  MaxSquareFeet      = new ArrayList<String>();
    private ArrayList<String>  bedroomList        = new ArrayList<String>();
    private ArrayList<String>  bathroomList       = new ArrayList<String>();
    private ArrayList<String>  phoneList          = new ArrayList<String>();
    private ArrayList<String>  GEOCODED_FROM_GOOGLE= new ArrayList<String>();
    private ArrayList<String>  notes              = new ArrayList<String>();
    private HashSet<String>    dupCheckMap        = new HashSet<String>();
    private String             builderName        = null;
    private String             builderUrl         = null;
    
    private ArrayList<String>  Count                 =       new ArrayList<String>();
    private ArrayList<String>  ConstructionStartDate =       new ArrayList<String>();
    private ArrayList<String>  ConstructionEndDate   =       new ArrayList<String>();

    public CommunityList(String builderName, String builderUrl) throws Exception {

        validateBasicCases("BuilderName", builderName, 2, 80);
        validateUrl("BuilderUrl", builderUrl);

        this.builderName = trim(builderName);
        this.builderUrl = trim(builderUrl);
    }
    
    private static String trim(String s){
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    public void addUnitCount(String count) throws Exception{
    	validateBasicCases("Number_Of_Units", count, 1, 4);
    	count=trim(count);
    	if(!count.equals(ALLOW_BLANK)){
    		if(!count.matches("[0-9]{1,4}")) {
    			err("Number_Of_Units", "must be in number format", count);
    		}	
    	}
    	Count.add(count);
    }
    
    public void addConstructionInformation(String val1,String val2) throws Exception{
    	DateFormat dateformat = new SimpleDateFormat("yyyy/MM/dd");
    	if(!val1.contains(ALLOW_BLANK)) {
    		if(!val1.matches("(^\\d{4})/([0][1-9]|[1][0-2])/([0][1-9]|[1][0-9]|[2][0-9]|[3][0,1])")) {
    			err("Construction_Start_Date","must be in proper number date format",val1);	
    		}
    	}
    	if(!val2.contains(ALLOW_BLANK)) {
    		if(!val2.matches("(^\\d{4})/([0][1-9]|[1][0-2])/([0][1-9]|[1][0-9]|[2][0-9]|[3][0,1])")) {
    			err("Construction_End_Date","must be in proper number date format",val2);	
    		}
    	}
    	val1=trim(val1);
    	val2=trim(val2);
    	ConstructionStartDate.add(val1);
    	ConstructionEndDate.add(val2);
    } 
    
    public void addPropertyType(String val,String val1) throws Exception {

        validateBasicCases("PropertyType", val, 4, 182);
        validateBasicCases("DERIVED_PROPERTY_TYPE", val1, 4, 120);
        val = trim(val);
        val1=trim(val1);
        propertyTypeList.add(val);
        DERIVED_PROPERTY_TYPE.add(val1);
    }//addPropertyType
   public void addNotes(String note){
	   note = trim(note);
	   if(note.length() > 1)
		   note = U.getCapitalise(note);
	   notes.add(note);
   }
  
    public void addPropertyStatus(String val) throws Exception {

        validateBasicCases("PropertyStatus", val, 4, 165);
        val = trim(val);
        String[] words = val.split(" ");
  		String capital = null, wd;
  		for (String word : words) {
  			wd = word.substring(0, 1).toUpperCase() + word.substring(1);
  			capital = (capital == null) ? wd : capital + " " + wd;
  		}
  		val=capital;
  		val = val.replace("Close-out", "Close Out").replace(" two ", " Two ");;
  		val = val.replace(" Ii ", " II ").replace(" Iv ", " IV ").replaceAll(" Iii$", " III").replaceAll(" Ii$", " II")
  				.replace(" Iii ", " III ").replace(" Ii,", " II,");
  		
        U.log("status=="+val);
        propertyStatusList.add(val);
    }//addPropertyStatus


    public void addPrice(String minPrice, String maxPrice) throws Exception {

        validateBasicCases("MinPrice", minPrice, 4, 12);
        validateBasicCases("MazPrice", maxPrice, 4, 13);
        minPrice = minPrice.replace("Rs.", "$");
        maxPrice = maxPrice.replace("Rs.", "$");
        //HOME_PRICE = \$[0-9]{2,3},[0-9]{3}
        //HOME_PRICE_M = \$[12],[0-9]{2,3},[0-9]{3}
        
        if (!minPrice.equals(ALLOW_BLANK)) {
        	
        	
            if (!minPrice.matches("\\$[0-9]{2,3},*[0-9]{3}")
                    && !minPrice.matches("\\$[0-9]{1,2},*[0-9]{2,3},*[0-9]{3}") ) {

                err("MinPrice", "Must match $000,000 format. Normally prices below $20,000 is a rental property. We don't want rentals. We only want houses for sale.", minPrice);
            }    
        	
        }
        if (!maxPrice.equals(ALLOW_BLANK)) {
            //$3,249,995
            if (!maxPrice.matches("\\$[0-9]{2,3},*[0-9]{3}")
                    && !maxPrice.matches("\\$[0-9],*[0-9]{2,3},*[0-9]{3}")&&!maxPrice.matches("\\$[0-9]{2},*[0-9]{2,3},*[0-9]{3}")) {
                err("MaxPrice", "Must match $000,000 format", maxPrice);
            }
        }

        if (minPrice.equals(ALLOW_BLANK))
            minPrice = "";
        if (maxPrice.equals(ALLOW_BLANK))
            maxPrice = "";
       // priceList.add(trim(minPrice) + "-" + trim(maxPrice) );
           if(minPrice.contains("$")){minPrice=minPrice.replace("$", "").trim();}
           if(minPrice.contains(",")){minPrice=minPrice.replace(",", "").trim();}
           if(maxPrice.contains("$")){maxPrice=maxPrice.replace("$", "").trim();}
           if(maxPrice.contains(",")){maxPrice=maxPrice.replace(",", "").trim();}
           MinPrice.add(trim(minPrice));
           MaxPrice.add(trim(maxPrice));
    }//addPrice


    public void addSquareFeet(String minSqFeet, String maxSqFeet) throws Exception {

        validateBasicCases("minSqFeet", minSqFeet, 3, 9);
        validateBasicCases("maxSqFeet", maxSqFeet, 3, 9);

        //HOME_PRICE = \$[0-9]{2,3},[0-9]{3}
        //HOME_PRICE_M = \$[12],[0-9]{2,3},[0-9]{3}

        if (!minSqFeet.equals(ALLOW_BLANK)) {
            if (!minSqFeet.matches("1*[0-9]*,*[0-9]{3}")) {
                err("minSqFeet", "Must match number format", minSqFeet);
            }
        }

        if (!maxSqFeet.equals(ALLOW_BLANK)) {
            if (!maxSqFeet.matches("1*[0-9]*,*[0-9]{3}")) {
                err("maxSqFeet", "Must match number format", maxSqFeet);
            }
        }

        if (minSqFeet.equals(ALLOW_BLANK))
            minSqFeet = "";
        if (maxSqFeet.equals(ALLOW_BLANK))
            maxSqFeet = "";
        if(minSqFeet.contains(",")){minSqFeet=minSqFeet.replace(",", "").trim();}
        if(maxSqFeet.contains(",")){maxSqFeet=maxSqFeet.replace(",", "").trim();}
       // squareFeetList.add(trim(minSqFeet) + "-" + trim(maxSqFeet));
        MinSquareFeet.add(trim(minSqFeet));
        MaxSquareFeet.add(trim(maxSqFeet));
    }//addSquareFeet


    public boolean communityUrlExists(String commUrl) throws Exception {

        String key = commUrl.toLowerCase();
        return (dupCheckMap.contains(key));
    }
    

    public boolean communityNameExists(String commName) throws Exception {
        return this.communityNames.contains(commName);
    }

    public void addCommunity(String communityName, String commUrl,String commType) throws Exception {
       //  Community Type
        validateBasicCases("CommunityName", communityName, 2, 100);

        if (communityUrlExists(commUrl)) {
            err("CommunityUrl", "has already been added", commUrl);
        }
        communityName = communityName.trim();
        /*if(communityName.endsWith("villas")||communityName.endsWith("Villas")||communityName.endsWith(" Luxury Patio")||communityName.endsWith(" Luxury Homes")||communityName.endsWith(" Ranch Patio")||communityName.endsWith(" Patio")){
        	communityName=communityName.replaceAll("villas|Villas| Luxury Patio| Luxury Homes| Ranch Patio| Patio", "");
        }
        if(communityName.endsWith("townhomes") || communityName.endsWith("Townhomes")){
        	communityName=communityName.replaceAll(" - townhomes|townhomes", "");
        }
        if(communityName.endsWith("Condo") || communityName.endsWith("condo") ||communityName.endsWith("Condominium") ||communityName.endsWith("condominium") ){
        	communityName=communityName.replaceAll("Condo|condo|Condominium|condominium", "");
        }
        
        if(communityName.endsWith("Courtyards") || communityName.endsWith("courtyards") ){
        	communityName=communityName.replaceAll("Courtyards|courtyards", "");
        }
        if(communityName.endsWith("Cottages") || communityName.endsWith("cottages") ){
        	communityName=communityName.replaceAll("Cottages|cottages", "");
        }*/
        
        /**
         * Below code is to remove the property type from the end of community name
         */
        //----Single-Family-----
        communityName = communityName.replaceAll("[S|s]ingle[-| ][F|f]amily\\s+[H|h]ome[s]*$|[S|s]ingle[-| ][F|f]amily\\s+[r|R]anch\\s*[h|H]ome[s]*$|[S|s]ingle[-| ][F|f]amily$", "");        
        //--Luxury Homes---
        communityName = communityName.replaceAll("[L|l]uxury\\s*[H|h]ome[s]*$|[L|l]uxury$|[L|l]uxury\\s*[p|P]atio[s]*$|[L|l]uxury\\s*[V|v]illa[s]*$", "");      
        //--Craftsman Style Homes---
        communityName = communityName.replaceAll("[C|c]raftsman[-| ]*[S|s]tyle\\s*[H|h]ome[s]*$", ""); 
        //--Traditional Homes---
        communityName = communityName.replaceAll("[T|t]raditional[-| ]*[h|H]ome[s]*$", "");        
        //-- Ranch Homes---
        communityName = communityName.replaceAll(" [R|r]anch[-| ]*[h|H]ome[s]*$", "");        
        //--Townhomes---
        communityName = communityName.replaceAll("[T|t]own[-| ]*[h|H]ome[s]*$", "");
        //--Condo---
        communityName = communityName.replaceAll("[c|C]ondo[s]*$|[c|C]ondominium[s]*$", "");
        //--Courtyards---
        communityName = communityName.replaceAll("[C|c]ourtyard[s]*$", "");
        //--Cottages---
//        communityName = communityName.replaceAll(" [C|c]ottage[s]*$", "");
        //--Patio---
        communityName = communityName.replaceAll("[P|p]atio[s]*$", "");
        //--Villas---
//        communityName = communityName.replaceAll(" [V|v]illa[s]*$", "");  
        //--Duplexes---
        communityName = communityName.replaceAll("^[D|d]uplexes\\s+|\\s+[D|d]uplexes$", ""); 
        //--Country Club---
    //    communityName = communityName.replaceAll("[C|c]ountry\\s*[C|c]lub$", ""); //^[C|c]ountry\\s[C|c]lub\\s+
        //----Other----
        communityName = communityName.replace("&amp;", "&");
        communityName=communityName.replaceAll(" Patio and Villa Homes$| [G|g]arden [H|h]omes$| Townhomes and Villas$| Luxury Patio$| Gated Community$| SF$|Single(-| )Family$| Single(-| )Family\\s*Homes$|Active Adult$|\\([^\\)]+\\)", "");
        
        
        
        U.log("Adding '" + communityName + "' : " + commUrl);
        validateSizes();

        validateUrl("CommunityUrl", commUrl);

        communityUrls.add(trim(commUrl));
        communityName= communityName.trim().replaceAll("\\s{2,}", " ").replaceAll("(\\S)-(\\S)", "$1 $2");
        String[] words = communityName.split(" ");
		String capital = null, wd;
		for (String word : words) {
			wd = word.substring(0, 1).toUpperCase() + word.substring(1);
			capital = (capital == null) ? wd : capital + " " + wd;
		}
		communityName=capital;
		communityName=communityName.replaceAll("&#8217;s|\u0027s|&nbsp;", "'s");
		communityName=communityName.replaceAll("&#39;s", "'s");
		communityName=communityName.replace("&#39;", "'");
		communityName=communityName.replace("Ii", "II").trim().replaceAll("-$", "").replace("IIi", "III");
        communityNames.add(trim(communityName));
        CommunityType.add(trim(commType));
        String key = commUrl.toLowerCase();
        dupCheckMap.add(key);
        
        
    }
    
    //addCommunityUrl


    static final String LAT_ERROR = "Must be a valid coordinate number. Check the spaces and strings in your value.";
    static final String LON_ERROR = "Must be a valid coordinate number. Check the spaces and strings in your value.";


    public void addLatitudeLongitude(String latitude, String longitude,String flag) throws Exception {

        validateBasicCases("Latitude", latitude, 4, 50);
        validateBasicCases("Longitude", longitude, 4, 50);


        //LATITUDE = [2-4][0-9]\.[0-9]+
        //LONGITUDE = \-*[0-9]{2,3}\.[0-9]+
        if (!latitude.equals(ALLOW_BLANK)) {
            if (!latitude.matches("[1-6][0-9]\\.[0-9]+")) {
                err("Latitude", LAT_ERROR, latitude);
            }
        }
        if (!longitude.equals(ALLOW_BLANK)) {
            if (!longitude.matches("\\-[0-9]{2,3}\\.[0-9]+")) {
                err("Longitude", LON_ERROR, longitude);
            }
        }

        latitudeList.add(latitude);
        longitudeList.add(longitude);
        GEOCODED_FROM_GOOGLE.add(flag.toUpperCase());
    }//addLatitudeLongitude


    public boolean isValidCity(String city){
        try {
            validateBasicCases("City", city, 3, 30);
        } catch (Exception e) {
            return false;
        }
        if (city.equals(ALLOW_BLANK))  return true;
        

        return (!city.matches("[0-9].*"));

    }//isValidCity()
    
    
    public void addAddress(String streetAddress, String city, String state, String zip) throws Exception {
    	
    	
    	if(streetAddress.toLowerCase().trim().equals("street"))
    		streetAddress=ALLOW_BLANK;

        validateBasicCases("StreetAddress", streetAddress, 2, 500);
        validateBasicCases("City", city, 3, 66);
        validateBasicCases("State", state, 2, 2);
        validateBasicCases("Zip", zip, 5, 5);

        //check city
        if (!city.equals(ALLOW_BLANK)) {
            if (city.matches("[0-9].*"))
                err("City", "Cannot start with a number", city);
        }


        //check state
        if (!state.equals(ALLOW_BLANK)) {
        	
            Collection<String> allUsStates = USStates.getAllAbbr();
            if (!allUsStates.contains(state)) {
                err("State", "is not a USA state", state);
            }
        }

        //check zip
        if (!zip.equals(ALLOW_BLANK)) {
            if (!zip.matches("[0-9]{5}")) {
                err("Zip", "must be 5 digit number", zip);
            }
        }

        streetAddress = trim(U.getCapitalise(streetAddress.replace(".","")));
        city = trim(city);
        state = trim(state);
        zip = trim(zip);
        
        
        String[] words = city.split(" ");
     		String capital = null, wd;
     		for (String word : words) {
     			wd = word.substring(0, 1).toUpperCase() + word.substring(1);
     			capital = (capital == null) ? wd : capital + " " + wd;
     		}
     		city=capital;
        
        
        addressList.add(streetAddress);
        cityList.add(city);
        stateList.add(state);
        zipList.add(zip);

    }//addAddress


    private static void err(String type, String msg, String data) throws Exception {

        String message = type + " " + msg + "\nYou passed in \"" + data + "\"";
        
        System.err.println("\n------------ ERROR ---------------");
        System.err.println(message);
        System.err.println("----------------------------------\n");
        throw new Exception(message);
    }


    private static void validateUrl(String type, String commUrl) throws Exception {


      /*  if (!commUrl.startsWith("http://"))
            throw new Exception(type + " must start with http://   " + commUrl);*/
         if (commUrl.indexOf("//") > 7)
            throw new Exception("Double slash not allowed in a " + type + " " + commUrl);
        else if (commUrl.endsWith("\\"))
            throw new Exception(type + " cannot end with a slash (\\) " + commUrl);

        validateBasicCases(type, commUrl, 10, 400);

    }//validateUrl


    private static void validateBasicCases(String type, String data, int minLength, int maxLength)
            throws Exception {

        if (data == null)
            throw new Exception(type + " cannot be NULL: " + data);

        if (data.matches("<(img|p|br|div|span|a|body|html|head|script)"))
            throw new Exception(type + " cannot contain HTML " + data);
        else if (data.contains("<") && data.contains(">"))
            throw new Exception(type + " cannot contain HTML " + data);

        if (!data.equals(ALLOW_BLANK)) {
            if (data.length() < minLength || data.length() > maxLength) {
                throw new Exception(type + " length must be between " + minLength + " and " + maxLength
                        + "\n" + data + "\nYour value length=" + data.length());
            }
        }
    }//validateBasicCases


    public String printAll() throws Exception {

        validateUrl("BuilderUrl", builderUrl);
        validateSizes();

        StringWriter sw = new StringWriter();

        CSVWriter writer = new CSVWriter(sw, ',');
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();

        final String[] columns = {"Index", "BuilderName", "BuilderUrl", "CommunityName", "CommunityUrl","CommunityType",
                "Address", "City", "State", "Zip", "Latitude", "Longitude","GEOCODED_FROM_GOOGLE","PropertyType", "DERIVED_PROPERTY_TYPE","PropertyStatus",
                "MinPrice","MaxPrice", "MinSquareFeet","MaxSquareFeet","Notes","Fetching Time","Number_Of_Units","Construction_Start_Date","Construction_End_Date"};

        //Util.log(communityUrls.get(i) + "\t #" + i);  
        writer.writeNext(columns);

        Util.log("# ----" + builderName + " = " + communityUrls.size() + " ----------");
int k=800;
        for (int i = 0; i < communityUrls.size(); i++) {

            String[] entries = new String[columns.length];
            k=k+1;
            int j = 0;
            entries[j++] =""+i;
            entries[j++] = builderName;
            entries[j++] = builderUrl;
            entries[j++] = get(communityNames, i);
            entries[j++] = get(communityUrls, i);
            entries[j++] = get(CommunityType, i);
            
            entries[j++] = get(addressList, i);
            entries[j++] = get(cityList, i);
            entries[j++] = get(stateList, i);
            entries[j++] = get(zipList, i);

            entries[j++] = get(latitudeList, i);
            entries[j++] = get(longitudeList, i);
            
            entries[j++] = get(GEOCODED_FROM_GOOGLE, i);
            
            
            entries[j++] = get(propertyTypeList, i);
            entries[j++] = get(DERIVED_PROPERTY_TYPE, i);
            //DERIVED_PROPERTY_TYPE
            entries[j++] = get(propertyStatusList, i);

            entries[j++] = get(MinPrice, i);
            entries[j++] = get(MaxPrice, i);
            entries[j++] = get(MinSquareFeet, i);
            entries[j++] = get(MaxSquareFeet, i);
            entries[j++] = get(notes, i);
           
            
            entries[j++] =dateFormat.format(date).toString() ;
            entries[j++] = get(Count,i);
            entries[j++] = get(ConstructionStartDate,i);
            entries[j++] = get(ConstructionEndDate,i);
            //Util.log(communityUrls.get(i) + "\t #" + i);
            writer.writeNext(entries);

        }
        writer.close();

        U.log(sw.toString());

        return sw.toString();
    }//printAll


    private static String get(ArrayList<String> a, int i){
        String v = a.get(i);
        //U.log(v);
        if (v.equals(ALLOW_BLANK)){
            //Client wants null strings for ALLOW_BLANK
            v = "";
        }
        return v;
    }

    private void validateSizes() throws Exception {

        HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
        map.put("communityUrls", communityUrls);
        map.put("addressList", addressList);
        map.put("cityList", cityList);
        map.put("longitudeList", longitudeList);
        map.put("latitudeList", latitudeList);
        
        map.put("GEOCODED_FROM_GOOGLE", GEOCODED_FROM_GOOGLE);
        
        map.put("zipList", zipList);
        map.put("propertyStatusList", propertyStatusList);
        map.put("propertyTypeList", propertyTypeList);
        map.put("DERIVED_PROPERTY_TYPE", DERIVED_PROPERTY_TYPE);
        //
        map.put("priceList", MinPrice);
        map.put("priceList", MaxPrice);
       // map.put("priceList", priceList);
        map.put("squareFeetList", MinSquareFeet);
        map.put("squareFeetList", MaxSquareFeet);
       // map.put("squareFeetList", squareFeetList);


        Object[] set = map.keySet().toArray();
        for (int i = 1; i < set.length; i++) {
            String k1 = (String) set[i - 1];
            String k2 = (String) set[i];

            ArrayList<String> list1 = map.get(k1);
            ArrayList<String> list2 = map.get(k2);

            if (list1.size() != list2.size()) {
                err("Sizes don't match " + list1.size() + "!=" + list2.size(), "", k1 + "!=" + k2
                        + "\nProbably '" + k2 + "' wasn't added");
            }
        }
    }//validateSizes()

    public void setBuilderName(String name) {
        this.builderName = trim(name);
    }

    public String getBuilderName() {

        return this.builderName;
    }

    public int getCount() {
        return this.communityNames.size();
    }


}
