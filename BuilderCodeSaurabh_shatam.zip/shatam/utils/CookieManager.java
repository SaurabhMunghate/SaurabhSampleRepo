package com.shatam.utils;


import java.io.IOException;
import java.net.URLConnection;
import java.util.HashSet;

public class CookieManager {

    private static final String SET_COOKIE = "Set-Cookie";
    private static final String COOKIE     = "Cookie";



    public static HashSet<String> getCookies(URLConnection conn) throws IOException {

        HashSet<String> cookies = new HashSet<String>();
        String headerName = null;
        for (int i = 1; (headerName = conn.getHeaderFieldKey(i)) != null; i++) {
            if (!headerName.equalsIgnoreCase(SET_COOKIE))
                continue;
            String vals = conn.getHeaderField(i);
            for (String val : vals.split(";")) {
                //U.log(i + "] Store cookie: " + val);
                cookies.add(val);
            }

        }//for i
        return cookies;
    }


    public static void setCookies(URLConnection conn, HashSet<String> cookies) throws IOException {

        String buf = "";
        for (String cookie : cookies) {
            if (cookie.startsWith("ARPT=") || cookie.startsWith("BHISession=")
                    || cookie.startsWith("ASP.NET_SessionId=")) {
                buf += cookie + "; ";
            }
        }
        if (buf.length() > 0) {
            //U.log("SetCookie: " + buf);
            conn.setRequestProperty(COOKIE, buf);
        }
    }


}
