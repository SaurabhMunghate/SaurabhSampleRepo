package com.shatam.utils;

import java.util.HashMap;

public class DerivedPropertyType {

	public static HashMap<String, String> dcommTypes = new HashMap<String, String>() {
		{
			//put("One Story Split","One Story Split");
			put("first and second floor owner|One- and two-story|single- and two-story|single and two-story|1 Stories|single-level home|1-and 2-story|1 Story</h5>|one or two-story homes|<em>1-Story</em>|Story 1.00|Stories: 1.0 |single and two story homes|1 - 2 Stories|1 - 1.5 Stories|story 1 | first-floor living |1 or 2-story home|1-Story</li>|single floor living|1st and 2nd floors|with first floor|Offering first floor|first floor owner|first floor living|single-floor|one or two-stories|1- or 2-story|One-Level|one level|one level living|first story|Stories\\s*\\n*\\s+1|One Level Living|one level living |1, 1.5 and 2-story|Story: 1.00| one-level living|1- and 2-story|one- & two-story|one-level homes|Single-Level|1 Story|one & two-story|one-and two-story|one and two story|1 story|Stories 1 |single level|single story|1  Story|Single- and 2-Story|1 &amp; 2 story|Stories: 1 |1 or 2 story| 1- &amp; 2-story|1- & 2-story|1 and 2-Story|single-level and two story|single-level and two story|one and two story|One &amp; two story|Story 1<|Single story|1 and 2 story|ingle &amp; two-story|Stories: 1<|one and two-story|1 & 2 story|One- and two-story|One- and two- story|one and two story|One or Two Story|1-3 Stories|one and two story|1-Stories|single-story|1 & 2-Story|single and two-story|1-2 stories|One and two-story|Stories 1 |one-story|single story|1 Story Home|1  Story Home| 1-story|One Story| 1-story|single-story|1 Stories| 1 STORY|Stories:</span> 1|1�story|single- and two-story|one story| one story|One, one and half and two story|1.0 Story| 1 &amp; 2-story home|Single and 2-Level |single, two-level|Single and 2-story|Single or multi-story|Single or 2-story|Story <strong>1<|>&nbsp;1-Story|>1 – 2 story|>1</strong> Story|Stories 1,|first level|new 1-2 Story|stories\":\"1-Story",
					"1 Story");  //Main-level living|
			
			put("reverse story-and-a-half homes|Reverse-one-half-Story|Reverse 1.5 Stories|Stories: Reverse 1.5|Reverse 1.5 Story|reverse 1 1/2 story", 
					"Reverse 1.5 Story");
			
			put("1.5 &amp; 2-story|1.5 and 2-story|1 1/2 story condos|1.5 Story</li>|1.5 Story|Stories 1.5| 1.5 Story<|1.5 - 2 Stories|1 1/2 story home|1.5 story home|One-and-a-half story|Stories: 1.5 &nbsp|One and a half-story|1, 1.5 and 2-story|Stories: 1.5|1 1/2 Story|1.5-story|1.5 Stories|1-1/2- story|Story 1 1/2|1.5 story|one &amp; a half story|one & a half story|story-and-a-half|one-half story|1 ½ story|1 &frac12; story|one-and-a-half or two story|1-½ and 2-story|story and a half|1.5 Story |Story 1.5|Stories: 1.5|Stories: 1.5|story 1 - 1.5|1.5 and 2 story|1�  story|1/2 story|stories\" value=\"1.5|1.5�story|one and a half story|1 &frac12; story|one and ½ story|Story <strong>1.5<| 1½-story |One and half story home",
					"1.5 Story");
			
			put(" 2nd story |<li>2 Story(</li>)?|2-story homes|2 STORY</div>|2 Stories|</span>2 Story</span>|<strong>2</strong> Stories|<p>2-Story|Two-level townhomes|2 Story,|2nd Story|two-story home[s]*|<em>2-Story</em>|\\s+2-Story |2-3 Story | (t|T)wo level townhome | 2-story design |2-3 story homes |2- and 3-story |two-story home[s]*|2&nbsp;&amp; 3-story|second floor owner| 2 story| 2 story |2 - 3 Stories|two-story|2- or 3-story |2 and 3 story| 2nd floor |2 Story</strong>|two-stories|second level |2-level luxury|second level|two-level homes|two and three-story| 2-Story|2 &amp; 3 story|<li>2 Stories|two to three stories|2.0 story| 2-Story|second-story|Story: 2.00|2 and 3 stories|2-level condos|Story 2|one and two story| 2 story|even\">Story 2|Stories 2|Stories: 2|two story| 2 Story|Stories:</span>2|2-Stories|Two stories|two-story|two and three story|two story |Stories 2|two- story|Second Story|two-story|Story 2.0|2  Story Home|2 stories| 2 story| 2 STORY|two-Story|[T|t]*wo-[S|s]*tory| Two-story| 2-Story|two story|Two Story| 2-story|TWO STORY|Stories:</span> 2| 2�story|two- and three-story|Stories: 2|two- to three-story|from 2 to 3 level|(\\s|\t)2 Story(\\s*)?<br|\"2 Story|from 2 to 3 levels|&nbsp;2 - 3 Story Detached|Single and 2-Level |<strong>2 Story|Story <strong>2<|>2 Story<|<li>2-Story|>2</strong> Story| 2-level |new 1-2 Story|\"stories\":2}|two level|>2-story Single Family| 2 to 3 story| 2 and 3-story| 2 Story |stories\":\"2-Story|two- and three-level homes",
					"2 Story");

			put("2 1/2 story|2 1/2 Story|2.5 stories| Story 2.5| 2.5 Story", "2.5 Story");
			
			put("Three-to-Four story| three to four stories| three story |tri-level home|three- to four- story|Series:</span> Tri Level|3 Stories|story 3| third-story |3 Stories|three-level Carriage-Style Townhomes|3-story townhomes| 3.0 story|3 Finished Levels,|3-Level Luxury |3 levels of living|3- and 4-story|3-level townhome|3 and 4 level townhomes|3rd level|3 and 4 level|third story|3-4 story|3 and 4 story|3-level townhomes|three stories|3 story|Stories 3|Three-Story|Story 3 |Stories: 3|Stories 3|two- to three-story|three to four-story|3-Stories|three story|three-story|3 Story|story 3.0 |3-story townhomes|3-story|Three-story| 3 Stories|Stories:</span> 3|3 Story|three-story|3�story|Stories: 3|from 2 to 3 level| three levels?| 3- and 4-level home| three, two-story | 3-level| three-level|three and four-story|three and two-story|three-and four-story|second and third levels|Three-level homes| 3rd story",
					"3 Story");
			
			put("Stories: 3.5|3.5 Stories", "3.5 Story");

			put("four levels |4 Stories|4-level home|four- story|Four story |four stories|4-level townhomes|4 finished levels|4th level bonus suites|4th level bonus suites| four level townhomes |4 level townhomes|3-4 Stories|Stories:</span>4|4-story|four-story|Stories: 4|4 level|4 Stories|4 story|Story 4 |Stories 4|4�Story| 4th level| 4 &amp; 9 floor| 3- and 4-level home|four-level | 4-level ",
					"4 Story");
			
			put("five-level splits", "Five-Level Splits");
	
			put(" five-story|five-level floorplans|5-level design|5-level plans| 5th-floor |Stories:5| 5 (S|s)tory| five levels? | 5-story|5 Story mid| 5 stories|>5 Story |\"5 Story|five stories| Story 5 ", 
					"5 Story");

			put(" 6 (s|S)tory|six-story| 6-story ", "6 Story");
			put("seven-story|, 7 floors| 7 (S|s)tory", "7 Story");
			put("eight-story| 8 (S|s)tory","8 Story");
			put(" nine-level |Nine stories|9th-Floor |nine-story|, 9 floors| 4 &amp; 9 floor| 9 story", "9 Story");
			put(" ten-story | 10- and 12-story|a 10-story| 10-story "," 10 Story");
			
			put(" 11-story", "11 Story");
			put(" 12 stories| 12-story| 12 story", "12 Story");
			put(" 14-story|Fourteen-Story"," 14 Story");
			put("top 15 floors| 15-story","15 Story");
			put(" 16 story ", "16 Story");
			put(" 17-Story ", "17 Story");
			put("18-story","18 Story");
			put("nineteen story | 19-story","19 Story");

			put(" 20-story| 20-story,"," 20 Story");
			put(" 21-story", "21 Story");
			put("22 Story| 22-story ","22 Story");
			put("25 Stories|25-story|25th-floor ", "25 Story");
			put(" 26 story ","26 Story");
			put(" 28-story ", "28 Story");
			put("32-story","32 Story");
			put("31 story","31 Story");
			put("33 stories ","33 Story");
			
			put("40-story ","40 Story");
			put("41 stories","41 Story");
			put("45th floor ","45 Story");
			put(" building: 46 levels","46 Story");
			
			put("multi-level foyer", "Multi-Level Foyer");
			
			put(" multilevel townhomes|Multi-Level|multi-level|Multi Level|multi-story|multi-level courtyard|multiple-level",
					"Multi-Level");
			put("reverse ranch", "Reverse Ranch");
			
			put("Ranch & Two-Story|Ranch & 2-Story Plans|Rancher Series|ranch floor plan|ranch and two-story|1 ranch|Ranch & Smart|Ranch Plan|Ranch Style Design|Ranch floorplans|ranch-style floor plan|Ranch Elevation| Ranch architectural styles|Ranch and |Spacious ranch plans|all-ranch plan community|listing\">\\s+Ranch|Ranch Patio |ranch-style|ranch home| Ranch | ranch| ranch-style |Ranch</span>| Ranches | ranch,| Ranch|<strong>Ranch</strong>|rambler style| ranch home|STYLE</p><span>Rambler| rambler floorplan|</i> Ranch</li>|<li>ranch condominium| rambler plan",
					"Ranch");

			put("(S|s)plit floor plan|split floorplan|Single Level Split Plan|split plan design|Series:</span> Split Level|split floor-plan|2-Story Bi-Level|Split Level</span>|Split-level home| a split level|Split-Level|Bi-Level| split levels?|split plan","Split-Level");
			
			put("Spanish Colonial|The Colonial|Colonial and Ranch|colonial home plans|and Colonial|Colonial Homes?|Colonial Revival|Ranch-, Colonial-|Colonial- and Ranch|Colonial styles?|story colonial|Ranch or Colonial|ranches to colonials|Colonial Single-Family Homes|Traditional Colonial|, Colonial and|Crafts, Colonial, |Colonial Architecture|Ranch, Colonial and|Colonial inspired architecture|Colonial Village|At Colonial Charters|Colonial exterior|including Colonial| Craftsman Colonial |</span>Colonial</span>|colonial, art |Colonial settlements|Spanish colonial Reviva|, Colonial Estates|Spanish Colonial, Ranch| colonial design|Colonial\\s+</span>|Colonial Manor|\\d{4} Colonial| II Colonial;|- Colonial|: Colonial |Colonial Heritage|styles like colonial",
					"Colonial");
		}
	};

}
