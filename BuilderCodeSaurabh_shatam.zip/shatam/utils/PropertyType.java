package com.shatam.utils;

import java.util.HashMap;

public abstract class PropertyType {

	public static HashMap<String, String> propTypes = new HashMap<String, String>() {

		{
			//================= A ====================
			
			put("Apartment Flat", 
					"Apartment Flat");
			
			put("apartments|apartment", 
					"Apartment Homes");
			//================== B ===================
			
			put("Basement Home ", "Basement Homes");

			put("Bungalow Series|Bungalow Home|BUNGALOW \\d+ sqft|Bungalows, Cottages|Traditional, Bungalow|The Bungalows?|\\d{4} Bungalow |Craftsman Bungalows|mix of Craftsman, Bungalow|Coastal, Craftsman and Bungalow-style| bungalow-style|detached bungalows|styles like Bungalow|Bungalows home|single-family homes and bungalows",
					"Bungalow Homes");
			
			//=================== C ==================

			put("Cabin ", 
					"Cabin");
			
			put("Carriage-Style Townhomes? |Carriage and Cottage Collections|The Carriage Collection|carriage house|Carriage</span>|Carriage Home|carriage flats|Carriage Style|Carriage, Townhom|carriage-style homes|Carriages Collection|Carriage Series",
					"Carriage Homes");
			
			put("claasic row homes", 
					"Classic Row Homes");
			
			put("Coach Home", 
					"Coach Homes");

			put(" a coastal design|coastal-style homes| coastal homes?|coastal architectural|Coastal living|Coastal designs|Coastal Farmhouse|coastal craftsman|coastal-themed single-family|Coastal Series|coastal \\w+ community|coastal cottage-style|coastal community|coastal-inspired carriage homes|coastal villas|Coastal, Craftsman and Bungalow-style|coastal-themed architecture|coastal contemporary architecture| Coastal</div>|The Coastal|Coastal cottage houses|coastal-inspired architecture| Coastal Collection| coastal luxury|Coastal Flats|beautiful coastal|coastal style|living the coastal|coastal amenities",//|intracoastal waterway
					"Coastal-Style Homes");
			
			put("commons area |common&nbsp;area|common area", 
					"Common Area");
			
			put("Common-Interest Developments (CIDs)",
					"Common-Interest Developments (CIDs)");
			
			put("condo(minium)?|CONDOS|condominium homes", 
					"Condominium");
			
			put("Condo-Hotel Residences", 
					"Condo-Hotel Residences");

			put("COTTAGES?", 
					"Cottage");
			
			put("court-yard style home|garden court yards|Courtyard|courtyard", 
					"Courtyard Homes");
			
			put("Covenants, Conditions and Restrictions (CCRCs)",
					"Covenants Conditions And Restrictions (CCRCs)");
			
			
			put("Craftsman style details|craftsman style trim|Craftsman-style home|Modern Craftsman|Craftsman,Traditional|craftsman styling|Craftsman-style architecture|Craftsman and Traditional|Craftsman Plus floor plans|Craftsman, Traditional|Poplar Craftsman|craftsmen style homes|Craftsman\\s*</div>|Craftsman style brand new homes|Farmhouse, Craftsman|Farm House, Craftsman|Craftsman-style home|Craftsman, and Farmhouse|craftsman-styled homes|craftsman details |craftsman style patio|Craftsman charm |Craftsman Homes|Craftsman features|Craftsman-style exterior|craftsman style facade|Craftsman Colonial|spacious Craftsman style|New Craftsman, Farmhouse|Craftsman Bungalow|craftsman-style exterior designs|crafted custom designed flat|Craftsman exterior styling|Beautiful Craftsman Home|Craftsman style new homes|Craftsman Style swim community|Craftsman and European-style homes|community of Craftsman|craftsman tradition|Craftsman style low maintenance homes|Craftsman townhomes|Craftsman New Homes|Craftsman influenced exteriors |Craftsman Style Home|Craftsman style bungalows|Craftsman cottages|Craftsman exteriors|Craftsman architecture| craftsman style two story home|Craftsman architectural styles|offers craftsman style|craftsman-style plan|Coast Design/Craftsmen Style|craftsman-style townhomes|Craftsman influenced architectural| fine craftsman details|Craftsman style homes|Craftsman-style home|Craftsman-style exteriors|craftsman-style design|Sierra Craftsman|craftsman-style single family|Craftsman-style single-family|Craftsman architectural styling|Craftsman Plus Collection| craftsman-style homes|craftsman style architecture| well-crafted homes|Craftsman, coupled|Craftsman-inspired|craftsman style crown| craftsman style trim accent|exquisite craftsman style|with craftsman exteriors|Craftsman style exterior|Craftsman Style Homes|and craftsman homes|Craftsman-style new homes|craftsman inspired detail|Craftsman design|"
					+ "elevation styles, country and craftsman|Spanish Colonial, Craftsman|craftsman-styled exterior|Craftsman-style flair|craftsman style ranch homes| Craftsman, Agrarian and Beach Cottage|craftsman style|Plan \\d+ Craftsman| Craftsman \\| Ranch|esigned Cottage, Craftsmen|superb craftsmanship|custom craftsmanship|stylish Craftsman exterior|Craftsman, Spanish|crasftsman style home|Craftsman Architectural|Craftsman &amp; Tudor style homes|mix of Craftsman, Bungalow|Coastal, Craftsman and Bungalow-style|Craftsman-style ranch| Craftsman</h4>|Spanish, Craftsman, and Tuscan Architecture|The Craftsman|Craftsman Series|Craftsman, Tudor|craftsman style|Craftsman 1st|craftsman home designs|craftman style homes|Farmhouse and Craftsman exteriors| and craftsman\\.|Craftsman-style |Crafstman and traditional exterior|craftsman and colonial style homes",
					"Craftsman-Style Homes");
			
			put("custom new home design|Single family Custom Homes|custom home appeal|Custom-style living|Summit Custom Homes|James Engle Custom Homes|custom home design|custom-designed townhome|custom home sits|Beautiful custom home|stunning custom home|Custom Home Communities|luxury custom homes|single-family custom homes|customizable homes|Custom Homes in |Designer Custom Finishes|semi-custom homes|customizable designs including|Custom homes plans|semi-custom designer homes|custom-feel all-ranch homes|custom single-family homes|appointed custom homes|unique, custom, luxurious|unique custom homes|custom 2-story plan|custom designed new homes|custom design options |custom-designed lower|great custom home |& Custom Homesites| and custom homes|custom home features |your custom new home|Custom Luxury Home|finest custom homes|in custom homes | custom home designs|Keystone Custom Homes| a custom home|magnificent custom homes|Custom Coastal Cottage-Style homes|new custom home| (C|c)ustom Homes?|Custom Series Homes|custom( |-)designed (plan|home)|custom estate home|custom-quality homes|affordable custom|Custom homes located|home to custom luxury|feel of custom estates|custom design|custom housing|end custom detail",
					"Custom Homes");
			
			//=================== D ==================
			
			put(" detached villa|detached residences|detached homes|detached condos|detached luxury single-family residences|detached three-story|detached villas|detached floorplans|Residential-Detached|detached bungalows|Detached<br>Homes|Single-Family Detached|detached single-family|detached, single-family|Single Family Detached|Detached and paired|Detached Single|dream home – detached|detached two-story homes|detached condominium|detached, two-story|detached 2 and 3-story|Detached Home|detached homes|Detached Homes|detached townhomes|detached ranch|detached home|Detached Town Homes|detached apartment|detached two-story|The only detached",
					"Detached Homes");
			
			put("Destination Clubs", 
					"Destination Clubs");
			
			put("<strong>Duplexes|Duplex | Duplex|>Duplexes ", 
					"Duplex");
			
			//===================== E ================
			put("Estate Residences|Estate Style Living|traditional and estates|Manor - Estate home|- Estate home|Estates at Mill Creek|Estate Series|single-family estate properties|estate-sized lots|Single-Level Estate Home|Estate Collection|estate floorplans|new estate home|estate-caliber homes|large estate home|estate-sized home|Estates features|Estates Series community|estate style community|Estate Size Homesites|estate sized lots|estate-sized home sites|Estate Home Community|Estates Series Home|Estate & Signature Collections|luxurious estate home|luxury living estate living|Estates sized homes| estate-style living |estate style living |luxurious estate living|Estate-Sized Homes|Estate-size home|estate home featuring| Estate Series |Estate style crown |estate style lots|estate sized home sites|Estate style homes|estate-sized homes sites|sprawling estate home|The Estate Collection|Estate Homes|to estate homes|estate-like homes|Estate homes, Manor homes|single family and estate homes|Estates Custom homes|Estate-sized homesites| Estates home| estate homes |single-family estate homes|luxury estate homes |estate homesites|luxurious estate homes|Estate homes New Home|Single Family Estate Home| elegant estate residences|estate home communities| estate-style home|estate homes feature|estate series homes|estate homes situated |Estate-Style Homes|estate lots|estate waterfront homesite|estate size lots|estate home|Estate Collection|Reserves Estates|The Estates - from|Estate-Style Community|estate sized homesites|feel of custom estates|Estate Style New Home|estate-style design",
					"Estate-Style Homes");
			
			put("executive style townhomes|Executive-level living|executive style home|Executive Home Collection|Executive Collection|Executive Series|Series:</span> Executive|executive-style homes|Executive, Single Family Homes|Executive homes|Executive homes?|executive-style",
					"Executive-Style Homes");

			//=================== F ==================			
			put("Prairie, Farmhouse|Farmhouse-inspired architectura|farmhouse interpretive townhomes|Farms Villas|modern farmhouse|The Farmhouse|Farmhouse exterior|Farm House, Craftsman|Farmhouse architecture|Farmhouse-style residences|Modern Farmhouse style|farm\\s*house style|Farmhouse styles homes|farmhouse designs|designed Farmhouse|Farmhouses designed|Farmhouse and Ranch|Farmhouse and Ranch|farmhouse elements|Farmhouse, Craftsman|Cottage, Farmhouse|Farmhouse and Traditional|Farmhouse Style Architecture|farmhouse inspired homes|Farmhouse-style Homes| Farmhouse,|American Farmhouse|-Farmhouse | Farmhouse</a>|Coastal Farmhouse-inspired new home|designed modern farm-house|Plan \\d+ Farmhouse|Farmhouse architectural styles|craftsman charm or farmhouse edge|(\\s|-)Farmhouse (II|I)| Farmhouse</h4>|modern farm house home|Farmhouse Series|Everson Farmhouse|Farmhouse and Craftsman style|farmhouse with comfortable|Farmhouse and Craftsman exteriors|Farmhouse-style exteriors",
					"Farmhouse-Style Homes");
			
			put("Flex Series|FLEX Homes|floor plan offers flex room|offering flex room options",
					"Flex Homes");
			
			put("4-plex|fourplex|four-plex|4 Plex", "Fourplex");

			
			//================== G ===================
			
			put("Apartments\\s*,\\s*Garden Style|garden style apartments|Gardens Collection|garden-style apartment buildings|garden style condominium|garden style floor plans|Garden-style apartment homes|Garden –Style Apartment Homes|Garden Collection|garden-style buildings|garden-style apartments|garden style apartment |garden style homes|garden-style community |garden apartments|Garden Series|garden home|garden/patio home|Garden View Home|garden style buildings|garden courtyard|garden patios|garden patio|Garden Villas|Garden Homes|Garden-Style Affordable Apartment", 
					"Garden Home");
			
			//=================== H ==================

			put("<h\\d>HOA</h\\d>|Farms HOA|by Homeowner Association|Active Homeowner Association|HOMEOWNER’S ASSOCIATION|low HOA fees|HOA-maintained front yards|with HOA|low fee HOA|Homeowner&rsquo;s Association |HOMEOWNER ASSOCIATION DUES|Homeowners' Association|resident Homeowner Association|<strong>HOA|Place HOA|Low HOA fees|Low HOA|HOA</a></li>|by HOA| HOA | HOA |hoa |HOA Info|HOA dues|hoa dues|home owners association|Homeowners Association|HOA <span|Homeowner's Association |Homeowner's Association|Home Owners' Association|The HOA|<li>HOA|HOA</li>|&q;HOA&q;|HOA-maintained|included in HOA|neighborhood HOA|Home Owner's Association| high HOA|Inspiration HOA",
					"Homeowner Association");
			
			put("Hotel Residences", 
					"Hotel Residences");
			
			put("Housing Cooperative (Co-Op)", 
					"Housing Cooperative (Co-Op)");
			
			//================ I =====================

			put("Interval Ownership", 
					"Interval Ownership");
			
			//TODO :==================== L =================
			
			put("Land Lease", 
					"Land Lease");
			
			put("Available lofts?|with Loft | a loft,? |Loft or Optional Bedroom|<li>Loft[\\*]*</li>|a loft as|and loft|the loft|lofts and|house loft|<li>Loft[s]*</li>|at Loft|loft plus|loft space|huge lof|loft-like design|loft options available|Loft in|Lofts At|The Lofts|recreational loft|large Loft| Loft</div>|, Loft,|patios. Lofts|Loft</span>|or Loft|City Lofts|loft with|Private Family Loft|<li>\\s*Loft\\s*</li>|entries, loft|, loft[s]*,|flexible loft|loft and|Loft and Bonus Room|loft, and two-car garage|expansive loft|loft-style units|open loft|Lofts At Uptown|lofts and rooftop|spacious loft|upper-level loft|Loft Designs|Loft and Terrace| lofts, and more|Loft and single-story flats|two-story lofts |2-story loft|Loft Apartment|Loft Row|loft-style apartments|Lofts at Village Walk|loft area|</span>Loft</span>| opt. loft home|Loft Home| Lofts is a|second-story loft|Upstairs [l|L]oft|loft upstairs|upstairs loft|loft, and balcony|lofts provide|Loft or Opt. Bedroom|of the Loft| and loft|Floor Loft|Floor Loft|Floor with Loft|Optional Loft|offer(ed|s) a loft|comfortable lofts| in lofts| a loft|gaming loft|loft/game room|gameroom/loft|reading loft|Opt\\. Loft |Loft or Flex Space|Loft or Opt|Offering Lofts|lofts per plan|Den, Loft|Loft or Bedroom| story loft|sq ft loft| Loft/Optional| loft &|Upper Level Loft|Den/Loft|bedroom \\+ Loft|bedroom \\+ study &amp; loft|plus Loft| loft level| lofts or|LOFT LIVING",
					"Loft");
			
			put("luxury residential|luxurious new townhomes|luxurious lifestyle|luxurious single-family|LUXURY GARDEN HOMES|luxurious interior|luxury of home|luxurious main level|[l|L]uxurious [O|o]wner's [S|s]uite|Luxurious Interior|custom luxury|luxury master-planned|luxurious community|Luxury features|luxury design|luxurious standard features|luxury owner retreats|Luxuriously Appointed Interiors|Luxury elevator townhomes|luxurious home|luxurious collection|luxurious new Coach Home|luxury, single family|luxurious features|Luxurious Living Spaces|luxurious dream home|luxurious finishes|luxury designed homes|luxurious condominium|luxury master suites|luxuriously appointed homes|luxurious\\s+single family homes|features luxurious|luxurious maintenance|luxury owner’s suite|LUXURIOUS MASTER SUITE|luxurious amenity|luxurious townhome|luxurious options|luxurious and|LUXURY MID-RISE CONDOS|Luxurious Master Suite|luxurious Owner’s Suite|luxurious resort-style amenities|luxury of living|luxurious multi levels|luxurious owner’s suite|luxurious carriage home|luxurious single-family homes|luxurious finishes|luxury residences |Luxurious Included |luxurious owner's suites|Luxury Included|luxury and convenience|luxurious amenities| luxury finishes| luxurious single level |luxurious master suites|luxurious estate living|new home luxury|luxury townhomes|Stylish luxury meets|warmth, luxury|Luxury Gated Community| luxury flats|Luxury Cottages|Luxury Custom Home|Luxurious new homes|luxury for buyers|luxury villa |many luxury features|luxury-inspired amenities|luxury town home|Luxurious sized Master Suites|luxury style|luxury amenities|luxury real estate community|Luxury Penthouse|luxury ranch-style homes|luxury new home|luxury rental residence|lifestyle and luxury|Luxurious Homes|luxury gated townhome|luxury gated|Luxury Retirement Community|luxury condo|luxury single| luxury living.|luxury neighborhood|new luxury plan|luxury collection|luxurious living|luxury townhomes|luxury life|AFFORDABLE LUXURY|luxury homes|luxury home|luxury patio homes|Luxury Estate Homes|homes that combine luxury|luxury gated communit|Luxury Single-Family Homes|Luxury Single Family Homes|luxury one-| luxury of 37 gated| offer luxury|luxury ranch home|luxury community|luxury apartment|luxury detached|Luxury, garage townhomes|luxury affordable|Luxury Living|luxury townhome|Luxury Villas|luxury single|luxury paired homes|luxury resort|comfort and luxury|Luxury Towhomes"
					+"|luxury of having|Luxurious mediterranean-style|luxurious pool|Luxurious, low-maintenance living|Low-Maintenance Luxury Properties|luxury residence|offering a life of luxury|luxurious floor plan|luxurious detached villas|Luxury First-Floor|luxurious 55\\+ community|luxurious plans|luxury amentities|luxury mid-rise condo|Luxury meets country-style|Luxury, Carriage Homes|luxury listings|Offering the luxury|these luxuries|luxury, gated community|Luxury Communities|feel luxurious|luxury garden apartment|luxury floorplan|designed for luxury|luxurious inside finishes|luxury lakeside living|luxurious single-story|maintaining the luxury|Luxury Properties|luxurious new community|Luxury and understated elegance|beachside luxury|Luxury Traditional|luxurious senior living|embrace a luxurious|comfortable luxury|Luxurious Single-Level|luxurious, low-maintenance homes|Live in luxury|is a luxurious|designed with luxury|ultimate in luxury|luxury-style living| Luxury Garden Home|touch of luxury|Luxury series Homes|luxurious, low-maintenance|with luxury choice|Combining luxury and|and luxury starting|Luxurious Lake| coastal luxury|living in luxury|offers luxury new|Luxury Series plan|luxury coastal community",
					"Luxury Homes");
			
			//=================== M ==================
			
			put("Manor[s]* at | - The Manors|Manors? Collection|The Manors home|Manor - Estate home|MANOR SERIES|Manor Homesites|Manor Estates|Manor Series homes|Windsor Manor home|beautiful Manor home|Manor Home Models|Manors Homes at |Manor Homes</a>|The Manor Collection|Single Family Manor Home|Manor Homes New Home Community|Castleton Manor Community|Estate homes, Manor homes|Manor ranch designed homes|Manor Homes | Manors Homes| Manors|Colonial Manor|Manor Townhomes| Manor Homes| manor house|The Manor - from",
					"Manor Homes");
			
			put("mediterranean-style|Mediterranean style|Mediterranean-inspired exteriors|Mediterranean detail|Mediterranean and Spanish architectural|Mediterranean Series",
					"Mediterranean-Style Homes");
			
			put("MULTI FAMILY|multi\\s*-?\\s*family,|Multifamily condominiums| multi\\s*-?\\s*family |>Multi-Family |Multi family&|<li>Multi-Family</li>|Multi-Family</span>| MULTIFAMILY|designed for multiple families|>MULTIFAMILY", 
					"Multi-Family");

			put("Multi-Family Dwelling", "Multi-Family Dwelling");

			put("Multi-Family Housing Products",
					"Multi-Family Housing Products");
			
			put("Multi-Generational Home|multi-generational living|multi-generational families|Multi-Gen Suites?|Multi-Generational Suites|Optional Multi-Gen Suite|MultiGen Innovation|multigenerational families|Multigeneration family|multi-generational first-floor suite|multi-gen living suite|a Multi-Gen option|multi-generational new home|multi-generational community|multigenerational living|multi-generational situation|multi-generational suite|multi-generational space|multi-generational family|featuring multigenerational|multi-generation living", 
					"Multi-Gen Homes");

			//================= P ====================

			put("Paired Townhome|paired courtyard homes|paired patio|paired home villas|Paired and single-family home|paired residences|paired villa |paired new homes|Paired Homes?|paired patio homes| Paired Ranches|Paired Villa homes|paired villas|paired and single family",
					"Paired Homes");
			
			put("Patio-style home|Patio Home|patio|Patio", 
					"Patio Homes");
			
			put("prairie-style homes|modern prairie home", 
					"Prairie-Style Homes");

			put("Private Residence Club (PRC)", 
					"Private Residence Club (PRC)");
			
			put("Private Resorts", 
					"Private Resort");
			
			//=============== Q ======================
			
			put("Quadraplex ", 
					"Quadraplex");

			//================ S =====================
		
			put("single and multifamily homes|Single-Family Custom Homes|Single-Family Homes| single and multi- family homes|single family home| single- and multi-family|single-family homes|Single Family Homes|Single luxury family|single-family|Single-Family|SINGLE FAMILY|single family|single and multi-family|Single-Family Home |Single Family Homes|single-family home",
					"Single Family");
			
			put("6-plex|sixplex |Six-plex|six-plex", "Sixplex");
			put("7-Plex", "Sevenplex");
			
			//================= T ====================
			
			put("Town Home Sites|stunning Town Home design| Town Home plans|townhome[s]*|<em>Triplex Townhomes|<em>Townhomes| Town Homes| - Townhomes|multi-level townhomes|multilevel townhomes|Luxury Townhomes|2-level townhome| townhomes,| Townhome | townhomes |and townhomes |townhome style| Townhomes</b>|Townhome/Condo |Townhome Condo |and townhomes.|>Townhomes<|<p>Town homes</p>| town&nbsp;home series| town-homes| town homes",
					"Townhomes");
			
			put("townhouses|Townhouse", 
					"Townhouse");
			
			put("Traditional exterior|- Traditional Series|Poplar Traditional|traditional layout|traditional one-story|Traditional three-story|traditional townhome|New Tradition Homes|traditional family homes|traditional single |TRADITIONAL NEW HOME|traditional-style brick homes|Traditional, Low County|Traditions floor plan|traditional architecture|Traditional-style homes|traditional two-story style home|traditional features|Traditional, Bungalow|Craftsman,Traditional|traditional upper level|traditional home arrangement|Traditional & Craftsman style exteriors|Windsor Traditional|traditional floor plans|traditional single family|Traditional Townhomes|traditional ranch-style homes|Traditional architectural style|Traditional Ranch homes|traditionally styled homes|Traditional single family homes|traditional collection| traditional communities|Traditional Singles|traditional-series|traditional three story|traditionally-styled|features Traditional|Traditional, and|Traditional and|Traditional</li>|Traditional Family Neighborhood|<p>Traditional,|Traditional two story home|traditional home|traditional design|traditional elegance|traditional new homes|traditional homes?|traditional neighborhood|Traditional Community|traditional single-family|Traditional Neighborhood Homes|mix of traditional|traditional style and|Cottage, Traditiona|Traditional, Cottage| traditional style|traditional one- and two-story homes|Traditional</div>| traditional two-story|Traditional Texas-style homes|Traditional and Cottage Collection|Traditional and Italian|Traditional",
					"Traditional Homes");
			
			put(" triplexes|Triplex |Tri-plex|tri-plex|3-Plex", 
					"Triplex");
			
			put("Tudor style homes|Craftsman, Tudor",
					"Tudor-Style Homes");

			put("twin \\(attached\\) house|twin-style carriage homes|Twin Homes|Twin Villas|Twin Villa|Twin Home| Twinhomes |Twin Townhomes| twins and single family", 
					"Twin Homes");
			
			put("Two-Family home|2-Family Home|2-Family Home",
					"Two Family Homes");

			//================== V ===================
			
			put("<h1>Villas</h1|Paired Villas|The Villas|Condominium Suites, Villas|ranch Villa|Branch Villas|single family homes, villas,|and villas|attached villas|Villa</em>| Villas</th|Twin Villas|courtyard villa|villas |luxurious villa|/Villa |Villa Homes|Villas | Villa,| villa |villa-style homes|Villa</span>"
					+"| villas,",
					"Villas");
			
			//================= Z ====================
			
			put("Zero-Lot-Line Home", 
					"Zero-Lot-Line Home");
			
			//=====================================
		}
	};
}
