package com.shatam.utils;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class Redirect extends JFrame {

	private static JTextArea textPane;
	static PrintStream old_out = System.out;
	static OutputStream out;

	public static JTextArea getTextPane() {
		return textPane;
	}

	public static void setTextPane(JTextArea textPane) {
		Redirect.textPane = textPane;
	}
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Redirect frame = new Redirect();
					frame.setVisible(true);
					Redirect.redirect();
					System.out.println("dfsd");
					reset();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Redirect() {
		super("## Console ##");
		textPane = new JTextArea();
		textPane.setEditable(false);
		JScrollPane jsp = new JScrollPane(textPane);
		setSize(500, 300);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(jsp);
		setVisible(true);
	}
	
	public static void redirect(){
		Redirect frame = new Redirect();
		//frame.setVisible(true);
		frame.redirectOutput();
	}
	
	public static void reset() {
		System.setOut(old_out);
	}

	public void redirectOutput() {
		
		out = new OutputStream() {
			@Override
			public void write(int b) throws IOException {
				updateTextArea(String.valueOf((char) b));
			}

			@Override
			public void write(byte[] b, int off, int len) throws IOException {
				updateTextArea(new String(b, off, len));
			}

			@Override
			public void write(byte[] b) throws IOException {
				write(b, 0, b.length);
			}
		};

		System.setOut(new PrintStream(out, true));
		System.setErr(new PrintStream(out, true));
		

	}

	private static void updateTextArea(final String text) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				textPane.append(text);
			}
		});
	}

}
