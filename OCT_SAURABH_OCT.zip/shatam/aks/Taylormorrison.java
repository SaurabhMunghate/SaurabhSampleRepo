package com.shatam.aks;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class Taylormorrison extends AbstractScrapper {
	// private static String string;
	CommunityLogger LOGGER;
	static int i = 0;

	public Taylormorrison() throws Exception {

		super("Taylor Morrison Homes", "https://www.taylormorrison.com");
		LOGGER = new CommunityLogger("Taylor Morisson homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper as = new Taylormorrison();
		as.process();
		FileUtil.writeAllText(U.getCachePath() + "Taylor morrison.csv", as.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String mainhtml = U.getHTML("https://www.taylormorrison.com");
		String regurlssec = U.getSectionValue(mainhtml, "\"Search Homes\",\"state\":", "\"bedrooms\"");
		Set s = new HashSet();
		String curl1 = null;
		String regurls[] = U.getValues(regurlssec, "\"value\":\"", "\"}");
		// U.log(regurls.length);
		for (String reg : regurls) {
			String regurl = "https://www.taylormorrison.com" + reg;
			U.log(regurl);
			String reghtml = U.getHTML(regurl);
			String commurls[] = U.getValues(reghtml, "DetailLink\"", "\"\"},\"community");
			U.log(commurls.length);
			for (String curl : commurls) {
				curl1 = curl;
				String commurl = "https://www.taylormorrison.com" + U.getSectionValue(curl, "\"Url\":\"", "\"");
				// U.log(commurl);
				// String commhtml=U.getHTML(commurl);

				s.add(commurl);

			}

		}
		Iterator i = s.iterator();
		U.log(s.size());
		while (i.hasNext()) {

			String a = (String) i.next();

			adddetails(a, curl1);

		}
		U.log(s.size());
	}

	public void adddetails(String commurl, String curl) throws Exception {
		// if(!commurl.contains("https://www.taylormorrison.com/co/denver/castle-pines/timberline-50s"))return;

		U.log(commurl + "====================" + i);
		String commhtml = U.getHTML(commurl);

		String communityname = U.getSectionValue(commhtml, "\"communityName\":\"", "\"");
		U.log(communityname);

		// ======================address============================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";
		// "address":{"address1":"17 Bethesda Church
		// Road","address2":"","city":"Lawrenceville","state":"GA","zip":"30044"},
		String addsec = U.getSectionValue(commhtml, "\"address\":", "},");

		if (addsec != null) {
			addsec = addsec.replace("Florida", "FL");
			addsec = addsec.replace("Tx", "TX");
		}
		U.log(addsec);

		// String address[]=addsec.split("+");
		String add12 = U.getSectionValue(addsec, "\"address1\":\"", "\"");
		if (add12 != null) {
			add[0] = add12;
		} else {
			String add21 = U.getSectionValue(addsec, "\"address2\":\"", "\"");
			add[0] = add21;
		}

		add[1] = U.getSectionValue(addsec, "\"city\":\"", "\"");
		add[2] = U.getSectionValue(addsec, "\"state\":\"", "\"");
		add[3] = U.getSectionValue(addsec, "\"zip\":\"", "\"");

		U.log(Arrays.toString(add));

		// ================================latlagsec=============================================

		String latlagsec = U.getSectionValue(curl, "\"latLng\":{", ",\"photos\":");
		latLong[0] = U.getSectionValue(latlagsec, "\"lat\":", ",");
		latLong[1] = U.getSectionValue(latlagsec, "\"lng\":", "}");

		U.log(Arrays.toString(latLong));

		// =============geo===================================

		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);

		// ===================================floorplansection========================================
		String floorplansec = null;

		String floorplanhtml = U.getHTML(commurl + "/floor-plans");

		if (floorplanhtml != null) {

			floorplansec = U.getSectionValue(floorplanhtml, "\"floorPlansListDataArray\":", "</script");

		}

		// ==================================available
		// home=====================================

		String availablehomesec = null;
		String avaialablehomehtml = U.getHTML(commurl + "/available-homes");

		if (avaialablehomehtml != null) {

			availablehomesec = U.getSectionValue(avaialablehomehtml, "availablePlansList\":", "</script");

		}

		// =====================================================prices==============================================================

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		commhtml = commhtml.replace("0s", "0,000").replace("\"pricing\":\"Low $200&#39;s\"",
				"\"pricing\":\"Low $200,000\"");
		prices = U.getPrices(availablehomesec + floorplansec + commhtml,
				"Low \\$\\d{3},\\d{3}|\"minPrice\":\\d{6}|Priced From the Mid \\$\\d{3},\\d{3}|\"price\":\\d{6}", 0);
		minPrice = prices[0];
		maxPrice = prices[1];
		U.log(Arrays.toString(prices));

		// ==================================sqft=====================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		sqft = U.getSqareFeet(availablehomesec + floorplansec + commhtml,
				" features \\d{4} square feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\"text\":\"Sq. Ft.\",\"value\":\"\\d{4}\"}|\"minSqFt\":\\d{4}",
				0);
		minsqft = sqft[0];
		maxsqft = sqft[1];
		U.log(Arrays.toString(sqft));

		// ============================communitytype=================================

		String commdesc = U.getSectionValue(commhtml, "\"description\":\"", "</community-about>");

		String ctype = null;

		ctype = U.getCommType(commdesc);

		U.log(ctype);

		if (ctype == null)
			ctype = ALLOW_BLANK;

		// ============================propertytype====================================

		String ptype = U.getPropType(commdesc + availablehomesec + floorplansec);
		U.log(ptype);

		// ========================dpropertytype========================================
		String asd = (commdesc + availablehomesec + floorplansec).replace("Single story", "1 Story")
				.replace("{\"text\":\"Story\",\"value\":\"3\"}", "3 Story")
				.replace("{\"text\":\"Story\",\"value\":\"1\"}", "1 Story")
				.replace("{\"text\":\"Story\",\"value\":\"2\"}", "2 Story");
		String dtype = U.getdCommType(asd);
		U.log(dtype);
		// ================================pstatus=========================================
		String pstatus = U.getPropStatus(commdesc + availablehomesec + floorplansec);

		U.log(pstatus);
		if (minPrice == null)
			minPrice = ALLOW_BLANK;
		if (maxPrice == null)
			maxPrice = ALLOW_BLANK;
		if (minsqft == null)
			minsqft = ALLOW_BLANK;
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;

		if (commurl.contains("https://www.taylormorrison.com/co/denver/castle-pines/timberline-50s"))
			add[2] = "CO";

		if (data.communityUrlExists(commurl)) {
			U.log("community repeated");
			LOGGER.AddCommunityUrl(commurl + "********************Repeated url");
			return;
		}

		LOGGER.AddCommunityUrl(commurl);
		data.addCommunity(communityname, commurl, ctype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", ""), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);

		i++;
	}

}
