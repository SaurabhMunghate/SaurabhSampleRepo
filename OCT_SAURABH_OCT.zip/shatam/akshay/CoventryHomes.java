package com.shatam.akshay;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

import net.sf.cglib.transform.impl.AddDelegateTransformer;

public class CoventryHomes extends AbstractScrapper{
	int i = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	
	
//	WebDriver driver = null;
	
	

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new CoventryHomes();
		a.process();

	//	FileUtil.writeAllText(U.getCachePath() + "MHI-McGuyer Homebuilders - Coventry Homes.csv", a.data().printAll());
	}

	public CoventryHomes() throws Exception {

		super("MHI-McGuyer Homebuilders - Coventry Homes", "https://www.coventryhomes.com/");
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Coventry Homes");
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
	String jsonUrls[]= {"https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid=h&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=985.99&zipcode=&zipcoderadius=&amenities=&projectid=",
			//"https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid=d&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=2000&zipcode=&zipcoderadius=&amenities=&projectid=",
		//	"https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid=a&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=985.99&zipcode=&zipcoderadius=&amenities=&projectid=",
		//	"https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid=s&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=985.99&zipcode=&zipcoderadius=&amenities=&projectid=",
			
	};
	for(String ju:jsonUrls) {
		String json=getHTML(ju);
		
		String commSec[]=U.getValues(json, "\"ProjectName\"", "\"MarketedCity\":");
		//U.log(commSec.length);
		for(String comSec:commSec) {
			
			addDetails(comSec);
		}
	}
	
LOGGER.DisposeLogger();
	}
	public void addDetails(String comSec) throws Exception {
		
		
	
	String comurlsec="https://www.coventryhomes.com/"+U.getSectionValue(comSec, "\"ProjectUrl\":\"", "\"");
	
	String url="",commname="";
	if(comurlsec.contains("/communities")) {
		
		String subCommSec[]=U.getValues(comSec, "\"CommunitySeoUrlName\"", "}");
		for(String subComm:subCommSec) {
			
			url="https://www.coventryhomes.com/"+U.getSectionValue(comSec, "\"MetroSeoUrlName\":\"", "\"")+"/"+U.getSectionValue(subComm, ":\"", "\"");
			commname=U.getSectionValue(subComm, "\"SubdivisionName\":\"", "\"");
			
			addOtherDetails(comSec,subComm,url,commname);
		}	
	}
	else {
		
		commname=U.getSectionValue(comSec, ":\"", "\"");
		url=comurlsec;
		
		addOtherDetails(comSec,"", url, commname);
	}
	
		}

	public void addOtherDetails(String comSec,String sec,String url,String commName) throws Exception {
		
		
		
		LOGGER.AddCommunityUrl(url);
		if(data.communityUrlExists(url)) {
			
			LOGGER.AddCommunityUrl("===============repeat"+url);
			return;
		}
//		U.log(url);
//		U.log(commName);
//		
		//getHTML("https://app.mhinc.com/api/PageMetaData/?DBACode=cov&Url=/houston/edgewater-50ft-homesites&Projectid=&Communityid=2043&JobId=&PlanId=&PriceSeriesId=&PageType=&IsTest=0&IsAdmin=1");
		
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		latLong[0]=U.getSectionValue(comSec, "\"Latitude\":\"", "\"");
		latLong[1]=U.getSectionValue(comSec, "\"Longitude\":\"", "\"");
		
		//add=U.getAddressGoogleApi(latLong);
		U.log(comSec);
		
//		U.log(Arrays.toString(add));
//		U.log(Arrays.toString(latLong));
//		U.log(geo);
		
		U.log("========="+j);
		j++;
	}
	
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
	//	U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"216.169.73.65",34679));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language","en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			urlConnection.addRequestProperty("authorization", "Basic Y292Ym95bDo3OEJGMDQ4Ri04OEY5LTREQTMtODdBNS1FRUY0NkE2NzVBRkU6RkRFN0ZDM0YtMTM1Qi00OENFLUFDMDQtMjhBRTQ4QTQ2QTcz");
			urlConnection.addRequestProperty("referer", "https://www.coventryhomes.com/");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			
			U.log("gethtml expection: "+e);
			

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}
