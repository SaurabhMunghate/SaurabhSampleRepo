package com.shatam.akshay;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class NewDreesHomes extends AbstractScrapper {
	final String BASE_URL = "https://www.dreeshomes.com";
	int j = 0;
	WebDriver driver = null;

	CommunityLogger LOGGER;

	public NewDreesHomes() throws Exception {
		super("Drees Homes", "https://www.dreeshomes.com/");
		LOGGER = new CommunityLogger("Drees Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new NewDreesHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Drees Homes.csv", a.data().printAll());
	}

	String RegionCode[] = { "AUST", "CINCI", "CLEVE", "DALL", "HOUS", "INDI", "JAX", "NASH", "RALE", "WASH" };

	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		// TODO Auto-generated method stub
		int i = 0;
		do {
			String regHtml = U.getHTML("https://dhp.dreeshomes.com/prod/communities?code=" + RegionCode[i]);

			regHtml = regHtml.replace("\"area_name\":\"", "newdata\"area_name\":\"").replace("}}]}}", "}}]}}newdata");
			String sections[] = U.getValues(regHtml, "\"area_name\":\"", "newdata");
			// U.log(sections.length);
			for (String section : sections) {
				addDetails(section,regHtml);
			}
			i++;
		} while (i < 10);
		LOGGER.DisposeLogger();
	}

	public void addDetails(String section,String regHtml) throws Exception {

		String comurl = U.getSectionValue(section, "\"details_url\":\"", "\",");
		
		//if(!comurl.contains("raleigh-durham/community/averette_ridge/averette_ridge"))return;
		
		
		LOGGER.AddCommunityUrl(comurl);
		U.log(comurl + "===================" + j);
		String comName = "";//U.getSectionValue(section, "\"community_name\":\"", "\"");
		U.log(comName);
		String comType = U.getCommType(U.getSectionValue(section, "\"biography\":\"", "\",\"market"));
		U.log(comType);
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		// add[0]=U.getSectionValue(section, "\"sales_address\":\"", "\"");
		add[1] = U.getSectionValue(section, "\"city\":\"", "\"");
		add[2] = U.getSectionValue(section, "\"state\":\"", "\"");
		add[3] = U.getSectionValue(section, "\"zip\":\"", "\"");

		//if (add[0] == null || add[0] == ALLOW_BLANK) {
			String html = U.getHtml(comurl, driver);
			comName=U.getSectionValue(html, "<h1 data-v-4feebad0=\"\">", "</h1>");
			U.log(comName);
			add[0] = U.getSectionValue(html, "<p data-v-fcc0551c=\"\" class=\"margin-left-20 addrtext\">", "</p>");
	//	}

//		if(comurl.contains("https://dreeshomes.com/custom-homes/austin/community/caliterra/caliterra_80s"))add[0]="131 Waters View Court";
//		if(comurl.contains("https://dreeshomes.com/custom-homes/austin/community/caliterra/caliterra_80s"))add[0]="131 Waters View Court";
//		if(comurl.contains("https://dreeshomes.com/custom-homes/austin/community/provence/provence"))add[0]="16705 Moineau Drive";
//		if(comurl.contains("https://dreeshomes.com/custom-homes/indianapolis/community/stone_haven/stone_haven"))add[0]="9028 Stone Trace Blvd";

		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		latLong[0] = U.getSectionValue(section, "\"latitude\":", ",");
		latLong[1] = U.getSectionValue(section, "\"longitude\":", ",");

		if (add[0] == null || add[1] == null || add[2] == null || add[3] == null || add[0].length() < 3) {
			if (latLong[0] != null && latLong[1] != null) {
				add = U.getAddressGoogleApi(latLong);
				geo = "TRUE";
			}
		}
//		if(latLong[0]==null||latLong[1]==null) {
//			if(add[1]!=null && add[2]!=null) {
//				latLong=U.getlatlongGoogleApi(add);
//				geo="TRUE";
//			}		
//		}
		U.log(geo);

		U.log(Arrays.toString(add));

		U.log(Arrays.toString(latLong));
		String minPrice = null, maxPrice = null;
		String minsqft = null, maxsqft = null;
	
		String prices[]=U.getPrices(html, "\\$\\d{3},\\d{3}", 0);
		minPrice=prices[0];
		maxPrice=prices[1];
		U.log(Arrays.toString(prices));
		String sqft[]=U.getSqareFeet(html, ">\\d{1},\\d{3}|- \\d{1},\\d{3}", 0);
		minsqft=sqft[0];
		maxsqft=sqft[1];
		U.log(Arrays.toString(sqft));
		
	//	U.log(section);
//		String desc="";
//		try {
//		 desc=U.getSectionValue(regHtml, "\"profile\":\"", "\"details_url\":\""+comurl+"");
//		}
//		catch(NullPointerException ne) {}
//		U.log(desc);
		
		String pType = U.getPropType(section.replace("Single Family", ""));
		U.log(pType);
		//U.log("MMMMMMMMM "+Util.matchAll(section, "[\\s\\w\\W]{30}Luxurious[\\s\\w\\W]{30}", 0));
		String dtype = U.getdCommType(section);
		U.log(dtype);

		section=section.replace("Move-in Ready Homes", "quick move-in");
		section=section.replace("\"unit_status\":\"[Coming Soon]\"", "");
		section=section.replace("\"directions\":\"Coming Soon", "");
		section=section.replace("build-to-order and quick move-in opportunities", "").replaceAll("Just one quick move-in home remains in this popular|planned to open Spring 2020|Pool Coming Spring 2021|The Lodge is coming soon|schools coming soon|ISD coming soon", "");
		section=section.replace("Wooded Home Sites in Amenity-Rich Community", "Wooded Homesites Available");
		String pstatus = U.getPropStatus(section.replace("\"unit_status\":\"[Closeout]\"", ""));
	
		String quickmovesec=U.getSectionValue(html, "class=\"gtm-qmi-jump-link\"", "</a>");
		
		if(quickmovesec!=null) {
			if(pstatus.length()>4) {
				pstatus +=", Quick Move-Ins";
			}
			else {
				pstatus="Quick Move-Ins";
			}
		}
		
		
		
		
		U.log(pstatus);
	//	U.log("MMMMMMMMM "+Util.matchAll(section, "[\\s\\w\\W]{30}Quick Move-in[\\s\\w\\W]{30}", 0));
	//	U.log("MMMMMMMMM "+Util.matchAll(section, "[\\s\\w\\W]{30}now selling[\\s\\w\\W]{30}", 0));
		if (data.communityUrlExists(comurl)) {
			LOGGER.AddCommunityUrl(comurl + "*************repeated************");

			return;
		}
		if (maxPrice == null || maxPrice.length() == 2) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null || minPrice.length() == 2) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (comType == null)
			comType = ALLOW_BLANK;

		data.addCommunity(comName.replace("&#x27;s", " &"), comurl, comType);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		// U.log(pstatus.length());
		data.addPropertyType(pType, dtype);
		data.addPropertyStatus(
				pstatus.replace("Quick Move-Ins Homes Coming Soon, Quick Move-Ins", "Quick Move-Ins Homes Coming Soon").replace("Quick Move-in", "Quick Move-Ins").replace("Quick Move-Ins, Quick Move-Ins", "Quick Move-Ins").replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon"));
		data.addNotes(U.getnote(U.getHTML(comurl)));

		j++;

	}
}
