package com.shatam.akshay;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class NuHomes extends AbstractScrapper {

	public NuHomes() throws Exception {
		super("Nu Homes", "https://www.nuhomesoklahoma.com");
		LOGGER = new CommunityLogger("Nu Homes");
		// TODO Auto-generated constructor stub
	}

//4cornerhomes
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new NuHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Nu Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainhtml = U.getHTML("https://www.nuhomesoklahoma.com/communities");
		String comSections[] = U.getValues(mainhtml, "class=\"CommunityCard_media\"",
				"<div class=\"CommunityCard_detailButton\"");
		U.log(comSections.length);
		for (String comSec : comSections) {
			String comUrl = "https://www.nuhomesoklahoma.com"
					+ U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");

			U.log(comUrl);
			addDetails(comUrl);
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comUrl) throws Exception {

//		if(!comUrl.contains("https://www.nuhomesoklahoma.com/communities/norman/landrun"))return;
		String commHtml = U.getHTML(comUrl);

		String communityName = ALLOW_BLANK;

		communityName = U.getSectionValue(commHtml, "<h2 class=\"DetailOverview_heading\"",
				"<span class=\"DetailOverview_subheading\"");
		communityName = communityName
				.replaceAll("data-reactid=\"\\d{3}\"><!-- react-text: \\d{3} -->|<!-- /react-text -->", "");
		U.log(communityName);

		// ==================commdescribtion
		String commdesc = U.getSectionValue(commHtml, "name=\"description\"", "<link rel=\"manifest\"");

		// =============community address
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";

		String addresssection = U.getSectionValue(commHtml, "<span class=\"DetailOverview_subheading\"",
				"</span></h2>");
		addresssection = addresssection.replaceAll(
				"Highland Meadows|data-reactid=\"\\d{3}\"><!-- react-text: \\d{3} -->|<!-- /react-text -->|<!-- react-text: \\d{3} -->",
				"");
		U.log(addresssection);

		String address[] = addresssection.split("[|,]");
		U.log(Arrays.toString(address));
		U.log(address.length);
		add[0] = address[0];
		add[1] = address[1];

		// String address2[]=add[2].split("[ ]");
		// U.log(Arrays.toString(address2));
		// U.log(address2.length);
		add[2] = "OK";
		add[3] = Util.match(addresssection, "\\d{5}");
		U.log(Arrays.toString(add));

		U.log(address.length);

		String latlongsection = U.getSectionValue(commHtml, "<a href=\"https://www.google.com/maps/place/", "/@");
		latLong = latlongsection.split(",");

		U.log(Arrays.toString(latLong));

		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if ((add[0].trim().length() < 3 || add[0] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);

		/// avaialable hoem plans section

		String availfloorplans = comUrl + "#plans";
		String availhtml = "";
		String avasec = "";
		availhtml = U.getHTML(availfloorplans);
		String availhomehtml = "";
		String availdesc = "",storysection="";
		String availplans[] = U.getValues(availhtml, "<div class=\"PlanCard_media\"", "<div class=\"PlanCard_inner\"");
		// String floorplandesc=U.getSectionValue(availhtml,
		U.log("====="+availplans.length);
		// "pdf\"},\"description\":\"", "\"garages\"");
		for (String availplansec : availplans) {
			availhomehtml = U
					.getHTML("https://www.nuhomesoklahoma.com/" + U.getSectionValue(availplansec, "href=\"/", "\""));

			storysection += U.getSectionValue(availhomehtml, "<div class=\"DetailOverview_headingWrapper\"", "Download Brochure");
			availdesc += U.getSectionValue(availhomehtml,  "Description</h3>", "</div></div></div></div>");
			avasec += availplansec;

		}

		//// quick move in homes

		String quickurls = comUrl + "#homes";
		String quickhtml = U.getHTML(quickurls);
		String quicsecdet = "", quickdesc="",quickStorySec="";
		String quickhomehtml = "";
		String quicksections[] = U.getValues(quickhtml, "<div class=\"HomeCard_wrapper\" ",
				"</div></div></div></div>");
		U.log("====="+quicksections.length);
		for (String qu : quicksections) {
		//	String quicurl= 
			//U.log("====="+quicurl);
			quickhomehtml = U.getHTML("https://www.nuhomesoklahoma.com" +U.getSectionValue(qu, "href=\"", "\""));
			quickStorySec+=U.getSectionValue(quickhomehtml, "<h2 class=\"DetailOverview_heading\"", "<span class=\"DetailOverview_sectionItem\"");
			quickdesc+=U.getSectionValue(quickhomehtml, "Description</h3>", "</div></div></div></div>");
			quicsecdet += qu;
		}

		/// prices

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;

		prices = U.getPrices((commdesc + avasec + quicsecdet).replaceAll("0s", "0,000"), "starting in the \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}<", 0);

		minPrice = prices[0];
		maxPrice = prices[1];

		U.log(Arrays.toString(prices));

		// ======================sqft

		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		sqft = U.getSqareFeet(commdesc + avasec + quicsecdet, "\">\\d{1},\\d{3}<", 0);

		minsqft = sqft[0];
		maxsqft = sqft[1];

		U.log(Arrays.toString(sqft));

		// communtiyg type
		String commtype = U.getCommunityType(commdesc);
		U.log(commtype);

//		if(availdesc!=null)
//			availdesc = availdesc.replace("perfect luxury home", "perfect luxury homes ");
		
		String ptype = U.getPropType((commdesc + availdesc + quickdesc));
		U.log(ptype);

		U.log(Util.matchAll(commdesc + availdesc + quickdesc, "[\\s\\w\\W]{30}perfect luxury home[\\s\\w\\W]{30}", 0));

		storysection=storysection.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">1</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "1 Story")
				.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">2</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "2 Story")
				.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">3</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "3 Story");
		
		
		quickStorySec=quickStorySec.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">1</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "1 Story")
				.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">2</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "2 Story")
				.replaceAll("<span class=\\\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">3</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "3 Story");
		String dtype = U.getdCommType(storysection+commdesc+quickStorySec);
		U.log(dtype);
 
		String quickmoveinsection="";
		try {
		quickmoveinsection=U.getSectionValue(commHtml, "<span class=\"DetailOverview_sectionItem DetailOverview_sectionItem-count\"", "</a></span></div>");
		//quickmoveinsection=quickmoveinsection.replaceAll("<!-- /react-text --><span class=\"badge\" data-reactid=\"\\d{3}\">", "");
		//U.log(quickmoveinsection);
		}
		catch(NullPointerException ne ) {
			
		}
		String pstatus = U.getPropStatus(commdesc+quickmoveinsection);

		U.log(pstatus);

		note = U.getnote(commHtml);
		if (maxPrice == null)
			maxPrice = ALLOW_BLANK;
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "*************repeated************");

			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		data.addCommunity(communityName, comUrl, commtype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("&amp;", " & "), add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);

	}

}
