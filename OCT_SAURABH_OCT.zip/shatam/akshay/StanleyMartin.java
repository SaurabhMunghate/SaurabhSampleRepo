package com.shatam.akshay;

import java.util.Arrays;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.b_061_080.ExtractStanleyMartinHomes;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class StanleyMartin extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicate = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	int k=0;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new StanleyMartin();
		a.process();
		U.log("duplicate=" + duplicate);
		FileUtil.writeAllText(U.getCachePath() + "Stanley Martin Homes.csv", a.data().printAll());

	}

	public StanleyMartin() throws Exception {

		super("Stanley Martin Homes", "https://www.stanleymartin.com/");
		LOGGER = new CommunityLogger("Stanley Martin Homes");
	}

	public void innerProcess() throws Exception {
		
		// Your code here
		String html1 = U.getHTML("https://www.stanleymartin.com/");
//		U.log(html1);

		String section = U.getSectionValue(html1,
				"<option disabled selected class=\"text-white\">Choose a location</option>", "</select>");
		// U.log(section);
		String links[] = U.getValues(section, "value=\"", "\">");
		U.log(links.length);
		for (String itom : links) {
			itom = "https://www.stanleymartin.com" + itom;
			// U.getCache(itom);
			if (itom.contains("ProjectDetail.asp")) {
				LOGGER.AddCommunityUrl(itom + "::::::::::::::::::::::Region redirects to community");
			}
			if (itom.contains("https://www.stanleymartin.com#") || itom.contains("www.stanleymartin.comhttps")
					|| itom.contains("https://www.stanleymartin.com/north-carolina/wake-forest"))
				continue;
			String html2 = U.getHTML(itom);
			String urls[] = U.getValues(html2, "container-fluid p-0", "col-lg-8 col-xs-12");
			// U.log(urls.length +":::::::::::::"+itom);
			for (String sec : urls) {
				String url = U.getSectionValue(sec, "<a href=\"", "\"");
				url = "https://www.stanleymartin.com" + url;
				// U.log("url: "+url);
				addDetails(url, sec);
				i++;
			}

			inr++;

		}
		// U.log(i);
		LOGGER.DisposeLogger();
	}

	public void addDetails(String url, String sec) throws Exception {
		// U.log("PAGE :" + url);
		
		
		// if(k<65)continue;
	//	if(j>100) {
	//	 if(!url.contains("https://www.stanleymartin.com/virginia/richmond/williamsburg/kelton-station/the-monroe"))return;
		if (url.equals("https://www.stanleymartin.com#overview") || url.contains(
				"https://www.stanleymartin.com/north-carolina/coastal-carolinas/southport/st-james-plantation")) {
			LOGGER.AddCommunityUrl(url + "===return=====");
			return;
		}

		String comurl = url;
		LOGGER.AddCommunityUrl("communityurl::::::::" + url);
		String html = U.getHTML(comurl);
		U.log(comurl + "=======" + j);

		String commname = U.getSectionValue(html, "<span class=\"text-white\">", "</span>");
		U.log(commname);

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";

		
		String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latlagsec=U.getSectionValue(html, "title=\"Address\" href=\"https://www.google.com/maps", "\"");
		

		String addresssec = "";

		String sec1 = ALLOW_BLANK;
		if (html.contains("fas fa-map-marker-alt fa-2x mb-2")) {
			sec1 = U.getSectionValue(html, "<i class=\"fas fa-map-marker-alt fa-2x mb-2\">",
					"<div class=\"col-sm-12 col-md-4 d-flex\">").replace("Unit A, <br />", "");
		}
		if (sec1 != null && sec1 != ALLOW_BLANK) {
			addresssec = U.getSectionValue(sec1, "</div>", "</a>").trim();
			String address[] = addresssec.split(",");
			add[0] = address[0];
			add[1] = address[1].replace("<br />", "").trim();
			String statezip[] = address[2].split(" ");
			U.log(statezip.length);
			U.log(Arrays.toString(statezip));
			add[2] = statezip[1];
			add[3] = statezip[2];
			U.log(addresssec);
		}

		U.log(Arrays.toString(add));
		U.log(add.length);
		if(latlagsec!=null) {
			latlagsec=latlagsec.replace("-+Woodcreek+Crossing", "").replace("-+Club+", "").replace("-+Northside", "").replaceAll(",\\d{4}m|,\\d{3}m|,\\d{2}z|,\\d{2}.\\d{2}z", "");
			latlong[0]=U.getSectionValue(latlagsec, "/@", ",");
			latlong[1]="-"+U.getSectionValue(latlagsec, "-", "/");
		}
		
		if((add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && add[2]==ALLOW_BLANK && add[3]==ALLOW_BLANK) && (latlong[0]==ALLOW_BLANK && latlong[1]==ALLOW_BLANK)) {
			if(url.contains("oldfield") && url.contains("south-carolina")) {
				add[1]="Oldfield";
				add[2]="SC";
				latlong=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlong);
				geo="TRUE";
			}
			if(url.contains("kelton-station") && url.contains("virginia")) {
				add[1]="Kelton Station";
				add[2]="VA";
				latlong=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlong);
				geo="TRUE";
			}
			
		}
		if(latlong[0]==null || latlong[1]==null ) {
			latlong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		
		U.log(latlong.length);
		
		U.log(latlagsec);
		
		U.log(Arrays.toString(latlong));
		
		U.log("GEO: " + geo);

		/// homes section
		String prisec1 = "";
		String prisec2 = "";

		String homepricesec[] = U.getValues(html,
				"<span class=\"community-title mt-0 text-success text-right font-weight-bold\">", "</span>");
		String movepricesec[] = U.getValues(html,
				"<span class=\"community-title text-success text-right font-weight-bold\">", "</span>");

		for (String psec1 : homepricesec) {
			prisec1 += "," + psec1.trim();
		}

		for (String psec2 : movepricesec) {
			prisec2 += "," + psec2.trim();
		}

		U.log(prisec1 + "=====" + prisec2);

		prices = U.getPrices(prisec1 + prisec2, ",\\$\\d{3},\\d{3}", 0);

		U.log(Arrays.toString(prices));
		String minPrice = ALLOW_BLANK;
		minPrice = prices[0];
		String maxPrice = ALLOW_BLANK;
		maxPrice = prices[1];
		String ssec = "";
		try {
			String sqftsec[] = U.getValues(html, "<span class=\"font-weight-bold\">",
					"<span class=\"w-100 float-right\">");

			for (String sq : sqftsec) {
				sq = sq.replace(" ", "");
				ssec += sq;
			}
		} catch (NullPointerException ne) {
		}
		// U.log(ssec);

		sqft = U.getSqareFeet(ssec, "\\d{1},\\d{3}|\\d{2},\\d{3}", 0);
		U.log(Arrays.toString(sqft));

		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		minsqft = sqft[0];
		maxsqft = sqft[1];

		String ctype = U.getCommType(html);
		U.log(ctype);
		String ptype = U.getPropType(html);
		

		String dtype = U.getdCommType(html);
		U.log(dtype);

		html = html.replace("Only FIVE home sites remain", "Only five home sites remain")
				.replace("<h3>Only ONE Homesite Remains</h3>", "only one homesite remains").replaceAll(
						"title=\"Move-In-Ready\">|mir = \"Move-In-Ready\"|block rounded-0 mt-2\">Move-In-Ready|<a href=\"/move-in-ready\" title=\"Move-In-Ready\"|meeting rooms will be opening soon|Amenities are now open|The Woodward Single Family are now open|Holy Cow - now open!|entertainment- coming soon|near the grand opening of our townhome model|Subway and more coming soon|current close out neighborhood|coming soon&nbsp;|coming Spring 2020</li>|grand opening of our models|alt=\"Pre-Construction Pricing!\"|pre-grand opening incentives|<em>New Section Coming Soon!</em>",
						"");

		String pstatus = U.getPropStatus(html);
	//	U.log("MMMMMMM " + Util.matchAll(html, "[\\s\\w\\W]{30}Ready[\\s\\w\\W]{30}", 0));
		// U.log("MMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}Final Homesite Coming
		// Soon[\\s\\w\\W]{30}", 0));

		if (!html.contains(">0</span>\" Move-In-Ready(s)")) {
			if (pstatus.length() > 4) {
				pstatus += ", Move-in Ready";
			} else {
				U.log("fgf");
				pstatus = "Move-in Ready";
			}
		}
		
		if(url.contains("charleston/bluffton/oldfield/the-foster")||url.contains("charleston/bluffton/oldfield/the-horlbeck")||url.contains("charleston/bluffton/oldfield/the-riverside")
				||url.contains("south-carolina/charleston/bluffton/oldfield/the-moreland")||url.contains("outh-carolina/charleston/bluffton/oldfield/the-tidalview")
				||url.contains("virginia/richmond/williamsburg/kelton-station/the-monroe"))pstatus=ALLOW_BLANK;

		if (url.contains("tanleymartin.com/south-carolina/columbia/gilbert/foxchase-ii"))
			pstatus += ", Last Chance";//// from image

		U.log(pstatus);
		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (ctype == null)
			ctype = ALLOW_BLANK;
		
		if(ptype.contains("Townhouse,") && ptype.contains(", Townhome")) {
			ptype=ptype.replace("Townhouse,", "");
		}
		U.log(ptype);
		
		data.addCommunity(commname.trim(), url, ctype);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon")
				.replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon"));
		data.addNotes(U.getnote(html));
	//	}
		j++;

	
	}
}
