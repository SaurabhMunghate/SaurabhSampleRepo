/**
 * @author Sampada Santosh
 * @date 12/4/2017
 * 
 */
package com.shatam.b_001_020;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Driver;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;
import org.bouncycastle.jcajce.provider.asymmetric.dsa.DSASigner.stdDSA;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.seleniumhq.jetty7.servlets.ConcatServlet;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.opera.core.systems.QuickMenu;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractTollBrothers extends AbstractScrapper 
{
	StringWriter writer = null;
	CommunityLogger LOGGER;
	static int dup=0;
	int i=0;
	static int err=0;
	public int inr=0;
	static int j=0;
	
	static WebDriver driver = null;
	
	public static void main(String[] args) throws Exception 
	{
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		AbstractScrapper a = new ExtractTollBrothers();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Toll Brothers.csv", a.data().printAll());
		
		driver.quit();
		
		U.log("dup::"+dup);
		U.log("err::"+err);
	}

	public ExtractTollBrothers() throws Exception {

		super("Toll Brothers", "https://www.tollbrothers.com/");
		LOGGER = new CommunityLogger("Toll Brothers");
			}

	public void innerProcess() throws Exception {
		writer = new StringWriter();
		String baseUrl="https://www.tollbrothers.com/";
		String html=U.getHTML(baseUrl);
				
		String stateSection = U.getSectionValue(html, "<div class=\"state-searches\">", "</nav>");
		
		String[] regionUrls=U.getValues(stateSection, "\"metro-areas-states\">", "title=\"");
		U.log("total region::"+regionUrls.length);
		
		for(String regionUrl:regionUrls){
			regionUrl=U.getSectionValue(regionUrl, "href=\"", "\"");
			U.log("regionUrl  === "+regionUrl);
			String regionHtml=U.getHTML(regionUrl);
			
			String[] comSections =U.getValues(regionHtml, "<div class=\"item-contain js-search-item js-", "</article>");//"<p><strong>Phone</strong>:"); 
			U.log(comSections.length);
			
			for(String comSec: comSections)
			{
				//U.log("comSec::"+comSec);
				i++;
//				if(i>=201 && i<=300)
//				if(i>=301)
//				if(i>=201 && i<=300)
//				if(i>=200)
//				if(i>=101 && i<=199)
				
				
//				if(i>=40 && i<=100) //done
				
//				if(i>=47 && i<=50) 
//					if(i>86 && i<=100) 
//						if(i>128 && i<=150)  
//							if(i>170 && i<=200)  
//								if(i>220 && i<=250) 
//									if(i>250 && i<=300) 
//										if(i>300 && i<=350) 
//											if(i>350 && i<=400)  
//												if(i>400)  
					
				{
					String comUrl=U.getSectionValue(comSec, "<a class=\"optCommLink\" href=\"", "\"");
					U.log("comUrl:::::::::::"+comUrl);
					String comId=U.getSectionValue(comSec, "data-commid=\"", "\">");
//					if (comUrl.contains("mycolemanhome")) {
//						//U.log("\nExternal site http://www.tollbrothers.com" + url);
//						LOGGER.AddCommunityUrl("mycolemanhome------->"+comUrl);
//						dup++;
//						continue;
//					}
					if(comUrl.contains("www.sharpresidential.com/communities/")) {
//						U.log("????????????1");
//						U.log("comUrl======"+comUrl);
						
							addNewDetails(comUrl,comSec);		
					}
					
					else if(!comUrl.contains("/ExternalURLClick") && !comUrl.contains("https://www.tollbrothers.com") &&  !comUrl.contains("https://www.sabalhomessc.com") &&!comUrl.contains("https://www.tollbrothersidaho.com")){
						if(comUrl.contains("https://www.mycolemanhome.com/")) continue; //272	Coleman Homes --> we have took this builder.
//						U.log("????????????2");
//						U.log("comUrl======"+comUrl);
						
							addApartment(comUrl,comSec,comId);
						
//						
					}else if(comUrl.contains("https://www.tollbrothersidaho.com")){
//						U.log("????????????3");
//						U.log("comUrl======"+comUrl);
						
							addIdahoDetails(comUrl,comSec);
						
						
						U.log("Hello");
						j++;
					}else if(comUrl.contains("/ExternalURLClick")){
//						U.log("????? 4");
//						U.log("comUrl"+comUrl);		
						
							addDetails("http://www.tollbrothers.com" + comUrl,comSec);
						
						
						U.log("Hello");
						j++;
					}
					else {
//						U.log("????????????5");
//						U.log("comUrl======"+comUrl);
						
							addDetails(comUrl,comSec);///////////////
						
					}
				}
			}
			//break;
		}
		U.log("count:"+i);
		U.log("external:"+j);
		LOGGER.DisposeLogger();
	}

	
	private void addIdahoDetails(String comUrl, String commData) throws Exception {
		
	//	try{
		{
			// .......................Community Url...........................
//			if (!comUrl.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Arizona/Allevare-at-Verrado"))return;
			
			U.log("==" + comUrl);
			U.log("ppppppppp"+commData);
			// ......................Community Name...........................
			String html = U.getHTML(comUrl);
			
			String dropSec=U.getSectionValue(html, "<head>", "</head>");
			html =html.replace(dropSec, "");
			
			String commName = U.getSectionValue(commData, "<h2>", "<");
			U.log(commName);
			if (this.data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl); 

			// ..............Community type, Property status,Derived property
			// type,Property type...........................
			String rem=U.getSectionValue(html, "getMarkerImage(name)","Sales Center</li>");
			String typeHtml=html;
			
		
			
			//========= Community type ===================
			
			html =html.replaceAll("Spurwing Golf Course|Golf Course - 10 minutes|disc golf|Purple Sage Golf Course|Lakeview Golf Course|RedHawk Golf Course", "");
			html=U.removeSectionValue(html, "<h3>What's Nearby</h3>", "</div>");
			String communitytype = U.getCommunityType(html);
			U.log(communitytype);
			
			//==================== floor plan Home ============
			String planhtml="";
			String[] plans=U.getValues(html, "<a href=\"https://www.tollbrothersidaho.com/floorplans", "\"");
			U.log("Floor Homes count =: "+plans.length);
			String secPlan =ALLOW_BLANK;
			for(String plan:plans){
				U.log(plan);
				planhtml=U.getHTML("https://www.tollbrothersidaho.com/floorplans"+plan);
//				U.log(U.getSectionValue(planhtml, "<div class=\"entry-content\">", "div class=\"includes-and-options\">"));
				secPlan += U.getSectionValue(planhtml, "<div class=\"entry-content\">", "div class=\"includes-and-options\">");
			}
			//============ Quick Home Section =================

			
			String quickHtml="";
			String[] quicksUrls=U.getValues(html, "<a href=\"https://www.tollbrothersidaho.com/home", "\"");
			U.log("Quick Home count=: "+quicksUrls.length);
			for(String quickurl:quicksUrls)	{
				U.log("quickurl : "+quickurl);
				quickHtml+=U.getHTML("https://www.tollbrothersidaho.com/home"+quickurl);
				U.log("qqqq"+quickurl);
			}
			
			String modelHomes ="";
			String[] modelUrls=U.getValues(html, "a href=\"https://www.tollbrothersidaho.com/model-homes/", "\"");
			U.log("Quick Home count=: "+modelUrls.length);
			for(String model:modelUrls)	{
				U.log("quickurl : "+model);
				modelHomes+=U.getHTML("https://www.tollbrothersidaho.com/model-homes/"+model);
				U.log("qqqq"+model);
			}
			
				
			
			//===================== Derived Community Type ===============
			String dtype = U.getdCommType((html+planhtml+quickHtml+modelHomes+secPlan.replaceAll("CARRIAGE HILL NORTH", "").replaceAll("CARRIAGE HILL NORTH\">", "")+quickHtml).replaceAll("value=\".* Ranch\"|Cartwright Ranch</|Sterling Ranch</| // Sterling Ranch|// Cartwright Ranch|CartwrightRanch\":|SterlingRanch\":|Sterling Ranch Sales Center", ""));
			U.log(dtype);
			
			commData=commData.replaceAll("now-selling", "now selling");
			//========== Property Status =============
			
			typeHtml = typeHtml.replace("Just a few opportunities remain", "Just few opportunities remain").replaceAll(" community pool, coming soon| Model Homes Coming Soon|\\(Open Fall 2018\\)</li>|School</a>\\s*\\(Open Fall 201|href=\"/move-in-ready-homes/\">- Move In Ready Homes</option>|This new phase|>Move In Ready Homes</a></li>|</i>\\s+Available|<!-- Available|>View Available", "")
					.replace("NEW Star Middle School (Open Fall 2018)</a", "");
			String propstatus = U.getPropStatus((typeHtml+commData).replace("Move-in Ready", "").replaceAll("Limited availability\\. Please call", ""));
			U.log(propstatus);
			

			// ..........................Address and Lat , Lng ..................................

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK }, lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;

			String addSec = U.getSectionValue(html, "<h2>Sales Center Directions</h2>", "<b>");
			U.log(addSec + "------");
			
			if (addSec != null) {
				addSec = U.getSectionValue(addSec, "<p>", "</p>").trim();
				geo = "FALSE";
				addSec = addSec.replaceAll("<br/>|<br />", ",").replace("Nampa", "Nampa,").replace("Nampa,,", "Nampa,");
				U.log("-------------------------------" + addSec);
				String[] addr=addSec.replaceAll("NOW SELLING! Located at the Lilac Springs Sales Center at the|SALES OFFICE &amp; DECORATED MODEL NOW OPEN!|Call for an appointment.|, Nampa Idaho 83687|\\(Can-Ada Road, south of Ustick Road, north of Cherry\\)", "").replaceAll("NOW SELLING!|COMING SOON!", "").split(",");
				U.log(Arrays.toString(addr));
				if(addr.length>2)
				{
				add[0]=addr[0].replace("&amp;", "&").trim();
				add[1]=addr[1].trim();
				add[3]=Util.match(addr[2], "\\d{5}");
				if(add[3]!=null)
				add[2]=addr[2].replace(add[3], "");
				}
			}
			U.log(Arrays.toString(add));

			String latlng_section = U.getSectionValue(html,	"center: new google.maps.LatLng", "};");
			U.log(latlng_section);
			if(latlng_section!=null) {
			lat = U.getSectionValue(latlng_section, "(", ",").trim();
			lng = U.getSectionValue(latlng_section, ",", ")").trim();
			}
			if(latlng_section==null) {
				lat = U.getSectionValue(html, "data-lat=\"", "\"");
				lng = U.getSectionValue(html, " data-lng=\"", "\"");
				if(lat==null)lat="-";
			}
			U.log(lat + "===========" + lng);
			String latlng[] = { lat, lng };

			if(latlng[0].equals("0") || latlng==null || latlng[0]==ALLOW_BLANK){
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo="TRUE";
			}
		
			// ........................Prizes ...........................
			String price[] = U.getPrices(html,
					"<span class=\"price\">\\s*\\$\\d+,\\d+\\s*</span>|<td>\\$\\d{3},\\d{3}\\s*[*]*</td>|<h3>\\$\\d{3},\\d{3}</h3>", 0);
			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log(minPrice);
			U.log(maxPrice);

			// ............................ square feet.....................
			String sqft[] = U.getSqareFeet(html+modelHomes,
					"<td>\\d{1},\\d{3}</td>|<td>\\d{4}</td>|<td>\\d,\\d+ <span|\\d,\\d+ Sq. Ft.\\s*|Starting at [0-9]{4} sq feet.|\\d{4} Square Feet|From \\d,\\d{3} SF", 0);
			String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			String remove=U.getSectionValue(html, "<div class=\"listings community-move-in-ready-listings\">", "<head>");
			U.log("============re"+remove);
			if(add[2].trim().length()!=2)
				add[2]=USStates.abbr(add[2]);
			
			if(add[2]==null)add[2]=ALLOW_BLANK;
			U.log(add[0]+"  "+add[1]+"      "+add[2]+"     "+add[3]);
			
			
			//============= PropType =======================
			html = html.replaceAll("A premier Coleman Homes community with affordable luxury homes and prime amenities", "");
			html=html.replaceAll("carriage|Carriage|- Carriage", "").replace("- Carriage", "").replace("Carriage", "");
	//U.log("secPlan:::::::::::::"+secPlan);
			String ptype=U.getPropType(html+comUrl+quickHtml+modelHomes+secPlan.replaceAll("AT CARRIAGE HILL NORTH", ""));
			U.log("propType= "+ptype);
			if(quicksUrls.length>0 && !propstatus.contains("Move-in")) {
				if(propstatus.length()>2) {
					propstatus=propstatus+", Move-in Ready Homes";
				}
				else {
					propstatus="Move-in Ready Homes";

				}
			}
			//status from images
			if(comUrl.contains("/the-oaks-north/"))propstatus ="Now Selling";//image
//			if(url.contains("/legacy/") || url.contains("heron-river/"))propstatus ="Now Selling, "+ propstatus;//image
			if(add[0].contains("117 Segal Drive GPS Users: 1426 W Baltimore Pike"))
				add[0]="117 Segal Drive";
			String notes=U.getnote(html);
			if(comUrl.contains("https://www.canvastempe.com/"))notes="Now Pre Leasing";
			if(comUrl.contains("https://www.liveunionplace.com/"))notes=ALLOW_BLANK;
			// ...................adding in csv...............................
			html=html.replace("affordable luxury homes and prime amenities","");
			data.addCommunity(commName, comUrl, communitytype);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1].trim(), geo);
			data.addPropertyType(ptype, dtype);
			data.addPropertyStatus(propstatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(notes.replace("Now Leasing, Lease Now", "Now Leasing"));
			data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
			}
		
//		}catch (Exception e) {}
	}

	private void addApartment(String comUrl, String comSec,String comId) throws Exception {
		//TODO
	//	if(!comUrl.contains("https://www.livehaverly.com"))return;
     //   if(!comUrl.contains("https://www.liveyournotion.com/")) return;
		
		//		if (i>=140)return; 
		
//		try {
		U.log("Count "+i);
		U.log(comUrl);
		U.log("FROM HERE");
	//	U.log("cmSec"+comSec);
		
		if(comUrl.contains("http://liveoleander.com/"))comUrl=comUrl.replace("http:", "https:");
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"************************REPEATED");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl+"************************Toll Brothers Apartment Living");

//		if(!comUrl.contains("https://www.livethemorgan.com"))return;
		
		String comName = U.getSectionValue(comSec, "class=\"item-name notranslate js-sort-name\">", "<");
		U.log("comName :: "+comName);
		if(comUrl.contains("themewsatprincetonjunction")) {
			String comHtml = U.getHtml(comUrl, driver);
			U.log(U.getCache(comUrl));
		}
		
		String comHtml = U.getPageSource(comUrl);
		U.log(U.getCache(comUrl));

		String comType = ALLOW_BLANK;
		//----Address------
		String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLng [] ={ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		String addSec = U.getSectionValue(comHtml, U.getCapitalise(comName.trim())+"</a>&nbsp;&nbsp;", "&nbsp;&nbsp;<a");
		U.log(addSec);
		if (addSec==null && comHtml.contains("<div class=\"address\">") && !comUrl.contains("themewsatprincetonjunction") ) {
			addSec=U.getNoHtml(U.getSectionValue(comHtml, "<div class=\"address\">", "</a>"));
		}
//		if(comUrl.contains("https://www.livethekendrick.com/"))addSec = "275 Second Avenue, Needham, MA 02494";
//		if(comUrl.contains("https://www.parcprinceton.com/"))addSec = "3000 Goldfinch Blvd, Princeton, NJ 08540";
		if(comUrl.contains("https://www.liveunionplace.com/") && addSec==null) addSec = "200 K Street Northeast, Washington, DC 20002";
		if(comUrl.contains("https://www.parcriverside.com")) addSec = "1011 First St SE, Washington, DC 20003";
//		if(comUrl.contains("https://www.kensingtonplacenj.com"))addSec = "527 Old Bridge Turnpike, East Brunswick, NJ 08816";
		if(comUrl.contains("nampa-id-homes/carriage-hill-west/"))addSec = "Lake Lowell Ave, Nampa, Idaho 83686";
		if(comUrl.contains("https://www.liveriverworks.com"))addSec = "45 N Main St.,Phoenixville, PA 19460";
		if(comUrl.contains("New-Jersey/West-Saddle-Estates"))addSec = "West Saddle River Road,Ho-Ho-Kus, NJ 07423";
		if(comUrl.contains("https://www.parcprinceton.com"))addSec = "3000 Goldfinch Blvd, Princeton, NJ 08540";
		if(comUrl.contains("https://www.kellerhomes.com/cordera"))addSec = "4411 Captain Jack Lane,Colorado Springs, CO 80924";
		if(comUrl.contains("https://www.kellerhomes.com/cumbre-vista"))addSec = "6458 Cumbre Vista Way,Colorado Springs, CO 80924";
		if(comUrl.contains("https://www.kellerhomes.com/elan-at-wolf-ranch"))addSec = "536 Chapel Hills Drive #150,Colorado Springs, CO 80920";
		if(comUrl.contains("https://www.kellerhomes.com/wolf-ranch"))addSec = "6411 Tumble Creek Drive,Colorado Springs, CO 80924";
		
		
		if(addSec == null){
			String sec = U.getSectionValue(comHtml, "id=\"google-map\">", "</article>");
			if(sec != null){
				addSec = U.getSectionValue(sec, "Sales Center</h2><p><p>", "</p>");
				U.log(addSec);
				if(addSec != null){
					addSec = addSec.replace("<br />", ",").replace(", Idaho", ", ID").replace("Nampa Idaho ", "Nampa, ID ");
					add = U.getAddress(addSec);
				}
				if(add[0] != ALLOW_BLANK){
					String [] marker = U.getValues(sec, "<div class=\"marker\"", "</div>");
					latLng[0] = U.getSectionValue(marker[marker.length-1], "data-lat=\"", "\"");
					latLng[1] = U.getSectionValue(marker[marker.length-1], "data-lng=\"", "\"");
				}
			}
			if(addSec == null){
				addSec = U.getSectionValue(comHtml, "Sales Center Directions</h2>", "</p>");
				if(addSec != null){
					addSec = addSec.replace("<br />", ",").replace(", Idaho", ", ID").replace("Nampa Idaho ", "Nampa, ID ")
							.replace("<p>", "");
					add = U.getAddress(addSec);
				}
			}
			
		}
		//Neighbourhood
		if(comHtml.contains("/neighborhood/")){
			String neighbourhoodUrl = null;
			if(comUrl.endsWith("/")) neighbourhoodUrl = comUrl+ "wp-content/themes/tollbrothers-child/JSON/neighborhood.json";
			else  neighbourhoodUrl = comUrl+ "/wp-content/themes/tollbrothers-child/JSON/neighborhood.json";
			U.log("neighbourhoodUrl :"+neighbourhoodUrl);
			String neighbourhoodJson = U.getHTML(neighbourhoodUrl);
	//		U.log(neighbourhoodJson);
			if(neighbourhoodJson != null){
				String latlngSection = U.getSectionValue(neighbourhoodJson, "\"property\":", "}}");
				if(latlngSection != null){
					latLng[0] = U.getSectionValue(latlngSection, "\"lat\":", ",");
					latLng[1] = U.getSectionValue(latlngSection, "\"lng\":", ",");
					geo="True";
				}
			}
			
		}
		if(!comUrl.contains("tollbrothwes")){
			String tempAddressSection = U.getSectionValue(comHtml, "<div class=\"address address-border testing\">", "</a></div>");
			U.log("tEMP ADD SECV::"+tempAddressSection);
			
			if(tempAddressSection != null){
				String latLngSection = null;
				if(tempAddressSection.contains("/@")){
					latLngSection = Util.match(tempAddressSection, "\\d{2}\\.\\d{2,}\\s?,\\s?-\\d{2,3}\\.\\d{2,}");
					if(latLngSection != null) latLng = latLngSection.split(",");
				}
				else{
					String googleUrl = U.getSectionValue(tempAddressSection, "<a href=\"", "\"");
					String googleMapHtml = U.getHTML(googleUrl);
					//U.log(StringEscapeUtils.unescapeHtml4(googleMapHtml));
					latLngSection = U.getSectionValue(googleMapHtml, "APP_INITIALIZATION_STATE", "]");
//					U.log(latLngSection);
					if(latLngSection != null){
						latLngSection = latLngSection.replaceAll("=\\[\\[\\[\\d{3,}\\.\\d{4,},", "");
						String vals[] = latLngSection.trim().split(",");
						if(vals[0].startsWith("-")){
							latLng[1] = vals[0];
							latLng[0] = vals[1];
						}else{
							latLng = vals;
						}
					}
				}
				tempAddressSection = tempAddressSection.replaceAll("<.*?>", "").replaceAll("\\s{1,}", " ");
				if(tempAddressSection != null)addSec = tempAddressSection;
//				U.log(tempAddressSection);
			}
//			if(tempAddressSection == null && comUrl.contains("themewsatprincetonjunction")) {
//				U.log("IN HERE");
//				String addSection = U.getSectionValue(comHtml, "<div class=\"address\">", "<div class=\"phone \">");
//				U.log("addSection: "+addSection);
//				String sec1 = U.getSectionValue(addSection, "<span class=\"line\">", "</span>");
//				String sec2 = U.getSectionValue(addSection, "</span><span class=\"line\">", "</span>");
//				U.log("IN HERE ADD : "+sec1+""+sec2);
//			}
		}
//		if(comUrl.contains("https://www.theyardsatoldstate.com/")) {
//			U.log("kkkkk");
//			addSec="121 S Allen Street, State College, PA 16801";
//		}
//		if(add[0]==null||add[0]==ALLOW_BLANK) {
//			String addSec2=U.getSectionValue(comHtml, "data-address=\"", "\"");
//			add=U.getAddress(addSec2);
////			latLng[0]=U.getSectionValue(comHtml, "data-lat=\"", "\"");
////			latLng[1]=U.getSectionValue(comHtml, " data-lng=\"", "\"");
//		}
		if(comUrl.contains("https://www.canvastempe.com/")) {
			addSec="1028 E. Orange Street, Tempe, AZ 85281";
			latLng[0] = "33.4184902";
			latLng[1] = "-111.9224631";
		}
		if(comUrl.contains("http://emersononkrog.com"))
			addSec = "49 Krog Street, Atlanta, GA 30307";
		
		if(comUrl.contains("https://www.oxleyedgewood.com/"))
			addSec = "1223 Hardee St NE, Atlanta, GA 30307";
		if(comUrl.contains("https://www.theyardsatoldstate.com/"))
			addSec="1830 Blue Course Dr, State College, PA 16801";
		U.log(">>> comUrl: "+comUrl);
		

		
		U.log("Address is : "+Arrays.toString(add));
		
		if(addSec != null){
			add = U.getAddress(addSec);
		}
			
		if(comUrl.contains("http://liveoleander.com/")||comUrl.contains("https://www.westerlydallas.com/")) {
			String addsec= U.getSectionValue(comHtml, "href=\"https://maps.google.com/?daddr=", "\"");
			add = U.getAddress(addsec);
		}
//==		
//		if(comUrl.contains("https://www.westerlydallas.com/")) {
//			String addsec= U.getSectionValue(comHtml, "href=\"https://maps.google.com/?daddr=", "\"");
//			add = U.getAddress(addsec);
//		}
/*		if(comUrl.contains("https://www.mycolemanhome.com/")){
			U.log("===================================");
			add = U.getAddress("11245 W Rosette Drive, Nampa, ID 83686");
		}*/
		
		//------Navigation Tab-----
		String floorPlanHtml = ALLOW_BLANK;
		String neighborhoodHtml = ALLOW_BLANK;
		String residentHtml = ALLOW_BLANK;
		String amentiesHtml = "";
		String navSec = U.getSectionValue(comHtml, "<ul id=\"menuElem\">", "</ul>");
		String nwSqftSec=ALLOW_BLANK;
		int lotCount=0;
		String noOfUnits=ALLOW_BLANK;
		if(navSec == null)
			navSec = U.getSectionValue(comHtml, "<ul id=\"menu-main", "</ul>");
		
//		U.log("ff"+navSec);
		
		if(navSec != null){
			String[] navUrls = U.getValues(navSec, "<a href=\"", "\"");
			for(String navUrl : navUrls){
				U.log(navUrl);
				if(navUrl.contains("/Floor-plans.aspx")||navUrl.contains("/floor-plans/") || navUrl.contains("orange/cameo/") || navUrl.contains("online-leasing/")) {
					if (navUrl.contains("https:")) {
//						if(comUrl.contains("https://www.livecameoca.com/")) {
						U.log("navUrl====="+navUrl);
							floorPlanHtml = U.getHtml(navUrl, driver);///////
							String midUrl=U.getSectionValue(floorPlanHtml, "<div id=\"engrain-container\" class=\"\"><iframe id=\"sightmap\" src=\"", ";");
							U.log("mid url"+midUrl);
							if(midUrl==null) {
								String midUrlSec=U.getSectionValue(floorPlanHtml, "<iframe id=\"sightmap\"", "</iframe>");
								if(midUrlSec!=null)
								midUrl=U.getSectionValue(midUrlSec, "src=\"", "\"");
								U.log("mid url"+midUrl);
							}
							if(midUrl!=null) {
							String midHtml=U.getHTML(midUrl);
							String sightSec=U.getSectionValue(midHtml, "window.__APP_CONFIG__ = {","}");
							String sightUrl=U.getSectionValue(sightSec, "\"href\":\"", "\"");
							sightUrl=sightUrl.replace("\\","");
							U.log("Sight Url"+sightUrl);
							String sightHtml=U.getHTML(sightUrl);
							
							JsonParser parser =new JsonParser();
							Object obj=parser.parse(sightHtml);
							JsonObject flrJsonObj = (JsonObject)obj;
							JsonObject dataJsn=(JsonObject)flrJsonObj.get("data");
							JsonArray array=(JsonArray)dataJsn.get("units");
							U.log("json size"+array.size());
							
			//NoOF UNITS				
							lotCount=array.size();
							noOfUnits=Integer.toString(lotCount);
							if(noOfUnits.equals("0"))
								noOfUnits=ALLOW_BLANK;
							
						     for(int i=0;i<+array.size();i++) {
								JsonObject flrpln=(JsonObject)array.get(i);
							//	U.log("ppp"+flrpln);
								
								  nwSqftSec+=" "+flrpln.get("display_area").getAsString();
							//	U.log("NWSQFT SEC"+nwSqftSec);
							}
							}
							
//					}
						}
//						else
//							floorPlanHtml = U.getPageSource(navUrl);
					else {
//						if(comUrl.contains("https://www.livecameoca.com/"))
							floorPlanHtml = U.getHtml(navUrl, driver);
//						else
//						floorPlanHtml = U.getPageSource(comUrl+navUrl);
					}
				}
				
				
				if(navUrl.contains("/Residents.aspx")) {
					residentHtml = U.getPageSource(comUrl+navUrl);
				}
				if(navUrl.contains("/Neighborhood.aspx")) {
					neighborhoodHtml = U.getPageSource(comUrl+navUrl);
				}
				if(navUrl.contains("/amenities")){
					if(navUrl.startsWith("http"))amentiesHtml = U.getPageSource(navUrl);
					else amentiesHtml = U.getPageSource(comUrl+navUrl);
				}
				if(navUrl.contains("-floor-plans/")) {
					floorPlanHtml = U.getPageSource(navUrl);
				}
				
				if(navUrl.contains("/neighborhood/")) {
					neighborhoodHtml = U.getPageSource(navUrl);
				}
				if(navUrl.contains("/about-")){
					if(navUrl.startsWith("http"))amentiesHtml = U.getPageSource(navUrl);
					else amentiesHtml = U.getPageSource(comUrl+navUrl);
				}
			}
		}
		
//dATE		String myFloorPlanUrl="https://sightmap.com/app/api/v1/910pd7qlp2z/sightmaps/"+comId;
//		U.log("MY FLR JSN URL"+"https://sightmap.com/app/api/v1/910pd7qlp2z/sightmaps/"+comId);
//		String myFloorHtml=U.getHTML(myFloorPlanUrl);
//		JsonParser parser =new JsonParser();
//		Object obj=parser.parse(myFloorHtml);
//		JsonObject flrJsonObj = (JsonObject)obj;
//		JsonObject dataJsn=(JsonObject)flrJsonObj.get("data");
//		JsonArray array=(JsonArray)dataJsn.get("units");
//		U.log("json size"+array.size());
//		String nwSqftSec=ALLOW_BLANK;
//		for(int i=0;i<+array.size();i++) {
//			JsonObject flrpln=(JsonObject)array.get(i);
//		//	U.log("ppp"+flrpln);
//			if(!flrpln.get("display_area").getAsString().equals(null))
//			  nwSqftSec=flrpln.get("display_area").getAsString();
//			U.log("NWSQFT SEC"+nwSqftSec);
	//	} dATE
//		String myFloorHtml=U.getHTML(myFloorPlanUrl);
//		//U.log("MYYYY"+myFloorHtml);
//		String jsonData=myFloorHtml;
//		JSONObject obj= new JSONObject(jsonData);
//		JSONArray jarr=(JSONArray)obj.get("units");
//		for(int i=0;i<jarr.length();i++) {
//			U.log("inside json"+i);
//		}
		
		
		if (comHtml.contains("<h2>Floorplans and Pricing <a")) {
			String floorVals[]=U.getValues(comHtml, "<tr class=\"collection-floorplans\">", "</tr>");
			for (String floors : floorVals) {
				String floorUrl=U.getSectionValue(floors, "href=\"", "\"");
				U.log("FloorData: "+floorUrl);
				String temphtml=U.getHTML(floorUrl);
				residentHtml+=U.getSectionValue(temphtml, "<div class=\"floorplan-overview\">", "</ul>");
//				floorPlanHtml+
			}
			floorPlanHtml+=" "+residentHtml;//addition date feb 2022
		}
		if (comHtml.contains("<div class=\"community-model-home\">")) {
			String moveInSections[]=U.getValues(comHtml, "<div class=\"community-model-home\">", "</a>");
			for (String moveIns : moveInSections) {
				String movInurl=U.getSectionValue(moveIns, "href=\"", "\"");
				U.log("movInurl: "+movInurl);
				try {
					String Html=U.getHTML(movInurl);
					String sec=U.getSectionValue(Html, "<div class=\"floorplan-content-area\">", "<div class=\"listing-map\" id=\"directions\">");
					floorPlanHtml+=sec;
				} catch (Exception e) {
					// TODO: handle exception
				}
				
			}
		}
		
//		if(comUrl.contains("https://www.livecameoca.com/"))
//			floorPlanHtml = U.getHTML("https://cameo.prospectportal.com/orange/cameo/");
		
		//--------lallng------
		if(neighborhoodHtml.length()>4 && latLng[0] == ALLOW_BLANK){
			latLng[0] = U.getSectionValue(neighborhoodHtml, " latitude='", "'");
			latLng[1] = U.getSectionValue(neighborhoodHtml, "longitude='", "'");
		}
		if(latLng[0]==null) {
			String ll=U.getSectionValue(neighborhoodHtml, "new google.maps.LatLng(",")");
			if(ll!=null)
				
			latLng=ll.split(",");
			U.log(ll);
		}
		U.log(Arrays.toString(latLng));
		if(latLng[0]==null|| latLng[0] == ALLOW_BLANK ||latLng[0].length()<4){
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo = "TRUE";
		}
		
		if(add[0]==null||add[0].length()<4) {
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo="TRUE";
		}
		//------Price----------
		String minPrice = ALLOW_BLANK,maxPrice = ALLOW_BLANK;
		comHtml = comHtml.replaceAll("0s", "0,000");
		
		String[] prices =U.getPrices(comHtml+comSec+floorPlanHtml, "\\$\\d{3},\\d{3}", 0);
		
		if(comUrl.contains("https://www.kellerhomes.com")) {
			String Quick = U.getHTML("https://www.kellerhomes.com/quick-move-in-homes");
			prices =U.getPrices(comHtml+comSec+floorPlanHtml+Quick, "\\$\\d{3},\\d{3}", 0);
		}
		
		minPrice = (prices[0]==null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
		U.log(minPrice + "\t" + maxPrice);
		
		//------SQFt----------
		String minSqFt = ALLOW_BLANK,maxSqFt = ALLOW_BLANK;
	U.log("PPPPPPP"+Util.matchAll(nwSqftSec+comHtml+comSec+floorPlanHtml,"[\\w\\W\\s]{50}1,000[\\w\\W\\s]{50}",0));
		String [] sqft = U.getSqareFeet((nwSqftSec+comHtml+comSec+floorPlanHtml).replaceAll("an 11,000 sq. ft. clubhouse|11,000-square-foot clubhouse|access to a 9,000 sq. ft. clubhouse.|including a 9,000-square-foot community center|9,000-square-foot clubhouse|including a 9,000-square-foot community center |data-sort=\"\\d+\"", ""),
				"\\d,\\d{3} sq. ft.|\\d{3} sq. ft.|\\| \\d,\\d{3} SQ FT|\\| \\d{3} SQ FT|>\\d,\\d{3}-\\d,\\d{3} Sq. Ft.</td>|>\\d,\\d{3} Sq. Ft.</td>|>\\d{3}-\\d{3} Sq. Ft.</td>|>\\d{3} Sq. Ft.</td>|\\d{1},\\d{3} SF\\s+</p>|Sq. Ft\\s+</span>\\s+<span class=\"value\">\\s+\\d{1},\\d{3}\\s+</span>|Sq. Ft\\s+</span>\\s+<span class=\"value\">\\s+\\d{3}\\s+</span>|size\">\\s+\\d{1},\\d{3} SQ FT\\s+</div>|size\">\\s+\\d{3} SQ FT\\s+</div>|<td class=\"sqft\" >\\d+ Sq\\. Ft\\.</td>|<li>\\d,\\d{3} Sq\\. Ft\\.</li>|<li>Starting at \\d,\\d{3} Square Feet</li>|\\d,\\d{3} Square Feet", 0);
		
		minSqFt = (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
		maxSqFt = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
		U.log("Sqft"+ minSqFt+" "+maxSqFt);
//		U.log("F<LOORHTML"+floorPlanHtml);
		
//       if(comUrl.contains("https://www.parcplymouthmeeting.com")) {//taken from IMAGE
//    	   minSqFt="622";
//    	   maxSqFt="1245";
//       }
//       if(comUrl.contains("https://www.livethemorgan.com")) {
//    	   minSqFt="609";
//    	   maxSqFt="1127";
//       }
	//	U.log(">>>>>>>>>>>>"+Util.matchAll(nwSqftSec+comHtml+comSec+floorPlanHtml, "[\\s\\w\\W]{30}1000[\\s\\w\\W]{30}", 0));
		U.log(">>>>>>>>>>> "+minSqFt + "\t" + maxSqFt);
		//-------propertyType
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+comSec+neighborhoodHtml+residentHtml+amentiesHtml, "[\\s\\w\\W]{50}Luxury Apartment[\\s\\w\\W]{50}", 0));

		String propType = ALLOW_BLANK;
		propType = U.getPropType((comHtml+comSec+neighborhoodHtml+residentHtml+amentiesHtml).replace("luxury apartment in Decatur", "").replace("Luxury Apartments in Decatur",""));
				
		//--------derivedType
		String dType = ALLOW_BLANK;
		dType = U.getdCommType((comHtml+comSec+neighborhoodHtml+residentHtml+floorPlanHtml).replaceAll("TERLING RANCH|ranch/\">Cartwright Ranch</a>|Cartwright Ranch|ranch/\">Sterling Ranch</a>|Sterling Ranch", ""));
				
		//-----ComTYpe
		comType = U.getCommType(comHtml+comSec+neighborhoodHtml+residentHtml+amentiesHtml);
		
		if(comUrl.contains("https://www.dullesgreene.com")){minSqFt="750";maxSqFt="1360";}
		
		if(comUrl.contains("https://www.kensingtonplacenj.com")){
			minSqFt="679";maxSqFt="1584";
			comType="Resort Style";};
		
		if(comUrl.contains("https://www.liveriverworks.com")){minSqFt="511";maxSqFt="1240";}
		
		if(comUrl.contains("https://www.livethemorgan.com")){
//			minSqFt="609";maxSqFt="1163";
			latLng = "40.7201563,-74.0429093".split(",");
			geo = "False";
		}
		
		if(comUrl.contains("https://www.parcplymouthmeeting.com")){
			latLng = "40.1109994,-75.2771509".split(",");
			geo = "False";
		}
		
		if(comUrl.contains("https://www.parcriverside.com")){
			minSqFt="468";maxSqFt="626";
			latLng = "38.8781716,-77.0083907".split(",");
			geo = "False";
		}
		
		if(comUrl.contains("https://www.parcwestborough.com")){minSqFt="777";maxSqFt="1411";}
		
		if(comUrl.contains("https://www.themewsatprincetonjunction.com")){
			maxSqFt="1322";         //from img maxSqFt="796";
//			latLng = "40.3073305,-74.6465714".split(",");
//			geo = "False";
		}
		
		if(comUrl.contains("https://www.liveoleander.com/")) {
		//	minSqFt = "580";maxSqFt = "1,443";
			latLng = "33.8265398,-84.3376033".split(",");
			geo = "False";
		}
//		if(comUrl.contains("https://www.theyardsatoldstate.com/")) {
//			latLng = "40.7940852,-77.8629114".split(",");
//			geo = "TRUE";
//		}
		
		if(comUrl.contains("https://www.oxleyedgewood.com/")){
			minSqFt = "1898";maxSqFt = "2833";
		}
		
		if(comUrl.contains("https://www.liveunionplace.com/")){
		//	minSqFt="593";maxSqFt="1370";
			latLng = "38.9028844,-77.0053659".split(",");
			geo = "False";
		}
		
		if(comUrl.contains("https://www.livethekendrick.com/")){
			propType = propType+",Courtyard";
		//	minSqFt="541";maxSqFt="1,292";
		}
		
		
//		if(comUrl.contains("https://www.ospreyatlanta.com/")){
//			minSqFt="462";maxSqFt="1426";
//		}
		
		
		//-------
		comHtml = comHtml.replaceAll("(data-title|alt)=\"Coming|plans are already selling|Court is NOW|center is now open|Limited availability\\. Please call fo|assignments coming soon|>Lease Now</a>|<h2>Move-in Ready Homes</h2>\\s+<p>No homes available</p>|ref=\"/move-in-ready-homes/\">Move In Ready Homes</a>|Move-in ready residences now available.\" />|pool, coming|Model Homes Coming|dle School \\(Open Fall 2018\\)</a>|we’re sold", "");
		//----Status
		String status = ALLOW_BLANK; String popSec = ALLOW_BLANK;
		if(comHtml.contains("<div class=\"title\">") && comUrl.contains("livehaverly.com")) {
			popSec = U.getSectionValue(comHtml, "<div class=\"title\">", "</div>");
			U.log("popSec: "+popSec);
		}
		
		//U.log(">>>STATUS>>>"+Util.matchAll(comHtml+comSec,"[\\w\\W\\s]{50}Now Available[\\w\\W\\s]{50}",0));
		status = U.getPropStatus((popSec+comHtml+comSec).replaceAll("brand-new apartments coming summer 2022|apartment homes are arriving summer 2022.|Pre-leasing is NOW AVAILABLE|>Coming Soon to<|THREE days away from our grand opening|<b>Coming Soon to</b> Sleepy Hollow|apartment homes now|Coming Soon to</b> Dallas|Coming Soon to</b> Decatur", ""));
		U.log("Prop Status"+status);
	//	U.log("==============>"+Util.matchAll(comHtml+comSec, "[\\w\\s\\W]{30}Now Open[\\w\\s\\W]{30}", 0));
		
		if(comUrl.contains("https://www.asterturtlecreek.com")){status="Now Open"; minSqFt="515"; maxSqFt="1366";
		}
		if(comUrl.contains("https://www.mycolemanhome.com/idaho-communities/heron-river/"))status = status+", Now Selling";//Img
		
		String note = U.getnote(comHtml.replaceAll("50\\% leased!! #TollBrothers|Visit our Virtual|Virtual Leasing Center|VIRTUAL LEASING CENTER|Lease now and receive|Lease now starting|Now leasing. Learn more|Lease Now\\s*<", ""));
		
		note = note.replace("Virtual Leasing, Now Leasing", "Now Leasing");
		
		if(add[0].contains("117 Segal Drive GPS Users: 1426 W Baltimore Pike"))
			add[0]="117 Segal Drive";
	//	if(comUrl.contains("https://www.canvastempe.com/"))note="Now Pre Leasing";
		if(comUrl.contains("https://www.liveunionplace.com/"))note=ALLOW_BLANK;
		
		//from image 17 march dattaraj
		if(comUrl.contains("https://www.liverafferty.com")) status = "Arriving Early 2024";
		
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0].replace(",", ""), add[1], add[2].trim(), add[3].trim());	
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note.replace("Now Leasing, Lease Now", "Now Leasing").replace("Pre-leasing, Leasing Now", "Pre-leasing"));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);
//		}catch (Exception e) {}
	}
	public void addNewDetails(String comUrl,String comSec) throws Exception {
		
//		try {
		U.log(comUrl);

		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"************************REPEATED");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl+"************************Toll Brothers Sharp Residential");

//		U.log(comSec);
//		if(!comUrl.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Arizona/Allevare-at-Verrado"))return;
		String comName = U.getSectionValue(comSec, "class=\"item-name notranslate js-sort-name\">", "<");
		U.log("comName :: "+comName);
		String comHtml = U.getHTML(comUrl);
		String comType = ALLOW_BLANK;
		//----Address------
		String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLng [] ={ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		String addSec = U.getSectionValue(comHtml, "id=comm_address>", "</a><div><a");
		if(addSec!=null)
		{
			addSec=addSec.replaceAll("<br>", ",").replaceAll("<a\\s*href=https://maps.google.com/maps/dir/(.*?)>", "");
			add = U.getAddress(addSec);
		}
		U.log(Arrays.toString(add));
		String latlng[] = null;
		String latlngSec = U.getSectionValue(comHtml, "var static_map_url=\"https://maps.googleapis.com/maps/api/staticmap?center=", "&zoom=");
		U.log(latlngSec);
		latlng = latlngSec.split(",");

		//------------floorPlanData---------------
		String floorPlanHtml = ALLOW_BLANK;
		String floorplans[] = U.getValues(comHtml, "href=\"https://www.sharpresidential.com/floorplan/", "\"");
		for(String plan:floorplans) {
			floorPlanHtml += U.getHTML("https://www.sharpresidential.com/floorplan/"+plan);
		}
		//------------availHomesData---------------
				String availHomesData = ALLOW_BLANK;
				String availHomes[] = U.getValues(comHtml, "href=\"/available-homes/", "\"");
				for(String home:availHomes) {
					availHomesData += U.getHTML("https://www.sharpresidential.com/available-homes/"+home);
				}
		//------Price----------
		String minPrice = ALLOW_BLANK,maxPrice = ALLOW_BLANK;
		String[] prices =U.getPrices(comHtml+comSec+floorPlanHtml+availHomesData, "\\$\\d{3},\\d{3}", 0);
		
		minPrice = (prices[0]==null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
		U.log(minPrice + "\t" + maxPrice);
//		
		//------SQFt----------
		String minSqFt = ALLOW_BLANK,maxSqFt = ALLOW_BLANK;
		String [] sqft = U.getSqareFeet(comHtml+comSec+floorPlanHtml, "\\d,\\d{3} SQ FT", 0);
		
		minSqFt = (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
		maxSqFt = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
		U.log(minSqFt + "\t" + maxSqFt);
	
		//-------propertyType
		String propType = ALLOW_BLANK;
		propType = U.getPropType(comHtml+comSec+floorPlanHtml+availHomesData);
				
		//--------derivedType
		String dType = ALLOW_BLANK;
		dType = U.getdCommType(comHtml+comSec+floorPlanHtml+availHomesData);
				
		//-----ComTYpe
		comHtml=comHtml.replaceAll("Active Adult", "");
		comType = U.getCommType(comHtml+comSec);

		//----Status
		String status = ALLOW_BLANK;
		status = U.getPropStatus(comHtml+comSec);
		
		if(add[0].contains("117 Segal Drive GPS Users: 1426 W Baltimore Pike"))
			add[0]="117 Segal Drive";
		String notes=U.getnote(comHtml);
		if(comUrl.contains("https://www.canvastempe.com/"))notes="Now Pre Leasing";
		if(comUrl.contains("https://www.liveunionplace.com/"))notes=ALLOW_BLANK;
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0].replace(",", ""), add[1], add[2].trim(), add[3].trim());	
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addNotes(notes.replace("Now Leasing, Lease Now", "Now Leasing"));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
//		}catch (Exception e) {}
	}

	

	int cnt = 0;
	public void addDetails(String url,String comSec) throws Exception {
		
//		try {
	//TODO:	Single execution
	//	if(!url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/New-York/Edge-on-Hudson-Residences-by-Toll-Brothers/Brownstones-at-Edge-on-Hudson"))return;


	
		U.log("Count "+i);
		
	{	
		if (url.contains("/ExternalURLClick?")) {
			//U.log("\nExternal site http://www.tollbrothers.com" + url);
			LOGGER.AddCommunityUrl("extenal sites------->"+url);
			dup++;
			return;
		}
		if (url.contains("mycolemanhome")) {
			//U.log("\nExternal site http://www.tollbrothers.com" + url);
			LOGGER.AddCommunityUrl("mycolehttps://www.tollbrothers.com/luxury-homes-for-sale/Colorado/Corderamanhome------->"+url);
			dup++;
			return;
		}
		if (url.contains("sabalhomessc")) {
			//U.log("\nExternal site http://www.tollbrothers.com" + url);
			LOGGER.AddCommunityUrl("sabalhomessc------->"+url);
			dup++;
			return;
		}
		if (this.data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl("*****************REPEATED**************"+ url);
			dup++;
			return;
		}
		
		if(url.contains("https://www.mycolemanhome.com/idaho-communities/nampa-id-homes/carriage-hill-west/")){
			LOGGER.AddCommunityUrl("*****************RETURNED**************"+ url);
			dup++;
			return;
		}//Toll Brothers Apartment Living
		
		if(url.contains("https://www.mycolemanhome.com/idaho-communities/nampa-id-homes/carriage-hill-west/")){
			LOGGER.AddCommunityUrl("*****************RETURNED**************"+ url);
			dup++;
			return;
		}//redirected
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Virginia/Dominion-Valley-Country-Club/Villas")){
			LOGGER.AddCommunityUrl("*****************RETURNED**************"+ url);
			dup++;
			return;
		}//redirected
		

		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Texas/Belterra-Estate-Collection")){
			LOGGER.AddCommunityUrl("*****************RETURNED**************"+ url);
			dup++;
			return;
		}//redirected 17 Sept
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Reserve-at-Makefield")){
			LOGGER.AddCommunityUrl("*****************RETURNED**************"+ url);
			dup++;
			return;
		}
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/California/Victoria-at-Plum-Canyon") ||
				url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/South-Carolina/Chastain-Glen")){
			LOGGER.AddCommunityUrl("*****************RETURNED**************"+ url);
			dup++;
			return;
		}//redirected
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Utah/Toll-Brothers-at-Rosecrest/Reserve-Collection"))
		{
			LOGGER.AddCommunityUrl("*****************NO DATA**************"+ url);
			//dup++;
			return;
		}
		
		
		
		LOGGER.AddCommunityUrl(url);

//		if(!url.contains("https://www.canvastempe.com/"))return;
		https://www.tollbrothers.com/luxury-homes-for-sale/Nevada/Regency-at-Stonebrook/Glenridge-Collection

		U.log("Count =="+cnt);
		U.log(url);
		
		String html=U.getHTML(url);
		String quickHomeSec=U.getSectionValue(html, "<span class=\"qdh-lot\">", "</span> Quick Move-In Homes");
		U.log(U.getCache(url));
		String temhtml=html;
		if(html.contains("The Colonial"))
			html=html.replace("title=\"The Colonial\"","");
		
		String otherSec = U.getSectionValue(temhtml, "<div class=\"other-collections\">", " </div>");
		if(otherSec !=null)
			temhtml = temhtml.replace(otherSec, "");
//		U.log("??????????????"+Util.matchAll(html,"[\\w\\s\\W]{30}New Phase Now Open[\\w\\s\\W]{30}",0));
		
		//----remove nearby communities section
			String remo = U.getSectionValue(html, "<header class=\"nearby-header page-margins\">", "/html>");
			
			if(remo !=null)
				temhtml = temhtml.replace(remo, "");
		
		String hiddenSec = U.getSectionValue(temhtml.replace("</html>", "MMMMMMMMM</html>"), "<div class=\"is-hidden\">", "MMMMMMMMM");
		if(hiddenSec !=null)
			temhtml = temhtml.replace(hiddenSec, "");
		
		String types = U.getSectionValue(temhtml, "<div class=\"home-types\">", "</div>");
		if(types !=null)
			temhtml = temhtml.replace(types, "");
//		U.log("ddddddddddddd"+types);
		
		if(remo !=null)
			html = html.replace(remo, "");
		
		
		
		//-------------comName-----------------//
		String communityName=U.getSectionValue(html,"<h1 class=\"\">","<");
		if(communityName==null)	communityName=U.getSectionValue(html,"<h1 class=\"light\">","<");
		if(communityName==null)	communityName=U.getSectionValue(html,"<h1 class=\"master-name light\">","<");
		if(communityName==null)	communityName=U.getSectionValue(html,"form-community-name\">","<");
		U.log("communityName::::::::::::"+communityName);
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/California/Regency-at-Folsom-Ranch"))communityName="Regency At Folsom Ranch";
		
			if (communityName != null) {
				communityName = communityName.replace("Country Club$", "");
				communityName = communityName.replaceAll(" - The Villas$| - Villas$|Villas$", "");
				communityName = communityName.replaceAll(" - The Cottages|- Lofts$|- Flats$|- The Townhomes$| - Townhomes$|Townhomes$| - Cottages$", "");
				communityName = communityName.replaceAll(
						" Country Club$|- Manor Homes| - The Courtyards$| Country Club - Villas$|Country Club - Golf Villas$| Country Club - Carriage Homes$| - Townhomes$|Country Club Active Adult Single Family Collection$",
						"");
				communityName = communityName.replace("Toll Brothers at", "");
				communityName = communityName.replace("by Toll Brothers", "");
			}
		U.log("communityName : "+communityName);
		
		//---------------------------latlong----------------//
		String geo = "FALSE";
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "map-container community js-com-map","</div>");
		
		if (latLongsec==null) {
			latLongsec = U.getSectionValue(html, "GeoCoordinates\",","},");
		}
		
//		U.log("latLongsec ::"+latLongsec);
		
		if(latLongsec!=null){
			latLongsec=latLongsec.replace("data-lat=\"", "\"latitude\" : \"").replace("data-lon=\"", "\"longitude\" : \"");
//			U.log("latLongsec ::"+latLongsec);
			latLong[0] = U.getSectionValue(latLongsec, "\"latitude\" : \"", "\"");
			latLong[1] = U.getSectionValue(latLongsec,"\"longitude\" : \"", "\"");
			if(latLong[0].equals("41")){
				latLong[0]="41.00";
			}
			if(latLong[1] != null && !latLong[1].trim().startsWith("-"))latLong[1] ="-"+latLong[1];
		}
		else {
			latLongsec = U.getSectionValue(html, "<div class=\"js-contact-panel-map map-container community js-osc-map is-full\"","<div class=\"map-cover js-fullscreen-map-trig\">");
			latLong[0]=U.getSectionValue(latLongsec, "data-lat=\"", "\"");
			latLong[1]=U.getSectionValue(latLongsec, "data-lon=\"", "\"");
		}
		U.log("Latlng : " +Arrays.toString(latLong));
//		U.log(Util.match(html, ".*presale.*"));
		html = html.replaceAll("Home Sites Open for Sale|Square is now open for sales|Loft Building Now Open for Sale|Brothers Community Now Open for Sale|Now Open for Sale and Taking Deposits|Home Sites Now Open for Sale| Home Sites - Now Open for Sale|Newest Charlotte-Area Community Now Open For Sale|work with your team, pre-sales to post-construction", "");
		String notes = U.getnote(html.replace("Anticipated to open for sale summer 2022", "").replaceAll("First Release", ""));
		U.log("NT ::"+notes);
		//-----------------------adress-----------------------//
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		//html=html.replace(",GPS Users: 1426 W. Baltimore Pike", "");
		String ad = U.getSectionValue(html, "Address</h6>", "</li>"); //"<a class=\"");
		if(ad!=null)
			ad=ad.replace(",GPS Users: 1426 W. Baltimore Pike", "");
//		U.log(ad);
		if (ad!=null) {
			ad=ad.replaceAll("</p>\\s+<p>", ",")
					.replaceAll(",\\d+.\\d+, -\\d+.\\d+</p>|<p>|<.*?>", "").replace("&nbsp;", " ");
			String rem=U.getSectionValue(ad, "(", ")");
			if(rem!=null)
			ad=ad.replace(rem, "");
			ad=ad.replace("(", "").replace(")", "");
			ad=ad.replace(",41, -74.0967", "");
			ad=ad.replace(",GPS Users: 1426 W. Baltimore Pike", "").replace("(GPS Users: 164 Mount Pleasant Road)", "").replace("(GPS: 80 Butcher Road)", "").replaceAll("On south side of Ten Mile Road, 1/2 mile west of Milford Road|, 1 mile North of Hwy 290|,South of Immokalee Road and North of Vanderbilt Beach Road", "")
					.replace("&nbsp;", " ").replaceAll("\\d+\\.\\d+, \\d+\\.\\d+", "").trim().replaceAll(",$", "");
			
			
//			U.log("-------->"+ad);
			add=U.getAddress(ad);
		}
		if (ad==null) {
			U.getSectionValue(html, "\"address\" : {", "},");
		}
//		U.log("ffff: "+ad);
		if(ad!=null && html.contains("Address</h6>")&&(add[0]==null||add[0]==ALLOW_BLANK)){
			U.log("hhhhhhhhh");
			add[0]=U.getSectionValue(ad, "\"streetAddress\" : \"", "\"");
			add[1]=U.getSectionValue(ad, "\"addressLocality\" : \"", "\"");
			add[2]=U.getSectionValue(ad, "\"addressRegion\" : \"", "\"");
			add[3]=U.getSectionValue(ad, "\"postalCode\" : \"", "\"");
			
		}
//		U.log("ppp"+add[1]);
//		U.log(add[0]);
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Mill-Creek-Forest/Magnolia")||url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Mill-Creek-Forest/Meadows")) {
			add[0]=add[0].replace(", Longleaf Pine Parkway and Greenbrier Road", "");
		}
		
		if(html.contains("\"streetAddress\" : \"")&&(add[0]==null||add[0]==ALLOW_BLANK)){
			//U.log("hhhhhhhhh");
			add[0]=U.getSectionValue(html, "\"streetAddress\" : \"", "\"");
			add[1]=U.getSectionValue(html, "\"addressLocality\" : \"", "\"");
			add[2]=U.getSectionValue(html, "\"addressRegion\" : \"", "\"");
			add[3]=U.getSectionValue(html, "\"postalCode\" : \"", "\"");
			
		}
		
		if(add[0]==null||add[0]==ALLOW_BLANK) {
			
			String addSec = U.getSectionValue(html, "<h5 class = \"osc-sales-address\">", "</h5>");
			if(addSec!=null) {
				
				addSec = addSec.replace(",&nbsp;", ",").replace("&nbsp;", " ");
				add = U.getAddress(addSec);
				
			}
			
		}
		
		U.log("Address : " +Arrays.toString(add));
		if(add[1]==null || (add[0].length()<4 && latLong[0].length()>4)){
			add = U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getGoogleAddressWithKey(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		
		if(add[0]!=ALLOW_BLANK && add[0]!=null && (latLong[0]==ALLOW_BLANK || latLong[0]==null)) {
			
			latLong = U.getlatlongGoogleApi(add);
			geo = "TRUE";
		}
			
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Maryland/The-Enclave-at-ArundelPreserve-Townhomes")) {
			add[1]="Severn";
			add[3]="21144";
		}
		// ---------community type,property type,property status,derived,
		
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html, "[\\s\\w\\W]{40}Home Sites Available[\\s\\w\\W]{30}", 0));
		html=html.replaceAll("notranslate\">6175</span>","");
		html=html.replaceAll("Dulles Landing shopping center now open!|home sites are now available.|Model Home Now Available for Sale!","")
				.replace("Spectacular new home designs now available!|Wooded Walk-Out Sites Now Available!|New home design now available!","");
		html=html.replaceAll("suites now available|walk out lots available|Limited home sites remain. Don|grand opening information|Sales Center is now open|Center is Now Open|wooded home sites available|home designs now available|One of the last opportunities|addition now available|lined home sites available|new home designs now available|Now Available: Prime location home sites|Out Sites Now Available|now available in the heart|The Waverly - Now Available|New home design now available|Grand Opening of Clubhouse|Yardley - The Villa|Yardley - The Carriage|about this Master|Yardley-The-Carriage|will be sold out|Designs Now","");
		html = html.replace("Final phase of home sites selling fast", "Final phase home sites selling fast");
		html = html.replaceAll("open in Fall 2017|open in the fall of 2017", "open fall 2017");
		html = html.replace("lake and golf views", "lake and golf course views").replace("New phase—Pond home sites available", "New Phase Pond Home Sites Available");
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html, "[\\s\\w\\W]{30}Home Sites Available[\\s\\w\\W]{30}", 0));
		
		//---quick and floor plans details--//
		
		String allHomesData=ALLOW_BLANK;
		int quickCount = 0 ;
		String homeUrls[] = U.getValues(html, "<div class = \"item-contain", "</a>"); //"<h3 class=\"plan-name","</h3>");
		U.log("Total Homes : "+ homeUrls.length);
		
		//======= Imge value
		String homeImg = ALLOW_BLANK;
		
		for(String hUrl:homeUrls){
			try {
				hUrl = U.getSectionValue(hUrl, "href=\"", "\"");
				U.log("=="+hUrl);
				if(hUrl.contains("/Quick-Move-In/"))quickCount++;
				String hHtml = U.getHTML(hUrl);
				
/*				String rem = U.getSectionValue(hHtml, "<section class=\"hero-contain\">", "</section>");
				
				if(rem!=null)
					hHtml = hHtml.replace(rem, "");
				
				String hidden = U.getSectionValue(html, "<div class=\"is-hidden\">", "</html>");
				if(hidden !=null)
					hHtml = hHtml.replace(hidden, "");
				
				String type = U.getSectionValue(html, "<div class=\"home-types\">", "</div>");
				if(type !=null)
					hHtml = hHtml.replaceAll(type, "");
				
				String[] sec = U.getValues(hHtml, "<span class=\"media-caption\">", "<");
				for(String img : sec)
					homeImg+=img;
*/				
				allHomesData+=U.getSectionValue(hHtml, "<section id = \"details\"", "</section>") +  U.getSectionValue(hHtml, "<h1 class = \"section-header", "</section>");;
			
			}catch(Exception e) {}
		}//eof for
		
		
		allHomesData = allHomesData.replaceAll("</span>\\s*<span>", " ");
		
		String rem = U.getSectionValue(html, "<section class=\"recommended-finance-nearby is-hidden\"", "</section>");
		if(rem != null) html = html.replace(rem, "");
		
		
		// --prices---//
		html  = html.replace("Low $600,000s","Low $600,000").replace("$1 million", "$1,000,000").replace("$1.8 million", "$1,800,000").replace("$3 million", "$3,000,000").replace(" $500,000-600,000 ", " $500,000-$600,000").replace("00s!", "00,000").replace("00s, ", "00,000").replace("00's", "00,000");
		
		html=formatMillionPrices(html);

	//	html=html.replace("<span class=\"price \">", "<span class=\"price \">$");

		html=U.removeSectionValue(html, "recommended-finance-nearby end-caps-only", "glide__arrows");
//		
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(comSec, "[\\s\\w\\W]{30}629,995[\\s\\w\\W]{30}", 0));
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html, "[\\s\\w\\W]{30}629,995[\\s\\w\\W]{30}", 0));
		
		String[] price = U.getPrices(html+comSec,
				"Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}s|Priced at <span class = \"detail\">\\$\\d+,\\d+|from the \\$\\d+,\\d+|(Starting|Priced) at <span class = \"detail\">\\$\\d{3},\\d{3}|<span class = \"label\">Priced at \\$\\d{3},\\d{3}</span>|<span class = \"label\">Starting at \\$\\d{3},\\d{3}</span>|<span class=\"price \">\\$\\d{3},\\d{3}|Single Family Home Over \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$</span>\\d{3},\\d{3}</span>|\\$</span><span class=\"price \">\\d{3},\\d{3}</span>|<span class=\"pfrom\">From</span>\\s+\\$\\d,\\d{3},\\d{3}</span>| \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}s</span>|Mid-\\$\\d{3},\\d{3}s</span>|<span class=\"js-sort-price\">\\s*\\$(\\d,)?\\d{3},\\d{3}|\\$</span>(\\d,)?\\d{3},\\d{3}</span>|price range\">(Upper|Low|The) \\$(\\d,)?\\d{3},\\d{3}|from the mid(-|\\s)\\$\\d{3},\\d{3}|class=\"price\\s?\">(\\d{1,2},)?\\d{3},\\d{3}</span>|js-sort-price\">\\s+\\$(\\d{1,2},)?\\d{3},\\d{3}</span>|start in the \\$\\d{3},\\d{3}", 0);
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Regency-at-Creekside-Meadows/Villas-Collection"))price[1]="$514,995";				
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Georgia/Toll-Brothers-at-Westshore-The-Cottages"))price[0]="$600,000";				
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
//==
		String planHtml="";
/*		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/New-Jersey/10-Provost-Street-at-Provost-Square")) {
		String planUrlSec=U.getSectionValue(html, " <li class=\"residences-column floor-plan js-residences-fp-container\">", "class=\"clear-styles right-button\">");
		String planUrl=U.getSectionValue(planUrlSec, "href=\"", "\"");
		planHtml=U.getHtml(planUrl, driver);
		}*/
		
//==
		html = html.replaceAll("clubhouse with 5,700 square feet|21,805 square feet of retail|clubhouse with just under \\d+,\\d+ square feet|Large home sites starting from \\d+,\\d{3} square feet|\\d+,\\d{3} square feet of specialty boutiques|home sites averaging \\d+,\\d{3} sq. ft|average 6,000 square feet|home sites averaging approximately \\d+,\\d{3} square feet to \\d+,\\d{3} square feet|home sites ranging from \\d+,\\d{3} up to \\d+,\\d{3} square feet|\\d+,\\d{3} square feet, all within the Meadows master plan|\\d,\\d{3} sq. ft. residents’ clubhouse|Home sites average over \\d+,\\d{3} square feet|\\d,\\d{3} to over \\d+,\\d{3} square feet of living space on expansive home sites|homes sites that average in excess of \\d+,\\d{3} square feet|\\d,\\d{3} sq. ft. resort-style club|home sites measuring approximately \\d,\\d{3}|\\d,\\d{3} square foot home sites|\\d+,\\d+ sq. ft. [C|c]lubhouse|\\d+,\\d+ sq. ft. Family|15,000 sq. ft. community clubhouse|30,000 sq. ft. Clubhouse with Banquet Facilities|13,000 sq. ft. community clubhouse|13,000 square foot community clubhouse|40,000 sq. ft. Community Clubhouse|40,000 square foot community clubhouse|center featuring over 7,000 |15,000 sq. ft. home sites|>15,000 square foot", "");
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				
				html=html.replace("From</span>\\3285&nbsp;<span class=\"sm-label\"> sq ft", "3285 sq ft.").replaceAll("plans on 7,200 sq. ft.|Five new designs on 8,750 sq. ft.|feet homes on 7,800 square feet home|7,250 sq. ft. home sites.", "");
		//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html+planHtml+allHomesData, "[\\s\\w\\W]{60}1,087[\\s\\w\\W]{60}", 0));	
		String[] sqft = U.getSqareFeet(html+planHtml+allHomesData,
							"\\d,\\d{3} - \\d,\\d{3}\\+ sq. ft.|\\d,\\d{3}-\\d,\\d{3}\\+ sq ft|ranging \\d{4}-\\d{4} square feet|range from \\d,\\d{3} – \\d,\\d{3} sq. ft|ranging from \\d,\\d{3} to over \\d,\\d{3} square feet|\\d{4} sq ft.|From</span>\\d{4}&nbsp;<span class=\"sm-label\"> sq ft<|approximately \\d,\\d{3} - \\d,\\d{3} total square feet|Ranging from \\d,\\d{3}-\\d,\\d{3}\\+ sq. ft.|ranging from \\d{4} to \\d{4}\\+ sq. ft.|approx. \\d,\\d+ - \\d,\\d+ sq. ft.|\\d,\\d{3}</span>\n\\s*<span class=\"label\">square feet</span>|\\d,\\d{3} up to \\d,\\d{3} square feet|ranging from \\d,\\d{3}–\\d,\\d{3} sq. ft|<span class=\"detail\">\\d{3}\\+</span>|<span class=\"detail\">\\d,\\d{3}\\+</span>|\\d{4}\\+ sq ft|\\d\\,\\d{3}\\+ square foot|home designs on \\d,\\d{3}\\+ square foot|\\d,\\d{3} – \\d,\\d{3} sq. ft| \\d,\\d{3}-\\d,\\d{3} square feet|Under \\d{4} Sq. Ft.|from \\d,\\d{3}- \\d,\\d{3}\\+ sq. ft|approximately \\d{1},\\d{3} to more than \\d{1},\\d{3} square feet|from \\d{1},\\d{3} to \\d{1},\\d{3}|from \\d{1},\\d{3}-\\d{1},\\d{3} square feet|from \\d{4} - \\d{4} sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} finished square feet|~\\d{1},\\d{3} sq. ft| \\d{1},\\d{3} up to \\d{1},\\d{3} sq. f|from \\d{1},\\d{3}\\s*-\\s*\\d{1},\\d{3}\\+ square feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d+ square feet|from \\d+-\\d,\\d+ square feet|\\d,\\d+ – \\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ square foo| \\d,\\d+ to over \\d,\\d+ square-feet| \\d,\\d+ – \\d,\\d+ sq. ft|\\d,\\d+ square feet to \\d,\\d+ square feet| \\d,\\d+ to \\d,\\d+ square feet| \\d{1},\\d+ to \\d,\\d+\\+ square feet|from \\d,\\d+ up to \\d,\\d+ square feet|from \\d{4} to \\d{4} sq. ft|approximately \\d,\\d+ square feet to \\d,\\d+ square feet|approximately \\d,\\d+ to approximately \\d,\\d+ square feet|from \\d,\\d+-\\d,\\d+ sq. ft|\\d,\\d+ to \\d,\\d+(\\+)* sq. ft| \\d,\\d+ - \\d,\\d+ square feet|\\d+ – \\d,\\d+ square feet | \\d,\\d+ sq. ft|\\d{1},\\d{3} to over \\d{1},\\d{3} square feet|from \\d{1},\\d{3} to \\d{1},\\d{3} square feet.|from \\d{1},\\d{3} to \\d{1},\\d{3}+ square feet.|\\d{1},\\d{3} up to \\d{1},\\d{3} square feet | from \\d{1},\\d{3} sq. ft. to \\d{1},\\d{3} |up to \\d{1},\\d{3} square feet|from \\d{1},\\d+ to over \\d{1},\\d+ square feet.|notranslate\">\\d{4} Sqft.</span>|from \\d{1},\\d{3}-\\d{1},\\d{3} sq. ft. |\\d{3,4} Sqft.| from \\d{1},\\d{3}-\\d{1},\\d{3} square feet |notranslate\">\\d{4}</span>|approximately \\d{1},\\d{3} square feet|<span class=\"js-sort-sqft\">\\s*\\d{3,4}<|from \\d{3} to \\d,\\d{3} sq. ft.|\\d{1},\\d{3}\\+ square feet|Square-Feet js-sort-sqft\" data-value=\"\\d{3,4}\"", 0);
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1]; 
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Arizona/Toll-Brothers-at-the-Meadows/Laurel-Collection"))
			maxSqf = "4272";
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//Remove filter section
		String remove = U.getSectionValue(html, "<aside class=\"omni-bar more-filters-container", "</aside>");
		if(remove != null) html = html.replace(remove, "");
		
		//Remove contact page from Page
		remove = U.getSectionValue(html, "<div class=\"contact_form", "</form>");
		if(remove != null) html = html.replace(remove, "");
		
		
		//----Community Type---
		String commTypeSec=U.getSectionValue(html, "Community Type</span>","</div>");
		if(commTypeSec!=null)
		  commTypeSec=commTypeSec.replace("Waterfront","Waterfront Community");
		html=html.replaceAll("Active Adult\">Active Adult|value=\"Active Adult\">", "").replace("<span class=\"amenity-title\">Gated</span>", "<span class=\"amenity-title\">Gated Community</span>");
		html = html.replace("data-type=\"Amenities/Resort\">Amenities/Resort", "resort style").replaceAll("age 55\\+|Collection, a 55\\+", "buyers 55 & over").replace("un-filled, 55+", "buyers 55 & over");
		String commType = U.getCommunityType(html+commTypeSec);
	//	U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html, "[\\s\\w\\W]{30}active adult[\\s\\w\\W]{30}", 0));
		U.log("comm Type:: "+commType);
		
		
	
		
		
		
		//----Property Status---
//		String propType = U.getPropType(pSec+dSec+zSec+sSec+yeSec+pSec1+url);
		html = html.replace("custom designed kitchens|Kitchens custom designed|landscaped interior courtyard", "landscaped interior Courtyard Home")
					.replace("Carriage</li>", "carriage homes </li>")
					.replace("The Estates", "The Estates Homes")
					.replace("The Manor", "The Manor Homes")
					.replace("The Traditional", "The Traditional Homes")
					.replaceAll("The Executives", "The executive style home")
					.replaceAll(" clubhouse features a charming farmhouse exterior|Courtyard_|Club-Villas|Club - Villas|Miravilla|Trovilla|Village|Carriages Collection</a></li>|- The Villa Collection</a>|Patio Door|elevation-name\">The Traditional</div>|Villamar|villamar|Lakeshore - Townhomes|-Twins|- The Townhome Collection|Townhome-Collection|Lakeshore-Townhomes|- Golf Villas|-Villas|- The Villas|- Carriage Homes|- The Carriage Collection|Carriage-Homes|Carriage-Collection", "");
		html=html.replace("Final opportunities are now available", "Final opportunities now available").replaceAll("elevation-name\">The(.*?)Farmhouse<|title=(.*?)Farmhouse|alt=(.*?)Farmhouse", "")
				.replace("The Executives features l", "The executive style home features ").replace("Executive Collection", " executive style home ");
		
		temhtml = temhtml.replace("custom designed kitchens|Kitchens custom designed|landscaped interior courtyard", "landscaped interior Courtyard Home")
				.replace("Carriage</li>", "carriage homes </li>")
				.replace("Craftsman and Prairie architectural styles", "Craftsman, Coastal and Farmhouse")
				.replace("The Estates", "The Estates Homes")
				.replace("The Manor", "The Manor Homes")
				.replace("The Traditional", "The Traditional Homes")
				.replaceAll("The Executives", "The executive style home")
				.replaceAll(" clubhouse features a charming farmhouse exterior|Courtyard_|Club-Villas|Club - Villas|Miravilla|Trovilla|Village|Carriages Collection</a></li>|- The Villa Collection</a>|Patio Door|elevation-name\">The Traditional</div>|Villamar|villamar|Lakeshore - Townhomes|-Twins|- The Townhome Collection|Townhome-Collection|Lakeshore-Townhomes|- Golf Villas|-Villas|- The Villas|- Carriage Homes|- The Carriage Collection|Carriage-Homes|Carriage-Collection", "");
		temhtml=temhtml.replace("Final opportunities are now available", "Final opportunities now available").replaceAll("elevation-name\">The(.*?)Farmhouse<|title=(.*?)Farmhouse|alt=(.*?)Farmhouse", "")
			.replace("The Executives features l", "The executive style home features ").replace("Executive Collection", " executive style home ");
			
		
		String removeHidden[] = U.getValues(temhtml, "<span class=\"is-hidden\">", "</span>");
		for(String remVal : removeHidden) temhtml = temhtml.replace(remVal, "");
		//----Property Type---
//		U.writeMyText(temhtml);
	
		String a=(temhtml+communityName+allHomesData).replaceAll("Mediterranean-style clubhouse|- The Farmhouse</span>|Farmhouse\"|title=\"The Farmhouse\"|<input type=\"checkbox\" id=\"filter-townhome-sbm\" class=\"js-checkbox\" name=\"h_type\" value=\"Townhome\"/>|<label for=\"filter-townhome-sbm\" class=\"icon icon-townhome checkLabel js-checkbox-trigger\">Townhome</label>|", "");
//		U.log("SSSSSSSSSSSSSSSSSSSS>>"+Util.matchAll(a, "[\\s\\w\\W]{30}carriage-style[\\s\\w\\W]{30}", 0));
		a=a.replaceAll("TownhouseExterior_", "");
		
		//=========== Image Gallary & Homes =============
		String[] imgSec = U.getValues(html, "<span class=\"media-caption\">", "</figure>");
		String imgType =ALLOW_BLANK;
		for(String img : imgSec)
			imgType+=img;
		String propTypeSec=U.getSectionValue(html, "Community Highlights","Amenities");
		if(propTypeSec!=null)
		propTypeSec=propTypeSec.replace("Detached 2-, 3-, and 4-story European-style homes", "Detached Homes");
		//U.log("MMM"+Util.match(txt, findPattern));
		a = a.replaceAll("New homes, luxury homes, home builder, new home|Toll Brothers&reg; Luxury Homes|America's Luxury Home Builder|new home, luxury home, home builders|"
				+ "designs with luxurious options & features", "").replace("featuring Craftsman, Farmhouse, West Indies and Tuscan", "featuring Craftsman Style Homes, Farmhouse Style Homes, West Indies and Tuscan")
				.replace("carriage-style townhome community located","carriage style townhome community located");
		
		String propType = U.getPropType((propTypeSec+homeImg+imgType+(a)).replaceAll("</svg><p>Quality craftsmanship|Quality craftsmanship|quality craftsmanship","").replaceAll("Oversized back patios for outdoor living|title=\"The Farmhouse\"|icon-single-family|trigger\">Single Family</label>|icon-condo|trigger\">Condo</label>|value=\"Condo\"|-condominium-|\"Single Family\"/|COURTYARD_\\d+|Country Manor", "").replace("- Townhomes", "").replace("/Townhomes", "").replace("Brothers&reg; Luxury Homes", "").replace("content=\"New Luxury Homes", "").replace("Family Homes\">New Luxury Homes", "").replace("New homes, luxury homes", "")
				.replaceAll("propTypeSec+homeImg+imgType+(a)|Toll Brothers&reg; Luxury Homes|America's Luxury Home Builder", "")
//				.replace("craftsmanship", "")
				.replace("Detached 2-, 3-, and 4-story European-style homes","Detached Homes")
				.replace("townhome-sbm", "")
				.replace("Villa-Collection", "").replace("Taxes and HOA", "")
				.replace("Home designs feature Coastal", "coastal design")
				.replaceAll(communityName+"New Luxury Homes For Sale in|Villa Collection|lexible carriage home designs|carriage homes for sale|Carriage Homes for Sale|Lakes - Estate Collection|/Villa-Collection\">Azure at Hacienda|Vallagio Manor ", ""));
	
		
		//U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(propTypeSec+homeImg+imgType+a, "[\\s\\w\\W]{50}loft[\\s\\w\\W]{50}", 0));
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(homeImg, "[\\s\\w\\W]{30}farmhouse[\\s\\w\\W]{30}", 0));
		U.log("propType: "+propType);
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(imgType, "[\\s\\w\\W]{30}farmhouse[\\s\\w\\W]{30}", 0));
		
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Azure-at-Hacienda-Lakes/Coach-Collection") || url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Azure-at-Hacienda-Lakes/Estate-Collection")
				|| url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Azure-at-Hacienda-Lakes/Heritage-Collection"))
			propType = propType.replace(", Villas", "");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Azure-at-Hacienda-Lakes/Heritage-Collection") || url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Azure-at-Hacienda-Lakes/Villa-Collection"))
			propType = propType.replace(", Craftsman Style Homes", "");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Maryland/Toll-Brothers-at-Turf-Valley/Single-Family-Homes") || url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Maryland/Toll-Brothers-at-Turf-Valley/Townhomes"))
			propType = propType.replace("Luxury Homes,", "");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Maryland/Toll-Brothers-at-Turf-Valley/Townhomes"))
			propType = propType.replace("Single Family,", "");
		
		//-----Derived Type-----
		html = html.replace("one- and two-story single-family", "1 story and two-story single-family homes") //.replaceAll("18-story|19-story", "")
				.replace("2 and/or 3-story decks", "2 story and 3-story decks")
				.replace("three- to four- story ", " 3 Story  4 Story ")
				.replace("one- and two-story", "1 Story 2 Story ");
		
		html = html.replaceAll("Rancho Mirage|Ranch shopping center| Ranch Road|Ranch\" class|Ranch<| Ranch\" data-|Talon Ranch Sales|The Ranch Hacienda|-Ranch-|-ranch-|Windgate Ranch|Rancho Cordova", "");
		html=html.replaceAll("The Spanish Colonial| Colonial Exterior Design\"|</strong><span class=\"modelDetail js-model-stories notranslate\">"," ");
		html=html.replaceAll("<li class=\"js-sort-stories\" data-value=\"(\\d)\">", " $1 story ")
				.replaceAll("<span class=\"js-sort-stories\">\\s*", " Stories ").replace("2-3 story", " 2 Story  3 Story ")
				.replaceAll("<li class=\"one-detail stories\">\\s*<span class=\"modelDetail notranslate\">\\s*3</span>", "3 stories")
				.replaceAll("<li class=\"one-detail stories\">\\s*<span class=\"modelDetail notranslate\">\\s*2</span>", "2 stories")
				.replaceAll("<li class=\"one-detail stories\">\\s*<span class=\"modelDetail notranslate\">\\s*1</span>\\s*</li>|<li class=\"one-detail stories\">\\s*<span class=\"modelDetail notranslate\">\\s*1\\s*</span>", "1 stories");
		allHomesData=allHomesData.replaceAll("Stories</span>\n*\\s*\n*<span>1</span>", " 1 Story ")
				.replaceAll("Stories</span>\n\\s*<p class=\"gallery-slide-down-info-icon-number\">", "Story ");
		
		String dpType = U.getdCommType((homeImg+imgType+html+allHomesData).replace("floor", ""));

		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/New-York/77-Charlton"))dpType="15 Story";
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html+allHomesData, "[\\s\\w\\W]{30}3 Story[\\s\\w\\W]{30}", 0));
		//remove gallery section
		html  = U.removeSectionValue(html, "<h2 class=\"content-heading\">Photo Gallery</h2>", "</section>");
		//remove image contains
		html =html.replaceAll("<img(.*?)>", "");
		html=html.replaceAll("with limited home sites remaining|Estate Collection is now available|many home sites available backing|center now open|out of the Model","")
				.replace(" - Schedule a Virtual", "");
		
		html = html.replace("Quick Delivery Home", "");
		//TODO ::
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html, "[\\s\\w\\W]{30}limited homes remain[\\s\\w\\W]{30}", 0));
		String ignoreData = "now available at Creekside|Coming Soon, Your New Community Clubhouse|Designs Coming Soon. |Grand Opening\">|Big Coming Soon|Park coming soon|the ‘coming soon|entertaining, coming soon|Act Now - Homes are Selling Quickly</p>|Golf Course Views Now Available - Hurry In |Collection Coming Soon|School are now open|School Coming Soon|[A|a]menit(y|ies)* [n|N]ow [o|O]pen|[P|p]ool [C|c]oming [S|s]oon|[S|s]chool [n|N]ow [o|O]pen|[S|s]pace [C|c]oming [S|s]oon|[P|p]ark coming soon|[C|c]enter [C|c]oming [S|s]oon|uxury Townhomes Coming Soon|Immediate and Quick Move In Homes Available|Model Home Will Be Opening Soon|Amazing Opportunities Ready for Move-In|Now Available: Prime|Decorated Home Now Available|Now Available</p><p>Enclave |Outdoor Living Now Available|Model Homes - Now Available| now available: convenient back|Coming Soon! Register |New Home Sites Coming Early Fall 2018| Move-In Ready Home Available|center are now open|Lined Home Sites Available|Spectacular Home Sites Available|Golf course home sites available|Move In Ready |Next Release Coming Soon|announcements and Grand Opening details| coming soon to Mira Villa|coming this Spring! Become|Coming Soon - Model Home|quick move-in homes remain!|The Sehome is Now Available|green space, now available|School coming Fall 2018|school opening fall 2018|community, opening Fall 2018|park, coming soon|green space, coming soon|Model Home - Now Open|Model Homes Now Open| close out details|Spacious home sites with stunning views now available|Bellwynn Renaissance Quick Delivery Home|qdh-callout\">Quick Delivery Homes Available!</li|Lake of Novi - the final section|Gorgeous home sites now available|Homes are selling quickly - Act now|Now Selling from Montevista|Texas\\. Opening in the Fall of 2017|New home sites now available at Encore|Home Designs Just Released|park, coming soon Summer 2018| just about sold out!|Sales Office opening soon"
				+"|Plan - Coming Soon|Coming Early 2019 to Sammamish|center opening Fall 2018|Model - Now Open|model home - now available|villas are now available|which are now available"
				+"|[M|m]ove(-)*\\s*[I|i]n|Design - The Bowan - Now Available|model homes - now available|Now Available! Click here|Park, coming soon|Move-in ready homes are available now|Golf Course Home Sites Available"
				+"|Move-in ready homes are available now|Golf Course Home Sites Available|Now Selling from Montevista|on Quick Delivery Homes, for a|Retreat home sites now available|Construction - Opening Summer 2017|center to open Spring 2017|grand opening details|Now Open: Clubhouse|school coming soon|is coming soon|- now open|Design - The Bowan - Now Available|Community Park, coming soon,|retail center coming soon and"
				+"|(Cul-De-Sac|Wooded Views|Acre Home Sites Are|the lake coming soon|Model Home -|Pool is) Now|home sites are now|event-name=\"Final|(Masters|Acre|Cul-De-Sac) Home Sites|now available at Frisco|heading\">QUICK DELIVERY HOME|QUICK DELIVERY HOMES</span>|Soon(</span>)? to Superior|Now Open - Brookmeade|open! Experience|[C|c]enter [O|o]pening|available for sale|School Coming";
		html = html.replaceAll(ignoreData, "").replace("Coming Soon - Spring 2020", "Coming Soon Spring 2020")
				.replace("Coming Soon - May 2020", "Coming Soon May 2020")
				.replace("Coming Soon - April 2021", "Coming Soon April 2021")
				.replace("Private, Wooded Home Sites Now Available", "Private & Wooded Home Sites Now Available")
				.replace("New Phase—Now Open", "New Phase Now Open")
				.replaceAll("move-in homes in person|SHOW ONLY QUICK MOVE-IN|<span>Only Quick Move|Selling by Appointment|Offering Our Final|MOVE-IN HOME AVAILABLE|Last Chance: Don't", ""); //
//				.replace("Final opportunity is now available", "Final opportunity now available");
//		U.log(Util.match(html, ".*Coming Soon.*"));
		
//		U.writeMyText(html);
		html=html.replaceAll("maintenance homes are now|Coming Spring 2021</p>|Coming Fall 2021 – Join|Coming June 2021 –|Future bocce court, coming soon|Floor plans are selling OUT|TownhouseExterior_|The Sales Center Is Now Open|5th grade coming soon|Concept Plan - Coming Soon|Porter Ranch Community Park, coming soon|Ranch Community Park is coming soon", "")
				.replaceAll("\\d+ Final Opportunity|\\d+ Now Open|Only Quick Delivery Homes|SHOW ONLY QUICK DELIVERY HOMES|[Q|q]uick [M|m]ove|[M|m]ove-[I|i]n|[M|m]ove [I|i]n|amenities now open|Now Open - Inspirada|Model Now Open|title=\"Now Open|Now Open: Reserve|School Coming| New Release - 220 Towns\">|more coming|now available at Creekside|Limited availability\\. Please call fo|distance to the community, opening Fall 2020|End Locations Now Available|Center Now Open|One-Acre Plus Home Sites Available|Henley Grand Opening| the lake coming soon|Before We are Sold Out|dle School \\(Open Fall 2018\\)</a>|data-vars- Home Sites Availabl|rs-event-name=\"Final Home Sites Available\">|Spacious Home Sites Available Across|Ranch Are Selling Quickly|Final Opportunities - Whittier Heights|Quick Delivery Homes Now Available|New Exterior Styles Now Available in The Grove|Just Released - New Home Sites| Now Available in The Grove", "");
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html, "[\\s\\w\\W]{30}Townhouse[\\s\\w\\W]{30}", 0));
		String statusSec=U.getSectionValue(html, "community-callout alt home-design-badge", "</p>");
		//String descSec=U.getSectionValue(html, "community-info-highlights", "</p>");
//		U.log(statusSec+""+comSec+" -----");
		
		
		String callOutSection=null;
	
		
		
		String descSec="";
		
		descSec=U.getSectionValue(html, "section-paragraph read-more-container", "</p>");
		
		callOutSection=U.getSectionValue(html, "<div class = \"community-hero-callout\">", "</div>");
		
		U.log("----->>>>>>>callOutSection: "+callOutSection);
		
		String propSec=U.getSectionValue(html, "<p class=\"community-callout\">","</p>");
		String comDesSec=U.getSectionValue(html, "<p class=\"section-paragraph\">","</p>");
		
		String commStatus = U.getPropStatus((comDesSec+propSec+statusSec+comSec+callOutSection+descSec).replace("Now selling our final phase", "Final phase Now selling").replaceAll("Golf Course Now Open|Coming Summer 2021|[q|Q]uick [m|M]ove|ready for a quick move|maintenance homes are now available", ""));
//		U.log(">>>>>>>status>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}Only 2 homes remain[\\s\\w\\W]{30}", 0));
		U.log("pre PropStatus"+commStatus);
//		commStatus=commStatus.replace("Quick Move-In Homes", "");
//		if(quickCount>0) {
//			if(commStatus.length()<4&&!commStatus.contains(""))
//				commStatus="Quick Move-In Homes";
//			else if(!commStatus.contains("Quick Move-In Homes"))
//				commStatus+=", Quick Move-In Homes";
//		}
		U.log("prop Status:: "+commStatus);
		
		
		if(commStatus.contains("Only 1 Home Site Remaining,") && commStatus.contains(", One Home Site Remaining")){
			commStatus = commStatus.replace(", One Home Site Remaining", "");
		}
//		U.log("MMM "+Util.matchAll(html.replace("The Sales Center Is Now Open", "").replace("s Now Available", ""), "[\\s\\w\\W]{30}Home Sites Available[\\s\\w\\W]{30}", 0));
			
		//-------------------------quick move in-----------------//
		//|| html.contains("Quick Move-In Homes Available")
//		if(html.contains("/Quick-Move-In/")||quickCount>0){
//			commStatus = commStatus.replaceAll("Quick Delivery Homes,|Quick Delivery Homes|Quick Delivery Home,|Quick Delivery Home", "");
//			if(commStatus.length()<4){
//				commStatus="Quick Move-In Homes";
//			}	else{
//				commStatus=commStatus+", Quick Move-In Homes";
//			}
//		}
		
	//	String quickSec=U.getSectionValue(html, "<button class = \"btn-with-plus-icon js-modal-qdhs-trigger clear-styles\">", "<svg xmlns=\"http://www.w3.org");
		//if(quickSec!=null)// || quickCount>0
		
		int myQuickCount=0;
		
		U.log("quickHomeSec"+quickHomeSec);
		if(quickHomeSec!=null)
		 myQuickCount=Integer.parseInt(quickHomeSec);
		U.log("Total quick home :"+myQuickCount);//quickCount
		
		if(myQuickCount>0)
		{
			if(commStatus.length()<4){
				commStatus="Quick Move-In Homes";
			}	else{
				commStatus=commStatus+", Quick Move-In Homes";
			}
		}
		U.log("commStatus====="+commStatus);
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/New-Jersey/Enclave-at-Ocean")) {
			
			minPrice="$958,405";
					minSqf="3186";
		}
//		commStatus=commStatus.replace("Fall 2017, Opening Fall 2017", "Opening Fall 2017");
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Illinois/Bowes-Creek-Country-Club/The-Townhome-Collection")
				||url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Texas/Creekside-at-Heritage-Park")
				||url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Maryland/Marlboro-Ridge/The-Meadows")
				||url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Texas/The-Reserve-at-Katy/The-Estates"))
			commStatus = commStatus.replace("Final Opportunities, Now Available", "Final Opportunities Now Available").replace("Final Opportunity, Now Available", "Final Opportunity Now Available");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Texas/Frisco-Springs"))
			commStatus = commStatus.replace(", Final Opportunities", "");
		
//		if( url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/North-Carolina/Toll-Brothers-at-Falls-at-Weddington"))commStatus = commStatus +", Final Opportunities";//Img
		
		if(url.contains("hhttps://www.tollbrothers.com/luxury-homes-for-sale/Colorado/Montaine/Estate-Collectionttps://www.tollbrothers.com/luxury-homes-for-sale/Arizona/Toll-Brothers-at-Blackstone/The-Retreat-Collection")|| url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Massachusetts/Regency-at-Glen-Ellen/The-Carriage-Collection")
				|| url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Massachusetts/Toll-Brothers-at-The-Pinehills/Briarwood")||url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Washington/McGraw-Square-at-Queen-Anne"))
			commStatus = commStatus.replace("Now Available,", "");
					
		if(propType.contains("Townhome")){
			propType=propType.replace("Townhouse, ","");
		}
		
	
		
		if(communityName!=null)
		communityName =communityName.replace("Turf Valley -", "Turf Valley");
		
		if(html.contains(" Master Plan Community"))
			if(!commType.contains("Master Planned"))
				commType = commType +", Master Planned";
				
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Michigan/North-Oaks-of-Ann-Arbor/The-Townhome-Collection"))
			commStatus = commStatus.replace("Now Available, Just Released,", "");
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/North-Carolina/Castleberry-Trails"))notes="Opening for Sale Early 2020";
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/California/The-Vistas-at-Orchard-Hills/Alta-Vista-at-Orchard-Hills"))
			commStatus = "Last Chance, Final Home Site Available"; //From Img
		
		//From img
		if((url.contains("/Washington/Toll-Brothers-at-Ten-Trails/Ten-Trails-Cedarwood-Collection")) && !commStatus.contains("Last Chance"))
		{
			if(commStatus.length()<4) {
				commStatus="Last Chance";
			}else {
				commStatus=commStatus+", Last Chance";
			}
		}
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Washington/The-Ridge-at-Big-Rock/Sandstone-Collection"))commStatus="Last Chance";
		if (url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Connecticut/Bethel-Crossing")) {
			commStatus+=", Only Few Homes Remain";
		}
		if (temhtml.contains("data-vars-event-name=\"Final Home Sites Available\">")) {
			if (commStatus.length()<2) {
				commStatus ="Final Home Sites Available";
			}else{
				commStatus =", Final Home Sites Available";
			}
		}
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Michigan/Hamlet/Hamlet-Pointe"))
//			commStatus = "Final Release of New Home Sites";
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Washington/The-Ridge-at-Big-Rock/Sandstone-Collection"))
//			commStatus = "Final opprtunity"+", Limited homes remain"+", Phase One is Almost Sold Out";
		
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Liseter/The-Merion-Collection"))
//			commStatus = "Final Opportunity, Only A Few Homes Remain"; //From Img
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/California/Altair/Alara"))
			commStatus = "Quick Delivery Home, Final Home Site Remaining"; //From Img
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Coastal-Oaks-at-Nocatee/Estate-%26-Signature-Collections") ||
				url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Coastal-Oaks-at-Nocatee/Legacy-Collection")){
			commStatus = "Final Opportunity, Only A Few Home Sites Remain";//Img
		}
		
/*		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Azure-at-Hacienda-Lakes/Villa-Collection"))
			commStatus = "Quick Delivery Home";
		commStatus = commStatus.replace("Quick Move-in, Quick Delivery Home", "Quick Delivery Home");
*/		
		if(url.contains("Villa"))
			if(!propType.contains("Villas"))
				if(propType.length()>3)
					propType += ", Villas";
				else 
					propType = "Villas";
				
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Reserve-at-Great-Valley")) commStatus = "Only 7 Home Sites Remain"; //Img
		
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Dautcher-Farm")) commStatus = "Home Sites Selling Quickly, Quick Delivery Home"; //From Img
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Texas/The-Reserve-at-Katy/The-Estates")) commStatus += ", Final Home Remains"; //Img
		
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/New-York/Edge-on-Hudson-Residences-by-Toll-Brothers/Lofts-at-Edge-on-Hudson"))dpType = "4 Story";
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Regency-at-Waterside"))communityName = "Regency At Waterside";
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/California/Pacifica-San-Juan/Tradewinds")) commStatus = "Final Opportunity, Limited Homes Remain"; //From Image (17 Feb 21)
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Washington/Skycroft")) commStatus = "Last Chance";  //From Image (17 Feb 21)
	
		
		// ---notes-----//
		commStatus = commStatus.replace("Quick Delivery Homes, Quick Delivery Home", "Quick Delivery Home")
				.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon").replace("New Release Coming Soon, Coming Soon", "New Release Coming Soon");
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Nevada/Bella-Vista-Ranch/Mason-Ridge")) {
			//, , NV 89521
			add[0]="2204 Edgelands Drive";
			add[1]="Reno";
			add[2]="NV";
			add[3]="89521";
			
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		
		if(add[0].contains("117 Segal Drive GPS Users: 1426 W Baltimore Pike"))
			add[0]="117 Segal Drive";
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/South-Carolina/Longwood-Bluffs/Coastal-Collection"))
			commStatus=commStatus.replace("Home Sites Available,", "");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Villages-at-Chester-Springs"))
			commStatus=commStatus.replace("Last Chance, Now Available,", "");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/South-Carolina/Forest-Edge-by-Toll-Brothers"))
			commStatus=commStatus.replace(", Coming 2021", "");  //there is no logic to keep with coming soon
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Liseter/The-Devon-Collection"))
			commStatus="Final Home Now Available";
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Franklin-Station/The-Villages-Collection"))
			commStatus=commStatus.replace(", Now Available", "");
		if(notes.contains(", Lease Now"))
		notes=notes.replace(", Lease Now", "");
		
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Arizona/Preserve-at-San-Tan/Peralta-Collection"))
			maxSqf="3400";
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Washington/Cavalera"))minPrice="$764,995";
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Laurel-Pointe-Lake-Nona"))
			communityName = "Laurel Pointe";
		if(url.contains("https://www.canvastempe.com/"))notes="Now Pre Leasing";
		if(url.contains("https://www.liveunionplace.com/"))notes=ALLOW_BLANK;
		
		if(communityName.contains("Bungalow"))
			if(!propType.contains("Bungalow Homes"))
				if(propType==ALLOW_BLANK)
					propType = "Bungalow Homes";
				else
					propType+=", Bungalow Homes";
		
		
		
		
		// ========= Com NAme Replace ===========================
		communityName = communityName.replaceAll(
				" Country Club$|- Manor Homes| - The Courtyards$| Country Club - Villas$|Country Club - Golf Villas$| Country Club - Carriage Homes$| - Townhomes$|Country Club Active Adult Single Family Collection$|- Bungalows$",
				"");
		
		
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Florida/Edison/Ambassador-Collection"))commStatus+=", Quick Move-In Homes";
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Massachusetts/Enclave-at-Boxborough"))commStatus+=", New Home Sites Just Released";
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Illinois/Bowes-Creek-Country-Club-The-Fairways-Collection"))commStatus+=", New Home Sites Just Released";
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Pennsylvania/Regency-at-Creekside-Meadows/Villas-Collection"))commStatus="Quick Move-In Homes";
//		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/South-Carolina/Johnston-Pointe"))commStatus+=", Final Opportunity";
		if(url.contains("https://www.tollbrothers.com/luxury-homes-for-sale/Illinois/The-Woods-of-South-Barrington-Signature-Collection"))commStatus+=", Last Chance";
		
	if(commStatus.contains("Ready Home Available, Quick Move-In Homes"))commStatus=commStatus.replace("Ready Home Available, Quick Move-In Homes", "Quick Move-In Homes");

	if(url.contains("Colorado/%C3%A9lan-at-Wolf-Ranch"))communityName="Elan At Wolf Ranch";
	int lotCount=0;
	String noOfUnits=ALLOW_BLANK;
	if(html.contains(" Site Plan")) {
//		String sightMapSec=U.getSectionValue(html, "data-id=\"siteplan", "</button>");
//		U.log("lllll"+sightMapSec);
		String sightMapUrl=U.getSectionValue(html, "data-iframe=\"", "\"");
		U.log("sightMapUrl==="+sightMapUrl);
		if(sightMapUrl!=null) {
		String siteMapHtml=U.getHtml(sightMapUrl, driver);
		U.log("Path:: "+U.getCache(sightMapUrl));
		String sightSec=U.getSectionValue(siteMapHtml, "<div id=\"statuses-container\"", "<floorplan-filters class=\"ng-tns-c100-7 ng-star-inserted\"");
	    String lotsDetails[]=U.getValues(sightSec, "<label>", "</div><toggle>");//<div class=\"swatch\"
	    U.log("Total types of lots:: "+lotsDetails.length);
	    
	    for(String str:lotsDetails) {
	    	str=U.getNoHtml(str);
	    	U.log("STR"+str);
	    	String num=Util.match(str, "\\d+");
	    	U.log("NUMBERS"+num);
	    	lotCount+=Integer.parseInt(num);
	    	noOfUnits=Integer.toString(lotCount);
	    	}
	}
	}
	
	if(noOfUnits.equals("0"))noOfUnits=ALLOW_BLANK;
		
		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0].replaceAll(",", ""), add[1], add[2].trim(), add[3].trim());	
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus.replace("Quick Move-in, Quick Move-In Homes", "Quick Move-In Homes").replace(", ,", ","));
		data.addNotes(notes.replace("Now Leasing, Lease Now", "Now Leasing"));
        data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
        data.addUnitCount(noOfUnits);
		}
	cnt++;
//		}catch (Exception e) {}
	}
	
	public static String formatMillionPrices(String html){
		Matcher millionPrice = Pattern.compile("\\$\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice.find()){
			U.log(millionPrice.group());
			String floorMatch = millionPrice.group().replaceAll(" Millions", ",000,000");  
			U.log(floorMatch);//$1.3 M
			html	 = html.replace(millionPrice.group(), floorMatch);
			}//end millionPrice
		return html;
	}
}