package com.shatam.b_001_020;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;

public class TollBrothersApartmentLiving extends AbstractScrapper {
	String  html1 = U
			.getHTML("http://www.tollbrothersapartmentliving.com/Find-an-Apartment.aspx#s1");
	// Creating single driver instance

	WebDriver driver = null;

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new TollBrothersApartmentLiving();
		a.process();
		FileUtil.writeAllText( U.getCachePath()+"Toll Brothers Apartment Living.csv", a
				.data().printAll());
	}

	public TollBrothersApartmentLiving() throws Exception {
		super("Toll Brothers Apartment Living",
				"http://www.tollbrothersapartmentliving.com/");
	}

	String state;
	int count = 0;

	public void innerProcess() throws Exception {
		String html1 = U
				.getHTML("http://www.tollbrothersapartmentliving.com/Find-an-Apartment.aspx#s1");

		String[] links = U.getValues(html1, "<div class=\"col-md-3",
				"Read More</a></div>");

		for (String link : links) {

			link = U.getSectionValue(link, "<a href=\"", "\"");
			U.log("Communities URL: " + link);
			if (!StringUtils.isEmpty(link.trim()))
				commDetails(link.trim());
		}

		if (driver != null)
			driver.close();
	}

	public void commDetails(String commUrl) throws Exception

	{
		U.log("Page Url: " + commUrl);

		// ...........................Community Name...........................
		String html = U.getHTML(commUrl);
		html=html.replace(" traditional American fare","");
		// String commName = ALLOW_BLANK;
		//if(!commUrl.contains("http://www.kensingtonplacenj.com"))return;
	
		String commName = ALLOW_BLANK;

		commName = U.getSectionValue(html,
				"<a href=\"/Home.aspx\" style=\"\">", "</a></li>");
		if(commName==null){
			commName=U.getSectionValue(html,"deluxe amenities. Call ","!\" /> ");
		}
		
		String amen=U.getHTML(commUrl+"/Amenities.aspx");
		// Add
		String flag = ALLOW_BLANK;
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String sectionAdd = U.getSectionValue(html, "class=\"footer-ad\">",
				"<a class");
		sectionAdd=sectionAdd.replace("Riverworks","");
		sectionAdd=sectionAdd.replace("Parc Westborough","");
		sectionAdd=sectionAdd.replace("The Morgan At Provost Square","");
		sectionAdd=sectionAdd.replace("Parc Plymouth Meeting","");
		sectionAdd=sectionAdd.replace("The Mews At Princeton Junction","");
		sectionAdd=sectionAdd.replace("Dulles Greene","");
		sectionAdd=sectionAdd.replace("Parc Riverside","");
		sectionAdd = sectionAdd.replace("&nbsp;", " ");
		sectionAdd=sectionAdd.replace("Kensington Place","");
		//sectionAdd = sectionAdd.replace(commName, "");
		add = U.findAddress(sectionAdd);
		U.log("My Section address:  " + sectionAdd);

		// Price

		// Floor Plans Links ..
		String floorSection = U.getSectionValue(html, "<li class=\"floor\"",
				"</a>");
		String floorLink = U.getSectionValue(floorSection, "<a href=\"", "\"");
		floorLink = commUrl + floorLink;
		floorLink=floorLink.replace("/Home.aspx","");
		U.log("Floor Link : " + floorLink);

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		if (driver == null) {
			driver = new FirefoxDriver();
		}

		String floorHtml = U.getHtml(floorLink, driver);
		// String price[] = U.getPrices(floorHtml, "", group)
		// Sqft

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String sqft[] = U.getSqareFeet(floorHtml, "\\d{1},\\d{3}|\\d{3} sqft|\\d{4} sqft|\\d{4} SQFT|\\d{3} \\- \\d{3} sqft", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		

		// LatLng

		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		flag = "TRUE";

		if(html.contains("/Neighborhood.aspx")){
			commUrl=commUrl.replace("/Home.aspx","");
			String dirLink = commUrl + "/Neighborhood.aspx";
			
			U.log(dirLink+"dirLink");
			String htmlDir = U.getHtml(dirLink, driver);
			latLng[0] = U.getSectionValue(htmlDir, "latitude='", "'");
			latLng[1] = U.getSectionValue(htmlDir, "longitude='", "'");
			flag = "FALSE";
		}
		
		if(latLng[0]==ALLOW_BLANK)
		latLng = U.getlatlongGoogleApi(add);

		// Community Type
		String communitytype = U.getCommunityType(html1+html+amen);

		// Property Type
		String proptype = U.getPropType(html);
		//proptype="Apartment, "+proptype;
		// Derive Prop
		String dtype = U.getdCommType(html);

		// Status
		String propstatus = U.getPropStatus(html);

		if (data.communityUrlExists(commUrl))
			return;
		
		if(commUrl.contains("http://www.liveriverworks.com")){minSqft="511";maxSqft="1240";}
		if(commUrl.contains("http://www.parcwestborough.com")){minSqft="777";maxSqft="1411";}
		if(commUrl.contains("http://www.livethemorgan.com")){minSqft="481";maxSqft="1481";}
		if(commUrl.contains("http://www.kensingtonplacenj.com")){minSqft="679";maxSqft="1584";}
		if(commUrl.contains("http://www.themewsatprincetonjunction.com")){minSqft="730";maxSqft="1344";}
		if(commUrl.contains("http://www.dullesgreene.com")){minSqft="750";maxSqft="1370";}
		if(commUrl.contains("http://www.parcriverside.com")){minSqft="468";maxSqft="1339";}
		if(commUrl.contains("http://www.parcplymouthmeeting.com")){minSqft="622";maxSqft="1307";}
		commName=commName.replace("Parc Plymouth Meeting","Parc");
		
		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0], latLng[1], flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(ALLOW_BLANK);
	}

}