package com.shatam.b_021_040;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class Brookfield extends AbstractScrapper{
	CommunityLogger LOGGER;

	public Brookfield() throws Exception {

		super("Brookfield Residential Properties", "https://www.brookfieldresidential.com/");
		LOGGER = new CommunityLogger("Brookfield Residential Properties");
	}

	int i=0; int count = 1;
	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new Brookfield();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Brookfield Residential Properties.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
	
		String regionHtml = U.sendPostRequestAcceptJson("https://www.brookfieldresidential.com/sitecore/api/ssc/BrookfieldResidential-Web-Areas-BRP-Controllers-Api/additionalsearch", 
				"{\"MinLongitude\":0,\"MinLatitude\":0,\"MaxLongitude\":0,\"MaxLatitude\":0,\"homebaths\":null,\"homebedrooms\":null,\"minimum_neighborhood_footage\":null,\"maximum_neighborhood_footage\":null,\"minimum_neighborhood_price\":null,\"maximum_neighborhood_price\":null,\"GroupMapPins\":false,\"isDefaultSearch\":false,\"ResultType\":\"FYHExperience\"}");
		//
//		U.log("regionHtml: "+regionHtml);
//		FileUtil.writeAllText("/home/shatam-100/Cache/test.txt", regionHtml);
		String communityData[] = U.getValues(regionHtml, "\"UniqueId\":{\"id\":\"", "\"maximumResidenceBaths\""); 
		U.log(communityData.length);
//		U.setUpChromePath();
//		WebDriver driver=new ChromeDriver();
		
		for(String cd:communityData) {

			String communityurl=U.getSectionValue(cd, "\"Url\":\"", "\"");
			if(communityurl.contains("alberta")||communityurl.contains("ontario/greater-toronto-area"))continue;
			
			U.log(""+count+" communityurl: "+communityurl);
			count++;
			//	U.log(cd);
			String compositeID =U.getSectionValue(cd, "CompositeIDs", "neighborhoodLotUnitNumber");
			U.log(compositeID);
			
			
//			try {
				adddetails(cd,communityurl);
//			} catch (Exception e) {}
			
		//	U.log("=============");
		}
		LOGGER.DisposeLogger();
		
	}
	public void adddetails(String jsonData,String comUrl) throws Exception {
		
		comUrl="https://www.brookfieldresidential.com"+comUrl;
		//Single com ++
//		if(!comUrl.contains("https://www.brookfieldresidential.com/new-homes/maryland/montgomery-county/clarksburg/bellamy")) return;
		
//	if(i>=30) 
	{
		
		U.log(comUrl+"============="+i);
		
		if(comUrl.contains("https://www.brookfieldresidential.com/new-homes/texas/austin-area/san-marcos/blanco-vista")
				|| comUrl.contains("https://www.brookfieldresidential.com/new-homes/california/riverside-county/menifee/audie-murphy-ranch")) {
			LOGGER.AddCommunityUrl(comUrl+"============>Return because its not showing on region page");
			return;
		}
		
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"============repeated");
			return;
		}
		
		
		String comHtml = U.getHTML(comUrl);
		U.log(U.getCache(comUrl));
		
		//-------removing otherNeighbourhoods sections below
		if(comHtml.contains("\"type\": \"otherNeighborhoods\",")) {
			
			String removeOtherNeigh = U.getSectionValue(comHtml, "\"type\": \"otherNeighborhoods\",", "</script>");
			
			comHtml = comHtml.replace(removeOtherNeigh, "");
			//U.log("removeOtherNeigh: "+removeOtherNeigh);
		}

		//-------returning main community here
		if(comHtml.contains("\"neighborhoods\": [")) {
			
			LOGGER.AddCommunityUrl(comUrl+"============ Returned as MainCommunity");
			U.log("Returned as Main Community------");
			return;
		} 
		LOGGER.AddCommunityUrl(comUrl);

		
		String comDesc = U.getSectionValue(comHtml, " \"description\": \"", "\"name\"");
		U.log("comDesc: "+comDesc);
		
		String headline = ALLOW_BLANK;
		if(comHtml.contains("\"headline\":") && comHtml.contains("\"imgUrl\":")) {
			headline = U.getSectionValue(comHtml, "\"headline\": \"", "\"imgUrl\"");
			U.log("headline: "+headline);
		}
		
		String[] headlinesArray;
		String combinedHeadlines = ALLOW_BLANK;
		
		if(comHtml.contains("\"headline\":")) {
			headlinesArray = U.getValues(comHtml, "\"headline\": \"", "\"");
			for(String head:headlinesArray) {
				combinedHeadlines += head; 
			}
		}
		
		U.log("jsonData: "+jsonData);
		String comName=U.getSectionValue(jsonData, "\"MyTimeMPCNameSortString\":\"", "\"");
		
		comName = comName.replaceAll(" Country Club$", "");
		
		U.log("comName: "+comName);
		
		//============================ Address ===============================
		
		String [] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String latlong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		String addSec = ALLOW_BLANK;
		if(comHtml.contains("salesCenters")) {
			
			addSec = U.getSectionValue(comHtml, "salesCenters", "officeHoursHtml");
//			U.log("addSecaddSecaddSecaddSecaddSec"+addSec);
			if(addSec != null) {
				
				add[0] = U.getSectionValue(addSec, "streetAddress1\": \"", "\"");
				add[1] = U.getSectionValue(addSec, "city\": \"", "\"");
				add[2] = U.getSectionValue(addSec, "stateCode\": \"", "\"");
				add[3] = U.getSectionValue(addSec, "zipCode\": \"", "\"");
				
				if(add[2] != null) {
					add[2] = add[2].replace("Colorado", "CO").replace("California", "CA").replace("Virginia", "VA")
							.replace("Texas", "TX").replace("Delaware", "DE").replace("Maryland", "MD");
				}
				
				if(add[0].isEmpty()) add[0] = ALLOW_BLANK; 
					
				U.log("ADDRESS: "+Arrays.toString(add));
			}
		}
		U.log("ADDRESS: "+Arrays.toString(add));
		 latlong[0]=U.getSectionValue(jsonData, "\"latitude\":", ",");
		 latlong[1]=U.getSectionValue(jsonData, "\"longitude\":", ",");
		
		U.log("LATLONG: "+Arrays.toString(latlong));
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{50}salesCenters[\\s\\w\\W]{500}", 0));
		
//		if(comUrl.contains("https://www.brookfieldresidential.com/new-homes/texas/austin-area/san-marcos/blanco-vista")) {
//			
//			add[0]="4040 Trail Ridge Pass";
//			add[1]="San Marcos";
//			add[2]="TX";
//			add[3]="78666";
//			latlong=U.getlatlongGoogleApi(add);
//			geo="TRUE";
//		}
		
		if(latlong[0].equals("0.0")) {
			if(comUrl.contains("texas") && comUrl.contains("austin")) {
			add[1]="Austin";
			add[2]="TX";
			latlong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlong);
			geo="TRUE";
			}
		}
		if(latlong != null && add[0]==ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latlong);
			U.log(Arrays.toString(add));
			U.log("ADDRESS: "+Arrays.toString(add));
			geo="TRUE";
		}

		
		//============================ Homes and Plan Data
		
		//FileUtil.writeAllText("/home/shatam-10/Desktop/comdatahtml.txt",comHtmlData);
		
		String homePlanSec = U.getSectionValue(comHtml, "\"type\": \"homesAndPlans\"", " </script>");
		//U.log("homePlanSec: "+homePlanSec);
		String homePlanData = ALLOW_BLANK;
		String homePlanDesc = ALLOW_BLANK;
		
		if(homePlanSec != null) {
			
			String[] getUrls = U.getValues(homePlanSec, "\"url\": \"", "\"");
			for(String urls:getUrls) {
				if(urls.contains(".jpg") || urls.contains(".svg")) continue;
				U.log("urls: "+urls);
				String homePlanUrl = "https://www.brookfieldresidential.com" + urls;
				U.log("homePlanUrl: "+homePlanUrl);
				
				//503 error
//				if(homePlanUrl.equals("https://www.brookfieldresidential.com/new-homes/california/east-bay/oakley/delaney-park/southport/717-delaney-parkway-unit-000214")) continue;
//				if(homePlanUrl.equals("https://www.brookfieldresidential.com/new-homes/colorado/denver/brighton/brighton-crossings/mosaic/394-baler-ct-unit-712001")) continue;
//				if(homePlanUrl.contains("https://www.brookfieldresidential.com/new-homes/colorado/denver/brighton/brighton-crossings/mosaic")) continue;
//				if(homePlanUrl.contains("https://www.brookfieldresidential.com/new-homes/colorado/denver/brighton/brighton-crossings/mosaic/393-baler-ct-unit")) continue;
				
				String homePlanInfo = U.getHTML(homePlanUrl);
//				U.log("homePlanInfo: "+homePlanInfo);

				if(homePlanInfo!=null) {
					homePlanDesc += U.getSectionValue(homePlanInfo, "\"description\": \"", "\"image");
				}
				homePlanInfo = U.removeSectionValue(homePlanInfo, "<script type=\"application/ld+json\">", "\"@type\": \"Product\"");
//				if(homePlanInfo.contains("1143000"))
//					U.log("FOUND");
//				if(homePlanInfo.contains("562990"))
//					U.log("FOUND");
//				homePlanInfo = homePlanInfo.replace("562990", "");
//				homePlanInfo = homePlanInfo.replace("\"highPrice\": \"1143000\",", "");
				homePlanData += homePlanInfo; 
			}
			
			
//			U.log("homePlanDesc: "+homePlanDesc);
		}
		

		
		// ==================== Prices =======================
		String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		prices =U.getPrices(homePlanData + comDesc + combinedHeadlines, "the mid \\$\\d{3},\\d{3}|starting from \\$\\d,\\d{3},\\d{3}|\"lowPrice\": \"\\d{7}\",|\"lowPrice\": \"\\d{6}|\"highPrice\": \"\\d{6}|\"price\": \\d{6},|"
				+ "\"price\": \"\\d{6}\",|\"price\": \\d{7},", 0);
		U.log(homePlanData.length());
		U.log("Prices: "+Arrays.toString(prices));
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(combinedHeadlines, "[\\s\\w\\W]{30}114300[\\s\\w\\W]{30}", 0));
		U.log(">>>>>>>>>>>>"+Util.matchAll(homePlanData, "[\\s\\w\\W]{30}114300[\\s\\w\\W]{30}", 0));
//		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comDesc, "[\\s\\w\\W]{30}114300[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(combinedHeadlines, "[\\s\\w\\W]{30}600[\\s\\w\\W]{30}", 0));

		// ==================== SqFt =======================
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		sqft =U.getSqareFeet(homePlanData + comDesc, "\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} square feet|\"minFootage\": \\d{4}|\"maxFootage\": \\d{4}|\"minFootage\": \\d{3},", 0);
		
		U.log(Arrays.toString(sqft));
		
		//======================== pType =======================

		String pType=ALLOW_BLANK;
		
		String otherNeigh = U.getSectionValue(comHtml, "\"title\": \"Other Neighborhoods\",", "</script>");
		
		if(otherNeigh != null) comHtml = comHtml.replace(otherNeigh, ""); 
		
		
		comHtml = comHtml.replaceAll("Sales Office for Traditional and Urban Homes|Brookfield Solterra BigSky3 Loft|loft.jpg|BigSky 3 Loft", "")
				.replace("Where modern luxury lives in the architecture", "Where modern luxury living in the architecture");
		
		homePlanDesc = homePlanDesc.replace("sacrifice the luxury of a spacious home", "sacrifice the luxury living of a spacious home")
				.replaceAll("luxury|luxurious", "luxury living").replace("prices for detached home designs", "prices for detached residences designs")
				.replaceAll("Sales Office for Traditional and Urban Homes", "");
		
		 pType=U.getPropType(comDesc + homePlanDesc + comHtml);
		 U.log("pType: "+pType);
//		 U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}detached[\\s\\w\\W]{30}", 0));
//		 U.log(">>>>>>>>>>>>"+Util.matchAll(homePlanData, "[\\s\\w\\W]{30}detached[\\s\\w\\W]{30}", 0));
		 		
		//======================== dType ======================= 
		String dType=ALLOW_BLANK;
		
		comDesc = comDesc.replace("three- and four-story","3 Story and 4 Story");
		
		homePlanData = homePlanData.replace("\"story\": 4.0", "4 Story").replace("\"story\": 1.0", "1 Story").replace("\"story\": 2.0", "2 Story")
				.replace("(Colonial)", "")
					.replaceAll("Colonial doors|home is on the 2nd floor which|third floor features|4-level|3rd level features|first floor", "");
			
			 dType = U.getdCommType(homePlanData + comDesc);
			 U.log("dType: "+dType);
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(homePlanData, "[\\s\\w\\W]{30}first floor[\\s\\w\\W]{30}", 0));
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(homePlanData, "[\\s\\w\\W]{30}4-level townhomes[\\s\\w\\W]{30}", 0));
			 
		//=============================== cType ==============================
		String cType=ALLOW_BLANK; String planningType=ALLOW_BLANK;
		comDesc = comDesc.replace("retail, and resort destination", "retail, and resort-inspired community destination")
				.replace("proximity to the active lifestyle", "proximity to the active adult lifestyle")
				.replace("golf-adjacent living", "golf course living")
				.replace("55+", "55+ Community").replace("adults 55+", "active adults 55+ community");
		
		combinedHeadlines = combinedHeadlines.replace("resort recreation", "resort style recreation");
		
		String comname = comName;
		comname = comname.replace("55+ at Heritage Shores", "55+ living at Heritage Shores");
				
		if(comHtml.contains("\"planningType\"")) {
			planningType = U.getSectionValue(comHtml, " \"planningType\": \"", "\"");
			U.log("planningType: "+planningType);
		}
		
		cType=U.getCommType(comDesc+comname+headline+planningType+combinedHeadlines);
				
		U.log("cType: "+cType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(homePlanData, "[\\s\\w\\W]{30}golf[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(combinedHeadlines, "[\\s\\w\\W]{30}resort[\\s\\w\\W]{30}", 0));
		
		//=============================== pStatus ============================	 
		String pStatus=ALLOW_BLANK;
		
		comHtml = comHtml.replace("Available, Reserved or Temporarily Sold Out?", "");
		comHtml = comHtml.replace("\"elevationSummaryStatus\": \"Sold Out\",", "");
				
		pStatus=U.getPropStatus((comHtml).replaceAll("Boulevard is now selling|Homes Now Selling|selling floor plans|One Lake is now selling|modern townhomes now selling|Homes Coming Soon In Fairfield|Lakeside at One Lake is now selling|single-family homes coming spring|show as “Temporarily Sold Out” which|Sales Gallery is now open by appointment|mean when a home says Coming Soon|answer\": \"“Coming Soon|Reserved or Temporarily Sold Out|With each new phase release, we make|The course is now open to the public|new retail coming soon to The Groves|model homes and move-in ready homes with a private|MyTimeSnipe\":\"MOVE-IN READY","")); 
		
		//For "Sold Out" Status
		if(jsonData.contains("\"isComingSoon\":false") && jsonData.contains("\"PlanElevationSummaryStatus\":\"Temporarily Not Available\"")) {
			
//			if(pStatus == ALLOW_BLANK)
//				pStatus = "Sold Out";
//			else if(pStatus != ALLOW_BLANK && !(pStatus.contains("Sold Out")))
//				pStatus = pStatus + ", Sold Out";
		}
		
		
		U.log("pStatus --- "+pStatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Now Selling[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Temporarily Sold Out[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
				
				
				if(prices[0]==null)prices[0]=ALLOW_BLANK;
				if(prices[1]==null)prices[1]=ALLOW_BLANK;
				if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
				if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
				
				
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				String sitePlanSec = ALLOW_BLANK; String sitePlanUrl = ALLOW_BLANK;
				
				if(comHtml.contains("\"siteplanCta\":")) {
					sitePlanSec = U.getSectionValue(comHtml, "\"siteplanCta\": {", "},");
					U.log("sitePlanSec: "+sitePlanSec);
					
					if(sitePlanSec != null) {
						sitePlanUrl = U.getSectionValue(sitePlanSec, "\"url\": \"", "\",");
						sitePlanUrl = "www.brookfieldresidential.com" + sitePlanUrl;
						U.log("sitePlanUrl: "+sitePlanUrl);	
						
						String compositeId = U.getSectionValue(sitePlanUrl, "siteplanCommunityId=", "&");
						U.log("compositeId: "+compositeId);
						if(compositeId == null) {
							sitePlanUrl = sitePlanUrl + "&";
							compositeId = U.getSectionValue(sitePlanUrl, "siteplanCommunityId=", "&");
						} 
						
						
						String siteJson = sendPostRequestAcceptJson("https://www.brookfieldresidential.com/sitecore/api/ssc/BrookfieldResidential-Web-Areas-BRP-Controllers-Api/siteplan_lotsplans", "{\"compositeId\":\""+ compositeId+"\"}");
						//U.log("siteJson: "+siteJson);
						
						if(siteJson != null) {
							
							String lotSec = U.getSectionValue(siteJson, "\"lots\":[", "],\"fallbackURL\"");
							//U.log("lotSec: "+lotSec);
							
							if(siteJson != null) {
								
								String[] projectName = U.getValues(lotSec, "\"projectName\":\"", "\"");
								U.log("projectName.length: "+projectName.length);
								int count = 0; 
								
								for(String name:projectName) {
									
									if(comName.contains(name)) {
										U.log(+count+ " name: "+name);
										count++;
									}
								}
								
								//for 0 and 1 count
								if(count == 0 || count == 1) {
									count = projectName.length;
								}
								
								U.log("count: "+count);
								units = String.valueOf(count);
							}
							

						}
					}
				}
				
				

				data.addCommunity(comName.replace("'s", "s"), comUrl, cType);
				data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
				data.addPrice(prices[0], prices[1]);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(sqft[0], sqft[1]);
				data.addPropertyType(pType, dType);
				data.addPropertyStatus(pStatus);
				data.addNotes(U.getnote(comHtml));
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);		
				
				
	}			
				
		
	i++;
	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
//		U.log(U.getCache(fileName));
		U.log("fileName: "+fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
	        connection.setRequestProperty("Accept", "application/json, text/plain, */*");
	        connection.setRequestProperty("Content-Security-Policy", "default-src 'self' 'unsafe-inline' 'unsafe-eval' https://apps.sitecore.net; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' 'unsafe-inline' https://fonts.gstatic.com; upgrade-insecure-requests; block-all-mixed-content;");
	        connection.setRequestProperty("Cookie", "_hjid=a3823b53-5241-4af1-ae8d-18b840af0087; _ga=GA1.2.2092636629.1631791442; SC_ANALYTICS_GLOBAL_COOKIE=147407f815cd44968dbf6fab2d107c4d|True; fpestid=mLvuO1em9GRonC9RnrQ-RRh8aAgwtDRRbtIhKhO4zzKkyFZauwRhRfwgoHYcTcSqGrX1lQ; hubspotutk=1f84a7c5ed8606bae5347444b20a247c; OptanonAlertBoxClosed=2021-09-16T11:24:12.772Z; calltrk_referrer=direct; calltrk_landing=https%3A//www.brookfieldresidential.com/new-homes/colorado/denver/denver/central-park/signature; brandcdn_uid=2b5996fa-4f28-4b6c-bfe0-bc0f4a6e8974; _hjSessionUser_1858142=eyJpZCI6IjA1ZWRlYjlmLTBjZGMtNWNkOC05NjkwLWUyZGQ4NWQ4YmY3OSIsImNyZWF0ZWQiOjE2NTAwOTI1NzQ1NjksImV4aXN0aW5nIjp0cnVlfQ==; _gcl_au=1.1.227644116.1650092579; _fbp=fb.1.1650092580219.2003590700; _clck=1gf12gm|1|f0o|0; ASP.NET_SessionId=a1v3myx1zq25neidnfzcrgbi; __RequestVerificationToken=7vrHm2g3akxmUfRPvx-8RW4KMaE53ITkHVhHYLhPCrdYi0PfdOOTGf2kTD1DjLJp3Wz_JZkje2nvunGJAEXokE7yVpaheQ3z0CoRW4qchSQ1; _gid=GA1.2.781243313.1650258777; _hjSession_1858142=eyJpZCI6IjViOTU5MjZhLWYyNTQtNDYzNy04YzRjLTljZWE1MTYwMGZhNyIsImNyZWF0ZWQiOjE2NTAyNTg3Nzc2MTAsImluU2FtcGxlIjp0cnVlfQ==; _hjAbsoluteSessionInProgress=1; __hssrc=1; brookfieldresidential#lang=en; rl_visitor_history=f840a6fa-aa6f-42ad-b924-a0b7a01c62f8; sifi_user_id=undefined; _hjIncludedInSessionSample=0; __hstc=41670589.1f84a7c5ed8606bae5347444b20a247c.1631791444976.1650258784410.1650264763114.6; _hjIncludedInPageviewSample=1; OptanonConsent=isIABGlobal=false&datestamp=Mon+Apr+18+2022+13%3A42%3A39+GMT%2B0530+(India+Standard+Time)&version=6.7.0&hosts=&consentId=5739ea28-05f4-4666-9ffe-fd8a8a7daa46&interactionCount=1&landingPath=NotLandingPage&groups=C0003%3A1%2CC0002%3A1%2CC0001%3A1%2CC0004%3A1%2CBG15%3A1&geolocation=%3B&AwaitingReconsent=false; _gat_UA-35969439-1=1; _uetsid=35ab96d0bed611ec91c7eb31a86008ee; _uetvid=97e1b68016e011ecbff4a9f0a26bd9e0; _tq_id.TV-18904545-1.54b2=eef58296e51dffd6.1631791442.0.1650269562..");
	        connection.setRequestProperty("Referer", "https://www.brookfieldresidential.com/new-homes?siteplanCommunityId=NSE%7E221H%7E1334&neighborhoodItemId=9d8c40b422ad4964855655a47c2b87b0&viewport=hash");
	        connection.setRequestProperty("Host", "www.brookfieldresidential.com");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36");
	        connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
}