/**
 * @Modified MJS
 * @date 19/08/19
 * @author Upendra Singg
 * @date 19/04/2018
 */
package com.shatam.b_021_040;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.params.AllClientPNames;
import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractHovnanian extends AbstractScrapper {
	static String BUILDER_NAME = "K. Hovnanian Homes";
	static int count = 0;
	public int dup = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	String status;
	WebDriver driver;
	private static LatencyCounter LATENCY = null;
	static String Builder_Url = "https://www.khov.com";

	public ExtractHovnanian() throws Exception {
		super(BUILDER_NAME, Builder_Url);
		LOGGER = new CommunityLogger("K. Hovnanian Homes");
	}

	public static void main(String[] args) throws Exception {
		
		LATENCY = new LatencyCounter();
		LATENCY.start("Time");
		AbstractScrapper a = new ExtractHovnanian();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "K. Hovnanian Homes.csv", a.data().printAll());
		U.log("count==" + count);
		LATENCY.end("Time");
		U.log(LATENCY);
	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String MainHtml = U.getPageSource(Builder_Url);
		String regionState = U.getSectionValue(MainHtml, "var selectedState=", "}}]");
		//U.log(regionState);
		String[] state = U.getValues(regionState, "Url\\\":\\\"", "\\\"");
		for (String string : state) {
			U.log("https://www.khov.com" + string);
			String stateHtml = U.getPageSource("https://www.khov.com" + string);
			String[] comdata = U.getValues(stateHtml, "{\\\"Name\\\":\\", "MapHoverButtonMode");
			//U.log(comdata.length);
			for (String data : comdata) {
				String url = Builder_Url + U.getSectionValue(data, "DetailLink\\\":\\\"", "\\\"");
				url = url.replace("\\\\", "\\");
				if(url.contains("/k-hovnanian-homes/estates-of-chancellorsville"))U.log(data);
				addDetails(data, url);
			}
		}
//		//U.log(comData.size());
//		Iterator<String> ite = comData1.iterator();
//		while (ite.hasNext()) {
//			String data = ite.next();
//			String url = Builder_Url + U.getSectionValue(data, "DetailLink\\\":\\\"", "\\\"");
//			url = url.replace("\\\\", "\\");
//			addDetails(data, url);
//			//break;
//		}

		LOGGER.DisposeLogger();
        driver.quit();
	}

	private void addDetails(String comSec, String comUrl) throws Exception {
	//	try{
		
//		if(j>=150)
		{
			comUrl = org.apache.commons.lang.StringEscapeUtils.unescapeJava(comUrl);
			
		///**********Single Run*********************
//		if (!comUrl.contains("https://www.khov.com/find-new-homes/virginia/stafford/22554/k-hovnanian-homes/hampton-run"))return;
	///    if (!comUrl.equals("https://www.khov.com/find-new-homes/arizona/phoenix/85021/k-hovnanian-homes/23-north"))return;


if(comUrl.contains("https://www.khov.com/find-new-homes/texas/rowlett/75088/k-hovnanian-homes/bayside")||comUrl.contains("https://www.khov.com/find-new-homes/texas/murphy/75094/k-hovnanian-homes/bluff-creek-estates"))return;
			U.log("count::" + j + "\ncomUrl::" + comUrl);
			U.log("Path::" + U.getCache(comUrl));
			String comHtml = U.getHTML(comUrl);
		//	String comHtml = U.getPageSource(comUrl);
		//	String comHtml = U.getHtml(comUrl, driver);
			String comHtml1  = comHtml;
			String remov = U.getSectionValue(comHtml, "OTHER NEW HOME COMMUNITIES NEARBY", "</html>");
			//U.log(remov);
			if(remov == null)remov = U.getSectionValue(comHtml, "var __communityInquiry='", "</html>");
			if(remov !=null)comHtml = comHtml.replace(remov, "");
			comHtml = comHtml.replaceAll("body-copy>\\s*<span class=weight-bold>Coming soon!</span>", "");
			comHtml=comHtml.replaceAll("Stories</span>\n\\s*<span class=numeric-amount>|Stories\\s*</span>\\s*<span class=numeric-amount>", "Story ");
			
			if(remov != null)
				comHtml=comHtml.replace(remov, "");

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

		//	U.log(comSec);

			// ======================================= remove
			// Sec==================================
			String rem = U.getSectionValue(comHtml, "<div class=\"otherCommunities featured-other-communities", "<div class=footerQuestions>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "\"", "\\\"").replace("\\\\", "\\").replace("???", "'");
		//	U.log("Com Name::::::::" + comName);
			comName = org.apache.commons.lang.StringEscapeUtils.unescapeJava(comName);//remove escape character
			comName  = comName.replaceAll("K. Hovnanian's<sup>\\?\\?</sup>| - Villas$| - Condos$|K. Hovnanian’s<sup>\\?\\?</sup>|K. Hovnanian’s<sup>®</sup> |K. Hovnanian's<sup>®</sup> | - Single Family$| - Luxury Condos$", "");
			if(comName.endsWith("Townhomes")||comName.endsWith("Villas"))comName = comName.replaceAll("Townhomes|Villas", "");
			U.log("comName : "+comName);
			
			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			U.log(comSec);
			

			String addSec = U.getSectionValue(comHtml, "<a href=\"http://maps.google.com/maps?saddr=My%20Location", "<div class=row>");
		//	U.log("this is addSec:::::::::"+addSec);
			if(addSec!=null) {
				addSec = U.getSectionValue(addSec, "target=_blank>", "</a>");
				addSec = addSec.replace("<br>", ",").replace("&amp;", "&").replace(".", "");
				add= U.getAddress(addSec);
				U.log("Add: "+Arrays.toString(add));
				
			}
			if(add[0]==null || add[1]==null || add[2]==null || add[3]==null) {
				
				comSec=comSec.replace("\\\\u0026", "&").replace("???", "'");
				add[0] = U.getSectionValue(comSec, "Address\\\":\\\"", "\\\"");
				add[1] = U.getSectionValue(comSec, "City\\\":\\\"", "\\\"");
				add[2] = U.getSectionValue(comSec, "StateAbbreviation\\\":\\\"", "\\\"");
				add[3] = U.getSectionValue(comSec, "ZipCode\\\":\\\"", "\\\"");
			}
			if(add[0]==ALLOW_BLANK || add[1]==ALLOW_BLANK || add[2]==ALLOW_BLANK || add[3]==ALLOW_BLANK) {
				
				comSec=comSec.replace("\\\\u0026", "&").replace("???", "'");
				add[0] = U.getSectionValue(comSec, "Address\\\":\\\"", "\\\"");
				add[1] = U.getSectionValue(comSec, "City\\\":\\\"", "\\\"");
				add[2] = U.getSectionValue(comSec, "StateAbbreviation\\\":\\\"", "\\\"");
				add[3] = U.getSectionValue(comSec, "ZipCode\\\":\\\"", "\\\"");
			}
			if(comUrl.contains("https://www.khov.com/find-new-homes/ohio/elyria/44035/four-seasons/k-hovnanian's-four-seasons-at-chestnut-ridge")) {
				add[0] = add[0].replace("(Corner of Chestnut Ridge Road & Bender Rd.)", "");
				}
			
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latlong[0] = U.getSectionValue(comSec, "Latitude\\\":", ",");
			latlong[1] = U.getSectionValue(comSec, "Longitude\\\":", "}");

			if (add[0] == null && latlong[0] != null) {

				add = U.getAddressGoogleApi(latlong);
				if(add == null) add = U.getAddressHereApi(latlong);
					
				geo = "TRUE";
			}
			if (add[0] != null && latlong[0] == null) {

				latlong = U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			if (add[2].length() > 2) { 
				add[2] = USStates.abbr(add[2]).trim();
			}
			add[0] = add[0].replace(" (Off University Drive just north of Sample Rd)", "").replace("\\\\t\\\\t\\\\t\\\\t\\\\t\\\\t", "").replace("\\\\u0027", "'")
					.replaceAll("And NE Cardinal Avenue|,", "")
					.replace("Trail Centreville", "Trail");
			
			// ==============================================================Price &&
			// SF============================================
			String homeData=getHomeData(comHtml);
			String qData = getQData(comHtml);
			String rwas = "";
			if (qData.length() != 0) {
				String[] remove = U.getValues(qData, "Was: <span class=numeric-amount>", "</span></h4>");
				for (String r : remove) {
					//U.log(r);
					rwas += r;
				}
			}
			//U.log(comSec);
			comSec = formatMillionPrices(comSec);
			comSec = comSec.replace("FormattedPrice\\\":\\\"Upper $800", "").replaceAll("\"formattedPrice\":\"Lower \\$\\d+|FormattedPrice\\\":\\\"Upper \\$800,000", "").replace("$1 millions", "$1,000,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec = comSec.replaceAll("0s|0S|0's|0&#39;s", "0,000");
			comHtml = comHtml.replaceAll("homesites from \\d,\\d+ sq\\. ft|\\d{2},\\d{3} sq. ft|\"formattedPrice\":\"Lower \\$\\d+", "").replaceAll("0s|0S|0's|0&#39;s|0s</span>", "0,000")
					.replace(" $1 millions", "$1,000,000").replaceAll("(W|w)as:\\s*<span class=numeric-amount>\\s*\\$(\\d,)?\\d+,\\d+", "").replace("between $0 and $250,000,000", "").replace("between $0 and $1,000,000", "");
			homeData = homeData.replaceAll("Was:\\s*\\$\\d+,\\d+", "");
			if(qData != null)
				qData = qData.replace(rwas, "").replaceAll(" Was: \\$(\\d,)?\\d{3},\\d{3}|\\$\\d+,\\d+ in upgrades included", "");

			//comHtml=comHtml.replaceAll(">$657,395", "");
			U.log(comSec);
			String[] prices = U.getPrices((comHtml + comSec+homeData+qData).replaceAll("amount between \\$\\d+ and \\$\\d+,\\d+,\\d+|\"formattedPrice\":\"Mid \\$500,000\",\"location\"", ""), "Starting from the <span>Lower \\$\\d{3},\\d{3}|<span class=\"numeric-amount\">\\$\\d{3},\\d{3}</span>|\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
			//U.log("MMM "+Util.matchAll(comHtml + comSec, "[\\s\\w\\W]{30}\\$800[\\s\\w\\W]{10}", 0));
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
//			comHtml=U.getNoHtml(comHtml);
			
			comHtml = comHtml.replace("up&nbsp;to", "up to").replaceAll("\\d,\\d{3} sq\\.? ft\\.?( resident)? clubhouse|\"description\":\"(.*?)\"}", "");
			String[] sqft = U.getSqareFeet(U.getNoHtml(comHtml).replaceAll("\\d,\\d+ sq. ft. clubhouse", ""),
					"from \\d,\\d{3}-\\d,\\d{3} sq. ft. |\\d,\\d{3} of living space|home designs up to \\d,\\d{3} square feet|\\d,\\d+ sq. ft|Sq Ft: \\d+-\\d+|\\d,\\d{3} to \\d,\\d{3} sq. ft.|\\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft|\\d,\\d{3}\\s*sq ft|Sq Ft:\\s*\\d,\\d{3}|homes up to \\d,\\d+ sq. ft|up to \\d,\\d{3} sq. ft|to \\d,\\d{3} square feet|"
					+ "from \\d,\\d{3}-\\d,\\d{3} sq ft",0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);
//			U.log(U.getSectionValue(comHtml, "<div class=home-details>", "<div class=\"otherCommunities featured-other-communities\">"));
			// ==============================================================Community
			// type============================================
//			comHtml = U.getNoHtml(comHtml);
			comHtml=comHtml.replaceAll("waterfront setting|waterfront single family homes in Boynton|Fairport Harbor Lakefront|lakefront-park\"|Duplex Townhomes Selling Fast |master-plan-community|Exciting Master-Planned|[e|E]longated|[i|I]rrigated|Old Country Club Road|Sleepy Hollow Country Club|www.golfsleepyhollow|117 Golf Course Drive|Hampton Lake community|lakefront opportunities|Preserve is a lakefront|lakeside lifestyle at Lakes of Cane", "");
			comSec = comSec.replace("Clubhouse\\\",\\\"Common", "").replace("\"Lounge\\\",\\\"Master Planned Community", "").replace("ActiveAdultLifestyle\\\":55,", "ActiveAdultLifestyle\": 55+ Community ,");
			String comType = ALLOW_BLANK;
			comHtml=comHtml.replace("art galleries and golf", " golf, ").replace("features lakefront homesites", "features lakefront community homesites");
			comType = U.getCommType(comHtml + comSec);
//			U.log(comSec);
//			U.log("MMMMMMMMMMMM"+Util.matchAll(comHtml+comSec , "[\\w\\s\\W]{30}waterfront[\\s\\w\\W]{50}", 0));

			// ==============================================================Property
			// type============================================

			String propType = ALLOW_BLANK;	
			comHtml=comHtml.replace("luxury new townhomes for sale", " luxury homes new townhomes for sale")
					.replace("traditional new-home", "traditional homes")
					.replaceAll("american farmhouse new homes|american farmhouse new homes aspire at sunnyside\" |Luxurious</span>\n\\s*<span class=featured-content-head>Interior|luxurious new single family homes", "luxury homes")
					.replaceAll("Loft\\s*\\w*", "Loft").replaceAll("for your multi-generational family|homeownership|HOA Fees|HOA_FEES|Homeowner Services|homeowner-services|-patio|HOA_FEES|HOA Fees:|featured-content-head>The Farmhouse", "");
			comHtml = comHtml.replace("multifamily-khov.ml3ds", "");
			propType = U.getPropType((comHtml + comSec+ homeData).replaceAll("HOA Fees|no HOA|No HOA|multifamily-khov|not have a Homeowners Association|HOA fees|HOA_FEES|for your multi-generational family|Enjoy low HOA fees|HOA Fees:|western-farmhouse|VILLAGO|[v|V]illago|rockford-loft|rockford loft j|HOA_FEES|HOA Fees|participation|RG-HOA|Cottageville|Apartment Buildings Rethinking|apartment-buildings|Why rent an apartment|farmhouse-new homes|abstract-traditional|cabin rentals|Clubhouse\",\"Common", ""));
			U.log("PROPERTY TYPE: "+propType);

			// ==============================================================Property
			// type============================================
			String dType = ALLOW_BLANK;
//			U.log(Util.match(homeData, ".*Stories.*"));
			
			comHtml = comHtml.replace("colonial-a-new", "").replaceAll("colonial-new-homes-at|Spanish Colonia|spanish colonial|colonial a new", "").replace("one- and two-story", " 1 Story  2 Story ").replaceAll(" Stories 2", "two- story")
					.replaceAll("<span class=\"numeric-amount\">\\s+(\\d)\\s+</span>\\s+<span class=\"list-style-text\">\\s+stories\\s+</span>", " $1 Story ")
					.replaceAll("<span class=\"list-style-text\">\\s+Stories\\s+</span>\\s+<span class=\"numeric-amount\">\\s+1\\s+</span>", "one Story")
					.replaceAll("<span class=\"list-style-text\">\\s+Stories\\s+</span>\\s+<span class=\"numeric-amount\">\\s+2\\s+</span>", "two Story")
					.replaceAll("<span class=\"list-style-text\">\\s+Stories\\s+</span>\\s+<span class=\"numeric-amount\">\\s+3\\s+</span>", "three Story");
					
			
			comSec = comSec.replaceAll("hancock III colonial new homes|colonial-new-homes", "");
			comHtml1=comHtml.replaceAll("colonial-new-homes-at|Spanish Colonia|spanish colonial|colonial a new", "");
			//dType = U.getNewdCommType((comHtml + comSec+homeData).replaceAll("\\s+Stories", " Stories").replaceAll("[R|r]ancho", ""));
//			U.writeMyText(comHtml + comSec+homeData+qData);
			dType=U.getdCommType((comHtml1 + comHtml + comSec+homeData+qData).replace("Rancho", "").replace("rancho", "").replace(" mccartney_ranch_", "").replaceAll(comName+"Wickenburg Ranch|-Spanish Colonial-|Arbor Ranch|-ranch-|Begonia Spanish Colonial|Ranch Circle|rose-a-spanish colonial|rom the Colonial period|Spanish-Colonial|spanish-colonial|SUNSET RANCH|bennettranch|ranch-elev|ladd-ranch|bennett-ranch|Bennett Ranch|BENNETT RANCH| Nelson Ranch Park is|wickenburg ranch|Wickenburg-Ranch|-rancho-|Rancho|wickenburg-ranch|asons at Wickenburg Ranch|[R|r]ancho|Ranch Circle", ""));
			U.log("DTYPE: "+dType);
//			U.log("MMMMMMMM "+Util.matchAll((comHtml1), "stories", 0));
		//	U.log("MMMMMMMM "+Util.matchAll((comHtml1), "[\\s\\w\\W]{100}stories[\\s\\w\\W]{150}", 0));

			// ==============================================================Property
			// Status============================================
			comSec = comSec.replace("</span> Home Designs Available", " Home Designs Available");
			comHtml = comHtml.replace("Now Available</span>\n" + 
					"<span class=featured-content-head>Premium Homesites", "").replaceAll("Quick Move|quick move", "")
					.replace("Final homes are now available", "Final homes now available");
			String remString = "\\d+ are now available|Quick Move-In Homes Now Available|Ready to move in homes are available and selling fast|homes are available and selling fast|Don't Wait! Limited Homesites Remain |Limited homesites remain! Don’t miss your|Homes Selling Quickly!|Townhomes are selling quickly|Move-in ready homes available.|communityStatus\":\"Coming Soon|Grand Opening of our beautiful new|Join Us for the Grand Opening|Image\\-Now\\-Open|image\\-now\\-open|\"Single Family Homes\",\"communityStatus\":\"Coming Soon\"|Low-maintenance Villa homes now available|on Quick move-in homes throughout Chicagoland|Purchase a quick move-in home from one of our|bold>Coming Soon<|Virtual Discovery Center\\s*Now Open|Now Open!</p>|Coming Soon\\s*Luxury|and [G|g]rand [O|o]pening [e|E]vents|Last model home available in a nearly sold out community|Coming Soon</span>|coming soon resort-style amenities.|spray-grounds coming soon|Unlimited opportunities for relaxation and recreation|Sports Courts Now Open|Clubhouse Now Open|Neighborhood Park\\s*Coming Summer 2018 |\\nComing soon!\\n|Coming soon, our newest|-coming-soon|coming soon resort-style|now available to residents|weight-bold>Now Open";
			
			comHtml = comHtml.replaceAll(remString, "")
					.replaceAll("Community to Host Grand Opening| Monroe to Host Clubhouse Grand Opening|featured-content-head>Grand", "").replace("weight-bold>Coming Soon in 2020</span>", "").replace("neighborhood park (coming Summer 2019)", "");
			
			String rmsec=U.getSectionValue(comHtml, "Neighborhood Park", "A beautiful");
			if(rmsec!=null)
				comHtml=comHtml.replace(rmsec, "");
			
			comSec=comSec.replaceAll("content-head>Coming Soon!|62634_Now Open_Deskto|We are now open|image-now-open|homes are available and selling fast|Image-Now-Open|last sections are selling fast|\"Availability\":\"Coming Soon\"", "");
			comHtml = comHtml.replace("final phase is selling FAST", "final phase selling FAST").replace("Phase II is now open", "Phase II now open")
					.replace("New Section, Opening Soon", "New Section Opening Soon").replace("Now Selling, New Section", "Now Selling New Section")
					.replaceAll("content-head>Coming Soon!|neighborhood park \\(coming Fall 2020\\) p|<span class=weight-bold>Opening Summer 2020</span>|Homes Now Available|Final homes are selling now|<span class=featued-content-subhead>Opening Summer 2020</span>|Final homes are now selling|We are now open|last chance for pre-construction pricing|[c|C]lose out another great day|Join us for the Grand Open|content-head>Model Grand|floorplans are now", "")
					.replaceAll("(Park </span>\\s+</h3>\\s+)?<p class=body-copy>\\s+<span class=weight-bold>Coming|Model, Now Open|In Homes are Selling|featured-content-head>Opening", "")
					.replace("new Quick Move-In Homes now available in Meadow Lakes", "")
					.replace("Homes are Selling Fast", "").replace("last sections are selling fast", "last sections selling fast");
			
//			U.writeMyText(comHtml);
			String[] banners = U.getValues(comHtml1, "<div class=\"promo-banner__title\">", "<");
			if(banners==null)
				banners=U.getValues(comHtml1, "<div class=promo-banner__title>", "<");
			String promoBanner = U.getSectionValue(comHtml, "<div class=promo-banner__sub-title>", "</div>")+U.getSectionValue(comHtml, "<div class=promo-banner__caption-title>", "<");
			promoBanner=promoBanner.trim();
			U.log("promoBanner: "+promoBanner);
			
			for(String banner : banners)
				promoBanner += " "+banner +" ";
			U.log("NWpromoBanner: "+promoBanner);
			if(promoBanner!=null)
				promoBanner = promoBanner.replace("Phase II is selling quickly", "Phase II selling quickly").replace("Now Selling, New Section", "Now Selling New Section")
						.replace("Limited Quick Move-In Homes Available","")
				.replace("Quick Move-In Specials Available", "Quick Move-In Homes");
			String remNear = U.getSectionValue(comHtml, "<div class=\"otherCommunities featured-other-communities\">", "</ul>");
			if(remNear!=null)
				comHtml = comHtml.replace(remNear, "").replace("Phase II is selling quickly", "");
			comHtml = comHtml.replaceAll("\n\\s*</span>\n\\s*<span class=\"featured-content-head\">\n\\s*", " ");
			comHtml=comHtml.replace("New Phase!\n" + 
					"</div>\n" + 
					"<div class=promo-banner__sub-title>\n" + 
					"Coming Soon", "New Phase Coming Soon");
			comHtml=comHtml.replace("oversized lots are selling fast", "oversized lots selling fast")
					.replace("before Tejas Trails is sold out", "")
					.replace("Homes now available in Meadow Lakes","")
					.replace("clubhouse opening in early 2022", "")
					.replaceAll("See why homes are selling fast at Hampton Run", "");
			//U.log("SSSSS"+Util.matchAll(comHtml, "[\\w\\W\\s]{30}Homes Now Available[\\w\\W\\s]{30}",0));
			String propertyStatus = ALLOW_BLANK; //Now Available
			propertyStatus = U.getNewPropStatus((comSec + comHtml+promoBanner).replace("Phase II is selling quickly", "").replace("Limited 65' Homesites Remain", "limited homesites remain")
					.replaceAll("Amenities Coming Soon!|<span class=\"weight-bold\">\n\\s*Coming Soon!\n\\s*</span>|Amenities Coming Soon|Model Home Coming Soon|model home coming soon|\"communityStatus\":\".*\"|Family Homes</p>\n\\s*<p class=two>\\s*<span class=weight-bold>\\s*Coming Soon|model home coming soon|Model Home\\s*</span>\n\\s*<span class=featured-content-head>\\s*Coming Soon|Coming Summer 2021 our stunning|promo-banner__caption-blurb>\n\\s*Coming|Last opportunity to own|model opening this summer|Don't miss your final opportunity |Move-In Ready|promo-banner__caption-sub-title>\n\\s*Now Selling!|Model Home</span>\n\\s*<span class=featured-content-head>Coming Soon!</span>|model home coming soon|Tours Now Available|Model Grand Opening Coming Soon!|Clubhouse Grand Opening", "")
					.replace("Homes are Selling Fast", ""))
					
					.replaceAll("Limited Quick Move-In Homes Available","")
					.replace("new Quick Move-In Homes now available in Meadow Lakes","")
					.replace("New Phase!\\s*\n\\s*</div>\n\\s*<div class=promo-banner__sub-title>\n\\s*Coming Soon", "New Phase Coming Soon");
			
			
			
			U.log("propertyStatus: "+propertyStatus);
//MATCH PRINT			
//			U.log("MMMMMMMM "+Util.matchAll((comSec ),"[\\s\\w\\W]{100}Homesites Selling Quickly[\\s\\w\\W]{100}", 0));
//			U.log("MMMMMMMM "+Util.matchAll(( comHtml),"[\\s\\w\\W]{100}Homesites Selling Quickly[\\s\\w\\W]{100}", 0));
//			U.log("MMMMMMMM "+Util.matchAll((promoBanner),"[\\s\\w\\W]{100}Homesites Selling Quickly[\\s\\w\\W]{100}", 0));

			U.log(qData.equals(ALLOW_BLANK));
			if((comSec.contains("HasQuickMoveInHomes\\\":true") && !propertyStatus.contains("Quick")) && qData!=null && !qData.equals(ALLOW_BLANK)){
				if(propertyStatus.length()<4)propertyStatus = "Quick Move In Homes";
				else propertyStatus = propertyStatus +", Quick Move In Homes";
				
			}
			
			propertyStatus=propertyStatus.replace("Quick Move-in Homes","Quick Move In Homes");
			if(propertyStatus.contains("New Phase Now Selling")&&propertyStatus.contains("Now Selling")) {
				propertyStatus=propertyStatus.replaceAll(", Now Selling|Now Selling, ","");
			}
			
			if (comUrl.contains("https://www.khov.com/find-new-homes/california/lake-elsinore/92530/k-hovnanian-homes/solstice-at-summerly"))
				propertyStatus=propertyStatus.replace("Coming Soon,", "");
			if (comUrl.contains("https://www.khov.com/find-new-homes/california/lake-elsinore/92530/k-hovnanian-homes/solstice-at-summerly"))
				propertyStatus=propertyStatus.replace("Coming Soon,", "");
		
			if (comUrl.contains("https://www.khov.com/find-new-homes/texas/houston/77051/k-hovnanian-homes/kirby-landing"))
				propertyStatus=propertyStatus.replace("Grand Opening,", "");
			if (comUrl.contains("https://www.khov.com/find-new-homes/florida/boca-raton/33428/k-hovnanian-homes/the-enclave-at-boca-dunes") || comUrl.contains("/k-hovnanian-homes/north-pointe-estates"))
				propertyStatus=propertyStatus.replace("Coming Soon,", "");
/*			if (comUrl.contains("https://www.khov.com/find-new-homes/delaware/lewes/19958/k-hovnanian-homes/red-mill-pond"))
				propertyStatus=propertyStatus.replace("New Homesites Released, ", "");
*/			if (comUrl.contains("/k-hovnanian-homes/the-estates-at-blackstone"))
				propertyStatus=propertyStatus.replace("Homes Now Available", "Final Homes Now Available");
			if (comUrl.contains("https://www.khov.com/find-new-homes/illinois/libertyville/60048/k-hovnanian-homes/parkside-at-libertyville"))
				propertyStatus=propertyStatus.replace(", A Few Homes Remaining", "");
			if (comUrl.contains("https://www.khov.com/find-new-homes/virginia/fredericksburg/22407/k-hovnanian-homes/estates-of-chancellorsville"))
				propertyStatus=propertyStatus.replace(", Only 2 Homesites Remain", "");
			if(propertyStatus.equals("Now Open, New Phase Now Open"))propertyStatus=propertyStatus.replace("Now Open, New Phase Now Open", "New Phase Now Open");
			
if(comUrl.contains("https://www.khov.com/find-new-homes/texas/crosby/77532/k-hovnanian-homes/crosby-park-village"))propertyStatus="Quick Move In Homes";
//if(comUrl.contains("https://www.khov.com/find-new-homes/texas/mont-belvieu/77523/k-hovnanian-homes/lakes-of-champion's-estates"))propertyStatus+=", Lake Homesites Available";
			String notes = U.getnote((comHtml+comSec).replaceAll("\"communityStatus\":\"Now Pre-Selling\"|/presales/", ""));
			add[0]=add[0].replace("203 Harvest Blossom Road", "203 Harvest Blossom Round");
//			image status
//			if(comUrl.contains("https://www.khov.com/find-new-homes/california/fresno/93727/k-hovnanian-homes/inspirado"))propertyStatus=propertyStatus+", Opening Fall 2019";
			//From Img
//			if(comUrl.contains("https://www.khov.com/find-new-homes/california/lodi/95242/k-hovnanian-homes/lavaux-at-vineyard-terrace") ||
//					comUrl.contains("https://www.khov.com/find-new-homes/california/lodi/95242/k-hovnanian-homes/encantada-at-vineyard-terrace")
//					){
//				propertyStatus=propertyStatus+", Opening Winter 2020";
//			}
			//From Image
//			if(comUrl.contains("https://www.khov.com/find-new-homes/florida/jupiter/33478/k-hovnanian-homes/reynolds-ranch")){
//				if(propertyStatus == ALLOW_BLANK)propertyStatus = "3 Homes Remaining";
//				else if(propertyStatus != ALLOW_BLANK && !propertyStatus.contains("3 Homes Remaining"))propertyStatus += ", 3 Homes Remaining";
//			}
			if(comUrl.contains("https://www.khov.com/find-new-homes/virginia/nokesville/20181/k-hovnanian-homes/alexander-lakes")) propertyStatus = propertyStatus.replace("Final Opportunities", "Sold Out");
			propertyStatus = propertyStatus.replace("A Few Homes Remaining, Only A Few Homes Remain", "Only A Few Homes Remain")
					.replace("Grand Opening Soon, Opening Soon", "Grand Opening Soon");
//			if(comUrl.contains("https://www.khov.com/find-new-homes/south-carolina/bluffton/29909/four-seasons/k-hovnanians-four-seasons-at-carolina-oaks"))
//				propertyStatus = propertyStatus.replace("New Phase Opening Soon", "New Phase Coming Early 2022");
			
			if(comUrl.contains("https://www.khov.com/find-new-homes/texas/mont-belvieu/77523/k-hovnanian-homes/south-lake-estate")|| 
					comUrl.contains("https://www.khov.com/find-new-homes/texas/league-city/77573/k-hovnanian-homes/westwood"))
				propertyStatus = propertyStatus.replace("Coming Soon,", "");
			
			//if(propertyStatus.contains("New Phase Opening Soon") && propertyStatus.contains("New Phase Coming Soon"))
				//propertyStatus = propertyStatus.replace("New Phase Coming Soon", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
					
			
			if(propType.contains("Townhouse") && propType.contains("Townhome")) {
			propType = propType.replace("Townhouse, Townhome", "Townhome");
			propType = propType.replaceAll(", Townhouse|Townhouse,", "");
			}
//			if(comUrl.contains("https://www.khov.com/find-new-homes/new-jersey/west-new-york/07093/k-hovnanian-homes/nine-on-the-hudson")) {
//				minPrice="$1,000,000";
//			}
			propertyStatus = propertyStatus.replace("Now Open, 70 Homes Sold, New Phase Now Open", "70 Homes Sold, New Phase Now Open")
					//.replace("Coming Soon, New Phase Opening Soon", "New Phase Opening Soon")
					.replace("Coming Soon, Opening Soon", "Coming Soon")
					.replace("New Phase Coming Spring 2022, New Phase Coming Early 2022", "New Phase Coming Spring 2022");
			///k-hovnanian-homes/hilltop-at-cedar-grove
			
			if(comUrl.contains("https://www.khov.com/find-new-homes/ohio/lorain/44053/k-hovnanian-homes/cooper's-landing"))add=U.getAddressGoogleApi(latlong);
			
			if(comUrl.contains("https://www.khov.com/find-new-homes/california/roseville/95747/k-hovnanian-homes/firefly-at-winding-creek"))minPrice="$600,000";
//			if(comUrl.contains("https://www.khov.com/find-new-homes/delaware/lewes/19958/k-hovnanian-homes/oyster-cove"))maxPrice="$642,409";
			if(comUrl.contains("/arizona/maricopa/85138/k-hovnanian-homes/the-lakes-at-rancho-el-dorado"))dType=ALLOW_BLANK;
		    if(comUrl.contains("https://www.khov.com/find-new-homes/ohio/green/44685/k-hovnanian-homes/forest-lakes"))propertyStatus="New Phase Coming Soon, New Phase Opening Soon";
			
			//remove bracketdata from streer
			add[0] = add[0].replaceAll("\\(.*\\)", "").replace("West of Intersection of ", "");
			
			String noOfUnits=ALLOW_BLANK;
			String interactiveSiteUrlSec=U.getSectionValue(comHtml1, "id=interactive-site-plan","</iframe>");
			if(interactiveSiteUrlSec!=null) {
			String  interactiveSiteUrl=U.getSectionValue(interactiveSiteUrlSec, "data-src=\"","\"");
			U.log("Interactive Site Url:: "+interactiveSiteUrl);
		//	String siteUrlHtml=getMyHTML(interactiveSiteUrl);
	       
			String siteUrlHtml=U.getHtml(interactiveSiteUrl, driver);
			
			String siteMapxUrl="https://khovsecure.ml3ds-cloud.com/resources/data/CommunityData/khovsecure.x.x?d=";
			
		     if(!interactiveSiteUrl.contains("#/lotmap/"));{
				 driver.get(interactiveSiteUrl);
		    	 interactiveSiteUrl=driver.getCurrentUrl();	
		        }
		     U.log("Interactive Site Url:: "+interactiveSiteUrl);
			String MyxMapHtml=getMyHTML(siteMapxUrl+System.currentTimeMillis(),interactiveSiteUrl);
			
			
			String lots[]=U.getValues(MyxMapHtml, "LotId", ",");
			int lotCount=lots.length;
			 noOfUnits=Integer.toString(lotCount);
			}
			//if(propertyStatus.contains("Quick Move-in Homes")) propertyStatus = propertyStatus.replace("Quick Move-in Homes", "Quick Move-in"); 
			U.log("noOfUnits== "+noOfUnits);
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus.replace("Ii", "II").replace("Future Opportunities Coming Soon, Coming Soon", "Future Opportunities Coming Soon"));
			data.addNotes(notes.replace("Now Pre-selling, Pre-sale", "Now Pre-selling"));
			data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
			
		}
		j++;
	//	}catch (Exception e) {}
	}
	
	private String getQData(String html) throws Exception {
		String qData="";
		String[] allHomeSec=U.getValues(html, "button white-color see-full-details-button qmi\" href=\"","\"");
		U.log("::::::::::::::Quick Data::::::::::::::::::"+allHomeSec.length);
		for (String url : allHomeSec) {
			if(!url.contains("http")){
				U.log("qUrl ::"+Builder_Url+url);
				qData=qData+U.getPageSource(Builder_Url+url);
			}
		}
/*		String vals[] = U.getValues(qData, "<div id=mapContainer>", "<div class=info-modal>");
		for(String str : vals) qData = qData.replace(str, "");
		vals = U.getValues(qData, "<div id=home-type", "<div id=community-lifestyle");
		for(String str : vals) qData = qData.replace(str, "");
		return qData;
*/
		if(allHomeSec.length==0)qData=ALLOW_BLANK;
		return U.getNoHtml(qData);
	}

	private String getHomeData(String html) throws IOException {
		String homeData="";
		String[] allHomeSec=U.getValues(html, "button white-color see-full-details-button\" href=\"","\"");
		U.log("::::::::::::::Home Data::::::::::::::::::"+allHomeSec.length);
		for (String url : allHomeSec) {
			if(!url.contains("http")){
			//	U.log("homeUrl ::"+Builder_Url+url+"\n"+U.getCache(Builder_Url+url));
				homeData=homeData+ U.getSectionValue(U.getPageSource(Builder_Url+url), "home-design-title>", "<div class=social-container>");
			}
		}
		return U.getNoHtml(homeData);
	}
	//Format million price
	public static String formatMillionPrices(String comSec){
		String floorMatch = "";
				if(comSec.contains("1.")){
					Matcher millionPrice = Pattern.compile("\\$\\d\\.\\d millions",Pattern.CASE_INSENSITIVE).matcher(comSec);
					while(millionPrice.find()){
						floorMatch = millionPrice.group().replace(" m", "00,000").replace(".", ",");  //$1.3 M
						comSec	 = comSec.replace(millionPrice.group(), floorMatch);
					}
				}
				else{
					Matcher millionPrice = Pattern.compile("\\$\\d millions",Pattern.CASE_INSENSITIVE).matcher(comSec);
					while(millionPrice.find()){
						
					floorMatch = millionPrice.group().replace(" m", ",000,000");  //$1 M
					comSec	 = comSec.replace(millionPrice.group(), floorMatch);
					}
				}
			return comSec;
		}
//}

///MMMMMMMMMMMMMMMMMMMMMMMmm
public static String getMyHTML(String path,String myParentUrl) throws IOException {

	path = path.replaceAll(" ", "%20");
	// U.log(" .............."+path);
	// Thread.sleep(4000);
	String fileName = U.getCache(path);
	File cacheFile = new File(fileName);
	if (cacheFile.exists())
		return FileUtil.readAllText(fileName);

	URL url = new URL(path);
	//U.log(url);
	String html = null;

	// chk responce code

//	int respCode = CheckUrlForHTML(path);
//	 U.log("respCode=" + respCode);
//	 if (respCode == 200) {

	// Proxy proxy = new Proxy(Proxy.Type.HTTP, new    //"157.90.199.133", 1080)
	// InetSocketAddress("107.151.136.218",80 ));   //"181.215.130.32", 8080)  //"134.209.69.46", 8080 //"157.90.199.129", 1080)
	Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
			"47.88.57.22",7328));//"208.80.28.208", 8080));
	final URLConnection urlConnection = url.openConnection();
	// Mimic browser
	try {
//		urlConnection
//				.addRequestProperty("User-Agent",
//						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
	//	urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
		//urlConnection.addRequestProperty("Accept-Language","en-GB,en-US;q=0.9,en;q=0.8");
		//urlConnection.addRequestProperty("Cache-Control", "max-age=0");
	//	urlConnection.addRequestProperty("Connection", "keep-alive");
		//MI
		urlConnection.addRequestProperty("authority", "khovsecure.ml3ds-cloud.com");
	//	urlConnection.addRequestProperty("path", "/resources/data/CommunityData/khovsecure.x.x?d="+System.currentTimeMillis());
		urlConnection.addRequestProperty("content-type","application/json; charset=UTF-8");
		urlConnection.addRequestProperty("scheme", "https");
		urlConnection.addRequestProperty("accept", "application/json; charset=UTF-8");
		urlConnection.addRequestProperty("accept-encoding", "gzip, deflate, br");
		urlConnection.addRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
		//urlConnection.addRequestProperty("cache-control", "max-age=0");
		urlConnection.addRequestProperty("cookie", "_ga=GA1.2.1495145230.1647278066; _ga=GA1.3.1495145230.1647278066; _gid=GA1.2.466674436.1649935232; _gid=GA1.3.466674436.1649935232");
	//	urlConnection.addRequestProperty("upgrade-insecure-requests", "1");
		urlConnection.addRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36");
	//	urlConnection.addRequestProperty("path", "/resources/data/CommunityData/khovsecure.x.x?d="+System.currentTimeMillis());
	///	urlConnection.addRequestProperty("fullurl", "https://khovsecure.ml3ds-cloud.com/#/lotmap/68203");
		urlConnection.addRequestProperty("fullurl", myParentUrl);
		urlConnection.addRequestProperty("referer", "https://khovsecure.ml3ds-cloud.com/");
		// U.log("getlink");
		final InputStream inputStream = urlConnection.getInputStream();

		html = IOUtils.toString(inputStream);
//	    U.log(html);

		// final String html = toString(inputStream);
		inputStream.close();
		if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, html);

		return html;
	} catch (Exception e) {
		U.log("gethtml expection: "+e);

	}
	return html;
	/*
	 * } else { return null; }
	 */

}


public static String getMyHTML2(String path,String myParentUrl) throws IOException {

	path = path.replaceAll(" ", "%20");
	// U.log(" .............."+path);
	// Thread.sleep(4000);
	String fileName = U.getCache(path);
	File cacheFile = new File(fileName);
	if (cacheFile.exists())
		return FileUtil.readAllText(fileName);

	URL url = new URL(path);
	//U.log(url);
	String html = null;

	// chk responce code

//	int respCode = CheckUrlForHTML(path);
//	 U.log("respCode=" + respCode);
//	 if (respCode == 200) {

	// Proxy proxy = new Proxy(Proxy.Type.HTTP, new    //"157.90.199.133", 1080)
	// InetSocketAddress("107.151.136.218",80 ));   //"181.215.130.32", 8080)  //"134.209.69.46", 8080 //"157.90.199.129", 1080)
	Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
			"47.88.57.22",7328));//"208.80.28.208", 8080));
	final URLConnection urlConnection = url.openConnection();
	// Mimic browser
	try {
//		urlConnection
//				.addRequestProperty("User-Agent",
//						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
	//	urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
		//urlConnection.addRequestProperty("Accept-Language","en-GB,en-US;q=0.9,en;q=0.8");
		//urlConnection.addRequestProperty("Cache-Control", "max-age=0");
	//	urlConnection.addRequestProperty("Connection", "keep-alive");
		//MI
		urlConnection.addRequestProperty("authority", "khovsecure.ml3ds-cloud.com");
	//	urlConnection.addRequestProperty("path", "/resources/data/CommunityData/khovsecure.x.x?d="+System.currentTimeMillis());
		urlConnection.addRequestProperty("content-type","application/json; charset=UTF-8");
		urlConnection.addRequestProperty("scheme", "https");
		urlConnection.addRequestProperty("accept", "application/json; charset=UTF-8");
		urlConnection.addRequestProperty("accept-encoding", "gzip, deflate, br");
		urlConnection.addRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
		//urlConnection.addRequestProperty("cache-control", "max-age=0");
		urlConnection.addRequestProperty("cookie", "_ga=GA1.2.1495145230.1647278066; _ga=GA1.3.1495145230.1647278066; _gid=GA1.2.466674436.1649935232; _gid=GA1.3.466674436.1649935232");
	//	urlConnection.addRequestProperty("upgrade-insecure-requests", "1");
		urlConnection.addRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36");
	//	urlConnection.addRequestProperty("path", "/resources/data/CommunityData/khovsecure.x.x?d="+System.currentTimeMillis());
	///	urlConnection.addRequestProperty("fullurl", "https://khovsecure.ml3ds-cloud.com/#/lotmap/68203");
		urlConnection.addRequestProperty("fullurl", myParentUrl);
		urlConnection.addRequestProperty("referer", "https://khovsecure.ml3ds-cloud.com/");
		// U.log("getlink");
		final InputStream inputStream = urlConnection.getInputStream();

		html = IOUtils.toString(inputStream);
//	    U.log(html);

		// final String html = toString(inputStream);
		inputStream.close();
		if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, html);

		return html;
	} catch (Exception e) {
		U.log("gethtml expection: "+e);

	}
	return html;
	/*
	 * } else { return null; }
	 */

}
}
