/**
 * @author Rakesh Chaudhari
 * @date 21 July 2015
 * 
 */
package com.shatam.b_021_040;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang.StringEscapeUtils;
import org.junit.runners.AllTests;
import org.omg.CosNaming.NamingContextPackage.NotEmpty;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPardeeHomes extends AbstractScrapper {

	ArrayList<String> comunities = new ArrayList<String>();
	int i = 0;
	static int j = 0;
	public int inr = 0;
	public int count = 0;
	CommunityLogger LOGGER;
	static HashMap<String, String> cityState = new HashMap<>();
	
	// Connection con;

	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new ExtractPardeeHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"TRI Pointe Group - Pardee Homes.csv", a
				.data().printAll());
	}

	public ExtractPardeeHomes() throws Exception {

		super("TRI Pointe Group - Pardee Homes", "https://www.pardeehomes.com");
		LOGGER = new CommunityLogger("TRI Pointe Group - Pardee Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
		cityState.put("San Diego", "CA");
		// Your code here
		String baseUrl = "https://www.pardeehomes.com";
		String html = U.getHTML(baseUrl);
		
		String regionUrlSection = U.getSectionValue(html, "Find Your Home", "</ul>");
		String[] regionUrls = U.getValues(regionUrlSection, "<a href=\"", "\"");
		for(String regionUrl : regionUrls){
			U.log("RegUrl ::"+regionUrl);
			String regHtml = U.getHTML(regionUrl);
			
			String comSection = U.getSectionValue(regHtml, "var cmPositions =", "cmPositions =");
			comSection = StringEscapeUtils.unescapeJava(comSection);
			comSection = comSection.replace("\\/", "/");
//			U.log(comSection);

			String comSections[] = U.getValues(comSection, "{", "}");
			U.log(comSections.length);
			for(String comSec : comSections){
				
				String comUrl = U.getSectionValue(comSec, "card_Url\":\"", "\"");
				findSubCommunities(comUrl, comSec);
			}
/*			String comSections[] = U.getValues(regHtml, "<div class=\"card-main-div\">", " class=\"card-btn\">");
			U.log(comSections.length);
			for(String comSec : comSections){
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
				findSubCommunities(comUrl, comSec);
			}
*/		}

/*		String[] values = U.getValues(html,"<div class=\"card card--neighborhood\"><div class=\"card__frame\">", "Learn");

		int totalComm = values.length;
		U.log("Total Cunt: " + totalComm);

		for (String comSec : values) {
			String url = U.getSectionValue(comSec, "<div class=\"card__image\"><a href=\"", "\"");
			url = url.replace("pardeehomes.com/VistaSantaFe/", "pardeehomes.com/neighborhood/VistaSantaFe/");
			String name = U.getSectionValue(comSec, "title=\"", "\"");
//			if(comSec.contains("escala"))U.log(comSec);
			String latLngSec = U.getSectionValue(html, "\"title\":\""+name, "}");
//			try {
//				addDetails(url, name,comSec,latLngSec);
//			} catch (Exception e) {
//			}
			
			// break;
		}*/

		LOGGER.DisposeLogger();
	

	}
	private void findSubCommunities(String mainComUrl, String comSec) throws Exception{
		String html = U.getHTML(mainComUrl);
		
		String neighborhoodSection = U.getSectionValue(html, " id=\"neighborhoods\">", "<script");
		if(neighborhoodSection != null){
			String[] subCommSections = U.getValues(neighborhoodSection, "<div class=\"card-main-div\">", " class=\"card-btn\">");
			for(String subCommSec : subCommSections){
//				U.log(subCommSec);
				String comUrl = U.getSectionValue(subCommSec, "<a href=\"", "\"");
				String comName = U.getSectionValue(subCommSec, "<h4>", "</h4>");
				findCommunityDetails(comUrl, comName, comSec+" $shatam "+subCommSec);
			}
		}else{
			String comName = U.getSectionValue(comSec, "<h3>", "</h3>");
			findCommunityDetails(mainComUrl, comName, comSec);
		}
	}
	
	// TODO: Extract Communities Details

	private void findCommunityDetails(String comUrl, String comName, String comSec) throws Exception{
//	if( i == 49)
	{
		//https://www.pardeehomes.com/san-diego/the-highlands/

//		if(!comUrl.contains("https://www.pardeehomes.com/inland-empire/beacon/"))return;
		
		U.log("Comm. Count =="+i);
		U.log(comUrl);
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "*******Repeated");
			return;
		}
		if (comUrl.contains("https://www.pardeehomes.com/inland-empire/tamarack/")) {//||comUrl.contains("https://www.pardeehomes.com/las-vegas/capri/")
			LOGGER.AddCommunityUrl(comUrl + "*******Returned");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html = U.getHTML(comUrl);
		html = U.removeComments(html);
		
		if(comName == null)
			comName = U.getSectionValue(comSec, "title\":\"", "\"");
		U.log(comSec);
		
		
		//=========== Address ====================
		String[] add = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		String geo = "False";
		String addSec = U.getSectionValue(html, "<div class=\"neigh_address\">", "<a");
		if(addSec != null){
			addSec = addSec.replaceAll("<.*?>", "").replace(" Santee, CA", ", Santee, CA").replace(" Santa Clarita, CA", ", Santa Clarita, CA").replaceAll(" Las Vegas , NV| Las Vegas, NV", ", Las Vegas, NV").replace(" Henderson, NV", ", Henderson, NV").replace(" Menifee, CA", ", Menifee, CA").replace(" Winchester, CA", ", Winchester, CA").replace(" Elsinore, CA", ", Elsinore, CA").replace(" Murrieta, CA", ", Murrieta, CA").replace(" Beaumont, CA", ", Beaumont, CA")
					.replace(" Banning, CA ", ", Banning, CA ").replaceAll("210 Abbey Hill Street\\s+210 Abbey Hill Street", "210 Abbey Hill Street").trim()
					.replace("Start Your Tour at The Carmel New Home Gallery", "");
			U.log(addSec);
			String [] vals = addSec.split(",");
			if(vals.length == 2){
				add[3] = Util.match(vals[1], "\\d{5}");
				add[2] = vals[1].replace(add[3], "").trim();
				
				add[1] = U.getSectionValue(html, "addressLocality\": \"", "\"");
				add[0] = vals[0].replace(add[1], "").trim();
			}else if (vals.length==3) {
				add=U.getAddress(addSec);
			}
		}
		U.log("Add ::"+Arrays.toString(add));
		
		//=========== Lat-lng ====================
		String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
		latLng[0] = U.getSectionValue(comSec, "\"lat\":\"", "\"");
		latLng[1] = U.getSectionValue(comSec, "\"lng\":\"", "\"");
		if((latLng[0]==null || latLng[0].length()<2) && html.contains("https://www.google.com/maps/")) {
			String latsec=U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");
			String[] newlatlng =U.getSectionValue(latsec, "/@", ",17z").split(",");
			latLng=newlatlng;
		}
		U.log("Latlng :"+Arrays.toString(latLng));
		if(latLng[0] != null && latLng[0].isEmpty()) latLng[0] = latLng[1] = ALLOW_BLANK;
		
		if(add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK){
			if(latLng[0] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				if(add == null)
					add = U.getAddressHereApi(latLng);
				
				geo = "True";
			}
			U.log("Add ::"+Arrays.toString(add));
		}
		//======= Move-In-Ready Homes ================
		String navSection = U.getSectionValue(html, "<div class=\"mobileMenuInner\">", "</ul>");
		String navUrls[] = U.getValues(navSection, "<a href=\"", "\"");
		int moveCount=0;
		String moveInHtml = ALLOW_BLANK;
		for(String navUrl : navUrls){
			U.log("jjjjj"+navUrl);
			if(navUrl.contains("move-in-ready")){
				moveCount++;
				U.log("navUrl :"+navUrl);
				moveInHtml = U.getHTML(navUrl);
			}
		}
				
		
		//======= Square feet ======
		String minSqf = ALLOW_BLANK;
		String maxSqf = ALLOW_BLANK;
		String[] subSec= {ALLOW_BLANK,ALLOW_BLANK};
		if(comSec.contains("shatam")) {
		subSec=comSec.split("shatam");
		
//		U.log("fffff"+subSec[1]);
		comSec=subSec[1];
		}
		
		String[] sqFt = U.getSqareFeet(comSec+html + moveInHtml,
				">\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft| \\d,\\d{3} to \\d,\\d{3} sq. ft|(s|S)qft\":\"\\d,\\d+ - \\d,\\d+\"|\\d,\\d{3} Sq.&nbspFt.|\\d{1},\\d{3} - \\d{1},\\d{3}  sq ft|\\d{1},\\d{3}\\s*–\\s*\\d{1},\\d{3} square feet|Approximately \\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} sq. ft. – \\d{1},\\d{3} sq. ft. |\\d{1},\\d{3}-\\d{1},\\d{3} square feet|\\d,\\d{3} sq. ft. � \\d,\\d{3} sq. ft|\\d{1},\\d{3}-\\d{1},\\d{3} sq. ft.|\\d,\\d+ to almost \\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ sq.ft|\\d,\\d+- to \\d,\\d+-square feet|\\d,\\d+ � \\d,\\d+ sq. ft.|\\d+,\\d+ – \\d+,\\d+ square feet|\\d+,\\d+ to \\d+,\\d+ square feet|\\d{1},\\d{3} sq ft",
				0);

		minSqf = (sqFt[0] != null) ? sqFt[0] : ALLOW_BLANK;
		maxSqf = (sqFt[1] != null) ? sqFt[1] : ALLOW_BLANK;
		U.log("minSqft:: " + minSqf + " maxSqft:: " + maxSqf);
		
		//======= Price ==================
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		
		html = html.replaceAll("0s|0Ks", "0,000").replace("<span class=\"price-case\"> 700000</span>", "low $700,000")
				.replace(" $1.5 Millions", " $1,500,000").replace(" $1.6 Millions", " $1,600,000")
				.replace("$2 Millions", "$2,000,000").replace("$1.8 Millions", "$1,800,000")
				.replace("$1.9 Millions", " $1,900,000").replaceAll("from the\\s{2,}\\$", "from the \\$")
				.replaceAll(" \\$(\\d) Millions", " \\$$1,000,000");

		html=html.replace("Priced from the High $700s", "Priced from the High $700,000").replace("Priced from the $1.4 Millions", "Priced from the $1,400,000").replace("from the $1.6 millions to the low $2 millions", "from the $1,600,000 to the low $2,000,000").replace("from the $1.8 millions to the $2.3 millions", "from the $1,800,000 to the $2,300,000").replace("from the $1.9 millions to the $2.5 millions.", "from the $1,900,000 to the $2,500,000");
		html=html.replace("$2.0 millions", "Priced from the $2,000,000");//.replace(" millions", ",000,000");
		html = U.formatMillionPrices(html);
		
		String[] price = U
				.getPrices(html + moveInHtml,
						"High \\$\\d{3},\\d{3}<|Priced from the (High|mid) \\$\\d{3},\\d{3}|Priced from( the)?( mid)? \\$\\d,\\d{3},\\d{3}|from the \\$\\d,\\d{3},\\d{3} to the low \\$\\d,\\d{3},\\d{3}|<p class=\"price\">\\$\\d{3},\\d{3}</p>|\"price-case\">\\s?\\$(\\d,)?\\d{3},\\d{3}|Priced at \\$\\d,\\d{3},\\d{3}|from the \\$\\d,\\d{3},\\d{3} to the \\$\\d,\\d{3},\\d{3}|the low \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|>Priced at \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Priced at \\$\\d{3},\\d{3}|high-\\$\\d{3},\\d{3}",
						0);

		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		//============= Floor Plans===============
		String allFloorHtml = ALLOW_BLANK;
		String planUrlSections[] = U.getValues(html, "<div class=\"card-main-div\">", "</div>");
		for(String planUrlSec :planUrlSections){
			String planUrl = U.getSectionValue(planUrlSec, "<a href=\"", "\"");
			U.log("planUrl ::"+planUrl);
			String planHtml = U.getHTML(planUrl);
			if(planHtml!=null) {
				allFloorHtml += U.getSectionValue(planHtml, "class=\"printdata\">", "id=\"new_videoGallery\"");
			}
		}
		//========== Move- In Ready Homes =============
		String allMoveInReadyHtml = ALLOW_BLANK;
		String moveInReadyUrlSections[] = U.getValues(moveInHtml, "<div class=\"card-main-div\">", "</div>");
		for(String moveInReadyUrlSec :moveInReadyUrlSections){
			String moveInReadyUrl = U.getSectionValue(moveInReadyUrlSec, "<a href=\"", "\"");
			U.log("moveInUrl ::"+moveInReadyUrl);
			String moveInReadHtml = U.getHTML(moveInReadyUrl);
			if(moveInReadHtml == null)moveInReadHtml = ALLOW_BLANK;
			allMoveInReadyHtml += U.getSectionValue(moveInReadHtml, "class=\"printdata\">", "id=\"new_videoGallery\"");
			
		}
		
		//========== Detail Section ==============
		String section = U.getSectionValue(html, "id=\"plans-pricing\">", "<div class=\"floorPlan_new");
		section=section==null?U.getSectionValue(html, "id=\"plans-pricing\">", "id=\"stayinformed\""):section;
//		U.log(section);
		//========== Community Type ===========
//		U.log(comSec);
		String comType = U.getCommunityType((section+comSec+subSec[0]).replaceAll("gated enclave", ""));
		U.log("::::::::::::::"+comType);
		if(html.contains("Inland Empire</a> > <a href=\"https://www.pardeehomes.com/community/altis-active-adult/\">Altis</a>")) {
			//comType= comType+", Active Adult";
			minPrice ="$300,000";
		}
		//============ Property Type ==============
		
		
		
		String propertyType = U.getPropType((section + allFloorHtml+ allMoveInReadyHtml).replace("NOW OPEN","").replace("Western Farmhouse set against", " Farmhouse architectural set against")
				.replaceAll("insurance premiums, homeowner’s association dues, or|Traditional Fireplace|traditional fireplace|Farmhouse, Contemporary, Spanish and Modern elevations|Coastal North|in Coastal|coastal|Assumptions. You are purchasing a single family home and primary residence.|Marketplace Now Open", ""));
//		U.log(Util.matchAll(allMoveInReadyHtml, ".*homeowner’s association.*", 0));
		//=========== Derived Property Type ============
		String dType = U.getdCommType(section + allFloorHtml.replaceAll("ounge and powder complete the first level", "")+ allMoveInReadyHtml); 

		//=========== Community Status ==============
		section=section.replace("Next Phase Release Coming January 2021", "Next Phase Coming January 2021")
				.replaceAll("Sandalwood Coming Soon|Altis Grand Opening Highlights|Alisio Grand Opening|grand opening festivities|Skyline, coming soon|fitness center coming soon.|ign up on the Corterra Final Opportunity Interest List |alt=\"Braeburn Grand Opening\"|join our Final Opportunity Interest List|title=\"Braeburn Grand Opening\"|\"video_slider_title\">Braeburn Grand Opening</div>|Models Opening Soon", "");
		U.log("total count"+navUrls.length);
		if(moveInReadyUrlSections.length>0) {
			section=section+" Move-In Ready Homes ";
		}
		section = section.replace("Coming in 2020", "Coming 2020")
				.replaceAll("Check out our move-in ready homes|chances to get", "");
		String propertyStatus = U.getPropStatus(section);
		if(html.contains("Final Homes Now Selling") && propertyStatus.contains("Final Homes, Move-in Ready Homes, Now Selling"))
			propertyStatus=propertyStatus.replace("Final Homes, Move-in Ready Homes, Now Selling", "Move-in Ready Homes,Final Homes Now Selling");
		
		String note = U.getnote(section);

		//==================================================================================
/*		if(comUrl.contains("https://www.pardeehomes.com/inland-empire/cascade/") || comUrl.contains("https://www.pardeehomes.com/inland-empire/daybreak/"))
			propertyStatus = propertyStatus + ", Oversized Homesites Available";
*/		
/*		if(comUrl.contains("https://www.pardeehomes.com/inland-empire/arroyo/") ||
				comUrl.contains("https://www.pardeehomes.com/inland-empire/cienega/")){
			add[1] = "Beaumont";
			add[2] = "CA";
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null)	add = U.getAddressHereApi(latLng);
			geo = "True";
			note = "Address & latLong taken from City and State";
		}*/
		/*if(comUrl.contains("inland-empire/centerstone/")||comUrl.contains("/inland-empire/horizon/")||comUrl.contains("/inland-empire/landmark/")) {
			add[1]="Banning";
			add[2]="CA";		
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null)	add = U.getAddressHereApi(latLng);
			
			geo="True";
			note = "Address & latLong taken from City and State";
		}*/
		
		if(comUrl.contains("https://www.pardeehomes.com/las-vegas/larimar/" )) {
			add[0] = "1213 Granite Falls Place";
			add[1] = "North Las Vegas";
		}
		
		if(comUrl.contains("blackstone/")||comUrl.contains("/indigo/")) {
			add[0]=add[0].replace("North", "");
			add[1]="North "+add[1];
		}
		
		if(comUrl.contains("https://www.pardeehomes.com/las-vegas/sandalwood/")) {
			latLng[0] = "36.161646"; //36.161646, -115.375239
			latLng[1] = "-115.375239";
		}
		
		if(comUrl.contains("https://www.pardeehomes.com/las-vegas/cobalt"))
			propertyStatus=propertyStatus.replace(", Now Open","");
		if(comUrl.contains("https://www.pardeehomes.com/inland-empire/vita/"))propertyType = "Patio Homes";
		
		add[0]=add[0].replace(add[1], "").replaceAll("Visit our New Home Gallery Located at Highline|Visit our New Home Gallery at Midnight Ridge", "");
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(propertyType, dType);
		data.addPropertyStatus(propertyStatus);
		data.addNotes(note);

	}
	i++;
	}
	
	private void addDetails(String url, String name,String comSec,String latLngSec)throws Exception {
	//TODO
//	if(i>=52)
//		if(!url.contains("https://www.pardeehomes.com/inland-empire/elan/"))return;
		{

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "*******Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			//if (url.contains("https://www.pardeehomes.com/las-vegas/encanto-at-durango-ranch/"))return;//Page Not found
			//String comhtml = U.getHtml(url, driver);
			String comhtml = U.getHTML(url);
			String comName = name;
			String comUrl = url;
			String extraDataUrl=comUrl+"lifestyle/";
			String lifeStyleHtml=U.getHTML(extraDataUrl);
			if (lifeStyleHtml!=null) {
				lifeStyleHtml=U.getSectionValue(lifeStyleHtml, "<div class=\"innerStr new_neighborhood\">", "<div class=\"contact_card\">");
				lifeStyleHtml=lifeStyleHtml.replaceAll("<h3>Golfing</h3>", "");
			}
			U.log(i+" ::url :: " + url);
			U.log("Name:: " + name);
			latLngSec = StringEscapeUtils.unescapeJava(latLngSec);
			U.log("comSec : "+latLngSec);
			String comType = ALLOW_BLANK;
			String propertyType = ALLOW_BLANK;
			String dType = ALLOW_BLANK;
			String propertyStatus = ALLOW_BLANK;
			String price[] = { ALLOW_BLANK, ALLOW_BLANK };
			String sqFt[] = { ALLOW_BLANK, ALLOW_BLANK };
			
			String noteVar = U.getnote(comhtml);

			// Florplan Urls
			String allFloorPlanData = ALLOW_BLANK;
			ArrayList<String> flrUrls = Util.matchAll(comhtml, "href=\"(.*?)\">View floor plans and gallery</a>",1);
			U.log("Total floor Plans : "+flrUrls.size());
			try {
			for(String flrUrl : flrUrls) {
				String floorHtml = U.getHTML(flrUrl);
				allFloorPlanData += U.getSectionValue(floorHtml, "<h3 class=\"neighborhood-name\"", "<div class=\"floorPlan_new row\">");
			}}
			catch(Exception e) {}
//			U.log(allFloorPlanData.contains("patio"));
			// Move-in-ready Urls
			String moveHtml = ALLOW_BLANK;
			String moveData =ALLOW_BLANK;
			if (comhtml.contains("Move-In Ready Homes</a>")) {
				U.log("hello");
				moveHtml = U.getHTML(comUrl + "move-in-ready/");
				String[] allPlanUrls=U.getValues(moveHtml, "<div class=\"card__image\"><a href=\"", "\">");
				U.log("Total move in homes :::::::::"+allPlanUrls.length+"::::::::::::::::::::");
				for(String planUrl: allPlanUrls){
					if(planUrl.contains("http")){
						U.log("Plan Url ::::: "+planUrl);
						String planHtml=U.getHTML(planUrl);
						try{
							String content = U.getSectionValue(planHtml, "<div id=\"qmidetials\"", "<div id=\"qmidetialsright");
							if(content == null) content =  U.getSectionValue(planHtml, "<div id=\"qmidetials\" class=", "<div class=\"floorPlan_new");
							moveData += content;
						}catch(Exception e){}
					}
				}
			}
			comhtml = comhtml.replace("Verana | Single Family Luxury Homes",
					"Verana Single Family Luxury Homes");
			comhtml = comhtml.replace(
					"master-planned community. (View Online)",
					"master-planned community View Online alterra");
			comhtml = comhtml.replace("master planned community providing",
					"master planned community providing summerfield");

			comhtml = comhtml
					.replaceAll(
							"\"name\": \"Daybreak Grand Opening\",|\"name\": \"Braeburn at Spencer’s Crossing - Grand Opening\",|<meta(.*?)>|opening this summer near Carnegie|Grand Opening Feb 25 - Visit the model homes|content=\"An exclusive 55\\+ Active Adult |content=\"Coming Fall 2017| home or common area will offer a |neighborhood Highlands Ranch|Pacific Highlands Ranch|neighborhood of New Homes Coming Soon|coming soon to Pacific|villages/westridge/|Assumptions. You are purchasing a single family|homeowner’s association dues|master planned community providing summerfield|master-planned community View Online alterra|to feature 78 single-family|Verana Single Family Luxury Homes|new floor plans at Keystone|rAnchor|content=\"Coming Soon - Viewpoint|content=\"Coming Soon - New homes|gated Solano|Gated Solano|highlands-ranch/|Pacific Highlands Ranch|Rancho|status-plan\">Sold Out",
							"");

			//U.log(comhtml);
			comhtml=comhtml.replaceAll("Alisio Grand Opening|First year of HOA dues|neighborhood highlands ranch|Grand Opening 4|NeighborhoodComing Soon|And coming soon|fitness center coming soon|\\(Coming Soon\\)|is Coming Soon to", "");
			comhtml = comhtml.replaceAll("Highlands Ranch|Highlands%20Ranch", "");
			comhtml=comhtml.replaceAll("Traditional architecture |Traditional. and Napa architectural", "Traditional Home")
								.replace("luxury residences", "luxury homes residences");
			comhtml=comhtml.replace("resort appeal thanks", "resort-style appeal thanks");
			comhtml=comhtml.replace("Coming Soon - Fall 2017", "Coming Soon Fall 2017")
											.replace("Coming Soon - Summer 2017", "Coming Soon Summer 2017");
			comhtml=comhtml.replace("Grand Opening - Summer 2017", "Grand Opening Summer 2017").replace("Farmhouse and", "modern farmhouse");
			if (comUrl.contains("/inland-empire/")) {
				comhtml+="master planned community";//Region pAge(homes for sale in the area’s best master-planned communities.)
			}
			
			
			//--------------------comType, Property Type,Dtype & Status -----------------------
			comType = U.getCommType(comhtml+lifeStyleHtml);
			String patioString=ALLOW_BLANK;
			if(allFloorPlanData!=null && allFloorPlanData.contains("Covered patio"))
				patioString ="Covered patio";

			propertyType = U.getPropType((comhtml+moveData+patioString).replaceAll("-Plan4-OutdoorPatio-|-Patio-", ""));
			dType = U.getdCommType((moveData+comhtml+allFloorPlanData).replaceAll("second story","").replace("First-floor"," 1 Story ")+moveData);
			comhtml=comhtml.replace("summer 2017 by","").replaceAll("us for the Grand Opening on November|<img(.*?)>|Altis Grand Opening|orhood-status-plan\">Temporary Sold Out</div>|status == \"Sold Out| status == \"Temporary Sold Out\"", "");
			comhtml=comhtml.replaceAll("3/Golf|status-plan\">Temporarily Sold Out|the Grand Opening of the brand new|Meridian Grand Opening|chool will be at Skyline, coming soon.|Centennial  - Coming Soon|[C|c]oming [S|s]oon to|The grand opening celebration is April 28|content=\"Coming soon to |\"Coming Soon\"|\"Sold Out\"|\"Temporary Sold Out\"|Center opening soon|Quick|final new homes are now selling in the beautiful|Starling- Grand Opening|hood coming|information on the final|Marketplace Now Open","")
					.replaceAll("VideoObject\",\\s+\"name\": \"Tamarack - Grand", "");
//			U.log(Util.matchAll(comhtml+lifeStyleHtml, "[\\s\\w\\s\\W]{30}golf[\\s\\w\\s\\W]{30}", 0));
			String rmNews=U.getSectionValue(comhtml, "<h2><span>News & Trends</span></h2>", "<div class=\"clear\"></div>");
			if(rmNews!=null)
			comhtml=comhtml.replace(rmNews, "");
			
			propertyStatus = U.getPropStatus(comhtml).replace("Marketplace Now Open", "");
			
			propertyStatus = propertyStatus.replace("Opening Fall 2018, Grand Opening", "Grand Opening Fall 2018");
			
//			U.log(comSec);
			
			// U.log("result:::"+Util.match(comhtml, ".*?Coming Fall 2017.*?"));
			
			// Squarefeet
			String minSqf = ALLOW_BLANK;
			String maxSqf = ALLOW_BLANK;
			String[] subSec= {ALLOW_BLANK,ALLOW_BLANK};
			if(comSec.contains("$shatam")) {
			subSec=comSec.split("$shatam");
			
			U.log("fffff"+subSec);
			comSec=subSec[1];
			}
			sqFt = U.getSqareFeet(comSec+latLngSec+comhtml + allFloorPlanData + moveHtml,
					"sqft\":\"\\d,\\d+ - \\d,\\d+\"|\\d{1},\\d{3} - \\d{1},\\d{3}  sq ft|\\d{1},\\d{3}\\s*–\\s*\\d{1},\\d{3} square feet|Approximately \\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} sq. ft. – \\d{1},\\d{3} sq. ft. |\\d{1},\\d{3}-\\d{1},\\d{3} square feet|\\d,\\d{3} sq. ft. � \\d,\\d{3} sq. ft|\\d{1},\\d{3}-\\d{1},\\d{3} sq. ft.|\\d,\\d+ to almost \\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ sq.ft|\\d,\\d+- to \\d,\\d+-square feet|\\d,\\d+ � \\d,\\d+ sq. ft.|\\d+,\\d+ – \\d+,\\d+ square feet|\\d+,\\d+ to \\d+,\\d+ square feet|\\d{1},\\d{3} sq ft",
					0);

			minSqf = (sqFt[0] != null) ? sqFt[0] : ALLOW_BLANK;
			maxSqf = (sqFt[1] != null) ? sqFt[1] : ALLOW_BLANK;

			U.log("minSqft:: " + minSqf + " maxSqft:: " + maxSqf);
			
			// Price
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;
			comhtml.replace("43502", "");
//comhtml.replaceAll("0s", "0");
			comhtml = comhtml.replace("300s", "300,000");
			comhtml=comhtml.replaceAll("1.2 million", "1,200,000")
					.replace("low $3 millions", "low $3,000,000");
			
			price = U
					.getPrices(
							comhtml + allFloorPlanData + moveHtml,
							"\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|>Priced at \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Priced at \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
							0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		//-------------------Address && latlng-----------------------
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
			String addHtml = ALLOW_BLANK;
			
			//***latlng from community page****
			comhtml = comhtml.replace("=&amp;", "=&");
			U.log("get::: " + U.getSectionValue(comhtml, "<li class=\"city\">", "</li>"));
			String latlngSec = U.getSectionValue(comhtml, "<a href=\"https://maps.google.com/maps?saddr=&daddr=", "\"");
			U.log("latlngSec : "+latlngSec);
			if (latlngSec !=null) {
				if(latlngSec.length() != 1)latLng = latlngSec.split(",");
				
			}
			U.log("latlng is "+Arrays.toString(latLng));
			
			//***Address fro directions page ****
			if(comhtml.contains("directions\">Directions</a><")){
				addHtml = U.getHTML(comUrl+"/directions");
				String addSec = U.getSectionValue(addHtml, "Directions</h2>", "<br/>");
				//U.log(":::::::::::::"+addSec);
				if(addSec!=null){
					addSec = addSec.replaceAll("Strada New Home Gallery - |</div>|<div class=\"row\">|<div class=\"medium-12\">|<p><b>", "").trim();
					U.log("new add sec:::::::::::::"+addSec);
					
					String[] tempAdd = addSec.split(",");
					add[0] = tempAdd[0].trim();
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2],"\\w+");
					add[3] = Util.match(tempAdd[2],"\\d+");
					U.log("Address is " + Arrays.toString(add));
					
					if(add[3]==null)add[3]=ALLOW_BLANK;
				}
			}
			else{
				String addSec = U.getSectionValue(comhtml, "<li class=\"city\">", "<br>");
				U.log("::::::::::: else :::::::: "+addSec);
				if(addSec != null){
					String [] tmp = addSec.trim().split(",");
					if(tmp.length==2){
						add[3] = Util.match(tmp[1], "\\d+");
						add[2] = Util.match(tmp[1], "[A-Z]{2}");
						if(add[2]!=null){
							add[1] = U.getCity(tmp[0], add[2]);
							add[0] = tmp[0].replaceAll(add[1], "").trim();
						}
						
					}
				}
				U.log("::::::::::: else :::::::: "+Arrays.toString(add));
			}
			
			if((add[0].length()<4 || add[3].length()<4)&& latLng[0].length()>4)
			{
				add = U.getAddressGoogleApi(latLng);
				geo = "TRUE";
			}
			
			
			if(latLng[0].length()<4 && add[3].length()>4  ){
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
				
			}
			//address from city and state
			if(add[0].length()<4 && latLng[0].length()<4){
				String city = Util.match(url, "com/(.*?)/",1);
				U.log(city+"\t"+url);
				add[1] = U.getCapitalise(city.replace("-", " "));
				U.log(add[1]+"\t"+cityState);
				add[2] = (String) cityState.get(city);
				
				latLng = U.getlatlongGoogleApi(add);
				add = U.getAddressGoogleApi(latLng);
				noteVar = "Address And Lat-Lng Are Taken Using City And State";
				geo = "TRUE";
			}
			add[0] = add[0].replace("Strada New Home Gallery - ", "");
			
			
			comName = comName.replace("Casavía", "Casavia");
			comName=comName.replace(": Homesites at Buffalo", "");
			comhtml = comName.replace(":", "");
			U.log(comName+"::::::::");
			if(comUrl.contains("https://www.pardeehomes.com/las-vegas/cobalt"))
				propertyStatus=propertyStatus.replace(", Now Open","");
			
			LOGGER.AddCommunityUrl(url);
			data.addCommunity(comName, url, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(propertyType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(noteVar);

		}
		i++;
	}
}
