/*
 *  Rakesh Chaudhari
	
 *  10 Oct 2015
 *  Modifications Rakesh
 */
package com.shatam.b_021_040;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTrilogylife extends AbstractScrapper {
	static int sitecounter = 0;
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;

	public static void main(String arg[]) throws Exception {

		AbstractScrapper a = new ExtractTrilogylife();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Shea Homes - Trilogy.csv", a
				.data().printAll());
	}

	public ExtractTrilogylife() throws Exception {
		super("Shea Homes - Trilogy", "https://www.trilogylife.com/");
		LOGGER = new CommunityLogger("Shea Homes - Trilogy--temp");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://www.sheahomes.com/trilogy/");//U.getHTML("https://www.trilogylife.com/communities/");

		// ******************* Get Region Urls****************//

		String section = U.getSectionValue(html,
				"<ul class=\"communities\">",
				"I WANT MORE INFO</h4>");

		String values[] = U.getValues(section, "<li class=\"community\">", "</li>");
		U.log(values.length);
		int totalComm = values.length / 2;
		for (String item : values) {
			// U.log("Community url::"+item);

			getCommunityUrl(item);
			inr++;
		}
		LOGGER.DisposeLogger();
	}

	private void getCommunityUrl(String addinfo) throws Exception {
		// U.log("**********" + addinfo + "****");

		String regUrl = U.getSectionValue(addinfo, "href=\"", "\"");
		U.log(addinfo);
		String commName = U.getSectionValue(addinfo, "<h4>", "<");

		if (commName != null)
			commName = commName.replace("®", "");

		U.log("@@@@@@@@commName::"+commName);
		//LOGGER.AddRegion(commName, regUrl.length());
		addDetails(regUrl, commName, addinfo);

	}

	private void addDetails(String comUrl, String commName, String addinfo)
			throws Exception {
//		if(!comUrl.contains("https://www.trilogylife.com/communities/arizona/wickenburg-ranch/"))return;

		// U.log("COMURL::::" + comUrl);
		
			
	if (j == 0) 
		{
			//U.log("COMURL::::" + comUrl);
			
			
			// Community Name
			sitecounter++;
			String html = U.getHTML(comUrl);
			html = html
					.replaceAll(
							"a traditionally-styled|pricing from $867,999</li>|Now Open For|Grand Opening|Town Homes|Patio Series|golf communities| Is Now Open!</h2>|Now Open In Peoria| now open for our| with the grand opening of the new| Custom Sales|Custom Home|CUSTOM HOME",
							"");

			// 6 Url redirect to sheaHome
//			if (comUrl.contains("sheahomes")) {
//				LOGGER.AddCommunityUrl(comUrl + "=========>sheahomes");
//				return;
//			}
			LOGGER.AddCommunityUrl(comUrl);


			if (commName == null) {
				String comNameSec = U.getSectionValue(html,
						"<div class=\"community-name\">", "</h1>");

				commName = U.getSectionValue(comNameSec, "\">", "</a>");

			}
			
			U.log("@@@@@@@@commName::"+commName);
			// ***************************** Address*********************//

			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK,
					ALLOW_BLANK, ALLOW_BLANK };
			String dirHtml = "";

			String ad = U.getSectionValue(html, "<p class=\"header\">Address</p>", "</div>");
			if (ad == null) {
				ad = U.getSectionValue(html, " id=\"enddisplay\" value=\"",
						"\"");
				if (add[0] == null) {
					add[0] = ALLOW_BLANK;
				}
			}
			if (ad != null) {
				ad = ad.replaceAll("<p>|</p>", "").replaceAll("<br>| <br />", ",").replaceAll("<span>|</span>", "");
				U.log(ad);
				add = U.getAddress(ad);
				add[0] = add[0].replace("30383 N 131ST DR", "30383 N 131St Dr").trim();
				add[1] = add[1].trim();
				add[2] = add[2].trim();
				add[3] = add[3].trim();
			}

			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]
					+ " Z:" + add[3]);

			// **************** LAT LONG****************************//

			String lat = U.getSectionValue(dirHtml, "map_latitude = \"", "\"");
			String lng = U.getSectionValue(dirHtml, "map_longitude = \"", "\"");
			if (lat == null) {
				String latSec = U.getSectionValue(html, "LatLng(", ")");
				if (latSec != null) {
					String latv[] = latSec.split(",");
					lat = latv[0];
					lng = latv[1];
				}
			}
			String flag = "False";
			if (lat == null) {
				lat = lng = flag = ALLOW_BLANK;
			}
			if (lat.length() < 3) {
				lat = lng = flag = ALLOW_BLANK;
			}
			U.log("LAT::" + lat + ":::LNG::" + lng);

			if (add[0] == ALLOW_BLANK) {
				String l1[] = { lat, lng };
				String addr[] = U.getAddressGoogleApi(l1);
				add[0] = addr[0];
				flag = "TRUE";
			}

			if (add[1] == ALLOW_BLANK) {
				String l1[] = { lat, lng };
				String addr[] = U.getAddressGoogleApi(l1);
				add[1] = addr[1];
				flag = "TRUE";
			}

			if (add[2] == ALLOW_BLANK) {
				String l1[] = { lat, lng };
				String addr[] = U.getAddressGoogleApi(l1);
				add[2] = addr[2];
				flag = "TRUE";
			}
			if (add[3] == ALLOW_BLANK) {
				String l1[] = { lat, lng };
				String addr[] = U.getAddressGoogleApi(l1);
				add[3] = addr[3];
				flag = "TRUE";
			}

			// *********************************** Square
			// Feet******************************//

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String sqSec = U.getSectionValue(html, " <div class=\"right\">",
					"</p>");
			String sqSec1 = U.getSectionValue(html, " <div class=\"left\">",
					"</div>");
			if (sqSec != null) {
				String[] sqft = U
						.getSqareFeet(
								sqSec + sqSec1,
								"\\d,\\d+ - \\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft.",
								0);// "(\\d{1},\\d+)",1);
				minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
				maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
			} else {
				// 2,726 Sq. Ft.
				String[] sqft = U
						.getSqareFeet(
								html,
								"from ~\\d{1},\\d{3} to ~\\d{1},\\d{3} square feet|\\d,\\d+ - \\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft.</li",
								0);
				minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
				maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
			}
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			// PRice
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String sec2 = U.getSectionValue(html, "class=\"news\"",
					"class=\"signup_container\"");
			html = html.replaceAll("0's|0s|0S", "0,000");
			String moveHtml = ALLOW_BLANK;
			if (!comUrl.contains("riceranch")) {
				moveHtml = U.getHTML(comUrl + "moveins");
			}		
			
			String allHomesData = ALLOW_BLANK;
			ArrayList<String> homeSec = Util.matchAll(html, "<a href=\"(.*?)\">\\w+\\s*<div class=\"tooltip\">",1);
			for(String home : homeSec){
				U.log("home : "+home);
				String homeHtml = U.getHTML(home);
				allHomesData += U.getSectionValue(homeHtml, "Overview</a></li>", "<div class=\"floorPlan\">");
			}
			
			
		//	U.log(U.getCache(comUrl));
			String priceSec = U.getSectionValue(html, "community-header\">",
					"sidebar-box\">");
			html = html.replace("$1M+", "$1,000,000").replace("0&rsquo;s",
					"0,000");
			// U.log(html);
			addinfo = addinfo.replace("$500s to spectacular $1 Million+",
					"$500,000 to spectacular $1,000,000")
					.replaceAll("0s|0's", "0,000");
			// quickhtml=quickhtml.replaceAll("<li>Price reflects \\$[0-9]{3},[0-9]{3}",
			// "");
			if (sec2 != null)
				html = html.replace(sec2, "");
			// moveHtml = moveHtml.replace("<strong class=\"extra\">PRICE: $",
			// "");
			String[] price = U
					.getPrices(
							html + moveHtml + priceSec + "" + addinfo,
							"from the mid \\$\\d{3},\\d{3}|Priced From \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|Base pricing from \\$\\d{3},\\d{3}</a>|PRICE: \\$[0-9]{3},[0-9]{3}|\\$\\d,\\d+,\\d+|\\$\\d{3},\\d+ to \\$\\d{3},\\d+|PRICE: \\$\\d{3},\\d+|mid \\$\\d+,\\d+ to the \\$\\d+,\\d+|priced from the \\$\\d+,\\d+",
							0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice :" + maxPrice + "------");

			// ************************ Property Type**********************//

			dirHtml = dirHtml.replaceAll("luxurious locker rooms|Luxury comes",
					"");
			html = html.replaceAll("luxurious locker rooms|Luxury comes", "").replace(" is a luxurious", "luxury design");
			if (moveHtml != null) {
				moveHtml = moveHtml
						.replaceAll(
								"Custom Sales|Custom Home|CUSTOM HOME|Town Homes|a traditionally-styled",
								"");
			}
			String pSec = U.getNoHtml(dirHtml + html + moveHtml);
			pSec=pSec.replaceAll("feeling of quality and craftsmanship", "");
			String pType = U.getPropType(pSec);
			
		//	U.log("%%%%%%%%%%"+html);
			
			html = html
					.replaceAll(
							"riceranc|wickenburg-ranch|Rice Ranch|Wickenburg Ranch|Encanterra® Resort Community|ranch|Rancho|featuring 1- and 2-story homes ranging",
							"");
			// U.log("result:"+Util.match(html, ".*?ranch.*?"));
			String dType = U.getdCommType(commName + html+allHomesData);
			dirHtml = dirHtml.replace("Shea and Trilogy Master Planned", "");
			html = html.replace("Shea and Trilogy Master Planned", "");
			html = html.replace("Resort Community", "");
			html=html.replaceAll(" 55\\+ golf resort community", "55 and greater.,golf course,resort style community");
			// U.log(html);
			// U.log("addinfo::"+addinfo);
			//U.log("Showhtml==="+html);
			//U.log("Showaddinfo==="+addinfo);
			//String sec="<a href=\"/55-plus-communities/\">55+ communites</a>";
			String comType = U.getCommunityType(html + addinfo);

			String pStatus = ALLOW_BLANK;// Opening Early 2014
			html = html.replace("Community Closed Out", "Close Out Community");
			String remove1 = "baseball stadium \\(coming 2019\\)|Now Open!<br /><br /></p>|Community Selling Now! With resort-style|Social Club, Coming Early 2018!|Now Open! The Seven |Shenandoah Lodge Grand Opening at Trilogy |Club - Grand Opening|Club is now open|on special events, new releases, and |Model Home Gallery is now ope|The Mita Club coming soon|Quick Move-In Homes|Come to the grand opening celebration |New Model Gallery Grand Opening This|announce the grand opening of our newest|floor plans and our Grand Opening special event|special updates and grand opening|since the grand opening event has been|Temporarily Sold Out|<p>Coming Soon!</p>|Final Home Now Selling";
			html = html.toLowerCase().replaceAll(remove1.toLowerCase(), "");
			String statusSect = html;
			html = html.replaceAll(" Model Home Gallery is now ope", "");
			html = html.replaceAll("Now Open - Come Take A Tour!", "");
			html = html.replaceAll("now open for our Members to enjoy!", "");
			html = html.replace(" now open at Trilogy|Social Club, Now Open!<",
					"");
			String planSec = U.getSectionValue(statusSect, "class=\"plans\"",
					"class=\"overview\"");
			if (planSec != null)
				statusSect = statusSect.replace(planSec, "");
			statusSect = statusSect
					.toLowerCase()
					.replaceAll(
							"Mills Club, Coming Soon|Now Open! Visit The Mita Club|golf course</span></a>&nbsp;now open|Mita Club, coming soon|celebrating the grand opening of|Grand Opening Celebration|Grand Opening of 2 beautiful bran|Grand Opening Celebration!|Grand Opening Reception|Grand Opening on March|Pre-Grand Opening Pricing|golf course now open|Center Now Open|Model Gallery Now Open|Coming Soon: The Mita|Grand Opening Celebration: Come|Grand Opening Celebration: Come|Gallery Grand Opening Now|Polo Club Grand Opening Celebration|Sports Complex Grand Opening|Amenity at encanterra, is grand opening now|quick|The Mita Club coming soon|<strong>Grand Opening</strong>|;Vision Studio Now Open|special updates and grand opening information|simply not available anywhere|Models Now Selling!|>Move-in Ready Homes<|View Our Move-In Ready Homes|4 Release Coming Soon|<div class=\"col4\"><p>Now Open!</p></div>|come see the new homes available."
									.toLowerCase(), "");
			// U.log(statusSect);
			String statusRem = U.getSectionValue(statusSect,
					"choose your home", "lifestyle <span>");
			if (statusRem != null)
				statusSect = statusSect.replace(statusRem, "");
			statusSect = statusSect.replace(
					"new phase of the community is now available",
					"new phase now available").replaceAll("we've just", "").replace("<br />New Oak House Resort Club Now Open!</h2>","").replace("</a>&nbsp;now open</li>","").replace("<br />new oak house resort club now open!</h2>","");
			//U.log("propertystatus=="+statusSect);
			pStatus = U.getPropStatus(statusSect);

			String note = U.getnote(html);

			if (add[0] == ALLOW_BLANK && lat != ALLOW_BLANK) {
				add = U.getGoogleAdd(lat, lng);
			}

			if (pStatus.length() < 3)
				pStatus = "";
			html = U.getHTML(comUrl);

			if (html.contains("<h2>Quick Move-In Homes")) {

				if (pStatus.length() < 1)
					pStatus = "Quick Move-ins Available";
				else
					pStatus = pStatus + ",Quick Move-ins Available";
			}

			else {
				if (pStatus.length() < 1)
					pStatus = "No Quick Move-ins Available";
				else
					pStatus = pStatus + ",No Quick Move-ins Available";

			}

			if (comUrl
					.contains("http://www.trilogylife.com/communities/arizona/verde-river/")) {
				dType = "Ranch";
			}
			if (comUrl
					.contains("http://www.trilogylife.com/communities/california/riceranch/")) {
				comType = "55+ Community";

				comType = comType.replace("55+ Community", "");

				pType = pType +", Luxury Homes";

				pStatus = pStatus.replace("New Phase, Now Available",
						"New Phase Now Available");

			}
			if (comUrl
					.contains("http://www.trilogylife.com/communities/nevada/las-vegas/")) {

				pStatus = pStatus.replace("Now Open,", "");
			}//http://www.trilogylife.com/communities/florida/ocala/
			if (comUrl
					.contains("http://www.trilogylife.com/communities/florida/ocala/")) {

				pType =  "Patio homes";
			}
			
			if (comUrl
					.contains("http://www.trilogylife.com/communities/florida/ocala/")) {

				pStatus = pStatus.replace("New Homes Available,", "");
			}
			if (comUrl
					.contains("http://www.trilogylife.com/communities/arizona/verde-river/")) {

				pStatus = pStatus.replace("Coming Soon,", "");
			}
			if (comUrl
					.contains("http://www.trilogylife.com/communities/arizona/wickenburg-ranch/")) {

				pStatus = pStatus.replace("New Homes Available, Now Open,", "");
			}
			if (comUrl
					.contains("http://www.trilogylife.com/communities/nevada/las-vegas/")) {
				pStatus = pStatus.replace("Selling Now,", "");
					pStatus = pStatus+",Now Selling";
			}
			

			U.log("COMNAME::" + commName);
			commName = commName
					.replaceAll(
							"®, a Trilogy® Resort Community|Trilogy® in |Trilogy® at|\\?\\?|\\?|Trilogy\\?\\? in|Trilogy\\?\\? at|Trilogy|Trilogy® at|Shea Homes® at |Trilogy®|™|®|Shea Homes At |Shea Homes at ",
							"");
			commName = commName.replace("Trilogy<sup></sup>, Located in", "");
			commName = commName.replace("<sup></sup>", "");
			commName=commName.replaceAll("Shea Homes at |, a  Resort Community", "");

			if (comUrl
					.contains("http://www.trilogylife.com/communities/nevada/ardiente/")) {
				pStatus = "Nearly Sold Out,Just One Home Remaining,No Quick Move-ins Available";
				add[0] = "5840 Summit Greens St";
				flag = "TRUE";
			}
			U.log("@@@@@@@@@@@@@@@@@@@ ::"+pType);
			
			
			U.log("COMNAME::" + commName);
			commName = commName.replace("Town Homes", "");

			if (maxPrice == null) {
				maxPrice = ALLOW_BLANK;
			}

			if (data.communityUrlExists(comUrl))
				return;
			data.addCommunity(commName.trim(), comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), flag);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
		}
		j++;
	}
//	public static String getHtml(String url, WebDriver driver) throws Exception {
//		// WebDriver driver = new FirefoxDriver();
//
//		String html = null;
//		String Dname = null;
//
//		String host = new URL(url).getHost();
//		host = host.replace("www.", "");
//		int dot = host.indexOf("/");
//		Dname = (dot != -1) ? host.substring(0, dot) : host;
//		File folder = null;
//
//		folder = new File(U.getCachePath() + Dname);
//		if (!folder.exists())
//			folder.mkdirs();
//	
//		String fileName = U.getCacheFileName(url);
//
//		fileName = U.getCachePath()+ Dname + "/" + fileName;
//
//		File f = new File(fileName);
//		if (f.exists()) {
//			return html = FileUtil.readAllText(fileName);
//			// U.log("Reading done");
//		}
//
//		
//
//		// if(respCode==200)
//		{
//
//			if (!f.exists()) {
//				synchronized (driver) {
//
//					BufferedWriter writer = new BufferedWriter(
//							new FileWriter(f));
//				
//					driver.get(url);
//					//U.log("after::::"+url);
//					Thread.sleep(2000);
//					((JavascriptExecutor) driver).executeScript(
//							"window.scrollBy(0,400)", ""); 
//					Thread.sleep(3000);
//					U.log("Current URL:::" + driver.getCurrentUrl());
//					html = driver.getPageSource();
//					Thread.sleep(2000);
//					WebElement e=driver.findElement(By.xpath("//*[@id=\"btnHiddenQMIHomesDeferInitialDataLoad\"]"));
//					e.click();
//					Thread.sleep(2000);
//					html=driver.getPageSource();
//					Thread.sleep(1000);
//					
//					writer.append(html);
//					writer.close();
//
//				}
//			} else {
//				if (f.exists()) {
//					html = FileUtil.readAllText(fileName);
//					U.log("Reading done");
//				}
//			}
//			return html;
//		}
//		// else{
//		// return null;
//		// }
//	}

}
