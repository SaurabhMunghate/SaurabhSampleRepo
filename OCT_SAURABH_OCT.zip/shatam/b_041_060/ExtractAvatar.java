/** Modification Aditya.
@author Rakesh Chaudhari
 *   
 */

package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractAvatar extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int j=0;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractAvatar();
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"csv/AV Homes.csv", a.data().printAll());
	}

	public ExtractAvatar() throws Exception {

		// super("Avatar Holdings", "http://www.avatarhomes.com/"); Change to
		// BElow NAme
		super("AV Homes", "http://www.avhomesinc.com/");
		LOGGER = new CommunityLogger("AV Homes");
	}

	public void innerProcess() throws Exception {

		String htm = U.getHTML("http://www.avhomesinc.com/");

		String sec[] = U.getValues(htm, "<a class=\"metro-area\" href=\"", "\"");

		// <a href="/communities/vitalia-at-tradition">View Community �</a>
		ArrayList<String> list = Util.matchAll(htm,"href=\"([^\"]+).>\\s*View Community", 1);
		for (String item : sec) {
//		U.log(item);

			String html = U.getHTML(item);
			String[] urlsec = U.getValues(html,	"<a class=\"scalable-this","<div class=\"listing-footer\">");
	//		U.log(urlsec.length);
			html = StringEscapeUtils.unescapeJava(html);
			//U.log(html);
			String latlngSec[]=U.getValues(html, "{\"map_id\":\"", "custom_fields_htm");
	//		U.log("Result:"+latlngSec.length);
			int totalComm = urlsec.length / 2;
			for (String comminfo : urlsec) {
				String comurl = U.getSectionValue(comminfo, "href=\"", "\">");
				//U.log("*****" + comurl);
				String commName = U.getSectionValue(comminfo, ">", "<");
				commName=commName.replaceAll("\\d. ", "");
				//U.log(comname);
//				comname=comname.replaceAll(" :: 55+ Community, AZ| &#8211; 55+ Community, FL", "");
				
				if (this.data.communityUrlExists(comurl)) {
					continue;
				}
				String tempLL=ALLOW_BLANK;
				for (String latlon : latlngSec) {
					if(U.getSectionValue(latlon, "linkd\":\"", "\"").contains(comurl.replaceAll("http://www.avhomesinc.com/communities/|/", ""))){
						tempLL=latlon;
						//U.log("found");
						break;
					}
				}
				addDetails(comurl, tempLL, item,comminfo,commName);
				inr++;
				// i++;
			}
			
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String url, String latLngSec, String regionUrl,String info,String commName)throws Exception {

	//if(!url.contains("http://www.avhomesinc.com/communities/heritage-run-townhomes/"))return;  //--run for single community
//		U.log(info+"^^^^^^^^^");
		
		if (url.contains("http://www.avhomesinc.com/communities/royal-oak-homes"))return;
		if(url.contains("http://www.avhomesinc.com/communities/bonterra-builders/"))return;
		if(url.contains("http://www.avhomesinc.com/communities/vermillion/"))return;
		if(url.contains("http://www.avhomesinc.com/communities/morgans-branch/"))return;
		//Date : 29-04-17
		if(url.contains("http://www.avhomesinc.com/communities/savvy-homes/"))return;
		
		//Oakdale homes, community of AVHOMES is redirecting to new url (http://www.avhomesinc.com/communities/oakdale-homes/),so providing data in separate csv file.
		if(url.contains("http://www.avhomesinc.com/communities/oakdale-homes/"))return;
		//Hampton Homes, community of AVHOMES is redirecting to new url (http://www.avhomesinc.com/communities/hampton-homes/),so providing data in separate csv file.
		if(url.contains("http://www.avhomesinc.com/communities/hampton-homes/"))return;
			//commname=commname.replaceAll(" &#8211; 55+ Community, FL", "");
			//U.log(commname+"this is piyush");
			
			
		//if(j==14)
		{
			U.log("\nPage: "+ j+" " + url);
			String htm = U.getHTML(url);
			String HTML=htm;
			String mainhtml=U.getSectionValue(htm, "<div class=\"post-content scalable\">", "<div class=\"clear\">");

			//===================== Comm Name ================
			
			commName = commName.replace(":: 55+ Community, AZ","");
			commName = commName.replace(", FL", "");
			commName = commName.replace("+ Community", "").replace("Coming Soon to Fernandina Beach &#821","").replace("!","");
			commName=commName.replaceAll(" &#821New Phase Coming Soon| Coming Soon!| ONE Move-In Ready Home Left!|&#8211; Now Pre-Selling!$", "");
			U.log(commName);
			//String commName = U.getSectionValue(htm, "<div class=\"headline\">", "<br />");
//			commName = commname;
			commName=commName.replaceAll(" &#821Phase 2 Coming Soon| &#821Final Close\\s*[o|O]ut| &#821New Phase| :: 55+ Community, Az| &#8211; 55+ Community, FL", "");
			commName = commName.replaceAll(":: 55+ Community, Az|:: + Community, Az|#|\\d+|;|&|\\.|ña|  + Community, FL| &#8211; 55+ Community, FL|Now Selling(!)?$|(Coming Soon|Model(s)? Open)(!)?", "").trim();
			U.log(commName+"%%%%%%%%%%%5");
			String remove1="  + Community, FL| :: + Community, AZ|  + Community, FL".toLowerCase();
			commName=commName.toLowerCase().replaceAll(remove1.toLowerCase(), "");
			

			//============== Address =========================
			//htm=htm.replaceAll("<br>Southeast Corner of <br/>Jackrabbit Trail and Van Buren Street|Sales Center NOW OPEN <br/>", "");
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec = U.getSectionValue(htm, "<div class=\"the-comm-address text-center\">", "</a><br/>");
			U.log("addSec : "+addSec);
			if(addSec != null){
				addSec = addSec.replaceAll("<address class=\"no_translate\">|<a href=\"(.*?)>|\\((.*?)\\)", "");
				
				if(addSec.contains("GPS Address:") && addSec.contains("Mailing Address")){
					addSec = U.getSectionValue(addSec, "GPS Address:</strong> <br/>", "<br/><strong>Mailing Address");
				}
				addSec = addSec.replaceAll("GPS address: |<br/>Mailing Address: 6511 Crown Parkway|<br>Southeast Corner of <br/>Jackrabbit Trail and Van Buren Street", "");
				addSec = addSec.replace("<br/><br/>", "<br/>").trim()
						.replace("<br/>", ",")
						.replace("<br>", "");
				add = U.getAddress(addSec);
				U.log("addSec : "+addSec);
			}
			U.log("add : "+Arrays.toString(add));
			//===This is latlng Sec from region page
			String latilongi[]={ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
			U.log("latLngSec::"+latLngSec);
			if(latLngSec!=null){
				latilongi[0]=U.getSectionValue(latLngSec, "\"lat\":\"", "\"");
				latilongi[1]=U.getSectionValue(latLngSec, "\"lng\":\"", "\"");
			}
			U.log(latilongi[0]+"\t"+latilongi[1]);
			add[0]=add[0].replace("Jomax & Lake Pleasant Pkwy, 9814 W. Rowel Rd.", "9814 W. Rowel Rd.")
					.replace("of, Jackrabbi", "of Jackrabbi");
			add[0]=add[0].replace("Now Selling!", "");
			if(add[0].length()<4&& latilongi[0].length()>4){
				add = U.getAddressGoogleApi(latilongi);
				geo="TRUE";
			}
			if(add[0].length()>4 && latilongi[0]==null){
				latilongi = U.getlatlongGoogleApi(add);
				geo="TRUE";
			}
			
			//============ Price Section =========================
//			String moveLink = Util.match(htm,"href=\"(/communities/[^/]+/move-ready)", 1);
			String moveLink = U.getSectionValue(htm, "slug=\"quick_move_ins\" class=\"\">", "</a>");
//			U.log("move==" + moveLink);
			String quickHomeHtml = null;
			if (moveLink != null) {

				String quickUrl = U.getSectionValue(moveLink, "<a href=\"", "\"");
				U.log("Quick Url=="+quickUrl);
				quickHomeHtml = U.getHTML(quickUrl);
	//			htm = htm + U.getHTML("http://www.vitaliahomes.com" + moveLink);
			}
	//		String homeLink = Util.match(htm,"href=\"(/communities/[^/]+/home-designs)", 1);
			String homeLink = U.getSectionValue(htm, "slug=\"home_designs\" class=\"\">", "</a>");
		//	U.log("homeLink==" + homeLink);
			if (homeLink != null) {
				//U.log(homeLink);
				String homeDesignUrl = U.getSectionValue(homeLink, "<a href=\"", "\"");
				U.log("Home design url=="+homeDesignUrl);
//				htm = htm + U.getHTML("http://www.vitaliahomes.com" + homeLink);
				htm = htm + U.getHTML(homeDesignUrl);				
			}
			

			//============ Price ======================
//			U.log(url);
			htm = U.getHTML(url);
			htm=htm.replace("00&#8217;s", "00,000").replaceAll("0&#039;s", "0,000");
			htm = htm.replaceAll("0s", "0,000s");
			String priceSec1 = U.getSectionValue(htm,	"<li name=\"home_designs", "<span>");
			String homeHtml = ALLOW_BLANK;
			String planHtml = ALLOW_BLANK;
			//U.log(priceSec1);
			if (priceSec1 != null) {
				homeHtml = U.getHTML(Util.match(priceSec1, "<a href=\"(.*?)\"",	1));
				homeHtml += U.getHTML(Util.match(priceSec1,	"<a href=\"(.*?)\"", 1) + "&focus=estate");
			}
			String priceSec2 = U.getSectionValue(htm,"<li name=\"quick_move_ins\"", "<span>");
			if (priceSec2 == null) {
				priceSec2 = U.getSectionValue(homeHtml,"<li name=\"quick_move_ins\"", "<span>");
			}
//			 U.log(Util.match(priceSec2, "<a href=\"(.*?)\"",1));

			if (priceSec2 != null)
				planHtml = U.getHTML(Util.match(priceSec2, "<a href=\"(.*?)\"",1));

					
			String pricehtml = homeHtml + planHtml;
			pricehtml = pricehtml.replace("0s", "0,000");
			htm = htm.replace("0s", "0,000");
			info=info.replace("s</li>", ",000");
			String jackUrl = "http://www.avhomesinc.com/metro-areas/jacksonville-metro/#";
			String jackhtml = U.getHTML(jackUrl);
		//	U.log("JACKHTML======>>"+jackhtml);
			
		//	U.log("pricehtml"+pricehtml);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			if(pricehtml.contains("<div class=\"pricing-cont w-special\">"))
			{
			String[] rem=U.getValues(pricehtml, "<div class=\"pricing-cont w-special\">","</div>");
			for(String rem1:rem)
			{
			htm=htm.replace(rem1,"");
			pricehtml=pricehtml.replace(rem1,"");
			}
			}
			info=info.replaceAll("0’s", "0,000").replace("0&#8217;s", "0,000");
			//U.log("Info 1===="+info);
			info = info.replace("0s", "0,000");
			//U.log("Info===="+htm);
			//
			String secPrice[] = U.getPrices(htm + pricehtml+info+jackhtml,
					"mid-\\$[0-9]{3},[0-9]{3}|upper \\$[0-9]{3},[0-9]{3}|high \\$[0-9]{3},[0-9]{3}|from the mid-\\$[0-9]{3},[0-9]{3}|Price: \\$\\d{3},\\d{3}|price\">\\$\\d+,\\d+|Homes starting(.*?)\\$\\d+,\\d+|Special Price: \\$\\d+,\\d+|Price:</span>\\s*\\$\\d+,\\d+|\\$\\d+,\\d+s|in the low \\$\\d+,\\d+|mid \\$\\d+,\\d+|Special Price: \\$\\d{6}|Special Price: \\$\\d{3},\\d{3}|Starting in the [0-9]{3},[0-9]{3}|from the Low \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}",
							0);
			minPrice = (secPrice[0] == null) ? ALLOW_BLANK : secPrice[0];
			maxPrice = (secPrice[1] == null) ? ALLOW_BLANK : secPrice[1];
			U.log("minPrice :" + minPrice + "  MaxPrice :" + maxPrice);
			
			//================== Square Feet =========================
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String hmedesingn=url+"?tab=home_designs";
			String hmedesignhtml=U.getHTML(hmedesingn);
			U.log("12121212"+U.getCacheFileName(hmedesingn));
			htm=htm.replace("Ranging in sizes from 1,600-2,600 sq. ft. Perfect for families of any size", "").replace("100s", "100,000").replace("fireplace, a 3,400 sq. ft. fitness center", "");
			pricehtml=pricehtml.replace("Ranging in sizes from 1,600-2,600 sq. ft. Perfect for families of any size", "").replace("fireplace, a 3,400 sq. ft. fitness center", "");
			htm=htm.replace("&#8211;", "-").replace("The new 18,500 sq. ft. center", "").replace("branch", "");
			
			String secsqFt[] = U.getSqareFeet(	htm + pricehtml+hmedesignhtml+info,
							"\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*square feet|\\d,\\d{3}\\s*-\\s*\\d,\\d{3} sq. ft.|<div class=\"home-design-sqft\">\\d,\\d{3} sq.ft.</div>|\\d,\\d{3} - \\d,\\d{3}\\+ sq. ft.|[0-9]{1},[0-9]{3} sq. ft. to [0-9]{1},[0-9]{3}|[0-9]{1},[0-9]{3}-[0-9]{1},[0-9]{3} Sq. Ft|[0-9]{1},[0-9]{3} to over [0-9]{1},[0-9]{3} sq. ft.|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3} Sq. Ft.|[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3} sq. ft.|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3} Square Feet|\\d,\\d+ to \\d,\\d+-square-fee|\\d,\\d+ to over \\d,\\d+ square feet|footage\">\\d+,\\d+</td>|Sq. Ft. \\d+,\\d+|\\d+,\\d+ to \\d+,\\d+ Sq. Ft.|Sq. Ft.:</span>\\s*\\d,\\d{3}| \\d,\\d+ Sq. Ft|Sq. Ft. \\d+,\\d+|[0-9]{1},[0-9]{3} sq. ft. to [0-9]{1},[0-9]{3} Square Feet|from \\d{4} to over \\d{4} Square Foot",
							0);
			minSqf = (secsqFt[0] == null) ? ALLOW_BLANK : secsqFt[0];
			maxSqf = (secsqFt[1] == null) ? ALLOW_BLANK : secsqFt[1];
			U.log("minSQF :" + minSqf + "  MaxSQF :" + maxSqf);

			//================= Property Status =======================
			String quick= U.getHTML(url + "?tab=quick_move_ins");
			String[] quickhomes=U.getValues(quick, "<a class=\"btn item-link\" href=\"", "\"");
			U.log("Quick Home count :::::"+quickhomes.length);
			String quickStatus = ALLOW_BLANK;
			if(htm.contains("?tab=quick_move_ins"))
			{
				if(quickhomes.length > 0){
					quickStatus = quickhomes.length+" Quick Move-ins Available";
			}else {
				quickStatus = "No Quick Move-ins Available";
			}
			}
			
			String qHomesHtml="";
			for(String quickh:quickhomes)
			{
				String dumpQhtml= U.getHTML(quickh);
				qHomesHtml += U.getSectionValue(dumpQhtml, "<h1 class=\"the-title\">", "Request More Information");
			}
			qHomesHtml=qHomesHtml.replaceAll("Branch|branch|Southwest-Ranch|-branch-|morgansbranch", "");
			String pStatus = ALLOW_BLANK;
			String statSec = htm;
			String remove = "AV Homes is Coming Soon|playground (.*?) opening Summer 2018|content=\"Phase II Now Selling|content=\"Stonebridge is now open! |Models Now Open|content=\"now open|models now open|NOW OPEN! ! 53 new homes|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|<strong> NOW open 7 days|Information Center NOW OPEN|Amelia Walk Now Open|quick move-in|Quick Move-In|Quick Move-Ins|quick-move-ins|Quick Move In Ready Homes Available|Quick Move-In|quick_move_ins";
			statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
			// U.log(statSec);
			String remS=U.getSectionValue(statSec, "<div class=\"translation-tool\">","<div class=\"main-nav clearfix\">");
			if(remS!=null)
			{
				statSec=statSec.replace(remS.toLowerCase(),"");
			}
			String remStatus = U.getSectionValue(statSec,
					"additional community details", "</body>");
			if (remStatus != null)
				statSec = statSec.replace(remStatus, "");
			statSec = U.removeComments(statSec);
			info = info.replaceAll("alt=\"Amelia Walk is now open|Models Now Open|View Homesites Available", "");
			info=info.replaceAll("Kissimmee are opening soon", "");
			statSec = statSec.replace("opening fall of 2017", "opening fall 2017").replaceAll("kissimmee are opening soon.", "");
			//U.log("infor::"+info);
	//U.log("statSec =="+statSec);
			
			pStatus = U.getPropStatus((statSec+info).replaceAll("model homes will be opening fall 2017|opening spring 2018|Private Encore Center opening in 2016|models now open|homes available now|soon in daven|sale that are ready to", "")+quickStatus);

			String avHomesHtml="";
			if(hmedesignhtml!=null)
			{
				if(hmedesignhtml.contains("<div class=\"home-design-image\">"))
				{
				ArrayList<String> avHomes= Util.matchAll(htm, " <div class=\"home-design-image\">\\s*<a href=\"(.*?)\"",1);
					U.log("total:::::::::::"+avHomes.size());
					for(String avh:avHomes)
					{
						//U.log(avh);
						String avhHtml=U.getHTML(avh);
						avHomesHtml += U.getSectionValue(avhHtml, "the-home-design-highlights", "</div>");
					}
				}
			}
			
			//============== Community Type ======================
			htm=htm.replaceAll("menu-item-55-plus-lifestyle\"><a href=\"/why-av-homes/?tab=55_plus_lifestyle\">55-Plus Lifestyle</a></li>|menu-item-55-plus-lifestyle\"><a href=\"/why-av-homes/?tab=55_plus_lifestyle\">55-Plus Lifestyle</a></li>|Active Adult Communities|Active Adult community|resort-styled pool|resort pool|Resort-style outdoor pool", "");
			String ameUrl = url+"?tab=amenities";
			String ameHtml = U.getHTML(ameUrl);
			htm = htm.replace("menu-item-55-plus-lifestyle\"><a href=\"/why-av-homes/?tab=55_plus_lifestyle\">55-Plus Lifestyle</a></li>", "").replaceAll("tech to active", "");
			ameHtml = ameHtml.replace("menu-item-55-plus-lifestyle\"><a href=\"/why-av-homes/?tab=55_plus_lifestyle\">55-Plus Lifestyle</a></li>", "");
			
			String drop = U.getSectionValue(htm, "var availableTags = ", "</script>");
			if (drop!=null) {
				htm = htm.replace(drop, "");
			}
			String drop1 = U.getSectionValue(ameHtml, "var availableTags = ", "</script>");
			if (drop1!=null) {
				ameHtml = ameHtml.replace(drop1, "");
			}
			
			//U.log(U.getSectionValue(ameHtml, "html", " $(function(){"));
			//U.log(ameHtml);
			
			if(htm.contains("<div class=\"sidebar\">")){
				String remSlider=U.getSectionValue(htm, " <div class=\"sidebar\">", " View All<span class=");
				//U.log(remSlider);
				if(remSlider!=null){
					htm=htm.replace(remSlider, "");
				}
			}
			 
			info = info.replace("amp;", "");
//			U.log(info);
			String comType = U.getCommunityType(htm+info+(ameHtml).replaceAll("Active|active", "")+info);
			
			//U.log(htm);
			String desc=U.getSectionValue(htm, "<div class=\"clearfix\">", "class=\"align-center\">");
			//U.log(desc);
	
			//U.log(moveLink);
			
			
		
			LOGGER.AddCommunityUrl(url);
			if(data.communityUrlExists(url))
			{
				LOGGER.AddCommunityUrl(url+"----->Repeat!");
				return;
			}
		
			
			//U.log(commName+"this is community name&&&&&&");
			commName=commName.trim();
			commName=commName.replaceAll("  + Community, FL|Coming Soon!| One Move In Ready Home Left!", "");
			
			//=============== Derived Community Type ===========================
			htm = htm.replace(" &amp; ", " & ");
			String comOverview  = U.getSectionValue(htm, "<div class=\"the-comm-content\">", "</div>");
			htm=htm.replaceAll("Branch|branch|Southwest-Ranch|-branch-|morgansbranch", "");
			htm=htm.toLowerCase().replaceAll("ranch|branch".toLowerCase(), "");
			qHomesHtml=qHomesHtml.toLowerCase().replaceAll("ranch|branch".toLowerCase(), "");
			hmedesignhtml=hmedesignhtml.toLowerCase().replaceAll("ranch|branch".toLowerCase(), "");
			info=info.toLowerCase().replaceAll("branch".toLowerCase(), "");
			//U.log(comOverview);
			htm=htm.replace("one-and-two-story"," 1 story  2 story  ");
			avHomesHtml = avHomesHtml.replace("covered patio. Complete with a 2 car garage", "");
			
			String dtype=null;
			
			 dtype=U.getdCommType(info+comOverview+(htm+qHomesHtml+avHomesHtml).replaceAll("ranch|Ranch ",""));
			
			
			//=============== Property Type =========================================
			htm = htm.replace("villa series", " Villas ").replaceAll("(label|value):\"The Villas|(v|V)illage", "");
						
			String remSec1 = U.getSectionValue(htm, "var availabletags=", "</script>");
			if(remSec1 != null)
				htm = htm.replace(remSec1, "");
			
			String ptype=U.getPropType((htm+info+avHomesHtml+mainhtml+qHomesHtml).replaceAll("Semi-custom|semi-custom", ""));
			//U.log("avHomesHtml : "+avHomesHtml);
			htm=htm.toLowerCase().replaceAll("branch|Village".toLowerCase(), "");
			if(commName.contains("Casa Monts")){
				commName="Casa Montana";
			}
			commName=commName.replaceAll("sold out!| now pre selling!","").replace("townhomes","");
			U.log("name:- "+commName);
			
			commName=commName.replace("Williams Preserve Coming Soon","Williams Preserve");
			data.addCommunity(commName, url, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latilongi[0].trim(), latilongi[1].trim(), geo);
			data.addPropertyType(ptype, dtype);
			data.addPropertyStatus(pStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(U.getnote(htm));

		}j++;
	}
}
