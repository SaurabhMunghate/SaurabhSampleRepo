/**
 * @author Pallavi
 * @date 25-Nov- 2018
 * 
 */
package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWilshireHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	private String baseUrl = "https://www.wilshire-homes.com";
	WebDriver driver=null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractWilshireHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"MHI-McGuyer Homebuilders - Wilshire Homes.csv", a	.data().printAll());
	}

	public ExtractWilshireHomes() throws Exception {

		super("MHI-McGuyer Homebuilders - Wilshire Homes","https://www.wilshire-homes.com/");
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Wilshire Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
//		driver = new FirefoxDriver();
		Proxy p=new Proxy();
		p.setHttpProxy("216.228.69.202:32170");
		p.setSslProxy("216.228.69.202:32170");
		//p.setNoProxy("no_proxy-var");
		
		DesiredCapabilities cap=new DesiredCapabilities().chrome();
		cap.setCapability("proxy", p);
		ChromeOptions options=new ChromeOptions();
		//options.addExtensions(new File("/home/shatam-17/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		//options.addArguments("–load-extension=" + new File("/home/shatam-17/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		cap.setCapability(ChromeOptions.CAPABILITY, options);
		driver=new ChromeDriver();

		
		
		
		Thread.sleep(5000);
		String html = getHtml(baseUrl,driver);
		String regionSection = U.getSectionValue(html, "Where We </span>Build", "</ul>");
		U.log(regionSection);
		String regionUrls[] = U.getValues(regionSection, "href=\"", "\">");
		for(String regionUrl : regionUrls){
			U.log(regionUrl);
			findCommunity(baseUrl+regionUrl);
		}
		
		driver.close();
		driver.quit();
		LOGGER.DisposeLogger();
	}
	private void findCommunity(String regionUrl)throws Exception{
		U.log("RegionUrl::"+regionUrl);
		String html = getHtml(regionUrl,driver);
		String commSec = U.getSectionValue(html, "<div class=\"communityContainer", "<span class=\"community\">Additional Locations</span>");
		U.log(U.getSectionValue(html, "<div class=\"communityContainer\"", "<span class=\"community\">Additional Locations</span>"));
		String[] communitySections = U.getValues(commSec, "<div class=\"itemListing\"", "</a></div>");
		U.log(communitySections.length);
		for(String communitySeciton : communitySections){
//			if(communitySeciton.contains("www.buildonyourlot-texas.com/locations/houston") || communitySeciton.contains("/designcenter"))continue;
			U.log("Community se"+communitySeciton);
			String communityUrl = U.getSectionValue(communitySeciton,"<a href=\"","\"");
			U.log("Community"+communityUrl);
			//if (communityUrl.equals("http"))return;
			String commHtml = getHtml(baseUrl+communityUrl,driver);
			U.log(U.getCache(baseUrl+communityUrl));
			//========== To Find Sub community ==============
			if(communityUrl.contains("/communities")){
				String comSec=U.getSectionValue(commHtml, "<h4><ul>","</ul></h4>");
				String[] subCommunitySections = U.getValues(comSec, "<li", "</li>");
				for(String subCommunitySection : subCommunitySections){
					String subCommunityUrl = U.getSectionValue(subCommunitySection, "<a href=\"", "\">");
					if(subCommunityUrl==null || subCommunityUrl.contains("portfolio"))continue;
					U.log("SubUrl:::::::"+subCommunityUrl);
					addInfo(baseUrl+subCommunityUrl, subCommunitySection+communitySeciton);
				}
			}else{
				if(communityUrl.contains("locations"))continue;
				addInfo(baseUrl+communityUrl, communitySeciton);
			}
		}
	}

	private void addInfo(String url, String lnk1) throws Exception {
//		if(url.contains("https://www.wilshire-homes.com/austin/new-homes-georgetown-tx-wolfranch-50ft"))
		{
			//TODO :
//	if (url.contains("https://www.wilshire-homes.com/austin/carnerosranch")) return;

//		if(!url.contains("https://www.wilshire-homes.com/austin/new-homes-georgetown-tx-wolfranch-51ft"))return;
		U.log("lnk1:::::::::::"+lnk1);
		
		if (url.contains("communities")	|| url.equalsIgnoreCase("https://www.wilshire-homes.com"))
			return;
		U.log("\n\nPAGE :" + url);
		
		String html = getHtml(url,driver);
		String allAvailHomeHtml="";
		String allFloorPlanHtml="";
		String tempHtml="";
		String rmSec=U.getSectionValue(html, "> Privacy Policy </a>. ", "</html");
		
		
//		if(rmSec!=null) {
//			html=html.replace(rmSec, "");
//		}
		String availHomeSecs[]=U.getValues(html, "<h3><a href=\""+url.replace("https://www.wilshire-homes.com", "")+"/home/", "\">");
		U.log("Total Home : "+availHomeSecs.length);
		for (String availUrl : availHomeSecs) {
				
				availUrl = url+"/home/"+availUrl;
				U.log("availUrl:"+availUrl);
				tempHtml=getHtml(availUrl,driver);
				allAvailHomeHtml += U.getSectionValue(tempHtml, "class=\"details\"", "</p>");
		}
		String floorplan=U.getSectionValue(html, "<div class=\"inventoryContainer\">", "<div class=\"tabItem\">");
		if(floorplan!=null) {
		String floorplanSecs[]=U.getValues(floorplan, "<div class=\"itemListing\"", "View Now");
		if (floorplanSecs.length>0) {
			for (String floorplanSec : floorplanSecs) {
				if (floorplanSec!=null) {
					floorplanSec=U.getSectionValue(floorplanSec, "href=\"", "\"");
					U.log("floorplanSec : "+floorplanSec);
					tempHtml=getHtml("https://www.wilshire-homes.com"+floorplanSec,driver);
					tempHtml=U.getSectionValue(tempHtml, "<div class=\"row home-stats\">", "class=\"four columns offset-by-one\"");
					if (tempHtml!=null) {
						allFloorPlanHtml=allFloorPlanHtml+tempHtml;
					}
				}
			}
		}}
		String rmsec = U.getSectionValue(html, "<script id=\"mhi-pub-state\"", "</htm");
		if(rmsec!=null)html = html.replace(rmsec, "");
		String newhtml=html;
		
		//========= CommName =============
		String commName = ALLOW_BLANK;
		
		String mainComName = U.getSectionValue(lnk1, "<h3><!---->", "/a>");
		if(mainComName!=null)
		commName = U.getSectionValue(mainComName, ">", "<");
		U.log("mainComName : "+mainComName);
		U.log("commName : "+commName);
//		if(commName == ALLOW_BLANK)commName =  U.getSectionValue(lnk1, ">", "</a");
		commName = commName.replace("@", "at");
		commName = commName.replaceAll(">|<", "").replace("&#39;", "'");
		if(commName==null ||commName==ALLOW_BLANK) {
		String parentName = U.getSectionValue(html, "<a id=\"project\">", "<");
		if(parentName==null)parentName ="";
		U.log("parentName : "+parentName);
		commName  = U.getSectionValue(html, "</h5><h1>", "<");
		U.log("commName : "+commName);
		
		if(!commName.contains(parentName)) {
			commName = parentName +" "+commName;
		}
		}
		//U.log("Name " + commName);
		//============= Notes =================
		String notes = U.getnote(html.replaceAll("offers new homes for sale|new homes for sale in |new homes for sale at|New homes for sale in", ""));
	
		
		//========= Lat Long =============
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, flag = "False";
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
		String lnk = U.getSectionValue(html,"<a href=\"http://maps.google.com", "target");
		
		if(lnk!=null){
//	        U.log("Map Link :" + lnk);
	        String latiSec = U.getSectionValue(lnk, "daddr=", "\"");
			String latLongi[] = latiSec.split(",");
			lat = latLongi[0];
			lng = latLongi[1];
		}
		 
		if(lnk==null){
			if(html.contains("daddr=")){
			String ink=U.getSectionValue(html,"daddr=","\"");
			String latLongi[] = ink.split(",");
			lat = latLongi[0];
			lng = latLongi[1];
			}
		}
		if(lng != null) lng = lng.replace("&q;", "");
		U.log("Lat:" + lat + " Long:" + lng);

		//=========== Address =======================
		

		String addr=ALLOW_BLANK;
		String addSec=U.getSectionValue(html, "fa fa-map-marker", "</p>");
		
		String addSection = null;
		if(addSec != null){
			
			addSection= U.getSectionValue(addSec, "<span>", "</a>");

			if(addSection != null)
				addSection = addSection.replaceAll("<br/>|<br />|<br>", ",").replaceAll("\\s{2,}|>|</span>", "").replace("TX", "TX ");
			U.log("addSection :: "+addSection);
		}
		if(addSec==null) {
			addSec=U.getSectionValue(html, "<p id=\"nomap\" class=\"address ng-star-inserted\" style=\"font-size: 1.25em;\"><span>", "</p><");
			addSection =addSec.replace("</span><br />", ",");
		}
//		add[0] = add[0].replaceAll("street ", "Street");
		if(addSection != null){
			add = U.getAddress(addSection);
		}
//		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"	+ add[3]);
		U.log("Address:::::: "+Arrays.toString(add));
		//taken from reg pg
/*		if(url.contains("https://www.wilshire-homes.com/austin/new-homes-hutto-tx-hutto-square")){
			lat = "30.55694";
			lng = "-97.553787";
		}*/
		/*if(url.contains("https://www.wilshire-homes.com/sanantonio/bricewood-45-homesites")){
			lat = "29.529129";
			lng = "-98.726794";
		}*/
		
		
		String[] latl={lat,lng};
		U.log(Arrays.toString(latl));
		
		if(lng!= null)
			lng = Util.match(lng, "-\\d{2}\\.\\d+");
		
		 if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK && lat != ALLOW_BLANK) {
				add=U.getAddressGoogleApi(latl);
				if(add == null) add = U.getGoogleAddressWithKey(latl);
				if(add == null) add = U.getAddressHereApi(latl);
				flag="TRUE";
		}
		if(add[0].length()==0)
		{
			add=U.getAddressGoogleApi(latl);
			if(add == null) add = U.getGoogleAddressWithKey(latl);
			if(add == null) add = U.getAddressHereApi(latl);
			flag="TRUE";
		}
		
		//==== Lat-Lng====
		String mapUrlSec = U.getSectionValue(html, "<p id=\"mapaddress\"", "<span class=");
		U.log(mapUrlSec);
		if(mapUrlSec != null){
			String mapUrl = U.getSectionValue(mapUrlSec, "_blank\" href=\"", "\"");
			if(mapUrl==null)mapUrl = U.getSectionValue(mapUrlSec, "_blank\" class=\"address\" href=\"", "\"");
			U.log("MapUrl-->"+mapUrl);
			
			String mapHtml = U.getHTML(mapUrl);
			String latLngSec = Util.match(mapHtml, ",\\[\"0x0:0x(.*?)\",null,null,\\[null,null,(\\d+\\.\\d+,\\-\\d+\\.\\d+)\\]");
			U.log(latLngSec);
			if(latLngSec != null){
				latLngSec = Util.match(latLngSec, "(\\d+\\.\\d+,\\-\\d+\\.\\d+)");
				U.log(latLngSec);
				if(latLngSec != null){
					String latLng[] = latLngSec.split(",");
					if(latLng != null && latLng[0] != null && latLng[1] != null){
						lat = latLng[0];
						lng = latLng[1];
						flag = "True"; //Since latlng not visible on the page
					}
				}				
			}
		}
		
		
		if (lat== ALLOW_BLANK) {
			String latLongi[] ={lat,lng};
			latLongi= U.getlatlongGoogleApi(add);
			if(latLongi == null) latLongi = U.getlatlongHereApi(add);
			U.log("latlong" + latLongi[0]);
			U.log("latlong" + latLongi[1]);
			lat=latLongi[0];
			lng=latLongi[1];
			flag= "TRUE";
		}
		 
			
			 
//		 if(url.contains("https://www.wilshire-homes.com/sanantonio/new-homes-new-braunfels-tx-pecan-crossing-60ft")){flag="TRUE";}
//		 U.log("add:"+add[0]+"streed:"+add[1]+"state"+add[2]+"code"+add[3]);
		
        /***********************SQUARE FEET******************/
		html = html.replaceAll("(\\$\\d+)'s", "$1,000s").replaceAll("tar-inserted\">\\$\\d{3},\\d{3}</span>", "");
		html = html.replaceAll(	"<span class=\"strikethrough\">\\s+\\$\\d+,\\d+</span>", "").replaceAll("$240,000s in 22 area developments|$240,000s in 22 area developments", "");
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(	html,
						"\\d,\\d{3} sq. ft. - \\d,\\d{3} sq. ft.|\\d{4} - \\d{4} Sq. Ft|\\d{4} to \\d{4} sq. ft|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft|Sq Ft: <strong> \\d+|\\d+ sqft|from \\d+ sq ft to \\d+ sq ft.|\\d+ sq. ft. to \\d+ sq. ft.",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		/**********************Price Section****************/
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String remSec = U.getSectionValue(html, "<h2 class=\"news-title\">Latest News</h2>", " <div class=\"element\">");
		U.log(remSec);
		if(remSec!=null)
			html = html.replace(remSec, "");
		html = html.replaceAll("with pricing from the \\$380,000s. Parent company MHIs|from the $240,000s.", "");
		html = html.replaceAll("0's|0’s|0s", "0,000").replace("From the $290's ", "From the $290,000");
		html =html.replaceAll("strikethrough\">\\$(\\d,)*\\d+,\\d+", "");
		String secPrice = U.getSectionValue(html, "<h3>Nearby Communities</h3>", "</html>");
		html = html.replace(secPrice, "").replaceAll("the $240,000", "");
		String[] price = U.getPrices( html,
						"From the \\$\\d{3},\\d{3}|from the Upper \\$\\d{3},\\d{3}|<div class=\"price\">\\$(\\d,)*\\d{3},\\d{3}</div>|\\$(\\d,)*\\d+,\\d+</span>|price\">\\s*\\$(\\d,)*\\d+,\\d+</div>|</span>\\$(\\d,)*\\d+,\\d+</div>|->\\$(\\d,)*\\d+,\\d+</div>|From the \\$\\d+,\\d+|beginning in the \\$\\d+,\\d+|low \\d{3},\\d{3}|\\$\\d{3},\\d{3}</div><h3>",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		//U.log(html);
		// ======== Property Type =============== 
		if(rmSec!=null) {
//			U.log(rmSec);
			newhtml=newhtml.replace(rmSec, "").replaceAll("<script id=\"app-root-state(.*?)}}</script>", "");
		}
//		if(rmSec!=null) {
//			allFloorPlanHtml=allFloorPlanHtml.replace(rmSec, "").replaceAll("<script id=\"app-root-state(.*?)}}</script>", "");
//		}
//		if(rmSec!=null) {
//			allAvailHomeHtml=allAvailHomeHtml.replace(rmSec, "").replaceAll("<script id=\"app-root-state(.*?)}}</script>", "");
//		}

		String pType = ALLOW_BLANK;
	    html=html.replaceAll("$25K more than traditional homes|within the Paloma Lake community|Carriage style|world-class community center with luxury amenities, including|Luxurious Baths|Luxurious garden", "");
	    allFloorPlanHtml=U.removeSectionValue(allFloorPlanHtml, "<h2 class=\"news-title\">Latest News</h2>", ">Read More News");
	    allAvailHomeHtml=U.removeSectionValue(allAvailHomeHtml, "<h2 class=\"news-title\">Latest News</h2>", ">Read More News");
		html=html.replaceAll("and patio|back patio|Rear Patio|Outdoor Patio|HOAInformation","");
		newhtml=newhtml.replaceAll("> Executive Series</span></h3>|Courtyard - The Bellville|alt='Courtyard|Steel carriage garage|world-class community center with luxury amenities, including|Luxurious Baths|Luxurious garden|Rear Patio|covered patio|Outdoor Patio|HOAInformation","");
	
		//String nayahtml=U.getHTML(url);
		//U.log(U.getSectionValue(newhtml, "Community Overview", "Schools</h2>")+"::::::::::::::::::::::::");
		if(newhtml.contains("HOA Fees information not available at this time")) {
		   newhtml=newhtml.replaceAll("HOA|hoa", "");
		}
		
		
		newhtml=newhtml.replaceAll("25k-more-than-traditional-homes| $25K more than traditional homes,|$25K more than traditional homes|carriage style|Carriage style|patio or even a new tele","");
		newhtml=U.removeSectionValue(newhtml, "<h2 class=\"news-title\">Latest News</h2>", ">Read More News");

		pType = U.getPropType((newhtml+allFloorPlanHtml+allAvailHomeHtml).replaceAll("luxurious master suite complete with a window seat|luxuries this home has|showcase the five garden home designs", ""));
		
		// ========== Derived Community Type =============
	    html=html.replace("one-and-a-half and two-story","1.5 Story,2 Story");
	    html=html.replace("Stories: 2.0","Story 2");
	    html=html.replace("Stories: 1.0","1 Story");   
 	    String derivedPType = U.getdCommType(html.replaceAll("1890 Ranch,|Rancho|Ranch Market|199265_wolf_ranch_wilshire008.jpg", " ")+commName);
		//U.log(">>>>>>>>>>>>>123"+derivedPType);

 	    //============= Community Type ================
 	    html = html.replaceAll("750-acre master planned community|ound in top-ranked master-planned communities throughout Texas|t 750-acre master-planned community in the|Tx. Paloma Lake is Round Rock’s newest 750 acre master planned community and is |master bath|within the Paloma Lake community|master walk-in|master closet(s)|master closets|master bedroom|Elongated", "");
		String rem=U.getSectionValue(html, "<head id=\"Head1\"><title>", "<!-- Basic Page Needs");
		if(rem!=null)
			html=html.replace(rem, "");
		
		String Type = U.getCommunityType(html);

		//============= Property Status ================
		String commStatus = ALLOW_BLANK;

		String statusSec = U.getHTML(url);
		//========== Remove Section of News Article ===========
		String rem1 = U.getSectionValue(statusSec, "<div class=\"NewsArticleText\">", "</div>");
		if(rem1 != null)
			statusSec = statusSec.replace(rem1, "");
		rem1 = U.getSectionValue(statusSec, "<script id=\"mhi-pub-state\"", "</html");
		if(rem1 != null)
		statusSec = statusSec.replace(rem1, "");		
		//U.log("statusSec:::::::::::::"+statusSec);
		String remove = "70’ Homesites Now Available|Bike Trails Now Open|splash pad now open|Elementary, set to open fall 2020|School set to open Fall 2020|Ranch Elementary - Coming Fall 2020|under construction or ready for move-in|learn more about the new homes available|ready for sale in Round Rock,|Grand Opening and Sales|under construction|Model Now Open|Now Selling in Schertz|New Model Now Open|HOA information not available at this time|over 50% sold out|divCloseOutCommunity|currently under construction at the Woodside|CENTER NOW OPEN|center coming soon|Now Open:|New Model Now Open!|Coming Soon Contact|Plans and pricing coming soon|Exciting Floor Plans Coming Soon!";
		statusSec = statusSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		html=html.replaceAll("(Summer 2017)","");
		statusSec=statusSec.replaceAll("(Summer 2017)","");
		lnk1=lnk1.replaceAll("Day Dock Coming 2019|under construction or ready for move-in|\\(Summer 2017\\)","");
		statusSec=statusSec.replaceAll("new wooded section now open!","New Section Now Open!");
		statusSec=statusSec.replace("burkburnett ii is now open at 20525 martin lane", "").replace("new section - coming soon","New Section Coming Soon");
		
		statusSec = statusSec.replaceAll("day dock coming 2019|coming soon|Model Now Open", "");
		statusSec = statusSec.replaceAll("move-in ready|last opportunities in", "");
		statusSec = statusSec.replaceAll("launch coming fall 2018|coming fall 2020|touts final opportunities in bricewood|pad now open|trails now open|offers new homes for sale|New Model Now Open!|grand opening event|homesites now available in|receive Grand Opening and Sales|sites available in schertz|about the new homes available in paloma lake.</p>", "");
//		U.log("statusSec:::::::::::::"+statusSec);
		statusSec=U.removeSectionValue(statusSec, "learn more about", "</p>");
		String scrollerSec=U.getSectionValue(html, "<div class=\"slick-list draggable\" style=\"padding: 0px 50px;\">", "</div></div></div><");
		if(statusSec==null)statusSec=ALLOW_BLANK;
//		U.log("MMM "+Util.matchAll(statusSec+scrollerSec+lnk1, "[\\s\\w\\W]{30}Now Open[\\s\\w\\W]{30}", 0));

		
		commStatus = U.getPropStatus((scrollerSec.replaceAll("Quick Move|70’ Homesites Now Available|Bike Trails Now Open|Day Dock Coming 2019", "").replace("Oversized/Greenbelt Homesites Available", "Oversized Greenbelt Homesites Available").replace("Oversized, Greenbelt Homesites", "Oversized Greenbelt Homesites")+statusSec.replace("Cul-de-Sac Lots Available".toLowerCase(), "")
		+lnk1.replace("pricing coming soon", "")).replaceAll("metroquandrantdiv(.*)</script", ""));
		commStatus=commStatus.replace("", "");
		
		commStatus = commStatus.replace("Close-out", "Close Out");
		if(lng!=null)
		lng=lng.replaceAll("-97.8961860000&q;|-97.8961860000&amp;q;", "-97.8961860000");
		
		
		add[0]=add[0].replace("6360-","");
		if (data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl("reopeat===" +url);
			return;
		}
			
		LOGGER.AddCommunityUrl(url);
		if(add[0].trim().length()<4)
		{
			String[] a={lat,lng};
			String add1[] = U.getAddressGoogleApi(a);
			if(add1 == null) add1 = U.getGoogleAddressWithKey(a);
			if(add1 == null) add1 = U.getAddressHereApi(a);
			add[0]=add1[0];
			flag="TRUE";
		}
		
/*		if(url.contains("/austin/carnerosranch")){
			commStatus="Move-in Ready Homes Available";
		}*/
		
		commStatus = commStatus.replace("Move-in Ready Homes Available", "Ready Now Homes");
		
		if (allAvailHomeHtml.contains("Ready Now")) {
			
			/*if (commStatus.length()>2&& !commStatus.contains("Move-in Ready")) {
				commStatus+=", Move-in Ready Homes";
			}else if (!commStatus.contains("Move-in Ready")) {
				commStatus="Move-in Ready Homes";
			}*/
			if (commStatus.length()>2&& !commStatus.contains("Move-in Ready")) {
				commStatus+=", Ready Now Homes";
			}else if (!commStatus.contains("Move-in Ready")) {
				commStatus="Ready Now Homes";
			}
		}
		
		commStatus = commStatus.replaceAll("Quick Move-in Homes,|Quick Move-in Homes", "");
		if(commStatus.length()<2)commStatus=ALLOW_BLANK;		
		U.log(lat+"MMMMMMMMMM"+lng);
//		if(add[2].length()>2)add[2]=ALLOW_BLANK;
		if(add[2].contains("TX"))add[2]="TX";
		add[0] = add[0].replaceAll("Visit our sales trailer in Foxbrook: <br> |Please visit us at our Foxbrook sales trailer <br>", "");
		U.log("GeoCode:::::::"+flag);
		U.log("State::"+add[2]);
		data.addCommunity(U.getCapitalise(commName), url, Type);
		data.addAddress(add[0].trim(), add[1].trim(),add[2], add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.replace("&amp;q;", "").trim(), lng.replace("&amp;q;", "").trim(), flag);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(commStatus);
		data.addNotes(notes);
		}
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					U.log("before::::"+url);
					driver.get(url);
					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					Thread.sleep(5000);
					html = driver.getPageSource();
					
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
//			driver.quit();
			return html;
		}
		// else{
		// return null;
		// }
	}

}
