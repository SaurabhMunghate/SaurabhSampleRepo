/**@ Modification Rakesh.
@author Parag Humane
 * @date 16/05/2012
 */
package com.shatam.b_061_080;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.util.StringUtils;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

import bsh.StringUtil;

public class ExtractChesmarHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractChesmarHomes();
		a.process();
		// a.data().printAll();  
		FileUtil.writeAllText(U.getCachePath() + "Chesmar Homes.csv", a.data().printAll());
	}

	public ExtractChesmarHomes() throws Exception {

		super("Chesmar Homes", "https://chesmar.com/");
		LOGGER = new CommunityLogger("Chesmar Homes");
	}

	public void innerProcess() throws Exception {

		U.setUpChromePath();
		driver = new ChromeDriver();
		String html = U.getHtml("https://chesmar.com",driver);
//		U.log(html);
		String sec = U.getSectionValue(html, " Explore Our Locations            </h1>", "<div class=\"exp-slide");
//		U.log(sec);
		String[] values = U.getValues(sec, "<a href=\"", "\"");
		String name, url;
		int i = 0;
		for (String regionUrl : values) {
			U.log(regionUrl);
//			try {
				GetCommUrl(regionUrl);
//			} catch (Exception e) {}
			i++;
			//break;
		}

		LOGGER.DisposeLogger();
		try{driver.close();driver.quit();}catch (Exception e) {}
		U.log("Count >>>>>>" + count);
	}

	int count = 0;

	private void GetCommUrl(String regUrl) throws Exception {
		int i = 0;
		// regUrl = "http://www.chesmar.com/communities/houston";
		String html = getWebHtml(regUrl,driver);

//		String RegHomeUrl=U.getSectionValue(html, "menu-item-object-page menu-item-5738\"><a href=\"", "\"");
//		html=getWebHtml(RegHomeUrl, driver);
		
//		String[] addSection = U.getValues(html, "<div class=\"listing-info\">","<div class=\"white heart-icon\">");//"</li></ul></div></div>");
		String[] addSection = U.getValues(html, "<div class=\"info-block\">","<div id");
//		if(!regUrl.contains("antonio"))return;
		U.log(addSection.length);
		
		for (String comSec : addSection) {
			//U.log(comSec);
			String communityUrl = U.getSectionValue(comSec, "class=\"listing-title\"><a href=\"", "\"");
			String comName=U.getSectionValue(comSec, "blank\">","</a>").trim();
			//U.log(count+"\t::::::::::"+communityUrl+"\t"+comName);
			addDetails(communityUrl, comSec,comName);
			count++;  
		}

	}

	int j = 0;

	private void addDetails(String communityUrl, String comSec,String commName) throws Exception {
		{
			//try{
//			if(j>=80)
			{
				//U.log(comSec);
				String commUrl = communityUrl;
		//TODO:============================= Single Run =====================================
//				if(!commUrl.contains("https://chesmar.com/communities/august-fields/")) return;
				
				//U.log("MainData>>>" + dataa);
				U.log(j+"\t::::::::::Page:" + commUrl + "\n com name : " + commName + "::::::::");
				if (data.communityUrlExists(commUrl)) {
					LOGGER.AddCommunityUrl("-------Repeated-------" + commUrl);
					return;
				}
				U.log("Community Url:\t" + commUrl);
				LOGGER.AddCommunityUrl(commUrl);
				commName=commName.replaceAll("at Mansfield|New Homes in|Paired Villas", "");
				if(commName.endsWith("Villas"))commName=commName.replace("Villas", "");
				String html = getWebHtml(commUrl, driver);
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
				String flag = "FALSE";
				String note="";
				if(commUrl.contains("https://chesmar.com/communities/regent-park/")) {
					add[1]=U.getSectionValue(html, "City: <span class=\"community-list-bold\">", "</span>");
					add[2]="San Antonio";
					latLong=U.getGoogleLatLngWithKey(add);
					add = U.getGoogleAddressWithKey(latLong);
					flag="TRUE";
					note="Address & Latlng Taken From City And State";
				}
				else {
				String addSec=U.getSectionValue(html, "https://www.google.com/maps/place/", "\">");
				U.log(addSec);
				
				if(commUrl.contains("https://chesmar.com/communities/august-fields/")) {
					addSec=U.getSectionValue(html, "TX 78130, USA\">", "</a>");
					U.log("addSec>> "+addSec);
				}//addSec==null && 
				
				if(addSec!=null) {
					addSec=addSec.replace("4742 Franklin Way, Iowa Colony, TX, 77583, USA", "4742 Franklin Way, Iowa Colony, TX 77583").replace("2991 Enz New Braunfels", "2991 Enz, New Braunfels").replaceAll(", USA\" data-ce-key=\"\\d+|,\\s*USA", "").replace("McKinney TX,", "McKinney, TX").replace("Buda", ", Buda").replace("TX, 78681", "TX 78681").replace("TX, 78626", "TX 78626").replaceAll("TX, 78253", "TX 78253").replaceAll("TX, 77386 USA", "TX  77386").replace("TX, 76063 USA", "TX 76063").replace("TX, 77386", "TX 77386").replace("TX, 77583, USA", "TX 77583")
							.replace("TX 78610, USA", "TX 78610").replace("TX, 77583, USA", "TX 77583").replace("3410 Harolds Hill Marion TX", "3410 Harolds Hill, Marion, TX")
							.replace("Texas, 75078", "TX 75078").replace("Homestead Community, Texas,", "").replace("The Woods of Garden Ridge by Chesmar Homes,", "")
							.replace("Drive Hutto", "Drive, Hutto").replace("TX, 78634", "TX 78634").replace("TX, 77493", "TX 77493")
							.replace("Manor Commons, Farm to Market Road 973", "");				
					
					String[] add1 = U.getAddress(addSec);
					
					if (add1!=null) {
						add=add1;
					}
				}
				

				
				U.log("Addrss::::"+Arrays.toString(add));
				String latSec=U.getSectionValue(html, "var php_vars = {\"", "};");
				if(latSec!=null) {
					latLong[0]=U.getSectionValue(latSec, "oglat\":\"", "\"");
					latLong[1]=U.getSectionValue(latSec, "oglong\":\"", "\"");
				}
			
//				if(commUrl.contains("https://chesmar.com/communities/lago-mar/")) 
//				{
//					add = new String[] {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
//					add[1]= "Texas City";
//					add[2]="Texas";
//					latLong=U.getGoogleLatLngWithKey(add);
//
//					add = U.getGoogleAddressWithKey(latLong);
//					flag="TRUE";
//					note="Address & Latlng Taken From City And State";
//				}
				U.log(add[0]+"  "+latLong[0]);
				if(add[0].length()<4 && latLong[0].length()<4)
				{
					add[1]=U.getSectionValue(html, "City: <span class=\"community-list-bold\">", "</span>");
					add[2]="TX";
					latLong=U.getlatlongGoogleApi(add);
					if(latLong == null)
						latLong = U.getGoogleLatLngWithKey(add);
					
					flag="TRUE";
					note="Address Taken From City And State";
				}
				
				if(add[2]==null) {
					add[2] = "Missouri City";
				}
				U.log(add[2]);
				if(add[2].length()>4 && latLong[0]==null) {
					latLong=U.getlatlongGoogleApi(add);
					if(latLong == null)
						latLong = U.getGoogleLatLngWithKey(add);
					flag="TRUE";
							
				}
				if(add[2].length()>4 && latLong[0].length()<4) {
					latLong=U.getlatlongGoogleApi(add);
					if(latLong == null)
						latLong = U.getGoogleLatLngWithKey(add);
					flag="TRUE";
					
				}
				if((add[0].length()<4 ||add[3].length()<4)&& latLong[0].length()>4) {

					String[] add1=U.getAddressGoogleApi(latLong);
					if(add1 == null)
						add1 = U.getGoogleAddressWithKey(latLong);
					if(add[0].length()<4)
						add[0] = add1[0];
					if(add[1]==null || add[1].length()<4)
						add[1] = add1[1];
					if(add[3].length()<4)
						add[3] = add1[3];
					if(add[2].length()<2)
						add[2] = add1[2];

					
					flag="TRUE";
				}}
				U.log("address:- " + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
				U.log("Latlong:- " + latLong[0] + " " + latLong[1]);
				add[0]  =add[0].replaceAll("^Chesmar Homes at Savannah, |The Woods of Garden Ridge by Chesmar Homes,", "")
						.replace("Trail, Road", "Trail Road");
				
				
				String[] planUrls = U.getValues(html, "<div class=\"listing-title\"><a href=\"", "\">");
				String allPlanData = "";
				U.log("Total Plan : "+planUrls.length);
					for (String purl : planUrls) {
//						U.log("Plan::::::"+purl);    //Plan::::::https://chesmar.com/floor-plans/madera-at-cibolo-canyons/brandon-9/
						try {
						String planHtml =  U.getHTML(purl);
//						if(planHtml.contains("story 4")) {
//							U.log("found");
//						}
						allPlanData += U.getSectionValue(planHtml, "site-content", "Prices and square footage are subject to change")+U.getSectionValue(planHtml, "<div class=\"entry-content\">", "</p>");}
						
						
						catch(Exception e) {}
					}
				//}

				html = html.replaceAll("<span class=\"community-list-bold\">", "").replace("mid $400s", "Starting From: $400,000");
				allPlanData = allPlanData.replaceAll("<span class=\"community-list-bold\">", "");

				// =====================================================================================================================
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(html + allPlanData + comSec,
						"feature \\d,\\d+ to over \\d,\\d+ sq ft|Sq Foot Range:\\s*\\d,\\d+-\\d,\\d+</span>|from \\d,\\d{3} sqft to over \\d,\\d{3} sqft|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d{3}\\s*-\\s*\\d,\\d{3}</span>|\\d,\\d{3} - \\d,\\d{3}</span>|Sq Foot Range:\\s*(\\d,)*\\d+\\s*-\\s*(\\d,)*\\d+|Sq Foot\\s*:\\s*(\\d,)*\\d+|range from \\d,\\d{3} sq. ft|over \\d,\\d{3} sq. ft|<div class=\"listing-icon-text\">\\d,\\d{3}",
						0);
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//				U.log(Util.matchAll(comSec, "[\\s\\W\\w]{30}1,297[\\s\\W\\w]{30}", 0));
				// =========================================================================================================================
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				html=html.replaceAll("0s|0's", "0,000");
				String[] price = U.getPrices(html + allPlanData + comSec,
						"<span class=\"community-list-bold\">\\$\\d{3},\\d{3}</span>|Starting From: \\$\\d{3},\\d{3}|Starting From:\\s*\\$\\d{3},\\d{3}|price\">\\$\\d{3},\\d{3}</div>|<div class=\"listing-2-price\" data-ce-key=\"\\d+\">\\$\\d{3},\\d{3}",
						0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
				
				// ============================================================================================================================
				html= html
						.replace(" luxurious course lifestyle", " luxury homes course lifestyle")
						.replace("luxury â€œlock and leaveâ€� home concept", "luxury homes â€œlock and leaveâ€� home concept")
						.replace("luxury, ease,", "luxury home").replaceAll("Traditional and Renewable Energy|hoa_dues|label for=\"hoa_dues\"|Single Family &amp; Townhomes\">Single Family &amp; Townhomes|Single Family Home</a></li>|Single-family Homes for Sale San Antonio|>Single Family House San Antonio</a>|single-family-", "");
				html=html.replaceAll("Paired Ã¢â‚¬Å“VillasÃ¢â‚¬ï¿½|Townhomes vs. Sin|Single &amp; Townhome|wnhome\">Townhome</li>|rel=\"Condo\">Condo|covered patio", "paired patio").replaceAll("value=\".*\">.*</option>|<a href=\"(.*?)</l>", "");
				String pType = U.getPropType((html + allPlanData).replaceAll("game room, a paired patio, and more|li paired patio|<li paired patio|Texas-size rear paired patios|Topaired patio|<li rel=\".*\">|value=\".*\">.*</option>|HOA Dues|hoa_dues|<a href=\"(.*?)\">.*</a></li>", ""));
				U.log(pType);
//				U.log(Util.matchAll(html + allPlanData, "[\\s\\W\\w]{30}custom home[\\s\\W\\w]{30}", 0));
				// ===============================================================================================================================
				
				html = html.replace("one-and-a-half and two-story homes", "one-and-a-half story and two-story homes").replace("1.5-story", "1.5--story");
				allPlanData=allPlanData.replace("1.5-story", "1.5--story");
				String derivedPType = U.getdCommType((html + allPlanData.replace(" 2 story 4 bed", " 2 story, 4 bed")).replaceAll("Ranch Rd|Ranch Road", ""));
//				U.log(Util.matchAll(html + allPlanData, "[\\s\\W\\w]{30}5-story[\\s\\W\\w]{30}", 0));
//				U.log("derivedPType: "+derivedPType);
				
				// =======================Property Status==========================================================================================================
				html =html.replace("New Phase! Limited Release", "New Phase Limited Release")
						.replace("Coming Fall of 2022", "Coming Fall 2022")
						.replace("NEW SINGLE-FAMILY SECTION NOW OPEN FOR SALE", "New Section Now Open FOR SALE")	
						.replaceAll("<em>coming soon</em></strong> in the near|out of our first section|now open for tours|<div class=\"reduced\">Last Chance</div>|Opening June 2018\\s*<br>|Opening June 2018<br /> |\"Quick Move-In\"|quick move-in's|Quick|>Quick Move-in<|ruction - Coming Soon|Ready|Move in Ready Homes | Lagoon Ã¢â‚¬â€œ Coming Soon|Coming-Soon-|comingsoon_commu|reduced\">Coming Soon</div|opening events", "")
						.replace("NEW SECTION WITH WATER VIEWS COMING SOON", "NEW SECTION COMING SOON").replace("NEW SECTION<em> ", "New Section ")
						.replace("Coming Soon in August", "").replace("Coming Spring of 2022", "Coming Spring 2022");
				comSec=comSec.replaceAll("Opening June 2018\\s*<br>|ruction - Coming Soon| Lagoon Ã¢â‚¬â€œ Coming Soon|Coming-Soon-|comingsoon_commu|ready|Ready|Quick", "");
				
				

				String propstatus = U.getPropStatus((html + comSec).replaceAll("comingsoon_community.jpg|Model Open, Now Selling|<div class=\"reduced\">Coming Soon</div>|Two New Models – Now Open|Models â€“ Now Open|These homes are selling fast|enter(s)?( is)? now", ""));			
				//-------quick status------
//			U.log("ssssssssssssss:"+Util.matchAll(html, "[\\s\\W\\w]{30}Coming Soon[\\s\\W\\w]{30}", 0));
//				U.log("ssssssssssssss:"+Util.matchAll(comSec, "[\\s\\W\\w]{30}Coming Soon[\\s\\W\\w]{30}", 0));

				//U.log(html.contains("target=\"_blank\" class=\"plan-movin-") && !propstatus.contains("Quick"));
				U.log("propstatus: "+propstatus);
				if(html.contains("class=\"plan-movin-link\">") && !propstatus.contains("Quick")){
					propstatus=propstatus.replaceAll("Ready To Move In,| Move In Ready Home,|Quick Move-in, |, Quick Move-in", "");
					if(propstatus.length()<4) propstatus = "Quick Move-in";
					else propstatus = propstatus + ", Quick Move-in";
				}
				
				
				if(commUrl.contains("/communities/sweetwater/"))propstatus ="Coming Soon";//image
				
				if(comSec.contains("<div class=\"reduced\">Coming Soon</div>") && !propstatus.contains("Coming Soon"))
					if(propstatus==ALLOW_BLANK)
						propstatus = "Coming Soon";
					else
						propstatus+=", Coming Soon";
				
				//if(commUrl.contains("https://chesmar.com/communities/venetian-pines/"))propstatus="Coming Soon";
//				if(commUrl.contains("https://chesmar.com/communities/brooklands/"))propstatus ="Coming Soon";//image
//				if(commUrl.contains("communities/somerset-at-mansfield/"))propstatus = propstatus.replace(", Coming Soon", "");
				// ==============================================================================================================================
				html = html.replaceAll("Planned Communities Worth|What Is a Master|Planned Community</a>|New Community \\(Master", "");
				html=html.replace(" lakefront entrance", "lakefront home sites");
				String commType = U.getCommType((html + comSec).replaceAll("Elongated|Love Living in a Master Planned Community|Master Planned Communities Worth It\\?|Master Planned Community\\?|master-planned-communit|Westlake [c|C]ommunity|Is a Master Planned Community|Are Master Planned Communities Worth", ""));
				// ==============================================================================================================================

				if(commUrl.contains("https://chesmar.com/communities/sienna-plantation/")) {
					add[0] = "8707 Azalea Crossing Court";
					add[1] = "Missouri City";
					add[2] = "TX";
					add[3] = "77459";
				}
				
				if(commUrl.contains("https://chesmar.com/communities/copper-branch/")) {
					add[0] = "14827 Arnold Palmer";
					add[1] = "San Antonio";
					add[2] = "TX";
					add[3] = "78217";
				}
				if(commUrl.contains("https://chesmar.com/communities/meridiana/")) {
					add[1]="Iowa Colony";
					flag="FALSE";
				}
				if(commUrl.contains("https://chesmar.com/communities/copper-branch/"))add[0]="14823 Palmer Creek";
				U.log(Arrays.toString(add));
/*				if(commUrl.contains("https://chesmar.com/communities/sienna-plantation/"))maxPrice="$402,990";
				if(commUrl.contains("stone-creek"))propstatus="Coming Soon July/August";
*/				
//				if(commUrl.contains("/communities/bridgeland/"))propstatus=propstatus+", New Section Now Open";

				html = html.replaceAll("SECTION NOW OPEN FOR SALE!","");
				propstatus=propstatus.replace("New Phase Now Open, Now Open", "New Phase Now Open");
				
				// ------------------------- Number of Units ---------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				
				data.addCommunity(commName, commUrl, commType);
				data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
				data.addSquareFeet(minSqf, maxSqf);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), flag);
				data.addPropertyType(pType, derivedPType);
				data.addPropertyStatus(propstatus.replace("Ii", "II"));
				data.addNotes(U.getnote(html));
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
			}
			j++;
			//}catch (Exception e) {}
		}

	
	}
	
	public static String getWebHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();

		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.get(url);
					// U.log("after::::"+url);
					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					Thread.sleep(2000);
					// U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					// Thread.sleep(2000);
					writer.append(html);
//					//-------below code is to click on next page button on region page------
					if(html.contains("<a href=\"#\">2</a>"))
					{
						try{
						WebElement click = driver.findElement(By.xpath("//*[@id=\"defineheight\"]/div/div[3]/span[3]/a")); 
						click.click();
						U.log("Click Success");
						html = html+driver.getPageSource();
						writer.append(html);
						}catch(Exception e){U.log("-----UnSuccessfull region load more button---------");};
					}
					Thread.sleep(4000);
					//-------below code is to get quick homes data of community------
					if(url.contains("communities")){
					if(html.contains("<span>Quick Move-in</span>"))
					{
						WebElement click = driver.findElement(By.xpath("//*[@id=\"primary\"]/div/div[2]/div/div[1]/a[2]")); //quick tab
						click.click();
						Thread.sleep(3000);
						U.log("Quick Homes Click Success");
						String myhtml = driver.getPageSource();
						html += U.getSectionValue(myhtml, "home-search-results", "<style>");
						writer.append(html);
					}
					Thread.sleep(2000);
					
					//-------below code is to get model homes data of community------
					if(html.contains("<span>Model Homes</span>"))
					{
						WebElement click = driver.findElement(By.xpath("//*[@id=\"primary\"]/div/div[2]/div/div[1]/a[3]")); //quick tab
						click.click();
						Thread.sleep(3000);
						U.log("Model Homes Click Success");
						String myhtml = driver.getPageSource();
						html += U.getSectionValue(myhtml, "home-search-results", "<style>");
						writer.append(html);
					}
					}
					Thread.sleep(2000);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}


}