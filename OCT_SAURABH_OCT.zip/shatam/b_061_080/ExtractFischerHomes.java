package com.shatam.b_061_080;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.bcel.generic.ALOAD;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
//import com.shatam.b_021_040.Brookfield;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFischerHomes extends AbstractScrapper {
	static CommunityLogger LOGGER;
	static int i=0;
	
	public ExtractFischerHomes() throws Exception {
		super("Fischer Homes", "https://www.fischerhomes.com");
		LOGGER = new CommunityLogger("Fischer Homes");
	}

	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new ExtractFischerHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Fischer Homes.csv", a.data().printAll());	
	}
	
	static MultiValueMap regionsData = new MultiValueMap();
	
	@Override
	protected void innerProcess() throws Exception {
		long startTime = System.currentTimeMillis();
		
		String regionsHtml = U.getHTML("https://www.fischerhomes.com/directive/dropdown-regional");
		String reg[] = U.getValues(regionsHtml, "<a href=\"", "\">");
		//U.log(reg.length);

		for(String rU:reg) {
		U.log(rU);
			String regUrl = "https://www.fischerhomes.com"+rU+"?json=true";
			U.log("regUrl: "+regUrl);
			String regJsonData = U.getHTML(regUrl);

//SINGLE RUN FOR REGION			
//			if(regUrl.equals("https://www.fischerhomes.com/find-new-homes/indianapolis/indiana/communities?json=true")) { 
				
			//For community data from Region page
				JsonParser json = new JsonParser();
				JsonObject objJson = (JsonObject)json.parse(regJsonData); 
				JsonObject regObj = (JsonObject)objJson.get("region");
				
				JsonArray comarray = new JsonArray();		
				comarray = (JsonArray)regObj.getAsJsonArray("communities");
				U.log("Total Com. on region page: "+comarray.size());
				for(int i = 0; i < comarray.size(); i++) {
					String regComData = comarray.get(i).toString();	
					String comIdFromReg = U.getSectionValue(regComData, "\"id\":", ",\"");
					//U.log("comIdFromReg: "+comIdFromReg);
					
					regionsData.put(comIdFromReg, regComData);
				}
				//U.log("regionsData size: "+regionsData.size());
				
			U.log("regJson Cache: "+U.getCache(regUrl));
			regJsonData = regJsonData+"]}]}";
					
			String jsonSec[] = U.getValues(regJsonData, "{\"id\":", "\"image\":{");
			U.log("jsonSec.length: "+jsonSec.length);
			
			for(String js:jsonSec) {
				//U.log(js);
				addDetails(js);
			}
//		}
//			else {
//				continue;
//			}
		}
		LOGGER.DisposeLogger();
		U.log("Time Taken: "+(System.currentTimeMillis() - startTime));
	}
	
	
	public static void addDetails(String regJson) throws Exception {
		
		String comUrl = "https://www.fischerhomes.com"+U.getSectionValue(regJson, "\"url\":\"", "\"").replace("\\", "");
		U.log(" "+i+" comUrl: "+comUrl);
		
//SINGLE EXECUTION
//		if(!comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/790/scioto-landing/")) return;
		
//		if(i>=125) {
		
		String jsonUrl = comUrl + "overview?json=true";
		
		if(comUrl.contains("/communities/270/bridle-creek-ranch/")) {
			jsonUrl = comUrl + "?json=true";
		}

		String comHtml = U.getHTML(jsonUrl);
		String comHtml2 = U.getHTML(comUrl);
		
		comHtml2=U.removeSectionValue(comHtml2, "<header", "</header>");
		
		U.log("regJson: "+regJson);
		U.log("comUrl: "+comUrl);
		U.log("comHtml JsonUrl: "+jsonUrl);
		U.log("Community Cache: "+U.getCache(comUrl + "overview?json=true"));
		
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"----------------------------------------Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

		//=========== Community Name
		String comName = U.getSectionValue(comHtml, "\"name\":\"", "\"");
		U.log("comName: "+comName);

		//=========== Address and LatLng
		String add[]= { ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK };
		String latlng[]= { ALLOW_BLANK,ALLOW_BLANK };
		String geo="FALSE";
		
		latlng[0] = U.getSectionValue(comHtml, "\"latitude\":\"", "\",");
		latlng[1] = U.getSectionValue(comHtml, "\"longitude\":\"", "\",");
		
		//address from sales_office
		add[0] = U.getSectionValue(comHtml, "\"sales_office_address\":\"", "\"");   
		add[0] = add[0].replace("412 N 2nd St, Loveland, OH 45140", "412 N 2nd St")
				.replace("26 CHATHAM BROOK DRIVE", "26 Chatam Brook Drive")
				.replace("5937 LYSTER LANE", "5937 Lyster Lane");
		
		add[1] = U.getSectionValue(comHtml, "sales_office_city\":\"", "\"");
		add[2] = U.getSectionValue(comHtml, "sales_office_state\":\"", "\"");
		add[3] = U.getSectionValue(comHtml, "\"sales_office_zip\":\"", "\"");
			
		U.log("ADDRESS: "+Arrays.toString(add)+" GEO: "+geo);
		U.log(Arrays.toString(latlng));
		
		//address from community data
		if(add[0] == ALLOW_BLANK || add[0].isEmpty() && add[1].isEmpty() && add[3].isEmpty()) {
			add[0] = U.getSectionValue(comHtml, "\"address\":\"", "\"");     
			add[1] = U.getSectionValue(comHtml, "\"city\":\"", "\"");
			add[2] = U.getSectionValue(comHtml, "\"state\":\"", "\"");
			add[3] = U.getSectionValue(comHtml, "\"zip\":\"", "\"");
			U.log("ADDRESS FROM COM: "+Arrays.toString(add)+" GEO: "+geo);
		}
		
		//address from model home
		String modelData = ALLOW_BLANK;
		modelData = getModelData(comHtml);
		//U.log("modelData: "+modelData);
		
		if(add[0].isEmpty() && add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
			
			add[0] = U.getSectionValue(modelData, "\"address\":\"", "\"");     
			add[1] = U.getSectionValue(modelData, "\"city\":\"", "\"");
			add[2] = U.getSectionValue(modelData, "\"state\":\"", "\"");
			add[3] = U.getSectionValue(modelData, "\"zip\":\"", "\"");
			U.log("ADDRESS FROM MODEL: "+Arrays.toString(add)+" GEO: "+geo);
		}
		
		if(add[0].equals("4940 Creekside Lane")||add[0].equals("Roberts Road")||add[0].isEmpty()) {
			add[0] = ALLOW_BLANK;
		}	
		
		if(add[0] == ALLOW_BLANK && latlng[0] != ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latlng);
			geo="TRUE";
			U.log("ADDRESS GEOCODED: "+Arrays.toString(add)+" GEO: "+geo);
		}
		
		U.log(Arrays.toString(add));
		
		
		//============ Community Unique Id
		String comUniqueId = U.getSectionValue(comHtml, "\"id\":", ",\"");
		U.log("comUniqueId: "+comUniqueId);

		//=========== Regions data of community from map
		String regionInfo = ALLOW_BLANK;
		ArrayList<String> regionPage = (ArrayList<String>)regionsData.get(comUniqueId); 
		
		if(regionPage != null) {
			for(String region:regionPage) {
				regionInfo += region;
				//U.log("regionInfo: "+regionInfo);
			}
		}
		//U.log("regionPage size: "+regionPage.size());
		
		//=========== Homes Data
		int homeCount = 0;
		int planCount = 0;
		String homeDescription = ALLOW_BLANK, propertyType = ALLOW_BLANK, homeData = ALLOW_BLANK;
		
		JsonParser json = new JsonParser();
		JsonObject objJsonHomes = (JsonObject)json.parse(comHtml); 
		JsonObject objJsonCom = (JsonObject)objJsonHomes.get("community");
		JsonArray homesArray = new JsonArray();	
		JsonArray planArray = new JsonArray();
		homesArray = (JsonArray)objJsonCom.getAsJsonArray("residences");
		homeCount = homesArray.size();
		U.log("homeCount: "+homeCount);
		planArray = (JsonArray)objJsonCom.getAsJsonArray("homes");
		planCount = planArray.size();
		U.log("planCount: "+planCount);
		
		for(int i = 0; i < homesArray.size(); i++) {
			String communitiesJson = homesArray.get(i).toString();	
			String Remove= U.getSectionValue(communitiesJson, "\"plan\":", "\"floors\"");
			homeDescription = U.getSectionValue(communitiesJson, "\"description\":", "\"banner\":");
			propertyType = U.getSectionValue(communitiesJson, "\"propertyType\":\"", "\"");
			homeDescription = homeDescription + propertyType;
			//U.log("propertyType: "+propertyType);
			communitiesJson = communitiesJson.replace(Remove, "");
			homeData += communitiesJson;
			
		}
		
		String planDescription = ALLOW_BLANK,  planData = ALLOW_BLANK;
		
		for(int i = 0; i < planArray.size(); i++) {
			String communitiesJson = planArray.get(i).toString();	
			String Remove= U.getSectionValue(communitiesJson, "\"plan\":", "\"floors\"");
			planDescription = U.getSectionValue(communitiesJson, "\"description\":", "\"banner\":");
			propertyType = U.getSectionValue(communitiesJson, "\"propertyType\":\"", "\"");
			planDescription = planDescription + propertyType;
			//U.log("propertyType: "+propertyType);
			communitiesJson = communitiesJson.replace(Remove, "");
			planData += communitiesJson;
			
		}
		
		//=========== Floor Plans Data
		int floorCount = 0;
		String floorsData = ALLOW_BLANK;
		
		JsonArray floorsArray = new JsonArray();	
		floorsArray = (JsonArray)objJsonCom.getAsJsonArray("residences");
		floorCount = floorsArray.size();
		U.log("floorCount: "+floorCount);
		
		for(int j = 0; j < floorsArray.size(); j++) {
			String floorJson = floorsArray.get(j).toString();
			floorsData += floorJson;
			//U.log("floorsData: "+floorsData);
		}
		
		//=========== Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String price [] = {ALLOW_BLANK,ALLOW_BLANK};
		
		price = U.getPrices(comHtml, "\"price\":\\d{6},\"price_high\":\\d{7}|null,\"price\":\\d{6},\"price_status|\"price\":\\d{6},\"sale_price|\"price_high\":\\d{6}", 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
	
		
		//=========== SQFT
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String sqft[] = {ALLOW_BLANK,ALLOW_BLANK};
		
		comHtml = comHtml.replaceAll("sqft_low\":2457,\"sqft_high\":2457", "");
		String comm_Desc=U.getSectionValue(comHtml, "community_code\":", "community_comments");
		
		sqft = U.getSqareFeet(comm_Desc+homeData+floorsData+modelData+planData, "ranging from \\d,\\d{3} sq ft. to \\d,\\d{3} sq ft.|\\d{4} sq ft.|\\d{4} sq ft. to \\d{4} sq ft.|null,\"sqft_low\":\\d{4}|\"sqft_high\":\\d{4}|\"sqft\":\\d{4}", 0);
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(planData, "[\\s\\w\\W]{30}864[\\s\\w\\W]{30}", 0));
		  
		//=========== cType
//		String comHtml_Sec=U.getSectionValue(comHtml, "", To)
		String ctype=U.getCommType((regJson+comm_Desc).replaceAll("Two golf courses are just minutes away|the Magic House, and other nearby parks, and top golf courses", "")
				.replaceAll("_MasterPlans|_Master Plans", ""));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(regJson, "[\\s\\w\\W]{30}golf course[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}golf course[\\s\\w\\W]{30}", 0));

		U.log("ctype=="+ctype);
		
		//=========== pType
		String desription = U.getSectionValue(comHtml, "\"description\":\"", "\"community_comments");
		String residences = U.getSectionValue(comHtml, "\"residences\":", "\"promoImage\"");
		//U.log("desription: "+desription);
		
		String pType = U.getPropType((comm_Desc+homeData+desription+residences+homeDescription+planDescription+planData)
				.replaceAll("canterburymanorstables|>Canterbury Manor Stables<", "")
				.replaceAll("Western Craftsman plan", "Western Craftsman-style home")
				.replace("Enjoy a tranquil coastal-themed setting", "Enjoy a tranquil coastal lifestyle setting")
				.replace("Grand Estates Custom Collection", "Grand Estates Custom homes Collection"));
		U.log("pType: "+pType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(homeData+desription+residences+homeDescription, "[\\s\\w\\W]{100}Manor[\\s\\w\\W]{100}", 0));
//		U.log("planData============\n"+planDescription);
		//=========== dType
		planData=planData.replace("\"floors\":", "Story ");

		String dType=U.getdCommType((regJson+comHtml+planData+homeData).replaceAll("\"plan\":Story 1,", "\"plan\":Stories: 1.0 ,").replace("5-level design", ""));
		U.log("dType=="+dType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(regJson+comHtml+planData+homeData, "[\\s\\w\\W]{100}story[\\s\\w\\W]{100}", 0));

		//=========== Status
		comHtml = comHtml.replaceAll("array of Move-In Ready homes available|Discover a variety of Move-In Ready homes available|\":\"closeout\"|"
				+ "a new single family homes community coming soon|Crescent Springs at Reserve at Meadowood Coming Soon|"
				+ "Park community offers new homes for sale and homes ready now|meta_description\":\"Fischer Homes - Coming Soon|\"title\":\"Coming Soon", "")
				.replace("A new phase of Maple Street homesites are available now", "A new phase homesites available now")
				.replace("A new phase of Designer homesites are available now", "A new phase homesites available now")
				.replace("grand-opening", "Grand Opening")
				.replace("New Paired Patio Homesites coming soon", "New Homesites coming soon")
				.replaceAll("[s|S]old-[o|O]ut", "sold out")
				.replaceAll("Amenity center coming 2022", "")
				.replaceAll("New phase of Maple Street homesites coming soon", "New phase of homesites coming soon");
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
		comHtml2=comHtml2.replaceAll("New phase of Maple Street homesites", "New phase of homesites");
		
		
		
		String status=U.getPropStatus((comHtml2+comHtml)
				.replaceAll("Amenities now open|Expanded amenity center now open", "")
				.replace("New phase of Maple Street homesites coming soon", "New phase of homesites coming soon"));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml2, "[\\s\\w\\W]{100}now open[\\s\\w\\W]{100}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{100}ow open[\\s\\w\\W]{100}", 0));

		if(homeCount > 0 ) {
			if(status == ALLOW_BLANK)
				status = "Move-In Ready";
			else if(status != ALLOW_BLANK && !status.contains("Move-in Ready"))
				status = status + ", Move-In Ready";	
		}
		
		if(comHtml.contains("banner\":\"coming-soon")) {
			if(status == ALLOW_BLANK)
				status = "Coming Soon";
			else if(status != ALLOW_BLANK && !status.contains("Coming Soon"))
				status = status + ", Coming Soon";
		}
		
		U.log("Status: "+status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{50}coming-soon[\\s\\w\\W]{90}", 0));
		status = status.replace("Move-in Ready", "Move-In Ready").replaceAll("Move-In Ready Homes", "Move-In Ready");;
		
		//Status from Images
		if(comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/119/the-settlement/")||
				comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/710/highland-ridge-at-river-crest/")||
				comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/663/bridlegate-at-triple-crown/")||
				comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/718/round-rock/")) {
			
			if(status == ALLOW_BLANK)
				status = "Final Opportunity";
			else if(status != ALLOW_BLANK)
				status = status + ", Final Opportunity";
			
		}
		if(comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/674/riviera/"))dType="1 Story";
		if(comUrl.equals("https://www.fischerhomes.com/find-new-homes/communities/790/scioto-landing/"))status="First Phase Of 20+ Homesites Sold Out";
		if(comUrl.contains("find-new-homes/communities/802/bent-creek-woods/"))
		{
			if(planCount>0) {
				if(status == ALLOW_BLANK)
					status = "Move-In Ready";
				else if(status != ALLOW_BLANK && !status.contains("Move-in Ready"))
					status = status + ", Move-In Ready";
			}
		}
		
		data.addCommunity(comName, comUrl, ctype);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(comHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
//		}
//		else
			i++;
	}
	
	public static String getModelData(String comHtml) {
		String modelHome = ALLOW_BLANK;
		int modelCount = 0;
		
		JsonParser json = new JsonParser();
		JsonObject objJsonModel = (JsonObject)json.parse(comHtml); 
		JsonObject objJsonCom = (JsonObject)objJsonModel.get("community");
		JsonArray modelArray = new JsonArray();		
		modelArray = (JsonArray)objJsonCom.getAsJsonArray("model_homes");
		modelCount = modelArray.size();
		U.log("Model homeCount: "+modelCount);
		
		for(int i = 0; i < modelArray.size(); i++) {
			String modelJson = modelArray.get(i).toString();	
			//String Remove= U.getSectionValue(modelJson, "\"plan\":", "\"floors\"");
			//U.log("modelJson: "+modelJson);
			modelHome += modelJson;
		
		}
		return modelHome;
	}
}
