/**
 *Modification Aditya.. 
@author Parag Humane 
 * @date 16/04/2012
 * 
 */
package com.shatam.b_061_080;
import java.io.*;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWciCommunities extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	static int j=0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractWciCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/WCI Communities.csv", a.data()
				.printAll());
	}

	public ExtractWciCommunities() throws Exception {
		super("WCI Communities", "http://www.wcicommunities.com/");
		LOGGER = new CommunityLogger("WCI Communities");
	}

	public void innerProcess() throws Exception {

		// Your code here
		String html = U.getHTML("http://www.wcicommunities.com/communities/");
		String section = U.getHtmlSection(html, "row content-list",	"container agentshield");
		String[] values = U.getValues(section, "<div class=\"col-xs-4","</div>");
		U.log(values.length);
		for (String item : values) {
			//U.log(item+"====");
			addDetails(item);
//			
			i++;
			inr++;
			// break;
		}
		LOGGER.DisposeLogger();
	}

	public void addDetailibis(String url) throws Exception {
		String html = U.getHTML(url);
		String STR = ALLOW_BLANK;
		String commName = ALLOW_BLANK, commType = ALLOW_BLANK, Ptype = ALLOW_BLANK, dPtype = ALLOW_BLANK, Pstatus = ALLOW_BLANK, note = ALLOW_BLANK;
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK }, latlng = {ALLOW_BLANK, ALLOW_BLANK }, SQFT = { ALLOW_BLANK, ALLOW_BLANK }, PRICE = {
				ALLOW_BLANK, ALLOW_BLANK };
		commName = "Ibis";
		Pstatus = "Coming Soon";
		SQFT[0] = "2502";
		add[0] = "222 Laken Dr";
		add[1] ="West Palm Beach";  
		add[2] = "FL";
		add[3]= "33409";
		latlng=U.getlatlongGoogleApi(add);
		note="Lat long and street address taken using city and states";
		String geo = ALLOW_BLANK;geo="TRUE";
		data.addCommunity(commName, url, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(SQFT[0], SQFT[1]);
		data.addPrice(PRICE[0], PRICE[1]);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPropertyType(Ptype, dPtype);
		data.addPropertyStatus(Pstatus);
		data.addNotes(note);
	}

	public void addDetails(String urlSec) throws Exception {
//	if(j==2)
	{
		String url = U.getSectionValue(urlSec, " <a href=\"", "\"");
		if (url == null)
			url = urlSec;// for checking single url
		U.log("PAGE::" + url);
		String aa="";
		
	
		String html = U.getHTML(url);
		File f = new File(U.getCache(url));
		if(html.contains("Object Moved</h1>This document may be found <a HREF=\"https://www.lennar.com")){
			LOGGER.AddCommunityUrl(url+"::::::::::Redirect to Lennar::::::::::::");
			return;
		}
		String STR = ALLOW_BLANK;
		String commName = ALLOW_BLANK, commType = ALLOW_BLANK, Ptype = ALLOW_BLANK, dPtype = ALLOW_BLANK, Pstatus = ALLOW_BLANK, note = ALLOW_BLANK;
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK }, latlng = {
				ALLOW_BLANK, ALLOW_BLANK }, SQFT = { ALLOW_BLANK, ALLOW_BLANK }, PRICE = {
				ALLOW_BLANK, ALLOW_BLANK };
		String geo = ALLOW_BLANK;

		//============ Community Type =====================
		String remove = U.getSectionValue(html, "center\">D", "</p>");
		if (remove != null)
			html = html.replaceAll(remove, "");
		remove = U.getSectionValue(STR, "keywords", "/>");
		if (remove != null)
			html = html.replaceAll(remove, "");
		if(url.contains("http://artesia.wcicommunities.com/"))
			html=html+" Cottage Homes";
		String newhtml=html;
		newhtml=newhtml.replaceAll("resort-style","Resort-Style").replaceAll("332-acre gated|gated-community","gated Community");
		newhtml=newhtml.replaceAll("Country-Club-East|countryclubeast|Country-Club-East-Single", "");
		String lifestyle=U.getHTML(url+"/lifestyle/");
		String drop=U.getSectionValue(newhtml, "main.area-map", " var map");
		if(drop!=null)newhtml=newhtml.replace(drop, "");
		String amenitiesHtml = null;
		if(lifestyle!=null){
			String drop2=U.getSectionValue(lifestyle, "main.area-map", " var map");
			if(drop2!=null)
				lifestyle=lifestyle.replace(drop2, "");
			String amenitiesSection = U.getSectionValue(lifestyle, "Lifestyle</a>", "Amenities</a>");
			if(amenitiesSection != null){
				String amemitiesUrl = U.getSectionValue(amenitiesSection, "<a href=\"", "\"");
				amenitiesHtml  = U.getHTML(url+"/"+amemitiesUrl);
			}
		}
		newhtml = newhtml.replaceAll("55-and-better community|55 and Better", "55+ community");
		commType = U.getCommunityType(newhtml+lifestyle);
		
		
		html=html.replaceAll("-Single-Family-Logo|Grand Opening New Clubhouses|center\">Opening Soon|-Single-Family-|condo, south tampa,|luxurious, penthouse|condominiums from the|developer and luxury homebuilder of single and multi-family homes|condos-florida-10.jpg|condos-3.jpg|condos-homes-4.jpg|homes condos naples tampa|homes-condos-naples-tampa-bay.jpg|condos-florida-5.jpg|condos-florida-9.jpg|homes-condos-7.jpg|village|Village", "");
			
		//======== Home tab html ====================
		String homesHtml=ALLOW_BLANK;
		String HomesSec=ALLOW_BLANK;
		if(html.contains("<a href=\"homes/\">Homes</a>")){
			homesHtml=U.getHTML(url+"/homes/");
			HomesSec=U.getSectionValue(homesHtml, "<h2>HOMES</h2>", "<div id=\"navbar\"");
			U.log("-----hello-----"+HomesSec);
		}
		//======== Notes ======================
		note = U.getnote(html);

		// ======= Altaira ==============
		String combinedHomesUrlHtml = null;
		if (url.contains("altaira")) {
			html = U.getHTML(url);
//			commName = U.getSectionValue(U.getSectionValue(html, "<h1>", "</h1>"), "| ", " ");
			//html = html.replaceAll("</h1>", "<sup>");
			commName = U.getSectionValue(html, "<h2 class=h2>", "<sup>");
//			String contacHtml = U.getHTML(url+"/contact.html");
			String contacHtml = U.getHTML(url+"location/community-map.html");
			
			latlng[0] =  U.getSectionValue(contacHtml, "var lat =", ";") ;
			latlng[1] = U.getSectionValue(contacHtml, "var lon =", ";");
			String addSection = U.getSectionValue(contacHtml, "></div><div class=\"col-md-12\">", "<br/><br/><strong>");
			addSection =  addSection.replace("<br/>", ",").replace("&nbsp;", " ").replace("</span><br>", ",").replaceAll("<span>|</span>|\\s{2,}", "");
			U.log(addSection);
			
			PRICE[0] = "$1,000,000";
			SQFT[0] = "3715";
			SQFT[1] = "4102";
//			add[1] = "Bonita Springs";
//			add[2] = "FL";
			add = U.getAddress(addSection);
			Ptype="Luxury Home,Condominium";
			geo = "False";
			amenitiesHtml = U.getHTML(url+"lifestyle/amenities/");
			dPtype = U.getdCommType((amenitiesHtml+html).replaceAll("Ranch", ""));
		}

		// ======== Others ==============
		else {
			commName = U.getSectionValue(html, "text-align: center;\">", "from");
			if (url.contains("http://ibis.wcicommunities.com/")) {
				commName = "IBIS";
			}
			html = html.replace("<title>Coming Soon |", "<title>");
			if(commName==null)
				commName = U.getSectionValue(html, "<title>", "|");
			U.log("Community Name:  " + commName);
			commName = commName.replace("<span>", "").replace("&amp;", "&");
			STR = Util.match(html, "<a href=\"(.*?)\" title=\"Area Map");
			if (STR == null)
				STR = ALLOW_BLANK;
			STR = U.getSectionValue(STR, "<a href=\"", "\"");
			U.log("Error::" + url + STR);
			STR = U.getHTML(url + STR);
			if (url.contains("http://portico.wcicommunities.com/")) {
				add[0]="";
				add[1]="Fort Myers";
				add[2]="FL";
				add[3]="";
				latlng=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlng);
				note="Address And LatLon Taken From City And State";
				geo="TRUE";
			}else if(STR!=null&&STR!=ALLOW_BLANK){
				add[0] = U.getSectionValue(STR, "Welcome Center", "<br/>");
				if (add[0] == null) {
					add[0] = ALLOW_BLANK;
				}
				add[2] = Util.match(add[0], "\\w{2} \\d{5}");
				
				if (add[2] != null) {
					add[0] = add[0].replace(add[2], "");
					add[3] = Util.match(add[2], "\\d{5}");
				}
				if (add[3] != null)
					add[2] = add[2].replaceAll(add[3], "").trim();
				
				add[1] = Util.match(add[0], ".*?,").replace(",", "");
				add[0] = U.getSectionValue(add[0], "p>", "<br");
				U.log(Arrays.toString(add));
				//=========== LatLng Section ===============
				latlng[0] = U.getSectionValue(STR, "var lat =", ";");
				if (latlng[0] != null )
					latlng[0] = latlng[0].trim();
				
				latlng[1] = U.getSectionValue(STR, "var lon =", ";");
				if (latlng[1] != null)
					latlng[1] = latlng[1].trim();
				U.log("lat::"+latlng[0]+" lng::"+latlng[1]);
				geo = "FALSE";
			}
			
			String mainSec = urlSec.replaceAll(" Million", ",000,000");
			mainSec = mainSec.replaceAll("0s", "0,000");
			aa = mainSec;
			String[] sections = U.getValues(html, "><a href=\"homes/", "\"");
			String pHtml = html.replaceAll("0s", "0,000");
			pHtml = pHtml.replaceAll(" Million", ",000,000");
			String loc_P = ALLOW_BLANK, loc_a = ALLOW_BLANK;
			String H = "";
			String planHtml=ALLOW_BLANK;
			for (String loc : sections) {
			
				U.log(url + "/homes/" + loc);
				H = H+U.getHTML(url + "/homes/" + loc);
				H=U.removeComments(H);
				H=H.replaceAll("developer and luxury homebuilder|content=\"View Luxury Hom|rel=\"View Luxury Hom| WCI Communities is a lifestyle community developer and luxury homebuilder of single and multi-family homes", "");
				/*if (H.contains("coach")) {
					U.log("Foound----------");
				}*/
				combinedHomesUrlHtml = combinedHomesUrlHtml+H;
				//find derived for the plan page on carriage home tab
				if(loc.contains("carriage-homes/")){
					String plansec=U.getSectionValue(H, " <div id=\"residence\" class=\"col-md-12\">", " <div id=\"weather\"></div>");
					if(plansec!=null)plansec=plansec.replace("<a href=\"tel:941.441.2626\" >", "");
					String[] planUrls=U.getValues(plansec, "<a href=\"", "\"");
					for (String planurl:planUrls){
						planHtml=planHtml+U.getHTML(url+planurl);
						planHtml=planHtml.replace("second-story", "2 Story");
						
					}
				
				}
			}
			
			
			//=========== Price ===========================
			pHtml=pHtml.replace("$1.5 million", "$1,500,000").replace("to the $900","");
			PRICE = U.getPrices((pHtml + mainSec + H).replace("from the $150", ""),
								"\\$\\d+,\\d+ to \\$\\d,\\d+,\\d+|\\$\\d+,\\d+ to \\$\\d+,\\d+|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+|\\$\\d,\\d+,\\d+",
								0);
			
						
			//============= Sqft ==============================	
			SQFT = U.getSqareFeet(homesHtml.replace("2,713 a/c sq. ft.","")+html+combinedHomesUrlHtml,
						"[0-9]{1},[0-9]{3} to more than [0-9]{1},[0-9]{3}|\\d,\\d+ a/c sq. ft.|\\d,\\d+ to \\d,\\d+ sq. ft.|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3} square feet|\\d,\\d{3} to \\d,\\d{3} a/c sq. ft.", 0);


			if (PRICE[0] == null)
				PRICE[0] = ALLOW_BLANK;
			if (PRICE[1] == null)
				PRICE[1] = ALLOW_BLANK;

			if (SQFT[0] == null)
				SQFT[0] = ALLOW_BLANK;
			if (SQFT[1] == null)
				SQFT[1] = ALLOW_BLANK;
		
			U.log("Max SQFT ::"+SQFT[0]+"\tMin SQFT:::"+SQFT[1]);
			if(homesHtml==null)homesHtml =ALLOW_BLANK;
				
			H = H.replace("second-story", "2 Story");
			

			String rem=U.getSectionValue(html, "col-sm-12 copyright", "</p>");
			if(rem!=null)
				html=html.replace(rem, "");

			//=========== Property Type =========================
			html = html.replaceAll("selection of luxury|Luxury Penthouse", "luxury homes");
			if (HomesSec!=null) {
				HomesSec = HomesSec.replace("Garden Villas", "Garden homes Villas");
			}
			
			if(combinedHomesUrlHtml != null)
			combinedHomesUrlHtml = combinedHomesUrlHtml.replace("detached single", "detached home single");
			
			if (url.contains("http://livingstonlakes.wcicommunities.com/")) {
				String tempHtml=U.getHTML(url+"homes");
				tempHtml=U.getSectionValue(tempHtml, "<h2>HOMES</h2>", "id=\"residence\"").replace("Carriage, Coach and Garden Homes", "Carriage, Coach Homes and Garden Homes");
				//U.log(tempHtml);
				combinedHomesUrlHtml=combinedHomesUrlHtml+tempHtml;
			}
			
			
			Ptype = U.getPropType(html+HomesSec+combinedHomesUrlHtml+amenitiesHtml);
		
			//=========== Derived Community Type ====================
		
			dPtype = U.getdCommType(planHtml+pHtml + mainSec + H + homesHtml.replace("one- and two-story","1 story ,2 story"));

			U.log("Max price ::"+PRICE[0]+"\tMin price:::"+PRICE[1]);
		}//eof else

		U.log("lat::"+latlng[0]+" lng::"+latlng[1]);
		//================= Property Status ====================
		
		Pstatus=U.getPropStatus((html+urlSec).replaceAll("Residences Now Available|Homes Coming Soon",""));
		
/*		if(url.contains("http://altaira.wcicommunities.com/")){
			add[0] = "5001 Coconut Road";
			latlng = U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		U.log("==="+latlng[1]);
*/		if(latlng[0].length()<4)
			latlng[0]=null;
		if(add[3]==ALLOW_BLANK&&latlng[0]!=null){
			String[] addrs=U.getAddressGoogleApi(latlng);
			add[3]=addrs[3];
			geo="TRUE";
		}
		
		if(latlng[0]==null){
			String commSec = U.getSectionValue(aa, "/\" title=\"", ">");
			String[] aadrs = commSec.split(",");
			add[1] = aadrs[0];
			add[2] = aadrs[1].trim();
			latlng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlng);
			geo="True";
			note="Lat long and street address taken using city and states";
		}
		
		if(url.contains("http://lostkey.wcicommunities.com/")){
			add[0]=" 14000 Perdido Key Dr";
			add[1]="Perdido";
			add[2]="FL";
			add[3]="32507";
			geo="FALSE";
		}
		if(url.contains("http://westshoreyachtclub.wcicommunities.com"))
			commName = "Westshore Yacht Club";
		if(url.contains("artesia.wcicommunities.com/") || url.contains("livingstonlakes.wcicommunities.com/"))
			Pstatus = ALLOW_BLANK;
		if(commName!=null)
			commName=commName.replace("<br />", "");
		
		U.log("CommType :::"+commType);
		U.log("PropType::"+Ptype);
		U.log("Dtype :::"+dPtype);
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(commName, url, commType);
		data.addAddress(add[0].replace(".", ""), add[1], add[2], add[3]);
		data.addSquareFeet(SQFT[0], SQFT[1]);
		data.addPrice(PRICE[0], PRICE[1]);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPropertyType(Ptype, dPtype);
		data.addPropertyStatus(Pstatus);
		data.addNotes(note);
	}j++;
	}
}
