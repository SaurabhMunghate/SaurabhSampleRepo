/* Sampada Santosh */
package com.shatam.b_081_100;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class EdgeHomes extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static int j = 0;
	static String Builder_name = "Edge Homes";
	static String HOME_URL = "https://www.edgehomes.com/";
	CommunityLogger LOGGER;
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new EdgeHomes();
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Edge Homes.csv", a.data().printAll());
	}

	public EdgeHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger(Builder_name);

	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String basehtml=U.getPageSource("https://www.edgehomes.com/communities/?type=single-family_townhome_condo");
		
		String vals[]=U.getValues(basehtml,"<div class=\"pin-widget\">",  " </ul>");
		String[] comm_Sec=U.getValues(basehtml,"<div class=\"single-property\">",  "Open Link Here</span>");
		U.log("communityLen::::::"+vals.length);
		
		for(String val:vals){
			String name=U.getSectionValue(val, "<p class=\"name\">", "</p>").trim();
//			U.log(val);
			String url=U.getSectionValue(val,"<a href=\"","\"");
			for(String commSec :comm_Sec) {
				String name2=U.getSectionValue(commSec, "<p class=\"h5 same-size mb-0\">", "</p>").trim();
				if(name.equals(name2)) {
					val+="====================\n"+commSec;
					addDetails(val,url);
				}
				
			}
		}
	//	driver.close();
//		try{
//			
//		}
//		catch(Exception e){}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comSec,String url) throws Exception {
	
//	if(j >= 7)
//		try{
	{
		
		//TODO ::
		if(!url.contains("https://www.edgehomes.com/communities/bringhurst-station/"))return;
		///String html=U.getPageSource(url);
		String html=U.getHtml(url,driver);

//		html=html.replace("Valley View Ranch","");
		String[] remove=U.getValues(html, "<div class=\"single-property\">", "Open Link Here");
		if(remove.length>0) {
			for(String rem : remove) {
				html=html.replace(rem, "");
			}
		}
		
//		String quikhtml = U.getSectionValue(html, "<!--<div class=\"quick_move_in_feed lazyload\">", "<!-- Start Community Features  -->");
		String quikhtml = U.getSectionValue(html, "<!-- Start Model Home  -->", "<!-- Start Community Features  -->");
		
//		U.log("comSec==="+comSec);
		U.log(j+"]]\turl:::"+url);
		
		//------------------------commName-------------------//
//		String communityName=U.getSectionValue(html,"<h4 class=\"h4 marg-btm-0 white\">","</h4>");
		String communityName=U.getSectionValue(comSec,"<p class=\"name\">","</p>").trim();

		communityName=communityName.replace("– Townhome","").replace("– Sales Trailer","").replace("Sales Center","").replace("&#8211; Sales Center","").replace("&#8211; ","")
				.replaceAll("OPENING SOON$|Townhome$|Condos$|Townhomes", "");
		
		
		U.log("communityName::::::::::::"+communityName);
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url+"*************************community repeated");
			return;
		}
		
		
		//---------------------Floorplan data---------------------------//
		String floorplanHtml=U.getHTML("https://www.edgehomes.com/floor-plans/");
		String plan_Data=ALLOW_BLANK;
		if(floorplanHtml!=null) {
			String[] plans=U.getValues(floorplanHtml, " <div class=\"image-wrap\">", "Open Link Here");
			if(plans.length>0)
			{
				for(String planData : plans) {
					String planUrl=U.getSectionValue(planData, "<a href=\"", "\" class");
//					U.log("planUrl::::"+planUrl);
					if(planUrl!=null)
					{
						String planHtml=U.getHTML(planUrl);
						String nameSec=U.getSectionValue(planHtml, "text-uppercase same-size\">", "</div>");
						if(nameSec.contains(communityName))
						{
							U.log("planUrl::::"+planUrl);
							plan_Data+=planData+"\n"+U.getSectionValue(planHtml, "poperty-top-details\">", " More Photos</u>");
						}
					}
				}
			}
		}
		
		//----------------------latong-------------------//
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(comSec, "href=\"https://www.google.com/maps?q=","\">");
		
		
		if (latLongsec != null) {

			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}

		
		//------------------adress------------//
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;

		String ad = U.getSectionValue(comSec, "<p class=\"address\">", "</p>").trim().replace("Utah", "UT");
		ad=ad.replace("Sales Center:","").replace("&amp;", "&");
		ad=ad.replace("14483 S Selving Way, Herriman UT 84096","14483 S Selving Way, Herriman ,UT 84096").replace("2300 W 8570 N Lehi", "2300 W 8570 N ,Lehi").replace("14454 River Chase Road Herriman","14454 River Chase Road, Herriman").replace("Model Home: 436 West 4050 North Lehi, UT 84043 | Community Location:","");
		ad=ad.replace("Saratoga Springs",",Saratoga Springs").replace("Riverton",",Riverton").replace("Road Bluffdale", "Road, Bluffdale").replace(", ,", ",")
				.replace("Herriman/,Riverton, UT 84095/84065", "Riverton, UT 84065");
		ad=ad.replace("586 N 260 West Lakefront at Town Center", "586 N 260 West").replace("586 N 260 West, Vineyard, UT 84058, Vineyard, UT 84059", "586 N 260 West, Vineyard, UT 84059");
		U.log("Addres: "+ad);
		//
		if (ad != null) {
			
			String a[]=ad.split(",");
			add[0]=a[0].trim();
			add[1]=a[1].trim();
			a[2]=a[2].trim();
			U.log(a[2].length());
			if(a[2].length()>2){
			String b[]=a[2].split(" ");
			add[2]=b[0].trim();
			add[3]=b[1].trim();
			geo="FALSE";
			}
			if(a[2].length()==2){
				add[2]=a[2];
			}
			
		}
		
		if (add[3]==ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
				+ " add[3] " + add[3]);
		
		
	
		//========= Floor Plan Html ====================
		String sqftfloorplan="";
		html = U.removeComments(html);
		String floorSec = Util.match(html, "<a href=\"(.*?)\" class=\"column\">\\s*<i class=\"icon-floorplan\">",1);
		U.log("floor url==::"+floorSec);
		String floorHtml = "";
		String flHtml="";
		if(floorSec != null){
			floorHtml = U.getHtml(floorSec, driver);
			flHtml=floorHtml;
//			U.log(U.getCache(floorSec));
			floorHtml = U.getSectionValue(floorHtml, "<div id=\"results\" class=\"column small-12 medium-12 large-12\">", "<div class=\"footer-container")
					+ U.getSectionValue(floorHtml, "<div class=\"row align-center large-up-3 medium-up-2 small-up-1\">", "<nav class=\"pagination-wrap\">");
//			U.log(floorHtml);
			try {
			if(floorHtml.contains("/floor-plans/page/2")) {
				String pageHtml=U.getHtml( "https://www.edgehomes.com/"+"floor-plans/page/2",driver);
				floorHtml+=U.getSectionValue(pageHtml, "<div id=\"results\" class=\"column small-12 medium-8 large-8\">", "<div class=\"footer-container");
			}}
			catch(Exception e) {}
		}
		
		//finding floor plans
		floorHtml = floorHtml.replaceAll("\\s{2,}", "");
//		U.log(floorHtml);
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(floorHtml,"[\\w\\s\\W]{30}Vincent[\\w\\s\\W]{400}",0));
		String floorSection[]  = U.getValues(floorHtml, "<div class=\"h4 marg-btm-0\">", "</div></div></div>"); //
		U.log("Total Floor :"+floorSection.length);
//		String pricesHtml="";
		String combinedFloorHtml = null;
		String combinedFloorHtml2 = null;
		for(String fSec : floorSection){
//			U.log(":::fSec:::::"+fSec);
			combinedFloorHtml2+=fSec;
			String floorUrl = U.getSectionValue(fSec, "<a href=\"", "\"");
//			U.log("=="+floorUrl);
			String fHtml = U.getPageSource(floorUrl);
//			pricesHtml+=fHtml;
			sqftfloorplan+=U.getSectionValue(fHtml, "<div class=\"column large-4 medium-4 small-12 padd-sides sr-from-bottom m-center\">", "<div class=\"column large-8 medium-8 small-12 sr-from-bottom m-center\">");
//			U.log("=="+sqftfloorplan);
			String communitiesFloorSection = U.getSectionValue(fHtml, "Communities with this Floorplan", "See More Communities with this floorplan");
			if(communitiesFloorSection != null){
				String comUrlSection[] = U.getValues(communitiesFloorSection, "<h2 class=\"h4\">", "</h2>");
				for(String comUrlSec : comUrlSection){
//					U.log("==>"+U.getSectionValue(comUrlSec, "<a href=\"", "\""));
					//check if this floor plan is for given community 
					if(url.equals(U.getSectionValue(comUrlSec, "<a href=\"", "\""))){
						combinedFloorHtml += fSec;
						break;
					}
				}
			}
		}
//		U.log(">>>combinedFloorHtml>>>>>>>>>>>>>>>>"+combinedFloorHtml);
		
		//U.log(floorHtml);
		// ---------community type,property type,property status,derived, property type---------//
		
		String availhtml=ALLOW_BLANK;
		String allAvailHomesData=ALLOW_BLANK;

//		String homeHtml="";
//		String [] homeData=U.getValues(html, "<div class=\"single-property\">", "Open Link Here");
//		if(homeData.length>0)
//		{
//			for(String home_data : homeData) {
//				String homeurl=U.getSectionValue(home_data, "<a href=\"", "\"");
//				if(homeurl!=null) {
//					U.log("homeurl=="+homeurl);
//					allAvailHomesData+=U.getHTML(homeurl);
//				}
//			}
//		}
		
		
		//-----------QuickMoveData
		String allQuickData = ALLOW_BLANK;
		allQuickData = getQuickData(communityName);
		
		html=html.replaceAll("nohoa|There is no HOA for this community.","");
		html=html.replace("Charter Schools Coming Soon</div>","");
//		html= U.removeSectionValue(html, "<nav class=\"nav-utilities ", "nterior Designers</a>");
		String psec=U.getSectionValue(html,"Come See our Model Home","div class=\"community-reps");
		String qsec=U.getSectionValue(html,"Choose Your Lot","</div>");
		if(qsec == null)qsec = ALLOW_BLANK;
		String commType = U.getCommunityType(qsec+html);
//		 
		String floorhtml1="";
		String floorhtml2="";
		String[] fpurl=U.getValues(flHtml, "<div class=\"h4 marg-btm-0\"><a href=\"", "\">");
		if(fpurl.length>0) {
			for(String FpUrl : fpurl) {
			//	U.log("FpUrl>>>>>>  "+FpUrl);
				floorhtml1=U.getPageSource(FpUrl);
				String communitysec=U.getSectionValue(floorhtml1, "Communities with this Floorplan", "See More Communities with this floorplan");
				if(communitysec.contains(url))
				{
					floorhtml2+=floorhtml1;
				}
				
			}
			
		}

		floorhtml2=floorhtml2.replaceAll("/condo|condo living|condominium main level floor plans|condominium third level floor plans|convenient condo living|condominium second level floor plan|-condo|Condo|condo-|_condo|CondoModel", "");
		
		floorhtml2=floorhtml2.replace("Traditional (Standard)", "Traditional exterior").replace("Craftsman (Optional)", "Craftsman-style exterior")
				.replace("Farmhouse (Optional)", "Farmhouse-style exteriors")
				.replace("4 Plex", "4-Plex Townhome").replace("5 Plex", "5-Plex Townhome").replace("6 Plex", "6-Plex Townhome").replace("3 Plex", "Triplex");
		
		plan_Data=plan_Data.replace("Traditional (Standard)", "Traditional exterior").replace("Craftsman (Optional)", "Craftsman style details")
				.replace("Farmhouse (Optional)", "Farmhouse exterior");
		
		String propType = U.getPropType((plan_Data+floorhtml2+comSec+psec+qsec+allQuickData+allAvailHomesData).replaceAll("CondoModel|name\":\"Condom|Condo Fl|condo-|_condo|Whether you’re single and just need a luxury condo for your busy lifestyle|Condo Garage|-Plex-", ""));
		U.log("propType: "+propType);

		U.log(">>>>>>>>>>>>"+Util.matchAll(plan_Data, 
				"[\\s\\w\\W]{30}Traditional (Standard)[\\s\\w\\W]{30}", 0));
		//======= Come See our Model Home Section ===============
		String modeHomeSec = U.getSectionValue(html, "class=\"column small-12 large-5\">", "See More</a>");
		String modelHomeHtml = null;
		if(modeHomeSec != null){
			String modeHomeUrl = U.getSectionValue(modeHomeSec, "<a href=\"", "\"");
			U.log("modeHomeUrl ::"+modeHomeUrl);
			if(!modeHomeUrl.contains("post_type=model_homes&p=21339")){//if model home not showing page not found
				modelHomeHtml = U.getPageSource(modeHomeUrl);
				modelHomeHtml = U.getSectionValue(modelHomeHtml, "Specifications</h4>", "</div>");
			}
		}
		
		//========== Derived community type =========================

//		U.log(Util.matchAll(floorHtml, "Two story",0));   
		String dpType = U.getdCommType(( plan_Data+floorhtml1+combinedFloorHtml2+allAvailHomesData+modelHomeHtml+comSec+combinedFloorHtml+allQuickData)
				.replaceAll("(L|l)evel|#single-floor_plans|single-floor_plans postid|id=\"single-floor_plans\"|.single-floor_plans|value=\"One Story\"", ""));

		U.log("dpType: "+dpType);

		html = html.replaceAll("See our Quick Move Ins|Coming Soon</title>|EDGEhomes \\| Coming Soon|2 Charter Schools Coming Soon|coming soon.|Lots Available\\s*</span>|icon-z-lots-available|Center OPENING|-coming-soon/|Coming Soon\\s*</title>|EDGEhomes\\s*\\\\|\\s*Coming Soon\"/>", "")
				.replaceAll("Quick Move-(I|i)ns\\s+</a>|See our Quick|quick|quick-move-ins/\">\\s*QUICK MOVE-INS|ve-ins/\">\n\\s+QUICK MOVE-INS", "");
		
		String commStatus = U.getPropStatus(html);
		commStatus = commStatus.replace("Quick Move-in", "");
		U.log("Staus: "+commStatus);
		
		U.log("QUIV+CKKK"+allQuickData);
		if(!commStatus.contains("Quick") && allQuickData.contains("<div class=\"column marg-btm-40 search-item") ){
//			U.log("<<<<<<<<<<<<");
			if(commStatus.length()<3){
				commStatus = "Quick Move Ins";
			}
			else{
				commStatus = commStatus + ", Quick Move Ins";
			}
		}
		
		

		// --prices---//
		html=html.replaceAll("0's|0's","0,000");
		html=html.replace("0's","0,000");
//				U.log(html);
		
//		U.log(comSec);
		String[] price = U.getPrices(html+comSec+allQuickData+allAvailHomesData,
				"lazyload\">\\$\\d{3},\\d{3}-\\d{3},\\d{3}</div|>\\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}</div>|Priced at <strong>\\$\\d{3},\\d{3}|<div class=\"h5\">\\$\\d{3},\\d{3}-\\d{3},\\d{3}</div>|<strong>high \\d{3},\\d+</strong>|\\$\\d{3},\\d+|high \\$\\d{3},\\d+|low \\d{3},\\d+|\\$d{3},\\d+-\\$\\d{3},\\d+|\\$\\d{3},\\d+|\\$\\d{3},\\d+", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		

		// -----------sqreft-----------//
		String[] sqft= {};
		html=html.replace("Finished -\\d+","")
				.replaceAll("Sq.\n" + 
						"            Ft.", "Sq.Ft.");
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		comSec=comSec.replaceAll("Sq.\n" + 
				"            Ft.\\s*", "Sq.Ft. ");
		
		
		//U.log(comSec);
		if(url.contains("https://www.edgehomes.com/communities/bringhurst-station/")) {//||url.contains("https://www.edgehomes.com/communities/bringhurst-station-townhomes/")
			 sqft= U.getSqareFeet(plan_Data+html+comSec+modelHomeHtml+allQuickData+sqftfloorplan+allAvailHomesData,
					"Sq.Ft. \\d,\\d{3} – \\d,\\d{3}|Total: \\d,\\d{3}|Sq.Ft. \\d,\\d{3}-\\d,\\d{3}|Square Ft - Total: \\d\\,\\d{3}|Square Ft - Total: \\d,\\d{3}|<div>Sq. Ft. \\d,\\d{3}(\\s*[–|-]\\s*\\d,\\d{3})*|<div>Sq. Ft. \\d{4} – \\d{4}|Sq. Ft. \\d+,\\d+-\\d+,\\d+|Sq. Ft. \\d+,\\d+ – \\d+,\\d+|Sq. Ft. \\d+-\\d+|Sq. Ft. \\d+|Sq. Ft. \\d{1},\\d{3}-\\d{1},\\d{3}|Square Ft - \\d,\\d{3}|class=\"h6\">\\s+\\d,\\d{3}\\s+<", 0);	
		}else {
			U.log("sqft===2");
		sqft = U.getSqareFeet(plan_Data+html+comSec+modelHomeHtml+allQuickData+sqftfloorplan+allAvailHomesData,
				"Sq.Ft. \\d,\\d{3}–\\d,\\d{3}|Sq.Ft. \\d,\\d{3} – \\d,\\d{3}|Sq.Ft. \\d,\\d{3} - \\d,\\d{3}|Sq.Ft. \\d,\\d{3}-\\d,\\d{3}|Sq.Ft. \\d,\\d{3}|Sq.Ft. \\d,\\d{3}-\\d,\\d{3}|Square Ft - Total: \\d\\,\\d{3}|Square Ft - Total: \\d,\\d{3}|Total: \\d,\\d{3}|<div>Sq. Ft. \\d,\\d{3}(\\s*[–|-]\\s*\\d,\\d{3})*|<div>Sq. Ft. \\d{4} – \\d{4}|Sq. Ft. \\d+,\\d+-\\d+,\\d+|Sq. Ft. \\d+,\\d+ – \\d+,\\d+|Sq. Ft. \\d+-\\d+|Sq. Ft. \\d+|Sq. Ft. \\d{1},\\d{3}-\\d{1},\\d{3}|Square Ft - \\d,\\d{3}|class=\"h6\">\\s+\\d,\\d{3}\\s+<", 0);
		}
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		U.log("Match1===="+Util.matchAll(plan_Data, "[\\s\\w\\W]{30}Total: 4,597[\\s\\w\\W]{30}",0));
//		U.log("Match1===="+Util.matchAll(modelHomeHtml+allQuickData, "[\\s\\w\\W]{30}Sq.Ft.[\\s\\w\\W]{30}",0));
//		U.log("Match1===="+Util.matchAll(sqftfloorplan+allAvailHomesData, "[\\s\\w\\W]{30}Sq.Ft.[\\s\\w\\W]{30}",0));
//		U.log("Match1===="+Util.matchAll(html+comSec+modelHomeHtml+allQuickData+sqftfloorplan+allAvailHomesData, "[\\s\\w\\W]{30}Sq.Ft.[\\s\\w\\W]{30}",0));

		if(commStatus.length()==0){
			commStatus=ALLOW_BLANK;
		}

		communityName=communityName.trim().replaceAll("Condos$", "");
		commStatus = commStatus.replace("Sold Out, Quick Move Ins", "Quick Move Ins");
        if(url.contains("https://www.edgehomes.com/communities/the-exchange-condo/")) {maxSqf="3622";dpType=ALLOW_BLANK;}
		
		//===========site plan============
		String lotCount=ALLOW_BLANK;
		int noOfUnit=0;
		String siteplanSec=U.getSectionValue(html, "<div class=\"iframe-container\">", "</iframe><noscript>");
		if(siteplanSec==null) {
			siteplanSec=U.getSectionValue(html, "<div class=\"iframe-container\">", "</iframe>");
		}
		if(siteplanSec!=null) {
		String siteMapUrl=U.getSectionValue(siteplanSec, "src=\"", "\"");
		U.log("sitemap Url:: "+siteMapUrl);
		if(siteMapUrl.contains("about:blank"))
			siteMapUrl=U.getSectionValue(siteplanSec, "data-lazy-src=\"", "\"");
		U.log("sitemap Url2:: "+siteMapUrl);
		
		String siteMapHtml=U.getHtml(siteMapUrl, driver);
		String lotData[]=U.getValues(siteMapHtml, "<path id=\"Lot_", "\"/>");
		noOfUnit=lotData.length;
		lotCount=Integer.toString(noOfUnit);
		if(lotCount.equals("0"))
			lotCount=ALLOW_BLANK;
		
		}
		U.log("No. of units= "+lotCount);
		
		
		
		// ---notes-----//
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(communityName.trim(), url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(lotCount);

	}
	j++;
	
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
		
	}

	private String getQuickData(String communityName) throws Exception {
		// TODO Auto-generated method stub
		String homedata=ALLOW_BLANK;
		U.log(communityName);
		String quickHtm = U.getHTML("https://www.edgehomes.com/quick-move-ins/");
		String commIds[]= U.getValues(quickHtm, "<label><input type=\"checkbox\" name=\"communities[]\"", "</label></div>");

		//		String homes[] = U.getValues(quickHtm, "<div class=\"column marg-btm-40 search-item", "</a>");
		for(String id :commIds) {
			String nameFromid = U.getSectionValue(id, "<span>", "<");
			if(nameFromid.equals(communityName.trim())) {
				U.log(nameFromid);

				String newid = U.getSectionValue(id, "value=\"", "\"");
				String response = sendPostRequestAcceptJson("https://www.edgehomes.com/wp-admin/admin-ajax.php", "communities%5B%5D="+newid+"&action=search_init&search_type=quickmoveins&post_title=Quick+Move-Ins&submit=SEARCH&sortby%5B%5D=most-relevant");
				homedata = U.getSectionValue(response, "\"results_content\":\"", "\"postdata\":");
				U.log("QUICKkkkk"+communityName+":::::::communityName::::::"+newid);
			}
			
		}
	//	U.log(StringEscapeUtils.unescapeJava(homedata)+":this is homedata");
		return StringEscapeUtils.unescapeJava(homedata);
	}
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	        connection.setRequestProperty("Referer", "https://www.edgehomes.com/quick-move-ins/");
	        connection.setRequestProperty("x-requested-with", "XMLHttpRequest");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Mobile Safari/537.36");
	        connection.setRequestProperty("cookie", "_ga=GA1.2.2028738912.1624258528; _gid=GA1.2.2054251389.1624258528; __ctmid=60d037e00000a67d158cfd3d; __ctmid=60d037e00000a67d158cfd3d; epicid=91be7cc7cf0b6caae9f43c26ead77508720e41abaa03e3d305501210e0adbd94; epic_country=US; epic_allowed=true; _fbp=fb.1.1624258532889.969418810; __hstc=85882566.a1e360217bdd23d02c67cbb92a47ea78.1624258536646.1624258536646.1624258536646.1; hubspotutk=a1e360217bdd23d02c67cbb92a47ea78; __hssrc=1; _pin_unauth=dWlkPVlqaG1NRFl5WkRndE0yUXlNQzAwWldSakxXSXdPVEl0TmpZM04yTmpNMkUzTlRFMA; igGeoExec=1; PHPSESSID=svlur70lo08og76des4h4pg9ga; _uetsid=a9517d70d25d11eba44e93d751a757d9; _uetvid=a951d0d0d25d11ebbf1ebbb9ee35cbf8; __hssc=85882566.9.1624258536648");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
}
