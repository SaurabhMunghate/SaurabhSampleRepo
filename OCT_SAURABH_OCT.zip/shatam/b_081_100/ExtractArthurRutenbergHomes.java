/**
 * @author Parag Humane 
 * @date 16/01/2013
 * 
 */
package com.shatam.b_081_100;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractArthurRutenbergHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	private static String baseUrl = "https://arhomes.com/";
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractArthurRutenbergHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Arthur Rutenberg Homes.csv", a.data()	.printAll());
	}

	public ExtractArthurRutenbergHomes() throws Exception {
		super("Arthur Rutenberg Homes", baseUrl);
		LOGGER = new CommunityLogger("Arthur Rutenberg Homes");
	}

	HashMap<String,String> homeStories = new HashMap<String,String>();
	
	void init(String mainUrl)throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(U.getCache(mainUrl)));
		String line = null;
		while((line = br.readLine()) != null){
			String[] vals = line.split(",");
			homeStories.put(vals[0].replace("  ", " ").toLowerCase(),vals[1]);  
		}
		br.close();
	}
	
	
	int l=0;
	public void innerProcess() throws Exception {

		String mainHtm = U.getHTML("https://arhomes.com/search-results/");
		String allcomSec = U.getSectionValue(mainHtm, "let markers = [", "]");
		String communities[]= U.getValues(allcomSec,"{\"" , "}}");
		for(String com:communities) {
				String comUrl = U.getSectionValue(com, "\"link\":\"", "\"");
				comUrl = StringEscapeUtils.unescapeJson(comUrl);
				U.log(comUrl);
				addDetails(com,comUrl);
		}
		U.log("Total :--"+l);
		LOGGER.DisposeLogger();
	}

	
	int pageCount = 0;
	private void addDetails(String comSec, String url) throws Exception{
		//TODO : Execute for single community
//		if(!url.contains("https://www.arhomes.com/model/talise-1746/"))return;
		
//		if(url.contains("https://www.arhomes.com/model/shearwater-1520/"))return;
		
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl("*******REPEATED*******" + url);
			return;
		}
		if (url.contains("monceau-1483") || url.contains("/tidewater-1617/")) {
			LOGGER.AddCommunityUrl("*******RETURNED*******" + url);
			return;
		}
		LOGGER.AddCommunityUrl(url);
	
		String comHtml=U.getHTML(url);
		String commName = U.getSectionValue(comHtml, "<h1 class=\"title h3\">", "</h");
		commName = commName.replace("d&#8217;Este", "d'Este").replace(" – Auburndale Water Ridge", "");
		U.log("Comname::::::"+commName);
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		U.log(comSec);
		comHtml = comHtml.replace("<p><strong>"+commName+"</strong></p>", "").replaceAll("5 Sandy Creek Farm Road</strong></p>\\s*<p><strong>", "5 Sandy Creek Farm Road").replace("New Waverly", "<br>New Waverly,").replaceAll("<p><strong>Pinehurst 1629B</strong></p>|<p><strong>Silver Creek 1650F</strong></p>", "")
				.replaceAll("</strong><br />\\s*<strong>", ",");

		String addSec = U.getSectionValue(comSec, "\"address\":\"", "\"");
		if(addSec!=null) {
			addSec=U.removeComments(addSec);
			addSec = addSec.replace("<br>", ",").replace("Mountain Brook, AL 35223", " ,Mountain Brook, AL 35223").replace("Drive","Drive,").replace("Palm Coast,", ",Palm Coast,").replace("Georgia,", ",GA").replace("Windermere,", ",Windermere,");
			add= U.getAddress(addSec);
//			U.log("Add ::"+Arrays.toString(add));
		}
		if(add[0]==ALLOW_BLANK) {
			add[0]= U.getSectionValue(comSec, "\"address\":\"", "<");
			String newAddsec = U.getSectionValue(comHtml, "<h4 class=\"h3\">Schedule a Visit</h4>", "</p>");
			if(add[0]==null)add[0] = U.getSectionValue(newAddsec, "<p><strong>", "<");
			String tempAdd = U.getSectionValue(comSec, "<br>", "\"");
			U.log(tempAdd+addSec);
			
			if(tempAdd==null)add[3] = Util.match(addSec.trim(), "\\d{5}$");
			else add[3] = Util.match(tempAdd, "\\d{5}");
			if(add[3]!= null)
			add[1]=U.getCityFromZip(add[3]);
			if(tempAdd==null)add[2]= Util.match(addSec, ",\\s+([A-Z]{2})\\s+",1);
			else add[2]= Util.match(tempAdd, "\\s+[A-Z]{2}\\s+");;
			
		}
		if(add[0] != null && add[0].contains("phone_number")) add[0] = ALLOW_BLANK;
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]+ " Z:" + add[3]);
		lat= U.getSectionValue(comHtml, "lat: ", ",");
		lng = U.getSectionValue(comHtml, "lng: ", " };");
		
		
		if(lng!=null && !lng.contains("-"))
			lng = "-"+lng;
		
		if(lat.contains("26.1348789") && lng.contains("-81.8311359")) {
			// lat long show location in sea area so that changing..
			lat="26.142041";
			lng="-81.794865";
		}
		String[] latlng = {lat,lng};
		if((add[0] == ALLOW_BLANK ||add[3]== ALLOW_BLANK || add[3] == null) && lat!= null) {
			if(lat!= null || lat != ALLOW_BLANK){
				add = U.getGoogleAddressWithKey(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
			}
			geo = "TRUE";
		}
		
		if(add[2]== ALLOW_BLANK || add[2] == null && lat!= null) {
			if(lat!= null || lat != ALLOW_BLANK){
				add = U.getGoogleAddressWithKey(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
			}
			geo = "TRUE";
		}
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comHtml = comHtml.replace("&amp;#39;s", "'s").replace("$1M", "$1,000,000").replaceAll(" Million| million", ",000,000");
		comHtml=comHtml.replace("from the 140's to 360's", "from the 140,000 to 360,000");
		comHtml = comHtml.replace("0's", "0,000").replace("0Ks", "0,000").replace("00s", "00,000");
		comHtml=comHtml.replace("$700'000", "$700,000").replaceAll("living space, and 8,846 total square|living. With 5,830 square feet|<meta name=\"description\" content=\"[\\w\\s\\W]*\" />", "");
		
		String[] price = U
				.getPrices(
						comSec + comHtml,
						"Home design plans available from the low \\$\\d+,\\d+|<span>\\$(\\d,)?\\d{3},\\d{3} |from the \\d+,\\d+ to \\d+,\\d+|low \\$\\d+,\\d+ to \\$\\d,\\d+,\\d+|\\$\\d,\\d+,\\d+|<span>\\$\\d,\\d+,\\d+</span>|<td><p>\\$\\d+,\\d+|<span>\\$\\d+,\\d+|\\$\\d+,\\d+|the low \\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		 String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		if(comHtml==null)
			comHtml=ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(comHtml,
					"living space with a total of \\d,\\d{3}.|Talise is a \\d,\\d{3} square|This \\d{4} square foot home|\\d,\\d{3} total square feet|\\d,\\d{3} sq. ft.|\\d+,\\d+sq. ft.|\\d{1},\\d{3}sq. ft.</span><br />|\\d{4} Square Feet|around \\d+,\\d+SF|\\d{1},\\d+ square ft|\\d{1},\\d+ square feet|\\d{1},\\d{3} SF|to \\d,\\d{3}-square-foot|\\d,\\d{3} square foot", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		comHtml = comHtml.replaceAll("farmhouse design", "Farmhouse in a community").replace("Coastal Contemporary design", "coastal-style homes Contemporary design")
				.replace("Luxury Abounds", "Luxury homes Abounds").replaceAll("Luxury abounds in the master suite|luxury awaits in the master suite|luxury details are complemented|luxury keynotes the interior", "luxury homes keynotes the interior")
				.replaceAll("present luxurious|luxurious plan comprising|Luxury and understated elegance|ultimate luxury and privacy|Rustic Luxury|home offers luxury|Luxury Redefined", "luxury homes")
				.replace("custom home", "custom home nestled").replaceAll("Luxury and Style in the| model is coming soon|Wellness Meets Luxury", "luxury homes").replace("Traditional Style in Evans Farm", "Traditional exterior").replace("Farmhouse custom built", "exceptional custom home");
		
//		U.log(comHtml);
		comHtml=comHtml.replace("designing custom home nestleds now", "");   //Luxury Custom Homes Builder | AR Homes
		String pType = U.getPropType((comHtml).replace("Farmhouse welcomes friendly", "Farmhouse Style").replaceAll("-Patio-|participationChance|Luxury Custom Homes Builder|participationChance|Luxury Custom Homes Builder|Banyan Point Condominiums|craftsmanship|SingleFamilyResidence|Carriage House Blvd",""));
//		U.log("html::::"+Util.matchAll(comHtml, "[\\s\\w\\W]{70}luxury[\\s\\w\\W]{30}",0));
		U.log("pType: "+pType);
		
		
		comHtml = comHtml.replaceAll(">Stories</label>\\s*<span>", "story ");
		String dPType = U.getdCommType(comHtml.replaceAll("floor|Floor|First level accommodations", ""));
//		U.log("html::::"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}bi-level[\\s\\w\\W]{30}",0));
		U.log("dType: "+dPType);
		
		String pStatus = U.getPropStatus(comHtml);
		String note = U.getnote(comHtml);
		add[0]=add[0].replace("Road, NE", "Road NE").replace("Blvd, West", "Blvd West").replace(",", "");
		commName = commName.replace("Pinehurst 1629B At Villa d&#8217;Este At Miromar Lakes", "Pinehurst 1629B At Villa D'Este At Miromar Lakes");
//		U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}48[\\w\\s\\W]{30}",0));
		comHtml = comHtml.replace("lakeside and golf community", "lakeside community and golf community");
		
		if(url.contains("https://www.arhomes.com/model/bayshore-1688/"))pType = pType.replace(", Luxury Homes", "");
//		if(url.contains("https://www.arhomes.com/model/fontainebleau-1657"))maxSqf="5465";
		
//		comHtml=comHtml.replace("Country Club Drive <br>", "");
		String cType=U.getCommunityType((comHtml+comSec).replaceAll("elongated|Country Club Drive <br>|picturesque lake community", ""));
//		cType=cType.replace("Country Club Drive <br>", "");
//		U.log("html::::"+Util.matchAll(comSec, "[\\s\\w\\W]{30}Country Club[\\s\\w\\W]{30}",0));
		U.log("ctype:  "+cType);
//		if(url.contains("https://www.arhomes.com/model/baxter-18775/")) {
//			cType="Lakefront Community";
//			
//			pType=pType+", Luxury Homes";
//		}
//		if(url.contains("https://www.arhomes.com/model/baxter-18775/")||url.contains("https://www.arhomes.com/model/claremont-1595/")) {
//			pType=pType+", Luxury Homes";
//		}
		
		
		
		data.addCommunity(commName, url, cType);
		data.addAddress(add[0].toLowerCase(), add[1].replace("O&#8217;Lakes", "O'Lakes").toLowerCase(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dPType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
	}



}