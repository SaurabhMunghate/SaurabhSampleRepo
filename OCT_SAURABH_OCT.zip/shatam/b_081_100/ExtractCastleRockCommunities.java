package com.shatam.b_081_100;

import java.util.HashSet;
import java.util.List;

import org.apache.jasper.tagplugins.jstl.core.Catch;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCastleRockCommunities extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	int j=0;
	public int inr = 0;
	static int dup = 0;
	static int d = 0;
	static String builderUrl = "https://c-rock.com";
	public static WebDriver driver;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCastleRockCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "CastleRock Communities.csv", a.data().printAll());
		U.log(dup);
		U.log(d);
	}

	public ExtractCastleRockCommunities() throws Exception {

		super("CastleRock Communities", builderUrl);
		LOGGER = new CommunityLogger("CastleRockCommunities");
	}

	public void innerProcess() throws Exception {

		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String url = builderUrl + "/find-your-new-home/";
		String html = U.getHtml(url,driver);

		String values[] = U.getValues(html, "<div class=\"card_row card-row-3 \"", "See Details</span></button>");
		U.log(values.length);
		for (int i = 0; i < values.length; i++) {

			if (values[i].contains("mercurycustomhomes")) {
				d++;
				continue;
			}

			// U.log(url + values[i]);
			String url1 = builderUrl + U.getSectionValue(values[i], "href=\"", "\"");
			
			// GetComURl(url1,values[i]); //
			addDetails1(url1, values[i]);
			// U.log(url1);

		}
//		addDetails1(builderUrl + "/find-your-new-home/houston/build-on-your-lot", ALLOW_BLANK);

		System.out.println("Total Count: " + hashSet.size());
	//	try {driver.close();}catch (Exception e) {}
		LOGGER.DisposeLogger();
		driver.close();
	}

	private HashSet<String> hashSet = new HashSet<String>();

	// =====================New code By
	// upendra=========================================

	//TODO :
	private void addDetails1(String url, String oldhtml) throws Exception {
//		if(j>=50 && j<=55)
		//if(j>=51)
		//try{
		{
			

		
		// //--Run for single execution

		 if(url.contains("https://c-rock.com/find-your-new-home/build-on-your-lot/"))return;
	//
//*************************Single Run>>>
	// if(!url.contains("https://c-rock.com/austin-community-detail/Santa-Rita-Ranch-67715"))return;
		String html = U.getHtml(url,driver);
		
//		String rem = U.getSectionValue(html, "<!-- ========= JS Section ========= -->", "</html>");
//		if(rem!=null)
//			html = html.replace(rem, "");
		
		U.log("count:::::  "+j);
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url + "---------------------------------repeat");
			return;
		}
		if(url.contains("https://c-rock.com/find-your-new-home/rim-rock/") || url.contains("https://c-rock.com/find-your-new-home/build-on-your-lot/")) {// 22 Oct 2021
			LOGGER.AddCommunityUrl("======= Return ============= "+url);
			return;
		}
		LOGGER.AddCommunityUrl(url);

		U.log("URL:: "+url);
		//U.log("Region:: "+oldhtml);
				

		String homehatml = "";
		int totalHomes=0; 
		String home=ALLOW_BLANK;
         String commName=U.getSectionValue(oldhtml, "card_link\"=\"\">","</span>");
		
		if (commName != null)
			commName = commName.replace("amp;", "").replace("–", "-");
		U.log("Community name :" + commName);
		
		  
		try {
		String[] homesec = U.getValues(html, "<div class=\"card_row card-row-3", "See Details</span></button>");
		 totalHomes=homesec.length;
		
		U.log("Total Home : " + homesec.length);
		
		for (String s : homesec) {
			String url1 = "https://c-rock.com" + U.getSectionValue(s, "<a href=\"", "\"");
			U.log("homeUrl :"+url1);
			try {
			 home +=" "+ U.getHtml(url1,driver);
			homehatml = homehatml + U.getSectionValue(home, "class=\"descriptionColumn card_titles\">", "SUBMIT</button>")
			+ U.getSectionValue(home, "data-inline-binding=\"dynamic_page_collection.Desc\" data-uw-styling-context=\"true\">", "</div>");
			}catch(Exception e) {}
		}
		}
		catch(NullPointerException b) {}
	
	/*	
		String AllHomesData=ALLOW_BLANK;
		String myHomeUrlSec[]=U.getValues(html, "Communities<span class=\"icon icon-angle-right\">","Move-In Ready Homes");
		for(String MyhomeSec:myHomeUrlSec) {
			//U.log("JJJJJ"+MyhomeSec);
			String myHomeRegName=U.getSectionValue(MyhomeSec, "/move-in-ready-homes-", "\"");
		    myHomeRegName=myHomeRegName.replace("-", "%20");
	/*	dateeeeee 21feb	String myHomereg=U.getSectionValue(MyhomeSec, "<a href=\"","\"");
			U.log("home rewgion url"+myHomereg);
			U.log(builderUrl+myHomereg);
			
			String homeRegHtml=U.getHtml(builderUrl+myHomereg,driver);
			String[] homeCitySec=U.getValues(homeRegHtml, "<span class=\"card-group-name\">", "See Details");
			for(String homeCity:homeCitySec) {
				String homeUrl=U.getSectionValue(homeCity, "href=\"", "\">");
				U.log("home URL"+homeUrl);
				String homeData=U.getHtml(builderUrl+homeUrl, driver);
				String commfrmHome=U.getSectionValue(homeData, "\"dynamic_page_collection.PlanName\"", "</a>");
				if(commfrmHome.contains(commName)) {
					AllHomesData+=" "+homeData;
			     }else
			    	 continue;
			}
		    
		    String homeDataHUrl="https://www.c-rock.com/_dm/s/rt/actions/sites/069fba31/collections/"+myHomeRegName+"%20Homes/ENGLISH";
		    U.log(">>>>>"+"https://www.c-rock.com/_dm/s/rt/actions/sites/069fba31/collections/"+myHomeRegName+"%20Homes/ENGLISH");
		    String homeDataHtml=U.getHtml(homeDataHUrl, driver);
		    
		    
		    
		    
		}*/
	//	String mychk=U.getHtml("https://www.c-rock.com/cobalt-collection", driver);
			
			//String myHomeUrlSec[]=U.getValues(html, "data-home-id=\"", "See Details");
			
		// ===========================commmunity
		// name====================================
		String Geo = "FALSE";
//		String commName = U.getSectionValue(html, "<h1", "</h1>");
//		
//		if(commName!=null)
//			commName = U.getSectionValue(commName, "data-inline-binding=\"dynamic_page_collection.Name\">", "<");
	
		
		// ============================Address
		// section=====================================
		
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		//date feb 2022
		String myAddressSec=U.getSectionValue(oldhtml,"<a href=\"https://www.google.com/maps?z=18&amp;q=","\" target=\"_blank\">");
		U.log("MY AFFRESS LINE"+myAddressSec);
		
		//String addSec = U.getSectionValue(html, "<span class=\"address-text\"", "<");
	//	U.log("addSec: "+myAddressSec);
		if(myAddressSec!=null) {
			String zip=Util.match(myAddressSec, ",\\d{5}", 0);
			U.log("ZIPO"+zip);
			myAddressSec=myAddressSec.replace(zip, "");
			zip=zip.replace(",", " ");
			myAddressSec=myAddressSec+zip;
			add = U.getAddress(myAddressSec);
		}
		
		U.log("Address: " + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
		
		String latSec = U.getSectionValue(html, "https://maps.google.com/maps?ll=", "&");
		if(latSec!=null) {
			latLong = latSec.split(",");
		}
		if(latSec==null) {
			String latSec1=U.getSectionValue(html, "function initMapmap()","});");
			if(latSec1!=null) {
			latSec=U.getSectionValue(latSec1, "myLatLng = {", ";");
			latLong[0]=U.getSectionValue(latSec,"lat: ", ",");
			latLong[1]=U.getSectionValue(latSec, ", lng:", "}");
			}
		}
		U.log("latSec"+latSec);
		U.log("LAT :- " + latLong[0] + "  " + latLong[1]);

		if (latLong[0] == null||latLong[0]==ALLOW_BLANK) {
			latLong[0] = ALLOW_BLANK;
			latLong[1] = ALLOW_BLANK;
			latLong=U.getlatlongGoogleApi(add);
			Geo = "TRUE";
		}
		
		
			add[0] = add[0].replaceAll("The Preserve at Lakeway by CastleRock Communities|[b|B]y CastleRock Communities|Model Close|Now Selling -|Coming Soon|null", "").trim();
		//.replace(commName, "")
			if (add[0] != null&& add[0].contains(commName)) 
			{
				add[0]=null;
			}
		if(url.contains("https://c-rock.com/houston-community-detail/Westwood-72818")) {
			Geo = "False";	
		}
		U.log("LAT :- " + latLong[0] + "  " + latLong[1]);
		if(add[0]==null||add[0]==null||add[0].isEmpty()) {
			add=U.getAddressGoogleApi(latLong);
			Geo = "TRUE";
		}

		// ===============================Sq.FT
		// Section====================================
		//U.log(oldhtml);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html + oldhtml,
				"\\d{4} - \\d{4} SF|\\d{4} SF",
				0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :-" + minSqf + "  maxSqf :-" + maxSqf);

		// ===============================Price
		// section=======================================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replace("190’s", "$190,000");
		html = html.replace("0’s", "0,000").replace("3 million", "3,000,000");
		
		String[] price = U.getPrices(
				(html + oldhtml),">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</span>|Starting at \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

		U.log("minP :-" + minPrice + "  maxP :-" + maxPrice);

		// ===============================Community type
		// section==================================
		html = html.replace("lakefront views with a fishing lake", "lakefront community views with a fishing lake");
		String Type = U.getCommunityType(
				(html + oldhtml).replaceAll("apiText = \"Green Community\"|IsGated|config.Gated|apiText = \"Master Planned\";", "").replaceAll("Gated Silver| Gated Section Silver Series Features|Golf and Country Club", "golf communities and Country Club"));

		// ==============================Prop-Type
		// section========================================

		html = html.replace("luxury standard features", "luxury homes standard features").replace("The luxury of hill country living in San Marcos", "The luxury homes of hill country living in San Marcos")
				.replace("luxury touches", "luxury home").replace("giving homebuyers a custom feel", "exceptional custom home").replaceAll("luxury baths|luxury master|Live in luxury|luxurious baths|Luxurious Master", "");
		
		homehatml = homehatml.replaceAll("luxury baths|luxury master|luxury touches|luxurious baths|Luxurious Master|Custom Home Building Seminar", "");
		//homehatml is replaced by  home date feb2022
		U.log("Propo"+Util.matchAll(html+home+homehatml,"[\\w\\W\\s]{50}Condominium[\\w\\W\\s]{50}", 0));
		String pType = U.getPropType(
				(home+homehatml + html).replace("living in luxury","Luxury Homes")
				.replaceAll("class=\"api-text \">Single Family</span>|apiText = \"Multi Family\";|IsTownHome|CondoOrTownhome|IsCondo|CondoOrTownhome|apiText = \"Single Family\";|Luxury  Homes</a>|uxury-homes/|luxury baths|Courtyard	512", "").replaceAll("Custom Homes|custom home", "kind custom home").replace("Custom Home Building Seminar", ""));

		// ================================DerivedPtye
		// section=====================================
//		U.log(Util.matchAll(html + oldhtml, "[\\w\\s\\W]{30}luxury[\\w\\s\\W]{30}", 0));

		html = html.replaceAll(
				"Spring Ranch|Springs Ranch|Alamo Ranch|Massey Ranch| Swayback Ranch|rAnchor|George Ranch |Rancho|rancho|Ranch Mall|Wolf Ranch|Ranch Sienna",
				"");
		html = html.replace("-Ranch", "").replace("-ranch", "");
		String derivedPType = U.getdCommType((html + oldhtml+homehatml+home).replace("Three stories", " 3 Story ")
				.replaceAll("Childrens Ranch|Ranch Road|Branch| Swayback Ranch|George Ranch|Alamo Ranch|rAnchorBackground|Star Ranch|Luckey Ranch|Laurel Mountain Ranch|Kid Ranch", ""));
		

		// ===============================Status
		// Section=========================================
		String pStatus = ALLOW_BLANK;
		pStatus = U.getPropStatus((html+ oldhtml).replace("lakefront home sites are available", "lakefront home sites available")
				.replaceAll("comingSoonImage|grandOpeningImage|closeoutImage|IsCloseOut|<h4 class=\"tab-text\">QUICK MOVE-INS</h4>|CG Coming Soon Grand Opening|X - Close Out|G -Grand Opening|C -Coming Soon|Homes Available Now|[M|m]ove-[I|i]n", ""));

//		U.log("MMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}Move-in[\\s\\w\\W]{30}", 0));
		 
		 //if(html.contains("/homeSold-"))
	//	if(totalHomes>0) {
		//	 String[] soldValues= U.getValues(html,"<img class=\"card_spec_sale_image","/homeSold-");
		String homeregHtml=ALLOW_BLANK;
		String availValues[] = U.getValues(html, "<div class=\"card_row card-row-3", "See Details</span></button>");
		int count=0;
		for(String avail : availValues) {
			if(avail.contains("-home-details"))
				count++;
		/*	String homeUrl=U.getSectionValue(avail,"href=\"", "\">");
			homeUrl=builderUrl+homeUrl;
			homeregHtml+=" "+U.getHtml(homeUrl, driver);
			*/		
					
		}		
	
		
		if (!pStatus.contains("Homes Available Now")&&!pStatus.contains("Quick") && count>0) {//&& count>soldValues.length ) {		
			if (pStatus.length() < 4) {
				pStatus = "Quick Move-in";//"Homes Available Now";
			} else {
				pStatus = pStatus +", Quick Move-in"; //", Homes Available Now";
			}
		}
		//}
		
		if(oldhtml.contains("/coming-soon-banner.png\""))
			if (pStatus.length() < 4) {
				pStatus = "Coming Soon";
			} else {
				if(!pStatus.contains("Coming Soon"))
				pStatus = pStatus + ", Coming Soon";
			}
		
		if(oldhtml.contains("/grand-opening-banner.png\""))
			if (pStatus.length() < 4) {
				pStatus = "Grand Opening";
			} else {
				if(!pStatus.contains("Grand Opening"))
				pStatus = pStatus + ", Grand Opening";
			}
		pStatus=pStatus.replace("Coming Soon, Coming Soon 2023", "Coming Soon 2023");
		// ==================================Notes
		// Section======================================
		String notes = U.getnote(html);

		if (url.contains("https://c-rock.com/find-your-new-home/build-on-your-lot/")) {
			commName="Build On Your Lot with CastleRock";
			add[0]="7670 WOODWAY";
			add[1]="HOUSTON";
			add[2]="TX";
			add[3]="77063";
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			Geo="TRUE";
			notes="Address And Latlong Taken From Contacts";
		}
		if (add[0] == null || add[0].trim().length() < 4 && add[3] == null || add[3].trim().length() < 4) {
			add = U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			Geo = "TRUE";
		}
		
		add[0] = add[0].replaceAll(
				"Please contact Andrea Chase at 832-477-7740 for more information.|Please contact Craig Lobel at 281-733-2811 for more information.",
				"");
		add[1] = add[1].replace(",", "");

		if(url.contains("https://c-rock.com/find-your-new-home/sunterra/")) {
			add[1]="Katy";
			add[2]="TX";
			add[3]="77493";
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			Geo = "TRUE";
		}
		if(url.contains("https://c-rock.com/houston-community-detail/Caney-Mills-160345")) {
			add[1]="Conroe";
			add[2]="TX";
			add[3]="77303";
			latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			Geo = "TRUE";
		}
		if (add[0] == null || add[0].trim().length() < 4) {
			String add1[] = U.getAddressGoogleApi(latLong);
			if(add1 == null) add1 = U.getAddressHereApi(latLong);
			add[0] = add1[0];
			Geo = "TRUE";
		}
		add[0]=add[0].replace("7670 WOODWAY", "7670 Woodway");
		add[1]=add[1].replace("HOUSTON", "Houston");
			if(url.contains("https://c-rock.com/find-your-new-home/magnolia-springs"))add[0]="Lily Bean";	
		if(pStatus.contains("New Homes Now Available, Homes Available Now"))pStatus=pStatus.replace("New Homes Now Available, Homes Available Now", " Homes Available Now");
		if(url.contains("/houston/build-on-your-lot"))pStatus="Homes Available Now";//pStatus = "Few Home Sites Available";
		if(url.contains("/find-your-new-home/preserve-at-lakeway/"))pStatus = "Few Home Sites Available";
		if(url.contains("/find-your-new-home/sierra-vista/"))pStatus = pStatus.replace("100% Financing", "100% Financing Available");
		
		if(add[0].trim().startsWith("-"))add[0] = add[0].replace("-", "");
		
		 add[0]=add[0].replace(" @", " &");
		notes = U.getnote(html + oldhtml);
		
		if(html.contains("<h2 style=\"text-align: center;\">Coming Soon Spring 2022!</h2> "))
			if(pStatus!=ALLOW_BLANK)
				pStatus += ", Coming Soon Spring 2022";
			else
				pStatus = "Coming Soon Spring 2022";
		
		if(oldhtml.contains("<p class=\"item marketingDescription\">Now Open!</p>"))
			if(pStatus!=ALLOW_BLANK)
				pStatus += ", Now Open";
			else
				pStatus = "Now Open";
		
//		if(url.contains("https://c-rock.com/houston-community-detail/Potomac-96387"))
//			add[0] = "1917 Potomac Dr";
		
		if(url.contains("find-your-new-home/stone-creek-ranch/"))
			pStatus=pStatus+", Lake Front Lots Available";
		pStatus = pStatus.replace("Closeout Community, ", "Closeout, ");
		
		data.addCommunity(commName, url, Type);
		data.addAddress(add[0].replaceAll(">|,", "").trim(), add[1].trim().replace(",", ""), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), Geo);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(notes);

	}
		j++;
//		}catch (Exception e) {}
	}
	// TODO Auto-generated method stub
	
}