/** @author Parag Humane
 *  @date 19/04/2013 
 */
package com.shatam.b_081_100;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHHHunt_Apartment extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	
	public ExtractHHHunt_Apartment() throws Exception {
		super("HHHunt Corporation - HHHunt Apartments","https://www.hhhunt.com/apartments.htm");
		LOGGER = new CommunityLogger("HHHunt Corporation - HHHunt Apartments");
	}

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractHHHunt_Apartment();
		a.process();
		FileUtil.writeAllText(	U.getCachePath()+"HHHunt Corporation - HHHunt Apartments.csv", a.data()
						.printAll());
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.hhhunt.com/apartments.html");
		String section = U.getSectionValue(html,"<div class=\"map-listing-wrapper\">","<div class=\"section-brown\"");
//		U.log("sec::"+section);
		String[] comUrlSections = U.getValues(section, "<li>", "</li>");
	
		for(String comSec : comUrlSections){
//			U.log(comSec);
			String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
			if(comUrl.contains("/apartment-communities/")){

				String regHtml = U.getPageSource(comUrl);

				String comSections1[] = U.getValues(regHtml, "<div class=\"apartment-section\">", "View Community");

				if(comSections1.length == 0)
					comSections1 = U.getValues(regHtml, "<h2 class=", "<div class=\"community-button\">");
				for(String comSec1 : comSections1){
//					U.log(comSec1);
					String comUrl1 = U.getSectionValue(comSec1, "href=\"", "\"");
					comUrl1 = comUrl1.replace("aws/index.htm", "");
//					U.log(comUrl1);
					findCommunityDetails(comUrl1,comSec1);
				}
			}
			else if(!comUrl.contains("/apartment-communities")){
//				U.log("--"+comUrl);
				findCommunityDetails(comUrl,comSec);
			}
		}
		LOGGER.DisposeLogger();

		
		
	}
	int j =0;
	private void findCommunityDetails(String comUrl, String comSec) throws Exception {
//		if(j == 7)
		{
//			if(!comUrl.contains("http://www.abberlywaterstone.com/"))return;
			U.log("Count ==="+j);
			U.log(comUrl);
			U.log("file name===="+U.getCache(comUrl));
			String html = U.getPageSource(comUrl);
			
//			U.log(comSec);
			//============== Community Name =========================
			String communityName = U.getSectionValue(html, "<h3", "</h3>");
		
//			U.log(communityName);
			if(communityName != null && communityName.contains("span")){
					communityName = communityName.replaceAll("\\s{2,}", "");
					communityName =  Util.match(communityName, "<span\\s?>(.*)?</span>");
			}
			if(communityName == null){
				communityName = U.getSectionValue(comSec, " <a class=","</a>");
				if(communityName != null)
					communityName = communityName.replaceAll("(.*)?\">", "");
			}
			if(communityName == null)
				communityName = U.getSectionValue(html, "itemprop=\"name\">", "</span>");
			communityName = communityName.replaceAll("style=\"color: #ffffff;\"> |<span>|</span>|<span >|Apartment Homes| Apartments|style=\"color: #ffffff;\">", "").trim();
			U.log("commName ::"+communityName);
			
			//================ Address ==========================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };			
			add[0]=U.getSectionValue(html, "itemprop=\"streetAddress\">", "</span>");
			
			add[1]=U.getSectionValue(html, "addressLocality\">", "</span>");
			add[2]=U.getSectionValue(html, "addressRegion\">", "</span>");
			add[3]=	U.getSectionValue(html, "postalCode\">", "</span>");
			

			U.log("Add ::"+Arrays.toString(add));
			
			if(add[0] == null && add[1] == null){

				String addSec = U.getSectionValue(html, "</h3>", "<br />");
				if(addSec == null)
					addSec = U.getSectionValue(html, "</h3>", "<br/>");
				if(addSec == null)
					addSec = U.getSectionValue(html, "</h3>", "<p style=");
				
				U.log(addSec);
				addSec = addSec.replace("Drive Fredericksburg", "Drive, Fredericksburg");
				U.log(addSec);
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}

			//============== LatLng ===================
			String geo = "false";
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			if (add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);
				geo="TRUE";
			}
			
			//=========== Floor Plans =======================

			String floorPlanSec = U.getSectionValue(html, "FLOOR PLANS", "</ul>");
			U.log(floorPlanSec);
			String floorBedRoomHtmls = null;
			if(floorPlanSec != null){
				floorPlanSec = U.removeComments(floorPlanSec);
				String [] floorBedroomUrls = U.getValues(floorPlanSec, "<a href=\"", "\"");
				for(String floorBedroomUrl : floorBedroomUrls){
					if(floorBedroomUrl.contains("community-map.html"))continue;
					if(floorBedroomUrl.contains("site-plan.htm"))continue;
					U.log("::::::::::::::::"+comUrl+floorBedroomUrl);
					floorBedRoomHtmls += U.getHTML(comUrl+floorBedroomUrl);
				}
			}
				
			
			String florLink = ALLOW_BLANK, florHtml = ALLOW_BLANK;

			if (comUrl.contains("http://www.austonwoodsliving.com")	|| comUrl.contains("foxridgeliving.com")|| (comUrl.contains("www.thegardensliving.com")))
				florLink = comUrl + "/floor-plans.html";
			else
				florLink = comUrl + "/floor-plans.htm";

			florHtml = U.getHTML(florLink);
			String floorHtml = "";
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String sqft[] = U
					.getSqareFeet(
							floorHtml + florHtml+floorBedRoomHtmls,
							"Sq. Ft.:</strong> \\d{3,4} square feet|<p>\\d?,?\\d{3} square feet|Floor: \\d?,?\\d{3} square feet|\\d,\\d{3} Sq.Ft.|\\d{3,4} Sq.Ft. |\\d?,?\\d{3} sq. ft.</p>|\\d+sq.ft.|\\d+ sq.ft.|\\d,\\d+ with|\\d+ sq. ft.</strong>|\\d+-\\d+ sq. ft.|\\d+ - \\d+ Sq.Ft|[1-9]\\d{3,4}+ Sq. Ft.|\\d{1},\\d{3} Sq. Ft.|\\d{3,4} Sq. Ft.",
							0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	
			// if(latLng[1].contains("21.044108"))latLng[1]=ALLOW_BLANK;
			communityName = communityName.replaceAll(" Apartment|Logo", "");
			add[3]=Util.match(add[3], "\\w{5}");
			
			//add[0]=add[0].trim().replace(". 100 Ashton Pointe Blvd.", "").replace(". 1000abberly Village Cir.", "1000 Abberly Village Circle");
			
			add[0]=add[0].replace("2015 abberly village apartments.", "");
			add[0]=add[0].replaceAll("1000abberly village cir.", "1000 Abberly Village Cir.,");
			
			add[0]=add[0].replace("2014 ashton pointe apartment homes.", "");
			add[0]=add[0].replaceAll(" 100 ashton pointe blvd.", "100 Ashton Pointe Blvd.,");
		
			U.log("addresss2-==="+add[0]);
			
			add[0]=add[0].replaceAll("\\.|,", "");
			U.log("addresss3-==="+add[0]);
//			if(comUrl.contains("waldenpondliving"))return;
			add[0]=add[0].replace("3 style=\"color:#fff;margin-top: 15px;\"> abberly crest apartment homes</h3>","").replace("2016 foxridge apartment homes", "").replace("2016 ashton pointe apartment homes", "");
			
			//============ Community Type =====================
			html = html.replaceAll("gated entrance", "");
			String commtype=U.getCommunityType(html);
			if(comUrl.contains("http://www.liveabberlywestashley.com"))
			{
				commtype="Resort Style";
			}
			String protype=ALLOW_BLANK;
			html=html.replaceAll("are luxurious|rent luxury|Rent a luxury|luxurious apart|trees, luxurious|and luxurious|luxury","");
			protype=U.getPropType(html+"Apartment Homes");
			if(comUrl.contains("http://www.abberlycrestliving.com/"))
			{
				protype="Apartment Homes,Patio Homes";
			}
			communityName = communityName.replaceAll("Apartment|Apartments|Logo", "");
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			add[1]=add[1].replace(",", "");
			data.addCommunity(communityName, comUrl, commtype);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),add[3].trim());
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(protype, U.getdCommType(html));
			data.addPropertyStatus(ALLOW_BLANK);
			data.addPrice(ALLOW_BLANK, ALLOW_BLANK);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(ALLOW_BLANK);

			
			
		}
		j++;
	}

	
	
}