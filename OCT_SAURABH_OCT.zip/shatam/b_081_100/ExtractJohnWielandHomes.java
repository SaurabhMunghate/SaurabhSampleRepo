/*
 * @author Aditya.
 */
package com.shatam.b_081_100;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;

import javax.sound.sampled.Port;
import javax.swing.text.html.HTML;

import org.apache.regexp.recompile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractJohnWielandHomes extends AbstractScrapper {
	static int duplicates = 0;
	public static int count = 0;
	public static String BASE_URL = "https://www.jwhomes.com";
	WebDriver driver = null;
	CommunityLogger LOGGER;
	static int j = 0;
//=====================================================================================================================================================

	public ExtractJohnWielandHomes() throws Exception {
		super("John Wieland Homes and Neighborhoods", "https://www.jwhomes.com/");
		LOGGER = new CommunityLogger("John Wieland Homes and Neighborhoods");
	}  

//=====================================================================================================================================================
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractJohnWielandHomes();
		//U.logDebug(true);
		a.process();
		// U.log("count=" + count);
		FileUtil.writeAllText(
				U.getCachePath()+"John Wieland Homes and Neighborhoods.csv", a.data().printAll());
		U.log(duplicates);
		U.log(count + ":: Urls Null...");
	}
//=====================================================================================================================================================InnerProcess
	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String mainHtml = U.getHtml("https://www.jwhomes.com/homes",driver);
		String regionSection = U.getSectionValue(mainHtml, "  <section class=\"Card-container container \">", "</main>");
//		U.log(regionSection);
		String regLink[] = U.getValues(regionSection, "<li><a style=\"color: #333333; font-size: 22px;\" href=\"", "\"><strong>");
		U.log("regLink=="+regLink.length);
		String regHtml="";
		for(String regUrl : regLink)
		{
			
			regUrl = "https://www.jwhomes.com"+regUrl;
			U.log("region url >>>>>>"+regUrl);
			regHtml = U.getHtml(regUrl, driver);
			
			String comSections[] = U.getValues(regHtml, "<div class=\"ProductSummary__community row", "Request Info");
			U.log(comSections.length);
			for(String sec:comSections) {
				
				
					//U.log(sec+"\n---------------------------------------------------------------------------------------------------------------\n");
				
//				try {
					ComDetails(sec);
//				} catch (Exception e) {}
			}
			//if(regUrl.contains("georgia"))return;
			//String regHtml = U.getHtml(regUrl, driver);
			/*if(!regUrl.contains("vinings")) {
				String regMissingUrl="https://www.jwhomes.com/homes/georgia/atlanta/vinings";
				regHtml=getHtml1(regMissingUrl,driver);
				U.log(regMissingUrl+"region url");
				String comSection = U.getSectionValue(regHtml, " <div class=\"CommunitySummary-detail", "View");
				ComDetails(comSection);
			}*/
			
//			   regHtml=getHtml1(regUrl,driver);
//			//}
//			//U.log("regHtml=="+regHtml);
//			   String comSection[] = U.getValues(regHtml, " <div class=\"CommunitySummary-detail", "View");
//			   U.log("total community ---> "+comSection.length);
//			   for(String comSec : comSection){
//				   String linksec=U.getSectionValue(comSec, "<h1>", "</h1>");
//				   U.log("linksec=="+linksec);
////				   ComDetails(comSec);
//			  }
//			   if(!regUrl.contains("vinings")) {
//					String regMissingUrl="https://www.jwhomes.com/homes/georgia/atlanta/vinings";
//					regHtml=getHtml1(regMissingUrl,driver);
//					U.log(regMissingUrl+"region url");
//					String comSec = U.getSectionValue(regHtml, " <div class=\"CommunitySummary-detail", "View");
////					ComDetails(comSec);
//				}
//			   if(!regUrl.contains("/atlanta/atlanta")) {
//					String regMissingUrl1="https://www.jwhomes.com/homes/georgia/atlanta/atlanta";
//					regHtml=getHtml1(regMissingUrl1,driver);
//					U.log(regMissingUrl1+"region url");
//					String comSec = U.getSectionValue(regHtml, " <div class=\"CommunitySummary-detail", "View");
////					ComDetails(comSec);
//				}
		}
		
		LOGGER.DisposeLogger();
		try{driver.close();driver.quit();}catch (Exception e) {}
	}
//========================================================================================================================================================ComDetails
	private void ComDetails(String comSection) throws Exception {
		//if(j==1)
//		try {
//		U.log("Hello in here::::::::");
	if(comSection.contains("www.pulte.com/homes"))return;
	
	//LOOK BELOW: Single Run following - don't do it from here. LOOK BELOW.
//	if(!comSection.contains("homes/south-carolina/charleston/charleston/wando-village-210606")) return;
		{
			
			if(comSection==null)return;
			
			String comSec = comSection.replace("href=\"tel:", "");
			comSec = comSec.replace("href=\"https://maps", "");
			
			String communityUrl = U.getSectionValue(comSec, "data-href=\"", "\"");
			
			U.log(j+" communityUrl: " + communityUrl);
			
			
			U.log("---------------------------------------------------------------------------------------------------------------------------");
			// U.log(comSec);
			if (communityUrl != null) {
				String GEO = "FALSE";
				//========================================================================================================================================Community Url
				if (communityUrl.contains("http")) {
					U.log("Contains HTTP");
				} else {
					communityUrl = BASE_URL + communityUrl;
				}
//				if(communityUrl.contains("charleston/mt-pleasant/dunes-west-golf-and-river-club-210202")) {
//					LOGGER.AddCommunityUrl(communityUrl+ "\t*********Returned main community has 6 sub communites******\t");
//					duplicates++;
//					return;
//				}
				if (data.communityUrlExists(communityUrl)) {
					LOGGER.AddCommunityUrl(communityUrl+ "\t*********Repeated******\t");
					duplicates++;
					return;
				}
				LOGGER.AddCommunityUrl(communityUrl);

//--------------TODO : Run for single execution
// if(!communityUrl.contains("https://www.jwhomes.com/homes/south-carolina/charleston/mt-pleasant/dunes-west-golf-and-river-club-210202"))return;
	
				U.log("Community Url::" + communityUrl);
				String comHtml=U.getHtml(communityUrl,driver);
				
				String comHtml1 = comHtml;
//				if(comHtml1.contains("<h2>Homesite Map </h2>")) {
//					String section = U.getSectionValue(comHtml, "<h2>Homesite Map </h2>", "Open Interactive Map");
//					U.log("section: "+section);
//				}

				
				comSec = comSec
						.replace(
								"{ href: 'https://maps.google.com/maps?q=' + Latitude + ',' + Longitude, target: '_blank' }",
								"");
				String lat = ALLOW_BLANK, lng = ALLOW_BLANK;String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
//				String latsec = U.getSectionValue(comSec, "com/maps?q=", "\"");
				latlng[0] = U.getSectionValue(comHtml, "Latitude\": \"", "\"");
				latlng[1] = U.getSectionValue(comHtml, "Longitude\": \"", "\"");

					
//				String comHtml = getHtml1(communityUrl, driver, false);
				comHtml=comHtml.replaceAll(" - Coming Soon|Coming Soon</li>|ComingSoonCarousel.ashx?w=183\">|Coming_Soon|Coming Soon</h1>|Coming Soon</span>|New Homes Available Soon|City Address Now Selling</p>|Living Spaces - Now Selling|Collection Just Released|Collection Now Selling","");
				
				// String comHtml1 = getHtml1(communityUrl, driver,true);
				//========================================================================================================================================Community Name
				String communityName = U.getSectionValue(comHtml,
						"<div class=\"visit-bk\">", "Sales Center");
				if (communityName != null) {
					communityName = communityName.replace("<h1>", "");
					communityName = communityName.trim();
				} else
					communityName = ALLOW_BLANK;

				if (communityName.equals(ALLOW_BLANK)) {
					communityName = U.getSectionValue(comHtml,
							"communityName bdxTitle\">", "</h2>");
				}
				if (communityName==null) {
					communityName =U.getSectionValue(comSection, "target=\"_blank\">", "</a>");	
					if(communityName==null){
						communityName=U.getSectionValue(comHtml, "h1>", "<");
					}
				}
				
				
				U.log("Community Name::" + communityName);

				//========================================================================================================================================Community Address
				String street = ALLOW_BLANK;
				String city = ALLOW_BLANK;
				String state = ALLOW_BLANK;
				String zip = ALLOW_BLANK;
				String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
						ALLOW_BLANK };
				if (street != null) {
					street = street.replace(",", "");
					street = street.replace("Coming Soon", "");
					street = street.replace("By Appointment ", "");
					street = street.toLowerCase().replaceAll(
							"located at river crest -|call for information|",
							"");
				}
				//new code for address
				if(street==null || street.length()<2){
					street=U.getSectionValue(comHtml, "Street1\": \"", "\"");
					city=U.getSectionValue(comHtml, "City\": \"", "\"");
					state=U.getSectionValue(comHtml, "State\": \"", "\"");
					U.log("state without abb=="+state);
					U.log("street=="+street);
					state=USStates.abbr(state);
					zip=U.getSectionValue(comHtml, "ZipCode\": \"", "\"");
				}
				if (street.length() < 3) {
					add = U.getAddressGoogleApi(latlng);
					String citychk = add[1].trim();
					if (city.equals(citychk)) {
						street = add[0];

						U.log("STREET UPDATED:::" + street);
						GEO = "TRUE";
					} else {
						street = ALLOW_BLANK;
						GEO = "FALSE";
					}
				}
				
				if (zip==ALLOW_BLANK) {
					String addr[] = U.getAddressGoogleApi(latlng);
					zip = addr[3];
				U.log("zip"+zip+"zipfkofvg");
					GEO = "TRUE";
				}
				U.log("Street: "+street);
				String planData=getPlanData(comHtml);

				U.log("GEOCODE::" + GEO);
				String replcSec = U.getSectionValue(comHtml,
						"Visit our other neighborhoods nearby ",
						"</body></html>");
				if (replcSec != null) {
					comHtml = comHtml.replace(replcSec, "");
				}
				String dataSecString = comSec.replaceAll("0s", "0,000");
				dataSecString = dataSecString.replaceAll("(\\$\\d+) Million",
						"$1,000,000");
				comHtml = comHtml.replaceAll("0s|0&#39;s", "0,000");
				comHtml = comHtml.replaceAll("(\\$\\d+) Million", "$1,000,000").replace("$800Ks", "$800,000").replace("$1M", "$1,000,000");

				// ==========================================================================================================Community SQFT

				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				String []wsqft=U.getValues(comHtml, "<div class=\"stat-container", "Sq. Ft.</div>");
				
				
				String[] sqft = U
						.getSqareFeet(
								(comHtml + dataSecString).replace("4,014 to 5,000+ square feet", "4,014 to 5,000 square feet"),
								"boast over \\d{4}SF of living space|\\d+,\\d+-\\d+,\\d+ square feet|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} sq. ft. - \\d,\\d{3} sq. ft.|sq. ft.'\">\\d{4}-\\d{4}\\+ sq. ft|\\d,\\d+ Square feet|\\d,\\d{3}\\+ </strong>|\\d,\\d{3}+ </strong>sq ft|sq. ft.'\">\\d{4}\\+ sq. ft|>\\s*\\d,\\d+",
								0);
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
				//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml + dataSecString, "[\\s\\w\\W]{30}5,000[\\s\\w\\W]{30}", 0));
				
				// ==========================================================================================================Community PRICES
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				if(comHtml.contains("<div class=\"data-label\">Was</div>")){
				String []rmwasPrice=U.getValues(comHtml, "<div class=\"stat-container", ">Was</div>");
				for(String s:rmwasPrice){
					comHtml=comHtml.replace(s, "");
				}}
				
				//priced from the Mid-$400s to Low-$500s
				comHtml=comHtml.replace("&#39;s","0,000");
				comHtml = comHtml.replaceAll("0s|0's", "0,000").replaceAll(
						"\\.(\\d{1}) Million", ",$100000");
				comHtml=comHtml.replace("Low $1.1M's", "Low $1,100,000").replace("0s+","0,000");
//			
				String[] price1 = U
						.getPrices(
								comHtml + dataSecString,
								"Low \\$\\d,\\d{3},\\d{3}|priced from the Mid-\\$\\d{3},\\d{3} to Low-\\$\\d{3},\\d{3}|High \\$\\d+,\\d+|High \\$\\d{3},\\d{3}|Low \\$\\d+,\\d+ to Mid \\$\\d+,\\d+|from the \\$\\d+,\\d+|Homes </span>.*?\\$\\d+,\\d+ to \\$\\d+,\\d+|visible: DisplayPrice\">.*?<|\\$\\d,\\d+,\\d+|Price\">.*?</strong>|green; font-weight: bold\">.*?<|bold\">\\$\\d{3},\\d+|Homesites </span>From the.*?<|Low \\$d{3},\\d+|Homes </span>From .*?<|\\$\\d{3},\\d{3}\\s*</div>|<h4>\\$\\d{3},\\d{3}</h4>",
								0);
				minPrice = (price1[0] == null) ? ALLOW_BLANK : price1[0];
				maxPrice = (price1[1] == null) ? ALLOW_BLANK : price1[1];
				U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//				U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}1,000,000[\\s\\w\\W]{30}", 0));
//				U.log(">>>>>>>>>>>>"+Util.matchAll(dataSecString, "[\\s\\w\\W]{30}1,000,000[\\s\\w\\W]{30}", 0));

				// ================================================================================================================Adding Details
				String dropMetaKey=U.getSectionValue(comHtml, "<meta content=\"", "name=\"keywords\" />");
				if(dropMetaKey!=null){
					comHtml=comHtml.replace(dropMetaKey, "");
					U.log("Success DropMetaKey");
				}
				comHtml = comHtml
						.replace(
								"Coming Soon: Expertly|<img class=\"simImage\" src=\"/~/media/JW Homes/Georgia/Atlanta/Atlanta/The Aldredge/The Aldredge Townhomes Rendering Carousel.ashx?w=183\">",
								"");
				comHtml=comHtml.replace("second floor bonus room ", "second story bonus room ");
				comHtml = comHtml.replace("luxurious interior", "luxury homes");
				comHtml=comHtml.replaceAll("3rd [F|f]loor [l|L]oft", "3rd level Floor Loft");
				planData=planData.replaceAll("3rd [F|f]loor [l|L]oft", "3rd level Floor Loft");
				//========================================================================================================================================property type
				comHtml=comHtml.replaceAll("Coming Soon</div>|u-noPad\\\">Coming Soon", "").replace("Traditionally inspired", "Traditional exterior");
				String propType = U.getPropType((planData+comHtml).replaceAll(
						"%20Townhouses%20Atlanta%2C|Loft, Banana Republic|Detached Garage|participation|Detached Two|traditionally inspired|Traditional Charm|Carriage\\-Style|Townhouses Brookhaven|HOA|cottage inspired|Village|village|New Townhomes|NEhoAZA|New Townhouse", ""));
					U.log("propType====================================================> "+propType);
//					U.log(Util.matchAll(planData+comHtml, "[\\w\\s\\W]{30}Loft[\\w\\s\\W]{30}",0));
				
					String statusLine=U.getSectionValue(comHtml, " <h4 class=\"CommunityHero__status\">", "</h4>");
				if(statusLine == null) statusLine=U.getSectionValue(comHtml, "<h4 class=\"CommunityHero__status ", "</h4>");
				
				//U.log(statusLine);
				String drpropType = U.getdCommType((comHtml + planData.replaceAll("<div class=\"floor-option.*>Second Floor</div>|The second-floor owner’s suite|second level", " 2 story ")//.replaceAll("<div class=\"floor-option.*>First Floor</div>|first level", " 1 story ")
						.replaceAll("<div class=\"floor-option.*>Three Floor</div>|<div class=\"floor-option.*>Third Floor</div>", "Story 3 ").replace("<div class=\"floor-option.*>Four Floor</div>|<div class=\"floor-option.*>Fourth Floor</div>", "Story 4 ")
						).replaceAll(
						"Branch|branch|First Floor", ""));
				//U.log(Util.match(comHtml, "[a|A]ctive [a|A]dult"));
				
				String comType = U.getCommType((comHtml + communityName).replace("waterfront new home community", "Waterfront Community").replaceAll("data-copy=\".*\"|snapshot in the Master Plan|Active Adult<|Golf and River Club|golf fees", ""));

				comHtml = comHtml.replace("</span> Homes Available Now",
						" Homes Available Now");
				comHtml = comHtml
						.replaceAll(
								" Models at Riverview Coming Soon|Foods coming soon|Foods now open!|Inside and Out - Opening Spring 2019|<div class=\"StatusTag\">Last Chance</div>|You Live - Opening Early 2020|Portfolio Now Selling|now selling at|Now Open|Coming Soon:|System - Coming Soon|Coming Soon: Expertly|Homesites Now Selling|Overlook Now Selling|Final Opportunities for|homes ready now|Homes Ready Now|and new releases|New Releases|an exciting offering coming soon|See More Homesites Available|Now Open! Beautiful Park|Now Open! Beautiful Garden|Now Open!&nbsp;Private|New Summer Club, Now Open|New Summer Club Now Open|Lighted Tennis Courts Coming Soon|10px;\" alt=\"Coming",
								"");
				String rmSec=U.getSectionValue(comHtml, "Nearby Neighborhood", "</script");
				if(rmSec!=null)
				comHtml=comHtml.replace(rmSec, "");
				comHtml=U.getNoHtml(comHtml);

				//======================================================================================================================================Property status
//				statusLine=statusLine.replace("Foods now open!", "");
				
				String propStatus = U.getPropStatus(statusLine+comHtml.replace("pond and lakefront homesites available.", "Pond And Lakefront Homesites Available").replaceAll("Quick move-in homes are|no Quick Move|Coming soon - new Single-Family |\"CommunityStatus\":\"Coming|Price Coming Soon|Quick Move-In \\(0\\)|Quick move in homes excluded|We are currently selling from our Sales|There are no Quick Move-Ins available|Luxurious Gated New Homes Coming Soon to Historic Vinings|priceComingSoon|Price Coming Soon|enclave of just 36 spacious homesites now selling|first release will offer distinctive new homes|Designer Models - Opening Soon|Opening Soon!|model is now available to tour at McLean|Coming Soon,|coming soon,|the neighborhood�s first release will offer distinctive |Coming This Fall - Suwanee's Newest Townhomes|A striking club pavilion and sparkling pool, opening late Summer 2017|opportunities in Milton|Price Coming Soon", ""));
				
				if(!comHtml.contains("<div class=\"homecard\">")){
					propStatus=propStatus.replaceAll(", New Homes Available Soon|New Homes Available Soon", "");
				}
//				U.log(Util.matchAll(statusLine+comHtml, "[\\w\\s\\W]{30}Quick Move-In[\\w\\s\\W]{30}",0));
				U.log("propStatus==============================> "+propStatus);
				//========================================================================================================================================end status
				
				
				street = street.replace("Sold Out", "");
				street = street.replace("sold out", "");
				street = street.toLowerCase().replaceAll(
						
						"located at|now selling", "");
				if (street == ALLOW_BLANK || street.trim().length() < 4) {
					String addr[] = U.getAddressGoogleApi(latlng);
					street = addr[0];
					city = addr[1];
					state = addr[2];
					zip = addr[3];
					GEO = "true";
				}

				if (city.length() < 2) {
					city = ALLOW_BLANK;
				}
				if (city == ALLOW_BLANK) {
					String[] addres = U.getAddressGoogleApi(latlng);
					street = addres[0];
					city = addres[1];
					state = addres[2];
					addres[3] = zip;
					GEO = "true";
					U.log("Street fm: "+street);
				}
//				if(j==0)
//					maxPrice="$1,021,900";
				//U.log(U.getCache(communityUrl));
								
					//U.log(street);		
					street=street.replace("loced across from avalon  the intersection of kimball bridge road and northwinds parkway","Northwinds Parkway");
			street=street.replaceAll("\\- 2103 haventree court|\\- 668 old dairy drive","");
//			if(communityUrl.contains("/home/shatam-4/Cache/jwhomes.com/jwhomescomFindYourHomeGeorgiaNeighborhoodsintheAtlantaGAAreaNeighborhoodsinCantonGACadenceatWoodmontNeighborhood.txt")){
//				communityName="Cadence at Woodmont Neighborhood";
//			}
			
			if(communityUrl.contains("https://www.jwhomes.com/Find-Your-Home/North-Carolina/Neighborhoods-in-the-Charlotte-NC-Area/Neighborhoods-in-Charlotte-NC/Elizabeth-Glen-Neighborhood")||communityUrl.contains("Neighborhoods-in-Charlotte-NC/Providence-Village-Neighborhood"))
			{
				if(propStatus.length()<2){
					propStatus="Coming Soon";
				}else {
					propStatus=propStatus+",Coming Soon";		
				}
			
			U.log("propStatus========================================================> "+propStatus);
			}
			
			if(propType.contains("Townhouse")){
				propType=propType.replace(",Townhouse","");
				
			}
//			if(communityUrl.contains("/charlotte/belmont/mclean-209722"))comType="Waterfront Community";
//			if(j==11)minPrice="$400,000";
			if(!lng.trim().contains("-")){
				lng="-"+lng;
				U.log(lng+"longitude");
			}
			street=street.replace("2028 tell way", "2028 Attell Way");
//			U.log("Street: "+street);
			
			
			if(comHtml1.contains("communityStatus\">Now Open</h4>"))
				if(propStatus==ALLOW_BLANK)
					propStatus = "Now Open";
				else
					propStatus += ", Now Open";
			
			if(comHtml.contains("Quick Move-In (0)"))
				propStatus = propStatus.replaceAll(", Quick Move-in Homes|, Quick Move-in|Quick Move-in Homes|Quick Move-in, |Quick Move-in", "");
			propStatus = propStatus.replaceAll("Quick Move-in Homes", "Quick Move-in");
			if(propStatus.isEmpty())propStatus=ALLOW_BLANK;
			if(communityUrl.contains("https://www.jwhomes.com/homes/north-carolina/charlotte/belmont/mclean-209722")) {
				propStatus=propStatus.replace(", Quick Move-in", "");
			}
			
			// ------------------------- Number of Units ---------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			String jsonLink = ALLOW_BLANK;
			
			if(comHtml1.contains("<h2>Homesite Map </h2>")) {
				String section = U.getSectionValue(comHtml1, "<h2>Homesite Map </h2>", "Open Interactive Map");
				U.log("section_One: "+section);
				
				if(section != null) {
					String mapUrl = U.getSectionValue(section, "href=\"", "\"");
					U.log("mapUrl: "+mapUrl);
					
					if(mapUrl != null) {
						if(mapUrl.contains("OLAId=") && mapUrl.contains("&amp")) {
							String subMapUrl = U.getSectionValue(mapUrl, "OLAId=", "&amp");
							U.log("subMapUrl: "+subMapUrl);
							
							String jsonUrl = "https://apps.alpha-vision.com/olajson/" + subMapUrl + ".json";
							U.log("jsonUrl_One: "+jsonUrl);
							jsonLink = jsonUrl;
						}
						else {
							String[] sub =  mapUrl.split("OLAId=");
							String subMapUrl = sub[1];
							U.log("subMapUrl: "+subMapUrl);				
							
							String jsonUrl = "https://apps.alpha-vision.com/olajson/" + subMapUrl + ".json";
							U.log("jsonUrl_Two: "+jsonUrl);
							jsonLink = jsonUrl;
						}
						
						U.log("jsonLink: "+jsonLink);
						String jsonData = ALLOW_BLANK;
						int totalUnits = 0;
						
						if(jsonLink != ALLOW_BLANK) {
							jsonData = U.getPageSource(jsonLink);
							U.log(U.getCache(jsonLink));
							
							String[] lotCounts = U.getValues(jsonData, "\"LotCount\":", ",\"");
							U.log("lotCounts: "+lotCounts.length);
							for(String lot:lotCounts) {
								U.log("lot: "+lot);
								int lotCount = Integer.parseInt(lot);
								totalUnits = totalUnits + lotCount;
								U.log("totalUnits: "+totalUnits);
							}
							
							units = String.valueOf(totalUnits);
							U.log("units: "+units);
						}
					}
				}
			}		
			
			
				data.addCommunity(communityName, communityUrl, comType);
				data.addAddress(street, city, state, zip);
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), GEO);
				data.addPropertyType(propType, drpropType);
				data.addPropertyStatus(propStatus);
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minSqf, maxSqf);
				data.addNotes(ALLOW_BLANK);
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);

			}
		}
		j++;
		
//		}catch (Exception e) {}
	}
//========================================================================================================================================GetPlanDetail
	private String getPlanData(String cHtml) throws IOException{
		String planData=ALLOW_BLANK;
		
			String[] planUrls=U.getValues(cHtml, "<div class=\"HomeDesignCompact__title\"", "View");
			U.log("plan::"+planUrls.length);
			int i=0;
			for(String planUrl: planUrls){
				if(i>5)break;
				i++;
				//U.log("planUrl::"+planUrl);
				String urlSec=U.getSectionValue(planUrl, "<div class=\"HomeDesigncompact__buttonWrapper\">", "class");
				if(urlSec!=null)
				planUrl=U.getSectionValue(urlSec, "<a href=\"", "\"");
//				U.log("planUrl::"+planUrl);
				if(planUrl!=null && planUrl.length()>200) {
					planUrl=U.getSectionValue(planUrl, "<h2><a href=\"", "\"");
				}
				String planHtml=U.getHTML("https://www.jwhomes.com"+planUrl);
			//	U.log(U.getCache("https://www.jwhomes.com"+planUrl));
				planData=planData+planHtml;
				
		}
		return planData;
	}

	public static String getHtml1(String url, WebDriver driver)
			throws Exception {
		// WebDriver driver = new FirefoxDriver();
		U.log("rakesh sr>>> "+url);
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;
		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		/*if (flag == true)
			folder = new File(U.getCachePath() + Dname + "john");
		else
			folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		if (flag == true)
			fileName = U.getCachePath() + Dname + "john" + "/" + fileName;
		else {
			fileName = U.getCachePath() + Dname + "/" + fileName;
		}*/

		//File f = new File(fileName);

		if (!f.exists()) {

			BufferedWriter writer = new BufferedWriter(new FileWriter(f));

			driver.get(url);

			((JavascriptExecutor) driver).executeScript(
					"window.scrollBy(0,4000)", "");

			// Thread.sleep(3000);
			html = driver.getPageSource();
			try {

				String aaaa = "availablelink";
				// WebElement option = driver. getElementsByClassName(aaaa);
				WebElement option = driver.findElement(By.xpath("/html/body/main/section[4]/div[4]/div/span/strong"));
				if(option.isDisplayed())
				{
				option.click();
				/*
				 * option= driver.findElement(By.className("planslink"));
				 * option.click(); option=
				 * driver.findElement(By.className("seemoreLarge"));
				 * option.click();
				 */
				U.log("click success");
				Thread.sleep(3000);
				U.log("Current URL Quick:::" + driver.getCurrentUrl());
				String currentPageSource=driver.getPageSource();
				html = html+currentPageSource;
				}
				
				
			} catch (Exception e) {

				e.printStackTrace();

			}			

			Thread.sleep(1000);
			writer.append(html);
			writer.close();

		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}

		return html;

	}
	public static String getHTMLNew(String url, WebDriver driver)
			throws Exception {
		// WebDriver driver = new FirefoxDriver();
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;
		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		/*if (flag == true)
			folder = new File(U.getCachePath() + Dname + "john");
		else
			folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		if (flag == true)
			fileName = U.getCachePath() + Dname + "john" + "/" + fileName;
		else {
			fileName = U.getCachePath() + Dname + "/" + fileName;
		}*/

		//File f = new File(fileName);

		if (!f.exists()) {

			BufferedWriter writer = new BufferedWriter(new FileWriter(f));

			driver.get(url);

			((JavascriptExecutor) driver).executeScript(
					"window.scrollBy(0,4000)", "");

			 Thread.sleep(3000);
			html = driver.getPageSource();
			try {

				// WebElement option = driver. getElementsByClassName(aaaa);
				WebElement option = driver.findElement(By.linkText("Click To Show All"));//("/html/body/main/section[4]/div[4]/div")
//				WebElement option = driver.findElement(By.xpath("/html/body/main/section[5]/div[4]/div/strong"));
				
				while(option.isDisplayed())
				{
					Thread.sleep(5000);
					option.click();
				/*
				 * option= driver.findElement(By.className("planslink"));
				 * option.click(); option=
				 * driver.findElement(By.className("seemoreLarge"));
				 * option.click();
				 */
				U.log("click success");
				Thread.sleep(3000);
				U.log("Current URL Quick:::" + driver.getCurrentUrl());
				String currentPageSource=driver.getPageSource();
				html = html+currentPageSource;
				}
				
				
			} catch (Exception e) {

				e.printStackTrace();

			}			

			Thread.sleep(1000);
			writer.append(html);
			writer.close();

		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}

		return html;

	}
}
