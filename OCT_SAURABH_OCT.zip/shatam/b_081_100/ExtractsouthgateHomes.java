package com.shatam.b_081_100;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractsouthgateHomes extends AbstractScrapper {
	
	static int j=0;
	static String BASEURL="https://www.southgatehomes.com";
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractsouthgateHomes();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Green Brick Partners - Southgate Homes.csv", a.data().printAll());
	}

	public ExtractsouthgateHomes() throws Exception {

		super("Green Brick Partners - Southgate Homes",	BASEURL);
		LOGGER = new CommunityLogger("Green Brick Partners - Southgate Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String mainHtml = U.getHtml("https://southgatehomes.com/communities/",driver);
		//U.log(mainHtml);
		
//		String regionCommunities[] = U.getValues(mainHtml, "<ul class=\"unifiednav__container unifiednav__container_sub-nav\" data-depth=\"1\"", "</ul>");
//		U.log(regionCommunities.length);
//		for(String regionComm : regionCommunities){
			String communtiySection[] = U.getValues(mainHtml, "<div class=\"col-md-6 col-lg-4 col-xl-3 mb-4 d-flex","View Community</a>");
			U.log("communtiySection ::"+communtiySection.length);
			for(String comSec : communtiySection){
				String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
						
				U.log("comUrl :"+comUrl);
				//U.log("comSec :"+comSec);
				
				String html = U.getHtml(comUrl,driver);
				if(html.contains("<div class=\"dmRespRow u_QMI-Homes\"")||(!html.contains("font-weight: bold;\">Series Homes</span>") 
						&& !html.contains("Series Homes</div>"))) {
				
					String comName = U.getSectionValue(comSec, "<h3>", "</h3>");
					U.log("comName from IP ::"+comName);
					
//						try {
							addDetails(comUrl, comName, comSec);
//						} catch(Exception e) {}
							
				}
			}
			LOGGER.DisposeLogger();
			driver.quit();
	}
			
//				else {
//					String subComm[] = U.getValues(html, "<div class=\"card_row ", "class=\"card_footer\">");
//					for(String com: subComm) {
//						comUrl = BASEURL +U.getSectionValue(com, "<a href=\"", "\"");
//						if(comUrl.contains("null"))continue;
//						String comName = U.getSectionValue(com, "<span class=\"card_title \" card_link\"=\"\">", "<");
//						if(comName == null) {
//							comName = U.getSectionValue(com, "card_spec\"=\"\">", "<");
//						}
//						U.log("comName ::"+comName);	
//					
//								
//						//addDetails(comUrl, comName, comSec+com);
//					}
//				}
//			}
//		}
		
		
/*		String communtiysection[] = U.getValues(mainHtml, "","");
//				"<div class=\"card_row card-row-3", "Community Details");
		
		U.log(communtiysection.length);
		for (String com : communtiysection) {
//			U.log(com+"^^^^^^^^^^^");
			
			String url = U.getSectionValue(com, "<a class=\"card_anchor\" href=\"", "\"");
			url = "https://southgatehomes.com"+url;
			
//			if(!url.contains("The-Grove-115914"))continue;
			
//			U.log(url);
			String commName = U.getSectionValue(com, "page-text-style=\"\">", "<");

//			String info = U.getSectionValue(com,"<div class=\"price\">", "Read More&hellip");
			
			
			
			
			if(url.contains("https://southgatehomes.com/communities/edgewood/"))
				url = "https://southgatehomes.com/communities/edgewood-series/";
			url = url.replace("&amp;", "&");
			
			
			String html = U.getHtml(url,driver);//U.getPageSource(url);
			if(html==null) {
				html=" ";
			}
//			U.log(html.length()+"\t"+url);
			String detailSection = U.getSectionValue(html, "Detail Community</div>", "Request More Information</button>");
			
			String[] subComm = null;
			if(url.contains("The-Grove-115914"))
				subComm = U.getValues(html, "<div id=\"card_image_container", "Request More Information</span></button>");
			else
			subComm = U.getValues(html, "<div id=\"card_image_container", "</a></div></div></div>");
			
			
			if(subComm!=null)
//			U.log("Found sub comm. :"+subComm.length);
			
			if(subComm!=null && subComm.length > 0){
				for(String subCommunity : subComm){
					if(subCommunity.contains("detail-home")){
						addDetails(url, html, commName, com);
						continue;
					}
					String subComUrl = U.getSectionValue(subCommunity, "<a href=\"", "\"");
//					U.log("===>"+subCommunity);
//					U.log("subComUrl:: "+subComUrl);
					subCommunity = subCommunity.replaceAll("<h1 style=\"text-align: center;\"> </h1>|<h1 style=\"text-align: center;\"> </h1>", "");
					
					commName = U.getSectionValue(subCommunity, "card_link\"=\"\">", "</span>");
					if(commName == null) commName = U.getSectionValue(subCommunity, "<span class=\"card_title \" card_spec\"=\"\">", "</span>");
					if(commName != null) { 
						commName = commName.replace("<br>", " ");
					
					}else {
						commName=U.getSectionValue(html, "\"fadeInUp\">","</h3>");
					}
					
					if(!subComUrl.contains("https")){
						subComUrl="https://www.southgatehomes.com"+subComUrl;
					}
					String subHtml = U.getHtml(subComUrl,driver);//U.getPageSource(subComUrl);
		
					addDetails(subComUrl, subHtml, commName, com+subCommunity+ detailSection);
				}
			}else{
				addDetails(url, html, commName, com);
			}
//			U.log("==================");
		}*/
//		LOGGER.DisposeLogger();
//		driver.quit();
//	}

	// TODO Auto-generated method stub
	public void addDetails(String url, String commName, String info)throws Exception
	{
		
//try {
		
		if(url.contains("https://southgatehomes.com/detail-community/NorthGlen-121513")|| url.contains("detail-home/"))return;
		
		//================== Run ============================
//		if(!url.contains("https://southgatehomes.com/community-detail/the-grove/"))return;
		
		
		U.log("community URL::"+url);
		

		if(url.endsWith("https://www.southgatehomes.com/the-grove") || url.endsWith("https://www.southgatehomes.com/windsong-ranch") || url.endsWith("https://www.southgatehomes.com/brockdale")){
			LOGGER.AddCommunityUrl(url+"::::::::::::Repeated");
			return;
		}
		if(url.contains("https://southgatehomes.com/communities/northwood-manor/")){
			LOGGER.AddCommunityUrl(url+"::::::::::::Redirected");
			return;
		}
		if(url.contains("https://www.southgatehomes.com/detail-home/The-Madison-1780427")){
			LOGGER.AddCommunityUrl(url+"::::::::::::Redirected");
			return;
		}
		
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url+"::::::::::::Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		
		String html = U.getHtml(url, driver);

		
		if(commName==null||commName.length()<3) {
			commName=U.getSectionValue(html, "\"fadeInUp\">","</h3>");
			U.log("======Null Name");
		}
		U.log("======"+commName);
//		try{

//		if(j==7)
		{
//		url = url.replace("&amp;", "&");
		

		U.log("url=>"+url);
		commName=commName.replaceAll("- Arglye|- Sunnyvale|- Allen|- Prosper|- Frisco|- Lucas", "");
		U.log("commName===>"+commName);
//		U.log(info);
//		String html = U.getHTML(url);
		
				
		//===========================================================================================================================community Type
		String communitytype = U.getCommunityType(html.replaceAll("\"Master Planned\"|\"Green Community\"|Country Club Rd|SouthgateDFW|Gated\\)|IsGated|gateDFW|egated", "")
				+ info);
		
		//============================================================================================================================Adress
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String lat = ALLOW_BLANK;
		String lng = ALLOW_BLANK;
		String geo = "False";
//		
//		if(url.contains("http://southgatehomes.com/communities/northglen/")){
//
//		}
		
		if(html.contains("<span class=\"addressCity\">")) {
		U.log("HI....");
			add[0] = U.getSectionValue(html, "<span class=\"addressStreet\">", "</span>");
		add[1] = U.getSectionValue(html, "<span class=\"addressCity\">", "</span>").replaceAll(",|<span>", "").trim();
		add[2] = U.getSectionValue(html, "<span class=\"addressState\">", "</span>").replaceAll(",|<span>|\\s*", "").trim();
		add[3] = U.getSectionValue(html, "<span class=\"addressZipCode\">", "</span>").replaceAll(",|<span>", "").trim();
		lat = U.getSectionValue(html, " data-center-latitude=\"", "\"");
		lng = U.getSectionValue(html, " data-center-longitude=\"", "\"");
		U.log(Arrays.toString(add));
		
		}
		else {
			
			String addSec = U.getSectionValue(html, "<span class=\"addressStreet\">", "</span>");
			if(addSec==null) {
				addSec = U.getSectionValue(html, "inline-bind-applied=\"true\">", "</div>");
				U.log(">>>>>>>>>>> "+addSec);
				if(addSec != null)
					addSec=U.getNoHtml(addSec.replaceAll("<span style=\"background-color: transparent;\">", ",").replace("&nbsp;", ""));
			}
			if(addSec==null) {
				addSec = U.getSectionValue(html, "inline-bind-applied=\"true\">", "</span>");
				if(addSec != null)
					addSec=U.getNoHtml(addSec.replace("&nbsp;", ""));
			}
			if(addSec==null && commName.contains("Northwood Manor") ||
					addSec==null && commName.contains("Windsong Ranch") ||
					addSec==null && commName.contains("The Grove")) {
				String addSection = U.getSectionValue(info, "View Google Map", "</a></h5>");
				U.log("addSection : "+addSection);
				
				if(addSection != null ) {
					add[0] = U.getSectionValue(addSection, "Directions\">", ",");
					
					String tempSec = U.getSectionValue(addSection, "nowrap\">", "</span>");
					String[] temp = tempSec.split(",");  
					
					add[1] = temp[0];
					add[2] = Util.match(temp[1], "\\w{2}");
					add[3] = Util.match(temp[1], "\\d{5}");
				}
				
				if(addSection != null) {
					String geoSec = U.getSectionValue(info, "destination", "rel=\"noreferrer");
					lat = U.getSectionValue(geoSec, "=", ",");
					lng = U.getSectionValue(geoSec, ",", "\"");
				}
				
			}
			
			if(addSec!=null) {
				addSec = addSec.replace("Frisco", ", Frisco").replace("<br>", ",").replace("(61's) | 4280 Bonner Court (71's &amp; 81's)", "");
			add = U.getAddress(addSec);
			
			lat = U.getSectionValue(html, " data-center-latitude=\"", "\"");
			lng = U.getSectionValue(html, " data-center-longitude=\"", "\"");
			}
		}
//		if(url.contains("https://www.southgatehomes.com/series-community/Windsong-Ranch-61-Series-148347")) {
//			
//			String addsec = "3780 Roundtree,Prosper,TX 75078";
//			add = U.getAddress(addsec);
//		}
		
//		String addSec = ALLOW_BLANK;
//		if(commName.equals("The Grove")) {
//			addSec = U.getSectionValue(html, "<div class=\"u_1333872691 dmNewParagraph", "</div>");
//			U.log("addSec grove : "+addSec);
//			
//			if(addSec != null) {
//				add[0] = U.getSectionValue(addSec, "data-diy-text=\"\">", ",&nbsp;");
//				String addOne = U.getSectionValue(addSec, "transparent;\">", "</span>");
//				U.log("addOne: "+addOne);
//				String[] newAddSec = addOne.split(",");
//				add[1] = newAddSec[0];
//				
//				String[] newAdd = newAddSec[1].split(" ");
//				add[2] = Util.match(addOne, "\\s\\w{2}\\s");
//				add[3] = Util.match(addOne, "\\d{5}");
//			}
//		}
		
		U.log(">>>>>>>.. "+Arrays.toString(add));
		U.log("lat: "+lat+" lng: "+lng);
		
		if(add[0]!=null){
		add[0]=add[0].replaceAll(",|<span>", "")
				.replaceAll("<span>|OPENING NOVEMBER 2nd|COMING OCTOBER|Phase 5B COMING SOON 61&#39; Lots|sales center located at lakes of argyle|By appt only.  Visit us at our Twin Creeks Model home|: BY APPT ONLY|COMING SOON!|Model Coming Soon!|Model Coming Soon|By appt only|By Appointment Only|COMING SOON|Sales Center located at Lakes of Argyle ","");
			}
		
		
		if(lat==null || lat.length()<3)
		{
			String tempAdd[]=U.getlatlongGoogleApi(add);
			if (tempAdd==null) tempAdd=U.getlatlongHereApi(add);
			lat = tempAdd[0];
			lng = tempAdd[1];
			geo = "True";
		}
		if(add[0]==null || add[0].length()<3)
		{
			String tempAdd[]=U.getAddressGoogleApi(new String[]{lat,lng});
			if (tempAdd==null) tempAdd=U.getGoogleAddressWithKey(new String[]{lat,lng});
			add[0] = tempAdd[0];
			geo = "True";
		}
//		add[0]=add[0].replaceAll("By appt only.  Visit us at our Twin Creeks Model home |: BY APPT ONLY|COMING SOON!|Model Coming Soon!|Model Coming Soon","");
		
		
		//U.log(html);
	
		//================================================================================================================================Property Type
		//fetch individual plan data
		String allPlanData = getPlanData(html);
		
		String proptype = U.getPropType((html+info+allPlanData).replaceAll("priceloft|prloft|config.MultiFamily|\"Multi Family\"|Custom Build|Cottage Circle|one of the top luxury home builders|\"Single Family\"|IsTownHome|CondoOrTownhome|IsCondo|Arizona Luxury Homes", ""));
		U.log("proptype: "+proptype);
//		U.log(Util.matchAll(html+info+allPlanData, "[\\w\\s\\W]{50}patio[\\w\\s\\W]{50}", 0));
//		U.log(Util.matchAll(html+info+allPlanData, "[\\w\\s\\W]{50}loft[\\w\\s\\W]{50}", 0));
		
		//=================================================================================================================================Derived Type
		//---fetching status from quick move in tab
		String quickSec = U.getSectionValue(html, "Quick Move-In Homes", "<li class=\"mainNavLiItem hasDrop");
//		U.log(quickSec);
		html = html.replaceAll("\">5T Ranch|footerAnch|ranch|personalizationRegisterAnch|/southgate-ranch|velAnchor\">Southgate Ranch|NoClick mainNavAnchor\">\\W+Quick Move-In Homes", "");

		html=html.replace("footerAnchorBackgroundColor","");
//		U.writeMyText(html);
		html=html.replaceAll("Windsong-Ranch|Windsong Ranch", "");
		String dtype = U.getdCommType((html+commName+info).replaceAll("Windsong-Ranch|Windsong Ranch", "").replaceAll("Windsong-Ranch|Windsong Ranch|/Windsong-Ranch-136241|Ranch - Argyle|ranch\"|5T Ranch|-Ranch-", ""));
		//=================================================================================================================================Property Status
		
		String quickHomeSection  = U.getSectionValue(html, ">Quick Move In Homes (QMI)</div>", "Interactive Site Plan</span></a>")+
				U.getSectionValue(html, "Quick Move In Homes (QMI)</span>", "GET IN TOUCH WITH");
		int quickHomeCount = 0;
		int soldCount = 0;
		try {
		if(quickHomeSection != null){
			
			String quickUrls[] = U.getValues(quickHomeSection, "<div id=\"cards_container", "</button>");//"<div id=\"card_body_"
			quickHomeCount = quickUrls.length;
			
//			U.log(quickUrls.length);
			for(String quickUrl : quickUrls){
//				U.log(">>>>>>>>>>>>> quickUrl: "+quickUrl);
				if(quickUrl.contains("homeSold.png"))
					soldCount++;
			}
		}
		}
		catch(NullPointerException ne) {}
		U.log("Total quick home :"+quickHomeCount);
		html=html.replace("<h2 style=\"text-align: center;\">NOW OPEN FOR","").replaceAll("Grand Opening|comingSoonImage|Close Out|C -Coming Soon|CG Coming Soon", ""); //Coming Soon
		html=html.replace("<div class=\"communityDescription bdxRTEWrapper\">Welcome to The Grove Frisco - We are NOW OPEN for ","");
		html=html.replace("<meta name=\"description\" content=\"Welcome to The Grove Frisco - We are NOW OPEN for Pre-Construction","")
				.replaceAll("data.config.closeoutFlag|Coming Soon</a>|IsCloseOut|closeoutImage|Move-In|Move In|data-link-text=\"Quick Move-in", "");
//		U.log(Util.match(info.replace("5T in Argyle is NOW OPEN", ""), ".*Phase 2 NOW OPEN.*"));
//		U.log(info);
		String popUp = ALLOW_BLANK;
		if(html.contains("\"promoContainer\"")) {
			String popUpSec = U.getSectionValue(html, "<div class=\"promoContainer\"", "promoDesc");
			popUp = U.getSectionValue(popUpSec, "promoTitle\">", "</h4>");
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}promoContainer[\\s\\w\\W]{30}", 0));
			U.log("popUp: "+popUp);
		}
		
		
		String propstatus = U.getPropStatus((html.replace("Phase 2 NOW OPEN", "Phase 2 Now Open")+info.replace("Phase 2 NOW OPEN for Sale", "Phase 2 now open"))
				.replaceAll("View Quick Move-in Homes|tle=\"View Quick Move-in Homes|>View Quick Move-in Homes<|[Plan|Lot] \\| Limited Availability|MOVE-IN READY|bdxRTEWrapper\">5T Ranch in Argyle is NOW OPEN|content=\"5T Ranch in Argyle is Now Open|<p class=\"officeHours \">COMING SOON!</p>|Move-in Ready|Move-in Ready! FINAL HOME!",""));
		//U.log(info);Closeout, Move-in Ready, 1 Home Remaining, Quick Move-In
		U.log("propstatus:====================================================================>::"+propstatus);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{10}Quick Move-in[\\s\\w\\W]{10}", 0));
	U.log("Sold Count: "+soldCount);
		if(quickHomeCount > 0 && quickHomeCount>soldCount && !propstatus.contains("Sold Out")){
			if(propstatus != ALLOW_BLANK) propstatus += ", Quick Move-In Homes";
			else if(propstatus == ALLOW_BLANK) propstatus = "Quick Move-In Homes";
		}
		/*if(propstatus!=null){
			quickSec = quickSec.replace("thirdLevelAnchor\">Lakes of Argyle", "");
			if(!propstatus.contains("Quick Move-in") && quickSec.contains(commName.replace("Angel Field West", "Angel Field").replace("The Grove Frisco", "The Grove - Frisco")) && propstatus.length()>4){
				propstatus=propstatus+", Quick Move-In";
			}
			else if(!propstatus.contains("Quick Move-in") && quickSec.contains(commName.replace("Angel Field West", "Angel Field").replace("The Grove Frisco", "The Grove - Frisco"))){
						propstatus="Quick Move-In";
			}
			propstatus=propstatus.replace("Phase Ii", "Phase II");
		}*/
		
		
		String extrasec = U.getSectionValue(html, "<select class=\"select-list select-list-price \" id=\"MinimumPrice\" name=\"MinimumPrice\">", "<div class=\"col col-last bdxSearchBedrooms\">");	
		if(extrasec!=null)
			html = html.replace(extrasec, "");
		
		html=html.replaceAll("<span class=\"previousPrice\">\\$\\d{3},\\d{3}</span>", "").replace("$700's","$700,000").replace("$500's", "$500,000")
				.replaceAll("in the \\$(\\d{3})'s", "in the \\$$1,000");
		info = info.replace("0's", "0,000");
	
		//============== PRICE =======================================================
		String[] prices = U.getPrices((html+info).replace("plans starting in the mid $600,000", ""), 
				"\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\d{6}\\s*</spa", 0);
		String minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		String maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("minPrice: "+minPrice +"  maxPrice: "+ maxPrice);

		//============== SQFT =======================================================
		html = html.replaceAll("<span id=\"suffix-text-.* class=\"suffix-api-text\">", "");
		
		String sqft[] = U
				.getSqareFeet(html,">\\d{4} - \\d{4}</span>\\s+\n\\s+Square Feet|\\d,\\d{3} Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d{4} - \\d{4} Square Feet|\\d,\\d{3} Square Feet",0);
		String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		String note = U.getnote(html.replaceAll("early pre-sale and lot hold|bdxRTEWrapper\">PHASE 3 NOW OPEN FOR SALE|content=\"PHASE 3 NOW OPEN FOR SALE", ""));
		
/*		if(note.contains("Now Open"))propstatus = propstatus.replace("Now Open,", "");
		if(url.contains("https://southgatehomes.com/communities/the-grove-frisco/"))add[2] = "TX";
		if(url.contains("https://southgatehomes.com/communities/the-grove-frisco/"))maxPrice = "$817,900";
*/		
		add[1]=add[1].replaceAll("\\s*Prosper\\s*", "Prosper").replaceAll("\\s*Lucas", "Lucas").replaceAll("\\s*Argyle", "Argyle").replaceAll("\\s*Sunnyvale", "Sunnyvale");
		
		
//		if(url.contains("https://www.southgatehomes.com/detail-community/Edgewood-114302") && !proptype.contains("Patio Homes"))
//			proptype = "Patio Homes";
			
/*		if(url.contains("https://southgatehomes.com/detail-community/Brockdale-Estates-119982"))
			commName="Brockdale Estates";
		
		if(url.contains("https://www.southgatehomes.com/series-community/Edgewood-74-Series-148345"))
			propstatus="Final Opportunity";
		if(url.contains("https://www.southgatehomes.com/series-community/Edgewood-74-Series-148345"))
			dtype="1 Story, 2 Story";
		
		if(url.contains("https://www.southgatehomes.com/series-community/Northwood-Manor-55-Series-148872"))
		propstatus="Now Open";
*///			if(url.contains("https://www.southgatehomes.com/series-community/Northwood-Manor-64-Series-148873"))
//				propstatus="Now Open";
			
//			if(url.contains("https://www.southgatehomes.com/series-community/Northwood-Manor-74-Series-148874"))
//				propstatus="Now Open";Northwood-Manor-64-Series-148873
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		
		if(url.contains("/northwood-manor/") || url.contains("/the-grove/")) {
			
			String iframeUrl = U.getSectionValue(html, "<iframe class=\"embed-responsive-item\" src=\"", "\"></iframe>").replace("&amp;", "&");
			U.log("iframeUrl: "+iframeUrl);
			
			String frameHtml = U.getHTML(iframeUrl);
			
			
			String comId = U.getSectionValue(frameHtml, "communityId: ", ",");	
			U.log("comId: "+comId);	
			
			String lotUrl = "https://salesarchitect.exsquared.com/api/Lotv2/getbybdxcommunityid/?bdxCommunityId="+ comId +"&communityNumber=";
			U.log("lotUrl: "+lotUrl);
			String lotHtml = U.getPageSource(lotUrl);
			String lotCount = U.getSectionValue(lotHtml, "LotCount>", "</");
			U.log("lotCount: "+lotCount);
			
			units = lotCount;
		}
		
		if(url.contains("/windsong-ranch/")) {
			
			String[] iframeUrls = U.getValues(html, "<iframe id=\"f360", "</iframe>");
			int countOfUnits = 0;
			
			for(String ifu:iframeUrls) {
				//U.log("ifu: "+ifu);
				String frameurl = U.getSectionValue(ifu, "src=\"", "\"");
				U.log("frameurl: "+frameurl);
				
				String frameData = U.getHtml(frameurl, driver);
				
				if(frameData.contains("<path fill=\"#e3e2e0")) {
					String[] pathFillOne = U.getValues(frameData, "<path fill=\"#e3e2e0\"", "</g>");
					U.log("pathFillOne: "+pathFillOne.length);
					
					countOfUnits = countOfUnits + pathFillOne.length;
				}
				if(frameData.contains("<path fill=\"#a98687")) {
					String[] pathFillTwo = U.getValues(frameData, "<path fill=\"#a98687", "</g>");
					U.log("pathFillTwo: "+pathFillTwo.length);
					
					countOfUnits = countOfUnits + pathFillTwo.length;
				}
				if(frameData.contains("<path fill=\"#a0b7af")) {
					String[] pathFillThree = U.getValues(frameData, "<path fill=\"#a0b7af", "</g>");
					U.log("pathFillThree: "+pathFillThree.length);
					
					countOfUnits = countOfUnits + pathFillThree.length;
				}
				
				U.log("countOfUnits: "+countOfUnits);
				units = String.valueOf(countOfUnits);
				
			}
		}
		
		U.log(">>>> Total Units: "+units);
		
		////================================================================================================================================= adding in csv
		data.addCommunity(commName.toLowerCase().replace("!", "").replace("  ", " ").trim(), url, communitytype);
		data.addAddress(add[0].trim()
				, add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus.replace("closeout", " ").replace("New Lots Now Available, Now Available", "New Lots Now Available"));
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);

	}j++;
		//}catch (Exception e) {}
	}
	private String getPlanData(String cHtml) throws Exception{
		String planData = ALLOW_BLANK;
		String[] planUrls =U.getValues(cHtml, "<div id=\"card_body_plan", "</button>");
		U.log("total plans ::"+planUrls.length);
		for(String planUrl : planUrls){
			planUrl = "https://southgatehomes.com"+U.getSectionValue(planUrl, "<a href=\"", "\">");
			U.log("planUrl:::::"+planUrl);
			String planHtml = U.getHtml(planUrl,driver);
			planData = planHtml;
//			if(planData.contains("patio")){
//				U.log("Found patio");
//				break;
//			}
		}
		return planData;
	}

}
