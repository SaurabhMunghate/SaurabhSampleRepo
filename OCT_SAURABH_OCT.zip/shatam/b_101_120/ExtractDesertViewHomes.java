/*
 * @modify : Pallavi
 * @date : 1-11-17
 */
package com.shatam.b_101_120;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractDesertViewHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER; 

	private static final String builderUrl = "https://www.desertviewhomes.com";
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractDesertViewHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Desert View Homes.csv", a.data()
				.printAll());
	}

	public ExtractDesertViewHomes() throws Exception {
		super("Desert View Homes", "https://www.desertviewhomes.com");
		LOGGER = new CommunityLogger("Desert View Homes");
	}

	public void innerProcess() throws Exception {
		String url = "https://desertviewhomes.com/communities/";
		String html = U.getHTML(url);
		String section = U.getSectionValue(html, "Communities</a>", "</ul>");
		U.log(section);
		String values[] = U.getValues(section, "<a href=\"", "\"");

		for(String value:values) {
			addvalues(value);
		}
		LOGGER.DisposeLogger();
	}

	int j = 0;
	private void addvalues(String url) throws Exception {

		String html = U.getHTML(url);
		html = html.replace("<a href=\"mailto:\" class=\"contact\">Email Agent</a>", "");
		html = U.getSectionValue(html, "<section class=\"movein-homes community\">", "<footer class=\"main\">");
		String values[] = U.getValues(html,	"<a ","More Info");
		for (String itom : values) {
			addNewDetails(itom);
			//break;
		}
	}

	private void addNewDetails(String info) throws Exception {
	//if(j==8)
	{
//			if(!info.contains("https://desertviewhomes.com/neighborhood/painted-sky-at-mission-ridge/")){return;}

		String url =U.getSectionValue(info, "href=\"", "\"");
		U.log("\nPAGE :" + url);
		
		String html = U.getHTML(url);

		

		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url + "\t*********Repeated******\t");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		//========= Community Name =================
		String communityName = U.getSectionValue(info,"<h3>", "</h3>");
		U.log("comName:::"+communityName);
		

		//============ Address =========================
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
		String addSec = U.getSectionValue(html, "Address</strong>", "</div>");
		U.log("----------addSec--- " + addSec);
		if(info.contains("https://desertviewhomes.com/neighborhood/sky-view-estates/")){
			addSec = addSec.replace("<br />", ",").replaceAll("<p>|</p>", "");
			String[] add1 =addSec.split(",");
			add[1]=add1[1];add[0]=add1[0];
			add[2]=Util.match(add1[2], "\\w{2}");
			add[3]=Util.match(add1[2], "\\d{5}");
			U.log(Arrays.toString(add));
		}
		else if (addSec != null) {
			addSec = addSec.replaceAll("</p>|Visit Enchanted Hills|<p>|NOW OPEN!<br />", "");
			addSec = addSec.replace("<br />", ",").replace("Place,", "Place").replace("Paso TX", "Paso, TX").replaceAll("1001 Aerodyne Place", "1001 Aerodyne Place,").trim();
			U.log("-----#-----" + addSec);
			if(addSec.contains(","))
			add = U.getAddress(addSec);
		}
		
		U.log("Add::::"+Arrays.toString(add));

		
		//=============== latitude longitude =======================
		
		String geo = "False";

		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };

		String latLngSec = U.getSectionValue(html, "Directions</h2>", "</iframe>");
		if(latLngSec != null){
			latLngSec = U.getSectionValue(latLngSec, "!2d", "!2m");
			if(latLngSec != null){
				String vals[] = latLngSec.split("!3d");
				latLng[0] = vals[1];
				latLng[1] = vals[0];
			}
		}
		U.log("Lat:" + latLng[0] + " Long:" + latLng[1]);

		if(add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				geo = "True";
			}
		}
		if(latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK){
			if(add[0] != ALLOW_BLANK && add[1] != ALLOW_BLANK){
			
				latLng = U.getlatlongGoogleApi(add);
				geo = "True";
			}
		}
		
		//==================== Available Homes ===========================
		String availableUrlSec = U.getSectionValue(html, "<span class=\"buttons\">", "Available Homes</a>");
		
		String availableHtml = U.getHTML(builderUrl+U.getSectionValue(availableUrlSec, "<a href=\"", "\""));
		availableHtml = U.removeComments(availableHtml);
		
		String combinedAvailableHtmls = "";
		String availableHomeSec[] = U.getValues(availableHtml, "<div class=\"listing-card-info\">","class=\"more-info\">");
		U.log("Available Home Count ==="+availableHomeSec.length);
		for(String availableSec : availableHomeSec){
			
			String homeUrl = U.getSectionValue(availableSec, " <a href=\"", "\"");
			U.log("availHome:::"+homeUrl);
			String homeHtml = U.getHTML(homeUrl);
			combinedAvailableHtmls += U.getSectionValue(homeHtml, "<article>", "copy-right homes\">");
		}
	

		String[] plans = U.getValues(html, "<p><a class=\"more-info\" href=\"", "\"");
		String plansHtml = "";
		String allPlansData = "";
		for(String plan:plans)
			
			
		{
			U.log("homePlan:::"+plan);
			 plansHtml= U.getHTML(plan);
			 allPlansData += U.getSectionValue(plansHtml, "</h1>", "</p>");
		}

		//============= Square feet =====================
		String minsqf = ALLOW_BLANK, maxsqf = ALLOW_BLANK;
		//U.log(info);
		String sqf[] = U.getSqareFeet(html + info+availableHtml+allPlansData,
				"from \\d,\\d{3} to over \\d,\\d{3} square feet|\\d{4}</span> SQFT</p>|from \\d,\\d+ to \\d,\\d+ square feet|from \\d,\\d+ to \\d,\\d+ finished square feet|\\d,\\d+ to \\d,\\d+ square feet,|Square Feet:[^\\d]+\\d{3,}|Sq. Ft.:</strong>\\s*\\d+|<span class=\"sqft\">\\d{4}</span> SQFT|\\d{4} sq. ft.", 0);
		minsqf = (sqf[0] == null) ? ALLOW_BLANK : sqf[0];
		maxsqf = (sqf[1] == null) ? ALLOW_BLANK : sqf[1];
		U.log("minsqf :" + minsqf + " maxsqf " + maxsqf);

		//============ Price==================
		String minPric = ALLOW_BLANK, maxPric = ALLOW_BLANK;
		html = html.replace("0's", "0,000s");

		String pricehtml = html +  info;
		pricehtml =pricehtml.replaceAll("0s", "0,000");
		pricehtml = pricehtml.replaceAll("1238|7507430|7806|123875074307806|178220219454", "");
		

		String price[] = U.getPrices(pricehtml + availableHtml+allPlansData, 
				"\\$\\d+,\\d+ to the \\$\\d+\\d+|\\$<span class=\"price\">\\d+,\\d+|Price:</strong>\\s+\\$\\d+,\\d+|\\$\\d+,\\d+ to \\$\\d+,\\d+</h4>|\\$\\d+,\\d+", 0);
		minPric = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPric = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPric :" + minPric + "maxPric :" + maxPric);

		//========================== Property Status ==========================
		String remove = "Sold out of Forest Meadows Sales|Community Park  Coming Soon|Quick Move| – coming soon!|including move-in ready|move-in-ready/\">Move In Ready Homes</a></li>|<p>NOW OPEN!<br";
		String statSec = html;
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		statSec = statSec.replace("Quick Move|Coming Soon! Schedule your private viewing", "");
		statSec = statSec.replace("opening soon!", "");
		statSec = statSec.replaceAll("move-in-ready|move in ready homes|available now in west", "");
//		U.log(statSec);
		String propStatus = U.getPropStatus((statSec +info).replaceAll("move|Move|move-in-ready|Download Available Lots|download available lots|CLOSEOUT PRICING|closeout pricing|sell out quickly|NOW OPEN!<br|coming soon! schedule your private viewing",""));

		//==================== Community Type ================ 
		html = html.replaceAll("Mission Ridge Master Planned Community|master planned community is serviced by", "");
		
		String comType = U.getCommunityType(html);
		
		
		//================== Property Type ==================
		html=html.replaceAll("amenities without paying Homeowner Association fees|-VILLA|village|Village|VILLAGE|villa|Villa|villa-|-villa-|-Villa-|villavalencia|\\+Villa\\+|VillaAllende|Villa Allende|rich with history from Pancho Villa to Billy the Kid", "");
		plansHtml = plansHtml.replaceAll("luxurious 5-piece|-VILLA|village|Village|VILLAGE|villa|Villa|villa-|-villa-|-Villa-|villavalencia|\\+Villa\\+|VillaAllende|Villa Allende|rich with history from Pancho Villa to Billy the Kid", "");
		combinedAvailableHtmls = combinedAvailableHtmls.replaceAll("-VILLA|village|Village|VILLAGE|villa|Villa|villa-|-villa-|-Villa-|villavalencia|\\+Villa\\+|VillaAllende|Villa Allende|rich with history from Pancho Villa to Billy the Kid", "");
		html=html.replace("such as lofts", "a loft");
		String pType = U.getPropType(html+combinedAvailableHtmls+allPlansData+communityName);

		//================= Derived Type ===================
		String dType =  U.getdCommType(html.replaceAll("Rancho|rancho","")+(combinedAvailableHtmls+plansHtml).replaceAll("Rancho|rancho|><option value=\"Ranch\" >Ranch",""));

		String note =ALLOW_BLANK;
		if (url.contains("https://desertviewhomes.com/neighborhood/villa-valencia/")) {
			add[0]="";
			add[1]="El Paso";
			add[2]="TX";
			add[3]="";
			latLng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLng);
			note="Address and Lat-Lng Taken Using City And State";
		}
	
		if(availableHtml.contains(" moveinready")){
			propStatus=U.getPropStatus(propStatus+" Move-In Ready Homes ");
		}
		
		data.addCommunity(communityName, url, comType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minsqf, maxsqf);
		data.addPrice(minPric, maxPric);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		}
	j++;

	}


}
