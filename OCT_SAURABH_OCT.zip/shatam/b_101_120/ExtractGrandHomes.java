/**
 * Modification Aditya...
@author Parag Humane 
 * @date 10/4/2012
 * 
 */
package com.shatam.b_101_120;


import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGrandHomes extends AbstractScrapper {
	int i=0;
	public int inr=0;
	HashMap<String, String> hm = new HashMap<String, String>();
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {
																																																									
		AbstractScrapper a = new ExtractGrandHomes();
		a.process();
		
		FileUtil.writeAllText(U.getCachePath()+"Grand Homes.csv", a.data()
				.printAll());
	}

	public ExtractGrandHomes() throws Exception {

		super("Grand Homes", "https://www.grandhomes.com/");
		LOGGER = new CommunityLogger("Grand Homes");
	}

	public void innerProcess() throws Exception {

		// Your code here
		String html = U.getHTML("https://www.grandhomes.com/?p=communities");
//		String[] regLatLongSecs;
		String mapHtml=U.getHTML("https://www.grandhomes.com/v/communities_map.cfm?w=550");//Add cookies from the request header section
//		String commSection = U.getSectionValue(html, "<td width=\"195\" align=\"left\"", "<td><script type=");
		String[] reglatlngSecs=U.getValues(mapHtml, "{name: 'marker", "'}");
//		U.log("////////"+mapHtml);
		
		for(String reglatlngSec:reglatlngSecs ) {

			reglatlngSec=StringEscapeUtils.unescapeJava(reglatlngSec);
//			U.log("== "+reglatlngSec);
			String keyName=U.getSectionValue(reglatlngSec, "target='_parent'>", "</a><br>");
			//U.log("Key: "+keyName);
			String ValueSec=reglatlngSec;
			//U.log("Val: "+ValueSec);
			hm.put(keyName.trim(), ValueSec);
			
			

		}
		
		String [] comUrlSections = U.getValues(html, "<div class=\"col-sm-3 col-lg-3 col-md-3\">", "</div>");//U.getValues(commSection, "<div align=\"left\"><a", "</td>");
		U.log(comUrlSections.length);
		for(String comSec : comUrlSections){
//			U.log(comSec);
			String url = U.getSectionValue(comSec, "href=\"", "\"");
			//U.log(url);

			String comName =  U.getSectionValue(comSec, "<p><a href=\"", "</a><br> ").replace(url,"").replaceAll(">|\"","");//U.getSectionValue(comSec, ">", "</a>");
			if(hm.containsKey(comName)) {
				comSec += "\n\n MAPSEC::: \n"+ hm.get(comName.trim());
				//U.log(comSec);
			}
//			try {
				addDetails("https://www.grandhomes.com" + url, comName,comSec,url);
//			} catch (Exception e) {}
//			break;
		}
		

		LOGGER.DisposeLogger();
	}

	int j = 0;
	
	private void addDetails(String url, String name,String comSec,String regUrl) throws Exception {
		//if(j==7)
//		try{
		{
			//TODO:
//			if(!url.contains("https://www.grandhomes.com/community/chadwick%2Dfarms/61/"))return;
//			if(!url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=108"))return;
			U.log("Count=="+j+"::::::::::"+"PAGE :" + url);
//			U.log(comSec);

			String html = U.getHTML(url);
			String geo="FALSE";
 
			String rmSec=U.getSectionValue(html,"About Grand Homes</h4>","<ul class=\"list-marked\">");
			html=html.replace(rmSec,"");
			//U.log("html----"+html);
			// commName
			String commName = name;
			commName=commName.replace(" in Frisco", "");
			U.log("Name:" + commName);
			
			if (this.data.communityUrlExists(url)) 
			{
				LOGGER.AddCommunityUrl(url+"\t*********Repeated******\t");
			//	duplicates++;
				return;
			}
			LOGGER.AddCommunityUrl(url);
			// Lat Long
			String geoFlag=ALLOW_BLANK;
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String[] latlng={ALLOW_BLANK,ALLOW_BLANK};

			
			// Address
			String section = U.getSectionValue(html, "Sales Office", "PH:");
			if (section == null)
				section = U.getSectionValue(html, "Sales office", "PH:");
			if (section == null)
				section = U.getHtmlSection(html, "class=\"commname", "PH:");
			
			//------------------------------new address Section--------------------------------------
			//String myAddressSec =U.getSectionValue(html, "<td align=\"left\" valign=\"top\" class=\"text02\"><div align=\"left\">", "</div></td>");
			String myAddressSec=U.getSectionValue(html,"<a href=\"http://maps.google.com/maps?q=","\" target=\"_blank\"");
//			myAddressSec=myAddressSec.replaceAll("\\+", " ");
			U.log("myAddressSec::::::::::"+myAddressSec);
			if(myAddressSec.contains("/www.google.com/maps"))
				myAddressSec = Util.match(myAddressSec, ">(.*)?\\s+(.*)?");
			//U.log(myAddressSec);
			if(myAddressSec!=null){
				myAddressSec=myAddressSec.replaceAll("Sales Office at  <br></b>|Sales office at:  <br>|Sales office at <br>", "");
				myAddressSec=myAddressSec.replace("Pkwy,     Grand Prairie", "Pkwy").replace("Little Elm/Frisco ISD", "Little Elm");
				myAddressSec=myAddressSec.replace("<br>", ",").replaceAll("</a>|>", "");
				String tempAdd[]=myAddressSec.split(",");
				if(tempAdd.length==3){
					add[0]=tempAdd[0].replace("+"," ");
					add[1]=tempAdd[1].replace("+"," ");
					add[2]=Util.match(tempAdd[2], "\\w+").replaceAll("\\d+","").replace("+"," ");
					add[3]=Util.match(tempAdd[2], "\\d+").replace("+"," ");
				}
			}
			//---------------------latlng Section------------------------
//			U.log("regUrl: "+regUrl);
			
			String myLatLngSec=ALLOW_BLANK;
			if(hm.containsKey(commName)) {
				String latlngRegSec=ALLOW_BLANK;
//				latlngRegSec=hm.get(commName);
				latlng[0] = U.getSectionValue(comSec, "latitude: ", ",");//Util.match(latlngRegSec, "\\d{2}\\.\\d{5,}");
				latlng[1] = U.getSectionValue(comSec, "longitude: ", ",");//Util.match(latlngRegSec, "-\\d{2,3}\\.\\d+");
				
				
				//U.log(latlng[0] + " " + latlng[1]);
//				if ((latlng[0] == ALLOW_BLANK || latlng[1] == ALLOW_BLANK) && add[0].length() > 3) {
//					latlng = U.getlatlongGoogleApi(add);
//					geo = "TRUE";
//				}
//				if ((add[0] == ALLOW_BLANK || add[1] == ALLOW_BLANK) && latlng[0].length() > 3) {
//					add = U.getAddressGoogleApi(latlng);
//					geo = "TRUE";
//				}
				
					
			}
			myLatLngSec=U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place", "Map Link</a>");
			U.log("myLatLngSec::"+myLatLngSec);
			if(myLatLngSec!=null){
				myLatLngSec=Util.match(html, "/@(.*?),\\d+(.*?)/data",1);
				latlng=myLatLngSec.split(",");
			}
			else{
				myLatLngSec=U.getSectionValue(html, "&sll=", "&s");
				U.log(myLatLngSec);
				if(myLatLngSec!=null){
					latlng=myLatLngSec.split(",");
				}
			}
				
			U.log(add[0].length()+":::::::::::::");
			
//			U.log("street:" + add[0] + "\n City:" + add[1] + "\n ST:" + add[2] + "\n Z:"
//					+ add[3]);
			U.log(Arrays.toString(add));
			U.log("lat lng is::"+Arrays.toString(latlng));
			
			
			if(add[0].length()<4 && latlng[0].length()>4){
				add=U.getAddressGoogleApi(latlng);
				if (add==null) add=U.getGoogleAddressWithKey(latlng);
				geo="TRUE";
			}
			
			if(add[0]!=ALLOW_BLANK && add[3]!=ALLOW_BLANK ){
				
				if(latlng[0]==ALLOW_BLANK){
					latlng= U.getlatlongGoogleApi(add);
					U.log(Arrays.toString(add));
					U.log(Arrays.toString(latlng));
					if (latlng==null)latlng=U.getGoogleLatLngWithKey(add);
					geo="True";
				}
			}
			//latlng taken from region page because no proper sec was found
			if(url.contains("/silverleaf%2Destates%2Din%2Dfrisco/116")) {
				String latlngSec ="33.120413,-96.873048";
				latlng = latlngSec.split(",");
			}
			
			html=html//.replace("lakefront living", "Lakefront Luxury")
					.replace("Waterfront homesites ", "waterfront living");
			String comType = U.getCommType(html.replaceAll("Country Club Estates</a>", "")+comSec);
			
			//============== Model Section =========================
			String combineSec=U.getSectionValue(html,"Model Homes","<div class=\"col-xs-12 col-sm-4\">");
			if(combineSec==null)
				combineSec=U.getSectionValue(html,"Model Homes","Available Floor Plans");
			//U.log(comSec);
			String combineUrls[]=U.getValues(combineSec,"<div class=\"col-xs-12 col-sm-6",	"</strong>");
			String modelPlanHtml="";//String combine="";
				U.log("\nModelPlan----"+combineUrls.length);
				for(String modelPlanUrl : combineUrls)
				{
					
				String planUrl=U.getSectionValue(modelPlanUrl,"<a href=\"","\"");
				planUrl="https://www.grandhomes.com"+planUrl;
//				U.log("MMMMMM "+planUrl);
				String html1=U.getHTML(planUrl);
				String remFooter=U.getSectionValue(html1, "<footer class=\"footer-default\">", "</footer>");
				if (remFooter!=null) html1=html1.replace(remFooter, "");
				//U.log(U.getHTML(planUrl));
				modelPlanHtml+=html1;
				}
				
				//===== Available Floor Plans =======
				String avilSec = U.getSectionValue(html, "<h4 class=\"BannerHeadingH4\">Available Floor Plans</h4>", "<h4 class=\"BannerHeadingH4\">Available Homes</h4>");
				
				if(avilSec==null)avilSec =ALLOW_BLANK;
				String[] planSec = U.getValues(avilSec, "<a href=\"/plan", "\"");
				String planData = ALLOW_BLANK;
				int p=0;
				for(String plan : planSec) {
					
					plan="https://www.grandhomes.com/plan"+plan;
					U.log("plan: "+plan);
					String phtml = U.getHTML(plan);
					planData += U.getSectionValue(phtml, "<h4 class=\"BannerHeadingH4\">Plan Details</h4>", "<h4 class=\"BannerHeadingH4\">Elevations</h4>");
//					U.log("patioUrl: "+patioUrl);
//					if(patioUrl!=null) {
//						try {
//						patioUrl = U.getSectionValue(patioUrl, "<iframe src=\"", "\"");
//						U.log("patioUrl: "+patioUrl);
//						planData+=U.getSectionValue(U.getHTML(patioUrl), "<div class=\"ifp-container\">", "<div class=\"option-list furniture\">");
//						}catch(Exception e){}
//						
//					}
//					planData+= U.getSectionValue(phtml, "<h4 class=\"BannerHeadingH4\">Plan Details</h4>", " </div>");
////					if(p>12)break;
//					p++;
				}
				
			
				//===== Available Floor Plans =======
				planSec = U.getValues(html, "  <a href=\"/inventory", "\">");
				if(planData==null)
					planData = ALLOW_BLANK;
				for(String plan : planSec) {
					
					plan="https://www.grandhomes.com/inventory"+plan;
					U.log("plan: "+plan);
					String phtml = U.getHTML(plan);
					planData += U.getSectionValue(phtml, "<h4 class=\"BannerHeadingH4\">Property Detail</h4>", "</section>");
					//U.log("patioUrl: "+patioUrl);
//					if(patioUrl!=null) {
//						try {
//						patioUrl = U.getSectionValue(patioUrl, "<iframe src=\"", "\"");
//						U.log("patioUrl: "+patioUrl);
//						planData+=U.getSectionValue(U.getHTML(patioUrl), "<div class=\"ifp-container\">", "<div class=\"option-list furniture\">");
//						}catch(Exception e){}
//						
//					}
//					planData+= U.getSectionValue(phtml, "<h4 class=\"BannerHeadingH4\">Plan Details</h4>", " </div>")+U.getSectionValue(phtml, "<section class=\"section\">", "</section>");
//					if(p>12)break;
					p++;
				}
				
			//	U.log("modelPlanHtml----"+modelPlanHtml+"\n");
				
            //=======================Price========================================
			//		U.log(U.getCache(url));
					String[] price;
					String priceSec=ALLOW_BLANK;
					html=html.replaceAll("0s","0,000").replace("$1.2 mil - $2.6 mil", "$1,200,000 mil - $2,600,000 mil");
					html=html.replaceAll("0's","0,000").replace("$1.9 million", "$1,900,000 million").replace("$1.53 million", "$1,530,000 million");
					html=html.replace("Price Range: From $1.0 to $1.2 million", "Price Range: From $1,000,000 to $1,200,000 million").replaceAll("$28,500","").replaceAll("$1.0 million - $2.0 million|$1 mil - $2 mil", "$1,000,000 million - $2,000,000 million").replace("$1.2 million", "$1,200,000 million")
							.replace("$2.5 mil", "$2,500,000 million")
							.replace("$2 million", "$2,000,000 million")
							.replace("$1.3 mil", "$1,300,000 million")
							.replace("$1.2 mil", "$1,200,000 million")
							.replace("$1.8 mil", "$1,800,000 million")
							.replace("$2.9 mil", "$2,900,000 million");
				//html=html.replace("0's", "0,000");
					//modelPlanHtml=modelPlanHtml.replace(rmSec,"");
				
					
					modelPlanHtml=modelPlanHtml.replace("$28,500","").replace("$1.53 million", "$1,530,000 million");

				//	U.log(section);
					String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
					
					if(hm.containsKey(regUrl)) {
						priceSec=hm.get(regUrl);	
//						U.log("=="+priceSec);
//						price = U.getPrices(priceSec, "\\$\\d,\\d{3},\\d{3} million|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",0);
						
					}
					
//					U.log("MMMMMMMMM"+Util.matchAll(priceSec+html+modelPlanHtml, "[\\s\\w\\W]{50}720[\\s\\w\\W]{30}", 0));
					
					priceSec=priceSec.replace("$1.53 million", "$1,530,000 million").replace("$1 million", "$1,000,000 million")
							.replace("$2.2 million", "$2,200,000 million").replaceAll("$2 million", "$2,000,000 million").replaceAll("0's","0,000").replaceAll("0s","0,000").replace("$1.0 million - $2.0 million", "$1,000,000 million - $2,000,000 million").replace("$1 mil - $2 mil", "$1,000,000 million - $2,000,000 million");
//					U.log("=="+priceSec);
					html = html.replace("$2.2 million", "$2,200,000 million").replace("$1 mil", "$1,000,000 mil")
							.replace("$2.8 mil", "$2,800,000 million")
							.replaceAll("0's", "0,000").replace("$1 million", "$1,000,000 million")
							.replace("$1.1 million - $2.1 million", "$1,100,000 million - $2,100,000 million").replace("$2.5 million", "$2,500,000 million");
					html=html.replace("$1.3 mil - $2.6 mil", "$1,300,000 mil - $2,600,000 mil").replace(" million", "00,000 million").replace(".", ",");
					
					price = U.getPrices((priceSec+html+modelPlanHtml).replace("Total Price:</strong> $800,792<br>", "").replace("Total Price:</strong> $818,893<br>", ""), 
							"\\$\\d,\\d{3},\\d{3} mil - \\$\\d,\\d{3},\\d{3} mil|\\$\\d,\\d{3},\\d{3} mil - \\$\\d,\\d{3},\\d{3} mil|Price Range: \\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3} million|Price Range: \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|Price Range: From \\$\\d{1},\\d{3},\\d{3} to \\$\\d{1},\\d{3},\\d{3} million|Price Range: \\$\\d,\\d{3},\\d{3} million - \\$\\d,\\d{3},\\d{3} million|Price Range: \\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3} mil|\\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3} million|Price Range: \\$\\d{3},\\d{3}|Priced From:\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d+|</strong> \\$\\d{3},\\d{3}<br>|\\$\\d{3},\\d{3}|//Price:.*?\\$\\s*\\d{3},\\d{3}", 0);//Price:.*?\\$\\s*(\\d+,\\d+)
					
//					U.log("MMMMMMMMM"+Util.matchAll(priceSec+html+modelPlanHtml, "[\\s\\w\\W]{50}4680[\\s\\w\\W]{30}", 0));

					minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
					maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
					if (maxPrice.equals(minPrice))
						maxPrice = ALLOW_BLANK;
					U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

					// Square Feet
					String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
					String[] sqft = U.getSqareFeet(html+modelPlanHtml, "Sq Ft Apx: \\d{4} - \\d{4}|Sq Ft Apx: \\d{4}|Sq Ft Apx:\\d{4}-\\d{4}|Sq Ft Apx: \\d{4} - \\d{4}|Sq Ft Apx: \\d,d{3} - \\d,\\d{3}|Apx:</strong> \\d{4} - \\d{4}</td>|\\d,\\d{3} to \\d,\\d{3} sq. ft.| Apx:</strong> \\d{4}-\\d{4}| Apx:</strong> \\d{4}</td>|Ft Apx:[^>]{4}>[^<]{4}", 0);//Ft Apx:[^>]+>([^<]+)
					minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
					maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
					U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
					String notes = ALLOW_BLANK;
					
					html = html.replace("New Phase - Now Pre-Selling", "New Phase Now Pre-Selling");
					notes = U.getnote(html.replace("Model Home Grand Opening", ""));
					
					//=========== Remove Meta =============
					String remMeta = U.getSectionValue(html, "</title>", "<link");
					if(remMeta != null)
						html = html.replace(remMeta, "");
					String remFooter=U.getSectionValue(html, "<footer class=\"footer-default\">", "</footer>");
//					U.log(remFooter);
					if(remFooter != null) {
						html = html.replace(remFooter, "");
//						modelPlanHtml=modelPlanHtml.replace(remFooter, "");
					}
				
					// Property Types
					html=html.replaceAll("Amenity Center with covered Patio|for multigenerational families|Village|Club Estate|Estates at (Miramonte|Pleasant)|Estates of Verona|(Whitestone|Silverleaf|Heritage Ridge) Estate","");
					html = html.replace("elegant Traditional", "Traditional homes");
					html = html.replace("meets luxury", "luxury homes").replace(" luxury, and ultimate ", " luxury homes, and ultimate ");
					html =html.replace("Craftsman and Modern Farmhouse style", "Craftsman style details and Modern Farmhouse style").replace("</strong> Add Loft <br>", " a loft").replace("Lake Forest Townhomes", "").replace("executive living", "Executive Style Homes");
					comSec = comSec.replaceAll("Club Estate", "");
					if(modelPlanHtml!=null)modelPlanHtml=modelPlanHtml.replace("Modern Farmhouse Upgrade", "");
					String propertyType = U.getPropType((planData+html+modelPlanHtml+comSec).replaceAll("homes for sale mediterranean|Reading Loft|Spanish Mediterranean Upgrade Elevation|Modern Farmhouse Elevation", ""));
//					U.log("MMMMMMMMM"+Util.matchAll(planData+html+modelPlanHtml+comSec, "[\\s\\w\\W]{50}Mediterranean[\\s\\w\\W]{30}", 0));

					U.log("propety Type :" + propertyType);
					
					html=html.replace("PHASE II NOW OPEN","PHASE 2 NOW OPEN").replace("NEW PHASE 4<br> NOW OPEN", "NEW PHASE 4 NOW OPEN");
//							.replace("NEW PHASE 2<br> NOW OPEN", "NEW PHASE 2 NOW OPEN");
					html=html.replaceAll("Bower Ranch|Newton Ranch|Shiloh Ranch","");
					html=html.replaceAll("Gated Neighborhood","Gated Community").replace("Oversized Homesites", "Oversized Homesites Available");
		//			html = html.replace("oversized homesites and waterfront lots ", "oversized homesites available and waterfront lots available").replaceAll("Model Home Grand Opening| alt=\"Hot Homes Ready Now|Model Grand Opening|Price Range:</strong> Coming Soon|Center-Coming Soon|Grand Opening New Model|Pre Grand Opening|Type:</strong> New Phase of|DESIGNS NOW|Section - Sold|venue coming", "");

				
					comSec=comSec.replaceAll("Model Home Grand Opening|GRAND OPENING - Pool, Park|text01\">Coming Soon!<br>|Grand Opening - New Model Home|Grand Opening 2 Models","");
					//U.log(comSec);
//					
					html=html.replace("<b>NEW PHASE! NOW OPEN!</b>", "New phase now open")
							.replace("FINAL OPPORTUNITES","FINAL OPPORTUNITIES").replace("Oversized & Gated Homesites Available", "Oversized Homesites Available");
					String status=U.getPropStatus(comSec.replaceAll("\"Grand", "")
							+html.replace("Oversized & Gated Homesites Available!", "Oversized Homesites Available")
							.replace("Phase 2 Opening this Spring", "Phase 2 Opening Spring")
							.replaceAll("distance, opening Fall|Price Range: Coming|Golf Coming Soon|Priced From: SOLD OUT|close-outside|New Phase Coming Fall 2021|Grand Opening Mansfield|Coming Soon to Market|Creek homesites available|venue coming|playground coming|Priced From: Sold Out|Section - Sold Out|playground coming|GRAND OPENING NEW MODEL|Model Hours: Coming Soon","").replace("Grand Finale - Last Chance", "Grand Finale Last Chance"));
					status = status.replaceAll("Phase 2b", "Phase 2B").replace(" Iii ", " III ").replace(" Ii ", " II ");
					
//				U.log("MMMMMMMMM"+Util.matchAll(comSec+html, "[\\s\\w\\W]{50}final[\\s\\w\\W]{30}", 0));

					
					if(modelPlanHtml.contains("</strong> Ready For Move In")){//||html.contains("inventory_detail")
						if(status != ALLOW_BLANK) status = status+ ", Ready For Move In";
						else status = "Ready For Move In";
					}
					U.log("Status:::"+status);
					
					html = html.replaceAll("Country Club Estates</a>|Bower Ranch|Shiloh Ranch|Craig Ranch|Newton Ranch|title=\"Multi", "");
					
					
					if(planData!=null)
						planData = planData.replace("Stories:", "Story");
					
					//========================== dType ==========================
					String dType = U.getdCommType((planData+html.replaceAll("RANCH|Ranch|ranch", "").replaceAll("Multi level fitness center offering classes|Multi-Level Work Out Facility", ""))+commName+modelPlanHtml);
					
//					U.log("MMMMMMMMM"+Util.matchAll(planData+html+commName+modelPlanHtml, "[\\s\\w\\W]{50}Multi-Level[\\s\\w\\W]{30}", 0));

					U.log("DType::"+dType);
					
					add[1]=add[1].replace("Prosper ISD / Celina", "Celina").replace("Little Elm/Frisco ISD", "Little Elm");
//					U.log(Arrays.toString(latlng));
					if(add[0].length()<4 && latlng[0].length()>5) {
						add=U.getAddressGoogleApi(latlng);
						if(add==null) add=U.getGoogleAddressWithKey(latlng);
						geo="TRUE";
					}
					if(url.contains("community_details&com=58") || url.contains("community_details&com=83"))status += ", Final Phase";
					
//					if(url.contains("p=community_details&com=111"))status="Coming Soon";
					if(url.contains("http://www.grandhomes.com/gh_comm_profile.php?com=97"))notes="Pre Grand Opening";

//					status = status.replace("New Phase Now Open", "New Phase, Now Open");
					if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=110")) {
						add[0]=ALLOW_BLANK;
						add[1]="Lucas";
						add[2]="TX";
						add[3]=ALLOW_BLANK;
						latlng=U.getlatlongGoogleApi(add);
						add=U.getAddressGoogleApi(latlng);
						geo="TRUE";
					}
//				if(url.contains("community/lakes%2Dat%2Dlegacy/107/"))minPrice="$870,000";
//				if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=80"))maxPrice="$2,000,000";
//				if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=110"))minSqf="3852";
//				if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=80"))minSqf="3852";
				if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=92")) {
					maxPrice=ALLOW_BLANK;
					dType=dType.replace("2 Story,", "");
				}
//				if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=102"))minPrice="$660,000";
//				if(url.contains("https://www.grandhomes.com/index.cfm?p=community_details&com=103"))maxPrice="$910,000";
				
				//Dt21Aug21
				//repeated status Coming Soon, Coming Soon late October 2021 taken detailed
				if(url.contains("https://www.grandhomes.com/community/westminster%2Dat%2Dcraig%2Dranch/90/"))status="Grand Finale";
//				if(url.contains("https://www.grandhomes.com/community/silverleaf%2Destates%2Din%2Dfrisco/116/"))status="Coming Soon late December 2021";
				if(url.contains("/community/chadwick%2Dfarms%2D/61/"))status="Final Phase";
				if(commName.endsWith("Townhomes"))commName = commName.replace("Townhomes", "");
				
				String availHtml = U.getHTML("https://www.grandhomes.com/index.cfm?p=available_now_grid");
				String[] homes = U.getValues(availHtml, "<div class=\"uk-card uk-card-default\">", "</a></button>");
				
				for(String avail : homes)
					if(avail.contains(commName))
						if(status==ALLOW_BLANK)
							status = "Quick Move In";
						else if(!status.contains("Quick Move In"))
							status+=", Quick Move In";
				if(url.contains("https://www.grandhomes.com/community/savannah/95/")) {
					status=status.replace("Final Phase, Last Chance", "Final Phase Last Chance");
				}
					// Add all
					data.addCommunity(commName, url, comType);
					data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
					data.addSquareFeet(minSqf, maxSqf);
					data.addPrice(minPrice, maxPrice);
					data.addLatitudeLongitude(latlng[0], latlng[1],geo);
					data.addPropertyType(propertyType, dType);
					data.addPropertyStatus(status.replaceAll("Ii", "II").replaceAll("!", ""));
					data.addNotes(notes);
					data.addUnitCount(ALLOW_BLANK);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				}
				j++;
				
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
				
	
	
	}

		}

