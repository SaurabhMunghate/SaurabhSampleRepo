package com.shatam.b_101_120;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHorizonViewHomes extends AbstractScrapper{

	
	
	/**
	 * @param args
	 */
	 static int j=0;
		int i = 0;
		public int inr = 0;
		static CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractHorizonViewHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Desert View Homes - Horizon View Homes.csv", a.data()
				.printAll());

	}
	public ExtractHorizonViewHomes()
			throws Exception {
		super("Desert View Homes - Horizon View Homes","https://horizonviewhomesco.com/");
		LOGGER=new CommunityLogger("Desert View Homes - Horizon View Homes");
		// TODO Auto-generated constructor stub
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String url = "https://horizonviewhomesco.com/";
		//String base = "http://www.desertviewhomes.com/";
		String html = U.getHTML(url);
		String section = U.getSectionValue(html, ">Communities</a>", "</ul>");
		 U.log(section);
		String values[] = U.getValues(section, "<a href=\"", "\"");
//		int totalComm = values.length / 2;

		for(String value:values)
		 {
			if(value.contains("https://horizonviewhomesco.com") || value.contains("horizonviewhomestx"))
			{
				U.log("values=======================================================================================> "+value);
			addvalues(value);
			inr++;
			}

		}
		LOGGER.DisposeLogger();
		
	}
	private void addvalues(String value) throws Exception {
		// TODO Auto-generated method stub
		String html=U.getHTML(value);
		String [] commData=U.getValues(html, "<div class=\"listings-card init community\">","More Info");
		for(String infoData:commData)
		{
			String comUrl=U.getSectionValue(infoData, "<div class=\"linksWrap\">","more-info");
			comUrl=U.getSectionValue(comUrl, "<a href=\"","\"");
			addDetails(comUrl,infoData);
		}
			
	}
	private void addDetails(String comUrl, String infoData) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://horizonviewhomestx.com/neighborhood/paloma/"))return;
		U.log("community No-->"+j);
		U.log("comUrl===============>  "+comUrl);
		String html=U.getHTML(comUrl);
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(infoData, "<h3>","</h3>");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String note=U.getnote(html);
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html, "<strong>Model Address</strong>","</p>");
		//U.log(addSec);
		
		if(addSec!=null)
		{
			addSec=addSec.replaceAll("Sales Office Trailer<br />|Sales Office<br />","").replace("Dr. Windsor", "Dr., Windsor");
			addSec=addSec.replace("<p>","").replace("<br />",",");
			U.log("kkkkkkkkkk--->"+addSec);
			addSec=addSec.replace("<p>","").replace("(Coming Soon),", "");
			String[] add1=addSec.split(",");
			if(add1.length>2)
			{
				add[0]=add1[0];
				add[1]=add1[1];
				add[3]=Util.match(add1[2],"\\d{4,5}");
				U.log("kk  "+add1[2]+"  "+add[3]);
				add[2]=add1[2].replace(add[3],"");
			}
		}
		else {
			String addMapSec=U.getSectionValue(html, "<iframe src", "</iframe>");
			//U.log("addMapSec=="+addMapSec.length());
			if(addMapSec!=null) {
			//addSec=addSec.replaceAll("%2C","");
			//addSec=addSec.replaceAll("+",",");
			String googleAddress=U.getSectionValue(addMapSec, "!2s","!");
			U.log("googleAddress=="+googleAddress.length());
			if(googleAddress.length()>3) {
			//if(googleAddress!=null) {
			googleAddress=googleAddress.replace("New+Braunfels", "New Braunfels");
			googleAddress=googleAddress.replaceFirst("\\+", " ").replaceAll("\\+", ",");
			googleAddress=googleAddress.replaceAll("%2C","");
			//googleAddress=googleAddress.replaceAll("+", ",");
			add=googleAddress.split(",");
			U.log("googleAddress=="+googleAddress);	
			//}
			}
		    }
		}
		U.log("address--->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
//------------------------------------------------------------------------------------------------------------------
	String latSec=U.getSectionValue(html, "https://www.google.com/maps/embed?pb=","\"");
	if(latSec!=null)
	{
		//U.log(latSec);
	String latSec1=U.getSectionValue(latSec, "!2d","!2m");
	if(latSec1==null)
	{
		latSec1=U.getSectionValue(latSec, "!2d","!3m");
	}
//	U.log(latSec1);
	String[] rLatlong=latSec1.split("!3d");
	latlag[0]=rLatlong[1];
	latlag[1]=rLatlong[0];
	}
	U.log("Latlong==>"+latlag[0]+"  "+latlag[1]);
	
	if(add[0]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
	{
		add=U.getAddressGoogleApi(latlag);
		geo="True";
	}
	if(add[0]==ALLOW_BLANK && latlag[0]==ALLOW_BLANK){
		add[0]="11409 Business Park Circle";
		add[1]="Firestone";
		add[2]="CO";
		add[3]="80504";
		
		geo="TRUE";
		note="Address Taken From Contact";
	}
	if(latlag[0]==ALLOW_BLANK)
	{
		latlag=U.getlatlongGoogleApi(add);
		geo="True";
	}
		
//============================================Price and SQ.FT======================================================================
		
	String minPrice=ALLOW_BLANK;
	String maxPrice=ALLOW_BLANK;
		String[] urlSec=U.getValues(html, "<p><a class=\"more-info\" href=\"","\">");
		String homeHtml="";
		for(String url1:urlSec)
		{
			homeHtml=homeHtml+U.getHTML(url1.trim());
		}
		
		String avalHtml=U.getHTML(comUrl.replace("neighborhood","available-homes"));
		html=html.replaceAll("0s|0's","0,000");
		String prices[] = U.getPrices(html+homeHtml+avalHtml,
		
				"\\$\\d,\\d+,\\d+|high \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|the Low \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|price\">\\d{3},\\d{3}| \\$\\d{3},\\d{3}</li>", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		String minSqft=ALLOW_BLANK;
		String maxSqft=ALLOW_BLANK;
		
		String[] sqft = U
				.getSqareFeet(
						html+homeHtml+avalHtml,
						"\\d,\\d+ to \\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft|\\d,\\d+ sq. ft|\\d{4} total square feet|\\d{4}</span> SQFT|\\d,\\d+ square feet",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		
//--------------------REMOVED SECTION---------------------------
		html=html.replaceAll("No HOA dues |Coming Soon</li></ul>|Rancho|Ranch Marketplace", "");
		
		
//================================================community type========================================================
		String communityType=U.getCommType(html+homeHtml);
		
//==========================================================Property Type================================================
		
		String proptype=U.getPropType(html+homeHtml);
		
//==================================================D-Property Type======================================================
		avalHtml=avalHtml.replace("<p>Two-Story</p>"," 2 Story ").replace("<p>Single-Story</p>"," 1 Story ");
		if(avalHtml.contains(" Single-Story"))
		{
			html=html+" 1 Story ";
		}
//		U.log(Util.match(html+homeHtml,"[\\w\\s\\W]{30}story 1,5[\\w\\s\\W]{30}",0));
		String dtype=U.getdCommType((html+homeHtml).replace(" story 1,530 square", ""));
		
//==============================================Property Status=========================================================
		String pstatus=U.getPropStatus(html.replaceAll(" Model</h2>\\s*<p>Coming soon</p>|IKEA \\(Coming Soon\\)|<p><p>Coming Soon</p>|Move In Ready Homes|Download Available Lots|is now open",""));
		String moveHtml = U.getHTML("https://horizonviewhomesco.com/move-in-ready-homes/")+U.getHTML("https://horizonviewhomestx.com/move-in-ready-homes/");
		
		String[] moveSections = U.getValues(moveHtml, "<div class=\"listings-card init", "More Info</a>");
		U.log("moveSections : "+moveSections.length);
		for(String movSec : moveSections){
			U.log("Hello"+movSec);
			if(movSec.contains(comUrl)){
				if(pstatus.length()>4){
					pstatus =pstatus + ", Move In Ready Homes";
				}
				else{
					pstatus = "Move In Ready Homes";
				}
				break;
			}
			//break;
		}
		
//============================================note====================================================================
		U.log(add[1]+"==");
		U.log(communityName);
		communityName = communityName.replaceAll("in "+add[1].trim(), "");
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+":::::::::::::::::::::::::::::repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
		j++;
	}

}