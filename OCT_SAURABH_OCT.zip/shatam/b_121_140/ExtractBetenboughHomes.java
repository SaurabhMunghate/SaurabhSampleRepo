/**
 * @author Aditya Mukundwar 
 * @date 22/12/2016
 * 
 */
package com.shatam.b_121_140;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang.StringUtils;
import org.apache.http.util.TextUtils;
import org.apache.regexp.recompile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

import bsh.StringUtil;

public class ExtractBetenboughHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static final String BASE_URL = "https://www.betenbough.com";
	WebDriver driver=null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractBetenboughHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Betenbough Homes.csv", a.data().printAll());
	}

	public ExtractBetenboughHomes() throws Exception {

		super("Betenbough Homes", "https://www.betenbough.com/");
		LOGGER = new CommunityLogger("Betenbough Homes");
	}

	// -------New Code :By Priti-------------
	public void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHtml("https://www.betenbough.com/communities",driver);

	//	String[] comSec = U.getValues(html, "<div class=\"CommunityCard_wrapper\"", "</hgroup></div></div>");
		String[] comSec = U.getValues(html, "<div class=\"CommunityCard_wrapper\"", "</div></div></div></div></div></div>");
		U.log("Total Count:: "+comSec.length);
		for (String cSec : comSec) {
			
			addDetails(cSec);
			
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comSec) throws Exception {
		//TODO ::
//		 if(j==0)(
		{
			String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
			comUrl = BASE_URL + comUrl;
			//https://www.betenbough.com/homes-in-bushland/
          //U.log(U.getCache(comUrl));
//			if(!comUrl.contains("https://www.betenbough.com/communities/amarillo/bushland-estates"))return;
			
			U.log("Count: "+j+"\tComUrl: "+comUrl);
		//	U.log(comSec);
			
			if (data.communityUrlExists(comUrl)) {
				
				LOGGER.AddCommunityUrl(comUrl + "----Repeated----");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
//			if(!comUrl.contains("https://www.betenbough.com/communities/lubbock/harvest")) return;
			
			
			//if(comUrl.contains("https://www.betenbough.com/our-homes/all-homes/north-park")) return;
			//if(comUrl.contains("https://www.betenbough.com/homes-in-bushland/")) return;//Content Of Quincy Park Comm.
			
			comSec = comSec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replaceAll("\\s+", " ");
			String comName = U.getSectionValue(comSec, "<a class=\"CommunityCard_name text-display d-flex flex-column\"","<");
			
			comName = comName.replaceAll("href=\".*>", "");
			U.log("comName:: "+comName);
			
			String comType = ALLOW_BLANK, propType = ALLOW_BLANK, dType = ALLOW_BLANK, propStatus = ALLOW_BLANK;

			String comHtml = getHtml(comUrl,driver);
			//String MpriceSec=U.getSectionValue(comHtml, "", To)
//			WebElement btn=driver.findElement(By.className("btn btn=brand3"));
//			btn.click();
//			comHtml=getHtml(comUrl,driver);
			U.log("Price match"+Util.matchAll(comHtml, "363950",0));
//			ArrayList<String> myprice=Util.matchAll(comHtml, "\\d{6}",0);
			String pricesec=ALLOW_BLANK;
			
			
			String remove = U.getSectionValue(comHtml, "Photo Gallery</h3>", "</html>");
			if(remove!=null)
			comHtml = comHtml.replace(remove, "");
//			
			comHtml = comHtml.replaceAll("footerAnchor|RegisterAnchor", "")
					.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replaceAll("\\s+", " ");

			//======= QUICK HOMES ===============================
			String[] quickSec = U.getValues(comHtml, "<div class=\"HomeCard_wrapper\"", "</li></ul>");
			
			String allQuickData = ALLOW_BLANK;
			for(String quick : quickSec) {
				
				String quickUrl = U.getSectionValue(quick, "<a class=\"\" href=\"", "\"");
				
				try {
				if(!quickUrl.contains("http"))
					quickUrl = BASE_URL+quickUrl;
				else
					quickUrl = quickUrl;
				
				String qhtml = U.getHtml(quickUrl, driver);
				//U.log("quickUrl::"+quickUrl);
				allQuickData += U.getSectionValue(qhtml, "<div class=\"container\"", "Floor Plans</h3>");
				}catch (Exception e) {
					// TODO: handle exception
				}
				
			}
			
			String[] homeUrlSec = U.getValues(comHtml,	"<div class=\"PlanCard_wrapper\"", "</li></ul>");
			String homeHtml = ALLOW_BLANK;
			for (String home : homeUrlSec) {
			
				String homeUrl = U.getSectionValue(home, "<a class=\"\" href=\"", "\"");
				homeUrl = BASE_URL + homeUrl;
			//	U.log("homeUrl::"+homeUrl);
				
				try {
				if(!homeUrl.contains("http"))
					homeUrl = BASE_URL+homeUrl;
				else
					homeUrl = homeUrl;
				
				String hhtml = U.getHtml(homeUrl, driver);
//				if(hhtml.contains("common areas")) {
//					U.log("Found");
//				}
				homeHtml = homeHtml + U.getSectionValue(hhtml, "<div class=\"container\"", "Floor Plans</h3>");
				}catch (Exception e) {
					// TODO: handle exception
				}
				if(homeHtml.contains("SINGLE FAMILY") && homeHtml.contains("back patio")){
					break;
				}

			}
			// ---comType-----
			comType = U.getCommunityType(comHtml);
			U.log("comType::" + comType);

			// ---propType-----
//			U.log("MMMMMMMMMMMMMM "+Util.matchAll(comHtml + comSec + homeHtml + allQuickData, "[\\s\\w\\s\\W]{30}common area[\\w\\s\\W]{30}", 0));
			if(homeHtml!=null)
				homeHtml = homeHtml.replace("craftsman-style columns ", "Craftsman style details");
			
			propType = U.getPropType((comHtml + homeHtml + allQuickData).replace("Traditional Comfort", "traditional exterior, ranch style").replaceAll("No HOA fees|more space than an apartment", ""));
			U.log("propType::" + propType);

			// ---dType-----
			dType = U.getdCommType(comHtml.replace("Traditional Comfort", "traditional exterior, ranch style").replaceAll("\\+Ranch\\+Avenue|Ranch Avenue", ""));
			U.log("dType::" + dType);

			
			
			// ---propStatus-----
			comHtml = comHtml.replaceAll("style homes are now|soon\\. Contact|Move-in Ready Homes", "").replace("ONLY THREE beautiful, 1+-acre homesites available", "Only three homesites available");
			propStatus = U.getPropStatus((comHtml+comSec).replaceAll("[Q|u]ick [M|m]ove|[Q|u]ick-[M|m]ove|[M|m]ove-[I|i]n|[M|m]ove [I|i]n", ""));
			
			
			
			U.log("propStatus::" + propStatus);

			// ----SquareFeet-----

			String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;

			comHtml = comHtml.replaceAll("<span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">SQ FT</span>", "SQ FT</span>")
					.replaceAll("</span><span class=\"HomeCard_iconListLabel\" data-reactid=\"\\d+\">SQ FT</span>", " SQ FT</span>");
			
//			U.log("KKKK"+Util.matchAll(comHtml + comSec,"[\\w\\W\\s]{50}2,659[\\w\\W\\s]{100}", 0));
			String[] squareFeet = U.getSqareFeet(comHtml + comSec ,
							"\\d,\\d{3} SQ FT|\\d,\\d{3} - \\d,\\d{3} sq ft|from \\d,\\d{3} to \\d,\\d{3} square feet|>\\d,\\d{3}</span>SQ FT</span>|from \\d,\\d{3} to \\d,\\d{3} square feet|SQ FT Range</b>\\d,\\d{3} - \\d,\\d{3}|from \\d,\\d{3} – \\d,\\d{3} square feet|\\d+,\\d+ SQ. FT.|\\d,\\d+ to \\d,\\d+ square feet|\\d{1},\\{3} - \\d{1},\\d{3} sq ft|\\d{1},\\d{3} sq ft",
							0);
			minSqFt = (squareFeet[0] == null) ? ALLOW_BLANK : squareFeet[0];
			maxSqFt = (squareFeet[1] == null) ? ALLOW_BLANK : squareFeet[1];

			U.log("minSqFt:" + minSqFt + "\tmaxSqFt:" + maxSqFt);

			// -----Price-----
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			//String joinedPrice = StringUtils.join(myprice);
			String[] prices = U.getPrices(comHtml + comSec + homeHtml + allQuickData,
							"\"price\":\\d{6}|\"priceHigh\":\\d{6}|Priced at \\$\\d+,\\d+|Starting at \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\"priceLow\":\\d{6}|\"price\":\\d{6}",
							0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			
//			U.log("MMMMMMMMMMMMMM "+Util.matchAll(comHtml , "[\\s\\w\\s\\W]{30}363,950[\\w\\s\\W]{30}", 0));

			U.log("minPrice:" + minPrice + "\tmaxPrice:" + maxPrice);

			// ----Address----&-----Latlng----

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };

			/*String addSec = U.getSectionValue(comHtml,	"<div class=\"address-box\">", "</a>");

			if(addSec!= null) {
			add[0] = U.getSectionValue(addSec, "addressStreet\">", "</span>")	.trim().replace(".", "");
			add[1] = U.getSectionValue(addSec, "addressCity\">", ", </span>").trim();
			add[2] = U.getSectionValue(addSec, "addressState\">", "</span>").trim();
			add[3] = U.getSectionValue(addSec, "addressZipCode\">", "</span>").trim();
			}*/
			
			String addSec = U.getSectionValue(comHtml,	"<span class=\"AgentsSection_text\" ", "<a href=");
			U.log("addSec :"+addSec);
			if(addSec != null){
				addSec = addSec.replace("</span><span class=\"AgentsSection_text\"", ",").replaceAll("data-reactid=\"\\d+\">", "")
						.replaceAll("</span>", "");
				
				add = U.getAddress(addSec);
			}
			U.log("address: " + Arrays.toString(add));

			String laString = U.getSectionValue(comSec, "<a href=\"https://www.google.com/maps/place/", "/");
			
			if(laString!= null)
			{
				U.log("laString:: "+laString);
				latLng = laString.split(",");
			}
			
			if(add[0]!= null) 
			add[0] = add[0].replace("Tradewind Square Model Home","");	
			
			if(add[0].length()<4 && latLng[0]!= null){
				String add1[] = U.getAddressGoogleApi(latLng);
				if(add1 == null) add1 = U.getAddressHereApi(latLng);
				add = add1;
				
				geo="TRUE";
			}
			
			if(quickSec.length>0) {
				
				if(propStatus==ALLOW_BLANK)
					propStatus = "Quick Move-In Homes";
				else
					propStatus += ", Quick Move-In Homes";
			}
			
			
			
			//================ note ===================
			String note = U.getnote(comHtml);

			if(comUrl.contains("https://www.betenbough.com/homes-in-bushland/")) {
				
				comName = "Bushland Estates";
				add[0] = "8780 Heritage Hills Pkwy";
				add[1] = "Amarillo";
				add[2] = "TX";
				add[3] = "79119";
				
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
				note = "Address Taken From Description";
			}
			
			
			U.log("lat: " + latLng[0] + " lng: " + latLng[1]);
			//From Img
			if(comUrl.contains("https://www.betenbough.com/our-homes/all-homes/milwaukee-ridge/")){
				propStatus = getStatus(propStatus, "Two Homesite Left");
			}
			
			if(comUrl.contains("https://www.betenbough.com/communities/amarillo/saturn-terrace"))maxPrice="$195,950";
			if(comUrl.contains("https://www.betenbough.com/communities/lubbock/bell-farms"))dType="Ranch";
			//if(comUrl.contains("https://www.betenbough.com/communities/amarillo/heritage-hills"))maxPrice="$";
			
			
			
//			if(comUrl.contains("communities/odessa/ratliff-ridge"))propType=propType.replaceAll("Craftsman Style Homes,|, Common Area", "");
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addNotes(U.getnote(comHtml));
            data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(ALLOW_BLANK);
		}
		j++;

	}
	
	public static String getHtml(String url, WebDriver driver)
			throws Exception {
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		
		if (!f.exists()) {

			BufferedWriter writer = new BufferedWriter(new FileWriter(f));

			driver.get(url);
			Thread.sleep(10000);
			((JavascriptExecutor) driver).executeScript(
					"window.scrollBy(0,1500)", ""); // y value '400' can be
			Thread.sleep(10000);

			try {
				WebElement option = null;
				driver.getPageSource();
//				option = driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div[9]/div/div[2]/div[3]/div/div/div[3]/div[2]/span[2]"));//--------//*[@id="cntQMI"]
				option = driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div[8]/div/div[2]/div[3]/div/div/div[3]/div[2]/span[2]"));//--------//*[@id="cntQMI"]
//				option = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[1]/div[7]/div/div[2]/div[3]/div/div/div[3]/div[2]/span[2]"));
				if(option.isDisplayed())
				 option.click();
				Thread.sleep(10000);
				((JavascriptExecutor) driver).executeScript(
						"window.scrollBy(0,500)", ""); // y value '400' can be
				Thread.sleep(10000);
				Thread.sleep(3000);
				option = driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div[9]/div/div[2]/div[3]/div/div/div[3]/div[2]/span[2]"));
				if(option.isDisplayed())
				option.click();
				Thread.sleep(3000);
				U.log("::::::::::::click succusfull1:::::::::");

			} catch (Exception e) {
//				Thread.sleep(3000);
//				WebElement option = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[1]/div[8]/div/div[2]/div[3]/div/div/div[3]/div[2]/span[2]"));
//				if(option!=null&&option.isDisplayed())
//				option.click();
//				Thread.sleep(3000);
				U.log("click unsuccusfull1" + e.toString());
			}
			
			U.log("Current URL:::" + driver.getCurrentUrl());
			html = driver.getPageSource();
			Thread.sleep(2 * 1000);

			writer.append(html);
			writer.close();

		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}

		return html;

	}

	private String getStatus(String pStatus, String ImgStatus){
		if(pStatus == ALLOW_BLANK) pStatus = ImgStatus;
		else if(pStatus != ALLOW_BLANK) pStatus += ", "+ImgStatus;
		return pStatus;
	}
}
