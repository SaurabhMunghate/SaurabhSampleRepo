/** @author Sagar Meshram
 *  @date 21/03/2022
 */
package com.shatam.b_121_140;

import java.util.Arrays;
import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHHhomes extends AbstractScrapper {
	int i = 0;
	static String BASEURL="https://hhhomes.com";
	static WebDriver driver = null;
	static CommunityLogger LOGGER;
	
	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new ExtractHHhomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"H&H Homes.csv", a.data().printAll());
	}

	public ExtractHHhomes() throws Exception {
		super("H&H Homes", "https://www.hhhomes.com/");
		LOGGER = new CommunityLogger("H&H Home");
	}
	
	public void innerProcess() throws Exception{
		String html=U.getHTML(BASEURL);
		String regionpart=U.getSectionValue(html, "<div class=\"footer-top d-none d-md-block\">", "<footer role=\"footer\">");
		String[] regionSection=U.getValues(regionpart, "<div class=\"masonry-item\">", "</ul>");
		U.log("regionSection :"+regionSection.length);
		String regionhtml="";
		for(String regionSec:regionSection) {
			String regionUrl=U.getSectionValue(regionSec, "<h4><a href=\"", "\">");
			regionhtml=U.getHTML(regionUrl);
			String []comUrlSection=U.getValues(regionhtml, "<div class=\"community-image-section\">", "View Community");
			U.log("comUrlSection :"+comUrlSection.length);
			for(String comUrlSec :comUrlSection) {
				String comUrl=U.getSectionValue(comUrlSec, "<a href=\"", "\"");
				addDetails(comUrl,comUrlSec);
			}
		}
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comUrl,String comUrlSec) throws Exception{
//		if(i>=17)
		{
//		if(!comUrl.contains("https://hhhomes.com/triad/josephs-creek/"))return;
		
		U.log("Count :"+i);
		LOGGER.AddCommunityUrl(comUrl);
		if(data().communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"*****************RETURN***********");
			return;
		}
		if(data().communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"*****************REDIRECT***********");
			return;
		}
//		U.log("comURL :"+comUrl);
		String comhtml=U.getHTML(comUrl);
		comhtml=U.getSectionValue(comhtml, "</title>", "</section>");
		String comName=U.getSectionValue(comhtml, "<h1>", "</h1>");
		U.log(comName);
		//===========ADDRESS & LATLNG===============
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		String addSec=U.getSectionValue(comhtml, "<span class=\"address\"><i class=\"fas fa-map-marker-alt\"></i>", "</span>");
		addSec=addSec.replaceAll(", (\\d{5})", " $1").replace("Clayton, NC 27520, Clayton,", "Clayton,").replace("Reidsville, NC, Reidsville,", "Reidsville,");
		U.log("------"+addSec);
		add=U.findAddress(addSec);
		if(add==null)
			addSec=U.getSectionValue(comhtml, "class=\"fas fa-map-marker-alt\"></i> ", "</span>");
			addSec=addSec.replaceAll(", (\\d{5})", " $1").replace(", ,", ",");
			
			if(comUrl.contains("https://hhhomes.com/myrtle-beach/calabash-station/")) {
				addSec="515 Deer Path, Calabash, NC 28467";
				add=U.getAddress(addSec);
				geo="TRUE";
			}
			
			add=U.getAddress(addSec);
		
		
		U.log(">>>>>>"+Arrays.toString(add));
		
		latlng[0]=U.getSectionValue(comhtml, "var defaultLat = ", ";");
		latlng[1]=U.getSectionValue(comhtml, "var defaultLng = ", ";");
		U.log(Arrays.toString(latlng));
		
		//=========FLOORPLANS===========
		String florpart=U.getSectionValue(comhtml, "<div id=\"community-floorplans\">", "<!--/.floorplan -->");
		String[] florSection=U.getValues(florpart, "<div class=\"col-12 col-md-4 col-lg-3 text-center\">", "</ul>");
		String florhtml="";
		for(String florSec :florSection) {
			String florUrl=U.getSectionValue(florSec, "<a href=\"", "\">");
			florhtml+=U.getHTML(florUrl);
		}
//		//========Available home=======
//		String avalpart=U.getSectionValue(comhtml, "", "<!--/.floorplan -->");
//		String[] florSection=U.getValues(florpart, "<div class=\"col-12 col-md-4 col-lg-3 text-center\">", "</ul>");
//		String florhtml="";
//		for(String florSec :florSection) {
//			String florUrl=U.getSectionValue(florSec, "<a href=\"", "\">");
//			florhtml=U.getHTML(florUrl);
//		}
		//==========price=======
		String minPrice=ALLOW_BLANK , maxPrice=ALLOW_BLANK;
		comhtml=comhtml.replace("Homes starting from the mid $300's", "Homes starting from the mid $300,000");
		String[] price = U.getPrices(comhtml+florhtml,"starting from the mid \\$\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice +" :: "+ maxPrice);
		//==========SQ-FT=======
		String minSqf=ALLOW_BLANK , maxSqf=ALLOW_BLANK;
		String[] sqft =U.getSqareFeet(comhtml+florhtml+comUrlSec, "from \\d{4} to \\d{4} Sq Ft.|\">\\d,\\d{3} - \\d,\\d{3}</p>|>\\d,\\d{3}</p>|\\d{4} to \\d{4} square feet", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log(minSqf +" :: "+ maxSqf);
		//=========Com type========
		String ctype=U.getCommunityType(comhtml+comUrlSec);
		//=========prop type========
//		comhtml=comhtml.replaceAll("", "");
		florhtml=florhtml.replaceAll("the-cottages-at-olde|The Cottages at Olde|value=\"Cottages at|\">Cottages at Indian|\">Cottages at Shaftesbury<|\">Cottages at Wilson", "");
		String ptype=U.getPropType((comhtml+florhtml).replaceAll("the-cottages-at-|The Cottages at Olde|/the-cottages-at-olde-|new Townhome selections|Greens Townhomes at|of Townhomes will|The Villas at (Fisher|Sandridge|S, dridge|Seaside|Sea)|The Villas, anding|Logans Manor|Manor at Lexington|Victoria Manor|the-villas-at|The Villas at Fisher|the-villas-at-fisher|h/villas-at-seaside|/villas-at-sandridge|\">Villas at|Bay Villas\">Summer Bay Villas</|The Villas at Fisher Landing\">The Villas at|The Villas at Sandridge\"|The Villas at Sandridge|\"The Villas at Seaside\">The Villas at Seasi", ""));
//		U.log(">>>>>>>"+Util.matchAll(comhtml+florhtml, "[\\s\\w\\W]{30}villas[\\s\\w\\W]{30}", 0));

		//=========D-prop type========
		florhtml=florhtml.replaceAll("<li><h2>(\\d)</h2><p>Stories</p></li>", "<li> $1 Story </li>");
		String dtype=U.getdCommType((comhtml+florhtml).replaceAll("Greens at Colonial Charters\">|Greens at Colonial Charters</|Townhomes at Colonial Charters\">|Townhomes at Colonial Charters</|-ranch|Branch|(Hawk|Timberland) Ranch", ""));

		//=========prop status========
		//.replaceAll("(Q|q)uick (M|m)ove", "")
		
		comhtml = comhtml.replace("floorplans or quick move-in ready homes", "floorplans or quick move-in homes");
		
		if(comhtml.contains("There are Currently No Quick Move-in Ready Homes in this Community.")) {
			comhtml = comhtml.replaceAll("(Q|q)uick (M|m)ove", "");
		}
		
		String pstatus=U.getPropStatus((comUrlSec+comhtml).replaceAll("new phase coming later this year|new homebuyers to qualify for USDA financing|homesites coming later this year|New Phase Coming Soon! This beautiful|ust three homes left in this rural|now SOLD OUT! To join", "")); //.replaceAll("Quick Move-in", "")
//		U.log(">>>>>>>"+Util.matchAll(comUrlSec+comhtml, "[\\s\\w\\W]{30}from the mid[\\s\\w\\W]{30}", 0));
		
		
		pstatus = pstatus.replace("Quick Move-in", "Quick Move-in Homes")
				.replace("Quick Move-in Homes Homes", "Quick Move-in Homes")
				.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
 				
		String notes=U.getnote(comhtml);
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				
		
		data.addCommunity(comName,comUrl, ctype);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(notes);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
	}
		i++;
	}
}
//	public void innerProcess() throws Exception {
//		String comListPageHtml = U.getHTML("https://www.hhhomes.com/API/communities.json");
//		String homesListPageHtml = U.getHTML("https://www.hhhomes.com/API/homes.json");
//		String modelListPageHtml = U.getHTML("https://www.hhhomes.com/API/models.json");
//		
//		comListPageHtml = StringEscapeUtils.unescapeJava(comListPageHtml);
//		homesListPageHtml = StringEscapeUtils.unescapeJava(homesListPageHtml);
//		modelListPageHtml = StringEscapeUtils.unescapeJava(modelListPageHtml);
//		
//		String [] comSections = U.getValues(comListPageHtml, "{\"com_id", "timestamp\"");
//		U.log(comSections.length);
//		
//		for(String comSec : comSections){
////			if(j>=40)
//
////			try{
//			{			
//			String comName = U.getSectionValue(comSec, "com_name\":\"", "\"");
//			String comUrl = "https://www.hhhomes.com"+ U.getSectionValue(comSec, "url\":\"", "\"");
//			//U.log("Community Url:\t" + comUrl);
//
//	//
//			
//			if(data.communityUrlExists(comUrl)){
//				LOGGER.AddCommunityUrl(comUrl+"::::::::::Repeated");
//			}
//			LOGGER.AddCommunityUrl(comUrl);
//			U.log("::::::::::::::::::::"+j);
//			U.log(comName+"====\t"+comUrl);
//		
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-fayetteville-nc/the-highlands-at-bedford")) {
//				LOGGER.AddCommunityUrl("========= Return =================== "+comUrl);
//				continue;
//			}
//			
//			//TODO:
////			if(!comUrl.contains("https://www.hhhomes.com/new-homes-pinehurst-nc/villages-at-the-carolina"))continue;
////			U.log("comSec==="+comSec);
//			
//			//--------Address----------
//			//U.log(U.getCache(comUrl));
//			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//			String geoCode="False";
//			
//			if(comSec.contains("GPS to Community")) {
//				String addsec = U.getSectionValue(comSec, "GPS to Community", "\",\"com_description\"");
//				String rem=U.getSectionValue(addsec, "<a href=", ">");
//				if(rem!=null)
//				addsec=addsec.replace(rem, "");
////				U.log("addsec1======="+addsec);
//				
//				String addsec1 = U.getSectionValue(addsec, "</strong>:", "</p>");
////				U.log(">>>>>>>>>"+addsec1);
//				if(addsec1==null)
//					 addsec1 = U.getSectionValue(addsec, "</strong>", "</a>");
////				U.log(">>>>>>>>>"+addsec1);
//				addsec1=U.getNoHtml(addsec1);
//					U.log(addsec1);
//				add= U.getAddress(addsec1);
//			}
//	
//			if(comSec.contains("home is located at")) {
//				String addsec = U.getSectionValue(comSec, "home is located at", ".")+"<";
//			//	U.log(addsec);
//				add= U.findAddress(addsec);
//			}
//			if(comSec.contains("Sales Center ")) {
//				String addsec = U.getSectionValue(comSec, "Sales Center ", ".")+"<";
//			//	U.log(addsec);
//				if(addsec!=null)addsec = addsec.replace("Dr", "Dr,").replace("NC,", "NC");
//				add= U.findAddress(addsec);
//			}
//			if(add == null) {
//				add = new String[4];
//				add[0]=ALLOW_BLANK;
//				add[1]=ALLOW_BLANK;
//				add[2]=ALLOW_BLANK;
//				add[3]=ALLOW_BLANK;
//			}
//			String addSec = U.getSectionValue(comSec, "gmap_url_address\":\"https://maps.google.com/?q", "z=");
//			if(addSec != null && add[0]==ALLOW_BLANK){
//			//	U.log("addSec : "+addSec);
//				addSec = addSec.replace("+NC+", ", NC ").replace("+SC+", ", SC ");
//				addSec = addSec.replace("+", " ");
//			//	U.log(comSec);
//				add[1]  = U.getSectionValue(comSec, "city_name\":\"", "\"");
//				U.log("city : "+add[1]);
//				add[2]  = U.getSectionValue(comSec, "state_code\":\"", "\"");
//				U.log("state : "+add[2]);
//				//addSec  =U.formatAddress(addSec);
//				add[0]  = Util.match(addSec, "(.*?)"+add[1]+",",1);
//				U.log("street : "+add[0]);
//				add[3]  = Util.match(addSec, add[2]+"\\s*(\\d{5})&",1);
//				U.log("zip : "+add[3]);
//				U.log(Arrays.toString(add));
//			}
//			String [] latLng = {ALLOW_BLANK,ALLOW_BLANK};
//			latLng[0] = U.getSectionValue(comSec, "com_lat\":", ",");
//			latLng[1] = U.getSectionValue(comSec, "com_lng\":", ",");
//			U.log(Arrays.toString(latLng));	
//			add[0]=add[0].replace("Lexington Plantation", "");
//			
//			if(add[0]!=null && add[0].length()<4 && latLng[0]!=null && latLng[0].length()>4){
//				add = U.getAddressGoogleApi(latLng);
//				if(add == null) add = U.getAddressHereApi(latLng);
//				geoCode="True";
//			}
//			
//			if (add[0].trim().endsWith(",")) {
//				add[0]  = add[0].replace(add[0].charAt(add[0].length()-1)+"", "");
//			}
//			
//			//--------homes data---
//			String allHomesdata = ALLOW_BLANK;
//			String[] homeSections = U.getValues(homesListPageHtml, "{\"inv_id\":", "\"timestamp\"");
//			U.log("Total homes : "+homeSections.length);
//			
//			for(String homeSec : homeSections){
//				//U.log(comName + "\t"+ U.getSectionValue(homeSec, "com_SmartTouchID", "com_builder"));
//				if(homeSec.contains("com_name\":\""+comName+"\",\"") && homeSec.contains("\"inv_status\":\"Active\"")){
//					allHomesdata += homeSec+"\n::::::New Home:::::::\n";
//					U.log(":::::::::::::Found Home::::::::::");
//				}
//			}
//			allHomesdata = allHomesdata.replaceAll("inv_stories\":", "inv_ Stories ");
//			//U.log(allHomesdata);
//			//---floor-model data-----------
//			String allmodelsdata = ALLOW_BLANK;
//			String[] modelSections = U.getValues(modelListPageHtml, "cmod_modelId", "timestamp\":");
//			U.log("Total Models homes : "+modelSections.length);
//			
//			for(String modelSec : modelSections){
//				//U.log(comName + "\t"+ U.getSectionValue(modelSec, "com_SmartTouchID", "com_builder"));				
//				if(modelSec.contains("com_name\":\""+comName+"\"")){
//					//if(!modelSec.contains("inv_status\":\"Sold") && !modelSec.contains("com_status\":\"ComingSoon"))
//					{
//						allmodelsdata += modelSec+"\n::::::New Home:::::::\n";
//						U.log(":::::::::::::Found Model Home::::::::::");
////						U.log("modelSec =="+modelSec);
//					}
//					
//				}
//			}
//			allmodelsdata = allmodelsdata.replaceAll("cmod_stories\":|\"mod_stories\":|\"mod_storiesDisplay\":", "inv_ Stories ");
//			
//			//-----prices-------
//			String lowPrice  = "$"+U.getSectionValue(comSec, "com_priceLow\":", ",")+",000" ;
//			String highPrice  = "$"+U.getSectionValue(comSec, "com_priceHigh\":", ",")+",000" ;
////			U.log(Util.matchAll(lowPrice+highPrice+allmodelsdata+allHomesdata+comSec,"[\\w\\s\\W]{30}1.5 story[\\w\\s\\W]{30}",0));
//			allHomesdata= allHomesdata.replaceAll("\"Sold\",\\s*\"inv_price\":\\d+", "");
//			allmodelsdata= allmodelsdata.replaceAll("\"Sold\",\\s*\"inv_price\":\\d+", "");
//			comSec = comSec
//					.replace("$227s", "$227,000").replace("High $200's", "High $200,000")
//					.replaceAll("0’s|0's|0s", "0,000");
//		//	U.log("====="+comSec);
//			if(comUrl.contains("/new-homes-charlotte-nc/baileys-run"))lowPrice="$200,000";
//			U.log(lowPrice+"\t"+highPrice);
//			
//			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			//U.log("mmmmmm"+Util.matchAll(comSec+lowPrice+highPrice+allmodelsdata+allHomesdata, "[\\w\\s\\W]{30}225000[\\w\\s\\W]{30}", 0));
//			
//			String availhtml="";
//			String floorhtml="";
//			String comhtml="";
//			try {
//				availhtml=U.getHtml(comUrl+"/homes", driver);
//				Thread.sleep(3000);
//				floorhtml=U.getHtml(comUrl+"/plans", driver);
//				Thread.sleep(3000);
//			comhtml=U.getHtml(comUrl, driver);
//			Thread.sleep(3000);
//			}
//			catch(Exception e) {
//				
//			}
//			String fphtml="";
//			String[] floorplanSec=U.getValues(floorhtml, "<div class=\"plans-list-media\">", "<span>Floor Plan PDF");
////			U.log("LLLLLLLLLLL"+floorplanSec.length);
//			for(String floorplan : floorplanSec) {
//				String fpUrl="https://www.hhhomes.com"+U.getSectionValue(floorplan, "href=\"", "\"");
////				U.log("fpUrl==="+fpUrl);
//				 fphtml+=U.getHtml(fpUrl, driver);
//			}
//			
//			String rem=U.getSectionValue(availhtml, "<h3>Filter", "Area<");
//			if(rem!=null) {
//				availhtml=availhtml.replace(rem,"");
//			}
//			String rem1=U.getSectionValue(comhtml, "<h3>Filter", "Area<");
//			if(rem1!=null) {
//				comhtml=comhtml.replace(rem1,"");
//			}
//			String rem3=U.getSectionValue(floorhtml, "<h3>Filter", "Area<");
//			if(rem3!=null) {
//				floorhtml=floorhtml.replace(rem3,"");
//			}
//			String rem4=U.getSectionValue(fphtml, "<h3>Filter", "Area<");
////			U.log(">>>>>>"+rem4);
//			if(rem4!=null) {
//				fphtml=fphtml.replace(rem4,"");
//			}
//			
//			//U.log("mmmmmm"+Util.matchAll(availhtml+floorhtml+comhtml, "[\\w\\s\\W]{30}190[\\w\\s\\W]{30}", 0));
//			comhtml=comhtml.replaceAll("0s", "0,000");
//			String modelSec="";
//			try {
//			String modelHtml=U.getHtml(comUrl+"/model-homes",driver);
//			Thread.sleep(3000);
//			
//			String mSections[]=U.getValues(modelHtml, "result-content", "testimonial-wrapper ng-scope");
//			U.log(mSections.length);
//			for(String mS:mSections) {
//				modelSec+=mS;
//				
//			}
//			}
//			catch(NullPointerException ne) {}
//			
////			U.log("======="+modelSec);
//			
////			U.log(comSec);
//			lowPrice = lowPrice+"</li>";
//			comhtml = comhtml.replaceAll("0's", "0,000");
//			String prices[] = U.getPrices((fphtml+availhtml+allHomesdata+floorhtml+comhtml+modelSec+lowPrice),
//					"From The \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</li>|Priced from the \\$\\d{3},\\d{3}|Price: \\$\\d{3},\\d{3}",0);
//			U.log(Arrays.toString(prices));
//		//	String prices[] = U.getPrices((lowPrice+highPrice),"\\$\\d{3},\\d{3}|Priced from the \\$\\d{3},\\d{3}|Price: \\$\\d{3},\\d{3}",0);
//			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
//			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
//
//			
////			U.log(">>>>>>>>"+Util.matchAll(floorhtml, "[\\w\\s\\W]{100}200,000[\\w\\s\\W]{100}", 0));
////			U.log(">>>>>>>>"+Util.matchAll(fphtml, "[\\w\\s\\W]{100}200,000[\\w\\s\\W]{100}", 0));
////			U.log(">>>>>>>>"+Util.matchAll(fphtml+availhtml+allHomesdata+floorhtml+comhtml+modelSec+lowPrice, "[\\w\\s\\W]{100}200,000[\\w\\s\\W]{100}", 0));
//
///*			if(highPrice != null && highPrice.contains("$0,000")) highPrice = null;
//			if(lowPrice != null && lowPrice.contains("$0,000")) lowPrice = null;
//
//			minPrice = (minPrice == ALLOW_BLANK && lowPrice != null) ? lowPrice: ALLOW_BLANK;
//			maxPrice = (maxPrice == ALLOW_BLANK && highPrice != null) ? highPrice : ALLOW_BLANK;
//			*/
//			U.log("Price"+minPrice+"\t"+maxPrice);
////			mod_sqftDisplay\":\"\\d{4}-\\d{4}
//			//-----sqft-----
//			String minSqft= ALLOW_BLANK, maxSqft = ALLOW_BLANK;
//			String sqft[] = U.getSqareFeet(comSec+floorhtml+modelSec+fphtml+availhtml, 
//					"\\d,\\d{3} Sq Ft|\\d{4} Sq Ft</li>|\\d{4}-\\d{4} Sq Ft</li>|will range from \\d{4} to \\d{4} Sq Ft| and \\d{4} to \\d{4} square feet|\\d{1},\\d{3} Sq Ft|com_sqftLow\":\\d{3,4},|com_sqftHigh\":\\d{4},|cmod_sqft\":\\d{4}", 0);
//			//U.log(Arrays.toString(prices));
//			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
//			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			U.log(minSqft+"\t"+maxSqft);
////			U.log("allmodelsdata====="+allmodelsdata);
////			U.log(Util.matchAll(comSec+allmodelsdata, "[\\w\\s\\W]{100}2955[\\w\\s\\W]{100}", 0));
////			U.log(Util.matchAll(allHomesdata+modelSec, "[\\w\\s\\W]{100}2955[\\w\\s\\W]{100}", 0));
//
//			//			U.log(Util.matchAll(comSec, "[\\w\\s\\W]{50}2433[\\w\\s\\W]{50}", 0));
//
//			//---comtype--
//			String comType =ALLOW_BLANK;
//			//
////			U.log(comSec);
//
//			comSec = comSec.replace("acksonville Country Club - 5 miles", "");
//			comSec = comSec.replace("beach amenities, golf courses", "");
//			comSec = comSec.replace("resort-style living", "").replace("championship golf ", "");
//			//
//			comSec = comSec.replaceAll("Country Club \\d+\\.\\d+", "");
//			comSec = comSec.replaceAll("Country Club-(\\s)?\\d+", "");
//			//
//			comSec = comSec.replaceAll("Golf Course (-)? \\d+", "").replaceAll("Public Golf Courses by Golf Diges|award-winning golf courses and|lake and disc golf course\\)", "");
//			comSec = comSec.replaceAll("Golf Club (-)? \\d+", "");
//			comSec = comSec.replaceAll("golfing|Golfing", "");
////			U.log(Util.match(comSec, ".*Golfing.*"));
//			//
//			//Country Club 3.5 Miles
//			comType = U.getCommType(comSec);
//			U.log("comType : "+comType);
//			
//			
//			allmodelsdata  = allmodelsdata.replaceAll("mod_stories\":", " Stories: ").replace("two story 3000 ", "two story, 3000 ");
//			//U.log(allmodelsdata);
//			//-----dtype-------
//			String dType = ALLOW_BLANK;
//			comSec=comSec.replace("1-2 Story ", "1 story - 2 Story ").replace("1.5-2 Story Homes ", "1.5 story , 2 story").replaceAll("No HOA fees or", "");
//			dType = U.getdCommType((comSec+allHomesdata+allmodelsdata).replaceAll("3000 sq. ft. home|Branching|franchises|floor|Floor|FLOOR|\"inv_ Stories 2|Stories \\d,\"inv_|\\d bedroom|level floor plan", "").replace("Stories \"1-1.5\"", "Stories 1 - 1.5 story").replace("1 – 1.5 story", "story 1, 1.5 story ").replace("1.5 to 2-story", "1.5 story to 2-story"));
//			U.log("dType : "+dType);
////			U.log("mmmmmm"+Util.matchAll(comSec, "[\\w\\s\\W]{100}1.5[\\w\\s\\W]{100}", 0));
//
////			U.log(Util.match(allHomesdata.replaceAll("Branching|franchises|floor|Floor|FLOOR|\"inv_ Stories 2|Stories \\d,\"inv_|\\d bedroom|level floor plan", "").replace("Stories \"1-1.5\"", "Stories 1 - 1.5 story").replace("1 – 1.5 story", "story 1, 1.5 story ").replace("1.5 to 2-story", "1.5 story to 2-story"), ".*story 3.*"));
//			//---proptype-----
//			allmodelsdata = allmodelsdata.replace("level luxury", "level luxury homes");
//			String propType = ALLOW_BLANK;
//			allmodelsdata = allmodelsdata.replaceAll("traditional size dining|traditional style tub|traditional family values", "");
//			allHomesdata = allHomesdata.replaceAll("traditional size dining|traditional style tub|traditional family values", "");
////			U.log(Util.matchAll(allHomesdata, ".*traditional.*", 0));
//			comSec = comSec.replace("Low Annual HOA's", "Farms HOA")
//					.replaceAll("limited homesite community|education available at Coastal|centered around traditional|access to the Intracoastal|beach, intracoastal| No HOA ", "");
//
////			U.writeMyText(comSec+(allHomesdata+allmodelsdata));
//			propType = U.getPropType(comSec+(allHomesdata+allmodelsdata).replaceAll("limited homesite community| No HOA |\"A Traditional|_a_traditional|No HOA fees or|traditional (tub|bathtub|sized bathtub|full bath)| education available at Coastal|_traditional_|access to the Intracoastal|beach, intracoastal", ""));
//			U.log("propType : "+propType);
//			
//			//----propStatus---
//			
//			String propStatus = ALLOW_BLANK;
//			
//			
//			
//			comSec = comSec.replaceAll("'Closeout'\"><em>Closeout Community|H&H Homes now|hideSold|_sold|'Closeout'\"><em>Closeout Community</em>|Limited time offer\\. Restrictions|before it's completely SOLD|Homes now available in Lauren|hoose a move-in ready home,|location for the coming soon|is completely SOLD OUT|this LAST opportunity is gone| on 50 available homesites. Each townhome |have very limited opportunities to purchase |Give us a call today before this LAST opportunity is gone|Limited homesite remain in the|International Drive is NOW OPEN|for sale in Turnberry are selling quickly|Soon: (The )?Fayetteville|bar coming|phase of the community offers|Consultants? for quick move|will only offer \\d+ available ", "")
//					.replace("New Phase of Summerwind Plantation COMING SOON", "New Phase COMING SOON")
//					.replace("Phase II is now SOLD OUT", "Phase II SOLD OUT")
//					.replace("FINAL Buying Opportunities", "FINAL Opportunities");
//			//.replace("Now Building in Phase II", "Now Building Phase II")
//			if(allHomesdata.contains("\"inv_status\":\"Active\",\"")) {
//				comSec=comSec+" Move-In Ready ";
//			}
//			comSec=comSec.replaceAll("'Closeout'\"><em>Closeout Community|Now Open For Homesite Tour|Creek will have limited homesite|Model Home Now|3 Coming April 2021|Internet Options Now Available", "")
//					.replace("WE'RE NOW </strong></span><strong style='color: #ff0000;'>S</strong><strong style='color: #ff0000;'>ELLING", "WE'RE NOW SELLING")
//					.replace("New Highcroft Phase Coming Fall 2021", "New Phase Coming Fall 2021");
//			
//			propStatus = U.getPropStatus(comSec
//					.replace("Phase 2 Is Now Open", "Phase 2 Now Open").replace("Phase 2 Is Now open", "Phase 2 Now open").replace("PHASE 1 IS NOW SOLD OUT", "PHASE 1 SOLD OUT").replace("PHAS</strong><strong>E COMING SOON", "NEW PHASE COMING SOON"));
//
//			U.log("propStatus : "+propStatus);
////			U.log("mmmmmm"+Util.matchAll(comSec, "[\\w\\s\\W]{30}ONLY 2 HOMEBUYING OPPORTUNITIES [\\w\\s\\W]{30}", 0));
//			//String homedata = U.getHTML(comUrl+"/homes")
//			add[0]=add[0].toLowerCase();
//			String secZip = U.getSectionValue(comSec, "\"com_zip\":\"", "\"");
//			if(secZip==null)secZip=ALLOW_BLANK;
////			U.log(U.getSectionValue(comSec, "\"com_directions\":\"", "\"").contains(add[3]));
//			if(U.getSectionValue(comSec, "\"com_directions\":\"", "\"")!=null && (U.getSectionValue(comSec, "\"com_directions\":\"", "\"").contains(add[3]) && secZip.equals(add[3]))) {
//				U.log("Hello in false");
//				geoCode="False";
//			}
//			else {
//				U.log("Hello in true");colonial
//				geoCode="True";
//			}
//			String descriptionSec= U.getSectionValue(comSec,"\"com_description\":\"", "\"");
//			if(descriptionSec!=null) {
//			//	U.log(descriptionSec);
//				if(descriptionSec.toLowerCase().contains(add[0].trim()) && descriptionSec.contains(add[1]) && descriptionSec.contains(add[3])&& descriptionSec.contains(add[2]) && geoCode=="True") {
//					geoCode="False";
//				}
//			}
////			U.log(descriptionSec.contains(add[1]));
//
////			U.log(secZip.equals(add[3])+"::::::::::"+U.getSectionValue(comSec, "\"com_directions\":\"", "\"").contains(add[3]));
//
//			//Address is not visible on page
////			if(comUrl.contains("https://www.hhhomes.com/new-homes-fayetteville-nc/the-midlands-at-bedford")) geoCode = "True";
//			//address is coming from model home
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-wilmington-nc/cane-garden-village")) {minPrice = "$210,000";maxPrice="$220,000";propStatus="Closeout";propType=ALLOW_BLANK;dType=ALLOW_BLANK;};
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-wilmington-nc/sparrows-bend")) { geoCode = "False";}
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-wilmington-nc/riverlights")){
//				add[0] = "235 Trawlers Way";
//				geoCode = "False";
//			}colonial
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-jacksonville-nc/homeplace-at-holly-ridge"))minPrice="$180,000";
//			add[0]=add[0].replaceAll("is located in the glenmere clubhouse go now: ", "");
//			
//			if(comUrl.contains("new-homes-fayetteville-nc/river-bluff")) propStatus = "New Homes Coming Soon";
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-raleigh-nc/franklin-park-at-carpenter-village")) propStatus = "Final Phase";
////			if(comUrl.contains("https://www.hhhomes.com/new-homes-wilmington-nc/cane-garden-village")){
////				if(propStatus == ALLOW_BLANK) propStatus = "Last Home";
////				else if(propStatus != ALLOW_BLANK) propStatus += ", Last Home";
////			}
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-jacksonville-nc/homeplace-at-holly-ridge")) {
//				add[1]="Holly Ridge";
//				add[2]="NC";
//				latLng=U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latLng);
//				geoCode="TRUE";
//			}
//			
//			
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-pinehurst-nc/winder-station")) {
//				add[1]="Vass";
//				add[2]="NC";
//				latLng=U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latLng);
//				geoCode="TRUE";
//			}
//				
//			propStatus = propStatus.replace("Closeout Community", "Closeout").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-charlotte-nc/creek-park"))propStatus="Only 4 Opportunities Left, Closeout";	
////			if(comUrl.contains("https://www.hhhomes.com/new-homes-charlotte-nc/baileys-run"))propStatus="Phase 2 Closed Out, Coming Soon";	
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-brunswick-county-nc/villas-at-seaside")||comUrl.contains("https://www.hhhomes.com/new-homes-fayetteville-nc/little-river-farm")||comUrl.contains("https://www.hhhomes.com/new-homes-brunswick-county-nc/calabash-station"))propStatus="Coming Soon";
//		
//			
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-raleigh-nc/mill-creek-at-wilsons-mills"))propStatus="New Phase Selling Now";	
//			if(comUrl.contains("new-homes-charlotte-nc/baileys-run"))minPrice=ALLOW_BLANK;	
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-jacksonville-nc/mimosa-bay"))propStatus="New Phase Coming Soon";	
//			if(comUrl.contains("https://www.hhhomes.com/new-homes-greensboro-nc/josephs-creek"))propStatus="Phase 1 Sold Out, New Phase Coming Soon";	
//			if(comUrl.contains("new-homes-jacksonville-nc/the-farm-at-hunters-creek"))propStatus=propStatus+", Only 2 Opportunities Left";
//			if(comUrl.contains("new-homes-fayetteville-nc/williams-farms"))propStatus=propStatus+", Coming Soon";
//			
//			if(propStatus!=null)
//				propStatus = propStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
//			
//			comName = comName.replaceAll("Country Club$| Villas$", "");
//			data.addCommunity(comName, comUrl, comType);
//			data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
//			data.addLatitudeLongitude(latLng[0], latLng[1], geoCode);
//			data.addPropertyType(propType, dType);
//			data.addPropertyStatus(propStatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon").replace("Ii", "II"));
//			data.addPrice(minPrice, maxPrice);
//			data.addSquareFeet(minSqft, maxSqft);
//			data.addNotes(U.getnote(comSec.replaceAll("Opening For Sales January 2022|presale contracts|Presales!</h2>|selection for presales|Only applies to Presale Homes", "")));
//			}
//			//break;
//			j++;
////			}catch (Exception e) {}
////		}
//		}
//	}

