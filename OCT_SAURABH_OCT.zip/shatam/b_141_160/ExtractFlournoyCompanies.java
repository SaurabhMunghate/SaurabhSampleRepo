/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_141_160;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFlournoyCompanies extends AbstractScrapper{
	WebDriver driver = null;
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	static HashMap<String,String> monthValueMap; 
	HashSet< String> multiComName = new HashSet<String>();
	public ExtractFlournoyCompanies() throws Exception {
		super("Flournoy Companies","https://www.flournoycompanies.com/");
		monthValueMap = new HashMap<String,String>();
		createMonthValMap();
		LOGGER=new CommunityLogger("Flournoy Companies");
	}

	private void createMonthValMap() {
		// TODO Auto-generated method stub
		monthValueMap.put("january", "01");
		monthValueMap.put("february", "02");
		monthValueMap.put("march", "03");
		monthValueMap.put("april", "04");
		monthValueMap.put("may", "05");
		monthValueMap.put("june", "06");
		monthValueMap.put("july", "07");
		monthValueMap.put("august", "08");
		monthValueMap.put("september", "09");
		monthValueMap.put("october", "10");
		monthValueMap.put("november", "11");
		monthValueMap.put("december", "12");		
	}

	/**
	 * @param args
	 * @throws Exception 
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws Exception {


		AbstractScrapper a = new ExtractFlournoyCompanies();
		//U.logDebug(true);
		int j = 0;
		a.process();
		
		FileUtil.writeAllText(U.getCachePath()+"Flournoy Companies.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}
 
	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		//driver = new FirefoxDriver(U.getFirefoxCapabilities());
		driver = new FirefoxDriver();
		String multifamilyValue = ALLOW_BLANK;
		String multiRegHtml = U.getHTML("https://flournoycompanies.com/multifamily-development/md-projects/") 
								+ U.getHTML("https://www.flournoycompanies.com/ConCompletedMultifamily.asp");
		multiRegHtml = multiRegHtml.replace("class=\"GreenText\" font-size:=\"\" style=\"color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, \" trebuchet=\"\">", "<div class=\"GreenText\">");
		String[] multiComLists = U.getValues(multiRegHtml, "<div class=\"elementor-post__card\">", "View Project"); 
		U.log("Total Multifamily Community:::::::::"+multiComLists.length);
		
		for(String multiComList : multiComLists){
//			U.log("multiComList : "+multiComList);
			String name=U.getSectionValue(multiComList, "<a href=\"", "</h3>");
			String cName=U.getNoHtml(U.getSectionValue(name, "\">", "</a>"));
//			U.log(">>>"+cName);
			multiComName.add(cName.trim());
		}
		
		
		//----------Modified -Feb2017-------------------
		String mainHtml =U.getHtml("https://flournoycompanies.com/about/all-projects/",driver);
		String[] comSections=U.getValues(mainHtml, "<article class=\"elementor-post", "</article>"); 
		U.log("Total Community:::::::::"+comSections.length);
		for(String comSec : comSections){
//			U.log("comSec========"+comSec);
			String cUrl=U.getSectionValue(comSec, "href=\"", "\"");
			String name=U.getSectionValue(comSec, "<a href=\"", "</h3>");
			String cName=U.getNoHtml(U.getSectionValue(name, "\">", "</a>"));
			
			if(cUrl == null){
				LOGGER.AddCommunityUrl(cName+"---------No Url----------");
				continue;
			}
			String multiSec="";
			for(String muilt:multiComLists ) {
				if(muilt.contains(cName))
				{
					multiSec=multiSec+muilt;
//					U.log(">>>>>>>>>>>>>>>>>>>>>"+cName.trim());
				}
				
			}
			
			if(multiComName.contains(cName.trim()))
			{
				multifamilyValue = "Found MULTI FAMILY ";
			}
			else{
				multifamilyValue = ALLOW_BLANK;
			}
			addDetails(cUrl,cName,comSec,multifamilyValue); //multifamilyValue
			//break;
		}
		LOGGER.DisposeLogger();
		driver.quit();
//		try{
//			driver.quit();
//		}catch(Exception e){}
	}

	private void addDetails(String comUrl, String comName, String commData, String multiFamilyValue) throws Exception {
		// TODO Auto-generated method stub

		if(comUrl.equals("http://www.thedistrictasheville.com")) comUrl = "https://www.bellapartmentliving.com/nc/asheville/the-district0/";
		
		if(comUrl.equals("http://www.flournoycompanies.com")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::Builder url:::::::::::"+comName);
			return; //builder url
		}
		if(comUrl.equals("http://www.parkwayplacecols.com")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::REdirecting to support:::::::::::"+comName);
			return; //builder url
		}
		

		//TODO : For Single Community Execution
//	if(!comUrl.contains("https://flournoycompanies.com/fdg-projects/aventine-northshore/"))return;  
		
		U.log("Count:::::::::::: "+j+"\n"+"commUrl-->"+comUrl);
		U.log("multiFamilyValue : : "+multiFamilyValue);
		if (comUrl.contains("steeplecrest") || comUrl.contains("http://www.westonranchapts.com")||comUrl.contains("http://www.oglethorpeplace.com")||comUrl.contains("http://www.thehavensa.com")||comUrl.contains("http://www.summerlakeapts.com")||comUrl.contains("http://www.kingstonvillasapts.com")||comUrl.contains("http://www.benningtechpark.com")||comUrl.contains("http://www.vueatbelleair.com")||comUrl.contains("http://www.35folly.com")||comUrl.contains("http://www.amberleighshores.com")||comUrl.contains("http://www.addisonparkmontgomery.com")||comUrl.contains("http://www.parkwayplacecols.com")||comUrl.contains("http://www.battleparkhomesga.com")||comUrl.contains("http://www.solaluxapts.com")||comUrl.contains("http://www.rockislandridges.com")|| comUrl.contains("http://www.districtwestapts.com")) {
			comUrl=comUrl.replace("http:", "https:");
		}	
		if(comUrl.contains("http://www.aventinenorthshore.com")||comUrl.contains("http://www.eastsidestationapts.com")||comUrl.contains("http://www.AventineAsheville.com")||comUrl.contains("http://www.thedistrictasheville.com")||comUrl.contains("http://www.districtwestapts.com")||comUrl.contains("http://www.districtsouthnc.com")){
			comUrl=comUrl.replace("http://www.", "https://");
			//comUrl = "https://districtsouthnc.com/";
		}
//		if(comUrl.contains("https://www.eastsidestationapts.com"))comUrl="https://eastsidestationapts.com/";
		
		
		String html=U.getHTML(comUrl);
		U.log(U.getCache(comUrl));
		
		if(html==null)
		{
			LOGGER.AddCommunityUrl("url grt null data"+comUrl);
			return;
		}
		
		//============================================Community name=======================================================================
		String communityName=comName;
		
		U.log("community Name---->"+communityName);
		
//===============Nav Bar Url===================
		String Location=ALLOW_BLANK;String about=ALLOW_BLANK;
		String floorHtml="",amenities="",apatHtml="",contactUs="";
		

		html=U.removeComments(html);
		//U.log("amenities::"+html);
		String navSectio=U.getSectionValue(html, "<nav", "/nav");
		
		if(navSectio==null && html.contains("navArea")){
			navSectio=U.getSectionValue(html, "<div class=\"navArea\">", "Apply</div></a>");
		}
		if(navSectio==null){
			navSectio=U.getSectionValue(html, "id=\"menuElem\">", "</ul>");
		}
		if(navSectio==null){
			navSectio=U.getSectionValue(html, "<ul class=\"nav\">", "</ul>");
		}
	//	U.log("navSectio::"+navSectio);
		if(navSectio!=null){
			String[] tabUrls=U.getValues(navSectio, "href=\"", "\"");
			for(String tabUrl:tabUrls){
//				U.log("tab::::"+tabUrl);
				if(!tabUrl.contains("http")){
					
					tabUrl=comUrl+"/"+tabUrl;
					tabUrl = tabUrl.replace("//Floor", "/Floor");
				}
				
				if(tabUrl.contains("mapsanddirections")){
					Location=U.getHTML(comUrl+"/mapsanddirections.aspx");
				}
				
				if(tabUrl.contains("floorplans")|| tabUrl.contains("floor.asp") || tabUrl.contains("Floor-Plans.aspx") || tabUrl.contains("floor-plans") || tabUrl.contains("Floor-plans")){
					U.log(tabUrl);
					floorHtml=U.getHTML(tabUrl);
					
					if(floorHtml == null) floorHtml = U.getRedirectedURL(comUrl, tabUrl);
						
				}
				if(tabUrl.contains("amenities")||tabUrl.contains("Amenities")){
					
					U.log(tabUrl);
					amenities=U.getHTML(tabUrl);
				}
				if(tabUrl.contains("contact")){
					U.log(tabUrl);
					contactUs=U.getHTML(tabUrl);
				}
				if(tabUrl.contains("apartments")){
					U.log(tabUrl);
					apatHtml=U.getHTML(tabUrl);
				}
			}
		}
		
		if(comUrl.contains("kingstonvillasapts.com")) {
			amenities = U.getHTML("https://www.kingstonvillasapts.com/amenities.aspx")  ;
		}
		
		if(navSectio==null){
			if (comUrl.contains("steeplecrest.com")) {
				floorHtml=U.getHTML("https://www.steeplecrest.com/apartments/index.asp");
			}else {
				floorHtml=U.getHTML("https://www.steeplecrest.com/Floor-plans.aspx");
			}
			
			if (comUrl.contains("steeplecrest.com")) {
				amenities=U.getHTML("https://www.steeplecrest.com/apartments/amenities_main.asp");
			}else
			 amenities=U.getHTML(comUrl+"/amenities");
			 if(amenities == null )
				 amenities=U.getHTML(comUrl+"/Amenities.aspx");

			 apatHtml=U.getHTML(comUrl+"/apartments");
		}
		if(comUrl.contains("eastsidestationapts.com"))	{
			about=U.getHTML("https://eastsidestationapts.com/about");
			floorHtml=U.getHTMLwithProxy("https://eastsidestationapts.com"+"/floor-plans");
			}
		if(comUrl.contains("https://www.rockislandridges.com"))	
			floorHtml=U.getHTML("https://www.rockislandridges.com/Floor-plans.aspx");
		
		//================================================Address section===================================================================
		
		
		
//		U.log("commData:::::::::"+commData);
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="False";
		String note=ALLOW_BLANK;

		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		if(comUrl.contains("https://flournoycompanies.com/fdg-projects/skyline-trinity/")) {
			add[0]="1502 Marilla St";
			add[1]="Dallas";
			add[2]="TX";
			add[3]="75201";
			geo="TRUE";
			latlag=U.getlatlongGoogleApi(add);
		}
		if(comUrl.contains("https://flournoycompanies.com/fdg-projects/skyline-trinity-2/")) {
			add[0]="1502 Marilla St";
			add[1]="Dallas";
			add[2]="TX";
			add[3]="75201";
			geo="TRUE";
			latlag=U.getlatlongGoogleApi(add);
		}
//--------------------------------------------------latlng----------------------------------------------------------------
		
		U.log("latlng--->"+latlag[0]+"  "+latlag[1]);
		
	
		html = html.replaceAll("Location</span>\n\\s*</span>\n\\s*</td>", "Location</span>");
		
//		String addSec = U.getNoHtml(U.getSectionValue(html, "Location</span>", "</td>"));
		
//		String addSec=U.getSectionValue(html, "uael-table-col elementor-repeater-item-9a9719c", "/span>");
		
		String addSec=U.getSectionValue(html, "Location</span>", "</tr>");
		
//		U.log(">>>>>>>>>"+addSec);
	String addSec1=U.getSectionValue(addSec, "text-inner\">", "<");
	
	String ad[]=addSec1.split(",");
	
	add[1]=ad[0].trim();
	add[2]=ad[1].trim();

	if(add[0]==ALLOW_BLANK||add[0]==null && latlag[0]==null  ) {
		
		latlag=U.getlatlongGoogleApi(add);
		add=U.getAddressGoogleApi(latlag);
		geo="TRUE";
	}
		
		if(add[0].length() > 4 && add[3].length() > 4){
			if(latlag[0].length() < 4){
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null)
					latlag = U.getlatlongGoogleApi(add);
				geo = "True";
			}
		}
		
		if(comUrl.contains("https://flournoycompanies.com/fdg-projects/sola/"))add[0]="E Union St";
		if(comUrl.contains("https://flournoycompanies.com/fdg-projects/sola-2/"))add[0]="E Union St";
//============================================Price and SQ.FT======================================================================
		
		 
		
		 String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0&#8217;s","0,000");
		String prices[] = U.getPrices(html+floorHtml+addSec,"\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);

		
//======================================================Sq.ft===========================================================================================		
		if (floorHtml!=null) {
			floorHtml=floorHtml.replaceAll("sq.ft <br /> <strong id=\"fp_\\d+_sqft\">", "sq.ft ").replaceAll("SQFT: <span id=\"fp_\\d+_sqft\">", "SQFT: ").replaceAll("<td data-selenium-id =\"Sqft_\\d\">", "").replace("<td align=\"center\" class=\"row1\" width=\"100\">", "<td align=\"center\" class=\"row1\" width=\"sqft\">");
		}
		
		html = html.replaceAll("Average Unit SF</span>\n\\s*</span>\n\\s*</td>", "Average Unit SF");
		
		String averageUnitSF = U.getSectionValue(html, "Average Unit SF", "</tr>");
//		U.log("====="+averageUnitSF);
		String[] sqft = U
				.getSqareFeet(
						(averageUnitSF),
						"inner\">\\d{4}</span>|inner\">\\d{3}</span>|<span class=\"uael-table__text-inner\">\\d+</span>|<span class=\"uael-table__text-inner\">\\d+ / \\d+</span>",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//		U.log("MMMMMMMMMMMMMMM "+Util.matchAll(html+floorHtml+apatHtml, "[\\s\\w\\W]{30}751</strong></li>[\\s\\w\\W]{30}", 0));
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		if(comUrl.contains("https://solaluxapts.com")){
			amenities=U.getHTML("https://www.solaluxapts.com/Amenities.aspx");
		}
		
		if(comUrl.contains("https://www.5oaksatwestchase.com/")){
			amenities=U.getHTML("https://www.5oaksatwestchase.com/amenities.aspx");
		}
		
		if(comUrl.contains("https://www.summerlakeapts.com")){
			
			amenities=U.getHTML("https://www.summerlakeapts.com/Features.aspx");
		}
		
		if(amenities!=null)amenities=amenities.replace("close out container", "");
		
		html=html.replaceAll("participation|close out containe|5-story mixed-use building", "");
		html=html.replace("luxury urban community", "luxury home urban community");
		
//================================================community type========================================================
//		U.log(about);
		String communityType=U.getCommType(html+amenities+about);
		
//==========================================================Property Type================================================
		
		html = html.replace("sense of coastal ease", "sense of Coastal living ease")
				.replace("custom interior finishes", "custom homes interior finishes");
		String proptype=U.getPropType((html+amenities+multiFamilyValue).replaceAll("Memory Care apartments|residences and common areas are loaded with amenities", ""));
		
		
//==================================================D-Property Type======================================================
		if(floorHtml!=null)
		floorHtml=floorHtml.replace("4th Floor"," 4 Story ");
		String dtype=U.getdCommType((html+amenities+floorHtml+apatHtml).replaceAll("\".*\"|The Rapids is a 5-story mixed-use building", ""));
		
//==============================================Property Status=========================================================
		if(amenities!=null)
			amenities=amenities.replaceAll("unlimited opportunities|\"ppcontent\"><p>Coming|NOW OPEN!! Call us today","");
		
		html = html.replaceAll("\"ppcontent\"><p>Coming|NOW OPEN!! Call us today", "");
		String pstatus=U.getPropStatus(html+amenities);
		
//============================================note====================================================================
		
	
		
		communityName = communityName.replaceAll(" Villas$", "");
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+":::::::::::::::::::>repeat");
			k++;
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		if(commData.contains("<div class=\"elementor-post__badge\">Sold</div>"))
			if(pstatus==ALLOW_BLANK)
				pstatus = "Sold Out";
			else
				pstatus += ", Sold Out";
		
			note = U.getnote(html);
//			U.log(">>>>>>>"+note);
//			U.log(">>>>>>>"+note.length());
			
			if(note.length()>1)
			{
				note=note+", Address and LatLng Taken From City and State";
			}
			else
				note="Address and LatLng Taken From City and State";
			
			
			String completionDate = U.getSectionValue(html, "Completion Date</span>", "</tr><tr data-entry=\"3\"");
			completionDate = Util.match(U.getSectionValue(completionDate,"<td class=\"uael-table-col","</td>"), "__text-inner\">(.*)</span>",1);
			completionDate = completionDate.replaceAll("Summer|Spring|Winter", "");
			if(completionDate.trim().length()>4) {
				String year = Util.match(completionDate, "\\d{4}");
				String month = monthValueMap.get(completionDate.replace(year, "").trim().toLowerCase());
				U.log(year+":"+month);
				completionDate = year+"/"+month+"/01";
			}
			else {
				completionDate = completionDate+"/01/01";
			}
			U.log("completionDate: "+completionDate);
			
			String noOfUnits = U.getSectionValue(html, "Number of Units</span>", "</tr><tr data-entry=");
			noOfUnits = Util.match(U.getSectionValue(noOfUnits,"<td class=\"uael-table-col","</td>"), "__text-inner\">(.*)</span>",1);
			if(noOfUnits.contains("/")) {
				noOfUnits = (Integer.parseInt(Util.match(noOfUnits.split("/")[0], "\\d+"))+Integer.parseInt(Util.match(noOfUnits.split("/")[1], "\\d+")))+"";
			}
			U.log(noOfUnits);
			communityName = communityName.replace("The Aventine Asheville", "The Aventine").replace("Aventine West Melbourne", "Aventine");
			data.addCommunity(U.getCapitalise(communityName.toLowerCase()),comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("@", ""), add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(noOfUnits);
			data.addConstructionInformation(ALLOW_BLANK, completionDate.trim());
		j++; 
	}

}