package com.shatam.b_141_160;

import java.io.*;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class Extract_050_FultonHomes extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	String baseUrl = "https://www.fultonhomes.com/";
	WebDriver driver = null;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new Extract_050_FultonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Fulton Homes.csv", a.data().printAll());
	}

	public Extract_050_FultonHomes() throws Exception {

		super("Fulton Homes", "https://www.fultonhomes.com");
		LOGGER = new CommunityLogger("Fulton Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
//		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		driver = new FirefoxDriver();
		String html = U.getHtml("https://www.fultonhomes.com/our-communities",driver);
		String[] html1 = U.getValues(html, "<div class=\"community-panel\">", "</div></div></div>");
		// U.log("==="+html+"========\n");

			for(String mainCommSec : html1 ) {
			String[] mainSec = U.getValues(mainCommSec, "<li><a", "</li>");

			for (String comSec : mainSec) {

				String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
				 
				U.log(comUrl + "::::::::::::::::::::::" + comSec);

//				try {
					addCommunityDetails(comUrl, comSec);
//				} catch (Exception e) {}

			}
			
		}

		// U.log(comSecs.length);
		// for (String comSec : comSecs) {
		//
		//
		// {
		// String Secs [] = U.getValues(comSec, "<li><a href=", "</li>");
		// for(String Sec:Secs)
		// {
		// addCommunityDetails(Sec,comSec);
		// //U.log(Sec);
		// //break;
		// }
		//
		// i++;
		// inr++;
		// }
		// }
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addCommunityDetails(String comUrl, String comSec) throws Exception {

		 //try{
//TODO::
//		 if(j==10)
		{

			// String comUrl =U.getSectionValue(comSec, "\"", "\">");
			//
			//
			// comUrl = baseUrl + comUrl;

			// =============================================================================
			comUrl = baseUrl+comUrl;
//		if(!comUrl.contains("https://www.fultonhomes.com/our-communities/estrella-commons/north-shore")) return;
		
			
			U.log("\n Count:"+ j);
			U.log("community link:" + comUrl);
			
			String communityPageHtml = U.getHTML(comUrl);
			
			String communityName = U.getSectionValue(communityPageHtml, "<span>Welcome to", "<");
			communityName = U.getNoHtml(communityName);
			
			
			U.log("community name:" + communityName);

			
			// ----------- Quick Move In Home Section------------

			String quickHomeHtml = null;

			String quickHomeSection = U.getSectionValue(communityPageHtml,
					"<ul class=\"thumbs-panel hidden-xs hidden-sm\">", "</ul>");
			// U.log(availableHomeSection);
			String[] quickHomeUrls = U.getValues(quickHomeSection, "<p class=\"title\"><a href=\"", "\"");
			U.log("Total quick Homes :: " + quickHomeUrls.length);
			int x = 0;
			for (String quickHomeUrl : quickHomeUrls) {
				quickHomeHtml = quickHomeHtml + getCombineHtml(baseUrl + quickHomeUrl);
				U.log("quickHomeUrl  :: " + quickHomeUrl);
				if (x == 10)
					break;
				x++;
			}

			if (quickHomeHtml == null)
				quickHomeHtml = ALLOW_BLANK;
			// =============== Available Plan =============
			String availableHomeHtml = null;
			// if(alllinkquickurl == null){
			String availableHomeSection = U.getSectionValue(communityPageHtml,
					"<ul class=\"thumbs-panel hidden-sm hidden-xs\">", "</ul>");
			// U.log(availableHomeSection);
			String[] availableHomeUrls = U.getValues(availableHomeSection, "<p class=\"title\"><a href=\"", "\"");
			U.log("Total avail Homes :: " + availableHomeUrls.length);
			int y = 0;
			for (String availableHomeUrl : availableHomeUrls) {
				availableHomeHtml = availableHomeHtml + getCombineHtml(baseUrl + availableHomeUrl);
				U.log("availableHomeUrl  :: " + availableHomeUrl);
				if (y == 10)
					break;
				y++;
			}

			String comDescription = U.getSectionValue(communityPageHtml, "<li id=\"neighborhood_floorplan_tab",
					"<div id=\"other-communities\"");
			if (comDescription == null)
				comDescription = U.getSectionValue(communityPageHtml, "hidden-sm overview-original hidden-print\">",
						"</ul>");

			// ------- Price -------------------------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			// U.log(comSec);
			String comSecPrice = U.getSectionValue(comSec, communityName, "</li>");
			// U.log(comSecPrice);

			if (comDescription != null)
				comDescription = comDescription.replace("'s", ",000");
			String[] price = { ALLOW_BLANK, ALLOW_BLANK };
			comSec = comSec.replaceAll("0's|0K", "0,000");
			comSec = comSec.replace("0's", "0,000");
			comSec = comSec.replace("the $1.34M's", "the $1,340,000");
			if (quickHomeHtml != null)
				quickHomeHtml = quickHomeHtml.replaceAll("<em>Starting at \\$271", "");
			// if (comDescription != null)
			price = U.getPrices(comDescription + quickHomeHtml + comSec + comSecPrice,
					">Price:</span> <b>\\$\\d{3},\\d{3}|>Starting at \\$\\d{3},\\d{3}|>Starting at: \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}", 0);
			
//			U.log("mmmmmm"+Util.matchAll(comDescription + quickHomeHtml + comSec + comSecPrice, "[\\w\\s\\W]{30}370[\\w\\s\\W]{30}", 0));
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// -------------- Square feet-----------------------------
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			// 1,763 - 3,769 Sq. Ft.
			String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
			// U.log(secio);
			// if (comDescription != null)
			sqft = U.getSqareFeet(comDescription + comSec + quickHomeHtml + comSec,
					"\\d{4} to nearly \\d{4} square feet|\\d{4} to \\d{4} square fee|\\d{4} to over \\d{4} square feet| \\d{1},\\d{3} Sq.|\\d,\\d+ - \\d,\\d+ Sq.| \\d{4} square fee|\\d{1},\\d+ Sq. Ft.|data\">\\d{1},\\d+ Sq Ft",
					0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			// ------------------- Address ---------------------------------

			String Geo = "FALSE";
			String adSec = U.getSectionValue(communityPageHtml, "<h4>Office Location</h4>", "<br /><a");
			U.log(adSec);

			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			if (adSec != null) {
				adSec = U.formatAddress(adSec);
				add = U.getAddress(adSec);
			}
			U.log("Address :: " + Arrays.toString(add));

			// ------------------ LatLng-----------------------
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			String latsec = U.getSectionValue(communityPageHtml, ".com/maps", "target");
			U.log("latsec : " + latsec);
			if (latsec != null)
				latsec = Util.match(latsec, "\\d{2}.\\d+,-\\d{3}.\\d+");

			if (latsec != null) {
				latLong = latsec.split(",");
				lat = (latLong[0] != null) ? latLong[0] : ALLOW_BLANK;
				lng = (latLong[1] != null) ? latLong[1] : ALLOW_BLANK;
			}
			U.log(latLong[0]);

			if (add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
				latLong = U.getlatlongGoogleApi(add);
				lat = (latLong[0] != null) ? latLong[0] : ALLOW_BLANK;
				lng = (latLong[1] != null) ? latLong[1] : ALLOW_BLANK;
				Geo = "TRUE";

			}
			if (add[0] == ALLOW_BLANK && lat != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latLong);
				Geo = "True";
			}

			add[0] = add[0].replace(",", "").replace(" .", ".");

			communityPageHtml = communityPageHtml
					.replaceAll("traditional single-family |tradtional single-family ", "traditional homes single-family ")
					.replace(" lofts and family rooms", " Loft homes and family rooms");
			communityPageHtml = communityPageHtml.replace("title=\"Fulton Ranch\">Fulton Ranch", "")
					.replace("title=\"Morrison Ranch\">Morrison Ranch", "");
			communityPageHtml = communityPageHtml.replaceAll(
					"href=\"our-communities/morrison-ranch|<a href=\"\" title=\"Fulton Ranch|<a href=\"\" title=\"Fulton Ranch|our-communities/fulton-ranch|PMI and HOA fees|PMI and HOA fees|Village|village| include the Rancho Mirage",
					"");
			communityPageHtml = communityPageHtml.replaceAll(
					"\"Rancho Mirage\"|rancho-mirage|in Rancho Mirage |rancho-mirage\"|Rancho Mirage</a>|>Rancho Mirage<br|Creek Station - Rancho Mirage",
					"");

			// ----------------- Property Type------------------

			// }
			String propTypeHtml = communityPageHtml + availableHomeHtml + quickHomeHtml;
			propTypeHtml = propTypeHtml//.replace("Custom Homesites!", "custom luxury homes")
					.replace("flex space which can be used for living", "FLEX Homes").replace("Enjoy the luxury and feel", "Enjoy the luxury home and feel").replace("increased size and luxury", "increased size and luxury homes")
					.replaceAll("\\d+ bedrooms|PMI and HOA fees", "").replace("/ Loft Plans", "with Loft ")
					.replace("providing that luxurious touch", "providing that luxurious living touch");
//			 U.log(">>>>>>>>>>>>>>>>>>"+Util.matchAll(propTypeHtml, "[\\s\\w\\W]{30}loft[\\s\\w\\W]{30}", 0));
//s			U.writeMyText(propTypeHtml);
			String pType = U.getPropType((comSec + propTypeHtml.replaceAll("etn2sTjcONdoTxpBLq|v5dcoNDO3r", "").replace("flex space which can be used", "Flex Room which can be used")));
//			U.log("mmmmmm"+Util.matchAll(propTypeHtml, "[\\w\\s\\W]{30}flex space which can be used[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(comSec , "[\\w\\s\\W]{30}flex space which can be used[\\w\\s\\W]{30}", 0));
			U.log("pType==="+pType);
			// ------------------- Derive Property type----------------
			communityPageHtml = communityPageHtml.replaceAll("Fulton Ranch", "").replace("One and two story",
					" 1 Story  2 Story ");

			String DPType = U.getdCommType(communityName + (communityPageHtml + availableHomeHtml + quickHomeHtml)
					.replaceAll("Morrison Ranch|morrison-ranch|story \\d bedrooms", ""));
			U.log("Dtpe=====" + DPType);

			// U.log("lat :" + lat + " longi :" + lng);
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("repeated*************" + comUrl);
				return;
			}
			if (add[1] == ALLOW_BLANK && add[2] == ALLOW_BLANK)
				Geo = ALLOW_BLANK;

			// Last community hard code values

			// get PRICES

			// ------------------ Community Type -----------------------
			communityPageHtml =communityPageHtml; //.replace("anchored by a massive lake-side park", "anchored by a massive lakeside community")
			String Type = U.getCommunityType((communityPageHtml).replaceAll(
					"header-master-plan|content/masterplan/|Ironwood masterplan|c_masterplan.jpg|Crossing Masterplan\"",
					""));
			 U.log("Ctype::"+Type);
//			 U.log(Util.matchAll(communityPageHtml , "[\\w\\s\\W]{30}lake[\\w\\s\\W]{80}",0));
			// ---------------- Property Status ------------------------
			String status = ALLOW_BLANK;
			String remove = "homesites have sold out|we will be temporarily selling out|delivery homes are still|oversize lots available|<p class=\"subtitle\">Coming Soon</p>|</li><li>Sold Out</li><li>|grand opening pricing|Grand Opening Promotions|Quick move-in homes|quick-move-in|UNTIL COMMUNITY CLOSEOUT|Legacy</a></li><li>Coming Soon|Closeout of |</a></li><li>Coming Soon|subtitle\">Sold";

			if(comDescription!= null)
			comDescription = comDescription.toLowerCase().replaceAll(remove.toLowerCase(), "")
			.replace("new phase of this extremely popular community is coming soon", "new phase coming soon");

			status = U.getPropStatus((comDescription+comSec).replaceAll("- Sold Out|subtitle\">Coming Soon</p>|plans listed as “coming", ""));
			
			status = status.replaceAll("^,", "");
			
//			if(comUrl.contains("morrison-ranch/lakeview-trails")) {
//				status = status.replace("Sold Out", "Final Phase Sold Out");
//			}
//			if(comUrl.contains("estrella-commons/north-shore")) {
//				status = status.replace("Final Closeout", "Final Closeout, Sold Out");
//			}
			U.log("status: "+status);
//			U.log(Util.matchAll(comDescription+comSec, "[\\w\\s\\W]{30}sold out[\\w\\s\\W]{80}",0));

			
			
			
			String note = "";
			note = U.getnote(communityPageHtml);
			// U.log("==="+comSec);
//			 U.log(Util.matchAll(comDescription+comSec, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{80}",0));

/*			if (comUrl.contains("morrison-ranch/lakeview-trails"))
				communityName = "Lakeview Trails at Morrison Ranch";
*/
//			if(status.contains("Final Phase, Sold Out")) 
//				status = "Final Phase Sold Out";
			
			if (comUrl.contains("/sirona/seaboard"))
				communityName = "Seaboard at Sirona";
			
			
	//	latLong=U.getlatlongGoogleApi(add);
			
//			if(comUrl.contains("https://www.fultonhomes.com/our-communities/barney-farms/meadows"))pType+=", Coastal Style Homes";
//			if(comUrl.contains("https://www.fultonhomes.com/our-communities/promenade/calistoga"))pType+=", Loft";

//			if(comUrl.contains("https://www.fultonhomes.com/our-communities/morrison-ranch/lakeview-trails"))minPrice="$531,900";
//			if(comUrl.contains("https://www.fultonhomes.com/our-communities/escalante/silverado"))minPrice="$375,900";
			

			U.log("communityName====" + communityName);
			String mapId = U.getSectionValue(communityPageHtml, "<a href=\"https://lotmaps.fultonhomes.com/map.html?id=", "&");
			U.log(mapId);
			String lotJsFileHtml = U.getHTML("https://lotmaps.fultonhomes.com/mapScripts/"+mapId+".js");
//			U.log(lotJsFileHtml);
			int lotCount = Util.matchAll(lotJsFileHtml, "lotId:\\s*\\d{2,3}", 0).size();
			//			communityName = communityName.replace("at Morrison Ranch", "");
			LOGGER.AddCommunityUrl(comUrl);

			data.addCommunity(communityName, comUrl, Type);
			data.addAddress(add[0], add[1], add[2], add[3]);

			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);

			data.addLatitudeLongitude(lat.trim(), lng.trim(), Geo);
			data.addPropertyType(pType, DPType);

			// ----- Property Status
			data.addPropertyStatus(status);
			data.addNotes(note);
			
			data.addUnitCount(lotCount+"");
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;

		 //}catch (Exception e) { }
	}

	private String getCombineHtml(String url) {
		String combinedHtml = null;
		try {
			combinedHtml = U.getHTML(url);
		} catch (IOException e) {
		}
		return combinedHtml;
	}
}