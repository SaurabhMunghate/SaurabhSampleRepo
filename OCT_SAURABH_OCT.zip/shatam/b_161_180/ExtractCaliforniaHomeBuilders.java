/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_161_180;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCaliforniaHomeBuilders extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractCaliforniaHomeBuilders()throws Exception {
		super("California Home Builders","https://www.calhomebuilders.com/");
		LOGGER=new CommunityLogger("California Home Builders");
	}


	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCaliforniaHomeBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"California Home Builders.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}
	//WebDriver driver=new FirefoxDriver();
	@Override
	protected void innerProcess() throws Exception {


		String html = U.getHTML("https://www.calhomebuilders.com/new-homes-for-sale");
		String section = U.getSectionValue(html, "<ul class=\"sf-result\">", "<div class=\"fusion-clearfix\">");
		String[] comSections = U.getValues(section, "<a href=\"", "</tbody>");
		for(String commSec : comSections){
			String commUrl = U.getSectionValue(commSec, "<a href=\"", "\"");
			addDetails(commUrl,commSec,html);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String cityData, String basehtml) throws Exception {
		// TODO Auto-generated method stub
		
		comUrl=comUrl.replace("https://www.calhomebuilders.com/ventanas", "https://www.calhomebuilders.com/ventanan");
		
//		if(!comUrl.contains("https://www.calhomebuilders.com/topanga-cyn"))return;

		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"::::::::::::::::::repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log("commUrl-->"+comUrl);
		String html=U.getHTML(comUrl);
		
		String learnMoveSec = U.getSectionValue(html, "<a class=\"fusion-button", "Learn More");
		String learnUrl =ALLOW_BLANK;
		String html1  = ALLOW_BLANK;
		if(learnMoveSec != null) {
			learnUrl = U.getSectionValue(learnMoveSec, "href=\"", "\""); 
		U.log("--->>>>"+learnUrl);
		html1 = U.getHTML(learnUrl);
		//html = html + html1;
		}
		
		
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(html, "property=\"og:title\" content=\"","\"");
		
		U.log("community Name---->"+communityName);
		
		
		String[] qSec = U.getValues(html1, "<h3 style=\"margin:", "</picture>");
		
		String mainhtml = "";
		String qData  = ALLOW_BLANK;
		for(String data : qSec) {
			
			if(data.toLowerCase().contains(communityName.toLowerCase()) || data.contains(communityName)) {U.log("===========");
		//	mainhtml = U.getHTML(U.getSectionValue(data, "<a href=\"", "\"").replaceAll("\n|\\s*", ""));
			String flr=U.getSectionValue(data,"<a href=\"", "\"");
			if(flr!=null)
     		mainhtml=U.getHTML(flr);
			U.log(mainhtml.contains("/floorplans\" "));
			qData = data;
			html+=data;
			break;
			}
		}
		
		//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		String addSec=U.getSectionValue(html,"https://www.google.com/maps/","data=");
		if(addSec!=null)
		{
			U.log("addSec:::"+addSec);
			addSec=addSec.replace("&#039;&#039;","/");
			String aSec=U.getSectionValue(addSec, "//","/@");
			if(aSec==null){
				aSec=U.getSectionValue(addSec, "place/", "/@");
			}
			U.log("aSec:::"+aSec);
			aSec=aSec.replace("+"," ");
			
			String check=com.shatam.utils.Util.match(aSec, "[A-Z]{2}\\s+\\d{4,}");
			if(check!=null)
			add=U.findAddress(aSec);
			U.log(add[0]);
			
			
		}
		else{
			cityData= cityData.replaceAll("</td>\\s*</tr>\\s*<tr>\\s*<td style=\"vertical-align: middle;\">", "addsec");
			addSec = U.getSectionValue(cityData, "addsec", "</td>");
			U.log(addSec);
			add=U.findAddress(addSec);
		}
		if (add!=null) {
			if(add[1]==ALLOW_BLANK && html.contains("{\"address\":\""))
			{
				String sec=U.getSectionValue(html, "{\"address\":\"","\"");
				U.log("sec::"+sec);
				add=U.findAddress(sec);
			}
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		}
		
		
		
		
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
		
		if(addSec!=null)
		{
			String lat=U.getSectionValue(addSec, "@",",");
			String lng=com.shatam.utils.Util.match(addSec, "-\\d{2,3}.\\d+");
			latlag[0]=lat;
			latlag[1]=lng;
			
		}
		if((latlag[0]==null || latlag[0]==ALLOW_BLANK) && mainhtml.length()>31) {
			
			addSec=U.getSectionValue(mainhtml,"https://www.google.com/maps/","\"");
			String lat=U.getSectionValue(addSec, "@",",");
			String lng=com.shatam.utils.Util.match(addSec, "-\\d{2,3}.\\d+");
			latlag[0]=lat;
			latlag[1]=lng;
			
		}
		if (comUrl.contains("https://www.calhomebuilders.com/discovery")) {
			addSec=U.getSectionValue(html, "<h3>VISIT US:</h3><p>", "</p><div");
			add=U.getAddress(addSec.replace("</p><p>", ","));
		}
		if(latlag[0]==ALLOW_BLANK)
		{
				latlag[0]=U.getSectionValue(html, "latitude\":\"","\"");
				latlag[1]=U.getSectionValue(html, "longitude\":\"","\"");
				geo="TRUE";
		}
		if(add==null||add[1]==ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(comUrl.contains("warner-center")) {
			String mapPage = U.getHTML("https://www.theqvariel.com/mapsanddirections"); 
			add[0] = U.getSectionValue(mapPage, "address: \"", "\"");
			add[1] = U.getSectionValue(mapPage, "city: \"", "\"");
			add[2] = U.getSectionValue(mapPage, "state: \"", "\"");
			add[3] = U.getSectionValue(mapPage, "zip: \"", "\"");
			latlag[0]=U.getSectionValue(mapPage, "latitude: \"","\"");
			latlag[1]=U.getSectionValue(mapPage, "longitude: \"","\"");
		}
		if(comUrl.contains("https://www.calhomebuilders.com/topanga-cyn")) {
			String mapPage =U.getHTML("https://www.theqtopanga.com/mapsanddirections");
			add[0] = U.getSectionValue(mapPage, "address: \"", "\"");
			add[1] = U.getSectionValue(mapPage, "city: \"", "\"");
			add[2] = U.getSectionValue(mapPage, "state: \"", "\"");
			add[3] = U.getSectionValue(mapPage, "zip: \"", "\"");
			latlag[0]=U.getSectionValue(mapPage, "latitude: \"","\"");
			latlag[1]=U.getSectionValue(mapPage, "longitude: \"","\"");
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
			
		//============================================Price and SQ.FT======================================================================
		String floorHtm = ALLOW_BLANK;
		String actHtml=ALLOW_BLANK;
		String amenitiHtm = ALLOW_BLANK;
		
		if(html.contains("FLOORPLANS</a>")) {
//			U.log("hello i am here::");
			floorHtm=U.getHTML(learnUrl+"/floorplans");
		}
		if(mainhtml.contains("/floorplans\" ")) {
//			U.log("hello i am here::"+U.getSectionValue(qData, "<a href=\"", "?")+"/floorplans");
			floorHtm=U.getHTML(U.getSectionValue(qData, "<a href=\"", "?")+"/floorplans");
			
		}
		
		if(mainhtml.contains("Amenities</a>")) {
//			U.log("hello i am here::");
			amenitiHtm=U.getHTML(U.getSectionValue(qData, "<a href=\"", "?")+"/amenities");
		}
//		if(comUrl.contains("https://www.calhomebuilders.com/warner-center")) {
//			floorHtm=U.getHTML("https://www.theqvariel.com/floorplans");
//		//	actHtml=U.getHTML("https://www.theqvariel.com/?rccustomid=Mzc2MTU%3d-9q3mqWU7iwY%3d&_ga=2.208835675.855535439.1640062698-715445762.1640062698");
//		}
//		if(comUrl.contains("https://www.calhomebuilders.com/topanga-cyn")) {
//			floorHtm=U.getHTML("https://www.theqtopanga.com/floorplans");
//		//	actHtml=U.getHTML("https://www.theqtopanga.com/?rccustomid=Mzc2MTY%3d-2pWN8J5yCIc%3d&_ga=2.217749727.855535439.1640062698-715445762.1640062698");
//			
//		}
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0&#8217;s","0,000");
		String prices[] = U.getPrices(html+cityData+floorHtm,"\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
			html=html.replaceAll("&#8211; ", " - ");
				
		String[] sqft = U
				.getSqareFeet(
						html+cityData+floorHtm+mainhtml,
						"</span>\\d,\\d{3}-<span class='sr-only'>to</span>\\d,\\d{3} Sq\\.Ft\\.</div>|</span>\\d,\\d{3} Sq\\.Ft\\.</div>|</span>\\d{3} Sq\\.Ft\\.</div>|-align: bottom;\">\\d{1},\\d{3}</td><td|\\d,\\d+ to \\d,\\d+ sq. ft|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d,\\d+ - \\d,\\d+ Sq. Ft|Square Footage: \\d,\\d{3}-\\d,\\d{3}</td>|Square Footage: \\d{3,4}-\\d{3,4}| \\d{4}</td><td|Square Footage:</td><td>\\d,\\d+|\\d,\\d+ Sq. Ft|Square Footage: \\d,\\d{3}</td>|Square Footage: \\d{3,4}</td>|\\d,\\d{3} to \\d,\\d{3} Sqft|>\\d,\\d{3} Sqft|>\\d{3} Sqft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];		
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//		U.log("mmmmmm"+Util.matchAll(html+cityData+floorHtm+mainhtml, "[\\w\\s\\W]{30}409[\\w\\s\\W]{30}", 0));

				
		//================================================community type========================================================
		html = html.replaceAll("disc golf course|irrigated", "");
		amenitiHtm = U.getSectionValue(amenitiHtm, " <h2 class=\"mb-3\">Community Amenities</h2>", "<h2 class=\"mb-3\">Pet Policy</h2>");
		String communityType=U.getCommType(html+cityData+amenitiHtm);
				
		//==========================================================Property Type================================================
				
		//U.log("mmmmmm"+Util.matchAll(mainhtml, "[\\w\\s\\W]{30}luxury[\\w\\s\\W]{30}", 0));
		
		String proptype=U.getPropType((html+cityData).replaceAll("Patio Doors</li>|Traditional utility", ""));
		
		if(comUrl.contains("https://www.calhomebuilders.com/warner-center")) {
			proptype="Apartment Homes";
		}
				
		//==================================================D-Property Type======================================================
		html=html.replaceAll("Porter Ranch|Stetson Ranch Park to|Saddletree Ranch Trailhead", "");
//		U.log("MMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}two story[\\s\\w\\W]{30}", 0));
		String dtype=U.getdCommType(html);
				
		//==============================================Property Status=========================================================
		html = html.replaceAll("COMING 2021</b></div>|COMING 2024</span></p>|THE Q TOPANGA</span></h2><p><span style=\"font-size: 21px; color: #e35205\">COMING 2021|VARIEL</b></a> IS NOW OPEN FOR PRE LEASING!<br />|New Homes Available in San Fernando|many closeout goods|New Homes Just Released!</div>|Now Available!</div>", "")
				.replace("6�homes", "6 homes");

		String pstatus=U.getPropStatus(html+cityData);
		
//		U.log("MMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}now open[\\s\\w\\W]{30}", 0));
		//============================================note====================================================================
		
		//U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}now leasing[\\w\\s\\W]{30}", 0));
		String note=U.getnote(html);
				

	/*	if(comUrl.contains("https://www.calhomebuilders.com/ventanas"))geo="FALSE";
		
		if(comUrl.contains("https://www.calhomebuilders.com/cabrillo"))add[0]="12361 San Fernando Road";
	*/	
	/*
	 *	if(comUrl.contains("https://www.calhomebuilders.com/warner-center")) {proptype = proptype + ", Courtyard Home"; } //minSqft="628";maxSqft="1223";*/
		if(comUrl.contains("https://www.calhomebuilders.com/topanga-cyn")||comUrl.contains("https://www.calhomebuilders.com/warner-center")) {communityType =  "Resort-style"; }
		
		
		if(proptype.contains("Apartment Homes"))proptype=proptype.replace("Apartment Homes", "Luxury Homes, Apartment Homes");
		U.log(">>>>>>>>>"+proptype);
		if(latlag[0]==null){
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo = "True";
		}
		if(dtype.contains("1 Story"))dtype=dtype.replace("1 Story", ALLOW_BLANK);
		if(comUrl.contains("https://www.calhomebuilders.com/warner-center")||comUrl.contains("https://www.calhomebuilders.com/topanga-cyn")) dtype=ALLOW_BLANK;
//		if(comUrl.contains("https://www.calhomebuilders.com/de-soto")) pstatus = "Coming 2024";
///		if(co
		if(comUrl.contains("https://www.calhomebuilders.com/topanga-cyn")) proptype = "Luxury Homes, Apartment Homes";
		data.addCommunity(communityName.toLowerCase(),comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus.replace("Coming Fall 2021, Coming 2021", "Coming Fall 2021"));
		data.addNotes(note); 
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		j++; 
	}

}