
package com.shatam.b_161_180;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;
//import com.sun.org.apache.bcel.internal.generic.RETURN;

public class ExtractHighlandHoldings extends AbstractScrapper {
	int i = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.highlandhomes.org"; 

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractHighlandHoldings();
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"Highland Holdings.csv", a.data()
				.printAll());
	}

	public ExtractHighlandHoldings() throws Exception {

		super("Highland Holdings", "https://www.highlandhomes.org/");
		LOGGER = new CommunityLogger("Highland Holdings");
	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://www.highlandhomes.org/new-homes"); //"https://www.highlandhomes.org/all-regions");
		//U.log(html);
/*		String sec=U.getSectionValue(html, "All Regions</h1>", "<footer id=\"footer\""); 
		
		String[] list=U.getValues(sec, "<div class=\"small-12 medium-8", "Directions</a>");
		for (String item : list) {
			//U.log(item);
			// if(inr==0||inr==totalComm||inr==totalComm+1||inr==list.size()-1)
			addDetails(item);
			inr++;
			i++;
			//break;
			// }
		}*/
		
		String communityContents[] = U.getValues(html, "<div class=\"col-sm-12 commmodelinvitem\">", ">VIEW COMMUNITY</a>");
		String section = U.getSectionValue(html, "data = eval", "</script>");
		String comSections[] = U.getValues(section, "METROAREADESC", "SECONDARYTAGLINE");
		U.log(comSections.length);
		for(String comSec : comSections){
//			U.log(comSec);
			String comUrl = U.getSectionValue(comSec, "COMMLINK\":\"", "\"");
			if(!comUrl.startsWith("http")) comUrl = builderUrl +comUrl;
//			U.log("comUrl ::"+comUrl);
			extractCommunityDetails(comUrl, comSec, communityContents);
		}
		LOGGER.DisposeLogger();

	}

	private static String priceRegex[] = {
			
			"from the \\$\\d{3},\\d{3}",
			"<span class=\"large\">\\$\\d{3},\\d{3}",
			"from the \\$\\d{3},\\d{3}",
			" low \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}",
		
	};
	private static String sqftRegex[] = {
			"home offer you \\d,\\d{3} sq. ft.",
			"specitem\">\\d,\\d{3} sq ft",
			"fullspecsitem\">\\s+\\d,\\d{3}\\s?-\\s?\\d,\\d{3}",
			"offer you \\d,\\d{3}-plus sq\\. ft\\.",
			"up to \\d,\\d{3} sq\\. ft\\.|\\d,\\d{3} square feet|\\d,\\d{3}\\+ square feet ",
			"\\d{1},\\d{3}-plus square feet"
	};
	
	//TODO : Extract community details here
	public void extractCommunityDetails(String comUrl, String comSec, String regPageContents[])throws Exception{
//	if(j == 18)
	{
//	if(!comUrl.contains("https://www.highlandhomes.org/new-homes/florida/east-polk-county/davenport/astonia"))return;
//	U.log("NEW $$$$$$$$$$$");
	
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+":::::::::::::Repeat");
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"\tcomUrl : "+comUrl);
		String html = U.getHTML(comUrl);
		
		
		String regPageContent = null;
		for(String content : regPageContents){
			String _url = U.getSectionValue(content, "<a href=\"", "\"");
			if(comUrl.equalsIgnoreCase(builderUrl + _url)){
				regPageContent = content;
				break;
			}
		}
		
		//======== Community Name ===========
		String comName = U.getSectionValue(comSec, "COMMUNITY_NAME\":\"", "\"");
		comName=comName.replace("VillaMar", "Villamar");
		//=========== Address ==============
	//	U.log(comSec);
		String [] add = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		String geo = "False";
		
		add[0] = U.getSectionValue(comSec, "ADDRESS\":\"", "\"");
		add[1] = U.getSectionValue(comSec, "CITY\":\"", "\"");
		add[2] = U.getSectionValue(comSec, "STATE\":\"", "\"");
		add[3] = U.getSectionValue(comSec, "ZIP\":", ",");
		U.log("Add :"+Arrays.toString(add));
		
		if(add[0] != null)
			add[0] = add[0].replaceAll("Sold Out!|, just west of N. 10th Street|just south of CR 540A|Models Coming Soon!", "").replace(", ", " ");
		
		if(add[0] != null && add[0].isEmpty()){
			String val = U.getSectionValue(html, "View on map</div>", "<br>");
			val = val.replaceAll("<.*>", "").trim();
			add[0] = val;
		}
		
		add[0] = add[0].replace(", ", " ").replaceAll("Sold Out!|Sold Out|Models Coming Soon!| 0.5-miles west of US-27|Coming Soon!", "");
		U.log("Sreet: "+add[0]);
		add[0] = add[0].replace("FL-37/N Church Ave & Bridgeport Lakes Blvd.", "Church Ave & Bridgeport Lakes Blvd").replace("Off Davenport Blvd west of Hwy 17/92","Davenport Blvd").replace("Off Eagle Lake Loop Rd just east of US-17", "Eagle Lake Loop Rd");
		
		//========== Lat-Lng ================
		String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
		latLng[0] = U.getSectionValue(comSec, "LATITUDE\":", ",");
		latLng[1] = U.getSectionValue(comSec, "LONGITUDE\":", ",");
		U.log("LatLng :"+latLng[0]+"\t"+latLng[1]);
		
		
		if(add[0].length()<3 && latLng[0]!=null) {
			
			geo = "TRUE";
			add = U.getAddressGoogleApi(latLng);
			
		}
		
		
		//============ Price ============
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html=html.replaceAll("\"description\": \".*\"|Cloud start from the \\$30", "");
		html = html.replaceAll("0&#\\d+;s|0's|0's|0’s", "0,000");
		String[] price = U.getPrices(comSec + html + regPageContent, String.join("|", priceRegex),	0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//			U.log("MMMMM1"+Util.matchAll(comSec + html, "[\\s\\w\\W]{100}\\$300[\\s\\w\\W]{100}", 0));

		//============= Square Feet ============
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		html=html
				.replace("start in the mid $300's", "start in the mid $300,000")
				.replace("priced from the low $300's ", "priced from the low $300,000");
		String[] sqft = U.getSqareFeet( comSec + html + regPageContent, String.join("|", sqftRegex),0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//======== Community Type ============
		
		html = html.replaceAll("Lakeside Preserve\">Lakeside Preserve|\"caption\":\"Lakeside living", "")
				.replaceAll("lakefront homes", "lakefront community").replaceAll("Lakeside Preserve", "Lakeside community");
		
		String comType = U.getCommunityType((comSec + html.replace("a lakefront neighborhood of new homes for sale", "a lakefront community neighborhood of new homes for sale")));
		
		//=============== Quick Homes =============
		int quickHomeCount = 0;
		String homeHtml=ALLOW_BLANK;
		String quickHomeSec = U.getSectionValue(html, "Quick Move In Homes</h3>", "<div class=\"modelrow");
		if(quickHomeSec == null) quickHomeSec = U.getSectionValue(html, "Quick Move In Homes</h3>", "<div class=\"container");
		if(quickHomeSec != null){
			String quickUrlSec[] = U.getValues(quickHomeSec, "commmodelinvitem\">", "</a>");
		     for(String q:quickUrlSec) {
		    	 String qUrl=U.getSectionValue(q, "<a href=\"","\"");
		    	 U.log("QURL=="+builderUrl+qUrl);
//		    	 U.log("q=="+q);
		    	 
		    	 String quickstsSec=U.getSectionValue(q, "<div class=\"mirbanneroverlay mirbanneroverlayblue\">", "</div>");
//		    	 if(quickstsSec==null)
		    	 if(quickstsSec!=null) {
		    	 if(quickstsSec.contains("July 2022 Move-In")||quickstsSec.contains("Move-In Ready"))
		    		 quickHomeCount++;
		    	 }
		    	// qUrl=qUrl.replace("/new-homes","new-homes");
		    	  homeHtml+="\n "+U.getHTML(builderUrl +qUrl);
		    	  
		     }
		     
		     U.log("quickUrls ::"+quickUrlSec.length);
//			quickHomeCount = quickUrlSec.length;
		}
		
		
		String planHomeSec = U.getSectionValue(html, "Home PLan Collection</h3>", "<a name=\"morecommunityinfo\"");
//		if(planHomeSec == null) planHomeSec = U.getSectionValue(html, "Quick Move In Homes</h3>", "<div class=\"container");
		if(planHomeSec != null){
			String planUrlSec[] = U.getValues(planHomeSec, "commmodelinvitem\">", "VIEW PLAN DETAILS</a>");
		     for(String q:planUrlSec) {
		    	 String pUrl=U.getSectionValue(q, "<a href=\"","\"");
		    	 U.log("planUrl=="+builderUrl+pUrl);
		    	// qUrl=qUrl.replace("/new-homes","new-homes");
		    	  homeHtml+="\n"+U.getHTML(builderUrl +pUrl);
		    	  
		     }
		     
		     U.log("planUrlSec ::"+planUrlSec.length);
//			quickHomeCount = planUrlSec.length;
		}
		
		
		
		//=========== Property Type ==================
		html = html.replaceAll("-townhomes| Townhomes(\">|</a>)", "")
				.replaceAll("caption\":\"Relax in your spacious and luxurious owner`s suite", "")
				.replace("luxurious owner", "luxury home");
		
	//	U.log("MMMMM1"+Util.matchAll(comSec + html, "[\\s\\w\\W]{100}villa[\\s\\w\\W]{100}", 0));
		homeHtml=homeHtml
				.replace("Luxurious, low-maintenance wood vinyl plank flooring", "luxuries, low-maintenance wood vinyl plank flooring").replace("this home with the best in luxurious style", "this home with the best in luxuries style");
		String propType = U.getPropType((comSec + html+homeHtml).replace("your&nbsp;luxurious <strong>owner&#39;s suite", "luxurious owners suite").replaceAll("alt=\"Farmhouse style bedroom|alt=\"Craftsman style exterior of a Lake Alfred home\" t|-village|Village|VillaMar|villamar", ""));
//		U.log("MMMMM1"+Util.matchAll(comSec + html+homeHtml, "[\\s\\w\\W]{100}farm[\\s\\w\\W]{100}", 0));
		//=========== Property Status ================
		comSec=comSec.replace("Now selling in the exciting new phase", "Now Selling New Phase")
				.replace("Homes are now available in Phase 4", "Homes now available in Phase 4").replace("new phase is coming soon", "new phase coming soon").replaceAll("few homes remain available to call your own|Florida! Homes are now", "");
		html = html.replace("Limited-availability", "Limited availability").replace("new phase is coming soon", "new phase coming soon")
				.replace("Homes are selling quickly", "Homes selling quickly").replace("Home sites are now available", "Home sites now available")
				.replace("Now building in Phase 2C", "Now building Phase 2C").replace("Homes are now available", "Homes now available")
				.replaceAll("Now building in Phase II!\"|new homes coming soon to a parkside setting|Blossom Grove Estates&nbsp;is currently sold out|Blossom Grove Estates is currently sold out|center is now|Quick Move In Homes|models are now open|exclusive home|caption\":\"Coming|structure is now|'Sold|Out!</div>|mobile\">Sold|[M|m]ove-in ready", "");
		

		
		String ribbon = U.getSectionValue(html, "<div class=\"ribbonbox\">", "</div>");
		if(ribbon != null) html = html.replace(ribbon, "");
	
		html = html.replace("<strong>now building in Phase 2 </strong>of","now building in Phase 2").replace("Homes now available in Phases I and II", "Homes now available Phases I and II")
				.replace("Homes are now available in Phase 4", "Homes now available in Phase 4").replace("Homes are now available in Phase 3", "Homes now available in Phase 3").replace("Homes now available in Phase II", "Homes are now available Phase II").replace("currently <strong>sold out in Phase 1", "Phase 1 currently sold out")
				.replaceAll("brand-new neighborhood of Eagle Lake new homes, coming soon|Eagle Hammock</a>, <strong>a brand-new community&nbsp;coming soon to Eagle Lake&nbsp;|brand-new phase of this existing neighborhood|available in the brand-new Phase 3 of this popular neighborhood|new phase is in development|A new phase of Jackson Crossing is in development|few homes remain&nbsp;available to call your own|Tuscany Bay is currently|Towne Park Estates II is currently|Breakwater Cove is currently|\"Homes now|SEARCH QUICK MOVE|available in both the Forest|soon and include|Amenities opening|(Crossing|Aniston) will be opening", "");
		
		html=html.replace("currently <strong>sold out in Phase 1<", "in Phase 1 currently sold out <").replaceAll("are opening soon!\"}|VillaMar is currently sold out|states is currently sold out", "").replace("Our beautiful, brand-new model center is now open", "");
		comSec=comSec.replace("Our beautiful, brand-new model center is now open","");
		String pStatus = U.getPropStatus((( html + comSec).replace("currently sold out!","Currently Sold Out").replace("Limited availability remains</strong> in Phase 3", "Limited availability remains in Phase 3").replace("currently sold out in Phase 1","Phase 1 Currently Sold Out").replaceAll("Homes are selling quickly in|in Auburndale, coming soon|pecsitem\">Currently Sold Out|ossing is currently sold out|: 'Coming Soon',|\">Currently Sold Out|is currently sold out|community coming soon|TAGLINE\":\"Currently Sold Out\"|eadows is currently sold out|states is currently sold out|Limited availability remains in this popular neighborhood|Information Center is now open|QUICK MOVE IN HOMES</a>|New models are now open|model homes are now open|\"Coming|Homes now available in Hunter|availability coming|Siena Reserve is now open|model center is now open|models are now OPEN|Move-in Ready|move-in ready|Move-In Ready|:\"Now|Phase II!\"|model homes </strong>are now open|Coming Soon!<br>|Grand Opening Celebration|\"SHORTDESCRIPTION\":\"Now Selling New Phase |(Q|q)uick (M|m)ove-(i|I)n|[M|m]ove-in [R|r]eady|\"Homes are now|Lakeland. Homes", "")
				+ribbon).replaceAll("information center is <b>now open!</b>|information center is now open!", "")
				.replace("New Phase Coming in Summer 2022", "New Phase Coming Summer 2022")
				.replace("New Phase Coming in Late 2022", "New Phase Coming Late 2022")
				.replaceAll("A new phase of Jackson Crossing is in development|Just a few homes remain at Juliana Village|Lakefront homes - Limited availability|=\"Currently sold out - A new phase is in development!|New construction homes in Davenport, FL are now available|new model center is now open|at Lake Myrtle is now open", "")
				.replace("Homes now available in Phase 4", "Phase 4 Homes Now Available")
				.replace("final home available</strong>&nbsp;", "final home available ")
				.replace("Limited availability remains</strong>", "Limited availability remains")
				.replace("Limited availability remains in the current phases", "Limited availability remains current phases")
				.replaceAll("quick move|Quick Move|QUICK MOVE IN|Quick Move In", "")
				.replace("Homes are now available in Phase 2C", "Homes Now Available Phase 2C")
				
				);//|Homes now available in the highly|
		pStatus=pStatus
				.replace("New Phase Coming Summer 2022, New Phase", "New Phase Coming Summer 2022")
				.replace("New Phase Coming Soon, Coming Soon","New Phase Coming Soon");
		
		U.log("pStatus==="+pStatus);
//		U.log("MMMMM2"+Util.matchAll( html + comSec, "[\\s\\w\\W]{60}now open[\\s\\w\\W]{60}", 0));
//			U.log("MMMMM1"+Util.matchAll(ribbon, "[\\s\\w\\W]{60}now open[\\s\\w\\W]{60}", 0));
		
		U.log("quickHomeCount: "+quickHomeCount);
		
		pStatus=pStatus.replaceAll(", Quick Move-in|, Quick Move In Homes", "");
		if(quickHomeCount > 0 && !pStatus.contains("Quick") ){
			if(pStatus != ALLOW_BLANK) pStatus = pStatus + ", Quick Move-In Homes";
			else if(pStatus == ALLOW_BLANK) pStatus = "Quick Move-In Homes";
		}
		
		if(ribbon != null && ribbon.length()>3) {
			
			
			if(!ribbon.toLowerCase().contains("pre-selling"))
			if(!pStatus.contains(U.getCapitalise(U.getNoHtml(ribbon).toLowerCase()))) {
				
				if(pStatus.length()<3)
					pStatus = U.getCapitalise(U.getNoHtml(ribbon).toLowerCase());
				else
					pStatus += ", "+U.getCapitalise(U.getNoHtml(ribbon).toLowerCase());
			}
				
		}
		
		
		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/east-polk-county/davenport/highland-meadows"))
			propType += ", Loft";
//		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/east-polk-county/davenport/blossom-grove-estates"))pStatus += ", Limited Availability Remains";
//		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/bradenton-sarasota/palmetto/jackson-crossing")||comUrl.contains("https://www.highlandhomes.org/new-homes/florida/bradenton-sarasota/parrish/aviary-at-rutland-ranch")) {
//			pStatus = pStatus.replace("Currently Sold Out", "Phase 1 Currently Sold Out");
////			pStatus += ", Sold Out";
//		}
		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/lakeland/south-lakeland/lakeside-preserve"))
			pStatus="Currently Sold Out";
//		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/east-polk-county/davenport/highland-meadows"))
//			pStatus="Currently Sold Out";
//		if(comUrl.contains("florida/east-polk-county/lake-alfred/the-lakes"))
////		   pStatus=pStatus.replace("New Phase", "New Phase Coming in Summer 2022");
//		if(comUrl.contains("florida/tampa-bay/riverview/ridgewood"))
//			   pStatus=pStatus.replace("New Phase", "New Phase Coming in Late 2022");
		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/east-polk-county/lake-alfred/the-lakes"))
			//=========== Derived Property Type ============
		html = html.replaceAll("rutland-ranch|rutland-ranch\"|Rutland Ranch", "");
		String dType = U.getdCommType(homeHtml+html.replaceAll("A versatile second-story", ""));
		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/greater-orlando/st-cloud/gramercy-farms-townhomes"))
			dType=ALLOW_BLANK;
			
		
		pStatus=pStatus.replace("Final Opportunity, Just A Few Homes Remain, Only A Few New Homes Remain, Quick Move-In Homes", "Final Opportunity, Just A Few Homes Remain, Quick Move-In Homes")	
				.replace("New Phase Coming Late 2022, New Phase", "New Phase Coming Late 2022")
				.replace("New Phase Coming Soon, Phase 1 Currently Sold Out, Coming Soon", "New Phase Coming Soon, Phase 1 Currently Sold Out");
		pStatus=pStatus.replace("Now Building Phase 2c", "Now Building Phase 2C").replace("New Phase Coming Soon, Currently Sold Out, Coming Soon", "New Phase Coming Soon, Currently Sold Out").replace("Currently Sold Out, Sold Out", "Currently Sold Out");
		//============ Note =================
		String note = U.getnote(html.replaceAll("offers new homes for sale in Haines City|New Homes for Sale in Lake Alfred",""));
		//if(comUrl.contains("/lakeland/hunters-crossing"))pStatus=pStatus.replace(", Now Available", "");
		if(comUrl.contains("florida/east-polk-county/auburndale/enclave-at-lake-myrtle"))pStatus=pStatus.replace(", Now Open","");
		if(comUrl.contains("/new-homes/florida/tampa-bay/ruskin/riverbend"))pStatus="Currently Sold Out";
//		if(comUrl.contains("florida/bradenton-sarasota/palmetto/jackson-crossing"))pStatus="Phase 1 Currently Sold Out, New Phase Coming in Late 2022, coming soon";
//		if(comUrl.contains("/greater-orlando/st-cloud/siena-reserve"))pStatus=pStatus.replace("Coming Soon", "New Phase Coming Soon");
		if(comUrl.contains("florida/greater-orlando/st-cloud/siena-reserve"))pStatus=pStatus.replace("Homes Now Available", "Homes Now Available Phase 2C");
		if(comUrl.contains("/new-homes/florida/tampa-bay/zephyrhills/stonebridge-at-chapel-creek"))pStatus=pStatus.replace("New Phase Open, ", "");
//		if(comUrl.contains("https://www.highlandhomes.org/new-homes/florida/east-polk-county/winter-haven/villamar"))pStatus="Quick Move In Homes, Now Building In Phase 4";
		
		U.log("NEW::::::::::::");
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus.replace("Currently Sold Out, Coming Soon, Sold Out", "Currently Sold Out, Coming Soon").replace("Ii", "II"));
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		
	}
	j++;
	}
	public void addDetails(String info) throws Exception {
		//if(j==19)
		{
	//		U.log(info);
		
		String url=U.getSectionValue(info, "<h2><a href=\"", "\"");
		
		U.log("count::::"+j+"\nPage :" + url);
		url="https://www.highlandhomes.org"+url;
		U.log(url);
//		if(!url.contains("https://www.highlandhomes.org/lakeland/towne-park-2")){return;}
		
		
		if(url.contains("https://www.highlandhomes.org/lakeland/hartford-estates"))return;

		String htm = U.getHTML(url);
		
		// -- Community Name -- //
		String commName = U.getSectionValue(info, "class=\"object-title\">", "<");
		U.log(commName);
		if(data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url+":::::::::::::Repeat");
			return;
		}
		LOGGER.AddCommunityUrl(url);

		String remMeta = U.getSectionValue(htm, "<meta name=\"description\"", "\"/>");
		//U.log(remMeta);
		htm = htm.replace(remMeta,"");
		// -- Address -- //
		String geo = "False";
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, "FL",
				ALLOW_BLANK };
		String addSec = U.getSectionValue(htm, "Address:", " <span class");
	
		U.log(addSec);
		if(addSec!=null)
		{
			addSec=U.getSectionValue(addSec, "target=\"_blank\">", "</a>").replace("<br>", ",");
		/*addSec = U.formatAddress(addSec).replaceFirst(",", "")*/
			//	.replaceAll(",,|Coming Soon!", "").replace("Address", "");
		//U.log(addSec);
	//		U.log(info);
		String []addrs=addSec.split(",");
		if(addrs.length==2){
		add[3]=Util.match(addrs[1], "\\d{5}");
		add[2]=Util.match(addrs[1], "\\w+");
		
		}
		else{
			add[0]=addrs[0];
			add[1]=addrs[1];
			add[3]=Util.match(addrs[2], "\\d{5}");
			add[2]=Util.match(addrs[2], "\\w+");
			
		}
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"
				+ add[3]);
		}
		if (url.contains("https://www.highlandhomes.org/east-polk-county/juliana-village")){
			addSec = U.getSectionValue(info, "/maps/dir/Current+Location/", "\"");
			if (addSec!=null) {
				addSec=addSec.replace("%2C", ",").replace("+", " ");
				add=U.getAddress(addSec);
			}
		}

		// -- Latitude, Longitude -- //
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
		
		String ll = U.getSectionValue(htm, "center=", "&");
		//U.log(ll);
		latLng = ll.split(",");
		
		
		latLng[1] =latLng[1].trim();
		U.log("lat :" + latLng[0] + "  Long :" + latLng[1].trim());
		// -- Plans & Pricing --//
		String ppLink = url + "/home-plans";
		U.log("ppLink:::::"+ppLink);
		String ppLinkHtml=U.getHTML(ppLink);
		String removePlanPrice="priced from the Low $100's";
		ppLinkHtml=ppLinkHtml.replace(removePlanPrice, "");
		//U.log(ppLinkHtml);
		//Fetching each plans data from pla&pricing
		String allPlanData = ALLOW_BLANK;
		if(ppLinkHtml != null){
			if(ppLinkHtml.contains("object-title")){
		String[] planUrls = U.getValues(ppLinkHtml, "<h2><a href=\"", "\" class=\"object-title\">");
		
		for(String planUrl :planUrls){
			U.log("planUrl ::::: "+planUrl);
			String planHtml = U.getHTML("https://www.highlandhomes.org"+planUrl);
			allPlanData += U.getSectionValue(planHtml, "<h1 class=\"small-12 medium-8 pull-4 column\">", "<h3>Home Plan</h3>");
		}
			}
		}
		
		String allReadyData = ALLOW_BLANK;
		String rhLink = "https://www.highlandhomes.org"+U.getSectionValue(htm, "Overview</a></li><li ><a href='", "'>Ready to Own Homes")  ;
		U.log("rhLink:::::"+rhLink);
		String rhHtml = U.getHTML(rhLink);
		if(rhHtml != null){
		String[] readyUrls = U.getValues(rhHtml, "<h2><a href=\"", "\" class=\"object-title\">");
		for(String readyUrl :readyUrls){
			U.log("readyUrl ::::: "+readyUrl);
			String planHtml = U.getHTML("https://www.highlandhomes.org"+readyUrl);
			allReadyData += U.getSectionValue(planHtml, "<h1 class=\"text-center\">", "<h2>Home Plan");
		}
			
		}
		//U.log(allPlanData);
		htm=htm.replaceAll("the \\$150's.\"/>|the \\$250's\"/>", "");
		htm = htm.replaceAll("0's", "0,000s");

		// -- Price -- //
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String homehtml = U.getHTML(url + "/ready-to-own");
		String[] price = U
				.getPrices(
						htm + homehtml +  ppLinkHtml,
						"Priced At</span> \\$\\d{3},\\d{3}</li>|Base Price</span>\\s*\\$\\d+,\\d+|PRICED AT:\\s+\\$\\d+,\\d+|Base Price:\\s*(\\$\\d+,\\d+)|\\$\\d+,\\d+s",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -- Square Feet -- //
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U
				.getSqareFeet(
						htm+homehtml + ppLinkHtml,"<li>\\d,\\d{3} Sq. Ft.</li>| \\d,\\d{3} sq. ft. of living|tvalue\">\\d{1},\\d{3} Sq.Ft.</td>|Living Space:\\s*\\d,\\d{3}|\\d,\\d+\\s*.\\s*\\d,\\d+ Sq|\\d,\\d+\\s*-\\s*Sq|\\d,\\d+-plus sq. ft.|<li>\\d,\\d{3} Sq.Ft.</li>",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		String status = ALLOW_BLANK;
		String statSec = htm;
//		statSec=statSec.replace("new phase, opening in Summer 2019", "new phase opening Summer 2019");
		String remove = "townhomes now available|During the Grand Opening|new phase, opening in Summer 2019! |Limited opportunities remain to own your dream home|townhomes are now available|center will be opening soon|Browse move-in ready homes |Move-in ready homes</a> are available now|waterfront home sites available|number of home sites available|inventory homes available|title='Waterfront home sites available| alt=\"Waterfront home sites available|cabana opening soon!|Now selling in the exciting new phase|<p>Coming Soon!</p>    </p>|value=\"townhouse\" checked=\"|single family home\" checked=\"checked\"/>single family home|Coming Soon to Apopka|Now Open|Palmetto Estates is now open|Conservation homesites - Sold Out|center now open|checked\"/>townhome|currently under construction a|Southwind is now open|Grand Opening news|Center under construction|Coming Soon - New Homes|center is now open|<p>Coming Soon!</p>    </p>";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		statSec=statSec.replace("<p>Coming Soon!</p>    </p>", "");
		String removeStatusP="";
		if(statSec!=null)
		{
			removeStatusP=U.getSectionValue(statSec," <p class=\"model-plan\">","  <p class=\"community-contact\">");
			if(removeStatusP!=null){
				statSec=statSec.replace(removeStatusP, "");
			}
			
		}
//		U.log(htm);
		statSec = statSec.replace("-NowSelling.jpg".toLowerCase(), " Now Selling ").replace("new phase, coming soon", "new phase coming soon");
		U.log("MMMMMMMMmmm "+statSec);
		status = U.getPropStatus(statSec.replaceAll("model homes are now open|:\"Now|model homes </strong>are now open|previously sold out", "")).replace("Coming Soon,", "");
		if(url.contains("https://www.highlandhomes.org/lakeland/wind-meadows"))
		{
			
			status="Final opportunity, Six homesites remaining, Limited homesites remaining";
			
		}
		
		
//		
		
		String ready=url+"/ready-to-own";
		String readyown=U.getHTML(ready);
		
		if(readyown.contains("We do not have Ready to Own homes currently available at this")){
			if(status.length()<4){
				status="No Move-in Ready Homes";
			}
			else{
				status=status+", No Move-in Ready Homes";
			}
		}
		else{
			if (!status.contains("Move-in Ready")) {
				if(status.length()<4){
					status="Move-in Ready Homes";
				}
				else{
					status=status+", Move-in Ready Homes";
				}
			}
			
		}
	
	if(status.contains("Move-in Ready Homes")){
		status=status.replace("Move-in Ready,","");
	}
	String ppLinkHtml1=U.getSectionValue(ppLinkHtml," <h4>Home Type</h4>","<div class=\"schools\">");
	if(ppLinkHtml1==null){
		ppLinkHtml1=ALLOW_BLANK;
	}
	if(url.contains("https://www.highlandhomes.org/sarasota/palmer-place"))
	{
		
		status="Final opportunity, Move-in Ready Homes";
		
	}
	ppLinkHtml1=ppLinkHtml1.replaceAll("New townhomes in Sarasota, FL|checked\"/>Townhome","");
	htm=htm.replaceAll("New townhomes in Sarasota, FL|checked\"/>Townhome","");
	//U.log("ppLinkHtml1 : "+ppLinkHtml1);
	String ss=U.getSectionValue(htm, "<section id=\"body\"","</section>");
	ss=U.getNoHtml(ss);
	htm=U.getNoHtml(htm);
	String pType=U.getPropType((allReadyData+allPlanData+ss+ppLinkHtml1).replaceAll("Condor|Craftsman-style exterior|Craftsman-style exterior|condor|Village|village|luxury master|common area with", ""));
	//U.log(Util.match(htm, ".*?townhome.*?"));
	
	if(pType.contains("Townhouse")){
		pType=pType.replace("Townhouse,","");
	}
	if(add[0]==ALLOW_BLANK){
		add = U.getAddressGoogleApi(latLng);
		geo ="True";
		}
	if(url.contains("https://www.highlandhomes.org/lakeland/towne-park-2"))	status="Homes Now Available Phase IIB, Move-in Ready Homes";
	status=status.replace("Limited Availability Remains, Limited Opportunities Remain, Move-in Ready Homes","Limited Availability Remains, Move-in Ready Homes");
	status=status.replace("One Home Remains","One Home Remains Available");
		if(add[0].length()==0)
		{add=U.getAddressGoogleApi(latLng);}
		//U.log(statSec);
		//htm = htm.toLowerCase().replaceAll("history|one story|two stories", "");
		String notes=U.getnote(htm);
		// Add All
		htm=U.getHTML(url);
		remMeta = U.getSectionValue(htm, "<meta name=\"description\"", "\"/>");
		htm = htm.replace(remMeta, "");
		if(add[2].length()>2)add[2]=ALLOW_BLANK;
		data.addCommunity(commName, url, U.getCommunityType(htm));
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		//htm=htm.toLowerCase().replace("wiregrass ranch high", "");
		data.addPropertyType(pType, U.getdCommType((htm+allPlanData).replaceAll("ranch|Ranch","")));
		data.addPropertyStatus(status.replace("�", ""));
		data.addNotes(notes);
		
		}j++;
	}
}