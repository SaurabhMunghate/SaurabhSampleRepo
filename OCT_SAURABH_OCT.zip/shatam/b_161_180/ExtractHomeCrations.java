package com.shatam.b_161_180;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHomeCrations extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j = 0;
	WebDriver driver = null;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractHomeCrations();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Home Creations.csv", a.data().printAll());
	}

	public ExtractHomeCrations() throws Exception {
		super("Home Creations", "https://www.homecreations.com");
		LOGGER = new CommunityLogger("Home Creations");
	}

	HashMap<String, String> listViewData = new HashMap<>();

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();

		String url1 = "https://www.homecreations.com/";
		String html1 = U.getHTML(url1);
		String[] citUrl=U.getValues(html1, "<div class=\"swiper-slide city-slide okc-city-slide\">", "</p></div>");
		U.log(citUrl.length);
		for (String citySec : citUrl) {
			String url=U.getSectionValue(citySec, "href=\"", "\"");
			U.log("https://www.homecreations.com"+url);
			String html=U.getHTML("https://www.homecreations.com"+url);
//			U.log("https://www.homecreations.com"+url);
			String rowListings[] = U.getValues(html, "<div class=\"card location-map-item\"", "View Details</a>");
//
//			U.log(rowListings.length);
			for (String itom : rowListings) {
				// U.log(itom);
				addNewDetails(itom);//
				inr++;
				i++;
			}
			U.log("total" + rowListings.length);
		}
//		
//		String html = U.getHTML("https://www.homecreations.com/new-homes/ok/tulsa/");
////		U.log("https://www.homecreations.com"+url);
//		String rowListings[] = U.getValues(html, "<div class=\"card location-map-item", "</div></div></div></div>");
//
//		U.log(rowListings.length);
//		for (String itom : rowListings) {
//			// U.log(itom);
////			addNewDetails(itom);//
//		}
//		
		

		 try { driver.quit(); } catch (Exception e) {}
		LOGGER.DisposeLogger();
		
	}

	int count = 0;

	private void addNewDetails(String comsec) throws Exception {
//		 if(j == 9)
		{
			count++;
			

			U.log("hhhhhhhhh: " + comsec);
			String url = U.getSectionValue(comsec, "href=\"", "\"");

			String comurl = "https://www.homecreations.com" + url;
			

//			if(!comurl.contains("https://www.homecreations.com/new-homes/ok/newcastle/farmington/399/"))return;
			
			U.log(U.getCache(comurl));
			
			if (data.communityUrlExists(comurl)) {
				LOGGER.AddCommunityUrl(comurl + "::::::::::::repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comurl);

			U.log(":::::::::::::::::::" + count);
			U.log("comurl====="+comurl);
//			U.log("hhhhhhhhh: \n" + comsec);
			String html = U.getHtml(comurl, driver);
			// String html = U.getHtmlHeadlessFirefox(comurl,driver);
			String commName = U.getSectionValue(comsec, "<strong>", "</strong>");
			commName = commName.replaceAll("Villas$", "");
			commName=U.getNoHtml(commName);
			U.log("COMMNAME::" + commName);

			// ===========================================Address
			// Sec===============================================================================================

			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };

			latlng[0] = U.getSectionValue(comsec, "data-latitude=\"", "\"");
			latlng[1] = U.getSectionValue(comsec, "data-longitude=\"", "\"");
			// address
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String Geo = "false";
			String addSec = U.getSectionValue(comsec, "<span class=\"x-small text-gray py-1\">", "</span>");
			
			if (addSec != null) {
				addSec = addSec.replaceAll("<br/>|<br>\\s*", ",").replace("OK 73099, Yukon, OK", "OK 73099");
				U.log("addSec:"+addSec);
				add = U.getAddress(addSec.replace("73099,Yukon, OK", "73099"));
			}
			if(add[0].length()<4 && latlng[0].length()>4) {
				add=U.getAddressGoogleApi(latlng);
				if(add == null)add = U.getGoogleAddressWithKey(latlng);
				Geo="TRUE";
			}
			if(add[3].length()<4 && latlng[0].length()>4) {
				add[3]=U.getAddressGoogleApi(latlng)[3];
				Geo="TRUE";
			}
			add[0]=add[0].replace("w 111th street s s willow street", "w 111th street s and s willow street");
			U.log("Street :" + add[0] + "==== City :" + add[1] + "==== State :" + add[2] + "==== zip :" + add[3]);
			// =================================== FloorPlan Data
			// =======================================================================================================

			String allFloorData = ALLOW_BLANK;
			String[] floorSec = U.getValues(html, "<div class=\"card-body-sec card-top-se", "View Details");
			if(floorSec.length == 0) floorSec = U.getValues(html, "<p class=\"h4 card-vert-item\">", "View Details");
			U.log("Total floorplan : " + floorSec.length);
			for (String floorS : floorSec) {
				try {
					// U.log(flrUrl);
					String flrUr = U.getSectionValue(floorS, "<a class=\"btn btn-primary btn-sm\" href=\"", "\"");
					U.log("flrUrl : " + flrUr);
					if (flrUr == null)
						continue;
					String fhtml = U.getHTML("https://www.homecreations.com" + flrUr);
					String homeSec = U.getSectionValue(fhtml, "<h3 class=\"heading-small\">Unique Home Features</h3>", "About The Community</h3>")
							+ U.getSectionValue(fhtml, " </script><div class=\"d-block mt", "</div></div>");
					
					if(homeSec == null)	homeSec = U.getSectionValue(fhtml, "<div class=\"d-block mt-3\">", "School Info</h3>");
					
					allFloorData += homeSec;
//							"<script type=\"text/javascript\">");
				} catch (Exception e) {
				}
			}
			
			
			String[] homeData=U.getValues(html, " <div class=\"swiper-slide sortable_spec_car", "View Details</a>");
			U.log("homeData>>>>>>>"+homeData.length);
			String homeHtml=null;
			for(String homedata : homeData) {
//				U.log("homeData>>>>>>>"+homedata);

				String homeUrl="https://www.homecreations.com"+U.getSectionValue(homedata, "<a href=\"", "\"");
				 homeHtml=U.getHtml(homeUrl, driver);
				 homeHtml+=U.getSectionValue(homeHtml, "<span class=\"heading\">", "About The Community</h3>")
						 +U.getSectionValue(homeHtml, " </script><div class=\"d-block mt", "</div></div>");
				
			}
			
			
			

			// =================================== price and squarefeet
			// =======================================================================================================

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replace("0&#39;s", "0,000").replace("0's", "0,000");

			String[] price = U.getPrices(comsec + html + allFloorData,
					"Starting at</span> <span class=\"text-red\">\\$\\d{3},\\d{3}|Starting from</span> <span class=\"text-red\">\\$\\d{3},\\d{3}|Priced at</span> <span class=\"text-red\">\\$\\d{3},\\d{3}|<span class=\"text-red\">\\$\\d{3},\\d{3}",
					0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// ------------Square Feet

			String[] sqft = U.getSqareFeet(html + comsec,
					"\\d,\\d{3} - \\d,\\d{3}</strong> Sq Ft|\\d,\\d{3}</strong> Sq Ft", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			html = html
					.replace("villas-yukon-community-highlight/\">brookstone villas, yukon � community highlight", "")
					.replace("2016/05/12/brookstone-villas", "");
			html = html.replace("-yukon-community-highlight/\">Brookstone Villas", "")
					.replaceAll("new-home_Hoa|Rhoades", "");

			// ============= Avaialble Home =====================

		//	 U.log(allFloorData);
			
			if(allFloorData != null)
				allFloorData = allFloorData.replaceAll("Farmhouse inspired sliding barn door|Traditional wood and slate", "");
//				.replace("access to the patio", "access to the covered patio");
			html = html
					.replace("custom floor plans", "custom homes").replace("luxury and exclusivity", "luxury homes and exclusivity")
					.replace("Elegance and luxury come standard in", "Elegance and luxury homes come standard in");
			if(homeHtml!=null)
			homeHtml=homeHtml.replace("covered back patio", "rear covered patio");
			String PType = U.getPropType((html + allFloorData+homeHtml));
//			U.log(Util.matchAll(html + allFloorData+homeHtml, "[\\s\\W\\w]{30}\\$268[\\s\\w\\W]{30}", 0));
			U.log("PType : "+PType);
			// =================== Property Status ====================
/*			String sss = "";
			String homehtml = U.getHTML("https://www.homecreations.com/new-homes/");
			String[] frontSec = U.getValues(homehtml, "<div class=\"row listing\">",
					"<div class=\"list-column columns list-view-more\">");
			for (String statSec : frontSec) {
				if (statSec.contains(commName))
					sss = statSec;
			}*/
			html = html.replaceAll("move-in ready option|card-banner heading\">Coming Soon</div>", "");
			String status = U.getPropStatus(comsec + html);
			U.log("status: "+status);
			
			if(html.contains("<div class=\"card-vert-item card-banner heading\">Move-In Ready</div>")){
				if(status == ALLOW_BLANK)status ="Move-In Ready";
				//else if(status != ALLOW_BLANK && !status.contains("Move-In Ready"))status +=", Move-In Ready";
			}
			// ================= Derived Property Type =================
			html = html.replaceAll("Ranch Lake|Cheek Ranch|[B|b]ranch", "")
					.replace("Whether 3-beds or 4, one-story or two", "Whether 3-beds or 4, one-story or two story");
			if(comurl.contains("https://www.homecreations.com/new-homes/ok/norman/blue-ridge/3042/"))status=ALLOW_BLANK;
			String dType = U.getdCommType(html + allFloorData+homeHtml);
			
			U.log(Util.matchAll(html + allFloorData+homeHtml, "[\\s\\W\\w]{30}2 story[\\s\\w\\W]{30}", 0));
			String note = U.getnote(html + comsec);
			
			String cType = U.getCommunityType(html).replaceAll("Moore Golf Course|masterplan", "");
			U.log("cType: "+cType);
			U.log(U.getSectionValue(html, "name=\"map_iframe\" scrolling=\"no\" src=\"", "\""));
			String lotMapData ="";
			String lotIds ="";
			if(html.contains("map_iframe")) {
				lotMapData= U.getHTML(U.getSectionValue(html, "name=\"map_iframe\" scrolling=\"no\" src=\"", "\""));
				lotIds= Util.matchAll(lotMapData, "text-anchor=\"middle\">", 0).size()>0?Util.matchAll(lotMapData, "text-anchor=\"middle\">", 0).size()+"":ALLOW_BLANK; 
			}
			if(lotIds.length()<1)lotIds=ALLOW_BLANK;
			data.addCommunity(commName, comurl,cType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), Geo);
			data.addPropertyType(PType, dType);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addUnitCount(lotIds);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);		}
		j++;
	}

}