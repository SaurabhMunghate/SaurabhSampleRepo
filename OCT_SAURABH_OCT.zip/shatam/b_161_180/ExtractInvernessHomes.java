package com.shatam.b_161_180;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractInvernessHomes extends AbstractScrapper 
{
	int i = 0;
	static int j=0;
	public int inr = 0;
	public static CommunityLogger LOGGER;
	public ExtractInvernessHomes() throws Exception 
	{

		super("Inverness Homes", "https://www.invernesshomesusa.com/");
		LOGGER=new CommunityLogger("Inverness Homes");

	}

	public static void main(String[] args) throws Exception 
	{

		AbstractScrapper a = new ExtractInvernessHomes();

		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Inverness Homes.csv", a.data().printAll());
	}


	public void innerProcess() throws Exception 
	{
		String url = "https://www.invernesshomesusa.com/";
//		String html = U.getHTMLwithProxy(url);
		String html = U.getHTML(url);
		String regSec=U.getSectionValue(html, "COMMUNITIES</span> <span class=\"fusion-caret\">", ">ABOUT US</span>");
		U.log(regSec);
		String regUrls[]=U.getValues(regSec, "<a  href=\"", "\"");
		for(String reg:regUrls) {
			if(reg.contains("/about-us"))continue;
			U.log(reg);
			String regHtm=U.getHTML(reg);
			String comSec[]=U.getValues(regHtm, "\"title", ",\"custom_filters\":[]}");
//			U.log(comSec.length);
			for(String sec:comSec) {
				String comurl=ALLOW_BLANK;
//				if(sec.contains("{marker_title}"))continue;
				comurl=StringEscapeUtils.unescapeJava(U.getSectionValue(sec, "<a href=", ">"));
				//U.log("Sec::::::::::::::::::\n"+StringEscapeUtils.unescapeJava(sec)+"\n::::::::::::endSec");
				if(!comurl.contains("https"))
				comurl="https://www.invernesshomesusa.com"+comurl;
				addDetails(comurl.replace("\"", ""), sec);
			}
		}
		LOGGER.DisposeLogger();

	}

	private void addDetails(String comUrl,String comsec) throws Exception {
	
//	if(j==9)
	{
		//U.log("count::::::::::::"+j+":::::::::::::::::::::::::");
		String commName = null, street = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK, city = ALLOW_BLANK, latitude = ALLOW_BLANK, longitude = ALLOW_BLANK, minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;
		String pType = ALLOW_BLANK, status = ALLOW_BLANK, maxPrice = ALLOW_BLANK, minPrice = ALLOW_BLANK;
		U.log("Page Community:" + comUrl);
	//				comUrl=comUrl.replace("/greenshire-commons/", "/greenshire-commons").replaceAll("bluffs-on-trebein/", "bluffs-on-trebein/");
		if(comUrl.endsWith("/")) {
			comUrl=comUrl.replaceAll("/$", "");
		}
	
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"::::::::::::::::::::repeated::::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String comHtml = U.getHTML(comUrl);
		comHtml=comHtml.replace("We are NOW SELLING","");
		
		//TODO: For Single Community Execution
//		if(!comUrl.contains("https://www.invernesshomesusa.com/dayton-ohio/bluffs-on-trebein"))return;
		
	
		// community name
	
		commName = U.getSectionValue(comHtml, "<h1 class=\"title-heading-left\">", "</h1>");
		 U.log("Community Name:-"+commName);
		// address
		String add[] = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
	
		String secmap = U.getSectionValue(comHtml, "><div class=\"fusion-text\">",
				"<br");
		U.log("gggggggg"+secmap);
		if(secmap.contains("OH,"))secmap=secmap.replaceAll("OH,", "OH");
				secmap=secmap.replaceAll(", Green Township|, Miami Township", "");
		add=U.findAddress(secmap);
		if(secmap!=null && add==null) {
			add=U.getAddress(secmap);
			add[0]=U.getNoHtml(add[0]);
		}
	
		// =====================lat and lng==========================
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		latLng[0]=U.getSectionValue(comsec, "\"lat\":\"", "\"");
		latLng[1]=U.getSectionValue(comsec, "\"lng\":\"", "\"");
		String planhtml="";
		String AllPlanData="";
		String[] plans=U.getValues(comHtml, "<h2 class=\"entry-title fusion-post-title\">", "</a>");
		for(String plan:plans)
		{
			plan=U.getSectionValue(plan, "href=\"", "\"");
			U.log(":::::::::::::::::::::::::::::::::::"+plan);
	//					planhtml=U.getHTMLwithProxy(plan);
			planhtml=U.getHTML(plan);
			AllPlanData += U.getSectionValue(planhtml, "<div class=\"fusion-title title fusion-title-size-three\" ", "Download Design</span>"); 
		}
		// =============================Price=============================================
		String secremove = U.getSectionValue(comHtml, "<div class=\"wpgmp_map_container", "</body>");
		comHtml=comHtml.replace(secremove, "");
	//				U.log(Util.matchAll(comsec, "[\\w\\s\\W]{30}\\$300[\\w\\s\\W]{30}", 0));
		comsec=comsec.replaceAll("\"name\":\"\\$\\d{3}-\\$\\d{3},\\d{3}\"|<option value=\".*</option>", "").replace("0's", "0,000");
//		U.log(comHtml.contains(secremove));
		
	
		comHtml=comHtml.replace("&#8217;s", ",000").replace(" &#8211", "");
//		U.log(Util.match(comHtml, ".*Priced From</strong>: \\$\\d{3}.*"));
		String price1[] = U.getPrices(comHtml+comsec+AllPlanData,
				"Priced From</strong>: \\$\\d{3},\\d{3}|<td class=\"currency\">\\d{6}|\\$\\d{3},\\d{3}", 0);
		minPrice = (price1[0] != null) ? price1[0] : ALLOW_BLANK;
		maxPrice = (price1[1] != null) ? price1[1] : ALLOW_BLANK;
		U.log("Minprice" + minPrice);
		U.log("maxPrice" + maxPrice);
		
//		U.log(Util.match(comHtml, ".*Square Footage</strong>: 1510.*"));
		String sqft[] = U.getSqareFeet(comHtml, "Square Footage</strong>: \\d{4}; \\d{4}\\+</div>|Square Footage</strong>: \\d{4} ; \\d{4}\\+?|\\d{4} sq. ft.|[0-9]{1},[0-9]{3} sq. ft.", 0);
		minSq = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSq = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	
		// Community Type
		String drop=U.getSectionValue(comHtml, "<script type=\"text/javascript\">", "</script>");
		if(drop!=null)
			comHtml=comHtml.replace(drop, "");
		comHtml=comHtml.replace("Move-In Ready Homes", "").replace("Move", "").replace("large homesites are available", "large homesites available");
		comHtml=comHtml.replace("lots available.", "");
		comHtml=comHtml.replace("now open! Inverness", "").replace("s now open at Landings at Sugarcreek", "").replace("New Phase of Homesites Just Released", "New Phase Homesites Just Released");
		comHtml=comHtml.replaceAll("map-desc\"><h2>New Section Now Selling|<h2>New Model Now Open!|\"Sinclair\" Now Open", "").replace("We are now selling at Landings", "").replace("New Model Now Open!", "").replace("move", "");
		comHtml=comHtml.replace("now open","").replace("NOW OPEN","").replace("Now Open","");
		String pStatus = U.getPropStatus(comHtml);
		comHtml=comHtml.replaceAll("villas|Villas", "");
		String newname=commName.replaceAll("village|Village", "");
		
		if(drop!=null)
			comHtml=comHtml.replace(drop, "");
		
		//U.log("::::::::::::::::::::::::::::::::::"+planhtml);
		comHtml = comHtml.replace(" luxury upgrade", "luxury homes");
		pType = U.getPropType((AllPlanData.replaceAll("villas_at|villas-at-kettering-pointe|Villas at Kettering Pointe", "")+comHtml).replaceAll("village|Village|Carriage|carriage_trails|carriage", "")+newname);
		U.log("Property type::::"+pType);
	
		String geo = "false";
		latitude=latLng[0];
		longitude=latLng[1];
		String[] latlng = { latitude, longitude };
	
		if (comHtml.contains("font-weight: 600;\">AVAILABLE</p>") || comHtml.contains("font-weight: 600;\">PENDING</p>")) {
			{
				if (pStatus.length() > 1) {
					pStatus = pStatus + ", Quick Move-in Homes";
				} else
					pStatus = "Quick Move-in Homes";
			}
		}
		if(add[0]==ALLOW_BLANK && latitude!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getGoogleAddressWithKey(latlng);
			geo="true";
		}
	
		String comHtm=comHtml;
		
		String communityType="";
		String dType="";
		if(comHtm!=null)
		{
	//					comHtm=U.getSectionValue(comHtm, "<div class=\"community-desc\"", "</div>")+U.getSectionValue(comHtm, "\">Recreation</a>", "</table>");
	//					comHtm=comHtm.replaceAll("Pipestone Golf Course|Community Golf Course", "");
	//					U.log(Util.matchAll(comHtm,"[\\w\\s\\W]{30}golf[\\w\\s\\W]{30}",0));
	
			communityType=U.getCommType(comHtm);
		}
		String remSliderBar=U.getSectionValue(comHtml, "<div class=\"sidebar\">", "</ul>");
		if (remSliderBar!=null) {
			comHtml=comHtml.replace(remSliderBar, "");
		}
		String remScripData=U.getSectionValue(comHtml, "var communities=[{\"id\":\"", "</script>");
		if (remScripData!=null) {
			U.log(":::::::::::Reomve Script::::");
			comHtml=comHtml.replace(remScripData, "");
		}
	//	U.log(comHtml);
		String moveInSec=ALLOW_BLANK;
		if (comHtml.contains(" <div id=\"tab-3\" class=\"tab-pane fade\">")) {
			moveInSec=U.getSectionValue(comHtml, "<div class=\"homes-desc-wrap\">", "<table class=\"footable\"");
		}
		U.log("moveInSec::"+moveInSec);
		pStatus=pStatus.replace("Final Phase Coming Soon, Coming Soon, Final Phase","Final Phase Coming Soon");
		pStatus=pStatus.replace("Phase 3 Now Selling, Now Selling", "Phase 3 Now Selling");
		
		comHtml=comHtml.replaceAll("story collection|whether your need is for a ranch home|three bedroom ranches", "");
					U.log(Util.matchAll(comHtml+moveInSec+planhtml+AllPlanData, "[\\w\\s\\W]{30}1/2 story[\\w\\s\\W]{30}", 0));
	
		//planhtml=planhtml.replace("5 unique levels of living.", "5 Story");
		dType=U.getdCommType((comHtml+moveInSec+planhtml+AllPlanData).replaceAll("village two-story-brighton fusion-col|y/two-story-brighton/\" |whether your need is for a ranch|offers a wide variety of ranch", "")); //+moveInSec
		add[0]=add[0].replaceAll(", Green Township|, Miami Township", "");

		data.addCommunity(commName, comUrl, communityType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSq, maxSq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(ALLOW_BLANK);
	
		
		}
		j++;
	}
		
}

