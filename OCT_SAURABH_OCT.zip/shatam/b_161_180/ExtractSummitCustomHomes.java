/**
 *
 @Author 
 */
package com.shatam.b_161_180;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSummitCustomHomes extends AbstractScrapper {
	static String BASEURL = "https://www.summithomeskc.com";
	static int j = 0;
	WebDriver driver = null;
	CommunityLogger LOGGER;
	// public WebDriver driver = new FirefoxDriver();

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSummitCustomHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Summit Homes.csv", a.data().printAll());
	}

	public ExtractSummitCustomHomes() throws Exception {

		super("Summit Homes", BASEURL);
		LOGGER = new CommunityLogger("Summit Homes");
	}

	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String, String>();

	public void innerProcess() throws Exception {
		// U.setUpGeckoPath();
		// //driver=new FirefoxDriver(U.getFirefoxBinary(),U.getFirefoxProfile());
		// driver = new FirefoxDriver();
		// String html = U.getHTML("https://www.summithomeskc.com");//***********create
		// txt file ************
		// String html =
		// U.getHtml("https://www.summithomeskc.com/communities/kansas-city-area",
		// driver)+U.getHtml("https://www.summithomeskc.com/communities/des-moines-area",driver);
		String html = U.getHTML("https://www.summithomeskc.com/communities");
		String communityList[] = U.getValues(html, "<div class=\"css-177gqtm\" ", "alt=\"Icon More Details\"");
		JsonParser jparser = new JsonParser();
		String jsonString = U.getSectionValue(html, "window.__PRELOADED_STATE__ = ", "</script>");
		// U.log(jsonString);
		JsonObject jobj = (JsonObject) jparser.parse(jsonString).getAsJsonObject().get("cloudData");
		// String redirecrSec=U.getSectionValue(jsonString, "\"redirects\":", "]");
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities");
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans");
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes");
		// U.log(planJson);
		String plans[] = U.getValues(planJson.toString(), "{\"@type\":\"ProductModel", "\"type\":\"plan\"");

		String homes[] = U.getValues(homeJson.toString(), "{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}");
		for (String home : homes) {
			String comunityIn = U.getSectionValue(home, "\"containedIn\":\"", "\"");
			homesData.put(comunityIn, home);
		}
		U.log(plans.length);
		for (String plan : plans) {
//			if(!plan.contains("5fcf9f614db04806c4f530d9"))continue;
//			U.log(plan);
			String[] comms =null;
			if(plan.contains("communityModelProperties"))
				comms=U.getValues(plan, "{\"community\"", "}}");
			else
				comms=U.getValues(plan, "{\"community\"", "}");
			for (String com : comms) {
				String comunityIn = U.getSectionValue(com, ":\"", "\"");
				plansData.put(comunityIn, com+"}"+plan.replace(U.getSectionValue(plan,"\"communities\":[", "]"),""));
			}
		}

		String comSection[] = U.getValues(
				U.removeSectionValue(commJson.toString(), "\"unpublished\":[", "receivedAt\":"),
				"{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");

		for (String comSec : comSection) {
			// U.log(U.getSectionValue(comSec, "\"sharedName\":\"", "\","));
			// U.log(U.getSectionValue(comSec, "\"sharedName\":\"", "\","));
			commDatas.put(U.getSectionValue(comSec, "\"sharedName\":\"", "\","), comSec);
			// break;
		}
		for (String commSec : communityList) {
			// U.log(commSec);
			String commUrl = "https://www.summithomeskc.com" + U.getSectionValue(commSec, "href=\"", "\"");
			// U.log(commUrl);
			String sharedName = commUrl.split("/")[6];
			// U.log(sharedName);
			commSec = commDatas.get(sharedName.replace("care-free", "carefree")) + commSec;
			// U.log(commSec);

			addDetails(commUrl,
					commSec.replaceAll(" data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->|<!-- /react-text -->", ""));
			// break;
		}

		U.log(homesData.size());
		U.log(plansData.size());
		LOGGER.DisposeLogger();
	}

	// TODO :
	public void addDetails(String url, String info) throws Exception {
		// if(j >=20)
		{

			info = info.trim();
			// info

//			if (!url.contains("https://www.summithomeskc.com/communities/kansas-city-area/overland-park/southpointe"))
//				return;
			String comName = U.getSectionValue(info, "<h4 class=\"d-flex flex-column\">", "<span class=\"mt-1\">");
			U.log(info + "\n::::::::::::::::::::" + j + "::::::::::::::::::::::\n" + comName);
			String siteDesc = U.getSectionValue(info, "],\"description\":\"", "\",\"");
			String comId = U.getSectionValue(info, "\"_id\":\"", "\"");
			U.log(comId);
			if (siteDesc == null) {
				String tempSiteDesc[] = U.getValues(info, "\"description\":\"", "\"");
				if (tempSiteDesc.length == 2) {
					siteDesc = tempSiteDesc[1];
				}else {
					siteDesc=ALLOW_BLANK;
				}
			}
//			U.log("---=-=-=" + siteDesc);
			ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId);
			//U.log("---=-=-=" + homeData.size());
			String homesecs = ALLOW_BLANK;
			String Modelhomesecs = ALLOW_BLANK;
			boolean modelPresent=false;
			if (homeData != null) {
				for (String home : homeData) {
					if(home.contains("\"isModel\":true,")) {
						modelPresent=true;
						Modelhomesecs=home;
					}
					homesecs += home;
				}
			}
			U.log(homesecs);
			ArrayList<String> planData = (ArrayList<String>) plansData.get(comId);
			String plansecs = ALLOW_BLANK;
			//U.log("---=-=-=" + planData.size());
			if (planData != null) {
				
				for (String plan : planData) {
					
					
					plansecs += plan.replaceAll("\"stories\":1.5,\"style\":\"1.5 Story\"|rse 1.5 story floor plan!\",|Reverse\\s+1|\"styles\":\"Reverse 1\\.5\",|\"headline\":\"New Reverse 1\\.5 story floor plan\",", "");
					if(plansecs.contains("1.5 Story"))
						U.log(plan.replaceAll("\"stories\":1.5,\"style\":\"1.5 Story\"|rse 1.5 story floor plan!\",|Reverse\\s+1|\"styles\":\"Reverse 1\\.5\",|\"headline\":\"New Reverse 1\\.5 story floor plan\",", ""));
//					break;
				}
			}
//			U.log("---=-=-=" + plansecs);
			// //
			// ..................................CommunityUrl......................................

			// U.log(url);
			// url = url.replace("http:", "https:");
			//
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "============>>>>>>Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			String[] latlong = { ALLOW_BLANK, ALLOW_BLANK };
			String add[]= { ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK, ALLOW_BLANK };
			String geo="False";
//			U.log(addSec);
			if(modelPresent) {
				String addSec = U.getSectionValue(Modelhomesecs, "\"address\":{\"@type\":\"PostalAddress\"", "},\"");
				add[0]=U.getSectionValue(addSec, "\"streetAddress\":\"", "\"");
				add[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
				add[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
				add[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\"");
//				U.log(Modelhomesecs);
//				U.log(addSec);
				U.log(Arrays.toString(add));
//				add
			}
			String latlon = U.getSectionValue(info, "\"geoIndexed\":[", "]");

			if (latlon != null) {
				String lonlat[] = latlon.split(",");
				latlong[0] = lonlat[1];
				latlong[1] = lonlat[0];
			}
			if(add[0]==ALLOW_BLANK&&latlong[0].length()>3) {
				add=U.getAddressGoogleApi(latlong);
				 geo="True";
			}
			
			siteDesc = siteDesc.replace("Available Lots", "Lots Available").replace("\">Coming Soon", "").replaceAll("New community opening\\s*Fall 2018!", "New community Opening Fall 2018!");
			siteDesc =siteDesc.replaceAll("class=\"ng-binding ng-scope\">Now available!|Homes now available|class=\"ng-binding ng-scope\">Coming soon!|Move-In Ready Homes now available|[q|Q]uick [M|m]ove|\"Summit Custom|Clubhouse Rendering - coming soon!|New phase coming 2019,|Coming Soon - Pool|Coming Soon - Playground|Pool coming summer 2019!|NOW OPEN! Sunday - |Clubhouse Coming in 2019!|pool coming summer 2018|Move-in ready homes now available|NOW OPEN! Located off |Now open for build jobs|Information Center Opening Summer 2016|Coming Soon</h5>|lots coming soon|>View Move-In Ready|>Sales Hours: Coming Soon|Center Coming Soon|Hours: Coming this September|<option>Select a Move-In Ready Home</option>|a href=\"/move-in-ready\">MOVE-IN READY</a></li>|Move in ready home|Move-In Ready Homes", "")
			 .replace("Close - Out Phase", "Close Out Phase");
			// U.log(Util.matchAll(html, "[\\w\\s\\W]{50}coming soon[\\w\\s\\W]{30}", 0));
			 //
			 String propstatus = U.getPropStatus(siteDesc);
			 
			 if(homesecs.contains("\"headline\":\"Move In Ready!\"")&&!(propstatus.contains("Move In")||propstatus.contains("Quick Move"))) {
				 if(propstatus==ALLOW_BLANK) {
					 propstatus="Quick Move-In Homes";
				 }else {
					 propstatus+=", Quick Move-In Homes";
				 }
			 }
			 U.log("propStatus :: "+propstatus);

			// // ........................... price ........................
			 String minPrice="";
			 String maxPrice="";
			 String sqft[] = U.getSqareFeet((info+siteDesc+homesecs+plansecs),",\"sqft\":\\d{4},\"stories\"|\"sqftHigh\":\\d{4},\"sqftLow\":\\d{4},\"status\":\"Active\"|\"sqft\":\\d{4},\"status\":", 0);
			 String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			 String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			 U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			 String price[] = U.getPrices((info+siteDesc+homesecs+plansecs), "\"communityModelProperties\":\\{\"price\":\\d{6,7}\\}\",|\"priceLow\":\\d{6,7},\"published\":true,|\"price\":\\d{6,7},\"published\":true,",0);
			 minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			 maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			 U.log("price: "+minPrice + ":::::::::" +maxPrice);
			
			 String dtype = U.getdCommType((comName+url+siteDesc+homesecs+plansecs).replace("2-Story</span>", "2 story").replaceAll("\"headline\":\"New Reverse 1.5 story floor plan\",|ng-binding\">&nbsp;1.5 Story|ng-binding\">&nbsp;2 Story|ng-binding\">&nbsp;Reverse 1.5 Story","").replaceAll("&nbsp;2-Story</span>|&nbsp;2-Story</span>", "Story 2 ").replace("1-Story</span>", "1 story").replace("spacious new 1.5 REV floorplan", "Reverse-one-half-Story").replaceAll("Ranch|RANCH", "")); //ranch| U.log("Dtype :: "+dtype);
			U.log(dtype);
			String units=ALLOW_BLANK;
			 //
			// //--------PropertyTYpe---------------
			// html=U.getNoHtml(html);
			// String remData = "ithout the burden of an HOA|Community: Manor
			// at|village|Village|Carriage style steel doors|Carriage style |Carriage style
			// insulated";
			 String proptype = U.getPropType((comName+(siteDesc+homesecs+plansecs).replaceAll("\"Summit Custom|Summit Custom|Farmhouse Exterior\"", "")));
			 U.log(proptype);
			 String communitytype=U.getCommType(siteDesc);
			 String startDt=ALLOW_BLANK,endDt=ALLOW_BLANK;
			 String lots[]=U.getValues(info, "\"lotID\":\"", "},\"");
			 U.log(Arrays.toString(lots));
			 if(lots!=null) {
				 units=lots.length+"";
			 }
			 U.log(lots.length);
			//
			//
			// if(url.contains("villa"))proptype=U.getPropType(commName+(html+allHomeData).replaceAll(remData,
			// ""));
			// U.log("proptype :: "+proptype);
			//// if(url.contains("/lee-s-summit/manor-at-stoney-creek"))maxPrice
			// ="$418,515";
			//// if(url.contains("/des-moines-area/norwalk/sunset-estates"))maxPrice
			// ="$451,200";
			// if(url.contains("oak-grove/oaks-of-edgewood"))dtype="1 Story";
			// if(url.contains("village") && commName.contains("Village"))proptype
			// =proptype.replace(", Villas", "");
			// if(url.contains("lee-s-summit/villas-of-parkwood"))dtype="1 Story, Ranch";
			// if(propstatus.contains("Coming 2019, New Phase Coming
			// 2019"))propstatus=propstatus.replace("Coming 2019, New Phase Coming 2019",
			// "New Phase Coming 2019");
			// propstatus=propstatus.replaceAll("Quick Move-in Homes|Quick Move-in|Move-in
			// Ready", "Quick Move-in Homes");
			// if(url.contains("/kansas-city-area/spring-hill/care-free-at-foxwood-ranch"))dtype="Ranch";
			//
			//
			// // ...................adding in csv...............................
			 data.addCommunity(comName, url, communitytype);
			 data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			 data.addLatitudeLongitude(latlong[0],latlong[1], geo);
			 data.addPropertyType(proptype, dtype);
			 data.addPropertyStatus(propstatus);
			 data.addPrice(minPrice, maxPrice);
			 data.addSquareFeet(minSqf, maxSqf);
			 data.addNotes(U.getnote(siteDesc));
			 data.addUnitCount(((units.equals("0"))?ALLOW_BLANK:units));
			 data.addConstructionInformation(startDt, endDt);
			//
			//
		}
		j++;
	}

	public static String getHtmlHeadlessFirefox(String url, WebDriver driver) throws IOException, InterruptedException {

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				BufferedWriter writer = new BufferedWriter(new FileWriter(f));
				driver.get(url);
				U.log("current url :" + url);
				Thread.sleep(10000);
				((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");

				html = driver.getPageSource();
				// U.log("Current Url : "+ driver.getCurrentUrl());
				Thread.sleep(2000);
				writer.append(html);
				writer.close();

			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}

	}// //

	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {

		String totalUnits = ALLOW_BLANK;
		String frameUrl = ALLOW_BLANK;
		String propertyID = ALLOW_BLANK;
		String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;

		if (html.contains("<iframe class=\"platmap-modal-iframe")) {

			String frameSec = U.getSectionValue(html, "<iframe class=\"platmap-modal-iframe", "</iframe>");
			U.log("frameSec: " + frameSec);

			if (frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "ng-src=\"", "\"");
				U.log("frameUrl: " + frameUrl);

				if (frameUrl.contains("/PlatMaps/")) {

					mapData = U.getHtml(frameUrl, driver);

					ArrayList<String> lots = Util.matchAll(mapData, "<path class=\"leaflet-interactive", 0);
					U.log("Lots Count: " + lots.size());
					totalCount = lots.size();
				}

			}

			totalUnits = String.valueOf(totalCount);

		}
		return totalUnits;
	}

}
