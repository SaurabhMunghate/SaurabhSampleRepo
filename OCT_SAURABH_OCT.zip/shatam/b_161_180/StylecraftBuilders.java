package com.shatam.b_161_180;

import java.util.Arrays;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class StylecraftBuilders extends AbstractScrapper {
	private static String builderUrl = "https://www.stylecraft.com/";
	private static String builderName = "Stylecraft Builders";
	private static String fileUrl = U.getCachePath()+"Stylecraft Builders.csv";
	private CommunityLogger LOGGER;
//	WebDriver driver = null;
	public StylecraftBuilders() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public static void main(String ar[]) throws Exception {

		AbstractScrapper a = new StylecraftBuilders();

		a.process();

		FileUtil.writeAllText(fileUrl, a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		//U.setUpGeckoPath();
		//driver=new FirefoxDriver(U.getFirefoxBinary(),U.getFirefoxProfile());
		//driver = new FirefoxDriver(U.getFirefoxCapabilities());

		String html = U.getHTML("https://www.stylecraft.com/new-homes/tx/southern-tx/")+
				U.getHTML("https://www.stylecraft.com/new-homes/tx/central-tx/");
		String[] comSections = U.getValues(html	,"<div class=\"col-md-6 col-lg-4 my-3 my-md-5\">" , "view community</b>");
		U.log(comSections.length);
		for (String comSec : comSections) {
			U.log(comSec);
			String comName = U.getSectionValue(comSec, "<b>", "</b>");
			U.log(">>>>>>>>>>>>>"+comName);
			String comUrl = "https://www.stylecraft.com"+ U.getSectionValue(comSec, "href=\"", "\"");
//			U.log(comUrl);
			if(comUrl.contains("null"))continue;
			findCommunityDetail(comUrl, comName, comSec);
			//break;
		}
		LOGGER.DisposeLogger();
				
	}
	int j = 0;
	private void findCommunityDetail(String communityUrl, String communityName,String comSec) throws Exception {
//		try{
//	if(j >= 39)
	{
		//TODO:
//		if(!communityUrl.contains("https://www.stylecraft.com/new-homes/tx/willis/summerchase/4833/"))return;
		String html = U.getHTML(communityUrl);
		U.log(":::::::::"+j+":::::::::::::");
		U.log("Community Name >>>>>"+communityName);
		U.log("Community Url >>"+communityUrl);
		U.log(U.getCache(communityUrl));
//		U.log(comSec);

		if (data.communityUrlExists(communityUrl))
		{
			LOGGER.AddCommunityUrl(communityUrl+"::::::::::Repeated:::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(communityUrl);

		String add [] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String geocode = "FALSE";
		//----Address------
		String addressSec = U.getSectionValue(html, "Sales Center Location:", "</div>");
//		U.log("addressSec ::"+addressSec);

		if(addressSec != null) { 
			addressSec = addressSec//.replaceAll("</h4>(.*?)</p>", "")
					.replaceAll("<p class=\"tu fs-1-2 m-0 bold\">(.*?)</p>", "").replace("<br>", ",").replace("<br/>", ",").replace("| Model Home NOW OPEN", "")
					.replaceAll("<.*?>", "");
			U.log("addressSec ::"+addressSec);
			add = U.findAddress(U.getNoHtml(addressSec));
		}
		U.log("Address is "+Arrays.toString(add));
		
		latLng = U.getSectionValue(html, "<a class=\"\" href=\"//maps.google.com/maps?q=", "\"").split(",");
		U.log("latLng is "+Arrays.toString(latLng));
		
		
		if(add[0] == null || add[0].length()<3) {
			
			add = U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getGoogleAddressWithKey(latLng);
			geocode = "TRUE";
			U.log("Here Addess: "+Arrays.toString(add));
		}
		
		html = html.replace("$500 Move-In","$500,000 Move-In").replace("$500 total move-in", "$500,000 total move-in");
		//------------Prices-------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		U.log(Util.matchAll(html+comSec, "326,900", 0));
		String prices [] = U.getPrices(comSec+html, "\\$\\d{3},\\d{3} - \\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
		minPrice = (prices[0]==null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
		U.log(minPrice+"\t"+maxPrice);
		//------------SqFt-------------
		
		String remSec=U.getSectionValue(html, "><script src=\"https://static.stylecraft.com/stylecraftbuilders/js/vendor/jquery.panzoom.min.js?v=a21d5a2\">", "</div></div></div></div></div></div></div></section>");
		if(remSec!=null)
			html=html.replace(remSec, "");
		//U.log("<<<<<<<<< "+Util.matchAll(comSec+html , "[\\s\\w\\W]{50}2,583[\\s\\w\\W]{30}",0));

		String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
		String sqFt [] = U.getSqareFeet((comSec+html).replace("small&gt;3,197 SF", ""), "\\d,\\d{3} to more than \\d,\\d{3} square feet|Sq.Ft. Range:</h4>\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} Sq. Ft.|\\d,\\d{3} square foot range| \\d{4} square feet|\\d,\\d{3} SF", 0);
		minSqFt = (sqFt[0]==null) ? ALLOW_BLANK : sqFt[0];
		maxSqFt = (sqFt[1]==null) ? ALLOW_BLANK : sqFt[1];
		U.log(minSqFt+"\t"+maxSqFt);
		
		//----communityType------
		String communityType = U.getCommunityType((html+comSec).replaceAll("irrigated", ""));
		U.log("communityType : "+communityType);
		
		//===Availble Homes and floorplans(22 Jun 19)===
		String allHomesData=ALLOW_BLANK;
		String homSections[] =U.getValues(html, "<div class=\"card-body ", "py-2 mt-3 w-100\">View");
		for(String home:homSections) {
			String homeUrl = U.getSectionValue(home, "href=\"", "\"");
			homeUrl ="https://www.stylecraft.com/"+homeUrl;
			U.log(homeUrl);
			allHomesData += U.getHTML(homeUrl);
			if(allHomesData!=null) {
				allHomesData = allHomesData.replace("such as HOA dues are not included", "").replaceAll("<img alt=\".*?\" src|carriage style side-load", "").replace("luxurious space","luxury homes");
			}
		}
		//=============Quick-move-in
		String quickmhtml=ALLOW_BLANK;
		
		String quickmpart=U.getSectionValue(html, "<section class=\"py-3 py-lg-5 location-detail-specs\" id=\"anchor-2\">", "</section>");
		if(quickmpart!=null) {
		String quickmSection[] =U.getValues(quickmpart, "class=\"col-md-6 col-lg-6 col-xl-4 my-3 my-md-5", "view home");
		for(String quickmSec:quickmSection) {
			String quickmUrl = U.getSectionValue(quickmSec, "<a href=\"/", "\">");
			quickmUrl ="https://www.stylecraft.com/"+quickmUrl;
			U.log(quickmUrl);
			quickmhtml += U.getHTML(quickmUrl);
		}
		}
		//----propertType------

		html = html.replace("experience a magical carriage ride", "Carriage Home").replaceAll("fees such as HOA dues are not", "").replace("Neo-traditional styles ", "Traditional exterior");
		String propertType = U.getPropType((html+comSec+allHomesData).replaceAll("craftsmanship|traditional mudroom|</li><li>HOA</li>|<br/>Single Family</p>|patio door", ""));
		U.log("propertType : "+propertType);
				
		//----derivedType------
		html = html.replaceAll("<img alt=\".*?\" src", "");
		String derivedType = U.getdCommType((html+comSec+allHomesData).replace("without a second story", ""));
		U.log("derivedType : "+derivedType);
		
		//----propertyStatus------
//		html=html.replace("quick-move-ins/\">Quick Move-Ins", "");
		html=html.replace("NEW PHASE OF SUMMERCHASE, COMING SOON", "New phase coming soon")
				.replace("NEW PHASE OF SUMMERCHASE, NOW SELLING", "NEW PHASE NOW SELLING");
		String propertyStatus = U.getPropStatus((html+comSec).replaceAll("elementary school now open on-site|\">Quick Move-Ins|Pecan Lakes Estates Amenities</h2><ul class=\"wysiwyg tw\"><li>100% Financing|\">Coming Soon</span></div>|coming soon to Tomball", ""));
		U.log("propertyStatus : "+propertyStatus);
//		U.log(">>>>>>>>>"+Util.matchAll(html+comSec+allHomesData, "[\\w\\s\\W]{30}Quick move[\\w\\s\\W]{30}", 0));

		if(propertyStatus.contains("New Phase Coming Soon") && propertyStatus.contains(", New Phase"))propertyStatus = propertyStatus.replace("New Phase Coming Soon, New Phase", "New Phase Coming Soon");
		
		/*if(html.contains(" fs-1-2 tc\"><b>view home") && allHomesData!=null && allHomesData.contains("Community:</h4><p class=\"tu fs-1-2\">"+communityName.trim()+"</p>")) {
			if(propertyStatus.length()>1) {
				propertyStatus =propertyStatus+", Quick Movie-in Homes";
			}
			else {
				propertyStatus = "Quick Movie-in Homes";
			}
		}*/
		if(communityUrl.contains("https://www.stylecraft.com/new-homes/tx/huntsville/spring-lake/9070/")) 
		{
			if(propertyStatus.length()>1)
				propertyStatus=propertyStatus+", Coming soon";
			else
				propertyStatus="Coming soon";
			
		}

//		if(communityUrl.contains("https://www.stylecraft.com/new-homes/tx/copperas-cove/heartwood-park/3528/")) {
//			propertyStatus="New Phase Coming";
//		}
		//status from image 24thAug21
		if(communityUrl.contains("/the-ridge-at-belle-meadows/6394/meadows/6394/"))propertyStatus="Coming Soon";
		html = html.replace("NEW PHASE NOW OPEN FOR PRESALE", "NEW PHASE PRESALE");
		String note=U.getnote(html);
		propertyStatus = propertyStatus.replace("Temporarily Sold Out, Sold Out", "Temporarily Sold Out");
		if(note.contains("New Phase Now Open"))propertyStatus= propertyStatus.replace(", New Phase Now Open|New Phase Now Open,", "");
	    add[0]= add[0].replace(" | Model Home NOW OPEN", "").replace("TEMPORARY LOCATED AT: ", "").replace(",", "");
	    String availLotData = Util.matchAll(html, "<div class=\"point", 0).size()==0?ALLOW_BLANK:Util.matchAll(html, "<div class=\"point", 0).size()+"";
	    data.addCommunity(communityName.replace("Porter’s", "Porter's"), communityUrl, communityType);
		data.addAddress(U.getCapitalise(add[0].toLowerCase()), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0], latLng[1], geocode);
		data.addPropertyType(propertType, derivedType);
		data.addPropertyStatus(propertyStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addNotes(note);
		data.addUnitCount(availLotData);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
	j++;
//		}catch(Exception e) {}
	}

	
}