/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_181_200;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRocklynHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractRocklynHomes()
			throws Exception {
		super("Rocklyn Homes","https://www.rocklynhomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Rocklyn Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRocklynHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Rocklyn Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	WebDriver driver=null;
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String mainhtml=U.getHtmlHeadlessFirefox("https://www.rocklynhomes.com/new-homes-available/georgia/atlanta/", driver);
		String reghtml=U.getHtmlHeadlessFirefox("http://rocklynhomes.com/new-homes-available/florida/ft-lauderdale/", driver);
		U.log(U.getCache("http://rocklynhomes.com/new-homes-in/georgia/atlanta/"));
		//String section=U.getSectionValue(mainhtml, "pagetitle\">Communities","id=\"footer_brown\"");
		String[] commSec=U.getValues(mainhtml+reghtml, "comm_list_block mobile-grid","Visit Community");
		U.log("Total Community-->"+commSec.length);
		for(String com:commSec)
		{
			String comUrl=U.getSectionValue(com,"<a href=\"" ,"\"");
			addDetails(comUrl,com);
			//U.log("comUrl-->"+comUrl);
		}
		//String commSection=U.getValues(code, From, To)
			
		driver.quit();
		LOGGER.DisposeLogger();

	}

	private void addDetails(String comUrl, String oldData) throws Exception {
		// TODO : For Single community Execution
//		if(j == 10)
//		try{
		{
//	if(!comUrl.contains("https://www.rocklynhomes.com/new-homes/atlanta-ga/waterford-at-briarcliff/"))return;
				
				U.log("COUNT=="+j+"     "+"commUrl-->"+comUrl);
				String html=U.getHtml(comUrl, driver);
				
					
						//============================================Community name=======================================================================
						String communityName=U.getSectionValue(oldData, "data-name=\"","\"");
						
						U.log("community Name---->"+communityName);
						
				//================================================Address section===================================================================
						String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
						String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
						String geo="FALSE";
						
						String addSec=U.getSectionValue(html, "<div class=\"grid-25 prefix-5\">","</a>");
						
						if(comUrl.contains("ew-homes/decatur-ga/stonemill"))
						addSec="Stone Mill Way, Stone Mountain, GA 30083";
						U.log("AddSec =="+addSec);
					    if(addSec!=null) {
						addSec=addSec.replace("<br>", ",").replaceAll("<p> Way,Stone Mountain, GA 30083", "");
/*					String s=Util.match(addSec, "<h3>(.*?)</h3>",1);
					U.log("s ==>"+s);
					addSec=addSec.replace(s,"");
*/					addSec=addSec.replaceAll("<h3>(.*?)</h3>","");
					    
       U.log(addSec);
      if(U.findAddress(addSec)!=null)
      add=U.findAddress(addSec);
									
						U.log(Arrays.toString(add));
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					    }							
				//--------------------------------------------------latlng----------------------------------------------------------------
						String latSec=U.getSectionValue(html, "google.maps.LatLng(",")");
						if(latSec==null) {
							latSec=U.getSectionValue(addSec,"destination","class=\"primary_bttn\" target=\"_blank\">Get Directions</a>");
						}
						latlag[0]=U.getSectionValue(oldData, "lat=\"", "\"");
						latlag[1]=U.getSectionValue(oldData, "long=\"", "\"");
						if(latlag==null) {
							latlag[0]=U.getSectionValue(latSec, "=", ",");
							latlag[1]=U.getSectionValue(latSec, ",", "\"");
							geo="False";
						}
						
						U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
						if(add[0].length()<4)
						{
							//add=U.getAddressFromLatLonWithKey(latlag);
							add=U.getAddressGoogleApi(latlag);
							if(add == null) add = U.getAddressGoogleApi(latlag);
							geo="true";
						}
						add[0] =add[0].replace(", SW", " SW");
				//============================================plan data=================================================
						
						html = U.removeComments(html);
						String planHtml=ALLOW_BLANK;int i=0;
						//U.log("html"+html);
					//	String planValues[]=U.getValues(html, "<div class=\"plan_inset\">", "PDF");
						String []planValues=U.getValues(html, "<div class=\"plan_inset\">", "Site Plan");
						U.log(">>>>>>>>"+planValues.length);
						if(planValues.length==0)
							planValues=U.getValues(html, "<div class=\"plan_inset\">", "Site Plan");
						for(String plan:planValues){
							if(i>5)break;
							i++;
							planHtml+=U.getHTML(U.getSectionValue(plan, "href=\"", "\""));
						}
				
				//============================================homes data=================================================
						String homeHtml=ALLOW_BLANK;int j=0;
						String homeValues[]=U.getValues(html, "data-status=\"Quick Move-In\"", "View Home"); //data-status="Quick Move-In"
						for(String homeplan:homeValues){
							if(j>5)break;
							j++;
							U.log("https://www.rocklynhomes.com"+U.getSectionValue(homeplan,"href=\"", "\""));
							homeHtml+=U.getHTML( "https://www.rocklynhomes.com"+U.getSectionValue(homeplan,"href=\"", "\""));
						}
						
				//============================================Price and SQ.FT======================================================================
							
						String note=ALLOW_BLANK;
						
						String qmHomeH=U.getHtmlHeadlessFirefox(comUrl+"#homes", driver);
						String fpHomeH=U.getHtmlHeadlessFirefox(comUrl+"#plans", driver);
						
						String feturH=U.getHtmlHeadlessFirefox(comUrl+"#features", driver);
						
						String floorplanHtml=U.getHTML("https://www.rocklynhomes.com/plans");
						String fpHtml="";
						String[] floorplanSec=U.getValues(floorplanHtml, "<div class=\"grid-25 inset_tb plan_post mobile", "View Plan</a></p>");
//						U.log(">>>>>>>>>>>>>>>>>>>>>>>>>"+floorplanSec.length);
						for(String sec :floorplanSec) 
						{
							String url=U.getSectionValue(sec, "<a href=\"", "\">");
							String floorHtml=U.getHTML(url);
							String floorHtmlSec=U.getSectionValue(floorHtml, "<h1 class=\"pagetitle grid-65\">", "Request More Information About This Plan");
							if(floorHtmlSec.contains(communityName))
							{
//								fpHtml=fpHtml+floorHtmlSec;
								fpHtml=fpHtml+U.getSectionValue(floorHtml, "<h1 class=\"pagetitle grid-65\">", "Request More Information About This Plan");
							}
							
						}
//						U.log("fpHtml>>>>>>>>>>>>\n"+fpHtml);
//						U.log(">>>>>>>>>>>>>>>>>>>>>>>>>");
						
						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
						
						oldData = oldData.replaceAll("0�s|0's|0&#8217;s|0’s","0,000").replace("From the Low $300s", "From the $300,000");
						html=html.replaceAll("0�s|0's|0&#8217;s|0’s","0,000");
//						U.log(homeHtml);
						
						if(fpHomeH!=null)
							fpHomeH = fpHomeH.replace("Low $200,000 in Stone Mountain", "");
						if(qmHomeH!=null)
							qmHomeH = qmHomeH.replace("Low $200,000 in Stone Mountain", "");
						if(homeHtml!=null)
							homeHtml = homeHtml.replace("Low $200,000 in Stone Mountain", "");

						html=html.replace("$1.5 - 2 Million", "$15,00,000 - $20,00,000").replace("High $1.5 million to $2 million", "High $1,500,000 million to $2,000,000 million")
								.replace("mid $300s", "Mid $300,000").replace("0s", "0,000");
						
						String prices[] = U.getPrices((html+oldData.replace("0's", "0,000")+fpHtml+qmHomeH+homeHtml).replaceAll("\"description\":\".*\"|content=\".*\"|ata-price=\"From The High \\$200,000 to \\$300,000", "")
								,"\\$\\d{2},\\d{2},\\d{3} - \\$\\d{2},\\d{2},\\d{3}|\\$\\d{1},\\d{3},\\d{3} million|Mid \\$\\d{3},\\d{3}|The High \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Low \\$\\d+,\\d+|From The Mid \\$\\d+,\\d+|anhdprice\">\\$\\d+,\\d+|the Low \\$\\d+,\\d+|Mid \\$\\d+,\\d+|mid \\$\\d+,\\d+| high \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|- \\$\\d{3},\\d{3}</h3>| <h1 align=\"center\">\\$\\d{3},\\d{3}</h1>", 0);
						
						minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
						maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
						
						U.log("Price--->"+minPrice+" "+maxPrice);
//					
				//======================================================Sq.ft===========================================================================================		
						
//						if(html.contains("<h2 class=\"comm_addtomenu hide-on-mobile\" data-linkto=\"homes\"><span>Available Homes</span></h2>"))
//							html = html.replaceAll("</i>\\d+ sqft</div>", "");
						
						String[] pendingHome=U.getValues(html, "Pending</h3>","<div class=\"plan_inset anhd_home_info grid-100 mobile-grid-100\">");
                        U.log("XX"+pendingHome.length);
						for(String pending:pendingHome) {
							html=html.replace(pending, "");
						}
						html=html.replaceAll("1685 sqft</div>", "");
						fpHomeH=fpHomeH.replaceAll("</i>\\d{4} sqft</div>|1685 sqft</div>", "");
						qmHomeH=qmHomeH
								.replaceAll("</i>\\d{4} sqft</div>|1685 sqft</div>", "");
						
						U.log("<<<<<<<<< "+Util.matchAll((html+oldData), "[\\s\\w\\W]{50}1,900[\\s\\w\\W]{30}",0));
						U.log("<<<<<<<<< "+Util.matchAll((html+oldData)+fpHtml+qmHomeH, "[\\s\\w\\W]{50}190[\\s\\w\\W]{30}",0));
						U.log("<<<<<<<<< "+Util.matchAll((html+oldData)+fpHtml+qmHomeH, "[\\s\\w\\W]{50}190[\\s\\w\\W]{30}",0));

						String[] sqft = U
								.getSqareFeet(
										((html+oldData)+fpHtml+qmHomeH).replace("Approximately 1900,000qft", ""),
										"\\d{4} – \\d{4} feet approx.|\\d,\\d{3} to \\d,\\d{3} square feet approx.|\\d{4} to \\d{4} feet approx|SqFt</strong><br />\\d,\\d+|\\d{4}- \\d{4} square feet|Sq.Ft.: \\d+,\\d+|\\d+,\\d+ sq. ft.|Sq.Ft.: \\d{4}|\\d+,\\d+ square feet|SF: </strong>\\d,\\d{3}|approximately \\d+,\\d+|Approx. SF: </strong>\\d{4}</p>|\\d{4} sqft",
										0);
						
						//U.log(Util.matchAll((html+oldData)+fpHomeH+qmHomeH, "[\\w\\s\\W]{30}1539[\\w\\s\\W]{30}",0));
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						if(comUrl.contains("https://www.rocklynhomes.com/new-homes/stonecrest/princeton-ridge/"))
						 maxSqft="1539";
							
							U.log("SQ.FT--->"+minSqft+" "+maxSqft);
						
				//================================================community type========================================================
						html=html.replace("Waterfront Homes", "waterfront Community");
						U.log("JJJ"+Util.match(html, "waterfront homes"));
						String communityType=U.getCommType((html+oldData+feturH).replaceAll("Gated Community with Pool|Public Golf Courses", ""));
						
				//==========================================================Property Type================================================
						oldData = oldData.replace("Luxury", "Luxury homes");
						html=html.replace("Comes With 1 Year Hoa Paid By Seller", "").replace("<li>Loft*</li>", "loft level");
						if(homeHtml != null) homeHtml = homeHtml.replace("ENJOY LUXURY", " enjoy luxury homes");
						
						html=html.replace("New Townhome Community from The Mid $200,000", "").replace("townes-of-auburn/\">Townes of Auburn", "");
//						U.log("ll"+Util.match((html),"townhome"));
//						U.log(Util.matchAll(html, "[\\w\\s\\W]{40}townhome[\\w\\s\\W]{40}", 0));
						
						String proptype=U.getPropType((html+oldData+feturH+fpHomeH+homeHtml));//.replaceAll("strong>Type: </strong>2 Story Townhome</p>|Comes With 1 Year Hoa Paid By Seller|Costs/Hoa Dues/", ""));
						if(comUrl.contains("https://www.rocklynhomes.com/new-homes/winder-ga/cannon-trace/"))
							proptype=proptype.replace(", Townhome", "");
				//==================================================D-Property Type======================================================
						html = html.replace("First Level And Stairs", " 1 story ");
						html = html.replaceAll("Stories: </strong>", "Stories ");
						fpHomeH=fpHomeH.replaceAll("Stories: </strong> ", "Stories ");
						planHtml=planHtml.replaceAll("Stories: </strong> ", "Stories ");
						String dtype=U.getdCommType((html+feturH+fpHomeH+planHtml).replaceAll("FLOOR|CS_\\dStory|Stories:|floor|Floor", ""));
//						
				//==============================================Property Status=========================================================
						html = html.replace("content=\"Heritage Corners is coming soon", "");
						html = html//.replace("PHASE IV – COMING APRIL 2021", "PHASE IV COMING APRIL 2021")
								.replace("PHASE III – Final Opportunities", "PHASE III Final Opportunities")//.replace("PHASE IV &#8211; COMING APRIL 2021", "PHASE IV COMING APRIL 2021").
								.replaceAll("/coming-soon/|Coming Soon Communities|>Coming Soon</a>|<meta content=\"Discover the new townhomes available|New Phase Now Selling</p>", "");
						
						oldData = oldData.replaceAll("(Winter|Fall) 2020", "");
					//	
						String pstatus=ALLOW_BLANK;
						pstatus = U.getPropStatus(oldData+html//.replace("Coming 1st Quarter 2022", "Coming 2022")
								.replace("PHASE IV – COMING Fall 2021", "Phase IV Coming Fall 2021").
								replaceAll("\".*\"|(Winter|Fall) 2020|Townhomes SOLD OUT|Family SOLD OUT|Coming Soon!\"|Coming Soon</a>|Summer Savings & Move|LAST OF 5 HOMES AVAILABLE IN COMMUNITY|MOVE-IN READY IN JULY|Information Coming Soon|/coming-soon/\">Coming Soon|Summer Savings &amp; Move|Community From the \\$200,000 Coming Soon|Coming Soon!<br>|\\$200&#8217;s Coming Soo|<p>Coming Soon!</p>|Y BEDROOMS. MOVE-IN READY HOME - HOME FOR THE HOLIDAYS - PI|data-status=\"Quick Move-In|Dock \\(limited opportunity\\)|Only 33 Lots Available!|Only 33 Left To Sell|Only 36 Lots Available.|Quick Move-In Homes|New Coming Soon CommunityFrom|.  Move-In Ready,",""));
						 U.log(Util.matchAll(oldData+html, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));
					
						if(!pstatus.contains("Quick") && qmHomeH.contains("<div class=\"anhdhome\">"))
						{
							if(pstatus.length()>4){
								pstatus = pstatus + ", Quick Move-In Homes";
							}
							else{
								pstatus = "Quick Move-In Homes";
							}
						}
						if(pstatus.contains("Move-in Ready")){
							pstatus=pstatus.replaceAll("Move-in Ready,", "");
						}
						
						if(proptype.contains("Townhome") && proptype.contains("Townhouse")) {
							
							proptype = proptype.replaceAll("Townhouse,|, Townhouse|Townhouse", "");
						}
						if(pstatus.contains("Coming Soon, Coming Soon 2nd Quarter 2022"))
							pstatus="Coming Soon 2nd Quarter 2022";
				//============================================note====================================================================
						
						 note=U.getnote((html+oldData).replaceAll("Pre-sale opportunities for Phase|and Pre-sale opportunities</h4>|New Townhome Community Now PreSelling|information on pre-sale|Pre-sale opportunities.</h4>", ""));

						 
						if(comUrl.contains("https://www.rocklynhomes.com/new-homes/atlanta-ga/south-wind"))dtype+=", 2 Story";
                        if(comUrl.contains("https://www.rocklynhomes.com/new-homes/stonecrest/princeton-ridge/"))maxSqft=ALLOW_BLANK;
						//						if(comUrl.contains("new-homes/conyers/ellis-pointe/"))maxPrice =ALLOW_BLANK;
						
/*						if(comUrl.contains("https://www.rocklynhomes.com/new-homes/lithonia-ga/princeton-ridge"))
							pstatus=pstatus.replace("Coming Soon, Coming Fall 2020,", "");
*//*						pstatus =pstatus.replace("Coming Soon Winter 2021, Coming Soon", "Coming Soon Winter 2021");
						if(comUrl.contains("https://www.rocklynhomes.com/new-homes/redan/beverly-heights"))
							pstatus="Coming spring 2021";
						
						if(comUrl.contains("https://www.rocklynhomes.com/new-homes/decatur-ga/stonemill/"))
							minPrice = ALLOW_BLANK;
*/						
						if(data.communityUrlExists(comUrl))
							{
							LOGGER.AddCommunityUrl(comUrl+"*************repeated************");
							k++;
							return;
							}
						pstatus = pstatus.replace("Coming Fall 2021, Phase IV Coming Fall 2021", "Phase IV Coming Fall 2021");
						//if(comUrl.contains("https://www.rocklynhomes.com/new-homes/atlanta-ga/cascades/"))pstatus+=", Sold Out";
						
							LOGGER.AddCommunityUrl(comUrl);
							data.addCommunity(communityName,comUrl, communityType);
							data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0].replace("HWY NW", "Hwy Nw").replace(",", ""), add[1], add[2], add[3]);
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(proptype, dtype);
							data.addPropertyStatus(pstatus.replace("Iv", "IV").replace("Ii", "II").replace("IIi", "III"));
							data.addNotes(note);
							data.addUnitCount(ALLOW_BLANK);
							data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
						j++;
						
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
				
	}

}
