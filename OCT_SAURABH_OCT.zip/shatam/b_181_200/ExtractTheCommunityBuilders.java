/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_181_200;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTheCommunityBuilders extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;

	public ExtractTheCommunityBuilders() throws Exception {
		super("The Community Builders", "https://www.tcbinc.org/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("The Community Builders");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractTheCommunityBuilders();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "The Community Builders.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}

	WebDriver driver = null;

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		//Find A Home Section
		String html = "";
		for(int i = 1; i <= 4; i++){
			String url = "https://www.tcbcommunities.com/searchlisting.aspx?ftst=&LocationGeoId=0&zoom=10&renewpg=1&PgNo="+i+"&";
			U.log(url);
			html = html + U.getHTML(url);
		}
		
		String[] comSections = U.getValues(html, "<div itemscope=\"\" itemtype", "Neighborhood</a></li>");
		U.log("ComCount ::"+comSections.length);
		int urlDoesNotHave = 0;
		for(String comSec : comSections){
			String urlSection = U.getSectionValue(comSec, "aria-label=\"Property Details\"", "class=");
//			U.log("urlSection ::"+urlSection);
			String comUrl = U.getSectionValue(urlSection, "<a href='", "'");
			U.log("comUrl ::"+comUrl);
			if(comUrl == null){
				urlDoesNotHave++;
				LOGGER.AddCommunityUrl("---- NO Community Url Found -----------");
				continue;
			}else{
				comUrl = comUrl.replace("http:", "https:");
//				 U.log("url1 : "+comUrl);
				addCommunity(comUrl, comSec);//MMMMMMMM
			}
		}
		// Communities Section
//		String mainHtml = U.getHTML("https://www.tcbinc.org/where-we-work/properties.html");//https://www.tcbinc.org/communities.html
		
		String mainHtml = U.getPageSource("https://tcbinc.org/where-we-work/properties/");
		String cTypeSec = U.getSectionValue(mainHtml, "<section id=\"accordionsort\">", "</section>");
//		U.log(">>>>>>>>>>"+cTypeSec);
		String[] cTypeValues = U.getValues(cTypeSec, "<div class=\"accordion-title\">", "</ul>");
		U.log("totalType-->" + cTypeValues.length);

		
		U.setUpChromePath(); 
		driver = new ChromeDriver(); //capabilities
		
		
		for (String value : cTypeValues) {
			//U.log(value);
				
//			U.log(value);
//			String valueHtml = U.getHTML(value);
//			String valueSec = U.getSectionValue(valueHtml, "<div class=\"accordion-title\">", "</section>");
//			//U.log(valueSec.length());
//			if(valueSec==null)valueSec = ALLOW_BLANK;
//			
//			String[] url = U.getValues(valueSec, "<a href=\"https:", "\"");
//			//U.log("count-->" + url.length);
//			for (String url1 : url) {
			
			if(!value.contains("View Website</a>")) {
				
				LOGGER.AddCommunityUrl("---- NO Community Url Found -----------");
				continue;
			}
			
			
		String	url1 = U.getSectionValue(U.getSectionValue(value, "<strong>Asset Link</strong>", "View Website</a>"),"<a href=\"","\"");
				if (!url1.contains("http")) 
					url1 = "https:" + url1;

				url1 = url1.replace("http:", "https:");
//				 U.log("url2 : "+url1);
				 if(url1.contains("https://www.theloftsatnodamills.com"))
					 url1="https://www.theloftsatnodamills.com/";
				addDetail(url1, driver);//mm
//			}
		}
		LOGGER.DisposeLogger();
		
		
		try{driver.close();
			driver.quit();
		}catch(Exception e){}
		U.log("Url is missing for community count ::"+urlDoesNotHave);
	}
	
	

	String checkComName = "";

	private void addCommunity(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub

//		if (j >= 70 && j<= 100) 
	//	if(j== 45)
		
//		try{
//		 if(!comUrl.contains("centralgrammarapartments")) return;
		{
			U.log("===============addCommunity===================");
//	        if(!comUrl.contains("https://www.fairlawnmarshallapartments.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))return;

			U.log(j + "\tcommUrl-->" + comUrl);

			if (comUrl == null) {
				return;
			}
			//https://www.lakestreetterrace.com?rcstdid=MzI%3d-GJOvflXLv8M%3d

//        if(!comUrl.contains("https://www.fairlawnmarshallapartments.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))return;
			
			if(comUrl.contains("oakwoodshores"))comUrl="http://www.oakwoodshores.com";
			if(comUrl.contains("https://villagesatmillcrossing.aptdemo.com/"))return;
			if(comUrl.contains("https://www.fairlawnmarshallapartments.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))comUrl="http://www.fairlawnmarshallapartments.com?rcstdid=MzI%3d-GJOvflXLv8M%3d";
			
			if(comUrl.contains("https://www.theshopsandlofts.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))comUrl="http://www.theshopsandlofts.com?rcstdid=MzI%3d-GJOvflXLv8M%3d";
			
			if(comUrl.contains("https://www.franklinschoolapts.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))comUrl="http://www.franklinschoolapts.com?rcstdid=MzI%3d-GJOvflXLv8M%3d";
			
			if(comUrl.contains("https://www.fruitseverapts.com")) {
				LOGGER.AddCommunityUrl("-------Not Open-------------"+comUrl);
				return; //not open
			}
			
			if(comUrl.contains("https://eastlibertyplace.com"))comUrl="https://www.eastlibertyplace.com"; //not open
			

			if (comUrl.contains("https://cornerstoneon50.com/")) {
				comUrl = comUrl.replace("https:", "http:");
			}
//			
//	if(!comUrl.contains("https://www.residencesatavondale.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))return;//Single Run

			 
			 
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "---------repeated---------------");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			U.log(U.getCache(comUrl));
			String html = U.getPageSource(comUrl);
//			 U.log("&&&&&&&&&&&&&&&&&"+html);

			// U.log(comData);
			// ============================================Community
			// name=======================================================================
			// String communityName=U.getSectionValue(html, "SID_PropertyName\">","</h1>");
			String communityName = U.getSectionValue(comData, "class=\"propertyName\">", "<");
			U.log("community Name---->2" + communityName);
			communityName=communityName.replace("-", " ");
			checkComName = checkComName + " , " + communityName.toLowerCase();
			communityName = communityName.replaceAll("Apartments|Townhomes|Welcome to |-| \\|", "");
			communityName = communityName.replace("*", "");
			U.log("community Name---->3" + communityName);
            U.bypassCertificate();
			// ================================================Address
			// section===================================================================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(comData, "class=\"prop-address\">", "div>");
			if (addSec != null) {
				add[0] = U.getSectionValue(addSec, "propertyAddress\">", "<");
				add[1] = U.getSectionValue(addSec, "propertyCity\">", "<");
				add[2] = U.getSectionValue(addSec, "propertyState\">", "<");
				add[3] = U.getSectionValue(addSec, "propertyZipCode\">", "<");
			}
			if (add[0] == null) {
				add[0] = U.getSectionValue(html, "address-street\">", "<");
				add[1] = U.getSectionValue(html, "address-city\">", "<");
				add[2] = U.getSectionValue(html, "address-state\">", "<");
				add[3] = U.getSectionValue(html, "address-zip\">", "<");
			}
			U.log("Address---->" + add[0] + " gg " + add[1] + " gg " + add[2] + " gg " + add[3]);
			add[0] = add[0].replaceAll(" \\(Basement\\)|,", "").replaceAll("River Run Condominiums c/o Hilltop Apartments 51 V", "");
			add[1] = add[1].replace(",", "");
			
			
			// --------------------------------------------------latlng----------------------------------------------------------------
			
			String mapurl=comUrl.replace("/index.aspx", "").replace("?rcstdid=MzI%3d-GJOvflXLv8M%3d", "")+"/"+"mapsanddirections.aspx";
			U.log("mapurl======== "+mapurl);
			mapurl=mapurl.replace("http:", "https:");
			String mapHtml=U.getPageSource(mapurl);
			U.log("mapurl :::"+U.getCache(mapurl));
//			U.log("mapurl======== "+mapHtml.length());
//			String latSec = U.getSectionValue(html, "google.maps.LatLng(", ")");
			String latSec = U.getSectionValue(mapHtml, "<button  data-selenium-id='mapdirBirdsView", "\">");
//			U.log("latSec====="+mapHtml);
			if (comData.contains("itemprop=\"latitude\">")) {
				U.log("Hello");
				latlag[0] = U.getSectionValue(comData, "latitude\">", "<");
				latlag[1] = U.getSectionValue(comData, "longitude\">", "<");

			}
			U.log("hhhh1--->" + latlag[0] + "  " + latlag[1]);
			if (latlag[0].length() < 4 || latlag[0].equals("-")) {
				latlag[0] = U.getSectionValue(mapHtml, "var latitude = \"", "\"");
				latlag[1] = U.getSectionValue(mapHtml, "var longitude = \"", "\"");
			}
			U.log("hhhh2--->" + latlag[0] + "  " + latlag[1]);
			
			if (latlag[0]==null|| latlag[0].equals("-")) {
				latlag[0] = U.getSectionValue(latSec, "lat=", "&");
				latlag[1] = U.getSectionValue(latSec, "lng=", "')");
			}
			U.log("hhhh4--->" + latlag[0] + "  " + latlag[1]);
			
			if (latlag[0] == null || latlag[0].length() < 4) {
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			U.log(latlag[0] + "::::" + latlag[0].length());
			U.log("hhhh3--->" + latlag[0] + "  " + latlag[1]);
			
			

			if (latlag[0].contains("0.0000")) {
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				geo = "True";
			}
			
			if (add[0] == null || add[0].length() < 4) {
				add = U.getAddressGoogleApi(latlag);
				if(add == null) add = U.getAddressHereApi(latlag);
				geo = "TRUE";
			}
			// ================Navigation Bar Urls===================

			// ============================================Price and
			// SQ.FT======================================================================

			String note = ALLOW_BLANK;

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			U.log("html ::"+html);
			html = html.replaceAll("0�s|0's|0&#8217;s", "0,000");
			String prices[] = U.getPrices(html, "anhdprice\">\\$\\d+,\\d+|the Mid \\$\\d+,\\d+", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("My price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================

			String FloorData = "";
			String chnage = Util.match(comUrl, "\\.com\\?[\\s\\w\\W]{0,}");
			if(chnage == null)
				chnage = Util.match(comUrl, "\\.com\\[\\s\\w\\W]{0,}");
//			U.log(chnage);
			if(chnage != null) {
				String floorUrl = comUrl.replace(chnage, ".com/floorplans.aspx");
			U.log("<<<<<<<<<<<<<<<<<<<"+floorUrl);
			FloorData += U.getPageSource(floorUrl);
			
			U.log("FloorData :::"+U.getCache(floorUrl));
			}
			
			FloorData=FloorData.replace("SQ. FT.\">\\s*(\\d{3}) -\\s*<span class=\"sr-only\">\\s*to\\s*</span>\\s*(\\d{3})\\s*<span class=\"sr-only\">\\s*Square Foot", "SQ. FT.$1 to $2");
			String floorurl=comUrl.replace("index.aspx", "floorplans.aspx");
			String floorhtml =U.getPageSource(floorurl);
			
			 U.log(">>>>>>>"+floorurl);
			String[] sqft = U.getSqareFeet(html + comData + FloorData+floorhtml,
					"</span> \\d,\\d+<span class=\"sr-only\">Square Foot|\\d*,\\d{3}\\s*</td>\\s*</tr>|\\d*,\\d{3}\\s*<span class=\"sr-only\">|Sqft_\\d\">\\s*\\d,\\d{3}|Sqft_\\d\">\\s*\\d{3}|label=\"SQ. FT.\">\\s*\\d{3}|\"Sqft_7\">\\d{1},\\d{3}</td>|SQ. FT.\">\\d,\\d+ -<span class='sr-only'>to</span> \\d,\\d+<span class=\"sr-only\">Square feet|SQ. FT.\">\\d+<span class=\"sr-only\">Square feet|SQ. FT.\">\\d+ -<span class='sr-only'>to</span> \\d,\\d+<span class=\"sr-only\">Square feet|SQ. FT.\">\\d{3} -<span class='sr-only'>to</span> \\d,\\d{3}|detail-floorplan-sqft\">\\d+</i>|Sqft_\">\\d+ -<span class=\"sr-only\">to</span> \\d+</td>|SQ. FT.\">\\d+ -<span class='sr-only'>to</span> \\d+|\\d{3,4} -<span class='sr-only'>to</span> \\d{3,4}|Sqft_\">\\d+ -<span class='sr-only'>to</span> \\d+</td>|LVSQFTs\">\\d{3,4}|\\{3,4} sq.ft|Sqft_5\">\\d{3,4}|footage\">\\d{3}-\\d{3}</td>|Sqft_\">\\d+</td>|SQ. FT.\">\\d+<span|>\\d{3,4}</td>",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
			
//			U.log("mmm: "+Util.match(html + comData + FloorData+floorhtml, "[\\w\\s\\W]{30}1,487[\\w\\s\\W]{40}"));

			// ================================================community
			// type========================================================
			html=html.replaceAll("those age 62 and older|a community for residents 62 years |those 62 and better|residents 62 years of age and older| aged 62 and older|aged 62 and better| are 62 years of age and older", " 62 years of age and older ");
			String communityType = U.getCommType(html.replace("&nbsp;", " ")
					.replaceAll("those 62 and better| aged 62 and older|aged 62 and better", "62 years and older")+ comData);
//			U.log("mmm: "+Util.match(html , "[\\w\\s\\W]{30}62 years[\\w\\s\\W]{40}"));

			U.log("communityType: "+communityType);
			// ==========================================================Property
			// Type================================================
			String amenities = "";
			if(comUrl.contains("https://www.tcbcommunities.com/apartments/pa/coatesville/downtown-revival-apartments"))
			 amenities = U.getHTML("https://www.tcbcommunities.com/apartments/pa/coatesville/downtown-revival-apartments/amenities.aspx");
			
			
			html = html.replaceAll("ApartmentComplex|Residences at , , apartment listings|Apartment Section Ends|Header\">apartment search</div>|Apartment Section Starts|The Beacon Center, apartments, rentals, apartment guide|Apartments in Washington", "")
					.replaceAll("River+Run+Condominiums+c/o+Hilltop+Apartments+51+V+|apartment finder, apartment search, apartment locator, apartments for rent|River+Run+Condominiums+c/o+Hilltop+Apartments+51+V++Northampton|River Run Condominiums c/o Hilltop Apartments 51|Apartments in Northampton|Northampton 811, apartments, rentals, apartment guide", "")
					.replaceAll("luxuriously comfortable apartments|luxurious, apartment living", "luxury homes, apartment living")
					.replaceAll("convenience and luxury|option for luxurious", "option for luxury homes");
			
			comData=comData.replace("id=\"apartment4\">Apartment</li>", "");
			
			
			String proptype = U.getPropType((html + comData +amenities).replaceAll("traditional and local vernacular|apartment4\">Apartment|River+Run+Condominiums|Hilltop Apartments|Hilltop+Apartments|River+Run+Condominiums|Apartments in Northampton|River Run Condominiums|WestVillageCondoAssociation|(V|v)illage", ""));
			proptype = proptype.replace("Apartment Homes,Townhouse,Patio Homes,Townhome",
					"Apartment Homes,Patio Homes,Townhome");
			
			if (proptype.contains("Townhouse") && proptype.contains("Townhome"))
				proptype = proptype.replaceAll("Townhouse,|, Townhouse", "");
//			U.log("mmmmmm"+Util.matchAll(html  , "[\\w\\s\\W]{60}Apartment[\\w\\s\\W]{30}", 0));
			
//			if(comUrl.contains("https://www.beaconcenterresidences.com?rcstdid=MzI%3d-GJOvflXLv8M%3d")) {
//				if(proptype==ALLOW_BLANK)
//					proptype ="Apartment Homes";
//			}
			if(comUrl.contains("victorygardensapartments.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))
				proptype+=", Garden Home";
			
//				U.log("mmm: "+Util.match(html, "[\\w\\s\\W]{30}Now leasing our newest phase[\\w\\s\\W]{30}"));

			U.log("propType: "+proptype);
			// ==================================================D-Property
			// Type======================================================
//			html = html.replace(" 3rd Floor ", "3 story").replace("1st and 2nd Floors", " 1 Story  2 Story ");
			String dtype = U.getdCommType(html.replaceAll("level living|2nd Floor &ndash; Housing Assistance Offic|Evans - 2nd Floor|the 1st and 2nd Floor", "") + comData);

			// ==============================================Property
			// Status=========================================================
			String pstatus = U.getPropStatus((html).replaceAll(
					"Coming soon to The Ridgeway Communities is the newest development phase|Alert| re-opening soon|Parking \\(Limited Availability|Only one home left! Contact us for deta|1 home left! Heat and|=\"Limited availability.\"|>Last home left! 566 S|Floor Plans Coming Soon|community! Details coming soon.</div|Spring 2017 and opening 2018|WAIT LIST IS NOW OPEN|Center - Coming Soon|Details Coming Soon|Coming Summer 2018|homes available at|(label|title)=\"Limited|list is now",
					"") + comData);
			U.log("propStatus: "+pstatus);
			// ============================================note====================================================================

			
			note = U.getnote(html);
			U.log("Note: "+note);

			if(comUrl.contains("https://www.tcbcommunities.com/apartments/ny/yonkers/the-ridgeway/index.aspx")) 
				communityName = "The Villas At The Ridgeway";

			if(comUrl.contains("https://www.thesouthendapartments.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))
				proptype+=", Luxury Homes";
			if(comUrl.contains("new-brunswick/lord-stirling-apartments/default.aspx")|| comUrl.contains("/apartments/ma/charlestown/building-1040/index.aspx"))communityType="62+ Community";
			if(comUrl.contains("https://www.tcbcommunities.com/apartments/ma/stow/pilot-grove-hill-apartments"))maxSqft="1206";
			
			comUrl = comUrl.replace("http:", "https:");
		//	if(comUrl.contains("https://www.lymanterrace.com?rcstdid=MzI%3d-GJOvflXLv8M%3d"))note="Now Leasing";
			if(comUrl.contains("https://www.olmstedapartments.com/"))communityType="62+ Community";
			
			if(comUrl.contains("www.liveincoatesville.com")) {
				minSqft="950";
				maxSqft="1010";
			}
			if(comUrl.contains("northampton/northampton-811/index.aspx"))
			{
				proptype=ALLOW_BLANK;
			}
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("&nbsp;", ""), add[1], add[2].trim(), add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt,endDt);
		}
		j++;
		
	//	}catch (Exception e) {}
	}

	private void addDetail(String comUrl, WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
//	if(j== 45)
		
// if(!comUrl.contains("https://www.thesouthendapartments.com/?rcstdid=MzI%3d-GJOvflXLv8M%3d")) return;
//		try	{
		//https://www.residencesatavondale.com?rcstdid=MzI%3d-GJOvflXLv8M%3d
 U.log("===============addDetail===================");
		U.log(U.getCache(comUrl));
		U.log(j + "\tcommUrl-->" + comUrl);
		if(comUrl.contains("oakwoodshores"))comUrl="http://www.oakwoodshores.com";

//		if (comUrl.contains("https://www.lincolnwoodsapt.com/")) // redirecting on Rentcafe
//		{
//			return;
//		}
		if(comUrl.contains("https://www.eastlibertyplace.com/")) return; //403 error
		if (comUrl.contains("https://www.pedestalgardens.com/")) return;
		if(comUrl.contains("https://villagesatmillcrossing.aptdemo.com/"))return;
		if(comUrl.contains("https://www.stillwaterheightsapts.com/")) return;
		if(comUrl.contains("https://www.matthewsmemorialterrace.com")) return;
		if(comUrl.contains("https:/www.morninggloryapts.com")) return; //August21
//		if (comUrl.contains("https://www.broadcreekapartments.com/"))return;
		if (comUrl.contains("https://www.willardsquareapts.com/")) return; // 400 error
		if (comUrl.contains("https://www.citywestohio.com/")||comUrl.contains("https://www.citywestohio.com/"))	return; //400 Error

		if (comUrl.contains("https://cornerstoneon50.com/")||comUrl.contains("https://www.eastlibertyplace.com/")) {
			comUrl = comUrl.replace("https:", "http:");
		}
		if (comUrl.contains("http://www.theloftsatnodamills.com")) {
			comUrl = "https://www.theloftsatnodamills.com";
		}
		if(comUrl.contains("https://www.ormontcourt.com/")) comUrl = comUrl.replace("https:", "http:");
		if (comUrl.contains("http://cornerstoneon50.com/")) {
			comUrl="http://www.cornerstoneon50.com/";
		}
		
		
		if (comUrl.contains("https://www.liveincoatesville.com/")) {
			LOGGER.AddCommunityUrl(comUrl + "---------Redirected---------------" + comUrl);
			k++;
			return;
		}
		if (comUrl.contains("https://www.morninggloryapts.com")) {
			LOGGER.AddCommunityUrl(comUrl + "---------Redirected---------------" + comUrl);
			k++;
			return;
		}
		if (comUrl.contains("https://www.meyersridgetownhomes.com/")) {
			LOGGER.AddCommunityUrl(comUrl + "---------Not Open---------------" + comUrl);
			k++;
			return;
		}
		
		//----- Single Run ------------------------------------------
//		 if(!comUrl.contains("http://www.cornerstoneon50.com/"))return;
		// error
		// String html=U.getHtmlHeadlessFirefox(comUrl, driver);
		
		
		// String html=U.getHtml(comUrl, driver);
		String html = getHtml(comUrl,driver);
		// U.log(html);
		/*
		 * String rem=U.getSectionValue(html, "project_next one columns\">","</body>");
		 * html=html.replace(rem,"");
		 */
		// ============================================Community
		// name=======================================================================
		// String communityName=U.getSectionValue(html, "SID_PropertyName\">","</h1>");
		String communityName = ALLOW_BLANK;

		communityName = U.getSectionValue(html, "<title>", "Apartment");
		U.log("community Name---->4" + communityName);
		if (communityName == null || communityName.length() < 4) {
			communityName = U.getSectionValue(html, "SID_PropertyName\">", "</h1>");
			U.log("hello");
		}
		if (communityName == null || communityName.length() < 4) {
			communityName = U.getSectionValue(html, "name=\"author\" content=\"", "\"");
		}
		
		if(comUrl.contains("https://www.backofthehillapartments.com/"))
			communityName="The Hill Apartments";
		if(comUrl.contains("https://www.pointesatdowntown.com/"))
			communityName="The Pointes";
		communityName=communityName.replaceAll("-", " ");
		communityName = communityName.trim().replaceAll("Apartments$|Townhomes|Welcome to |-| \\|", "");

		U.log("community Name---->1" + communityName);

		if (checkComName.contains(communityName.toLowerCase().trim())) {
			LOGGER.AddCommunityUrl(comUrl + "---------repeated---------------" + communityName);
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		// ================Navigation Bar Urls===================
		String floorHomeH = ALLOW_BLANK;
		// U.getHtml(comUrl+"floorplans.aspx", driver);
		String animitHomeH = ALLOW_BLANK;
		String mapHtml = ALLOW_BLANK;
		// U.getHtml(comUrl+"amenities.aspx", driver);
		String navSec = U.getSectionValue(html, "<nav", " </nav>");
		if (navSec==null) {
			navSec = U.getSectionValue(html, "<ul class=\"menuitemcontainer nav\">", "</ul>");
		}
		// U.log("navSec:::"+navSec);
		if (navSec != null) {
		String[] navUrls = U.getValues(navSec, "href=\"", "\"");
			for (String myNavUrl : navUrls) {
				U.log("myNavUrl::::" + myNavUrl);
					if (!comUrl.contains("com/")) {
						comUrl = comUrl + "/";
					}
					if (myNavUrl.contains("floorplan")) {
						String florUrl = myNavUrl;
						if (!myNavUrl.contains("http"))
							florUrl = comUrl + myNavUrl;
							florUrl = florUrl.replace("index.aspx?nocache=1", "");
							U.log("florUrl::" + florUrl);
							floorHomeH = U.getHtml(florUrl.replace(".com//", ".com/"),driver) + floorHomeH;
					}
					
					if (myNavUrl.contains("amenities")) {
							String amenUrl = comUrl + myNavUrl;
							amenUrl = amenUrl.replace("index.aspx?nocache=1", "");
							U.log("amenUrl::" + amenUrl);
							animitHomeH = U.getHTML(amenUrl);
					}
					if (myNavUrl.contains("mapsanddirections")) {
						String mapUrl = comUrl + myNavUrl;
						mapUrl = mapUrl.replace("index.aspx?nocache=1", "");
						U.log("mapUrl::" + mapUrl);
						mapHtml = U.getHTML(mapUrl);
				}
			}
		}
		if (comUrl.contains("https://www.broadcreekapartments.com/")) {
			String	florUrl = "https://www.broadcreekapartments.com/Floor-plans.aspx";
				florUrl = florUrl.replace("index.aspx?nocache=1", "");
				U.log("florUrl::" + florUrl);
				floorHomeH = U.getHtml(florUrl.replace(".com//", ".com/"),driver) + floorHomeH;
		}
		// ================================================Address
		// section===================================================================
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";

		add[0] = U.getSectionValue(html, "streetAddress\": \"", "\"");
		if (add[0] == null) add[0] = U.getSectionValue(html,"streetAddress\":\"", "\"");
		if (add[0] == null) add[0] = U.getSectionValue(html,"streetAddress\">", "<");
		
		if (add[0] == null) {
			add[0] = U.getSectionValue(html, "address-street\">", "<");
			if (html.contains("api-address\">")) {
				add[0] = U.getSectionValue(html, "api-address\">", "<");
			}
			if (add[0] == null) {
				add[0] = ALLOW_BLANK;
			}
		}
		add[1] = U.getSectionValue(html, "addressLocality\": \"", "\"");
		add[2] = U.getSectionValue(html, "addressRegion\": \"", "\"");
		add[3] = U.getSectionValue(html, "postalCode\" : \"", "\"");
		if(add[3]==null) {
			add[3] = U.getSectionValue(html, "\"postalCode\": \"", "\"");
		}
		
		if (add[1] == null) add[1] = U.getSectionValue(html, "addressLocality\":\"", "\"");
		if (add[2] == null) add[2] = U.getSectionValue(html, "addressRegion\":\"", "\"");
		if (add[3] == null) add[3] = U.getSectionValue(html, "postalCode\":\"", "\"");
		
		if (add[1] == null && add[2] == null && add[3] == null) {
			add[1] = U.getSectionValue(html, "addressLocality\">", "<");
			add[2] = U.getSectionValue(html, "addressRegion\">", "<");
			add[3] = U.getSectionValue(html, "postalCode\">", "<");
		}
if(comUrl.contains("https://www.backofthehillapartments.com/"))
{
	communityName="The Hill Apartments";
	add[0]="100 SOUTH HUNTINGTON AVENUE";
	add[1]="JAMAICA PLAIN";
	add[2]="MA";
	add[3]="02130";
	
	latlag=U.getlatlongGoogleApi(add);
	
}
	//100 SOUTH HUNTINGTON AVENUE  JAMAICA PLAIN, MA 02130
		U.log("Address---->" + add[0] + " city:" + add[1] + " state:" + add[2] + " zip:" + add[3]);
		add[0] = add[0].replaceAll(" \\(Basement\\)|,", "");
		add[1] = add[1].replace(",", "");
		U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);

		// --------------------------------------------------latlng----------------------------------------------------------------
		String latSec = U.getSectionValue(html, "google.maps.LatLng(", ")");
		if (html.contains("itemprop=\"latitude\" />")) {
			U.log("Hello");
			latlag[1] = Util.match(html, "<meta content=\"(.*?)\" itemprop=\"latitude\" />", 1).replaceAll("\"", "");
			latlag[0] = Util.match(html, "<meta content=\"(.*?)\" itemprop=\"longitude\" />", 1).replaceAll("\"", "");

			// <meta content="-71.06124" itemprop="latitude" />
			// <meta content="42.35274" itemprop="longitude" />
		}
		if (html.contains("<meta itemprop=\"latitude\"")) {
			latlag[1] = U.getSectionValue(html, "<meta itemprop=\"latitude\" content=\"", "\"");
			latlag[0] = U.getSectionValue(html, "<meta itemprop=\"longitude\" content=\"", "\"");
		}
		if (html.contains("latitude = \"")) {
			latlag[0] = U.getSectionValue(html, "latitude = \"", "\"");
			latlag[1] = U.getSectionValue(html, "longitude = \"", "\"");
		}
		if (html.contains("latitude\":")) {
			latlag[0] = U.getSectionValue(html, "latitude\":", ",\"");
			latlag[1] = U.getSectionValue(html, "longitude\":", "},");
			if(latlag[0]==null||latlag[0]==ALLOW_BLANK)
				latlag[0] = U.getSectionValue(html, "\"latitude\": \"", "\",");
			if(latlag[1]==null||latlag[1]==ALLOW_BLANK) {
				latlag[1]=U.getSectionValue(html, "\"longitude\": \"", "\",");
			}
			U.log("My lalng"+Arrays.toString(latlag));
		}
		if(mapHtml == null) mapHtml ="";
		if(latlag[0].length()<4 && mapHtml.length()>4){
			latlag[0] = U.getSectionValue(mapHtml, "latitude\": \"", "\"");
			latlag[1] = U.getSectionValue(mapHtml, "longitude\": \"", "\"");
		}
		
		if (latlag[0].length() < 4 || latlag[0].contains("0.0000")) {
			latlag = U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo = "TRUE";
		}

		U.log(latlag[0] + "::::" + latlag[0].length());
		if(latlag[1] != null && latlag[1].length() > 10){
			latlag[1] = Util.match(latlag[1], "-\\d{2}\\.\\d{2,}");
		}
		U.log("hhhh--->" + latlag[0] + "  " + latlag[1]);
		if (add[0].length() < 4) {
			add = U.getAddressGoogleApi(latlag);
			geo = "true";
		}
		if(latlag[1]==null) {
			latlag=U.getlatlongGoogleApi(add);
		}
		if(latlag[1].length()>3)
		latlag[1] = latlag[1].replace("}}</script><link href=\"https://cs-cdn.realpage.com/CMS/C14640/TemplateResources/Global/Icons/font-awesome.min.css\" type=\"text/css\" rel=\"stylesheet\" as=\"style\" onload=\"null\" data-loadcss=\"true\" media=\"all\">\n" + 
				"<script type=\"text/javascript\">var latitude='36.857612',longitude='-76.254218',name='Broad Creek Apartments',addressLine1='1420 Merrimac Ave',city='Norfolk',addressState='VA',addressPostalCode='23504',phonesNumber='(757) 628-8270',website='';</script><link href=\"https://cs-cdn.realpage.com/CMS/C14640/GlobalResources/datepicker.css\" type=\"text/css\" rel=\"stylesheet\" as=\"style\" onload=\"null\" data-loadcss=\"true\" media=\"all\">\n" + 
				"<script src=\"https://cs-cdn.realpage.com/CMS/C14640/GlobalResources/datepicker.js\" type=\"text/javascript\" defer=\"defer\"></script><script type=\"text/javascript\">\n" + 
				"(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)", "");

		

		// ============================================Price and
		// SQ.FT======================================================================

		String note = ALLOW_BLANK;

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		html = html.replaceAll("0�s|0's|0&#8217;s", "0,000");
		String prices[] = U.getPrices(html + floorHomeH, "\\d,\\d+ -<span class='sr-only'>to</span> \\d,\\d+<span class=\"sr-only\">Square Foot</span></td>|anhdprice\">\\$\\d+,\\d+|the Mid \\$\\d+,\\d+", 0);

		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		U.log("My price--->" + minPrice + " " + maxPrice);

		// ======================================================Sq.ft===========================================================================================
		if (floorHomeH != null) {
			floorHomeH = floorHomeH.replaceAll("Sqft_\\d+\"", "Sqft_\"");
		}
		U.log("ffffffff  " + U.getSectionValue(floorHomeH, "<tbody id=\"divFPRows\">", "</tr>"));
		//floorHomeH = floorHomeH.replaceAll(" -<span class='sr-only'>", "");
		String[] sqft = U.getSqareFeet(html + floorHomeH,
				"<td data-label=\"SQ. FT.\">\\d{3} -<span class=\"sr-only\">to</span> \\d,\\d{3}<span class=\"sr-only\">Square Foot|sqft\">\\d,\\d{3} - \\d,\\d{3}</span><|sqft\">\\d,\\d{3}</span>|sqft\">\\d{3,4} - \\d{3,4}</span>|\"Sqft_1\">\\d{3,4} -<span class='sr-only'>to</span> \\d{3,4}</td></tr>|<td class=\"footage\">\\d{3,4}</td>|class=\"detail-floorplan-sqft\">\\d{3,4}</i>|Sqft_\">\\d+\\s*-<span class='sr-only'>to</span>\\s*\\d{3,4}</td>|footage\">\\d{3}-\\d{3}</td>|detail-floorplan-sqft\">\\d+</i>|footage\">\\d+</td>|Sqft_\" class=\"tcolumn text-center\">\\d+|SQ. FT.\">\\d+|Sqft_\">\\d+</td>|SQ. FT.\">\\d+<span|Sqft_\">\\d{3,4}|to</span> \\d{3,4}",
				0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->" + minSqft + " " + maxSqft);

		// ================================================community
		// type========================================================
		if(animitHomeH!=null)
		animitHomeH = U.getNoHtml(animitHomeH);
		html = U.getNoHtml(html);
		String communityType = U.getCommType(html + animitHomeH);

		// ==========================================================Property
		// Type================================================

		String proptype = U.getPropType((html + animitHomeH).replaceAll("(V|v)illage", ""));
		if (proptype.contains("Townhouse") && proptype.contains("Townhome"))
			proptype = proptype.replace("Townhouse,", "");

		// ==================================================D-Property
		// Type======================================================
		if(animitHomeH == null) animitHomeH = "";
		animitHomeH = animitHomeH.replace("1st and 2nd Floors", " 1 Story  and  2 Story");
		String dtype = U.getdCommType(html + animitHomeH);

		// ==============================================Property
		// Status=========================================================
		String pstatus = U.getPropStatus((html + animitHomeH).replaceAll("Homes Available Now|IS NOW OPEN", ""));

		// ============================================note====================================================================

		note = U.getnote(html);
		//U.log("mmm: "+Util.match(html, "[\\w\\s\\W]{30}Now leasing our newest phase[\\w\\s\\W]{30}"));
		if (data.communityUrlExists(comUrl)) {
			k++;
			return;
		}
		latlag[1] = latlag[1].replace("}}</script><link href=\"https://cs-cdn.realpage.com/CMS/C14640/TemplateResources/Global/Icons/font-awesome.min.css\" type=\"text/css\" rel=\"preload\" as=\"style\" onload=\"this.rel='stylesheet'\" />\n" + 
				"<script type=\"text/javascript\">var latitude='36.857612',longitude='-76.254218',name='Broad Creek Apartments',addressLine1='1420 Merrimac Ave',city='Norfolk',addressState='VA',addressPostalCode='23504',phonesNumber='(757) 628-8270',website='';</script><link href=\"https://cs-cdn.realpage.com/CMS/C14640/GlobalResources/datepicker.css\" type=\"text/css\" rel=\"preload\" as=\"style\" onload=\"this.rel='stylesheet'\" />\n" + 
				"<script src=\"https://cs-cdn.realpage.com/CMS/C14640/GlobalResources/datepicker.js\" type=\"text/javascript\" defer=\"defer\"></script><script type=\"text/javascript\">\n" + 
				"(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)", "");
		
		if(comUrl.contains("https://www.olmstedapartments.com/"))communityType="62+ Community";
		if(comUrl.contains("www.liveincoatesville.com")) {
			minSqft="950";
			maxSqft="1010";
		}
		
	
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(communityName, comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("&nbsp;", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt,endDt);
		j++;
//	}catch(Exception e) {U.log(e);}
		
	}
	public static String getCache(String path) throws MalformedURLException {

		String Dname = null;
		String host = new URL(path).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;

		File folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = getCacheFileName(path);
		fileName = U.getCachePath() + Dname + "/" + fileName;
		return fileName;
	}
	public static String getCacheFileName(String url) {

		String str = url.replaceAll("http://", "");
		str = str.replaceAll("www.", "");
		str = str.replaceAll("[^\\w]", "");
		if (str.length() > 200) {
			str = str.substring(0, 100) + str.substring(170, 190)
					+ str.length() + "-" + str.hashCode();

		}

		try {
			str = URLEncoder.encode(str, "UTF-8");
			// U.log(str);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();

		}
		return str + ".txt";
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;
U.log(fileName);
		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(7000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}


	public static String getHtml1(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.get(url);
					Thread.sleep(4000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); // y value '400' can
					// be

					String html1 = "";
					html = driver.getPageSource();
					WebElement click = null;
					for (int i = 2; i < 6; i++) {
						//// *[@id=\"paginationTop\"]/div/ul/li["+i+"]/a
						// *[@id="paginationTop"]/div/ul/li[6]/a
						// *[@id="list-view"]/div[4]/div/ul/li[3]/a
						//// *[@id="paginationTop"]/div/ul/li[4]/a
						// *[@id="paginationTop"]/div/ul/li[2]/a
						click = driver.findElement(By.xpath("//*[@id=\"paginationTop\"]/div/ul/li[" + i + "]/a"));
						// WebElement
						// driver.findElement(By.xpath("//*[@id=\"recaptcha-anchor-label\"]"));//*[@id="list-view"]/div[4]/div/ul/li[6]/a
						Thread.sleep(4000);
						click.click();
						// driver.findElement(By.xpath("//*[@id=\"homes\"]/div[2]/dir-pagination-controls/ul/li[3]/a"));//*[@id="paginationTop"]/div/ul/li[6]/a
						// click.click();
						Thread.sleep(4000);
						/*
						 * ((JavascriptExecutor) driver).executeScript( "window.scrollBy(0,400)", "");
						 */
						U.log("Current URL:::" + driver.getCurrentUrl());
						html1 = driver.getPageSource();
						html = html + html1;
					}
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}


}
