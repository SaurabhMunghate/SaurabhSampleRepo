/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_201_220;

import java.util.ArrayList;
import java.util.Arrays;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractImpressionHomes extends AbstractScrapper {
	WebDriver driver = null;
	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;

	public ExtractImpressionHomes() throws Exception {
		super("Impression Homes", "https://www.impressionhomes.net/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Impression Homes");
	}
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractImpressionHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Impression Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html  = U.getHTML("https://www.impressionhomes.net");
		String section = U.getSectionValue(html, "Our Communities</a>", "Move In Ready Homes</a></li>"); //"</li></ul></li></ul></li>");
//		U.log(section);
		
		int count = 0;
		String regionUrlSection[] = U.getValues(section, "menu-item-object-page menu-item-has-children", "</a>");
		for(String regionUrlSec : regionUrlSection){
			String regionUrl = U.getSectionValue(regionUrlSec, "<a href=\"", "\"");
			U.log("regionUrl ::: "+regionUrl);
			String regionHtml = U.getHTML(regionUrl);
//			if(!regionUrl.contains("melissa"))continue;
//			U.log(regionHtml);
			String comUrlSection[] = new String[]{};
			if(regionHtml.contains("View More Info"))
		    comUrlSection = U.getValues(regionHtml, "<div class=\"sow-image-container\">", "View More Info");
			if(comUrlSection==null || comUrlSection.length == 0)
				comUrlSection = U.getValues(regionHtml, "<div class=\"textwidget custom-html-widget\"><h3", "View More Info");
			
//			if(comUrlSection==null ||comUrlSection.length == 0)
//				comUrlSection = U.getValues(regionHtml, "<div class=\"sow-image-container\">", "View More Info");
			
			if(comUrlSection==null ||comUrlSection.length == 0)
				comUrlSection = U.getValues(regionHtml, "<p><img loading=\"lazy\"", "View More Info");
			
			if(comUrlSection==null ||comUrlSection.length == 0)
				comUrlSection = U.getValues(regionHtml, "<img class=\"alignleft wp-image-", "View More Info");
			
			if(comUrlSection==null ||comUrlSection.length == 0)
				comUrlSection = U.getValues(regionHtml, "<img class=\"size-medium wp-image", "View More Info");
			
			if(comUrlSection==null ||comUrlSection.length == 0)
				comUrlSection = U.getValues(regionHtml, "<p><img class=\"wp-image", "View More Info");
			
			
			count += comUrlSection.length;
			U.log("com count :"+comUrlSection.length);
			for(String comUrlSec : comUrlSection){
				String url = U.getSectionValue(comUrlSec, " href=\"", "\"");
				String name = U.getSectionValue(comUrlSec, "<strong>", "</strong>");
//				U.log("comUrlSec ::"+comUrlSec);
//				U.log("1==========="+url);
				addDetails(url, name, comUrlSec);
			}
			
		}
		U.log(count);
	
		/*
		 * for extra community 
		 */
		
		String[] urlSections = U.getValues(section, "menu-item-object-community menu-item", "</li>");
		
		U.log(urlSections.length);
		
		for(String urlSection : urlSections){
			if(!urlSection.contains("community"))continue;
			String url=U.getSectionValue(urlSection, "href=\"", "\"");
//			U.log("2==========="+url);
			String name= U.getSectionValue(urlSection, "/\">", "<");
			addDetails(url, name, "");
		}

		driver.quit();
		LOGGER.DisposeLogger();
	}


	private void addDetails(String comUrl, String commData, String regionSec) throws Exception {
		// TODO Auto-generated method stub
//		 if(j>=29)
		{
			//======================= Run =========================================================
			//if(!comUrl.contains("https://www.impressionhomes.net/community/timberbrook/"))return;	

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated ---->"+comUrl);
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			if(comUrl.contains("https://www.impressionhomes.net/?post_type=community&amp;p=2568") || comUrl.contains("https://www.impressionhomes.net/?post_type=community&#038;p=1029"))return;
			U.log("Count==" + j);
//			U.log("regionSec======"+regionSec);
			U.log("commUrl-->" + comUrl);
			U.log("commData ::"+commData);
			if(commData == null) commData = ALLOW_BLANK;
			String html = U.getHtml(comUrl, driver);
			html=U.removeSectionValue(html, " Find Community <i ", ">Why Choose Impression</a");
			html=U.removeSectionValue(html, ">Homebuyer Tips:</h2>", "</body></html>");
			U.log(U.getCache(comUrl));
			// U.log(html);
			// ============================================Community
			// name=======================================================================
//			String communityName = U.getSectionValue(commData, "menu-image-title\">", "</span>");
/*			String communityName = U.getSectionValue(html, "<h1>", "</h1>");
			communityName = commData;
*/			String communityName =U.getSectionValue(html, "<h1 class=\"entry-title property-title\">", "</h1");
			communityName = communityName.replace("<br /><small>", " ").replaceAll("</small>|<.*?>", "");
			communityName=communityName.replace("Redden Farms –","Redden Farms");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================
			String note = "";
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			html = U.removeComments(html);
			String addSec = U.getSectionValue(html, "Model Location:", "</p>");
			U.log(addSec);
			if (addSec != null) {
				addSec = addSec.replace("</strong>", "").trim().replaceAll("^<br>|<br>$|&nbsp;", "").trim()
							.replace("Visit our sales office in the Bar C Ranch community located at", "")
							.replace("Pre-Selling from our Aubrey Creek Estates model located at:", "")
							.replace("Selling from Coventry East Model located at:", "")
							.replace("Coming Soon!","")
							.replace("Summer Creek South Homeowner’s Association<strong><br>", "").replace("TX&nbsp;76036", "TX 76036" );
				addSec = addSec.replaceAll("<br />|<br>", ",").replaceAll("TX,", "TX").replaceAll("^, </strong>", "");
				if (addSec.contains(",")) {
					add = U.getAddress(addSec);
				}
				if(addSec.contains("TX")) {
					add[2]="TX";
				}
			}
			
			U.log("Address ::"+Arrays.toString(add));
//			U.log("Address---->" + add[0] + " : " + add[1] + " : " + add[2] + " : " + add[3]);

			//String phtml = U.getHtml("https://www.impressionhomes.net" + "/quick-move-ins/", driver);
			// --------------------------------------------------latlng----------------------------------------------------------------
			add[0] = add[0].trim();
			String latLngSec = U.getSectionValue(html, "https://maps.google.com/maps?ll=", "\"");
			U.log(latLngSec);
			if (latLngSec != null) {
				latlag[0] = Util.match(latLngSec, "\\d{2,3}.\\d{3,}");
				latlag[1] = Util.match(latLngSec, "-\\d{2,3}.\\d{3,}");
			}
			if(latLngSec==null) {
				latLngSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "&amp;dir_action=navigate&amp;travelmode=driving\"");
				U.log("Hello"+latLngSec);
				latlag =latLngSec.split(",");
		
			}
//			else if(latLngSec==null) {
//				latLngSec = U.getSectionValue(html, "<p><iframe", "</iframe><");
//				if(latLngSec==null && html.contains("<iframe")) {
//					latLngSec = U.getSectionValue(html, "<iframe", "</iframe><");
//				}
//				U.log("Hello"+latLngSec);
//				if(latLngSec!=null) {
//				latLngSec = U.getSectionValue(latLngSec, "src=\"", "\"");
//				latlag[0]=U.getSectionValue(latLngSec, "3d", "!");
//				latlag[1]=U.getSectionValue(latLngSec, "!2d", "!");
//				if(latLngSec.contains("&amp;ll=") && latlag[0]==null) {
//					latLngSec = U.getSectionValue(latLngSec, "m&amp;ll=", "&amp;spn");
//					latlag =latLngSec.split(",");
//				}
//				}
//				else {
//					latLngSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "&amp;dir_action=");
//					latlag =latLngSec.split(",");
//				}
//			}
			
			if (latlag[1] == null || latlag[1].length() < 4) {
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				geo = "true";
			}
			if ((add[0] == ALLOW_BLANK || add[0].length() < 4) && latlag[1] != null) {
				add = U.getAddressGoogleApi(latlag);
				if(add == null) add = U.getAddressHereApi(latlag);
				geo = "TRUE";
			}
			U.log("hhhh--->" + latlag[0] + "  " + latlag[1]);
			// -------------Modified address------------
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]);
			}
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			U.log("zip :" + add[3] + "::::::::");
			add[3] = add[3].replaceAll(" (Model is actually in Aledo TX  76008)", "").replace(")", "").trim();
			if(add[0].contains("40655156"))add[0] = "10946 Live Oak Creek Dr";
			//--------floor and quick in homes data-------
			int quickCount = 0;
			String [] allHomeUrls = U.getValues(html, "<div class=\"property-box-image", "<img");
			String allHomesData = ALLOW_BLANK;
			U.log("Total Homes--->"+allHomeUrls.length);
			for(String homeUrl : allHomeUrls){
				//U.log(homeUrl);
				homeUrl = U.getSectionValue(homeUrl, "<a href=\"", "\"");
				U.log("homeUrl : "+homeUrl);
				if(!homeUrl.contains("https:"))homeUrl = "https://www.impressionhomes.net"+homeUrl;
				String homeHtml = U.getHTML(homeUrl);
				if(homeHtml== null)continue;
				if(homeUrl.contains("floorplan"))
				{
					if(homeHtml.contains("Plan Information"))allHomesData += U.getSectionValue(homeHtml, "<h2>Plan Information", "<h2>Floorplan Image");
					else allHomesData += U.getSectionValue(homeHtml, "<h1 class=\"entry-title property-title\">", "h2>Floorplan Image</h2>");
				}
				else 
				{
					quickCount++;
					allHomesData += U.getSectionValue(homeHtml, "<h1 class=\"entry-title property-title\">", "h2>Floorplan Image</h2>");		
				}
			}
			allHomesData = allHomesData.replace("</dt><dd>", " ");//Stories</dt><dd>2</dd>
			
			
			//============== Region Data =================
/*			String html1  = U.getHTML("https://www.impressionhomes.net");
			String section = U.getSectionValue(html1, "Our Communities</a", "</li></ul></li></ul></li>");
//			U.log(section);
			String[] urlSections = U.getValues(section, "><a", "/a>");
			
			for(String urlSection : urlSections){
				if(urlSection.contains("community"))continue;
				String url=U.getSectionValue(urlSection, "href=\"", "\"");
				
				String mainHtml = U.getHTML(url);
				
				String comSec = U.getSectionValue(mainHtml, "<header class=\"entry-header page-header\">", "<div class=\"footer\"");
				
				comSec = comSec.replace("aubrey-creek/", "aubrey-creek-estates/").replace("<strong><em>Learn more", "<strong><em>View More");
				
				String coms[] = U.getValues(comSec, comUrl.trim(), "View More");
				
				for(String com : coms) {
					
					if(com.contains(comUrl)) {
						commData += com;
						U.log("111 "+com);
					}
						
				}
				
				coms = U.getValues(comSec, comUrl.trim(), "View More");
				for(String com : coms) {
					
					if(com.contains(comUrl)) {
						commData += com;
						U.log("222 "+com);
					}
				}

				}
*/			
			
			//U.log(allHomesData);
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0s|0's|0&#8217;s|0s|0’s", "0,000");
			
			commData = commData.replaceAll("0s", "0,000").replace("&#8211;", "-");
			regionSec = regionSec.replace("00s", "00,000");
//			regionSec=regionSec.replace("Low $400,000","");
//			U.log("\n>>>>>>>>>>>>>>>>>>>>>>>\n"+regionSec+"\n>>>>>>>>>>>>>>>>>>>>>>>\n");
//			U.log("MMM"+Util.matchAll((regionSec), "[\\w\\s\\W]{40}300,000[\\w\\s\\W]{40}",0));//regionSec
			
			String prices[] = U.getPrices(commData+ html+regionSec   ,
					"Mid \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|Starting From:</strong> Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|(Price Range|Starting At):</strong>\\s?\\$\\d{3},\\d{3}(\\s?(-|–)\\s?\\$\\d{3},\\d{3})?|\\$\\d+,\\d+ - \\$\\d+,\\d+|\\$\\d+,\\d+</a>|\\$\\d{3},\\d{3}|omm-desc\">\\d{3},\\d{3} - \\d{3},\\d{3}|currency-dollar\"></i><strong>\\n*\\s*\\d{3},\\d{3}",
					0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
			
			html = html.replace("11,000 sqft Event and Amenity Center", "");
			regionSec = regionSec.replace("&#8211;", "–");
//			U.log("MM"+Util.match((commData + regionSec+html),"1424"));
			html=html.replaceAll("<li id=\"menu-item-\\d{4}","");
//			U.log("OO"+Util.matchAll(html, "[\\w\\W\\s]{30}1804[\\w\\W\\s]{30}", 0));
			String[] sqft = U.getSqareFeet(regionSec + regionSec + html ,
					"\\d,\\d{3} to \\d,\\d{3} square feet|Square Footage:</strong> \\d,\\d{3}<| \\d,\\d{3} – \\d,\\d{3} sqft|Square (Feet|Footage):</strong> \\d,\\d{3} - \\d,\\d{3}|(Square Footage|Square Feet):</strong>\\s?\\d,\\d{3}\\s?(-|–)\\s?\\d,\\d{3}|Square Feet:</strong> \\d,\\d{3}|Square Feet:</div> <div class=\"comm-desc\">\\d+ - \\d+|comm-desc\">\\d{4}-\\d{4}|comm-desc\">\\d{1},\\d+ - \\d{1},\\d+|\\d{4} sq ft|\\s{5,}\\n*\\d{3,4}\\s*</td>|\\s{5,}\\n*\\d,\\d{3}\\s*</td>|\\d,\\d{3} sqft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			if(comUrl.contains("https://www.impressionhomes.net/community/briarwood-hills/")) {
//				minSqft=ALLOW_BLANK;
//				maxSqft=ALLOW_BLANK;
//			}
//			if(comUrl.contains("https://www.impressionhomes.net/community/montclaire/")) {
//				minSqft=ALLOW_BLANK;
//				maxSqft=ALLOW_BLANK;
//			}
			if(comUrl.contains("https://www.impressionhomes.net/community/creek-valley/")) {
				minSqft="1982";
				maxSqft="2180";
			}

			// ================================================community
			// type========================================================
//            U.log("MATCHINH"+Util.matchAll((html + commData),"[\\w\\W\\s]{40}Active Adult[\\w\\W\\s]{40}",0));
			String communityType = U.getCommType((html + commData).replaceAll(" resort-style amenity cente|Redden Farms – Active Adult", ""));

			// ==========================================================Property
			// Type================================================
			html = html.replaceAll(
					"Village|village|Villas at|/villa|ranch/\"|Villa di|Ranch</span>|luxury community|Pre.Selling Custom Homes|>Coming Soon!<",
					"");
			html = U.getNoHtml(html);
			html = html.replaceAll("Villas\\s*of\\s*Stone", "");
//    U.log("JJ"+Util.match((html), "Ranch"));
    html=html.replaceAll("Marine Creek Ranch|marine-creek-ranch","");
    
    allHomesData=allHomesData.replaceAll("<li class=\"yes\">Loft</li>", "<li class=\"yes\">loft level</li>");
   
    String remSec=null;
     remSec=U.getSectionValue(html, "Find Community", "Why Choose Impression");
	if(remSec!=null) 
		html=html.replace(remSec, "");
//	U.log("remSec=="+remSec);
	
	
//	U.log("ALL HOME data"+allHomesData);
	
		String proptype = U.getPropType((html + commData +allHomesData ).replace("Manor features", "Manor Homes").replaceAll("single-family homes in the beautiful,|custom home builders|(Weatherford|River|Hardeman) Estates|Cons of Townhome Living", "")+ communityName);
		U.log("proptype=="+proptype);
//		U.log("mmmmmm"+Util.matchAll(html   , "[\\w\\s\\W]{30}Find Community[\\w\\s\\W]{30}", 0));
//		U.log("mmmmmm"+Util.matchAll( commData   , "[\\w\\s\\W]{30}manor[\\w\\s\\W]{30}", 0));
//		U.log("mmmmmm"+Util.matchAll(allHomesData  , "[\\w\\s\\W]{30}manor[\\w\\s\\W]{30}", 0));


			// ==================================================D-Property
			// Type======================================================
			html = html.replaceAll("one, and two-story|1- and 2-story", " 1 Story 2 Story ")
					.replace("1-, 1-1/2 and 2-story home ", "1 story , 1.5 story and 2 story ");
			
			String dtype = U.getdCommType((html + commData + allHomesData.replaceAll("4-2.5-2|4-2-2|3-2-2|4-3-2|floor|4 bedroom", "")).replaceAll("Ranch Rd|Ranchwood|ranchwood|Ranchers|ranchers", "")+communityName);
		
			
			// ==============================================Property  Status=========================================================
			html = html.replaceAll("Quick|quick|(Starting At|Feet|Fax|Hours|Model Location)(.*?)Coming", "");

			
			// html=html.replace("Coming Soon!","");
			

			html = html.replaceAll("Dog Park Coming Fall 2019|now selling custom new|now selling in Justin|USDA &#8211; 0% Down Available|USDA – 0% Down Available|Move In Ready Homes\\s*Why Choose Impressio|Hours:\\s*Coming soon!|Model Location:\\s*Coming soon!|Move In Ready Homes\\s*Why Choose Impression |tab-content hide\"><p>Coming Soon!</p>|On-site – Opening August 2017|<div id=\"tab2\" class=\"tab-content hide\">\\s*<p>Coming Soon!</p>|Location:\\s+Coming|<div class=\"tab-content hide\" id=\"tab2\">\\s?<p>Coming Soon!</p>"
					+"|Move-in Ready Homes or|Move In Ready Homes|Move Homes Available Now|Move Homes Coming Soon",
					"");
//			U.log(html.contains("move in"));

			html = html.replace("&#8211;", "-").replace("USDA - 0% Down Available", "USDA 0% Down Available").replaceAll("\"Now selling|details on our Grand Opening|ng>SOLD OUT</s|ur coming soon co|full details on our Grand Opening|Price: Coming Soon|Sqft: Coming Soon|Coming Soon!|coming soon!", "");
			
			regionSec=regionSec.replace("New Inventory Coming Soon!", "").replace("Coming Soon! Join our VIP List!", "");
			html=html.replace("Quick-Move Homes Coming Soon!", "Coming Soon!");
			String pstatus = U.getPropStatus(( html + commData+regionSec).replace("Quick-Move Homes Coming Soon", "")); //regionSec
//			U.log("mmmmmm"+Util.matchAll(  html + commData+regionSec , "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));

			if(comUrl.contains("https://www.impressionhomes.net/community/riverwalk/"))pstatus="Quick Move In";
			
			U.log("property status-->" + pstatus);
			U.log("Total quickCount : "+quickCount);
			if(quickCount!=0 && !pstatus.contains("Move")){
				if(pstatus == ALLOW_BLANK)pstatus="Quick Move In";
				else pstatus = pstatus+", Quick Move In";
			}
			
			// ============================================note====================================================================
			//U.log(html);
			html = html.replaceAll("Pre-Grand Opening incentives|TX is now pre-selling new", "");
			note = U.getnote(html);
			if(communityName.contains("Village"))proptype=proptype.replace("Villas,", "");
			if(note.contains("Pre-selling New Phase"))
				pstatus=pstatus.replaceAll("Selling New Phase,|Selling New Phase", "");
			if(pstatus.length()<2)pstatus=ALLOW_BLANK;

			add[0]=add[0].replace("Pre-Selling from The Heights of Weatherford – ", "");
			add[0]=add[0].replace("Selling from Coventry East Model located at:, ", "");
			add[0]=add[0].replace("Come visit us at our Timberbrook community!", "").replace("Pre-Selling from The Heights of Weatherford located at:, ", "").replace(", ", "");
			
			pstatus = pstatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");

			https://www.impressionhomes.net/community/coventry-east-townhomes/
//			if(comUrl.contains("https://www.impressionhomes.net/community/morningstar/")) {minPrice = "$280,000";pstatus="New Phase";};
			if(comUrl.contains("https://www.impressionhomes.net/community/montclaire/"))pstatus="Coming Soon";
			if(comUrl.contains("marine-creek-ranch/"))pstatus =pstatus.replace("New Phase Coming Fall 2022, New Phase", "New Phase Coming Fall 2022");
			if(comUrl.contains("https://www.impressionhomes.net/community/the-vineyards/"))pstatus = pstatus.replace(", Sold Out", "");
			
			if(comUrl.contains("/community/heartland/"))pstatus = pstatus.replace("New Phase Now Selling, ", "");//Img
		//	if(comUrl.contains(""))
				
			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replaceAll("Ii", "II"));
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
		}
		j++;

	}

}