/*sampada santosh*/
package com.shatam.b_201_220;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractLegacyHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "http://www.legacyhomesusa.com/";
	static String BASEURL1 = "http://www.legacyhomesusa.com/our-communities/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractLegacyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Legacy Homes.csv", a.data()
				.printAll());

	}

	public ExtractLegacyHomes() throws Exception {

		super("Legacy Homes", "http://www.legacyhomesusa.com/");
		LOGGER = new CommunityLogger("Legacy Homes");
	}

	public void innerProcess() throws Exception {

		String basehtml = U.getHTML("http://www.legacyhomesusa.com/");
		
		String[] regUrl=U.getValues(basehtml, "<div class=\"col-md-3 col-sm-3\"><a href=\"","\"");
		for(String url : regUrl) {
			if(!url.contains("liveataspire")) {
			url="http://www.legacyhomesusa.com"+url;
			U.log(url);
			String regHtml=U.getHTML(url);
//			regHtml=regHtml.replaceAll("<p>&nbsp;</p>", "");
//			String[] comSection = U.getValues(regHtml,"<div class=\"photo_box ico_right_enter box_border_padding\">",
//					"<div class=\"col-md-4\">");
			String[] comSection = U.getValues(regHtml,"<div class=\"photo_box ico_right_enter box_border_padding\">",
					"</p>");
			U.log("comSection   "+comSection.length);
			
			for(String commSec:comSection ) {
				String commUrl="http://www.legacyhomesusa.com"+U.getSectionValue(commSec, "<a href=\"", "\"><img");
				if(commUrl.contains("null"))
				{
					continue;
				}
//				if(commSec.contains("Winter")) {
//					FileUtil.writeAllText("/home/shatam-10/Desktop/data/regionsdata.txt", commSec);
//				}
					
//				U.log("commUrl   "+commUrl);
			//	U.log(">>>>>> "+commSec);
				String comName=null;
				comName = U.getSectionValue(commSec, "title=\"", "\" /></a");
//				 comName = U.getSectionValue(commSec, "<img alt=\"", "\"");
				if(comName==null) {
					U.log(">>>>>");
				String comNameSec1 = U.getSectionValue(commSec, "<h3>", "</h3>");
				comName=U.getSectionValue(comNameSec1, "\">", "</a>");
				if(comName==null) {
					String comNameSec=U.getSectionValue(commSec, "title=\"", "</a>");
					comName=U.getSectionValue(comNameSec, "><span>", "</span>");
				}
				}
				U.log("comName:::::::::::::"+ comName);
//				try {
					addDetails(commUrl,comName,commSec);
//				} catch (Exception e) {}
			}
			
			}
			else
//				try {
					addDetails("https://www.liveataspire.com", "Aspire","");
//				} catch (Exception e) {}
		
//		String comSection = U.getSectionValue(basehtml,
//				"<ul class=\"dnngo_slide_menu",
//				"<a href=\"http://www.liveataspire.com/");
//		//U.log(regionSection);
//		String comValues[] = U.getValues(comSection, "<li class=\" \">", "</li>");
//		U.log("Total com : "+comValues.length);
//		for (String comValue : comValues) {
//			String comUrl = U.getSectionValue(comValue, "<a href=\"", "\"");
			
//			String comName = Util.match(comValue, "<span>\\w*\\s*\\w*\\s*\\w+ - (.*?)</span></a>",1);
//			U.log(comName +":::::::::::::"+ comUrl);
//			addDetails(comUrl,comName);
		}

		
		LOGGER.DisposeLogger();
	}


	public void addDetails(String cUrl,String name,String commSec) throws Exception {
		//TODO :
//	if(j== 11)
	{
		U.log("Count :"+j);
		
//		if(!cUrl.contains("http://www.legacyhomesusa.com/find-your-home/southern-california-nevada-arizona/bullhead-city-ironwood.aspx"))return;

		
		String html = U.getHTML(cUrl);
		U.log(cUrl);
		
		//---------Logger---------
		if(data.communityUrlExists(cUrl)){
			LOGGER.AddCommunityUrl(cUrl+"********repeated*******");
			return;
		}
		if(cUrl.contains("http://www.legacyhomesusa.com/find-your-home/southern-california-nevada-arizona/bullhead-city-river-s-edge.aspx")||cUrl.contains("http://www.legacyhomesusa.com/find-your-home/southern-california-nevada-arizona/bullhead-city-river-s-edge.aspx")){
			LOGGER.AddCommunityUrl(cUrl+"********Redirected*******");
			return;
		}
		LOGGER.AddCommunityUrl(cUrl);
		//-------------comName-------
				String cName = name;
				cName = U.getNoHtml(cName.replace("ñ", "n"));
				U.log("cName::::"+cName);
				
		//-----------------------
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo= "FALSE";
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String notes =ALLOW_BLANK;
		//-----------Address------------
		String addSec = U.getSectionValue(html, "<h4>Sales Office Address</h4>", "<em class=");
		if(addSec == null)
			addSec = U.getSectionValue(html, "<p>Sales Office Address<br />", "<em class=");
		if(addSec == null)
			addSec = U.getSectionValue(html, "<h4>Sales Office Address</h4>", ">Map</a>");
		if(addSec == null) {
			addSec = U.getSectionValue(html, "<a class=\"address-link color-inherit d-block\" href=\"https://maps.google.com?q=", "\"");
			if(addSec!=null)addSec=addSec.replace("Tracy", ",Tracy");
		}
		
		U.log(addSec);
		if(addSec!=null){
			addSec = addSec.replace("<p>", "").replace("<br />", ",").replace("&nbsp;", " ").replace("California&nbsp;92392", "California 92392").trim();
			String[] tempAdd = addSec.split(",");
			add[0] = tempAdd[0].trim();
			add[1] = tempAdd[1].trim();
			add[2] = Util.match(tempAdd[2], "\\w+").trim();
			add[3] = Util.match(tempAdd[2], "\\d+");
			if(add[2].length()>2){
				add[2] = USStates.abbr(add[2]);
			}
			U.log("Address is ::" +Arrays.toString(add));
		}
		if(addSec==null)
		{
			addSec=U.getSectionValue(html, "class=\"Normal\">", "</h2>");
//			addSec=U.getNoHtml(addSec);
//			add=U.getAddress(addSec);
			U.log(">>>>>>>>"+addSec);
			String[] add1= addSec.split(",");
			add1[1]=USStates.abbr(add1[1]);
//			add=addSec.split(",");
		latLng=U.getlatlongGoogleApi(new String[] {"",add1[0],add1[1],""});
		add=U.getAddressGoogleApi(latLng);
		
			U.log(">>>>>>>>"+add1[1]);
			
			geo = "TRUE";
		}

		
		//-----Fetching latlng using address as latlng not present on com page----------
		if(addSec!=null && addSec.contains("https://www.google.com/maps/place")) {
			String latlngsec =U.getSectionValue(addSec, "/@", ",13z/data=!");
			latLng = latlngsec.split(",");
		}
		
		//google can find latlng for this community address
		if(cUrl.contains("http://www.legacyhomesusa.com/find-your-home/northern-california-nevada/soledad-vintage-estates.aspx")){
			latLng[0] = "36.4328333";
			latLng[1] = "-121.3186609";
			geo = "TRUE";
		}
//		if(add[0]==null||add[0]==ALLOW_BLANK ||add[1]==null||add[1]==ALLOW_BLANK || add[3]==null||add[3]==ALLOW_BLANK)
//		{
//			latLng=U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latLng);
//			geo = "TRUE";
//		}
		
		if(add[0].length()>4 && latLng[0]==ALLOW_BLANK){
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo = "TRUE";
		}
		U.log("latlng is "+Arrays.toString(latLng));
		
		if(cUrl.contains("https://www.liveataspire.com")){
			
			
			latLng[0] = U.getSectionValue(html, "latitude: \"", "\"");
			latLng[1] = U.getSectionValue(html, "longitude: \"", "\"");
			
			add[0] = U.getSectionValue(html, "address: \"", "\"").replace("&nbsp;", "");
			add[1] = U.getSectionValue(html, "city: \"", "\"");
			add[2] = U.getSectionValue(html, "state: \"", "\"");
			add[3] = U.getSectionValue(html, "zip: \"", "\"");
			U.log("latlng is "+Arrays.toString(latLng));
			U.log("Address is ::" +Arrays.toString(add));
			
			html = html + " B3 TOWNHOME B4 TOWNHOME";//floorplan
		}
		//-----fetching zip code from latlng
		if(add[3]==null){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "TRUE";
		}
		if(cUrl.contains("http://www.legacyhomesusa.com/find-your-home/southern-california-nevada-arizona/la-quinta-santerra.aspx")){
			add[1] = "La Quinta";
			add[2] = "CA";
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "TRUE";
			notes = "Address And LatLng Taken Using City And State";
		}
		if(cUrl.contains("http://www.legacyhomesusa.com/find-your-home/southern-california-nevada-arizona/riverside-bridle-ridge.aspx"))
			add[0]="2955 Van Buren Boulevard";
		//add[0]=add[0].replace("2955 Van Buren Boulevard Ste H2","2955 Van Buren Boulevard");
		//-----------remove common header section---------------
		String removeHeader = U.getSectionValue(html, "<div class=\"hidden-xs  \" id=\"header3\"> ", "Testimonials</span></a></li></ul>");
		if(removeHeader!=null){
			html = html.replace(removeHeader, "");
			U.log(":::::::::::removeHeader::::::::::::::::");
		}
		html = U.removeComments(html);
		String floorHtml=ALLOW_BLANK;
		if(cUrl.contains("https://www.liveataspire.com")) {
			floorHtml =U.getHTML("https://www.liveataspire.com/floorplans");
		}
		//---------Price-------------
		String minPrice = ALLOW_BLANK,maxPrice =ALLOW_BLANK;
		String[] prices = U.getPrices(html, "\\$\\d{3},\\d{3}", 0); 
		
		minPrice = (prices[0]==null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
		
		U.log("min price: "+ minPrice + "\t max price : "+maxPrice);
		
		//------------Square Feet-------
		String minSqFt = ALLOW_BLANK, maxSqFt =ALLOW_BLANK;
		String remSecs[]=U.getValues(html, "hidden-xs hidden-sm hidden-md hidden-lg", "</a></p>");
		for (String rem : remSecs) {
//			U.log(rem);
			html=html.replace(rem, "");
		}
		html=html.replace("2,525&nbsp;Square Feet", "2,525 Square Feet");
		String[] SqFt = U.getSqareFeet(html+floorHtml, 
				"\\d,\\d{3} Sq.Ft.|\\d{3} Sq.Ft.|ranging from\\s*\\d,\\d{3} to \\d,\\d{3} square feet|range from \\d,\\d{3} to \\d,\\d{3} square feet|approximately \\d{4} to \\d{4} square feet|\\d{4} square feet to just over \\d{4} square feet|\\d{4} square feet to \\d{4} square feet|\\d{4} to \\d{4} square feet|\\d,\\d{3} Square Feet<br />|SqFt\">\\d,\\d{3}|SqFt\">\\d{3}", 0); 
		
		minSqFt = (SqFt[0]==null) ? ALLOW_BLANK : SqFt[0];
		maxSqFt = (SqFt[1]==null) ? ALLOW_BLANK : SqFt[1];
		
		U.log("min SqFt: "+ minSqFt + "\t max SqFt : "+maxSqFt);
		
		//-----------remove data-------
		String removeData = "Enlongated";
		html=html.replace(removeData, "");
		
		//------------modified html data--------
		html = html.replaceAll("<li>Loft</li>|Bath, Loft,", "Loft Home").replaceAll("<li>Elongated Toilets</li>|less than traditional", "");
		
		//---------community type------------
		String comType = U.getCommunityType(html);
		U.log("comType::: "+comType);
		//---------property type---------------
		html = html.replaceAll("traditional power", "").replace("Traditional &amp; Cottage Architectural", "Traditional exterior & Cottage Architectural");
		
//		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}Loft[\\w\\s\\W]{30}", 0));
		
		String propType = U.getPropType(html);
		U.log("propeType::: "+propType);
		
		
		
		
		
		
		
		//---------derived type----------------
		String  dSec=ALLOW_BLANK;
		if(html.contains("Community Information<")||html.contains("Community Information-<")){
			html = html.replace("Rancho", "");
			dSec=U.getSectionValue(html,"<h3 class=\"text-center\"","/a></div>");
			
			if(dSec == null)dSec=U.getSectionValue(html,"Community Information</h1>","</p>");//for St. Andrews community
			dSec+=U.getSectionValue(html,"<h3>Community Features</h3>","<div class=\"edn_clearFix\">");
	
		}
		//if(dS)
//		U.log(dSec);
		if(dSec==null)dSec = ALLOW_BLANK;
		
		
//		dSec=dSec.replace("Thermal Equalizer System (Two Story Plans)", "");
		String dType = U.getdCommType(dSec.replaceAll("second story loft option home|Multi Level Dishwasher| Ranch Drive|Santana Ranch", ""));
//		U.log("mmmmmm"+Util.matchAll(dSec, "[\\w\\s\\W]{30}Spanish Colonial[\\w\\s\\W]{30}", 0));
		if(dType.length()==0){
			
			dType=ALLOW_BLANK;
		}
		
		U.log("dType::: "+dType);
		//---------property status-------------
//		html=html.replace("BUILDER CLOSE - OUT", "BUILDER CLOSE-OUT");
		String pStatus=ALLOW_BLANK;
		 pStatus = U.getPropStatus((commSec) + html.replaceAll("Coming Summer 2021|Coming Fall 2021|<h4>Sales Office Hours</h4>\\s*<p>Community Sold Out<br />|Office Hours</h4>\\s+<p>Opening Fall", ""));
		U.log("pStatus::: "+pStatus);
//		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}Opening Winter[\\w\\s\\W]{30}", 0));

		if(cUrl.contains("https://www.liveataspire.com")){
			
			propType+=", Multi-Family";
			
		}
//		Coming Summer 2021
		
//		if(cUrl.contains("city-ironwood.aspx")||cUrl.contains("poppy-lane.aspx")||cUrl.contains("bridle-ridge.aspx")||cUrl.contains("village-square.aspx")) {
//			if(!pStatus.equals(ALLOW_BLANK)) {
//			pStatus="Coming Soon, "+pStatus;
//			}
//			else
//				pStatus="Coming Soon";
//		}
		
//		if(cUrl.contains("-poppy-lane.aspx"))
//			pStatus="Coming Summer 2022"; //from region page image
//		if(cUrl.contains("montrose.aspx")||cUrl.contains("-poppy-lane.aspx")||cUrl.contains("city-ironwood.aspx")||cUrl.contains("riverside-bridle-ridge.aspx"))
//			pStatus=pStatus+", Coming Soon";
////		
//		if(cUrl.contains("riverside-bridle-ridge.aspx"))
//			pStatus+=", Coming Summer 2022";
		
		//add data in csv
		data.addCommunity(cName,cUrl, comType);
		data.addAddress(U.getCapitalise(add[0].toLowerCase()), add[1], add[2].trim().toUpperCase(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(U.getCapitalise(pStatus.toLowerCase()));
		data.addNotes(notes);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);	
		j++;
	}
	
	}
}