/* Modification ADitya..
 * @ ashish shivhare */
package com.shatam.b_201_220;

import java.util.Arrays;
import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import org.apache.commons.lang3.StringUtils;

public class ExtractMyBuffington extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	private static final String BUILDER_URL = "https://www.mybuffington.com/";
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractMyBuffington();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Buffington Homes.csv", a.data()
				.printAll());

	}

	public ExtractMyBuffington() throws Exception {

		super("Buffington Homes", "https://www.mybuffington.com/");
		LOGGER = new CommunityLogger("Buffington Homes");
	}
	HashMap<String, String> qmiData=new HashMap<>();
	public void innerProcess() throws Exception {
		// String url="https://www.mybuffington.com/communities";
		String url = "https://www.mybuffington.com/find-your-home/our-communities/";
		String base = "https://www.mybuffington.com/";
	//	U.bypassCertificate();
//		String qmiPageUrl="https://www.mybuffington.com/quickmovein/";
//		String qmiHtml=U.getHTML(qmiPageUrl);
		
		String html = U.getHTMLwithProxy(url);
		//U.log(html);
//		String section = U.getSectionValue(html, "<div class=\"listings block\">","<div class=\"extra block\">");
		String[] sections = U.getValues(html, "var contentString","icon: ");
//		String[] sections = U.getValues(html, "uk-text-center uk-margin-large-bottom","View Community");
		U.log(sections.length);
		for (String sect : sections) {
//		U.log(sect);
			String comval = U.getSectionValue(sect, "a href=\"", "\"");
			sect = sect.replaceAll("0's|0s", "0,000MyPrice");
//			 U.log("My Section: " + comval);
			//if(i>5)
			addDetails(comval, sect);
			inr++;
			i++;
//break;
		}
	
		LOGGER.DisposeLogger();	
	}
	
	int j = 0;
	private void addDetails(String comUrl, String sections) throws Exception {
//		if(!comUrl.contains("https://www.mybuffington.com/new-home-communities/new-homes-whisper-valley-tx-whisper-valley/"))return;
//		try{
		{
		
		//if(comUrl.contains("https://www.mybuffington.com/new-home-communities/homes-driftwood-tx-rutherford-west/"))return;//redirect to main page


		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"---->Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

		//	U.log(sections);
		
		U.log(j+"\tPage::" + comUrl);
		String html = U.getHTMLwithProxy(comUrl);
//		String commName = U.getSectionValue(sections, "title: \"", "\"");
//		String commName = U.getSectionValue(sections, "margin-small\">", "</h4>");
		String commName = U.getSectionValue(html, "<h1 class=\"uk-text-secondary uk-text-uppercase w700 s2 uk-margin-bottom-remove\">", "<");
		
		String drop1 =  U.getSectionValue(html, "<strong>Seton Medical Center</strong>", "<div id=\"PanelFloorplansContent");
		if(drop1!=null)
		html = html.replace(drop1, "");
		
		

		// if(html.contains("Page Not Found")){ return;}
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = "False";
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addr = U.getSectionValue(html, "!2s", "!");
		//addr = addr.replace("<br />", ",");
		if(addr!=null){
			addr = addr.replace("+", " ").replace("%2C", ",").replace("%23", "#");
			U.log("addr Section1 ::::::::::::: "+addr+" :::::::::::::::::::::::");
			addr=addr.replace("Belterra, TX 78737", " a , Belterra, TX 78737");
			U.log("addr Section1 ::::::::::::: "+addr+" :::::::::::::::::::::::");
			add = U.findAddress(addr);
		}
		if(add==null||addr==null){
			addr = U.getSectionValue(html, "Model Address</h3>", "</p>");
			addr = addr.replace("<br />", ", ").replace("512.585.9061 for access or to tour home", "")
					.replaceAll(" \\d{3}\\.\\d{3}\\.\\d{4}", "");
			U.log("addr Section2 ::::::::::::: "+addr+" :::::::::::::::::::::::");
			add = U.findAddress(addr);
		}
		U.log("Address::: "+Arrays.toString(add));
		String lats=U.getSectionValue(sections, "LatLng(", ")");
		if(lats!=null) {
			String[] ll=lats.split(",");
			lat=ll[0];
			lng=ll[1];
		}
		
		if(add == null && lat.length()>4){
			String[] latlong={lat,lng};
			add = U.getAddressGoogleApi(latlong);
			if(add == null) add = U.getAddressHereApi(latlong);
			geo = "TRUE";
		}
		if(add[3].length()<4 && lat.length()>4)
		{
			String[] latlong={lat,lng};
			add=U.getAddressGoogleApi(latlong);
			if(add == null) add = U.getAddressHereApi(latlong);
			geo = "TRUE";
		}

		U.log("=========" + add[0]);
		if (add[0].trim().startsWith("'"))
			add[0] = add[0].substring(2);
		U.log("=========" + add[0]);
		
		//----------------Price----------------
		String maxSq = ALLOW_BLANK, minSq = ALLOW_BLANK, maxPrice = ALLOW_BLANK, minPrice = ALLOW_BLANK;
		//From the $449'starting in the high $200K’s
		html = html.replace("starting in the high $200K’s", "starting in the high $200,000").replace("0&rsquo;s.", "0,000").replaceAll("0's|0’s|0&#8217;s", "0,000").replaceAll("9's", "9,000").replace("K’s", ",000").replace("off of options up to $30,000</span>", "")
				.replace("00k&#8217;s", "00,000");
		sections=sections.replace("$600k", "$600,000").replace("$429K - $449K", "$429,000 - $449,000").replaceAll("'s|’s|&#8217;s", ",000")
				.replace("Closeout $429K", "Closeout $429,000").replace("$289's", "$289,000");
		U.log(sections);
		String price[] = U
				.getPrices(
						html + sections,
						">\\$\\d{1},\\d{3},\\d{3}<|From the \\$\\d{3},\\d{3}|tarting in the high \\$\\d{3},\\d{3}|<p>\\$\\d+,\\d+<br />|in the low \\$\\d{3},\\d{3}|<strong>\\$\\d+,\\d+<br />|\\$\\d+,\\d+|\\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice:" + minPrice + "MaxPrice" + maxPrice);
		
		//---------------Square feet-------------
		String sqFt[] = U.getSqareFeet(html, "from \\d,\\d{3} sqft up to \\d,\\d{3} sqft|\\d,\\d+ Sq Ft|\\d+ square feet|\\d{4} sqft",
				0);
		minSq = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSq = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("MinSqt:" + minSq + "MinSqt" + maxSq);
		
		
		//=============== Available homes ======================
		String availableSection = U.getSectionValue(html, "<ul id=\"homes-block\"", "<script>");
		String combinedAvailableHtmls = null;
		if(availableSection != null){
			String[] availableHomeUrls = U.getValues(availableSection, "<a href=\"", "\"");
			U.log("available home count=="+availableHomeUrls.length);
			int x = 0;
			for(String availableUrl : availableHomeUrls){
				if(!availableUrl.contains("homes"))continue;
				U.log("avialHomes:::"+availableUrl);
				if(!availableUrl.contains("https:")) continue;
				String availableHtml = U.getHTMLwithProxy(availableUrl);//withProxy
				if(availableHtml!=null)
				combinedAvailableHtmls += U.getSectionValue(availableHtml, "<h4 class=\"uk-margin-large-top", "<div id=\"request-info");
				if(x ==7)break;
			}
		}
//		//=============== floor plans  ======================
//				String floorSection = U.getSectionValue(html, " uk-text-bold\">Home Designs</h1>", "<div class=\"uk-container");
//				String combinedfloorHtmls = null;
//				if(availableSection != null){
//					String[] floorplansUrls = U.getValues(floorSection, "<a href=\"", "\"");
//					U.log("available home count=="+floorplansUrls.length);
//					int x = 0;
//					for(String planUrl : floorplansUrls){
//						if(!planUrl.contains("homes"))continue;
//						U.log("avialHomes:::"+planUrl);
//						if(!planUrl.contains("https:")) continue;
//						String planHtml = U.getHTMLwithProxy(planUrl);
//						if(planHtml!=null)
//							combinedfloorHtmls += U.getSectionValue(planHtml, "<h4 class=\"uk-margin-large-top", "<div id=\"request-info");
//						if(x ==7)break;
//					}
//				}
		//-----------Property Type-------------------
		String pType = null;
		html = html.replaceAll("Enjoy outdoor dining on the patio|new elite golf course|Golf Course Coming Near|craftsman John| the Manor|Jewelry Craftsmen |Austin-area golf co|amenities of this Austin-area golf co|finest public golf co|7,147 yard par-72 golf co|lack Hawk Golf Co|up-scale golf co|designed disc golf course, sand|Rear Patio Door|Village|Villages|VILLAGES|villages|village|tradition|traditional|Shop in luxury at|130 luxury and|Elongated|award-winning master plan|summer traditions", "");
		//U.log("Match====="+Util.match(html, ".*?patio.*?"));
		pType = U.getPropType(html+combinedAvailableHtmls.replace("traditional styling at the exterior", "traditional exterior"));
		if (pType == null)
			pType = ALLOW_BLANK;

		//-----------community type-----------
		String communityType = U.getCommunityType(html);
		U.log("CommunityType: "+communityType);

		//------------Status------------------
		String status = ALLOW_BLANK;
		
		
		String statSec = html;
		String remove = "SOLD OUT &#8211; The Colony|is now available for purchase|Hours</h3>\\s+Closed|Closed out Phases|10,000 in Move-in Ready Options|<i class=\"fa fa-star\"></i> Move In Ready</span>|quickmovein/\">Quick Move in Homes</a|><b><i>Now Available</i><|tax incentives now available| &#8211; ONLY 2 Opportunities Left!!!</span></strong></em></h1>|Model Under Construction|COMING SOON|PLAT MAP COMING SOON!|Model Hours:</strong><br />COMING SOON|under construction inventory|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|This is a close out community|<h1 style=\"text-align: center;\">coming|utility providers</h1>\\s+<h3>coming";
		statSec = statSec.replace("Now Selling in Phase 2", "Now Selling Phase 2").replace("New lots coming in 2021", "New lots coming 2021").toLowerCase().replaceAll(remove.toLowerCase(), "");
		
		remove = U.getSectionValue(statSec, "<h2 class=\"script\">from <em>our blog</em></h2>", "<iframe src=");
		if(remove != null) statSec = statSec.replace(remove, "");
		
		if(sections != null)
		sections = sections.replace("New Phase May of 2021", "New Phase May 2021");
		
statSec=statSec.replace("new phase opening soon!</p>", "");
		status = U.getPropStatus((statSec+sections).replace("phase i &#8211; sold out", "phase i sold out").replace("Now Selling in Phase 2", "Now Selling Phase 2").replace("New Lots are on the way!  Looking to 2021", "New Lots Coming 2021"));
		U.log(Util.matchAll(statSec, "[\\w\\s\\W]{30}coming[\\w\\s\\W]{30}", 0));
		//Status from image
		if(comUrl.contains("https://www.mybuffington.com/new-homes-pflugerville-tx-villages-hidden-lake")){
			status = "Final Opportunity";//from image
		}
		
		if(comUrl.contains("new-homes-manor-tx-whisper-valley/")){
			maxPrice = "$399,990";//from image
		}

		/*String quickHtm = U.getHTML("https://www.mybuffington.com/quickmovein/");
		String qmiSection=U.getSectionValue(html, "<h1 class=\"uk-text-uppercase uk-text-secondary uk-text-center uk-text-bold\">Available Homes</h1>", "<script>");
		U.log(qmiSection);
		if (qmiSection!=null) {
			if (qmiSection.contains("<div class=\"banner \">Available</div>") && quickHtm.contains(commName)) {
				if (status.length()>2&&!status.contains("Quick")) {
					status+=", Quick Move In Homes";
				}else if (!status.contains("Quick")) {
					status="Quick Move In Homes";
				}
			}
		}*/
		

//		
		//---------------derived type------------
		html = U.removeComments(html);
		html = html.replaceAll("2-story gym & aerobics|Avery Ranch|Ranch Road|Ranch|ranch|branch|franchise| 3 bedroom a", "");
		if(combinedAvailableHtmls!=null)
		combinedAvailableHtmls=combinedAvailableHtmls.replaceAll("Avery Ranch|Ranch Road|Ranch|ranch|branch", "").replaceAll(" 3 bedroom a|4 bed|4 bedroom|4bed|5 bed", "");
		String dType = U.getdCommType(html+commName+combinedAvailableHtmls);
		
		//--------add data in csv---------------------
		data.addCommunity(commName.toLowerCase(), comUrl, communityType);
		data.addAddress(add[0].trim().replace("#", ""), add[1].trim(), "TX", add[3].trim());
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSq, maxSq);
		data.addNotes(ALLOW_BLANK);
		// TODO Auto-generated method stub

	}
	j++;
//		}catch(Exception e) {}
	}
}
