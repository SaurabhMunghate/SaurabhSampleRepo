/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_201_220;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractStevensFineHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractStevensFineHomes()
			throws Exception {
		super("Stevens Fine Homes","https://www.stevensfinehomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Stevens Fine Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractStevensFineHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Stevens Fine Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.stevensfinehomes.com/communities");
		U.bypassCertificate();
		String[] comSec=U.getValues(mainHtml, "<div class=\"builder-grid-item","</a>");
		for(String comData:comSec)
		{
			
			String comUrl=U.getSectionValue(comData, "href=\"","\"");
			U.log(comUrl);
			addDetails(comUrl,comData);
			//break;
		}
		LOGGER.DisposeLogger();
		
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	if(j>3)
	{
		//if(!comUrl.contains("https://stevensfinehomes.com/communities/cypress-grove-townes/"))return;
		
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"--->Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHTML(comUrl);
		
		/*String rem=U.getSectionValue(html, "<head>","$919,990");
		html=html.replace(rem,"");*/
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "<h3 class=\"builder-grid-title\">","</h3>");
		
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		String addSec=null;
		addSec=U.getSectionValue(html, "<h3 class=\"heading-title secondary listing-subtitle\">","</h3>");
		// if(comUrl.contains("/hampstead-pines"))addSec=U.getSectionValue(html, "<div class=\"address\">","</div>");
		U.log(addSec+"....");
		addSec=addSec.replace("NEW MODEL HOME COMING SOON to Pinnacle Point", "");
		if(addSec != null && !addSec.isEmpty()){
			addSec=addSec.replace("<br/>","").replace("Wilmington NC","Wilmington, NC").replace(" Hamsptead NC", " Hamsptead, NC")
					.replace(" North Carolina ", " NC ").replace("Hampstead NC ", "Hampstead, NC ")
					.replace("Leland NC ", "Leland, NC ");
			U.log(addSec+"<<<");
			add=U.findAddress(addSec);
		}
		U.log("Add ::"+Arrays.toString(add));
				
				
//--------------------------------------------------latlng----------------------------------------------------------------
		latlag[0]=U.getSectionValue(comData, "data-latitude=\"", "\"");
		latlag[1]=U.getSectionValue(comData, "data-longitude=\"", "\"");
//		String laSec=U.getSectionValue(html, "coordinates\": [","]");
//		U.log(laSec); 
//		String[] lat1=laSec.split(",");
//		if(lat1[0].contains("-")){
//			latlag[0]=lat1[1];
//			latlag[1]=lat1[0];
//		}else{
//			latlag[0]=lat1[0];
//			latlag[1]=lat1[1];
//		}
		
		if((add==null || add[0]==ALLOW_BLANK)&& latlag[0]!=null)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(add[1]!=ALLOW_BLANK && latlag[0]==null)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
//		if(comUrl.contains("the-pinnacle-at-mallory-creek-plantation")) {String temp=latlag[1];latlag[1]="-"+latlag[0];latlag[0]=temp;};
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]); 

//=========================================================================================
		String availHome="";
		String[] availSec=U.getValues(html, "<div class=\"builder-grid-item","</a>");
		for(String url:availSec){
			if(url.contains("google"))continue;
			url=U.getSectionValue(url, "href=\"","\"");
			
			U.log(url);
			String floorHtml = U.getHTML(url);
			if(floorHtml != null){
			String section = U.getSectionValue(floorHtml, "<main class=\"main listing ", "View Community</a>");
			if(section != null)
				availHome=availHome+section;
			else availHome=availHome+floorHtml;
			}
		}
		
		
		int quickCount = 0;
		String quickData=ALLOW_BLANK;
		String quickMoveSection = U.getSectionValue(html, "id=\"homes-detail\">", "</article>");
		if(quickMoveSection != null){
			String quickHomeSection[] = U.getValues(quickMoveSection, "homeplanitem\">", "</li>");
			U.log("Total Quick found :"+quickHomeSection.length);
			for(String quickSec : quickHomeSection){
				if(!(quickSec.contains("sold\">Sold</div>")||quickSec.contains("under-construction\">Under Construction")))quickCount++;
			//U.log("Quick Sec"+quickSec);
			String quickHomeUrl=U.getSectionValue(quickSec, "href=\"", "\"");
			quickData+=U.getHTML("https://www.stevensfinehomes.com"+quickHomeUrl);
			
			}
		}
		U.log(quickCount);
		
//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replace("from the $200’s", "from the $200,000").replace("low $200's", "start at $200,000").replaceAll("0�s|0&rsquo;s|0's|0&#8217;s|0s|0's","0,000");
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+comData+availHome+quickData, "[\\s\\w\\W]{30}200’s[\\s\\w\\W]{30}", 0));		
//		U.log("comData===="+comData);
        comData=comData.replace("starting from the $200s to the $300s", "starting from the $200,000 to the $300,000");
        comData=comData.replaceAll("0s|0's", "0,000");

     String prices[] = U.getPrices(html+comData+availHome+quickData,"from the \\$\\d{3},\\d{3} to the \\$\\d{3},\\d{3}|starting from the \\$\\d{3},\\d{3} to the \\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|<p>\\$\\d{3},\\d{3}</p>|From the \\$\\d{3},\\d{3}|<div class=\"starting_price\"><strong>\\$\\d{3},\\d{3}<|<span class=\"price\">\\$\\d{3},\\d{3}</span>|Starting in the low \\$\\d{3},\\d{3}|\\$ \\d{3},\\d{3}|price\">\\$\\d+,\\d+|Starting at \\$\\d+,\\d+|start at \\$\\d+,\\d+|Low \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|upper \\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		//U.log(U.getSectionValue(html, "<!-- <span class=\"price\">", "<"));
		//U.log(html.contains("<!-- <span class=\"price\">"));
//======================================================Sq.ft===========================================================================================		
		//availHome frm may
		
		String[] sqft = U
				.getSqareFeet(
						html+comData+availHome,
						"over \\d,\\d{3} square feet|<strong>\\d{4}-\\d{4}</strong> Sq. Ft.|<strong>\\d{4}</strong> Sq. Ft.|\\d{4} SQ. Ft.|\\d,\\d+ to \\d,\\d+ square feet|[1-9]\\d+</span> Sq Ft|[1-9],\\d+ square feet",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		html =html.replace("craftsman designs", "Craftsman-style home");
		String communityType=U.getCommType(html+comData);
		
//==========================================================Property Type================================================
		html = html.replace("coastal charm of living", "Coastal community").replace("Twin-Villas", "Twin home-Villas").replaceAll("luxury interior finishes", "luxury homes interior finishes");
		
		
		String proptype=U.getPropType((html+availHome).replaceAll("Coastal living at it&#8217;s finest|feature coastal craftsman style exteriors with|"
				+ "flex room that can serve as a media|gorgeous coastal cottage trim details", ""));
		
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+availHome, "[\\s\\w\\W]{30}coastal cottage[\\s\\w\\W]{30}", 0));		
		U.log("proptype : "+proptype);
		
//==================================================D-Property Type======================================================
		availHome=availHome.replace("</span><span>Story"," Story");
		String dtype=U.getdCommType(html+comData+availHome);
		
//==============================================Property Status=========================================================
		
		html=html.replace("Now Selling in Phase 2", "Now Selling Phase 2")
				.replace("Now Selling in the Final Phase", "Now Selling Final Phase");
		html=html.replaceAll("<p>NEXT TOWNHOME COLLECTION COMING SOON!&nbsp|1270 Dabney Park Drive Now Open!</p>|opening offers|Opening Offers|"
				+ "opportunities remain in this|"
				+ "opportunities remain, please|Available Move-in Ready Homes</h3>|title=\"Available Move-in Ready Homes\">","");
		
		String pstatus=U.getPropStatus(html+comData);
		U.log("pstatus : "+pstatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+comData, "[\\s\\w\\W]{30}collection[\\s\\w\\W]{30}", 0));	
		/*
			 * if(comUrl.equals(
			 * "https://www.stevensfinehomes.com/communities/hampstead-pines")) {
			 * pstatus=pstatus+", Coming Soon";//note: coming soon from image
			 * 
			 * }
			 */
		
/*		if(html.contains("<a class=\"overlay-trigger\" href=\"/quick-move-in-homes/") && !pstatus.contains("Move-in")){
			if(pstatus.length()<4){
				pstatus = "Quick Move-In Homes";
			}
			else{
				pstatus = pstatus + ", Quick Move-In Homes";
			}
		}*/
		
		if(quickCount > 0 && !pstatus.contains("Move-in")){
			if(pstatus.length()<4){
				pstatus = "Quick Move-In Homes";
			}
				/*
				 * else{ pstatus = pstatus + ", Quick Move-In Homes"; }
				 */
		}
		
		pstatus = pstatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon");
//============================================note====================================================================
	//	if(comUrl.contains("https://www.stevensfinehomes.com/communities/dabney-park"))maxPrice="$298,280";
		 note=U.getnote(html);
		

		if(add[2].length()>2)
		{
		add[2] = USStates.abbr(add[2]);
		}
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
	j++;
	}

}
