package com.shatam.b_221_240;

public class EmpireCommunities {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
