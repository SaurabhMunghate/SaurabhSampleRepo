/*sampada santosh*/
package com.shatam.b_221_240;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractCachetHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://www.cachethomes.net/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCachetHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Cachet Homes.csv", a.data()
				.printAll());
 
	}

	public ExtractCachetHomes() throws Exception {

		super("Cachet Homes", "https://www.cachethomes.net/");
		LOGGER = new CommunityLogger("Cachet Homes");
	}

	public void innerProcess() throws Exception {
		String basehtml = U.getHTML("https://www.cachethomes.net/find-a-home/");
		String section = U.getSectionValue(basehtml,
				"<section id='community'", "</section>");
		//U.log(section);
		String values[] = U.getValues(section,
				"<div class='is-community-card'>",
				">Explore this Community</a>");
//
		for (String value : values) {
			String url = U.getSectionValue(value, "<a href='", "'");
			String name = U.getSectionValue(value, "<h2 class='is-title'>", "<");
			U.log("url : " + url);
			U.log("name : " + name);
			addDetails(url, name,value);

		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String url, String communityName,String value) throws Exception {
	//TODO : For Single Community Execution	
//	if(j == 2)
		
//		try{
	{ 
//		if(!url.contains("https://www.cachethomes.net/locations/peak-view/")) return;
		
//		if(!url.contains("https://www.cachethomes.net/locations/cachet-encore-at-union-park/"))return;
    //   if(!url.contains("https://www.cachethomes.net/locations/cachet-at-the-post/")) return;
		
		if(data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url+"------------> Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(url);

		
		
		String html = U.getHTML(url);
		
		
		String remove = U.getSectionValue(html,"<h2 class='is-title'>Available Communities</h2>", "</div>");
		if(remove!=null)
			html = html.replace(remove, "");
		
		//U.log("comSec ::"+value);
		// -----------adress---------//

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		html = html.replace("pdf\" target=\"_blank\" rel=\"noopener", "");
		String ad = U.getSectionValue(html,
				"target='_blank' class='loc-link'>",
				"</a>");
//		U.log("address sec--> "+ad+"*&*&*");
		if(value.contains("https://www.google.com/maps/")) {
			ad = U.getSectionValue(value, "https://www.google.com/maps/", "/@");
			ad = ad.replace(",USA", "").replace("+", " ").replace("%26", "&").replaceAll("dir//|place/", "").replace("AZ ", "AZ,").replace("E Gold Dust Ave & N 124th St", "124th Street and Gold Dust");
			U.log(".............."+ad);
			add = ad.split(",");
		}

		if (ad != null && add[0]==ALLOW_BLANK) {
			ad = ad.replace("<br />", ",").replace(" | ", ",").replace("<p style=\"text-align: center;\">", "").replace(",+", ",").replace("+", " ")
					.replaceAll("<h3 .*>.*</h3>", "");
			U.log("addSec ::"+ad);
			if(ad.contains(",")) {
				add = U.getAddress(ad);
				U.log("address is : "+Arrays.toString(add));
			}

		}

		String geo = "FALSE";
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "<div class=\"list-group-item\" data-link='", "</div>");
		if(latLongsec == null) latLongsec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/", "</a>");
		U.log("latLongsec ::"+latLongsec);
		if (latLongsec != null) {
			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		
		if(value.contains("https://www.google.com/maps/")) {
			
			latLongsec = U.getSectionValue(value, "/@", "/");
			latLong = latLongsec.split(",");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
		}
		
		
		if(url.contains("https://www.cachethomes.net/locations/peak-view/")) {
			
			add[0] = "Desert View Village";
			add[1] = "Phoenix";
			add[2] = "AZ";
			add[3] = ALLOW_BLANK;
			
			latLong = U.getlatlongGoogleApi(add);
		}
		
		
		if (add[0].length() == 0) {
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressGoogleApi(latLong);
				
			add[0] = addr[0];
			geo = "TRUE";
		}
		if (add[3].length() <2 ) {
			String addr[] = U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		if(add[0]==null||add[0]==ALLOW_BLANK)
		{
			add = U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressGoogleApi(latLong);
			geo ="True";
			
		}
		if(latLong[0].length()<4 && add[0]!=ALLOW_BLANK)
		{
			latLong = U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongGoogleApi(add);
			geo ="True";
			
		}
		

		// ---------community type,property type,property status,derived,
		// property type---------//
		//---------Quick homes data-------------
		String allQuickSec = ALLOW_BLANK;
		String quickhtml=ALLOW_BLANK;
		if(html.contains("\">VIEW QUICK-MOVE HOMES AND HOMES UNDER CONSTRUCTION&gt;</a>")||html.contains("VIEW QUICK-MOVE HOMES &gt;</a>")||html.contains("VIEW INVENTORY HOMES &gt;</a")||html.contains("View Inventory Homes ></a>"))
		{
//			U.log("quickUrl: "+U.getSectionValue(html, "<a class=\"btn\" href=\"", "\">VIEW INVENTORY HOMES &gt;</a>"));
//			U.log("quickUrl : "+"https://www.cachethomes.net/quick-move/#"+communityName.toLowerCase().replace(" ", "-").replace("union-park", "union"));
			String quikurl=U.getSectionValue(html, "<a class=\"btn\" href=\"", "\">VIEW QUICK-MOVE HOMES &gt;</a>");
			if(quikurl==null)quikurl=U.getSectionValue(html, "<a class=\"btn\" href=\"", "\">VIEW INVENTORY HOMES &gt;</a>");
			if(quikurl==null)quikurl=U.getSectionValue(html, "<a class=\"btn btn-block\" href=\"", "\">VIEW QUICK-MOVE HOMES &gt;</a>");
			if(quikurl==null)quikurl=U.getSectionValue(html, "<p style=\"text-align: center;\"><a class=\"btn\" href=\"", "\">VIEW QUICK-MOVE HOMES");
			if(quikurl==null)quikurl=U.getSectionValue(html, "<a class='is-button is-highlight-button is-solid' href='", "'");
			U.log("quickUrl : "+quikurl);
			if(!quikurl.startsWith("https"))
				quikurl="https://www.cachethomes.net"+quikurl;
			quickhtml = U.getHTML(quikurl);
			
			String[] quickComSec = U.getValues(quickhtml, "<div class=\"rooms", "<div class=\"pop-more-info\"");
			U.log("Found Quick Homes For Comm. Count ::"+quickComSec.length);
			for(String quick : quickComSec){
				//U.log("--------------\n"+quick);
				if(quick.contains(communityName.toLowerCase().replace(" ", "-").replace("union-park", "union")) && !quick.contains("No Move-in Ready Homes Available")){
//					U.log("============"+Util.matchAll(quick, "[\\s\\w\\W]{30}union[\\s\\w\\W]{30}",0));
					allQuickSec = quick;
					U.log("*** Found Quick Move ***");
					break;
				}else if(url.contains("https://www.cachethomes.net/locations/cachet-at-the-post/")&&quick.contains("Etsy-Cover-Photo.png")) {
					allQuickSec = quick;
					U.log(" Found Quick Move ***");
					break;
				}
				//allQuickSec=quick;
			}
		}
//		U.log("All quick section is"+allQuickSec);
		
		
		
		html = html.replaceAll("Outdoor-courtyard.jpg|wigwam/luxury-townhomes/\">Luxury Townhomes</a></li>|center;\">COMING SOON|wigwam/single-family-homes/\">Single Family Homes</a></li>|wigwam/luxury-condominiums/\">Luxury Condominiums</a></li>|arget=\"_blank\" rel=\"noopener\">master plan website<", "");
		html =html.replace(U.getSectionValue(html, " <ul id=\"menu-main-left\" cl", "<div id=\"main\">"), "");
		
		allQuickSec=allQuickSec.replaceAll("<li>2-Story</li>", " 2 Story ");
		String commType = U.getCommunityType(html.replace("homes in a gated community", ""));

/*		String rem = U.getSectionValue(html, "<script type=\"application", "</script>");
		if(rem != null) html = html.replace(rem, "");
*/		
		String rem = U.getSectionValue(html, "<ul class=\"sub-menu\">", "</div>");
		if(rem != null) html = html.replace(rem, "");
		
		if(allQuickSec!= null) allQuickSec = allQuickSec.replace("Villa Plan", "villas");
		
		
		String propType = U.getPropType((html+allQuickSec).replaceAll("\"Luxury custom homes\",\"custom home|\"condo\",\"townhome\",\"single family home developers\"|Single Family Home</option|Single Family Homes</a|single-family-homes/\"", ""));
		String dpType = U.getdCommType((html+allQuickSec).replaceAll("Gainey Ranch|McCormich Ranch|1st floor</li>", ""));
		
		
		html = html.replace("Coming soon &#8211; Fall, 2021", "Coming soon Fall 2021").replace("Coming Soon Summer, 2022","COMING SOON SUMMER 2022").replace("Coming &#8211; Summer, 2022", "Coming Summer 2022").replaceAll("Coming  &#8211; Fall, 2021|Coming Fall, 2021", "Coming Fall 2021").replace("Phase I is now sold out", "Phase I sold out")
				.replaceAll("location-status coming-soon'>Coming Soon!</p>|<p>Coming Soon</p>", "").
				replace("Coming Soon Fall, 2021", "Coming Soon Fall 2021").replace("Coming Soon Early 2022!", "COMING SOON EARLY 2022").replace("Coming Soon Summer, 2022!","COMING SOON SUMMER 2022").replace("Coming Soon Fall, 2021!","COMING SOON FALL 2021").replace("COMING SOON LATE 2021!","COMING SOON LATE 2021")
				.replace("Coming Soon Late 2021!", "COMING SOON LATE 2021");
		        
		String commStatus = ALLOW_BLANK;
		
		
		if(value!=null)
			value = value.replaceAll("calendar.svg' />Coming soon|coming-soon'|location-status coming-soon'>Coming Soon","");
		html=html.replaceAll("Coming Soon Spring, 2022", "Coming Soon Spring 2022");
		    commStatus=U.getPropStatus(U.getNoHtml(html.replace("Sales Grand Opening &#8211; May 20, 2022", "").replace("COMING SOON SUMMER, 2022", "COMING SOON SUMMER 2022").replaceAll("coming-soon'|location-status coming-soon'>Coming Soon!|<p>Coming Soon</p>|<p>Now Sold|Coming-Soon-|\">SOLD OUT</p>|\">NOW SOLD OUT</a>|<p>Sold out.</p>|custom homes on the few remaining lots within", "")+value));
		//commStatus=U.getPropStatus(html);
		 //   U.log(Util.matchAll(U.getNoHtml(value+html.replaceAll("coming-soon'|location-status coming-soon'>Coming Soon!|<p>Coming Soon</p>|<p>Now Sold|Coming-Soon-|\">SOLD OUT</p>|\">NOW SOLD OUT</a>|<p>Sold out.</p>|custom homes on the few remaining lots within", "")), "[\\s\\w\\W]{30}coming[\\s\\w\\W]{30}", 0));
		U.log("Property status is:"+commStatus);
		
//		U.log(">>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));


		//if(html.contains("Oversized Homesites Available"))
			//commStatus=commStatus+","+"Oversized Homesites Available";
		
//		U.log("match:::::::::::::"+Util.matchAll(value+html, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
		
//		commStatus=commStatus.replace("Quick-move Homes", "");
//		
//		if(allQuickSec.length()>318 && !commStatus.contains("move-in")){
//			if(commStatus==ALLOW_BLANK){
//				commStatus = "Move-In Ready Homes";
//			}
//			else{
//				commStatus = commStatus+", Move-In Ready Homes";
//			}
//		}
//		commStatus=U.getPropStatus(commStatus);
		// --prices---//
		allQuickSec=allQuickSec.replaceAll("<del>.*</del>|<del>\\$\\d{3},\\d{3}</del>", "");
		html = html.replace("$2 million", "$2,000,000").replace("Two Millions", "$2,000,000").replaceAll("0's|0&#8217;s|0’s", "0,000").replace("1.5 million", "1,500,000 million").replace("1.6 million", "1,600,000").replace("$1.7 million", "Priced at 1,700,000")
				.replace("$500&#8217;s", "$500,000").replace("Homes priced in the Two Millions", "from the $2,000,000");
		String[] price = U.getPrices(html+allQuickSec,
				"\\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|From the high \\$\\d{3},\\d{3}|from the mid \\$\\d{3},\\d{3}|price'>\\s*From\\s*\\$\\s* \\d{3},\\d{3}</span>|From the low \\$\\d{3},\\d{3}|<p>\\$\\d{3},\\d{3}</p>|Priced at \\$\\d+,\\d+,\\d+|Priced at \\$\\d+,\\d+|Starting at \\$\\d+,\\d+,\\d+|Starting at \\$\\d+,\\d+|\\$\\d+,\\d+,\\d+|Priced at \\$\\d+,\\d+,\\d+|\\$\\s+\\d{3},\\d{3}</strong></p>", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		//U.log("match:::::::::::::"+Util.matchAll(quickhtml, "[\\s\\w\\W]{30}600[\\s\\w\\W]{30}", 0));
		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		U.log(allQuickSec);
		String[] sqft = U.getSqareFeet(html+allQuickSec, "\\d,\\d{3} Sq\\. Ft\\.</p>|<li>\\s+\\d,\\d{3} Square Feet\\s+</li>|<li>\\d,\\d{3} Square Feet</li>|home \\d,\\d+ sq. ft|\\d+,\\d+ - \\d+,\\d+ Square| \\d+,\\d+ to \\d+ square feet |\\d+,\\d+ Square Feet|\\d,\\d{3} sq ft. on over|\\d,\\d{3} sq. ft.", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		if(url.contains("/sincuidados/")) {minSqf="4140";maxSqf="4196";commStatus="Few Remaining Lots, "+commStatus;}
		
//		commStatus = commStatus.replace("Quick Move-in", "Quick Move In Homes");
		if(url.contains("https://www.cachethomes.net/emerald-hills/")) commStatus = "Coming Soon Fall 2021";
		
//		if(url.contains("https://www.cachethomes.net/union-park/"))commStatus=commStatus.replace("Sold Out", "Phase I Sold Out");
		if(url.contains("https://www.cachethomes.net/locations/peak-view/")) {
		//commStatus="Coming Soon Late 2021";
		propType += ", Luxury Homes";//img
		}
		//U.log(allQuickSec);
		// ---notes-----//
//if(url.contains("https://www.cachethomes.net/union-park"))commStatus=commStatus.replaceAll(", Quick Move In Homes|, Coming Fall 2021", "");
		String lotMapUrl = U.getSectionValue(html, "allowfullscreen=\"allowfullscreen\" data-aa-src=\"", "\"></iframe></p>");
		String lotIds="";
		if(lotMapUrl!=null) {
			String lotHtml = U.getHTML(lotMapUrl);
			String comId = U.getSectionValue(lotHtml, "VIP.Main.setup('", "',");
			if(comId!=null) {
				lotHtml = U.getHTML("https://contradovip.com/site.get.php?rid="+comId);
				lotIds = Util.matchAll(lotHtml, "displayname=\"Homesite ", 0).size()>0?Util.matchAll(lotHtml, "displayname=\"Homesite ", 0).size()+"":ALLOW_BLANK;
			}
		}
		if(lotIds.length()<1)lotIds=ALLOW_BLANK;
		U.log(communityName);
		data.addCommunity(communityName.replace("Wigwam", "The Wigwam").replaceAll("by Cachet Homes", "").trim(), url, commType);
		data.addAddress(U.getNoHtml(add[0]), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
//		U.log(commStatus);
		data.addPropertyStatus(commStatus.replace("Ii", "II")); 
		data.addNotes(U.getnote(html+value)); 
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}j++;
	
//		}catch (Exception e) {}
	}

}