/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMcKeeBuilders extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractMcKeeBuilders()
			throws Exception {
		super("McKee Builders","https://mckeebuilders.com/");
		// TODO Auto-generated constructor stub 
		LOGGER=new CommunityLogger("McKee Builders");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractMcKeeBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McKee Builders.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://mckeebuilders.com/find-your-new-home/");
		String section=U.getSectionValue(mainHtml,"<section class=\"state","<div class=\"footer-contact");
		//U.log(section);
		String sta[]=U.getValues(mainHtml, "if(title == '", "</a>");
		String[] comInfo=U.getValues(section, "<p class=\"name","Visit Community");
		for(String comData:comInfo)
		{
			//U.log(comData);
			String comUrl=U.getSectionValue(comData,"href=\"","\"");
			
			if(comUrl.contains("javascript"))continue;
			if(!comUrl.contains("http"))
			{
				comUrl="http:"+comUrl;
			}
			if(!comUrl.contains("https:") && !comUrl.contains("thegroveatfenwick"))
			{
				comUrl=comUrl.replace("http:", "https:");
			}
//			U.log(comUrl);
//			try {
				addDetails(comUrl,comData,mainHtml,sta);
//			} catch (Exception e) {}
		}	
		//addDetails("https://weatherbynj.com/", "", "", new String[]{});
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData,String mainHtml,String[] sta) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://baybridgecove.com/"))return;

		//		try {
		
		U.log(j+"   commUrl-->"+comUrl);
	
		if(comUrl.equals("http://whisperingwoodsde.com/"))comUrl="https://whisperingwoodsde.com/";
		if(comUrl.equals("http://thegroveatfenwick.com"))comUrl="https://thegroveatfenwick.com";
		
		if(comUrl.contains("https://winchelsea.mckeebuilders.com")) {
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------RETURNING");
			return;
		}
		
		String html=U.getHTML(comUrl);
		//============================================Community name=======================================================================
//		U.log(comData);
		String communityName=U.getSectionValue(comData, "\">","<");
		if(communityName == null) communityName=U.getSectionValue(html, "<div class=\"comm-name\">","</div></a>");
		communityName=communityName.replaceAll("’|'","").replace("&#8217;", "");//.replaceAll("- (.*?)$", "");
		if(communityName.contains("<a"))
			communityName=communityName.replaceAll("<a(.*?)>", "");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String locatinHtml=ALLOW_BLANK;
		String addSec=null;

		locatinHtml=U.getHTML(comUrl+"/directions");
		
/*		if(comUrl.contains("https://55kentcounty.com"))
				 locatinHtml=U.getHTML(comUrl+"directions");
*/		
		
		
		if(locatinHtml==null )
			 locatinHtml=U.getHTML(comUrl+"/location/");
		if(locatinHtml==null )
			 locatinHtml=U.getHTML(comUrl+"/contact-us/");
		
		
 //----------------------------------------------------------------------------------------------------------------

		 String ss="";
		 if(locatinHtml!=null)
		 {
			 addSec=U.getSectionValue(locatinHtml, "GPS Address:","</p>");
		 }
		 
		if(comUrl.contains("thegroveatfenwick.com"))
		{
				locatinHtml=U.getHTML("https://thegroveatfenwick.com/contact-us");
				addSec = U.getSectionValue(locatinHtml, "GPS Address: <strong>", "</strong></p>");
				addSec = addSec.replace("Road Selbyville", "Road, Selbyville");
				String[] temp = U.getSectionValue(locatinHtml, "!2d", "!2m").split("!3d");
				latlag[0] = temp[1];
				latlag[1] = temp[0];
				U.log(addSec);
		}
		
		if(comUrl.contains("whisperingwoodsde.com"))
		{
				locatinHtml=U.getHTML("https://whisperingwoodsde.com/site-map/");
				addSec = U.getSectionValue(locatinHtml, "GPS Address:", "</p>");
				addSec = addSec.replace(" Middletown", ", Middletown");
				
		}
		
		if(comUrl.contains("preserveatmarshcreek.mckeebuilders.com"))
		{
				locatinHtml=U.getHTML("https://preserveatmarshcreek.mckeebuilders.com/site-map/");
				addSec = U.getSectionValue(locatinHtml, "GPS Address:", "</p>");
				addSec = addSec.replace(" Downingtown", ", Downingtown");
				U.log(addSec);
		}
		
		 if(comUrl.contains("mckeebuilders.com/cecil-woods"))
		{
				locatinHtml=U.getHTML("http://55plusmd.com/");
				addSec=U.getSectionValue(locatinHtml, "streetAddress\">","</span>")+","+U.getSectionValue(locatinHtml, "addressLocality\">","</span>")+
						","+U.getSectionValue(locatinHtml, "addressRegion\">","</span>")+" "+U.getSectionValue(locatinHtml, "postalCode\">","</span>");
				ss="LAST CHANCE,Only a few homes left";
			}
 //-------------------------------------------------------------------------------------------------------------------
		 U.log(addSec);
		 if(addSec!=null)
		 {
			 
		 addSec=addSec.replace("310 Milford Road Downingtown PA, 19335", "310 Milford Road, Downingtown, PA 19335").replaceAll("GPS Address: ", "").replaceAll("<br />|</strong>","").replace(" DE, ", ",DE ").replace("Road  Selbyville", "Road , Selbyville").replaceAll("Drive Stevensville", "Drive,Stevensville").replaceAll("Rd Middletown", "Rd,Middletown").replaceAll("Drive Magnolia", "Drive,Magnolia");
		U.log("aaaaaa "+addSec);
		 String[] add1=addSec.split(",");
		 U.log("add::"+Arrays.toString(add1));

		 if(add1.length>2)
		 {
			 add[0]=add1[0];
			 add[1]=add1[1].replaceAll("^ Selbyville", "Selbyville");
			 add[3]=Util.match(add1[2],"\\d{5}");
			 if(add[3]!=null)
			 {
			 add[2]=add1[2].replace(add[3],"").trim();
			 add[2]=U.getNoHtml(add[2].replace("Get Directions", ""));
			 }
			 else
			 {
				 add[2]=add1[2];
			 }
		 }
		 else if(add1.length==2)
		 {
			 add[1]=add1[0];
			 add[3]=Util.match(add1[1],"\\d{5}");
			 add[2]=add1[1].replace(add[3],"").trim();
		 }
		 }
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
		add[0]=add[0].trim();
		if(locatinHtml==null)
			locatinHtml=" ";
		String laSec=U.getSectionValue(locatinHtml, "map\" lat","gps-address");
		
		if(laSec==null)
		{
			laSec=U.getSectionValue(html,"maps.LatLng(", ")");
		}
		if(laSec==null) {
			laSec=U.getSectionValue(locatinHtml, "var locations = [","];");
		}
		if(laSec!=null)
		{
			U.log(Util.match(laSec, "\\d{2,3}.\\d+"));
		
		latlag[0]=Util.match(laSec, "\\d{2,3}.\\d+");
		latlag[1]=Util.match(laSec,"-\\d{2,3}.\\d+");
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		}
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		
		//------------fetching latlng from main Page----------
		String mainLatLngSec  = U.getSectionValue(mainHtml, "['"+communityName.trim()+"',", "]");
		U.log("hello"+mainLatLngSec);
		if(mainLatLngSec != null && latlag[0] == ALLOW_BLANK){
			latlag[0] = Util.match(mainLatLngSec, "\\d{2,3}\\.\\d+");
			latlag[1] = Util.match(mainLatLngSec, "-\\d{2,3}\\.\\d+");
			add = U.getAddressGoogleApi(latlag);
			geo = "TRUE";
		}
		
		//============ Quick Move In ==============
		String quickMoveInSec = U.getSectionValue(html, "<li class=\"Quick-Deliveries\">", "</a>");
		String quickHtml = null;
		if(quickMoveInSec != null){
			String quickUrl = U.getSectionValue(quickMoveInSec, ";\" href=\"", "\"");
			
			if(quickUrl != null)
			quickHtml = U.getHTML(quickUrl);
			U.log(U.getCache(quickUrl));
		}
		
		if(comUrl.contains("https://55kentcounty.com")) quickHtml = U.getHTML("https://55kentcounty.com/quick-deliveries/");
		
		String p=ALLOW_BLANK;
//		if(comUrl.contains("baybridgecove.com"))
//		{
//			String quickMoveInHTML = U.getHTML("https://baybridgecove.com/quick-deliveries/");//U.getSectionValue(html, "<li class=\"Quick-Deliveries\">", "</a>");
//			
//			String quickUrl = U.getSectionValue(quickMoveInHTML, "href=\"", "\"");
//			U.log("quickUrl : "+quickUrl);
//			if(quickMoveInHTML != null)
//			quickHtml =quickMoveInHTML;
//			p="Quick Delivery Homes";
//			
//		}
//		U.log(quickHtml);
		String quickData=ALLOW_BLANK;
		if (comUrl.contains("https://thegroveatfenwick.com")) {
			quickData = U.getHTML(comUrl+"/move-in-quick");
		}else {
			quickData = U.getHTML(comUrl+"/quick-deliveries");
		}
//		U.log(quickData);
		//====== Remove Section ===========
		String remSec = U.getSectionValue(html, "<div id=\"seo\">", "<section class");
		if(remSec != null)
			html = html.replace(remSec, "");
//============================================Price and SQ.FT======================================================================
		String homeHtml="";
		if(comUrl.contains("thegroveatfenwick.com"))
		{
			quickHtml=U.getHTMLwithProxy("https://thegroveatfenwick.com/move-in-quick");
		}
		if(html.contains("home-models\">")||html.contains("<div class=\"img-frame\">"))
		{
			//String[] url=U.getValues(html, "<h2 itemprop=\"name\">","More</a>");//<div class="model">
			String[] url=U.getValues(html, "<div class=\"model","View");
			if(url.length<1)
			{
				url=U.getValues(html, "<div class=\"img-frame\">","</a></div>");
			}
			for(String url1:url)
			{
				if(comUrl.contains("thegroveatfenwick.com"))
					url1=U.getSectionValue(url1, "<a href=\"", "\">");
				else
					url1=U.getSectionValue(url1, "data-link=\"", "\"");
				U.log("homes Url::::::::"+url1);
				if(!url1.contains("http" ))
				{
					url1="http:"+url1;
				}
				
				String home = U.getHTML(url1);
				String rem = U.getSectionValue(home, "<aside class=\"more-posts full\">", "</aside>");
				
				if(rem!=null)
					home = home.replace(rem, "");
				
				homeHtml+= home;
			}
//			homeHtml=homeHtml.replaceAll("<li>From \\$254,900</li>", "");
		}
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comData=comData.replaceAll("0�s|0's|0&#8217;s|0s|0k's","0,000");
		if(!html.contains("00,000s"))
			html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0's","0,000");
		if (quickHtml!=null) {
			quickHtml=quickHtml.replaceAll("Was: \\$\\d{3},\\d{3}...||from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|<strong>Was \\$\\d{3},\\d{3}... ", "");
		}

		
//		U.log("comData :::"+comData);
//		if(html.contains("394")) {U.log(">>>>>>>>>>>."+"FOUND");}
		String prices[] = U.getPrices((html+locatinHtml+homeHtml+quickHtml+quickData+comData).replace("From $360,900", "").replace("From $537,900", ""),
				"<strong>From \\$\\d{3},\\d{3}<|\\$\\d{3},\\d{3}</strong></p>|NOW \\$\\d{3},\\d{3}</p>|NOW \\$\\d{3},\\d{3}</strong>|price\">\\$\\d+,\\d+|From <b>\\$\\d+,\\d+|price\">\\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}| Mid \\$\\d{3},\\d{3}|from the upper \\$\\d{3},\\d{3}|<strong>[\\$]*\\d{3},\\d{3}|the High \\$\\d{3},\\d{3}", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		U.log("Price--->"+minPrice+" "+maxPrice);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+locatinHtml+homeHtml+quickHtml+quickData+comData, "[\\s\\w\\W]{60}\\$380[\\s\\w\\W]{60}", 0));
//======================================================Sq.ft===========================================================================================		
//		U.log(homeHtml);
		
		String[] sqft = U
				.getSqareFeet(
						html+locatinHtml+homeHtml+quickData+quickHtml+comData,
						"\\d,\\d{3} Sq. Ft.|\\d,\\d{3}  sq ft|\\d+,\\d+</b> Sq Ft.|sqft\">\\d,\\d{3}|\\d{4} SQ.FT|\\d+,\\d+ square feet|\\d,\\d{3} SQ|\\d{4} sq. ft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		String remm=U.removeSectionValue(html, "Questions or comments\"><", "<p>Schedule a virtual appointment</p>");
		if(remm!=null) {
			html = html.replace(remm,"" );
		}
		String remm1=U.removeSectionValue(locatinHtml, "Questions or comments\"><", "<p>Schedule a virtual appointment</p>");
		if(remm1!=null) {
			locatinHtml = locatinHtml.replace(remm1,"" );
		}
		html = html.replaceAll("many of the 55+ community locations were just too rural for us|alt=\"Active|Active Adult Retirement Communities", "");
		String communityType=U.getCommType(html+locatinHtml+comData);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+locatinHtml, "[\\s\\w\\W]{60}55+ Community[\\s\\w\\W]{60}", 0));

		
		U.log("Ctype::"+communityType);
		
//==========================================================Property Type================================================
		html = html.replaceAll("value=\"Courtyards|/> Courtyards|>Carriage Homes", "");
		locatinHtml = locatinHtml.replaceAll("Coastal Kayak|Coastal Taquería|value=\"Courtyards|/> Courtyards", "");
		html = html.replace("Luxury 55+", "luxury homes 55+");
		if(quickHtml != null)
		quickHtml = quickHtml.replaceAll("value=\"Courtyards|/> Courtyards", "");
		
		html = html.replaceAll("<meta name=.*\">|55\\+ Carriage Homes", "");
		html=html.replace("Single, Twin and Carriage"," Single Family , Twin homes and Carriage home ");
		html=html.replace(" Maryland, this luxurious 5", "luxury homes").replace("Luxury Carriage Homes", "Luxury Homes,Carriage Homes");
		String proptype=U.getPropType((html+locatinHtml+homeHtml+quickHtml+comData)
				.replaceAll("\"The Oxford Carriage Home|<title>The Oxford Carriage Home|Carriage Homes in Kent Island|fireplace and loft area|features a loft with bedroom and bath|Carriage Homes in Kent Island, MD|-furnished-patio|Ev-courtyard-1.jpg", "").replace("Build a Semi Custom dream home", ""));
//		U.log(">>>>>>>>>>"+Util.matchAll(html+locatinHtml, "[\\w\\s\\W]{30}Carriage[\\w\\s\\W]{30}", 0));
		U.log("PType::"+proptype);
		
//==================================================D-Property Type======================================================
		
		if(homeHtml != null) homeHtml = homeHtml.replace("2nd floor loft", "2 story loft");
		
		String dtype=U.getdCommType((html+locatinHtml+quickHtml+homeHtml+comData));//.replaceAll("1st floor|first floor|1st Floor</li>", "1 story").replaceAll("second floor|2nd Floor", "2 story")
	
//		U.log("SSSSSSSSSSS "+Util.matchAll(html+locatinHtml, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));

		
		
		//	if(comUrl.contains("http://mckeebuilders.com/communities/the-grove"))dtype = "1 Story,2 Story";
//==============================================Property Status=========================================================
		
		html = html.replaceAll(" pond views are now available|sales center is now open|Sales Center Now Open|\"Coming soon|Dalton Grand Opening Event|Coming soon to Fenwick|Arbor - <strong>SOLD|class=\"sold|Out!</span>|Available - Click Here|SOLD OUT</strong>|move in date", "");
		String remSec1 = U.getSectionValue(html, "<aside class=\"qd\">", "</aside>");
		if(remSec1 != null)
			html = html.replace(remSec1, "");
		for (String s :	 sta) {
			if (s.contains(communityName.trim())) {
				//U.log(s);
				ss=ss+s;
			}
		}
		
		String popUp = U.getSectionValue(html, "<div class=\"main-screen\">", "<div class=\"form-cont\">");
		
		html=U.removeSectionValue(html, "<p class=\"main\">Move In Quick!</p>", "</section>")+U.removeSectionValue(html, "<footer class=\"new-footer\">", "</body>");
		
		String pstatus=U.getPropStatus((html+comData+ss+popUp).replaceAll("SOLD OUT!</p>|-sold-out|<span>sold out\\!|lubhouse [G|g]rand|Model Grand|<p class=\"green\" style=\"text-transform:uppercase; font-weight:bold; font-size:24px;\">SOLD OUT!</p>|<p>This popular 55+ McKee community is now <span>sold out!</span></p>|<span>1 Home Remaining</span>|McKee community is now <span>sold out|<span>Final chance</span><br/> to live at| with last homes available and model home specials!</p>|-sold-out|Coming soon! A brand new community|Quick Delivery|Coming soon, a brand new|sales center is now open|Center is now|you’re ready to move in!|Models Are Now|Amenities <b>NOW OPEN|/quick-delivery-homes/\">Quick Delivery Homes</a>", ""));
		U.log("status::: "+pstatus);
//		U.log("SSSSSSSSSSS "+Util.matchAll(html, "[\\s\\w\\W]{30}grand opening[\\s\\w\\W]{30}", 0));
//		U.log("SSSSSSSSSSS "+Util.matchAll(comData, "[\\s\\w\\W]{30}grand opening[\\s\\w\\W]{30}", 0));
//		U.log("SSSSSSSSSSS "+Util.matchAll(popUp, "[\\s\\w\\W]{30}grand opening[\\s\\w\\W]{30}", 0));

		/*if(quickData != null)
		{
			//U.log(quickData);
			if(!quickData.contains("Currently we have no Quick Deliveries")){
			if(pstatus.length()<4 ||pstatus==ALLOW_BLANK)
			{
				pstatus="Quick Delivery Homes";
			}
			else if(!pstatus.contains("Quick Delivery Homes"))
			{
			pstatus=pstatus+", Quick Delivery Homes";
			}
			}
		}*/
		if(quickHtml!=null || (quickData!=null && quickData.contains("<div class=\"qd-title\">")))
			if(pstatus.length()<4 ||pstatus==ALLOW_BLANK)
			{
				pstatus="Quick Delivery Homes";
			}
			else if(!pstatus.contains("Quick Delivery Homes"))
			{
			pstatus=pstatus+", Quick Delivery Homes";
			}
		if(pstatus.length()<4)
			pstatus=p;
		
		if(comUrl.contains("55kentcounty")) {
			
			pstatus = "Sold Out"; 
			/*proptype = ALLOW_BLANK;
			minPrice = ALLOW_BLANK; maxPrice = ALLOW_BLANK;
			minSqft = ALLOW_BLANK; maxSqft = ALLOW_BLANK;
*/			
		}
		
		
		if(comUrl.contains("https://weatherbynj.com/")) {
			add[0]="";
			add[1]="Swedesboro";
			add[2]="NJ";
			add[3]="";
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			note="Address Taken From City And State";
			geo="TRUE";
		}
		
//============================================note====================================================================
		
		 note=U.getnote(html);
		
		if(add[2].trim().length()>2){
			add[2]=USStates.abbr(add[2]);
		}
		if(comUrl.contains("55middletownde.com/"))pstatus="Only 1 Homes Left";
		if(comUrl.contains("https://thegroveatfenwick.com"))communityName = "The Grove At Fenwick";
//		if(comUrl.contains("whisperingwoodsde.com"))pstatus += ", Sold Out";
		

		
		
			if(data.communityUrlExists(comUrl))
			{
			LOGGER.AddCommunityUrl(comUrl+"+++++++++++++Repeated+++++++++++");
			k++;
			return;
			}
			
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			
			LOGGER.AddCommunityUrl(comUrl);
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
			j++;
//		}catch(Exception e){}
	}

}