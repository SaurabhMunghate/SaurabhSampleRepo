package com.shatam.b_241_260;

import com.shatam.utils.CommunityLogger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.cellprocessor.Trim;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class EmpireCommunities extends AbstractScrapper {
	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;

	public EmpireCommunities() throws Exception {
		super("Empire Communities", "https://www.empirecommunities.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Empire Communities");
	}
//10  10   15   16   5
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new EmpireCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Empire Communities.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
	}

	protected void innerProcess() throws Exception {

		U.setUpChromePath();
		WebDriver driver = new ChromeDriver();
		
		String regUrls[]= {"atlanta/community/","houston/community/","austin/community/","san-antonio/community/","north-carolina/"};
		
		for(String regU:regUrls) {
		String mainHtml = U.getHtml("https://www.empirecommunities.com/"+regU, driver);
		if(regU.contains("north-carolina/")) {
			String comSection[]=U.getValues(mainHtml, "communitiesBlock_communityContainer", "</a>");
			for(String comSec:comSection) {
			
//				try {
					addNorthCarolina(comSec,driver);
//				} catch (Exception e) {}
			
			}
			
		}
		else {
			int count = 0;
			String[] comSections = U.getValues(mainHtml, "<div class=\"contDesc_featuredBlock\">", "</a>");
		//	U.log(comSections.length);
			for (String comSec : comSections) {
				if (comSec.contains("data-country=\"CA\""))
					continue;// Canada Communities
				
				String cUrl = U.getSectionValue(comSec, "href=\"", "\"");
				count++;
				// U.log(cUrl);
//				try {
					addDetails(cUrl, comSec, driver);
//				} catch (Exception e) {}
			
			}
		}
		
		
		
		}
		
		
		
		//U.log(count);
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String cUrl, String comSec, WebDriver driver) throws Exception {
		// TODO Auto-generated method stub

//		if (!cUrl.contains("https://www.empirecommunities.com/atlanta/community/the-swift/"))return;

//		try{
//		if(j >= 37)
		{
			U.log(">>>>>>>>>>>>>>>>>>>11111");
//			if (cUrl.contains("https://www.donjulianbuilders.com/the-hills-of-leawood")) {
//				LOGGER.AddCommunityUrl(cUrl + "::::::::::returned");
//				k++;
//				return;
//			}
			

//			U.log("Count:::" + j + );
			U.log("Count::"+j);
			U.log("comUrl =="+cUrl);
			if (data.communityUrlExists(cUrl)) {
				LOGGER.AddCommunityUrl(cUrl + "::::::::::repeated");
				k++;
				return;
			}

			LOGGER.AddCommunityUrl(cUrl);
			String html = U.getHTML(cUrl);
			
			
			// ------------------ UNITS COUNT ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, cUrl, driver);
			U.log("Total Units : "+units);
			
			String statusSec = U.getSectionValue(html, "<li id=\"communities\" ", "<li id=\"communities-by-region\" ");
			
			String header = U.getSectionValue(html, "<header", "</header");
			String remove = U.getSectionValue(html, "<p class=\"titleSearch\">LISTING TYPE</p>", "END MORE FILTERS");
			if (remove == null)
				remove = "";
			html = html.replace(remove, "");
			if (header == null)
				header = "";
			html = html.replace(header, "");
			
			html = U.removeSectionValue(html, "<head>", "</head>");
//			html = U.removeSectionValue(html, "<div class=\"mainMenu\">", "</header>");

			String[] mobilePriceSec = U.getValues(header, "<p class=\"communityName\">", "</a>");

			// ======= Communty Name ============
			comSec=comSec.replace("’s", "");
			String comName = U.getSectionValue(comSec, "communitySearchTitle\">", "<");
			U.log(comName);
			String newCommSec[] = U.getValues(statusSec, "<a href=\"", "</a>");
			for(String sec : newCommSec) {
				if(sec.contains(cUrl)) {
					U.log(sec);
					comSec=comSec+":::::::::::::\n"+sec;
				}
			}
			String mobilePrice = "";
			for (String price : mobilePriceSec) {

				if (U.getCapitalise(price.toLowerCase()).contains(comName)) {
					mobilePrice = price;
					break;
				}

			}

			// ============= Address ==============
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String note=ALLOW_BLANK;
			String nwAddSec=U.getHTML(cUrl+"home/");
			String addSec = U.getSectionValue(html, "<div class=\"line_map_direction\"", "</section>");
			if(addSec == null) addSec = U.getSectionValue(html, "<div class=\"saleCenterInfo\">", "<p class=\"desc_map_direction");
			
			if (addSec != null) {

				addSec = U.getSectionValue(addSec, "<p class=\"text_superSmall\"", "</p>");
//				U.log("MMMMMMM" + addSec);

				if (addSec != null) {
					
					addSec = U.getNoHtml(addSec.replaceAll(
							"style=\"color: #2e2624; font-family:HelveticaNeue_Lt;\">|New Model Home Now Open<br />|style=\"color: #2e2624; font-family:HelveticaNeue_Lt;\">|Monday &#8211; Saturday: 10AM &#8211; 6PM<br />\\s*Sunday: 12PM &#8211; 6PM<br />\\s*<br />\\s*By Appointment Only|Saturday &#8211; Sunday: Closed|Sunday: 12PM &#8211; 6PM|Halcyon is located at: <br />|Villas at Rowe is located on:<br />|The Swift site is Located at:<br/>|Paintbox site is located at:<br/>|Lovetree is Located at<br>|Halcyon is located at: <br />|Halcyon is located at: <br/>|Crosby site is Located at:<br/>|Empire Albright is located at<br/>|4forty4 site is located at: <br/>|Sales center is located at:<br/>|Ponce City Market|Dalston is Located at: <br>|Monday &#8211; Saturday: 10AM &#8211; 6PM<br/>|Sunday: 12PM &#8211; 6PM<br/>|Monday- Saturday: 10AM &#8211; 6PM<br/>|The Swift site is Located at<br/>|Paintbox site is located at<br/>|Model homes now open by appointment only </br> <br/>|Crosby site is Located at<br/>|Buckley site is located at <br/>|4forty4 site is located at<br/>|Lovetree is located in<br>|4Forty4 is Located at<br/>|<br/>\\s+<br/>\\s+<br/>|<br/>\\s+<br/>|<br/>\\s+\\(Quarter mile east on Hufsmith off FM 2978, then north on Hufsmith Cemetery\\)",
							"").replaceAll("Lovetree is located at:<br>|Halcyon is located at: <br />|T. \\(404\\) 941 1547|Call to schedule a personalized tour.<br />|Monday &#8211; Friday: 10AM &#8211; 6PM<br />|Monday &#8211; Saturday: 10AM &#8211; 6PM<br />|Monday &#8211; Saturday: 10AM &#8211; 6PM<br />|Monday &#8211; Saturday: 10AM &#8211; 6PM<br />|Sunday: 12PM &#8211; 6PM<br />|4Forty4 is located at:\\s*|The Swift is located at: |<br>Sales center is located at Ponce City Market.", "")
							.replace("<br />\\s*<br />", "").replace("78660<br />\\s*<br />\\s*By Appointment Only.", "Texas 78660").replace(" Avondale Avenue SE <br />", " Avondale Avenue SE,").replace("<br/>", ",").replace("<br />", ",")).trim()
							.replaceAll("Crosby site is Located at:<br/>|Villas at Rowe is located on:<br />|Crosby is located at: |4forty4 site is located at: ,style=\"color:.*>|AND MODEL HOME|, USA|<p class=\"desc_map_direction|\n", "")
							.replace("TX, 78666", "TX 78666").replace("Drive Conroe", "Drive, Conroe").replace("Road Liberty Hill", "Road, Liberty Hill").replace("Road Alpharetta, GA", "Road, Alpharetta, GA").replace(", ,Montgomery TX", ",Montgomery, TX").replaceAll(
									"Call to Schedule an Appointment,|By Appointment Only|T\\. \\(\\d+\\) \\d+-\\d+,|,4Forty4 is Located at,",
									"").replaceAll("\\s+Atlanta, GA", "  ,Atlanta, GA")
						.replaceAll("\\s+Conroe, TX", ", Conroe, TX").replace(",rowe lane", "rowe lane").replaceAll("\\s+Porter, TX ", ", Porter, TX ").replaceAll("\\s+Manvel, TX", ", Manvel, TX").replaceAll("\\s+Fulshear, TX ", ", Fulshear, TX ").replaceAll("\\s*Hockley, TX ", ", Hockley, TX ").replaceAll("\\s*League City, TX", ", League City, TX").replace("Circle Cypress", "Circle, Cypress").replaceAll(
									"Villas at Rowe is located on:,|12604 Playa Cove, Texas City, 77568,Classic Series Model Home:|Buckley is Located at ,|Crosby is Located at,|Paintbox is Located at,|T. \\(770\\) 824 3793,,The Swift is located at,|The Swift is Located at,|55&#8242; Model Home: 21009 Carries Ranch Road, Pflugerville, TX 78660,65&#8242; Model Home:|Premier Series Model Home: 12604 Playa Cove, Texas City, 77591|Signature Series Model Home: ",
									"").replace(",,.", "")
						.replace("17227 Rose Horn Drive,, Hockley, TX ,77447", "17227 Rose Horn Drive, Hockley, TX 77447");
//					String zip = Util.match(addSec.replace("78642<br />", "78642").replace("<br />", ",").split(",")[2], "\\s+\\d{5}\\s+");
				//	U.log(">>>>>>>>> "+addSec);
//
					String city="";
//					if(zip!=null)
//						city = U.getCityFromZip(zip);
					 city= U.getSectionValue(html, "<p class=\"text_fifth_featureBlock\">", "</p>");
					if(city!=null && addSec.contains(city.trim())) {
						addSec= addSec.toLowerCase().replaceAll("\\s*"+city.trim(), ", "+city.trim());
					}
					addSec = addSec.replace("765 Blue Oak Pass ", "765 Blue Oak Pass,").replace("TX, 78666", "TX 78666").replace("Place NE Atlanta,", "Place NE, Atlanta,")
							.replace("Monday &#8211; Friday: 10AM &#8211; 6PM,Saturday &#8211; Sunday: Closed", "").replace("&#038;", "&").replace("8925 Panhandle Drive", "8925 Panhandle Drive, ")
							.replaceAll("[\\w\\s]+:","").replace("Call to schedule a personalized tour.  Buckley site is located at: ", "").replace("55&#8242; Model Home: 21009 Carries Ranch Road, Pflugerville, TX 78660,60&#8242; Model Home:", "")
							.replace("TX, 78602", "TX 78602").replace("new model home now open, ", "");
					U.log("addSec >>>> " + addSec);
					add = U.getAddress(addSec);
					U.log("Address:: " + Arrays.toString(add));

				}

			} else {

				addSec = U.getSectionValue(html, "<div class=\"saleCenterInfo\">", "</br><br/>");
				if (addSec != null) {
					U.log(addSec);
					addSec = addSec.replace("<br/>", ",");
					addSec = U.getNoHtml(addSec);
					add = U.getAddress(addSec);
					U.log("Address:: " + Arrays.toString(add));
				}
			}
			if(cUrl.contains("https://www.empirecommunities.com/houston/community/build-on-your-lot/")) {
				add[1]="Houston";
				add[2]="TX";
				latlng=U.getlatlongGoogleApi(add);
				U.log("ll"+Arrays.toString(latlng));
				if(latlng==null)
					latlng=U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latlng);
				geo="TRUE";
				
			}
			
			if(addSec==null) {
				String addrSec=U.getSectionValue(nwAddSec, "SALES CENTER AND HOURS","</p>");
				if(addrSec!=null) {
				addrSec=U.getNoHtml(addrSec);
				add=U.getAddress(addrSec);
				U.log("NEW Address"+Arrays.toString(add));
				}
			}
			
			if(latlng[0].length()<4 && latlng[1].length()<4) {
				latlng[0] = U.getSectionValue(html, "data-lat=\"", "\"");
				latlng[1] = U.getSectionValue(html, "data-lng=\"", "\"");
			}
			if(latlng[0] == null) latlng[0] = latlng[1] = ALLOW_BLANK;
			U.log("Latlong:: " + Arrays.toString(latlng));
			
			
			if(cUrl.contains("/houston/community/city-homes/")){
				add = U.getAddress("1218 West 25th Street,Houston, TX 77008");
				addSec = "";
				
			}
			if(cUrl.contains("/houston/community/royal-oaks-landing/")){
				add = U.getAddress("12012 Royal Oaks Run Drive, Houston, TX 77082");
				addSec = "";
			}
			if(cUrl.contains("/houston/community/newport-lake-estates/")){
				add = U.getAddress("2910 Close Reach Rd, Manvel, TX 77578");
				addSec = "";
			}
			//community detail page
			if(cUrl.contains("https://www.empirecommunities.com/san-antonio/community/arcadia-ridge/")){
				latlng[0] = "29.418345";
				latlng[1] = "-98.768214";
			}
			if (cUrl.contains("https://www.empirecommunities.com/houston/community/lago-mar/")) {
				add[0] = "12604 Playa Cove Ln";
				add[1] = "La Marque";
				add[2] = "TX";
				add[3] = "77568";
				geo = "TRUE";
			}
			if(cUrl.contains("/houston/community/designbuild/")) {
				add[0] = "-";
				add[1] = "HOUSTON";
				add[2] = "TX";
				add[3] = "";
				latlng = U.getlatlongGoogleApi(add);
				add= U.getGoogleAddressWithKey(latlng);
				note= "Address and LatLng Taken From City & State";
				geo = "TRUE";
			}
			// 12604 Playa Cove Ln, La Marque, TX 77568, USA
			if (add[0] == ALLOW_BLANK || add[0] == null || addSec == null) {
				add = U.getGoogleAddressWithKey(latlng);
				if (add == null)
					add = U.getAddressHereApi(latlng);
				geo = "TRUE";
			}
			if ((add[2] == null || add[2] == ALLOW_BLANK) && latlng[0] != null) {
				String add1[] = U.getAddressHereApi(latlng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latlng);
				add[2] = add1[2];
				geo = "TRUE";
			}

			if (latlng[0] == null||latlng[0]==ALLOW_BLANK) {

				latlng = U.getlatlongHereApi(add);
				geo = "TRUE";
				U.log("Latlong2:: " + Arrays.toString(latlng));
			}

		
			String remNav = U.getSectionValue(html, "<li id=\"communities\"", "<div id=\"albright_submenu\"");
			if(remNav != null) html = html.replace(remNav, "");
			
			// ========= Move in Data ==============
			html = html.replaceAll("</a>\n*\\s*</div>", "</a></div>")
					.replaceAll("MOVE-IN READY HOMES\\s*</h2>", "MOVE-IN READY HOMES</h2>")
					.replaceAll("FLOOR PLANS\\s*</h2>", "FLOOR PLANS</h2>")
					.replaceAll("MOVE-IN READY\\s*</h2>", "MOVE-IN READY HOMES</h2>");

			String moveSection = U.getSectionValue(html, "MOVE-IN READY HOMES</h2>", "</section>");
			if(moveSection==null)moveSection = U.getSectionValue(html, "QUICK MOVE-IN HOMES									</h2>   ", "		</section>");
			if (moveSection == null)
				moveSection = "";
			String moveSec[] = U.getValues(moveSection, "<div class=\"itemGallery_featuredBlock\">", "</a></div>");
			String moveData = "";
			int moveCount = 0;

			U.log("Move Homes:: " + moveSec.length);
			
//			if(moveSection == "" && moveSec.length == 0 && html.contains("/category/move-in-ready/")){
//				String moveHtml1 = U.getHTML(cUrl+"category/move-in-ready");
//				
//				moveSec = U.getValues(moveHtml1, "<div class=\"lisitingCardHR\"", "</a>");
//			}

//			for (String move : moveSec) {
//
//				String moveUrl = U.getSectionValue(move, "<a href=\"", "\"");
//
//				try {
//					U.log("Move Url:: " + moveUrl);
//					String moveHtml = U.getHTML(moveUrl);
////					moveHtml = moveHtml.replace(remove, "").replace(header, "").replace(remNav, "");
////					moveHtml = U.removeSectionValue(moveHtml, "<head>", "</head>");
//					moveHtml = U.getSectionValue(moveHtml, "<section id=\"headerListing\"", "</section>");
//					moveData += moveHtml + move;
//					moveCount++;
////					U.log(moveData);
//				} catch (Exception e) {
//					// TODO: handle exception
//				}
//			}
			String floorSection = U.getSectionValue(html, "FLOOR PLANS</h2>", "</section>");
			if (floorSection == null)
				floorSection = "";
			String floorSec[] = U.getValues(floorSection, "<div class=\"itemGallery_featuredBlock\">", "</a></div>");
			String floorData = "";

			U.log("Floor Homes:: " + floorSec.length);
			
			if(floorSection == "" && floorSec.length == 0 && html.contains("/category/floor-plans")){
				String floorHtml = U.getHTML(cUrl+"category/floor-plans/");
				
				floorSec = U.getValues(floorHtml, "<div class=\"lisitingCardHR\"", "</a>");
			}

			

			for (String floor : floorSec) {

				String floorUrl = U.getSectionValue(floor, "<a href=\"", "\"");

				try {
					U.log("Floor Url:: " + floorUrl);
					String floorHtml = U.getHTML(floorUrl);
//					floorHtml = floorHtml.replace(remove, "").replace(header, "").replace(remNav, "");
//					floorHtml = U.removeSectionValue(floorHtml, "<head>", "</head>");
					
					floorHtml = U.getSectionValue(floorHtml, "<section id=\"headerPresale\">", "<section id=\"floorplanListing\">");
					floorData += floorHtml + floor;
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
//			U.log(moveData);
			
			//========= 40'Homesites and 50' homesites data
			String homeSitesData = ALLOW_BLANK; String homeSitesPrices = ALLOW_BLANK;
			
			if(html.contains("category/40-lot/") || html.contains("category/50-lot/")) {
				String homesiteFourty = cUrl + "category/40-lot/";
				U.log("homesiteFourty: "+homesiteFourty);
				String homeSiteOne = U.getHTML(homesiteFourty);
				
				String homesiteFifty = cUrl + "category/50-lot/";
				U.log("homesiteFifty: "+homesiteFifty);
				String homeSiteTwo = U.getHTML(homesiteFifty);
				
				homeSitesData += homeSiteOne + homeSiteTwo;
				
				String[] homesitesValues = U.getValues(homeSitesData, "<div class=\"listingPrice spacing_1\">", "</div>");
				U.log("homesitesValues.length: "+homesitesValues.length);
				
				for(String homesite:homesitesValues) {
					U.log(homesite);
					homeSitesPrices += homesite;
				}
				
				
			}
			
			
			// ======== Price & SqFt =====================
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0�s|0's|0s|0’s|0k's|0\\&#8217;s", "0,000");// high $200’s.
			comSec = comSec.replaceAll("0&#8217;s|0�s|0's", "0,000");
			mobilePrice = mobilePrice.replaceAll("0&#8217;s|0�s|0's", "0,000");
			

			String prices[] = U.getPrices((html + comSec + moveData + floorData + mobilePrice  + homeSitesPrices)
					.replaceAll("709,990|759,990|240,000|317,000|342,900|297,990|507,000|556,000|468,990|476,990|479,990", "")
					.replace("eatureBlock generalText text_small commPrice\">From the mid $500,000</p>", ""),
					"\\$\\d{3},\\d{3}</p>|\\$\\d,\\d{3},\\d{3}|high [\\$]*\\d{3},\\d{3}|from the [\\$]*\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>|low [\\$]*\\d{3},\\d{3}|- \\$\\d{3},\\d{3}</h3>|\\$\\d{3},\\d{3}",
					0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Price--->" + minPrice + " " + maxPrice);

			html = html.replaceAll("(\\d,\\d{3}) &#8211; (\\d,\\d{3})", "$1 - $2");
//			U.log("MMMMMMMM "+Util.matchAll(html   , "[\\s\\w\\W]{60}779,260[\\s\\w\\W]{60}", 0));
//			U.log("MMMMMMMM "+Util.matchAll(homeSitesPrices  , "[\\s\\w\\W]{1}611,990[\\s\\w\\W]{10}", 0));

			//.replaceAll("4,214|2,827|1,747|3,860|3,442|2,616|2,975", "")
			String[] sqft = U.getSqareFeet((html + comSec + moveData + floorData).replace("Located on an oversized 12,713 sq ft lot at the end of", ""),
					"\\d{4}-\\d{4} sq.ft.|\\d{4}-\\d{4} SF|SQ FT: \\d{4} – \\d{4}|\\d,\\d{3} – \\d,\\d{3} sq.ft.|\\d,\\d{3} sq.ft.|\\d,\\d{3} sq.ft. to \\d,\\d{3} sq.ft.|\\d,\\d{3}-\\d,\\d{3} sq.ft.|>\\d{1},\\d{3} -|- \\d{1},\\d{3}</p>|superSmall commSize\">From \\d,\\d{3}( - \\d,\\d{3})?</p>|text_smallLarge\">\\s+\\d,\\d{3} - \\d,\\d{3}|maximize its \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} sq.ft|commSize\">\\d,\\d{3} - \\d,\\d{3}|>\\s*\\d,\\d{3}\\s*</p>", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			U.log("MMMMMMMM "+Util.matchAll(html + comSec + moveData + floorData, "[\\s\\w\\W]{30}2997 sq.ft.[\\s\\w\\W]{30}", 0));
			// ================================================community
			// type========================================================

			html = html.replace("beautiful lakes in the area", "Lake community");

			String communityType = U.getCommType((html + comSec)
					.replaceAll("WILLIAMS GOLF|Penick Golf Campus|LAKEFRONT PARK|golf\\.jpg|TOPGOLF|disc golf|Kallison Ranch,  a popular master-planned community", ""));
			U.log("ComType:: " + communityType);

			// ==========================================================Property
			// Type================================================
			

			html = html.replaceAll("CONDO<|img(.*?)>|href=\"(.*?)\"", "").replace("comfortable luxury", "luxury homes")
					.replace("neighborhood HOA", "Homeowner Association").replaceAll("Villas at Rowe</option>", "");
			String proptype = ALLOW_BLANK;
//			U.log(floorData);
//			U.writeMyText(html + comSec + moveData + floorData);
			proptype = U.getPropType((comSec + html +  moveData + floorData)
					.replaceAll("Detached Homes</p>(<p class=\"homeCategories|<p class=\"taglineCommunity)|tagComm\">Single Family Homes in Houston</p>", ""));
			U.log("proptype:: " + proptype);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}Row Homes[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30} Carriage house [\\s\\w\\W]{30}", 0));

			// ==================================================D-Property
			// Type======================================================
			String rmsec = U.getSectionValue(html, "<head>", "</div><!--#searchHeader-->");
			html = html.replace("Ranch Style&nbsp;&amp;", "ranch-style").replace(rmsec, "")
					.replaceAll("[B|b]ranch|BRANCH|Ranch</div>|Ranch - <span>|Kallison Ranch|KallisonRanch|-ranch|RANCH|-Ranch| Ranch Road,", "");
			
			if(moveData!=null)moveData=moveData.replace(rmsec, "");
			if(floorData!=null)floorData=floorData.replace(rmsec, "");

			String dtype = U.getdCommType((html + comSec + moveData + floorData)
					.replaceAll("1-2\\s*</p>", " 1 Story  2 Story ").replace("2-3 Stories", "2 story, 3 Stories").replace("1.5-story", "1½-story").replaceAll("3 bedroom, 2 baths is |4 bedroom 2.5 bath home features a|RANCH</p>|Ranch</option>|-ranch|Ranch-|RANCH</p>", "")
					.replace("1 and 2-story", " 1 Story  2 Story ").replace("1 – 2 Stories", " 1 Story  2 Story "));
			U.log("dtype::::::::::::" + dtype);
			//U.log("MMMMM "+Util.matchAll(comSec + html +  moveData + floorData, "[\\s\\w\\W]{30}Stories[\\s\\w\\W]{30}", 0));
			// ================ Status ==================================
			html = html.replace("New Phase of Homes Coming Soon", "New Phase Coming Soon")
					.replace("Opening for Sales in Early 2021", "Opening Early 2021")
					.replace("NEW PHASE, NOW OPEN AT THE SWIFT", "new phase now open")
					.replaceAll("CENTER <br/>\\s+COMING|half-acre lots|coming soon\\.<|NOW AVAILABLE<br", "");

//			U.log(html); 
			comSec=comSec.replaceAll("MODEL HOME COMING SOON|commPrice\">COMING SOON</p>", "");
			html=html.replace("&#9733; FINAL OPPORTUNITY REMAINING &#9733;", "Final Opportunities Remaining")
					.replace("New Phase of Homes Coming Fall 2021", "New Phase Coming Fall 2021")
					.replace("New phase coming this fall", "New phase coming fall")
					.replaceAll("class=\"moveInReadyTags\">\\s+COMING SOON\\s+</div>", "class=\"moveInReadyTags\">\\s+</div>")
					.replaceAll("class=\"moveInReadyTags\">\\s+FINAL OPPORTUNITY\\s+</div>","")
					.replaceAll("MODEL HOME COMING SOON|commPrice\">COMING SOON</p>", "")
					.replace("Our next phase will open in early 2022","next phase open early 2022")
					.replace("next phase will open in early 2022", "next phase open early 2022");
			
			
			
			String status = U.getPropStatus((html + comSec).replaceAll("HOMES COMING LATER THIS YEAR|Now in its last phase of building|Final 14 Homes Remaining|Final 13 Homes Remaining|MODEL HOME COMING SOON| information on our grand opening|commPrice\">Coming Soon</p> |phase of homes coming soon|lass=\"moveInReadyTags\">\\s*Coming Soon|subTitleFont\">Coming Soon</p>|commPrice\">COMING SOON</p>|tagLinePrices\">NOW AVAILABLE<br/>|\">Final Opportunities Remain</p>|\">NEW PHASE COMING SOON</p>|CENTER OPENING|available to book|NOW OPEN|TX. Currently sold out|NOW OPEN<br/>|MODEL HOME<br/>\\s+OPENING SOON|MODEL HOME<br/>\\s+COMING SOON|Texas is now open|[m|M]ove-[i|I]n|MOVE-IN",
					""));
//			U.log("MMMMM "+Util.matchAll(html+comSec, "[\\s\\w\\W]{30}HOMES REMAINING[\\s\\w\\W]{30}", 0));

			status=status.replace("Final Opportunity Remaining, Final Opportunity", "Final Opportunity Remaining").replace("New Phase Coming Fall 2021, Coming This Fall", "New Phase Coming Fall 2021").replace("New Section Coming Fall 2021, Coming This Fall", "New Section Coming Fall 2021").replace("Coming This Fall, Coming Soon", "Coming This Fall").replace("New Phase Of Homes Coming Summer/fall 2021", "New Phase Coming Summer/fall 2021");
			if(cUrl.contains("https://www.empirecommunities.com/austin/community/parmer-ranch/")) status=status.replace("Coming Soon, ","");
			U.log("Status:: " + status);

			// ============ Note ==================
			note = U.getnote(html.replace("type=presale'", ""));
			U.log("Note:: " + note);
			U.log("-->"+moveCount);
			if (moveCount > 0
					|| Util.match(html, "<div class=\"moveInReadyTags\">\\s+Move-in Ready\\s+</div>") != null || Util.match(html, "MOVE-IN READY TOWNHOMES\\s*</h2>")!=null) {

				if (status == ALLOW_BLANK)
					status = "Quick Move-In Homes";
				else
					status = status + ", Quick Move-In Homes";
			}

//				minSqft="3,043";
//			//	maxSqft="";
//			}
			
//			if(cUrl.contains("https://www.empirecommunities.com/austin/community/lakeside-at-lake-georgetown")||cUrl.contains("https://www.empirecommunities.com/houston/community/royal-oaks-landing")||cUrl.contains("https://www.empirecommunities.com/austin/community/plum-creek")) {
//				maxPrice=ALLOW_BLANK;
//			}
//			if(cUrl.contains("https://www.empirecommunities.com/austin/community/double-eagle-ranch"))status+=", Quick Move-In Homes";
			// ================================================================================================
			if(cUrl.contains("/community/arcadia-ridge/"))dtype=dtype.replace("Ranch", ALLOW_BLANK);
/*			if (cUrl.contains("https://www.empirecommunities.com/austin/community/mueller/"))
				status = "New Phase of Homes Coming Soon";



*/			// =====================================================================================================

			if(cUrl.contains("https://www.empirecommunities.com/atlanta/community/buckley/"))add[0]="141 West Wieuca Road NE";
//			if(cUrl.contains("https://www.empirecommunities.com/austin/community/blanco-vista"))maxPrice=ALLOW_BLANK;
//			if(cUrl.contains("https://www.empirecommunities.com/houston/community/hidden-lakes"))maxPrice="$538,213";
			
			
			
			//if(cUrl.contains("https://www.empirecommunities.com/houston/community/newport-lake-estates"))proptype+=", Estate Style Homes";
			//r�
			add[0] = add[0].replace("Monday – 10AM – 6PM, 12PM – 6PM, , ", "").replace(comName+" is located at:", "");
			if(cUrl.contains("https://www.empirecommunities.com/austin/community/mueller/"))status=status.replace("Coming This Spring, New Phase", "New Phase Coming This Spring");
			comName = comName.replace("�", "'");
			
			U.log(""+Arrays.toString(add));			

			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(comName.replace("Hunter�s", "Hunters").replace("Harper�s", "Harpers"), cUrl, communityType);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", ""), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(status.replace("New Section Coming Summer 2021, New Phase Coming Soon", "New Section Coming Summer 2021"));
			data.addNotes(note);

		}
		j++;
//		}catch(Exception e) {}

	}

	public void addNorthCarolina(String comSec,WebDriver driver) throws Exception {
		
		
		
		
		String comUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
		U.log(comUrl);
		
//		if (!comUrl.contains("https://www.empirecommunities.com/atlanta/community/the-swift/"))return;

//		if(!comUrl.contains("https://www.empirecommunities.com/houston/community/balmoral/"))return;
		U.log(">>>>>>>>>>>>>>>>>>>222222");
		String comHtml=U.getHTML(comUrl);
		
		
		// ------------------ UNITS COUNT ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		
		String rem = U.getSectionValue(comHtml, "<li class=\"subMenuMobile\" data-open=\"false\" id=\"communities-dropdown\">", "<div id=\"smenuCommunityDesk\">");
		comHtml =comHtml.replace(rem, "");
		String comName =ALLOW_BLANK;
		String comNameSec=U.getSectionValue(comHtml, "fullBlock_title text_extraLarge fullBlock_leftTitle", "/h2>");
		if(comNameSec==null)comNameSec=ALLOW_BLANK;
		comName =U.getSectionValue(comNameSec, "<br>", "<");
//		U.log(comHtml);
		if(comName==null)comName = U.getSectionValue(comHtml, "EMPIRE<br />", "</h2>");
		
		comName=U.getCapitalise(comName.toLowerCase());
		
	
		U.log(comName);
		
		String addSec=U.getSectionValue(comHtml, "\"https://maps.google.com?", "/a>");
	
		//U.log(addSec);
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLag[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String note= U.getnote(comHtml);
		if(addSec==null)addSec=ALLOW_BLANK;
		latLag[0]=U.getSectionValue(addSec, "daddr=", ",");
		latLag[1]="-"+U.getSectionValue(addSec, ", -", "\"");
		U.log(Arrays.toString(latLag));
		
		if(latLag[0]!=null && latLag[0]!=ALLOW_BLANK)
			add=U.getAddressGoogleApi(latLag);
		
		
		if(comUrl.contains("north-carolina/community/camber-woods/"))
		{
			add[1]="Gastonia";
			add[2]="NC";
			latLag = U.getlatlongGoogleApi(add);
			add= U.getGoogleAddressWithKey(latLag);
			note="Address & LatLng Taken from City & State";
			geo="True";
		}
		if(comUrl.contains("/community/camellia-gardens/"))
		{
			add[1]="Harrisburg";
			add[2]="NC";
			latLag = U.getlatlongGoogleApi(add);
			add= U.getGoogleAddressWithKey(latLag);
			note="Address & LatLng Taken from City & State";
			geo="True";
		}
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latLag));
		
		
		String floorUrl=comUrl+"category/floor-plans/";
		String floorhtml=U.getHTML(floorUrl);
		U.log("floorhtml: "+floorUrl);
		String floorSec="";
		String sqftSec1="";
		
		
		String SqftSections[]=U.getValues(comHtml, "SqftHomes_fifth_featureBlock sizeClass", "</a>");
		for(String ss:SqftSections) {
			sqftSec1+=ss;
		}
		String floorSection[]=U.getValues(floorhtml, "infoListing", "</a>");
	
		for(String fs:floorSection) {
			
			floorSec+=fs;
		}
		
		//========== Getting floopr plans data
		String homePlansData = ALLOW_BLANK;
		String[] homePlanSec = U.getValues(floorhtml, "<div class=\"lisitingCardHR\"", "<div class=\"infoListing\">");
		for(String homePlan:homePlanSec) {
			
			String homeLink = U.getSectionValue(homePlan, "<a href=\"", "\">");
			U.log("homeLink: "+homeLink);
			
			homePlansData += U.getHTML(homeLink);
		}
		
		String quickHtml=U.getHTML(comUrl+"category/move-in-ready/");
		
		String quicSec[]=U.getValues(quickHtml, "lisitingCardHR", "</a>");
		String quickSec="";
	//	String sqftSec2="";
		for(String qs:quicSec) {
			quickSec+=qs;
		}
		
		String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		//Below sections have garbage price values
		String remPriceOne = U.getSectionValue(comHtml, "<option value=\"\">MIN</option>", "</select>");
		String remPriceTwo = U.getSectionValue(comHtml, "<option value=\"\">MAX</option>", "</select>");
//		U.log(remPriceOne);
//		U.log(remPriceTwo);
		
		comHtml = comHtml.replace(remPriceOne, "").replace(remPriceTwo, "");
		
	//	U.log(sqftSec1);
		comSec=comSec.replace("0�s", "0,000").replace("$300's", "$300,000");
//		U.log(comSec);
		comHtml=comHtml.replace("From $1 Million+", "From $1,000,000")
				.replace("00's</p>", "00,000</p>").replace("$300's", "$300,000").replaceAll("0’s|0&#8217;s", "0,000").replace("$400’s", "$400,000").replaceAll("\\$\\d+,\\d+ or less</option|\\$\\d{3},\\d{3}</option> |<option value=\"\\d+\">\\d+ sq.ft.|<option value=\"\\d+\">\\d,\\d+ sq.ft.", "");
		
		prices=U.getPrices(floorSec+quickSec+comSec+comHtml, "From \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}2,000,000[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(floorSec+quickSec+comSec, "[\\s\\w\\W]{30}2,000,000[\\s\\w\\W]{30}", 0));
		
		sqft=U.getSqareFeet(sqftSec1+comSec, "\\d,\\d{3} sq.ft. to \\d,\\d{3} sq.ft.|\\d{1},\\d{3}|- \\d{1},\\d{3}", 0);
		
		U.log(Arrays.toString(prices));
		U.log(Arrays.toString(sqft));
		
		String cType=ALLOW_BLANK;
		
		
		
		
		cType=U.getCommType(comHtml);
		
		String ptype=ALLOW_BLANK;
		ptype=U.getPropType(comHtml + homePlansData);
		U.log("ptype: "+ptype);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homePlansData, "[\\s\\w\\W]{30}flex[\\s\\w\\W]{30}", 0));
		
		String dType=U.getdCommType(comHtml.replace(">1 &#038; 2 Story Homes", ">1 Story &#038; 2 Story Homes").replace("three-and four-story", "three-story and four-story").replace("3 & 4 Story Homes", "3 Story, 4 Story"));
		
		String statusSec=U.getSectionValue(comHtml, "fullBlock_subtitle text_mediumLarge fullBlock_leftSubtitle", "<section id=\"featured_block-block");
		if(statusSec==null)statusSec=U.getSectionValue(comHtml, "fullBlock_subtitle text_mediumLarge fullBlock_leftSubtitle", "</h3>");
		if(statusSec==null)statusSec=ALLOW_BLANK;
		statusSec = statusSec.replace("next phase will open in early 2022", "next phase open early 2022");
//		U.log(statusSec);
		statusSec=statusSec.replace("Belle Grove offers Quick Move-in Inventory homes","");
		String pstatus=U.getPropStatus(statusSec.replace(" Quick Move-in Inventory homes", " Quick Move-in homes")+comSec);
		
		
		if(quicSec.length>1) {
			if(pstatus.length()<3) {
				pstatus="Quick Move-In Homes";
				
			}
			else {
				pstatus+=", Quick Move-In Homes";
			}
			
		}
		if(comUrl.contains("https://www.empirecommunities.com/north-carolina/community/landings-at-noda/")) note=ALLOW_BLANK;
		if(comUrl.contains("/community/west-end-towns/"))sqft[0]="1,300";
		if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
		if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
		if(prices[0]==null)prices[0]=ALLOW_BLANK;
		if(prices[1]==null)prices[1]=ALLOW_BLANK;
		
		
		LOGGER.AddCommunityUrl(comUrl);	

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(comName, comUrl, cType);
		data.addLatitudeLongitude(latLag[0].trim(), latLag[1].trim(), geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].replace(",", ""), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(ptype, dType);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		
		
		
		U.log("=============");
	}
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String jsonLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("SITE MAP</a></li>")) {
			
			String frameUrlSec = U.getSectionValue(comHtml, "<li id=\"site-map\"", "SITE MAP</a></li>"); 
			frameUrl = U.getSectionValue(frameUrlSec, "<a href=\"", "\"");
			U.log("frameUrl from sitemap: "+frameUrl);
		}
		
		if(comHtml.contains("LOT MAP</a></li>")) {
			
			String frameUrlSec = U.getSectionValue(comHtml, "<li id=\"lot-map\"", "LOT MAP</a></li>"); 
			if(frameUrlSec == null) frameUrlSec = U.getSectionValue(comHtml, "<li class=\"innerSubmenuItem\">", "LOT MAP</a></li>");
			frameUrl = U.getSectionValue(frameUrlSec, "<a href=\"", "\"");
			U.log("frameUrl from lotmap: "+frameUrl);
		}
		
		if(frameUrl != ALLOW_BLANK) {
			
			if(!(frameUrl.contains(".pdf")) || !(frameUrl.contains(".jpg"))) {
				
				mapData = U.getHtml(frameUrl, driver);
				U.log(U.getCache(frameUrl));	
				
				//FLOW 1: For direct data on maps thorough dots.
				if(mapData.contains("<div data-lotid")) {
					
					ArrayList<String> dots = Util.matchAll(mapData, "<div data-lotid=\"", 0);
					U.log("Count dots: "+dots.size());
					totalUnits = String.valueOf(dots.size());
				}
				
				//FLOW 2: For iframe available on map page. Getting data through jsonLink.
				else if(!(mapData.contains("<div data-lotid")) && mapData.contains("edwardandrewspipeline")) {
					
					String frameSec = U.getSectionValue(mapData, "src=\"https://edwardandrewspipeline", "\"");
					U.log("frameSec: "+frameSec);
					
					if(frameSec.contains("?")) {
						String[] forCid = frameSec.split("\\?");
						String cid = forCid[1]; 
						U.log("cid: "+cid);
						
						jsonLink = "https://edwardandrewspipeline.trapponline.com/Controls/eHome/CommunityXML.ashx?" + cid;
						U.log("jsonLink: "+jsonLink);
						
						String jsonMapData = U.getHTML(jsonLink);
						
						if(jsonMapData.contains("lotnum=\"")) {
							
							ArrayList<String> lotsnumber = Util.matchAll(jsonMapData, "lotnum=\"", 0);
							U.log("Lotsnumber: "+lotsnumber.size());
							totalUnits = String.valueOf(lotsnumber.size());
						}
					}
				}
				
			} 
			
		}
					
		return totalUnits;
	}
	
	
	
	
	
	
	
	private void addDetails1(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
		// if(j ==11)
		{
		if (!comUrl.contains("https://www.empirecommunities.com/austin/community/parmer-ranch/")) return;
			U.log(U.getCache(comUrl));
			if (comUrl.contains("https://www.empirecommunities.com/community/lakeside-2/"))
				comUrl = "https://www.empirecommunities.com/community-page/lakeside-tx/";
			U.log(j + "   commUrl-->" + comUrl + "\n" + comData);
			String html = U.getHTMLwithProxy(comUrl);

//============================================Community name=======================================================================
			String communityName = U.getSectionValue(comData, "<h3 class=\"mTitleInner mTitleIn bold\">", "<");

			if (communityName == null)
				communityName = U.getSectionValue(html, "<title>", "|");
			communityName = U.getCapitalise(communityName.toLowerCase());
			communityName = communityName.replaceAll("&#8217;| Yard Homes", "");

			U.log("community Name---->" + communityName);

//================================================Address section===================================================================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			String note = "";
			note = U.getnote(html);
			String ad = U.getSectionValue(html, "   <address>", "</address>");
			// U.log(ad);
			if (ad != null)
				ad = ad.replaceAll("CALL AGENT FOR SHOWING|<p>Visit Our Model Home Today<br />", "");

			if (ad != null && ad.trim().length() > 10) {
				ad = ad.replaceAll(",<br />|<p>|</p>", "").replace("San Antonio,", ",San Antonio,");
				add = U.findAddress(ad);
				if (comUrl.contains("https://www.empirecommunities.com/community/coastal-point/")) {
					U.log("ssss" + ad);
					add = U.getAddress(ad.replaceAll("1604 Noble Way Court\n" + "League City",
							"1604 Noble Way Court, League City"));
				}
				U.log("Address : " + Arrays.toString(add));
			}
			if (ad == null) {
				ad = U.getSectionValue(html, "<a href=\"mailto", "</div");
				U.log(ad);
				ad = ad.replaceAll(":(.*?)com</a>", "").replaceAll("& Journey Parkway", "& Journey Parkway,");
				add = U.findAddress(ad);
			}
			if (ad == null || add == null || add[3] == ALLOW_BLANK) {
				ad = U.getSectionValue(comData, "<div class=\"mContent light\">", "</p>");
				if (ad != null) {
					ad = ad.replaceAll("<p>|, USA", "").replaceAll("<br />", ",").replaceAll("TX, ", "TX ");
					U.log(ad);
					add = U.findAddress(ad);
				}
			}
			if (comUrl.contains("/community/cityhomes/")) {
				ad = U.getSectionValue(html, "<li><span>NOW SELLING", "<br>");
				add = U.findAddress(ad);
			}
			if (comUrl.contains("/community/designbuild/")) {
				ad = U.getSectionValue(html, "<li><span>Quick Move-In</span>", "</li");
				if (ad != null) {
					add = U.findAddress(ad);
				}
			}
			U.log("New Address is : " + Arrays.toString(add));

			// ---------Retriving latlng from main page------------

			latLong[0] = U.getSectionValue(comData, "data-lat=\"", "\"");
			latLong[1] = U.getSectionValue(comData, "data-lng=\"", "\"");
			U.log("latlong::::" + latLong[0]);
			U.log("latlong::::" + latLong[1]);

			if (latLong[0] == ALLOW_BLANK) {

				latLong = U.getlatlongGoogleApi(add);
				U.log("latlong" + latLong[0]);
				U.log("latlong" + latLong[1]);
				geo = "TRUE";
			}
			if (add == null || add[0] == ALLOW_BLANK) {
				U.log("hello");
				String addr[] = U.getAddressGoogleApi(latLong);
				add = addr;
				geo = "TRUE";
			}

//=================================Fetch data from Quick Homes================================================================
			int quickCount = 0;
			String allquickHtml = ALLOW_BLANK, quickHomeSec = ALLOW_BLANK, quickHtml = ALLOW_BLANK;
			String allHomesData = ALLOW_BLANK, homeSection = ALLOW_BLANK, homeHtml = ALLOW_BLANK;

			if (html.contains("section=homes")) {
				homeHtml = U.getHTMLwithProxy(comUrl.replace("community", "community-page") + "/?section=homes");
				homeSection = U.getSectionValue(homeHtml, "<div class=\"fullestContainer homes\">", "<footer>");
				if (homeSection != null) {
					String allUrls[] = U.getValues(homeSection, "<a class=\"infoHouseBox viewDetails ",
							"<div class=\"infoBoxIcon ");
					for (String hString : allUrls) {
						hString = U.getSectionValue(hString, "href=\"", "\"");
						U.log(hString);
						allHomesData += U.getSectionValue(U.getHTMLwithProxy(hString.trim()),
								"<div class=\"mediaItem\" id=\"mediaItem-0\">",
								"  <span id=\"size\">Request Info</span>");
					}
				}
				String qlink = Util.match(html, " <li><a id=\"linkMob-\\d\" class=\"linkMob\"(.*?)>Quick Move-In</a>",
						0);
				if (qlink != null) {
					quickHtml = U.getHTMLwithProxy(U.getSectionValue(qlink, "href=\"", "\"").trim());
				} else if (html.contains(">Move-in Ready</a>")) {
					qlink = Util.match(html, " <li><a id=\"linkMob-\\d\" class=\"linkMob\"(.*?)>Move-in Ready</a>", 0);
					quickHtml = U.getHTMLwithProxy(U.getSectionValue(qlink, "href=\"", "\"").trim());
				}
			}
//============================================Price and SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0�s|0's|0s|0’s|0k's|0\\&#8217;s", "0,000");// high $200’s.
			comData = comData.replaceAll("0&#8217;s|0�s|0's", "0,000");
			quickHtml = quickHtml.replace("$<span class=\"priceContainer\">", "$");
			homeHtml = homeHtml.replace("$<span class=\"priceContainer\">", "$");
			String prices[] = U.getPrices(html + quickHtml + homeHtml,
					"\\$\\d,\\d{3},\\d{3}|high [\\$]*\\d{3},\\d{3}|from the [\\$]*\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>|low [\\$]*\\d{3},\\d{3}|mid [\\$]*\\d{3},\\d{3}|- \\$\\d{3},\\d{3}</h3>|\\$\\d{3},\\d{3}",
					0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

//======================================================Sq.ft===========================================================================================		
			String[] sqft = U.getSqareFeet(html + quickHtml + homeHtml,
					"\\d,\\d{3} sq. ft. to over \\d,\\d{3} sq. ft|\\d,\\d{3} square feet to \\d,\\d{3} square feet|\\d,\\d{3} sq.ft.|Sq. Ft.: \\d,\\d{3}<br /",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

//================================================community type========================================================

			String communityType = U.getCommType((html + comData).replace("disc golf", ""));

//==========================================================Property Type================================================
			html = html.replaceAll("CONDO<|img(.*?)>|href=\"(.*?)\"", "");
			String proptype = ALLOW_BLANK;
			proptype = U.getPropType(html + comData + allHomesData + allquickHtml);

//==================================================D-Property Type======================================================
			html = html.replace("Ranch Style&nbsp;&amp;", "ranch-style")
					.replaceAll("[B|b]ranch|BRANCH|Ranch</div>|Ranch - <span>", "");
			String dtype = U.getdCommType(
					(html + comData + allquickHtml + allHomesData).replace("1 and 2-story", " 1 Story  2 Story "));
			U.log("dtype::::::::::::" + dtype);
//==============================================Property Status=========================================================
			html = html.replaceAll(
					"MODEL HOME<br/>\\s+COMING SOON|MOVE IN READY Homes\\s*</p>|selection of quick move-in|<p>Coming Soon</p>|Move-In Ready Homes\\s*</|new move-in ready homes across |MODEL HOME COMING SOON|move-in ready homes across Austin|>Now Open</span></strong></h3>|<span style=\"color:#fa5a0a;\">Coming Soon</span>|span style=\"color: #312725;\"><strong>now open</strong></span></h3>|Tomball is Now Open|Tomball is now open for|<p>Coming Soon|<p>Coming Soon</p>|coming soon from the|Model Home<br />\\s*Coming Soon</h3>|<span>Coming Soon </span>",
					"").replace("New section of homes coming soon,", "New section coming soon,")
					.replaceAll("NEW PHASE<br />\\s*COMING SOON</h3>", "New Phase Coming Soon")
					.replaceAll("Only 2 Homes <br />\\s*Remaining", "Only 2 Homes Remaining");
			html = html.replace("New section of homes coming soon", "NEW SECTION COMING SOON");
			comData = comData.replaceAll(" <p>Coming Soon<br />", "");
			String pstatus = U.getPropStatus(html + comData);
//	U.log(Util.match(txt, findPattern));
			U.log("status:::" + pstatus);
//	U.log("quick count==="+quickHtml);
			if (!pstatus.contains("Quick") && !quickHtml.contains("0</span> Designs Available")
					&& ((html.contains(">Quick Move-In</a>") || html.contains("\">Quick Move-in</a>")
							|| allHomesData.contains("target=\"_self\">Move-in Ready</a>")))) {
				if (pstatus == ALLOW_BLANK) {
					pstatus = "Quick Move-In";
				} else if (pstatus != ALLOW_BLANK) {
					pstatus = pstatus + ", Quick Move-In";
				}
			}
			if (!pstatus.contains("Quick") && quickHtml.contains("target=\"_self\">Move-in Ready</a>")) {
				if (pstatus == ALLOW_BLANK) {
					pstatus = "Quick Move-In";
				} else if (pstatus != ALLOW_BLANK) {
					pstatus = pstatus + ", Quick Move-In";
				}
			}
			if (pstatus.contains("Quick Move-In") && pstatus.contains("Quick Move-in Homes,"))
				pstatus = pstatus.replaceAll("Quick Move-in Homes,*", "");
			pstatus = pstatus.replace("Quick Move-in Homes", "Quick Move-In");
			add[0] = add[0].replaceAll(",|Rough Hollow Community Information Center, ", "");
			if (comUrl.contains("/goodnight-ranch"))
				pstatus = pstatus.replace("Coming Soon", "New Section Coming Soon");
			if (note.contains("Now Open") && pstatus.contains("Now Open"))
				pstatus = pstatus.replace("Now Open", "-");
//	comUrl=comUrl.trim().replace("community", "community-page");
			if (comUrl.contains("https://www.empirecommunities.com/community-page/lakeside-tx/"))
				comUrl = "https://www.empirecommunities.com/community/lakeside-2/";
//============================================note====================================================================
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "::::::::::repeated");
				k++;
				return;
			}

			LOGGER.AddCommunityUrl(comUrl);
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			

			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
		}
		j++;
	}

}