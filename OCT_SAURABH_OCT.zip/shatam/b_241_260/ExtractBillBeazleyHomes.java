/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_241_260;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBillBeazleyHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractBillBeazleyHomes() throws Exception {
		super("Bill Beazley Homes","https://www.billbeazleyhomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Bill Beazley Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractBillBeazleyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Bill Beazley Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	WebDriver driver= null;
	HashMap<String, String> latList=new HashMap<>();
	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String mainHtml=U.getHTML("https://billbeazleyhomes.com/neighborhoods/");
	
		String[] comSections = U.getValues(mainHtml, "<h3 class=\"pp-content-grid-post-title\">", "</h3>");
		U.log(comSections.length);
		for(String comSec : comSections){
			String cUrl =U.getSectionValue(comSec, "<a href='", "'");
			U.log(cUrl);
			addDetails(cUrl,comSec);
			//break;
		}
		LOGGER.DisposeLogger();
		driver.quit();
		
		//try{driver.quit();}catch(SessionNotCreatedException e){}
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	try{
	{
//		if(!comUrl.contains("https://billbeazleyhomes.com/neighborhoods/bergen-place-west/"))return;
//		if(!comUrl.contains("https://billbeazleyhomes.com/neighborhoods/greggs-mill/"))return;
		U.log(U.getCache(comUrl));
		
		if(comUrl.contains("highgrove") ||comUrl.contains("woodlief")) {
			LOGGER.AddCommunityUrl("::::::::::::Returned divisions hidden::::::::::::");
			return;
		}
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"::::::::::repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHtml(comUrl, driver);
		U.log(U.getCache(comUrl));	
		
		String Decs = U.getSectionValue(html, "<div class=\"ult_tab_min_contain \">", "<!-- end comments -->");
		String commSec=U.getSectionValue(html, "<span class=\"title-text pp-primary-title\">Agents</span>", "First time homebuyer</span>");		
				
//============================================Community name=======================================================================
	String communityName=U.getSectionValue(html, "<h1 class=\"heading-title\">","</h1");
	if(communityName!=null)communityName = U.getSectionValue(communityName, "<span class=\"title-text pp-secondary-title\">", "<");
	U.log(communityName);
	html = html.replace("<h4 style=\"text-align: center;\" aria-level=\"3\"><strong>", "<h4 style=\"text-align: center;\"><strong>");
	if(communityName == null)communityName = U.getSectionValue(html, "<h4 style=\"text-align: center;\"><strong>", "<");
	communityName = U.getCapitalise(communityName.toLowerCase());
	communityName = communityName.replace("&#8217;","");

	U.log("community Name---->"+communityName);
	
//================================================Address section===================================================================
	String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
	String geo = "FALSE";
	String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
	String note="";
	
//	U.log(">>>>>>>>>>.. "+Util.match(html, ".*Presale.*"));
	note = U.getnote(html.replace("PRESALE- Builder ", "").replaceAll("showcaseRemarks\">PRESALE|/presales/|\">PRESALE! Builder ", ""));
	
	String ad = U.getSectionValue(html,"<span class=\"title-text pp-primary-title\">Location</span>", "</h3>");//U.getSectionValue(html,"<strong>LOCATION:</strong></h4>", "</p>");
	U.log("FIRST ADD SEC: "+ad);
	if(ad==null) ad = U.getSectionValue(comData,"https://www.google.com/maps/place/", "/@");
	if(ad!=null)ad=ad.replace("CALL AGENT FOR SHOWING", "").replaceAll("\\s+|\\+"," ").replaceAll("\\n*","").replace("%26", "&");
	
	if(ad!=null && ad.trim().length()>10){
		ad=ad.replace("<br />",",");
		ad=ad.replace("<p style=\"text-align: center;\">","").replace("South Carolina", "SC").replace("Hayne?s", "Hayne's");
		U.log("gggg  "+ad);
		ad=ad.replace("254 Longstreet Crossing","254 Longstreet Crossing, North Augusta, SC 29860");
		add=U.findAddress(ad);
		U.log("Address : " + Arrays.toString(add));
	}
//	if(comUrl.contains("/bergen-place-west/")) {
//		ad="260 Longstreet Crossing</p><p style=\"text-align: center;\">North Augusta, SC 29860</p>";
//		U.log(ad);
//		add=U.findAddress(ad);
//	}
	
	//---------Retriving latlng from main page------------
	String latLngSec = ALLOW_BLANK;

	latLngSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");//Util.match(comData, "/@(.*?),\\d{2}[.\\d+]*z",1);
	U.log(communityName+"::::::\nlatLngSec:::::::::"+latLngSec);
	
	if(latLngSec.contains("404+allenwood+street+30909/")) {
		latLngSec = null;
		latLong[0] = ALLOW_BLANK;
	}
	
	if(latLngSec != null){
		latLngSec = U.getSectionValue(latLngSec, "/@", "/data");
		latLngSec = latLngSec.replaceAll(",\\d+z", "");
		if(latLngSec != null)
		latLong = latLngSec.split(",");
		U.log("latlong::::" + latLong[0]);
		U.log("latlong::::" + latLong[1]);
	}
	
	if (latLong[0] == ALLOW_BLANK) {

		latLong = U.getlatlongGoogleApi(add);
		U.log("latlong" + latLong[0]);
		U.log("latlong" + latLong[1]);
		geo = "TRUE";
	}
	if (add==null || add[2]==null) {
		String addr[] = U.getAddressGoogleApi(latLong);
		add = addr;
		geo = "TRUE";
	}
	
	//-----------------Fetch data from Quick Homes---------------------
	String allHomesData = ALLOW_BLANK; String quickHomeSec = ALLOW_BLANK;
	int quickCount = 0;int cnt =0 ;
	String qhtml = U.getHTML("https://search.billbeazleyhomes.com/i/ready-to-move-in");
	String sts="";
	
	if(qhtml != null) quickHomeSec = U.getSectionValue(qhtml, "<ul class=\"IDX-resultsCellsContainer\">", "</ul>");
//	U.log("quickHomeSec==="+quickHomeSec);
	if(quickHomeSec != null){
		String quickUrls[] = U.getValues(quickHomeSec, "<div class=\"IDX-results--card-content\"><a href=\"", "\" ");
		//U.log(Arrays.toString(quickUrls));
		//if(quickUrls.length==0) {
			U.log("Hello");
			for(String quick : quickUrls) {
				
				quick = U.getNoHtml(quick).replaceAll("&nbsp;", "").trim();
				U.log(">>>>>>>>>>"+quick+"\t"+html.contains(quick));
				if(html.contains(quick)) 
					quickCount++;
					
			}
			U.log("quickCount==="+quickCount);
			
			
			if(comUrl.contains("https://billbeazleyhomes.com/neighborhoods/the-retreat-at-storm-branch/"))
			{
				String quickSec=U.getSectionValue(html, "<h4>Quick Move In</h4>", "Quick facts</span>"); 
				String url=U.getSectionValue(quickSec, "href=\"", "\"");
//				U.log("url===="+url);
				if(url!=null) {
					quickCount++;
				}
			}
			
			
			
			//quickUrls=U.getValues(quickHomeSec, "<a href=\"", "\"");
			
//			U.log("QUICK URLS: "+quickUrls.length);  
//			if(quickUrls.length>0)
//			{
//				sts="Quick Move-in";
//			}
		//}
		
		quickHomeSec = U.getSectionValue(html, "<div id=\"IDX-showcaseGallery-", "<style type=\"text/css\">");
		quickUrls = U.getValues(html, "<div class=\"IDX-showcaseContainer\" style=\"height: 6px;\"><a href=\"", "\"");
		
		for(String homeSec : quickUrls){
			U.log("homeSec : "+homeSec);
			String homeHtml = U.getHTML(homeSec);
			U.log("homeHtml: "+homeHtml);
			
			allHomesData += U.getSectionValue(homeHtml, "<div id=\"IDX-main\"", "IDX Broker</a></div>")+U.getSectionValue(homeHtml, "Primary Features</h3>", "Additional</h3>");
			cnt++;
			if(cnt>=8)break;
		}
		//quickCount = quickUrls.length;
	}
	

//	U.log(allHomesData);
	//--------------fetch data from Homes for Sales------------
	String[] homeSection = U.getValues(html, "<div class=\"IDX-showcaseContainer\" style=\"height: 306px;\"><a href=\"", "\"");
	U.log("Total Homes : "+homeSection.length);
	
	for(String homeSec : homeSection){
		U.log("homeSec11 : "+homeSec);
		String homeHtml = U.getHTML(homeSec);
		allHomesData +=U.getSectionValue(homeHtml, "Discover your dream home</span>", "arget=\"blank\">IDX Broker</a>") +U.getSectionValue(homeHtml, "<div id=\"IDX-detailsAddress\">", "Zoning Info");
		cnt++;
//		if(cnt>=8)break;
	}
//============================================Price and SQ.FT======================================================================
	
	
	String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
	String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	html=html.replace("homes with lots of living space, starting in the $170s", "");

	html=html.replaceAll("0�s|0's|0’s|0&#8217;s|0s|0k's|0k|0&#8217;s","0,000").replace("$1 million","$1,000,000").replace("average of $250,000", "")
			.replaceAll("mid \\$\\d{3},\\d{3} or", "");
	comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
	//Prices from community front page
	String htmlForPrice = U.getHTML(comUrl);
	String priceSec = U.getSectionValue(htmlForPrice, "Price Range Starting From", "</h3>");
	String priceNum = U.getSectionValue(priceSec, "secondary-title\">", "'s</span>");
	String finalPrice = priceNum+",000"; 
	U.log("Final Price: "+finalPrice);
	String prices[] = U.getPrices(html+comData+allHomesData+finalPrice,"\\$\\d{3},\\d{3}|starting in the \\d{3},\\d{3}|showcasePrice\">\\s*\\$\\d+,\\d+|low \\$\\d{3},\\d{3}|<strong> \\$\\d+,\\d+|\\$\\d+,\\d+</strong>| the \\$\\d{3},\\d+| average of \\$\\d{3},\\d+|mid \\$\\d{3},\\d{3}", 0);
	
	minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
	maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
	
//	if(comUrl.contains("https://billbeazleyhomes.com/neighborhoods/greggs-mill/")) minPrice = finalPrice;
	
//	U.log("MATCH : "+Util.matchAll(html+comData, "\\w+ \\$\\d{3},\\d{3} \\w+", 0));
	U.log("Price--->"+minPrice+" and "+maxPrice);
//	U.log("KKKKKKKK"+Util.matchAll(comData, "[\\w\\s\\W]{100}\\$170[\\w\\s\\W]{100}", 0));

//======================================================Sq.ft===========================================================================================		
	//dataOfHomes from community inspect page 
	String dataOfHomes = ALLOW_BLANK;
	String designHomeData = ALLOW_BLANK; 
	String section = ALLOW_BLANK;
	String availableHomes = U.getSectionValue(html, "Homes For Sale", "Quick");
	String quickHoveIn = U.getSectionValue(html, "Move In", "fl-col-content");
	String designHome = U.getSectionValue(html, "<span class=\"title-text pp-primary-title\">Design Your Home</span>", "<!-- .pp-content-posts -->");
	
	String designHomeUrls[] = U.getValues(designHome, "<div class=\"pp-content-grid-post-image\">", "</div>");
	U.log("designHomeUrls: "+designHomeUrls.length);
	for(String Url:designHomeUrls) {
		String homeUrl = U.getSectionValue(Url, "<a href=\"", "\"");
		U.log("homeUrl: "+homeUrl);
		designHomeData += U.getHTML(homeUrl);
		
	}
	
	String mixData = availableHomes + quickHoveIn;
	
	String urls[] = U.getValues(mixData, "href=\"", "\"");
	for(String url:urls) {
		U.log("HURLS: "+url);
		section = U.getHTML(url);
		
		if(section != null) {
			
			if(section.contains("4,577")) {
				U.log("Found");
			}
			 dataOfHomes += U.getSectionValue(section, "</span>&nbsp", "SqFt");
			//U.log("SECTION: "+section);
		}

	}
	
	
	U.log("HURLS: "+urls.length);
	
	String[] sqft = U.getSqareFeet(designHomeData+dataOfHomes+commSec.replace("$7,000 BUYER INCENTIVE", ""),"\\d,\\d{3} ft2</span>|\\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3}\n\\s*</span>|\\d,\\d+ ft2</span>|\\d,\\d+ square feet|\\d,\\d+ or as much as \\d+ square feet|\\d,\\d+ ft2",0);
//	"\\d,\\d{3} SqFt|\\d,\\d{3}</span> <span class=\"IDX-fieldLabel\">SqFt</span>|from \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} square feet|\\d+,\\d+ sq. ft|\\d{5} SF|left\">\\d{4}</td>|\\d{1},\\d+ ft|sqft \\d,\\d{3}"
	minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
	maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	

	
	U.log("SQ.FT: "+minSqft+" "+maxSqft);

//================================================community type========================================================

	String communityType=U.getCommType((html+comData).replace("disc golf",""));
	
//==========================================================Property Type================================================
	html=html.replaceAll("Grovetown Homes|Luxury Ensuite|Gardens|gardens|villa|Villa|-Patio","")
			.replace("The Estates at Southampton Near Augusta", "The Estates Homes at Southampton Near Augusta");
	
	String proptype=ALLOW_BLANK;
	proptype = U.getPropType(Decs+html+comData+allHomesData.replaceAll("Covered, Patio", "Covered Patio"));
	//U.log(Util.matchAll(html, "[\\w\\s\\W]{50}estate[\\w\\s\\W]{50}", 0));
	
//==================================================D-Property Type======================================================
	html=html.replace("Ranch Style&nbsp;&amp;","ranch-style").replaceAll("[B|b]ranch|BRANCH|15 single story", "").replace("like first floor bedrooms", "").replace("prefer first floor bedrooms", "");
	String dtype=U.getdCommType((html+comData).replaceAll("one or two stories|One and two-story", " 1 Story  2 Story "));
	
	U.log("dtype::::::::::::"+dtype);
//==============================================Property Status=========================================================
	if(html.contains("move-in ready models"))
	{
		html=html.replaceAll("quick|Quick","");
		U.log("hello-->1");
	}

	String html1 = html;
	html=html.replaceAll("READY TO MOVE IN!|.NOW OPEN!|> set to open in fall 2016.<|coming soon! Homeowner’s|style pool coming 2018|Ready|ready|<i>NOW OPEN|Pool NOW OPEN|Quick Move-In","");
	

	String pstatus=U.getPropStatus((html+comData).replaceAll("<h4>Quick Move In</h4>|We offer quick move-in  homes", "")+sts);
	U.log("status:::"+pstatus);
	U.log("quick count==="+quickCount);
	if(quickCount>0 && !pstatus.contains("Quick Move")){
		if(pstatus == ALLOW_BLANK){
			pstatus = "Quick Move-In";
		}
		else if(pstatus != ALLOW_BLANK )
		{
			pstatus = pstatus + ", Quick Move-In";
		}
	}

	if(pstatus.contains("Quick Move-in"))
	{
		dtype=U.getdCommType(html+comData+" 2 Story ");
		//proptype=U.getPropType(html+comData+" Patio Homes ");
	}
	if(proptype.contains("Townhome") && proptype.contains("Townhouse"))
		proptype = proptype.replace("Townhouse,", "");
	
	if(comUrl.contains("/woodlief/"))dtype="2 Story";
	
//	if(!comUrl.contains("/columbia-county-ga/kelarie/") || !comUrl.contains("/greggs-mill/"))
//		pstatus = pstatus.replaceAll(", Quick Move-In|Quick Move-In", "");
	
	if(pstatus.length()<3)
		pstatus = ALLOW_BLANK;
	if(comUrl.contains("https://billbeazleyhomes.com/aiken-sc-new-homes/summerton-village/")) {
		communityName="Summerton Village";
		pstatus=ALLOW_BLANK;
	}
	
//	if(comUrl.contains("billbeazleyhomes.com/neighborhoods/danbrooke-village/"))pstatus="Quick Move-in";
//============================================note====================================================================
		

	System.out.println("Derived type::::"+dtype);
	
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
//================================================================================================================
			int s=0;
		String lotCount=ALLOW_BLANK;
	String link_Sec=U.getSectionValue(html, "View Available Lots</span>", "</iframe></p>");	
//	U.log("link_Sec==="+link_Sec);
	if(link_Sec==null) {
		link_Sec=U.getSectionValue(html, "View Available lots</span>", "</iframe></p>");
	}
//	U.log("KKKKKKKK"+Util.matchAll(html, "[\\w\\s\\W]{100}View Available Lots</span>[\\w\\s\\W]{100}", 0));
//	U.log("KKKKKKKK"+Util.matchAll(html, "[\\w\\s\\W]{100}</iframe></p>[\\w\\s\\W]{100}", 0));

	
	if(link_Sec!=null) {
		String map_link=U.getSectionValue(link_Sec, "src=\"", "\">");
		
	map_link=map_link.replace("marketing/Danbrooke ge", "marketing/Danbrooke%20Village")
			.replace("marketing/Summerton ge", "marketing/Summerton%20Village")
			.replace("marketing/The Retreat At Storm", "marketing/The%20Retreat%20At%20Storm%20Branch");
		U.log("map_link===="+map_link);
		if(map_link!=null) {
			String mapHtml=U.getHtml(map_link, driver);
			String data_Sec=U.getSectionValue(mapHtml, "Sales Status<a href=\"", "<script>");
//			U.log("data_Sec :::" +data_Sec);
			if(data_Sec!=null) {
			String[] count_Sec=U.getValues(data_Sec, "<div class=\"legend_data_content\">", "</div>");
			if(count_Sec.length>0) {
			for(String count : count_Sec) {
				count=U.getNoHtml(count).trim();
//				U.log("count :::" +count);
				count=Util.match(count, "\\d+");
				
				s+=Integer.parseInt(count);
				
			}
			}
			}
			U.log("ddddddd :::" +s);
			lotCount=Integer.toString(s);
			
		}
	}
	if(lotCount.equals("0"))
	{
		lotCount=ALLOW_BLANK;
	}
		
		
		
		data.addCommunity(communityName.replace("Hayne�s", "Haynes").replace("Gregg�s", "Greggs"),comUrl, communityType);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("Hayne�s","Haynes").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
		j++;
//	}catch(Exception e){}
	}

}