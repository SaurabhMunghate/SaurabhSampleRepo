package com.shatam.b_241_260;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKeylandHomes extends AbstractScrapper{
	WebDriver driver = null;
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractKeylandHomes()
			throws Exception {
		super("Keyland Homes", "https://www.keylandhomes.com");
		LOGGER=new CommunityLogger("Keyland Homes");
		// TODO Auto-generated constructor stub
	}

	
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractKeylandHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Keyland Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		// TODO Auto-generated method stub
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam/CRXChrome/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		
		 Proxy proxy = new Proxy();
//		 proxy.setHttpProxy("45.145.150.50:3128");
//		 proxy.setSslProxy("138.197.209.229:3128"); 
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			//driver = new ChromeDriver(capabilities);
		 //capabilities.setCapability("proxy", proxy);
		 driver = new ChromeDriver(capabilities);
		Thread.sleep(10000);
		
		
//		String mainHtml=U.getHTMLwithProxy("https://keylandhomes.com/our-communities/");
		String mainHtml=U.getHtml("https://keylandhomes.com/our-communities/",driver);

		//U.log(mainHtml);
		String[] sec=U.getValues(mainHtml,"<div class=\"uk-cover-container\">","View Community</a></p>");
		U.log(sec.length);
		for(String aSec:sec)
		{
			String url=U.getSectionValue(aSec, "<a href=\"","\"");
			U.log("URL:\t" + url);
			U.log(U.getCache(url));
			addDetail(url,aSec);
		//	break;
		}
//		driver.close();
		try{
			driver.quit();
		}catch(Exception e){}
		LOGGER.DisposeLogger();
	}



	private void addDetail(String comUrl, String dataSec) throws Exception {
		// TODO Auto-generated method stub
//https://www.keylandhomes.com/new-home-communities/homes-lakeville-berres-ridge/
		
//	if(!comUrl.contains("https://keylandhomes.com/new-home-communities/knob-hill-villas/"))return;
	//	if(j>=8)
		{
			U.log("count==="+j);
			
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"---------------> Repeated");
			k++;
			return;
		}
		/*if(comUrl.contains("bridle-creek")){
			LOGGER.AddCommunityUrl(comUrl+"---------------> redirected you too many times.");
			k++;
			return;
		}*/
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log("\n Count: "+j);
		U.log(U.getCache(comUrl));
		U.log("commUrl-->"+comUrl);
//				String html=U.getHTMLwithProxy(comUrl);
		
		  String html=U.getHtml(comUrl,driver);
				U.log(U.getCache(comUrl));
				/*String rem=U.getSectionValue(html, "project_next one columns\">","</body>");
				html=html.replace(rem,"");*/
				
//				U.log("1 story match"+Util.match(html, "story"));
				html=html.replace("data-type=\"1 Story\"", "");
				U.log("1 story match in sec"+Util.match(dataSec, "story"));
				//============================================Community name=======================================================================
				String communityName=U.getSectionValue(dataSec, " class=\"uk-link-reset\">","<");
				
				communityName = communityName.replaceAll("- Coming Soon!|Coming Soon!", "");
				communityName=communityName.replace("Knob Hill Villas","Knob Hill");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				String note=ALLOW_BLANK;
				String addSec=U.getSectionValue(html, "<div class=\"uk-width-expand\">","</div>");
				U.log(addSec);
				if(addSec!=null)
				{
				addSec=addSec.replaceAll("Call For Information|Call for Information", "");
				addSec=addSec.replace("<br />",",");
				addSec=addSec.replace("<br>",",");
				String[] add1=U.getAddress(addSec);
				System.out.println(add1.length);
//				if(add1.length==3)
//				{
//					add[0]=add1[0];
//					add[1]=add1[1];
//					add[2]=add1[2];
//				}
				add = add1;
				}
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				// Given address is home address not community address so geo code is true
				
//				U.log(Util.matchAll(html, "[\\w\\s\\W]{100}44.722[\\w\\s\\W]{100}",0));
				String latlng_sec=U.getSectionValue(html, "href=\"https://maps.google.com/maps?ll=","&amp;");
				U.log("latlng_sec--->"+latlng_sec);
				if(latlng_sec!=null) {
				latlag=latlng_sec.split(",");
//				latlag[1]=U.getSectionValue(html, "data-lng=\"","\"");
				geo="False";
				}
				else {
					latlag[0]=U.getSectionValue(html, "data-lat=\"", "\"");
					latlag[1]=U.getSectionValue(html, "data-lng=\"", "\"");
				}
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=null && (latlag[0]==ALLOW_BLANK || latlag[0]==null))
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag =U.getlatlongHereApi(add);
					
					geo="TRUE";
				}
//				if(comUrl.contains("/lakeville-mn-new-homes-pheasant-run/") || 
//						comUrl.contains("/new-homes-apple-valley-mn-quarry-ponds/") || 
//						comUrl.contains("/homes-apple-valley-mn-quarry-ridge/") ||
//						comUrl.contains("/new-home-communities/berres-ridge/")){
//					add = U.getAddressGoogleApi(latlag);
//					geo = "True";
//				}
				if((add[3].length()<5 || add[3] == ALLOW_BLANK) && latlag[0].length()>4)
				{
					//String latLong[] = U.getlatlongGoogleApi(add);
					String addVal [] = U.getAddressGoogleApi(latlag);
					if(addVal == null) addVal = U.getAddressHereApi(latlag);
					add[3] = addVal[3];
					geo = "True";
				}
				
				if((add[0] == ALLOW_BLANK || add[0].isEmpty()) && latlag[0]!=null || add[0].length()<4)
				{
					String addVal [] = U.getAddressGoogleApi(latlag);
					if(addVal == null) addVal = U.getAddressHereApi(latlag);
					add[0]=addVal[0];
					geo="TRUE";
				}
		
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		//----------------Home Design Data-----------------------
				//String homeDesignData = getHomeDesignData("http://www.keylandhomes.com/new-home-plans/",communityName);
			
		//============================================Price and SQ.FT======================================================================
				String homeHtml="";
				String[] urlHome=U.getValues(html, "<div class=\"w25 columns no-pad\">", "</div>");
				for(String sec:urlHome)
				{
					String url=U.getSectionValue(sec,"<a href=\"","\"");
					homeHtml=homeHtml+U.getHTMLwithProxy(url);
					
				}
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				dataSec=dataSec.replaceAll("0�s|0's|0s|0&#8217;s","0,000");
				html=html.replaceAll("0�s|0's|0s|0&#8217;s","0,000")
						.replace("5's", "5,000");
				String prices[] = U.getPrices(html+dataSec+homeHtml,"From the mid \\$\\d{3},\\d{3}|\\$\\d+,\\d+</span>|From The \\$\\d{3},\\d+|From the \\$\\d{3},\\d+|bottom\">\\$\\d{3},\\d+|\\$\\d{3},\\d{3}\\s*</div>", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		

				
				String[] sqft = U
						.getSqareFeet(
								html+dataSec+homeHtml,
								" \\d{4} sf -|\\d+,\\d+ to \\d+,\\d+ square feet|\\d+,\\d+ sq. ft|SqFt:</strong> \\d{4}|\\d{4} sf</span></a>|\\d,\\d{3} SqFt",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
		//================================================community type========================================================
	
				String communityType=U.getCommType(html+dataSec);
				
		//==========================================================Property Type================================================
				html=html.replaceAll("participation|it of cabin fever|data-type=\"2 Story\"","");
				String proptype=U.getPropType(html+dataSec);
				
		//==================================================D-Property Type======================================================
				U.log("MMMMM"+Util.matchAll(html+dataSec, "[\\w\\W\\s]{50}ranch[\\w\\W\\s]{50}",0));

				String dtype=U.getdCommType((html+dataSec).replaceAll("data-type=\"Ranch\"|A two-story home with|A two-story home with four bedrooms", ""));
		//==============================================Property Status=========================================================
				
//				U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}Coming Fall[\\w\\s\\W]{30}", 0));
				
				html=html.replaceAll("Hours:</strong>Coming Soon|Coming Fall 2019!", "").replaceAll("Fairfield Drive - Coming Soon| The Meadows of Cleary Lake &#8211; Coming Fall 2019!", "");
				String pstatus=U.getPropStatus(html);
				
		//============================================note====================================================================
				
				// note=U.getnote(html);
				add[0] = add[0].replace("(see website", "");
				U.log(Arrays.toString(add));
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addUnitCount(ALLOW_BLANK);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				
		}
		j++;
	}



	private String getHomeDesignData(String url, String cName) throws Exception {
		
		String ComHomeDesignData = getHtml(url,cName, driver);
		return ComHomeDesignData;
	}
	public static String getHtml(String url,String cName, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url+cName);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(	new FileWriter(f));
			
					driver.get("http://www.usa-proxy.org/");
					U.log("after::::"+url);
					Thread.sleep(5000);
					WebElement inputBox = driver.findElement(By.xpath("//*[@id=\"input\"]"));//inptu field
					inputBox.sendKeys(url);
					 WebElement click = driver.findElement(By.xpath("//*[@id=\"content\"]/form/input[2]"));//go button
					 click.click();
					
					U.log("Current URL:::" + driver.getCurrentUrl());
					
					//Sellect community
					Thread.sleep(10000);
				
					Select dropdown = new Select(driver.findElement(By.name("comm_name"))); //comm_name
					dropdown.selectByVisibleText(cName);
					Thread.sleep(5000);
					//Filler
					 WebElement clickFilter = driver.findElement(By.cssSelector("body > div.content.block > div > div.w100.columns > div > form > input.remove-bottom"));//Filler
					 clickFilter.click();
					 Thread.sleep(5000);
					U.log("::::::::::::Click Filter Success::::::::::");
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
}