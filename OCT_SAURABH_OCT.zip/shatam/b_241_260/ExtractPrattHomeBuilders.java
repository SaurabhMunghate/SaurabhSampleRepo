/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_241_260;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPrattHomeBuilders extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver = null;

	public ExtractPrattHomeBuilders()
			throws Exception {
		super("Pratt Home Builders","https://www.prattliving.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Pratt Home Builders");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractPrattHomeBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Pratt Home Builders.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam/CRXChrome/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		driver = new ChromeDriver(capabilities);
		Thread.sleep(7000);
		

//		U.setUpGeckoPath();;
//		driver = new FirefoxDriver();//for sitePlan
    		
//		String moveInPage=U.getHTMLwithProxy("https://www.prattliving.com/find-your-home/move-in-ready-homes/");
//		String mainHtml=U.getHTMLwithProxy("http://www.prattliving.com/find-your-home/");
		
		String moveInPage=U.getHtml("https://www.prattliving.com/find-your-home/move-in-ready-homes/",driver);
		String mainHtml=U.getHtml("http://www.prattliving.com/find-your-home/",driver);
		
		String[] comSec=U.getValues(mainHtml, " var contentString"," // pixels ");
		U.log("communities in total are"+comSec.length);
		for(String comData:comSec)
		{
			String comUrl=U.getSectionValue(comData, "a href=\"","\"");
			U.log("comUrl::::::"+comUrl);
			addDetails(comUrl,comData,moveInPage);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData,String moveInPage) throws Exception {
		// TODO Auto-generated method stub
	//if(j>=4)
		//Single Run==============
		
//		if(!comUrl.contains("https://www.prattliving.com/new-home-communities/magnolia-farms-apison-by-pratt-homes/")) return;
	
		
		{
//		if(!comUrl.contains("commUrl-->https://www.prattliving.com/new-home-communities/engel-park-by-pratt-homes/")) return;
	//	if(comUrl.contains("https://www.prattliving.com/new-home-communities/engel-park-by-pratt-homes/"))return;
		U.log(j+"   commUrl-->"+comUrl);
		
		if(data.communityUrlExists(comUrl))
		{
		LOGGER.AddCommunityUrl(comUrl+"------------ Repeated");
		k++;
		return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		      // U.bypassCertificate();
		   //dt 	String html=U.getHTMLwithProxy(comUrl);
		        String html=U.getHtml(comUrl,driver);
		    	U.bypassCertificate();
		    	Thread.sleep(10000);
		    	
			//	String html=U.getHtml(comUrl,driver);
				
				String localAreaSec = U.getSectionValue(html, "<h1 class=\"uk-text-center\">Local Area</h1>", "<li id=\"map-block\"");
				if(localAreaSec!=null)
				html=html.replace(localAreaSec, "");
		//============================================Community name=======================================================================
				//String communityName=U.getSectionValue(comData, "'<h3>'+\"","\"+'</h3>'").replace("&#8217;","");
				String communityName= U.getCapitalise(U.getSectionValue(comUrl, "communities/", "/").replace("-", " "));
				communityName=communityName.replace("The_inlet", "The Inlet").replace("Huntley_meadows","Huntley meadows")
						.replace("Magnolia Farms Apison ", "Magnolia Farms").replace("By Pratt Homes", "").replace("Hixson Amber Valley", "Amber Valley").replace("Hixson Amber Ridge", "Amber Ridge").replace("Amber Ridge Copy", "Amber Valley");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				
				String note=U.getnote(html.replace("Available Pre-Sale</span><", ""));
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latLng={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				//---------Adress and latlng using google iframe link--------------------------
				
				String googleIFrameSec = U.getSectionValue(html, "<iframe width=\"600\" height=\"450\" style=\"border: 0;\" src=\"", "\"");
				
				if(googleIFrameSec!=null){
					U.log("iFrameSec::::::::::"+googleIFrameSec);
					//------------address and latlng from google link-----------------------
					if(googleIFrameSec.contains("www.google.com/maps")){
						//--google address---
						String googleAddSec = U.getSectionValue(googleIFrameSec, "!2s", "!5");
						if(googleAddSec!=null){
							googleAddSec = googleAddSec.replace("+", " ").replace("%2C ", ",");
							String[] tempAdd = googleAddSec.split(",");
							add[0] = tempAdd[0];
							add[1] = tempAdd[1];
							add[2] = Util.match(tempAdd[2], "\\w+");
							add[3] =Util.match(tempAdd[2], "\\d+");
							U.log("Google address is :::" + Arrays.toString(add));
						}
						//--google latlng---
						String googleLatlngSec = U.getSectionValue(googleIFrameSec, "!2d", "!2m");
						U.log("googleLatlngSec::::::::::"+googleLatlngSec);
						if(googleLatlngSec!=null){
							String[] tempLatlng = googleLatlngSec.split("!3d");					
							latLng[0] = tempLatlng[1];
							latLng[1] = tempLatlng[0];
							U.log("Google latLng is :::" + Arrays.toString(latLng));
						}
						geo  = "FALSE";
					}
				}
				
				//---------Adress and latlng using bing iframe link--------------------------
				String bingIFrameSec = U.getSectionValue(html, "<iframe width=\"500\" height=\"400\" frameborder=\"0\" src=\"", "\"");
				
				if(bingIFrameSec!=null){
					U.log("bingIFrameSec::::::::::"+bingIFrameSec);
						//--google latlng---
						String bingLatlngSec = U.getSectionValue(bingIFrameSec, "cp=", "&amp");
						U.log("bingLatlngSec::::::::::"+bingLatlngSec);
						if(bingLatlngSec!=null){
							latLng = bingLatlngSec.split("~");					
							U.log("Bing latLng is :::" + Arrays.toString(latLng));
						}
						if(bingIFrameSec.contains("pp=")){
							//--google address---
							String bingAddSec = U.getSectionValue(bingIFrameSec, "pp=", "~~");
							if(bingAddSec!=null && bingAddSec.length()!=0){
								
								bingAddSec = bingAddSec.replace("%20", " ").replace("%2C ", ",");
								U.log("bingAddSec::::::"+bingAddSec);
								String[] tempAdd = bingAddSec.split(",");
								if(tempAdd.length==3){
									add[0] = tempAdd[0];
									add[1] = tempAdd[1];
									add[2] = Util.match(tempAdd[2], "\\w+");
									add[3] =Util.match(tempAdd[2], "\\d+");
									U.log("Bing address is :::" + Arrays.toString(add));
								}
								else{
									add = U.getAddressGoogleApi(latLng);
									if(add == null) add = U.getAddressHereApi(latLng);
									geo = "TRUE";
								}
							}
							else{
								add = U.getAddressGoogleApi(latLng);
								if(add == null) add = U.getAddressHereApi(latLng);
								geo = "TRUE";
							}
						}
				}
				String latlonSec=U.getSectionValue(comData, "LatLng(", "),");
				latLng=latlonSec.split(",");
				
				//----------------Only when address and latlng both are not present on  community page then take address of sales office-------------
				String addSec=U.getSectionValue(html, "Sales Office</strong><br />","</p>").replace("Call Brittany at (423) 757-7687","");
				U.log("<<<<<<<<"+addSec);
				if(addSec!=null && add[0].length()<3 )
				{
					addSec = addSec.replaceAll("Call Brittany and Shae at (423) 757-7687 Ext 1,|Please Call Brittany And Shae (423) 757-7687 Ext 1|Call Brittany And Shae At (423) 757-7687 Extension 1|Call Brittany And Shae At (423) 757-7687 Ext 1||Off Julian Road near Council Fire Golf Course|Off Julian Road", "")
							.replace("Please call (423) 757-7687", "");
					addSec=addSec.replace("<br />",",");
					addSec=addSec.replace(", ", "");
					addSec=addSec.replace("�", "");
					addSec=addSec.replaceAll("\\s+", " ");
					U.log(addSec);
					
					add=U.getAddress(addSec);
				}
				if (add[0].contains("1412 Sedgefield Drive")) {
					add[0]="1412 Sedgefield Drive";
				}
				
				if(comUrl.contains("/engel-park-by-pratt-homes/")) {
					add[1]="Chattanooga";
					add[2]="TN";
					add[3]="37405";
					latLng = U.getlatlongGoogleApi(add);
					add= U.getAddressGoogleApi(latLng);
					geo = "TRUE";
					note= "Address And Lat-Lng Taken From City State";
				}
				U.log("0000"+add[0]);
				add[0]=add[0].replaceAll("Please call Brittany and Shae|Please Call Brittany And Shae|Call Brittany and Shae at ","");
			//	add[0]=add[0].replaceAll("\\(\\d{3}\\)\\s*\\d{3}-\\de{4}\\s*Ext[.]\\s*1", "");
				
				add[0]=add[0].replace("(423) 757-7687","");
				
				add[0]=add[0].replaceAll("Extension 1|Ext. 1|Ext 1", "");//extensiona replace in may 2022
				//|Please call Brittany and Shae (423) 757-7687 Ext. 1|Please Call Brittany And Shae (423) 757-7687 Ext 1|Please Call Brittany And Shae (423) 757-7687 Ext. 1", "");
				add[0]=add[0].replace("Call Brittany and Shae at (423) 757-7687 Extension 1","");
//				add[0]=add[0].replace("Call Brittany and Shae at (423) 757-7687 Ext 1", "").replace("Call Brittany And Shae At (423) 757-7687 Extension 1","");
//				add[0]=add[0].replace("Please Call Brittany And Shae (423) 757-7687 Ext 1", "");
				U.log("  "+add[0].trim()+"  "+add[1]+"  "+add[2]+"  "+add[3]);
			//	U.log(comData);
				if(add[1]!=ALLOW_BLANK && latLng[0]==ALLOW_BLANK)
				{
					latLng=U.getlatlongGoogleApi(add);
					if(latLng == null) latLng = U.getlatlongHereApi(add);
					geo="TRUE";
				}
				
				if(add[0].length()<3 && latLng[0]!=ALLOW_BLANK)
				{
					add = U.getAddressGoogleApi(latLng);
					geo="TRUE";
				}
				
				U.log("hhhh1--->"+latLng[0]+"  "+latLng[1]);
		
		//============================================Price and SQ.FT======================================================================
				
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				html=html.replace("Craftsman-inspired homes in the mid $200s", "");
				html=html.replace(" 200's", "$200,000").replace(" 400's", "$400,000").replaceAll("\\$409,900 - Price Reduced|\\$324,900", "").replace(" $500's","$500,000").replace(" $300's", "$300,000");
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
				comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000").replace("5s -", "5,000 -");
//				U.log(comData);
				if(html==null)html=ALLOW_BLANK;
				if(html.contains("")) {
					String remData[]= U.getValues(html, "<div class=\"popover-inner\"><h4 class=\"popover-title\">", "</p>");
					for(String rem:remData) {
//						U.log(rem);
						html=html.replace(rem, "");
					}
				}
//				U.log(html);
				if(comUrl.contains("https://www.prattliving.com/new-home-communities/creekside-at-hampton-meadows/"))
					html=html.replace("$367,900", "");
					
				String prices[] = U.getPrices(html,"From the low \\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\d{3},\\d{3} - \\d{3},\\d{3}<br />", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
				//U.log(comData);3100 - 3,550 SQFT
				String[] sqft = U.getSqareFeet(	html+comData,
						"\\d,\\d{3} - \\d,\\d{3} sqft|\\d{4} - \\d,\\d{3} SQFT|\\d,\\d{3} - \\d,\\d{3} SQ FT|\\d,\\d{3} - \\d,\\d{3} SQFT|\\d+,\\d+ SQFT",0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
		//==================fetch available Home Data==============
				String allAvailData = ALLOW_BLANK;
				String[] availUrls ={};
				String availHtml="";
				String availSec=U.getSectionValue(html, "<h1 class=\"uk-text-center\">Available Homes</h1>", "<a id=\"siteplan\">");
				if(availSec!=null){
					availUrls = U.getValues(availSec, "<div class=\"uk-panel uk-panel-box uk-panel-hover uk-text-center\"", "Baths");
				U.log("total avail home = "+availUrls.length);
				
				for(String availUrl : availUrls){
					//U.log(availUrl);
					availUrl = U.getSectionValue(availUrl, "href='", "'");
					if(availUrl.contains("-commons-town-home-"))continue;
					U.log("availUrl::::: "+availUrl);
//					availHtml = U.getHTMLwithProxy(availUrl);
					availHtml = U.getHtml(availUrl,driver);
					allAvailData = U.getSectionValue(availHtml, "<div class=\"uk-width-medium-1-2 uk-flex-middle\">", "<div class=\"footer uk-block\">") + allAvailData;
//					U.log(allAvailData);
					allAvailData = allAvailData.replaceAll("Stories:</strong>", "Stories:").replace("occupies the entire third floor", "");
//					if (availUrl.contains("8365-river-birch-loop/")) {
//						allAvailData+="patio";
//					}
				}
				}
				
				String allDesignData=ALLOW_BLANK;
				String[] designHomeUrl=U.getValues(html, "uk-panel uk-panel-box uk-panel-hover uk-text-center", "</p>");
				U.log("Total Design Home:--"+designHomeUrl.length);
				int i=0;
				for (String string : designHomeUrl) {
					String ss=U.getSectionValue(string, "<a href=\"","\"");
					if(ss==null)continue;
					U.log(ss);
//	dt				allDesignData+=U.getHTMLwithProxy(ss);
					allDesignData+=U.getHtml(ss,driver);
					if(i>5)break;
					i++;
					
				}
				
				String homedata="";
				int count=0;
////				U.log(U.getCache("https://www.prattliving.com/find-your-home/quick-move-in-page/"));
//	dt			String quickHtml=U.getHTMLwithProxy("https://www.prattliving.com/find-your-home/quick-move-in-page/");
				String quickHtml=U.getHtml("https://www.prattliving.com/find-your-home/quick-move-in-page/",driver);

				String[] quickComSec=U.getValues(quickHtml, "<div class=\"uk-panel uk-panel-box uk-panel-hover uk-text-center\"", "Baths:");
				U.log(">>>>>>>+"+quickComSec.length);
				for(String quick : quickComSec) {
					if(quick.contains("Available Soon")||quick.contains("Sold"))
						continue;
					String homeurl=U.getSectionValue(quick, "href='", "';\">");
//					U.log(">>>>>>>+"+homeurl);
// dt					String homeHtml=U.getHTMLwithProxy(homeurl);
					String homeHtml=U.getHtml(homeurl,driver);

					if(homeHtml.contains(communityName)) {
						count++;
						U.log(">>>>>>>+"+homeurl);
					homedata+=homeHtml;
					}
			
					else 
						continue;
				}
				U.log("count>>>>>>>>"+count);
				
		//================================================community type========================================================
				//comData = U.removeSectionValue(comData, "<div class=\"hidden\">", " </div>");
				
				//
				//html = html.replaceAll("Fire Golf Course for a round of golf|Fire Golf Course|Windstone Golf|Fire Golf|Valley Brook Golf Course|Creeks Bend Golf Course|master-planned-home/\">|Honors golf courses", "");
				
				String communityType=U.getCommType(html+comData);
//				U.log(Util.matchAll(allAvailData,"patio",0));

		//==========================================================Property Type================================================
				html = html.replaceAll("Sales Office Information:</h1>|carriage style garage|Hours</strong><br />\\s*Coming Soon<br />|\\s*Coming soon!</p>|Available Townhomes|Townhome Locations|>Apartment Homes</a>|\"/apartment-|77\">Traditional|homes\">Apartment|\">Apartment|townhomes\" target=|Townhomes</a>|href=\"/townhome|parent\">Townhome|Pratt Homes. Craftsman", "");
				html = html.replace("traditional, contemporary or something", "traditional layout").replace("Opening in February 2020", "").replace("with craftsman touches", "with Craftsman Style Homes touches").replaceAll("traditional to cozy craftsman.", "New Tradition Homes,with Craftsman Style Homes touches");
				html=html.replaceAll("minimal HOA annual fee", "low HOA fees").replace("single level, bungalow-style ", "Bungalow Series");
				String proptype=U.getPropType((html+comData +allAvailData+allDesignData+comUrl).replaceAll("rd car garage with carriage style entr|Forget cabin fever|carriage style garage|available-townhomes-lease|Available Townhomes for Lease|craftsman accents|tion for a carriage style garage", ""));
//				U.log(Util.match((html+comData +allAvailData+allDesignData+comUrl).replaceAll("rd car garage with carriage style entr|Forget cabin fever|carriage style garage|available-townhomes-lease|Available Townhomes for Lease|craftsman accents|tion for a carriage style garage", ""), ".*Carriag.*"));
		//==================================================D-Property Type======================================================
				//allDesignData=allDesignData.replace("Stories:</strong> ", "Story ");
				//allDesignData=U.getNoHtml(allDesignData);
				
				String dtype=U.getdCommType(html+comData + allAvailData+allDesignData.replaceAll("<strong>Stories:</strong> ","Stories: "));
		//==============================================Property Status=========================================================
				html = html.replaceAll("Pricing coming soon|<strong>Office Hours</strong><br />\\s*Coming Soon<br />|SOON!</a>|Available Pre-Sale</span><|Single Level\\s*Available Summer 2019</p>|Model Home Coming Soon|Coming Soon! Call us|One the last new homes available in this Community|Move In Ready Homes</a>|are now available close|Mobile Information Center Now Open|plans are now|development coming Fall 2018|just a few homes left|Coming Soon</p>|move-in ready!", "")
						.replace("Phase II is close to selling out", "Phase II selling out")
						.replace("The Final Phase opening soon", "The Final phase opens early 2022")
						.replace("Coming late 2021/early 2022", "Coming early 2022")
						.replace("FINAL phase of Seven Lakes opens late 2021/early 2022", "FINAL phase opens late 2021/early 2022").replace("Phase III is now selling", "Phase III now selling").replace("Now selling in Phase 2", "Now selling Phase 2").replace("Phase 4 to open in early 2020", "Phase 4 open early 2020").replace("New phase opening in 2020", "").replace("New phase opening in 2020","");
				
				
				String pstatus=U.getPropStatus((html+comData).replace("Phase 1 is close to selling out", "Phase 1 selling out")
						.replace("FINAL phase of Seven Lakes opens late 2021/early 2022","Final phase opens late 2021/early 2022").replaceAll("Pratt Home Builders \\| Now Open|Now Open!  Pratt Home Builders|quick-move-in-page/|Quick Move-in</a>|Phase 2 Opening Fall 2021|Pricing coming soon|Single Level\\s+Available Spring of 2019| The Final Phase opening soon!\"|Ready for Move In Spring 2020 - <a href=\"|Coming Soon - <a href=|Coming Soon!</p>|Ready for Move In Spring 2020</p>|Phase 3 opening Fall 2019<br />|for move-in Fall of 2017|Available for move in|Move-in Ready</span>|and final phase", "").replace("The FINAL phase of Seven Lakes opens late 2021/early 2022!", "The Final phase of seven lakes opens late 2021/early 2022").replace("Phase II is close to selling out!","Phase II close to selling out").replace("The FINAL phase of Seven Lakes opens late 2021/early 2022!","The FINAL phase opens late 2021/early 2022").replace("Coming late 2021/early 2022!","Coming late 2021/early 2022").replace("Final Phase opening soon!","Final Phase opening soon"));
				
				if(comUrl.contains("http://www.prattliving.com/Seven-Lakes") || comUrl.contains("http://www.prattliving.com/Stonebrook") || comUrl.contains("www.prattliving.com/Timber-Creek"))
					pstatus = "Phase III Coming Soon"; //Image 
				
//				U.log(Util.matchAll(html+comData, "[\\w\\s\\W]{50}opening[\\w\\s\\W]{50}", 0));

				U.log(">>>>>"+pstatus);
		//============================================note====================================================================
//				U.log(U.getSectionValue(html, "Available Homes</h1>", "siteplan-block"));
				/*if(availUrls.length>0 && html.contains("uk-panel-badge uk-badge \">Move-in Ready</div>")){
					if(pstatus==ALLOW_BLANK)pstatus="Move-In Ready";
					else pstatus=pstatus+", Move-In Ready";
				}*/
//				U.log("pstatus.length()===="+pstatus.length());
                if(count>0 ) {
	               if(pstatus.length()>3) {
		             pstatus=pstatus+", Quick Move-in";
	               }
	            else {
		           pstatus="Quick Move-in";
	                 }
                 }
				
				communityName = communityName.trim().replaceAll(" Cleveland Pratt Homes$| Apison$", "");
			//	if(comUrl.contains("https://www.prattliving.com/new-home-communities/cove-at-signal-forest-by-pratt-homes/"))pstatus = "Now Selling";//Img
//				if(comUrl.contains("https://www.prattliving.com/new-home-communities/river-watch-by-pratt-homes/"))pstatus = "Now Selling";//Img
				
				if(html.contains("<div class=\"uk-panel-badge uk-badge \">Move-in Ready</div>") && !pstatus.contains("Move"))
				{
					
					if(pstatus.length()<4)
						pstatus = "Move-in Ready";
					else
						pstatus = pstatus + ", Move-in Ready";
				}
				pstatus=pstatus.replace("New Phase Opening In 2020, New Phase Open", "New Phase Opening In 2020");
				pstatus=pstatus.replace("Final Phase, Last Home Available In Phase 3, Final Phase Opens Late 2021/early 2022", "Last Home Available In Phase 3, Final Phase Opens Late 2021/early 2022");
				
				
				
				add[1] = add[1].replace("Soddy-Daisy", "Soddy Daisy");
				
				//	Site Plan
				
				String sitePlanSec=U.getSectionValue(html, "<a id=\"siteplan\"></a>", "</li>");
			    int lotCount=0;
			    String noOfUnits=ALLOW_BLANK;
				if(sitePlanSec!=null) {
					String siteMapUrl=U.getSectionValue(sitePlanSec, "data-src=\"", "\"");
					U.log("SiteMapUrl== "+siteMapUrl);
					String siteMapHtml=U.getHtml(siteMapUrl, driver);
					U.log("SiteMap Path:: "+U.getCache(siteMapUrl));
					String lotData[]=U.getValues(siteMapHtml, "<g id=\"v.1.opt", "\">");
					lotCount=lotData.length;
					noOfUnits=Integer.toString(lotCount);
					
					if(noOfUnits.equals("0"))
						noOfUnits=ALLOW_BLANK;
				}
				U.log("Number of Units= "+noOfUnits);
				
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim().toLowerCase(), "TN", add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus.replace("Iii", "III").replace("Ii", "II"));
					data.addNotes(note);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
					data.addUnitCount(noOfUnits);
	}
					j++;
	}

}