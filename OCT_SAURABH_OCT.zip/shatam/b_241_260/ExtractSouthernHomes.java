/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_241_260;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSouthernHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public ExtractSouthernHomes()
			throws Exception {
		super("Southern Homes","https://www.mysouthernhome.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Southern Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSouthernHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Southern Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String mainHtml=U.getHtml("https://www.mysouthernhome.com/our-communities",driver);
		
		String[] comSec=U.getValues(mainHtml, "template-data=\"community\"","Visit <i");
		U.log("comUrl--------->"+comSec.length);
		for(String comData:comSec)
		{
			String comUrl=U.getSectionValue(comData, "href=\"","\"");
			//U.log("comUrl--------->"+"https://www.mysouthernhome.com"+comUrl);
			
//			try {
				addDetails("https://www.mysouthernhome.com"+comUrl,comData);
//			} catch (Exception e) {}
			
		}
		U.log(comSec.length);
		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();		
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	if(!comUrl.contains("https://www.mysouthernhome.com/avon-park/twin-lakes-pointe/")) return;
//		if(j >= 16)
		{
				
				U.log(j+"   commUrl-->"+comUrl);
				if(data.communityUrlExists(comUrl))
				{
				LOGGER.AddCommunityUrl(comUrl+"-------------------- Repeated");
				k++;
				return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				
				String html=U.getHtml(comUrl,driver);
				U.log(U.getCache(comUrl));
				
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				units = getUnits(html, driver);
				
				U.log("Total Units: "+units);
				//---------------------------------------------------------
				
			//	U.log(comData);
				//html = U.removeComments(html);
			//============================================Community name=======================================================================
				String communityName=U.getSectionValue(comData, " <h4 class=\"name\">","<");
				U.log("community Name---->"+communityName);
						
			//================================================Address section===================================================================
						String note=ALLOW_BLANK;
						String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
						String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
						String geo="FALSE";
						
						String addSec=U.getSectionValue(html, "community location</h4>","</p>");
						if(addSec==null) {
						addSec=U.getSectionValue(html, "model center</h4>","</p>");
						}
						U.log("addSec :: " + addSec);
						if(addSec!=null){
							String zip=Util.match(addSec, "\\d{5}");
							if(zip!=null) {
								String city=U.getCityFromZip(zip);
								U.log(city);
								if(addSec.toLowerCase().contains(city)) {
									addSec=addSec.toLowerCase().replace(city, ","+city);
									U.log(addSec);
								}
							}
							addSec=addSec.replace("Auburndale Auburndale", "Auburndale").replace("&amp;", "&");
							addSec = addSec.replace(" Lakeland", ", Lakeland").replaceAll("<p>", "").replace("Lake Wales", ", Lake Wales")
									.replace(" Auburndale", ", Auburndale").replace("Lake Wales", ", Lake Wales").replace("Haines City", ", Haines City").replace(" Winter Haven", ", Winter Haven")
									.replace("Main St Lake Hamilton", "Main St, Lake Hamilton");
							
							if(addSec.length()>10)
							add = U.getAddress(addSec);
							
							if(add[0].contains("Berkley Rd and Lake Myrtle Park Rd")) {
								add[0] = add[0].replace("Berkley Rd and Lake Myrtle Park Rd", "Berkley Rd");
							} 
							
							U.log("Add::"+Arrays.toString(add));
						}
						
						
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
				//============latlng======================================
						
						
					String latLngSec = U.getSectionValue(html, "<a class=\"red-bg white uppercase\" target=\"_blank\" ng-href=\"https://www.google.com/maps/dir//", "\"");
					U.log("latLngSec::::::"+latLngSec);
					if(latLngSec==null && html.contains("latitude: "))
					{
						latlng[0]=U.getSectionValue(html, "latitude: ", ",");
						latlng[1]=U.getSectionValue(html, "longitude:", ",");
					}
					
					if(latLngSec!=null){
						latlng =latLngSec.split(",");
					}
					
					if(add[0].length()<4 && latlng[0].length()>4){
						add = U.getAddressGoogleApi(latlng);
						if(add == null) add = U.getAddressHereApi(latlng);
						geo = "TRUE";
					}
				//=================================================plan data======================================================================
					String planHtml="";
					String[] homeSec=U.getValues(html, "<i class=\"fa fa-heart-o\" aria-hidden=\"true\"></i>","<div class=\"img");
				//	U.log("Home Data:::::: "+homeSec.length);
					for(String home:homeSec)
					{
						
						String homeUrl=U.getSectionValue(home, "href=\"","\"");
						if(homeUrl.contains("<% ::templateData.url %>"))continue;
						homeUrl=comUrl+homeUrl;
					//	U.log("Home data::::::"+homeUrl);
						planHtml=planHtml+U.getHtml(homeUrl, driver);
					}
					//==============================================Property Status=========================================================
					html=html.replaceAll("Hurry, One Home Left!&nbsp;| ng-hide\">\\s*<p>COMING ", "");
//					U.log(comData);
					comData = comData.replaceAll("'closeout'|-closeout|ng-hide\" style=\"\"> Community Closeout", "");
					//U.log(comData);
//						U.log("MMMMMMM"+Util.matchAll(html, "[\\w\\s\\W]{100}COMMUNITY CLOSEOUT[\\w\\s\\W]{100}", 0));

					if(html.contains("class=\"banner-availability ng-hide\"> <p>COMMUNITY CLOSEOUT"))
					{
						html=html.replace("COMMUNITY CLOSEOUT", "");
					}
					
					
					String pstatus=U.getPropStatus(comData +(html).replaceAll("Move-In Ready Only|closeout|Closeout",""));

			//============================================note====================================================================
			//========================================getting move in ready(2nd nov 2018)==============================//
//					String movieIn
					String moveinHtml=U.getHtml("https://www.mysouthernhome.com/find-your-home/move-in-ready",driver);
					String moveinHomes[]=U.getValues(moveinHtml, "ng-repeat=\"home in homes | orderBy:sortType:sortReverse\"", "class=\"fa fa-arrow-circle-o-right\"");
					moveinHtml=U.removeSectionValue(moveinHtml, " <!-- footer --> ", "</body>");
					if(moveinHtml.toLowerCase().contains(communityName.toLowerCase())){
						if( pstatus==ALLOW_BLANK)
							pstatus="Move-In Ready";
						else
							pstatus=pstatus+", Move-In Ready";;
					}
					String moveInData="";
					for (String movein : moveinHomes) {
						if(movein.toLowerCase().contains(communityName.toLowerCase())) {
							moveInData+=movein;
						//	U.log(movein);
						}
					}
				//============================================Price and SQ.FT======================================================================
						
						
						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
						
						html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
					//	planHtml=planHtml.replace("\">$225,900</span>", "");
						String prices[] = U.getPrices(html+moveInData+comData+planHtml,"\"price\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</div>|From: \\$\\d{3},\\d{3}|From \\$\\d{3},\\d+|mid \\$\\d+,\\d+|the \\$\\d+,\\d+", 0);
						U.log(Util.matchAll(planHtml, "[\\w\\s\\W]{30}230,900[\\w\\s\\W]{30}", 0));
						minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
						maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
						
						U.log("Price--->"+minPrice+" "+maxPrice);
						
				//======================================================Sq.ft===========================================================================================		
						html = html.replaceAll("2,000 Sq. Ft. features list| class=\"ng-hide\"> <a ng-href=\"\" class=\"red uppercase\" target=\"_blank\"> &lt; \\d,\\d{3} Sq. Ft. features list <i class=|2,000\\+ sq. ft. features list |<span>1,176 - 3,881</span>", "");
//					
						
						if(planHtml!=null)
							planHtml = planHtml.replaceAll("\\d,\\d{3} square feet of living space", "");
						
						String[] sqft = U
								.getSqareFeet(
										html+comData+planHtml+moveInData,
										"\\d,\\d{3} SF to \\d,\\d{3} SF| \\d,\\d{3}</li>|\\d,\\d{3} square feet |\\d+,\\d+ sq. ft|left\">\\d{4}</td>|<span>\\d{1},\\d{3} - \\d{1},\\d{3}</span>|<span>\\d,\\d{3}</span>",
										0);
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						U.log("SQ.FT--->"+minSqft+" "+maxSqft);
						
				//================================================community type========================================================
						
						String communityType=U.getCommType(html+comData);
						
				//==========================================================Property Type================================================
						html = html.replaceAll("Craftsman Exterior\\.jpg|at-dean-ranch|Dean Ranch", "");
						comData = comData.replaceAll("Craftsman Exterior\\.jpg", "");
//						U.log(comData);
						String proptype=U.getPropType((html+comData+planHtml).replaceAll("20Craftsman\\.jpg|craftsman-style elevation|craftsman elevation|no HOA restrictions",""));
						
				//==================================================D-Property Type======================================================
						planHtml = planHtml.replaceAll("split floorplan|split floor plan", "split-level floorplan ");
						String dtype=U.getdCommType((html+comData+planHtml).replaceAll("at-dean-ranch|Dean Ranch", ""));
						
						
						
						add[0]=add[0].replace(",", "");
						

						
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
	
						
							data.addCommunity(communityName.replace("Sun 'n Lake", "Sun 'N Lake"),comUrl, communityType);
							data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(proptype, dtype);
							data.addPropertyStatus(pstatus);
							data.addNotes(note);
							data.addUnitCount(units);
							data.addConstructionInformation(startDt, endDt);
		}
							j++;
	}
	
	public static String getUnits(String html, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String mapUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("<a href=\"http://southern.salessimplicity.net") ||
				html.contains("<a href=\"https://southern.salessimplicity.net")) {
			
				
			if(html.contains("<a href=\"https://southern.salessimplicity.net")) {
				mapUrl = U.getSectionValue(html, "<a href=\"https://southern.salessimplicity.net", "\"").replace("&amp;", "&");
				mapUrl = "https://southern.salessimplicity.net" + mapUrl ;
			} 
			else {
				mapUrl = U.getSectionValue(html, "<a href=\"http://southern.salessimplicity.net", "\"").replace("&amp;", "&");
				mapUrl = "http://southern.salessimplicity.net" + mapUrl ;
			}		
				
				U.log("mapUrl: "+mapUrl);
				
				if(mapUrl != null) {
					
					mapData = U.getHtml(mapUrl, driver);
					
					if(mapData.contains("<img id=\"topoImgLot")) {
						
						ArrayList<String> stars = Util.matchAll(mapData, "<img id=\"topoImgLot", 0);
						U.log("Count stars: "+stars.size());
						totalUnits = String.valueOf(stars.size());
					}
				}
		}
			
		return totalUnits;
	}

}

	



