/*sampada santosh*/
package com.shatam.b_241_260;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSunRiverStGeorgeDevelopmentLC extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://sunriver.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractSunRiverStGeorgeDevelopmentLC();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"SunRiver Communities.csv",
				a.data().printAll());

	}

	public ExtractSunRiverStGeorgeDevelopmentLC() throws Exception {

		super("SunRiver Communities", "https://www.sunriver.com");
		LOGGER = new CommunityLogger("SunRiver Communities");
	}
	WebDriver driver = null;
	public void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String basehtml = U.getHTML("https://sunriver.com");
		
		HashMap<String, String> homesMap = new HashMap<>();
		String homeHtml = U.getHTML("https://www.sunriver.com/find-a-home");
//		String[] homesSection = U.getValues(U.getSectionValue(homeHtml,"ind the community that fits<strong>","</section>"),"<div class=\"sqs-block html-block sqs-block-html\" data-block-type=\"","<div class=\"sqs-block image-block sqs-block-image");
//		U.log("MMMMM :"+homesSection.length);
//		for(String homeSec : homesSection){
////			U.log(homeSec);
//			String homeUrlSec = U.getSectionValue(homeSec, "href=\"/","\"");
//			U.log(homeUrlSec);
//			homeUrlSec=BASEURL+homeUrlSec;
//			findDetail(homeUrlSec,homeSec);
//			String homeUrlSec = U.getSectionValue(homeSec, "Explore Community", "class=\"sqs-block-button-element--large sqs-button-element--secondary sqs-block-button-element");
//			U.log(homeUrlSec);
			
//		}
		String[] homesSection = U.getValues(U.getSectionValue(homeHtml, "Find the community that fits", "</section>"), "<div class=\"sqs-block html-block sqs-block-html\" data-block-type=", "<div class=\"sqs-block image-block sqs-block-image");
		U.log(homesSection.length);
		for(String homeSec : homesSection){
//			U.log(homeSec);
//			String homeUrlSec = U.getSectionValue(homeSec, "Explore Community</a>", "");
			String homeUrlSec = U.getSectionValue(homeSec, "data-button-type=\"tertiary\"", "tertiary sqs-block-button-element\"");
			String comName = U.getSectionValue(homeSec, "href=\"", "\"");
			U.log("%%%%%%%%"+comName);
			homesMap.put(comName, homeSec);
			if(homeSec.contains("sunriver-firelight")) {
//				try { 
					findDetails("sunriver-firelight","/sunriver-firelight",homeSec); 
//					} catch (Exception e) {}
			}
			
		}
		U.log("Total Home : "+homesMap.size());
		
		
		String sec = U.getSectionValue(basehtml, "<strong>Communities</strong", "</div></div></div><div class=\"col sqs-col-3");
//		U.log("*******"+sec);
		String comSections [] = U.getValues(sec, "<p class=\"\" style=\"white-space:pre-wrap;\">", "a></p>");
		U.log(comSections.length);
		
		for(String comSec : comSections){
//			U.log(">>>>>>>>>"+comSec);
			
			String comName  = U.getSectionValue(comSec, ">", "</");//.replaceAll("Villas", "");
//			U.log(comName);
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
//			U.log("--------"+comUrl);
			
			String extractHomesData = homesMap.get(comUrl);
//			U.log("+++++++++"+extractHomesData);
			if(comName.contains("SunRiver") && !comUrl.contains("http"))comUrl = "https://www.sunriver.com"+comUrl;
//			try { 
			addDetails(comName,comUrl,extractHomesData, driver); 
//			} catch (Exception e) {}
			
			//break;
		}
		
		
		
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}

	}
	private void findDetails(String comName, String comUrl, String homeUrlSec) throws Exception{
		comUrl=BASEURL+comUrl;
		U.log("%%%%%"+comUrl);
		String html = U.getHTML(comUrl);
		LOGGER.AddCommunityUrl(comUrl);
//		U.log("******"+homeUrlSec);
		//======ADDRSS & LAT-LNG=====
		String[]ad ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] ltlg = {ALLOW_BLANK,ALLOW_BLANK};
		String geocode = "TRUE",note =ALLOW_BLANK;
		if(html != null) {
			ad[0]=ALLOW_BLANK;
			ad[1]="Cedar";
			ad[2]="UT";
			ad[3]=ALLOW_BLANK;
			ltlg =U.getlatlongGoogleApi(ad);
			ad=U.getAddressGoogleApi(ltlg);
			U.log(Arrays.toString(ad));
			U.log(Arrays.toString(ltlg));
			note="Address taken from City and State";
		}
		//====prices=====
		String[] price = U.getPrices(homeUrlSec+html, "\\$\\d{3},\\d{3}", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		//====square ft====
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(homeUrlSec+html, "\\d{4} sqft", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("square feet==" + sqft[0] + ":::" + sqft[1]);
		// ---------community type,property type,property status,derived,property type---------//
		String commType = U.getCommunityType(homeUrlSec+html);
		String propType = U.getPropType(homeUrlSec+html);
		String dpType = U.getdCommType(homeUrlSec+html);
		String commStatus = U.getPropStatus(homeUrlSec+html);   //+extractHomesData 
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(comName, comUrl, commType);
		data.addAddress(ad[0], ad[1], ad[2].trim(), ad[3]);
		data.addLatitudeLongitude(ltlg[0].trim(), ltlg[1].trim(), geocode);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(note);
	}
	
	private void addDetails(String comName, String comUrl, String extractHomesData, WebDriver driver) throws Exception {
		//TODO:
//		if(!comUrl.contains("https://www.bloomingtonvillas.com"))return;
//	if(!comUrl.contains("https://www.sunriver.com/st-george"))return;
		
		U.log(":::::::::::"+comUrl+":::::::::::::::"+U.getCache(comUrl));
		
		if(data.communityUrlExists(comUrl)) {
			
			LOGGER.AddCommunityUrl(comUrl+"=============Repeated=================");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(extractHomesData);
		String florUrl = "";
		String floorPlanHtml = "";
		String allFlrPlanData = "";
		if(comUrl.contains("sunriver")&&!comUrl.contains("https://www.sunriver.com/st-george")){           //==
//			florUrl = "https://www.sunriver.com"+ Util.match(extractHomesData, "<a href=\"(.*?)\" class=\"sqs-block-button-element--large ",1);
			florUrl = comUrl+"/floor-plans";
			U.log("iF florUrl : "+florUrl);
			floorPlanHtml = U.getHTML(florUrl);
			for(String fUrl :  U.getValues(floorPlanHtml, " class=\"sqs-block-button-container--center\"", "See More Details")){
				U.log(fUrl);
	
				String tempHtml = U.getHTML("https://www.sunriver.com"+U.getSectionValue(fUrl,"href=\"","\""));
				allFlrPlanData += U.getSectionValue(tempHtml, "Back to all floor plans", "</section>");
				
			}
			
		}
		else{
			if(extractHomesData!=null) {
			florUrl = U.getSectionValue(extractHomesData, "href=\"", "\"");//Util.match(extractHomesData, "<a href=\"(.*?)\" class=\"sqs-block-button-element--small sqs-block-button-element\" target=\"_blank\">\\s*$",1);
			if(!florUrl.contains("https"))florUrl="https://www.sunriver.com"+florUrl;
			U.log("Else florUrl : "+florUrl);
			if(comUrl.contains("https://www.hamblinestates.com")){
				florUrl = florUrl.replace("/homes/", "/homes-for-sale");
				floorPlanHtml = U.getHtml(florUrl, driver);
			}
			
			else {
				floorPlanHtml = U.getHTML(florUrl);
				if(comUrl.contains("https://www.sunriver.com/st-george"))floorPlanHtml = U.getHtml(florUrl,driver);
			}
			}
		}
		
		if(comUrl.contains("bloomingtonvillas")) {
			florUrl = comUrl+"/ownership";
			floorPlanHtml = U.getHTML(florUrl);

		}	
		
		U.log(">>>>>>>>>>>>>>>>>>>> "+comUrl+"\t"+U.getCache(comUrl));
		
		String comHtml = U.getHTML(comUrl);//withProxy
		
		String homesHtml = ALLOW_BLANK,amenitiesHtml=ALLOW_BLANK,lifeStyleHtml = ALLOW_BLANK;
		String navbarSections = U.getSectionValue(comHtml, "<div class=\"Mobile-overlay\">", "<button class=\"Mobile-overlay-close");
		String navUrls [] = U.getValues(navbarSections, "<a href=\"", "\"");
		for(String navUrl : navUrls){
			U.log("navUrl ::"+navUrl);
			if(navUrl.contains("/homes"))
				if(comUrl+navUrl == "https://www.sunriver.com/villas/homes")
					continue;
				else
					homesHtml=U.getHtml(comUrl+navUrl,driver);
			U.log("navUrl ::"+navUrl);
			if(navUrl.contains("lifestyle"))lifeStyleHtml=U.getHTML(comUrl+navUrl);
			if(navUrl.contains("amenities"))amenitiesHtml=U.getHTML(comUrl+navUrl);
		}
		String[]add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE",note =ALLOW_BLANK;
		if(comUrl.contains("sunriver")){
			add = new String[] {"4782 S Wallace Dr","St. George", "UT", "84790"};
//			latLng = U.getlatlongGoogleApi(add);
			latLng = new String[] {"37.026365","-113.609799"};
			geo= "TRUE";
			note ="Address & LatLong Taken From Contact";
					
		}
		if(comUrl.contains("hamblinestates")){
			add = new String[] {"3174 S Bloomington Dr E","St. George", "UT", "84790"};
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo= "TRUE";	
		}
		if(comUrl.contains("bloomingtonvillas")){
			add = new String[] {"3080 S Bloomington Dr. E","St. George", "UT", "84790"};
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo= "TRUE";	
		}
		// ---------community type,property type,property status,derived,property type---------//
		comHtml=comHtml.replaceAll("SunRiver Villas|Villas<|Bloomington Villas|/villas|bloomingtonvillas.com\"|Discovery Villa", "")
				.replaceAll("tagline\">Resort Style|siteTagLine\":\"Resort", "");

		String commType = U.getCommunityType(comHtml);
		String propType = U.getPropType(comHtml+ allFlrPlanData +floorPlanHtml+amenitiesHtml+extractHomesData);
		String dpType = U.getdCommType(comHtml);
		String commStatus = U.getPropStatus(comHtml.replaceAll("Golf Course Homes Now Available", ""));   //+extractHomesData 
//		U.log(Util.matchAll(comHtml , "[\\w\\s\\W]{30}coming Soon[\\w\\s\\W]{30}", 0));
		comHtml = comHtml.replaceAll("0’S", "0,000").replace("alt=\"$499,900\" ", "").replace("<p><strong>$499,900</strong></p>", "");
		allFlrPlanData=allFlrPlanData.replaceAll("alt=\"\\$340,900\"", "").replace("alt=\"$334,900\"", "");
		
//		U.log(Util.matchAll(allFlrPlanData , "[\\w\\s\\W]{30}779[\\w\\s\\W]{30}", 0));

		String[] price = U.getPrices(comHtml+extractHomesData+floorPlanHtml+allFlrPlanData, "\\$\\d{3},\\d+|<strong>\\$\\d{3},\\d{3}</strong>|\\$\\d{3},\\d{3}</p><p|\">\\$\\d{3},\\d{3}</td>", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
//		U.log("<<<<<<<<<<<<<<<"+Util.matchAll(comHtml+extractHomesData+floorPlanHtml+allFlrPlanData , "[\\w\\s\\W]{30}[\\w\\s\\W]{30}", 0));
		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		comHtml = comHtml.replaceAll("\\d+ sq. ft. clubhouse", "");
		String[] sqft = U.getSqareFeet(comHtml+extractHomesData+floorPlanHtml+allFlrPlanData, " \\d,\\d+ sq.ft|\\d{4} Sq. Ft.|\\d{4} sqft|Total SqFt:</strong>(&nbsp;)?\\d,\\d+", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("MINSQF: "+minSqf+" MAXSQF: "+maxSqf);
//		if(comUrl.contains("https://www.hamblinestates.com")){
//			// values taken from img present at Homes  
//			minSqf = "1890";
//			minPrice = "$349,900";
//		}
		if(comName.contains("Estates") && !propType.contains("Estate")) {
			if(propType.length()<2)propType="Estate-Style Homes";
			else propType=propType+", Estate-Style Homes";
		}
		if(comUrl.contains("https://www.sunriver.com/st-george")) {
//			minSqf = "1,850";
//			minPrice = "$530,972";
//			maxPrice="$779,500";
//			maxSqf="4,222";
		}
		if(comUrl.contains("https://www.hamblinestates.com")){
			commStatus=ALLOW_BLANK;
			//from homes images
			minSqf = "2,552";
			maxSqf = "3,325";
			minPrice = "$499,900";
			maxPrice = "$699,900";
			//commStatus ="Sold Out";
		}
		if(comUrl.contains("https://www.bloomingtonvillas.com"))commStatus="New Phases Coming Soon";
		if(comUrl.contains("https://www.sunriver.com/villas"))comName="SunRiver Villas";
//		if(comUrl.contains("https://www.sunriver.com/st-george") ||comUrl.contains("https://www.sunriver.com/villas") )
//			commType = commType+", 55+ Community"; //From Regionn Img
		
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(comName, comUrl, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(note);
	}

	

}