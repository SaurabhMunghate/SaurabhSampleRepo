/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPacificCommunitiesBuilder extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;

	public ExtractPacificCommunitiesBuilder() throws Exception {
		super("Pacific Communities Builder", "https://pacificcommunities.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Pacific Communities Builder");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractPacificCommunitiesBuilder();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Pacific Communities Builder.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver=new ChromeDriver();
		String mainHtml = U.getHTML("https://pacificcommunities.com/find-a-home/");
		String paginationSection = U.getSectionValue(mainHtml, "collection-pagination\">", "</div>");
		if (paginationSection != null) {
			String pagingUrls[] = U.getValues(paginationSection, "\" href=\"", "\">");
			List<String> list = new ArrayList<>();

			for (String pagingUrl : pagingUrls) {
				if (!list.contains(pagingUrl))
					list.add(pagingUrl);
				else
					continue;
				U.log(pagingUrl);
				mainHtml = mainHtml + U.getHTML(pagingUrl);
			}
		}
//		mainHtml=mainHtml+U.getHTML("https://pacificcommunities.com/find-a-home/page/2/");
//		mainHtml=mainHtml+U.getHTML("https://p	acificcommunities.com/property-category/coming-soon/");
		String[] comSec = U.getValues(mainHtml, "<div class=\"community-preview\">", "</script>"); 
				//"<h2 class=\"community__name\">", "</script>");
		for (String comData : comSec) {
			// U.log(comData);
			if (!comData.contains("<a href=\""))
				continue;

			String comUrl = U.getSectionValue(comData, "<a href=\"", "\"");

//			U.log("comUrl::"+comUrl);
//			try {
				addDetails(comUrl, comData);
//			} catch (Exception e) {}
		}
		U.log(comSec.length);
		driver.quit();
		LOGGER.DisposeLogger();
	}

	// TODO :
	private void addDetails(String comUrl, String comData) throws Exception {
//		if(!comUrl.contains("https://pacificcommunities.com/communities/pacific-del-lago/")) return;
	//try{
		{
			U.log("count"+j);
//			U.log("comData:::" + comData);
			U.log(j + "   commUrl-->" + comUrl);

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "<==========Repeated");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			String html = U.getHTML(comUrl);
			

			

			String nowSellHtml = U.getHTML("https://pacificcommunities.com/property-category/now-selling/")
					+ U.getHTML("https://pacificcommunities.com/property-category/now-selling/page/2/");
			String[] nowSellSec = U.getValues(nowSellHtml, "<h2 class=\"community__name\">", "</h2>");

			String lastChanHtml = U.getHTML("https://pacificcommunities.com/property-category/last-chance/");
			String[] lastChanSec = U.getValues(lastChanHtml, "<h2 class=\"community__name\">", "</h2>");

			String comSoonHtml = U.getHTML("https://pacificcommunities.com/property-category/coming-soon/");
			String[] comSoonSec = U.getValues(comSoonHtml, "<h2 class=\"community__name\">", "</h2>");

			String feature = U.getHTML(comUrl + "features/");

//============================================Community name=======================================================================
			String communityName = U.getSectionValue(comData, "<h2 class=\"community__name\">", "</a>");
			if(communityName != null) communityName = communityName.replaceAll("<.*?>", "").trim();
					//U.getSectionValue(comData, "\">", "<");

			U.log("community Name---->" + communityName);
//============================================note====================================================================
			String note = "";
			// if(comUrl.contains("https://pacificcommunities.com/communities/pacific-bougainvillea/"))note="Now Leasing";
			// Opening";

			note = U.getnote(html+comData);

//================================================Address section===================================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(comData, "address: \"", "\"").replace("Sales Office<br />", "");
			U.log("addSec: "+addSec);
			
			if(addSec != null && addSec.contains("Edgewater Road & East Barrel Springs Road, Palmdale CA 93550, USA")) {
				addSec = "East Barrel Springs Road, Palmdale, CA 93550, USA";
				U.log("addSec from here: "+addSec);
			}

			if (addSec != null) {

				String[] tempAdd = addSec.split(",");
				if (tempAdd.length >= 3) {
					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2], "\\w+");
					add[3] = Util.match(tempAdd[2], "\\d+");
				}
				if (tempAdd.length == 2) {
					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
				}
				if (add[3] == null)
					add[3] = ALLOW_BLANK;

				if (add[1] != null)
					add[1] = U.getCapitalise(add[1].toLowerCase());
			}

			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);

//--------------------------------------------------latlng----------------------------------------------------------------
			latlag[0] = U.getSectionValue(comData, "lat: '", "'");
			latlag[1] = U.getSectionValue(comData, "lng: '", "'");

			U.log("hhhh--->" + latlag[0] + "  " + latlag[1]);

			if (add[1] != ALLOW_BLANK && latlag[0] == ALLOW_BLANK) {
				latlag = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			// --------------fetch add from latlng----------------
			if ((add[3].length() < 5) && latlag[0] != ALLOW_BLANK) {
				String[] tempAdd = U.getAddressGoogleApi(latlag);
				if (tempAdd == null)
					tempAdd = U.getAddressHereApi(latlag);
				add = tempAdd;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latlag[0] + "  " + latlag[1]);

//============================================Price and SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			comData = comData.replace("400000s<br />", "400,000<br />");
			html = html.replace(" $500'000's", " $500,000")
					.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k", "0,000").replace("$1 million", "$1,000,000");
			comData = comData.replaceAll("0&#8217;s|0�s|0's", "0,000");
			
			String prices[] = U.getPrices(html + comData, "Price: From the \\$\\d{6}|Price: From the \\$\\d{3}'\\d{3}|From the low $1,000,000|\\$\\d{3},\\d+| <p>\\$\\d+,\\d+</p>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

//======================================================Sq.ft===========================================================================================		
			String[] sqft = U.getSqareFeet(html + comData,
					"Square Footage: \\d,\\d{3}-\\d,\\d{3} SF|\\d{1},\\d+-\\d{1},\\d+ Square Feet</li>|\\d{1},\\d+ to \\d{1},\\d+ Square Feet|<p>\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft\\.|\\d{1},\\d+ t- \\d{1},\\d+ sq. ft.|\\d,\\d{3}-\\d,\\d{3} SQ\\. FT|\\d{1},\\d+ - \\d{1},\\d+ SF|\\d{1},\\d+ Square Feet",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			if(comUrl.contains("https://pacificcommunities.com/communities/pacific-jasper/"))
				maxSqft="2466";
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//=========fetch about community url data===========
			String aboutHtml = ALLOW_BLANK;
			if (html.contains(">Community</a>")) {
				aboutHtml = U.getHTML(comUrl + "community/");
			}
//================================================community type========================================================
			// html=html.replace("Pacific Mayfield (55+", "Pacific Mayfield (55+
			// community");
			html = html.replace("Discover adult living", "Discover active adult living");

			html = html.replace("55+ community)' href='", "");
			if (aboutHtml != null)
				aboutHtml = aboutHtml.replaceAll(
						"Elongated Toilets|Lakes? Country |Golf enthusiasts|Hills Golf|golfing since you were|City golf|golf at Menifee|& Golf Course,",
						"");
			String communityType = U.getCommType(html + comData + aboutHtml);
			
//==========================================================Property Type================================================
			html = html.replaceAll(
					"California that make luxury living affordable|that make luxury living affordable|NO HOA |No HOA|>NO HOA<",
					"").replaceAll("Super Loft|LOFT - ", " loft homes ")
					.replace("estate community", "estate homes community");
			// U.log(html);
			feature = feature.replaceAll("luxury living affordable|Real Estate|Farmhouse Sinks|Farmhouse Kitchen Sink", "").replaceAll(
					"Spanish, Craftsman, and Tuscan Architecture|Spanish, Craftsman &amp; Tuscan Architecture",
					"Craftsman style details");
			
			if(comUrl.contains("https://pacificcommunities.com/communities/pacificlegacy/")) html = html +"Pacific Legacy - New Single-Family Homes in Perris, CA"; //Yutube link
			//U.log("com"+html);
		//	U.log("MMMMMMMMMMMMMMMM " + Util.matchAll(html + comData, "[\\w\\s\\W]{50}Crafts[\\w\\s\\W]{50}", 0));
		
		//	U.log("MMMMMMMMMMMMMMMM " + Util.match(html + comData, "Craft"));
			String proptype = U.getPropType((html + comData.replace("Gated Luxury Estate Homes", "") + feature).replaceAll("-Patio|_Patio_", ""));
			U.log("proptype=="+proptype);
			

//==================================================D-Property Type======================================================
			html = html.replace("Stories <span class=\"value\">", "Story ").replaceAll("1 &amp; 2-Story Homes|1 &amp; 2-story homes ",
					"1 story,2-story homes ");

			String dtype = U.getdCommType((html + comData + feature ).replaceAll("Rancho|rancho", ""));

//==============================================Property Status=========================================================
			String titleContent = U.getSectionValue(html, "</title>", "<body");
			String communityFooter = U.getSectionValue(html, "nearby-communities\">", "</div>");
			if (titleContent != null)
				html = html.replace(titleContent, "");
			if (communityFooter != null)
				html = html.replace(communityFooter, "");

			html = html.replaceAll(
					"Now selling the model homes|Price: Coming Soon|copy\">Now Selling</span>|Pre-Grand Opening|our coming soon|alt=\"Cost\"></p>\\s*<p>\\s*Coming Soon\\s*</p>",
					"").replaceAll(
							"Plan \\d \\(Sold|Plan \\d - SOLD|Plan \\d[A-Z]?\\s{1,}\\(SOLD|-sold-out|content=\"Only \\d homes|\\(\\d Homes Remain\\)|Preview Grand",
							"");
			comData = comData.replaceAll("FinalOpp.jpg|FinalOpportunity", "Final Opportunity")
					.replaceAll("Price: Coming Soon", "");

//		String lastChanceProperty = U.getHTML("https://pacificcommunities.com/property-category/last-chance/");
//		String [] communityLastChance = U.getValues(lastChanceProperty, "<div class=\"community-description\">", "</h2>");
//		for(String val : communityLastChance){
//			if(val.contains(comUrl)){
//				html = html +" Last Chance";
//			}
//		}
//		String nowSellingProperty = U.getHTML("https://pacificcommunities.com/property-category/now-selling/");
//		String [] communityNowSelling = U.getValues(nowSellingProperty, "<div class=\"community-description\">", "</h2>");
//		for(String val : communityNowSelling){
//			if(val.contains(comUrl)){
//				html = html +" Now Selling";
//			}
//		}

			comData = comData.replaceAll("OpportunityEagle-1\\.jpg", "").replace("SoldOut_", "Sold Out_");
			html = html.replaceAll("\\(?SOLD OUT\\)?</h3>|Model Preview Coming Early", "")
					.replace("Coming Soon in 2022", "Coming Soon 2022").replace("open in the spring of 2021",
					"open in spring of 2021");

//		U.log(html);
			
			
//			
//			U.log("stat matching"+Util.match(html,"Grand Opening"));
//			U.log("stst matching"+Util.match(comData,"Grand Opening"));
			String pstatus = U.getPropStatus((comData+html ).replaceAll("opening Spring 2022", "Coming Spring 2022")
					.replace("jpg\" alt=\"Coming soon Pacific Palacio", "")
					.replaceAll("MODEL HOMES JUST RELEASED|model opening Summer 2022|anticipated to open early 2022|ComingSoon-Pacific|<p>Coming Soon</p>|this is a sold out community</p>|Coming Soon to Perris|Preview Coming", ""));

//			U.log("MMMMMMMMMMMMMMMM " + Util.matchAll(html + comData, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));
			
			
//		U.log(comData);
//		U.log(Util.matchAll(html+comData,"[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
			// from images
//		if(comUrl.contains("/communities/pacific-melrose/"))pstatus="Sold Out, "+pstatus;
			// if(comUrl.contains("/communities/pacific-galleria/"))pstatus="Coming Soon,
			// Coming Fall 2019";
/*			if (comUrl.contains("/communities/pacific-avenue/"))
				pstatus = pstatus + ", Coming Early 2021"; // From Reg. pg. img
//*/			
			
			U.log("pstatus======"+pstatus);
			
			if (comUrl.contains("communities/pacificlegacy/"))
				pstatus = "Sold Out";

			if (!pstatus.contains("Coming Soon")) {

				
				for (String name : comSoonSec) {
					
				//	U.log(name);
					if (name.contains(communityName+"</a>")){
						if (pstatus.length() < 4)
							pstatus = "Coming Soon";
//						else
//							pstatus = pstatus + ", Coming Soon";
					}

				}
			}

			pstatus=pstatus.replace("Coming Soon, Coming Soon Spring 2022","Coming Soon Spring 2022");
			pstatus=pstatus.replace("Coming Soon, Coming Soon 2022, Final Opportunity", "Coming Soon 2022, Final Opportunity");
			pstatus=pstatus.replace("Coming Soon Spring 2022, Coming Soon","Coming Soon Spring 2022");
			pstatus=pstatus.replace("Coming 2022/2023, Coming Soon","Coming 2022/2023");
			pstatus=pstatus.replace("Coming Soon, Coming 2023", "Coming 2023");
			
			
			
			
			//			for(String now : nowSellSec) {
//				U.log("chkmng nw sell url"+now.contains("Pacific Mosaico"));
//				if(now.contains(communityName))
//					pstatus = getStatus(pstatus, "Now Selling");;
//			}
			
//			for(String last : lastChanSec) {
//				
//				if(last.contains(communityName))
//					pstatus = getStatus(pstatus, "Last Chance");;
//			}
			
//			for(String coming : comSoonSec) {
//				
//				if(coming.contains(communityName))
//					pstatus = getStatus(pstatus, "Coming Soon");;
//			}
			
//			if (comUrl.contains("/communities/pacific-wildflower/"))
//				pstatus = "Coming Early 2022"; // From Reg. pg. img
//			
			
			
	if(comUrl.contains("https://pacificcommunities.com/communities/pacific-galleria/"))minPrice="$1,000,000";
	//if(comUrl.contains("https://pacificcommunities.com/communities/pacific-marigold/"))pstatus+=", Last Chance";

			add[2] = add[2].replace(".", "");
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//siteMap=======
			
			String noOfUnits=ALLOW_BLANK;
			int lotCount=0;
			String lotCount2=ALLOW_BLANK;
			String siteMapSec=U.getSectionValue(html, "https://apps.alpha-vision.com", "Sitemap");
			if(siteMapSec!=null) {
				String siteMapUrlSec=U.getSectionValue(html, "https://apps.alpha-vision.com", "\">Sitemap");
					String siteMapUrl="https://apps.alpha-vision.com"+siteMapUrlSec;
					U.log("siteMapUrl= "+siteMapUrl);
			//		String sitemapHtml=U.getHtml(siteMapUrl,driver);
					U.log("path:: "+U.getCache(siteMapUrl));
				
					String olaId=Util.match(siteMapUrl, "OLAId=(.*)",1);
					U.log("Ola Id:: "+olaId);
					String siteUrl="https://apps.alpha-vision.com/olajson/"+olaId+".json?";
					String siteHtml=U.getHtml(siteUrl,driver);
					U.log("path2:: "+U.getCache(siteUrl));
					/*String siteHtmlJson=U.getSectionValue(siteHtml, "pre-wrap;\">", "</pre></body></html>");
					JsonParser parser=new JsonParser();
					JsonObject map=(JsonObject) parser.parse("siteHtmlJson");
					JsonArray lotgroup=map.get("LotGroups").getAsJsonArray();
					for(int i=0;i<lotgroup.size();i++) {
						lotCount2=lotgroup.get(i).getAsString();
						U.log("ggg"+lotCount2);
						
					}
					*/
//					String lotData1[]=U.getValues(sitemapHtml,"<div class=\"anchorshape round\"", "</div>");
//					lotCount=lotData1.length;
//					noOfUnits=Integer.toString(lotCount);
					lotCount2=U.getSectionValue(siteHtml, "\"LotCount\":", ",");
					U.log("lotCount2: "+lotCount2);
					
					if(lotCount2 == null)
						lotCount2=ALLOW_BLANK;
					
					noOfUnits=lotCount2;
			}
			
			if(noOfUnits.equals("0"))
              noOfUnits=ALLOW_BLANK;			
			
		U.log("Number of units"+noOfUnits);
			
			
			
			
			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].toLowerCase().trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
		}
		j++;
	//}catch(Exception e){}
	}

	private String getStatus(String pstatus, String status) {
		// TODO Auto-generated method stub
		
		if(pstatus==ALLOW_BLANK)
			pstatus = status;
		else
			pstatus += ", "+status;
		
		return pstatus;
	}

}