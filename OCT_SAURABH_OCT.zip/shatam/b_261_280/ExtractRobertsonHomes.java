/**
 * @author Priti
 * @date 02/07/2018
 * 
 */
package com.shatam.b_261_280;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRobertsonHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private String builderUrl = "https://www.robertsonhomes.com";
	public ExtractRobertsonHomes()
			throws Exception {
		super("Robertson Homes","https://www.robertsonhomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Robertson Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractRobertsonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Robertson Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}
	String mainHtml=ALLOW_BLANK;
	@Override
	protected void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		WebDriver driver = new FirefoxDriver();
		
		String comListPageHtml = U.getHTML("https://www.robertsonhomes.com/communities");
//		comListPageHtml = StringEscapeUtils.unescapeJava(comListPageHtml);
//		String floorListPagehtml = U.getHTML("http://www.robertsonhomes.com/API/models.json");
//		floorListPagehtml = StringEscapeUtils.unescapeJava(floorListPagehtml);
//		String quickListPagehtml = U.getHTML("http://www.robertsonhomes.com/API/homes.json");
//		quickListPagehtml = StringEscapeUtils.unescapeJava(quickListPagehtml);
//		U.log(comListPageHtml);
		String [] comSections = U.getValues(comListPageHtml, "<div class=\"CommunityCard_wrapper\"", "class=\"CommunityCard_pin\"");
//		String comSection=U.getSectionValue(comListPageHtml,"<script>window.__PRELOADED_STATE__ ","</html");
//		comListPageHtml=comListPageHtml.replace(comSection,"");
//		U.log(comListPageHtml);
		
		U.log("Total com : " +comSections.length);
		for(String com:comSections) {
//			U.log(com);
			String comurl=U.getSectionValue(com, "href=\"", "\"");
			if (!comurl.startsWith("https://www")) {
				comurl="https://www.robertsonhomes.com"+comurl;
			}
			String comHtml=U.getHTML(comurl);
			String rmhtml=U.getSectionValue(comHtml, "<script>window.__PRELOADED_STATE__ ", "</html");
			if(rmhtml==null)rmhtml = "";
			comHtml=comHtml.replace(rmhtml, "");
		//	U.log(comHtml);
			com=com.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->|data-reactid=\"\\d+\"", "");
		//	U.log("matching grand finale"+Util.match(com, "Grand Finale"));
//			try {
				addDetails(comurl,com,comHtml);
//			} catch (Exception e) {}
		}
		//driver.quit();
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comurl,String comSec,String comHtml) throws Exception {
		//TODO : For Single Community Execution
//		if(!comurl.contains("https://www.robertsonhomes.com/communities/hazel-park/park-54"))return;
//		if(j ==12)
		{
			
			if (data.communityUrlExists(comurl)){
				LOGGER.AddCommunityUrl(comurl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comurl);
			//Comnames
			String comName = U.getSectionValue(comSec, "<h4 class=\"CommunityCard_name d-flex flex-column\" >", "<");
			comName=comName.replaceAll("=.*>", "");
			U.log(j+"\t"+comurl+"\t"+comName);
			
			//Address & lat-longs
			String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String street=ALLOW_BLANK,city=ALLOW_BLANK,state=ALLOW_BLANK,zip=ALLOW_BLANK;
			String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
			String geo=ALLOW_BLANK;
			String addSec = U.getSectionValue(comHtml, "</script><script data-react-helmet=\"true\"", "</script>");
			if(addSec != null){
//				addSec = addSec.replace("+", ",").replace("Rd, A1", "Rd");
				U.log(addSec);
				 street=U.getSectionValue(addSec, "streetAddress\":\"", "\"");
				 city=U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
				 state=U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
				 zip=U.getSectionValue(addSec, "postalCode\":\"", "\"");
				 latLng[0] = U.getSectionValue(addSec, "\"latitude\":", ",");
				 latLng[1] = U.getSectionValue(addSec, "\"longitude\":", "}");
				 geo="False";
			}
//			sreet=street.replaceAll(city+"|"+state+"|"+zip+"|,", "");
			street = street.replaceAll("750 Forest|, Birmingham MI 48009", "");
			U.log("Street:"+street+" "+"City::"+" "+city+" "+"State::"+state+" "+"Zip::"+zip);
			U.log(Arrays.toString(latLng));

			if(comurl.contains("https://www.robertsonhomes.com/communities/birmingham/750-forest")) {
				
				add = U.getAddressHereApi(latLng);
				street = add[0];
				geo = "TRUE";
			}
			
			//-------fetch homePlan Data
			int countComHomes = 0 ;
			String allHomesData = ALLOW_BLANK;
			String [] homeSections = U.getValues(comHtml, "href=\"/plan/", "\"");
			U.log("Total Homes Plan : "+homeSections.length);
			for(String homeSec : homeSections){
				U.log("homeSec: "+homeSec);
					String homedata=U.getHTML("https://www.robertsonhomes.com/plan/"+homeSec);
//					String rmhtml=U.getSectionValue(homedata, "<body", "window.__PRELOADED_STATE_");
//					homedata=homedata.replace(rmhtml, "");
					allHomesData += U.getSectionValue(homedata, "<body", "You Might Like</h3>")+U.getSectionValue(homedata, " name=\"description\"", "\"/>")
					+U.getSectionValue(homedata, "<h3 class=\"Plan_about\"", "</div>");
//					U.log(allHomesData.contains("__STATE_"));
//					U.log(Util.matchAll(allHomesData,"[\\w\\s\\W]{30}\\$2[\\w\\s\\W]{30}",0));

//					countComHomes++;	
			}
//			allHomesData = allHomesData.replaceAll("_stories\":", "_stories ");
			
//			//-------fetch floorPlan Data
			String [] quickSections = U.getValues(comHtml, "href=\"/homes/", "\"");
			U.log("Total QuiCk Plan : "+quickSections.length);
			for(String quickSec : quickSections){
				U.log("quickSec: "+quickSec);
					String quickdata=U.getHTML("https://www.robertsonhomes.com/homes/"+quickSec);
					quickdata=U.getSectionValue(quickdata, "<body", "Photos</h3>")+U.getSectionValue(quickdata, "name=\"description\"", "\"")+U.getSectionValue(quickdata, "<p class=\"HomeDesc_p\"", "</p"); //"You Might Like</h3>");
					allHomesData += quickdata;
					countComHomes++;	
			}
			U.log(countComHomes);

//			int countComFloor = 0 ;
			String allFlrData = ALLOW_BLANK;
//			
			//Price
			comSec = comSec.replaceAll("00s|00’s", "00,000");
			comHtml = comHtml.replace("$1 Million+", "$1,000,000").replaceAll("00k|00ks|00k's|00's|00s|00’s", "00,000").replace("from the $500s", "from the $500,000").replace("upper $300's", "upper $300,000").replace("\\n$249,064 Purchase price\\n<helmet-script/>99,251 Loan Amount\\n$49,813 down payment", "");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			String [] prices = U.getPrices((comSec+comHtml).replaceAll("Estimated Loan Amount</div><div data-reactid=\"\\d+\">\\$\\d+,\\d+|Down Payment<!-- /react-text --></div><div data-reactid=\"\\d+\">\\$\\d+,\\d+", ""), " from the \\$\\d{3},\\d{3}| upper \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|mid \\$\\d{3}\\d{3}|from the \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",0);//"mod_basePrice\":\\d{6,7}|com_priceLow\":\\d{6,7}|com_priceHigh\":\\d{6,7}|inv_price\":\\d{6,7}|Price \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}", 0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
//			U.log("Match=="+Util.matchAll(comSec+comHtml,"[\\w\\s\\W]{30}\\$500[\\w\\s\\W]{30}",0));
			U.log("prices==> "+minPrice +"\t"+ maxPrice);
			
			//sqft
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		   
			String [] sqft = U.getSqareFeet((comSec+allFlrData+comHtml+allHomesData).replaceAll("1,928</span>|1,834 square feet of living space|1,834</span>|Over 1,800 sqft of true one level|1,800 sqft of modern living", ""), "\\d,\\d{3}-\\d,\\d{3}</b> SQ FT|Square footage averages \\d,\\d{3}|\\d,\\d{3} to \\d,\\d{3} square feet|com_sqftLow\":\\d{4}|com_sqftHigh\":\\d{4}|inv_sqft\":\\d{4}|>\\d,\\d{3}-\\d,\\d{3}<|>\\d,\\d{3}<|Over \\d,\\d{3} sqft|\\d,\\d{3} sqft", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		//	 U.log(Util.matchAll((comSec+allFlrData+comHtml+allHomesData),"[\\w\\W\\s]{50}1,928[\\w\\W\\s]{50}", 0));
			
//			U.log(Util.matchAll(allHomesData,"[\\w\\s\\W]{30}1,800[\\w\\s\\W]{30}",0));
			U.log("sqft==> "+minSqft +"\t"+ maxSqft);
//			
			//==== Remove Blog ============
			String rem = U.getSectionValue(comHtml, "<div class=\"Blogpost", "</style");
			if(rem != null) comHtml = comHtml.replace(rem, "");
//			//comType
			String comType = U.getCommType(comSec);
			U.log("comType : "+comType);
			
//			//propType
			
			comSec = comSec.replaceAll("com_condo\":0|com_condo\":1,|com_series\":\"Townhome", "");
			comHtml=comHtml.replaceAll("entire process of building our condo|chic-condos-near|developing the finest communities of condos|chic condos near|condos and single-family homes in Southeast Michigan.\"|crafted|we have been awarded for developing the finest communities of condos and single-family homes in Southeast Michigan.|The Garden Villas at Cherry Hill", "");
			comHtml=comHtml.replace("This luxury, contemporary community ","Luxury Homes");
			String garbage = U.getSectionValue(comHtml, "window.__PRELOADED_STATE__", "</html>");
			if(garbage==null)
				garbage = "";
			
			String propType = U.getPropType(comSec+comHtml+allHomesData);
			U.log("propType : "+propType);
//		
//					
//			U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(comSec+comHtml+allHomesData,"[\\w\\s\\W]{30}courty[\\w\\s\\W]{30}",0));

			if(propType.contains("Townhouse") && propType.contains("Townhome")){
				propType = propType.replaceAll("Townhouse,|Townhouse", "").replace(", ,", ",").trim()
						.replaceAll("^,|,$", "").trim();
			}
			//dType
			comHtml = comHtml.replaceAll("rooftop terrace on the 4th level", "");
			U.log(allHomesData.contains("custom"));
			if(allHomesData!=null) {
				allHomesData=allHomesData.replace("<!-- /react-text --><!-- react-text: 180 --> <!-- /react-text --><!-- react-text: 181 -->", " Stories ");
			}
			
			String dType = U.getdCommType(comSec+(allFlrData+allHomesData+comHtml).replaceAll("Floor|floor", ""));
			U.log("dType : "+dType);
//			//Multi-Family
//			//-----------
			comSec = comSec.replaceAll("Quick|quick|Center Now", "");
			comHtml = comHtml.replaceAll("Home Sites Available\"},|coming soon from Robert", "")
					.replace("Phase 3 Home Sites Now Available", "Phase 3 wooded home sites available");
			//-comHeadline
			String headLine = U.getSectionValue(comSec, "_marketingHeadline\":\"", "\"")+" === "+U.getSectionValue(comHtml, "class=\"CommunityHeadline mt-3\"", "</h3>");
			String caroselHeadline = U.getSectionValue(comHtml, "<h4 class=\"Carousel_headline", "</h4>");
			//pStatus
//			U.log(comSec);
			U.log(headLine);
			String descSec=U.getSectionValue(comHtml, "</script><script data-react-helmet=\"true\"", "</script>");;
			if(descSec == null) 
				descSec = "";
			
			descSec = descSec.replace("Final Home Sites have been released", "Final Home Sites released")
					.replace("Only 1 Penthouse Home Remains", "Only 1 Home Remains").replaceAll("New Townes Homes Now Available just 2 blocks from downtown Wixom", "");
						
			comSec=comSec.replaceAll("New Townes Homes Now Available just 2 blocks from downtown Wixom", "");
			
			comSec=comSec.toLowerCase().replaceAll("home now open|now open!\"|information and grand opening|Model Home Now Open|Center Now Open|coming soon from", "");

//			U.log("Matching srtat1"+Util.match(comSec, "Grand Finale"));
//			U.log("Matching srtat1"+Util.match(descSec, "Grand Finale"));
			String pStatus = U.getPropStatus(comSec
					+headLine.replaceAll("Grand Opening Incentive|Model Home Now Open|Center Now Open|information and grand opening|Quick Move In Homes Available|Grand Opening Information Coming Soon|coming soon from", "")
					+(caroselHeadline+descSec).replace("Only 1 Penthouse Home Remains- Immediate Occupancy", "Only 1 home Remains")
					.replaceAll("Immediate Move|Model Home Now Open|Now Available just 2 block|Center Now Open|information and grand opening|\">Coming Soon - New | our final 2 quick move-in homes!|homes ready now with all upgrades|Grand Opening soon from Robertson Homes|Quick Move-in Opportunity", ""));
			U.log("pStatus : "+pStatus);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\w\\s\\W]{30}finale[\\w\\s\\W]{30}", 0));
			
	//		if(comurl.contains("auburn-hills/riverside-townes"))pStatus = pStatus.replace("Coming Soon, Grand Opening Soon, Opening Soon", "Grand Opening Soon");
//			if(countComHomes != 0){
//				if (!pStatus.contains("Quick Move-")) {
//					if(pStatus.length()<4)pStatus = "Quick Move-In";
//					else pStatus = pStatus+", Quick Move-In";
//				}else {
//					pStatus=pStatus.replace("Move-in", "Move-In");
//				}
//			}
/*			else{
				if (!pStatus.contains("Quick Move-")) {
					if(pStatus.length()<4)pStatus = "No Quick Move-In Homes";
					else pStatus = pStatus+", No Quick Move-In Homes";
				}else {
					pStatus = pStatus.replace("Quick Move-In Homes", "No Quick Move-In Homes");
				}
			}

*/			

			pStatus = pStatus.replaceAll("Only 1 Home Sites Remain, 1 Home Site Remains", "Only 1 Home Sites Remain");
//			if(comurl.contains("https://www.robertsonhomes.com/communities/wixom/encore-townes-at-tribute"))pStatus = "New Townes Homes Now Available, "+pStatus;
			
			//comurl="https://www.robertsonhomes.com"+comurl;
			
			
				
					
//			if(comurl.contains("https://www.robertsonhomes.com/communities/detroit/scripps-district")){
//				if(pStatus==ALLOW_BLANK)
//					pStatus="Grand Finale";
//				else
//					pStatus=pStatus+", Grand Finale";
//				
//			}
										

							


if(comurl.contains("https://www.robertsonhomes.com/communities/ferndale/parkdale-townes")){
	if(pStatus==ALLOW_BLANK)
		pStatus="Grand Finale";
	else
		pStatus=pStatus+", Grand Finale";
	
}
					
//	
//	propType += ", Courtyard Home";
//}
//if(comurl.contains("https://www.robertsonhomes.com/communities/birmingham/750-forest"))
//	propType+=", Luxury Homes";
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;

			street=street.replace(", A1", "");
			data.addCommunity(comName,comurl, comType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(street.replace(",", "").trim(), city.trim(), state.trim(), zip.trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote((comSec+descSec).replaceAll("Town Homes now open for sale|New Town Homes for Sale|New Town Homes for sale in Royal Oak", "")));
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;
	}
	
	
	private String getHTML(String url, WebDriver driver) throws IOException, InterruptedException {
		String html = null;
		String Dname = null;
//		driver.navigate().to(url);
//		driver.manage().deleteAllCookies();
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{
			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					
					driver.manage().window().maximize();
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(5000);
					
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1000)", ""); 
					
					try{
						
					WebDriverWait wait = new WebDriverWait(driver, 20);
					
					while( driver.findElements(By.xpath("//*[@id=\"root\"]/div/div/div/div[5]/div[3]/span")).size() > 0) {
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[5]/div[3]/span"))));
						//Thread.sleep(2000);
						WebElement loadBtn = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[5]/div[3]/span"));//--------//load more button
						loadBtn.click();
						U.log(":::::::::::::CLick Success:::::::::::::::");
						Thread.sleep(5000);

						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,800)", "");
						}
					}
					catch(Exception e){
						U.log(":::::::::::::CLick UnSuccess:::::::::::::::"+e.getMessage());
					}
					
					Thread.sleep(8000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
}


