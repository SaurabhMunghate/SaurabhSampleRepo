/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSeagateHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static String builderUrl = "https://www.seagatehomes.com";
	public ExtractSeagateHomes() throws Exception {
		super("Seagate Homes","https://www.seagatehomes.com/");

		LOGGER=new CommunityLogger("Seagate Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		AbstractScrapper a=new ExtractSeagateHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Seagate Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	WebDriver driver=null;
	HashMap<String,String> mapData=new HashMap<>();
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		

		String mainHtml=U.getHTML("https://www.seagatehomes.com/where-we-build");
//		String[] mapSec=U.getValues(mainHtml,"{\"name", "icon\":");
//		for(String addLat:mapSec)
//		{
//			String nameKey=U.getSectionValue(addLat, ":\"","\"").replace("&amp;#39;","'").replace("\\","");
//			U.log(nameKey);
//			mapData.put(nameKey.toLowerCase().trim(),addLat);
//		}
		String[] comSec=U.getValues(mainHtml, "div class=\"HomeCard_wrapper\"","Learn More</a></div>");
		U.log("Total Community-->"+comSec.length);
		for(String comData:comSec)
		{
			String comUrl="https://www.seagatehomes.com"+U.getSectionValue(comData,"<a class=\"ViewHomeBtn\" href=\"","\"");
			if(U.getSectionValue(comData,"<a class=\"ViewHomeBtn\" href=\"","\"")== null )continue;//|| comUrl.contains("find-your-luxury-home")
			if(comUrl.contains("find-your-luxury-home")) {
				String Html=U.getHTML("https://www.seagatehomes.com/find-your-luxury-home");

				String[] comSec1=U.getValues(Html, "div class=\"HomeCard_wrapper\"","Learn More</a></div>");
				U.log("Total Community-->"+comSec1.length);
				for(String comData1:comSec1)
				{
					String comUrl1="https://www.seagatehomes.com"+U.getSectionValue(comData1,"href=\"","\"");
//					U.log(comUrl1);
					addDetails(comUrl1,comData1);
				}
			}
			else {
//			U.log(comUrl);
			addDetails(comUrl,comData);
			}
		}
		driver.quit();
		
		LOGGER.DisposeLogger();
	}
	
	int cnt = 0;
	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
		
//	try{
	{
//	if(!comUrl.contains("https://www.seagatehomes.com/find-your-home/matanzas-lakes/matanzas-lakes"))return;
//		if(comUrl.contains("https://www.seagatehomes.com/palm-coast-plantation")) return; //Url not open
		if(comUrl.equals("https://www.seagatehomes.com/where-we-build"))return;

		
		U.log("Count =="+cnt);
		U.log(j+"   commUrl-->"+comUrl);
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"--------------- Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHtml(comUrl ,driver);
		String html1 = html;
		String rmsec =U.getSectionValue(html, "><script>window.__PRELOADED_STATE__ =", "</html");
		if(rmsec==null)rmsec = "";
		html=html.replace(rmsec, "");
//============================================Community name=======================================================================
	U.log(comData);
	String communityName=U.getSectionValue(html, "<h1 data-reactid","<");
	if(communityName!=null)communityName = communityName.replaceAll("=\"\\d+\">", "");
	U.log("community Name---->"+communityName);
	
//================================================Address section===================================================================
	
//	String addSec=mapData.get(communityName.toLowerCase().trim());
	String note=ALLOW_BLANK;
	String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
	String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
	String geo="FALSE";

	
	
//--------------------------------------------------latlng----------------------------------------------------------------
//	U.log(addSec);
	
	if(comData!=null)
	{
		latlag[0]=Util.match(comData,"\\d{2,3}[.]{1}\\d+");
		latlag[1]=Util.match(comData,"-\\d{2,3}[.]{1}\\d+");
	}
	
	U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
	
	U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
	String addSec= U.getSectionValue(html, "<p class=\"DetailHeader_address\"", "</p></div>");
	if(addSec!=null) {
		addSec = addSec.replaceAll("<!-- /react-text --><!-- react-text: \\d+ --> <!-- /react-text --><!-- react-text: \\d+ -->", ",").replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replaceAll(" data-reactid=\"\\d+\">", "").replace(" | ", ",");
		U.log(addSec);
		add = addSec.split(",");
	}
//	String addd=U.getSectionValue(addSec, "address\":\"","\"");
//	U.log(addd);
//	if(addd!=null) {
//		addd=addd.replace("Palm Coast",",Palm Coast,");
//		add=U.getAddress(addd);
//		U.log(Arrays.toString(add));
//		add[0]=add[0].replace("Call for Appointment", "");
//	}
//	if(add[0] == ALLOW_BLANK) add[0] = U.getSectionValue(html, "sales_center_address\" class=\"ng-binding ng-scope\">", "</span>").replace("Call to set appointment", "");
//	if(add[0] == null) add[0] = ALLOW_BLANK;
//	if(add[3] == ALLOW_BLANK) add[3] = U.getSectionValue(html, "sales_center_zip\" class=\"ng-binding ng-scope\">", "</span>").trim();
//	if(add[3] == null) add[3] = ALLOW_BLANK;
//	if(add[0].length()<3) {
//		add=U.getAddressGoogleApi(latlag);
//		if(add == null) add = U.getAddressHereApi(latlag);
//		geo = "True";
//	}
	
//============================================Price and SQ.FT======================================================================
	String combinedFloorPlanHtml = ALLOW_BLANK;
	String combinedAvailHomesHtml = ALLOW_BLANK;

	String floorHtml=ALLOW_BLANK;//U.getHtml(comUrl+"-floorplans", driver);
	String description = ALLOW_BLANK;
	String availHtml=ALLOW_BLANK;//U.getHtml(comUrl+"-homes", driver);
	String loftType = null;
	for(String plan:U.getValues(html, "<div class=\"PlanCard_media", "View Plan</a></div>")) {
		String planurl = U.getSectionValue(plan, "<a class=\"CommunityPlans_viewPlan\" href=\"", "\"");
		U.log(">>>>>>>>>  https://www.seagatehomes.com"+planurl);
		
		if(planurl.contains("/st-andrews")) loftType = " loft and ";
		floorHtml = U.getHTML("https://www.seagatehomes.com"+planurl);
		
		if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/palm-coast-on-your-lot")) {
			description = U.getSectionValue(floorHtml, "\"description\":\"", "elevationPhotos");
			description=description.replaceAll("coastal|[p|P]atio|single family|luxury|Custom|Duplex|custom homes|Luxury Community|Luxury Home", "");
		}
//		if(floorHtml.contains("split plan")) {
//			U.log("Found");
//		}
		rmsec = U.getSectionValue(floorHtml, "<script>window.__PRELOADED_STATE__ =", "</html");
		
		
		combinedFloorPlanHtml +=floorHtml.replace(rmsec, "");//.replace(rmsec, "")
	}
	for(String home:U.getValues(html, "<div class=\"HomeCard_wrapper\"", "View Details</a></div>")) {
		String homeurl = U.getSectionValue(home, "<a class=\"ViewHomeBtn\" href=\"", "\"");
		availHtml = U.getHTML("https://www.seagatehomes.com"+homeurl);
		U.log("homeurl: "+homeurl);
		rmsec =U.getSectionValue(availHtml, "><script>window.__PRELOADED_STATE__ =", "</html");
		combinedAvailHomesHtml += availHtml.replace(rmsec, "");
	}
	String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
	String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	
	html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k|0'S|0’s","0,000").replace("$1 million","$1,000,000");
	
	comData=comData.replaceAll("0&#8217;s|0�s|0's|0s|0’s","0,000");
	
	String prices[] = U.getPrices(html+comData,"\\$\\d{1},\\d+,\\d+|\\$\\d+,\\d+", 0);
	
	minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
	maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
	
	U.log("Price--->"+minPrice+" "+maxPrice);
	
//======================================================Sq.ft===========================================================================================		
	comData = comData.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replaceAll("SQFT Range: <span data-reactid=\"\\d+\">", "SQFT Range: ");
	//U.log("comData: "+comData);
	html = html.replaceAll(">(\\d,\\d{3})</strong></span><span class=\"HomeCard_iconListValue\" data-reactid=\"(\\d+)\">SQFT", " $1 SQFT ");
	
	String[] sqft = U.getSqareFeet(
					html+comData,
					"SQFT Range: \\d,\\d{3} - \\d,\\d{3}|Total SQ FT<br /><span class=\"ng-binding\">\\d,\\d+|SQFT<br><span class=\"ng-binding\">\\d,\\d{3}|SQ FT Range: \\d{1},\\d+ - \\d{1},\\d+|\\d{1},\\d+ Square Feet|Total SQ FT<br><span class=\"ng-binding\">\\d+,\\d+|"
					+ "\\d,\\d{3} SQFT",
					0);
	minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
	maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	U.log("SQ.FT--->"+minSqft+" "+maxSqft);
	//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}2,869[\\s\\w\\W]{100}", 0));
	
//================================================community type========================================================
	html = html.replaceAll("alt=\"(.*)?\"", "").replace("featuring two lakes", "featuring two lakes lakefront Community");
	html=html.replace("those at least 55 years", " seniors 55 and over").replace("golf resorts", "Golf Course and golf resorts");
	String communityType=U.getCommType(html+comData);
	U.log("communityType=="+communityType);
	
////=========== Floorplan Html ======================
//	U.log(combinedFloorPlanHtml);
//	if(floorHtml.contains("View Detail</a>")){
//	String [] floorPlanUrls = U.getValues(floorHtml, "\" class=\"btn\"", "View Detail</a>");
//	U.log("FloorPlan Homes =="+floorPlanUrls.length);
//	int x = 0;
//	
//	for(String floorPlanUrl : floorPlanUrls){
//		floorPlanUrl = U.getSectionValue(floorPlanUrl, "href=\"", "\"");
//		U.log(builderUrl+floorPlanUrl);
//		combinedFloorPlanHtml += U.getHtml(builderUrl+floorPlanUrl, driver);
//		if(x == 6)break;
//		x++;
//	}
//	}
//	//=========== availhomes Html ======================
//	//U.log(availHtml);
//	if(!availHtml.contains("No homes match this criteria")){
//	String [] availHomeUrls = U.getValues(availHtml, "\" class=\"btn\"", "View Detail</a>");
//		U.log("availHomeUrls =="+availHomeUrls.length);
//		int y = 0;
//		
//		for(String availHomeUrl : availHomeUrls){
//			availHomeUrl = U.getSectionValue(availHomeUrl, "href=\"", "\"");
//			U.log(builderUrl+availHomeUrl);
//			combinedAvailHomesHtml += U.getHtml(builderUrl+availHomeUrl, driver);
//			if(y == 5)break;
//			y++;
//		}
//	}
//==========================================================Property Type================================================
	html = html.replace("Luxury Properties", "luxury homes").replaceAll("custom-homes\">Luxury|-custom-homes|>Custom Homes</a>", "");
	//.replace("beautiful coastal Florida property", "coastal-style homes").
	

//	html=html.replace("Luxury Properties", "luxury homes");
	String proptype=U.getPropType((description+combinedAvailHomesHtml+html+comData+combinedFloorPlanHtml.replace("luxury in the spacious", "luxury homes")).replaceAll("\"name\":\"Is Single Family|customer|Light up your patio|within Tidelands on the Intracoastal|intracoastal-on-your-lot|build our duplex in 2018|quality and craftsmanship", "")+loftType);
	
	U.log("proptype: "+proptype);
//	U.log(">>>>>"+Util.matchAll(description,"[\\w\\s\\W]{30}Coastal[\\w\\s\\W]{60}",0));
//	U.log(">>>>>"+Util.matchAll(combinedAvailHomesHtml,"[\\w\\s\\W]{30}Coastal[\\w\\s\\W]{60}",0));
//	U.log(">>>>>"+Util.matchAll(html+comData,"[\\w\\s\\W]{30}Coastal[\\w\\s\\W]{60}",0));
//	U.log(">>>>>"+Util.matchAll(description+combinedAvailHomesHtml+html+comData+combinedFloorPlanHtml,"[\\w\\s\\W]{30}Multi-Family[\\w\\s\\W]{60}",0));

//==================================================D-Property Type======================================================
	html=html.replace("Stories <span class=\"value\">", "Stories ");
	if(combinedFloorPlanHtml!=null)
		combinedFloorPlanHtml = combinedFloorPlanHtml.replace("stunning two-story entry", "stunning 2 story entry");
	
	String dtype=U.getdCommType((html+comData+combinedFloorPlanHtml+combinedAvailHomesHtml)
			.replaceAll("floor|Floor", ""));//+" 2 Story "
//	U.log("========"+Util.matchAll(combinedFloorPlanHtml,"[\\w\\s\\W]{30}split[\\w\\s\\W]{60}",0));
	
//==============================================Property Status=========================================================
	html = html.replace("PHASE I is over 70% Sold", "PHASE I 70% Sold");
	String pstatus=U.getPropStatus((html+comData).replaceAll("delivery-homes\">Quick Delivery|Quick Move-In Homes</a>|'Coming Soon'", ""));
	

	html1 = html1.replaceAll("<!-- /react-text --><!-- react-text: \\d+ -->", "");
	String check = "Quick Move-In Homes in "+communityName;
	
	if(html1.contains(check) && !pstatus.contains("Move")) {
		
		if(pstatus.length()<3)
			pstatus = "Quick Move-In Homes";
		else if(pstatus.length()>3)
			pstatus += ", Quick Move-In Homes";
	}
	
	if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/tidelands"))pstatus = ALLOW_BLANK;
//============================================note====================================================================
	
	
	communityName=communityName.replace("On Your Lot"," On Your Lot");
			/*
			 * if(comUrl.contains(
			 * "https://www.seagatehomes.com/find-your-home/palm-coast/palm-coast-on-your-lot"
			 * )) { proptype="Loft, Multi-Family"; //maxSqft="3354"; }
			 */
	if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/palm-coast-on-your-lot"))dtype="2 Story";
	if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/tidelands"))dtype="2 Story";
	if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/palm-coast-and-canals-model")) {proptype+=", Luxury Homes";dtype="2 Story";}
	if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/grand-haven") ||
			comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/palm-coast-plantation"))dtype = "2 Story";
	if(comUrl.contains("/palm-coast/palm-coast-and-canals-model"))pstatus=ALLOW_BLANK;
		add[2]=add[2].replace(",","").trim();
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		if(comUrl.contains("https://www.seagatehomes.com/find-your-home/palm-coast/palm-coast-on-your-lot"))proptype+=", Multi-Family";

//		=================================================================================
		
		String lotCount=ALLOW_BLANK;
		
		String lotSec=U.getSectionValue(html1, "<g>", "</g>") ;
//		U.log("lotCount=="+lotSec);
		if(lotSec!=null) {
	String [] lotData=U.getValues(lotSec, "<path class=\"leaflet-interactive\"", "/>");
	U.log("lotCount=="+lotData.length);
	if(lotData.length>0) {
		lotCount=Integer.toString(lotData.length);
		 U.log("lotCount=="+lotCount);
	}
		}
		
		
		
		
		
		
		
		
		data.addCommunity(U.getCapitalise(communityName.toLowerCase()),comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		j++;
	}
	cnt++;
//	}catch(Exception e){}
	}

}
