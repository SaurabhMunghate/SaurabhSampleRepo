/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractVantageHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	public ExtractVantageHomes()
			throws Exception {
		super("Vantage Homes","https://vantagehomescolorado.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Vantage Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractVantageHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Vantage Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}


	HashMap<String,String> priceList=new HashMap<>();
	
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpGeckoPath();
//		driver=new FirefoxDriver();
		U.setUpChromePath();
		driver = new ChromeDriver();
		String mainHtml=U.getHTML( "https://vantagehomescolorado.com/communities/"); //"https://www.vantagehomescolorado.com/pages/Communities");
		mainHtml=mainHtml.replace("{\"map_id\":\"1\"}", "");
		mainHtml =mainHtml.replaceAll("</p>\\s*</div>\\s*</div>\\s*</div>\\s*</div>\\s*</div>\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "endsec");
		
		String communities[] = U.getValues(mainHtml, "<div class=\"fl-photo-content fl-photo-img-png\">", "endsec");
		String[] priceData=U.getValues(mainHtml, "map_id\":","}");
		for(String addPrice:priceData)
		{
			
			String nameKey=U.getSectionValue(addPrice,"title\":\"","\"");
			U.log(nameKey);
			for(String com:communities) {
				if(com.contains(nameKey)) {
					addPrice=addPrice+"\n"+com;
				}
			}
			U.log(addPrice);
			priceList.put(nameKey.toLowerCase().trim(),addPrice);
		}
//------------------------------------------------------------------------------------------------------------------------------
		//String urlSection=U.getSectionValue(mainHtml, "<p>COMMUNITIES</p>","<li class=\"mapPDF\">");
//		String iframurl=U.getSectionValue(mainHtml, "<iframe loading=\"lazy\" src=\"", "\" width");
//		U.log(">>>>>>>>>"+iframurl);
//		String frameHtml=U.getHTML(iframurl);
//		U.log(U.getCache(iframurl));
//		String[] addSec=U.getValues(frameHtml, "'<div class=\"ql-editor\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 14px;\">\\u003Cp\\u003E\\u003Cstrong\\u003E", "maxWidth: undefined,");
//		U.log(">>>>>>>>>"+addSec.length);

		String[] comSec=U.getValues(mainHtml, "<div class=\"fl-photo fl-photo-align-center\" itemscope itemtype=\"https://schema.org/ImageObject\">","endsec");
		U.log("count-->"+comSec.length);
		int z=0;
		for(String com:comSec)
		{
//			z++;
//			if(z==1)continue;
			String comUrl="";
			 comUrl=U.getSectionValue(com, "href=\"","\"");
//			 U.log(">>>>>"+comUrl);
//			 String name=U.getSectionValue(comUrl, "communities/", "/").replace("-", " ").toUpperCase();
//			 U.log(">>>>>"+name);
//			 for(String sec : addSec) {
//				 if(sec.contains(name)) {
//					 com=com+"\n"+sec;
//				 }
//			 }
			 
			 if(!comUrl.contains("http")) {
				 comUrl="https://vantagehomescolorado.com"+comUrl;
			 }
			
//			U.log(">>>>>>>>>>"+com);
			
			
			
			
//			String comData=U.getSectionValue(com, "<p>", "<");
			addDetails(comUrl,com);
			
			
		}
		addDetails("https://vantagehomescolorado.com/communities/forest-lakes/","");//====
//		addDetails("https://vantagehomescolorado.com/communities/timber-ridge/","");
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//		try{
	//	if(j==7) {
		if(comUrl.contains("https://vhco.kinsta.cloud/"))comUrl="https://vantagehomescolorado.com/communities/estancia-at-cordera/";
		

		//Single Run
		//if(!comUrl.contains("https://vantagehomescolorado.com/communities/forest-lakes/"))return;

		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"----------> Repeated");
			k++;
			return;
		}
		if(comUrl.contains("https://vantagehomescolorado.com/communities/north-fork/"))
		{
			LOGGER.AddCommunityUrl(comUrl+"----------> page not found");
			
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		U.log("Count :"+j);
		U.log(j+"   commUrl-->"+comUrl);
	//	if(j>=4) {
				String html=U.getHtml(comUrl,driver);
//				U.log("MMMMMM "+comData);
		
				
		//============================================Community name=======================================================================
				String communityName=U.getSectionValue(html, "<title>","</title>");
				if(communityName!=null)communityName=communityName.replaceAll("&#8211; Vantage Homes| – Vantage Homes", "");
				//communityName = U.getCapitalise(communityName.toLowerCase());
				// - Vantage Homes
				 communityName = communityName.replace("- Vantage Homes", "");
				U.log("community Name---->"+communityName);
				
				String availValue = ALLOW_BLANK;
				String availHtml = U.getHTML("https://vantagehomescolorado.com/properties/");
				String[] availData = U.getValues(availHtml, "<div class=\"wpl-column\">", "</ul>");
				U.log("availData---->"+availData.length);
				int i=0;
				for(String avail : availData) {
					if(communityName.contains("Timber Ridge"))communityName="Retreat At Timberridge";
					if(avail.contains(communityName)) {
//						U.log("COUNT==="+avail);
						String data=avail;

						avail = U.getSectionValue(avail, "href=\"", "\"");
						availValue+= U.getSectionValue(U.getHTML(avail),"Property Description</div>","</div>")+data;
					i++;
					}
					
				}
//				U.log("MMMMMMMM "+Util.matchAll(availValue, "[\\s\\w\\W]{10}\\$[\\s\\w\\W]{10}", 0));

//				U.log("COUNT==="+availValue);
				
		//================================================Address section===================================================================
				
				String note="";
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
			//Please verify address for every time..
				
				/*//-----------Address from community contact deatils section----------------
				String addSec = U.getSectionValue(html, "", "");*/
				//-----address section from model homes------------------ 
				String addSec =U.getSectionValue(html, "<a href=\"https://goo.gl/maps/","</a></p>");
//				U.log("addSec : "+addSec+"::");
				
				String aa=priceList.get(communityName.toLowerCase().trim());
				if(communityName.equals("Estancia at Cordera")) { 
					aa=priceList.get("cordera");
				}
				//U.log("addSec33 : "+aa);
				if(addSec!=null && !comUrl.contains("/university-park") &&!comUrl.contains("sanctuary-pointe")) {
					addSec=addSec.replace("<br />", ",").replace("Colorado Springs 80921", "Colorado Springs, 80921").replace("<br>", ",").replaceAll("Eb11HWY4cY2Xyszd6\">|TDxLDejDWRkZKgsx9\" target=\"_blank\" rel=\"noopener\">|HyhCxnVQJum\" target=\"_blank\" rel=\"noopener\">|KzkBNcZDUhN2\" target=\"_blank\" rel=\"noopener\">|MJ1XhEBbMBK7mAeZ8\" target=\"_blank\" rel=\"noopener\">|hkvecTJZyGYjncC9A\">|PWCawqXovBUsAqor5\" target=\"_blank\" rel=\"noopener\">|FLkW1f5N9a82\">|8LA3zMejwFt\" target=\"_blank\" rel=\"noopener\">|mTFfucHhT6L5GuEK8\" target=\"_blank\" rel=\"noopener\">", "");
//					if(addSec.contains("<i class=\"fa fa-map-o\" aria-hidden=\"true\"></i>")) {
//						addSec= U.getSectionValue(addSec, "<p>", "</p>");
//					}
//					U.log("Updated Address:::::"+addSec);
					
					if(addSec.contains("text\">"))
						addSec = U.getSectionValue(addSec, "<p>", "</p>");
					add = U.getAddress(addSec);
					//U.log(Arrays.toString(add));

				}
				//if(comUrl.contains("/estancia-at-cordera/") || comUrl.contains("/count-fleet-court/"))	{
				//}
				if(aa!=null && add[3].length()<4 && addSec.contains("<i class=\"fa fa-map-o\" aria-hidden=\"true\"></i>")){
					String mainAddSec ="";
					if(comUrl.contains("sanctuary-pointe")) {
						mainAddSec =U.getSectionValue(StringEscapeUtils.unescapeJava(aa), "target=\"_blank\" rel=\"noopener\">", "</a></p>");
						
					}
					if(mainAddSec == null) mainAddSec = U.getSectionValue(aa, "address\":\"", ", United States");
					if(mainAddSec == null) mainAddSec = U.getSectionValue(aa, "address\":\"", ", USA\"");
					if(mainAddSec == null) mainAddSec = U.getSectionValue(StringEscapeUtils.unescapeJava(aa), "target=\"_blank\" rel=\"noopener\">", "</a></p>");
					
					U.log("Main Page Address ::: "+mainAddSec);
					
					if(mainAddSec != null){
						add = U.getAddress(mainAddSec);
					}
					if(mainAddSec!=null) {
						mainAddSec=mainAddSec.replace("<br />", ",");					
						add = U.getAddress(mainAddSec);	
					}
					U.log(Arrays.toString(add));
					/*if(add[3] == ALLOW_BLANK){
						mainAddSec = U.getSectionValue(aa, "rel=\\\"noopener\\\">", "<\\/a>");
						U.log("----><"+mainAddSec);
						if(mainAddSec != null){
							mainAddSec = mainAddSec.replace("<br \\/>", "<br>").replace("&nbsp;", "");
							U.log(mainAddSec);
							String val = Util.match(mainAddSec, "<br>(.*?)$");
							U.log(val);
							if(val != null) add[3] = Util.match(val, "\\d{5}");
							if(add[3] == null) add[3] = ALLOW_BLANK;
						}
					}*/
				}
				String []tempAdd=add;
				if(add[3].length()<4 && addSec!=null && !comUrl.contains("/sanctuary-pointe/"))
				{
					if(!comUrl.contains("estancia-at-cordera/")){
						
						addSec = Util.match(addSec, "\">(.*?)\\s*$",1);
					}
					if(comUrl.contains("/communities/university-park")) {
						addSec=U.getSectionValue(html, "href=\"https://www.google.com/maps/place", "</a></p>");
//						U.log("addSec==== "+addSec);
						addSec=addSec.replaceAll("/(.*?)\">", "");
					}
					if(addSec!=null) {
					addSec = addSec.replaceAll("&nbsp;|FLkW1f5N9a82\">", "").replace("<br>", ",").replace("<br />", ",");
					addSec = addSec.replaceAll("Colorado Springs (\\d{5})", "Colorado Springs, $1");
					
					//U.log("Com Page Address ::: "+addSec);
//					geo = "TRUE";
					String[] add1 = U.getAddress(addSec);
					add[3] = add1[3];
					if(add[0] == ALLOW_BLANK) add[0] = add1[0];
					if(add[1] == ALLOW_BLANK) add[1] = add1[1];
					if(add[2] == ALLOW_BLANK) add[2] = add1[2];
					//latlag=U.getGoogleLatLngWithKey(add);
					//geo="FALSE";
					
					}
				}
//				if(comUrl.contains("/communities/count-fleet-court/")) add[2] = "CO";
				
//				if (add[2]==null&&tempAdd[2]!=null) {
//					add[2]=tempAdd[2];
//				}
				
				/*if(comUrl.contains("https://www.vantagehomescolorado.com/communities/university-park")) {
					String[] addSec1 = U.getValues(html, "class=\"fl-icon-text\">", "</a>");
					addSec = addSec1[1].replaceAll("<p>|</p>", "").replace("<br>", ",");
					addSec = U.getNoHtml(addSec);
					add = U.getAddress(addSec);
					
				}*/
//				if(add[0].equals("-")) {
//					String addSec=U.getSectionValue(html, "", To)
//				}
				if(comUrl.contains("communities/sanctuary-pointe/")) {
					///addSec=U.getSectionValue(html, "<div><a href=\"https://goo.gl/maps/", ":<br>");
					addSec=U.getSectionValue(html, "<a href=\"https://goo.gl/maps", "<br />");
					U.log("LLLL"+addSec);
					String a=U.getSectionValue(addSec, "target=\"_blank\">", "<div>Open");
					a=U.getNoHtml(a);
//					U.log("DDDDD  "+a);
					add=U.getAddress(a);
				}
				if(comUrl.contains("/communities/forest-lakes/")) {
					addSec=U.getSectionValue(html, "itemprop=\"name description\">Model Home</span>", "Open:<br />");
				//	String a=U.getSectionValue(addSec, "<a href=\"https://goo.gl/maps", "</div>");
					String a=U.getSectionValue(addSec, "<a href=\"https://goo.gl/maps", "</div>");
					a=U.getNoHtml(a);
//					U.log("DDDDD  "+addSec);
					add=U.getAddress(a.replace("/2yE6YTNLNZpxXXq16\">", ""));
				}
				
				
				if(add[0]!=null)
				add[0]=U.getNoHtml(add[0]);
				
				U.log("Address---->"+add[0]+" : "+add[1]+" : "+add[2]+" : "+add[3]);
				

		//--------------------------------------------------latlng----------------------------------------------------------------
				String latSec=U.getSectionValue(html, "https://www.google.com/maps/dir//","\"");
				if(latSec == null)
					latSec = U.getSectionValue(html, "https://www.google.com/maps","/a>");
				if(latSec!=null)
				{
					addSec=U.getSectionValue(latSec,"@",",1");
				}
				if(latSec!=null)
				{
					latlag[0]=Util.match(addSec,"\\d{2,3}\\.\\d+");
					latlag[1]=Util.match(addSec,"-\\d{2,3}\\.\\d+");
				}
				else if(aa!=null){
					U.log("inside elese if");
					latlag[0]=Util.match(aa,"\"lat\":\"(.*?)\"",1);
					latlag[1]=Util.match(aa,"\"lng\":\"(.*?)\"",1);
				}
				html=html.replace("<iframe id=\"frame_comm_filing\" class=\"Phases\" style=\"width: 100%; height: 650px;\" src=\"", "<iframe id=\"frame_comm_filing\" class=\"Phases\" src=\"");
				String mapUrl = U.getSectionValue(html, "<iframe id=\"frame_comm_filing\" class=\"Phases\" src=\"", "\"");
				U.log("this is mapUrl::"+mapUrl);
				String latPage = U.getHtml(mapUrl,driver);
				if(latPage!=null) {
					latlag[0]= U.getSectionValue(latPage, "id=\"center_lat\" value=\"", "\"");
					latlag[1]= U.getSectionValue(latPage, "id=\"center_long\" value=\"", "\"");
				//	geo="TRUE";
				}
//				String latlngPage = U.getHTML("https://vantagehomes.lotvue.com/lotbuzz/lotbuzz_view?community="+communityName.replace(" ", "+")+"&lotbuzz_site_url=&is_touch=1&split_map=&building_name=&floor=&parcel=&phase_name=");

				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[0]!=null && add[1]!=null &&  add[3]!=null && add[2]==null  ) {
					add[2]=U.getAddressGoogleApi(latlag)[2];
					if(add == null)add[2] = U.getAddressHereApi(latlag)[2];
					geo="TRUE";
					}
					U.log("Address---->"+add[0]+" : "+add[1]+" : "+add[2]+" : "+add[3]);

				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					add[0]=add[0].replace("3237 Bright Moon Drive", "Bright Moon Drive");
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}
				
				if((add[2]==ALLOW_BLANK || add[2]==null || add[3] == ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK)
				{
					U.log(Arrays.toString(add));
					String add1[] = U.getAddressGoogleApi(latlag);
					if(add1 == null) add1 = U.getAddressHereApi(latlag);
					if(add[0]==ALLOW_BLANK||add[0]==null)add[0]= add1[0];
					if(add[1]==ALLOW_BLANK||add[1]==null)add[1]= add1[1];
					if(add[2]==ALLOW_BLANK || add[2]==null)	add[2] = add1[2];
					if(add[3] == ALLOW_BLANK) add[3] = add1[3];
					geo="TRUE";
				}

				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
/*				if(comUrl.contains("https://www.vantagehomescolorado.com/communities/count-fleet-court/")){
					add = new String[] {"1118 Kelso Place","Colorado Springs","CO", "80921"};
					latlag = U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}*/
/*				if(comUrl.contains("https://www.vantagehomescolorado.com/communities/21")){
					add = new String[] {"8282 Wheatland Drive","Colorado Springs","CO", "80908"};
					latlag = U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}*/
		//============================================Price and SQ.FT======================================================================
				String availableUrlSection = U.getSectionValue(html, "fl-button-width-auto fl-button-center\">", "</a>");
				String availableHome = null;
				try {
				if(availableUrlSection != null){
					String availableUrl = U.getSectionValue(availableUrlSection, "<a href=\"", "\"").replace("amp;", "");
					U.log("availableUrl -->"+availableUrl);
					availableHome = U.getHTML(availableUrl);
				}
				}
				catch(Exception e) {}
				
				String homeHtml="";
				String[] urlSec=U.getValues(html, "<h2 class=\"fl-post-carousel-title\"","</h2>");
				if(urlSec.length==0)
					urlSec=U.getValues(html, "<p>Model: ","</p");
				for(String url:urlSec)
				{
					url = url.replace("<a href=\"<h ref=", "<a href=\"<a href=");
					String homeUrl=U.getSectionValue(url, "<a href=\"","\"");
					U.log(">>"+homeUrl);
					if(homeUrl.startsWith("http")){
						homeHtml=homeHtml+U.getHTML(homeUrl);
					}
					else {
						homeUrl = "https://vantagehomescolorado.com/"+homeUrl;
						if(homeUrl.startsWith("http")){
							homeHtml=homeHtml+U.getHTML(homeUrl);
						}
					}
				}
				
//				U.log("homehtml::"+homeHtml);
				String availHome="";
				String homSec=U.getSectionValue(html, "<div class=\"ihf-grid-result-price title-bar-1\">","</i> </a>");
				if(homSec!=null) {
				String[] availUrl=U.getValues(homSec, "<a href=\"","\">");
				for(String url1:availUrl)
				{
					U.log(">>"+url1);
					availHome=availHome+U.getHTML(url1);
				}
				}
				
				if(comData==null)
				{
					comData=ALLOW_BLANK;
				}
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
				comData=comData.replace("low $400s", "$400,000").replaceAll("0&#8217;s|0�s|0's","0,000");
				
				U.log("PRICE MATCVH"+Util.match(html+comData+homeHtml+availHome +availValue+ availableHome,"[\\w\\W\\s]{50}\\$774[\\w\\W\\s]{50}",0));
				String prices[] = U.getPrices(html+comData+homeHtml+availHome +availValue+ availableHome,
						"<span >\\$\\d{1},\\d{3},\\d{3}</span>|<span >\\$\\d{3},\\d{3}</span>|\\$\\d{3},\\d{3}|from the low-\\$\\d{3},\\d{3}|the mid-\\$\\d{3},\\d{3}|Price:</strong> \\$\\d{3},\\d+|price_box\"  >\\s+<span >\\$\\d{3},\\d+<|sale-price\"> \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d+|priceBlock\">\\$\\d{3},\\d+|Price: \\$\\d{3},\\d+|low \\$\\d{3},\\d+|mid \\$\\d{3},\\d+|high \\$\\d{3},\\d+|upper \\$\\d{3},\\d{3}", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				homeHtml=homeHtml.replaceAll("</h3>\\s*<p style=\"text-align: center;\">\\s*<span style=\"font-size: 20px;\">", ":");
				U.log("Price--->"+minPrice+" "+maxPrice);
				//U.log("availHomes : "+availHome);
//                
//                if(comUrl.contains("communities/timber-ridge/")) {
//                	minPrice="$1,230,000";
//                }
			
				
		//======================================================Sq.ft===========================================================================================		
				
				
				
//				U.log("SSS"+Util.matchAll(html,"[\\w\\W\\s]{40}1500[\\w\\W\\s]{40}",0));
//				U.log("SSS"+Util.matchAll(comData,"[\\w\\W\\s]{40}1500[\\w\\W\\s]{40}",0));
//				U.log("SSS"+Util.matchAll(homeHtml,"[\\w\\W\\s]{40}1500[\\w\\W\\s]{40}",0));
//				U.log("SSS"+Util.matchAll(availHome,"[\\w\\W\\s]{40}1500[\\w\\W\\s]{40}",0));
			//	homeHtml=homeHtml.replace("TOTAL SQ. FT.:1500 - 2871","");
				String[] sqft = U
						.getSqareFeet(
								html+comData+homeHtml+availHome,
								"\\d{4}-\\d{4} Sq.Ft|Home Sq. Ft: <span class=\"colorBrown\">\\d{4} - \\d{4}|Sq. Ft.: \\d,\\d{3}|Range:</strong> \\d{4}-\\d{4}|Sq.Ft.:</strong> \\d{4}|Sq. Ft: \\d{1},\\d+|TOTAL SQ. FT.:\\d{4}\\s*-\\s*\\d{4}",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
		//================================================community type========================================================
	
				String communityType=U.getCommType(html+comData);
				
		//==========================================================Property Type================================================
				
				
				String proptype=U.getPropType((availValue+html+comData+availHome+homeHtml).replace("most luxurious", "luxury home").replaceAll("Villa Sport", ""));
		
				
		//==================================================D-Property Type======================================================
				html=html.replaceAll("sterling-ranch|Old Ranch|tag-two-story","");
				//U.log(homeHtml);
				String dtype=U.getdCommType((availValue+html+comData+homeHtml+availHome).replaceAll("ranch plan|tag-ranch|Sterling Ranch|sterling-ranch|tag-two-story","").replace("Two-Story"," 2 Story "));
				
		//==============================================Property Status=========================================================
				html=html.replaceAll("TimberRidge is currently sold|Trails Coming soon|currently selling from the Cordera model|now open|Rec Center Coming Soon","");//.replace("Walk-Out Lots Still Available", "Walk-Out Lots Available")
				String pstatus=U.getPropStatus(html+comData);//.replace("3 LOTS COMING IN 2021", "3 LOTS COMING 2021")
				
		
				
	//============================================note====================================================================
	
				//image
			if(comUrl.contains("http://www.vantagehomescolorado.com/pages/estancia"))minPrice = "$400,000";	
			if(comUrl.contains("https://www.vantagehomescolorado.com/communities/sanctuary-pointe")) {
				add[0]="16486 Florawood Place";
				geo="FALSE";
			}
			if(comUrl.contains("https://www.vantagehomescolorado.com/communities/thefarm/"))proptype+=", Farmhouse Style Homes";
			/*if(comUrl.contains("/flying-horse/")) {
				String latsec="39.0126484,-104.7895576";
				latlag=latsec.split(",");
				geo="FALSE";
			}*/
			//if(comUrl.contains("/thefarm/"))maxPrice="$549,900";
			
			
//			if(comUrl.contains("https://vantagehomescolorado.com/communities/forest-lakes/")){
//				add[0]="16486 Florawood Place";
//				add[1]="Monument";
//				add[2]="CO";
//				add[3]="80132";
//				geo = "FALSE";
//			}
			
			if(note==null || note.length()<3)
				note = ALLOW_BLANK;
				if(comUrl.contains("https://vantagehomescolorado.com/communities/forest-lakes/")){
//					add[0]="16486 Florawood Place";
//					add[1]="Monument";
//					add[2]="CO";
//					add[3]="80132";
					latlag[0]="38.9976322";
					latlag[1]="-104.7992894";
					pstatus=pstatus.replace("Sold Out,", "");
				}
//				if(comUrl.contains("https://vantagehomescolorado.com/communities/timber-ridge/")){
//				//	add[0]="9540 Federal Dr";
//					add[1]="Colorado";
//					add[2]="CO";
//					latlag=U.getlatlongGoogleApi(add);
//					add=U.getAddressGoogleApi(latlag);
//					geo="TRUE";
//				//	add[3]="80921";
//				//	latlag[0]="38.9976322";
//				//	latlag[1]="-104.7992894";
//				}

//if(comUrl.contains("https://vantagehomescolorado.com/communities/flying-horse/")||comUrl.contains("https://vantagehomescolorado.com/communities/north-fork/"))dtype=ALLOW_BLANK;				
				
				if(comUrl.contains("https://vantagehomescolorado.com/communities/thefarm/"))proptype="Patio Homes";
				if(comUrl.contains("https://vantagehomescolorado.com/communities/forest-lakes/"))proptype="Luxury Homes, Loft, Patio Homes";
				if(comUrl.contains("com/communities/timber-ridge/"))communityName="Timber Ridge";

				add[0]=add[0].replaceAll("\n*", "");
				add[0]=add[0].replaceAll(" \\s*", "");
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				//Site Map======
				
				String lotCount=ALLOW_BLANK;
				if(html.contains("OPEN INTERACTIVE LOT MAP")) {
					String mapSec=U.getSectionValue(html, "OPEN INTERACTIVE LOT MAP", "</iframe></div>");
					String siteMapUrl=U.getSectionValue(mapSec, "src=\"", "\"");
					String mapHtml=U.getHtml(siteMapUrl, driver);
					U.log("Path::"+U.getCache(siteMapUrl));
					
//					String[] lotSold=U.getValues(mapHtml, "<path d=\"M49", "/>");
//					U.log("Sold Count:: "+lotSold.length);
//					
//					String[] lotAvail=U.getValues(mapHtml, "<path d=\"M18", "/>");
//					U.log("Available Count"+lotAvail.length);
//					
//					String []lotQuick=U.getValues(mapHtml,"<path d=\"M35", "/>");
//					U.log("Quick Count"+lotQuick.length);
//					
//					String []lotModel=U.getValues(mapHtml, "<path id=\"IL_100", "</path>");
//					U.log("total Count"+lotModel.length);
					int s=0;
					
					
					String siteMapStat=U.getSectionValue(mapHtml, "Sales Status<a href", "<script>");
//					siteMapStat=U.getNoHtml(siteMapStat);
					String[] lotAvail=U.getValues(siteMapStat, "<span class=\"legend_text \" data-legend-id=\"", "</div>");
					for(String lotdata : lotAvail) {
						lotdata=U.getNoHtml(lotdata).trim();
						U.log("lotdata==="+lotdata);
						String d=Util.match(lotdata.replaceAll("\\d+\">", ""), "\\d+");
						s+=Integer.parseInt(d);
						
					}
					lotCount=Integer.toString(s);
					U.log("lotCount==="+lotCount);
//					U.log("siteMapStat=="+siteMapStat);
//					String lotSold=U.getSectionValue(mapHtml, "Sold</span>", ")</span>");
//					U.log(U.getNoHtml(lotSold));
//					String lotSoldCount=U.getNoHtml(lotSold).replace("(", "").trim();
//					U.log(lotSoldCount);
//					
//					String lotAvail=U.getSectionValue(mapHtml, "Available Lot</span>", ")</span>");
//					String lotAvailCount=U.getNoHtml(lotAvail).replace("(", "").trim();
//					
//					String lotModel=U.getSectionValue(mapHtml, "Model Home</span>", ")</span>");
//					String lotModelCount=U.getNoHtml(lotModel).replace("(", "").trim();
//					
//					String lotQuick=U.getSectionValue(mapHtml, "Spec Home / Quick Move-in</span>", ")</span>");
//					String lotQuickCount=U.getNoHtml(lotQuick).replace("(", "").trim();
//					
//					String lotUnAvail=U.getSectionValue(mapHtml, "Unavailable / Not For Sale</span", "");
					
				
				}
				
				
				
				
				
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].replaceAll(",|\n", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus.replace("Selling Out, Currently Sold", "Selling Out"));
					data.addNotes(note); 
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
					data.addUnitCount(lotCount);
	//}
	j++;
//		}catch(Exception e){}
	}
	//}
}
