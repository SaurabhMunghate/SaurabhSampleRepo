/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWoodlandHomes extends AbstractScrapper
{
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;

	public ExtractWoodlandHomes()throws Exception  {
		super("Woodland Homes","https://www.woodlandhomes.com/");
		LOGGER=new CommunityLogger("Woodland Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		AbstractScrapper a=new ExtractWoodlandHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Woodland Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k); 
	}

	WebDriver driver= null;
	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String mainHtml=U.getHtml("http://www.woodlandhomes.com/communities",driver);
		String[] comSec=U.getValues(mainHtml, "<div class=\"CommunityCard_inner\"","title=\"Map This Community\"");
		U.log("Total Community--->"+comSec.length);
		for(String comData:comSec)
		{
//			U.log("ComData==="+comData);
			String comUrl="http://www.woodlandhomes.com"+U.getSectionValue(comData, "href=\"","\"");
//			U.log(comUrl);
//			try {
				addDetails(comUrl,comData);
//			} catch (Exception e) {}
//			break;
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
	// TODO : For Single Community Execution
		
//	if(!comUrl.contains("meridianville-al/monroe-manor"))return;
//	if(j >= 0 && j<=7)
//		if(j >= 9)
		
	{
		comUrl=comUrl.replace("http://", "https://");
		
		U.log("comData-->"+comData);
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"-----------> Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

		U.log(j+"   commUrl-->"+comUrl);
		if(comUrl.contains("http://www.woodlandhomes.com/page.php?p=3&amp;com=28"))comUrl="http://www.woodlandhomes.com/the-retreat-at-abbington";
		if(comUrl.contains("http://www.woodlandhomes.com/page.php?p=3&amp;com=10"))comUrl="http://www.woodlandhomes.com/cedar-cove";
		if(comUrl.contains("http://www.woodlandhomes.com/page.php?p=3&amp;com=39"))comUrl = "http://www.woodlandhomes.com/the-retreat-at-abbington";
		String html=U.getHtml(comUrl, driver);
		
		html=U.removeSectionValue(html, "window.__PRELOADED_STATE__", "</script>");
		html=html.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->", "");
		
		html=html.replace("the children to enjoy is now open","");
		html=html.replace(" class=\"ng-binding\">Townhome Designs</a></li>","");
		html=html.replace("class=\"ng-binding\">Patio Home","");
		
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "\">","<").replace("&#8217;","").replace("Patio Homes","").replace("Town Homes","");
		U.log("community Name11---->"+communityName.length());
		if(communityName.length()<1) {
//			U.log("LLLLLLLLLL");
			communityName=U.getSectionValue(html, "<h2 class=\"DetailOverview_heading\" data-reactid=","<span").replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "")
					.replace("&#8217;","").replaceAll("\"\\d+\">", "").replace("Patio Homes","").replace("Town Homes","");
		}
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		
//		String directionHtml=U.getHtml(comUrl+"-directions", driver);
		String note=ALLOW_BLANK;
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html,"<span class=\"DetailsPage_h2\" data-reactid=","</span>");
		U.log("FIRST:===> "+addSec);
		if(addSec==null) {
			addSec=U.getSectionValue(html,"<h2 class=\"DetailOverview_heading\"","</span>");
			addSec=U.getNoHtml(addSec);
		}
		U.log("FIRST:===> "+addSec);
		
		if(addSec!=null) {
			
			addSec=addSec.replaceAll("data-reactid=\"\\d+\">"+communityName, "")
					.replaceAll("\"\\d+\">", "")
					.replace("102 Hollow Tree Circle Huntsville AL 35811 | New Market, AL 35811", "102 Hollow Tree Circle, Huntsville, AL 35811")
					.replace(" | ", ", ")
					
					.replace("335 Kendallwood DR Meridianville AL 35759", "335 Kendallwood DR");
//			U.log("FIRST:===> "+addSec);
			addSec = U.getCapitalise(addSec.toLowerCase());
			addSec=addSec
					.replaceAll("Contact Agent for Private Tour|Model Home Coming Soon", "");
			add=U.getAddress(addSec);
			
		}
//		if(addSec!=null && !addSec.contains("{{community.city_name}}")){
//			U.log("FIRST: "+addSec);
//			addSec=addSec.replaceAll("\"\\d+\">", "").replace(" | ", ", ");
//			addSec = U.getCapitalise(addSec.toLowerCase());
//			addSec=addSec
//					.replaceAll("Contact Agent for Private Tour|Model Home Coming Soon", "");
//			if(addSec.contains("ng-if=\"community.city_name\"")) {
//			add[0]=U.getSectionValue(addSec, "<span class=\"ng-binding\">","</span>");
//			
//			U.log("=== "+add[0]);
//			
//			add[1]=U.getSectionValue(addSec, "<span ng-if=\"community.city_name\" class=\"ng-binding ng-scope\">","</span>").replace(",","");
//			add[2]=U.getSectionValue(addSec, "<span ng-if=\"community.state_code\" class=\"ng-binding ng-scope\">","</span>").replace(",","");
//			}
//			else {
//				addSec=null;
//			}
//		}
		if(add[0] != null && add[0].isEmpty()){
			addSec = U.getSectionValue(html, "Model Home located at", "</span>");
			addSec = U.getCapitalise(addSec.toLowerCase());
			U.log(addSec);
			U.log("=== "+add[0]);
			if(addSec != null){
				add = U.getAddress(addSec);
			}
		}
		
		if(comUrl.contains("http://www.woodlandhomes.com/wildwood")) {
			addSec=U.getSectionValue(html,"<div class=\"top-row\">","</h3>");
			addSec=U.getSectionValue(addSec, "<span class=\"ng-binding\">","</span>")
					.replace("6601 WAXWOOD DRIVE NW MADISON AL 35757", "6601 WAXWOOD DRIVE NW, MADISON, AL 35757");
			add = U.getAddress(U.getCapitalise(addSec.toLowerCase()));
		}
//		if(add[0]!=null) {
			add[0]=add[0].replace("Meridianville AL 35759", "");
//		}

		U.log("Address---->"+add[0]+"   "+add[1]+"   "+add[2]+"   "+add[3]);
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
//		String latSec=U.getSectionValue(directionHtml, "https://maps.google.com/?q","\"");
		String latSec=U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place/","@");
//U.log("======"+latSec);
		
		if(latSec!=null){
			latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
			latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK){
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if((add[0].length()<4 || add[3]==null) && latlag[0]!=ALLOW_BLANK){
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK){
			String[] add1=U.getAddressGoogleApi(latlag);
			if(add1 == null) add1 = U.getAddressHereApi(latlag);
			
			add[3]=add1[3];
			add1 = null;
			geo="TRUE";
		}
		if(comUrl.contains("the-villages-at-kelly-cove")) {
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
//============================================Price and SQ.FT======================================================================
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String pHtml=ALLOW_BLANK;
//		String quickHtml = getHtml(comUrl+"-homes", driver);
//		U.log(U.getCache(comUrl+"-homes"));
		int quickHomeCount = 0;
//		if(quickHtml!=null){
//					
//				String pVals[]=U.getValues(quickHtml,"<favorite url=\"", "\"");
//				U.log("Quick home no>>>>"+pVals.length);
//				 for(String pVal:pVals){
//					 
//					 String pVal1="http://www.woodlandhomes.com"+pVal;
//					 U.log(pVal1+"::::::::::::::pVal");
//					 if(pVal1.contains("{")) continue;
//					 if(comUrl.equals(pVal1))continue;
//					 String moveInHomeHtml = U.getHtml(pVal1, driver); 
//					  pHtml=pHtml+ U.getSectionValue(moveInHomeHtml, "Home Details</h1>", "<main class=");
//					  quickHomeCount++;
//				}
//			
//		}
		
		String quickHtml =null;
		String quickHomeSec=U.getSectionValue(html, "Quick Move-In Homes</h3>", "Photo Gallery</h3>");
		if(quickHomeSec!=null) {
		String[] quickData=U.getValues(quickHomeSec, "class=\"HomeCard_inner\"", "</div></div></div></div></div></div></div></div></div></div></div></div>");
		U.log("quickData=="+quickData.length);
		for(String quickHomeData :quickData ) {
			
			if(!quickHomeData.contains("Status: Under Construction")) {
			quickHomeCount++;
			}
			String quickHomeUrl="https://www.woodlandhomes.com"+U.getSectionValue(quickHomeData, "href=\"", "\"");
//			U.log("quickHomeUrl=="+quickHomeData);
			U.log("quickHomeUrl=="+quickHomeUrl);
			quickHtml=getHtml(quickHomeUrl, driver);
			quickHtml=quickHomeData+U.getSectionValue(quickHtml, "class=\"Carousel_imageButtonRight\"", "</div></div></li></ul></div></div></div></div></div></div><div");
		}
	}
		U.log("Total Quick Home Count ::"+quickHomeCount);
//		 pHtml=pHtml.replace("class=\"ng-binding\">Patio Home","");
//		 pHtml=pHtml.replace("class=\"ng-binding\">Townhome Designs","");
		
//		String floorHtml=U.getHtml(comUrl+"-floorplans", driver);
		
		
		String floorHtml =null;
		String allFloorHtml = ALLOW_BLANK;
		int floorplanCount=0;
//		String floorPlanSec=U.getSectionValue(html, "Available Floor Plans</h3>", "Photo Gallery</h3>");
		String[] floorPlanData=U.getValues(html, "<div class=\"PlanCard_wrapper\"", "</div></div></div></div></div><div");
		if(floorPlanData.length>0) {
		for(String floorplan :floorPlanData ) {
			floorplanCount++;
			String floorPlanUrl="https://www.woodlandhomes.com"+U.getSectionValue(floorplan, "href=\"", "\"");
			U.log("floorPlanUrl: "+floorPlanUrl);
			floorHtml=getHtml(floorPlanUrl, driver);
			floorHtml=U.getSectionValue(floorHtml, "class=\"Carousel_imageButtonRight\"", "</div></div></li></ul></div></div></div></div></div></div><div");
			allFloorHtml += floorHtml; 
		}
		}
		U.log("Total Floorplan Count ::"+floorplanCount);
		
		
		
		
		
		html= html.replace("starting in the 400s", "starting in the $400,000");
		html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
		comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
		//comData=comData.replace("0’s","0,000");
		html=html.replace("0’s","0,000");
		
		String priceMatch = Util.match(html, "\\$\\d{3}s");
		if(priceMatch != null){
			String match =  priceMatch.replace("s", ",000");
			html = html.replace(priceMatch, match);
		}
			
		
		String prices[] = U.getPrices(html+comData+quickHtml+floorHtml,"from the \\$\\d{3},\\d{3}|\\$\\d+,\\d+|\\$\\d{1},\\d{3},\\d+|\\$\\d{3},\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);

//======================================================Sq.ft===========================================================================================		
		
html=html.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">SQ FT", " SQ FT");
if(floorHtml!=null)
floorHtml=floorHtml.replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">Story", " Story")	;	

String[] sqft = U.getSqareFeet(html+comData+quickHtml+floorHtml,
						"\\d,\\d{3} SQ FT|SQFT Range: \\d,\\d{3} to \\d,\\d{3}|Square Feet:</span> \\d,\\d{3}|Range: \\d+,\\d+ to \\d+,\\d+|Feet:</span> \\d+,\\d+|\\d+,\\d+ Sq. Ft.|\\d+,\\d+ sq. ft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);

//================================================community type========================================================

		String communityType=U.getCommType((html+comData).replace(" Jones Golf Trail", ""));

//==========================================================Property Type================================================
//		String floorSec = U.getSectionValue(floorHtml, "<div class=\"plans\">", "dir-pagination-controls");
		//U.log(floorSec);
//	if(pHtml!=null) {
//		pHtml=pHtml.replaceAll("craftsman|Carriage Style Garage", "");
//	}
//	if(floorSec!=null) {
//		floorSec=floorSec.replace("- Executive</h4>", "executive style townhomes");
//	}
		html=U.getSectionValue(html, "class=\"Carousel_imageButtonRight", "<footer");
		html=html.replaceAll("accessing Colonial Golf Course|access to Colonial Golf Course", "")
				.replaceAll("- Executive</a>", "- executive style home</a>");
		
		String proptype=U.getPropType((html+comData+floorHtml+quickHtml).replaceAll("accessing Colonial Golf Course|access to Colonial Golf Course", ""));
		if(proptype.contains("Townhome") && proptype.contains("Townhouse"))
			proptype = proptype.replaceAll(",Townhouse|Townhouse,", "");
		
//		U.log("MMM"+Util.matchAll((html),"[\\w\\W\\s]{70}Colonial[\\w\\W\\s]{70}",0));
////		U.log("MMM"+Util.matchAll((comData),"[\\w\\W\\s]{70}Colonial[\\w\\W\\s]{70}",0));
////		U.log("MMM"+Util.matchAll((floorHtml),"[\\w\\W\\s]{70}Colonial[\\w\\W\\s]{70}",0));
//		U.log("MMM"+Util.matchAll((quickHtml),"[\\w\\W\\s]{70}Colonial[\\w\\W\\s]{70}",0));

		
//==================================================D-Property Type======================================================
		allFloorHtml = allFloorHtml
		.replaceAll("ItemValue\" data-reactid=\"\\d+\">(\\d{1})</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"167\">Story</span>", " $1 Story ")
		.replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">", " ");
		
		String dtype=U.getdCommType(((html+comData+quickHtml+floorHtml+allFloorHtml).replaceAll("</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d+\">Stories", " Stories").replaceAll("ranch|Ranch","")+comUrl).replace("Colonial Golf Course", "The Colonial  Golf Course"));
		U.log("dtype: "+dtype);

//==============================================Property Status=========================================================
		html = html.replaceAll("Coming Fall 2022 Welcoming local residents and families relocating to North|TOUR NOW|Move-In Ready Homes</a>| Fall 2020", "");
//		html=html.replace("basement home sites available","");
		html=html.replace(" its fifth and final phase of this one-of-a-kind, master-planned community. ", "");
		
		comData = comData.replace("ONLY 2 INVENTORY LOTS REMAINING","ONLY 2 LOTS REMAINING");
		
		String pstatus=U.getPropStatus((html+comData).replace("Quick Move-In Homes", ""));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+comData, "[\\s\\w\\W]{100}Coming Fall 2022[\\s\\w\\W]{60}", 0));

		if( quickHomeCount > 0){
			if(pstatus.length() > 1) pstatus = pstatus +", Quick Move-in Homes";
			else pstatus = "Quick Move-in Homes";
		}
//		if(quickHtml!=null && quickHtml.contains("No homes match this criteria")){
//			pstatus=pstatus.replace("Move-in Ready Homes","No Move-in Ready Homes");
//		}
		
//============================================note====================================================================
	
//		if(comUrl.contains("http://www.woodlandhomes.com/the-bluffs") && !pstatus.contains("Final Phase")){
//			if(pstatus == ALLOW_BLANK) pstatus = "Final Phase";
//			else if(pstatus != ALLOW_BLANK) pstatus += ", Final Phase";
//		}
		
		//from community page image
		if(comUrl.contains("http://www.woodlandhomes.com/mountain-preserve") && !communityType.contains("Master Planned")){
			if(communityType == ALLOW_BLANK) communityType = "Master Planned";
			else if(communityType != ALLOW_BLANK) communityType += ", Master Planned";
		}
		
		//http://www.woodlandhomes.com/cedar-cove
		if (comUrl.contains("http://www.woodlandhomes.com/foxfield"))minSqft ="3000";
//		{
//			pstatus=pstatus+", Final Phase Now Available";
//		}
		if(comUrl.contains("/madison-al/bellawoods"))	pstatus = "Coming Spring 2022"; //Img
		if(dtype.length()==0)dtype=ALLOW_BLANK;
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
	}
		j++;
	}
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());

					html = driver.getPageSource();
					
					try{
						WebElement click = driver.findElement(By.xpath("/html/body/section/div/div/main/div[3]/dir-pagination-controls/ul/li[3]/a"));
						click.click();
						Thread.sleep(2000);
						U.log("click success");
						html = html + driver.getPageSource();
					}catch(Exception e){
						U.log("Click failed");
//						U.log(e.toString());
					}
					
					html = html + driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}

	}
}

