package com.shatam.b_281_300;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.*;


public class BonterraBuilders extends AbstractScrapper {
	static int j=0;
	CommunityLogger LOGGER;
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new BonterraBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/Bonterra Builders.csv", a.data().printAll());
	}

	public static String homeurl = "https://www.bonterrabuilders.com";

	public BonterraBuilders() throws Exception {
		super("Bonterra Builders", homeurl);
		LOGGER = new CommunityLogger("Bonterra Builders");
	}

	int a = 0;

	public void innerProcess() throws Exception {
		String html1 = U.getHTML(homeurl + "/new-homes-for-sale");
		U.log(html1);
		String[] commSections = U.getValues(html1, "<div class=\"communitylist\">", "<hr size=\"1\">");
		for (String commSec : commSections) {
			String commUrl = U.getSectionValue(commSec, "<a href=\"", "\"");
//			U.log(homeurl+commUrl);
			commDetails(homeurl+commUrl, commSec);
		}
		LOGGER.DisposeLogger();
	}
	
	public void commDetails(String commUrl,String commSec) throws Exception {
		//if(j == 18)
		{
			U.log(j);
			U.log("=== "+commUrl);
			String html2 = U.getHTML(commUrl);
	
			//============ Community Name ============= 
			String commName = U.getSectionValue(html2, "<div class=\"title\">","</div>");
			commName = U.getSectionValue(commName, "<h2>", "|");
			if (commName.contains("-"))
				commName = U.getSectionValue(commName, "", "-");
			commName = commName.trim();
	
			// ============= Comm Page Section ====================
	
			String page1 = U.getSectionValue(html2, "class=\"pagecontent\">","detailright rounded colored \">");
			String page2 = U.getSectionValue(html2, "class=\"detailright", "footer");
			String page3 = U.getSectionValue(html2, "<h2>Standard Features</h2>", "Amenities</h4>");
			String pagecontent = page1 + page2 +page3;
			String remove=U.getSectionValue(pagecontent, "Area Information", "Amenities");
			if(remove!=null) pagecontent=pagecontent.replace(remove, "");
			pagecontent=pagecontent.replace("Model Homes are NOW OPEN", "");
			pagecontent=pagecontent.replace("Craftsman, Charleston", "Craftsman style homes, Charleston").replace("Convenient luxury", "Convenient luxury home");
			//U.log(page1);
			// ============= Community Type  ====================
			
			String commType = U.getCommunityType(pagecontent);

			//============= Note ===================
			String notes = ALLOW_BLANK;
			notes = U.getnote(pagecontent);
	
			// ============== Address ====================
			pagecontent = pagecontent.replace("GPS Address: ", "").replace("For GPS Purposes Only: ", "");
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec = U.getSectionValue(pagecontent, "Location", "<p>");
			U.log("addSec:"+addSec);
			if (addSec.contains("streetAddress")) {
				add[0] = U.getSectionValue(addSec, "streetAddress\">", "<");
			}
			if (addSec.contains("addressLocality")) {
				add[1] = U.getSectionValue(addSec, "addressLocality\">", "<");
			}
			if (addSec.contains("addressRegion")) {
				add[2] = U.getSectionValue(addSec, "addressRegion\">", "<");
			}
			if (addSec.contains("postalCode")) {
				add[3] = U.getSectionValue(addSec, "postalCode\">", "<");
			}
			if (add[2].length()!=2) {
				add[2] = USStates.abbr(add[2]);
			}
			
			U.log(Arrays.toString(add));
			
			//============= LatLng =================== 
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String flag="False";
			String latsec = U.getSectionValue(html2, "<h2>Directions</h2>", "</div>");
			String mapurl=U.getSectionValue(latsec, "<iframe src=\"", "\"");
			U.log("mapurl::"+mapurl);
			String mapsrc=U.getHTML("https://www.bonterrabuilders.com/"+mapurl);
			U.log(U.getCache("https://www.bonterrabuilders.com/"+mapurl));
			String lat=null;
			String lng=null;
			if (mapsrc.contains("lat:")) {
				lat=U.getSectionValue(mapsrc, "lat: \"", "\"").trim();
				lng=U.getSectionValue(mapsrc, "lng: \"", "\"").trim();
			}else if (mapsrc.contains("maps?q=")) {
				//http://maps.google.com/maps?q=34.993027,-80.663944&z=8&output=embed
				String latlonSec=U.getSectionValue(mapsrc, "http://maps.google.com/", "\"");
				lat=U.getSectionValue(latlonSec, "?q=", ",");
				lng=U.getSectionValue(latlonSec, ",", "&z");
			}else{
				lat=Util.match(mapsrc, "\\d.\\d+");
				lng=Util.match(mapsrc, "-\\d.\\d+");

			}
			
			U.log(lat+lng);
			if(lat==null){
				if (add[0] !=ALLOW_BLANK || add[1] !=ALLOW_BLANK || add[2] !=ALLOW_BLANK || add[3] !=ALLOW_BLANK) {
					latlng = U.getlatlongGoogleApi(add);
					lat=latlng[0];
					lng=latlng[1];
					flag = "TRUE";	
				}
			}

			// =================== Sqft ================
			String description = U.getSectionValue(html2, "<div class=\"rounded colored\">", "<div class=\"responsive-tabs\">");
	
			String[] area = U.getSqareFeet(pagecontent+description+html2,
							"\\d{4} - \\d{4} square feet|SqFt: \\d+,\\d+|\\d+ to \\d+ square feet|\\d+,\\d+-\\d+,\\d+ sqft.|square footage from \\d,\\d+ - \\d,\\d+|\\d,\\d+ to over \\d,\\d+ square feet.|\\d{4} square feet to over \\d{4} square feet|around \\d{4} and going over \\d{4}|Square footage from \\d,\\d+ to \\d,\\d+\\+|\\d,\\d+&nbsp;square feet",
							0);
			if (area[0] == null) area[0] = ALLOW_BLANK;
			if (area[1] == null) area[1] = ALLOW_BLANK;
	
			// ============== Prices ======================
			html2=html2.replace("0&rsquo;s","0,000");
			pagecontent = pagecontent.replaceAll("0s|0's|0’s", "0,000").replace("0&rsquo;s","0,000");
			if(description==null) description = ALLOW_BLANK;
			description = description.replace("00&rsquo;s", "00's");
			description = description.replaceAll("0s|0's", "0,000");
			
			String[] Prices = U.getPrices(pagecontent+description+html2,
					"\\$\\d+,\\d+ to the \\$\\d+,\\d+|priced from the Mid \\d{3},\\d{3} to the \\d{3},\\d{3}|From the low \\d{1},\\d{3},\\d{3}|\\$\\d{3,}[,,^\\s]\\d{3,}|\\$\\d{3},\\d{3}|low \\d{1},\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|the \\d{3},\\d{3}", 0);
			if (Prices[0] == null || Prices[1] == null) {
				pagecontent = pagecontent.replace("0's", "0,000");
			}
			//U.log(description);

			// ================ Property Status ========================
			String Status = ALLOW_BLANK;
			String statusMove=U.getSectionValue(html2, "<h4>Inventory Homes</h4>", "<script src=\"/common/tableSort.js\">");

			description = description.replace("combination of luxurious", "combination of luxury homes ");
			description = description.replaceAll(" basements are now available|village|Village|branch|Branch", "");
			pagecontent = pagecontent.replaceAll("basements are now available|<h2>Amenities</h2><p>&nbsp;COMING SOON!</p></div>|branch|Branch|>Amenities</h2><p>&nbsp;COMING SOON!!</p>", "");
			Status = U.getPropStatus((pagecontent+statusMove+description+commSec).replaceAll("Model Home will be opening soon,|Quick Delivery Home|COMING SOON!</span>", ""));
			if (html2.contains("Quick Move In Homes</h4>")&& !Status.contains("Quick")) {
				if (Status.length()>2) {
					Status+=", Quick Move In Homes";
				}else{
					Status="Quick Move In Homes";
				}
					
			}
			//============ Fecting plan and quick move-in homes data ====================
			
			String combinedHomeHtml = ALLOW_BLANK;
			
				String [] homeUrlSection = U.getValues(html2, "<div class=\"tablesingle\">", "</a>");
				U.log("Home Design count=: "+homeUrlSection.length);
				int x = 0;
				for(String homeUrlSec : homeUrlSection){
					String homeUrl = U.getSectionValue(homeUrlSec, "<a href=\"", "\"");
					U.log(homeUrl);
					String homeHtml = U.getHTML(homeurl+homeUrl);
					combinedHomeHtml += U.getSectionValue(homeHtml, "<div class=\"title\"><h1>", "<form action=\"/contact-us");
					
				}
			combinedHomeHtml = combinedHomeHtml.replaceAll(" beautiful story and a half ranch| half with four|SingleFamilyResidence", "")
					.replace("3rd floor ", "3 story").replace("main floor", "1 story");
			
			//=========== Property Type ===================
			String Type = ALLOW_BLANK;
			String featuresSec=U.getSectionValue(html2, "<h2>Standard Features</h2>", "</div>");
			//U.log(combinedHomeHtml);
			Type = U.getPropType((pagecontent+description+combinedHomeHtml+featuresSec).replaceAll(" combination of luxury|luxury level finishes|Luxury Detail", "custom luxury").replaceAll("McAdenville- Manor", "MANOR SERIES"));
			//U.log("status move is \n"+description);
					
			//================== Derived Community Type ================
			String dType = ALLOW_BLANK;
			//U.log(combinedHomeHtml);
			dType = U.getdCommType((pagecontent+description+combinedHomeHtml));
			dType=dType.replaceAll("4 Story,", "");
			if(add[0].contains("*see directions"))add[0]=ALLOW_BLANK;
			
			if(add[3].isEmpty()) add[3] = ALLOW_BLANK;
			
			if((add[0]==ALLOW_BLANK||add[3] == ALLOW_BLANK)&&lat.length()>2){
				latlng[0]=lat;
				latlng[1]=lng;
				String[] addr=U.getAddressGoogleApi(latlng);
				if(add[0]==ALLOW_BLANK)add[0]=addr[0];
				if(add[3]== ALLOW_BLANK)add[3]=addr[3];
				flag="True";
			}
			if (add[0]==ALLOW_BLANK&&(add[1]!=ALLOW_BLANK&&add[2]!=ALLOW_BLANK)) {
				latlng=U.getlatlongGoogleApi(add);
				lat=latlng[0];
				lng=latlng[1];
				add=U.getAddressGoogleApi(latlng);
				notes="Add And Lat Lon taken From City And State";
				flag = "TRUE";
			}
			if(Prices[0]==null){
				Prices[0]=Prices[1]=ALLOW_BLANK;
			}
			if(Prices[1]==null){
				Prices[1]=ALLOW_BLANK;
			}
			commName =commName.replace(", North Carolina", "");
			U.log(add[3]+"=");
			
			
			if (data.communityUrlExists(commUrl)){
				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);
			data.addCommunity(commName, commUrl, commType);
			data.addLatitudeLongitude(lat,lng, flag);
			data.addPrice(Prices[0], Prices[1]);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addSquareFeet(area[0], area[1]);
			data.addPropertyType(Type, dType);
			data.addPropertyStatus(Status);
			data.addNotes(notes);
		}
		j++;
	}
}