/* @author Aditya
 * Date - 27/12/2016.
 */
package com.shatam.b_281_300;

import java.io.*;
import java.util.Arrays;

import javax.swing.text.html.HTML;

import org.apache.commons.lang.ObjectUtils.Null;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import com.shatam.b_140_149.ExtractSchellBrothers;

public class ExtracPacesetterHomes extends AbstractScrapper {
	int k = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	public int inr = 0;
	static final String BASE_URL = "https://www.pacesetterhomestexas.com";

	public ExtracPacesetterHomes() throws Exception {
		super("Pacesetter Homes", "https://www.pacesetterhomestexas.com/");
		LOGGER = new CommunityLogger("Pacesetter Home");
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtracPacesetterHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Pacesetter Homes.csv", a.data()
				.printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		String html = U.getHTML("https://www.pacesetterhomestexas.com/new-homes/texas/austin/")
				+U.getHTML("https://www.pacesetterhomestexas.com/new-homes/texas/dallas/");
		
	//	String[] comSec = U.getValues(html, "<div class=\"col-md-6 col-sm-6 mb-4 community-card oi-map-item oi-map-item-location", "View Community");
		String[] comSec=U.getValues(html, "<div class=\"col-md-6 col-sm-6 mb-4 community-card oi-map-item oi-map-item-location \"", "View Community");
		U.log("#####total comUrls :: "+comSec.length);
		LOGGER.countOfCommunity(comSec.length);
		for (String com : comSec) {
		//	U.log("comZSec"+com);
			String url= U.getSectionValue(com, "<a href=\"", "\"");
			U.log("comURL : "+url);
//			addDetails(comURL);
			addDetailsNew(url,com);
		}
		LOGGER.DisposeLogger();
	}

	int i = 0;
	
	//TODO:
	private void addDetailsNew(String comUrl,String info) throws Exception {
//		try{
		//if(i >= 22)
		{
			// ---------------------Community Url----------------------------
			//comUrl = BASE_URL + comUrl;
			
//if(!comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/valley-vista-estates/"))return;
		
			if(comUrl.contains("/new-homes-by-city/")){
				LOGGER.AddCommunityUrl("------Return-------" + comUrl);
				return;
			}
			

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("------REPEATED-------" + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			U.log(U.getCache(comUrl));
			U.log(i+"\tcommunity url:::"+comUrl);
		
			comUrl=comUrl.replace("-(rockwall-now-preselling!)", "");
			String comHtml = U.getHTML(comUrl);
			
		//	U.log("+++++++++++++++++++++"+comHtml);
			String availHomeHtml=ALLOW_BLANK;
			String availUrl =ALLOW_BLANK;
			String availHtml = ALLOW_BLANK;
			String floorurls[]=U.getValues(comHtml, "<div class=\"col-lg-4 col-md-6 mb-4 plan-card portico\">", "</div>");
			if(floorurls.length == 0)floorurls=U.getValues(comHtml, "<div class=\"col-lg-4 col-md-6 mb-4 plan-card ", "</div>");
			for(String furls:floorurls) {
				
				furls=U.getSectionValue(furls, " <a href=\"", "\"");
				U.log("floorUrl :"+furls);
				availHtml =U.getHTML(furls);
				
				if(availHtml!=null)
					availHomeHtml = availHomeHtml+ U.getSectionValue(availHtml, "<div class=\"container\">", "<div class=\"community")
						+U.getSectionValue(availHtml, "<div class=\"container\">", "<a name=\"elevations");
				
			}
		
			//====== Quick Data =======
			String quickData = ALLOW_BLANK;
			String[] quickSec = U.getValues(comHtml, "<div class=\"card card-block\">", "</a>");
			for(String quick : quickSec) {
				String qUrl=ALLOW_BLANK;
				qUrl = U.getSectionValue(quick,"<a href=\"", "\"");
				U.log("quick url::"+qUrl);
				qUrl=qUrl.trim();
				U.log(qUrl.isEmpty());
				if(!(qUrl.isEmpty()))
				  quickData += U.getSectionValue(U.getHTML(qUrl), "<a name=\"overview\"", "<div class=\"community photos");
			}
			
//			U.log(info);
			// ---------------------Community Name----------------------------
			String comName = U.getSectionValue(comHtml, "<h1 class=\"name\">", "</h1>").replace("Woodridge - Sold Out!", "Woodridge");
			if(comName==null) {U.log("Info"+info);
				comName=U.getSectionValue(info, "class=\"card-title\">", "<");
			}
			comName =comName.replace("Woodridge - Sold Out!", "Woodridge").replaceAll("- Only Two Quick Move-In Opportunities Available!| - \\d+ Inventory Homes Coming Soon!|- COMING 2022!|- Sold Out!|- New Model Now Open!| - FINAL OPPORTUNITIES!|- New Model!|- Coming Soon!| -Now Selling!|Twinhomes| - Models Now Open!| - Final Opportunities!| - Now Pre Selling!|- COMING SOON!", "");
			comName=comName.replaceAll("- Interest List Closed|- SOLD OUT!", "");
			U.log("comName: "+comName);

			
			String[] sqftSec = U.getValues(comHtml, "<a href=\"https://my.matterport.com", "\"");
			
			String imgSqft = ALLOW_BLANK;
/*			for(String imgUrl : sqftSec ) {
				
				imgUrl = "https://my.matterport.com"+imgUrl;
				U.log(imgUrl);
				try {
					if(imgUrl.contains("show/?m=8afmTb34mE2")) continue;
				imgSqft += U.getSectionValue(U.getHTML(imgUrl), "<title>", "</title>");
				}catch (Exception e) {
					// TODO: handle exception
				}
				
			}*/
			
			
			// ---------------------Community SQFT----------------------------
			String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
			imgSqft=imgSqft.replaceAll("2.5 baths, 1,728 sq. ft", "");
			String[] sqft = U.getSqareFeet(comHtml  + availHomeHtml ,
					"\\d,\\d{3} Sq.Ft.|\\d,\\d{3} sq\\. ft|\\d{4} Sq. Ft|\\d,\\d{3} Sq.Ft|SqFt</span><span class=\"IDX-text\">\\s*\\d,\\d{3}", 0);

			minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("minSqFeet: "+minSqFeet+"\tmaxSqFeet: "+maxSqFeet);

			// ---------------------Community Price----------------------------

			String[] remSec = U.getValues(comHtml, "Find a Neighborhood</a>","Customer Service"); // Common Section
			String detailsHtml = comHtml;
			for (String sec : remSec) {
				detailsHtml = detailsHtml.replace(sec, "");
			}
			
			String latitude = ALLOW_BLANK;
			String longitude = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String note = ALLOW_BLANK;
			note = U.getnote(comHtml);
			String[] latLong = { latitude, longitude };

			// ---------------------Community Address----------------------------
			latitude = U.getSectionValue(info, "data-latitude=\"", "\"");
			longitude = U.getSectionValue(info, "data-longitude=\"", "\"");
			
			String addsec1=U.getSectionValue(info, "<div class=\"community-card card map\">", "  <div class=\"from-the-statement\">");
			System.out.println("***************************"+addsec1);
			if(addsec1!=null) {
				addsec1=U.getSectionValue(addsec1, " <div class=\"info\">", "</div");
				addsec1=addsec1.replace("<br/>", ",");
				add=U.getAddress(addsec1);
			}
			U.log("Addser0"+Arrays.toString(add));
			if (add[0] != ALLOW_BLANK && latitude == null) {
				if(latLong[0] == ALLOW_BLANK || latLong[0] == null){
					U.log("helllo in here:::::::");
					latLong = U.getlatlongGoogleApi(add);
					if(latLong == null)latLong = U.getlatlongHereApi(add);
					geo = "TRUE";
				}
				latitude=latLong[0];
				longitude=latLong[1];
				
			}
			if (add[0] == ALLOW_BLANK && latitude != ALLOW_BLANK) {
				U.log("helllo in here2:::::::");			
				add = getAddress(latLong);
				geo = "TRUE";
			}
			if(latitude==null&&add[0]!=ALLOW_BLANK) {
				latLong=U.getlatlongGoogleApi(add);
				geo="True";
			}
			
			U.log("lattitude -" + latitude + " longitute:- " + longitude);
			latLong[0]=latitude;
			latLong[1]=longitude;
			
			
			
			if(add==null)add = new String[]{ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
			
			if(comUrl.contains("/new-homes/texas/dallas/green-meadows/")) {
				add[1]="Celina";
				add[2]="TX";
				add[3] = "75009";
				latLong  = getLatLong(add);
				add = getAddress(latLong);
				
				geo="True";
				note="Address Taken From City & State";
			}
			if(comUrl.contains("/new-homes/texas/dallas/town-park")) {
				add[1]="Princeton";
				add[2]="TX";
				add[3] = "75407";
				latLong  = getLatLong(add);
				add = getAddress(latLong);
				geo="True";
				note="Address Taken From City & State";
			}
			if(comUrl.contains("new-homes/texas/dallas/lake-park-villas/")) {
				add[1]="Wylie"; 
				add[2]="TX";
				add[3] = "75098";
				latLong  = getLatLong(add);
				add = getAddress(latLong);
				geo="True";
				note="Address Taken From City & State";
			}
			
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/brooklands/")) {
				add[1]="Hutto";
				add[2]="TX";
				latLong=getLatLong(add);
//				if(latLong!=null) {
//					add=U.getAddressGoogleApi(latLong);
				add=getAddress(latLong);
					geo="True";
				}
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/grande-estates/")) {
				add[1]="Bertram";
				add[2]="TX";
				add[3]="78605";
				add=getAddress(latLong);
				
			}
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/dallas/enclave-at-meadow-run-coming-soon/"))
			{
				add[0]="3310 Bear Creek Dr";
				add[1]="Melissa";
				add[2]="TX";
				add[3]="75454";
				latLong=U.getlatlongGoogleApi(add);
				//add=U.getAddressGoogleApi(latLong);
				geo="True";
			}
			
			
			if(add[2].contains("Aubrey")) {
				add[0] = "5580 US-377";
				add[1] = "Aubrey";
				add[2] = "TX";
				add[3] = "76227";
			}
			
			U.log("Add:::"+Arrays.toString(add));
			add[0] = add[0].replaceAll("Home Address\\s*The Campania model is located at, ", "");
			U.log("Address : " +Arrays.toString(add));
		//	U.log("Address::"+addsec1);
			
			// ---------------------Community Details----------------------------
			String propType = ALLOW_BLANK;
			String propStatus = ALLOW_BLANK;
			String comType = ALLOW_BLANK;
			String drivTpye = ALLOW_BLANK;
			detailsHtml=detailsHtml.replaceAll("The Children's Courtyard|Courtyard Homes Coming Soon|Attached Apartment Restroom|apartment-to-home|Brooklands Model Home Attached Apartment|saddle-creek-courtyard-homes|crosswinds-courtyard-homes|Courtyard Homes in Saddle Creek are sold out|Courtyard Homes Coming Soon|Quest Apartments|Courtyard Homes in Crosswinds","").replace("one and two story", " 1 Story  2 Story ")
					.replace("Craftsman Floor Plans", "Craftsman style");
//			U.log("MMMP"+Util.matchAll(detailsHtml, "[\\w\\W\\s]{50}Courtyard[\\w\\W\\s]{50}", 0));
			//U.log("Detailshtml"+detailsHtml);
			propType = U.getPropType((detailsHtml.replace("Twinhome Floor Plans</button>", "Twin Homes Floor Plans</button>").replaceAll("Quest Apartments|Courtyard Homes in Crosswinds|-Farmhouse|New Townhomes|-patio","") + U.getNoHtml(availHtml +availHomeHtml)).replaceAll("-Farmhouse|New Townhomes|'hoa'|apartment-to-home| Apartment to Home|Garage Apartment|title='Saddle Creek Twinhomes|addlecreek-twinhomes", "").replaceAll("-\\d-PLEX-|\\d-PLEX Elevation", ""));
			
			
			U.log("property type "+propType);
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/grande-estates/"))propType="Craftsman Style Homes, Homeowner Association";
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/sorento/"))propType="Craftsman Style Homes, Homeowner Association";
			//====================== Property Status ======================
			detailsHtml = U.removeSectionValue(detailsHtml, "<head>", "</head>");
			
			String[] remove = U.getValues(detailsHtml, "<div class=\"pum-content popmake-content\">", "</div>");
			
			for(String rem : remove)
				detailsHtml = detailsHtml.replace(rem, "");
			
			String[] remove1 = U.getValues(detailsHtml, "class=\"pum-title popmake-title\">", "</div>");
			
			for(String rem : remove1)
				detailsHtml = detailsHtml.replace(rem, "");

			detailsHtml = detailsHtml.replace("New phase is coming soon", "New phase coming soon")
					.replaceAll("move-in ready by 2022!|See New Homes Coming Soon|currently do not have any move-in ready homes|No Quick Move-in Homes|NO QUICK MOVE-IN HOMES|ready for move-in roughly|Quick Move-Ins</option>|ACRE LOTS AVAILABLE|Village at Manor Commons - COMING SOON!|Star Ranch - COMING SOON|Coming Soon!,|Coming soon!|title='.*'|OPEN (TO WALK|to walk)|WE ARE SOLD|this summer, this new|are currently sold out. They will be available again ", "")
					.replace("(coming soon", "")
					.replaceAll("class=\"pum-title popmake-title\">.*<|Marbella - COMING|<div class=\"card-banner\">Coming Soon!</div>|Portico Homes Coming", "");
//			U.log("MM<"+Util.match(detailsHtml,"New Townhomes Coming Soon"));
			propStatus = U.getPropStatus(detailsHtml.replaceAll("MODEL HOME OPENING LATE 2022|Learn More about your future home at Easton Park, Move-In Ready|More Homes Coming Soon!\\s*</div>|Courtyard Homes Coming Soon|New Models Now Open|are currently sold out|but we have more coming soon|Courtyard Homes are sold out|are currently sold out, but we have||More Homes Coming Soon!", "").replace("for sale - coming soon!", "").replace("Phase 2 is COMING SOON", "Phase 2 COMING SOON"));
//			U.log("MM<"+Util.match(detailsHtml,"New Homesites Coming Soon"));

			U.log("propStatus====="+propStatus);
//			U.log("<<<<<<<<<<<< "+Util.matchAll(detailsHtml,"[\\s\\w\\W]{50}Coming Soon[\\s\\w\\W]{30}", 0));
//            if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/center-45/"))propStatus="Coming Soon, New Townhomes Coming Soon";
			 
			
			
			comType = U.getCommType(detailsHtml.replace("Resort Pool", "").replace("|  Greenbelt  |", "|  Green Community  |"));
//			U.log("<<<<<<<<<<<< "+Util.matchAll(detailsHtml,"[\\s\\w\\W]{50}greenbelt[\\s\\w\\W]{30}", 0));


			drivTpye = U.getdCommType(comName+(detailsHtml + availHomeHtml +  quickData).replaceAll("ranch|Ranch",""));//.replace("story 3", "2 story"));

			
			U.log("derived property-->"+drivTpye);
			
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/dallas/lake-park-villas/"))drivTpye=drivTpye.replace("1 Story, ","");
			//prices
			detailsHtml = detailsHtml.replaceAll("0s\\)</a>", "");
			String priceHtml = detailsHtml.replaceAll("0s|0's", "0,000");
			info=info.replaceAll("0s|0's", "0,000");
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			if(availHomeHtml != null)
				availHomeHtml = availHomeHtml.replaceAll("sq. ft. - \\$\\d{3},\\d{3}</p><br />", "sq. ft.");
			
			String[] price = U.getPrices(priceHtml +   availHomeHtml +info,
					"\\$\\d{3},\\d{3}|", 0);
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			comName = comName.replace("’s", "");
			
//			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/trace/")) {maxPrice="$301,255"; }
		
			if(comUrl.contains("https://pacesetterhomestexas.com/new-home-communities/avalon-78660"))
				drivTpye="1.5 Story,"+drivTpye;
		
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-home-communities/sun-chase-78617/")) propStatus = "Coming Soon"; //from reg pg coming soon comm. section
			U.log("Property type:::::"+propType);
			if(comHtml.contains("<button type=\"button\" class=\"btn btn-secondary spec\">Quick Move-Ins</button>")) {
				if(propStatus.length()>2 && !propStatus.contains("Move")) {
					propStatus=propStatus+", Quick Move-Ins";
				}
				else if(!propStatus.contains("Move")){
					propStatus="Quick Move-Ins";

				}
			}
			if(comHtml.contains("plan-card craftsman") && !propType.contains("Craftsman")) {
				if(propType.length()<1)propType="Craftsman Style Homes";
				else propType = "Craftsman Style Homes, "+propType;
			}
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/dallas/aubrey-creek-estates/")){
				if(propType.length()<1)propType="Traditional Homes";
				else propType = "Traditional Homes, "+propType;
			}
			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/trace/"))propType="Homeowner Association";
			
			propStatus=propStatus.replace("New Phase Coming Soon, New Homesites Coming Soon, Coming Soon, Sold Out", "New Phase Coming Soon, New Homesites Coming Soon, Sold Out");
			propStatus = propStatus.replace("Currently Sold Out, Sold Out", "Sold Out").replace("Now Selling, Currently Sold Out", "Now Selling").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");

			if(comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/star-ranch/")) minSqFeet = "2230";
			propStatus=propStatus.replace("Sold Out, Sold-out", "Sold Out").replace("New Phase Coming Soon, Sold Out, New Homesites Coming Soon, Coming Soon", "New Phase Coming Soon, Sold Out, New Homesites Coming Soon");
			comName=comName.replace(" - Now Selling!", "").replace(" - New Models Now Open!", "").toLowerCase();
			if(comUrl.contains("dallas/lake-park-villas/"))comName="Lake Park";
			propStatus=propStatus.replace("New Phase, Sold Out, Quick Move-in", "Quick Move-in").replace("New Homesites Coming Soon, Coming Soon", "New Homesites Coming Soon");
			if(comUrl.contains("texas/austin/marbella/"))minSqFeet="2,477";
			
			
			
			data.addCommunity(comName.replace("Villas", ""), comUrl, comType);
			
			data.addAddress(add[0].trim(), add[1], add[2].trim(), add[3]);
			data.addSquareFeet(minSqFeet, maxSqFeet);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLong[0], latLong[1], geo);
			data.addPropertyType(propType, drivTpye);
			data.addPropertyStatus(propStatus.replace("Sold Out, Coming Soon", "Sold Out").replace("Currently Sold Out, Sold Out", "Sold Out"));
			data.addNotes(note);
		}
		i++;
//		}catch(Exception e){}
		}

		private String[] getLatLong(String add[]) throws Exception{
			String[] latLong=U.getlatlongGoogleApi(add);
			if(latLong == null)latLong = U.getlatlongHereApi(add);
			return latLong;
		}
		
		private String[] getAddress(String latLong[]) throws Exception{
			
			String[] add=U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			return add;
			
		}
		
		private void addDetails(String comUrl) throws Exception {
//			if( i >= 20 && i<= 40)
			{
				// ---------------------Community Url----------------------------
				//comUrl = BASE_URL + comUrl;
				

//				if(!comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/dallas/parks-at-legacy/"))return;
//				if(!comUrl.contains("https://www.pacesetterhomestexas.com/new-homes/texas/austin/marbella/"))return;
				if (data.communityUrlExists(comUrl)) {
					LOGGER.AddCommunityUrl("------REPEATED-------" + comUrl);
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);

				U.log(U.getCache(comUrl));
				U.log(i+"\tcommunity url:::"+comUrl);
				
				comUrl=comUrl.replace("-(rockwall-now-preselling!)", "");
				String comHtml = U.getHTML(comUrl);
				
			//	U.log("+++++++++++++++++++++"+comHtml);
				String availHomeHtml=ALLOW_BLANK;
				String availUrl =ALLOW_BLANK,floorUrl = ALLOW_BLANK;
				String floorHtml = ALLOW_BLANK;
				String availHtml = ALLOW_BLANK;
				String headerSec = U.getSectionValue(comHtml, "cphMainMenu_T1A59EC58018_ctl00_ctl00_ctl00_ctl00_ctl07_childNodesContainer", "</div>");
//				U.log(headerSec);
				String comHeader = U.getSectionValue(headerSec, comUrl.replace("https://pacesetterhomestexas.com", ""), "</ul>");
//				U.log(comHeader);
				if(comHeader!=null){
				for(String navUrl : U.getValues(comHeader, "<a href=\"", "\"")){
					U.log(":::::::::::::::::"+navUrl);
					if(navUrl.contains("available-homes")) {
					availHtml = U.getHTML("https://pacesetterhomestexas.com"+navUrl);
					U.log("https://pacesetterhomestexas.com"+navUrl);
					if(availHtml.contains("Object moved to")) {
						availHtml=U.getHTML(U.getSectionValue(availHtml, "<a href=\"", "\""));
					}
					}
					if(navUrl.contains("floor")){
						if(navUrl.contains("http:"))floorHtml = U.getHTML(navUrl);
						else floorHtml = U.getHTML("https://pacesetterhomestexas.com"+navUrl);
					}
						
				}
				}
//				U.log("availhtm : "+floorHtml);

				if(availHtml==ALLOW_BLANK && comHtml.contains("View Available Homes</a>")){
					availHtml = U.getHTML("http://www.pacesetterhomestexas.idxbroker.com/i/"+U.getSectionValue(comHtml, "href=\"http://www.pacesetterhomestexas.idxbroker.com/i/", "\""));
				}
				if(floorHtml==ALLOW_BLANK ){
					floorHtml = U.getHTML(comUrl+"/floor-plans");
				}
				U.log("----http://www.pacesetterhomestexas.idxbroker.com/i/"+U.getSectionValue(comHtml, "href=\"http://www.pacesetterhomestexas.idxbroker.com/i/", "\""));

				
				if(comUrl.contains("anna-town-square"))
				{
					floorHtml = U.getHTML("https://www.pacesetterhomestexas.com/new-home-communities/anna-town-square/floor-plans");
				}
				

				// ---------------------Community Name----------------------------
				String comName = U.getSectionValue(comHtml, "<title>", "title>");
				comName = U.getSectionValue(comName, ":", "<").trim();
				U.log(comName);

				// ---------------------Community SQFT----------------------------
				String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml + floorHtml + availHtml,
						"\\d+ Sq. Ft|SqFt</span><span class=\"IDX-text\">\\s*\\d,\\d{3}", 0);
				minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

				// ---------------------Community Price----------------------------

				String[] remSec = U.getValues(comHtml, "Find a Neighborhood</a>","Customer Service"); // Common Section
				String detailsHtml = comHtml;
				for (String sec : remSec) {
					detailsHtml = detailsHtml.replace(sec, "");
				}
				
				String latitude = ALLOW_BLANK;
				String longitude = ALLOW_BLANK;
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String geo = "FALSE";

				// ---------------------Community Address----------------------------
				latitude = U.getSectionValue(comHtml, "var lat = \"", "\"");
				longitude = U.getSectionValue(comHtml, "var lng = \"", "\"");
				
				String addsec1=U.getSectionValue(comHtml, "<h3>Model", "View");
				if(addsec1==null) {
					U.log("hrllo1  ");
					 addsec1=U.getSectionValue(comHtml, "Model Home Address", "View");
				}
				if (addsec1==null) {
					U.log("hrllo2  ");
					addsec1=U.getSectionValue(comHtml, "Address</h3>", "</p>");
				}
//				System.out.println("***************************"+addsec1);
				
				U.log("lattitude -" + latitude + " longitute:- " + longitude);
				String[] latLong = { latitude, longitude };

				comHtml =comHtml.replaceAll("<h2>Coming Soon!</h2> <p>|<h3>Now Open!</h3>\n" + 
						"<p>", "Address</h2> <p>").replace(" Home Address</h3>", "").replace("Opening Saturday, June 2nd!", "");
				
			
				String addsec = U.getSectionValue(comHtml, "Address</h2> <p>", "(");
				if(addsec==null) {
					addsec=U.getSectionValue(comHtml, "<h3>Model Home Address<br />", "(");
					if(addsec==null) {
						addsec=U.getSectionValue(comHtml, "</span></strong></span><br />","</h3>");
					}
					U.log("ffffff"+addsec);
					if(addsec!=null)
					addsec=U.getNoHtml(addsec.replace("Manor, ", ",Manor, "));
				}
				if(comUrl.contains("https://www.pacesetterhomestexas.com/new-home-communities/marbella-78641")) {
					addsec=U.getSectionValue(comHtml, "Visit the model:</span><br />","</strong></div>").replace("<br />", ",");
				}
				if(comHtml.contains("<p>Visit") || comHtml.contains("<h3>Visit") || comHtml.contains("<h2>Model Home") || comHtml.contains("h2>New Model")) {
					
					U.log("hrllo");
					addsec=U.getSectionValue(comHtml, "<h3>Visit Model Home:</h3>","</p>");
					if(addsec==null) {
						addsec = U.getSectionValue(comHtml, "<p>Visit our model home ","</p>");
					}
					if(addsec==null)
					{
						addsec =  U.getSectionValue(comHtml, "<h2>Model Home Now Open!</h2>","</p>");
					}
					if(addsec==null)
					{
						addsec =  U.getSectionValue(comHtml, "<p>Come visit us at","</p>");
					}
					if(addsec!=null)
					{
						addsec = addsec.replace("in Valley Vista Estates:<br />|our brand new model, located at&nbsp;<br />", "").replace("<br />", ",");
					}
					
				}
				U.log("ggggggggggg   "+addsec);
				if(addsec==null && addsec1!=null) {
					addsec=U.getSectionValue(addsec1,"<p>","(");
					if(addsec!=null) {
						addsec=addsec.replace("&nbsp;","").replace(" TX.",", TX.");
					}
				}
				
				if(addsec==null&&addsec1!=null){
					addsec=addsec1;
				}
				
				if (addsec != null) {
					addsec = addsec.replaceFirst("<br />", ",").replace("<p>", "").replace("Avenue ,","Avenue,").replace("Drive ,","Drive,").replaceAll("Home Address|The Campania model is located at,", "");
					if (addsec.contains("By Appointment Only")
							| addsec.contains("	"))
						addsec = ALLOW_BLANK;
					
					if(addsec.contains("<table style=")){
						addsec = U.getSectionValue(addsec, "located at,", "</td>").replace("<br />", ",");
					}
					U.log("addSec:::::"+addsec);
					
					add = U.findAddress(addsec);
				}
				else if(comHtml.contains("The Office Model Home is located at "))
				{
					add[0] = "4600 Kind Way";
					add[1] = "Austin";
					add[2] = "TX";
					add[3] = "78725";
				}
				U.log("Address : " +Arrays.toString(add));
				
				if(add==null)add = new String[]{ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				
				if ((add[0] == ALLOW_BLANK && latitude != ALLOW_BLANK)||latitude!=null){
					U.log(latLong[0]);

					add = U.getAddressGoogleApi(latLong);
					if(add == null) add = U.getAddressGoogleApi(latLong);
					geo = "TRUE";
				}
				U.log("Add:::"+Arrays.toString(add));
				add[0] = add[0].replaceAll("Home Address\\s*The Campania model is located at, ", "");
				
			//	U.log("Address::"+addsec1);
				
				// ---------------------Community Details----------------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String comType = ALLOW_BLANK;
				String drivTpye = ALLOW_BLANK;
				String note = ALLOW_BLANK;
				
				//---------Available home Data------------
				String allAvailHomesData = ALLOW_BLANK;String[] availHomeUrls= {};
				if(availHtml!=null) {
					availHtml=U.getSectionValue(availHtml, "<div class='sfContentBlock'>", "<div id=\"IDX-resultsFooter\"");
					if(availHtml!=null)
					availHomeUrls = U.getValues(availHtml, "<div class=\"IDX-resultsPhoto\"><a href=\"", "\"");
				}
				
				U.log("availHomeUrls :: "+availHomeUrls.length);
				
				int x=0;
				for(String availHomeUrl : availHomeUrls ){
					x++;
					U.log("availHomeUrl : "+availHomeUrl);
					
					availHomeHtml = U.getHTML(availHomeUrl);
					allAvailHomesData += U.getSectionValue(availHomeHtml, "<h1>Property Details</h1>", "Property listed by Dennis Ciani");
					
					//if(x==3)break;
				}
				allAvailHomesData = allAvailHomesData.replace("Living/Den, Loft", "Living/Den, Loft Homes ").replaceAll("Former model home REDUCED from \\$\\d{3},\\d{3}", "");
				//U.log("++++++++++"+availHtml);
				propType = U.getPropType(detailsHtml.replace("-patio","") + U.getNoHtml(floorHtml + availHtml +allAvailHomesData));
				U.log("property type "+propType);
				
				//====================== Property Status ======================
				detailsHtml = detailsHtml.replaceAll("Coming Soon!,", "").replace("(coming soon", "")
						.replaceAll("summer, this new community ", "");
//				U.log(detailsHtml);
				propStatus = U.getPropStatus(detailsHtml);
				
				String floorHtm=U.getHTML(comUrl+"/floor-plans2");
//				U.log();
				comType = U.getCommType(detailsHtml);
				
				drivTpye = U.getdCommType(comName+(detailsHtml + floorHtml + availHtml+floorHtm).replaceAll("ranch|Ranch",""));//.replace("story 3", "2 story"));
				U.log("derived property-->"+drivTpye);
				note = U.getnote(comHtml);
				//prices
				detailsHtml = detailsHtml.replaceAll("0s\\)</a>", "");
				String priceHtml = detailsHtml.replaceAll("0s|0's", "0,000");
				
				
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				//From mid $300s
				U.log(Util.match(allAvailHomesData, ".*283.*"));
				String[] price = U.getPrices(priceHtml + floorHtml + availHtml+allAvailHomesData,
						"\\$\\d{3},\\d{3}", 0);
				//From\\s*\\[a-z]\\s*\\$\\d{3}\\d{3}|From\\s*\\$\\d{3}\\d{3}|From\\s\\$\\d{3}\\d{3}|Listing Price</span><span class=\"IDX-text\">\\$\\d{3},\\d{3}
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

				comName = comName.replace("’s", "");
				
				if(comUrl.contains("https://pacesetterhomestexas.com/new-home-communities/hawkes-landing-78641"))
				{
					add[0]="316 South Brook Drive";
					geo="False";
				}
		/*		
				if(comUrl.contains("https://pacesetterhomestexas.com/new-home-communities/avalon-78660"))
					drivTpye="1.5 Story,"+drivTpye;
		*/		
				if(comUrl.contains("https://www.pacesetterhomestexas.com/new-home-communities/sun-chase-78617/")) propStatus = "Coming Soon"; //from reg pg coming soon comm. section
				U.log("Property type:::::"+propType);
propStatus=propStatus.replace("Sold Out, Sold-out", "Sold Out").replace("New Phase Coming Soon, Sold Out, New Homesites Coming Soon, Coming Soon", "New Phase Coming Soon, Sold Out, New Homesites Coming Soon");
			
//propStatus=propStatus;


data.addCommunity(comName.replace("Villas", ""), comUrl, comType);
				data.addAddress(add[0].trim(), add[1], add[2].trim(), add[3]);
				data.addSquareFeet(minSqFeet, maxSqFeet);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(latitude, longitude, geo);
				data.addPropertyType(propType, drivTpye);
				data.addPropertyStatus(propStatus.replace("Sold Out, Coming Soon", "Sold Out").replace("Currently Sold Out, Sold Out", "Sold Out").replace("Currently Sold Ou", "Sold Out"));
				data.addNotes(note);
			}
			i++;
			}

}