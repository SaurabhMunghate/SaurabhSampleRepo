/**
 * @modify Sawan
 * @date: 7/11/2017
 * 
 */
package com.shatam.b_281_300;

import java.util.ArrayList;
import java.util.Arrays;

import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.b_281_300.ExtractBrandywineHomes;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBrandywineHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String BASEURL = "https://www.brandywine-homes.com/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractBrandywineHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Brandywine Homes.csv", a.data().printAll());

	}

	public ExtractBrandywineHomes() throws Exception {

		super("Brandywine Homes", "https://www.brandywine-homes.com/");
		LOGGER = new CommunityLogger("Brandywine Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		String basehtml = U.getHtml("https://www.brandywine-homes.com/neighborhoods/", driver);
		String section = U.getSectionValue(basehtml, "</script><h2>", "<div id=\"map_canvas");

		String vals[] = U.getValues(basehtml, "regionArray[", "});");

		U.log("vals:::::::::" + vals.length);

		for (String val : vals) {
//U.log("{{{{{{{{{{{{{{{{{{{{{{"+val+"\n");
			String url = U.getSectionValue(val, "web: \"", "\"");

			String name = U.getSectionValue(val, "title: \"", "\"");
			url = url.replace("http:", "https:");
			name = name.replace("Villas", "").replace("RTHM", "Rthm");
			U.log("url::::" + url);
			String regStatus = ALLOW_BLANK;
			// ---------statusfromregionpage----------
//			if (val.contains("nowselling-normal"))
//				regStatus = "Now Selling";
//			else if (val.contains("comingsoon-normal"))
//				regStatus = "Coming Soon";
			// U.log(regStatus);

//			try {
				addDetails(val, url, name, regStatus);
//			} catch (Exception e) {}
		}

		LOGGER.DisposeLogger();
		driver.quit();
		// try{driver.quit();}catch(SessionNotCreatedException e){}

	}

	// TODO ::
	public void addDetails(String comsec, String url, String communityName, String regStatus) throws Exception {
//		 try{
//		if (!url.contains("https://www.brandywine-homes.com/communities/rthm/"))return;
		
//		if(j>=2)
		{
			String html = U.getHtml(url.replace("http:", "https:"), driver);
			U.log(":::::::::::::: " + j+":::::::::::");
			U.log("community URL: " + url);
//			 U.log(comsec);

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "----------------------- Repeat");
				return;
			}
			
			if(url.contains("https://www.brandywine-homes.com/find-your-home/citra/")) {
				LOGGER.AddCommunityUrl(url+ "---------------------------------REDIRECTING TO MAIN PAGE");
				return;
			}
			
			
			LOGGER.AddCommunityUrl(url);
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, url, driver);
			U.log("Total Units : "+units);
			// ---------------------------------------------------------

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			String geo = "False";
			String note = ALLOW_BLANK;
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };

			// ==============Visit-Us ==================
			String visitUsHtml = null, contactUsHtml=null;
			if (!url.endsWith("/"))
				visitUsHtml = U.getHtml(url + "/visit-us/", driver);
			else
				visitUsHtml = U.getHtml(url + "visit-us/", driver);
			String contactUs=null;
			
			if (!url.endsWith("/"))
				contactUsHtml= U.getHtml(url + "/conntact-us/", driver);
			else
				contactUsHtml = U.getHtml(url + "conntact-us/", driver);

			// ============ Address =====================
			String street = ALLOW_BLANK, city = ALLOW_BLANK;
			String state = ALLOW_BLANK, zip = ALLOW_BLANK;
			html = U.removeComments(html);
			String addSec = ALLOW_BLANK;
			if (addSec == null||addSec==ALLOW_BLANK)
				addSec = U.getSectionValue(html, "Sales Center</h2>", "</h3>");
			if(addSec==null) 
				addSec=U.getSectionValue(html, ">Sales Center", "</h3>");
			
			// if(addSec == null)
			// addSec = U.getSectionValue(html, "<h5 class=\"type-primary\">", "</h5>");
			// if(addSec == null)
			// addSec = U.getSectionValue(html, "class=\"twhite\">", "</h5>");
			
//			if(addSec.contains("<br>"))
//				addSec=addSec.replace("<br>", ",").replace(" Coming Soon", "");
			U.log("addSec1 ==" + addSec);
			if (addSec != null) {
				addSec = addSec.replaceAll(
						"<h5 class=\"tbrn\">|Call \\d{3}-\\d{3}-\\d{4}|<h5 class=\".*?\">|<a href=\".*?\">|<br>", "")
						.replace("Telegraph Road", "Telegraph Road,").replace("&nbsp;", " ").replace("<br>", ",").replace("Coming Soon</h2>", "").replace("<br />", ",")
						.replaceAll("4747 Daisy Ave.", "4747 Daisy Ave,")
						.replaceAll("</a>\\s*Call \\d+-\\d+-\\d+</a>", "").replace("1007 E. Victoria St.Carson, CA 90746", "1007 E. Victoria St.,Carson, CA 90746");

				U.log("addSec2 ==" + addSec.replace("1007 E. Victoria St.Carson, CA 90746", "1007 E. Victoria St.,Carson, CA 90746")
				.replace("St. Carson", "St, Carson"));

				addSec = U.formatAddress(addSec);
				// U.log(addSec);

				String vals[] = addSec.replace("St.Baldwin", "St., Baldwin").replace("St. Carson", "St, Carson").split(",");
				U.log(Arrays.toString(vals) + "Values");
				vals[0]=vals[0].replace(" Coming Soon", "");
				if (addSec == ALLOW_BLANK) {
					latLong[0] = U.getSectionValue(comsec, "lat: ", ",");
					latLong[1] = U.getSectionValue(comsec, "lng: ", ",");
					add = U.getAddressGoogleApi(latLong);
					geo="True";
					// addSec=street+","+city+","+state+","+zip;

				} else if(vals.length==3){

					add[0] = vals[0].trim();
					add[1] = vals[1].trim();
					add[2] = Util.match(vals[2], "\\w{2}").trim();
					add[3] = Util.match(vals[2], "\\d{5}").trim();
				}
				U.log("Add:::" + Arrays.toString(add));
			} 
//			else if (!url.contains("/neighborhoods/")) {
//				addSec = U.getSectionValue(html, "class=\"twhite\">", "</a>").replaceAll("&nbsp;", "")
//						.replaceAll("<br />", ",");
//				U.log("addSec3==" + addSec);
//				if (addSec != null) {
//					addSec = addSec.replaceAll(
//							"<h5 class=\"tbrn\">|Call \\d{3}-\\d{3}-\\d{4}|<h5 class=\".*?\">|<a href=\".*?\">", "")
//							.replace("&nbsp;", " ").replace("<br />", ",");
					U.log("addSec4==" + addSec);

					if (addSec != null) {
						addSec = addSec.replace("<br>", ",").replace("CA9", "CA 9");
						addSec = U.formatAddress(addSec);
						String vals[] = addSec.split(",");
						U.log(vals.length);
						if (vals.length >= 3) {
							add[0] = vals[0].trim();
							add[1] = vals[1].trim();
							add[2] = Util.match(vals[2], "[A-Z]{2}").trim();
							add[3] = Util.match(vals[2], "\\d{5}").trim();
							U.log("Add:::" + Arrays.toString(add));
//						}
//					}
				}
			}
			if (addSec == null && add[0].length() < 2) {
				U.log("Hello there::::::::" + add[0]);
				addSec = U.getSectionValue(html, "<h2 class=\"neighborhood-address\">", "<");
//				U.log("addSec111==="+addSec);
				if(addSec!=null) {
				add[1] = addSec.split(",")[0];
				add[2] = addSec.split(",")[1];
				latLong = U.getlatlongGoogleApi(add);
				if (latLong == null)
					latLong = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latLong);
				if (add == null)
					add = U.getAddressHereApi(latLong);
				geo = "True";
				note = "Address Is Taken From City & State";
				}
			}
			// if(url.contains("https://www.brandywine-homes.com/neighborhoods/candlewood/")){
			// add[0] = "S Bramblebush Ave";
			// add[1] = "Whittier";
			// add[2] = "CA";
			// add[3] = "90604";
			// latLong = U.getlatlongGoogleApi(add);
			// geo = "True";
			// note = "Address Is Taken From Region Map Image";
			// }
			if (url.contains("https://www.brandywine-homes.com/neighborhoods/bradbury/")) {
				add[0] = "Mulvane St";
				add[1] = "La Puente";
				add[2] = "CA";
				add[3] = "91744";
				latLong = U.getlatlongGoogleApi(add);
				geo = "True";
				note = "Address Is Taken From Region Map Image";
			}
			if (url.contains("https://www.brandywine-homes.com/neighborhoods/palmera/")) {
				add[0] = "Badillo St";
				add[1] = "Baldwin Park";
				add[2] = "CA";
				add[3] = "91706";
				latLong = U.getlatlongGoogleApi(add);
				geo = "True";
				note = "Address Is Taken From Region Map Image";
			}
			if (url.contains("https://brandywine-homes.com/neighborhoods/carlow/")) {
				add[0] = "San Antonio Dr";
				add[1] = "Norwalk";
				add[2] = "CA";
				add[3] = "90650";
				latLong = U.getlatlongGoogleApi(add);
				geo = "True";
				note = "Address Is Taken From Region Map Image";
			}
			if (url.contains("https://brandywine-homes.com/neighborhoods/placentia/")
					|| url.contains("/neighborhoods/villena/")) {
				// add[0] = "Badillo St";
				add[1] = "Placentia";
				add[2] = "CA";
				// add[3] = "91706";
				latLong = U.getlatlongGoogleApi(add);
				if (latLong == null)
					latLong = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latLong);
				if (add == null)
					add = U.getAddressHereApi(latLong);
				geo = "True";
				note = "Address Is Taken From City & State";
			}
			if (url.contains("https://brandywine-homes.com/neighborhoods/upton/")) {
				add[1] = "Carson";
				add[2] = "CA";
				latLong = U.getlatlongGoogleApi(add);
				if (latLong == null)
					latLong = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latLong);
				if (add == null)
					add = U.getAddressHereApi(latLong);
				geo = "True";
				note = "Address Is Taken From City & State";
			}
//			if (latLong == null)
//				latLong = U.getlatlongHereApi(add);
//			
			
		
			// =========== Lat-Lng ================
			if (visitUsHtml != null) {
				
				latLong[0] = U.getSectionValue(visitUsHtml, "var lat = ", ";");
				latLong[1] = U.getSectionValue(visitUsHtml, "var lng = ", ";");

				if (latLong[0] == null||latLong[0]==ALLOW_BLANK) {
					if (U.getSectionValue(visitUsHtml, "google.maps.LatLng(", "),") != null)
						latLong = U.getSectionValue(visitUsHtml, "google.maps.LatLng(", "),").split(",");
				}
				if (latLong[0] == null||latLong[0]==ALLOW_BLANK) {
					if (U.getSectionValue(visitUsHtml, "name=\"daddr\" value=\"", "\"") != null)
						latLong = U.getSectionValue(visitUsHtml, "name=\"daddr\" value=\"", "\"").split(",");
				}

				if (latLong[0] == null ||latLong[0]==ALLOW_BLANK) {
					latLong[0] = U.getSectionValue(comsec, "lat:", ",");
					latLong[1] = U.getSectionValue(comsec, "lng:", ",");

				}
				U.log("LatLng::" + Arrays.toString(latLong));
			}

			if ((latLong[0] == null || latLong[0] == ALLOW_BLANK) && add[0].length() > 4) {
				U.log("Hello there::::::::");
				latLong = U.getlatlongGoogleApi(add);
				if (latLong == null)
					latLong = U.getlatlongHereApi(add);
				geo = "True";
			}

			if ((add[0] == null || add[0] == ALLOW_BLANK) && latLong[0].length() > 4) {
				U.log("Hello there too::::::::");
				add = U.getAddressGoogleApi(latLong);
				if (add == null)
					latLong = U.getAddressHereApi(latLong);
				geo = "True";
			}

			// if(latLong[0]==null)latLong[0]=latLong[1]=ALLOW_BLANK;

			// if(url.contains("https://brandywine-homes.com/neighborhoods/oliva/")){
			// add[0] = "Huntington Dr";
			// add[1] = "Duarte";
			// add[2] = "CA";
			// add[3]="91010";
			// latLong = U.getlatlongGoogleApi(add);
			// if(latLong == null) latLong = U.getlatlongHereApi(add);
			// geo = "True";
			// note = "Address Is Taken From Region Map Image";
			//
			// }

			// ==============Feature Html ==================
			String featureHtml = null;
			if (!url.endsWith("/"))
				featureHtml = U.getHtml(url + "/features/", driver);
			else
				featureHtml = U.getHtml(url + "features/", driver);

			// ============= FloorPlans =================
			String floorPlanHtml = null;

			if (!url.endsWith("/"))
				floorPlanHtml = U.getHtml(url + "/floor-plans/", driver);
			else
				floorPlanHtml = U.getHtml(url + "floor-plans/", driver);
			// =========== Community Page Html ===================
			String comPage = ALLOW_BLANK;
			if (!url.endsWith("/"))
				comPage = U.getHtml(url + "/community/", driver);
			else
				comPage = U.getHtml(url + "community/", driver);

			// ================= New Page =====================
			String newsHtml = null;
			if (!url.endsWith("/"))
				newsHtml = U.getHtml(url + "/news/", driver);
			else
				newsHtml = U.getHtml(url + "news/", driver);
			U.log("-->" + url + "/news/");
			// ============== Community Type ================
			html = U.removeSectionValue(html, "<section id=\"footer-boxes\" class=\"clearfix\">", "</htm");
			html = html.replaceAll("Grand Opening August|Grand Opening: August|Castella Grand Opening!", "");
			// U.log(Util.match(featureHtml, ".*gated.*"));
			comPage = U.removeSectionValue(comPage, "regionArray = [", "</script>");
			comPage = U.removeSectionValue(comPage, "<div id=\"map_canvas\"", "<script");
			// U.log(Util.match((html+comsec+comPage+featureHtml).replaceAll(" title=\"La
			// Mirada Golf Course\"><|Whittier Narrows Golf Course</a>|coveted golf course
			// views, |Townhomes with Golf Course Views in Whittier| Golf Course View
			// Townhome|;\">Candlewood Country Club &amp; Golf Course<|\"Candlewood Country
			// Club &amp; Golf Course\"|elongated", ""), ".*Golf Course.*"));
			String commType = U.getCommunityType((html + comsec + comPage + featureHtml).replaceAll(
					"Coyote Hills Golf Course|Lakewood Golf Country Club| title=\"La Mirada Golf Course\"><|elongated commodes|Whittier Narrows Golf Course</a>|Townhomes with Golf Course Views in Whittier| Golf Course View Townhome|;\">Candlewood Country Club &amp; Golf Course<|\"Candlewood Country Club &amp; Golf Course\"|elongated|Dad Miller Golf Course|newsContainerTitle\">Golf",
					""));
//			U.log("kkkkkkkkkk "+Util.matchAll(html + comsec + comPage + featureHtml, "[\\s\\w\\W]{100}Country Club[\\s\\w\\W]{100}", 0));

			// ============= Property Type ======================
			featureHtml = featureHtml.replaceAll("class=\"sub-menu soon\">Apartments|com/about/multi-family/\">Apartments</a></li>|Remarkable Craftsman, Americana, and Spanish house elevations", "");
			html = html.replaceAll("luxury at Oliva| feature luxurious", "luxury homes")
					.replace("traditional Southern California townhome ", "traditional homes Southern California townhome ")
					.replaceAll(
					"alt=\"Saddlecreek Villas Now Selling|alt=\"Candlewood Villas in Whittier Now Selling", "");
			
			String propType = U.getPropType((html + comsec + featureHtml + floorPlanHtml).replace("Farmhouse-", "Farmhouse Series").replaceAll("Luxury Townhomes|sub-menu soon\">Apartments|com/about/multi-family/\">Apartments</a></li>|fa-apartment:before|fa-apartment:after", ""));
//			U.log("mm"+Util.matchAll(html + comsec + floorPlanHtml, "[\\w\\s\\W]{30}apartment[\\w\\s\\W]{30}", 0));
			U.log("ptype: "+propType);

			// ============= Derived Type ======================
			// comPage = comPage.replaceAll("99ranch|Ranch Market|JQUERY GET FIRST", "");

			String dpType = U.getdCommType(html.replace(" JQUERY GET FIRST STORY ////////////", "") + comsec);
//			 U.log("<<<<<<<<<<<< "+Util.matchAll(comsec, "[\\s\\w\\W]{30}stroy[\\s\\w\\W]{30}", 0));
			 U.log("dddddp"+dpType);
			// ================= Property Status ========================

			comsec = comsec.replace("status: \"nowselling\",", "status: \"now selling\",").replaceAll("Anticipated Opening (.*?) 2018", "").replace("Coming Soon - Fall 2021", "Coming Soon Fall 2021")
					.replace("Coming Soon - Jan 2022", "Coming Soon Jan 2022");
			html = html.replaceAll("alt=\".*?\"", "").replaceAll(
					"Quick move-in homes at Saddle Creek in San Dimas|>Sales Center Coming&nbsp;Soon<|SADDLE CREEK SELLING FAST|sub-menu soon\">Coming Soon|Anticipated Opening (.*?) 2018|New Townhomes coming soon|close-out-at|Sales Center Now Open!|Sales Center <br> Now Open!</h4>|not closed|newsContainerTitle\">Quick move",
					"");
//			U.log(regStatus);
			if(url.contains("https://www.brandywine-homes.com/communities/carlow/")) {
				html=html.replaceAll("SADDLE CREEK IS SOLD OUT!", "");
			}else {
			html=html.replaceAll("<li class=\"sub-menu\">Now Selling|Carlow - Now Selling!|<li class=\"sub-menu\">Now Selling|Carlow - Almost Sold Out|CARLOW - NOW SELLING!|munities/carlow/\">\\s*Carlow is Sold Out|SADDLE CREEK IS SOLD OUT!", "");
			}
			
			
//			U.log("comsec :"+comsec);
			String commStatus = U.getPropStatus((comsec + html + regStatus).replace("Last Chance - Models Available", "").replace("Coming in late 2022", "coming late 2022"));
			U.log("ssssss: "+commStatus);
//			U.log("<<<<<<<<<<<< "+Util.matchAll(comsec + html + regStatus, "[\\s\\w\\W]{30}coming late[\\s\\w\\W]{30}", 0));
//			comsec=comsec.replace("Pre-Sales", "Pre Sale");
			
			//note
			note=U.getnote(comsec);
			
			U.log("note: "+note);

			html = html.replace("$400,000’s", "$400,000").replace("1 Million", "1,000,000 Million")
					.replace("low $1 million", "low $1,000,000");
			// U.log(newsHtml);
			// --prices---//
			String[] price = U.getPrices(
					html.replaceAll("\\$500,000s, coming to Anaheim|Over \\$178,000 in Included ", "") + newsHtml
							+ comsec,
					"From the Low \\$\\d{3},\\d{3}|From the Mid \\$\\d{3},\\d{3}|From the High \\$\\d{3},\\d{3}|Low \\$\\d,\\d{3},\\d{3}| from \\$\\d,\\d+,\\d+|high \\$\\d+,\\d+|low \\$(\\d,)?\\d+,\\d+|\\$\\d{3},\\d{3}",
					0);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// -----------sqreft-----------//
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html + comsec + floorPlanHtml,
					"sqft: \"\\d,\\d{3} - \\d,\\d{3}\"|Approx. \\d+ - \\d,\\d+ sq. ft.|Approx \\d,\\d+ Sq. Ft.|up to \\d,\\d+ sq. ft.|\\d,\\d{3}-\\d,\\d{3} sq. ft.|sqft: \"\\d,\\d{3}-\\d,\\d{3}\"|\\d,\\d{3} to \\d,\\d{3} sq. ft.|>\\d,\\d{3} sq. ft.<|\\d{1},\\d{3} (-|–) \\d{1},\\d{3} sq. ft|\\d{1},\\d{3} - \\d{1},\\d{3} square feet|Approx. \\d,\\d{3} (Sq. Ft|sq. ft)",
					0);
			
//			 U.log("<<<<<******* "+Util.matchAll(html + comsec + floorPlanHtml, "[\\s\\w\\W]{50}Approx[\\s\\w\\W]{50}", 0));

			
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			if(url.contains("/communities/carlow/")||url.contains("/communities/upton/") || url.contains("/communities/villena/"))dpType="1 Story, 2 Story, 3 Story";
			if(url.contains("/communities/arletta/")) {
				dpType="1 Story, 2 Story";
				if(!url.contains("/communities/arletta/"))
				commStatus = commStatus+", New Homesites Now Available";
			}
//			if(url.contains("https://www.brandywine-homes.com/communities/carson-landing/"))dpType="2 Story, 3 Story";
			// if(url.contains("http://www.palmeranewhomes.com/")||url.contains("http://www.saddlecreeksandimas.com/"))commStatus
			// = "Coming Soon"; //reg pg
			// if(url.contains("http://www.corsicabuenapark.com/")||url.contains("http://www.bradburynewhomes.com/"))commStatus
			// = "Now Selling"; //reg pg
			// ---notes-----//
			//formatting status
			
			//if(url.contains("find-your-home/the-hawthorne/"))commStatus=commStatus+", Coming Soon";
			if(url.contains("https://www.brandywine-homes.com/communities/upton/availability/")) {minPrice=ALLOW_BLANK;}
			
			commStatus = commStatus.replace("Final Homesites Now Selling, Now Selling", "Final Homesites Now Selling");
	
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName, url, commType);
			data.addAddress(add[0].replace("+", "&"), add[1].replace(".", ""), add[2].trim(), add[3]);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(commStatus);
			data.addNotes(note);

		}
		j++;
//		 }catch(Exception e){}
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comUrl.contains("https://www.brandywine-homes.com/communities/mayfield/")||comUrl.contains("https://www.brandywine-homes.com/communities/carson-landing/") ||
				comUrl.contains("https://www.brandywine-homes.com/communities/rthm/")||comUrl.contains("https://www.brandywine-homes.com/communities/verdana/")) {
			
			String mapUrl = comUrl + "availability" ;
			U.log("mapUrl: "+mapUrl);
			
			mapData = U.getHtml(mapUrl, driver);
			U.log(U.getCache(mapUrl));
			
			if(mapData.contains("class=\"lot tooltip tooltipstered")) {
				
				ArrayList<String> pins = Util.matchAll(mapData, "class=\"lot tooltip tooltipstered", 0);
				U.log("Count Pins: "+pins.size());
				totalUnits = String.valueOf(pins.size());
			}
			
		}
		
		
		return totalUnits;
	}

}
