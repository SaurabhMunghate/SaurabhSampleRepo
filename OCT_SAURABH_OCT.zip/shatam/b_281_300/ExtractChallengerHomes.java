/*
 * @autor:sahil 
 * @date : 29 Jun 2015
 */
package com.shatam.b_281_300;

import java.util.Arrays;

import javax.swing.text.html.HTML;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
//import com.sun.org.apache.regexp.internal.recompile;

public class ExtractChallengerHomes extends AbstractScrapper {
	static String BASEURL = "https://challengerhomes.com/";
	CommunityLogger LOGGER;
	WebDriver driver= null;

	int j=0;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractChallengerHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Challenger Homes.csv", a.data()
				.printAll());
	}
 
	public ExtractChallengerHomes() throws Exception {

		super("Challenger Homes", BASEURL);
		LOGGER = new CommunityLogger("Challenger Homes");
	}

	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
//		proxy.setHttpProxy("157.245.123.27:8888")
//		     .setFtpProxy("157.245.123.27:8888")
//		     .setSslProxy("157.245.123.27:8888");
//		DesiredCapabilities cap = new DesiredCapabilities();
//		driver = new FirefoxDriver(cap);

	String html=U.getHTML("https://challengerhomes.com/communities/");
	
	
//	String availHtml = U.getHTML("https://challengerhomes.com/homes");
	
	
	//U.log("html= "+html);
	//String[] urlSec=U.getValues(html, "data-container=\"body\"", "Explore Communities</a></li>");
	
	String[] urlSec=U.getValues(html, "<div class=\"CommunitiesMapList__list-item CommunitiesMapList__map-mobile-list-item branded-corners js-map-list-item\"", "View Community</div>");
	//String[] mapSec = U.getValues(html,"\"permalink\":\"",",\"address\":\"");
	String comSec = U.getSectionValue(html, "const communities", "const geoJsonItems");
	//U.log(comSec);
	int i=0;
	String mapSecs[] = U.getValues(comSec,",\"permalink\":\"","starting_price\":");
	
	for(String commsec:urlSec)
	{
		//U.log("comSec= "+commsec);
		String commURl=U.getSectionValue(commsec, "<a href=\"", "\"");
		
//		U.log("comName= "+commURl);
		String allAvailData ="";
//		for(String availhomeSec : U.getValues(availHtml, "div class=\"HomeCard_inner", "View Detail")){
//			if(availhomeSec.contains(commName)){
//				allAvailData += availhomeSec;
//			}
//		}
		for(String sec: mapSecs) {
			sec =StringEscapeUtils.unescapeJava(sec);
//			U.log(sec);
			if(sec.contains(commURl)) {
				commsec =commsec+sec;
			}
		}
//		addDetails(commName,commsec,html, allAvailData);
		addComDetails(commURl,commsec);
		//break;
	}
	LOGGER.DisposeLogger();
	}
	
	
	public void addComDetails(String comUrl,String Comsec) throws Exception {
		U.log("Community url ::::"+comUrl);
		
//		if(!comUrl.contains("https://challengerhomes.com/communities/colorado/northern-colorado/cherry-meadows/"))return;// Single Run
		
		
		if(data.communityUrlExists(comUrl)) {
					
			LOGGER.AddCommunityUrl(comUrl+"==========Reperated==============");
					return;
		}
		

		if(comUrl.contains("https://challengerhomes.com/communities/colorado/northern-colorado/mountains-edge/")) {
					
			LOGGER.AddCommunityUrl(comUrl+"==========Page Not Found==============");
					return;
		}
		
		
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml = U.getHTML(comUrl);
		
		String commName = U.getSectionValue(comHtml, "heading--h1\">", "<");
		String subName = U.getSectionValue(comHtml, "<span>Single Family Homes - ", "<");
		
		if(subName!=null)
			subName = subName.replace("&#8217;", "'");
		
		if(subName!=null && !commName.trim().equals(subName.trim()))
			commName = commName+" "+subName.trim();
		if(comUrl.contains("https://challengerhomes.com/communities/colorado/colorado-springs/skyline-ridge/"))
			commName ="Skyline Ridge";
		
		
		commName=commName.replace("&#8211;", "-");
		U.log("Comname: "+commName);
		
		String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String note=ALLOW_BLANK;
		String geo ="False";
		String addsec = U.getSectionValue(Comsec, "<div class=\"SingleCommunity__header-address-text\">", "</div>");		
		if(addsec == null) {
			
			addsec = U.getSectionValue(comHtml, "</span> — ", "</a>");
		}
		if(addsec==null) {
	      addsec=U.getSectionValue(comHtml, "https://www.google.com/maps/dir/", "/a>");
	        if(addsec!=null)
	            addsec=U.getSectionValue(addsec, "\">", "<");
	    //  addsec=U.getNoHtml(addsec);
		}
		if(addsec!=null) {
			addsec= addsec.replace("<br>", ",");
			add= U.getAddress(addsec);
		}
		if(Comsec.contains("lat\":\"")) {
			latlng[0] = U.getSectionValue(Comsec, "\"lat\":\"", "\"");
			latlng[1] = U.getSectionValue(Comsec, "\"lng\":\"", "\"");
		}
		if(latlng[0]==null || latlng[0]==ALLOW_BLANK) {
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			geo="True";
		}
		if(add[0]==null||add[0]==ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latlng);
			geo="True";
		}
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlng));
		String allHomesdata= ALLOW_BLANK;
		String plans[]= U.getValues(comHtml, "  <div class=\"preview branded-corners preview--plan\"", "View Floor Plan</div>");
		
		if(plans.length == 0)
			plans = U.getValues(comHtml, "<div class=\"preview__content\">", "View Floor Plan</span>");
			
		for(String planurl:plans) {
			planurl= U.getSectionValue(planurl, "<a href=\"", "\"");
			if(planurl == null || planurl.length() < 5)continue;
			U.log("planurl ::"+planurl);
			String homehtm=U.getHTML(planurl);
			allHomesdata += U.getSectionValue(homehtm, "<div class=\"SingleFloorPlan\">", "<div class=\"mortgage-calc_-_wrap\">") + U.getSectionValue(homehtm, "<div class=\"SingleFloorPlan\">", "Floor Plan</h2>")
			+U.getSectionValue(homehtm, "Plan Overview</strong></h2>", "</p>")
			+ U.getSectionValue(homehtm, "<div class=\"SingleFloorPlan\">", " <div class=\"SingleFloorPlan__header-contact\">")
			+ U.getSectionValue(homehtm, "<span>Starting from", "</span>");		
		}
		
		//=========================================
		 String floorQuickHomeSec[] = U.getValues(allHomesdata, "<div class=\"preview__content\">", "View Home</span>");
		 
		 for(String remove : floorQuickHomeSec) {
			 
			 if(remove!= null)
			 allHomesdata = allHomesdata.replace(remove , "");
		 }
		
		String[] sqft=U.getSqareFeet((comHtml+Comsec+allHomesdata).replace("&#8211;", "-"), "up to \\d,\\d{3} square feet|up to \\d,\\d{3} finished square feet|\\d{4} Sq. Ft|\\d,\\d{3} - 2 Sq. Ft.|\\d,\\d{3} - 1 Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|\\d{4}\\s*-\\s*\\d{4} Sq. Ft.|\\d{4} - \\d{4} Sqft|>\\d,\\d{3} – \\d,\\d{3} SF<|Max Total \\d,\\d+ SQ FT|Square Footage <span class=\"ng-binding\">\\d,\\d+ to \\d,\\d+|Max Total:</span> \\d,\\d+ SQ FT|Max SF</strong> \\d.\\d{3}|<div>\\d,\\d{3} SF</div>", 0);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}1,108[\\s\\w\\W]{30}", 0));
		
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comHtml = comHtml.replaceAll("0&#8217;s|0’s|0s|0's", "0,000");
		
		String[] price=U.getPrices((comHtml+Comsec+allHomesdata).replaceAll("\"price\":\"\\$\\d{3},\\d{3}\"|\\$\\d{3},\\d{3}\" lii=\"",""), 
				"<strong>\\$\\d{3},\\d{3}</strong>|Starting from <strong>\\$\\d{3},\\d{3}|Starting from <strong>\\$\\d{3},\\d{3}<|From the <strong>\\$\\d{3},\\d{3}<|Priced from the <strong>\\$\\d{3},\\d{3}<|\\$[0-9]{3},[0-9]{3} to \\$[0-9]{3},[0-9]{3}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+ to \\$\\d+,\\d+|\\$\\d+,\\d+ to \\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log(Util.matchAll(comHtml+Comsec+allHomesdata, ".*\\$567,900.*", 0));
		
		//propType
		comHtml = comHtml.replace("2 - 3 Levels", "2 story,3 story").replace("1 - 2 Levels", "1 story, 2 story");
		if(allHomesdata!=null)allHomesdata=allHomesdata.replaceAll("2 Level[s]|second floor ", " 2 Story").replace("Level", " story");
		String dtype=U.getdCommType(comHtml+Comsec+allHomesdata);
		
		
		String commType=U.getCommunityType(comHtml+Comsec);
		String ptype=U.getPropType((comHtml+Comsec+allHomesdata).replaceAll("salad in cottage\">|single-family[-]?|Mountain Vista Luxury Paired Patio|Northgate Patio Homes|The Reserve at North Creek Patio Homes|Trails East Patio Homes|Townhome/Patio Home|Craftsman|Paired|Compatible", ""));
		
		comHtml = comHtml.replaceAll("Now Selling New Single Family Homes In Mead|Now selling single family homes in Colorado|starting-price\">Coming", "");

		String rem = U.getSectionValue(comHtml, "<div id=\"floorplans_homes\">", "<div id=\"sitemap\">");
		if(rem!=null)
			comHtml = comHtml.replace(rem, "");
		
		//U.log("MMm"+Util.matchAll(comHtml, "[\\w\\W\\s]{40}NOW SELLING[\\w\\W\\s]{40}", 0));
		String pStatus=U.getPropStatus(comHtml.replaceAll("Now selling new single family homes in Loveland|Quick Move-In Homes</a><", ""));
		
		String quickcount = Util.match(comHtml, "<span class=\"SingleCommunity__header-homes-count\">(\\d</span> Quick Move-In Homes)",1);
	//	U.log(quickcount);
		if(quickcount==null)quickcount=ALLOW_BLANK;
		if(quickcount.equals("0</span> Quick Move-In Homes")) {
			U.log("i am changing::::");
			pStatus = pStatus.replaceAll(", Quick Move-in Homes|, Quick Move-in|^Quick Move-in Homes|Quick Move-in", "").trim().replaceAll("^,|,$", "");
		}
		if(pStatus.isEmpty()) pStatus = ALLOW_BLANK;
		U.log("+++++++++++++ "+pStatus);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}now open[\\s\\w\\W]{30}", 0));
		add[0] = add[0].replaceAll("\\(sales center coming soon\\)", "");
		if(comUrl.contains("https://challengerhomes.com/communities/chapel-heights-ascent-copy/"))commName ="The Townes At Chapel Heights";
		
		data.addCommunity(commName.replace("Chapel Heights &#8211; Discovery Collection Discovery Collection", "Chapel Heights - Discovery Collection")
				.replace("Ascent at Ventana South Ascent Collection", "Ascent at Ventana South"), comUrl, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);

		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);

		data.addPropertyType(ptype,dtype);
				
		data.addPropertyStatus(pStatus);

		data.addPrice(minPrice, maxPrice);

		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(comHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
		
	}
	public void addDetails(String commName, String commsec,String buiHtml,String allAvailData) throws Exception {
		//U.log(commsec);
	//if(j==6)
		{
					
		String commUrl=U.getSectionValue(commsec, "href=\"", "\"");
		commUrl="https://www.mychallengerhomes.com"+commUrl;
		
	//	if(!commUrl.contains("https://challengerhomes.com/communities/colorado/northern-colorado/eagle-brook-meadows/"))return;
		
		
			
		commUrl=commUrl.replace("&amp;", "&");
		
		if(commUrl.contains("https://www.mychallengerhomes.com/communities/colorado-springs/revel-at-wolf-ranch")) {
			
			LOGGER.AddCommunityUrl(commUrl+"=======Redirected============");
			return;
		}
		
		if(data.communityUrlExists(commUrl)) {
			
			LOGGER.AddCommunityUrl(commUrl+"==========Reperated==============");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		U.log("comUrl= "+commUrl);
		
		
		commName=commName.replaceAll("Luxury Paired Patio Homes|Single Family Homes|data-reactid=\"\\d+\"|>", "");
		String comHtml=U.getHtml(commUrl, driver);
		comHtml=comHtml.replace("Life Time Fitness, Villa Sport, and the YMCA ","");
		
		
		
		//latlng
		comHtml=comHtml.replace("{\"@type\":\"GeoCoordinates\",\"latitude\":38.881126,\"longitude\":-94.821048}", "");
		String latsec=U.getSectionValue(comHtml, "{\"@type\":\"GeoCoordinates\"", "}");
		U.log("latsec= "+latsec);
		String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		latlng[0]=Util.match(latsec, "\\d{2}.\\d+");
		latlng[1]=Util.match(latsec, "\\-\\d{3}.\\d+|\\-\\d{2}.\\d+");
		U.log(latlng[0]+","+latlng[1]);
		
		//Address
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addsec=U.getSectionValue(comHtml, "><address class=\"ModelInfo", "</address>");
		if(addsec!=null) {
			addsec=addsec.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->| - Coming Soon |_list ModelInfo_list-address\">|COMING SOON ", "").replaceAll("<br>", ",");
			U.log(addsec);
			add=U.findAddress(addsec);
			if(add==null) {
				U.log(addsec);
				add=U.getAddress(addsec);
			}
			U.log(Arrays.toString(add));
		}
		if(add[0]==ALLOW_BLANK && latlng[0]!=null) {
			add[0]=U.getAddressGoogleApi(latlng)[0];
			geo="True";
		}
		String dropPropSec[] = U.getValues(comHtml, "<script>", "</script");
		//U.log(dropPropSec);	
		for(String sec:dropPropSec) {
			comHtml = comHtml.replace(sec, "");
		}
		//String geo="true";
		
		String[] planUrls=U.getValues(comHtml, "<a class=\"PlanCard_imageLink\" href=\"", "\"");
		
		String planHtml="";
		for(String planUrl:planUrls)
		{
			U.log("plan url: "+planUrl);
			String tempHtml=U.getHtml("http://www.mychallengerhomes.com"+planUrl, driver).replaceAll("Single Family Homes\"| Ranch\"|-ranch\"", "");
			String tempSec=U.getSectionValue(tempHtml, "<div class=\"Floorplans_optionsNav\"", "<div class=\"Floorplans_imageWrapper ");
//			U.log(tempSec);
			if (tempSec!=null) {
				planHtml+=tempSec.replace(">First Floor</span>", " stories\":1}").replace(">Second Floor</span>", " stories\":2}").replace(">Third Floor</span>", " stories\":3}");
			}
			planHtml=planHtml+tempHtml;
			dropPropSec = U.getValues(planHtml, "<script>", "</script");
			//U.log(dropPropSec);	
			for(String sec:dropPropSec) {
				planHtml = planHtml.replace(sec, "");
			}
			
		}
		comHtml=comHtml.replaceAll("Max SF</strong><!-- react-text: \\d+ --> <!-- /react-text --><!-- react-text: \\d+ -->", "Max SF</strong> ");
		String[] sqft=U.getSqareFeet(comHtml+planHtml+allAvailData, ">\\d,\\d{3} – \\d,\\d{3} SF<|Max Total \\d,\\d+ SQ FT|Square Footage <span class=\"ng-binding\">\\d,\\d+ to \\d,\\d+|Max Total:</span> \\d,\\d+ SQ FT|Max SF</strong> \\d.\\d{3}", 0);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comHtml = comHtml.replaceAll("0's<|0s", "0,000");
		
		String[] price=U.getPrices((comHtml+planHtml+allAvailData).replaceAll("\"price\":\"\\$\\d{3},\\d{3}\"|\\$\\d{3},\\d{3}\" lii=\"",""),
				"From the <strong>\\$\\d{3},\\d{3}<|Priced from the <strong>\\$\\d{3},\\d{3}<|\\$[0-9]{3},[0-9]{3} to \\$[0-9]{3},[0-9]{3}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+ to \\$\\d+,\\d+|\\$\\d+,\\d+ to \\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		//U.log(allAvailData);
		//propType
//		U.log(""+Util.matchAll(comHtml, ".*301900.*", 0));
		
		
		String dropPropSec2  = U.getSectionValue(comHtml, "ng-untouched ng-valid\" ng-options=\"plan.com_name for plan", "</select></li>");
		//U.log(dropPropSec2);
		if(dropPropSec2!=null)
		
		comHtml = comHtml.replace(dropPropSec2, "");
		
		comHtml = comHtml.replace("17\">Park Haven Townhomes</a","");
		comHtml=comHtml.replace("com=10\">Trails East Patio Homes</a>", "");
		comHtml=comHtml.replace("com=33\">Northgate Patio Homes</a>", "")
				.replaceAll("Townhome/Patio Home\">Townhome/Patio Home|Townhomes\"|Townhomes</option>|/courtyards|\">Courtyards|\"Courtyards ", "");
		planHtml =planHtml.replaceAll("Custom Homes|Townhome/Patio Home\">Townhome/Patio Home|Townhomes\"|Townhomes</option>|/courtyards|\">Courtyards|\"Courtyards ", "");
		//comHtml = comHtml.replace("Covered Patios", "");
			
		
		//U.log(comHtml);
//		U.log(Util.match(comHtml, ".*single family.*"));
		comHtml=U.removeSectionValue(comHtml, "<p class=\"Footer_text\"", "</script>");
		String ptype=U.getPropType((comHtml+planHtml).replaceAll("single-family[-]?|Mountain Vista Luxury Paired Patio|Northgate Patio Homes|The Reserve at North Creek Patio Homes|Trails East Patio Homes|Townhome/Patio Home|Craftsman|Paired|Compatible", ""));
		
		ptype=ptype.replace(",Custom Home","");
		
		//
		//planHtml = planHtml.replace("Beautiful, 2 Story Vaulted Ceiling", "");
		
		comHtml = comHtml.replaceAll("Cuchares Ranch| Wolf Ranch\"| Wolf Ranch</|springsranch|\">Springs Ranch","");
		planHtml = planHtml.replaceAll("Large Rancher|Large Rancher|Gorgeous Rancher|Cuchares Ranch", "");
		
		//U.log("res"+Util.match(comHtml, ".*?ranch.*?"));
		
		
		planHtml=planHtml.replaceAll("Second Floor |2nd Level|<li>2 Story "," 2 Stories ");
		Util.match(planHtml, ".*second floor*");
		String dtype=U.getdCommType(comHtml+planHtml);
		
		
		String commType=U.getCommunityType(comHtml);
		
		
		//U.log(comHtml);
		comHtml=comHtml.replaceAll("Now Selling New Single Family Homes In Mead|style=\"background-color: #3578bc\">\n.*\\s*Now Selling|Now selling single family homes in Colorado|&lt;p&gt;Grand Opening March 18th|Stop by our Grand Opening March 18th|COMING SOON&lt|Our model home will be opening soon|Model Opening Soon!", "");
		comHtml=comHtml.replace("coming soon)","");
		String pStatus=U.getPropStatus(comHtml);
		U.log("pStatus: "+pStatus);
		
		
		U.log("commName"+commName+"commName");
		if(commName.trim().endsWith(" Townhomes"))commName=commName.replace(" Townhomes", "");
		if(commName.trim().endsWith(" Townhouse"))commName=commName.replace(" Townhouse", "");
		if(commName.endsWith("Patio Homes"))commName=commName.replace("Patio Homes", "");
		if(commUrl.contains("/patriot-park"))pStatus="-";
		commName=commName.replace(" Townhouse - SOLD OUT", "");
		
		
		
		data.addCommunity(commName, commUrl, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);

		data.addLatitudeLongitude(latlng[0], latlng[1], geo);

		data.addPropertyType(ptype,dtype);
				
		data.addPropertyStatus(pStatus);

		data.addPrice(minPrice, maxPrice);

		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(comHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
		}j++;
	}

}
