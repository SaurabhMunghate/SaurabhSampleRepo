package com.shatam.b_281_300;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractEncoreCapitalManagement extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static String Builder_name = "Encore Capital Management";
	static String HOME_URL = "https://www.encorecm.com/";
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractEncoreCapitalManagement();
		a.process();
		a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"csv/Encore Capital Management.csv", a
				.data().printAll());
	}

	public ExtractEncoreCapitalManagement() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger("Encore Capital Management");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.encorecm.com/");
		U.log(html);
		String region[] = U.getValues(html, "<div class=\"pic\"><a href=\"","\"");
		
		for (String regUrl : region) {
			U.log("region==" + (HOME_URL + regUrl));
			String regHtml = U.getHTML(HOME_URL + regUrl);
			   
			//section for community&property type from reg page
			String regprop=U.getSectionValue(regHtml, "<section id=\"tagline\">", "</section>");
			//U.log("regprop::"+regprop);
			
			String sec[] = U.getValues(regHtml, "<div class=\"name\"",
					"div class=\"info\">");
			U.log("total::"+sec.length);
			for (String comm : sec) {
				
				if (comm.contains("<a href=\"")) {
									
					adDetails(comm,regprop);
				}
				//break;
			}
			 //break;
		}
		LOGGER.DisposeLogger();
	}

	public void adDetails(String comsec, String regprop) throws Exception {

		
		//-------------comUrl------------
		String url = U.getSectionValue(comsec, "<a href=\"", "\"");
		U.log("Page Url: " + url);
		/*if (url == null || url.contains("http://www.encoreorlando.com/"))
			return;*/
		if(url.contains("http://www.cityhomes-us.com"))return; //this the next builder url 
		if(url.contains("http://auramedicaldistrict.com/"))return; //this the next builder url 
		if(url.contains("http://www.encoreorlando.com/"))return; //this the next builder url 
		if(url.contains("http://www.paramountworldcentermia.com/"))return;
		//if(!url.contains("http://thebearsdenclub.com/"))return;
		//U.log("comsec: " + comsec);
		//--------Community Name-----------
		String name = U.getSectionValue(comsec, ">", "<");
		String html = U.getHTML(url);
		
		//-------------Prices----------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html=html.replace("$1 million","$1,000,000");
		String[] price = U
				.getPrices(
						html + comsec,
						"Starting at <b>\\$\\d+,\\d+</b>|grid-price\">\\$\\d+,\\d+</p>|over \\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+ to \\$\\d+,\\d+|mid \\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		
		//-------------Square Feet-------------
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U
				.getSqareFeet(
						html + comsec,
						"SQ. FT. <b>\\d{4} - \\d{4}<|\\d+,\\d+ SQ. FT.|SQ. FT. <b>\\d+-\\d+<",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		
		
		html=html.replace("center;\">NOW OPEN", "");
		html=html.replaceAll("Deck or patio", " patio home ");
		
		//---------Community Type, Property Type, Derived Property Type And Status -------------
		String ctype = U.getCommunityType(html+regprop);
		String ptye = U.getPropType(html+regprop+comsec);
		String dType=U.getdCommType(html);
		String status=U.getPropStatus(html+comsec);
		
		
		//--------Address And Lat-Lng----------------
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo="True";
		String note=U.getnote(html);
		
		if (url.contains("http://paramountresidences.com/")) {
			name = "Paramount";

		}
		if(url.contains("http://www.encoreorlando.com/")){
			add[1]="Kissimmee";
			add[2]="FL";
		}
		if (name.contains("McKinley Village Logo")) {
			add[1] = "Sacramento";
			add[2] = "CA";

		}

		if (name.contains("Latitudes")) {
			add[0] = "2753 Waverly Drive";
			add[1] = "Los Angeles";
			add[2] = "CA";
			minSqf = "1,243";
			maxSqf = "1,910";
		}

		if (name.contains("Aura Wycliff")) {
			add[1] = "Dallas";
			add[2] = "TX";
			minSqf = "1,243";
			maxSqf = "1,910";
			add[0] = "4343 Congress Ave";
			add[3] = "75219";

		}
		if (name.contains("Miami Worldcenter")) {
			add[1] = "Miami";
			add[2] = "FL";

		}
		if (url.contains("http://www.paramountworldcentermia.com")) {
			add[0] = "16850 Collins Avenue Suite #105";
			add[1] = "Sunny Isles Beach";
			add[2] = "FL";
			add[3] = "33160";
			minSqf = "1491";
			maxSqf = "2578";
			ctype = "Resort-Style";
			
		}
		
		if (url.contains("http://paramountresidences.com")) {
			add[0] = "3020 NE 32nd Avenue, Suite 117";
			add[1] = "Fort Lauderdale";
			add[2] = "FL";
			add[3] = "33308";

			String sqFt[] = U
					.getSqareFeet(
							U.getHTML("http://paramountresidences.com/index.php?option=com_stpagebuilder&view=page&Itemid=116"),
							"Interior Area \\d+,\\d+ sq ft", 0);
			minSqf = sqFt[0];
			maxSqf = sqFt[1];
		}
		//
		if (name.contains("Dallas")) {
			name = "Aura Wycliff Apartment";
		}

		if (url.contains("http://mckinleyvillage.com/")) {
			add[0] = "3340 McKinley Village Way";
			add[1] = "Sacramento";
			add[2] = "CA";
			add[3] = "95816";
			minSqf="1298";
			maxSqf="3172";
			maxPrice="$900,000";
			minPrice="$300,000";
			dType="1 Story,2 Story";
			ptye="Cottage,Courtyard Home";
		}
		if (url.contains("http://www.miamiworldcenter.com/")) {

			add[0] = "7785 SW 66th St";
			add[1] = "Miami";
			add[2] = "FL";
			add[3] = "33143";
			ctype = "Resort-Style,Master Planned";
			note="Address And LatLng Taken Using City And State";
		}
		String dtype = U.getdCommType(html);
		if (url.contains("http://www.silverlakeliving.com")) {
			dtype = "Three Story";
			add[3] = " 90039";
			minPrice = "$789,900";
		}
		String htmlResi = "";
		if (url.contains("http://www.silverlakeliving.com")) {
			String residence = "http://www.silverlakeliving.com/residence-one.cfm";
			String htmlResidence = U.getHTML(residence);
			htmlResi = htmlResidence;
		}

		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		
		if (add[0] != ALLOW_BLANK) {
			latLng = U.getlatlongGoogleApi(add);
			geo = "TRUE";
		}
		if (add[3] == ALLOW_BLANK && latLng[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
		}
		if (url.contains("http://experiencethestandard.com/")) {

			name = "The Standard";
			add[0] = "6811 East Main Street";
			add[1] = "Scottsdale";
			add[2] = "AZ";
			add[3] = "85251";
			ptye = ptye+",Multi-Family";
			minSqf = "669";
			maxSqf = "1655";
			
		}
		if (url.contains("http://www.theretreatatwindermere.com/")) {

			add[0] = "5820 Nature View Drive";
			add[1] = "Windermere";
			add[2] = "FL";
			add[3] = "34786";
			
			minSqf = "656";
			maxSqf = "1382";
			ptye +=",Multi-Family";

		}
		if (url.contains("http://www.avelinelajolla.com/")) {

			add[0] = "720 Silver St.";
			add[1] = "La Jolla";
			add[2] = "CA";
			add[3] = "92037";
			ptye=ptye+",Patio Homes";
			
			minSqf = "1917";
			maxSqf = "2618";
		}
		if (url.contains("http://www.paramountresidences.com/")) {

			name = "Paramount Fort Louderdale Beach";
			add[0] = "3020 NE 32nd Avenue Suite 117";
			add[1] = "Fort Lauderdale";
			add[2] = "FL";
			add[3] = "33308";
			minSqf = "1910";
			maxSqf = "3474";

		}
		if (url.contains("http://www.theriseoldtown.com/")) {

			
			add[0] = "4545 SW Angel Ave";
			add[1] = "Beaverton";
			add[2] = "OR";
			add[3] = "97005";
			ptye += ",Multi-Family";
			
			geo="FALSE";

		}
if (url.contains("http://plantationwalk.com/")) {
			add[0]="311 N University Dr";
			add[1] = "Plantation";
			add[2] = "FL";
			add[3]="33324";
			ctype +=", Resort-Style";
		}

if (url.contains("http://thebearsdenclub.com/")) {
	add[0]="Traditions Blvd";
	add[1] = "Reunion Resort";
	add[2] = "FL";
	add[3]="34747";
	minSqf="3512";
	maxSqf="4945";

}
		
				
		if (url.contains("http://www.theencoreclub.com/")) {

			name = "Encore Club At Reunion";
			add[0] = "7635 Fairfax Dr";
			add[1] = "Reunion";
			add[2] = "FL";
			add[3] = "34747";
			ctype = ctype+", Resort-Style, Golf Course,Gated Community";
			ptye="Apartment Homes,Luxury Homes";
			dType="2 Story";
			/*minSqf = "2500";
			maxSqf = "6400";
			minPrice = "$300,000";*/
			
			geo="False";
		}
		String latLong[]={ALLOW_BLANK,ALLOW_BLANK};
		//lat-lng
		if(add[1]!=null && add[1]!=ALLOW_BLANK)
		{
		 latLng= U.getlatlongGoogleApi(add);
		}
		
		if(url.contains("http://www.theencoreclub.com/"))
		{
			latLong[0] ="28.287323";
			latLong[1]="-81.62599";
		}
		if(url.contains("http://www.theretreatatwindermere.com/"))
		{
			latLong[0]="28.478735";
			latLong[1]="-81.589756";
			geo="FALSE";
			dType="2 Story,Split Level";
			
		}
		if(url.contains("http://www.avelinelajolla.com/"))
		{
			latLong[0]="32.84663";
			latLong[1]="-117.27286";
			geo="FALSE";
			add[0]="7861 Herschel Ave.";
		}
		if(url.contains("http://www.encoreorlando.com/"))
		{
			if(latLong[0].length()<4)
				latLong=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLong);
			note="Address And LatLng Taken Using City And State";
		}
		
		if(add[0]==null)
		{
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
		if(latLong[0].length()<5 && add[1].length()>4)
		{
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if (url.contains("http://www.theriseoldtown.com/"))geo="FALSE";
		if (url.contains("http://thebearsdenclub.com/")) add[0]="7800 Traditions Blvd";
		if(data.communityUrlExists(url))
		{
		LOGGER.AddCommunityUrl(url+"   Repeate Community url");
		return;
		}
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(name, url, ctype);
		data.addAddress(add[0], add[1].trim(), add[2].toUpperCase().trim(),
				add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPropertyType(ptye, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);

	}
}