/*
 * Modification Aditya.
 */
package com.shatam.b_281_300;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKolterResidential extends AbstractScrapper {
	static int i = 1;
	static String BASEURL = "https://www.kolterhomes.com";
	CommunityLogger LOGGER;
	WebDriver driver = null;
	int j = 0, k = 0;

	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */

	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractKolterResidential();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Kolter Residential - Kolter Homes.csv", a.data().printAll());
	}

	public ExtractKolterResidential() throws Exception {

		super("Kolter Residential - Kolter Homes", BASEURL);
		LOGGER = new CommunityLogger("Kolter Residential - Kolter Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
	
	//ChromeOptions options = new ChromeOptions ();
	//	options.addExtensions (new File("/home/shatam-10/snap/skype/common/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
	//	DesiredCapabilities capabilities = new DesiredCapabilities ();
		//capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//
//		driver = new ChromeDriver(capabilities);
		
		Proxy proxy = new Proxy(); //"159.89.221.73",3128
		proxy.setHttpProxy("72.47.152.224:55443");  //209.126.4.134:3128
		proxy.setSslProxy("72.47.152.224:55443");  //45.42.177.21:3128
		

		DesiredCapabilities capabilities = DesiredCapabilities.chrome(); 
//		capabilities.setCapability("proxy", proxy); 

		ChromeOptions options = new ChromeOptions(); 
		options.addArguments("start-maximized"); 

		capabilities.setCapability(ChromeOptions.CAPABILITY, options); 

		driver = new ChromeDriver(capabilities);
		Thread.sleep(6000);
		
		
		String html = U.getHtml("https://www.kolterhomes.com/new-homes/",driver);
//		U.log("html" + html);
		// String sec=U.getSectionValue(html,"<header>Active Adult Living
		// Communities</header>","<img
		// src=\"/includes/communities/alton/other/th_ALTON_Header1.jpg");

		//String sec = U.getSectionValue(html, "<a href=\"/new-homes", "Click here for more info");
		//U.log("sec:" + sec);
		// sec=sec.replace("https://www.kolterhomes.com/new-homes/fort-myers-florida-active-adult-verandah/","/new-homes/fort-myers-florida-active-adult-verandah/");

		String vals[] = U.getValues(html, "<a href=\"/new", "Click here for more info");
U.log(vals.length);
		for(int i=1;i<vals.length;i++) {
			//U.log(vals[i]);
			String cU=U.getSectionValue(vals[i],"-", "\"");
			if(!cU.contains("https")) {
			String commUrl="https://www.kolterhomes.com/new-"+cU;
			U.log(commUrl);
			findCommunityDetails(commUrl, vals[i]);
			}
			else {
				String commUrl=cU;
				U.log(commUrl);
				findCommunityDetails(commUrl, vals[i]);
			}
		}
		findCommunityDetails("https://www.kolterhomes.com/new-homes/cresswind-charlotte-north-carolina-active-adult-55-homes/", "<div class=\"description\"> <h2>Cresswind Charlotte</h2> <p>Charlotte, NC</p> <p>Charlotte's Best Located 55+ Community with great amenities &amp; homes from the $300s</p> </div>");
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void findCommunityDetails(String commUrl, String commSec) throws Exception {
//	 if(j >= 15)
		// if
	//if (!commUrl.contains("https://www.kolterhomes.com/new-homes/port-saint-lucie-florida-vizcaya-falls/"))return;
		{
			U.log(commUrl + "++++++++++:::::::::::::::::::commUrl");
			 //U.log(commUrl+"::::::::::::::::::::"+commSec);

	
			U.log("Count :: " + j);

			
		//	commUrl = "https://www.kolterhomes.com" + commUrl;
			U.getCache(commUrl);
			String html = U.getHtml(commUrl,driver);
			U.log(commSec);
			html = html.replace("Patio@", "");
			// ========== Community Name ====================
			String communityName = U.getSectionValue(commSec, "<h2>", "</h2>");
			communityName = communityName.replaceAll("\\s{2,}", "");
			
			communityName=communityName.replace("Astor Creek Country Club", "Astor Creek");
			U.log("commName::" + communityName);

			// ============== Notes ==============
			String note = U.getnote(html);

			// ================ Address ======================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String directionSec = U.getSectionValue(html, " <li id=\"directions\" class=\"\">", "<span>");
			String directionHtml = "";
			if (directionSec != null) {
				U.log("directionUrl :::" + BASEURL + U.getSectionValue(directionSec, "<a href=\"", "\""));
				directionHtml = U.getHtml(BASEURL + U.getSectionValue(directionSec, "<a href=\"", "\""),driver);
//				U.log(directionHtml);
				
			}if (directionSec == null) {
				directionSec = ALLOW_BLANK;
			}
			if(commUrl.contains("/cresswind-charlotte-north-carolina-active-adult-55-homes/"))directionHtml=U.getHtml("https://www.kolterhomes.com/new-homes/cresswind-charlotte-north-carolina-active-adult-55-homes/directions/",driver);
			String addSec = U.getSectionValue(directionHtml, "<address>", "</address>");
			if (addSec != null) {
				addSec = addSec.replaceAll("\\s{2,}", "").replaceAll("<br />|<br/>|<br>", ",");
				U.log(addSec);
				add = U.getAddress(addSec);
				add[0] = add[0].replace("Alton On-Site Model Center, ", "");
				U.log("My Address ::: " + Arrays.toString(add));
			}
			
			// ================== LatLng Section ====================
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String geo = "False";
			
		//	String latLngSec1=U.getSectionValue(directionHtml, "d = {", "};");
		
			String latLngSec2 = U.getSectionValue(directionHtml, "https://www.google.com/maps/", "\"");
		

			if (latLngSec2 != null) {
				String latLngVal = U.getSectionValue(latLngSec2, "@", "/").replaceAll(",17z", "");
				U.log("latlongsec:;;;;;;;;;;;;;;;;;;"+latLngVal);
				
				if (latLngVal != null) {
					String val[] = latLngVal.split(",");
					lat = val[0];
					lng = val[1];
				} else {
					lat = U.getSectionValue(directionHtml, "lat : parseFloat('", "'");
					lng = U.getSectionValue(directionHtml, "lon : parseFloat('", "'");
				}
			}
			if (lat == null||lat==ALLOW_BLANK) {
				lat = U.getSectionValue(directionHtml, "lat:parseFloat(\"", "\"");//lat : parseFloat('
				lng = U.getSectionValue(directionHtml, "lon:parseFloat(\"", "\"");
			}
			if(lat==null||lat==ALLOW_BLANK) {
				lat = U.getSectionValue(directionHtml, "lat : parseFloat('", "')");//lat : parseFloat('
				lng = U.getSectionValue(directionHtml, "lon : parseFloat('", "'),");
			}
			U.log("L:ATLNG "+lat+"  "+lng);
			
			
			if (commUrl.contains("/new-homes/cresswind-charlotte-north-carolina-active-adult-55-homes/")) {
				lat = "35.224935";
				lng = "-80.648608";
			}
//			if (commUrl.contains("https://www.kolterhomes.com/http://moderneboca.com/")) {
//				lat = "35.224935";
//				lng = "-80.648608";
//			}
//			if (commUrl.contains("watersound-30a-naturewalk-at-watersound-origins/")) {
//				String adds[]= {"","Panama City","FL",""};
//				String latlong[]=U.getlatlongGoogleApi(adds);
//				if(latlong == null) latlong = U.getlatlongHereApi(adds);
//				lat=latlong[0];
//				lng=latlong[1];
//				geo="TRUE";
//				note="Address Taken From Using City And State";
//			}
//			if(commUrl.contains("/york-south-carolina-handsmill-on-lake-wylie/")) {
//				String adds[]= {"","York","SC",""};
//				String latlong[]=U.getlatlongGoogleApi(adds);
//				if(latlong == null) latlong = U.getlatlongHereApi(adds);
//				lat=latlong[0];
//				lng=latlong[1];
//				geo="TRUE";
//				note="Address Taken From Using City And State";
//			}
			if (commUrl.contains("santa-rosa-beach-30a-florida-nature-walk-at-seagrove/")) {
				String adds[]= {"","Panama City","FL",""};
				String latlong[]=U.getlatlongGoogleApi(adds);
				if(latlong == null) latlong = U.getlatlongHereApi(adds);
				lat=latlong[0];
				lng=latlong[1];
				geo="TRUE";
				note="Address Taken From Using City And State";
			}
			
			if (commUrl.contains("https://www.kolterhomes.com/new-homes/deland-florida-reserve-at-victoria/")) {
				String adds[]= {"","Deland","FL",""};
				String latlong[]=U.getlatlongGoogleApi(adds);
				if(latlong == null) latlong = U.getlatlongHereApi(adds);
				lat=latlong[0];
				lng=latlong[1];
				geo="TRUE";
				note="Address Taken From Using City And State";
			}
			
			if (commUrl.contains("port-st-lucie-florida-golf-astor-creek-country-club/")
					||commUrl.contains("port-st-lucie-florida-rivella/") || commUrl.contains("port-saint-lucie-florida-vizcaya-falls/")) {
				String adds[]= {"","Port St. Lucie","FL",""};
				String latlong[]=U.getlatlongGoogleApi(adds);
				if(lat == ALLOW_BLANK) latlong = U.getlatlongHereApi(adds);
				lat=latlong[0];
				lng=latlong[1];
				geo="TRUE";
				note="Address Taken From Using City And State";
			}
			
			
			
			U.log("Lat::" + lat + "\tLng::" + lng);

			if (lat != ALLOW_BLANK && lng != ALLOW_BLANK) {
				if (add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) {
					String[] latLong = { lat, lng };
					add = U.getAddressGoogleApi(latLong);
					if(add == null) add = U.getAddressHereApi(latLong);
					geo = "True";
				}
			}
			if (add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
				if (lat == ALLOW_BLANK || lat == null && lng == ALLOW_BLANK || lng == null) {
					String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
					latLong = U.getlatlongGoogleApi(add);
					if(latLong == null) latLong = U.getlatlongHereApi(add);
					lat = latLong[0];
					lng = latLong[1];
					geo = "True";
				}
			}
			if(add[0].length()<4 && lat.length()>4)
			{
				add = U.getAddressGoogleApi(new String[]{lat,lng});
				if(add == null) add = U.getAddressHereApi(new String[]{lat,lng});
				geo = "True";
			}
			// U.log(commSec);
			
			add[0]=add[0].replace("1431 Orange Camp Road, Suite 116", "1431 Orange Camp Road");

			Matcher mat = Pattern.compile("\\$\\d{3}s", Pattern.CASE_INSENSITIVE).matcher(html);
			while (mat.find()) {
				String priceMatch = mat.group().replace("s", ",000"); // $230s
				html = html.replace(mat.group(), priceMatch);
			}

			// ============ Model Homes ===========================
			String modelHomeSec = U.getSectionValue(html, "<li id=\"homes\"", "<span>");
			 U.log("modelHomeSec : "+modelHomeSec);
			String modelHomeHtml = null;
			if (modelHomeSec != null)
				modelHomeHtml = U.getHtml(BASEURL + U.getSectionValue(modelHomeSec, "<a href=\"", "\""),driver);
			if (modelHomeSec == null)
				modelHomeHtml = U.getHTML(commUrl+"/homes");
			String combinedHomeHtml = null;
			if (modelHomeHtml != null) {
				
				String[] homeUrls = U.getValues(modelHomeHtml, "data-ifp=\"1\"> <a href=\"", "\"");
				for (String homeUrl : homeUrls) {
					 U.log("homeUrl :"+homeUrl);
					 if(!homeUrl.contains("http"))homeUrl=BASEURL+homeUrl;
					combinedHomeHtml += U.getHTML(homeUrl);//U.getHtml(BASEURL + homeUrl,driver);
				}
			}
			
			// =========== Quick Homes =========================
			int quickHomeCount=0;
			int noQuickCount=0;
			int pending=0;
			String temp=ALLOW_BLANK;
			String quickHomeSec = U.getSectionValue(html, "<li id=\"move-in-ready\"", "<span>");
			if (quickHomeSec == null)
				quickHomeSec = U.getSectionValue(html, "<li id=\"move-in-ready\"", "<span>");
			
			if (quickHomeSec == null && modelHomeHtml != null)
				quickHomeSec = U.getSectionValue(modelHomeHtml, "FLOORPLANS</a>", "MOVE-IN READY HOMES</a>");
			
			String quickHomeHtml = null;
			String comQHome = "";
			if (quickHomeSec != null) {
				U.log("MoveUrl::" + BASEURL + U.getSectionValue(quickHomeSec, "<a href=\"", "\""));
				quickHomeHtml = U.getHtml(BASEURL + U.getSectionValue(quickHomeSec, "<a href=\"", "\""),driver);
				String homeS[] = U.getValues(quickHomeHtml, "<div class=\"item\" data-category=","</li> </ul> </a>");//eof sec "title="
				quickHomeCount=homeS.length;
				
				for (String string : homeS) {
//					if(string.contains("MOVE-IN: OCTOBER 2022")||string.contains("MOVE-IN: SEPTEMBER 2022")) {
//						noQuickCount++;
//					}
					
					if(string.contains("<div class=\"home-pending\"> PENDING ")) {
						U.log("Hello");
						pending++;	
					}
					String qurl ="https://www.kolterhomes.com"+ U.getSectionValue(string, "<a href=\"", "\"");
				    temp= U.getHtml(qurl,driver);
				    if(temp.contains("Move-In: October 2022")||temp.contains("Move-In: September 2022")) {
						noQuickCount++;
					}
					comQHome = comQHome +temp;
					
					U.log(qurl);
				}
			}

			// ================= Feature ===========================
			String featureSec = U.getSectionValue(html, "<li id=\"features\"", "<span>");
			// U.log(featureSec);
			String featureHtml = null;
			if (featureSec != null) {
				featureHtml = U
						.getHtml("https://www.kolterhomes.com" + U.getSectionValue(featureSec, "<a href=\"", "\""),driver);
			}
			//=============aminities=============
			String aminitySec = U.getSectionValue(html, "<li id=\"lifestyle\"", "<span>");
			// U.log(aminitySec);
			String aminityHtml = null;
			if (aminitySec != null) {
				aminityHtml = U
						.getHtml("https://www.kolterhomes.com" + U.getSectionValue(aminitySec, "<a href=\"", "\""),driver);
			}
			// ================== SQFT ====================
			String maxSqf = ALLOW_BLANK, minSqf = ALLOW_BLANK;
			String sqft[] = U.getSqareFeet(quickHomeHtml + modelHomeHtml + html,
					"\\d,\\d{3} a/c sq. ft. to over \\d,\\d{3} a/c sq. ft.|Home from \\d,\\d{3} - \\d,\\d{3} sq\\. ft\\.|Home under \\d,\\d{3} sq\\. ft\\.|\\d,\\d{3} to \\d,\\d{3} sq. ft|>\\d,\\d{3} Total Sq. Ft.<|<li>\\d,\\d{3} Total Sq. Ft.|\\d{1},\\d{3}\\sTotal\\sSq.\\sFt.|<li>\\d,\\d{3} Total Sq. Ft.</li>|\\d,\\d{3}\\+ a/c sq. ft.",
					0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			if(commUrl.contains("https://www.kolterhomes.com/new-homes/palm-city-florida-canopy-creek/"))minSqf="4000";//img
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			// ================ Price =====================
			String moveinSec = U.getSectionValue(html, "<li id=\"move-in-ready\" ", "<span>Move-In Ready</span>");
			// String moveinUrl=U.getSectionValue(moveinSec, "<a href=\"","\"");
			/*
			 * String moveinHtml=U.getHTML("https://www.kolterhomes.com"+moveinUrl);
			 * U.log(moveinHtml);
			 */
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html=html.replace("$2 million", "$2,000,000");
			commSec = commSec.replace("$1M", "$1,000,000")
					.replace("$1 Million", "$1,000,000")
					.replace("$2 Million", "$2,000,000")
					.replace("$1.5m", "$1,500,000").replace("$1 million", "$1,000,000")
					.replaceAll("0s|0's|0S|0S", "0,000");
			html = html.replace("$1 Million", "$1,000,000");
			if (quickHomeHtml!=null) {
				quickHomeHtml=quickHomeHtml.replace("$1M", "$1,000,000");
			}
			commSec=commSec.replace("$2 million", "$2,000,000");
//			U.log(commSec);
			String price[] = U.getPrices(quickHomeHtml + modelHomeHtml + html + commSec,
					"\\$\\d,\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}MyPrice|> \\$\\d,\\d{3},\\d{3} <|> \\$\\d{3},\\d{3} <",
					0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

			U.log("minPrice::" + minPrice + "\tmaxPrice::" + maxPrice);
			// =============== Community Type =================
			html = html.replace("55&#x2b;", "55+").replace("Premier Lakeside Lifestyle and Best New Home Value", "Premier Lakeside community and Best New Home Value");
			if(aminityHtml ==null) 
				aminityHtml = "";
			String communityType = U.getCommunityType((html+aminityHtml).replaceAll("new homes, gated,|new homes in the gated|lakefront Clubhouse|lakefront clubhouse", "").replace("<h1>On Par with Championship Golf & Country Clubs</h1>", "")+commSec);
			
			
			// communityType=communityType.replace(",","");
			U.log("comType=" + communityType);
			
//			U.log(">>>>>>>>>>>>>>"+Util.matchAll(commSec+html + quickHomeHtml + modelHomeHtml + featureHtml, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));

			// ============== Property Type =============
			String propertyType = ALLOW_BLANK;
			if(featureHtml ==null) featureHtml = "";
			featureHtml = featureHtml.replace("found in any luxury home,", "luxurious homes");
			featureHtml = featureHtml.replace("\"Single Family/Townhomes\"});</script>", "");
			if (modelHomeHtml != null)
				modelHomeHtml = modelHomeHtml.replace("\"Single Family/Townhomes\"});</script>", "");

			html = html.replace("\"Single Family/Townhomes\"});</script>", "");
			// U.log(modelHomeHtml);
			if (quickHomeHtml != null)
				
				
			quickHomeHtml=U.removeSectionValue(quickHomeHtml, "name=\"description\"", "<link");
			propertyType = U.getPropType(commSec + (html + quickHomeHtml + modelHomeHtml + featureHtml).replace("Interested in HOA", "")
					.replaceAll("Traditional brick|Traditional paver|value with single family|communityType\":\"Single Family", "").replaceAll(" Townhome Communities|townhomes|townhomes,", ""));
			
			if (propertyType.contains("Townhouse") && propertyType.contains("Townhome")) {
				propertyType = propertyType.replace("Townhouse,", "");
			}

//			U.log(">>>>>>>>>>>>>>"+Util.matchAll(commSec+html + quickHomeHtml + modelHomeHtml + featureHtml, "[\\s\\w\\W]{30}Single Family[\\s\\w\\W]{30}", 0));

			
			U.log("Property Type=" + propertyType);
			// ============== Property Status ==========
			//|Ultimate Opportunities - \\d+ Homes Remain
			html = html.replaceAll("<strong>SOLD OUT:</strong> get on the VIP|now selling at Cresswind Georgi|recently sold our final new|Quick Delivery|CLUB JUST RELEASED|Move-In Ready|Available Fall 2018|Now Open for Preview|Center</a> Opening in 2018|AVAILABLE BY SOCIAL|Center</a> - Now", "");
		//	U.log(commSec);
			commSec = commSec.replaceAll("<strong>SOLD OUT:</strong> get on the VIP|now selling at Cresswind Georgi|<strong>OPENING THIS", "");
			String propertStatus = U.getPropStatus(commSec+html.replace("full video coming soon", ""));
			propertStatus = propertStatus.replace("Ii", "II");
			U.log("status=" + propertStatus);
		//	String moveHtm = U.getHTMLwithProxy(commUrl+"/move-in-ready/");
			String moveHtm =U.getHtml(commUrl+"/move-in-ready/",driver);
			if (moveHtm!=null) {
				U.log(moveHtm.contains("<div class=\"description with-price\">")+"i m here::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
//				String[] quickHomeUrlSec = U.getValues(quickHomeHtml, "<div class=\"item\" data-", "</a>");
//				U.log("quick sec::::::::::"+quickHomeUrlSec);
				if (moveHtm.contains("<div class=\"description with-price\">")) {
					if (propertStatus != ALLOW_BLANK && !propertStatus.contains("Move-In") && !propertStatus.contains("Ready Homes"))
						propertStatus += ", Move-In Ready Homes";
					else
						propertStatus = "Move-In Ready Homes";
				}
			}

			
			U.log("noQuickCount="+noQuickCount);
			U.log("quickHomeCount="+quickHomeCount);
			U.log("pending="+pending);

			if((quickHomeCount==noQuickCount||quickHomeCount<noQuickCount)||pending>=quickHomeCount)
				propertStatus=propertStatus.replaceAll("Move-In Ready Homes|Move-In Ready Homes, |, Move-In Ready Homes", "");
			if(propertStatus.length()<4)
				propertStatus=ALLOW_BLANK;
			
			// ============== Derived Community Type ==========
			if (combinedHomeHtml != null)
				combinedHomeHtml = combinedHomeHtml.replaceAll("Stories</span>\\s+<span class=\"value\">(\\d\\.?\\d?)</span>", " $1 Story ");
//				.replaceAll("Stories</span>\\s+<span class=\"value\">(\\d\\.?\\d?)</span>", " 3 Stories ");
				
//						.replaceAll("Stories</th>\\s<td>1<|Stories</th> <td>1", " 1 Story ").replaceAll("Stories</th> <td>2<", " 2 Story ").replace("Stories</th> <td>3", " 3 Story ");
			// featureHtml=featureHtml.replace("first and second story","single-floor and
			// 2-story");

			String dType = U.getdCommType((featureHtml + quickHomeHtml + modelHomeHtml + html + combinedHomeHtml
					+ commSec
					+ comQHome.replaceAll("Stories</th>\\s*<td>1", " 1 Story ").replace("Stories</th> <td>2", " 2 Story "))
							.replaceAll("2nd Floor|\\d+-Story|Colonial Town", "").replaceAll("ranch|Ranch</option>|2 Bedroom, 2 Bath", "").replaceAll("ranch|Ranch", ""));

			U.log("dType=" + dType);

//			U.log(">>>>>>>>>>>>>>"+Util.matchAll(featureHtml + quickHomeHtml + modelHomeHtml + html + combinedHomeHtml+commSec+comQHome, "[\\s\\w\\W]{30}Stories[\\s\\w\\W]{50}", 0));
			
			if (commUrl.contains("new-homes/palm-beach-gardens-florida-alton/")){dType +=", 3 Story";}

			propertStatus=propertStatus.replace("Move In Ready Home, Move-In Ready Homes", "Move-In Ready Homes");
			U.log("Max price is:::" + maxPrice);
			U.log("nComType=" + communityType);
//			if (commUrl.contains("new-homes/palm-city-florida-canopy-creek/"))propertStatus="Water & Preserve Homesites Available";
			if (data.communityUrlExists(commUrl)) {
				LOGGER.AddCommunityUrl(commUrl + "--------------------------------- repeated");
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);
//			if(commUrl.contains("charlotte-north-carolina-active-adult-cresswind-wesley-chapel/")) {
//				add[1]="Charlotte";
//				add[2]="NC";
//				String ll[]=U.getlatlongGoogleApi(add);
//				lat=ll[0];
//				lng=ll[1];
//				add=U.getAddressGoogleApi(ll);
//				geo="TRUE";
//				note="Address Taken From City And State";
//			}//dt
			if(commUrl.contains("new-homes/georgia-active-adult-cresswind-at-lake-lanier/")) {
				add[1]="Gainesville";
				add[2]="GA";
				String ll[]=U.getlatlongGoogleApi(add);
				lat=ll[0];
				lng=ll[1];
				add=U.getAddressGoogleApi(ll);
				geo="TRUE";
				note="Address Taken From City And State";
			}
//			if(commUrl.contains("https://www.kolterhomes.com/new-homes/charleston-summerville-south-carolina-active-adult-cresswind-charleston")) {
//				propertStatus="Move-In Ready Homes";
//				maxPrice="$504,030";
//			}
			
//			if(commUrl.contains("https://www.kolterhomes.com/new-homes/port-saint-lucie-florida-vizcaya-falls"))communityType="Gated Community, Resort Style, Lakeside Community";
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(communityName, commUrl, communityType.replace("55\\+", "55+"));
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(propertyType, dType);
			data.addPropertyStatus(propertStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;
	}

	// This function is to find community details which communit layout different
	// from others
	private void findDetails(String commUrl, String commSec) throws Exception {
		// if(k >= -1)return;

		{
			// U.log("Just came from above::::"+commUrl);
			commUrl = commUrl.replace("http://", "https://");
			//if(!commUrl.contains("waterclubliving"))return;
			{
				U.log(":::::::::::::::::;" + commUrl);
				U.log("Count :: " + k);

			//	U.log(commSec);
				if (data.communityUrlExists(commUrl)) {
					LOGGER.AddCommunityUrl(commUrl + "---------------------------------repeat");
					return;
				}

				String html = ALLOW_BLANK;
				if (commUrl.contains("themarksarasota.com"))
					html=U.getHTMLwithProxy("https://www.themarksarasota.com/");
				else html=U.getHtml(commUrl, driver);

				if (commUrl.contains("www.theresidencessarasota.com"))
					commUrl = "https://www.theresidencessarasota.com/";

				// ========== Community Name ====================
				String communityName = U.getSectionValue(commSec, "<h2>", "</h2>");
				communityName = communityName.replaceAll("\\s{2,}", "").replace(", Sarasota", "");
				U.log("commName::" + communityName);
				communityName = U.getCapitalise(communityName.toLowerCase());

				// ================ Address ======================
				String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				//U.log(html);
				String addressSec = U.getSectionValue(html, "<footer class=\"wrap-block\">", "</span>");
				 U.log("%%%%%%%%%%%"+addressSec);
				if (addressSec != null) {

					addressSec = addressSec.replaceAll("<div class=\"content clear\">|<span>|<p>", "").replace("|", "")
							.replace("Trail Boca Raton", "Trail, Boca Raton");
					// System.out.println("))))))))"+addressSec);

					if (addressSec.trim().length() < 100) {
						U.log("ppppp " + addressSec);
						addressSec = U.formatAddress(addressSec);
						add = U.getAddress(addressSec);
					}
				}

				// ---------- Contact --------------

				String contactHtml = U.getHtml(commUrl + "contact", driver);
			//	U.log(contactHtml);
				// System.out.println("address section is"+addressSec);

				String addSec = U.getSectionValue(contactHtml, "<address>", "</address>");

				if (addSec == null)

					addSec = U.getSectionValue(contactHtml, "Sales Gallery</strong>", "</p>");U.log("hello---1");
				if (addSec == null)
					addSec = U.getSectionValue(contactHtml, "<h3>SALES GALLERY OPEN DAILY</h3>", "</h5>");U.log("hello---2");
				if (addSec == null)
				 	addSec = U.getSectionValue(contactHtml, "<p class=\"footer-address\">", "</div>");U.log("hello---3");
				if (addSec == null)
					addSec = U.getSectionValue(contactHtml, "SALES GALLERY</strong><br />", "</li>");U.log("hello---4");
				if (addSec == null)
					addSec = U.getSectionValue(contactHtml, "Sales Office</strong>", "941-702-2300<br />");U.log("hello---5");
				if (addSec == null)
					addSec = U.getSectionValue(contactHtml, "Sales Gallery Open Daily</strong></h4>", "<small>");U.log("hello---6");
				if (addSec == null) {
					addSec = U.getSectionValue(contactHtml, "<footer class=\"wrap-block\">", "site map");U.log("hello---7");
					U.log(addSec);
					if (addSec != null)
						addSec = U.getSectionValue(addSec, "<p>", "<span>");
				}
				U.log("::::::::::" + addSec + "<<<<<<<<<");
				if (addSec != null) {
					if (addSec.length() == 0) {
						addSec = U.getSectionValue(contactHtml, "<div class=\"nav-top\"><span>",
								"</span> <span>|</span> <a href=\"");
					}
					addSec = addSec.replace("Drive</span> <span>|</span> <span>", "Drive,");
					addSec = addSec.replaceAll("\\s{2,}", "").replace("<br />", ",").replace(", #304", " #304")
							.replace("Boulevard, Suite 150", "Boulevard Suite 150").replace(",USA", "").replaceAll(
									"</h4>|<p>|954.800.6263|</p>|\n|,,,|</i>|</li>|<li>|<h5>|<i class=\"fa fa-map-marker fa-lg\">|Singer Island,|\\s{2,}",
									"");
					if (addSec.length() > 200) {
						addSec = U.getSectionValue(addSec, "target=\"_blank\">", "</a>");
					}
					addSec = addSec.replaceAll("  |    ", "").replace("<br>", ", ").replace(", USA", "")
							.replaceAll("&nbsp;", "");
					U.log("$%^&$%$%$%$%$%$%@$#$" + addSec);
					if (add[0] == ALLOW_BLANK)
						add = U.getAddress(addSec);
					U.log(Arrays.toString(add));
				}

				if (addSec == null && add[0] == ALLOW_BLANK) {
					add[0] = U.getSectionValue(contactHtml, "streetAddress\":\"", "\"");
					add[1] = U.getSectionValue(contactHtml, "addressLocality\":\"", "\"");
					add[2] = U.getSectionValue(contactHtml, "addressRegion\":\"", "\"");
					add[3] = U.getSectionValue(contactHtml, "postalCode\":\"", "\"");
				}
				U.log("hello " + add[1]);
				if (addSec == null && add[1] == null) {
					add[0] = U.getSectionValue(contactHtml, "streetAddress\">", "</span>");
					add[1] = U.getSectionValue(contactHtml, "addressLocality\">", "</span>");
					add[2] = U.getSectionValue(contactHtml, "addressRegion\">", "</span>");
					add[3] = U.getSectionValue(contactHtml, "postalCode\">", "</span>");
				}
				if(commUrl.contains("themarksarasota")){
					add = new String[]{"100 S Washington Blvd","Sarasota","FL","34236"};
					
				}
				// ================== LatLng Section ====================
				String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
				String geo = "False";

				String latLngSec = U.getSectionValue(contactHtml, "https://www.google.com/maps/", "\"");
				if (latLngSec == null)
					latLngSec = U.getSectionValue(contactHtml, "href=\"https://www.google.com.co/maps/", "\"");
				// U.log(latLngSec);
				
				String latLngVal = null;
				if (latLngSec != null) {
					latLngVal = U.getSectionValue(latLngSec, "%212d", "%212m");

					if (latLngVal != null) {
						latLngVal = latLngVal.replace("%213d", ",");
						String val[] = latLngVal.split(",");
						lat = val[1];
						lng = val[0];
					}
					if (latLngVal == null && latLngSec.contains("@")) {
						latLngVal = U.getSectionValue(latLngSec, "@", "/");
						if (latLngVal != null) {
							String val[] = latLngVal.split(",");
							lat = val[0];
							lng = val[1];
						}
					}
				}
				if(contactHtml.contains("https://www.google.com/maps/embed?")){
					latLngSec = U.getSectionValue(contactHtml, "https://www.google.com/maps/embed?pb=", "\"");
						lat = U.getSectionValue(latLngSec, "3d", "!");
						lng = U.getSectionValue(latLngSec, "2d", "!");
					
				}
				if(contactHtml.contains("latitude")){
					lat = U.getSectionValue(contactHtml, "latitude\":", ",");
					lng = U.getSectionValue(contactHtml, "longitude\":", "}");
					if(lat==null){
						lat = U.getSectionValue(contactHtml, "itemprop=\"latitude\" content=\"", "\"");
						lng = U.getSectionValue(contactHtml, "itemprop=\"longitude\" content=\"", "\"");
					}
				}
				U.log("Lat::" + lat + "\tLng::" + lng);
				if (lat != ALLOW_BLANK && lng != ALLOW_BLANK) {
					if (add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) {
						String[] latLong = { lat, lng };
						add = U.getAddressGoogleApi(latLong);
						geo = "True";
					}
				} else {
					if (add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
						String[] latLong = U.getlatlongGoogleApi(add);
						lat = latLong[0];
						lng = latLong[1];
						geo = "True";
					}
				}
				if (lat == ALLOW_BLANK && lng == ALLOW_BLANK) {
					lat = U.getSectionValue(contactHtml, "latitude\":", ",");
					lng = U.getSectionValue(contactHtml, "longitude\":", "}");
				}
				if (commUrl.contains("https://www.vuesarasotabay.com/")) {
					add[0] = U.getSectionValue(contactHtml, "street-address\">", "</span>");
					add[1] = U.getSectionValue(contactHtml, "class=\"locality\">", "</span>");
					add[2] = U.getSectionValue(contactHtml, "class=\"region\">", "</abbr>");
					add[3] = U.getSectionValue(contactHtml, "class=\"postal-code\">", "</span>");
					lat = "27.335323";
					lng = "-82.531636";
				}

				Matcher mat = Pattern.compile("\\$\\d{3}s", Pattern.CASE_INSENSITIVE).matcher(html);
				while (mat.find()) {
					String priceMatch = mat.group().replace("s", ",000"); // $230s
					html = html.replace(mat.group(), priceMatch);
				}
				// ================= Feature ===========================
				String featureHtml = null;
				featureHtml = U.getHtml(commUrl + "features", driver);
				if (featureHtml.length() < 500 || featureHtml == null)
					featureHtml = U.getHtml(commUrl + "residences/features", driver);

				// ============ Floor Plans ===========================
				String modelHomeHtml = null;
				modelHomeHtml = U.getHtml(commUrl + "residences/plan-one", driver);
				if (commUrl.contains("https://moderneboca.com/")){
					modelHomeHtml+=U.getHtml(commUrl + "residences/plan-two",driver)+U.getHtml(commUrl + "residences/plan-three",driver);
				}
				if (commUrl.contains("https://www.theresidencessarasota.com")
						|| commUrl.contains("https://www.onehundredlasolas.com/"))
					modelHomeHtml = U.getHtml(commUrl + "floorplans/", driver);

				if (modelHomeHtml.length() < 500 || modelHomeHtml == null)
					modelHomeHtml = U.getHtml(commUrl + "residences/floorplans/", driver);

				if (commUrl.contains("https://www.5000nocean.com"))
					modelHomeHtml = U.getHtml(commUrl + "/residences/floorplans/seabreeze", driver);

				if (commUrl.contains("https://www.waterclubliving.com/north-palm/"))
					modelHomeHtml = U.getHtml(commUrl + "residences.php", driver);

				if (commUrl.contains("https://www.theresidencessarasota.com")){
					modelHomeHtml = U.getHtml(commUrl + "floorplans/", driver);
					modelHomeHtml+=U.getHtml(commUrl + "/penthouses/", driver);
				}
				if (modelHomeHtml != null) {
//					String planSection = U.getSectionValue(modelHomeHtml, "class=\"floorplan-box clear\">", "</div>");
//					if (planSection != null) {
						String[] planUrls = U.getValues(modelHomeHtml, "<li><a href=\"/floorplans/", "\"");
						for (String planUrl : planUrls) {
							U.log("========>" + commUrl + planUrl);
							modelHomeHtml += U.getHtml(commUrl + planUrl, driver);
						//}
					}
				}
				//for modernboca//Onepetersburg
				String floorHtmlnew=ALLOW_BLANK;
				if(commUrl.contains("moderneboca.com")){
					floorHtmlnew=U.getHtml("https://www.moderneboca.com/residences",driver);
					floorHtmlnew=floorHtmlnew.replace("Level", "story");
				}
				if(commUrl.contains("https://www.onestpetersburg.com")){
					floorHtmlnew=U.getHtml("https://www.onestpetersburg.com/floorplans/",driver);
					String plans[]=U.getValues(floorHtmlnew, "<li><a href=\"/floorplans/", "\"");
					for(String plan:plans)
					{	
					floorHtmlnew+=U.getHtml("https://www.onestpetersburg.com/floorplans/"+plan,driver);
					floorHtmlnew=floorHtmlnew.replaceAll("INTERIOR(.*?)TOTAL AREA", "");
					}
				}
				// =========== Amenities =========================
				String amenitiesHtml = null;
				if(!commUrl.contains("https://www.5000nocean.com"))
				amenitiesHtml = U.getHtml(commUrl + "amenities", driver);
				else amenitiesHtml=U.getHtml(commUrl+"/lifestyle",driver);
				if(!commUrl.contains("https://www.5000nocean.com")){
				if (amenitiesHtml.length() < 500 || amenitiesHtml == null)
					amenitiesHtml = U.getHtml(commUrl + "residences/amenities", driver);
				if (amenitiesHtml.length() < 500 || amenitiesHtml == null)
					amenitiesHtml = U.getHtml(commUrl + "building/amenities", driver);
				if (amenitiesHtml.length() < 500 || amenitiesHtml == null)
					amenitiesHtml = U.getHtml(commUrl + "lifestyle", driver);
				}
				// ============ Building ==============
				String buildingHtml = null;
				if (commUrl.contains("https://www.onestpetersburg.com/")) {
					buildingHtml = U.getHtml(commUrl + "building", driver);
					modelHomeHtml = U.getHtml(commUrl + "residences", driver);
				}
				// =========== Residence ==============
				String residenceHtml = null;
				if (commUrl.contains("https://themarksarasota.com/")) {
					String residenceSec = U.getSectionValue(html, ">RESIDENCES</a>", "FEATURES</a");
					String urlVals[] = U.getValues(residenceSec, "<a href=\"", "\"");
					for (String urlVal : urlVals) {
						U.log("planUrl::::" + "https://www.themarksarasota.com/" + urlVal);
						residenceHtml += U.getHTMLwithProxy("https://www.themarksarasota.com/" + urlVal);
					}
				}
				if (commUrl.contains("https://www.vuesarasotabay.com/")) {
					String residenceSec = U.getSectionValue(html, "<ul class=\"box-nav nav-residences\">",
							"Features</a></li>");
					String urlVals[] = U.getValues(residenceSec, "<a href=\"/", "\"");
					for (String urlVal : urlVals)
						residenceHtml += U.getHtml(commUrl + urlVal,driver);
				}

				// ================== SQFT ====================
				if (modelHomeHtml != null)
					modelHomeHtml = modelHomeHtml.replaceAll(
							"Level \\d</td>\\s+<td>\\d,\\d+ sf</td>\\s+<td>\\d+ m2</td>|7,000 sq. ft. of extraordinary",
							"");

				if (featureHtml != null)
					featureHtml = featureHtml.replaceAll("7,000 sq. ft. of extraordinary", "");

				String rem = "1,000|5,000|7,000 sq. ft. of extraordinary|5,000 sq ft private|5,000 sq. ft. clubhouse|2,407 sq. ft., of oceanfront terrace";

				String maxSqf = ALLOW_BLANK, minSqf = ALLOW_BLANK;
				String sqft[] = U.getSqareFeet(
						(amenitiesHtml + modelHomeHtml + featureHtml + residenceHtml+floorHtmlnew).replaceAll(rem, ""),
						"\\d,\\d{3} Total Sq. Ft.|Total Area</td>\\s+<td>\\d,\\d+ sf</td>|Total Living Area</td>\\s+<td>\\d,\\d+ sf</td>|\\d,\\d{3} SQ FT|\\d,\\d{3} sf|\\d,\\d{3} sq. ft|\\d,\\d{3} SQ. FT.|<td>\\d,\\d{3}(\\s+) sq. ft.</td>|<strong>\\d,\\d{3} - \\d,\\d{3} sq. ft.</strong>|\\d,\\d{3} sq. ft.",
						0);
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

				// ================ Price =====================
				U.log(Util.matchAll(amenitiesHtml + modelHomeHtml + featureHtml + residenceHtml+floorHtmlnew, "[\\w*\\s*\\W*]{10}\\d,\\d{3}[\\w*\\s*\\W*]{10}", 0));
				if(modelHomeHtml!=null)modelHomeHtml=modelHomeHtml.replace("$569,000</span>", "");
				commSec = commSec.replace("$1M", "$1,000,000").replace("$2 Million", "$2,000,000 Million")
						.replace("$1.5m", "$1,500,000").replace("$1 million", "$1,000,000").replace("0s", "0,000");
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String price[] = U.getPrices(amenitiesHtml + modelHomeHtml + featureHtml + html + commSec,
						"\\$\\d,\\d{3},\\d{3} |From \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}MyPrice", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

				U.log("minPrice::" + minPrice + "\tmaxPrice::" + maxPrice);

				// =============== Community Type =================
				String communityType = U.getCommunityType((html + amenitiesHtml).replaceAll("lakefront Clubhouse|lakefront clubhouse", "").replace("<h1>On Par with Championship Golf & Country Clubs</h1>", ""));
				// U.log("Amenities:::***************"+amenitiesHtml);
				// communityType=communityType.replace(",","");
				U.log("ComType=" + communityType);
				// ============== Property Type =============
				String propertyType = U
						.getPropType((html + amenitiesHtml + modelHomeHtml + featureHtml + buildingHtml+floorHtmlnew));
				U.log("PType::" + propertyType);
				// ============== Property Status ==========
				html = html.replaceAll("We recently sold our|Gallery Grand|>Villas - SOLD|Special (C|c)loseout", "");
				commSec = commSec.replaceAll("Million Coming|Special (C|c)loseout", "");

				String propertStatus = U.getPropStatus(html + commSec);
				if (propertStatus.equals("Move-in Ready")) {
					propertStatus="Move-In Ready Homes";
				}

				// ============== Derived Community Type ==========
				if (modelHomeHtml != null)
					modelHomeHtml = modelHomeHtml.replaceAll("3 stories; 174 keys", "");

				if (buildingHtml != null)
					buildingHtml = buildingHtml.replaceAll("3 stories; 174 keys", "");
				//U.log(floorHtmlnew);
//				U.log(Util.matchAll(floorHtmlnew,"Level",0));
				String dType = U
						.getdCommType((featureHtml + amenitiesHtml + modelHomeHtml + html + buildingHtml + commSec+floorHtmlnew).replaceAll("ranch/\"|Ranch</option>", "").replaceAll("ranch/\"|Ranch</a>", "")
								.replace("Colonial Town", ""));
				U.log("DType::" + dType);
				// ============== Notes ==============
				String note = U.getnote(html.replaceAll("special pre-sale information", ""));
				U.log(":::::::::::::::::::::::" + Arrays.toString(add));

				if (propertyType.contains("Townhouse") && propertyType.contains("Townhome"))
					propertyType = propertyType.replace("Townhouse,", "");

				if (commUrl.contains("www.waterclubliving.com"))maxPrice = "$2,100,000"; // img

				if (lat == null) {
					lat = ALLOW_BLANK;
					lng = ALLOW_BLANK;
				}
				if(commUrl.contains("moderneboca.com"))add[2]="FL";
				U.log("Property type::::" + propertyType);
				
				String counting=ALLOW_BLANK;
				String startDt=ALLOW_BLANK;
				String endDt=ALLOW_BLANK;
				
				LOGGER.AddCommunityUrl(commUrl);
				data.addCommunity(communityName, commUrl, communityType.replace("55\\+", "55+"));
				data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
				data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
				data.addPropertyType(propertyType, dType);
				data.addPropertyStatus(propertStatus);
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minSqf, maxSqf);
				data.addNotes(note);
				data.addUnitCount(counting);
				data.addConstructionInformation(startDt, endDt);
			}
		}
		k++;
	}

}