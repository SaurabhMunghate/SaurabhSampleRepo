/**
 * @author Parag Humane 
 * @date 14/3/2012
 * 
 */
package com.shatam.b_281_300;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractRelatedGroup extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	WebDriver driver = null;
	CommunityLogger LOGGER;
	private static String builderName = "Related Group";
	private String builderUrl  = "http://relatedgroup.com";
	
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractRelatedGroup();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Related Group.csv", a.data().printAll());
	}

	public ExtractRelatedGroup() throws Exception {
		super(builderName, "http://relatedgroup.com/");
		LOGGER=new CommunityLogger(builderName);
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML(builderUrl);	
		String [] urls = U.getValues(html, "<li class=\"box\">", "</a>");
		for(String url : urls){
			url = U.getSectionValue(url, "<a href=\"", "\"");
	//		U.log(url);
			String homeHtml = U.getHTML(url);
			String []  comSections = U.getValues(homeHtml, "<div class=\"popup_content\">", "<script>");
//			U.log("Homes ::"+comSections.length);
			for(String comSec : comSections){
				if(!comSec.contains("http"))continue;
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
//				U.log(comUrl);
				findCommunityDetails(comUrl,comSec);
			}
		}
		LOGGER.DisposeLogger();
	}
	int j = 0;
	private void findCommunityDetails(String comUrl, String comSec) throws Exception {
		//if(j == 6)
		{
		U.log(j+"/t:::::::: "+comUrl);
		if(comUrl.contains("http://aubergemiamiresidences.com"))return;  // Error 403 Forbidden

		String html = U.getPageSource(comUrl);
		
		U.log(comSec);
		String commName = U.getSectionValue(comSec, "<h1>", "</h1>");
		
		//============ Price ==================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String prices[] = U.getPrices(html+comSec,"\\$\\d{1},\\d+,\\d+|\\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
		//=====================Sq.ft=======================
		String minSqft = ALLOW_BLANK, maxSqft= ALLOW_BLANK;
		html = html.replaceAll("space plus nearly 1,000", "");
		String[] sqft = U.getSqareFeet(html+comSec,
						"from \\d,\\d{3} to \\d,\\d{3} square feet|\\d{1},\\d+ - \\d{1},\\d+ Square Feet| \\d{1},\\d+ Square Feet",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
	
		html = html.replaceAll("gated parking", "");
		String comType = U.getCommunityType(html+comSec);
		
		String[] add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "False";
		String addValues = getHardcodedAddress("Hardcode_RelatedGroup", comUrl);
		U.log(addValues);
		if(addValues != null){
			String addVal [] = addValues.split(",");
			
			add[0] = addVal[0];
			add[1] = addVal[1];
			add[2] = addVal[2];
			add[3] = addVal[3];
			latlng [0] = addVal[4];
			latlng[1] = addVal[5];
			geo = addVal[6];
			if(minSqft == ALLOW_BLANK && addVal.length > 7){
				minSqft = addVal[7];
				maxSqft = addVal[8];
			}
		}
		
		
		String contactHtml = null;
		if(html.contains("/contact/"))
			contactHtml = U.getHTML(comUrl+"/contact/");
		html = html.replaceAll("Courtyard-Eve|courtyard-eve|Book luxurious|best in luxury", "");
		String groveHtml = null;
		if(html.contains("/the-grove"))
			groveHtml = U.getHTML(comUrl+"/the-grove");
		String amentiesHtml = null;
		if(html.contains("/residences-amenities/"))
			amentiesHtml = U.getHTML(comUrl+"/residences-amenities/");
		if(html.contains("/the-amenities/"))
			amentiesHtml = U.getHTML(comUrl+"/the-amenities/");
		if(html.contains("/amenities.php"))
			amentiesHtml = U.getHTML(comUrl+"/amenities.php");
		if(html.contains("/amenities.asp"))
			amentiesHtml = U.getHTML(comUrl+"/amenities.asp");
		
		String propType = U.getPropType(html+comSec+contactHtml+groveHtml+amentiesHtml);
		
		comSec = comSec.replace("five levels of the tower", "");
		html = html.replaceAll("item-level-2", "");
		String dType = U.getdCommType(html+comSec);
		
		html = html.replaceAll("SOON</p>|Soon'\\);", "");
		String propStatus = U.getPropStatus(html+comSec);


		
		String note = ALLOW_BLANK;
		
		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
    	data.addCommunity(commName.toLowerCase().trim(), comUrl, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0].trim(),latlng[1].trim(),geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
	}
	j++;
	}
	public static String getHardcodedAddress(String builderName, String comUrl)
			throws Exception {
//		commUrl = comUrl;

		String newFile = "/home/shatam-4/Harcoded Builders/" + builderName	+ ".csv";
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {
			if (count > 0) {
				String aaa = getBuilderObj(newCsvRow,comUrl);
				if (aaa != null)
					return aaa;
			}
			count++;
		}
		newFileReader.close();
		return null;
	}

	public static String getBuilderObj(List<String> newCsvRow,String comUrl) {
		if (comUrl.contains(newCsvRow.get(1).trim())) {
			return ( newCsvRow.get(3) + ","
					+ newCsvRow.get(4) + "," + newCsvRow.get(5) + ","
					+ newCsvRow.get(6) + "," + newCsvRow.get(7) + ","
					+ newCsvRow.get(8) + "," + newCsvRow.get(9) + "," + newCsvRow.get(15)+ "," + newCsvRow.get(16));
		}
		return null;
	}

	
}