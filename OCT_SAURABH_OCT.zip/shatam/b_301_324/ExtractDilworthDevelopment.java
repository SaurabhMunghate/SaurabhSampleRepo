package com.shatam.b_301_324;

import java.io.IOException;
import java.util.Arrays;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDilworthDevelopment extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://www.dilworthdevelopment.com";

	public ExtractDilworthDevelopment() throws Exception {
		super("Dilworth Development", builderUrl);				
		LOGGER = new CommunityLogger("Dilworth Development");																																										
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractDilworthDevelopment();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Dilworth Development.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
		String html = U.getHTML("https://www.dilworthdevelopment.com/communities/");
		String[] mainSec = U.getValues(html, "<article data-slug=", "</article>");
		
		for(String data : mainSec)
		{
			String comUrl = U.getSectionValue(data, "href=\"", "\"");
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			String comHtml = U.getHTML(comUrl);
			
			if(comHtml.contains("<article data-slug=\"")) {
				
				String[] subSec = U.getValues(comHtml, "<article data-slug=", "</article>");
				
				for(String subData : subSec)
				{
					comUrl = U.getSectionValue(subData, "href=\"", "\"");
					getDetail(comUrl, subData);
				}
				
			}
			else
				getDetail(comUrl, data);
		}
		
		LOGGER.DisposeLogger();
		
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("https://www.dilworthdevelopment.com/communities/the-camp/")) return;
		
		U.log("Count: " + j + "\t" + comUrl);
		{
			
//			U.log(com);
			if(comUrl.contains("http://www.parcatauclub.com/"))comUrl="https://www.parcatauclub.com/";
			String html = U.getHTML(comUrl);
			U.log(U.getCache(comUrl));
			
			if(html.contains("Harris Doyle Homes - A Berkshire Hathaway Company")||comUrl.contains("harrisdoyle.com")) {
				LOGGER.AddCommunityUrl("=====Harris Doyle===Return===== " + comUrl);
				return;
			}
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(com, "<h3 class=\"edgtf-item-title\">", "<");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<iframe src=\"https://www.google.com/maps/embed?pb=", "\""); //+U.getSectionValue(html, "<div class=\"DetailInformation_headerContent\" data-reactid=", "")
			
			if(addSec==null) {
				addSec=U.getSectionValue(html, "<h5 class=\"DetailInformation_communityLocation\" data-reactid=", "/h5>");
			}
			if(comUrl.contains("https://www.dilworthdevelopment.com/communities/the-gardens/")) {
				addSec="Falling Leaf Lane,Union Grove, AL, 35175";
			}
//			if(comUrl.contains("/hamilton-gables/")) { 
			if(html.contains("<h3>Address</h3>")) { 
				addSec=U.getSectionValue(html, "<h3>Address</h3>", "<h3>Sales Contact</h3>");
//				U.log("======"+addSec);
				if(addSec!=null)
				addSec=addSec.replaceAll("\r\n\\s*\r\n\\s*</div>\r\n\\s*\r\n\\s*<div class=\"wpb_text_column wpb_content_element \" >\r\n\\s*<div class=\"wpb_wrapper\">", "");
			}
//			U.log(addSec);
			String forAdd = ALLOW_BLANK;
			if (addSec != null) {
				
//				U.log("Adress:--" + addSec);
				addSec=addSec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", " ");
				addSec=addSec.replaceAll("</p>\\s*<p>", ",").replaceAll(" </span>|</span>|</p>\r\n\\s*<p>", ",");
				U.log("Adress:--" + addSec);
				forAdd = addSec;
				
				if(addSec.contains("<p>")) {
					addSec=addSec.replace("<br />", ",");
//					U.log(addSec);
					addSec=U.getSectionValue(addSec, "<p>", "<");
				}else {
				addSec=addSec.replaceAll("     |\"\\d+", "");
				addSec=U.getSectionValue(addSec, "> ", "<");
				}
//				U.log(addSec);
				add=U.getAddress(addSec);
//				add[0]=U.getSectionValue(addSec, "\\d+ -->", "<!--");
//				add[1]=U.getSectionValue(addSec, "", "");
//				add[2]=U.getSectionValue(addSec, "", "");
//				addSec = Util.match(addSec, "!2s.*!\\d");
//				U.log(addSec);
//				if (addSec != null){
//					
//					addSec = addSec.replace("%20", " ").replace("+", " ").replace("%2C", ",");
//					add = U.getAddress(U.getNoHtml(addSec));
//				}

			}
			
			
			
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
		
//				addSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "/@");
//				if (addSec != null) {
//					
//					addSec = Util.match(addSec, "-\\d+\\.\\d+.*\\d+\\.\\d+");
//					
//					addSec = addSec.replaceAll("!\\d\\w", ",");
//						
//					latLng = addSec.split(",");
//					String laString = latLng[1];
//					latLng[1] = latLng[0];
//					latLng[0] = laString;
//				}
			String LatlongSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "/@");
			if (LatlongSec != null) {
				latLng=LatlongSec.split(",");
			}
			
				if (comUrl.contains("https://www.parcatauclub.com/")) {

					latLng[0] = "32.608452";
					latLng[1] = "-85.441856";
					
				}
			if(LatlongSec==null) {
				LatlongSec = U.getSectionValue(html, "src=\"https://www.google.com/maps/embed?", "\"");
				if(LatlongSec!=null) 
				{
					latLng[0] = U.getSectionValue(LatlongSec, "3d", "!");
					latLng[1] = U.getSectionValue(LatlongSec, "2d", "!");
				}
			}
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			
			
			
			
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);
			
			if(comUrl.contains("https://www.dilworthdevelopment.com/communities/the-camp/")) {
				addSec = forAdd;
				latLng[0]=latLng[1]=ALLOW_BLANK;
//				U.log("forAdd: "+forAdd);
//				latLng[0] = Util.match(addSec, "\\d{2}.\\d{5}");
//				latLng[1] = Util.match(addSec, "-\\d{2}.\\d{5}");
//				
//				U.log("LATLONG: "+Arrays.toString(latLng));
			}
			
			if(latLng[0]==ALLOW_BLANK) {
				latLng[0]=Util.match(addSec, "\\d{2}\\.\\d{5,}");
				latLng[1]=Util.match(addSec, "-\\d{2,3}\\.\\d{5,}");
			}
			U.log("latlong--->" + latLng[0] + "  " + latLng[1]);
			if (add[1] != ALLOW_BLANK && (latLng[0] == ALLOW_BLANK || latLng[0]==null)) {
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			if(comUrl.contains("/village-at-oakland-springs/")) {
				add[1]="Madison";
				add[2]="AL";
				latLng=U.getGoogleLatLngWithKey(add);
				add=U.getGoogleAddressWithKey(latLng);
				geo="true";
				note="address taken from city and state";
			}
			
			if ((add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}


			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);
			if(add[0]!=ALLOW_BLANK && add[3]==ALLOW_BLANK && latLng[0]!=ALLOW_BLANK) {
				add=U.getAddressGoogleApi(latLng);
				geo="True";
			}
			if(html.contains("<div class=\"wpb_gmaps_widget wpb_content_element hide-it\">")) {
				geo="True";
			}
			//section present in source but not on page 28Aug21
			if(comUrl.contains("/village-at-oakland-springs/"))html=U.removeSectionValue(html, "<div class=\"vc_tta-container\" data-vc-action=\"collapse\">", "</htm");
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("0s", "0,000").replaceAll("Homes over \\d+ SF: \\d+ gallon electric hybrid water heater|Homes under \\d+ SF: \\d+ gallon gas water heater|Homes over \\d+ SF: \\d+-gallon electric hybrid water heater|Homes under \\d+ SF: \\d+-gallon gas water heater", "");
			String prices[] = U.getPrices(com + html, " \\$\\d{3},\\d{3}</p>|starting at \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</p>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html,
					"<br />\n\\s*\\d,\\d{3} sq\\. ft|\\s+\\d,\\d{3} sq\\.ft|\\d,\\d{3} - \\d,\\d{3} sq\\.ft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " Max" + maxSqft);
			
			//=======About Sec======
			String aboutSec="";
			aboutSec=U.getSectionValue(html, "<div class=\"wpb_column vc_column_container vc_col-sm-9\">", "</p>\r\n" + 
					"\r\n" + 
					"		</div>");
			U.log(aboutSec);
			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com+aboutSec).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf|elongated toilets", ""));
//			U.log(Util.matchAll(html+com, "[\\w\\s\\W]{30}gated[\\w\\s\\W]{30}",0));
			// ==========================================================Property
			// Type================================================
			String pTypesection=U.getSectionValue(html, ">Community Description</h3>", "</div></div></div></div></div>")+U.getSectionValue(html, ">Included Features</h3>", "</p></div></div></div></div></div></div></div></div>");
			String proptype = U.getPropType((pTypesection+com)); //html +

			// ==================================================D-Property
			// Type======================================================
			
			String dtype = U.getdCommType((html + com).replaceAll("branch|BRANCH|(f|F)loor|=\"Check out the 2-story living room and loft inside", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
			String comStatushtml =U.getSectionValue(html, "<div class=\"CarouselImage_titleOverlay_wrapper\" data-reactid=", "</div></div></a></div>");
			html = html.replaceAll("slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			String pstatus = U.getPropStatus((comStatushtml+com+aboutSec).replace("More information coming soon", ""));  //html+
		//	U.log(Util.matchAll(aboutSec, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			

			//========== Hard Code Data ==================================
			if(comUrl.contains("/village-at-oakland-springs/")) {
				minPrice=ALLOW_BLANK;maxPrice=ALLOW_BLANK;minSqft=ALLOW_BLANK;maxSqft=ALLOW_BLANK; //not prresent on page
				pstatus="Coming soon";
			}
			if(comUrl.contains("parcatauclub")) {
				communityType="Golf Course";   //from img
			}
			if(comUrl.contains("/communities/the-camp/"))pstatus="Coming Soon";
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s", "");
			if(comUrl.contains("https://www.dilworthdevelopment.com/communities/the-cove/"))proptype="Homeowner Association";
			
			if(comUrl.contains("https://www.dilworthdevelopment.com/communities/the-camp/"))
				{
				proptype="Carriage Homes, Cottage";
				communityType="Lakefront Community";
				}

			
			//=========================================================================================================================
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;

	}

}
