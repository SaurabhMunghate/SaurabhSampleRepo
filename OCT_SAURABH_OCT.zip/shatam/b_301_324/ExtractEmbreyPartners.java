package com.shatam.b_301_324;


import java.util.Arrays;

import javax.swing.text.html.HTML;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractEmbreyPartners extends AbstractScrapper{
	static int j = 0 ;
	CommunityLogger LOGGER;
	WebDriver  driver = null;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a =new ExtractEmbreyPartners();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Embrey.csv", a.data()
				.printAll());

	}
	public ExtractEmbreyPartners() throws Exception {

		super("Embrey", "https://www.embreydc.com/");
		LOGGER = new CommunityLogger("Embrey");
	}

	@Override
	protected void innerProcess() throws Exception {
		int i=0;
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHtml("https://www.embreydc.com/portfolio/",driver);
//		html=html.replaceAll(",\\s*</span>\\s*<span class=\"website\"><a href=\"", "urlstart");
		String sec = U.getSectionValue(html, "<section id=\"page-block-2\"", "</section");
		//String[] comUrls = U.getValues(sec, "<div class=\"block-subcontent ", "</a></span>");
		String[] comUrls = U.getValues(html, "<div class=\"block-subcontent cagriditem", "</div></div></div></div></div>");
	   //  String[] comUrls =U.getValues(html, "{\"title\":", "}");
		U.log(comUrls.length);
		for(String comUrl : comUrls){
		//	U.log(comUrl);
			//String url = U.getSectionValue(comUrl, "<span class=\"website\"><a href=\"", "\"");
			String url = U.getSectionValue(comUrl, "url=\"", "\"");
			if(url==null)
				url=U.getSectionValue(comUrl, "data-url=\"", "\"");
			//U.log((i++)+"-->"+url);
			
			///****if community missing bug comes then check following ccomm names and remove them from conitinue list
			
			if(comUrl.contains("Ironwood at Red Rocks")||comUrl.contains("Ridgeline at Rogers Ranch")||comUrl.contains("Everly")||comUrl.contains("Venue at the Promenade")||comUrl.contains("The Flats at Santan")||comUrl.contains("Domain at Founders Parc")||comUrl.contains("LUXE at Mile High")||comUrl.contains("Kelly at Samuels Ave")||comUrl.contains("Knox at Metrocenter")||comUrl.contains("Riata")||comUrl.contains("The Standard at Legacy")||comUrl.contains("The Finch")||comUrl.contains("Seven Oaks")||comUrl.contains("Keene at the District")||comUrl.contains("Hensley at the District")||comUrl.contains("The Quincy at Kierland")||comUrl.contains("Statler McCain's Station")||comUrl.contains("Collection at Gruene")||comUrl.contains("Tin Top at the Creamery")||comUrl.contains("http://TBD")||  comUrl.contains("sanantonio.gov") ||comUrl.contains("lenoxstoneoak.com")||
					comUrl.contains("liveatamara")|| comUrl.contains("quarryvillagesa.com")||comUrl.contains("cellarsatpearl")
			||comUrl.contains("thehighbank") || comUrl.contains("lenoxoverlook")|| comUrl.contains("losroblesliving") ||
			comUrl.contains("melaluxuryapts")||comUrl.contains("quailcreekapts")|| comUrl.contains("livesouthline")
			||comUrl.contains("stonegrovefallcreek") )continue;
			
			if(comUrl.contains("Tin Top at the Creamery"))continue;
			
			U.log("comUrl : "+url);

//			try {
				findData(url,comUrl);
//			} catch (Exception e) {}
//			
			
		}
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}
	private void findData(String url,String comSec) throws Exception {
//try {
		if (!url.contains("www.")&&!url.contains("http://theartessa.securityproperties.com")&&!url.contains("http://liveatthecollection.com"))
			url = url.replace("http://", "https://www.");
		else if(url.contains("http://theartessa.securityproperties.com"))
			url=url.replace("http://", "https://");
		//https://cortland.com/apartments/cortland-walker-ranch/
//		U.log("---=="+url);
		if(url.contains("www.cellarsatpearl.com"))url=url.replace("https://", "http://");
		if (url.contains("https://www.weidner.com/gilbert/flats-at-san-tan/"))
			url = "https://arizona.weidner.com/apartments/az/gilbert/the-flats-at-santan/index.aspx";
		if(url.contains("parkatwestave.com")) {
			url = "https://cortland.com/apartments/cortland-walker-ranch/";
		}
		if(url.contains("liveatbrackenridge"))url="https://cortland.com/apartments/cortland-brackenridge/";
		
		if(url.contains("https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/")){
			
		}
	//TODO : To run for single community

		
		//=======single run
//		if(!url.contains("https://www.livetheupland.com/")) return;//Single Run	
 	
 	
 	
 	
 	
 	
 	//24 Oct 2020
 	if(url.contains("https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/") ||
 			url.contains("https://www.liveatfoundersparc.com/")){
 		LOGGER.AddCommunityUrl("============ Not Open ====================== "+url);
		return;
	}

	
		U.log("count== "+j+"--"+url);
		//if(j==14)
		{
		
		if(data.communityUrlExists(url)) {
			
			LOGGER.AddCommunityUrl("============ Reppeated ====================== "+url);
			return;
		}
		
//		if(url.contains("https://cortland.com/apartments/cortland-brackenridge/") || url.contains("https://cortland.com/apartments/cortland-walker-ranch/")) {
//			
//			LOGGER.AddCommunityUrl("============ Redirected ====================== "+url);
//			return;
//		}
		LOGGER.AddCommunityUrl(url);
		
	
		{
			
		String comHtml = U.getHtml(url,driver);
		if(comHtml == null || comHtml.length()<2) {
			comHtml = U.getHTMLwithProxy(url);
		}
		if(comHtml.length()<2) {
			comHtml = U.getHtml(url,driver);
		}
		String floorurl=ALLOW_BLANK,mapUrl = ALLOW_BLANK, aminityUrl = ALLOW_BLANK;
		String allurls[]= U.getValues(comHtml, "<a href=\"", "\"");
		for(String aurl:allurls) {
			if(aurl.contains("interactivemap.aspx")|| aurl.contains("goo.gl/maps/")||aurl.contains("/terms_maps") || aurl.contains("/maps?cid=") || aurl.contains("//maps.google.com/?q"))continue;
			if(aurl.contains("map")) {
				mapUrl = aurl;
			}
			if(aurl.contains("floor")) {
				floorurl = aurl;
				
			}
			if(aurl.contains("ameni")) {
				aminityUrl = aurl;
			}
			if(mapUrl == ALLOW_BLANK) {
				if(aurl.contains("contact") || aurl.contains("visit") || aurl.contains("mapsanddirections")) {
					mapUrl = aurl;
					U.log("mapUrl =========== "+mapUrl);
				}
			}
			mapUrl=mapUrl.replace("map-directions/reviews/", "map-directions");
		}
		//if html does contains some class between <a and href=
		String navbarsec = U.getSectionValue(comHtml, "<div class=\"collapse navbar-collapse\"", "</div>");
		if(navbarsec==null)navbarsec = U.getSectionValue(comHtml, "<div class=\"navbar-inner\">", "</div>");
		if(navbarsec==null)navbarsec = U.getSectionValue(comHtml, "<nav migration_allowed=\"1\" migrated=\"0\" role=\"navigation\" class=\"elementor-nav-menu--main elementor-nav-menu__container ", "</nav>");
		if(navbarsec==null)navbarsec = U.getSectionValue(comHtml, "<nav class=\"propertyheader__nav\"", "</div>");
		if(navbarsec==null)navbarsec = U.getSectionValue(comHtml, "<section class=\"nav-wrapper\">", "</div>");
		if(navbarsec==null)navbarsec = U.getSectionValue(comHtml, "<div class=\"navbar-inner", "</div>");
		if(navbarsec==null)navbarsec = ALLOW_BLANK;
		allurls= U.getValues(navbarsec, "href=\"", "\"");
		for(String aurl:allurls) {
			if(aurl.contains("interactivemap.aspx")|| aurl.contains("goo.gl/maps/")||aurl.contains("/terms_maps") || aurl.contains("business") || aurl.contains("facebook")|| aurl.contains("yelp")|| aurl.contains("instagram")|| aurl.contains("/maps?cid=") || aurl.contains("//maps.google.com/?q")|| aurl.length()<5 || aurl.contains("("))continue;
			U.log(aurl);
			if(aurl.contains("map")) {
				mapUrl = aurl;
			}
			if(aurl.contains("floor")) {
				floorurl = aurl;
			}
			if(aurl.contains("ameni")) {
				aminityUrl = aurl;
			}
			if(mapUrl == ALLOW_BLANK) {
				if(aurl.contains("contact") || aurl.contains("visit") || aurl.contains("mapsanddirections")) {
					mapUrl = aurl;
				}
			}
			mapUrl=mapUrl.replace("map-directions/reviews/", "map-directions");
		}
		if(url.contains("theartessa")) {
			floorurl ="https://www.securityproperties.com/theartessa/franklin/the-artessa-apartments/conventional/";
			mapUrl ="https://theartessa.securityproperties.com/franklin/the-artessa-apartments/map-and-directions/";
		}
		String domain = url;
		
//		if(url.contains("cortland")) {
//			domain="https://cortland.com/apartments";
//			mapUrl = mapUrl.replace("/apartments/", "");
//			floorurl = floorurl.replace("/apartments/", "");
//			aminityUrl = aminityUrl.replace("/apartments/", "");
//		}
		if(url.contains("bhmanagement")) {
			mapUrl ="https://bhmanagement.com/communities/connection-at-buffalo-pointe/contact/";
			floorurl = "https://bhmanagement.com/communities/connection-at-buffalo-pointe/floorplans/#2699";
			aminityUrl = "https://bhmanagement.com/communities/connection-at-buffalo-pointe/amenities/";
		}
		if(url.contains("bhmanagement")) {
			mapUrl ="https://bhmanagement.com/communities/connection-at-buffalo-pointe/contact/";
			floorurl = "https://bhmanagement.com/communities/connection-at-buffalo-pointe/floorplans/#2699";
			aminityUrl = "https://bhmanagement.com/communities/connection-at-buffalo-pointe/amenities/";
		}
		if(url.contains("https://www.liveatthecanneryapartments.com/"))
			floorurl = "https://www.liveatthecanneryapartments.com/floorplans";
		if(url.contains("liveatthecollection")) {
			mapUrl = "https://liveatthecollection.com/contact/";
			floorurl = "https://liveatthecollection.com/floorplans/";;
			aminityUrl = "https://liveatthecollection.com/amenities/";
		}if(url.contains("/las-colinas-at-black-canyon/")) {
			mapUrl = "https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/map-directions";
			floorurl = "https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/floor-plans";;
			aminityUrl = "https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/amenities";
			}
		if(url.contains("/las-colinas-at-black-canyon/"))floorurl="https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/floor-plans#/categories/all/floorplans";

		if(url.contains("westendatcitycenter"))floorurl="https://www.westendatcitycenter.com/apartments/ks/lenexa/floor-plans#/categories/all/floorplans";
		if(url.contains("addisonkellersprings"))floorurl="https://www.addisonkellersprings.com/apartments/tx/addison/floor-plans#/categories/all/floorplans";
		if(url.contains("liveatgreenvue"))floorurl="https://www.liveatgreenvue.com/apartments/tx/richardson/floor-plans#/categories/all/floorplans";
		if(url.contains("liveattouchstone"))floorurl="https://www.liveattouchstone.com/floorplans";
		if(url.contains("liveatgreenvue"))floorurl="https://www.liveatgreenvue.com/floorplans.aspx";
		if(url.contains("addisonkellersprings"))floorurl="https://www.addisonkellersprings.com/floorplans.aspx";
		if(url.contains("westendatcitycenter"))floorurl="https://www.westendatcitycenter.com/floorplans.aspx";
		if(url.contains("rentanapt"))floorurl="https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/floor-plans";
		if(url.contains("https://arizona.weidner.com/apartments/az/gilbert/the-flats-at-santan/index.aspx"))
			floorurl = "https://arizona.weidner.com/apartments/az/gilbert/the-flats-at-santan/floorplans";
		if(url.contains("https://www.ridgelinerogersranch.com")) floorurl = "https://www.ridgelinerogersranch.com/floorplans";
		if(url.contains("https://www.liveatleResort-Style Swimming Poolgacyapartments.com"))floorurl = "https://www.liveatlegacyapartments.com/apartments/tx/san-antonio/floor-plans";
		if(url.contains("https://www.costabellaapts.com")) floorurl="https://www.costabellaapts.com/floorplans.aspx";
		if(url.contains("https://www.7600broadway.com")){
			floorurl="https://www.7600broadway.com/plans";
			aminityUrl = "https://www.7600broadway.com/refined-living";
		}
		if(url.contains("thestandardatlegacy.com/"))floorurl=url+"floorplans";
		if(url.contains("https://www.liveatthekelley.com/")) floorurl="https://www.liveatthekelley.com/floorplans";
		if(url.contains("encoreatboulevardone"))floorurl=url+"floorplans";
//		if(!mapUrl.contains("http") && !mapUrl.contains(domain)) {
//			domain = domain.replace("index.aspx", "");
//			if(!domain.endsWith("/"))domain=domain+"/";
//			mapUrl = domain+mapUrl;
//			mapUrl=mapUrl.replace("//", "/");
//		}
//		if(!aminityUrl.contains("http") && !aminityUrl.contains(domain)) {
//			domain = domain.replace("index.aspx", "");
//			if(!domain.endsWith("/"))domain=domain+"/";
//			aminityUrl=domain+aminityUrl;
//			aminityUrl=aminityUrl.replace("//", "/");
//
//		}
//		if(!floorurl.contains("http") && !floorurl.contains(domain)) {
//			domain = domain.replace("index.aspx", "");
//			if(!domain.endsWith("/"))domain=domain+"/";
//			floorurl=domain+floorurl;
//			floorurl=floorurl.replace("//", "/");
//
//		}
		if(url.contains("Venue-at-the-Promenade-Apartments"))mapUrl=ALLOW_BLANK;//does have address and latlong on comm page
		U.log(mapUrl+"::::::"+floorurl+"::::::::::"+aminityUrl);
		//============= Comumity Name ===============
		
		//String comName = U.getSectionValue(comSec, "style=\"color:#f57c1f\">", "<");
		String comName = U.getSectionValue(comSec, "data-title=\"", "\"");
//		if(Util.matchAll(comSec, "style=\"color:#f57c1f\">(.*)<", 1).size()>1)
//			comName=Util.matchAll(comSec, "style=\"color:#f57c1f\">(.*)<", 1).get((Util.matchAll(comSec, "style=\"color:#f57c1f\">(.*)<", 1).size()-1));
		U.log("ComName: "+comName);

		//============= Nav Section Data ===========
		
		String floorHtml = ALLOW_BLANK;
		String amenities = ALLOW_BLANK;
		String mapSec = ALLOW_BLANK;
		mapUrl=mapUrl.trim();
		
		U.log("mapUrl>>>>>>>>> : "+mapUrl);
		
		if(mapUrl.contains("map&amp;directions"))mapUrl = mapUrl.replace("map&amp;directions", "mapsanddirections");
		
		U.log("mapUrl Final : "+mapUrl);
		
		if(!mapUrl.contains("http")) {
			domain = domain.replace("index.aspx", "");
			if(!url.endsWith("/") && !mapUrl.startsWith("/")) {
				
				U.log("mapUrl 1 : "+domain+"/"+mapUrl);
				mapSec=U.getHtml(domain+"/"+mapUrl,driver);
			
			}

			
			else if(!url.endsWith("/") && mapUrl.startsWith("/")) {
				U.log("mapUrl 2 : "+domain+mapUrl);
				mapSec=U.getHtml(domain+mapUrl,driver);
			}	
				
			
			
			else if(url.endsWith("/") && !mapUrl.startsWith("/")) {
				U.log("mapUrl 3 : "+domain+mapUrl);
				mapSec=U.getHtml(domain+mapUrl,driver);
			}
			else if(mapUrl.equals("/mapsanddirections")) {
				
				mapUrl = mapUrl.replace("/", "");
				U.log("mapUrl---: "+domain+mapUrl);
				
				mapSec=U.getHtml(domain + mapUrl,driver);
			}
				
		}
		else {
			U.log("mapUrl direct-: "+mapUrl);
			mapSec=U.getHtml(mapUrl,driver);
		}
//		U.log(U.getCacheFileName(mapUrl));
		if(!aminityUrl.contains("http")) 
		{
			if(!url.endsWith("/") && !amenities.startsWith("/")) {
				amenities=U.getHtml(domain+aminityUrl,driver);//"/"
				U.log("j1");
			}
			else if(!url.endsWith("/") && amenities.startsWith("/")) {
				amenities=U.getHtml(domain+aminityUrl,driver);
				U.log("j1");
			}
			else if(url.endsWith("/") && !amenities.startsWith("/")) {
			//	U.log("PPPPP=="+domain+amenities);
				U.log("PPPPP=="+domain+aminityUrl.replace("/", ""));
				amenities=U.getHtml(domain+aminityUrl.replace("/", ""),driver);
				U.log("CACHE1==="+U.getCache(domain+aminityUrl));
			}
			else if(url.endsWith("/")&& aminityUrl.startsWith("/")) {
				U.log("M HEkko");
				amenities=U.getHtml(domain+aminityUrl.replace("/", ""), driver);
			}
				
			
		}
//		if(!aminityUrl.contains("http")) 
//		{
//			if(!url.endsWith("/") && !aminityUrl.startsWith("/"))
//				amenities=U.getHtml(domain+"/"+aminityUrl,driver);
//			
//			else if(!url.endsWith("/") && aminityUrl.startsWith("/"))
//				amenities=U.getHtml(domain+aminityUrl,driver);
//			
//			else if(url.endsWith("/") && !aminityUrl.startsWith("/")) {
//			//	U.log("PPPPP=="+domain+amenities);
//				U.log("PPPPP=="+domain+aminityUrl);
//				amenities=U.getHtml(domain+aminityUrl,driver);
//				U.log("CACHE1==="+U.getCache(domain+aminityUrl));
//			}
//			
//		}
		else {
			//U.log("jjjjjj");
			U.log(aminityUrl);
			amenities=U.getHtml(aminityUrl,driver);
		}
//		U.log(url.endsWith("/") && floorurl.startsWith("/"));
		String floorplanSec=null;
		U.log("FLOOR PLAN URL"+floorurl);
		if(!floorurl.contains("http")) 
		{
			domain = domain.replace("index.aspx", "");
			if(!url.endsWith("/") && !floorurl.startsWith("/")) {
				floorHtml=U.getHtml(domain+"/"+floorurl,driver);
				if(floorHtml.length()<2)floorHtml = U.getHtml(domain+"/"+floorurl,driver);
			}
			else if(url.endsWith("/") && floorurl.startsWith("/")) {
				floorurl=floorurl.replace("/", "");
				U.log("url+floorurl>>>>>>>  "+url+floorurl);
				floorHtml=U.getHtml(url+floorurl,driver);
				U.log("flr path: "+U.getCache(url+floorurl));
				floorplanSec=U.getSectionValue(floorHtml, "<!-- Optimized Floor Plans Layout Start -->", "<!-- Optimized Floor Plans Layout End -->");
				if(floorplanSec==null)floorplanSec=U.getSectionValue(floorHtml, "Floor Plans</h1>", "Availability <span class=\"sr-only\">for B1</span>");
			//	floorHtml=null;
				
			}
			else if(!url.endsWith("/") && floorurl.startsWith("/")) {
					//U.log("hello:::::::"+U.getHTML(domain+floorurl));\
				U.log("hello");
					floorHtml=U.getHtml(domain+floorurl,driver);
					if(floorHtml.length()<2)floorHtml = U.getHtml(domain+floorurl,driver);
			}
			else if(url.endsWith("/") && !floorurl.startsWith("/")) {
				floorHtml=U.getHtml(domain+floorurl,driver);
				
			}
			
		
		}
		else {
			try {
			floorHtml=U.getHtml(floorurl,driver);
			if(floorHtml.length()<2)
				
				floorHtml = U.getHtml(floorurl,driver);
				}catch (Exception e) {
				}
			
		}
		if(floorHtml==ALLOW_BLANK) {
			try {
			floorHtml=U.getHtml(domain+"/"+floorurl,driver);
			if(floorHtml==null)floorHtml="-";
			}catch (Exception e) {
				// TODO: handle exception
				floorHtml="-";
			}
		}
		
	  String myFloorHtml=ALLOW_BLANK;
		if(floorHtml!=null) {
		String[] myFloors=U.getValues(floorHtml, "<div class=\"col-12  my-2\">", "</a>");
		for(String myFloor:myFloors) {
			
			String mfloor=U.getSectionValue(myFloor, "<a href=\"", "\"");
			U.log("mfloor:: "+mfloor);
			if(domain.endsWith("/") && !mfloor.startsWith("/")) {
			myFloorHtml+=" "+U.getHtml(domain+mfloor,driver);
			U.log("M11");
			}
			else if(!domain.endsWith("/") && !mfloor.startsWith("/")) {
			   myFloorHtml+=" "+U.getHtml(domain+"/"+mfloor,driver);
			   U.log("M22");  
			}
			else if(!domain.endsWith("/") && mfloor.startsWith("/")) {
				myFloorHtml+=" "+U.getHtml(domain+mfloor,driver);
				 U.log("M33");  
			}
		}
		}
		if(url.contains("theartessa")) {
			floorurl ="https://www.securityproperties.com/theartessa/franklin/the-artessa-apartments/conventional/";
			mapUrl ="https://theartessa.securityproperties.com/franklin/the-artessa-apartments/map-and-directions/";
			floorHtml =U.getHTML(floorurl);
		}
		
	//	U.log(">>>>>>>>>..M "+Util.matchAll(floorHtml, "[\\w\\s\\W]{30}patios[\\w\\s\\W]{30}", 0));
//		U.log("kkkkkkkkkk111 "+Util.matchAll(floorHtml, "[\\s\\w\\W]{100}620 Sq.Ft[\\s\\w\\W]{200}", 0));

		
		String notes = ALLOW_BLANK;
		String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		add[0] = U.getSectionValue(comHtml, "address_street\">", "<");
		add[1] = U.getSectionValue(comHtml, "address_city\">", "<");
		add[2] = U.getSectionValue(comHtml, "\"address_state\">", "<");
		add[3] = U.getSectionValue(comHtml, "address_zip\">", "<");
		if(add[0]== null && comHtml.contains(">Find Us</span>")) {
			String addSec = U.getSectionValue(comHtml, " <span class=\"homepage__location-subtitle heading\">Find Us</span>", "</a>");
			add = U.findAddress(addSec);
		}
		if(add[0]== null && comHtml.contains("<address>")) {
			String addSec = U.getSectionValue(comHtml, "<address>", "</address>");
			add = U.getAddress(addSec);
		}
		
		if(add[0]== null && mapSec != null) {
			add[0] = U.getSectionValue(mapSec, "\"streetAddress\": \"", "\"");
			add[1] = U.getSectionValue(mapSec, "\"addressLocality\": \"", "\"");
			add[2] = U.getSectionValue(mapSec, "\"addressRegion\": \"", "\"");
			add[3] = U.getSectionValue(mapSec, "\"postalCode\" : \"", "\"");
		
		}
		if(add[0]== null && mapSec.contains("<div class=\"address\">")) {
			String addSec = U.getSectionValue(mapSec, "<div class=\"address\">", "<br><a href=\"");
			U.log(addSec);
			add = U.findAddress(addSec);
		}
		if(add[0]== null && mapSec.contains("<span data-selenium-id='address_street'>")) {
			add[0] = U.getSectionValue(mapSec, "<span data-selenium-id='address_street'>", "<");
			add[1] = U.getSectionValue(mapSec, "<span data-selenium-id='address_city'>", "<");
			add[2] = U.getSectionValue(mapSec, "<span data-selenium-id='address_state'>", "<");
			add[3] = U.getSectionValue(mapSec, "<span data-selenium-id='address_zip'>", "<");
		}
		if(add[0]!=null)
		  add[0]=add[0].replace("&nbsp;", "");
		U.log("My Address is"+Arrays.toString(add));
//		U.log("--=-==--"+mapSec);
		if((add[0]== ALLOW_BLANK ||add[0]==null)&& mapSec!=null) {
			if(mapSec.contains("href=\"http://maps.google.com?q=")) {
				String asec = U.getSectionValue(mapSec, " href=\"http://maps.google.com?q=", "</a>';");
				if(asec!=null)asec=asec.replace("Gilbert AZ,", "Gilbert<br> AZ");
				add =U.findAddress(asec);
			}
			if(comHtml.contains("href=\"http://maps.google.com/maps?q=")) {
				String asec = U.getSectionValue(comHtml, "href=\"http://maps.google.com/maps?q=", "</a>");
				if(asec!=null)asec=asec.replace("Castle Rock, <br>CO 80108", "Castle Rock<br>CO 80108");
				add =U.findAddress(asec);
			}
//			U.log("HERERER");
			if(comHtml.contains("href='http://maps.google.com?q=")) {
				U.log("HERERER");	
				String asec = U.getSectionValue(comHtml, "href='http://maps.google.com?q=", "</a>");
				U.log("--==--"+asec);
				if(asec!=null)asec=asec.replace("Castle Rock, <br>CO 80108", "Castle Rock<br>CO 80108").replaceAll("Touchstone Modern Apartment Homes|The Flats at SanTan", "");
				add =U.findAddress(asec);
			}
		}
		if(mapSec.contains("\"address\": \"")) {
			String asec = U.getSectionValue(mapSec, "\"address\": \"", "\"");
			add = U.findAddress(asec);
		}
		if(mapSec.contains("<p class=\"header__contact\">")) {
			String asec = U.getSectionValue(mapSec, "<a class=\"header__contact--link\" target=\"_blank\"", "</p>");
			asec = U.getSectionValue(asec, ">", "<");
			U.log(asec);
			asec=asec.replace("Carrollton", ",Carrollton");
			add = U.getAddress(asec.trim());
		}
		if(mapSec.contains("<span itemprop=\"streetAddress\">")) {
			add[0] = U.getSectionValue(mapSec, "<span itemprop=\"streetAddress\">", "<");
			add[1] = U.getSectionValue(mapSec, " <span itemprop=\"addressLocality\">", "<");
			add[2] = U.getSectionValue(mapSec, "<span itemprop=\"addressRegion\">", "<");
			add[3] = U.getSectionValue(mapSec, "<span itemprop=\"postalCode\">", "<");
		}
		if(mapSec.contains("<span class=\"street-address\">")) {
			add[0] = U.getSectionValue(mapSec, "<span class=\"street-address\">", "<");
			add[1] = U.getSectionValue(mapSec, "<span class=\"locality\">", ", </span>");
			add[2] = U.getSectionValue(mapSec, "<span class=\"region\">", " <");
			add[3] = U.getSectionValue(mapSec, "<span class=\"postal-code\">", "</span>");
		}
		if(comHtml.contains("<address class=\"vls-property\">")) {
			String asec = U.getSectionValue(mapSec, "<address class=\"vls-property\">", "</address>");
			add = U.findAddress(asec);
		}
		if(url.contains("apartmentsforrentsanantoniotx")) {
			String asec = "6522 Camp Bullis Road, San Antonio, TX 78256";
			if(asec!=null)
			add = U.findAddress(asec);
		}
		if(url.contains("liveatthecollection")) {
			String asec = "4025 Huffines Blvd,Carrollton,TX 75010";
			if(asec!=null)
			add = U.findAddress(asec);
		}
		if(url.contains("liveatriata.com")) {
			String asec = "100 N. Hearthstone Way, Chandler, AZ 85226";
			if(asec!=null)
			add = U.findAddress(asec);
			geo="False";
		}
		if(add[0] != null) add[0] = add[0].replaceAll("Riata, |Westerly Apartments, |Domain at The Gate, ", "");
//		U.log(Arrays.toString(add));
		
		//========== Latlong ============
		
//		if(url.contains("https://www.westerlyapartmenthomes.com/"))
//			mapSec = U.getHtml(domain+"/"+mapUrl, driver);
		
				String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
				String note = ALLOW_BLANK;
//				U.log("mapUrl>> "+mapUrl);
				
				//U.log("mapSec======= "+mapSec);
				
				if(mapSec != null) {U.log("==============================================================================");
					latlng[0] = U.getSectionValue(mapSec, "var latitude = \"", "\"");
					latlng[1] = U.getSectionValue(mapSec, "var longitude = \"", "\"");
					
					U.log("Latlong1: "+Arrays.toString(latlng));
					
					if(mapSec.contains("\"@type\": \"GeoCoordinates\",")) {
						latlng[0] = U.getSectionValue(mapSec, "\"latitude\": \"", "\"");
						latlng[1] = U.getSectionValue(mapSec, "\"longitude\": \"", "\"");
						U.log("Latlong2: "+Arrays.toString(latlng));
					}
				}
//				U.log("nnnnnn>> "+Arrays.toString(latlng));
				if(mapSec.contains("\"@type\" : \"GeoCoordinates\",") && (latlng[0]==null || latlng[0].length()<2)) {
					latlng[0] = U.getSectionValue(mapSec, "latitude\": ", ",");
					latlng[1] = U.getSectionValue(mapSec, "\"longitude\": ", "}");
					U.log("Latlong3: "+Arrays.toString(latlng));
				}
//				U.log("nnnnnn>> "+Arrays.toString(latlng));
				if(mapSec.contains("https://www.google.com/maps/embed?pb=!")) {
					String latSec = U.getSectionValue(mapSec, "https://www.google.com/maps/embed?pb=", "\"");
					latlng[1] = U.getSectionValue(latSec, "!2d", "!");
					latlng[0] = U.getSectionValue(latSec, "3d", "!");
					U.log("Latlong4: "+Arrays.toString(latlng));
				}
//				U.log("LLLLLL>> "+Arrays.toString(latlng));
				
				if(comHtml.contains("itemprop=\"latitude\" content=\"") && (latlng[0]== null||latlng[0].length()<1)) {
					latlng[0] = U.getSectionValue(comHtml, " itemprop=\"latitude\" content=\"", "\"");
					latlng[1] = U.getSectionValue(comHtml, "itemprop=\"longitude\" content=\"", "\"");
					U.log("Latlong5: "+Arrays.toString(latlng));
				}
				if(comHtml.contains("<div class=\"cms-map\" data-cms=\"map\"") && (latlng[0]== null||latlng[0].length()<1)) {
					latlng[0] = U.getSectionValue(comHtml, "data-lat=\"", "\"");
					latlng[1] = U.getSectionValue(comHtml, "data-lng=\"", "\"");
				}
				if(comHtml.contains("href=\"https://maps.google.com/maps?ll=")) {
					String latSec = U.getSectionValue(comHtml, "href=\"https://maps.google.com/maps?ll=", "&amp;z=");
					latlng =latSec.split(",");
				}
//				U.log(Util.matchAll(mapSec, "[\\w\\s\\W]{100}maps[\\w\\s\\W]{100}", 0));
				if(mapSec.contains("https://maps.google.com/maps?ll=")) {
					String latSec = U.getSectionValue(mapSec, "https://maps.google.com/maps?ll=", "&amp;z=");
					latlng =latSec.split(",");
					U.log("Latlong6: "+Arrays.toString(latlng));
				}
				
				U.log("Latlong FINAL: "+Arrays.toString(latlng));
				
				if(url.contains("https://www.7600broadway.com/")) {
					add[1]="San Antonio";
					add[2]="TX";
					latlng=U.getlatlongHereApi(add);
					add=U.getAddressGoogleApi(latlng);
					geo="True";
					//note="Address taken from city and state";
				}
		
				
				if(add[0] == null || add[0].length()<3 || add[3] == null) {
					
					if(latlng[0] == null) {
						
						String city = U.getSectionValue(comSec, "<span class=\"city\">", "<");
						String state = U.getSectionValue(comSec, "<span class=\"state\">", "<").replace(",", "");
						add[1] = city;
						add[2] = state;
						
						latlng = U.getlatlongGoogleApi(add);
						if(latlng == null) latlng = U.getlatlongHereApi(add);
						
					}
					add = U.getAddressGoogleApi(latlng);
					if(add == null) add = U.getAddressHereApi(latlng);
//					U.log("Address From Google: "+Arrays.toString(add));
					geo = "TRUE";
				}
				
				if(latlng[0] == null) {
					
					latlng = U.getlatlongGoogleApi(add);
					if(latlng == null) latlng = U.getlatlongHereApi(add);
//					U.log("Latlong From Google: "+Arrays.toString(latlng));
					geo = "TRUE";
				}
				
				
				//========== Price ==============
				comHtml=comHtml.replace("Starting in the $1100's and 2 Bedroom Homes Starting in the $2100's", "Starting in the $1,100,000 and 2 Bedroom Homes Starting in the $2,100,000");
				String[] price = U.getPrices(comHtml+floorHtml, "Starting in the \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
				
				price[0] = (price[0] == null) ? ALLOW_BLANK : price[0];
				price[1] = (price[1] == null) ? ALLOW_BLANK : price[1];	
				
				U.log("Price: "+Arrays.toString(price));
				
				//========== Sqft ==============
//				U.log(floorHtml);
				if(floorplanSec!=null) {
					floorplanSec=floorplanSec.replace(">Sq.Ft.:</span>\n" + 
							"												<span data-selenium-id=\"Floorplan0SqFt\">", ">Sq.Ft.:");
				}
				if(floorHtml != null)
				floorHtml = floorHtml.replace("SF(1).png", "").replaceAll("<td data-label=(\"|')SQ. FT.(\"|') data-selenium-id=(\"|')Sqft_\\d(\"|') class=(\"|')tcolumn text-center(\"|')>", "Square Feet ")
				.replace("490-<span class=\"sr-only\">to</span>513 Sq.Ft.", "490-513 Sq.Ft.").replaceAll("</div>\n\\s+<div class=\"statLabel\" role=\"text\" aria-label=\"square feet\">sq ft", " sq ft").replaceAll("propMinSqft: \\d+|propMaxSqft: \\d+|086 Sq. Ft.|SF.png|SF\\(1\\).png", "").replaceAll("SQ.FT.</strong></td><td data-selenium-id =\"Sqft_\\d+\">", "SQFT ").replace("078 Sq. Ft.", "")
				.replaceAll("</div>\\s+<div class=\"statLabel\" aria-hidden=\"true\">Sq Ft<", " Sq Ft<");
				comHtml = comHtml.replace("SF(1).png", "").replace("078 Sq. Ft.| 086 Sq. Ft.", "").replaceAll("propMinSqft: \\d+|propMaxSqft: \\d+", "");
				String[] sqft = U.getSqareFeet((comHtml+floorplanSec+floorHtml).replaceAll("\\d+</div><div class=\"filters__graph", ""), 
						"\\d{3}-<span class=\"sr-only\">to</span>\\d{3} Sq.Ft.|SqFt\">\\d,\\d{3}</span>|SqFt\">\\d{3}</span>|</span>\\d{3} Sq.Ft.</div>|\\d{3}-\\d{3} Sq.Ft.|>\\d+-\\d+ square feet|Sq. Ft</span><span class=\"fp-col-text\">\\d,\\d{3}|Sq. Ft</span><span class=\"fp-col-text\">\\d{3}|>\\d+ square feet|\\d,\\d{3} Sq.Ft.|>\\d+ SqFt</div>|item\">(\\d,)?\\d{3} Sqft</li>|<td data-selenium-id=\"Sqft_\\d+\">\\d,\\d+</td>|\"Sqft_\\d+\">\\d{3,4} -<span class=\"sr-only\">to</span> \\d+</td>|\"Sqft_1\">\\d+|ranging from (\\d,)?\\d{3} to \\d,\\d{3} square feet|>Up to \\d,\\d{3} <span class=\"fp-sqft\">sq. ft.</span>|<span class=\"ng-binding\">\\d,\\d{3}</span> <span class=\"sub\">SQFT|<span class=\"ng-binding\">\\d{3}</span> <span class=\"sub\">SQFT|>Up to \\d{3,4} <span class=\"fp-sqft\">sq. ft.</span>|\"FPsqft_0\">\\d{3,4}| <span class=\"fp-sqft\">sq. ft.</span>|\\d,\\d{3} sq ft|\\d{4} sq ft|\\d{3} sq ft|Square Feet \\d,\\d{3} -<span class='sr-only'>to</span> \\d,\\d{3}</td>|Square Feet \\d,\\d{3}|Square Feet \\d{3} -<span class='sr-only'>to</span> \\d{3}</td>|Square Feet \\d{3}|<div class=\"unit-size\">\\d,\\d{3} Sq. Ft.</div>|<div class=\"unit-size\">\\d{3} Sq. Ft.</div>|\\d,\\d{3} Sq. Ft.|\\d{3} Sq. Ft.|sqft: \"\\d,\\d{3}|sqft: \"\\d{3}|\\d,\\d{3} <span class=\"fp-sqft\">sq. ft.|\\d{3} <span class=\"fp-sqft\">sq. ft.|\\d{3} to \\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} square feet|\\d{3,4} <span class=\"fp-sqft\">sq. ft.</span>|\\d,\\d{3} Sq. Ft.|\\d{3,4} sq.ft.</span>|\\d{3,4} sq. ft.|SQFT \\d,\\d{3}|SQFT \\d{3,4}|SQFT \\d,\\d{3} -<span class='sr-only'>to</span> \\d,\\d{3}|SQFT \\d{3,4} -<span class='sr-only'>to</span> \\d,\\d{3}|SQFT \\d{3,4} -<span class='sr-only'>to</span> \\d{3,4}|sqft: \\d{3,4}|\\d,\\d{3}<span class=\"sr-only\">Square feet|\\d{3}<span class=\"sr-only\">Square feet|Sq. Ft</span><span class=\"fp-col-text\">\\d,\\d{3}|Sq. Ft</span><span class=\"fp-col-text\">\\d{3,4}|<span>\\d{3} sq. ft|\\d{3,4} Sq.Ft.|\\d{3} SF|\\d{4} SF|\\d,\\d{3}sqft</p>|\\d{4}sqft</p>|\\d{3}sqft</p>|SqFt\">\\d,\\d{3}|SqFt\">\\d{3}", 0);
//				U.log(Util.matchAll(floorplanSec, "[\\w\\s\\W]{200}Sq.Ft[\\w\\s\\W]{200}", 0));
				sqft[0] = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				sqft[1] = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];	
				
				U.log("SquareFeet: "+Arrays.toString(sqft));
				
				if(url.contains("https://cortland.com/apartments/cortland-walker-ranch/")) {
					sqft[0]="613";   
					sqft[1] ="1830";
				}
				if(url.contains("https://cortland.com/apartments/cortland-brackenridge/")) {
					sqft[0]="594";   
					sqft[1] ="1542";
				}
				
				
//				U.log("kkkkkkkkkk "+Util.matchAll(floorHtml, "[\\s\\w\\W]{50}1,600[\\s\\w\\W]{100}", 0));
//				U.log("kkkkkkkkkk "+Util.matchAll(comHtml, "[\\s\\w\\W]{50}1,900[\\s\\w\\W]{100}", 0));

				//============Comumity type ============
				comHtml= comHtml.replace("resort-inspired experience", "Resort-style");
				String  comType = U.getCommType(comHtml+amenities).replace("resort-style fresh swimming pool", "resort-style swimming pools");
				U.log("Commuinty Type: "+comType);
//				U.log(">>>>>>>>>.. "+Util.matchAll(comHtml, "[\\w\\s\\W]{30}resort[\\w\\s\\W]{30}", 0));
//				U.log(">>>>>>>>>.. "+Util.matchAll(amenities, "[\\w\\s\\W]{30}resort[\\w\\s\\W]{30}", 0));
				
				//========= Property Type ==============
				comHtml=comHtml.replaceAll("living with luxurious style|luxury of serene", "luxury homes").replace("Estates at Bee Cave", "Estate Residences")
						.replace("traditional flat apartments", "traditional style flat apartments");
				
				if(amenities != null) amenities = amenities.replaceAll(" luxurious experience|enjoy additional luxuries", "luxury homes");
			//	U.log(">>>>>>>>>.. "+Util.matchAll(comHtml+floorHtml+amenities+myFloorHtml, "[\\w\\s\\W]{30}patios[\\w\\s\\W]{30}", 0));
				
				String pType = U.getPropType((comHtml+floorHtml+amenities+myFloorHtml)
						.replaceAll("vertical.multifamily|multifamily.exp.|Carriage House</a>|Ranch Elementary|arden-style soaking tubs", ""));
				U.log("Property Type: "+pType);
				
//				U.log(">>>>>>>>>.. "+Util.matchAll(comHtml, "[\\w\\s\\W]{30}multifamily[\\w\\s\\W]{30}", 0));
//				U.log(">>>>>>>>>.. "+Util.matchAll(floorHtml, "[\\w\\s\\W]{30}multifamily[\\w\\s\\W]{30}", 0));
//				U.log(">>>>>>>>>.. "+Util.matchAll(amenities, "[\\w\\s\\W]{30}multifamily[\\w\\s\\W]{30}", 0));

				//======== Derived Type ============
				String rem = U.getSectionValue(comHtml, "<div class=\"nearby-communities", "<footer class=\"footer\">");
				if(rem!=null)
					comHtml = comHtml.replace(rem, "");
				
				String dType = U.getdCommType((comHtml+amenities+floorHtml).replaceAll("Second Story Fitness Center|two-story elite fitness|two-story [f|F]itness|story outdoor lounge| \"Canyon Ranch\" : \"/dmslivecafe/2/111265/canyon-ranch-|Ranch Elementary", ""));
				U.log("Derived Tyupoe: "+dType);
				
				//======== Property Status ==============
				comHtml=comHtml.replace("line-height:1.2;\">Coming Soon</p>", "");
				String status = U.getPropStatus((comHtml+comSec).replaceAll("Now Open! Fort Worth's newest luxury community|READY TO MOVE IN?|<div class=\"text-3x font-weight-bold font-heading mb-3 mb-lg-0\">READY TO MOVE IN</div>|line-height:1.2;'>Coming Soon</p>|<h2>Ready To Move In\\?</h2>|Now Open! Schedule a Tour Today!|Ready to move in\\?|Ready to move in? Enter a date", "").replaceAll("free on move-in|other move-in|Units Now Available|free on move-in ready units|tour options now available|Studio\n\\s+</strong>\n\\s+<p>Coming Soon</p>|content: \"Coming Soon To Littleton\"|Open for Tours|Bed\\s+</strong>\\s+<p>Coming", ""));
//				U.log("kkkkkkkkkk "+Util.matchAll(comSec, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{200}", 0));

				U.log("Status :"+status);
				
				
				
				if(add[0].length()<=3 || add[0] == null) {
					add[0] = ALLOW_BLANK;
					add[1] = ALLOW_BLANK;
					add[2] = ALLOW_BLANK;
					add[3] = ALLOW_BLANK;
				}
					
				if(add[2].length()>2) {
					add[2]=USStates.abbr(add[2]);
				}
				//https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/

				if(url.contains("https://www.rentanapt.com/apartments/az/phoenix/las-colinas-at-black-canyon/")) {
					//sqft[0] = "757";
					//sqft[1] = "1,644 ";
				}
				
				if(url.contains("https://www.thestandardatlegacy.com/"))comName = "THE STANDARD AT LEGACY";
				if(url.contains("https://www.encoreatboulevardone.com/"))comName = "ENCORE AT BOULEVARD ONE";
				if(url.contains("https://www.domainatthegate.com/")||url.contains("https://www.liveatthekelley.com")||url.contains("https://www.encoreatboulevardone.com")
						||url.contains("https://www.escapeatarrowhead.com/")||url.contains("https://www.liveatfoundersparc.com/")||
						url.contains("https://www.knoxmetrocenter.com/")||url.contains("https://www.thecanplant.com/")||url.contains("https://www.liveatslatecreek.com/")
						||url.contains("https://www.liveattouchstone.com/")) {
					geo="FALSE";
				}
				if(url.contains("https://www.agorastoneoak.com/")) {
					status=ALLOW_BLANK;
					pType=pType+", Luxury Homes";
							comType=comType+", Resort Style";
				}
				if(url.contains("theartessa.securityproperties.com")) {sqft[0]="713";sqft[1]="1,208";}
				if(url.contains("https://www.liveattouchstone.com/"))note ="Now Leasing";
				if(url.contains("https://www.apartmentsforrentsanantoniotx.com")){sqft[0]="806";sqft[1]="1,424";}
				if(url.contains("thestandardatlegacy")){sqft[0]="460";sqft[1]="2,256";}
				pType=pType.replace(", Townhouse", "");
				latlng[0] = latlng[0].replace("\"", "");
				latlng[1] = latlng[1].replace("\"", "");
				add[0]=add[0].replace("&nbsp;", "");
				if(url.contains("/Venue-at-the-Promenade-Apartments"))status = ALLOW_BLANK;
				if(url.contains("https://www.liveatthecanneryapartments.com/")||url.contains("https://www.liveatthekelley.com/"))note="Now Leasing";// from pop-up img
//				if(url.contains("https://cortland.com/apartments/cortland-brackenridge/") || url.contains("https://cortland.com/apartments/cortland-walker-ranch/")) {
//				if(url.contains("https://www.embreydc.com/embrey-projects/everly/")) nots = "Now Leasing"; //Img from its own website
                if(url.contains("https://www.livebrightleaf.com/")||url.contains("https://www.livetheupland.com/")||url.contains("https://www.theharperliving.com"))
                	pType=pType+", Patio Homes";
			
                
                note=U.getnote(comSec+comHtml);
				
                U.log("note: "+note);
               // U.log(">>>>>>>>>.. "+Util.matchAll(comSec, "[\\w\\s\\W]{10}leasing[\\w\\s\\W]{10}", 0));
               if(url.contains("https://www.7600broadway.com/")) note = note + ", Address taken from city and state"; 
                
                
				String noOfUnits=ALLOW_BLANK;
				if(comHtml.contains("Site Map")&& !comHtml.contains("<a href=\"location.aspx\"")) {
					String siteMapSec=U.getSectionValue(comHtml, "<a data-selenium-id=\"mobile_SiteMapaspx_MenuLink\"", "</a>");
					if(siteMapSec==null) {
						siteMapSec=U.getSectionValue(comHtml, "id=\"primarymenulink", "data-selenium-id=\"locationaspx_MenuLink\">");
					}
					
					String siteMapUrl=url+U.getSectionValue(siteMapSec, "href=\"", "\"");
//					if(siteMapUrl.contains("location.aspx")) {
//						siteMapUrl=url+siteMapUrl;
//					}
					JsonArray arr=getUnit(siteMapUrl);
					int lotCount=arr.size();
					noOfUnits=Integer.toString(lotCount);
					
					if(noOfUnits.equals("0"))
						noOfUnits=ALLOW_BLANK;
					U.log("No Of Units"+noOfUnits);
				}
				if(comHtml.contains("Site Map")&&comHtml.contains("<a href=\"location.aspx\"")) {
					String siteMapUrl=url+"location.aspx";
					JsonArray arr=getUnit(siteMapUrl);
					int lotCount=arr.size();
					noOfUnits=Integer.toString(lotCount);
					
					if(noOfUnits.equals("0"))
						noOfUnits=ALLOW_BLANK;
					U.log("No Of Units"+noOfUnits);
				}
				
				data.addCommunity(comName.toLowerCase(), url, comType);
				data.addAddress(add[0].replace("�", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
				data.addPropertyType(pType, dType);
				data.addSquareFeet(sqft[0], sqft[1]);
				data.addPrice(price[0], price[1]);
				data.addPropertyStatus(status);
				data.addNotes(note);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
                data.addUnitCount(noOfUnits);
//		}catch (Exception e) {}
		}   j++;
	}		
		
		
	}
  private JsonArray getUnit(String siteMapUrl) throws Exception {
	U.log("siteMapUrl"+siteMapUrl);
	
	String siteMapHtml=U.getHtml(siteMapUrl, driver);
	String siteSec=U.getSectionValue(siteMapHtml, "<iframe", "</iframe>");
	U.log("siteSec"+siteSec);
	if(siteMapUrl.contains("/location.aspx")){
		U.log("HIIII");
		siteSec=U.getSectionValue(siteMapHtml, "class=\"custompage\"><iframe", "</iframe>");
		U.log("lll"+siteSec);
	}
	String siteUrl=U.getSectionValue(siteSec, "src=\"", "\"");
	
	U.log("URLLL"+siteUrl);
	String siteHtml=U.getHtml(siteUrl, driver);
	U.log("KKK"+U.getCache(siteUrl));
	//U.log("++++"+siteHtml);
	String siteSec2=U.getSectionValue(siteHtml, "window.__APP_CONFIG__ = {", "}]");
	U.log(siteSec2);
	String mSiteUrl=U.getSectionValue(siteSec2, "\"href\":\"", "\"").replace("\\", "");
	U.log("jjj"+mSiteUrl);
	String mapJson=U.getHTML(mSiteUrl);
	if(mapJson!=null) {
	JsonParser parser=new JsonParser();
	JsonObject homeJs=(JsonObject) parser.parse(mapJson);
    
    JsonArray homes=homeJs.get("data").getAsJsonObject().get("units").getAsJsonArray();
    int lotCount=homes.size();
    U.log("number of units"+lotCount);
    return homes;
	//U.log("MMMMMM"+mapJson);
	}
	return null;
	}
				

	
	private void findApartmentsUrls(String regUrl) throws Exception {
		
		String regHtml = U.getHtml(regUrl,driver);
		String apartSec = U.getSectionValue(regHtml, "<nav id=\"project-list\">", "</nav>");
		
		String[] apartUrls = U.getValues(apartSec, "href=\"", "\"");
		U.log(apartUrls.length);
		String regPropertyType = "Apartments + Multi-Family ";
		//----Extract Apartments Data
		for(String apartUrl : apartUrls){
			//U.log("apartUrl : "+apartUrl);
			if(regUrl.contains("garden-apartments/")){
				regPropertyType += "Garden Home";
			}
			ExtractApartmentData(apartUrl,regPropertyType);
		}
		
	}
	private void ExtractApartmentData(String apartUrl,String regPropertyType) throws Exception {
		//TODO : For Single Community Execution
//		if(j == 0)
//		if(!apartUrl.contains("https://www.embreydc.com/embrey-projects/dominion-apartments/"))return;
		{
//			if(apartUrl.contains("https://www.embreydc.com/embrey-projects/flats-santan/"))return;//community web link not oprning
			
			if (data.communityUrlExists(apartUrl)) {
				LOGGER.AddCommunityUrl("------REPEATED-------" + apartUrl);
				return;
			}
			LOGGER.AddCommunityUrl(apartUrl);

			
			String comUrl = apartUrl;
			U.log(j+"\tcomUrl :: "+comUrl);
			String aptHtml = U.getHtml(comUrl,driver);
			
			//----Community NAme------
			String comName = U.getSectionValue(aptHtml, "<h2>", "</h2>");
			comName = comName.replace("&#038;", "&");
			U.log("comName : "+comName);
			
			String mapHtml = ALLOW_BLANK;
			String floorHtml = ALLOW_BLANK;
			String amenHtml = ALLOW_BLANK;
			//-----------Individual community site of each community-----------
			String ownComUrl = Util.match(aptHtml, "Website:</span><span class=\"right\">\\s*<a href=\"(.*?)\"",1);
			U.log("ownComUrl : "+ownComUrl);
			String ownComHtml = ALLOW_BLANK;
			if(ownComUrl !=null ){
				ownComUrl = ownComUrl.replace("http:", "https:");
				if(ownComUrl.contains("https://www.FlatsAtSanTan.com")) ownComUrl = "https://www.weidner.com/gilbert/flats-at-san-tan/";
				ownComHtml = U.getPageSource(ownComUrl);
//				U.log(Util.match(ownComHtml, "/floor(.*?)\""));
				String[] navSecUrls = U.getValues(ownComHtml, "<li class=\"mainnavlink\" id=\"primarymenulink", "</a>");
//				U.log(navSecUrls.length+"=== urls");
				if(navSecUrls.length == 0){
					String navSection = U.getSectionValue(ownComHtml, "<nav class=\"navigation", "</nav>");
//					U.log(navSection);
					if(navSection == null) navSection = U.getSectionValue(ownComHtml, "<ul class=\"side-menu__nav\">", "</ul>");
//					U.log(navSection);
					if(navSection != null)
						navSecUrls = U.getValues(navSection, "<li", "</a>");
					
				}
				for(String navSecUrl : navSecUrls){
//					U.log("***"+navSecUrl);
					String _navSecUrl = 	U.getSectionValue(navSecUrl, "<a href=\"", "\"");
					if(_navSecUrl == null)  _navSecUrl = 	U.getSectionValue(navSecUrl, "href=\"", "\"");
					navSecUrl = _navSecUrl;
					U.log("navSecUrl : "+navSecUrl);
					if(navSecUrl.contains("floorplans")){
						U.log("---"+ownComUrl+"/"+navSecUrl);
						floorHtml = U.getHtml(ownComUrl+"/"+navSecUrl,driver);
					}
					if(navSecUrl.contains("amenities")){
						amenHtml = U.getPageSource(ownComUrl+"/"+navSecUrl);
					}
					if(navSecUrl.contains("mapsanddirections")){
						mapHtml = U.getPageSource(ownComUrl+"/"+navSecUrl);
					}
				}
				if(ownComUrl.contains("https://www.canyonsatsaddlerockapts.com")){
					navSecUrls = U.getValues(ownComHtml, "<a class=\"header-nav-", "</a>");

					for(String navSecUrl : navSecUrls){					
						navSecUrl = 	U.getSectionValue(navSecUrl, "href=\"", "\"");
						U.log("navSecUrl : "+navSecUrl);
						if(navSecUrl.endsWith("canyons-at-saddle-rock/")){
							floorHtml = U.getHtml(navSecUrl,driver);
						}
						if(navSecUrl.contains("amenities")){
							amenHtml = U.getPageSource(navSecUrl);
						}
						if(navSecUrl.contains("map-and-directions/") || navSecUrl.contains("mapsanddirections")){
							mapHtml = U.getPageSource(navSecUrl);
						}
					}
				}
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/brackenridge-midtown/")){
				floorHtml = U.getHtml("https://www.liveatbrackenridge.com/floor-plans.aspx",driver);
			}
			if(comUrl.contains("/embrey-projects/dominion-apartments/")){
				amenHtml = U.getHtml("https://www.grandatdominion.com/customamenities.aspx",driver);
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/west-ave-2/")){
				floorHtml = U.getHtml("https://www.parkatwestave.com/floor-plans.aspx",driver);
				floorHtml += U.getHtml("https://www.parkatwestave.com/home.aspx",driver);
			}
			
			/*if(comUrl.contains("https://www.embreydc.com/embrey-projects/ken-caryl/")){
				floorHtml = U.getHTML("https://www.bellapartmentliving.com/co/littleton/bell-ken-caryl/floorplans.aspx");
			}*/
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/west-end-at-city-center-2/")){
				floorHtml = U.getHtml("https://www.westendatcitycenter.com/apartments/ks/lenexa/floor-plans#/categories/all/floorplans",driver);
			}
			
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/dwell-legacy/")){
				floorHtml = U.getHtml("https://www.liveatlegacyapartments.com/apartments/tx/san-antonio/floor-plans",driver);
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/estates-bee-cave/")){
				floorHtml = U.getHtml("https://www.estatesatbeecave.com/apartments/tx/bee-cave/floor-plans#/categories/all/floorplans",driver);
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/greenvue/")){
				floorHtml = U.getHtml("https://www.liveatgreenvue.com/apartments/tx/richardson/floor-plans#/categories/all/floorplans",driver);
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/the-residences-at-the-collection/")){
				floorHtml = U.getHtml("https://liveatthecollection.com/floorplans/",driver);
			}
			
			
			if(floorHtml==null || floorHtml.length()<30 && ownComUrl!=null){
				//U.log(ownComHtml);
				String flurl=Util.match(ownComHtml, "\\=\"(.*?)/floor(.*?)\"");
				U.log("* flurl :"+flurl);
				if(flurl!=null) {
					flurl=flurl.replaceAll("=\"header-nav-link\" href=\"|\"|\\=|header-nav-link href", "");
				}
				U.log("** flurl :"+flurl);
//				if(ownComUrl.contains("www.domainatmidtownpark.com"))flurl="https://www.domainatmidtownpark.com/apartments/tx/dallas/floor-plans#/categories/all/floorplans";
				if(ownComUrl.contains("https://www.liveattheconnection.com")){
					flurl="https://bhmanagement.com/communities/connection-at-buffalo-pointe/";
					floorHtml=U.getHtml(flurl,driver);
					}
				else{
					if(flurl != null && flurl.startsWith("http")){
						floorHtml=U.getHtml(flurl,driver);
					}
					else if(flurl != null && !flurl.startsWith("http")) floorHtml=U.getHtml(ownComUrl.replaceAll("https:", "https:")+flurl,driver);
				}
				U.log(flurl);
				if(flurl!=null) {
					
					//https://www.liveatbrackenridge.comhttps//cs-cdn.realpage.com/CMS/C6964/CMSScripts/Custom/RPWebParts/floorplan-V3.js
				//U.log(ownComUrl+Util.match(ownComHtml, "/floor(.*?)\"").replaceAll("\"", ""));
				}
			}
			//---------Address----------
			String notes = ALLOW_BLANK;
			String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
			String addSec = U.getSectionValue(aptHtml, "Address:</span><span class=\"right\">", "</span>");
			U.log("addSec : "+addSec);
					
			if(addSec != null){
				addSec = addSec.replace("Boulevard  Dallas", "Boulevard,  Dallas").replace(" Texas 75081", " TX 75081")
						.replace("CO, 80021<br />", "CO 80021").replaceAll(" <br />\\s+<br />", "");
				U.log(addSec);
				String[] temp = addSec.split(",");
				if(temp.length==3){
					add[0] = temp[0];
					add[1] = temp[1];
					U.log(temp[2]);
					add[3] = Util.match(temp[2], "\\d+");
					add[2] = Util.match(temp[2], "\\w+");
					if(add[2].trim().length()>2){
						add[2] = USStates.abbr(add[2]);
					}
				}
			}
			U.log("Address is " + Arrays.toString(add));
			if (ownComHtml.contains("streetAddress\"") && add[3]==null) {
				add[0]=U.getSectionValue(ownComHtml, "\"streetAddress\": \"", "\"");
				add[1]=U.getSectionValue(ownComHtml, "\"addressLocality\": \"", "\"");
				add[2]=U.getSectionValue(ownComHtml, "\"addressRegion\": \"", "\"");
				add[3]=U.getSectionValue(ownComHtml, "\"postalCode\" : \"", "\"");
				if (add[3]==null) {
					add[3]=U.getSectionValue(ownComHtml, "\"postalCode\": \"", "\"");	
				}
				if(add[0] == null && add[3] == null){
					add[0]=U.getSectionValue(ownComHtml, "\"streetAddress\":\"", "\"");
					add[1]=U.getSectionValue(ownComHtml, "\"addressLocality\":\"", "\"");
					add[2]=U.getSectionValue(ownComHtml, "\"addressRegion\":\"", "\"");
					add[3]=U.getSectionValue(ownComHtml, "\"postalCode\":\"", "\"");
				}
			}
			U.log("Address is " + Arrays.toString(add));
			if (ownComHtml.contains("streetAddress\"") && (add[1]==null)) {
				U.log("hello");
				add[0]=U.getSectionValue(ownComHtml, "itemprop=\"streetAddress\" content=\"", "\"");
				add[1]=U.getSectionValue(ownComHtml, "itemprop=\"addressLocality\" content=\"", "\"");
				add[2]=U.getSectionValue(ownComHtml, "itemprop=\"addressRegion\" content=\"", "\"");
				add[3]=U.getSectionValue(ownComHtml, "itemprop=\"postalCode\" content=\"", "\"");
			}
			
			//-------------------latlLng Section--------------
			String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
			latLng[0] = U.getSectionValue(mapHtml, "var latitude = \"", "\"");
			latLng[1] = U.getSectionValue(mapHtml, "var longitude = \"", "\"");
			if (latLng[0]==null&&ownComHtml.contains("latitude")) {
				latLng[0] = U.getSectionValue(ownComHtml, "var latitude = \"", "\"");
				latLng[1] = U.getSectionValue(ownComHtml, "var longitude = \"", "\"");
			}
			if (latLng[0]==null && ownComHtml.contains("latitude")) {
				latLng[0] = U.getSectionValue(ownComHtml, "\"latitude\": \"", "\"");
				latLng[1] = U.getSectionValue(ownComHtml, "\"longitude\": \"", "\"");
				if(latLng[0] == null){
					latLng[0] = U.getSectionValue(ownComHtml, "\"latitude\": ", ",");
					latLng[1] = U.getSectionValue(ownComHtml, "\"longitude\": ", "}");
				}
			}
			if (latLng[0]==null&&ownComHtml.contains("latitude")) {
				latLng[0] = U.getSectionValue(ownComHtml, "itemprop=\"latitude\" content=\"", "\"");
				latLng[1] = U.getSectionValue(ownComHtml, "itemprop=\"longitude\" content=\"", "\"");
			}
			if (comUrl.contains("embrey-projects/touchstone/")) {
				mapHtml = U.getHtml("https://www.liveattouchstone.com/mapsanddirections.aspx",driver);
				latLng[0] = U.getSectionValue(mapHtml, "var latitude = \"", "\"");
				latLng[1] = U.getSectionValue(mapHtml, "var longitude = \"", "\"");
			}
			
			U.log("latLng is " + Arrays.toString(latLng));
			
			if(latLng[0] ==null ){
				String latLngSec= U.getSectionValue(ownComHtml, "geo.position\" content=\"", "\"");
				if(latLngSec!=null){
					latLng = latLngSec.split(";");
				}
			}
			if(latLng[0] ==null){
				latLng[0] = U.getSectionValue(ownComHtml, "data-lat=\"", "\"");
				latLng[1] = U.getSectionValue(ownComHtml, "data-lng=\"", "\"");
			}
			if(latLng[0]!=null && add[0].length()>4){
				if(latLng[0].contains("0.0000")){
					latLng = U.getlatlongGoogleApi(add);
					if(latLng == null) latLng = U.getlatlongHereApi(add);
					geo = "TRUE";
				}
			}
			U.log("latLng is " + Arrays.toString(latLng));
			
//			if(latLng[0] == null && apartUrl.contains("https://www.embreydc.com/embrey-projects/the-connection-at-buffalo-pointe/")){
//				String latLngSec = U.getSectionValue(ownComHtml, "add_point(", ");");
//				
//				String vals[] = latLngSec.split(",");
//				latLng[0] = vals[0];
//				latLng[1] = vals[1];
//			}

			if(latLng[0] == null && latLng[1] == null&& add[0].length()>4){
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			if( add[3] == null && latLng[0].length()>4){
				String add1[] = U.getAddressGoogleApi(latLng);
				if(add1 == null) add1 = U.getAddressHereApi(latLng);
				add[3] = add1[3];
				add1 = null;
				geo = "TRUE";
			}
			
			//---------Address from contact us page-----------
			if(add[0].length()<4 && latLng[0] == null){
				add[0] = "1020 NE Loop 410";
				add[1] = "San Antonio";
				add[2] = "TX";
				add[3] = "78209";
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				geo = "TRUE";
				notes = "Address And Lat-Lng Taken From Contact Us Page";
			}
			if(add[0].length()<4 && latLng[0].length()>4){
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "TRUE";
			}
			//--------if full address not present of first com page then
			//----Address and latlng manually taken from individual community site-------------
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/dominion-apartments/")){
				add[0] = "23910 West Interstate 10";
				add[1] = "San Antonio";
				add[2] = "TX";
				add[3] = "78257";
				latLng[0] = "29.6645646";
				latLng[1] = "-98.6289183";
				geo = "FALSE";
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/west-ave/")){
				latLng[0] = "29.560302";
				latLng[1] = "-98.495186";
				geo = "FALSE";
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/canyons-at-saddle-rock/")){
				latLng[0] = "39.592314";
				latLng[1] = "-104.720366";
				geo = "FALSE";
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/estates-bee-cave/")){
				latLng[0] = "30.3205258";
				latLng[1] = "-97.9569444";
				geo = "FALSE";
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/highpointe-cypresswood/")){
				latLng[0] = "29.9784771";
				latLng[1] = "-95.5684239";
				geo = "FALSE";
			}
//			if(comUrl.contains("https://www.embreydc.com/embrey-projects/dwell-legacy/")){
//				latLng[0] = "29.6121458";
//				latLng[1] = "-98.4629416";
//				geo = "FALSE";
//			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/everly/")){
				add = new String[]{"2827 Dunvale Rd","Houston" ,"TX", "77063"};
				geo = "FALSE";
			}
			if(comUrl.contains("https://www.embreydc.com/embrey-projects/west-ave-2/")){
				add = new String[]{"12803 West Avenue","San Antonio", "TX", "78216"};
				geo = "FALSE";
			}
			String webHtml="";
			if(aptHtml.contains("Website:")) {
				String webUSec=U.getSectionValue(aptHtml, "Website:","</a>");
				String wURL=U.getSectionValue(webUSec, "<a href=\"","\"");
				webHtml=U.getHtml(wURL.replaceAll("https|http","https")+"/floorplans.aspx",driver);
			}
			
			//----------Price--------------
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;
			if(floorHtml == null) {
				floorHtml=U.getHTML(comUrl+"/floorplans");
			}
			floorHtml = floorHtml.replaceAll("</strong></td><td data-selenium-id =\"Sqft_2\">|<span class='sr-only'>to</span>", "");
			String[] prices = U.getPrices(aptHtml+ownComHtml+floorHtml, "\\$\\d{3},\\d{3}", 0);
			floorHtml=floorHtml.replaceAll("<span(.*?)>", "").replaceAll("</div>\\s*<div(.*?)>", " ");
		//	U.log(Util.match(floorHtml, "<span id=\"(.*?)\">"));
//			U.log(floorHtml);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("minPrice : "+minPrice);
			U.log("maxPrice : "+maxPrice);
			
			//-----------Square feet-------------
			String minSqft =ALLOW_BLANK , maxSqft = ALLOW_BLANK;
			ownComUrl=ownComUrl==null?"":ownComUrl;
			U.log(Util.match(floorHtml, ".*1,208.*"));
			if (ownComUrl.contains("https://www.bellapartmentliving.com/co/littleton/bell-ken-caryl/index.aspx")) {
				floorHtml+="Sq. Feet</span><span class=\"fp-col-text\">783</span>   Sq. Feet</span><span class=\"fp-col-text\">729</span>   Sq. Feet</span><span class=\"fp-col-text\">856</span>";
			}
			if (comUrl.contains("https://www.embreydc.com/embrey-projects/the-connection-at-buffalo-pointe/")) {
				floorHtml+="Sq. Feet</span><span class=\"fp-col-text\">559</span>   Sq. Feet</span><span class=\"fp-col-text\">1523</span>   Sq. Feet</span><span class=\"fp-col-text\">798</span>";
			}
			
			if(floorHtml!=null)
			{
				floorHtml = U.removeSectionValue(floorHtml, "<span class=\"fp-video\" data-selenium-id=\"FPvideo_7\">", "</html");
				floorHtml = floorHtml.replaceAll("propMinSqft: \\d+,|id=\"sqft_min\" value=\"600\"", "");
			}
			
			
			String[] sqFt = U.getSqareFeet((floorHtml+aptHtml+ownComHtml+webHtml).replaceAll("propMinSqft: \\d+|SF.png","")
					,"\\d{3} - \\d{3} sq ft|Sq. Ft\\s*</span>\\s*<span class=\"fp-col-text\">\\s*\\d,\\d{3}|Sq. Ft</span><span class=\"fp-col-text\">\\d{3}|</span> Bathroom \\d,\\d{3} Sq. Ft.|<div class=\"unit-size\">\\d,\\d{3} Sq. Ft.</div>|Sq. Ft</span><span class=\"fp-col-text\">\\d,\\d{3}|\\d,\\d{3} to \\d,\\d{3} square feet|\\d{3} to \\d,\\d{3} sq ft|SQFT: \\d,\\d{3} - \\d,\\d{3}</span>|>\\d{3,4}-\\d{3,4} sq ft<|\\d{3,4}</td></tr>|sqft\">\\d{3,4} sq ft</span>|\\d{3,4} to \\d,\\d{3} square feet|>\\d{3,4} sq ft<|SQ. FT.\">\\d{3,4}|_sqft\">\\d{3,4}|sqft: \\d{3,4},|Sq. Feet</span><span class=\"fp-col-text\">\\d{3,4}</span>|SQFT: \\d,\\d{3}</span>|SQFT: \\d{3}</span>|\\d{3,4} Sq. Ft.|\\d,\\d{3} Sq. Ft|\\d{3} sq.ft|\\d{4} sq.ft|sqft: \"\\d,\\d{3}\",", 0);
			minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			
			U.log("minSqft : "+minSqft);
			U.log("maxSqft : "+maxSqft);
			
			ownComHtml = ownComHtml.replaceAll("Sleek and Ready for Move in|Ranch Road|Two-story Clubhouse with", "");
			
			//---------community Type---------
			String comType = ALLOW_BLANK;

			comType = U.getCommunityType(ownComHtml+amenHtml);
			
			//----------PropertyTYpe----------
			String propType = ALLOW_BLANK;
//			U.log(amenHtml);
			propType = U.getPropType(ownComHtml+amenHtml+regPropertyType);
			//U.log(Util.matchAll(ownComHtml+amenHtml+regPropertyType, "[\\w\\s\\W]{30}multi[\\w\\s\\W]{30}", 0));

			//------------Derived TYpe---------
			String derivedType = ALLOW_BLANK;
			ownComHtml = ownComHtml.replace("Ranch Road", "").replaceAll("Walker Ranch", "");
			floorHtml = floorHtml.replaceAll("Ranch Road|Storage Units only on 1st, 2nd and 3rd", "");
			
			derivedType = U.getdCommType((ownComHtml+floorHtml).replaceAll("Second Story Fitness Center|two-story elite fitness|two-story [f|F]itness|Walker Ranch|Rancho", ""));
//			U.log(">>>>>>>>>>>>>>"+Util.matchAll((ownComHtml+floorHtml).replaceAll("two-story elite fitness|two-story [f|F]itness|Walker Ranch|Rancho", ""), "[\\w\\s\\W]{30}Second Story[\\w\\s\\W]{30}", 0));

			//---------propert status------
			String propStatus = ALLOW_BLANK;
			ownComHtml = ownComHtml.replaceAll("READY TO MOVE IN?|<div class=\"text-3x font-weight-bold font-heading mb-3 mb-lg-0\">READY TO MOVE IN</div>|Units Now Available|;line-height:1.2;'>Coming Soon</p>|center openin|Soon To Littleto|<p>\\s*Coming Soon\\s*</p>|center now open|<p>\\s*Coming|<span>\\s*Coming|<span>\\s*\\((c|c)oming|Open for Tours", "");

			propStatus = U.getPropStatus(ownComHtml);
			
			U.log("propStatus===="+propStatus);
//			U.log("kkkkkkkkkk "+Util.matchAll(ownComHtml, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{200}", 0));

			
			U.log(mapHtml.contains("https://www.google.com/maps?cid=") );
			if(mapHtml!=null && mapHtml.contains("\"https://api.mapbox.com/") || ownComHtml.contains("https://www.google.com/maps?cid="))
			{
				geo="TRUE";
			}
			
			
				
				
			
//			if(apartUrl.contains("https://www.embreydc.com/embrey-projects/everly/")||apartUrl.contains("https://www.liveatthekelley.com/")) notes = "Now Leasing"; //Img from its own website
			//if(apartUrl.contains("https://www.embreydc.com/embrey-projects/westerly/")) notes = "Preleasing For July 2019"; //Img from its own website
//			if(apartUrl.contains("https://www.embreydc.com/embrey-projects/encore-boulevard/")) notes = "Preleasing"; //Img from its own website
	/*		if(apartUrl.contains("https://www.embreydc.com/embrey-projects/artessa-franklin/"))
				propType = propType+",Luxury Homes"; //images*/	
			if(apartUrl.contains("https://www.agorastoneoak.com/"))propStatus=ALLOW_BLANK;
			data.addCommunity(comName	,apartUrl, comType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("�", "").trim(), add[1].trim(), add[2].replace("Texas", "TX").trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, derivedType);
			data.addPropertyStatus(propStatus);
			data.addNotes(notes);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
			
			
		}
		j++;
	
	}
}
