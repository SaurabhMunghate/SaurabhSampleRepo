package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractEnceHomes extends AbstractScrapper {
	private static final boolean False = false;
	int i=0;	public int inr=0;
	static int j=0;
	CommunityLogger LOGGER;
	//WebDriver driver = new FirefoxDriver();
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractEnceHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ence Homes.csv", a.data().printAll());
	}

	public ExtractEnceHomes() throws Exception {

		super("Ence Homes", "https://encehomes.com/");
		LOGGER = new CommunityLogger("Ence Homes");
	}

	public void innerProcess() throws Exception {
		String url = "https://www.encehomes.com/communities";
		String html = U.getHTML(url);
		
        String secs[]=U.getValues(html,"<h2 class=\"head_line\">","Visit Community");
       for(String sec:secs)
		{
    	   //U.log(sec);
			String link = U.getSectionValue(sec, "href=\"", "\"");
			
			String name=U.getSectionValue(sec, "\">", "<").replaceAll("Tuscano Townhomes", "Tuscano");
			
			addDetails(link,name,sec);
			i++;inr++;
		}
         LOGGER.DisposeLogger();
         //driver.close();
		
	}

	private void addDetails(String comUrl,String name,String commInfo) throws Exception {
        
//	if (!comUrl.contains("https://www.encehomes.com/communities/varano-vistas/")) return;
//		if(j==4)
//		try{
		{
			
			U.log(j+" : "+comUrl);
			LOGGER.AddCommunityUrl(comUrl);
		String html = U.getHTML(comUrl);
		html=html.replace("Golf Club","");
		html=html.replace("www.golfentrada.com","");
		
		html=html.replace("golf.com","").replaceAll("mini golf|Golf Course\",\"coords\":|miniature golf| Enjoy mini golf, ", "");
//		if (name=="Tuscano Townhomes")
//			name="Tuscano";
//			U.log("======================================================================================================");
//		
		String commName = name;
		
//		U.log(commInfo);
		// Address & Lat Long
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		String addsec = U.getSectionValue(html, "Location</strong></li>", "Phone");
		addsec=addsec.replaceAll("\\s{2,}", " ");
		U.log("addsec::"+addsec);
		addsec = U.removeComments(addsec);
		addsec=addsec.replaceAll("Arancio Point|<span style=\"font-weight: 400;\">|</span>|Coming Soon|<span  style=\"font-weight: 400;\">|<li >|<li>|</li>\\s*<li class=\"hidden-xs hidden-sm\">|<li>|Phase 1 Sold Out, |\\s*Sign Up For Phase 2 VIP List,\\s* ", "");
		
		addsec=addsec.replace("</li>", ",");
		U.log("addsec::"+addsec);
		
		String[] ad = addsec.split(",");
		U.log(Arrays.toString(ad));
		add[0]=ad[0];
		add[1]=ad[1];
		add[3] = Util.match(ad[2], "\\d{5}");
		add[2] = Util.match(ad[2], "\\w{2}");
		
		String latsec = U.getSectionValue(html, "https://maps.google.com/?q=", "&amp");
		String[] latlong = latsec.split(",");
		lat = latlong[0];
		lng = latlong[1];
		geo = "FALSE";
		
	
		//for latlong new
		if(latlong[0]==null)
		{
			latsec=U.getSectionValue(html, "https://www.google.com/maps/dir/", "/@");
			latlong=latsec.split(",");
			lat = latlong[0];
			lng = latlong[1];
			geo = "FALSE";
		}
		add[0] = add[0].replace("Call For Appointment", ALLOW_BLANK);
		add[0]=add[0].replaceAll("\\s*Sign Up For Phase 2 VIP List\\s*", ALLOW_BLANK);
		U.log("Address:::::"+Arrays.toString(add));
		 if(add[0]==ALLOW_BLANK ||add[0].trim().length()<4)
		 {
			 add=U.getAddressGoogleApi(latlong);
			 geo="TRUE";
		 }
		

		// Square feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html+commInfo,
				"<li >\\d{4} sqft|\\d,\\d+ to \\d,\\d+ square feet|SQFT Range: \\d,\\d+ to \\d,\\d+|\\d,\\d+ sqft|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|SQFT Range: \\d+ to \\d+|square footage being between \\d,?\\d{3}-\\d,?\\d{3}|<li >\\d{4} sqft</li>|about \\d{4} square feet", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// Price
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = U.removeComments(html);
		html = html.replace("from the 270’s", "from the $270,000").replace("Upper 300s", "Upper $300,000").replaceAll("0's|0’s|0&#8217;s", "0,000");
		html = html.replace("High $400k", "High $400,000").replace("<!----><span style=\"font-weight: 400;\" ng-if=\"community.com_priceHigh &gt; 0\" class=\"ng-binding ng-scope\">", "");
		
		String[] price = U.getPrices(html.replace("Mid $300k", "Mid $300,000")+commInfo,
				"Mid \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|>\\$\\d{3},\\d{3} </span>|Price Range: \\$\\d+,\\d+ to \\$\\d+,\\d+|From the  \\$\\d+,\\d+|Price Range: \\$\\d+,\\d+|\\$\\d+,\\d+|(start|competitively) in the \\d{3},\\d{3}|starting in the \\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log("MMMMMMM "+Util.matchAll((html), "[\\s\\w\\W]{70}Price Range:[\\s\\w\\W]{70}", 0));

		//================ Model & Floor Plan Html =================
		String combinedHomeHtml = null;
		String homeSections [] = U.getValues(html, "<div class=\"plan-result-inner\">", "</a>");
		for(String homeSec : homeSections){
			String homeUrl = U.getSectionValue(homeSec, "href=\"", "\"");
			U.log("homeUrl==="+homeUrl);
			if (homeUrl.contains("https://www.encehomes.com/plans/white-sands-plan-2592/")) {
				continue;
			}
//			try {
			String homeHtml = U.getHTML(homeUrl);
			
			combinedHomeHtml += U.getSectionValue(homeHtml, "Home Description</div>", "Floor Plan");
//		}
//			catch(Exception e) {}
		}
		
		
		html = html.replaceAll("\"name\":\"Dixie Red Hill Golf Course|poi_name\":\"Green Springs Golf Course|Dixie Red Hill Golf Course</li><li class=\"poi_list_item\"|Green Springs Golf Course</li><li class=\"poi_list_item\" |name\":\"Green Springs Golf Course\",\"coords\"|poi_name\":\"Dixie Red Hill Golf Course\",|No HOA|Move-In Ready Homes", "");
	
		
		//U.log(Util.match(combinedHomeHtml, ".*?Common Area.*?"));
		html=html.replace("farm style designs", "farmhouse style designs").replaceAll("Custom|custom|CUSTOM|<span class='entry-title'>Tuscano Townhomes</span>","").replace("-craftsman","");
		html = html.replace("target=\"_blank\">HOA</a>", " HOA ");
		String pType = U.getPropType((html+commInfo+combinedHomeHtml).replace("title='white trails common area", "").replace("luxurious retreat", "luxury homes").replaceAll("luxuries society has given to us|ions or traditional dine-in|CRAFTSMAN.jpg|Chinese \\(Traditional\\)|chinese-traditional|Custom|CUSTOM", ""));
//		U.log("MMMMMMM "+Util.matchAll((combinedHomeHtml), "[\\s\\w\\W]{70}common area[\\s\\w\\W]{70}", 0));

		html=html.replace("Phase 3 will be opening soon","Phase 3 opening soon");
		html=html.replace("Phase 1 is selling fast", "Phase 1 selling fast").replace("Phase 1 is currently sold out", "Phase 1 currently sold out");
		html =html.replace("phase 1 is almost sold out", "phase 1 almost sold out")
				.replaceAll("content=\"COMING SOON|Sentieri Canyon Coming Soon|content=\"Arroyo is now Open|content=\"Riverstone currently has 2 homesites|and \\(Coming Soon\\) Smit|content=\"New community now available|Move-in Ready|Move-In Ready", "")
				.replaceAll("text\">Quick Move|Quick Move in Homes</a>|Quick Move-In Homes</a>|Phase 1 Sold Out, Sign Up|Quick Move-In", "");
		
		
		html = html.replace("only has two homes available", "only two homes available")
				.replace("Phase 3 is now available", "phase 3 now available")
				.replace("Phase 1 is sold out", "Phase 1 sold out")
				.replace("Phase 2 is now open", "Phase 2 now open")
				.replace("townhomes are now available", "townhomes now available")
				.replace("These townhomes are coming soon","Townhomes Coming Soon")
				.replace("Grand_Opening_Invitation", "Grand Opening_Invitation");
//		html=html.replace("old farm style designs", "Farmhouse-style Homes");
//		U.log(html);
//		U.log(Util.match(html, ".*?Coming Soon.*?"));
		String status = U.getPropStatus(html.replaceAll("Quick Move-in Homes|quick move-in homes|Quick Move-In Homes|Quick Move in Homes", "").replaceAll("quick move-in homes|Quick Move in Homes|because it was a Quick Move-in home|Sedero Coming Soon|White Trails Coming Soo",""));
				//U.log("MMMMMMM "+Util.matchAll((html), "[\\s\\w\\W]{70}quick move[\\s\\w\\W]{70}", 0));

			
		String qHtml = U.getHTML("https://www.encehomes.com/homes/");
		
		String[] qSec = U.getValues(qHtml, "<div class=\"home-details", "</ul>");
		
		for(String qPart : qSec) {
			
			if(qPart.contains(commName.replace("at Divario", "").trim()))
				if (!status.contains("Move In")&&!status.contains("Move-In")) {
					if(status.length()<4){
					//	status="Move-In Ready Homes";//dt 27 may 22
						status="Quick Move-In Homes";
					}
					else{
//						status=status+", Move-In Ready Homes";
						status=status+", Quick Move-In Homes";
					}
				}else {
//					status=status.replaceAll("Move In Ready[ Home[s]?]?", "Move-In Ready Homes");
					status=status.replaceAll("Quick Move-In[ Home[s]?]?", "Quick Move-In Homes");
				}
		}
		
		
		boolean readystatus=callReady(commName);
		
		if(readystatus==true){
			if (!status.contains("Move In")&&!status.contains("Move-In")) {
				if(status.length()<4){
					//status="Move-In Ready Homes";
					status="Quick Move-In Homes";
				}
				else{
				//	status=status+",Move-In Ready Homes";
					status=status+" ,Move-In Ready Homes";
				}
			}else {
//				status=status.replaceAll("Move In Ready[ Home[s]?]?", "Move-In Ready Homes");
				status=status.replaceAll("Quick Move-In[ Home[s]?]?", "Quick Move-In Homes");

			}
			
		}
		
         U.log("status=========>"+status);
		String note = U.getnote(html);
		
		if(comUrl.contains("https://www.encehomes.com/communities/aspen-estates/")) pType = pType+", Estate-Style Homes";
		if(comUrl.contains("https://www.encehomes.com/communities/arancio-point/"))status =ALLOW_BLANK;
		commName=commName.replace(" Coming Soon", "");
		data.addCommunity(commName.replace("&#8211;", ""), comUrl, U.getCommunityType(html.replaceAll("Country Club\",\"coords|Enjoy mini golf", "")));
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng.trim(), geo);
		data.addPropertyType(pType, U.getdCommType((html+combinedHomeHtml).replaceAll("floor|Floor", "")));
		data.addPropertyStatus(status);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}j++;
//		}catch(Exception e){}

		
	}
	public boolean callReady(String key) throws Exception{
		U.log("comname::"+key+"::");
		String readyHtml=U.getHTML("https://www.encehomes.com/homes");
		boolean flag=false;
		int noOfQhome=0;
		int ntReady=0;
		
		String homeSec=U.getSectionValue(readyHtml, "<ul class=\"list-unstyled plans\">", "<script type=\"text/javascript\">");
		String[] section=U.getValues(readyHtml, "<div class=\"plan-result-inner\">", "<div class=\"plan-result-button-bar\">");

//		String[] section=U.getValues(readyHtml, "<li>Community:", "<li>Status:");
		U.log("section::"+section.length);
		for(String sec:section ){
			if(sec.contains(key)){
				//flag=true;
				noOfQhome++;
			if(sec.contains("Est. Move-in Date: "))	
				ntReady++;
			}
		}
		if(noOfQhome>ntReady) {
			flag=true;
		}
		return flag;
	}
}
