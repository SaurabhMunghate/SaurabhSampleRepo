//Written by Upendra=>07-04-2018

package com.shatam.b_301_324;

import java.io.IOException;
import java.util.Arrays;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;

public class ExtractHamptonHomes extends AbstractScrapper {
	static CommunityLogger LOGGER;
	static int k = 0;
	static int j = 0;
	

	public ExtractHamptonHomes() throws Exception {
		// TODO Auto-generated constructor stub
		super("Hampton Homes", "http://hamptonhomestexas.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Hampton Homes");
	}

	public static void main(String[] args) throws Exception {
		
	        AbstractScrapper a = new ExtractHamptonHomes();
			a.process();
			FileUtil.writeAllText(U.getCachePath() + "Hampton Homes.csv", a.data().printAll());
		 
	        
		// TODO Auto-generated method stub
		
		

	}

	private static void addCommunity(String comUrl, String mainData) throws Exception {
		// TODO Auto-generated method stub
		//if(!comUrl.contains("http://hamptonhomestexas.com/communities/windmill-farms/"))return;
		String html = U.getHTML(comUrl);

		// ==============================================================Community Name
		String comName = U.getSectionValue(html, "<h3>", "</h3>");
		U.log("Community name:-- " + comName);

		// ===============================================================Address Data

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "false";
		//U.log(html);
		String addSec = U.getSectionValue(html, "Model:</dt><dd>", "</dd>");
		U.log(addSec);
		if (addSec != null) {
			addSec = addSec.replace("<em>(Opening September)</em><br>", "").replaceAll(
					"<br>2665 The Bailey - Elevation B|<br>3201 The Chester - Elevation A|<br>2037 The Shelby - Elevation C",
					"");
			add = U.findAddress(addSec);
		}
		U.log(Arrays.toString(add));
		String latSec = U.getSectionValue(html, "new google.maps.LatLng(", ")");
		latlong = latSec.split(",");
		U.log(Arrays.toString(latlong));

		if (add[0].length() < 4 && latlong[0].length() > 4) {
			add = U.getAddressGoogleApi(latlong);
			geo = "TRUE";
		}

		// =================================================================FlorePlan
		// Html

		String florHtml = "";
		String floreSec = U.getSectionValue(html, "<h3>Floorplans</h3>", "</section>");
		if (floreSec != null) {
			String[] florHome = U.getValues(floreSec, "href=\"", "\"");
			for (String string : florHome) {
				florHtml = florHtml + U.getHTML("http://hamptonhomestexas.com" + string);
			}
		}

		// ==================================================================QuickPlan
		// Html

		String allQuickHtml = "";
		String quickSec = U.getSectionValue(html, "<h3>Quick Move-In</h3>", "</section>");
		if (quickSec != null) {
			String[] quickHome = U.getValues(floreSec, "href=\"", "\"");
			for (String string : quickHome) {
				String quickHtml = U.getHTML("http://hamptonhomestexas.com" + string);
				allQuickHtml += U.getSectionValue(quickHtml, "ntro-left equal-heights\">", "\"section-contact-info\">"); 
			}
		}

		// =====================================================================Price
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replace("$185,00", "$185,000");
		// U.log(html);
		html = html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k", "0,000").replace("$1 million", "$1,000,000");
		String prices[] = U.getPrices(html + florHtml + allQuickHtml,
				"Starting at \\$\\d{3},\\d{3}|From <strong>\\$\\d{3},\\d{3}", 0);

		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		U.log("Price--->" + minPrice + " " + maxPrice);

		// =========================================================================Sq.ft
		String[] sqft = U.getSqareFeet(html + florHtml + allQuickHtml, "Sq. Ft. A/C:</strong> \\d{4}|\\d{4} SQ FT", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->" + minSqft + " " + maxSqft);

		// ================================================community
		// type========================================================

		String communityType = U.getCommType(html);

		// ==========================================================Property
		// Type================================================
		html = html.replaceAll("Macondo", "");
		
		String proptype = U.getNewPropType(html+allQuickHtml);
		

		// ==================================================D-Property
		// Type======================================================
		html = html.replace("Floors: 1 - 2", " 1 Story 2 Story ");
		html = html.replaceAll("Rancho|Ranchers", "");
		// U.log(availHomeData);

		String dtype = U
				.getdCommType(comName+comUrl+(html + florHtml + allQuickHtml).replaceAll("ranch MOVE IN READY |Ranch|Ranchers|ranch", ""));

		// ==============================================Property
		// Status=========================================================
		String pstatus = ALLOW_BLANK;
		html=html.replaceAll("PRICE COMING SOON|Price Coming Soon|<h3>Quick Move-In</h3>", "");
		pstatus = U.getNewPropStatus(html+mainData);

		if (html.contains("These homes are currently available for quick")) {
			if (pstatus.length() > 4) {
				pstatus = pstatus + ",Quick Move In";
			} else {
				 pstatus="Quick Move In";
			}
		}

		// ============================================note====================================================================
		String note = U.getnote(html);

		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl);
			k++;
			return;
		}
		add[2] = add[2].replace(".", "");
		U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
		data.addCommunity(comName, comUrl, communityType);
		data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		j++;
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml = U.getHTML("http://hamptonhomestexas.com/communities/");
		String[] comSec = U.getValues(mainHtml, "<div class=\"col col-sm-4\">", "</a></div>");
		U.log(comSec.length);
		for (String string : comSec) {
			String comUrl = "http://hamptonhomestexas.com" + U.getSectionValue(string, "<a href=\"", "\"");
			U.log(comUrl);
			addCommunity(comUrl, string);
		}

	}

}
