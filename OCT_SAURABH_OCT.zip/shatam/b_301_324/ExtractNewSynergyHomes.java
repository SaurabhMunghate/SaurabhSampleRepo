package com.shatam.b_301_324;

/**
 * @author MJS 
 * @date 23/02/2021
 * 
 */

import java.util.Arrays;

import com.shatam.b_101_120.SignatureHomes;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNewSynergyHomes extends AbstractScrapper{

	int i = 0;
	static int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	
	public ExtractNewSynergyHomes() throws Exception {

		super("Mattamy Homes - New Synergy Homes", "https://www.newsynergyhomes.com/");
		LOGGER = new CommunityLogger("Mattamy Homes - New Synergy Homes");
	}

	public static void main(String args[]) throws Exception {

		AbstractScrapper a = new ExtractNewSynergyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Mattamy Homes - New Synergy Homes.csv", a.data()
				.printAll());
	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
	
		String html = U.getHTML("https://www.newsynergyhomes.com/communities/");
		
		String[] comSec = U.getValues(html, "<div class=\"community\">", "Learn More");
		
		for(String com : comSec) {
			
			String comUrl = U.getSectionValue(com, "<a href=\"", "\">");
			addDetail(com, comUrl);
			
		}
		LOGGER.DisposeLogger();
	}

	private void addDetail(String com, String comUrl) throws Exception {
		// TODO Auto-generated method stub
//		try {
//				if(!comUrl.contains("https://www.newsynergyhomes.com/communities/iron-horse/"))return;
		
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("============= Repeated ===========: "+comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log("Count: "+j);
		U.log("comUrl: "+comUrl);
		
		String html = U.getHTML(comUrl);
		
		//======== ComName ==============================================================================================
		String comName = U.getSectionValue(com, "<h3>", "</h3>");
		U.log("comName: "+comName);
		comName=comName.replace("50’s", "50's");
		//======== Address ==============================================================================================
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		
		String addSec = U.getSectionValue(html, "<strong>Model Home:</strong></p>", "</p>");
		
		if(addSec!=null) {
			
			addSec = U.getNoHtml(addSec.replaceAll("<br />", ","));
			add = U.getAddress(addSec);
			U.log("Address: "+Arrays.toString(add));
		}
		
		latlng[0] = U.getSectionValue(html, "data-lat=\"", "\"");
		latlng[1] = U.getSectionValue(html, "data-lon=\"", "\"");
		U.log("Latlng: "+Arrays.toString(latlng));
		
		if(add[0]==null || add[0].length()<3) {
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
		}
		
		//=============== FLOOR PLAN ===================================================================================
		
		String[] floorSec=null;
		String floorPart = U.getSectionValue(html, "<h3>Floorplans</h3>", "</section>");
		if(floorPart!=null)
		floorSec = U.getValues(floorPart, "<a href=\"", "\"");
		
		String floorHtml = ALLOW_BLANK;
		if(floorSec!=null)
		for(String floor : floorSec) {
			
			if(!floor.contains("http"))
				floor = "https://www.newsynergyhomes.com"+floor;
				U.log("floor: "+floor);
				floorHtml+= U.getSectionValue(U.getHTML(floor), "<section class=\"floorplans-description\">", "</section>")+floorPart;
		}
		
		String[] quickSec=null;
		String quickPart = U.getSectionValue(html, "<h3>Quick Move-Ins</h3>", "</section>");
		if(quickPart!=null)
		quickSec = U.getValues(quickPart, "<p><a", "</p>");

		int pending = 0;
		int avail = 0;
		String quickHtml = ALLOW_BLANK;
		if(quickSec!=null)
		for(String quick : quickSec) {
			
			if(quick.contains("Pending"))
				pending++;
			if(quick.contains("<span class=\"left\">Available"))
				avail++;
			
			if(!quick.contains("http"))
				quick = "https://www.newsynergyhomes.com"+U.getSectionValue(quick, "href=\"", "\"");
			else
				quick = U.getSectionValue(quick, "href=\"", "\"");
			U.log("quick: "+quick);
			try {
				quickHtml+= U.getSectionValue(U.getHTML(quick), "<section class=\"specs-description\">", "</section>")+quickPart;
				}catch (Exception e) {
					// TODO: handle exception
				}
		}
		
		
		//============ PRICE ============================================================================================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html = html.replaceAll("0’s|0's|0s", "0,000").replace("Mid-200's", " Mid $200,000").replace(" mid 200s", " mid $200,000");
		com = com.replace("0s","0,000").replace("0’s","0,000");

		String[] price = U.getPrices(com +floorHtml+ quickHtml+html, 
						"<p class=\"starting-at\">From the \\$\\d{3},\\d{3}|<span class=\"right\">\\$\\d{3},\\d{3}</span>|<span class=\"right\">FROM \\$\\d{3},\\d{3}</span>",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log(Util.matchAll(com +floorHtml+ quickHtml+html, "[\\s\\w\\W]{30}\\$399,990[\\s\\w\\W]{30}", 0));
		
		// =============== Square Feet ===============
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;

		String sqftSec[]=U.getValues(quickHtml, "Square Footage:","</div>");
		String sqSec="";
				for(String ss:sqftSec) {
					sqSec+=ss;
				}
				U.log(sqSec);
		String[] sqft = U.getSqareFeet(quickHtml + floorHtml + html+sqSec,
				"\\d{4}</span>|<span class=\"right\">\\d{4} - \\d{4} SQ FT</span>|<span class=\"left\">\\d{4} - \\d{4} SQ FT</span>|Square Footage:</span>\n\\s*<span class=\"attribute-value\">\n\\s*\\d{4}|approximately \\d,\\d{3} square feet|<span class=\"left\">\\d{4} SQ FT</span>",
				0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft :" + minSqf + "\tMaxSqft :" + maxSqf);
		
		
		//============= Property Status ==============
		html = html.replaceAll("available for quick or immediate|<span class=\"right\">Coming Soon</span>|<span class=\"left\">Coming Soon</span>", "");
		String status = U.getPropStatus(com+html);
		U.log("Status: "+status);

		
		//============ Property Type =================
		String pType = U.getPropType(com + html +quickHtml + floorHtml);
		U.log("pType: "+pType);
		
		
		//============ D-Property Type =================
		String dType = U.getdCommType(com + html +quickHtml + floorHtml);
		U.log("dType: "+dType);
		
		
		//=========== Community Type ====================
		String cType = U.getCommunityType(com + html);
		U.log("cType: "+cType);
		
		//======Note ======================================
		String note = U.getnote(html+com);
		U.log("Note: "+note);
		
		//===== Coming Soon ==========================
		if(com.contains("<img src=\"/wp-content/themes/new-synergy-homes/assets/img/coming-soon.png\""))
			if(status==ALLOW_BLANK)
				status = "Coming Soon";
			else if(!status.contains("Coming Soon"))
				status += ", Coming Soon";
		
		
		//=============== Quick Move =============
		if(quickSec!=null)
		if(quickSec.length>pending && (quickSec.length-pending)>avail) {
			
			if(status==ALLOW_BLANK)
				status = "Quick Move-Ins";
			else
				status += ", Quick Move-Ins";
		}
		
		
//		if(comUrl.contains("https://www.newsynergyhomes.com/communities/iron-horse/")) {
//			status+=", Coming March 2021";
//		}
		//============================================================================================
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);
		j++;
//		}catch(Exception e){}
	}

}
