package com.shatam.b_301_324;

import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.GetHtmlSource;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPyattBuilders extends AbstractScrapper{
	static String builderName="Pyatt Builders";
	static String builderUrl="https://www.pyattbuilders.com";
	CommunityLogger LOGGER;
	
	static int dupli=0;
	
	WebDriver driver = null;
	public ExtractPyattBuilders()throws Exception {
		super(builderName, builderUrl);
		LOGGER=new CommunityLogger(builderName);
	}
	public static void main(String[] args) throws Exception {

		
		AbstractScrapper abS=new ExtractPyattBuilders();
		
		abS.process();
		FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abS.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		//U.setUpChromePath();
		//driver = new ChromeDriver();

	//	U.setUpGeckoPath();
	//	driver = new FirefoxDriver();
//		U.setUpChromePath();
//		driver=new ChromeDriver();
		String mainHtml=U.getHTML(builderUrl+"/where-we-build/");
		//U.log(mainHtml);
//		String commSec=U.getSectionValue(mainHtml, "id=\"wwbCommunity-link-", "</li>");
		//U.log(commSec);
		//commSec=commSec.replaceAll("<p>&nbsp;</p>|<p></div>", "");
		String[] comms=U.getValues(mainHtml, "id=\"wwbCommunity-link-", "</li>");
		String commName=ALLOW_BLANK;
		String commURL=ALLOW_BLANK;
		U.log(comms.length);
		int i=0;
		for (String commData : comms) {
			//U.log(commData);
			commURL=U.getSectionValue(commData, "href=\"", "\"");
			commName=U.getSectionValue(commData, ">", "<").replaceAll("Carmel - |Noblesville - |Greenfield - |New Palestine - |Franklin - |Indianapolis - |Camby - |Shelbyville - ", "");
			if(!commURL.startsWith("http"))
				commURL=builderUrl+commURL;
			
			addDetails(commURL,commName);
			
			i++;
			//break;
		}
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}
	int j = 0 ;
	//TODO ::
		private void addDetails(String comUrl, String comName ) throws Exception {
	//if(j == 2)
		{
//		
//		if(!comUrl.contains("https://www.pyattbuilders.com/new-home-communities/marion-central/highlands-at-grassy-creek"))return;
			

			U.log("Count =="+j);
			U.log("comUrl ===============================================>="+comUrl);
//			String communityHtml=U.getHTML(comUrl);
//			String html = U.getHtml(comUrl, driver);
			String html = U.getHTML(comUrl);
			
			
			//================= Quick Count ======================
			
			String footerSec=U.getSectionValue(html, "<footer class=\"footer\">", "</html>");
			html=html.replace(footerSec, "");

			if (data.communityUrlExists(comUrl)){
	        	LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
	        	return;
	        }
	        LOGGER.AddCommunityUrl(comUrl);
	        
			//=========== Community Name ===========
			comName = comName.replaceAll("Mooresville -", "");
			U.log("comName ::==== "+comName);
			
			//=========== Notes ==================
			String notes = U.getnote(html);
			
			//============== LatLng ==================
			String latLong[] = {ALLOW_BLANK,ALLOW_BLANK};
			
			//============== Section =================
			String mainSection = U.getSectionValue(html, "</h1>", "<div class=\"clearfix\">");
//			U.log(mainSection);
			String planHtmls = null;
			
			if(mainSection != null){
				String [] planUrls = U.getValues(mainSection, "<a href=\"", "\"");
				
				for(int i = 0; i < planUrls.length; i ++){
					if(planUrls[i].startsWith("#"))continue;
					String planHtml = null;
					planUrls[i] = planUrls[i].replace("amp;", "");

					
					
					if(planUrls[i].startsWith("http")){
						planHtml = U.getHtml(planUrls[i], driver);
						
						U.log("Plan Url ---> "+planUrls[i]);
					}
					if(!planUrls[i].startsWith("http")){
						if(!planUrls[i].startsWith("/")) planUrls[i] = "/"+planUrls[i];
						planHtml = U.getHtml(builderUrl+planUrls[i], driver);
						U.log("PlanUrls : "+builderUrl+planUrls[i]);
						U.log(U.getCache(builderUrl+planUrls[i]));
					}
					
					
					//This below condition is used to find view plan url .
					//From View Plan Url, we are taking latlng from that url page.
					if(i == 0){

						String latLngSec = U.getSectionValue(planHtml, "/maps/@", "data=");
						
						if(latLngSec != null){
							latLong = findLatLng(latLngSec);
						}
					}
					planHtmls += planHtml;
				}
			}
			if(mainSection == null){
				String latLngSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/search/?api=1&amp;query=", "\"");
				U.log("latLngSec : "+latLngSec);
				if(latLngSec != null)
					latLong = findLatLng(latLngSec);
			}
			
			if(latLong[0] ==ALLOW_BLANK){
				latLong[0] = U.getSectionValue(html, "latitude&quot;:&quot;", "&quot;,");
				latLong[1] = U.getSectionValue(html, "&quot;longitude&quot;:&quot;", "&quot;");
			}
			
			U.log("LatLong : "+Arrays.toString(latLong));
			//============== Plan Section =================
			String allPlanHtml=ALLOW_BLANK;
			String floorPlanSec=U.getSectionValue(html, "<h3 class=\"cms-floorplans__title py-title animate__animated animate__fadeIn\">", "<div class=\"modal__content\" ref=\"hhModalContent\">");
//			U.log(" sec"+floorPlanSec);
			String planUrls[]=U.getValues(floorPlanSec, "<a","class=\"card card--qmi card--floorplan\"");//class="card card--qmi card--floorplan"
			if(planUrls.length>0) {
				for(String s:planUrls) {
				String planhtm=ALLOW_BLANK;
//				U.log("|||||||||"+s);
				String planDataUrl=("https://www.pyattbuilders.com"+U.getSectionValue(s, "href=\"", "\"")).replace(" ", "-").toLowerCase().replace("/pointe-at-central-park/", "/the-pointe-at-central-park/");
//				U.log(planDataUrl);
				//https://www.pyattbuilders.com/api/component/grove-at-legacy/brooklyn
				planhtm=U.getHTML(planDataUrl);
				allPlanHtml+=planhtm;
//				break;
				}
				U.log("totat: homes length =="+planUrls.length);
			}
			String quickMoveInHomesData="";
			int homesCount = 0;
			//QuickMoveIn page data
//			String quickHtml=getQuickHomeData();
			String quickSecs=U.getSectionValue(html, "<header class=\"cms-qmi__header\">", "<div class=\"community__lotmap\">");
			if(quickSecs!=null) {
				String[] quickHomes=U.getValues(quickSecs, "<div class=\"cms-qmi__qmis\">", "<div class=\"card__header\">"); // "<div class=\"card__cta card__cta--view cta cta--outline-gold cta-yelling \">Details</div>"); // "<a href=\"/quick-move-ins","\"");
				for (String quick : quickHomes) {
//					U.log(quick);
//					String quickUrl="https://www.pyattbuilders.com/quick-move-ins"+quick; //U.getSectionValue(quick, "s", "\"");
					
					String quickUrl= builderUrl+U.getSectionValue(quick, "href=\"", "\"");
					
					U.log("Quick Url"+quickUrl);
					String quickHtml=U.getHTML(quickUrl);
					
					if(!quickHtml.contains("Estimated Completion Date:")) {
						homesCount++;
					}
					quickMoveInHomesData+=U.getSectionValue(quickHtml, " <header class=\"qmi-info__location \">", "</footer>");
				}
				U.log("totat: quick homes length =="+quickHomes.length);
			}
			U.log("homesCount: "+homesCount);
			
			String geo = "False";
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addressSec=U.getSectionValue(html, "<span class=\"cms-contact__label\">Model / Sales Center:  </span>", "</div>");
			U.log(addressSec);
			if(addressSec!=null) {
				add=U.getAddress(U.getNoHtml(addressSec));
			}
			U.log(Arrays.toString(add));
			if(latLong[0] != ALLOW_BLANK && latLong[1] != ALLOW_BLANK&&add[0]==ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				geo = "True";
			}
			
		
			
			if(comUrl.contains("https://www.finecraftbuilders.com")){
				if(planHtmls == null)
					planHtmls = fetchFineBuilderData(comUrl);
				
				//====== LatLng======
				String latLngSec = U.getSectionValue(html, "!2d", "!2m");
				if(latLngSec != null){
					String vals[] = latLngSec.split("!3d");
					latLong[0] = vals[1];
					latLong[1] = vals[0];
				}
				//=======Address =====
				String addSec = U.getSectionValue(html, "Model Homes</h4>", "</p>");
				if(addSec != null){
					addSec = addSec.replaceAll("</strong><br>|The Cornerstone Series", "").replace("<br>", ",").replaceAll("<.*>", "");
					add = U.getAddress(addSec);
				}
			}
			
			//System.out.println(Arrays.toString(latLong)  + "-------");
			if(comUrl.contains("http://www.pyattbuilders.com/new-enghttps://www.pyattbuilders.com/new-home-communities/marion-central/stable-chaseland-way-heritage-hills/")){
				add[0]="Treetops Boulevard";
				add[1]="Avon";
				add[2]="IN";
				add[3]="46123";
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				geo = "TRUE";
				notes = "Address Taken From Home Plan Map";
			}
//			U.log(quickMoveInHomesData);
			//=========== Price ===============
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
			html = html.replaceAll("0s|0k", "0,000").replace("$183s", "$183,000").replace("$233s", "$233,000").replace(".5k", ",500").replace("&#8211;", "-").replace("5s", "5,000");
			html=html.replaceAll("k</li>", ",000").replace("$390", "\\$390,000");
			String [] prices = U.getPrices(html.replace("s", ",000")+planHtmls+quickMoveInHomesData, 
					"<div class=\"qmi-info__price\">\\s+\\$\\d{3},\\d{3}\\s+</div>|Price: \\$\\d{3},\\d{3}\\s?(–|-)|start at \\$\\d{3},\\d{3}|property-price\">\\$\\d{3},\\d{3}|\\s?\\$\\d{3},\\d{3}|Starting at\\s+<div class=\"listPrice\">\\s+\\$\\d{6,}|Upper \\$\\d{3},\\d{3}|(S|s)tarting at \\$\\d{3},\\d{3}|FROM \\$\\d{3},\\d{3}|start at \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}<",
					0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("prices-->"+minPrice+" "+maxPrice);
			
			//============ Sqft ==============
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String [] sqft = U.getSqareFeet(html+planHtmls+quickMoveInHomesData, 
					"<div class=\"snapshot__value\">\\s+\\d,\\d{3}\\s+sf\\s+</div>|from \\d{1},\\d{3} � \\d{1},\\d{3}|property-size\">\\d,\\d{3} SQ FT</li>|\\d,\\d+ – \\d,\\d+ square feet|\\d{4} sq ft</li>|Sq Ft: \\d,\\d{3} (–|-) \\d,\\d{3}|Sq Ft: \\d,\\d{3}\\s?–\\s?\\d,\\d{3}|</span>\\s?2652 sq ft|\\s\\d{4} sqft</h3>|Sq Ft: \\d,\\d{3}|\\d,\\d{3} SQFT</h4>|\\d,\\d{3}\\s*-\\s*\\d,\\d{3} SQ\\s*FT|from \\d,\\d{3} - \\d,\\d{3} square feet", 0);
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
			
			//=========== Property Type ==================
			if(planHtmls != null){

				planHtmls = planHtmls.replaceAll(">Patio</a>|Lane and Patio|the-patio-series|The Patio Series<|Farmhouse style elevation", "");
				
			}
//			U.log(Util.matchAll(html+planHtmls+quickMoveInHomesData, ".*traditional.*",0));
			String rem = "(F|f)armhouse style elevation|(T|t)raditional style elevation|(T|t)raditional-style elevation|Craftsman style elevation|Craftsman-style elevation";
/*			if(quickMoveInHomesData!=null)quickMoveInHomesData=quickMoveInHomesData.
					replaceAll("(F|f)armhouse style elevation|(T|t)raditional style elevation|Traditional-style elevation", "");
*///			html = html.replaceAll("the-patio-series|The Patio Series<", "patio homes");
			
			if(quickMoveInHomesData!=null)
				quickMoveInHomesData = quickMoveInHomesData.replace("2 separate living spaces", " Story 2 ").replace("cozy and luxurious,", " luxury Homes ").replace("One Level Design", "");
//			U.log(Util.matchAll((html+planHtmls+quickMoveInHomesData+allPlanHtml),"[\\w\\W\\s]{30}Luxury[\\w\\W\\s]{30}", 0));
			String propType = U.getPropType((html+planHtmls+quickMoveInHomesData+allPlanHtml).replaceAll(rem, ""));
			if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/the-pointe/"))propType=ALLOW_BLANK;
			
			U.log("property Type=================================================================================================>"+propType);
			//============ Property Status ==============
			
			String propStatus = ALLOW_BLANK; 	
			html = html.replaceAll("Move-in home remaining in this|Only 2 Quick Move-in homes|Quick Move-Ins|Quick Move-In Homes", "");
			html=html.replaceAll("Pricing Coming", "");
			html=html.replace("Quick Move-in Home", "");
			//html = U.removeSectionValue(html, "<head>", "</head>");
			
			propStatus = U.getPropStatus(html);
			//propStatus=propStatus.replace("Quick Move-Ins, Quick Move-Ins", "Quick Move-Ins");
//			if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/the-trails/"))
//				propStatus="Only 1 Lot Remaining, Quick Move-in";
			U.log("Property status is:::"+propStatus);
//			U.log(">>status<<<>>>"+propStatus);
//			if(quickHomes != null){
//				//U.log(quickMoveInHomesData);
//				if(quickHomes.length>0){
//					if(!propStatus.equalsIgnoreCase("Quick Move")){
//						if(propStatus != ALLOW_BLANK) propStatus +=", Quick Move-Ins";
//						else propStatus ="Quick Move-Ins";
//					}
//				}
//			}
//			propStatus=propStatus.replaceAll("Quick Move-in, |, Quick Move-in","");
//			propStatus=propStatus.replace("Quick Move-in",ALLOW_BLANK);
			propStatus=propStatus.replace("Quick Move-in Homes", "");
			propStatus=propStatus.replace("Quick Move-in Home", "");
//			if(html.contains("View Quick Move-Ins"))
			if(homesCount>0) {
				if(propStatus!=ALLOW_BLANK) {
					propStatus=propStatus+", Quick Move-Ins";
				}
				else
					propStatus="Quick Move-Ins";
			}
			
			
			
			U.log("Final propewrty status::::::"+propStatus);
			
			//=============Community Type ==========
			String comType = ALLOW_BLANK;
			if(mainSection != null)	comType = U.getCommunityType(mainSection);
			else comType = U.getCommunityType(html);
			
			//============ Derived Property Type ============
			
			allPlanHtml=allPlanHtml.replaceAll("LH\\d{4} First Floor|LH\\d{4}_Second Floor|LH\\d{4} Second Floor","");
			String dType = U.getdCommType(html+planHtmls+quickMoveInHomesData+allPlanHtml);
			U.log("deriveed"+dType);
			
//			if(comUrl.contains("/meadow-lake-estates/"))propStatus=propStatus.replaceAll("Sold Out", "Section 1 Sold Out");
//			if(comUrl.contains("/neighborhood/hollowbrook/"))propStatus=propStatus.replaceAll("1 Lot Remaining, Only A Few Lots Remaining, Quick Move-In", "Only A Few Lots Remaining, Quick Move-In");
//
//			if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/thorp-farms/"))propType += ", Luxury Homes";
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/country-lake-estates/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/mckenzie-terrace/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/the-trails/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/meadow-lake-village/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/deer-meadows/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/buck-creek-woods/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/highlands-at-grassy-creek/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/parks-at-glen-ridge"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/stable-chase/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/north-madison-crossing/"))propType=ALLOW_BLANK;
//            if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/deer-meadows"))dType="2 Story";
			
			
			U.log("Dtype=========================> "+dType);
			//
			U.log(add[1].trim()+" - ");
			comName=comName.replace(add[1].trim()+" - ", "")
					.replaceAll("Franklin - ", "");
			U.log(comName);
			
			 //==============Unit COunt===========
	        String counting=ALLOW_BLANK;
	        String startDt=ALLOW_BLANK;
	        String endDt=ALLOW_BLANK;
	        int lotCount=0;
	        
	        if(html.contains("Community Map")) {
	        	U.log("INSIDE");
//	        	U.log(html);
//			 String lotpart=U.getSectionValue(html, "Our Neighborhoods", "View the interactive map"); //.replace("\\/", "/").replace("&quot;", "")
//			 U.log(lotpart);
	        	 String lotpart=U.getSectionValue(html, ":lots", "}]\""); //.replace("\\/", "/").replace("&quot;", "")
////			 U.log(lotpart);
			 String[] lotSection=U.getValues(lotpart, "id&quot;:", ",");
	        	
//	        	<div style="position: absolute; left: -256px;
			 lotCount=lotSection.length;
			 U.log("lotCount ::"+lotCount);
			}
			counting=Integer.toString(lotCount);
			
	       
			
			
			data.addCommunity(comName, comUrl, comType);
			data.addLatitudeLongitude(latLong[0], latLong[1], geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(notes);  
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);	
		
		j++;
		}
	}
	//This below function is used to find latLng from html page.
	String [] findLatLng(String latLngSec){
		String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
		Matcher mat = Pattern.compile("\\d{2}\\.\\d{3,},-\\d{2}\\.\\d{3,}",Pattern.CASE_INSENSITIVE).matcher(latLngSec);
		while(mat.find()){
			latLng = mat.group().split(",");
		}
		return latLng;
	}
	
	final String fetchFineBuilderData(String comUrl) throws Exception{

		String planHtmls = U.getHTML(comUrl+"/our-homes/");
		U.log(comUrl+"/our-homes/");
		String floorPlanSection[] = U.getValues(planHtmls, "series-card-floor-plans\">", "</ul>");
		
		for(String floorPlanSec : floorPlanSection){
			
			String [] planUrls = U.getValues(floorPlanSec, "<a href=\"", "\"");
			for(String planUrl : planUrls){
				U.log("planUrl:::::"+planUrl);
				String planHtml = U.getHTML(planUrl);
				planHtmls += U.getSectionValue(planHtml, "<h3 class", "<div id=\"footer");
			}
		}
		
		return planHtmls;
	}
	private String getQuickHomesData(String comName,String quickHtml) throws IOException{
		String html=ALLOW_BLANK;
		String quickLinkes[]=U.getValues(quickHtml, "<div class=\"item-grid-view clearfix\">", "Calculate your Mortgage");
		for(String quickSec:quickLinkes){
//			U.log(quickSec.toLowerCase().contains(comName.toLowerCase().trim()));
			if(quickSec.toLowerCase().contains(comName.toLowerCase().trim()) && !quickSec.contains("(OLD) ")){
				String quickUrl=U.getSectionValue(quickSec, "<p class=\"post-title\"><a href=\"", "\">");
				U.log("quickUrl++++"+quickUrl);
				if(quickUrl!=null && !quickSec.contains("Build Now")){
					html+=U.getSectionValue(U.getHTML(quickUrl), "<div class=\"page-section-inner\">", ">Calculate your Mortgage</span></button> ")
							+ U.getSectionValue(U.getHTML(quickUrl), "<div class=\"page-section page-section-property-single\">", "<!-- SCHEDULE A TOUR AREA -->");
				}
			}
			else
				continue;
		}
	
		return html;
	}
	public String getQuickHomeData() throws Exception{
		String Allquickdata=ALLOW_BLANK;
		String quickhtnm=U.getHTML("https://www.pyattbuilders.com/quick-move-ins/");
		String dropheadSec=U.getSectionValue(quickhtnm, "<html lang=\"en-US\"", "<div class=\"property-search-results-count\">");	
		quickhtnm=quickhtnm.replace(dropheadSec, "");
		Allquickdata+=quickhtnm;
		for(int i=2;i<6;i++) {
			if(!quickhtnm.contains(">LOAD MORE</a></div>"))break;
			else {
				U.log("https://www.pyattbuilders.com/quick-move-ins/page/"+i+"/");
				Allquickdata+=quickhtnm+U.getHTML("https://www.pyattbuilders.com/quick-move-ins/page/"+i+"/");
				dropheadSec=U.getSectionValue(Allquickdata, "<html lang=\"en-US\" ", "<div class=\"property-search-results-count\">");	
				Allquickdata=Allquickdata.replace(dropheadSec, "");

			}
		}
		return Allquickdata;
	}
}
