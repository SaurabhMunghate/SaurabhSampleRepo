package com.shatam.b_301_324;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.StorageHolder.Type;
import com.google.common.reflect.TypeToken;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTrumarkCompanies extends AbstractScrapper {
	private final static String BASEURL = "https://trumarkhomes.com";
	static int i;
	static int j = 0 ;
	CommunityLogger LOGGER;

	WebDriver driver = null;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractTrumarkCompanies();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Trumark Companies - Trumark Homes.csv", a.data().printAll());

	}

	public ExtractTrumarkCompanies() throws Exception {

		super("Trumark Companies - Trumark Homes", "https://trumarkhomes.com/");
		LOGGER = new CommunityLogger("Trumark Companies - Trumark Homes");
	}

	Map<String, String> headUrl = new HashMap();
	static List<String> regionArray = new ArrayList<String>(); //for status. Contains region page data of all comms. in array format

	public void innerProcess() throws Exception {
	
//		headUrl.put("1", "/neighborhoods/northern-california/");
//		headUrl.put("2", "/neighborhoods/southern-california/");
//		headUrl.put("3", "/neighborhoods/colorado/");
		
	//	String[] regions = {"/neighborhoods/northern-california/", "/neighborhoods/southern-california/", "/neighborhoods/colorado/"};
	//	String[] regions = {"/neighborhoods/northern-california/" };
		
		U.setUpChromePath();
		driver=new ChromeDriver();
		
		String html = U.getHTML(BASEURL);
		
		getRegionPageData(html, BASEURL);		//To get region page data of all communities.
		
		String mainSec = U.getSectionValue(html, "var header_communities_norcal =", "</script>"); //"var header_communities_socal");
		//U.log("mainSec"+mainSec);
		
		if(mainSec != null)
			mainSec = StringEscapeUtils.unescapeJava(mainSec.trim());
			
		//U.log("mainSec: "+mainSec);
/*		U.log(Util.matchAll(mainSec, "\\{\"id\":(\\d+),\"name\":", 0).size());
		U.log(Util.matchAll(mainSec, "\"places_json\":", 0).size());

		JsonParser parser = new JsonParser();
	
		parser.parse(mainSec);*/
		 
//		JsonArray commArray =.getAsJsonObject().getAsJsonArray();
		
//		U.log(commArray.size());
		

//		mainSec = mainSec.replaceAll("\"id\":\\d+,\"name\"", "STARTPOINT");
		String[] regSec = U.getValues(mainSec, "[[", "]]");     //3 region sections.
		U.log("regSec Length:: "+regSec.length);
		
		
		for(String reg : regSec) {
//			comData = comData.replace("\"url\":\"northern-california\"}", "")
//					.replace("\"url\":\"southern-california\"}", "")
//					.replace("\"url\":\"colorado\"", "");
//			U.log(comData);
			String[] comSec = U.getValues(reg, "{", "}");
			U.log("Community Length:: "+comSec.length);
			
			int count = 1;
			for(String comsec:comSec) {
				
				if(comsec.contains("\"isParent\":true")) //removing parent sections
					continue;
				
				//getting communities
				if(comsec.contains("\"isNeighborhood\":true")) {		
					String comUrl = BASEURL + U.getSectionValue(comsec, "\"path\":\"", "\"");
					U.log(+count+" comUrl: "+comUrl);
					count++;
					
					addDetails(comUrl, comsec);
				} 
			}
			
			
			
			
			
//			String head = headUrl.get(U.getSectionValue(comData, "\"region_id\":", ","));
//			U.log("HEAD===="+comUrl);
		//	comUrl = BASEURL + comUrl;
			
//			String comUrl = U.getSectionValue(comData, "\"cta_link\":\"", "\"") ;
			
		//	U.log(+count+" comUrl: "+comUrl);
			
				//addDetails(comUrl, comData);
		
		}
		
		
		LOGGER.DisposeLogger();
		driver.quit();
	}


	public void addSubReg(String subRegUrl) throws Exception{
		U.log("Hello::"+subRegUrl);
		String subRegHtml=U.getHTML(BASEURL+subRegUrl);
		//U.log(subRegHtml); 
		ArrayList<String> cUrl=Util.matchAll(subRegHtml, "a href=\"/(.*?)\"><img title=", 1);
		U.log("total sub com:"+cUrl.size());
		for(int m=0;m<cUrl.size();m++){
//			U.log("url is ::"+BASEURL+cUrl.get(m));
			String url=BASEURL+cUrl.get(m);
			//addDetails(url);
		}
		//addDetails("https://thecollectivemanteca.com");
	}
	

	@SuppressWarnings("unused")
	public void addDetails(String commUrl, String comData) throws Exception {
	//TODO ::
	//try{
//		comData="start "+comData;
		
		
//		 if(commUrl.contains("https://trumarkhomes.com/nullpelican-shores"))commUrl = "https://trumarkhomes.com/neighborhoods/colorado/pelican-shores";
	
//		 if (!commUrl.equals("https://trumarkhomes.com/neighborhoods/northern-california/the-strand-townhomes")) return;
		 U.log("comData====== "+comData);
//		 if(j>=20)
		 {

//		if (!commUrl.contains("https://trumarkhomes.com/neighborhoods/northern-california/the-strand")) return;
         
		 if (data.communityUrlExists(commUrl)){
	        	LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
	        	return;
	        }
			
		
		 if (commUrl.contains("https://wallisranch.com/")||commUrl.contains("/get-info/?nh=origin")) {
			 LOGGER.AddCommunityUrl(commUrl+ "---------------------------------Return");
			return;
		}
		U.log("Page Url: "+ j +" "+ commUrl);
		
		LOGGER.AddCommunityUrl(commUrl);
		String html = U.getHTML(commUrl);
//		String html = U.getHtml(commUrl,driver);
		String rem  = U.getSectionValue(html, "header_communities_norcal", "</script>");
		if(rem!=null)
			html = html.replace(rem, "");
		
		String comJson 	= U.getSectionValue(html,"var neighborhood =","var region =");
		//U.log("comJson: "+comJson);
//		FileUtil.writeAllText("/home/shatam-10/Desktop/comdata.txt", comJson);
		
		String descSec= U.getSectionValue(comJson,"\"overview\":\"<div>","<\\/div>\"");
		
//		U.log("::::::::desc sec"+descSec);

		//=================== Community Name ========================
		//String commName = U.getSectionValue(html, "<title>", " - ");
		
//		U.log("comData --->"+comData);
		
		
		String commName = U.getSectionValue(comData, "\"name\":\"", "\"").replaceAll("Collective 55\\+", "Collective");
		U.log("commName11111::"+commName);
		
		if (commName != null && (commName.contains("Northern California") || commName.contains("Southern California"))) {
			commName = U.getSectionValue(comData, "STARTPOINT :\"", "\"").replace(" 55+", "");
			U.log("commName22222::"+commName);
		}
		

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String feture=ALLOW_BLANK;
		
		if(html.contains("Features</a></li>")){
			feture=U.getHtml(commUrl+"features/", driver);
			if(rem!=null)
				feture = feture.replace(rem, "");
		}
		
		
		
		//========== Notes ==================
		String note = ALLOW_BLANK;
		
		
//		if(commUrl.contains("https://trumarkhomes.com/southern-california/edencrest/"))
//		{	add[1]="ESCONDIDO";
//		    add[2]="CA";
//		}
//		if (commUrl.contains("https://trumarkhomes.com/neighborhoods/southern-california/laube-solis-park")) {
//			note = "Pre-sales Spring 2022";
//		}
	
		
		//========== LatLng =====================

		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		
		latLng[0] = U.getSectionValue(comJson, "\"lat\":", ",");
		latLng[1] = U.getSectionValue(comJson, "\"lng\":", ",");
		
		
		if(latLng[0].contains("-")) {
			
			String temp = latLng[0];
			latLng[0] = latLng[1];
			latLng[1] = temp; 
		}
		U.log("LatLng::"+Arrays.toString(latLng));
		//============Unit Count
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		String[] lotSection;
		int lotCount=0;
		String lotHtml;
		if(commUrl.contains("/neighborhoods/southern-california/rancho-palma")) {
			lotHtml=U.getHtml("https://contradovip.com/trumark-homes/rancho-palma/site/", driver);
			U.log(U.getCache("https://contradovip.com/trumark-homes/rancho-palma/site/"));
			lotSection=U.getValues(lotHtml, "<g id=\"v.1.opt", "\"");
			lotCount=lotSection.length;
			counting=Integer.toString(lotCount);
		}
		if(html.contains("alphamap") || html.contains("apps.focus360.com")) {
		String siteMapUrl=U.getSectionValue(html, "iframe\":\"", "\"").replace("\\/", "/");
		U.log("siteMapUrl ::"+siteMapUrl);
		lotHtml=U.getHtml(siteMapUrl,driver);
		U.log(U.getCache(siteMapUrl));
		lotSection=U.getValues(lotHtml, "<div class=\"anchorshape", "\"");
		lotCount=lotSection.length;
		counting=Integer.toString(lotCount);
			if(lotCount==0) {
				lotSection=U.getValues(lotHtml, "<g id=\"lot_", "\"");
				lotCount=lotSection.length;
				counting=Integer.toString(lotCount);
				if(counting.equals("0"))
					counting=ALLOW_BLANK;
			}
			U.log("counting ::"+counting);
		}
		//============ Address =========================
		//northern-california\/jasper","directionsLink":"https:\/\/www.google.com\/maps\/dir\/\/
		
		comData = comData.replace(",<br>Sunnyvale, ", ",Sunnyvale, ").replace("Sea, Bank St,&nbsp;<br>Newark", "Sea Bank St, Newark")
				.replace("St.&nbsp;<br>Anaheim", "St., Anaheim").replace("Avenue&nbsp;<br>Escondido", "Avenue,Escondido")
				.replace("Ave.<br>Brea,", "Ave., Brea,");
		
		//String addSec = U.getSectionValue(comData, "gallery_hours\":\"<div>", "<br>");
//		U.log(comData);
		String commUrl1 = commUrl.replace("https://trumarkhomes.com/neighborhoods/southern-california/", "");
		commUrl1 = commUrl.replace("https://trumarkhomes.com/neighborhoods/colorado/", "");
//		commUrl1 = commUrl1.replace("/", "\\\\/");
		U.log(commUrl1);
		
		if(commUrl1.contains("/")) {
        	commUrl1 = commUrl1.replace("/", "");
        }
		if(commUrl1.contains("https://trumarkhomes.com/neighborhoods/northern-california/")) {
			commUrl1 = commUrl1.replace("https://trumarkhomes.com/neighborhoods/northern-california/", "");
		}
        if(commUrl1.contains("https://trumarkhomes.com/neighborhoods/colorado/")) {
        	commUrl1 = commUrl1.replace("https://trumarkhomes.com/neighborhoods/colorado/", "");
		}
        if(commUrl1.contains("https:trumarkhomes.comneighborhoodssouthern-california")) {
			commUrl1 = commUrl1.replace("https:trumarkhomes.comneighborhoodssouthern-california", "");
		}
        if(commUrl1.contains("https:trumarkhomes.comneighborhoodscolorado")) {
        	commUrl1 = commUrl1.replace("https:trumarkhomes.comneighborhoodscolorad", "");
		}
        if(commUrl1.contains("https:trumarkhomes.comneighborhoodsnorthern-california")) {
			commUrl1 = commUrl1.replace("https:trumarkhomes.comneighborhoodsnorthern-california", "");
		}
//        if(commUrl1.contains("https:trumarkhomes.comneighborhoodsnorthern-california")) {
//        	commUrl1 = commUrl1.replace("https:trumarkhomes.comneighborhoodsnorthern-california", "");
//		}
        
        U.log(commUrl1);
		String addSec = U.getSectionValue(html,commUrl1+"\",\"directionsLink\":\"https:\\/\\/www.google.com\\/maps\\/dir\\/\\/", "\",");
		U.log(addSec);
		
		U.log("addSec&7"+addSec);
		if(addSec != null)
			{
			add = addSec.replace("+", ",").split(",");
//			add = U.getAddress(addSec);
			}
		if(addSec == null) {
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "TRUE";
//			
		}
        
//		String addSec = U.getSectionValue(html, "Sales Gallery</h4>", "</div></div>");
		U.log("StreetStreetStreet== :: "+add[0]+ " City :: "+add[1]+" State :: "+add[2]+" Zip :: "+add[3]);

		//sau
		
//		String commUrl1 = commUrl.replace("https://trumarkhomes.com/neighborhoods/southern-california/", "");
//		commUrl1 = commUrl.replace("https://trumarkhomes.com/neighborhoods/colorado/", "");
//		html = html.replaceAll("\",\"directionsLink\":\"https:\\/\\/www.google.com\\/maps\\/dir\\/\\/", "");
//		html = html.replaceAll("", "").replace("", "");

//		commUrl1 = commUrl1+"\",\"directionsLink\":\"https:\\/\\/www.google.com\\/maps\\/dir\\/\\/";	
//		U.log(commUrl1);
		
//		String addSec = U.getSectionValue(html, "var neighborhood =", "google");
//		if(comData.contains("Festival-RainDance-National")) {
//			U.log("Trueeeeee");
//		}
		

		U.log("addSec firsyt"+addSec);
		
		if(addSec == null) {
		    addSec = U.getSectionValue(comData, "sales_gallery_hours\":\"<div>", "<br><br>");
//		    if(addSec!=null) {
//		    	String remSec=U.getSectionValue(addSec, "\"<div>", "\">");
//		    	addSec=addSec.replace(remSec, "");
//		    }
//		    U.log("addSec1:: "+addSec);
		}
		if(addSec == null) {
			addSec = U.getSectionValue(comData, "\"contact_box\":\"", "\",");
//			 U.log("addSec2:: "+addSec);
			
			}
		if(addSec!=null)
		addSec=addSec.replace("Monday: 2pm - 5pm<br>Tuesday - Sunday: 10am - 5pm<br><a href=\\\"https:\\/\\/g.page\\/rancho-palma?share\\\">", "");
		
		
		
		//U.log("PPPPPPPPPPPp"+Util.matchAll(html, "[\\w\\W\\s]{200}6431 N. Cava Lane[\\w\\W\\s]{100}", 0));
//		U.log("addSec3:: "+addSec);
	
		
		
		
//		if (addSec!=null&&commUrl.contains("neighborhoods/northern-california/origin")) {
//			//addSec = U.getSectionValue(html, "https://www.google.com/maps/place/", "/").replace("+", " ");
//			//933 E. Louise Ave., Manteca, CA 95336
//			add[0] = ALLOW_BLANK;
//			add[1] = ALLOW_BLANK;
//			add[2] = ALLOW_BLANK;
//			add[3] = ALLOW_BLANK;
//		}
		
		
//		U.log("AddSecLast::"+addSec);
		
//		if(addSec == null) {
//			
//			addSec = U.getSectionValue(html, "sales_gallery_hours\":\"<div>", "<br><strong>");
//			
//			if(addSec != null) {
//				addSec = addSec.replaceAll("Monday: 2pm - 5pm<br>Tuesday - Sunday: 10am - 5pm<br><a href=\\\"https:\\/\\/g.page\\/rancho-", "")
//						.replace("Monday: 2pm - 6pm,Tuesday - Sunday: 10am - 6pm,", "");
////				addSec = addSec.replaceAll("Monday - Sunday: 10:00 AM - 6:00 PM, ","");
////				addSec = addSec.replaceAll(", \"contact_box\":\"  Martha Bunch","");
//			}
////			if(commUrl.contains("-at-the-collective")) {
////				addSec = "1306 Parkcrest Circle, Manteca, CA 95336";
////			}
////			U.log("addSec: "+addSec);
//			
//			if(addSec != null && addSec.contains("/rancho-palma?share\\\">")) {
//				
//				addSec = U.getSectionValue(addSec, "rancho-palma?share\\\">", "<\\/a><br>");
////				U.log("addSec====: "+addSec);
//			}
//			if(addSec != null && addSec.contains("goocalifornia/neptune-at-melrose-heights.gl\\/maps\\/6WuyFHoKKK4QrQfGA")) {
//				
//				addSec = U.getSectionValue(addSec, "6WuyFHoKKK4QrQfGA\\\">", "<\\/a>");
////				U.log("addSec====: "+addSec);
//			}
//			
//			//U.log(">>>>>>>>>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{30}1315 Parkcrest Circle[\\w\\s\\W]{100}", 0));
//		}
		
		
//		if(commUrl.contains("/southern-california/west-village-brea"))addSec = "400 West Central Avenue, Brea, CA 92821";
//		if(addSec != null){
//			
////		U.log(addSec);
//		addSec = U.getNoHtml(addSec.replace("<br>", ","));
//		addSec = addSec.replace(",,", ",").replaceAll(".*@.*\\.com|&nbsp;,|&nbsp;|#{6,}|#01451091,|,CA DRE License|,On the corner of E. El Norte Pkwy &amp; E. Lincoln Ave.", "");
//		addSec = addSec.replace("  Escondido", ",  Escondido").replace(", Windsor", "Windor").replaceAll(",\\s*,", ".");
////		U.log("addSec:---- "+addSec);
//		
//		
////			add = U.getAddress(addSec);
////		U.log("ADDRESS: "+Arrays.toString(add));
//		}
//		if(add == null) {
//			add = new String[] {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//		}
		
//		U.log("Street :: "+add[0]+ " City :: "+add[1]+" State :: "+add[2]+" Zip :: "+add[3]);
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/origin/")){
//			add = U.getAddress("933 E. Louise Ave, Manteca, CA 95336");
//			geo = "True";
//			note = "Street Is Taken From Site Map";
//			latLng = U.getlatlongGoogleApi(add);
//			if(latLng == null) latLng = U.getlatlongHereApi(add);
//		}
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/alameda/")){
//			add[1] = "Alameda";
//			add[2] = "CA";
//		}
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/compass-bay/")){
//			add[1] = "Newark";
//			add[2] = "CA";
//		}
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/the-collection/")){
//			add[1] = "Danville";
//			add[2] = "CA";
//		}
//		
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/danville/"))
//		{	add[1]="Danville";
//		    add[2]="CA";
//		    add[0] = ALLOW_BLANK;
//		add[1] = ALLOW_BLANK;
//		add[2] = ALLOW_BLANK;
//		add[3] = ALLOW_BLANK;
//		}
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/edendale/"))
//		{	add[1]="Danville";
//		    add[2]="CA";
//		    
//		}
//		if(commUrl.contains("https://trumarkhomes.com/southern-california/west-village/"))
//		{	add[1]="Edendale";
//		    add[2]="CA";
//		    
//		}

//		if(commUrl.contains("https://trumarkhomes.com/northern-california/sunnyvale/"))
//		{	
//			add[1]="Sunnyvale";add[2]="CA";
//		}
		//add[0]=add[0].replace(" #1006","");add
		
		
		//sau
		add[0]=add[0].replace("Monday: 2pm - 5pm Tuesday - Sunday: 10am - 5pm ", "");
		if(add[0].length()<4 || add[3] == ALLOW_BLANK){
			
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "TRUE";
		}
	
		if(latLng[0]==null || latLng[0].length()<4) {
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if(latLng == null || latLng[0] == null){
			latLng = new String[]{ ALLOW_BLANK, ALLOW_BLANK};
					
		}
		
		//======= Quick Data ========
		String quickSec = U.getSectionValue(html, "\"quickmoveins\":", "\"floorplans\":");
		if(quickSec==null) quickSec = "";
		quickSec = quickSec.replaceAll("\\{\"id\":\\d+,\"name\":", "STARTPOINT");
		
		String[] quickHome = U.getValues(quickSec, "STARTPOINT", "}");
		String quickHtml = "";
		for(String quick  : quickHome) {
			
			quickHtml+=quick;
		}
//		U.log("quickHtml::: "+quickHtml);
		
		//======= Floor Data ========
		String floorSec = U.getSectionValue(html.replaceAll("var\\s*region", "varregion"), "\"floorplans\":", "varregion");
		if(floorSec==null) floorSec = "";
		floorSec = floorSec.replaceAll("\\{\"id\":\\d+,\"name\":", "STARTPOINT");
		
		String[] floorHome = U.getValues(floorSec, "STARTPOINT", "}");
		String floorHtml = "";
		for(String floor  : floorHome) {
			
			floorHtml+=floor;
		}
//		U.log("FloorHtml::: "+floorHtml);
				
		//================ Price =========================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replace("Anticipated pricing from the $800,000s+", "from the $800,000");
		//From the Low $1Ms
		html=html.replace("$1 Millions", "$1,000,000").replace("$2 Millions", "$2,000,000");

		Matcher millionPrice = Pattern.compile("\\$\\d.\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
		while(millionPrice.find()){
			//U.log(mat.group());
			String floorMatch = millionPrice.group().replace(" M", "00,000").replace(".", ",");  //$1.3 M
			html	 = html.replace(millionPrice.group(), floorMatch);
		}//end millionPrice
		comData = comData.replaceAll(" \\$(\\d)\\.(\\d)M's", " \\$$1,$200,000 ")
				.replaceAll(" \\$(\\d)Ms", " \\$$1,000,000 ");
		
		html = html.replaceAll("\\$1 MILLIONS", "$1,000,000");
		html = html.replaceAll("<span style=\"text-decoration:line-through;\">\\$\\d+,\\d+</span>", "");
		
		
//			U.log("Desc:: "+descSec);	
				if(descSec==null)descSec = ALLOW_BLANK;
		
		descSec=descSec.replace("pricing from the $800,000s+<br><\\/strong><br>Penny", "from the $800,000").replace("$300,000s", "$300,000").replace("at least $105,000", "").replace("$1 Millions", "$1,000,000").replace("$2 Millions", "$2,000,000");
//		U.log("Desc22:: "+descSec);	

		
		//price is not visible on page
	//	if(!commUrl.contains("/northern-california/the-strand"))descSec=ALLOW_BLANK;
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/southern-california/lewis-mason")){
//			floorHtml = floorHtml.replace("From the mid $700,000", "");
//			comData = comData.replace("From the mid $700,000", "");
//		}
		comData=comData.replace("From the Low 900's", "From the Low 900,000");
		
//		U.log("Desc23:: "+descSe1701 Branching Canopy Dr	Windsor	CO	80550	40.454843);	
		String prices[] = U.getPrices((quickHtml+floorHtml+comData+descSec).replace("to make at least $105,000", "").replace("$1.3Mils", "$1,300,000").replace("0Ks", "0,000"),
				"from the \\$\\d{3},\\d{3}|price\":\"\\d+,\\d+s - \\d+,\\d+s|From the Low \\d+,\\d+|Starting from \\$\\d,\\d{3},\\d{3}|Starting from the High \\$\\d{3},\\d{3}|from the low \\$\\d+,\\d+,\\d+|\"price\":\"\\$\\d,\\d{3},\\d{3}\\+\"|Mid \\$\\d,\\d{3},\\d{3}|\"price\":\"\\$\\d{3},\\d{3}\\+\"|Starting From \\$\\d{3},\\d{3}|<li>\\$\\d{3},\\d{3}</li>|<li>\\$\\d{1},\\d{3},\\d{3}</li>|\\$\\d,\\d+,\\d+|\\$\\d{3},\\d{3}", 0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
//		U.log(">>>>>>>>>>>>>>>>"+Util.matchAll(quickHtml+floorHtml+comData+descSec, "[\\w\\s\\W]{30}Starting from \\$1.3Mils[\\w\\s\\W]{30}", 0));
		
		U.log("price :::"+minPrice +"\t"+maxPrice);
		//================ Sqft =========================
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		html=html.replace("–", "-").replace("&#8211;", "-");

		if(comData != null)comData =comData.replaceAll("retail space for three separate units ranging from \\d{3} to \\d,\\d{3} square feet","");
		
//		U.log(comData);
		

		String[] sqft = U.getSqareFeet((comJson+comData+quickHtml+floorHtml+descSec).replaceAll("offers 1,783", ""),
				"\\d,\\d{3} SQ. FT. to \\d,\\d{3} SQ. FT|sqft\":\"\\d,\\d{3} Sq. Ft.|sqft\":\"Approx\\. \\d{3} Sq. Ft.|\"sqft\":\"Approx\\. \\d,\\d{3} – \\d,\\d{3} sqft\"|\"sqft\":\"Approx\\. \\d,\\d{3}-\\d,\\d{3} sqft\"|Approx. \\d,\\d+ - \\d,\\d+ sqft|from approximately \\d,\\d+ sq. ft|from \\d,\\d+ to \\d,\\d+ square feet|townhome plans ranging from \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} sq\\. ft|Approx. \\d{3} - \\d,\\d{3} Sq. Ft.|Approx. \\d{1},\\d{3} Sq. Ft|stunning \\d,\\d{3} Sq. Ft.|\\d,\\d{3}-\\d,\\d{3} Sq.Ft.|Approx. \\d{1},\\d{3} - \\d{1},\\d{3} sq.ft.|\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|\\d,\\d+ &#8211; \\d,\\d+ Sq. Ft.|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d,\\d+ � \\d,\\d+ Square Feet|\\d,\\d+ - \\d,\\d+ Square Feet|\\d,\\d+ � \\d,\\d+ Square Feet|Up to \\d,\\d{3} Square Feet|\\d,\\d{3} Square Feet",0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comJson+comData+quickHtml+floorHtml+descSec, "[\\s\\w\\W]{30}4,113[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comJson, "[\\s\\w\\W]{30}2143[\\s\\w\\W]{30}", 0));
		html=html.replaceAll("Detached<br>&nbsp;&nbsp;Homes|New Detached<br />Homes", "Detached Homes");
		
		
		// Community Type
//		html = html.replaceAll("55\\+ Neighborhood</div></a></li>", "");
		comData=comData.replace("most striking waterfronts around", "serene waterfront community");
		String communitytype = U.getCommunityType((comData+comJson));//.replaceAll("Country Club\"|Country Club Dr", ""));//|55\\+ Neighborhood</div></a></li>
//		U.log(aboutPg.replaceAll("Country Club\",\"|Country Club Dr", ""));

//		U.log(">>>>>>>>>>>>"+Util.matchAll(comData, "[\\s\\w\\W]{30}55+ neighborhood[\\s\\w\\W]{30}", 0));

	
//		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//		U.log("---="+communitytype);
		//=========== Property Type =================
		html =html.replaceAll("Detached<br />\\s+Homes", "Detached Homes");
		if (feture!=null) {
			feture = feture.replaceAll("LUXURIOUS</b> MASTER SUITE|Luxurious</b> Master Suite", "Luxurious Master Suite");
		}
		
//		U.writeMyText(combinedHomeHtml);
		String proptype = U.getPropType((comData+floorHtml+quickHtml).replaceAll("style = 'craftsman';|-cottage-|&quot;Townhouse&quot|_type\":\"Townhouse", ""));
		
//		U.log("<<<<<<<<<<<<"+Util.matchAll(combinedHomeHtml, "[\\s\\w\\W]{30}craftsman[\\s\\w\\W]{30}", 0));
//		if (commUrl.contains("https://trumarkhomes.com/northern-california/sunnyvale/"))
//		{
//			proptype="Single Family Homes";		
//		}
		// Derive Prop
		html = html.replace("Fielding at Wallis Ranch</a></li>", "").replace("fielding-at-wallis-ranch/\">", "");
		html = html.replaceAll("wallis-ranch/|Wallis Ranch</a></li>|-ranch|Rancho|Wallis Ranch|/rancho|Wallis ranch", "").replace("Two- and Three-Story ", " 2 Story  3 Story ");
		quickHtml=quickHtml.replace("2-Stories", " 2 story")
				.replaceAll("rancho|Rancho|wallis-ranch/|Wallis Ranch</a></li>|Wallis Ranch|-ranch|Wallis ranch", "");
		floorHtml=floorHtml.replace("2-Stories", " 2 story")
				.replaceAll("rancho|Rancho|wallis-ranch/|Wallis Ranch</a></li>|Wallis Ranch|-ranch|Wallis ranch", "");
		
		String dtype = U.getdCommType((comData.replaceAll("rancho|Rancho", "")+quickHtml+floorHtml.replaceAll("lives like a 2-story", ""))
				.replaceAll("The first floor features a secondary bedroom|space on the second floor with a gourmet|second floor", "")
				.replace("stories\":\"1-Story", "one-story"));
		
//		("<<<<<<<<<<<<"+Util.matchAll(quickHtml+floorHtml, "[\\s\\w\\W]{30}2-story[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<<"+Util.matchAll(quickHtml+floorHtml, "[\\s\\w\\W]{30}first floor[\\s\\w\\W]{30}", 0));
	
		//========= Status ===================
		String regionStatus = ALLOW_BLANK;
		String nameCom = ALLOW_BLANK;
		
		for(String regsec:regionArray) {
			nameCom = U.getSectionValue(regsec, "\"name\":\"", "\",").replaceAll("Collective 55\\+", "Collective");
//			U.log("nameCom: "+nameCom);
			
			//MATCHING NAMES [Check if names are proper]
			if(nameCom.equals(commName)) {
				regionStatus += regsec;
			}
		}
		
//		U.log("regionStatus: "+regionStatus);
	
		String rmSec=U.getSectionValue(html, "<header>", "<a class=\"get-info\"");//.replaceAll("<header>(.*?)<a class=\"get-info\"", "")
		if (rmSec != null)	html=html.replace(rmSec, "");
		rmSec=U.getSectionValue(html, "<head>", "<body");
		if (rmSec != null)	html=html.replace(rmSec, "");
		
		comData=comData.replace("&nbsp;NOW OPEN", "").replaceAll("NEW HOMES<br />\n" + 
				"NOW SELLING", "NEW HOMES NOW SELLING");
		comData=comData.replace("NEW HOMES COMING<br>SUMMER 2017", "NEW HOMES COMING SPRING 2017");
		comData=comData.replace("Quick Move-In</a>","").replace("1X (SOLD OUT)", "")
				.replaceAll("Now Selling Model Homes|\"cta_copy\":\"Sold Out\"|2017 to Dublin,", "").replace("<br>Now Selling!</a>", "").replace("Now Selling!</a>", "").replace("NOW SELLING!</a>", "")
				.replaceAll("grand opening event|model opening|Models Coming Summer 2021|Ferry \\(coming|Clubhouse Coming Soon|</h3>\\s*<p>SOLD OUT</p>|Quick move-in opportunities!|CA<br/>FINAL OPPORTUNITY|CA<br>ONLY 1 HOME REMAINS|Bedrooms<br />\\s*SOLD OUT</li>|\\(SOLD OUT\\)</a>|Now Open|now open|MODELS NOW SELLING|Coming Soon!</a>|SOLD OUT<br>|<br>SOLD OUT</a>","");
		
//		U.log("--->"+comData);          //////////////////////////////
		String propstatus = U.getPropStatus( (comData + regionStatus).replaceAll("snipe\":\"<div>Now Selling|hero_image_snipe\":\"Now Selling| - More Coming Soon|Coming Early 2022\",\"visualizer_src\"", "")); //		

//		U.log("<<<<<<<<<<<<"+Util.matchAll(comData + regionStatus, "[\\s\\w\\W]{30}Now Selling[\\s\\w\\W]{30}", 0));
		U.log("propstatus: "+propstatus);

		
		//U.log(html);
//		propstatus=propstatus.replaceAll(",Now Open|Now Open","");
//		if(propstatus.length()<4)
//			propstatus=ALLOW_BLANK;
		
		if(commUrl.contains("https://trumarkhomes.com/northern-california/sp78/"))quickHtml=quickHtml.replace("<div id=\"quick-move-in-wrap\">", ""); //quick home redirect to site map 
		
		
//		if (quickHome.length>0 &&! propstatus.contains("Quick") && !commUrl.contains("northern-california/glass-bay/")) 
//		{
//			if (propstatus.length()>3) {
//				propstatus+=", Quick Move-In";
//			}else{
//				propstatus="Quick Move-In";
//			}
//		}california/neptune-at-melrose-heights
		
		commName=commName.replace("Founders<br>Chino Hills, CA<br>Coming Soon!","Founders In Chino Hills");
		
		//======= It coming from pop up =============
//		if(commUrl.contains("https://trumarkhomes.com/northern-california/fielding-at-wallis-ranch/"))communitytype = "Gated Community,Resort Style,Master Planned";
	
//		if (commUrl.contains("https://trumarkhomes.com/southern-california/west-village/")) {dtype=dtype.replace(", 1 Story, 2 Story", "");add[0]="215 S Brea Blvd";minSqft="2246";maxSqft="2280";
//		add[0]="400 W. Central Avenue";
//		add[1] = "Brea";
//		add[2] = "CA";
//        add[3]="92821";}
		
		
		
		regionStatus=regionStatus.replaceAll("title\":\"PRE-SALES PROCEDURES|title\":\"Pre-Sales Procedures|<div>PRE-SALES PROCEDURES|<strong>Pre-Selling Soon", "");
		if(note.isEmpty() || note == ALLOW_BLANK) note = U.getnote(comData+descSec+regionStatus);//.replaceAll("title\":\"PRE-SALES ", "");
		
//		U.log("<<<<<<<<<<<<"+Util.matchAll(comData + regionStatus, "[\\s\\w\\W]{30}Pre-sale[\\s\\w\\W]{50}", 0));


//		propstatus = propstatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon");
//		
//		add[0] = add[0].replace("Temporarily Closed, ", "");
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/northern-california/edendale-danville")) 
//			add[0]="Camino Tassajara & Sherburne Hills Dr";
//		
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/northern-california/crest-at-alameda-point")) {
////			proptype+=", Townhouse";
//		dtype=dtype.replace("2 Story,", "");
//		}
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/northern-california/leeward-at-alameda-point"))
//			dtype=dtype.replace(", 4 Story, 1 Story", "");
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/northern-california/origin")) {
//			proptype+=", Luxury Homes";
//		
//		}
//		if(commUrl.contains("crest-at-alameda-point"))propstatus=propstatus.replace(", Quick Move-In", "");
////			note = "Pre-Selling Fall 2021";
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/northern-california/jasper"))
//			note = "Pre-Selling December 2021";
////		if(commUrl.contains("northern-california/origin"))propstatus="Now Selling";
//		if(commUrl.contains("https://trumarkhomes.com//neighborhoods/southern-california/sunset-at-melrose-heights")) {
//			minSqft="1175";
//			maxSqft="1720";
//		}
//		if (commUrl.contains("https://trumarkhomes.com/neighborhoods/colorado/RainDance-National")) {
//			minSqft="2124";
//			maxSqft="4400";
//		}
//		if(commUrl.contains("sunset-at-melrose-heights")) {
//			propstatus = "Coming Soon";
//			//note = "Pre-Selling November 2021";
//		}
//		if (commUrl.contains("https://trumarkhomes.com/neighborhoods/colorado/Festival-RainDance-National"))
//			commName ="Festival at RainDance National";
//		if (commUrl.contains("https://trumarkhomes.com/neighborhoods/colorado/Sugar-Hills-RainDance-National")) {
//			commName ="Sugar Hills at RainDance National";
//			if(proptype.length()>0) {
//				proptype=proptype+", Custom Homes";
//			}
//			else
//				proptype="Custom Homes";
//		}
//		if (commUrl.contains("https://trumarkhomes.com/neighborhoods/southern-california/strand-at-melrose-heights")) {minSqft="1745";maxSqft="2143";}	
//		if (commUrl.contains("northern-california/the-strand")|| commUrl.contains("colorado/pelican-shores")) {
//			propstatus=propstatus.replace(", Quick Move-In", "");
//		}
		
//		if (commUrl.contains("southern-california/zest-covina")||commUrl.contains("southern-california/laube-solis-park") ||commUrl.contains("southern-california/covina-bowl")) propstatus="Coming Soon";
//
//		if (commUrl.contains("https://trumarkhomes.com/neighborhoods/northern-california/Dawn-at-the-collective")) minPrice = "$500,000"; 
//		
//		if (commUrl.contains("northern-california/Penny-Lane") ||commUrl.contains("/vistas-mockingbird-canyon")
//				||commUrl.contains("/laube-solis-park")) counting=ALLOW_BLANK;
		
//		U.log(add[0]);
		
		if(commUrl.contains("california/neptune-at-melrose-heights")) {
			add[0] = "1714 Crabapple Way";
			add[1] = "Oceanside";
			add[2] = "CA";
			add[3] = "92056";
		}
		if(commUrl.contains("colorado/Sugar-Hills-RainDance-National")) {
			add[0] = "1716 Branching Canopy Dr";
			add[1] = "Windsor";
			add[2] = "CO";
			add[3] = "80550";
			
		}
		if(commUrl.contains("/neighborhoods/northern-california/Penny-Lane")) {
			note ="";
		}
		if(commName.contains("The Strand")) {
			propstatus = "Now Selling";
		}
		if(commUrl.contains("neighborhoods/northern-california/origin")) {
			minSqft = "2493";
		}
		
		data.addCommunity(commName.toLowerCase(), commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus.replace("Now Selling Phase 4, Now Selling", "Now Selling Phase 4"));
		data.addNotes(note);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}j++;
//	}catch(Exception e){}
	}
	
	public static  void getRegionPageData (String html, String BASEURL) throws IOException {
		
		String regHtml = U.getHTML(BASEURL + "/neighborhoods/northern-california/") +
				U.getHTML(BASEURL + "/neicalifornia/neptune-at-melrose-heightsghborhoods/southern-california/")+ 
				U.getHTML(BASEURL + "/neighborhoods/colorado/");

		String[] statusSec = U.getValues(regHtml, "var currentneighborhoods =", "var pastneighborhoods");
		for(String reg:statusSec) {

			JsonParser json = new JsonParser(); 
			 
			JsonArray array = new JsonArray(); 
			array = (JsonArray)json.parse(reg);	
			for(int i=0; i<array.size(); i++) {
				String regionData = array.get(i).toString();
				regionArray.add(regionData);
			}
			//U.log("Total regionArray: "+regionArray.size());
		}	
	}
}