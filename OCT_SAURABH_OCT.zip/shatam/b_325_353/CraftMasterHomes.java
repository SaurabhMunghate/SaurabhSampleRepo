package com.shatam.b_325_353;

import java.util.Arrays;

import com.shatam.b_161_180.ExtractEagleConstruction;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class CraftMasterHomes extends AbstractScrapper {
	//Author Madhuri 

	
	CommunityLogger LOGGER;
	
	static int j=0;
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new CraftMasterHomes();
		a.process();
		//a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"CraftMasterHomes.csv", a.data()
				.printAll());
	}
	public CraftMasterHomes () throws Exception {
		super("CraftMasterHomes","https://www.craftmasterhomes.com/");
		LOGGER=new CommunityLogger("CraftMasterHomes");
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.craftmasterhomes.com/new-homes/");
		String comSec[]=U.getValues(mainHtml, "<div class=\"oi-infowindow-content\"", "</div>");
		U.log("com count==="+comSec.length);
		for(String sec:comSec) {
			String comName=U.getSectionValue(sec, "name oswald text-navy font-medium mb-2\">", "</p>");
			String comUrl=U.getSectionValue(sec, "<a href=\"", "\">");
			comUrl="https://www.craftmasterhomes.com"+comUrl;
//			U.log("Name n Url : "+comName+" "+comUrl);
//			try {
				addDetails(comName,comUrl,sec);
//			} catch (Exception e) {}
		    }
		LOGGER.DisposeLogger();			
		}
		
//	}
	private void addDetails(String comName, String comUrl, String sec ) throws Exception {
		// TODO Auto-generated method stub
		
		U.log("Count==>"+j);
		
//		if(!comUrl.contains("https://www.craftmasterhomes.com/new-homes/va/mechanicsville/rock-creek/8562/")) return;
		
	     U.log("comUrl==>"+comUrl);
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------>repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHTML(comUrl);
		String htmlHome=U.getHTML("https://www.craftmasterhomes.com/new-homes/available/");
//		U.log("SEc===="+sec);
		
	//	String htmlHome=U.getHTML("https://www.craftmasterhomes.com/new-homes/available/");
		String availHome=ALLOW_BLANK;
		int count=0;
//		String homeSec[]=U.getValues(htmlHome, "<div class=\"card-body text-center\">", "alt=\"View Home\" /></button>");
		
		String homeSec[]=U.getValues(htmlHome, "<div class=\"card-body text-center\">", "VIEW HOME<img");
		U.log("homeSec length ==== "+homeSec.length);
		
		for(String hmsec:homeSec) {
		String homeUrl=U.getSectionValue(hmsec,"href=\"", "\"");
		U.log("homeUrl===="+homeUrl);
		homeUrl="https://www.craftmasterhomes.com"+homeUrl;
		String hmName=U.getSectionValue(htmlHome,"<div class=\"card-body text-center\">", "</div></div></div></div></div></div>");
		String MyHomeHtml=U.getHTML(homeUrl);
		//U.log("XCom name & Home Url"+comName+ " " +homeUrl);
		String tempComName=comName.replaceAll("\\s", "-");
		
		U.log("temp com Name=="+tempComName);
		if(homeUrl.contains(tempComName.toLowerCase().trim())) {
			//addDetails(comName,comUrl,hmsec,MyHomeHtml);
		//	U.log("mapping chk "+Util.match(homeUrl, tempComName));
			 availHome+=hmsec;
			 count++;
		}
		
	    }
//	    
//	    }
		//****floor plans
		String MyflrData=ALLOW_BLANK;
		String floorsec = U.getSectionValue(html, "Available</span><span class=\"upper\">Floorplans</span>", "Move-In Ready</span><span class=\"upper\">Homes</span>");
		
//		U.log("floorsec >>>>>>>>>> : "+floorsec);
		
		if(floorsec == null) {
			floorsec = U.getSectionValue(html, "Available</span><span class=\"upper\">Floorplans</span>", "Around the</span><span class=\"upper\">Neighborhood</span>");
		}
//		U.log("floorsec: "+floorsec);
		
		if(floorsec != null) {
			String []floorplanSec=U.getValues(floorsec, "<div class=\"font-medium text-navy oswald one-space\">", "VIEW FLOORPLAN");
			U.log("floorplanSec.length: "+floorplanSec.length);
			
			for(String flrpln:floorplanSec) {
				String flrUrl=U.getSectionValue(flrpln, "href=\"", "\"");
				flrUrl="https://www.craftmasterhomes.com/"+flrUrl;
				U.log("Floor Url: "+flrUrl);

				String flrdesc=U.getHTML(flrUrl);
				 MyflrData+=" "+flrpln+flrdesc;
			}
		}
		
		
		String geo="False";
		//**********latlng	
//	String lat=ALLOW_BLANK,lng=ALLOW_BLANK;
	String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
	String latlngSec=U.getSectionValue(html, "<a href=\"https://maps.google.com?daddr=", "\"");
	U.log("latlngSec=="+latlngSec);
	latlng=latlngSec.split(",");
//	lat=U.getSectionValue(sec, "data-latitude=\"","\"");
//	lng=U.getSectionValue(sec, "data-longitude=\"", "\"");
//	latlng[0]=lat;
//	latlng[1]=lng;
	U.log("LatLng is"+Arrays.toString(latlng));
	
	//*****Price
	
	String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	
	availHome = availHome.replaceAll("blue oswald text-uppercase\">\\$\\d{3},\\d{3}</div><span class=", "");
	
	String price[]=U.getPrices(html+MyflrData+availHome,"Priced at</span> <span \\.\">\\$\\d{3}\\d{3}|\\$\\d{3},\\d{3}|",0);
	minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
	maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
	U.log("minPrice="+minPrice+"       "+"maxPrice="+maxPrice);
	
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}742,[\\s\\w\\W]{30}", 0));
//	U.log(">>>>>>>>>>>>"+Util.matchAll(MyflrData, "[\\s\\w\\W]{30}742,[\\s\\w\\W]{30}", 0));
//	U.log(">>>>>>>>>>>>"+Util.matchAll(availHome, "[\\s\\w\\W]{30}742,[\\s\\w\\W]{30}", 0));
	
	//******SQFT
	String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
	String sqft[]=U.getSqareFeet(html+MyflrData+availHome,"\\d{4}\\+ Square Feet|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|range from \\d{4} - \\d{4} square feet|range from \\d{4} - over \\d{4} square feet|\\d,\\d{3} –\\d,\\d{3} Sq. Ft|range from \\d{4} to \\d{4}+ square feet|ranging from\\d,\\d{3} - \\d,\\d{3}+ sf. ", 0);
	minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
	maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	U.log("minSqf="+minSqf+"     "+"maxSqf="+maxSqf);
	
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}2400[\\s\\w\\W]{80}", 0));
	//*****Address
	
	String[] add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK}; 
	String addSec = U.getSectionValue(sec, "<p class=\"address font-xsmall text-blue sans-regular extra-space mb-2\">", "</p>");
	U.log("Address sec=="+addSec);
	addSec=addSec.replaceAll("<br/>|<br />", ",").trim();
	//U.log("Address sec2"+addSec);
	if(addSec!=null){
		
		add  =U.getAddress(addSec);
		U.log("Address::::::"+Arrays.toString(add)); 
		add[0].replace("(GPS: )", "");
	}
	if(add[0]==null || add[0].length()<5)
	{
//		String latLng[]= {lat,lng};
		add=U.getAddressGoogleApi(latlng);
	if(add==null)add=U.getGoogleAddressWithKey(latlng);
		geo="TRUE";
		
	}
	add[0]=add[0].replace("(GPS: )", "");
	
	//****communtiy type
//	String comDesc=U.getSectionValue(html, "<div class=\"wysiwyg sans-light font-small text-grey\"><p>", "</p></div>");
	html=html.replace("golf courses, and school information are not guaranteed", "")
			.replaceAll("ocated inside the master-planned community of New Kent Vineyards","");
	String ctype = U.getCommType(html.replace("The Cottages at Viniterra is a 55+", "The Cottages at Viniterra is a  55+ Community ")+sec);
	U.log("Community type "+ctype);
	
	//*****Property Status
	html=html.replace("coming soon - a dog park", "").replaceAll("href=\"/new-homes/available/\">Move-In Ready Homes</a> <a class=", "");
	String status=ALLOW_BLANK;
	
	status=U.getPropStatus((html).replaceAll("new Moseley Elementary school opening Fall 2022|href=\"/new-homes/available/\">Move-In Ready Homes</a>", ""));
	
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{80}Coming Soon[\\s\\w\\W]{80}", 0));
	U.log("status===== "+status);
	status=status.replaceAll("Move-in Ready Homes|, Move-in Ready Homes|, Move-in Ready",ALLOW_BLANK);
//	if(status.length()>4 &&!status.contains("Move-in Ready")) {
//	if(count>0)
//		status+= "Move-in Ready";
//	else
//		status=status.replace(", Move-in Ready","");
//	
//	}
//	if(count<=0) {
//		status=status.replaceAll("[,]*[\\s]*Move-in Ready","");
//	}//bcz all homes are sold
	U.log("proprty Status===="+status);
	
	//**(*Property Type
	MyflrData = MyflrData.replaceAll("Farmhouse Exterior|Rear Patio|-Patio_|data-title=\"Patio|Townsend Grand Patio", "");
	String propType=U.getPropType((html+MyflrData).replaceAll("Traditional Elevation|clubhouse features an outdoor patio with a fireplac|11/22/Cottages|>Craftsman<|>Farmhouse<|xsmall\">Traditional</div></a>|-xsmall\">Craftsman</div></a>|Craftsman Elevation|Traditional Elevation|<br/>Carriage House</p><p class=\"price font-large|<br>Carriage House", ""));
	U.log("PropType : "+propType);
	
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html+MyflrData, "[\\s\\w\\W]{30}Cottage[\\s\\w\\W]{30}", 0));
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html+MyflrData, "[\\s\\w\\W]{30}Cottages[\\s\\w\\W]{30}", 0));
	
	//****derived PropType
	MyflrData = MyflrData.replaceAll("The 1st floor features a private Owners|family room are also on the 1st floor|separate room on the 1st floor|"
			+ "1st Floor Owners Suite|are also on the 1st floor|finished third floor|and a third floor with rec room|"
			+ "located on the first floor|plan first floor includes a formal|first floor features|open 1st floor|on the 1st floor", "");
	MyflrData = MyflrData.replaceAll("=\"Ranch-style|third floor","");
	html = html.replaceAll("optional third floors|third floor", "").replace("Ranch-style", "");
	if(homeSec.length>0) {
		if(status.length()>2)
		status=status+", Move-In Ready";
		if(status.length()<2)
			status="Move-In Ready";
	}
	String dPropType=U.getdCommType(html+MyflrData);
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html+MyflrData, "[\\s\\w\\W]{10}master[\\s\\w\\W]{30}", 0));
	//U.log(">>>>>>>>>>>>"+Util.matchAll(html+MyflrData, "[\\s\\w\\W]{5}third floor[\\s\\w\\W]{30}", 0));
	//U.log(">>>>>>>>>>>>"+Util.matchAll(MyflrData, "[\\s\\w\\W]{30}Ranch-style[\\s\\w\\W]{30}", 0));
	U.log("Derived comm type"+dPropType);
	//*****Note
	String note = U.getnote(html);
	U.log("Note "+note);
//	status=status.replaceAll("-,|-", "");
	if(status.length()==0)
		status=ALLOW_BLANK;
	
	
	// ------------------ No. of units ------------------------
	String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
	
	
	
	data.addUnitCount(units);
	data.addConstructionInformation(startDt, endDt);
	data.addCommunity(comName, comUrl, ctype);
	data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
	data.addSquareFeet(minSqf, maxSqf);
	data.addPrice(minPrice, maxPrice);
	data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
	data.addPropertyType(propType, dPropType);
	data.addPropertyStatus(status.replace("Movein Ready", "Move-In Ready"));
	data.addNotes(note);
	
	
	j++;
	}
	

}

