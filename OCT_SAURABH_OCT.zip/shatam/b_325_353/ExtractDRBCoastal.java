/**
 * @author Pallavi
 * @date 21/8/2021
 * 
 */

package com.shatam.b_325_353;
import java.util.Arrays;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDRBCoastal extends AbstractScrapper{
	CommunityLogger LOGGER;
	
	
	public ExtractDRBCoastal() throws Exception {
		// TODO Auto-generated constructor stub
		super("DRB Coastal", "https://www.drbcoastal.com/");
		LOGGER = new CommunityLogger("DRB Coastal");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractDRBCoastal();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"DRB Coastal.csv", a.data().printAll());
	}
	
	
	//extract communities from region
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml = U.getPageSource("https://www.drbcoastal.com/_dm/s/rt/actions/sites/26d430d1/collections/Search%20Comms/ENGLISH?_=1629526733792");
		mainHtml = mainHtml.replace("\\\"", "\"");
		
		String commSecs[] = U.getValues(mainHtml, "{\"uuid\":\"", "\"page_item_url\"");
		U.log(commSecs.length);
		for(String sec: commSecs) {
			String comUrl = U.getSectionValue(sec, "\"CommunityUrl\":\"", "\"");
			if(comUrl == null)comUrl = "https://www.drbcoastal.com/community-details/"+U.getSectionValue(sec, "\"DudaUrl\":\"", "\"");
			U.log(comUrl);
			String comName = U.getSectionValue(sec, ",\"BrHi\":", "\",\"Desc\":");
			comName=comName.replaceAll("\\d+,\"Name\":\"", "");
			U.log(comName);
//			try {
				addDetails(comUrl, comName, sec);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}
	//extract community details
	private void addDetails(String url,String name, String mainData) throws Exception {
			
//---------- For single execution ----------------------
//		    if(!url.contains("https://www.drbcoastal.com/community-details/The-Estuary-151857")) return;
		    
		    
			U.log("mainData: "+mainData);
			//Community url
			U.log("Communtiy Url: "+url);
			
			//Community Name
			U.log("Community Name: "+name);
			
			//Html 
			String mainHtm = U.getPageSource(url);
			
			//Address and latlong 
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
			add[0] = U.getSectionValue(mainData, "\"SalesOfficeAddress\":\"", "\"");
			add[1] = U.getSectionValue(mainData, "\"SalesOfficeCity\":\"", "\"");
			add[2] = U.getSectionValue(mainData, "\"SalesOfficeState\":\"", "\"");
			add[3] = U.getSectionValue(mainData, "\"SalesOfficeZip\":\"", "\"");
			
			//latLang
			String latlong[]={ALLOW_BLANK,ALLOW_BLANK};
			latlong[0]=U.getSectionValue(mainData, "\"Lat\":\"", "\"");
			latlong[1]=U.getSectionValue(mainData, "\"Lng\":\"", "\"");
			
//			if(url.contains("https://www.drbcoastal.com/community-details/The-Estuary-151857")) {
//				add[0] = null; //duet to incorrect json geo
//			} 
			
			if(add[0]==null || add[0].length()<2) {
				add[0] = U.getAddressGoogleApi(latlong)[0];
				geo="True";
			}
		
			U.log("Address: "+Arrays.toString(add));
			U.log("Latlng: "+Arrays.toString(latlong));

			//HomesData =====
			String homesData = ALLOW_BLANK;
			String allHomesDataHtml = U.getPageSource("https://www.drbcoastal.com/_dm/s/rt/actions/sites/26d430d1/collections/Search%20Homes/ENGLISH?_=1629529831520");
			allHomesDataHtml = allHomesDataHtml.replace("\\\"", "\"");
//			FileUtil.writeAllText("/home/shatam-10/Desktop/data/homesCoast.txt", allHomesDataHtml);
			
			String allHomesData[] = U.getValues(allHomesDataHtml, "{\"uuid\":\"", "\"page_item_url\"");
			for(String home:allHomesData) {
				home=home.replaceAll("Phillips Creek approximately|Phillips Creek Collection|off site at Phillips Creek", "");
				if(home.contains(name)) {
//					U.log("\n"+home+"\n");
					homesData+=home;
				}
			}
//			U.log("homesData: "+homesData);
			//Prices 
			mainData = mainData.replace("0s", "0,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			mainData=mainData.replace("From the $500s!", "From the $500,000!");
			String[] price = U.getPrices(homesData +mainData, 
					"Rd.\",\"PriceLo\":\\d{7},|\"PriceLo\":\\d{6},\"Green|From the \\$\\d+,\\d+|from the \\d{3},\\d{3}|UPPER \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|\"PriceHi\":\"\\d{7}\"|PriceLo\":\"\\d{7}\"|\"PriceHi\":\"\\d{6}\"|\"PriceLo\":\"\\d{6}\"",
					0);
			minPrice = price[0]!=null ? price[0] : ALLOW_BLANK;
			maxPrice = price[1]!=null ? price[1] : ALLOW_BLANK;
			U.log("minPrice: "+minPrice+"\tmaxPrice: "+maxPrice);
//			U.log("mmmmmm"+Util.matchAll(mainData, "[\\w\\s\\W]{10}329,045[\\w\\s\\W]{10}", 0));
			//U.log("mmmmmm"+Util.matchAll(mainHtm, "[\\w\\s\\W]{10}40.964[\\w\\s\\W]{10}", 0));
			//sqFt 
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(homesData +mainData, 
					"\\d{4} - \\d{4} Sq.Ft.|up to \\d,\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq.ft.|Almost \\d,\\d{3} Sq. Ft|\\d{4} Sq Ft|\"SftLo\":\\d{3}\"|\"SftHi\":\\d{3}\"|\"SftLo\":\\d{4}|\"SftHi\":\\d{4}",
					0);
			minSqf = sqft[0]!=null ? sqft[0] : ALLOW_BLANK;
			maxSqf = sqft[1]!=null ? sqft[1] : ALLOW_BLANK;
			U.log("minSqf: "+minSqf+"\t maxSqf: "+maxSqf);
			
			//CommuntiyType
			if(mainData.contains("\"IsMasterPlanned\":true")) {
				mainData += "Master Planned";
			}
			String cType = U.getCommunityType(mainData.replaceAll("\"IsGated\":1|IsGated\":0|config.Gated|data.IsGated", ""));
			
//			U.log("mmmmmm"+Util.matchAll(mainData, "[\\w\\s\\W]{100}Gated[\\w\\s\\W]{100}", 0));

			
			
			//PropertyStatus
			String moveIndates[] = U.getValues(homesData, "\"MoveInDate\":\"", "\"");
			String moveData = "";
//			for(String date:moveIndates) {
////				U.log("moveDate: "+date);
//				if(date.length()>3)
//				moveData+="Quick Move-Ins"+"\n";
//			}
			mainData = mainData.replace("Now open by appointment", "");
			
			
			String propStatus = U.getPropStatus((mainData+moveData).replaceAll("C -Coming Soon|Area and Others Coming Soon|area and others coming soon|Before Hawthorne is Sold Out|LAST CHANCE! Amenity Filled Community|Now Selling! Exceptional Main Level Living", ""));
			propStatus=propStatus.replace("Quick Move-in", "Quick Move Ins");
			
			//-----For quick move-in status---------
			int quickCount = 0;
			if(mainData.contains("\"NumQmi\":")) {
				
				String numQmi = U.getSectionValue(mainData, "\"NumQmi\":", ",\"");
				quickCount = Integer.parseInt(numQmi);
				
				U.log("quickCount: "+quickCount);
			}
			
			if(quickCount > 0) {
				if(propStatus == ALLOW_BLANK)
					propStatus = "Quick Move Ins";
				else if(propStatus != ALLOW_BLANK)
					propStatus = propStatus + ", Quick Move Ins";
			}
			
			U.log("propStatus::::::::::::::"+propStatus);
//			U.log("mmmmmm"+Util.matchAll(mainData, "[\\w\\s\\W]{30}Coming Soon[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(mainHtm, "[\\w\\s\\W]{50}Coming Soon[\\w\\s\\W]{50}", 0));

			
			//PropertyType
			String proptype =U.getPropType((homesData +mainData)
					.replace("South Pointe Estates will offer the DRB Coastal home designs", "South Pointe Estates will offer the DRB Coastal Style home designs")
					.replace("Luxury , Elevated, Single Family Homes with Marsh Views", "luxury living , Elevated, Single Family Homes with Marsh Views")
					.replaceAll("Elevated Craftsman style homes|views in your estate home minutes from the beach|\"IsCondo\"|CondoOrTownhome|IsTownHome", ""));
			U.log("proptype: "+proptype);
//			U.log("mmmmmm"+Util.matchAll(homesData +mainData, "[\\w\\s\\W]{1}luxury[\\w\\s\\W]{50}", 0));

			
			
			//derivedPropType
			homesData = homesData.replace("\"Name\":\"Stories\",\"Value\":\"", "stories ");
			String dproptype =U.getdCommType((homesData +mainData).replace("1st level", "1 story").replaceAll("Floor|floor|Colonial Revival", ""));
			
			U.log("dproptype: "+dproptype);
//			U.log(Util.matchAll((homesData +mainData),"[\\w\\s\\W]{3}stories[\\w\\s\\W]{30}",0));
			
			//status from region images
			if(url.contains("Rushland-Plantation-167692")||url.contains("Recess-Pointe-167664")|| url.contains("Stratton-Place-157197")) {
				if(propStatus.length()<3)
					propStatus = "Coming Soon";
				else
					propStatus = propStatus+ ", Coming Soon";
			}
			if(url.contains("details/White-Creek-at-Bethany-152447"))propStatus="Sold Out";
			
			if(url.contains("details/The-Estuary-151857"))propStatus="Grand Opening";
//			if(url.contains("community-details/Hawthorne-148009"))propStatus="Last Chance of Final Phase, "+propStatus.replaceAll(", Final Phase|, Last Chance", "")+", Closeout";
			
			
			if(data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+"------------repeated");
				return;
			}

			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			
			LOGGER.AddCommunityUrl(url);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(name, url, cType);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(proptype, dproptype);
			data.addPropertyStatus(propStatus);
			data.addNotes(U.getnote(mainData));
	}
	
}
