package com.shatam.b_325_353;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import javax.management.monitor.CounterMonitorMBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDavidsonHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver;
	static int j = 0;

	public ExtractDavidsonHomes() throws Exception {

		super("Davidson Homes", "https://davidsonhomesllc.com/");
		LOGGER = new CommunityLogger("Davidson Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractDavidsonHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Davidson Homes.csv", u.data().printAll());

	} 

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam-50/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities();
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		 driver = new ChromeDriver(capabilities);
			Thread.sleep(10000);
		
		String mainHtml = U.getHtml("https://davidsonhomesllc.com/",driver);
		U.log(U.getCache("https://davidsonhomesllc.com/"));

		String regUrls[] = U.getValues(mainHtml, "<a class=\"state-links__link\" href=\"", "\">");
		U.log("Total Regions: "+regUrls.length);
		
		for (String rsec : regUrls) {
			String regUrl = "https://davidsonhomesllc.com" + rsec;
			U.log("regUrl: "+regUrl); 
			
			String regHtml = U.getHtml(regUrl,driver);
			String regSec=U.getSectionValue(regHtml, "class=\"search-results__col search-results__col--results search-results__col--results-active\"", "class=\"search-results__toggle-button search-results__toggle-button--map\"");
			String comSections[] = U.getValues(regSec, "class=\"search-card search-card--animate search-card--community\"",
					"/p></div></div></div></div></div></a>");
			U.log("comSections.length: "+comSections.length);
			
			for (String comSec : comSections) {

				String comUrl = "https://davidsonhomesllc.com" + U.getSectionValue(comSec, "href=\"", "\">");
				//U.log("comUrl: "+comUrl);
//				try {
					addDetails(comUrl, comSec);
//				} catch (Exception e) {}

			}
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comUrl, String comSec) throws Exception {

//		try
		
//============= SINGLE EXECUTION FROM HERE ===========		
//	 if(!comUrl.contains("https://davidsonhomesllc.com/states/georgia/atlanta-market-area/marietta/manor-estates/"))return;
//		if(j>=45)
		{
		U.log("\n::::::::::::"+"COUNT = "+j+":::::::::::::\n");
		
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml = U.getHtml(comUrl, driver);
		comHtml=U.removeSectionValue(comHtml, "<h5 class=\"section__title\">Other communities", "<div class=\"footer");
		U.log(U.getCache(comUrl));
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
	
		// =============remove other community section

	//	String remSec = U.getSectionValue(comHtml, "OTHER COMMUNITIES", "</footer>");
		String remSec = U.getSectionValue(comHtml, "Other communities within 10 miles</h5>", "class=\"footer__button\">About US");
		if (remSec != null) {
			comHtml = comHtml.replace(remSec, "");
		}
        String rmsec[] = U.getValues(comHtml, "<script type=\"text/javascript\">", "</script>");
        for(String s:rmsec) {
        	
        	comHtml = comHtml.replace(s, "");
        }
		U.log(comUrl + "=========" + j);

		// ====================communityName==================

		String comName = U.getSectionValue(comHtml, "<h1 class=\"hero__title alt\">", "</h1>");
		U.log("comName: "+comName);

		// ====================address=======================

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String addressSec = U.getSectionValue(comHtml, "<h2 class=\"hero__state\">", "</h2>");
		U.log("addressSec: "+addressSec);
		String addSecUrls[] = U.getValues(addressSec, "/\">", "</a><span");
		U.log("addSecUrls: "+addSecUrls.length);
		
		for(String sec:addSecUrls) {
			U.log("sec: "+sec);
		}
		
		add[0] = ALLOW_BLANK;
		add[1] = addSecUrls[0];
		add[2] = addSecUrls[1];
		add[3] = ALLOW_BLANK;
		
		//latlag section
		if(comHtml.contains("<a href=\"https://www.google.com/maps/dir")) {
			
			String geoSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
			U.log("geoSec: "+geoSec);
			
			latlag = geoSec.split(",");
			U.log("LATLONG: "+Arrays.toString(latlag));
		}

		if(add[0] == ALLOW_BLANK && latlag[0] == ALLOW_BLANK) {
			
			latlag = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlag);
			geo = "TRUE";
		}
		else if (add[0] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latlag);
			geo = "TRUE";
		}
			

		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log("geo: "+geo);

		// ===================floorplansection===========================================

		String floorPlanUrl = comUrl + "#floorplan";
		U.log(floorPlanUrl);
		String floorplanHtml = U.getHTML(floorPlanUrl);
		String remove = U.getSectionValue(floorplanHtml, "<h5 class='section__title'>OTHER COMMUNITIES ", "</footer>");
		String allPlanData =ALLOW_BLANK;
				
		if(floorplanHtml!=null && remove!=null)floorplanHtml=floorplanHtml.replace(remove, "");
		String plans[] = U.getValues(comHtml, "<div class='properties-card__bottom'", "</a");
		for(String plan:plans) {
			U.log(">>>>"+plan);
			String furl =U.getSectionValue(plan, "<a href=\"", "\"");
			if(furl==null)furl =U.getSectionValue(plan, "<a href=\'", "\'");
			allPlanData += U.getHTML(furl);
		}
		
		String [] myPlans=U.getValues(floorplanHtml, "<a class=\"button button--small\"", "More Details</a>");
		String allHomeData=ALLOW_BLANK;
		
		for(String mPlan:myPlans) {
			String homeUrl=U.getSectionValue(mPlan, "href=\"", "\">");
			//U.log("home Url"+homeUrl);
			allHomeData+=U.getHtml("https://davidsonhomesllc.com/"+homeUrl, driver);
		}
		// ================= avaialable homessection

		String availHomeUrl = comUrl + "#availablehomes";
		U.log(availHomeUrl);
		String availplanHtml = U.getHTML(availHomeUrl);
		 remove = U.getSectionValue(availplanHtml, "<h5 class='section__title'>OTHER COMMUNITIES ", "</footer>");
		if(availplanHtml!=null && remove!=null )availplanHtml=availplanHtml.replace(remove, "");

		// =======================prices========================

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		comHtml = comHtml.replace("&#36;", "$").replace("&#8208;", "-").replace("0s", "0,000");
		prices = U.getPrices(
				(comHtml + floorplanHtml + availplanHtml + comSec + allHomeData).replace("post_excerpt\": \"In Highland Forest, we’re offering gorgeous single-family homes starting in the high $200s", ""),
				"\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}|‐ \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|high \\$\\d+,\\d+", 0);
		U.log("min "+prices[0]+" max "+prices[1]);	
		U.log(Arrays.toString(prices));

		// =================sqft==================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };

		sqft = U.getSqareFeet(comHtml + floorplanHtml + availplanHtml + comSec,
				"\">\\d{1},\\d{3}|>\\d{1},\\d{3} sq.ft<|\\d{1},\\d{3}</strong>", 0);
	


		U.log(Arrays.toString(sqft));

		// ==================communitytype========================
		String cType = ALLOW_BLANK;

		String comDesc = U.getSectionValue(comHtml, "community-content__title-row", "community-content__right-half")
				+ U.getSectionValue(comHtml, "Community Features</button>", "</div>");
		comDesc=comDesc.replace("Lake features", "Lakeside Community");
	//	U.log("KKKKk"+Util.matchAll(comDesc + comSec, "[\\w\\s\\W]{60}gated[\\w\\s\\W]{90}", 0));
	//	U.log("Descri:: "+comDesc);
		cType = U.getCommType((comDesc + comSec).replaceAll("the Darden to Hasentree Golf Community", ""));

		if(comUrl.contains("https://davidsonhomesllc.com/states/alabama/huntsville-market-area/madison/laurenwood-preserve/"))
			cType="Lakeside Community";
			
			U.log("cType::::::" + cType);

		// ===================propertyType================================
		String pType = ALLOW_BLANK;
		
		pType = U.getPropType((comDesc + comSec+allPlanData+allHomeData));

		U.log("pType::::::" + pType);

		// ============================dproptype=================================
		String dType = ALLOW_BLANK;
		
		String comFeaturs = U.getSectionValue(comHtml, "", "");
//		U.log("SSS"+Util.matchAll(comDesc + comFeaturs + comSec+allPlanData+allHomeData,"[\\w\\W\\s]{100}10 foot ceilings on the second floor,[\\w\\W\\s]{50}",0));
		dType = U.getdCommType((comDesc + comFeaturs + comSec+allPlanData+allHomeData).replace("10 foot ceilings on the second floor", "10 foot ceilings on the second floor owner").replace("Features a media room on third level", ""));
		U.log("dType::::::" + dType);

		// =======================propertyStatus===================================

		String pStatus = ALLOW_BLANK;
//		comDesc = comDesc//.replace("quickly selling out our first phase", "quickly selling out first phase")
//				.replace("quickly selling out our first phase", "first phase selling out");
		
//		U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(comDesc + comSec, "[\\w\\s\\W]{60}Coming Soon[\\w\\s\\W]{90}", 0));
//		U.log(comDesc);
		comDesc = comDesc.replace("New floor plans coming soon", "New plans coming soon")
				.replace("waterside homesite are available", "waterside homesite available").replace("Phase 2 is Now Open","Phase 2 Now Open");
		pStatus = U.getPropStatus((comDesc + comSec).replaceAll("Acre Homesites Available|With additional quick move-in homes|After quickly selling out our first phase, we plan to build|Willow plans have limited availability|community__status--close-out'>|now selling our model home|And with quick move-in homes on t", ""));
		U.log(Util.matchAll(comDesc + comSec, "[\\w\\s\\W]{30}New Phase Coming Soon[\\w\\s\\W]{30}", 0));
		if(comUrl.contains("https://davidsonhomesllc.com/states/tennessee/nashville-market-area/murfreesboro/shelton-square/"))
			pStatus="Coming Soon";//frfm image
//		U.log(comSec);
		
		U.log("status:::::::" + pStatus);

		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;

		String note = U.getnote(comHtml.replaceAll("XXXX MOCK LOT FOR SALES|schema.org/PreSale", ""));
		
		
		if (comUrl.contains(
				"https://davidsonhomesllc.com/states/north-carolina/raleigh-market-area/wake-forest/hasentree/")) {

			add[2] = "NC";
			add[3] = "27587";
		}
//		if (comUrl.contains("https://davidsonhomesllc.com/states/georgia/atlanta-market-area/cumming/cooper-place/"))
//			pStatus = "Phase 1 Sold Out, Phase 2 Coming Soon";// img

	
		if(comUrl.contains("nashville-market-area/murfreesboro/rivers-edge/"))pStatus="New Phase Now Selling";
//		if(comUrl.contains("https://davidsonhomesllc.com/states/tennessee/nashville-market-area/murfreesboro/salem-landing/"))pStatus+=", New Floor Plans Coming Soon";
		if (comUrl.contains(
				"https://davidsonhomesllc.com/states/alabama/huntsville-market-area/new-market/flint-meadows/"))
			note = ALLOW_BLANK;
		
		//from image
//		if(comUrl.contains("https://davidsonhomesllc.com/states/alabama/huntsville-market-area/huntsville/jaguar-hills/")) pStatus ="New Phase Now Selling";
		if(pStatus!=null)
			pStatus = pStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		
		data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		} 
		j++;
		
//		catch (Exception e) {}
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("class=\"interactiveLot")) {
			
			ArrayList<String> pins = Util.matchAll(html, "class=\"interactiveLot", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());
			
		}
		
		return totalUnits;
	}
		
			
	
	
	

}
