package com.shatam.b_325_353;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashSet;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.regexp.recompile;
/**
 * @author MJS
 * @date 01/04/2021 
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDeNovaHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.denovahomes.com";

	public ExtractDeNovaHomes() throws Exception {
		super("DeNova Homes", builderUrl);
		LOGGER = new CommunityLogger("DeNova Homes");
	}
	
	static MultiValueMap regionPageData = new MultiValueMap();
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractDeNovaHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "DeNova Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String html = U.getHTML("https://www.denovahomes.com");
		String sec = U.getSectionValue(html, "Find Your Home</a>", "<h5><strong>Find Your Dream Home</strong></h5>");
		sec = sec.replace("<a class=\"dropdown-item heading-item\"", "<a class=\"dropdown-ite heading-item\"");
		//U.log("sec: "+sec);
		String[] mainSec = U.getValues(sec, "<a class=\"dropdown-item", "</a>");
		U.log("mainSec: "+mainSec.length);
		
		//for storing region page dat of comm.
		String[] regionSec = {"/north-bay-area/", "/south-bay-area/", "/east-bay-area/"};  
		String[] regionComm = null;
		String regionHtml = null;
		
		for(String region : regionSec) {
			
			String regionUrl = "https://www.denovahomes.com" + region;
			U.log("regionUrl: "+regionUrl);
			regionHtml = U.getHTML(regionUrl);
			String[] regData = U.getValues(regionHtml, "<span class=\"card-title location-name d-block", "<div class=\"oi-infowindow-content\""); 
			U.log("regData: "+regData.length);
			
			for(String reg:regData) {
			//	U.log("reg: "+reg);
				String comNameFromReg = U.getSectionValue(reg, "uppercase m-0 bold\">", "</span>"); 
				U.log("comNameFromReg: "+comNameFromReg);
				regionPageData.put(comNameFromReg, reg);
			}
			U.log("regionPageData: "+regionPageData.size());			
		}

		for(String main : mainSec) {
			
			String comUrl = "https://www.denovahomes.com" + U.getSectionValue(main, "href=\"", "\"");
			if(comUrl.contains("/diablo-meadows/") || comUrl.contains("/secluded-woods/")) {
				comUrl = U.getSectionValue(main, "href=\"", "\"");
			}
			
			U.log("comUrl: "+comUrl);
//			try {
					addDetail(comUrl, main, html);
//			} catch (Exception e) {}
//			if(comUrl.equals("/new-homes/ca/northern/"))continue;
//			
//			//if(comUrl.contains("/new-homes"))
//			//	getDetail(builderUrl+comUrl, main);
//			//else
//			//	addDetail(comUrl, main);
//			
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetail(String comUrl, String com, String builderHtml) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.denovahomes.com/new-homes/ca/antioch/luca-at-aviano/7623/"))return;
//		if(!comUrl.contains("https://www.denovahomes.com/new-homes/ca/petaluma/makenna/9971/")) return;
		{
//			U.log(">>>>>>>>>>>");
//			if(!comUrl.contains("https://www.denovahomes.com/new-homes/ca/brentwood/bennett-estates/9430/"))return;
//			FileUtil.writeAllText("/home/shatam-10/Desktop/data/buiders.txt", builderHtml);
			
			U.log("Count: " + j + "\t" + comUrl);
				
				{
					
					if (data.communityUrlExists(comUrl)) {
						LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
						return;
					}
					if (comUrl.contains("/ca/sonoma/mockingbird-lane/4044/")|| comUrl.contains("the-knolls-at-allendale/2970/") || comUrl.contains("/the-meadows-at-allendale/2971/")) {
						LOGGER.AddCommunityUrl("Past communities======== " + comUrl);
						return;
					}
					LOGGER.AddCommunityUrl(comUrl);
					
					String html = U.getHtml(comUrl, driver);
					String comHtml = html;
					html=U.removeSectionValue(html, "<b>Hours:</b>", "<a");
					// ============================================Community
					// name=======================================================================
					
					String communityName = U.getSectionValue(com, "\">","<span>");
					communityName = U.getCapitalise(communityName.replace("Bennett Estate", "Bennett Estates").toLowerCase().trim());
					communityName = communityName.replace("&#8217;", "'").replaceAll("The Master Planned Community", "")
							.replace("Bennett Estatess", "Bennett Estates").replace("Traditions At The Meadow", "Traditions at the Meadow");
					U.log("community Name---->" + communityName);

					// ================================================Address
					// section===================================================================

					String note = ALLOW_BLANK;
					String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
					String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
					String geo = "FALSE";
					
					if(comUrl.contains("/secluded-woods/") || comUrl.contains("/diablo-meadows/")) {
						//String addSec = U.getSectionValue(html, communityName.trim()+"</span></span></span></p>", "<br>");
						String addSec = U.getSectionValue(html, "playfair display\">LOCATION</font>", ">T:");
						U.log("addSec: " + addSec);
						
						if(addSec!=null) {
							//addSec = U.getNoHtml("Start"+addSec.replace("</span></span></span></span></span></p>", ",").trim()+"End");
							String[] values = U.getValues(html, "<span style=\"color:#ffffff;\">", "</span></span></span>");
							//U.log("addSec---: " + addSec);
							for(String value:values) {
								//U.log("value: " +value);
							}
							
							String addsecs = values[1] +", " + values[2]; 
							U.log("addsecs: " +addsecs);
							
							add = U.getAddress(addsecs);
						}
						U.log("Address From here---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

					}
					else {
						String addSecMain = U.getSectionValue(html, "<b>Address:</b>", "</b>");
						addSecMain = addSecMain.replace("Directions\">", "Directions\">begin here");
						
						String addSec = U.getSectionValue(addSecMain, "begin", "Hours");
						U.log("addSecMain: "+addSecMain);
						U.log("addSec: "+addSec);
						if(addSec!=null) {
							add[0] = U.getSectionValue(addSec, "here", "</a>");
							
							String section = U.getSectionValue(addSec, "<br />", "<br /><b>"); 
							U.log("section: "+section);
							String[] temp = section.split(",");
							
							add[1] = temp[0];
							add[2] = Util.match(temp[1], "\\w+");
							add[3] = Util.match(temp[1], "\\d{5}");
						}
						U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
						
						//latLng section
							latLng[0] = Util.match(addSecMain, "\\d+\\.\\d+");
							latLng[1] = Util.match(addSecMain, "-\\d+\\.\\d+");
							U.log("Lat Lng -->" + latLng[0] + "  " + latLng[1]);
						
					}
					
					// --------------------------------------------------latlng----------------------------------------------------------------
						String latSec = U.getSectionValue(html, "<iframe src=\"https://www.google.com/maps", "</iframe>");
						if(latSec!=null) {
						latLng[0] = Util.match(latSec, "!3d\\d+\\.\\d+").replace("!3d", "");
						latLng[1] = Util.match(latSec, "-\\d+\\.\\d+");
						}
						
						
					if (latLng[0] == null || latLng[1] == null)
						latLng[0] = latLng[1] = ALLOW_BLANK;
					U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

					if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
						latLng = U.getlatlongGoogleApi(add);

						geo = "TRUE";
					}

					
					if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
						String add1[] = U.getAddressGoogleApi(latLng);
						if (add1 == null)
							add1 = U.getAddressHereApi(latLng);
						if (add[0] == null || add[0].length() < 2)
							add = add1;
						if (add[3] == null)
							add = add1;
						geo = "TRUE";
					}

					U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);
					
					//============================================= RESIDENCES DATA ========================================
					String residenceData = ALLOW_BLANK;
					String homeInfo = ALLOW_BLANK;
					HashSet<String> homeLinks = new HashSet<String>();
					
					if(html.contains("<a class=\"card-img-top\" href=\"")) {
						String[] residence = U.getValues(html, "<a class=\"card-img-top\" href=\"", "\" tabindex=");
						U.log("residence length: "+residence.length);
						
						for(String resi:residence) {
							//U.log("resi: "+resi);
							homeLinks.add(resi);
						}
						
						U.log("homeLinks Size: "+homeLinks.size());
					}
					
					if(homeLinks != null) {
						
						for(String home:homeLinks) {
							
							String homeUrl = "https://www.denovahomes.com" + home;
							U.log("homeUrl: "+homeUrl);
							
							String homeHtml = U.getHtml(homeUrl, driver);
							if(homeHtml.contains("Plan Details") && homeHtml.contains("Get Financing Info")) {
								
								U.log("IN HERE");
								homeInfo = U.getSectionValue(homeHtml, "Plan Details", "Get Financing Info");
								//U.log("homeInfo: "+homeInfo);
							}
							
							residenceData += homeInfo;
						}
					}
					
					//================================Data of each community from region page - [Use if needed. Never used below.]
					String regdata = ALLOW_BLANK;
					ArrayList<String> regionPage = (ArrayList<String>) regionPageData.get(communityName);
					if(regionPage != null) {
						for(String regpage:regionPage) {
							
							U.log("regpage: "+regpage);
							
							regdata += regpage;
						}
					}
					
					// ============================================Price and
					// SQ.FT======================================================================

					String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
					String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

					html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
							.replace("</strong>   &#36;", " $")
							.replace("the low $1 Millions", "the low $1,000,000");
					com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
					
					html = html.replace("mid $1 Million", "mid $1,000,000").replace("0s", "0,000").replace("0's", "0,000")
							.replace("from the Low $700&amp;#39;s", "from the Low $700,000")
							.replace("from the Low $1 Millions", "from the Low $1,000,000");
					
					String prices[] = U.getPrices(com + html, "from the Low \\$\\d{3},\\d{3}|the low \\$\\d,\\d{3},\\d{3}|mid \\$\\d,\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|<span class=\"price bold d-block lead text-highlight\">\\$\\d{3}\\d{3}</span>|<span class=\"price bold d-block lead text-highlight\">\\$\\d,\\d{3},\\d{3}</span>|<h2 class=\"bold text-highlight\">\\$\\d{3},\\d{3}</h2>|<h2 class=\"bold text-highlight\">\\$\\d,\\d{3},\\d{3}</h2>|from the \\$\\d{3},\\d{3}", 0);

					minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
					maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

					U.log("Price--->" + minPrice + " " + maxPrice);
					
//					U.log(">>>>>>>>>>>>"+Util.matchAll(html , "[\\s\\w\\W]{100}700[\\s\\w\\W]{30}", 0));
//					U.log(">>>>>>>>>>>>"+Util.matchAll(com, "[\\s\\w\\W]{100}the low \\$1 Millions[\\s\\w\\W]{30}", 0));

					// ======================================================Sq.ft===========================================================================================
				
					String[] sqft = U.getSqareFeet(com + html,
							"from \\d+ to \\d,\\d{3} sq\\. ft|plans offer \\d,\\d{3} to \\d,\\d{3} square feet|ranging from \\d+-\\d,\\d{3} sq\\. ft|approximately \\d,\\d{3} to \\d,\\d{3} square feet|<span class=\"sq-ft d-block\">\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft\\.</span>|<span class=\"sq-ft d-block\">\\d,\\d{3} Sq\\. Ft\\.</span>|from \\d,\\d{3} to \\d,\\d{3} square feet|home with \\d,\\d{3} Sq\\. Ft|- \\d+ Sq\\. Ft",
							0);
					minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
					maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
					U.log("SQ.FT--->" + minSqft + " " + maxSqft);

					// ================================================community
					// type========================================================
					String comDesc=U.getSectionValue(html, "col-md-8 location-desc pt-4 pt-md-0", "</article");
					html = html.replace("newest  55 + Active Adult gated", "newest  55+ community Active Adult gated");
					
					String communityType = U.getCommType((html + com)
							.replaceAll("from your lakefront home at One56|Elongated|The Master Planned Community Delaney Park|-master-plan|Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));
					U.log("communityType ---->" + communityType);
					//U.log(">>>>>>>>>>>>"+Util.matchAll(html + com, "[\\s\\w\\W]{30}55+[\\s\\w\\W]{30}", 0));
					// ==========================================================Property
					// Type================================================

					String sec1="";
					
					sec1=U.getSectionValue(com, "<p class=\"m-0\">", "</p");
					
					
//					U.writeMyText(html.replaceAll("\".*\"", ""));
					String proptype = U.getPropType((html+comDesc+sec1+regdata).replaceAll("Single Family Homes|Cottage Elevation", "")); //.replaceAll("\".*\"", "")
		              U.log("proptype===="+proptype);
		             // U.log(Util.matchAll(html+comDesc+sec1, "[\\s\\w\\W]{30}single[\\s\\w\\W]{30}", 0));
		// ==================================================D-Property
					// Type======================================================
					String dtype = U.getdCommType((html + com).replaceAll("-ranch/|Leaf Ranch|Brody Ranch|Emerson Ranch|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
							+ communityName + residenceData);
					U.log("dtype===="+dtype);
//					U.log(Util.matchAll(residenceData, "[\\s\\w\\W]{30}two-story[\\s\\w\\W]{30}", 0));
//					U.log(Util.matchAll(html+comDesc+sec1, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));
					
					// ==============================================Property
					// Status=========================================================
					String featuredProperties = ALLOW_BLANK; 
					String features = ALLOW_BLANK;
					
					if(builderHtml.contains("Featured Properties") && builderHtml.contains("Building a Better Community")) {
						
						featuredProperties = U.getSectionValue(builderHtml, "Featured Properties", "Building a Better Community");
						U.log("featuredProperties: "+featuredProperties);
						
						if(featuredProperties.contains("<div class=\"col-md-6 col-lg-5 featured-details px-4 pt-4\">") && featuredProperties.contains("role=\"button\">Details")) {
							
							String[] values = U.getValues(featuredProperties, "<div class=\"col-md-6 col-lg-5 featured-details px-4 pt-4\">", "role=\"button\">Details");
							for(String value:values) {
								
								U.log("value: "+value);
								
								communityName = communityName.replace("Luminescence At Liberty", "Luminescence at Liberty");
								U.log("communityName: "+communityName);
								if(value.contains(communityName)) {
									
									features += value;
								}
							}
						}
					}
					
					
					html = html.replaceAll("We are currently selling our homes from|Landing are Sold Out|<div class=\"text\">TEMPORARILY SOLD OUT</div>|<div class=\"text\">NOW SELLING</div>|Landing are sold out|coming early 2019|Neighborhoods<br> Now Selling|coming soon communities|Coming Soon</h5><ul class=\"footer|Quick Delivery|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
							.replace("One Home is AVAILABLE to purchase", "One Home AVAILABLE to purchase")
//							.replace("Grand Open Spring/Summer 2022", "Grand Opening Spring/Summer 2022")
							.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
					com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
							.replaceAll("Landing are Sold Out|coming early 2019|Neighborhoods<br> Now Selling|coming soon communities|Quick Delivery|Coming soon, neuhouse", "");
					
					String pstatus = U.getPropStatus((html + com + features + regdata).replaceAll("We are currently selling our homes|banner\">MOVE-IN READY|Hours:</b> Coming Fall 2022|uppercase\">Coming Soon</h5>", ""));
					
					if(comHtml.contains("<div class=\"banner\">Move-In Ready</div>")) {
						
						if(pstatus == ALLOW_BLANK)
							pstatus = "Move-In Ready";
						else if(pstatus != ALLOW_BLANK)
							pstatus = pstatus + ", Move-In Ready";	
					}
					
					U.log("pstatus: "+pstatus);
					//U.log("com: "+com);
					
					//U.log(">>>>>>>>>>>>>>>>>>"+Util.matchAll(features, "[\\s\\w\\W]{30}grand opening[\\s\\w\\W]{30}", 0));
					
					if(pstatus.contains("New Homes Coming Soon, Coming Soon")) pstatus = pstatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon");
					
					// ============================================note====================================================================


					U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
					
					//========== Hard Code Data ==================================
					
		/*			if(homeSec!=null && homeSec.length>0 && avail>0)
						if(pstatus==ALLOW_BLANK)
							pstatus = "Available Homes";
						else if(!pstatus.contains("Available Homes"))
							pstatus += ", Available Homes";
		*/			
					pstatus = pstatus.replace("Spring/summer", "Spring/Summer").replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
					if(add[0]!=null)
						add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
					
					
					//=========================================================================================================================
//					File f=new File("/home/shatam-50/Documents/Bugs");
//					FileWriter w = new FileWriter(f);
					String lotcount=ALLOW_BLANK;
					String mapLink=U.getSectionValue(html, "<iframe allowfullscreen=\"\" class=\"embed-responsive-item\" loading=\"lazy\" scrolling=\"yes\" src=\"", "\">");
					U.log("mapLink=="+mapLink);
					if(mapLink!=null) {
						String mapHtml=U.getHtml(mapLink,driver);
						String lotSec=U.getSectionValue(mapHtml, "<div id=\"FocusSitemapLayers\"", "id=\"footprints\"");
						String[] lotdata=U.getValues(lotSec, "<g id=\"lot", ">");
						for(String s : lotdata) {
					
						//w.write("\n"+s+"\n");
						}
						if(lotdata.length>0) {
							lotcount=Integer.toString(lotdata.length);

						}
					}
					
					U.log("lotcount=="+lotcount);
					

					data.addCommunity(communityName.replace(",", ""), comUrl, communityType);
					data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note);
					data.addUnitCount(lotcount);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				}
				j++;
		}
		
	}

//	private void getDetail(String comUrl, String com) throws Exception {
//		// TODO Auto-generated method stub
//		
////		if(!comUrl.contains("https://www.denovahomes.com/new-homes/ca/rio-vista/luminescence-at-liberty/7423/"))return;
////		if(!comUrl.contains("https://www.denovahomes.com/new-homes/ca/fairfield/one56-at-one-lake/9692/"))return;
//		{
//		U.log("Count: " + j + "\t" + comUrl);
//		{
//			
//			if (data.communityUrlExists(comUrl)) {
//				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
//				return;
//			}
//			if (comUrl.contains("/ca/sonoma/mockingbird-lane/4044/")|| comUrl.contains("the-knolls-at-allendale/2970/") || comUrl.contains("/the-meadows-at-allendale/2971/")) {
//				LOGGER.AddCommunityUrl("Past communities======== " + comUrl);
//				return;
//			}
//			LOGGER.AddCommunityUrl(comUrl);
//			
//			String html = U.getHtml(comUrl, driver);
//			// ============================================Community
//			// name=======================================================================
//			
//			String communityName = U.getSectionValue(com, "<span class=\"card-title location-name d-block text-uppercase m-0 bold\">","<");
//			if(communityName==null) {
//				communityName = U.getSectionValue(html, "<h1 class=\"mt-0 line-height-1 display-4\">","<");
//			}
//			else if(communityName==null) {
//			communityName = U.getSectionValue(html, "<title>","</title>");
//			}
//			if(communityName!=null) {
//			communityName = U.getCapitalise(communityName.toLowerCase().trim());
//			communityName = communityName.replace("&#8217;", "'").replaceAll("The Master Planned Community", "").replace(",", "");
//			}
//			
//			U.log("community Name---->" + communityName);
//
//			// ================================================Address
//			// section===================================================================
//
//			String note = ALLOW_BLANK;
//			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
//			String geo = "FALSE";
//
//			String addSec = U.getSectionValue(html, "<b>Address:</b>", "Hours:</b>");
//			if(addSec!=null) {
//				
//				String addVal = U.getSectionValue(addSec, "Directions\">", "<b>");
//				if(addVal!=null)
//					addVal = addVal.replaceAll("<br>", ",").replaceAll("</a>", "");
//				U.log(addVal);
//				add = U.getAddress(addVal);
//			}
//			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
//
//			// --------------------------------------------------latlng----------------------------------------------------------------
//			if(addSec!=null) {
//				
//				String latSec = U.getSectionValue(addSec, "href=\"//maps.google.com/maps?q=", "\"");
//				latLng = latSec.split(",");
//			}
//			if (latLng[0] == null || latLng[1] == null) {
//				
//				latLng[0] = U.getSectionValue(com, "data-latitude=\"", "\"");
//				latLng[1] = U.getSectionValue(com, "data-longitude=\"", "\"");
//				
//			}
//				
//			if (latLng[0] == null || latLng[1] == null)
//				latLng[0] = latLng[1] = ALLOW_BLANK;
//			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);
//
//			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
//				latLng = U.getlatlongGoogleApi(add);
//
//				geo = "TRUE";
//			}
//
//			
//			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
//				String add1[] = U.getAddressGoogleApi(latLng);
//				if (add1 == null)
//					add1 = U.getAddressHereApi(latLng);
//				if (add[0] == null || add[0].length() < 2)
//					add = add1;
//				if (add[3] == null)
//					add = add1;
//				geo = "TRUE";
//			}
//
//			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);
//
//			//====== Floor Plans ================================
//			String floorPart = U.getSectionValue(html, "<section class=\"plan-list py-3 py-md-5\" id=\"location-plans\">", "</section>");
//			if(floorPart==null)
//				floorPart = "";
//			String[] floorSec = U.getValues(floorPart, "<div class=\"col-12 col-sm-6 col-md-4 col-xl-3 mb-3 px-2\"", "</a></div></div></div>");
//			String floorData = ALLOW_BLANK;
//			int i = 0;
//			for(String floor : floorSec) {
//				
//				floor = U.getSectionValue(floor, "\" href=\"", "\"");
//				floorData += U.getSectionValue(U.getHtml(builderUrl+floor, driver), "<section class=\"plan-details py-lg white-bg\">", "</section>");
//				if(i>5)
//					break;
//				else
//					i++;
//					
//			}
//			//====== Available Homes ================================
////			String homePart = U.getSectionValue(html, "<section class=\"spec-list py-3 py-md-5\" id=\"location-specs\">", "</section>");
//			String homePart = U.getSectionValue(html, "", "</section>");
//
//			if(homePart==null)
//				homePart = "";
//			int avail = 0;
//			String[] homeSec = U.getValues(homePart, "<div class=\"col mb-3 px-2 slide\"", "Details</a>");
//			String homeData = ALLOW_BLANK;
//			int k = 0;
//			for(String home : homeSec) {
//				if(!home.contains("Under Construction</h5>"))
//					avail++;
//				home = U.getSectionValue(home, "\" href=\"", "\"");
//				U.log(">>>>>>>"+home);
//				homeData += U.getSectionValue(U.getHtml(builderUrl+home, driver), "<section class=\"plan-details py-lg white-bg mb-3\">", "</section>");
//				
//				if(k>5)
//					break;
//				else
//					k++;
//			}
////			homeData
//			
//
//			// ============================================Price and
//			// SQ.FT======================================================================
//
//			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
//			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//
//			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
//					.replace("0's", "0,000").replace("</strong>   &#36;", " $");
//			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
//			
//			html = html.replace("0s", "0,000").replace("from the $900's", "$900,000");
//			String prices[] = U.getPrices(com + html + floorData + homeData, "From \\$\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|<span class=\"price bold d-block lead text-highlight\">\\$\\d{3}\\d{3}</span>|<span class=\"price bold d-block lead text-highlight\">\\$\\d,\\d{3},\\d{3}</span>|<h2 class=\"bold text-highlight\">\\$\\d{3},\\d{3}</h2>|<h2 class=\"bold text-highlight\">\\$\\d,\\d{3},\\d{3}</h2>|from the \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}", 0);
//
//			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
//			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
//
//			U.log("Price--->" + minPrice + " " + maxPrice);
//
//			// ======================================================Sq.ft===========================================================================================
//		
//			String[] sqft = U.getSqareFeet(com + html + floorData + homeData,
//					"from \\d+ to \\d,\\d{3} sq\\. ft|plans offer \\d,\\d{3} to \\d,\\d{3} square feet|ranging from \\d+-\\d,\\d{3} sq\\. ft|approximately \\d,\\d{3} to \\d,\\d{3} square feet|<span class=\"sq-ft d-block\">\\d,\\d{3} - \\d,\\d{3} Sq\\. Ft\\.</span>|<span class=\"sq-ft d-block\">\\d,\\d{3} Sq\\. Ft\\.</span>|from \\d,\\d{3} to \\d,\\d{3} square feet|home with \\d,\\d{3} Sq\\. Ft|- \\d+ Sq\\. Ft",
//					0);
//			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
//			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			U.log("SQ.FT1--->" + minSqft + " " + maxSqft);
//
//			// ================================================community
//			// type========================================================
//			String comDesc=U.getSectionValue(html, "col-md-8 location-desc pt-4 pt-md-0", "</article");
//					
//			
//					
//			String communityType = U.getCommType((html + com).replace("newest 55 +", "newest 55+").replaceAll("Elongated|-master-plan|The Master Planned Community Delaney Park|Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));
//
//			// ==========================================================Property
//			// Type================================================
//
//			String sec1="";
//			
//			sec1=U.getSectionValue(com, "<p class=\"m-0\">", "</p");
//			U.log(sec1);
//			
////			U.writeMyText(html.replaceAll("\".*\"", ""));
//			html=html.replaceAll("quot;end_time&quot;:20231,&quot;text&quot;:&quot;The living room with windows and patio door|Outdoor patio with chairs", "");
//			homeData=homeData.replace("Included Courtyard Patio", "");
//			
//			String proptype = U.getPropType((html+ floorData + homeData+comDesc+sec1).replaceAll("Craftsman elevations|Craftsman exterior elevation|Cottage Elevation", "")); //.replaceAll("\".*\"", "")
//            
////			U.log("kkkkkkkkkk "+Util.matchAll(homeData , "[\\s\\w\\W]{100}second floor[\\s\\w\\W]{100}", 0));
////			U.log("kkkkkkkkkk "+Util.matchAll(comDesc+sec1, "[\\s\\w\\W]{100}second floor[\\s\\w\\W]{100}", 0));
//
//			
//			U.log(" proptype ::::: "+proptype);
//// ==================================================D-Property
//			// Type======================================================
////			homeData=homeData.replace("second floor", "2 Story");
//			String dtype = U.getdCommType((html + com + floorData + homeData).replaceAll("-ranch/|Leaf Ranch|Brody Ranch|Emerson Ranch|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
//					+ communityName);
//			U.log(" dtype ::::: "+dtype);
////			U.log(Util.matchAll(html + com, "[\\s\\w\\W]{30}three-level[\\s\\w\\W]{30}", 0));
////			U.log(Util.matchAll(floorData + homeData, "[\\s\\w\\W]{30}three-level[\\s\\w\\W]{30}", 0));
//			// ==============================================Property
//			// Status=========================================================
//	
//			html = html.replaceAll("banner\">MOVE-IN READY|Landing are Sold Out|<div class=\"text\">TEMPORARILY SOLD OUT</div>|<div class=\"text\">NOW SELLING</div>|Landing are sold out|coming early 2019|Neighborhoods<br> Now Selling|coming soon communities|Coming Soon</h5><ul class=\"footer|Quick Delivery|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
////					.replace("Grand Open Summer 2022", "Grand Opening Summer 2022")
//					.replace("Grand Open Spring/Summer 2022", "Grand Opening Spring/Summer 2022").replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
//			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
//					.replaceAll("banner\">MOVE-IN READY|Landing are Sold Out|coming early 2019|Neighborhoods<br> Now Selling|coming soon communities|Quick Delivery|Coming soon, neuhouse", "");
//			
//			String pstatus = U.getPropStatus(html + com).replace("class=\"banner\">MOVE-IN READY", "");
//			pstatus = pstatus.replace("Grand Opening Spring/summer 2022", "Grand Open Spring/summer 2022");
//			U.log(" pstatus ::::: "+pstatus);
//			//U.log(Util.matchAll(html + com, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));
//
//			// ============================================note====================================================================
//
//
//			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
//			
//			//========== Hard Code Data ==================================
//			
///*			if(homeSec!=null && homeSec.length>0 && avail>0)
//				if(pstatus==ALLOW_BLANK)
//					pstatus = "Available Homes";
//				else if(!pstatus.contains("Available Homes"))
//					pstatus += ", Available Homes";
//*/			
//			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
//			if(add[0]!=null)
//				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
//			
//			if(comUrl.contains("https://www.denovahomes.com/new-homes/ca/oakley/the-master-planned-community-delaney-park/2974/")) {
//				communityName = "Delaney Park";
//				communityType = "Master Planned";
//			}
////			if(comUrl.contains("https://www.denovahomes.com/new-homes/ca/san-jose/asana/2972/"))dtype=dtype+", 2 Story";
//			if(comUrl.contains("the-landing-at-wildflower-station/4881/")) {
//				dtype=dtype.replace(", 2 Story", "");
//				proptype=ALLOW_BLANK;
//			}
//
//			//=========================================================================================================================
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			
//			data.addCommunity(communityName, comUrl, communityType);
//			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
//			data.addPrice(minPrice, maxPrice);
//			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
//			data.addSquareFeet(minSqft, maxSqft);
//			data.addPropertyType(proptype, dtype);
//			data.addPropertyStatus(pstatus);
//			data.addNotes(U.getnote(html));
//
//		}
//		j++;
//		}
//		
//	}
	}