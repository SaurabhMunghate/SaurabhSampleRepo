package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.io.FilenameUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFlagshipHomesSau extends AbstractScrapper {
	CommunityLogger LOGGER;

	public ExtractFlagshipHomesSau() throws Exception {
		super("Flagship Homes", "https://www.forsail.com/");
		LOGGER = new CommunityLogger("44Flagship Homes Data");
	}

	public static void main(String[] args) throws Exception {
		System.out.println("Start======Start=======Start======Start=======Start======Start======Start");
		AbstractScrapper saurabh = new ExtractFlagshipHomesSau();
		saurabh.process();
		FileUtil.writeAllText(U.getCachePath() + "44Florsheim Homes Data.csv", saurabh.data().printAll());
		System.out.println("End======End========End========End=========End======End=======End");
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub

		String commSec[] = U.getValues(U.getHTML("https://www.forsail.com/"), "<div class=\"community-info\">",
				"button\">details</a>");
		for (String comSec : commSec) {
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
			comUrl = "https://www.forsail.com" + comUrl;
			String commName = U.getSectionValue(comSec, "community-title\">", "<");
			U.log("--------------------------------------------------------------------------------------");
			U.log(comUrl + " name: " + commName);
			// addDetails(comUrl,commName);
			addDetailss(comUrl, commName,comSec);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetailss(String comUrl, String commName,String comSec) throws Exception {

		String comHtml = U.getHTML(comUrl);//

		LOGGER.AddCommunityUrl(comUrl);

		String commType  = U.getCommType(comHtml + comSec);
		U.log("commType -- " + commType);

		String g = "FALSE";
		String[] address = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latL = { ALLOW_BLANK, ALLOW_BLANK };
		String minP = ALLOW_BLANK, maxP = ALLOW_BLANK;

		String seclatlong = U.getSectionValue(comHtml, "coordinates: [", "]");

		if (seclatlong != null) {
			String cor[] = seclatlong.split(",");
			if (cor.length == 2) {
				if (cor[0].trim().startsWith("-")) {
					latL[0] = cor[1].trim();
					latL[1] = cor[0].trim();
				} else if (cor[1].trim().startsWith("-")) {
					latL[0] = cor[0].trim();
					latL[1] = cor[1].trim();
				}
			}
		} else {
			latL = U.getGoogleLatLngWithKey(address);
			g = "T";
		}
		if (latL[0] == ALLOW_BLANK || latL[0] == null || latL[0].isEmpty() || latL[0] == "-") {
			latL = U.getGoogleLatLngWithKey(address);
			g = "true";
		}

		String hh = U.getHTML("https://www.forsail.com/homes-for-sale");
		// String homeData1=U.getSectionValue(homeHtml, ">Move-In Ready</h1>", ">About
		// Us</a>");
		String[] homeforsaleData = U.getValues(hh, "class=\"collection-item", "For Sale</div>");
		String homeforSaleHtml = "";
		for (String home : homeforsaleData) {
			String homeUrl = U.getSectionValue(home, "<a href=\"", "\"");
			homeUrl = "https://www.forsail.com" + homeUrl;
			U.log("homeUrl:--" + homeUrl);
			homeforSaleHtml += U.getHTML(homeUrl);
		}
		// Available Home Data-
		String homeD = "";
		String homeSec = U.getSectionValue(comHtml, "Subdivisions in this Community</h3>",
				">Details</a></div></div></div></div></div></div></div>");
		if (homeSec != null) {
			String[] homeUrls = U.getValues(homeSec, "<a href=\"", "\"");
			int c = 0;
			for (String homeUrl : homeUrls) {
				c++;
				homeUrl = "https://www.forsail.com" + homeUrl;
				homeD += U.getHTML(homeUrl);
			}
		}
		String pri[] = U.getPrices(comHtml + homeD,
				">\\$\\d{3},\\d{3}<|\">\\$\\d{3},\\d{3}</h3>|Starting at \\$\\d{3},\\d{3}", 0);

		if (comUrl.contains("https://www.forsail.com/communities/silver-lake")) {
			pri = U.getPrices(comHtml + homeD + homeforSaleHtml,
					">\\$\\d{3},\\d{3}<|\">\\$\\d{3},\\d{3}</h3>|Starting at \\$\\d{3},\\d{3}", 0);
		}
		minP = (pri[0] == null) ? ALLOW_BLANK : pri[0];
		maxP = (pri[1] == null) ? ALLOW_BLANK : pri[1];
		U.log("min price " + minP + "  max price " + maxP);

		String note = ALLOW_BLANK;
		note = U.getnote(comHtml);
		U.log("note--" + note);

		comHtml = comHtml.replace(" Eagle Mountain", ", Eagle Mountain");

		String aa = U.getSectionValue(comHtml, "</h1></div><div class=\"community-address\">",
				"</div></div><div style");

		U.log(" " + aa);
		aa = aa.replace("Drive American", "Drive,American").replace("WEST MAPLETON", "WEST, MAPLETON");
		address = U.getAddress(aa);
		U.log("Address " + Arrays.toString(address));

		// Floor Plan Data
		String floorPHtm = U.getHTML("https://www.forsail.com/floor-plans");
		String planD = "";
		String[] planUrls = U.getValues(floorPHtm, "<a id=\"w-node-_", "</a>");
		for (String plan : planUrls) {
			if (plan.contains(commName)) {
				planD += plan.replace("feet.png\" width=\"20\" alt=\"\"/></div><div class=\"columntext\">", "Sq. Ft. ");
			}
		}
		// Community Sqft
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet((comHtml + homeD + planD), "", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		if (comUrl.contains("https://www.forsail.com/communities/silver-lake")) {
			sqft = U.getSqareFeet((comHtml + homeD + planD + homeforSaleHtml), "", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		}

		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
		// Quick Move-In Home Data
		String qdata = null;
		String quickData = U.getSectionValue(U.getHTML("https://www.forsail.com/quick-move-ins"), ">Move-In Ready</h1>",
				">About Us</a>");
		String[] quickHomeData = U.getValues(quickData, "class=\"heading-5\">", ">For Sale</div>");
		U.log("quickHomeDa--" + quickHomeData.length);
		String quickhomeHtml = "";
		for (String quick : quickHomeData) {
			U.log("quick11:" + quick);
			String quickUrl = U.getSectionValue(quickData, "<a href=\"", "\"");
			quickUrl = "https://www.forsail.com" + quickUrl;
			U.log("quickUrl:-" + quickUrl);
			quickhomeHtml = U.getHTML(quickUrl);
		}
		// Community Data
		String propT = ALLOW_BLANK;
		String propStatus = ALLOW_BLANK;
		String drvPropT = ALLOW_BLANK;

		propT = U.getPropType((comHtml + homeD + quickhomeHtml).replaceAll("Villages at Vintaro", "")); // Property Type
		U.log("PType" + propT);

		// Community Data
		data.addCommunity(commName, comUrl, commType);
		data.addLatitudeLongitude(latL[0], latL[1], g);
		data.addPrice(minP, maxP);
		data.addAddress(address[0], address[1], address[2], address[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propT, drvPropT);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);

	}
}