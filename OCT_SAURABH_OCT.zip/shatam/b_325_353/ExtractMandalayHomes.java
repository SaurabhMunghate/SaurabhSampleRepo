package com.shatam.b_325_353;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMandalayHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver;
	
	
	public ExtractMandalayHomes() throws Exception {
		super("Mandalay Homes", "https://www.mandalayhomes.com/");
		LOGGER = new CommunityLogger("Mandalay Homes");
	}
//D
	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String regHtml=U.getHTML("https://www.mandalayhomes.com/");
		String[] comSecs=U.getValues(regHtml, " <div class=\"mod-community-flag-mlc-", "</div><input class=\"fooboxshare_post_id\" ");
		for(String comSec:comSecs) {
			String comurl=U.getSectionValue(comSec, "<a href=\"", "\"");
			String commName=U.getSectionValue(comSec, "style=\"font-size:2.2em;font-weight:100;margin-bottom:2px;line-height:1em\">", "</div>");
//			try {
				addDetails(comurl,commName,comSec);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addDetails(String comurl, String commName, String regComSec) throws Exception {
		// TODO Auto-generated method stub
//		if(!comurl.contains("https://www.mandalayhomes.com/community/jasper/")) return;
		
		// ----------------- Community Url-----------------------
				U.log("communityURL==========> "+comurl);
				String comHtml = U.getHTML(comurl);
				
				
		// ------------------ UNITS COUNT ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				units = getUnits(comHtml, comurl, driver);
				U.log("Total Units : "+units);
						
		
		// ----------------- Community Name-----------------------
				U.log("comName======> "+commName);
				
		// ----------------- Community LOGGER-----------------------
				if (data.communityUrlExists(comurl)) {
					LOGGER.AddCommunityUrl("-------Repeated-------" + comurl);
					return;
				}
				LOGGER.AddCommunityUrl(comurl);
				
				
		//====================================Note ======================================
				String note=ALLOW_BLANK;
				note= U.getnote(comHtml);
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] citystate= {ALLOW_BLANK,ALLOW_BLANK};
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				String addSec="";
				
				
				addSec=U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/", "\"");
				U.log("addSec: "+addSec);
				if(addSec==null||addSec==ALLOW_BLANK) {
					String address=U.getSectionValue(comHtml, "<div style=\"font-weight: 300;font-size: 1em;\">", "</div>");
					citystate=address.split(",");
					add[1]=citystate[0];
					add[2]=citystate[1];
					latLong=U.getGoogleLatLngWithKey(add);
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
					if(note.length()<3) {
						note="Address taken from city and state";
					}else {
						note=note+", Address taken from city and state";
					}
					
				}else {
				add=U.getAddress(addSec);
				}
				if(add[3]==null||add[3]==ALLOW_BLANK) {
					latLong=U.getGoogleLatLngWithKey(add);
					add=U.getAddressGoogleApi(latLong);
//					U.log("Address ::"+Arrays.toString(add));
					geo="true";
				}
				
				U.log("Address ::"+Arrays.toString(add));
//				U.log("Latlong ::"+Arrays.toString(latLong));
				if((add[0]!=null||add[0]!=ALLOW_BLANK)&& (add[3]!=ALLOW_BLANK || add[3]!=null)&& latLong[0]==ALLOW_BLANK) {
					latLong=U.getGoogleLatLngWithKey(add);
					geo="True";
				}
				U.log("latlng ::"+Arrays.toString(latLong));
				
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml,	"\\d\\,\\d{3} Sq Ft|\\d\\,\\d{3}  to  \\d\\,\\d{3}</div>", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				comHtml = comHtml.replaceAll(" option\">\\$\\d{3}K</option>| option\">\\d,\\d{3}\\+</option>", "")
						.replaceAll("\\$\\d{3},\\d{3}<input class=\"fooboxshare_post_id\" type=\"hidden\"", "");
				
				comHtml=comHtml.replace("<span>$300<span", "<span>$300,000<span").replace("<span>$400<span", "<span>$400,000<span");
//				String priceForm=U.getSectionValue(comHtml+regComSec, "<div class=\"home-search-filters\">", "</select>");
				String price[]= U.getPrices(comHtml+regComSec, "\\$\\d{3},\\d{3}|Under \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}<input", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
				
				// ----------------- Homes Data-----------------------
				int hm=0;
				String HomeSec="";
				String[] HomUrls=U.getValues(comHtml, "href=\"https://www.mandalayhomes.com/plan", "\"");
				for(String homeUrl:HomUrls) {
					hm++;
					homeUrl="https://www.mandalayhomes.com/plan"+homeUrl;
//					U.log(hm+"=== "+homeUrl);
					String hmHtml=U.getHTML(homeUrl);
//					if(hmHtml.contains("patio"))
//						U.log("Found");
					HomeSec+=U.getSectionValue(hmHtml, "<div style=\"padding-bottom:20px\">", "For More Information</div></div></div> ");
//					U.log(HomeSec);
				}
//				U.log(HomeSec);
				// ----------------- Community Data-----------------------
				
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				comHtml = comHtml.replace("farmhouse and contemporary styles", "farmhouse styles").replaceAll("chinese-traditional\":\"Chinese \\(Traditional\\)", "");
				propType=U.getPropType(comHtml+HomeSec);
//				U.log(Util.matchAll(comHtml+HomeSec, "[\\w\\s\\W]{30}farm[\\w\\s\\W]{30}", 0));
				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
				
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType(comHtml+HomeSec);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
				propStatus=U.getPropStatus((comHtml+regComSec).replaceAll("/move-in-ready-homes/", ""));
				
//				U.log(">>>>>>>>"+Util.matchAll(comHtml+regComSec, "[\\w\\s\\W]{100}Move-in-ready[\\w\\s\\W]{100}",0));
				U.log("\n");
				
				U.log("PStatus========>:::"+propStatus);
				if(comurl.contains("community/cliffs-at-the-dells/"))commName ="Cliffs At The Dells";

				
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
				data.addCommunity(commName, comurl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
				
				
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractMandalayHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Mandalay Homes.csv", a.data().printAll());
		
	}
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("Homesite Availability</h2>")) {
			
			String frameSec = U.getSectionValue(comHtml, "Homesite Availability</h2>", "</iframe>");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "src=\"", "\""); 
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.contains("lotvue.com") || frameUrl.contains("contradovip.com")) {
					
					mapData = U.getHtml(frameUrl, driver);
					U.log(U.getCache(frameUrl));
					
					if(comUrl.contains("/community/mountain-gate-the-traditions/")) {
						
						ArrayList<String> pins = Util.matchAll(mapData, "<g id=\"v.1.opt.", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}
					
					if(comUrl.contains("https://www.mandalayhomes.com/community/jasper/")) {
						
						ArrayList<String> pins = Util.matchAll(mapData, "id=\"IL_201_JA_JA_", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}
				}
				
			}
		}
		
		return totalUnits;
	}
			

}
