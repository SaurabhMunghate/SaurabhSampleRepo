package com.shatam.b_325_353;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;
/**
 * @author MJS
 * @date 31/03/2021 
 * 
 */
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractOurCountryHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.ourcountryhomes.com";
	HashMap<String, String> map = new HashMap<>();
	HashMap<String, String> mapdata = new HashMap<>();

	public ExtractOurCountryHomes() throws Exception {
		super("Our Country Homes", builderUrl);
		LOGGER = new CommunityLogger("Our Country Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractOurCountryHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Our Country Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
		
	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		String urlHtml = U.getHtml("https://www.ourcountryhomes.com/communities", driver);

		String[] comUrlSec = U.getValues(urlHtml, "<li class=\"result ng-scope", "</li>");
		
		String html = U.getHTML("https://api.mybuildercloud.com/api/v1/communities?where={%22published%22:true,%22builder%22:%225702abbdf410954eb27cdb56%22}&max_results=9999");
		String qHtml = U.getHTML("https://api.mybuildercloud.com/api/v1/homes?where={%22published%22:true,%22builder%22:%225702abbdf410954eb27cdb56%22}&max_results=9999");
		String fHtml = U.getHTML("https://api.mybuildercloud.com/api/v1/plans?where={%22published%22:true,%22builder%22:%225702abbdf410954eb27cdb56%22}&max_results=9999");
		
		JsonParser parser=new JsonParser();
		JsonArray arr=parser.parse(html).getAsJsonObject().get("_items").getAsJsonArray();
		U.log("arr===="+arr.size());
		for(int j=0;j<arr.size();j++) {
			String Data=arr.get(j).toString();
//			U.log("=================\n"+Data);
			String name=U.getSectionValue(Data, "\"sharedName\":\"", "\",");
			String mapURL=U.getSectionValue(Data, "\"zplaturl\":\"", "\"}");
//			break;
//			U.log("=================\n"+name);
//			U.log("=================\n"+mapURL);
			mapdata.put(name, mapURL);
//			break;
		}
		
		
		String[] mainSec = U.getValues(html, "\"_etag\": \"", "\"zillowHours\":");
		String[] quickSec = U.getValues(qHtml, "\"_etag\": \"", "\"uniqueName\":");
		String[] flooeSec = U.getValues(fHtml, "\"_etag\": \"", "\"uniqueName\":");
		U.log(mainSec.length);
		String data = ALLOW_BLANK;
		for(String main : mainSec) {
			
			String id = U.getSectionValue(main, "\"_id\": \"", "\"");
			String name = U.getSectionValue(main, "\"modifier_email\":", "\"openingHours\": \"");
			if(name == null)
				name = U.getSectionValue(main, "\"modifier_email\":", "\"photos\":");
			if(name == null)
				name = U.getSectionValue(main, "\"modifier_email\":", "\"outOfCommunity\"");
			name = U.getSectionValue(name, "\"name\": \"", "\"").trim();
			data = main;
			
			if (id != null) {
				for (String floor : flooeSec)
					if (floor.contains(id))
						data += "START OF FLOOR" + floor + "END OF FLOOR";
				for (String quick : quickSec)
					if (quick.contains(id))
						data += "START OF QUICK" + quick + "END OF QUICK";
			}
			map.put(name, data);
		}
		
		for(String com : comUrlSec) {
			
			//String comUrl = U.getSectionValue(com, "<a href=\"", "\"");
			String comUrl = U.getSectionValue(com, "href=\"", "\"");
			String name = U.getSectionValue(com, "<h4 class=\"ng-binding\">","<").trim();
//			U.log("name=="+name);
//			if(name.equals("Iron Horse Commons"))
//				U.log(comUrl+"\t"+name+"\t"+map.get(name));
			if(!comUrl.contains("https:/"))
				comUrl=builderUrl+comUrl;
			getDetail(comUrl, map.get(name), name);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}


	private void getDetail(String comUrl, String com, String name) throws Exception {
		// TODO Auto-generated method stub
		
//if(!comUrl.contains("https://www.ourcountryhomes.com/communities/highland-oaks"))return;
		
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = com;
//			U.log("com=========="+com);
			String commHtml=getHtml(comUrl, driver);
			
			String[] rem=U.getValues(commHtml, "<strong>Find Your Home", "Careers</a></li>") ;
			for(String remove : rem) {
//				U.log("rem===="+remove);
				commHtml=commHtml.replace(remove, "");
			}
			// ============================================Community
			// name=======================================================================
			
			String communityName = name;
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'").replaceAll("(.*)?>", "");
			U.log("community Name---->" + communityName);

			//============Unit Count
	        String counting=ALLOW_BLANK;
	        String startDt=ALLOW_BLANK;
	        String endDt=ALLOW_BLANK;	
			int lotCount=0;
//			if(mapdata.get(communityName)==communityName) {
//				String value=mapdata.toString();
//				U.log("valour===="+value);
//			}
			String shname=communityName.toLowerCase().replace(" ", "-");
			String value=mapdata.get(shname);
			U.log("valour===="+value);
			
			if(value!=null) {
				String lotHtml=U.getHtml(value,driver);
				String[] lotSection=U.getValues(lotHtml, "path class=\"leaflet-interactive", ">");
				counting=Integer.toString(lotSection.length);


			}
			
//			if(commHtml.contains("view map of lots")) {
//				String siteUrlPart=U.getSectionValue(commHtml, "<iframe id=\"map\"", "</iframe>");
//				if(siteUrlPart!=null) {
//				String siteUrl=U.getSectionValue(siteUrlPart, "src=\"", "\"");
//				U.log("siteUrl ::"+siteUrl);
//				String lotHtml=U.getHtml(siteUrl,driver);
//				U.log(U.getCache(siteUrl));
//				String lotPart=U.getSectionValue(lotHtml, "<svg xmlns=", "</svg>");
//				U.log("lotPart ::"+lotPart);
//				String[] lotSection=U.getValues(lotPart, "<path class=\"", "\"");
//				counting=Integer.toString(lotSection.length);
//				}
//			}
	        
			U.log("counting ::"+counting);
			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

//			String addSec = U.getSectionValue(html, "\"address\": {\"", "}");
//			
//			if(addSec!=null) {
//				
//				add[0] = U.getSectionValue(addSec, "\"streetAddress\": \"", "\"");
//				add[1] = U.getSectionValue(addSec, "\"addressLocality\": \"", "\"");
//				add[2] = U.getSectionValue(addSec, "\"addressRegion\": \"", "\"");
//				add[3] = U.getSectionValue(addSec, "\"postalCode\": \"", "\"");
//			
//			}
			
			String addSec=null;
			if(comUrl.contains("ochlifestylehomes") || comUrl.contains("OCHLifestylehomes")) {
				addSec=U.getSectionValue(commHtml, "<div class=\"u_1131439246 dmNewParagraph\"", "</div></div> ");
				U.log("addSec-1==="+addSec);
				addSec=U.getNoHtml(addSec);
				addSec=addSec.replaceAll("data-element-type=\"paragraph\" id=\"\\d+\" style=\"transition: opacity \\ds ease-in-out \\ds;\" data-version=\"\\d+\">|data-element-type=\"paragraph\" id=\"\\d+\" style=\"transition: opacity \\ds ease-in-out \\ds;\">", "")
						.replace("N. Richland Hills", ", N. Richland Hills")
						.replace("Haltom City", ", Haltom City")
						.replace("    Runaway Bay", ",Runaway Bay")
						.replace("&amp;", "&")
						.replaceAll("Model Home", "").trim();
				U.log("addSec-1==="+addSec);
				add=U.getAddress(addSec);

			}
			else {
				addSec=U.getSectionValue(commHtml, "class=\"com-info com-addy\"", "</i>");
					if(addSec!=null)
					{
							addSec=addSec.replace("</strong></li><li><i class=\"ng-binding\">", ", ");
							addSec=U.getNoHtml(addSec);
							String state=U.getSectionValue(commHtml, "\"addressRegion\": \"", "\",");
							U.log("state==="+state);
							addSec=addSec.replace(state, ", "+state).replace("&amp;", "&").trim();
							U.log("addSec-2==="+addSec);
							add=U.getAddress(addSec);
					}
			}
			
			
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
		
			String latSec = U.getSectionValue(html, "\"geoIndexed\": [", "]");
			String[] val = latSec.split(","); 
		
			latLng[0] = val[1];
			latLng[1] = val[0];
			U.log("hhhh-1--->" + latLng[0] + "  " + latLng[1]);		
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh-2--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0]==null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0]==null || add[0].length() < 4)
					add[0] = add1[0];
				if (add[3] == null)
					add[3] = add1[3];
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//========== Move In Homes ==================================================
			String moveData = U.getSectionValue(html, "START OF QUICK","END OF QUICK");
			
			//========== Floor Homes ==================================================
			
			String floorData = U.getSectionValue(html, "START OF FLOOR","END OF FLOOR");
//			U.log(">>>>>>>>"+Util.matchAll(floorData, "[\\w\\s\\W]{100}546 sq[\\w\\s\\W]{100}",0));
			
			if(comUrl.contains("https://www.OCHLifestylehomes.com/heritage-village")) {
				String planHtml=U.getPageSource("https://www.ochlifestylehomes.com/floor-plans");
//				U.log("planHtml ::"+planHtml);
				String[] planSec=U.getValues(planHtml, "<div class=\"caption-container u", "Button\n" + 
						"                                                    </span>");
						for(String urlSec : planSec) {
							String url="https://www.ochlifestylehomes.com"+U.getSectionValue(urlSec, "href=\"", "\"");
							floorData+=U.getPageSource(url);
						}
			}
			
			if(comUrl.contains("https://www.ochlifestylehomes.com/iron-horse-commons")) {
				String[] planSec=U.getValues(html, "<div class=\"caption-container u", "Button\n" + 
						"                                                    </span>");
						for(String urlSec : planSec) {
							String url="https://www.ochlifestylehomes.com"+U.getSectionValue(urlSec, "href=\"", "\"");
							floorData+=U.getPageSource(url);
						}
			}
			// ============================================Price and
			// SQ.FT======================================================================
			String id = U.getSectionValue(html, "\"_id\": \"", "\"");
			U.log(id+"::::::::this is id");
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
            String pricedata[] = U.getValues(html, "{\"community\": \""+id+"\", \"communityModelProperties\": {", "}");
			U.log(Arrays.toString(pricedata));
			String priceString="";
			for(String s: pricedata) {
				priceString+=s+":::::::::::";
			}	
            html = html.replace("From the $400s", "From the $400,000")
            		.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
            commHtml=commHtml
            		.replace("From the $400s", "From the $400,000")
            		.replace("From the $500s", "From the $500,000");
			com = com.replaceAll("0&#39;s|0&#8217;s|0s|0's", "0,000").replaceAll("\"bd_priceDisplay\": \"From the \\$\\d{3}|com_priceDisplay\": \"From the \\$\\d{3},\\d{3}\"|\"communityModelProperties\": \\{\"price\": \\d+\\}", "").replace("&#39;s", ",000");
			commHtml=commHtml.replace("From the low $300s", "From the low $300,000")//.replaceAll("From the $500s", "From the $500,000")
					.replace("From the $345s", "From the $345,000");
			html = html.replaceAll("\"bd_priceDisplay\": \"From the \\$\\d{3},\\d{3}|com_priceDisplay\": \"From the \\$\\d{3},\\d{3}\"|\"communityModelProperties\": \\{\"price\": \\d+\\}", "").replace("0s", "0,000");
			String prices[] = U.getPrices(commHtml+com + html +priceString, "From the low \\$\\f{3},\\d{3}|From the \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\"priceLow\": \\d+|\"price\": \\d+|\\$\\d{3},\\d{3}", 0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log(">>>>>>>>"+Util.matchAll(html +priceString+commHtml+com, "[\\w\\s\\W]{100}From the \\$400s[\\w\\s\\W]{100}",0));


			// ======================================================Sq.ft===========================================================================================
		commHtml=commHtml.replace("SQFT: <strong class=\"ng-binding\">", "SQFT: ");
			String[] sqft = U.getSqareFeet(commHtml+floorData+moveData,
					"\\d,\\d{3} Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} sq. ft.|SQFT: \\d,\\d+|SqFt From: </strong>\\d,\\d+|\"sqft\": \\d+|\"sqftLow\": \\d+",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			String communityType = U.getCommType((commHtml).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================

			String proptype = U.getPropType((html).replace("executive luxury homes", "executive-style luxury homes"));

			// ==================================================D-Property
			// Type======================================================
			html = html.replace("\"stories\": ", " Story").replaceAll("single and 2-story", "1-story and 2-story");
			String dtype = U.getdCommType((html).replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
			
			commHtml=commHtml.replace("Quick Move-In <strong class", "")
					.replaceAll("Coming Soon -1 and 2 Acre Lots in Boyd", "")
					.replace("2+ Acre lots Coming Soon", "")
					.replace("Coming Soon !  Acre + lots", "")
					.replace("New Phase - Coming Soon", "New Phase Coming Soon")
					.replace("Now Selling in Phase II", "Now Selling Phase II");
			
			
			
			html = html.replaceAll("Coming Soon -1 and 2 Acre Lots in Boyd", "")
					.replace("Coming Soon !  Acre + lots", "")
					.replaceAll("\"status\": \"Coming Soon\"|into new phase|\"com_status\": \"Coming|\"Grand Opening\", \"style\": \"Townhomes\"|Pre-Sells are now available|<strong>NOW SELLING!</strong></span>|\"com_statusDisplay\": \"Now Selling\"|bd_statusDisplay\": \"Now Selling\"|mageTitle\": \"Coming|statusDisplay\": \"Coming|[S|s]pec [C|c]oming|[Q|q]uick [M|m]ove|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					
					.replace("wooded & waterfront lots are available", "wooded and waterfront lots available").replace("Phase I is almost sold out", "Phase I almost sold out").replace("now selling the final lots in Phase I", "Final Lots Now selling Phase I").replace("New Phase - Coming Soon ", "New Phase Coming Soon ").replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			String pstatus = U.getPropStatus(commHtml
					.replaceAll("Quick Move-In|<h2 class=\"heading-one centerit\">Quick Move-In|page-text-style\">Quick Move-In<span| data-link-text=\"\n" + 
							"         Quick Move-In", "")
					.replace("Phase II, Coming Soon", "Phase II Coming Soon").replace("wooded & waterfront lots are available", "wooded & waterfront lots available").replace("Phase I is almost sold out", "Phase I almost sold out"));//.replace("now selling the final lots in Phase I", "Final Lots Now selling Phase I")
			U.log(">>>>>>>>"+Util.matchAll(commHtml, "[\\w\\s\\W]{100}quick move-in[\\w\\s\\W]{100}",0));
			// ============================================note====================================================================
			html=html.replaceAll("comImageTitle\": \"Lakes of Argyle Pre Selling|_pre-selling-|\"imageTitle\": \"Lakes of Argyle Pre Selling\"", "");
			note=U.getnote(commHtml+html.replace("Phase II - Now Pre-Selling", "Phase II Now Pre-Selling").replace("Pre-Sells are now available", "Pre-Sells now available").replace("Phase II - Now Pre-Selling", "Phase II Now Pre-Selling"));
//			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
//			U.log(">>>>>>>>"+Util.matchAll(commHtml, "[\\w\\s\\W]{100}Pre Selling[\\w\\s\\W]{100}",0));
//			U.log(">>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{100}Pre Selling[\\w\\s\\W]{100}",0));

			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|Argyle, TX 76226", "");
			
		
//			if(moveData!=null && moveData.contains("\"status\": \"Active\""))
//				if(pstatus==ALLOW_BLANK)
//					pstatus = "Quick Move-Ins";
//				else if(!pstatus.contains("Quick Move-Ins")) 
//					pstatus += ", Quick Move-Ins";
			
			if(comUrl.contains("https://www.OCHLifestylehomes.com/heritage-village"))comUrl="https://www.ochlifestylehomes.com/heritage-village";
			if(comUrl.contains("https://www.ourcountryhomes.com/communities/highland-crossing"))note="Pre-Sells Now Available";
			
			pstatus = pstatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			
			add[1]=add[1].replace("Fort Worth / Eagle Mountain", "Fort Worth");
			
			if(comUrl.contains("highland-crossing"))note=ALLOW_BLANK;
			
			if(comUrl.contains("/communities/parks-of-aledo") ||
					comUrl.contains("/communities/the-resort-on-eagle-mt-lake"))
			{
				if(pstatus.length()>1)
					pstatus=pstatus+", Quick Move-In";
				else
					pstatus="Quick Move-In";
			}
			
			if(comUrl.contains("https://www.ochlifestylehomes.com/iron-horse-commons"))proptype+=", Homeowner Association";
			if(comUrl.contains("/runaway-bay"))
					communityType="Golf Course, Lakeside Community";
			
			if(counting.equals("0"))counting=ALLOW_BLANK;
			
			//=========================================================================================================================

			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replaceAll(">|TBD |,", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Ii", "II").replace("Waterfront Lots Available", "wooded and waterfront lots available"));
			data.addNotes(note.replace("Ii", "II"));
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;

	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					driver.manage().window().maximize();
					driver.get(url);
					Thread.sleep(10000);

					//U.log("after::::"+url);
					html = driver.getPageSource();
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
//					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(1000);
					if(html.contains("view map of lots")) {
						try {
							driver.findElement(By.xpath("//*[@id=\"page\"]/main/ui-view/div[2]/div/div/aside/div[6]/ul/li/a[2]")).click();
							Thread.sleep(5000);
							html += driver.getPageSource();
						}catch(Exception e) {
							U.log("Site map is not found.");
						}
					}
					
//					if(url.contains("")||url.endsWith("idx")) {
//						driver.switchTo().frame(0); // community map
//						U.log("Inside");
//					}else if(driver.getPageSource().contains("Directions")) {
//						driver.findElement(By.xpath("//*[@id=\"comp-jpsqdr7t\"]/a")).click();
//					}
				
//					Thread.sleep(5000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
//					html = driver.getPageSource();
//					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}

}