package com.shatam.b_325_353;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.openqa.selenium.WebDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPrincetonClassicHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver=null;
	public ExtractPrincetonClassicHomes() throws Exception {

		
		super("Princeton Classic Homes", "https://www.princetonclassichomes.com/");
		LOGGER = new CommunityLogger("Princeton Classic Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractPrincetonClassicHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Princeton Classic Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		String mainHtml=U.getHTML("https://www.princetonclassichomes.com/");
		mainHtml=mainHtml.replace("<a href=\"/communities\"", "");
		String comSections[]=U.getValues(mainHtml, "<a href=\"/communities", "/a>");
		
		for(String comSec:comSections) {
			
			String comUrl="https://www.princetonclassichomes.com/communities/"+U.getSectionValue(comSec, "/", "\"");

			addDetails(comUrl, comSec);
			
		}
		
		
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comUrl, String comSec) throws Exception {
		
		U.log("====================="+j);
		U.log(comUrl);
		//TODO:
	//	if(!comUrl.contains("https://www.princetonclassichomes.com/communities/rodeo-palms-lakes"))return;
		
		LOGGER.AddCommunityUrl(comUrl);
		String comName=U.getSectionValue(comSec, "\">", "<");
		U.log(comName);
		
		String comHtml=U.getHTML(comUrl);
		
		U.getCache(comUrl);
		//U.log(comSec);
		//=========================address=================================================
	
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String addSec=U.getSectionValue(comHtml, "SALES OFFICE", "/a>");
		
		U.log(addSec);
		latlag[0]=U.getSectionValue(addSec, "place/", ",");
		latlag[1]="-"+U.getSectionValue(addSec, ",-", "\"");
		
		String addSec1=U.getSectionValue(addSec.replaceAll("<br>|, ", ","), "\">", "<");
//		String addSec1=U.getSectionValue(addSec.replaceAll("<br>|, ", ","), "\">", "<");
		U.log("AA"+addSec);
		if(addSec1!=null)
		  add=U.getAddress(addSec1);
		
		if(comUrl.contains("https://www.princetonclassichomes.com/communities/lake-shore-harbour-sold-out")) {
			add[0]="3231 Lake Shore Harbour Dr";
			add[1]="Missouri City";
			add[3]="77459";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";			 
		}
		
//		if(add[0]==ALLOW_BLANK) {
//		add=U.getAddressGoogleApi(latlag);
//		geo="TRUE";
//		}
		if(add[2]==null|| add[2]==ALLOW_BLANK) {
			add[2]=U.getAddressGoogleApi(latlag)[2];
			geo="TRUE";	
		}
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log(geo);
		
		
		 //============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		
	      String comPrice=U.getSectionValue(comHtml, "header-price", "</span>")
	    		  +U.getSectionValue(comHtml, "<h2>Community Home Series</h2>", "</a></div></div>");
	      comPrice=comPrice.replace("</div>", ",000")
	    		  .replaceAll("From the \\$(\\d{3})s", "From the \\$$1,000");
	      
	      comHtml = comHtml.replaceAll("Was \\$\\d{3},\\d+</div>", "");
	 
	      String quickPrices=U.getSectionValue(comHtml, "data-view=\"available_homes\">", "</script>")+U.getSectionValue(comHtml, "data-view=\"available_homes\">", "<div class=\"views-element-container\">");
	      String plansPrices=U.getSectionValue(comHtml, "<h2>Available Floor Plans</h2>", "<h2>Nearby Communities</h2>");
	 
	      
			prices=U.getPrices(quickPrices+comPrice+plansPrices, "$457,246|\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
			
			U.log(Arrays.toString(prices));
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(comHtml, ">\\d{1},\\d{3}</div>", 0);
			
			U.log(Arrays.toString(sqft));
		//	U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}283[\\w\\s\\W]{30}",0));
			String commDesc=U.getSectionValue(comHtml, "sectioncommunity", "Directions").replace("waterfront home sites", "waterfront community home sites");
			//U.log("descr"+commDesc);
			String cType=U.getCommType(commDesc);
			U.log(cType);
			
			
			String pType=ALLOW_BLANK;
			pType = U.getPropType(comHtml.replace("Village", ""));
			
			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			
			String quickSec = U.getSectionValue(comHtml, "<div class=\"section-homes\"", "</script>");
			String[] qUrl = U.getValues(quickSec, "href=\"/home/", "\"");
			String qucikData =ALLOW_BLANK;
			for(String quick : qUrl) {
				
				quick = "https://www.princetonclassichomes.com/home/"+quick;
				qucikData+=U.getHTML(quick);
//				U.log("quick: "+quick);
				
			}
			
//			String floorSec = U.getSectionValue(comHtml, "<div class=\"section-homes\"", "</script>");
			String[] fUrl = U.getValues(comHtml, "<a class=\"w-inline-block w-clearfix details-link\" href=\"/plan/", "\"");
			String floorData =ALLOW_BLANK;
			for(String floor : fUrl) {
				
				floor = "https://www.princetonclassichomes.com/plan/"+floor;
//				U.log("floor :::"+ floor);
				floorData+=U.getHTML(floor);
				
			}
			if(qucikData!=null)
				qucikData = qucikData.replaceAll("Stories</h4><h3 class=\"input\">", " Story ");
			if(floorData!=null)
				floorData = floorData.replaceAll("Stories</h4><h3 class=\"input\">", " Story ");
			
			
			
			
			comHtml = comHtml.replaceAll("318 Arbor Ranch Circle|interior doors on first floor|ranchhs|Ranch High|Ranch\\+High|Ranch Circle", "");
			dType = U.getdCommType((comHtml+qucikData+floorData).replace("318 Arbor Ranch Circle", "").replace("Story 2", "2 story"));
			
//			U.log(Util.matchAll(comHtml+qucikData+floorData, "[\\w\\s\\W]{100}Ranch[\\w\\s\\W]{100}",0));
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;

			comHtml=comHtml.replaceAll("homesites available set among|-sold-out\"|>Waterfront Home Sites Available</p>|- Sold Out</span>|\">Lake Lots Available</p>|Lake Shore Harbour - Sold Out</span>|/laurel-glen-close-out\"", "")
					.replace("water front home sites set among almost", "waterfront homesites available set among almost");
	//		U.log("JJJJJJJJJJJjjj"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}close-out[\\w\\s\\W]{100}",0));
			pStatus = U.getPropStatus(comHtml.replaceAll("/communities/lilac-bend-close-out|communities/upland-square-close-out|/marcello-lakes-close-out|/home/marcello-lakes-sold-out", "").replace("homesites available set among", "").replace("Section Coming October 2021", "New Section Coming October 2021"));
			
			
			
//			U.log(">>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Close out[\\w\\s\\W]{30}",0));
			U.log("status:::::::" + pStatus);
			
			if(quickSec!=null && !quickSec.contains("/home/"))
				pStatus = pStatus.replaceAll("Quick Move-in Homes,|Quick Move-in Homes|, Quick Move-in Homes", "");
			
			if (pStatus == null || pStatus.length()<3)
				pStatus = ALLOW_BLANK;
			
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			if(comUrl.contains("https://www.princetonclassichomes.com/communities/marcello-lakes"))dType="1 Story";
//			if(comUrl.contains("https://www.princetonclassichomes.com/communities/greatwood-lake"))prices[1]="$411,990";
			//if(comUrl.contains("/communities/rodeo-palms-lakes"))pStatus="Quick Move-in Homes";
//			if(comUrl.contains("sold-out"))pStatus="Sold Out";
			if(comUrl.contains("communities/greatwood-lake-new-section-coming-december-2021")||comUrl.contains("communities/marcello-lakes-sold-out") )
				pStatus=pStatus.replaceAll("Close Out, |Close-out, ", "");
			U.log("status:::::::" + pStatus);
			
			data.addCommunity(comName, comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(comHtml));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		    data.addUnitCount(ALLOW_BLANK);
		
		
		
		
		
		
		
		j++;
	}
	
}
