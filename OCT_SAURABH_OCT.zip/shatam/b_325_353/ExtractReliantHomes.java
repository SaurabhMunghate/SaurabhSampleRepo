package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractReliantHomes extends AbstractScrapper{
	CommunityLogger LOGGER;
WebDriver driver=null;
	static int j = 0;

	public ExtractReliantHomes() throws Exception {

		super("Reliant Homes", "https://www.relianthomes.com/");
		LOGGER = new CommunityLogger("Reliant Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractReliantHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Reliant Homes.csv", u.data().printAll());
		
	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		String mainHtml=getHtml("https://www.relianthomes.com/", driver);
		String regUrls[]=U.getValues(mainHtml, "homepage-cta-btn", "</a>");
		for(String regU:regUrls) {
			//U.log(regU);
			String regUrl="https://www.relianthomes.com/"+U.getSectionValue(regU, "href=\"", "\"");
			
			String regHtml=getHtml(regUrl, driver);
			
		//	String comSections[]=U.getValues(regHtml, "\"comm-comm-item ng-scope ng-isolate-scope\"", "</community-card>");
			String comSections[]=U.getValues(regHtml, "<li ng-if=\"community.name\" ", " </a><div class=\"fav-wrap\"");
			U.log(comSections.length);
			for(String comSec:comSections) {
				
				String comUrl="https://www.relianthomes.com"+U.getSectionValue(comSec, "href=\"", "\"");

//				try {
					addDetails(comUrl, comSec);
//				} catch (Exception e) {}
			}
		}
		driver.quit();
		LOGGER.DisposeLogger();
		
	}

	public void addDetails(String comUrl, String comSec) throws Exception {

		//U.log(comSec);
//	if(j>=6) {
		U.log("comUrl: "+comUrl);
		
		//TODO:
//		if(!comUrl.contains("https://www.relianthomes.com/communities/fountain-inn/martin-woods"))return;
		
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String comHtml=getHtml(comUrl, driver);
		U.log(U.getCache(comUrl));	
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		//String comName=U.getSectionValue(comSec, "class=\"ng-binding ng-scope\" style=\"\">", "</li>");
		String comName=U.getSectionValue(comHtml, "<h1 class=\"ng-binding\">","</h1>");
				if(comUrl.contains("https://www.relianthomes.com/communities/monroe/belmont"))
				{
					comName="Belmont";
				}
				if(comUrl.contains("https://www.relianthomes.com/communities/loganville/bentley-farms"))
				{
					comName="Bentley Farms";
				}
				
				if(comUrl.contains("https://www.relianthomes.com/communities/winder/calgary-downs"))
				{
					comName="Calgary Downs";
				}
			if(comUrl.contains("https://www.relianthomes.com/communities/monroe/clubside-estates"))
				{
					comName="Clubside Estates";
				}
	
	if(comUrl.contains("https://www.relianthomes.com/communities/monroe/grand-haven-at-alcovy-mountain"))
		{
			comName="Grand Haven at Alcovy Mountain";
		}
	if(comUrl.contains("https://www.relianthomes.com/communities/monroe/reserve-at-flat-creek"))
	{
		comName="Reserve At Flat Creek";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/monroe/the-fields-at-alcovy-mountain"))
	{
		comName="The Fields at Alcovy Mountain";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/anderson/willow-haven-at-cobbs-glen"))
	{
		comName="Willow Haven at Cobb's Glen";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/hull/woodbury"))
	{
		comName="Woodbury";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/greenville/reedy-springs"))
	{
		comName="Reedy Springs";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/loganville/bullock-estates"))
	{
		comName="Bullock Estates";
	}
	
		U.log("comunityname=>"+comName);
		if(comUrl.contains("https://www.relianthomes.com//communities/anderson/axman-oaks"))comName="Axman Oaks";
		if(comUrl.contains("https://www.relianthomes.com//communities/greenville/reedy-springs"))comName="Reedy Springs";
		if(comUrl.contains("https://www.relianthomes.com//communities/anderson/willow-haven-at-cobbs-glen"))comName="Willow Haven at Cobbs Glen";
		
		//============================address section==============================================
		
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
//		String addressSec=U.getSectionValue(comHtml, "Location:", "</h4>");
//		U.log(addressSec);
//		add=U.getAddress(addressSec);
		U.log(U.getCache(comUrl));
		String latlagSec=U.getSectionValue(comHtml, "\"https://www.google.com/", "\"");
		
	//String latlagSec=U.getSectionValue(comHtml, "latitude", "longitude");
	//	U.log("lat"=>latlagSec);
		if(latlagSec != null) {
			latlag[0]=U.getSectionValue(latlagSec, "/@", ",");
			latlag[1]="-"+U.getSectionValue(latlagSec, ",-", ",");
		}
			
		
		if(latlag[0]==null)
		{
			latlag[0]=	U.getSectionValue(comHtml, "latitude\":", "\"");
			latlag[1]=U.getSectionValue(comHtml, "longitude\":", "\"");
		}
		if(comName.equals("Individual Home Sites") || comName.equals("Reserve At Flat Creek") || comName.equals("Calgary Downs")) {

			latlag[0]=	U.getSectionValue(comHtml, "\"latitude\": \"", "\"");
			latlag[1]=U.getSectionValue(comHtml, "\"longitude\": \"", "\"");
		}
		
		try{
		add=U.getAddressGoogleApi(latlag);
		}
		catch(Exception e){
			
			add=U.getAddressHereApi(latlag);
		}
		
		
		geo="TRUE";
		
		
		U.log(Arrays.toString(add));
		U.log("latlong==>"+Arrays.toString(latlag));
		U.log(geo);
		
		
		String[] floorSec = U.getValues(comHtml, "<plan-card plan=\"plan\"", "</plan-card> </div>");
		
		String floorData = ALLOW_BLANK;
		
		if(!comHtml.contains("class=\"home-tile col-lg-3 ng-scope ng-hide\""))
		for(String plan : floorSec) {
			
			plan = U.getSectionValue(plan, "href=\"", "\"");
			U.log("Plan: "+plan);
			String pHtml = U.getHtml("https://www.relianthomes.com"+plan, driver);
			floorData = floorData + U.getSectionValue(pHtml, "<section class=\"homm-det-header", "</section>")+
					U.getSectionValue(pHtml, " id=\"description\"> ", "</section>");
		}
		
		String homeHtml = null;
		String[] planUrls = U.getValues(comHtml, "<div class=\"home-image\"> <a href=\"", "\"");
		U.log("planUrls.length: "+planUrls.length);
		
		
		
		for(String planUrl : planUrls){
			//
			//U.log("planUrl -->"+"https://www.relianthomes.com"+planUrl);
			homeHtml += U.getSectionValue(U.getHtml("https://www.relianthomes.com"+planUrl, driver), "<section class=\"homm-det-header", "</section>")+
					U.getSectionValue(U.getHtml("https://www.relianthomes.com"+planUrl, driver), "<h4>Property <span>Description</span></h4>", "<h3 class=\"home-list-title\">Other Homes in this Community</h3>");;
			
			//homeHtml += U.getHtml("https://www.relianthomes.com"+planUrl, driver);
		}
//		U.log(Util.matchAll(floorData, ".*loft.*", 0));
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			prices=U.getPrices(comHtml+comSec + homeHtml, "\\$\\d{3},\\d{3}", 0);
			
			U.log(Arrays.toString(prices));
//			U.log(Util.matchAll(comHtml+homeHtml, "[\\w\\s\\W]{30}602[\\w\\s\\W]{30}",0));
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			if(comHtml.contains("class=\"home-tile col-lg-3 ng-scope ng-hide\""))
				comHtml = comHtml.replaceAll("\\d,\\d+ SQ FT</span>", "");
			
			sqft=U.getSqareFeet(comHtml+comSec, "\\d{1},\\d{3} - \\d{1},\\d{3}|\\d{1},\\d{3} SQ", 0);
			
			U.log(Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comHtml).replace(",Country Club", ", Country Club")
					.replace(",Active Adult", ", Active Adult").replace(",Resort Style", ", Resort Style");
			U.log(cType);
//			String homeUrl=ALLOW_BLANK;
//			String homeData=ALLOW_BLANK;
//			String[] homeSecUrls=U.getValues(comHtml,"<div class=\"home-image\">", "<div class=\"home-content\">");
//			for(String homeUrlSec: homeSecUrls) {
//				homeUrl=U.getSectionValue(homeUrlSec, "<a href=\"", "\"");
//				homeData=homeData+U.getHTML("")
//				
//			}
				
			String pType=ALLOW_BLANK;
			pType = U.getPropType(comHtml+homeHtml+floorData); 

			U.log("pType::::::" + pType);
//			U.log(Util.matchAll(comHtml+homeHtml, "[\\w\\s\\W]{30}loft[\\w\\s\\W]{30}",0));
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			

			
			if(floorData!=null)
				floorData = floorData.replaceAll("</span> Stories", " Story");
			
			dType = U.getdCommType(comHtml+floorData+homeHtml).replace(",2 Story",", 2 Story")
					.replace(",Ranch",", Ranch");
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;

			pStatus = U.getPropStatus((comHtml).replace("== 'Coming Soon'", ""));
			//U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			
			if(comUrl.contains("https://www.relianthomes.com/communities/winder/sims-crossing")) {
				dType="2 Story, 1.5 Story";
			}
			if(comUrl.contains("https://www.relianthomes.com//communities/bethlehem/berry-springs"))sqft[0]="2,300";
			if(comUrl.contains("https://www.relianthomes.com//communities/winder/calgary-down"))dType="2 Story, 1 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/winder/sims-crossing"))dType="2 Story, 1 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/monroe/grand-haven-at-alcovy-mountain"))dType+=", 2 Story, 1 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/anderson/axman-oaks"))dType="2 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/loganville/fairwinds")) {
				prices[1]="$379,900";
				sqft[1]="3300";
			}
			if(comUrl.contains("https://www.relianthomes.com//communities/monroe/belmont"))add[0]="70 Bella Dr";
			

			if(comUrl.contains("https://www.relianthomes.com//communities/winder/sims-crossing"))sqft[1]="2938";
			
			if(comUrl.contains("https://www.relianthomes.com/communities/monroe/clubside-estates"))dType="2 Story";
			if(comUrl.contains("https://www.relianthomes.com/communities/monroe/grand-haven-at-alcovy-mountain"))
				{
				dType="Split Level, Ranch, 1 Story";
				pType="Patio Homes, Traditional Homes";
				}
			if(comUrl.contains("https://www.relianthomes.com/communities/fountain-inn/martin-woods") ||
				comUrl.contains("https://www.relianthomes.com/communities/loganville/individual-home-sites-ga") ||
				comUrl.contains("https://www.relianthomes.com/communities/loganville/bullock-estates"))  dType = dType +", 1 Story";
			
			
			if(comUrl.contains("https://www.relianthomes.com/communities/loganville/bentley-farms"))pType="Loft";
			if(comUrl.contains("https://www.relianthomes.com/communities/winder/calgary-downs"))pType="Loft";
			if(comUrl.contains("https://www.relianthomes.com/communities/hull/woodbury"))pType="Loft";
		
			
			
			data.addCommunity(comName, comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(comHtml));
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
		
		
		
		U.log("================================"+j);
//		}
		j++;
		
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(12000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					int i=0;
					
					try{
						if(driver.getPageSource().contains("AVAILABLE HOMES") ) {
							driver.findElement(By.xpath("//*[@id=\"homes\"]/div/div[1]/ul/li[1]/a[1]")).click();
							U.log("click ------>  AVAILABLE HOMES");
							Thread.sleep(4000);
							html += driver.getPageSource();
							
						}
					}catch(Exception e){
						U.log("Not Click on  --> AVAILABLE HOMES");
					}
					try{
						if (driver.getPageSource().contains("UNDER CONTRACT")){
							U.log("click ------>  UNDER CONTRACT");
	
							driver.findElement(By.xpath("//*[@id=\"homes\"]/div/div[1]/ul/li[2]/a[1]")).click();
							Thread.sleep(4000);
							html += driver.getPageSource();
						}			
					}catch(Exception e){
						U.log("Not Click on  --> AVAILABLE HOMES");
					}
					try{
						if(driver.getPageSource().contains("FLOOR PLANS")) {
							U.log("click ------> FLOOR PLANS");
	
							driver.findElement(By.xpath("//*[@id=\"homes\"]/div/div[1]/ul/li[3]/a[1]")).click();
							Thread.sleep(1000);
							html += driver.getPageSource();
						}
					}catch(Exception e){
						U.log("Not Click on  --> FLOOR PLANS");
					}
/*					String urlsplitted[]=url.split("/");
					U.log(urlsplitted.length);
					if(urlsplitted.length==7) {
						

						
							html += driver.getPageSource();
					}
					else {
					
					}
*/
					html += driver.getPageSource();
					
					Thread.sleep(3000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("src=\"https://www.mybuildercloud.com")) {
			
			
			frameUrl = U.getSectionValue(comHtml, "src=\"https://www.mybuildercloud.com", "\""); 
			frameUrl = "https://www.mybuildercloud.com" + frameUrl;
			U.log("frameUrl: "+frameUrl);
			
			if(frameUrl.contains("PlatMaps")) {
				
				mapData = U.getHtml(frameUrl, driver);
				U.log(U.getCache(frameUrl));
				
				if(mapData.contains("<path class=\"leaflet-interactive")) {
					
					ArrayList<String> pins = Util.matchAll(mapData, "<path class=\"leaflet-interactive", 0);
					U.log("Count Pins: "+pins.size());
					totalUnits = String.valueOf(pins.size());
				}
			}
		}
		
		return totalUnits;
	}
	
}
