package com.shatam.b_325_353;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractRiversideHomebuilders extends AbstractScrapper {
	CommunityLogger LOGGER;
//	WebDriver driver = null;

	static int j = 0;

	public ExtractRiversideHomebuilders() throws Exception {

		super("Riverside Homebuilders", "https://www.riversidehomebuilders.com/");
		LOGGER = new CommunityLogger("Riverside Homebuilders");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractRiversideHomebuilders();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Riverside Homebuilders.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		JsonParser jparser=new JsonParser();

		String mainHtml = U.getHTML("https://www.riversidehomebuilders.com/communities");
//		U.log(mainHtml);
		String comSecScript=U.getSectionValue(mainHtml, "<script>window.__PRELOADED_STATE__ = ", "</script>"); // "\"data\":[],\"receivedAt\":");
	
		JsonArray communityArray = new JsonArray();
		JsonArray homesArray = new JsonArray();
		JsonArray plansArray = new JsonArray();
		JsonArray lotsArray = new JsonArray();
		
		JsonObject communityJObj = jparser.parse(comSecScript).getAsJsonObject().get("cloudData").getAsJsonObject().get("communities").getAsJsonObject();
		for(Entry<String, JsonElement> entry : communityJObj.entrySet()) {
//			U.log(entry.getKey());
			if(entry.getValue().getAsJsonObject().get("data").isJsonArray()) {
				communityArray.addAll(entry.getValue().getAsJsonObject().get("data").getAsJsonArray());
			}else continue;
		}
//		U.log(communityJObj);
		U.log("Community ::"+communityArray.size());
		
		JsonObject homesJObj = jparser.parse(comSecScript).getAsJsonObject().get("cloudData").getAsJsonObject().get("homes").getAsJsonObject();
		for(Entry<String, JsonElement> entry : homesJObj.entrySet()) {
			if(entry.getKey().contains("recent"))continue;
//			U.log(entry.getKey());
			if(entry.getValue().getAsJsonObject().get("data").isJsonArray()) {
				homesArray.addAll(entry.getValue().getAsJsonObject().get("data").getAsJsonArray());
			}else continue;
		}
		U.log("Homes ::"+homesArray.size());
		
		JsonObject plansJObj = jparser.parse(comSecScript).getAsJsonObject().get("cloudData").getAsJsonObject().get("plans").getAsJsonObject();
		for(Entry<String, JsonElement> entry : plansJObj.entrySet()) {
			if(entry.getKey().contains("recent"))continue;
//			U.log(entry.getKey());
			if(entry.getValue().getAsJsonObject().get("data").isJsonArray()) {
				plansArray.addAll(entry.getValue().getAsJsonObject().get("data").getAsJsonArray());
			}else continue;
		}
		U.log("Plans ::"+plansArray.size());
		
		
//		String idPayload =U.sendPostRequestAcceptJson(");
		String idPayload=sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetCommunitiesLite\",\"variables\":{\"clientName\":\"rshomebuilders\"},\"query\":\"query GetCommunitiesLite($clientName: String!, $bonafide: Boolean) {\\n  communities(clientName: $clientName, active: true, bonafide: $bonafide) {\\n    id\\n    name\\n    logo\\n    longitude\\n    latitude\\n    thumb\\n    bonafide\\n    pricing\\n    agents(clientName: $clientName) {\\n      id\\n      email\\n      phone\\n      firstName\\n      lastName\\n      __typename\\n    }\\n    cityLocation(clientName: $clientName) {\\n      id\\n      name\\n      customName\\n      stateCode\\n      metroName\\n      metroCustomName\\n      zip\\n      postCode\\n      __typename\\n    }\\n    plans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      name\\n      bedRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      bathRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      costRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      sizeRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      src\\n      siteplanType\\n      geoInfo(clientName: $clientName) {\\n        id\\n        siteplanId\\n        neLatitude\\n        neLongitude\\n        swLatitude\\n        swLongitude\\n        geoJson\\n        __typename\\n      }\\n      __typename\\n    }\\n    lots(clientName: $clientName) {\\n      id\\n      salesStatus\\n      inventory(clientName: $clientName) {\\n        id\\n        price\\n        sqft\\n        beds\\n        baths\\n        elevationId\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}");
//		U.log("Payload data : "+idPayload);
		JsonArray communityIdsJObj = jparser.parse(idPayload).getAsJsonObject().get("data").getAsJsonObject().get("communities").getAsJsonArray();
		U.log("communityIds  : "+communityIdsJObj.size());
		
		String comName = null;
		String unitsize = null;
		for(JsonElement comSec : communityArray) {
			String comUrl = "https://www.riversidehomebuilders.com/communities/" + U.getSectionValue(comSec.toString(), "\"area\":\"", "\"").trim().toLowerCase().replaceAll(" ", "-")+"/" +U.getSectionValue(comSec.toString(), "\"sharedName\":\"", "\"");
			comName = comSec.getAsJsonObject().get("name").getAsString();
			String name="matchcheck";
			for(JsonElement lotElement : communityIdsJObj) {
				if(comName.equals(lotElement.getAsJsonObject().get("name").getAsString())) {			
					name="match";
					String communityId = lotElement.getAsJsonObject().get("id").getAsString();
					String lotPayload = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetSiteplanLiteByCommunityId\",\"variables\":{\"clientName\":\"rshomebuilders\",\"communityId\":"+communityId+"},\"query\":\"query GetSiteplanLiteByCommunityId($clientName: String!, $communityId: Int!) {\\n  activeSiteplanByCommunityId(clientName: $clientName, communityId: $communityId, master: false) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    ...HotspotsFields\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      garagePosition\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    subSiteplans(clientName: $clientName, active: true) {\\n      id\\n      name\\n      info(clientName: $clientName) {\\n        siteplanId\\n        thumb\\n        fontSize\\n        x\\n        y\\n        whiteLabel\\n        showsThumb\\n        __typename\\n      }\\n      lots(clientName: $clientName) {\\n        id\\n        communityId\\n        salesStatus\\n        inventory(clientName: $clientName) {\\n          id\\n          communityId\\n          lotId\\n          planId\\n          elevationId\\n          __typename\\n        }\\n        excludedPlanElevations(clientName: $clientName) {\\n          planId\\n          elevationId\\n          planName\\n          planDisplayName\\n          elevationCaption\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment HotspotsFields on Siteplan {\\n  hotspots {\\n    id\\n    siteplanId\\n    name\\n    x\\n    y\\n    description\\n    thumb\\n    assets {\\n      id\\n      listIndex\\n      src\\n      description\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
					
					lotsArray = jparser.parse(lotPayload).getAsJsonObject().get("data").getAsJsonObject().get("activeSiteplanByCommunityId").getAsJsonObject().get("lots").getAsJsonArray();
					unitsize=String.valueOf(lotsArray.size());
				}
			}
			
			//Reapeat lots sizes
			if(name=="match") {}
			else {unitsize=ALLOW_BLANK;}
			comSec.getAsJsonObject().remove("metaTags");
			comSec.getAsJsonObject().remove("photos");
			comSec.getAsJsonObject().remove("status");
			
			addDetails(comUrl, comSec.toString(), comName, homesArray, plansArray, unitsize);
		}
		

	}

	public void addDetails(String comUrl, String comSec, String comName, JsonArray homesArray, JsonArray plansArray, String unitsize) throws Exception {

//		if (j >=31)
		{

//	 if(!comUrl.contains("https://www.riversidehomebuilders.com/communities/springtown/wellington-addition"))return;
	 U.log(comUrl);
		U.log("Count : " + j);		 
		 if (data.communityUrlExists(comUrl)) {
			 LOGGER.AddCommunityUrl(comUrl+"***********************repeated");
				return;
		 }

		LOGGER.AddCommunityUrl(comUrl);
		String homeUrlKeyword=U.getSectionValue(comSec, ",\"_id\":\"", "\",");

		// ------------------ No. of units ------------------------
		String units=ALLOW_BLANK; String endDt = ALLOW_BLANK; String startDt=ALLOW_BLANK;
			units=unitsize;	
//		
//		
			U.log("Total Units : "+units);
		
		// ------------------ No. of units ------------------------
		U.log("comName=="+comName);
		
		
		// ========================addressec===================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		U.log(comSec);
		String addSec = U.getSectionValue(comSec, "\"model_address\":[{", "}],");
		if(addSec != null) {
			add[0] = U.getSectionValue(addSec, "\"street_address\":\"", "\"");
			add[1] = U.getSectionValue(addSec, "\"city\":\"", "\"");
			add[2] = U.getSectionValue(addSec, "\"state\":\"", "\"");
			add[3] = U.getSectionValue(addSec, "\"postal_code\":\"", "\"");
		}
		if(add[2] != null && add[2].length() > 2) {
			add[2] = add[2].replaceAll("TX - ", "").trim();
			add[2] = USStates.abbr(add[2]);
		}
		else if(add[2] != null && add[2].length() == 2) add[2] = add[2].toUpperCase(); 
		
		
		U.log(Arrays.toString(add));
		
		String latlagsec = Util.match(comSec, "\"geoIndexed\":\\[(-\\d{2}\\.\\d{3,},\\d{2}\\.\\d{3,})\\]", 1);
		U.log(latlagsec);
		if(latlagsec != null) {
			latlng[0] = latlagsec.split(",")[1];
			latlng[1] = latlagsec.split(",")[0];
		}

		if(add[0]==null || add[0]==ALLOW_BLANK || add[2]==null) {
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
		}

		
		U.log(Arrays.toString(latlng));
		U.log(geo);
		

		// ===========================available
		// homes========================================
		
		int availableCount=0;
		String availHomesData = "";
		List<String> findHomes = new ArrayList<>();
		for(JsonElement homeElement : homesArray) {
			if(homeUrlKeyword.equals(homeElement.getAsJsonObject().get("containedIn").getAsString())) {
				availableCount++;
				
//				U.log("prices ::"+homeElement.getAsJsonObject().has("price"));
				if(homeElement.getAsJsonObject().has("price")) {
//					U.log("Status :"+homeElement.getAsJsonObject().get("status").getAsString().equals("Active"));
					if(!homeElement.getAsJsonObject().get("status").getAsString().equals("Active")) {
						homeElement.getAsJsonObject().remove("price");
					}
				}
				
				availHomesData += homeElement.toString();
				findHomes.add(homeElement.toString());
			}
		}
		U.log("Total Available Homes : "+availableCount);
//		U.log(availHomesData);

		U.log("["+String.join(",", findHomes)+"]");
		

		// ========================floorplan
		int planCount=0;
		String planHomesData = "";
		for(JsonElement planElement : plansArray) {
			for(JsonElement commElement : planElement.getAsJsonObject().get("communities").getAsJsonArray()) {
				if(homeUrlKeyword.equals(commElement.getAsJsonObject().get("community").getAsString())) {
					planCount++;
					planHomesData += planElement.toString();
				}
			}
		}
		U.log("Total Plan Homes : "+planCount);
//		U.log("-->"+planHomesData);
		
		// ===============================price============================================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

//		U.log(availHomesData);
		String prices[] = U.getPrices(comSec + availHomesData , "\"price\":\\d{6},".trim(), 0);
		
		
		minPrice = prices[0] == null ? ALLOW_BLANK: prices[0];
		maxPrice = prices[1] == null ? ALLOW_BLANK: prices[1];
		U.log(minPrice+" "+maxPrice);
		
		// ==============================sqft================================================
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;//2,272 square feet 
		String sqft[] = U.getSqareFeet(comSec, ",\"sqftHigh\":\\d{4},|\"sqftLow\":\\d{4},", 0);
		minSqft= sqft[0] == null ? ALLOW_BLANK: sqft[0];
		maxSqft= sqft[1] == null ? ALLOW_BLANK: sqft[1];
		U.log(Arrays.toString(sqft));
		
		// =========================communitytype
		String cType = U.getCommunityType(comSec);

		// ===================propertyType================================
		String pType =  U.getPropType((comSec+availHomesData + planHomesData).replaceAll("Craftsman, Farmhouse,", "Craftsman and Farmhouse style homes").replace("no HOA", ""));
		U.log("pType::::::" + pType);
		// ============================dproptype=================================
		String dType = U.getdCommType((comSec + availHomesData + planHomesData));
		U.log("dType::::::" + dType);
		 
		// =======================propertyStatus===================================

		String pStatus =  U.getPropStatus((comSec).replace("coming_soon_popup", ""));
		U.log("status:::::::" + pStatus);
		
		data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replace("Iii", "III").replace("Ii", "II"));
		data.addNotes(U.getnote(comSec));
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		}
	j++;

	}	

	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
//		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");

	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("referer", "https://myhome.anewgo.com/");
	        connection.setRequestProperty("content-type", "application/json");
	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1NDY2NjY1MSwiZXhwIjoxNjU0NzA5ODUxfQ.cjwVGnbTDD9m1OKPP9kQKwyUORcfUTGHc_UOXJH2MWg");
//	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}	

}
