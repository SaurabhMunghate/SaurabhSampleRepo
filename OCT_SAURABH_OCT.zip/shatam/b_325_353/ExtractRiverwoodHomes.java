package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRiverwoodHomes extends AbstractScrapper {

	String builderUrl="http://www.riverwoodhomes.com/";
	CommunityLogger LOGGER;
	int j=0;
	public ExtractRiverwoodHomes() throws Exception {
		super("Riverwood Homes", "http://www.riverwoodhomes.com/");
		LOGGER = new CommunityLogger("Riverwood Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractRiverwoodHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Riverwood Homes.csv", a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		String regHtml=U.getHTML("http://www.riverwoodhomes.com/communities/");
		String[] regUrls=U.getValues(regHtml, "<a class=\"redbtn\"","/a></p>");
		for(String regUrl:regUrls) {	
			String regName=U.getSectionValue(regUrl, ">", "<");
			regUrl=U.getSectionValue(regUrl, "href=\"", "\"");
			regUrl="http://www.riverwoodhomes.com"+regUrl;
//			U.log("regUrl: "+regUrl+" regName: "+regName);
			String rhtml=U.getHTML(regUrl);
			String[] commUrls=U.getValues(rhtml, "<a class=\"bluebtn\"", "/a></p>");
			for(String cUrl:commUrls) {
				String cName=U.getSectionValue(cUrl, ">", "<");
				cUrl="http://www.riverwoodhomes.com"+U.getSectionValue(cUrl, "href=\"", "\"");
				
//				U.log("cUrl: "+cUrl+"\n CName: "+cName);
				addDetails(cUrl,cName,regName);
				
			}
			
		}
		LOGGER.DisposeLogger();
		
	}

	private void addDetails(String comUrl, String comName,String regName) throws Exception {
		// TODO Execute for single community
//	if(!comUrl.contains("http://www.riverwoodhomes.com/communities/boise__idaho/patagonia/"))return;
		
		
		U.log("count===> "+j);

		// ----------------- Community Url-----------------------
		U.log("communityURL===> "+comUrl);
		String comHtml = U.getHTML(comUrl);
		
		
		// ----------------- Community Name-----------------------
		U.log("comName===> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		/*
		 * For 'Patagonia' Community
		 */
		String avahomes = U.getSectionValue(comHtml,"| <a href=\"/","\">Next</a>");
		String availHomesUrl=avahomes;
		U.log("**** homeURL********"+availHomesUrl);
		String avahomesUrlhtml= null;
		if(availHomesUrl != null) {
			avahomesUrlhtml=U.getHTML(builderUrl+availHomesUrl);
		}
//		U.log("%%%%%%%%%%%"+avahomesUrlhtml);
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] cityState= {ALLOW_BLANK,ALLOW_BLANK};
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				
				String mapURL=U.getSectionValue(comHtml,"<p><iframe height=\"480\" src=\"","\" width=\"100%\"></iframe></p>");
				if(mapURL == null)mapURL=U.getSectionValue(comHtml,"<iframe src=\"","\" width=");
				U.log("****mapURL *********"+mapURL);
				
				if(mapURL != null) {
					String mapHtml = U.getHTML(mapURL);
//					U.lSol Duc Ave, Kennewick, WA 99338, USAog(mapHtml);
					String latlngSec = Util.matchAll(mapHtml, "\\[\\],1,1,\\[\\[null,\\[(\\d{2}\\.\\d{5,},-\\d{3}\\.\\d{5,})\\]\\],", 1).get(1);
					U.log("latlngSec ==="+latlngSec); 
					
					if(latlngSec != null) {
						latLong = latlngSec.split(",");	
					}
				}
				
				if(latLong[0] == ALLOW_BLANK && latLong[1] == ALLOW_BLANK) {
					cityState=regName.split(",");
	//				U.log(Arrays.toString(cityState));
					add[1]=cityState[0];
					add[2]=cityState[1];
					
					if(add[0]==ALLOW_BLANK && add[3]==ALLOW_BLANK) {
						latLong=U.getGoogleLatLngWithKey(add);
						add=U.getGoogleAddressWithKey(latLong);
						geo="true";
						note="Address Taken From City and State";
					}
				}else {
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
				}
				U.log("Address ::"+Arrays.toString(add));
				
				
				U.log("Note========>:::"+note);
				//------------------Floor Plan Data-----------------------
				String[] homeUrlSec = U.getValues(comHtml, "<a class=\"greybtn\" href=\"", "\"");
				
				String homeData = ALLOW_BLANK;
				for(String home : homeUrlSec) {
					
					homeData += U.getSectionValue(U.getHTML("http://www.riverwoodhomes.com/"+home), "<address><span>", " Contact</section></div>");
					
				}
				
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String HomeData=null;
				
				String homeURL=U.getSectionValue(comHtml, "<div class=\"listingsitems n-v1-cols\"", "<div class=\"listingspager lpbottom n-v1-cols\">");
				U.log("HOMEURLSEC1: "+homeURL);
				
				if(homeURL == null) {
					String section[] = U.getValues(comHtml + avahomesUrlhtml, "\"forecolor10 fontstyle4\"", "\">");
					U.log("HOMEURLSEC2: "+section.length);
					for(String sec:section) {
						sec = sec + "\"";
						U.log(sec);
						String secUrl = U.getSectionValue(sec, "href=\"", "\"");
						U.log(secUrl);
						String HomeHtml=U.getHTML("http://www.riverwoodhomes.com/"+ secUrl);
						homeData+=HomeHtml;
					}
				}
						
				if(homeURL!=null) {
				String[] HomeUrls=U.getValues(homeURL, "href=\"", "\">View");
				U.log(HomeUrls.length);
			
			for(String URLs : HomeUrls)
			{
				String HomeHtml=U.getHTML("http://www.riverwoodhomes.com/"+URLs);
				homeData+=HomeHtml;
			}
		}
				
//				U.log(">>>>>>>>"+Util.matchAll(comHtml+homeData, "[\\w\\s\\W]{100}97[\\w\\s\\W]{100}",0));
				
				String[] sqft = U.getSqareFeet(comHtml+homeData+avahomesUrlhtml, "Aprox Sqft: \\d+|<h4><span class=\"item\">\\d{4}</span></h4>|\\d,\\d+ - \\d,\\d+ Sq Ft|\\d,\\d+ Sq Ft|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} Sq Ft", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String price[] = U.getPrices(comHtml+homeData+avahomesUrlhtml, " MID \\$\\d{3},d{3}|\\$\\d{3},\\d{3}", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("minPrice:  " + minPrice + " maxPrice: " + maxPrice);
		
				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				//U.log(homeData);
				homeData = homeData.replace("Multi Gen House", "Multi-Gen Homes");
				propType=U.getPropType((comHtml+homeData));
//				comHtml = comHtml.replace("Boise Ranch and Falcon Crest golf courses", ""); 
				
//				if(comUrl.contains("http://www.riverwoodhomes.com/communities/tri-cities__washington/steeplechase/"))
//						propType = propType + ",Multi-Gen Homes";
				U.log("PType========>:::"+propType);
//				U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeData, "[\\s\\w\\W]{30}custom[\\s\\w\\W]{30}", 0));
				
				//=========== Community Type ========================
				
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType(comHtml+homeData);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
				propStatus=U.getPropStatus(comHtml);
				
				U.log("PStatus========>:::"+propStatus);
				
			
				
 				
				// ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
				data.addUnitCount(ALLOW_BLANK);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				j++;
	
	}

}
