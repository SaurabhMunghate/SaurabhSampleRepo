package com.shatam.b_325_353;

import java.util.Arrays;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRobertThomasHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractRobertThomasHomes() throws Exception {
		super("Robert Thomas Homes", "https://www.robertthomashomes.com/");
		LOGGER = new CommunityLogger("Robert Thomas Homes");
	}

	@Override
	protected void innerProcess() throws Exception {

		String regHtml=U.getHTML("https://www.robertthomashomes.com/beautiful-communities/");
		regHtml = regHtml.replaceAll("</a>\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "endSec");
		String[] comSecs=U.getValues(regHtml, "<div class=\"wpb_raw_code wpb_content_element wpb_raw_html\" >", "endSec");
			for(String comSec:comSecs) {
	//			U.log(comSec);
				String commName="";
				String comurl=U.getSectionValue(comSec, "<a href=\"", "\"");
				commName=U.getSectionValue(comSec, "<h3 class=\"tilecontent-title\" style=\"text-align: center;\">", "</h3>");
				U.log(comurl+" name: "+commName);
			
				addDetails(comurl,commName,comSec);
	//			break;
			}
		
		LOGGER.DisposeLogger();

	}

	int j=0;
	private void addDetails(String comUrl, String comName, String comSec) throws Exception {
		// TODO Execute for single community
	//	if(!comUrl.contains("https://www.robertthomashomes.com/beautiful-communities/huntersbrook/"))return;
	//	if(j>=5)
		{
		U.log("Count: "+j);
		// ----------------- Community Url-----------------------
		U.log("communityURL=====> "+comUrl);
//		if(comUrl.contains("beautiful-communities/huntersbrook"))return;
		String comHtml = U.getHTML(comUrl);
		
		// ----------------- Community Name-----------------------
		U.log("comName=====> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				String mapStatus="";
				String addHtml=U.getHTML("https://www.robertthomashomes.com/wp-json/wpgmza/v1/features/base64eJyrVkrLzClJLVKyUqqOUcpNLIjPTIlRsopRMoxR0gEJFGeUFni6FAPFomOBAsmlxSX5uW6ZqTkpELFapVoABU0Wug");
				addHtml=addHtml.replace("{\"filter\":{\"map_id\":\"1\"", "");
				String[] addSecs=U.getValues(addHtml, "\"map_id\"", "categories\":[\"");
				for(String addSec:addSecs) {
					
					addSec= StringEscapeUtils.unescapeJava(addSec);
//					U.log(">>> "+addSec);
					if(addSec.contains(comUrl)) {
						if(comUrl.contains("https://www.robertthomashomes.com/beautiful-communities/westin-ridge/")) {
							String addresecsHtml=U.getHTML("https://www.robertthomashomes.com/wp-json/wpgmza/v1/features/base64eJyrVkrLzClJLVKyUqqOUcpNLIjPTIlRsopRMjSwjFHSAQkVZ5QWeLoUA0WjY4ECyaXFJfm5bpmpOSkQsVqlWgAn+Bcj");
							addSec=addresecsHtml;
							addSec= StringEscapeUtils.unescapeJava(addSec);
//							addSec=addSec.replace("3F7H MW Plymouth", "3F7H MW, Plymouth");
						}
						mapStatus=addSec;
//						U.log(">>> "+addSec);
						String address=U.getSectionValue(addSec, "address\":\"", "\"");
						address=address.replace("42R5+3J Hugo", "42R5 3J, Hugo").replaceAll("\\+", " ").replace("3F7H MW Plymouth", "3F7H MW, Plymouth");
//						U.log(address);
						add=U.getAddress(address);
						String latLongSec=U.getSectionValue(addSec, "/@", "/data=");
						if(latLongSec==null) {
							
							latLong[0]=Util.match(addSec, "\\d{2,3}.\\d{5,}");
							latLong[1]=Util.match(addSec, "-\\d{2,3}.\\d{5,}");
							
						}else {
						latLong[0]=Util.match(latLongSec, "\\d{2,3}.\\d{5,}");
						latLong[1]=Util.match(latLongSec, "-\\d{2,3}.\\d{5,}");
						}
//						U.log("Latlong ::"+Arrays.toString(latLong));
					}
				}
				if((add[3]==null||add[3]==ALLOW_BLANK)&&latLong[0]!=ALLOW_BLANK) {
					add=U.getGoogleAddressWithKey(latLong);
					geo="True";
				}
				U.log("Address ::"+Arrays.toString(add));
				U.log("Latlong ::"+Arrays.toString(latLong));
				if(latLong[0].length()<5) {
					String latlongData=U.getPageSource("https://www.robertthomashomes.com/wp-json/wpgmza/v1/features/base64eJyrVkrLzClJLVKyUqqOUcpNLIjPTIlRsopRMjSxiFHSAQkVZ5QWeLoUA0WjY4ECyaXFJfm5bpmpOSkQsVqlWgAofRcm");
					String latlngSec=U.getSectionValue(latlongData, "\"markers\":[", "}],");
//					U.log("name=="+latlngSec);

					String[] Data=U.getValues(latlngSec, "map_id\":\"", "\"custom_fields_html");
//					U.log("name=="+Data.length);
					for(String temp : Data) {
//						String name=U.getSectionValue(temp, "\"title\":\"", "\",");
//						U.log("name=="+name);
						if(temp.contains(comName)) {
//							U.log("temp==="+temp);
							latLong[0]=U.getSectionValue(temp, "\"lat\":\"", "\",");
							latLong[1]=U.getSectionValue(temp, "\"lng\":\"", "\",");

						}
					}
				}
				U.log("Latlong ::"+Arrays.toString(latLong));
				if((latLong[0]!=null || latLong[0].length()<5) && (add[0]==null ||add[0].length()<5) ) {
//					if((add[3]==null||add[3]==ALLOW_BLANK)&&latLong[0]!=ALLOW_BLANK) {
						add=U.getGoogleAddressWithKey(latLong);
						geo="True";
//					}
				}
		
//				if(comUrl.contains("/beautiful-communities/huntersbrook/")) {
//					add[1]="Victoria";
//					add[0]="MN";
//					latLong = U.getlatlongGoogleApi(add);
//					add = U.getAddressHereApi(latLong);
//					geo="True";
//					note="Address and LatLng Taken from City & State";
//				}
//				if(comUrl.contains("/beautiful-communities/wildflower-at-lake-elmo/")) {
//					add[1]="Lake Elmo";
//					add[0]="MN";
//					latLong = U.getlatlongGoogleApi(add);
//					add = U.getAddressHereApi(latLong);
//					geo="True";
//					note="Address and LatLng Taken from City & State";
//				}
//				U.log("Note========>:::"+note);
				//bcz add present in json bt not on web page
				if(comUrl.contains("https://www.robertthomashomes.com/beautiful-communities/the-harvest/")||comUrl.contains("https://www.robertthomashomes.com/beautiful-communities/spirit-of-brandtjen-farm/")) {
					geo="true";
				}
				//------------------Available Home Data-----------------------
				
				String homeData="";
				String homeSec="";
				String CollSec="";
				String[] homeUrls= {};
			//	if(!comUrl.contains("https://www.robertthomashomes.com/beautiful-communities/pike-lake-landing/")) {
					String floorplanUrl=U.getSectionValue(comHtml, "About</span></a><a href=\"", "\"");
					U.log("FUrl: "+floorplanUrl);
					if(floorplanUrl!=null) {
					String floorHtml=U.getHTML(floorplanUrl);
					//homeSec=U.getSectionValue(floorHtml, ">Choose Floorplan Collection:</span>", "</div></div></div></div></div></div></div></div></div></div></div><div class=\"vc_section show-at-mm-breakpoint\">");
					homeUrls=U.getValues(floorHtml, "<div class=\"homeCollection\">", "r\">View Details</span>");
					int c=0;
					for(String homeCollSec:homeUrls) {
//						c++;
//						U.log(c+"== "+homeCollSec);
						CollSec+=homeCollSec;
						String homeUrl=U.getSectionValue(homeCollSec, "<a href=\"", "\"");
					//	U.log(c+"== "+homeUrl);
						String home=U.getHTML(homeUrl);
						c++;
						homeData+=U.getSectionValue(home, "div class=\"homeCollection\">", "<div class=\"post-pagination-wrap wpe");
						//U.log(homeData);
					}
					}
				//}
//					
				String quickUrl="";
				String quikHtml="";
				
				int myQuickCount=0;
				String quickHomes[] = {};
				String availableLater[] = {};
				if(comHtml.contains("<span>Quick Move-in Homes</span>")) {
					quickUrl=U.getSectionValue(comHtml, "Models</span></a><a href=\"", "\"");
					if(quickUrl==null)
					quickUrl=U.getSectionValue(comHtml, "Model Homes</span></a><a href=\"", "\"");

					U.log("quickUrl=="+quickUrl);
					quikHtml=U.getHTML(quickUrl);
					quickHomes = U.getValues(quikHtml, "<div class=\"homeCollection\">", "\">View Details</span>");
					
					myQuickCount=quickHomes.length;
					
					availableLater = U.getValues(quikHtml, "<h2 class=\"overlaymessage\">", "<");
					CollSec+=quikHtml;
				}
				//U.log(quickHomes.length+"LLLLLLLL"+availableLater.length);
				String showcasemodalhtm =ALLOW_BLANK;
				String showcaseurl = U.getSectionValue(comHtml, "Available Floorplans</span></a>", "<span>Showcase Model");
				if(showcaseurl !=null) { showcaseurl =U.getSectionValue(showcaseurl, "<a href=\"", "\"");
				showcasemodalhtm = U.getHTML(showcaseurl);
				}
				if(showcasemodalhtm!=null)showcasemodalhtm=showcasemodalhtm.replaceAll("<div class=\"homePriceStrikethrough\">\\$\\d{3},\\d{3}</div>", "");
				
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				comHtml=comHtml.replace("* Sq. Ft.", " Sq. Ft.");
				String[] sqft = U.getSqareFeet((comHtml+CollSec+showcasemodalhtm+homeData).replace("* Sq. Ft.", " Sq. Ft."),	"\\d,\\d{3} -\\d,\\d{3} Sq. Ft.|\\d,\\d{3} Sq. Ft.|\\d,\\d{3} -\\d,\\d{3}\\* Sq\\. Ft\\.|\\d,\\d{3}-\\d,\\d{3}\\* Sq. Ft.|>\\d,\\d{3} Sq. Ft.<", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}2,849[\\w\\s\\W]{30}", 0));
//				U.log(Util.matchAll(CollSec, "[\\w\\s\\W]{30}2,849[\\w\\s\\W]{30}", 0));
//				U.log(Util.matchAll(showcasemodalhtm, "[\\w\\s\\W]{30}2,849[\\w\\s\\W]{30}", 0));
//				U.log(Util.matchAll(homeData, "[\\w\\s\\W]{30}2,849[\\w\\s\\W]{30}", 0));
                if(comUrl.contains("https://www.robertthomashomes.com/beautiful-communities/pike-lake-landing/")) {
                	minSqft="1981";
                }
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//				comHtml=comHtml.replace("low as the mid $300’s.", "low as the mid $300,000").replace("Starting in the low $300’s", "Starting in the low $300,000");
				String price[] = U.getPrices(comHtml+CollSec+comSec+showcasemodalhtm, "\\$\\d,\\d{3},\\d{3}|starts at \\$\\d{3},\\d{3}<|>\\$\\d{3},\\d{3}</div>|>\\$\\d{3},\\d{3}</span>", 0);  //|Starting From \\$\\d{3},\\d{3}
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
//				
				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				propType=U.getPropType((comHtml+homeData).replaceAll("multi-generational parks|Chinese \\(Traditional\\)|chinese-traditional|\"Enclave at Elm Creek Villas|= ENCLAVE AT ELM CREEK VILLAS =|/* Enclave at Elm Creek Villas|Village", ""));

				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
//				comHtml=comHtml.replace("", "");
				comHtml=U.getSectionValue(comHtml, "label=\"Main menu\">", "<p class=\"newHomeConsultantEmail\">");
				commType = U.getCommType(comHtml);
//				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}Country Club[\\w\\s\\W]{30}", 0));
//				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}Golf Course[\\w\\s\\W]{30}", 0));

				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType((comHtml+homeData+CollSec).replaceAll("inspired rambler features|\".*\"|Branch", ""));
				U.log("dpppp"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}rambler[\\w\\s\\W]{100}", 0));
				U.log("dpppp"+Util.matchAll(homeData, "[\\w\\s\\W]{100}rambler[\\w\\s\\W]{100}", 0));
				U.log("dpppp"+Util.matchAll(CollSec, "[\\w\\s\\W]{30}rambler[\\w\\s\\W]{30}", 0));
				U.log("PdrvType========>:::"+drvPropType);
				
//				comHtml=comHtml.replace("wooded-view home sites available", "wooded home sites available");
				
				//====================================Property Status ======================================
				if(comHtml.contains("<span>Quick Move-in Homes</span>")) {
//					String quickUrl=U.getSectionValue(comHtml, "Homes</span></a><a href=\"", "\"");
//					String quikHtml=U.getHTML(quickUrl);
					comHtml = comHtml.replaceAll("Interchange is now open", "");
					if(quikHtml.contains("<div class=\"homePlan\">") && quickHomes.length>availableLater.length) {
						propStatus=U.getPropStatus((comHtml+mapStatus+comSec).replaceAll("<strong>NOW OPEN!</br>Heritage", "").replace("change is now open", ""));
					}
					else {
						U.log("============");
						comHtml=comHtml.replaceAll("<span>Quick Move-in Homes</span>|<strong>NOW OPEN!</br>Heritage Collection|Chaska, MN &#8211; Quick Move-In Homes\" |Quick Move-in Homes|Interchange is now open", ""); 
						propStatus=U.getPropStatus((comHtml+mapStatus+comSec).replace("<strong>NOW OPEN!</br>Heritage ", ""));
					}
				}
				else {
				comHtml=comHtml.replaceAll("<span>Quick Move-in Homes</span>|<strong>NOW OPEN!</br>Heritage Collection|Interchange is now open|Quick Move-in Homes", ""); 
				propStatus=U.getPropStatus((comHtml+mapStatus).replace("<strong>NOW OPEN!</br>Heritage ", ""));
				}
				U.log(Util.matchAll(comHtml+mapStatus+comSec, "[\\w\\s\\W]{30}Now Open[\\w\\s\\W]{30}", 0));

				//in Address street is not proper
				if(comUrl.contains("/highcroft-of-woodbury/")) {
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
				}
//				U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{70}Coming January 2022[\\w\\s\\W]{70}", 0));
//				U.log(Util.matchAll(mapStatus, "[\\w\\s\\W]{70}Coming January 2022[\\w\\s\\W]{70}", 0));
//				U.log(Util.matchAll(comSec, "[\\w\\s\\W]{70}Coming January 2022[\\w\\s\\W]{70}", 0));

//				propStatus=propStatus.replace("Home Sites Available", "Wooded Home Sites Available");
				U.log("PStatus========>:::"+propStatus);
				//if(comUrl.contains("the-harvest/"))add[0]="4315 Millstone Dr";
				if(comUrl.contains("spirit-of-brandtjen-farm")) {
					add[0]="16972 Brandtjen Farm Dr";
					latLong[0]="44.7121543"; 
					latLong[1]="-93.1611368";
				}
				if(comUrl.contains("/westin-ridge")) {
					add[0]="5990 Alvarado Lane North";
					geo="False";
					propStatus="Sold Out";
				}
				
				String quickHtml=U.getHTML("https://www.robertthomashomes.com/quick-move-in-homes/");
				String [] quickData=U.getValues(quickHtml, "<div class=\"homeCollection\">", "</div></div></div></div>\n" + 
						"\n" + 
						"	\n" + 
						"	\n" + 
						"	\n" + 
						"	\n" + 
						"</div>\n" + 
						"\n" + 
						"\n" + 
						"		</div>\n" + 
						"	</div>");
				int count=0;
				U.log("quickData.length>>>>>>>"+quickData.length);
				for(String quick : quickData) {
					String name=comName.replace(" ", "_");
					U.log("name=="+name);
					if(quick.contains(name)) {
						count++;
					}
				}
				U.log("Count=="+count);
				if(count>0||myQuickCount>0) {
					if(propStatus.length()>3) {
						propStatus+=", Quick Move-in Homes";
					}
					else
						propStatus="Quick Move-in Homes";
				}
			//	if(comUrl.contains("pike-lake-landing/"))propStatus=propStatus.replace("Coming January 2022, ", "");

				// ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);	
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);
				
		}
	j++;	
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractRobertThomasHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Robert Thomas Homes.csv", a.data().printAll());
	}

}
