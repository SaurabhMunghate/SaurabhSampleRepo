package com.shatam.b_325_353;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSilverstoneCommunities extends AbstractScrapper {
	CommunityLogger LOGGER;

	static int j = 0;

	public ExtractSilverstoneCommunities() throws Exception {

		super("Silverstone Communities", "https://www.silverstonenewhomes.com/");
		LOGGER = new CommunityLogger("Silverstone Communities");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractSilverstoneCommunities();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Silverstone Communities.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {

		String mainHtml = U.getHTML("https://www.silverstonenewhomes.com/communities/");
		//mainHtml=mainHtml.replace("grid-100 tablet-grid-100 mobile-grid-100 grid-parent communities_list_single comm_list_block list_sort_single", "startendgrid-100 tablet-grid-100 mobile-grid-100 grid-parent communities_list_single comm_list_block list_sort_single");
		String comSections[] = U.getValues(mainHtml, "grid-parent communities_list_single comm_list_block list_sort_single",
				"<div class=\"grid-100 tablet-grid-100 mobile-grid-100");
		 U.log(comSections.length);
		for (String comSec : comSections) {
			//U.log(comSec);
			addDetails(comSec);
		}
		

		LOGGER.DisposeLogger();
	}

	public void addDetails(String comSec) throws Exception {

		//U.log(comSec);

		
		
		String comUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
	//	U.log(comUrl);
//	if(!comUrl.contains("https://www.silverstonenewhomes.com/new-homes/conyers/ginger-lake-estates/"))return;
		
		LOGGER.AddCommunityUrl(comUrl);
		
//	if(comUrl.contains("https://www.silverstonenewhomes.com/new-homes/conyers/harvest-mill/")) {
//		
//		LOGGER.AddCommunityUrl("======= Return No Data ========"+comUrl);
//		return;
//	}
		

		
		String comName=U.getSectionValue(comSec, "data-name=\"", "\"");
		U.log(comName);
		
//		if(comUrl.contains("village-crossing") && comName==null) {
//			LOGGER.AddCommunityUrl(comUrl+"================repeated");return;
//		}
		
		
		
		String comHtml=U.getHTML(comUrl);
		//=========================addresssec===========================================
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String addressSec=U.getSectionValue(comHtml, "<b>Sales Office Location:</b>", "https://maps");

		//String addSec=U.getSectionValue(addressSec, "<p>", "</p>").trim();
	//	U.log(addressSec);
		if(addressSec!=null) {
		add[0]=U.getSectionValue(addressSec, "<p>", "<br>");
		
		if(add[0]!=null)
			add[0] = add[0].replace(" ", "").trim();
		add[1]=U.getSectionValue(addressSec, "<br>", ",");
		String adSec=U.getSectionValue(addressSec, ",", "<br>");
		
	//	U.log(adSec);
		add[2]=U.getSectionValue(adSec, " ", " ");
		add[3]=Util.match(adSec, "\\d{5}");
		
		}
		latlag[0]=U.getSectionValue(comSec, "data-lat=\"", "\"");
		latlag[1]=U.getSectionValue(comSec, "data-long=\"", "\"");
		
	//	add=U.getAddressGoogleApi(latlag);
	if(add[0]==null || add[0].length()==0) {
		
		add=U.getAddressGoogleApi(latlag);
		geo="TRUE";
		
	}
		
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		
		//======================floorplans============
		String floorplanData ="";
		String floorUrls[] = U.getValues(comHtml, "<div class=\"grid-33 tablet-grid-50 mobile-grid-100 primary_card_single_wrapper\">", "Explore Plan</a>");
		for(String s:floorUrls) {
		//	U.log(s);
			String floorurl =U.getSectionValue(s, "<a href=\"", "\"");
			U.log("floorurl=="+floorurl);
			String floorHtm = U.getHTML(floorurl);
			floorplanData +=floorHtm;
//			if(floorplanData.contains("367,990")) {
//				U.log("FOUND");
//			}
		}

		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
	      comHtml = comHtml.replace("Beautiful basement homes in East Paulding from$302,390. The Summit at West Ridge", "").replace(" $208,990. Swimming Pool,", "").replace("0s", "0,000").replace("0's", "0,000").replaceAll("0s|0'S", "0,000").replace("Mid 200,000", "Mid $200,000");
	      comSec=comSec.replace("0's", "0,000").replaceAll("0s|0'S", "0,000");
	    //  U.log(Util.matchAll(comSec+comHtml+floorplanData, "[\\w\\s\\W]{30}367,990[\\w\\s\\W]{30}", 0));
			prices=U.getPrices((comSec+comHtml+floorplanData), "\\$\\d{3},\\d{3}", 0);
		//	U.log(comSec);

//			U.log(Util.matchAll(floorplanData, "[\\w\\s\\W]{30}367,990[\\w\\s\\W]{30}", 0));

			U.log(Arrays.toString(prices));
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(comSec+comHtml+floorplanData, "\\d,\\d{3} to over \\d,\\d{3} square feet|<b>\\d{4}</b><p>Sq Ft", 0);
			
			U.log(Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comSec+comHtml.replace("swim community features", ""));
			U.log(cType);
			String detailSec = U.getSectionValue(comHtml, "<h4 class=\"tertiary_color\">Community Details</h4>", "</div");
			
			String pType=ALLOW_BLANK;
			comSec = comSec.replaceAll("<div class=\"list_type\">\n\\s*<p>Duplex</p>\n\\s*</div>", "<div class=\"list_type\"><p>Duplex Homes</p></div>");
			pType = U.getPropType((comSec+comHtml+floorplanData)
					.replace("community has estate-size lots", "community has estate style lots")
					.replace("Luxury Vinyl Plank", "luxury home").replaceAll("Only two homes remain\\. This prestigious|Kings Lake Townhomes|Village|village|Villa Rica", ""));
//			U.log(Util.matchAll(comSec+comHtml+floorplanData, "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}", 0));
			U.log("pType::::::" + pType);
//			U.log("comSec::::::" + comSec);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			
			dType = U.getdCommType(comSec+floorplanData+detailSec);
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;
			String removeDescSec = U.getSectionValue(comHtml, "lass=\"yoast-schema-graph\">{\"@context\"", "</script>");
			comHtml = comHtml.replace(removeDescSec, "");
			comHtml=comHtml.replaceAll("New phase coming Fall 2021", "").replace("Only 7 lots remain in Phase II", "Only 7 lots remain Phase II");
			pStatus = U.getPropStatus((comHtml+ comSec).replaceAll("Basements coming soon|content=\".*\" />|Final Opportunities. Silverstone|Village Only 5 homesites remain", ""));
		//	U.log(Util.matchAll(comSec+comHtml+floorplanData, "[\\w\\s\\W]{30}selling now[\\w\\s\\W]{30}", 0));
			U.log("status:::::::" + pStatus);

			
//			if(comUrl.contains("https://www.silverstonenewhomes.com/new-homes/covington/the-preakness"))prices[0]="$400,000";
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			if(pStatus.contains("Quick Move-in") && !pStatus.contains("in Homes")) {
				pStatus=pStatus.replace("Quick Move-in", "Quick Move-in Homes");
			}
			if(add[0]==ALLOW_BLANK || add[0]==null) {
				add=U.getAddressGoogleApi(latlag);
				geo="TRUE";
			}
			if(comName.contains("Village"))pType = pType.replaceAll("Villas,|, Villas", "");
			if(data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl+"==============repeated");
				return;
			}
//			if(comUrl.contains("/new-homes/conyers/harvest-mill/"))pStatus = "Final Opportunities Now Selling";
			
			String lotCount=ALLOW_BLANK;

			if(comHtml.contains("<h2>Site Plan</h2>"))
			{
				String lotData[]=U.getValues(comHtml,"<div class=\"siteplan_point status", ">");
				U.log("lotData:::::::" + lotData.length);
				if(lotData.length>0) {
					lotCount=Integer.toString(lotData.length);
				}
			}
			
			
			
			data.addCommunity(comName, comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replaceAll(",", "").trim(), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus.replace("Ii", "II").replace("Only One More Opportunity", "Only One More Opportunity Remaining").replace("Final Opportunities Now Selling, Now Selling", "Final Opportunities Now Selling"));
			data.addNotes(U.getnote(comHtml));
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
			
				
		
		
		
//		U.log("====================="+j);
		j++;
	}
}