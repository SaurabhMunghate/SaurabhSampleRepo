package com.shatam.utils;

import java.io.IOException;
import java.util.ArrayList;

public class GetLink {
	public ArrayList<String> getUrl(String html, String st1, String st2) {

		int start = 0, end;

		ArrayList<String> arl = new ArrayList<String>();

		while (true) {
			start = html.indexOf(st1, start);
			if (start == -1)
				break;
			end = html.indexOf(st2, start + 6);
			arl.add(html.substring(start + 6, end));
			start = end;
		}

		return arl;

	}

	public ArrayList<String> getUrl(String html, String begin, String st1,
			String st2) {

		int start, end;
		start = html.indexOf(begin, 0);
		ArrayList<String> arl = new ArrayList<String>();

		while (true) {
			start = html.indexOf(st1, start);
			if (start == -1)
				break;
			end = html.indexOf(st2, start + 6);
			arl.add(html.substring(start + 6, end));
			start = end;
		}

		return arl;

	}

	public ArrayList<String> getUrl1(String html, String s1, String s2,
			String s3) {

		ArrayList<String> arl = new ArrayList<String>();
		int start = 0, end;

		while (true) {
			start = html.indexOf(s1, start);
			if (start == -1) {
				break;
			}
			start = html.indexOf(s2, start);
			end = html.indexOf(s3, start + 9);
			arl.add(html.substring(start + 9, end));
			start = end;
		}

		return arl;
	}

	public ArrayList<String> getUrl1(String html, String s4, String s1,
			String s2, String s3) {

		ArrayList<String> arl = new ArrayList<String>();
		int start = 0, end;

		while (true) {
			start = html.indexOf(s4, start);
			if (start == -1) {
				break;
			}
			start = html.indexOf(s1, start);
			if (start == -1) {
				break;
			}
			start = html.indexOf(s2, start);
			end = html.indexOf(s3, start + 9);
			arl.add(html.substring(start + 9, end));
			start = end;
		}

		return arl;
	}

	public static boolean containNumber(String str) {

		for (int i = 0; i < str.length(); i++) {
			if (Character.isDigit(str.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	public static String getNumber(String str) {
		str = str + " ";
		String val = null;
		for (int i = 0; i < str.length(); i++) {
			if (Character.isDigit(str.charAt(i))) {
				while (Character.isDigit(str.charAt(i)) || str.charAt(i) == ',') {
					if (val != null)
						val = val + Character.toString(str.charAt(i));
					else
						val = Character.toString(str.charAt(i));
					i++;
				}
				return val;
			}
		}
		return val;

	}

	public static String[] getMaxMin(ArrayList<String> arl) {
		int max = 0, min;
		int val;
		String[] maxMin = new String[2];
		for (String str : arl) {
			if (str.contains("$"))
				str = str.replace("$", "");
			if (str.contains(","))
				str = str.replace(",", "");
			val = Integer.parseInt(str);
			if (val > max) {
				max = val;
			}
		}
		min = max;
		for (String str : arl) {
			if (str.contains("$"))
				str = str.replace("$", "");
			if (str.contains(","))
				str = str.replace(",", "");
			val = Integer.parseInt(str);
			if (min > val) {
				min = val;
			}
			maxMin[0] = Integer.toString(min);
			maxMin[1] = Integer.toString(max);
		}

		return maxMin;
	}

	public static String inPriceFormat(String price) {
		if (price.length() < 4) {
			price = "$" + price + ",000";
		} else {
			String end = price.substring(price.length() - 3);
			String start = price.substring(0, price.length() - 3);
			

			if (start.length() >= 4) {

				String end1 = start.substring(start.length() - 3);
				start = start.substring(0, start.length() - 3);
				price = "$" + start + "," + end1 + "," + end;

			} else {

				price = "$" + start + "," + end;

			}
		}
		return price;
	}

	public static String[] googleAddress(String completeAddress) {
		// ['6471-6499 Sullins Rd','Charlotte, NC 28214'
		U.log(completeAddress);
		String[] str = new String[4];
		str[0] = U.getSectionValue(completeAddress, "['", "'").replaceAll(
				"\\\\x26", "&");
		str[1] = U.getSectionValue(completeAddress, ",'", ",");
		String state = completeAddress.substring(
				completeAddress.lastIndexOf(",") + 1).trim();
		str[3] = GetLink.getNumber(state);
		str[2] = Util.match(state, "[A-Z][A-Z]");

		return str;
	}

	public static String[] getLatLng(String latLng) {

		String[] str = new String[2];
		str[0] = Util.match(latLng, "[0-9]{2}.[0-9]{1,6}");
		str[1] = Util.match(latLng, "-[0-9]{2,3}.[0-9]{1,6}");
		return str;
	}

	public static String[] getAreas(String areas) {

		String[] str = new String[2];
		if (areas.contains(" to"))
			str = areas.split(" to");
		if (areas.contains(" -"))
			str = areas.split(" -");

		str[0] = Util.match(str[0], "[0-9]{3,4}");
		str[1] = Util.match(str[1], "[0-9]{3,4}");

		return str;
	}

	public static ArrayList<String> getNumberList(ArrayList<String> arlist) {
		String temp;
		for (int i = 0; i < arlist.size(); i++) {
			temp = GetLink.getNumber(arlist.get(i)).replaceAll(",", "");
			arlist.remove(i);
			arlist.add(i, temp);
		}
		return arlist;
	}

	public static String[] getAddress1(String completeAddress) {
		// Example :972 Shaddock Park Lane <br />
		// Allen, Texas 75013<br />
		String[] address = new String[4];
		address[0] = null;
		address[1] = null;
		address[2] = null;
		address[3] = null;
		address[0] = completeAddress.substring(0, completeAddress.indexOf("<"))
				.trim();
		String temp = completeAddress.substring(
				completeAddress.indexOf(">") + 1).trim();

		address[1] = temp.substring(0, temp.indexOf(","));
		address[2] = U.getSectionValue(temp, ", ", " ").trim();

		if (address[2].length() > 2) {
			address[2] = USStates.abbr(address[2]);
		}
		address[3] = GetLink.getNumber(temp);
		return address;
	}

	public static String[] getGoogleAddrLatLng(String completeAddress1)
			throws IOException {
		// completeAddress1 : 23290 Evening Primrose Square, Ashburn, VA
		String[] addrLatLng = new String[6];
		String[] address = new String[4];
		String completeAddress = completeAddress1.replaceAll(" ", "+");
		completeAddress = "http://maps.google.com/maps?daddr="
				+ completeAddress;
		U.log(completeAddress);
		String adrHtml = U.getHTML(completeAddress);

		String compAddress = U.getSectionValue(adrHtml, "addressLines:", "],");
		// compAddress = compAddress.replaceAll("\\\\x27", "'");
		U.log("compAddress:" + compAddress);

		if (compAddress == null) {
			address = U.getAddress(completeAddress1);
			addrLatLng[4] = "-";
			addrLatLng[5] = "-";
		} else {
			// U.log(compAddress);
			address = GetLink.googleAddress(compAddress);
			U.log(address[0]);
			U.log(address[1]);
			U.log(address[2]);
			U.log(address[3]);
			String lat = U.getSectionValue(adrHtml, "{center:{lat:", ",");
			String lng = U.getSectionValue(adrHtml, ",lng:", "}");
			addrLatLng[4] = lat;
			addrLatLng[5] = lng;
		}
		addrLatLng[0] = address[0];
		addrLatLng[0] = addrLatLng[0].replaceAll("\\\\x26", "&");
		addrLatLng[1] = address[1];
		addrLatLng[2] = address[2];
		addrLatLng[3] = address[3];
		// U.log("START");
		// U.log(addrLatLng[0]);U.log(addrLatLng[1]);U.log(addrLatLng[2]);U.log(addrLatLng[3]);

		return addrLatLng;
	}

	public static String[] getStreetStateCity(String sec) throws IOException {
		String addr[] = { "", "", "" };
		String ad[] = sec.split(",");
		addr[0] = ad[0];
		ad = ad[1].trim().split(" ");
		addr[1] = ad[0].trim();
		addr[2] = ad[1];
		if (addr[1].length() > 2)
			addr[1] = USStates.abbr(addr[1]);

		return addr;

	}

	public static String[] getAddrLatLngLink(String gLink) throws IOException {

		String[] addrLatLng = new String[6];
		String[] address = new String[4];
		gLink = gLink.replaceAll("amp;", "");
		String adrHtml = U.getHTML(gLink);

		String compAddress = U.getSectionValue(adrHtml, "addressLines:", "],");

		// U.log(compAddress);
		if (compAddress != null) {
			address = GetLink.googleAddress(compAddress);
			// U.log(address[0]);U.log(address[1]);U.log(address[2]);U.log(address[3]);
			String lat = U.getSectionValue(adrHtml, "{center:{lat:", ",");
			String lng = U.getSectionValue(adrHtml, ",lng:", "}");
			addrLatLng[4] = lat;
			addrLatLng[5] = lng;

			addrLatLng[0] = U.getSectionValue(adrHtml,
					"jsprops=\"label:'A'\"><span>", "</");// pp-place-title"><span>
			if (addrLatLng[0] == null)
				addrLatLng[0] = U.getSectionValue(adrHtml, "laddr:'", ",");

			addrLatLng[0] = addrLatLng[0].replaceAll("\\\\x26", "&");
			addrLatLng[1] = U.getSectionValue(compAddress, "['", ",");
			addrLatLng[2] = address[2];
			addrLatLng[3] = address[3];
			// U.log(addrLatLng[0]);U.log(addrLatLng[1]);U.log(addrLatLng[2]);U.log(addrLatLng[3]);
		} else {
			addrLatLng[0] = "-";
			addrLatLng[1] = "-";
			addrLatLng[2] = "-";
			addrLatLng[3] = "-";
			addrLatLng[4] = "-";
			addrLatLng[5] = "-";
		}

		return addrLatLng;
	}
}
