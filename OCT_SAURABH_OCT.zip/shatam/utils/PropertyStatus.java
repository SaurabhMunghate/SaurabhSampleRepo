package com.shatam.utils;

import java.util.ArrayList;

public abstract class PropertyStatus {

	public static final String propStatusIgnore = "Models Opening Spring|New Floorplans Just Released|NEW PLANS COMING SOON|NEW MODEL COMING SOON|Model Homes Coming Soon|Model(s)? opening soon|Model Coming Fall 202\\d+|Model home now selling|Final homes for sale|Model Home Now Open|Model Home now available|Model Homes Now Available|Models coming this summer|Pricing Now Available|Appointments now available|Final Balance Home Now Available|floorplan[s]* is now available|Floorplans–Now Available|Amenity Site Coming Soon|[P|p]ricing\\s*[is]*\\s*[N|n]ow [A|a]vailable|Community Garden Coming Soon|Clubhouse coming soon|Coming Soon: On-site Community|Price Coming Soon|Now Open - Two new model|Pickleball Courts coming soon|Amenity expansion coming soon|Coming Soon - Amenity|Coming Soon - Clubhouse|New Flats Coming Soon|design[s]* now available|Model Home is Now Available|Site Plan Now Available|model home coming soon|Model Home, now OPEN|tot lot coming soon|New Model\\s*Coming Soon|pre-selling out |Model home is now selling|model home now available|model is now available|model home is COMING SOON|model home is coming soon|New Floor Plans Just Released|now open for leasing|Now Open For Presales|Models Now Selling|Grand Opening Pricing|ONE HOME REMAINING \\(MODEL\\)|model residences now selling|New floor plans were just released|NOW OPEN - NEW MODEL|Floor Plan Coming Soon|#\">Coming Soon</a></li>|Model Home now available for purchase|Pre-Grand Opening|Preselling Now|Preselling Now|New Model - Now Selling|Pre-Selling Now|Model Home coming |MODELS NOW OPEN|More Info Coming Soon|Model[s]* Now Available|Models now available!|New Model Complex Now Open|Final Phase Now Preselling|join us for our Grand Opening|Center - now open|MODEL NOW OPEN|Grand Opening Prices|Model NOW Open|Model Coming Soon|Plan sold out|model homes are now open|Model Homes Now Selling|Model Opening Soon|New Mode\\s*Coming Soon|school currently under construction|Grand Opening Icon|Model Home Opening Soon|Now Open Image|<!-- Quick Move-Ins -->|MODEL NOW OPEN|AREA INFORMATION COMING SOON|Price is coming soon|Sales Center Now Open|Model Home COMING SOON|Model Home Coming Soon|walking trails coming soon|Close-Out Special|Coming Soon</a> |Park Coming Soon|Models coming soon|Home Coming Soon|Model Coming Soon|Office Now Open|Home Under Construction|Model Homes Now Open|Homes Opening Soon|homes are under construction|are currently under construction|pool coming soon|home is now open|model is now open|Model Grand Opening|Home Grand Opening|Model now under construction|Clubhouse Now Open|homes under construction|Clubhouse NOW OPEN|MODEL HOME NOW OPEN|Price Is Coming Soon|Area Now Open|Lot - Now Open|Amenities coming|Park is Now Open|Final Home Sites Released for Sale";
	
	public static ArrayList<String> propStatus = new ArrayList<String>() {
		{

			add("New Homesites Releasing Soon");
			add("Only 2 basement homes remain");
			add("More than 60% sold");
			add("Only Four Opportunities Remaining");
			add("New Floor Plans Available");
			add("\\d+ Spring Move-Ins Available|Spring Move-Ins Available|Summer Move-Ins Available");
			add("Only 1 Ranch Home Remains");
			add("Last home available in Phase \\d+|Last Available Home in Phase \\d+|Last Homes? Available");
			add("only inventory homes remain");
			add("Final Section of Homesites Now Released|new homesites now released");
			add("Only 1 Opportunity\\s*Home Remains");
			add("Only 1 new home opportunity remains");
			add("Limited Homes Left");
			add("Opening March 31st");
			add("Final home sites released");
			add("Two Final Inventory Opportunities|Final Inventory Opportunities");
			add("Final Two Homes Available");
			add("New Section Available Now|NEW SECTION AVAILABLE");
			add("Only 9 New Homes Remain");
			add("Homesites With Lake Views Available");
			add("MORE OPPORTUNITIES AVAILABLE");
			add("Only Two Home Sites Remain");
			add("Only 3 Grand Finale Home Sites Remain");
			add("8 Lots Remaining");
			add("ONLY 2 LAKE HOMES REMAINING");
			add("New Addition Just Released");
			add("only basement lots remain");
			add("Final Few Homes Left");
			add("\\d+ Walkout Basement Homesites Remaining|Walk out basements available|\\d+ Walk-out Basement Homesite (Remaining|available)|Limited Basement Homesites Remain|Basement Homesites Remaining|Only TWO Waterfront Homesites Remain|Only basement homesites remain|Finished basements available|Basements Available");
			add("Wooded & Walkout Lots Remaining|\\d{1,2} Lots Remaining");
			add("Only \\d+ home sites left|Only \\d+ Home Sites Left");
			
			add("last phase released|first phase release");
			add("Only 40 total opportunities available");
			add("Only 73 Sites Available");
			add("NOW CLOSING");
			add("Available Inventory Home[s]* Only");
			add("ONLY 1 LUXURY PATIO HOME REMAINS");
			add("ONLY FOUR LOTS REMAINING");
//			add("FINAL 3 HOMESITES AVAILABLE IN LATE FEBRUARY 2021|FINAL 3 HOMES");
			add("PHASE I 70% Sold");
			add("ONLY 1 INVENTORY HOME REMAINING");
//			add("LAST PHASE SELLING");
			add("\\d+ New Plans Available");
			add("Last Remaining Opportunity");
			add("Phase 3 coming this spring|Coming this spring");
			add("Last Lots Released|Last Lot Remain");
			

			add("FINAL NEW HOME OPPORTUNITIES");
			add("Two homes ready now");

			add("home sites currently available");
			add("USDA ZERO DOWN FINANCING AVAILABLE");
			add("70 home-sites available");
			add("Just 1 Lot Left");
			add("only a few residences remaining");
			add("JUST 3 homes left");
			add("150 LOTS REMAINING");
			

			add("only 30 home sites");
			add("IMMEDIATE DELIVERY AVAILABLE");
			add("Only 1 Residence Available");
			
			add("ONLY 3 CHANCES LEFT");
			add("Only 7 units left");
			add("Lots are going fast");
			add("Designer Showcase Homes available");
			add("Final 3 Homes");
			add("ONLY FEW REMAINING");

			add("last section for sale now");
			add("FINAL 50's Section");
			add("MORE LOTS RELEASED|NEW LOTS RELEASED");
			add("Final Lots Released");
			//add("Only 1�opportunity remains|Only one more opportunity");
			add("1 Townhome Homesite Remains");
			add("Three homes remaining in current phase");

			add("Next Homesite Release Coming Soon|New Inventory Coming Soon|COMING SOON FALL 202\\d|\\d+ Opportunities Coming Soon|New Phase Release Coming Soon|Final \\d+ Homes Coming Soon|\\d+ HOMES COMING SOON|Large Wooded Home Sites Coming Soon|PHASE \\d+ COMING SOON|\\d+ new lots coming soon|Coming Soon April 2021|Coming Soon Jan 202\\d|Coming Soon June 2020|COMING SOON 202\\d|Final Homes Coming Soon|new homes sites coming soon|Next Phase Coming Soon|MORE homes coming soon|Showcase Homes Coming Soon|New Town Homes Coming Soon|Coming soon (Spring|Summer|Winter|early) 202\\d+|Phase V Coming Soon|Phase II Coming Soon|NEXT PHASE COMING SOON|Phase III Coming Soon|Final Home Coming Soon|Final Release Coming Soon|New oversized home sites coming soon|New Homes Coming Soon|Phase 7 COMING SOON|Phase 2 and 3 coming soon|Final section coming soon|More Home Sites Coming Soon|New Designer Phase Coming Soon|MORE OPPORTUNITIES COMING SOON|NEW RELEASE COMING SOON|\\d new estate homesites coming soon|\\d MORE HOMESITES COMING SOON|New plans & new homesites coming soon|New Phase of Homesites Coming Soon|Homesites Coming Soon|Additional phase coming soon|Future Phase COMING SOON|new homes coming soon|New Townhomes Coming Soon|Townhomes coming soon|NEW SECTION COMING SOON|Second Phase Coming Soon|Final [P|p]hase Coming Soon|New Homes Coming Soon|PHASE 2 COMING SOON|NEW LOTS COMING SOON|NEW HOMESITES COMING SOON|New home sites coming soon|new phases coming soon|NEW SECTION COMING SOON|New Section[s]* Coming Soon|New Phase Coming Soon|Phase 3 Coming Soon|Phase 4 Coming Soon|Phase 6 Coming Soon|Homesites Coming Soon|Coming Soon in May|More Lots Coming Soon|Lots coming soon|Coming Soon"); //|New Phase Coming|Coming Soon|COMING SOON|coming soon|Coming Soon|COMING SOON|
			add("ONLY \\d+ FINAL HOME REMAINS|One Final Home Remains|Final Residences Remaining|Limited availability in Final Phase|Limited availability remains|limited availability remaining|Limited availability remain[s]*|Limited availability remains|Limited availability remains|LIMITED AVAILABILITY|Last Home Remaining|FINAL HOME REMAINING|FINAL HOME REMAINS");
//			add("New Home Sites Just Released");
			add("New Homes Just Released");
			add("Limited Home Opportunities");

			add("(only )?\\d+ lots left");
			add("Only \\d+ New Home Lots Left|Only \\d+ Left");
			add("Only 2 Remaining Opportunities|Only 2 remaining");
			add("Final Phase Released|Final Phase Release|Final Phase Releasing Soon");
			add("only a limited homesites remain|Limited Home Site Opportunities Available|Limited Home sites remaining|Limited Homesites Remaining|Limited home sites remain|limited homesites remaining|Limited homesites remain|Home sites limited|Limited Homes Remain|Limited Homes Remain");
			add("Limited Homesites Left");
			
			add("only two lots left|TWO LOTS LEFT");
			add("NOW OPEN Phase 2");
			add("Oversized Lots Still Available in New Section|premium lots available|Final 1/2 Acre Lot Available|Walk-Out Lots Available|Waterfront and waterview lots available|waterfront lake lots and private wooded creek lots available|waterfront lots and wooded tree lots available now|Lake front lots available|Water View Lots Available|Wooded & Pond Lots Available|pond and wooded lots available|Just 1 Beautiful Lake Lot Available|Only 8 lots available|Greenbelt Lots Available|Nine large lots available|LIMITED LOTS AVAILABLE|Large Lots Available|New Lake View Lots Available|Water Lots Available|Oversized Lots Available|Walkout basment lots available|New Basement Lots Available|Basement lots available|Waterfront Lots Available|New Lake Front Lots Available|New Lake Lots Available|Limited Lake Lots Available|New Greenbelt Lots Available|Over-Sized Lots Available|Limited homes and lots available|\\d+ New Lots Available|New Lots Available|14 available lots|Only one lot available|\\d LOTS AVAILABLE|Lake Lots Available|Lakefront Lots Available|Oversize Lots Available|Only two lots available|Wooded lots available|Lots Available Now|Lots Available|only \\d+ lots available|\\d{2} Lots Available|Corner Lots? Available|\\d Lake Lots Left|Limited lots left|lots available"); //|Available Now

			add("Wooded lots NOW AVAILABLE");
			add("\\d+ Premium Homesites Sold In New Phase|final homesites sold");
			add("\\d+ premium walkout homesites remain");
			
			add("New Homesites just released in Section III|New Home Sites Just Released|Premium Lakefront Homesites Just Released|Premium Homesites Just Released|\\d+ New Floorplans Released|Five large lots just released|New Large Wooded Home Sites Just Released|New floorplan Just Released|Phase \\d Lots JUST RELEASED|Final Wooded Home Sites Just Released|New Wooded Home Sites Just Released|Last Section Just Released|Phase \\d+ JUST RELEASED|NEW SITES JUST RELEASED|New Building Just Released|FINAL Building Just Released|wooded homesites just released|Final homesites just released|Last Phase Just Released|Final Home Sites Just Released|New phase homesites just opened|New phase of homesites just released|New Phase Homesites Just Released|Wooded and walkout basement sites just released|FINAL PHASE OF PRESERVE HOMESITES JUST RELEASED|New Basement Homesites Just Released|View Homesites Just Released|FINAL PHASE JUST RELEASED|just released final phase|Final Section Just Released|New home sites released|Final home site just released|just released final section|New Phase and Plan Just Released|New Section Just Released|PHASE II Homes Just Released|Phase 2 just released|just released 3rd phase|New Homesite Release|New Homesites Released|Newly Released Home Sites|NEW CUSTOM LOTS JUST RELEASED|NEW LOTS JUST RELEASED|NEW HOMESITES JUST RELEASED|New phase just released|Four lots just released|New Phase Just Released|just released new section|lots just released|HOMESITES JUST RELEASED|Just Released|NEW PHASE RELEASE"); //New Phase Released|New Phase Release|FINAL HOMES?  //|Final Homesites?|FINAL HOMES
			add("Limited wooded-view home sites available|\\d+ homesites available in Phase II|walkout basement home sites available|pond and lakefront homesites available|\\d+ Lakeview Homesites Remaining|FINAL 3 HOMESITES AVAILABLE IN LATE FEBRUARY 2021|Preserve and lake view home sites available|\\d+ Homesites Available in the Final Phase|Oversized and greenbelt home sites available|New Wooded and Lake View Homesites Available|Greenbelt view homesites available|water front home sites available|(few )?walkout home sites available|Lake View Homesites Available Now|Waterfront Homesites Available|One Wooded Homesite Available|Lakeview Home Sites Available|Wooded and Basement Home sites available|Limited number of larger home sites available|walkout basement home sites available|Basement Home sites Available Only|(Private )?Wooded Home Sites Available|Large Home Sites Available|Basement Home sites Available|Limited Lake[front]* Homesites Available|Lakefront homesites available|Lakefront Home Sites Available|Only 10 Grand Finale Home Sites Remain|Phase One Homesites available|remaining home sites available|Final phase of homesites available now|NEW homesites available now|NEW HOME SITES AVAILABLE NOW|New Home Sites Available|450 homesites available|Final Home Sites Available|Oversized home sites available|86 foot home sites available|Greenbelt Home Sites Available|wooded & creek home sites available|premium home sites available|Home Sites Available|new homesites available|limited home sites available|New Sites Available|only \\d+ home sites available|\\d+ home sites available|new homesites available|only five homesites available|only four homesites available|only \\d+ homesites available| \\d homesites available|Only a few homesites available|Limited Homesites Available|limited homesite opportunities|Limited Homesite Release|LIMITED HOMESITE |Limited Homes Available|homesites available NOW|\\d+ homesites available");
//			add("\\d+ Homesites Available");
			add("Selling out soon");

			add("Only a couple homes left");
			add("Only a Few Lots Left");
			add("Opening in the Fall");

			add("NEW PHASE RELEASING SOON");
			add("FINAL PHASE CLOSEOUT");
			add("ONLY 5 OPPORTUNITIES REMAIN");
			add("Only \\d+ basement opportunities remain|Final Basement Opportunities");
			add("Final 5 Opportunities");
			add("PHASE III Final Opportunities|Final Opportunities remaining in current phase|New Lot Opportunities|PHASE IV Final Opportunity|Final Opportunities for current phase|Final Opportunities in Current Phase|Last opportunity until next phase opens|Phase II Closeout Final Opportunities|Final Opportunities in Phase Four|Final Opportunities 3 Homes Left|Final New Home Opportunity|\\d+ Final Opportunities|Final Opportunities in Phase 3|Final \\d Opportunities|Final few opportunities remain|Closeout Final Opportunities|LAST OPPORTUNITY REMAINING|Final Opportunity Available|FINAL OPPORTUNITIES AVAILABLE|Final Opportunities Remain(ing)?|FINAL OPPORTUNITIES LEFT|only 1 FINAL Opportunity Remaining|Only 6 Opportunities Left|Only \\d+ Opportunities Left|13 OPPORTUNITIES LEFT|\\d+ OPPORTUNITIES LEFT|ONLY A FEW OPPORTUNITIES REMAIN|ONLY A FEW OPPORTUNITIES LEFT|FEW OPPORTUNITIES REMAIN|few opportunities left|only a few opportunities remaining|Final 3 Opportunities|Final Opportunities Remaining|final opportunities|FINAL OPPORTUNITY|Final Opportunity|Final Opportunity|FINAL OPPORTUNITIES|Final Opportunities|Last Opportunity|Final Opportunities");
			add("Phase II selling out|(NEW|First) PHASE SELLING OUT|Phase 1 Close To Selling Out|Limited homesites selling out( quickly)?|Phase 1 Nearing Sellout|Phase 1 selling out|Final Phase Selling Out Fast|Lots selling out|Selling out quickly|Selling Out Quickly|Selling Out Fast|currently selling out|Nearing sellout|Selling Out|NEARING SELL-OUT"); //

			add("now selling lots in phase \\d+|phase \\d+ selling now|FIRST RELEASE OF HOMES NOW SELLING|Now Selling Final Section|Final homesite selling now|Phase I now selling|now opened the final phase|now selling its final \\d+ homes|Now Selling \\d+ New Homesites|New Wooded Home Sites Now Selling|final homesites now released|Now Selling remaining Basement Homesites|thirty three home sites now available|Phase \\d Homesites Now Available|Waterfront home sites now available|Now Selling Second Phase|New Phases Now Open|Now Selling in New Phase \\d+|Final \\d+ homesites now available|\\d+ Wooded Homesites Remaining|Final Phase of homesites now available|Now selling Phase 2 homesites|Final Phases Now Selling|Now open Phase 1B|thirty-three home sites now available|Homes now available in Phases?( I and II| II)|New Phase and New Plans Now Selling|Home Sites and Showcase Homes Now Open|New section of home sites now open|Private & Wooded Home Sites Now Available|Mountain View Home Sites Now Available|Brand New Plans Now Selling|New Sections & Floor Plans Now Available|New Floor Plans Now Available|New Floorplans Now Available|(New )?Home Sites Now Selling|FIRST RELEASE OF HOMES NOW SELLING|now selling Phases Two and Three|Move-in-ready homes now available|PHASE \\d+ HOMESITES NOW AVAILABLE|PHASE \\d NEW SECTION NOW SELLING|Now selling quickly|lakeside and bayfront homesites available|(Large )?Wooded homesites available|water view homesites now available|New Wooded Home Sites Now Available|Final Home Now Available|Water Front Lots Now Available|Phase \\d and \\d lots now available|PHASE \\d+ NOW AVAILABLE|Phase \\d+ NOW OPEN|Phase II Lots Now Open|Wooded lots NOW AVAILABLE|Bay Front Lots Now Available|Large Lots Now Available|Phase II homesites now available|Phase \\d+ Lots Now Available|\\d+ Lots Now Available|lots now available|New lots now available|Section III Now Open|New Townhomes Now Open|Now Selling Phase Five|Now Selling Phase Three|Now Selling PHASE III|Phase \\d+ now selling|Final \\d homes now available|Retreat Home Sites Now Available|Now Selling New Floorplans|waterfront lots now open|NOW SELLING PHASE II|Now Selling Phase I|Phase II Now Selling|Section \\d Now Available|FINAL \\d HOMES SELLING NOW|Section 3 Now Open|Phase Two Now Selling|NEW BUILDING NOW AVAILABLE|Newest phase now open|Now Selling New Townhome|New home sites are now available|New Home\\s*[S|s]ite[s]* Now Available|Now selling newly released home sites|Half-Acre Homes Now Available|now available Phase I|MORE OPPORTUNITIES NOW AVAILABLE|Immediate Occupancy Now Available|FINAL HOME NOW SELLING|final homes now available|Newest phase now open|Now Selling Phase 3 Homesites|NOW SELLING Phase 3|NOW SELLING PHASE \\d+(A)?|NEW PHASE \\d+ NOW OPEN|new phase now open and selling|now open and selling|New Floorplans Now Selling|Phase 2 New Home Sites & Plans Now Available|New Townhomes Now Selling|WATERFRONT LOTS NOW SELLING|final homesite now selling|Final Section Now Available|Final Homesites Now Selling|New Homesites Now Selling|FINAL HOMES SELLING NOW|Now Open & Selling|wooded homesites now available|PHASE 3 NOW SELLING|Phase III Now Available|Now selling final homes?(ites)?|waterfront homes now available|Water view home sites now available|FINAL Phase Now Available|Phase II Home Sites Now Available|Phase 2 Home Sites Now Available|Phase \\d+ Now Selling|Phase 1 Now Selling|Now selling Section Two|LAST SECTION OF HOMESITES NOW AVAILABLE|Large Homesites Now Available|PREMIUM HOMESITES NOW SELLING|Final Release now available|Premium Homesites Now Available|Now Selling Phase 6|final section now open| now selling phase 4|FINAL HOMES NOW SELLING|Final Two Homes Now Selling|Phase 2 OPEN NOW|now selling newest phase|now selling new phase|Basement homesites now available|NOW SELLING PHASE 4|Phase Two now open|PHASE 3 NOW OPEN|FINAL HOME SELLING NOW|New Townhomes Now Available|Condos Now Available|LOTS NOW SELLING|TWO NEW PHASES NOW SELLING|Now Selling Section 4|homes now available |Only 2 Finale Home Sites Remain|Only Six Home Sites Remain|Now Selling Final Inventory Home|Phase 4 Now Selling|New phase now available|newest phase now available|Final Ready Homes now available|Phase IV and V now Open |PHASE II NOW OPEN|first phase now available|Now Selling FINAL \\d+ Home|Now Selling New Phase|Selling New Phase|Phase V now selling|New Homes Now Selling|Phase III Now Selling|Now selling new homesites|Now selling third and final phase|Now Selling Phase II|NOW SELLING PHASE 1 & 2|NOW SELLING PHASE \\d+|New Phase Now Open|Second Phase Now Selling|Phase II now available|Phase V Now Available|Phase IV Now Available|Phase IV now open|New Homes Now Selling|Phase IV now Open|Now selling Section Two|Now Selling Sections 2 &amp; 3|Now Selling Sections 2 & 3|Now Selling New Section|Final Section Now Open|NEW Sections now available|New Plans now available|FINAL \\d+ NEW HOMES NOW AVAILABLE|Section II Now Open|New Homes now available|New Phases? Now Selling|New Section Now Available|\\d*\\s*home sites now available|(MORE )?homesites are now available|First Section Now Selling|new section now open|New Home Sites Now Available|New Sections? Now Selling|New Selling New Section|now selling new phase|Phase Two - NOW SELLING|Phase 3 Now Selling|Phase 2 Now Selling|Now Selling Phase 2|New Homesites Now Open|section 2 now open|Phase III Now Open|Phase III Lots Now Open|NOW SELLING PHASE TWO|PHASE II NOW SELLING|last phase now Selling|Final Phase Now Selling|NOW SELLING FINAL PHASE|Now selling final phase|NEW PHASE NOW SELLING|homesites now selling|Now Selling Phase IV|Now selling phases 4 and 5|Final Section Now Selling|Now Selling New Section|now selling new phase|Final Phase Now Available|Final Home Sites Now Available|FINAL PHASEs? NOW OPEN|LAST HOME NOW AVAILABLE|New Homestes Now Available|homes now available|now available|Quick Move In Now Available|New Private Homesites Now Available|New Homesites Now Available|NEW HOME SITES ARE NOW AVAILABLE|homesites now available|homesites now available|Final Homesites Now Available|New Homesites Now Open|Phase 2 now open|Phase 2 Now Open|Only a Few Lots Remaining|Only a few lots remain|Just a Few Remain|3 Homesites Released in Final Phase|NEW PHASE NOW OPEN|NEW SECTIONS NOW OPEN|New Section Now Open|Phase 6 is now open|Phase three now open|Phase Four NOW OPEN|NOW OPEN|Now Open|Phase 4 now open|Last Section Now Open|Second Phase Now Open|NOW OPEN|Final Homes Now Selling|Final Homes Now Selling|Final Phase Available|Phase Two Now Selling|PHASE 3 HOMES NOW SELLING|Now Selling Building \\d+|Now selling homesites in Phase \\d+|Now selling homesites|Now Selling out|Now Selling|NOW SELLING|Final Phase Selling Now|NEW PHASE SELLING NOW|Final Homes Remain|Final Homes Available|Opportunities Available Now|SELLING NOW|Final Homes Released|Homesites Now Open|FINAL RELEASE|Final Phase|New Phase Released|Homesites now available"); //|FINAL HOMES|Final Phase|New Phases?|Selling Out|NEW PHASE|Opening New Phase|
			add("Limited basement homesites available|(Limited Number of )?Basement homesites available");
			add("New Phase Available Early 2021|New Phase Available");
			add("Only 2�homesites remain");
			add("GRAND RE-OPENING");
			add("Only 1 House Left");
			add("Selling out soon");
			add("Phase 5 now open");
			add("Selling Phase V");
			add("10 Final Home Sites Left");
			add("new unit now open");
			add("ONLY 8 TWIN HOMES LEFT");
			add("LAST HOME LEFT");
			add("Only 18 large homesites available|two large homesites available|Large Homesites Available");

			add("Only \\d opportunity remains|Only 1 More Opportunities|Only ONE opportunity remains|only one opportunity remains|Only One Opportunity Remains|Just One Opportunity Remains|One Opportunity Remains|1 REMAINING OPPORTUNITY LEFT|1 REMAINING OPPORTUNITY"); //|\\d opportunity remain			
			add("Last Opportunities in Phase I|Limited Presale Opportunities Now Available|Only \\d+ remaining opportunities|43 opportunities available|Limited opportunities in Phase IV|Only One Opportunity Available|ONE OPPORTUNITY AVAILABLE|Only 18 Large Homesites Available|Last Opportunities Remain|LAST OPPORTUNITIES|Limited Opportunities Phase IV left|Limited Opportunity Remaining|Limited opportunities left|One opportunity remaining|only five homesites available|(Only |Just )?Two opportunities remain|Only 2 opportunities remain|Only \\d+ Opportunities Remain(ing)?|Only \\d+ Opportunity Available|Only \\d+ Opportunities Available|\\d+ Opportunities (Remain(ing)?|Available)|Limited Opportunities Available|limited build opportunities remaining|Limited Opportunities Remain(ing)?|Opportunities Limited|Limited Opportunities|LIMITED OPPORTUNITIES REMAIN|Limited Opportunities|Limited Opportunity");
			add("Only 4 homesites left");
			add("Only three opportunities remain");
			add("Only TWO opportunities available");
			add("One Quick Move-In Home Remains");
			add("Only One Opportunity Left|ONE OPPORTUNITY LEFT");

//			add("ONLY 14 OPPORTUNITIES");
			add("ONLY A COUPLE OPPORTUNITIES LEFT");
			add("Only 5 homesites left");
			add("Phase 1 almost completed");
			add("Only 2 Homes Remian");

			add("Only TWO opportunities available");
			add("Only 1 Opportunity Remaining");
//			add("Only 5 Opportunities Remaining|\\d+ Opportunities Remaining");
			add("Only 1 Opportunity Left in Current Phase|Only 1 Opportunity Left in Phase 1|Only 1 Opportunity Left");
			add("Phase 2 is now available");
			add("Only 4 Homes Available");
//			add("Phase 2 currently under construction");
			add("LAST HOME LEFT");
			add("only 7 left");
			add("Lots are selling fast|lots selling fast|Phase 4 Home Sites Selling Fast|Phase I Selling Fast|Final phase home sites selling fast|Final Homes Selling Fast|current phase selling fast|Phase III Selling Fast|Phase 1 selling fast|Last phase Selling Fast|New Homes Selling Fast|HOMES SELLING FAST|Final Phase Selling Fast|Homesites Selling Fast|Selling Fast|fast selling ");
			add("Coming late Spring 202\\d|COMING LATE SPRING");
			add("Only 11 Sites Remain");
//			add("9 Opportunities left");
			add("Closing Soon");
			add("(Only )?One home site remains|Just 1 Home Site Remains");
			add("limited lots remaining");
			add("6 new home sites remain");
//			add("\\$0 DOWN FINANCING AVAILABLE");

			add("USDA Loans available|\\$0 DOWN FINANCING AVAILABLE|VA and USDA financing|USDA Rural Housing 100% financing|\\d+% down USDA financing available|USDA Eligible 100% Financing|100% financing through USDA|100% financing from usda|USDA Financing Eligible|USDA Eligible Financing|USDA-Financing Eligible|USDA Eligible|USDA 100% Financing Available|USDA Financing available|100% Financing Available|100% USDA financing|USDA financing|100% Financing|100% Financing|USDA 100% Financing|100% financing|USDA Home Loan");
			add("VA Financing Available");
			add("Only three Homesites Left");
			add("ONLY FOUR HOMES LEFT");
			add("ONLY ONE HOMESITE AVAILABLE|\\d+ homesite available");
			add("only 1 quick move in home remaining");
			add("\\d+ Lake lot remaining|ONLY 1 LOT REMAINING");
			add("Only 4 Quick Move In Homes Remain");
			add("Only FIVE HOMES remaining");
			add("Only a few lots left");
			add("Only one lot left|JUST ONE LOT REMAINING");
			add("New phase	coming soon");
			add("only 1 house remaining");
			add("\\d+ town homes remaining");
			add("USDA Approved Financing Available|USDA Approved");
			add("Only 1 Homesite Left|Only 6 Homesite Left");
			add("Only 1 Townhome Left");
//			add("Final Phases Now Selling");
			add("Last 5 Homes Remaining");
			add("PHASE 1 -SOLD OUT");
			add("PHASE 2 - NOW SELLING");
			add("ONLY TWO DESIGNER HOMES REMAINING");
			
			add("ONLY 2 HOMESITES LEFT");
			add("Currently Selling final phase|Currently selling NEW SECTION|Currently Selling Phase 6|currently selling Phase 1 "); //|Currently Selling
//			add("Opening This Summer");
			add("[Only]*\\s*\\d+ Townhomes Remaining|Only \\d+ Townhome Remains|Only \\d+ Townhomes Remain|\\d+ TOWNHOMES LEFT|\\d+ Townhomes Remain");
			add("ONLY \\d+ INVENTORY HOMES REMAINING|\\d+ Inventory Homes Remaining");
			add("Only \\d+ Available Homes remain|Two Stunning Homes Available|LAST \\d+ HOMES AVAILABLE|Final 2 Homes Available|Only 1 Available Home Left|ONLY 2 AVAILABLE HOMES LEFT|only a few available homesites left|\\d+ Available Homesites|\\d+ Available Homes|New homes available soon|\\d+ Home Available Now|\\d+ Homes Available Now|Only 1 Home Available|Last Two Homes Available|\\d+ available homesites|Only \\d+ homes available|\\d+ homes available"); //|FINAL \\d+ HOMES(ITES)?
			add("Phase 5B opening this winter|Opening This Winter");
			add("Final 7 Homesites Remaining");
			add("Just 1 home remains");
			add("CLOSEOUT OPPORTUNITIES");
			add("Coming This October");
			add("(New|Final) Phase coming this summer|New Phase Coming September|Coming this summer"); 
//			add("Final Phase Coming This Summer"); 
			add("Only 1 Homesite Available");
			add("Only 3 \"Quick Move In\" homes remaining");
			add("Grand Closing");
			add("ONLY A FEW REMAINING LOTS|few remaining lots");
			add("100% Financing Now Available");

			add("two home sites remaining|TWO home sites remaining|two home sites remaining"); //|\\d+ Home Sites Remaining( in Building One)?
			
			add("Coming Later this Year");
			add("168 Homesites Released In Sections");
//			add("Phase 2 Homesites Now Available");
			add("NEW 65' OVERSIZE HOMESITES NOW AVAILABLE");
			add("NEW CLASSIC HOME SITES AVAILABLE");
			add("ONLY NINE OPPORTUNITIES LEFT");
			add("29 TOWNHOMES STILL AVAILABLE");
			add("New Home Ready Now");
			add("Over 100 Homesites Sold");
			
//			add("TEMPORARILY SOLD OUT");
//			add("temporarily sold out");
			add("New Townhome Available");
			add("Coming in September|New Section Coming in September");
			
			add("Only TWO homesite remains");
			
			add("Phase Two Coming Summer 2021|NEW (PHASE|homes|Lots) COMING SUMMER 202\\d|Arriving SUMMER 2020|COMING SUMMER 202\\d");

			add("(NEW PHASE )?Opening Summer 2021|opening this Summer");
			add("Final Section Opening FALL 2021|Final Section Open");

			
			add("Phase Two Opening Early 2022|Grand Opening Summer 2021|Opening Early-Mid 202\\d|Grand Opening March 2021|Grand Opening in 2021|Grand Opening December 2020|Grand Opening Early 2021|GRAND OPENING FALL 202\\d|Grand Opening New Phase & Homesites|Phase \\d Grand Opening|Grand Opening Spring 202\\d|Grand Opening late August|Grand opening October \\d+|NEW PHASE GRAND OPENING|New Section Grand Opening|New Phase Grand Opening Now|Grand Opening of Final Phase|GRAND OPENING PHASE 3 & 4|GRAND OPENING Phase 4|Grand Opening Phase II|Grand Opening This Summer|Grand Opening Soon|Grand Opening this fall|Grand Opening Opportunities|GRAND OPENING IN JUNE|Grand Opening|(New Phase )?Opening Spring 202\\d|Opening Early 202\\d|Opening Fall 202\\d|Opening March 2021|Opening 2021");
			add("opening Phase III");
			add("New Phase Opening In July|New (phase|Homes) opening Summer 2020|Opening Summer 2020|New phase opening early 2020|Opening Early 2020|New phase opening in 2020|phase 2 opening soon|New Phase Opening Soon|(new|Next) section opening soon|new phase opening soon|New Phase Open Now|Opening Soon"); //New Phase Open||Opening Soon
			add("New Section Open Now|New Section Open");
			add("only 1 homesite left");
			add("Just 1 homesite available");
			add("Closing Out - Few remaining");
			add("Community Close-Out|FINAL PHASE CLOSE OUT|Builder Close-Out|closing out the final phase|Phase 1 CLOSEOUT|Phase \\d Close-Out|Phase One Close Out|Phase \\d+ Closeout|Current Phase Closeout|Community Closeout Phase|Community Closeout|COMMUNITY CLOSE OUT|Grand Closeout|Nearing Close-out|Phase I Close-Out|Phase \\d+ Closing Out|Close Out Phase|closing out soon|Closeout Community|Nearing Closeout|FINAL CLOSE OUT|Nearing Close Out|Near Close Out|ALMOST CLOSED OUT|Close Out|CLOSEOUT|Final Closeout|CLOSED-OUT|CLOSED OUT|Close-Out Special|Close Out Specials| Close-Out?|Close-out |close-out |CLOSING OUT|closing out|Close-Out");
			add("0% Down Available");
			add("Unit \\d Now Open");
			add("Final Home Available");
			add("Only TWO Lots Remain|TWO LOTS REMAIN");
			add("Immediate Move-ins Available|Only \\d+ Quick Move-In Homes Remain|Only 7 Town Homes Available|2 remaining quick delivery homes available|\\d+ Quick Delivery Homes Available|Quick Move-In Homes Ready Now|Move-in Ready Homes Available|New Homes Ready Now|\\d+ homes ready now|Homes Ready Now|Move In Ready home|Only 2 Move-In Ready Homes Remain|No Quick Move In Homes|No Quick Move-In Homes|MOVE-IN READY HOMES|One Move-In Ready Home Remains|Quick Move-In Homes|Quick Move-In Home|Quick Move In Homes|Quick Move-In |\\d+ Quick Move-Ins Available|\\d+ Quick Move-In Home|\\d+ Quick Move-in home|No Quick Move-Ins Available|no Quick Move-In homes available|no Move-In Ready Homes|No Move-In Ready Homes|No Move-In Ready Homes|no move-in ready homes available|\\d{1,2} Quick Move-ins? Available|Quick Move-ins? Available|No Quick Move-In homes available|Quick Move-in not Available|Quick Movein not Available|No Quick Move-Ins?|QUICK MOVE-IN HOMES|No Quick Move-In Homes|Move-In Ready Available|Move In Ready Available|move-in ready homes available|Move In Ready Homes| Move-In Ready Homes| Move-in Ready|Ready Home Available|Quick Delivery Homes|Quick Delivery Home|Quick-Move In Homes|quick move-in"); //|Quick Move-in
			add("Now Offering Premier Floor Plans");
//			add("Ready for Sale");
			add("Not Ready for Sale");
			add("Not Ready to sale");
			add("\\d{1,2} homes already sold");
			add("First & Second Building SOLD OUT|ALL LOTS Currently sold out|First Building is SOLD OUT|OVER \\d{2}% SOLD OUT IN PHASE I|50% Sold Out in Phase I|Current Section Almost Sold Out|Over halfway sold out of section \\d+|Phase 1A is SOLD OUT|COMMUNITY SOLD OUT|(All )?Current Phases? SOLD OUT|Phase one sold out|Phase 1 currently sold out|50% sold out of final phase|PHASE 1 SOLD OUT|Phase 8 SOLD OUT|Phase 4 nearly sold|Sold out Phase I|phase one and phase two sold out|MORE THAN 70% SOLD OUT|first phase sold out|First Phase Over 75% Sold Out|Over 75% Sold|Phase 7 SOLD OUT|Current Section Sold Out|CURRENT PHASE SOLD OUT|currnetly sold out|Now Sold Out|Phase II SOLD OUT|sold out quickly|last phase sold out fast|Phase 1 nearly sold out|Lots are sold out|sold out current phase|phase 1 almost sold out|Lots Sold Out|Currently Sold Out|Currently Sold|PHASE 3 SOLD OUT|ALMOST SOLD OUT|almost sold out|Almost Sold Out|Almost Sold Out|almost sold out|Phase I SOLD OUT|Phase I sold out|Phase I is SOLD OUT|\\d+% sold out|Temporarily Sold-Out|Sold Out|SOLD OUT|SOLD OUT|Nearly sold out|sold-out|TEMPORARILY SOLD OUT|temporarily sold out|(Nearly|Over) \\d{2}% Sold|50% SOLD");
			add("Actively Selling");
			add("Last Chance Opportunities Remaining|Last chance for wooded home sites|LAST CHANCE|FINAL CHANCE");
			add("only a few more oppportunities available");
			add("58 homes sold|\\d+ homes sold");
			add("ONLY ONE REMAINS|ONE REMAINS|only ONE remains");
			add("Only a few homes left in phase \\d+|Only a few home sites remain|few home sites remaining in phase 1|Only 1 homesite remaining|only one homesite remaining|Only one homesite remains|ONE homesite remaining |Only 6 new home opportunities remain|FINAL HOMESITES REMAIN|ONE HOMESITE REMAINING|Only Few Homesites Remain|Only a Few Remain|Only a few remaining homes|Only a few new homes remain|ONLY 7 HOMESITES LEFT IN PHASE 7|3 remaining homesites|Only a Few Homesites Left|Only one homesite left|Only A Few Homes Left|ONLY 1 HOMESITE REMAINING|Only 1 homesite remaining|1 Home Site Available|ONE home site remaining|one home site remaining|1 Homesite Remaining|Few Homesites Remain|Only a few homesites remain|\\d+ HOMESITES LEFT|Last Homesite available|few home sites remain|Few Homes Left"); //|Limited Homesites //|(Only )?1 Home Site Remaining|\\d+ HOMESITE remain(ing|s)
			add("ONLY \\d+ HOMES LEFT IN PHASE III|ONLY TWO HOMESITES REMAIN|\\d+ Homesites Remaining in the Final Phase|Only One( more)? Home Remains( in the Current Phase)?|ONLY ONE HOME LEFT IN THIS PHASE|Less than ten homesites remaining|Final phase One home remaining|Just a few homes remain|FINAL FEW HOMES REMAINING|Only three homesites remain(ing)?|ONLY TWO HOMESITES REMAIN|(TWO|THREE) homesites remaining|only \\d+ homesites? remain(ing)?|Only \\d+ homesites remain|(JUST )?\\d Homesites Remain(ing)?|\\d+ HOMESITES REMAIN|Last \\d+ homes left|Only \\d New Homes Remain|Only \\d Homes Remaining|only \\d+ homes? remains?|ONLY A FEW HOMES REMAIN|Only One Homes Remains|Only Three New Homes Left|One Townhome Homesite Remaining|Just \\d+ home left|Less than \\d+ home sites remaining|Grand Finale Only \\d Home Sites Remain|Under \\d+ homes remain|Less than \\d+ homes remain(ing)?|Only \\d+ Homes? (Left|Remaining)|only \\d homes? (left|remaining|remains?)|(Only )?\\d Home Sites? (Remaining|remains?)|ONLY \\d HOMESITE REMAINS|Final Two Homes Remaining|ONLY FOUR HOMES LEFT|Only two homes (remain|left)|TWO HOMES REMAIN|Only ONE home (available|LEFT|remains|remaining)|One Home (Left|Remains|remaining)|\\d+ Homes? (Remaining|REMAIN|LEFT)|\\d Homesites (remaining|Remains)| \\d+ Home Sites (Remaining|Remains?)|One townhome left|few homes remain| \\d+ HOMES REMAIN|\\d+ Homesite Remains"); //|One Homesite (Left|remaining)
			add("\\d Showcase Homes? Remaining");

			add("ONLY \\d LOTS REMAIN?");
			add("only 1 lot left");
			add("(only )?Four Homesites Remain");
			add("USDA LOAN QUALIFIED");
//			add("New section of home sites now open");
			add("Selling Lots Only");
			add("Just 1 Left");
			add("\\d+ Cul-de-Sac Wooded Homesites Remaining|(Only )?\\d Large Wooded Homesites Remaining");
			add("Townhomes Selling Quickly in New Section|FINAL SECTION SELLING QUICKLY|New (Section|Phase) Selling Quickly|Final Phase Selling Quickly|final few homes are selling quickly|Phase I homesites selling quickly|Lots selling quickly|Homes selling quickly|Selling Quickly"); //
			add("56 Home-sites Available|only 52 sites available");
			add("Phase 3 Homes Selling");
			add("NEW (HOMES|Phase|Lots|homesites) COMING THIS FALL|second phase coming this fall|Coming this Fall");
			add("(new phase |New Section )?Coming this winter");
//			add("LAST ONE");
			add("New Floor Plan Available");
			add("\\d Market Homes Remain");
			add("New lots coming 202\\d|Phase \\d coming 2022|NEW PHASE COMING 202[1|2|3]|New phases coming 2021|next phase coming 2021|(Next Phase |New Phase |More townhomes )?COMING WINTER 202\\d|(\\d+ LOTS )?COMING in 202\\d|Coming 202\\d");
			add("Phase 2 Coming Winter of 2020-2021");
//			add("COMING 2020|Coming in 2020");
			add("Coming Early Fall 2021|Phase (2|II) Coming Early 202\\d|Coming Early 2022");
			
			add("Phase III coming late 2020|(Next Phase )?Coming Late 202\\d");
			add("oversize homesites available");
			add("ONLY 4 EXCEPTIONAL LOTS LEFT");
			add("Section II Open");
			add("Only TWO Remain in Phase I");
			add("Homesite 1 is SOLD");
			add("Arriving Early 2020");
//			add("Opening Spring 202\\d|Opening 2021");
//			add("Opening Fall 202\\d"); 
			add("Coming Spring/Summer 202\\d|NEW PHASE COMING SPRING 202\\d|Coming Spring 2021|COMING SPRING 202\\d");
			add("PHASE \\d+ COMING FALL 2021|New homesites coming Fall 202\\d|(NEW|Next) PHASE COMING FALL 202\\d|(SECOND PHASE )?Coming Fall 2021|coming fall 2020");
			add("Opening Winter 2020/2021|Opening Winter 2020");
			add("Phase I available Spring 2020");
//			
			add("Basement homes available");
			add("Immediate Move-in Available");
			add("Limited-Time Offer|Limited Time Offer");
			add("Just TWO Home Left");
			add("Phase 3 Home Sites Now Released");
//			add("Limited Home Sites Remain");
			add("only one more phase left");
			add("Phase \\d+ open early 2020");
//			add("Coming April 2020");
//			add("New Phase Coming May 2020");
			add("Coming Early Summer 2020|Coming Early Summer");
			add("New Bristol Twin Lots Released");
			add("NEW HOMES AVAILABLE NOW|New Homes Available|Homes Available Now"); //|available now
			add("FHA FINANCING AVAILABLE|FHA Financing");
//			add("More premium lots available");
			add("Only \\d+ new market homes left");
//			add("Homes Available Spring 2020");
			add("Opening Late 2020");
			add("Phase \\d+ Now Released");
//			add("Coming May 2020");
			add("only (one|1) phase remaining");
			add("new phase coming mid 2020|Coming Mid 202\\d");
			add("Opening May 2020");
			add("ONLY FOUR open homesites left in phase one");
			add("(New Phase )?coming (August|September) 2020");
			add("(New phase )?Coming Late Fall 202\\d|coming late fall");
			add("Final Section Released");
			add("Opening Late Summer 2020");
			add("FINAL LOTS REMAINING");
			add("Last two home available");
			add("Only three homes left");
			add("One finished home left");
			add("Only 1 Condo Remaining");
			add("(New )?Apartments Arriving (Summer|Fall) 202\\d|New Apartments Arriving Early 2021|New Apartments Arriving Fall 2020|Residences Arriving Spring 2021|Apartments Arrive Spring 2021|New Apartments Arriving 202\\d|arriving (fall|Early|Summer) 202\\d|Arriving 2021");
//			add("open in spring of 2021");
			add("Phase \\d+ Coming Early 2021|New Homesites Coming Early 2021|New Phase Coming Early 2021|coming early 2021");
			add("\\d+ pond (view )?homesites remaining");
			
			add("New Section Coming October 2021");
			add("new section coming January 202\\d|COMING JANUARY 202\\d");
			add("Opening Winter 20/21");
			add("over 85% sold in section II");
			add("COMING DECEMBER 2020");
			add("Coming February 2021");
			add("now building new section");
			add("Opening Winter 2021");
			add("large & wooded & cul-de-sac homesites available|cul-de-sac homesites available");
			add("soon release a new section");
			add("Only \\d Condos Remaining");
			add("Now Building in Phase (\\d+|II)");
			add("PHASE THREE OPENING IN OCTOBER");
			add("Opening in Early 2021");
			add("Phase \\d+ Home Sites Released");
			add("\\d+ Walk-Out Homesites Remain|\\d+ Cul-De-Sac Homesites Remain");
			add("New Phase Homesites Now Available");
			add("Coming March 2021|COMING AUGUST 2021");
			add("limited number of homesites available");
			add("Only a Couple of Homesites Remain");
			add("Only Two Townhomes Remain|Just one townhome remains");
			add("\\d+ homesites opening in Phase 1");
			add("Only \\d+ Oppourtunities Remaining");
			add("Corner homesites available");
			add("Cul-de-sac and Oversized homesites available|Lakeview and cul-de-sac homesites available|Waterview and wooded view homesites available|oversized homesites available");
			add("New Phase Coming Fall of 2021");
			add("Spring 2021 Delivery");
//			add("PHASE IV COMING APRIL 2021|Coming April 2021");
			add("QUICK DELIVERY AVAILABLE");
			add("CLOSET OUT OPPORTUNITIES");
			add("Opening Mid-2021");
			add("New Phase Opening Spring 2021");
			add("LIMITED RELEASE( Opportunities)?");
			add("Summer 2021 Delivery");
			add("Opening February 202\\d");
			add("New Phase May 2021");
			add("71 home sites released in Phase 1");
			add("Last Homes in Current Section");
			add("Opening in early Spring 2022");
			add("Next Phase Release Coming July 2021");
			add("Final Home Opportunity in Phase I");
			add("Last Homes Remaining|Last Remaining Homes|Last Homesites Remaining");
			add("Only THREE lots remaining");
			add("Only two inventory homes remaining");
			add("Only Two Remain");
			add("only one new home left in Phase II");
			add("only \\d+ townhomes available");
		}
		
	};
}
