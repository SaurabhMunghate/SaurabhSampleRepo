package com.shatam.utils;

public class Setting {

}
