/**@author Aditya.
 * 
 */
package com.shatam.b_001_020;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
//import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class CENTEX_HOMES extends AbstractScrapper

{
	static int count = 0;
	public int dup = 0;
	CommunityLogger LOGGER;
	static String Builder_Url = "https://www.centex.com";
	static int j = 0;
	String status;
	WebDriver driver;
	List<String> comData = new ArrayList<>();
	private static LatencyCounter LATENCY = null;

	public CENTEX_HOMES() throws Exception {

		super("Pulte Group - Centex Homes", "https://www.centex.com");
		LOGGER = new CommunityLogger("Pulte Group - Centex Homes");

	}

	public static void main(String[] args) throws Exception {
		LATENCY = new LatencyCounter();
		LATENCY.start("Community State");
		AbstractScrapper a = new CENTEX_HOMES();
		a.process();
		LATENCY.end("Community State");
		FileUtil.writeAllText(U.getCachePath() + "Pulte Group - Centex Homes.csv", a.data().printAll());
		System.out.println(LATENCY);
	}

	@Override
	protected void innerProcess() throws Exception {

		String MainHtml = U.getHTML(Builder_Url);
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();

		String regionState = U.getSectionValue(MainHtml, "<select class=\"form-control State\"", "</select>");
		// U.log(regionState);
		String[] state = U.getValues(regionState, "<option value=\"", "\">");
		for (String string : state) {
			U.log("state::::::" + string);
			if (string.length() < 3) {
				continue;
			}
			String stateHtml = U.getHTML(
					"https://www.centex.com/api/marker/mapmarkers?brand=Centex&state=" + string + "&qmi=false");
			String stateData = U.getHTML("https://www.centex.com/API/community/Search?qmi=false&brand=Centex&state="
					+ string + "&productType=community&pageSize=99&pageNumber=0&flag=state&data=" + string);
			String[] comdata1 = U.getValues(stateData, "<hr class=\"visible-xs\" />", "<hr class=\"visible-xs\">");
			String[] comdata = U.getValues(stateHtml, "{\"Id\":", "\"exact\"");
//			U.log(comdata.length);
//			U.log(comdata1.length);
			for (int i = 0; i < comdata.length; i++) {
				comData.add(comdata1[i] + comdata[i]);
			}
			//U.log("StateD:: "+"https://www.centex.com/api/marker/mapmarkers?brand=Centex&state=" + string + "&qmi=false");
		   // U.log("StateD2::"+"https://www.centex.com/API/community/Search?qmi=false&brand=Centex&state="+string+"&productType=community&pageSize=99&pageNumber=0&flag=state&data="+string);
		}
		U.log(comData.size());
		Iterator<String> ite = comData.iterator();
		while (ite.hasNext()) {
			String data = ite.next();
			
			String url = U.getSectionValue(data, "<a href=\"", "\"");
			if (!url.startsWith("https:")) {
				url = Builder_Url + U.getSectionValue(data, "<a href=\"", "\""); 
			}
			
			addDetails(data, url);
		}
       // driver.quit();
		LOGGER.DisposeLogger();

	}

	private void addDetails(String comSec, String comUrl) throws Exception {
//		if(j >= 101)
//		try
//		{
//		if(j >=145)
		{
		
//			 U.log("count::"+j);
			// *********Community Url**************************
			// TODO : For Single Community execution
//			if (!comUrl.contains("https://www.centex.com/homes/north-carolina/charlotte/catawba/legacy-ridge-211023"))return;
			
//				if (!comUrl.contains("https://www.centex.com/homes/arizona/phoenix/tolleson/verde-trails-210758"))return;

			U.log("\n\ncount::" + j + "\ncomUrl::" + comUrl);
			 
			U.log("Path::" + U.getCache(comUrl));
			String comHtml = U.getHTML(comUrl);
			
//			U.log("========mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}1,782[\\w\\s\\W]{30}", 0));
			

			String quickCount=U.getSectionValue(comHtml, "data-analytics=\"homes-glance|toggle|qmis\">", "</div>");
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.pulte.com"))) {
				LOGGER.AddCommunityUrl("*****************PulteHomes**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.delwebb.com/"))) {
				LOGGER.AddCommunityUrl("*****************DelWebbHomes**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.divosta.com/"))) {
				LOGGER.AddCommunityUrl("*****************DivostaHomes**************" + comUrl);
				dup++;
				return;
			}
			if(comUrl.contains("https://www.centex.com/homes/tennessee/nashville/murfreesboro/hayden-cove-210525")
					|| comUrl.contains("https://www.centex.com/homes/florida/tampa/parrish/brightwood-at-north-river-ranch-210373"))
			{
				LOGGER.AddCommunityUrl("*****************Redirect**************" + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

//			U.log("Common Section : "+comSec);

			// ======================================= remove
			// Sec==================================
			String rem = U.getSectionValue(comHtml, "nearbyMarkers =", "</script>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			String coming = "";
			if (comHtml.contains("<h4 class=\"CommunityHero__status\">Coming Soon</h4>")) {

				coming = "<h4 class=\"CommunityHero__status\">Coming Soon</h4>";
			}
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "target=\"_blank\">", "<");
			if (comName == null) {
				comName = U.getSectionValue(comSec, "community-name|Centex\">", "<");
			}

			comName = comName.replace("&#174;", "");
			if (comName.endsWith("Country Club"))
				comName = comName.replaceAll("Country Club", "");
			if (comName.endsWith(" Townhomes"))
				comName = comName.replaceAll(" Townhomes", "");
			comName = comName.replaceAll(" - Active Adult Community| - Condominium", "");
			U.log("Com Name::::::::" + comName);

			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
//			U.log(comHtml.contains("\"Address\": {"));
			if (comHtml.contains("\"Address\": {")) {
				String addSec = U.getSectionValue(comHtml, "\"Address\": {", "}");
				addSec = addSec.replace("Coming Soon", "").replace("(Tavistock Lakes \\u0026 Karrer)", "")
						.replace("&#39;", "'").replace("(SR 210 and US-1)", "")
						.replace("(Selling from Settlers Ridge)", "").replace("(Selling from Hawthorn Hills)", "")
						.replace("\\u0026", "&").replace("&amp;", "&").replace("Sold Out", "");
				add[0] = U.getSectionValue(addSec, "Street1\": \"", "\"");
				add[1] = U.getSectionValue(addSec, "City\": \"", "\"");
				add[2] = U.getSectionValue(addSec, "State\": \"", "\"");
				add[3] = U.getSectionValue(addSec, "ZipCode\": \"", "\"");
			} else {
				comSec = StringEscapeUtils.unescapeHtml(comSec);
				comSec = comSec.replace("Coming Soon", "").replace("(Tavistock Lakes \\u0026 Karrer)", "")
						.replace("(SR 210 and US-1)", "").replace("\\u0026", "&").replace("&amp;", "&");
				add[0] = U.getSectionValue(comSec, "Street1\":\"", "\"");
				add[1] = U.getSectionValue(comSec, "City\":\"", "\"");
				add[2] = U.getSectionValue(comSec, "State\":\"", "\"");
				add[3] = U.getSectionValue(comSec, "ZipCode\":\"", "\"");
			}
			add[0]=add[0].replace("George Liles Parkway/Roberta Road", "George Liles Parkway");
			U.log("address::::" + Arrays.toString(add));
			add[0] = add[0].replace("Pinto Drive + Aster Road", "795 Lilium Trail").replace("Woodlands", "")
					.replace("(Tavistock Lakes & Karrer)", "").replace("(Mt. Olive & Rindge)", "")
					.replaceAll(" and North Buena Vista Drive| 3 Miles West Of Us 41|2.5 miles west of I-75 and 2.5 miles east of US-41", "");
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latlong[0] = U.getSectionValue(comSec, "Latitude\":\"", "\"");
			latlong[1] = U.getSectionValue(comSec, "Longitude\":\"", "\"");

			U.log("LatLong ::" + Arrays.toString(latlong));
			if ((add[0] == null || add[0].length() < 4) && latlong[0] != null) {
				if (!add[3].isEmpty()) {
					String add1[] = U.getAddressGoogleApi(latlong);
					if(add1 == null) add1 = U.getAddressHereApi(latlong);
					if (add1 != null)
						add[0] = add1[0];
					if (add[0] == null || add[0].isEmpty())
						add1 = U.getNewBingAddress(latlong);
					if (add1 != null)
						add[0] = add1[0];
					add1 = null;
				} else {
					add = U.getAddressGoogleApi(latlong);
					if (add == null)
						add = U.getNewBingAddress(latlong);
				}
//				add = U.getAddressGoogleApi(latlong);
				geo = "TRUE";
			}
			if (add[0] != null && latlong[0] == null) {
				latlong = U.getlatlongGoogleApi(add);
				if(latlong == null) latlong = U.getlatlongHereApi(add);
//				latlong = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
//			U.log(add[0]);

			add[0] = add[0].replaceAll(
					" and North Buena Vista Drive| 3 miles west of US 41| \\(at Leander Blvd\\)|Homestead Park Office:|Model Closed| \\(Near 110 and Mozart St.\\)|, gps 528 Boston Post rd| \\(GPS: 528 Boston Post Rd\\)| \\(GPS: 528 Boston Post Rd\\)|, Gps 528 Boston Post Rd|\\(|\\)|\\\\t",
					"");
			// ==============================================================Price &&
			// SF============================================
			// U.log(U.getSectionValue(comSec, "starting-at-data ", "</div>"));
//			U.log("===================="+comSec);
			
//			U.log("::::::mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30} <span class=\"label\">Sq. Ft.</span>[\\w\\s\\W]{30}", 0));
			
			if(comUrl.contains("/the-hills-at-cielo-ranch-210245")) {
				comSec= comSec.replace("$279,490", "");
			}
			if(comUrl.contains("/laurel-glen-at-oakfield-209870")) {
				comSec= comSec.replace("$335,990", "");
			}
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String rmsecforForestLakecomm = U.getSectionValue(comSec, "Model preview tours are happening now at Citrus Isle!</p>", "Starting At</span>");
			if(rmsecforForestLakecomm!=null)comSec=comSec.replace(rmsecforForestLakecomm, "");
			comSec = comSec.replaceAll("0s|0S|0's|0&#39;s|0Ks", "0,000").replace("$338,990", "");
			comSec = comSec.replaceAll("\\s*\\$\\d{3},\\d{3} in Savings|\\$\\d{3},\\d{3}\\s*</div>", "");
			comHtml = comHtml
					.replaceAll("data-description=\"(.*)\"|content=\"(.*)\"|data-fb-pixel-model=\"(.*)\"|\"communityDescription\":\"(.*?)\"", "").replaceAll("With new homes starting in the \\$230Ks, now is a great|<p>On new homes in Clermont from the Mid-\\$200Ks w/ USDA Fixed Rate Loan</p>", "")
					.replaceAll("\\s*\\$\\d{3},\\d{3} in Savings|stat-line\">\\n*\\s*\\$\\d{3},\\d{3}\\s*</div>", "");
			comHtml = comHtml.replaceAll("0s|0S|0's|0’s|0&#39;s|0Ks", "0,000");
			comHtml = comHtml.replace("$1 million", "$1,000,000");
			comHtml = comHtml.replaceAll(
					"collapse stat-line\">\\n*\\s*\\$\\d,\\d{3},\\d{3}|\\d{2,3},\\d{3} in Savings|\\$\\d{2,3},\\d{3}\\s+</div>\\s+<div class=\"data-label\">in Savings</div>",
					"");
			comHtml = comHtml.replaceAll("collapse\">\\n*\\s*", "Upper ")
					.replace("+</span>", "</span>");
			comHtml = comHtml.replaceAll("<div class=\"CommunityHero__startingAtData\">\n\\s*", "High ");
			//comHtml=comHtml.replace("$294,990", "").replaceAll("<h4>\n\\s*$294,990\\s*</h4>", "");
			
//			U.log("mmmmmm"+Util.matchAll( comHtml + comSec, "[\\w\\s\\W]{30}298,990[\\w\\s\\W]{100}", 0));
			String[] prices = U.getPrices(comHtml + comSec,
					"<span class=\"price-amount\">\\$\\d{3},\\d{3}</span>|\\$\\d+,\\d+\n\\s*</div>\n\\s*<div class=\"CommunityHero__startingAtLabel\">Starting At</div>|From the Low-\\$\\d{3},\\d{3}|<div class=\"CommunityHero__startingAtData\">\\s+\\$\\d+,\\d+|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</h4>|Upper \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|C00000\">\n*\\s*\\$549,990|C00000\">\\n*\\s*\\$\\d{3},\\d{3}|collapse\">\\n\\s*\\$\\d{3},\\d{3}|starting-at-data\">\\s*\\$\\d{3},\\d{3}|Starting in the \\$\\d{3},\\d{3}|Upper-\\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|class=\"td starting-at\">\\$\\d{3},\\d{3}<|mid-\\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}",
					0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			//U.log(Util.matchAll(( comSec), "[\\w\\s\\W]{20}\\$27[\\w\\s\\W]{10}",0));
			
//			U.log(">>>>>>>>>>>>>>>>>>>>>"+comHtml+"\n===============");
			comHtml=comHtml.replaceAll("\\s*</h4>\n" + 
					"                    <span class=\"label\">Sq. Ft.", " Sq. Ft.");
			String[] sqft = U.getSqareFeet(comHtml.replace("–", "-"),
					"\\d,\\d{3} Sq. Ft.|sq. ft. ranging from \\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}</span> sqft|from \\d,\\d{3} to \\d,\\d{3}\\+ sf|\\d,\\d{3} - \\d,\\d{3}+ sq|\\d{4}-\\d{4}\\+ SF|\\d,\\d{3} � \\d,\\d{3} square feet|from \\d,\\d{3} - \\d,\\d{3} SF|\\d,\\d{3} to \\d,\\d{3,4} sq. ft.|<div class=\"td\">\\d,\\d{3}</div>|from \\d,\\d{3}–\\d,\\d{3} sq.ft.|\\d{1},\\d{3} to more than \\d{1},\\d{3} Sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} Sq.Ft.|\\d{4}-\\d{4} SF|\\d{1},\\d{3}–\\d{1},\\d{3} sq. ft.|<h4>\\d{1},\\d{3}</h4>|<h4>\\d{3,4}</h4>|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}\\+ Square Feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+\\+ sq. ft.|\\d,\\d+ to \\d,\\d+\\+ square feet|\\d,\\d+-\\d,\\d+\\+ Sq. Ft.|\\d+ - \\d+\\+ Square Feet|\\d,\\d+-\\d,\\d+\\+Square Feet|\\d,\\d+-\\d,\\d+\\+Sq. Ft.|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+\\+ Sq. Ft.|\\d{1},\\d{3} Square Feet|\\d,\\d+-\\d,\\d+ S.F.|\\d{4}-\\d{4} sq ft|From \\d{1},\\d{3} sq. ft|<h4>\\s*\\d,\\d{3}\\+*\\s*</h4>|ranging from \\d,\\d{3}-\\d,\\d{3} sq ft|homesite, at least \\d+,\\d{3} sf|<h4>\\s+\\d{3,4}\\s+</h4>\\s+<span class=\"label\">Sq. Ft|empty-collapse\">\\s+\\d,\\d{3}\\s+</div>\\s+<div class=\"data-label\">Sq. Ft.|Homes Ranging from \\d,\\d{3} – \\d,\\d{3} sq. ft.|Ranging From \\d,\\d{3} - \\d,\\d{3} square feet",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);
//			U.log(Util.matchAll(( comHtml), "[\\w\\s\\W]{100}1,908[\\w\\s\\W]{100}",0));

			// ------------------replace section----------
			comHtml = comHtml.replaceAll("Pulte Active Adult|Pulte Homes&#174; Active Adult|Anthem is a master-planned",
					"");
			// ==============================================================HomesData============================================

			String[] homeUrl = U.getValues(comHtml, "<div class=\"HomeDesignCompact__title\">", "</div>");
			String homeData = "";
			U.log(homeUrl.length);
			if (homeUrl.length > 0) {
				int p = 0;
				for (String string : homeUrl) {
				//	if (p < 5) {
				//		p++;
						String hUrl = "https://www.centex.com" + U.getSectionValue(string, "<a href=\"", "\"");
						U.log("Home Url=="+hUrl);
						String homeHtml=U.getHTML(hUrl);
//						if(homeHtml.contains("one-story home"))
//								{
//							U.log("FOUND");
//						}
						homeData = homeData + U.getSectionValue(homeHtml, "<div class=\"container\">", " <h3 class=\"HomePlanner__title col-xs-12\">\n" + 
								"            Customize Your Home\n" + 
								"        </h3>");

				//	} else {
				//		break;
				//	}

				}
			}

			// ==============================================================Community
			// type============================================

			String comType = ALLOW_BLANK;
			comType = U.getCommType(comHtml
					.replaceAll(
					"spending the day golfing|\\d+ Lakefront Street|Golf Rd.|Gated Children&#39;s Play Area|Pasadena Golf Course and|hampionship disc golf course, and ten picnic shelters.|ion and golf fees may |nveniently located within the master-planned community, is just a short bike ride or walk away",
					"") + comSec);
			// ==============================================================Property
			// type============================================

			rem = U.getSectionValue(comHtml, "<section id=\"plOffersEvents\"", "</section>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			String propType = ALLOW_BLANK;
			
			comHtml=comHtml.replaceAll("Custom cabinetry|Customer|Craftsman-Style Ext|<li>Craftsman Style Ext", "");
			homeData=homeData.replaceAll("Craftsman-Style Ext|Custom cabinetry|Customer|custom-feel|Custom cabinets|<li>Craftsman Style Ext", "");
			
			propType = U.getNewPropType(U.getNoHtml(homeData + comHtml.replaceAll("data-copy=\"Residents of this Centex single family|Tapatio’s Mexicano|Craftsman-Style Ext,|Custom cabinetry|not include HOA", "")).replace("Craftsman-Style Ext", "").replaceAll(
					"Fort Yargo State Park is just 8 miles away and features cottages and campsites for rent| River Mall is a traditional enclosed mal|Craftsman and Traditional Exteriors featuring Brick|Babcock-Ranch|Babcock Ranch|\"Street.*anch|-ranch-|Branch|participation|Farmhouse Style Elevation|Beautiful Farmhouse Elevation-HUGE|Gorgeous Stone Farmhouse Elevation|Stone and Farmhouse Elevation|Beautiful Farmhouse & Stone Elevation|Country Farmhouse Elevation|Farmhouse Elevation on a Large CornerLot|Farmhouse Sink in Island|data-alt=\"Farmhouse Gathering Room\"|Farmhouse Kitchen|Farmhouse Bath|Farmhouse Gathering Room",
					"") + comSec);
			
//			U.log("mmmmmm&&&"+Util.matchAll(homeData, "[\\w\\s\\W]{30}single family[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm&&&"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}single family[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm&&&"+Util.matchAll(comSec, "[\\w\\s\\W]{30}single family[\\w\\s\\W]{30}", 0));

//			U.log("mmmmmm&&&"+Util.matchAll(homeData, "[\\w\\s\\W]{30}Patio[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm&&&"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Patio[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm&&&"+Util.matchAll(comSec, "[\\w\\s\\W]{30}Patio[\\w\\s\\W]{30}", 0));

			
			U.log("propType=="+propType);
			// ==============================================================dProperty
			// type============================================

//			U.log("mmmmmm&&&"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Craftsman[\\w\\s\\W]{30}", 0));

			comHtml = comHtml.replaceAll(
					" Ranch,|1st Floor| Ranch\"|Ranch&nbsp;|ranch- |3-Story Rock Climbing Wall|Lakewood Ranch Waterside, |Rancho",
					"").replace("single- and two-story homes", "single-story and two-story homes");
			comHtml = comHtml.replaceAll("1 and 2 story|1 and 2 Story|one and two-story|1 and 2-Story|1- and 2-story ", " 1 Story  2 Story ");
			String dType = ALLOW_BLANK;
//            U.log("DDDD2==="+Util.matchAll(homeData,"one-story", 0));

      //      U.log("DDDD1"+Util.matchAll(homeData+comHtml,"[\\w\\W\\s]{20}ranch[\\w\\W\\s]{10}", 0));
            String[] remove=U.getValues(comHtml, "LocationSelectionData.locations = [{", "<div class=\"LocationSelection-Wrapper \">");
            for(String remv:remove) {
            //	U.log("REMV"+remv);
            	comHtml=comHtml.replace(remv, "");
            	homeData=homeData.replace(remv, "");
            }
			dType = U.getNewdCommType((comHtml.replaceAll("floor|Floor","")
					.replace("2 story 4 bed plus","2 story   4 bed plus")
					.replace("discover 1 &amp; 2 story homes","discover 1 story & 2 story homes")
					.replaceAll("Rio Rancho|Babcock-Ranch|Lakewood-Ranch|Babcock Ranch|Lakewood Ranch", "")
					+ homeData.replaceAll("floor|Floor","")
					.replaceAll("Rio Rancho|Babcock-Ranch|Lakewood-Ranch|Babcock Ranch|Lakewood Ranch","").replaceAll("The first floor Owner’s Suite", " 1 Story")
							.replaceAll("2-story|second Floor", "second-story")
							.replaceAll("floor|Floor|Cielo Ranch|North River Ranch|at-north-river-ranch", "")
					+ comSec.replaceAll("floor|Floor","").replaceAll("26 Storybook Lane|North River Ranch", "")).replaceAll("1 and 2 story New Home Construction|1 &amp; 2 Story", " 1 Story  2 Story ").replaceAll(
							"AlamoRanch|Bethlehem with first and second floor owner&#39;s|Babcock-Ranch|Babcock Ranch|\"Street.*anch|-ranch-|Branch|branch|North River Ranch|at-north-river-ranch",
							"").replaceAll(
									"Davis Ranch|Swayback Ranch|AlamoRanch|Babcock-Ranch|Babcock Ranch|\"Street.*anch|-ranch-|Branch|North River Ranch|at-north-river-ranch|Ranch\"|Ranch \"",
									""));
//			2 story 4 bed plus
//			U.log("homeData=="+homeData);

			 
			U.log("dType=="+dType);
			// ==============================================================Property
			// Status============================================
			
			comHtml = comHtml.replaceAll("Move-in Ready Homes|Quick Move-Ins", "");


			
			String statusTag = U.getSectionValue(comHtml, "<h4 class=\"status\">", "</h4>");
			if (statusTag == null)
				statusTag = U.getSectionValue(comHtml, "<h4 class=\"CommunityHero__status\">", "</h4>");
			String globalFeat = U.getSectionValue(comHtml, "GlobalMapsObj.featuresMarkers", "</script>");
			if (globalFeat != null)
				globalFeat = globalFeat.replaceAll("Price Coming|CommunityStatus\":\"Coming", "");

			comSec = comSec.replace("</span> Home Designs Available", " Home Designs Available")
					.replace("pool is now open", "");
			comSec = comSec.replaceAll(
					"Opening March 2019, our Pinnacle Serie|\"CommunityStatus\":\"Coming Soon\",|Price Coming Soon|\"CtaQmiText\":\"1 Quick Move-Ins Available\",\"Latitude\":\"42.455571\"|Final Home Now Selling|\"Street1\":\"Coming Soon\"|</i>Coming Soon,|Coming Soon:|Now Open, Locke",
					"");
			comHtml = comHtml.replaceAll(
					"communities, is now open|Clubhouse Coming Soon|menities are coming soon|new homes in Brookside are now|opening soon on Culebra Road| natatorium is coming in 2019|Coming Soon to the Estates|playgrounds coming soon|Amenities coming soon|ready for move in with an open floor plan|<li>ready for move in August</li>|Slab Lots Available|waterfront community is down to the final opportunities|Final Opportunities Here\\s+</a>|Restaurant is NOW OPEN|Opening March 2019, our Pinnacle Serie|VIP! Coming Soon in|<li><p>The coming soon community will be on your right|located in South Austin, is now selling homes from the high|Pricing Just Released|Just Released: |<div class=\"hours-item\">.* Coming Soon</div>|Monday Coming Soon|Price Coming Soon|Final Home Now Selling|Coming Winter 2018!\"|Pre-Sales Trailer will be on the Left|ready for move in with included basements and access to amenities. Only a few homes remain|<li>Ready to Move In Now!</li>|New Homesites Available\\!|<li>Ready for Move In Now!</li>|<li>Opening Spring 2018</li>|Just Released\\&quot; Amenity|NOW SELLING from Lochaven|home in the coming soon community of| is Coming Soon to Reston|\"Street1\":\"Coming Soon\"| <li>Coming Fall 2018</li>|</i>Coming Soon,|>\\s*Coming Soon,|Closing soon, limited inventory remains|<p><p>Homes are selling fast|Our first release|in our first release|pool is now open|community opening in early 2018|schools opening this fall|Opening Spring 2019, Pulte|Retail Area Opening Soon|CRYSTAL LAGOON OPENING SOON|Spradley, opening fall 2018|Final opportunity for the Lynwood |<li>Final Opportunity for 2018|slated to open in early 2018|caption\">Coming Winter 2018|<li>Grand Opening this Winter<|Exteriors Coming Soon|Coming Soon: a multi|Amenity Center Coming Fall 2018|Gathering Area - Coming 2019|Grand Opening of the Continental|Last chance to move in |year&nbsp;and homesites are selling fast| stores now open|Designs Now Available|is now available|Model Opening September 2018|Lake View Lots Available|Spacious Lots Available</li>|sac Lots Available|Grand Opening August|grand opening on Saturday|grand opening in August|New Building Grand Opening|tours are now open|now available for your new dream|grand opening information|grand opening on July|div class=\"StatusTag\">Sold Out</div>|now available for quick move-in|The Coming Soon Community will be|more information on this Coming Soon community|Clubhouse Opening Soon|courts - are opening soon|US, opening soon|Quick Move|quick move|now available at|Quick move| fast selling|Lake Coming Winter 2018|Dining Coming Soon|Price Coming Soon|>Coming Soon|\"Coming Soon|- Coming Soon|Coming Soon -|\"Coming Soon:|Temporarily sold out",
					"").replace("(coming soon)", "").replace("Launch) Coming Soon", "")
					.replace("Now Selling for Summer 2019", "Now Selling Summer 2019")
					.replaceAll("qmi-inventory hidden-xs\">\\s+<ul>\\s+<li>READY TO MOVE|(Center|Amenities) Opening|Our Model Homes and Quick Move-in Homes are Open",
							"")
					.replaceAll(
							"(space|course) home site|host our Grand Opening|<div class=\"StatusTag\">Almost Sold Out</div>|Model Home Park Now Open|Acre\\+ Home Sites|(P|p)ool now|clearfix\">\\s+<p>Currently Sold|class=\"hours-item\"> Currently Sold|Center (is )?Now |Opening of \\d Models|our official Grand|Lucero (New )?Homes Now Available|Series Homes Now|Available Now in Peoria|Released: (Amenity|Entry|View)|renderings just|Map Now|chance to own new|Our Model Homes and Quick Move-in Homes are Open|Purchase a quick move-in home",
							"")
					.replaceAll(
							"Drop Zone&quot; - Now Open|class=\"StatusTag\">Last Chance|opening Fall 2019. Join our|hours-item\"> Almost Sold|<p>Almost Sold Out!|hours-item\"> Grand Opening Fall 2019|Now Open, Locke Pointe|Now Available with Optional|class=\"hours-item\"> Grand Opening (Late Summer)?",
							"");

//			U.log("---"+statusTag);
//			U.log(comHtml);
//			U.log(comSec);
			// ====== Remove Section =====

			String imgStatus = U.getSectionValue(comHtml, " <span class=\"caption\">", "<")
					+ U.getSectionValue(comHtml, "<div class=\"Community-status-flag\"", "</div>");
			rem = U.getSectionValue(comHtml, "<section id=\"plOffersEvents", "</section>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");

			rem = U.getSectionValue(comHtml, "<ul class=\"list-unstyled\">", "</ul>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			
			rem = U.getSectionValue(comHtml, " GlobalMapsObj.nearbyMarkers =", "</script>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			
		//	comHtml = comHtml.replace("Coming in Late 2020", "Coming Late 2020");
			comHtml = comHtml.replaceAll(
					"Now Selling from Ridgeview|=Brand New Move-In|\"Brand New Move-In|caption\">Brand New Move-In|=New Move-In|\"New Move-In|caption\">New Move-In|caption\">Move-In|\"Move-In|=Move-In|Appointments Preferred - New Section Coming Soon|Look for our next and final phase|Ferndale Place Now Selling|Place Now Selling</span>|Place Now Selling\"|Move-In Ready Homes Available</span>|Move-In Ready Homes Available\"|Move-In Ready Homes For Sale</span>|Move-In Ready Homes For Sale\"|caption\">Move-In Ready Homes</span>|Move-In Ready Homes\"|Facebook Live Grand Opening|Virtual Grand Opening Event|Live Grand Opening Recap|Price Coming Soon|Amenity Coming Soon|Now Open in New Braunfels|natatorium is now open|Chophouse are now open|Special Limited-Time Offer|Cul-de-sac Home Sites|Cul-de-sac home sites|Model opening early|Pond View Home Sites|Now selling final opportunities by appointment|wooded lots. Almost sold|Amenity Now Open|New Homes Coming Soon\"|Brand New Homes Coming Soon</span>|ion\">New Homes Coming Soon</span>|caption\">Move-In Ready Homes in PHX</span>|Move-In Ready Homes in PHX\"",
					"");

			if (imgStatus!=null) {
				imgStatus=imgStatus.replaceAll("Ferndale Place Now Selling", "");
			}
			String html2 = U.getHTML(comUrl);
			String addFeatures = U.getSectionValue(html2, "<h3>Additional Features</h3>", "</ul>");
			String head = U.getSectionValue(html2, "<h4 class=\"CommunityHero__status\">", "</h4>");
			
			comHtml=comHtml.replace("The final phase at Spence Creek is now open", "The final phase now open")
					.replaceAll("Now Selling! Offering the same great|\"Move-In Ready Home Available Now\"|caption\">Move-In Ready Home Available Now<|<li>Cul-de-sac home sites available</li>\n\\s*<li>Homes include|<li>Spacious, Cul-de-Sac Homesites|<li>Cul-de-Sac Homesites Available</li>\n\\s*<li>Convenient|quick move-in homes are excluded|no Quick Move-Ins available|Quick Move-in Homes are Open|Parrish are now available|Model opening 2021", "")
					.toLowerCase().replace("quick move-in home", "");
			
			if(addFeatures!=null)
			addFeatures = addFeatures
					.replaceAll("<li>Cul-de-sac home sites available</li>\n\\s*<li>Homes include|Model opening 2021", "");
					//.replaceAll("<li>Cul-de-Sac and Wooded Lots Available</li>", "<li>Wooded Lots Available</li>");
			comSec = comSec.replaceAll("townhome homesites coming soon", "");
			
			
			U.log(quickCount+"this is quick count");
			if(quickCount!=null && quickCount.contains("(0)"))quickCount="";
			else if(quickCount!=null ) quickCount = "Quick Move-ins Available";
			//U.log(quickCount+"::this is quick count");
//			U.writeMyText(addFeatures+imgStatus + comSec + globalFeat + comHtml + statusTag);
			if(head!=null)
				head = head.replace("Opening in Mid-2021", "Opening Mid 2021");
			if(imgStatus!=null)
			imgStatus = imgStatus.replace("Opening in Spring 2022", "Opening Spring 2022").replaceAll("Coming Soon in 2022|coming soon in 2022", "coming soon 2022")
				.replaceAll("New Homes Coming Soon", "");
			U.log("imgStatus: "+imgStatus );
			
			String [] stsFromImg=U.getValues(html2, "<div class=\"Image-caption\" title=\"", "</div>");
			if(stsFromImg.length>0) {
				for(String sts :stsFromImg) {
					imgStatus+="\n"+sts;
				}
			}
//			U.log("imgStatus: "+imgStatus );

			String commfrontstatus=U.getSectionValue(U.getHTML(comUrl), "<h4 class=\"CommunityHero__status\"", "</h4>");

			U.log("Upper Status: "+commfrontstatus);
			if(commfrontstatus!=null)
				commfrontstatus = commfrontstatus.replace("Opening in Late 2021", "Opening Late 2021").replace("Opening in Mid-2022", "Opening Mid 2022")
				.replace("Opening in Early 2022", "Opening Early 2022")
				.replace("Opening in Early 2021", "Opening Early 2021").replace("Opening in Mid-2022", "Opening Mid 2022").replace("Grand Opening In Summer 2021", "Grand Opening Summer 2021");
			
		//	U.log("addFeaturesSECV"+addFeatures);
			
//			U.log("mmmmmm===="+Util.matchAll((commfrontstatus+addFeatures+imgStatus + comSec + globalFeat + comHtml + statusTag + head+quickCount).replaceAll("<div class=\"StatusTag\" data-automation=\"\">[s|S]old [o|O]ut</div>", ""), 
//					"[\\w\\s\\W]{30}Now open[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm===="+Util.matchAll((comHtml),"[\\w\\s\\W]{30}<div class=\"GlanceViewSection qmigallery\">[\\w\\s\\W]{30}", 0));
			String rem11=U.getSectionValue(comHtml, "<div class=\"glanceview\">", "<div class=\"glanceviewsection qmigallery\">");
//			U.log(">>>>"+rem11);
			if(rem11!=null) {
				comHtml=comHtml.replace(rem11, "");
			}
			
			comHtml=U.removeSectionValue(comHtml, "<div class=\"GlanceView\">", " <div class=\"GlanceViewSection qmilist\">");
			comHtml=comHtml.replaceAll("is now selling!|but serenoa lakes is now selling|Now Selling! Offering the same great location and amenities|"
					+ "Rainbow Canyon is Opening Soon|rainbow canyon is opening soon|move-in ready homes", "");
		
			comSec = comSec.replaceAll("Now Selling! Offering the same|rainbow canyon is opening soon|move-in ready homes", "");
			
			String commDetail=U.getSectionValue(comHtml, "<div class=\"row CommunityOverview__information", " </section>");
			
			imgStatus=imgStatus.replaceAll("Move-In Ready Homes|Quick Move-Ins", "");
			String propertyStatus = U.getNewPropStatus((commDetail +addFeatures+imgStatus + comSec + globalFeat +  statusTag + head+commfrontstatus)
					//.replace(">Wooded Lots Avail", "Wooded Lots Available")
					.replaceAll("Move-in Ready Homes|Quick Move-Ins", "")

					.replaceAll("CtaQmiText\":\"\\d+ Quick Move-Ins Available", "")
					.replaceAll("\"CommunityStatus\":\"Quick Move-Ins Available\"", "")
					.replaceAll("[P|p]ulte [h|H]omes [p|P]hase [n|N]ow [s|S]elling|[n|N]ow [s|S]elling\"|[n|N]ow selling in our new [p|P]ulte|grand opening event|grand opening detail|beat move-in|=Move-in|\"Move-in|class=\"caption\">Move-in|now selling new homes in murfre|Chophouse are now open in Nexton|coming soon to kissim|5 homes remain at fountai|data-alt=\"now selling new homes\"|caption=\"now selling new homes\"|description=now selling new homes\"", "")
					.replaceAll("\"CtaQmiText\":\"1 Quick Move-Ins Available\"", "").replaceAll(" data-med, c/v/344625/13&amp;description=new homes available now\"|<span class=\"caption\">new homes available now</span>|brand new homes available now|data-image-caption=\"new homes available now\"|data-alt=\"new homes available now\"|marana homes coming soon|Coming Soon, Marana Homes Coming Soon", "")
					.toLowerCase().replace("quick move-in home", "").replace("and playground now open", "")
					.replaceAll("<div class=statustag data-automation=>sold out</div>|dog park coming soon|fitness center coming soon|lazy river coming soon|amenities coming soon|statustag\" data-automation=\"\">sold out</div>|\"CommunityStatus\":\"Grand Opening\",\"|[g|G]rand [o|O]pening \\d+\\.\\d+</li>|Ready to move into in October|crossing move-in ready|available now\"|\"CtaQmiText\":\"1 Quick Move-Ins Available\"|(sushi|center|clubhouse|park) coming|coming soon to san antonio get", ""))
					.replaceAll("\\d+ Quick Move-ins Available", "Quick Move-ins Available");
			
			U.log("  propertyStatus: " + propertyStatus);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(commDetail +addFeatures , "[\\s\\w\\W]{100}Move-in Ready Homes[\\s\\w\\W]{100}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll( globalFeat +  statusTag    , "[\\s\\w\\W]{100}Move-in Ready Homes[\\s\\w\\W]{100}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(imgStatus + comSec , "[\\s\\w\\W]{100}Move-in Ready Homes[\\s\\w\\W]{100}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(head+quickCount+commfrontstatus , "[\\s\\w\\W]{100}Move-in Ready Homes[\\s\\w\\W]{100}", 0));

			if(propertyStatus!=null) {
				propertyStatus=propertyStatus.replace(", ,", ", ");
			}
			/*
			 * if (propertyStatus.contains("Quick Move-ins") &&
			 * propertyStatus.contains("Coming Soon")) { propertyStatus =
			 * propertyStatus.replace("Coming Soon", ""); propertyStatus =
			 * U.getNewPropStatus(propertyStatus + coming); }
			 */
			if (comUrl.contains("/fort-myers/enclaves-at-eagle-landing-210421")) {
				add[0] = U.getAddressGoogleApi(latlong)[0];
				geo = "TRUE";
			}
			
			if(commfrontstatus!=null)
			if(commfrontstatus.contains("data-automation=\"communityStatus\">Coming Soon") && !propertyStatus.contains("Coming Soon"))
				if(propertyStatus==ALLOW_BLANK)
					propertyStatus = "Coming Soon";
				else
					propertyStatus = "Coming Soon, "+propertyStatus;
			U.log("*** " + propertyStatus);

			String notes = U.getnote(comHtml.replaceAll(
					"Pre-Selling Appointments|vip pre-selling|Pre-Sales Gallery|out serenoa lakes - now pre-selling|our new homes for sale|Find new homes for sale|is open for sale from the Pre-Sales Gallery|open for sale from|Pulte’s new homes for sale",
					""));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml , "[\\s\\w\\W]{30}Pre-Selling[\\s\\w\\W]{30}", 0));

			if (add[0].length() < 1) {
				add[0] = U.getAddressGoogleApi(latlong)[0];
//				add[0]=U.getAddressGoogleApi(latlong)[0];
				geo = "TRUE";
			}
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]).trim();
			}
			if (add[0].contains(",")) {
				String temp[] = add[0].split(",");
				add[0] = temp[0];

			}
			add[0] = add[0].toLowerCase().replace("&amp;", "");
			if (propertyStatus.contains("New Section Now Available") && propertyStatus.contains(",Now Available"))
				propertyStatus = propertyStatus.replaceAll(",Now Available", "");
			if (propertyStatus.contains("Quick Move-ins Available") && propertyStatus.contains(", Now Available"))
				propertyStatus = propertyStatus.replaceAll(", Now Available", "");
			if (propertyStatus.contains("Grand Opening This Fall"))
				propertyStatus = propertyStatus.replaceAll("Grand Opening This Fall, Opening This Fall",
						"Grand Opening This Fall");
			if (propertyStatus.contains("Grand Opening Fall 2019"))
				propertyStatus = propertyStatus.replaceAll("Grand Opening Fall 2019, Opening Fall 2019",
						"Grand Opening Fall 2019");
			if (propertyStatus.contains("Grand Opening 2019"))
				propertyStatus = propertyStatus.replaceAll("Grand Opening 2019, Opening 2019", "Grand Opening 2019");

			if (comUrl.contains("https://www.centex.com/homes/texas/houston/conroe/the-pines-at-seven-coves-210502"))
				propertyStatus = propertyStatus.replace(", Grand Opening", "");

			comHtml = U.getHTML(comUrl);
			
			if((comHtml.contains("Financing Through USDA") || comHtml.contains("<li>USDA Loan Eligible</li>")|| comHtml.contains("<li>USDA loan eligible</li>"))
					&&!(propertyStatus.contains("USDA")||propertyStatus.contains("Usda"))) {
				if(propertyStatus != ALLOW_BLANK)propertyStatus = propertyStatus + ", USDA Loan Eligible";
				else if(propertyStatus == ALLOW_BLANK)propertyStatus = "USDA Loan Eligible";
			}
			
			propertyStatus = propertyStatus.replaceAll(", Move-in Ready Homes|, Quick Move-in Home|Ready For Move In, ", "");
			
			if(comUrl.contains("ardmore-freedom-series-210393") || comUrl.contains("woods-at-grey-oaks-210521") || comUrl.contains("fuquay-varina/hidden-valley-210133"))
			{
			if(propertyStatus.contains("Quick Move-ins") && !propertyStatus.contains("Quick Move-ins Available"))	
				propertyStatus=propertyStatus.replace("Quick Move-ins", "Quick Move-ins Available");
			}
			if(comUrl.contains("https://www.centex.com/homes/arizona/tucson/marana/gateway-at-gladden-farms-210705"))
			{
				propertyStatus=propertyStatus.replace(" Coming Soon", "");
				//propertyStatus="Now Open, "+propertyStatus+", Quick Move-ins Available";
			}
			if(comUrl.contains("https://www.centex.com/homes/florida/orlando/kissimmee/cypress-cay-210672"))
			{
				dType="1 Story, 2 Story";
			}
           
			if (comUrl.contains("south-carolina/charleston/summerville/sanctuary-cove-at-cane-bay-210100"))propertyStatus="New Phase Coming Soon, Phase 5 Coming Soon, New Homesites Coming Soon";//====remm
			if (comUrl.contains("https://www.centex.com/homes/florida/orlando/polk-city/fountain-park-209549"))propertyStatus = propertyStatus.replaceAll("Less Than 5 Opportunities Remain, Less Than 5 Homes Remain", "Less Than 5 Opportunities Remain");
			if(comUrl.contains("https://www.centex.com/homes/florida/tampa/wesley-chapel/wesley-reserve-at-chapel-crossings-210684"))propType+=", Coastal Style Homes";//from img
			
//			if(propertyStatus.contains("Quick Move-ins") && !propertyStatus.contains("Quick Move-ins Available"))
//			{
//				propertyStatus=propertyStatus.replace("Quick Move-ins", "Quick Move-ins Available");
//			}
			if (comUrl.contains("https://www.centex.com/homes/south-carolina/charleston/summerville/sanctuary-cove-at-cane-bay-210100")) propertyStatus = propertyStatus.replace(", Coming Soon", ", Phase 5 Coming Soon"); //from img - 11 feb.dattaraj
			if(comUrl.contains("https://www.centex.com/homes/texas/houston/magnolia/myrtle-gardens-210960"))propertyStatus="Coming Soon in Fall 2022";
			if(comUrl.contains("https://www.centex.com/homes/texas/houston/cypress/marvida-210893"))propertyStatus="Coming Soon in 2022";
			if(comUrl.contains("https://www.centex.com/homes/texas/houston/porter/peppervine-210914"))propertyStatus="Coming Soon in 2022";
		
//			if(comUrl.contains("raleigh/540-west-210338")||
//					comUrl.contains("fuquay-varina/hidden-valley-210133") ||
//					comUrl.contains("summerville/bradford-pointe-210178") ||
//					comUrl.contains("myrtle-beach/conway/heritage-preserve-209595"))
//				{
//				propertyStatus=propertyStatus.replace("Quick Move-ins Available", "");
//			}
//		if(propertyStatus.length()==0) {
//			propertyStatus=ALLOW_BLANK;
//		}
			propertyStatus=propertyStatus.replaceAll(",Quick Move-ins Available|Quick Move-ins Available,|Quick Move-ins Available|, Quick Move-ins", "");
			int quick_Count=0;
			String [] quickHomes=U.getValues(comHtml, "<div class=\"QmiSummary-SeriesFlex \">", "View Home");
			U.log("quickHomes=="+quickHomes.length);
			if(quickHomes.length==0)
				quickHomes=U.getValues(comHtml, "<div class=\"HomeDesignSummary--qmi clearfix", "View Home");
			U.log("quickHomes=="+quickHomes.length);

			for(String quickHome :quickHomes) {
				if(quickHome.contains("<div class=\"data-value u-no-empty-collapse\">\n" + 
						"                        Available Now")
						||quickHome.contains("<div class=\"data-value u-no-empty-collapse\">\n" + 
								"                        Contact Us") ) {
					quick_Count++;
				}
			}
			if(quick_Count>0) {
			if(propertyStatus.length()>2) {
				propertyStatus+=", Quick Move-ins";
			}
			else {
				propertyStatus="Quick Move-ins";
			}
			}
			
			U.log("propertyStatus============\n"+propertyStatus);
			propertyStatus=propertyStatus.replaceAll("Now Open Available", "Now Open");

			if(propertyStatus.length()==0) {
				propertyStatus=ALLOW_BLANK;
			}
			
			String siteMapSec=U.getSectionValue(comHtml,"<h2></strong>Homesite Map</strong> </h2>", "Open Interactive Map</a>");
			String noOfUnits=ALLOW_BLANK;
			String noOfUnits1=ALLOW_BLANK;
			int lotCCount=0;
			
			String sitemapJsonurl=null;
			if(siteMapSec!=null) {
				
			String siteMapUrl=U.getSectionValue(siteMapSec, "href=\"", "\"");
			U.log("1ST sitemap Url: "+siteMapUrl);
			
			if(siteMapUrl.contains("OLAId=")&&siteMapUrl.contains("&amp")) {
				//siteMapUrl=siteMapUrl.replace("vps1.", "").replace("ola/nexGenOLA.html?OLAId=", "olajson/")+".json?";
				//siteMapUrl=siteMapUrl.replace("http://vps1.alpha-vision.com/ola/nexGenOLA.html?", "https://apps.alpha-vision.com/alphamap/index.html?").replace("&amp;","&");
			String partKey=U.getSectionValue(siteMapUrl, "OLAId=", "&amp");
			U.log("PartKey=="+partKey);
			
			if(partKey.contains("==") || partKey.contains("+")) {
				
				String subMapUrlEncode = URLEncoder.encode(partKey, "UTF-8");
				U.log("subMapUrlEncode: "+subMapUrlEncode);
				String guiIdLink = "https://services.alpha-vision.com/api/apiola/IsAlphamapActive?olaId=" + subMapUrlEncode;
				U.log("guiIdLink: "+guiIdLink);
				String guiHtml = U.getHTML(guiIdLink);
				U.log(U.getCache(guiIdLink));
				String guiId = U.getSectionValue(guiHtml, "\"GUID\":\"", "\"");
				U.log("guiId: "+guiId);
				if(guiId==null) {
					guiId = U.getSectionValue(guiHtml, "<GUID>", "</GUID>");
				}
				U.log("guiId: "+guiId);
				String jsonUrl = "https://apps.alpha-vision.com/olajson/" + guiId + ".json";
				U.log("jsonUrl guiId: "+jsonUrl);
				sitemapJsonurl = jsonUrl;
			}
			else {
				String jsonUrl = "https://apps.alpha-vision.com/olajson/" + partKey + ".json";
				U.log("jsonUrl_One: "+jsonUrl);
				sitemapJsonurl = jsonUrl;
			}
			
			//String mapUrlforGrpId="https://services.alpha-vision.com/api/apiola/IsAlphamapActive?olaId="+URLEncoder.encode(partKey, "UTF-8");
//			U.log("URLLLLLL"+mapUrlforGrpId);
//			String HtmlfrGrpId=U.getHTML(mapUrlforGrpId);
//			U.log("KKKKKKKKK::"+HtmlfrGrpId);
			}	
			else
			{
				String[] olaIds=siteMapUrl.split("OLAId=");
				sitemapJsonurl="https://apps.alpha-vision.com/olajson/"+olaIds[1].trim()+".json?";
				sitemapJsonurl=sitemapJsonurl.replaceAll("==&amp;languageId=1|&amp;languageId=1","");
				U.log("Sitemap JSON url:: "+sitemapJsonurl);
				
			}
				
		/*		
			U.log("SiteMap Url:: "+siteMapUrl);
			String sitemapJsonurl=siteMapUrl.replace("alphamap/index.html?OLAId=", "olajson/")+".json?";*/
		//	String sitemapJsonurl="https://apps.alpha-vision.com/olajson/2cd2d2a2-4072-4452-b790-c4e89428178e.json?_=1649245421521";
			
			String sitemapJsonData=U.getPageSource(sitemapJsonurl);
			U.log("Path:: "+U.getCache(sitemapJsonurl));
			String MapJsonData=U.getSectionValue(sitemapJsonData, "pre-wrap;\">", "</pre></body></html>");
			JsonParser parser =new JsonParser();
			Object obj=null;
			if(MapJsonData!=null)
				obj =parser.parse(MapJsonData);
			else
				obj=parser.parse(sitemapJsonData);
			JsonObject siteJsonObj = (JsonObject)obj;
			JsonArray lotGroups=(JsonArray) siteJsonObj.get("LotGroups");
			for(int i=0;i<lotGroups.size();i++)
			{
				JsonObject lot=(JsonObject) lotGroups.get(i);
				String lotCount=lot.get("LotCount").getAsString();
				lotCCount +=Integer.parseInt(lotCount);
			}
			if(comUrl.contains("https://www.centex.com/homes/florida/orlando/clermont/cagan-crossings-210575")||
					comUrl.contains("tampa/plant-city/north-park-isle-210737")||
					comUrl.contains("south-bloomfield/bloomfield-hills-210578")) 
			{
				U.log("MAP WITHOUT PHASES >>>>>> "+Util.matchAll(sitemapJsonData, "[\\s\\w\\W]{50}layers/main_lots[\\s\\w\\W]{30}", 0));
				String urlForCount = Util.match(sitemapJsonData, "/homebuilders/\\d+/communities/\\d+/siteplans/\\d+/layers/main_lots_\\d+.svgz");
				urlForCount = "https://apps.alpha-vision.com" + urlForCount;
				
				U.log("urlForCount: "+urlForCount);
				
				String dataForCount = U.getPageSource(urlForCount);
				U.log(U.getCache(urlForCount));
				
				String[] getCount = U.getValues(dataForCount, "class=\"lot\"", ">");
				U.log("getCount: "+getCount.length);
				
//				 String unitsNumber = String.valueOf(getCount.length);
//				 U.log("unitsNumber: "+unitsNumber);
				lotCCount=getCount.length;
			}
			}
			
			
			noOfUnits=Integer.toString(lotCCount);
			
			if(noOfUnits.equals("0"))
				noOfUnits=ALLOW_BLANK;
			
			
			U.log("Number Of Units="+noOfUnits);
			String startDate=ALLOW_BLANK;
			String endDate=ALLOW_BLANK;
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(notes);
			data.addConstructionInformation(endDate, endDate);
			data.addUnitCount(noOfUnits);
			
			
			

		}
//		catch(Exception e) {}
		j++;
		
	
	}

}