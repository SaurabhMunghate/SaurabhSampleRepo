/*
 * @ Modified By : Pallavi
 * @Date : July2018
 */


package com.shatam.b_001_020;

import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractCalAtlanticHomes extends AbstractScrapper {
	static int count = 0;
	public int i = 0;
	public int inr = 0;
	public static int dup = 0;
	CommunityLogger LOGGER;
	HashSet<String> dupRegionUrl=new HashSet<String>();  
	private String baseUrl = "https://www.calatlantichomes.com";
	// WebDriver driver=new FirefoxDriver();

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCalAtlanticHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/CalAtlantic Homes.csv", a
				.data().printAll());
		U.log("duplicates==" + dup);
	}

	public ExtractCalAtlanticHomes() throws Exception {
		super("CalAtlantic Homes", "https://www.calatlantichomes.com");
		LOGGER = new CommunityLogger("CalAtlantic Homes");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.calatlantichomes.com/find-your-new-home.html");
		String regionSection = U.getSectionValue(html, "<div class=\"flyout\">", "<div class=\"flyout\">");

		String regionUrls[] = U.getValues(regionSection, "<a href=", ">");
		for(String regionUrl : regionUrls){
			Pattern p = Pattern.compile("[0-9]+");
			Matcher m = p.matcher(regionUrl);
			  if(m.find()){ 
				  String regUrl = U.getSectionValue(regionUrl, "\"", "\"");
//				  U.log("regUrl::"+regUrl);
				  dupRegionUrl.add(baseUrl+regUrl); //adding region in HashSet
				//  break;
			  }
		}
	
		//iterating the region hashset
		Iterator<String> itr=dupRegionUrl.iterator();  
		  while(itr.hasNext()){  
		//   System.out.println(itr.next());  
		   findCommunity(itr.next());
		  }  

		
		LOGGER.DisposeLogger();
	}
	private void findCommunity(String regionUrl) throws Exception{
		U.log("regionUrl::"+regionUrl);
//		if(regionUrl.contains("6-miami-ft-lauderdale-palm-beach"))return;
	//	if(!regionUrl.contains("20-san-antonio"))return;
		String html = U.getHTML(regionUrl);
	
		String[] communitySections;
		html=html.replaceAll("</div>\\s*</li>","endsec");//("</li>\\s*</ul>\\s*</div>", "endsec");
		if(regionUrl.contains("https://www.calatlantichomes.com/find-your-new-home/15-los-angeles.html")){
			communitySections= U.getValues(html, "<div class=\"pic\">", "<div class=\"division-office");
		}
		else{
			communitySections=U.getValues(html, "<div class=\"pic\">","endsec" );//"<li class=\"community listing\" data-name");
		}
		//U.log("No .of Communities::::::::"+communitySections.length);
		if(html.contains("<title>Lennar Homes for Sale")){
			LOGGER.AddRegion(regionUrl+"::::::::::::Region Redirected To Lennar::::::::::::;", communitySections.length);
		}
		else{
			LOGGER.AddRegion(regionUrl, communitySections.length);
		}
		
		
		int i=0,j=0;
		for(String commSection : communitySections){
//			if(i == 2){
			String communityUrl = U.getSectionValue(commSection, "href=\"", "\"");
			//U.log(commSection);
			//U.log("commSection:::"+commSection +"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
			commSection = commSection.replaceAll("</li>\\s*</ul>\\s*</div>\\s*</li> ", "shatam");
			//==================
			String remComSec =U.getSectionValue(commSection, "<div class=\"list-communities \" data-name=\"","shatam");
			//U.log("remove::"+remComSec);
			if(remComSec!=null){
				commSection=commSection.replaceAll(remComSec, "");
			}
			//==================
			
			addDetails(baseUrl+communityUrl,commSection);
		
			//}
			i++;
			//U.log(i);
			//break;
		}
		
	}
	private void addDetails(String comUrl,String regionSection) throws Exception {
		//if(!comUrl.contains("7847-chapel-creek-village.html"))return;
		//if (i==173) 
		{
		//if (!comUrl.contains("https://www.calatlantichomes.com/find-your-new-home/34-raleigh-durham/7851-lake-castleberry-the-bluffs.html"))return;

		if(comUrl.contains("https://www.calatlantichomes.comhttp"))comUrl = comUrl.replace("https://www.calatlantichomes.comhttp", "https");
		
		if (comUrl.contains("https://www.calatlantichomes.com/find-your-new-home/2-austin/5032-the-crossings-at-twin-creeks.html"))return;// redirect to main page
		if (comUrl.contains("https://www.calatlantichomes.com/find-your-new-home/2-austin/7578-crossings-at-twin-creeks.html"))return;
		if (comUrl.contains("https://www.calatlantichomes.com/pages/1916-chicago-the-manors-at-brookmere.html"))return;
		if (comUrl.contains("https://www.calatlantichomes.com/find-your-new-home/26-baltimore/5043-admirals-ridge-townhomes.html"))return;
		if (comUrl.contains("https://www.calatlantichomes.com/find-your-new-home/26-baltimore"))return;
		
		//U.log("regionSection::::::::::::::::"+regionSection);
		U.log("count=== " + i + "\n" + comUrl);
		String geo = "False";
			
		String html = U.getPageSource(comUrl);
		String html1 = html;
		
		if(html.contains("title=\"Lennar\">")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::::::Community Redirected To Lennar::::::::::::");
			return;
		}
		
		
		// U.log("HELLO");
			/* -------------- Community Name ----------------- */
			String commName = U.getSectionValue(html, "<h1>", "<").trim();
			U.log("commName :" + commName + "Hello");
			
			//U.log("commName :" + commName + "Hello");
			commName = commName.replace(" Quick Move Ins", "").replaceAll("\\d Car Garage", "");
			commName = commName.replace("&amp;", "&").replace("�", "n").replace("Andar?", "Andare").replace("Ava?a", "Avana").replace("Celestina ? The Sanctuary ", "Celestina - The Sanctuary ");
			commName = commName.replace("celestina – the", "celestina - the");
			commName = commName.toLowerCase().replaceAll(" active adult| two-car garage|traditional townhomes|- townhomes|- single-family homes| condominiums| single family homes| townhomes| quick move ins|&#39;| single family","");
			if (commName.endsWith("villas"))commName = commName.replace("villas", "");
			if (commName.endsWith("carriage homes"))commName = commName.replace("carriage homes", "");
			if (commName.endsWith("estate homes"))commName = commName.replace("estate homes", "");
			if (commName.endsWith("twin homes"))commName = commName.replace("twin homes", "");
			if (commName.endsWith("single-family homes")|| commName.endsWith("single-family"))commName = commName.replaceAll("single-family homes|single-family", "");
			if(commName.trim().contains("two story"))commName=commName.replaceAll("two story","");
			if(commName.trim().contains("ranch style"))commName=commName.replaceAll("ranch style", ""); 
			commName=commName.replace("�", "n").replace(" � ", " - ");
			commName=commName.replace("�", "e");
			U.log("commName :" + commName + "Hello");

			//=====remove extra addsec
			html=html.replace("<span itemprop=\"streetAddress\">We", "");
			
			/* --- Address-lat-long ----  */
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK, ALLOW_BLANK };
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
			html = html.replaceAll("\"streetAddress\">\\s*For GPS: Please", "").replaceAll("<span itemprop=\"streetAddress\">\\W+GPS ADDRESS", "");
			html=html.replaceAll("<span itemprop=\"streetAddress\">\\s*We've Moved", "").replace("Model Home Coming Soon!", "");
			html=html.replaceAll("\\s+", " ");
			html=html.replace("<span itemprop=\"streetAddress\"> Located", "");
			U.log("Street"+U.getSectionValue(html,"<span itemprop", "</span>"));
			add[0] = U.getSectionValue(html,"<span itemprop=\"streetAddress\">", "</span>");
			add[1] = U.getSectionValue(html,"<span itemprop=\"addressLocality\">", "</span>");
			add[2] = U.getSectionValue(html,"<span itemprop=\"addressRegion\">", "</span>");
			add[3] = U.getSectionValue(html, "<span itemprop=\"postalCode\">","</span>");
			add[0] = (add[0] == null) || add[0].length() < 3 ? ALLOW_BLANK: add[0];

			add[1] = (add[1] == null) ? ALLOW_BLANK : add[1];
			add[2] = (add[2] == null) ? ALLOW_BLANK : add[2].trim();
			add[3] = (add[3] == null) ? ALLOW_BLANK : add[3];
			//U.log("street:::"+U.getSectionValue(html,"<span itemprop=\"streetAddress\">", "</span>"));
			if (add[0].toLowerCase().contains("now selling") || add[0].contains("visit") || add[0].contains("TBD")
					|| add[0].contains("No Model") || add[0].contains("Coming Soon") || add[0].contains("Sales "))
				add[1] = ALLOW_BLANK;

		
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]+ " Z:" + add[3]);
			
			latLong[0] = Util.match(html,"place.location.latitude\" content=\"(\\d+.\\d+)", 1);
			latLong[1] = Util.match(html,"place.location.longitude\" content=\"(-\\d+.\\d+)", 1);
			lat = (latLong[0] != null) ? latLong[0] : ALLOW_BLANK;
			lng = (latLong[1] != null) ? latLong[1] : ALLOW_BLANK;

			U.log("Lat:" + lat + " Long:" + lng);

			if (add[0] == ALLOW_BLANK) {
				String[] adr = U.getAddressGoogleApi(new String[] { lat, lng });
				if (adr != null)
					add[0] = adr[0];
				geo = "True";

			}
			add[0] = add[0].toLowerCase().replace("tbd","").replace("&amp;","&").replace("sales center coming soon", "").replace("coming summer 2014", ALLOW_BLANK).replace("coming soon", ALLOW_BLANK).replace("currently sold out", ALLOW_BLANK).replace("future lot 1", ALLOW_BLANK);
			add[0] = add[0].replaceAll("&amp;|(|)", "");
			// U.log("Street::"+add[0]);
			if (add[0].trim().length() > 100)
				add[0] = ALLOW_BLANK;

			add[0] = add[0].trim().toLowerCase().replaceAll("visit us at meridian crossing to learn more|\\(located at deer springs and hualapai\\)|\\(located at sunset and buffalo\\)|\\(located at buffalo and russell\\)|model closed|by appt only",ALLOW_BLANK);
			add[0] = add[0].replace("homesite #5 - ", "");

			if (add[0] == ALLOW_BLANK || add[0].length() == 1) {
				String address[] = U.getAddressGoogleApi(latLong);
				U.log(address[1] + "address-->" + add[1].trim());
				add[1] = add[1].trim();
				if (address[1].contains(add[1])) {
					U.log(address[1] + "address-->" + add[1]);
					add[0] = address[0];
					geo = "True";
				}
			}

			if (add[0].contains("<"))
				add[0] = ALLOW_BLANK;
			add[1] = add[1].toLowerCase().replaceAll("(hse schools)", "");
			if (add[3].trim().length() != 5)
				add[3] = ALLOW_BLANK;

			// Add-lat-long end here
			//----------Address 2 -----------------------------
			add[0] = add[0].replace(".,", "").replace(",", "");
			add[0] = add[0].replace("Now Pre-selling".toLowerCase(), "");
			add[0] = add[0].replace("Snorris@stanpac.com".toLowerCase(), "");
			add[0] = add[0].replace("Prado@stanpac.com".toLowerCase(), "");
			add[0] = add[0].replace("By Appointment Only".toLowerCase(), "");
			add[0] = add[0].replace("please call for information", "");
			add[0] = add[0].replace("call for information", "")
							.replace("pocahontas ave  -  south of clairemont mesa blvd.", "pocahontas ave");
			add[0]=add[0].replace("located at the intersection of chivalry drive and duchess drive", "11401 Lords Lane");
			U.log("street:::" + add[0]);
			if (add[0].trim().endsWith("."))
				add[0] = add[0].replace(".", " ");

			if (add[0] == ALLOW_BLANK || add[0].length() < 2) {

				add = U.getAddressGoogleApi(latLong);
				geo = "True";
			}
			if (add[0].contains("13800 lyndhurst")) {
				add[0] = add[0] + " Building 12";
			}

			add[1] = add[1].replace("()", "");
			
			if (add[3] == null)
				add[3] = ALLOW_BLANK;
		
			// pointing toward water
			if (lat.contains("30.296") && lng.contains("-97.7056")){
				String[] lals = U.getlatlongGoogleApi(add);
				lat = lals[0];
				lng = lals[1];
				geo = "true";
			}
			//-----------End Address 2 -------------------------------

			html = U.getSectionValue(html, "</head>", "google-search-form");
			String repAdd = U.getSectionValue(html, "Community Resources","<footer class=\"site\">");
			if (repAdd != null)
				html = html.replace(repAdd, "");
			String secp[] = U.getValues(html, "<ul class=\"count-", "</ul>");

			for (String s : secp) {
				// U.log(s);
				html = html.replace(s, "");
			}
			//-------- Price ------------------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = U.getHTML(comUrl);
			String commResSec = U.getSectionValue(html, "Community Resources","</script>");
			// U.log("commResSec::"+commResSec);
			if (commResSec != null)
				html = html.replace(commResSec, "");
			// U.log(commResSec);
			html = html.replaceAll("a 27,000 sq. ft. aquatic faci|8,000 square feet include a fitness center|center with a 10,700 square foot clubhouse and nearly 6,000 square feet|an over 10,700 square foot|dining facilities and an 8,000 square foot","");
			html = html.replaceAll("(\\$\\d+)&#39;s", "$1,000");
			html = html.replace("&#39;", "").replaceAll("mid (\\d+)'s","mid \\$$1,000");
			html = html.replace("$1 Million", "$1,000,000").replace("000,000s", "000,000")
					.replaceAll("\\$150,000-\\$200,000", "");
			html = html.replace("from the high 200�s", "from the high $200�s");
			html = html.replace("starting from the mid $200’s", "mid $200,000");
			html = html.replaceAll("0s|0's|0�s", "0,000");
			//U.log(U.getSectionValue(html, "luxury homes with city views, o","uxury homes with city views, open f"));
			// <p class="price">Priced at $789,950 </p>
			// Priced at $384,990 High $400�s and Low $500�s
			String sec1 = U.getSectionValue(U.getHTML(comUrl),"<ul class=\"callouts\">", "</ul>");
			if (sec1 != null) {
				sec1 = sec1.replaceAll("0s|0�s", "0,000");
			}
			sec1 += U.getSectionValue(html, "<p class=\"status\">", "</p");
			// U.log("::::"+Util.match(html, "high-\\$300,000"));
			String[] price = U.getPrices(sec1 + html+regionSection,
							"Priced at \\$\\d,\\d{3},\\d{3}|Starting from the \\$\\d,\\d{3},\\d{3}|Product Range \\$\\d{3},\\d{3}-\\d{3},\\d{3}|from the low \\$[0-9]{1},[0-9]{3},[0-9]{3}| starting in the \\$\\d+,\\d+|from \\$\\d+,\\d+|price\">\\$\\d+,\\d+|High \\$\\d+,\\d+|Low \\$\\d+,\\d+|low \\$\\d,\\d+,\\d+|mid \\$\\d+,\\d+|\\$\\d,\\d+,\\d+|Priced at \\$\\d+,\\d+,\\d+|Priced at \\$\\d+,\\d+|start in the \\$\\d+,\\d+|priced from the \\$\\d+,\\d+ to the \\$\\d+,\\d+|Over \\$\\d,\\d+,\\d+|HIgh \\$\\d+,\\d+|\\$\\d{3},\\d+ and|mid-\\$\\d+,\\d+|mid \\$\\d+,\\d+|the upper \\$\\d+,\\d+|the low \\$\\d{3},\\d+|range from \\$\\d+,\\d+ to \\$\\d+,\\d+|From the \\$\\d+,\\d+|was \\$\\d+,\\d+|From \\$\\d{3},\\d+|\\$\\d+,\\d+s|price\">\\$\\d{1},\\d+,\\d+|low \\$\\d{3},\\d+|high-\\$\\d{3},\\d{3}",0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			html = html.replaceAll("85,000 square feet of retail|15,000 square feet recreation|Club features 7,000 sq. ft.,|8,000 square foot clubhouse| 8,000 square foot community clubhouse|dining facilities, 8,000 sq. ft.","");

			//--------- Square feet---------------------
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			
			html = html.replace("homesites up to 9,000 square feet in size", "homesites up to 9000 square feet in size").replaceAll("homesites up to \\d,\\d+ square feet|Lot Sizes up to \\d{2},\\d{3} sq. ft.","");
			
			String[] sqft = U.getSqareFeet(html+regionSection,
							"\\d,\\d+ – \\d,\\d+ square feet|\\d{4} square feet|Sq Ft:\\s*</dt>\\s*<dd>\\s*\\d{3}|<b>[0-9]{1},[0-9]{3} Sq Ft</b>|Sq Ft: \\d{3,}|range from [0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}|\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d{4}-\\d{4} square feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d{3} – \\d,\\d{3}\\+ square feet|\\d,\\d+– \\d,\\d+ square feet|\\d,\\d+–\\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ square fee|square footage ranging from \\d,\\d+ to \\d,\\d+|\\d{1},\\d{3} to \\d{1},\\d{3} square feet |\\d,\\d+ square|\\d{1},\\d{3} to \\d{1},\\d{3} sq. ft|\\d{1},\\d{3} - \\d{1},\\d{3} sq| \\d,\\d+ square feet|\\d{4} sq. ft|\\d{4} to \\d{4} square feet|\\d,\\d+ - \\d,\\d+ Square Feet|\\d+ sq.ft. up to \\d+ sq. ft.|<dd>\\d+,\\d+</dd>|<dd>\\W+\\d+,\\d+\\W+</dd>|Sq. Footage From \\d,\\d+ to \\d,\\d+| \\d{1},\\d{2} sq. ft.|from \\d,\\d+ to \\d,\\d+ square feet|from \\d,\\d+-\\d,\\d+ square feet|up to \\d+,\\d+ sq ft|Up to \\d+,\\d+ Sq. Ft.|\\d,\\d+ - \\d,\\d+ Sq. Ft.|Sq Ft: \\d,\\d+|Sq. Ft: \\d{3,}| \\d,\\d+ Square Feet|<li>\\s*Sq. Ft: \\d{3,} <|Sq. Ft:</dt>\\s<dd>\\d{3,}|Sq. Ft:</dt>\\s+<dd>\\d+,\\d{3,}|Sq Ft:</dt>\\s+<dd>\\d,\\d{3}</dd>|over \\d,\\d+ available sq. ft.",0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			//------------- Property Type---------------------
			String propertyType = ALLOW_BLANK;
			String derivedPType = ALLOW_BLANK;
			U.log(U.getCache(comUrl));
			// U.log("**********"+
			// Util.match(html,"<dt>\\s+Stories:\\s+</dt>\\s+<dd>\\s+\\d+"));
			String storSec = Util.match(html,"<dt>\\s+Stories:\\s+</dt>\\s+<dd>\\s+\\d+");
			if (storSec != null)
				storSec = storSec.replace("<dt> Stories: </dt> <dd>", "Stories");
			html = html.replaceAll("<dt>\\s+Stories:\\s+</dt>\\s+<dd>\\s+","Stories: ");
			// U.log("**********"+ Util.match(html,"Stories:\\s+\\d+"));
			// Rancho
			U.log("storSec ::"+storSec+":::");
			html = html.replaceAll("branch|Branch", "");
			html = html.replace("Rancho", "");
			html = html.replaceAll("Stories: (\\d) - (\\d)","Stories: $1 - Stories: $2");

			String badComm = U.getSectionValue(html,"<div id=\"direction-text\">", "</html");
			if (badComm != null)
				html = html.replace(badComm, "");
			badComm = U.getSectionValue(html, "<li class=\"community\">","</select>");
			if (badComm != null)
				html = html.replace(badComm, "");
			regionSection=regionSection.replaceAll("Ranch|Ranch</h3>|Ranch\"", "");
			html=html.replace("Spanish Colonial Elevation", "Spanish colonial Elevation").replace("Spanish Colonial Revival", "Spanish colonial Revival");
			html = html.replaceAll(" with Stonebridge Ranch Country|through Avery Ranch|The Ranch at Brushy Creek|Ranch Pkwy|Medical Center Craig Ranch|ranch-style-living|Ranch Style Living\\s+<|1858-indianapolis-ranch|alt=\"Ranch Style Living|Indianapolis - Ranch Style Living|Ranch Style Living</a></li>|Colonial|Ranch 99|D Ranch|stone Ranch|1890 Ranch|Park, Benbrook Ranch|4 bedroom|Pizza Ranch|pizzaranch|Sonoma Ranch|SONOMA RANCH|COTTAGE PINES LANE|Valley Ranch|C Ranch |Ranch Metro Park | Ranch Road|Springs Ranch Park|Vail Ranch|W RANCH|H Ranch|FishHawk Ranch|fishhawk-ranch|FishHawk-Ranch|Ranch -|ranch -|ranch- |3rd bedroom|Lakewood Ranch|Ranch Pkwy|Ranch Elementary|rancho|Rancho|Ranch Palos|Ranch Way|306 H Ranch|Oaks Ranch|ranch-golf-country-club|3-Tier|Ranch Pkwy|sdmclakewoodranchhs|Ranch High|Branch|Ranch Boulevard|patio-villas|Ranch Road|Ranch Blvd|Ranch Rd|Ranch Elementary School|Green Valley Ranch|Creek Ranch|Oaks Ranch Golf","");
			 
			html=html.replaceAll("Branch</strong>|yellowrivergameranch|Game Ranch\\s*</h4>|showers, first-floor bedroom|first-floor owner’s suite options", " 1 story ").replace("first floor guest suite options and 3rd floor living options", "first story guest suite options and 3 story living options");
			//U.log("Result:"+Util.match(html, ".*?Ranch.*?")+"--------------");
			derivedPType = U.getdCommType((html + commName+regionSection).replace("branch", "")+ storSec);

			badComm = U.getSectionValue(html, "class=\"community\">","</select>");
			if (badComm != null)
				html = html.replace(badComm, "");
			badComm = U.getSectionValue(html, "<section id=\"promotions\">","div class=\"inner map-full\">");
			if (badComm != null)
				html = html.replace(badComm, "");
			
			html=html.replaceAll("Craftsman, Cottage, Mission and Traditional|traditional, historic styles, including Craftsman", "traditional homes, Craftsman-style homes")
					.replace("luxury with a limited number", "luxury home with a limited number")
					.replace(" Spanish and Craftsman styles", " Spanish and Craftsman-style homes");
			html = html.replaceAll("Smock golf course|luxurious garden bathroom|data-video=\"0\" data-category=\"Patio\">|Luxurious bathroom|luxurious master bedroom|Villas</h3>|1257 Villa|Cottage Garden Way|No homeowner|No HOA dues|no HOA dues |patio with BBQ|no HOA|No HOA|luxurious Owner|luxurious soaking|Milbrook \\(Detached|Carriage Falls|Carriage Trace|Carriage Bush|Village|VILLAGE|village|Timberstone Villas|timberstone-villas","");
			html=html.replaceAll("Traditional Spanish styling|Traditional, European Cottage|architecture includes Traditional, Spanish and| Mission and Traditional", "Traditional Home");
			html=html.replace("detached, single-story ", "detached home, single-story ")
					.replaceAll("Craftsman, Cottage|Heritage, Craftsman", "Craftsman-style homes").replaceAll("luxurious single-family home ", "luxury homes,single family homes");
			
			html =html.replace("features newly designed luxury", "features newly designed luxury homes").replace("luxury meets livability", "luxury home meets livability").replace(" luxury of a golf-course community ", " luxury home of a golf-course community ").replace("with detached, alley", "with detached home , alley");
			propertyType = U.getPropType((html + comUrl+regionSection).replaceAll("Patio\"|Cottage Grove|luxury shower|Luxury master bath| Traditional Townhomes |Villasenor|villaolivia|Villa Olivia|Villas\\.pdf|Village|\\- Single Family Home|Luxurious Bath|luxurious bath|Carriage Court|Crossing Twin Homes",""));
			//U.log("result:"+Util.match(html, ".*?traditional, historic styles, including Craftsman.*?"));
			// property type
			String drop = U.getSectionValue(html1, "alt=\"Recreation\"/>","<div class=\"category\">");
			// U.log(drop);
			if (drop != null)
				html1 = html1.replace(drop, "");

			html1 = html1.replace("Master Planned Landscape Design", "").replace("Country Club Hills", "")/*.replace("resort-style recreation center", "")*/;
			html1 = html1.replace("50 Master Planned Communities", "");
			html1 = html1.replaceAll("\\(55+\\) gated community","55+ gated community");
			html1=html1.replace("Golf Course and Resort", "Golf Course and Resort-Style")
					.replace(" a resort-inspired", " a resort-Style-inspired")
					.replace("activities including golf,", "activities including golf course");;
			
			// U.log(html1);
			html1 = html1.replaceAll("resort-style pool with cabanas|and Smock golf course|on Country Club Drive|Seasons Country Club|Country Club Road|Country Club Hill|country club hill|Lake Country Club|Zionsville Golf Cour|Alaqua Country Club","");
			// U.log("=====> "+ Util.match(html1, ".*?golf cour.*?"));
			if (commResSec != null)
				html1 = html1.replace(commResSec, "");
			// U.log("html1::"+Util.match(html1, ".*?active adult.*?"));
			// -------------- Community type --------------------------------
			regionSection = regionSection.replace("golf courses, resorts", "golf courses, resort-style community");
			//U.log(html1);
			String cType = U.getCommunityType((html1+regionSection).replace("dining, golf", "golf course"));
			U.log("Ctype:::"+cType);
			// ----------------- Property Status---------------------------------------
			String pStatus = ALLOW_BLANK;
			if (comUrl.contains("http://www.calatlantichomes.com/find-your-new-home/28-denver/8057-green-gables-reserve-paired-homes.html"))
				html = html.replace("Coming Soon —", "");
			
			html=html.replace("limited number of homesites available", " limited homesites available")
					.replace("Newest phase, now open", "Newest phase now open")
					.replace("61 home sites are available", "61 home sites available").replace("67 total home sites available", "67 home sites available");
			html = html.replaceAll("Excellence, is now open|quick move-in homes please|sold out - new villa|amenities coming soon|construction and coming soon|amenities are coming soon|New floor plans are coming soon|2 are Sold Out\\s*</li>|truly is a limited opportunity|Now Selling promotion |Move-in ready homes available now|Home plans now available|homes now selling|owner(.*?)s suite coming soon|including the coming soon 257|new designs now available|limited opportunity to take |parks are coming soon|to suite lots available|amenities coming soon|Coming soon to the community are an on-site school|New Models ~ NOW OPEN| our Grand Opening anticipated|Spa coming soon|list for this coming soon|Model open by appointment only|Swimming pool and fitness center coming soon|Coming soon to the community are an onsite school and a pool","");
			//html = html.replace("home sites are available","home sites available");
			String sec = U.getSectionValue(html, "class=\"status\"","</section>");
			//String sec2 = U.getSectionValue(html,"<meta property=\"og:street-address\" content=\"", "\"");
			String sec3 = U.getSectionValue(html1, "description","<meta property");
			sec3 += U.getSectionValue(html, "section-inner description", "</p>");
			//U.log("regionSection:::" + Util.match(regionSection, ".*?now selling.*?"));
			regionSection=regionSection.replaceAll("sold out - new villa|Quick Move-In opportunities still remain in Young|Hurry! One Quick Move-In Home Remains!|Now Open - 3|Now Open ~ Tour|information on our final opportunities|Paired homes now selling|2 are Sold Out\\s*</li>|Owner(.*?)s Suite Coming Soon|being sold out of our newest models|sold out of build lots|New Models ~ NOW OPEN|floor plans now available|floor plans now available|Model Homes Now Available For Sale|\\s*For more Quick Move-In homes in Aliana", "")
					.replace("Basement Homesites Available ", "Basement Home sites Available ");
			regionSection = regionSection.replace("Phase Two - Coming Summer 2018", "Phase Two Coming Summer 2018").replace("Coming Soon Early 2019", "coming soon early 2019");
			sec=sec.replaceAll("For more Quick Move-In homes in Aliana","-").replace("Coming Soon Early 2019", "coming soon early 2019");

//			U.log(regionSection);
			pStatus = U.getPropStatus((sec +  sec3 +regionSection).replaceAll("Quick Move In Homes","Quick Move-in Homes").replace("Phase 2: NOW OPEN", "Phase 2 Now Open")
							.replaceAll("amenity center coming in 2018|plans now selling!|space opening summer 2018|scheduled to open Fall 2018|New Floorplans Now Available|library coming soon|treed homesites just released|<p>Quick Move-In Homes Available!</p>|information on final opportunities|information on our final opportunity|one of the last opportunities to purchase|Elementary is now open|Model Home Grand Opening|Models Coming Summer 2017|amenities are coming soon|basement home sites available|amenities coming soon|Upscale luxury amenities, coming this fall|Community Coming Soon|title=\"Coming Soon|Move-in ready homes available now|Plan 1 is Sold Out|Rare new homes now available| amenities, coming soon|Sale-Last Chance | models homes now open|New Models ~ NOW OPEN|news, sales and Grand Opening dates|sales information and Grand Opening Dates|Models now available|parks coming soon|Models Now Selling|Model open by appointment only|Swimming pool and fitness center coming soon|Coming soon to the community are an onsite school and a pool|Mavericks; and coming in 2016|pool now open|school opening soon|playground coming soon|school coming soon|estimated opening Fall 2016|style community pool is coming soon|school opening in 2017|Grand Opening incentives|Park will be opening soon|Coming soon to Highland Grove|School is coming in the fall of \\d{4}|currently under construction|Approaching Closeout!|Model Now Open|model will be under construction|models will go under construction|School coming \\d+|in opportunities",""));

			pStatus = pStatus.replace("Near Our Close-out Phase","Near Close-out").replace("Home Sites", "Homesites");
			pStatus = pStatus.replace("closeout", "Close Out");
			pStatus = pStatus.replace("Iv", "IV").replace("New Phase Now Open, Now Open", "New Phase Now Open");
			pStatus = pStatus.replaceAll("Closeout Final Opportunities, Closeout", "Closeout Final Opportunities");
			
			U.log("Prop Status: " + pStatus);
			if(comUrl.contains("/8362-wild-plum.html"))pStatus=pStatus.replace("Coming Soon", "coming soon early 2019");

			String promoSec = U.getSectionValue(html1,"<section id=\"promotions\">","<div class=\"floating-menu\">");
			if (promoSec != null)html = html.replace(promoSec, "");

			String notes = ALLOW_BLANK;

			notes = U.getnote(html);
			if (add[2].length() != 2)
				add[2] = USStates.abbr(add[2]);

			//----------- Modify sections---------------
			pStatus = pStatus.replace("Coming Soon Fall 2016, Coming Soon", "Coming Soon Fall 2016");
			add[0] = add[0].replace("(corner of w. main st. and shelborne rd.)", "");

			commName = commName.replaceAll("�", "n").replace("iii","III").replace(" iv", " IV");
			commName = commName.replace("- the cottages", "").trim();

			if (commName.endsWith("paired homes"))commName = commName.replace("paired homes", "");
			if (commName.endsWith("patio villas"))commName = commName.replace("patio villas", "");
			if (commName.endsWith("patio homes"))commName = commName.replace("patio homes", "");
			if (commName.endsWith("garden homes"))commName = commName.replace("garden homes", "");
			if (commName.trim().contains("-"))commName = commName.replace("-", "");
			commName = commName.replace("avaña", "Avana");
			commName = commName.replace("celestina – the ", "celestina - the ").replaceAll("patio$|Patio$", "");
			if(commName.endsWith("country club"))commName = commName.replace("country club", "");
		
			U.log("commName::" + commName + ":commName");
			U.log("Dtype:::"+derivedPType);
			
			U.log("Ptype :::"+propertyType);
			U.log("comName :::"+commName);

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************"+ comUrl);
				dup++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			// adding data in csv
			data.addCommunity(commName, comUrl, cType);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(propertyType, derivedPType);
			data.addPropertyStatus(pStatus);
			data.addNotes(notes);
			
		}
		i++;//
	}
}