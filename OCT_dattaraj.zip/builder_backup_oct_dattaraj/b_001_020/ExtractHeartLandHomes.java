package com.shatam.b_001_020;

import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHeartLandHomes extends AbstractScrapper {

	public int j = 0;
	static String HOME_URL = "https://www.heartlandluxuryhomes.com";
	static String BUILDER_NAME = "NVR - Heartland Homes";
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractHeartLandHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "NVR - Heartland Homes.csv", a.data().printAll());
	}

	public ExtractHeartLandHomes() throws Exception {
		super("NVR - Heartland Homes", "https://www.heartlandluxuryhomes.com/");
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	@Override
	protected void innerProcess() throws Exception {
//		String mainHtml = U.getHTML("https://www.heartlandluxuryhomes.com/sitemap");
		String Html = U.getPageSource("https://www.heartlandluxuryhomes.com/find-your-home");
//		U.log(mainHtml);
//		String sections = U.getSectionValue(mainHtml, "<h3>Neighborhoods</h3>", "</ul>");
		String sections = U.getSectionValue(Html, "<div id=\"allMarkets\"", "<div id=\"allCounties\"");
		// U.log(sections);
		String[] comSections = U.getValues(sections, "<div class=\"find-all-results-header-container\">", "</div>");
		U.log("Total Region : " + comSections.length);
		for (String sec : comSections) {
			// U.log("sss----"+sec);
			String url = HOME_URL + U.getSectionValue(sec, "<a href=\"", "\"");
			String mainHtml = U.getHTML(url);

			String[] comSec = U.getValues(mainHtml, "<div class=\"communities-near-cards\">",
					"<div class=\"search-results-city-state\">");

			for (String comsec : comSec) {

				String comUrl = U.getSectionValue(comsec, "href=\"", "\"");
				comUrl = HOME_URL + comUrl;
				// U.log(comUrl);

				String name = U.getSectionValue(comsec, "data-marketing-name=\"", "\"");

//			U.log(sec);
				
				
				
				if (!comUrl.contains("https://www.heartlandluxuryhomes.com'")) { 
				//if(comUrl.contains("falling-water-master-page")){
					
					String comHtml = U.getHTML(comUrl);
					
					if(comHtml.contains("Communities Available")) {
						
					
						String[] commSec = U.getValues(comHtml, "<div class=\"card mpc-card-link\">", "<div class=\"search-results-city-state\">");
					//	String[] commSec=U.getValues(comHtml, "<div class=\"search-results-card\">", " <div class=\"search-buttons\">");
						for(String com : commSec) {
							
							comUrl = U.getSectionValue(com, "<a href=\"", "\"");
							name = U.getSectionValue(com, "<div class=\"search-results-name\">", "<");
							
							addDetails(HOME_URL+comUrl, name);
						}
						
					}
				
					else
						addDetails(comUrl, name);
					
				}
					
			}
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String url, String name) throws Exception {
//https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151326/pennsylvania/wexford/englishfarms
//https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151701/west-virginia/morgantown/falling-water-master-page

//		if (!url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151950/pennsylvania/valencia/fieldstone-ridge"))return;
		
		
//		if(!url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151700/west-virginia/morgantown/theglensatfallingwater")) return;
		//if(!url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151700")) return;
		//if(!url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151880/pennsylvania/north-strabane/thelanding")) return;
//	if(j == 1)
		{
			/*
			 * if(url.contains("robinson-township/silver-summit-townhomes"))
			 * name=name.replace("Silver Summit","Silver Summit Townhomes");
			 */

			U.log("\nCount :" + j);
			name=name.replace(" - Community", "");
			U.log(url + "\t" + name);
			if(name.endsWith("Estates")) {name=name.replace("Estates", "");}

			name = name.replace(" Single Family Homes", "").replaceAll(" - One Level Living$| Patio and Single Family Homes$| Townhomes and Villas$", "");

//		String comHtml = U.getHTML(url);
			String comHtml = U.getPageSource(url);
			
//			U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}This lakeside community offers privacy[\\w\\s\\W]{30}", 0));

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + url);
				return;
			}
			LOGGER.AddCommunityUrl(url);

			// -------Slider Sec------
			String slider = U.getSectionValue(comHtml, "<section id=\"photo-tour\" class=\"photo-gallery\">",
					"schedule-photo-tour\">");

			// U.log(comHtml);
			// ----remove header-------
			comHtml = U.removeSectionValue(comHtml, "<head>", "<header");
			
			


			String remove = U.getSectionValue(comHtml, "<div id=\"communitiesNearby\">", "<script>");

			if (remove != null)
				comHtml = comHtml.replace(remove, "");
			// U.log(comHtml);
			// ----remove footer------
//		comHtml = U.removeSectionValue(comHtml, "<h2>Nearby Communities</h2>", "</body>");
			// comHtml = U.removeSectionValue(comHtml, "Nearby Communities", "</body>");

			// --------Address-------
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String notes = ALLOW_BLANK;

			// comHtml = U.removeSectionValue(comHtml, "<section
			// id=\"supplemental-information\">", "</div>");

//		String addSec = U.getSectionValue(comHtml, "<h2 class=\"icon-pacemark2\">Location</h2>", "</p>");
			String addSec = U.getSectionValue(comHtml, "<h2 class=\"icon-pacemark2\">", "</p>");
			U.log("Address: " + addSec);
			if (addSec != null) {
				addSec = addSec.replaceAll("\\s*<br\\s?/>\\s*", ",").replaceAll("<p>|Location\\s+</h2>", "").trim();
				U.log("Address1:" + addSec);
				String[] tempAdd = addSec.split(",");
				// U.log(tempAdd.length);
				if (tempAdd.length == 4) {
					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2], "\\w{2}");
					add[3] = Util.match(tempAdd[2], "\\d{5}");
				}
			}
			U.log(Arrays.toString(add));
			// -----------latlng--------
			String directionUrl = U.getSectionValue(comHtml, "var url = '", "';");
			U.log(U.getCache(HOME_URL + directionUrl));
			U.log("directionUrl : " + directionUrl);
			if (directionUrl == null && url.contains("neighborhoods/pa/allegheny/wexford/englishfarms"))
				directionUrl = "/directions/10222120151326"; // taken from its region page
			
			if(!directionUrl.contains("/directions"))
				directionUrl += "/directions";
			U.log(" address  --------- "+add[0]);
			
			
			if (comHtml.contains("id=\"btnDirections")) {
//			String dirHtml = U.getHTML(HOME_URL+directionUrl);
				String dirHtml = U.getPageSource(HOME_URL + directionUrl);
				String latlngSec = U.getSectionValue(dirHtml, "var communityMapCoordinates = {", " }");
				if (latlngSec == null)
					latlngSec = U.getSectionValue(dirHtml, "https://www.google.com/maps/search/?api=1&query=", ";");

				latlngSec = latlngSec.replaceAll("'|\\+", "");
				latLng = latlngSec.replaceAll("lat:|lng:", "").split(",");
				dirHtml = dirHtml.replaceAll("ADDRESS\\s*</div>", "ADDRESS</div>");
				addSec = U.getSectionValue(dirHtml, "ADDRESS</div>",
						"<div class=\"address-button-container GoogleMaps\">");
				// U.log("<<<<<<<<<<<< "+addSec);
//				if (addSec != null) {
//					addSec = addSec.replace("</div>", ",").replace("<div class=\"row no-wrap address-padding\">", "");
//					U.log(o);
//					add = U.getAddress(addSec);
//					add = U.getAddress(add[0]);
//				}
			}
			
			U.log(" address  --------- "+add[0]);

			U.log(Arrays.toString(latLng));
//===			
			if(latLng[0]==null||latLng[0]==ALLOW_BLANK) {
				latLng[0]=Util.match(comHtml, "\\d{2,3}\\.\\d{5,}");
				latLng[1]=Util.match(comHtml, "-\\d{2,3}\\.\\d+");
			}
			U.log(Arrays.toString(latLng));
//===			

			if ((latLng[0] == null || latLng[0].length() < 4)&&comHtml.contains("communityMapCoordinates")) {
				String latSec = U.getSectionValue(comHtml, "var communityMapCoordinates = {", " }");
				latLng = latSec.replaceAll("lat:|lng:", "").split(",");
			}

			// ------Below code is to take address using city and state where there is no
			// address and latlng mention on community page

			if (add[0].length() < 4 && latLng[0].length() < 4) {
				String cityState = U.getSectionValue(url, "	/",
						"/" + name.toLowerCase().replace(" - ", "-").replace(" ", "-"));
				if (cityState == null)
					cityState = U.getSectionValue(url, "neighborhoods/",
							"/" + name.trim().toLowerCase().replace(" - ", "-").replace(" ", ""));
				if (cityState == null) {
					cityState = U.getSectionValue(comHtml, "<div class=\"newHomesIn-city-state\">","</h2>");
					if (cityState!=null) {
						String[] tempAdd =cityState.replaceAll("<h2>", "").trim().split(",");
						add[1]=tempAdd[0];
						add[2]=tempAdd[1];
					}
					
				}
				if (url.contains(
						"https://www.heartlandluxuryhomes.com/neighborhoods/pa/allegheny/pine-township/laurel-grove"))
					cityState = "pa/allegheny/gibsonia";
				U.log("cityState : " + cityState);
				if (cityState.contains("/")) {
					String[] tempAdd = cityState.split("/");
					add[1] = U.getCapitalise(tempAdd[2]);
					add[2] = tempAdd[0].toUpperCase();
				}
				
				
				U.log(add[1] + "," + add[2]);
				latLng = U.getlatlongGoogleApi(add);
				if (latLng == null)
					latLng = U.getlatlongHereApi(add);

				add = U.getAddressGoogleApi(latLng);
				if (add == null)
					add = U.getAddressHereApi(latLng);
				notes = "Address And LatLng Taken Using City And State";
				geo = "TRUE";
				U.log(Arrays.toString(add));
				U.log(Arrays.toString(latLng));
			}
			if (latLng[0] != null && add[0].equals(ALLOW_BLANK) && add[1].equals(ALLOW_BLANK)) {
				add = U.getAddressGoogleApi(latLng);
				if (add == null)
					add = U.getAddressHereApi(latLng);
				geo = "TRUE";
			}
			if (add[0] == ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latLng);
				if (add == null)
					add = U.getAddressHereApi(latLng);
				notes = "Address And LatLng Taken Using City And State";
				geo = "TRUE";
			}
			

			// -----------Homes Data-----------
			String combineHomeData = ALLOW_BLANK;
			String[] homeSections = U.getValues(comHtml, " <div class=\"card-body\">", "</div>");
			U.log("Total Home : " + homeSections.length);
			for (String homeSec : homeSections) {
				homeSec = U.getSectionValue(homeSec, "<a href=\"", "\">");
				if (homeSec == null) {
					continue;
				}
				if (homeSec.contains("14933") || homeSec.contains("53092")) {
					System.out.println("Continue...");
					continue;
				}
				U.log("Home Url : " + HOME_URL + homeSec);
//			String homeHtml = U.getHTML(HOME_URL+homeSec);
				String homeHtml = U.getPageSource(HOME_URL + homeSec);
				combineHomeData += U.getSectionValue(homeHtml, "<p id=\"product-about-long-description\">", "</div>");
			}
//		U.log(combineHomeData);
			// -------Format Price---------
			Matcher mat = Pattern.compile("\\$\\d{3}s", Pattern.CASE_INSENSITIVE).matcher(comHtml);
			while (mat.find()) {
				// U.log(mat.group());
				String priceMatch = mat.group().replace("s", ",000"); // $500s
				comHtml = comHtml.replace(mat.group(), priceMatch);
			}

			// --------Price-------------
			String myPriceSec=ALLOW_BLANK;
            String priceSec[]=U.getValues(combineHomeData,"<div class=\"search-results-price-display\">", "</div>");
            for(String mpriceSec:priceSec) {
            	myPriceSec=myPriceSec+mpriceSec;
            	myPriceSec=U.getNoHtml(mpriceSec);
            }
			comHtml = comHtml.replace("0s", "0,000").replaceAll("\\d{3},\\d{3} sq", "").replaceAll("\\$\\n\\s*", "")
					.replaceAll("was \\$\\d{3},\\d{3}|rose from \\$\\d{3},\\d{3} in 2000 to \\$\\d{3},\\d{3}", "");
			comHtml=comHtml.replaceAll("sales price of \\$\\d{3},\\d{3}, a total loan amount of \\$\\d{3},\\d{3}", "");

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			U.log("mu=yPriceSec"+myPriceSec);
			String[] price = U.getPrices(comHtml+ combineHomeData+myPriceSec, "Mid \\$\\d{3},\\d{3}|FROM THE UPPER \\$\\d{3},\\d{3}|FROM THE MID \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\d{3},\\d{3}", 0);
			
			

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

			U.log(minPrice + "\t" + maxPrice);

			// ---------SQFT------
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

			comHtml = comHtml.replace("+", "").replace("4,278 sq.ft", "");
			comHtml = comHtml.replace("2,640 sq.ft", "");
			comHtml=comHtml.replace("Townhomes offer up to 2,400 square feet", "");
			
			String[] sqft = U.getSqareFeet(comHtml + combineHomeData,
					"\\d,\\d{3}+ square feet|\\d,\\d{3} square feet of living space|over \\d,\\d{3} sq. ft|up to \\d,\\d{3} square feet|>\\d,\\d{3}&#x2B; sq.ft|\\d,\\d{3}-\\d,\\d{3}+ sq. ft.|\\d,\\d+ sq.ft|<strong>(\\s+)?\\d{4}(\\s+)?<sup>(\\s+)?(\\+)*(\\s+)?</sup>(\\s+)?</strong>(\\s+)?Sq. Ft|<strong>\\s*\\d{4}\\s*<sup/>\\s*</strong>\\s*Sq. Ft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			U.log(minSqft + "\t" + maxSqft);

			// ----Modification
			combineHomeData = combineHomeData.replaceAll(
					"traditional, transitional and Craftsman elevations|traditional and craftsman elevations|traditional, classic elevations|traditional, craftsman, and manor elevations|Craftsman Elevation|craftsmanship|craftsman, and manor elevations|craftsman-like details",
					"").replaceAll("traditional or Craftsman styles available",
							"traditional homes or Craftsman-style home");
			comHtml = comHtml.replace("Cabin Wave Pool", "").replace("and luxury in an ideal location", "luxury homes");
			
			// ---------Property Type---------
			
			comHtml=comHtml.replace("Interior Craftsman Trim Packages", "");
			if(url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151880/pennsylvania/north-strabane/thelanding")) {
				String Myremove=U.getSectionValue(comHtml, "<div class=\"disclaimer-footer\">", "</div>");
				comHtml=comHtml.replace(Myremove, "");
			}
//			U.log("MMMM"+Util.match(comHtml, "Homeowner&rsquo;s Association"));
			comHtml=comHtml.replace("own quality craftsmanship for less than rent just minutes", "")
							.replace("more traditional farmhouse exterior", "more Traditional Homes exterior")
							.replace("Monthly HOA fee not included", "Monthly fee not included")
							.replace("If your occupation has", "").replace("ample space for patios", "").replace("ample space for patios", "")
							.replace("Monthly HOA fee", "").replace("low a HOA fee", "");
		
			combineHomeData=combineHomeData.replace("own quality craftsmanship for less than rent just minutes","");
			
			String propType = ALLOW_BLANK;
			propType = U.getPropType((comHtml + combineHomeData + slider).replace("Farmhouse Elevation\n                    </h5>", "")
					.replace("Traditional Homes exterior? Want", "")
					.replaceAll("Modern Farmhouse, or Craftsman vibe, you can complete your", "")
					.replaceAll("more traditional farmhouse exterior|Hardiboard Craftsman-Style Exteriors|(B|b)edner (E|e)state|Striking cottage or farmhouse elevations", ""));
			
			if(propType.contains("Townhouse") && propType.contains("Townhomes")||propType.contains("Townhome"))
				propType = propType.replace("Townhouse", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
			
			if(url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151805/pennsylvania/adams-township/gabrielscrest")) {
				propType = propType.replace("Townhouse,", "");
			}
//			 U.log("MMMMMMM "+Util.matchAll(comHtml + combineHomeData + slider, "[\\s\\w\\W]{50}farmhouse[\\s\\w\\W]{50}", 0));

			U.log(propType);
				

			// -------Deriver Type-----
			
			String dType = ALLOW_BLANK;
			// comHtml = comHtml.replace("Main-Level ", " 1 story ");
			//combineHomeData = combineHomeData.replace("2nd floor laundry", "2 story laundry");
		
			comHtml=comHtml.replace("FIRST FLOOR OWNER'S SUITE", "1 Story").replaceAll("</strong>to see the ranch-style homes at&nbsp;Laurel La|laurellandingranchhomes|but desire a ranch-style main level living home", "").replace("1st or 2nd floor owner's suites", "1 story");
			
			if(combineHomeData.contains("The first floor features soaring 9 ft. ceilings, a gourmet kitchen with 42\" cabinets, ample counter space, and a pantry for extra storage.")) {
				combineHomeData = combineHomeData.replace("The first floor features soaring 9 ft. ceilings","1 Story features soaring 9 ft. ceilings");
			}
			
			dType = U.getdCommType((comHtml + combineHomeData + slider).replace("second floor", "2 Story").replace("first floor", "1 Story").replace("1st and 2nd floor", "1 Story & 2 Story").replaceAll(
					"Colonial, Federal, and European-style elevations are available|<p>First floor owner’s suite|Grove offer you first floor owner|<h3>FIRST FLOOR LIVING</h3|Enjoy the ease of a first floor owners suite,|[F|f]loor|FLOOR OWNER",
					""));
			 U.log(dType);

			// U.log("MMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{30}FIRST FLOOR[\\s\\w\\W]{30}", 0));

			/*
			 * if(url.contains(
			 * "https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151716/west-virginia/morgantown/stonehurst"
			 * )) { dType = "1 Story"; }
			 */
			
			// -----ComType----
			String comType = ALLOW_BLANK;
			
			
			comHtml = comHtml.replace("Lakeview Golf &amp; Resort", "Lake community and resort-class lake living")
					.replaceAll("Treesdale Golf & Country Club", "").replace("lakeside community offers", "");
			comHtml=comHtml.replace("North Park and Treesdale Country Club", "");
			comHtml=comHtml.replace("Country Club to never miss a tee time", "");
			comHtml=comHtml.replaceAll("at a resort all year|RESORT-STYLE COMMUNITY AMENITIES|", "");
			comHtml=comHtml.replace("Lindenwood Golf Course and Valley Brook Country Club to never miss a tee time","");
			comHtml=comHtml.replace("You'll be close enough to Lindenwood Golf Course and Valley Brook Country Club to never miss a tee time","");
			if(url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151466/pennsylvania/mcmurray/waterdamfarms"))
			{
				/*
				 * U.log("SSSS"+Util.matchAll(combineHomeData, "Golf Course and", 0));
				 * U.log("SSSS"+Util.matchAll(combineHomeData, "Country Club", 0));
				 * U.log("SSS"+Util.matchAll(comHtml,
				 * "[\\s\\w\\W]{30}Golf Course[\\s\\w\\W]{30}", 0));
				 * U.log("SSS"+Util.matchAll(comHtml,
				 * "[\\s\\w\\W]{30}Country Club[\\s\\w\\W]{30}", 0));
				 */
			   comHtml=comHtml.replace("be close enough to Lindenwood Golf Course and Valley Brook !</p>", "");
			   comHtml=comHtml.replace("ood Golf Club and Valleybrook Country Club</strong> are just a few minut", "");
				//combineHomeData=combineHomeData.replace("Country Club", "");
				//combineHomeData=combineHomeData.replace("Golf Course", "");
				}
			comType = U.getCommType(comHtml);
//			if(url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151466/pennsylvania/mcmurray/waterdamfarms"))
//				comType=comType.replace("Country Club","");
//			if(url.contains("https://www.heartlandluxuryhomes.com/new-homes/communities/10222120151466/pennsylvania/mcmurray/waterdamfarms"))
//				comType.replace("Golf Course", "");
//			
//			 U.log("MMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{30}lakeside community[\\s\\w\\W]{30}", 0));
//
//			 U.log("MMMMMMM "+Util.matchAll(combineHomeData , "[\\s\\w\\W]{30}lakeside community[\\s\\w\\W]{30}", 0));

			
			U.log(comType);
//			U.log("##########"+comType);
			
			// ----PropStatus----
			
			comHtml = comHtml.replaceAll("5\\s*</div>\\s*<div class=\"fomo-block-option1-description\">homesites remaining.", "5 homesites remaining").replaceAll("<div class=\"fomo-block-option1-remaining\">\n\\s+\n\\s+1\n\\s+\n\\s+</div>\n\\s+<div class=\"fomo-block-option1-description\">\n\\s+Homesite remains", "1 Homesite remains")
					.replaceAll("<div class=\"fomo-block-option1-remaining\">\n\\s+\n\\s+2\n\\s+\n\\s+</div>\n\\s+<div class=\"fomo-block-option1-description\">\n\\s+Homesites Remaining", "2 Homesites Remaining")
					.replaceAll(
					" NEW HOMESITES!\\s*</div>\\s*<div class=\"personalized-description bodyCopyFont\">\\s*Coming Soon! ",
					"New Homesites Coming Soon");
					
			
			
			comHtml = comHtml.replaceAll(
					"we're completely SOLD OUT|rare quick move-in opportunity|QUICK MOVE IN NOW AVAILABLE|New home designs coming soon|Quick Move in Now Available!|Prices Coming Soon|Just Released! Be the first to choose|Plus now open, grab|Coming Soon! Be the first to|about quick move-ins available at|our model to see the newly released|Selling! Be the first",
					"").replace("Final estate homesite now available", "final homesite now available").replaceAll("before we are SOLD OUT|up for (the|our) Grand", "")
					.replace("Phase 4 Home Sites are Selling Fast", "Phase 4 Homesites Selling Fast")
					.replace("Phase 4 is nearly sold ", "Phase 4 nearly sold out")
					.replaceAll("to see the newly released home sites!| with less than \\d+ homesites|Closeout savings|until we are completely SOLD|price-display\">\\s+Sold", "")
					.replace("A PLANNED COMMUNITY CLUBHOUSE IS COMING SOON", "A PLANNED COMMUNITY CLUBHOUSE IS ")
					.replace("is coming soon. Workout in the", "is Workout in the ");
					//.replace("", "");
		//	U.log("MMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{200}Available[\\s\\w\\W]{30}", 0));

			// Neighborhood Has Only A Few
			
			comHtml = comHtml.replaceAll(
					"we're completely SOLD OUT|alt='Currently Selling in the final phase'|final opportunity for a 1st floor owner|Final Opportunity for a 1st floor owner|Quick Move-?\\s?In|The Andover Now Available at Waterdam Farms|The community is down to its final phase|Final Phase Includes Gorgeous Wooded|now available at The Overlook|estate homesites coming soon|Quick Move In Box|href=\"/quick-move-in-homes\">\n\\s*Quick Move-In",
					"")
					.replace("Final estate homesite now available", "final homesite now available").replace("Final phase is selling quickly", "Final phase selling quickly")
					.replace("Currently Selling in the final phase", "Currently Selling final phase")
					.replaceAll("4\n+\\s+</div>\n+\\s+<div class=\"fomo-block-option1-description\">\\s+Homesites remain", "4 homesites remain")
					.replaceAll("1\n\\s+</div>\n\\s+<div class=\"fomo-block-option1-description\">Homesite remains", "1 Homesite remains")
//					.replaceAll("(\\d+)\n+\\s+</div>\n+\\s+<div class=\"fomo-block-option1-description\">\\s*homesite remaining|(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">\\s+Homesites Remaining", "$1 Homesites Remaining")
					.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">\\s+homesites remain", "$1 homesites remain");
			comHtml=comHtml.replaceAll("\\s+\n" + 
					"                                \r\n" + 
					"                  </div>\r\n" + 
					"                  <div class=\"fomo-block-option1-description\">|\r\n" + 
					"                                </div>\r\n" + 
					"                                <div class=\"fomo-block-option1-description\">", "").replace("4\r\n" + 
							"                    opportunities remaining!", "4 opportunities remaining!").replace("5homesites remaining", "5 homesites remaining");
			comHtml=comHtml.replaceAll("2\r\n\\s+Wooded Homesites Available", "2 Wooded Homesites Available")
					.replace("\n" + 
							"                                \n" + 
							"                  </div>\n" + 
							"                  <div class=\"fomo-block-option1-description\">\n" + 
							"                    ", " ")
					.replace("\n" + 
							"                                </div>\n" + 
							"                                <div class=\"fomo-block-option1-description\">", " ");
			
			//comHtml=comHtml.replace("Finished basements available","");
			
			String eg=U.getSectionValue(comHtml, "<div class=\"fomo-block-option1-remaining\">", "<form id=\"scheduleVisitForm\">\n" + 
					"");
			
			comHtml = comHtml.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">", "$1 ")
					.replaceAll("There is just one opportunity remaining to build the Stapleton Duplex|class=\"homes-going\">\\s+Final (O|o)pportunity for (views|a walk)", "")
					.replaceAll("(\\d+)\\s+Homesite Remaining", "$1 Homesite Remaining").replace("ty-status-badge\">\n                                Coming Soon", "")
					.replaceAll("(\\d+)\\s+Homesites Remaining", "$1 Homesites Remaining").replaceAll("loan amount of $\\d{3},\\d{3}","")
					.replaceAll("estate homesites available", "").replace("1\n" + 
							"                                    </div>\n" + 
							"                                    <div class=\"fomo-block-option1-description\">Homesite remains", "1 Homesite remains")
					.replaceAll("secure one of the final two homesites in The Glens!", "secure one of the in The Glens!")	
					.replaceAll("\\w{4}\\W\\w{6}=\"Coming Soon\"", "\\w{4}\\W\\w{6}=\"\"")
					.replaceAll("Finished basements available", "").replaceAll("Price increases are coming soon", "")
					.replaceAll("homes sold in 3 weeks!", "").replaceAll("The Landing is sold out", "")
					.replace("<h5>Finished Basements Available</h5>", "")
					.replaceAll("14 homes sold in 3 weeks</div>", "").replace("latest phase has limited homesites", "").replace("Community Clubhouse is coming soon.", "");
					
			
//			U.log("##########"+eg);
			String removeSec=U.getSectionValue(comHtml, "8 COMMUNITIES NEAR", "Find Your Heartland Homes Community");
			if(removeSec!=null) {
				comHtml=comHtml.replace(removeSec, "");
			}
			
			String propStatus = U.getPropStatus((comHtml)
					.replace("The final phase of homesites", "").replace("pick your homesite in the final phase of Autumn Ridge", "")
					.replace("<h5>Basements Available</h5>", "")
					.replaceAll("New Home Design Coming", ""));
			
//			U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{50}sold out[\\w\\s\\W]{30}", 0));

			U.log("STATUS: "+propStatus);
			
			if (url.endsWith("/pa/allegheny/robinson-township/silver-summit"))
				propStatus = propStatus + ", Last Chance"; // from reg

			if (url.endsWith("neighborhoods/pa/allegheny/wexford/englishfarms"))
				propStatus = propStatus + ", Grand Opening"; // from reg
			
			if (url.contains("pennsylvania/marshall-township/venango-trails"))
				propStatus = "Final Opportunity, Last Chance";
			
			propStatus = propStatus.replaceAll("Quick Move-in, Quick Move In Now Available", "Quick Move-in");
			if(propStatus.contains("Homes Are Selling Quickly, ") && propStatus.contains("Selling Quickly"))propStatus = propStatus.replace(", Selling Quickly", "");
			name = name.replace("&#x27;s", "'s");
			add[1]= add[1].replace("North Strabane Township", "North Strabane");
			
			/*
			 * if(url.contains(
			 * "https://www.heartlandluxuryhomes.com/new-homes/communities/10222120152034/west-virginia/morgantown/autumnridge"
			 * )) { minPrice="$200000"; maxPrice="$400000"; }
			 */
	
			data.addCommunity(name, url, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyStatus(propStatus);
			data.addPropertyType(propType, dType);
			data.addNotes(notes);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
	}

}