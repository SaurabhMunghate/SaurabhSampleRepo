package com.shatam.b_001_020;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringEscapeUtils;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKbHomes extends AbstractScrapper {

	private static final String HOME_URL = "https://www.kbhome.com";
	private static final String BUILDER_NAME = "KB Home";

	CommunityLogger LOGGER;

	public ExtractKbHomes() throws Exception {
		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public static void main(String[] args) throws Exception {
//commneted 
		AbstractScrapper a = new ExtractKbHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "KB Home.csv", a.data().printAll());
	}

	@Override
	public void innerProcess() throws Exception {
//		String html = U.getHTML(HOME_URL);
		String html = U.getPageSource(HOME_URL);
//		String regionSection = U.getSectionValue(html, "<select class=\"counties\"", " <input type=\"submit\"");
//		regionSection = regionSection.replaceAll("<option value=\"\">", "");11
		String regUrls[] = U.getValues(html, "<li class=\"region-name leading-yellow-chevron-right\">", "</li>");
		for (String regUrl : regUrls) {
			if (regUrl.contains("/new-homes-closed") || regUrl.contains(".xml"))
				continue;
//			U.log("Region url"+regUrl);
			findCommunityUrl(HOME_URL + U.getSectionValue(regUrl, "<a href=\"", "\""));
//			break;
		}
		U.log("Total count ==" + cnt);
		U.log("Repeat ===" + dup);
		LOGGER.DisposeLogger();

	}

	private static Set<String> uniqueRegion = new HashSet<>();
	int cnt = 0;

	private void findCommunityUrl(String regUrl) throws Exception {

//		U.log("regUrl========"+regUrl);
//		String html = U.getHTML(regUrl);
		String html = U.getPageSource(regUrl);
		String commSection = U.getSectionValue(html, "var regionComms", "var regionMapData");
		String commData[] = U.getValues(commSection, "{", "}");
		//U.log(commData.length);
		if (!uniqueRegion.add(regUrl))
			return; // return repeated region url

		LOGGER.AddRegion(regUrl, commData.length);

//		U.log(regUrl);
		for (String comSec : commData) {
		
			
			String comUrl = U.getSectionValue(comSec, "\"Url\":\"", "\",");
//			U.log("comUrl===="+HOME_URL + comUrl);
			findCommunityDetails(HOME_URL + comUrl, comSec); //june 2022
			cnt++;
		}
	}

	int dup = 0, j = 0;

	private void findCommunityDetails(String comUrl, String comSec) throws Exception {
//		if(j >=310)
//		if(j>300 && j<=400)
	//	if(j>100 && j<=200)*****
//   1..	if(j>=169)
		//if(j >=0 && j<=100)*****

//		try{
		{

			// TODO : Single community exec
//		 if(!comUrl.contains("https://www.kbhome.com/new-homes-austin/scenic-pass")) return;
//       if(!comUrl.contains("https://www.kbhome.com/new-homes-orlando-area/preservation-pointe")) return;
			U.log("Count ==" + j);
			U.log("==>" + comUrl);


			if (data.communityUrlExists(comUrl)) {
				U.log("community repeated");
				LOGGER.AddCommunityUrl(comUrl + "============> Repeated URL");
				return;
			}

			if (comUrl.equals("https://www.kbhome.com/new-homes-denver-and-northern-colorado/sky-ranch") ||
					comUrl.contains("https://www.kbhome.com/new-homes-phoenix/oak-park")
//					comUrl.contains("https://www.kbhome.com/new-homes-phoenix/marbella-park")
					) 
			{
				U.log("community repeated");
				LOGGER.AddCommunityUrl(comUrl + "============> Return URL Page not found");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

//		if(comUrl != null)return;

			String html = U.getPageSource(comUrl);
//			U.log("====="+Util.matchAll(html, "[\\w\\s\\W]{30}Coming[\\s\\w\\W]{30}", 0));
			String quickSec = U.getSectionValue(html, "var LocalQMIs", "}];");
			String floorPlanSec = U.getSectionValue(html, "var FloorPlanList", "}];");

			String remSec = U.getSectionValue(html, "<div id=\"fb-root\">", "</body>");
//		U.log("--->"+remSec);
			if (remSec != null) {

				html = html.replace(remSec, "");
			}
			String relatedremSec = U.getSectionValue(html, "<section id=\"community-related\">", "</section>");
//		U.log("--->"+remSec);
			if (relatedremSec != null) {

				html = html.replace(relatedremSec, "");
			}

			// ============= Community Name ==================
			String commName = U.getSectionValue(comSec, "Community\":\"", "\",");
			commName = commName.replaceAll(
					"KB Home at | Villas$|- The Villas$|-the-villas$|-paired-homes$|-patio-homes$|Cottages$|basement-homes$|Townhomes$|Paired Homes$|Patio Homes$|®",
					"").replace("iii", "III").replace(" \\u0026 ", " & ").replace("\\u0027", "'");
			commName = commName.replace("Autumn Winds™", "Autumn Winds");
			commName = commName.replace("???", "-").replace("–", "-").replace(" Sahuarita", "");
			U.log("CommName ==>" + commName);
//			 U.log(comSec);
			// =========== Address ============================
			
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//			String AddressSec=U.getSectionValue(html, "<address>", "</address>");
//			U.log(AddressSec);
			// String addSec = U.getPageSource(comUrl+"#salesoffice");

//		add[0] = Util.match(comSec, "\"LocationInfo\":\"(.*?)\"", 1);
//		if(add[0].length()<3)
			add[0] = Util.match(comSec, "\"Address\":\"(.*?)\"", 1);

			add[1] = Util.match(comSec, "\"City\":\"(.*?)\"", 1);
			add[2] = Util.match(comSec, "\"State\":\"(.*?)\"", 1);
			add[3] = Util.match(comSec, "\"Zip\":\"(.*?)\"", 1);
			if (add[0].contains("Call "))
				add[0] = ALLOW_BLANK;
//		if (add[0].contains("(")) {
//			String loc1 = add[0].substring(add[0].indexOf("("));
//			add[0] = add[0].replace(loc1, "");
//		}

//	U.log(add[0]);
			if (add[0].startsWith("(") && add[0].endsWith(")"))
				add[0] = add[0].replaceAll("\\(|\\)", "");
			add[0] = add[0].replaceAll(
					"Office closed|open by Appointment only|(Open )?By Appointment (O|o)nly| - temp sales center until new sales center opens|Coming Soon|Please call to set up an appointmen",
					"");
			add[0] = add[0].replace(".", "");

			add[0] = add[0].replace("Sales Centre: ", "").replace(" \\u0026 ", " & ").replace("Sales Gallery: ", "")
					.replace("1475 Ceremony", "147 Ceremony")
					.replace("Covey Rd and Cloud Haven Dr", "9673 Trailhead Lane");
			add[0] = add[0].replace(" &amp;", "&").replaceAll(",", "");
			add[1] = add[1].replace("Mandarin in ", "");
			U.log(add[1]);
			add[1] = add[1].replace("O\\u0027 Lakes", "O' Lakes");

			if (comUrl.contains("https://www.kbhome.com/new-homes-austin-san-marcos/brentwood-villas"))
				add[0] = "W Slaughter Ln and Mary Moore Searight Dr.";
			if(comUrl.contains("https://www.kbhome.com/new-homes-san-antonio/mission-del-lago"))
				add[0] = "Lagoon Landing & Del Lago Pkwy";
//		if(comUrl.contains("https://www.kbhome.com/new-homes-denver-and-northern-colorado/canyons-villas")) add[0] = "East of I-25 South on Hess Rd";
			add[0]=add[0].replace("Foster Rd & Windfield Path", "3514 Andromeda Way").replace("W Thomas Rd and N Avondale Blvd", "11438 W La Reata Ave").replace("518 Kayak Cove", "5018 Kayak Cove")
					.replace("US-401 and Kipling Rd", "5631 Christian Light Rd").replace("Riceland Way and Hwy 24/27", "Riceland Way and Hwy").replace("Martindale Rd and Selinsky Rd", "5028 Jonina Ln")
					.replace("On the northwest corner of 83rd Ave & W Broadway Rd","83rd Ave & W Broadway Rd");
		String addSec1=ALLOW_BLANK;
			if(comUrl.contains("https://www.kbhome.com/new-homes-denver-and-northern-colorado/windsong")
					||comUrl.contains("https://www.kbhome.com/new-homes-dallas-fort-worth/retreat-at-stonebriar")
					||comUrl.contains("https://www.kbhome.com/new-homes-austin/village-at-northtown")
					||comUrl.contains("https://www.kbhome.com/new-homes-san-antonio/mission-del-lago")
					||comUrl.contains("https://www.kbhome.com/new-homes-austin/scenic-pass")) {
				addSec1=U.getSectionValue(html, "<address>", " </address>");
				addSec1=addSec1.replaceAll("\\s*<br/>\\s*", ", ");
//				U.log("addSec ::" +addSec1);

				addSec1=U.getNoHtml(addSec1).trim().replace(" (Heatherwilde Blvd. and Wells Branch Pkwy.)", "")
						.replace(" (Stillridge Dr. and Hwy. 71)", "");
				U.log("addSec ::" +addSec1);
				add=U.getAddress(addSec1);
			}

			
			U.log("Add ::" + Arrays.toString(add));

			// =============== latitude Longitude ============================
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latLong[0] = Util.match(comSec, "\"Lat\":\"(.*?)\"", 1);
			latLong[1] = Util.match(comSec, "\"Lng\":\"(.*?)\"", 1);
//U.log(">>>>>>>>"+comSec);
			if (latLong[0].contains("-")) {
				String temp = latLong[0];
				latLong[0] = latLong[1];
				latLong[1] = temp;
			}
			latLong[1]=latLong[1].replace(",851", "");
			U.log("LatLng::" + Arrays.toString(latLong));
			if (latLong[0].contains("111.970139")) {
				latLong[0] = "33.781556";
				latLong[1] = "-111.970139";
			}
			String geo = "FALSE";
			add[0] = add[0].replaceAll("By appointment|Buckeye", ALLOW_BLANK).replace(", Unit", " Unit");
			if (add[0] == ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latLong);
				if (add == null)
					add = U.getGoogleAddressWithKey(latLong);
				geo = "TRUE";
			}

			if (add[0].length() < 4) {
				String[] addrs = U.getAddressGoogleApi(latLong);
				if (addrs == null)
					addrs = U.getNewBingAddress(latLong);
				add[0] = addrs[0];
				geo = "True";
			}

			/*
			 * state & zip values are not visible on page
			 */
			String addSec = U.getSectionValue(html, "<address>", "</address>");
			if (addSec != null && !addSec.contains(add[2] + " " + add[3])) {
				U.log("******* Incomplete address is found on main page.");
				geo = "True";
			}
			
			if(comUrl.contains("https://www.kbhome.com/new-homes-bay-area-north/copperleaf-at-homestead")) {
				geo="True";//bcz add not given in web p[age bt found on sourcecode
			}
			if(comUrl.contains("https://www.kbhome.com/new-homes-orlando-area/preservation-pointe")) {
				latLong=U.getlatlongGoogleApi(add);//bcz latlng showing in lake
			}

			// ========== Home Sections ==============
			html = html.replace("\"Stories\":\"", "\"Stories ");
			html = html.replaceAll("Plan \\d+ Loft|Plan 2 Loft", "Plan \\d+ Loft homes");
			String commDetailSec = U.getSectionValue(html, "id=\"left-sidebar\"", "</ul>")
					+ U.getSectionValue(html, "<section id=\"community-info\"", "</section>")
					+ U.getSectionValue(html, "<div id=\"community-lightbox-dialog", "<script>")
					+ U.getSectionValue(html, "<div id=\"community-lightbox-dialog", "<script>")
					+ U.getSectionValue(html, "<section id=\"community-hero\"", "</section>"); // "id=\"description\">");

			floorPlanSec = floorPlanSec + U.getSectionValue(html, "var floorPlanList", "</script>")
					+ U.getSectionValue(html, "<section id=\"community-plans\" ", "</section>")
					+ U.getSectionValue(html, "var floorPlanList = [", "</script>");
			quickSec = quickSec + U.getSectionValue(html, "var localQMIs", "</script>")
					+ U.getSectionValue(html, "<section id=\"community-moveinready\"", "<script>");

//			 U.log("quickSec :"+floorPlanSec);
			// ============ Price ==================
//		U.log("-----"+commDetailSec);
			if (commDetailSec != null) {
				String cost = Util.match(commDetailSec, "\\$\\d{3}S|\\$\\d{3}s|\\$\\d{3}'s|\\$\\d{3}'S");
				U.log("cost" + cost);
				if (cost != null)
					commDetailSec = commDetailSec.replace(cost, cost.replaceAll("'s|'S|s|S", ",000"));
			}

			if (comUrl.contains("https://www.kbhome.com/new-homes-orange-county/elderberry-at-portola-springs")) {
				comSec = comSec.replace("From the low $1M", "");
			}
//		U.log(floorPlanSec);
			if (floorPlanSec != null)
				floorPlanSec = floorPlanSec.replace("loan of $304,086", "")
						.replaceAll("loan of \\$291,632|loan of \\$184,590|loan of \\$299,012|loan of \\$\\d{3}", "");
//		U.log("#############"+comSec+"***********************");
//		U.log(comSec);
			comSec = comSec.replaceAll("\"PricingMessage\":\"From the low \\$1M\",", "")
					.replaceAll("From the low \\$1M|the low \\$1 millions", "the low \\$1,000,000");
//		U.log(Util.matchAll(quickSec, "\\w*\\s*\\$223,750[\\s*\\w*]*", 0));
			// commDetailSec+quickSec+comSec+floorPlanSec

//		U.log(quickSec);    //$\\d{3},\\d{3}

			String[] price = U.getPrices(
					(commDetailSec + quickSec + floorPlanSec).replaceAll("WAS \\$\\d,\\d{3},\\d{3}", "")
							.replace("From the mid $200s", "From the mid $200,000"),
					"<span class=\"label\">Price</span>\\s+<strong>\\s+\\$\\d{3},\\d{3}\\s+</strong>|<strong>\\s+\\$\\d{3},\\d{3}\\s+</strong>|\\$\\d,\\d{3},\\d{3}|Price\":\"\\$[0-9]{1},[0-9]{3},[0-9]{3}|Priced from\\s+\\$\\d{1},\\d{3},\\d{3}|\"NumPrice\":\\d{6,7},|\\$\\d{3},\\d{3}|From the mid \\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3} &ndash; \\$\\d{1},\\d{3},\\d{3}|Priced from\\s+\\$\\d+,\\d+|Priced from\\W+\\$\\d,\\d+,\\d+|\\$\\d+,\\d+ &ndash; \\$\\d,\\d+,\\d+|\\$\\d+,\\d+ &ndash; \\$\\d+,\\d+|\"Price\":\"\\$\\d+,\\d+\"|\\$\\d+,\\d+ &ndash; \\$\\d+,\\d+|\\$\\d+,\\d+ &ndash; \\$\\d+,\\d+|\\$\\d{3},\\d{3}|class=\"list-stat\">\\s*(\\$\\d+,\\d+)|\\$\\d+,\\d+ - \\$\\d+,\\d+|\\$\\d,\\d+,\\d+|low \\$\\d+,\\d+|mid \\$\\d{3},{3}|the low \\$\\d,\\d{3},\\d{3}|\"NumPrice\":\\d{6,7},",
					0);
			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

//		U.log(price[0]);
//		U.log("====="+Util.match(commDetailSec+quickSec+comSec+floorPlanSec, ""));
			U.log("Min price :" + minPrice + "\tMax price :" + maxPrice);

			// =========== Square Feet =========================
			// Below Variable is for those community url where they redirected to own
			// community url.
			String floorQuickSec = U.getSectionValue(html, "Spacious Floor Plans</h2>", ">Quick Move-In Homes");
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		U.log(quickSec);
//			floorPlanSec=floorPlanSec.replace("\"Size\":\"", "\"Sq ft\":\"");
			comSec = comSec.replaceAll("\"SizeRange\":\"1209 – 1631\"", "\"SizeRange\":\"1209 – \"");
			
			String[] sqft = U.getSqareFeet(commDetailSec + quickSec + comSec + floorPlanSec + floorQuickSec,
					"<div class=\"data\">\\s+\\d{4} sqft\\s+</div>|SizeRange\":\"\\d{3,4} – \\d{4}|range from \\d{3,4} to \\d{4} square feet|> \\d{4} sq ft <|\\d+ to \\d+ sq. ft.|\"Size\":\"\\d+\"|Square Footage: </span>\\s+\\d+|Square Footage:\\s*</td>\\s*<td class=\"list-stat\">\\s*(\\d+)|Square Footage:</span> \\d+|ranging from \\d+ to \\d+ sq. ft|up to \\d,\\d{3} sq|> \\d{4} sq ft < ",
					0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			U.log("<>>>>>>>>"+Util.matchAll(comSec, "[\\w\\s\\W]{100}1631[\\s\\w\\W]{100}",0));
//			U.log("<>>>>>>>>"+Util.matchAll(quickSec, "[\\w\\s\\W]{100}1631[\\s\\w\\W]{100}",0));
//			U.log("<>>>>>>>>"+Util.matchAll(floorQuickSec, "[\\w\\s\\W]{100}1,631[\\s\\w\\W]{100}",0));

			
			if (comUrl.contains("https://www.kbhome.com/new-homes-orlando-area/canoe-creek-crossings"))
				minSqf = "1760";
			if (comUrl.contains("https://www.kbhome.com/new-homes-bay-area/signature-the-district"))
				minSqf = "665";
			// =========== Floor Plan Html ======================
			if (floorPlanSec == null)
				floorPlanSec = ALLOW_BLANK;
			String[] floorUrls = U.getValues(floorPlanSec, "Url\":\"", "\"");
			U.log("Floor Home ===" + floorUrls.length);
			String combinedFloorHtml = null;
			int x = 0;
			for (String floorUrl : floorUrls) {
//				U.log("http://www.kbhome.com"+floorUrl);
				String floorHtml = U.getPageSource("http://www.kbhome.com" + floorUrl);
				combinedFloorHtml += U.getSectionValue(floorHtml, "<div id=\"fpdetail-container",
						"<div id=\"interactiveTour")
						+ U.getSectionValue(floorHtml, "<h3>Exterior Options", "<div class=\"content")
						+ U.getSectionValue(floorHtml, "class=\"column small-12 medium-8 large-8", "</div>")
						+ U.getSectionValue(floorHtml, "<div class=\"highlights row secondary\">", "</div>");

				if (x > 10)
					break;
				x++;
			}
//		U.log("com::::::::::::::::"+combinedFloorHtml);
			// =========== Derived Community Type ============
			if (quickSec == null)
				quickSec = ALLOW_BLANK;
			quickSec = quickSec.replaceAll(
					"Colonial doors|RANCHO|rancho|Rancho|Ontario Ranch|Ranch Drive|Colonial White|Colonial interior doors|Colonial baseboard",
					"");

			String rem = "Patterson Ranch|Roberts Ranch|Colonial doors|RANCHO|rancho|floor|Floor|Rancho|Ontario Ranch|Ranch Drive|Colonial White|Colonial interior doors|Colonial baseboard|Ranch shopping|Ranch Marketplace|Ranch Town|Ranch Preserve|Cinco Ranch";
			String dType = ALLOW_BLANK;

			String vals[] = U.getValues(quickSec, "\"DisplayPricedFrom\":", "BedroomsMin");
//		 U.log(floorPlanSec);
			for (String val : vals) {
				quickSec = quickSec.replace(val, val.replaceAll("\"Stories\":\"(\\d)\",", " $1 Story "));
			}
			vals = U.getValues(floorPlanSec, "\"DisplayPricedFrom\":", "BedroomsMin");
			for (String val : vals) {
				floorPlanSec = floorPlanSec.replace(val, val.replaceAll("\"Stories\":\"(\\d)\",", " $1 Story "));
			}
			// U.log(floorPlanSec);
			/*
			 * U.log(ssec); if(ssec!=null){
			 * dType=dType+", "+U.getSectionValue(ssec,"\"Stories\":\"","\",\"").replace(
			 * "1","1 Story").replace("2","2 Story").replace("3","3 Story");
			 * 
			 * }
			 */

			if (floorPlanSec == ALLOW_BLANK || quickSec == ALLOW_BLANK) {
				dType = U.getdCommType((html + comUrl).replaceAll("Patterson Ranch|Roberts Ranch|floors of private|floor with glass", ""));
				U.log("Derived PType From 1");
			} else if (floorPlanSec != ALLOW_BLANK || quickSec != ALLOW_BLANK) {

				
//				U.log("<>>>>>>>>"+Util.matchAll(quickSec + floorPlanSec + comUrl + commName + commDetailSec + combinedFloorHtml, "[\\w\\s\\W]{100}Ranch[\\s\\w\\W]{100}",0));
	
				dType = U.getdCommType((quickSec + floorPlanSec + comUrl + commName + commDetailSec + combinedFloorHtml)
						.replaceAll(rem, ""));
				U.log("Derived PType From 2");
				// U.log((quickSec+floorPlanSec+comUrl+commName+commDetailSec+combinedFloorHtml).replaceAll(rem,
				// ""));
			}
			//U.log("<>>>>>>>>"+Util.matchAll(quickSec + floorPlanSec + comUrl + commName + commDetailSec + combinedFloorHtml, "[\\w\\s\\W]{100}Ranch[\\s\\w\\W]{100}",0));
			U.log("DType::" + dType);
			// U.log(floorPlanSec);

			// ================ Property Status=====================
//		String status = Util.match(comSec, ".*Floor Plans Available.*",0);
//		U.log("=="+status);

			String comhtml = U.getHTML(comUrl);
			// U.log("::::::::::::::_----------"+comhtml);
			/*
			 * String
			 * ssss=U.getSectionValue(comhtml,"<a data-tab=\"moveinready\" href=\"#\">\n" +
			 * "<span class=\"vertically-centered\">","</span></a></li>"); U.log(ssss);
			 */
			/*
			 * try { if(minSqf==ALLOW_BLANK) { String
			 * minsection=U.getSectionValue(comhtml,"DisplayPricedFrom\"","\"Stories");
			 * U.log(minsection); //"Size":"1933"
			 * minSqf=U.getSectionValue(minsection,"\"Size\":\"","\"");
			 * 
			 * maxSqf=ALLOW_BLANK; } } catch(NullPointerException ne) {
			 * 
			 * }
			 */

			if (comhtml.contains("covered patio ideal"))
				comhtml = comhtml.replace("covered patio ideal", "Patio");
			// String sec=U.getSectionValue(comhtml, "community-status", "/a>");
			String s = U.getSectionValue(comhtml, "dataLayer.page['community status'] = '", "';");
//		String s=U.getSectionValue(sec,">","<");

//			U.log(":::::::::::::::::::::&&::::::::" + s);
			String remStatus = ">Now Open</span>|<span class=\"hide-for-small \" style=\"\">New Phase Coming Soon</span>|<div id=\"badge-msg\"><span>New Floor Plans Available</span>|data-banner=\"Only a few homesites remain!\" o|span class=\"hide-for-small \" style=\"\">Only a few homesites remain!</span>|Quick Move-In Homes Coming Soon|photo-coming-soon|<span class=\"hide-for-small \" style=\"\">\\s*New Homesites Coming Soon\\s*</span>|data-banner=\"New Homesites Coming Soon\" |Address\":\"Coming Soon|indexOf(\"coming-soon\")|coming-soon-banner|New homes are coming soon to the Phoenix area|Grand Opening This Weekend|Move-in ready homes|Last Chance to Own |3907 Now Available|<span class=\"hide-for-small \" style=\"\">\\s*Now Open\\s*</span>|data-banner=\"Now Open\" |style=\"\">\\s*Coming Soon\\s*</span>|data-banner=\"Coming Soon\"|//--Coming Soon Image Text Banner|Four New Communities Coming Soon|Now open for information|Community pool opening soon|Community pool coming Spring 2017|Move-in Homes|move-in|quick|Quick|content=\"Coming|--Coming Soon|Coming Soon Text|image=\"Coming Soon|badge-msg\"><span>New Phase Opening Soon|Model Home Now|course home sites|Park, opening"
					+ "|data-banner=\"Two Homes Remain!\"|<span class=\"hide-for-small \" style=\"\">\\s*Two Homes Remain!\\s*</span>|Last Chance to Own|hide-for-small \" style=\"\">\\s+(Only One Home|Grand Opening|Last Chance)|Opening on Saturday|School opening|hide-for-small \" style=\"\">\\s+(Opening|Only \\d Homes)|data-banner=\"(Opening|Only \\d Homes)";
			html = html.replaceAll(remStatus, "");

			comSec = comSec.replaceAll(
					"New homes are coming soon to the Phoenix area|Address\":\"Coming Soon|Now open for information|Model Home Now|Status\":\"New Phase Opening|Move-In Ready Homes Available",
					"");

			String promoSec = U.getSectionValue(html, "promo hide-for-small\">", "</div>");
			if (promoSec != null)
				html = html.replace(promoSec, "");
			promoSec = U.getSectionValue(html, "<div class=\"promo row\">", "</a>");
			if (promoSec != null) {
				html = html.replace(promoSec, "");
				if (commDetailSec != null)
					commDetailSec = commDetailSec.replace(promoSec, "");
			}

			String comStatusSec = U.getSectionValue(html, "<div id=\"communityBadge\"", "<div class=\"heading\">")
					+ U.getSectionValue(html, "promo hide-for-small\">", "</div>")
					+ U.getSectionValue(html, "<li class=\"slideBanner", "<picture>")
					+ U.getSectionValue(html, "<div class=\"banner hide", "</div>");

			
			String seccc = U.getSectionValue(comhtml, "<div class=\"tab-control equalize\">", "</u>");
//			U.log("::::::::::::::::" + seccc);
//			U.log(">>>>>>> s: "+s);
			if (s != null)
				s = s.replaceAll("Move-In Ready Homes Available|Move-In Ready Homes Available (Active)", "");
			if (commDetailSec != null)
				commDetailSec = commDetailSec.replaceAll(
						"New homes are coming soon to the Phoenix area|wooded homesite|course homesites|Conservation Homesites|Larger homesites|cabana \\(opening|Move-In Ready Homes Available",
						"").replaceAll("<p>\\s+Coming Soon\\s+</p>", "")
						.replace("final home is now selling", "final home now selling")
						.replace("New homes are coming soon", "New homes coming soon")
						.replace("New Phase – Coming Winter 2021", "New Phase Coming Winter 2021");
			String propertyStatus = ALLOW_BLANK;
		

			String remove = U.getSectionValue(html, "<div class=\"community-chooser\">", "</html>");
			if(remove!=null)
				html = html.replace(remove, "");
			
			if (commDetailSec == null) {
				propertyStatus = U.getPropStatus((html + comSec + quickSec + s).replaceAll(
						"\"Status\":\"Coming Soon\"|office coming soon|Pool and Cabana Coming Soon|Sales office coming soon|data-banner=\"New Floor Plans Available|\"Status\":\"Grand Opening This Saturday\"|data-banner=\"Only a few homesites remain!\" o",
						"").replace("<span class=\"hide-for-small \" style=\"\">New Floor Plans Available</span>", ""))
						.replace("Move-in Homes Available", "");
				U.log("PStatus from 1");
			} else {	
				commDetailSec = commDetailSec.replaceAll("Sales office coming soon|ontactsales\">\\s+Coming Soon\\s+</a>", "");
				
				propertyStatus = U.getPropStatus(
						((commDetailSec + comStatusSec + quickSec + s).replace("(Closeout)", "").replace("Grand Opening This Weekend", "Grand Opening").replaceAll("Sales office coming soon|ontactsales\">\\s+Coming Soon\\s+</a>", "")
								.replaceAll(remStatus, "") + comSec).replaceAll(
								"\"Grand|Now Open\"|Community pool and cabana now open|ide-for-small active position-bottom\" style=\"\">Now Open</span>|New Phase Coming Soon\\s+</span>|\"New Phase Coming Soon\"|Status\":\"New Floor Plans Available\"|style=\"\">\\s+Only a few homesites remain!\\s+</span><div id=\"badge-msg\">\n\\s*\n*<span>\n\\s*\n*\\s*New Floor Plans Available","")
								.replaceAll("Tour a move-in ready home without a sales counselo|Move-in Ready Homes\\s+</spa|3 Move-in Ready Homes in this Community,|Open \\(Coming|Pool and Cabana Coming Soon|Model Homes Coming Soon|span>\\s+Model Home Now Open\\s+</span>|\"Status\":\"Grand Opening This Saturday\"|\"Only a few homesites remain\"|span class=\"hide-for-small \" style=\"\">Only a few homesites remain!</span>|\"StatusLink|data-banner=\"New Floor Plans Available","")
								.replaceAll("ide-for-small \" style=\"\">\n\\s*\n*\\s*New Floor Plans Available|office coming|Residence One Move|Model Homes Now",	"")
								.replaceAll("<span class=\"hide-for-small \" style=\"\">New Floor Plans Available</span>|Move-(i|I)n (R|r)eady","").replace("This lovely, two-story model home is one of the final opportunities to own at Aston Park", ""))
								.replaceAll("Status\":\"Coming Soon|ales office coming soon|ontactsales\">\\s+Coming Soon\\s+</a>","");
				if (propertyStatus.isEmpty())
					propertyStatus = ALLOW_BLANK;
				U.log("PStatus from 2: "+propertyStatus);
				//U.log(">>>>>>>>>>>>>"+Util.matchAll(s, "[\\w\\s\\W]*Coming Soon[\\s\\w\\W]{30}", 0));
			}
			
			if (comhtml.contains("No Quick Move-In homes are currently available")) {
				propertyStatus = propertyStatus.replaceAll(", Move-in Ready Homes|Move-in Ready Homes", "");
			}
			if(!comUrl.contains("/new-homes-san-bernardino-county/la-cresta-at-sycamore-hills")) {
				if(!comUrl.contains("/new-homes-charlotte-area/midland-crossing")) {
					if(s!=null) {
					if (s.contains("Move-In Ready Homes Available (Closeout)")) {
						propertyStatus = propertyStatus.replaceAll(", Move-in Ready Homes|Move-in Ready Homes", "");
					}
				}
				}
			}
			if (comhtml.contains("1 Move-in Ready Home")) {
				if (propertyStatus != ALLOW_BLANK)
					/*
					 * propertyStatus+=", Move-in Ready Home"; else
					 */
					propertyStatus += ", Move-in Ready Home";
				// propertyStatus.replace(", Move-in Ready Homes","");
			}
			if (comhtml.contains("2 Move-in Ready Homes")) {

				propertyStatus += ", Move-in Ready Home";

				// propertyStatus.replace(", Move-in Ready Homes","");
			}
//			if(comUrl.contains("https://www.kbhome.com/new-homes-seattle-tacoma-area/aston-park"))
//				propertyStatus=propertyStatus.replace("Final Opportunities,", "");
			
			
			
//			U.log("PStatus :: " + propertyStatus);

			String[] quickHomeSec = U.getValues(quickSec, "\"Title\":\"", "}");
//			String url="";
//			if(quickHomeSec.length>0) {
//				for( String sec : quickHomeSec) {
//					url=U.getSectionValue(sec, "Url\":\"", "\",");
//					U.log("sec :::::::::::"+sec);
//				}
//			}
//			U.log(":::::::::::"+url);
			
			
//		U.log(Arrays.toString(quickHomeSec));
			U.log("quickHomeSec : " + quickHomeSec.length);

			/*
			 * if(quickHomeSec.length > 0 && !propertyStatus.contains("Quick Move-in Homes")
			 * && !html.contains("No Quick Move-In homes are currently available") ){
			 * propertyStatus=propertyStatus.
			 * replaceAll("Move-in Ready Homes, |, Move-in Ready Homes", ""); if
			 * (propertyStatus == ALLOW_BLANK) propertyStatus = "Quick Move In Homes"; else
			 * if(propertyStatus != ALLOW_BLANK) propertyStatus = propertyStatus +
			 * ", Quick Move In Homes"; }
			 */
			/*
			 * propertyStatus =
			 * propertyStatus.replaceAll("Move-in Ready Homes, Quick Move In Homes",
			 * "Quick Move In Homes").replace("Quick Move-in, Quick Move In Homes",
			 * "Quick Move In Homes") .replace("Quick Move-in Homes",
			 * "Quick Move In Homes");
			 */

			if (quickHomeSec.length > 0 && !propertyStatus.contains("Move-in Ready Home")
					&& !html.contains("No Move-in Ready Homes in this Community")) {
				propertyStatus = propertyStatus
						.replaceAll("Move-in Ready Homes, |, Move-in Ready Homes|, Move-in Ready", "");
				if (propertyStatus == ALLOW_BLANK)
					propertyStatus = "Move-in Ready Home";
				else if (propertyStatus != ALLOW_BLANK)
					propertyStatus = propertyStatus + ", Move-in Ready Home";
			}

//		if(propertyStatus.contains("Quick Move In Homes"))	propertyStatus=propertyStatus.replace("Quick Move-in Homes Available,","");

			if (propertyStatus.contains("Final Homesites Now Selling, Now Selling"))
				propertyStatus = propertyStatus.replace("Final Homesites Now Selling, Now Selling",
						"Final Homesites Now Selling");

			propertyStatus = propertyStatus
					.replace("New Phase Now Open, Now Open", "New Phase Now Open")
					.replace("Move-in Ready Homes Available", "Move-in Ready Homes");

			// =========== Property Type =====================

			html = html.replace("Plan 1 Farmhouse", "Farmhouse-inspired architectura")
					.replaceAll("Residence Two Loft|<li>Loft", "with Loft ")
					.replaceAll("Residence 1 - Traditional 'A'", "Traditional exterior")
					.replaceAll("Residence 1 - Craftsman|Plan 2 Craftsman", "Craftsman style details");

			if (combinedFloorHtml != null)
				combinedFloorHtml = combinedFloorHtml.replace("Residence 1 - Traditional 'A'", "Traditional exterior")
						.replace("<p>Craftsman", "Craftsman style details");
			String sliderSec = U.getSectionValue(html, "<div class=\"slideshow", "<div class=\"controls");
			String pType = ALLOW_BLANK;
			String rem1 = "Plans/Villa|removed/Villa|-tracking=\"Villa|-marcos/villa|<h2>Villas at|villa-del|Plans/Villa|village|villas_|Villas_at|Village|luxurious tub|luxurious master bath| luxurious master suite |luxurious granite countertops| luxurious bath|winter garden homes, new homes at|winter garden homes, new homes at|Winter Garden homes, new homes|Garden homes, new homes at Orchard Park, KB Home|310 Cottage View|HOA dues and lot premiums|No HOA|no HOA| luxurious gas|_DUPLEX_|-Duplex-|-Duplex_|%20Duplex_|luxurious master bath|luxury kitchen|luxurious super master bath|_Townhomes-|HOA dues and concierge";

			// String removePatio=Util.matchAll(comhtml+combinedFloorHtml,
			// "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0);
//		commDetailSec=commDetailSec.replaceAll("MarbellaRanch_Plan2419-Patio_3130|Plan 2419 Patio|MarbellaRanch_Plan2419-Patio|Mirabella-Plan1859-Patio|Mirabella-Plan1859-Patio|MarbellaRanch_Plan2419-Patio|Marbella Ranch Plan \\d+ Patio|", "");
			// .replaceAll("MarbellaRanch_Plan2419-Patio_3130|Plan 2419
			// Patio|MarbellaRanch_Plan2419-Patio|Mirabella-Plan1859-Patio|Mirabella-Plan1859-Patio|MarbellaRanch_Plan2419-Patio|Marbella
			// Ranch Plan \\d+ Patio|", "")
			String psec = (html + combinedFloorHtml + comhtml).replaceAll(
					"spending 4 years in an apartment|(Closeout)|ove-In Ready Homes Available (Closeout)|%20Villa_200|Meadows Villas|meadows-villas|Ranch Villa Collection|crowfoot-villas|Crowfoot Villas|%20Villas|ranch-villa-collection|%20Townhomes%20|mirabella-townhomes|Mirabella Townhomes|Fielding Cottages|fielding-cottages|Bannon Lakes - Executive Series|bannon-lakes-executive-series|Bartram Creek - Executive Series|bartram-creek-executive-series|Bartram Creek - Executive Series\"],|The Preserve at Wells Creek - Executive Series\"]|Southshore at Bannon Lakes - Executive Series\"]",
					"")
					.replaceAll("Plan \\d+ Patio", "");
			String psec1 = (quickSec + commDetailSec + combinedFloorHtml + sliderSec + comhtml).replaceAll(
					"(Closeout)|ove-In Ready Homes Available (Closeout)|%20Villa_200|Meadows Villas|meadows-villas|Ranch Villa Collection|crowfoot-villas|Crowfoot Villas|%20Villas|ranch-villa-collection|%20Townhomes%20|mirabella-townhomes|Mirabella Townhomes|Fielding Cottages|fielding-cottages|Bannon Lakes - Executive Series|bannon-lakes-executive-series|Bartram Creek - Executive Series|bartram-creek-executive-series|MarbellaRanch_Plan2419-Patio_3130|Plan 2419 Patio|MarbellaRanch_Plan2419-Patio|Mirabella-Plan1859-Patio|Mirabella-Plan1859-Patio|MarbellaRanch_Plan2419-Patio|Marbella Ranch Plan \\d+ Patio|",
					"").replaceAll(
							"spending 4 years in an apartment|Bartram Creek - Executive Series\"],|The Preserve at Wells Creek - Executive Series\"]|Southshore at Bannon Lakes - Executive Series\"]",
							"");
			
		//	U.log("$$$$$$$$$$$$"+Util.matchAll(psec1, "[\\s\\w\\W]{30}flex[\\s\\w\\W]{30}", 0));
//			.replaceAll("Landings at Riverbend Townhomes|landings-at-riverbend-townhomes|","")
			
			if (commDetailSec == null && quickSec == ALLOW_BLANK) {
				rem1 = rem1 + "patio</li>";
				U.log("Property Type::::::::");
				pType = U.getPropType(psec.replace("The Preserve at Wells Creek - Executive Series", "").replaceAll("Landings at Riverbend Townhomes|landings-at-riverbend-townhomes|","").replaceAll(rem1, "").replaceAll("spending 4 years in an apartment|Plan 1859 Patio", ""));
				
				
			} else {
				psec1 = psec1.replaceAll("Plan \\d{4} - Patio\"|Plan\\d+-Patio|Plan \\d{4} - Patio|Plan \\d{4} Patio|Back Patio|Plan \\d{4} Back Patio|"
						+ "Montevello_3061-Patio|Plan 1209 - 6-Plex Building|very happy with our new KB custom home and the KB home|"
						+ "Row Homes at Lacy Crossing Thumbnail|Row Homes at Lacy Crossing|townhomes-at-lacy-crossing|Townhomes%20at%20Lacy|"
						+ "Townhomes at Lacy|C_Cottage_|Prairie Village Villas Thumbnail|prairie-village-villas|Colliers Hill Villas|colliers-hill-villas|"
						+ "Prairie Village Villas|Painted Prairie Villas|painted-prairie-villas|Sky Ranch Villas|sky-ranch-villas|sky-ranch-villas|"
						+ "Community Common Area with Park|Paired Homes Elevation|_Patio_|vinyl windows and patio doors with screens|alt=\"6-Plex\"|"
						+ "meadows-at-oakleaf-townhomes|Meadows at Oakleaf Townhomes|Jacksonville, FL -  6-Plex\"|ption\">\\s+6-Plex\\s+</div>|"
						+ "/5-Plex%20E|5 Plex Elevation|4 Plex Elevation|4-Plex Street View Scheme|4-Plex%20Scheme|4-Plex Scheme 1|Centennial Ranch Lot|"
						+ "alt=\"4-Plex\"|orchard-park-townhomes|Orchard Park Townhomes|Elevation C / 4-plex|Elevation B / 4-plex|haven-villas-at-sundance|"
						+ "HavenVillasAtSundance|Villas at Sundance Thumbnail|Haven Villas at Sundance|centrella-villas|Centrella Villas|fielding-villas|"
						+ "Fielding Villas Thumbnail|FIELDING%20VILLAS|Fielding Villas|mission-villas|_MissionVillas_|Villas Thumbnail|Mission Villas", "");
				
				psec1 = psec1.replaceAll("Plan 1516 4-Plex|Plan 1432 4-Plex|Plan 1516 4-Plex|Plan 1432 4-Plex|Plan 1516 4-Plex|Plan 1432 4-Plex","").replace("Jacksonville, FL -  6-Plex", "").replace("5-Plex-E-Italian","");
				
			//	U.log("mmmmmmm!"+Util.matchAll(psec1, "[\\s\\w\\W]{30}4-Plex[\\s\\w\\W]{30}", 0));
				pType = U.getPropType(psec1.replace("The Preserve at Wells Creek - Executive Series", "").replaceAll("Craftsman_sch1.jpg|Cottage_sch4.jpg|Cottage_sch5.jpg|Craftsman_sch14.jpg|Farmhouse_sch6.jpg|Residence Two Loft|<li>Loft|Loft\\s*</li>", "loft options available")
						.replaceAll("Landings at Riverbend Townhomes|landings-at-riverbend-townhomes","")
						.replaceAll("spending 4 years in an apartment|Plan 1859 Patio|Plan 1591 Patio", "").replaceAll(rem1, "")).replaceAll("Plan \\d+ Patio", "");
			}
//			U.log(Util.matchAll(psec1, "[\\s\\w\\W]{30}Villas[\\s\\w\\W]{30}", 0));
//		U.log(commDetailSec);
//		U.log(comhtml);
//		U.log(combinedFloorHtml);
//		U.log(Util.matchAll(comhtml, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0));
//			U.log(">>>>>>>>>>>: "+Util.matchAll(psec1, "[\\s\\w\\W]{30}6-Plex[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>: "+Util.matchAll(psec1, "[\\s\\w\\W]{30}Villas[\\s\\w\\W]{30}", 0));
//			U.log("pType::" + pType);
			
//			U.log("Status   :::::::::::: "+propertyStatus);

			// ============= Community Type ================
			html = html.replaceAll(
					"Gated garage |golf courses, and school|Fire Golf Course|Mini Golf Course|(Mirror|Spring) Lake (C|c)ommunity|Lost Pines Resort|fully irrigated yard|Lakefront Community (Entrance|Open Air|Park|Greenspaces)|Lakefront community, Lakewood|"
					+ "golfing, biking and wineries",
					"");
			
			
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}waterfront[\\w\\s\\W]{30}", 0));
			
			String comType = U.getCommunityType(html.replaceAll("renowned thriving downtown waterfront|Park and Crooked Tree Golf Course", ""));
			
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}Golf[\\w\\s\\W]{30}", 0));
//			U.log("COMMUNITY TYPE   :  "+comType);

			if (comUrl.contains("https://www.kbhome.com/new-homes-bay-area/signature-72-townsend"))
				maxPrice = ALLOW_BLANK;

			if (comUrl.contains("https://www.kbhome.com/new-homes-houston/yorktowne-oaks"))
				propertyStatus = ALLOW_BLANK;
			if (comUrl.contains("https://www.kbhome.com/new-homes-austin-san-marcos/greenlawn-village")) {
				pType = "Loft";
			}
			// if(comUrl.contains("https://www.kbhome.com/new-homes-phoenix/entrada-del-oro-ii"))add[0]="";
			if (comUrl.contains("/new-homes-raleigh-durham/reunion-pointe"))
				propertyStatus = "Final Homesites";
			if (comUrl.contains("https://www.kbhome.com/new-homes-riverside-san-bernardino-county/seneca")) {
				add[0] = "40534 Calla Lilly St.";
				geo = "FALSE";
			}

			if (propertyStatus.contains("Quick Move-in Homes Available"))
				propertyStatus = propertyStatus.replace(" Available", "");
			if (propertyStatus.contains("Opening Soon, New Phase Opening Soon"))
				propertyStatus = propertyStatus.replace("Opening Soon, New Phase Opening Soon",
						"New Phase Opening Soon");
			add[0] = add[0].replaceAll("\\(.*\\)", "");
			String notes = ALLOW_BLANK;
			// if(comUrl.contains("https://www.kbhome.com/new-homes-san-antonio/the-vistas-of-carmona-hills"))propertyStatus="Final
			// Homesites, "+propertyStatus;
//		notes=U.getnote(html);
//		if(propertyStatus.contains("Quick Move")) {notes="New Homes For Sale";}
//		else { notes=notes+"New Homes For Sale";}
			if (commName.endsWith("Lake") && comType.contains("Lakeside Community"))
				comType = comType.replaceAll(",*Lakeside Community,*", ALLOW_BLANK);

			U.log(propertyStatus);
			propertyStatus = propertyStatus.replaceAll(
					"Move-in Homes Available, Quick Move In Homes|Move-in Ready Homes Available, Quick Move In Homes",
					"Quick Move In Homes"); // .replaceAll("Move-in Ready Homes", "Quick Move In Homes");

			if (comUrl.contains("https://www.kbhome.com/new-homes-austin/greenlawn-village")) {
				propertyStatus = propertyStatus + ",Move-in Ready Homes";
				minPrice = "$378,485";
			}
			if (comUrl.contains("https://www.kbhome.com/new-homes-las-vegas/reserves-at-tanglewood")) {
				propertyStatus = propertyStatus + ",Move-in Ready Homes";
				minPrice = "$452,760";
			}
			if (comUrl.contains("https://www.kbhome.com/new-homes-houston/briscoe-falls-preserve"))
				minSqf = "2314";

			if (propertyStatus.length() < 4)
				propertyStatus = ALLOW_BLANK;
			if (comUrl.contains("https://www.kbhome.com/new-homes-san-antonio/woodside-farms"))
				pType = "Loft";

			if (comUrl.contains("https://www.kbhome.com/new-homes-orlando-area/gramercy-farms-ii")) {
				propertyStatus = ALLOW_BLANK;
				propertyStatus = propertyStatus.replace("Move-in Ready Home", "");

			}

			if (comUrl.contains("https://www.kbhome.com/new-homes-las-vegas/cattara"))
				propertyStatus = "Move-in Ready Home";

//			if(comUrl.contains("https://www.kbhome.com/new-homes-houston/spring-creek"))propertyStatus="Coming Soon";
			/*
			 * if(comUrl.contains("https://www.kbhome.com/new-homes-las-vegas/cattara"))
			 * minSqf="1157"; maxSqf="1768";
			 */

			if (propertyStatus.contains("-,"))
				propertyStatus = propertyStatus.replace("-,", "");
			if (propertyStatus.contains("Move-in Ready Homes") && propertyStatus.contains(", Move-in Ready Home"))
				propertyStatus = propertyStatus.replace(", Move-in Ready Homes", "");
			if (propertyStatus.length() < 4) {
				propertyStatus = ALLOW_BLANK;
			}
			if (dType.length() < 4) {
				dType = ALLOW_BLANK;
			}
			if (propertyStatus.contains("Move-in Ready Home,Move-in Ready Homes"))
				propertyStatus = propertyStatus.replace(",Move-in Ready Homes", "");

			if (comUrl.contains("https://www.kbhome.com/new-homes-orlando-area/gramercy-farms-ii")) {
				propertyStatus = "Move-in Ready Home";
				minSqf = "1511";

			}
			if (comUrl.contains(
					"https://www.kbhome.com/new-homes-denver-and-northern-colorado/the-canyons-classic-collection"))
				pType = "Loft";
			if (comUrl.contains("https://www.kbhome.com/new-homes-las-vegas/cattara")) {
				minSqf = "1157";
				maxSqf = "1768";
			}
			if (comUrl.contains("https://www.kbhome.com/new-homes-las-vegas/groves-at-saddlebrook")) {
				maxPrice = "$257,990";
			}
			if (comUrl.contains("https://www.kbhome.com/new-homes-denver-and-northern-colorado/sky-ranch")) {
				maxPrice = "$533,000";
			}
			if (comUrl.contains("https://www.kbhome.com/new-homes-las-vegas/tarim")) {
				maxPrice = "$382,007";
			}
			if (comUrl.contains("https://www.kbhome.com/new-homes-denver-and-northern-colorado/sky-ranch")) {
				maxPrice = "$724,285";
			}

			if (minSqf == ALLOW_BLANK) {
				String secmin = ALLOW_BLANK;

				secmin = U.getSectionValue(comhtml, "\"DisplayPricedFrom\":\"", ",\"Stories\":");
				try {
					minSqf = U.getSectionValue(secmin, "\"Size\":\"", "\"");
				} catch (NullPointerException ne) {
					minSqf = ALLOW_BLANK;
				}

				/*
				 * if(comUrl.contains("https://www.kbhome.com/new-homes-phoenix/tortosa")) {
				 * secmin="dfg"; }
				 */
				U.log(minSqf);

			}

			if (comUrl.contains("https://www.kbhome.com/new-homes-lakeland-area/cayden-reserve"))
				propertyStatus = propertyStatus.replace("Closeout,", "");
			if (commName.contains("Executive")) {
				if (!pType.contains("Executive Style Homes")) {
					if (pType.length() > 4)
						pType += ", Executive Style Homes";
					else
						pType = "Executive Style Homes";
				}
			}
			if (comUrl.contains("cottages")) {
				if (!pType.contains("Cottage")) {
					if (pType.length() > 4)
						pType += ", Cottage";
					else
						pType = "Cottage";
				}
			}
			if (comUrl.contains("villa") && !comUrl.contains("village")) {
				if (!pType.contains("Villas")) {
					if (pType.length() > 4)
						pType += ", Villas";
					else {
						pType = "Villas";
					}
				}
			}
//			if (comUrl.contains("townhomes")) {
//				if (!pType.contains("Villas")) {
//					if (pType.length() > 4)
//						pType += ", Townhome";
//					else
//						pType = "Townhome";
//				}
//			}

			
			if(comUrl.contains("https://www.kbhome.com/x86339.xml"))
			{
				comUrl="https://www.kbhome.com/new-homes-orlando-area/bellaviva-i";
			}
			
			
			if(comUrl.contains("https://www.kbhome.com/new-homes-houston/katy-manor-preserve"))
				propertyStatus="New Phase Coming soon";
			
			if(comUrl.contains("https://www.kbhome.com/new-homes-denver-and-northern-colorado/central-park-villa-collection"))
				propertyStatus=propertyStatus+", Final phase selling";
			if(propertyStatus!=null)
				propertyStatus = propertyStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
			

			if (comUrl.contains(
					"https://www.kbhome.com/new-homes-jacksonville-st-augustine-area/the-preserve-at-wells-creek-classic-series")
					|| comUrl.contains("https://www.kbhome.com/new-homes-jacksonville-st-augustine-area/flagler-cove"))
				pType = pType.replace("Executive Style Homes,", "");

//			if (comUrl.contains("new-homes-phoenix/entrada-del-oro-ii"))
//				add[0] = ("W El Camino Viejo And US-60");
			data.addCommunity(commName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].replace("’", "'").trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPropertyType(pType.replace("Townhome, Townhome", "Townhome"), dType.replace("-,", ""));
			data.addPropertyStatus(
					propertyStatus.replace("Move-in Ready Home", "Move-in Ready Homes").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon").replace("Homess", "Homes"));
			data.addPrice(minPrice.trim(), maxPrice.trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(notes);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);

		}
		j++;
//		}catch(Exception e) {}
	}
}