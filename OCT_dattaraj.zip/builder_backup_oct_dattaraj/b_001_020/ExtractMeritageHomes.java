package com.shatam.b_001_020;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.internal.seleniumemulation.AddSelection;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMeritageHomes extends AbstractScrapper{
	int k = 0, i=0,dupli=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	int dup=0;
	private static final String builderUrl = "https://www.meritagehomes.com";
	
	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new ExtractMeritageHomes();
	//	U.logDebug(true);
		a.process();
		FileUtil.writeAllText( U.getCachePath()+"Meritage Homes.csv", a.data().printAll());
	}

	public ExtractMeritageHomes() throws Exception {
		super("Meritage Homes", "https://www.meritagehomes.com/");
		LOGGER = new CommunityLogger("Meritage Homes");
	}

	public void innerProcess() throws Exception {

		String html = U.getPageSource(builderUrl);
		String[] regionSec=U.getValues(html, "<a class=\"button button--white\"", ">");
		for (String region : regionSec) {
			region=U.getSectionValue(region, "href=\"", "\"");
			String regionUrl = builderUrl+region;
			
			U.log("**************" + regionUrl);
			
			String regionHtml = U.getPageSource(regionUrl);
			
			String[] subRegionSecs = U.getValues(regionHtml, "<a class=\"button button--black view\"", ">");
			//U.log(subRegionSecs.length);
			for (String subRegionSec : subRegionSecs) {
				subRegionSec=U.getSectionValue(subRegionSec, "=\"", "\"");
//				U.log(subRegionSec);
				String subRegionHtml=U.getPageSource("https://www.meritagehomes.com"+subRegionSec);
				U.log("https://www.meritagehomes.com"+subRegionSec);
				String subRegionUrl="https://www.meritagehomes.com"+subRegionSec;
				subRegionHtml=subRegionHtml.replace("VIP List Now Forming", "");
				 subRegionHtml= subRegionHtml.replaceAll("</div>\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "endsec"); 	
//				if (!subRegionSec.contains("/az/tucson"))continue;
//				U.log(subRegionHtml);
				String[] comingsooncommunitySecs = {};
				String[] communitySecs = {};
//				String[] communitySecs=U.getValues(subRegionHtml, "small-12 break-early-12 medium-6 column content", " <div class=\"bottom\">");
				comingsooncommunitySecs = U.getValues(subRegionHtml, "<div class=\"community-horizontal ", "<div class=\"bottom\">");
//				
//				if(communitySecs==null ||communitySecs.length==0 && subRegionHtml.contains("View Community")) {
//					communitySecs = U.getValues(subRegionHtml, "<div class=\"community-horizontal", "View Community");
//				}
				U.log("https://www.meritagehomes.com"+subRegionSec+"::::"+ communitySecs.length+comingsooncommunitySecs.length);
				LOGGER.AddRegion("https://www.meritagehomes.com"+subRegionSec, comingsooncommunitySecs.length);
				for (String commSec : communitySecs) {
//					U.log("Community Count :"+k);
			//	if (k >=94 && k <= 100)//done
//					if (k >=0 && k <= 100) //done
//					if (k >=135 && k <= 200) //done
//					if(k >= 300)
					{
					//U.log("K ="+k);
//						try	{
							
							
							addDetails(commSec,subRegionUrl);
							
//						} catch (Exception e) {}
						
					}
					//continue;
//					k++;
				}
				for (String commSec : comingsooncommunitySecs) {
//					U.log("Community Count :"+k);
			//	if (k >=94 && k <= 100)//done
//					if (k >=0 && k <= 100) //done
//					if (k >=135 && k <= 200) //done
//					if(k >= 200)
					{
					//U.log("K ="+k);
//						try {
						//U.log("FROM HERE"+commSec);
//							if(commSec == null)continue;
							addDetails(commSec,subRegionUrl); 
//					} catch (Exception e) {}
						
					}
					//continue;
					k++;
				}
				inr++;
			}
			
		
		}
		
	
		
		U.log("Total community "+k);
		U.log("Total Duplicate community "+dupli);
		LOGGER.DisposeLogger();
	}
	
	int j = 0;
	private void addDetails(String commSec,String subRegionUrl) throws Exception {
		
//	if(j >= 0 && j<=100)
//		if(j > 186 && j<=200)
//		if(j >= 206 && j<=300)
//	if(j < 50)
//	if(j >= 50)
//	if(j >= 105)
//	if(j >= 115 && j<=200)
		
//		try{
	{
//		if(commSec.contains("<div class=\"community-horizontal ")) {
//			commSec = U.getSectionValue(commSec, "<div class=\"community-horizontal ", " <div class=\"bottom\">");
//		}
		String commURL=U.getSectionValue(commSec, "<a class=\"button button--black view\" href=\"", "\">");
//		U.log(commSec);
		if (commURL==null) {
			commURL=U.getSectionValue(commSec, "<h3 class=\"community--name \">", "</a>");
			commURL=U.getSectionValue(commURL, "href=\"", "\"");
//			U.log(commURL);
		}
		commURL=builderUrl+commURL;
		
		
		//TODO ::For single community
//	if(!commURL.equals("https://www.meritagehomes.com/state/ca/sacramento/meadowlands")) return;
		
		
		//redirect url
		if(commURL.contains("https://www.meritagehomes.com/state/ca/bay-area/brookline"))return;
		if(commURL.contains("https://www.meritagehomes.com/state/az/tucson/la-estancia---artistry-series"))return;
		if(commURL.contains("https://www.meritagehomes.com/state/sc/greenville/victoria-park---garden"))return;
		if(commURL.contains("https://www.meritagehomes.com/state/ca/sacramento/sierra-crossings"))return;
		if(commURL.contains("https://www.meritagehomes.com/state/ca/sacramento/sierra-crossings-ii"))return;
		if(commURL.contains("/state/co/denver/inspiration")|| commURL.contains("/atlanta/longleaf-at-laurel-canyon"))return;
//	if(commURL.contains("https://www.meritagehomes.com/state/co/denver/buffalo-highlands"))return; // sept 2021
		commSec = commSec.replace("will offer quick move-in", "");
		
		U.log("==>>"+j+" :::");
		U.log("commURL: "+commURL);
		U.log(U.getCache(commURL));
		if (data.communityUrlExists(commURL))
		{
			dupli++;
			LOGGER.AddCommunityUrl("repeat======="+commURL);
			return;
		}
		
		if (commURL.contains("https://www.meritagehomes.com/state/ca/southern-ca/landmark") || commURL.contains("https://www.meritagehomes.com/state/ca/bay-area/palermo"))
		{
			dupli++;
			LOGGER.AddCommunityUrl("Return 404======="+commURL);
			return;
		}
		
		LOGGER.AddCommunityUrl("community url======="+commURL);
		
		String commHTML = U.getPageSource(commURL);
		U.log(U.getCache(commURL));
		
		String comHtml = commHTML; 
		
		String[] rem1=U.getValues(commHTML, "<div class=\"reveal promo-popup tiny\"", "<div class=\"disclaimer\">");
		if(rem1.length>0) {
			for(String remove:rem1) {
				commHTML=commHTML.replace(remove, "");
			}
		}
		String removeSec=U.getSectionValue(commHTML, "<h3>What&#39;s nearby</h3>", "</article>");
		if(removeSec!=null) {
			commHTML=commHTML.replace(removeSec, "");
		}
		
		
		
		commHTML=commHTML.replaceAll("\\s+", " ");
		String commName=U.getSectionValue(commSec, "community--name \"", "a>");
		commName=U.getSectionValue(commName,"\">", "<").trim();
		String cName=commName;
		if (commName.endsWith("Townhomes")) commName = commName.replace("Townhomes", "");
		
		commName=commName.replaceAll("New Phase - | - Estate$|Bungalows$|- The Villas|- The Lofts| - New Phase$|: Single Family Homes$|: Paired Homes$", "").replace("–", "-");
		//U.log(commSec);
		commName=commName.replace("Babcock Ranch-", "Babcock Ranch -");
		U.log(commName);
		String geo="false";
		
		String detailSec = U.getSectionValue(commHTML, " <div class=\"community-detail-overview pad\">", "View Community Video");
		if(detailSec==null)detailSec= U.getSectionValue(commHTML, "<div class=\"community-detail-overview pad\">", "<section class=\"tabbed-accordion");
		//==================================Address and latlon sec====================================================
		String lat=U.getSectionValue(commHTML, "data-lat=\"", "\"");
		String lon=U.getSectionValue(commHTML, "data-long=\"", "\"");
		U.log(lat+"   "+lon);
		String addressSection=U.getSectionValue(commHTML, "<strong> Sales Center </strong>", "Map View");
		if(addressSection == null)
		addressSection=U.getSectionValue(commHTML, "<strong>Sales Center</strong>", "Map View");
		if (addressSection ==null) addressSection=U.getSectionValue(commHTML, "<strong>Sales Center</strong>", "Map View");
		if (addressSection ==null) addressSection=U.getSectionValue(commHTML, "Community Address", "Directions");
		addressSection=addressSection.replaceAll("Temporary Office - Kingdom Heights|Meadows is now pre-selling from Celebration |Model Coming Soon", "");
		System.out.println("addressSection\t" + addressSection);

		String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		if (addressSection!=null) {
			addressSection=U.getSectionValue(addressSection, ">", "</p>").replace("Preselling from Celebration at Gladden Farms", "");
			U.log("addressSection: >>> "+addressSection);
//			addressSection=addressSection.replace("Preselling from Celebration at Gladden Farms", "");
			if (addressSection!=null) {
				addressSection=addressSection.replace("&amp;", "&").replace(", <br/>", "<br/>").replace("Pre-selling virtually", "").replace("Preselling from Homestead at Marley Park  14340 W. Andora St", "14340 W. Andora St")
						.replaceAll("Selling from Rancho del Lago - Heritage Series: 11137 S Silver Fern Drive", "11137 S Silver Fern Drive")
						.replaceAll("SOLD OUT|Call for Appointment|Preselling from La Estancia Homestead|Join the interest list today to stay up to date with presales and pricing.|Coming Soon:|Pre-selling from Tribute at Gladden Farms -|Schedule an appointment by calling \\d-\\d+-\\d+-\\d+|Call \\d-\\d+-\\d+-\\d+ for Appointment|Appointment Only|Now Selling from Arbors at Meadow Woods-|Now Selling from McAllister Landing - |Now Selling from Hawks Crest Townhomes- |Now selling from Twinwaters-|Pre-selling at Zanjero Trails: |Selling out of Florenza: |Selling out of Sienna Hills:|- Schedule an appointment by calling 1-877-275-6374 -|Call for appointment 1-877-275-6374 <br/>|COMING SOON| - By Appointment Only|By Appointment Only|VIP Pre-Sale List Now Forming: |By appointment only|Call 877-524-8716 for more details|Interest List Now Forming Call 877-275-6374|Interest List Now Forming Call 877-524-8716|Coming (S|s)oon|Now Selling from Lake Preserve - |Interest List Now Forming.|Call \\d{3}-\\d{3}-\\d{4}.|-|Call 18556221065 for Appointment", "")
						.replaceAll("Pre-selling virtually|Sold out|<p vif=\"community\"> |Preselling from San Tan Ridge|By appt only|Open by appointment only|Appt\\. Only|New phase coming soon|Preselling from Cadiz at Sedella|Preselling from Wildgrove|Preselling from Legacy at Homestead|Preselling from Sunset Farms|Preselling from Sedella|Comng Soon|Selling out of Almeria:|–|Now Selling from the Hatchery -|For more information call 877-736-0375|Schedule an appointment by calling 1-877-275-6374|Sales Center|Pre-selling from The Meadows|Selling from|Now Selling From Twinwaters|Selling Out Of Sienna Hills:|Now Selling from Park Place at Aloma|Innovation Park 4th Model's Casita|Call \\d-\\d+-\\d+-\\d+ for Appointment |Now Selling from Hammock Park|Now Selling from Lake Preserve|TBD|Now (s|S)elling from (Oviedo Gardens|Fuller Oak|Estates at Parkside|Westside Village)|Sold Out|Now Selling from Fullers Oak|Pre-selling out of The Meadows|Pre-sales: |coming soon|Now selling from Ashcroft at WaterGrass ", "");
				
				addressSection=addressSection.replace("<br/>", ",")
						.replace("SE GA 30082", "SE");
				//add=addressSection.split(",");
				addressSection = addressSection.replace("HoweyintheHills", "Howey-in-the-Hills").replace("FuquayVarina", "Fuquay-Varina")
						.replace("Preselling from Entrada del Rio  ", "").replaceAll("Pre Celebration at Gladden Farms", "")
						.replace("68226998 Avalon Rd", "6822-6998 Avalon Rd")
						.replace("Join the interest list today to stay up to date with presales and pricing.", "").replaceAll("Selling From Solorio|Preselling from La Estancia Homestead|Now preselling from Madera Town Center", "");
				U.log(addressSection);
				add=U.getAddress(addressSection);
				U.log("ADDRESS: "+Arrays.toString(add));
			}
		}
		
		U.log(Arrays.toString(add));
		if(commURL.contains("https://www.meritagehomes.com/state/fl/orlando/villamar")) {
			add[0] = "241 Terranova Blvd";
			add[1] = "Winter Haven";
			add[2] = "FL";
			add[3] = "33884";
			geo="True";
			//Winter Haven, FL 33884
		}
		if ((lat==ALLOW_BLANK||lat==null) && (!add[0].equals(ALLOW_BLANK)||add[0]!=null)) {
			String latlon[]=U.getlatlongGoogleApi(add);
			if(latlon == null)
				latlon = U.getGooleLatLong(add);
			
			lat=latlon[0];
			lon=latlon[1];
			geo="true";

			
		}
		
	
		
		U.log("Lat :"+lat+"\tlng :"+lon);
		if(lon!=null && !lon.startsWith("-"))
			lon = "-"+lon;
		
		U.log("Add::"+Arrays.toString(add));
//		if(commURL.contains("https://www.meritagehomes.com/state/ca/sacramento/crosswinds-at-river-oaks")) {
//			add[0]="Plumas Lake Park & Ride Hwy 70";
//			geo="TRUE";
//		}
		if ((lat !=ALLOW_BLANK ||lat!=null) && (add[0].equals(ALLOW_BLANK)||add[0]==null)) {
			
			String latlon[]={lat,lon};
			add=U.getAddressGoogleApi(latlon);
			if(add == null)
				add = U.getNewBingAddress(latlon);
			U.log(Arrays.toString(add)  + "\t my address");
			geo="true";
		}
		//==================================Price====================================================
		String combinedFloorHtml = null;
		String floorSec = U.getSectionValue(commHTML, "<section class=\"community-vertical fl-list\" aria", "aria-label=\"Quick Move Ins\">");
		if(floorSec != null){
			String[] floorUrls = U.getValues(floorSec, "<h3 class=", "</h3>");
			U.log("floor count="+floorUrls.length);
			int x = 0;
			for(String floorUrl : floorUrls){
				floorUrl = U.getSectionValue(floorUrl, "<a href=\"", "\"");
				U.log("floorUrl::"+builderUrl+floorUrl);
				if(x == 5)break;
				x++;
				//U.log(U.getCache(builderUrl+floorUrl));
				String floorHtml = U.getPageSource(builderUrl+floorUrl);
				combinedFloorHtml += U.getSectionValue(floorHtml, "class=\"community-detail-overview pad", "class=\"explore-floorplan\"");
			}
		}

		String[] floorUrls = U.getValues(floorSec, "<div class=\"mid\">", "View Floorplans </a>");
		U.log("floor count="+floorUrls.length);
		int x = 0;
		for(String floorUrl : floorUrls){
				floorUrl = U.getSectionValue(floorUrl, "<a href=\"", "\"");
				U.log("floorUrl::"+builderUrl+floorUrl);
				if(x == 5)break;
				x++;
				//U.log(U.getCache(builderUrl+floorUrl));
				String floorHtml = U.getPageSource(builderUrl+floorUrl);
				combinedFloorHtml += U.getSectionValue(floorHtml, "class=\"community-detail-overview pad", "class=\"explore-floorplan\"");
		}
		commHTML=commHTML.replaceAll("<meta.*?>|<span data-lazy=\".*?\">|<img class=.*?>|<img src=.*?>|Selling out of Florenza", "");
		commSec=commSec.replaceAll("content=\".*?\"|<span data-lazy=\".*?\">|<img class=.*?>|<img src=.*?>", "");
//		U.log(Util.match(commHTML,".*?\\$222,990.*?"));
		String statuscomsec=Util.match(commSec, "class=\"snipe\">\\s*<span>\\s*(.*?)\\s*</span>",0);
		U.log(statuscomsec+"::::::::::");
		if(statuscomsec!=null && statuscomsec.contains("Quick Move-in Homes Available")) {
			commSec=commSec.replace(statuscomsec, "");
//			U.log(commSec);
		}
		String prices[]={ALLOW_BLANK,ALLOW_BLANK};
		commSec=commSec.replaceAll("00's\\s+</p>|00&#39;s\\s+</p>", "00,000").replaceAll("00s", "00,000").replace("80s", "80,000").replaceAll("0s", "0,000");
		commHTML=commHTML.replace("$300,000s", "$300,000")
				.replace("the mid $200's", "the mid $200,000").replace("from the high 100s", "from the high $100s").replace("the Low $200's", "the Low $200s").replaceAll("0s", "0,000")
				.replace("00’s", "00,000").replace("00’s", "00,000")
				.replace("from the low $1 Millions", "from the low $1,000,000")
				.replace("500,000,000", "500,000");
		commHTML=formatPrices(commHTML);
		
		
	String removeNearbySection="";
		
		removeNearbySection=U.getSectionValue(commHTML, "Compare Nearby Communities", "text/javascript");
		
		if(removeNearbySection!=null)
		commHTML=commHTML.replace(removeNearbySection, "");
		

//		U.writeMyText(commHTML);
		prices=U.getPrices(commHTML+commSec, 
				"from the low \\$\\d+,\\d+,\\d+|Starting at\\s*</h3>\\s*<span>\\s*\\$\\d,\\d{3},\\d{3}|the mid \\$\\d{3},\\d{3}|community--range\">\\s?\\$\\d,\\d{3},\\d{3}|From the (mid|low) \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|<h3 class=\"community--range\">\\s+\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}\\s+</h3>|(s|S)tarting at \\$\\d,\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}| mid \\$\\d{3},\\d{3}|$324,294 - $324,294\\n\\s*</h3>|<h3 class=\"community--range\">\\s*\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\\s*</h3>|range\">\\s*\\n*\\s*\\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|[from|in] the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
		String minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		String maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log("Min Price "+minPrice+" Max Price "+maxPrice);
		commHTML=commHTML.replaceAll("\\$\\d{3},\\d{3}.\">", "");
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commHTML, "[\\s\\w\\W]{80}411,990[\\s\\w\\W]{80}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commSec, "[\\s\\w\\W]{80}411,990[\\s\\w\\W]{80}", 0));
		
		//==================================Sqft====================================================
		commHTML = commHTML.replaceAll("Sq. Feet\\s*</h3>\\s*<span>\\s*Up to |Sq ft\\s*<b>\\s*up to ", "Sq. Feet ");
		String sqft[]={ALLOW_BLANK,ALLOW_BLANK};
		sqft=U.getSqareFeet(commHTML+commSec, 
				"Approx. <b>\\d,\\d+</b> sq. ft. </p>|Approx. <b>\\d+</b> sq. ft.</p>|Approx. Sq. Ft. </h3> <span> \\d,\\d+ - \\d,\\d+ </span>|up to \\d,\\d{3} square feet|loor plans ranging from \\d,\\d{3} sq|ranging from \\d,\\d{3} to \\d,\\d{3} square feet|from \\d,\\d{3} – \\d,\\d{3} sq. ft|from \\d,\\d{3} – \\d,\\d{3} sq. ft. |\\d,\\d{3}-\\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} sq. ft|from \\d,\\d{3} to \\d,\\d{3}\\+ sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq. ft.|<strong>\\s*\\d{4} sq. feet\\s*</strong>|\\d,\\d{3} sq. ft|Sq. Feet - \\d,\\d{3}\\s*</span>|\\d,\\d{3} livable sq. ft.|Sq. Feet</h3>\\s+<span>Up to \\d,\\d{3}|Sq. Feet \\d,\\d{3}|Sq. Feet \\d{4}", 0);
		String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("Min sqft "+minSqf+" Max sqft "+maxSqf);
		
		//==================================Communntiy type====================================================
		String rem = U.getSectionValue(commHTML, "<footer ", "</footer>");
		if(rem != null) commHTML = commHTML.replace(rem, "");

		String neighborhood = U.getSectionValue(commHTML, "<h2>Welcome to the neighborhood</h2>", "</section>");
		if(neighborhood !=null)
			commHTML = commHTML.replace(neighborhood, "");
		if(combinedFloorHtml !=null && neighborhood !=null)
			combinedFloorHtml = combinedFloorHtml.replace(neighborhood, "");
		if(commSec !=null && neighborhood !=null)
			commSec = commSec.replace(neighborhood, "");
		commHTML=commHTML.replaceAll("Resort-Style Pool|resort-style pool", "")
				.replace("waterfront homesites available", "Waterfront Homesites available");
		String commType=U.getCommunityType(commURL.replace("active-adult", " active adult ")
										+(commHTML+commSec+combinedFloorHtml).replace("Resort-Style Pool|Lakefront Living", "lakefront home sites")
										.replaceAll("resort style pool|This home’s elongated foyer|contemporary lakefront home has a beautiful|contemporary home has beautiful lakefront|Topgolf|<a href=\"/state/az/active-adult\">\\s*Active Adult\\s*</a>|<a href=\"/active-adult\">\\s*Active Adult\\s*</a>|Browse Our 55\\+ Active Adult Communities|Active Adult|<h5>\\s*Golf Course|Augusta Ranch Golf", ""));
		U.log("commType=="+commType);

		//==================================Property type====================================================
		
		if(neighborhood ==null) neighborhood = "";
		
		commHTML=commHTML.replace("-cottage", "").replaceAll("Springs Bungalows home|Willowcrest Bungalows", "Willowcrest bungalow style homes")
				.replace("luxurious primary suite", "luxury homes").replace(" The Manor - Classic home", " The Manor homes - Classic home");
		String propType=U.getPropType(commSec+ (commHTML+combinedFloorHtml+commName).replace(neighborhood, "").replaceAll("Flex Space|flex space|flex room", "FLEX Homes")
				.replaceAll("Resort-Style Pool|craftsmanship|Cabin Run Bridge|From cabinet hardware|Villa Rica|---back-patio", ""));

		if(commURL.contains("https://www.meritagehomes.com/state/az/phoenix/homestead-at-marley-park---classic-series") || commURL.contains("https://www.meritagehomes.com/state/az/phoenix/homestead-at-marley-park---reserve-series"))
			propType = propType.replace("Estate-Style Homes,", "");
		U.log("propType:::::::::"+propType);
		
		//==================================Derived Property type====================================================
		String remove = "floor|Rancho|Ranch Marketplace|located in Rancho|Wood Ranch BBQ|Hurley Ranch|Chilton Ranch|(Wolf|Wildlife) Ranch|First Floor";
		if(detailSec==null)detailSec=ALLOW_BLANK;
		detailSec = detailSec.replaceAll("Stories\\s*</h3>\\s*<span>\\s*2", "2 Story");
		detailSec = detailSec.replaceAll("Stories\\s*</h3>\\s*<span>\\s*1 - 2", "1 story, 2 Story");

		U.log("detailSec:::::::::"+detailSec);
		String dPropType=U.getdCommType((commHTML.replaceAll("<h3> Stories </h3> <span> (\\d) - (\\d) </span>", " $1 story, $2 story").replaceAll("<h3> Stories </h3> <span> (\\d) </span>", " $1 Story")+commSec+detailSec).replaceAll(remove, ""));//.replace(commName, "")
		//==================================Property Status====================================================
		
		
		commHTML=commHTML.replaceAll("data-allow-all-closed|Explore the move-in|registration is now open|Coming Soon - 5135|coming soon to Babcock Ranch|Grand Opening - September 13, 2019|New Tucson Communities Coming September 2019|select quick move-in homes|Ready for Move-In Now|Coming Soon. Arcadia Ridge,|office coming soon|Model Coming Soon|community--series\"> Coming Soon|alt=\"Grand Opening\"|Sienna Grand Opening Event |Sienna Grand Opening|<span class=\"community--series\"> Now Available|Selling out of Almeria:|Platinum Series is coming soon to the desirable City of Sugar Land|Quick move-in home purchase agreements entered by|New homes are coming soon|Selling out of Sienna Hills:|center \\(coming soon|No Quick Move-in Homes|community\">\\s*Coming Soon\\s*<br/>|Quick Move In|<span>Quick Move-in <br/> Homes</span></a>|\"Quick Move Ins\"|\"Quick Move-ins\" />|<span>Quick Move-in <br />|wonderland is coming|soon\\s+<br/>\\s+Rancho|June on quick move-in homes| - Coming Soon", "")
				.replace("Opening in May 2021", "Opening May 2021").replaceAll("(C|c)enter (C|c)oming|Efficient Homes coming", "").replace("coming Spring of 2020", "coming Spring 2020").replace("new phase is coming soon", "new phase coming soon")
				.replace("Phase 2 of The Summit coming Summer 2019", "Phase 2 coming Summer 2019").replace("only a limited number of homesites remain", "only a limited homesites remain")
				.replace("+Location/ + Coming Soon", "").replaceAll("community\">\\s*Coming Soon\\s*<br />", "").replace("New phase opening in Fall 2021", "New phase opening Fall 2021").replace("Opening in 2021", "Opening 2021").replace("first-phase homesites available now", "first phase homesites available now");
		
		
		
		commSec = commSec.replaceAll("Coming soon to Anderson County|Grand Opening - September|Pool-sized Backyards Now Available|Selling out of Sienna Hills:| coming soon to Glendale|efficient homes coming soon|School - Coming Soon|community\">Coming Soon<br/>|clubhouse is coming|Only\\s*\\d*(.*?)Home Remains|Move-in Homes Coming", "")
				.replace("Phase 2 of The Summit coming Summer 2019", "Phase 2 coming Summer 2019")
				.replace("New phase opening in early 2020", "New phase opening early 2020")
				.replace("Grand Opening - December 2020", "Grand Opening December 2020");
		
//		U.log(">>>>>>"+Util.matchAll(commSec, "[\\w\\s\\W]{100}Closed[\\w\\s\\W]{100}", 0));
//		U.log(commSec+"\n"+statuscomsec);
		
/*		U.writeMyText(commSec.replaceAll("Amenity Center Coming Soon|Quick move-in homes now available|Now open from|Move-in Ready Homes Available|move-in ready homes with|Now open for sales in Anderson County|final opportunity to own near Orange|> Coming soon <br/> Goodyear|Champion Estates is coming soon|Plan Coming Soon|New Plans Coming Soon|coming-soon\">Coming Soon</a|alt=\"Coming Soon\"| Coming Soon<br />|_comingsoon_|/coming-soon\">|COMING SOON - JOIN THE INTEREST LIST|clubhouse is now open|our final quick-move in homes today", "").replace("Pool and Rec Center coming 2018", "").replace(" - ", " ")
				+(commHTML).replace("Opening in 2021", "Opening 2021").replaceAll("<span class=\"community--series\">Now Available</span>|<span>Basements Available</span>|Opening Soon -| our closeout communities today |e\"> <span>SOLD OUT</span|mmunity\"> Sold Out <br/>|on any quick move-in home|will offer quick move-in|COMING SOON<br />|community--series\">Coming|Discovery - New Phase|Grand Opening on March|Center Coming Soon|Amenity Coming Soon|Last chance to own at Modena|Among the final phases|Lakeview is coming soon| Coming soon to Goodyear|We just released|community\"> Coming soon <br/> |parks. Opening Summer 2019|Champion Estates is coming soon|New Plans Coming Soon|Coming Soon Homesite|Plan Coming Soon|on Quick Move-In Homes|alt=\"grand opening\"|Coming soon to a neighborhood near you|Closeout - Last Chance|Coming October, 2017|_comingsoon_final|comingsoon_final|Ready for move in|<span class=\"community--series\">\\s*Now available\\s*</span>|Quick Move-in|Quick Move In|COMING SOON - JOIN THE INTEREST LIST|Coming Soon\\s+</a|alt=\"Coming Soon\"|Coming Soon\\s+<br />|_comingsoon_|/coming-soon\">|<div class=\"snipe\">\\s+<span>Coming Soon",""));
*/		
		U.log("subRegionUrl======="+subRegionUrl);
		String regionHtml=U.getHTML(subRegionUrl);
		String regSec=null;
		String [] newregSec=U.getValues(regionHtml, "<div class=\"community-horizontal", "  <div class=\"mid\">");
		for(String reg : newregSec)
		{
			if(reg.contains(cName))
			{
				regSec=reg;
			}
		}
		
		String sts="";
		String quickSec=U.getSectionValue(commHTML, "Quick Move-in Homes", "Stay up to date with");
//		U.log("quickSec>>>>>>>>>\n"+quickSec);
		if(quickSec!=null) {
		String[] quickData=U.getValues(quickSec, "<h3 class=\"card-title\">", "View Quick Move-in");
		U.log("quickData==="+quickData.length);
		if(quickData.length>0) {
			sts="Quick Move-in";
		}
		}
		else
			U.log("NOT FOUND");
		
		
		commHTML = commHTML.replace("Sold out - Join the interest list", "")
				.replace("Coming to Forney in Spring 2022", "Coming Spring 2022")
				.replace("New phase, plans and model coming soon", "New phase coming soon")
				.replaceAll("Directions </a> <p> <br/> Coming Fall 2021", "")
				.replace("opening in Spring 2022", "opening Spring 2022")
				.replace("Winding Creek Townhomes is currently sold out", "Winding Creek Currently Sold Out Townhomes")
				.replace("Coming Soon. Scenic Crest is located just inside Boerne", "Scenic Crest is located just inside Boerne Coming Soon,");
		
		
		
		commSec=commSec.replaceAll("Amenity Coming Soon|Model Coming Soon|New Models Now Open","");
		regSec=regSec.replace("Amenity Coming Soon", "").replaceAll("Model Coming Soon|New Models Now Open", "")
				.replaceAll("<img src=\"//mthcdn.azureedge.net/-/media/assets/atlanta-ga/zz-closed-out-", "")
				.replace("Phase Two Coming Soon", "Phase II Coming Soon");
		
		if(commName.equals("Prescott Oaks")) {
			regSec = regSec.replace("New Homes Coming Late 2022", "");
		}
		if(commURL.equals("https://www.meritagehomes.com/state/ca/sacramento/meadowlands")) regSec = regSec.replace("Sold Out", "");
		
		String propStatus=U.getPropStatus((regSec+commName+commSec.replaceAll("Model Homes Coming Soon|snipe-overlay\"> <span> Coming Soon </span>|Quick Move|Remove Gallery from Metro Page. -->\\s*\n\\s*<div class=\"snipe snipe-overlay\">\n\\s*<span>\n\\s*Sold Out|Move-in ready|quick move-in townhomes|Amenity Center Coming Soon|Quick move-in homes now available|Now open from|Move-in Ready Homes Available|move-in ready homes with|Now open for sales in Anderson County|final opportunity to own near Orange|> Coming soon <br/> Goodyear|Champion Estates is coming soon|Plan Coming Soon|New Plans Coming Soon|coming-soon\">Coming Soon</a|alt=\"Coming Soon\"| Coming Soon<br />|_comingsoon_|/coming-soon\">|COMING SOON - JOIN THE INTEREST LIST|clubhouse is now open|our final quick-move in homes today", "").replace("Pool and Rec Center coming 2018", "").replace(" - ", " ")
				+(commHTML.replace("A new phase is coming soon", "A new phase coming soon")
						.replace("A new phase at La Estancia - Homestead is coming soon", "A new phase coming soon")
						.replace("Coming Soon. Catalina offers gorgeous sur", "")).replaceAll("snipe-overlay\"> <span> Coming Soon </span>", "").replace("Opening in 2021", "Opening 2021")
				.replaceAll("Cornerstone Crossings is coming soon|Floorplan Coming|amenities are coming|Coming Soon<br />|Coming Soon\\+Winchester|Cornerstone Commons is coming soon|Hawks Crest are now selling out of Legacy Place|Model Homes Coming Soon|Currently selling by appointment only|Coming Fall 2022, Clear Pond will feature a variety|New models are now open|New Models Now Open|A community pool and cabana coming soon|Directions </a> <p> <br/> Coming [S|s]oon|model is coming soon|Quick Move|Coming Fall 2021 to Braselton|Sold Out\\.\\s*Charming homes with fabulous included features|coming soon to Snellville|efficient homes coming soon|Coming Soon\\. Scenic Crest|Ranch is coming soon|[m|M]ove-in|[q|Q]uick [m|M]ove|LAST CHANCE - Located right off I-30|coming soon community|- Few Homesites remain.|Coming Soon - \\d+|-closed-out-|<span class=\"community--series\">Now Available</span>|<span>Basements Available</span>|Opening Soon -| our closeout communities today |e\"> <span>SOLD OUT</span|mmunity\"> Sold Out <br/>|on any quick move-in home|will offer quick move-in|COMING SOON<br />|community--series\">Coming|Discovery - New Phase|Grand Opening on March|Center Coming Soon|Amenity Coming Soon|Last chance to own at Modena|Among the final phases|Lakeview is coming soon| Coming soon to Goodyear|We just released|community\"> Coming soon <br/> |parks. Opening Summer 2019|Champion Estates is coming soon|New Plans Coming Soon|Coming Soon Homesite|Plan Coming Soon|on Quick Move-In Homes|alt=\"grand opening\"|Coming soon to a neighborhood near you|Closeout - Last Chance|Coming October, 2017|_comingsoon_final|comingsoon_final|Ready for move in|<span class=\"community--series\">\\s*Now available\\s*</span>|Quick Move-in|Quick Move In|COMING SOON - JOIN THE INTEREST LIST|Coming Soon\\s+</a|alt=\"Coming Soon\"|Coming Soon\\s+<br />|_comingsoon_|/coming-soon\">|<div class=\"snipe\">\\s+<span>Coming Soon","")
				+sts).replace("Model Coming Soon", "").replaceAll("Model Homes Coming Soon", ""));
		
		U.log("Status:::::::::: "+propStatus);
		
//		U.log("MMMMMMMMMM "+Util.matchAll(commHTML, "[\\s\\w\\W]{50}coming soon[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMMM "+Util.matchAll(regSec+commName+commSec+sts, "[\\s\\w\\W]{50}Coming Soon[\\s\\w\\W]{50}", 0));
//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/prosts.txt", regSec+commName+commSec+sts);
		
//		U.log("regSec=======\n"+regSec);
		//==================================Notes====================================================
//		String propStatus=U.getPropStatus(commSec);
		String notes=U.getnote((regSec+commHTML+commSec).replace("Noe Pre-Selling", "Now Pre-Selling").replaceAll("pre-sales and pricing|access to our presales", ""));
		U.log("notes: "+notes);
//		U.log("MMMMMMMMMM "+Util.matchAll(regSec+commHTML+commSec, "[\\s\\w\\W]{50}pre-sales[\\s\\w\\W]{50}", 0));
		
		//========================================================================================================
//		U.log(commSec);
		propStatus = propStatus.replace("Only A Few Homesites Remain, Only 1 Homesite Remains", "Only 1 Homesite Remains")
				.replace("Only 1 Homesite Remains, Only One Homesite Left", "Only One Homesite Left")
				.replaceAll("Quick Move-ins Available", "Quick Move-ins");
		if(propStatus.contains("Only Four Homes Left") && propStatus.contains("Only Two Homes Left")) {
			propStatus = propStatus.replace("Only Two Homes Left", "");
		}
		if(add[2].length()>3)
		add[2]=USStates.abbr(add[2]);

		commHTML=U.getHTML(commURL);
		//System.out.println("Rakesh\t" + propStatus);
		if(commHTML.contains("No Quick Move-in Homes available at this time") && !commSec.contains("tab-qmi-title")){
			propStatus=propStatus.replaceAll("\\s*\\d Quick Move-in Homes,|\\d Quick Move-in Homes?,|\\s*Quick Move-in Home,|\\s*Quick Move-in,|, Quick Move-in( Homes)?|\\d+ Quick Move-in", "");
			propStatus=propStatus.replaceAll("Quick Move-ins Available|\\d+ Quick Move-in Homes|Quick Move-in Homes|Quick Move-in Homes,|Quick Move-in Homes|\\d+ Quick Move-in|Quick Move-in", "");
//			if(propStatus==ALLOW_BLANK)
//				propStatus="No Quick Move-in Homes";
//			else
//				propStatus=propStatus+", No Quick Move-in Homes";
					
//			propStatus=U.getPropStatus(propStatus);
			
		}
//		propStatus = propStatus.replace("Move-in Ready Homes", "Quick Move-in Home");
		
		
		propStatus = propStatus.replace("New Homesites Coming Soon, Coming Soon", "New Homesites Coming Soon").replace("New Phase, New Phase Released", "New Phase Released");
		propStatus = propStatus.replace(" Waterfront Homesites Available, Waterfront Homesites Available", "Waterfront Homesites Available");
		//
/*		if(propStatus.contains("Opening Spring 2019, Grand Opening Spring 2019"))propStatus=propStatus.replace("Opening Spring 2019, Grand Opening Spring 2019", "Grand Opening Spring 2019");
		if(propStatus.contains("Opening March 2019, Grand Opening March 2019,"))propStatus=propStatus.replace("Opening March 2019, Grand Opening March 2019,", "Grand Opening March 2019,");
*/		if(commURL.contains("/state/tn/nashville/holland-ridge"))propStatus=propStatus.replace("Coming Soon", "New Homes Coming Soon");
		if(propStatus.contains("February"))propStatus=propStatus.replace("Grand Opening February 9,", "");
		
		//===================================================================================================
		if(commURL.contains("https://www.meritagehomes.com/state/ca/sacramento/marbella"))propStatus = propStatus.replace(", Sold Out", ""); 
		if(commURL.contains("https://www.meritagehomes.com/state/ga/atlanta/willowcrest-townhomes"))propStatus = propStatus.replace("Coming Soon,", ""); 
//		if(commURL.contains("https://www.meritagehomes.com/state/tx/houston/riverstone-ranch---the-manor---estate") ||
//				commURL.contains("https://www.meritagehomes.com/state/tx/houston/riverstone-ranch---the-landing")) commType = "Master Planned";
		
		if(commURL.contains("/ga/atlanta/willowcrest--bungalows")|| commURL.contains("state/ga/atlanta/bells-landing")) propStatus = "Currently Sold Out";

 
		if(commURL.contains("https://www.meritagehomes.com/state/ca/bay-area/sundance"))propStatus = "Coming Soon";
		if(commSec.contains("NOW OPEN &amp; SELLING"))
			propStatus = propStatus.replace("Now Open", "Now Open, Now Selling");
		U.log("propStatus: "+propStatus);
		propStatus =propStatus.replaceAll("Only (\\d+) Quick Move-in Homes Remain", "$1 Quick Move-in Home");//.replaceAll("\\d+ Quick Move-in Homes", "Quick Move-in Homes")
		if(propStatus.length()<=0)propStatus="-";
		
//		if(!propStatus.contains("Coming Soon") && commHTML.contains("comingsoon_1000x450")){
//			if(propStatus == ALLOW_BLANK)propStatus = "Coming Soon";
//			else if(propStatus != ALLOW_BLANK)propStatus += ", Coming Soon";
//		}
		if(!propStatus.contains("Last Chance") && commHTML.contains("lastchance_1000x450.ashx")){
			if(propStatus == ALLOW_BLANK)propStatus = "Last Chance";
			else if(propStatus != ALLOW_BLANK)propStatus += ", Last Chance";
		}
		
		if(commURL.contains("https://www.meritagehomes.com/state/ca/southern-ca/creekside"))propType = propType.replace("Estate-Style Homes,", "");
		if(commURL.contains("https://www.meritagehomes.com/state/fl/tampa/lake-hanna-preserve"))propStatus = propStatus.replace(", 4 Homes Remain", "");
		if(commURL.contains("https://www.meritagehomes.com/state/nc/raleigh/south--main"))notes = "Now Pre-Selling";
		propStatus = propStatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		
		if(propStatus==null)
			propStatus = ALLOW_BLANK;
		propStatus=propStatus.replace("1 Quick Move-in Home", "Quick Move-in Homes");
		U.log("==================="+propStatus);
		if(propStatus.contains("Quick Move-in"))
			propStatus = propStatus.replaceAll("\\d+ Quick Move-in Homes Available|\\d+ Quick Move-in Homes|Quick Move-in", "Quick Move-in Homes");
		
		propStatus = propStatus.trim().replaceAll("^,|,$", "");
		
		
//		U.log("111==================="+propStatus);
		//================================Writing data to csv===================================================
		
			if (commSec.replaceAll("<span>\n\\s*Final Phase\n\\s*</span>", "<span>Final Phase</span>").contains("<span>Final Phase</span>")) {
				if (propStatus.equals(ALLOW_BLANK)) {
					propStatus = "Final Phase";// From image Jun 23
				} else {
					if (!propStatus.contains("Final Phase")) {
						propStatus += ", Final Phase";
					}

				}
			}
		if(commURL.contains("https://www.meritagehomes.com/state/tx/dallasft-worth/berkshire---woodland-series")) {
			propStatus="Limited Homesites Available, Quick Move-in Homes";
		}
		U.log(add[0]);
		add[0] = add[0].replace("�", "").replace("Opening Soon  ", "").replace("Preselling from Homestead at Marley Park  14340 W. Andora St.", "14340 W. Andora St.").trim();
		if(commURL.contains("https://www.meritagehomes.com/state/az/phoenix/ellison-trails")) {
			add[0]="55th Ave &,  W Elliot Rd";
			add[1]="Laveen Village";
			add[2]="AZ";
			add[3]="85339";
		}
		int quickC=0;
		String quickCount=U.getSectionValue(commHTML, "<section class=\"community-vertical \" aria-label=\"Quick Move Ins\">", "<h2 class=\"text-center\">All-in Monthly Payment Calculator</h2>");
		if(quickCount!=null) {
			String[] quick=U.getValues(quickCount, "<h3 class=\"card-title\">", "</span>");
			quickC++;
		}
		if(quickC>0 && !propStatus.contains("Move-in")) {
			if(propStatus==ALLOW_BLANK)
				propStatus="Quick Move-in Homes";
			else
				propStatus=propStatus+", Quick Move-in Homes";
					
			//propStatus=U.getPropStatus(propStatus);
			
		}
		if(propStatus!=null)
			propStatus = propStatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
//		if(commURL.contains("https://www.meritagehomes.com/state/ga/atlanta/bells-landing"))propStatus+=", Now Open";//Img
		
		if(propStatus!=null && propStatus.contains("Move-in"))
			propStatus = propStatus.replaceAll("\\d+ Quick Move-in,|\\d+ Quick Move-in", "Quick Move-in Homes").replace("Quick Move-in,", "Quick Move-in Homes,");
		propStatus = propStatus.replace("New Phase Opening Fall 2021, New Phase Open", "New Phase Opening Fall 2021").replace("Quick Move-in Homes Now Selling", "Quick Move-in Homes, Now Selling");
	
		
		if(commURL.contains("https://www.meritagehomes.com/state/fl/tampa/the-reserve-at-van-oaks")) {
			add[0]="139 Costa Loop";
			add[1]="Auburndale";
			add[2]="FL";
			add[3]="33823";
			geo="TRUE";
		}
		
//		if(commURL.contains("https://www.meritagehomes.com/state/fl/tampa/monroe-meadows"))propStatus="Quick Move-in Homes";
		if(commURL.contains("state/ca/southern-ca/harvest-at-rancho-mission-viejo"))propStatus=propStatus.replace("Coming Soon, ", "");

		propStatus=propStatus.replace("Homesites Available, Waterfront Homesites Available", "Waterfront Homesites Available")
				.replace("Homesites Available, Oversized Homesites Available", "Oversized Homesites Available")
				.replace("Limited Homesite, Limited Homesites Available", "Limited Homesites Available")
				.replace("Homes Homes", "Homes").replace("New Phase Now Selling, Now Selling", "New Phase Now Selling")//.replace("s Available", "")
				.replace("Final Phase Coming Soon, Final Phase", "Final Phase Coming Soon")
				;
		
		if(commURL.contains("southern-ca/arbor-at-legacy-park"))propStatus="Now Selling"; // from img
		if(commURL.contains("/state/sc/myrtle-beach/clear-pond"))propStatus=propStatus.replace(", Opening Fall 2022", ""); 
		if(commURL.contains("state/az/phoenix/new-phase---the-enclave-at-mission-royale---classic-series")|| commURL.contains("az/phoenix/new-phase---the-enclave-at-mission-royale---estate-series"))propStatus="New phase coming soon"; 
		
		if(commURL.contains("state/ca/bay-area/tramore-village-at-vanden-meadows")|| commURL.contains("state/ca/bay-area/waterford-village-at-vanden-meadows")|| commURL.contains("https://www.meritagehomes.com/state/ca/sacramento/encore-at-meadowlands"))propStatus="coming soon"; // from img

		
		if(propStatus.length()<4)propStatus=ALLOW_BLANK;
		if(commURL.equals("https://www.meritagehomes.com/state/tx/dallasft-worth/parkside-village"))propStatus=ALLOW_BLANK;
		
		
		//------------- Number Of Units -------------------------------------------------------
		
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		String unitCount = getUnits(comHtml, commURL);
		
		U.log("unitCount: "+unitCount);
		
		units = unitCount;
		
		
		data.addCommunity(commName.trim(), commURL, commType);
		data.addAddress(U.getCapitalise(add[0].replace("Preselling from Celebration at Gladden Farms", "").replace(",", "").toLowerCase()), add[1], add[2].trim(),add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lon.trim(), geo);
		data.addPropertyType(propType, dPropType);
		data.addPropertyStatus(propStatus.replace("Coming Soon, Limited Homesite", "Limited Homesite Coming Soon").replace("s Available", " Available").replace("Quick Move-in Homess", "Quick Move-in Homes"));
		data.addNotes(notes);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);

		
	}
	j++;
//		}catch (Exception e) {}
	}
	
	public static String formatPrices(String html){
		Matcher price = Pattern.compile("\\$\\d{3}s",Pattern.CASE_INSENSITIVE).matcher(html);
			while(price.find()){
			U.log(price.group());
			String floorMatch = price.group().replace("s", ",000");  //$1.3 M
			html	 = html.replace(price.group(), floorMatch);
			}//end millionPrice
		return html;
	}
	
	public static String getUnits(String comHtml, String commURL) throws IOException {
		
		String countOfUnits = ALLOW_BLANK;
		String mapSec = ALLOW_BLANK;
		String mapLink = ALLOW_BLANK;
		
		U.log(">>> Inside getUnits method >>> ");
		
		if(commURL.contains("/state/sc/greenville/collier-ridge") ||
				commURL.contains("/sacramento/the-commons-at-the-hideaway")) {
			//pdf format map present - check next time
			comHtml = comHtml.replace("<iframe src=\"//mthcdn.azureedge.net/-/media/assets/greenville-sc", "")
					.replace("<iframe src=\"//mthcdn.azureedge.net/-/media/assets/sacramento-ca/the-hideaway", "");
		}
		
		if(comHtml.contains("- Community map")) {
			
			mapSec = U.getSectionValue(comHtml, "- Community map", "</section>");
			U.log("mapSec: "+mapSec);
		
			if(mapSec != null) {
				
				if(mapSec.contains("<iframe src=\"")) {
					
					mapLink = U.getSectionValue(mapSec, "<iframe src=\"", "\"");
					if(mapLink.contains("&amp;")) {
						mapLink = mapLink.replace("&amp;", "&");
					}
					U.log("mapLink: "+mapLink);
					
					
					if(mapLink != ALLOW_BLANK || mapLink != null) {
					
						String mapData = U.getPageSource(mapLink);
						U.log(U.getCache(mapLink));
						//FileUtil.writeAllText("/home/shatam-10/Desktop/comdata.txt", mapData);
					
						if(mapData != null) {
						
							String comId = U.getSectionValue(mapData, "communityId: ", ",");
							U.log("comId: "+comId);
						
							String linkForCount = "https://salesarchitect.exsquared.com/api/Lotv2/getbybdxcommunityid/?bdxCommunityId="+ comId +"&communityNumber=";
							U.log("linkForCount: "+linkForCount);
						
							String countData = U.getPageSource(linkForCount);
							U.log(U.getCache(linkForCount));
							//FileUtil.writeAllText("/home/shatam-10/Desktop/countdata.txt", countData);
						
							String countNumber = U.getSectionValue(countData, "LotCount>", "<");
							U.log("countNumber: "+countNumber);
						
							if(countNumber == null) countNumber = ALLOW_BLANK;
						
							countOfUnits = countNumber;
						}
					
				}
			}
		}
	}
		
		
		return countOfUnits;
		
	}

}