package com.shatam.b_001_020;

import java.util.HashSet;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.phantomjs.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMultifamilyLennar extends AbstractScrapper {
	// HashSet<String>commUrl=new HashSet<String>();
	WebDriver driver = new FirefoxDriver();
	CommunityLogger LOGGER;
	static int j = 0;

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractMultifamilyLennar();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Lennar Homes - Lennar Multifamily Communities.csv", a.data().printAll());
	}

	public ExtractMultifamilyLennar() throws Exception {
		super("Lennar Homes - Lennar Multifamily Communities", "http://livelmc.com/");
		LOGGER = new CommunityLogger("Lennar Homes");
	}

	@Override//Use proxy
	public void innerProcess() throws Exception {
		String html = U.getHtml("http://livelmc.com/",driver);
		// driver.quit();
		// U.log(html);
		String[] regs = U.getValues(html,
						" <li><a data-abbrev=",
						"</li>");
		U.log(regs.length);
		for(String reg : regs)
		{
			U.log("reg url :::::::::::"+U.getSectionValue(reg, "href=\"", "\""));
			String regHtml = U.getHtml(U.getSectionValue(reg, "href=\"", "\""),driver);
			String[] commSecs = U.getValues(regHtml, "<div class=\"img-container\">", "</li>") ;
			for(String commSec:commSecs ){
				
			U.log("comurl:::::::::::::::::::::::"+U.getSectionValue(commSec, "_property_site\" href=\"", "\""));
			addDetails(commSec);
			}
			}
		driver.close();
	}
	
	private void addDetails(String commSec) throws Exception {
		
		//if(j==15)
		{
		//U.log(commSec);
			
		String commUrl =  U.getSectionValue(commSec, "_property_site\" href=\"", "\"");
		U.log(commUrl);
		
		//if(!commUrl.contains("http://www.livewhittaker.com/"))return;
		
		if(commUrl==null)
			commUrl=ALLOW_BLANK;
		if(commUrl.trim().length()<4)return;
		
		if(commUrl.contains("http://LiveNexa.com/"))return;
		if(commUrl.contains("http://liveLMC.com/"))return;
		if(commUrl.contains("http://livelmc.com/"))return;
		if(commUrl.contains("http://www.livenordhaus.com/"))return;
		if(commUrl.contains("http://www.livemorris.com/"))return;
		if(commUrl.contains("http://MusePhoenix.com/"))return;
		if(commUrl.contains("http://www.LiveTheEmerson.com/"))return;
		if(commUrl.contains("http://LIVEBEACON85.COM/"))return;
		
		
		String CommName = U.getSectionValue(commSec, "<h3><b>", "<");
		CommName=U.getCapitalise(CommName.toLowerCase());
		
		
		
				
		String commHtml = U.getHtml(commUrl, driver);
		
		String amenHtml = ALLOW_BLANK, featureHtml = ALLOW_BLANK;
		if(commHtml.contains("amenities/\">Amenities") || commHtml.contains("amenities/\">AMENITIES") )
		{
			U.log("Amen Url ::::::: " + commUrl+"/amenities");
			amenHtml = U.getHTML(commUrl+"/amenities");
		}
		if(commHtml.contains("features/\">Features"))
		{
			U.log("feature Url ::::::: " + commUrl+"/features");
			featureHtml = U.getHTML(commUrl+"/features");
		}
			
		commHtml=commHtml.replaceAll("North Tower Now Open|COMING SOON! Enjoy the conveniences|Multifamily|multifamily|obligated | Leasing is Now Available","");
		String propType = U.getPropType(commHtml+amenHtml+featureHtml+"apartment");
		String dType = U.getdCommType(commHtml.replaceAll("Valley Ranch Blvd| RANCH BLVD", ""));
		String commType = U.getCommType(commHtml);
		String lat = ALLOW_BLANK;
		String lon = ALLOW_BLANK;
		String geocode = ALLOW_BLANK;
		String geo = ALLOW_BLANK;
		String status = U.getPropStatus(commHtml+commSec);
		String note = ALLOW_BLANK;
		String minsqft = ALLOW_BLANK, maxsqft = ALLOW_BLANK;
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		if(commUrl.contains("crestatmillenia"))
		{
		add[0]="5100 Millenia Waters Drive";add[1]="Orlando"; add[2]="FL"; add[3]="32839";
		lat="28.4862813";
		lon="-81.4287642";
		geocode="FALSE";
		
		}
		String[] sqft={ALLOW_BLANK,ALLOW_BLANK};
		
		if(commUrl.contains("malbecatvallagio")){
			commType="Resort Style,Gated Community";
		}
		if(commUrl.contains("ariaatmillenia")){
			commType="Resort Style";
			sqft[0]="709";
			sqft[1]="1279";
		}
		if(commUrl.contains("onyxedina")){
			commType="Resort Style";
			sqft[0]="549";
			sqft[1]="1550";
		}
		if(commUrl.contains("maldenstation")){
			add[0]="250 W. Santa Fe Avenue";// 205 S Kings Dr, Charlotte, NC 28204
			geocode="False";
		}
		if(commUrl.contains("thebrookonjanes"))
		{
			sqft[0]="502";
			sqft[1]="1355";
		}
		if(commUrl.contains("westandfondren"))
		{
			sqft[0]="592";
			sqft[1]="1639";
		}
		if(commUrl.contains("octavenashville"))
		{
			sqft[0]="541";
			sqft[1]="1149";
		}
		if(commUrl.contains("malbecatvallagio"))
		{
			sqft[0]="835";
			sqft[1]="1375";
		}
		if(commUrl.contains("bocacitywalk"))
		{
			sqft[0]="640";
			sqft[1]="1346";
		}
		if(commUrl.contains("http://www.livewhittaker.com/"))
		{
			sqft[0]="527";
			sqft[1]="1202";
		}
		if(commUrl.contains("http://www.rentatlasapts.com/"))
		{
			sqft[0]="552";
			sqft[1]="1917";
		}
		if(commUrl.contains("http://www.roswellcitywalk.com/"))
		{
			lat="34.0260785";lon="-84.3586291";
			String[] lat1={lat,lon};
			add=U.getAddressGoogleApi(lat1);
			geocode="TRUE";
		}
		if(commUrl.contains("skywaterapartment")){
			sqft[0]="632";
			sqft[1]="1774";
		}
		if(commUrl.contains("liveparkhouse")){
			commType="Resort Style";
			propType=propType+",Patio Homes";
			sqft[0]="655";
			sqft[1]="1081";
		}
		if(commUrl.contains("livetera")){
			sqft[0]="658";
			sqft[1]="1264";
		}
		if(commUrl.contains("crestatmillenia")){
			sqft[0]="709";
			sqft[1]="1279";
		}
		if(commUrl.contains(".roswellcitywalk")){
			sqft[0]="687";
			sqft[1]="1353";
		}
		if(commUrl.contains("tapestrynaperville")){
			sqft[0]="674";
			sqft[1]="1360";
		}
		if(commUrl.contains("tapestryglenview")){
			sqft[0]="599";
			sqft[1]="1212";
		}
		
		if(commUrl.contains("tapestrylargostation")){
			sqft[0]="752";
			sqft[1]="1511";
		}
		if(commUrl.contains("midtown205")){
			propType="Apartment Homes";
		}
		if(commUrl.contains("crestatpearl")){
			sqft[0]="-";
			sqft[1]="-";
		}
		if(commUrl.contains("crestatparkcentral")){
			sqft[0]="675";
			sqft[1]="1500";
			propType="Luxury Homes, Courtyard Home";
			
		}
		if(commUrl.contains("crestatglencoe")){
			sqft[0]="597";
			sqft[1]="1233";
			propType="Luxury Homes, Apartment Homes";
		}
		if(commUrl.contains("crestlascolina")){
			sqft[0]="600";
			sqft[1]="1431";
			propType="Courtyard Home";
		}
		if(commUrl.contains("indigobcs"))
		{
			sqft[0]="480";
			sqft[1]="1420";
			propType="Luxury Homes, Courtyard Home, Apartment Homes";
			
		}
		if(commUrl.contains("crestatoakpark"))
		{
			sqft[0]="569";
			sqft[1]="1080";
		}
		if(commUrl.contains("colonyatthelakes")){
			propType=propType+",Courtyard Home";
			sqft[0]="675";
			sqft[1]="1049";
		}
		if(commUrl.contains("http://www.parkerberkeley.com/")){
			propType=propType+",Courtyard Home";
			sqft[0]="683";
			sqft[1]="1218";
		}
		
		if(commUrl.contains("maldenstation")){
			sqft[0]="467";
			sqft[1]="1245";
		}
		
		if(commUrl.contains("livemarston")){
			sqft[0]="548";
			sqft[1]="1406";
		}
		
		if(commUrl.contains("leasefrontera")){
			sqft[0]="1210";
			sqft[1]="2182";
		}
		if(commUrl.contains("crestlascolinas")){
			propType="Apartment Homes,Luxury Homes";
		}
		if(commUrl.contains("thehighlandapts")){
			propType=propType+",Luxury Homes";
			sqft[0]="499";
			sqft[1]="1722";
		}
		
		if(this.data.communityUrlExists(commUrl))return;
		if(add[0].length()<4||add[1].length()<4)
		{
			String aaaa=U.getHardcodedAddress1("Hardcoded Lennar Homes - Lennar Multifamily Communities", commUrl);
		    U.log("------->"+aaaa);
		    if(aaaa!=null){
		    	aaaa=aaaa.replace(", Suite", " Suite");
		    String[] aaa=aaaa.split(",");
		    add[0]=aaa[0];
		    add[1]=aaa[1];
		    add[2]=aaa[2];
		    add[3] = aaa[3];
		     geocode=aaa[6];
		     lat = aaa[4];
		     lon = aaa[5];
		     if(lat!=null)
		    	 //add=U.getAddressGoogleApi(latlng);
		     if(geocode.contains("TRUE"))
		     {
		    	 String[] latln = U.getlatlongGoogleApi(add);
		    	 lat = latln[0];
		    	 lon = latln[1];
		     }
		}
		}
		
		add[1] = U.getCapitalise(add[1].toLowerCase());
		add[0] = U.getCapitalise(add[0].toLowerCase());
		
		data.addCommunity(CommName, commUrl, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPrice(ALLOW_BLANK, ALLOW_BLANK);
		data.addLatitudeLongitude(lat.trim(), lon.trim(), geocode);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(commHtml));
	}j++;
		
		
	}
		
	
}