/** @author Sanket Patil
 * 
 *  @date 27/3/2012 
 *  Modification Aditya..
 */

package com.shatam.b_001_020;

import java.io.File;
import java.sql.Connection;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.bcel.generic.LLOAD;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

import sqliteTest.testSqlite;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractQuadrantHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	WebDriver driver = null;
	int i = 0;
	static int dup=0;
	CommunityLogger LOGGER;
	//Connection con;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractQuadrantHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/TRI Pointe Group - Quadrant Homes.csv",
				a.data().printAll());
	}

	public ExtractQuadrantHomes() throws Exception {

		super("TRI Pointe Group - Quadrant Homes",
				"https://www.quadranthomes.com");
		LOGGER = new CommunityLogger("TRI Pointe Group - Quadrant Homes");
	}

	public void innerProcess() throws Exception {
		//System.setProperty("phantomjs.binary.path", System.getProperty("user.home")+File.separator+"phantomjs");		
		U.setUpGeckoPath();
		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		//new code -Dec2016
		String html = U.getHtml("https://www.quadranthomes.com/find-your-home",driver);

		
		String sec=U.getSectionValue(html, "<ul class=\"listing\">", "</ul>");
		//U.log("sec:"+sec);
		
		String[] comSections=U.getValues(sec, "<div class=\"pricingDetail\">", "</li>");
		U.log(comSections.length);
		
		for(String comSec:comSections){
			String url =U.getSectionValue(comSec, "<h1><a class=\"priceImg\" href=\"", "\"");
			String name= U.getSectionValue(comSec, "title=\"Explore ", "\">");
			//U.log("name:"+name);
			//U.log("url:"+url);
			//U.log(comSec);
			addDetails(name,url,comSec,html);
		}
		
		
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addDetails(String name, String url, String comSec,String regHtml) throws Exception {
		
	//if(j==5)
		{
		//if (!url.contains("https://www.quadranthomes.com/washington/grove-north/"))return;
		//U.log(comSec);
		String comUrl;
			String comName=name;
			
			 comUrl=url;
			 String comHtml=U.getHtml(comUrl, driver);
			//U.log(j+"::comUrl:"+comUrl);
			//U.log(U.getCache(comUrl));
			
			//---Address latlng and geocode---
			String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
			String latLng[]={ALLOW_BLANK,ALLOW_BLANK};
			String geo="True";
			String mapHtml=ALLOW_BLANK;
			
			/*if(comHtml.contains("Maps &amp; Directions</a></li>")){
				String mapUrl=comUrl+"map-direction/";
				mapHtml=U.getHTML(mapUrl);
			}*/
			
			String addSec=U.getSectionValue(comHtml,"<li class=\"address\">", "<br>");
			if(comUrl.contains("https://www.quadranthomes.com/washington/inglewood-landing/")){
				addSec=U.getSectionValue(comHtml, "<strong>Inglewood Landing</strong><br>", "<br>");
			}
			//U.log("addSec::"+addSec);
			if(addSec!=null){
				addSec = addSec.replaceAll("<p>|<br /></p>", "");
				
				addSec = addSec.replace("<br> ", ",");
				//U.log(addSec);
				String[] ad=addSec.split(",");
				U.log("Adress:"+Arrays.toString(ad));
				ad[2]=ad[2].replace("<br>", "");
				add[0]=ad[0].trim();
				add[1]=ad[1].trim();
				add[2]=Util.match(ad[2].trim(), "\\w+");
				add[3]=Util.match(ad[2].trim(), "\\d+");
				U.log("Adress:"+Arrays.toString(add));
			}
			
			String latlngSec=U.getSectionValue(mapHtml, "google.maps.LatLng( ", ")");
			//U.log("latlngSec::"+latlngSec);
			
			if(latlngSec!=null){
				latLng=latlngSec.split(" , ");
				U.log("latlng:"+Arrays.toString(latLng));
			}
			if(comUrl.contains("https://www.quadranthomes.com/washington/copperwood/")){
				latlngSec=U.getSectionValue(comHtml, "/@", ",17z/");
				//U.log(latlngSec);
				latLng=latlngSec.split(",");
				U.log("latlng:"+Arrays.toString(latLng));
			}
			if(add[0]!=null&& latLng[0]!=null){
				geo="FALSE";
			}
			if(addSec==null){
				addSec=U.getSectionValue(comHtml, "<h4>Model Home</h4>", "</div>");
				if(addSec!=null){
					addSec = addSec.replaceAll("<p>|<br /></p>", "");
					
					addSec = addSec.replaceAll("<br> |<br /> ", ",");
					//U.log(addSec);
					String[] ad=addSec.split(",");
					U.log("Adress:"+Arrays.toString(ad));
					ad[2]=ad[2].replace("<br>", "");
					add[0]=ad[0].trim();
					add[1]=ad[1].trim();
					add[2]=Util.match(ad[2].trim(), "\\w+");
					add[3]=Util.match(ad[2].trim(), "\\d+");
					U.log("Adress:"+Arrays.toString(add));
					
					latlngSec=U.getSectionValue(comHtml, "/@"	, ",13z/");
					U.log(latlngSec);
					if(latlngSec!=null){
						latLng=latlngSec.split(",");
						U.log("latlng:"+Arrays.toString(latLng));
					}
					
					}
			}
			if(add[0].isEmpty() ||add[3] == null){
				if(latLng[0] != ALLOW_BLANK  && latLng[1] != ALLOW_BLANK){
					add = U.getAddressGoogleApi(latLng);
					geo = "True";
				}
			}
			//
			String planHtml=ALLOW_BLANK;
			String quickHtml=ALLOW_BLANK;
			String InquickHtml=ALLOW_BLANK;
			String z=ALLOW_BLANK;
			if(comHtml.contains("Plans &amp; Pricing</a></li>")){
				String planUrl=comUrl+"floorplans/";
				planHtml=U.getHTML(planUrl);
			}
			String qhomeHtml="";
			if(comHtml.contains("Quick Move-In Homes</a></li><li><a href=\"")){
				String quickUrl=comUrl+"quick-move-ins";
				U.log("ZZZZZZZZZZZ"+quickUrl);
				quickHtml=U.getHTML(quickUrl);
				//U.log(quickHtml);
				InquickHtml=U.getSectionValue(quickHtml,"<div class=\"plan-blocks\"><div class=\"plan-pricing qmi_list\"><ul>","<div class=\"rightSection\" id=\"rightsidebar\">");
				String[]a=U.getValues(InquickHtml, "href=\"","\"");
				for(String bb:a)
				{
					z=U.getHTML(bb);
					qhomeHtml=qhomeHtml+U.getSectionValue(z,"<div class=\"wrapper\">", "<div class=\"floorPlan_new row\">");
				}
			}
			String neighHtml=ALLOW_BLANK;
			if(comHtml.contains("Neighborhood Living</a></li><li>")){
				String neighUrl=comUrl+"neighborhood-living/";
				neighHtml=U.getHTML(neighUrl);
			}
			//================= Remove Meta tag ===================
			Matcher mat = Pattern.compile("<meta(.*?)/>",Pattern.CASE_INSENSITIVE).matcher(comHtml);
			while(mat.find()){
				comHtml = comHtml.replace(mat.group(), "");
			}

			
			
			//String drop =U.getSectionValue(comHtml, "", "");
			comHtml=comHtml.replaceAll("content=\"Coming in 2017|</span> <span class=\"price-case\">|pagerAnchorBuilder|Coming Soon to Bothell", "");
			neighHtml = neighHtml.replaceAll("Assumptions. You are purchasing a single family", "");
			comHtml = comHtml.replaceAll("Luxurious 5 piece|Assumptions. You are purchasing a single family", "");
			comHtml = comHtml.replace("NEW PHASE, NEW PLANS COMING SOON", "NEW PHASE COMING SOON");
			comHtml=comHtml.replaceAll("if \\(status == 'Coming Soon'|else if\\(status == 'Now Selling'\\)|\\d{3},\\d{3}m/data", "");
			comHtml=comHtml.replace("COMING SOON – SPRING 2018", "Coming Soon Spring 2018");
			comHtml=comHtml.replace("00s", "00,000").replace("Coming Soon in Early 2019", "Coming Soon Early 2019");
			comHtml=comHtml.replace("$1.3", "$1,300,000");
			comHtml = comHtml.replace("$1.1", "$1,100,000").replace("$1.2 Millions", "$1,200,000");
			U.log(Util.matchAll(comHtml+comSec+planHtml+quickHtml+qhomeHtml, "[\\w\\s\\W]{20}\\d{3},\\d{3}[\\w\\s\\W]{20}",0));
			//U.log("Here::" +U.getSectionValue(comHtml, "Anticipated pricing from ", "</span>"));
			//---Prices---
			comHtml=comHtml.replace("$1 Millions","$1,000,000").replace("$1.4 Millions", "$1,000,000").replace("$1.8 Millions", "$1,800,000");
			comHtml = comHtml.replace("800s. For more info", "");
			
			String minPrice=ALLOW_BLANK, maxPrice=ALLOW_BLANK;
			String[] prices=U.getPrices(comHtml+planHtml+quickHtml+comSec+qhomeHtml,"\\d{3},\\d{3}|the \\$\\d{1},\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|the low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{1},\\d+,\\d+", 0); 
			
			minPrice=(prices[0]==null)? ALLOW_BLANK : prices[0];
			maxPrice=(prices[1]==null)? ALLOW_BLANK : prices[1];
			
			U.log("minprice:"+minPrice);
			U.log("maxprice:"+maxPrice);
			
			//----Square feet
			
			
			String minSqFt=ALLOW_BLANK, maxSqFt=ALLOW_BLANK;
			String[] squarefeet=U.getSqareFeet(comHtml+planHtml+quickHtml,"\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3} – \\d{1},\\d{3} sq ft|\\d{1},\\d{3} to \\d{1},\\d{3} sf|\\d{1},\\d{3} sq. ft|size from \\d{1},\\d{3} to \\d{1},\\d{3},",0); 
			
			minSqFt=(squarefeet[0]==null) ? ALLOW_BLANK : squarefeet[0];
			maxSqFt=(squarefeet[1]==null) ? ALLOW_BLANK : squarefeet[1];
			
			U.log("minSqFt:"+minSqFt);
			U.log("maxSqFt:"+maxSqFt);
			
			
			String comType=ALLOW_BLANK, propType=ALLOW_BLANK,dType=ALLOW_BLANK,status=ALLOW_BLANK;
			//----comType---
			comType=U.getCommunityType(comHtml.replace("Golf Complex", "")+neighHtml);
			
			
			//---PropType---
			String rem=U.getSectionValue(comHtml, "<h2>News & Trends </h2>", "<div class=\"clear\">");
			if(rem!=null) {
				comHtml=comHtml.replace(rem, "");
				qhomeHtml=qhomeHtml.replace(rem, "");
				neighHtml=neighHtml.replace(rem, "");
				
			}
			qhomeHtml=qhomeHtml.replace("den &amp; loft", "den & loft");
			propType=U.getPropType((comHtml+neighHtml+qhomeHtml).replaceAll("as parks, stylish townhomes|Small town| the town|homeowner|homeowners|Homeowners",""));
			propType=propType.replaceAll("Townhomes,Townhouse", "Townhomes");
			//---dType----
			comHtml=comHtml.replace("first and second floors"," 1 Story 2 Story ");
			dType=U.getdCommType(comHtml+quickHtml+neighHtml+qhomeHtml);
			//U.log(comHtml);
			//---status---
			String lable_stat=ALLOW_BLANK;
			if(comUrl.contains("https://www.quadranthomes.com/washington/overlook/"))
			{
				lable_stat=U.getSectionValue(comHtml, "label_status\">", "</span>");
			}
			comHtml=comHtml.replace("var status = 'Final Homes Now Selling';", "").replaceAll("Final Quick Move-in Homes Now Selling|plan-status-floor\">Now Selling|close-out-savings\">|11/CLOSEOUT|content=\"Now Selling:|NOW SELLING PRESALE|NOW SELLING DESIGNER HOMES|Model Opening Early 2017|Now Selling in Bellevue|Now Selling Bellevue","").replace("Now Selling')","")
					.replaceAll("label_status\">\\s+Now", "");
			comHtml=comHtml.replace("Coming Soon in Spring 2019", "Coming Soon Spring 2019");
			U.log(Util.match(comHtml, ".*?Coming Soon Early 2019.*?"));
			status=U.getPropStatus((lable_stat+comHtml+comSec.replace("<!--span class=\"plan-status\">Final Homes Now Selling</span><br-->", "")).replaceAll("COMING SOON - FALL 2018", "COMING SOON FALL 2018").replace("Coming soon:","").replace("Coming Soon')","").replaceAll("status-floor\">Now Selling|Coming Soon\\s*</span>",""));
			String notes=ALLOW_BLANK;
			notes=U.getnote(comHtml);
			
			
			
			if(url.contains("https://www.quadranthomes.com/washington/viscaia/")){
				status=status.replace(",Opening Spring 2017","");
				}
			
		
			U.log("latlngSec::"+latlngSec);
			U.log(comName+":::::::::");
			if(latlngSec==null){
				String tempName="\""+comName+"\"";
				String regSec=U.getSectionValue(regHtml, "var markers1 = [[\"", "]];");
				
				U.log("regSec:::::"+regSec);
				String temp=comName.trim()+"\", ";
				
				String regLL=U.getSectionValue(regSec, temp, "\"");
				U.log("regLL:::::::::::"+regLL);
				if(regLL!=null){
					latLng=regLL.split(",");
					latLng[1]=latLng[1].trim();
					U.log("Lat lng is"+Arrays.toString(latLng));
				}
			}
			
			LOGGER.AddCommunityUrl(comUrl);
			
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+"repeated");
				dup++;
			}
			if(latLng[0].length()<4){
				latLng=U.getlatlongGoogleApi(add);
				//geo="TRUE";
			}
			status=status.replace("Coming Soon Fall 2018, Coming Soon", "Coming Soon Fall 2018");
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(status);
			data.addNotes(notes);
		}j++;
		
		
	}
	
}
	