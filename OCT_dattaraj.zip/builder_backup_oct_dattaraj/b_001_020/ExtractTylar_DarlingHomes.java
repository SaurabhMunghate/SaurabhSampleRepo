/* Modification Aditya..
 * Date 09-07-2015
Auther Ashish Shivhare
 * 
 * Date 9/4/12
 */

package com.shatam.b_001_020;

import java.io.*;
import java.net.URL;
import java.sql.Connection;
import java.text.NumberFormat;
import java.util.Arrays;

import org.apache.regexp.recompile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import sqliteTest.testSqlite;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

import mx4j.util.Utils;

public class ExtractTylar_DarlingHomes extends AbstractScrapper {
	int k = 0;
	static int duplicates = 0;
	public int inr = 0;
	private static String BUILDER_NAME = "Taylor Morrison - Darling Homes";
	private static String BASE_URL = "https://www.darlinghomes.com/";
	CommunityLogger LOGGER;
int index = 0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractTylar_DarlingHomes();
		a.process();
		
		FileUtil.writeAllText(U.getCachePath()+"csv/Taylor Morrison - Darling Homes.csv", a
				.data().printAll());
	}

	public ExtractTylar_DarlingHomes() throws Exception {

		super(BUILDER_NAME, BASE_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public void innerProcess() throws Exception {
		 System.setProperty("phantomjs.binary.path", System.getProperty("user.home")+File.separator+"phantomjs");		
         WebDriver driver = new PhantomJSDriver();	
		
		String url = BASE_URL;
		String html = U.getHTML(url);
		String urlSec=U.getSectionValue(html, "<ul class=\"ddlist", "class=\"mod-t1\">");
	
		String citval[] = null;
		
			citval = U.getValues(urlSec, "<a href=\"", "\"");
			int temp = citval.length / 2;
			
			int i = 0;
			for (String itom : citval) 
			{
				//if(i == 1){
				U.log(" city Url :" + itom);

				findCommunity(itom, driver);
				//}
				i++;
			}
		
		driver.quit();
		
	}
	private void findCommunity(String regionUrl,WebDriver driver) throws Exception {	
	
		
		String html = U.getHtml(regionUrl, driver);
		String LinkSec[] = U.getValues(html, "<div class=\"commImg\">","<div class=\"hfslist\">");
		int i = 0;
		U.log("section : " + LinkSec.length);
		for(String section : LinkSec){
			//if(i > 20){
			String communityUrl = U.getSectionValue(section, "<a href=\"", "\"");
			communityDetails(communityUrl, section, driver);
			//U.log(i+":::::::::::::communityUrl:::::::"+communityUrl);
			//}
			i++;
		}
		U.log(i);	
	}
	private void communityDetails(String communityUrl, String section, WebDriver driver) throws Exception{
	//if(!communityUrl.contains("https://www.darlinghomes.com/new-homes/texas/dallas/frisco/chapel-creek-community"))return;
		//if(index==57)
		{
		//if(communityUrl.contains("mckinney/tucker-hill-"))return;	//redirect
		section = section.replace("Priced from the 490s", "Priced from the $490s");
		section = section.replace("3,337 to 4,389", "3,337 to 4,389 Sq. Ft.");
		section = section.replace("3,093 to 4,197", "3,093 to 4,197 Sq. Ft.");
		section = section.replace("2,731 to 3,971", "2,731 to 3,971 Sq. Ft.");
		//U.log(section);
		U.log("----="+index);
		U.log(U.getCache(communityUrl));
		
		String html = U.getHTML(communityUrl);
		
		String propStatus=U.getSectionValue(section, "<div class=\"comstsflag\">", "</div>");//<div class="comstsflag">
		
		U.log("Statussssssssssss:"+propStatus);
		System.out.println("#########3");
		if (propStatus!=null) {
			propStatus=propStatus.replace("closeout_flag.png", " Close Out ");
			System.out.println("hurry up::::"+propStatus);
			
			propStatus=propStatus.replace("comingsoon_flag.png", "Coming Soon");
			propStatus=propStatus.replace("New Pricing", "");
			propStatus=propStatus+"";
			
			
		}
		U.log(propStatus);
		if(html==null)return;
		html =html.replace("to over", "to");
		
		String headSection = U.getSectionValue(html, "<meta name", "</head>");
		if(headSection != null)
			
		html = html.replace(headSection, "");
		/*String homeUrl = U.getSectionValue(html, "\" action=\"","\" method");
		String moveLink = U.getHtml(BASE_URL + homeUrl, driver);*/
	
		//***********Fetching all floor plan Data************
		String floorMainHtml = ALLOW_BLANK,allFloorData=ALLOW_BLANK;
		
		String floorMainUrl = U.getSectionValue(html, "<li id=\"content_0_ctl01_secnav_0_liFloorPlans\" class=\"cdm\"><a href=\"", "\"");
		
		U.log("floorUrl::::::"+"https://www.darlinghomes.com"+ floorMainUrl);
		
		if(floorMainUrl!=null){
			floorMainHtml = U.getHtml("https://www.darlinghomes.com"+ floorMainUrl, driver);
			
			//All floorPlan Data
			String[] floorUrls = U.getValues(floorMainHtml, "<a data-bind=\"attr:{href: url}\" class=\"CDti\" href=\"", "\"");
			U.log("total floor Plan :: "+floorUrls.length);
			
			for(String flrUrl : floorUrls){
				U.log("::::::::::::"+"https://www.darlinghomes.com/"+flrUrl);
				
				String fHtml = U.getHTML("https://www.darlinghomes.com/"+flrUrl);
				allFloorData = U.getSectionValue(fHtml, "<div class=\"plan-middle1\">", "</div>")+allFloorData;
				//U.log(allFloorData);
				
				if(allFloorData.contains("patio") || allFloorData.contains("Patio") ){
					U.log("**************found patio**********");
					break;
				}
			}
		}
		String featureHtml=U.getHTML(communityUrl + "/home-features");
		
		//******Homes Ready Now(homes for sale) Page Data
		String homeReadyUrl ="", readyHtml=ALLOW_BLANK, readyHome="";
		if(html.contains(">HOMES FOR SALE<"))
		{
		homeReadyUrl=communityUrl+"/homes-ready-now";
		readyHtml=U.getHTML(homeReadyUrl);
		  if(readyHtml.contains("Homes Ready Now"))
		  {
			 readyHome = "Homes Ready Now";
		  }
		}
		String allReadyHomeData = ALLOW_BLANK;
		if(readyHtml != ALLOW_BLANK )
		{
			String readySec = U.getSectionValue(readyHtml, "var initialData = [", "]");
			if(readySec != null){
				String [] allReadyHomesUrl = U.getValues(readySec, ",url: '", "',purl: '"); 
				U.log("Total ready home : "+allReadyHomesUrl.length);
				for(String eachReadyHomeUrl : allReadyHomesUrl){
					U.log("eachReadyHomeUrl : \t"+"https://www.darlinghomes.com"+eachReadyHomeUrl);
					String RDHHtml = U.getHTML("https://www.darlinghomes.com"+eachReadyHomeUrl);
					allReadyHomeData += U.getSectionValue(RDHHtml, "<div class=\"plan-middle1\">", "</div>");
				}
			}
		}

		String communityName = U.getSectionValue(html,"<h1>About", "</h1>").replace("|", "");
		U.log("============================" + communityName);

		String addSec = Util.match(section, "q=.*?\">(.*?)</a>", 1);

		addSec = addSec.replaceAll(", Texas|TX <br />", "");
		addSec = addSec.replaceAll("<br>|<br />| <br />", ",");
		addSec = addSec.replaceAll("By Appointment Only|Model Home Closed|Model Coming Soon|Offsite Model - Last Chance|Grand Central Park Coming Soon|Model Home Now Open| Offsite Model|Model Home Now Open|Model Home Now Closed", "");
		U.log("addsec-------" + addSec);
		String[] add = addSec.split(",");
		
		
		String street = add[0];
		String city = add[1];
		String state = add[2].replaceAll("\\d+", "");
		String zip = Util.match(add[2], "\\d{5}");
		
		street = street.replaceAll("Model Closed\\s*Appointment Only$|Call for Appointment|Appointments Only|Model Closed - Call for Appt.|Model Address TBD|Model Address TBD ", ALLOW_BLANK);
		
			
		if (street.equals("Model Offsite")) {
			street=ALLOW_BLANK;
		}
		//U.log("Street :"+street+":::");
		U.log("City :"+city);
		U.log("State :"+state);
		U.log("zip :"+zip);
		
		String geo="FALSE";
		if (street.length() <4)
			street = ALLOW_BLANK;

		if(street==ALLOW_BLANK){
			
		}
		String itempriceSec = U.getSectionValue(section,
				"<span class=\"priceFrom\">", "</span>");
		itempriceSec = itempriceSec.replace("0s", "0,000").replace("0's", "0,000");
	

		String priceHtml = floorMainHtml;
		 readyHtml=readyHtml.replace("price: ", "price: $");

		String prices[] = U.getPrices(html + itempriceSec 
				+ priceHtml + readyHtml,
				"\\$\\d+,\\d+,\\d+|\\$\\d+,\\d+|\\$\\d+", 0);
		
		
		if(communityName.contains("Canals At Grand Park 40s")){
			String removeSection=U.getSectionValue(html, "and the 55s", "square feet.");
			html=html.replace(removeSection, "");
		}
//		U.log("item:: "+html);
		

		String sqft[] = U.getSqareFeet(html+priceHtml + section +readyHtml,
						"sqft\">\\d,\\d{3}</span> Sq. Ft.|around \\d{4} to \\d{4} square feet|\\d{4} to \\d{4} square feet|\\d,\\d+ - \\d,\\d+ square foot|\\d+,\\d+-\\d+,\\d+ sq ft,|mid \\d+,\\d+ square feet|\\d+,\\d+-\\d+,\\d+ sq. ft.|\\d+,\\d+-\\d+,\\d+ square feet|\\d+,\\d+ and \\d+,\\d+ square feet.|\\d+,\\d+ to more than \\d+,\\d+ square feet|\\d+,\\d+ square feet to \\d+,\\d+|\\d+,\\d+ to \\d+,\\d+ square foot|\\d+,\\d+ to over \\d+,\\d+ square feet|from approximately \\d,\\d{3} to \\d,\\d{3}|sqft: \\d+|\\d,\\d+ Sq. Ft.|\\d+,\\d+-\\d+,\\d+ square feet|\\d+,\\d+ to around \\d+,\\d+ square |\\d+ to \\d+ square feet|\\d+,\\d+ to \\d+,\\d+ Sq.| sqft\">\\d+,\\d+|\\d+,\\d+ to \\d+ square feet|\\d+,\\d+[.*?]\\d+,\\d+ square feet|\\d,\\d+ - \\d+ square feet|\\d,\\d+-\\d,\\d+ Square|\\d,\\d{3} square feet",
						0);
	
		html = html.replace("Savor the luxuries of peaceful", "Savor the luxurious homes of peaceful").replaceAll("Lewisville|Lakeside DFW Villas|_villa_community|Multi Family|Multi-Family Dwellings|Multi Family Homes|family rooms|Family Homes|multiplebgs", "");
		//String remo=U.getSectionValue(comHtml,"<div class=\"rt-col\">","<script type=\"text/javascript\">");
		html = html.replace("Golf Course Patio New Homes Lantana", "golf course patio new homes lantana");
		html = html.replaceAll("golf course patio new homes lantana|-55-patio-subdivision.jpg|55 patio community/images", "");
		html = html.replace("traditional architectural", "Traditional homes");
		html=html.replaceAll("Amenity Center Patio|D Courtyard Entrance|d_courtyard.jpg|to Patio|family_patio|_patio|55-patio-subdivision|patio community/images|luxuries of peaceful|\"Patio and Backyard\"","");
		String proType=null;
		if (communityUrl.contains("http://www.darlinghomes.com/new-homes/texas/houston/cypress/cypress-creek-lakes-community")) {
			proType=U.getHTML("http://www.darlinghomes.com/new-homes/texas/houston/cypress/cypress-creek-lakes-community/7225/home-available-now-at-20722-connor-run-77433");
			proType=U.getSectionValue(proType, "<div class=\"plan-middle1\">", "</p>");
		}
		
		html=html.replace("55+ and looking to live", "seniors 55 and over");
		String Type = U.getPropType(html+featureHtml+allFloorData+proType+allReadyHomeData);
		Type = Type.replace("Condominium", "");

		String status = ALLOW_BLANK;
		html = html.replaceAll("eligible move-in ready home|New community Kroger now open|new homes available in Frisco|amenity center coming soon|fire pit coming soon|Coming Soon we will be proudly|grand opening expected in 2018|move-in ready homes|Move-in Ready Homes|Move-In Ready Homes|Coming this fall, Cypress|\" title=\"Close Out \"|alt=\"Close Out \" title=\"Close Out|close out snipe|Model Now Open", "");
		html = html.replace("Now Selling in Phase 2", "Now Selling Phase 2");
		html = html.replace("Last Opportunities", "Last Opportunity");
		html=html.replace("as well as water view lots available. ", " ");
		html=html.replace("on 60� lots with depths from 120", "");
		html=html.replace("Plans 5606 and 5634 now available!", "");
		html=html.replace("Villa residences are coming soon to McKinn", "");
		html=html.replaceAll("Phase 4 is coming soon", "Phase 4 coming soon");
		html = html.replace("homes sites now available", "home sites now available");
	
		//html=html.replaceAll("New Pricing", "");
		status = U.getPropStatus((propStatus+html+readyHome).replaceAll("Now Open\" |collection of patio home sites is NOW AVAILABLE|Last Opportunities for Darling Homes in Harmony ", ""));

		if (status.length() == 0)status = ALLOW_BLANK;
		
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;

		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		street = street.toLowerCase().replace(
				"temporary onsite sales trailer", "");

		if (zip == null)
			zip = ALLOW_BLANK;

		if (zip.equals("00000"))
			zip = ALLOW_BLANK;
		if (street.length() < 3)
			street = ALLOW_BLANK;
		
		String driverUrl = U.getSectionValue(html, "DrivingDirections&#39;);\" href=\"", "\"");
		if(driverUrl == null){
			driverUrl = Util.match(html, " <ul class=\"comInfo\">\\s*<li><a href=\"(.*?)\" onclick=\"TM.Common.GAlogevent\\('Details', 'Click', 'CommunityLinks-Driving",1);
		}

		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		
		String latlng[] = U.getSectionValue(section, "q=", "\"").split(",");
		
		
		if(Util.match(latlng[0],"[A-Za-z]+")==null){
			lat = latlng[0];
			lng = latlng[1];
		}
		U.log("lat:"+lat+" lng:"+lng);

		String adds[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
		if (driverUrl != null){
			String drivingHtml = U.getHTML(BASE_URL + driverUrl);
			
			if (drivingHtml != null){
				String latLng = U.getSectionValue(drivingHtml,"new google.maps.LatLng(", ")");
				U.log(latLng+"latLng");
				if (latLng != null)
					latlng = latLng.split(",");
				if(Util.match(latlng[0],"[A-Za-z]+")==null){
					lat = latlng[0];
					lng = latlng[1];
					if(street.isEmpty() || street == ALLOW_BLANK){
						adds = U.getAddressGoogleApi(latlng);
						geo="TRUE";
					}else{
						U.log("^^^^^^^^^^^^^^^^^|"+street+"|^^^^^^^");
						adds[0] = street;
						adds[1] = city;
						adds[2] = state;
						adds[3] = zip;
						geo = "FALSE";
					}
				}
			}
		}else {
			adds[0] = street;
			adds[1] = city;
			adds[2] = state;
			adds[3] = zip;
			geo="FALSE";
		}
		if(lat==ALLOW_BLANK && adds[0]!=ALLOW_BLANK){
			//U.log("Aa::::::"+Arrays.toString(adds));
			adds[0] =adds[0].replace("model home coming soon", "");
			latlng=U.getlatlongGoogleApi(adds);
			lat = latlng[0];
			lng = latlng[1];
			geo = "TRUE";
			
			
		}
		adds[0] = adds[0].toLowerCase().replaceAll(
				"Offsite Model - Last Chance|visit our model home in riverstone |sales office tbd|model home coming soon|model address tba|model home tba| IsModel Closed Until Phase 3|Grand Central Park Coming Soon|model offsite", ALLOW_BLANK);
		U.log(adds[0]+"**************");
		//geo= "true";
		
		U.log(latlng[0]);
		System.out.println("hiiiiiiiii");
		U.log(latlng[1]);
		if(adds[0].length()<4||adds[0]==ALLOW_BLANK){
			adds=U.getAddressGoogleApi(latlng);
			geo="TRUE";
			
		}
		html=html.replaceAll("1 to 2 Story |one and two story","1 Story ,2 Story");
		floorMainHtml=floorMainHtml.replaceAll("1 to 2 Story |one and two story","1 Story ,2 Story");
			
		communityName = communityName.replace("Creekside 80s, Coronet|Waterbridge", "Creekside 80s, Coronet And Waterbridge");
		communityName = communityName.replaceAll(",", " ").replaceAll("Luxury Homes at Sawmill Lake|  Patio Homes at Sawmill Lake| Luxury", "");
		communityName = communityName.trim();
		if(communityName.endsWith("-"))communityName = communityName.replace("-", "");
		U.log(communityName+"::::::::");
		//----------from img
		if(communityUrl.contains("http://www.darlinghomes.com/new-homes/texas/houston/montgomery/woodforest-luxury-patio-community"))status = "New Homesites Available";
		if(communityUrl.contains("/new-homes/texas/houston/the-woodlands/coronet-ridge-and-waterbridge-community"))status = "New Lakeview Homesite Available";
		if(communityUrl.contains("/new-homes/texas/dallas/coppell/main-street-coppell-community"))status = "Limited Opportunities Remain";
		if (communityUrl.contains("http://www.darlinghomes.com/new-homes/texas/houston/cypress/alden-woods-community")) status="New section now open";
		//if(communityUrl.contains("http://www.darlinghomes.com/new-homes/texas/houston/missouri-city/sienna-plantation-patio-community"))status=status.replace(rem, "");
		if(communityUrl.contains("/new-homes/texas/houston/spring/harmony-creek-community"))status = status+", Only 1 Opportunities Remain"; //HardCoded as it is written on image
		//if(communityUrl.contains("http://www.darlinghomes.com/new-homes/texas/houston/fulshear/cross-creek-ranch-patio-community"))status = status+", Only 2 Opportunities Remain";	
		
		//----_Status From Images----------
		if(communityUrl.contains("https://www.darlinghomes.com/new-homes/texas/houston/fulshear/cross-creek-ranch-community")||
				communityUrl.contains("https://www.darlinghomes.com/new-homes/texas/houston/sugar-land/avalon-at-riverstone-55s-community")||
				communityUrl.contains("https://www.darlinghomes.com/new-homes/texas/houston/montgomery/woodforest-luxury-homes-community"))
			status = "Final Opportunity,"+status;
		if(communityUrl.contains("https://www.darlinghomes.com/new-homes/texas/houston/the-woodlands/creekside-75s-jaden-oaks-community"))
			status = "Limited Opportunities,"+status;
		if(data.communityUrlExists(communityUrl)){
			LOGGER.AddCommunityUrl(communityUrl+":::::::::::::::::;repeated:::::::::::::::");
			return;
			
		}
		
		
		LOGGER.AddCommunityUrl(communityUrl);
		U.log(adds[0]+"-------------**************");
		//street = adds[0];
		
		//---DType-----
		String dtype = U.getdCommType(html.replace("1.5,and 2 story ", "1.5 story,and 2 story ").replace("three- and four-story", "3 Story and four-story").replaceAll("first-floor living areas|after Brinkmann Ranch|Windsong Ranch Model Home|/windsong ranch/images/", "")+(allReadyHomeData+floorMainHtml+featureHtml).replaceAll(" 4 bedroom|3560 sq|4 Bed|Branch home features|Molding on First Floor|Doors on First Floor", ""));
		
		data.addCommunity(communityName, communityUrl ,U.getCommunityType(((html +section).replaceAll("master suites|, Master Planned Community,|65 Master","")).toLowerCase().replaceAll("The Woodlands - one of the finest master-planned communities|houston/master plans|dallas/master plans".toLowerCase(), "")));
		data.addAddress(adds[0], adds[1], adds[2].trim(),adds[3].trim());
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPrice(prices[0], prices[1]); 
		data.addLatitudeLongitude(lat.trim(),lng.trim(), geo);
		data.addPropertyType(Type, dtype); // propty
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(html.replaceAll("VIP Pre-Sale Event", "")));
	}
		index++;

	}
	

}

