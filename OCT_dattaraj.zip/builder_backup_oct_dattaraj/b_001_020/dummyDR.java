package com.shatam.b_001_020;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class dummyDR {
		
		static WebDriver driver = null;
	
		public static void main(String args[]) throws Exception  {
			
			U.setUpGeckoPath();
			driver = new FirefoxDriver();
			
			//String reg = U.getPageSource("https://www.drhorton.com/hawaii");
			String reg = U.getHtml("https://www.drhorton.com/hawaii", driver);
			FileUtil.writeAllText("/home/shatam-10/Desktop/data/drdata.txt", reg);
		
	}
}