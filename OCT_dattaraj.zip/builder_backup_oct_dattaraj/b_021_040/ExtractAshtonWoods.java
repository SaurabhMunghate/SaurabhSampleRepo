package com.shatam.b_021_040;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.OaIdl.HREFTYPE;

//import com.sun.jna.platform.win32.COM.COMUtils;
public class ExtractAshtonWoods extends AbstractScrapper {
	static int site = 0;

	public int i = 0;
	public int inr = 0;
	static int j = 0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	FirefoxProfile ffprofile = new FirefoxProfile();
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new ExtractAshtonWoods();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Ashton Woods Homes.csv", a.data().printAll());
		U.log(duplicates);

	}

	public ExtractAshtonWoods() throws Exception {

		super("Ashton Woods Homes", "https://www.ashtonwoods.com");
		LOGGER = new CommunityLogger("Ashton Woods Homes");
	}

//	public void innerProcess() throws Exception {
//		// System.setProperty("webdriver.gecko.driver",
//		// System.getProperty("user.home")+File.separator+"geckodriver");
//		int total=0;
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
//		String html = U.getHTML("https://www.ashtonwoods.com");
//
//		String reginSec = U.getSectionValue(html, "<section class=\"section divisions-grid\">", "</section>");
//		//U.log("hiiiiiregionSec::");
//		String[] val = U.getValues(reginSec, "<a href=\"", "\"");
//
//		for (String region : val) {
////			U.log(region);
//			String regionUrl = "https://www.ashtonwoods.com" + region;
//			U.log("region:::" + regionUrl);
//			html = U.getHtml(regionUrl, driver);
//
//			/*
//			 * String sec = U.getSectionValue(html,
//			 * "<div class=\"communities-col\" id=\"communities-col\">",
//			 * "<hr class=\"separator\">"); if(sec==null) { continue; }
//			 */
//			
//			String[] mainSec = U.getValues(html, "js-view-selector__mobile-column-left\">", "View Community");
////			U.log("::::::::::\n"+mainSec.length);
//			for(String main : mainSec) {
////				U.log("::::::::::\n"+main);
////			String commLinks[] = U.getValues(main, "<a class=\"js-view-selector__grid-only\" ", "</a>");
//				String commLinks[] = U.getValues(main, "<a class=\"js-view-selector__grid-only", "division-list__view-community\">");
//			total+=commLinks.length;
////			 U.log(commLinks.length);https://www.ashtonwoods.com
//			
//			for (String link : commLinks) {
////				 U.log("link::"+link);
//				//String urlSec=U.getSectionValue(link, "<div class=\"name\">", "</div>");
//				
//				String commUrl = U.getSectionValue(link, "href=\"", "\"");
////				U.log(commUrl);
////				if(!commUrl.contains("/atlanta/aria-canon-series")) continue;
////				U.log("link::"+link);
////				 U.log("**************" + "https://www.ashtonwoods.com"+commUrl );
//				String commHtml=U.getHtml("https://www.ashtonwoods.com"+commUrl, driver);
//				//String pType = U.getSectionValue(link, "<span class=\"communtable\">", "</span>");
//				if (link.contains("division-list__communities\">")) {
//					//U.log("subcomm");
//					//String subSec = U.getSectionValue(link, "", "");
//					String[] subcomm = U.getValues(link, "<a href=\"", "\"");
////					//U.log(commUrl+"   "+subcomm.length+"    Subcommunitylength");
//					total+=subcomm.length-1;
//					for (String subCommunites : subcomm) {
//						commUrl = "https://www.ashtonwoods.com" + subCommunites;//U.getSectionValue(subCommunites, "href=\"", "\"");
//						commHtml=U.getHtml(commUrl, driver);
//						//U.log("MMMMMM "+commHtml.contains("<div class=\"value\">Coming soon</div>"));
//						/*if(subCommunites.contains("<div class=\"value\">Coming soon</div>"))
//							addDeails(commUrl, commHtml,subCommunites);
//						else*/
////						U.log("URL   "+commUrl);
////						U.log(">>>>>>>>>>>");
//						if (commUrl.contains("-area") || commUrl.contains("#quick-move-ins"))continue;
//						U.log("URL   "+commUrl);
////							addDeails(commUrl, commHtml,main+subCommunites,regionUrl);
//
//					}
//				} else {
//
//					if (commUrl!=null && commUrl.length() > 3) {
//						if(commUrl.contains("null"))return;
//						else {
//						commUrl = "https://www.ashtonwoods.com" + commUrl;
//						commHtml=U.getHTML(commUrl);
////						U.log("<<<<<<<<<<");
////						if (commUrl.contains("-area") || commUrl.contains("#quick-move-ins"))continue;
//						U.log("URL   "+commUrl);
////						addDeails(commUrl,commHtml, main,regionUrl);//link
//						}
//					}
//				}
//				inr++;
//				i++;
//			}
//			}
//		}
	//	LOGGER.DisposeLogger();
	//	driver.quit();
//		//U.log("--------------------"+total);
//	}
	
	
	public void innerProcess() throws Exception {
		// System.setProperty("webdriver.gecko.driver",
		// System.getProperty("user.home")+File.separator+"geckodriver");
		int total=0;
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		U.setUpChromePath();
		driver=new ChromeDriver();
		String html = U.getHTML("https://www.ashtonwoods.com");

		String reginSec = U.getSectionValue(html, "<div class=\"location__dropdown\">", "</ul>");
//		U.log("hiiiiiregionSec::"+reginSec);
		String[] val = U.getValues(reginSec, "<a href=\"", "\"");

		for (String region : val) {
//			U.log(region);
			//if(!region.contains("houston")) continue;
			String regionUrl = "https://www.ashtonwoods.com" + region;
//			U.log("region:::" + regionUrl);
			//if(region.contains("dallas")) {
			html = U.getHtml(regionUrl, driver);

			/*
			 * String sec = U.getSectionValue(html,
			 * "<div class=\"communities-col\" id=\"communities-col\">",
			 * "<hr class=\"separator\">"); if(sec==null) { continue; }
			 */
			
			String[] mainSec = U.getValues(html, "js-view-selector__mobile-column-left\">", "View Community");
			U.log("mainCommunitiews lenght"+mainSec.length);
			for(String main : mainSec) {
			
				String subSec=U.getSectionValue(main, "<div class=\"hidden-xs division-list__communities\">", "</div>");
				if(subSec.contains("<a href=\"")) {
					String[] sub_url=U.getValues(subSec, "<a href=\"", "\">");
					if(sub_url.length>0) {
					for(String sub_Url : sub_url) {
						sub_Url="https://www.ashtonwoods.com"+sub_Url;
						U.log("sub_url=="+sub_Url);
						addDeails(sub_Url,"",regionUrl);
					}
					}
				}
				else {
					String url=U.getSectionValue(main, "href=\"", "\">");
					url="https://www.ashtonwoods.com"+url;
					U.log(">>>>>>url=="+url);
					addDeails(url,main,regionUrl);
				}
			
//				String commUrl = U.getSectionValue(main, "href=\"", "\"");
////				U.log("commUrl**************"+commUrl);
//				if(commUrl==null) continue;
//				if(commUrl.endsWith("-area")) continue;
//				//if(!commUrl.contains("dallas")) continue;
//				String commHtml=U.getHtml("https://www.ashtonwoods.com"+commUrl, driver); 
//				
//				//String pType = U.getSectionValue(link, "<span class=\"communtable\">", "</span>");
//				if (commHtml.contains("<div class=\"content-wrapper property-cards__header-wrapper\">")) {
//					//U.log("subcomm");
//					//String subSec = U.getSectionValue(link, "", "");
//					String[] subcomm = U.getValues(commHtml, "<div class=\"property-card property-cards__card\"", "View Series");
//					
//					U.log(commUrl+"   "+subcomm.length+"    Subcommunitylength");
//					//total+=subcomm.length-1;
//					for (String subCommunites : subcomm) {
//						commUrl = "https://www.ashtonwoods.com" + U.getSectionValue(subCommunites, "href=\"", "\"");
//						U.log(total+"-->"+commUrl);
//						//U.log(total+"-->"+subCommunites);
//						commHtml=U.getHtml(commUrl, driver);
//						
////							addDeails(commUrl, commHtml,subCommunites,regionUrl);/////
//						total++;
//					}
//				}else if(commUrl.contains("creekside-ranch")) {
////					U.log("MMM");
//					String subComUrlsec=U.getSectionValue(main, "<div class=\"hidden-xs division-list__communities\">", "</div>");
//					String subcomUrl=U.getSectionValue(subComUrlsec, "<a href=\"", "\"");
//					String Url="https://www.ashtonwoods.com"+subcomUrl;
////					U.log("subCommUrl==="+Url+ "\nsubcommNmae");
////					addDeails(Url, commHtml,main,regionUrl);//////
//				}
//				
//				
//				else {
//  
//					if (commUrl.length() > 3) {
////						U.log("<<<<<<<<<<");
//						commUrl = "https://www.ashtonwoods.com" + commUrl;
////						U.log(total+"-|->"+commUrl);
////						U.log("Urls====="+commUrl);
////						addDeails(commUrl,commHtml, main,regionUrl);//link
//						total++;
//					}
//				}
//			    if(commUrl.contains("katy-lakes")) {
//			    	
////				U.log("commUrl======"+commUrl+"\nSSSSS\n");
//				String subComUrlsec=U.getSectionValue(main,"<div class=\"hidden-xs division-list__communities\">","</div>");
////				U.log("subComUrlsec======"+subComUrlsec+"\nSSSSS\n");
//
//				
//				String subcomUrl[]=U.getValues(subComUrlsec, "<a href=\"", "\">");
//				//String subcommUrls=ALLOW_BLANK
//				for(String subcommUrls:subcomUrl) {
//					
//					subcommUrls="https://www.ashtonwoods.com"+subcommUrls;
////					U.log("subcommUrls====="+subcommUrls);
//					addDeails(subcommUrls,commHtml,main,regionUrl);/////
//				    }
//				}
				inr++;
				i++;
			
			}
		}
		LOGGER.DisposeLogger();
		try{driver.quit();}catch(Exception e) {}
		U.log("--------------------"+total);
		//}
	}
	
	
	

	private void addDeails(String url, String commSec, String regionUrl) throws Exception {
//		try
//		{
			
//		if(j>=5 && j<=30)
//			if(j>=29 && j<=30)
//			if(j>=53 && j<=60)//======
//				if(j>=75 && j<=90)//======
//			if(j>=90)//======
			{
			//TODO: For Single Community Execution
//				if(!url.contains("https://www.ashtonwoods.com/san-antonio/preserve-singing-hills-60s"))return; 
		
			if (url.contains("https://www.ashtonwoods.com/dallas/montgomery-ridge-60-heritage-series"))return;//redirect
			if (url.contains("https://www.ashtonwoods.com/tampa/fishhawk-preserve"))return; // redirect modify at "01-07-2017"
			if (url.contains("https://www.ashtonwoods.com/houston/hidden-lakes-70ft"))return;// redirect
			if (url.contains("https://www.ashtonwoods.com/atlanta/cobblestone-manor-sf"))return;
			if (url.contains("https://www.ashtonwoods.com/atlanta/new-sandy-springs-development"))return;
			if(url.contains("https://www.ashtonwoods.com/phoenix/trailside-spur-cross"))return;//redirect at main community dt: 18Aug21
         if(url.equals("https://www.ashtonwoods.com/houston/katy-lakes")) return;//parent commumnoity
			//TODO: For Single Community Execution
			
//			if (!url.contains("https://www.ashtonwoods.com/san-antonio/preserve-singing-hills-"))return;
			{
				
				
				U.log("\n::::::::::Count:::::::::::"+j+"\n" + "\tPage :" + url);
				
				String html=U.getHtml(url, driver);
//				 U.log(commSec);
				String flag = "false";
				if (data.communityUrlExists(url))
				{
					LOGGER.AddCommunityUrl(url + "--------REPEATED-------");
					return;
				}
				if (html.contains("PAGE NOT FOUND")) {
					LOGGER.AddCommunityUrl(url + "--------PAGE NOT FOUND-------");
					return;
				}
				
				
				LOGGER.AddCommunityUrl(url);
				
				U.log("regionUrl  ==  "+regionUrl);
				String regHtml=U.getHTML(regionUrl);
				String CommSec[]=U.getValues(regHtml, "<div class=\"row js-view-selector__grid-only js-division-list__image-row\">", " View Community");
				U.log("lennnnn======"+CommSec.length);
				
				String homePlanSec=U.getSectionValue(html, "<div class=\"tabs__series js-carousel__slider\">", "<li id=\"panel-quick-move-ins");
				
				
//				
				html=html.replaceAll("No future phases or pre-sale homesites will be available|No future phases or pre-sale homesites available", "");
			//	U.log(commSec);
				commSec = commSec.replaceAll("beds\">\\s*Sold Out|baths\">\\s*Sold Out|area\">\\s*Sold Out|price\">\\s*Sold Out", "");
				html = html.replace("$1M", "$1,000,000");
				html = html.replace("and Grand Opening information", "").replaceAll("coming soon on the right|closeout.jpg", "")
						.replace("Coming Soon\"", "").replace("Coming Soon! ", "").replace("Coming Soon,", "")
						.replace("FishHawk Ranch Cottage", "").replace("information coming soon", "").replace("<span>Coming soon","");
				
				// ========================Comm Name =====================================
				String commName = "";
				U.log("url::::::"+url);
				String commHtml=U.getHTML(url);
				String remove=U.getSectionValue(commHtml, "<section class=\"property-cards property-cards-", "</footer>");
				if(remove!=null)
				{
					commHtml=commHtml.replace(remove, "");
				}
				
//				String quickSec = U.getSectionValue(commHtml, "id=\"quick-move-ins-tab\">", "<li id=\"panel-quick-move-ins\"");	
				
//				U.log(":::::::::::::::"+quickSec);
//				String commNameSec = U.getSectionValue(html, "<a class=\"js-view-selector__grid-only\" href=", ">");
				commName=U.getSectionValue(commHtml, "<h1 class=\"image-content__title\">", "<");
				
				
				commName=commName.replace("Hampton Oaks Traditional ", "Hampton Oaks");
				
				
				U.log("commName:::::::::::::::"+commName);
				if(url.contains("houston/creekside-ranch-45ft")) {
					commName="Creekside Ranch 45FT";
				}
//				U.log("::::::::::::;"+commName);
				if(commName==null) {
				String commNameSec=U.getSectionValue(commSec, "<div class=\"name\">", "</div>");
					if(commNameSec!=null)
						commName=U.getSectionValue(commNameSec, ">", "<");
				}
				
//				if(commName!=null) {
//				commName = commName.replaceAll(" - Townhomes$|New Homes|Traditional|Villas|Lofts", "");
//				commName = commName.replaceAll("Manors|Executive|Manor| - Single Family", "");
//				}
					String ComSec=null;
					//commName=commName.replace("-", "");
					commName=commName.replace("City Point Bungalows", "City Point");
					commName=commName.replace("City Point Urban", "City Point");
				 U.log("Comm Name:" + commName);
				 String name=commName;
				// U.log("aaaa"+commName+"aaaaa");
				if (commName.contains("type=\"text/css\">"))
					commName = U.getSectionValue("aaa" + commName, "aaa", "-");
				
				for(String commsec : CommSec) {
					if(commsec.contains((name).replaceAll("  Single Family|  Townhomes", "")))
					{
						
//						U.log("????????????"+commsec);
						
						ComSec+=commsec.replace("Quick Move-Ins", "");
					}
				}
				
				
//				String homePlanSec=U.getSectionValue(commHtml, "<div class=\"tabs__series js-carousel__slider\">", "<li id=\"panel-quick-move-ins");

				
				
				
				
				// -----------End Name-----------
				String secPrice = U.getSectionValue(html, "id=\"1\"", "<div id=\"collapse9\"");
				// U.log(":::::::::" + secPrice);
				String quickHtml = ALLOW_BLANK;

				String moreposSec = U.getSectionValue(html, "<h3 class=\"section-title\">More Possibilities</h3>","</html>");
				if (moreposSec != null) {
					html = html.replace(moreposSec, "");
				}

//				String subComm = U.getSectionValue(html, "<section class=\"section section-full-width section-subcommunity\">", "</section>");
//				if(subComm != null)
//					html = html.replace(subComm, "");
				html=html.replaceAll("<div class=\"price\">\\s+From \\$\\d{3},\\d{3}\\s+</div>", "");

				if (secPrice == null)
					secPrice = U.getSectionValue(html, "id=\"1\"", "id=\"3\"");

				String rem = U.getSectionValue(html, "<h3 class=\"section-title\">More Possibilities</h3>", "</html>");
				if (rem != null)
					html = html.replace(rem, "");
				// $460's
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				// Quick move in
				
				String[] price = { ALLOW_BLANK, ALLOW_BLANK };
				
				String[] r = U.getValues(html, "<input type=\"hidden\"", "\">");
				for(String rr : r) {
					
					html = html.replace(rr, "");
				}
				//commSec = commSec.replace(U.getSectionValue(commSec, "<span class", "</span>"), "");
				
				int count=0;
				String quickSec=U.getSectionValue(commHtml, "id=\"quick-move-ins\"", "</section>");
				if(quickSec!=null) {
				String[] quick = U.getValues(html, "<a class=\"property-card__action\" target=\"_blank\"", "View Home\n" + 
						"</a>");
				U.log("quick======"+quick.length);
				if (quick != null)
					for (String q : quick) {
						if(q.contains("Available Now")) {
							count++;
						}
						quickHtml += q;
					}
				}
				U.log("count===="+count);
				
				
				
				
				
				
				if (secPrice == null)
					secPrice = ALLOW_BLANK;
				if (secPrice != null)
					secPrice = secPrice.replace("'s", ",000").replace("0s", "0,000");
				// U.log(quickhtml);
				if (secPrice == null)
					secPrice = ALLOW_BLANK;
			//	html=html.replace("Plans from $277K - $336K", "");
				html=html.replace("mid-$500s", "mid-$500,000").replace("$1.3M", "$1,300,000").replace("$1.1M", "$1,100,000").replace("$1.2M", "$1,200,000").replace("high 200's", "high $200's");
				html=html.replace("$1.6M", "$1,600,000").replace("From $567K - $657K", "From $567,000 - $657,000");
				html = U.formatMillionPrices(html);
			
				
				
				commHtml=commHtml.replace("mid-$500s", "mid-$500,000").replace("$1.3M", "$1,300,000").replace("$1.1M", "$1,100,000").replace("$1.2M", "$1,200,000").replace("high 200's", "high $200's");
				commHtml=commHtml.replace("$1.6M", "$1,600,000").replace("From $567K - $657K", "From $567,000 - $657,000");
				
				commHtml = commHtml.replace("from the $600's", "from the $600,000").replace("'s", ",000").replace("0s</div>", "0,000</div>").replace("0s", "0,000").replaceAll("aria-valuetext=\"\\$\\d{3}K\"><div class=\"noUi-tooltip\">\\$\\d{3}K</div>", "").replace("K", ",000").replace("K</div>", ",000").replace("K - ", ",000 - ");
				commHtml = commHtml.replace("priced from the low $600,000, offers a casual", "")
						.replace("K", ",000").replaceAll("0’s|0's|0s|0S", "0,000").replace("$1.0M", "$1,000,000").replace("$1.4M</div>", "$1,400,000</div>").replace("$655K - $713K", "$655,000 - $713,000").replace("$419K", "419,000");
				commSec=commSec.replace("K", ",000").replace("$1M", "$1,000,000").replace("0s", "0,000").replace("$1.1M", "$1,100,000").replace("$1.2M", "$1,200,000");
				//U.writeMyText(html);
				commHtml=commHtml.replace("K", ",000");
				
				 
				
				String comsecPrice = commSec.contains("|  ") ? "" : commSec;
				
//				U.log("commSec:::::"+comsecPrice);
//				U.log("MMMMMMM "+Util.matchAll(html+comsecPrice  , "[\\s\\w\\W]{50}PLANS FROM[\\s\\w\\W]{100}", 0));
//				U.log("MMMMMMM "+Util.matchAll(commHtml+comsecPrice  , "[\\s\\w\\W]{50}PLANS FROM[\\s\\w\\W]{100}", 0));

				price = U.getPrices(( commHtml+quickHtml+comsecPrice).replaceAll(
						"e18853ff16b30131c857d1a4c3816e85|5892aa798987c8666aff9994886161b8|48294ca4cc|\\d{9,19}|40557114740357400|1460442009650|89707625367679650|1460441461453|76804748735715180|1460438276957|87716074849571090|1460431120244|94231503449912720|1460433707254|36349518964593610|1460436807365|20369591800988516|<div class=\"noUi-tooltip\">\\$\\d,\\d{3},\\d{3}</div>",
						""),
						"_price\">\\$\\d{3},\\d{3}</div>|Plans from \\$\\d,\\d{3},\\d{3}—\\$\\d,\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}—\\$\\d,\\d{3},\\d{3}|body-title\">\n\\s*\\$\\d+,\\d+\n\\s*</div>|mid-\\$\\d{3},\\d{3}|Plans from \\$\\d{3} - \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}–\\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|(from|starting in) the mid-\\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3} - $\\d{3},\\d{3}|From \\$\\d{3},\\d{3}\\s?-\\s?\\$(\\d,)?\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3} </span>|\\$\\d{3},\\d{3}</div>|\\$\\d,\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|<p class=\"city\">\\$\\d{3},\\d{3}</p>|value\">\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|value\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*-\\s*\\$\\d{3},\\d{3}|<span class=\"price\">\\$\\d{3},\\d{3}\\s*-\\s*$\\d{3},\\d{3}</span>|From \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>|\\$</em>\\d{3},\\d{3}</span>|low \\$\\d{3},\\d+|priced from the \\$\\d{3},\\d+|in the \\$\\d{3},\\d+|the high \\$\\d{3},\\d+|value\">\\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}</div>|value\">\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</p>",
						0);
				
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				 U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//				 U.log("MMMMMMM "+Util.matchAll(commHtml  , "[\\s\\w\\W]{30}\\$401[\\s\\w\\W]{100}", 0));
//				 U.log("MMMMMMM "+Util.matchAll(comsecPrice  , "[\\s\\w\\W]{30}\\$401[\\s\\w\\W]{100}", 0));

				if (minPrice == ALLOW_BLANK) {
					String[] pric = { ALLOW_BLANK, ALLOW_BLANK };
					pric = U.getPrices(commSec, "\\$</em>\\d+,\\d+", 0);
					minPrice = (pric[0] == null) ? ALLOW_BLANK : pric[0];
					maxPrice = (pric[1] == null) ? ALLOW_BLANK : pric[1];
					
				}
				//U.log(html);
				// ----------square feet---------
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;

				// regionsqft
//				if(html.contains("View Home\n" + 
//						"</a>")) {
				
				quickHtml = quickHtml.replaceAll("</strong>\n*\\s*<span>", "");

				String[] sqft = U.getSqareFeet((secPrice + commHtml + quickHtml + commSec).replaceAll("\\d{2},\\d{3} sq\\. ft", ""),
						"\\d,\\d{3} - \\d,\\d{3} sqft.|\\d,\\d+–\\d,\\d+ sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq. ft.|up to over \\d,\\d{3} square feet|\\d,\\d{3}Sq. Ft|<strong>\\d,\\d{3}</strong>\\s*<span>Sq. Ft.</span>|\\d,\\d{3} - \\d,\\d{3} sq. ft.|<span>\\d{3} - \\d,\\d{3} sq. ft.|<strong>\\d,\\d{3}</strong>\\s+<span>Sq. Ft.</span>\\d,\\d{3} - \\d,\\d{3} sq. ft.|\\d,\\d{3} up to \\d,\\d{3} square feet|\\d,\\d{3} up to nearly \\d,\\d{3} square feet|from \\d{4} to \\d{4} sq. ft|\\d{1},\\d{3} square feet to \\d{1},\\d{3} square feet|square footage from \\d{1},\\d{3}-\\d{1},\\d{3}|\\d{1},\\d{3}-\\d{1},\\d{3} sq. ft.|from \\d{1},\\d{3} – \\d{1},\\d{3} sq. ft.| \\d{3} - \\d,\\d{3} sq. ft|<span>\\d,\\d{3}</span>Square Feet|<span>\\d{3}</span>Square Feet|\\d{1},\\d{3} – \\d{1},\\d{3} square feet|\\d,\\d+ to \\d,\\d+ square feet|\\d+ - \\d+ sq ft|<div class=\"square\">\\s+<span>\\d,\\d+|\\d+ – \\d+ square feet|\\d+,\\d+ to just over \\d+,\\d+ square fee|>\\d+ - \\d,\\d+<|\\d+,\\d+ to \\d+,\\d+\\+ square feet|\\d,\\d{3} sq. ft.",
						0);
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
				//U.log("MMMMMMM "+Util.matchAll(commSec, "[\\s\\w\\W]{30}2,506–3,358 sq. ft.[\\s\\w\\W]{100}", 0));
				//U.log("commSec: "+commSec);	
				// -------LatLng-------
				String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
//				
				// U.log(html);story
				String addsec=null;
				String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String addLatSec=U.getSectionValue(html, "<a class=\"button button--primary modal-directions__action\" href=", "Open in Maps</a");
				 
				addsec = U.getSectionValue(addLatSec, "search/", "/@");
				addsec=addsec.replaceAll("Mc,000inney", "McKinney").replaceAll(",000aty", "Katy")
						.replaceAll("Pittsboro, NC", "Pittsboro").replaceAll("202 ,000ilmarnock", "202 Kilmarnock")
						.replaceAll("lincoln oaks by ashton woods, |Lagos by Ashton Woods,", "")
						.replace("Berry Creek Highlands by Ashton Woods ,  ", "")
						.replaceAll("Lexington Estates By Ashton Woods, |Lexington Estates by Ashton Woods, ", "");
				 U.log("addsec=="+addsec);
				add=U.getAddress(addsec);
				
				String latLngSec=U.getSectionValue(addLatSec, "/@", "\" target=\"");
//				
				latLng=latLngSec.split(",");
//				
				
				U.log("\n Address is " + Arrays.toString(add));
//				U.log("addsec==" + addsec);
				U.log("latlang==" + latLngSec);
							
				
				add[0] = add[0].toLowerCase();
//				U.log("Street is : " + add[0]);
				add[0] = add[0].replaceAll(
						"[M|m]odel [n|N]ow [S|s]old!|two beautiful model homes now open!|model coming soon!|model closed - by appointment only|by appointment only|by appointment only\\.|visit our model home in pecan crossing -|model closed|\\. by appointment|- model is closed",
						"").replace("&amp; ", "& ");
//				
				if (add[0].length() < 4 && latLng[0].length() > 4) {
					add = U.getAddressGoogleApi(latLng);
					if(add == null) add = U.getAddressHereApi(latLng);
					flag = "TRUE";
				}
				if(latLng[0]==null && add[1]!=null) {
					latLng=U.getlatlongGoogleApi(add);
					if(latLng == null) latLng = U.getlatlongHereApi(add);
					flag = "TRUE";
				}
				
				 
//				 if(url.contains("https://www.ashtonwoods.com/houston/summer-lakes-60ft")) {
//					 add[0]="302 Lake Rim Drive";
//					 flag="TRUE";
//				 }
//				 
				 U.log("\n Address is-1 " + Arrays.toString(add));
				 U.log(" LatLng is" + Arrays.toString(latLng));
				 
				//============================================ ...Property Status ========================================
				String pStatus = ALLOW_BLANK;
				
				//----remove header------
				//html = U.removeSectionValue(html, "</title>", "<div class=\"hero-description\">");
				
//				String qq=U.getSectionValue(html, "<span class=\"quick-move-ins-section-btn\">","</span>");
//				qq = qq + U.getSectionValue(html, " <div class=\"hero-description\">", "<div class=\"hero-links\">");
//				qq = qq.replace("Now Selilng", "Now Selling");
				
				//qq = qq.replace("Located in this fast selling", "");

//				String remove = "coming soon and this community|Details Coming|Way to Close Out|WAY TO Close Out|WAY TO CLOSE OUT|FINAL opportunity to own in this great| Limited homesites available\\s*</li>|home design are now sold out|home design&nbsp;are now sold out|Coming soon, explore|data-community=\"Overlook at Queen Creek\">\n*\\s*Coming Soon|<span class=\"price\">\n*\\s*Coming Soon\n*\\s*</span>|data-community=\"Halstead Lofts\">\n*\\s*Coming Soon\n*\\s*</p>| data-price=\"Coming soon\"|From Coming Soon|GALLERY NOW OPEN|<p class=\"city\">Coming soon</p>|Plan Details Coming Soon|our homes available for quick move-in.</p>|MODEL AND HOME GALLERY: NOW OPEN| Sound is now available| designer model home is now available|All Quick Move-ins|Quick move-ins only| homes available for quick move-in|model home is the last home available|Show Only</span> <span>Quick Move-ins</span|nformation on Our Quick Move-In Inventory Cal|We are currently sold out. We are estimating|new section coming Fall 2016|Details Coming Soon|last opportunity for our popular \"Oxford|Final opportunities! Schedule an appointment|now open in our model|sold_out|Center coming soon|2014|<h4>Information Center Opening Soon!</h4>|Model Opening Summer 2014|>Coming Soon</span>&nbsp|the Grand Opening|NOW SELLING!  UNFINISHED|Now selling 48|plans coming soon|garages are now selling|.coming-soon|awh-coming-soon.jpg|\"coming-soon\"|<li>COMING SOON</li>|GRAND OPENING DETAILS|<li>COMING SOON|coming-soon\"|coming-soon.jpg|Details Coming Soon</p>|HOME COMING SOON";
//				html = html.replace("Only 8 executive homesites available", "Only 8 homesites available").replaceAll(remove, "").replaceAll("\\d Quick Move-Ins Available|\\d Quick Move-ins Available|\\d quick move-ins available", " Quick Move-in")
//						.replace("} quick move-ins available</a>", "").replaceAll("new phase is now open |NEW PHASE NOW OPEN", "new phase now open ")
//						.replaceAll("Plan Details Coming Soon|Join Our VIP List today to find out details about the next section opening Fall 2021", "")
//						.replaceAll("for quick move|available for quick move-in|purchase a quick move-in|NEW QUICK MOVE-IN HOMES COMING SOON|Details Coming Soon|\"description\":\"<p>FINAL OPPORTUNITIES! Located|[E|e]*lementary [S|s]*chool opening in the Fall |Coming Late Summer 2019!|<div class=\"value\">Coming Soon</div>|Close Out. By appointment|price\">\\s*Coming Soon|Lofts\">\\s*Coming Soon|Amenity Center - Coming Soon|-price=\"Coming soon\"|Model Coming Soon|Sold out\\s*</p>\\s*<p class=\"phone\">|<span class=\"price\">Coming Soon|data-price=\"Coming soon\"|Coming Soon\\s*</p>\\s*<p class=\"phone\">|<strong>Coming soon</strong>\\s*<span>Sq.|Model and Home Gallery Coming Soon|GrandCloseout_|kind move-in ready home|recreation complex is coming soon|Move-In Ready Home Plus|looking for a quick move-in home in the area|Special Pricing on homes ready now|Special Pricing on homes ready now|Plans Now Available|Quick Move-In Homes from|golf course lots available|HOME - MOVE-|home - move-|in homes avail|Move In|move in|sold out. we are","");
				
				//-----Section for status------------
//				String sectionForStatus = U.getSectionValue(html, "afixed-sub-navigation sticky navbar", "<section class=\"section studio-section");
////				U.log(sectionForStatus);
//				commSec = commSec.replace("Located in this fast selling", "").replaceAll(">\r\n\\s+ Sold Out\r\n\\s+ <|>\r\n\\s+ Sold Out \\s+ <", ">Sold Out<");
//				//U.log(commSec);
//				commSec=commSec.replaceAll("beds\">Sold Out|price\">Sold Out|baths\">Sold Out|area\">Sold Out", "");
//				String sectionForStatus1 = U.getSectionValue(html, "<span class=\"quick-move-ins-section-btn\">", "</span>");
//				if(sectionForStatus!=null||sectionForStatus1!=null) {
//					sectionForStatus1 = (sectionForStatus+sectionForStatus1).replace("Located in this fast selling", "");
//				}
//				String promoSec = U.getSectionValue(html, " <section class=\"section section-promo\" ", "</section");	
//				pStatus  = U.getPropStatus((sectionForStatus1+"  "+qq+commSec+promoSec+quickSec).replace("section opening Spring 2022", "new section opening Spring 2022")
//						.replace("Current Section is SOLD out", "Current Section SOLD out").replace("oversized conservation homesites just released", "oversized homesites just released")
//						.replaceAll("first opportunity to own in our new phas|\"value\">Sold out|SOLD OUT                </p>|new phase is now open in Laureat|<h2>NEW PHASE NOW OPEN</h2>|<h2>NEW PHASE NOW OPEN!</h2>|<p>Opening Fall 2020</p>|=\"Coming soon\"|price-text\">Coming soon|Coming Late Summer 2019!|Plan Details Coming Soon|Plan Details Coming Soon|Description Coming Soon|complex is coming soon|remaining homes are selling|There are only a few|Plan Details Coming Soon|(price|footage)=\"Coming soon|-price=\"Coming soon\"|price-text\">Coming soon|Plan Details Coming Soon| lots available. Here,|which is coming in|but is move-in|Sales Gallery Coming Soon|<div class=\"value\">From Coming Soon</div>|ata-price=\"Coming soon\"|\">\\s+Coming Soon\\s+</p>|\"price\">\\s+Coming Soon\\s+</span>|ata-min-price=\"Coming soon|data-max-price=\"Coming soon|price-text\">Coming soon|School</div>\\s+<p>Opening Fall 2020</p>|One of the final opportunities for long-range views| closing costs. Limited time offer,|Model Homes Coming Soon|models coming soon", "")
//						.replaceAll("Quick Move-Ins Available</a>|#quick-move-ins|details about the next section opening Spring 2022|available for quick move|MOVE-IN HOMES COMING SOON!|Final opportunities! 80 ft homesites|\"description\":\"<p>FINAL OPPORTUNITIES! Located|streetAddress\":\"Coming|search/Coming|adress\">\\s+Coming|Gallery Coming|advantage of this last|remaining at Canopy|remaining! This stunning|Center is now|section-sm\">\\s+<p>Now", "")
//						.replace("Phase One is sold out", "Phase One sold out")); //
////			U.log("=====" + Util.matchAll(sectionForStatus1+qq+commSec+promoSec+quickSec,"[\\w\\s\\W]{50}new phase[\\w\\s\\W]{30}", 0));
//				pStatus = pStatus.replaceAll("Ready For Move-in, ", "");
//				if (commSec.contains("20-AW-CHAR-STN_ImageTags")) {
//					pStatus=pStatus.length()>2?pStatus+", Over 85% Sold":"Over 85% Sold";
//				}
				html=html.replaceAll("/quick-move-ins\"|>Quick Move Ins</a>|Search for\n" + 
						"              Quick Move Ins</a>|class=\"property-card__content-inner n-content\">\n" + 
						"            <ul>\n" + 
						"                <li>Limited homesites available</li>|<address class=\"schools__school-address\">\n" + 
						"                      Opening Fall 2021|Available Dec 2021|Model Home Juneberry now available|cta-banner__subtitle\">Limited-Time Offer</p>|explore our townhomes available for quick move-in|form-footer-col-title\">Coming Soon</p>|<div class=\"modal-directions__content-hours\">\n" + 
						"              <p><b>Coming Soon</b></p>", "")
						.replaceAll("explore our homes available for quick move-in|<!-- <span class=\"property-card__tag\">Now Selling</span> -->|Designer model home coming soon!", "");
				
				commHtml = commHtml.replaceAll("Current Section is SOLD out! New Section Coming Summer 2022!</h3>|before the gallery opening, or kick off|model home is opening soon", "");
				String remSec=U.getSectionValue(commHtml, "<script type=\"application/ld+json\">", "</script>");
				if(remSec!=null) {
					commHtml = commHtml.replace(remSec, "");
				} 
				String[] remSec2=U.getValues(commHtml, "<a class=\"property-card__footer-action", "</a>");
//				U.log("remSec2=="+remSec2);
				if(remSec2.length>0) {
					for(String remove1 : remSec2) {
					commHtml = commHtml.replace(remove1, "");
					}
				} 
				String commHtmlSec=U.getSectionValue(commHtml, "<div class=\"col-xs-12 col-lg-8\">", " </ul>\n" + 
						"              </div>");
				pStatus=U.getPropStatus((commHtmlSec+commSec+ComSec)
						.replace("Current Section is SOLD out", "Current Section SOLD out")
							.replaceAll("Moncks Corner is a new phase of Strawberry Station|text\">Sold Out|=\"Sold|Woods\",\"description\":\"Final Opportunity|model is coming soon|Model Coming Soon|MODEL COMING SOON|Model Home Juneberry now available|data-footage=\"Coming soon\"|data-stories=\"Coming soon\"|data-bedrooms=\"Coming soon\"|data-bath=\"Coming soon\"|data-garage=\"Coming", "")
							.replaceAll("Quick Move-in|NEW QUIC,000 MOVE-IN HOMES NOW AVAILABLE|Join Our VIP List today to find out details about the next section opening Spring 2022|<!-- <span class=\"property-card__tag\">Now Selling</span> -->|BY APPOINTMENT ONLY - - FINAL OPPORTUNITY|Quick Move-Ins</a>|MOVE-IN HOMES COMING SOON|Sales Center coming soon|sales center are Coming Soon| New Raleigh Studio Coming Soon|Studio Experience Coming Soon|explore our homes available for quick move-in|MODEL HOME NOW OPEN|Sales Center is NOW OPEN", ""));
				
//				U.log("MMMMMMMMM 11  "+Util.matchAll(commHtmlSec+commSec+ComSec, "[\\s\\w\\W]{100}Homes Now Available[\\s\\w\\W]{100}", 0));
//String quickSec=U.getSectionValue(commHtml, "id=\"quick-move-ins-tab\">", To)
//				String quickData=U.getValue(commHtml, "", To)
				
				
				
				
				
				U.log("pStatus>>>>>>>"+pStatus);
				if(pStatus.length()<1)
					pStatus=ALLOW_BLANK;
				
//				U.log("MMMMMMMMM "+Util.matchAll(commHtml, "[\\s\\w\\W]{100}Opening Soon[\\s\\w\\W]{100}", 0));
//				U.log("MMMMMMMMM "+Util.matchAll(quickSec+ComSec, "[\\s\\w\\W]{100}Sold Out[\\s\\w\\W]{100}", 0));

//				
				// --------Derived Type------------------------
				String derivedPType = ALLOW_BLANK;
//				String dtypeRem = U.getSectionValue(commHtml, "Know Your Neighbors", "</html>");
//
//				String dTyepSec = ALLOW_BLANK;
//				if (dtypeRem != null)
//					dTyepSec = commHtml.replace(dtypeRem, "").replaceAll("first level child we need to c|Branch|branch|ranch|Ranch|RANCH|floor|Floor", "");
//
//				commHtml = commHtml.replace("<div class=\"story\">\\s*<i class=\"icon story-ic\"></i>\\s*<span>3</span>",
//						"3 Stories");
////				U.log("<<<<<<<<<<<<<<<<<<<<" + quickHtml + ">>>>>>>>>>>>>>>>>>>>>>>>>>");
//				derivedPType = getDTypeOfStory(html+homePlanSec+quickSec);//replaceAll("<h4>Stories</h4>.*<span>", " Story ")
//				U.log("comOverview::" + derivedPType);
				derivedPType = U.getdCommType(
						(html+homePlanSec+quickSec).replaceAll("first level child we need to c|Two-story foyer|two-story entry foyer|24' wide|floor|Floor|level|Level|Branch|Rancho|Michael Dell’s Ranch|value=\"Single", ""));
				U.log("derivedPType >>>>>>>>  "+derivedPType);
				
				// --------End dtype------------

				// U.log("url::"+url);

//				U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);

				// ----Community Type -----------------------
//				String neigh = U.getSectionValue(commHtml, "<h5>Neighborhood</h5>", "</html>");
//				if (neigh != null) {
//					commHtml = commHtml.replace(neigh, "");
//				}
				commHtml = commHtml.replace("Golf Course</h4>", "").replace(" Top Golf", " Top Golf course");
				commHtml = commHtml.replace("golf course</span>", "").replaceAll(
						"oy-kizer-golf|<h4 class=\"name\">Falconhead Golf|ime at Fort Bend Country Club and Greatwood Golf Club|<h4 class=\"name\">Blackhawk Golf|<span>Golf|elongated windows",
						"");
				// U.log(Util.match(commHtml, ".*?golf.*?"));
				String communityType = U.getCommunityType((commHtml + commSec).replaceAll(
						" serenity of your lakeside lifestyle or the active social l|lake-front community in Towne| lakefront community in Towne Lake |teel appliances. Lakeshore is a gated lakefront community|inspired by your lakeside community|elongated| National Golf Club|master community|MASTER COMMUNITY|Stonebridge Country Club|Elongated|Country Club Drive|Eldorado Country|Towne Lake Community",
						""));
				U.log("communityType >>>>>>>>  "+communityType);
				// ---------End CommunityTYpe----------

				// -------------Property Type--------------------
				// pStatus = pStatus.replaceAll("\\w+ Opportunities Remain,", "");
				
				commHtml = commHtml.replace("farmhouse twist on a modern style", "Farmhouse in a community twist on a modern style")
						.replaceAll("Luxury Homes from Ashton Woods|Townhome</option>|label\">Single Family</div>|class=\"area\">\\w* Homes<|farmhouse style sink", "").replaceAll("luxury and prestige", "luxury homes");
				commSec=commSec.replaceAll("Townhome</option>|class=\"area\">\\w* Homes<", "");
				String propertyType = ALLOW_BLANK;

				//U.log("===========: "+ComSec);
				if(ComSec!=null) ComSec.replaceAll("The farmhouse kitchen,", "");
				commHtml=commHtml.replace("Bungalows", "Bungalows Homes").replaceAll("paint above the farmhouse sink for the kids|and subtle farmhouse roots reveal the depth|"
						+ "fresh approach to farmhouse|refined farmhouse table", "");
				propertyType = U.getPropType(commSec +commHtml+homePlanSec+ComSec);
				U.log("propertyType >>>>>>>>  "+propertyType);
				// U.log("prpperty type is : " + commSec);
				if (propertyType.contains("Townhome")&&propertyType.contains("Townhouse")) {
					propertyType=propertyType.replace("Townhouse, ", "");
				}
				if(url.contains("https://www.ashtonwoods.com/houston/summer-lakes-60ft"))
					propertyType="Single Family";
//				U.log("propertyType >>>>>>>>  "+propertyType);
//				U.log("MMMMMMM "+Util.matchAll(commHtml, "[\\s\\w\\W]{30}Bungalows Homes[\\s\\w\\W]{100}", 0));
				//-------formatting community name-------------
//				if (commName == null)
//					commName = url.replace("https://www.ashtonwoods.com/", "");
				commName = commName.replace("Estates at Sweetwater Townhomes - Now Pre-Selling", "Estates At Sweetwater")
						.replaceAll("houston/", "");
				commName = commName.replace("</span>", "");
				commName = commName.replaceAll("</title>\\w+<style media=\"all\" type=\"text/css\">\\w+\\@import url|Lofts|Country Club Traditional|Country Club","");
				// U.log(commName+" jjj");
				
				commName = commName.replace("Traditional$", "").replace("LoFTs", "Lofts");
				/*if (commName.endsWith("Cottage"))commName = commName.replace("Cottage", "");
				if (commName.endsWith("Courtyard"))commName = commName.replace("Courtyard", "");
				commName = commName.replaceAll("Cottages|Townhomes", "").trim();*/
				commName = commName.replace("University Place -", "University Place");
				commName=commName.replace("Lakeshore at Towne Lake Villas","Lakeshore At Towne Lake");
				
				if (commName.endsWith("Country Club"))commName = commName.replace("Country Club", "");

				
				String noteVar = U.getnote(html+ComSec);
				U.log("Note : "+noteVar);
//				U.log("MMMMMMMMM "+Util.matchAll(html+ComSec, "[\\s\\w\\W]{100}Pre-sale[\\s\\w\\W]{100}", 0));
				
				//--------Formatting Status-----------
				
				if (url.contains("/hastings-ridge-kinder-ranch")) {
					propertyType=propertyType+",Patio";
				}
//				if(url.contains("https://www.ashtonwoods.com/dallas/city-point-bungalows")) {
//					propertyType=propertyType+", Bungalow Homes";
//				}
				
				pStatus = pStatus.replaceAll("Move-in Ready Homes,", "");
				pStatus = pStatus.replace("Sold-out", "Sold Out");

				if (pStatus.contains(" Coming Summer 2017")) {
					pStatus = pStatus.replace("Coming Soon,", "");
				}
			//	if(!html.contains("<a class=\"q-mov-link\" href=\""+url.replace("https://www.ashtonwoods.com", "")))pStatus=pStatus.replaceAll("Quick Move-in, |Quick Move-in", "");
				if (pStatus.length() == 0)
					pStatus = ALLOW_BLANK;
				if(url.contains("/tampa/waterside"))pStatus ="Last Chance, "+pStatus;
//				add[1]=add[1].replace("Mc'sinney", "McKinney");
//				add[0]=add[0].replace("FM 1516 & Slumber Ln (NS)", "FM 1516 & Slumber Ln").replace("2053 west 'sinfield trail", "2053 west Kinfield trail");
				if(pStatus.contains(" Sold Out, Phase One Sold Out"))pStatus= pStatus.replace(" Sold Out, Phase One Sold Out", " Phase One Sold Out");
				if(url.contains("/charleston/sol-legare-preserve")) pStatus = pStatus +", Final Opportunity"; //From Img
				
				if(url.contains("https://www.ashtonwoods.com/houston/kingwood")) pStatus = pStatus +", Final Opportunity"; //From Img
				if(url.contains("https://www.ashtonwoods.com/atlanta/halstead-townhomes"))pStatus = "Sold Out";//From Img
				if(url.contains("https://www.ashtonwoods.com/atlanta/serenade-townhomes"))derivedPType = "4 Story";
				if(url.contains("https://www.ashtonwoods.com/houston/creekside-ranch-50ft"))derivedPType+= ", 1 Story, 2 Story";
				
				if(url.contains("https://www.ashtonwoods.com/raleigh/lochridge-manors")) pStatus="One Home Remainig, Quick Move-in";
				if(url.contains("https://www.ashtonwoods.com/raleigh/lochridge-estates")) pStatus="One Homesite Rmaining";
				if(url.contains("https://www.ashtonwoods.com/atlanta/bellehurst")) {
					addsec=ALLOW_BLANK;
					latLng[0]=ALLOW_BLANK;
					latLng[1]=ALLOW_BLANK;
					add[0]=ALLOW_BLANK;
					add[1]=ALLOW_BLANK;
					add[2]=ALLOW_BLANK;

					add[3]=ALLOW_BLANK;
					
				}
			//	if(url.contains("https://www.ashtonwoods.com/san-antonio/sunday-creek-kinder-ranch"))pStatus=pStatus.replace(", Coming Soon", "");
						
						if(url.contains("https://www.ashtonwoods.com/san-antonio/arcadia-ridge-highlands"))pStatus=pStatus.replace("Coming Soon,", "");
				//4075 Bellehurst Lane, Cumming, GA 30040
				if(url.contains("https://www.ashtonwoods.com/atlanta/bellehurst")) {
					add[0]="4075 Bellehurst Lane";
					add[1]="Cumming";
					add[2]="GA";
					add[3]="30040";
					latLng[0] = "34.22805";
					latLng[1] = "-84.2267997";
				}
				if(url.contains("https://www.ashtonwoods.com/san-antonio/copper-ridge")) {
					add[0]=ALLOW_BLANK;
					add[1]="New Braunfels";
					add[2]="TX";
					latLng=U.getlatlongGoogleApi(add);
					add=U.getAddressGoogleApi(latLng);
					flag="TRUE";
					noteVar="Address Taken From City And State";
				}
					/*
					 * if(url.contains("https://www.ashtonwoods.com/atlanta/brookview-single-family"
					 * )) noteVar="Pre-sale Opportunities Available";
					 * if(url.contains("https://www.ashtonwoods.com/atlanta/brookview-townhomes"))
					 * noteVar="Pre-sale Opportunities Available";
					 */
				pStatus = pStatus.replaceAll("\\d+ Quick Move-in", "Quick Move-in");
				if(pStatus.contains("Quick Move-ins Available")) {
					pStatus=pStatus.replace("Quick Move-ins Available", "Quick Move-in");
				}
				if(url.contains("https://www.ashtonwoods.com/dallas/willow-springs-50s"))maxPrice="$379,990";
				if(url.contains("https://www.ashtonwoods.com/austin/lagos"))pStatus=pStatus.replace("New Section Coming Soon, Coming Soon", "New Section Coming Soon"); //coming soon repeated
				if(url.contains("https://www.ashtonwoods.com/austin/mockingbird-park")||url.contains("/austin/carmel"))pStatus=pStatus.replace("New Section Coming, New Section Coming", "Coming Soon, New Section Coming");
			//	if(url.contains("houston/dellrose")|| url.contains("/houston/northgrove"))pStatus="New Phase, "+pStatus;
				if(url.contains("https://www.ashtonwoods.com/dallas/western-ridge"))pStatus=pStatus.replace(", Limited Opportunities Remain", "");
				commName = commName.replace("FT","ft");
				
				pStatus = pStatus.replace("Final Opportunities, Quick Move-in, Final Opportunity", "Quick Move-in, Final Opportunity").replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon").replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon").replace("Ii", "II").replace("IIi", "III");
			
				if(url.contains("https://www.ashtonwoods.com/raleigh/savaan-gardens"))pStatus="Sold Out";
				if(url.contains("https://www.ashtonwoods.com/atlanta/aria-tenor-series"))pStatus=ALLOW_BLANK;
				
				if(url.equals("https://www.ashtonwoods.com/orlando/hampton-oaks-manor"))minSqf="1756";
				
				U.log("\n Address is " + Arrays.toString(add));
				
				
				
				if(count>0) {
					if(pStatus.length()>3) {
						pStatus+=", Quick Move-in";
					}
					else
						pStatus="Quick Move-in";
				}
				
				
				U.log("commName:  " + commName);
				U.log("latLng:" + latLng[0]+latLng[1]);
				U.log("propertyType:" + propertyType);
				U.log("derivedPType:" + derivedPType);
				U.log("pStatus:" + pStatus);
				U.log("add[0]:" + add[0]);
//				U.log(">>>>>>>>>>>>>>>>>>" );
//				replaceAll("lincoln oaks by ashton woods, ", "")
//				.replaceAll("Lexington Estates By Ashton Woods, ", "")
				
				add[0]=add[0].replaceAll("lincoln oaks by ashton woods, |Lexington Estates By Ashton Woods, ", "");
				
				if(url.equals("https://www.ashtonwoods.com/houston/lakeshore-towne-lake-villas"))pStatus=pStatus.replace("Quick Move-in, ", "") ;
				
				if(url.equals("https://www.ashtonwoods.com/atlanta/reserve-wildwood"))minPrice=ALLOW_BLANK ;
				if(url.equals("https://www.ashtonwoods.com/austin/provence-60s"))pStatus="Final Opportunities in This Section" ;
				if(url.equals("https://www.ashtonwoods.com/dallas/legends-crossing-townhomes"))pStatus+=", Final Opportunities" ;
				if(url.contains("https://www.ashtonwoods.com/dallas/lexington-estates-townhomes"))pStatus="coming soon" ;
				
//				===================================================================================
				String lotCount=ALLOW_BLANK;
				String[] lot_data=null;
				String mapHtml=ALLOW_BLANK;
				String iframeSec=U.getSectionValue(commHtml, "id=\"community-map\">", "</iframe>");
				if(iframeSec!=null) {
				String iframe_link=U.getSectionValue(iframeSec, "<iframe src=\"", "\"");
//				
				U.log("iframe_link:::::::" + iframe_link);
				if(iframe_link!=null) {
					mapHtml=U.getHtml(iframe_link.trim(), driver);
					if(iframe_link.contains("#/lotmap")) {
						lotCount=Util.getUnits(mapHtml);
					}
					else {
//						int sum=0;
//						String[] lotDataSec1=U.getValues(mapHtml, "<div id=\"statuses-container\"", "</section>");
//						String lotDataSec=null;
//						if(lotDataSec1.length>0) {
//							for(String lotdata : lotDataSec1) {
//								U.log("lotdata=="+lotdata);
//						lotDataSec+=lotdata;
//							}
//						}
//						if(lotDataSec!=null) {
//							String[] lotData=U.getValues(lotDataSec, "<label>", "</div>") ;
//							if(lotData.length>0) {
//								for(String lotdata : lotData) {
//									lotdata=U.getNoHtml(lotdata).trim();
////									U.log("lotdata=="+lotdata);
//									sum+=Integer.parseInt(Util.match(lotdata, "\\d+"));
//								}
//							}
//						}
//						lotCount=Integer.toString(sum);
						lotCount=Util.getUnitsByMatch(mapHtml);
					}
				}
				}
				
//				if(url.contains("https://www.ashtonwoods.com/atlanta/encore-single-family"))
//				{
//					int count=0;
//					mapHtml=getHTML("https://argo.ml3ds-cloud.com/api/communities/86638?dataLevel=2&filterToActiveOnly=true");
//					lot_data=U.getValues(mapHtml, "{\"MappedFloorPlanIds\":", "\"Tags\":[]") ;
//					if(lot_data.length>0) {
//						for(String lots : lot_data) {
////							U.log("lots=="+lots);
//							if(!lots.contains("\"StatusId\":null")) {
//								count++;
//							}
////							break;
//						}
//					}
//					U.log("Count=="+count);
//					lotCount=Integer.toString(count);
//				}
				
				if(lotCount.equals("0") ){
					lotCount=ALLOW_BLANK;
				}
				 U.log("lotCount=="+lotCount);
				 
				 
				 
				
				 pStatus=pStatus.replace("Coming Soon, Coming Spring 2022", "Coming Spring 2022")
						 .replace("New Phase Now Open, Now Open", "New Phase Now Open");
					
				data.addCommunity(commName.replaceAll(" - Bungalows$|Cottages| Bungalows", ""), url.replace("https:", "https:"), communityType);
				data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
				data.addSquareFeet(minSqf, maxSqf);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
				data.addPropertyType(propertyType, derivedPType);
				data.addPropertyStatus(pStatus);
				data.addNotes(noteVar);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(lotCount);
			
			}
//			else
//				j++;
		
			}j++;
//		}
//		catch (Exception e) {
////			 TODO: handle exception
//			U.log(e);
//		}
	}
		
	
	
	public  String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName =U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode =U.CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent",
							"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "application/json, text/plain, */*");
			urlConnection.addRequestProperty("Content-Length","33427");
			urlConnection.addRequestProperty("Accept-Language","en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Referer", "https://myscp.ml3ds-icon.com/");
			urlConnection.addRequestProperty("x-ml-date", "Mon, 16 May 2022 13:41:28 GMT");
			urlConnection.addRequestProperty("Authorization", "converge.apiuser@medialabinc.local 7pzfu/Hd2paGcDtHWorV4zusLg4CHeJCUNjN2Xnq2Fw=");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	
	
	
	
	
	
	
	
//PRE-SELLING SOON
	private String getDTypeOfStory(String html1) throws IOException, InterruptedException {
		String html = html1;
		
		String val = U.getSectionValue(html, "<h4>Stories</h4>", "</span>");
		if(val!=null)
			val = U.getNoHtml(val).trim()+" Story";
		U.log("==================="+val);
		
		String[] dTypeSec = U.getValues(html, "<i class=\"icon story-ic\"></i>", "</div>");

		boolean oneStory = false, twoStory = false, threeStory = false, halfStory = false, oneptf = false,
				fourstory = false, thalf = false;
		String dType = ALLOW_BLANK;
		for (String story : dTypeSec) {
			 
			if (dTypeSec != null) {
				story = story.replace("1.5", "15").replace("4340", "4").replace("3.5", "35");

				String id = Util.match(story, "\\d+", 0);
				if (id != null) {
					// U.log(id);
					if (id.contains("15") && oneptf == false) {
						if (dType.length() < 4)
							dType = dType + " 1.5 Stories ";
						else
							dType = dType + ", 1.5 Stories ";
						oneptf = true;
					}
					if ((id.contains("1") && oneStory == false)) {
						if (dType.length() < 4)
							dType = dType + " 1 Stories";
						else
							dType = dType + ", 1 Stories ";
						oneStory = true;
					}
					if ((id.contains("2") && twoStory == false)) {
						if (dType.length() < 4)
							dType = dType + " 2 Stories ";
						else
							dType = dType + ", 2 Stories ";
						twoStory = true;
					}
					if (id.contains("3") && threeStory == false) {
						threeStory = true;
						if (dType.length() < 4)
							dType = dType + " 3 Stories";
						else
							dType = dType + ", 3 Stories";
					}
					
				}
			}

		}

		return dType.replace("-", "").trim().length() <= 1 ? ALLOW_BLANK : dType.replace("-", "").trim();
	}

}