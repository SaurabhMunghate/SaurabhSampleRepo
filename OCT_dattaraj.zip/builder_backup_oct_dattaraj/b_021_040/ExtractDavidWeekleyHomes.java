package com.shatam.b_021_040;


import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



//import org.pdfbox.examples.pdmodel.ReplaceString;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDavidWeekleyHomes extends AbstractScrapper {
	private static final String builderUrl = "https://www.davidweekleyhomes.com";
	//private static final Object  comUrl;
	static int sitecounter = 0;
	static int l=0;
	public int i = 0, j;
	public int inr = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		
		AbstractScrapper a = new ExtractDavidWeekleyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"David Weekley Homes.csv", a.data().printAll());
	}


	public ExtractDavidWeekleyHomes() throws Exception {

		super("David Weekley Homes", "https://www.davidweekleyhomes.com");
		LOGGER = new CommunityLogger("David Weekley Homes");
	}

	public void innerProcess() throws Exception {
		/*System.setProperty("phantomjs.binary.path", System.getProperty("user.home")+File.separator+"phantomjs");		
		driver = new PhantomJSDriver();*/
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHTML("https://www.davidweekleyhomes.com/");
		// U.log(html);
		String sec = U.getSectionValue(html, "marketSelectionDialog","</select>");
		//U.log(sec);
		String values[] = U.getValues(sec, "value=\"", "\"");

		for (String item : values) {
			//try {
				if(item.length()>2) {
					item = builderUrl + item;
				//	U.log("Region Url: " +  item);
	//				U.log(U.getCache(item));
					addDetails(item);
					//break;
				}
			inr++;
			i++;
		}
	//	addNewDetails("https://www.davidweekleyhomes.com/new-homes/fl/orlando/lake-mary/griffin-park-bungalows","");

		//U.log(values.length);
		LOGGER.DisposeLogger();
		driver.quit();
		System.out.println(totalCount);
	}

	int communityCount = 0;
	static int totalCount = 0;
	private void addDetails(String regUrl) throws Exception {
 // if(!regUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/cypress/lakeland-heights-34-series")) return;
		
		//if(!regUrl.contains("https://www.davidweekleyhomes.com/new-homes/nc/charlotte"))return;
	//	//if(!regUrl.contains("new-homes/tx/san-antonio/san-antonio/the-bluffs-at-two-creeks")) return;
	//	U.log("1st u,log in adddetails"+U.getCache(regUrl));
		String html = U.getHtml(regUrl.replace("com//new-", "com/new-"), driver);
		//U.log(regUrl.replace("com//new-", "com/new-"));
		//U.log(U.getSectionValue(html, "html", "Build On Your Lot"));
//		U.log(regUrl);
		String marketId = U.getSectionValue(html, "d.MarketId=\"", "\";");
		String jsonData = U.getHTML("https://www.davidweekleyhomes.com/search/communitydata?marketId="+marketId.replace("/", "%2F")+"&pageNumber=1");
	//	if(!marketId.contains("45"))return;
		//U.log(jsonData);

		String sec = U.getSectionValue(html, "Build On Your Lot", "\"boyl-communities-panel");
		//U.log("https://www.davidweekleyhomes.com/search/communitydata?marketId="+marketId.replace("/", "%2F")+"&pageNumber=1");
		if(sec==null)return;
		
		//String val[] = U.getValues(sec, " data-bind=\"attr: {href: Token}, text: Name", "</a></h3>");
		//String val[] = U.getValues(sec, "<h3 class=\"community-header dark\">", "</a></h3>");
		String val[] = U.getValues(sec, " <div class=\"single-tabbed-listing\">", "<div class=\"tab-container\">");
		//U.log(val.length);
		LOGGER.AddRegion(regUrl, val.length);
		
		int k=0;
		System.out.println("Size: " + val.length);
		//totalCount = totalCount + val.length;
		for (String item : val) {
		//	U.log(item);
			///String url = U.getSectionValue(item, "href=\"", "\"");
			String url = U.getSectionValue(item, "<a data-bind=\"attr: {href: Token}\" href=\"", "\"");
			//String url = U.getSectionValue(item, "href=\"", "\"");
			//
			if(!url.startsWith("http")) url = builderUrl + url;
			//System.out.println(url);
			totalCount++;
//			try{				
			//url = url.replace("neighborhoods", "new-homes").toLowerCase();
			String values[]=U.getValues(jsonData, "{\"Id\":\"communities", "\"CommunityPhoneNumber\":\"");
			for(String sect: values) {
				//U.log(sect);
				if(sect.contains(url.replace("https://www.davidweekleyhomes.com", ""))) {
					item += sect;
				}
			}
//			U.log(item);
			try {
				addNewDetails(url, item);
			} catch (Exception e) {} //=============================================
//			}catch(Exception e){}
			//U.log(url+":::::::::::::::new details url");
			communityCount++;
			k++;
			//break;
		}
		
	//	  U.log(totalCount);
	//	U.log("reCount"+k); U.log("Size: " + communityCount);
		 
	
		
	}
	
	//TODO : Extract Communities detail here
	private void addNewDetails(String comUrl, String communitySec) throws Exception {
//		try{
		{
//		if(!comUrl.equals("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/south-jordan/envision-at-daybreak"))return;
		//U.log(communitySec);
//			if(l>=100 && l<=200) 
//			if(l>=200)
//			if(l>=114)
			{
//			if(l>=0) {
		if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/dallas-ft-worth/arlington/sterling-green"))
		{
			LOGGER.AddCommunityUrl("Return ======="+comUrl);
			return;
		}
		
		//U.log(">>> Count : "+ l);
		U.log(l+":::"+"URL------->"+comUrl);

		String html = U.getHTML(comUrl);//U.getHtml(comUrl, driver);
       // U.log(U.getCache(comUrl));
		if (data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl("Repeat ======="+comUrl);
			l++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
//		if(comUrl != null) return;


		//======== commName ========
		String commName = U.getSectionValue(html, "<span class=\"current\">","</");
//		commName=commName.replaceAll("Cottages|Cottage", "");
		
		U.log("MM"+commName);
		if (commName == null)commName =U.getSectionValue(html, "<h1 class=\"title-01\">", "<");
		commName = commName.replace("’", "'").replace("&#39;", "'").replaceAll("\\?\\?\\?$", "'");
		commName=  commName.replace("Parkland Square/ Parkland Row 42'; Homesites", "Parkland Row 42' Homesites");
		commName = commName.toLowerCase().replace("by david weekley", "").replace(" – ", " - ");
		commName = commName.replaceAll("ΓÇÔ", "");
		commName = commName.replaceAll("<p>| 75’/ 90’", "").replace("quarter ???"	, "Quarter").replace("??? urban", "- urban").trim()
				.replaceAll(" - the$| villa homes$|executive homes$| townhomes$| paired homes$| manor$", "").trim().replaceAll("-$", "")
				.replace("???s", "'s").replace("??? the", "- the");
        commName = commName.replace("–", "-");
        commName = commName.replace("- cottage homes", "");
        commName = commName.replace("- flex row homes", "- flex homes, row homes");
		commName = commName.replaceAll("- the villas$", "");
		
	    
		U.log(commName+"::::::::::");
	    commName=commName.replaceAll(" - st. petersburg| - the cottages|- cottages|- courtyard homes|\\- garden homes|\\- city homes|\\- City Homes|\\-  gardens|\\- Estate Homes|\\- estate homes|\\-  villas|custom homes$|- villas|- gardens|traditional$|townhomes$|- paired homes$| -  homes$|-  series$| - garden series$|   series$","");
	    if(commName.endsWith("villas"))
	    	commName=commName.replace("villas", "");
		//U.log(commName);
		
		//============== address ==================
		String note = ALLOW_BLANK;
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		
		html = html.replace("<br />Suite ", "Suite ").replace("Place, NE", "Place NE").replace(", NE", "");
		String address1 = U.getSectionValue(html, "<div class=\"pure-u-xl-3-5 pure-u-lg-3-5 pure-u-md-3-5 pure-u-sm-1 pure-u-xs-1\">", "<span class=\"line phone\">");
		if(address1 == null) address1 = U.getSectionValue(html, "Address</h2>", "</span>");
		//U.log("::::"+address1);
		if(address1 != null)
			address1=address1.replaceAll("New Model Coming Soon|Please Call for an Appointment|Call for Appointment - |Call for Appointment|Please Call for Appointment|Please call for Appointment","");
		
		if(address1 != null){
			address1 = address1.replace("<span class=\"line\">", "").replace("</span>", "");
			address1 = address1.replace("<br />", ",").replace("North, Suite 160", "North Suite 160").replace(" 4100 W. Kennedy Blvd. ,Unit 116", " 4100 W. Kennedy Blvd Unit 116")
					.replace(",,", ",").replace(", Suite", " Suite").replace(", Unit", " Unit")
					.replaceAll(",Unit \\d,", ",").replaceAll("<.*?>", "");
		
			//U.log("Address Sec :"+address1);
			String adds[]=address1.split(",");
		//U.log(adds.length);
			if(adds.length >= 3){
				add[0]=adds[0].trim().replace("Suite", ",Suite");
				add[1]=adds[1].trim();
				//add[2]=Util.match(adds[2], "\\w+");
				add[2]=adds[2].replaceAll("\\d+", "");
				add[3]=Util.match(adds[2], "\\d+");
				
				
				add[0] = add[0].replaceAll("TBD|Model Coming Soon:|Model at: |Lot 38|To make an appointment please call 817.484.0069|Please call for Appointment", "");
				add[0] = add[0].replaceAll("..\\d+\\.\\d+\\.\\d+|No Model Office - Please call for an appointmen|To make an appointment please call|By Appointment Only| - No Model - For Appointment Please Call|Please call for appointment to schedule a showing","");
				add[0] = add[0].replaceAll("Cal for more information.|Cross Streets: ", "");
			}
		//	U.log("street:::"+add[0]);
			if(adds.length==2){
				add[1]=adds[0];
				add[2]=adds[1].replaceAll("\\d+", "");
				add[3]=Util.match(adds[1], "\\d+");
			}
			
			if (add[1].length() < 2) add[1] = ALLOW_BLANK;
			add[2] = add[2].replace("<br/>", "").trim();
			if(add[3] == null) add[3] = ALLOW_BLANK;
		}
		
		add[0 ]= add[0].replaceAll("No Model Office - Please call for an appointment|Please call for appointment to schedule a showing|By Appointment Only|Model Coming Soon - By Appointment Only|Model Coming Soon!|Please Call For Appointment To Schedule A Showing|Raleigh|Sales Center Now Open!|Visit Our New Home Center @|Model at:", 
				"");
		add[0] = add[0].replace("Visit our New Home Center @ ", "").replace(",", " ");
		add[0] = add[0].replaceAll("Model Coming Soon\\s?-?\\s?", "").replace("Central Living Sales Office - ", "").replace("- No Model - For Appointment Please Call","");
		add[0] = add[0].replaceAll(" -$", "");
		//https://www.davidweekleyhomes.com/new-homes/fl/tampa/st-petersburg/burlington-townhomes

		if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/tampa/st-petersburg/burlington-townhomes")) {
			//148-100 Bayshore Dr SE, St. Petersburg, FL 33701, USA
			add[0] = "148-100 Bayshore Dr SE";
			add[1] = "St. Petersburg";
			add[2] = "FL";
			add[3] = "33701";
		}
		if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/dallas-ft-worth/celina/mustang-lakes-classic-series")) {
			add[0]="2603 Seabiscuit Rd";
			add[1]="Celina";
			add[2]="TX";
			add[3]="75009";
			geo="True";
		}
  
		U.log("Street: " + add[0] + " City: " + add[1] + " State: "+ add[2] + " Zip :" + add[3]);
		
		//========== Lat-lng ========
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		
/*		lat = U.getSectionValue(html, "Latitude&quot;:", ",");
		lng = U.getSectionValue(html, "Longitude&quot;:", ",");
		

		U.log("Lat-lng :: "+lat + ", " +lng);
		
		if (lat != null)
			if (lat.contains("-")) {
				lat = lng;
				lng = lat;
			}
		if(lat == null) lat = lng = ALLOW_BLANK;
		
		String[] latLng = { lat, lng };

//		String latlngs[] = { ALLOW_BLANK, ALLOW_BLANK };
		if (lat.length() < 3) {
			String temp = U.getSectionValue(html, "data-center=\"{", "}");
			if (temp != null) {
				lat = U.getSectionValue(temp, "Latitude&quot;:", ",");
				lng = U.getSectionValue(temp, "Longitude&quot;:", ",");
				latLng[0] = lat;
				if(latLng[1].trim().length()>4&&!latLng[1].contains("-"))
					latLng[1]="-"+latLng[1];
				latLng[1] = lng;
				
				U.log("LAT::::::::::" + lat + "LONG::::::::::::::" + lng);
				if (lat.contains("-")) {
					latLng[0] = ALLOW_BLANK;
					latLng[1] = ALLOW_BLANK;

				}
			}
		}
*/		
		
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
		latLng[0] = U.getSectionValue(communitySec, "\"Latitude\":", ",");
		latLng[1] = U.getSectionValue(communitySec, "\"Longitude\":", ",");
		if(latLng[0]!=null)lat = latLng[0];
		if(latLng[1]!=null)lng = latLng[1];

		if(address1 !=null && add[3] == ALLOW_BLANK) {
			String cityState = U.getSectionValue(html, "<span class=\"location\">", "|");
			if(cityState == null ||cityState == "" ) {
				cityState = U.getSectionValue(html, "<span class=\"location\">", "<");
			}
			if(cityState == null)
				cityState = U.getSectionValue(html, "<div class=\"location\">", "|");
			if(cityState == null)
				cityState = U.getSectionValue(html, "<div class=\"location\">", "<");
			String citystateval[] = cityState.split(",");
			U.log(Arrays.toString(citystateval)+":::::"+citystateval[1]);
			add[1]=citystateval[0];
			add[2]= citystateval[1];
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null)
				latLng = U.getGoogleLatLngWithKey(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			geo="TRUE";
			//note = "Street Address And Lat-Long Taken From City & State";
		}
		if(lat == ALLOW_BLANK && add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK){ // &&  (add[3] != ALLOW_BLANK && add[3] != null)  //((add[0] != ALLOW_BLANK && add[0] != null) || add[3] != ALLOW_BLANK))
		
			String[] tempAdd = add;
			tempAdd[0]=tempAdd[0].replaceAll("#23|#", "");
			
			//latLng = U.getlatlongGoogleApi(tempAdd);
			latLng = U.getlatlongGoogleApi(add);
			if (latLng==null) latLng=U.getGoogleLatLngWithKey(tempAdd);
			if(latLng == null) latLng = U.getlatlongHereApi(tempAdd);
			if(latLng == null) latLng = U.getNewBingLatLong(tempAdd);
			lat = latLng[0];
			lng = latLng[1];
			geo = "True";
		}
		U.log("Lat-lng :: "+lat + ", " +lng);
		
		if (lat.trim() != ALLOW_BLANK && (add[0] == ALLOW_BLANK || add[0].trim().isEmpty())) {
			String adds[] = U.getAddressGoogleApi(latLng);
			if(adds == null) adds = U.getGoogleAddressWithKey(latLng);
			if(adds == null) adds = U.getAddressHereApi(latLng);
			
			add[0] = adds[0];
			if(add[3] == ALLOW_BLANK){
				add[3] = adds[3];
				note="Lat-Long Is Taken From City And State";
			}
			geo = "TRUE";
			U.log("Add ::"+Arrays.toString(add));
		}
	    if(lat == ALLOW_BLANK || lat.length()<2) {
	    	if(html.contains("https://maps.googleapis.com/maps/api/staticmap?")) {
	    		String latSec = U.getSectionValue(html, "https://maps.googleapis.com/maps/api/staticmap?center=", "&amp;zoom=");
	    		lat = latSec.split(",")[0];
	    		lng = latSec.split(",")[1];
	    	}
	    	if(add[0].length()<4 && lat.length()>3) {
	    		add = U.getAddressGoogleApi(new String[] {lat,lng});
	    		if(add == null) add = U.getGoogleAddressWithKey(latLng);
	    	}
	    }
	    
		String remoMeta=U.getSectionValue(html, " <meta name=\"description", "<meta property=");
		if(remoMeta!=null){
			html=html.replace(remoMeta, "");
		}
		
		//===================  Price============================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		ArrayList<String> priceList=Util.matchAll(html, "\\$\\s*\\d{3}s", 0);
	
/*		for(String s:priceList){
			html=html.replaceAll("\\$\\d{3}s", "\\$\\d{3},000");
		}
*/		html = convertMillon(html);
		
		
		
		
		
		//====================== Floorplans(6/8/18) ==========================
		String floorsHtml=null,dataSecfromFloor=null;
//		U.log(html);
		
		
		String floorPlans[] = U.getValues(html, "<h2 class=\"plan-title\"><a href=\"","\""); // "Make Appointment");
		U.log("Total Floor : " + floorPlans.length);
		
		int k=0;
		for(String floor:floorPlans){			
			//if(k++ == 4)break;
			//String linkSec=U.getSectionValue(floor, "plan-id", "</h3>");
			//U.log(linkSec);
			//floorsHtml=U.getHTML("https://www.davidweekleyhomes.com"+U.getSectionValue(linkSec, "href=\"", "\""));
			String floorUrl = builderUrl+floor;
			U.log("floorUrl : " +floorUrl);
			floorsHtml = U.getHTML(floorUrl);
			dataSecfromFloor+=U.getSectionValue(floorsHtml, " <div id=\"detail-section\" class=\"pure-g content\">", "Learn More</span>");
		}
		
		
		String flor = comUrl + "#floorplans";
		// U.log("" + U.getCache(flor));
		flor = U.getHTML(flor);
		//U.log("section::"+U.getSectionValue(thtml, "ute starting-price\">", " </div>"));
		String Quickmove = comUrl + "#showcases";
		Quickmove = U.getHTML(Quickmove);
		String head = U.getSectionValue(html, " <div class=\"pure-u-sm-1-2 pure-u-xs-1-2 attribute starting-price\">", " </div>");
		
//		if (head!=null) {
//			head = head.replaceAll("\\$\\d{3}s", "\\$ \\d{3},000").replace("s", ",000");
//		}
//		
		String nHtml = U.getHTML(comUrl);
		String priceSec=" ";
		priceSec = U.getSectionValue(nHtml, "class=\"att-label\">From the</div>", "</div>");
		
		if(priceSec!=null) 
			priceSec = priceSec.replace("0's", "0,000").replace("s", ",000").trim();
//		String Stringcombine = "";
	
       // if(priceSec==null) {
        	priceSec=priceSec+U.getSectionValue(html,"<div class=\"first-level-properties\">", "<div class=\"second-level-properties \">");
       // }
    	U.log("Is empty"+priceSec.isEmpty());
		html = html.replace("0's", "0,000").replace("0s", "0,000").trim()
				.replaceAll("From the</div>\\s+<div class=\"att-value\">", "From the ");
		html = html.replace("<div class=\"att-value\">$425s</div>", "<div class=\"att-value\">$425,000</div>").
				replaceAll("\\$(\\d{3})s</div>", "\\$$1,000</div>");

		String[] price = U.getPrices(priceSec + html+nHtml ,
						"\\$\\d{3},\\d{3}|From:\\s*\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|From the \\$\\s*\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$ \\d{3},\\d{3}|From the\\$\\d{3},\\d{3}",
						0);
		//U.log("PRICE"+Util.matchAll(html, "[\\w\\W\\s]{30}$532,990[\\w\\W\\s]{30}", 0));
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/san-antonio/san-antonio/the-bluffs-at-two-creeks"))
    	minPrice="$532990";

		U.log("Minprice: " + minPrice + "  " + "MaxPrice: " + maxPrice);

		if (maxPrice.equals(minPrice))maxPrice = ALLOW_BLANK;


	//	U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		
		
		
		
		
		//====================== Sqft ==========================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		/**
		 * @date 22 Dec 2018
		 */
		String comDetailSection = U.getSectionValue(html, "<div id=\"community-name-location-desktop\">", "<div class=\"community-tabs");
		if(comDetailSection == null)
			comDetailSection = U.getSectionValue(html, "<div id=\"community-name-location-desktop\">", "<div id=\"tabs\"");
		
		if(comDetailSection == null)
			comDetailSection = U.getSectionValue(html, "<div class=\"community-name ", "<div id=\"community-overview");
		
		String homeAndQuickSections[] = U.getValues(html, "plan-number\">","card-buttons\">"); // "<div class=\"plan-card-details\">", "<div class=\"mobile-listing");
		U.log("total sections in homeAndQuickSections"+homeAndQuickSections.length);
		String combinedSectionHomes = null;
		for(String sec : homeAndQuickSections) combinedSectionHomes += sec;
				
		
		//U.log(U.getSectionValue(html, "<div id=\"property-intro\">", "<div class=\"pure-g details community\">"));
//		U.log(Util.matchAll(flor, "[\\w*\\s*\\W*]coming summer[\\w*\\s*\\W*]",0));
		
		flor=flor.replaceAll("2172-|>2172", "");
		html=html.replaceAll("2172-|>2172", "");
		Quickmove=Quickmove.replaceAll("2172-|>2172", "");
//		FileUtil.writeAllText("/home/glady/filename.txt", html);
		//U.log("kkkkkkkk"+comDetailSection+"  "+combinedSectionHomes);
		String[] sqft = U
				.getSqareFeet(
						(comDetailSection+ combinedSectionHomes).replaceAll("-4078|-3216|- 3216|2024-4078|1722-4078", ""),
						"<div class=\"att-value\">\\d{4}-\\d{4}</div>|Sq.\\s* Ft:\\s* \\d{4}|\\d{1},\\d{3} � \\d{1},\\d{3}+ square feet|Sq Ft \\d{1},\\d{3} � \\d{1},\\d{3}|class=\"card-black\">Sq\\. Ft: \\d{4}( - \\d{4})?</h4>|class=\"sqft att-value\">\\d{4}(-\\d{4})</div>|Sq.Ft.</div>\\s+\\d{4}-\\d{4}|from \\d,\\d{3} to \\d,\\d{3} square feet|\\d+,\\d+ \\&ndash; \\d+,\\d+ square feet|Sq.Ft.</div>\\n*\\s*\\n*\\s*\\d{4}-\\d{4}|Sq. Ft.</div>\\n*\\s*<div class=\"value\">\\d{4} - \\d{4}|Sq. Ft.</div>\\n*\\s*<div class=\"value\">\\d{3,4}|Sq.Ft.</div>\\n*\\s*\\n*\\s*\\d{4}|\\d{4} \\&ndash; \\d{4} sq. ft. homes|\\d{4}-\\d{4} sq. ft.|\\d+,\\d+ to more than \\d+,\\d+ square feet|\\d+,\\d+ - \\d+,\\d+ square feet|\\d+,\\d+ to \\d+,\\d+ square feet|\\d{4} Sq. Ft.|\\d+ Sq. Ft.|\\d+ - \\d+ sq. ft.|\\d,\\d+ to \\d,\\d+ sq. ft.|between \\d,\\d+ and \\d,\\d+|\\d,\\d+ square feet|\\d{3}-\\d{4} sq. ft|\\d,\\d{3} sq. ft",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		
	if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/orlando/orlando/flora")) {
		minSqf="1952";
		maxSqf="2509";
	}
	if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/orlando/clermont/john-s-lake-landing-manor")) {
		minSqf="2625";
		maxSqf="3431";
	}
	if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/austin/hutto/carmel-creek")) {
		minSqf="1400";
		maxSqf="3000";
	}
	if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/san-antonio/san-antonio/the-bluffs-at-two-creeks"))
	{
		minSqf="2940";
	}	
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		
		
		
		
		//============= Property Type ==============
		//TODO : Property Types
		String dummyHtml = "";
		dummyHtml = U.getHTML(comUrl + "#floorplans");
		String hoahtml=U.getHTML(comUrl);
		String HOAs=hoahtml;
		html = html.replace("Custom Classics by David Weekley homes", "Custom Classics Homes by David Weekley homes");
		
		if(remoMeta!=null){
			dummyHtml=dummyHtml.replace(remoMeta, "");
			HOAs=HOAs.replace(remoMeta, "");
		}
		String title = U.getSectionValue(html, "<title>", "<");
		
		html=html.replace("Along with luxurious", "luxury homes").replaceAll("Paired &amp; Cottage homes", " Paired home Cottage homes")
				.replace("variety of Custom", "additional custom").replace("Traditional farmhouse- and prairie-style architecture", "modern farmhouse, Traditional exterior").replaceAll("all in a luxurious|Luxurious Central Living|Luxury, low-maintenance|Embrace a luxurious|discover luxurious,|number of these luxury|you can live a luxurious|Luxury, location and a home|luxurious comforts", "Luxury Home ");	
		
		html=html.replaceAll("avid weekley quick move-in|efficient homes are now available|Multifamily Utility|multifamilyutility|Multifamily Utility|Greenly-Villa|dwh-icons dwh-icon-hoa\"", "");
		
		dummyHtml=dummyHtml.replaceAll("luxurious floor plans available", "luxury homes")
				.replace("<h5 class=\"taxes-name\">HOA:</h5>", "<h3>HOA</h3>")
				.replaceAll("efficient homes are now available|Multifamily Utility|multifamilyutility|Multifamily Utility|Greenly-Villa|Villa Cour", "");
		
		dummyHtml=dummyHtml.replaceAll(
				"School - Opening Fall 2017|Villas Water Feature and Trail|Custom|custom|Village|village|Multifamily Utility|multifamilyutility|multifamily utility|Oak Park Villa|luxurious swimming",
				"");
		HOAs=HOAs.replaceAll("School - Opening Fall 2017|Multifamily Utility|Custom|custom|multifamilyutility|Multifamily Utility|village|Village|Greenly-Villa|Villa Cour|Oak Park Villa|luxurious swimming", "");
		HOAs=HOAs.replaceAll(
				"Villas Water Feature and Trail|Multi-Level.*?Warranty|Multifamily.*?Utility|multifamilyutility|multifamily utility"
				.toLowerCase(), "");
		//U.log("result::::"+Util.match(dummyHtml, ".*?Opening Fall 2017.*?"));
					
		String comDetailSec = U.getSectionValue(html, "details community\">", "</div>")+U.getSectionValue(html, "<h2>Overview</h2>", "</div>");
		//U.log(comDetailSec);
		if (comDetailSec!=null) {
			comDetailSec=comDetailSec.replace(" custom designed new homes", "custom homes")
					.replaceAll("Series and a variety of Custom Choices", "Custom designed plan").replace("traditional, craftsman", "traditional,Craftsman-style home").replace(" Carriage Series", " Carriage Home Series")
					.replace("Lifestyle Collection! Embrace luxurious, low-maintenance living while enjoying", "Lifestyle Collection! Embrace luxury homes , low-maintenance living while enjoying");
		}
		String rem = "CDD Fee for Cottage Series|CDD Fee for Garden Series|Bungalow Road|Winter Garden|The Farmhouse amenity center|ainside at Victory - Bungalow Series\" |multi-level bedroom plan, spacious|multi-level-warranty|Multi-Level Warranty|apartment?|apartments on your right|Shutters evokes coastal living|traditional at the same time|villanova|alt=\"HighGrove Villa|Caption\":\"(Our )?Executive |news/executive|craftsmanship of a Denver";		
		
		//TODO:
		if(dataSecfromFloor!=null)
			dataSecfromFloor = dataSecfromFloor.replaceAll("luxurious comfort of the deluxe|effortless luxury|luxurious Whitham family home", "luxury homes");

		String pType=U.getPropType((HOAs+dummyHtml+commName+comDetailSec.replace("Resort-style pool", "")+dataSecfromFloor+title+commName).replaceAll(rem, ""));
		
	
//		U.log("MMM "+Util.matchAll(comDetailSec, "[\\s\\w\\W]{30}Resort-style pool[\\s\\w\\W]{30}", 0));
//		FileUtil.writeAllText("/home/glady/filename.txt", HOAs+dummyHtml+commName+comDetailSec+dataSecfromFloor);
		
		U.log("pType:" + pType);
		
		if(pType.contains("Townhomes") && pType.contains("Townhouse"))
			pType = pType.replace(",Townhouse", "");
			
		
		
		
		
		//===========Community detail ==============
		String minP = U.getSectionValue(html, "refinement\">From the", "s");
		if (minP != null && minPrice == ALLOW_BLANK) {
			if (minP.contains("1464"))
				minP = "$1,464,000";
			else {
				minP = minP.trim() + ",000";
			}
			minPrice = minP;
		}

		
		
		
		//=============== Derived Community Type ====================
		html = html.replaceAll("Stories\\s*</div>\\s*<div class=\"value\">\\s*1 - 1.5", " 1 Story and 1.5 stories ");
		html = html.replaceAll("Stories\\s*</div>\\s*<div class=\"value\">\\s*2 - 3", " 2 Story and 3 stories ");
		html=html.replaceAll("Stories\\s*</div>\\s*<div class=\"value\">\\s*2", " 2 Story ");
		html=html.replaceAll("Stor[y|ies]\\s*</div>\\s*<div class=\"value\">\\s*1", " 1 Story ");
		html=html.replaceAll("Stories\\s*</div>\\s*<div class=\"value\">\\s*3", " 3 Stories ");
		html=html.replaceAll("\\n*\\s*</div>\\s*<div class=\"value\">\\s*", " ")
				.replaceAll("Stories\\s*</div>\\s*<div class=\"value\">\\s*1 - 2", " 1 Story and 2 Story ");
		
		dummyHtml = dummyHtml.replaceAll("multi-level-warranty|Multi-Level Warranty", "");
		html=html.replace("three- and four-story", " 3 story and 4 story ").replace("3- and 4-story", "3 story and 4 story ");
		html=html.replace("two- and three-story", "2 story and 3 story").replace("Two- and three-story", "2 story and 3 story");
		html=html.replace("1.5- and 2-story"," 1.5 story  2 story  ").replace("one- or two-story"," 1 Story 2 Story ");
		String s=ALLOW_BLANK;
		if(html.contains("ranch-style"))
		{
			s=" Ranch ";
		}
		
		String dType = U.getdCommType((((dummyHtml+html.replace("Several one- and one-and-a-half story floor plans to choose from", "Several 1 Story and one-and-a-half story floor plans to choose from").replace("two- or three-story", " 2 Story  3 Story ")+dataSecfromFloor).replaceAll("multi-level-warranty|this 2 story, 3 bedroom|multi-level-warranty|open-concept first floor living|Your first story presents|[f|F]*ishHawk\\s*[-]*\\s*[R|r]*anch|two-story fitness center|multi-level-warranty|Multi-level Warranty|Ranch Parkway|Ranch Rd|Oaks Ranch|Branch|branch|ranch\">Fair Oaks Ranch|multi-level.*?warranty|Multi-Level.*?Warranty|ranch|Ranch|RANCH", ""))
										+s+commName.replaceAll("[f|F]*ishHawk\\s*[-]*\\s*[R|r]*anch|branch","")).replaceAll("Colonialtown North|multi-level bedroom plan, spacious|multi-level-warranty", ""));
		U.log("dType::"+dType);
		//U.log("MMM "+Util.matchAll(dummyHtml+html+dataSecfromFloor+s+commName, "[\\s\\w\\W]{30}multi-level[\\s\\w\\W]{30}", 0));
		
		
		
		//================ Community Type ===========================
		//TODO : Community Type
		html = html.replace("Lakefront and conservation homesites", "lakefront home sites").replace("ultimate blend of luxury", "");
		String commtypeSec=U.getSectionValue(html, "<h1 class=\"title-01\">", "<div class=\"clear\">");
		if(commtypeSec==null)
			commtypeSec = ALLOW_BLANK;
		html = html.replace("<span class=\"amenity-name\">Waterfront Views</span>", "Waterfront Community")
				.replaceAll("living-in-tampa\"\\s*>\\s*Active Adult|Walnut Creek Country Club|Active Adult\"|page/active-adult|alt=\"Active Adult|rel=\"\">Active Adult|Country Club Road|Caption\":\"Active Adult|rel=\"\">Active Adult</a>|alt=\"Active Adult\">|Active Adult Living in Tampa|rel=\"\">\\W+Active Adult|/active-adult|Westlake|Towne Lake", "");
	
	
		html=html.replace("<li class=\"active\">Master Planned ", "masterfully-planned community").replace("Active Adult\n" + 
				"            </a>", "");
		//U.log("result::"+Util.match(html, ".*?ranch.*?"));
		String Type = U.getCommunityType(html.replace("new homes in this active 55+ adult", "new homes in this ages 55+ Active Adult Community").replaceAll("Golf Course within \\d miles|Nearby soccer complex and golf courses|Ballantyne Country Club</li>|active\">Golf Course within|alt=\" - Lake Living|alt=\"towne lake - lake living|class=\"active\">Master|master_planned active\">|Country Club D|Country ClubDr", ""));
//		U.log("MMMMMMMMMM result::"+Util.matchAll(html, "[\\w\\s\\W]{30}active 55+[\\w\\s\\W]{30}",0));

		
		// ================= Property Status =====================
		//TODO : Property Status
		String status = ALLOW_BLANK;
		
		html = html.replace("new section is now open", "new section now open")
				.replaceAll("\"New Phase Coming Soon\"|coming soon to a new phase of Lakes of River Trails|new phase of David Weekley homes are coming soon", "new phase coming soon").replace("David Weekley homes are now selling", "David Weekley now selling").replace("Now selling 56 homesites in Phase 2,", "Now selling Phase 2,");
		
	
		String remove = "foot homesites now|school coming soon|IsComingSoon|schedule-tour-form-header\">New Opportunities Coming Soon|Coming Soon!\"|coming this summer to the Highland Park|ime with a Quick Move-in Home |>\\s*Final Opportunities Remain in Charlotte!\\s*</a>|limited opportunities remaining in several Charlotte|adults is now available|are now available from David Weekley Home|Now available on 34-foot|School - Opening 2017|School - Opening Fall 2017| map of our available homesites|sarasota/close-ou|320\\)\" title=\"Now Selling\">|estate homesites available|on floor plans, available homesites|images/CLOSE OUT|images/CLOSE OUT|coming-soon|title=\"Now Selling\">Now Selling</a>|Final Opportunity - The Gunner|is actively selling|2012|2013|2011|School now open|close-out\"|Close-Out Communities|\\Close-Out|Section Close Out|Westcott, is now open|\\(now open\\)|\\(coming soon\\)|new homesites now available!</li>|See Quick";
		html = html.toLowerCase().replaceAll(remove.toLowerCase(), "");
		
		html = html.replaceAll("/new-homes/ga/atlanta/coming-soon|new, move-in ready home|Coming Soon\">Coming Soon<", ""); ///alt=\\\"final opportunities\".toLowerCase()

		html=html.replace("src=\"/_images/closeout.png\" alt=\"Close-out\">","Close Out");
		html = html.replaceAll("number of move-in ready |few opportunities remain in golf|close on a move-in ready|exceptional move-in ready|weekley homes is now available| needs are now available in wol|weekley are now available in|foot homesites now available in|park series homesites now available|is now selling two showcase homes|nd all new floor plans available|alt=\"now selling\"|winning david weekley homes are now available in|special incentives when you purchase a move-in ready|homes are now available in the heights|one of the few opportunities to own in|elementary opening on site fall|grand opening|opening in 2017|Grand Opening|Grand Opening!\">Grand Opening!</a>|center</a> coming", "");
		html=html
				.replaceAll("entertainment coming soon to|playground coming soon|,\"caption\":\"quick|a new Quick Move-in Home in the|\"Caption\":\"Quick Move In\"|program is now available|pad coming summer 2019|always wanted is now available|now available in mueller|now available in griffin|choose one of our beautiful[,]* quick move-in homes|move-in ready or ready soon homes|homes are now available|Elementary opening on site fall |limited homesites with wetland|Limited homesites with wetland views |000 homes sold|grand-opening|winning homes are now|Center</a> coming summer","")
				.replace("new phase of homes is coming this summer", "new phase coming this summer").replace("homes are now available", "homes now available")
				.replaceAll("coming this summer to the Highland Park|45-foot homesites are now available|time with move-in ready homes from |#showcases\">Quick Move-Ins (1)|img alt=\"Quick Move|showcases\">View Quick Move-Ins|img alt=\"quick move-ins|cases\">[V|v]iew [Q|q]uick [M|m]ove-[I|i]ns|top\">[Q|q]uick [M|m]ove-[I|i]ns|cases\">[Q|q]uick [M|m]ove-[I|i]ns|david weekley quick move-in homes|center coming spring|see move-in tab|trails are now|a new quick move-in home in|move-in homes! experience", "")
				.replaceAll("[Q|q]uick [M|m]ove|now available from David|cabana coming| Homes Coming|foot homesites now|selling from pioneer|floor plans are now|incentives on quick move|alt=\"Coming|images/closeout|- now open!|alt=\"towne lake - lake living|/coming-soon|ollection - coming soon|collection coming soon|Collection Coming Soon\\s*|david weekley homes are now selling in the|ready-soon\" >quick move|ready-soon\">\n*\\s*quick move|alt=\"quick move|east shore landing - coming soon|alt=\"coming soon|images/comingsoon|coming soon to east shore landing|alt=\"east shore landing - coming|caption\":\"quick move|menu_quickmovein|coming soon to grand central|houston/coming|district coming soon|District Coming Soon|austin/coming-soon|island parkway is now open|Parkway is now open to|<span>coming soon</span>|elementary school coming soon</|title=\"coming soon\"|title=\"Coming Soon\"|selling from liberty cove model|incentives with a quick move|<i class=\"dwh-icons dwh-icon-hoa\"></i> <span class=\"amenity-name\">Home Owners Association", "")
				.replace(" now building in a new section", " now building new section").replace("Brightwalk - Now Selling!","");
	
		//U.log(communitySec);
		communitySec = U.getSectionValue(communitySec, "<span class=\"label", "</span>");
		U.log("Communiy Sec: " + communitySec);
		
		if(communitySec!=null)
			communitySec = communitySec.replaceAll("\"[c|C]oming|[Q|q]uick [M|m]ove","");
		
		comDetailSec=comDetailSec.replace("A new phase of David Weekley homes is now available", "A new phase now available")
				.replace("New homes from Encore by David Weekley Homes are now available", "New homes now available")
				.replace("new phase of homesites is now available", "new phase homesites now available")
				.replace(" final phase of award-winning David Weekley homes is now selling","final phase now selling").replace("new phase of homes is coming this summer", "new phase coming this summer").replace("new phase of our award-winning homes is coming soon", "new phase coming soon").replace("homes will be coming in 2022", "New Phase Coming 2022").replace("new phase of single-family homes in Persimmon Park � Cottage Series for release in early 2022", "new phase release").replace("new phase of homes will be coming in fall 2021", "new phase coming fall 2021").replace("new phase of homes is coming this summer", "new phase coming this summer")
				.replace("new phase of homesites is coming soon", "new phase homesites coming soon").replace("New homes are now available", "New homes now available")
				.replace("homes are now available", "homes now available")
				.replaceAll("features move-in ready|\"[c|C]oming|[Q|q]uick [M|m]ove|now available from David|Final Opportunties\"|watercourse coming|school coming|cabana coming| Homes Coming|New Phase Coming\"|Weekley homes are now|foot homesites now", "");
		//U.log("ZZZZZ"+Util.matchAll(comDetailSec, "[\\w\\W\\s]{3}New Homes Quick Move-in[\\w\\W\\s]",0));		
		status = U.getPropStatus(comDetailSec+communitySec+html.replaceAll("features move-in ready|title=\"Coming|[S|s]oon\"|<div class=\"schedule-tour-form-right\">.*</form>|\"[c|C]oming|school coming soon|[N|n]ew [P|p]hase [C|c]oming\"|[Q|q]uick [M|m]ove|[n|N]ew [s|S]ection [c|C]oming [s|S]oon\\s*\"|selling out of [h|H]armony|[q|Q]uick [m|M]ove-ins, please|[n|N]ow [s|S]elling\\s*\"|options now available|coming soon\\s*\"|<address>coming soon</address>|coming soon\"|Coming Soon\"|and the coming soon|<address>Coming Soon</address>|New amenity center now open|on a Quick Move-in|watercourse coming|Quick Move-in Home| is now available from david we|homes are coming|or sales in the master", ""));
		//status = U.getPropStatus(communitySec);
		
//		U.log("MMMMMMMMMM result::"+Util.matchAll(comDetailSec+communitySec+html, "[\\w\\s\\W]{30}Only a few opportunities remain[\\w\\s\\W]{30}",0));
		
//		U.log("herere");
		status = status.replace("Closeout", "Close Out");
		status=status.replace("LakeView And LakeFront Homesites Avaialble","");
		
		
//		if(status.contains("Quick Move-in") && status.contains("Homes Now Available"))
//			status = status.replace(", Homes Now Available", "");
		
		html = U.getHTML(comUrl);

		if (html.contains("images/comingsoon.png") && !status.contains("Coming Soon")) {
			if (status.length() < 3)status = "Coming Soon"; //&& !status.contains(ALLOW_BLANK)
			else status = status + ", Coming Soon";
		}
		if (html.contains("_images/closeout.png\" alt=\"Close-out\" />")) {//&& !status.contains("Close")) 
			if (status.length() < 3)status = "Close Out"; //&& !status.contains(ALLOW_BLANK)
			else status = status + ", Close Out";
		}
		if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/orlando/clermont/john-s-lake-landing-cottage"))
			status=status.replace("Coming Soon","New phase Coming soon");
//		status = status.replace("-,", "");
		U.log("status here : " + status);

		String[] dateValue = U.getValues(html, "<span class=\"label image-tag\">", "</span>");
		
		int dateCount = 0;
		for(String date : dateValue) {
			if(date!=null && date.contains("Ready")) {
				String d = Util.match(date, "Ready \\d");
				if(Integer.parseInt(d.replace("Ready", "").trim())>4)// 4 is month
					dateCount++;
			}
		}
		
		String quickData[]  = U.getValues(html, "<a href=\"/homes-ready-soon/", "\"");
		
		HashSet<String> val  = new HashSet<>();
		for(String quick : quickData)
			val.add(quick);
		
	//	U.log("Quick Over Date Count: "+val.size()+"\t"+dateCount);
		
		if ((html.contains("<a href=\"#showcases\">Quick Move-Ins")||html.contains("<a href=\"#showcases\">Quick Move-ins") || html.contains("<h1 class=\"home-tours-title\">Quick Move-ins"))&&!status.contains("Quick")) {
			status=status.replaceAll(", Move-in Ready Homes|Quick Move-in Home|Move-in Ready Homes|, Move-in Ready|Move-in Ready,|Move-in Ready","");
//			status=status.replaceAll(", Only A Few Opportunities Remain|Only A Few Opportunities Remain","");
			U.log("status here : " + status);
			if(val.size()>0)//dateCount
			if (status.length() < 3)
				status = "Quick Move-in";
			else
				status = status + ", Quick Move-in";
		}
		status=status.replace("Quick Move-in Home", "");
		if(status.length()<3){
			status=ALLOW_BLANK;
		}
	
		status=status.replaceAll("Iii","III");
	    if(html.contains("/media/CommunityImage/a0d18df7-4b97-4c6e-a0cb-903ce530840d.jpg") ){//&& !status.contains("Now Selling")
	    	if(status.length()<2) status = "Now Selling";
	    	else status=status + ", Now Selling";
	    }
	    if((html.contains("/media/CommunityImage/28e88038-f7b4-46e0-9fc6-ee690a5bb03d.jpg") || html.contains("- Final Opportunties\"")) && !status.contains("Final Opportunities")){
	    	if(status.length()<2) status = "Final Opportunities";
	    	else status=status + ", Final Opportunities";
	    }
	   
	    if(commName.contains("- flex homes, row homes")) {
	    	commName = commName.replace("- flex homes, row homes", "");
	    if(commName.contains("Parkland Square/ Parkland Row 42' homesites"))
	    	commName=commName.replace("Parkland Square/ ", "");
	    	
	    	if(!pType.contains("Row Homes"))
	    	pType = pType+", Row Homes";
	    }
	    if(commName.contains(" row homes")) {
	    	commName = commName.replace(" row homes", "");
	    	
	    	if(!pType.contains("Row Homes"))
	    	pType = pType+", Row Homes";
	    }
	    
	    //From Image
	    if((comUrl.contains("/new-homes/ga/atlanta/suwanee/the-reserve-at-old-atlanta") || comUrl.contains("/new-homes/fl/tampa/odessa/asturia-lake-series")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/mn/minneapolis-st-paul/orono/orono-preserve")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/conroe/grand-central-park-50")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/austin/kyle/cypress-forest-lifestyle-collection")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ga/atlanta/smyrna/village-of-belmont-cottages")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/houston/ashford-manor")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/dallas-ft-worth/argyle/harvest-townside")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/jacksonville/jacksonville/hampton-west")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/or/portland/hillsboro/reed-s-crossing-the-classics-series"))
	    		&& !status.contains("Final Opportunities")){
	    	if(status.length()<2) status = "Final Opportunities";
	    	else status=status + ", Final Opportunities";
	    }
	    
	  //From Image
	    if((comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/lehi/holbrook-farms-the-cottages") 
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/lehi/holbrook-farms-the-villas")
	    		|| comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/lehi/holbrook-farms-the-cottages"))
	    		&& !status.contains("Sold Out")){
	    	if(status.length()<2) status = "Sold Out";
	    	else status=status + ", Sold Out";
	    }
	    
	  //From Image
	   

	    //From Image
//	    if((comUrl.contains("/new-homes/ga/atlanta/sandy-springs/ellison-park") || comUrl.contains("/new-homes/ga/atlanta/flowery-branch/the-retreat-in-sterling-on-the-lake")
//	    		 || comUrl.contains("/new-homes/tx/dallas-ft-worth/flower-mound/magnolia-court"))
//	    		&& !status.contains("Coming Soon")){
//	    	if(status.length()<2) status = "Coming Soon";
//	    	else status=status + ", Coming Soon";
//	    }
	    
	    
	    

	    
	    if((comUrl.contains("/new-homes/tx/austin/austin/central-living-lifestyle-collection"))
	    		&& !status.contains("Now Selling")){
	    	if(status.length()<2) status = "Now Selling";
	    	else status=status + ", Now Selling";
	    }
	    
//	    if(comUrl.contains("/austin/austin/suburban-build-on-your-lot-executive-collection") ||comUrl.contains("/austin/austin/suburban-build-on-your-lot-lifestyle-collection")||comUrl.contains("/austin/austin/urban-build-on-your-lot-urban-collection"))add[1] ="Winters";
	    //if(comUrl.contains("chapel-hill/encore-at-briar-chapel-tradition-series"))status ="Phase 2 Now Selling";
	    if(commName.contains("estates series") && !pType.contains("Estate"))pType = pType+", Estate-Style Homes";
	    //
	    

	    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/az/phoenix/mesa/cadence-at-gateway-the-commons")) {
	    	add[0] = "W Main St";geo="TRUE";
	    	latLng=U.getlatlongGoogleApi(add);
	    	geo="TRUE";
	    }
	    //https://www.davidweekleyhomes.com/new-homes/az/phoenix/mesa/eastmark-voyage

//	    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/az/phoenix/mesa/eastmark-voyage")) {
//	    	add[0] = "W Main St";
//	    	latLng=U.getlatlongGoogleApi(add);
//	    	geo="TRUE";
//	    }
	    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/dallas-ft-worth/fort-worth/meadowbrook-park")) {
	    	
	    	add[0]="401 Commerce St";
	   	 add[1]="Fort Worth";
	   	 add[2]="TX";
	   			add[3]= "76008";
	   	 latLng=U.getlatlongGoogleApi(add);
	   	 
	   	 geo="TRUE";
	
	    	
	    }
	    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/co/denver/denver/central-park-willow-park-east-cottages"))
 {
	    	add[0]="1451 Bannock St";
	    	geo="TRUE";

	   	 
	    }
	    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/dallas-ft-worth/fort-worth/meadowbrook-park"))
	    {
	    	//70 --> ,3319 Bristol Rd, Fort Worth, TX 76107, USA
	   	    	add[0]="3319 Bristol Rd";
	   	    	add[1]="Fort Worth";
		    	add[2]="TX";
		    	//add=U.getAddressGoogleApi(latLng);
		    	//latLng=U.getlatlongGoogleApi(add);
		    	latLng[0]="32.7554834";
		    	latLng[1]="-97.365871";
	   	    	geo="TRUE";

	   	   	 
	   	    }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/co/denver/denver/central-park-willow-park-east-paired-homes"))
 {
	    	add[0]="1451 Bannock St";
	    	latLng=U.getlatlongGoogleApi(add);
	    	geo="TRUE";
	   	 
	    }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/co/denver/denver/central-park-southend-row-homes"))
 {
	    	add[0]="1451 Bannock St";
	    	latLng=U.getlatlongGoogleApi(add);
	    	geo="TRUE";  	 
	    }
// if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/tampa/dunedin/central-living-pinellas")) {
//	 add[0]="San Mateo Dr";
//	 
//	 latLng=U.getlatlongGoogleApi(add);
//	 
//	 geo="TRUE";
//	 }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/dallas-ft-worth/fort-worth/walsh-gardens")) {
	add[0]="401 Commerce St";
	 add[1]="Fort Worth";
	 add[2]="TX";
			add[3]= "76008";
	 latLng=U.getlatlongGoogleApi(add);
	 
	 geo="TRUE";
	 }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/richmond/veranda-40")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/montgomery/woodforest-creek-view-42")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/montgomery/woodforest-creek-view-50"))
 {
	 status=status.replaceAll(", Now Open|Now Open","");
 }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/or/portland/tigard/ridgecrest"))
 {
	 status=status.replaceAll("Coming Soon,","");
 }

 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/katy/cane-island-50")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/katy/cane-island-quail-park"))
	 status=status.replaceAll(",", "");
// if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/katy/cane-island-50")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/katy/cane-island-quail-park")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/or/portland/hillsboro/reed-s-crossing-the-garden-series"))
//	    status=status.replaceAll("Coming Soon|, Coming Soon", "");
if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/az/phoenix/buckeye/victory-at-verrado")) {
	status += ", Now Selling";
}
 if( comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/austin/dripping-springs/headwaters")) {
	 minPrice="$367,000";
	 maxPrice="$432,990";
 }
// if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/in/indianapolis/westfield/lakes-of-shady-nook"))
// {
//
//	 status = "LakeView And LakeFront Homesites Avaialble";
////	 status=status.replace("-","");
// }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/orlando/winter-garden/oakland-park-cottage-homes"))
 {
	 pType=pType.replace(", Garden Home", "");
 }
// if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/fl/tampa/land-o-lakes/bexley-village-series")) {
//	 status = "New phase release";
//status=status.replace("-","");	 
// }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/salt-lake-city/the-cottages-at-ridgeview")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/salt-lake-city/paired-villas-at-ridgeview")||comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/salt-lake-city/the-carriages-at-ridgeview")) {
	 add[0]="395 S Main St";
	 add[1]="Salt Lake City";
	 add[2]="UT";
	 add[3]="84111";
 }
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tn/nashville/nolensville/annecy-cottages")) {
	 add[0]="Sam Donald Rd";
 }
 status = status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
 if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tn/nashville/nolensville/the-enclave-at-dove-lake-the-steeplechase-collection"))status="Now Selling";
 if(comUrl.contains("https://www.perryhomes.com/new-homes-dallas/parks-at-legacy/332/"))
	 pType=pType.replace(", Homeowner Association","");
	    add[1] = add[1].replace("&#39;", "");
	    add[0] = add[0].replace("to 831", "831");
	    add[0] = add[0].replace(" @ Zack St", "");
	    
	    if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/houston/houston/somerset-green")) {
	   	 lat="18.8154265";
	   	 lng="-76.7751434";
	    }  
	  // if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/nc/charlotte/indian-land/ansley-park"))status="Now Selling";
	  if(status==null || status.length()==0)status=ALLOW_BLANK;
//	  else
//		  status = status.replaceAll("Now Available,|Now Available", "");
//	  
	  if(status==null || status.length()==0)status=ALLOW_BLANK;
	   if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/sc/charleston/charleston/charleston-build-on-your-lot-executive-collection"))add[0]="498 Wando Park Blvd"; 
	

	   
	   status=status
			 .replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, New Phase, Coming Soon", "New Phase Coming Soon").replace("Final Opportunties, Limited Opportunities Remain, Close Out, Quick Move-in, Final Opportunities", "Final Opportunties, Limited Opportunities Remain, Close Out, Quick Move-in")
			   .replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
	   
	   if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/sc/charleston/charleston/point-hope-cottage-collection")||
			   comUrl.contains("https://www.davidweekleyhomes.com/new-homes/sc/charleston/charleston/point-hope-park-collection"))status="New Opportunities Coming Soon";
	  
	   if(comUrl.contains("persimmon-park"))
		   if(status==ALLOW_BLANK)status="New Phase Release Early 2022";
		   else
			  status += ", New Phase Release Early 2022";
	 note=U.getnote(html.replace("Verrado Highlands - Signature Series - Now Preselling", ""));
//		U.log(">>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{50}selling[\\w\\s\\W]{30}", 0));

	if(note!=null||note!=ALLOW_BLANK)		 note=note.replace("Now Pre-selling, Now Preselling", "Now Pre-selling");

	

	
	if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/tx/austin/austin/mueller")||
			comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/south-jordan/ascent-at-daybreak"))status ="Now Selling";
	
	status=status.replace("Coming 2022, New Phase Coming 2022", "New Phase Coming 2022")
			.replaceAll("Coming Summer 2019,|, Coming Summer 2019", "");
	
	
	if(comUrl.contains("https://www.davidweekleyhomes.com/new-homes/ut/salt-lake-city/cedar-hills/cedar-canyon"))
	status=status+", Final Opportunities";// from img
	
	
	
	if(comUrl.contains("ut/salt-lake-city/south-jordan/envision-at-daybreak"))
		status="Now Selling";// from img
	
	
	
		data.addCommunity(commName, comUrl, Type);
		data.addAddress(add[0].replace("6 Offices Across Dallas", "6200 Randol Mill Rd"), add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status.replace("Final Phase Now Selling, New Phase, Final Phase, Now Selling", "Final Phase Now Selling").replace("New Phase Coming This Summer, Coming Soon", "New Phase Coming This Summer").replace("Final Opportunities Remain, Final Opportunities", "Final Opportunities Remain").replace("New Phase Homesites Coming Soon, Coming Soon", "New Phase Homesites Coming Soon").replace("Ii", "II").replace("New Phase Coming 2022, New Phase, Coming Soon", "New Phase Coming 2022"));
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
		
		}
		}
		l++;
//		}catch (Exception e) {}

	}
	
	private String convertMillon(String html){
		Matcher mat = Pattern.compile("\\$\\d\\.\\d+ Million",Pattern.CASE_INSENSITIVE).matcher(html);
		while(mat.find()){
		    
		    String val1 = Util.match( mat.group(), "\\$\\d\\.");
		    val1 = val1.replace(".", "");

		    String val2 = Util.match( mat.group(), "\\.\\d+");
		    val2 = val2.replace(".", ",");
		    if(val2.length() == 3) val2 = val2+"0,000";
		    if(val2.length() == 2) val2 = val2+"00,000";
		    String val = val1+val2;
		    html = html.replace(mat.group(), val);
		}
		Matcher mat2 = Pattern.compile("\\$\\d+ Million",Pattern.CASE_INSENSITIVE).matcher(html); // $1 Million
		while(mat2.find()){
		    
		    String value = Util.match( mat2.group(), "\\$\\d+ M");
		    value = value.replace(" M", ",000,000");
		    
		    html = html.replace(mat2.group(), value);
		}
		return html;
	}
}
