/**
 * @Author:sanket
 * @Date:15/3/2012
 */
package com.shatam.b_021_040;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHighLandHomes extends AbstractScrapper {
	public int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int duplicates = 0;
	ArrayList<String> comm = new ArrayList<String>();
	WebDriver driver = null;
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractHighLandHomes();
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Highland Homes.csv", a.data()
				.printAll());
		U.log(duplicates);
	}

	public ExtractHighLandHomes() throws Exception {

		super("Highland Homes", "https://www.highlandhomes.com");
		LOGGER = new CommunityLogger("Highland Homes");
	}

	public void innerProcess() throws Exception {
	
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String[] region = { "austin", "dfw", "houston", "san-antonio" };
		// https://www.highlandhomes.com/dfw/

		for (int j = 0; j < region.length; j++) {
			
//			String html = U.getPageSource("https://www.highlandhomes.com/" + region[j]);
			String html = U.getHtml("https://www.highlandhomes.com/" + region[j], driver);
//			if(region[j].equals("houston"))
			{
				U.log("https://www.highlandhomes.com/" + region[j]);
				String [] comSections = U.getValues(html, "<div class=\"community-name\">", "</div></div></div>");
				//U.log(comSections.length);
				int totalCount = 0;
				for(String comSec : comSections){
				//	U.log(comSec);
					String statusSec = U.getSectionValue(comSec, "span class=\"sidenote\"", "<div");
					comSec = comSec.replace("</span></a>", "</a>");
					String comName = U.getSectionValue(comSec, "font-weight: bold;\">", "</span>");
//					U.log(comName);
					String[] subComSections = U.getValues(comSec, "<a href=", "</span>");
//					U.log(subComSections.length);
					for(int k = 1; k < subComSections.length; k++){
						String comUrl = U.getSectionValue(subComSections[k], "\"", "\"");
						//U.log(comUrl);
						//if(!comUrl.contains("http")){
							addDetail("https://www.highlandhomes.com" + comUrl, subComSections[0]+"\n"+subComSections[k]+"\n"+statusSec, driver);
						//}
							
						totalCount++;
					}
	}
				/*String [] comSections = U.getValues(html, "<div class=\"community-name", "</div></div></div>");
				int totalCount=0;
				U.log("Main Communities Count : "+comSections.length);
				for (String comSec : comSections) {
					//U.log(comSec);
					if(comSec.contains("<span>All Homes</span>")){
						//addDetail("https://www.highlandhomes.com"+U.getSectionValue(comSec, "<a href=\"", "\""), comSec, driver);
						totalCount++;
					}
					else{
						String subRegionUrl = "https://www.highlandhomes.com" + U.getSectionValue(comSec, "<a href=\"", "\"");
						U.log("subRegionUrl : "+subRegionUrl);
						
					}
					
					//break;
				}*/
				U.log(totalCount);
			}

			//U.log(i);
			inr = 0;

		}
		
		
		
		LOGGER.DisposeLogger();
		driver.close();
		try{
			driver.quit();
		}catch(Exception e){}
		U.log(i);
	}

	private void addDetail(String url, String comminfo, WebDriver driver) throws Exception {

		//if(!url.contains("https://www.highlandhomes.com/houston/richmond/veranda"))return;
		if (data.communityUrlExists(url))
		{
			LOGGER.AddCommunityUrl(url + "--------REPEATED-------");
			return;
		}
		if(url.contains("www.huntingtonhomestx.com")){
			LOGGER.AddCommunityUrl(url + "-------- Redirected to huntingtonhomestx -------");
			return;
		}
		LOGGER.AddCommunityUrl(url);

		
		String html1 = ALLOW_BLANK;
		//url = url.replace("/section/explore", "").replace("/explore", "");
		U.log("url : "+url);
		html1 = U.getHtml(url, driver);//U.getHtml(url, driver);
		
		//----remove footer section-----
		html1 = U.removeSectionValue(html1,"<footer class=\"cf\">", "</html>");
		U.log(comminfo);
		// comminfo = comminfo.replace(oldChar, newChar)
		U.log(comminfo+"\nPAGE :" + url);
		U.log(U.getCache(url));
		if (html1.contains("<h2>Page Not Found</h2>")) {
			duplicates++;
			LOGGER.AddCommunityUrl(url+"::::::::::::::::::404 Error:::::::::");
			return;
		}
		
		//------------CommunityName------
		String communityName = U.getSectionValue(html1, "<h1><strong>", "</strong></h1>");
		communityName = communityName.replaceAll("<span class=\"comingSoon\">Coming Soon</span>|<span class=\"comingsoon\">coming soon</span>", "");
//		U.log(communityName);
		communityName = communityName.toLowerCase().replaceAll("highlands at|- estate sized homesites|Explore|explore", "");
		
		communityName=communityName.replaceAll(":", "");
		// address
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		
		
		String addressSec = U.getNoHtml(U.formatAddress(U.getSectionValue(html1, "<p class=\"secondLine\">", "</p>")));
		U.log(addressSec);
		if(addressSec!=null){
			add = U.getAddress(addressSec);
		}
		U.log(Arrays.toString(add));
		if(add[0]==null)add[0]=ALLOW_BLANK;
			add[0] = add[0].replaceAll("Model -|Creekwood Model:|Cinco Ranch Model -", "");
		// Price

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String minsqft = ALLOW_BLANK, maxsqft = ALLOW_BLANK;
		comminfo = comminfo.replace("0s", "0,000")
				.replace("lowPrice\":", "lowPrice\":\\$")
							;
//		comminfo = comminfo.replace("highPrice\":", "highPrice\":\\$");

		String price[] = U.getPrices(html1+comminfo, "\\$\\d{3}(,)*\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

		

		String sqft[] = U.getSqareFeet( html1,
				"\\d{4} to \\d{4} sqft|\\d{4}-\\d{4} square feet|square footages up to \\d{4} square feet|\\>\\d,\\d+\\<|from \\d+,\\d{3}\\-\\d+,\\d{3} square", 0);
		minsqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxsqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		//U.log(minsqft);

		// lat and lang
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;

		// property Type

		
		//--------pType------------
		String pType = ALLOW_BLANK;		
		pType = U.getPropType(html1.replace("with a cabin and fishing dock", ""));
		
		
		//-------Derived_Type-------------
		String derivedPType = ALLOW_BLANK;
		html1 = html1.replace("</span><span class=\"label\">stories", " Stories");
		derivedPType=U.getdCommType(communityName+url+html1);
		
		//-------Address--------------
		String geo = "FALSE";
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latlNgSec = U.getSectionValue(html1, " <a href=\"https://maps.google.com/maps?q=loc:", "(");
		if( latlNgSec!=null){
				latLng = latlNgSec.split(",");
				lat=latLng[0];
				lng=latLng[1];
				if(lng.contains("target")){
					lng = lng.substring(0, lng.indexOf("\""));
				}
		}else {
		lat = U.getSectionValue(comminfo, "lat\":\"", "\"");
		lng = U.getSectionValue(comminfo, "lon\":\"", "\"");
		}
		if (add[0].length() < 3) {
			latLng[0] = lat.trim();
			latLng[1] = lng.trim();
			U.log("latLng size:: "+latLng.length+":::"+latLng[0]+"::::"+latLng[1]);
			String[] lati={latLng[0],latLng[1]};
			try{
			String adds[] = U.getAddressGoogleApi(lati);
			//String adds[] = adds=U.getBingAddress(latLng[0],latLng[1]);
			if(adds[3].length()<4)
				adds=U.getBingAddress(latLng[0],latLng[1]);
			add[0] = adds[0];add[1]=adds[1];add[2]=adds[2];add[3]=adds[3];
			}catch (Exception e) {
				// TODO: handle exception
			}
			geo = "TRUE";
		}
		if (communityName.contains("The Ranch At Brushy Creek")) {
			add[0] = "102 N Frontier Ln";
			add[1] = "Cedar Park";

		}
		if (add[0].length() > 100)
			add[0] = ALLOW_BLANK;

		add[0] = add[0].replace(
				"(pre-selling from Heatherwood in McKinney, TX), -", "");
		add[1] = add[1]
				.replaceAll(
						"parks and a resort-style pool. Stay tuned for more details on this upcoming community!|dining and entertainment is just minutes away! Stay tuned for more information on this exciting new development!",
						ALLOW_BLANK);
		if (add[2] == null)
			add[2] = ALLOW_BLANK;
		add[0] = add[0].replace("Coming Soon!", ALLOW_BLANK);
		add[0] = add[0].replace("By Appointment Only", ALLOW_BLANK);
		add[0] = add[0].replace("Selling From Our Creekside Park Model:", "");
		add[1] = add[1].replace("coming this Summer!", ALLOW_BLANK);
		if (maxPrice.contains("null"))
			maxPrice = ALLOW_BLANK;

		add[0] = add[0].toLowerCase().replace("sales office: ", "");
		add[2]=add[2].replaceAll("Texas|texas", "TX");
		
		if(add[0]==ALLOW_BLANK || add[0].length()<4)
		{
			String laton[]={lat,lng};
			add=U.getAddressGoogleApi(laton);
			/*if(add == null)
				add = U.getAddressHereApi(laton);*/
		}
		
		//-------------CommunityType--------------
		html1=html1.replace("value=\"Golf\" /> Golf</div>", "value=\"Golf\"/> Golf Course </div>");
		html1=html1.replace("Hackberry Country Club", "").replaceAll("Golf Club|Ranch Golf", "golf course");
		String communityType = U.getCommunityType((html1 ).replaceAll("Resort Style Living in|Left on Country Club| Golf", ""));
		
		//--------Status-------------
		String pStatus = ALLOW_BLANK;
		
		html1 = html1.replaceAll(
						"Coming Soon: Poolside|The Farm Stand Market Now Open|elementary school coming soon|Model Now Open - Now Selling|1 Coming Soon|Blvd Now Open|Model Now Open - Now Selling|Model Now Open|time_frame\":\"New Phase Now Open|ISD Elementary School Now Open",
						"");
		html1 = html1.replaceAll("\\d Coming Soon|and move-in ready homes from any device|elementary school now open|Center Coming Soon|Move In|Move-in|Elementary Coming Soon|coming-soon", "");
		html1 =html1.replaceAll(" Coming Summer 2018, a future amenity|Creek lots available|Exclusive Golf Course Lots Available|Model Now Open - Now Selling|New Hill Country Lots Available in Leande|\"Available Now\"|Available Now|New homes available|school opening Fall 2017", "");
		comminfo = comminfo.replace("Model Now Open - Now Selling", "").replaceAll("Golf Course Lots Available|Lakeside Amphitheater Now Open|Amenity Center Now Open|The Farm Stand Market Now Open", "");
		
		//-------below code will remove all "Move-in Ready" but not this content -> "6 move-in ready homes"
		if(!html1.contains("thumbnail home-container homeSpec")){
			html1 = html1.replaceAll("[M|m]ove-[i|I]n [R|r]eady", "");
		}
		//U.log(Util.matchAll(comminfo+html1, "[\\w\\s\\W]{30}coming summer[\\w\\s\\W]{30}", 0));
		pStatus = U.getPropStatus(comminfo+html1);
		
		U.log("pStatus : "+pStatus);
		U.log("pStatus :----"+pStatus);
		pStatus = pStatus.replace("New Lots Now Available, Now Available", "New Lots Now Available");
		
		//------Notes---------
		String noteVar = U.getnote(html1+comminfo);
		if(noteVar.contains("Final Phase"))
			pStatus=pStatus.replace("Final Phase, ", "");
		if(noteVar.contains("Pre-selling New Phase"))pStatus=pStatus.replaceAll(", Selling New Phase", "");
		
		
		data.addCommunity(communityName.toLowerCase(), url, communityType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(noteVar);

	}
}
