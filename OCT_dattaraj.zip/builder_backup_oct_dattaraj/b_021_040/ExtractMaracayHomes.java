/*
 * @author :  Sawan
 * @date : 29-06-2017
 */
package com.shatam.b_021_040;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMaracayHomes extends AbstractScrapper {
	CommunityLogger LOGGER;

	public int inr = 0;
	static int j = 0;
	private static String builderUrl = "https://www.maracayhomes.com";
	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new ExtractMaracayHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"TRI Pointe Group - Maracay Homes.csv", a.data().printAll());
	}

	public ExtractMaracayHomes() throws Exception {

		super("TRI Pointe Group - Maracay Homes","https://www.maracayhomes.com/");
		LOGGER = new CommunityLogger("TRI Pointe Group - Maracay Homes");
	}

	public void innerProcess() throws Exception {
		String html = U.getPageSource(builderUrl);
		String regSection = U.getSectionValue(html, "Find Your Home", "</ul>");
		String [] regUrls = U.getValues(regSection, "<a href=\"", "\"");
		
		for(String regUrl : regUrls){
			U.log("Region url***************************************************> "+regUrl);
			String regHtml = U.getPageSource(regUrl);
			String section = U.getSectionValue(regHtml, "<div id=\"allhomes\"", "<input type=\"hidden\"");
			String comSections [] = U.getValues(section, "<div class=\"columnInfo", "class=\"viewMore");
//			U.log(comSections.length);
		
			for(String comSec : comSections){
//				U.log(comSec);
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
				U.log("comURL******************************************************************> "+comUrl);
//				addDetails(comUrl, comSec);
				
				findCommunity(comUrl,comSec);
//				/return;
				
		}
		
	}
		LOGGER.DisposeLogger();
	}
	
	
	
	

	int i = 0;
	private void findCommunity(String url, String comSec) throws Exception{
//		if(i==15)
		
		{
			String html = U.getPageSource(url);
			String subComSections [] = U.getValues(html, "<div class=\"columnInfo", "class=\"viewMore");
			U.log(subComSections.length);
			LOGGER.AddCommunityUrl("Main Community ::"+url+"\tSubCommunityCount ::"+subComSections.length);
//			U.log(comSec);
			for(String subComSec : subComSections){
				String comUrl = U.getSectionValue(subComSec,"<a href=\"", "\"");
//				U.log(subComSec);
//				if(!comUrl.contains("https://www.maracayhomes.com/new-homes/tucson/center-pointe-vistoso-desert-crest/"))return;
				if(!comUrl.contains("https://www.maracayhomes.com/new-homes/phoenix/avance/"))
				{
					findCommunityDetails(comUrl,subComSec+comSec);
					}else
						AvanceUrl(comUrl,comSec);
			}
		}
//		}
//		i++;
	}
	
	
	//==================================================================================================================================================Avance Url
private void AvanceUrl(String commUrl,String comSec) throws Exception
	{
	
	
	String z=U.getHTML("https://www.maracayhomes.com/community/avance/");
	String hData=U.getHTML("https://www.avanceliving.com/find-a-home/");
	
	z=z.replace("on select move-in ready homes", "");
//	
	
	U.log("=========================================================================================================================================================================================================================================================================================================");
	String geo="false";
			
	String [] latLng = {ALLOW_BLANK,ALLOW_BLANK};
	String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
	
	//get the pageSource
		String htm1=U.getPageSource(commUrl);
//		htm1=htm1.replace("finish and capacity selected by the builder) on select move-in ready homes", "");
//		U.log(htm1);

		//get the Community Name
//		String comname=U.getSectionValue(htm1,"coty\">" ,"</h1>");
		String comname=U.getSectionValue(htm1,"<meta name=\"description\" content=\"" ,"\"").replace(" by Maracay Homes.","");
//		<meta name="description" content="Avance by Maracay Homes."/>
		U.log("com Name********************> "+comname);
		
		
		
		
		
	String html2=U.getHTML("https://www.avanceliving.com/contact/");

	String latlogSec= U.getSectionValue(html2, "center_lat\":", ",\"zoom\":");
//	String latLngSection = U.getSectionValue(latlogSec, "<a href=\"https://maps.google.com/maps?", "class=\"directions\">");
	
		latLng[0] = U.getSectionValue(html2, "center_lat\":\"", "\"");
		latLng[1] = U.getSectionValue(html2, "center_lng\":\"", "\"");
	
	U.log("LatLnfg =="+Arrays.toString(latLng));
	
	U.log("LatLngSec **********************> "+latlogSec);
//	=============================================================================================address
	String[] addr=U.getAddressGoogleApi(latLng);
	add[0]=addr[0];
	add[1]=addr[1];
	add[2]=addr[2];
	add[3]=addr[3];
	U.log("Adress:"+Arrays.toString(add));
	geo="true";

	//======================================================================================= Price ======================
//	comInfo = comInfo.replace("'s</small>", ",000");
	String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	
	String[] price = U.getPrices(htm1+z+comSec+hData, "\\$\\d+,\\d+|\\$\\d+", 0);
	minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
	maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

	U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
	
//	===============================================================================================SQFT
	
	String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;			
	String sqFt[] = U.getSqareFeet(htm1+z+comSec+hData,
					"<br>\\d,\\d{3} - \\d,\\d{3} sq. ft.<br>|\\d,\\d{3} - \\d,\\d{3} sq ft<br>|\\d,\\d{3} - \\d,\\d{3} sq. ft.<br>|homesites with the typical sizes ranging from \\d{2},\\d{3} to \\d{2},\\d{3}\\+ square feet|homesites with the typical size being \\d+,\\d{3} square feet|approximately \\d,\\d+ to \\d,\\d+ sq. ft|\\d+,\\d+ to over \\d+,\\d+ square feet|\\d,\\d+ to \\d,\\d+ square feet |\\d,\\d{3} <small>sq.ft.</small></p>|\\d ,\\d+ to \\d,\\d+ square feet|\\d,\\d{3} SQ. FT.|\\d,\\d{3} sq. ft.",
					0);

	minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
	maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
	
	U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
	

	
	
	
	//	===========================================================================================================================Property Type

	String propType = U.getPropType(htm1+hData+z);
	U.log("Prop Type::************************************" + propType);
	
//	===========================================================================================================================Derived Property Type


	String derivedPType = ALLOW_BLANK;
	derivedPType = U.getdCommType(htm1+hData+z);
	U.log("derivedPType*******************************"+derivedPType);
	
	//=================================================================================================================== Community Type ===============
//	amentiesHtml = amentiesHtml.replaceAll("Lakes Golf", "");
	String communityType = U.getCommunityType(htm1+html2+z);
	U.log("communityType*************************************> "+communityType);
	
	
	//================================================================================================================== Property Status===============

	String pStatus = ALLOW_BLANK;
//	htm1=htm1.replace("on select move-in ready homes,","");
	pStatus = U.getPropStatus(htm1+z);
	U.log("pStatus********************************************************************************************"+pStatus);

	//======== Notes ================
	String noteVar = ALLOW_BLANK;
	noteVar = U.getnote(htm1+z);


	// ===========add data==========================
	data.addCommunity(comname, commUrl, communityType+", Master Planned");
	data.addAddress(add[0].replace("&amp;", "&"), add[1], add[2], add[3]);
	data.addSquareFeet(minSqf, maxSqf);
	data.addPrice(minPrice, maxPrice);
	data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
	data.addPropertyType(propType, derivedPType);
	data.addPropertyStatus(pStatus);
	data.addNotes(noteVar);

	j++;
	

	

	U.log("=========================================================================================================================================================================================================================================================================================================");
	
	}//avanceUrl

//========================================================================================================================================================================

	
	
	
	
	
	
	
	
	
	

	private void findCommunityDetails(String comUrl, String subComSec) throws Exception {
//	if(j == 6)
		{
		String [] latLng = {ALLOW_BLANK,ALLOW_BLANK};
		String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		U.log(subComSec);
		{
			
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			
			
			U.log("Count =="+j);
			U.log(comUrl);
			
			
			String html = U.getPageSource(comUrl);
			
			//================================================================================= Community Name ==============
			String comName = U.getSectionValue(html, "neighborhood--title\">", "</h1>");
			if(comName != null)
				comName = comName.trim().replaceAll("- 55\\+ Community$|55\\+ Community$", "");
			U.log("comName :::***********************> "+comName);
	
			//==============================================================================Section ===============
			String comInfo = U.getSectionValue(html, "<div class=\"breadcrumbs\">", "class=\"email stayinform\">");
			//U.log("comInfo ::::::::::::::::"+comInfo);
			//========== LatLng Section ======================
			
			String latlogSec= U.getSectionValue(comInfo, "<nav class=\"utility-nav\">", "<a href=\"#stayinform_mobile\"");
			String latLngSection = U.getSectionValue(latlogSec, "<a href=\"https://maps.google.com/maps?", "class=\"");
//			U.log(comInfo);
			U.log("LatLngSec **********************> "+latLngSection);
			if(latLngSection != null){
				latLng = findLatLng(latLngSection);
			}
			U.log("LatLnfg =="+Arrays.toString(latLng));
			
			//=============================================================== Address ===========================================================================================
			String geo = "False";
			String addSection=U.getSectionValue(comInfo, "<li class=\"city\">", "<a href=");
			String addSec=U.getSectionValue(addSection, "<br/>", "<br/>").replace(", Peoria, AZ 85383 Peoria", "Peoria");
			U.log("addSec::::::::::"+addSec);
		    String cityName=U.getSectionValue(comInfo, "class=\"city\">", "</a>");
		    U.log("cityName::::::::::"+cityName);
			if(addSec!=null){
				//addSec = addSec.replaceAll("<p>|<br /></p>", "");
				
				addSec = addSec.replace(", ½ mile South of Riggs Rd.", "");
				//U.log(addSec);
				if(addSec.trim().contains(cityName.trim())) {
				addSec=addSec.replace(cityName.trim(), ","+cityName.trim());
				}
				//addSec = U.formatAddress(addSec);
				String[] ad=addSec.trim().split(",");
				U.log("Adress:"+Arrays.toString(ad));
				//ad[2]=ad[2].replace("<br>", "");
				add[0]=ad[0].trim();
				add[1]=ad[1].trim();
				add[2]=Util.match(ad[2].trim(), "\\w+");
				add[3]=Util.match(ad[2].trim(), "\\d+");
				U.log("Adress:"+Arrays.toString(add));
			}
			if((add[0]== null || add[1]== null || add[2]== null || add[3] == null) && latLng[0] != ALLOW_BLANK  && latLng[1] != ALLOW_BLANK){
				add = findAddress(latLngSection);
				geo = "True";
			}
			add[0] = add[0].replaceAll(" \\|", "");
		/*	if(latLng[0] != ALLOW_BLANK  && latLng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				geo = "True";
			}*/
			U.log("Add =="+Arrays.toString(add));
	
			//========================================================================== ======================================= Community Menu Section =============
			String menuSection = U.getSectionValue(html, "<div class=\"mobileMenuInner\"", "</ul>");
			String menuUrls [] = U.getValues(menuSection, "<a href=\"", "\"");//return values
			
			//==========================================================================FLOOR PLAN & MOVE IN READY HOME 
			String floorPlanHtml = null;
			String readyHomeHtml = null;
			String amentiesHtml = null;
												
			for(String planHomeUrl : menuUrls){
				if(planHomeUrl.contains("/floorplans"))
					floorPlanHtml  = U.getPageSource(planHomeUrl);
				if(planHomeUrl.contains("/move-in-ready"))
					readyHomeHtml = U.getPageSource(planHomeUrl);	
				if(planHomeUrl.contains("/neighborhood-map"))continue;
				if(planHomeUrl.contains("/lifestyle"))
					amentiesHtml = U.getPageSource(planHomeUrl);
			}
			//========================================================================== =======================================--------- Combined Html of Floor plan -----------
			String combinedfloorHtmls = null;
			if(floorPlanHtml != null){
				String floorSection = U.getSectionValue(floorPlanHtml, "<div class=\"neighborhoodPlans\">", "<div class=\"clear oddClear\">");
				String[] floorUrlSections = U.getValues(floorSection, "<figure class=\"figure\">", "</a>");
				U.log("Floor home ::"+floorUrlSections.length);
				for(String floorUrlSection : floorUrlSections){
					
					String floorUrl = U.getSectionValue(floorUrlSection, "<a href=\"", "\">");
					U.log("floorUrl:::"+floorUrl);
					combinedfloorHtmls = combinedfloorHtmls+U.getSectionValue(U.getPageSource(floorUrl)	, "<h4>", "</p>");
				}
				//-----rem0ve footer----
				floorPlanHtml = U.removeSectionValue(floorPlanHtml, "<div class=\"footerDisclaimer", "</footer>");
			}
			
			//================================================================================================================Combined Html of Move in ready homes -----------
			String combinedReadyHtmls = null;
			if(readyHomeHtml != null){
				String readySection = U.getSectionValue(readyHomeHtml, "<div class=\"move-in-ready-home\"", "<div class=\"clear oddClear\">");
				String[] readyUrlSections = U.getValues(readySection, "<figure class=\"figure\">", "</a>");
				U.log("Move in Home  ::"+readyUrlSections.length);
				for(String readyUrlSection : readyUrlSections){
					String readyUrl = U.getSectionValue(readyUrlSection, "<a href=\"", "\">");
					combinedReadyHtmls = combinedReadyHtmls+U.getSectionValue(U.getPageSource(readyUrl), "<h3>", "<div class=\"contact");
				}
				readyHomeHtml = U.removeSectionValue(readyHomeHtml, "<div class=\"footerDisclaimer", "</footer>"); 
				
			}
			
			 
			
			//======================================================================================= Price ======================
			comInfo = comInfo.replace("'s</small>", ",000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			String[] price = U.getPrices(comInfo+floorPlanHtml+readyHomeHtml, "\\$\\d+,\\d+|\\$\\d+", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
			//=============== Sqft ============================
			comInfo = comInfo.replaceAll("being 10,125 square feet|ypical size being 10,800 square feet|24,000\\+ square feet", "");
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;			
			String sqFt[] = U.getSqareFeet(	comInfo+floorPlanHtml+readyHomeHtml,
							"homesites with the typical sizes ranging from \\d{2},\\d{3} to \\d{2},\\d{3}\\+ square feet|\\d,\\d{3} to \\d,\\d{3} square feet|homesites with the typical size being \\d+,\\d{3} square feet|approximately \\d,\\d+ to \\d,\\d+ sq. ft|\\d+,\\d+ to over \\d+,\\d+ square feet|\\d,\\d+ to \\d,\\d+ square feet |\\d,\\d{3} <small>sq.ft.</small></p>|\\d ,\\d+ to \\d,\\d+ square feet|\\d,\\d{3} SQ. FT.|\\d,\\d{3} sq. ft.",
							0);

			minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			//=============== Property Type ===============
			comInfo = comInfo.replaceAll("Estates\\s+</span>\\s+</em>\\s+</strong>\\s+series", "Estates Series Home");
			U.log(Util.matchAll(comInfo+combinedfloorHtmls+combinedReadyHtmls, "[\\w\\s\\W]{30}homeowner’s association[\\w\\s\\W]{30}", 0));
			String propType = U.getPropType((comInfo+(combinedfloorHtmls+combinedReadyHtmls).replaceAll("villagio|Villagio|Village|Villagio| homeowner’s association dues", "")).replace("homeowner’s association dues", ""));
			U.log("Prop Type::" + propType);

			//=============== Community Type ===============
			String communitylable=ALLOW_BLANK;
			amentiesHtml = amentiesHtml.replaceAll("Lakes Golf|French Country |Golf And Country Club|(Ahwatukee|Palmbrook|Arrowhead) Country|sunlakescountry|Seville-Golf-Country|Sun Lakes Country|Seville Golf & Country", "");
			if(subComSec.contains("Master-Planned"))
				communitylable = "Master-Planned";
			String communityType = U.getCommunityType((comInfo+amentiesHtml+communitylable).replace("Encanterra Golf And Country Club|French Country |Seville Golf & Country Club|Seville-Golf-Country-Club", ""));
			if(comUrl.contains("the-lakes-at-annecy")|| comUrl.contains("avance"))communityType=communityType+", Matser Planned";
			// =============== Derived Property type  ===============
			String derivedPType = ALLOW_BLANK;
			comInfo=comInfo.replace("single- and two-story", " 1 Story 2 Story ");
			comInfo = comInfo.replaceAll("rancho|Rancho", "");
			derivedPType = U.getdCommType((comInfo + comName+combinedfloorHtmls+combinedReadyHtmls).replaceAll("Ranch Hacienda Elevation|pagerAnchorBuilder|ranch-hacienda-C| six floor plans|rancho|Rancho|-colonial-", ""));
			
			// =============== Property Status  ===============

			String pStatus = ALLOW_BLANK;
			comInfo = comInfo.replace("* Coming Soon Div", "").replaceAll("\\| Now Available!|model home is now available|last opportunity to purchase a|now open in Artesian", "")
					.replaceAll("close-out|Closeout|CLOSEOUT|CloseOut","Close Out").replace("opening Fall of 2017", "opening Fall 2017")
					.replace("new build opportunities and move-in ready homes", "").replace("Thatcher Model | Now", "").replace("title=\"Grand Opening Celebration\"", "");

			pStatus = U.getPropStatus(comInfo+subComSec+menuSection);

			//======== Notes ================
			String noteVar = ALLOW_BLANK;
			noteVar = U.getnote(comInfo);
			String moveHtml=U.getHTML(comUrl+"/move-in-ready/");
			if(!moveHtml.contains("<span class=\"plan_card_detail\">"))pStatus=pStatus.replaceAll("Move-in Ready Homes,", "");

			// ===========add data==========================
			data.addCommunity(comName, comUrl, communityType);
			data.addAddress(add[0].replace("&amp;", "&"), add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(propType, derivedPType);
			data.addPropertyStatus(pStatus);
			data.addNotes(noteVar);
		}
		}
		j++;
	}
	private  String [] findLatLng(String latLngSection){
		String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
		Matcher mat = Pattern.compile("\\d{2,3}\\.\\d{3,8},-\\d{2,3}\\.\\d{3,8}",Pattern.CASE_INSENSITIVE).matcher(latLngSection);
		if(mat.find()){
//			U.log(mat.group());
			latLng = mat.group().split(",");
		}
		return latLng;
	}
	private String [] findAddress(String addressSection){
		String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addSec = U.getSectionValue(addressSection, ">", "</a>");
		if(addSec != null){
			addSec = addSec.replace("101st Pl. &amp; Brown Rd. ", "101st Pl. & Brown Rd,").replace("Dr. Oro Valley", "Dr., Oro Valley").replace("ñ", "n").replace(".20 miles south of Snyder Road", ",").replace("Ave. Buckeye", "Ave., Buckeye").replace("Lane Peoria", "Lane, Peoria")
					.replace("Street Buckeye", "Street, Buckeye").replace("Ave. Peoria", "Ave., Peoria").replace("Way Mesa", "Way, Mesa").replace("Rd. Gilbert", "Rd., Gilbert")
					.replace("Drive Peoria", "Drive, Peoria").replace("Drive Queen Creek", "Drive, Queen Creek").replace("Place Oro Valley", "Place, Oro Valley").replace("Drive Marana", "Drive, Marana")
					.replace("Road Queen Creek", "Road, Queen Creek").replace("Road Chandler", "Road, Chandler").replace("St. Gilbert", "St., Gilbert").replace("Rd. Chandler", "Rd., Chandler").replace("Way Gilbert", "Way, Gilbert")
					.replace("&#241;", "n").replaceAll("Sales Office Closed|1.25 miles north of Catalina Highway|amp;", "").replace(" | ", ", ");
			add = U.getAddress(addSec);
		}
		return add;
	}

}
