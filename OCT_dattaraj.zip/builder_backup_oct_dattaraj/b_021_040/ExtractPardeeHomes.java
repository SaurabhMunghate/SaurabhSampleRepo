/**
 * @author Rakesh Chaudhari
 * @date 21 July 2015
 * 
 */
package com.shatam.b_021_040;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang.StringEscapeUtils;
import org.junit.runners.AllTests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPardeeHomes extends AbstractScrapper {

	ArrayList<String> comunities = new ArrayList<String>();
	int i = 0;
	static int j = 0;
	public int inr = 0;
	public int count = 0;
	CommunityLogger LOGGER;
	static HashMap<String, String> cityState = new HashMap<>();
	
	// Connection con;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractPardeeHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"TRI Pointe Group - Pardee Homes.csv", a
				.data().printAll());
	}

	public ExtractPardeeHomes() throws Exception {

		super("TRI Pointe Group - Pardee Homes", "https://www.pardeehomes.com");
		LOGGER = new CommunityLogger("TRI Pointe Group - Pardee Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		cityState.put("San Diego", "CA");
		
		// Your code here
		final String baseUrl = "https://www.pardeehomes.com";
		String html = U.getHTML("https://www.pardeehomes.com/find-my-home/");

		String[] values = U.getValues(html,"<div class=\"card card--neighborhood\"><div class=\"card__frame\">", "Learn");

		int totalComm = values.length;
		U.log("Total Cunt: " + totalComm);

		for (String comSec : values) {
			String url = U.getSectionValue(comSec, "<div class=\"card__image\"><a href=\"", "\"");
			url = url.replace("pardeehomes.com/VistaSantaFe/", "pardeehomes.com/neighborhood/VistaSantaFe/");
			String name = U.getSectionValue(comSec, "title=\"", "\"");
//			if(comSec.contains("escala"))U.log(comSec);
			String latLngSec = U.getSectionValue(html, "\"title\":\""+name, "}");
//			try {
				addDetails(url, name,comSec,latLngSec);
//			} catch (Exception e) {
				// TODO: handle exception
//			}
			
			// break;
		}

		LOGGER.DisposeLogger();
	

	}

	private void addDetails(String url, String name,String comSec,String latLngSec)throws Exception {
	//TODO
//	if(i>=52)
//		if(!url.contains("https://www.pardeehomes.com/los-angeles/lyra/"))return;
		{

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "*******Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			if (url.contains("https://www.pardeehomes.com/las-vegas/encanto-at-durango-ranch/"))return;//Page Not found
			//String comhtml = U.getHtml(url, driver);
			String comhtml = U.getHTML(url);
			String comName = name;
			String comUrl = url;
			String extraDataUrl=comUrl+"lifestyle/";
			String lifeStyleHtml=U.getHTML(extraDataUrl);
			if (lifeStyleHtml!=null) {
				lifeStyleHtml=U.getSectionValue(lifeStyleHtml, "<div class=\"innerStr new_neighborhood\">", "<div class=\"contact_card\">");
			}
			if(!comhtml.contains("Neighborhood Lifestyle")) lifeStyleHtml = "";
			U.log(i+" ::url :: " + url);
			U.log("Name:: " + name);
			latLngSec = StringEscapeUtils.unescapeJava(latLngSec);
			U.log("comSec : "+latLngSec);
			String comType = ALLOW_BLANK;
			String propertyType = ALLOW_BLANK;
			String dType = ALLOW_BLANK;
			String propertyStatus = ALLOW_BLANK;
			String price[] = { ALLOW_BLANK, ALLOW_BLANK };
			String sqFt[] = { ALLOW_BLANK, ALLOW_BLANK };
			
			String noteVar = U.getnote(comhtml);

			// Florplan Urls
			String allFloorPlanData = ALLOW_BLANK;
			ArrayList<String> flrUrls = Util.matchAll(comhtml, "href=\"(.*?)\">View floor plans and gallery</a>",1);
			U.log("Total floor Plans : "+flrUrls.size());
			for(String flrUrl : flrUrls){
				String floorHtml = U.getHTML(flrUrl);
				allFloorPlanData += U.getSectionValue(floorHtml, "<h3 class=\"neighborhood-name\"", "<div class=\"floorPlan_new row\">");
			}
//			U.log(allFloorPlanData.contains("patio"));
			// Move-in-ready Urls
			String moveHtml = ALLOW_BLANK;
			String moveData =ALLOW_BLANK;
			if (comhtml.contains("Move-In Ready Homes</a>")) {
				U.log("hello");
				moveHtml = U.getHTML(comUrl + "move-in-ready/");
				String[] allPlanUrls=U.getValues(moveHtml, "<div class=\"card__image\"><a href=\"", "\">");
				U.log("Total move in homes :::::::::"+allPlanUrls.length+"::::::::::::::::::::");
				for(String planUrl: allPlanUrls){
					if(planUrl.contains("http")){
						U.log("Plan Url ::::: "+planUrl);
						String planHtml=U.getHTML(planUrl);
						try{
							String content = U.getSectionValue(planHtml, "<div id=\"qmidetials\"", "<div id=\"qmidetialsright");
							if(content == null) content =  U.getSectionValue(planHtml, "<div id=\"qmidetials\" class=", "<div class=\"floorPlan_new");
							moveData += content;
						}catch(Exception e){}
					}
				}
			}
			comhtml = comhtml.replace("Verana | Single Family Luxury Homes",
					"Verana Single Family Luxury Homes");
			comhtml = comhtml.replace(
					"master-planned community. (View Online)",
					"master-planned community View Online alterra");
			comhtml = comhtml.replace("master planned community providing",
					"master planned community providing summerfield");

			comhtml = comhtml
					.replaceAll(
							"\"name\": \"Daybreak Grand Opening\",|\"name\": \"Braeburn at Spencer’s Crossing - Grand Opening\",|<meta(.*?)>|opening this summer near Carnegie|Grand Opening Feb 25 - Visit the model homes|content=\"An exclusive 55\\+ Active Adult |content=\"Coming Fall 2017| home or common area will offer a |neighborhood Highlands Ranch|Pacific Highlands Ranch|neighborhood of New Homes Coming Soon|coming soon to Pacific|villages/westridge/|Assumptions. You are purchasing a single family|homeowner’s association dues|master planned community providing summerfield|master-planned community View Online alterra|to feature 78 single-family|Verana Single Family Luxury Homes|new floor plans at Keystone|rAnchor|content=\"Coming Soon - Viewpoint|content=\"Coming Soon - New homes|gated Solano|Gated Solano|highlands-ranch/|Pacific Highlands Ranch|Rancho|status-plan\">Sold Out",
							"");

			//U.log(comhtml);
			comhtml=comhtml.replaceAll("First year of HOA dues|neighborhood highlands ranch|Grand Opening 4|NeighborhoodComing Soon|And coming soon|fitness center coming soon|\\(Coming Soon\\)|is Coming Soon to", "");
			comhtml = comhtml.replaceAll("Highlands Ranch|Highlands%20Ranch|insurance premiums, homeowner", "");
			comhtml=comhtml.replaceAll("Traditional architecture |Traditional. and Napa architectural", "Traditional Home")
								.replace("luxury residences", "luxury homes residences");
			comhtml=comhtml.replace("resort appeal thanks", "resort-style appeal thanks");
			comhtml=comhtml.replace("Coming Soon - Fall 2017", "Coming Soon Fall 2017")
											.replace("Coming Soon - Summer 2017", "Coming Soon Summer 2017");
			comhtml=comhtml.replace("Grand Opening - Summer 2017", "Grand Opening Summer 2017").replace("Farmhouse and", "modern farmhouse");
			if (comUrl.contains("/inland-empire/")) {
				comhtml+="master planned community";//Region pAge(homes for sale in the area’s best master-planned communities.)
			}
			//--------------------comType, Property Type,Dtype & Status -----------------------
			comType = U.getCommType(comhtml+lifeStyleHtml);
			
			String patioString=ALLOW_BLANK;
			if(allFloorPlanData!=null && allFloorPlanData.contains("Covered patio"))
				patioString ="Covered patio";
			propertyType = U.getPropType((comhtml+moveData+patioString).replaceAll("-Plan4-OutdoorPatio-|-Patio-", ""));
			
			
			dType = U.getdCommType((moveData+comhtml+allFloorPlanData).replaceAll("second story","").replace("First-floor"," 1 Story ")+moveData);
			
			
			comhtml=comhtml.replace("summer 2017 by","").
					replaceAll("us for the Grand Opening on November|<img(.*?)>|Altis Grand Opening|orhood-status-plan\">Temporary Sold Out</div>|status == \"Sold Out| status == \"Temporary Sold Out\"", "")
					.replaceAll("neighborhood-status-plan\">Temporarily Sold|music to celebrate the Grand|Alisio Grand", "");
			comhtml=comhtml.replaceAll("the Grand Opening of the brand new|Meridian Grand Opening|chool will be at Skyline, coming soon.|Centennial  - Coming Soon|[C|c]oming [S|s]oon to|The grand opening celebration is April 28|content=\"Coming soon to |\"Coming Soon\"|\"Sold Out\"|\"Temporary Sold Out\"|Center opening soon|Quick|final new homes are now selling in the beautiful|Starling- Grand Opening|hood coming|information on the final","")
					.replaceAll("VideoObject\",\\s+\"name\": \"Tamarack - Grand", "");
//			U.log(Util.matchAll(comhtml, "[\\s\\w\\s\\W]{30}sold[\\s\\w\\s\\W]{30}", 0));
			
			propertyStatus = U.getPropStatus(comhtml);
			
			propertyStatus = propertyStatus.replace("Opening Fall 2018, Grand Opening", "Grand Opening Fall 2018");
			
//			U.log(comSec);
			
			// U.log("result:::"+Util.match(comhtml, ".*?Coming Fall 2017.*?"));
			
			// Squarefeet
			String minSqf = ALLOW_BLANK;
			String maxSqf = ALLOW_BLANK;

			sqFt = U.getSqareFeet(comSec+latLngSec+comhtml + allFloorPlanData + moveHtml,
					"sqft\":\"\\d,\\d+ - \\d,\\d+\"|\\d{1},\\d{3} - \\d{1},\\d{3}  sq ft|\\d{1},\\d{3}\\s*–\\s*\\d{1},\\d{3} square feet|Approximately \\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} sq. ft. – \\d{1},\\d{3} sq. ft. |\\d{1},\\d{3}-\\d{1},\\d{3} square feet|\\d,\\d{3} sq. ft. � \\d,\\d{3} sq. ft|\\d{1},\\d{3}-\\d{1},\\d{3} sq. ft.|\\d,\\d+ to almost \\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ sq.ft|\\d,\\d+- to \\d,\\d+-square feet|\\d,\\d+ � \\d,\\d+ sq. ft.|\\d+,\\d+ – \\d+,\\d+ square feet|\\d+,\\d+ to \\d+,\\d+ square feet|\\d{1},\\d{3} sq ft",
					0);

			minSqf = (sqFt[0] != null) ? sqFt[0] : ALLOW_BLANK;
			maxSqf = (sqFt[1] != null) ? sqFt[1] : ALLOW_BLANK;

			U.log("minSqft:: " + minSqf + " maxSqft:: " + maxSqf);
			
			// Price
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;
			comhtml.replace("43502", "");
//comhtml.replaceAll("0s", "0");
			comhtml = comhtml.replace("300s", "300,000");
			comhtml=comhtml.replaceAll("1.2 million", "1,200,000")
					.replace("low $3 millions", "low $3,000,000");
			
			price = U
					.getPrices(
							comhtml + allFloorPlanData + moveHtml,
							"\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|>Priced at \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Priced at \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
							0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		//-------------------Address && latlng-----------------------
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
			String addHtml = ALLOW_BLANK;
			
			//***latlng from community page****
			comhtml = comhtml.replace("=&amp;", "=&");
			U.log("get::: " + U.getSectionValue(comhtml, "<li class=\"city\">", "</li>"));
			String latlngSec = U.getSectionValue(comhtml, "<a href=\"https://maps.google.com/maps?saddr=&daddr=", "\"");
			U.log("latlngSec : "+latlngSec);
			if (latlngSec !=null) {
				if(latlngSec.length() != 1)latLng = latlngSec.split(",");
				
			}
			U.log("latlng is "+Arrays.toString(latLng));
			
			//***Address fro directions page ****
			if(comhtml.contains("directions\">Directions</a><")){
				addHtml = U.getHTML(comUrl+"/directions");
				String addSec = U.getSectionValue(addHtml, "Directions</h2>", "<br/>");
				//U.log(":::::::::::::"+addSec);
				if(addSec!=null){
					addSec = addSec.replaceAll("Strada New Home Gallery - |</div>|<div class=\"row\">|<div class=\"medium-12\">|<p><b>", "").trim();
					U.log("new add sec:::::::::::::"+addSec);
					
					String[] tempAdd = addSec.split(",");
					add[0] = tempAdd[0].trim();
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2],"\\w+");
					add[3] = Util.match(tempAdd[2],"\\d+");
					U.log("Address is " + Arrays.toString(add));
					
					if(add[3]==null)add[3]=ALLOW_BLANK;
				}
			}
			else{
				String addSec = U.getSectionValue(comhtml, "<li class=\"city\">", "<br>");
				U.log("::::::::::: else :::::::: "+addSec);
				if(addSec != null){
					String [] tmp = addSec.trim().split(",");
					if(tmp.length==2){
						add[3] = Util.match(tmp[1], "\\d+");
						add[2] = Util.match(tmp[1], "[A-Z]{2}");
						if(add[2]!=null){
							add[1] = U.getCity(tmp[0], add[2]);
							add[0] = tmp[0].replaceAll(add[1], "").trim();
						}
						
					}
				}
				U.log("::::::::::: else :::::::: "+Arrays.toString(add));
			}
			
			if((add[0].length()<4 || add[3].length()<4)&& latLng[0].length()>4)
			{
				add = U.getAddressGoogleApi(latLng);
				geo = "TRUE";
			}
			
			
			if(latLng[0].length()<4 && add[3].length()>4  ){
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
				
			}
			//address from city and state
			if(add[0].length()<4 && latLng[0].length()<4){
				String city = Util.match(url, "com/(.*?)/",1);
				U.log(city+"\t"+url);
				add[1] = U.getCapitalise(city.replace("-", " "));
				U.log(add[1]+"\t"+cityState);
				add[2] = (String) cityState.get(city);
				
				latLng = U.getlatlongGoogleApi(add);
				add = U.getAddressGoogleApi(latLng);
				noteVar = "Address And Lat-Lng Are Taken Using City And State";
				geo = "TRUE";
			}
			add[0] = add[0].replace("Strada New Home Gallery - ", "");
			
			
			comName = comName.replace("Casavía", "Casavia");
			comName=comName.replace(": Homesites at Buffalo", "");
			comhtml = comName.replace(":", "");
			U.log(comName+"::::::::");
			
			LOGGER.AddCommunityUrl(url);
			data.addCommunity(comName, url, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(propertyType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(noteVar);

		}
		i++;
	}
}
