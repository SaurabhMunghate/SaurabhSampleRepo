//<<<<<<< ExtractSheaApartments.java
/*@ Modification Rakesh..
 */
/*package com.shatam.b_010_019;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractSheaApartments extends AbstractScrapper {

	static int sitecounter = 0;
	public int i = 0;
	public int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;

public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractSheaApartments();
		a.process();
		a.data().printAll();
		FileUtil.writeAllText("C:/cache/Shea Homes - Apartments.csv", a.data()
				.printAll());

	}

	public ExtractSheaApartments() throws Exception {
		super("Shea Homes - Apartments", "http://www.sheaapartments.com/");
		LOGGER = new CommunityLogger("Shea Homes - Apartments");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("http://www.sheaapartments.com/");
		String section = U.getSectionValue(html,
				"<ul  class=\"sub-menu-margin-shadow\">", "</div>");

		String[] Url = U.getValues(section, "<a href=\"", "\"");
		String[] comN = U.getValues(section, "\">", "</a>");

		for (int i = 0; i < Url.length; i++) {
			String commName = comN[i].trim();
			LOGGER.AddCommunityUrl(commName);
			String comUrl = Url[i].trim();
			addDetails(commName, comUrl);

		}
		j++;
		LOGGER.DisposeLogger();
	}

	public void addDetails(String commName, String comUrl) throws Exception {
		String commUrl = "http://www.sheaapartments.com" + comUrl;
		String html = U.getHTML(commUrl);

		 *********************************ADDRESS***************************
/*		String geo = "";
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		add[0] = U.getSectionValue(html, "streetAddress\">", "</span>").trim();
		add[1] = U.getSectionValue(html, "addressLocality\">", "</span>")
				.trim();
		add[2] = U.getSectionValue(html, "addressRegion\">", "</span>").trim();
		add[3] = U.getSectionValue(html, "postalCode\">", "</span>").trim();

		 *************************latlng********************************
		String[] latlng = U.getlatlongGoogleApi(add);
		String lat = latlng[0];
		String lng = latlng[1];
		geo = "FALSE";

		// **********************COMMUNITY INFO*************************

		String Type = U.getCommunityType(html);
		String pType = U.getPropType(html);
		html = html.replace("Highlands Ranch</a>", "");
		String dType = U.getdCommType(html);
		html = html.replaceAll(
				"COMING SOON are a brand new Resident Lounge|2015", "");
		String status = U.getPropStatus(html);
		String note = ALLOW_BLANK;

		// *********************************Prices***************************

		String html1 = U.getHTML(commUrl + "floor-plans/");
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		String[] prices = U.getPrices(html1, "\\$\\d,\\d{3}|\\$\\d+,\\d{3}", 0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		// *********************************Square Ft.***********************

		html1 = html1.replaceAll("\\s+", " ");
		String minSq = ALLOW_BLANK;
		String maxSq = ALLOW_BLANK;
		String[] sqft = U
				.getSqareFeet(
						html1,
						"<small>\\d,\\d{3} - \\d,\\d{3}</small>|<small>\\d,\\d{3}</small>|<small>\\d{3}</small>|<small>\\d{3} - \\d{3}</small>",
						0);
		minSq = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
		maxSq = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
		U.log("MinSq:" + minSq + "MaxSq:" + maxSq);

		data.addCommunity(commName, commUrl, Type);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSq, maxSq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);

	}

}
=======
/*@ Modification Rakesh..
 */
package com.shatam.b_021_040;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractSheaApartments extends AbstractScrapper {

	static int sitecounter = 0;
	public int i = 0;
	public int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractSheaApartments();
		a.process();
		a.data().printAll();
		FileUtil.writeAllText(
				U.getCachePath()+"Shea Homes - Apartments.csv", a
						.data().printAll());

	}

	public ExtractSheaApartments() throws Exception {
		super("Shea Homes - Apartments", "http://www.sheaapartments.com/");
		LOGGER = new CommunityLogger("Shea Homes - Apartments");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("http://www.sheaapartments.com/");
		String section = U.getSectionValue(html,
				"<h3><a href=\"/apartments/\">",
				"<div class=\"main--wrapper\">");

		String[] Url = U.getValues(section, "<li>", "</li>");
		// String[] comN = U.getValues(section, "\">", "</a>");

		for (String newUrl : Url) {
			String commName = U.getSectionValue(newUrl, "\">", "</a>").trim();
			LOGGER.AddCommunityUrl(commName);
			String comUrl = U.getSectionValue(newUrl, "<a href=\"", "\">");
			addDetails(commName, comUrl);

		}

		j++;
		LOGGER.DisposeLogger();
	}

	public void addDetails(String commName, String comUrl) throws Exception {
		
		//if(j==9)
		{
		String commUrl = "http://www.sheaapartments.com" + comUrl;
		String html = U.getHTML(commUrl);

		// *********************************ADDRESS***************************//
		String geo = "";
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		add[0] = U.getSectionValue(html, "streetAddress\">", "</span>").trim();
		add[1] = U.getSectionValue(html, "addressLocality\">", "</span>")
				.trim();
		add[2] = U.getSectionValue(html, "addressRegion\">", "</span>").trim();
		add[3] = U.getSectionValue(html, "postalCode\">", "</span>").trim();

		// *************************latlng********************************//
		String[] latlng = U.getlatlongGoogleApi(add);
		String lat = latlng[0];
		String lng = latlng[1];
		geo = "FALSE";

		//***************amenities Url Data*****************
		String amenSection=ALLOW_BLANK;
		if(html.contains("FEATURES, AMENITIES, SERVICES")){
			String amenUrl=commUrl+"amenities/";
			String amenHtml=U.getHTML(amenUrl);
			amenSection=U.getSectionValue(amenHtml, "<div id=\"property_features\"", "div class=\"property-phone-");
		}
		
		// **********************COMMUNITY INFO*************************//
		String remove = "village|ocean ranch village|Highlands Ranch</a>|Detached private garages available|Resort-style saltwater pool";
		html = html.toLowerCase().replaceAll(remove.toLowerCase(), "");
		html=html.replace("gated parking","gated-community");
		String Type = U.getCommunityType(html+amenSection);
		
		html = html.replaceAll("comfort, luxury|comfort and luxury", "luxury homes");
		String pType = U.getPropType(html+amenSection);
		/*if(html.contains("apartments"))
		{
			if(pType==ALLOW_BLANK)
				pType="";
		 pType=pType+"Apartments";
		}*/
		U.log(pType+"###############");
		html = html.replaceAll("Highlands Ranch</a>|colonial floor", "");
		String dType = U.getdCommType(html);
		html = html
				.replaceAll(
						"toll road. now open|Now Open! \" /><meta name|services&nbsp;coming&nbsp;soon|toll road. coming soon|the 73 toll road. Coming Soon|community is coming soon|COMING SOON are a brand new Resident Lounge|2015|Habit all now open|community is coming soon|services are opening soon|road. Coming Soon.",
						"");
		//U.log(html);
		String status = U.getPropStatus(html);
		String note = ALLOW_BLANK;

		// *********************************Prices***************************//
		String[] prices={ALLOW_BLANK,ALLOW_BLANK};
		String html1 = U.getHTML(commUrl + "floor-plans/");
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		prices = U.getPrices(html1, "\\$\\d,\\d{3}|\\$\\d+,\\d{3}", 0);
				
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		// *********************************Square Ft.***********************//

		html1 = html1.replaceAll("\\s+", " ");
		String minSq = ALLOW_BLANK;
		String maxSq = ALLOW_BLANK;
		String[] sqft = U
				.getSqareFeet(
						html1,
						"<small>\\d,\\d{3} - \\d,\\d{3}</small>|<small>\\d,\\d{3}</small>|<small>\\d{3}</small>|<small>\\d{3} - \\d{3}</small>",
						0);
		minSq = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
		maxSq = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
		U.log("MinSq:" + minSq + "MaxSq:" + maxSq);

		data.addCommunity(commName, commUrl, Type);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSq, maxSq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(ALLOW_BLANK);

	}j++;
	}

}
//>>>>>>> 1.9
