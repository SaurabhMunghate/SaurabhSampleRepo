/*
 * @author : Sawan
 * @date : 29-06-2017
 */
package com.shatam.b_021_040;


import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTrendMakerHomes extends AbstractScrapper {
	
	public int inr = 0, j = 0;
	CommunityLogger LOGGER;
	
	static int z = 0;
	private static final String builderUrl = "https://www.trendmakerhomes.com/"; 
	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new ExtractTrendMakerHomes();
		a.process();
		FileUtil.writeAllText(	U.getCachePath()+"csv/TRI Pointe Group - Trendmaker Homes.csv", a.data().printAll());
		U.log("REAPTED=" + z);
	}

	public ExtractTrendMakerHomes() throws Exception {

		super("TRI Pointe Group - Trendmaker Homes","https://www.trendmakerhomes.com/");
		LOGGER = new CommunityLogger("TRI Pointe Group - Trendmaker Homes");
		
	}

	public void innerProcess() throws Exception {
	
		String html = U.getPageSource(builderUrl);
		String regSection = U.getSectionValue(html, "Find Your Home", "</ul>");
		String [] regUrls = U.getValues(regSection, "<a class=\"navigation__sub-link\" href=\"", "\"");
		for(String regUrl : regUrls){
			U.log(regUrl);
			if(regUrl.contains("quick-move-ins"))continue;
			String regHtml = U.getPageSource(regUrl);
			if (regUrl.contains("dallas.trendmakerhomes.")) {
				String [] comUrlSections = U.getValues(regHtml, "<div class=\"CommunityCard_inner\"", "Visit Community");
	//			U.log(comUrlSections.length);
				for(String comSec : comUrlSections){
					
					String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
					j++;
	//				try {
					findDallasCommunityDetails("https://dallas.trendmakerhomes.com"+comUrl,comSec);
	//				} catch (Exception e) {
						// TODO: handle exception
	//				}
//					break;
				}
			}else {
			
				if(regUrl.contains("quick-move-ins"))continue;
				String section = U.getSectionValue(regHtml, "id=\"listing\">", "<div class=\"tabular-panes\">");
				String [] comUrlSections = U.getValues(section, "planContent\">", "<div class");
	//			U.log(comUrlSections.length);
				for(String comSec : comUrlSections){
					String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
					if(comUrl.contains("quick-move-ins"))continue;
	//				try {
						findCommunity(comUrl,comSec);
	//				} catch (Exception e) {
						// TODO: handle exception
	//				}
					
				}
			}
		}
		LOGGER.DisposeLogger();
		U.log(j);
	}
	private void findDallasCommunityDetails(String comUrl, String comSec) throws Exception {
		// TODO Auto-generated method stub
		{
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			//if (!comUrl.contains("https://dallas.trendmakerhomes.com/communities/fort-worth/ventana"))return;
			
//			if (!comUrl.contains("https://dallas.trendmakerhomes.com/communities/heath/heath-golf-and-yacht-club"))return;
			U.log("Count =="+j);
			//U.log("subComSec : "+subComSec);
			U.log("comm url--> "+comUrl);
			
			String html = U.getPageSource(comUrl);
			//html = null;
			
			//=========== Community Name ====================
			String comName = U.getSectionValue(html, "<h1 data-reactid=\"", "<br ").trim();
			if(comName != null)
				comName = comName.replaceAll("\\d+\">|<!-- react-text: \\d+ -->|<!-- /react-text -->", "").trim();
			else
			{
				U.log("errrrorrrr");
			}
			comName = comName.replace("90’&amp;", "90’ &");
			U.log("comName =="+comName);
			
		
			
			//================ Section ========================
			String  comInfo = U.getSectionValue(html, "<div class=\"CommunityHeader_imageWrapper","<div class=\"FooterContent\"");
			//U.log("community info-->"+comInfo);
			//============== Notes ===================
			String notes = U.getnote(comInfo);
			
			//============= Floor Plan & Move In Ready Homes Html=================
			String floorHtml = null;
			String moveInHomeHtml = null;
			String [] menuUrls = U.getValues(comInfo, "<div class=\"PlanCard_media\"", "View Plan");
			for(String menuUrl :  menuUrls){
				String Url="https://dallas.trendmakerhomes.com"+U.getSectionValue(menuUrl, "href=\"", "\"");
				String tempHtml=U.getPageSource(Url);
				floorHtml+= menuUrl+U.getSectionValue(tempHtml, "<div class=\"CommunityHeader_contentWrapper\"", "<div class=\"CommunityHomes\" ");
							
			}
			menuUrls = U.getValues(comInfo, "<div class=\"HomeCard_media\"", "View Details");
			for (String menuUrl : menuUrls) {
				String Url="https://dallas.trendmakerhomes.com"+U.getSectionValue(menuUrl, "href=\"", "\"");
				String tempHtml=U.getPageSource(Url);
				moveInHomeHtml+= menuUrl+U.getSectionValue(tempHtml, "<div class=\"CommunityHeader_contentWrapper\"", "<div class=\"CommunityHomes\" ");
//				moveInHomeHtml = menuUrl+U.getPageSource(Url);
			}
			
			//----Map Page----
			String mapHtml = null;
			
			//============== Address =========================
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addressSection ="", mapPage="";
			
			String addressLatLonSec=U.getSectionValue(html, "\"name\":\""+comName.replace("&amp;", "&"), "</script>");
			add[0]=U.getSectionValue(addressLatLonSec, "\"streetAddress\":\"", "\"");
			add[1]=U.getSectionValue(addressLatLonSec, "\"addressLocality\":\"", "\"");
			add[2]=U.getSectionValue(addressLatLonSec, "\"addressRegion\":\"", "\"");
			add[3]=U.getSectionValue(addressLatLonSec, "\"postalCode\":\"", "\"");
			
			if(addressSection != null&&(add[0]==null||add[0].isEmpty())){
				add = findAddress(addressSection);
			}
		//	U.log("______________________________"+add+"1st add____________________");
			U.log("Add =="+Arrays.toString(add));
			//================= LatLng Section =====================
			String[]  latLng = {ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
			String latLngSection = U.getSectionValue(html, "var google_link = '", ";");
			latLng[0]=U.getSectionValue(addressLatLonSec, "latitude\":", ",");
			latLng[1]=U.getSectionValue(addressLatLonSec, "longitude\":", "}");
			if(latLng[0]==ALLOW_BLANK){
				latLngSection=U.getSectionValue(html, "https://maps.google.com/maps?saddr=&amp;daddr=", "\"");
				latLng=latLngSection.split(",");
			}
			if(!latLng[0].contains(".")){
				latLngSection=U.getSectionValue(html, "data-cao-referenceid=", "Directions");
				U.log(latLngSection);
				latLngSection=U.getSectionValue(latLngSection, "https://maps.google.com/maps?saddr=&amp;daddr=", "\"");
				latLng=latLngSection.split(",");
			}
//			
			if(latLngSection != null && latLng[0]==ALLOW_BLANK)
				latLng = findLatLng(latLngSection);
			U.log("LatLng ==="+Arrays.toString(latLng));

			if(add[0].length()<4 && latLng[0].length()>4){
					add = U.getAddressGoogleApi(latLng);
					geo = "True";
			}
			
			String newPrice = "";
			if(html.contains("class=\"title\">"))
			newPrice = U.getSectionValue(html, "class=\"title\">", "</div>").replace("0s", "0,000");
			
			//============= Price ===================
			comSec = comSec.replace("0s", "0,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			//U.log("subcomsec--> "+subComSec);
			String[] price = U.getPrices(U.removeComments(comInfo+comSec+floorHtml+moveInHomeHtml+newPrice).replaceAll("Prices range from \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}.\"}", ""), 
					"Starting At</span>\\$\\d{3},\\d{3}|Price Range: </b>\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</span>|Priced From \\$\\d{3},\\d{3}|\\$\\d+,\\d+|from the \\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

			U.log("MinPrice ::" + minPrice + " MaxPrice ::" + maxPrice);
			
			//=================== Sqft ========================
//			U.log(Util.match(U.removeComments(comInfo+comSec+floorHtml+moveInHomeHtml), ".*1,831.*"));
			html=html.replaceAll("Stories:\\s*</b>\\s*<!-- react-text: \\d+ -->\\s*", "Stories ");
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(U.removeComments(html+comInfo+comSec+floorHtml+moveInHomeHtml),
					"\\d,\\d{3}\\s+</b>\\s+</span>\\s*<span class=\"HomeCard_iconListValue\"|SQFT Range:\\s+</b>\\s+\\d,\\d{3}\\s+-\\s+\\d,\\d{3}\\s+</span>|\\d,\\d{3} - \\d,\\d{3} Sqft.|>\\d,\\d{3} Sq. Ft|\\d,\\d{3} sqft.|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|>\\s+\\d,\\d{3} Sq. Ft|\\d,\\d{3} SQFT",0);
			minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
			maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
			U.log("MinSQf ::" + minSqf + " MaxSqf ::" + maxSqf);

			//======== Combined Floor Htmls ==================
			String combinedFloorHtml = null;
//			U.log(floorHtml);
			if(floorHtml != null){
//				U.log(floorHtml);
				String [] floorUrlSections = U.getValues(floorHtml, "<figure class=\"figure\">", "</a>");
				if(floorUrlSections.length<1)floorUrlSections=U.getValues(floorHtml, " <a class=\"", "<a class=\"CommunityPlans_viewPlan");
				for(String floorUrlSec : floorUrlSections){
//					U.log(floorUrlSec);
					String floorUrl = U.getSectionValue(floorUrlSec, "href=\"", "\"");
					String floorPlanHtml = U.getPageSource("https://dallas.trendmakerhomes.com"+floorUrl);
					U.log("floorUrl ::"+floorUrl);
					combinedFloorHtml += U.getSectionValue(floorPlanHtml, "<div id=\"floorPlan\"", "<div class=\"salesPrice");
//					U.log(combinedFloorHtml);
					if(combinedFloorHtml.contains("null"))combinedFloorHtml+=U.getSectionValue(floorPlanHtml, "<div class=\"CommunityHeader_contentWrapper\" ", " CALCULATE PAYMENT");
				}
			}
			//========== Combined Move In Ready Home Htmls ===================
			String combinedReadyHtmls = null;
			if(moveInHomeHtml != null){
//				U.log("MOVEINREADY");
				String readyUrlSections [] = U.getValues(moveInHomeHtml, "<figure class=\"figure\">", "</a>");
				for(String readyUrlSec : readyUrlSections){
					String readyUrl = U.getSectionValue(readyUrlSec, "<a href=\"", "\"");
					String readyHtml = U.getPageSource(readyUrl);
					U.log("readyUrl ::"+readyUrl);
					combinedReadyHtmls += U.getSectionValue(readyHtml, "<p>", "<script>");
				}
			}
			//U.log(combinedFloorHtml);	
			//for /villas-royal-brook-65/
						//================= Property Type ==================
			comInfo = comInfo.replaceAll("data-sheets-value=(.*?)>|residents experience unlimited opportunities|on/\">\\s+Vill|or/\">\\s+Vill|50/\">\\s+Vill|ds/\">\\s+Villa|60/\">\\s+Villas|void(0);\">\\s+Villas|on/villa|me\": \"Vill|Villages", "");
//			U.log(combinedFloorHtml);
			String propType = U.getPropType(comInfo+moveInHomeHtml+combinedFloorHtml);
			
			//================== Community Type ===============
			//comInfo=comInfo.replace("Creek Ranch","");
			//U.log(comInfo);
			String comType = U.getCommunityType(comInfo);
			
			//================== Derived Property Type =============
              //U.log("**************************"+comInfo+"***************");
			String dtypesHtml=U.getdCommType(html).replace("Ranch", "");
            comInfo = comInfo.replaceAll("offered in the grand opening section|1890 Ranch Shopping Cente|[R|r]ancho|pagerAnchorBuilder|data-sub-html=\"LaCenterra city centre in Cinco Ranch","").replace("NEW SECTION NOW OPEN", "new section now open").replaceAll("<span>\\s*Now Selling\\s*</span>\\s*</figure>", "");
			String derivedPType = U.getdCommType(U.removeComments((comInfo+combinedFloorHtml+dtypesHtml)).replaceAll("Cross Creek Ranch|Highlands at Mayfield Ranch|4 bedroom,|chisholm-trail-ranch|Craig Ranch|Chisholm Trail Ranch", ""));
//			U.log(Util.matchAll((html+comInfo+combinedFloorHtml),"[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}",0));
	
			//================= Property Status =============
			//String statussec=U.getSectionValue(html, "div class=\"communtyContent neighbourhood\">", "</div>");
			//U.log(comInfo);
			String propStatus = U.getPropStatus(comSec+comInfo);
			if(comUrl.contains("/cross-creek-ranch-60/")||comUrl.contains("/cross-creek-ranch-65/"))
				propStatus=propStatus+",New Section Now Open";
			if(propStatus.contains("Coming Early 2019, Coming Soon"))propStatus="Coming Early 2019";
//			if(comUrl.contains("/fort-worth/lakes-of-river-trails"))
//					propStatus=propStatus.replace("New Section Open", "New Section Opening Spring 2019");
			//New Section Opening in Spring 2019
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].replace(" |", ""), add[1], add[2], add[3]);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(propType, derivedPType);
			data.addPropertyStatus(propStatus);
			data.addNotes(notes);		
		}
		
		j++;
	}
	int i = 0;
	private void findCommunity(String url, String comSec) throws Exception {
		//if(i == 3)
		{
			//U.log("community no--> "+i);
			//U.log("subRegUrl : "+url);
			String subRegHtml = U.getPageSource(url);
			String section = U.getSectionValue(subRegHtml, "<div class=\"listing\">", "<div class=\"clearfix");
//			U.log(section);
			if(section != null){
				String subComSections [] = U.getValues(section, "<figure class=\"figure\">", "class=\"viewGallery\">");
				U.log("sub comm section"+subComSections.length);
				LOGGER.AddCommunityUrl("Main Community ==>"+url+"\tSubCommunityCount ==>"+subComSections.length);
				for(String subComSec :  subComSections){
					String comUrl =  U.getSectionValue(subComSec, "<a href=\"", "\"");
				//	U.log("communbity url--> "+comUrl);
					findCommunityDetails(comUrl,subComSec,subRegHtml);
					j++;
				}
			}else if(section == null){
				LOGGER.AddCommunityUrl("Main Community ==>"+url+"\tSubCommunityCount ==> 0");
				j++;
				findCommunityDetails(url, comSec,subRegHtml);
			}
		}
		
	}

	private void findCommunityDetails(String comUrl, String subComSec, String subRegHtml) throws Exception {
		//if(j==16 )
		//if (!comUrl.contains("https://dallas.trendmakerhomes.com/communities/fort-worth/ventana"))return;
		
		
		{
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			
			LOGGER.AddCommunityUrl(comUrl);
			
			U.log("Count =="+j);
			//U.log("subComSec : "+subComSec);
			U.log("comm url--> "+comUrl);
			
			String html = U.getPageSource(comUrl);
			//html = null;
			
			//=========== Community Name ====================
			String comName = U.getSectionValue(html, "<h1 class=\"neighborhood--title\">", "<").trim();
			if(comName != null)
				comName = comName.trim();
			else
			{
				U.log("errrrorrrr");
			}
			comName = comName.replace("90’&amp;", "90’ &");
			U.log("comName =="+comName);
			
		
			
			//================ Section ========================
			String  comInfo = U.getSectionValue(html, "<div class=\"innerStr innerStr_banner\">"," <footer class=\"footer\">");
			//U.log("community info-->"+comInfo);
			//============== Notes ===================
			String notes = U.getnote(comInfo);
			
			//============= Floor Plan & Move In Ready Homes Html=================
			String floorHtml = null;
			String moveInHomeHtml = null;
			String menuSection = U.getSectionValue(comInfo, "div class=\"mobileMenuInner", "</ul>");
			String [] menuUrls = U.getValues(menuSection, "<a href=\"", "\"");
			for(String menuUrl :  menuUrls){
				if(menuUrl.contains("floorplans"))
					floorHtml = U.getPageSource(menuUrl);
				if(menuUrl.contains("move-in-ready"))
					moveInHomeHtml = U.getPageSource(menuUrl);
			
			}
			
			//----Map Page----
			String mapHtml = null;
			if(html.contains("Map &amp; Directions")){
				String mapUrl = Util.match(html, "<li>\\s*<a href=\"(.*?)\">\\s*Map &amp; Directions\\s*</a>\\s*</li>",1);
				U.log("mapUrl : "+mapUrl);
				if(!mapUrl.contains("http"))mapUrl = comUrl+mapUrl;
				mapHtml = U.getHTML(mapUrl);
				if(mapHtml==null)mapHtml=ALLOW_BLANK;
			}
			//============== Address =========================
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addressSection ="", mapPage="";
			
			addressSection = Util.match(html, "<br/>\\s*(.*?)\\s*<br/>\\s*<a href=\"http[s]*://map",1);//U.getSectionValue(html, "var markers = [[\"", "];");
			U.log("addressSection :"+addressSection);
			if(addressSection == null && mapHtml !=null ){
				//U.log(mapHtml);
				addressSection = Util.match(mapHtml, "Get directions to reach (.*?) - (.*?). Get in touch ",2);
				//addressSection = U.formatAddress(addressSection);
				
			}
			if(add[0].length()<3 &&(mapHtml!=null && mapHtml.contains("neigh_address"))){
				addressSection=U.getSectionValue(mapHtml, "<div class=\"neigh_address\">", "<a ");
				addressSection=U.getSectionValue(addressSection, "</strong><br>", "<br>");
				U.log(addressSection); 
			}
			if(addressSection != null){
				add = findAddress(addressSection);
			}
		//	U.log("______________________________"+add+"1st add____________________");
			U.log("Add =="+Arrays.toString(add));
			//================= LatLng Section =====================
			String[]  latLng = {ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
			String latLngSection = U.getSectionValue(html, "var google_link = '", ";");
			if(latLngSection == null && mapHtml !=null){
				latLngSection = U.getSectionValue(mapHtml, "var google_link = '", ";");
			}
			if(latLng[0]==ALLOW_BLANK){
				latLngSection=U.getSectionValue(html, "https://maps.google.com/maps?saddr=&amp;daddr=", "\"");
				latLng=latLngSection.split(",");
			}
			if(!latLng[0].contains(".")){
				latLngSection=U.getSectionValue(html, "data-cao-referenceid=", "Directions");
				U.log(latLngSection);
				latLngSection=U.getSectionValue(latLngSection, "https://maps.google.com/maps?saddr=&amp;daddr=", "\"");
				latLng=latLngSection.split(",");
			}
//			
			if(latLngSection != null && latLng[0]==ALLOW_BLANK)
				latLng = findLatLng(latLngSection);
			U.log("LatLng ==="+Arrays.toString(latLng));

			if(add[0].length()<4 && latLng[0].length()>4){
					add = U.getAddressGoogleApi(latLng);
					geo = "True";
			}
			
			String newPrice = "";
			if(html.contains("class=\"title\">"))
			newPrice = U.getSectionValue(html, "class=\"title\">", "</div>").replace("0s", "0,000");
			
			//============= Price ===================
			subComSec = subComSec.replace("0s", "0,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			//U.log("subcomsec--> "+subComSec);
			String[] price = U.getPrices(comInfo+subComSec+floorHtml+moveInHomeHtml+newPrice, 
					"Priced From \\$\\d{3},\\d{3}|\\$\\d+,\\d+|from the \\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

			U.log("MinPrice ::" + minPrice + " MaxPrice ::" + maxPrice);
			
			//=================== Sqft ========================
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(comInfo+subComSec+floorHtml+moveInHomeHtml,
					"\\d,\\d{3} - \\d,\\d{3} Sqft.|>\\d,\\d{3} Sq. Ft|\\d,\\d{3} sqft.|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|>\\s+\\d,\\d{3} Sq. Ft|\\d,\\d{3} SQFT",0);
			minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
			maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
			U.log("MinSQf ::" + minSqf + " MaxSqf ::" + maxSqf);

			//======== Combined Floor Htmls ==================
			String combinedFloorHtml = null;
			if(floorHtml != null){
				String [] floorUrlSections = U.getValues(floorHtml, "<figure class=\"figure\">", "</a>");
				for(String floorUrlSec : floorUrlSections){
					String floorUrl = U.getSectionValue(floorUrlSec, "<a href=\"", "\"");
					String floorPlanHtml = U.getPageSource(floorUrl);
					U.log("floorUrl ::"+floorUrl);
					combinedFloorHtml += U.getSectionValue(floorPlanHtml, "<div id=\"floorPlan\"", "<div class=\"salesPrice");
				}
			}
			//========== Combined Move In Ready Home Htmls ===================
			String combinedReadyHtmls = null;
			if(moveInHomeHtml != null){
				String readyUrlSections [] = U.getValues(moveInHomeHtml, "<figure class=\"figure\">", "</a>");
				for(String readyUrlSec : readyUrlSections){
					String readyUrl = U.getSectionValue(readyUrlSec, "<a href=\"", "\"");
					String readyHtml = U.getPageSource(readyUrl);
					U.log("readyUrl ::"+readyUrl);
					combinedReadyHtmls += U.getSectionValue(readyHtml, "<p>", "<script>");
				}
			}
			//U.log(combinedFloorHtml);	
			//for /villas-royal-brook-65/
			if(comUrl.contains("/villas-royal-brook-65/")){
			menuSection = U.getSectionValue(html, "<ul class=\"nav navbar-nav\">", "</ul>");
			menuUrls = U.getValues(menuSection, "<a href=\"", "\"");
			for(String menuUrl :  menuUrls){
				U.log("menuUrl : "+menuUrl);
				if(menuUrl.contains("plan"))
					combinedFloorHtml+=U.getHTML(menuUrl);
					
			}
			combinedFloorHtml=combinedFloorHtml.replaceAll("pagerAnchorBuilder:| home or common area will offe", "");
			}
			//================= Property Type ==================
			comInfo = comInfo.replaceAll("data-sheets-value=(.*?)>|residents experience unlimited opportunities|on/\">\\s+Vill|or/\">\\s+Vill|50/\">\\s+Vill|ds/\">\\s+Villa|60/\">\\s+Villas|void(0);\">\\s+Villas|on/villa|me\": \"Vill|Villages", "");

			String propType = U.getPropType(comInfo+combinedReadyHtmls+combinedFloorHtml);
			
			//================== Community Type ===============
			//comInfo=comInfo.replace("Creek Ranch","");
			//U.log(comInfo);
			String comType = U.getCommunityType(comInfo);
			
			//================== Derived Property Type =============
              //U.log("**************************"+comInfo+"***************");
              comInfo = comInfo.replaceAll("offered in the grand opening section|1890 Ranch Shopping Cente|[R|r]ancho|pagerAnchorBuilder|data-sub-html=\"LaCenterra city centre in Cinco Ranch","").replace("NEW SECTION NOW OPEN", "new section now open").replaceAll("<span>\\s*Now Selling\\s*</span>\\s*</figure>", "");
			String derivedPType = U.getdCommType((comInfo+combinedFloorHtml).replaceAll("Cross Creek Ranch|Ranch High School|Highlands at Mayfield Ranch|4 bedroom,", ""));
					
			//================= Property Status =============
			//String statussec=U.getSectionValue(html, "div class=\"communtyContent neighbourhood\">", "</div>");
//			U.log(subComSec);
			U.log(Util.match(comInfo, ".*New Section Open.*"));
//			String pageStatus=U.getSectionValue(html, "<div class=\"communtyContent neighbourhood\">", "   <ul>");
//			U.log(pageStatus);
			String propStatus = U.getPropStatus((subComSec+comInfo).replaceAll("<span>\\s+Coming Soon\\s+</span>", ""));
			if(comUrl.contains("/cross-creek-ranch-65/")||comUrl.contains("austin/rancho-sienna-60/") )
				propStatus=propStatus+", New Section Now Open";
			if(propStatus.contains("Coming Early 2019, Coming Soon"))propStatus="Coming Early 2019";
			if(comUrl.contains("/houston/cross-creek-ranch-60/"))
					add[0]="3867 Desert Springs Lane";
			//New Section Opening in Spring 2019
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(propType, derivedPType);
			data.addPropertyStatus(propStatus);
			data.addNotes(notes);		
		}
		
		j++;
	}
	private  String [] findLatLng(String latLngSection){
		String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
		latLngSection = latLngSection.replace("!3m1!4b1!4m5!3m4!1s0x0:0x0!8m2!3d", "");
		//U.log(latLngSection);
		latLngSection = latLngSection.replace("addr=&daddr", "");
		latLngSection = U.getSectionValue(latLngSection, "=", "'");
		latLngSection = latLngSection.replace("%2C", ",").replace("!4d", ",");
		//U.log(latLngSection);
		latLng = latLngSection.split(",");
		return latLng;
	}
	private String [] findAddress(String addressSection){
		addressSection = addressSection.replace("13303 Fairfield Arbor Ln, 13303 Fairfield Arbor Ln", "13303 Fairfield Arbor Ln")
						.replace("4730 Orchard Creek Lane, 4730 Orchard Creek Lane ", "4730 Orchard Creek Lane");
		String state = "",city = "",zip = "",street = "";
		String [] add = null;
	
		U.log(addressSection);
		//-----zip-------
		zip = Util.match(addressSection, ", (\\w+)\\s+(\\d{5})",2);
		U.log("zip : "+zip);
		//--------state---------
		state = Util.match(addressSection, ", (\\w+)\\s+\\d{5}",1);
		U.log("State is : "+state);
		
		//--------city---------
		if(state != null){
			city = U.getCity(addressSection, state);
		}
		city =city.replace(",", "");
		U.log("city is : "+city);
		//--------street---------
		if(city != null){
			street = addressSection.substring(0,addressSection.indexOf(city)).trim();
		}
		street =street.replace(",", "");
		U.log("street is : "+street);
		
		//add = findAddress(addressSection);
		
		add = new String [] {street,city,state,zip};
		return add;
	}

}
