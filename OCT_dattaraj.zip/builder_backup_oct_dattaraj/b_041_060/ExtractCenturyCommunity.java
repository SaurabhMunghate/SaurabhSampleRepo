/** @author Parag Humane
 *  @date 27/05/2013 
 *  Modification Priti...
 *  
 */

package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.regexp.recompile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;

public class ExtractCenturyCommunity extends AbstractScrapper {
	int i = 0,  duplicate = 0;
	public int inr = 0;
	static int k=0,j=0,count=0,m=0;
	WebDriver driver=null;

	CommunityLogger LOGGER;
	static String BASEURL = "https://www.centurycommunities.com/";
	
	//date 18 dec2021
	
	

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractCenturyCommunity();
		a.process();
		//a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Century Communities.csv", a.data()
				.printAll());
	}

	public ExtractCenturyCommunity() throws Exception {

		super("Century Communities", "https://www.centurycommunities.com/");
		LOGGER = new CommunityLogger("Century Communities");
	}

	public void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();

		
		String baseHtml=U.getHTML("https://www.centurycommunities.com/");
//		String stateSecUrl=U.getSectionValue(baseHtml, "Find Your Home</a>", "<a href=\"/homebuying-process\">Homebuyers</a>");
//		String[] metroStateUrls=U.getValues(stateSecUrl, "<a href=\"", "\">");
//		for(String subMetro:metroStateUrls) {
//			
//		}
		
//		String stateSec=U.getSectionValue(baseHtml, "Select Location", "</select>");
//		String[] regions=U.getValues(stateSec,"\">","</option>");
//		
//		String subRegSec=U.getSectionValue(baseHtml, "name=\"InterestedInMetro\" ","</select>");
//		String [] subRegion=U.getValues(subRegSec, "<optgroup", "</optgroup>");
//		for(String mainReg:subRegion) {
//			String state=U.getSectionValue(mainReg, "label=\"", "\">");
//			U.log("State"+state);
//			String metroSec[]=U.getValues(mainReg, "<option value=\"", "</option>");
//			for(String metro:metroSec) {
////				U.log("Mterp"+metro);
//			//	metro=metro.replaceAll("<option value=\"\\d+\">", "").trim();
//				metro=metro.replaceAll("\\d+\">|,", "");
//				metro=metro.replace("/","-");
//				if(metro.contains("Colorado Springs "))
//					metro="colorado springs metro";
//				if(metro.contains("SC Charlotte Metro"))
//					metro=metro.replace("SC ", "");
//				String regUrl="https://www.centurycommunities.com/find-your-home/"+state.toLowerCase().replace(" ", "%20");
//			    U.log(regUrl);
//			    if(regUrl.contains("https://www.centurycommunities.com/find-your-home/north%20carolina/greensboro/high-point-metro"))
//			      continue;
			    String stateSecUrl=U.getSectionValue(baseHtml, "Find Your Home</a>", "<a href=\"/homebuying-process\">Homebuyers</a>");
				String[] metroStateUrls=U.getValues(stateSecUrl, "<a href=\"", "\">");
				for(String regionUrls:metroStateUrls) {
					regionUrls="https://www.centurycommunities.com"+regionUrls;
//					U.log("regionUrls :: "+regionUrls);
					if(regionUrls.contains("https://www.centurycommunities.com/find-your-home/florida/southeast-florida-metro")) {
			    		continue;
			    	}
			    String regHtml=U.getHTML(regionUrls);
			  //  U.log("rr"+regHtml);
			    String[] commSec=U.getValues(regHtml, "<div class=\"col-xl-4 col-lg-6 col-sm-6 community-column\">", "<a class=\"btn community-button\"");
//			    U.log(commSec.length);
			    if(commSec==null)
			    	commSec=U.getValues(regHtml, "<h2 class=\"title\">", "<div class=\"button-link\">");
			   
			 //   String[] commSec=U.getValues(regHtml, "<a class=\"btn community-button\"", "View Homes");
//			    U.log("comm in reg"+state+">>"+metro+"are::"+commSec.length);
			    for(String comSec:commSec) {
			    //	U.log("COMSEC"+comSec);
			    	String comUrl=U.getSectionValue(comSec, "<a href=\"", "\">");
			    	comUrl="https://www.centurycommunities.com/"+comUrl;
//			    	U.log("Url"+comUrl);
			    	String comNameSec=U.getSectionValue(comSec,"<p class=\"company-name\">", "/a>");
			    //	U.log("Com namew Sec"+comNameSec);
			    	String comName=U.getSectionValue(comNameSec,"\">", "<");
//			    	U.log("Community name"+comName);
			    	addDetails(comUrl,comName,comSec);
			    	m++;
			    }
			}
			
			//if(state.contains("Indiana")) {
			
			
			//}
//			}
			
			String mregUrl="https://www.centurycommunities.com/find-your-home/indiana/louisville-metro";
		    String mregHtml=U.getHTML(mregUrl);
		    String mcommSec[]=U.getValues(mregHtml, "<div class=\"col-xl-4 col-lg-6 col-sm-6 community-column\">","<a class=\"btn community-button\"");
		   for(String mcomSec:mcommSec) {
//			   U.log("Inside indiana="+mcommSec.length);
		    String comUrl=U.getSectionValue(mcomSec, "<a href=\"", "\">");
	    	comUrl="https://www.centurycommunities.com/"+comUrl;
//	    	U.log("Url"+comUrl);
	    	String mcomNameSec=U.getSectionValue(mcomSec,"<p class=\"company-name\">", "/a>");
		    //	U.log("Com namew Sec"+comNameSec);
		    	String mcomName=U.getSectionValue(mcomNameSec,"\">", "<");
//		    	U.log("Community name="+mcomName);
		    	
		    	addDetails(comUrl,mcomName,mcomSec);
		    	m++;
		    	U.log("total"+m);
		}
//			driver.quit();		


		LOGGER.DisposeLogger();
//		
	}
	
	private void addDetailsOne(String comUrl, String communityName, String comInfo) throws Exception {
		
//		try{
		//if(j>=277)
//		if(j>=0 && j<=50)//d
//			if(j>=50 && j<=100)//d
//				if(j>=100 && j<=150)
//					if(j>=150 && j<=200)
//						if(j>=200 && j<=250)
//		if(j>=140 && j<=200)
//			if(j>=211 && j<=250)
//		if(j>340)
		{
				U.log("count   "+j);
			//TODO :		
//			if(!comUrl.contains("https://www.centurycommunities.com//find-your-home/california/northern-california-metro/antioch/vista-ii")) return;
		
			/**
			 * @author Sawan Meshram
			 * @date 17 Jan 2022
			 */
//			if(comUrl.contains("https://www.centurycommunities.com//find-your-home/washington/seattle-metro/puyallup/pines-at-sunrise")){
//				LOGGER.AddCommunityUrl(comUrl+"-------------> Page Not Found");
//				return;
//			}

			if(comUrl.contains("https://www.centurycommunities.com//find-your-home/texas/austin-metro/leander/crystal-springs/crystal-springs-falls")) {
				LOGGER.AddCommunityUrl("=======Page Not found======"+comUrl);
				return;
			}
			
		if(this.data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"**************************repeat");
			k++;
			return;
		}	
		LOGGER.AddCommunityUrl(comUrl);
		
		
		if(communityName != null)
			communityName  = communityName.replaceAll("Paired Homes|Manor", "").replaceAll("Cottages$|- Parker City| - SOLD OUT| - Winterville| - Lake City", "");
		U.log("\n:::::::::::::::"+j+":::::::::::::::::::::::::\n");
		communityName=communityName.replaceAll("Cross Creek - Freeport","Cross Creek")
				.replaceAll("Stonewall Villas","Stonewall")
				.replaceAll("American Fork Crossing Villas","American Fork Crossing");
		U.log("communityName======= "+communityName);
		U.log("comUrl::::::::"+comUrl);
		U.log(U.getCache(comUrl));
		
		String html=U.getHTML(comUrl);
		String galleryflagStatu= U.getSectionValue(html, "<div class=\"gallery_flags\">", "</div");
		U.log("flag status:::"+galleryflagStatu);
		
		String overviewSec=U.getSectionValue(html, " <div class=\"overview-description \">", "</div")+U.getSectionValue(html, "\"description\":\"", "\"")
		+U.getSectionValue(html, "<div class=\"overview-description full\">", "</div>");
		
		
		/*
		 * Remove section
		 */
		String[] remove = U.getValues(html, "<div class=\"modal-body\">", "</button>");
		for(String rem : remove) html = html.replace(rem, "");
		
		remove = U.getValues(html, "<div class=\"per-month-price price_container hide-content\">", "<div class=\"starting-price\">");
		for(String rem : remove) html = html.replace(rem, "");
		

		String remove1 = U.getSectionValue(comInfo, "<div class=\"community-per-month-price price-container hide-content\">", "<div class=\"community-starting-price\">");
		if(remove1!=null)comInfo = comInfo.replace(remove1, "");
		
		
		remove1=U.getSectionValue(html, "<div class=\"similar-communities\" data-name=\"\">","<script type=\"text/javascript\">");
		if(remove1!=null) html=html.replace(remove1, "");
		
//		=================================================================================
		String[] lot_data=null;
		String lotCount=ALLOW_BLANK;
		String maplink_Sec=U.getSectionValue(html, "<a class=\"btn button-secondary\" href=\"", "\"");
		U.log("maplink_Sec >>>>>>>>"+maplink_Sec);
		String mapHtml=ALLOW_BLANK;
		if(maplink_Sec!=null) {
		mapHtml=U.getHtml(maplink_Sec, driver);
		if(mapHtml!=null) {
		if(maplink_Sec.contains("SiteMapPreview") || maplink_Sec.contains("SiteOverview")) {
			lotCount=Util.getUnits(mapHtml);
		}
		else if(maplink_Sec.contains("photos/maps") ) {
			String Sec=U.getSectionValue(mapHtml, "<svg version", "</svg>");
			lot_data=U.getValues(Sec, "id=\"lot", ">");
			lotCount= Integer.toString(lot_data.length);
		}
		else {
		lotCount=Util.getUnitsByMatch(mapHtml);
		}
		}
		}
		U.log("======lotCount=="+lotCount);
		
		}
		
	} 

	
	private void addDetails(String comUrl, String communityName, String comInfo) throws Exception {
//		
		{

			//TODO :		
			U.log("count   "+j);
		U.log("communityName======= "+communityName);
		U.log("comUrl::::::::"+comUrl);
		U.log(U.getCache(comUrl));
		
		String html=U.getHTML(comUrl);
		

//				=================================================================================
				String[] lot_data=null;
				String lotCount=ALLOW_BLANK;
				String maplink_Sec=U.getSectionValue(html, "<a class=\"btn button-secondary\" href=\"", "\"");
				U.log("maplink_Sec >>>>>>>>"+maplink_Sec);
				String mapHtml=ALLOW_BLANK;
				if(maplink_Sec!=null) {
				mapHtml=U.getHtml(maplink_Sec, driver);
				if(mapHtml!=null) {
				if(maplink_Sec.contains("SiteMapPreview") || maplink_Sec.contains("SiteOverview")) {
					lotCount=Util.getUnits(mapHtml);
				}
				else if(maplink_Sec.contains("photos/maps") ) {
					String Sec=U.getSectionValue(mapHtml, "<svg version", "</svg>");
					lot_data=U.getValues(Sec, "id=\"lot", ">");
					lotCount= Integer.toString(lot_data.length);
				}
				else {
				lotCount=Util.getUnitsByMatch(mapHtml);
				}
				}
				}
		
	}
		j++;
		
//	}catch (Exception e) {}
	}
	

	
	public  String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName =U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode =U.CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "application/json, text/plain, */*");
//			urlConnection.addRequestProperty("Accept-Language","en-us,en;q=0.5");
			urlConnection.addRequestProperty("Referer", "https://myscp.ml3ds-icon.com/");
			urlConnection.addRequestProperty("x-ml-date", "Wed, 20 Apr 2022 12:21:41 GMT");
			urlConnection.addRequestProperty("Authorization", "converge.apiuser@medialabinc.local BbFockVcW28KhRFvQ4x83ER6i7bks6qM51z9jGre0S8=");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}