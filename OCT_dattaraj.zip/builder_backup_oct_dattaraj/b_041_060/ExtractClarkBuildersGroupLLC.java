package com.shatam.b_041_060;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.xerces.impl.io.Latin1Reader;
import org.openqa.selenium.remote.html5.AddWebStorage;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractClarkBuildersGroupLLC extends AbstractScrapper {

	/**
	 * @param args
	 */
	public static int j = 0, count = 0, repeated = 0;
	CommunityLogger LOGGER;
	HashMap<String, String> checkUrl = new HashMap<>();
	private static final String builderUrl = "https://www.cbgbuildingcompany.com";

	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractClarkBuildersGroupLLC();
		// U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "CBG Building Company.csv", a.data().printAll());
		U.log("total communit" + count);
		U.log(count - j);
		U.log("repeated::" + repeated);
	}

	public ExtractClarkBuildersGroupLLC() throws Exception {
		// TODO Auto-generated constructor stub
		super("CBG Building Company", "https://www.cbgbuildingcompany.com/");
		LOGGER = new CommunityLogger("CBG Building Company");
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		int totalCount = 0;
		String html = U.getHTML("https://www.cbgbuildingcompany.com/work/multifamily-mixed-use/");
		String pages[] = U.getValues(html, "<a class=\"page-numbers\" href=\"", "\"");

		String NwComSec = U.getSectionValue(html, "<nav class=\"sidebar_menu\">", "</nav>");
		String NwComSecUrls[] = U.getValues(NwComSec, "<a href=\"", "\">");
		for (String page : pages) {
			U.log("page===" + page);
			html += U.getHTML(page);
		}

		for (String NwComSecUrl : NwComSecUrls) {
			U.log("NwComSecUrl==" + NwComSecUrl);
			html += U.getHTML(NwComSecUrl);
		}
		String regn = U.getSectionValue(html, ">Regions</a>", "</ul>");
		String[] rgnUrl = U.getValues(regn, "href=\"", "\">");
		if (rgnUrl.length > 0) {
			for (String regnUrl : rgnUrl) {
				if (!regnUrl.equals("https://www.cbgbuildingcompany.com/offices/")) {
					html += U.getHTML(regnUrl);
				}
			}
		}

//		String regSec = U.getSectionValue(html, "com/Portfolio\">PORTFOLIO</a>", "</div>");
//
		String[] comSec = U.getValues(html, "<li class=\"college_item_wrap\"", "</li>");
		U.log(comSec.length);
		for (String com : comSec) {
			// U.log("com:: "+com);
			String url = U.getSectionValue(com, "<a class=\"college_item\" href=\"", "\"");
//			U.log("url==="+url);
			findDetails(url, com);
		}
		totalCount += comSec.length;
		U.log("TotalCount==" + totalCount);

		U.log(j + "::::::::::::::::");
		LOGGER.DisposeLogger();
	}

	private void findDetails(String commUrl, String com) throws Exception {
		// TODO Auto-generated method stub
//		if(!commUrl.contains("https://www.cbgbuildingcompany.com/projects/camden-westwind/")) return;

		U.log("Count: " + j);

		// if(j>=232)
		{
			String html = U.getHTML(commUrl);
			
			String rm = U.getSectionValue(html, "<div class=\"related_projects\">", "</html");
			html = html.replace(rm, "");
			String rm1 = U.getSectionValue(html, "<div class=\"project_col desktop_mod\">",
					"<div class=\"project_col_wrap project");
			if (rm1 != null) {
				html = html.replace(rm1, "");
			}
			U.log("===>" + commUrl);
			U.log(U.getCache(commUrl));
			if (this.data.communityUrlExists(commUrl)) {
				repeated++;
				LOGGER.AddCommunityUrl(commUrl + "=============>repeated");
				return;
			}
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/san-diego-family-housing/")) {

				LOGGER.AddCommunityUrl(commUrl + "=======Return======>community present in two different state");
				return;
			}

			LOGGER.AddCommunityUrl(commUrl);
			// ============================================note====================================================================
			String note = U.getnote(html);
			U.log("note--->" + note);
			// ==========================================Community name
			// section==========================================================
			String communityName = U.getSectionValue(com, "<div class=\"college_title\">", "</div>");
			communityName = communityName.replace(" ??? Phase", " - Phase")
					.replaceAll("Condominiums$|Dallas Apartments$|Lofts$|Apartments$| Downtown Columbia$", "");
			U.log("CommunityName--->" + communityName);

			communityName = communityName.replace("&amp;", "&");
			communityName = communityName.replace("&#176; ", " ");
			communityName = communityName.replaceAll("Shannon&#39;s", "Shannon's").replaceAll(" Apartment Homes$", "");
			communityName = communityName.replace("Apartments (PS Phase II)", "");
			communityName = communityName.toLowerCase();
			communityName = communityName.replace("360� H Street", "360 H Street");
			U.log("CommunityName--->" + communityName + ":::::::::::::::::");

			communityName = communityName.replaceAll("Columbia|Apartment Homes$|Apartments$|Lofts$", "");

			// ==========================================Address
			// section=================================================================
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String addSec = U.getSectionValue(html, "<div class=\"address_text\">", "</div>");
			U.log(addSec);

			if (addSec != null) {
				// addSec=addSec.replace("7000 Wisconsin Ave, Chevy Chase, MD 20815", "7000
				// Wisconsin Ave,Chevy Chase,MD 20815");
				addSec = U.getSectionValue(addSec, "<p>", "</p>");
				if (addSec != null) {
					addSec = addSec.replaceAll("\\s*<br/>\\s*", ",");
					U.log(addSec);
					add = U.getAddress(addSec);
				}

			}
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/uc-davis-orchard-park/")) {
				add[0] = "UC davis Orchard park";
				add[1] = "Davis";
				add[2] = "CA";
				add[3] = "95616";
				geo = "TRUE";
			}
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/7000-wisconsin")) {
				add[0] = "7000 Wisconsin Ave";
				add[1] = "Chevy Chase";
				add[2] = "MD";
				add[3] = "20815";

			}
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/san-diego-family-housing/")) {
				add[1] = "Nevada";
				add[2] = "CA";
				latlag = U.getlatlongGoogleApi(add);
				add = U.getAddressGoogleApi(latlag);
				geo = "True";

			}
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/brightleaf-cooper/")) {
				add[0] = "509 N Saint Asaph St";
			}

			add[0] = add[0].replace("24746 Tribe Square/Hutchinson Farm Drive", "24746 Tribe Square");
			add[0] = add[0].replace("11107 Eisenhower (E) Street", "11107 Eisenhower E Street")
					.replace("6603 South Trask St Tampa Fl 33616", "6603 South Trask St");
			// add[0]=add[0].replace("8300,8310 & 8320 Colesville Road","8300, 8310 & 8320
			// Colesville Road");

			U.log("ADDRESS===="+Arrays.toString(add));
			latlag[0] = U.getSectionValue(html, "data-x=\"", "\"");
			latlag[1] = U.getSectionValue(html, "data-y=\"", "\"");
			U.log("latlag===="+Arrays.toString(latlag));
			if (add[3] == ALLOW_BLANK && add[0].length() > 2 && latlag[0] != ALLOW_BLANK) {
				add[3] = U.getAddressGoogleApi(latlag)[3];
				geo = "True";
			}
			if (add[0].length() < 2 && add[1].length() < 2 && add[2].length() < 2 && latlag[0] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latlag);
				geo = "True";
			}
			html = html.replace("$47,443,000 Construction Financing", "");
			html = html.replaceAll(
					" \\$89,000 for Children of Military|used \\$750,000 worth of keystone|6,568 SF of ground-floor reta| features 15,000 square feet of restaurant,|16,000 square feet of street-level retail space |69,900 square feet of retail space |2,200 square feet of ground floor retail|introduce over 66,000 square feet|rental apartments totaling 401,297 square feet|19,298 square feet of retail space|2,675 square feet of cultural|3,011 square feet of leasable",
					"");
//				html = html.replaceAll("\\d+,\\d+ square feet of retail", "");
			String remove = "\\d+,\\d+ Square Feet of Retail|\\d+,\\d+ square feet of community retail|\\d+,\\d+ square feet of retail|\\d+,\\d+ square feet of ground floor retail|\\d+,\\d+ square feet of ground-floor retail|\\d+,\\d+ square feet of retail space|800,000 square feet of office and hotel space| 2,150 square feet of street-level retail | 3,600 SF clubhouse|14,000 square feet of leasable retail |70,000 square feet of in-line |6,450|70,441 square feet of ground-floor retail|2,100 SF maintenance|6,000 SF LEED community center|6,000 square feet welcome center|4,200 SF Neighborhood Center| and 45,000 SF|45,000 square feet of retail, and 25,000 square feet|parking and 4,300|parking and a 76,000|130,820 SF building|6871 square foot clubhouse |4,000 SF clubhouse| 9,000 SF clubhouse| 25,000 square feet of flex retail|10,000 square feet of ground floor retail|10,500 square feet of community|4,700 SF of amenity areas|2,000 SF fitness center|$89,000 for Children of Military|1,150 square feet and feature|verage 1,100 SF each|4,700 square feet of office | 10,000 square feet of restaurant |2,500 square feet of street-level retail |1,250 square feet and featuring|over 22,900 square feet of public|30,000 square feet of retail | 5,000 SF Ground Floor Retail|3,500 square feet of retail space|8,000 square feet of retail|7,100 square feet of ground floor|20,000 square feet of common area amenities|etail spaces totaling 21,000 square feet | 11,856 square feet of retail space|a 55,000 square foot cast|26,000 square feet of amenity area|22,165 square feet of retail|6,568 square feet of ground|69,900 square feet of retail space |100,000 square feet of retail|2,500 square feet of retail|42,645 square feet"
					+ "|\\d+,\\d+ square feet of (amenity areas|retaining walls|LEED|amenity space)";

			html = html.replaceAll(remove, "");
			html = html.replaceAll("\\d{2},\\d{3,} SF", "").replaceAll("Event Raises over \\$\\d{3}", "");
			// U.log(html);
			// ============================================Price and
			// SQ.FT======================================================================

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replaceAll(
					"closed a \\$56,000,000 non-recourse|\\$\\d+,\\d{3},\\d{3}|LLC Provides \\$68,350,000 in Financing",
					"");
			String prices[] = U.getPrices(html,

					"\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log(Arrays.toString(prices));

			// ======================================================Sq.ft===========================================================================================
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			// U.log(html);
//				U.writeMyText(html);
			// \\d{2},\\{3} square feet of retail
			String[] sqft = U.getSqareFeet(html.replaceAll(
					"12,901 square feet of amenities|Club House 6,000 SF| 4,300 square feet of ground floor retail|\\d+,\\d+ square feet of high-end retail|7,100 square feet of ground-floor retail space|6,000 SF clubhouse|10,000 square feet of ground-floor retail",
					""),
					"units range in size from \\d,\\d{3} to \\d,\\d{3} SF|\\d,\\d{3} square feet|\\d{1},\\d{3} SF|\\d+ to \\d{1},\\d{3} SF|\\d{3,4} to \\d,\\d{3} square feet|\\d{1},\\d{3} square feet|\\d,\\d{3} square feet|average \\d+ to \\d,\\d+ SF|square footage of \\d{1},\\d{3}|from \\d+ to \\d{1},\\d{3} SF|with \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} SF to \\d{1},\\d{3} SF|\\d+,\\d+ square feet|\\d{4} square| \\d{1},\\d{3} SF|\\d,\\d+ square feet|\\d{3,4} square feet",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("-======" + Arrays.toString(sqft));
//			U.log("MMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}6,000[\\s\\w\\W]{30}",0));

			// ======================Drop nav bar sectio====================
			String dropNav = U.getSectionValue(html, "<table id=\"topNavContainerDark", "<div id=\"pagecontent");
			if (dropNav != null) {
				html = html.replace(dropNav, "");
			}

			// ================================================community
			// type========================================================

			html = html.replace("Mitigated challenges ", "");
			String communityType = U.getCommType(html);

			// ==========================================================Property
			// Type================================================
			html = html.replaceAll(
					"eatures three courtyard parks|Village|village|Condominiums\">Next project",
					"").replaceAll(" loft-style|available lofts|include 17 loft,", " loft homes ")
					.replace("garden-style apartment complex", "Garden-Style Living apartment complex")
					.replace("space including apartments, common, and amenity areas",
							"space including apartments, common areas, and amenity areas")
					.replaceAll(
							"Luxury Housing Addition|is a luxury| luxurious units|Luxury Senior Living Campu|Unit Luxury|luxurious 440-unit Class|luxury rental units",
							" luxury homes units")
					.replaceAll("Choice and Custom Home Design Award|Congress Craftsmanship Award", "");

			String proptype = U.getPropType(html + com);
//				U.log(propSection);
			proptype = proptype.replace("Townhouse,Townhome", "Townhome");
			if (proptype.contains("Townhome") && proptype.contains("Townhouse"))
				proptype = proptype.replaceAll("Townhouse,|Townhouse", "");

			proptype = proptype.replace(",,", ",").replaceAll(",$", "");

			U.log("Property Type:::::::: " + proptype);
//			U.log("MMMMMMMMMM "+Util.matchAll(html+com, "[\\s\\w\\W]{50}farmhouse[\\s\\w\\W]{50}",0));
			// ==================================================D-Property
			// Type======================================================

			html = html.replace("seven level", "7 Story").replace("three- and four-story", "3 Story and 4 Story")
					.replace("3- and 4-story ", " 3 Story  4 Story ").replace(" four residential stories", "4 story")
					.replace("across six floors", " 6 story")
					.replaceAll("Branch|branch|floor (e-lounge|to encour)", "");
			html = html.replace("seven four- and five-story", "4 Story 5 Story ").replace("1- and 2-story",
					" 1 Story  2 Story ");
			html = html.replaceAll("four- and five-story|four- and five-story", "four-story and five-story");
			html = html.replaceAll(
					" four levels of underground|multi-level interactive|Celebrates Grand Opening|Celebrate Grand Opening|two stories of below grade parking|two-level underground| two-story below grade parking|a steel one-story attachment|level parking garage|Level Garage|level garage|above a two-level|12th floor party|level reinforce|two levels below|Stories of Underground|level clubhous",
					"")
					.replaceAll(
							"floor laundry|stories of below(-|\\s)grade(-|\\s)parking|level, cast-in-place|story pre-cast concrete|level(s)? of (above|below)(-|\\s)grade park|floor fitness center|story precast parking|floor including a Giant|floor. 360|Floor|floor",
							"")
					.replaceAll(
							"one level of underground parking|two-story fitness|parking spaces across three|three levels of retail",
							"");

			html = html.replaceAll(
					"five-story wrap around a six-story concrete garage|five levels of wood over two levels of concrete",
					"").replace("three-and four-story buildings", "3 Story,4 Story")
					.replace(" five three-story apartment", "Story 3 ")
					.replaceAll("two-story below-grade parking", "Story 2 ")
					.replace("four to five wood-framed stories", "Story 4 Story 5 ")
					.replace(" six levels of high", " 6 Story of high").replace("across three levels", "across 3 story")
					.replace("five levels of wood", "5 Story of wood").replace("Four split-level", "split floorplan")
					.replace("4-story", "4 Stories").replaceAll(
							"story precast garage|(story|level) (podium|parking)|(levels|stories) of wood-frame|levels of concrete underground|level below-grade parking|Level Underground Cast-in-Place Parking",
							"");
			// html = html.replaceAll("12-Story", "12 storiess");
			// html = html.replaceAll("12-story", "12 storiess");

			// U.log("MMMMMMMMMM "+Util.matchAll(html+com, "[\\s\\w\\W]{30}5
			// Story[\\s\\w\\W]{30}",0));
			com = com.replaceAll("14-[S|s]tory", "Fourteen-Story").replaceAll("12-[S|s]tory", "tweleve story")
					.replaceAll("13-Story| 13-story", "thirteen Story")
					.replaceAll("22-story|22-Story", "twenty-two_story")
					.replaceAll("11-story|11-Story", "Eleven-Story")
					.replaceAll("Two Stories of Underground Parking|Four-Level Underground Cast-in-Place Parking", "");
			
			
			html = html.replaceAll("22-story|22-Story", "twenty-two_story")
					.replaceAll("parking garage and podium level below five wood-framed stories|five-story garage|constructed as a double- with 5 Story of wood-framed apartments above it|luxury apartment building comprised of 5 Story of wood-framed units and a two- beneath|Two Stories of Underground Parking|two-story, 12,598-square-foot clubhouse|single-story wood-framed garages|single-story enclosed garage structures", "")
					.replaceAll("11-story|11-Story", "Eleven-Story")
					.replaceAll("comprised of 5 Story of wood framing|five levels of wood framing", "")
					.replaceAll("14-[S|s]tory", "Fourteen-Story").replace("two-story clubhouse flanked", "")
					.replaceAll("12-[S|s]tory", "tweleve story").replaceAll("13-Story| 13-story", "thirteen Story");

			String dtype = U.getdCommType((html.replace(" include a 2-story", " include a 2 Story") + com)
					.replaceAll("five wood-framed stories", "5 story").replace("four wood-framed stories", "4 stories")
					.replaceAll(
							"which consists of a five-story|six-story concrete garage|seven-story above-grade precast parking garage|Courtland consists of 12 stories of Prescient|five-level cast-in-place parking garage|Six to Nine stories|and a five-story|11-story auxiliary tower|Connecticut Avenue, a Nine-Story| Six to Nine Stories| five stories of wood framing|three-story concrete podium|three-story archway over|three-story type 1A podium|two-story concrete podium|a 2-story elevated clubhouse|Replacing a one-story|level|intersects a 4-story|the complex will consist of a five-story|an additional five-story|attached seven-story|one-story concrete podium",
							""));

//				U.log("MMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{50}3 story[\\s\\w\\W]{50}",0));
//				U.log("MMMMMMMMMM "+Util.matchAll(com, "[\\s\\w\\W]{50}3 story[\\s\\w\\W]{50}",0));
				
				
			if (dtype.contains("14 Story, 4 Story"))
				dtype = dtype.replaceAll(", 4 Story", "");
//				if(dtype.contains("22 Story")&& dtype.contains(", 2 Story"))dtype = dtype.replaceAll(", 2 Story", "");
//				if(dtype.contains(", 22 Story")&& dtype.contains("2 Story,"))dtype = dtype.replaceAll("2 Story,", "");
//				if(dtype.contains("2 Story, 12 Story")) {
//					dtype = dtype.replaceAll("2 Story,", "");
//				}
//				if(dtype.contains("2 Story, 12 Story"))dtype = dtype.replace("2 Story, ", "");
//				if(dtype.contains("12 Story")&& dtype.contains(", 2 Story"))dtype = dtype.replaceAll(", 2 Story", "");
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/the-clarendon/"))
				dtype = "12 Story";

			U.log("Dtype==" + dtype);
//				U.log(dtype + "======Dtype");
			// ==============================================Property
			// Status=========================================================
			html = html.replaceAll("Phase 2 public|celebrated the grand opening", "");
			String pstatus = U.getPropStatus(html + com);
			if (communityName.endsWith("Condominiums"))
				communityName = communityName.replace("Condominiums", "");
			// =========================
			count++;
			add[0] = add[0].replace("amp; 515 Oronoco St", "515 Oronoco St")
					.replaceAll("/td>td Align=\"left\" Valign=\"top\">", "");
			add[0] = add[0].replace("305 10th Street, South", "305 10th Street South");

			if (commUrl.contains("https://www.cbgbuildingcompany.com/Portfolio/Project/The-Galaxy")
					|| commUrl.contains("https://www.cbgbuildingcompany.com/Portfolio/Project/Varsity-on-Charles")
					|| commUrl.contains("https://www.cbgbuildingcompany.com/Portfolio/Project/4000-North-Fairfax")
					|| commUrl.contains("https://www.cbgbuildingcompany.com/Portfolio/Project/Riverlodge-Phase-II"))
				proptype = proptype + ", Luxury Homes";

			if (commUrl.contains("https://www.cbgbuildingcompany.com/Portfolio/Project/Metropolitan-at-Largo-Station"))
				dtype = "Split Level";
			if (commUrl.contains("https://www.cbgbuildingcompany.com/Portfolio/Project/Cambridge-Commons"))
				dtype += ", Split Level";
			if (com.contains("Luxury-And-Market-Rate-Apartments")) {

				if (proptype.length() < 3 && !proptype.contains("Luxury"))
					proptype = "Luxury Homes";
				else if (!proptype.contains("Luxury"))
					proptype = proptype + ", Luxury Homes";

			}

			if (com.contains("High-Density-Apartments") || com.contains("Luxury-And-Market-Rate-Apartments")) {

				if (proptype.length() < 3 && !proptype.contains("Apartment"))
					proptype = "Apartment Homes";

				else if (!proptype.contains("Apartment"))
					proptype = proptype + ", Apartment Homes";
			}
			communityName = communityName.replace("IIi", "III");
					
			if (commUrl.contains("https://www.cbgbuildingcompany.com/projects/aurora-condominiums"))
				dtype = "10 Story, 12 Story";
			if (commUrl.contains("cbgbuildingcompany.com/projects/j-creekside-at-exton/"))
				dtype = "5 Story";

//            =============================================================================

			String completion_date = U.getSectionValue(html, "Completion:", "</p>");
			String date_1 = "";
			U.log("completion_date==" + completion_date);
			if (completion_date != null) {
//				U.log("completion_date=="+completion_date);
				completion_date = U.getNoHtml(completion_date).trim();
				String[] date = completion_date.split(" ");
				U.log("date.length==" + (date.length - 1));
				for (int i = (date.length - 1); i >= 0; i--) {
//					U.log("d=="+i);
					U.log("d==" + date[i]);
					switch (date[0]) {
					case "January":
						date[0] = "01";
						break;
					case "February":
						date[0] = "02";
						break;
					case "March":
						date[0] = "03";
						break;
					case "April":
						date[0] = "04";
						break;
					case "May":
						date[0] = "05";
						break;
					case "June":
						date[0] = "06";
						break;
					case "July":
						date[0] = "07";
						break;
					case "August":
						date[0] = "08";
						break;
					case "September":
						date[0] = "09";
						break;
					case "October":
						date[0] = "10";
						break;
					case "November":
						date[0] = "11";
						break;
					case "December":
						date[0] = "12";
						break;
					default:
						date[1] = "Invalid month";
						break;
					}
					date_1 += date[i] + "/";
				}
				date_1 = date_1 + "01";
			} else {
				date_1 = ALLOW_BLANK;
			}

			U.log("date_1==" + date_1);

			data.addCommunity(
					communityName.replace(" – ", " ").replace("Ii", "II").replace("IIi", "III").replace("360�", "360"),
					commUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("LoopBldg", "Loop Bldg").replace("BoulevardBldg", "Boulevard Bldg")
					.replace(",", "").replace(" Tampa Fl 33616", ""), add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype.replace("11 Story, 1 Story", "11 Story")
					.replaceAll("5 Story, 15 Story|15 Story, 5 Story", "15 Story"));
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, date_1);
			data.addUnitCount(ALLOW_BLANK);
		}
		j++;
	}

}