/**
 *@Modified MJS
 *@date 24/08/19
 @author Upendra Singh
 * @date 27/03/2017
 * 
 */
package com.shatam.b_041_060;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDSLD_Homes extends AbstractScrapper {
	int i = 0;
	int counter = 0;
	static int j = 0;
	static String BASE_URL = "https://www.dsldhomes.com";
	CommunityLogger LOGGER;
	public int inr = 0;
	static int duplicates = 0;
	String pstatus = ALLOW_BLANK;
	String[] mainprice = { ALLOW_BLANK, ALLOW_BLANK };
	String[] sqrft = { ALLOW_BLANK, ALLOW_BLANK };
	String minSqf = ALLOW_BLANK;
	String maxSqf = ALLOW_BLANK;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractDSLD_Homes();
		
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "DSLD Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public ExtractDSLD_Homes() throws Exception {

		super("DSLD Homes", BASE_URL);
		LOGGER = new CommunityLogger("DSLD Homes");
	}


	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainhtml = U.getHTML("https://www.dsldhomes.com/communities");

		String communtiesection[] = U.getValues(mainhtml, "<a class=\"col-10 mr-auto CommunityCard_title px-0\"",
				"View Detail");
		int i = 0;
		U.log("Total: "+communtiesection.length);
		for (String commurl : communtiesection) {
			
			String communityurl = "https://www.dsldhomes.com/" + U.getSectionValue(commurl, "href=\"/", "\"");

			String comName = U.getSectionValue(commurl, "-->", "<!--");
			String commhtml = U.getHTML(communityurl);
			adddetails(commhtml, communityurl, comName);

			i++;
		}
		LOGGER.DisposeLogger();
	}

	
	public void adddetails(String commhtml, String communityurl, String comName) throws Exception {
		
		//TODO:
		// for single community run

//		if(!communityurl.contains("https://www.dsldhomes.com/communities/louisiana/baton-rouge/jamestown-crossing")) return;
		
// if(j>=90) {
		U.log("Count: "+j);
		if (data.communityUrlExists(communityurl)) {
			LOGGER.AddCommunityUrl(communityurl + "*************repeated************");

			return;
		}
		LOGGER.AddCommunityUrl(communityurl);
		
		// =====================communityname==============================================
		String commName = comName;

		if(commName!=null && commName.length()>3)
			commName = commName.replace("&#x27;s","'s")
			.replaceAll("Cottages$|Villas", "");
		U.log(commName);

		String sectioncomm = U.getSectionValue(commhtml, "</script><script data-react-helmet=\"true\"",
				"</head><body><noscript>");

		String commdesc = U.getSectionValue(commhtml, "</script><script data-react-helmet=", "</script>");

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";

		String addresssection = U.getSectionValue(commhtml, "class=\"CommunityDetail_section mb-3\"",
				"</span></hgroup>");

		U.log(addresssection);
		if (addresssection != null) {
			addresssection = addresssection.replaceAll(
					"data-reactid=\"\\d+\"><b data-reactid=\"\\d+\">|Selling From|Model Home Address|</b><span data-reactid=\"\\d+\">",
					"").replaceAll("</span><span data-reactid=\"\\d+\">", ",").replace("&#x27;", "'");
			add = U.getAddress(addresssection);
		}


		U.log(add[0] + "    " + add[1] + "    " + add[2] + "     " + add[3]);
		U.log(Arrays.toString(add));

		String latlongsection = U.getSectionValue(commhtml, "<img src=\"/images/icons/share.svg\" ",
				" class=\"CommunityDetail_map\"");

		String lat = U.getSectionValue(latlongsection, "<a href=\"https://www.google.com/maps/place/", "/@");
		U.log(lat);

		latLong = lat.split(",");

		U.log(Arrays.toString(latLong));

		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);

		// ===============================available plans
		// section================================
		/*
		 * String availplans=communityurl+"#available-plans";
		 * 
		 * String availplanshtml=U.getHTML(availplans);
		 */
		String availurls[] = U.getValues(commhtml, "<a class=\"col-10 mr-auto PlanCard_title px-0\" ", "View Detail");
		String storysection = null;
		String planspricesection = null;
		String sqftsec = null;

		String plandesc = null;
		for (String a1 : availurls) {
			String planurls = "https://www.dsldhomes.com" + U.getSectionValue(a1, "href=\"", "\"");
			U.log("planurls-==="+planurls);
//			 String planhtml=U.getHTML(planurls);
//			 if(planhtml.contains("patio")) {
//				 U.log("Found");
//			 }
			try {
				a1 = a1.replaceAll("=\"\\d{3}\"|=\"\\d{4}\"", "");
				String planname = U.getSectionValue(a1, "data-reactid>", "</a>");
//				U.log("planname==="+planname);
//				String s = U.getSectionValue(commhtml.replace("Rodessa III B - Front Elevation - DSLD Homes", "Rodessa III B - Huntsville"), "\"caption\":\"" + planname + "", "}]},");
				
				String s = U.getSectionValue(commhtml.replace("Rodessa III B - Front Elevation - DSLD Homes", "Rodessa III B - Huntsville"), "\"name\":\"" + planname + "", "\"uniqueName\":");

				
				if (s==null) {
					s = U.getSectionValue(commhtml.replace("Rodessa III B - Front Elevation - DSLD Homes", "Rodessa III B - Huntsville"), "\"caption\":\"" + planname + "", "}]");
				}
				//U.writeMyText((U.getSectionValue(commhtml, "\"name\":\"Rodessa III B - Floor plan - DSLD Homes\",\"tags\":\"Rodessa III B - Floor plan - DSLD Homes\"", "}]}").replace("Rodessa III B - Front Elevation - DSLD Homes", "Rodessa III B - Huntsville")));
//				 U.log(s);
//				U.log("MMMMMMMMM "+Util.matchAll(s, "[\\w\\s\\W]{30}stories[\\w\\s\\W]{30}", 0));


				storysection += U.getSectionValue(s, "\"stories\":", ",").replace("1", "1 Story")
						.replace("2", "2 Story").replace("3", "3 Story");
				

				planspricesection += U.getSectionValue(a1, "class=\"px-3 px-lg-4 py-3 PlanCard_price \"",
						"</div></div>");

				sqftsec += U.getSectionValue(a1, "style=\"background-image:url(/images/icons/sqft.svg);\"",
						"</li></ul><ul class=");

				plandesc += U.getSectionValue(commhtml, "", "");
			} catch (NullPointerException ne) {

			}

		}
		U.log("storysection===="+storysection);
		// =============================available quick
		// section===================================

		/*
		 * String availquick=communityurl+"#available-homes";
		 * 
		 * String availquickhtml=U.getHTML(availquick);
		 */

		String availquickurls[] = U.getValues(commhtml, "<div class=\"HomeCard_headlineWrapper",
				"View Detail");

		String quickstorysection = null;
		String quickpricesection = null;
		String desquic = null;
		String quicksqftsec = null;
		String quickdesc = null;
		String quicname = null;
		String quickData = ALLOW_BLANK;
		String quickDesc = ALLOW_BLANK;
		
		int  quickCount=0;
		int  UcquickCount=0;
		
		for (String quicksec : availquickurls) {
			if(!quicksec.contains("Under Construction")) {
				if(!quicksec.contains("corner lot"))
					UcquickCount++;
			}
			else
				quickCount++;
			

//			U.log("======dsl==="+quicksec);
			String quickurls = "https://www.dsldhomes.com"
					+ U.getSectionValue(quicksec, "href=\"", "\"");
			
			U.log("QuickUrls: "+quickurls);
			String quickInfo = U.getHTML(quickurls);
			if(quickInfo != null) {
				
				String descSec = U.getSectionValue(quickInfo, ">About</h3>", "</div></div></div>");
				quickDesc += descSec;
			}
			
			quickData += quickInfo;
			
			
			quickurls = quickurls.replaceAll(": \\d{4}", "");
			String quicnames = U.getSectionValue(commhtml, "<span class=\"HomeCard_tour \"", "</span></span>");

			if (quicnames != null)
				quicname = U.getSectionValue(quicnames, "alt=\"", "\"");
			if (quicnames == null) {
				String asd = U.getSectionValue(commhtml, "<a class=\"col-10 mr-auto HomeCard_title px-0\"",
							"<span class=\"HomeCard_subtitle\"").replaceAll(": \\d{4}", "");
				quicname = U.getSectionValue(asd, "<!-- react-text -->", "<!-- /react-text -->");
			}
			if (quicnames == null) {
				quicname = U.getSectionValue(commhtml, "<span class=\"HomeCard_subtitle\" ",
						"<a class=\"HomeCard_btn HomeCard_visit\"").replaceAll(": \\d{4}", "");

			}

			//U.log("quickname: "+quicname);
			
			
			// <!-- react-text -->115 GENTLE CRESCENT LN.<!-- /react-text -->
			// "streetAddress":"115 GENTLE CRESCENT LN
			// String quickhtml=U.getHTML(quickurls);
			desquic = U.getSectionValue(commhtml, "\"streetAddress\":\"" + quicname + "", "\"postalCode\":\"");

			// U.log("jjjjjjjjjjjjjjjjjjjjjj"+desquic);

			if(desquic!=null) {
				
				quickstorysection += U.getSectionValue(desquic, "\"stories\":", ",").replace("1", "1 Story")
						.replace("2", "2 Story").replace("3", "3 Story");
				
				quickdesc += U.getSectionValue(desquic, "\"description\":", "\",\"elevation");
			}
	

			if(quicksec!=null) {
				quickpricesection += U.getSectionValue(quicksec, "<div class=\"px-3 px-lg-4 py-3 HomeCard_price\"",
						"</div></div>");

				quicksqftsec += U.getSectionValue(quicksec, "style=\"background-image:url(/images/icons/sqft.svg);\"",
						"</li></ul>");
			}
				

			
		
	}
		
		U.log("QUICK COUNT: "+UcquickCount);
		
		// ======================================prices======================================

		String pricemain = U.getSectionValue(commhtml, "<span class=\"CommunityPrice_address\"",
				"</span></div><ul class=\"list-");

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;
		prices = U.getPrices(pricemain + quickpricesection + planspricesection, "\\$\\d{3},\\d{3}", 0);

		minPrice = prices[0];
		maxPrice = prices[1];

		U.log("prices======="+Arrays.toString(prices));
		// ==========================sqft======================================
		String sqftmain = U.getSectionValue(commhtml, "style=\"background-image:url(/images/icons/sqft.svg);\"",
				"<ul class=\"list-unstyled d-flex\"");
//		U.log(sqftmain);
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		sqft = U.getSqareFeet(sqftmain + quicksqftsec + sqftsec, ">\\d{1},\\d{3}|- \\d{1},\\d{3}<", 0);

		minsqft = sqft[0];
		maxsqft = sqft[1];

		U.log(Arrays.toString(sqft));

		// ====================================communtiytype=======================================
		String commtype = null;

		// U.log(commdesc);

		if (commdesc != null)
			commtype = U.getCommType(commdesc.replaceAll("golfing around|visit the Glenlakes golf club", ""));
		U.log("commtype====="+commtype);

		// ====================================property
		// type=================================

		String commdesc1=U.getSectionValue(commhtml, "CommunityAbout_description", "</p>");
		String comenu = U.getSectionValue(commhtml, "Community Menu</a><ul class=\"CommunityPageMenu_list",
				"CommunityPageMenu_contact\"");
		String hoa = ALLOW_BLANK;

		hoa = U.getSectionValue(commhtml, "<li class=\"CommunityPageMenu_listItem\"",
				"</style><div class=\"css-1na4j8c\"");

		if(commdesc!=null)
			commdesc = commdesc.replace("and Colonial Golf Courses", "and Golf Courses").replace("the Colonial and Fox Run Golf Course", "Fox Run Golf Course");
			
		String ptype = U.getPropType((commName+commdesc1+commdesc + quickdesc + comenu + hoa + quickDesc).replaceAll("cabinetry|cabin rentals", ""));

		U.log(ptype);
		// ==================dtype=========================

		// U.log("======================"+quickstorysection);
		// U.log("////////////////////"+storysection);

		if(storysection!=null)
			storysection = storysection.replace("1 Story", " 1 Story ").replace("2 Story", " 2 Story ").replace("3 Story", " 3 Story ");
		
		if(quickstorysection!=null)
			quickstorysection = quickstorysection.replace("1 Story", " 1 Story ").replace("2 Story", " 2 Story ").replace("3 Story", " 3 Story ");
		
		if(quickDesc != null) quickDesc = quickDesc.replace("split designed floor plan", "split-level designed floor plan");
		
		String dtype = U.getdCommType((commdesc1+commdesc + quickstorysection + storysection + quickdesc + quickDesc).replaceAll("Kart Ranch", ""));
//		U.log("MMMMMMMMM "+Util.matchAll(quickDesc, "[\\w\\s\\W]{30}split[\\w\\s\\W]{30}", 0));

		U.log(dtype);

		// =====================pstatus=================================
		commhtml=commhtml.replaceAll("</span><!-- react-text: \\d+ --> Quick Move-In<", " Quick Move-In<");
//		U.log("===="+Util.match(commhtml, "[\\w\\s\\W]{50}quick[\\w\\s\\W]{30}"));
//		if(commhtml.contains(">0 Quick Move-In<")) {
////			if(pstatus.contains(""))
//			
//		}
		
		String ssec = U.getSectionValue(commhtml, "<li class=\"flex-fill CommunityPrice_homes pt-4\"",
				"<li class=\"flex-fill CommunityPrice_homes pt-4 ");
//		U.log(ssec);
//		if (ssec != null)
//			ssec = ssec.replaceAll("</span><!-- react-text: \\d+ -->", "");
		ssec = ssec.replaceAll("0 Quick Move-In", "");
//		U.log("===="+Util.match(ssec, "[\\w\\s\\W]{50}quick[\\w\\s\\W]{30}"));
		U.log("-------" + ssec);
		String ima = U.getSectionValue(commhtml, "<span class=\"flex-fill HomeCard_status\"", "</span><div");
		if (ima != null)
			ima = ima.replaceAll("Under Construction -", "");
		String regi = U.getSectionValue(commhtml, "class=\"CommunityDetail_section flex-row flex-wrap mb-3\"",
				"</hgroup><hgroup");
		if (regi != null)
			regi = regi.replaceAll("</b><!-- react-text: \\d{3} -->|Active", "");

		if(commdesc!=null)
			commdesc = commdesc.replace("waterfront lake lots and private wooded creek lots available", "waterfront lake lots available and private wooded creek lots available")
			.replaceAll("selections or rather a move-in ready home|Choose one of our move-in ready homes", "");
		
		
		String pstatus = U.getPropStatus((commdesc1+commdesc + regi + ssec)
				.replaceAll("Quick Move-in|Quick Move-In|move-in ready", "")
				.replaceAll("Grand Openings &Open Houses|rather a Move in|DSLD Homes is now selling|selections or rather a Move-in Ready home|King George offers move-in ready|Choose one of our move-in ready|wooded creek lots available|total lots( are)? available|trail coming soon|options are now available", ""));

		//U.log(">>>>>>>>>>>>>>>>"+Util.match(commdesc1+commdesc + regi + ssec, "[\\w\\s\\W]{50}Move-in[\\w\\s\\W]{30}"));
		
//		if(availquickurls.length==UcquickCount) {
//			pstatus=pstatus.replaceAll("Quick Move-in,|, Quick Move-in,|Quick Move-in", "");
//		}
//		
//		U.log(pstatus);
//		U.log("quickCount==="+quickCount);
//		
		
		U.log("pstatus==== "+pstatus);
		
		if (pstatus.contains(", Move In Ready Home") || pstatus.contains(", Move-in Ready Homes") || pstatus.contains(", Move-in Ready")) {
			pstatus = pstatus.replaceAll("Move In Ready Home|Move-in Ready Homes|Move-in Ready", "Quick Move-in");
		}

		if (pstatus.contains("Move-in Ready Homes") || pstatus.contains("Move-in Ready")) {
			pstatus = "Quick Move-in";
		}
		if(communityurl.contains("https://www.dsldhomes.com/communities/alabama/huntsville/meadow-crest"))pstatus+=", Only 48 Total Lots Available";
		if(pstatus!=null && pstatus.contains("Quick Move-in"))
			pstatus = pstatus.replaceAll("\\d Quick Move-in", "Quick Move-in");
		
		
		if(communityurl.contains("https://www.dsldhomes.com/communities/louisiana/baton-rouge/spring-gardens"))
			pstatus = "Waterfront Lake Lots And Private Wooded Creek Lots Available, "+pstatus;
		if(communityurl.contains("https://www.dsldhomes.com/communities/louisiana/covington/village-at-guste-island")) {
			ptype+=", Loft";
			pstatus+=", Now Selling";
		}
		 
		if(communityurl.contains("https://www.dsldhomes.com/communities/louisiana/covington/village-at-guste-island"))
			dtype = "2 Story";
		if(communityurl.contains("https://www.dsldhomes.com/communities/louisiana/hammond/choctaw-ridge"))dtype="1 Story";
		
		
		
		if(dtype==ALLOW_BLANK)dtype="1 Story";
		
		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (commtype == null)
			commtype = ALLOW_BLANK;
		
		//if(availquickurls!=null && availquickurls.length > 0 && !pstatus.contains("Quick Move") ) {
		U.log("QUICK COUNT FOR STS: "+UcquickCount);
		
		if(UcquickCount > 0 && !pstatus.contains("Quick Move")) {
			
			if(pstatus.length()>2) {
				pstatus=pstatus+", Quick Move-In";
				
			}else {
				pstatus="Quick Move-In";
			}
		}
		U.log("pstatus here ==== "+pstatus);
		
		if(pstatus.length()<1) {
			pstatus=ALLOW_BLANK;
		}
		
		if(communityurl.contains("alabama/baldwinmobile/osprey-landing")||communityurl.contains("/alabama/huntsville/parkside")||communityurl.contains("/alabama/baldwinmobile/sonoma-ridge")||communityurl.contains("communities/florida/gulf-breeze/the-sanctuary"))
			dtype=dtype.replace(", 2 Story", "");
		if(pstatus.contains("Quick Move-in")) {
			pstatus=pstatus.replace("Quick Move-in", "Quick Move-in Homes");
		}
		
			
		data.addCommunity(commName.replace("&#x27;s", " &"), communityurl, commtype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		j++;
	}
//	}
}