package com.shatam.b_041_060;

import java.util.Arrays;

import org.apache.jasper.tagplugins.jstl.core.Catch;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDreesHomes extends AbstractScrapper{

	CommunityLogger LOGGER;
	final String BASE_URL = "https://www.dreeshomes.com";
	int j = 0;
	WebDriver driver=null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractDreesHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Drees Homes.csv", a.data().printAll());
	}

	public ExtractDreesHomes() throws Exception {
		super("Drees Homes", "https://www.dreeshomes.com/");
		LOGGER = new CommunityLogger("Drees Homes");
	}

	String RegionCode[] = { "AUST", "CINCI", "CLEVE", "DALL", "HOUS", "INDI", "JAX", "NASH", "RALE", "WASH" };

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		// TODO Auto-generated method stub
		int i = 0;
		do {
			String regHtml = U.getHTML("https://dhp.dreeshomes.com/prod/communities?code=" + RegionCode[i]);
			U.log("https://dhp.dreeshomes.com/prod/communities?code=" + RegionCode[i]);

			regHtml = regHtml.replace("\"area_name\":\"", "newdata\"area_name\":\"").replace("}}]}}", "}}]}}newdata");
			String sections[] = U.getValues(regHtml, "\"area_name\":\"", "interactive_plat_url");
			 U.log(sections.length);
			for (String section : sections) {
				String comurl = U.getSectionValue(section, "\"details_url\":\"", "\",");
				
//				U.log(">>>>>>>>"+comurl);
//				try {
					addDetails(section,regHtml);
//				} catch (Exception e) {}
				
				
				
			}
			i++;
		} while (i < 10);
//		driver.close();
		LOGGER.DisposeLogger();
	}

	public void addDetails(String section,String regHtml) throws Exception {
			
		String comurl = U.getSectionValue(section, "\"details_url\":\"", "\",");
		//TODO:
//	if(!comurl.contains("https://www.dreeshomes.com/custom-homes/washington-virginia-maryland/community/embrey_mill/cascade_flats_at_embrey_mill/")) return;
		
		
//		U.log("::::\n"+section);
//		if(j>=50)
		
//		try
		{
//			if(j>=20 && j<=50)c
//			if(j>50 && j<=100)
//			if(j>50 && j<=100)
//			if(j>=135)
//			if(j>=42)		
//			if(j>=117)
//			if(j>=14 && j<=50)
//			if(j>=100 && j<=150)
			
			{
		LOGGER.AddCommunityUrl(comurl);
		//Updated 19th Aug 21
//		if(comurl.contains("tallyn_ridge_estates")) {
//			LOGGER.AddCommunityUrl(comurl+"::::::::::Url giving server error on date 19th Aug 21");
//			return;
//		}
		U.log(j + "===================" + comurl);
		
//		U.log("::::\n"+section);
		
		String cName = U.getSectionValue(section, "\"community_name\":\"", "\"");
//		
		U.log("cName====="+cName);
//		U.log(section);
		String comDetail = U.getSectionValue(section, "\"biography\":\"", "\",\"market");
		String html=null;
		
		
//		if(!comurl.contains("https://www.dreeshomes.com/custom-homes/washington-virginia-maryland/community/potomac_shores/villas_at_potomac_shores/"))
//			html=U.getHTML(comurl);
//		else
//		 html = U.getHtml(comurl, driver);

		 html = U.getHTML(comurl);
		 U.log(U.getCache(comurl));	
		 
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		 
		units = getUnits(comurl, html, driver);
		
		U.log(" Total units: "+units);
		
//		--------------------------------------------------------------------------------------------
		 
		 String comName = U.getSectionValue(html, "<h1 data-v-6625cd37>", "</h1>");
		 
			U.log(comName);
		 U.log("comName====="+comName);
//		U.log(">>>>>>>>>>>>"+html);
		String comtypeSec = U.getSectionValue(html, "<ul class=\"secondary-ammenities\"", "</ul>");
		
		if(comDetail==null)comDetail = ALLOW_BLANK;
		
		String comType = U.getCommType((comDetail+comtypeSec));
		U.log("comType=====  "+comType);
		
//		U.log("MMMMMMMMM "+Util.matchAll(comDetail+comtypeSec, "[\\w\\s\\W]{30}adults[\\w\\s\\W]{30}", 0));
//		U.log("MMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}adults[\\w\\s\\W]{30}", 0));
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		// add[0]=U.getSectionValue(section, "\"sales_address\":\"", "\"");
		add[1] = U.getSectionValue(section, "\"city\":\"", "\"");
		add[2] = U.getSectionValue(section, "\"state\":\"", "\"");
		add[3] = U.getSectionValue(section, "\"zip\":\"", "\"");

		//if (add[0] == null || add[0] == ALLOW_BLANK) {
			
//		comName=U.getSectionValue(html, "<h1 data-v-0bf7586c=\"\">", "</h1>");
			if(comName==null)
				comName=U.getSectionValue(html, "<h1 data-v-4feebad0=\"\">", "</h1>");
			U.log(comName);
			if(comName==null) {
				comName=U.getSectionValue(html, "v-breadcrumbs__item--disabled\">", "<");
				
				if(comName.endsWith("Villas" )) {
					comName = comName.replaceAll(" Villas$| -Villas$| - The Villas$", "");
				}
				
				U.log("comName: "+comName);
			}
			
			
			add[0] = U.getSectionValue(html, "<p data-v-fcc0551c=\"\" class=\"margin-left-20 addrtext\">", "</p>");
	//	}

		
		String pageAddressSec = U.getSectionValue(html, "Community Location", "</p> <button type=\"button\"");
		U.log("pageAddressSec=======  "+pageAddressSec);
		if(pageAddressSec == null) {
			pageAddressSec = U.getSectionValue(html, "Community Location</h3>", "<button type=\"button");
			U.log("pageAddressSec=======  "+pageAddressSec);
		}
		
		
		String rem=U.getSectionValue(pageAddressSec, "</h3>", "</p>");
		U.log("rem========="+rem);
		pageAddressSec=pageAddressSec.replace(rem, "");
		
		U.log("pageAddressSec here=======  "+pageAddressSec);
		if(pageAddressSec!=null) {
			pageAddressSec=pageAddressSec.replace("  Bloomfield Estates   |</p> <p class=\"small\" data-v-0ae94aef=\"\">|<p class=\"small\" data-v-0ae94aef=\"\">,|<p class=\"small\" data-v-641e6435=\"\">"+comName+"</p>", "").replace("<p class=\"small\" data-v-27987021=\"\">Rough Hollow", "").replaceAll("Tallyn Ridge at Pinecliff Park|<p class=\"small\" data-v-0ae94aef>|</p> <p class=\"small\" data-v-641e6435=\"\">|</p> <p class=\"small\" data-v-27987021=\"\">", ",").replaceAll("<p class=\"small\" data-v-641e6435=\"\">|<p class=\"small\" data-v-27987021=\"\">", "");
//			pageAddressSec=U.getNoHtml(pageAddressSec);
//			String addSec=U.getSectionValue(pageAddressSec, "", To)
			pageAddressSec=pageAddressSec.replaceAll("<p class=\"small\" data-v-0ae94aef=\"\">\n" + 
					"            |<p class=\"small\" data-v-0ae94aef=\"\">,</p> <p class=\"small\" data-v-0ae94aef=\"\">", "");
			
			pageAddressSec=U.getNoHtml(pageAddressSec);
			String city=U.getSectionValue(section, "\"city\":\"", "\",\"");
//			pageAddressSec=pageAddressSec.replace("Collin-, McKinney", "Collin-McKinney");
			
//			if(pageAddressSec.contains("7652 Collin-"))pageAddressSec=pageAddressSec.replace("Collin-, McKinney", "Collin-McKinney");
//			if(pageAddressSec.contains(comName)||pageAddressSec.contains(cName)) {
//				if(pageAddressSec.contains(comName))
//				pageAddressSec=pageAddressSec.replace(comName, "");
//				else if(pageAddressSec.contains(cName))
//					pageAddressSec=pageAddressSec.replace(cName, "");
//			}
			if(pageAddressSec.contains(city))
			{
				pageAddressSec=pageAddressSec.replace(city, ", "+city);
			}
			U.log("pageAddressSec========"+pageAddressSec);
			pageAddressSec=pageAddressSec.replaceAll("West 130th Street., Brunswick Hills, OH,\\s*Brunswick Hills, OH 44212", "West 130th Street.,Brunswick Hills, OH 44212").replaceAll(" Towne Lake,|Sanctuary Village,|Crooked Tree Preserve,|The Oaks at San Gabriel,", "").replace(",,", ",");
			add=U.getAddress(pageAddressSec);
			
//			U.log("}}}}}}}}}}}}city===="+city);
//			U.log("}}}}}}}}}}}}"+add[3]);
			
			if(comurl.contains("community/deer_haven/deer_haven/"))
			{
				add[0]="Deer Haven Drive";
			}
			
			
			if(add[0].contains(",") && add[0].split(",")[1].length()>4)add[0]=add[0].split(",")[1];
			else if(!add[0].contains(","))add[0]=add[0];
			else add[0]=ALLOW_BLANK;
			
			add[0]=add[0].trim().replace(comName+", ", "");

		}
		if(comurl.contains("https://www.dreeshomes.com/custom-homes/cincinnati-northern-kentucky/community/arcadia/arcadia-vineyards_condos/")) {
			add[0]=add[0].replace("Boulevard","Arcadia Boulevard");
					
		}
		if(comurl.contains("the_pinnacle_at_craig_ranch/the_pinnacle_at_craig_ranch/"))
		{
			add[0]=" 7652 Collin-McKinney Parkway";
		}
//		if(comName.contains("Arcadia"))
//			add[0]=add[0]+" Arcadia Blvd";
//		if(comName.contains("Arcadia - Vineyards Condos"))
//			add[0]="Arcadia Boulevard";
//		if(comName.contains("Deer Haven"))
//			add[0]="Deer Haven "+add[0];
		
//		U.log("ADDRESS::::::::::"+Arrays.toString(add));
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latsec=U.getSectionValue(section, "href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "&amp");
		U.log("latsec======="+latsec);
		
		latLong[0] = U.getSectionValue(section, "\"latitude\":", ",");
		latLong[1] = U.getSectionValue(section, "\"longitude\":", ",");
		if(latLong[0]==null && latLong[1]==null)
		{
//			U.log("KKKKKKKKK");
			latLong[0] = U.getSectionValue(section, "center_latitude:", ",");
			latLong[1] = U.getSectionValue(section, "center_longitude:", ",");
		}
//U.log(">>>>>>>>>>>:::::"+add[3]);
		if (add[0] == null || add[1] == null || add[2] == null || add[3] == null || add[0].length() < 3) {
			if (latLong[0] != null && latLong[1] != null) {
				add = U.getAddressGoogleApi(latLong);
				geo = "TRUE";
			}
		}
//		if(latLong[0]==null||latLong[1]==null) {
//			if(add[1]!=null && add[2]!=null) {
//				latLong=U.getlatlongGoogleApi(add);
//				geo="TRUE";
//			}		
//		}
		U.log("geo===="+geo);
//		U.log("comName>>>>>>>>>>>"+comName);
		U.log("Address===="+Arrays.toString(add));

		U.log("latLong===="+Arrays.toString(latLong));
		String minPrice = null, maxPrice = null;
		String minsqft = null, maxsqft = null;
		
		
		//===== Homes Data =================
		String homesData = ALLOW_BLANK;
		String carouselHomesData = ALLOW_BLANK;
			
			if(html.contains("<div class=\"home-cards\"") && html.contains("drees-footer-container")) { 
				
				U.log("Extracting Homes Data");
				
				String homesSec = U.getSectionValue(html, "<div class=\"home-cards\"", "drees-footer-container");
				
				String[] homeValues = U.getValues(homesSec, "<section data-fetch-key", "</div></section>");
				U.log("homeValues.length: "+homeValues.length);
				
				for(String home:homeValues) {
					
					String homeLink = U.getSectionValue(home, "<a href=\"", "\"");
					U.log("homeLink: "+homeLink);
					
//					homesData += U.getHtml(homeLink, driver);
					homesData +=U.getSectionValue(U.getHTML(homeLink), "Community Location", " Download Brochure");
					carouselHomesData += U.getSectionValue(U.getHTML(homeLink), "<div class=\"carousel_caption py-1 px-3\">", "<div class=\"spacer p-1\">") ;
				}
			}
			String model_data="";
				String modelData[]=U.getValues(html, "{plan_type:", "details_url:");
				U.log("modelData: "+modelData.length);
				for(String model :modelData) {
					model_data+=model;
				}
	
	//--------------QUICK SECTION BELOW
	String quickData = ALLOW_BLANK;
	
	String[] quickHomes=U.getValues(html, "{is_boy", "]");
	int quick=0;
	//if(quickmovesec!=null&&	quickchk.contains("quick-move-in")){
	U.log("quickHome==="+quickHomes.length);
	if(quickHomes.length>0) {
		for(String quickHome : quickHomes)
		{
			U.log("quickHome: "+quickHome);
			
			quickData += quickHome;
			
			if(quickHome.contains("target_date:\"Immediate\"") || quickHome.contains("target_date:\"Summer 2022"))
			{
				quick++; //for status.
			}
		}
	}
 
		
		
		html = html.replace("Homes from $500", "Homes from $500,000").replaceAll("under $500,000\\\"", "").replace(",square_feet:3883,job_number:", "");
		String prices[]=U.getPrices(html.replace("2013 for home $500,000", ""), "Homes from \\$\\d,\\d{3},\\d{3}|Homes from \\$\\d+,\\d+ - \\$\\d,\\d+,\\d+|\\$\\d{1},\\d{3},\\d{3} - \\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
		minPrice=prices[0];
		maxPrice=prices[1];
//		U.log("MMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}\\$500[\\w\\s\\W]{30}", 0));
		U.log("price===== "+Arrays.toString(prices));
		
		html = html.replaceAll("the 5,000 square foot community clubhouse", "");
		
		String sqft[]=U.getSqareFeet(html+model_data, "square_feet:\\d{4},|\\d,\\d{3} square foot|Sq Footage:\\d,\\d{3}|Square Feet: \\d,\\d{3}-\\d,\\d{3}|Square Feet: \\d,\\d{3}-\\d,\\d{3}|\\d{4}-\\d{4} square feet|>\\d{1},\\d{3}|- \\d{1},\\d{3}|Square Feet: \\d,\\d{3}", 0);
		minsqft=sqft[0];
		maxsqft=sqft[1];
		U.log("sqft===== "+Arrays.toString(sqft));
		
//		U.log(section);
//		String desc="";
//		try {
//		 desc=U.getSectionValue(regHtml, "\"profile\":\"", "\"details_url\":\""+comurl+"");
//		}
//		catch(NullPointerException ne) {}
//		U.log(desc);
		
		String alsoIncludes = ALLOW_BLANK;
		if(html.contains("Also includes:</p>") && html.contains("Visit Community Website")) {
			alsoIncludes = U.getSectionValue(html, "Also includes:</p>", "Visit Community Website");
		}
		
		String carousel = ALLOW_BLANK;
		if(html.contains("<div class=\"carousel_caption py-1 px-3\">")) {
			carousel = U.getSectionValue(html, "<div class=\"carousel_caption py-1 px-3\">", "<section class=\"VipForm\">");
			//U.log(carousel);
		}

		section=section.replace("Stories: 2", "Stories 2").replace("Luxurious, 2 and 3-story", "2 Stories and 3 Stories luxury homes")
				.replace("Estates Villas", "Estate Residences, and villas")
				.replace(" driven Custom + Construct program Drees Homes", "additional custom")
				.replace("luxury lakeside living", "luxury living lakeside living")
				.replace("luxury", "luxury living")
				.replace("luxurious paired villa-living", "luxuries and paired home villa-living")
				.replaceAll("Brintons Cottage Street|onto Brintons Cottage", "");
		
		quickData = quickData.replace("Sumlin is a luxurious two-story home", "Sumlin is a luxury living two-story home")
				.replace("The luxurious first floor", "The luxury living first floor")
				.replace("showcasing a private luxury", "showcasing a private luxury living");
				
		String pType = U.getPropType((homesData + alsoIncludes + carousel + carouselHomesData +quickData) + section.replaceAll("type\":\"Condo|has no HOA|luxurious Buchanan model|luxury owner's suite", "luxuries").replace(" luxury lakeside living", "luxuries lakeside living"));
		
//		U.log("MMMMMMMMM "+Util.matchAll(homesData + alsoIncludes + section, "[\\w\\s\\W]{60}luxur[\\w\\s\\W]{100}", 0));
//		U.log("MMMMMMMMM "+Util.matchAll(carouselHomesData, "[\\w\\s\\W]{60}patio[\\w\\s\\W]{100}", 0));
		
		U.log("pType===="+pType);
//		U.log(">>>>>>>>>>>> "+Util.matchAll(quickData, "[\\s\\w\\W]{30}luxur[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMMmx "+Util.matchAll(html, "[\\s\\w\\W]{100}hoa[\\s\\w\\W]{100}", 0));

		html = html.replace("Stories: 2", " 2 Stories").replace("two-story floor", " 2 Stories")
				.replace("Luxurious, 2 and 3-story", "2 Stories, 3 Stories luxury homes").replace("Stories: 1 - 2", " 1 Story 2 Story")
				.replace("Stories: 3 - 4", " 3 Story 4 Story")
				.replace("Stories: 1", "1 Story")
				.replace("Stories: 2-3", "2 Story, 3 Story")
				.replace("Stories: 2 - 3", " 2 Story 3 Story").replace("Stories: ", "Story ")
				.replaceAll("one and two-story|one- and two-story ", "1 Story 2 Story");
		section = section.replaceAll("[F|f]loor|[L|l]evel|[S|s]tory", "");
		
		String unWJsn=U.getSectionValue(html, "window.__DREES__=","</script>");
		String html2=html.replace(unWJsn, "");
		html=html.replace("two-story foyer with a private study","").replace("two-story family room with wall of windows", "").replace("two-story foyer with staircase","").replace("two story single family home with stone and siding","").replace("Custom two-story home", "").replace("Two-story family room with stone fireplace", "").replace("custom two-story brick home","");
		html=html.replace("two-story", "").replace("two story","")
				.replace("EMBREY MILL ONE-LEVEL LIVING", "");
		html=html.replace("one-level_living","").replace("One-Level Living","");
		
		html2=html2.replace("2 Stories-3", "2 Stories-3 Story")
				.replaceAll(" Embrey Mill One-Level Living|_one-level_living", "");
		
		String dtype = U.getdCommType(homesData + (section+html2).replaceAll("Second Floor|Ranch Road|EMBREY MILL ONE-LEVEL LIVING|Embrey Mill One-Level Living|modern functionality in a multi-level plan|areas in a convenient, one-level floor plan|this one-level ranch has something for everyone|is_ranch|Ranch High School|cyranch|Exterior 2-story with stone", "").replaceAll("eadline\":\"Expansive One-Level Ranch|intricately-designed ranch plan with|eadline\":\"Expansive One-Level Ranch|\"headline\":\"Stunning Ranch|FRanch|\"headline\":\"Ranch|custom ranch home with brick exterior|\"is_ranch|[B|b]ranch|is_ranch", ""));
		U.log("dtype===="+dtype);
	//	U.log("MMMMMMMMMMMmx "+Util.matchAll(html2, "[\\s\\w\\W]{100}Second Floor[\\s\\w\\W]{100}", 0));

//U.log(section);
//		String stsec=section;
		section=section.replace("Move-in Ready Homes", "quick move-in");
		section=section.replace("\"unit_status\":\"[Coming Soon]\"", "");
		section=section.replace("\"directions\":\"Coming Soon", "");
		section=section.replace("build-to-order and quick move-in opportunities", "").replaceAll("Grand Opening|Homes Ready for Move-in This Summer|New Model Grand Opening|Coming Soon - Audubon Town Center|Just one quick move-in home remains in this popular|planned to open Spring 2020|Pool Coming Spring 2021|The Lodge is coming soon|schools coming soon|ISD coming soon", "");
		section=section.replaceAll("new collection of  plans coming soon|Community Sold Out! Now Selling at Wolf Run|premium home sites available|Quick Move-In Home Now Available!|Quick Move-Ins Coming Soon|Drees urban living coming soon", "")
				.replace("New Section Now Open-Move-in Ready Home Available", "New Section Now Open")
				.replace("Coming Nov. 2021", "Coming Nov 2021").replace("Quick Move-In Opportunity Coming Soon!","");
		
		String special = ALLOW_BLANK;
		if(html.contains("<div class=\"special-message") && html.contains("</div>")) {
			special = U.getSectionValue(html, "<div class=\"special-message", "</div>");
			U.log("special: "+special);
		}
		
		
		String pstatus = U.getPropStatus((special).replaceAll("Quick Move-in|Quick Move-In|Quick Move-in Available|One Quick Move-in Available|Quick Move-ins and|Last Quick Move-In Now Available|Inventory Homes Now Available|Quick Move-in Homes Coming Soon", "") 
				+ section.replaceAll("Model Now Open! Quick Move-in Homes Coming Soon!|Quick Move-in Homes Now Available|Close-Out-Model Home|Quick Move-in Opportunities Coming Soon|Limited Quick Move-in Homes Coming!|quick move-in opportunities coming soon|sage\\\":\\\"Now Selling! New Model Coming Soon!\\\"|Drees urban living coming soon to", "")
				.replace("New Phase  & Model Coming Soon! Join the VIP List.", "new phase coming soon").replace("South Fork River Camp (coming soon)","")
				.replace("Sold Out! Final Opportunities Coming Soon!", "Sold Out!")
				.replace("Final Opportunities in Current Phase", "Final Opportunities Current Phase").replace("Limited Opportunities Coming this Summer", "Limited Opportunities Coming Summer")
				.replaceAll("Quick Move-in|Quick Move-In|Quick Move-in Available|One Quick Move-in Available|Quick Move-ins and|Last Quick Move-In Now Available|Inventory Homes Now Available|Quick Move-in Homes Coming Soon|Model  Coming Soon!|1-acre home sites available| cabana are now open|Model Coming Soon|acre and wooded home sites available|school coming|pad coming soon|Two Quick Move-ins Coming Soon|Cove - Coming 20\\d+|\"\\[Closeout|\"Closeout|\"special_message\":\"Quick Move-in Homes Coming Soon!\"|\"unit_status\":\"[Closeout]\"", ""));
		
		U.log("Status : "+pstatus);
		
		if(comurl.contains("/vandalia/meadowview_at_vandalia/"))pstatus=pstatus.replace("Coming Soon, ", "");
//		String quickmovesec=U.getSectionValue(html, "class=\"gtm-qmi-jump-link\"", "</a>");
		//String quickmovesec=U.getSectionValue(html, "<div class=\"home-cards\"", "</span></div></section> <!----></div>");
//		U.log("quickSec:::::"+quickmovesec);
		//if(quickmovesec==null)
		String quickmovesec=U.getSectionValue(U.getHTML(comurl), "qmis:[{", "plan:{detail:{neighborhoodPlan:{}}}}");
//		String quickchk=ALLOW_BLANK;
//		quickchk=U.getSectionValue(quickmovesec, "details_url:\"","\"");
		//U.log("CHK"+quickchk);
	//	if(quickchk.contains("quick-move-in"))
		
		
		
		
//    	if(quickmovesec!=null) {//&& quickmovesec.contains("details_url:")) {// && quickmovesec.contains("details_url:\"https:")) {

			if(quick>0) {
			if(pstatus.length()>4) {
				pstatus +=", Quick Move-Ins";
			}
			else {
				pstatus="Quick Move-Ins";
			}
			}
		U.log("Status : "+pstatus);
		
//		U.log(">>>>>>>>>>>> "+Util.matchAll(html, "[\\s\\w\\W]{30}Sold out[\\s\\w\\W]{30}", 0));
		
		pstatus= pstatus.replace("Quick Move-in Homes, Quick Move-Ins", "Quick Move-Ins").replace("Final Phase Coming Soon, Final Phase", "Final Phase Coming Soon");
		pstatus=pstatus.replace("Quick Move-Inss Available, Quick Move-Ins","Quick Move-Ins");
		pstatus=pstatus.replace("Quick Move-ins Available, Quick Move-Ins","Quick Move-Ins");

		if (data.communityUrlExists(comurl)) {
			LOGGER.AddCommunityUrl(comurl + "*************repeated************");

			return;
		}
		if (maxPrice == null || maxPrice.length() == 2) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null || minPrice.length() == 2) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (comType == null)
			comType = ALLOW_BLANK;
		String note=U.getnote(html.replaceAll("\"text_info\":\"Now Pre-Selling New Phase 1|u003ENow Pre-Selling New Phase 1|2Fpresales", ""));
		
		if(pstatus!=null)
			pstatus = pstatus.replace("Just Released, New Home Sites Just Released", "New Home Sites Just Released")
			.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		if(comName!=null)comName = comName.replace("Arcadia - Vineyards Condos", "Arcadia - Vineyards").replace("One-Level Living", "");
		//repeated Status formattoing(DT 27 jul 21)
		pstatus = pstatus.replace("Sold-out", "Sold Out")
				.replace("Coming Summer 2022, Final Phase Coming Summer 2022", "Final Phase Coming Summer 2022")
				.replace("New Phase, Now Selling New Phase", "Now Selling New Phase")
				.replace("Final Phase Coming Soon, Current Section Sold Out, Final Phase", "Final Phase Coming Soon, Current Section Sold Out")
				.replace("Final Phase, Final Phase Selling Quickly", "Final Phase Selling Quickly")
				.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
	

		if(comurl.contains("/houston/community/towne_lake/towne_lake_95s/"))dtype="1 Story";
		if(comurl.contains("cantering_hills_at_steeplechase_townhomes"))comName="Cantering Hills at Steeplechase";
		if(comurl.contains("community/woodcreek_crossing/woodcreek_crossing/"))pstatus=pstatus.replace(", Quick Move-Ins", "");
		//U.log("comName>>>>>>>>>>>"+comName);
		if(comurl.contains("custom-homes/cincinnati-northern-kentucky/community/manor_hill/manor_hill/"))pstatus=pstatus.replace("New Phase, Coming This Fall", "New Phase Coming This Fall");

		
		
		
		data.addCommunity(comName.replace("&#x27;s", " &"), comurl, comType);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("&amp;", "&"), add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(pType, dtype);
		data.addPropertyStatus(
		pstatus.replace("Quick Move-Inss Available, Quick Move-Ins","Quick Move-Ins").replace("Quick Move-Inss Available","Quick Move-Ins Available").replace("Quick Move-Inss","Quick Move-Ins").replace("Quick Move-Ins Homes Coming Soon, Quick Move-Ins", "Quick Move-Ins Homes Coming Soon").replace("Quick Move-in", "Quick Move-Ins").replace("Quick Move-Ins, Quick Move-Ins", "Quick Move-Ins").replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon"));
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		}
		j++;
		}
	
//	catch (Exception e) {
//	
//		U.log(e);}
	}
	
//	public static String getUnits(String comUrl, String html, WebDriver driver) throws Exception {
		public static String getUnits(String comUrl, String html, WebDriver driver) throws Exception {

		
		int totalCount = 0; String totalUnits = ALLOW_BLANK; 
		String mapData = ALLOW_BLANK;
		
		U.log("comUrl from getUnits: "+comUrl);
		
		if(html.contains("View Interactive Site Plan")) {
			U.log("INside");
		String[] comSplit = comUrl.split("/");
		U.log("comSplit length: "+comSplit.length);
		for(int i=0; i<comSplit.length; i++) {
			U.log(+i+" : "+comSplit[i]);
		}
		
		String linkForId = "https://www.dreeshomes.com/sales-plat-api/api/v1/area/"+comSplit[4]+"/community/"+comSplit[6]+"/neighborhood/"+comSplit[7];
		U.log(">>> linkForId: "+linkForId);
		
		String idData = U.getHTML(linkForId);
		
		if(idData != null) {
			String id = U.getSectionValue(idData, "\"id\":\"", "\",");
			U.log(">>> id: "+id);
			
			String lotLink = "https://www.dreeshomes.com/sales-plat-api/api/v1/legend/neighborhood/" + id ;
			U.log(">>> lotLink: "+lotLink);
			
			String lotData = U.getHTML(lotLink);
			
			if(lotData.contains("\"Available\",\"count\"")) {
				
				String available = U.getSectionValue(lotData, "\"Available\",\"count\":", ",\"");
				U.log("available: "+available);
				totalCount = totalCount + Integer.parseInt(available);
			}
			
			if(lotData.contains("\"Quick Move-In\",\"count\"")) {
				
				String quickMove = U.getSectionValue(lotData, "\"Quick Move-In\",\"count\":", ",\"");
				U.log("quickMove: "+quickMove);
				totalCount = totalCount + Integer.parseInt(quickMove);
			}
			
			if(lotData.contains("\"Sold\",\"count\"")) {
				
				String sold = U.getSectionValue(lotData, "\"Sold\",\"count\":", ",\"");
				U.log("sold: "+sold);
				totalCount = totalCount + Integer.parseInt(sold);
			}
			
			if(lotData.contains("\"Reserved\",\"count\"")) {
				
				String reserved = U.getSectionValue(lotData, "\"Reserved\",\"count\":", ",\"");
				U.log("reserved: "+reserved);
				totalCount = totalCount + Integer.parseInt(reserved);
			}
			
			if(lotData.contains("\"Model\",\"count\"")) {
				
				String model = U.getSectionValue(lotData, "\"Model\",\"count\":", ",\"");
				U.log("model: "+model);
				totalCount = totalCount + Integer.parseInt(model);
			}
			
			totalUnits = String.valueOf(totalCount);
		}
	}
	return totalUnits;
}
	
//	public static String getUnits(String comUrl, String html, WebDriver driver) throws Exception {
//		
//		int totalCount = 0; String totalUnits = ALLOW_BLANK; 
//		String mapData = ALLOW_BLANK;
//		
//		if(html.contains("View Interactive Site Plan")) {
//			try {
//				mapData = U.getHtml(comUrl + "plat" , driver);
//			} catch (Exception e) {}
//			
//			
//			if(mapData.contains("<path id=\"_x31")) {
//				
//				String[] lotOne = U.getValues(mapData, "<path id=\"_x31", "\"");
//				U.log("lotOne: "+lotOne.length);
//				totalCount = totalCount + lotOne.length;
//			}
//			
//			if(mapData.contains("<path id=\"_x32")) {
//				
//				String[] lotTwo = U.getValues(mapData, "<path id=\"_x32", "\"");
//				U.log("lotTwo: "+lotTwo.length);
//				totalCount = totalCount + lotTwo.length;
//			}
//			
////			if(mapData.contains("<path id=\"_x33")) {
////				
////				String[] lotTwo_1 = U.getValues(mapData, "<path id=\"_x33", "\"");
////				U.log("lotTwo_1: "+lotTwo_1.length);
////				totalCount = totalCount + lotTwo_1.length;
////			}
//			
//			if(mapData.contains("<path id=\"_x34")) {
//				
//				String[] lotThree = U.getValues(mapData, "<path id=\"_x34", "\"");
//				U.log("lotThree: "+lotThree.length);
//				totalCount = totalCount + lotThree.length;
//			}
//			
//			if(mapData.contains("<path id=\"_x35")) {
//				
//				String[] lotThree = U.getValues(mapData, "<path id=\"_x35", "\"");
//				U.log("lotThree: "+lotThree.length);
//				totalCount = totalCount + lotThree.length;
//			}
//
//			if(mapData.contains("<path id=\"_x36")) {
//	
//				String[] lotThree = U.getValues(mapData, "<path id=\"_x36", "\"");
//				U.log("lotThree: "+lotThree.length);
//				totalCount = totalCount + lotThree.length;
//			}
//			
//			totalUnits = String.valueOf(totalCount);
//			U.log("totalUnits: "+totalUnits);
//		}
//		
//		return totalUnits;
//		
//	}

}
