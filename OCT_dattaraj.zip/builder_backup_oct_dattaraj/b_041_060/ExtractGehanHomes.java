/**
l * @author Rakesh Chaudhari
 * @date 22 Jun 2015
 * 
 */
/**
 * @author Rakesh Chaudhari
 * @date 22 Jun 2015
 * 
 */
package com.shatam.b_041_060;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGehanHomes extends AbstractScrapper {
	CommunityLogger Logger;
	static int i = 0;
	public static int k=0;
	public int inr = 0;
	public static int duplicates = 0;
	String latlngs[];
	static WebDriver driver = null;
	

	public static void main(String[] args) throws Exception {

		
		AbstractScrapper a = new ExtractGehanHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Gehan Homes.csv", a.data().printAll());
		U.log(duplicates);
		U.log(i);
	}

	public ExtractGehanHomes() throws Exception {

		super("Gehan Homes", "https://www.gehanhomes.com/");
		Logger = new CommunityLogger("Gehan Homes");
		
	}

	public void innerProcess() throws Exception {
				
		U.setUpGeckoPath();
		//driver=new FirefoxDriver();
		
		DesiredCapabilities capabilities = DesiredCapabilities.firefox(); 
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("permissions.default.image", 2);
		capabilities.setCapability("firefox_profile", profile);
		driver = new FirefoxDriver(capabilities);

				
//	    U.setUpChromePath();
//	    driver = new ChromeDriver();
//		String html = U.getHtml("https://www.gehanhomes.com/", driver);
		String html = U.getHTML("https://www.gehanhomes.com/").replace("\\\"", "\"");

//		String sec = U.getSectionValue(html, "homeLocationsNav footerNav setActiveNav", "</ul>");
		String sec = U.getSectionValue(html, "\">Now, Let's Find Your New Home!</span></h1> ", "</section> ");

		String regUrl[] = U.getValues(sec, " href=\"", "\"");
		U.log("----------total region==" + regUrl.length + "---------------");
		for (String region : regUrl) {
			U.log("----------Start region" + region + "---------------");
			//U.log("https://www.gehanhomes.com" + region);
			if (region.contains("estate")){
			     	U.log("+++++++++++++++++++++DUPLICATES"+region);
				//html = U.getHTML(region);
				continue;
				}
			//html = U.getHTML("https://www.gehanhomes.com" + region);
			
			html = U.getHtml("https://www.gehanhomes.com" + region, driver);
				
			
			String commLinksSec[] = U.getValues(html, " <div id=\"card_body_comm", "More Details</span");
			U.log("no. of com url:"+commLinksSec.length);
			
			for (String commSec : commLinksSec) {
				
				String url = U.getSectionValue(commSec, "<a href=\"", "\"");
				
				if (this.data.communityUrlExists("https://www.gehanhomes.com"+url)) {
					duplicates = duplicates + 1;
					U.log("+++++++++++123++++++++++DUPLICATES"+duplicates);
					continue;
				}
				
				addDetails("https://www.gehanhomes.com" + url, commSec);
				
				//U.log("com Link: "+link);
				inr++;
			
				i++;
			}
			
			inr = 0;
		}
		Logger.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}
	//TODO : Extact communities detail here
	private void addDetails(String url, String commSec) throws Exception {

//		try{
			
		//Single Run
//		if(!url.contains("https://www.gehanhomes.com/new-homes/texas/dallas-fort-worth/community/Mitchell-Farms-165646")) return;
		
		if(k == 92)
//		if(k >=71 && k<90)
//		if(k >=35 && k <=50)
			
		{
			
//			U.log(commSec);
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/houston/midtown-at-magnolia/")) {
			Logger.AddCommunityUrl("=======Page Not found======"+url);
			return;
		}
		
		if(url.contains("https://www.gehanhomes.com/find-your-new-home/dallas-fort-worth/green-oaks-preserve/")) {
			Logger.AddCommunityUrl("======Redirecting to region page======="+url);
			return;
		}
		String geo = "False";
		U.log("\n\n:::::::::community no:::::::::"+k+"::::::::::::::::\n");
		
		/*//check whether the community cache file exist
		isUrlAlreadyExist(url);*/
		
		String html = getHtml1(url, driver);
		String quik=html;
		String[] remm=U.getValues(html, "Filters</span> ", ">Search</span>") ;
		for(String remove: remm) {
			html=html.replace(remove, "");
		}
		html=U.removeSectionValue(html, "Neighborhoods Near <span", "</body>");
		
//		Logger.AddCommunityUrl(url);
		
		}
k++;

//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
	
	
	
	public static String getHtml1(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(10000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					if(isElementPresent(By.className("view-more-cards"))) {
						driver.findElement(By.className("view-more-cards")).click();
					}
					if(isElementPresent(By.className("view-more-cards"))) {
						driver.findElement(By.className("view-more-cards")).click();
					} 
					Thread.sleep(10000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(10000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

	
	
	private static boolean isElementPresent(By className) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isUrlAlreadyExist(String url){
		String cacheFilePath=ALLOW_BLANK;
		cacheFilePath = U.getCacheFileName(url);
		File f = new File(cacheFilePath);
		if(f.exists()){
		 f.delete();
		 return true;
		 
		}
		return false;


		}

	

}


