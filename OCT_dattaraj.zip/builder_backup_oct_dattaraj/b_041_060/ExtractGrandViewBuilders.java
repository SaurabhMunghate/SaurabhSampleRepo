/*
 * Modification Aditya.
 */
package com.shatam.b_041_060;

import java.util.ArrayList;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractGrandViewBuilders extends AbstractScrapper 

{
	CommunityLogger LOGGER;
	int i=0;	public int inr=0;
	public static void main(String[] args) throws Exception {

		
		AbstractScrapper a = new ExtractGrandViewBuilders();
		a.process();
		FileUtil.writeAllText("/home/sahil/Cache/Century Communities - Grand View Builders.csv", a.data().printAll());
	}

	public ExtractGrandViewBuilders() throws Exception 
	{

		super("Century Communities - Grand View Builders", "http://www.gvbtx.com/");
		LOGGER = new CommunityLogger("Century Communities - Grand View Builders");
	}

	
	public void innerProcess() throws Exception {
		String url = "http://www.gvbtx.com/Communities";
		String base = "http://www.gvbtx.com/";
		String html = U.getHTML(url);
		//address
		
		String sec = U.getHtmlSection(html, "id=\"comms\"></a>",
				"id=\"sidebar\">");
		String values[] = U.getValues(sec, "<a href=\"", "\"");
		U.log("==============values==========="+values[0]);
		ArrayList<String> com = new ArrayList<String>();
		int totalComm=values.length/2;
		ArrayList<String> URL_LIST = new ArrayList<String>();
		for (String itom : values) 
		{
			if (!com.contains(itom)) 
			{
				com.add(itom);
					
				URL_LIST.add(itom);
				
			}
		}
		String commLatNameSection = U.getSectionValue(html,
				"var points = new Array;", "correctZoom(map,");
	/*	String latLngSec=U.getSectionValue(commLatNameSection, "tL", "var marker");*/
		

		
		
		
		ArrayList<String> commLat= new ArrayList<String>();	
		String commSection="";
		commSection = U.getSectionValue(html, "var points = new Array;", "correctZoom");
		
	//	LOGGER.countOfCommunity(URL_LIST.size());
		for (String itom : values) 
		{
			
				
				
				
			
			addDetails(base + itom,commSection);
			i++;inr++;
			//break;
			}
		
		U.log(com.size());
		LOGGER.DisposeLogger();
	//	addDetails("http://www.gvbtx.com/comm_profile.php?com=29");
	}

	private void addDetails(String comUrl,String commSection) throws Exception {
	//	U.log("\n"+comUrl);
		U.log(commSection.length()+"================="+commSection);
		String lat="";
		String lng="";
		String[] latLng={ALLOW_BLANK,ALLOW_BLANK};
		String[] latValue={ALLOW_BLANK};
		
		ArrayList<String>impSec=new ArrayList<String>();
		String[] latLNGS=U.getValues(commSection, "= new GLatLng", "map.addOverlay");
		for(String latS:latLNGS){
			String latlll=U.getSectionValue(latS, "(", ")");
			String latName=U.getSectionValue(latS, "txt01\\\"", "</span>");
			impSec.add(latlll+","+latName);
		
			
			U.log(" hello  "+latS);
		}
		String base = "http://www.gvbtx.com/";
		String htm = U.getHTML(comUrl);
		
		String commName = U.getSectionValue(htm,
		"<h4 style=\"font-size: 18px;\">", "</h4>");
U.log(commName);

		/*latLng=latValue[0].split(",");
		lat=(latLng[0]!=null)? latLng[0] : ALLOW_BLANK;
		lng=(latLng[1]!=null)? latLng[1] : ALLOW_BLANK;
		U.log("Lat:" + lat + " Long:" + lng);
		String geo="False";*/
String pri="";
	for(String na:impSec){
		if(na.contains(commName))
		
		{
			pri=na.replace(commName+",","");
			
		}
}
		
	U.log("888888888888888888888"+pri);
	String geo="";
//	if(pri.length()>4)
//	{
//	latLng=pri.split(",");
//	lat=(latLng[0]!=null)? latLng[0] : ALLOW_BLANK;
//	lng=(latLng[1]!=null)? latLng[1] : ALLOW_BLANK;
//	U.log("Lat:" + lat + " Long:" + lng);
//	 geo="False";
//	}
	
	
	
	
		//commnity Url
		
		
		
		
		// commname
		/*String commNames=U.getSectionValue(commSection, "<span class=\\\"comm_click_txt01\\\"> ", "</");
		String communityName="";
	
		U.log("===========comnamesSec========"+commNames);*/
		
		/*//Address
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String addrs=U.getSectionValue(commSection, "</span></a><br>", "</p>\");}").replaceAll("<br>",",");
		add=addrs.split(",");
		String street=add[0];
		String city=add[1];
		String stateZip=add[2];
		String state=Util.match(stateZip, "\\w+");
		String zip=Util.match(stateZip, "\\d+");
		*/
		/*String city=cityA[0];
		String zip=Util.match(txt, findPattern)
		*/
		/*U.log("street===="+street+"city======="+city+"state========="+state+"zip======="+zip);
		U.log("===========address========"+addrs);*/
		/*if(commNames==null){
		commNames=ALLOW_BLANK;
		}*/
		/*String commName = U.getSectionValue(html,
				"<h4 style=\"font-size: 18px;\">", "</h4>");
		U.log(commName);*/
		
		//latLong
		/*if (this.data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
			
			return;
		}
		*/
		LOGGER.AddCommunityUrl(comUrl);
		
		// Address=
		String add[] = new String[] { ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK, ALLOW_BLANK };
		String gLink=Util.match(htm, "href=\"([^\"]+)[^>]+>\\s*Map Community", 1);
		gLink=gLink.replace("http:", "https:");
		U.log(gLink);
		String[] addr=U.getGoogleAddress(U.getHTML(gLink));
		U.log(gLink);
		
		if(addr!=null)
			add=addr;
		add[0]=add[0].replace("Americas Best Value Inn & Suites,", "");//
		add[0]=add[0].replace("Houston Massage Clinic,", "");//
		add[0]=add[0].replace("Grand View Builders,", "");//La Marque Middle School, 
		add[0]=add[0].replace("La Marque Middle School,", "");
		
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"
				+ add[3]);
		/*
		//Lat Long
		String lat=ALLOW_BLANK,lng=ALLOW_BLANK;String[] latLong={lat,lng};
		if(add[0]!=null){
		latLong= U.getGooleLatLong(add);
		lat=(latLong[0]!=null)? latLong[0] : ALLOW_BLANK;
		lng=(latLong[1]!=null)? latLong[1] : ALLOW_BLANK;
		U.log("Lat:" + lat + " Long:" + lng);
		
		}*/
		//missing lat lng
	
		
	
		String squrl = U.getSectionValue(htm,
				"<li id=\"comm_nav_plans\"><a href=\"", "\"");
		U.log(base + squrl);
		String flowUrl=base+squrl;
		String floHtml = U.getHTML(base + squrl);

		// squae feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(floHtml,
				"<strong>Square Feet:\\s[^>]+>([^<]+)", 1);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		// U.log("me"+sqft[0]);
		if (minSqf.length() < 4)
			minSqf = ALLOW_BLANK;
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		// price
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		U.log(base + squrl);
		// floHtml=floHtml.replaceAll("'","");
		String moveUrl=flowUrl.replace("plans", "movein");
		//U.log("++++++++++++++++++++"+moveUrl);
		String moveHtml=U.getHTML(moveUrl);
		
		
		
		String sec=U.getSectionValue(htm, "<div class=\"sidebar_infobox\">", "</html>");
		htm=htm.replace(sec, "");
		
		sec=U.getSectionValue(moveHtml, "<div class=\"sidebar_infobox_top\">", "</html>");
		if(sec!=null)moveHtml=moveHtml.replace(sec, "").replace("From the $280,000s","");
		
		floHtml=floHtml.replace(sec, "");
		
		floHtml=floHtml.replace("$$", "$");
		
		//drop showcase section from floorhtml
		String dropSec=U.getSectionValue(floHtml, "<div class=\"sidebar_infobox\">", "Learn More</a><");
		if(dropSec!=null)
		floHtml = floHtml.replace(dropSec, "");
		
		String[] price = U
				.getPrices(
						floHtml+moveHtml+htm,
						"<strong>Price:</strong> \\$\\d+,\\d+|Price:</strong> \\$\\d+,\\d+|Priced From:</strong> \\$\\d+,\\d+|Price Range:</strong> From the \\$\\d+,\\d+|Price Range:</strong> \\$\\d+,\\d+|\\$\\d{6}|<strong>Price:</strong> \\d+,\\d+",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		minPrice = minPrice.replace("'", "");
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		if (minPrice.equals(ALLOW_BLANK)) 
		{
			minPrice = U.getSectionValue(htm,
					"<h5><strong>Price Range:</strong> From the ", "s");
			maxPrice = ALLOW_BLANK;
			if(minPrice!=null)
			minPrice = minPrice.replace("'", "");
		}
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		String pType = U.getPropType(htm + floHtml);
		if (pType == ALLOW_BLANK) {
			//pType = "Single Family";
		}
		String note=ALLOW_BLANK;
		
		String status= ALLOW_BLANK;
		String statSec= htm;
		String remove= "Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|Now-open|now-open|now open";
		statSec= statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		status= U.getPropStatus(statSec);
		
		String adress=U.getSectionValue(htm, "<div class=\"comm_header_col02\">", "</h5>");
	U.log("====================Address==============="+adress);
		adress=U.getSectionValue(adress, "<strong>", "<");
		if(adress!=null){
		String adds[]=adress.split(",");
			add[0]=adds[0];
			//if(add[1]==ALLOW_BLANK){
				add[1]=adds[1];
				if(adds[2].trim().length()>2)
				add[2]=USStates.abbr(adds[2]);
				else
					add[2]=adds[2].trim();
			//}
		}
		
		//<div class="comm_module_content" style="height: 375px;">
	
	//11 th community address:Tomball,TX 77375
	U.log("status length :: "+status.length() +" status :: "+status );
//	if(status==ALLOW_BLANK)status="";
//		
//		if(moveHtml.contains("<div class=\"comm_module_content\" style=\"height: 375px;\">"))
//		{
//			
//			if(status.length()<1)
//				status="Move In ready";
//			else
//				status=status+",Move In ready";
//		}
//		
//		else{
//			if(status.length()<1)
//				status="No Move In ready";
//			else
//				status=status+",No Move In ready";
//			
//		}
	
		U.log(lat+"result");
		U.log("address"+add[0]);
		add[0]=add[0].replaceAll("by appointment only|By Appointment Only",ALLOW_BLANK);
		String latlngs[]={ALLOW_BLANK,ALLOW_BLANK};
		add[0]=add[0].trim();
		U.log("address::"+add[0].length());
if(add[0].length()!=1&&lat.length()<3 ){
	latlngs=U.getlatlongGoogleApi(add);
		lat=latlngs[0];
		lng=latlngs[1];
		geo="True";
		U.log("Hello");
		}


	/*if(add[3]==ALLOW_BLANK&&lat!=ALLOW_BLANK){
		String addrs[]=U.getAddressGoogleApi(latlngs);
		add[3]=addrs[3];
}
	
if(lat==null && lng==null)
{
	String latslngs[] = { lat, lng };
	String url = "http://www.gvbtx.com/Communities";

	String htm = U.getHTML(url);

	
	if(htm.contains("http://www.gvbtx.com/comm_profile.php?com=25"))
	{
		
		
		String latLngSec = U.getSectionValue(htm,
				"var point10 = new GLatLng", "points[10] = ");

		latslngs = U.getValues(latLngSec, "(", ");");
		latslngs = latslngs[0].split(",");
		lat = latslngs[0];
		lng = latslngs[1];

		U.log("lat========" + lat + "======lng=======" + lng);
	}
}
if(add[0].length()==1){
	lat=lng=geo=ALLOW_BLANK;
}*/

	U.log(minPrice);
		if(minPrice==null)
		{
			minPrice=ALLOW_BLANK;
			maxPrice=ALLOW_BLANK;
		}
		String[] plansLink=U.getValues(floHtml, "&raquo; <a href=\"", "\">");
		String dHtml="";
		for(String link: plansLink)
		{
			U.log("sahil"+link);
			String linkHtml=U.getHTML("http://www.gvbtx.com/"+link);
			//U.log(linkHtml);
			dHtml=dHtml+linkHtml;
		}
		if(lat.length()<4)
		{
			String[] la=U.getlatlongGoogleApi(add);
			lat=la[0];
			lng=la[1];
			geo="True";
		}
		String[] latl={lat,lng};
		String[] addrs=U.getAddressGoogleApi(latl);
		add[3]=addrs[3];
		if(add[0].length()<4)
			add[0]=addrs[0];
		
String dType=U.getdCommType(dHtml+htm+moveHtml);
htm=htm.replace("resort style","Resort-style");
String commType=U.getCommunityType(htm + floHtml);
		if(comUrl.contains("http://www.gvbtx.com/comm_profile.php?com=31"))
		{
			status="Coming soon";
		}
		if(this.data.communityUrlExists(comUrl))
			return;
		//if(comUrl.contains("http://www.gvbtx.com/Village-Of-Oak-Forest"))maxPrice="$282,490";
		
		data.addCommunity(commName, comUrl, commType);
		data.addAddress(add[0],add[1],add[2].trim(),add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(),geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status.replace("-,", ""));
		data.addNotes(note);
		// TODO Auto-generated method stub

	}

	}

