/**
 * @author Mrutyunjay
 * @date 13 Jan 21
 */
package com.shatam.b_041_060;



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLgiHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int repeat =0;
	int i = 0;
	WebDriver driver=null;
	public int inr = 0;
	static int duplicates = 0;
	ArrayList<String[]> set =new ArrayList<String[]>();
	private static final String builder_url = "https://www.lgihomes.com";
	
	static int count = 0;
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractLgiHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"LGI Homes.csv", a.data().printAll());
		U.log("duplicate::"+duplicates);
	}

	public ExtractLgiHomes() throws Exception {

		super("LGI Homes", "https://www.lgihomes.com/");
		LOGGER = new CommunityLogger("Lgi Homes");
		
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver=new ChromeDriver();
		String url = "https://www.lgihomes.com/";
		String html = U.getHTML(url);
		String comsec[]=U.getValues(html, "{\"Name\":", "\"Boost\""); 
		U.log("comsec.length: "+comsec.length);
		
		
		for(String c:comsec) {
//			U.log(c);
//			String section = U.getSectionValue(c, "\"ItemUrl\":\"", "\"");
//			U.log("section : "+section);
			String itemurl1 = U.getSectionValue(c, "\"ItemUrl\":\"", "\"");
			
			String commname=U.getSectionValue(c, "\"", ",");
			
			String[]d=itemurl1.trim().split("/");
			U.log("region ::"+itemurl1);
			U.log(d.length);

			if(d.length==3) {
				itemurl1 = builder_url + itemurl1;
				
				getcommunity(itemurl1,driver);
			  }
			 
				  
		}
		U.log("Total comm. count ::"+count);
		LOGGER.DisposeLogger();
		driver.quit();
	}

	

	private void getcommunity(String itemurl1, WebDriver driver) throws Exception {
		
		String html=getHtml(itemurl1, driver);
		
		String commsec[]=U.getValues(html, "<div class=\"coveo-card-layout CoveoResult\">", "View Community");
		//U.log("commsec length: "+commsec.length);

		
		U.log(itemurl1+"============="+commsec.length);
		for(String a:commsec) {
			String url= builder_url +U.getSectionValue(a, "href=\"", "\"");
			//U.log("============="+url);
			addDetails(url,html);
			
			count++;
		}
		
	}
	//TODO:
	private void addDetails(String itemurl,String reghtml1) throws Exception {
//    if(i>=52)
	
//		try{
{

//	if(!itemurl.contains("https://www.lgihomes.com/colorado/denver/cottonwood-greens"))return;

		if (data.communityUrlExists(itemurl)){
			LOGGER.AddCommunityUrl(itemurl+ "***************************Repeated Url");
			return;
		}
		LOGGER.AddCommunityUrl(itemurl);	
		U.log(i+"=================" + itemurl);

		String html=U.getHTML(itemurl);
		String rmSec=U.getSectionValue(html, "<h2 class=\"title\">Nearby Communities</h2>", "<div class=\"footer bottom\">");
		if(rmSec!=null)
			html=html.replace(rmSec, "");
		
		String comname=U.getSectionValue(html, "<h3 class=\"title\">", "</h3>").replace("TRACE", "Trace");
		
		comname = comname.replace("&#39;s", "'s").replace("Segovia at Estrella™", "Segovia at Estrella");
		
		U.log("comName :"+comname);
		//======= Note ===========
		
		String note=U.getnote(html.replace("when we open for sales.", ""));

		
		//========= Address ========
	//	String geoCode = "False";
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		String geo="FALSE";
//		String addr=ALLOW_BLANK;
		
			html=html.replace("\"postalCode\": \"0\",", "\"postalCode\": \"\",");
			street=U.getSectionValue(html, "\"streetAddress\": \"", "\"");
			city=U.getSectionValue(html, "\"addressLocality\": \"", "\"");
			state=U.getSectionValue(html, "\"addressRegion\": \"", "\"");
			zip=U.getSectionValue(html, "\"postalCode\": \"", "\"");
			
			if(street == ALLOW_BLANK && zip == ALLOW_BLANK && state == ALLOW_BLANK) {
				street=U.getSectionValue(html, "\"address\":\"", "\"");
				city=U.getSectionValue(html, "\"city\":\"", "\"");
				state=U.getSectionValue(html, "\"state\":\"", "\"");
				zip=U.getSectionValue(html, "\"zipcode\":\"", "\"");
			}

			add[0]=street;
			add[1]=city;
			add[2]=state;
			add[3]=zip;
			if(add[0]!=null && add[0].length()>=4)
			add[0]=add[0].replace("2481 Del Prado Blvd North, Suite 117", "2481 Del Prado Blvd North Suite 117");
			
			U.log("Add: "+Arrays.toString(add));
			
			//Latlong

//			String latlagsec=U.getSectionValue(html, "<a class=\"link action-communityoverview-direction\"", "</div>");
//			if(latlagsec!=null) {
//				 String latlagsec1=U.getSectionValue(latlagsec, "@", "z/");
//				 U.log(">>>>>>>="+latlagsec1);
//				 if(latlagsec1!=null) {
//				 latLong=latlagsec1.split(",");
//				 }
//			}
			
			
			String	latlagsec=U.getSectionValue(html, "<a class=\"link action-communityoverview-direction\" ", "Get Directions");
U.log("latlagsec===="+latlagsec);
			if(latlagsec!=null && latlagsec.contains("/@")) 
			{
				
				latLong[0]=U.getSectionValue(latlagsec, "!3d", "!4d");
				latLong[1]=U.getSectionValue(latlagsec, "!4d", "!");
				U.log("latLong-1===="+latLong[0]+"\t"+latLong[1]);
				if(latLong[1]==null) {
					String latlng=U.getSectionValue(latlagsec, "!4d", "\"");
				U.log(">>>>>>>>>>>DDDDDDDDDDD"+latlng);

					if(latlng!=null) {
					latLong[1]=Util.match(latlng, "-\\d+.\\d{1}\\d+");
					}
//					if(latlng!=null) {
//						latLong[1]=Util.match(latlng, "-\\d{3}.\\d{1}\\d+");
//						}
				}
				U.log("latLong-2===="+latLong[0]+"\t"+latLong[1]);

			
			if(latLong[1]!=null) {
				latLong[1]=latLong[1].replace("?", "");
			}
			U.log("latLong-3===="+latLong[0]+"\t"+latLong[1]);

			
			}
			
//			else {
////				U.log(">>>>>>>>>>>DDDDDDDDDDD");
//				latlagsec=U.getSectionValue(html, "class=\"community-map", "</div>");
//			
//			if(latlagsec!=null) {
//			latLong[0]=U.getSectionValue(latlagsec, "data-lat=\"", "\"");
//			latLong[1]=U.getSectionValue(latlagsec, "data-lng=\"", "\"");
//			U.log("latLong-4===="+latLong[0]+"\t"+latLong[1]);
//
//			}
//			}
			
			if(latLong[0]==null) {
				latlagsec=U.getSectionValue(html, "<a class=\"link action-communityoverview-direction\" ", "Get Directions");
				
								if(latlagsec!=null) {
									latLong[0]=U.getSectionValue(latlagsec, "/@", ",");
									latLong[1]="-"+U.getSectionValue(latlagsec, ",-", ",");
									U.log("latLong-5===="+latLong[0]+"\t"+latLong[1]);

			}
			}
			
			
			
			if(add[0].length()<4 && add[1].length()<4) {
				U.log(">>>>>>>>>>>DDDDDDDDDDD");
				latlagsec=U.getSectionValue(html, "class=\"community-map", "</div>");
			
			if(latlagsec!=null) {
			latLong[0]=U.getSectionValue(latlagsec, "data-lat=\"", "\"");
			latLong[1]=U.getSectionValue(latlagsec, "data-lng=\"", "\"");
			U.log("latLong-4===="+latLong[0]+"\t"+latLong[1]);
//
			}
			}
			
			
			U.log("LATLONG::::"+latLong[0]+"   "+latLong[1]);
			
//			
////			else {
////				 latlagsec=U.getSectionValue(html, "<a class=\"link action-communityoverview-direction\" ", "Get Directions");
////
////				if(latlagsec!=null) {
////					latLong[0]=U.getSectionValue(latlagsec, "/@", ",");
////					latLong[1]="-"+U.getSectionValue(latlagsec, ",-", ",");
////			}
////			
////		}
//			}
		if(itemurl.contains("https://www.lgihomes.com/texas/houston/lago-mar")) {
			add[0]="Lago Mar Blvd";
			add[1]="Dickinson";
			add[2]="TX";
			add[3]="77539";
			geo="TRUE";
		}
		if(latLong[0] == null) latLong[0] = latLong[1] = ALLOW_BLANK;
				
				
				U.log(Arrays.toString(latLong));
				
				if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
					latLong = U.getlatlongGoogleApi(add);
					if (latLong == null)
						latLong = U.getGoogleLatLngWithKey(add);
//					latlag=U.getBingLatLong(add);

					geo = "TRUE";
				}
				if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
					add = U.getAddressGoogleApi(latLong);
					if (add == null)
						add = U.getAddressHereApi(latLong);
					geo = "TRUE";
				}
				if (add[3] == null && latLong[0] != ALLOW_BLANK) {
					String[] add1 = U.getAddressGoogleApi(latLong);
					if (add1 == null)
						add1 = U.getAddressHereApi(latLong);

					add[3] = add1[3];
					add1 = null;
					geo = "TRUE";
				}

//				U.log("GEO: "+geo);	
				
		//==============================floorplans=====================================================
				String floorplansec=U.getSectionValue(html, "\"@type\": \"OfferCatalog\"", "</script>");
				String floorhtml=null;
				String floorpricesec = ALLOW_BLANK;
				
				String floorplandetails=ALLOW_BLANK;
				String floorplandesc=null;
				String floorplandesc1=null;
				if(floorplansec!=null) {
				String floorurls[]=U.getValues(floorplansec, "\"@id\": \"", "\",");
				
			
				for(String fu:floorurls) {
					U.log("fu: "+fu);
					String floorurl="https://www.lgihomes.com"+fu;
					
					floorhtml=U.getHTML(floorurl);	
					floorpricesec += U.getSectionValue(floorhtml, "<span class=\"starting-price\">", "</span>");
					
					floorplandetails +=U.getSectionValue(floorhtml, " <ul class=\"floorplan-details\">", "trademark-icon");
					
					floorplandesc += U.getSectionValue(floorhtml, "floorplan-content", "<div class=\"floorplan-right\">");
					floorplandesc1+=U.getSectionValue(floorhtml, "<div class=\"diagram-container\">", "Floor Plan Features:");
				}
				}
				
				
		
		//===========================prices=====================================================
				
				String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
				String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
				
				String minPrice=ALLOW_BLANK;
				String maxPrice=ALLOW_BLANK;
				String minsqft=ALLOW_BLANK;
				String maxsqft=ALLOW_BLANK;
				
				
				
				prices=U.getPrices(html+floorpricesec, "From \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
				
				minPrice=prices[0];
				maxPrice=prices[1];
				
				
//				U.log(Arrays.toString(prices));
				String regSqft=ALLOW_BLANK;
				String regSqftSec[]=U.getValues(reghtml1, "<div class=\"result-image\">", "<h3>Amenities</h3>");
				U.log("regSqftSec :::"+regSqftSec.length);
				for(String regsq:regSqftSec) {
					String urlV=U.getSectionValue(regsq, "href=\"", "\">");
					U.log(urlV);
					if(urlV != null && itemurl.contains(urlV)) {
						regSqft=regSqft+regsq;
					}
				}
				sqft=U.getSqareFeet(html+floorplandetails+regSqft, "\\d,\\d{3} - \\d,\\d{3} Sq. Ft|size from \\d,\\d{3} to \\d{1},\\d{3} square feet|from \\d,\\d{3} to over \\d,\\d{3} square feet|\\d{1},\\d{3} SF", 0);
			
			
				
				minsqft=sqft[0];
				maxsqft=sqft[1];
				
//				U.log(Arrays.toString(sqft));
			
		//==========================communitytype===========================
				
				String commdesc=U.getSectionValue(html, "<div class=\"commoverview-content\">","<div class=\"commoverview-info\">")
						+ U.getSectionValue(html, "<div class=\"hero-content\">", "</div>"); 
				
				String amenitiesection=U.getSectionValue(html, "amenities-list", "</ul>");
				String comdes1=U.getSectionValue(html, "Additional Community Info", "floorplansearch")+U.getSectionValue(html, "<div class=\"commoverview-content\">", "<div class=\"amenities\">");
				commdesc=commdesc.replace("Brand-new homes are coming soon at our nearby community", "");

				//				U.log(commdesc);
				String ctype=U.getCommType((commdesc+amenitiesection+comdes1).replace("lakefront boardwalk", "lakefront community boardwalk")
						.replace("elongated", "").replace("Lumber Creek gated community pool ", ""));
//				U.log("CommType: "+ctype);
				
		//===========================propertytype===============================
				
				if(commdesc!=null)
					commdesc = commdesc.replace("charming coastal scenery", "charming coastal community scenery")
					.replace(" boasts luxurious", " boasts luxury homes");
				
				if(comdes1!=null)
					comdes1 = comdes1.replace("charming coastal scenery", "charming coastal community scenery")
					.replace("Luxurious Upgrades Completely Included", "Luxury homes Upgrades Completely Included")
					.replace("luxurious, upgraded homes", "luxury homes");
				
				//U.log(commdesc);
				String ptype=U.getPropType(comname+(floorplandesc+commdesc+amenitiesection+comdes1).replaceAll("traditional incandescent", ""));
//				U.log("ptype: "+ptype);

		//============================dtype==========================
		
				if(comdes1!=null)
					comdes1 = comdes1
					.replaceAll("alt=\"LGI Homes townhome building, 4-plex of all Blackberry plans attached", "")
					.replaceAll("one to two-stories|one- to two-stories", " 1 Story 2 Story");
				if(floorplandesc1!=null)
				floorplandesc1=floorplandesc1.replace("1st Floor", "1 Story").replace("2nd Floor", "2 Story");
				
				String dtype=U.getdCommType((floorplandesc1+floorplandesc+floorplandetails+comdes1+commdesc)
						.replace("one to two stories", "one story to two stories")
						.replaceAll("Colonial Promenade", ""));
				
//				U.log("dtype: "+dtype);
//				U.log("=============DP1 "+Util.matchAll(floorplandesc1, "[\\w\\W\\s]{50}plex[\\w\\s\\W]{50}", 0));

				
				//=========================pstatus============================
				html=html.replace("kept up-to-date on the Grand Opening of Huntington Pointe", "");
				String regs[]=U.getValues(reghtml1, "coveo-card-layout CoveoResult", "<div class=\"result-top\">");
				String regst=null;
				
				for(String df:regs) {
					String u=U.getSectionValue(df, "href=\"", "\"");
					if(itemurl.contains(u)) {
//						U.log("u=="+df);

						regst=U.getSectionValue(df, "<div class=\"result-status\">", "</div>");


						
					}
					
					
				}
				
				if(floorplandesc!=null) {
					floorplandesc=floorplandesc.replaceAll("stunning homes available|(N|n)ow available|now selling|Available now|quick move-in at Ghost Hollow Estates located in Casa Grande|available for quick move-in.", "");
				}
			
				
				String rem = U.getSectionValue(html, "<div id=\"nearby-communities\"", "</main>");
				if(rem != null) html = html.replace(rem, "");
				
				String commim=U.getSectionValue(html, "<div class=\"hero-content\">", "</div>");
				String resec=U.getSectionValue(html, "How Can I Own a New Home Today?", "</script>");
				String asf=null;
				if(resec!=null) {
					
					 asf=(commdesc+amenitiesection+comdes1+floorplandesc).replace(resec, "").replaceAll(" premier features that make these homes move-in ready|Upgraded and Move-in Ready|Additionally, coming soon to the community|kept up-to-date on the Grand Opening", "");
				}
	//		U.log(asf);
				String as="";
				if(asf!=null)
					as=(asf).replaceAll("Floor Plans Available|This picturesque community features beautiful, move-in ready homes", "");
				
				String rmstr="Katy Coming|Additionally, coming soon to the community|available for immediate move-in|Now open in the west section|baths is available for immediate move-in|<h1 class=\"title\">New Section Now Open</h1>|future parks coming soon including|ready for immediate move-in at |brand-new floor plans available for immediate move-in |loor plan is ready for immediate move-in|For immediate move-in opportunities|quick move-in at Willowwood|Quick|quick|ready|Ready|Move-in Ready Homes in Sanger|is move-in ready and affordable|Springs has quick move-in homes for|<h4>Move-In Ready Homes</h4>|move-in ready homes located|selection of move-in ready homes|brand-new home is move-in ready|This move-in ready|Move-in Ready Retreat|Move-in Ready Floor Plans|this move-in ready home|provides residents with move-in ready|move-in ready homes at affordable |homes more than just move-in ready|finishes that move-in ready homebuyers|spectacular move-in ready homes|move-in ready homes in an exceptional|Move-in Ready with Upgraded Features|a fantastic selection of move-in ready homes ideally located |variety of move-in ready homes|available for quick move-in.|Upgraded Homes Ready for Move-in| for quick move-in at some |<h1 class=\\\"title\\\">Move-in Ready Homes</h1>|Move-in ready homes with designer|These move-in ready homes offer|Move-in ready homes with upgraded|this home is move-in ready and sets";
				commim=commim.replace("Move-in Ready Townhomes Now Available in Portland", "").replace("More New-Construction Homes Coming Soon to Fort Pierce", "").replace("More Homes Coming Soon Near Deltona and DeLand", "").replace("More Quality-Construction Homes Coming Soon to Sarasota", "");
//				.replace("Sold Out Near Fort Worth", "")
				

				as=as.replace("Brand-new homes are coming soon at our nearby community","");
				String pstatus=U.getPropStatus((commim + regst +as)
						.replace("Last Chance to Own in Crowley", "")
						.replace("<p><strong>QUICK MOVE-IN HOMES AVAILABLE NOW!</strong></p>", "")
						.replace("More Upgraded Retreats Coming Soon to Fort Pierce", "")
						.replace("New Homes Available Now in Kings Mountain", "New Homes Now Available in Kings Mountain")
						.replace("New Homes For Sale Coming Soon", "New Homes Coming Soon")
						.replaceAll(rmstr, "").replace("to be kept up-to-date on the Grand Opening of Huntington Pointe", "")
						.replace("premier features that make these homes move-in ready.", "")
						.replaceAll("Coming Soon in Youngsville</h2>|brand-new homes|remaining homes for sale|for Sale in Lakeland are Coming|Immediate Move-in in Springville|Twinhomes Now|<div class=\"result-status\">Sold Out</div>|Riverstone, a coming soon community|class=\"result-status\">Sold Out|COMING SOON north of Seattle", ""));
				

//				U.log("pstatus: "+pstatus);
				if(itemurl.contains("www.lgihomes.com/texas/austin/homestead-estates")) {
					ptype+=", Estate-Style Homes";
				}
				if(itemurl.contains("minneapolis/riverpointe")) {
					ptype="Townhome";
				}
				
				
				if(itemurl.contains("/north-carolina/charlotte/village-at-granite")) {
					pstatus+=", New Section Coming Soon";//====remm
				}
				
				if(itemurl.contains("minnesota/minneapolis/riverpointe")) {
					pstatus="Move In Ready";//====remm
				}
				if(latLong[0]==null || latLong[1]==null)
				{
					latLong=U.getlatlongGoogleApi(add);
					geo="TRUE";
				}
				if(minPrice==null)minPrice=ALLOW_BLANK;
				if(maxPrice==null)maxPrice=ALLOW_BLANK;
				
				if(minsqft==null)minsqft=ALLOW_BLANK;
				if(maxsqft==null)maxsqft=ALLOW_BLANK;
   
				pstatus=pstatus.replace("Now Open, Phase Two Now Open", "Phase Two Now Open");//====remm
				data.addCommunity(comname.replaceAll("LGI Homes|Varina, NC -|Salem -|New Community", ""),itemurl, ctype);
				data.addAddress(add[0].replace("@",""), add[1].replace("St. Augustine, FL", "St. Augustine"), add[2].trim(), add[3]);
				data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
				data.addPropertyType(ptype, dtype);
				data.addPropertyStatus(pstatus);
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minsqft, maxsqft);
				data.addNotes(note);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);
				
	}
				
				i++;
				

//		}catch (Exception e) {}
	}

	private String getHtml(String url,WebDriver driver) throws IOException, InterruptedException {
		int i = 1;
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					
					driver.manage().window().maximize();
					driver.get(url);
					//U.log("after::::"+url);
					
					
					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}

}