/**
 * @author Aditya..
 */

package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractMHIMcGuyerHomebuilders extends AbstractScrapper {
	private static String BULIDER_NAME = "MHI-McGuyer Homebuilders - Build on your lot by Coventry Homes";
	private static String HOME_URL = "https://buildonyourlot.coventryhomes.com";
	String geoCode = "FALSE";
	CommunityLogger LOGGER;
	private static WebDriver driver=null;

	public ExtractMHIMcGuyerHomebuilders() throws Exception {
		super(BULIDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Build on your lot by Coventry Homes");
	}

	public static void main(String args[]) throws Exception {
		U.setUpChromePath();
		U.setUpChromePath();
		driver=new ChromeDriver();
		AbstractScrapper a = new ExtractMHIMcGuyerHomebuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"MHI-McGuyer Homebuilders - Build on your lot by Coventry Homes.csv",a.data().printAll());

	}
	public void innerProcess() throws Exception {
		String metroIdsUrl="https://app.mhinc.com/api/DBAMetros/?DBACode=boyl";
		String metroRegionHTml=getHTML(metroIdsUrl);
		String regions[]=U.getValues(metroRegionHTml, "{", "}");
		for (String region : regions) {
			U.log("region==="+region);
			String id=U.getSectionValue(region, "\"metroid\":\"", "\"");
			String url=U.getSectionValue(region, "\"metroseourlname\":\"", "\"").toLowerCase()+"/";
			String commData=getHTML("https://app.mhinc.com/api/BOYLCommunityDetails?DBACode=boyl&metroid="+id.toLowerCase()+"&CommunitySeoUrlName= ");
//			U.log("********"+"https://app.mhinc.com/api/BOYLCommunityDetails?DBACode=boyl&metroid="+id.toLowerCase()+"&CommunitySeoUrlName= ");
			
//=================================== SINGLE EXECUTION
//			if(!url.contains("sanantonio"))continue;
			
			//comurl
			String comUrl=HOME_URL+"/locations/"+url;
			U.log(comUrl);
			//comName
			U.log("=================================");
//			if (!comUrl.contains("https://buildonyourlot.coventryhomes.com/locations/dallas-ft-worth"))return;
			
			
			String comName = U.getSectionValue(commData, "\"ProjectName\":\"", "\"");
			U.log(comName);
			//comAdd
			String street = ALLOW_BLANK;
			String city = ALLOW_BLANK;
			String state = ALLOW_BLANK;
			String zip = ALLOW_BLANK;
			String geo="True";
			street=U.getSectionValue(commData, "\"Address\":\"", "\"");
			street= street.replace("Set Your Appointment At Any Of Our DFW Area Model Homes", "");
			//U.log("street: "+street);
			city=U.getSectionValue(commData, "\"City\":\"", "\"");
			state=U.getSectionValue(commData, "\"State\":\"", "\"");
			zip=U.getSectionValue(commData, "\"Zip\":\"", "\"");
			if(street!=null)
				street= street
				.replace("7676 Woodway Drive, Suite 104", "7676 Woodway Drive Suite 104")
				.replaceAll("Set your appointment at any of our DFW area model homes|We'd be happy to meet you at any of our area model homes!|We're available to meet you at any of our area model homes.|We'd Be Happy To Meet You At Any Of Our Area Model Homes", "");
			
			
			U.log("ADDRESS HERE: "+street+":::"+city+"::::"+state+"::::::::::"+zip);
			
			//latlong
			String latLng[]= {ALLOW_BLANK,ALLOW_BLANK};
			String latSec= U.getSectionValue(commData, "&daddr=", "\"");
			if(latSec!=null)
			latLng = latSec.split(",");
			
			U.log("LATLNG: "+Arrays.toString(latLng));
			
			if(latLng[0]!=null && latLng[0]!=ALLOW_BLANK && (street.length()<2)) {
				street = U.getAddressGoogleApi(latLng)[0];
				geo ="True";
			}
			if(street!=ALLOW_BLANK && street!=null && (latLng[0]==null|| latLng[0]==ALLOW_BLANK)) {
				latLng = U.getlatlongGoogleApi(new String[]{street,city,state,zip});
				geo ="True";
			}
			if(latLng[0]!=null && latLng[0]!=ALLOW_BLANK && (street.contains("happy to meet"))) {
				street = U.getAddressGoogleApi(latLng)[0];
				geo ="True";
			}
			U.log(street+":::"+city+"::::"+state+"::::::::::"+zip);
			U.log(Arrays.toString(latLng));
			//Prices & sqfts 
			
			//price
			U.log(commData);
			commData=commData.replace("0's", "0,000");
			String[] price = U.getPrices(commData, "From the \\$\\d{3},\\d{3} |\\$\\d,\\d+,\\d+|\\$\\d+,\\d+|\"BasePrice\":\"\\d{6}\"", 0);
			
			//sqft
			
			String[] sqft = U.getSqareFeet(commData, "\\d+ sf|\\d+ sqft|approximately \\d{4} sq. ft.|\"SqFt\":\"\\d{4}\",", 0);
			U.log(Arrays.toString(price));
			U.log(Arrays.toString(sqft));
			
			
			//proptype
			
			
			commData=commData.replace("step of the custom home", "interiors custom designed");//.replace("traditional development", "Traditional exterior");
			commData=commData.replaceAll("el carriage style garage door |located in a gated community| the front courtyard|gated community. Come visit |the last opportunity ","");
			String propertyType = U.getPropType(commData);
			U.log("****"+propertyType);
			
			//dtype
			
			commData= commData.replace("\"Stories\":\"1.0", "1 story").replace("\"Stories\":\"2.0", "2 story").replace("\"Stories\":\"1.5", "1.5 story");
			String derivedPropertyType = U.getdCommType(commData.replace("Steel raised ranch panel garage door ", "").replaceAll("Branch|_[r|R]anch", ""));
			
			//pstatus
			
			commData=commData.replaceAll("phContent1_Noseminars\">\\W+Coming Soon!", "").replace("home is under construction", "");
			String propertyStatus = U.getPropStatus(commData);
			//comType
			commData=commData.replaceAll("Elongated commode", "");
			String communityType = U.getCommunityType(commData);
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
				
				return;
			}
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			LOGGER.AddCommunityUrl(comUrl);
			data.addCommunity(comName, comUrl, communityType);
			data.addAddress(street, city, state, zip);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propertyType, derivedPropertyType);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(price[0], price[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addNotes(U.getnote(commData));
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);

		}
		driver.quit();
		LOGGER.DisposeLogger();
		//U.log(regionAPiHTml);
	}
	

//	private void setDriverProxy(){
//		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
//		proxy.setHttpProxy("157.90.199.133:1080")
//	     .setFtpProxy("157.90.199.133:1080")
//	     .setSslProxy("157.90.199.133:1080");
//		DesiredCapabilities cap = new DesiredCapabilities();
//		cap.setCapability(CapabilityType.PROXY, proxy);   //104.148.76.147:3128 //12.227.26.82:8080 //134.209.69.46:8080
//		driver = new FirefoxDriver();
//	}
	
	private void getDetails(String regionUrl) throws Exception {
		
		
		
//		if(!regionUrl.contains("https://buildonyourlot.coventryhomes.com/locations/dallas-ft-worth/")) return;
		
		
		
		String regHtml = getHTML(regionUrl);
		String communitySec = U.getSectionValue(regHtml, "<div class=\"details\">", "<p>");
		String communityName = U.getSectionValue(communitySec, "<h4>Overview of", "<");
		U.log("Community NAme::" + communityName);
		regHtml=regHtml.replaceAll("Stories:", "Stories");
		
		String derivedPropertyType = U.getdCommType(regHtml.replace("Steel raised ranch panel garage door ", "").replaceAll("Branch|_[r|R]anch", ""));

		// ******************Community Prices****************************

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		regHtml=regHtml.replaceAll("<span class=\"strikethrough ng-star-inserted\">\\s*\\$\\d,\\d{3},\\d{3}\\s*</span>|<span class=\"strikethrough ng-star-inserted\">\\s*\\$\\d{3},\\d{3}\\s*</span>|<span class=\"strikethrough\">\\W*\\$\\d,\\d+,\\d+</span>| <span class=\"strikethrough\">\\s*\\$\\d{3},\\d{3}</span>&nbsp;<span>|<span class=\"strikethrough\">\\$\\d{3},\\d{3}</span>","" );
		String availHome=U.getSectionValue(regHtml, "<h2>Available Homes</h2>", "pageLoad_CommunitySide");
		
		
	//	U.log("available homes :"+availHome);
		
		regHtml = regHtml.replaceAll("0's|0's", "0,000");
		
		String[] price = U.getPrices(regHtml, "\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice);
		U.log(maxPrice);

		// ******************Community Area [SqrFeet]******************

		String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(regHtml, "\\d+ sf|\\d+ sqft", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log(minSqFeet);
		U.log(maxSqFeet);
		String street = ALLOW_BLANK;
		String city = ALLOW_BLANK;
		String state = ALLOW_BLANK;
		String zip = ALLOW_BLANK;
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String geo="False";
		String mapsec=U.getSectionValue(regHtml, "mapaddress", "<p>");
		String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
		if(mapsec!=null) {
		String latLngSec=U.getSectionValue(mapsec, "/maps?q=", "&amp;");
		if(latLngSec!=null) {
			latlng=latLngSec.split(",");
			lat=latlng[0];
			lng=latlng[1];
			U.log(Arrays.toString(latlng));
		}
		String addsec=U.getSectionValue(mapsec, "<span class=\"fa fa-map-marker\"></span><span>", "</a>");
		if(addsec!=null) {
			addsec=addsec.replace("</span><br>", ",").replaceAll(", Suite 104", "");
			String[] add=U.findAddress(addsec);
			U.log(Arrays.toString(add));
			street=add[0];city=add[1];state=add[2];zip=add[3];
			U.log("gggggggg"+street);
			if(street.contains("We'd be happy") || street.contains("we're available")|| street.contains("we'd be happy ")) {
				U.log("hello");
				add[0]=add[0].replace("We'd Be Happy To Meet You At Any Of Our Area Model Homes", "").replaceAll("we're available to meet you at any of our area model homes.|We're available to meet you at any of our area model homes\\.", "-");
				add=U.getAddressGoogleApi(new String[] {lat,lng});
				if(add==null)add=U.getGoogleAddressWithKey(new String[] {lat,lng});
				geo="True";
				street=add[0];
			}
		}
		}	
		
		/*else {
				U.log("else:::::::::::::"+addsec);
				addsec=U.getSectionValue(mapsec, "<span>", "</p>");
				if(addsec!=null) {
				addsec=addsec.replace("</span><br>", ",").replaceAll("TX,", "TX");
				String [] add=U.findAddress(addsec);
				U.log(Arrays.toString(add));
				street=add[0];city=add[1];state=add[2];zip=add[3];
				if(lat==ALLOW_BLANK) {
					latlng=U.getlatlongGoogleApi(add);
					geo="True";
					lat=latlng[0];
					lng=latlng[1];
				}
				U.log(Arrays.toString(latlng));
				}
		}*/
		if (regionUrl
				.contains("https://buildonyourlot.coventryhomes.com/locations/austin")) {
			street="8200 N. Mopac Ste. 300";
			city = "Austin";
			state = "TX";
			zip = "78759";
			lat="30.369913";
			lng="-97.7425754";
			geo="TRUE";
					
		}
		if (regionUrl
				.equals("https://buildonyourlot.coventryhomes.com/locations/dallas-ft-worth")) {
			street="2722 Lawtherwood Ct";
			city = "Dallas";
			state = "TX";
			zip = "75248";
			lat="32.8206646";
			lng="-96.7313396";
			geo="TRUE";
		}
//		if (regionUrl
//				.equals("https://buildonyourlot.coventryhomes.com/locations/houston")) {
//			street="7676 Woodway Drive SUITE 104";
//			city = "Houston";
//			state = "TX";
//			zip = "77063";
//			lat = "29.75179";
//			lng = "-95.50378";
//			geo="TRUE";
//		}
		if (regionUrl
				.equals("https://buildonyourlot.coventryhomes.com/locations/sanantonio")) {
			street="1209 Vintage Way";
			city = "New Braunfels";
			state = "TX";
			zip = "78132";
			lat="29.7785832";
			lng="-98.2625709";
			geo="TRUE";
		}

		
		regHtml=regHtml.replace("step of the custom home", "interiors custom designed").replace("traditional development", "Traditional exterior");
		regHtml=regHtml.replaceAll("el carriage style garage door|Luxurious garden |located in a gated community|Luxurious Baths| the front courtyard|gated community. Come visit |the last opportunity ","");
		String propertyType = U.getPropType(regHtml);
		
		
		regHtml=regHtml.replaceAll("phContent1_Noseminars\">\\W+Coming Soon!", "").replace("home is under construction", "");
		String propertyStatus = U.getPropStatus(regHtml);
		
		regHtml=regHtml.replaceAll("Elongated commode", "");
		String communityType = U.getCommunityType(regHtml);
		
	//	U.log(regHtml);
		U.log(derivedPropertyType);
		
		U.log("geo::::::::::::"+geo);
//		zip=U.getAddressGoogleApi(new String[]{lat, lng})[3];
		if (data.communityUrlExists(regionUrl)) {
			LOGGER.AddCommunityUrl(regionUrl + "\t*********Repeated******\t");
			
			return;
		}
		LOGGER.AddCommunityUrl(regionUrl);
		data.addCommunity(communityName, regionUrl, communityType);
		data.addAddress(street, city, state, zip);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(propertyType, derivedPropertyType);
		data.addPropertyStatus(propertyStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFeet, maxSqFeet);
		data.addNotes(ALLOW_BLANK);
		
	}
	
	
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"167.172.123.221",9300));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "application/json, text/plain, */*");
			urlConnection.addRequestProperty("Authorization", "Basic Y292Ym95bDo3OEJGMDQ4Ri04OEY5LTREQTMtODdBNS1FRUY0NkE2NzVBRkU6RkRFN0ZDM0YtMTM1Qi00OENFLUFDMDQtMjhBRTQ4QTQ2QTcz");
			urlConnection.addRequestProperty("Referer","https://buildonyourlot.coventryhomes.com/");
			//urlConnection.addRequestProperty("Sec-Fetch-Mode","cors");

			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();
			Thread.sleep(10000);
			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			
			U.log("gethtml expection: "+e);
			

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	
	
}