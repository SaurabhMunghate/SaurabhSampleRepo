/**@Modificattion Aditya. 
	Parag Humane
 * Date:30/11/2013
 * 
 */
package com.shatam.b_061_080;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractDRBHomes extends AbstractScrapper {
	int i = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractDRBHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"DRB Homes.csv", a.data().printAll());
	}

	public ExtractDRBHomes() throws Exception {

		super("Dan Ryan Builders", "https://www.danryanbuilders.com");
		LOGGER = new CommunityLogger("DRB Homes");
	}
	
	static ArrayList<String> communities = new ArrayList<String>(); 
	
	public void innerProcess() throws Exception {

		String drbHomesData = U.getHTML("https://api.drbhomes.com/api/v1/public/community?brand%5B%5D=drbhomes&sortBy=name&sortOrder=ASC&page=1&limit=1000");
		String drbElevateData = U.getHTML("https://api.drbhomes.com/api/v1/public/community?brand%5B%5D=drbelevate&sortBy=name&sortOrder=ASC&page=1&limit=1000");
		
		JsonParser json = new JsonParser();
		JsonObject objDrbHomes = (JsonObject)json.parse(drbHomesData);
		JsonObject objDrbElevate = (JsonObject)json.parse(drbElevateData);
		
//		U.log("objDrbHomes: "+objDrbHomes.toString());
//		U.log("objDrbElevate: "+objDrbElevate.toString());

		JsonArray drbHomesArray = new JsonArray();		
		drbHomesArray = (JsonArray)objDrbHomes.getAsJsonArray("items");
		U.log("drbHomesArray size: "+drbHomesArray.size());
		
		JsonArray drbElevateArray = new JsonArray();
		drbElevateArray = (JsonArray)objDrbElevate.getAsJsonArray("items");
		U.log("drbElevateArray size: "+drbElevateArray.size());
		
		for(int i=0; i<drbHomesArray.size(); i++) {
			
			String comDrbHomes = drbHomesArray.get(i).toString();
			//U.log("comDrbHomes: "+comDrbHomes);
			
			communities.add(comDrbHomes);
		}
		
		for(int i=0; i<drbElevateArray.size(); i++) {
			
			String comDrbElevate = drbElevateArray.get(i).toString();
			//U.log("comDrbElevate: "+comDrbElevate);
			
			communities.add(comDrbElevate);
		}
		
		U.log("Total Communities: "+communities.size());
		
		int i = 0;
		for(String community:communities) {
			
			//U.log("community: "+community);
			addDetails(community);
			i++;
			
			//if(i == 5)break;
		}
		
		LOGGER.DisposeLogger();
	}

	private void addDetails(String community) throws Exception {

		
		
		//-------------------------COMMUNITY URL
		String stateLabel = U.getSectionValue(community, "stateLabel\":\"", "\"").toLowerCase();
		//U.log("stateLabel: "+stateLabel);
		if(stateLabel.contains(" ")) stateLabel = stateLabel.replace(" ", "-");
		U.log("stateLabel: "+stateLabel);
		
		
		String countyLabel = U.getSectionValue(community, "label\":\"", "\"").toLowerCase();
		//U.log("countyLabel: "+countyLabel);
		if(countyLabel.contains(" ")) countyLabel = countyLabel.replace(" ", "-");
		U.log("countyLabel: "+countyLabel);
		
		
		String comname = U.getSectionValue(community, "name\":\"", "\"").toLowerCase();
		//U.log("comname: "+comname);
		if(comname.contains(" ")) comname = comname.replace(" ", "-");
		U.log("comname: "+comname);
		
		//--------communityURLS
		String comUrl = "https://www.drbhomes.com/drbhomes/find-your-home/communities/"+stateLabel+"/"+countyLabel+"/"+comname+"/overview";
		
		if(comUrl != null) {
			comUrl = comUrl.replace("archer's-rock-townhomes/overview", "archers-rock-townhomes/overview")
					.replace("weaver's-ridge-townhomes/overview", "weavers-ridge-townhomes/overview");
		}
		
		U.log("comUrl: "+comUrl);
		
		LOGGER.AddCommunityUrl(comUrl);
		
//------------------------SINGLE EXECUTION
//  if(!comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/north-carolina/raleigh/atwater/overview")) return;
		
		
		//--------------RETURNING COMMS.
		if(comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/virginia/prince-william-county/carter's-grove/overview") ||
				comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/north-carolina/raleigh/weaver's-ridge-single-family/overview") ||
				comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/west-virginia/morgantown/cheat-cove---townhomes/overview") ||
				comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/virginia/dc-metro/carter's-grove/overview") ||
				comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/north-carolina/raleigh/weaver's-pond-/overview")) {
			
			
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------504 GATEWAY ERROR");
			return;
		}

		//------------------------GET COMMUNITY BELOW
		U.log("community: "+community);
	
		//-------------------------COMMUNITY NAME
		String comName = U.getSectionValue(community, "name\":\"", "\"");
		
		if(comName != null) {
			comName = comName.replace("Rosehill Manor Active Adult Homes", "Rosehill Manor")
					.replace("Spring Valley Estates Villas", "Spring Valley Estates");
		}
		
		U.log("comName: "+comName);
		
		//-------------------------COMMUNITY UNIQUE ID
		String uniqueId = U.getSectionValue(community, "id\":", ",");
		U.log("uniqueId: "+uniqueId);
		
		//-------------------------ADDRESS	
		String add[] = { ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK };
		String latlng[] = { ALLOW_BLANK,ALLOW_BLANK };
		String geo = "FALSE";	
		
		add[0] = U.getSectionValue(community, "address1\":\"", "\"");
		add[1] = U.getSectionValue(community, "city\":\"", "\"");
		add[2] = U.getSectionValue(community, "stateName\":\"", "\"");
		add[3] = U.getSectionValue(community, "zip\":\"", "\"");
		
		
		if(add[0] != null) {
			
			add[0] = add[0].replace(" (Across From Flint Wood Farms)", "");
		}
		
		//--------------for off site sales address
		if(comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/south-carolina/charleston/recess-pointe/overview") ||
				comUrl.contains("https://www.drbhomes.com/drbhomes/find-your-home/communities/north-carolina/raleigh/atwater/overview")) {
		
			add[0] = U.getSectionValue(community, "offsiteSalesCenterAddress\":{\"address1\":\"", "\"");
		}
		
		U.log("ADDRESS: "+Arrays.toString(add));
		
		//------------------------LATLONG
		latlng[0] = U.getSectionValue(community, "latitude\":", ",");
		latlng[1] = U.getSectionValue(community, "longitude\":", ",");
		
		U.log("LATLONG: "+Arrays.toString(latlng));
		
		//------------------------PLANS DATA
		String planJsonLink = "https://api.drbhomes.com/api/v1/public/community/"+ uniqueId +"/plans";
		U.log("planJsonLink: "+planJsonLink);
		
		String plansData = ALLOW_BLANK;
		
		plansData = U.getHTML(planJsonLink);
		U.log("plansData: "+plansData);
		
		JsonParser json = new JsonParser();
		JsonObject objPlans = (JsonObject)json.parse(plansData);
		
		JsonArray plansArray = new JsonArray();		
		plansArray = (JsonArray)objPlans.getAsJsonArray("items");
		U.log("Total Plans: "+plansArray.size());
		
		
		//------------------------HOMES DATA
		String homeJsonLink = "https://api.drbhomes.com/api/v1/public/community/"+ uniqueId +"/move-in-homes";
		U.log("homeJsonLink: "+homeJsonLink);
		
		String homesData = ALLOW_BLANK;
		int quickCount = 0; 
		
		homesData = U.getHTML(homeJsonLink);
		U.log("homesData: "+homesData);
		
		JsonObject objHomes = (JsonObject)json.parse(homesData);

		JsonArray homesArray = new JsonArray();		
		homesArray = (JsonArray)objHomes.getAsJsonArray("items");
		U.log("Total Homes: "+homesArray.size());

		for(int i=0; i<homesArray.size(); i++) {
			//---for status
			String home = homesArray.get(i).toString();
			
			if(home.contains("availabilityDate\":\"2022-08-") ||
					home.contains("availabilityDate\":\"2022-09-") || home.contains("availabilityDate\":\"2022-10-") ||
					home.contains("availabilityDate\":\"2022-12-") || home.contains("availabilityDate\":\"2022-11-")) {
				
			}else {
				quickCount++;
			}
		}
						
		
		//quickCount = homesArray.size();
		U.log("quickCount: "+quickCount);

		//================ Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String price [] = {ALLOW_BLANK,ALLOW_BLANK};
		String priceFromHomes = ALLOW_BLANK;
		
		community = community.replaceAll("00s|00's", "00,000")
				.replace("After Park Circle From The $300,000", "");
		
		if(homesData.contains("\"basement\":") && homesData.contains("\"yearBuilt\"")) {
			String[] homePrices = U.getValues(homesData, "\"basement\":", "yearBuilt");
			priceFromHomes += homePrices;
		}
		
		price = U.getPrices((community+plansData+homesData), 
				"basePrice\":\\d{6}|priceFrom\":\\d{6}|priceTo\":\\d{6}|From the \\$\\d{3},\\d{3}|"
				+ "FROM THE UPPER \\$\\d{3},\\d{3}|price\":\\d{6}|from the low \\$\\d{3},\\d{3}", 0); 
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(community, "[\\s\\w\\W]{30}300[\\s\\w\\W]{30}", 0));
		
		//=========== SQFT
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String sqft[] = {ALLOW_BLANK,ALLOW_BLANK};
				
		sqft = U.getSqareFeet(community+plansData+homesData, "sqFtMin\":\\d{4}|sqFtMax\":\\d{4}|from \\d{4}-\\d{4} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet"
				+ "|from \\d{4}- \\d{4} square feet|sqFt\":\\d{4}|and \\d,\\d{3} square feet", 0);
				
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homeData, "[\\s\\w\\W]{30}1720[\\s\\w\\W]{30}", 0));
		
		//=========== cType			
		String ctype=U.getCommType(community);
		U.log("ctype: "+ctype);
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(description+headline, "[\\s\\w\\W]{30}golf[\\s\\w\\W]{30}", 0));
		
		//=========== pType
		
		community = community.replace("Welcome to Wyncreek Estates", "Welcome to Wyncreek Estate style");
		
		String pType = U.getPropType((community+plansData+homesData));
		
		U.log("pType: "+pType);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(community, "[\\s\\w\\W]{30}estate[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comJson+plansInfo+homesData, "[\\s\\w\\W]{30}Single Family[\\s\\w\\W]{30}", 0));
			
		//=========== dType
		
		String dType=U.getdCommType((community+plansData+homesData));
		
		U.log("dType: "+dType);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(plansInfo+homesData, "[\\s\\w\\W]{30}story 4[\\s\\w\\W]{30}", 0));
		
		//=========== Status
		String status = ALLOW_BLANK;			
				
		
		status = U.getPropStatus((community)
				.replaceAll("marketingHeadline\":\"New Homesites Now Selling", "")
				.replaceAll("Duncan Area Selling Fast|quick move-in or design|sales center is now open|New Move-In Ready Homes Now Available|New Phase Now Selling New Showcase Homes|New Section Open in Duncan|marketingHeadline\":\"NOW SELLING|marketingHeadline\":\"Now Selling|trees are now available|marketingHeadline\":\"New Townhomes Now Selling In Charles Town|Reidville/Moore Area. New Section Now Selling|marketingHeadline\":\"New Homesites NOW AVAILABLE|marketingDescription\":\"New homes coming late summer|Price Includes Upgrades, Limited Homes Available Now|Pricing Includes Upgrades, Limited Homes Available Now|marketingHeadline\":\"Grand Re-Opening|name\":\"Closeout\"|Currently selling from our off-site sales|marketingHeadline\":\"Now Selling New Homesites|receive updates about the grand opening|area and others coming soon", ""));
		
		U.log("Status BEFORE: "+status);
		
		U.log("quickCount: "+quickCount);
		
		if(quickCount > 0) {
			if(status == ALLOW_BLANK)
				status = "Quick Move-in Homes";
			else if(status != ALLOW_BLANK)
				status = status + ", Quick Move-in Homes";	
		}
						
		U.log("Status: "+status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(community, "[\\s\\w\\W]{50}Selling Fast[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(community, "[\\s\\w\\W]{50}Move-in Ready[\\s\\w\\W]{30}", 0));
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		
		
		
		data.addCommunity(comName, comUrl, ctype);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(community));
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		
		U.log(" ");
	}

}