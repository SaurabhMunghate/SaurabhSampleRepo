/*
 * Modification Aditya..
 */
package com.shatam.b_061_080;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.b_001_020.DR_HORTAN;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEpconCommunitiesFranchising extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	WebDriver driver;

	public static void main(String[] ar) throws Exception {
		

		AbstractScrapper a = new ExtractEpconCommunitiesFranchising();
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Epcon Communities Franchising.csv", a
				.data().printAll());
	}
	
	public ExtractEpconCommunitiesFranchising() throws Exception {

		super("Epcon Communities Franchising",	"https://www.epconcommunities.com");
		LOGGER = new CommunityLogger("Epcon Communities Franchising");
	}
	

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
	String html=U.getHTML("https://www.epconcommunities.com/communities/");
	String[] comSections=U.getValues(html, "<div class=\"community\"", "<div class=\"image"); 
	U.log("comSections.length: "+comSections.length);
	int i=0;
	for(String comSec: comSections){
		String url="https://www.epconcommunities.com"+U.getSectionValue(comSec, "<a href=\"", "\" ");
		
//		U.log(+i+" url: "+url);
		i++;
		//U.log(comSec);

//		try {
			addDetails(url, comSec);
//		} catch (Exception e) {}
		
		//break;
	}
	
	//driver.quit();
	LOGGER.DisposeLogger();
	}

	private void addDetails(String url,String comSec) throws Exception {
//		if (url.contains("https://www.epconcommunities.com//al///"))return;
//	if(j>=30 && j<60)
//		if(j >= 60)
//TODO:
		{

//		if(!url.contains("https://www.epconcommunities.com/oh/west-chester/bel-haven")) return;
		
		U.log(j+"************" + url);
		
		if (data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url + "*********Repeated******");
			return;
		}
		if (url.contains("https://www.epconcommunities.com/wi/menasha/woodland-lake-cottages")) {
			LOGGER.AddCommunityUrl(url + "*********Return******");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		String comHtml = U.getHTML(url);
		U.log("----------" + U.getCache(url));
		
//		U.log(comSec);
		


		
		//================ Community OverView Page Data ================ 
		String overViewUrl = url+"/overview/";//Util.match(comHtml, "<a href=\"(.*?)\" class=\"bottom-link\">About the Community</a>",1);
		U.log("overViewUrl : "+overViewUrl);
		
		String overViewHtml = "";
		if(overViewUrl != null){
			overViewHtml =  U.getHTML(overViewUrl);
//			if(overViewHtml==null) {
//				overViewHtml =U.getHTML("https://www.epconcommunities.com" +Util.match(comHtml, "<a class=\"btn outline\" href=\"(.*?)\">About the Community</a>",1));
//			}
//			overViewHtml=overViewHtml.replaceAll("Coming in 2021: Clubhouse", "");
		}
		
		
        //================ Community Name ================ 
        String name = U.getSectionValue(comSec, "<h3 class=\"h6\">", "</h3>");
        name = name.replace("Grand Opening! 10/26 and 10/27 10am to 4pm", "").replaceAll(", a 55\\+ Epcon Community", "");
        name=name.replace("Woodland Lakes Cottages","Woodland Lakes")
        		.replace("Ladera at the Reserve at Mansfield","Ladera at the Reserve");
        
        U.log("CommName::" + name);
		//================ Address ===================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		
		String flag = "False";
		String[] latlng = {ALLOW_BLANK, ALLOW_BLANK};
		
		
		
		String addressSec = U.getSectionValue(comHtml, "<strong>Address:</strong>", "<a class=\"underline-link");
		if(addressSec == null) addressSec = U.getSectionValue(comHtml, "<h5>Community Location</h5>", " </div>");
		if(addressSec==null)addressSec = U.getSectionValue(comHtml, "<div class=\"column-title\">Address:</div>","<div class=\"column-title\">");
		if(addressSec==null || addressSec.length()<4)addressSec = U.getSectionValue(comHtml, "<h5>Welcome Center</h5>"," </div>");
		U.log("addressSec ::"+addressSec);
		
		
		//================  lat lon ================ 
		if(addressSec!=null) {
				if(addressSec.contains("/www.google.com/maps/place")) {
					latlng[0] = U.getSectionValue(addressSec, "/@", ",");
					latlng[1] = "-"+U.getSectionValue(addressSec, ",-", ",");
				}
				else {
				latlng[0] = U.getSectionValue(comSec, "data-latitude=\"", "\"");
				latlng[1] = U.getSectionValue(comSec, "data-longitude=\"", "\"");
				}
				
				U.log(latlng[0] + ":::::" + latlng[1]);
				
				
		}
		
		if(addressSec != null){
			addressSec=addressSec.replace("The Clubhouse - 835 Rania Way W,<br>", "835 Rania Way W,");
			addressSec=addressSec.replace("<br>", ",").replace(", ,", "").replace("Cecil Township,", "").replace("(Cecil Township)", "").replace("(Chartiers Township)", "").replace("(North Fayette Township)", "")
					.replace("Commons Chesterfield, VA 23832", "Commons")
					.replace("Road, Zelienople Pa ", "Road,")
					.replaceAll("The Clubhouse -|Future Community Location:", "");
			addressSec = addressSec.replace("<br>",",").trim();
			addressSec = addressSec.replaceAll("<p>|</p>","").trim();
			addressSec=U.getNoHtml(addressSec).trim();
			add = U.getAddress(addressSec);
		}
		
		
		U.log("==="+addressSec);
		
		if(addressSec!=null) {
		String []address=addressSec.split(",");
		U.log(address.length);
		if(address.length==4) {
		add[0]=address[0];
		add[1]=address[1];
		add[2]=address[2].trim();
		add[3]=address[3].trim();
		}
		if(address.length==3) {
			add[0]=address[0];
			add[1]=address[1];
			String statezip[]=address[2].split(" ");
			if(statezip.length==3) {
			add[2]=statezip[1];
			add[3]=statezip[2];
			}
			else {
				add[2]=statezip[1];
				add[3]=ALLOW_BLANK;
			}
		}
		
			
		}
		
				
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"	+ add[3]);
		

		String note = ALLOW_BLANK;
		String communityAlert = U.getSectionValue(comHtml, "<div id=\"community-alert", "Get Our App!</a>");
		
		comHtml = U.removeSectionValue(comHtml, "<footer>", "</script>"); // "</body>");
		if(overViewHtml != null)overViewHtml = U.removeSectionValue(overViewHtml, "<footer>", "</script>"); //"</body>");
		
		note=U.getnote((comHtml+overViewHtml).replaceAll("Now accepting home site reservations</strong><br />", ""));
		
		
		if(add[0].length()<3 && add[1].length()>=2 && add[3].length()==5) {
			add[0]=U.getAddressGoogleApi(latlng)[0];
			flag = "True";
		}
		add[1]=add[1].replace("Concord Twp.", "Concord Twp");
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"	+ add[3]);

		if(latlng[0] == null || latlng[0].isEmpty())latlng[0] = ALLOW_BLANK;
		if(latlng[1] == null || latlng[1].isEmpty())latlng[1] = ALLOW_BLANK;
		
		latlng[0] = latlng[0].replace("°", "");
		latlng[1] = latlng[1].replace("°", "");
		
		
		if(add[3]==null || add[3]=="") {
			
//			add[3]="";
			add[3]=U.getAddressGoogleApi(latlng)[3];
			if(add == null)add[3] = U.getAddressHereApi(latlng)[3];
			flag="TRUE";
	
	}
		
		
		if(url.contains("the-cottages-at-hickory-flat")){
			add[0] = "-";
			add[1] = "Canton";		
			add[2] = "GA";
			add[3] = "-";
			
			latlng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlng);

			flag ="TRUE";
			note = "Address And Lat-Long Is Taken From City & State";
		}
		
		if(url.contains("https://www.epconcommunities.com/nd/fargo/the-ranch-at-the-wilds")) {
			
			add[0] = "-";
			add[1] = "Fargo";		
			add[2] = "ND";
			add[3] = "-";
			
			latlng = getLatLng(add);
			add = getAddress(latlng);
			
			flag ="TRUE";
			note = "Address And Lat-Long Is Taken From City & State";
		}
		if(url.contains("https://www.epconcommunities.com/nd/fargo/the-ranch-at-the-wilds")) {
			
			add[0] = "-";
			add[1] = "Fargo";		
			add[2] = "ND";
			add[3] = "-";
			
			latlng = getLatLng(add);
			add = getAddress(latlng);

			flag ="TRUE";
			note = "Address And Lat-Long Is Taken From City & State";
		}
//		if(url.contains("https://www.epconcommunities.com/in/west-lafayette/the-courtyards-at-belle-terra")) {
//			add[1]="West Lafayette";
//			add[2]="IN";
//			latlng = getLatLng(add);
//			add = getAddress(latlng);
//
//			flag ="TRUE";
//			note = "Address And Lat-Long Is Taken From City & State";
//		}

			
		
		if(add[3]==ALLOW_BLANK && latlng[0].length()>3)	{
			String[] addrs = getAddress(latlng);
			add[3]=addrs[3];
			flag="TRUE";
		}
		if (add[0] == ALLOW_BLANK && latlng[0].length()>3) {
			add = getAddress(latlng);
			flag = "TRUE";
		}
		
		
		
		
		
		//========== Model Home Url Section ========================
		String modelHtml = ALLOW_BLANK;
		String quickmoddelData=ALLOW_BLANK;
		int quickcount=0;
		String modelUrl = Util.match(comHtml, "<a href=\"(.*?)\">Find your home</a>",1);
		U.log("modelUrl : "+"https://www.epconcommunities.com"+modelUrl);
		if(modelUrl != null){
			modelUrl=modelUrl.replace("\" class=\"btn", "");
			modelHtml = U.getHTML("https://www.epconcommunities.com" + modelUrl.replace("\" class=\"btn", ""));
			
			
			String[] quickData=U.getValues(modelHtml, "<div class=\"home-top-col home-title\">", "<div class=\"buttons\">");
			for(String quickHome:quickData) {
				if(quickHome.contains("Available Summer 2022")||quickHome.contains("Framing - Home will be ready by June/July 2022")||quickHome.contains("Home will be ready June/July 2022")) {
					quickcount++;
				}
			}
		}
		//------fetching all model Homes Data--------
		String allModelHomesData = ALLOW_BLANK;
		ArrayList<String> allModelUrls = Util.matchAll(modelHtml, "<a href=\"(.*?)\" class=\"floorplan\">", 1);
		for(String eachModelUrl : allModelUrls){

//			U.log("eachModelUrl : "+"https://www.epconcommunities.com"+eachModelUrl);
			String eachModelHtml = U.getHTML("https://www.epconcommunities.com"+eachModelUrl); 
			allModelHomesData += U.getSectionValue(eachModelHtml, "community-model bg-white", "<div class=\"bottom-section\">");

		}
		
		// ==================== Sqft ===========================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(comSec + overViewHtml + comHtml + modelHtml + allModelHomesData,
				"\\d,\\d{3}-\\d,\\d{3} Sq. Ft|\\d{1},\\d{3} sq. ft|ranging from \\d{4} to \\d{4} sq\\. feet|\\d{4}-\\d{4} Square Feet|\\d{4}-\\d{4} Sq. Feet|\\d{4} Square Feet",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		 U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		
		//======================== Price =======================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		modelHtml = modelHtml.replaceAll("0's|0's", "0,000");
//		overViewHtml=overViewHtml.replaceAll("\\$(\\d{3})&#8217;s to \\$(\\d{3})&#8217;s", "from $1,000 to the \\${2},000");
	
		if(overViewHtml == null) overViewHtml = "";
		overViewHtml=overViewHtml.replaceAll("0’s|0s|0&#8217;s", "0,000");
		
		comSec=comSec.replace("0s|0's|0's|0s", "0,000").replace("S304", "$304");
		
		Matcher matchPrice = Pattern.compile("\\$*\\d+[']*s<",Pattern.CASE_INSENSITIVE).matcher(comSec);
		while(matchPrice.find()){
		//U.log(matchPrice.group());
		String match = matchPrice.group().replace("0's", "0,000").replace("'s", ",000").replace("00s", "00,000");  //$100's
		comSec	 = comSec.replace(matchPrice.group(), match);
		}//end millionPrice
		//overViewHtml=overViewHtml.replace("to $500�s", "to $500,000");
		comHtml = comHtml.replaceAll("0's|0’s", "0,000");
		comSec=comSec.replaceAll("0's|0’s|0s", "0,000");
		String[] price = U.getPrices((comSec+overViewHtml+comHtml +modelHtml+ allModelHomesData).replace("0's", "0,000"),
				"from the high \\d{3},\\d{3}|from the low \\$\\d{3},\\d{3}<|<div class=\"price\">\\$\\d{3},\\d{3}</div>|<p>From the upper \\$\\d{3},\\d{3} </p>|the upper \\d{3},\\d{3}|from \\$\\d{3},\\d{3}|from the lower-\\$\\d{3},\\d{3}|from the low \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|only \\$\\d{3},\\d{3}|to \\$\\d{3},\\d{3}|from the upper \\$\\d{3},\\d{3}|starting in the \\d{3},\\d{3}|the mid \\d{3},\\d{3}|<p>Starting in the \\$\\d{3},\\d{3}</p>|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|<p>\\$\\d{3},\\d{3}</p>|Prices starting at \\$?\\d{3},\\d{3}|homes near \\$\\d{3},\\d{3}|from the low \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|from \\d{3},\\d{3} to the \\d{3},\\d{3}|<div class=\"price\">\\$\\d{3},\\d{3}</div>|<div class=\"price\">\\$\\d{6}</div>|Move In Ready at \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3} &#8211; \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|From the high \\$\\d{3},\\d{3}|the upper-\\$\\d{3},\\d{3}|price \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|From the Mid \\$\\d{3},\\d{3}|low \\s*\\d{3},\\d{3}|starting at \\$\\s*\\d{3}[,]*\\d{3}|starting at \\$\\s*low\\s*\\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} with bonus|mid \\$\\d{3},\\d{3}|upper-\\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|at \\$\\d{3},\\d{3}",0);
		//
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		
//		U.log(Util.matchAll(comSec, "[\\s\\w\\W]{100}\\$300[\\s\\w\\W]{100}", 0));

		
		//================ Property Type =========================
		
		comHtml =comHtml.replace("55+ Epcon Community", "55+ Community").replace("traditional 55+", "buyers 55 & over,Traditional exterior");
		comHtml  = comHtml.replaceAll("Only two homes remain available|they are need of a condo|design of our condo |new home builders, ranch homes, condos| from the Condo Parade|private garden|courtyard100|new construction, active adult,|gton-villas-at-cobblestone|The HOA president and his wife are wonderful and very |Condos_Epcon|Village|village|Ridge Road Villas|Condo Parade", "");
		overViewHtml=overViewHtml.replaceAll("Only 4 home sites remain for project |Only two homes remain available|EL TAPATIO MEXICAN RESTAURANT", "");
		//------ remove meta contain-------------	
		String rem = U.getSectionValue(comHtml, "<meta name=\"viewport", "<header>");
		if(rem!=null)
			comHtml=comHtml.replace(rem,"");
		
		String rmsec=U.getSectionValue(overViewHtml, "<span>GuildQuality Reviews", "</script>");
//		U.log(rmsec);

		comHtml = U.removeSectionValue(comHtml, "<head>", "</head>");

		if(rmsec==null)rmsec=ALLOW_BLANK;
		//overViewHtml = overViewHtml;
		
		if(overViewHtml!= null)
			overViewHtml = overViewHtml.replace("one floor and custom touches throughout", "one floor and custom homes touches throughout")
			.replace("single-family cottage homes", "single family homes cottage homes").replace("single-family detached homes", "single family homes detached homes").replace("detached, ranch-style homes", "detached homes , ranch-style homes");
		
		String pType = U.getPropType((comHtml+modelHtml+allModelHomesData+overViewHtml)
				.replace("Private, garden courtyard ", "Private, garden   courtyard")
				.replace("award-winning, traditional, all-brick architecture with", "award-winning, Traditional exterior, all-brick architecture with")
				.replaceAll("Ashley Manor Memory Care|alt=\"The Courtyards on Hyatts\"|Craftsman elevation|_Patio_|Communities condo development|Log Cabin|EL TAPATIO MEXICAN RESTAURANT|garage lots now available|private courtyards.\" />|epconfranchising|Tapatio Mexican Restaurant|Epcon Patio Home Community|Newest patio homes|the-courtyards.jpg|English Villa Dr|_Courtyard_", "")
				.replace("MO offering luxury ranch style homes with courty", "MO offering luxury homes ranch style homes with courty")
				.replaceAll("European garden-style attached", "garden style apartments").replace(rmsec, ""));
		

		
		pType=pType.replace("Townhouse,Townhomes", "Townhomes");
		U.log("pType: "+pType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+modelHtml+allModelHomesData+overViewHtml, "[\\s\\w\\W]{30}garden[\\s\\w\\W]{30}", 0));
		
		//================= Derived Community Type ==================
	
		//U.log(modelPricingSec);
		modelHtml = modelHtml.replaceAll("\"description\">(\\d)-Story</div>", "\"description\"> $1 Story </div>")
				.replace("\"description\">Ranch Style</div>", "\"description\"> Ranch Style </div>");
		
		comHtml = comHtml.replace("2nd level bonus suite", "Story 2 bonus suite");
		String dType = U.getdCommType((comHtml+modelHtml+overViewHtml+allModelHomesData)
				.replace("Colonial-", "")
				.replaceAll("07156-Colonial-PDA-3|single-floor|epconfranchising|NC offering luxury ranch homes|2nd floor", ""));
		
		U.log("dType: "+dType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+modelHtml+overViewHtml+allModelHomesData, "[\\s\\w\\W]{30}Colonial[\\s\\w\\W]{30}", 0));https://www.epconcommunities.com/ia/waverly/eisenach-village

		
		//=============== Community Type =======================
		
//		String remSec=U.getSectionValue(comHtml, "attractions-section", "<div class=\"disclaimer\">");
//		U.log(remSec);
//		if(remSec!=null)comHtml=comHtml.replace(remSec, "");
		String remSecs[]=U.getValues(overViewHtml, "<li class=\"attraction\"", "</li>");
		for (String remSec : remSecs) {
//			comHtml=comHtml.replace(remSec, "");
			overViewHtml=overViewHtml.replace(remSec, "");
		}
		String remSec=U.getSectionValue(overViewHtml, "\"attractions\":[{", "</script>");
		if(remSec!=null)overViewHtml=overViewHtml.replace(remSec, "");
//		U.log(Util.match(overViewHtml, ".*Country Club.*"));	
		//comHtml = comHtml.replace("restaurants, golf,", "restaurants, golf course").replace("Country Club Road", "").replaceAll("next to Gray Eagle Golf course|offers a genuine country club lifestyle", "");
		overViewHtml=overViewHtml.replaceAll("<img src=\"https://www.epconcommunities.com/wp-content/themes/epcon/images/icon-golf.svg\" alt=\"Golf\">\n\\s*Golf", "galleries and golf")
				.replace("55+ Adult Active Community", "55+ Community, active adult")
				.replaceAll("<p>This over 55 community|55\\+, Age-restricted community", " seniors 55 and over")
				.replace("options for 62+", "options for 62 years and older")
				.replaceAll("Mallard Head Country Club|Golf Center", "")
				.replace("galleries and golf ", "galleries and golf course")
				.replaceAll("Financing options for 62 years and older", "");
		comHtml = U.removeSectionValue(comHtml, "<head>", "</head>");
		comHtml=comHtml.replace("traditional 55+", "buyers 55 & over,Traditional exterior")
				.replace("Serenity at Meridiana is a gated, 55+, Active Adult Community", "Serenity at Meridiana is a gated, 55-plus community, Active Adult Community")
				.replaceAll("an alternative to buyers 55 & over|active adult communities in", "");
		//U.log(comHtml);
		String Type = U.getCommunityType(comHtml+overViewHtml);
		U.log("cType: "+Type);
//		U.log(Util.matchAll(comHtml, "[\\s\\w\\W]{100}buyers 55 & over[\\s\\w\\W]{100}", 0));
//		U.log(Util.matchAll(comHtml, "[\\s\\w\\W]{100}active adult[\\s\\w\\W]{100}", 0));

		//============= Property Status ========================
		/*String comAlert = U.getSectionValue(comHtml, "<div id=\"community-alert\">", "<script>");
		if(comAlert != null){
			comHtml = comHtml.replace(comAlert, "");
		}*/
		
		comHtml = comHtml.replace("Phase 3 is now available", "Phase 3 Now Available")
				.toLowerCase().replaceAll("before "+name.toLowerCase().trim()+" is sold out", "");
		comHtml = comHtml.replaceAll("Car Lots Available|Move In Ready|be sold out soon|quick move-in homes left|quick move-in homes today|move-in ready homes for Spring|NOW SELLING 3 CAR LOTS|before Marrington is sold out| to close out community</p>|sold out &#8212; Contact".toLowerCase(), "");
		String remove = "POND VIEWS NOW|lots &amp; move-in ready|ite opportunities are coming soon|(clubhouse at|visit) our sold|Ready Homes and our Close";
		comHtml = comHtml.replaceAll(remove.toLowerCase(),"");
		String status = ALLOW_BLANK;

 		overViewHtml=overViewHtml
 				.replace("The condo association is only $179 per month! And low Butler County taxes, too! Selling fast", "")
 				.replace("Selling fast!", "selling fast").replace("Spring Valley Drive is 75% SOLD OUT", "75% Sold Out")
 				.replace("phase II will be coming soon", "phase II coming soon").replace("Phase 3 is now available", "Phase 3 now available")
 				.replace("are sold out in phase I ", "are phase I sold out ")
 				.replaceAll("The Courtyards at Mallory Retreat is a new phase of the established", "");

 		comHtml = comHtml.replace("a limited number of lots left", "a limited lots left");

		
 		
		status = U.getPropStatus((comHtml+comSec+overViewHtml)
				.replace("FINAL 2 OPPORTUNITIES", "FINAL OPPORTUNITIES")
				.replace("<p>Now Selling! HighRidge, a new community in Fuqua", "")
				.replace("Phase III has a variety of lots currently available", "Phase III lots available")
				.replace("information is coming soon", "")
				.replace("phase i and phase ii are sold out", "phase i and phase ii sold out")
				.replace("only two lots remain in phase 1", "Only two lots remain in Phase 1")
				.replaceAll("information is coming soon|new off-site welcome center now open|New Off-Site Welcome Center Now Open|grand opening of the new welcome center|Grand Opening of the New Welcome Center|garage lots are now available for sale in our future phases|[q|Q]uick [m|M]ove|more information is coming soon|<h2>COMING SOON</h2>|ite opportunities are coming soon", "")
				.replace("Phase I is selling quickly", "Phase I selling quickly").replace("Phase 1 lots are selling quickly", "Phase 1 lots selling quickly").replace("phase 1 is sold out", "Phase 1 SOLD OUT").replace("phase i is selling quickly", "Phase I selling quickly")
				.replaceAll("home sites available for reservation|is now open to the public|information about our community coming soon|villas available for immediate|Villas Available for Immediate|Model Coming|ow Butler County taxes, too! Selling fast|before we are sold out|more information is coming soon|Move-in Ready|move-in ready|We only have 8 homesites left|Coming in 2020: Clubhouse|coming in 2020: clubhouse|garage lots now available|both are move-in ready and |garage lots available|car lots available</h2>|Car Lots Available|virtual tours coming soon|Coming in 2018: Amenity cente|be sold out soon|final phase site development progre| <p>closeout.</p>\\s*<p>Welcome to The |now open on select days|quick move-in homes left|villas are now", ""));
//		U.log(modelHtml.contains("Quick Move-In Homes"));
		//status from each model homes
		
//		U.log(Util.matchAll(comHtml, "[\\s\\w\\W]{100}selling fast[\\s\\w\\W]{100}", 0));
//		U.log(">>>>>>>>>>>"+Util.matchAll(comHtml+comSec+overViewHtml, "[\\s\\w\\W]{30}lots availab[\\s\\w\\W]{100}", 0));
//
//		U.log(Util.matchAll(overViewHtml, "[\\s\\w\\W]{100}selling fast[\\s\\w\\W]{100}", 0));
//		\\\\
		
		U.log("status =====>"+status);
		if(modelHtml.contains("Quick Move-In Homes") && !status.contains("Quick")){
			if(status.length()<4)
				status = "Quick Move-In Homes";
			else
				status = status + ", Quick Move-In Homes";
		}
		status = status.replace("Move In Ready Home, Quick Move-In Homes", "Quick Move-In Homes").replace("Now Available, Phase 3 Now Available", "Phase 3 Now Available");
		if(url.contains("pa/harmony/scenic-ridge"))status=status.replace("Two Lots Remain", "Only Two Lots Remain in Phase 1");
        
		if(name.endsWith(" villas"))name=name.replace(" villas", "");
        //********
		
		status=status.replaceAll(", Quick Move-In Homes|Quick Move-In Homes, |Quick Move-In Homes", "");
		
		
		if(quickcount>0) {
			if(status.length()<4)
				status = "Quick Move-In Homes";
			else
				status = status + ", Quick Move-In Homes";
		}
		if(status.isEmpty())status=ALLOW_BLANK;
 		
 		status=status.replace("Final Phase, Now Selling Final Phase", "Now Selling Final Phase");
// 		if(status.contains("Final Phase") && status.contains("Now Selling Final Phase"))
// 			status=status.replace("Final Phase, ", "");
 		add[0]=add[0].replace("&amp;", "&").replace(" (Sales Office)", "");
 		add[0]=add[0].replace("King Edward Drive Cecil Township", "King Edward Drive").replace(",", "").replaceAll("200 Hill Place Drive North Fayette Township", "200 Hill Place Drive");
// 		lng=Util.match(lng, "\\-\\d{2,3}.\\d+");
 		add[0]=add[0].replace("475 Barnickle Street Chartiers Township", "475 Barnickle Street");
		U.log("addr" + add[0]);
 		if(url.contains("courtyards-at-the-preserves")) {
 			status=status.replace("Now Selling Quick Move-In Homes", "Now Selling Final Phase, Quick Move-In Homes");
 			U.log("hello neew status:::::::"+status);

 		}
 		

 		status = status.replace("Lots Are Now Available, Now Available", "Lots Are Now Available")
 				.replaceAll("Limited Homesites Remain, Limited Homesites|Limited Homesites, Limited Homesites Remain", "Limited Homesites Remain");
		
 		
 		
 		
// 		if(url.contains("https://www.epconcommunities.com/pa/washington/belmont-park"))status =ALLOW_BLANK;
// 		if(url.contains("https://www.epconcommunities.com/nd/fargo/the-ranch-at-the-wilds"))maxPrice = "$600,000";
// 		if(url.contains("ks/bel-aire/the-courtyards-at-elk-creek"))status = "Final Phase, "+status;
// 		if(url.contains("the-courtyards-at-mint-hill"))status=ALLOW_BLANK;
// 		if(url.contains("https://www.epconcommunities.com/ia/ames/domani-courtyards")) {
// 		
// 			//add[0]="4114 Cochrane Pkwy ";
// 			add[1]="Ames";
// 			add[2]="IA";
// 		//	add[3]="50014";
// 			
// 			
// 			latlng = getLatLng(add);
// 			add = getAddress(latlng);
//// 			latlng=U.getlatlongGoogleApi(add);
//// 			add=U.getAddressGoogleApi(latlng);
// 			flag="TRUE";
// 		}
/* 		if(url.contains("https://www.epconcommunities.com/ks/bel-aire/the-courtyards-at-elk-creek"))
 			status=status.replace("Limited Number Of Lots Left ,Now Selling, Nearly Sold Out,", "");
 		
 			if(url.contains("https://www.epconcommunities.com/il/woodstock/maples-at-the-sonatas"))
 				status=status.replace("Last Chance, Only 2 Homes Remaining,", "");
 			
 			if(url.contains("https://www.epconcommunities.com/oh/plain-city/the-courtyards-on-hyland-run"))
 				status=status.replace(", Sold Out", "");
 
 				if(url.contains("https://www.epconcommunities.com/ia/ankeny/courtyards-at-rock-creek"))
 	 				status=status.replace(", Phase 1 Sold Out", "");
 				
 				if(url.contains("https://www.epconcommunities.com/oh/springfield/derby-glen-village"))
 					pType += ", Detached Homes";

 				if(url.contains("https://www.epconcommunities.com/tx/ft-worth/ladera-tavolo-park"))	maxPrice="$500,000";	
*/ 			
// 		if(url.contains("https://www.epconcommunities.com/nc/mebane/villas-5th"))status = "Final Phase"; 
 		
 		if(url.contains("https://www.epconcommunities.com/wi/menasha-appleton/woodland-lake-cottages")) {
 		 			add=U.getAddressGoogleApi(latlng);
 		 			flag="TRUE";
 		 		}
 				if(url.contains("https://www.epconcommunities.com/oh/chillicothe/the-courtyards-at-deer-run")) {
 					pType+=", Homeowner Association";
 				}
 				
 		if(url.contains("https://www.epconcommunities.com/mo/cottleville/the-courtyards-of-cottleville"))minPrice = "$370,000";
 				
//====================no.Of Units======================
 		int lotCount=0;
 		String noOfUnits=ALLOW_BLANK;
 		if(overViewHtml.contains("<iframe id=\"frame_comm_filing\"")) {
 			String siteUrlSec=U.getSectionValue(overViewHtml, "<iframe id=\"frame_comm_filing\"", "</iframe>");
 		    String siteUrl=U.getSectionValue(siteUrlSec, "src=\"", "\"");
 		    U.log("siteUrl:: "+siteUrl);
 		    String siteHtml=U.getHtml(siteUrl,driver);
 		    U.log("pATH:: "+U.getCache(siteUrl));
 		    String lotData[]=U.getValues(siteHtml, "<span class=\"legend_text \"", "</div>");
 		    String lotNum=ALLOW_BLANK;
 		    for(String data:lotData) {
// 		    	U.log(data);
 		    	 data=U.getNoHtml(data);
// 		    	U.log("Data No Html "+data);
 		    	data=data.replaceAll("data-legend-id=\"", "")
 		    			.replaceAll("\\d+\">", "");
 		    	U.log("Data No Html "+data);
//// 		    	String data1=U.getSectionValue(data, ">", ")");
// 		    	
 		    	lotNum=Util.match(data, "\\d+");
// 		    	U.log("NUM="+lotNum);
 		    	lotCount+=Integer.parseInt(lotNum) ;
 		    	
 		    			
 		    }
 		   U.log("lotCount="+lotCount);
 		    noOfUnits=Integer.toString(lotCount);
 		   if(lotCount==0) {
 			  noOfUnits=ALLOW_BLANK; 
 		   }
 		
 		
 		}
 		
 		
		data.addCommunity(name, url, Type);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status.replace("Ii ", "II ").replace("Now Selling Quick Move-In Homes", "Now Selling, Quick Move-In Homes"));
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);

	}
		j++;

	}

	private static String[] getAddress(String []latlng) throws Exception{
		 String[] add = U.getGoogleAddressWithKey(latlng);
		 if(add == null) add = U.getAddressHereApi(latlng);
		 return add;
	}
	private static String[] getLatLng(String add[]) throws Exception{
		String[] latlng= U.getlatlongGoogleApi(add);
		if(latlng == null) latlng = U.getlatlongHereApi(add);
		return latlng;
	}
	
}