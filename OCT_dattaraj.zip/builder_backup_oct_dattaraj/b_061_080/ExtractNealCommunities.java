/**
 * @author Aditya Mukundwar
 * @date 21/12/2016
 * 
 */
package com.shatam.b_061_080;
import java.io.*;
import java.io.IOException;
import java.util.Arrays;

import com.shatam.b_201_220.StoneridgeHomes;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNealCommunities extends AbstractScrapper {

	CommunityLogger LOGGER;
	final static String BUILDER_URL = "https://www.nealcommunities.com";
	static int j=0;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractNealCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Neal Communities.csv", a.data().printAll());
	}

	public ExtractNealCommunities() throws Exception {

		super("Neal Communities", BUILDER_URL);
		LOGGER = new CommunityLogger("Neal Communities");
	}

	@Override
	public void innerProcess() throws Exception {
  

		String html = U.getHTML("https://www.nealcommunities.com/where-we-build/");
		String regUrlSections = U.getSectionValue(html, "<div class=\"map-where\">", "<div class=\"home-interest-list w-container\">");
//		U.log(regUrlSections);
		String regUrlsSec [] = U.getValues(regUrlSections, "<a", "</a");
		

		
		int cnt = 0;
//			regUrl = U.getSectionValue(regUrl, "href=\"", "\"");
//			if(regUrl.contains("/where-we-build/where-neal-builds/"))continue;
			//U.log("Region Url =="+BUILDER_URL+regUrl);
//			String regHtml = U.getHTML(BUILDER_URL+regUrl);
//			U.log(regUrlsSec.length);
			for(String commUrlSec : regUrlsSec){
				String communityUrl = U.getSectionValue(commUrlSec, "href=\"", "\"");
				//U.log("commFORUrl================================================================>>>>>> "+communityUrl);
				if(communityUrl.contains("#"))continue;
//				try {
					addDetails(communityUrl,commUrlSec);
//				} catch (Exception e) {}
				cnt++;
			}
		
		U.log("Total Count =="+cnt);
		LOGGER.DisposeLogger();
	}

	//int j=0;
	private void addDetails(String communityUrl,String comSec) throws Exception {
		
	//if(j>=4)
		
		{
		
		U.log("Count :"+j);

		
	//TODO: Execute for single community
	if(!communityUrl.contains("https://www.nealcommunities.com/new-homes/wildleaf-at-north-river-ranch/"))return;
		

		U.log("communityURL========================================================> "+communityUrl);
		String comHtml = U.getHTML(communityUrl);
		U.log("===================================================================="+U.getCache(communityUrl)+"===============================================================");
		
//		U.log(comSec);
		// ----------------- Community Url-----------------------
		String comName = U.getSectionValue(comSec, "<div class=\"where-comm-name\">","</div>");
		comName = comName.replace("&#39;s", "").replace("&#038; ", "& ");
		U.log("comName========================================================> "+comName);
		//U.log(comSec);
		
		
		// ----------------- Community LOGGER-----------------------
		
		if (data.communityUrlExists(communityUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + communityUrl);
			return;
		}
		LOGGER.AddCommunityUrl(communityUrl);
		
		
		// ----------------- Community LatLong-----------------------
		String latitude = U.getSectionValue(comSec, "data-latitude=\"",	"\"");
		String longitude = U.getSectionValue(comSec,"data-longitude=\"", "\"");
		U.log("latitude : " + latitude + "  longitude : " + longitude);
		
		String[] latlng1= {latitude,longitude};
		
		String geo = "FALSE";

		

		// ----------------- Community Address-----------------------
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		

		String address=U.getSectionValue(comHtml, "<h3 class=\"heading-6\">DIRECTIONS TO", "</div>");
	
		//	U.log("Address1111 ::"+address);
		if(address!=null) {
			
			
			U.log("111111111111111111");
			address=address.replaceAll("From HWY 41:</b>: Exit onto Rockley Boulevard and follow for 3 miles. Turn right onto Center Road and then turn onto Observation Boulevard. The entrance to Grand Palm (on Aucilla Road) will be on your right. </p>|From HWY 41: : Exit onto Rockley Boulevard and follow for 3 miles. Turn right onto Center Road and then turn onto Observation Boulevard. The entrance to  (on Aucilla Road) will be on your right.  |From HWY 41: : Exit Onto Rockley Boulevard And Follow For 3 Miles Turn Right Onto Center Road And Then Turn Onto Observation Boulevard The Entrance To (on Aucilla Road) Will Be On Your Right 21209 Wacissa Drive|<div class=\"text-block-5\">From downtown Naples: take Davis Boulevard east to Santa Barbara Boulevard and head south on Santa Barbara. Travel 1 mile and turn left on Crews Road. Turn left onto Sunset Boulevard and Seychelles will be straight ahead.<p>|<div class=\"text-block-5\">From I-75: Take Exit 229 towards Parrish and follow Moccasin Wallow Road heading East. Travel 4 miles and turn Right onto Fort Hamer Road. Riverfield will be on your right.|<b>NEW ADDRESS: 3420 Sky Blue Cove, Lakewood Ranch FL 34211</p>", "");
			String rem=U.getSectionValue(address, "<p>", "</p>");
			if(rem!=null)
			address=address.replace(rem, "");
//			String addr=U.getSectionValue(address, "<a href=\"https://www.google.com/map", "</b>");
//			U.log("newAdd ::"+addr);
//			String addr1=U.getSectionValue(addr, "\">", "<");
			address=U.getNoHtml(address);
			address=address.replace(comName, "").replace("Homes available for pre-sales - schedule an appointment for more information", "")
					.replace("11568  Palm Court", "11568 Verandah Palm Court");
			U.log("newAdd ::"+address);
			address=address.replace("- Naples, FL", ", Naples, FL").replace(" - Sarasota", ", Sarasota").replace("- Parrish, FL", ", Parrish, FL").replace("- Venice FL", ", Venice, FL").replace("- Port Charlotte FL", ", Port Charlotte, FL");
			address=address.replace("-", ",");
			add=U.getAddress(address);
		}
			
		
		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/riverfield-at-north-river-ranch/")) {
			String addressSection=U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/", "</div>");
			if(addressSection != null)
				addressSection = U.getSectionValue(addressSection, "target=\"new\">", "</a>");
			
			if(addressSection != null) addressSection = addressSection.replace(" - ", ", ");
					
					
			U.log("addressSection ::"+addressSection);
			add=U.getAddress(addressSection);
			U.log("Add: "+Arrays.toString(add));

		}
//		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/wildleaf-at-north-river-ranch/")) {
//			String mAdd=U.getSectionValue(comHtml, "https://www.google.com/maps/search/?api=1&parameters&query=", "target=\"_");
//			String temp[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK}
//			
//		   temp[0]=mAdd.replaceAll("\\+|\\%2C", " ").trim();
//		    
//		}
//		add[0]=add[0].replaceAll("From HWY 41: : Exit Onto Rockley Boulevard And Follow For 3 Miles Turn Right Onto Center Road And Then Turn Onto Observation Boulevard The Entrance To (on Aucilla Road) Will Be On Your Right\\s* ", "");			
			if(communityUrl.contains("https://www.nealcommunities.com/new-homes/grand-palm/"))
				add[0]="21209 Wacissa Drive";
		
		
		if(add[0]==ALLOW_BLANK)   {
				
				
				String addressSection = U.getSectionValue(comSec, "<div class=\"where-comm-city\"", "</div>");

				if (add[0] == ALLOW_BLANK) {
					
			   U.log("22222222222222");
					add[1] = U.getSectionValue(addressSection, ">", ",");
					addressSection=addressSection.replaceAll(add[1], "");
					add[2] = Util.match(addressSection, "\\w{2}");
					add[3] = Util.match(addressSection, "\\d{5}");
					add[2]=add[2].replaceAll(add[3], "");
					//add[0] = U.getSectionValue(comHtml, "https://www.google.com/maps/search/?api=1&parameters&query=", "\"");
//					if(communityUrl.contains("https://www.nealcommunities.com/new-homes/cielo/"))
//						add[0] = "220 Corsano Drive";
					if(communityUrl.contains("https://www.nealcommunities.com/new-homes/wildleaf-at-north-river-ranch/"))
					add[0] = U.getSectionValue(comHtml, "https://www.google.com/maps/search/?api=1&parameters&query=", "%2C").replaceAll("\\+", " ");
					
					U.log("Add: "+Arrays.toString(add));

//					U.log(">>>>>>>>>>>"+add[0].length());
					if(add[0]!=null && add[0].length()>4) {
					add[0]=add[0].replaceAll("\\+|\\%2C", " ").replace(add[3], "");
//					add[0]=null;
					
					geo = "TRUE";
					}
					
					else if(add[0]==null || add[0].length()<4){
						U.log(">>>>>>>>>>>33333333333");
						
						 add[0]=U.getAddressGoogleApi(latlng1)[0];
						 geo = "TRUE";
					}
				}
		}

		
//		U.log(">>>>>>>>>>>"+add[0]);
		
		
		add[0]=add[0].replace("2665  Circle","2665 Seychelles Circle");
		add[0]=add[0].trim().replace("4056  Drive", "4056 SkySail Drive");
		U.log("Address ::"+Arrays.toString(add));
		
		//////////////////////////////////////////////////////////////////

	
		
		
		//------------------Floor Plan Data-----------------------
//		String planHtmls="";
		String floorHtml=ALLOW_BLANK;
		if (comHtml.contains("<h3>FLOOR PLANS AVAILABLE</h3>")) {
			String floorSec=U.getSectionValue(comHtml, "<div id=\"communityDetailsHomeListings\">", "<div class=\"clear\">");
			//U.log(floorSec);
			String[] floorUrlSec=U.getValues(floorSec, "<a class=\"btnStylesImportant\"", ">");
			for (String floorUrlse : floorUrlSec) {
				String floorUrl=U.getSectionValue(floorUrlse, "href=\"", "\"");
			//	U.log(floorUrl);
				String html=U.getHTML("https://www.nealcommunities.com"+floorUrl);
				floorHtml+=U.getSectionValue(html, "<div class=\"communityAndHomesDetails\">", "<div class=\"mediaSection amenityHolder\">");
			}
		}else{
			//Plan Section
//			U.log("=================");
			String planSection = U.getSectionValue(comHtml, "<div class=\"container w-container grid-plan\">", "<div class=\"detail-pic comm");
//			String planSection = U.getSectionValue(comHtml, "<div class=\"container w-container grid-plan\">", "<div id=\"Comm-Detail\" class=\"community-more-info\">");
//			if(planSection==null)
//				planSection = U.getSectionValue(comHtml, "<div class=\"container w-container grid-plan\">", "<div class=\"detail-pic comm");
			if(planSection == null)
				planSection = U.getSectionValue(comHtml, "<div class=\"series-description\">", "<div class=\"detail-pic comm");
			if(planSection == null)
				planSection = U.getSectionValue(comHtml, "<div class=\"series-description\">", "<div id=\"Comm-Detail\"");
			if(planSection != null){
				String planUrls[] = U.getValues(planSection, "<a href=\"", "\"");
				for(String planUrl : planUrls){
			//		U.log("planUrl ::"+planUrl);
					String pHtml = U.getHTML(planUrl);
//					planHtmls=pHtml;
					if(pHtml != null)
						floorHtml += U.getSectionValue(pHtml, "<div class=\"home-info\">", "<h3 class=\"heading-11 mart");
				}
			}
			
		}
//		String quickHtml="";
		if(comHtml.contains("<div>QUICK MOVE-IN</div>")) {
			String quickComSec=U.getSectionValue(comHtml, "<div class=\"container w-container grid-spec\">", "<script type=\"text/javascript\">");
			String[] quickUrls=U.getValues(quickComSec, "<a href=\"", "\"");
			U.log("QuickUrl: "+quickUrls);
			for(String moveUrl:quickUrls) {
				floorHtml+=U.getHTML(moveUrl);
			}
		}
		
		// ----------------- Community Sqft-----------------------
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		
		
		String[] sqft = U.getSqareFeet(comHtml+comSec,	"\\d,\\d{3} Sq Ft\\s*</div>|\\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+ Sq Ft|\\d,\\d+ Sq Ft|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} Sq Ft", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//		U.log("mmmmmm"+Util.matchAll(comHtml+comSec, "[\\w\\s\\W]{30}3,346[\\w\\s\\W]{30}", 0));

		// ----------------- Community Price-----------------------
		
			
		
		comHtml=comHtml.replaceAll("<a href=\"#\" class=\"w-dropdown-link.*</a>|<!--from high \\$\\d{3}&rsquo;s-->|<!-- <div class=\"starting\">STARTING AT \\$\\d{3},\\d{3}</div> -->|<!-- <div class=\"where-comm-starting\">Priced from \\$\\d{3},\\d{3}</div> -->", "").replaceAll("0s|0’S|0&rsquo;s|0<span style=\"text-transform:lowercase\">'s", "0,000"); 
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		String regHtml=U.getHTML("https://www.nealcommunities.com/where-we-build/");
		String regdata[]=U.getValues(regHtml,"<div class=\"where-comm-name\">", " <div class=\"where-comm-btn");
		
		for(String regData : regdata)
		{
			if(regData.replace("&#038;", "&").contains(comName))
			{
				regData=regData.replaceAll("<!-- <div class=\"where-comm-starting\">STARTING AT \\$\\d+,\\d+</div> -->|<span style=\"text-transform:lowercase\">", "").replace("0's", "0,000");
				String price[] = U.getPrices(comHtml+regData, "Priced at \\$\\d,\\d{3},\\d{3}|Priced from <br>\\$\\d{3},\\d{3}</div>|LOW \\$\\d+,\\d+|MID \\$\\d{3},\\d+|UPPER \\$\\d{3},\\d{3}|MID \\$\\d{3},d{3}|\\$\\d{3},\\d{3}", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			}
		}
		
//		String price[] = U.getPrices(comHtml, " MID \\$\\d{3},d{3}|\\$\\d{3},\\d{3}", 0);
//		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
//		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		

	/*	if(communityUrl.contains("https://www.nealcommunities.com/new-homes/poinciana/"))
			maxPrice = "$318,990";
*/		U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);

		// ----------------- Community Data-----------------------
		String propType = ALLOW_BLANK;
		String propStatus = ALLOW_BLANK;
		String drvPropType = ALLOW_BLANK;
		String commType = ALLOW_BLANK;
		String notes = ALLOW_BLANK;

		String propHtml = comHtml.replace("Lakewood Ranch", "");
		//===================================================================== Property Type =========================================================================================
		propHtml = propHtml.replace("coastal-inspired", "coastal area home").replace("urban farmhouse feel", "modern farmhouse").replace("paired villas", "paired home villas").replace("twin villa homes", "twin home villa homes");
//		U.log(floorHtml);
		
//		U.log("mmmmmm"+Util.matchAll(comSec+propHtml+floorHtml, "[\\w\\s\\W]{20}ranch[\\w\\s\\W]{20}", 0));
		propType = U.getPropType((comSec+propHtml.replaceAll("Luxury carriage homes ", "Luxury Homes carriage homes ")+floorHtml).replaceAll("leaf-at-north-river-ranch|NorthRiverRanch|River Ranch|resort-style pool|Cottage Hill Avenue|Cottage|cottage|https://www.nealvillahome.com/| <div>Villa Homes</div>",""));
		U.log("PType====================================================================>:::"+propType);
		//
		//=========== ==========================================================Property Status =======================================================================================
		
		String remSec = U.getSectionValue(propHtml, "<li class=\"mainNavLiItem hasDrop", "</ul>");
		if(remSec != null)
			propHtml = propHtml.replace(remSec, "");
		
		propHtml = propHtml.replaceAll("Quick move-in and move-in ready units|131112=Boca Royale Golf &amp; Country Club=69119|FishHawk Ranch=96542| Lakewood Ranch|model home is now available|Opportunities in", "");
		propHtml=propHtml.replaceAll("Move In Ready Homes Available Now", "Move In Ready Homes")
				.replace("FINAL PHASE - NOW SELLING", "FINAL PHASE NOW SELLING");
		comSec=comSec.replaceAll("Move In Ready Homes Available Now", "Move In Ready Homes");
//		 <div>Quick Move-In Homes</div>
		propStatus = ALLOW_BLANK;
		U.log("============================================================================================================================================================");
	//	U.log(propHtml);
		String remStr = "homes are coming|Just a few remaining home sites are left|NOW AVAILABLE FOR|Quick Move|quick move|now available for walk-through|receive Grand Opening information|close-out stage and is by appointment| To \\$25,000 On Quick Move-In Homes|prices now available!|collection of move-in ready homes| and Grand Opening invitations| grand opening pricing and special event|Now Open for Pre-Sales|There are just 2 homes left|Collection Is Now Available|grand opening events|exciting new community, opening|<h3 class=\"h3-white\">Quick Move-In Homes</h3>|title=\"Quick Move-in Homes\"|of our quick move-in homes|our beautiful, quick move-in homes| model and quick move-in homes|  <div>Quick Move-In Homes</div>|Come into Neal Communities and ask about our move-in ready home specials|COMING SOON: Daybreak |marketingDescription\">\\s+[\\(]*COMING SOON|Coming Soon[\\)]*!\\s+</div>|Quick Move-In!</div>|Quick move-in homes are available|Home Designs &amp; Floor Plans Available|Home Designs &amp; Floor Plans Available|new home available now in|Last |selling the last remaining home|your last chance to live in the center of everything|all-new, move-in ready";
		propHtml = propHtml.replaceAll(remStr, "").replace("Coming this Winter, 2019", "Coming Winter 2019");
		comSec = comSec.replaceAll("Home Designs &amp; Floor Plans Available|close-out stage and is by appointment|grand opening events and|close-out\">|<h3 class=\"h3-white\">Quick Move-In Homes</h3>|  <div>Quick Move-In Homes</div>| Last |selling the last remaining home|your last chance to live in the center of everything","");
		propHtml = propHtml
				.replace("FINAL PHASE &#8211; NOW SELLING", "Final Phase Now Selling");
				
		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/boca-royale-golf-country-club/")) {
			propHtml=propHtml.replace("small-light mr w-button\">QUICK MOVE-IN HOMES</a>\r\n" + 
					"            <h3 ", "");
		}
//		.replaceAll("small-light mr w-button\">QUICK MOVE-IN HOMES</a>\r\n" + 
//				"            <h3 ", "");
		
//		U.log("mmmmmm"+Util.matchAll(propHtml+comSec, "[\\w\\s\\W]{30}Move-in-ready[\\w\\s\\W]{30}", 0));
		
		propStatus = U.getPropStatus((propHtml+comSec).replaceAll("Now Available for Pre-Sales|Now open for pre-sales", "").replace("New Homes, Now Selling", "New Homes Now Selling"));

		if(!(propStatus.contains("Move")||propStatus.contains("Homes Available")) && propHtml.contains("btnViewQmis\">HOMES AVAILABLE NOW</li>")){
			if(propStatus.length()<4){
				propStatus = "Quick Move-in Homes";
			}
			else{
				propStatus = propStatus + ", Quick Move-in Homes";
			}
		}
		if(communityUrl.contains("https://www.nealcommunities.com/where-we-build/tampa/waterset") && propHtml.contains("Just 1 new home left")){
			
			propStatus = "Just 1 new home left";
		
		}
		if(propStatus.contains("Final Phase") && propStatus.contains("Final Phase Now Selling")){
			propStatus = propStatus.replaceAll("Final Phase\\s*,", "");
		}

		U.log("status============================================>"+propStatus);
//		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/vicenza/"))propStatus=propStatus+", Coming Winter 2019";
	
		
		
		//=========== Community Type ========================
		
		commType = U.getCommType(propHtml.replaceAll("onto Golf Course Road|Boca Royale Golf &amp; Country Club", ""));
		
		//=========== Derived Community Type ============
		propHtml = propHtml.replaceAll(">Taylor Ranch|River Ranch|Colonial Boulevard|Colonial Blvd| Lakewood Ranch|-Ranch|FishHawk Ranch", "");
		drvPropType = U.getdCommType(propHtml);
		U.log("Dtype::"+drvPropType);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(floorHtml, "[\\s\\w\\W]{30} story[\\s\\w\\W]{30}", 0));
		
		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/boca-royale-golf-country-club/")) {
			propStatus=propStatus.replace("Quick Move-in Homes", "");
		}
//			if(communityUrl.contains("https://www.nealcommunities.com/new-homes/riverfield-at-north-river-ranch/")) {
//				drvPropType="Ranch";
//			}
		comName = comName.replaceAll("Golf &amp; Country Club$|Golf & Country Club", "");
		U.log("CommName==>"+comName);
		add[0]=add[0].replaceAll("FL \\d+|From I-75:</b> Take Exit 205 for Clark Road heading East for 1 mile. Turn Right on Ibis Street. Travel South for almost 2 miles. Grand Park will be on your right.</p>\\s*<p><b><a href=\"https://www.google.com/maps/place/Grand+Park+%7C+Neal+Communities/@, 17z/data=!3m1!4b1!4m5!3m4!1s0x0:0xfcd578ababc94f68!8m2!3d27.2381869!4d-82.4366681?hl=en\"", "");
		notes= U.getnote(propHtml);
		
//		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/avelina/"))geo="TRUE";
		
		
		propType = propType.replace("Townhouse, Townhome", "Townhome");
		
		if(propStatus.contains("Move-in-ready"))propStatus=propStatus.replace("Move-in-ready", "Quick Move-in");
		if(communityUrl.contains("https://www.nealcommunities.com/new-homes/wysteria/") || communityUrl.contains("https://www.nealcommunities.com/new-homes/skysail/"))
			propStatus=propStatus.replace(", Quick Move-in", "");
		
		// ----------------- Community Data-----------------------
		data.addCommunity(comName, communityUrl, commType);
		data.addLatitudeLongitude(latitude, longitude, geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("Venice", ""), add[1], add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, drvPropType);
		data.addPropertyStatus(propStatus);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
//		j++;
		}
	j++;
	}
	

}