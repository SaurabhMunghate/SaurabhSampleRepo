/** @author Rakesh Chaudhari
 *  @date 23 Jun 2015 
 */

package com.shatam.b_061_080;
import java.io.*;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNealsignature extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	
	WebDriver driver=null;
	
	public static void main(String[] ar) throws Exception {
		

		AbstractScrapper a = new ExtractNealsignature();
		//U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"Neal Communities - Neal Signature Homes.csv",	a.data().printAll());

	}

	public ExtractNealsignature() throws Exception {

		super("Neal Communities - Neal Signature Homes","https://nealsignaturehomes.com/");
		LOGGER = new CommunityLogger("Neal Communities - Neal Signature Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String htm = U.getHTML("https://nealsignaturehomes.com/");

		String section = U.getSectionValue(htm, "<div class=\"sub-nav__map\">", "<div class=\"sub-nav__footer\">");
		String blocks[] = U.getValues(section,"sub-nav__city\">", "</div>");

		// String urls[] = U.getValues(htm, "<a href=\"", "\"");
		U.log("Total::"+blocks.length);
		for (String commBlock : blocks) {
			//U.log(commBlock);
			//U.log("Hello---------------------------");
			String regUrl=U.getSectionValue(commBlock, "<a href=\"", "\"");
			if(!regUrl.contains("http")) {
			regUrl="https://nealsignaturehomes.com"+regUrl;
			}
			U.log("region url "+regUrl);
			String regHtml=getHtml(regUrl, driver);
			String urls[] = U.getValues(commBlock, "<li><a href=\"", "\"");
			for (String url : urls) {
				if(!url.contains("http")) {
					url="https://nealsignaturehomes.com"+url;
					}
				
				//U.log("Community URl "+url);
				addDetails(url, regHtml);
			}
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	int n = 1;

	private void addDetails(String url,String regHtml) throws Exception
	{
		
//		try {
		//TODO : Execute for single community
		
//		if(!url.contains("https://nealsignaturehomes.com/aria/"))return;
		
		U.log("\n\n"+U.getCache(url));
		if(url.contains("https://nealsignaturehomes.com/on-your-lot/")) {																																																												
			LOGGER.AddCommunityUrl(url+ "---------------------------------redirect to custom home design url");
			return;
		}
		U.log("PAGE :[" + (n++) + "]:" + url);
		
			
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
			duplicates++;
			return;
		}
		LOGGER.AddCommunityUrl(url);
		String htm1 = getHtml(url,driver);
		htm1=U.removeSectionValue(htm1, " <p>Filter By</p>", "<div class=\"home-search__checkboxes\">");
		htm1=U.removeSectionValue(htm1, "<div class=\"site-header__bottom\">", "</header>");
		htm1 = U.removeComments(htm1);
		regHtml = U.removeComments(regHtml);
		
		if (htm1.contains("Error loading MacroEngine script")) {
			LOGGER.AddCommunityUrl(url+ "---------------------------------Error loading MacroEngine script");
			duplicates++;
			return;
		}
	
		// GeoCode
		String geocode = "FALSE";

		// -- Community Name -- //
		String communityName = ALLOW_BLANK;
		communityName = U.getSectionValue(htm1, "<h1>", "</h1>").replace("&#038;", "&");
		communityName =  communityName.replace(" – ", " - ");
		U.log(communityName);
		// String baseurl=url.replace("http://www.nealcommunities.com", "");
		
		//============== Address =======================
		String addresssection = U.getSectionValue(htm1, "</a></figure>", "/p>");
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };


		// U.log(addresssection);

		String addSec = U.getSectionValue(htm1, "city__sales-address", "</ul>");
		if (addSec!=null) {
			addSec=addSec.replace("Neal Signature Homes at Country Club East", "");
			addSec=addSec.replace("<li>"+U.getSectionValue(addSec, "<li>", "</li>")+"</li>", "");
			addSec=addSec.replace("</li>", ",");
			addSec=addSec.replaceAll("\\s{2,}|<li>|\">|</li>", "");
			add=U.getAddress(addSec);
		}
		if(url.contains("/river-wind/")) {
			addSec =U.getSectionValue(htm1, "<ul class=\"city__sales-address\">", " </ul>");
			if(addSec!=null) {
			addSec=addSec.replace("Bradenton", ", Bradenton").replaceAll("<li>River Wind</li>|\\<.*?>", "");
			add=U.getAddress(addSec);
			}
		}
		U.log(addSec);
		
		U.log("street: " + add[0] + " City: " + add[1] + " ST: " + add[2] + " Z: "	+ add[3]);

		//=============== LatLng =======================

		String secGMap = U.getSectionValue(htm1, "data-location=","}]");

		U.log("My Section: " + secGMap);

		if (secGMap != null) {
			// secGMap = U.getSectionValue(secGMap, "@", ",");
			if (!secGMap.contains("@")) {
				String lat = Util.match(secGMap, "\\d{2}\\.\\d{4,}");
				String lng = Util.match(secGMap, "-\\d{2,3}\\.\\d+");
				latLng[0] = lat;
				latLng[1] = lng;
				geocode = "False";
			}
		}
		U.log("lat: "+latLng[0]+" lon: "+latLng[1]);
		
		if(latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK){
			latLng[0]= U.getSectionValue(htm1, "data-lat=\"", "\"");
			latLng[1]= U.getSectionValue(htm1, "data-lng=\"", "\"");
		}
		if(latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK){
			String latLngSec = U.getSectionValue(htm1, "https://www.google.com/maps", "target=");
			if(latLngSec != null){
				latLngSec = U.getSectionValue(latLngSec, "2!3d", "\"");
				U.log(latLngSec);
				latLng = latLngSec.split("!4d");
			}
		}
		U.log(Arrays.toString(latLng));
		if (add[0] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geocode = "TRUE";
		}
		U.log(U.getCache(url) + "&&&&&&&&&&&&&&&&&&");
		// }
		// -- Price -- //
		String[] plans = U.getValues(htm1, "<div class=\"home-search__wrap\">", "<div"); 
		U.log(plans.length);
		String plansHtml = "";
		String availHtml="";
		for(String plan:plans){
			plan=U.getSectionValue(plan, "href=\"", "\"");
			try{
			U.log("plan==="+plan);
			if (plan.contains("/available")) {
				availHtml=availHtml+U.getHtml(plan,driver);
			}
			plansHtml = plansHtml + U.getHtml(plan,driver);
//			if(plansHtml.contains("courtyard")) {
//				U.log("Found");
//				}
			}
			
			catch (Exception e) {
				// TODO: handle exception
				U.log(e);
			}
		}
		plansHtml = U.removeComments(plansHtml);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		// U.log(U.getCache(url));
		String remSec="$250,000 - $500,000|$500,000 - $750,000|$750,000+";
		//U.log(remSec);
		htm1=htm1.replaceAll(remSec, "");
		remSec=U.getSectionValue(htm1, "<select name=\"square_feet\"", "</select>");
		if(remSec!=null)
		htm1=htm1.replaceAll(remSec, "");
		htm1=htm1.replace(" floor plans ranging from 3,555 to 5,000-plus square feet", " floor plans ranging from sqft\">3,555</li>   sqft\">5,000</li> square feet");
		//================= Sqft =========================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(htm1,
						"\\d,\\d{3} - \\d,\\d{3} SqFt|sqft\">\\d,\\d{3}</li>|\\d+,\\d+ Sq. Ft|\\d+,\\d+ to \\d+,\\d+ plus square feet|\\d+,\\d+ to \\d+,\\d+ square feet|\\d,\\d+ and \\d,\\d+ plus square feet|\\d,\\d+ and \\d,\\d+ square feet|\\d,\\d{3}-square-foot",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		// $1m's<
		// 1m's
		//================= Price ===========================
		htm1 = htm1.replace("low 1M", "low $1,000,000").replace("$1M", "$1,000,000");
		plansHtml = plansHtml.replace("$1m's", "$1,000,000").replace("$1M", "$1,000,000");
		htm1 = htm1.replace("'s", ",000");
		plansHtml = plansHtml.replace("'s", ",000");
		htm1 = htm1.replace("00s", "00").replace("$1M", "$1,000,000");
//		U.log("****************************************************************");
//		U.log(htm1);
//		U.log("****************************************************************");
		String[] price = U.getPrices(htm1,"<span>\\$\\d+,\\d+</span>|From \\$\\d{3},\\d{3}</h3>|starting at \\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|From the high \\$\\d+,\\d+",0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//		U.log(Util.matchAll(htm1, "[\\w\\s\\W]{30}1,015,990[\\w\\s\\W]{30}", 0)); 
//		U.log(Util.matchAll(plansHtml, "[\\w\\s\\W]{30}1,015,990[\\w\\s\\W]{30}", 0)); 

		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -- Square Feet -- //

		// -- Address & Latitude, Longitude -- //
		
		if (latLng[0].equals("37.0625") || latLng[0].contains("25.7734431")) {
			latLng[0] = ALLOW_BLANK;
			latLng[1] = ALLOW_BLANK;
		}
		if (latLng[0] == ALLOW_BLANK) {
			latLng[0] = latLng[1] = geocode = ALLOW_BLANK;
		}
		if (availHtml!=null||availHtml.trim().length()!=0) {
			if (availHtml.contains("loft")) {
				availHtml=availHtml.replace("bonus/game/loft room", " loft-style ");
			}
		}
		
		String prosec = U.getSectionValue(htm1,	"<section class='main' id='main' role='main'>",	"<div class='data-grid'>");
		htm1=htm1.replace("luxury homes are fully customizable", "luxury homes are fully custom home")
				.replace("West Indies and Coastal architecture", "West Indies and Coastal architectural styles")
				.replace("luxury estate home", "luxury homes, Estate Residences").replace("Luxurious Custom Homes</li>", " custom home designs");
	//	U.log(prosec + "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		String propertytype = U.getPropType((htm1+availHtml+plansHtml).replace("country estates", "estate-style living").replace("Luxury at", "luxury home")
				.replaceAll("Find your luxury Home</a>|<p>Explore all luxury homes\\.</p>|Luxury of Living Well\"|custom\" >Custom Homes|Custom Built Neal Signature Homes|See our custom|Custom", ""));
//		U.log(Util.matchAll(htm1, "[\\w\\s\\W]{30}single-family[\\w\\s\\W]{30}", 0)); 
//		U.log(Util.matchAll(availHtml, "[\\w\\s\\W]{30}single-family[\\w\\s\\W]{30}", 0)); 
//		U.log(Util.matchAll(plansHtml, "[\\w\\s\\W]{30}single-family[\\w\\s\\W]{30}", 0)); 

		
		U.log("propertytype==="+propertytype);
/*			if (propertytype.length() < 1) {
				propertytype = ALLOW_BLANK;
			}
		if (propertytype == null) {
			propertytype = ALLOW_BLANK;
		}
*/		
			htm1 = htm1.toLowerCase().replace("ranch", url).replace("at the estuary is now available", "");
		plansHtml = plansHtml.replaceAll("Lakewood Ranch</label>|17_3'>Lakewood Ranch</label>|at-ranch/\"><span class=\"wpmega-link-title\">The Forest at Hi Hat Ranch</span></a></li>|<br/> Lakewood Ranch, FL 34202</p>", "");		
		htm1=htm1.replaceAll("1 and 2 story|one- and two-story|One- & Two-Story|one- or two-story", " 1 Story   2 Story ");
		htm1=htm1.replace("one- &amp; two-story", " 1 Story  2 Story ").replace("lakefront homesites", "lakefront community");
		
		String dType = U.getdCommType(communityName+(htm1+url+plansHtml).replaceAll("floor|Lakewood Ranch|\\+Lakewood\\+Ranch,|Hi Hat Ranch|lakewood Ranch, FL|Hat Ranch|ranch","").replaceAll("one- or two-story| single or two-story", " 1 story  2 story  "));
		
		htm1 = htm1.replace("class=\"wpmega-link-title\">Move In Ready</span>",	"");
		htm1 = htm1.toLowerCase().replace("is coming soon to sarasota", "");
//		String drop = U.getSectionValue(htm1, "</head>", "</header>");
		
//		htm1 = htm1.replace(drop, "");
//		htm1=U.removeSectionValue(htm1, "<p>Filter By</p>", "</html>");
		String propstatus = U.getPropStatus(htm1.replaceAll("country club - st. lucia: now selling|-now-selling|pristine home sites|Just 2 quick move-in homes", ""));
		U.log(" propstatus================="+propstatus);

		htm1=htm1.replaceAll("&amp;", "&");
		htm1 = htm1.replaceAll("gated neighborhood|close to golf|country-club-|country-club-east|country-club-west|<li><a href=(.*?)</li|boca-royale-golf-country-club/|>boca royale golf & country club<|Golf &Amp; Country Club|Golf & Country Club|Country Club East|Country Club West|Resort Style</option>|boca-royale-golf-country-club|Boca Royale Golf & Country Club|country club east|country club west|country club</span>|country club</a>", "");
		
//		htm1=htm1.replace("waterfront lifestyle", "waterfront community").replace(U.getSectionValue(htm1, "button button--blue js-clear-form", "</select>"), "");
		
		String commType = U.getCommunityType(htm1
				.replace("selection of pristine lakeside homes", "selection of pristine lakeside living homes")
				.replace("exciting lakefront adventures", "exciting lakefront property adventures"));
//		U.log(Util.matchAll(htm1, "[\\w\\s\\W]{30}golf & country club[\\w\\s\\W]{30}", 0)); 

		U.log("Ctype::"+commType);

		/*if (url.contains("http://nealsignaturehomes.com/forest-high-hat-ranch")) {
			commType=commType.replace("Resort Style,Golf Course,Master Planned,Country Club", "Master Planned");
		}
		if (url.contains("/country-club-east-windy-will")||url.contains("/university-park-lansdowne")||url.contains("/wildgrass")) {
			commType=commType.replace("Resort Style,", "");
		}*/
		
		
		if (add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK 	&& latLng[0] == ALLOW_BLANK) {
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geocode = "TRUE";
		}
		
//		htm1=U.getHTML(url);
//		U.log(htm1);

		htm1 = htm1.replace("<span class=\"wpmega-link-title\">Move In Ready</span>", "").replace("our newest community, is coming soon", "");
	//	U.log(htm1);
		htm1 = U.removeSectionValue(htm1, "</head>", "</header>");

		htm1 = U.removeComments(htm1);
		htm1=U.removeSectionValue(htm1, "<p>Filter By</p>", "Advanced Filters");
		htm1=htm1.replaceAll("Just 2 quick move-in homes|<p>See all move-in ready homes.</p>|<p>Move-In Ready Homes</p>|\\s*community only has 3&nbsp;quick move-in homes&nbsp;available.|move-in ready homes|Don’t let the final opportunity|don’t let the final opportunity", "");

		String pStatus = U.getPropStatus(htm1.replaceAll("pristine home sites available|just 2 quick move-in homes", ""));
		U.log("pStatus=="+pStatus);
		
	
		U.log(pStatus.contains(" Move-in Ready Home"));

//		if (htm1.contains("home-search__result--move-in-ready") && !pStatus.contains("Move-in Ready Homes")) {
//			if(pStatus==ALLOW_BLANK || pStatus.length()<4){
//				pStatus="Move-in Ready Homes";
//			}
//			else {
//				pStatus=propstatus;
//			}
//		}

		pStatus = pStatus.replace("2 Quick Move-in Home", "Move-in Ready Homes");
		if (pStatus.length() < 2) {
			pStatus = ALLOW_BLANK;
		}
		if(pStatus.contains("Last Opportunity, Few Home Sites Remain, Final Opportunity")){
			pStatus="Few Home Sites Remain, Final Opportunity";
		}
		if (url.contains("/the-estuary/")) {
			propstatus=propstatus+", Final Homesite Available";
		}
		add[0] = add[0].replaceAll("<.*?>", "");//

		latLng[0] = latLng[0].replace(" ", "");
		if(add[0].contains("8301 The Park Blvd")&&add[1].contains("University Park")){
			latLng[0]="27.4057353";
			latLng[1]="-82.4755669";
			geocode="True";
		}
		if(add[0].length()<5 && latLng[0].length()>4){
			String add1[] = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			add[0] = add1[0];
			geocode="TRUE";
		}
		
		if (url.contains("https://nealsignaturehomes.com/boca-royale-golf-country-club")) {
			communityName ="Boca Royale";
		}
		
		U.log("Ctype::"+commType);
		U.log("Ptype:::"+propertytype);

		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geocode);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propertytype, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
//		}catch(Exception e) {}

	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		int i=1;
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));

					driver.get(url);
					try{
					((JavascriptExecutor) driver).executeScript("window.scrollBy(,4000)", "");
					}catch(Exception e){}
					 Thread.sleep(10000);
					 String html1="";
					
					//Thread.sleep(15000);
					U.log("Current URL:::" + driver.getCurrentUrl());

					String htm = driver.getPageSource();
					//U.log(html);
					WebElement click=null;
					String totalHomes=Util.match(htm, "\\d+ results");
					if(totalHomes != null){
						totalHomes=Util.match(totalHomes, "\\d+");
						//*[@id="page-section-content_1"]/div[4]/div/div[2]/div[3]/div[1]/div[7]/a
						//if(driver.findElement(By.cssSelector("#page-section-content_1 > div.page-element-dynamic.page-element-homes-search-dynamic > div > div.container > div:nth-child(3) > div.home-search__list-view > div.home-search__more > a")).isDisplayed())
						while(i<Integer.parseInt(totalHomes) && Integer.parseInt(totalHomes)!=0)
						{//   //*[@id="page-section-content_1"]/div[4]/div/div[2]/div[3]/div[1]/div[7]/a //*[@id="page-section-content_1"]/div[4]/div/div[2]/div[3]/div[1]/div[7]/a
							i=i+6;////*[@id="page-section-content_1"]/div[4]/div/div[2]/div[3]/div[1]/div[13]/a
							//*[@id="page-section-content_1"]/div[4]/div/div[2]/div[3]/div[1]/div[7]/a     //*[@id="page-section-content_1"]/div[4]/div/div[2]/div[3]/div[1]/div[7]/a
							try {
//								click=driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[8]/div[2]/div[3]/div[1]/div["+i+"]/a"));
								click=driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[9]/div[2]/div[3]/div[1]/div[7]/a"));

								
								if (click.isDisplayed()&&click.isEnabled()) {
									//click.
									click.click();
								}
							} catch (Exception e) {
								// TODO: handle exception
							} 
						
						//click = driver.findElement(By.xpath("//*[@id=\"page-section-content_1\"]/div[4]/div/div[2]/div[3]/div[1]/div["+i+"]/a"));
						//*[@id="page"]/main/ui-view/ng-include[1]/div/div[2]/ul/li[41]/a
						 
						
						 Thread.sleep(5000);
						 U.log("Current URL:::" + driver.getCurrentUrl());
						 html = driver.getPageSource();
						}
					}
					i=0;
					html=html1+html;
					if(html.length()<200)html=htm;
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}