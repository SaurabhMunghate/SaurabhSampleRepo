/**
 *Modification Aditya..
 @author Rakesh Chaudhari
 * @date 
 * 
 */
package com.shatam.b_061_080;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractStanleyMartinHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicate = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	int k=0;
	WebDriver driver;
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractStanleyMartinHomes();
		a.process();
		U.log("duplicate=" + duplicate);
		FileUtil.writeAllText(U.getCachePath() + "Stanley Martin Homes.csv", a.data().printAll());

	} 

	public ExtractStanleyMartinHomes() throws Exception {

		super("Stanley Martin Homes", "https://www.stanleymartin.com/");
		LOGGER = new CommunityLogger("Stanley Martin Homes");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		// Your code here
		String html1 = U.getHTML("https://www.stanleymartin.com/");
//		U.log(html1);

		String section = U.getSectionValue(html1,
				"Choose a location</option>", "</select>");
		// U.log(section);
		String links[] = U.getValues(html1, "<option value=\"", "\"");
	
		for (String itom : links) {
			
			itom = "https://www.stanleymartin.com" + itom;
			U.log("Region: "+itom);
			if(itom.contains("/aiken-north-augusta/harlem/hickory-woods")) {
				addDetails(itom, ""); //direct community url given in region section
			}
			
			String regionHtml = U.getHTML(itom);
			if(!regionHtml.contains("<a href=\"#findYourHome\" class=\"nav-link\" title=\"Choose A Design\">")) {
			String[] comSec = U.getValues(regionHtml, "<li class=\"border bg-white h-auto", "</li>");
			U.log(comSec.length);
			for(String com : comSec ) {
				
				String comUrl = U.getSectionValue(com, "<a href=\"", "\"");
				
//				U.log(comUrl);
				
				if(!comUrl.contains("http"))
				comUrl = "https://www.stanleymartin.com"+comUrl;
				//if(comUrl.contains("https://www.avexhomes.com"))
				//	addData(comUrl, com);////// never used - update from march 2022
				//else
//				try {
					addDetails(comUrl, com);
//				} catch (Exception e) {}
				
					
			}
			}
			else
//				try {
					addDetails(itom, "");
//				} catch (Exception e) {}
				

			inr++;

		}
		// U.log(i);
		LOGGER.DisposeLogger();
	}
	
	private void addData(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.avexhomes.com/communities/dillard-pointe"))return;
		
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		
		
		LOGGER.AddCommunityUrl("communityurl::::::::" + comUrl);
		
		U.log("comUrl: "+comUrl);
		
		String html = U.getHTML(comUrl);
		//========== ComName ==========
		String comName = U.getSectionValue(com, "title=\"", "\"").trim() ;
		U.log("comName: "+comName);
		comName=comName.replace("West Village At Avalon Park Orlando","West Village At Avalon Park");
		
		//====== Address ==============
		String[] add = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		String[] latlong = {ALLOW_BLANK, ALLOW_BLANK};
		String Geo = "FALSE";
		
		String[] addSecs = U.getValues(html, "<div class=\"et_pb_text_inner\">", "</p>");
		for(String addSec : addSecs)
			if(addSec.contains(">directions</a>")) {
				U.log(addSec);
				addSec = U.getSectionValue(addSec, "<p>", "<a").replace("St. Cloud FL", "St. Cloud, FL")
						.replaceAll("In Polk County at:|<br />|\\(", "");
				add = U.getAddress(addSec);
				
			}
		U.log(Arrays.toString(add));
		latlong[0] = U.getSectionValue(html, "data-lat=\"", "\"");
		latlong[1] = U.getSectionValue(html, "data-lng=\"", "\"");
		
		
		if(add[0]==null || add[0]==ALLOW_BLANK && latlong[0]!=null) {
			add = U.getAddressGoogleApi(latlong);
			Geo = "TURE";
		}
		if(latlong[0]==null) {
			latlong = U.getlatlongGoogleApi(add);
			Geo = "TURE";
		}
		U.log(Arrays.toString(latlong));
		
		//======== Floor Plans =================
		String[] floorSec = U.getValues(html, "<div style=\"position:relative\">", "</div>");
		String floorData = ALLOW_BLANK;
		for(String floor : floorSec) {
			
			floorData += U.getSectionValue(U.getHTML(U.getSectionValue(floor, "<a href=\"", "\"")),"<!--Home Details-->", "<!-- container -->");
		}
		
		// ======== Floor Plans =================
		String[] homeSec = U.getValues(html, "<div style=position:relative>", "</div>");
		String homeData = ALLOW_BLANK;
		for (String home : homeSec) {

			homeData += U.getSectionValue(U.getHTML(U.getSectionValue(home, "<a href=\"", "\"")),
					"<!--Home Details-->", "<!-- container -->");
		}
		
		
		//======= Price =====================================
		html = html.replaceAll("the \\$\\d+s\\.\"", "").replaceAll("0s", "0,000");
		String[] price = U.getPrices(html + com + floorData + homeData,
				"start in the low-\\$\\d{3},\\d{3}|The \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</div>|from \\$\\d{3},\\d{3}</div>|\\$\\d{3},\\d{3}</h3>", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		//====== Sqft =======================================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft= U.getSqareFeet(html+ com + floorData + homeData,
					"from \\d,\\d{3}-\\d,\\d{3} square feet|>\\d{4} SqFt</p>|SqFt: <strong>\\d{4}</strong>", 0);	
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//======== ComType =============
		String commType = U.getCommType(html + com);
		U.log("commType: "+commType);
		
		//======== PropType =============
		String propType = U.getPropType(html + com + floorData + homeData);
		U.log("propType: " + propType);
		
		//======== DPropType =============
		String dpType = U.getdCommType(html + com + floorData + homeData);
		U.log("dpType: " + dpType);
		
		//======== DPropType =============
		html = html.replaceAll("\"Now Selling|<p>SOLD OUT</p></div>-->|Coming Soon\\)</a>|beautiful enclave of 12 available homesites", "");
		String commStatus = U.getPropStatus(html + com);
		U.log("commStatus: " + commStatus);
		
		if(comUrl.contains("https://www.avexhomes.com/wiregrass"))commStatus+=", Now Open";
		//=============================================================
		data.addCommunity(comName.trim(), comUrl, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), Geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));
	}

	//TODO:
	public void addDetails(String url, String sec) throws Exception {
		
//		if(j>=11 && j<=20)
//		if(j>=21 && j<=30)
//		if(j>31 && j<=40)
//		if(j>41 && j<=50)
//		if(j<=10)
		
//		if(!url.contains("https://www.stanleymartin.com/florida/orlando/kissimmee/poinciana")) return;	
		
		{
		
		
		if (url.equals("https://www.stanleymartin.com#overview") || 
				url.contains("https://www.stanleymartin.com/north-carolina/coastal-carolinas/southport/st-james-plantation")) {
			LOGGER.AddCommunityUrl(url + "===return=====");
			return;
		}
		if (url.contains("https://www.stanleymartin.com/virginia/northern-virginia/chantilly/the-retreat-at-poland-hill")) {
			LOGGER.AddCommunityUrl("-------return--community not found-----" + url);
			return;
		}
		
//		if (url.equals("https://www.stanleymartin.com/south-carolina/aiken-north-augusta/harlem/hickory-woods")) {
//			LOGGER.AddCommunityUrl(url + "===> Repeated Community has been redirect, '/' is added at end of URL");
//			return;
//		}

		String comurl = url;
		if (data.communityUrlExists(comurl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comurl);
			return;
		}
		
		
		
		LOGGER.AddCommunityUrl("communityurl::::::::" + url);
		
		String html = U.getHTML(comurl);
		U.log(U.getCache(comurl));
		
		
		//U.log("SEC: "+sec);
		
		U.log(comurl + "=======" + j);
		String remSec=null;
		String[] rem=U.getValues(html, "title=\"Homebuyer Resources\">", "What's Inside Our Homes");
//		U.log(">>>>>rem.length>>>>>>>"+rem.length);
		for(String remove : rem) {
//			U.log(">>>>>>>>>>>>"+remove);
//			remSec=remSec+remove;
			html=html.replace(remove,"");
		}

		
		html=html.replace("<h1 class=\"pl-0 pt-3\">", "<h1>");
		String commname = U.getSectionValue(html, "<h1>", "</h1>").trim();
		if(commname==null)
			commname = U.getSectionValue(html, "<h1 class=\"pl-0\">", "<").trim();
		commname=commname.replace("West Village at Avalon Park Orlando","West Village at Avalon Park");
		U.log("commname: "+commname);

		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";

		
		String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latlagsec=U.getSectionValue(html, "title=\"Address\" href=\"https://www.google.com/maps", "\"");
		if(latlagsec==null) latlagsec=U.getSectionValue(sec, "<iframe src=\"www.google.com/maps/embed?pb=", "\"");
		
		String addresssec = "";

		String sec1 = ALLOW_BLANK;

		if (html.contains("fas fa-map-marker-alt fa-2x mb-2")) {
			sec1 = U.getSectionValue(html, "<i class=\"fas fa-map-marker-alt fa-2x mb-2\">",
					"<div class=\"col-sm-12 col-md-4 d-flex\">").replace("Unit A, <br />", "");
		}
		
		if (sec1 != null && sec1 != ALLOW_BLANK && add[0]==ALLOW_BLANK) {
			addresssec = U.getSectionValue(sec1, "</div>", "</a>").trim();
			U.log(">>>>>>>>"+addresssec);
			addresssec=addresssec.replace(",, <br />",  ", ");
			
			String address[] = addresssec.split(",");
			add[0] = address[0];
			add[0] = add[0].replace("Holly Spring Lane and Bull Run Post Office Road", "Holly Spring Lane");
			
			add[1] = address[1].replace("Wesley Chapel FL","Wesley Chapel" ).replace("<br />", "").trim();
			String statezip[] = address[2].split(" ");
			U.log(statezip.length);
			U.log(Arrays.toString(statezip));
			add[2] = statezip[1];
			add[3] = statezip[2];
			U.log("addresssec: "+addresssec);
		}
		if (html.contains("<i class=\"fas fa-map-marker-alt mr-1\">")) {
			sec1 = U.getSectionValue(html, "<i class=\"fas fa-map-marker-alt mr-1\">",
					"</div>").replace("Unit A, <br />", "");
		}
		if (sec1 != null && sec1 != ALLOW_BLANK && add[0]==ALLOW_BLANK) {
			addresssec = U.getSectionValue(sec1, "</i>", "</a>").replaceAll("\\s{2,}", "").trim();
			String address[] = addresssec.split(",");
			add[0] = address[0];
			add[1] = address[1].replace("<br />", "").trim();
			add[2] = address[2];
			
			U.log(addresssec);
		}

		U.log(Arrays.toString(add));
		U.log(add.length);
		
		
		if(latlagsec!=null) {
			U.log("latlagsec ::"+latlagsec);
			latlagsec=latlagsec.replace("-+Woodcreek+Crossing", "").replace("-+Club+", "").replace("-+Northside", "").replaceAll(",\\d{4}m|,\\d{3}m|,\\d{2}z|,\\d{2}.\\d{2}z", "");
			latlong[0]=U.getSectionValue(latlagsec, "/@", ",");
			latlong[1]="-"+U.getSectionValue(latlagsec, "-", "/");
			
			if(latlong[0] == null || latlong[1] == null){
				latlong[0] = Util.match(latlagsec, "!2d(-\\d{2}\\.\\d{3,})!3d(\\d{2}\\.\\d{3,})!2m", 2);
				latlong[1] = Util.match(latlagsec, "!2d(-\\d{2}\\.\\d{3,})!3d(\\d{2}\\.\\d{3,})!2m", 1);						
			}
			
			
			if(latlong[0] == null || latlong[1] == null){
				latlong[0] = U.getSectionValue(latlagsec, "/search/", ",");
				latlong[1] = U.getSectionValue(latlagsec, "+", "?");
			}
			U.log("latlong ::"+Arrays.toString(latlong));

		}
		
		if(url.equals("https://www.stanleymartin.com/florida/orlando/kissimmee/poinciana")) {
			
			String regionData = U.getHTML("https://www.stanleymartin.com/florida/orlando");
			latlagsec=U.getSectionValue(regionData, "\"title\": 'Poinciana'", "\"description\"");
			
			U.log("latlagsec: "+latlagsec);
			
			latlong[0]=U.getSectionValue(latlagsec, "\"lat\": '", "',");
			latlong[1]=U.getSectionValue(latlagsec, "\"lng\": '", "',");
			U.log("latlong here: "+Arrays.toString(latlong));
		}
		
		if((add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && add[2]==ALLOW_BLANK && add[3]==ALLOW_BLANK) && (latlong[0]==ALLOW_BLANK && latlong[1]==ALLOW_BLANK)) {
			if(url.contains("oldfield") && url.contains("south-carolina")) {
				add[1]="Oldfield";
				add[2]="SC";
				latlong=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlong);
				geo="TRUE";
			}
			if(url.contains("kelton-station") && url.contains("virginia")) {
				add[1]="Kelton Station";
				add[2]="VA";
				latlong=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlong);
				geo="TRUE";
			}
			
		}
		if(latlong[0]==null || latlong[1]==null ) {
			U.log("found");
			latlong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		
		if((add[0]!=null && add[0]!=ALLOW_BLANK) && (latlong[0]==null || latlong[0]==ALLOW_BLANK)) {
			latlong = U.getlatlongGoogleApi(add);
			geo = "True";
		}
		if(add[3]==ALLOW_BLANK&& latlong[0]!=null) {
			add[3] = U.getAddressGoogleApi(latlong)[3];
			geo = "True";
		}
		
		latlong[1] = latlong[1].replace("-78.2427154,18.3z", "-78.2427154");
		
		if(url.contains("/northern-virginia/centreville/the-reserve-at-holly-springs"))
			latlong[1] ="-77.5174327";
		
//		U.log(latlong.length);
//		U.log(latlagsec);
		
		U.log("latlong ::"+Arrays.toString(latlong));
		
		U.log("GEO: " + geo);
		
		//========= homes data section
		String homedesc="";
		String homesDataPrices = ALLOW_BLANK;
		try {
		String []homedesignurls=U.getValues(html, "<li class=\"border bg-white h-auto\">", "</li>");
		for(String homeSec:homedesignurls) {
			String homeurl="https://www.stanleymartin.com/"+U.getSectionValue(homeSec, "<a href=\"", "\"");
			U.log("homeurl: "+homeurl);
			String homehtml=U.getHTML(homeurl);
			homesDataPrices += homehtml;
			homedesc+=U.getSectionValue(homehtml, "<section id=\"gallery\"", "</section>")+U.getSectionValue(homehtml, "<section class=\"section-body", "</section>");
		}
		}
		catch(NullPointerException ne) {
			
		}

		/// homes section
		String prisec1 = "";
		String prisec2 = "";

		String homepricesec[] = U.getValues(html,
				"<span class=\"community-title mt-0 text-success text-right font-weight-bold\">", "</span>");
		String movepricesec[] = U.getValues(html,
				"<span class=\"community-title text-success text-right font-weight-bold\">", "</span>");
		U.log("homepricesec::::"+homepricesec.length);
		for (String psec1 : homepricesec) {
			prisec1 += "," + psec1.trim();
		}

		for (String psec2 : movepricesec) {
			prisec2 += "," + psec2.trim();
		}

		U.log(prisec1 + "=====" + prisec2);
		String descSec="";
		descSec=U.getSectionValue(html, "my-auto text-white", "gallery-tabs d-flex col-sm-12 col-lg-6 order-sm-2 order-lg-2 p-0");
		descSec += U.getSectionValue(html, "<div id=\"greeeting\"", "</div");
		descSec +=U.getSectionValue(html, "<div class=\"card d-block d-md-none" , "</p>");
		
		
//		U.log("descSec:::::::::::"+descSec);
		
		if(descSec!=null) {
		descSec=descSec.replace("0s", "0,000");
		descSec=descSec.replace("upper $300&#39;s", "upper $300,000");
		}
		
		String pSec1="";
		pSec1=U.getSectionValue(html, "d-flex justify-content-sm-start justify-content-lg-end h4 pt-3 font-weight-bold", "</div>");
//		U.log("sec============"+sec);
	
		//improper price values
		homesDataPrices = homesDataPrices.replaceAll("Base Price </div><div class='col font-weight-bold text-right'>\\$\\d{3},\\d{3}</div>","");
		
		String priceSecLeft = ALLOW_BLANK;
		priceSecLeft = U.getSectionValue(html, "<strong>", "</strong>");
		
		if(priceSecLeft != null) {
			priceSecLeft = priceSecLeft.replace("starting in the mid $300s", "starting in the mid $300,000")
					.replaceAll("00s|00Ks", "00,000");
		}
		
		
		descSec = descSec.replace("$1.2Ms", "$1,200,000").replace("$1.1Ms", "$1,100,000").replace("$1.1M", "$1,100,000")
				.replaceAll("<span class=\"home-price\">\\s+$331,205", "$331,205");
		
		String[] prices = U.getPrices((prisec1 + prisec2+descSec+pSec1+sec + homesDataPrices +priceSecLeft).replaceAll("00Ks", "00,000"), 
				"upper \\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|Priced From:</b><span class='text-success font-weight-bold'> \\$\\d+,\\d+|\\$\\d{3},\\d{3}|,\\$\\d{3},\\d{3}", 0);

		String minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		String maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log(Arrays.toString(prices));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(prisec1 + prisec2+descSec+pSec1+sec + homesDataPrices +priceSecLeft, "[\\s\\w\\W]{10}331[\\s\\w\\W]{10}", 0));

		html = html.replaceAll("<span class=\"font-weight-bold\">\\s+(\\d{4})\\s+</span>\\s+<span class=\"w-100 float-right\">\\s+Sq. Ft.\\s+</span>", "<span>$1 Sq. Ft.</span>")
				.replaceAll("<span class=\"font-weight-bold\">\\s+(\\d,\\d{3})\\s+-\\s+(\\d,\\d{3})\\s+</span>\\s+<span class=\"w-100 float-right\">\\s+Sq. Ft.\\s+</span>", "<span>$1-$2 Sq. Ft.</span>");
		
		
		String ssec = "";
		try {
			String sqftsec[] = U.getValues(html, "<span class=\"font-weight-bold\">",
					"<span class=\"w-100 float-right\">");

			for (String sq : sqftsec) {
				sq = sq.replace(" ", "");
				ssec += sq+"sq.ft";
			}
		} catch (NullPointerException ne) {
		}
//		 U.log("ssec"+ssec);
		

		
		if(descSec!=null) {
		descSec=descSec.replace("starting from 2700+ square feet", "2,700");
		}
		String sqSec1="";
		
		sqSec1	=U.getSectionValue(html, "d-flex align-self-center justify-content-center text-white text-center", "Sq. Ft");
		
		
		
//		sqft = U.getSqareFeet((ssec+descSec+sqSec1).replace("rgba(255,255,255,0)", ""), "\\d{3}-\\d{4} square feet|Max \\d{1},\\d{3}|Min \\d{1},\\d{3}|\\d{1},\\d{3} - \\d{1},\\d{3}|\\d{1},\\d{3}|\\d{2},\\d{3}", 0);
		descSec=descSec.replace("starting from 1963+ square feet", "starting from 1963 square feet").replace("from 1,400 &ndash; 2,850 sq. ft.", " from 1,400 – 2,850 sq. ft.");
		
		String descSec2=U.getSectionValue(html, "<div class=\"h3 text-uppercase font-weight-bold text-blue\">", " <div class=\"tab-content\">");
		
		// ========================== SQuare FEETS ============================
		html = html.replaceAll("sqftNumber\">\\s+(\\d{4})\\s+</span>", " $1 Sq. Ft. ");
		
		
		String[] sqft = U.getSqareFeet((html + homesDataPrices)
				.replace("starting from 2700+ square feet", "starting from 2700 square feet"),
				"\\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} square feet|almost \\d,\\d{3} sq ft|\\d{4} Sq. Ft.|up to \\d,\\d{3} sq ft and a \\d,\\d{3} sq ft|from \\d,\\d{3}\\+ sq ft|up to \\d,\\d{3} sq. ft.|\\d,\\d{3} sq.ft. |from \\d,\\d{3} &ndash; \\d,\\d{3} sq. ft.|<span>\\d,\\d{3}-\\d,\\d{3} Sq. Ft.</span>|<span>\\d{4} Sq. Ft.</span>| range from \\d,\\d+-\\d,\\d+ square feet|from over \\d,\\d+ to over \\d,\\d+ square feet |starting from \\d{4}\\+ square feet|from \\d,\\d+-\\d,\\d+ square feet|\\d,\\d+ – \\d,\\d+ sq. ft.|starting from \\d+ square feet|\\d,\\d{3} square feet|from \\d,\\d{3} to over \\d,\\d{3} square feet|starting from \\d+\\+ sq ft|up to \\d,\\d{3}\\+ square feet|from \\d,\\d{3} - \\d,\\d{3} square feet|starting at \\d,\\d{3} sq ft|from \\d,\\d{3} square feet to almost \\d,\\d{3} square feet|\\d{4}\n\\s*</span>\n\\s*sq.ft|\\d{1},\\d{3}\n\\s*</span>\n\\s*sq.ft|sq.ft\n\\s*\\d{1},\\d{3}\n\\s*-\n\\s*\\d{1},\\d{3}" , 0);
		
//		U.log("descSec2:::::::"+descSec2);
		

		String minsqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		String maxsqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		U.log("minsqft :"+minsqft+"\t"+maxsqft);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}1498[\\s\\w\\W]{30}", 0));
		
		html = U.removeSectionValue(html, "<head>", "</head>");
		html = html.replace(" Barr Lake community", "").replace("Enjoy the comfort you expect with the luxury you deserve", "Enjoy the comfort you expect with the luxury homes you deserve");
		
		
		String ctype = U.getCommType(html.replace("Masterfully crafted", "master-planned amenities")
				.replace("acre waterfront and wooded homesites", "acre waterfront community and wooded homesites"));
		U.log("ctype: "+ctype);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}riverfront[\\s\\w\\W]{30}", 0));
		
		String ptype = U.getPropType(html.replace("Executive-style four-side brick homes", "Executive-style homes"));
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}Cabin[\\s\\w\\W]{30}", 0));
		U.log("ptype: "+ptype);
		
	
		
		if(homedesc!=null)
			homedesc = homedesc.replace("second level is home to another full bath", " Story 2 level is home to another full bath");
		
		html = html.replace("new two-level condo home designs", "new two-story condo home designs");
		
		String dtype = U.getdCommType(html+homedesc.replace("one-story", "1 Story"));
		U.log("dtype: "+dtype);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homedesc, "[\\s\\w\\W]{30}\\$244,[\\s\\w\\W]{30}", 0));
		
		html = html.replace("Only FIVE home sites remain", "Only five home sites remain")
				.replace("NEW PHASE COMING IN SUMMER 2021", "NEW PHASE COMING SUMMER 2021").replace("PHASE 1 IS SOLD OUT", "PHASE 1 SOLD OUT").replace("Section 1 of Pleasant Green is now Sold Out", "Section 1 now Sold Out").replace("New Section of Homes Coming Soon", "New Section Coming Soon").replace("<h3>Only ONE Homesite Remains</h3>", "only one homesite remains")
				.replaceAll(
						"\\d Quick Move-[i|I]n|is now open at Westside|is now open at Shipley| The Kaye, is now open|alt=\"New Section Coming Soon\"|New single-family homesites coming soon|Cabana- Now Open|final Quick Move-in|We have (<strong>)?Quick Move-in|Designer Inspired Quick Move-in|having any homesites available|Town Center\\(coming soon!\\)|having home sites available until June|New Villa Design Coming Soon|having home sites available for 3 or more months|title=\"Move-In-Ready\">|mir = \"Move-In-Ready\"|block rounded-0 mt-2\">Move-In-Ready|River - coming soon|<a href=\"/move-in-ready\" title=\"Move-In-Ready\"|meeting rooms will be opening soon|Amenities are now open|The Woodward Single Family are now open|Holy Cow - now open!|entertainment- coming soon|near the grand opening of our townhome model|Subway and more coming soon|current close out neighborhood|coming soon&nbsp;|coming Spring 2020</li>|grand opening of our models|alt=\"Pre-Construction Pricing!\"|pre-grand opening incentives|<em>New Section Coming Soon!</em>",
						"");

		 
		String statusSec = ALLOW_BLANK; 
		statusSec=U.getSectionValue(html, "<em>", "</em>");
		
		if(statusSec==null) {
			statusSec=U.getSectionValue(html, "<strong>", "</strong>");
		}
		U.log("statusSec ::"+statusSec);
		int quickcount=0;
		String quickSec=U.getSectionValue(html, "<div id=\"Content_MoveInReadyGrid_SitePagePanel\">", "In The Area");
		String[] quickData=U.getValues(quickSec, "<div class=\"col-lg-8 col-xs-12\">", "Bathrooms") ;
		for(String quickdata : quickData) {
			
			quickcount++;
		}
		U.log("quickcount:::::::"+quickcount);
		String statusSec2 = null;
//		if(quickcount>0)
//		{
//			statusSec2 = statusSec + "Quick Move-In";
//		}
//		U.log("sec:::::::"+sec);

//		U.log("sec ::"+sec);
		sec = sec.replaceAll("[q|Q]uick [m|M]ove|move-in villa homes|#ec008c;'>Sold Out</span>", "");
		html=html.replace("&#39", "")
				.replaceAll("home</a> is now available|homes are now available|es/PT/SoldOut.jpg\">|eventCategory: ;Move-In-Ready;|;HD Move-in-ready Tab Clicks;|fa-clock fa-2x mb-2\"></i>\n\\s*</div>\n\\s*Sold Out\n\\s*</div>", "");
		
		html=html.replace("New Section Coming Soon!", "New Section Coming Soon").replace("Section 1 of Pleasant Green is now Sold Out", "Section 1 Sold Out")
				.replace("new phase of homesites coming Spring 2022", "new phase homesites coming Spring 2022")
				.replaceAll("Peachtree, coming|townhomes coming soon to Lawrenceville|fa-clock fa-2x mb-2\"></i>\\s+</div>\\s+Coming Soon|Pines coming in 2022|>Dillard Pointe is coming soon!<", "");

		
//	U.log("sec:::::::"+sec);
	String pstatus = U.getPropStatus( (html+statusSec+sec).replace("newest section at Wildewood is NOW SELLING", "Now Selling Our Newest Section")
			.replace("Dillard Pointe is coming soon", "coming soon Dillard Pointe")
			.replace("(Coming Soon)", "")
			.replace("and townhomes coming soon to Lawrenceville", "and townhomes to Lawrenceville")
			.replace("Phase 2, coming early 2022", "Phase 2 coming early 2022")
				.replaceAll("enclave of 12 available homesites located|Place are now open|Models are now open|Summer Move-Ins Now Available|Summer Move-ins Now Available|aisie are now available to tour|of Condos Just Released|about our coming soon neighbor|Dillard Pointe is coming soon!|entertainment- coming soon|The Kendry</a>, is coming soon|Tours Now Available|Unfinished Basements Available|do not have waterfront homesites|[q|Q]uick [m|M]ove|virtual appointment to learn more about our last remaining homes|Wildewood Landing is Coming Soon!|move-in homes (offering|is now open at Westside|only 2 homes remain with homesites|of materials)|title=\"Quick Move-In\"|Quick Move-In|alt=\"Sold | alt=\"New Phase Now Selling\" |New Villa Design Coming Soon","")
				.replace("New Phase Coming Soon!", "New Phase Coming Soon").replace("Section 1 now Sold Out", "Section 1 Sold Out")
				.replace("new phase of homesites coming December 2021", "new phase coming December 2021")
				.replace("New Section of Homesites Coming Soon", "New Section Homesites Coming Soon")
				.replace("Phase 2, coming this Fall", "Phase 2 coming this Fall").replace("Our newest section, Wildewood Landing, is coming soon!", "New Section Coming Soon")
				.replace("New homesites are now available", "New homesites now available")
				.replace("A new phase of homesites coming December 2021", "New phase homesites coming December 2021")
				.replaceAll("Hard Hat Tours Now Available|fr-fic fr-dii\" alt=\"Now Selling\"|Jackson Model home</a> is now available for leaseback|Our Jackson Model home is now available for leaseback|about our last remaining home|[q|Q]uick [m|M]ove|fas fa-clock fa-2x mb-2\"></i>\n\\s*</div>\n\\s*Coming Soon", "")
				.replace("We have just released our last home","Last Home Just Released")
				.replace("A new section of the popular President&#39;s Pointe neighborhood is coming in mid-2022", "A new section coming mid 2022")); 
	
	pstatus=pstatus.replace("Coming Spring 2022, Opening Spring 2022, Coming Soon","Coming Spring 2022, Opening Spring 2022");
    pstatus=pstatus.replace("New Homesites Coming Soon, Coming Soon, New Phase Now Selling","New Homesites Coming Soon, New Phase Now Selling");
		
    U.log("pstatus: "+pstatus);

		if(url.contains("maryland/lanham/glenn-dale-commons")) {
			if(pstatus.length()>1)
			pstatus+=", New Section Coming Soon";
			else
				pstatus="New Section Coming Soon";
		}
	

		/*
		 * from region page images
		 */
		if(url.contains("/charleston/mount-pleasant/bridgeview")
						||url.contains("/apex/woodhall")||url.contains("charleston/the-cove-at-folly")) 
		{
			
			if(pstatus.length()<2)pstatus="Final Opportunities";
			else pstatus=pstatus+", Final Opportunities";
		}
		
		/*
		 * from region page images dt 20Aug21
		 */
		
		if(url.contains("https://www.stanleymartin.com/south-carolina/charleston/charleston/the-cove-at-folly"))ctype="Waterfront Community";
		if(url.contains("https://www.stanleymartin.com/virginia/charlottesville/crozet/pleasant-green"))pstatus="Section 2 Coming Soon, Sold Out";
		
//		if(quickcount>0) {
//			if(pstatus == ALLOW_BLANK)
//				pstatus = "Quick Move-In";
//			else if(pstatus != ALLOW_BLANK && !pstatus.contains("Quick Move"))
//				pstatus = pstatus + ", Quick Move-In";	
//		}
//		pstatus = pstatus.replace("Quick Move-in", "Quick Move-In");
		
		U.log("pstatus::::::::"+pstatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+statusSec+sec+statusSec2, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+statusSec+sec, "[\\s\\w\\W]{30}Available Homesites[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+statusSec+sec, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));
	
		if (ctype == null)	ctype = ALLOW_BLANK;
		
		if(ptype.contains("Townhouse") && ptype.contains("Townhome")) {
			ptype=ptype.replace("Townhomes", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
		}
//		U.log(ptype);

	 String HTML=U.getHTML(comurl);
	 String quicksec=U.getSectionValue(HTML, "<div id=\"Content_MoveInReadyGrid_SitePagePanel\">", "<div class=\"h3 text-uppercase font-weight-bold text-blue\">\n" + 
	 		"							In The Area");
	 if(quicksec==null)quicksec=ALLOW_BLANK;;
	 String QuickHomes[]=U.getValues(quicksec, "<a class=\"community-title\" ", " <span class=\"w-100 float-right\">\n" + 
	 		"																	Bathrooms");
	 U.log(QuickHomes.length);
	 if(QuickHomes.length>0)
	 {
		 if(pstatus.length()>2)
		 {
			 pstatus=pstatus+", Quick Move-In";
		 }
		 else
			 pstatus="Quick Move-In"; 
	 }
				
//		if(url.contains("/waldorf/bensville-crossing"))
//		{
//			if(pstatus.length()>2)
//			 {
//				 pstatus=pstatus+", Only One Home Remains";
//			 }
//			 else
//				 pstatus="Only One Home Remains";
//		}
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		int lotCount = 0;
		String frameUrl = ALLOW_BLANK;
		String gmtDate_1 = getDateInGMT(); //important parameter to fetch data
		U.log("gmtDate: "+gmtDate_1);
		
		if(html.contains("<iframe id=\"planFrame")) {
			
			String iframeSec = U.getSectionValue(html, "<iframe id=\"planFrame", "</iframe>");
			U.log("iframeSec: "+iframeSec);
			
			frameUrl = U.getSectionValue(iframeSec, "src=\"", "\"");
			U.log("frameUrl: "+frameUrl);
			
//			String[] frameIds = frameUrl.split("/");
//			U.log("frameIds[5]: "+frameIds[4]);
//			U.log("frameIds[7]: "+frameIds[6]);
//			
//			String countLink = "";
			
			
			String comId = U.getSectionValue(frameUrl, "com/scp/", "/site-map");
			U.log("comId: "+comId);
			
			String jsonLink = "https://argo.ml3ds-cloud.com/api/communities/"+ comId +"?dataLevel=2&filterToActiveOnly=true";
			U.log("jsonLink: "+jsonLink);
			
			String gmtDate = getDateInGMT(); //important parameter to fetch data
			U.log("gmtDate: "+gmtDate);
			
			String jsonHtml = getHTML(jsonLink, gmtDate);
			//U.log("jsonHtml: "+jsonHtml);
			//FileUtil.writeAllText("/home/shatam-10/Desktop/json.txt", jsonHtml);
			
			if(jsonHtml != null) {
				
				JsonParser json = new JsonParser();
				JsonObject jsonObj = (JsonObject) json.parse(jsonHtml);
				//U.log("jsonObj: "+jsonObj);
				
				JsonArray lots = new JsonArray();
				JsonArray neighbourhoods = new JsonArray();
				
				neighbourhoods = (JsonArray) jsonObj.get("Neighborhoods");
				
				for(int i=0; i<neighbourhoods.size(); i++) {
					
					String lotts = neighbourhoods.get(i).toString();
					//U.log("lotts: "+lotts);
					
					JsonObject lotObj = (JsonObject) json.parse(lotts);
					lots = (JsonArray) lotObj.get("Lots");
					//U.log("lotObj: "+lotObj.toString());
					U.log("lots: "+lots.size());
					
					lotCount = lotCount + lots.size();
				}
			}

		}
		
		U.log("lotCount: "+lotCount);
		if(units.equals("0")) units = ALLOW_BLANK; 
		
		units = String.valueOf(lotCount);
				
		latlong[1]=latlong[1].replace(",12540m", "");
		//from img 19 march dattaraj
		if(url.contains("https://www.stanleymartin.com/west-virginia/west-virginia/ranson/presidents-pointe")) pstatus = "New Phase, " + pstatus;
				
		
		
		data.addCommunity(commname.trim(), url, ctype);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
		data.addPropertyType(ptype, dtype.replace("1.5 Story, 5 Story", "1.5 Story"));
		data.addPropertyStatus(pstatus); 
		data.addNotes(U.getnote(html));
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		
		
		}
		j++;

	
	}
	
	public static String getHTML(String path, String gmtDate) throws IOException {

		path = path.replaceAll(" ", "%20");

		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);
		U.log(url);
		String html = null;

		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"104.149.3.3", 8080));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "*/*");
			urlConnection.addRequestProperty("Authorization", "converge.apiuser@medialabinc.local EeijmiWeuJsxA4gl51i+8kejSyTHQ8/XVUfvYEAS6KA=");
			//urlConnection.addRequestProperty("x-ml-date", gmtDate);
			urlConnection.addRequestProperty("x-ml-date", "Fri, 17 Jun 2022 08:05:15 GMT");
			urlConnection.addRequestProperty("Accept-Language", "en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Access-Control-Request-Method", "GET");
			urlConnection.addRequestProperty("Referer", "https://myscp.ml3ds-iconstage.com/");
			urlConnection.addRequestProperty("Sec-Fetch-Site", "cross-site");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			urlConnection.addRequestProperty("Access-Control-Request-Headers", "authorization,x-ml-date");

			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);

			inputStream.close();
			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
	}
	
	public static String getDateInGMT() {
		
		String formattedDate = ALLOW_BLANK;
		
		final Date currentTime = new Date();
		//U.log("currentTime: "+currentTime);
		
		final SimpleDateFormat sdf =
		        new SimpleDateFormat("EEE, dd MMM yyyy hh:mm:ss z");
		
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		System.out.println("GMT time: " + sdf.format(currentTime));
		
		//U.log("sdf: "+sdf.format(currentTime));
		
		formattedDate = sdf.format(currentTime);
		
		return formattedDate;
	}
}
	
	// ---------------- Number of units with selenium --------------------------
//	String driverHtml = ALLOW_BLANK;
//	int countOfUnits = 0;
//	
//	if(frameUrl != null) {
//		driverHtml = U.getHtml(frameUrl, driver);
//		U.log(U.getCache(frameUrl));
//		
//		if(driverHtml != null) {
//			
//			if(driverHtml.contains("<path fill=\"#a98687")) {
//				String[] pathOne = U.getValues(driverHtml, "<polygon style=\"fill:#FFFFFF;stroke:#000000", "stroke");
//				U.log("pathOne: "+pathOne.length);
//				countOfUnits = countOfUnits + pathOne.length;
//			}
//			
//			if(driverHtml.contains("<path fill=\"#a98687")) {
//				String[] pathTwo = U.getValues(driverHtml, "<path style=\"fill:#FFFFFF;stroke:#000000", "stroke");
//				U.log("pathTwo: "+pathTwo.length);
//				countOfUnits = countOfUnits + pathTwo.length;
//			}
//			
//			if(driverHtml.contains("<polygon style=\"fill:#FFFFFF;stroke:#303030")) {
//				String[] pathThree = U.getValues(driverHtml, "<polygon style=\"fill:#FFFFFF;stroke:#303030", "stroke");
//				U.log("pathThree: "+pathThree.length);
//				countOfUnits = countOfUnits + pathThree.length;
//			}
//			
//			if(driverHtml.contains("<path style=\"fill:#FFFFFF;stroke:#303030")) {
//				String[] pathFour = U.getValues(driverHtml, "<path style=\"fill:#FFFFFF;stroke:#303030", "stroke");
//				U.log("pathFour: "+pathFour.length);
//				countOfUnits = countOfUnits + pathFour.length;
//			}
//			
//			if(driverHtml.contains("<path style=\"fill: rgb(236, 0, 140)")) {
//				String[] pathFive = U.getValues(driverHtml, "<path style=\"fill: rgb(236, 0, 140)", "stroke");
//				U.log("pathFive: "+pathFive.length);
//				countOfUnits = countOfUnits + pathFive.length;
//			}
//			
//			if(driverHtml.contains("<polygon style=\"fill: rgb(236, 0, 140)")) {
//				String[] pathSix = U.getValues(driverHtml, "<polygon style=\"fill: rgb(236, 0, 140)", "stroke");
//				U.log("pathSix: "+pathSix.length);
//				countOfUnits = countOfUnits + pathSix.length;
//			}
//			
//		}
//	}
//	
//	units = String.valueOf(countOfUnits);
//	U.log("Total Units: "+units);
	

