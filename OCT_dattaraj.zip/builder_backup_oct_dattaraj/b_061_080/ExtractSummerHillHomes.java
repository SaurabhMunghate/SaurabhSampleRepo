package com.shatam.b_061_080;

import java_cup.runtime.virtual_parse_stack;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSummerHillHomes extends AbstractScrapper {

	WebDriver driver=null;
	CommunityLogger LOGGER;
	int j=0;
	public ExtractSummerHillHomes()throws Exception {
		super("SummerHill Homes","https://www.summerhillhomes.com/");
		LOGGER = new CommunityLogger("SummerHill Homes");
	}
	HashMap<String, String>homesDataMap=new HashMap<>();
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractSummerHillHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"SummerHill Homes.csv", a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		
		
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String mainHtml=U.getHtml("https://www.summerhillhomes.com/community-list", driver);
		//U.log("html:-->"+mainHtml);
		String homesReadyhtml=U.getHtml("https://www.summerhillhomes.com/homes-now-ready", driver);
//		U.log(homesReadyhtml);
		String homesData[]=U.getValues(homesReadyhtml, "<div class=\"col-sm-12 available-now-info", "</div><!-- end ngRepeat: home in community");
		U.log("homesData length: "+homesData.length);
		if(homesData.length != 0) { 
			for (String home : homesData) {
				String communityname=U.getSectionValue(home, "<b class=\"ng-binding\">", "</b><br>");
				U.log("COMMUNITY NAME: "+communityname);
				homesDataMap.put(communityname, home);
			}
		}
		
		U.log("HELLO ALL");
		String[] comSec=U.getValues(mainHtml, "\"col-xs-12 col-sm-6 col-md-4 col-lg-4 ng-scope\"","end ngRepeat: community in communities");
		U.log(comSec.length);
		for(String val:comSec)
		{	
			//U.log("VAL DATA: "+val);
			String url="https://www.summerhillhomes.com"+U.getSectionValue(val, " href=\"","\"");
			U.log("URL:--->"+url);
			addCommunity(url,val);
		}
		LOGGER.DisposeLogger();
		driver.close();
		try{ driver.quit();} catch(Exception e){}
		

	}

	//TODO : Exec for single community
	private void addCommunity(String url, String val) throws Exception {
		
	//if(!url.contains("https://www.summerhillhomes.com/city-village"))return;
//		if(!url.contains("https://www.summerhillhomes.com/nuevo"))return;
	
	//U.log("Val DATA: "+val);
			
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"==========repeated============");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		
		String html=U.getHtml(url, driver);
		U.log(U.getCache(url));
				
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(html, "subtitle right gray\">","</h2>");
		communityName=communityName.replace("Welcome To</span>","").replace("@", "At").replaceAll(" - Pleasanton| - Moraga| - Santa Clara| - Saratoga| - Mountain View| - Los Gatos", "");
		
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html, "<div class=\"lower-content\">","</div>").replace("OFF SITE SALES OFFICE ", "").trim().replace(".", "").replace("Street, Suite", "Street Suite");
		
	//	U.log("addSec: "+addSec);
		
		addSec = addSec.replace("<br />", ",").replace("<div class=\"box__address\">", ",");
	//	U.log("addSec: "+addSec);
		
		add=U.getAddress(addSec.replace("<br>", ","));
		
		
		U.log("address:--->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		add[0]= add[0].replace(",", "");;
		String latlngSec=U.getSectionValue(html, "community\":{\"id\"", "driving_directions");
		U.log("latlngSec::"+latlngSec);
		if(latlngSec!=null){
			latlag[0]=U.getSectionValue(latlngSec, "latitude\":\"", "\"");
			latlag[1]=U.getSectionValue(latlngSec, "longitude\":\"", "\"");
		}
		U.log("lat::"+latlag[0]+" lng::"+latlag[1]);
		if(latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if(add[3]==ALLOW_BLANK)
		{
			String add1[] = U.getAddressGoogleApi(latlag);
			if(add1 == null) add1 = U.getAddressHereApi(latlag);
			add[3] = add1[3];
			geo="TRUE";
		}
		add[0] = add[0].replace("1008 Carolan Ave, Burlingame", "1008 Carolan Ave").replace("883 N Shoreline Blvd, Suite B100", "883 N Shoreline Blvd Suite B100").replace("OFF SITE SALES OFFICE ", "");
		
		
		html = U.removeSectionValue(html, "var jsonCache =", "</script>");
		String [] floorHomeCards = U.getValues(html, "<div class=\"card-box\">", "</span>");
		for(String rem : floorHomeCards) html = html.replace(rem, "");
				
				
//============================================Price and SQ.FT======================================================================
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html=html.replaceAll("\\$80,000 TO OVER \\$100,000|(O|o)ver \\$\\d{3},\\d{3} in (u|U)pgrades|<li>\\$2,232,000</li>","");
		
		
		String prices[] = U.getPrices(html+val," Priced from the low \\$\\d,\\d{3},\\d{3}|price ng-binding\">\\$\\d,\\d{3},\\d{3}</div>|mid $\\d+,\\d+,\\d+s|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log(minPrice+"\t"+maxPrice);
//======================================================Sq.ft===========================================================================================		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		html=html.replace("4,000-square-foot community center","");
		String[] sqft = U.getSqareFeet(html+val,
						"\\d,\\d{3}-\\d,\\d{3} Sq. Ft|>\\d+ - \\d,\\d{3} sqft|>\\d+ - \\d,\\d+ sq ft|\\d{1},\\d{3}-square-foot|\\d,\\d+ to \\d,\\d+ square|\\d,\\d+ - \\d,\\d+ sq ft|\\d,\\d+ sq ft|ng-binding\">approx. (\\d,)?\\d{3} sq ft</li>",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log(minSqft+"\t"+maxSqft);
//========================remove section===========================
		String rem="MODEL HOME NOW SELLING|price_status\":\"Sold Out\"|<div class=\"price ng-binding\">Sold Out</div>|banner sold-out ng-binding ng-scope\" ng-switch-when=\"Sold Out\">Sold Out</div>|Information Coming Soon|Elongated Toilet|MODELS OPENING SOON|<a href=\"/coming-soon/|Pricing To Be Determined\">Coming Soon<|<div class=\"price ng-binding\">Temporarily Sold|banner temporarily-sold-out ng-binding ng-scope\" ng-switch-when=\"Temporarily Sold Out\">Temporarily Sold Out</div>|price_status\":\"Temporarily Sold|Temporarily Sold Out\" class=\"banner temporarily-sold-out|\"/coming-soon/| pricing-to-be-determined\">Coming Soon</div>|'coming-soon'|lower-content\">\\s+Coming Soon|ng-switch-default=\"\">Coming Soon</div>";
		html=html.replaceAll(rem, "");
		val=val.replaceAll("class=\"coming-soon-banner ng-hide\">\\s+Coming Soon","");
		html=U.removeComments(html);
		//U.log("result::"+Util.match(html, ".*?Coming Soon "));
		//U.log(html);
		
		
//================================================community type========================================================
		String communityType=U.getCommType((html+val).replace("elongated", ""));
		
//==========================================================Property Type================================================
		html = html.replaceAll("three story townhomes on Marquetta Circle and 31 three story townhomes on Thea|27 Single Family Homes - two-story homes and single level homes|FIRST SALES RELEASE COMING SOON|Condo project approval|common areas including landscaping|Common Area insurance, common area|Patio w/ Deck<|Patio</label>|shapartments|apartments.png,|patio.JPG|Covered Patio|results. HOA", "");
		html=html.replace("\"single family","");
		String html1=U.getNoHtml(html);
		html1 = html1.replaceAll("and Professional HOA Management|Yes, there will be a HOA|HOA and Taxes are subject to change|ProspectPatio|Will there be a (.*?)omeowner(.*?)s (.*?)ssociation|homeowner's association fee|fee for the Homeowner’s Association</p>|Homeowner’s AssociationQ:", "");
		//U.log(html1);
		html1=html1.replace("Yes, there will be a HOA", "").replace("ROWHOMES", "row homes")
				.replace("Flex/loft rooms with large windows", "Flex room loft rooms with large windows")
				.replace("detached three-level row homes", "detached residences three-level row homes")
				.replace("floor plans offering one, two, or three story living", "floor plans offering one-story, two-story, or three story living");
		
		String propType=U.getPropType(html1.replaceAll("/ACourtyard|Common Area Landscaping|Townhome Style Condos", "").replaceAll("The dues may cover common area landscaping|Select homes offer lofts|&amp; 4-plex condo homes|Half-hot duplex|ACourtyard|Nuevoapartment|be a Homeowner’s Association|Common Area Landscaping|Townhome Style Condos", ""));
		
		U.log("propType===="+propType);
//		U.log("SSSSSSSSSSSSSSSSSSSS"+Util.matchAll(html1, "[\\s\\w\\W]{60}rowhome[\\s\\w\\W]{30}", 0));
		
		if(propType.contains("Townhouse")){
			propType=propType.replaceAll(", Townhouse|Townhouse, |Townhouse", "");
		}
		if(propType.contains("Claasic Row Homes")){
			propType=propType.replace("Claasic Row Homes", "Row Homes, ");
		}
//		if(propType.contains(", Townhome")){
//			propType=propType.replace(", Townhome", "Townhome");
//		}	
		if(propType.contains("Luxury HomesTownhome")) {
			propType=propType.replace("Luxury HomesTownhome", " Luxury Homes, Townhome");
		  } 
		U.log("propType===="+propType);
//==================================================D-Property Type======================================================
		html = html.replaceAll("floor|Floor|Rancho", "");
		String dType=U.getdCommType(html+homesDataMap.get(communityName) + html1);
		U.log("dType===="+dType);
		
		
//==============================================Property Status=========================================================

		html = html.replace(U.getSectionValue(html, "office-hours", "contacts"), "");
		html = html.replace(U.getSectionValue(html, "<footer class=\"fixed-position\">", "</html>"), "");
		html = html.replace("Coming  Early", "Coming Early")
				.replace("PHASE 2 - COMING SOON", "PHASE 2 COMING SOON");
		html = html.replaceAll("Coming Fall/Winter 2021|View  - Sold Out|(Rowhomes|\\(SOLD OUT\\)\\s*</i>|MODEL HOMES COMING SOON|price ng-binding\">\\s*Sold Out\\s*</p>|ROWHOMES) \\(SOLD OUT\\)|\\(SOLD OUT\\)  31 |PLANS COMING MID 2019|information Coming Soon|Bellavista Now Selling Brochure|sorellas\">\\s*Sorellas \\(ONLY 1 HOME LEFT\\)|Interest List - Pre-Sale Coming Soon|class=\"banner sold-out|binding ng-scope\">Sold Out|switch-when=\"Sold Out|LOT #SOLD OUT</p>|- Coming Soon|>Coming Soon|- Coming Soon| \\(Coming Soon\\)", "");
		String pStatus= ALLOW_BLANK;
		
		val = val.replaceAll("coming-soon-banner ng-hide\" ng-show=\"community.availability == 'upcoming'\">\\s*Coming Soon", "")
				 .replaceAll("Over 90% Sold Out", "")
				 .replaceAll("Only 2 Homes Remain", "")
				 .replaceAll("E-States: SOLD OUT", "")
				 .replaceAll("E-Towns: SOLD OUT", "")
				 .replaceAll("Coming Soon", "").replaceAll("coming-soon-banner", "").replaceAll("Coming Fall/Winter 2021", "")
				  .replaceAll("<p class=\"price ng-binding\">Sold Out</p>", "");
	
//		U.log("Match====="+Util.matchAll(html,"[\\w\\s\\W]{10}Homes Ready Now[\\w\\s\\W]{10}",0));
//		U.log("Match====="+Util.matchAll(html,"[\\w\\s\\W]{10}Over 100 Homes Sold[\\w\\s\\W]{10}",0));

	
		
		pStatus = U.getPropStatus((html.replaceAll("Bellaterra: Over 110 Homes Sold|View homes ready now|>Homes Ready Now <|button\">Homes ready now|Over 100 Homes Sold|Now Selling</span>|Locations Now Selling|\"coming-soon-banner\"|E-Towns: SOLD OUT|E-States: SOLD OUT|class=\"banner temporarily-sold-out ng-binding ng-scope\">Temporarily Sold|\"Temporarily Sold Out|class=\"price ng-binding\">Temporarily Sold Out|class=\"price ng-binding\">Sold Out|LIMITED OPPORTUNITY OF ONLY 20 HOMES|MODEL HOMES COMING SOON|MOVE-IN READY HOMES, PLEASE VISIT|INFORMATION COMING|<div class=\"lower-content\">\n\\s+Coming Soon|Waverly Cove - Coming Soon|Vista - Coming Soon|North 40 - Coming Soon|STUDIO NOW OPEN|Temporarily Sold Out<|sorellas (only 1 home left)|TEMPORARILY SOLD OUT|HOMES READY NOW|Homes Ready Now|Move-in Ready|as quick move|FOR OUR MOVE-IN|\\(SOLD OUT\\)|price ng-binding\">\\s*Sold Out\\s*</p>", "")+val));
		
		if(url.contains("https://www.summerhillhomes.com/north-forty/"))pStatus="110 Homes Sold";
		if(url.contains("https://www.summerhillhomes.com/laguna-vista"))dType="1 Story, 2 Story, 3 Story";
		pStatus = pStatus.replace("Limited Presale Opportunities Now Available, Now Available", "Limited Presale Opportunities Now Available");

//		U.log(":::::::::"+Util.match(val, ".*?Coming soon.*?"));
		//String homesReadyPage= U.getHtml("https://www.summerhillhomes.com/homes-now-ready",driver);
		
//============================================note====================================================================
		if(url.contains("https://www.summerhillhomes.com/coming-soon/tanglewood"))pStatus=ALLOW_BLANK;
		if(url.contains("https://www.summerhillhomes.com/waverly-cove"))pStatus="Final Homes Now Selling";
		if(url.contains("/nuevo")|| url.contains("/towns-at-avondale"))propType=propType.replaceAll("Patio Homes, |, Common Area|Common Area, ","");
//		if(url.contains("/nuevo")|| url.contains("/towns-at-avondale")||url.contains("/north-forty")||url.contains("/locale-at-state-street"))propType=propType.replace("Condominium, ","");
		if(url.contains("/waverly-cove"))propType=propType.replace("Patio Homes, ","");
		//communityType=ALLOW_BLANK;		
		String note=U.getnote(html1);
//		FileUtil.writeAllText("/home/glady/filename.txt", html);
//		if(url.contains("https://www.summerhillhomes.com/portico"))
//			pStatus=ALLOW_BLANK;
		
		
		if(propType.contains(", Homeowner Association")) {
			propType=propType.replace(", Homeowner Association", "");
			
		}
		
		if(propType.contains("Single Family, CondominiumTownhome, Detached Home"))
			propType= "Single Family, Condominium, Townhome, Detached Home";
		
		if(communityName!=null)
		communityName = communityName.replaceAll("- Foster City|- Monte Sereno|- April 2021|, Mountain View|, Santa Clara|, Foster City", "");
		
		if(homesDataMap.containsKey(communityName)) {
			if(pStatus.length()<1) {
				pStatus ="Homes Ready Now";
			}else {
				pStatus =pStatus;
			}
			
		}
		add[0]=add[0].toLowerCase();
		
		// ------------------------- Number of Units ---------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		int lotCount=0;
		
		if(html.contains("site-plan")) {
			String siteUrl=url+"/site-plan";
			String siteHtml=U.getHtml(siteUrl, driver);
			U.log("Path:: "+U.getCache(siteUrl));
			
			String nwSiteUrlSec=U.getSectionValue(siteHtml, "<iframe class=\"embed-responsive-item\"", "</iframe>");
			if(nwSiteUrlSec!=null) {
			String nwSiteUrl=U.getSectionValue(nwSiteUrlSec, "src=\"", "\"");
			U.log("Nw Site Url::  "+nwSiteUrl);
			String siteMapHtml=U.getHtml(nwSiteUrl, driver);
			U.log("Path2:: "+U.getCache(nwSiteUrl));
			String lotData[]=U.getValues(siteMapHtml, "<g id=\"lot_", ">");
			lotCount=lotData.length;
			U.log("lotCpunt: "+lotCount);
		}
			else {
				String lotData[]=U.getValues(siteHtml,"<p class=\"lot-number\">LOT", "</p>");
				lotCount=lotData.length;
				U.log("lotCpunt: "+lotCount);
			}
			units=Integer.toString(lotCount);
			
			
		}
		if(units.equals("0"))
          units=ALLOW_BLANK;
		U.log("NO Of Units"+units);
		
		
		data.addCommunity(communityName,url, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		
		j++;
		
	}

}
