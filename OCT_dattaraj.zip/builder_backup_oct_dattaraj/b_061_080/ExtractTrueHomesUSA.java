package com.shatam.b_061_080;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractTrueHomesUSA extends AbstractScrapper {

	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.truehomesusa.com";
	WebDriver driver = null;
	int i=0;

	public static void main(String ar[]) throws Exception {

		AbstractScrapper a = new ExtractTrueHomesUSA();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"True Homes.csv", a.data().printAll());	
	}
	
	MultiValueMap allHomesData = new MultiValueMap();

	public ExtractTrueHomesUSA() throws Exception {
		super("True Homes", "https://www.truehomesusa.com");
		LOGGER = new CommunityLogger("True Homes");
	}

	public void innerProcess() throws Exception {
		long startTime = System.currentTimeMillis();
		
		//============ HomesData Quick Move Ins
		String homesHtml =getHTML("https://www.truehomesusa.com/api/home");
		U.log(U.getCache("https://www.truehomesusa.com/api/home"));
		//U.log("homesHtml: "+homesHtml);
		JsonParser jsonHomes = new JsonParser();
		JsonObject objJsonHomes = (JsonObject)jsonHomes.parse(homesHtml); 
		
		JsonArray homesArray = new JsonArray();		
		homesArray = (JsonArray)objJsonHomes.getAsJsonArray("homes");
		U.log("Total Homes: "+homesArray.size());
		
		for(int j=0; j<homesArray.size();j++) {
			String homeJson = homesArray.get(j).toString();	
			String communityId = U.getSectionValue(homeJson, "community_id\":", ",\"");
			//U.log("communityId: "+communityId);
			
			String remResidence = U.getSectionValue(homeJson, "\"residence\":", "collection\":");
			if(remResidence!=null)
			homeJson.replace(remResidence, "");
			
			String soldBanner = U.getSectionValue(homeJson, "\"banner\":", ",");  //removing homes with "sold" status
			if(soldBanner.equals("\"sold\"")) {
				continue;
			}
			//U.log("soldBanner: "+soldBanner);
			
			allHomesData.put(communityId, homeJson);
		}
		U.log("allHomesData Size: "+allHomesData.size());
//	U.log("New Size: "+allHomesData.get("254"));
		
		//============ CommunityData
		String mainHtml =getHTML("https://www.truehomesusa.com/api/menu-community");
		//U.log("mainHtml: "+mainHtml);
		JsonParser json = new JsonParser();
		JsonObject objJson = (JsonObject)json.parse(mainHtml); 
		
		JsonArray comarray = new JsonArray();		
		comarray = (JsonArray)objJson.getAsJsonArray("communities");
		U.log("Total Com: "+comarray.size());
		
		for(int i = 0; i < comarray.size(); i++) {
			String communitiesJson = comarray.get(i).toString();	
			String id = U.getSectionValue(communitiesJson, "\"id\":", ",\"");
			String name = U.getSectionValue(communitiesJson, "\"name\":\"", "\",");
			
			//For community url
			String urlSec = U.getSectionValue(communitiesJson, "collections\":", "}");
			String url = U.getSectionValue(urlSec, "\"url\":\"", "\"");
			
			  if(url == null) { 
				  urlSec = U.getSectionValue(communitiesJson, "pivot\":", "\"}"); 
				  urlSec =  urlSec + "\"}";
				  //U.log("urlSec : "+urlSec); 
				  url = U.getSectionValue(urlSec, "],\"url\":\"", "\"");
				  //U.log("url : "+url);
			  }
			 
			//U.log(" "+i+" id: "+id+"  name: "+name+"  url: "+url);
			addDetails(name, id, url);
		}
		LOGGER.DisposeLogger();
		U.log("Time Taken: "+(System.currentTimeMillis() - startTime));
	}
			 
	private void addDetails(String name, String id, String url) throws Exception {
				
		//===========Community Url
		String comUrl = builderUrl + url;
		U.log("\n\nCount: "+i);
		U.log("comUrl: "+comUrl);
		
//SINGLE EXECUTION
//		if(!comUrl.contains("https://www.truehomesusa.com/charlotte/edgewater-the-links/")) return;
		
		//============ Community Logger
		LOGGER.AddCommunityUrl(comUrl);
		
		String comHtml = getHTML("https://www.truehomesusa.com/api/community/" + id); 
		//U.log("comHtml: "+comHtml);                   //Get JSON data of community.
		U.log(U.getCache("https://www.truehomesusa.com/api/community/" + id));
		//===========Community Name
		String comName = name;
		
		if(comName != null) {
			
			comName = comName.replace("Edgewater Cottages", "Edgewater");
		}
		
		U.log("comName: "+comName);
		
		//===========Address
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		street = U.getSectionValue(comHtml, "\"address\":\"", "\"");
		if(street != null) street = street.replace("29 Manor Stone Drive Clayton, NC", "29 Manor Stone Drive");
		
		city = U.getSectionValue(comHtml, "\"city\":\"", "\"");
		state = U.getSectionValue(comHtml, "\"state\":\"", "\"");
		zip = U.getSectionValue(comHtml, "\"zip\":\"", "\"");
		
		add[0] = street; add[1] = city; add[2] = state; add[3] = zip; 
		
		U.log("ADDRESS: "+add[0]+" - "+add[1]+" - "+add[2]+" - "+add[3]+" - "+geo);
		
		if(add[0].isEmpty() && add[3].isEmpty()) {
			add[0] = ALLOW_BLANK;
			add[3] = ALLOW_BLANK;
		}
		
		//===========Lat Lng
		String lat = U.getSectionValue(comHtml, "\"latitude\":\"", "\"");
		String lon = U.getSectionValue(comHtml, "\"longitude\":\"", "\"");
		
		latLng[0] = lat;
		latLng[1] = lon;
		U.log("LatLng: "+Arrays.toString(latLng));
		
		if(add[0] == ALLOW_BLANK && add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK && latLng[0] != ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latLng);
			
			if(add==null)
				add=U.getAddressHereApi(latLng);
			geo="TRUE";
			U.log("ADDRESS GEO: "+Arrays.toString(add));
		}
		//============ Community Unique Id
		String comUniqueId = U.getSectionValue(comHtml, "\"id\":", ",\"");
		U.log("comUniqueId: "+comUniqueId);
		
		//============ HomesData
		String quickHomesData = ALLOW_BLANK;
		int homesCounter = 0;
		ArrayList<String> homeData = (ArrayList<String>) allHomesData.get(comUniqueId);
		if(homeData == null) {
			homesCounter = 0;
		}
		else {
			homesCounter = homeData.size();
		}
		
		U.log("homeData Size: "+homesCounter);
		
		if(homeData != null) {
		for(String home:homeData) {
			String removeSec = U.getSectionValue(home, "\"lot_size\"", "elevation\":");
			home = home.replace(removeSec, "");
			quickHomesData += home;
			}
		}
		
		//============ Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String remOne = U.getSectionValue(comHtml, "collections\":[", "}],");
		String remTwo = U.getSectionValue(comHtml, "collection\":", "\"},");
		
		if(remOne != null && remTwo != null) {
			comHtml = comHtml.replace(remOne, "").replace(remTwo, "").replaceAll("00's|00's|00s", "00,000");
		}
		
		comHtml = comHtml.replace("price_override\":\"From the $400,000", "");
		
		String[] price = U.getPrices(comHtml+quickHomesData, "autospecs\":\\d,\"price\":\\d{6}|Priced from the \\$\\d{3},\\d{3}|price_override\":\"From the \\$\\d{3},\\d{3}||From the Mid \\$\\d{3},\\d{3}|"
				+ "From Mid \\$\\d{3},\\d{3} - Mid \\$\\d{3}\\d{3}|From High \\$\\d{3},\\d{3}|From Low \\$\\d{3},\\d{3}", 0); //\"price_high\":\\d{6}|\"price\":\\d{6}
						
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		

//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}338[\\s\\w\\W]{30}", 0));		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(quickHomesData, "[\\s\\w\\W]{30}338[\\s\\w\\W]{30}", 0));		

		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
				
		//============ Square Feet
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(comHtml, "\\d,\\d{3} - \\d,\\d{3} sq. ft.|sqft_low\":\\d{4}|sqft_high\":\\d{4}", 0); //sqft_low\":\\d{4}|sqft_high\":\\d{4}
				
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);	
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}1149[\\s\\w\\W]{30}", 0));
		
		//============ cType
		comHtml = comHtml.replaceAll("nexton-master-planned-community-of-the-year", "");
		
		String cType = U.getCommType(comHtml);
		U.log("cType: "+cType);
			
		//============ pType
		if(comUrl.contains("-estates")) comHtml = comHtml + ", Estate Style";
		
		comHtml = comHtml.replaceAll("property_type\":\"Single Family|property_type\":\"single family home", "");	
		
		String pType = U.getPropType(comHtml);
		U.log("pType: "+pType);
	
		//============ dType
		comHtml = comHtml.replaceAll("The First Floor is rounded out|featured on the first floor is a private|Rounding out the First Floor is a large|"
				+ "irst floor is a large Master Suite","");
		
		String dType = U.getdCommType(comHtml);
		U.log("dType: "+dType);
				
		//============ Status
		String status = ALLOW_BLANK;
		String usda_financing = U.getSectionValue(comHtml, "is_usda_financing\":", ",\"");
		U.log("homesCounter: "+homesCounter);
		
		comHtml = comHtml.replaceAll("availability\":\"closeout|promises to be a very fast selling community|MODEL HOMES SALES CENTER IS NOW OPEN|"
				+ "Select from Move-In Ready Homes that are available for|Map is coming soon|Lot is now available in Charleston|"
				+ "headline\":\"NOW OPEN - Brand New Location in Kanna", "");
		
		status = U.getPropStatus(comHtml);
		
		if(usda_financing.equals("1")) {
			if(status == ALLOW_BLANK)
				status = "USDA Financing Available";
			else
				status = status + ", USDA Financing Available";
		}
		
		if(homesCounter > 1) {
			if(status == ALLOW_BLANK)
				status = "Quick Move-Ins";
			else
				status = status + ", Quick Move-Ins";
		}
		
		if(comUrl.contains("https://www.truehomesusa.com/charlotte/haven-at-rocky-river/")) {///bcz sold is given in image
			status	="USDA Financing Available";
		}
		if(comUrl.contains("https://www.truehomesusa.com/raleigh/walker-grove/")) {
			status="Now Selling, USDA Financing Available";
		}
		
		U.log("Status: "+status);
				
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Closeout[\\s\\w\\W]{30}", 0));
		//============ Note
			
		
		String note = U.getnote(comHtml);	
		U.log("note: "+note);
		
		
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyStatus(status);
		data.addPropertyType(pType, dType);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		i++;
		
	}
	
	
	
	
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName =U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode =U. CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "application/json, text/plain, */*");
			urlConnection.addRequestProperty("Accept-Language",
					"en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Referer", "max-age=0");
			urlConnection.addRequestProperty("Connection", "https://www.truehomesusa.com/");
			urlConnection.addRequestProperty("Authority", "www.truehomesusa.com");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}