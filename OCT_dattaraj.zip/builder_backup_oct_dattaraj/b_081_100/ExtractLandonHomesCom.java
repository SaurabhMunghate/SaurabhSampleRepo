package com.shatam.b_081_100;

/**
 * @author Rakesh Chaudhari
 * @date 08-07-2015
 * 
 */
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;


import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLandonHomesCom extends AbstractScrapper 
{
	static String BASEURL = "https://www.landonhomes.com/";
	CommunityLogger LOGGER;
	static int j=0;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception 
	
	{
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractLandonHomesCom();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Landon Homes.csv", a.data().printAll());
	}

	public ExtractLandonHomesCom() throws Exception 
	{
		super("Landon Homes", BASEURL);
		LOGGER = new CommunityLogger("Landon Homes");
	}

	public void innerProcess() throws Exception 
	{
//		String html = getHTMLwithProxy("https://www.landonhomes.com/find-a-home/");
		String html = U.getHTML("https://www.landonhomes.com/find-a-home/");
		/*String urls_section = U.getSectionValue(html, "Find a Home</a>",
				"Quick Move-Ins");*/
		// U.log(urls_section);
		//String community_urls_names[] = U.getValues(html,"<div class=\"listing fourcol", "class=\"viewdetails");
//		String comSection=U.getSectionValue(html,"","");
		String communitySections[] = U.getValues(html,"<div class=\"uk-width-1-3@m\">", "View Community</a>");
		U.log(communitySections.length);
		for (String comSec : communitySections) 
		{
//			U.log(" sfddggfgfg"+comSec);
			String commUrl = U.getSectionValue(comSec, "<a href=\"", "\"");

			String commUrlhtml=U.getHTML(commUrl);
			
			String commName = U.getSectionValue(comSec, " class=\"uk-link-reset\">", "<");

			
			if(commUrlhtml.contains("Home Series</h1>")) {
				String[]SubComUrlSections=U.getValues(commUrlhtml, "<div class=\"uk-cover-container\">", "View Community</a>");
				
				LOGGER.AddSubRegion(commUrl, SubComUrlSections.length);
				
				for(String SubComUrlSec :SubComUrlSections ) {
					String SubComUrl=U.getSectionValue(SubComUrlSec, "<a href=\"", "\"");
					String subCommName=U.getSectionValue(SubComUrlSec, "class=\"uk-link-reset\">", "</a>");
					U.log(commName);
					
					if(!subCommName.startsWith(commName)) subCommName= commName+" "+subCommName;
//					try {
						addDetails(SubComUrl, subCommName,SubComUrlSec);
//					} catch (Exception e) {}
					//U.log("FROM HERE");
				}
			}else {
	
	//			U.log(commUrl + "\t: " + commName);
//				try {
					addDetails(commUrl, commName,comSec);
//				} catch (Exception e) {}
					//U.log("FROM HERE---");	
				
				//break;
			}
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String commUrl, String commName, String info) throws Exception 
	{
		
//		if(j==10)
	//TODO:
//	if(!commUrl.contains("https://landonhomes.com/new-home-communities/homes-argyle-tx-canyon-falls/")) return;
		{
			
//			if(data.communityUrlExists(url)){
//				LOGGER.AddCommunityUrl(url+"::::::::::::::::::::::::");
//				return;
//			}	
			
		//	U.log(info);
		// ............................Community Url...........................
		U.log(j+"\tPage Url: " + commUrl);
		
		
		if (data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl(commUrl+"-----------> Repeated");
			return;
		}
		
		LOGGER.AddCommunityUrl(commUrl);
		
		commName=commName.replace(" Cottage", "").replace(" Craftsman", "");
		// ...........................Community Name...........................
		U.log("commName: "+commName);
		//U.log("info: "+info);

		// .......................comunity type,property type, property

		//String html = getHTMLwithProxy(commUrl);
		String html = U.getHTML(commUrl);
		String htmlOne = html;
		U.log(U.getCache(commUrl));
		
		
		String navBar = U.getSectionValue(html, "<nav class=\"uk-flex uk-flex-right uk-flex-middle\" uk-navbar>", "<!-- container -->");
		if(navBar!=null)
			html = html.replace(navBar, "");
		
		String phtml=html;
		String planUrlHtml=ALLOW_BLANK;
//		String rm = U.getSectionValue(html, "<div id=\"questions\" class=\"uk-modal\">", "</html>");
//		U.log("............"+rm);
//		html= html.replace(rm, "");
//		rm = U.getSectionValue(html, "<div class=\"alert\">", "</div>");
//		if(rm!=null)
//		html= html.replace(rm, "");

		String[] planSecUrlSec=U.getValues(html,"<div class=\"uk-position-relative\">", "</div>");
		for(String planUrl:planSecUrlSec) {
			planUrl=U.getSectionValue(planUrl, "<a href=\"", "\"");
			
//			U.log("PlanUrl: "+planUrl);
			if(planUrl!=null)
			planUrlHtml+=U.getHTML(planUrl);
			
		}
		
		//==================Add & latlng
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String flag="False";
		
//		latLng[0]=U.getSectionValue(info, "data-lat=\"", "\"");
//		latLng[1]=U.getSectionValue(info, "data-lng=\"", "\"");
		latLng[0]=U.getSectionValue(html, "data-lat=\"", "\"");
		latLng[1]=U.getSectionValue(html, "data-lng=\"", "\"");
		U.log(Arrays.toString(latLng));
		
		String addSec=U.getSectionValue(html, "Model Address: <i class=\"fas fa-map-marker-alt uk-text-secondary\"></i>", "</p>");
		if(addSec==null) {
			addSec=U.getSectionValue(info, "<i class=\"fas fa-map-marker-alt\"></i>", "</div>");
		}
		U.log("addSec ::"+addSec);
		add=U.getAddress((addSec).replace("13103 Strike Gold Blvd,, Frisco", "13103 Strike Gold Blvd, Frisco"));
		
		if(latLng[0]==null || latLng[1]==null && add[1] != null && add[2] != null) {
			latLng = U.getlatlongGoogleApi(add);
			U.log(">>>> "+Arrays.toString(add));
		}
		
//		if(commUrl.contains("/lexington-frisco-symmetry-37s/")||
//				commUrl.contains("/lexington-frisco-duets-41s/")) {
//			
//			add=U.getAddressGoogleApi(latLng);
//			U.log(Arrays.toString(add));
//			flag="TRUE";
//		}
		
		U.log("ADDRESS: "+Arrays.toString(add));
		
		U.log(Arrays.toString(latLng));
//		if(latLng[0]!=null || latLng[1]!=null)
//		add=U.getAddressGoogleApi(latLng);
//		U.log(Arrays.toString(add));
		
	
		
//		if(latLng[0]==null || latLng[1]==null) {
//			latLng[0]=U.getSectionValue(html, "data-lat=\"", "\"");
//			latLng[1]=U.getSectionValue(html, "data-lng=\"", "\"");
//		}
			
		
		if(latLng[0]==null || latLng[1]==null && add[0] != null) {
			latLng=U.getlatlongGoogleApi(add);
			U.log(Arrays.toString(latLng));
		}
		
//		String addSec = Util.match(html, "</h2>\\s*<span>(.*?)</span>",1);//U.getSectionValue(html, "</span></h2>", "</span>");
//		
//		if(commUrl.contains("https://landonhomes.com/new-home-communities/homes-in-frisco-tx-at-hollyhock-landon-homes/")){
//			addSec = "2720 Hammock Lake Drive, Little Elm, TX 75068";
//		}
//		U.log("..........."+addSec);
//		if(addSec != null){
//			addSec =addSec.replaceAll("<span>|TBD|Model Coming Soon|Coming Soon", "");
//			add = U.getAddress(addSec);
//		}
//		U.log("Address : " + Arrays.toString(add));
//		add[0]=add[0].replaceAll("TBD|Drop by our Richwoods Province Model for more information        at |Drop by Richwoods Province Model for more information|Drop by our Model at West Park        or check out our Trailer in Lexington on Coit between Eldorado and Main ", "");
//		
		
		
		// Price
		info  = info.replace("at the 750's", "at the 750,000");
		
		info=info.replace("790’s", "790,000").replace("0’s", "0,000");
		info = info.replace("0's", "0,000");
//		U.log(info);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		info=info.replace("Prices from the 430's", "Priced from the $430,000 ");//Starting from the 820's
		info=info.replace("$1Mil+", "$1,000,000").replace("Starting from the 820's", "Priced from the $820,000 ");
		info = info.replace("0's", "0,000").replace("$400's", "$400,000").replace("â€™s", ",000").replace("'s", ",000");
		html=html.replace("0s", "0,000").replace("0&#8217;s", "0,000").replace("$900's","$900,000").replace("$1Mil+", "$1,000,000")
				.replaceAll("<strike class=\"uk-text-secondary\">\\$\\d,\\d+,\\d+</strike>|<strike class=\"uk-text-secondary\">\\$\\d{3},\\d+", "");
		
	//	U.log(info);
		
		String[] prices = U.getPrices(html+info,
				"\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}|from the \\d,\\d{3},\\d{3}|</strike>\\s*\\$\\d{3},\\d{3}</h2>|starting from</small> \\$\\d,\\d{3},\\d{3}|remove\">\\$\\d{3},\\d{3}<|starting from</small>\\s?\\$\\d{3},\\d{3}|\\$\\d+,\\d+</li>|from the (\\$)?\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|in the \\$\\d{3},\\d{3}|at the \\$\\d{3},\\d{3}| low \\$\\d{3},\\d{3}",0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		U.log(minPrice+"\t"+maxPrice);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+info, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sqFt = U.getSqareFeet(html,
				// from the $400,000
						"\\d,\\d{3} SqFt|from \\d,\\d{3} sq ft to over \\d,\\d{3} sq ft.|(a|A)pprox. sqft:\\s?\\d,\\d{3}|Size:</b> \\d+,\\d+ SQFT</li>|SqFt: \\d,\\d{3}", 0);

		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

		U.log(minSqft+"\t"+maxSqft);
		// LatLng

		
		String latLngSec = U.getSectionValue(html, "<div class=\"marker", "</div>");
//		U.log(sec);
//		if(latLngSec != null){
//			latLng[0] = U.getSectionValue(latLngSec, "data-lat=\"", "\"");
//			latLng[1] = U.getSectionValue(latLngSec, "data-lng=\"", "\"");
//		}
//		U.log("latLng : " + Arrays.toString(latLng));
//		String flag = "FALSE";
//		if(add[0].length()==0 || add[0].length()<3)
//		{
//			add=U.getAddressGoogleApi(latLng);
//			if(add == null)
//				add = U.getGoogleAddressWithKey(latLng);
//			flag="True";
//		}
		// Community Type
		html=html.replace("luxurious floor plans ", "luxury homes")
				.replaceAll("Creeks Golf Club is an Arnold Palmer|<li>Public Golf Club|resort style pool(s)?|resort style community pools|Resort-Style Pool with Lap Lane|Resort style pool with lap lanes|Landscaped accents add beauty to this master-planned|gated home community of Fairways at Craig Ranch.\" />| master-planned community Hollyhock|n the master planned community Hollyhock", "");
		
		String communitytype = U.getCommunityType(html.replaceAll("=\".*\"", ""));
		U.log("communitytype: "+communitytype);
		
		// Property Type
		
		if(!commUrl.contains("https://landonhomes.com/new-home-communities/homes-frisco-tx-lexington-country-executive-series/"))
			html=html.replace("Executive Series", "");
		
		String htmlRem = U.getSectionValue(html, "<div class=\"uk-slider-container\">", "</ul>");//remove gallery photo
		
		if(htmlRem!=null)
			html  = html.replace(htmlRem,"");
		
		html  = html.replaceAll("https://landonhomes.com/2017/wp-content/uploads/(.*?)data-uk-lightbox", "");
		html=html.replaceAll("luxury Plano TX homes|Luxury by Design ", "luxury homes ");
		html=html.replaceAll("-Courtyard-|=\".*\"|Covered Patio\"|-Patio-|_Patio-|at/03-Patio.jpg|banquet-rm_patio|Patio-2017|on-Model/61-Patio.jpg|Ready for Presale|-villas/\">West Park Villas</a></li>|value='West Park Villas|13'>West Park Villas</label>|community of West Park Villas|West Park Villas</label>|13-Patio-H720.jpg" +
				"|-Patio-|-Patio_|60-Patio-H720.jpg|47-Patio-H720.jpg|48-Patio-H720.jpg|54-Patio_720.jpg|63-Patio-H720.jpg|64-Patio-H720.jpg|65-Patio-H720.jpg|-Courtyard-","");
		//U.log(html+"%%%%");
       html=html.replace(">Magnolia Landing Cottage</a>", "");	
		planUrlHtml=planUrlHtml.replace("<li>HOA", "").replace(">Magnolia Landing Cottage</a>", "").replace("Executive Series at Lexington Country", "").replace("Lexington Country Executive Series", "");
		String proptype = U.getPropType((html+planUrlHtml).replaceAll("-Courtyard-|=\".*\"|Covered Patio\"|-Patio-",""));
		
		U.log("prop types:"+proptype);
		// Derive Prop
		html=html.replace("Story: 1 - 1.5", "1 stories - 1.5 stories ").replace("<!--Story: 1-->", "1 Story");
		html=html.replace("Stories:</b>", " story ").replaceAll("Story: ", " story ").replace("<!--Story: 1.5-->", "1.5 Story");
		//html=html.replaceAll("Story:", " story");
		//html=
		//html=html.replace("story \\d", "story \\d ");
		html=html.toLowerCase().replace("ranch", "");
		html=html.replaceAll("ranch high school|ranch road missouri|ranch high school", "");
		//U.log(html);
		
		String dtype = U.getdCommType((html+commName+planUrlHtml).replaceAll("=\".*\"", ""));
		
		U.log("derived types:"+dtype);
//		U.log(">>>>>>>>>>>>>>>>>"+Util.matchAll(planUrlHtml, "[\\s\\w\\W]{100}1.5 Story[\\s\\w\\W]{300}",0));

		html=html.toLowerCase().replace("lewisville is now open!!!!</li>", "").replace("extension now opn at anthe", "");
		html=html.replaceAll("series - coming soon</label>|<marquee>grand opening incentives!</marquee>|new lots available now !!!</marquee>| - coming soon'  id='| scenic lakeview homesites available</li>|largest homesites available|lewisville is now open|extension now open|now open, adjacent to the|quick-move-ins/|Quick Move-Ins|Quick Move-Ins"
				, "");
		html=html.replaceAll("coming soon, rowlett|outside\">coming|last opportunity until next phase opens!|place/coming soon|family homes coming|Quick Move-In Homes</a>|png\" /> Quick Move-In|landonhomes\\.com/quick-move-in-homes/|mega-menu-description\">sold out!</span>|>Grand Opening Incentives!|lexington country coming soon|lexington - coming soon|but more will be coming soon.</p>|Country Coming Soon|soon to (T|t)he (G|g)rove"
				, "");
		
	
		info=info.replace("Coming Soon in January 2020", "Coming Soon January 2020").replace("New Home-Sites Released!", "New Home Sites Released")
				.replace("padding:3px 10px;\">Sold Out", "")
				.replace("60' Homesites - New Lots Released", "")
				.replaceAll("Pre-planned Quick Move-ins Available|New Lots Released in Phase 27|\">Grand Opening Incentives!</h2>|Coming Soon</label>|Coming Soon'  id=|- Coming Soon|Coming Soon!&quot;]\"","");

		
		html=html.replace("over-sized home-sites are also available", "Over-sized home-sites available").replace("sold out of current phase", "sold out current phase")
				.replace("over sized home-sites are also available", "over sized home-sites available").replaceAll("playground coming soon|menu-description\">Coming soon|Playground Coming|school is coming soon|png\" /> quick move|elevation coming soon|snip\">coming soon|mega-menu-description\">\\d opportunity remaining</span>|mega-menu-description\">\\d opportunities remaining</span>|now open for tours|mega-menu-description\">\\s*coming soon|- coming soon|Coming Soon'  id=|Coming Soon</label>|- Coming Soon|Coming Soon!&quot;]\"|in homes</a>|move-in</h4|now available!</marquee>|We are selling the final opportunity from our Lexington Country","").replaceAll("Phase 11A – Coming Soon|Phase 11A &#8211; Coming Soon|phase 11a &#8211; coming soon", "Phase 11A Coming Soon")
				.replaceAll("\\d+ Floor Plans Available to Build|selling the final|community is sold|stimulus on last \\d+ lots", "");
		//html = U.removeSectionValue(html, "<nav class=\"uk-navbar\">", "<a href=\"#offcanvas");
		
		
		html=html.replaceAll("phase 2 &#8211; now open!</p>", "phase 2 now open");
		html=html.replaceAll("floor plans available to build|pre-planned quick move-in|description\">Coming soon|tx-phase 2 coming summer 2021", "").replace("more details coming soon", "").replaceAll("Patio-\\d{3}x\\d{3}.jpg| new phase coming spring 2021|phase 2, coming spring 2021", "").replace("tx-sold out", "").replace("sold out for february", "").replace("tx-phase 2 coming late spring", "");
		String propstatus = U.getPropStatus((html+info).replaceAll("|Phase 2 Open, No Waitlist|\\d+ Floor Plans Available to Build|Frisco, TX &mdash; Coming Soon|Pre-planned Quick Move-ins Available|office coming soon|model coming soon|\\d+ Floor Plans Available to Build", "")
				.replace("phase 1 close-out", "phase 1 closeout").replaceAll("11a|Pre-Selling New Phase - See sales", "11A").replace("Phase 2 &#8211; Now Open","Phase 2 Now Open"));
		
		
		U.log("propstatus:: "+propstatus);
//		U.log(">>>>>>>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{50}Limited oppor[\\s\\w\\W]{50}",0));
//		U.log(">>>>>>>>>>>>>>>>>"+Util.matchAll(info, "[\\s\\w\\W]{50}Limited oppor[\\s\\w\\W]{50}",0));
		
		//U.log(info);
		info = info.replaceAll("Coming\\s{2,}Soon", "Coming Soon");
		String notes=U.getnote((html+info).replace("tx now pre-selling", "").replaceAll("now pre-selling new allen", ""));
		//U.log(">>>>>>>>>>>>>>>>>"+Util.matchAll(info, "[\\s\\w\\W]{10}phase 2[\\s\\w\\W]{10}",0));
		

		
		
/*		if(commUrl.contains("https://www.landonhomes.com/new-home-communities/homes-argyle-tx-canyon-falls/"))
			propstatus=propstatus + ", New Phase Now Open";
		
			
		if(commUrl.contains("https://www.landonhomes.com/new-home-communities/new-homes-frisco-tx-at-hollyhock-classic-series/"))
			propstatus = propstatus.replace("Final 20 Opportunities Now Available, Now Available", "Final 20 Opportunities Now Available");
		
		propstatus = propstatus.replaceAll("\\d+ Floor Plans Available,|\\d+ Floor Plans Available|, \\d+ Floor Plans Available", "")
				.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		
		if(propstatus.contains("New Phase Coming,") && propstatus.contains("New Phase Coming "))
			propstatus = propstatus.replaceAll("New Phase Coming,", "");
		if(commUrl.contains("https://www.landonhomes.com/new-home-communities/frisco-tx-new-homes-lexington-country-impression-series"))propstatus="New Plans Released";
*/
		
//if(propstatus.length()<4)
//	propstatus=ALLOW_BLANK;
//		// Add All
//
//
//if(add[0].contains("Office")) {
//	add=U.getAddressGoogleApi(latLng);
//	flag="TRUE";
//}

//propstatus=propstatus.replace("New Phase Coming Late 2021, Coming Soon, Coming Late 2021", "New Phase Coming Late 2021");
if(info.contains(">Final Phase</h2>") && !propstatus.contains("Final Phase"))
	if(propstatus==ALLOW_BLANK)propstatus = "Final Phase";
	else propstatus += ", Final Phase";

		//	------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		if(htmlOne.contains("class=\"popover-icon\">")) {

			ArrayList<String> lotCount = Util.matchAll(htmlOne, "class=\"popover-icon\">", 0);
			U.log("lots.length: "+lotCount.size());
			
			units = String.valueOf(lotCount.size());
		}
		
		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus.replace("Currently Sold Out, Sold Out", "Currently Sold Out").replaceAll("\\d+ Floor Plans Available,", ""));
		data.addNotes(notes);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
	}j++;
		}
	
	public static String getHTMLwithProxy(String path) throws IOException, NoSuchAlgorithmException, KeyManagementException {

		// System.setProperty("http.proxyHost", "104.130.132.119");
		// System.setProperty("http.proxyPort", "3128");

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);

		//U.log("filename:::" + fileName);

		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		URL url = new URL(path);

		String html = null;

/*		SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(new KeyManager[0], new TrustManager[] {new DefaultTrustManager()}, new SecureRandom());
        SSLContext.setDefault(ctx);
*/		
		// chk responce code

		// int respCode = CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);

		{
			
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
					"104.236.55.48",8080));
			
			
			final URLConnection urlConnection = url.openConnection(proxy);

			// Mimic browser
			try {
				urlConnection
						.addRequestProperty("User-Agent",
								"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
				urlConnection
						.addRequestProperty("Accept", "text/css,*/*;q=0.1");
				urlConnection.addRequestProperty("Accept-Language",
						"en-us,en;q=0.5");
				urlConnection.addRequestProperty("Cache-Control", "max-age=0");
				urlConnection.addRequestProperty("Connection", "keep-alive");
				// U.log("getlink");
				final InputStream inputStream = urlConnection.getInputStream();

				html = IOUtils.toString(inputStream);
				// final String html = toString(inputStream);
				inputStream.close();

				if (!cacheFile.exists())
					FileUtil.writeAllText(fileName, html);

				return html;
			} catch (Exception e) {
				U.log(e);

			}
			return html;
		}

	}
	
}
