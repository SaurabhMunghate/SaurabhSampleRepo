/**
 * @author Parag Humane 
 * @date 16/04/2012
 * 
 */
package com.shatam.b_081_100;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLombardoHomes extends AbstractScrapper {
	static int dup=0;
	CommunityLogger LOGGER;
	
	WebDriver driver = null;
	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new ExtractLombardoHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Lombardo Homes.csv", a.data()
				.printAll());
//		U.log(dup);
	}

	public ExtractLombardoHomes() throws Exception {

		super("Lombardo Homes", "https://www.lombardohomes.com/");
		LOGGER = new CommunityLogger("Lombardo Homes");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String html = U.getHTML("https://lombardohomes.com/");
		String StateMIjson = U.getHTML("https://lombardohomes.com/wp-admin/admin-ajax.php?action=fetch_communities&page=1&state=MI&city=&communityId=&school=&sqftMin=1200&sqftMax=5500&priceMin=150000&priceMax=750000&modelAvailable=false&priceFilterToggle=&county=");
		String StateMOjson = U.getHTML("https://lombardohomes.com/wp-admin/admin-ajax.php?action=fetch_communities&page=1&state=MO&city=&communityId=&school=&sqftMin=1200&sqftMax=5500&priceMin=150000&priceMax=750000&modelAvailable=false&priceFilterToggle=&county=");
		String dataMI[] = U.getValues(StateMIjson, "{\"ID\"", "\"limited\":false}");
		String dataMO[] = U.getValues(StateMOjson, "{\"ID\"", "\"limited\":false}");

//		U.log(StateMOjson);
		String comurls[]=U.getValues(html, "/lombardohomes.com\\/community\\", "\\/&quot;");
		for(String comurl:comurls) {
			String url="https://lombardohomes.com/community"+comurl;
			String comhtml=U.getHtml(url,driver);
			String stateSec ="";
			for(String data: dataMI) {
				if(data.contains(comurl)) {
					stateSec = data;
				}
			}
			for(String data: dataMO) {
				if(data.contains(comurl)) {
					stateSec = data;
				}
			}
//			U.log("url===="+url);
			addDetails(url, "", comhtml, stateSec);
		}
		
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	
	//TODO :
	int i = 0;
	private void addDetails(String url, String commName, String comsec, String stateData) throws Exception {

//		if(!url.contains("https://lombardohomes.com/community/st-charles-county-wentzville-mo-sutton-farms")) return;
		
//		if(i>=20)
//		try
		{
		U.log(i+" PAGE :" + url);
		
		if(url.contains("https://lombardohomes.com/new-homes-in-michigan/build-on-your-lot") || url.contains("https://lombardohomes.com/new-homes-in-st-louis/cranbrook-custom-homes-camelot/")
				)return;
//		|| url.contains("https://lombardohomes.com/community/anywhere-lombardo/")
		
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"::::::::::::::repeated::::::::::");
			return;
		}
		if(url.equals("https://lombardohomes.com/community/macomb-county-macomb-preserves-at-legacy-estates")) {
			LOGGER.AddCommunityUrl(url+"::::::::::::::Redirect to region page::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(url);
   //U.log("comSec:: "+comsec);
		
		commName=U.getSectionValue(comsec, "<h1>", "</h1>");
		
		commName=commName.replace(" &#8211; ", "-");
		commName=commName.replace("Anywhere Lombardo – Columbia","Anywhere - Lombardo Columbia");
		commName=commName.replace("Anywhere Lombardo – Michigan","Anywhere Lombardo - Michigan");
		
		String tempCommName=ALLOW_BLANK;
		tempCommName=commName;
//		U.log("=========="+comsec);
		String html = U.getHtml(url,driver);
		U.log(">>>>"+U.getCache(url));
		
		String statusSection=U.getSectionValue(html, "<h4 class=\"unset-text text-center\">", "</h4>");
		if(statusSection==null){
			statusSection=ALLOW_BLANK;
		}

		
		String commName1=U.getSectionValue(html,"aria-current=\"page\">","<");
		U.log("commName1=== " + commName1);
//		U.log("=========="+Util.matchAll(comsec, "now open", 0));
		
		html = U.removeSectionValue(html, "<head>", "</head>");
		// =============== Address==================
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		// ============Lat & Lng===============
				String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
				String geo = "False";
				String note=ALLOW_BLANK;
				
		//-------Community Address-------------
		String addressSec = ALLOW_BLANK;
		String comAddSec = U.getSectionValue(html,"<h4>Community Info</h4>","</a>");
		String salesAddSec=U.getSectionValue(html, "<h4>Sales Office</h4>", "</a>");
		String latlngSec=ALLOW_BLANK;
		
		String []temp=null;
		
		U.log("comAddSec===="+comAddSec);
		U.log("salesAddSec===="+salesAddSec);
		
		if(comAddSec!=null) {
			addressSec=U.getSectionValue(comAddSec, "<address>", "</address>");
			if(addressSec!=null) {
				addressSec=addressSec.trim();
//				
				addressSec=addressSec.replace("Highway N, East of Highway K", "Highway N")
						.replace("Ivory Ln, Columbia, MO, USA", "Ivory Ln, Columbia, MO")
						.replace("4701 Kenora, Dr, Columbia, MO, 65201", "4701 Kenora Dr, Columbia, MO 65201");
				U.log("addressSec-1===="+addressSec);
				temp=addressSec.split(",");
				U.log("temp.length===="+temp.length);
				if(temp.length==3 ||temp.length==4) {
					String address=Arrays.toString(temp);
					add=U.getAddress(address);
				}
		
				else {
					addressSec=U.getSectionValue(salesAddSec, "<address>", "</address>");
					if(addressSec!=null) {
						addressSec=addressSec.trim();
						U.log("addressSec-2===="+addressSec);
						temp=addressSec.split(",");
						if(temp.length==3) {
							String address=Arrays.toString(temp);
							add=U.getAddress(address);
						}
				}
				
			}
				
		}
		}
		
		
		if(comAddSec.contains("<a href=\"https://www.google.com/maps"))
		{
			 latlngSec=U.getSectionValue(comAddSec, "<a href=\"https://www.google.com/maps/place", "\"");
			U.log("latlngSec-1===="+latlngSec);
			
		}
		else {
			latlngSec=U.getSectionValue(salesAddSec, "<a href=\"https://www.google.com/maps/place", "\"");
			U.log("latlngSec-2===="+latlngSec);
		}
		if(latlngSec!=null) {
			latlngSec=U.getSectionValue(latlngSec, "/@", "/").replaceAll(",\\d{2}z", "");
			latLong=latlngSec.split(",");
		}
		else {
			String DataHtml=U.getHTML("https://lombardohomes.com/wp-admin/admin-ajax.php?action=fetch_communities&page=1&state=");
			if(DataHtml!=null)
			{
				String[] communitySec=U.getValues(DataHtml, "{\"ID\"", "\"limited\":");
				if(communitySec.length>0) {
					for(String communityData :communitySec) {
						communityData=communityData.replace("\\/", "/");
						if(communityData.contains(url)) {
							latLong[0]=U.getSectionValue(communityData, "\"lat\":", ",");
							latLong[1]=U.getSectionValue(communityData, "\"lng\":", ",");
						}
					}
				}
				
			}
		}
		
		
		if(add[0]!=ALLOW_BLANK && add[1]!=ALLOW_BLANK && add[2]!=ALLOW_BLANK && add[3]==ALLOW_BLANK)
		{
			add[3]=U.getAddressGoogleApi(latLong)[3];
			geo = "True";
		}
		
		U.log("address=="+Arrays.toString(add));
		U.log("latLong=="+Arrays.toString(latLong));
		
		
		if(url.equals("https://lombardohomes.com/community/anywhere-lombardo-michigan")){
			add[0]="13001 23 Mile Road Suite 200";
			add[1]="Shelby Township";
			add[2]="MI";
			add[3]="48315";
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null)
				latLong = U.getlatlongHereApi(add);
			note="Address Taken From Contact";
			geo = "TRUE";
		}

		if(url.equals("https://lombardohomes.com/community/st-charles-county-wentzville-mo-sutton-farms")) {
	
			add=U.getAddressGoogleApi(latLong);	
					geo = "TRUE";
	}
		
		if(url.contains("community/anywhere-lombardo-st-louis-county")) {
//			String[] add1= {"", "Ellisville", "MO",""};
			add[0]="16144 Clayton Road";
			add[1]="Ellisville";
			add[2]="MO";
			add[3]="63011";
			U.log("address--1=="+Arrays.toString(add));

			latLong=U.getlatlongHereApi(add);
//			add = U.getAddressGoogleApi(latLong);
//			if(add == null) add = U.getGoogleAddressWithKey(latLong);
			geo = "TRUE";
		}
		
			if (latLong[0] == ALLOW_BLANK && latLong[0] != null) {
				
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null)
					latLong = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			
			
		

		// =================Price=====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replaceAll("0s", "0,000MyPrice").replaceAll("<span class=\"community-attributes--attribute\">\n\\s*", "<span class=\"community-attributes--attribute\">");
		String[] price = U
				.getPrices(
						html,
						"price\">\\$\\d{3},\\d{3}</span>|<p>\\$\\d{3},\\d{3}<br />|>\\$<span>\\d{3},\\d{3}</span></div>|<li>\\$\\d+,\\d+</li>|center\">\\$\\d+,\\d+</td>|\\$\\d{3},\\d{3}MyPrice",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		if (maxPrice.equals(minPrice))
			maxPrice = ALLOW_BLANK;
		
		if(url.contains("https://lombardohomes.com/community/oakland-county-rochester-hills-cumberland-pointe"))minPrice=ALLOW_BLANK;
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// =============== Square Feet================
		html=html.replace("1,300 &#8211; ", "1,300 - ");
//				.replaceAll("\\d+,\\d+ sq\\. ft\\. of living space", "");
		
		comsec=comsec.replaceAll("\\d+,\\d+ sq\\. ft\\. of living space", "")
				.replaceAll("2,700+ sq. ft.", "2,700 sq. ft.");
		html=html.replace("2,750+ sq. ft", "2,750 sq. ft").replace("2,700+ sq. ft.", "2,700 sq. ft.").replace("2,000 – 3,200+ sq ft", "2,000 – 3,200 sq ft");
		comsec=comsec.replace("2,700+ sq. ft.", "2,700 sq. ft.");
//		U.log(">>>>>>>>"+Util.matchAll("\n"+comsec, "[\\w\\s\\W]{30}1,300 [\\w\\s\\W]{30}", 0));
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		.replace("&#8211;", "-").replace(" 2.400 sq. ft.", " 2,400 sq. ft.").replaceAll("starting from 1,300 – 2,700+ sq. ft", "starting from 1,300 – 2,700 sq. ft."),
		String[] sqft = U
				.getSqareFeet(
						(html+comsec),
						"more than \\d,\\d{3} sq. ft|more than \\d,\\d{3} sq. ft.|\\d,\\d{3} – \\d,\\d{3} sq ft|starting from \\d,\\d+ – \\d,\\d+ sq. ft.|<span class=\"community-attributes--attribute\">\\d,\\d{3}-\\d,\\d{3}|from \\d,\\d{3} – \\d,\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq. ft. |range from \\d,\\d{3} - \\d,\\d{3} sq. ft and|range from \\d,\\d{3} – \\d,\\d{3} sq. ft and|Sq. Feet: \\d,\\d{3}<br />|[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3}\\+ sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq ft|colonials from [0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}\\+ sq. ft.|\\d,\\d+ sq. ft. to \\d,\\d+ sq. ft.|\\d,\\d+ to \\d,\\d+ sq. ft.|\\d,\\d+ sq. ft. to \\d,\\d+ sq. ft. |from \\d,\\d+ to \\d,\\d+ sq. ft.|\\d,\\d+ sq ft|\\d,\\d+ sq. ft|\\d,\\d+ to \\d,\\d+ sq. ft|<div class=\"info-item\">\\d,\\d{3}-\\d,\\d{3}",
						
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// =========Property Type, Community Type, Property Status============
		String comType = ALLOW_BLANK;
		html = html.replace("55+ buyer!\" />", "");
		comType = U.getCommunityType(html.replace(" golf facilities ", "golf course").replaceAll("55\\+ buyer!\" />|Looking for an active adult lifestyle|membership to Lake Forest Golf &amp; Country Club|Lake Forest Country Club. And finally", ""));
		
		//==fetch homes data========
		String comBine = getHomes(url);
		comBine =comBine.replace("first floor", " first story").replace("second floor", " second story");
		//U.log(comBine);
		//=======Property TYpe
		html=html.replace("amazing views, legendary craftsmanship", "").replace("1.5-story", "one and a half story").replaceAll("Duplex_Front|merges custom home |Apartment Communities</a>|apartment-communities-in-michigan/\"|Villanueva|villanueva|Custom", "");
			
		String pType = ALLOW_BLANK;
		pType = U.getPropType((commName+html+comBine)
				.replace("main-menu flex space-between", "")
				.replace("Trailwoods Estates              </h2>", "Trailwoods Estate Style Living              </h2>")
				.replace("103 Westleigh Manor Dr", "").replace("Stoneybrooke+Apartments!8m2!3d42.3495299!4d-", ""));
		
		U.log("pType: "+pType);
//		U.log(">>>>>>>>"+Util.matchAll(commName+html+comBine, "[\\w\\s\\W]{30}flex space[\\w\\s\\W]{30}", 0));

		//=====Derived Type=========
		String dPropStatus = ALLOW_BLANK;

		String derived = U.getSectionValue(html, "<section class=\"content-slider flex-row-reverse\">",
				"</div>	");

		html = html.replaceAll("alt=\"Coming Soon\"|Information Coming Soon|details on our next phase grand opening|about the new sites available:|-template--sold-out|Coming-Soon|Grand opening September 14|/inverness/\">Now Open!</a>", "");

		
		
		dPropStatus = U.getdCommType(derived+comBine);

		U.log(dPropStatus);
		
		//Thread.sleep(10000);
		
		String pStatus = ALLOW_BLANK;
		String statSec = html;
		U.log("KKK"+Util.match(statSec,"sold out"));
		String remove = "LEADING UP TO THE GRAND|Hours: </span>COMING SOON!|details on our next phase grand opening|closeout-header|Cambridge Falls Final Closeout|<li>COMING SOON!|-template--sold-out| available homesites are cul-de-sac |Available homesites at Woods |COMING SOON!</a></li>|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|private bath. Limited opportunities|Display Now Open|information coming|Name: </span>COMING";
		statSec = statSec.replace("Phase I at Enclave a Legacy Estates is sold out", "Phase I sold out")
				.replace("NEW HOMES COMING SATURDAY, OCTOBER 19", "NEW HOMES COMING OCTOBER 19").toLowerCase().replaceAll(remove.toLowerCase(), "");
		statSec = statSec.replaceAll("only one quick close home remains",
				"Only one home remains");
		
		pStatus = U.getPropStatus((statusSection+statSec+comsec)
				.replace("text-center\">limited opportunities available", "text-center\">limited opportunities")
				.replace("Limited Opportunities Available", "Limited Opportunities")
				.replace("Additional Homesites Coming Soon to Columbia", "Homesites Coming Soon to Columbia")
				.replaceAll("Quick Move-In|quick move-in", "")
				.replaceAll("Package Now|package now", "")
				.replace("new additions coming soon", "")
				.replaceAll("decorated model &amp; new homesites now open|Additional Homesites Coming Soon|grand opening is highly anticipated|grand opening week|office grand|details on our next phase grand opening|LEADING UP TO THE GRAND|Information Coming Soon|about our final opportunities|advantage of the final opportunities|-template--sold-out|updates on this exciting grand", "")
				.replace("Only ONE immediate occupancy hom", " ONLY ONE HOME REMAINING "));
		
		U.log("=========="+Util.matchAll((statSec+comsec), "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));
//		U.log("=========="+Util.matchAll((statSec), "now open", 0));

		U.log("PropStatus:"+pStatus);
		
		
		if(html.contains("Quick Close <span>Homes</span></h3><ul class=\"models\">") || html.contains("font-main\">View Quick Close Home</a>")){
			if(pStatus.length()<4){
				pStatus="Quick Close Homes";
			}
			else{
				pStatus=pStatus+", Quick Close Homes";
			}
		}
		
		if(url.contains("https://lombardohomes.com/community/oakland-county-rochester-hills-cumberland-pointe"))pStatus="Sold Out";
//		else{
//			if(pStatus.length()<4){
//				pStatus="No Quick Close Homes";
//			}
//			else{
//				pStatus=pStatus+", No Quick Close Homes";
//			}
//		}
//		pStatus = pStatus.replace("Opening Fall 2017, Grand Opening", "Grand Opening Fall 2017");
		
//		U.log(stateData);
		
		pStatus = pStatus.replace("Grand Opening, Opening Fall 2020", "Grand Opening Fall 2020");
//		U.log("=========================================");
		if (url.contains("http://lombardohomes.com/new-homes-in-michigan/macomb-county-macomb-township-wolverine-country-club-")
				|| url.contains("http://lombardohomes.com/new-homes-in-st-louis/st-charles-county-st-charles-estates-at-talbridge/"))
			geo = "False";
		commName = commName.toLowerCase().replace(
				"Tead Estates At Wildwood".toLowerCase(),
				"Homestead Estates At Wildwood");
		if(url.contains("https://lombardohomes.com/community/the-heights-at-elkow-farms"))pStatus="Cul-de-sac Homesites Available";
		if (data.communityUrlExists(url)){
			dup++;
			return;
		}
		if (latLong[0] == null) {
			latLong[0] = ALLOW_BLANK;
			latLong[1] = ALLOW_BLANK;
		}

		if (url.contains("wildwood")) {
			commName = "Homestead Estates at Wildwood";
		}
		 
		if (url.contains("https://lombardohomes.com/community/washtenaw-county-ypsilanti-township-majestic-ponds/")) pStatus += ", Limited Opportunity";
				
		add[0] = add[0].replace("Dr.", "Dr").replace("Ct.", "Ct")
				.replace("Rd.", "Rd").replace("Ave.", "Ave");
		add[1]= add[1].replace("O�Fallon","O'Fallon");
		if(url.contains("http://lombardohomes.com/new-homes-in-st-louis/st-charles-county-st-charles-estates-at-timberleaf/"))
		{
			dPropStatus=dPropStatus.replace("1.5 Story,", "");
			geo="FALSE";
		}
		U.log("GEO code::"+geo);

		U.log(">>"+commName);
		if(commName.endsWith("custom homes")){
			commName=commName.replace("custom homes", "");
		}
//		commName = commName.replace(" of ann arbor", "");
		
		//getting status from statedata: (Now Open)
		
		String[] datas = U.getValues(stateData, "\"post_author\":\"", "\"phone_link\":\"");
		for(String data : datas)
			
//			if(stateData.contains(commName) && stateData.contains("\"now_open\":true") && !pStatus.contains("Now Open")) 

		if(stateData.contains("\"now_open\":true") && !pStatus.contains("Now Open")) 
		{
			if(pStatus.length()<2) {pStatus = "Now Open";}
			else {
				pStatus = "Now Open, "+pStatus;
			}
		}
		
		
//		====================================================================================
		U.log("commName::"+commName1);
		String count=ALLOW_BLANK,noOfUnits=ALLOW_BLANK;
		int s=0;
		
		String[] lot_data=null;

		

		if(url.contains("https://lombardohomes.com/community/macomb-county-macomb-stillwater-crossing"))
			pStatus = ALLOW_BLANK;

		
		
		if(url.contains("/community/columbia-mo-the-gates"))minSqf = "2300";
		if(url.contains("https://lombardohomes.com/community/anywhere-lombardo-michigan"))pStatus = ALLOW_BLANK;
		
		pStatus=pStatus.replace("Ii", "II");
		
		if(url.contains("https://lombardohomes.com/community/anywhere-lombardo-michigan"))tempCommName="Build On Your Lot - MI";
		if(url.contains("/washtenaw-county-ann-arbor-scioview"))tempCommName="scioview";
		U.log("tempCommName="+tempCommName);
		
		tempCommName = tempCommName.toLowerCase();
		
		if(html.contains("siteplan")) {																																						 //"communityName\":\""+tempCommName+"\"}						
		String map_data=sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetCommunityByNameLite\",\"variables\":{\"clientName\":\"lombardo\",\"communityName\":\""+tempCommName+"\"},\"query\":\"query GetCommunityByNameLite($clientName: String!, $communityName: String!) {\\n  communityByName(clientName: $clientName, communityName: $communityName) {\\n    ...CommunityFields\\n    siteplans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      lotMetric\\n      src\\n      geoInfo(clientName: $clientName) {\\n        id\\n        __typename\\n      }\\n      lotLegend(clientName: $clientName) {\\n        id\\n        code\\n        name\\n        hex\\n        __typename\\n      }\\n      __typename\\n    }\\n    stdFeatureCategories(clientName: $clientName) {\\n      id\\n      name\\n      features(clientName: $clientName, communityName: $communityName) {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment CommunityFields on Community {\\n  id\\n  name\\n  thumb\\n  bonafide\\n  buildYourLot\\n  caption\\n  colormtd\\n  description\\n  pricing\\n  logo\\n  longitude\\n  latitude\\n  address\\n  sortType\\n  sortOrder\\n  primarySiteplan(clientName: $clientName, active: true) {\\n    id\\n    lotMetric\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    __typename\\n  }\\n  cityLocation(clientName: $clientName) {\\n    id\\n    name\\n    customName\\n    stateCode\\n    zip\\n    postCode\\n    __typename\\n  }\\n  agents(clientName: $clientName) {\\n    id\\n    email\\n    phone\\n    firstName\\n    lastName\\n    picture\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
       U.log("Path: "+U.getCache("https://nexus.anewgo.com/api/graphql_gateway"));
       
       
     //  U.log("Map Data::"+map_data);
       
       String commId=U.getSectionValue(map_data, "{\"communityByName\":{\"id\":", ",");
       U.log("commId="+commId);
       																																															 //"communityId\":"+commId+"                              																			
       String lotData=sendPostRequestAcceptJson2("https://nexus.anewgo.com/api/graphql_gateway","{\"operationName\":\"GetSiteplanLiteByCommunityId\",\"variables\":{\"clientName\":\"lombardo\",\"communityId\":"+commId+"},\"query\":\"query GetSiteplanLiteByCommunityId($clientName: String!, $communityId: Int!) {\\n  activeSiteplanByCommunityId(clientName: $clientName, communityId: $communityId, master: false) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    ...HotspotsFields\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      garagePosition\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    subSiteplans(clientName: $clientName, active: true) {\\n      id\\n      name\\n      info(clientName: $clientName) {\\n        siteplanId\\n        thumb\\n        fontSize\\n        x\\n        y\\n        whiteLabel\\n        showsThumb\\n        __typename\\n      }\\n      lots(clientName: $clientName) {\\n        id\\n        communityId\\n        salesStatus\\n        inventory(clientName: $clientName) {\\n          id\\n          communityId\\n          lotId\\n          planId\\n          elevationId\\n          __typename\\n        }\\n        excludedPlanElevations(clientName: $clientName) {\\n          planId\\n          elevationId\\n          planName\\n          planDisplayName\\n          elevationCaption\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment HotspotsFields on Siteplan {\\n  hotspots {\\n    id\\n    siteplanId\\n    name\\n    x\\n    y\\n    description\\n    thumb\\n    assets {\\n      id\\n      listIndex\\n      src\\n      description\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
    	U.log("Path2:"+U.getCache("https://nexus.anewgo.com/api/graphql_gateway"));	   
	
    	String lotDataSec=U.getSectionValue(lotData, "\"lots\":", "\"subSiteplans\":");
    	String[] lotArr=U.getValues(lotDataSec,"{\"lotId\":", "\"__typename\":\"Lot\"}");
    	int num=0;
    	num=lotArr.length;
    	noOfUnits=Integer.toString(num);
		}
		if(noOfUnits.equals("0"))
			noOfUnits=ALLOW_BLANK;
    	U.log("no Of Units:: "+noOfUnits); 
    	
    	
    	if(url.contains("https://lombardohomes.com/community/anywhere-lombardo-columbia"))
    		commName="Anywhere Lombardo - Columbia";
    	
		data.addCommunity(commName.replace(" – ", " - "), url, comType);
		data.addAddress(add[0].replace("[", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPropertyType(pType, dPropStatus);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(noOfUnits);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
//		catch(Exception e) {}
		i++;
		
	}
	
	
	
	
	
	
	
	

	private String getHomes(String url) throws IOException {
		String combineHtml = ALLOW_BLANK;
		String html = U.getHTML(url);

		String sectionHomes = U.getSectionValue(html,
				"Available <span>Home Plans", "class=\"right-side\">");
		String links[] = U.getValues(html, "class=\"model-image\"><a href=\"",
				"\"");
		for (String link : links) {
            U.log("Home Url: " + link);
            String homeHtml =U.getHTML(link);
            
			combineHtml = U.getSectionValue(homeHtml, "<h3 class=\"overview\">", "REQUEST INFORMATION")+combineHtml;
 
		}

		
		return combineHtml;

	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		U.log("fileName=="+fileName);
		U.log(payload);
		U.log(requestUrl);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	   //     connection.setRequestProperty("commonConfig", "%7B%22brand%22%3A%22wix%22%2C%22BSI%22%3A%2265c9492d-6abb-4ac5-b8e2-703455567d4b%7C1%22%7D");
	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY2NTYzNzg4OCwiZXhwIjoxNjY1NjgxMDg4fQ.vnKREsrV9LWY0wDF5VwNORFbHtQt3Rx-wuTV5Ww9GdE");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");
	        connection.setRequestProperty("referer", "https://myhome.anewgo.com/");
	        connection.setRequestProperty("accept", "*/*");
	       // connection.setRequestProperty("path", "/api/graphql_gateway");
	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("accept-language", "en-US,en;q=0.9,es;q=0.8,fr;q=0.7");
	        connection.setRequestProperty("content-length", "1706");

	       // connection.setRequestProperty("accept-encoding", "gzip");
	        connection.setRequestProperty("Content-Type", "application/json");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

	
	public static String sendPostRequestAcceptJson2(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		
		U.log("requestUrl === "+requestUrl);
		U.log("fileName2 === "+fileName);
		
		
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
//	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	   //     connection.setRequestProperty("commonConfig", "%7B%22brand%22%3A%22wix%22%2C%22BSI%22%3A%2265c9492d-6abb-4ac5-b8e2-703455567d4b%7C1%22%7D");
	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY2NTYzNzg4OCwiZXhwIjoxNjY1NjgxMDg4fQ.vnKREsrV9LWY0wDF5VwNORFbHtQt3Rx-wuTV5Ww9GdE");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");
	        connection.setRequestProperty("referer", "https://myhome.anewgo.com/");
	        connection.setRequestProperty("accept", "*/*");
	       // connection.setRequestProperty("path", "/api/graphql_gateway");
	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
	        connection.setRequestProperty("content-length", "2593");

	       // connection.setRequestProperty("accept-encoding", "gzip");
	        connection.setRequestProperty("content-type", "application/json");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
//	    } catch (Exception e) {
//	            throw new RuntimeException(e.getMessage());
//	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

	

	public String RedirectedURL(String url) throws Exception {
		URLConnection con = new URL(url).openConnection();
		// System.out.println( "orignal url: " + con.getURL() );
		
		con.connect();
		// System.out.println( "connected url: " + con.getURL() );
		InputStream is = con.getInputStream();
		// System.out.println( "redirected url: " + con.getURL().toString() );
		String RedUrl = con.getURL().toString();
		is.close();
		return RedUrl;

	}
}