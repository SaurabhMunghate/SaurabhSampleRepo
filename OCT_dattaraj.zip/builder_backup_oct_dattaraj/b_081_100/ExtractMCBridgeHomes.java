package com.shatam.b_081_100;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map.Entry;

import org.apache.commons.collections.map.MultiValueMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class ExtractMCBridgeHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	int count = 0;
	

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractMCBridgeHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McBride & Son Companies.csv", a.data().printAll());
	}

	public ExtractMCBridgeHomes() throws Exception {
		
		super("McBride & Son Companies", "https://www.mcbridehomes.com");
		LOGGER = new CommunityLogger("McBride & Son Companies");
	}

	static MultiValueMap communityData = new MultiValueMap();
	static MultiValueMap homesDataMap = new MultiValueMap();
	static MultiValueMap plansDataMap = new MultiValueMap();
	
	public void innerProcess() throws Exception {
		
		String communitiesData = U.getHTML("https://mcbridehomes.com/communities");
		U.log(U.getCache("https://mcbridehomes.com/communities"));
		
		// ==== Getting Json data storing in map ========
		String jsonSection = U.getSectionValue(communitiesData, "<script>window.__PRELOADED_STATE__ = ", "</script><script type=\"text/javascript\"");
		
		JsonParser json = new JsonParser();
		JsonObject objJsonCom = (JsonObject)json.parse(jsonSection);
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/mcbridge.txt", jsonSection);
		
		JsonObject jsonCom = (JsonObject)objJsonCom.get("cloudData");
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/jsoncom.txt", jsonCom.toString());
		
		JsonObject jsoncom = (JsonObject)jsonCom.get("communities");
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/jsoncommunities.txt", jsoncom.toString());
		
		for(Entry<String, JsonElement> element : jsonCom.get("communities").getAsJsonObject().entrySet()) {
			U.log(element.getKey());
			//U.log(element.getValue());

			JsonArray communitiesArray = element.getValue().getAsJsonObject().get("data").getAsJsonArray();
			//U.log("Community count: "+communitiesArray.size());
			
			for(int i=0; i<communitiesArray.size(); i++) {
				
				String comData = communitiesArray.get(i).toString();
				//U.log("comData: "+comData);
				
				String sharedName = U.getSectionValue(comData, "\"sharedName\":\"", "\"");
				//U.log("sharedName: "+sharedName);
				
				communityData.put(sharedName, comData);				
			}
		
			gethomesData(jsonSection);
			getplansData(jsonSection);
			
		// ===== Getting community urls storing in map =====
//		String[] comUrlsSecs = U.getValues(communitiesData, "<h4 class=\"CommunityCard_contentName d-flex flex-column mt-lg-3", "<div class=\"CommunityCard_media");
		String[] comUrlsSecs = U.getValues(communitiesData, "class=\"CommunityCard_wrapper\"", "<div class=\"CommunityCard_media");
		U.log("comUrlsSecs: "+comUrlsSecs.length);
		for(String comurl:comUrlsSecs) {
			String url = U.getSectionValue(comurl, "href=\"", "\"");
			url = "https://mcbridehomes.com" + url;
			
			String[] urlsSplit = url.split("/");
			String comSharedName = urlsSplit[6];
			
			U.log("url: "+url+"\n comSharedName: "+comSharedName);
			
//			try {
				addDetails(url, comSharedName, comurl);
//			} catch (Exception e) {}
			//U.log(" ");
			//break;
		}
		
		U.log("communityData : "+communityData.size());
			
		} 
		
		U.log(" ");
		
		U.log("Total Comm"+i);
		LOGGER.DisposeLogger();
	}
	
	private void addDetails(String comUrl, String comSharedName, String comSec) throws Exception {
		
		
//		if(!comUrl.contains("https://mcbridehomes.com/communities/jefferson-county/fenton-area-jefferson-co-mo/manors-at-fox-creek"))return;
		
		if(comUrl.contains("https://mcbridehomes.com/communities/st-louis-county/eureka/arbors-of-rockwood-forest")) {
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------PAGE NOT FOUND");
			return;
		}
		
		if(data.communityUrlExists(comUrl)) {	
			LOGGER.AddCommunityUrl("----------------------------------Repeated" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		
		U.log("comUrl: "+comUrl);
		
		ArrayList<String> comDetails = (ArrayList<String>) communityData.get(comSharedName);
		String comJson = comDetails.get(0);
		
		U.log("count : "+count+" comJson >>> : "+comJson);
		
		// =================== Community Name 
		String comName = U.getSectionValue(comJson, "com\",\"name\":\"", "\"");
		U.log("comName: "+comName);
		
		// =================== Address and LatLong
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		add[0] = U.getSectionValue(comJson, "\"streetAddress\":\"", "\"");
		add[1] = U.getSectionValue(comJson, "\"addressLocality\":\"", "\"");
		add[2] = U.getSectionValue(comJson, "\"addressRegion\":\"", "\"");
		add[3] = U.getSectionValue(comJson, "\"postalCode\":\"", "\"");
		
		U.log("Add::"+Arrays.toString(add));
		
		String latLngSec = U.getSectionValue(comJson, "\"geoIndexed\":[", "]");
		U.log("latLngSec: "+latLngSec);
		
		String[] latlong = latLngSec.split(","); 
		
		latLng[0] = latlong[1];
		latLng[1] = latlong[0];
		
		U.log("LatLng::"+Arrays.toString(latLng));
		
		if(add[0] == null) {
			add = U.getAddressGoogleApi(latLng);
			geo = "TRUE";
		}
		
		// =================== Community Id
		String comUniqueId = U.getSectionValue(comJson, "\"_id\":\"", "\"");
		U.log("comUniqueId: "+comUniqueId);
		
		// =================== Homes Data
		String homesData = ALLOW_BLANK; int quickCount = 0;
		
		ArrayList<String> homes = (ArrayList<String>) homesDataMap.get(comUniqueId);
		//U.log("homes size: "+homes.size());
		
			if(homes != null) {
				for(String home:homes) {
					
					U.log("HOME: "+home);
					
					//for status
					if(home.contains("Ready in Early Fall") || home.contains("READY IN EARLY FALL") || home.contains("READY IN FALL")
							|| home.contains("READY IN EARLY 2023") || home.contains("READY IN SPRING 2023") || home.contains("headline\":\"ASPEN")) {
						
					} else {
						quickCount++;
					}   
					
					homesData += home;
					
				}
				U.log("homeCount: "+homes.size());
			}

		U.log("quickCount: "+quickCount);
			
		//================ Plans Data
		int plansCount = 0; 
		String plansInfo = ALLOW_BLANK;
						
		ArrayList<String> plans = (ArrayList<String>) plansDataMap.get(comUniqueId);
			if(plans != null) {
				for(String plan:plans) {
					plansInfo += plan;
				}
				U.log("plansCount: "+plans.size());
			}

			//================ Prices
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String price [] = {ALLOW_BLANK,ALLOW_BLANK};
			
			comJson = comJson.replaceAll("0's|0’s|0s", "0,000");
			
			price = U.getPrices((comJson+plansInfo+homesData).replace("87741f2f9e304cc823ff\",\"price\":399900", ""), 
					"sale_price\":\"\\$\\d{3},\\d{3}|da6\",\"price\":\\d{6}|}},\"price\":\\d{6}|From the \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|"
					+ "ff\",\"price\":\\d{6}|}],\"priceLow\":\\d{6}|from the high \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|in the \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}", 0); //dad\",\"price\":\\d{6}
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comJson, "[\\s\\w\\W]{30}82403[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(plansInfo, "[\\s\\w\\W]{30}82403[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(homesData, "[\\s\\w\\W]{30}82403[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}82403[\\s\\w\\W]{30}", 0));
			
			//=========== SQFT
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String sqft[] = {ALLOW_BLANK,ALLOW_BLANK};
					
			sqft = U.getSqareFeet(comJson+plansInfo+homesData, "\"SftLo\":\\d{4}|\"SftHi\":\\d{4}", 0);
					
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
					
			U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(homeData, "[\\s\\w\\W]{30}1720[\\s\\w\\W]{30}", 0));
			
			//=========== cType			
			String ctype=U.getCommType(comJson);
			U.log("ctype: "+ctype);
			
			//U.log(">>>>>>>>>>>>"+Util.matchAll(description+headline, "[\\s\\w\\W]{30}golf[\\s\\w\\W]{30}", 0));
			
			//=========== pType
			String customAmeneties = U.getSectionValue(comJson, "\"CustomAmenities\":[", "\"DudaUrl\"");
			
			comJson = comJson.replaceAll("The Manors at Charlestowne|The Manors offers", "");
		
			
			String pType = U.getPropType((comJson+plansInfo+homesData)
					.replaceAll("caption\":\"Modern Farmhouse|planType\":\"Single Family|Traditional 2 Bedroom||The Manors offers|The Manors at", ""));
			U.log("pType: "+pType);
			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comJson+plansInfo+homesData, "[\\s\\w\\W]{30}Modern Farmhouse[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comJson+plansInfo+homesData, "[\\s\\w\\W]{30}cottage[\\s\\w\\W]{30}", 0));
				
			//=========== dType
			
			String dType=U.getdCommType((plansInfo+homesData).replaceAll("4 bedroom,|4BR 2.5BA home will", ""));
			U.log("dType: "+dType);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(plansInfo+homesData, "[\\s\\w\\W]{30}story 4[\\s\\w\\W]{30}", 0));
			
			//=========== Status
			String status = ALLOW_BLANK;			
			
			comJson = comJson.replace("Phase 2 has been selling fast","Phase 2 selling fast")
					.replace("Phase 4 is now selling","Phase 4 now selling")
					.replaceAll("ingrade lots available|over-20-sold-out-at-mcbride|now-66-sold-out-at-cedar|homesites remain in this current|[S|s]chool [C|c]oming|"
							+ "now open for information", "");
			
			status=U.getPropStatus(comJson);
					
			if(quickCount > 1) {
				if(status == ALLOW_BLANK)
					status = "Quick Move Homes";
				else if(status != ALLOW_BLANK)
					status = status + ", Quick Move Homes";	
			}
							
			U.log("Status: "+status);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comJson, "[\\s\\w\\W]{50}grand opening[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comJson, "[\\s\\w\\W]{50}opening[\\s\\w\\W]{30}", 0));
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			
			data.addCommunity(comName, comUrl, ctype);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status);
			data.addNotes(U.getnote(comJson));
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
			
			count ++;
		
		}
	
	public static void gethomesData(String jsonSection) throws IOException {
		
		String allHomesData = ALLOW_BLANK;
		
		JsonParser json = new JsonParser();
		JsonObject objJsonCom = (JsonObject)json.parse(jsonSection);	
		JsonObject jsonCom = (JsonObject)objJsonCom.get("cloudData");
		JsonObject homes = (JsonObject)jsonCom.get("homes");
		FileUtil.writeAllText("/home/shatam-10/Desktop/data/homes.txt", homes.toString());
		
		for(Entry<String, JsonElement> element : jsonCom.get("homes").getAsJsonObject().entrySet()) {
			
			if(element.getKey().contains("recent")) continue;
			U.log(element.getKey());
			//U.log(element.getValue());

			JsonArray homesArray = element.getValue().getAsJsonObject().get("data").getAsJsonArray();
			//U.log("homesArray: "+homesArray.size());
			
			for(int i=0; i<homesArray.size(); i++) {
			
				String homeJsonData = homesArray.get(i).toString();
				//U.log("homeJsonData: "+homeJsonData.toString());
				
				String containedIn = U.getSectionValue(homeJsonData, "\"containedIn\":\"", "\"");
				//U.log("containedIn: "+containedIn);
				
				homesDataMap.put(containedIn, homeJsonData);
				//U.log("homesDataMap.size(): "+homesDataMap.size());
			}
		}	

		
	}
	
	public static void getplansData(String jsonSection) throws IOException {
		
		String allPlansData = ALLOW_BLANK;
		
		JsonParser json = new JsonParser();
		JsonObject objJsonCom = (JsonObject)json.parse(jsonSection);	
		JsonObject jsonCom = (JsonObject)objJsonCom.get("cloudData");
		JsonObject plans = (JsonObject)jsonCom.get("plans");
		FileUtil.writeAllText("/home/shatam-10/Desktop/data/plans.txt", plans.toString());
		
		for(Entry<String, JsonElement> element : jsonCom.get("plans").getAsJsonObject().entrySet()) {
			
			U.log(element.getKey());
			//U.log(element.getValue());
			if(element.getKey().contains("recent")) continue;
			
			JsonArray plansArray = element.getValue().getAsJsonObject().get("data").getAsJsonArray();
			U.log("plansArray: "+plansArray.size());
			
			for(int i=0; i<plansArray.size(); i++) {
			
				String planJsonData = plansArray.get(i).toString();
				//U.log("planJsonData: "+planJsonData.toString());
				
				String communitiesSec = U.getSectionValue(planJsonData, "\"communities\":[", "\"elevationPhotos\"");
				
				String description = U.getSectionValue(communitiesSec, "\"description\":\"", "\"");
				//U.log("description: "+description);
				
				String[] planValues = U.getValues(communitiesSec, "{\"community\"", "\"}}");
				//U.log("planValues: "+planValues.length);
				
				for(String plan:planValues) {
					//U.log("plan: "+plan);
					
					String planKey = U.getSectionValue(plan, "\"", "\"");
					//U.log("planKey: "+planKey);
	
					
					planJsonData = planJsonData.replace(communitiesSec, "");
					
					plansDataMap.put(planKey, planJsonData + plan + description);
					//U.log("plansDataMap.size(): "+plansDataMap.size());
					
				}
		
			}
		}	

		
	}
}
