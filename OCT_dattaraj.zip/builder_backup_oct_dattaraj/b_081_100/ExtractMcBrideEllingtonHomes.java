package com.shatam.b_081_100;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import sqliteTest.testSqlite;

//import com.shatam.b_000_009.ExtractDivosta;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMcBrideEllingtonHomes extends AbstractScrapper  {
	public int i = 0;
	public int inr = 0;
	int count;
	static String HOME_URL = "http://ellingtonhomes-mcbride.com/";
	static String BUILDER_NAME = "McBride - Ellington Homes";
	CommunityLogger LOGGER;
	Connection con;
	
//	ArrayList<String> comList = new ArrayList();

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractMcBrideEllingtonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McBride - Ellington Homes.csv", a.data().printAll());
		//a.data().printAll();
	}

	public ExtractMcBrideEllingtonHomes() throws Exception {

		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public void innerProcess() throws Exception {

		U.setUpChromePath();
		WebDriver driver = new ChromeDriver();
		con = testSqlite.ConnectDatabase();
		String html = U.getHTML("http://ellingtonhomes-mcbride.com/");
		String sec = U.getSectionValue(html, "<div id=\"slides\">", "<form role=\"search");
		U.log(sec);
		String url = ALLOW_BLANK;
		String[] urlSecs = U.getValues(sec, "<a", "rel");
		for(String urlsec:urlSecs)
		{
			 url=U.getSectionValue(urlsec, "href=\"", "\"");
			 try {
				calladddetail(url);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*String arr[]={"http://ellingtonhomes-mcbride.com/listings/arbors-at-churchill/","http://ellingtonhomes-mcbride.com/listings/12372-s-outer-forty-drive/"};
		for(String myurl:arr)
		{
			try {
				calladddetail(myurl);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		driver.quit();
		testSqlite.closeconnectionconn(con);
		 LOGGER.DisposeLogger();
}

	 private void calladddetail(String url) throws Throwable{
		 //LOGGER.countOfCommunity(i);
		 i++;
		
			String	html = U.getHTML(url);
			String commName = U.getSectionValue(html, "<title>", "</title>");
			U.log(commName);
			
			//====================add==========================
			String street = U.getSectionValue(html, "Address:</b>", "<br />");
			String city = U.getSectionValue(html, "City:</b>", "<br />");
			if (city==null) {
					addinfo(street,url,html,commName);
			}else
			{
			city=city.replace("&amp;","&");
			String state = U.getSectionValue(html, "State:</b>", "<br />");
			String zip = U.getSectionValue(html, "ZIP:</b>", "<br />");
			String latl = U.getSectionValue(html, "!2d", "2!");
			U.log(latl);
			String[] latsec = latl.split("!3d");
			String lng = latsec[0];
			String lat = Util.match(latsec[1], "\\d+.\\d+");
			U.log(latsec[1]+lng);
            String geo = "FALSE";
            
            //===============price================
            String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
            String[] price=U.getPrices(html, "\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
            minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
			 //===============sqft================
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft=U.getSqareFeet(html, "Square Feet:</b> \\d,\\d+", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
		   //================type==============
		  
			String commType=U.getCommType(html);
			html=html.replaceAll("Luxury Master Bath|luxury-master-bath", "");
			String propType=U.getPropType(html);
			String dpropType=U.getdCommType(html);
			html=html.replace("SOLD!<br />", "sold out");
			String propStatus=U.getPropStatus(html);
			//===============add==========
			LOGGER.AddCommunityUrl(url);
			
			data.addCommunity(commName, url, commType);
			data.addAddress(street,city,state.trim(),zip.trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(propType, dpropType);
			data.addPropertyStatus(propStatus);
			data.addNotes(ALLOW_BLANK);
			}

	 
	 }

	private void addinfo(String street, String url,String html,String commName) throws Throwable {
		String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
		if(url.contains("http://ellingtonhomes-mcbride.com/listings/arbors-at-churchill/"));
		{
		add[0]="Churchill Ln";
		add[1]="Ballwin";
		add[2]="MO";
		add[3]="63011";
		latlng=U.getlatlongGoogleApi(add);
		}
		if(url.contains("http://ellingtonhomes-mcbride.com/listings/12372-s-outer-forty-drive/"));
		{
			latlng[0]="38.637353";
			latlng[1]="-90.45622";
			add=U.getAddressGoogleApi(latlng);
	}
		//===============price================
		html=html.replace("&#8217;s", ",000").replace("0’s", "0,000");
        String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
        String[] price=U.getPrices(html, "\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
        minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		 //===============sqft================
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft=U.getSqareFeet(html, "Square Feet:</b> \\d,\\d+|[0-9]{1},[0-9]{3} SF", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
	   //================type==============
	  
		String commType=U.getCommType(html);
		html=html.replaceAll("Luxury Master Bath|luxury-master-bath", "");
		String propType=U.getPropType(html);
		String dpropType=U.getdCommType(html);
		html=html.replace("SOLD!<br />", "sold out");
		String propStatus=U.getPropStatus(html);
		//===============add==========
		LOGGER.AddCommunityUrl(url);
		
		data.addCommunity(commName, url, commType);
		data.addAddress(add[0],add[1],add[2].trim(),add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0], latlng[1], "TRUE");
		data.addPropertyType(propType, dpropType);
		data.addPropertyStatus(propStatus);
		data.addNotes(ALLOW_BLANK);
		}
		
	}
	 