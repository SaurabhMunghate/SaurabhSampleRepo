/*
 * new code By Priti -Feb 2017
 */
package com.shatam.b_101_120;

import java.util.Arrays;
import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class DesertAspenHomes extends AbstractScrapper {
static int j=0;
	int i = 0;
	public int inr = 0;
	public static CommunityLogger LOGGER;
	HashMap< String, String> LatLngList = new HashMap<>();

	private static final String builderUrl = "https://aspenviewhomes.com";
	

	public DesertAspenHomes() throws Exception {

		super("Desert View Homes - Aspen View Homes",
				"https://aspenviewhomes.com/");
		LOGGER = new CommunityLogger("Desert View Homes - Aspen View Homes");
	}
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new DesertAspenHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Desert View Homes - Aspen View Homes.csv", a.data()
						.printAll());
		LOGGER.DisposeLogger();	

	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("http://aspenviewhomes.com/locations/southern-colorado-locations/");
		
		String[] comSections=U.getValues(html, "<div class=\"listings-card-image community\">", "More Info</a>");
		
		U.log("Total communities ::: "+comSections.length);
		
		for(String comSec : comSections){
			//U.log(comSec);
			String cUrl =U.getSectionValue(comSec, "<div class=\"linksWrap\">", "class=\"");
			addDetails(cUrl ,comSec, html);
			//break;
		}
	}

	private void addDetails(String cUrl, String comSec, String regHtml) throws Exception {
		// TODO Auto-generated method stub
		
		//if(j==7)
		{		
			String communityUrl=U.getSectionValue(cUrl, "<a href=\"", "\"");
			communityUrl = builderUrl+communityUrl;
//			if(!communityUrl.contains("https://aspenviewhomes.com/neighborhood/the-courtyards-at-woodmen-hills"))return;
			U.log(j+"::::::::::communityUrl:::::::::::::::::"+communityUrl);
			String comHtml = U.getHTML(communityUrl);
			//==========com Name ===========
			String comName=U.getSectionValue(comSec, "<h3>", "</h3>");
			U.log("comName::"+comName+"::");
			
			//==============Address ======================
			
//			U.log("comSec::::::::"+comSec);
			
			String add[] ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addSec=U.getSectionValue(comSec, "Address:</strong> <br />", "</p>");
			U.log("addSec :: "+addSec);
			if(addSec!=null){
				addSec=addSec.replace("<br />", ",");
				addSec = addSec.replace("Monument CO", "Monument, CO");
				String[] tempAdd=addSec.split(",");
				U.log("Temp Address is ::::::"+ Arrays.toString(tempAdd));
				if(tempAdd.length==3){
					add[0]=tempAdd[0].trim();
					add[1]=tempAdd[1].trim();
					add[2]=Util.match(tempAdd[2],"\\w+");
					add[3]=Util.match(tempAdd[2],"\\d+");
				}
			}
			U.log("Address is ::::::"+ Arrays.toString(add));
			//==================Lat-Lng==================
			String latLngSec=ALLOW_BLANK;
			String geo="FALSE";
			String[] latLng= {ALLOW_BLANK,ALLOW_BLANK};
			//fetch latlng from reg page
			String[] regComLL = U.getValues(regHtml, "{\"extension_fields\":null,", "infowindow_disable\"");
			U.log("total regComLL::"+regComLL.length);
			for(String comLatLng : regComLL){
				if(comLatLng.contains(comName)){
					U.log("comLatLng:::"+comLatLng);
					latLng[0]=U.getSectionValue(comLatLng, "lat\":\"", "\"");
					latLng[1]=U.getSectionValue(comLatLng, "lng\":\"", "\"");
					if (latLng[1].equals("104.646685")) {
						latLng[1]="-104.646685";
					}
					U.log("com lat lng from region page is :"+ Arrays.toString(latLng));
					break;
				}
			}

			if(add[0].length()<3 && latLng[0].length()>4){
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
			if(add[0].length()>4 && latLng[0].length()<4){
				latLng=U.getlatlongGoogleApi(add);
				geo="TRUE";
			}
			//=======available homes data
			String availHomeHtml=ALLOW_BLANK;
			if(comSec.contains(">See Homes</a>")){
				String availUrl=communityUrl.replace("neighborhood", "available-homes");
				U.log("availUrl::::::::"+availUrl);
				availHomeHtml =U.getHTML(availUrl);
				if(communityUrl.contains("carriage-meadows-south-at-lorson-ranch")){
					String[] allHomeUrls=U.getValues(availHomeHtml, "href=\"", "\"");
					int k=0;
					for(String u:allHomeUrls){
							//U.log(u);
							if(k==5)return;
							if(u.contains("http://aspenviewhomes.com/homes/"))
							availHomeHtml +=U.getHTML(u);	
					}
				}

			}
			
			//===========Home Plans=======
			String homePlanHtml=ALLOW_BLANK;
			if(comSec.contains("Home Plans</a>")){
				String homePlanUrl=communityUrl.replace("neighborhood", "home-plans");
				U.log("homePlanUrl::::::::"+homePlanUrl);
				homePlanHtml = U.getHTML(homePlanUrl);
			}
			

			//fetching each homes data
			String allHomeData = ALLOW_BLANK;
			
			String[] eachHomeUrls = U.getValues(comHtml, "<p><a class=\"more-info\" href=\"", "\">The");
			U.log("Total Home : "+eachHomeUrls.length);
			for(String eachHomeUrl : eachHomeUrls){
				U.log("eachHomeUrl :: "+eachHomeUrl);
				String eachHomeHtml = U.getHTML(eachHomeUrl);
				allHomeData += U.getSectionValue(eachHomeHtml, "<div class=\"copy-left\">", "</p>");
			}
			//U.log(allHomeData);
			//========Prices================
			String minPrice = ALLOW_BLANK,maxPrice=ALLOW_BLANK;
			comHtml = comHtml.replaceAll("the \\$230s. Colorado", "");
			 comHtml=comHtml.replaceAll("00s|00’s|00's|00s", "00,000").replace("30s", "30,000").replace("0s", "0,000");
			String[] prices=U.getPrices(comHtml+availHomeHtml, "low \\$\\d{3},\\d{3}|\"price\">\\d{3},\\d{3}</span>|From the \\$\\d{3},\\d{3}from the low \\$\\d{3},\\d{3}|from the high \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}| mid \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}", 0);
			
			
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("minPrice:"+minPrice+ " maxPrice::"+maxPrice);
			
			//=========Squarefeet===========
			String minSqft=ALLOW_BLANK,maxSqft=ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							comHtml+availHomeHtml+homePlanHtml+allHomeData,
							"sqft\">\\d{4}</span> SQFT|and \\d,\\d+ sq ft",0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft--->"+minSqft+"  maxSqft-->"+maxSqft);
			
			//=======community Type,Property Type, dType PropStatus=======
					//U.log(comHtml);
			String comType=ALLOW_BLANK,propType=ALLOW_BLANK,dType=ALLOW_BLANK,PropStatus=ALLOW_BLANK;
			
			//--------remove section----------
			comHtml=comHtml.replace("Villa Sport", "");
			
			comType=U.getCommType(comHtml);
			U.log("comType:::"+comType);
			propType=U.getPropType(comHtml+availHomeHtml.replaceAll("Courtyards|courtyards", "")+allHomeData);//+availHomeHtml.replaceAll("Courtyards|courtyards", "")+allHomeData);
			U.log("propType:::"+propType);
			
			String note="";
//			if(communityUrl.contains("http://aspenviewhomes.com/neighborhood/broadmoor-view")) {
//				add[0]="555 Middle Creek Pkwy";
//				add[1]="Colorado Springs";
//				add[2]="CO";
//				add[3]="80921";
//				latLng=U.getlatlongGoogleApi(add);
//				geo="TRUE";
//				note="Address And LatLong Taken From Contacts";
//				
//			}
			
			availHomeHtml = availHomeHtml.replaceAll("Story</button>|\\.Single-Story\">|\\.Two-Story\">", "");
			//U.log(availHomeHtml);
			dType=U.getdCommType((comHtml+availHomeHtml+allHomeData).replace("tri-level home", "3 Stories"));
			U.log("dType:::"+dType);
			
			//------------status-----------
			comHtml = U.removeComments(comHtml);
			comHtml=comHtml.replaceAll("Now open in Security\\.\"/>|with new homesites coming soon|Meridian, coming soon|Move In Ready Homes</a></li>|NEW HOMESITES AVAILABLE NOW FOR PRESALE|coming soon to Monument|<p>Coming Soon</p><!--Your|View Homes is selling now|<strong>Model Address</strong>\\s*<p>Coming soon</p>", "")
					.replace("new home sites are coming soon", "new home sites coming soon");
			
			
			PropStatus=U.getPropStatus(comHtml);
			U.log("PropStatus:::"+PropStatus);
	
			availHomeHtml = availHomeHtml.replace("data-filter=\".moveinready", "");
			
			if(availHomeHtml.contains("moveinready")){
				if(PropStatus != ALLOW_BLANK){
					PropStatus =PropStatus + ", Move In Ready Homes";
				}
				else{
					PropStatus = "Move In Ready Homes";
				}
			}
		
			if (this.data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl(communityUrl + "\t*********Repeated******\t");
				return;
			}
			LOGGER.AddCommunityUrl(communityUrl.replace("http://", "https://"));
			data.addCommunity(comName,communityUrl.replace("http://", "https://"), comType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].toLowerCase().trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(PropStatus);
			data.addNotes(note); 
			
		}j++;
	}
}
