/**Modification Pallavi..
 * @author Parag Humane 
 * @date 2/4/2012
 * 
 */
package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractAllenEdwinHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicates = 0;
	static int j = 0;
	 WebDriver driver = null;

	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractAllenEdwinHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Allen Edwin Homes.csv",
				a.data().printAll());
		U.log(duplicates);
	}
	

	public ExtractAllenEdwinHomes() throws Exception {

		super("Allen Edwin Homes", "https://www.allenedwin.com");
		LOGGER = new CommunityLogger("Allen Edwin Homes");
	}
	private WebDriver setProxy(String ip, String port){
		Proxy proxy = new Proxy(); 
		proxy.setHttpProxy(ip+":"+port); 
		proxy.setSslProxy(ip+":"+port); 

		DesiredCapabilities capabilities = DesiredCapabilities.chrome(); 
		capabilities.setCapability("proxy", proxy); 
		//Map<String, Object> prefs = new HashMap<String, Object>();
	      // browser setting to disable image
	    //prefs.put("profile.managed_default_content_settings.images", 2);
		//ChromeOptions options = new ChromeOptions();
		//options.setExperimentalOption("prefs", prefs);		
		//options.addArguments("start-maximized"); 

		//capabilities.setCapability(ChromeOptions.CAPABILITY, options); 

		//return new ChromeDriver(capabilities);
		return new FirefoxDriver(capabilities);

		
	}
	public void innerProcess() throws Exception {

		// Your code here
		ArrayList<String> links = new ArrayList<String>();
//		U.setUpChromePath();
//		driver = new ChromeDriver();
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();		

		
		//String html = getHtml("https://www.allenedwin.com/all-communities",driver);
		String html = U.getHtml("https://www.allenedwin.com/all-communities",driver);
//		String html = U.getHTMLwithProxy("https://www.allenedwin.com/all-communities");
		
			ArrayList<String> comm = new ArrayList<>(Arrays.asList(U.getValues(html, " <div id=\"card_body_comm_", "See Details</span>")));
            int cv=0;
			int totalComm = comm.size() / 2;
            U.log("total communities"+comm.size());
			for (String item : comm) {
				links.add(item);
				if(item.contains("southwest-michigan-community-detail"))
				// U.log(item);
					cv++;
				
				String urlc=U.getSectionValue(item, "<a href=\"", "\"");
			//	U.log(">>>>>>>>>>>>"+urlc);
//				try {
					addDetails("https://www.allenedwin.com" + urlc,item);
//				} catch (Exception e) {}
				
				
				inr++;
				i++;

			}
			U.log("S/w michigan"+cv);
		
		U.log(i);
		LOGGER.DisposeLogger();
		//driver.quit();
	}

	private void addDetails(String url,String info) throws Exception {

//		if(j>=93 && j<=120)//dd
			
//		if(j > 200)
//		try{	
//			if(j>=70 && j<=120)//c
	//		if(j>=43 && j<=100)//c
//				if(j>=100 && j<=150)//c
//		if(j>=152 && j<=240)//c dd
			
			 //if(j <= 50 )
			//if(j >= 50 )
			//if(j >= 150 )	
		{
			//TODO :
//			if(!url.contains("https://www.allenedwin.com/livingston-community-detail/Red-Cedar-Crossing-West-135269"))return;

			
			U.log(j+"::\tPAGE :" + url);
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "\t*********Repeated******\t");
				duplicates++;
				return;
			}
			LOGGER.AddCommunityUrl(url);
			 if(url.contains("https://www.allenedwin.com/communities/all-communities/gilmore-farms/"))return;//contains data of Centennial
			 if(url.contains("https://www.allenedwin.com/communities/all-communities/emerald-glen-of-manchester/"))return;
			 if(url.contains("https://www.allenedwin.com/communities/all-communities/centennial/"))return;

			 //{
//			String html = getHtml(url,driver);
			 String html = U.getHtml(url,driver);
			U.log("CACHE: "+U.getCache(url));
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, driver);
			if(units.equals("0"))
				units=ALLOW_BLANK;
			//---------------------------------------------------------
			
//			 U.log(info);
			String remove1=null;
			String[] remSec=U.getValues(html, "Move-in Ready<span class=\"icon icon-angle-down\"></span>", "data-auto=\"page-text-style\">CORE REALTORS");
			for(String rem1:remSec) {
				remove1+=rem1;
			}
			html=html.replace(remove1, "");
					
					
					// commName			
			String commName =U.getSectionValue(info, "<span class=\"card_title \" card_link\"=\"\">", "<");
			if(commName.endsWith("Villas"))commName=commName.replace("Villas", "").replace("–", "-");
			U.log("CommName:" + commName);

//			//================= Combined Home Html =================
			String allPlanHtml = ALLOW_BLANK;
			String planhtml=ALLOW_BLANK;
//			if(html.contains("<div class=\"card_row card-row-3 \" id=\"card_row_")) {
//			String[] plans = U.getValues(html, "<div class=\"card_row card-row-3 \" id=\"card_row_",">See Details</span>");
//			U.log("Plans count=="+plans.length);
//			for (String plan : plans) {
//				try {
//				String planurl = U.getSectionValue(plan, "href=\"", "\"");
//				planurl = planurl.replace("&amp;", "&");
//				planurl = "https://www.allenedwin.com" + planurl;
//				U.log("planurl::"+planurl);
//				planhtml = getHTML(planurl);
//				allPlanHtml += U.getSectionValue(planhtml, "bind-applied=\"true\"> <h1 class=\"size-40 m-size-32\">", "<h2><span style=\"display: initial;\">Plan Detail</span></h2>")+U.getSectionValue(planhtml, "<div id=\"homeDetail\">", "<div class=\"topRight\">");
//				allPlanHtml += U.getSectionValue(planhtml,"<div id=\"allWrapper\" class=\"allWrapper\">","<h2><span style=\"display: initial;\">Photo");
//				//U.log(U.getSectionValue(planhtml, "<div class=\"detailPage", "<div class=\"salesAddress blockBorder\">"));
//				//if(i==8)break;
//				i++;}
//				catch(Exception e) {}
//			}
//			}
			String homeHTML=null;
			U.log("url===="+url);
			String latSecfromPlanJSON = ALLOW_BLANK;
			String planUrl = U.getSectionValue(url, "https://www.allenedwin.com/", "-community-detail");
			U.log("********"+planUrl);
			String newPlanUrl="";
			if(planUrl.contains("-")) {
				String sect[] = planUrl.split("-");
				for(String sec: sect) {
					newPlanUrl+=StringUtils.capitalise(sec)+" ";
				}
			}else
				newPlanUrl = StringUtils.capitalise(planUrl)+" ";
			U.log(newPlanUrl);
			String siteAlias = U.getSectionValue(html, " SiteAlias: '", "'");
			planUrl = "https://www.allenedwin.com/_dm/s/rt/actions/sites/"+siteAlias+"/collections/"+newPlanUrl+"Homes";
			int homeCount=0;
			planUrl = planUrl.replace("Gr%20Homes", "GR%20Homes").replace("Washtenaw", "Washtenaw County").replaceAll("Livingston", "Livingston County").replaceAll("Genesee Oakland ", "Genesee-Oakland ").replace("Se%20Homes", "SE%20Homes");
			//U.log(">>>>>>>>>>>planUrl  "+planUrl);
			String regplanHtml= U.getPageSource(planUrl);
			regplanHtml = regplanHtml.replace("\\\"", "\"");
			String plandata[]= U.getValues(regplanHtml, "{\"uuid\":", "page_item_url");
			U.log(plandata.length);
			for(String plan : plandata) {
				
				if(plan.contains(commName.trim())) {
					
					latSecfromPlanJSON=plan;
					allPlanHtml+=plan;
					homeCount++;
				}
				
			}
			U.log(homeCount);
			allPlanHtml = allPlanHtml.replaceAll("footerAnchor|branch|RegisterAnch|\\d+ Ranch", "");
//			U.log(Util.match(allPlanHtml, ""));
			
			
			
			String[] homeSec=U.getValues(html, "<div><a class=\"card_anchor\"", "<div id=\"card_image_container");
//			U.log("len======"+homeSec.length);
//			for(String homsec : homeSec)
//			{
//				String homeURL=U.getSectionValue(homsec, "href=\"", "\"");
//				String homeUrl="https://www.allenedwin.com"+homeURL;
//				U.log("::::::::::"+homeUrl);
//				homeHTML+=U.getPageSource(homeUrl);
////				U.log("::::::::::"+homeHTML);
//			}
//			U.log("mmmmmm"+Util.matchAll(homeHTML, "[\\w\\s\\W]{30}story[\\w\\s\\W]{30}", 0));
//	
//			//================= Price ====================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			html=U.removeSectionValue(html, "<!-- ========= JS Section ========= -->", "</body>");
			
			if(url.contains("lakeshore-community-detail/Arborwood-115880")) {
				allPlanHtml=allPlanHtml.replaceAll("325900\"", "");
			}
			
			html=html.replaceAll("Hometown Plans From \\$219,900|Integrity Plans From \\$221,900|Elements Plans From \\$265,900|Traditions Plans From \\$326,900", "");
			html = html
					.replaceAll("Integrity Plans From \\$\\d{3},\\d{3}&#10;|Integrity Plans From \\$\\d{3},\\d{3}|Elements Plans From \\$\\d{3},\\d{3}|"
							+ "Traditions Plans From \\$\\d{3},\\d{3}", "")
					.replaceAll("0’s|0k|0&rsquo;s", "0,000").replaceAll("’s|'s.", ",000").replace("$200’s", "\\$200,000");
			
			String[] price = U.getPrices(html+allPlanHtml,
								"Starting at</span> \\$\\d,\\d{3},\\d{3}|from the mid \\d{3},\\d{3}|from the low \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|\\$(\\d+,\\d+)|Price:</td><td><strong>\\$(\\d+,\\d+)|<td><strong>\\$[0-9]{2},[0-9]{3},[0-9]{3}|dealPrice\">\\$\\d{3},\\d{3}|\"PriceLo\":\"\\d{6}\"|\"PriceHi\":\"\\d{6}\"",
								0);
			
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{100}999,000[\\w\\s\\W]{100}", 0));
//			U.log("mmmmmm"+Util.matchAll(allPlanHtml, "[\\w\\s\\W]{100}999,000[\\w\\s\\W]{100}", 0));
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			

			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//
//			//=================== Sqft ===========================	
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			
			
//			U.writeMyText(html);
			html =html.replaceAll("</span>\\s*<span id=\"suffix-text-1\" class=\"suffix-api-text\">Sq. Ft.", " Sq. Ft.");
//			if(allPlanHtml!= null)
//				allPlanHtml = allPlanHtml.replaceAll("\\d{1},\\d{3} square foot ranch", "");
			String[] sqft = U.getSqareFeet(html+homeHTML+allPlanHtml,
					"over \\d{4} sq. ft.|over \\d,\\d{3} sq. ft.|\\d{4} - \\d{4} Sq. Ft.| \\d,\\d{3} square foot|area\">\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d,\\d{3} sq.ft. to over \\d,\\d{3} sq.ft|\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*SQ FT|\\d+,\\d+ - \\d+,\\d+  Square Feet|\\d+,\\d+ Square Feet|(Size: \\d{1},\\d{3})|\\d,\\d+ square feet|\"SftLo\":\\d{4}",0);
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}2735[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(homeHTML, "[\\w\\s\\W]{30}features over 2,700[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(allPlanHtml, "[\\w\\s\\W]{100}features over 2,700[\\w\\s\\W]{100}", 0));

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//		
//			
//			//============= Property Type ==========================
			String propertyType = ALLOW_BLANK;
			String javaScripts[] = U.getValues(html, "<script>", "</script>");
			for(String script:javaScripts) {
				html=html.replace(script, "");
			}
			html = html.replaceAll("HOA dues are additional and not", "").replace("custom landscape plan", "custom plan").replaceAll("footerAnchor|systemaggregatedgaqid| Elements, Traditions|apiText = \".*\";", "").replace("feel of an executive retreat", "executive home sites")
					;//.replace("small lake", "small lakeside community")//.replace("lakeshore living", "lakeside community living")
		
//			U.log("mmmmmm"+Util.matchAll(homeHTML+allPlanHtml + html, "[\\w\\s\\W]{60}Homeowners Association[\\w\\s\\W]{60}", 0));

			
			propertyType = U.getPropType((html+homeHTML+allPlanHtml).replaceAll("HOA dues are additional|-Village-Homes-|village|Village|footerAnchor|systemaggregatedgaqid|gaaggregatedeventattributes|gaaggregatedeven| aggregated| Elements, Traditions|apiText = \".*\";", "").replace("traditional-yet-open floor", "Traditional Homes").replace("this traditional", "Traditional Homes"));//single family present in plans
			U.log(propertyType);
			
			
			
			
//			//========== Lat Long ===============
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String latSec = U.getSectionValue(html, "https://www.google.com/maps/place/", "\"");
			String latlng[] = {ALLOW_BLANK,ALLOW_BLANK};
			if(latSec!=null) {
				latlng =latSec.split(",");
				lat = latlng[0];
				lng = latlng[1];
			}
//			if(lat==ALLOW_BLANK && latSecfromPlanJSON!=ALLOW_BLANK) {
//				lat = U.getSectionValue(latSecfromPlanJSON, "\"Lat\":\"", "\"");
//				lng = U.getSectionValue(latSecfromPlanJSON, "\"Lng\":\"", "\"");;
//			}Villa
			String Geo = "True";

			U.log("Lati :" + lat + " Long:" + lng);

//			
//		
//			//=============== Derived Type ========================
			html=html.replace(" spit level floor", " split level floor").replaceAll("footerAnchor|RegisterAnch", "");

			String dPtype = U.getdCommType((homeHTML+allPlanHtml + html).replaceAll("one level of this gorgeous ranch|first floor|First Floor|footerAnchor|RegisterAnch", ""));
//			U.log("mmmmmm"+Util.matchAll(homeHTML+allPlanHtml + html, "[\\w\\s\\W]{30}story[\\w\\s\\W]{30}", 0));
//
//			//============= Addres ====================
			U.log("///////////");
			String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
			String[] add = { street, city, state, zip };
//			String latlng[] = { lat, lng };
//			
		//	U.log(add);
			//String addressSec = U.getSectionValue(html, "homeAddress h2Styles", "</div>");
//			U.log("addressSec : "+info);
			/*if(addressSec != null)
			{*/
//			add[0] = U.getSectionValue(info, "<span class=\"addressStreet\">", "</span>");
//			if(add[0].length()<2)add[0]=ALLOW_BLANK;
//			add[1] = U.getSectionValue(info, "<span itemprop=\"addressLocality\">", "</span>");
//			add[2] = U.getSectionValue(info, "<span itemprop=\"addressRegion\">", "</span>");
//			add[3] = U.getSectionValue(info, "<span itemprop=\"postalCode\">", "</span>");
			//}
//			if(url.contains("")) {
//				add[0]=null;
//				add[1]="Plymouth";
//				add[2]="IN";
//				add[3]="46563";
//			}
//			String addSec= U.getSectionValue(html, "<span class=\"address-text\">", "</span>");//U.getSectionValue(info, "<a href=\"https://www.google.com/maps?z=18&amp;q=", "\"");
			String addSec= U.getSectionValue(html, "<span class=\"address-text\">", " </a></div>");
			
			if(addSec!= null) {
			addSec = addSec.replace("165 Greenly St, Holland, MI 49424,Holland,MI,49424", "165 Greenly St,Holland,MI,49424");
			}
			if(addSec == null) {
				addSec= U.getSectionValue(html, "<span class=\"address-text\">", "</span>");
			}
			
			U.log("addSec: "+addSec);
//			add = addSec.split(",");//
			if(addSec != null) {
				addSec=U.getNoHtml(addSec);
				add=U.getAddress(addSec);
			}
			
			if (add[0]==ALLOW_BLANK) {
				String addressSec=U.getSectionValue(html, "<div class=\"communityAddress \">", " </div>");
				if(addressSec!=null)
				add[0] = U.getSectionValue(addressSec, "<span class=\"addressStreet\">", "</span>");
				
			}
			Geo = "false";
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]+ " Z:" + add[3]);
			
			if(add[0]==null)add[0] = ALLOW_BLANK;
			add[0] = add[0].replace("ramp", "Ramp").replace("&amp;", "&").replace("null", "");
			if(add[0].length()<4)
			{
				String[] add1 = U.getAddressGoogleApi(new String []{lat ,lng});
				if(add1 == null) add1 = U.getAddressHereApi(new String []{lat ,lng});
				add[0] = add1[0];
				Geo = "True";
			}
			add[1] = add[1].replace(",", "");
			
			//U.log(html);
			
			
//			//============= Property Status =======================
//			
			String movesec = ALLOW_BLANK;
			String statSec = html;
			String remove = "<strong>Coming Soon</strong>|facilities is under construction|BigHeader\">Move-In Ready Homes|sortcaption\">Move-In Ready Homes|\"Move in Ready Homes|School, is now open|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
			info = info.replace("NEW &amp; FINAL PHASE NOW AVAILABLE", "NEW and FINAL PHASE NOW AVAILABLE").replace("New Phase Coming Fall of 2021", "New Phase Coming Fall 2021").replace("COMING SPRING 2</p>", "COMING SPRING 2020</p>").replace("NEW PHASE & NEW MODEL NOW AVAILABLE", "NEW PHASE NOW AVAILABLE");

			statSec = statSec.toLowerCase()	.replaceAll(remove.toLowerCase(), "");
		//	U.log("mmmmmm"+Util.matchAll(statSec+info,"[\\w\\s\\W]{30}MOVE-IN READY[\\w\\s\\W]{30}", 0));
			String	status = U.getPropStatus((statSec + info).replaceAll("MOVE-IN READY|data-link-text=\"\n\\s*move-in ready\\s*\"|home floorplans and move in ready homes|/move-in-ready|Wrapper\">Move In Ready|/move-in-ready/|move in ready|large homesites available in th\" />|qmis\">Homes Available|class=\"\">Homes Available|acre lots".toLowerCase(),""));

//			if((html.contains(">Homes Available Now</span></h2> ") || html.contains("Request More Information</span></button></div><div><a href=\""))&& !status.contains("Homes Available Now")){
//				if(status.length()<5){
//					status="Move-in Ready";
//				}
//				else{
//					status="Move-in Ready, "+status;
//				}
//			}
      U.log("status====="+status);
      if(status.contains("Final Phase, Almost Sold Out"))status=status.replace("Final Phase, Almost Sold Out", "Final Phase Almost Sold Out");
	     	 String availSec=U.getSectionValue(html, "Homes Available Now<", "Media Gallery</span>");
	     	 if(availSec.contains("Request More Information</span></button></div><div><"))
	     	 {
	     		if(status.length()<5){
					status="Move-in Ready";
				}
				else if(!status.contains("Move-in Ready")){
					status="Move-in Ready, "+status;
				}
	     	 }
	     
//	     	U.log("mmmmmm"+Util.matchAll(availSec, "[\\w\\s\\W]{30}Request More Information</span></button>[\\w\\s\\W]{30}", 0));
			
			U.log("???????"+status.length()+"::hello"+status+":::");
			
			
			
		
			//============== Community Type ====================
			html = html.replaceAll("systemAggregatedGaqID|gaAggregatedEventAttributes|gaAggregatedEventAttributes|aggregated|config.Gated|", "")
					.replace(
							"Skating Rink\" OR \"Golf Course\" OR \"Ice Rink\" OR \"Basketball Court\" OR Minigolf OR",
							"");
			String rem = U.getSectionValue(html, "var srchphrase=new Array",
					"var localSearch;");
	
			String remHtml = html;
			String Type = ALLOW_BLANK;
	
			if (rem != null)
				remHtml = html.replace(rem, "");
			
			remHtml=remHtml.replace("\"golf course\"", "");
		//	U.log("@@@@@@@"+remHtml);
			movesec=movesec.replace("\"golf course\"", "");
			
//				U.log("mmmmmm"+Util.matchAll(remHtml + movesec,"[\\w\\s\\W]{100}lakeside community[\\w\\s\\W]{60}", 0));

			Type = U.getCommunityType(remHtml + movesec);
			
//			if(url.contains("https://www.allenedwin.com/communities/all-communities/brighamwood/"))
//				status = "Only 1 Lot Available, "+status;
			
			status = status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			status=status.replace("New Phase Coming Soon, New Phase", "New Phase Coming Soon");
			status=status.replace("New Phase Coming, New Phase Coming Fall 2021", "New Phase Coming Fall 2021").replaceAll("Final Phase Almost Sold Out, Final Phase", "Final Phase Almost Sold Out");
           // status=status.replace(", Sold Out", ", Final Phase Almost Sold Out");
			
			
			if(commName.contains("Estates")) {
				if(propertyType.length()>4) {
					propertyType+=", Estate Style Homes";
				}
				else {
					propertyType="Estate Style Homes";
				}
			}
//			if(url.contains("https://www.allenedwin.com/communities/all-communities/applegate-woods")) {
//				status="New Phase Coming Fall 2021";
//			}
//			
//			if(url.contains("/all-communities/glockenberg-estates/")) {
//				status="Only 2 New Construction Homes Available";
//			}
	
			// Add all
			
			status=status.replace("New Phase Now Open, Now Open", "New Phase Now Open");
			if(status.contains("Move-in Ready, Move-in-ready"))status=status.replace("Move-in Ready, Move-in-ready", "Move-in-ready");
			
			
			String notes = ALLOW_BLANK;
			add[0]=add[0].replace(", Holland, MI 49424", "").toLowerCase();
			commName = commName.replace("Plan Library – Hometown", "Plan Library - Hometown");
			data.addCommunity(commName, url, Type);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lng, Geo);
			data.addPropertyType(propertyType, dPtype);
			data.addPropertyStatus(status.replaceAll("!", ""));
			data.addNotes(notes);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
//			j++;
		}
			
		j++;
		
//		}catch (Exception e) {}
		
		
	}
	
	public static String getUnits(String html, WebDriver driver) throws Exception {

		String totalUnits = ALLOW_BLANK; String mapUrl = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		
		if(html.contains("<li class=\"feature-list-title\">Lot Maps</li>")) {
			
			String mapUrlSec = U.getSectionValue(html, "<li class=\"feature-list-title\">Lot Maps</li>", "</a></li></ul></ul>");
			U.log("mapUrlSec: "+mapUrlSec);
			
			if(mapUrlSec != null) {
				mapUrl = U.getSectionValue(mapUrlSec, "<a href=\"", "\"");
				mapUrl = mapUrl.replace("&amp;", "&");
				U.log("mapUrl: "+mapUrl);
				
				if(mapUrl != null) {
					mapData = U.getHtml(mapUrl, driver);
				
					//for closed
					if(mapData.contains("class=\"mapplic-pin Closed open-point-tooltip")) {
						
						String[] lotOne = U.getValues(mapData, "class=\"mapplic-pin Closed open-point-tooltip", "\"");
						U.log("lotOne: "+lotOne.length);
						
						totalCount = totalCount + lotOne.length;
					}
					
					//for inventory
					if(mapData.contains("class=\"mapplic-pin Inventory open-point-tooltip")) {
						
						String[] lotTwo = U.getValues(mapData, "class=\"mapplic-pin Inventory open-point-tooltip", "\"");
						U.log("lotTwo: "+lotTwo.length);
						
						totalCount = totalCount + lotTwo.length;
					}	
					
					//for unreleased
					if(mapData.contains("class=\"mapplic-pin Unreleased open-point-tooltip")) {
						
						String[] lotThree = U.getValues(mapData, "class=\"mapplic-pin Unreleased open-point-tooltip", "\"");
						U.log("lotThree: "+lotThree.length);
						
						totalCount = totalCount + lotThree.length;
					}
					
					totalUnits = String.valueOf(totalCount);
					U.log("totalUnits: "+totalUnits);
				}
			}
		}
		
		return totalUnits;
		
	}
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		U.log(fileName);
		if (f.exists()) {
			 html = FileUtil.readAllText(fileName);
			 if(!url.contains("all-communities")) {
			 if(!html.contains("<div class=\"add-container\"><a href=\"")) {
				 f.delete();
				 html=getHtml(url,driver);
			 }}
			 return html;
		}

		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
										
					driver.get(url);
					Thread.sleep(5000);
					html = driver.getPageSource();
//					WebElement map=driver.findElement(By.xpath("//*[@id=\"map\"]/div/div/div[2]"));
//					if(!map.isDisplayed()) {
//						
//						driver.get(url);
//						Thread.sleep(2000);
//
//					}
//					for(int i =1 ; i<=4 ; i++){
//						try{	
//							
//							WebElement next = driver.findElement(By.xpath(" //*[@id=\"filtered\"]/div[2]/div/div/ul/li["+i+"]/a")); //next page
//							next.click();
//							html += driver.getPageSource();
//							Thread.sleep(2000);
//						}
////						catch(Exception e){
//							U.log("NExt page  not found");
//						}
//					}
					U.log("Current URL:::" + driver.getCurrentUrl());
					//html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();
					

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		
	}	
	
	public static String getHTML(String path) throws IOException, InterruptedException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);
		U.log(url);
		String html = null;

		// chk responce code

//		int respCode = CheckUrlForHTML(path);
//		 U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
//		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
//				"167.71.167.1", 8080));
		final URLConnection urlConnection = url.openConnection();
		Thread.sleep(2000);
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			urlConnection.addRequestProperty("Accept-Language",
				"en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Referer", "https://www.allenedwin.com/");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
//		    U.log(html);

			// final String html = toString(inputStream);
			inputStream.close();
			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}