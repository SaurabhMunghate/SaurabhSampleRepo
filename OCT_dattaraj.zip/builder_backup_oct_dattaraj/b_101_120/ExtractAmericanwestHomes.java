/**
 * @author Rakesh Chaudhari
 * @date  11/2/12
 * 
 */
package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractAmericanwestHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	int dup = 0;
	String Builder_Url = "https://www.americanwesthomes.com";

//	WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractAmericanwestHomes();
		a.process();
//		a.data().printAll();
		FileUtil.writeAllText(U.getCachePath() + "American West Development.csv", a.data().printAll());

	}

	public ExtractAmericanwestHomes() throws Exception {

		super("American West Development", "https://www.americanwesthomes.com");
		LOGGER = new CommunityLogger("American West Development");
	}

	public void innerProcess() throws Exception {

//		String html = getHtml("https://www.americanwesthomes.com/homes/nevada", driver);
		String html= U.getHTML("https://www.americanwesthomes.com/api/Community/ProductCommunitySearch?brand=AmericanWest&state=Nevada&region=&cityNames=&minPrice=&maxPrice=&minBedrooms=&maxBedrooms=&minBathrooms=&maxBathrooms=&homeType=&pageSize=150&pageNumber=0");
		String[] comSec = U.getValues(html, "class=\"ProductSummary__community row", "View Community");
		U.log(comSec.length);

		for (String com : comSec) {

			String comUrl = U.getSectionValue(com, "data-href=\"", "\"");
			if(!comUrl.startsWith("http"))
				comUrl = "https://www.americanwesthomes.com" + comUrl;
			U.log(comUrl);
			addDetails(comUrl, com);

		}

		LOGGER.DisposeLogger();

	}


	int j = 0;

	//TODO ::
	private void addDetails(String comUrl, String comSec) throws Exception {
	//	if(j>=15)
	//	try{
		{
			U.log("count::" + j + "\ncomUrl::" + comUrl);
			U.log("Path::" + U.getCache(comUrl));
			
//			if(!comUrl.contains("https://www.americanwesthomes.com/homes/nevada/las-vegas/las-vegas/quinn-canyon-210909")) return;

			if (comUrl.contains("www.pulte.com")) {
				LOGGER.AddCommunityUrl("*****************PulteHhome**************" + comUrl);
				dup++;
				return;
			}

			if (this.data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			String comHtml = U.getHTML(comUrl);

			String statusSec = U.getSectionValue(comHtml, "<h4 class=\"status\">", "</h4>");
			// U.log(comSec);

			// ======================================= remove
			// Sec==================================
			String rem = U.getSectionValue(comHtml, "nearbyMarkers =", "</script>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "community-name|AmericanWest\">", "<");
			U.log("Com Name::::::::" + comName);
			if (comName == null) {
				comName = U.getSectionValue(comHtml, "<h1>", "<");
			}
			if (comName == null) {
				comName = U.getSectionValue(comHtml, "\"community\":\"", "\"");
			}

			comName = comName.replace("Fox Hill Estates", "Fox Hill")
					.replaceAll("Del Webb at |Del Webb | By Del Webb|Del Webb&#174;  - |&#174;| by Del Webb","");
			
			U.log("Com Name Here::::::::" + comName);
			
			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String addSec = U.getSectionValue(comSec, "icon-pin-clear-filled\"></i>", "<");
			
			if(addSec != null) add = U.getAddress(addSec);
			if(addSec == null || add[0] == ALLOW_BLANK || add[0].length()<3) {
				
				addSec = U.getSectionValue(comHtml, "</h1>", "<br />");
				add = U.getAddress(addSec);
			}
			 
			if(addSec == null || add[0] == ALLOW_BLANK || add[0].length()<3) {
				
				add[0] = U.getSectionValue(comHtml, "streetAddress\">", "<").replace(",", "").trim();
				add[0] = U.getSectionValue(comHtml, "\"addressLocality\">", "<").replace(",", "").trim();
				add[0] = U.getSectionValue(comHtml, "\"addressRegion\">", "<").replace(",", "").trim();
				add[0] = U.getSectionValue(comHtml, "postalCode\">", "<").replace(",", "").trim();
			}

			
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latlong[0] = U.getSectionValue(comHtml, "\"Latitude\": \"", "\"");
			latlong[1] = U.getSectionValue(comHtml, "\"Longitude\": \"", "\"");

			if (add[0] == null && latlong[0] != null) {

				add = U.getAddressGoogleApi(latlong);
				geo = "TRUE";
			}
			if (add[0] != null && latlong[0] == null) {

				latlong = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			// ==============================================================Price &&
			// SF============================================
			// U.log(comSec);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec = comSec.replaceAll("0s|0S|0's|0&#39;s", "0,000");
			comHtml = comHtml.replaceAll("0s|0S|0's|0&#39;s", "0,000");
			comHtml = comHtml.replaceAll(
					"data-value u-no-empty-collapse stat-line\">\\s*\\$\\d+,\\d+\\s*</div>\\s*<div class=\"data-label\">Was|\\$\\d+,\\d+ in Savings|<div class=\"data-value u-no-empty-collapse\">\\s*\\$\\d+,\\d+\\s*</div",
					"");
			String[] prices = U.getPrices(comHtml + comSec,
					" <div class=\"starting-at-data\">\\s+\\$\\d,\\d{3},\\d{3}\\s+</div>|starting-at\">\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
					0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

			String[] sqft = U.getSqareFeet(comHtml,
					"\\d,\\d{3} - \\d,\\d{3}</span> sqft|\\d,\\d{3} - \\d,\\d{3} sf.|<h4>\\s+\\d{3}\\s+</h4>|\\d,\\d{3} � \\d,\\d{3} square feet|<div class=\"td\">\\d,\\d{3}</div>|from \\d,\\d{3}–\\d,\\d{3} sq.ft.|\\d{1},\\d{3} to more than \\d{1},\\d{3} Sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} Sq.Ft.|\\d{4}-\\d{4} SF|\\d{1},\\d{3}–\\d{1},\\d{3} sq. ft.|<h4>\\d{1},\\d{3}</h4>|<h4>\\d{3,4}</h4>|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}\\+ Square Feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+\\+ sq. ft.|\\d,\\d+ to \\d,\\d+\\+ square feet|\\d,\\d+-\\d,\\d+\\+ Sq. Ft.|\\d+ - \\d+\\+ Square Feet|\\d,\\d+-\\d,\\d+\\+Square Feet|\\d,\\d+-\\d,\\d+\\+Sq. Ft.|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+\\+ Sq. Ft.|\\d{1},\\d{3} Square Feet|\\d,\\d+-\\d,\\d+ S.F.|\\d{4}-\\d{4} sq ft|From \\d{1},\\d{3} sq. ft|<h4>\\s*\\d,\\d{3}\\+*\\s*</h4>|ranging from \\d,\\d{3}-\\d,\\d{3} sq ft|homesite, at least \\d+,\\d{3} sf",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);

			// ============= Home Data =================
			String homeUrlSection[] = U.getValues(comHtml, "HomeDesignCompact__title\">", "</div>");
			int x = 0;
			String combinedHomeHtml = null;
			for (String homeSec : homeUrlSection) {
				String homeUrl = U.getSectionValue(homeSec, "<a href=\"", "\"");
				if (!homeUrl.contains("http"))
					homeUrl = Builder_Url + homeUrl;
				
//				U.log("homeurl>>>>>>>>>>>>>>>>>>>>>>"+homeUrl);
				
				if (x++ == 5)
					break;
				U.log("homeUrl ::" + homeUrl);
				String homeHtml = U.getHTML(homeUrl);
				try {
					combinedHomeHtml += U.getSectionValue(homeHtml, "data-description=\"", "\"")
							+ U.getSectionValue(homeHtml, "<div class=\"Inspiration-copy\">", "</button>");
				} catch (Exception e) {
				}
			}
			// ==============================================================Community
			// type============================================
			comHtml = comHtml.replaceAll("luxurious owner&#39;s suites|Luxurious Owner&#39;s", "luxury homes")
					.replaceAll("data-index=\"\\d+\" data-option=\"HOA\">HOA|container\" data-option=\"HOA\"|participation","");
			
			comHtml = U.removeSectionValue(comHtml, "<div class=\"Disclaimer", "</body>");
			comHtml = U.getNoHtml(comHtml);
			String comType = ALLOW_BLANK;
			comType = U.getCommType((comHtml.replace("&amp;", "&") + comSec).replaceAll("Pulte Homes&#174; Active Adult|Active Adult</a>", ""));

			// ==============================================================Property
			// type============================================

			String propType = ALLOW_BLANK;
			if(combinedHomeHtml!=null)
				combinedHomeHtml = combinedHomeHtml.replace("touch of luxury ", "luxury home").replaceAll("Custom designer cabinets|where custom cabinetry|customize your new home", "");
			
			comHtml = comHtml.replaceAll("analytics-cta=\"HOA\">HOA|option=\"HOA\"", "").replace("Spacious Game Room Loft", "loft/game room")
					.replace("luxurious owner and guest suites", "luxury homes owner and guest suites");
			comHtml=comHtml.replaceAll("Walk-In Customers Welcome|Customer Service", "");
			comSec=comSec.replaceAll("Walk-In Customers Welcome", "");
			

			propType = U.getPropType((comHtml + comSec + combinedHomeHtml).replaceAll("insurance and HOA fees not included", "")
					.replace("Find new homes in both contemporary and traditional styles", "Find new homes in both contemporary and traditional homes styles")
					.replaceAll("Choose from three home designs in modern or traditional styles", "modern or traditional homes styles"));
			
			U.log("::::::::::::::::::::::propType: "+propType);
//			U.log("mmmmmm"+Util.matchAll(comHtml + comSec , "[\\w\\s\\W]{50}traditional[\\w\\s\\W]{30}", 0));
			U.log(propType+">>>>>>>>>>"+Util.matchAll(comHtml + comSec + combinedHomeHtml, "[\\s\\w\\W]{60}HOA[\\s\\w\\W]{60}",0));
//			U.log(propType+">>>>>>>>>>"+Util.matchAll(comHtml + comSec + combinedHomeHtml, "[\\s\\w\\W]{60}Courtyard[\\s\\w\\W]{60}",0));

			// ==============================================================D-Property
			// type============================================
			String dType = ALLOW_BLANK;

			comSec = comSec.replace("1-3 Story Homes", " 1 Story 3 Story homes");
			
			comHtml = comHtml.replace("one-and two-story", "1 Story 2 Story").replaceAll("LocationSelectionData.locations =(.*?)}\\];", "").replace("one, two, and three-story floorplans", "one story, two story, and three story floorplans").replace("One-to three-story", "One-story three-story")
					.replaceAll("two, and three-story|two-and three-story", "two story , and three-story");// remove script
//			U.log("MMMMMMMMM"+Util.matchAll(comHtml, "[\\s\\w\\W]{50}first floor[\\s\\w\\W]{50}", 0));
//			U.log("MMMMMMMMM"+Util.matchAll(comSec, "[\\s\\w\\W]{50}first floor[\\s\\w\\W]{50}", 0));
//			U.log("MMMMMMMMM"+Util.matchAll(combinedHomeHtml, "[\\s\\w\\W]{50}first floor[\\s\\w\\W]{50}", 0));
			dType = U.getNewdCommType((comHtml + comSec + combinedHomeHtml).replaceAll("First Floor Owner&#39;s|first floor|first floor owner|private first floor Owner’s Suite|-ranch-|North Ranch|Silverado Ranch", ""));

			// ==============================================================Property
			// Status============================================
			comHtml = U.removeSectionValue(comHtml, "Model Grand", "Request Info");

			comHtml = comHtml == null ? "" : comHtml;
			
			String propertyStatus = U.getNewPropStatus((statusSec + comSec + comHtml.replace("Now Open", ""))
					.replaceAll("Quick move-in homes|Quick Move Ins|Quick Move In|Quick Move-In|Quick Move-In (0)|Quick Move-in|no Quick Move-Ins|select Quick Move-in", "")
					.replaceAll("quick move-in|3 New Models Opening Soon|Move-Ins Available\"|Coming Soon\"|Price Coming Soon|Quick Move-Ins Available\"|your last chance|ur Model Homes and Quick Move-in Homes are Ope|The Hayden Coming Soon|Price Coming Soon|Quick Move-In|There are no Quick Move-Ins available|\\d+ Coming ", "")
					.replaceAll("<img cla, arousel\">\\s+Sold Out, Sold Out|Sold Out\\s+<img cla", "")
					.replaceAll("data-automation=\"\">Sold Out|homes now available|CommunityStatus\":\"Sold Out|New Homesites Available", ""));
			
			//U.log("MMMMMMMMM"+Util.matchAll(statusSec + comSec + comHtml, "[\\s\\w\\W]{50}Quick move[\\s\\w\\W]{50}", 0));
			U.log("propertyStatus: "+propertyStatus);
			
//			if(!propertyStatus.contains("Quick")) {
//				
//				if(!comHtml.contains("There are no Quick Move-Ins available"))
//					if(propertyStatus == ALLOW_BLANK) propertyStatus = "Quick Move-in";
//					else if(propertyStatus != ALLOW_BLANK) propertyStatus = propertyStatus + ", Quick Move-in";
//			}

//			if(comUrl.contains("https://www.americanwesthomes.com/homes/nevada/las-vegas/las-vegas/wesley-park-210657"))propertyStatus = propertyStatus.replaceAll(", Quick Move-in", "");
//			if(comUrl.contains("https://www.americanwesthomes.com/homes/nevada/las-vegas/las-vegas/southbrook-210358"))propertyStatus = propertyStatus.replaceAll(", Quick Move-in|Quick Move-in|", "");
			if(comUrl.contains("https://www.americanwesthomes.com/homes/nevada/las-vegas/las-vegas/quinn-canyon-210909"))minPrice="$519500";
			if(propertyStatus==null || propertyStatus.length()<3)
				propertyStatus = ALLOW_BLANK;
			
			String notes = U.getnote(comHtml);
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]).trim();
			}

			if(add[0]!=null)
				add[0] = add[0].replace("&amp;", "&");
			
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			String jsonLink = ALLOW_BLANK; String jsonData = ALLOW_BLANK;
			int totalUnits = 0;
			
			
			String comhtml = U.getHTML(comUrl);
			//U.log("comhtml: "+comhtml);
//			FileUtil.writeAllText("/home/shatam-50/Desktop/comdata.txt", comhtml);
			
			if(comhtml.contains("<h2></strong>Homesite Map</strong> </h2>")) {
				String unitSection = U.getSectionValue(comhtml, "<h2></strong>Homesite Map</strong> </h2>", "Open Interactive Map");
				U.log("unitSection: "+unitSection);
				
				if(unitSection != null) {
					String mapUrl = U.getSectionValue(unitSection, "href=\"", "\"");
					U.log("mapUrl: "+mapUrl);
					
					if(mapUrl != null) {
						if(mapUrl.contains("OLAId=") && mapUrl.contains("&amp")) {
							String subMapUrl = U.getSectionValue(mapUrl, "OLAId=", "&amp");
							U.log("subMapUrl: "+subMapUrl);
							
							String jsonUrl = "https://apps.alpha-vision.com/olajson/" + subMapUrl + ".json";
							U.log("jsonUrl_One: "+jsonUrl);
							jsonLink = jsonUrl;
						}
						else {
							String[] sub =  mapUrl.split("OLAId=");
							String subMapUrl = sub[1];
							U.log("subMapUrl: "+subMapUrl);				
							
							String jsonUrl = "https://apps.alpha-vision.com/olajson/" + subMapUrl + ".json";
							U.log("jsonUrl_Two: "+jsonUrl);
							jsonLink = jsonUrl;
						} 
						
						U.log("jsonLink: "+jsonLink);
						
						if(jsonLink != ALLOW_BLANK) {
							jsonData = U.getPageSource(jsonLink);
							U.log(U.getCache(jsonLink));
							
							String[] lotCounts = U.getValues(jsonData, "\"LotCount\":", ",\"");
							U.log("lotCounts: "+lotCounts.length);
							for(String lot:lotCounts) {
								U.log(lot);
								int lotCount = Integer.parseInt(lot);
								totalUnits = totalUnits + lotCount;
			
							}
							U.log("totalUnits: "+totalUnits);
							units = String.valueOf(totalUnits);
							U.log("Total Units: "+units);
						}
						
					}
					
				}
				
			} 
			
			if(comUrl.contains("https://www.americanwesthomes.com/homes/nevada/las-vegas/las-vegas/brentwood-210360")) propertyStatus = ALLOW_BLANK;
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(notes);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
			
		}
		j++;
//		}catch(Exception e){}
	}

}