/*
 * Parag Humane
 * 2/08/2013
 */
package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import org.apache.bcel.generic.SWITCH;

public class ExtractBallHomes extends AbstractScrapper {
	Connection con;
	int k = 0;
	static int index = 0;
	public int inr = 0;
	static int j=0;
	private static final String builderUrl = "https://www.ballhomes.com";
	WebDriver driver = null;
	CommunityLogger  LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractBallHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ball Homes.csv", a.data().printAll());
	}

	public ExtractBallHomes() throws Exception {
		super("Ball Homes", "https://www.ballhomes.com");
		LOGGER = new CommunityLogger("Ball Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String html = U.getHTML(builderUrl);
		String regSection = U.getSectionValue(html, "Locations</a><ul>", "</ul>");
		String [] regUrls = U.getValues(regSection, "<a href=\"", "\"");
		for(String regUrl : regUrls){
			U.log(regUrl);
			String regHtml = U.getHTML(builderUrl+regUrl);
			String comSection = U.getSectionValue(regHtml, "<div id=\"insideRight\"", "<div class=\"bh-wrapper-bottom");
			String [] comUrls = U.getValues(comSection, "community\"><a href=\"", "\"");
			U.log(comUrls.length);
			for(String comUrl : comUrls){
				U.log(comUrl);
				
//				try {
					addInfo(builderUrl+comUrl);
//				} catch (Exception e) {}
			
			}
			break;
		}

//		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private void addInfo(String comUrl) throws Exception {
//		if(j  >= 0 && j<=5) 
		{
		
//		if(!comUrl.contains("https://www.ballhomes.com/Locations/Sanders_Garden/")) return;
		
		
//		try{
			U.log(U.getCache(comUrl));
		U.log("\nPAGE    :"+j +"  " + comUrl);
	//	U.log(U.getCache(comUrl));
		String html = U.getHtml(comUrl, driver);
		if(html.contains("<a id=\"ctl00_contentMain_communitySideNav1_lnkFeatures\"")) {
			String featureurl=comUrl+U.getSectionValue(html, "<a id=\"ctl00_contentMain_communitySideNav1_lnkFeatures\" href=\"", "\">");
//			U.log("featureurl");
			String featurehtml=U.getHtml(featureurl, driver);
			featurehtml=featurehtml.replaceAll("[C|c]oming [S|s]oon|carriage|now available", "");
			html=html+U.getSectionValue(featurehtml, "<div class=\"features\">", "</tbody>");
			
		}

		String rem = U.getSectionValue(html, "<html", "<body");
		if(rem != null)
			html = html.replace(rem, "");
		//=============== community name ======================================
	//	String comm[] = U.getValues(html, "class=\"communityName\">", "</");
		String commuName = U.getSectionValue(html, "    (new app.Map({ name: \"","\"");  //.toLowerCase();
		if(commuName.endsWith("villas"))commuName=commuName.replace("villas", "");
		if(commuName!=null)
			commuName = commuName.replaceAll("Coming Late Fall 2022! |Coming Fall 2022! |Coming Late Summer 2022!|Coming Late Spring 2022!|Coming Late Spring 2022! ", "");
		U.log("community name:" + commuName);

		//============== Address ===========================
		String[] add = { "3609 Walden Drive", "Lexington", "KY", "40517" };

		String geo = "TRUE";

		String lat = U.getSectionValue(html, "lat:", ",").trim();
		String lng = U.getSectionValue(html, "lng:", "}").trim();
		String[] LL = { lat, lng };
		add = U.getAddressGoogleApi(LL);
		if(add == null)
			add = U.getGoogleAddressWithKey(LL);
/*		if (add == null) {
			String latlng[] = { lat, lng };
			add = U.getAddressGoogleApi(latlng);

		}
*/		
		String quickHome = U.getHTML("https://www.ballhomes.com/api/quickMoveHomes/index");
		String[] qHomes = U.getValues(quickHome, "\"quickMoveId\":", "\"agent\":");
		String quickData = "";
		for(String home: qHomes) {
			if(home.contains(commuName)) {
			U.log("------------------------");
			quickData+=home;
			}
		}
		
		
		
		//=========== Price ====================
		String quickHtml=ALLOW_BLANK;
		if(html.contains("ctl00_contentMain_communitySideNav1_lnkQuickMoveHomes")){
			String quickUrl=U.getSectionValue(html, "<a id=\"ctl00_contentMain_communitySideNav1_lnkQuickMoveHomes\"", "Quick Move Homes</a>");
			quickUrl="https://www.ballhomes.com"+U.getSectionValue(quickUrl, " href=\"", "\"");
			U.log("quickUrl::"+quickUrl);
			quickHtml=getHtml(quickUrl,driver);
			U.log("quick PAth:"+U.getCacheFileName(quickUrl));
		}
		
		
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replaceAll("0's|0s", "0,000s");
		//U.log(quickHtml);
		int q=0;
		String quickValue = "";
		if(quickHtml!= null) {
			
			String[] value = U.getValues(quickHtml, "<td class=\"qm-cell\">", "</div> </td> </tr>");
			U.log("value==="+value.length);
			for(String val : value) {
				if(val.contains("September"))
				{
					q++;
				}
				
				if(val.contains(commuName)) {
//					U.log("val==="+val);
					String url=U.getSectionValue(val, "propertyListingUrl\" class=\"ng-scope\"> <a href=\"", "\"");
					U.log("qurl==="+url);
					if(url!=null) {
					String qHtml=U.getHTML(url);
					quickValue +=val+"\n"+U.getSectionValue(qHtml, "<div class=\"si-ld-top js-top-nav\">", "section class=\"si-ld-calculator is-collapse")
					+"\n"+U.getSectionValue(qHtml, "<h2>Community Information</h2>", "</section>")
					+"\n"+U.getSectionValue(qHtml, "<div class=\"property-details-description__text\">", "</p>")
					+"\n"+U.getSectionValue(qHtml, "property details\n"
							+ "                </h2>", "<div class=\"property-details-disclaimer aem-GridColumn aem-GridColumn--default--")
					+"\n"+U.getSectionValue(qHtml, " <div class=\"bootstrap desktop-facts-contact\">", " <a id=\"contactForm\"></a>");
//					U.log("quickValue==="+quickValue);
//					break;
					}
				}
			}
		}
		
		U.log("qqqqq==="+q);
		//====================== Sqft =======================
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				
				quickValue=quickValue.replaceAll("Sq. Feet:</strong><span>| Sq. Ft.\n"
						+ "                            </div>\n"
						+ "                            <div class=\"td \">\n"
						+ "                                ", " Sq. Ft. ");
				
				String[] sqft = U.getSqareFeet(html+quickValue,
								"\\d,\\d{3} square feet|Sq. Ft. \\d,\\d{3}|\\d{4}</span> Sq. Ft. Living Space|\\d{4} Sq. Ft.|\\d{4}sf|\\d{4} to over \\d{4} square feet|\\d{4} to \\d{4} square feet|[0-9]{4} to [0-9]{4} square foot homes",
								0);
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		
		String[] price = U.getPrices(html+quickValue+quickData,
						"\"price\": \\d{6}|<strong>Price: |Price:</strong> \\$\\d+,\\d+|At: </strong>\\$\\d+,\\d+|\\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		//========== Property Status ================
//		U.log("MMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(quickValue, "[\\w\\s\\W]{100}2,639 square feet[\\w\\s\\W]{100}", 0));
		
		html = html.replace("Now available!&nbsp; Wyndover Hills", "Now available  Wyndover Hills")
				.replaceAll("comm-desc\">Coming Soon!  Quick Move Homes are under construction|See Quick Move|limited availability!\"|Now available!|Hills Now Available|data-title=\"Coming Soon|content=\"New homes available |content=\"Ball Homes now available|content=\"New Homes available from Ball Home|content=\"Ball Homes are now available|Notify Me of New Releases", "").replace(">Grand Opening! Gallery of Homes ", "");
		String dropsec=U.getSectionValue(html, "href=\"/Communities/\">Communities</a><ul>", ">Contact Us</a><");
		if(dropsec!=null)
		html=html.replace(dropsec, "");
		
		//html=html.replace("limited number of homes remain", "Limited Homes Remain");
				
		html=html.replace("The Trend Collection is now available", "").replace("limited number of homes remain available", "Limited Homes Available").replace("Coming in Spring 2019", "Coming Spring 2019")
				.replace("final phase to be developed in late 2022", "final phase late 2022")
				.replaceAll("Trend Collection at Old Oxford</a> now available", "");
		
		
		String commStatus = U.getPropStatus(html);
//		
//		U.log("MMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{60}final phase[\\w\\s\\W]{60}", 0));

		
		U.log("Status::"+commStatus);
//		if(!quickData.contains(commuName)){
////			if(commStatus.length()<3){
////				commStatus="No Quick Move Homes";
////			}else{
////				commStatus=commStatus+", No Quick Move Homes";
////			}
//		}else {
			if(q>0){
				if(commStatus.length()>3)
			{
					commStatus=commStatus+", Quick Move Homes";
				
			}else{
				commStatus="Quick Move Homes";
			}
			}
//		}
		
		
				
		String featureHtml=ALLOW_BLANK;
		
		if(html.contains("Included Features</a>")){
			String featureUrl=comUrl+"Features/";
			U.log("featureUrl:::"+featureUrl);
			featureHtml=U.getHtml(featureUrl, driver);

			featureHtml=U.getSectionValue(featureHtml, "COMMUNITY FEATURES", "div id=\"communitySideNav");
			if(featureHtml != null)
				featureHtml=featureHtml.replaceAll("Village|Village|village", "");
		}
		
		String availHtml = "";
		String[] avais = U.getValues(html, "ng-binding\" href=\"", "\"");
		int x = 0;
		for(String avai : avais){
			U.log("avai::::"+avai);
			availHtml = availHtml + U.getHTML("https://www.ballhomes.com"+avai);
			if(x == 8)break;
			x++;
		}
		for (String avai : avais) {
			if (avai.contains("/Westmont_II_Expanded/")||avai.contains("/Westmont_II/")) {
				availHtml=availHtml+"one-story";
			}
		}
		String key = U.getSectionValue(html, "keywords", "/>");
		if (key != null)
			html = html.replace(key, "");
		html = html.replaceAll(
						"Village|Village|village| luxury master bath |/Villas/\">Villas<|Luxury_Townhomes/\">Luxury Townhomes<|Georgetown|luxury bath|luxury master bath|Luxury bath|luxury bath",
						"");
		availHtml =availHtml.replaceAll("Village|Village|village|adds a luxur|luxury bath| luxury touch|luxury master bath |/Villas/\">Villas<|Luxury_Townhomes/\">Luxury Townhomes<|Georgetown|luxury bath|luxury master bath|Luxury bath|luxury bath", "");
		//U.log("result:"+Util.match(availHtml, ".*?luxur.*?"));
		//String combineHtml = html + getStoryHtml(comUrl);
		//=========================Community Type=================================
		html=html.replace("plate glass mirrors and elongated commodes", "");
		String cType=U.getCommunityType(html+availHtml);
		
//		U.log("MMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}gated[\\w\\s\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(availHtml, "[\\w\\s\\W]{30}gated[\\w\\s\\W]{30}", 0));

		
		
		U.log("cType====="+cType);

		//============== Derived Community Type ================
		String adrop = U.getSectionValue(availHtml, "<!DOCTYPE html>", "<div id=\"insideHeaderFull\">");
		String adropfooter = U.getSectionValue(availHtml, " <div id=\"insideRight\">", "</html>");
		if(adrop==null)
			adrop = ALLOW_BLANK;
		if(adropfooter==null)
			adropfooter = ALLOW_BLANK;
		availHtml = availHtml.replace(adrop, "").replace(adropfooter, "");
		String dType = U.getdCommType(html.replaceAll("first floor guest suites|first floor master baths|first floor guest suite |several first-floor master plans", "") +availHtml.replaceAll("first floor|the first floor study|converted to a first floor guest|throughout the first floor|standard on the first floor|ceilings on the first floor|are also included on the first floor", "")+quickValue);
		U.log("dType: "+dType);
		//-----------Property TYpe---------------
		String propType = ALLOW_BLANK;
		html = html
				.replace("with open concept living and flexible spaces", "with open concept living and flex spaces")
				.replace(" have loft,", "the loft").replace("luxury", "luxury living");
		
		propType = U.getPropType((html+featureHtml+availHtml.replaceAll("villa|Villa","villas").replaceAll("luxury master|quicker than a traditional",""))
				.replace("Talbot floor plan is a traditional two story floor", "Talbot floor plan is a traditional style two story floor")
				.replace("home ownership both a traditional", "home ownership both a traditional style homes")+quickValue);
		U.log("propType: "+propType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(quickValue, "[\\s\\w\\W]{30}patio[\\s\\w\\W]{30}", 0));
		
		if(comUrl.contains("https://www.ballhomes.com/Locations/Edmonds_Cross/"))dType=dType+", Split Level";
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+":::::::::::::Repeated:::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		//U.log(":::::::::::::"+Util.match(availHtml,".*?villa.*?"));
		// Add ALL
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		html = html.replace(" rare lakeside setting", " rare lakeside community setting");
		if(comUrl.contains("https://www.ballhomes.com/Locations/Notting_Hill"))commStatus+=", Limited Opportunity";
		data.addCommunity(commuName.replace("Coming Soon! ", ""), comUrl, cType.replaceAll("Master suite|Masterson Station",""));
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(commStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(ALLOW_BLANK);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		}
		j++;
//		}catch(Exception e){U.log(e);}
//		}
	
	}


	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;
 		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(6000);
					
					Thread.sleep(6000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,document.body.scrollHeight)", ""); 
					Thread.sleep(6000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
//		 }
	}
	
}