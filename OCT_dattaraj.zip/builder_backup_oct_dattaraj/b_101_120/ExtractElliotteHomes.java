/**
 * @author Parag Humane 
 * @date 24/04/2013
 * 
 */
package com.shatam.b_101_120;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractElliotteHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	static int j = 0;
	WebDriver driver = null;

	private static final String builderUrl = "https://www.elliotthomes.com";

	public static void main(String[] args) throws Exception {
 
		AbstractScrapper a = new ExtractElliotteHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Elliott Homes.csv", a.data().printAll());
	}

	public ExtractElliotteHomes() throws Exception {

		super("Elliott Homes", "https://www.elliotthomes.com/");
		LOGGER = new CommunityLogger("Elliott Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHTML("https://www.elliotthomes.com/communities");
//		String regSection = U.getSectionValue(html, "Where We Build</a></li>", "<li><a href=\"/quick");
//		U.log(regSection);
//		String[] regUrlSection = U.getValues(html, "<div class=\"CommunityCard_wrapper\"", "</div></div></div>");
//		for (String regUrlSec : regUrlSection) {
//			String regUrl = U.getSectionValue(regUrlSec, "<a class=\"\" href=\"", "\"");
//			U.log(regUrl);
//			String regHtml = U.getHTML(builderUrl + regUrl);
//			String comSection[] = U.getValues(regHtml, "<div class=\"card regional__card", "Community <i class=\"btn__arrow btn__arrow-medium\">");
//			U.log(comSection.length);
//			for (String comSec : comSection) {
//				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
////				U.log(comUrl);
////				 U.log(comSec);
////				if(comUrl.contains("/master-planned/"))
////					findSubCommunity(builderUrl + comUrl, comSec);
////				else 
////					addDetails(builderUrl + comUrl, comSec);
//			}
//		}
		String comSection[] = U.getValues(html, "<div class=\"CommunityCard_wrapper\"", "</div></div></div></div></div><div class=\"");
		U.log(comSection.length);
		for (String comSec : comSection) {
			String comUrl = U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");
			U.log(comUrl);
//			if(comUrl.contains("/master-planned/"))
//				findSubCommunity(builderUrl + comUrl, comSec);
//			else 
			 addDetailsNew(builderUrl + comUrl, comSec.replaceAll("<!-- /react-text -->|<!-- react-empty: \\d+ -->|<!-- react-text: \\d+ --|data-reactid=\"\\d+\"", ""));
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	
//	private void findSubCommunity(String url, String sec) throws Exception{
//		String html = U.getHTML(url);
//		String comSection[] = U.getValues(html, "<a class=\"card__wrap\"", "<div class=\"text-right card__cta");
//		U.log(comSection.length);
//		for(String comSec : comSection){
//			String comUrl = U.getSectionValue(comSec, " href=\"", "\"");
//			 addDetails(builderUrl + comUrl, comSec);
//		}
//	}

	
	private void addDetailsNew(String url, String comSec) throws Exception {
//		 if(j==6)
//		try{
		{
			//TODO : Execute for single community
//	if(!url.contains("https://www.elliotthomes.com/communities/california/sacramento/turkey-creek-estates-custom-lots")) return;

			if (data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+ "------------  repeat");
				return;
			}
			if(url.contains("https://www.elliotthomes.com/communities/undefined/"))return;// not present on reg dt:20 Sep 21
			LOGGER.AddCommunityUrl(url);
			
			U.log("Count == "+j+"\r\nPAGE :" + url);

			String htm = U.getHtml(url, driver);
			U.log(U.getCache(url));
			
			String preloadSec= U.getSectionValue(htm, "window.__PRELOADED_STATE__", "</htm");
			htm = htm.replace(preloadSec, "");
			U.log("<<<<<<<<<<<<<<<<<<<<<<<<<, "+comSec);
			// CommName
			
			String commName = U.getSectionValue(comSec, "<span class=\"CommunityCard_communityName\" >", "<");
			if (commName.contains("-"))
				commName = commName.split("-")[0];
			commName=commName.replace("é", "e")
					.replaceAll("Welcome to |, Custom Homes| Custom Lots$|is SOLD OUT!|, Custom Lots|<BR>JULY SALE!|<br>NOW AVAILABLE|Estates Custom Lots<BR>A SELECT FEW!","");
			U.log("Community Name :" + commName);

//			// ------------------- Address & lat-lng----------------------------------
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			geo = "FALSE"; String ll[] = new String[2];

			String latlngSec = ALLOW_BLANK;
			htm = htm.replace("<a href=\"https://www.google.com/maps/place/undefined,undefined/", "");
			latlngSec = U.getSectionValue(htm, "href=\"https://www.google.com/maps/place/",
					"/@");
			U.log(latlngSec);
			if(latlngSec!=null) {
				ll=latlngSec.split(",");
				lat=ll[0];
				lng=ll[1];
			}
			U.log("Lat: "+lat +" LLLLL"+" Lng: "+lng);

			// U.log(lng);
			String addSec= U.getSectionValue(htm, "<h2 class=\"DetailHeader_subheading\"", "</h2>");
			if(addSec!=null) {
				addSec = addSec.replaceAll("data-reactid=\"\\d+\">", "").replace("|", ",");
				add=U.getAddress(addSec);
				add[0]=add[0].replace("&amp;", "&");
			}
			U.log(Arrays.toString(add));
			
			if(add[0].contains("Please see out of community sales office")||add[0].contains("No Sale Office")) {
				add = U.getAddressGoogleApi(ll);
				if(add == null) 
					add = U.getAddressHereApi(ll);
				geo = "TRUE";
			}
//			
//			String quick = Util.match(url, "https://www.elliotthomes.com/\\w{2}/(.*?)/");
//			U.log("quick::" + quick);
//
//			if (quick != null) {
//				quick = "https://www.elliotthomes.com/quick-delivery-homes?community=" + url.replace(quick, "");
//				U.log("quick::" + quick);
//				quick = U.getHTML(quick);
//				// U.log("quick::"+quick);
//			}
			
			//floorPlandata
			String allFloorData=ALLOW_BLANK, allQuickData =ALLOW_BLANK;
			String plans[] = U.getValues(htm, "<div class=\"PlanCard_wrapper\"", "/div></div></div></div></div>");
			U.log("floorLength: "+plans.length);
			for(String plan: plans) {
				String planUrl = builderUrl+ U.getSectionValue(plan, "<a class=\"\" href=\"", "\"");
				String planHtm = U.getHTML(planUrl);
				allFloorData +=U.getSectionValue(planHtm, "<h1 class=\"DetailHeader_heading\" data-", "Map &amp; Contact Info</h3></div>");
				
			}
//			// U.log(htm);
//			// Price
//			htm=htm.replace("Lot sizes range between 6,000 and 23,000 square", "");
//			if(quick!=null)
//			quick = quick.replaceAll("Original Purchase Price was \\$\\d{3},\\d{3}| Lot sizes range between 6,000 and 23,000 square feet", "");// 144}
//			
//			htm = htm.replaceAll(" / \\$\\d+,\\d+|move-in ready and specially priced at \\$\\d+,\\d+|/ \\d{3},\\d{3} Sq Ft.", "")
//					.replaceAll("High \\$(\\d{3})s", "High \\$$1,000"); //lot sqft
//					
			htm = htm.replace("0s", "0,000")
					.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">|<!-- /react-text -->|data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->|<span data-reactid=\"\\d+\">|</span></span><span class=\"DetailHeader_listLabel\" data-reactid=\"\\d+\">"," ");
//			htm = htm.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">"," ");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			U.log(htm);
			String[] price = U.getPrices(htm +comSec+ allFloorData,"Low \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|>\\$\\d,\\d{3},\\d{3}</span>|FROM \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d+|From\\s*<b>\\$\\d+,\\d+|at \\$\\d+,\\d+|From\\s*\\$\\d+,\\d+|FROM \\$\\d+,\\d+", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// Square Feet
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(htm +comSec+ allFloorData,
					"\\d,\\d{3}    -   \\d,\\d{3}   SQ FT|under \\d,\\d{3} square feet|almost \\d,\\d{3} square feet|\\d,\\d{3} square feet to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} SQ FT|Sq Ft\\s+\\d,\\d{3}\\s+-\\s+\\d,\\d{3}|\\d,\\d{3} SQ FT|range between \\d,\\d{3} and \\d{1,2},\\d{3} square feet| Sq Ft: \\d,\\d+ - \\d,\\d+|Sq Ft\\s+\\d,\\d{3}|Sq Ft[\\n\\s]*\\d,\\d{3}[-\\n\\s]*\\d,\\d{3}|\\d{1,3},\\d{3} Sq Ft|Sq Ft:\\s*<b>\\s*[^<]+|\\d+,\\d+ SF|\\d{4} square feet to \\d{4} square feet|range from \\d{4} to \\d{4} square feet|\\d,\\d{3} and \\d{1,2},\\d{3} square feet",
					0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			if(url.contains("/lakeview-oaks-at-empire-ranch-custom-lots")) {minSqf=ALLOW_BLANK;maxSqf=ALLOW_BLANK;}
			if(url.contains("/terraces-west")) {minSqf="2496";maxSqf="2929";}
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			//U.log("=========="+Util.matchAll(htm +comSec+ allFloorData, "[\\w\\s\\W]{50}1,609[\\w\\s\\W]{30}", 0));

			//status
			String status = ALLOW_BLANK;
			String statSec = htm;
			String remove = " <p class=\"small\">COMING SOON</p>| two-story home is now available|Custom Lots<br>NOW AVAILABLE|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|-SOLD OUT - FOLSOM</option>|limited availability of larger |Quick Move|Quick-Move|- COMING FALL 2018|- COMING SOON|Stoneridge - Coming Soon\\s+</a>|Hours:</b><br/>\\s+Opening February 2017|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
			statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
			statSec = statSec.replaceAll("Temporarily Sold Out|\"headline\":\"Sold Out!\"|status\":\"Sold Out\"|\"headline\":\"SOLD OUT\"|Custom Lots are Sold Out", "");
			status = U.getPropStatus((statSec)
					.replaceAll("hours</h4><h5 class=\"contactbanner_sectiontext\"  >coming soon|<div class=\"plancard_headlinebanner\"  >temporarily sold out|price\">\n\\s*[s|S]old|price\">\n\\s*[t|T]emporarily [s|S]old|temporarily sold out<br/>|is now available and|model homes are now available|with limited|lovely home is move-in ready!|Custom Lots<br>NOW AVAILABLE|\"headline\":\"Sold Out!\"|headline\":\"Custom Lots are Sold Out!\"|status\":\"Sold Out\"|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|floorplans<br /> coming|is move-in|plancard_headlinebanner\" >temporarily sold out</div>", "") + comSec.replaceAll("Custom Lots<br>NOW AVAILABLE", ""));
			
//			status = status.replace("Sold Out", ALLOW_BLANK);
//			U.log("=========="+Util.matchAll(statSec, "[\\w\\s\\W]{50}coming soon[\\w\\s\\W]{30}", 0));
//			U.log("=========="+Util.matchAll(comSec, "[\\w\\s\\W]{50}Temporarily Sold Out[\\w\\s\\W]{30}", 0));
			U.log("status: "+status);
			
			//commtype
			String communityType = U.getCommunityType((htm+comSec).replaceAll("Elongated|elongated|data-master_plan_community", ""));
			U.log("communityType: "+communityType);

			//propType =
			allFloorData=allFloorData.replace("inviting courtyard and portico", "inviting Courtyard and portico");
			String prpType=U.getPropType(commName.replace("Villa ", "") + (htm+comSec+allFloorData)
					.replace("Turkey Creek Estates Custom", "Turkey Creek Estate style home and Custom homes")
					.replace("Craftsman or Modern Prairie", "Craftsman style homes or Modern Prairie")
					.replaceAll("Villa Fiore|Custom Homes</a>|Spanish Colonial Trim|"
					+ "the inviting courtyard and portico|duplex GFCI|\">ESTATE SERIES|Estate Series|Terraces Townhomes", ""));
			U.log("propType: "+prpType);
			//U.log("=========="+Util.matchAll(htm+comSec+allFloorData, "[\\w\\s\\W]{50}estate[\\w\\s\\W]{30}", 0));
			
			//dtype
			String dType=U.getdCommType(commName+url+(htm+comSec+allFloorData).replaceAll("rancho|Rancho|floor|", ""));
//			U.log("=========="+Util.matchAll((commName+htm+comSec+allFloorData), "[\\w\\s\\W]{50}villa[\\w\\s\\W]{30}", 0));

			U.log("dType: "+dType);
			
			
//			====================================================================================
			
			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
			String lot_Sec=U.getSectionValue(htm, "<g>", "</g>");
			if(lot_Sec!=null) {
				lot_data=U.getValues(lot_Sec, "<path class=", "</path>");
				if(lot_data.length>0) {
				lotCount=Integer.toString(lot_data.length);
				 U.log("lotCount2=="+lotCount);
				}
			}
			
			

			String note = U.getnote(htm+comSec);
			data.addCommunity(commName.replaceAll(" Custom Lots!|, Custom Homes & Lots", ""), url, communityType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(prpType,dType);
			
			data.addPropertyStatus(status);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
			//			
			//			// U.log(quick);
//			if(quick!=null)
//			if (quick.contains("No results found"))
//				statSec = statSec.replace("see homes available now", "");// 178
//
//			statSec = statSec.replace(U.getSectionValue(statSec, "<header>", "</header>"), "").replace("Coming in Early Summer 2019", "Coming Early Summer 2019")
//					.replace("<h5>see homes available now</h5>", "");
//			String drop3 = U.getSectionValue(statSec, "<select name=\"community_ids[]\" class=\"form-control\">",
//					"</select>");
//			statSec = statSec.replace(drop3, "");
////			 U.log(comSec);
//			comSec = comSec.replaceAll("with limited", "");
//			statSec=statSec.replaceAll("15 new lots with new floorplans coming soon!|15 new lots with updated floorplans coming soon!", "15 new lots coming soon!");
//			
////			U.log("wecomeDesc+++++"+wecomeDesc);
//			
//			status = U.getPropStatus(wecomeDesc+(statSec).replaceAll("price\">\n\\s*[s|S]old|price\">\n\\s*[t|T]emporarily [s|S]old|temporarily sold out<br/>|is now available and|model homes are now available|with limited|lovely home is move-in ready!|Custom Lots<br>NOW AVAILABLE|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|floorplans<br /> coming|is move-in", "") + comSec.replaceAll("Custom Lots<br>NOW AVAILABLE", ""));
//			U.log("=========="+Util.matchAll((wecomeDesc+statSec).replaceAll("price\">\n\\s*Sold|price\">\n\\s*Temporarily Sold",""), "[\\w\\s\\W]{50}Sold Out[\\w\\s\\W]{30}", 0));
//			
//			U.log("riboonSec: "+riboonSec);
//			// htm = htm.replace("championship golf in Empire Ranch", " Ranch ");
//			if (url.contains("https://www.elliotthomes.com/microsite/overview/CA/Folsom/innovations-two"))
//				maxPrice = "$470,950";
//			htm = htm.replaceAll("Empire Ranch|empire-ranch|Townhomes|ROC# 244491 - Terraces Townhomes", "");
//			
//			// =========== About Area Html =======================
//			String areaUrlSec = U.getSectionValue(htm, "Welcome</a>", "</a>");
//			String areaHtml = ALLOW_BLANK;
//			if (areaUrlSec != null)
//				areaHtml = U.getHTML(builderUrl + U.getSectionValue(areaUrlSec, "<a href=\"", "\""));
//
//			// htm = htm.replaceAll("Empire Ranch|empire-ranch|Rancho", "");
//			// areaHtml = areaHtml.replaceAll("Empire Ranch|empire-ranch|Rancho", "");
//			
//			htm = htm.replace("championship golf in", "championship galleries and golf in");
//			String drop1 = U.getSectionValue(htm, "Find Your Home", "</header>");
//			String drop2 = U.getSectionValue(htm, "popover_content interest_list_signup_content",
//					"user_logged_in_status");
//			if (drop1 != null)
//				htm = htm.replace(drop1, "").replace(drop2, "");
//			// U.log(htm);
//			
//			String dropFooter=U.getSectionValue(htm, "<footer>", "</body>");
//			htm=htm.replace(dropFooter, "");
//			if(quick!=null)
//			quick = quick.replaceAll("ranch|Ranch|<li>ROC# 244491 - Terraces Townhomes|floor", "");// 199
//			// U.log("Hello::"+Util.match(quick, ".*?town home.*?"));
//			
//			// U.log("quick::"+quick);
//			if(quick!=null){
//			if (quick.contains("<h2>No results found.</h2>")
//					|| quick.contains("Sorry, we do not have Quick Delivery Homes"))
//				status = status.replace("Quick Delivery Homes", "No Quick Delivery Homes");
//			}
//			//========== Move-in homes =============
//			String quickHomeSection[] = U.getValues(htm, "<div class=\"quick-move-in__body\">", "</svg>");
//			U.log("Move-In ::"+quickHomeSection.length);
//			//if(htm.contains("<a class=\"btn-view-quick-move-ins") && !status.contains("Move")) {
//			if (riboonSec==null) {
//				riboonSec=ALLOW_BLANK;
//			}
//			
//			if((quickHomeSection.length > 0||riboonSec.contains("Move-In Ready")) && !status.contains("Move")) {
//				if(status.length()>4) {
//					status=status+", Move-in Ready";
//				}else {				
//					status="Move-in Ready";
//				}
//			}
//			
//			// home features
//			String featureHtml = ALLOW_BLANK;
//			if (htm.contains("Home Features</a>")) {
//				featureHtml = U.getHTML(url + "/features");
//				if(featureHtml!=null)
//				featureHtml = featureHtml.replaceAll("atio door covering|<li>ROC# 244491 - Terraces Townhomes", "");
//				U.log("fetatures");
//
//			}
//			String floorDeatils="";
//			String floorSecs[]=U.getValues(htm, "<a class=\"card__wrap\" href=\"", "\"");
//			for (String floor : floorSecs) {
//				String floorhtml=U.getHTML("https://www.elliotthomes.com"+floor.replace("/AZ/yuma/", "/new-homes-in-yuma-az/").replace("/CA/el-dorado-hills/", "/new-homes-in-el-dorado-hills-ca/"));
//				U.log("https://www.elliotthomes.com"+floor.replace("/AZ/yuma/", "/new-homes-in-yuma-az/").replace("/CA/el-dorado-hills/", "/new-homes-in-el-dorado-hills-ca/"));
//				floorDeatils+=U.getSectionValue(floorhtml, "<select name=\"plans\"", " <div class=\"card__top-");
//			}
//			
//			htm = htm.replace("Arizona and our custom lots", "").replaceAll(
//					"Broadstone, Custom Lots|Custom Lots by Elliott Homes|Estates Custom Lots|custom-lots|Custom styles for|Custom Lots from |custom lots - folsom|and our custom lots|Oaks at , Custom Lots",
//					"");
//			htm = htm.replace("Custom Lots</strong>,", "and custom homes Lots,");// .replace("championship golf",
//																					// "championship Golf
//																					// Club").replace("lose to golf and
//																					// offers", "lose to Golf Club and
//		
//			htm=htm.replaceAll("<option(.*?)</option", "");
//			if(quick!=null)
//			quick=quick.replace(dropFooter, "").replaceAll("<option(.*?)</option", "");
//			
//			//=================================================================================================================================PropType			
//			String prpType=U.getPropType(commName + (htm + quick + featureHtml+floorDeatils).replaceAll("Custom Homes</a>|Spanish Colonial Trim|duplex GFCI|\">ESTATE SERIES|Estate Series", ""));
//			U.log("propType====================================================> "+prpType);
//			//=================================================================================================================================ComType
//			htm=htm.replace("1<br>Story", " 1 Story ").replace("2<br>Story</li>", " 2 story ").replaceAll("Empire Ranch|empire-ranch|Rancho|colonial base moldings|Spanish Colonial Trim", "");
//			String dType=U.getdCommType(commName+url+(htm +quick));
////			if(url.contains("/lakeview-oaks-at-empire-ranch-custom-lots")) {dType=dType.replace("2 Story, 1 Story, ", "");}
//
//			U.log("CommunityType====================================================> "+dType);
//			
//			
//			add[0]=U.getNoHtml(add[0]);
//			lng = lng.replace("&t=h", "").trim();
//					
//			//if(commName.contains("Estate")) {{if(prpType==ALLOW_BLANK)prpType = "Estate-Style Homes";}}
//			//status = status.replace("New Phase Coming, New Phase Coming Fall 2020", "New Phase Coming Fall 2020").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
//			// offers");
//
///*			if(url.contains("https://www.elliotthomes.com/new-homes-in-yuma-az/sunset-terraces-at-the-view")) {minSqf = "1628"; maxSqf = ALLOW_BLANK;}
//			
//*/
//			
//			// U.log(htm);
//			data.addCommunity(commName.replaceAll(" Custom Lots!|, Custom Homes & Lots", ""), url, communityType);
//			data.addAddress(add[0], add[1], add[2], add[3]);
//			data.addSquareFeet(minSqf, maxSqf);
//			data.addPrice(minPrice, maxPrice);
//			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
//			data.addPropertyType(prpType,dType);
//			
//			data.addPropertyStatus(status);
//			data.addNotes(note);

		}
		j++;
//		}catch(Exception e) {}
	}
	
	
//	private void addDetails(String url, String comSec) throws Exception {
////		 if(j==6)
////		try{
//		{
//			//TODO : Execute for single community
////	if(!url.contains("https://www.elliotthomes.com/new-homes-in-lincoln-ca/turkey-creek-estates"))return;//9
//
//			if (data.communityUrlExists(url)){
//				LOGGER.AddCommunityUrl(url+ "------------  repeat");
//				return;
//			}
//			LOGGER.AddCommunityUrl(url);
//			
//			U.log("\r\nPAGE :" + url);
//
//			String htm = U.getHTML(url);
////			U.log("<<<<<<<<<<<<<<<<<<<<<<<<<, "+comSec);
//			String riboonSec=U.getSectionValue(htm, "<div class=\"corner-ribbon available\">", "</div>");
//			// CommName
//			String commSec = U.getSectionValue(htm, "<div class=\"hero__caption-centered\">",
//					"<ul class=\"list-inline snapshot\">");
//			String commName = U.getSectionValue(commSec, "<h2>", "</h2>");
//			if (commName.contains("-"))
//				commName = commName.split("-")[0];
//			commName=commName.replace("é", "e")
//					.replaceAll("Welcome to |, Custom Homes| Custom Lots$|is SOLD OUT!|, Custom Lots|<BR>JULY SALE!|<br>NOW AVAILABLE|Estates Custom Lots<BR>A SELECT FEW!","");
//			U.log("Community Name :" + commName);
//
//			// ------------------- Address & lat-lng----------------------------------
//			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//			String geo = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
//			geo = "FALSE";
//
//			String latlngSec = ALLOW_BLANK;
//			latlngSec = U.getSectionValue(htm, "<img src=\"http://maps.googleapis.com/maps/api/staticmap?center=",
//					"\"");
//			if (latlngSec != null) {
//				lat = U.getSectionValue(latlngSec, "color:blue%7C", ",");
//				lng = U.getSectionValue(latlngSec, ",", "&sensor=");
//			} else if (lat == null || lat == ALLOW_BLANK) {
//				lat=U.getSectionValue(comSec,"data-lat=\"","\"");
//				lng=U.getSectionValue(comSec,"data-lng=\"","\"");
//			}
//			if(lat==null) {
//				latlngSec = U.getSectionValue(htm, "href=\"https://maps.google.com/maps?&daddr=","\"");
//				String ll[]=latlngSec.split("%2C");
//				lat=ll[0];
//				lng=ll[1];
//			}
//			// U.log(lng);
//			if (htm.contains("itemprop=\"streetAddress\">")) {
//				add[0] = U.getSectionValue(htm, "itemprop=\"streetAddress\">", "</span>")
//						.replaceAll("GPS: [0-9a-zA-z. ]+", "")
//						.replaceAll("1806 Daffodil Drive Lodi, CA 95242\\s*\\n*\\s*<br>, CA 95242 ", "1806 Daffodil Drive");
//				add[1] = U.getSectionValue(htm, "itemprop=\"addressLocality\">", "</span>");
//				add[2] = U.getSectionValue(htm, "itemprop=\"addressRegion\">", "</span>");
//				add[3] = U.getSectionValue(htm, "itemprop=\"postalCode\">", "</span>");
//				add[3] = add[3].replace(" ‎", "");
//			}
//			if(url.contains("https://www.elliotthomes.com/new-homes-in-folsom-ca/lakeview-oaks-at-empire-ranch-custom-lots")) {
//				
//				add[0] = "340 Palladio Parkway Suite 521";
//				add[1] = "Folsom";
//				add[2] = "CA";
//				add[3] = "95630";
//			}
//			
//			add[0] = add[0].replaceAll("<br>GPS: <br>From Madison Ave:<br>Turn North on Kenneth Ave, Left on Gum Ranch Drive|Online Sales Office Only|<br>|<br>GPS(.*?)$", "").trim();
//			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);
//			// if address is not given
//			add[0] = add[0].trim().replace("SOLD OUT|\\s*<br>\\s*", "");
//			if ((add[0] == ALLOW_BLANK || add[0].length()<4) && lat != ALLOW_BLANK) {
//
//				add = U.getAddressGoogleApi(new String[] { lat, lng });
//				if(add == null) add = U.getAddressHereApi(new String[] { lat, lng });
//				geo = "TRUE";
//
//			}
//
//			U.log("Lat :" + lat + " Long :" + lng);
//			// ------Address from city and state----------
//			String note = ALLOW_BLANK;
//			if (add[0].length() < 4 && lat.length() < 4) {
//				String cityState = U.getSectionValue(htm, "<i class=\"elliott-map_pin\">",
//						"<div class=\"microsite_descript");
//				U.log("cityState::::::::::::" + cityState);
//				if (cityState != null) {
//					add[1] = U.getSectionValue(cityState, "</i> <b>", "</b>").trim();
//					add[2] = U.getSectionValue(cityState, "</b> /", "</div>").trim();
//					U.log(add[1] + "::::::::::::::::" + add[2]);
//					note = "Address and Lat-Lng Taken Using CIty And State";
//					String lat2[] = U.getlatlongGoogleApi(add);
//					if(lat2 == null) lat2 = U.getlatlongHereApi(add);
//					add = U.getAddressGoogleApi(lat2);
//					if(add == null) add = U.getAddressHereApi(lat2);
//					lat = lat2[0];
//					lng = lat2[1];
//					geo = "TRUE";
//				}
//			}
//			add[1] = add[1].replace("-", " ");
//
//			String quick = Util.match(url, "https://www.elliotthomes.com/\\w{2}/(.*?)/");
//			U.log("quick::" + quick);
//
//			if (quick != null) {
//				quick = "https://www.elliotthomes.com/quick-delivery-homes?community=" + url.replace(quick, "");
//				U.log("quick::" + quick);
//				quick = U.getHTML(quick);
//				// U.log("quick::"+quick);
//			}
//			// U.log(htm);
//			// Price
//			htm=htm.replace("Lot sizes range between 6,000 and 23,000 square", "");
//			if(quick!=null)
//			quick = quick.replaceAll("Original Purchase Price was \\$\\d{3},\\d{3}| Lot sizes range between 6,000 and 23,000 square feet", "");// 144}
//			
//			htm = htm.replaceAll(" / \\$\\d+,\\d+|move-in ready and specially priced at \\$\\d+,\\d+|/ \\d{3},\\d{3} Sq Ft.", "")
//					.replaceAll("High \\$(\\d{3})s", "High \\$$1,000"); //lot sqft
//		
//			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			
//			String[] price = U.getPrices(htm + quick,"FROM \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d+|From\\s*<b>\\$\\d+,\\d+|at \\$\\d+,\\d+|From\\s*\\$\\d+,\\d+|FROM \\$\\d+,\\d+", 0);
//			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
//			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//			if(url.contains("/lakeview-oaks-at-empire-ranch-custom-lots"))maxPrice=ALLOW_BLANK;
//			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//			if(quick!=null)
//			quick = quick.replaceAll("\\d,\\d{3} sq. ft. lot", "");// 154
//			// Square Feet
//			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//			
//			
//			String[] sqft = U.getSqareFeet(htm + quick,
//					"Sq Ft\\s+\\d,\\d{3}\\s+-\\s+\\d,\\d{3}|\\d,\\d{3} SQ FT|range between \\d,\\d{3} and \\d{1,2},\\d{3} square feet| Sq Ft: \\d,\\d+ - \\d,\\d+|Sq Ft\\s+\\d,\\d{3}|Sq Ft[\\n\\s]*\\d,\\d{3}[-\\n\\s]*\\d,\\d{3}|\\d{1,3},\\d{3} Sq Ft|Sq Ft:\\s*<b>\\s*[^<]+|\\d+,\\d+ SF|\\d{4} square feet to \\d{4} square feet|range from \\d{4} to \\d{4} square feet|\\d,\\d{3} and \\d{1,2},\\d{3} square feet",
//					0);
//			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
//			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			if(url.contains("/lakeview-oaks-at-empire-ranch-custom-lots")) {minSqf=ALLOW_BLANK;maxSqf=ALLOW_BLANK;}
//			if(url.contains("/terraces-west")) {minSqf="2496";maxSqf="2929";}
//			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//
//			String status = ALLOW_BLANK;
//			String statSec = htm;
//			String wecomeDesc = U.getSectionValue(htm, "welcome__welcome-description\">", "</strong></span>");
//			String remove = " <p class=\"small\">COMING SOON</p>| two-story home is now available|Custom Lots<br>NOW AVAILABLE|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|-SOLD OUT - FOLSOM</option>|limited availability of larger |Quick Move|Quick-Move|- COMING FALL 2018|- COMING SOON|Stoneridge - Coming Soon\\s+</a>|Hours:</b><br/>\\s+Opening February 2017|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
//			statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
//			// U.log(quick);
//			if(quick!=null)
//			if (quick.contains("No results found"))
//				statSec = statSec.replace("see homes available now", "");// 178
//
//			statSec = statSec.replace(U.getSectionValue(statSec, "<header>", "</header>"), "").replace("Coming in Early Summer 2019", "Coming Early Summer 2019")
//					.replace("<h5>see homes available now</h5>", "");
//			String drop3 = U.getSectionValue(statSec, "<select name=\"community_ids[]\" class=\"form-control\">",
//					"</select>");
//			statSec = statSec.replace(drop3, "");
////			 U.log(comSec);
//			comSec = comSec.replaceAll("with limited", "");
//			statSec=statSec.replaceAll("15 new lots with new floorplans coming soon!|15 new lots with updated floorplans coming soon!", "15 new lots coming soon!");
//			
////			U.log("wecomeDesc+++++"+wecomeDesc);
//			
//			status = U.getPropStatus(wecomeDesc+(statSec).replaceAll("price\">\n\\s*[s|S]old|price\">\n\\s*[t|T]emporarily [s|S]old|temporarily sold out<br/>|is now available and|model homes are now available|with limited|lovely home is move-in ready!|Custom Lots<br>NOW AVAILABLE|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|floorplans<br /> coming|is move-in", "") + comSec.replaceAll("Custom Lots<br>NOW AVAILABLE", ""));
//			U.log("=========="+Util.matchAll((wecomeDesc+statSec).replaceAll("price\">\n\\s*Sold|price\">\n\\s*Temporarily Sold",""), "[\\w\\s\\W]{50}Sold Out[\\w\\s\\W]{30}", 0));
//			
//			U.log("riboonSec: "+riboonSec);
//			// htm = htm.replace("championship golf in Empire Ranch", " Ranch ");
//			if (url.contains("https://www.elliotthomes.com/microsite/overview/CA/Folsom/innovations-two"))
//				maxPrice = "$470,950";
//			htm = htm.replaceAll("Empire Ranch|empire-ranch|Townhomes|ROC# 244491 - Terraces Townhomes", "");
//			
//			// =========== About Area Html =======================
//			String areaUrlSec = U.getSectionValue(htm, "Welcome</a>", "</a>");
//			String areaHtml = ALLOW_BLANK;
//			if (areaUrlSec != null)
//				areaHtml = U.getHTML(builderUrl + U.getSectionValue(areaUrlSec, "<a href=\"", "\""));
//
//			// htm = htm.replaceAll("Empire Ranch|empire-ranch|Rancho", "");
//			// areaHtml = areaHtml.replaceAll("Empire Ranch|empire-ranch|Rancho", "");
//			
//			htm = htm.replace("championship golf in", "championship galleries and golf in");
//			String communityType = U.getCommunityType(htm.replaceAll("Elongated|elongated|data-master_plan_community", ""));
//			String drop1 = U.getSectionValue(htm, "Find Your Home", "</header>");
//			String drop2 = U.getSectionValue(htm, "popover_content interest_list_signup_content",
//					"user_logged_in_status");
//			if (drop1 != null)
//				htm = htm.replace(drop1, "").replace(drop2, "");
//			// U.log(htm);
//			
//			String dropFooter=U.getSectionValue(htm, "<footer>", "</body>");
//			htm=htm.replace(dropFooter, "");
//			if(quick!=null)
//			quick = quick.replaceAll("ranch|Ranch|<li>ROC# 244491 - Terraces Townhomes|floor", "");// 199
//			// U.log("Hello::"+Util.match(quick, ".*?town home.*?"));
//			
//			// U.log("quick::"+quick);
//			if(quick!=null){
//			if (quick.contains("<h2>No results found.</h2>")
//					|| quick.contains("Sorry, we do not have Quick Delivery Homes"))
//				status = status.replace("Quick Delivery Homes", "No Quick Delivery Homes");
//			}
//			//========== Move-in homes =============
//			String quickHomeSection[] = U.getValues(htm, "<div class=\"quick-move-in__body\">", "</svg>");
//			U.log("Move-In ::"+quickHomeSection.length);
//			//if(htm.contains("<a class=\"btn-view-quick-move-ins") && !status.contains("Move")) {
//			if (riboonSec==null) {
//				riboonSec=ALLOW_BLANK;
//			}
//			
//			if((quickHomeSection.length > 0||riboonSec.contains("Move-In Ready")) && !status.contains("Move")) {
//				if(status.length()>4) {
//					status=status+", Move-in Ready";
//				}else {				
//					status="Move-in Ready";
//				}
//			}
//			
//			// home features
//			String featureHtml = ALLOW_BLANK;
//			if (htm.contains("Home Features</a>")) {
//				featureHtml = U.getHTML(url + "/features");
//				if(featureHtml!=null)
//				featureHtml = featureHtml.replaceAll("atio door covering|<li>ROC# 244491 - Terraces Townhomes", "");
//				U.log("fetatures");
//
//			}
//			String floorDeatils="";
//			String floorSecs[]=U.getValues(htm, "<a class=\"card__wrap\" href=\"", "\"");
//			for (String floor : floorSecs) {
//				String floorhtml=U.getHTML("https://www.elliotthomes.com"+floor.replace("/AZ/yuma/", "/new-homes-in-yuma-az/").replace("/CA/el-dorado-hills/", "/new-homes-in-el-dorado-hills-ca/"));
//				U.log("https://www.elliotthomes.com"+floor.replace("/AZ/yuma/", "/new-homes-in-yuma-az/").replace("/CA/el-dorado-hills/", "/new-homes-in-el-dorado-hills-ca/"));
//				floorDeatils+=U.getSectionValue(floorhtml, "<select name=\"plans\"", " <div class=\"card__top-");
//			}
//			
//			htm = htm.replace("Arizona and our custom lots", "").replaceAll(
//					"Broadstone, Custom Lots|Custom Lots by Elliott Homes|Estates Custom Lots|custom-lots|Custom styles for|Custom Lots from |custom lots - folsom|and our custom lots|Oaks at , Custom Lots",
//					"");
//			htm = htm.replace("Custom Lots</strong>,", "and custom homes Lots,");// .replace("championship golf",
//																					// "championship Golf
//																					// Club").replace("lose to golf and
//																					// offers", "lose to Golf Club and
//		
//			htm=htm.replaceAll("<option(.*?)</option", "");
//			if(quick!=null)
//			quick=quick.replace(dropFooter, "").replaceAll("<option(.*?)</option", "");
//			
//			//=================================================================================================================================PropType			
//			String prpType=U.getPropType(commName + (htm + quick + featureHtml+floorDeatils).replaceAll("Custom Homes</a>|Spanish Colonial Trim|duplex GFCI|\">ESTATE SERIES|Estate Series", ""));
//			U.log("propType====================================================> "+prpType);
//			//=================================================================================================================================ComType
//			htm=htm.replace("1<br>Story", " 1 Story ").replace("2<br>Story</li>", " 2 story ").replaceAll("Empire Ranch|empire-ranch|Rancho|colonial base moldings|Spanish Colonial Trim", "");
//			String dType=U.getdCommType(commName+url+(htm +quick));
////			if(url.contains("/lakeview-oaks-at-empire-ranch-custom-lots")) {dType=dType.replace("2 Story, 1 Story, ", "");}
//
//			U.log("CommunityType====================================================> "+dType);
//			
//			
//			add[0]=U.getNoHtml(add[0]);
//			lng = lng.replace("&t=h", "").trim();
//					
//			//if(commName.contains("Estate")) {{if(prpType==ALLOW_BLANK)prpType = "Estate-Style Homes";}}
//			//status = status.replace("New Phase Coming, New Phase Coming Fall 2020", "New Phase Coming Fall 2020").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
//			// offers");
//
///*			if(url.contains("https://www.elliotthomes.com/new-homes-in-yuma-az/sunset-terraces-at-the-view")) {minSqf = "1628"; maxSqf = ALLOW_BLANK;}
//			
//*/
//			
//			// U.log(htm);
//			data.addCommunity(commName.replaceAll(" Custom Lots!|, Custom Homes & Lots", ""), url, communityType);
//			data.addAddress(add[0], add[1], add[2], add[3]);
//			data.addSquareFeet(minSqf, maxSqf);
//			data.addPrice(minPrice, maxPrice);
//			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
//			data.addPropertyType(prpType,dType);
//			
//			data.addPropertyStatus(status);
//			data.addNotes(note);
//
//		}
//		j++;
////		}catch(Exception e) {}
//	}
}