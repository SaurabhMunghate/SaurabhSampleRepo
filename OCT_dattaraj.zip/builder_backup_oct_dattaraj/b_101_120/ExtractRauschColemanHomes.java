/*
 * Modification Chinmay.
 */

package com.shatam.b_101_120;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.collections.map.MultiValueMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/*
 * Parag Humane
 * Date:31/07/2013
 * 
 */

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import org.apache.commons.lang.ArrayUtils;

public class ExtractRauschColemanHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	private static String BASEURL ="https://www.rauschcolemanhomes.com";
	
	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new ExtractRauschColemanHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Rausch Coleman Homes.csv", a.data().printAll());

	}
	
	public ExtractRauschColemanHomes() throws Exception {
		super("Rausch Coleman Homes", "https://www.rauschcolemanhomes.com");
		LOGGER = new CommunityLogger("Rausch Coleman Homes");
	}
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	
	HashMap<String, String> redirectMap = new HashMap<String,String>();
	public void innerProcess() throws Exception{
		String html =U.getHTML("https://www.rauschcolemanhomes.com/find-your-home");
		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(html, "__PRELOADED_STATE__ = ", "</script>");
		if (removeScript == null)
			removeScript = "";
		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
		//String redirecrSec=U.getSectionValue(removeScript, "\"redirects\":", "]");
		JsonArray commJson = (JsonArray) jobj.getAsJsonObject().get("communities").getAsJsonObject().get("572b28c4371e2f035bb60133").getAsJsonObject().get("data").getAsJsonArray();
		JsonArray redirects=(JsonArray) jobj.getAsJsonObject().get("builder").getAsJsonObject().get("572b28c4371e2f035bb60133").getAsJsonObject().get("data").getAsJsonObject().get("products").getAsJsonObject().get("BDWebsiteConfig").getAsJsonObject().get("data").getAsJsonObject().get("redirects").getAsJsonArray();
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans");
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes");
		String plans[] = U.getValues(planJson.toString(), "{\"@type\":\"ProductModel\"", "\"type\":\"plan\"");
		
		//U.log(commJson.size());
		//U.log(plans.length);
		String homes[] = U.getValues(homeJson.toString(), "{\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}");
		for (JsonElement redirect : redirects) {
		//	U.log(redirect.toString());
			
			String key=U.getSectionValue(redirect.toString().replace("/division/find/kansas-city\"", "/division/find/kansas-city-mo\""), "\"from\":\"", "\"");
			if(key.contains("Kansas-City-MO\""))
				U.log(key);
			String value=U.getSectionValue(redirect.toString(), "\"to\":\"", "\"");
			redirectMap.put("https://www.rauschcolemanhomes.com"+key, value);
//			break;
		}
		for (String home : homes) {
			
			String comunityIn = U.getSectionValue(home, "\"containedIn\":\"", "\"");
			homesData.put(comunityIn, home);
		}
		for (String plan : plans) {
			//U.log(plan);
			String[] comms = U.getValues(plan, "{\"community\"", "}}");
			for (String com : comms) {
				String comunityIn = U.getSectionValue(com, ":\"", "\"");
				plansData.put(comunityIn, com);
			}
		}
		U.log(homesData.size());
		U.log(plansData.size());
//		FileUtil.writeAllText("/home/chinmay/Cache/rauschcolemanhomes.com/conjs1aan.txt", ""+commJson);
//		String comSection[] = U.getValues(""+commJson,"{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");

		for (JsonElement comSec : commJson) {
	//		FileUtil.writeAllText("/home/chinmay/Cache/rauschcolemanhomes.com/conjson.txt", ""+comSec);
			//commDatas.put(U.getSectionValue(comSec, "\"sharedName\":\"", "\","), comSec);
			//String commUrl="https://www.rauschcolemanhomes.com"+U.getSectionValue(comSec, "href=\"", "\"");

		//	U.log(comSec.getAsJsonObject().get("uniqueName"));
	//		U.log(comSec.getAsJsonObject().get("display_name"));
			
		//	U.log(redirectMap.get(comSec.getAsJsonObject().get("website").toString().replace("\"", "").toLowerCase()));
			String comUrl="https://www.rauschcolemanhomes.com"+redirectMap.get(comSec.getAsJsonObject().get("website").toString().replace("\"", "").toLowerCase())+"/"+comSec.getAsJsonObject().get("uniqueName").getAsString();
			String comName=comSec.getAsJsonObject().get("display_name").getAsString();
			//U.log(comName);
			//U.log(comUrl);
			//U.log((U.getSectionValue(comSec, "area\":\"", "\"").replace(", ", "-")).toLowerCase()+"/"+U.getSectionValue(comSec, "\"uniqueName\":\"", "\","));
			//U.log(commUrl);
			addDetails(comUrl.replace("-by-rausch-coleman", ""),comName,comSec);
			//break;
		}
	//	U.log(commDatas.size());
		/*String regUrlSec =U.getSectionValue(html, "<ul class=\"division-list\">", "</ul>");
		String[] regUrl=U.getValues(regUrlSec, "href=\"", "\"");
		for(String regURL :regUrl) {
			regURL=BASEURL+regURL;
//			U.log("Region URL :"+regURL);
			String reghtml=U.getHTML(regURL);
			String[] comSections =U.getValues(reghtml, "<a class=\"sub-tile\"", "</footer>");
			for(String comUrlSec:comSections) {
				String comUrl=U.getSectionValue(comUrlSec, "href=\"", "\">");
				comUrl=BASEURL+comUrl;
				String comName =U.getSectionValue(comUrlSec,"<h3 class=\"name\">","</h3>");
				comName=comName.replace("&#039;s", "'s").replace("Homestead of the GAP", "Homestead of the Gap");
				
//				try {
					addDetails(comUrl,comName,comUrlSec);
//				} catch (Exception e) {}
				
			}
		}*/
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comUrl,String comName,JsonElement comData) throws Exception {
//		if(i>=94) 
		{
		comUrl=comUrl.replace("comnull/", "com/communities/");
		LOGGER.AddCommunityUrl(comUrl);
		if(data.communityNameExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"*****************REPEATED***************");
			return;
		}
				
//		if(!comUrl.contains("https://www.rauschcolemanhomes.com/communities/oklahoma/oklahoma-city-ok/323-robertson's-landing")) return;
		
		if(comUrl.contains("https://www.rauschcolemanhomes.com/communities/oklahoma/oklahoma-city-ok/323-robertson's-landing")) {
			LOGGER.AddCommunityUrl(comUrl+"---------PAGE NOT FOUND");
			return;
		}
			
		
		U.log("count :"+i);
		U.log(comData.getAsJsonObject().get("website"));
		String comId = comData.getAsJsonObject().get("_id").getAsString();
		String desc= comData.getAsJsonObject().get("description").getAsString();
	//	String comhtml =U.getHTML(comUrl);
		U.log(comId);
		U.log(comData);
		//String comData = comhtml;
		
	//	comhtml=U.getSectionValue(comhtml, "<section class=\"section-intro\">", "<div class=\"row row-disclaimers\">");
		U.log("Community Name :"+comName);
		U.log(comUrl);
	//================Address & Lat-Lng====================
		String[] add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
		String note="";
		String geo="FALSE";
		JsonArray latLonData=comData.getAsJsonObject().get("geoIndexed").getAsJsonArray();
		latlng[0]=latLonData.get(1).getAsString();
		latlng[1]=latLonData.get(0).getAsString();
		
		
		U.log(Arrays.toString(latlng));
		//String addSec=U.getSectionValue(comhtml, "</a></strong>", "</p>");
//		U.log("addSec =="+addSec);
		add[0]=comData.getAsJsonObject().get("outOfCommunity").getAsJsonObject().get("address").getAsJsonObject().get("streetAddress").getAsString();
		
		if(add[0]!=null) {
			add[0]=add[0].replaceAll("White Oak Crossing|TBD", ALLOW_BLANK);
		}
		add[1]=comData.getAsJsonObject().get("outOfCommunity").getAsJsonObject().get("address").getAsJsonObject().get("addressLocality").getAsString();
		add[2]=comData.getAsJsonObject().get("outOfCommunity").getAsJsonObject().get("address").getAsJsonObject().get("addressRegion").getAsString();
		add[3]=comData.getAsJsonObject().get("outOfCommunity").getAsJsonObject().get("address").getAsJsonObject().get("postalCode").getAsString();
		
		U.log("Address intital:: "+Arrays.toString(add));
		
		String locatedOffDirection=comData.getAsJsonObject().get("directions").getAsString();
		String status=comData.getAsJsonObject().get("status").getAsString();
		if(status!=null) {
			if(status.equals("Active")) {
				status="now selling";
			}
		}
		String street=ALLOW_BLANK;
		if(add[0].contains("TBD") && locatedOffDirection!=null) {
			street=U.getSectionValue(locatedOffDirection, "Located off of ", " in Tuscaloosa.");
			if(street==null) {
				street=U.getHtmlSection(locatedOffDirection, "Hardy Toll", "1960");
			}
			if(street!=null) {
				add[0]=street;
			}
			
		}
		
		if(locatedOffDirection==null) {
			locatedOffDirection=ALLOW_BLANK;
		}
		locatedOffDirection=locatedOffDirection.replace("00's", "00,000 price");
		U.log(comData);
		U.log("located Off"+locatedOffDirection);
		
		U.log("Address :: "+Arrays.toString(add));
		if((add[0].equals(ALLOW_BLANK)||add[0].contains("TBD"))&&latlng[0]!=ALLOW_BLANK ) {
			add=U.getGoogleAddressWithKey(latlng);
			geo="TRUE";
		}
			
	//==============HOME DATA===========
//		String homehtml="";
//		String moveinhtml="";
		int nomvin=0; int quickcount=0;
//		if(comhtml.contains("Home Designs") || comhtml.contains("Move-in Ready")) {
		
		ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId.replace("\"", ""));
		String homesecs = ALLOW_BLANK;
		if (homeData != null) {
			for (String home : homeData) {
				//U.log("homeData: "+home);
				
				if(!home.contains("\"status\":\"Sold\"")) {
					if(!home.contains("status\":\"Under Construction")) {
						quickcount++;
					}					
				}
				homesecs += home;
			}
		}
//		U.log(quickcount);
//		 U.log("homesecs::::::::::::::::: \n"+homeData.size());
		String storySec=ALLOW_BLANK;
		ArrayList<String> planData = (ArrayList<String>) plansData.get(comId.replace("\"", ""));
		String plansecs = ALLOW_BLANK;

		if (planData != null) {
			for (String plan : planData) {
				plansecs += plan;
			}
			
		}
//		U.log("homesecs::::::::::::::::: \n"+planData.size());
//	//============MOVE-IN-READY==============
//		String moveinSec=U.getSectionValue(comhtml, "<div id=\"tab-content-movein\" class=\"tab-content\"", "<div id=\"loader\" class=\"text-center\">");
		
//		
//		if(moveinSec!=null) {
////		String[] moveinData=U.getValues(moveinSec, "<div class=\"columns\">", "</ul>");
//			String[] moveinData=U.getValues(moveinSec, "<div class=\"columns\">", "</ul>");
//		quickcount=moveinData.length;
//		for(String moveinUrlSec:moveinData) {
////			if(moveinUrlSec.contains("10487"))
////			  U.log("mmmm  "+moveinUrlSec);
//			if(moveinUrlSec.contains("image-col sold-1")) {
//				nomvin++;
//			}
//			String moveinUrl=U.getSectionValue(moveinUrlSec, "<a href=\"", "\">");
//			moveinUrl=BASEURL+moveinUrl;
//			U.log(moveinUrl);
//			moveinhtml +=U.getHTML(moveinUrl);
////			}
//		}
//		}
//	//===========PRICE==============
		String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
//		
//		comData = comData.replaceAll("<p class=\"monthly-price\">starting at <span class=\"price\">\\$\\d{3},\\d{3}</span></p>", "");
		U.log(street);
		String[] price=U.getPrices(locatedOffDirection+comData+plansecs+homesecs, "\\d{3},\\d{3} price|\"priceLow\":\\d{6},|\"priceHigh\":\\d{6},", 0);
		minPrice =(price[0]==null) ? ALLOW_BLANK:price[0];
		maxPrice =(price[1]==null) ? ALLOW_BLANK:price[1];
		U.log("minPrice :"+minPrice+ " : "+"minPrice :"+maxPrice);
//		
////		U.log("MMMM"+Util.matchAll(comData,"[\\w\\W\\s]{50}1075[\\w\\W\\s]{50}", 0));
//		
//	//===========SQFT==============
		String minSqf=ALLOW_BLANK,maxSqf=ALLOW_BLANK;
		String[] sqft=U.getSqareFeet(comData+plansecs+homesecs, "\"sqftLow\":\\d{4},|\"sqftHigh\":\\d{4},", 0);
		minSqf =(sqft[0]==null) ? ALLOW_BLANK:sqft[0];
		maxSqf =(sqft[1]==null) ? ALLOW_BLANK:sqft[1];
		U.log("minSqf :"+minSqf+ " : "+"maxSqf :"+maxSqf);
//		
////		U.log("MMMM"+Util.matchAll(comData,"[\\w\\W\\s]{50}sq/ft[\\w\\W\\s]{50}", 0));
//		
//	//==========Community-Type============
		desc = desc.replace("about the Lakeside Cottages community", "about the Lakeside community Cottages community");
//		
		String ctype=U.getCommType(desc);
		U.log(ctype);
//		//U.log("MMMM"+Util.matchAll(comhtml,"[\\w\\W\\s]{50}lakeside[\\w\\W\\s]{50}", 0));
//	//==========Property-Type============
//		//U.log("MMMM"+Util.matchAll(comhtml,"[\\w\\W\\s]{50}cottage[\\w\\W\\s]{50}", 0));
////		U.log("MMMM"+Util.matchAll(homehtml,"[\\w\\W\\s]{50}villa[\\w\\W\\s]{50}", 0));
		if(comUrl.contains("-estates")) desc = desc + "Estate style Homes";
			
		String ptype=U.getPropType((homesecs+plansecs+desc).replaceAll("Village|village|HOA fees are not included|cottages-at-lane",""));
		U.log("ptype: "+ptype);
		
//	//==========D Property-Type============
////		U.log("MMMM"+Util.matchAll(moveinhtml,"[\\w\\W\\s]{50}ranch[\\w\\W\\s]{50}", 0));
////		U.log("MMMM"+Util.matchAll(homehtml,"[\\w\\W\\s]{50}ranch[\\w\\W\\s]{50}", 0));
		String dtype=U.getdCommType((homesecs+plansecs+desc).replaceAll("franchot-fields|redstone-ranch|still-creek-ranch", ""));
//		
//	//==========Property Status============	
		String pstatus=U.getPropStatus((status+desc).replace("Phase 2 pricing coming soon", ""));
//		
////		if(comhtml.contains("div class=\"image-col sold-1\"")) {
////			pstatus = pstatus.replaceAll("Move-in Ready|, Move-in Ready", ALLOW_BLANK);
//		
////		}
//		
//		
//		pstatus=pstatus.replaceAll(", Move-in Ready|Move-in Ready, |Move-in Ready", "");
//		pstatus = pstatus.replace("Coming Soon-", "Coming Soon")
//				.replace("Closeout-", "Closeout");
//		
//		U.log("pstatus111: "+pstatus);
//		
		U.log("quickcount: "+quickcount);
		U.log("WQQQQ "+nomvin);
//		
		if(quickcount>0) {
			if(pstatus.length()>3 && pstatus!=ALLOW_BLANK ){
				pstatus=pstatus+", Move-in Ready";
			}
			else{
				pstatus="Move-in Ready";
			}
		}
//		if(pstatus.isEmpty()) {
//			pstatus=ALLOW_BLANK;
//		}
//		
		U.log("pstatus: "+pstatus);
//		
////	if(comUrl.contains("https://www.rauschcolemanhomes.com/division/find/oklahoma-city/mustang-farms"))
////		pstatus="Coming Soon";
//		
////		U.log(">>>>>>>>>>>>"+Util.matchAll(comhtml+comUrlSec, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));
//		
//		//=================== Note ========================
////		U.log(">>>>>>>>>>>>"+Util.matchAll(comhtml, "[\\s\\w\\W]{30}move-in[\\s\\w\\W]{30}", 0));
//		
//		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
//		
//		 
//		 
//	
 		String notes = U.getnote(desc);
		data.addCommunity(comName, comUrl, ctype);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(notes);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
	}
		i++;
	}
}