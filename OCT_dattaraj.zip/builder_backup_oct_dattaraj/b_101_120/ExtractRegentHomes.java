/**
 * @author Upendra Singh 
 * @date 27/01/2017
 * 
 */
package com.shatam.b_101_120;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class ExtractRegentHomes extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;

	WebDriver driver = null;

	private static final String builderUrl = "https://www.regenthomestn.com";

	public ExtractRegentHomes() throws Exception {
		super("Regent Homes", "https://www.regenthomestn.com/");
		LOGGER = new CommunityLogger("Regent Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRegentHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Regent Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		// TODO Auto-generated method stub
		String commListHtml = U.getHtml("https://www.regenthomestn.com/communities", driver);
		String commSecs[] = U.getValues(commListHtml, "<div class=\"community-card\">", "</community-card>");
		for (String comSec : commSecs) {
			// U.log(comSec);
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
			addDetails(builderUrl + comUrl, comSec);
			// break;
		}
		
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.regenthomestn.com/communities/nashville/columbia/trotwood/overview"))return;
		// try{
		{
			U.log(j + "   commUrl-->" + comUrl);
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "---------repeated-------------");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHtml(comUrl, driver);
			U.log(U.getCache(comUrl));
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(comData, "class=\"ng-binding\">", "<");
			communityName = communityName.replace(", Madison AL", "").replace(", Huntsville, AL", "");
			U.log("community Name---->" + communityName);
			// ================================================Address
			// section===================================================================

			String note = U.getnote(html);

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<h4 class=\"ng-binding\">", "<br /><b class=\"community-county");
			
			if(addSec == null)
				addSec = U.getSectionValue(html, "<h4 class=\"ng-binding\">", "<br><b class=\"community-county");

			 U.log(addSec);
			if (addSec != null) {
				addSec = addSec.replaceAll("<br />|<br>", ",").replace(", Nolensville Area", "");
				add = U.getAddress(addSec);

			}
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			// --------------------------------------------------latlng----------------------------------------------------------------
			String latlongSec=null;
			String newHtml=U.getHTML("https://api.mybuildercloud.com/api/v1/communities?where={%22published%22:true,%22builder%22:%225702bb75f410954eb27cf9ff%22}&max_results=9999");
			String[] sec=U.getValues(newHtml, "{\"@type\": \"GatedResidenceCommunity\"", "\"zillowHours\":");
//			U.log("Length===="+sec.length);
			for(String data : sec) {
//				U.log("data===\n"+data+"\n\n");
				if(data.contains(communityName)) {
//					U.log("data===="+data);
//					latlongSec=U.getSectionValue(data, "\"geoIndexed\": ", ", \"");
				}
				String name=U.getSectionValue(data, "\"sharedName\": \"", "\",");
				String newName=communityName.toLowerCase().replace(" ", "-");
//				U.log("LLLLLLLLLLL===="+newName);
				if(name.contains(newName)) {
					U.log("name===="+name);
					latlongSec=U.getSectionValue(data, "\"geoIndexed\": ", ", \"");
				}
//				break;
				
			}
			U.log("JJJJJ==="+latlongSec);
			
			
			String directionUrl = comUrl.replace("/overview", "/directions");
			String directionHtml = U.getHtml(directionUrl, driver);

//			String latSec = U.getSectionValue(directionHtml, "https://www.google.com/maps/", "\"");
//			U.log("latSec===="+latSec);
			if (latlongSec != null) {
				latlag[1] = U.getSectionValue(latlongSec, "[", ",");
				latlag[0] = U.getSectionValue(latlongSec, ",", "]");
			}
			U.log("hhhh--->" + latlag[0] + "  " + latlag[1]);
			if (add[1] != ALLOW_BLANK && latlag[0] == ALLOW_BLANK) {
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				if(latlag == null) latlag = U.getNewBingLatLong(add);
				geo = "TRUE";
			}
			if ((add[0] == ALLOW_BLANK || add[0].length() < 4 || add[3] == null) && latlag[0] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latlag);
				if(add == null) add = U.getAddressHereApi(latlag);
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latlag[0] + "  " + latlag[1]);

			// ======= Floor plan & Available home ============
			String floorHtml = "", availHomeHtml = "";
			String urlSection = U.getSectionValue(html,
					"<ul class=\"list-unstyled inside-menu-header hidden-xs hidden-sm\">", "</ul>");
			 U.log(urlSection + "\t1URLLLLLLLLLL");
			String[] navUrls = U.getValues(urlSection, "href=\"", "\"");
			for (String navUrl : navUrls) {
			//	U.log(navUrl + "====<");
				if (navUrl.contains("floor-plans") || navUrl.contains("floorplans"))
					floorHtml = U.getHtml(builderUrl + navUrl, driver);
				if (navUrl.contains("new-homes-for-sale") || navUrl.contains("available-homes"))
					availHomeHtml = U.getHtml(builderUrl + navUrl, driver);
			}
			if (availHomeHtml != null && availHomeHtml.trim().length() != 0) {
				String availHomes[] = U.getValues(availHomeHtml, "<div class=\"home-card card\"", "</home-card>");
				U.log(availHomes.length);
				for (String avail : availHomes) {
					// U.log(avail);
					String availHomeUrl = builderUrl + U.getSectionValue(avail, "href=\"", "\"");
					U.log("availHomeUrl :"+availHomeUrl);
					String tempHtml = U.getHtml(availHomeUrl, driver);
					tempHtml = U.getSectionValue(tempHtml, "<section class=\"detail-header ng-scope\">",
							"ng-include src=\"'/presentation/Footer/template.html'");
					availHomeHtml += tempHtml;
				}
			}
			if (floorHtml != null && floorHtml.trim().length() != 0) {
				String floorHomes[] = U.getValues(floorHtml, "<div class=\"plan-card card", "</plan-card>");
				U.log(floorHomes.length);
				for (String floorPlan : floorHomes) {
					// U.log(avail);
					String floorHomeUrl = builderUrl + U.getSectionValue(floorPlan, "href=\"", "\"");
					String tempHtml = U.getHtml(floorHomeUrl, driver);
					tempHtml = U.getSectionValue(tempHtml, "<section class=\"detail-header ng-scope\">",
							"ng-include src=\"'/presentation/Footer/template.html'");
					floorHtml += tempHtml;
				}
			}
			// ============================================Price and SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html=html.replace("<!-- ngIf: community.priceHigh --><ngif ng-if=\"community.priceHigh\" class=\"ng-binding ng-scope\">", "");
			//U.log(html);
			html = html.replaceAll("0s|0's|0&#8217;s|0s|0k's|0k", "0,000").replace("$1 million", "$1,000,000");
			floorHtml = floorHtml.replaceAll("0s|0's|0&#8217;s|0s|0k's|0k", "0,000").replace("$1 million",
					"$1,000,000");
			comData = comData.replaceAll("99's", "99,000").replaceAll("0's", "0,000");
//			comData=comData.replace("'s", ",000");
			comData = formatPrices(comData);
			String comdataprices[]=U.getPrices(comData,"\\$\\d{3},\\d{3}",0);
//			U.log(Arrays.toString(U.getPrices(html + availHomeHtml + floorHtml+comData,
//			"Price Range:</strong> \\$\\d{3},\\d{3}- \\$\\d{3},\\d{3}|<strong>Price Range:</strong> \\$\\d{3},\\d{3}<!-- ngIf: community.priceHigh --><ngif ng-if=\"community.priceHigh\" class=\"ng-binding ng-scope\" style=\"\">- \\$\\d{3},\\d{3}</ngif>|Price Range:</span> \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Price Range:</strong> \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</li>|<div class=\"result-price ng-binding\">\\$\\d{3},\\d{3}</div>|<strong>Price:</strong> <span class=\"ng-binding\">\\$\\d{3},\\d{3}</span>|Range:</strong> \\d{3},\\d{3}|Price:</strong> \\$\\d{3},\\d{3}|Priced From:</span> \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}",
//			0)));

			
			String prices[] = U.getPrices(html + availHomeHtml + floorHtml+comData,
					"Price Range:</strong> \\$\\d{3},\\d{3}- \\$\\d{3},\\d{3}|<strong>Price Range:</strong> \\$\\d{3},\\d{3}<!-- ngIf: community.priceHigh --><ngif ng-if=\"community.priceHigh\" class=\"ng-binding ng-scope\" style=\"\">- \\$\\d{3},\\d{3}</ngif>|Price Range:</span> \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Price Range:</strong> \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</li>|<div class=\"result-price ng-binding\">\\$\\d{3},\\d{3}</div>|<strong>Price:</strong> <span class=\"ng-binding\">\\$\\d{3},\\d{3}</span>|Range:</strong> \\d{3},\\d{3}|Price:</strong> \\$\\d{3},\\d{3}|Priced From:</span> \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}",
					0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Price--->" + minPrice + " " + maxPrice);
			// ======================================================Sq.ft===========================================================================================
			String[] sqft = U.getSqareFeet(html + comData + availHomeHtml + floorHtml,
					"\\d,\\d{3} sq. ft. |\\d,\\d{3}-\\d,\\d{3} sq. ft|from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft.|up to \\d,\\d{3} living square feet|\\d,\\d{3} to \\d,\\d{3} square feet|<span class=\"ng-binding\">\\d,\\d{3}</span>SQ FT</li>|sqft.svg\" alt=\"\"><br><span class=\"ng-binding\">\\d,\\d{3}</span>|SQ FT Range:</strong> \\d,\\d{3} <!-- ngIf: community.sqftHigh --><span ng-if=\"community.sqftHigh\" class=\"ng-binding ng-scope\">- \\d,\\d{3}</span>|SQ FT Range:</span> \\d{1},\\d+ to \\d{1},\\d+|SQ FT:</span> \\d{1},\\d+|up to \\d,\\d{3} square feet|SQ FT Range:</strong> \\d{3,4}|SQ FT Range:</strong> \\d,\\d{3} ",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
			// ================================================community type========================================================
			String communityType = U.getCommType(html + comData);
			// ==========================================================Property Type================================================
			String tempHtml = html;
			String remMeta = U.getSectionValue(tempHtml, "<html xml:lang=\"en\" ", "</title>");
			if (remMeta != null) {
				U.log("Success remMeta");
				tempHtml = tempHtml.replace(remMeta, "");
			}
//			 U.log("temphtmlllll___> "+tempHtml);
			// tempHtml =
			// tempHtml.replaceAll("-condo-|(Condos)|=Condo|_condo_|_condo|\"Condo\">Condo<|condos
			// in Columbia Tennessee", "");
			tempHtml = tempHtml.replaceAll(
					"Village|village|Work Townhomes|new townhomes|\\(condo|<option value=\"Condo\">Condo|type=Condo|center-condo|-condo-|(Condos)|Columbia home builders, new townhome|condos in Columbia Tennessee|townhomes-for-|<option value=\"Townhome\">Townhome</option>|=Townhome\">|\"/townhome-communities\">Townhomes</a>|Townhomes</a>|/townhome-floorplans",
					"");
			tempHtml = tempHtml.replaceAll(
					"'Single Family' >Single Family</option>|<option value=\"Single Family\">Single Family</option>|=Single Family\">Single Family Homes</a>|>Single Family Homes</a>| Regent Homes specialize in new single family homes, townhomes |single-family-",
					"");
			// U.log("result::"+Util.match(tempHtml, ".*?condo.*"));
			tempHtml = tempHtml.replaceAll("</span> Single\\s+", "Single");
			tempHtml = tempHtml.replace("traditionally designed building", "Traditional exterior").replace("idyllic traditional setting", "traditional homes");
			tempHtml = tempHtml.replace("luxurious first floor", "Luxury homes");
			// if(tempHtml.contains("Condo")){
			// U.log("here is condo");
			// }
			tempHtml=tempHtml.replace(">Home Type:</strong> <!-- ngIf: community.style === 'CondoOnly' --> <!-- ngIf: !community.style --><span ng-if=\"!community.style\" class=\"ng-scope\">", "Home Type: ");
			tempHtml=tempHtml.replaceAll(" data-caption=\"Cottage Homes\"|singleSelectFilter.filterModel.Type = 'Condominium", "").replace("traditional, craftsman and", "Traditional exterior,Craftsman style details");
//			1st Floor</span><br>Owner's Suite</li>
			availHomeHtml=availHomeHtml.replace("and an enormous loft", "and an enormous with Loft ")
					.replace("1st Floor</span><br>Owner's Suite</li>", "1st Floor Owner's Suite");
			String proptype = U
					.getPropType((tempHtml + comData + availHomeHtml + floorHtml)
							.replace("rear patio for barbecuing", "rear covered patio for barbecuing")
							.replace("enjoy the rear patio for barbecuing", "").replaceAll("Oxford Farmhouse GY|class=\"row homes\"|Townhomes</a>|Townhomes photo\"|\"townhomes|[T|t]ownhomes\"|craftsmanship|/condos\"|\"condos| = 'Condominium'| data-caption=\"Cottage Homes\"|alt=\"Cottage homes at Burkitt|Huntland cottage home|singleSelectFilter.filterModel.Type = 'Condominium|<a href=\"/homes/huntsville/townhomes\" ui-sref=\"townhomes|'Single Family'|true\">Single Family Homes</a>|>Single Family|Midland I B cottage home", "")
							.replaceAll("'CondoOnly'|ui-sref=\"condos|filterModel.Type = 'Condo'|/condos\"|isNavCollapsed = true\">Condos</a>|filterModel.Type = 'Townhome'|/townhomes\"|sref=\"townhomes|isNavCollapsed = true\">Townhomes</a>|Village|village|isNavCollapsed = true\">Single Family Homes</a>|/single-family-homes\"|filterModel.Type = 'Single Family'", ""));
			U.log("prop type--> " + proptype);
//			
//			U.log("<<<<<<<<<<< "+Util.matchAll((tempHtml + comData + availHomeHtml + floorHtml),"[\\w\\s\\W]{30}3rd Floor[\\w\\s\\W]{30}",0));

			
			if(proptype.contains("Townhouse") && proptype.contains("Townhome"))proptype=proptype.replace("Townhouse,", "");
			// ==================================================D-Property Type======================================================
			String availHtml = ALLOW_BLANK;
			html = html.replaceAll("floor", "");
			html = html.replace("Stories <span class=\"value\">", " Story ");
			availHomeHtml = availHomeHtml.replace("stately two-level", "2 story").replace(" expansive first level", "1 story").replace("third level ", " 3 stories "); //.replace("level", "")
			html=html.replaceAll("photo of two-story home painted|Tolbert Model Home, First Floor Owner's Bath|2-story home photo|3-story color photo|Tolbert Model Home, First Floor Owner's Suite", "");
			
			availHomeHtml=availHomeHtml.replace("third level", "3-story");
			
			String dtype = U.getdCommType((html + comData + availHomeHtml + floorHtml.replaceAll("<span class=\"ng-binding\">3</span>Stories", "3 Story") + availHtml));
			U.log("dtype::::::::::::::"+dtype);
			
//			U.log("<<<<<<<<<<< "+Util.matchAll(( html    ),"[\\w\\s\\W]{30}1st Floor Owner's Suite[\\w\\s\\W]{30}",0));
//			U.log("<<<<<<<<<<< "+Util.matchAll(( comData    ),"[\\w\\s\\W]{30}1st Floor Owner's Suite[\\w\\s\\W]{30}",0));
//			U.log("<<<<<<<<<<< "+Util.matchAll(( availHomeHtml    ),"[\\w\\s\\W]{30}1st Floor Owner's Suite[\\w\\s\\W]{30}",0));
//			U.log("<<<<<<<<<<< "+Util.matchAll(( floorHtml   ),"[\\w\\s\\W]{30}1st Floor Owner's Suite[\\w\\s\\W]{30}",0));

	
			// ==============================================Property Status=========================================================
			html = html.replaceAll("Pool. Now Open|Soon! New|Community Restaurants Now Open|Soon Steamboys", "")
					.replace("Coming Soon! Phase II", "Phase II Coming Soon!")
					.replace("Only One Regent Home Remaining", "Only One Home Remaining")
					.replace("New Phase Opening In July", "New Phase Opening July")
					.replaceAll("when the new phase of condos, retail shops|miss this last|selling the Shops", "");
					//.replace(">Only 1 Remaining!</h4>", ">Only 1 Home Remaining!</h4>");
			//|and now selling the Charleston
			
			String pstatus = U.getPropStatus((html.replace("Coming Soon! Phase II", "Coming Soon Phase II").replace("class=\"detail-headline ng-binding ng-scope\" style=\"\">Fina Phase!</h4>", "class=\"detail-headline ng-binding ng-scope\" style=\"\">Final Phase!</h4>") + comData));
			pstatus = pstatus.replace("Ii", "II");
			U.log("pstatus: "+pstatus);
//			U.log("<<<<<<<<<<< "+Util.matchAll(( html  ),"[\\w\\s\\W]{30}Coming Soon[\\w\\s\\W]{30}",0));
			if(comData.contains("</span> Available Homes</li>"))
			{
				
					String statusline=Util.match(comData, "\\d+</span> Available Homes</li>");
					U.log(statusline);
					if(statusline!=null)statusline=statusline.replaceAll("</span>|</li>", "");
					if(pstatus.length()<2){
						pstatus=statusline;
					}
					else {
						pstatus=pstatus+", "+statusline;
					}
			}
				
			// ============================================note====================================================================

			add[2] = add[2].replace(".", "");
		//	if(comUrl.contains("nolensville/burkitt-springs/overview"))pstatus=pstatus+", Final Phase";
		
//			if(comUrl.contains("https://www.regenthomestn.com/communities/nashville/nolensville/burkitt-commons/overview") && !pstatus.contains("Now Selling")){
//				if(pstatus == ALLOW_BLANK)pstatus = "Now Selling";
//				else if(pstatus != ALLOW_BLANK)pstatus=pstatus+", Now Selling";
//			}
				
//			if(comUrl.contains("communities/nashville/nolensville/burkitt-commons/overview")){
//				if(pstatus == ALLOW_BLANK)pstatus = "Available Winter 2021";
//				else if(pstatus != ALLOW_BLANK)pstatus=pstatus+", Available Winter 2021";
//			}
			
//			pstatus=pstatus.replace("Coming Summer 2022, Coming Soon", "Coming Summer 2022");
			int lotCount=0;
			String noOfUnits=ALLOW_BLANK;
			String siteSec=U.getSectionValue(html, "Available Homes", "Community Map");
			if(siteSec!=null) {
				
				//U.log("JJJJ"+siteSec);
				U.log("Hello");
				String sitemapUrl=comUrl.replace("overview", "map");
				U.log("Site MapUrl:: "+sitemapUrl);
				String siteMapHtml=U.getHtml(sitemapUrl,driver);
				Thread.sleep(20000);
				String svgSec=U.getSectionValue(siteMapHtml, "<iframe class=\"platmap-modal-iframe\"", "</iframe></div>");
			    String svgUrl=U.getSectionValue(svgSec, "ng-src=\"", "amp;url=");
			    U.log("svG uRL"+svgUrl);
			    String svgHtml=U.getHtml(svgUrl, driver);
			    
			    String soldcount[]=U.getValues(svgHtml, "<path class=\"leaflet-interactive sold polygon\"", "\">");
			    String underConstr[]=U.getValues(svgHtml, "<path class=\"leaflet-interactive home status-under-construction polygon\"", "\">");
			    lotCount=soldcount.length+underConstr.length;
			    
			    noOfUnits=Integer.toString(lotCount);
			    if(noOfUnits.equals("0"))
			    	noOfUnits=ALLOW_BLANK;
			}
			
			U.log("No.of units= "+noOfUnits);
			
			
			
			
			
			
		    if(pstatus.contains("Only 2 Remaining, 2 Available Homes"))pstatus=pstatus.replace("Only 2 Remaining, 2 Available Homes", "2 Available Homes");
			if(comUrl.contains("https://www.regenthomestn.com/communities/nashville/thompson-s-station/tollgate-village-town-center/overview"))dtype="1 Story, 3 Story";
			if(comUrl.contains("https://www.regenthomestn.com/communities/nashville/mt-juliet/waltons-grove/overview"))dtype=dtype.replace("1 Story, ", "");
			if(comUrl.contains("https://www.regenthomestn.com/communities/nashville/columbia/trotwood/overview"))pstatus+=", Coming Soon";
			if(comUrl.contains("https://www.regenthomestn.com/communities/nashville/nolensville/burkitt-commons/overview"))dtype="1 Story, 3 Story";
			if(comUrl.contains("https://www.regenthomestn.com/communities/nashville/columbia/trotwood/overview"))proptype+=", Homeowner Association";

			
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
		}
		j++;
		// }catch(Exception e) {}
	}
	//Format million price
	public static String formatPrices(String regsec){	
		Matcher millionPrice = Pattern.compile(" From \\$\\d{3}'s",Pattern.CASE_INSENSITIVE).matcher(regsec);	
		while(millionPrice.find()){			
			//U.log(mat.group());		
			String floorMatch = millionPrice.group().replace("'s", ",000");  
			//$1.3 M		
			regsec	 = regsec.replace(millionPrice.group(), floorMatch);			
			}
		//end millionPrice	
		return regsec;
		
		}
		
	

}