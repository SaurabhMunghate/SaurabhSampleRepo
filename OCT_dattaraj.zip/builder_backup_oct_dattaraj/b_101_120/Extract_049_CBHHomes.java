/*
 * @Autor: Rakesh
 * 
 */
package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.regexp.recompile;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.net.URL;
import java.net.URLEncoder;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import java.net.URLEncoder;

public class Extract_049_CBHHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j = 0;
//	ChromeDriver driver = null;
	FirefoxDriver driver = null;
	CommunityLogger LOGGER;
	String[] latlng;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new Extract_049_CBHHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "CBH Homes.csv", a.data().printAll());
	}

	public Extract_049_CBHHomes() throws Exception {

		super("CBH Homes", "https://www.cbhhomes.com");
		LOGGER = new CommunityLogger("CBH Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		if (driver == null) driver = new FirefoxDriver();
		driver.manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS);
		String url = "https://cbhhomes.com/Communities";
		String jsonHtml = getHTMLwithProxy("https://cbhhomes.com/wp/wp-admin/admin-ajax.php?action=get_communities&page=1&count=0");
		String commSec[] = U.getValues(jsonHtml, "\"type\":\"community\"", "\"rentalsAvailable\""); //"true}");
		U.log("TotalCommunity:> " + commSec.length);

		for (String item : commSec) {
			String name = U.getSectionValue(item, "title\":\"", "\"");
			String item1 = U.getSectionValue(item, "url\":\"", "\"").replace("\\", "");
//			U.log(">>>>>>>"+item1);
			addDetails(item1, name, item);
			inr++;
			i++;
		}
		
		if (driver != null)	driver.quit();
		LOGGER.DisposeLogger();
		U.log(i);
	}

	private void addDetails(String URl, String name, String mainSec) throws Exception {
		//TODO : Execute for single community
//	 if(!URl.contains("https://cbhhomes.com/communities/meridian/aegean-estates/"))return;
//	try{
//		if(j>=11)
    	{
			if (URl.contains("/meridian/12-oaks-at-ten-mile")
					|| URl.contains("/communities/meridian/victory-south/")) {
				LOGGER.AddCommunityUrl(URl + "::::::::::::::::::::::::no data");
				return;
			}
			
			if(URl.equals("https://cbhhomes.com/communities/")){
				LOGGER.AddCommunityUrl(URl + "::::::::::::::::::::::::Return");
				return;
			}
			if(URl.contains("https://cbhhomes.com/communities/twin-falls/grandview-estates/")||URl.contains("https://cbhhomes.com/communities/mountain-home/morning-view/")||URl.contains("https://cbhhomes.com/communities/nampa/meriwether-park/")||URl.contains("https://cbhhomes.com/communities/kuna/saranda/")
					|| URl.contains("https://cbhhomes.com/communities/meridian/woodburn/") || URl.contains("https://cbhhomes.com/communities/boise/locale/")
					|| URl.contains("cedar-spring-apartments/") || URl.contains("/jericho-townhomes/")
					|| URl.contains("roe-street-townhomes/") || URl.contains("the-240-apartments/")||URl.contains("union-square")) {
				LOGGER.AddCommunityUrl(URl + "::::::::::::::::::::::::not present on region page");
				return;
			}
			
			if(URl.contains("https://cbhhomes.com/communities/meridian/laurels/") || URl.contains("https://cbhhomes.com/communities/boise/whitepine/")) return;
			
			U.log("\n"+j+" <:::> PAGE :" + URl);
//			U.log(mainSec);
			String html = U.getHtml(URl, driver);
			if (data.communityUrlExists(URl)) {
				LOGGER.AddCommunityUrl(URl + "\t*********Repeated******\t");
				return;
			}
			LOGGER.AddCommunityUrl(URl);

			
			if(name!=null)
				name = name.replaceAll("Cottages$", "");
			
			U.log("Community Name::> " + name);


			// =============================================Address
			// Section==============================================================

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String GeoCode = "FALSE";
			
			
//			U.log("latlng ::"+Arrays.toString(latlng));

//			String addSec = U.getSectionValue(html, "<dd><address>", "</address></dd>");
//			
//			if(addSec != null){
//				addSec = addSec.replace("<br>", ",").replaceAll("<.*?>", "").replace(", Idaho ", ", ID ");
//				add = U.getAddress(addSec);
//			}
			U.log("ADDRESS: "+Arrays.toString(add));

			// same latlng are present at Direction to Community link
			if (mainSec.contains("latitude\":")) {
				latlng[0] = U.getSectionValue(mainSec, "latitude\":", ",");
				latlng[1] = U.getSectionValue(mainSec, "longitude\":", ",").replace("}", "");
				U.log("ONE latlng[0]: "+latlng[0]+" latlng[1]: "+latlng[1]+" GEO: "+GeoCode);
			}
			
			if (latlng[0].length() < 4 && add[1].length() > 2) {
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getGoogleLatLngWithKey(add);
				GeoCode = "TRUE";
				U.log("TWO latlng[0]: "+latlng[0]+" latlng[1]: "+latlng[1]);
			}
			if ((add[0].length() < 2 || add[3].length() < 2) & latlng[0].length() > 4) {
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getGoogleAddressWithKey(latlng);
				GeoCode = "TRUE";
				U.log("THREE latlng[0]: "+latlng[0]+" latlng[1]: "+latlng[1]);
			}
			
			// ============================================Price and
			// SQ.FT======================================================================
			String[] maltisec = U.getValues(html, "<li><a class=\"menuitem\" href=\"", "\"");

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			String prices[] = U.getPrices(html + mainSec,
					"<div class=\"price\"><div>\\$\\d{3},\\d{3}</div>|minPrice\":\\d{6,7}|high \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|the Low \\$\\d{3},\\d+|primary bold\">\\$\\d{3},\\d{3}|price\"><div><small>\\$\\d{3},\\d{3}",
					0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================

			// String sqftSec = U.getSectionValue(datasec, "<div class=info_content>",
			// "</div>']");

			// 2,157 square feet
			String[] sqft = U.getSqareFeet(html + mainSec,
					">\\d,\\d{3}</span><span>SQ.&nbsp;FT|<dt>SQ\\.&nbsp;FT\\.</dt><dd>\\d{3}</dd>|\\d,\\d{3}\\s+square\\s+feet|\\d,\\d+ to \\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft|\\d,\\d+ sq. ft|SQ\\.( |&nbsp;)FT\\.</dt><dd>\\d,\\d{3}",
					0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqf + " " + maxSqf);

			//============= Home html ==============
			String combinedHomeHtml = null;
			String homeUrls[] = U.getValues(html, "<li><article class=\"card card", "</article>");
			U.log("Home Count ::"+homeUrls.length);
			int k = 0;
			for(String homeUrl : homeUrls){
				
				
				homeUrl = U.getSectionValue(homeUrl, "</a><a href=\"", "\"");
			//	U.log(homeUrl);
				
				if(homeUrl==null || !homeUrl.contains("http"))continue;
				String homeHtml = U.getPageSource(homeUrl);
				String floorSec = U.getSectionValue(homeHtml, "<div class=\"embed\">", "</iframe>");
				if(floorSec!=null) {
					String floorUrl = U.getSectionValue(floorSec, "src=\"", "\"");
					
					String floorhtml = U.getHtml(floorUrl, driver);
//					U.log("-----------"+U.getCacheFileName(floorUrl));
					combinedHomeHtml+=floorhtml.replaceAll("</div>\n\\s+<div class=\"spec-name ng-binding\"> Floors</div>", " Story ");
				}
				String sec = U.getSectionValue(homeHtml, "<section class=\"home-details\">", "<section class=\"cbh-team");
//				U.log(sec);
				if(sec == null) sec = U.getSectionValue(homeHtml, "<section class=\"home-details\">", "<div class=\"request-form");
				combinedHomeHtml += sec;
				if(k++ == 12)break;
			}
//			U.log(">>>>>>>>>>> "+Util.matchAll(combinedHomeHtml, "[\\w\\s\\W]{30}Story[\\w\\s\\W]{30}", 0));
			// =================================Derived Type=====================
			String newRmsec = U.getSectionValue(html, " <listingcardlist", "<ul><li><article class=\"card card--listing");
			if(combinedHomeHtml!=null)
				combinedHomeHtml = combinedHomeHtml.replaceAll("</div>\n" + 
						"                                <div class=\"spec-name ng-binding\"> Floors</div>", " Story");
			
			if(newRmsec!=null)html=html.replace(newRmsec, "");
			String DerivedPType = U.getdCommType((mainSec + html +combinedHomeHtml).replaceAll("Malaspina Ranch.|Ranch Dr|Church Ranch|-Ranch-|Youth Ranch|East Ranch|4 bedroom", ""));
		
			//U.log(">>>>>>>>>>> "+Util.matchAll(mainSec + html +combinedHomeHtml, "[\\w\\s\\W]{30}single[\\w\\s\\W]{30}", 0));
			
			// =================================Community Type=====================
			String rmsec=U.getSectionValue(html, "<h3>Nearby Recreation</h3>", "<h2>Want More Information?</h2>");
			if(rmsec!=null)html=html.replace(rmsec, "");
			html = html.replaceAll("Lakeview Golf", "");
			String Type = U.getCommType(mainSec + html);

			// =================================Property Type=====================
			/*if(maxPrice.length()>3) {
				html=html +"  with Loft    Patio home ";
			}*/
			html=html.replace("offers the luxury of", "luxury homes").replace("estates, townhomes and more", "Estate Residences, Town Home Sites").replace("Offering the luxury ", "luxury homes");
			String pType = U.getPropType((mainSec + html + combinedHomeHtml).replaceAll("idahoartscharter|Home is Cottage Elevation", ""));
			U.log("pType: "+pType);
//			U.log(">>>>>>>>>>> "+Util.matchAll(mainSec + html +combinedHomeHtml, "[\\w\\s\\W]{30}Cottage[\\w\\s\\W]{30}", 0));
			
			// =================================Property Status=====================
			

			
			html=html.replace("NEW PHASE Coming Soon", "new phase coming soon")
					.replace("PHASE #4 COMING SOON!", "Phase 4 Coming Soon!")
					.replace("Phase #2 NOW AVAILABLE", "PHASE 2 NOW AVAILABLE")
					.replace("Phase #2 COMING SOON", "PHASE 2 COMING SOON").replace("Phase #3 COMING SOON","Phase 3 COMING SOON")
					.replace("Phase #4 COMING SOON","Phase 4 COMING SOON")
					.replace("Phase #3 NOW AVAILABLE", "phase 3 NOW AVAILABLE")
					.replace("New homes <span class=\"color-primary bold\">coming soon", "New homes coming soon");

			html = html.replaceAll("</span> Homes Available", " Homes Available");
			html = html.replaceAll("school coming soon|menu-item-53658\"><a>Quick Move in Homes</a>|New homes\\s*<span class=\"color-primary bold\">\\s*coming soon!|last chance to call|<span class=\"color-primary bold\">\\s*coming soon!\\s*</span>|Quick Move in Homes</a>", "");
			String status = U.getPropStatus(html.replaceAll("Shiny new homes coming soon", ""));
			
			U.log("status: "+status);
			
//			U.log(">>>>>>>>>>> "+Util.matchAll( html, "[\\w\\s\\W]{30}now selling[\\w\\s\\W]{30}", 0));
			
			String availHomeStr=Util.match(html, "\\d+ Homes Available");
			U.log(availHomeStr);
			// =================================Property Type=====================
			String note = U.getnote(html);
//			if(status.equals("Coming Soon"))status="New Homes Coming Soon";
			if(URl.contains("/boise/roe-street-townhomes/")) {
				DerivedPType="2 Story";
//				maxSqf="1784";
				minSqf="1,824";
			}
//			if(html.contains("<h2 class=\"light\">Available Homes"))
//			{
//				if(status.length()<3) {
//					status  = "Quick Move-In Homes";
//				}else {
//					status  = status+", Quick Move-In Homes";
//				}
//					
//			}
			
		//	if(html.contains("More opportunities coming soon"))
				//status = status.replace("New Homes Coming Soon", "More Opportunities Coming Soon");
			
			
			if(html.contains("new homes coming soon")) {
				if(!status.contains("New Homes Coming Soon")) {
					if(status==ALLOW_BLANK)
						status = "New Homes Coming Soon";
					else
						status += ", New Homes Coming Soon";
				}
			}
//					
			status = status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon")
					.replace("New Phase Coming Soon, New Homes Coming Soon", "New Phase Coming Soon");
			
			status=status.replace("New Homes Coming Soon, Phase 4 Coming Soon, Coming Soon", "New Homes Coming Soon, Phase 4 Coming Soon");
			
			if(URl.contains("https://cbhhomes.com/communities/nampa/peregrine-estates"))DerivedPType="1 Story";
			
			name=name.replaceAll("Apartments$", "");
			data.addCommunity(name, URl, Type);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), GeoCode);
			data.addPropertyType(pType, DerivedPType);
			data.addPropertyStatus(status);
			data.addNotes(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(ALLOW_BLANK);
		}
		j++;
//		}catch (Exception e) {}
	}
	public static String getHTMLwithProxy(String path)
			throws IOException, NoSuchAlgorithmException, KeyManagementException {

		// System.setProperty("http.proxyHost", "104.130.132.119");
		// System.setProperty("http.proxyPort", "3128");

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);

		// U.log("filename:::" + fileName);

		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(new KeyManager[0], new TrustManager[] { new DefaultTrustManager() }, new SecureRandom());
		SSLContext.setDefault(ctx);

		// chk responce code

		// int respCode = CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);

		{

			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("208.180.237.55", 31012));

			final URLConnection urlConnection = url.openConnection();

			// Mimic browser
			try {
				urlConnection.addRequestProperty("User-Agent",
						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
				urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
				urlConnection.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
				urlConnection.addRequestProperty("Cache-Control", "max-age=0");
				urlConnection.addRequestProperty("Connection", "keep-alive");
				// U.log("getlink");
				final InputStream inputStream = urlConnection.getInputStream();

				html = IOUtils.toString(inputStream);
				// final String html = toString(inputStream);
				inputStream.close();

				if (!cacheFile.exists())
					FileUtil.writeAllText(fileName, html);

				return html;
			} catch (Exception e) {
				U.log(e);

			}
			return html;
		}

	}

}



class DefaultTrustManager implements X509TrustManager {
	@Override
	public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		// TODO Auto-generated method stub
	}

	@Override
	public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		// TODO Auto-generated method stub
	}

	@Override
	public X509Certificate[] getAcceptedIssuers() {
		// TODO Auto-generated method stub
		return null;
	}

}