package com.shatam.b_101_120;

import java.io.*;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class SignatureHomes extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	WebDriver driver;
	static String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
			ALLOW_BLANK };

	public static void main(String args[]) throws Exception {

		AbstractScrapper a = new SignatureHomes();
		//U.logDebug(true);
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Signature Homes.csv", a.data()
				.printAll());
	}

	public SignatureHomes() throws Exception {

		super("Signature Homes", "https://e-signaturehomes.com/");
		LOGGER = new CommunityLogger("Signature Homes");
	}

	public void innerProcess() throws Exception {
	
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String html = U.getHTML("https://e-signaturehomes.com/communities/");
		String sections[] = U.getValues(html, "<div class=\"community-city", " Learn More</div> ");
		U.log("tOTAL cOMM"+sections.length);
		
		for(String section : sections){
			U.log(section);
			String regionUrl = U.getSectionValue(section, "<a href=\"", "\"");
//			U.log("regionUrl ::"+regionUrl);
			String regHtml = U.getHTML(regionUrl);
			
			String locationSection = U.getSectionValue(regHtml, "var locations  = [", "];");
//			U.log(locationSection);

			String comSections[] = U.getValues(regHtml, "<div class=\"feature-box ", "<div class=\"clearfix\">");
			U.log("INNER SEC"+comSections.length);
			
			for(String comSec : comSections){
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
				U.log("comUrl==="+comUrl);
//				try {
					extractCommunities(comUrl, comSec, locationSection);
//				} catch (Exception e) {}
			}
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	//TODO : For Extraction of Communities
	private void extractCommunities(String comUrl, String comSec, String locationSec) throws Exception{
//	if(j == 6)
	{
		
//------------SINGLE EXE.		
//		if(!comUrl.contains("https://e-signaturehomes.com/live/blackridge/"))return;
			
		if (data.communityUrlExists(comUrl))
			return;
		
		if(comUrl.contains("https://e-signaturehomes.com/live/blackridge/the-landing-at-blackridge-2/"))
		{
			LOGGER.AddCommunityUrl(comUrl + "*********Page Not Found******");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j + "\tcomUrl :"+comUrl);
		if(comUrl.contains("http://livestmarlo.com/"))
			comUrl = "https://livestmarlo.com/";
		
		String html = U.getHTML(comUrl.trim());
		U.log(U.getCache(comUrl));
		
		if(html.length()<31)html = U.getPageSource(comUrl.trim());
		// ================ commName ===================
		String commName = Util.match(comSec, "/\">(.*?)</a></h3>", 1);
		U.log("Name :" + commName);
//		U.log(locationSec);

		//================= Nav Section =====================
		String navSection = U.getSectionValue(html,"aria-label=\"Navigation Menu\"" , "</nav>");//"<nav>"
		if(navSection == null)
			//navSection = U.getSectionValue(html, "<ul id=\"menu-header\"", "</div>");
			navSection = U.getSectionValue(html, "<ul class=\"sub-menu\">", "Design Studio");
		if(navSection == null)
			navSection=U.getSectionValue(html, "<ul id=\"menu-primary-navigation\"", "</nav>");
		//U.log("nnav secv11= "+navSection);
		
		if(navSection == null) navSection =ALLOW_BLANK;
		//U.log("nnav secv22= "+navSection);
		
		String contactHtml = null, floorHtml = null, quickHtml= null, amentiesHtml = null, explore=null, siteHtml=null;
		String navUrls[] = U.getValues(navSection, " href=\"", "\"");
		for(String navUrl : navUrls){
			U.log("NNC "+navUrl);
			
			if(navUrl.equals("#"))continue;
			if(navUrl.contains("/events"))continue;
			if(navUrl.contains("/account"))continue;
			if(navUrl.contains("/interiors"))continue;
			if(navUrl.contains("/exteriors"))continue;
			if(navUrl.contains("/residents"))continue;
			
			if(navUrl.equals("https://e-signaturehomes.com/communities/"))continue;
			if(navUrl.equals(comUrl))continue;
			
			if(navUrl.contains("site-map/")||navUrl.contains("site-map/")||navUrl.contains("site-plan/")||navUrl.contains("/site_map")) {
				U.log(navUrl);
				
          		siteHtml=U.getHtml(navUrl,driver);
          		
			}
			
			if(navUrl.contains("/amenities")){
			//	U.log(navUrl);
				amentiesHtml += U.getHTML(navUrl);
				continue;
			}
			if(navUrl.contains("/community/")){
			//	U.log(navUrl);
				amentiesHtml += U.getHTML(navUrl);
				continue;
			}
			if(navUrl.contains("/floorplans") || navUrl.contains("/floor-plans")){
				U.log("FloorUrl :: "+navUrl);
				floorHtml += U.getHTML(navUrl);
				continue;
			}
			if(navUrl.contains("/quickdelivery")){
			//	U.log(navUrl);
				quickHtml = U.getHTML(navUrl);
				continue;
			}
			if(navUrl.contains("https://e-signaturehomes.com/live/abingdon-lake-wilborn/")){
				contactHtml = U.getHTML("https://e-signaturehomes.com/communities/abingdon-at-lake-wilborn/landing/");
				continue;
			}
			if((navUrl.contains("/communities") && !navUrl.contains("/floor-plans") ) || navUrl.contains("/contact")){
			//	U.log(navUrl);
				contactHtml = U.getHTML(navUrl);
				continue;
			}
			
			if(navUrl.contains("/explore")) {
				explore=U.getHTML(navUrl);
			}
			
			
			U.log(navUrl);
		}
	     if(comUrl.contains("https://e-signaturehomes.com/communities/the-hills-at-chelseas-way/")) {
	    	 U.log("Hello");
	    	 siteHtml=U.getHtml("https://the-hills-at-chelseas-way-signature-homes.idapro.cloud/site_map",driver); 
	    	 U.log("pathMMM::"+U.getCache("https://the-hills-at-chelseas-way-signature-homes.idapro.cloud/site_map"));
	     }
	     	     
		if(comUrl.contains("https://e-signaturehomes.com/live/blackridge/the-landing-at-blackridge-2/"))
			floorHtml+=U.getHTML("https://e-signaturehomes.com/communities/the-landing-at-blackridge/");
		//========= Notes ===========
		String note = ALLOW_BLANK;
		
		// =============== Address ==================
		String geo = "FALSE";
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		
		if(contactHtml == null)
			contactHtml = html;
		if(contactHtml != null && contactHtml.length()>31){
			//U.log("contactHtml: "+contactHtml);
			String addSec = Util.match(contactHtml, "maps.google.com/\\?q=(.*?)\" target=\"_blank\">(.*?)</a>.",2);
			if(addSec!=null){
				addSec = addSec.replaceAll("Plowson Road Mt. Juliet TN|Plowson Road, Mt. Juliet TN", "Plowson Road, Mt. Juliet, TN").replace("Hoover AL", "Hoover, AL");
				U.log(addSec);
				add = U.getAddress(addSec);
			}
			else {
				
				addSec = U.getSectionValue(contactHtml, "<h4>Location</h4><p>", "</a></p>");
				if(addSec!=null) {
					addSec = addSec.replaceAll("</a><br />|<br />", ",");
				add = U.getAddress(U.getNoHtml(addSec));}
			}
			
			
			String latLngSec = U.getSectionValue(contactHtml, "maps.google.com/?q=", "\"");
			U.log("latLngSec: "+latLngSec);
			
			if(latLngSec != null )
				latLng = latLngSec.split(",");
			
			if(latLngSec==null) {
				
				latLngSec = U.getSectionValue(contactHtml, "<a href=\"https://www.google.com/maps/", "\"");
				U.log("latLngSec inside: "+latLngSec);
				
				if(latLngSec!=null) {
				latLngSec = U.getSectionValue(latLngSec, "/@", "/");
				latLng = latLngSec.replaceAll(",234m|,\\d+z", "").split(",");
				}
			}
			
			U.log("LatLng :"+Arrays.toString(latLng));
		}
		if(comUrl.contains("https://e-signaturehomes.com/live/stockton/")) {
			add[0]=ALLOW_BLANK;
			add[1]="Trussville";
			add[2]="AL";
			add[3]=ALLOW_BLANK;
			latLng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
			note = "Address And Lat-Long Is Taken From City & State";
		}
		if(comUrl.contains("https://liveblackridgebend.com/") ||
				comUrl.contains("https://e-signaturehomes.com/live/blackridge/")) {
			add[0]=ALLOW_BLANK;
			add[1]="Hoover";
			add[2]="AL";
			add[3]=ALLOW_BLANK;
			latLng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
			note = "Address And Lat-Long Is Taken From City & State";
		}
		
		if(comUrl.contains("https://e-signaturehomes.com/communities/the-river-at-blackridge/")) {
			add[0]=ALLOW_BLANK;
			add[1]="Hoover";
			add[2]="AL";
			add[3]=ALLOW_BLANK;
			latLng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
			note = "Address And Lat-Long Is Taken From City & State";
		}
		if(comUrl.contains("/communities/the-hills-at-chelseas-way/")) {
			String addSec = U.getSectionValue(html, "<div class=\"mt60 mb60\"><p class=\"navy\"> ", "<span class=\"hide\">");
			String latLngSec = U.getSectionValue(addSec, "<a href=\"https://maps.google.com/?q=", "\"");
			latLng = latLngSec.split(",");
			addSec=U.getSectionValue(addSec, ">", "<");
			U.log("this is addSec::::::::"+addSec);
			add= U.getAddress(addSec);
			
		}
		if(comUrl.contains("https://livestmarlo.com/")) {
			String addSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\">");
			U.log("addSec: "+addSec);
			String latSec = U.getSectionValue(addSec, "/@", ",17z/");
			latLng = latSec.split(",");
			addSec = U.getSectionValue(addSec, "/place/", "/@");
			U.log(addSec);
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
//			note = "Address And Lat-Long Is Taken From City & State";
			U.log("From Here000000");
		}
		
		
		U.log("Add ::"+Arrays.toString(add));
		U.log("LatLng ::"+Arrays.toString(latLng));

		if(floorHtml == null && quickHtml == null){
			String floorUrlSection = U.getSectionValue(html, "View Community Site Plan</a>", "View Floor Plans</a>");
			if(floorUrlSection != null){
				String floorUrl = U.getSectionValue(floorUrlSection, "<a href=\"", "\"");
				U.log("floorUrl :"+floorUrl);
				floorHtml = U.getHTML(floorUrl);
			}
		}
		//============== Quick Deliveries ==============
		if(floorHtml != null && quickHtml == null){
			String quickUrlSection = U.getSectionValue(floorHtml, "Floor Plans</a>", "class=");
			if(quickUrlSection != null){
				String quickUrl = U.getSectionValue(quickUrlSection, "<a href=\"", "\"");
				if(quickUrl == null){
					quickUrlSection = U.getSectionValue(floorHtml, "Ready To See What's Next?", "View all floor plans");
					if(quickUrlSection != null) quickUrl = U.getSectionValue(quickUrlSection, " href=\"", "\"");
				}
				U.log("quickUrl :"+quickUrl);
				if(quickUrl != null)
					quickHtml = U.getHTML(quickUrl);
			}
		}
		//========== Floor Plans ==================
		if(floorHtml == null && quickHtml != null){
			quickHtml = U.removeComments(quickHtml);
			String floorUrlSection = U.getSectionValue(quickHtml, "Floor Plans</h2>", "Floor Plans</a>");
			if(floorUrlSection != null){
				String floorUrl = U.getSectionValue(floorUrlSection, "<a href=\"", "\"");
				
				U.log("floorUrl :"+floorUrl);
				floorHtml += U.getHTML(floorUrl);
			}
		}
		int quickHomeCount = 0;
		int soldQuickHomeCount = 0;

		if(quickHtml != null){
			String quickHomeSections[] = U.getValues(quickHtml, "<div class=\"floor-plan__single", "class=\"floor-plan__thumb");
			quickHomeCount = quickHomeSections.length;
		}
		//========== Price ===========

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log(comSec);
		html = html.replaceAll("0’s|0's|0s", "0,000").replace("Mid-200's", " Mid $200,000").replace(" mid 200s", " mid $200,000");
		comSec = comSec.replace("$800k", "$800,000").replace("0s","0,000").replace("0’s","0,000");
//		U.log(comSec);
		
		
		String[] price = U.getPrices(comSec +floorHtml+ quickHtml+html, 
						"\\$\\d{3},\\d{3}|starting in the High \\$\\d{3},\\d{3}|mt10\"> \\$\\d{3},\\d{3}</p>|from the \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|from the MID \\$\\d{3},\\d{3} to LOW \\$\\d{3},\\d{3}|Price: \\$\\d+,\\d+|low \\$\\d+,\\d+ to \\$\\d+,\\d+|begin in the \\d+,\\d+|Low \\$\\d+,\\d+|Mid \\$\\d{3},\\d{3}|(low|upper) \\$?\\d{3},\\d{3}|mt10\">\\s*\\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log("MMMMMMMMM"+Util.match(floorHtml, "[\\s\\w\\W]{50}2,471[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMM"+Util.match(quickHtml, "[\\s\\w\\W]{50}2,471[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMM"+Util.match(html, "[\\s\\w\\W]{50}1,900[\\s\\w\\W]{50}", 0));


		// =============== Square Feet ===============
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(quickHtml+floorHtml+html,
				"Ranging from \\d,\\d{3} square feet to over \\d,\\d{3} square feet|range between \\d,\\d{3} and \\d,\\d{3} square feet|Ranging from \\d,\\d{3} square feet to \\d,\\d{3} square feet|Ranging from \\d,\\d{3} to \\d,\\d{3} square feet|from \\d,\\d{3} to almost \\d,\\d{3} square feet|Square Footage:\\s*\\d,\\d{3}-\\d,\\d{3}|Square Footage: \\d+,\\d+|Square Footage: \\d{4}|Square Footage:\\s*\\d,\\d{3}</p>", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft :"+minSqf+"\tMaxSqft :"+maxSqf);
		
//		U.log("MMMMMMMMM"+Util.match(floorHtml, "[\\s\\w\\W]{50}4,000[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMM"+Util.match(quickHtml, "[\\s\\w\\W]{50}4,000[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMM"+Util.match(html, "[\\s\\w\\W]{50}4,000[\\s\\w\\W]{50}", 0));
		
		
	// ============= Property Status ==============
		String modelStatus =U.getSectionValue(html, "\"message\":\"", "\",")+U.getSectionValue(html, "<h2", "</h2>");
		
		String stsSec = ALLOW_BLANK;
		if(html.contains("Blackridge Bend is offering limited opportunities")) {
			stsSec = U.getSectionValue(html, "Blackridge Bend is offering", "property");
		}
		
		U.log("modelStatus::::::::"+modelStatus);
		String status = U.getPropStatus((comSec+modelStatus+stsSec).replaceAll("New Phase<br />\\s*Now Selling<","New Phase Now Selling").replaceAll("New Phase<br />\n\\s*Coming Soon", "New Phase Coming Soon")
				.replaceAll("more about our final phase", ""));

		if(quickHomeCount > 0 && !status.contains("Quick Delivery Homes")){
			if(status == ALLOW_BLANK) status = "Quick Delivery Homes";
			else status = status +", Quick Delivery Homes";
		}
		
		U.log("status: "+status);
//		U.log("MMMMMMMMM"+Util.match(comSec+modelStatus, "[\\s\\w\\W]{50}limited oppo[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMM"+Util.match(html, "[\\s\\w\\W]{50}limited oppo[\\s\\w\\W]{50}", 0));

		
		String dType = U.getdCommType(comSec + html.replace("caption\":\"Picturesque landscape, fenced ranch at sunrise", ""));

//		U.log("MMMMMMMMM"+Util.match( html, "[\\s\\w\\W]{50}ranch[\\s\\w\\W]{50}", 0));
//		U.log("MMMMMMMMM"+Util.match(comSec , "[\\s\\w\\W]{50}New Phase[\\s\\w\\W]{50}", 0));

		
		//============ Property Type =================
		html = U.removeSectionValue(html, "<head>", "</head>");
		if(amentiesHtml != null)
			amentiesHtml = U.removeSectionValue(amentiesHtml, "<head>", "</head>");
		
		html = html.replace("A luxury resort-style neighborhood", "A luxury living resort-style neighborhood")
				.replaceAll("luxurious master bath|farmhouse located", "").replace("Luxury Meets Lifestyle", "Luxury homes Meets Lifestyle");
//		regSec = regSec.replaceAll("luxurious master bath", "");
		
		String pType = U.getPropType((comSec + html.replaceAll("custom built homes|custom waterfront home|Waterfront Custom Home", "exceptional custom home").
				replaceAll("ranch at sunrise\"|Apartment</option>|and luxury custom homes|Patio MLS|/Patio|Upstairs Common|Patio-|luxurious master bath","")
				+amentiesHtml).replace("all from your riverfront estate", "estate community").replaceAll("<h3>Lake Craftsman|quality craftsmanship|ranch at sunrise\"|luxury custom homes|The community offers custom homes and|We offer custom homes|newly built, custom homes",""));
		//U.log("------ "+Util.matchAll( comSec + html + amentiesHtml, ".*ranch.*", 0));
		
//		U.log("MMMMMMMMM"+Util.match(amentiesHtml , "[\\s\\w\\W]{50}Craftsman[\\s\\w\\W]{50}", 0));
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/mcbridge.txt", jsonSection);
		
		//=========== Community Type ====================
		

		html = html.replace("Residents can easily access our very own Blackridge Lake", "Residents can easily access our very own Blackridge LakeFront Community");
		String cType = U.getCommunityType((comSec + html+amentiesHtml+explore)
				.replaceAll("resort-style pool|Our communities are master|Resort-Style-Swimming-Pool|s newest community that offers lakeside living, resort-", ""));

//		if(comUrl.contains("https://e-signaturehomes.com/communities/the-hills-at-chelseas-way/")) 
//		{
//			add[1] = "Cross Plains";
//			add[2] = "TN";
//			
//			latLng = U.getlatlongGoogleApi(add);
//			if(latLng == null) latLng = U.getlatlongHereApi(add);
//			add = U.getAddressGoogleApi(latLng);
//			if(add == null)add = U.getAddressHereApi(latLng);
//			geo = "True";
//			
//			note = "Address And Lat-Long Is Taken From City & State";
//		}
		if(comUrl.contains("liveknoxsquare") || comUrl.contains("abingdon-lake-wilborn/")) 
		{
			add[1] = "Hoover";
			add[2] = "AL";
			
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getAddressHereApi(latLng);
			geo = "True";
			
			note = "Address And Lat-Long Is Taken From City & State";
		}
		
		if(comUrl.contains("https://livejunelake.com/")) 
		{
			add[1] = "Williamson County";
			add[2] = "TN";
			
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getAddressHereApi(latLng);
			geo = "True";
			
			note = "Address And Lat-Long Is Taken From City & State";
		}
		

		if(comUrl.contains("https://thehighlandsatblackridge.com/") || //comUrl.contains("https://e-signaturehomes.com/live/blackridge/")
				comUrl.contains("https://e-signaturehomes.com/live/lake-wilborn/") || comUrl.contains("https://e-signaturehomes.com/live/mcdaniel-estates/")
				|| comUrl.contains("https://e-signaturehomes.com/communities/the-landing-at-blackridge-2/")){
			

			add[1] = "Hoover";
			add[2] = "AL";
			
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getAddressHereApi(latLng);
			geo = "True";
			
			note = "Address And Lat-Long Is Taken From City & State";
		}
		
		if(comUrl.contains("https://e-signaturehomes.com/live/jackson-hills/")) 
		{
			add[1] = "Mt. Juliet";
			add[2] = "TN";
			
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latLng);
			if(add == null)add = U.getAddressHereApi(latLng);
			geo = "True";
			
			note = "Address And Lat-Long Is Taken From City & State";
		}
		
		if(comUrl.contains("https://e-signaturehomes.com/live/green-trails/")) {
			add[0] = "Flemming Pkwy";
			add[1] = "Hoover";
			add[2] = "AL";
			add[3] = "35080";
		}
		
		if(comUrl.contains("/mcdaniel-farms"))status="Now Selling, No Quick Delivery Homes";
		if(comUrl.contains("https://e-signaturehomes.com/live/blackridge/the-landing-at-blackridge-2/")){
			
			minSqf = ALLOW_BLANK;maxSqf = ALLOW_BLANK;
			minPrice = ALLOW_BLANK;maxPrice = ALLOW_BLANK;
			
		}
		if(comUrl.contains("https://liveknoxsquare.com/"))maxSqf = "3609";
		if(status!=null)
			status = status.replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		if(comUrl.contains("http://livestmarlo.com/"))dType = ALLOW_BLANK;
		if(comUrl.contains("https://e-signaturehomes.com/live/blackridge/the-landing-at-blackridge-2/")) {
			status=status.replace("Now Selling", "New Phase Now Selling");
		}
		
		//===============site map===============
		String siteMapUrl=ALLOW_BLANK,siteMapHtml=ALLOW_BLANK,noOfUnits=ALLOW_BLANK;
		int lotCount=0;
		String []lotData=null;
		String siteMapUrlSec=null;
		if(html.contains("Site Plan")||html.contains("Site Map")) {
			U.log("HOO");
			
			
		if(siteHtml != null) {
			
			
			siteMapUrlSec=U.getSectionValue(siteHtml, "<iframe", "</iframe>");
			U.log("siteMapUrlSec: "+siteMapUrlSec);
		
		if(siteMapUrlSec!=null) {
			siteMapUrl=U.getSectionValue(siteMapUrlSec, "data-src=\"", "\"");
			if(siteMapUrl!=null) {
			siteMapHtml=U.getHtml(siteMapUrl,driver);
			U.log("path2::"+U.getCache(siteMapUrl));
			U.log("lots"+siteMapHtml.contains("<g id=\"Lots\">"));
			U.log("lots2"+siteMapHtml.contains("<g id=\"svg-pan-zoom-controls\""));
			String lotMapSec=U.getSectionValue(siteMapHtml, "<g id=\"Lots\">", "<g id=\"svg-pan-zoom-controls\"");
			lotData=U.getValues(lotMapSec, "<g id=\"_", "/>");
			lotCount=lotData.length;
			noOfUnits=Integer.toString(lotCount);
			U.log(Util.match(siteHtml, "<g id=\"101"));
//			if(comUrl.contains("the-hills-at-chelseas-way")) {
//				U.log(Util.match(siteHtml, "<g id=\"101"));
//				//String lotSec=U.getSectionValue(siteHtml, "<g id=\"Lots\">", "<g id=\"svg-pan-zoom-controls\"");
//				String []lotData2=U.getValues(siteHtml, "<g id=\"_", "</g>");
//				U.log("PPPPPPPPPPPPPP"+lotData2.length);
//				lotCount=lotData2.length;
//				
//				noOfUnits=Integer.toString(lotCount);
//			}
			}
		}
		else
		{
			U.log("jjjjJJK");
			lotData=U.getValues(siteHtml, "<g id=\"Lot_", "</g>");
			lotCount=lotData.length;
			noOfUnits=Integer.toString(lotCount);
		}
		
		if(noOfUnits.equals("0"))
			noOfUnits=ALLOW_BLANK;
		}
	}

		U.log("No Of Units"+noOfUnits);
		
		//PRICE FROM IMAGES
		if(comUrl.contains("https://e-signaturehomes.com/live/blackridge/")) {
			minPrice = "$355,000";
			maxPrice = "$417,000";
		}
		

		data.addCommunity(commName, comUrl, cType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);
		data.addUnitCount(noOfUnits);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	
	}
	j++;
	}
	



}