package com.shatam.b_121_140;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.IFEQ;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;
//import org.apache.xml.serializer.utils.Utils;
//import bsh.util.Util;

public class ExtractCavinessCatesCommunities extends AbstractScrapper {
	public int inr = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	WebDriver driver = null;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractCavinessCatesCommunities();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Caviness and Cates Communities.csv", a	.data().printAll());
	}

	public ExtractCavinessCatesCommunities() throws Exception {

		super("Caviness and Cates Communities",
				"https://www.cavinessandcates.com");
		LOGGER = new CommunityLogger("Caviness and Cates Communities");
	}

	// int k=0;
	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String url = "https://www.cavinessandcates.com";
		String html = U.getHTML(url);
		String mainSec = U.getSectionValue(html, "Find Your Home", "</li>");
		String valus[] = U.getValues(mainSec, "href=\"", "\"");
		for (String itom : valus) {
			if(itom.contains("googletag"))continue;
			String cityUrl = "https://www.cavinessandcates.com" + itom;
			U.log("cityUrl: "+cityUrl);
			
			String cutyhtml = U.getHTML(cityUrl);
			String comvalus[] = U.getValues(cutyhtml,"<b class=\"text-medium text-tundora\"","DETAILS</b></a>");
			int k = 0;
			//int totalComm = comvalus.length / 2;
			for (String info : comvalus) {
				 //U.log(k + "=====" + info);
				// if(inr==0||inr==totalComm||inr==totalComm+1||inr==comvalus.length-1)
				String comUrl = U.getSectionValue(info, "href=\"", "\"");
				U.log(+k+" URLS: "+"https://www.cavinessandcates.com" +comUrl);
				addDetails("https://www.cavinessandcates.com" +comUrl, info, k);
				k++;
				//findurl(info);
				// break;
			}

			// break;

		}
		LOGGER.DisposeLogger();
		try{driver.quit();}catch(Exception e){};
		
	}

	int i = 0;

//	private void findurl(String info) throws Exception {	
//		// String html = U.getHTML(cityurl);
//		info = info.replace("<a href=\"#\" class=", "");
//		String url = U.getSectionValue(info, "<a href=\"", "\"");
//		addDetails(url, info, i);
//		//U.log("count--->"+i);
//		i++;
//	}
	//TODO : Extract communities details here
	private void addDetails(String url, String info, int i)	throws Exception {
//	if(j >= 27)
		try{

		{
//		if(!url.contains("https://www.cavinessandcates.com/new-homes/nc/clayton/gordon-park/5550/#anchor")) return;


			U.log("::::::::::::"+j+"\nPAGE:" + url);
			U.log(U.getCache(url));

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url	+ "*****************************REPEAT");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			
			//String html = getHtml(url, driver);
			String html = U.getHtml(url, driver);
			html=html.replace("No lots are available","");
			//========= community name ====================
			String commuName = U.getSectionValue(info, ">",	"<");
			commuName = commuName.replaceAll("Villas$", "");
			U.log("COOMMNAME::" + commuName);
			
			// ================== Notes =================
			String note = U.getnote(html);
			//========= lat long valus ==================
			String latitude = null;
			String longitude = null;
			String geo = "False";
			// {lat:34.76109167583707, lng:-76.62900030612946}
			//U.log(info);
			latitude = U.getSectionValue(info, "latitude=\"", "\"");
			longitude = U.getSectionValue(info, "longitude=\"", "\"");
			U.log("lat : "+latitude+"  lng :" + longitude);
			
			if(latitude == null) {
				String latlngSec = U.getSectionValue(html, "OiMap.Single", "nearby");
				latitude = U.getSectionValue(latlngSec, "latitude':", ",");
				longitude = U.getSectionValue(latlngSec, "longitude':", ",");
				U.log(" FROM HERE lat : "+latitude+"  lng :" + longitude);
			}
			
			if(latitude.length()==0){
				String latlngSec = U.getSectionValue(html, "var myLatlng = new google.maps.LatLng(", ")");
				String ll [] = latlngSec.split(",");
				latitude = ll[0];
				longitude = ll[1];
				U.log("lat : "+latitude+"  lng :" + longitude);
			}

			//=========== Address ===============
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			//html = html.replace("</p><p>Directions", "</p><p><strong>Directions");
			String addSec = U.getSectionValue(html, "content-end\"><div>", "</div>");
			if(addSec!=null)
			{
			addSec=addSec.replace("[300 - 399]","300-399").replace("<br />", ",");
			}
			
			U.log("addSec=="+addSec);
			if(addSec == null)
				addSec = U.getSectionValue(html, "Directions</h3>", "</p><p><strong>");
			if(addSec == null)
				addSec = U.getSectionValue(html, "Directions</h3>", "<p>Direction");
			if(addSec == null) {
				String addSecmain = U.getSectionValue(html, "justify-content-end", "oi-aspect four-three sixteen");
				if(addSecmain == null)
					addSecmain = U.getSectionValue(html, "justify-content-end", "video-hero");
				
				addSec = U.getSectionValue(addSecmain, "<div>", "</div>");
				addSec = addSec.trim().replaceAll("<br />", ",");
				U.log("addSec inside: "+addSec.trim());
			}
				
			
			//U.log("addSec=="+addSec);
			if(addSec != null && !addSec.contains("GPS Coordinates:")){
				addSec = addSec.replaceAll("<br/>|</p>", ",").replaceAll("<p>|\\((.*)?\\)", "").replace("Spring Lake", ",Spring Lake").replace("Youngsville", ",Youngsville")
						.replaceAll("Fayetteville NC|, Fayetteville NC", ", Fayetteville, NC").replace("Hope Mills", ",Hope Mills").replace("Raeford", ",Raeford").replaceAll("</strong>|\\[|\\]", "")
						.replace("Greenville", ",Greenville").replaceAll("<br>,|, ,", ",").replace("�","");
				addSec = addSec.replace("<br> ", ", ").replace(", ,", ",");
				U.log(addSec);
				if(addSec.contains(","))
				add = U.getAddress(addSec);
				U.log("ADDRESS HERE: "+Arrays.toString(add)+" GEO: "+geo);
			}
			
			if(add[3] == null) add[3] = ALLOW_BLANK;
			if(latitude.equals("33.95") && longitude.equals("78.58")){
				add [1] ="Calabash";
				add [2] = "NC";
				String latLng[] = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getGoogleAddressWithKey(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "True";
				latitude = latLng[0];
				longitude = latLng[1];
				note = "Address & Lat-Lng Is Taken From City & State";
			}
			if (latitude != null && (add[0] == ALLOW_BLANK || add[3]== ALLOW_BLANK)) {
				if (latitude.trim().length() > 4) {
					String latlng[] = { latitude, longitude };
					add = U.getAddressGoogleApi(latlng);
					if(add == null) add = U.getGoogleAddressWithKey(latlng);
					if(add == null) add = U.getAddressHereApi(latlng);
					geo = "True";
				}
			}
			
			//========= Get floor plan HTML =============
//			String floorHtml=ALLOW_BLANK;
			String floorPlanhtml = getHtml(url, driver);
			String comHtml = ALLOW_BLANK;

		
			
			//get data for individual homes
			String allHomesData = ALLOW_BLANK;
			String availHomesec=U.getSectionValue(html, "<div id=\"community-homes\"", "<div class=\"col-xs-12 community-directions\">");
			String urlSec[] = null;
		
			//TODO :============Quick Homes ====================
			
			String quickHomeSection = U.getSectionValue(html, "<div class=\"caviness-pane p-3 active\"", "</div></div></div></div></div>");
			int quckHomeCount = 0;
			int soldCount = 0;
			int quickCountStatus = 0;
			
			String count[] = null;
			String combinedQuickHtml = null;
			if(quickHomeSection != null){
//				count = U.getValues(quickHomeSection, "<b class=\"text-medium text-tundora\">", "DETAILS");
				count = U.getValues(quickHomeSection, "<div class=\"p-3\">", "DETAILS");
				U.log("totyal qkm v "+count.length);

				
				for(String q : count) {
					
					//U.log("q =="+q);
					if(q.contains("SOLD") || q.contains(">Model Home<")||q.contains("Coming Soon")) //here, Model Home is not included a quick move in homes on given builder
						soldCount +=1;
				}
					
				String quickUrls[] = U.getValues(quickHomeSection, "center\" href=\"", "\"");
				for(String quickUrl :quickUrls){
					if(quickUrl.contains("google"))continue;
					if (!quickUrl.contains("http"))quickUrl = "https://www.cavinessandcates.com" + quickUrl;
					U.log("quickUrl =="+quickUrl);
					String quickHomeHtml = U.getHTML(quickUrl);
					
					//for status purpose
					if(quickHomeHtml.contains("Move-In Ready!</h1>")) {
						
						quickCountStatus++;
					}
					
					combinedQuickHtml += U.getSectionValue(quickHomeHtml, "<h1 class=\"caviness-title","</ul>"); //"id=\"overview\">", "</ul>");
//					allHomesData += U.getSectionValue(quickHomeHtml, "<h1 class=\"address\">", "</section>");
					quckHomeCount++;
				}
			}
			
			U.log("quickCountStatus: "+quickCountStatus);
			
			//TODO :============= Floor PLan =================
			String combinedFloorHtmls = null;
			String floorSection = U.getSectionValue(html, "<div class=\"caviness-pane p-3\"", "</div></div></div></div></div>");
			if(floorSection != null){
				String floorUrls[] = U.getValues(floorSection, "center\" href=\"", "\"");
				for(String floorUrl : floorUrls){
					if(floorUrl.contains("https://www.google.com/maps/dir/"))continue;
					if (!floorUrl.contains("http"))floorUrl = "https://www.cavinessandcates.com" + floorUrl;
			//		U.log("floorUrl=="+floorUrl);
					String floorPlanHtml = U.getHTML(floorUrl);
					combinedFloorHtmls += U.getSectionValue(floorPlanHtml, "id=\"overview\">", "</ul>");
					allHomesData += U.getSectionValue(floorPlanHtml, "<div class=\"col-lg-4 col-md-4 col-sm-12 col-xs-12\">", "</section>");
				}
			}
		

		
			//================= price =======================
			String priceSec = U.getHtmlSection(html,"<h5>Prices starting from</h5>", "<dl class=\"schools\">");
			// U.log(priceSec);
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK, minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;
			html = html.replace("$400s ranging", "$400,000 ranging").replace("&#36;", "$").replaceAll("0s|0’s", "0,000").replaceAll(" (\\d{2})0's", " \\$$10,000s").replaceAll("0's", "0,000").replaceAll("<span class=\"text-medium\">Starting From</span> <b class=\"text-large\">\\$\\d+,\\d+", "");
			String[] price = U.getPrices(html,
							"\\$\\d{3},\\d{3} ranging|THE MID \\$\\d{3},\\d{3}|Price</span> <b class=\"text-large\">\\$\\d{3},\\d{3}</b>|"
							+ "Starting From</span> <b class=\"text-large\">\\$\\d+,\\d+|bold\">from \\$\\d{3},\\d{3}|<p class=\"grid-price\">\\$\\d{3},\\d{3}|Starting at <b>\\$\\d+,\\d+</b>|grid-price\">\\$\\d+,\\d+</p>|\\$\\d+,\\d+ to \\$\\d+,\\d+|start in the \\$\\d+,\\d+|Price: <sup>\\$</sup><strong>\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}",
							0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			//U.log("MMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}\\$4[\\s\\w\\W]{30}", 0));

			//============= square feet ================
			String SqSection = U.getHtmlSection(html, "<div id=\"tab-2\">"," id=\"newsletter-signup-top\">");
			// U.log(SqSection);
			if (SqSection == null) {
				String ifSec = U.getHtmlSection(html,"<h5>Prices starting from</h5>", "</dl>");
				if (ifSec == null) {
					U.log(" null  minsq maxSq");
				} else {
					String ifVal[] = U.getValues(ifSec, "<dd>", "</dd>");
					if (ifVal.length > 1) {
						if (ifVal[1].contains("-")) {
							String val[] = ifVal[1].split("-");
							minSq = val[0].trim();
							if (ifVal.length > 1)
								maxSq = val[1].trim();
						} else {
							minSq = ifVal[1].replace("+", "");
							maxSq = ALLOW_BLANK;
						}
					}
				}
			} else {
				int j = 0;
				String sqvalues[] = U.getValues(SqSection, "<dd>SqFt:", "</dd>");
				int sq[] = new int[sqvalues.length];
				for (String itom : sqvalues) {
					itom = itom.trim();
					itom = itom.replace(",", "");
					Integer a = Integer.parseInt(itom);
					sq[j] = (int) a;
					j++;
				}
				sq = U.getMaxAndMin(sq);
				U.log(sq[0]);
				U.log(sq[1]);
				maxSq = "" + sq[0];
				minSq = "" + sq[1];
			}
			// latitude longitude
			if (minSq.contains("<") && maxSq.contains("<"))
				minSq = ALLOW_BLANK;
			maxSq = ALLOW_BLANK;

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html + floorPlanhtml,
							"\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft|from \\d{1},\\d{3} - \\d{1},\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} square feet|<b>\\d,\\d{3} - \\d,\\d{3} Sq. Ft</b>|<b>\\d,\\d+</b> Sq. Ft.|>\\d,\\d+ Sq Ft</span>|<b>\\d,\\d+ - \\d,\\d+</b> Sq. Ft.|SQ. FT. <b>\\d,\\d+ - \\d,\\d+| \\d,\\d{3}-\\d,\\d{3} square feet|SQ. FT. <b>\\d{4} - \\d{4}<|Sq.Ft. <b>\\d{4} - \\d{4}|\\d+,\\d+ SQ. FT.|SQ. FT. <b>\\d+-\\d+<|from \\d+\\-\\d+\\+ sq ft.|Sq.Ft. <b>\\d{4}",
							0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			
			
			//============= Property Type ============
			html=html.replace("with a traditional \"Main Street\" feel", "traditional style home").replace("modern luxuries", "luxury living").replace("traditional style Mexican cuisine", "");
			
			
//			U.writeMyText(html+comHtml+combinedFloorHtmls+combinedQuickHtml);
			String pType = U.getPropType((info + html+comHtml+combinedFloorHtmls+combinedQuickHtml).replaceAll("the-cottages-at|alt=\"The Cottages at Wilson|The Cottages at Wilson", "")
					.replaceAll("&amp; Townhouses|Townhouses in Pinehurst|Craftsman style front door|craftsman style front door|f-proxima-reg\">Single Family Homes</div><span class=\"d-inline-b", "").replace("custom home builder","").replaceAll("coastal Brunswick|and craftsmanship|Executive Place|armhouse style sink", ""));
			U.log("pType: "+pType);
			
//			U.log("MMMMMMMM "+Util.matchAll((info + html+comHtml+combinedFloorHtmls+combinedQuickHtml), "[\\s\\w\\W]{30}cottage[\\s\\w\\W]{30}", 0));
			
			//comHtml=U.getNoHtml(comHtml);
			//============== Derived community type ==================
			//U.log(comHtml);
			
			comHtml = comHtml.replaceAll("Stories[\\s*\\n*]*1.5", "1.5 Stories");
			comHtml = comHtml.replaceAll("Stories[\\s*\\n*]*2.5", " 2.5 Stories ");
//			comHtml = allHomesData.replaceAll("Stories\\s+1", "1 story");
			comHtml = comHtml.replaceAll("Stories\\s+2", "2 story");
//			allHomesData = allHomesData.replaceAll("<span>Stories\\s*</span>\\s*1/1.5/2\\s*</li>", "1 Stories,1.5 Story,2 Stories").replaceAll("<span>Stories</span>\\s*", "Stories ").replaceAll("Branch|branch", "");
			if(combinedFloorHtmls != null)
				combinedFloorHtmls = combinedFloorHtmls.replaceAll("Stories</span>\\s{2,}", " Story ").replaceAll("\\s{2,}", "").replaceAll("Branch|branch", "");
//			U.log(combinedFloorHtmls);
//			U.log(combinedQuickHtml);
			String quickStories = " ";
			if(combinedQuickHtml != null){
				List<String> stories = Util.matchAll(combinedQuickHtml, "<span>Stories</span>\\s+(\\d(\\.5)?)\\s+</li>", 1);
				if(stories.isEmpty())
					stories = Util.matchAll(combinedQuickHtml, "<span>Stories</span>\\s+<strong>(\\d(\\.5)?)</strong>", 1);
				if(stories.isEmpty())
					stories = Util.matchAll(combinedQuickHtml, "<b>(\\d)</b> Stories</span>", 1);
				
//				U.log(stories.size());
				if(stories != null)
					for(String story : stories) quickStories +=  story+" Story ";
			}
//			U.log(combinedQuickHtml);
//			U.log(quickStories);
			
			String floorStories = "";
			
			if(allHomesData != null){
				List<String> stories = Util.matchAll(allHomesData, "<span>Stories</span>\\s+(\\d(\\.5)?)\\s+</li>", 1);
				if(stories != null)
					for(String story : stories) floorStories +=  story+" Story ";
				allHomesData=allHomesData
						.replaceAll("Stories</span>\\s*<strong>1/1.5/2", "1 Stories, 1.5 Stories, 2 Stories")
						.replaceAll("Stories</span>\\s*<strong>2", "2 story")
						.replaceAll("Stories</span>\\s*<strong>1.5", "1.5 story")
						.replaceAll("Stories</span>\\s*<strong>1", "1 story")
						.replaceAll("Stories</span>\\s*<strong>2.5", "2.5 story");
			}
//			U.log(allHomesData);
//			U.log(floorStories);
			if(combinedFloorHtmls!=null){
				combinedFloorHtmls = combinedFloorHtmls.replace("</b> Stories", " Story")
						.replaceAll("<span> Story 1/1.5/2</li>", "1 Stories, 1.5 Stories, 2 Stories")
						.replaceAll("<span> Story 1/1.5</li>", "1 Stories, 1.5 Stories")
						.replaceAll("Stories</span>\\s*<strong>1", "1 story")
						.replaceAll("Stories</span>\\s*<strong>2", "2 story")
						.replaceAll("Stories</span>\\s*<strong>1.5", "1.5 story").
						replaceAll("Stories</span>\\s*<strong>2.5", "2.5 story");
			}
			//U.log(quickStories);	
			html=html.replace("1 - 2 Stories", "1 Story,2 Story").replace("2 - 2.5 Stories","2 Story, 2.5 stories").replace("1.5 - 2.5 Stories", "1.5 Story - 2.5 Stories").replace("1.5 - 2 Stories", "1.5 Story,2 Story").replace("single-story and two-story", "1 Story, 2 Story").replace("1 - 2.5 Stories", "1 Story, 2.5 Story");
			html = html.replace("<b>1.5 - 2.5</b> Stories", "<b>1.5 stories- 2.5 Stories").replace("<b>1 - 2.5</b> Stories", "<b>1 story- 2.5 story").replace("<b>1 - 2</b> Stories", "<b>1 stories- 2 Stories").replaceAll("<b>(\\d\\.\\d) - (\\d\\.\\d)</b> Stories", "<b> $1 Story - $2 Story </b>")
					.replace("<b>1.5 - 2</b> Stories</span>", "<b> 1.5 Story - 2 Story</b> Stories</span>")
					.replace("1.5 - 3 Stories", "Stories 1.5- 3 Stories");
//			U.writeMyText(html);2 - 2.5 Stories
			String DPType = U.getdCommType((combinedFloorHtmls+ allHomesData+ html.replaceAll("third story", " 3 story ").replace("<b>1.5</b> Stories</span>", "1.5 Story").replaceAll("(B|b)ranch", "")
					+quickStories+floorStories).replaceAll("floor|Floors|Floor", ""));
			//U.log("****::" + combinedFloorHtmls);
			//U.log("MMMMMMMM "+Util.matchAll(combinedFloorHtmls+ allHomesData+ html, "[\\s\\w\\W]{100}Stories[\\s\\w\\W]{100}", 0));
			//======= Property Status ================
			

			if (commuName.contains("Breighmere")) {
				latitude = "35.138303";
				longitude = "-77.099843";
			}
			if (url.contains("http://www.cavinessandcates.com/index/c/community/cid/72/")) {
				latitude = "35.099247";
				longitude = "-76.981850";
			}

			String status = ALLOW_BLANK;
			String statusSec = html;
			
			String sec2 = U.getSectionValue(statusSec, "id=\"headlines\"","gray-center-content");
			if (sec2 != null)
				statusSec = statusSec.replace(sec2, "").replaceAll("regular\">MOVE-IN READY</span>", "Quick Move-in Homes")
						.replaceAll("content=\"join the coming soon list to be the first to know", "list to be the first to know")
						.replaceAll("ates.com/cavinesscates/images/icon-bath.svg?v=1d1019c\"><b>2.5 - 3.5 Bath</b></span> <span><img alt=\"Stories\" src=\"https://static.cavinessandcates.com/cavinesscates/images/icon-stories.svg?v=7887d65\"><b>1.5 S, ates.com/cavinesscates/images/icon-bath.svg?v=1d1019c\"><b>2.5 - 3.5 Bath</b></span> <span><img alt=\"Stories\" src=\"https://static.cavinessandcates.com/cavinesscates/images/icon-stories.svg?v=7887d65\"><b>1.5 S", "\\sAllow");
			String remove = "comingsoonform|COMING SOON<br/> REGISTER|Coming Soon Form|community-home-link\">Quick Move-In|>Quick Move-In <b>Homes</b>|Crossing Quick Move-In Homes|now selling in|\"Now Selling|grand opening|move-in-ready-homes|All Move-In Ready|Move-in Ready Homes|move-in ready homes|Move-In Ready Homes|ready-banner\">Ready to Move|SOON<br> REGISTER";
		
			statusSec = statusSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
//			U.log("info: "+info);
//			 U.log("statsec is " + statusSec);
//			U.writeMyText(statusSec+info);
			String a=(statusSec+info).replace("next phase coming 2021", "Next Phase Coming 2021").replace("0 Quick Move-In", "").replaceAll("regular\">MOVE-IN READY</span>", "Quick Move-in Homes")
					.replaceAll("rounded-circle\\s*d-inline-block mr-\\d\"></span>[c|C]oming|[q|Q]uick [m|M]ove|0 quick move-in|>quick move-ins<|text-medium\">coming soon</span>", "");
			a = a.replaceAll("scheduletourcomingsoon", "");
			
			status = U.getPropStatus(a
					.replaceAll("JOHNSTON COUNTY \\W+", "\\W+\\W+ currently sold out")); 
			
			//.replaceAll("\"><span class=\"text-medium\">Coming Soon</span></div><hr/><div class=\"", "\"><span class=\"text-medium\"</div><hr/><div class=\"")
			
			//for quick count
			int quickCount = 0;
			String quickSec = U.getSectionValue(html, "<div class=\"caviness-tab tab-qmi active\" id=\"qmi\" data-id=\"1\">", "</div>");
			if(quickSec != null) {
				String match = Util.match(quickSec, "(\\d)", 0);
				quickCount = Integer.parseInt(match);
				U.log(">>>>>> quickCount: "+quickCount);
			}
			
			
			if(quickCount > soldCount) {//0
				if(status == ALLOW_BLANK)
					status = "Quick Move-Ins";
				else
					status = status + ", Quick Move-Ins";
			}
//			U.log("MMMMMMMM "+Util.matchAll(a, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));

//			U.log("MATCH FOUND AT: "+Util.matchAll(a, "[\\s\\w\\W]{30}Coming[\\s\\w\\W]{30}", 0));
			U.log("STATUS: "+status);
//			U.log(comHtml+";;;;;;;;;;;;;;;;;hello");
			int newcount = 0;
			if(count!=null)
				newcount = count.length;
			
			U.log("Quick Over Sold Count: "+newcount+" "+soldCount+" "+quckHomeCount);
			if(status.contains("Quick"))
				status=status.replaceAll("Ready To Move In,|Ready To Move In|, Quick Move-in|Quick Move-in,|\\d+ Quick Move-in(,)|Quick Move-in", "");
			
			//quckHomeCount > 0 && newcount>soldCount && html.contains("<div class=\"caviness-tab tab-qmi")
			
			U.log("quickCountStatus: "+quickCountStatus);
			
			if(quickCountStatus>0){
				
				if (status.length()<2) {
					status="Quick Move-Ins";
				}else {
					if (!status.contains("Ready To")||!status.contains("Quick")) {
						status="Quick Move-Ins";
					}
				}
				U.log("I m in here:::::::"+status.length());

			}
//			U.log("quickHomeSection :"+quickHomeSection);
			ArrayList<String> noquick = new ArrayList<>();
			
			if(quickHomeSection!=null)
				noquick=Util.matchAll(quickHomeSection, "<span class=\"ready-banner sold\">Sold</span>|<span class=\"ready-banner sold right\">Sold</span>|<span class=\"model-status bg-red text-regular\">SOLD</span>", 0);
			if(noquick.contains(null)) {
				U.log("helllo");
			}
			U.log(noquick.size()+"::::::::::::"+quckHomeCount);
//			if(noquick.size()>=quckHomeCount) {
//				status=status.replaceAll(", Quick Move-in Homes|Quick Move-in Homes", "");
//				if (status.length()<2) {
//					status="No Quick Move-in Homes";
//				}else {
//					if (!status.contains("Ready To")||!status.contains("Quick")) {
//						status+=", No Quick Move-in Homes";
//					}
//				}
//			}
			
			if(url.contains("https://www.cavinessandcates.com/new-homes/nc/spring-lake/anderson-creek-crossing/5541/#anchor"))status=ALLOW_BLANK;// in cache coming soon is nt aval

			if(url.contains("https://www.cavinessandcates.com/new-homes/nc/carthage/brookwood/5572/"))status="Quick Move-in Homes";
			
			if (add[0] == null)add[0] = ALLOW_BLANK;
			if (add[1] == null)add[1] = ALLOW_BLANK;
			if (add[2] == null)add[2] = ALLOW_BLANK;
			if (add[3] == null)add[3] = ALLOW_BLANK;

			U.log("Address is : " + Arrays.toString(add) );

			if (add[1].length() < 4)
				add[1] = ALLOW_BLANK;
			if (latitude == null) {
				latitude = longitude = ALLOW_BLANK;
			}
			if (latitude.length() < 4) {
				latitude = longitude = ALLOW_BLANK;
			}
			add[0]=add[0].replace(" 300-399 Jethro Mills Rd", "300-399 Jethro Mills Rd").trim().replaceAll("<br>|&nbsp;|,", "");
			
			// U.log(U.getCache(url));
//			if(url.contains("https://www.cavinessandcates.com/new-homes/nc/pinehurst/royal-oak-of-pinehurst/5747/"))status=status.replace(", Quick Move-in Homes", "");
//			if(url.contains("https://www.cavinessandcates.com/community/royal-oak-of-pinehurst"))status="Coming Soon, "+status;
			//============== Community Type =============
			String Type = U.getCommunityType(html.replace("3 golf-courses", "golfing"));
			if(status.length()<4) status = ALLOW_BLANK;
			
			// U.log(":::" + minSq + ":::::" + maxSq);
//			if(url.contains("/new-homes/nc/hampstead/the-sanctuary-at-forest-sound/8302/"))
//				status="New Homes Coming Late Summer 2021, "+status;
			if(url.contains("https://www.cavinessandcates.com/new-homes/nc/aberdeen/legacy-lakes/6274/"))
				status = ALLOW_BLANK;
			if(status.contains("Sold Out"))
				status = "Currently Sold Out";
			if(status!=null)
				status = status.replace("New Homes Coming Late Summer 2021, Coming Late Summer, Coming Soon", "New Homes Coming Late Summer 2021, Coming Soon").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			if(pType.contains(" Townhouse,")&& pType.contains("Townhome"))pType = pType.replaceAll("Townhouse,|, Townhouse", "");
//			if(url.contains("https://www.cavinessandcates.com/new-homes/nc/pinehurst/royal-oak-of-pinehurst/5747/"))
//				pType = pType+",Townhouse";
			status=status.replace("Quick Move-in Homes", "Quick Move-Ins")
					.replace("New Homes Coming Late Summer 2021, Coming Soon, Coming Late Summer 2021", "New Homes Coming Late Summer 2021, Coming Soon");//.replace("Sold Out", "Currently Sold Out");
			
			
					
//			====================================================================================		
			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
			String lot_Sec=U.getSectionValue(html, "<div class=\"panzoom position-absolute\"", "class=\"oi-isp-legend\">");
			if(lot_Sec!=null) {
				lot_data=U.getValues(lot_Sec, "<div class=\" ", "\"></div>");
				 U.log("lotCount=="+lot_data.length);
				if(lot_data.length>0) {
					lotCount=Integer.toString(lot_data.length);
					 U.log("lotCount=="+lotCount);
					}
			}
			
			
			
			data.addCommunity(commuName, url, Type);
			data.addAddress(add[0].replace("<br />", "").trim(), add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latitude, longitude, geo);
			data.addPropertyType(pType, DPType);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
		}catch (Exception e) {}

	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{
			if (!f.exists()) {
				synchronized (driver) {
					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					/*
					 * driver.manage() .addCookie( new
					 * Cookie("visid_incap_612201",
					 * "gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"
					 * ));
					 */
					driver.get(url);
					// Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); // y value '400' can
					// be
					Thread.sleep(4000);
					html = driver.getPageSource();				
					
					try {

						//WebElement option = driver.findElement(By.id("community-floorplans-link")); //community-floorplans-link
//						driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.MINUTES);
//						U.log("::::::::::click success::::::::::::");
						WebElement option = driver.findElement(By.xpath("//*[@id=\"plans\"]")); //community-floorplans-link
//						option.click();
						option.click();
						U.log("::::::::::click success::::::::::::");
						Thread.sleep(4000);
						
						WebDriverWait wait = new WebDriverWait(driver, 5);  
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("community-floorplans")));

						
					} catch (Exception e) {
						U.log(e.toString());
					}

					U.log("Current URL:::" + driver.getCurrentUrl());
					String html1 = driver.getPageSource();
					
					html = html+html1;
					
					Thread.sleep(2000);
					writer.append(html);
					writer.close();
				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}

}