/** @Priti
 *  @date 26/02/2019
 */

package com.shatam.b_121_140;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;

public class ExtractGoodallHomes extends AbstractScrapper {
	WebDriver driver = null;
	int j = 0;
	private static final String builderUrl = "https://www.goodallhomes.com";
	CommunityLogger LOGGER;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractGoodallHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Goodall Homes.csv", a.data().printAll());

	}

	public ExtractGoodallHomes() throws Exception {

		super("Goodall Homes", builderUrl);
		LOGGER = new CommunityLogger("Goodall Homes");

	}

	public void innerProcess() throws Exception {

		String baseHtml = getHTML("https://www.goodallhomes.com/communities");
		baseHtml = U.removeComments(baseHtml);
		String comSections[] = U.getValues(baseHtml, "<div class=\"CommunityCard_wrapper\"", "Visit Community");
		U.log(comSections.length);
		for (String comSec : comSections) {
//==
			comSec=comSec.replace("The Knoll At Fairvue Cottages", "The Knoll At Fairvue").replace("Groves Park Cottages","Groves Park");
//==
			String comUrl = "https://www.goodallhomes.com" + U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");
			String comHtml=U.getHTML(comUrl);
			
			//=============Sub community Section================
			
//			U.log("comUrl======="+comUrl);
			if(comHtml.contains("Home Products</span>")) {
				String subCommSec=U.getSectionValue(comHtml, "Home Products</span>", "</div></div></div></div></div></div></div></div></div></div></div></div></div></div>");
				String[] subCommunityData=U.getValues(subCommSec, "div class=\"CommunityCard_wrapper\"", "Visit Community") ;
			U.log("subCommunityData====="+subCommunityData.length);
			for(String subData : subCommunityData) {
//				U.log("<MMMMMMMMMMMMM");
				String subUrl="https://www.goodallhomes.com"+U.getSectionValue(subData, "href=\"", "\"");
				String subHtml=U.getHTML(subUrl);
				String comName = Util.match(subData,
								"<h4 class=\"CommunityCard_nameTitle\" data-reactid=\"\\d+\">(.*?)</h4>", 1);
					//U.log("comName====="+comName);				
					addDetails(subData,subHtml, subUrl, comName);
//				U.log("SUB URL====="+subUrl);

			}
			}
			else {
			
			String comName = Util.match(comSec,
					"<h4 class=\"CommunityCard_nameTitle\" data-reactid=\"\\d+\">(.*?)</h4><h5", 1);

			addDetails(comSec,comHtml, comUrl, comName);
			}
			// break;
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comSec,String comHtml, String comUrl, String comName) throws Exception {
		//TODO: For Single Comm. execution
//		if (j >= 15) 
//		try{
		{

//		if(!comUrl.equals("https://www.goodallhomes.com/communities/southern-kentucky-area/bowling-green-ky/upton-farms")) return;
		

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + ":::::::repeated");
				return;
			}
			
			if (comUrl.contains("https://www.goodallhomes.com/communities/undefined/undefined/test-community")) {
				LOGGER.AddCommunityUrl(comUrl + ":::::::repeated");
				return;
			}
			
			if (comUrl.contains("https://www.goodallhomes.com/communities/undefined/undefined/carter-crossings")) {
				LOGGER.AddCommunityUrl(comUrl + ":::::::NOT OPENING"); //june 2022
				return;
			}
			
			LOGGER.AddCommunityUrl(comUrl);
			U.log(":::::::::::::::::::::::" + j + ":::::::::::::::::::::::");
			U.log(comUrl);
			comName=comName.replace("Barnett&#x27;s Crossing Villas", "Barnett's Crossing Villas")
					.replace("Barnett&#x27;s Crossing Cottages", "Barnett's Crossing Cottages");
			U.log(comName);
//			comName = comName.replace("&#x27;", "'");
			comSec = comSec.replaceAll("<!----><!---->-<!----><!---->", "-");
//			U.log(comSec);
//			String comHtml = getHTML(comUrl);
			
//			U.log(Util.matchAll(  comHtml + comSec, "[\\w\\s\\W]{10}stories[\\w\\s\\W]{100}", 0));
//			String storydata = U.getdCommType(comHtml.replace("homebuilding companies alike, two- and three-story", "").replaceAll("Floor|floor", "").replaceAll("Stories</b><!-- react-text: \\d+ -->1-1.5", "1 story, and 1.5 story").replaceAll("Stories</b><!-- react-text: \\d+ -->1.5", "1.5 story"));
			String descsec= U.getSectionValue(comHtml, "</script><script data-react-helmet=\"true\" ", ",\"address\"");
//			U.log("storydata ======"+storydata);
//			U.log("MMMMMMM "+Util.matchAll(storydata, "[\\s\\w\\W]{50}three-story[\\s\\w\\W]{50}", 0));

			String discover = U.getSectionValue(comHtml, "<meta data-react-helmet", ".\",\"address\":");
			String navSection  = U.getSectionValue(comHtml, "<ul class=\"CommunityPageMenu_list", "</ul>");
//			U.log(navSection);
			
			
			
			String planHtml = "", quickHtml = "";
			if(navSection != null){
				String navUrlSections[] = U.getValues(navSection, "<a title=", ">");
				
				for(String navUrlSection : navUrlSections){
					
					String navUrl = U.getSectionValue(navUrlSection, "href=\"", "\"");
					U.log(navUrl);
					if(navUrl.length() >7 && !navUrl.startsWith("http")){
						navUrl = "https://www.goodallhomes.com" + navUrl; 
					}
					if(navUrl.contains("/plans")){
						planHtml = U.getHTML(navUrl);	
					}
					if(navUrl.contains("/homes"))
						quickHtml = U.getHTML(navUrl);
					
				}
			}
			String quickSection = "";
			String quickString = ALLOW_BLANK;
			if (comHtml.contains(">Quick Move-In Homes</a>")) {
				String _quickHtml= getHTML(comUrl + "/homes");
				
				String[] qUrls = U.getValues(_quickHtml, "<a class=\"HomeCard_detailButton\" href=\"", "\"");
				int homesCount = 0;
				
				for(String home : qUrls) {
					try {
						U.log("home: "+home);
						
						String quickhtml=U.getHTML("https://www.goodallhomes.com"+home);
						
						if(!(quickhtml.contains(">Completion Date"))) {
							homesCount++;
						}
						if((quickhtml.contains("Mid October"))) {
							homesCount++;
						}
						
						quickSection += U.getSectionValue(quickhtml, "Property Details</h4>", "Download PDF")
								+U.getSectionValue(quickhtml, "<p class=\"HomeAbout_body\"", "class=\"HomeAbout");
					}catch (Exception e) {
						// TODO: handle exception
					}
					 
					
				}
				
				U.log("homesCount: "+homesCount);
				
				quickHtml = U.removeSectionValue(quickHtml, "<script>window.__PRELOADED_STATE__", "</html");
				quickHtml = U.getSectionValue(quickHtml, "<div class=\"Breadcrumbs_wrapper Goodall_container\" ", ">Learn More</span>");
				_quickHtml = U.removeComments(_quickHtml);
				_quickHtml = _quickHtml.replaceAll("<!----><!---->", "");
				String quickCount =U.getSectionValue(_quickHtml, "<span class=\"ShowingNeighborhoods\" data", "</span>");
				U.log("quickHtml:::::::::"
						+ U.getSectionValue(_quickHtml, "<span class=\"ShowingNeighborhoods\" data", "</span>"));
				//if ( !quickCount.contains("Showing 0 of 0 Quick")&& !quickHtml.contains("Showing 0 of 0 Quick"))
					
				if (homesCount > 0) quickString = "Quick Move-in Homes";
				

			}
			String jsonSec= U.getSectionValue(comHtml, "</script><script data-react-helmet=\"true\" type=\"application/ld+json\">", "</script>");
			U.log(jsonSec+"::::::::json");
			String desc = U.getSectionValue(comHtml, "description\":\"", "<body>");
			// ------ Remove Section---------
			String section = U.getSectionValue(comHtml, "<div id=\"overview", "<h3 class=\"Interested_title");
			if(section != null)
				comHtml = section;
/*			String rem = U.getSectionValue(comHtml, "<html", "<body>");
			if(rem != null )
*/
			
			comHtml = U.removeSectionValue(comHtml, "Nearby Neighborhoods</span></h3>",	"<h3 class=\"LatestWidget_title");
			
			comHtml = U.removeComments(comHtml);
			String[] remVals = U.getValues(comHtml, "<style data-emotion-", "</style>");
			for(String remVal : remVals) comHtml = comHtml.replace(remVal, "");

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addressSec = U.getSectionValue(comHtml, "Sales Center</span>", "</h4></div>");
			if (addressSec != null) {
//				addressSec = U.getNoHtml(addressSec);
				addressSec = addressSec.replace("</h4>", ",").replace("<!---->", " ")
						.replaceAll("<.*?>", "");
				U.log(addressSec);
				// addressSec = U.formatAddress(addressSec);
				addressSec = addressSec.replace("Blvd E Oak Ridge", "Blvd E, Oak Ridge")
						.replace("Rd. Maryville", "Rd, Maryville").replace("Pike Mt Juliet", "Pike, Mt Juliet")
						.replace(",,", ",");
				U.log("addressSec :  " + addressSec);
				add = U.getAddress(addressSec.replace(",.,", ","));
//				add[0]=add[0].replace("Kennedy Lane, Franklin KY 42134", "Kennedy Lane");
			}
			U.log(Arrays.toString(add));
			String latLngSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/", "/@");
			if (latLngSec != null) {
				latLng = latLngSec.split(",");
			}

			U.log(Arrays.toString(latLng));

			if (planHtml == null)
				planHtml = "";
			String planHtml1 = ALLOW_BLANK;
			String[] pUrls = U.getValues(planHtml, "<a class=\"PlanCard_mediaLink\" href=\"", "\"");
			
			for(String plan : pUrls)
				try {U.log("plan: "+plan);
				String planData=U.getHTML("https://www.goodallhomes.com"+plan);
				planHtml1 += U.getSectionValue(planData, "Features</span></h3>", "</ul>")+
						U.getSectionValue(planData, "Plan Type</b>", "</div>")+
						U.getSectionValue(planData, "<ul class=\"PhotoList_list", "</div></div></div></div></div></div></div></div></div></div>");
				} catch (Exception e) {
					// TODO: handle exception
				}
			
//			planHtml = U.getHTML(comUrl + "/plans");	
			planHtml = U.getSectionValue(planHtml, "<div class=\"PlanCard_media", "<style data-emotion");
			if (planHtml != null) {
				planHtml = U.getNoHtml(planHtml);
			}else {
				planHtml="";
			}
			
			
			
			if (quickHtml == null)quickHtml = "";
			
			String quickSections[] = U.getValues(quickHtml, "<div class=\"HomeCard_address\"", "</div></div></div></div>");
			for(String sec : quickSections)
				quickSection += sec;
			
			if (quickSection != null) {
				quickSection = U.getNoHtml(quickSection);
			}
			
			
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String minSQFT = ALLOW_BLANK, maxSQFT = ALLOW_BLANK;

			comHtml = comHtml.replace("From the mid-300s", "mid $300,000").replaceAll("0s|0’s|0&#x27;s", "0,000");
			if(desc != null) desc = desc.replaceAll("0s|0’s|0&#x27;s", "0,000");
			if(discover==null) discover = "";
			discover = discover.replace("0s", "0,000");
			//U.log("MMMMMMM "+Util.matchAll(discover+comHtml + comSec +planHtml+quickSection+ desc , "[\\s\\w\\W]{30}\\$491[\\s\\w\\W]{30}", 0));
String  price = U.getSectionValue(comHtml, "Price Range<", "class=\"CommunityDetails_iconsItem\"");

			String prices[] = U.getPrices(discover+comHtml + comSec +planHtml+quickSection+ desc + price , "starting from \\$\\d{3},\\d{3}|to \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|\\$(\\d,)?\\d{3},\\d+", 0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log(minPrice + "\t" + maxPrice);
			
			comHtml = comHtml.replaceAll("<!--(.*?)-->", "");
			
			String[] sqft = U.getSqareFeet(discover+comHtml + comSec+planHtml+quickSection + desc,
					"\\d,\\d{3}   SQ FT|\\d,\\d{3} to \\d{4} square feet |range from \\d,\\d{3} to more than \\d,\\d{3} square feet|range from \\d{4} to \\d{4} square feet|range from \\d,\\d{3} square feet to more than \\d,\\d{3}|plan gives you \\d,\\d{3} square feet|\\d,\\d{3} square feet to more than \\d,\\d{3}|SQ FT Range</b>(\\d,)?\\d{3} to( \\d,\\d{3}</span>)?|<!---->\\d,\\d+-\\d,\\d+<!---->|\\d,\\d{3} square feet to \\d,\\d{3} square feet|\\d,\\d+ to \\d,\\d+ square feet|SQ FT Range\\s*\\d,\\d+\\s*to\\s*\\d,\\d+|\\d{4}-\\d{4}\\s+SQ FT| \\d,\\d{3} square feet",
					0);
			minSQFT = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSQFT = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log(minSQFT + "\t" + maxSQFT);
			//U.log("MMMMMMM "+Util.matchAll(discover+comHtml + comSec+planHtml+quickSection + desc , "[\\s\\w\\W]{30}2,941[\\s\\w\\W]{30}", 0));
			// ----------------------
			String rmsec = U.getSectionValue(comHtml, "<h3 class=\"Interested_title\" ", "</html");
			if(rmsec != null)
				comHtml = comHtml.replace(rmsec, "");
			comHtml = comHtml.replaceAll(
					"disc golf|GatedResidence|Elongated|Irrigated|HOA Info|Afsgdsg|Goodall Homes has been building new single family homes, townhomes, condominiums, courtyard cottages, and villas since 1983",
					"");
			// U.log(comHtml);

			String comType = ALLOW_BLANK, propType = ALLOW_BLANK, dType = ALLOW_BLANK, status = ALLOW_BLANK;
			comType = U.getCommunityType((discover+comHtml + comSec).replaceAll(", disc golf, bocce", ""));
			U.log(comType);
//			U.log(comHtml);
			comSec = comSec.replace("><!---->Villas<!---->", "The Villas");
			String dis = U.getSectionValue(discover, "description", "\"/>");
			comHtml = comHtml.replaceAll("type=\"application/ld+json\">(.*)?</script>", "")
					.replace("New Phase, Now Open", "New Phase Now Open").replace("carriage collection", "carriage homes collection")
					.replaceAll("Homestead, a Craftsman|attention to detail, quality craftsmanship", "Craftsman style details").replace(", or loft with ", " a loft").replaceAll(" Craftsman</div>|House Lane|traditional dining| Traditional</div>", "");
//			U.log("MMMMMMM "+Util.matchAll(planHtml1 + quickSection + dis+comHtml + comSec+descsec, "[\\s\\w\\W]{30}single family[\\s\\w\\W]{30}", 0));

			quickSection=quickSection.replace("Also includes a covered patio", "Also includes a rear covered patio").replace("The Wilburn      Stories  2", "The Wilburn two-story");
			
			//planHtml1 + quickSection + dis+comHtml + comSec+descsec
			
			propType = U.getPropType((planHtml1+comHtml+quickSection)
					.replaceAll("craftsmanship|Carriage Style Garage Door|Luxury Vinyl Tile|Carriage Lights", ""));

			U.log("propType: "+propType);
//			U.log("MMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{60}Common area[\\s\\w\\W]{60}", 0));
			
			comHtml = comHtml.replaceAll("Stories</b><!---->", "Stories ").replaceAll("Stories <!-- /react-text --><b data-reactid=\"\\d+\">1.5", "1.5 Story</li>");
			comHtml = comHtml.replaceAll(">Stories 1-2", "Stories 1 , Stories 2 ");

			

			if(discover==null)discover="";
			
//			U.log("MMMMMMM "+Util.matchAll(quickSection, "[\\s\\w\\W]{100}Stories[\\s\\w\\W]{100}", 0));

			
			discover = discover.replace("one and two-story", "1 Story 2 Story");
			comHtml = comHtml.replaceAll("Stories</b>1-1.5", "1 story, and 1.5 story")
					.replaceAll("Stories</b><!-- react-text: \\d+ -->1.5", "1.5 story")
					.replace("one and two-story", "1 Story 2 Story").replaceAll("Stories</b>(\\d)</span>", " $1 Story </span>")
					.replaceAll("Stories</b>(\\d)\\s?-\\s?(\\d)</span>", " $1 Story, $2 Story </span>");
//			U.log(planHtml);
			planHtml = planHtml.replaceAll(" Stories\\s+(\\d)\\s+View Details", " $1 Stories  View Details  ");
			if(quickSection!=null)
				quickSection = quickSection.replaceAll("Stories</b><!-- react-text: \\d+ -->", "Story").replace("Stories  1", "Stories 1");
			dType = U.getdCommType((quickSection + discover + comHtml + comSec + planHtml.replaceAll(" Stories   1.5", "1.5 Story</li>")).replaceAll("Colonial Baseboard|Colonial\"|floor|Floor|FLOOR", ""));
			U.log("dType: "+dType);

			
			comHtml = comHtml.replaceAll("The current phase at Summerlin is almost sold out|current phase is sold out",
					"current phase almost sold out")
					.replaceAll("data-reactid=\"\\d+\">New Phase Now Open", "");
			if(jsonSec!=null)jsonSec=jsonSec.replaceAll("The current phase at Summerlin is almost sold out|current phase is sold out",
					"current phase almost sold out");
			
			comSec = comSec.replaceAll("CommunityCard_overlay false\" data-reactid=\"\\d+\">Coming Soon", "");
			comHtml = comHtml.replaceAll("My Home Canvas Customer Portal (COMING SOON)", "My Home Canvas Customer Portal")
					.replace("current phase at Summerlin is almost sold out", "current phase almost sold out")
					.replaceAll("\">Coming Soon</span>|\">Pricing Coming Soon</span>|overlayAlt NowSelling\"|\">Now Selling</span>|The final phase backs up to trees|Coming Soon!</li><li>Select from| data-reactid=\"403\">Coming Soon!</span>|sites and move-in ready homes now available. Contact us|quick_move_in|Future Quick Move-In|Quick Move-In</li>|Community Playground \\(coming soon\\)|selection of available quick move-in homes|Icon Quick Move-In|Quick Move-In<!---->|Photos for Quick Move-In Homes may|Photos for Quick Move-In Homes|Quick Move-In Homes</a>|Playground Coming",
					"");
			
			if(jsonSec!=null)jsonSec=jsonSec.replaceAll("including a pool and clubhouse (coming soon)", "");
//			U.writeMyText(comHtml + comSec + quickString);
			U.log("quickString: "+quickString);
//			jsonSec = jsonSec.replace("We have a few homesites and move-in ready homes now available","We have a few homesites remaining and move-in ready homes now available");
			status = U.getPropStatus((comHtml + comSec + quickString +jsonSec)
					.replace("current phase at Summerlin is almost sold out", "current phase almost sold out")
					.replaceAll("only a few homesites remaining|Pricing Coming Soon|(coming soon)|Plat Maps may not reflect a Community’s Limited Availability status|(COMING SOON)|data-reactid=\"560\">Pricing Coming Soon</span><div class=|NowSelling\" data-reactid=\"474\">Now Selling</span></div></a><div class|</span> Quick Move-In Home</li>|reflect a Community’s Limited Availability|line lots are available|residences are filling up quickly!|Quick Move In Homes...No Need|selection of available quick move-in homes|We have a few homesites and move-in ready homes now availabl|Limited Time Offer\\. Ask Us|index=\"\\d+\" data-reactid=\"\\d+\">Coming", ""));
			

			U.log(status);
			
			status=status.replace("Quick Move-in Homes", "Quick Move-In")
					.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			
			if(comUrl.contains("https://www.goodallhomes.com/communities/nashville-area/gallatin-tn/the-villas-at-foxland-crossing")) status =status.replace(", Quick Move-in", "");

			if (comName.endsWith("Villas"))
				comName = comName.replace("Villas", "").replaceAll("Cottages$", "");
			
			comName = comName.replace("Villas", "").replaceAll("Cottages$", "");
			
			if(status.contains("Limited Availability") && status.contains(", Limited Homesite"))
				status = status.replace(", Limited Homesite", "");

//			U.log("MMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Presale[\\s\\w\\W]{30}", 0));
		//	if(comUrl.contains("/lebanon-tn/stonebridge-villas"))status=status+", Only A Few Homesites Remain";

			
//			==========================================================================
			
			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
			String lot_Sec=U.getSectionValue(comHtml, "<svg version=", "</svg>");
			if(lot_Sec!=null) {
				lot_data=U.getValues(lot_Sec, "<g class=\"", "</g>");
				if(lot_data.length>0) {
				lotCount=Integer.toString(lot_data.length);
				 U.log("lotCount2=="+lotCount);
				}
			}
			
			
			
			
			
			
			
			// ...................adding in csv...............................
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].replace("Kennedy Lane, Franklin KY 42134", "Kennedy Lane").replace(",", ""), add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSQFT, maxSQFT);
			data.addNotes(U.getnote(comHtml.replaceAll("built_presale|Built Presale","")));
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
		}

		j++;
//		}catch(Exception e) {}
	}

	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode = U.CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);
		// if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("181.215.130.32", 3128));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			Thread.sleep(3000);
			urlConnection.addRequestProperty("User-Agent",
					"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);

			// ---remove script--------
			html = U.removeSectionValue(html, "<script>window.__PRELOADED_STATE", "</script></body>");

			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: " + e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}

}