package com.shatam.b_121_140;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.AddSelection;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTheOlsonCo extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	String[] adds;
	static int j=0;
	CommunityLogger LOGGER;
	public static WebDriver drvr= null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractTheOlsonCo();
	//	U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Olson Company.csv", a.data().printAll());

	}

	public ExtractTheOlsonCo() throws Exception {
		super("Olson Company", "https://www.olsonhomes.com/");
		LOGGER =new CommunityLogger("Olson Company");
	}

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		drvr = new FirefoxDriver();
		
		// https://www.olsonhomes.com/includes/js-communities.js
		String url = "https://www.olsonhomes.com/communities/";
		String html = "";
		html = U.getHTML(url);
		//U.log("+++++++++++++**********++++++++++++" + html);
		String sec[] = U.getValues(html, "<div class='community-inner'>", "</div></div></div></div>");
		U.log("Number Of Communities: "+sec.length);
		
		for (String commInfo : sec) {
				
				if (commInfo.contains("sausalitowalk")	|| commInfo.contains("Mariposa Walk"))
					continue;
				// if(i<2)
				String comUrl = U.getSectionValue(commInfo, "href='", "'");
				String commName = U.getSectionValue(commInfo, "community-title'>", "<");

				// if(inr==0||inr==totalComm||inr==totalComm+1||inr==sec.length-1)
//				try {
					addDetails(comUrl, commName, commInfo);
//				} catch (Exception e) {}
				
				// inr++;
				// i++;
			}

		/*String pageHtml = U.getHTML("https://www.olsonhomes.com/");
		
		String links[] = U.getValues(pageHtml, ".locations.push({", "});");
		
		for (String i : links) {
		//	U.log("****" + i);
			String urll = U.getSectionValue(i, "web:\"", "\"");
			String name = U.getSectionValue(i, "title:\"", "\"");
			addDetails(urll, name, i);
		}*/
		LOGGER.DisposeLogger();
		try{drvr.quit();}catch(Exception e) {}

	}

	private void addDetails(String comUrl, String commName, String commInfo)	throws Exception {
		//if(j==2)
//		try{
		{
	
			//TODO:
		if(comUrl==null || comUrl.length()<4)return;
		//============ Single Runb =================
		
//	if(!comUrl.contains("https://www.olsonhomes.com/community/vista-walk-la-habra/")) return;
	
		
		U.log("\nCount :"+ j+"\n");
//		 U.log("CO:::"+commInfo);
		U.log("Page :- " + comUrl);
		U.log("Community Name: "+commName);
		//U.log(U.getCache(comUrl));

		if(comUrl.contains("www.oakwalkhomes.com"))comUrl="https://www.oakwalkhomes.com";
		String html = U.getHTML(comUrl);
		U.log(U.getCache(comUrl));
		
	//	U.log("KKKK"+html.contains("Pre-sales begin in May"));
		String ownHtmlurl=ALLOW_BLANK;
		ownHtmlurl = U.getSectionValue(html, "<div class=\"elementor-shortcode\"><a href=\"", "\"");
		if(ownHtmlurl==null || ownHtmlurl.contains("www.tapestrywalk.com"))ownHtmlurl=comUrl;
		
		U.log("ownHtmlurl --->"+ownHtmlurl);
		String ownHtml= U.getHTML(ownHtmlurl);	
		// lat long
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = "False";
		
			String lati = Util.match(html, "lat:\\s*(\\d+.\\d+)", 1);
			String longi = Util.match(html, "lng:\\s*(-\\d+.\\d+)", 1);
			if (lati != null) {
				lat = lati;
				lng = longi;
				geo = "FALSE";
			}
			 U.log("GEOCODE: lat"+lat+" lng"+lng);
			U.log(!comUrl.contains("/community/blvd-walk-montebello/") && ownHtml.contains("Location"));
		if(!comUrl.contains("/community/blvd-walk-montebello/") && ownHtml.contains("Location")) {
	//	String ownContactUrl = U.getHtml(ownHtmlurl+"/contact-us/?loc=directions",drvr);
			U.log("qwm dhrt "+ownHtmlurl);
		String ownContactUrl = U.getHtml(ownHtmlurl+"contact/",drvr);
		if(lati==null || lati.length()<2 ||lat.length()<2) {
			U.log("hellpo");
			String latsec= U.getSectionValue(ownContactUrl, "href=\"https://maps.google.com/maps?ll=", "&amp;");
			U.log("latsec: "+latsec);
			
			if(latsec != null) {
			String latlng[]= latsec.split(",");
			lat = latlng[0];
			lng=latlng[1];
			geo = "FALSE";
			}
			
		}
			
		//	String addSec=U.getSectionValue(html, "<span class=\"community-address\">","</span>");
			
	}
		U.log(html.contains("https://www.google.com/maps/embed"));
		if(html.contains("https://www.google.com/maps/embed")) {
			String latLngSec = U.getSectionValue(html, "<iframe src=", "width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>");
			if(latLngSec==null)
			 latLngSec = U.getSectionValue(html, "<iframe src=\"", "width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"");
			if(latLngSec==null)
				latLngSec = U.getSectionValue(html, "<iframe src=\"", "width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>");	
			U.log(latLngSec);
			if (latLngSec != null) {
				U.log("INSIDE LNG sEC");
				lng = U.getSectionValue(latLngSec, "!2d", "!");
				lat = U.getSectionValue(latLngSec, "3d", "!");
			}
		}
		// August Code
		if(html.contains("gmap_canvas")) {
			String iframeUrl=U.getSectionValue(html, "iframe width=\"600\" height=\"500\" id=\"gmap_canvas\" src=\"", "\"");
		    String iframeHtml=U.getHTML(iframeUrl);
		    U.log("i frame Path: "+U.getCache(iframeUrl));
		    String latLngSec=U.getSectionValue(iframeHtml, "https://maps.google.com/maps/api/staticmap?", "zoom=");
		    lat=U.getSectionValue(latLngSec, "center=", "%2C");
		    lng=U.getSectionValue(latLngSec, "%2C", "&amp;");
		    U.log("August ltlng: "+lat+" "+lng);
		}
		
//		Comm Name
		U.log("cominfo:::"+commInfo);
	
			//
			U.log("lat"+lat+" lng::"+lng);
			// address
			String[] latlng = { lat, lng };
			
			String addSec = U.getSectionValue(html, "\"community-address\">", "<");
			
			if(addSec == null) {
				add = U.getAddress(addSec);
				if(add[0]==null || add[0]==ALLOW_BLANK)
					addSec = U.getSectionValue(html, "Corporate Office<br />", "</strong><br /><a");
				U.log("Corporate Add :"+addSec);
			}
			
			if(addSec != null) {
				addSec = addSec.replace("8375 Talbert Avenue, Huntington Beach, CA, CA 92646", "8375 Talbert Avenue, Huntington Beach, CA 92646");
			}
			
			U.log("addSec ===== "+addSec);
			addSec.replace("<br /></strong><strong>", ",").replace("</strong><br /><strong>", "");
			
			
			add = U.getAddress(addSec);
			
			U.log("My Address::"+Arrays.toString(add)+"ZIP::"+add[3].length());
		
		String blogHtml = "";
		
     
		if(add[0]==null || add[0]==ALLOW_BLANK) {
			addSec = U.getSectionValue(html, "<iframe frameborder=\"0\"", "</iframe>");
			if(addSec == null) {
				addSec = U.getSectionValue(html, "title=\"", "\"");
				add = U.getAddress(addSec);
			}
			
			
		}
		
		
		if(lat == null || lat == ALLOW_BLANK) {
			
			if(comUrl.contains("https://www.olsonhomes.com/community/flora-walk-torrance/")) {
				
				add[1] = "Torrance";
				add[2] = "CA";
			}
			
			if(comUrl.contains("https://www.olsonhomes.com/community/westside-walk-costa-mesa/")) {
				add[1] = "Costa Mesa";
				add[2] = "CA";
				add[3] = "92626";
			}
			
			
			if(comUrl.contains("/community/laurel-walk/")) {
				
				//getting address from inner page.
				String adHtml = U.getHTML("https://www.laurelwalkhomes.com/contact/");
				String section = U.getSectionValue(adHtml, "<div class=\"elementor-custom-embed\">", "</iframe>");
				U.log("section: "+section);
				
				if(section != null) {
					String linkForAddress = U.getSectionValue(section, "src=\"", "\"");
					U.log("linkForAddress: "+linkForAddress);
					
					String addressData = U.getHTML(linkForAddress);
					U.log(U.getCache(linkForAddress));
					
					String addSection = Util.match(addressData, "[\\w\\W\\s]{100}https://www.google.com/maps/preview/[\\w\\W\\s]{100}");
					U.log("addSection: "+addSection);
					
					//ADDRESS
					String addrSec = U.getSectionValue(section, "aria-label=\"", "\"");
					U.log("addrSec: "+addrSec);
					add = U.getAddress(addrSec);
					
					U.log("ADDRESS ==== : "+Arrays.toString(add));
					
					//GEOCODES
					String geoSec = U.getSectionValue(addSection, "/@", "data").replace(",3311a,13.1y/", "");
					U.log("geoSec: "+geoSec);
					
					String[] addSplit = geoSec.split(",");
					lat = addSplit[0];
					lng = addSplit[1];
					
					 U.log("GEOCODE HERE ==== : lat"+lat+" lng"+lng);
				}
			}
				
			
			if(addSec != null && !comUrl.contains("/community/laurel-walk/")) {
				
				U.log("In Block 1");
				
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				lat = latlng[0];
				lng = latlng[1];
				geo = "TRUE";
				U.log("lat"+lat+" lng::"+lng);
			}
			if(add[0] == null || add[0] == ALLOW_BLANK) {
				
				U.log("In Block 2");
				
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo = "TRUE";
				U.log("Address : "+add);
			}
		}
		if(add[0] == null || add[0] == ALLOW_BLANK) {
			
			U.log("In Block 3");
			
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			geo = "TRUE";
			U.log("Address : "+add);
		}
		
		
		
		//----------------------------ComSite
		String comSiteHtml = "";
		String comFloorHtml = "";
		String comDetailsHtml = "";
		
		String comSiteUrl = U.getSectionValue(html, "div class=\"elementor-shortcode\"><a href=\"", "\"");
		U.log("comSiteUrl==  "+comSiteUrl);
		if(comSiteUrl!= null && !comSiteUrl.contains("tapestrywalk")) {
			comSiteHtml = U.getHTML(comSiteUrl);
			U.log(U.getCache(comSiteUrl));
		
			if(comSiteHtml.contains("/floor-plans/")) {
				comFloorHtml = U.getHTML(comSiteUrl+"floor-plans/");
				U.log(U.getCache(comSiteUrl+"floor-plans/"));
			}
			
		
			else if(comSiteHtml.contains("/homes/")) {
				comFloorHtml=U.getHTML(comSiteUrl+"homes/");
				U.log("ll"+comSiteUrl+"homes/");
				U.log(U.getCache(comSiteUrl+"homes/"));
			}
				
		//	U.log("MATCHING"+Util.matchAll(comFloorHtml, "[\\w\\W\\s]{50}585,990[\\w\\W\\s]{50}",0));
			U.log(comSiteUrl+"/floor-plans/");
			U.log(comSiteUrl+"/homes/");
			
		}
		U.log("MTY HU"+Util.match(comSiteHtml,"585,990"));
		if(comUrl.contains("/expo-walk-leimert-park/"))comFloorHtml=U.getHTML("https://www.expowalk.com/homes/");

		if(comUrl.contains("/community/blvd-walk-montebello/"))comFloorHtml=U.getHTML("https://www.blvdwalk.com/homes/");
		//String navSec = U.getSectionValue(comSiteHtml, "<ul id=\"main-nav", "</ul>");
		
		
//		comFloorHtml=comFloorHtml.replaceAll("'residence-price'>\\$\\d{3},\\d{3}</div>", "");
		//comSiteHtml=comSiteHtml.replaceAll("'residence-price'>\\$\\d{3},\\d{3}</div>", "");
		
		//U.log("blog is : " + );
		if(html.contains("<a href=\"/blog/"))
		{
			blogHtml = U.getHTML(comUrl+"/blog")+U.getHTML(comUrl+"/features/");
		}
		if (comUrl.contains("https://ventanawalk.com/")) {
			blogHtml=blogHtml+U.getHTML("https://www.ventanawalk.com/floor-plans/");
		}
		if(comUrl.contains("https://www.magnoliawalkhomes.com") || comUrl.contains("https://www.metrowalkhomes.com") || comUrl.contains("https://ventanawalk.com/")){
			blogHtml += U.getHTML(comUrl+"/details/");
		}
		if(comUrl.contains("districtwalk"))blogHtml+=U.getHTML("https://www.districtwalk.com/availability/");
		// Price
		
//		if(comFloorHtml!=null)
//			comFloorHtml = comFloorHtml.replaceAll("<div class=\"residence-availability\">Sold</div>.*</div><div class='residence-price'>\\$\\d+,\\d+</div>", "");
//		
		html = html.replace("0s", "0,000")
				.replaceAll("income homes will be up to \\$\\d+,\\d+", "");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		// + comFloorHtml
//		U.log("MATCHING"+Util.matchAll(comFloorHtml, "[\\w\\W\\s]{50}585,990[\\w\\W\\s]{50}",0));
		String[] price = U.getPrices(blogHtml+html+comSiteHtml,
				"\\$\\d{3},\\d{3}|residence-price'>\\$\\d{3},\\d{3}|\\$\\d{3},\\d+|mid \\d{3},\\d{3}", 0);
		 
//		U.log("MMMMMMMMMMMMM "+Util.matchAll(comSiteHtml, "[\\s\\w\\W]{30}639,990[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMM "+Util.matchAll(blogHtml, "[\\s\\w\\W]{30}639,990[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMM "+Util.matchAll(comFloorHtml, "[\\s\\w\\W]{30}639,990[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}639,990[\\s\\w\\W]{30}", 0));
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		 U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		 
		 
		 
		// square feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String floorHtm = "";
		String flLink = Util.match(html, "<a href=\".*?>Floor Plans</a></li>");
		if(flLink==null)
			flLink = Util.match(html, "<a href=\".*?>Floor<br />Plans</a></li>");
		 U.log(":: f"+flLink);
		if (flLink != null) {
			
			flLink = U.getSectionValue(flLink, "href=\"", "\"");
			if(!flLink.contains("http") )
				flLink = comUrl +  flLink ;
			
			U.log(flLink);
			String flHtm = U.getHTML(flLink);
			floorHtm = flHtm;
			
			flHtm = U.getHtmlSection(flHtm, "<li class=\"fpTitle\">", "</ul>");
			if(flHtm!=null)
			{
			String links[] = U.getValues(flHtm, "<a href=\"", "\"");
			for (String item : links) {
				U.log(comUrl + item);
				floorHtm += U.getHTML(comUrl + item);
			}
		}
		}
		html = html.replace(" &#8211; ", "-");
		floorHtm=floorHtm.replace("2,019 sq. ft. home for sale in Monterey Park", "\"/>");
		//U.log(floorHtm);
		String[] sqft = U
				.getSqareFeet(
						(floorHtm + html+blogHtml +comFloorHtml+comSiteHtml).replace("residence-footage'>1,504 sq. ft.</div>", "")
						.replace("<p><br />1,246-1,803<br />Up to 4 beds/4 baths<br /></p>", "<p><br />1,246-1,803 Sqft<br />Up to 4 beds/4 baths<br /></p>"),
						
						"\\d,\\d{3}-\\d,\\d{3} Sqft|\\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft.|\\d,\\d{3} to \\d,\\d{3} sq. ft.|\\d,\\d{3} � \\d,\\d{3} sq. ft.|[0-9]{3},[0-9]{3}–[0-9]{1},[0-9]{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|\\d+,\\d+-\\d+,\\d+ s.f.|[0-9]{1},[0-9]{3} sq. ft|Approx \\d{4} Sq. Ft.",
						0);
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		 U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//	 U.log("MMMMMMMMMMMMM "+Util.matchAll(floorHtm + html+blogHtml +comFloorHtml+comSiteHtml, "[\\s\\w\\W]{100}779,990[\\s\\w\\W]{100}", 0));
//	 U.log("MMMMMMMMMMMMM "+Util.matchAll(floorHtm + html+blogHtml +comFloorHtml+comSiteHtml, "[\\s\\w\\W]{100}1,246[\\s\\w\\W]{100}", 0));
//	 U.log("MMMMMMMMMMMMM "+Util.matchAll(floorHtm + html+blogHtml +comFloorHtml+comSiteHtml, "[\\s\\w\\W]{100}1,863[\\s\\w\\W]{100}", 0));
//	 U.log("MMMMMMMMMMMMM "+Util.matchAll(floorHtm + html+blogHtml +comFloorHtml+comSiteHtml, "[\\s\\w\\W]{100}1,299[\\s\\w\\W]{100}", 0));
		// property type
		blogHtml=blogHtml.replace("plan-7R-patio", "");
		
		html=html.replaceAll("and HOA are not included|custom-html|custom_html|cSummerustomset|custom menu|custom-logo|top customer experience awards|custom-css\">", "");
		
//		 U.log("MMMMMMMMMMMMM "+Util.matchAll( commInfo +floorHtm+ html+blogHtml +comFloorHtml+comSiteHtml, "[\\s\\w\\W]{30}townhomes[\\s\\w\\W]{30}", 0));
		
		String pType = U.getPropType((commInfo +floorHtm+ html+blogHtml +comFloorHtml+comSiteHtml).replace("Loft/Opt. Bed","with Loft ")
				.replaceAll("azalea-walk-new-townhomes-in-gardena|and HOA are not included|custom-logo|custom-html|custom menu|custom_html|custom-css|allow_custom_scripts|custom-pro|custom-frontend|Olson has built more than 11,000 single-family attached, single-family detached|village|Village|bedroom single family|porches, patios", ""));

		U.log("pType : "+pType);
		
		
		// status
		html=U.removeComments(html);
		if(comSiteHtml!=null)
		comSiteHtml = comSiteHtml.replace("Grand Opening<br>March 2022", "Grand Opening March 2022")
			.replaceAll("size-default\">Lumina Walk is currently Sold|size-default\">Final phase now selling", "");
		
		html=html.replace("Grand Opening<br>March 2022", "Grand Opening March 2022")
				.replaceAll("grand openings and homebuyer|Welcome Center Now Open|New Homesite Release Saturday|Models Now Open|Sales Center Coming Fall 2016", "");
		String status = ALLOW_BLANK;
		status = U.getSectionValue(commInfo, "saleStatus:\"", ",") + html;
		String remove = "Final Opportunities Remain! <i |will be ready for move-in this| Mesa, coming soon|Willowbrook is Selling Fast|District Walk</span><sup>&trade;</sup> Welcome Center Now Open|for other communities now selling|Final home remaining|<h2>Temporarily Sold Out!|last chance-final homes available at |temporarily-sold-out/\">|<h2>New Phase Release at Metro Walk|fntext\">\\s*<h2>new homesite release|fntext\">\\s*<h2>new homesites available|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|sale coming soon|<h2>Last Chance to";
		
		 html= html.toLowerCase().replaceAll(remove.toLowerCase(), "");
		 
//		 U.log("MMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));
//		 U.log("MMMMMMMMMMMMM "+Util.matchAll(commInfo, "[\\s\\w\\W]{30}final phase[\\s\\w\\W]{30}", 0));
//		 U.log("MMMMMMMMMMMMM "+Util.matchAll(comSiteHtml, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));

		 status = U.getPropStatus((html+commInfo+comSiteHtml).replace("snipe'>Now Selling</div>", " Now Selling ")
				 .replace("new homes in la habra coming soon", "new homes coming soon")
				 .replace("Laurel Walk is currently Sold Out", "")
				 .replaceAll("Grand Opening This Winter. Sign up|Model Grand Opening This Winter|grand openings and more", "")
				 .replaceAll("Get community and grand opening news|grand openings and homebuyer resources|Model Grand Opening in June|and grand opening news delivered|Lumina Walk Grand Opening This Saturday|to attend the Grand Opening of Lumina Walk|Pre-qualifications for Jasmine Walk are now open|residence-availability'>Sold|Rate Homes are Sold|Grand Opening news|will be ready for move-in this|Grand Opening news|grand openings and homebuyer|grand opening news|availability'>Quick Move|New Homesite Release This Saturday| Mesa, coming soon|Welcome Center Now Open|Last Chance to Own at|New Homesite Release Saturday|grand openings and homebuyer||center now open|saleStatus:\"Coming Soon!\"|Center Now Open|WELCOME CENTER NOW OPEN",""));
		
		 status=status.replace("Opening Summer 2022, Grand Opening, Coming Soon", "Grand Opening Opening Summer 2022, Coming Soon");
		 if(status.equals("Coming Soon, Grand Opening, Opening This Winter")) status = "Coming Soon, Grand Opening This Winter";
		 U.log("::::::::>>>>>>>>>>>>>>>>>>>>"+status);
		 
		
		// Notes info variable
		String noteVar = ALLOW_BLANK;
		
//		U.log(Util.match(blogHtml, ".*gated.*"));

		String communityType = U.getCommunityType((html+blogHtml+comSiteHtml).replaceAll("elongated| community-55", ""));
		
		if (comUrl.contains("https://www.rosewalkhomes.com/"))
			status = ALLOW_BLANK;
		
		add[1] = add[1].trim();
		if (add[0].endsWith("."))
			add[0] = add[0].replace(".", "");

		add[1] = add[1].replace("�", " ");
		add[1] = add[1].trim();
		
		add[0] = add[0].replace("   ", "");
		U.log(add[0]);
		String statsec = U.getSectionValue(html,
				"<h2 style=\"text-align: center;\">", "</h2>");
		
	
	//----------------------------------------------
	//below code is to take page street address in case where the main page(baseurl) community address doesn't matches with the address present on community page
	String comAddSec = U.getSectionValue(html, "class=\"footaddress", "</a>");	
	U.log(comAddSec);
	
	
	U.log("city::"+add[1]);
	String streetSec=U.getSectionValue(html, "<p>aldea walk™", add[1].toLowerCase()); //for Aldea Walk
	
	if(streetSec==null && comAddSec!=null){
		streetSec=U.getSectionValue(comAddSec, "proximanova twhite\">", ", "+add[1].toLowerCase()); //for other
		if(add[3].length()<4){
			add[3]=Util.match(comAddSec, ", ca (\\d+)",1);
			if(add[3]!=null)
			add[2]="CA";
			U.log("zip::"+add[3]);
		}
	}
	U.log("streetSec::"+streetSec);
		
	if(streetSec!=null && !streetSec.contains(add[0])){
		add[0]=streetSec;
		U.log("page address::"+add[0]);
	}
	if(streetSec!=null && add[0].isEmpty()){
		add[0]=streetSec;
		U.log("page address::=="+add[0]);
	}
	
	html = html.replace("two- &#038; three-story attached homes", "2 Story and 3 Story attached homes");
	
	String dtype= U.getdCommType((html+blogHtml+comSiteHtml).replaceAll("ranch parkway", ""));
	
	//U.log("MMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));
	//-----------------------------------------------------
		U.log("zip::"+add[3].length()+"*********::::::::::");
	/*if(add[0].length()<4 ||add[3].length()==0 )
	{
		String latlng[] = { lat, lng };
		add=U.getAddressGoogleApi(latlng);
		geo="TRUE";
	}*/
	if(comUrl.contains("https://villagewalkdowney.com/"))minPrice="$639,990";
	if(comUrl.contains("https://www.magnoliawalkhomes.com"))geo = "FALSE";
		blogHtml = blogHtml.replaceAll("Colonial short panel|(f|F)loor", "");
//	if(comUrl.contains("/community/expo-walk-leimert-park/"))status =status+", Quick Move-in";	
	if(comUrl.contains("portola-walk-la-habra"))dtype = dtype+", Ranch";
	commName=commName.replace("&#038;", "&").replace("™", "");
	add[0] = add[0].replace("&#038;", "&");
		/*if (add[1].length() < 2)
			add[1] = ALLOW_BLANK;*/
	//if(comUrl.contains("https://www.olsonhomes.com/community/expo-walk-leimert-park"))geo="FALSE";
//	if(comUrl.contains("https://www.olsonhomes.com/community/lumina-walk/")) status = "Grand Opening Spring 2022, Coming Soon";
		if (this.data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"*********repeated*************");
			return;
		}
		//if(comUrl.contains("https://www.olsonhomes.com/community/twenty8-walk/"))minSqf="1513";
		 status=status.replace("Opening Summer 2022, Grand Opening, Coming Soon", "Grand Opening Opening Summer 2022, Coming Soon");

		if(comUrl.contains("https://www.olsonhomes.com/community/flora-walk-torrance/")) {minPrice =ALLOW_BLANK; maxPrice = ALLOW_BLANK;}
		status = status.replace("Grand Opening Fall 2021, Coming Soon, Grand Opening", "Grand Opening Fall 2021, Coming Soon").replace("Temporarily Sold Out, Sold Out,", "Temporarily Sold Out, ")
				.replace(", Grand Opening Fall 2021, Opening Fall 2021", ", Grand Opening Fall 2021");
		
		noteVar=U.getnote((html+ownHtml).replace("Pre-selling our final phase","Pre-selling final phase"));
	//	U.log("KKKK"+html.contains("Pre-sales begin in May"));
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		
		LOGGER.AddCommunityUrl(comUrl);
		data.addCommunity(commName, comUrl, communityType);

		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dtype);
		data.addPropertyStatus(status);
		data.addNotes(noteVar);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);

		// TODO Auto-generated method stub
		}j++;
//		}catch(Exception e) {}
	}

	
}