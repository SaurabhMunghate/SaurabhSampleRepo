/** @author ashish
 *  @date 4/05/2013 
 */

package com.shatam.b_141_160;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import org.apache.regexp.recompile;

public class ExtractElitePropertiesofAmerica extends AbstractScrapper {
	WebDriver driver = null;
	public int inr = 0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	private String baseUrl = "https://classichomes.com";
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractElitePropertiesofAmerica();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Classic Homes.csv", a.data().printAll());
		U.log(duplicates);

	}

	public ExtractElitePropertiesofAmerica() throws Exception {

		super("Classic Homes", "https://classichomes.com/");
		LOGGER = new CommunityLogger("Classic Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();

		//String html = U.getHTML("https://classichomes.com/neighborhoods/");
		String html = U.getHtml("https://classichomes.com/neighborhoods/", driver);
		String latLngSec = U.getSectionValue(html, "et_pb_module et_pb_map_container_extended", "et_pb_section et_pb_section_2 neighborhood-listing");
		String[] commSections = U.getValues(html, "div class=\"et_pb_map_pin_extended", "</div>");

		//U.log(latLngSec);
//		U.log(commSections.length);
		for(String commSec : commSections){
		//	U.log(">>>>>>>>>"+commSec);
			String commUrl = "";				
			commUrl = U.getSectionValue(commSec, "et_pb_promo_button et_pb_button\" href=\"", "\"");
			
			
			
//			U.log("==="+commUrl);	
			if(commUrl==null)continue;
			if(commUrl.contains("/jacksoncreeknorth/")) commUrl = "/project/jackson-creek-north/";

			
			if(!commUrl.startsWith("http")){
				if(commUrl.startsWith("/"))
					commUrl = baseUrl + commUrl;
				else if(!commUrl.startsWith("/"))
					commUrl = baseUrl +"/"+ commUrl;
			}
		//	U.log("Region Url: "+commUrl);
			String cHtml =  U.getHtml(commUrl, driver);
			//-----code for fetching sub communities-------

			String[] subComUrls= {};
			String comUrl = ALLOW_BLANK;
			if(cHtml.contains("Learn More</a>")) {
				subComUrls= U.getValues(cHtml, "<div class=\"et_pb_text_inner\">", "Learn More</a>");
				for(String subComUrl : subComUrls){
					String surl =  U.getSectionValue(subComUrl, "\" href=\"", "\"");
					if (!surl.contains("https:")) {
						surl = baseUrl+surl;
						}
						
						
//						U.log("subComUrl : "+subComUrl);
//					U.log("commUrl77==="+surl);

						String subComHtml =  U.getHtmlHeadlessFirefox(surl, driver);
						getData(surl,subComHtml,commSec+subComUrl,latLngSec,html);
					}
				inr +=subComUrls.length;
			}
			else if(cHtml.contains(">Explore")){
				 subComUrls= U.getValues(cHtml, "div class=\"et_pb_column et_pb_column_2_3", ">Explore");
				 for(String subComUrl : subComUrls){
					 String surl =  U.getSectionValue(subComUrl, "\" href=\"", "\"");
						if (!surl.contains("https")) {
							surl = baseUrl+surl;
							}
							//U.log("subComUrl : "+subComUrl);
//						U.log("commUrl66==="+surl);

							String subComHtml =  U.getHtmlHeadlessFirefox(surl, driver);
							getData(surl,subComHtml,"",latLngSec,html);//commSec
						}
				 inr +=subComUrls.length;
			}else {
				inr+=1;
//				U.log("commUrl55==="+commUrl);

				getData(commUrl,cHtml,commSec,latLngSec,html);//commSec
			}
		}
		U.log(inr);
		String dropDownData = U.getSectionValue(html, "aria-current=\"page\">Neighborhoods</a>", "Find Your Home</a>");
		String missingComSec[] = U.getValues(dropDownData, " class=\"menu-item menu-item-type-post_type ", "</a></li>");
		U.log(missingComSec.length);
		for(String missingCom :missingComSec) {
			String commUrl = "";				
			commUrl = U.getSectionValue(missingCom, "href=\"", "\"");
			
			
			
//			U.log("==="+commUrl);	
			if(commUrl==null || !commUrl.contains("/project/"))continue;
			if(commUrl.contains("/jacksoncreeknorth/")) commUrl = "/project/jackson-creek-north/";

			
			if(!commUrl.startsWith("http")){
				if(commUrl.startsWith("/"))
					commUrl = baseUrl + commUrl;
				else if(!commUrl.startsWith("/"))
					commUrl = baseUrl +"/"+ commUrl;
			}
			U.log("Region Url: "+commUrl);
			String cHtml =  U.getHtml(commUrl, driver);
//			U.log(cHtml);
			//-----code for fetching sub communities-------

			String[] subComUrls= {};
			String comUrl = ALLOW_BLANK;
			if(cHtml.contains("Learn More</a>")) {
				subComUrls= U.getValues(cHtml, "<div class=\"et_pb_text_inner\">", "Learn More</a>");
				for(String subComUrl : subComUrls){
					String surl =  U.getSectionValue(subComUrl, "\" href=\"", "\"");
					if (!surl.contains("https:")) {
						surl = baseUrl+surl;
						}
						
						
//						U.log("subComUrl : "+subComUrl);
//					U.log("commUrl44==="+surl);

						String subComHtml =  U.getHtmlHeadlessFirefox(surl, driver);
						getData(surl,subComHtml,missingCom,latLngSec,html);
					}
				inr +=subComUrls.length;
			}
			else if(cHtml.contains("View Homes</a>")) {
				subComUrls= U.getValues(cHtml, "<a class=\"et_pb_button ", "<div class=\"et_pb_divider_internal\"></div>");
				for(String subComUrl : subComUrls){
					String surl =  U.getSectionValue(subComUrl, "\" href=\"", "\"");
					if (!surl.contains("https:")) {
						surl = baseUrl+surl;
						}
						
						
//						U.log("subComUrl : "+subComUrl);
//					U.log("commUrl33==="+surl);
						String subComHtml =  U.getHtmlHeadlessFirefox(surl, driver);
					getData(surl,subComHtml,missingCom+subComUrl,latLngSec,html);
					}
				inr +=subComUrls.length;
			}
			else if(cHtml.contains(">Explore")){
				 subComUrls= U.getValues(cHtml, "div class=\"et_pb_column et_pb_column_2_3", ">Explore");
				 for(String subComUrl : subComUrls){
					 String surl =  U.getSectionValue(subComUrl, "\" href=\"", "\"");
						if (!surl.contains("https")) {
							surl = baseUrl+surl;
							}
							//U.log("subComUrl : "+subComUrl);
//						U.log("commUrl22==="+surl);

							String subComHtml =  U.getHtmlHeadlessFirefox(surl, driver);
							getData(surl,subComHtml,"",latLngSec,html);//commSec
						}
				 inr +=subComUrls.length;
			}else {
//				U.log("commUrl1111==="+commUrl);
				inr+=1;
				getData(commUrl,cHtml,missingCom,latLngSec,html);//commSec
			}
			
		}
		LOGGER.DisposeLogger();
		//driver.close();
		//
		//driver.quit();
	}

	//TODO :
	private void getData(String communityUrl,String comHtml, String commSec,String latLngSec,String RegHtml) throws Exception {

		
//		try{
//		if(j > 10)
		
		{
			communityUrl = communityUrl.replace("com//", "com/").replace("http://", "https://").replaceAll("https://classichomes.comhttps://classichomes.com/", "https://classichomes.com/");
//https://classichomes.com/project/sanctuary-pointe-renaissance-collection/
			if(communityUrl.contains("-available-homes") || communityUrl.contains("sanctuary-pointe-renaissance-collection/")) return;
			
			
			//TODO :
//			if(!communityUrl.contains("https://classichomes.com/project/timberridge/")) return;
			
//			U.log("Comm Sec=="+commSec);
			String RegStatus="";
			
			U.log("count::"+j);
			U.log("\ncommunityUrl==="+communityUrl);
//			U.log("commSec:: " + commSec);
			U.log( U.getCache(communityUrl));
			if (data.communityUrlExists(communityUrl) || communityUrl.contains("https://classichomes.com/project/wolf-ranch-paired-patio-homes/")) {
				LOGGER.AddCommunityUrl(communityUrl+ "---------------------------------repeat");
				duplicates++;
				return;
			}
			
			if(communityUrl.contains("https://classichomes.com/project/north-fork-townhome-collection/")) {
				LOGGER.AddCommunityUrl(communityUrl+ "---------------------------------REDIRECTED");
				return;
			}
			
			
			LOGGER.AddCommunityUrl(communityUrl);
			// LOGGER.countOfCommunity(inr);
			//============== Community Name ================
			String communityName=ALLOW_BLANK;
			
			communityName = U.getSectionValue(comHtml, "<h5 class=\"et_pb_toggle_title\">About", "</h5>");
			U.log("communityName===="+communityName);
			
			if(communityName == null)
				communityName = U.getSectionValue(comHtml, "<h1>", "</h1>");
//			if(communityName .contains(""))
//				communityName = U.getSectionValue(comHtml, "<h3>Introducing ", "</h3>");
//			if(communityName == null) 
//				communityName = U.getSectionValue(comHtml, "<title>", "-");
			U.log("CommunityName=2::" + communityName);

//			U.log(communityName);
			if(communityName.contains("Gallery"))
				communityName= U.getSectionValue(comHtml, "<h3>About", "</h3>");

			U.log("CommunityName=1::" + communityName);

			
			
			
			

			  //Updating community Names
					if(communityName != null) {
						communityName = communityName.replace("Available Homes", "");
					U.log("Updated Community Name::"+communityName.length());	
					}
					
					U.log("CommunityName::" + communityName);
					
					
					if(communityName == null || communityName.length()<2) {
						U.log("Updating nane");
						communityName = U.getSectionValue(comHtml, "<div class=\"et_pb_text_inner\"><h3>About", "</h3>");
					}
					
			if(communityName == null || communityName.length()<2)communityName =  U.getSectionValue(commSec, "<h3 style=\"margin-top: 10px;\">", "<");
			String rem = U.getSectionValue(comHtml, "<head>", "</head>");
			if(rem != null) comHtml = comHtml.replace(rem, "");
			
			if(communityUrl.contains("/project/jackson-creek-north")) communityName = "Jackson Creek North";
			if(communityUrl.contains("https://classichomes.com/project/bison-ranch/"))communityName = "Bison Ranch";
			if(communityUrl.contains("/project/banning-lewis-ranch/"))communityName="The Retreat";
			if(communityUrl.contains("https://classichomes.com/project/greenways/"))communityName="Greenways";
			if(communityUrl.contains("pathways-4-square/"))communityName="Pathways";

			//=========== New Address and Latlng ===================
			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String note =ALLOW_BLANK;
			String geo="FALSE" ;
			String RegComSec="";
			String adds[]= {};
			String []latLong= {ALLOW_BLANK,ALLOW_BLANK};
			communityName=communityName.replace("TimberRidge", "Timber Ridge");
			String addHtml = U.getHTML("https://classichomes.com/neighborhoods/");
			String addSection = ALLOW_BLANK;
			String lats[] = U.getValues(addHtml, "<div class=\"et_pb_map_pin_extended\"", "LEARN MORE</a>");

			adds= U.getValues(addHtml, "<div class=\"et_pb_text_inner\"><h3>", "</div>\n" + 
					"			</div>");
			U.log("adds====="+adds.length);
			U.log("adds-----====="+adds.toString());
			
			for(String addsec : adds) {

//				U.log("ADDDDRESSSSS00========"+addsec);
				if(addsec.contains(communityName.toUpperCase().trim()) || addsec.contains(communityUrl)) {
//					U.log("ADDDDRESSSSS00========"+addsec);
					addSection =addsec;
					RegStatus=addsec;
					if(communityUrl.contains("https://classichomes.com/project/forest-lakes/"))
						addsec = U.getSectionValue(addsec, "</strong>", "<br><em>");
					else if(communityUrl.contains("https://classichomes.com/project/sterlingranch/") || communityUrl.contains("https://classichomes.com/project/cottonwood-creek/") ||communityName.contains("Banning Lewis Ranch") || communityUrl.contains("https://classichomes.com/project/renaissance-indigo-ranch/"))
						addsec = U.getSectionValue(addsec, "</h4>", "<br>");
					else if( communityUrl.contains("https://classichomes.com/project/hannah-ridge-classic-collection/") || communityUrl.contains("https://classichomes.com/project/hannah-ridge-midtown/"))
						addsec = U.getSectionValue(addsec, "</h4>\n" + 
								"<p>", "<br>");
					else if(communityUrl.contains("https://classichomes.com/project/jackson-creek-north/") || communityUrl.contains("https://classichomes.com/project/bison-ranch/"))
						addsec = U.getSectionValue(addsec, "</h4>", "<br");
					else if(communityUrl.contains("project/wolf-ranch-single-family-homes/") ||communityUrl.contains("project/wolf-ranch-midtown-collection/") )
						addsec = U.getSectionValue(addsec, "<p>", "</p>");
					else if(communityUrl.contains("https://classichomes.com/project/timberridge/")
							)
						addsec = U.getSectionValue(addsec, "<p>", "<br>");
					else if(communityUrl.contains("https://classichomes.com/project/greenways/"))
						addsec = U.getSectionValue(addsec, "</em><br>", "</p>");
					else if(communityUrl.contains("project/pathways-4-square/"))
						addsec = U.getSectionValue(addsec, "</p>\n" + 
								"<p>", "<br>");
					
					else
						addsec = Util.match(addsec, "</a></h3>\\s*.*\\s*\\d{5}<", 0);
					
//					U.log("ADDDDRESSSSS11"+addsec);
					
					if(addsec!=null) {
					addsec  = U.getNoHtml(addsec);
					
					addsec  =addsec.replaceAll("&nbsp;|&nbsp;", " ");
					
					add = U.getAddress(addsec);
					}
					
				}
				
				if(communityName.contains("The Village of Palermo") || communityUrl.contains("https://classichomes.com/project/village-of-cortona/"))
					if(addsec.contains("FLYING HORSE")) {
						
						addsec = Util.match(addsec, "</a></h3>\\s*.*\\s*\\d{5}<", 0);
						
						U.log(addsec);
						
						if(addsec!=null)
						addsec  = U.getNoHtml(addsec);
						
						addsec  =addsec.replaceAll("", "");
						
						add = U.getAddress(addsec);
						U.log("ADDDDRESSSSS: "+Arrays.toString(add));
					}
					
			}
			
			if(communityUrl.contains("project/pathways-midtown/")
					||communityUrl.contains("project/pathways-4-square/")) {
				String addSec_1=U.getSectionValue(comHtml, "Sales Center</span></h4>", "</p>");
				if(addSec_1!=null) {
					addSec_1=U.getNoHtml(addSec_1).trim();
					U.log("addSec_1: "+addSec_1);
					add = U.getAddress(addSec_1);
				}
			}
			if(communityUrl.contains("project/north-fork-townhome-collection/")) {
				String addSec_1=U.getSectionValue(comHtml, "Model Home Location:", "<h5><a href=");
				if(addSec_1!=null) {
				addSec_1=addSec_1.replaceAll("</strong></h5>\n" + 
						"<h5><strong>", ", ");
					addSec_1=U.getNoHtml(addSec_1).trim();
					U.log("addSec_1: "+addSec_1);
					add = U.getAddress(addSec_1);
				}
			}
			
			
//			}
			U.log("add: "+Arrays.toString(add));
			
			if(add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK) {
				
				String addSec = U.getSectionValue(comHtml, "<div class=\"et_pb_text_inner\"><p>", "</p>");
				addSec = addSec.replace("<br>", ", ");
				U.log("addSec: "+addSec);
				
				add = U.getAddress(addSec);
				U.log("ADDRESS: "+Arrays.toString(add));
			}
			
			communityName=communityName.replace("Timber Ridge", "TimberRidge");
			for(String latsec : lats) {
				
				if(latsec.contains(communityName.trim())) {
					
					lat = U.getSectionValue(latsec, "data-lat=\"", "\"");
					lng = U.getSectionValue(latsec, "data-lng=\"", "\"");
					U.log("MMMMMM "+lat+"\t"+lng);
					 latLong[0]= lat;
					 latLong[1]=lng;
				}
				
				if(communityName.trim().contains("The Village of Palermo") || communityUrl.trim().contains("https://classichomes.com/project/village-of-cortona/"))
					if(latsec.contains("Flying Horse")) {
						lat = U.getSectionValue(latsec, "data-lat=\"", "\"");
						lng = U.getSectionValue(latsec, "data-lng=\"", "\"");
						U.log("MMMMMM "+lat+"\t"+lng);
					}
					
			}
			if(lat ==null || lat == ALLOW_BLANK) {
				lat = U.getSectionValue(comHtml, "data-center-lat=\"", "\"");
				lng = U.getSectionValue(comHtml, "data-center-lng=\"", "\"");
				U.log("MMMMMM "+lat+"\t"+lng);
			}
			if(add[0]==null && comHtml.contains("Model Location</span></h4>")) {
				String addsec = U.getSectionValue(comHtml, "Model Location</span></h4>", "</p>");
				addsec = addsec.replace("<div class=\"et_pb_blurb_description\"><p>", "").replace("<br />", ",");
				add = U.getAddress(addsec);			
			}
			if(add[0]==null && comHtml.contains("<div class=\"infowindow\">") ) {
				String addsec = U.getSectionValue(comHtml, "<div class=\"infowindow\">", "</div>");
				addsec = addsec.replace("<div class=\"et_pb_blurb_description\"><p>", "").replace("<br>", ",");
				U.log("hello::"+addsec);

				add = U.getAddress(addsec);			
			}
			if(communityUrl.contains("/project/village-of-palermo/")) {
				String addsec = U.getSectionValue(comHtml, "<a href=\"webextlink://", "\"");
				U.log("hello::"+addsec);
				add = U.getAddress(addsec);		
			}
		    
			if(communityUrl.contains("https://classichomes.com/project/banning-lewis-ranch/")) {
		    	String addsec = U.getSectionValue(comHtml, "</strong><br>", "</p>")+" END";
		    	U.log("hello--1::"+addsec);
		    	if(addsec!=null) {
		    		addsec = U.getSectionValue(addsec, "<br>", "END");
		    		
		    		addsec = addsec.replace(", 80923<br>", ", ");
		    		U.log("hello--11::"+addsec);
		    		add = U.getAddress(addsec);
		    	}
		    }
			
		    if(add[0] != null) add[0] = add[0].replace("&amp;", "&").replaceAll("&nbsp;|-|Model Location:,", " ");
		    
//		    //============LatLng Section =================
//		    if(communityUrl.contains("project/greenways")) {
//		    	lats = new String[] {"38.88654000917","-104.71112251283"};
//		    	add = U.getAddressGoogleApi(lats);
//		    	lat = lats[0];
//		    	lng = lats[1];
//		    	geo= "True";		    	
//		    }
		    if(lat == ALLOW_BLANK && lng == ALLOW_BLANK){
		    	if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK){
		    		 latLong = U.getlatlongGoogleApi(add);
		    		if(latLong == null) latLong = U.getlatlongHereApi(add);
		    		U.log(Arrays.toString(latLong));
		    		lat = latLong[0];
		    		lng = latLong[1];
		    		geo = "True";
		    	}
		    }else{
		    	U.log("hello i am in else::::::::::::"+add[0]+"::::"+add[3]);
		    	if(add[0].length()<4 ||(add[0] == ALLOW_BLANK  && add[3] == ALLOW_BLANK)){
		    		 latLong [0] =lat;
		    		 latLong[1]=lng;
		    		add = U.getAddressGoogleApi(latLong);
		    		if(add == null) add = U.getGoogleAddressWithKey(latLong);
		    		if(add == null) add = U.getAddressHereApi(latLong);
		    		geo = "True";
		    	}
		    	if(add[2] == null){
		    		//String latLong [] = {lat,lng};
		    		latLong [0] =lat;
		    		latLong[1]=lng;
		    		String[] add1 = U.getAddressGoogleApi(latLong);
		    		if(add1 == null) add1 = U.getGoogleAddressWithKey(latLong);
		    		if(add1 == null) add1 = U.getAddressHereApi(latLong);
		    		add[2] = add1[2];
		    		geo = "True";
		    	}
		    }
		    
//		    	String latlngsec = U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "/data");
//		    	if(latlngsec!=null ) {
//		    		
//		    		String latlng[] = U.getSectionValue(latlngsec, "@", ",1066").split(",");
//		    		
//		    		lat = latlng[0];
//		    		lng = latlng[1];
//		    	}
//		    }
			
			String [] latlng=U.getValues(latLngSec, "<h3 style=\"margin-top:", "data-title=");
			for(String latlngData :latlng) {
				if(latlngData.contains(communityName)) {
					U.log("latlngData=="+latlngData);
				}
			}
	
			
			
//			communityName=U.getSectionValue(comHtml, "<div class=\"et_pb_text_inner\"><h1>", "</h1>");	
//			U.log("communityName======"+communityName);
			
		    //===================== Available Home ===================
		    String combinedAvailableHtml = null;
		    String [] availableUrls = U.getValues(comHtml, "responsiveExpander", "target=");
		    U.log("homedata: "+availableUrls.length);
		    
		    for(String availableUrl : availableUrls){
		    	availableUrl=U.getSectionValue(availableUrl, "href=\"", "\"");
		    //	U.log(">>>"+availableUrl);
		    	if(availableUrl.contains("http")||availableUrl.contains("https") )
		    	{
			    	U.log("availableUrl :"+availableUrl);	
			    	String availHtml =  U.getPageSource(availableUrl);
			    	if(availHtml.contains("2499")) {
			    		U.log("FOUND");
			    	}
			    	combinedAvailableHtml += U.getSectionValue(availHtml, "<table", "</table>");
		    	}
		    }
		    // homedata from page

		     availableUrls = U.getValues(comHtml, "<a class=\"et_pb_button et_pb_promo_button\" href=\"", "\"");
			 U.log("homedata: "+availableUrls.length);
		     for(String availableUrl : availableUrls){
//		    	availableUrl=U.getSectionValue(availableUrl, "href=\"", "\"");
		    	U.log(">>>"+availableUrl);
		    	if(availableUrl.contains("http")||availableUrl.contains("https") )
		    	{
			    	U.log("availableUrl :"+availableUrl);	
			    	String availHtml =  U.getPageSource(availableUrl);
			    	combinedAvailableHtml += U.getSectionValue(availHtml, "<table", "</table>");
		    	}
		    }
//		    U.log(combinedAvailableHtml);
		    String homesdata=ALLOW_BLANK;
//		    String availSec = U.getSectionValue(comHtml, "<h1>Available Homes</h1>", "<h2>MAPS</h2>");
		    if(comHtml.contains("<div class=\"IDX-showcaseContainer\"")) {
		    String [] homesurl = U.getValues(comHtml, "<a href=\"https://classichomes.idxbroker.com", "\"");
		    for(String home : homesurl){
		    	home="https://classichomes.idxbroker.com"+home;
		    	U.log(">>>"+home);
		    	U.log(U.getCache(home));
		    	{
		    	String homehtm =  U.getPageSource(home);
//		    	U.log(U.getSectionValue(homehtm, "<div id=\"IDX-description\"", "<div id=\"IDX-field-garageSpaces\""));
		    	homesdata += U.getSectionValue(homehtm, "<div id=\"IDX-description\"", "<div id=\"IDX-field-garageSpaces\"")+U.getSectionValue(homehtm, "<div class=\"IDX-panel-body", "IDX-description");
		    	// U.getSectionValue(homehtm, "<div class=\"IDX-detailsAddressInfo\">", "</div>");
		    	}
		    }
		    }
		    
		    //------------------------ QUICKS STATUS--------------------------
		    String quickData = ALLOW_BLANK;
		    int quickHomeCount = 0;
		    
		    if(comHtml.contains("<h1>Available Homes</h1>")) {
		    	
		    	U.log("QUICKS PRESENT ----------- ");
		    	
		    	String [] availableQuicks = U.getValues(comHtml, "<div class=\"IDX-showcaseContainer", "</div></div></div></div>");
			    U.log("homedata here: "+availableQuicks.length);	
			    
			    for(String quicks:availableQuicks) {
			    	
			    	String quickUrl = U.getSectionValue(quicks, "<a href=\"", "\"");
			    	U.log("quickUrl: "+quickUrl);
			    	
			    	if(quickUrl != null) {
			    		String quickHome = U.getHTML(quickUrl);
			    		
			    		//for quick status
			    		//U.log(">>>>>>>>>>>>"+Util.matchAll(quickHome, "[\\s\\w\\W]{30}<span class=\"IDX-text\">\\s+Active[\\s\\w\\W]{30}", 0));
			    		
			    		quickHome = quickHome.replaceAll("<span class=\"IDX-text\">\\s+Active", "Status-Active");
			    		
			    		if(quickHome.contains("Status-Active")) {
			    			
			    			quickHomeCount++;
			    		}
			    		
			    	}
			    }
		    }
		    
		    U.log("quickHomeCount: "+quickHomeCount);
		    
		    //============== Sqft =========================
		    
		    String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		    if(combinedAvailableHtml!=null)combinedAvailableHtml= combinedAvailableHtml.replace("SqFt</span><span class=\"IDX-text\">", "SqFT ");
//		    U.log("<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+Util.matchAll(homesdata, "[\\s\\w\\W]{30}SqFt[\\s\\w\\W]{30}",0));
		    String sqft[] = U.getSqareFeet(comHtml+combinedAvailableHtml+homesdata+commSec,//.replaceAll(">SqFt</span><span class=\"IDX-text\">\\s+\\d,\\d{3}\\s+</span>", "")
					"sqft\">\\d,\\d{3}|homes range in size from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft.|range in size from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft.|ranging from approximately \\d,\\d{3} to \\d,\\d{3} sq. ft.|ranging from \\d,\\d{3} to \\d,\\d{3} sq. ft|SqFt</span><span class=\"IDX-text\">\n" + 
					"\\d,\\d{3}|class=\"  column-sqft\">\\d+</td>|SqFt\n\\s+</span>\n\\s+<span class=\"IDX-text\">\n\\s+\n\\s+\\d,\\d{3}|<td style=\"\">\\d{1},\\d{3}</td>|SqFt Total\\s+</span>\\s+<span class=\"IDX-text\">\\s+\\d{4}\\s+</span>|>SqFt Total</span><span class=\"IDX-text\">\\s+\\d{4}\\s+</span>|\\d{4} sq.ft|column-sqft\">\\d{4}</td>|\\d{4} Maximum\\s*</td>|\\d{4} Standard\\s*</td>|sqft\">\\d,\\d+</td>|SqFt Total\\s{2,}</span>\\s{2,}<span class=\"IDX-text\">\\s{2,}\\d{4}|Square Feet\\s+</span>\\s+<span class=\"IDX-text\">\\s+\\d,\\d{3}|<td style=\"\">\\d{4}</td>|\\d,\\d{3} Maximum\\s*</td>|SqFT \\d,\\d{3}|SqFT \\d{3}",
					0);
		    
//		    U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll((comHtml), "[\\s\\w\\W]{100}1,051,000[\\s\\w\\W]{100}",0));
//		    U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll((combinedAvailableHtml), "[\\s\\w\\W]{100}1,051,000[\\s\\w\\W]{100}",0));
//		    U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll((homesdata), "[\\s\\w\\W]{100}1,051,000[\\s\\w\\W]{100}",0));
//		    U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll((commSec), "[\\s\\w\\W]{100}1,051,000[\\s\\w\\W]{100}",0));

		    minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		    U.log("SQFT:::"+minSqft+"\t"+maxSqft);
			
		    //================ Price =====================
		    
//		    U.log("commSec ------>"+commSec);
		    comHtml=comHtml.replace("ranges from $125,000 to the $300,000�s", "");
		    Matcher mat = Pattern.compile("\\$\\d{3}s",Pattern.CASE_INSENSITIVE).matcher(commSec);
		    while(mat.find()){
			    //U.log(mat.group());
			    String priceMatch = mat.group().replace("s", ",000");  //$230s
			    commSec = commSec.replace(mat.group(), priceMatch);
		    }
		    
//		    U.log("================\n"+commSec);
		    comHtml = comHtml.replaceAll("$125,000 to the $300,000’s and home site sales will be managed", "");
		    
		    comHtml = comHtml.replace("$280s.\",", "");
		    comHtml = comHtml.replace("0’s", "0,000").replaceAll("0s|0's|0�s|0�s","0,000");
		    comHtml = comHtml.replace("lots ranges from $125,000 to the $300,000,000 and", "");
//		    U.log(Util.match(commSec, ".*\\$300.*"));
		    String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;//renaissance">278,000</td>
//		    U.log(commSec);
		    if(commSec==null)commSec=ALLOW_BLANK;
		    if(commSec !=null) {
		    	String rmSec=U.getSectionValue(commSec, "<div class=\"infowindow\"><p style=\"text-align: center;\">", "<");
		    	if(rmSec!=null)
		    	commSec= commSec.replace(rmSec, "");
		    } 	
		    commSec=commSec.replace("from the upper $500s", "from the upper $500,000").replace("from the mid $400s", "from the mid $400,000").replaceAll("\\$390,000 Paired-patio hom|from the \\$380,000</p>", "").replace(" low to mid $400s", " low to mid $400,000");
		    addSection = addSection.replace("$700s", "$700,000");
//		    if(communityUrl.contains("/project/north-fork-classic-collection/"))commSec += "Single family homes from the upper $300,000";
		    
		    if(communityUrl.contains("sanctuary-pointe-single-family-homes")) commSec = commSec.replace("upper $300,000", "");
//		    U.log(addSection);
//		    if(communityUrl.contains("https://classichomes.com/project/sanctuary-pointe-renaissance-collection/")) {
//		    	//price not in reg page but present in pagesource
//		    	commSec=commSec.replaceAll("Single Family Homes from the mid $400,000|Homes from the upper $300,000", "");
//		    }
//		    U.log(commSec+"===============================\n");
//		    U.log(combinedAvailableHtml+"============================\n");
//		    U.log(comHtml+"===============================\n");
		    
		    RegStatus=RegStatus.replace("0s","0,000");
		    commSec=commSec.replace("0s","0,000");
//		    U.log("reg satatusPP"+RegStatus);	
		    String[] price = U.getPrices(comHtml+commSec+combinedAvailableHtml+addSection+RegStatus,
					"from our Classic Collection. From the \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|>\\d{3},\\d{3}</td>|upper \\$\\d{3},\\d{3}|>\\d,\\d+,\\d+</td>|<td style=\"\">\\d,\\d{3},\\d{3}</td>|upper \\$\\d{3},\\d{3}| low to mid \\$\\d{3},\\d{3}|renaissance\">\\d{3},\\d{3}</td>|\\$\\d{3},\\d{3}</div>|\\$\\d+,\\d+|From the \\$\\d+,\\d+|From the \\d+,\\d+|from the \\$\\d{3},\\d{3}|to the \\$\\d{3},\\d{3}|blrfillings14c\">\\d{3},\\d{3}</td>|the \\$\\d{3},\\d{3}", 0);///|>\\d{3},\\d{3}<
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("MinPrice :" + minPrice + " MaxPrice:"+ maxPrice);
			
//			U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll(comHtml, "[\\s\\w\\W]{60}400,000[\\s\\w\\W]{60}",0));
//			U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll(commSec, "[\\s\\w\\W]{60}400,000[\\s\\w\\W]{60}",0));
//			U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll(combinedAvailableHtml, "[\\s\\w\\W]{60}400,000[\\s\\w\\W]{60}",0));
//			U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll(addSection, "[\\s\\w\\W]{60}400,000[\\s\\w\\W]{60}",0));
//			U.log("MMMMMMMMMMMMMMMMMMmm "+Util.matchAll(RegStatus, "[\\s\\w\\W]{60}400,000[\\s\\w\\W]{60}",0));
//		    U.log(">>>>>>>>"+RegStatus);
		//
			
		    //================= Community Type ==================
			if(communityUrl.contains("https://classichomes.com/project/banning-lewis-ranch/"))commSec="The Retreat at Banning Lewis Ranch an Age Restricted 55+ Community"+commSec;
			comHtml = comHtml.replaceAll("s, disc golf course, |Banning Lewis Ranch Retreat \\(55\\+ Community\\)|value='Banning Lewis Ranch Retreat \\(55\\+ Community\\)'|content=\"Offering pools, tennis courts, and more, Banning Lewis Ranch is a master planned |signature golf course designed|MasterPlan|masterplan", "");

//			rem = U.getSectionValue(comHtml, "Parks and Recreation</h5>", "</div>");
//			if(rem != null) comHtml = comHtml.replace(rem, "");
			comHtml=comHtml.replaceAll("Pine Creek Golf Club – 15 minutes|<p>If golfing is of interest to you, Banning Lewis Ranch is located near several golf courses", "")
					.replace(" including Springs Ranch,&nbsp;Antler Creek (in Meridian Ranch)&nbsp;and Pine Creek Golf Courses.</p>", "")
					.replace("golfer seeking", "golf and").replaceAll("Golf Club in Meridian Ranch is worthy of 18 holes|award winning Golf Course and Club at Flying Horse|Golf Course is \\d+ minutes|Golf Course is approximately \\d+ minutes", "");
			
		    String communityType = U.getCommunityType(comHtml.replace("luxurious resorts", "resort-like activities")+commSec);
		    

		    
		    U.log("Ctype:::"+communityType);
		    //================== Property Type ================
		   
		    comHtml = comHtml.replaceAll("Villa Sport|(V|v)illage|paired-patio-collection\">Paired Patio Plans</a>|do not impact the Wolf Ranch Homeowner", "").replaceAll("Ranch</a>|-ranch|>Ranch", "");
		    commSec = commSec.replaceAll("Ranch</a>|-ranch|ranch-|>Ranch", "");
		    if(communityUrl.contains("/project/sanctuary-pointe-paired-patio-homes/")) commSec = commSec.replaceAll("Single Family Homes", "");
		    if(communityUrl.contains("/project/renaissance-indigo-ranch/")) commSec = " Single family homes from the $330s ";
		    if(communityUrl.contains("https://classichomes.com/project/sterlingranch/"))commSec = " Single family homes";
		   
		    rem = U.getSectionValue(comHtml, "<h1>Gallery</h1>", "<script type=\"text/javascript\">");
		    if(rem != null) comHtml = comHtml.replace(rem, "");
		    rem = U.getSectionValue(comHtml, "class=\"mobile_nav closed\">", "</div>");
		    if(rem != null) comHtml = comHtml.replace(rem, "");
		    

		    //U.writeMyText(comHtml+combinedAvailableHtml+commSec+homesdata);
		    String propertyType = U.getPropType((comHtml+combinedAvailableHtml+commSec+homesdata).replaceAll("Fork Townhomes</label>|Townhomes\"|-townhome-|Townhomes</a>|-[P|p]atio-|Telluride Paired Patio|paired-patio-collection\">Paired Patio Plans</a>|townhome-collection/\">Townhomes|Paired Patio</a>|chinese-traditional|Chinese \\(Traditional\\)", ""));
		    U.log("PType::"+propertyType);
		    
		    //================= Property Status =============
		    comHtml = comHtml.replace("currently <em>SOLD OUT", "currently SOLD OUT")
		    		.replace("New homesites are coming soon", "New homesites coming soon").replaceAll("Complex is now open|construction with a planned opening in the Spring of 2019|Grand Closing Homes are now available|MODELS OPENING SUMMER 2018|ranch/\"|Ranch\\s*</a>\\s*</li>|>\\s*2-story\\s*<|2 Story Floor Plans|Coming Soon:&nbsp; West Valley at Forest Lakes|Complex is now|closeout|sac lots|release of Sanctuary|maintenance community now|release will take place|is now open and the|Model Home</a> are now open|odel Home is now open ", "")
		    		.replaceAll("\"With \\d+ floor plans available to build|TimberRidge is currently sold from the Homestead|Lakes are coming soon|currently sold from our Hannah Ridge Classic|currently sold from our Wolf Ranch Classic Collection Model|center will be opening|out of Filings|Wolf Ranch is sold|close-outline|is now&nbsp;open!&nbsp;&nbsp;Amenities|Complex is now open|grand opening during|showcaseRemarks\">Coming soon|Center is Now|open by appointment", "");
		    RegStatus=RegStatus.replaceAll("New lnventory Homes Coming Soon!|New lots coming soon.</em>", "");
		    commSec = commSec.replace("find our SOLD OUT Midtown Collection featuring", "");
		    
		    
		    // U.log("reg satatus"+RegStatus);
		    String propertyStatus = U.getPropStatus((comHtml.replace("new home designs coming soon", "").replace("New Homesites in Filing 5 Coming Soon", "New Homesites Coming Soon")
		    		+(commSec+RegStatus).replaceAll("MIDTOWN COLLECTION</a>: <em>SOLD OUT</em></p>", "")));
//		   U.log("propertyStatus==========="+commSec);
		    

		    U.log("propertyStatus"+propertyStatus);
//		    U.log(">>>>>>>>>>>>>>>>>>>>>>>>>> "+Util.matchAll(commSec+RegStatus, "[\\s\\w\\W]{60}sold out[\\s\\w\\W]{60}",0));
		    
		    
		    //------for quick stataus
		    
		    if(quickHomeCount > 0) {
		    	if(propertyStatus == ALLOW_BLANK)
		    		propertyStatus = "Quick Move-Ins";
		    	else if(propertyStatus != ALLOW_BLANK)
		    		propertyStatus = propertyStatus + ", Quick Move-Ins";	
		    	}

		    
		    //================= Derived Community Type ============
		    comHtml = comHtml.replaceAll("Springs Ranch|sterlingranch|Wolf Ranch|Ranch Road|Springs Ranch|Ranch</label>|Ranch</a>|Ranch\"", "");
		    comHtml=U.getNoHtml(comHtml);

		    String dType = U.getdCommType(communityName+commSec+(comHtml+combinedAvailableHtml).replaceAll("minutes from Indigo Ranch|Ranch Road|>\\d+ Story Floor Plans<|>2 Story Floor Plans<|Springs Ranch|branch|3 [S|s]tory [f|F]loor [P|p]lans|Ranch\"|Ranch Retreat|Ranch</", ""));
		    

		    //================ Notes ===================
		    comHtml = comHtml.replaceAll("for sales in Filing", "");
		    note = U.getnote(comHtml);
		    if(communityUrl.contains("https://classichomes.com/project/timberridge/"))maxPrice = "$1,022,500";
		    if(communityUrl.contains("https://classichomes.com/project/greenways/"))minPrice = "$500,000";
		    if(communityUrl.contains("/sanctuary-pointe-renaissance-collection/"))propertyStatus="Sold Out";
		    if(communityUrl.contains("https://classichomes.com//project/village-of-verona/")) communityType+=",Golf Course";
		    if(communityUrl.contains("https://classichomes.com//project/wolf-ranch-paired-patio-homes/"))minPrice = "$360,000";
		    if(communityUrl.contains("/pathways-4-square/")||communityUrl.contains("pathways-midtown/") ) {minPrice = "$400,000";propertyStatus="Now Selling";} 
		    if(communityUrl.contains("village-of-palermo/") )minPrice = "$600,000";

		//U.log(combinedAvailableHtml);
		    
		    //propertyType=propertyType.replace("Single Family,","");
		    
		    if(propertyStatus.length()==0){
		    	propertyStatus=ALLOW_BLANK;
		    }
		    
		    if(propertyType.length()==0){
		    	propertyType=ALLOW_BLANK;
		    }
//https://classichomes.com/project/sanctuary-pointe-renaissance-collection/

			if(communityUrl.contains("/milan-flying-horse/")) {minSqft="3190";maxSqft="5137";}
			if(communityUrl.contains("/project/cottonwood-creek/")) communityName = "Midtown Collection at Cottonwood Creek";
			if(communityUrl.contains("/project/foothills-farm")){
				communityName = "Midtown at Foothills";
				add[0] = "6385 Corporate Drive";
				add[1] = "Colorado Springs";
				add[2] = "CO";
				add[3] = "80919";
				String latLng[] = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				lat = latLng[0];
				lng = latLng[1];
				geo = "True";
				note = "Address Is Taken From Contact Page";
			}
			
			if(communityUrl.contains("https://classichomes.com/project/sanctuary-pointe-renaissance-collection/")) 
			{
				
				add[0] = "1654 Summerglow Lane";
				add[1] = "Monument";
				add[2] = "CO";
				add[3] = "80132";
				geo = "False";
				
			}
//			if(communityUrl.contains("project/greenways/"))propertyStatus="Now Selling";
		//	https://classichomes.com/projects/hannah-ridge/
			if(communityUrl.contains("/project/banning-lewis-ranch/"))communityType =communityType.replace("Golf Course, Resort Style, 55+ Community", "Resort Style, 55+ Community");
			if(communityUrl.contains("https://classichomes.com/project/greenways/"))communityName="Greenways at Sand Creek";
			if(communityUrl.contains("/sanctuary-pointe-single-family-homes/"))propertyStatus = ALLOW_BLANK;
			if(communityUrl.contains("https://classichomes.com/project/lexington-crossing/"))propertyType = propertyType + ", Single Family";
			if(communityUrl.contains("https://classichomes.com/project/cottonwood-creek/"))geo = "FALSE";
			
			
			if(communityUrl.contains("https://classichomes.com/project/sanctuary-pointe-single-family-homes/")) {
				minSqft="3094";
				maxSqft="5827";
				
			}
			if(communityUrl.contains("https://classichomes.com/project/timberridge/")) {
				minSqft="3272";
				maxSqft="5827";
				
			}
//			if(communityUrl.contains("https://classichomes.com/project/sterlingranch/")) {
//				minSqft="3748";
//			}
//			if(communityUrl.contains("https://classichomes.com/project/pathways-4-square/")) {
//				minSqft="1685";
//			}
			if(communityUrl.contains("https://classichomes.com/project/timberridge/")) {
				communityName="Timber Ridge";
				minSqft="2743";
			}
			
			
//			if(communityUrl.contains("/project/banning-lewis-ranch/"))communityName="The Retreat";
//
			if(communityUrl.contains("hannah-ridge-classic-collection/"))communityName="Hannah Ridge classic collection";
			if(communityUrl.contains("/hannah-ridge-midtown/"))communityName="Hannah Ridge midtown  collection";
			if(communityUrl.contains("/wolf-ranch-single-family-homes/"))communityName="Wolf Ranch The Classic Collection";
			if(communityUrl.contains("wolf-ranch-midtown-collection/"))communityName="Wolf Ranch The Midtown Collection";
//			if(communityUrl.contains("project/village-of-palermo/"))communityName="Flying Horse";

			
			propertyStatus=propertyStatus.replace("Coming Soon Fall 2021, Coming Soon", "Coming Soon Fall 2021").replace("New Lots Coming 2022, Coming 2022", "New Lots Coming 2022");
//			communityName = communityName.replaceAll("the|The", "");
			data.addCommunity(communityName.trim(), communityUrl, communityType);
			data.addAddress(add[0].replace("Sold from Timber Ridge Model:", "").trim(), add[1].replace("</a> ","").trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(propertyType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
		
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
}
