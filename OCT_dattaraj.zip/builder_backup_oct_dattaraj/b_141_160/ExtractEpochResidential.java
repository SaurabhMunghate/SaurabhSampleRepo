/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_141_160;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEpochResidential extends AbstractScrapper{

	CommunityLogger LOGGER;
	int j=0;
	int k=0;
	public ExtractEpochResidential()throws Exception {
		super("Epoch Residential","https://epochresidential.com/");
		LOGGER=new CommunityLogger("Epoch Residential");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractEpochResidential();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Epoch Residential.csv", a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();

		String Html=U.getHTML("https://epochresidential.com/communities");
		String[] commSec=U.getValues(Html,"location_category_id\":\"","notes\":");
		U.log("Total Community--->"+commSec.length);
		for(String com:commSec)
		{
			//U.log(com);
			String url1=U.getSectionValue(com,"\"url\":\"","\"").replaceAll("\\\\", "");
			//U.log("comUrl-->"+url1);
//			if(url1.contains("www.integrasprings.com/"))
			//url1=getRedirectedURLConnection(url1);
//			try {
				addCommunity(url1,com);
//			} catch (Exception e) {}
			
		}
//		driver.close();
		LOGGER.DisposeLogger();
		U.log("repeted--->"+k);
	}
	
	WebDriver driver=null;
	
	private void addCommunity(String comUrl, String oldData) throws Exception {
		//TODO :
//		if(!comUrl.contains("winterpark.epochlivingcalirosa")) return;

		//		try {
		
		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
			k++;
			return;
		}
		if (comUrl.contains("http://yourcapitalplace.com/")){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Redirects to MARK-TAYLOR");
			k++;
			return;
		}
		U.log("community Url:--"+comUrl);
		if(comUrl.length()<5 || !comUrl.contains("http"))return;
		String html=U.getHtmlHeadlessFirefox(comUrl,driver);
		
		//========================== No. of units ==========================
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(html, comUrl, driver);
		U.log("Total Units : "+units);
	
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(oldData, "name\":\"","\"");
		communityName = communityName.trim().replaceAll("Kissimmee Active Adult|Active Adult Apartments$| Apartment Homes", "");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		U.log(oldData);
		
		add[0]=U.getSectionValue(oldData, "address\":\"", "\"");
		add[1]=U.getSectionValue(oldData, "city\":\"", "\"");
		add[2]=U.getSectionValue(oldData, "state\":\"", "\"");
		add[3]=U.getSectionValue(oldData, "zip\":\"", "\"");
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
//------------------------------------------------------------------------------------------------------------------
		
		latlag[0]=U.getSectionValue(oldData,"latitude\":\"","\"");
		latlag[1]=U.getSectionValue(oldData,"\"longitude\":\"","\"");
		U.log("lat lng are ::::::::::: "+latlag[0]+":::::::::::::::::"+latlag[1]);
		
		if(latlag[0].length()<4||latlag[0].contains("0.000000000")){
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if(add[0]==ALLOW_BLANK){
			add[0]=U.getAddressGoogleApi(latlag)[0];
		}
		
//============================================Price and SQ.FT======================================================================
		String FloorHtml=ALLOW_BLANK;
		String animit=ALLOW_BLANK;
		String comUrl1=comUrl.replace("http:", "https:");

		if(comUrl.contains("www.gilberttowncommons.com")){//||comUrl.contains("http://maitlandstationapts.com/")){
			FloorHtml=U.getHtml("http://www.gilberttowncommons.com"+"/floor-plans",driver);
			animit=U.getHtml("http://www.gilberttowncommons.com"+"/amenities",driver);
		}
		if(comUrl.contains("theoaksonthelake")){//||comUrl.contains("http://maitlandstationapts.com/")){
			FloorHtml=U.getHtml("https://www.theoaksonthelake.com/"+"floorplans",driver);
			animit=U.getHtml("https://www.theoaksonthelake.com"+"/amenities",driver);
		}
		if(comUrl.contains("http://maitlandstationapts.com/")){
			FloorHtml=U.getHTML("https://maitlandstationapts.com/"+"/floor-plans/");
			animit=U.getHTML("https://maitlandstationapts.com/"+"/amenities");
		}
		if (comUrl.contains("http://thepierpontapartments.com")) {
			FloorHtml=U.getHtml("http://thepierpontapartments.com"+"/floor-plans/", driver);
		}
		if (comUrl.contains("http://www.theoaksatsouthlakecommons.com/")) {
			FloorHtml=U.getHtml("https://www.theoaksatsouthlakecommons.com/floor-plans/", driver);
		}
		if(comUrl.contains("https://gilberttowncommons.com"))
		{
			FloorHtml=U.getHtml("https://gilberttowncommons.com"+"/floor-plans/", driver);
		}
		if(comUrl.contains("epochlivingkestra.com"))
		{
			animit=U.getHtml("https://epochlivingkestra.com/amenities/", driver);
			FloorHtml = U.getHtml("https://epochlivingkestra.com/floorplans/", driver);
		}
		if(comUrl.contains("http://epochlivinglakeside.com")||comUrl.contains("http://www.caneislandliving.com/")|| comUrl.contains("http://epochlivingseaisleresort.com/")||comUrl.contains("http://epochlivingwiregrass.com/")){
			FloorHtml=FloorHtml+U.getHTML((comUrl.replace("http", "https")+"/floorplans/").replace("//floorplans", "/floorplans"));
			if(comUrl.contains("http://www.caneislandliving.com/")||comUrl.contains("http://epochlivingseaisleresort.com/")||comUrl.contains("http://epochlivingwiregrass.com/"))
				FloorHtml=FloorHtml+U.getHTML(comUrl+"floorplans/");
			animit=animit+U.getHTML(comUrl+"/amenities");
		}
		if(comUrl.contains("http://epochlivinglakeside.com")) {
			animit = U.getHTML("https://epochlivinglakeside.com/features/");
		}
		if(comUrl.contains("https://thepierpontapartments.com/")) {
			animit = U.getHtml("https://thepierpontapartments.com/apartment-features/",driver);
			FloorHtml= U.getHtml("https://thepierpontapartments.com/floor-plans/",driver);
		}
		if(comUrl.contains("epochlivingveere.com")) {
			animit = U.getHtml("https://epochlivingveere.com/features-amenities/",driver);
			FloorHtml= U.getHtml("https://epochlivingveere.com/availability/",driver);
		}
		if(comUrl.contains("loftsatuptown.com")) {
			animit = U.getHtml("https://loftsatuptown.com/features-amenities/",driver);
			FloorHtml= U.getHtml("https://loftsatuptown.com/availibility/",driver);
		}
		if (comUrl.contains("http://epochlivingstationhouse.com")) {
			FloorHtml=U.getHTML(comUrl+"floorplans");
		}else if(FloorHtml==null&& animit==null||comUrl.contains("/www.wildflowergainesville.com")){
			FloorHtml=U.getHTML(comUrl1+"floorplans.aspx")+U.getHtmlHeadlessFirefox(comUrl+"interactivemap.aspx", driver);;
			U.log(comUrl+"floorplans.aspx"+"*************");
			animit=U.getHTML(comUrl1+"amenities.aspx");

		}
		if(FloorHtml==null || FloorHtml.length() < 100 ){
			U.log("Heereerer");
			if (comUrl.endsWith("/")) {
				FloorHtml=U.getHtmlHeadlessFirefox(comUrl+"floor-plans/", driver);
			}else{
				FloorHtml=U.getHtmlHeadlessFirefox(comUrl+"/floor-plans/", driver);
			}
			 
		}
		if(animit==null || animit.length() < 100){
			animit=U.getHtmlHeadlessFirefox(comUrl+"/apartment-features/", driver);
		}
		if(animit == null)
			animit=U.getHtmlHeadlessFirefox(comUrl+"/features-amenities/", driver);
			
//		U.log(FloorHtml.length());
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0s","0,000");
		String prices[] = U.getPrices(html+FloorHtml,"Starting at \\$\\d+,\\d+|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+|the low \\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		
//		U.log(FloorHtml);
//		U.log(">>>>>>>>>>>"+Util.matchAll(FloorHtml, "[\\w\\s\\W]{30}square feet[\\w\\s\\W]{10}",0));
		String[] sqft = U.getSqareFeet(html+FloorHtml+animit,
						"\\d,\\d{3} [SQ FT|square feet]|</span>\\d+ Square Feet</p>|</span>\\d,\\d{3} Square Feet</p>|sq. ft.</div>\\s+\\d{3}-\\d,\\d{3}|\\d{4}</td></tr>|Interior Space \\d{3} s.f.|\\d,\\d{3} Square Feet|\\d{3,4} SQ|\\d{3,4} SQ. FEET|sqft</span> \\d{3,4}-\\d,\\d{3}|SQ. FT.\">\\d{3,4}|<li>Sq Ft: \\d{3,4}|\\s+sqft: \\d{3,4},\\s*beds|sqft: \"\\d{3}\",|sqft: \"\\d,\\d{3}\",",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		html=html.replaceAll("=\"gatedCommunity\"|<span>Gated Community</span>", "");
		animit =U.removeComments(animit);
//		U.log("result:::::"+Util.match(html, ".*?coming.*?"));
		
//		U.writeMyText((html+animit).replace("Gated Access", "gated community"));
		String communityType=U.getCommType((html+animit)
				.replace("gated dog park", "")
				.replaceAll("Gated Access|Gated / Restricted Access", "gated community").replaceAll("Luxury Active Adult Apartments in Kissimmee|Calirosa Active Adult", "").replaceAll("Gated dog park", ""));
		U.log("communityType: "+communityType);
//		U.log(">>>>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{50}gated[\\w\\s\\W]{50}",0));
		
		if(comUrl.contains("http://epochlivingseaisleresort.com/")) {
			
			if(communityType.length()>2)
				communityType = communityType + ", Gated Community";
			else
				communityType = "Gated Community";
		}
		//U.log(html);
//==========================================================Property Type================================================
		animit = U.removeComments(animit);	
		FloorHtml=FloorHtml.replace("(Loft)", "and loft");
		String proptype=U.getPropType((html+animit+FloorHtml).replace("offers luxury,", "luxury homes").replaceAll("\"Luxury Apartment|<title>Luxury Apartments|CARRIAGE|f\\.traditional",""));
		
	
		U.log("Ptype::"+proptype);
//==================================================D-Property Type======================================================
		html =html.replaceAll("Ranch</option>| Ranch Apartments</option>", "");
//		FloorHtml = FloorHtml.replaceAll("2nd Floor</option>|1st Floor</option>|3rd Floor</option>", "");
//		animit = animit.replace("1st floor", "1 story").replace("2 Levels", "2 story").replace("2n floor", "2 story").replace("3rd Floor", "3 story");
		String dtype=U.getdCommType((html+FloorHtml+animit).replace("First Floor", "1 story").replaceAll("floor|Floor|Two-story clubhouse featuring", ""));
		
//===============================animit===============Property Status=========================================================
//		U.log(">>>>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{10}Now Available[\\w\\s\\W]{10}",0));
		
		html=html.replaceAll("Tours Now Available|Our leasing office is now open|terms now available|UNITS ARE NOW AVAILABLE|Now leasing Wildflower apartments|Office is now open on|Now Open\\s*</option>|NOW OPEN SUNDAY|Move in Specials Now Available|Move in specials now available|Coming Soon - Contact us|Amazon lockers are now available|<h3>Limited time|Limited time offer\\*  One", "");
		animit = animit.replace("lockers-coming soon", "");
//		U.log("result:::::"+Util.match(html, ".*?Now Open.*?"));
		String pstatus=U.getPropStatus(html+animit+oldData);
//		U.log("MMMMM"+Util.matchAll(html+animit+oldData, "[\\w\\s\\W]{30}Limited Availability[\\w\\s\\W]{30}", 0));
//		U.log("MMMMM"+Util.matchAll(html+animit+oldData, "[\\w\\s\\W]{30}limited[\\w\\s\\W]{30}", 0));
//		U.log("MMMMM"+Util.matchAll(html, "[\\w\\s\\W]{30}privy-popup-content [\\w\\s\\W]{30}", 0));
		if(comUrl.contains("thepierpontapartments"))communityType="Golf Course";
		if(comUrl.contains("loftsatuptown.com/")) {communityType="Resort Style";proptype=proptype+", Single Family";};
	
		///Status From Images
		if(comUrl.contains("https://astoriaatcelebration.com/") || comUrl.contains("epochlivingcalirosa"))proptype=proptype+", Patio Homes";
//============================================note====================================================================
		String note=U.getnote(html.replaceAll(" content=\"Now leasing|Now leasing Sea Isle apartments", ""));
		
//		if(comUrl.contains("https://epochlivingmandolin.com")
//				|| comUrl.contains("https://www.theoaksonthelake.com/")) note= "Now Leasing";
		if(comUrl.contains("loftsatuptown.com")) {minSqft="890";maxSqft="1,374";}
		if(comUrl.contains("epochlivingveere.com")) {minSqft="682";maxSqft="1,579";}
		if(comUrl.contains("http://epochlivingkestra.com")) dtype = "2 Story";
			
		if (html.contains("https://www.mark-taylor.com/")){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Redirect to new Builder");
			k++;
			return;
		}
//		if(comUrl.contains("https://winterpark.epochlivingcalirosa.com/")) {
//			minSqft=ALLOW_BLANK;
//			maxSqft=ALLOW_BLANK;
////			pstatus="Coming Soon"; //from reg page from img
//		}
		
		LOGGER.AddCommunityUrl(comUrl);
		comUrl=comUrl.replace("http://", "https://");
		if(comUrl.contains("www.caneislandliving.com/"))comUrl="https://www.caneislandliving.com/";
		if(comUrl.contains("https://www.loftsatuptown.com"))communityType=ALLOW_BLANK;
		//from images reg 23Aug21
		if(comUrl.contains("https://winterpark.epochlivingcalirosa.com/")) note = "Now Leasing"; // from region page
	//	if(comUrl.contains("www.kissimmee.epochlivingcalirosa.com/"))pstatus ="Now Open";
		if(comUrl.contains("https://winterpark.epochlivingcalirosa.com/"))pstatus ="Now Open";
		
		if(units.equals("0")) {
			units = ALLOW_BLANK;
				}
		
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		
		j++;
		
//		}catch (Exception e) {}
		
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0; int unitcount = 0;
		
		//-------- FOR WINTERPARK -------
		if(comUrl.contains("https://winterpark.epochlivingcalirosa.com/")) {
			
			String mapPageData = U.getHtml("https://winterpark.epochlivingcalirosa.com/floor-plans/all/availability/", driver);
			
			String frameSec = U.getSectionValue(mapPageData, "id=\"sightmap\" src=\"https://sightmap.com/embed", "\"");
			U.log("frameSec: "+frameSec);
			
			frameUrl = "https://sightmap.com/embed" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
 		}
		
		//-------- LOFT AT UPTOWN ALTAMONTE -------
		if(comUrl.contains("http://www.loftsatuptown.com/")) {
			
			String mapPageData = U.getHtml("https://loftsatuptown.com/availibility/", driver);
			
			String frameSec = U.getSectionValue(mapPageData, "id=\"sightmap\" src=\"https://sightmap.com/embed", "\"");
			U.log("frameSec: "+frameSec);
			
			frameUrl = "https://sightmap.com/embed" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
		}
		
		//-------- WILDFLOWER -------
		if(comUrl.contains("http://www.wildflowergainesville.com/")) {
			
			String mapPageData = U.getHtml("https://www.wildflowergainesville.com/interactivemap.aspx", driver);
			
			String frameSec = U.getSectionValue(mapPageData, "src=\"https://sightmap.com/embed", "\"");
			U.log("frameSec: "+frameSec);
			
			frameUrl = "https://sightmap.com/embed" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);

		}
		
		if(mapData != ALLOW_BLANK) {
			

			ArrayList<String> unitsAvailable = Util.matchAll(mapData, "\\d+ Units available|\\d Unit available", 0);
			U.log("Count Pins: "+unitsAvailable.size());
			
			for(String unitava : unitsAvailable) {
				unitava = unitava.replaceAll("Units available|Unit available", "").trim();
				U.log("unitava: "+unitava);
				
				unitcount += Integer.parseInt(unitava);
				
			}
			U.log("unitcount: "+unitcount);
			totalUnits = String.valueOf(unitcount);
		}
		
		return totalUnits;
	}
	
	
	//Getting redirected url
	public static String getRedirectedURLConnection(String url) throws IOException {
		String newUrl=null;
		URL obj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
		int status = conn.getResponseCode();
		if (status != HttpURLConnection.HTTP_OK) {
			if (status == HttpURLConnection.HTTP_MOVED_TEMP
				|| status == HttpURLConnection.HTTP_MOVED_PERM
					|| status == HttpURLConnection.HTTP_SEE_OTHER){
				newUrl = conn.getHeaderField("Location");
			}
			return newUrl;
		}
		else
		return url;

	}

}
