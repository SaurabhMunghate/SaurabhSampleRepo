/**
 * @author Upendra Singh 
 * @date 01/2017
 * @modify: Sawan
 * @date: 2-11-2017 
 */
package com.shatam.b_141_160;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEvergreeneHomes extends AbstractScrapper{

	private static final String builderUrl = "https://myevergreenehome.com";
	CommunityLogger LOGGER;
	int j=0;
	String latSE="";
	HashMap<String, String> latLon=new HashMap<>();

	public ExtractEvergreeneHomes()	throws Exception {
		super("Evergreene Homes",builderUrl);
		LOGGER=new CommunityLogger("Evergreene Homes");
	}
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractEvergreeneHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Evergreene Homes.csv", a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		int totalCount = 0;
		String mainHtml=U.getHTML("https://myevergreenehome.com");
		String regionSecs[]=U.getValues(mainHtml, "<a class=\"region-box-link\"", "title=\"");
		for (String region : regionSecs) {
			String regionUrl=U.getSectionValue(region, "href=\"", "\"");
			U.log("regionUrl::"+regionUrl);
			String regionHtml=U.getHTML(regionUrl);
			String commSecs[]=U.getValues(regionHtml, "<div class=\"single-location", "</a>");
			for (String comm : commSecs) {
				String url=U.getSectionValue(comm, "href=&quot;", "&quot;");
				if(url==null)
				  url=U.getSectionValue(comm, "<a href=\"", "\"");
				latLon.put(url, comm);
			}
		}
		String html = U.getHTML("https://myevergreenehome.com/evergreene-homes-communities/");
		String section = U.getSectionValue(html, "class=\"communities-tiles", "</section>");
		//String[] comSec = U.getValues(section, "<div class=\"community", "</a>");
		String[] comSec = U.getValues(section,"<a href=","</div>");
		U.log("soldCommunty : "+comSec.length);
		for(String com : comSec){
//			U.log("RegUrl::"+regUrl);
			String comUrl = U.getSectionValue(com, "\"", "\"");
			U.log("comUrl::"+comUrl);

			//String comHtml = U.getHTML(comUrl);
//			for(String comSec : comSection){
//				U.log(comUrl);
				totalCount++;
				addCommunity(comUrl, com);//=======================
			//}
		}
		String soldHtml=U.getHTML("https://myevergreenehome.com/evergreene-communities/sold-out/");
		latSE=U.getSectionValue(soldHtml, "<ul id=\"mapLocations\">","map-frame");
/*		String[] soldCommunty=U.getValues(soldHtml, "<div class=\"community ", "</div>");
		U.log("soldCommunty : "+soldCommunty.length);
		for (String string : soldCommunty) {
			//U.log(string);
			String comUrl=U.getSectionValue(string, "<a href=\"", "\"");
//			U.log(comUrl);
			//if(comUrl!=null)
			//addCommunity(comUrl,string+" Sold Out");
			
		}
*/		
		LOGGER.DisposeLogger();
		U.log("Total Count"+totalCount);
	}



	private void addCommunity(String comUrl, String comSec) throws Exception {
	//	if(j>-1)
//	if(j >= 6)	
		//try{
	{
//		if(!comUrl.contains("https://myevergreenehome.com/communities/on-your-lot-at-lake-anna/"))return;

		// TODO Auto-generated method stub
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"============>>>>>>Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"\t"+comUrl);
		String html=U.getHTML(comUrl);
		String html1 = html;
//		U.log(Util.matchAll(html, "[\\w\\s\\W]{30}sold[\\w\\s\\W]{30}", 0));

		
		html = U.removeSectionValue(html, "<head>", "</head>");
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comSec, "<h4>","</h4>");
		communityName = communityName.replace(" &#8211; ", " - ");
		U.log("community Name---->"+communityName);
		if(comUrl.contains("communities/signature-homes/"))communityName = "Signature Homes";
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};

		String geo="FALSE";
		String addSec=U.getSectionValue(html, "location\">","</div>");
		
		U.log("addSec---->"+addSec);
		if(addSec != null){
			addSec = addSec.replaceAll(",\\s*,", "");
			addSec = Util.match(addSec, "target=\"_blank\">(.*?)</a>",1);
			add = U.getAddress(addSec);
		
		}else {
			addSec=U.getSectionValue(html, "<h2>", "</h2>");
			if(addSec!=null)
			 add = U.getAddress(addSec);
			else {
				addSec=U.getSectionValue(html, "<a href=\"https://www.google.com/maps/","</span>");
				if(addSec!=null) {
				String myAddSec=U.getSectionValue(addSec, "\">","</a>");
				add=U.getAddress(myAddSec);
				}
			}
			
		}
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
		
		
				
//-----------------------------------LAt-Lng-------------------------------------------------------------------------------
		String[] latLng={ALLOW_BLANK,ALLOW_BLANK};
		latLng[0] = U.getSectionValue(comSec, "data-lat=\"", "\"");
		latLng[1] = U.getSectionValue(comSec, "data-lng=\"", "\"");
		if (latLng[0]==null) {
			String latLonSec=latLon.get(comUrl);
//			U.log("latLonSec ::"+latLonSec);
			if (latLonSec!=null) {
				latLng[0]=U.getSectionValue(latLonSec, "data-lat=\"", "\"");
				latLng[1]=U.getSectionValue(latLonSec, "data-lng=\"", "\"");
			}
			
		}
		if(latLng[0]==null) {
			String latS=U.getSectionValue(latSE, comUrl,"Get Directions");
			if(latS!=null){
			String ll=U.getSectionValue(latS, "href=&quot;http://maps.google.com?daddr=","&quot");
			latLng=ll.split(",");}
		}
		
		if(latLng.length==0){
			latLng = new String[]{ALLOW_BLANK,ALLOW_BLANK};
		}
		
		
		
		if(add[0] != null) add[0] = add[0].replaceAll("\\(.*?\\)", "");
		if(comUrl.contains("https://myevergreenehome.com/communities/on-your-lot-at-lake-anna/"))
		{
			add=U.getAddressGoogleApi(latLng);
			geo="TRUE";
		}
		if(comUrl.contains("https://myevergreenehome.com/communities/on-your-lot-in-western-loudoun/"))
		{
			add[2] = "VA";
			add[0] = "3684 Centerview Drive Suite 120";
			add[1] = "Chantilly";
			add[3] = "20151";
		}
//----------Fetching address from latlng------------
		U.log("latlong "+Arrays.toString(latLng));
		if(add[1]!=ALLOW_BLANK  && (latLng[1]==null||latLng[1].trim().length()==0)) {
			U.log("hello 44 ");
			//String as=U.getSectionValue(comSec, "<p>", "</p>");
			latLng=U.getlatlongGoogleApi(add);
			
			if(latLng == null) latLng = U.getNewBingLatLong(add);
			if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
			String add1[] = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getGoogleAddressWithKey(latLng);
//			add= add1;
			geo="TRUE";
		}
		if(add[1]==ALLOW_BLANK && latLng[1]==null) {
			U.log("hello 55 "+comSec);
			String as=U.getSectionValue(comSec, "<p>", "</p>");
			String[] ss=as.split(",");
			if(ss!=null) {
			add[1]=ss[0];
			add[2]=ss[1];
			
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
			geo="TRUE";
			}
		}
		if(add[0].length()<4 && latLng[0].length()>4){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			geo="true";
		}
		
		if(latLng[0].length()<4 && add[1].length()>3) {
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
			geo="TRUE";
		}
	
		if(comUrl.contains("https://myevergreenehome.com/communities/sold-out-17/")) {
			add[2] = "VA";
			add[0] = "8842 Orchard Ln";
			add[1] = "Manassas";
			add[3] = "20110";
		}
		
		
		if(add[3].length()<4 && latLng[0].length()>4){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			geo="TRUE";
		}
//============================================Price and SQ.FT======================================================================
		
		
		String combinedHomeHtmls = ALLOW_BLANK;
		String homeProtype=ALLOW_BLANK;
		String quickUrlSection = U.getSectionValue(html, "id=\"quickDeliveries\">", "</section>");
		if(quickUrlSection != null){
			String[] quickHomeUrls=U.getValues(quickUrlSection, "<div class=\"home ","<div class=\"inner\">");
			
			for(String qHomeUrl:quickHomeUrls)
			{
				try {
				qHomeUrl = U.getSectionValue(qHomeUrl, "<a href=\"", "\" title=");
				U.log("quickHomeUrl=="+qHomeUrl);
				String homeHtml = U.getHTML(qHomeUrl);
				homeProtype+= U.getSectionValue(homeHtml, "<header class=\"home-header\"", "</strong></h4>");
				combinedHomeHtmls += U.getSectionValue(homeHtml, "<div class=\"home-specs\"", "<section class=\"community-homes");
				}catch(Exception e) {}
			}
		}
		String[] homeUrls=U.getValues(html, "<div class=\"home homes-","<div class=\"inner\">");
		for(String homeUrl:homeUrls)
		{
			homeUrl = U.getSectionValue(homeUrl, "<a href=\"", "\" title=");
			U.log("homeUrl=="+homeUrl);
			String homeHtml = U.getHTML(homeUrl);
			homeProtype+= U.getSectionValue(homeHtml, "<header class=\"home-header\"", "</strong></h4>");
			combinedHomeHtmls += U.getSectionValue(homeHtml, "<header class=\"home-header\"", "<section class=\"community-homes");
		}
//		combinedHomeHtmls = combinedHomeHtmls.replace("3 levels", "3 stories");
//		U.log(combinedHomeHtmls);
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log(Util.matchAll(html+combinedHomeHtmls, "[\\w\\s\\W]{30}\\$2[\\w\\s\\W]{30}", 0));

		html = html.replace("&#8217;s", ",000").replace("$1.973,973", "$1,973,973").replace("$1.48M", "$1,480,000").replace("$2.1M &#8211; $2.2M", "$2,100,000 – $2,200,000")
				.replace("0s", "0,000").replace("$1.6M", "$1,600,000").replace("$1.9M", "$1,900,000").replace("$1.480M","$1,480,000")
				.replace("$2.25M - $2.3M", "$2,250,000 - $2,300,000")
				.replace("$2.25M","$2,250,000").replace("$2.3M","$2,300,000")
				.replace("$1.8M", "$1,800,000").replaceAll("From (\\d)\\.(\\d)M<", "From \\$$1,$200,000<").replace("From $2.1M", "From $2,100,000 Million");
		
		String prices[] = U.getPrices(html+combinedHomeHtmls,
				"From \\$\\d,\\d{3},\\d{3} &#8211; \\$\\d,\\d{3},\\\\d{3}|\\$\\d,\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3} Million|prices start in the \\$\\d{3},\\d{3}|(High|low) \\$\\d{3},\\d{3}|priced from \\$\\d{3},\\d{3}|Price: <strong>\\$(\\d,)?\\d{3},\\d{3}|From <strong>\\$(\\d,)?\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|<p><strong>\\$\\d{3},\\d+|at \\$\\d{3},\\d+|\\s+\\$\\d{3},\\d+, MLS | \\$\\d{3},\\d+</strong>|upper \\$\\d{3},\\d{3}|\\$\\d{3},\\d+</p>", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		
		//U.log(html);
		String[] sqft = U.getSqareFeet(	html+combinedHomeHtmls,
						"open \\d,\\d{3} square feet|\\d,\\d{3} SF| \\d,\\d{3} (of )?Square Feet with|\\d{4} SF, MLS|\\d{1},\\d{3} finished SF|With \\d{1},\\d{3} SF|total of \\d{1},\\d{3} SF|over \\d{1},\\d{3} sq. ft.|<strong>(\\d,\\d{3}-)?\\d,\\d{3}</strong></p>\\s+<p class=\"small\">Square Feet|\\d{4}\\+ sq ft main|\\s+\\d,\\d+ SF\\s+|from \\d,\\d{3}\\s?(–|-)\\s?\\d,\\d{3} (S|s)quare (F|f)eet|over \\d,\\d{3} sq ft|\\d,\\d{3}\\+ SF",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
//================================================community type========================================================
		String communityType=U.getCommType(html);
		
//==========================================================Property Type================================================
		html = html.replace(" luxury main-level living", " luxury living").replace("his craftsman inspired", "Craftsman style details").replace("Introducing Coastal Corner", "coastal-inspired architecture").replace("This craftsman inspired 4 bed and 4.5 bath home", "Craftsman style details").replaceAll("luxury Rehoboth Beach homes|main-level luxury", "luxury homes").replace(" 1st and 2nd Floor Masters", " 1 Story and 2 Story ").replace("ecure your last chance for this classic cottage series ", "").replace("Mud Room on Main Level", "Mud Room on 1 story ");
		String proptype=U.getPropType((html+combinedHomeHtmls+homeProtype).replaceAll("Coastal Designed Chairs|Coastal Highway|G Carriage House|G-Carriage-House-View",""));
		//U.log(html);
//==================================================D-Property Type======================================================
		combinedHomeHtmls = U.removeComments(combinedHomeHtmls);
		html = html.replace("two floors with", " 2 story ");
		String dtype=U.getdCommType((html+combinedHomeHtmls)); //avalHomeHtml
	//	U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(combinedHomeHtmls, "[\\w\\s\\W]{30}third floor[\\w\\s\\W]{30}", 0));
//==============================================Property Status=========================================================
		html = html.replaceAll("Move In Ready", "").replace("Building B is Coming Soon", "Building B Coming Soon")
				.replace("ONLY FOUR open homesites left in phase one", "ONLY FOUR homesites left in phase one")
				.replace("Homesites Are Limited", "Limited Homesites")
				.replace("Coming in Spring of 2022", "Coming Spring 2022")
				.replace("Coming in Summer of 2022", "Coming Summer 2022")
				.replace("first two homes have sold", "first two homes sold")
				.replace("homes are selling fast", "homes selling fast")
				.replace("Coming in Fall of 2021", "Coming Fall 2021").replace("Coming Fall of 2022", "Coming Fall 2022")
				.replace("Coming in Summer of 2021", "Coming Summer 2021")
				.replace("Coming Summer of 2022", "Coming Summer 2022");
		
		
		String headStatus = U.getSectionValue(html, "<h3 class=\"incentive-title\">", "<")+U.getSectionValue(html1, "<section class=\"community-about\"", "</section");
		html = html.replace("Coming Winter of 2022.", "Coming Winter 2022.").replace("ONE SOLD, ONLY ONE AVAILABLE", "ONE SOLD ONLY ONE AVAILABLE").replaceAll("Price: Coming Soon|Pricing: Coming Soon|Buildings are SOLD|Immediate Move|Range is coming|\"Quick|Model Coming This Summer|quick-deliveries-|Model is now|immediate delivery available|coming soon to Longmoor Farms|hese homes are selling fast|Tour the site today! Only TWO homesites remain|wimming pool \\(Coming in 2020\\)|Only One Home Remains|MLS: Coming Soon|Open House Coming Soon|Now Selling: 25D|Coming Soon: 25A|Now Selling: 25B|last chance for this classic cottage series|<p><strong>SOLD|banyan-sold-out|/sold-out/\">Sold Out|title=\"Sold Out\"|our grand opening event|Ready to Move In Now! 3 car|</h4>\\s+<p><strong>C(OMING|oming)|distinctive and limited|now available on Homesite|is move-in ready|Move In Ready Home!|<p><strong>SOLD", "");
		
		String pstatus=U.getPropStatus((html+comSec+headStatus)
				.replaceAll("Pricing: Coming Soon", "")
				.replace("First and Second Buildings are SOLD OUT", "First and Second Buildings SOLD OUT")
				.replace("Homesites Are Limited", "Limited Homesites")
				.replace("Only a few lots remain", "Only few lots remain")
				.replace("Only a few lots remain in Tidal Walk's Final Phase", "Only a few lots remain in Final Phase"));
//			U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+comSec+headStatus, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));

		if(html1.contains(" <h3 class=\"homes-title\">Available Immediate Move")) {
			if(pstatus.length()>4) {
				pstatus=pstatus+", Immediate Move-Ins";
			}else {
				pstatus="Immediate Move-Ins";
			}
		}
		pstatus = pstatus.replace("Only Two Homesites Remain, Only 2 Homesites Remain", "Only Two Homesites Remain");
//============================================note====================================================================
		int quickDeliveryHomeCount = 0;
		String section = U.getSectionValue(html, "Available Quick Deliveries", "Available Floor Plans");
		if(section != null){
			String[] quickHomes = U.getValues(section, "class=\"home\">", "<div");
			quickDeliveryHomeCount = quickHomes.length;
		}
		
		if(quickDeliveryHomeCount > 0){
			if(pstatus != ALLOW_BLANK)pstatus += ", Quick Delivery Homes";
			else pstatus = "Quick Delivery Homes";
		}
		pstatus = pstatus.replace("Sold-out", "Sold Out");
//		if(comUrl.contains("/communities/southpointe/"))pstatus= ALLOW_BLANK;
		html = html.replace("PHASE TWO IS NOW OPEN FOR SALE", "PHASE TWO NOW OPEN FOR SALE");
		
		U.log("OOO"+Util.match(html,"Building F Now Open for Sales"));
		String note=U.getnote(html);
		add[0]=add[0].replace("+", "&").replace(", Suite 2", "");
	//	if(comUrl.contains("https://myevergreenehome.com/communities/lewes-crest/"))pstatus = pstatus.replace("Sold Out,", "First And Second Building Sold Out,");
		
		if(comUrl.contains("https://myevergreenehome.com/communities/oyl-at-lake-anna")) {
			add[1]="Mineral";
			add[2]="VA";
			latLng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLng);
			geo="TRUE";
		}
		if(pstatus.contains("Sold Out,") && pstatus.contains(", Sold Out"))pstatus=pstatus.replace(",Sold Out", "");
		pstatus=pstatus.replace("Homes Are Selling Fast, Selling Fast", "Homes Are Selling Fast");
		
		if(comUrl.contains("https://myevergreenehome.com/communities/preston-lake/"))
			pstatus=pstatus.replace(", Quick Deliveries", "");
		if(comUrl.contains("https://myevergreenehome.com/communities/brewers-crossing/"))
			pstatus=pstatus.replace(", Immediate Move-Ins", "");
		
		
		if(comUrl.contains("https://myevergreenehome.com/communities/hickman-street/"))
			note="Address And Latlong Taken From City And State";
	
		
		
		data.addCommunity(communityName.replaceAll(" Villa$", ""),comUrl, communityType);
		data.addLatitudeLongitude(latLng[0].replace("-", "").trim(), latLng[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1].toLowerCase(), add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus.replace("Sold Out, Sold Out", "Sold Out"));
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
		j++;
		//}catch (Exception e) {}
	}

}