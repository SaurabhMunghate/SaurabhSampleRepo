/** @author Rakesh
 *  @date 20/10/2016
 */
package com.shatam.b_141_160;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKeystoneCustomHomes extends AbstractScrapper {
	
	static int j = 0;
	int k = 0;
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {
//		System.setProperty("webdriver.chrome.driver","/home/glady/chromedriver");
		
		AbstractScrapper a = new ExtractKeystoneCustomHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Keystone Custom Homes.csv", a.data()
				.printAll());
	}

	public ExtractKeystoneCustomHomes() throws Exception {

		super("Keystone Custom Homes", "https://www.keystonecustomhome.com/");
		LOGGER = new CommunityLogger("Keystone Custom Homes");
	}
	
	private WebDriver driver = null;
	private void setProxyForFireFox(){
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		Proxy proxy = new Proxy();
        proxy.setHttpProxy("72.175.68.179:80");
 
      //  capabilities.setCapability("proxy", proxy);
		driver = new FirefoxDriver(capabilities);
		
		
	}
	
	public void innerProcess() throws Exception {
		/*
		 * Set proxy setting for firefox 
		 */
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		
		String base = "https://www.keystonecustomhome.com";
		
		//String Html = U.getHTML("https://www.keystonecustomhome.com/find-your-home-advanced/communities.json");
		
		String Html = U.getHtml("https://www.keystonecustomhome.com/find-your-home/", driver);
		U.log(U.getCache("https://www.keystonecustomhome.com/find-your-home/"));

		
		String[] comSecs = U.getValues(Html, "<div class=\"col-12 mb-3\"><div \"\"=\"\" class=\"card p-1 mb-3 oi-map-item location-card rounded", "</script></div></div>");
		U.log("Total comSecs: "+comSecs.length);
		
		int y = 0;
		for (String item : comSecs) {

			//U.log("item::"+item);
			String comUrl = "https://www.keystonecustomhome.com" + U.getSectionValue(item, "href=\"", "\">");	
			U.log("Count: "+ y +" === comUrl ::"+comUrl);
			
			String html = getHtml(comUrl, driver);
			y ++;
			
//				try { 
						adddetails(item, comUrl, driver); 
//					} catch (Exception e) {}
				

		}
		LOGGER.DisposeLogger();

//		try{driver.quit();}catch (Exception e) {}
	}

	private void adddetails(String item,String comUrl, WebDriver driver) throws Exception {
//		if(j <=10)
//	    if(j >=8)
//		try{
		{
//			TODO ::
//			if(!comUrl.contains("https://www.keystonecustomhome.com/find-your-home/pa/newtown-square/ventry-at-edgmont-preserve/")) return;
	
			U.log("Count ::"+j);
			U.log("item ::"+item);
			
			if(comUrl.contains("https://www.keystonecustomhome.com/north-east-md-chesapeake-bay-golf-club-townhomes"))return;//redirected
			if(comUrl.contains("https://www.keystonecustomhome.com/-stoudtburg-village-townhomes")||comUrl.contains("https://www.youtube.com/embed/jgB3pUABozw"))return; //Error
			if(comUrl.contains("https://www.keystonecustomhome.com/harrisburg-pa-paxton-crossing"))return;//redirect to main page
			if(comUrl.contains("https://youtu.be"))return; //YOUTUBE
			
			U.log(U.getCache(comUrl));
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated-------------" + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			U.log("\nPAGE :" + comUrl);
			String html = getHtml(comUrl, driver);
			
			String forQuickStatus = ALLOW_BLANK;
			if(html.contains("<span class=\"banner position-absolute t-0 popular bg-orange f-12 px-5 py-2 text-white z-1\">Available Now</span>")) {
				
				forQuickStatus = "Quick Present";
			}
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, comUrl, driver);
			U.log("Total Units : "+units);
			// ---------------------------------------------------------
			String note=ALLOW_BLANK;
			
			String rem1=U.getSectionValue(html, "<div id=\"nearby\" class=\"nearby\">", "</body>");
			if(rem1!=null) {
				html=html.replace(rem1, "");
			}
			if (U.getSectionValue(html, "<div class=\"nearby\">", "</body>")!=null)
			html=html.replace(U.getSectionValue(html, "<div class=\"nearby\">", "</body>"), "");
			html=html.replace("<p>Quick Move-Ins</p>", "");
			if(html.contains("<h3>404 ERROR</h3>"))
			{
				LOGGER.AddCommunityUrl("404 ERROR+++++" + comUrl);
				k++;
					return;
			}
			
			String [] rem=U.getValues(html, "__contact-us__contact__info\">", "</path>");
			for(String remSec : rem) {
				if(remSec.contains("<a href=\"/cdn-cgi/l/email")||remSec.contains("<a href=\"tel"))
				html=html.replace(remSec, "");
			}
			String commName = "";
			if(html.contains("<p class=\"community_name\">"))
			{
				commName = U.getSectionValue(html,
						"<p class=\"community_name\">", "</p>");
			}
			else //if(html.contains("<title>"))
			{
				commName = U.getSectionValue(html, "\"name\":\"", "\"");
//				commName = U.getSectionValue(commName, ">", "<");
			}
			
			if(commName == null) commName = U.getSectionValue(html, "<h1 class=\"display-4 fw-bold text-black mb-md-3\">", "</h1>");
			if(commName == null) commName = U.getSectionValue(item, "<div><h5 class=\"loc-name fw-bold f-16 ls-1\">", "</h5>");
			
			if(commName!=null)
				if(commName.endsWith("Townhomes"))commName=commName.replace(" - Townhomes", "");
				if(commName.endsWith(" Manor Homes"))commName=commName.replace(" Manor Homes", "");	
				
			commName=commName.replace("-Traditional", "").replace("Villas", "").replace("Attached", "").replaceAll("Carriage Homes$", "");
			U.log("comname----> "+commName);
			
			String newhtm=html;
			if(html.contains("window.community")) html=html.replace(U.getSectionValue(html, " window.community = {\"", "</script>"), "");
			
			
			if(U.getSectionValue(html, "<div class=\"filters\">", "<label for=\"popular")!=null)
			html=html.replace(U.getSectionValue(html, "<div class=\"filters\">", "<label for=\"popular"), "");
			
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			
			String address=ALLOW_BLANK;
			if(html.contains("class=\"community_address\"") &&
					!(comUrl.contains("https://www.keystonecustomhome.com/-paxton-crossing")|| comUrl.contains("https://www.keystonecustomhome.com/-spring-hill")))
							{
				address = U.getSectionValue(html, "<p class=\"community_address", "</p>").replaceAll("\\n", "<a>");
				U.log(address);
				add[0] = U.getSectionValue(address, "<a>", "<a>");
				address = address.replace(add[0], "");
				U.log(add[0]);
				U.log(address);
				add[1] = U.getSectionValue(address, "<a><a>", "<a>");
				address= address.replace(add[1], "");
				U.log(address);
				
				add[2] = U.getSectionValue(address, "<a><a><a>", "<a>");
				address = address.replace(add[2], "");
				U.log(address);
				add[3] = U.getSectionValue(address, "<a><a><a><a>", "<a>");
				U.log("new address--> "+address);
				add[0] = add[0].replace("<a>", "").trim();
				add[1] = add[1].replace("><a><a><a>", "").trim();
				add[2] = add[2].replace("><a><a><a><a> ", "").trim();
				add[3] = add[3].replace("><a><a><a><a>", "").trim();
				U.log("add0-->"+add[0]);
//				U.log("add1-->"+add[1]);
//				U.log("add2"+add[2]);
//				U.log("add3--> "+add[3]);
			}
			
			String addSec = U.getSectionValue(html,
					"<g id=\"Icons-/-Marker\"",
					"<br>");
			if(addSec==null)addSec=U.getSectionValue(html, "<div class=\"cm__ts__container__address\">", "</div>");
			
			U.log("addSec=======  "+addSec);
			
			if(addSec!=null) {
				String addSec1= U.getSectionValue(addSec, "</span>", "</span>");
				if(addSec1!=null) {
				addSec1=addSec1.replaceAll(", USA", "").replace("EXTD", "extd");
				add=U.getAddress(addSec1);
				}else {
					addSec=addSec.replace("<div>", "-, ");
					add=U.getAddress(addSec);
					U.log(Arrays.toString(add));
				}
			}
			
			U.log("addSec here =======  "+addSec);
			
			//FLOW @1.
			if(addSec == null && html.contains("<a class=\"oi-directions-click\"")) {
				
				U.log("INSIDE FLOW 1 -----------------------------");
				
				String addSection = U.getSectionValue(html, "<a class=\"oi-directions-click", "/a>");
				U.log("addSection inside --- "+addSection);
				
				if(addSection != null) {
					
					String addsec = U.getSectionValue(addSection, "svg?v=bbcb1fa\">", "<");
					U.log("addsec: "+addsec);
					
					add=U.getAddress(addsec);
					U.log("Address flow 1 ======== "+Arrays.toString(add));
				}
			}
			
			//FLOW @2.
			if(addSec == null && add[0] == ALLOW_BLANK) {
				
				U.log("INSIDE FLOW 2 -----------------------------");
				
				String addSection = U.getSectionValue(html, "<h1 class=\"display-4 fw-bold text-black mb-md-3\">", "span>");
				U.log("addSection inside --- "+addSection);
				
				if(addSection == null) addSection = U.getSectionValue(html, "<h1 class=\"display-4 fw-bold mb-md-3\">", "span>");
				U.log("addSection inside here --- "+addSection);
				
				
				if(addSection != null) {
					
					String addsec = U.getSectionValue(addSection, "<span class=\"d-block d-md-inline-block\">", "</");
					U.log("addsec: "+addsec);
					
					//if street address is not given.
					if(addsec.split(",").length == 2) {
						add[0] = ALLOW_BLANK;
						add[1] = addsec.split(",")[0];
						add[2] = Util.match(addSection.split(",")[1], "\\w+");
						add[3] = Util.match(addSection.split(",")[1], "\\d+");
					}
					
					U.log("Address inside === "+Arrays.toString(add));
				} 
					
			}
			
			
			U.log("ADDRESS HERE :- "+Arrays.toString(add));
			
			U.log("ADDRESS add[0] :- "+add[0]);

			add[0]=add[0].replace(", York, PA 17402", "");
			
			add[1]=add[1].replace(",", "");
			
			//------quick Home data-------
			String allQuickhtml = "";
			ArrayList<String> soldCount = new ArrayList<String>();
			String quickhtml=U.getHtml(comUrl+"#quick-move-ins", driver);
			String[] quickurls = U.getValues(quickhtml,"<a rel=\"nofollow\" ng-href=\"", "\"");
			if(quickurls!=null && quickurls.length>0) {
			U.log("total quickurl::::::::::::::::"+quickurls.length);
			for(String quick : quickurls){
				
				String qHtml = U.getHtml("https://www.keystonecustomhome.com"+quick, driver);
				allQuickhtml += U.getSectionValue(qHtml, "<div class=\"for_left_padding\">", "<div id=\"contact-us\"");
				allQuickhtml=allQuickhtml.replace("complete the second floor", "");
			}
			soldCount=Util.matchAll(U.getHtml(comUrl+"#quick-move-ins", driver), "<p class=\"banner\">Sold</p>", 0);
			allQuickhtml=allQuickhtml.replace("second floor"," 2 Story ").replace("first floor", " 1 Story ");
			}
			
			// =============== Floorplans data ==========================
			String floorPlansData = ALLOW_BLANK; String framesData = ALLOW_BLANK;
			
			//String floorHtml = U.getHtml(comUrl+"/#plans", driver);
			
			String[] floorUrls = U.getValues(html, "<div class=\"bg-white rounded-3 p-1 mb-5 border light-blue aos-init aos-animate", "</a></div></div>");
			U.log("total floorUrls::::::::::::::::"+floorUrls.length);
			
			for(String floor:floorUrls) {
				
				String floorurl = "https://www.keystonecustomhome.com/find-your-home" + U.getSectionValue(floor, "href=\"/find-your-home", "\">");
				U.log("floorurl: "+floorurl);
				
				String floorPlanData = U.getHtml(floorurl, driver);
				
				floorPlansData += floorPlanData;
				
				//for getting iframe data in plans
				if(floorPlanData.contains("<iframe src=\"https://myhome.anewgo.com")) {
					String frameUrl = U.getSectionValue(floorPlanData, "<iframe src=\"https://myhome.anewgo.com", "\"");
					frameUrl = "https://myhome.anewgo.com" + frameUrl ;
					U.log("frameUrl: "+frameUrl);
					
					framesData += U.getHtml(frameUrl, driver);
					
				}
			}
			
//			U.log("MMMMM"+Util.matchAll(framesData, "[\\w\\s\\W]{30}traditional[\\w\\s\\W]{30}", 0));
//			U.log("MMMMM"+Util.matchAll(framesData, "[\\w\\s\\W]{30}loft[\\w\\s\\W]{30}", 0));
//			U.log("MMMMM"+Util.matchAll(framesData, "[\\w\\s\\W]{30}farmhouse[\\w\\s\\W]{30}", 0));
			
			html = html.replace("life of luxury", "life of luxury home");
			html = html
					.replaceAll(
							"single family homes' %></li|including the Colonial|Colonial Park Mall|single family homes and  townhomes  in 38 communities|property_type : 'Single Family Homes'|Single Family Homes|Keystone Custom Home",
							"");
			html = html.replaceAll("Augusta Traditional|MOSES TRADITIONAL", "Traditional Home").replace("Keystone Custom Homes", "")
					.replace("floorplan is fully customized to your design", "floorplan is fully custom homes to your design");
			//U.log("item:::::"+item);
			html = html.replace("luxurious, equestrian-inspired community", "luxury home").replace("luxurious community", "luxury homes").replace("Farmhouse</h3>", "Farmhouse-inspired architectura");
			
			String pType = ALLOW_BLANK; 
			
			pType = U.getPropType((html+item+allQuickhtml+framesData+floorPlansData)
					.replace("estate homesites vary from", "")
					.replace("Keystone Custom Homes", "").replaceAll("Ethan English Cottage</h3>|Ethan English Cottage| Elevation - Manor,|, Elevation - Manor, >\n" + 
					"                            Manor|Elevation - Manor, 022", "")+"")
					.replaceAll("\"title\":\"Manor\"|elevationmanor|\"Elevation::Manor\"|Ethan English Cottage|\"name\":\"Ethan English Cottage\"", "");


//			U.log("MMMMM"+Util.matchAll(html+item+allQuickhtml+framesData+floorPlansData, "[\\w\\s\\W]{30}estate[\\w\\s\\W]{30}", 0));
			
			pType = pType.replace("Townhouse,", "");
			
			U.log("pType:::::::::::"+pType);
			
			if (pType == null) {
				pType = ALLOW_BLANK;
			}
			//U.log("::::::::::::::::::::::::::"+U.getSectionValue(html, "https://maps.google.com/maps?ll=", "&amp;z=7"));
			// ----------------lat long---------------
			String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
			String gCode = "TRUE";
			//String gmapLink = Util.match(html,"https://maps.google.com/maps\\?daddr=(.*?)\"", 1);//href="https://maps.google.com/maps?ll=39.958544,-76.783264&amp;z=7&amp;
			String gmapLink = Util.match(html,"ll=(.*?)&amp;z=7&amp;t=m&amp;hl=en-US&amp;gl=US&", 1);
			U.log("gmap: " + gmapLink);
			if(gmapLink!=null){
				latLng = gmapLink.split(",");
				gCode ="FALSE";
			}
			else if(html.contains("https://maps.google.com/maps?daddr=")){
				
				gmapLink = U.getSectionValue(html, "<a href=\"https://maps.google.com/maps?daddr=", "\"");
				U.log("gmap :::::::::::::::::::::: " + gmapLink);
				latLng = gmapLink.split("%2C");
				gCode ="FALSE";
			}
			else if(html.contains("var myLatLng =")) {
				latLng[0]=U.getSectionValue(html, "{lat:", ",");
				latLng[1]=U.getSectionValue(html, "lng:", "}");
				gCode ="FALSE";
			}
			else if(html.contains("https://maps.google.com/maps?ll=")) {
				
				String geoSec = U.getSectionValue(html, "https://maps.google.com/maps?ll=", "&amp;");
				U.log("geoSec ------  "+geoSec);
				
				latLng[0] = geoSec.split(",")[0];
				latLng[1] = geoSec.split(",")[1];
				gCode = "FALSE";
			}
			else if(add[1].length()>3){
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				gCode ="true";
				note="Address Taken From City and State";
			}
			
			U.log("LATLONG HERE: "+Arrays.toString(latLng));
			
			
			if(add[1].length()<3 && latLng[0].length()<4)
			{
				String ss=U.getSectionValue(item,"<h4 class=\"ng-binding\">", "</h4>");
				if(ss!=null) {
					String aa[]=ss.split(",");
					if(aa.length==2)
					{
						add[1]=aa[0];
						add[2]=aa[1];
					}	
				}
			}
			
			if(add[1].length()<3 && latLng[0].length()>4) {
				add=U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				gCode ="true";
			}
			
			if(add[0].length()<3 && latLng[0].length()>4) {
				add=U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				gCode ="true";
			}
			
			U.log("LATLONG: "+Arrays.toString(latLng));
			
			
			// Price
			String returnedCard[]=U.getValues(html, "<div class=\"in-card\">", "View Home Details");
			for(String card:returnedCard) {
				html=html.replace(card, "");
			}
			if(comUrl.contains("/york-pa-penns-preserve"))html=html.replaceAll("<br>\\s*\\$312,412\\s*</h4>", "");
			String maxPrice = ALLOW_BLANK, minPrice = ALLOW_BLANK;
			
			html = html.replaceAll("0's", "0,000s").replaceAll(
					"<span class=\"savings\">[^<]+<", "");
			//U.log("____________"+html);
			
				//html = html.replaceAll("nearby__block__snapshot__price\">\n" +"From The \\$\\d{3},\\d{3}s", "");
				
		//	String html=U.getHTML(comUrl);
			//U.log("=============");
				String expprsec[]=U.getValues(html, "nearby__block__snapshot__price\">", "</div>");
				for(String ads:expprsec) {
					html=html.replaceAll(ads, "");
				}
	
			
			
			String bindings[]=U.getValues(html, "<h3 class=\"ng-binding\">", "</p>");
			for(String ad:bindings) {
				html=html.replace(ad, "");
			}
			//remove nearyby block
			bindings =U.getValues(html, "<div class=\"nearby__block__snapshot\">", "</a>");
			for(String ad:bindings) {
				html=html.replace(ad, "");
			}
			
			
			//REMOVING EXPLORE NEW CONSTRUCTION BLOCK---------------
			if(html.contains("Explore New Construction Homes")) {
				String remSection = U.getSectionValue(html, "Explore New Construction Homes", "</section>");
				//U.log("remSection: "+remSection);
				
				html = html.replace(remSection, "");
				
			}
			
				String[] price = U
					.getPrices(
						html ,
							"text-end\">\\$\\d,\\d{3},\\d{3}</div>|From the \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d+|<div class=\"pricing\">\\$[0-9]{3},[0-9]{3}</div>",
							0);
				
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
			//U.log("MMMMM"+Util.matchAll(html, "[\\w\\s\\W]{30}\\$1,589[\\w\\s\\W]{30}", 0));
			

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String sqft[] = U
					.getSqareFeet(
							html+allQuickhtml,
							"\\d{4} - \\d{4} sqft</span>|Home Sqft: \\d,\\d+|\\d,\\d{3}\\s?-\\s?\\d,\\d{3} sqft|sqft\">Sq Ft: \\d,\\d{3}|\\d{1},\\d{3} - \\d,\\d{3}</snapshot-range>|\\d{4} to \\d{4}\\+ square feet |\\d{1},\\d{3} Sq Ft| starting at \\d,\\d{3} sqft",
							0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			

			String remove = "13 estate homesites now available|Bar and Grille coming soon|Coming Soon Under Construction|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|geolocation is not available|Quick Move-In Homes";
			html = html.replaceAll("MD are move-in ready| Designer Model Home Available Now", "");
			html = html.toLowerCase()
					.replaceAll(remove.toLowerCase(), "");
			html = html.replace("avilable", "available").replace("homesites are now sold out", "homesites now sold out")
					.replaceAll(
					"only one homesite|Only one homesite and", "only one homesite remaining");
			html = html.replace(
					"only 3 homesites in the current phase remain",
					"Only 3 homesites remain");
			html = html.replace("Only one homesite Remain left","Only one homesite left")
					.replace("first phase is now available", "first phase now available");

			
			html = html.toLowerCase().replaceAll(remove.toLowerCase(), "");
			html = html.replaceAll("showoverlay\\('quick-move-in'\\)\">quick move|quick-move-in/| <p>quick move-ins</p>|</svg>\\s+</span>\\s+quick move-in|quick move-in\\s+</span>|miss out on homes now available in the community ", "");

			html = html.replace("move in ready homes", "");
			html=html.replaceAll("only one homesite|Only one homesite and", "only one homesite remaining");
			html=html.replace("available homesites</a>", "").replace("homesites are now sold out", "homesites now sold out");
			html=html.replace("current phase is sold out", "Current phase sold out");
			html=U.removeComments(html);
			html = U.removeSectionValue(html, "<head>", "</head>");
			//U.log(html);
			html=html.replaceAll("quick move|Quick Move", "");
			
			String pStatus = ALLOW_BLANK;
			
			pStatus = U.getPropStatus(html.replace("new phase now openwelcome to devon creek estates", "")
					.replace("new phase open now!welcome to devon creek", "")
					.replaceAll("md is sold out|clubhouse, that is coming soon|md coming soon3|md coming soon!3|family homes in now available, so don't miss| move-in options|homes_count\">quick move-", ""));
			
			
			pStatus = pStatus.replace("Closeout", "Close Out");
			
			U.log("pStatus: "+pStatus);
//			U.log("MMMMM"+Util.matchAll(html, "[\\w\\s\\W]{60}sold out[\\w\\s\\W]{60}", 0));
			
			
			U.log(soldCount.size()+"LLLLLLLLLLL"+ quickurls.length);
			
			//------find quick move-in status
//			if(quickurls.length>0 && !pStatus.contains("Quick") && soldCount.size()<quickurls.length)
			
			if(forQuickStatus.equals("Quick Present")) {
				
				U.log("Quick Present Here -------------------// ");
				
				if(pStatus.length()<4){
					pStatus = "Quick Move-In";
				}
				else{
					pStatus = pStatus+", Quick Move-In";
				}
			}
			
			
			if(commName.endsWith("Manor"))pType=pType+", Manor Homes";

			String dType = ALLOW_BLANK;
			int isRanch =Util.matchAll(newhtm, "\"ranch_plan\":1,",0).size();
			int issecStory=Util.matchAll(newhtm, "\"two_story_great_room\":1",0).size();
			//int isoneStory=Util.matchAll(newhtm, "\"first_floor_owners_suite\":1",0).size();
			//U.log("isRanch"+isRanch);
			//U.log("issecStory"+issecStory);
			//U.log("isoneStory"+isoneStory);

			if(isRanch>=1) {
				html=html+":::::: Ranch";
			}
			if(issecStory>=1) {
				html=html+":::::: 2 story";
			}
//			if(isoneStory>=1) {
//				html=html+":::::: 1 story";
//			}
			html = html.replace("second floor", " 2 Story");

			String floorhtml="";
			String descsec="";
			try {
				String floorurl[]=U.getValues(html, "https://www.keystonecustomhome.com/find-your-home/floorplans", "\"");
				for(String fu:floorurl) {
					floorhtml=U.getHtml("https://www.keystonecustomhome.com/find-your-home/floorplans"+fu,driver);
					descsec+=U.getSectionValue(floorhtml, "wysiwyg ng-pristine ng-untouched ng-valid ta-bind ng-not-empty", "</p>");
				}
			}
			catch(Exception e) {}
			
			
			
			
			dType = U.getdCommType((html+allQuickhtml+descsec).replaceAll("colonial park|Colonial Park|floor|branch|ranch_plan|colonial shopping", ""));
//			U.log("MMMMM"+Util.matchAll(html+allQuickhtml+descsec, "[\\w\\s\\W]{30}colonial[\\w\\s\\W]{30}", 0));

			String lati[] = { ALLOW_BLANK, ALLOW_BLANK };
			if (lati[0] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(lati);
				if(add == null) add = U.getAddressHereApi(lati);
			}
//			html = U.getHTML(comUrl);
			
			
			add[0]=add[0].replace(".","").replace("&amp;", "&").replace(", Westminster, MD 21157", "");
			if(add[0].length()<4){
				add[0] = ALLOW_BLANK;
				add[1] = ALLOW_BLANK;
				add[2] = ALLOW_BLANK;
				add[2] = ALLOW_BLANK;
				
			}
			add[0]=add[0].replace("5125 N George Street Extended","5125 N George Street Extension");
			if(latLng[0].length()<4){
				latLng[0] = ALLOW_BLANK;
				latLng[1] = ALLOW_BLANK;
				
			}
			if(comUrl.contains("https://www.keystonecustomhome.com/find-your-home/md/woodstock/the-preserve-at-marriotts-ridge")) {
				add[0]="1811 Woodstock Rd";
				add[1]="Woodstock";
				add[2]="MD";
				add[3]="21163";
				latLng[0] ="39.32126430";
			    latLng[1]="-76.87868480";
			    gCode="FALSE";
				
			}
			
			
			if(comUrl.contains("shrewsbury/hamiltons-overlook"))note="New Homes For Sale";
			if(comUrl.contains("/pa/lancaster/devon-creek-singles") || comUrl.contains("/pa/dover/palomino-heights"))dType = "2 Story";
//			if(comUrl.contains("https://www.keystonecustomhome.com/find-your-home/md/frederick/kellerton-townhomes"))maxPrice="$310,000";
			String communityType = U.getCommunityType(html);
			
			
			
//			if(comUrl.contains("https://www.keystonecustomhome.com/find-your-home/pa/stewartstown/cloverfield-farms")) {
//				pType="Manor Homes";
//			}
if(comUrl.contains("https://www.keystonecustomhome.com/find-your-home/pa/new-freedom/koller-pointe")) {
	pType=pType+", Manor Homes";
			}
//			
		
//			pStatus=ALLOW_BLANK;
			U.log("add[0]=="+add[0]+"add[1]=="+add[1]+"add[2]=="+add[2]+"add[3]=="+add[3]);
//			if(comUrl.contains("https://www.keystonecustomhome.com/find-your-home/pa/elizabethtown/bishop-woods/"))pStatus="Quick Move-Ins";
						
			data.addCommunity(commName.toLowerCase(), comUrl, communityType);
			data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), gCode);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);

		}
		j++;
//		}catch(Exception e) {}
	}

	public static String[] getlatlongGoogleApi(String addr) throws IOException {

		addr = "https://maps.googleapis.com/maps/api/geocode/json?address="// 1138
																			// Waterlyn
																			// Drive","Clayton","NC
				// + URLEncoder.encode(addr, "UTF-8");
				+ addr;
		U.log(addr);
		String html = U.getHTML(addr);

		String str = Util.match(html, "\"short_name\" : \"FL\"");
		U.log("state: " + str);

		String lat = U.getSectionValue(html, "\"lat\" :", ",");
		String lng = U.getSectionValue(html, "\"lng\" :", "}");
		String latlng[] = { lat, lng };
		U.log(lat);
		return latlng;
	}

	public static ArrayList<String> matchAll(String html, String expression,
			int groupNum) {

		Matcher m = Pattern.compile(expression, Pattern.DOTALL).matcher(html);

		ArrayList<String> list = new ArrayList<String>();

		while (m.find()) {

			list.add(m.group(groupNum).trim());
		}
		return list;
		
	}

	public static String match(String txt, String findPattern) {

		Matcher m = Pattern.compile(findPattern, Pattern.DOTALL).matcher(txt);
		while (m.find()) {
			String val = txt.substring(m.start(), m.end());
			val = val.trim();

			val = val.replaceAll("\\s+", " ").trim();
			return m.group();
		}
		return null;
	}// match

	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					/*driver.manage()
							.addCookie(
									new Cookie("visid_incap_612201",
											"gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"));*/
					driver.get(url);
					Thread.sleep(4000); //*[@id="microsite-menu-tabs"]/ul/li[2]/a
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,700)", ""); // y value '400' can
					
					
					Thread.sleep(3000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					U.log("Current URL:::" + driver.getCurrentUrl());
					if(!driver.getCurrentUrl().contains("quick")||!driver.getCurrentUrl().contains("find")){
					//------------tab-click--------
					if(html.contains("More Plans")) {
					WebElement tab = driver.findElement(By.xpath("//*[@id=\"tab-plans\"]/div/div/div[3]/button"));
					tab.click();
					Thread.sleep(5000);
					html += driver.getPageSource();
					}
//					//-------floorplansection---------
					int homelen=Util.matchAll(html, "openHomePlansModal", 0).size()/2;
//					try {
					U.log(homelen);
					if(!html.contains("More Plans")) 
						homelen=Util.matchAll(html, "openHomePlansModal", 0).size();
					for(int i=1;i<=homelen;i++){
						try {
						
						WebElement input = driver.findElement(By.xpath("//*[@id=\"tab-plans\"]/div/div/div[2]/article["+i+"]/div[3]/a[2]"));
						input.click();					//*[@id="home-models"]/div/div[2]/div/div[31]/div/div/div/div[2]/a
						U.log("::::::::::::::::::::click successfull");
						
						Thread.sleep(2000);
						String section=driver.getPageSource();
						String home=U.getSectionValue(section, "<div class=\"modal-content\"", "<!-- ./modal-body -->");
						html+=home;
						Thread.sleep(2000);
						WebElement close=driver.findElement(By.xpath("/html/body/div[1]/div/div/div/a"));
						close.click();
						}catch (Exception e) {
							// TODO: handle exception
						}
						Thread.sleep(2000);
					}
//					}
//					catch(Exception e) {}
//					String sec1[]=U.getValues(html, "<article class=\"cm__plan-card ng-scope\"", "<div class=\"arrow-right\">");
//					U.log(sec1.length);
					
					}
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("<span class=\"map__title\">Site Plan</span>")) {
			
			ArrayList<String> pins = Util.matchAll(html, "<div class=\"pin lot", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());
		}
		
		return totalUnits;
	}
	
	
}