/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_141_160;

import java.io.IOException;
import java.util.Arrays;

import org.apache.http.conn.ssl.AllowAllHostnameVerifier;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractParkSquareHomes extends AbstractScrapper{

	static CommunityLogger LOGGER;
	static int count =1;
	int j=0;
	public ExtractParkSquareHomes()
			throws Exception {
		super("Park Square Homes","https://www.parksquarehomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Park Square Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractParkSquareHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Park Square Homes.csv", a.data().printAll());
		LOGGER.DisposeLogger();

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.parksquarehomes.com/where-we-build/all-communities/");
		String[] comSec=U.getValues(mainHtml,"data-event-code=\"COMR", "View Details");
		U.log("Total Community--->"+comSec.length);
		for(String comm:comSec)
		{
//			U.log("count -->"+count);
			comm=U.removeComments(comm);
			String url1=U.getSectionValue(comm, "<a href=\"","\"");
//			U.log(comm);
//			U.log("Url-->"+url1);
//			if(count>15)
	/*		if(url1.contains("mirabay")) {
				String mainHtm = U.getHTML("https://www.parksquarehomes.com"+url1);
				
				String subUrls[] = U.getValues(mainHtm, "class=\"callout standardTextCalloutoneColumnCallout row2", "class=\"calloutLinkStyles bdxApiLogEventInformation\">");
				for(String url:subUrls) {
					String comUrl = U.getSectionValue(url, " <a href=\"", "\"");
//					U.log(comUrl);
					addCommunity(comUrl,url.replace("<p><a id=\"MIRABAY\"></a> </p>", ""));
				}
			}*/
			//else {
				addCommunity("https://www.parksquarehomes.com"+url1,comm);
			//}
			count++;
		}
	}

	private void addCommunity(String comUrl, String oldData) throws Exception {
		//TODO : For Single Community Execution
//		if(!comUrl.contains("https://www.parksquarehomes.com/where-we-build/all-communities/tarpon-bay/"))return;
		//try {
		
			String html=U.getHTML(comUrl);
			//
			U.log("count:::::::"+j+"\n"+"comUrl---->"+comUrl);
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			//============================================note====================================================================
			html = U.removeSectionValue(html, "<head>", "</head>");
			String note=U.getnote(html+oldData);
//			U.log(">>>>>>>>oldData   "+oldData);
			//============================================Community name=======================================================================
			String section=U.getSectionValue(html,"<section id=\"info\">","</section>");
		//	U.log(section);
			String communityName=U.getSectionValue(oldData, "data-community-name=\"","\"");
			if(communityName== null)communityName=U.getSectionValue(oldData, "<h2>","<");
			if(communityName!=null)communityName= communityName.replaceAll("Resort &amp; Club|Resort Phase II|1.", "").replace(" at Mirabay", "").replace(" &#82; Final Opportunities", "");
			if(communityName.endsWith(" Townhomes"))communityName = communityName.replace(" Townhomes", "").replace("iii", "III");
			
			communityName = communityName.replaceAll("Phase III", "")
					.replace("Sonoma Resort", "Sonoma");
					
			U.log("community Name---->"+communityName);
			
	//================================================Address section===================================================================
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String addSec=U.getSectionValue(html, "  class=\"gaBDXClickTracking bdxApiLogEventInformation \">", "</div>");
			addSec=addSec.replace("Currently no onsite sales office", "");
			U.log("addSec: "+addSec);
			if(addSec!=null) {
				add[0]=U.getSectionValue(addSec, "<span class=\"addressStreet\">","</span>");
				add[1]=U.getSectionValue(addSec, "<span class=\"addressCity\">","</span>");
				add[2]=U.getSectionValue(addSec, "<span class=\"addressState\">","</span>");
				add[3]=U.getSectionValue(addSec, "<span class=\"addressZipCode\">","</span>");
			}
			if(addSec!=null && (add[0]==null || add[0].length()<3)) {
				add[0]=U.getSectionValue(oldData, "<span class=\"addressStreet\">","</span>");
				add[1]=U.getSectionValue(oldData, "<span class=\"addressCity\">","</span>");
				add[2]=U.getSectionValue(oldData, "<span class=\"addressState\">","</span>");
				add[3]=U.getSectionValue(oldData, "<span class=\"addressZipCode\">","</span>");
			}
			
			if(oldData.contains("item description addressInfo")) {
				add[0]=U.getSectionValue(oldData, "<span class=\"addressStreet\">","</span>");
				add[1]=U.getSectionValue(oldData, "<span itemprop=\"addressLocality\">","</span>");
				add[2]=U.getSectionValue(oldData, "<span itemprop=\"addressRegion\">","</span>");
				add[3]=U.getSectionValue(oldData, "<span itemprop=\"postalCode\">","</span>");
			}
		//	if(add[0].contains("Currently no onsite sales office"))add[0]=ALLOW_BLANK;
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			
		if(oldData.contains("data-latitude=\"")) {
			latlag[0]=U.getSectionValue(oldData, "data-latitude=\"", "\"");
			latlag[1]=U.getSectionValue(oldData, "data-longitude=\"", "\"");	
		}
		if(latlag[0]==ALLOW_BLANK && html.contains("Latitude:</span>")) {
			latlag[0]=U.getSectionValue(html, "Latitude:</span> ", "</span>");
			latlag[1]=U.getSectionValue(html, "Longitude:</span> ", "</span>");
		}
		U.log("latlag---->"+latlag[0]+" "+latlag[1]);
		if(addSec!=null) {
			add[0]=U.getSectionValue(addSec, "<span class=\"addressStreet\">","</span>");
			add[1]=U.getSectionValue(addSec, "<span class=\"addressCity\">","</span>");
			add[2]=U.getSectionValue(addSec, "<span class=\"addressState\">","</span>");
			add[3]=U.getSectionValue(addSec, "<span class=\"addressZipCode\">","</span>");
		}
//		U.log(add[0]);
		if(add[0]!=null)add[0]=add[0].replace("At this time, NO Sales Office Onsite", "")
				.replaceAll("Currently no onsite sales center. |By Appointment Only(!)?|No sales office onsite at this time", "");
		if(add[0]==null)add[0]=ALLOW_BLANK;
		add[0]=add[0].replaceAll(add[1]+"|"+add[2], "");
		if((add[0]==null||add[0]==ALLOW_BLANK||add[0].length() < 2) && latlag[0].length() >2 ){
			U.log("Hello in here>>>>>>");
			String tempAdd[]=U.getAddressGoogleApi(latlag);
			if(tempAdd==null)tempAdd=U.getGoogleAddressWithKey(latlag);
			add[0]=tempAdd[0];
			geo="True";
		}

	//------------------fetching Price from Available Home Url --	"https://www.parksquarehomes.com/homes/"	============
			String availPriceSec = ALLOW_BLANK;
			int homeCount = 0;
			
			String[] comAvailSection = U.getValues(html, "data-event-code=\"COMHR\"", "View Details");
			U.log("ffffffffff"+comAvailSection.length);
			
			for(String comAvailSec : comAvailSection){
					String hUrl=U.getSectionValue(comAvailSec, "<a href=\"","\">");
					U.log(hUrl);
					String homeData=U.getHTML("https://www.parksquarehomes.com"+hUrl);
					availPriceSec += homeData;
					homeCount++;
			}
			
	//============================================Price and SQ.FT======================================================================
			
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			html=html.replaceAll(" <span class=\"previousPrice\">\\$\\d{3},\\d{3}</span>", "").replace(" High 200's!", "High $200,000").replace("\\$200�s","$200,000").replace(" MID 200s ", "$200,000").replace("HIGH 300s", "HIGH $300,000");
			html=html.replaceAll("0�sDavenport|0's|0s","0,000");
			oldData = oldData.replace("From $1.2M+", "From $1,200,000").replace("&#8217;s", "'s").replaceAll("0s|0's", "0,000").replace("HIGH ", "HIGH $").replaceAll("\\s+million", ",000,000");
			availPriceSec = availPriceSec.replaceAll("Was \\$\\d+,\\d+|Before \\$\\d+,\\d+", "");
			
//			U.log(oldData);
//			U.log(Util.matchAll((html+oldData+availPriceSec),"[\\w\\s\\W]{100}\\$275[\\w\\s\\W]{50}",0));
			String prices[] = U.getPrices((html+oldData+availPriceSec).replaceAll("Lot Premium: \\$\\d{3},\\d{3}|class=\"previousPrice\">\\s*\\$\\d{3},\\d{3}",""),"From \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|over \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|\\$\\d{3},\\d+|the low \\$\\d+,\\d+|HIGH \\$\\d+,\\d+", 0);
			//U.log(Util.matchAll(html+oldData, "\\d{3},\\d{3}", 0));
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Price--->"+minPrice+" "+maxPrice);
			
	//======================================================Sq.ft===========================================================================================		
			
			html = html.replace("sq. ft.", "sq ft").replace("sq.ft.", "sq ft");
			String[] sqft = U
					.getSqareFeet(
							(html+availPriceSec+oldData).replaceAll("over \\d,\\d{3} square feet of living space", ""),
							"\\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3} – \\d,\\d{3} sq ft|\\d,\\d{3} - \\d,\\d{3} sq ft.|from \\d,\\d{3} - \\d,\\d{3} sq ft|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|from\\d,\\d{3} - \\d,\\d{3} sq ft|from \\d,\\d{3} sq ft - \\d,\\d{3} sq ft|\\d,\\d{3} Sq\\. Ft|from \\d,\\d{3} sq ft to \\d,\\d{3} sq ft|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|\\d,\\d+ square|\\d,\\d+ Sq. Ft|\\d,\\d+ sq. ft|model-feet\">\\d,\\d+|model-feet\">\\d{4}",
							0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//			U.log(Util.matchAll((html),"[\\w\\s\\W]{30}2,211[\\w\\s\\W]{30}",0));

	//=====================Fetching plan Data====================
			String allPlanData=ALLOW_BLANK;
			String[] planUrls = U.getValues(html, "<li class=\"model-image open-house\"><a href=\"", "\"");
			
			for(String planUrl : planUrls){
				//U.log("planUrl:::::::::"+planUrl);
				String planHtml=U.getHTML(planUrl);
				allPlanData=U.getSectionValue(planHtml, "<section id=\"info\">", "</section>")+allPlanData;
				allPlanData=allPlanData.replaceAll("luxurious master bath|luxurious master bath| luxurious bath", "").replace("the second floor just ", "the 2 story just ");
			}
			
			//U.log(oldData);
	//================================================community type========================================================
			html = html.replaceAll("The Lakeside pools|beautiful waterfront views|waterfront MiraBay", "beautiful waterfront community");
					
			String communityType=U.getCommType(html+oldData);
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}water[\\w\\s\\W]{30}", 0));

	//==========================================================Property Type================================================
			html = html.replace("ideal luxury destination", "luxury home").replace("luxurious resort-style", "luxurious homes resort-style").replace("luxurious interior", "luxurious homes")
					.replace("coastal architecture", "coastal-style homes architecture");
			html = html.replaceAll("resort-style pool| lower than most apartments|hoa\">Homeowners|hoa/\">Homeowners|<p>Homes Available|homes\">Homes Available|Villa Gr|Arizona Luxury Homes", "");
			availPriceSec=availPriceSec.replace("resort-style pool", "");
			html=html.replace(" many custom options for you to select from to accommodate your family", " many Custom homes options for you to select from to accommodate your family");
			
			String proptype=U.getPropType((html+allPlanData+availPriceSec+oldData).replace("Paired Villa Floorplan Brochure", "").replaceAll("resort-style pools", ""));
//			U.log("mmmmmm"+Util.matchAll(html+allPlanData, "[\\w\\s\\W]{50}Paired[\\w\\s\\W]{50}", 0));
//			U.log("mmmmmm"+Util.matchAll(availPriceSec+oldData, "[\\w\\s\\W]{50}Paired[\\w\\s\\W]{50}", 0));

	//==================================================D-Property Type======================================================
			html = html.replaceAll("footerAnchorBackgroundColor|fishhawk-ranch|rAnchor|FishHawk Ranch|Colonial Town Park|FishHawk Ranch", "");
//			U.log("mmmmmm"+Util.matchAll(html+oldData, "[\\w\\s\\W]{50}ranch[\\w\\s\\W]{50}", 0));
//			U.log("mmmmmm"+Util.matchAll(availPriceSec+allPlanData, "[\\w\\s\\W]{50}ranch[\\w\\s\\W]{50}", 0));
			String dtype=U.getdCommType((html+oldData+availPriceSec+allPlanData).replaceAll("personalizationRegisterAnchor|footerAnchor|floor|Floor| On the first level", "").replace("one and two story", " 1 Story  2 Story "));
			
	//==============================================Property Status=========================================================
			html =html.replaceAll("now open for the remaining|description marketingDescription\">\n\\s*COMING SOON!|description marketingDescription\">\n\\s*SOLD OUT|Move-in| marketingDescription\">\\s*Coming Soon!|<h2 style=\"text-align: center;\">Coming Soon!</h2>\\s*</div>\n\\s*</div>\n\\s*<span class=\"calloutLink calloutLinkToCenter\">|officeHours \">COMING SOON|Models coming August|Models are now|Models opening early 2021|ready homes available!\" />|content=\"Coming Soon|\"Coming Soon|Now selling from The Markham|Models coming early 2020|Coming Soon - Join our interest list today|<li>Coming Soon!</li>|alt=\"Move-In Ready|Final Opportunity!</a></li>|Quick Move-In Homes</a>", "");
			
//			oldData = oldData.replace("Phase II - Grand Opening", "Phase II Grand Opening");
			
			String pstatus=ALLOW_BLANK;
			oldData=oldData.replaceAll("closeout.png", "");
//			U.log("mmmmmm11"+Util.matchAll(html, "[\\w\\s\\W]{50}coming late 2022[\\w\\s\\W]{50}", 0));
			pstatus = U.getPropStatus((html+oldData)
					.replaceAll("Quick Move-In|Quick Move-in|quick move-in", "")
					.replace("(coming soon), with appointed", "")
					.replaceAll("Lot #\\d+ - Coming Late 2022", "").replace("Phase II now open! Tarpon Bay", ""));
			
			pstatus = pstatus.replaceAll(",Homes Available Now|Homes Available Now,", "");
			String allAvailHomesMainPage=U.getHTML("https://www.parksquarehomes.com/available-homes/");
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]Quick Move[\\w\\s\\W]{50}", 0));
//			U.log("mmmmmm"+Util.matchAll(oldData, "[\\w\\s\\W]Now Open[\\w\\s\\W]{50}", 0));
//			pstatus=pstatus.replace("", newChar)
			U.log(pstatus);
			int q=0;
			String quickSec=U.getSectionValue(html, "<div id=\"qmisJumpLocation\"", "</ul>");
			if(quickSec!=null) {
			String[] quickData=U.getValues(quickSec, "<div class=\"listingHeader\">", "View Details");
			if(quickData.length>0) {
				for(String quick_Data :quickData) {
					String imp=U.getSectionValue(quick_Data, " <h4 class=\"availabiltyDate \">", "</h4>");
//					U.log("imp=="+imp);
//					U.log("imp=="+imp.length());
					if(imp.length()==0) {
						q++;
					}
				}
			}
			}
			U.log("Quick Count=="+q);
			
			//Status from "Homes Available Now" page --https://www.parksquarehomes.com/homes/
			if(homeCount >=1  && html.contains("  <li><a href=\"javascript:void(0);\" class=\"qmis\">Homes Available Now</a></li>")){
				if(pstatus.length()>4 && !pstatus.contains("Homes Available")){
					pstatus = pstatus + ", Homes Available Now";
				}
				else
				{
					pstatus = "Homes Available Now";
				}
			}
			
//			if(html.contains("qmis\">Quick Move-In") && !pstatus.contains("Quick")) {
			if(q>0) {

				if(pstatus.length()>4){
					pstatus = pstatus + ", Quick Move-in";
				}
				else
				{
					pstatus = "Quick Move-in";
				}
			}
			add[0] = U.getCapitalise(add[0].toLowerCase());
			/////////////////////////////////////Image Status/////////////////////////////////////
			
			
			//below are status from reg page com comsec img
			if(comUrl.contains("/sawgrass-landing-orlando/") || comUrl.contains("/victoria-woods-at-providence-2/")){
				if(pstatus.length()<2)pstatus="Now Selling";
				else pstatus=pstatus+", Now Selling";
			}
			
			if(comUrl.contains("crofton-springs-at-providence-davenport/")||comUrl.contains("/ambergate/")){
				if(pstatus.length()<2)pstatus="Closeout";
				else pstatus=pstatus+", Closeout";//reg page img
			}
				
			if(comUrl.contains("/goldenrod-reserve-orlando/")){
				if(pstatus.length()<2)pstatus="Final Opportunities";
				else pstatus=pstatus+", Final Opportunities";
			}
//			if(comUrl.contains("/sonoma-resort/")){
//				if(pstatus.length()<2)pstatus="Sold Out";
//				else pstatus=pstatus+", Sold Out";
//			}
			
			
			
			
//			
			if(pstatus.contains("Community Closeout, Homes Available Now"))pstatus=pstatus.replaceAll("Community Closeout", "Closeout");
			if(pstatus.length()<1){
				pstatus=ALLOW_BLANK;
			}
			if(comUrl.contains("/where-we-build/all-communities/north-river-ranch/")) {
				if(pstatus.length()<2)pstatus="Opening This Summer";
			}
			if(comUrl.contains("ravenna-townhomes/") 
					||comUrl.contains("/communities/compass-landing/")){
				note="Now Pre-Selling";//Image
			}
			if(comUrl.contains("https://www.parksquarehomes.com/where-we-build/all-communities/shell-cove-at-mirabay/")) {
				communityType+=", Waterfront Community";
			}
			//note = U.getnote(html);
			
			
			//U.log("MMM "+communityName);
//			if()
			
			add[0] = add[0].replace("&amp;", "&");
			add[1]=add[1].replace(",", "");
			
//			if(comUrl.contains("https://www.parksquarehomes.com/where-we-build/all-communities/tarpon-bay/")) pstatus=pstatus+", Phase II Now Open";
			
			///////////////////////////////////End///////////////////////////
			if(data.communityUrlExists(comUrl))return;
				data.addCommunity(communityName,comUrl, communityType);
				data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].replace("By Appointment Only! ", "").replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(proptype, dtype);
				data.addPropertyStatus(pstatus.replace("Ii", "II"));
				data.addNotes(note);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(ALLOW_BLANK);
			j++;
		//}catch (Exception e) {}
		
	}

}
