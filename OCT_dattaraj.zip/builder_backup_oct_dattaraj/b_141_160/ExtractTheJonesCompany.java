/** @author Rakesh Chaudhari
 *  @date 29 Jun 2014s
 */

package com.shatam.b_141_160;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import org.apache.commons.lang.StringEscapeUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTheJonesCompany extends AbstractScrapper {
	HashMap<String, String>hm=new HashMap<>();
	int i = 1;
	public int inr = 0;
	static int duplicates = 0;
	static int j=0;
	CommunityLogger LOGGER;


	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractTheJonesCompany();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Jones Company.csv", a.data().printAll());
		// U.log(duplicates);
	}

	public ExtractTheJonesCompany() throws Exception {

		super("Jones Company", "https://www.livejones.com");
		LOGGER=new CommunityLogger("Jones Company");

	}

	public void innerProcess() throws Exception {

		String html = U.getHTML("https://livejones.com/where-we-build/");
		
		String communities[] = U.getValues(html," class=\"community-listing\"", "</li>");

		int totalComm = communities.length;

		U.log("Total Community Count: " + totalComm);
		int c=0;
		String comUrlSec=U.getSectionValue(html, "data-communities='", "' class=\"map\">");
//		for (String communitie : communities) {
//			
//			addDetails(communitie);
//		}
//		addDetails("<li><a class=\"fa fa-\" href=\"https://livejones.com/campaigns/annecy/\">[Coming Soon] Annecy</a></li>");
//		addDetails("<li><a class=\"fa fa-\" href=\"https://livejones.com/campaigns/terra-vista/\">[Coming Soon] Terra Vista</a></li>");
		
		JsonParser parser = new JsonParser();
		JsonArray jsonArray = (JsonArray) parser.parse(comUrlSec).getAsJsonArray();
		
		for(JsonElement json : jsonArray) {
			
			String comUrl = json.getAsJsonObject().get("permalink").getAsString().toString();
			String comName = json.getAsJsonObject().get("post_name").getAsString().toString();
			U.log(comUrl+"\t"+comName);
			addDetails(comUrl,comName,json);
			
		}
		
//		String[] comurls=U.getValues(comUrlSec, "\"permalink\":\"", "\"");
//		String latlngSecs = U.getSectionValue(html, "var $communities = \"[", "]\"");
//		String[] arr = U.getValues(latlngSecs, "{", "}");
//		String[] latlngUrl= {};
//		for(String latlngSec:arr){
//			latlngSec = StringEscapeUtils.unescapeJava(latlngSec);
////			U.log("Upper-latlngSec:: "+latlngSec);
//			latlngUrl = latlngSec.split(",");
//			
//			String keySec=U.getSectionValue(latlngUrl[0],"\"title\":\"","\"");
////			U.log(keySec);
//			String valSec = latlngSec;
//			hm.put(keySec, valSec);
////			String keySec = latlngUrl[4].replace("\"", "");
//		}
//		for(String cUrl:comurls) {
//				String cName=U.getSectionValue(cUrl, ">", "<");
//				cName=cName.replace("[Coming Soon] ", "");
//				cUrl=U.getSectionValue(cUrl, "\"", "\"");
////				U.log("cUrl: "+cUrl+" cName: "+cName);
////				for (String communitie : communities) {
////					c++;
//					
//		//			U.log(c+" commm::::"+communitie);
//					addDetails(cUrl,cName,html);
////				}
//		}

		LOGGER.DisposeLogger();
	}

	private void addDetails(String cUrl,String commName,JsonElement json) throws Exception {
		//TODO :
//		if(j>=3)
		
		{
			String communityUrl =cUrl;
//		if(!communityUrl.contains("https://livejones.com/communities/river-oaks/")) return;

		{
			String html1 = "";

			String geo = "FALSE";

			U.log("------------"+j+"------------"
					+ communityUrl);// System.exit(0);
			if (communityUrl.contains("/where-we-build/"))
				return;
			
			if (this.data.communityUrlExists(communityUrl))
			{
				LOGGER.AddCommunityUrl(communityUrl+"----------------> Repeated");
				i++;
				return;
			}
			LOGGER.AddCommunityUrl(communityUrl);

			html1 = U.getHTML(communityUrl);
			
//			U.log("<<<<<<<<< "+Util.matc0hAll(html1 , "[\\s\\w\\W]{50}571[\\s\\w\\W]{30}",0));

			String type = U.getCommunityType(html1);

//			String communityName = U.getSectionValue(html1, "\" data-title=\"", "\"");
//			communityName = communityName.replace("&#8217;s", "").replace("Coming Soon &#8211;", "");
			String communityName =commName;
			U.log("communityName :" + communityName);
			U.log("URL :" + communityUrl);// U.log(communityName);
			
			// LatLong
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
//			U.log(communitie);
			
			
			String latsec=U.getSectionValue(html1, "//maps.google.com/?q=", "\"");
			U.log("latsec:: "+latsec);
			
			String communitie=ALLOW_BLANK;
			commName=commName.trim();
			lat = json.getAsJsonObject().get("latitude").getAsString().toString();
			lng = json.getAsJsonObject().get("longitude").getAsString().toString();
			U.log(lat + ":::::" + lng);
			
//			U.log("latlong : "+lat+"  "+lng);
//			if(latsec!=null)
//			{
//				if(latsec.contains(",")){
//				String[] latlng=latsec.split(",");
//				lat=latlng[0];
//				lng=latlng[1];
//				}
//			}
//			else{
//				if(communitie.contains("maps.google.com")) {
//				//----------Fetching latlng from main page----------------
//				latsec = U.getSectionValue(communitie, "<a href=\"//maps.google.com/?q=", "\"");
//				String[] latlng=latsec.split("%2C\\+");
//				lat=latlng[0];
//				lng=latlng[1];
//			}
//			}
		
//			U.log(lat + ":::::" + lng);
			String note=ALLOW_BLANK;
			note=U.getnote(html1.replaceAll("When Pre-Selling begins", ""));
			// Address
			String add[] = new String[] { ALLOW_BLANK, ALLOW_BLANK,	ALLOW_BLANK, ALLOW_BLANK };
			
			// Address Here...
			if(communityUrl.contains("/campaigns/")) {
				String addrs=U.getSectionValue(html1, "style=\"font-family: Lato; font-size: 36px; color: #48494d; line-height: 40px;\">Discover", ".<br />");
				add[1]=U.getSectionValue(addrs, "in ", ",");
				add[2]="TN";
				String latlng[] = U.getlatlongGoogleApi(add);
				lat = latlng[0];
				lng = latlng[1];
				add=U.getAddressGoogleApi(latlng);
				geo="true";
				note ="Address Latlng Taken From City & State";
			}
			
//			if(communityUrl.contains("https://livejones.com/campaigns/annecy/")) {
//				add[1]="Nolensville";
//				add[2]="TN";
//				String latlng[] = U.getlatlongGoogleApi(add);
//				lat = latlng[0];
//				lng = latlng[1];
//				add=U.getAddressGoogleApi(latlng);
//				note ="Address Latlng Taken From City & State";
//				geo = "TRUE";
//			}
//			
//			if(communityUrl.contains("https://livejones.com/campaigns/terra-vista/")) {
//				add[1]="Franklin";
//				add[2]="TN";
//				String latlng[] = U.getlatlongGoogleApi(add);
//				lat = latlng[0];
//				lng = latlng[1];
//				add=U.getAddressGoogleApi(latlng);
//				note ="Address Latlng Taken From City & State";
//				geo = "TRUE";
//			}
//			
			String secAddress = U.getSectionValue(html1, "<div class=\"map-info\">","</h4>")+"</a>";
			U.log("address sec is"+secAddress);
			if (secAddress != null && !secAddress.contains("null</a>")) {
				secAddress = U.getSectionValue(secAddress,	"<h4>", "</a>");
				secAddress = secAddress.replace("<br/>", ",").replaceAll("&nbsp;|</a>", "");
				U.log(secAddress);
				add = U.getAddress(secAddress);
				U.log(Arrays.toString(add));
			}

			if (add == null) {
				add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,	ALLOW_BLANK };
			}

			if (add[0] == ALLOW_BLANK && lat.length()>4) {
				add = U.getAddressGoogleApi(new String[] { lat, lng });
				if(add == null) add = U.getAddressHereApi(new String[] { lat, lng });
				geo = "TRUE";
			}
	
			if (lat == ALLOW_BLANK  && add[0].length()>4) {
				String latlng[] = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				lat = latlng[0];
				lng = latlng[1];
				geo = "TRUE";
			}
			
			
			
			//-----------------------Other Pages----------------
			String floorPlansUrl = communityUrl + "floorplans/";
			String quickUrl = communityUrl + "quick-move-in-homes/";
		//	String quickUrl ="https://livejones.com/new-homes/quick-move-in-homes/";
			U.log("quick===" + quickUrl);
            String modelHomes=communityUrl+"model-homes/";
			String collectionsUrl = communityUrl+"collections/";
			// avaHomeUrl = avaHomeUrl.replace(" ", "%20");

			U.log("Floor Plan :" + floorPlansUrl);
			//U.log("quick===" + quickUrl);
			// U.log("avaHomeUrl :" + avaHomeUrl);
			String floorPlansHtml = U.getHTML(floorPlansUrl);
			String quickHtml = U.getHTML(quickUrl);
            String modelHtml=U.getHTML(modelHomes);
            String collectionHtml = U.getHTML(collectionsUrl);
            String collectionDetails=ALLOW_BLANK;
            
            String[] floorData = U.getValues(html1, "<a href=\"https://livejones.com/new-homes/plans", "\"");
            for(String floor : floorData)
            	try {
					floorPlansHtml += U.getSectionValue(U.getHTML("https://livejones.com/new-homes/plans"+floor), "<h3>Floorplan Details</h3>", "<h4>Neighborhood:</h4>");
				} catch (Exception e) {
					// TODO: handle exception
				}
            
            String[] collectData = U.getValues(html1, "<a href=\"/new-homes/home-collections", "\"");
//            for(String f : collectData) {
//            	U.log("KKKKKKKKKK===="+f);
//            }
            for(String floor : collectData)
            	try {
            		String[] collection= U.getValues(U.getHTML("https://livejones.com/new-homes/home-collections"+floor), "div class=\"product home-collections", "<!-- /collections-overview-item -->");
            		for(String data : collection)
            			if(data.contains(commName))
            				collectionHtml += data;
				} catch (Exception e) {
					// TODO: handle exception
				}
			
            ///URL SECTION NEW
            //nw code for collection by madhuri
            String nwUrlSec=U.getSectionValue(html1, "<div id=\"product-collections-link-target\"", "<div class=\"organism bottom-widgets\"");
            if(nwUrlSec!=null) {
            	String nwUrls[]=U.getValues(html1, " <a href=\"", "\"");
            	for(String nwUrl:nwUrls) {
            		if(!nwUrl.contains("http")) {
            			nwUrl="https://www.livejones.com"+nwUrl;
            		}
            		if(nwUrl.contains("/plans")||nwUrl.contains("/floorplan")) {
            			floorPlansHtml+=U.getHTML(nwUrl);
            		//	U.log("FF"+U.getCache(nwUrl));
            		}
            		if(nwUrl.contains("collection")) {
            		collectionDetails+=U.getHTML(nwUrl);
            		//	U.log("FF"+U.getCache(nwUrl));
            		}
            			
            	}
            	
            }
            
            String collHomeData[]=U.getValues(collectionDetails,"<div class=\"product home-collections collections-overview-item js-tracking\"", "</div><!-- /collections-overview-item -->");
            U.log("ityem no>: "+collHomeData.length);
            String myCollection=ALLOW_BLANK;
            for(String collHome:collHomeData) {
            	//U.log("ColHIOME="+collHome);
            	if(collHome.contains("Townhome Collection"))
            		continue;
            	
            	String comNameAvailSec=U.getSectionValue(collHome, "<h5>Find these homes at:</h5>", "</a>");
               
            	//U.log("comNameAvailSec="+comNameAvailSec);
                if(comNameAvailSec.contains(communityName)) {
                	U.log("hello");
                	myCollection+=collHome;
                }
            
            }
           //eof collection code 
            
            //nEW CODE FOR QUICK MOVE IN
            String quickUrl2="https://livejones.com/new-homes/quick-move-in-homes/";
            
            String myQuickHome=ALLOW_BLANK;
            String myQuickHomeUrl=ALLOW_BLANK;
            String qHtml2=U.getHTML(quickUrl2);
            String myQuickHtml=ALLOW_BLANK;
            String myQuickSec=U.getSectionValue(qHtml2, "<ul class=\"homes-list\">", "</section>");
            
            String quickHomes[]=U.getValues(myQuickSec, "class=\"home-listing\" ", "View More Details");
            for(String quickHome:quickHomes) {
            	String comNameIdSec=U.getSectionValue(quickHome, "<h4>Neighborhood:</h4>", "</li>");
            	
            	if(comNameIdSec.contains(communityName)) {
            		myQuickHome+=quickHome;
            		myQuickHomeUrl=U.getSectionValue(quickHome, "<a href=\"https://livejones.com/home", "\"");
            		myQuickHomeUrl="https://livejones.com/home/"+myQuickHomeUrl;
            		myQuickHtml+=U.getHTML(myQuickHomeUrl);
            	}
            }
           //eof new quick code 
			// Price
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;// <strong>Price:</strong>
			// $379,390
			html1 = U.getHTML(communityUrl);
			
			String priceSec=U.getSectionValue(html1, "<h2 id=\"product-price-from\"", "</h2>");
		
			priceSec=priceSec.replaceAll("[s]\\s*at "+communityName, ",000 at "+communityName)
					.replace("[s]\\s*at "+communityName, ",000 at "+communityName)
					.replaceAll("From the \\$(\\d{3})s", "From the \\$$1,000");
			//priceSec=priceSec.replace("$539s", "$539,000").replace("$451s", "$451,000").replace("$438s", "\\$498,000").replace("$474s", " $474,000").replace("$878s", "$878,000").replace("$502s", " $502,000");
			
			//U.log(communitie);
//			communitie=communitie.replace("'s ", ",000");
			
			html1 = html1.replaceAll("[s]\\s*at "+communityName, ",000 at "+communityName);
			html1=html1.replaceAll("0s|0’s.", "0,000").replace("0&#8217;s", "0,000").replace("Williamson County from the $360s", "");
			
			html1 = html1.replace("Williamson County from the $360,000\"", "").replace("From the $449s", "from the $449,000").replace("0's", "0,000").replace("400’s", "400,000");
			html1 = html1.replace("$718s", "$718,000").replace("From the $474s", "From the $474,000").replace("0s", "0,000").replace("$376s", "$376,000");
			
			
//			U.log("<<<<<<<<< "+Util.matchAll(priceSec+floorPlansHtml  , "[\\s\\w\\W]{100}$472,900[\\s\\w\\W]{100}",0));
			String[] price = U 
					.getPrices(
							(priceSec+floorPlansHtml + html1).replace("$475k", "$475,000").replace("$499,900", "").replace("474,900", "").replace("$472,900", "").replace("$450,900", "").replace("From $455k", "From $455,000").replaceAll("0s", "0,000").replace("$1.1m", "$1,100,000") + quickHtml+modelHtml + json.toString(),
							"From \\$\\d{1},\\d{3},\\d{3}|From the \\$\\d{3},\\d{3} |Starting at \\$\\d,\\d{3},\\d{3}|From the \\$\\d+,\\d{3}|Starting at \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}",0);
//			U.log("<<<<<<<<< "+Util.matchAll(floorPlansHtml , "[\\s\\w\\W]{100}$450,900[\\s\\w\\W]{30}",0));
			
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			html1=html1.replace("–", "-");
			//U.log(html1);
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							floorPlansHtml + html1 + quickHtml,
							"<span class=\"count\">\\d{4}</span>",
							0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			// propertyType
			HashSet<String> hSet = new HashSet<String>();
	
			if(floorPlansHtml ==null) 
				floorPlansHtml = "";
			
			String[] propertyTypes = U.getValues(floorPlansHtml,
					"Type:</strong>", "<");
			for (String proType : propertyTypes) {
				proType = proType.trim();
				hSet.add(proType);
			}
			String dpType = ALLOW_BLANK;
			floorPlansHtml = floorPlansHtml.replace("a href=\"#request-info-form", "");
			String dTypeUrl = U.getSectionValue(floorPlansHtml,
					"<h3>Floorplans</h3>", "Fill out the form");
			
			if(dTypeUrl ==null)
				dTypeUrl = "";
				
			String[] dUrl = U.getValues(dTypeUrl, "<a href=\"", "\"");

			String dHtml = ALLOW_BLANK;
			for (String d : dUrl) {
				//U.log(":::::::"+d);
				if(d.contains("http")){
				dHtml = dHtml + U.getHTML(d);
				}
			}
			
			//--------all Movein Homes Data--------
			String allQuickData = ALLOW_BLANK;
			
			if(quickHtml == null)
				quickHtml = "";
			
			
			String[] quickPlanUrls = U.getValues(quickHtml, "Request Info</span></a></div><a href=\"", "\" ");
			for(String qUrl : quickPlanUrls){
				U.log(qUrl);
				String qHtml = U.getHTML(qUrl);
				allQuickData += U.getSectionValue(qHtml, "<h3>About This Home</h3>", "Get More Info About This Home");
			}
			
			dHtml = dHtml.replace("</strong> Stories", " Stories");
			allQuickData = allQuickData.replace("</strong> Stories", " Stories");
			if(floorPlansHtml!=null)
				floorPlansHtml = floorPlansHtml.replace("</strong> Stories", " Stories");
			dpType = U.getdCommType((floorPlansHtml+dHtml+allQuickData).replaceAll("Floor|floor", ""));
			dpType = dpType.replace("[", "");
			dpType = dpType.replace("]", "");
			
			//U.log(html1);
			
			html1 =html1.replace("luxuriou,000", "luxurious");
		
			html1 =html1.replaceAll("luxury and convenience| utmost in luxury|luxury at an affordable price| Luxurious Soaking Tub|appointed luxury built-in", "luxury homes");
			
			if(collectionHtml ==null)
				collectionHtml = "";
			
			
//			U.log("<<<<<<<<< "+Util.matchAll(collectionHtml, "[\\s\\w\\W]{50}craftsman-style exterior[\\s\\w\\W]{30}",0));
//			U.log("<<<<<<<<< "+Util.matchAll(html1+collectionHtml+floorPlansHtml+allQuickData, "[\\s\\w\\W]{50}patio[\\s\\w\\W]{30}",0));

			
//			collectionHtml=collectionHtml.replaceAll("luxury at an affordable price", "luxury homes");
			
			//myQuickHtml+myCollection added in may
			String propertyType = U.getPropType((myQuickHtml+myCollection+html1+collectionHtml+floorPlansHtml+allQuickData).replaceAll("Village|village|Courtyard garages", ""));
			U.log("propertyType: "+propertyType);
			// Property Status
			html1=html1.replace("Springdale Elementary Coming Fall 2017","");
			String status = ALLOW_BLANK;
			String statSec = U.getHTML(communityUrl);
			String remove = "CABANA Coming|homesites are currently SOLD OUT | list for next phase - coming FALL 2021|updates on the next phase - coming fall 2021|New Homes Coming Soon to Franklin|New Homes Coming Soon to Nolensville|Creek is sold out|basements are Now Available in|CABANA Coming Soon|OFFICE COMING SOON|FOR SALE COMING SOON|Elementary Coming Fall 2017|\"Sold Out\" style=\"position|<h3>COMING SOON:|Sold-Out|NEW Model Home &#8211; NOW OPEN|homes &#8211; now open|Coming soon&#8230;</p>|COMING SOON! NEW! Schools|Grand-Opening.png\"|alt=\"Grand Opening\"|Closeout.png\" |alt=\"Closeout\"|Grand Openings are planned|Model Grand Opening|Quick Move-In Homes|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|Model Home Coming Soon|Walking trails - Coming Soon|Community Swimming Pool - Coming Soon!|Neighborhood Clubhouse - Coming Soon|Tennis Courts - Coming Soon|Playgrounds - Coming Soon";

			statSec = statSec.toLowerCase()
					.replaceAll(remove.toLowerCase(), "");
			statSec = statSec.replace(" (coming soon)</span>", "");
		//	U.log("==========="+U.getSectionValue(html1, "<header><h3>Description</h3> </header><div class=\"inner\"><p style=\"text-align: left;\">", "<header><h3>Schools</h3>"));
			statSec = statSec + U.getSectionValue(html1, "<header><h3>Description</h3> </header><div class=\"inner\"><p style=\"text-align: left;\">", "<header><h3>Schools</h3>");
			statSec=statSec.replace("the next phase - coming summer 2021 below!", "next phase coming SPRING 2021").replace("next phase - coming spring 2021", "next phase coming SPRING 2021").replace("new phase of inspiration homesites is now selling", "New Phase NOW SELLING")
					.replace("next phase - coming summer 2021", "next phase coming summer 2021").replaceAll("\">coming soon|this final opportunity to own a home|\\(coming soon\\)</a>|new estate lots now available|foxglove farm has only 30 home sites|tn' >coming soon|>otter creek \\(coming soon\\)|otter creek coming soon to|<option value='coming soon|TN' >Coming Soon:|value='Coming Soon:|bierstadt is now|home \\(coming|>\\[coming","");
			
			String rem = U.getSectionValue(html1, "<body class=\"community", "</header>");
			
			if(rem!=null)
				statSec = statSec.replace(rem, "");
			
			//--status from image url -----------
			String comIimageStatus = U.getSectionValue(html1, "<div class=\"community-contact-image\">", "Community Overview"); 
//			U.log(statSec);
//			U.writeMyText(statSec+comIimageStatus);
			
			String statusSec1="";
			statusSec1=U.getSectionValue(html1, "community-alert-notice", "</span>");
			
			status = U.getPropStatus((statSec+comIimageStatus+communitie+statusSec1)
					.replace("ANNECY's new phase is COMING SOON", "ANNECY's New Phase Coming Soon")
					.replaceAll("dorris farm - coming soon|dorris farm &#8211; coming soon", "")
					.replace("dorris farms - coming soon</a></li>", "")
					.replace("coming soon</span></a></li>", "")
					.replace("Dorris Farms - Coming Soon</a></li>", "").replace("Coming Soon</span></a>", "").replace("list for next phase - coming FALL 2021", "").replace("next phase - coming FALL 2021", "next phase coming FALL 2021")
					.replaceAll("[d|D]orris Farm - [c|C]oming [s|S]oon|[d|D]orris Farm &#8211; [c|C]oming [s|S]oon|cabana now open|model now open|Coming Soon\\]|Entry lots COMING SOON", "").replace("phase 1 is sold out", "Phase 1 SOLD OUT").replaceAll("cottage homesites are currently sold out until late spring 2021|Entry lots COMING SOON|sold out until approximately|<img src=.*?>", "").replace("new phase of homesites just opened", "New phase homesites just opened"));

//			U.log("<<<<<<<<< "+Util.matchAll(statSec+comIimageStatus+communitie+statusSec1, "[\\s\\w\\W]{50}Coming Soon[\\s\\w\\W]{30}",0));
			
		//if (status == ALLOW_BLANK)status = "";
	
		
//		if(communityUrl.contains("https://livejones.com/communities/arrington-ridge/"))
//			propertyType="Manor Homes, Luxury Homes";
		
		
		
		if (quickHtml.contains("<div class=\"price-text\">")) {
				if (status.length() < 1)
					status = "Quick Move-In Homes";
				else
					status = status + ", Quick Move-In Homes";
			} 
		if(status.contains("Lots Now Available, Now Available")){
			status = status.replace("Lots Now Available, Now Available", "Lots Now Available");
		}
		if(status.isEmpty())status = ALLOW_BLANK;

			if (dpType.length() < 5)
				dpType = ALLOW_BLANK;
			dpType=dpType.replace("1.5 Story,","");

			U.log("=================" + minSqf);
	         html1=html1.toLowerCase().replace("when pre-selling begi", "");
//	         if(rcommunityUrl.contains("https://livejones.com/communities/south-haven/"))maxPrice="$474,691";	        
	         if(communityUrl.contains("https://livejones.com/communities/new-homes/fairview-tn/otter-creek/"))status=status.replace(", Coming Spring 2021", "");
//	         if(communityUrl.contains("communities/new-homes/mt-juliet-tn/kelsey-glen/"))status=status.replace("Coming Soon, Currently Sold Out, Quick Move-In Homes", "Currently Sold Out, Quick Move-In Homes");
	         status=status.replace("Quick Move-in, Last Chance, Quick Move-In Homes", "Last Chance, Quick Move-In Homes").replace("Final Homes Remain, Final Homes", "Final Homes Remain");
//	         if(communityUrl.contains("/franklin-tn/the-crest-at-ladd-park/"))status="Quick Move-In Homes";
//	         if(communityUrl.contains("https://livejones.com/communities/new-homes/franklin-tn/foxglove-farm-at-ladd-park/"))status = status + ", Now Open";
//	         if(communityUrl.contains("/otter-creek/")) {
//	        	 minPrice=ALLOW_BLANK;
//	        	 maxPrice=ALLOW_BLANK;
//	        	 minSqf=ALLOW_BLANK;
//	        	 maxSqf=ALLOW_BLANK;
//	        	 
//	         };
	       
	        if(communityUrl.contains("https://livejones.com/communities/terra-vista/")) status="Homesites Coming Soon";  
	        if(communityUrl.contains("https://livejones.com/communities/annecy/")) status="New Phase Coming Soon";
	         status = status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
	         
	         data.addCommunity(communityName, communityUrl, type);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(propertyType, dpType);
			data.addPropertyStatus(status.replace("-,", ""));
			data.addPrice(minPrice, maxPrice);
			data.addNotes(note);
			data.addSquareFeet(minSqf, maxSqf);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
			i++;
			inr++;
			
		}
	}
j++;

		//}catch (Exception e) {}
}
}