/**
 * @author : Sawan
 * @date : 4-10-2017
 */
package com.shatam.b_141_160;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractWadeJurneyHomes extends AbstractScrapper {
//	WebDriver driver = null;
	public int inr = 0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.wadejurneyhomes.com";
	HashSet<String> communityUrls=new HashSet<String>();
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractWadeJurneyHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Wade Jurney Homes.csv", a.data().printAll());
	}

	public ExtractWadeJurneyHomes() throws Exception {

		super("Wade Jurney Homes", builderUrl);
		LOGGER = new CommunityLogger("Wade Jurney Homes");
	}

	public void innerProcess() throws Exception {
		String stateHtml=ALLOW_BLANK;String Urls[]=null;String stateurl=null;
		String html = U.getHTML("http://www.wadejurneyhomes.com/communities/");
		String stateUrls[] = U.getValues(html, "<h5 class=\"community-lists__title\">Communities in ", "</h5>");
	
		//NewCode 26/12/18
		int comRegCount=0,comSecCityCount=0;
		for(String url:stateUrls){
			String stateUrl="https://www.wadejurneyhomes.com/state/"+url.toLowerCase().replace(" ", "-");
			//U.log(stateUrl);
//			if(!stateUrl.contains("georgia"))continue;
			String regHtml=U.getHTML(stateUrl);
			
//			//---below code is to verify state page community count
//			String comSecFromReg[]=U.getValues(regHtml, "<div class=\"community-search__item", "View Community");
//			U.log(comSecFromReg.length);
//			comRegCount+=comSecFromReg.length;
//			for(String sec:comSecFromReg) {
//				String htm=U.getHTML(U.getSectionValue(sec, "community-search__title\" href=\"", "\""));
//			}
			
			String [] subRegurls = U.getValues(regHtml, "<h3><a href=\"", "\"");
			for(String subreg:subRegurls) {
//				U.log("subreg :::::::::::::::: "+subreg);
				String subRegHtml=U.getHTML(subreg);
				
				String cityUrls[]=U.getValues(subRegHtml, "<h3><a href=\"", "\"");
				for(String cityUrl:cityUrls) {
					//U.log(cityUrl);
					String cityHtml=U.getHTML(cityUrl);
					//String[] comSecFromCity = U.getValues(cityHtml, "<div class=\"marker\" data-lat=\"", "View Community");
					String[] comSecFromCity = U.getValues(cityHtml, "<div class=\"community-search__item", "View Community");
					//U.log(comSecFromCity.length);
					LOGGER.AddCommunityUrl("cityurl::::::::::::"+cityUrl+":::::::::count::::::"+comSecFromCity.length);

					comSecCityCount+=comSecFromCity.length;
					for(String comSec : comSecFromCity){
						String comUrl = U.getSectionValue(comSec, "community-search__title\" href=\"", "\"");
						communityUrls.add(comUrl);
						String comName = U.getSectionValue(comSec, "<a class=\"community-search__title\" href=\""+comUrl+"\">", "<");
						//U.log(comUrl+" ::: "+comName);
						String latlngSec = Util.match(cityHtml, "<div class=\"marker\"(.*?)\\s*<h3 class=\"marker-heading\">"+comName,1);
						//U.log("latlngSec : "+latlngSec);
						String comHtml = U.getHTML(comUrl);
						findCommunityDetails(comUrl,comHtml,comSec+latlngSec);
					}
					
				}
			}
			
		}
		U.log(comSecCityCount+":::::::"+comRegCount);			
		U.log(communityUrls.size());
		
		LOGGER.DisposeLogger();
	}
	int j = 0;

	private void findCommunityDetails(String comUrl, String html, String comSec)throws Exception{
		// TODO Auto-generated method stub
	//if(j>=210)
	//if(!comUrl.contains("https://www.wadejurneyhomes.com/community/sunflower-flats/"))return;
	{
		U.log(j+ " <===>"+comUrl);
		//if(comSec==null)return;
		if(comUrl.contains("http://www.wadejurneyhomes.com/search-results/ga/newtoncovington/"))return;
//		if(comUrl.contains("https://www.wadejurneyhomes.com/community/yorktown-meadows-coming-soon/"))return;//no data
		U.log(U.getCache(comUrl));
		U.log(comSec);
		//============ Community Name ==================
//		String comName = U.getSectionValue(html, "class=\"et_pb_text_inner\">", "<p style=");
		String comName = U.getSectionValue(comSec, " <h3 class=\"marker-heading\">", "</h3>");
		if(comName != null)
			comName = comName.trim();
		if(comName==null)
			comName=U.getSectionValue(html, " <h1 class=\"search-results__title\">", "<");
		//if(comName.endsWith("Townhomes"))comName = comName.replace("Townhomes", "");
		U.log("comName =="+comName+"==========");
		
		//============= Address ======================
		String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] add1=null;
		String geo = "False";

		String addSection = U.getSectionValue(html, "<p class=\"search-results__address\">", "</p>");
		U.log("aaaaaaa"+addSection);
		if(addSection != null){
			addSection = addSection.replaceAll("<.*?>|Lot 1, ", "").replace(", Suite", " Suite");
			add1=addSection.split(",");//U.getAddress(addSection);
			U.log(Arrays.toString(add1)+"this is address");
			if(add1.length>2)
			{
				//---Street----
				add[0]=add1[0].trim();
				U.log(add1.length);
				
				//---State-
				add[2]=Util.match(add1[2].trim(), "\\w+").trim();//add1[2].trim();//Util.match(addSection.trim(), "[[:upper:]]{2}").trim();//;//
				
				if(!add1[1].trim().equals(add1[2].trim()))
					add[1]=add1[1].trim();
				else
					add[1]=ALLOW_BLANK;
				
				//-----Zip----
				U.log("KKKKKKK "+add1[2]+" ::::::::::::");
				if(add1.length>3) {
					add1[3]=add1[3].replaceAll("USA", "");
				if(add[2] !=null && add1[3].length()<4) 
					add[3]=Util.match(add1[2], add[2]+"\\s*(\\d{5})",1);
				else if (add[3].length()<3) 
					add[3]=add1[3];
				else
					add[3]=ALLOW_BLANK;
				}
				
//				if(add1[3]!=null) {
//					add1[3]=add1[3].replaceAll("USA", "");
//					add[3]=add1[3];
//				}
				add[3]=Util.match(addSection, "\\d{5}");
				
			}
		}
		if(add[2].length()>2)
			add[2]=USStates.abbr(add1[2]);


		U.log("Add :::"+Arrays.toString(add));

		//================ LatLng ===================
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String latLngSec = U.getSectionValue(html, "https://www.google.com/maps", "z/data");
		if(latLngSec != null){
			latLngSec = latLngSec.replaceAll("@|/", "");
			String vals[] = latLngSec.split(",");
			latLng[0] = vals[0];
			latLng[1] = vals[1];
			U.log("LatLng1 ==="+Arrays.toString(latLng));
		}
		
		if(latLng[0]==ALLOW_BLANK){
			latLng[0] =U.getSectionValue(comSec, "data-lat=\"", "\"");
			latLng[1] =U.getSectionValue(comSec, "data-lng=\"", "\"");
			U.log("LatLng2 ==="+Arrays.toString(latLng));
		}
		if(latLng[0]==null || latLng[0]==ALLOW_BLANK){
			latLng[0] =U.getSectionValue(html, "\"latitude\":\"", "\"");
			latLng[1] =U.getSectionValue(html, "\"longitude\":\"", "\"");
			U.log("LatLng3 ==="+Arrays.toString(latLng));
		}
		
		if(comUrl.contains("/powers-court/")){
			add[2]="GA";
			geo="True";
		}
		if(comUrl.contains("/lexington/")){
			add[0]=ALLOW_BLANK;
			add[1]="Phenix City";
			add[2]="AL";
			add[3]="36869";
		}
		if(comUrl.contains("/country-club-hills/")){
			add[0]="Pine Needles Drive";
			add[1]="Winson-Salem";
			add[2]=ALLOW_BLANK;
			add[3]=ALLOW_BLANK;
		}if(comUrl.contains("/minas-place/"))
			add[2]="NC";
		if(comUrl.contains("/judson-mills-village/")){add[0]=ALLOW_BLANK;add[1]="Judson Mills Village";add[2]="SC";add[3]=ALLOW_BLANK;}
		if(comUrl.contains("/yorktown-meadows-coming-soon") || comUrl.contains("/emerald-pointe/")) {
			String ad[]={"-","Muncie","IN","-"};
			latLng=U.getlatlongGoogleApi(ad);
			add=U.getAddressGoogleApi(latLng);
			geo="TRUE";
		}


		//============ Home Studio to Find LatLng & Address ============
		if(latLng[0] == ALLOW_BLANK){
			String homeStudioSec = U.getSectionValue(html, "et_pb_button_module_wrapper et_pb_module\">", "</a>");
			if(homeStudioSec != null){
				U.log(homeStudioSec);
				String studioUrl = U.getSectionValue(homeStudioSec, "href=\"", "\"");
				U.log("Studio Url=="+builderUrl+studioUrl);
				String studioHome = null;
				if(!studioUrl.startsWith("http"))
					studioHome = U.getHTML(builderUrl+studioUrl);
				else
					studioHome = U.getHTML(studioUrl);
				String latLngSec1 = U.getSectionValue(studioHome, "wjInitMap()", "</script>");
				if(latLngSec1 != null){
					latLng[0] = U.getSectionValue(latLngSec1, "lat:", ",");
					latLng[1] = U.getSectionValue(latLngSec1, "lng:", "};");
				}
				if(latLng[0] != null) latLng[0] = latLng[0].trim();
				else latLng[0] = ALLOW_BLANK;
				if(latLng[1] != null) latLng[1] = latLng[1].trim();
				else latLng[1] = ALLOW_BLANK;
				
				/*
				 * Compare address from studio page and main page. If they are same then we will take latlng from studio page.
				 * If not then we will find latlng from googleapis.
				 */
				String addrs[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String addSec = U.getSectionValue(studioHome, "Address:</strong>", "<p><strong>");
				U.log("AddSec From Studio==="+addSec);
				if(addSec != null){
					addSec = addSec.replace(", Unit", " Unit").replace(", Suite", " Suite");
					addrs = U.getAddress(addSec);
					if(!add[0].contains(addrs[0])){
						try{
							latLng = U.getlatlongGoogleApi(add);
							
						}catch (Exception e) {
							latLng = U.getBingLatLong(add);
						}
						geo = "True";
					}
				}
				U.log("Add From Studio=="+Arrays.toString(addrs));
			}
			U.log("LatLng3 ==="+Arrays.toString(latLng));
		}
		String Note=ALLOW_BLANK;
		if(comUrl.contains("https://www.wadejurneyhomes.com/community/hopewell-heights-coming-soon/")) {
			add[0]="";
			add[1]="Chillicothe";
			add[2]="OH";
			add[3]="";
			latLng=U.getlatlongGoogleApi(add);
			add[0]=U.getAddressGoogleApi(latLng)[0];
			add[3]=U.getAddressGoogleApi(latLng)[3];
			geo = "True";
			Note="Address taken from city and state";
		}
		
		if(latLng[0]==null) {latLng[0]=ALLOW_BLANK;latLng[1]=ALLOW_BLANK;}
		
		if(latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK || latLng[0]==null  ){
			if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK){
				latLng = U.getlatlongGoogleApi(add);
				geo = "True";
			}
		}
		
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK  || add[3]==null){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				geo = "True";
			}
		}
	
		
		if(add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
				add[0] = U.getAddressGoogleApi(latLng)[0];
				geo = "True";
			}
		}
		if(add[0] != ALLOW_BLANK && (add[3] == ALLOW_BLANK || add[3].trim().length()<3)){
			if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLng);
				geo = "True";
			}
		}
		if(add[2]==null && latLng[0]!=ALLOW_BLANK){
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
		}
//		if(add1[2]==null && latLng[0]!=ALLOW_BLANK){
//			add = U.getAddressGoogleApi(latLng);
//			geo = "True";
//		}
		if(comUrl.contains("https://www.wadejurneyhomes.com/community/poinciana-village/")) {
			add[0]="Saint Tropez Court";
			add[1]="Poinciana";
			add[2]="FL";
			add[3]="";
			latLng=U.getlatlongGoogleApi(add);
			add[3]=U.getAddressGoogleApi(latLng)[3];
			geo = "True";
			//Note="Address taken from city and state";
		}
		if(comUrl.contains("/community/maplewood/"))add[0]="118 Yellow Pine Drive";
		U.log("Add :::"+Arrays.toString(add));
		String paginationSec=U.getSectionValue(html, "<ul class='bx_pagination'>", "</div>");
//		U.log(paginationSec);
		if (paginationSec!=null&&paginationSec.contains("class='' href='")) {
			U.log(builderUrl+U.getSectionValue(paginationSec, "class='' href='", "'"));
			String tempHtml=U.getHTML(builderUrl+U.getSectionValue(paginationSec, "class='' href='", "'"));
			html+=tempHtml;
		}
		//============ Home Available Section ============
		String homeSection = U.getSectionValue(html, "<div class=\"bx_plans row moveinready\">", "<h4>Community Details</h4");
		
		//U.log("homeSec"+homeSection);
		//============== Homes Html =======================
		String combineHomeHtmls = ALLOW_BLANK;
		int homeAvailableCnt = 0;
		if(homeSection != null){
			String [] homeUrls = U.getValues(html, "<a class=\"btn btn--info\" href=\"", "\"");
			U.log("Home count=="+homeUrls.length);
			homeAvailableCnt = homeUrls.length;
			int x = 0;
			for(String homeUrl : homeUrls){
				U.log("homeUrl=="+homeUrl);
				String homeHtml = U.getHTML(homeUrl);
				if(homeHtml!=null) {
				combineHomeHtmls += U.getHTML(homeUrl);//U.getSectionValue(homeHtml, "id=\"IDX-detailsHead\">", "<div id=\"IDX-description\">"); //"<div id=\"IDX-BankRateTool");
				}
				if(x == 6)break;
				x++;
			}
		}
		//=========== Price =============
		html=html.replaceAll("<br>Lot Size:*?<br>", "");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replace("'s", ",000").replace("0’s", "0,000").replace("0s", "0,000");
		comSec = comSec.replace("0s", "0,000").replace("in the 100s", "in the $100,000");
//		U.log(combineHomeHtmls);
		String price[] = U.getPrices(homeSection+html.replace("\"totalprice\":\"$162,990.00\",\"", "")+comSec+combineHomeHtmls, 
				"Starting at \\$\\d{3},\\d{3}|<h5 class=\"price-sm\">\\$\\d{2,3},\\d{3}|the low \\d{3},\\d{3}|Starting from \\$\\d{3},\\d{3}|Promo Price :</b> \\$\\d{2,3},\\d{3}.00|the \\$\\d{3},\\d{3}|Starting from \\$\\d{2,3},\\d{3}|IDX-detailsPrice\">\\$\\d{2,3},\\d{3}|IDX-showcasePrice\">\\s+\\$\\d{3},\\d{3}|Total Price:</b>\\s+\\$\\d{2,3},\\d{3}|totalprice\":\"\\$\\d{3},\\d{3}|(the mid|in the) \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice:" + minPrice + " MaxPrice:" + maxPrice);

		
		
		//=========== Sqft =====================
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
	
//		U.log(comSec);
		combineHomeHtmls=combineHomeHtmls.replaceAll("</span> <span class=\"IDX-fieldLabel\">", " ");
		
		String[] sqft = U.getSqareFeet(combineHomeHtmls+html+comSec,
				"homes range from \\d{3,4}-\\d{3,4} square feet|\\d{3} or \\d{3} square feet|\\d{4} – \\d{4} sq ft|community-search__size\">\\d{3,4}-\\d{3,4}</span>|<span class=\"option-detail\">\\d{3,4}</span>\\s+<span class=\"option-title\">sqft</span>|search__size\">\\d{3,4} sq. ft.</span>|community-search__size\">\\d{3,4} sq ft</span>|to over \\d,\\d{3} square feet|\\d{3,4}-\\d{4} sq ft|\\d{3,4}–\\d{3,4} sq ft|\\d,\\d+-\\d,\\d+ sq ft|SQFT:</span>\\s+<span class=\"option-detail\">\\d+<|IDX-fieldData\">\\d,\\d{3}|square footage ranging from \\d{3,4}+ to \\d{3,4}|from \\d{4} - \\d{4}|than \\d,\\d{3} square feet|ranging from \\d,?\\d{3}-\\d,?\\d{3} square feet|Square feet: \\d{4}\\s?(–|-)\\s?\\d{4}|DX-fieldData\">\\d,\\d{3}</span>|Lot SqFt:</strong>\\s+<span class=\"IDX-fieldData\">\\s+\\d{4,}|\\d{4}\\+ sq ft|\\d{4}\\s?(–|-)\\s?\\d{4} sq. ft.|\\d{4}\\s?-\\s?\\d{4} sq(.)? ft(.)?|<p> \\d{4} – \\d{4} sq ft </p>|<p> \\d{4}\\+ sq </p>|<p> \\d{4}-\\d{4} </p>|option-detail\">\\d{4}</span>|<p> \\d{4} </p>|up to \\d{4} sq"
				, 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//================ Community Type =============
		String comDetailSection = U.getSectionValue(html, "Details</h3>", "</h3>");
//		U.log(comDetailSection);
		String comType = U.getCommType(comDetailSection+html);
		
		//=================== Property Type =============
		if(combineHomeHtmls != null)
			combineHomeHtmls = combineHomeHtmls.replaceAll("Area Maintenance|(F|f)loor|FLOOR|(v|V)illage", "");
		
		String remSec = U.getSectionValue(html, "<h2>Nearby Communities", "<div class=\"footer");
		if(remSec != null)
			html = html.replace(remSec, "");
		
		html = html.replaceAll("(v|V)illage||Vistanna Villa", "");
		String pType = U.getPropType((combineHomeHtmls+html).replaceAll("Villa Rica|villa-rica|no HOA fees|HOA assessments are additional", ""));

		if(pType.contains("Townhouse") && (pType.contains("Townhomes") || pType.contains("Townhome")))
			pType = pType.replaceAll(",Townhouse", "");

		//================= Property Status ============
		html = html.replaceAll("Homes Available Now", "");
		String titleLine=U.getSectionValue(html, "<title>", "</title>");
		if(!titleLine.contains("Coming")) {titleLine=U.getSectionValue(comUrl, "community/", "/");titleLine=titleLine.replaceAll("-", " ");}
		String pStatus = U.getPropStatus((comDetailSection+html+titleLine).replaceAll("Coming Soon|coming soon", ""));
		
//		if(homeAvailableCnt > 0 && !pStatus.contains("Homes Available Now")){
//			if(pStatus == ALLOW_BLANK) pStatus = "Homes Available Now";
//			else pStatus +=",Homes Available Now";
//		}
//	
		//================= Derived Type =================
		html = html.replaceAll("STORIES:</span>\\s+<span class=\"option-detail\">1<",  " 1 Story<");
		String dType = U.getdCommType(combineHomeHtmls+html.replace("second floor", "2 Story"));
		
		//============ Notes ==============
		if(pType.contains("Townhouse, Townhome"))pType="Townhome";
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"<=============== Repeat");
			return;
		}
		if(add[2].length()>2){
			add[2]=USStates.abbr(add[2]);
		}
		//.replaceAll("&#8217;", "'")
		//if(comName.contains("&#8217;"))
			comName=comName.replaceAll("- Coming soon!$| &#8211; Coming Soon!| – Coming Soon!", "").replaceAll("&#8217;", "'").replace(" &#8211; ", "-").replaceAll("Townhomes", "");
		LOGGER.AddCommunityUrl(comUrl);	
		data.addCommunity(comName, comUrl, comType);
		U.log("add[0]:"+add[0]+", add[1]: "+add[1]+" add[2] :"+add[2]+ ",add[3] :" +add[3]);
		data.addAddress(add[0].trim(), add[1].replace("�", "").trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(Note);
		
	}
	j++;
	}
}
