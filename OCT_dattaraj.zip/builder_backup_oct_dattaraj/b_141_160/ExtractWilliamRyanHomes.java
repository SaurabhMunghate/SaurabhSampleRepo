/** @author 
 *  @date
 */

package com.shatam.b_141_160;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.apache.commons.collections.map.MultiValueMap;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWilliamRyanHomes extends AbstractScrapper {
	static int i = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	private static final String builderUrl = "https://www.williamryanhomes.com";

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractWilliamRyanHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"William Ryan Homes.csv", a.data()
				.printAll());
	}
	
	MultiValueMap homesData = new MultiValueMap();
	
	public ExtractWilliamRyanHomes() throws Exception {
		super("William Ryan Homes", "https://www.williamryanhomes.com/");
		LOGGER = new CommunityLogger("William Ryan Homes");
	}

	public void innerProcess() throws Exception {
		JsonParser json = new JsonParser();
		//For Homes
		String homesHtml = U.getPageSource("https://www.williamryanhomes.com/_dm/s/rt/actions/sites/f54dccf6/collections/Search%20Homes/ENGLISH_UK");
		JsonObject allHomesJson = (JsonObject)json.parse((homesHtml.replaceAll("\\\"","\""))); 
		JsonArray homes = new JsonArray(); 
		homes = (JsonArray)json.parse(allHomesJson.get("value").getAsString().replaceAll("\\\"","\""));
		U.log("Total Homes: "+homes.size());
		
		for(int i = 0; i < homes.size(); i++) {
			String homeJson = homes.get(i).toString();
			String dudaCommUrl = U.getSectionValue(homeJson, "\"DudaCommUrl\":\"", "\"");
			//U.log("dudaCommUrl: "+dudaCommUrl);
			homesData.put(dudaCommUrl, homeJson);
		}
		U.log("homesData Size: "+homesData.size());
		
		//For Communities
		String html = U.getPageSource("https://www.williamryanhomes.com/_dm/s/rt/actions/sites/f54dccf6/collections/Search%20Comms/ENGLISH_UK");
		JsonObject comJson = (JsonObject)json.parse((html.replaceAll("\\\"","\""))); 
		JsonArray value = new JsonArray(); 
		value = (JsonArray)json.parse(comJson.get("value").getAsString().replaceAll("\\\"","\""));
		U.log("Total Com: "+value.size());
		
		for(int j = 0; j < value.size(); j++) {
			String communityJson = value.get(j).toString();
			String commUrl = U.getSectionValue(communityJson, "\"CommunityUrl\":\"", "\"");
//			U.log("jsoncommUrl-1: "+commUrl);
			
			if(commUrl==null || commUrl.length()==0) {
				commUrl = "https://www.williamryanhomes.com/communities/" + U.getSectionValue(communityJson.toString(), "\"page_item_url\":\"", "\"");
//				U.log("new jsoncommUrl-2: "+commUrl);
			}
			//U.log("new communityJson: "+communityJson);
			
			addDetails(commUrl, communityJson);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comSec) throws Exception {

//		if (!comUrl.contains("https://www.williamryanhomes.com/communities/Sussex-Preserve-117903")) return;
		
		
		if (comUrl.contains("http://www.williamryanhomes.com/comm_overview.php?com=65")) return;

		
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("--------------------------------------REPEATED" + comUrl);
			return;
		}
		
		

		LOGGER.AddCommunityUrl(comUrl);
		
			U.log("Count: "+i+" comUrl : "+comUrl);
			String dudaUrl = U.getSectionValue(comSec, "\"DudaUrl\":\"", "\"");
			U.log("dudaUrl : "+dudaUrl);
			
			//=================== Com. Name
			String nameSec = U.getSectionValue(comSec, "\"BrHi\":", ",\"Desc\"");
			String comName = U.getSectionValue(nameSec, "\"Name\":\"", "\"");
			U.log("comName : "+comName);
			
			//=================== Address
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			
			String state = U.getSectionValue(comSec, "\"State\":\"", "\"");
			//U.log("state : "+state);
			String city = U.getSectionValue(comSec, "\"City\":\"", "\"");
			//U.log("city : "+city);
			String zip = U.getSectionValue(comSec, "\"Zip\":\"", "\"");
			//U.log("city : "+zip);
			String street = U.getSectionValue(comSec, "\"Addr\":\"", "\"");
			//U.log("street : "+street);
			street = street.replace(" + Founders Circle", "").replace(" + Tea Olive Terrace", "").replace(" + Chalice Dr", "").replace(" Ct. + Tea Olive Terrace", "");
			
			U.log("ADDRESS: "+street+" - "+city+" - "+state+" - "+zip+" - "+geo);
			//=================== Lat Lng
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String lat = U.getSectionValue(comSec, "\"Lat\":\"", "\"");
			U.log("lat : "+lat);
			String lng = U.getSectionValue(comSec, "\"Lng\":\"", "\"");
			U.log("lng : "+lng);
			
			latLng[0] = lat;
			latLng[1] = lng;
			
			//homesData from map
			ArrayList<String> homeData = (ArrayList<String>) homesData.get(dudaUrl);
			//U.log("homeData Size: "+homeData.size());
			String homesecs = ALLOW_BLANK;
			int quickCount = 0;
			
			if (homeData != null) {
				for (String home : homeData) {
					if(home.contains("\"IsQmi\"")) {
						
						String isQmi = U.getSectionValue(home, "\"IsQmi\":", ",\"");
						
						if(isQmi.equals("true") && !home.contains("THIS HOME HAS NOW SOLD"))
//							U.log("quickData: "+home);
							quickCount++;
					}
					homesecs += home;
				}
			}
			U.log("quickCount: "+quickCount);
			//=================== Prices
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U.getPrices(comSec+homesecs,"\"PrLo\":\\d{6}|\"PrHi\":\\d{6}|\"PriceHi\":\"\\d{6}\"", 0);
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("price : "+Arrays.toString(price));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+homesecs, "[\\s\\w\\W]{30}2455[\\s\\w\\W]{30}", 0));
			
			//=================== SqFt
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(comSec+homesecs,
					"\\d,\\d{3} sq. ft to \\d,\\d{3} sq. ft featuring|from \\d{4} square feet to over \\d{4} square feet|nearly \\d,\\d{3} sq ft|from \\d,\\d{3} sq ft|from \\d,\\d{3} to \\d,\\d{3} square feet|SftLo\":\\d{4}|"
					+ "SftHi\":\\d{4}", 0);
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("sqft : "+Arrays.toString(sqft));
			//U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}1516[\\s\\w\\W]{30}", 0));
			
			//============ cType
			comSec=comSec.replaceAll("Waterfront community playground|Waterfront Community Playground", "");
			String cType = U.getCommType(comSec);
			U.log("cType: "+cType);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}Waterfront Community[\\s\\w\\W]{30}", 0));
					
			//============ pType
			comSec = comSec.replaceAll("\"IsCondo\"|\"IsTownHome\"", "");
			homesecs = homesecs.replaceAll("Modern Farmhouse Elevation|Camden Colonial exterior elevation rendering|Colonial exterior elevation", "");
			
			String pType = U.getPropType(comSec+homesecs);
			U.log("pType: "+pType);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}Colonial exterior[\\s\\w\\W]{30}", 0));
			//U.log(">>>>>>>>>>>>"+Util.matchAll(homesecs, "[\\s\\w\\W]{30}Colonial exterior[\\s\\w\\W]{30}", 0));
			
			//============ dType
			String dType = U.getdCommType(comSec+homesecs);
			U.log("dType: "+dType);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(description, "[\\s\\w\\W]{30}Golf Club[\\s\\w\\W]{30}", 0));
			//============ Status	
			comSec = comSec.replaceAll("at Victory in Verrado - Coming Soon!|Hours\":\"Coming Soon|Front Exterior - Coming Soon!|Back Exterior - Coming Soon|"
					+ "Front Door Entrance - Coming Soon|DrivingDirections\":\"Coming Soon|and Mountains - Coming Soon|Hallway - Coming Soon|Bedroom - Coming Soon|"
					+ "Shower - Coming Soon|Jill Bath - Coming Soon|Vanity - Coming Soon|Pool - Coming Soon|Patio - Coming Soon|House - Coming Soon|Pool - Coming Soon|"
					+ "Front Door - Coming Soon|Entry - Coming Soon|- Coming Soon!|first to know about our Grand Opening|grand opening in 2018", "")
					.replace("in Victory at Verrado - Coming Soon!", "").replace("Fairways - Coming this Summer", "");
			
			homesecs = homesecs.replaceAll("\"MarketingDesc\":\"Coming Soon!\"|Hours\":\"Coming Soon|DrivingDirections\":\"Coming Soon|know about our Grand Opening|grand opening in 2018", "");
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+homesecs, "[\\s\\w\\W]{60}Ready for[\\s\\w\\W]{50}", 0));
			String Status = U.getPropStatus((comSec).replaceAll("Sussex Preserve, coming soon|Ready for move in late|comingSoonImage|comingSoonFlag|\"MarketingDesc\":\"Coming Soon!\"|Model Coming Soon|homesites coming soon William Ryan Homes|home community coming soon to Palmetto|coming soon to Spring Hill|C -Coming Soon|CG Coming Soon Grand Opening", "").replace("\"MarketingDesc\":\"Ready for Move In Late Spring/Summer 2022", ""));
			U.log("quickCount=="+quickCount);
			if(quickCount > 0) {
				if(Status == ALLOW_BLANK) Status = "Quick Move-Ins";
				else if(Status != ALLOW_BLANK) Status += ", Quick Move-Ins";
			}
			Status=Status.replace("New Phase Coming Soon, New Phase Opening Soon", "New Phase Opening Soon");
			U.log("Status: "+Status);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}Grand Opening[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(homesecs, "[\\s\\w\\W]{30}Grand Opening[\\s\\w\\W]{30}", 0));
			//============ Note
			String note = U.getnote(comSec);
			U.log("note: "+note);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(planData, "[\\s\\w\\W]{30}Presale[\\s\\w\\W]{30}", 0));	
			//https://salesarchitect.exsquared.com/api/GeoJsonAPI/GetGeoJsonData?bdxCommunityID=167480&communityNumber=
			String commid = U.getSectionValue(comSec, ",\"Id\":", ",");
			String lotMapHtm = U.getHTML("https://salesarchitect.exsquared.com/api/GeoJsonAPI/GetGeoJsonData?bdxCommunityID="+commid+"&communityNumber=");
			U.log(comSec);
			String lotmapData = Util.matchAll(lotMapHtm, "\"internalReference\":\"",0).size()>0?Util.matchAll(lotMapHtm, "\"internalReference\":\"",0).size()+"":ALLOW_BLANK;
			data.addCommunity(comName, comUrl, cType);
			data.addAddress(street, city, state, zip);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyStatus(Status);
			data.addPropertyType(pType, dType);
			data.addNotes(note);
			data.addUnitCount(lotmapData);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			U.log(" ");
			i++;
	}
}
