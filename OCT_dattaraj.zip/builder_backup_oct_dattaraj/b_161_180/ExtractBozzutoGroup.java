/**
 * @author Priti
 * @date 02/08/2018
 * 
 */
package com.shatam.b_161_180;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.plaf.synth.Region;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractBozzutoGroup extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	HashSet<String> set = new HashSet<String>();
	WebDriver driver = null;
	static HashMap<String, String[]> latLong = new HashMap<String, String[]>();
	private String baseUrl = "https://www.bozzuto.com";

	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new ExtractBozzutoGroup();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Bozzuto Group.csv", a.data().printAll());
	}

	public ExtractBozzutoGroup() throws Exception {

		super("Bozzuto Group", "https://www.bozzuto.com/");
		LOGGER = new CommunityLogger("Bozzuto Group");
	}
	int toalCom=0;
	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		// String base = "https://www.bozzuto.com/";
		String base = "https://www.bozzuto.com/apartments";
		String html = U.getPageSource(base);

		// ==== Apartment homes ====
		// String regionSec = U.getSectionValue(html, " The Bozzuto Difference ", "<div
		// class=\"l-row\">");
		String[] regionUrls = U.getValues(html, " <button data-state-url=\"", "\"");
		U.log(regionUrls.length);
		for (String regionUrl : regionUrls) {
			U.log(">>>>>>>regionUrl>>> "+regionUrl);
			// if(regionUrl.contains("dc"))
//			try {
				findRegionApartment(regionUrl);
//			} catch (Exception e) {}
			
			// break;
		}
		
//		addBuyDetails();

		//		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}
	private void findRegionApartment(String reionUrl) throws Exception {
		//U.log("Reg::=" + reionUrl);
		//U.log(U.getCache(reionUrl));
		String reionHtml = U.getHTML(reionUrl);
		//ArrayList<String> count = Util.matchAll(reionHtml, "data-page", 0);
//		if (reionHtml.contains("pagination__item pagination__item--current")) {
//				String hh=reionHtml;
//				for (int i = 2; i <= 10 + 1; i++) {
//					if(hh.contains("data-page=\""+i)) {
//						 hh=U.getHtml(reionUrl + "#page="+i,driver);
//						 U.log(reionUrl + "#page="+i);
//					String regionHtml = hh;
//					//Thread.sleep(5000);
//					reionHtml = reionHtml + regionHtml;
//					}else {
//						break;
//					}
//			
//				}
//
//		}
//		String[] apartmentSec = U.getValues(reionHtml, "><div data-property-id=",
//				"<div class=\"card__specs card");
		
		String[] apartmentSec = U.getValues(reionHtml, " <div class=\"img-wrapper u-aspect-md-3x2\">",
				"<div class=\"card__specs card");
		
		
		U.log("apartmentSec ::"+apartmentSec.length);
		//U.log(toalCom+=apartmentSec.length);
		for (String section : apartmentSec) {
			String apartmentUrl = U.getSectionValue(section, "<a href=\"", "\"");
//			 U.log(section);
			//U.log(">>>>>>>apartmentUrl: "+apartmentUrl);

			String apartmentName = U.getSectionValue(section, "card__title--link\">", "</a>").trim();
			U.log(">>>>>>>apartmentName: "+apartmentName);
			addDetails(apartmentUrl, apartmentName, section);
			// break;
		}
	}

	// TODO :
	private void addDetails(String url, String name, String section) throws Exception {
//		 if(j >= 110)
//			 if(j >= 100&&j<150)
		{
			//TODO : Execute for single community
			
//			if(!url.contains("https://www.bozzuto.com/apartments/washington/dc/intersect-at-o/")) return;
 
 

 if(url.contains("https://www.bozzuto.com/apartments/arlington/va/sedonaslate/"))name="Sedona Slate";
 name=name.replaceAll(" Chicago$|New Haven|Mineola|Pittsburgh|Miami", "").replace("�me at Meridian Hill", "Ame At Meridian Hill").replace("�s", "s").replace("�", "").trim()
		 .replace("&#038;", "&").replace("&#8211;", "-");//.trim()
 U.log("::::::::::::::::::: COMMUNITY NAME   "+name);
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "==========>Repeated");
				return;
			}
			

			if(url.contains("https://www.bozzuto.com/apartments/fort-lee/nj/the-modern-100-park/") || url.contains("https://www.bozzuto.com/apartments/glastonbury/ct/the-tannery/")) {
				LOGGER.AddCommunityUrl(url+"====returning to builder url");
				return;
			}
			LOGGER.AddCommunityUrl(url);
/*			if (set.contains(url)) {
				LOGGER.AddCommunityUrl(url + "//==========>Repeated");		
				return;
			}
			set.add(url);*/
//			if (url.contains("https://www.bozzuto.com/apartments/washington/dc/city-market-at-o-street-2"))	return;// 404 error
			U.log(j + "\t" + url);
			String aptHtml = U.getHTML(url);

			// ----Address-----
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE",note=ALLOW_BLANK;
			
			String addSec=U.getSectionValue(aptHtml, "</p><p class=\"content__address h-no-tracking\">","</div>");
//			U.log(">>>>>addSec  "+addSec);
//			if(name.contains("Park + Ford"))
//			{
////				add[0]="3101 Park Center Drive";
//				addSec=addSec.replace("and 4401 Ford Avenue", "");
//			}
//			addSec=addSec.replace("and 4401 Ford Avenue", " ");
			U.log("this is add:::"+addSec);
			if(addSec!=null) {
				addSec=U.getNoHtml(addSec.replace("</p>", ","));
				U.log("eeeeeeee"+addSec);
				addSec=addSec.replace(" 698 N.E. 1st Ave.,  Miami,                             FL  33132", "698 NE 1st Ave ,  Miami,  FL  33132");
				U.log("eeeeeeee"+addSec);
				addSec=addSec.replace("Falls Church, VA 22044,", "501 Roosevelt Blvd, Falls Church, VA 22044").replace("Arlington, VA 22202,", "710 12th Street S, Arlington, VA 22202,")
						.replaceAll(",\\s+ ([A-Z]{2})  (\\d{4}),", ", $1 0$2");
				add=U.findAddress(addSec);
				if(add==null)add=U.getAddress(addSec);
				if(add[0]==null)add[0]=ALLOW_BLANK;
				U.log(add[0]);
				add[0]=add[0].replace("one city place", "");
			}
			if (add[0].length()<4){
				addSec = U.getSectionValue(aptHtml, "      \"address\":", "</script>");
				
		
//			U.log("fffffff"+addSec);
			if (addSec != null) {
				add[0] = U.getSectionValue(addSec, "streetAddress\": \"", "\"").replace("One City Place", ALLOW_BLANK);
				add[1] = U.getSectionValue(addSec, "addressLocality\": \"", "\"");
				add[2] =  U.getSectionValue(addSec, "addressRegion\": \"", "\"");
				add[3] = U.getSectionValue(addSec, "postalCode\": \"", "\"");

				
				
			}
			}
			if(addSec==null) {
				addSec= U.getSectionValue(aptHtml, " <p class=\"content__address", "</div>");
//				U.log(addSec);
				if(addSec!=null) {
				addSec=addSec.replace("201 I Street, NE.", "201 I Street NE").replaceAll(", NE.|N.E.", " NE").replaceAll(">(.*?)</p>\\s*<p", "");
				add=U.findAddress(addSec);
				}
				if(add==null && addSec!=null) {
					addSec=addSec.replaceAll("</p>", "").replaceAll("<p class=\"content__address h-no-tracking\">", ",");
					add=U.getAddress(addSec);
				}
				add[0]=add[0].replaceAll("New York / New Jersey / Connecticut Apartments,|,|Capitol Hill</p>|h-no-tracking\">\\s*|h-no-tracking\" class=\"content__address |h-no-tracking\">Washington, DC Apartments</p>", "");

			}
			if((add[2]==ALLOW_BLANK|| add[0]==ALLOW_BLANK) && add==null && aptHtml.contains("<p class=\"content__address h-no-tracking\">"))
			{
				addSec=U.getSectionValue(aptHtml, "<p class=\"content__address h-no-tracking\">","</div>");
				if(addSec!=null) {
					addSec=U.getNoHtml(addSec.replace("</p>", ","));
					U.log("eeeeeeee"+addSec);
					addSec=addSec.replace(" 698 N.E. 1st Ave.,  Miami,                             FL  33132", "698 NE 1st Ave ,  Miami,  FL  33132");
					U.log("eeeeeeee"+addSec);
					addSec=addSec.replace("Falls Church, VA 22044,", "501 Roosevelt Blvd, Falls Church, VA 22044").replace("Arlington, VA 22202,", "710 12th Street S, Arlington, VA 22202,")
							.replaceAll(",\\s+ ([A-Z]{2})  (\\d{4}),", ", $1 0$2");
					add=U.findAddress(addSec);
					if(add==null)add=U.getAddress(addSec);
					if(add[0]==null)add[0]=ALLOW_BLANK;
					U.log(add[0]);
					add[0]=add[0].replace("one city place", "");
				}
			}
			
			
			if(url.contains("https://www.bozzuto.com/apartments/washington/dc/the-vale/")) {
				
				addSec = "1000 Butternut St NW, Washington,DC  20012";
				add = U.getAddress(addSec);
			}
			
			if(url.contains("https://www.bozzuto.com/apartments/fort-lee/nj/the-modern-2/")) 
				add[0]="100-800 Park Avenue";
			
			if(add[0].contains("The Wharf Washington")) 
				add[0]="The Wharf";
			
			
			U.log("Address is : " + Arrays.toString(add));

			String latlngSec = U.getSectionValue(aptHtml, "rel=\"noopener\" href=\"https://maps.google.com/maps?ll=",
					"&");
			if (latlngSec != null)
				latLng = latlngSec.split(",");
			else {
				
				latLng[0]=U.getSectionValue(aptHtml, "data-lat=\"", "\"");
				latLng[1]=U.getSectionValue(aptHtml, "data-lng=\"", "\"");

			}
			if(latLng[0]==null)latLng[0]=ALLOW_BLANK;
			if(latLng[0]== ALLOW_BLANK) {
				latlngSec = U.getSectionValue(aptHtml, "href=\"https://www.google.com/maps?q=","\"");
				if(latlngSec!=null)
				latLng = latlngSec.split(",");
				
//				if(url.contains("https://www.bozzuto.com/apartments/fort-lee/nj/the-modern-100-park/")) {
//					add[1]="";
//					add[2]="";
//					latLng=U.getlatlongGoogleApi(add);
//					add=U.getAddressGoogleApi(latLng);
//					geo="TRUE";
//				}
			}
			U.log("latLng is : " + Arrays.toString(latLng));
			

			if (add[0].length() < 4 && latLng[0].length() > 4) {
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add =U.getAddressHereApi(latLng);
				geo = "TRUE";
			}
			if (add[0].length() > 4 && latLng[0].length() < 4) {
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
		
			add[0] = add[0].replace("Avenue, ", "Avenue ").toLowerCase();
			if(add[3].length()<5 || add[1].isEmpty()) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if(add1 == null) add1= U.getAddressHereApi(latLng);
				if(add[3].length()<5)
					add[3]=add1[3];
				if(add[1].isEmpty()) add[1]=add1[1]; 
				geo = "TRUE";
			}
			
			
			// ------Price-----
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			aptHtml=aptHtml.replace("0&#8217;s", "0,000");
			String prices[] = U.getPrices(aptHtml + section, "\\$\\d{3},\\d{3}", 0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			// -----Sqft----
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			aptHtml = aptHtml.replaceAll("\\d,\\d+ sq ft fitness center", "");
			String sqft[] = U.getSqareFeet(aptHtml + section, "dark\">\n\\s*\\d+ Sq Ft|dark\">\\d{3,4} Sq Ft<|\\d{3,4} Sq\\s*Ft", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("sqft::::::minSqft="+minSqft+"    maxSqft="+maxSqft);

			// ---------comType--propType---dTpe---propStatus-----
			String rem = U.getSectionValue(aptHtml, "id=\"ReviewsSection\"", "<div id=\"\"");
			if(rem != null) aptHtml = aptHtml.replace(rem, "");
			
			aptHtml = aptHtml.replace("Leasing in 2023", "Leasing 2023");
			note=U.getnote(aptHtml);
			U.log("::::::::::: note: "+note);
			//U.log("mmmmmm"+Util.matchAll(aptHtml, "[\\w\\s\\W]{30}leasing[\\w\\s\\W]{30}", 0));
			
			aptHtml = aptHtml.replace("Colonial Village Shopping Center", "").replace("Walkable Waterfront", "Walkable Waterfront Community")
					.replace("62+ Apartments", "62+ apartment community").replace("Waterfront Ease", "Waterfront community Ease")
					.replace("Coastal Suburban Living", "coastal-style homes")
					.replace("Lakeside is the perfect retreat to call home", "Lakeside Community is the perfect retreat to call home")
					.replace("spacious and homey loft, flat or townhome", "spacious and homey spacious loft, flat or townhome")
					.replaceAll("farmhouse modern apartments","modern farmhouse");
			aptHtml=aptHtml.replaceAll("Coral Gables Golf Course Maintenance|l-row l-row--flex room-zeta|FREE on Move-In Ready|Multi-level gym|third floor lobby is available| 2nd floor amenities|Two-story Fitness |oming soon to A2 by Anthem Hous|Market now open|- Coming Soon|room-beta\"><h3>Coming", "");
			aptHtml=aptHtml.replace(" Coastal Charm in Annapolis", "coastal-style homes").replaceAll("Multi-level Clubhouse|multi-level clubhouse|Lakefront a few|Opening in early 2021 in the heart|Coming soon! Pour Vino|hardly ready for move|Gift cards have limited availability|park is coming|Brand-new townhomes available|grand opening event|Cheers to the Grand|their grand opening|nice at the Grand|Foods opening", "");
			
			String comType = U.getCommType((aptHtml + section).replaceAll("Gated Access|obligated", "")
					.replaceAll("Waterfront Apartments|Waterfront Lofts", "Waterfront Community Apartments"));
			U.log("::::::::::: comType"+comType);
			
			String propType = U.getPropType(aptHtml + section);
			U.log("::::::::::: propType"+propType);
			
			aptHtml = aptHtml.replaceAll("Multi-level (fitness|resort)", "").replace("11th-floor", " 11-story").replace("eighteenth-floor", "18-story");
			
			String dType = U.getdCommType((aptHtml + section).replaceAll("third floor|2nd floor|[F|f]irst floor|four levels of management|Soaring two-story windows|two-story lofts|two-story fitness center|Expansive two-story Great Room with fireplace|Two-story lobby|king views from Parc Huron's 21-story tower|18th floor sky|18-story sky deck|Ranchos| Virginia colonial feel|1st Floor, Bethesda, MD\"|branchID|Branch", ""));
			U.log("::::::::::: dType"+dType);
			//U.log("mmmmmm"+Util.matchAll(aptHtml+ section, "[\\w\\s\\W]{30}waterfront[\\w\\s\\W]{30}", 0));

			aptHtml = aptHtml.replaceAll("are now available to lease|answer my move-in ready|h-no-tracking\"> Coming Soon", "")
					.replace("Opening in Fall 2022", "Opening Fall 2022");
			
					
			String propStatus = U.getPropStatus((U.getNoHtml(aptHtml) + section).replaceAll("card-btn opt-tour\">Coming Soon</a>|clean and move-in ready|Fall 2022, The Claude will offer|Brand New Apartments Coming 2023|ready to move into as soon|perfect and ready for move in|Steakhouse is now opened|amenities are now available| penthouses now available|on Move-In Ready Homes|Arriving Summer 2020| Picture|partment was move-in ready", "").replace("Opening in early 2021", "Opening early 2021").replaceAll("AMENITY FEE for a LIMITED TIME ONLY|t-grey-dark\"> Now selling|omes are now selling", ""));
			
//			U.log("mmmmmm"+Util.matchAll(aptHtml+ section, "[\\w\\s\\W]{30}arriving[\\w\\s\\W]{30}", 0));
			
			U.log("::::::::::: propStatus: "+propStatus);
			
			
			//////////////////////////////////////////////////////////////////////////////////////////////
			if(name.contains("The Claude at Chevy Chase Lake"))
			{
				propStatus=propStatus.replace("Opening In Fall 2022, ", "");
			}
			
//			
//			U.log(Util.matchAll(aptHtml+section, "[\\w\\s\\W]{30}18th floo[\\w\\s\\W]{30}", 0));
			if (add[1].length() > 5 && latLng[0].length() < 4) {
				latLng = U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latLng);
				geo = "TRUE";
				note="Address Is Taken From City And State";
			}
			if(dType.contains("32 Story") && dType.contains("2 Story")) dType=dType.replace("2 Story,", "");
			name = name.replace(" Apartment Homes", "");
			if (name.endsWith("Apartments"))
				name = name.replace("Apartments", "");
			if (name.endsWith("Lofts"))
				name = name.replace("Lofts", "");
			name=name.replace("â", "A").replace(" – ", " - ");
			name=name.replace("�", "a");
			name=name.replace("77h", "77H").replace("14w", "14W");
//			U.log("what is the status===="+Util.matchAll(aptHtml+section,"[\\w\\s\\W]{30}coming[\\w\\s\\W]{30}",0));

			if (propType.contains("Townhouse,") && propType.contains(", Townhome"))
				propType = propType.replaceAll("Townhouse,", "");
			
			
			if(url.contains("https://www.bozzuto.com/apartments/boston/ma/the-harlo"))
				dType=dType.replace(", 1 Story", "");
				
			if(propStatus.contains("Arriving Early 2021") && propStatus.contains("Opening Early 2021"))
				propStatus = propStatus.replaceAll(", Opening Early 2021", "");
				if(url.contains("https://www.bozzuto.com/apartments/unknown/nj/edge")) {
					add[0]="170 Avenue F";
					add[1]="Bayonne";
					add[2]="NJ";
					add[3]="07002";
				}
			//if(url.contains("https://www.bozzuto.com/apartments/unknown/dc/3801-connecticut-avenue"))add[1]="Cleveland Park";
			//if(url.contains("https://www.bozzuto.com/apartments/unknown/dc/450k"))add[1]="Mount Vernon Triangle";
				if(url.contains("unknown")) {
					add[1]=U.getSectionValue(aptHtml, "\"content__address h-no-tracking\">", "</p>");
				}
			if(url.contains("https://www.bozzuto.com/apartments/unknown/ny/42-broad/")) add[0] = "42 Broad St. West";
			if(add[1].contains("New York / New Jersey / Connecticut Apartments")||add[1].contains("NoMa/Union Market")) {
				add=U.getAddressGoogleApi(latLng);
				
			}
			if(url.contains("https://www.bozzuto.com/apartments/baltimore/md/spinnaker-bay-at-harbor-east/"))comType="Waterfront Community";
			if(url.contains("https://www.bozzuto.com/apartments/alexandria/va/array-at-west-alex"))propStatus=ALLOW_BLANK;
		if(url.contains("https://www.bozzuto.com/apartments/unknown/nj/edge"))add[1]="Bayonne";
		if(url.contains("https://www.bozzuto.com/apartments/gambrills/md/monarch"))propStatus=propStatus.replace(", Grand Opening", "");
		
		if(propType.contains("Townhome") && propType.contains("Townhouse"))
			propType = propType.replaceAll(", Townhouse|Townhouse,", "");
		
		if(url.contains("apartments/boston/ma/one-greenway/"))dType=dType.replace("1 Story, ", "");

		name = name.trim();
		U.log("Note: "+note);
		
		//summer is over in USA. SEPT - 2022.
		if(url.contains("https://www.bozzuto.com/apartments/washington/dc/intersect-at-o/")) propStatus=ALLOW_BLANK; 
		
	     // ------------------ No. of units ------------------------
	     String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
			data.addCommunity(name.replace("Sedona|slate", "Sedona Slate").toLowerCase(), url, comType);
			data.addAddress(add[0].replace(",", "").replace(add[1], ""), add[1], add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(propType, dType.replace("3 2 Story", "32 Story").replace("11 Story, 1 Story", "11 Story"));
			data.addPropertyStatus(propStatus);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addNotes(note.replaceAll("Lease Now, Lease Now|Now Leasing, Lease Now", "Now Leasing").replace("Now Leasing, Leasing Now", "Now Leasing").replace("Lease Now, Now Leasing", "Lease Now"));

		}
		j++;

	}

	private void addBuyDetails() throws Exception {

		String mainHtml = U.getHTML("https://www.bozzuto.com/homes-search/");
		String comDataSec[] = U.getValues(mainHtml, "<div class=\"img-wrapper u-aspect-sm-3x2", "Visit website");
		for (String sec : comDataSec) {
//			U.log(sec);
			String url = U.getSectionValue(sec, "<a href=\"", "\"");
			if(url.contains("https://www.bozzuto.com/new-homes/communities/emblem-at-barracks-row/")) {
				url="https://www.emblembarracksrow.com";
			}
			if(url.equals("livewest141.com")) {
				url="http://www.livewest141.com";
			}
			String html = U.getHTML(url);
			U.log(U.getCache(url));
			String name = U.getSectionValue(sec, "class=\"card__title--link\">", "</a>");
			

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			if(url.contains("emblembarracksrow")) {
				String mapHtml=U.getHTML("https://www.emblembarracksrow.com/contactus.aspx");
				add[0]=U.getSectionValue(mapHtml, "<span data-selenium-id=address_street>", "</span>").replaceAll("&nbsp;", "");
				add[1]=U.getSectionValue(mapHtml, "<span data-selenium-id=address_city>", "</span>");
				add[2]=U.getSectionValue(mapHtml, "<span data-selenium-id=address_state>", "</span>");
				add[3]=U.getSectionValue(mapHtml, "<span data-selenium-id=address_zip>", "</span>");
				latLng= U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				geo = "TRUE";
			}

			if(add[0]==ALLOW_BLANK && latLng[0]==ALLOW_BLANK) {
				String addSec= U.getSectionValue(html, "<p class=\"content__address h-no-tracking\">", "</div>");
				add=U.findAddress(addSec);
				add[0]=add[0].replaceAll("Annapolis|,", "");
	
				
				U.log(add[0]+"\thhh\t"+add[1]+"\thhh\t"+add[2]+"\thhh\t"+add[3]);
				String laString=U.getSectionValue(html, "<div class=\"marker\"", "</div>");
				if(laString!=null) {
					latLng[0]=U.getSectionValue(html, "data-lat=\"", "\"");
					latLng[1]=U.getSectionValue(html, "data-lng=\"", "\"");
				}
			}

			String planHtml = U.getHTML(url + "/homes.aspx");
			if (planHtml != null) {
				if (planHtml.contains("<ul class=\"nav nav-tabs big-tabs\">")) {
					String homeSec = U.getSectionValue(planHtml, "<ul class=\"nav nav-tabs big-tabs\">", "</ul>");
					String homeUrl[] = U.getValues(homeSec, "<a href=", ">");
					for (String u : homeUrl) {
						planHtml = planHtml + U.getHTML(url + "/" + u);
					}
					
				}
			}
			String feturHtml = U.getHTML(url + "/features.aspx");
			String extrainfo = U.getHTML(url + "/available-retail-space.aspx");

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String prices[] = U.getPrices(sec + html + planHtml + extrainfo,
					"\\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|price-text>\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} BASE PRICE", 0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log(prices[0]+"\t\t"+prices[1]);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String sqft[] = U.getSqareFeet(sec + html + extrainfo+planHtml , "<li>\\d,\\d{3} SQ.FT|\\d{4} SQ. FT.|<li>[0-9]{3} SQ.FT", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SRFIT::::::"+minSqft+"\t\t"+maxSqft);
			String comType = U.getCommType((sec + html + feturHtml).replace("waterfront parks", ""));

			String propType = U.getPropType((sec + html + feturHtml).replaceAll("ApartmentComplex", ""));

			String dType = U.getdCommType((sec + html + feturHtml + planHtml).replaceAll("1st Floor, Bethesda, MD\"|branchID|Branch|Multi-level", ""));

			String propStatus = U.getPropStatus((sec + html + feturHtml).replaceAll("FEE for a LIMITED TIME ONLY|Brand New Apartments Coming 2023", ""));
			
			
			
			if(url.contains("http://homesatuplands.com"))minSqft = "1916";
			if(url.contains("https://www.emblembarracksrow.co"))propStatus="Only One Penthouse Left";
			if(data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url + "==========>Repeated");
				return;
			}
				if(add[1].contains("New York / New Jersey / Connecticut Apartments")||add[1].contains("NoMa/Union Market")) {
					add=U.getAddressGoogleApi(latLng);
					
				}

			if(url.contains("https://www.bozzuto.com/apartments/unknown/nj/edge"))add[1]="Bayonne";
			LOGGER.AddCommunityUrl(url);
			data.addCommunity(name.replace("Sedona|slate", "Sedona Slate").toLowerCase().trim(), url, comType);
			data.addAddress(add[0].replace(",", ""), add[1], add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(ALLOW_BLANK);
		}

	
	}

	
}


