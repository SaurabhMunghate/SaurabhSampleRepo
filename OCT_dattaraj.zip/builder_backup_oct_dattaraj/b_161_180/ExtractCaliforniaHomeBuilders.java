/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_161_180;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractCaliforniaHomeBuilders extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractCaliforniaHomeBuilders()throws Exception {
		super("California Home Builders","https://www.calhomebuilders.com/");
		LOGGER=new CommunityLogger("California Home Builders");
	}


	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCaliforniaHomeBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"California Home Builders.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}
	
	@Override
	protected void innerProcess() throws Exception {


		String html = U.getHTML("https://calhomebuilders.com/projects/#");
		String section = U.getSectionValue(html, "<button type=\"submit\" class=\"btn btn-primary btn-block\">", "<footer id=\"colophon\" class=\"site-footer\">");
		String[] comSections = U.getValues(section, "<div class=\"portfolio-content-inner\">", "</div>");
		U.log("Total ComSections :: "+comSections.length);
		
		for(String commSec : comSections){
			String commUrl = U.getSectionValue(commSec, "<a href=\"", "\"");
			addDetails(commUrl,commSec);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String cityData) throws Exception {
		// TODO Auto-generated method stub
		
		//Single Run
//		if(!comUrl.contains("https://calhomebuilders.com/portfolio/toscana/")) return;

		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"::::::::::::::::::repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log("commUrl-->"+comUrl);
		

		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(U.getHtmlSection(cityData, "<h2 class=\"entry-title\">", "</h2>"), "/\">","</a>").replace("&#038;", "&").replace("&#8211;", "-");
		U.log("Community Name---->"+communityName);
		
		
		
		String html=U.getHTML(comUrl);
		String visitUrlHtml=ALLOW_BLANK;
		String visitWebsiteUrl=U.getSectionValue(html, "<a class=\"breadcrumb-projects\" href=\"", "\"><span>visit website");
		U.log("visit Url :: "+visitWebsiteUrl);
		
		if(comUrl.equals("https://calhomebuilders.com/portfolio/the-ridge/")) {
			visitWebsiteUrl = "https://calhomebuilders.com/portfolio/the-ridge/#";
		}
		
		//check here---
		if(visitWebsiteUrl.equals("#")) visitWebsiteUrl = comUrl + "#";
		
		if(visitWebsiteUrl!=null) {
			visitUrlHtml=U.getHTML(visitWebsiteUrl);
		}
		
		String amenitiesSecCheck=U.getSectionValue(visitUrlHtml, "<a data-selenium-id=\"mobile_amenitiesaspx_MenuLink\"", "</a>");
		String floorSecCheck=U.getSectionValue(visitUrlHtml, "<a data-selenium-id=\"mobile_floorplansaspx_MenuLink\"", "</a>");
		String floorSecCheck2=U.getSectionValue(visitUrlHtml, "<a class=\"dropdown-item\" data-selenium-id=\"mobile_floorplansaspx_ActualMenuLink\"", "</a>");
		
		String amenitiesHtml=ALLOW_BLANK;
		if(amenitiesSecCheck!=null) {
			amenitiesHtml=U.getHTML(visitWebsiteUrl+"amenities");
			U.log("amenities ::"+visitWebsiteUrl+"amenities");
		}
		
		String floorHtml=ALLOW_BLANK;
		if(floorSecCheck!=null || floorSecCheck2!=null) {
			floorHtml=U.getHTML(visitWebsiteUrl+"floorplans");
			U.log("floorplans ::"+visitWebsiteUrl+"floorplans");
		}
		
		
		String removeSec=U.getHtmlSection(html, "Plans</h2>", "");
		if(removeSec!=null)
			html=html.replace(removeSec, "");
		
		String SqftSection=U.getHtmlSection(html, "Area </span>", "\">Apartments</span>");
		if(SqftSection==null){
			SqftSection= ALLOW_BLANK;
		}else {
			SqftSection=U.getNoHtml(SqftSection);
		}
		String priceSection=U.getHtmlSection(html, "Price Range", "<div class=\"single-portfolio-summary-content\">");
		if(priceSection!=null) {
			priceSection=U.getNoHtml(priceSection);
			priceSection=priceSection.replace("k", ",000");
		}
		else {
			priceSection=ALLOW_BLANK;
		}
		//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String note=ALLOW_BLANK;
		
		int sec=1;
		String addSec=U.getSectionValue(visitUrlHtml, "<div itemprop=\"address\">", "</address>");
		
		if(addSec==null) {
			addSec=U.getSectionValue(html,"Location </span><span class=\"meta-value\">","</span>");
			sec=2;
		}
		
		if(addSec!=null && sec==1) {
			add[0]=U.getSectionValue(addSec, "address_street\">", "</div>").trim();
			add[1]=U.getSectionValue(addSec, "address_city\">", "</span>").trim();
			add[2]=U.getSectionValue(addSec, "address_state\">", "</span>").trim();
			add[3]=U.getSectionValue(addSec, "address_zip\">", "</span>").trim();		
		}
		
		if(addSec!=null && sec==2)
		{
			String addS[] = addSec.split(",");
			if(addS[1].contains("USA")) {
				add[1]=addS[0];
				add[2]=USStates.abbr(addS[0]);
			}else {
				add[1]=addS[0];
				add[2]=addS[1];				
			}
			latlag=U.getlatlongGoogleApi(add);
			add= U.getAddressGoogleApi(latlag);
			geo="True";
			note="Address and Latlong taken from City and State";
		}
		
		String latLongSec=U.getSectionValue(visitUrlHtml, "<div class=\"ysi-button-widget ysi-button-wrapper mt-4\">", "Get Directions");
		if(latLongSec!=null) {
			String latUrl=visitWebsiteUrl+"mapsanddirections";
			if(!latUrl.contains("dronfieldastoria.com/mapsanddirections")){
			String latlongHtml=U.getHTML(latUrl);
				latLongSec=U.getSectionValue(latlongHtml, "https://maps.google.com/maps?q=", "\"");
				if(latLongSec==null) latLongSec=U.getSectionValue(latlongHtml, "https://www.google.com/maps/place/Legacy&#x2B;Apartments/@", ",17z");
				if(latLongSec==null) 
					latlag[0]=U.getSectionValue(latlongHtml, "latitude: \"", "\"");
					latlag[1]=U.getSectionValue(latlongHtml, "longitude: \"", "\"");
				
				if(latLongSec!=null) {
					latlag=latLongSec.split(",");
				}				
			}
		}
		
		if(add[0]!=ALLOW_BLANK && add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK) {
			latlag=U.getlatlongHereApi(add);
			geo="True";
		}

		U.log("Latag :: "+Arrays.toString(latlag));
		U.log("Address :: "+Arrays.toString(add));
		U.log("GeoCode :: "+geo);
		U.log("Note :: "+note);
		
		
		//============================================Price and SQ.FT======================================================================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] Prices = U.getPrices(visitUrlHtml+priceSection, "\\$\\d{2,3},\\d{3}", 0);
		minPrice = (Prices[0] == null) ? ALLOW_BLANK : Prices[0];
		maxPrice = (Prices[1] == null) ? ALLOW_BLANK : Prices[1];
		U.log("MinPrice :: "+minPrice+" MaxPrice :: "+maxPrice);
		
		//======================================================Sq.ft===========================================================================================		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] area ={ALLOW_BLANK,ALLOW_BLANK};
		area=U.getSqareFeet(floorHtml+visitUrlHtml+SqftSection, "</span>\\d,\\d{3} Sq. Ft.</div>|</span>\\d{3} Sq. Ft.</div>|\\d,\\d{3} and \\d,\\d{3} square feet|</span>\\d,\\d{3} Sq.Ft.|</span>\\d{3} Sq.Ft.|\\d{3,4} - \\d{3,4} Sq ft", 0);
		minSqft = (area[0] == null) ? ALLOW_BLANK : area[0];
		maxSqft = (area[1] == null) ? ALLOW_BLANK : area[1];
		U.log("MinSqft :: "+minSqft+" MaxSqft :: "+maxSqft);
		
//		U.log("MMMMM"+Util.matchAll(floorHtml+visitUrlHtml+SqftSection, "[\\w\\s\\W]{60}710[\\w\\s\\W]{60}", 0));
		
		//================================================community type========================================================
		String communityType=U.getCommType((amenitiesHtml+visitUrlHtml+html+cityData).replace("Gated Parking", ""));
		U.log("Community Type :: "+communityType);	
				
		//==========================================================Property Type================================================
		String proptype=U.getPropType((amenitiesHtml.replace("patio-balcony", "")+visitUrlHtml.replace("and Patio\"", "")+html+cityData)
				.replaceAll("common |COMMON |Common ", "")
				.replace("courtyard\">", "")
				.replaceAll("Condo|condo", "").replaceAll("Multi|multi", ""));
		U.log("Property Type :: "+proptype);		
						
		//==================================================D-Property Type======================================================
		String dtype=U.getdCommType(amenitiesHtml+visitUrlHtml.replace("TWO STORY, STATE-", "")+html);
		U.log("D-Property Type :: "+dtype);		
		
		
		visitUrlHtml=visitUrlHtml.replace("<div class=\"display-3 letter-spacing-1 font-heading font-weight-bold \">", "");
		//==============================================Property Status=========================================================
		String pstatus=U.getPropStatus((html+cityData+visitUrlHtml.replace("READY TO MOVE IN?</a>", "")));
//		U.log("MMMMM"+Util.matchAll(amenitiesHtml+visitUrlHtml+html+cityData, "[\\w\\s\\W]{100}patio</div>[\\w\\s\\W]{10}", 0));
		U.log("Property Status :: "+pstatus);		
		
		note=U.getnote(visitUrlHtml.replace("NOW</div>\n" + 
				"                            LEASING", " NOW LEASING"));
		
		data.addCommunity(communityName.toLowerCase(),comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus.replace("Coming Fall 2021, Coming 2021", "Coming Fall 2021"));
		data.addNotes(note); 
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
	
		j++; 
	}

}