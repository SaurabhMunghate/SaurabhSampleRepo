/**@author Aditya.
 * Date- 02-06-2015
 * Date Modified-03-06-2015
 * 
 */

package com.shatam.b_161_180;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.jxpath.ri.compiler.Step;
import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

import net.sourceforge.htmlunit.corejs.javascript.ast.CatchClause;

public class ExtractGardnerHomesBuilder extends AbstractScrapper {

	public static String HOME_URL = "https://www.gjgardner.com/";
	static int j = 0;
	CommunityLogger LOGGER;

	public ExtractGardnerHomesBuilder() throws Exception {
		super("G.J.Gardner Homes", HOME_URL);
		LOGGER = new CommunityLogger("G.J.Gardner Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractGardnerHomesBuilder();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "G.J.Gardner Homes.csv", a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {

		String cmHtml = "https://www.gjgardner.com/home-builders/";
		String stateHtml = U.getHTML(cmHtml);

//		String regionSection = U.getSectionValue(stateHtml, "<section class=\"page-columns", "</section>");
		String regionSection = U.getSectionValue(stateHtml, "G.J Gardner Offices", "</section></div>");
		U.log("regionSection: "+regionSection.length());
		
		ArrayList<String> urls = Util.matchAll(regionSection, "<li><a.+>", 0);

		for (String regUrl : urls) {

			String url = U.getSectionValue(regUrl, "href=\"", "\"");
			U.log("url: "+url);
			
			addComDetails(url, regUrl);
			//break;
		}
		
		LOGGER.DisposeLogger();
	}

	public void addComDetails(String url, String dataSec) throws Exception {
	//	if( j>= 80)
//		if( j>= 50 && j<= 80)
//		if( j>= 80 && j<= 110)
		{
//			if(!url.contains("https://www.gjgardner.com/home-builders/california/san-diego-north-county-9333/")) return;
//			
			// ******************Community Url***************************
			 
			 if (data.communityUrlExists(url)) {
					LOGGER.AddCommunityUrl(url + "-------------repeat------------");
					return;
				}
			 LOGGER.AddCommunityUrl(url);
			 
			String geoCode = "FALSE";
			String commUrl = url;
			U.log("Count ===" + j);
			if (commUrl.contains(
					"https://www.gjgardner.com/lafayette-home-builders/communities/beautiful-bridgeview-lot-in-monticello-with-lake-access-2217.aspx"))
				return;// redirect
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/acerage-homesites-702.aspx"))return;// redirect
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/spactacular-1-acre-homesites-535.aspx"))return;// redir
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/central-location-536.aspx"))return;// redirect
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/gorgeous-acreage-community-516.aspx"))return;// redir
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/gorgeous-acreage-community-516.aspx"))return;
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/spectacular-gated-community-in-roxborough-518.aspx"))return;
			// redirhttps://www.gjgardner.com/lafayette-home-builders/communities/stanfield-ridge-huge-lots-minutes-from-purdue-740.aspx
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/spectular-forested-homesites-534.aspx"))return;// redir
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/timber-ridge-estate-homesites-701.aspx"))return;// redir
			if (commUrl.contains("https://www.gjgardner.com/z-douglas-county-home-builders/communities/timber-ridge-estate-homesites-703.aspx"))return;// redir
			
			//community not found on region returning. CHECK NEXT TIME.
			if(url.contains("https://www.gjgardner.com/home-builders/texas/san-antonio-south-7161/")) return; 
			
			
			String commHtml = U.getHTML(commUrl);
			// String communityUrl = HOME_URL + commUrl;
			U.log("***********" + commUrl);

			String planhtml = ALLOW_BLANK;
			// PLANS
			String Fhtml = "";

			String id = Util.match(url, "\\d+");
			planhtml = U.getHTML("https://www.gjgardner.com/wp-json/hi-api/v1/properties?office-id="+id);
			String pageUrls[]= U.getValues(planhtml, "<a class=\\\"page-numbers\\\" href=\\\"", "\\\"");
			U.log(pageUrls.length);
			for(String urls:pageUrls) {
				U.log(StringEscapeUtils.unescapeJava(urls));
				String formattedUrl = StringEscapeUtils.unescapeJava(urls);
				planhtml += U.getHTML(formattedUrl);
			}
			U.log("planhtml: "+"https://www.gjgardner.com/wp-json/hi-api/v1/properties?office-id="+id);
			
			if(planhtml!=null)
			planhtml = planhtml.replace("Craftsman, Spanish", "Craftsman Style Home, Spanish");
			// ******************Community Prices*************************

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			commHtml = commHtml.replaceAll("0`s|0's|0&#39;s", "0,000");
			// U.log(U.getSectionValue(commHtml, "Enjoy Colorado living at Forest", "this
			// special community offers easy"));
			commHtml = commHtml.replace("$400 - $2,000,000", "$400,000 - $2,000,000");
			
			commHtml = commHtml.replace("0s", "0,000");
			
			commHtml = commHtml.replaceAll("0s|0&#39;s", "0,000");
			// U.log("@@@@@@@@@@"+commHtml);
			String[] price = U.getPrices(planhtml+commHtml,
					"\"property_sale_price\":\"\\d+\"|<div class=\"listing-price\">\\s*\\$\\d{3},\\d{3}",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("minPrice: "+minPrice);
			U.log("maxPrice: "+maxPrice);

			// ******************Community Area [SqrFeet]******************
			String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet( planhtml,
					"\"property_floor_size\":\"\\d+\"|land_size\":\"\\d+",
					0);

			minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("minSqFeet: "+minSqFeet +" maxSqFeet: "+maxSqFeet);
			
//			U.log(Util.matchAll(planhtml, "[\\w\\s\\W]{30}36496[\\w\\s\\W]{90}", 0));

			// ******************Community Address, Lat And lng**************

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = {ALLOW_BLANK,ALLOW_BLANK}, lng = ALLOW_BLANK;
			String note = ALLOW_BLANK;
			commHtml = commHtml.replace("amp; ", " ");
			
			latLng[0] = U.getSectionValue(commHtml, "data-val-lat='", "'");
			latLng[1] = U.getSectionValue(commHtml, "data-val-lng='", "'");
			
			U.log("LATLONG: "+Arrays.toString(latLng));
			
			if(latLng[0] == null) {
				
				String latlongSec = U.getSectionValue(commHtml, "https://www.google.com.au/maps/place", "data=");
				if(latlongSec == null) latlongSec = U.getSectionValue(commHtml, "https://www.google.com/maps/place", "data=");
				U.log("latlongSec: "+latlongSec);
				
				latLng[0] = U.getSectionValue(latlongSec, "@", ",");
				latLng[1] = Util.match(latlongSec, "\\-\\d{2,3}.\\d+");
				
				U.log("LATLONG INSIDE: "+Arrays.toString(latLng));
			}
			
			
			String streetAddress = U.getSectionValue(commHtml, "<h4 class=\"address\">", "</h4>");
			U.log(streetAddress);
			
			//storing street 
			String streetFromCom = ALLOW_BLANK;	
			
			if(streetAddress != null) {
			streetAddress = streetAddress.replace("<p>00 eagle dr", "<p>eagle dr").replace("Texas,", "TX")
					.replace("California,", "CA").replace("Colorado,", "CO").replace("Florida,", "FL").replace("Indiana,", "IN")
					.replace("119 S. Douty St.", "119 S. Douty St, .")
					.replace("700 Alhambra Blvd.", "700 Alhambra Blvd, .").replace("4705 W 38th Ave", "4705 W 38th Ave,")
					.replaceAll("Blvd.", "Blvd, .").replace("2821 Oceanside Blvd., Suite A", "2821 Oceanside Blvd,")
			.replaceAll(", USA|Reserve at Sonoma Verde|Alsatian Ridge|By Appointment|Redlands Mesa - Golf Course|Bridle Hill,|, Highpointe Estates", "").replace("BRADENTON", "Bradenton").replace("Severance ", "Severance,").replace("Windsor ", "Windsor,");
			
			U.log("streetAddress===>" + streetAddress);
			
		
			if(streetAddress.contains(",")) {
				//check condition above imp. street must have comma
				
				String[] street = streetAddress.split(",");
				U.log("street[0]: "+street[0]);
				
				streetFromCom = street[0];
				U.log("streetFromCom: "+streetFromCom);
			}
			else {
				//adding comma only if streetAddress present
				
				streetAddress = streetAddress + ", . ";
				
				String[] street = streetAddress.split(",");
				U.log("street[0]: "+street[0]);
				
				streetFromCom = street[0];
				U.log("streetFromCom from else: "+streetFromCom);
			} 
			
			add = U.getAddress(streetAddress);
			
			U.log("Address===>" +Arrays.toString(add));
			
			}
			
			
			
			if(add[0].length()<4 && latLng[0].length()>4 || add[2] == null && latLng[0].length()>4)
			{
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getGoogleAddressWithKey(latLng);
				if(add== null) add = U.getAddressHereApi(latLng);
				geoCode = "TRUE";
				
				U.log("Address from API===>" +Arrays.toString(add));
			}
			
			
			
			//changing street in gogle address with street from comPage
			if(streetFromCom != ALLOW_BLANK && add[0] != ALLOW_BLANK) {
				
				add[0] = streetFromCom;
			}
			
			U.log("Address Final===>" +Arrays.toString(add));
			
			// ******************Community Name*****************************

			String nameSec[] = U.getValues(dataSec, "title=\"", "\"");
			U.log(commUrl);
			String comName = nameSec[0];

			comName = comName.trim();

			
			// At index..
			U.log(comName);
			comName = comName.replaceAll("Community|, Pool, Play", "").replace("| Oceanside CA", "").toLowerCase();
			comName = comName.replace("| ca", "").replaceAll("two buildable lots in one - |3 lots available in | lot available in , in|take a look at | -2 lots available in central fort collins|1 lot left in a prime lakefront community|-15 minutes nw of fort collins!| luxury\\s*\\|\\s*westminster, co| - 7 lots left!| - available spring of 2019!!|offering luxury amenities at |79 lots available in 2019|final community|final 10 units available for sale| ~ berthoud", "");
			U.log("comName : "+comName);
			

			// -------remove common section-------
			commHtml = U.removeSectionValue(commHtml, "city-region homepage-popup", "</nav>");
			commHtml = U.removeSectionValue(commHtml, "ContentPlaceHolderDefault_MobileMenu_14_UsaPanel", "</nav>");

			planhtml = U.removeSectionValue(planhtml, "city-region homepage-popup", "</nav>");
			planhtml = U.removeSectionValue(planhtml, "ContentPlaceHolderDefault_MobileMenu_14_UsaPanel", "</nav>");

			Fhtml = U.removeSectionValue(Fhtml, "city-region homepage-popup", "</nav>");
			Fhtml = U.removeSectionValue(Fhtml, "ContentPlaceHolderDefault_MobileMenu_14_UsaPanel", "</nav>>");
			// -----------------------------------------
			// ****************** Property Status ********************************
			String rem1 = U.getSectionValue(commHtml, "<h2>Location</h2>", "</body>");
			commHtml = commHtml.replace("Only a few lots are still available","Only few lots available").replace("three stunning lots that are now available ", "three lots now available").replace("wooded lots are available", "wooded lots available").replaceAll(
					"lots are available|title: \"Now Available\"|Now Available</a>|Village|village|tapatio|Tapatio|Patio Home Living|patio-home-living|Open Space and Luxury|open-space-and-luxury|Franchise|franchising|Branch|Beautiful Golf Course|Redlands Mesa - Golf Course|beautiful-golf-course|redlands-mesa-golf-course|resort-style-lake|Resort Style &amp|resort-style-community|Resort-Style Community|Resort Style Living|resort-style-living|Resort Style & Lake|resort-style-and-lake",
					"");
			commHtml = commHtml.replace("Craftsman or Spanish style", "Craftsman Style Home")
					.replace(" bungalows & Victorians", "bungalow style homes").replace(" setting for your luxurious", "luxury home").replace("estate lots left", "Estate-size home lots left");
			String remove = U.getSectionValue(commHtml, "class=\"multiLocationMap row\">", " </body>");
			if (remove != null)
				commHtml = commHtml.replace(remove, "");
			commHtml = commHtml //.replace("variety of available lots", "lots available")
					.replaceAll("Lots Available In 2019|lots available in 2019|school grand opening 2021|lots that are now available|something move-in ready|Franchise|franchising|franchise|Franchises|available, the only|sites are now", "")
					.replaceAll("Homesites are selling fast", "Homesites selling fast").replace("only 6 (1+ acre) estate lots left", "only 6 lots left").replaceAll("32 Lots are NOW available", "32 Lots Now Available");
			commHtml = commHtml.replaceAll("coming spring of 2018|COMING SPRING OF 2018", "coming spring 2018")
					.replaceAll("COMING SPRING OF 2019", "COMING SPRING 2019").
					replace("Homesites are selling fast", "Homesites selling fast")
					.replaceAll("Available Spring of 2019", "Available Spring 2019").replace("2 lots still available", "2 lots available").replaceAll("lot is still available|lots are still available", "lots available")
					.replace("Only a few lots are still available", "Only a few lots available").replace("Only 7 lots are still available", "Only 7 lots available")
					.replace("Only 9 lots are still available", "Only 9 lots available")
					.replace("Walkout basment lots available", "Walkout basement lots available").replace("Only 4 lots are still available", "Only 4 lots available")
					.replaceAll("courtyard entrance|property_design_n, er&rsquo;s proposed Courtyard|\"Courtyard\"|\"Courtyard\"", "");
//			
			String propertyStatus = U.getPropStatus(commHtml);
			U.log(propertyStatus);
			if(commUrl.contains("bennett-co-antelope-hills-936.aspx"))comName="Antelope Hills";
			// ****************** Community Type ********************************
			String communityType = U.getCommunityType(commHtml.replace("&ndash;", "-") + commUrl);
			
			// ****************** Derived Community Type ********************************
			commHtml = commHtml.replace("traditional, victorian, colonial, mid-century modern, or craftsman", "styles such as traditional, craftsman, The Colonial").replaceAll(" Story | story ", " Story,");
			String derivedPropertyType = U.getdCommType(((commHtml + planhtml).replaceAll("Old Ranch|\"\\d Story\"|Rancho", ""))
					.replaceAll("single and double story", " 1 story  2 story ").replace("singleStory", "single Story")); // commHtml+
//			U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{30}Story[\\w\\s\\W]{30}", 0));

			// ****************** Property Type ********************************
			planhtml = U.getNoHtml(planhtml);
			commHtml = commHtml.replaceAll("Meditteranean or Hill Country style home|Meditteranean or Hill Country style home", "Mediterranean-Style Homes or Hill Country style home")
					.replace("craftsman, modern farmhouse, traditional or mediterranean", "craftsman homes, modern farmhouse, traditional homes or Mediterranean-Style Homes ")
					.replace("modern farmhouse, or traditional,", "modern farmhouse, or traditional homes,").replace("coastal, contemporary", "coastal homes").replaceAll("craftsman, modern,| modern, craftsman,", "Craftsman style details").replaceAll("Custom build your dream home|custom, country dream home|Custom built homes", "exceptional custom home").replace(" prime luxury ", "luxury homes").replace("Build your custom, country", "Build your custom home design");
	
			String propertyType = U
					.getPropType((commHtml + planhtml).replace("luxury estate", "luxury home, estate").replace("Custom GJ Gardner home", "this custom home")
							.replaceAll("Old Ranch|Cottage Home\"|NO HOA community|With no HOA restrictions|Custom Home Consultant|and Luxury|Traditional Country|Condos</a>|-condos-|>Cottage|custom_|custom-|-custom", ""));
			
//			U.log(Util.matchAll(commHtml+ planhtml + Fhtml, "[\\w\\s\\W]{20}Cottage[\\w\\s\\W]{20}", 0));

		
	
			//------remove community name from street address
			add[0] = add[0].toLowerCase().replaceAll("^"+comName.toLowerCase()+", ", "");
			
			U.log("add1" + add[0]);
			if(add[0].startsWith("0"))
			add[0] = add[0].replace("00 eagle dr", "eagle dr");
			
			data.addCommunity(U.getCapitalise(comName), commUrl, communityType);
			data.addAddress(add[0].replace("- golf course", "").replaceAll(";|#|,", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geoCode);
			data.addPropertyType(propertyType, derivedPropertyType);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFeet, maxSqFeet);
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
		
	}
	
	public static String[] getAddress(String line) {
		String[] ad = line.split(",");

		String[] add = new String[] { "-", "-", "-", "-" };
		int n = ad.length;
		//U.log("ad length is ::"+ad.length);
		if (ad.length >= 3) {
			for (int i = 0; i < n - 2; i++)
				add[0] = (i == 0) ? ad[i].trim() : add[0] + ", " + ad[i].trim();
			add[0] = add[0].trim().replaceAll("\\d+.\\d+\\s*,\\s*-\\d+.\\d+",
					"");
			add[1] = ad[n - 2].trim();// city
			
			add[2] = Util.match(ad[n - 1], "\\w+", 0); // State--or-->\\w+ OR
			
											// [a-z\\sa-z]+
			add[2] = (add[2] == null) ? "-" : add[2].toUpperCase();
			if (add[2] == null)
				add[2] = "-";
			if (add[2].length() > 2)
				add[2] = USStates.abbr(add[2]);
			add[3] = Util.match(ad[n - 1], "\\d{5}", 0);
			if (add[3] == null)
				add[3] = "-";
		}
		for (int i = 0; i < 1; i++) {
			if (!add[i].equals("-") && add[i].length() < 3)
				add[i] = "-";
		}

		return add;
	}
}