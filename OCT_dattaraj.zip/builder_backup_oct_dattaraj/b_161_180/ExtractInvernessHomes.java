package com.shatam.b_161_180;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractInvernessHomes extends AbstractScrapper 
{
	int i = 0;
	static int j=0;
	public int inr = 0;
	public static CommunityLogger LOGGER;
	public ExtractInvernessHomes() throws Exception 
	{

		super("Inverness Homes", "https://www.invernesshomesusa.com/");
		LOGGER=new CommunityLogger("Inverness Homes");

	}

	public static void main(String[] args) throws Exception 
	{

		AbstractScrapper a = new ExtractInvernessHomes();

		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Inverness Homes.csv", a.data().printAll());
	}


	public void innerProcess() throws Exception 
	{
		String url = "https://www.invernesshomesusa.com/";
		String html = U.getHTMLwithProxy(url);
		String regSec=U.getSectionValue(html, "COMMUNITIES</span> <span class=\"fusion-caret\">", ">ABOUT US</span>");
		U.log(regSec);
		String regUrls[]=U.getValues(regSec, "<a  href=\"", "\"");
		for(String reg:regUrls) {
			if(reg.contains("/about-us"))continue;
			U.log(reg);
			String regHtm=U.getHTMLwithProxy(reg);
			String comSec[]=U.getValues(regHtm, "\"title", ",\"custom_filters\":[]}");
			for(String sec:comSec) {
				String comurl=ALLOW_BLANK;
//				if(sec.contains("{marker_title}"))continue;
				comurl=StringEscapeUtils.unescapeJava(U.getSectionValue(sec, "<a href=", ">"));
				U.log("Sec::::::::::::::::::\n"+StringEscapeUtils.unescapeJava(sec)+"\n::::::::::::endSec");
				if(!comurl.contains("https"))
				comurl="https://www.invernesshomesusa.com"+comurl;
				addDetails(comurl.replace("\"", ""), sec);
			}
		}
		LOGGER.DisposeLogger();
//		String secPage = U.getSectionValue(html, "title=\"Our Communites\"","<li class=\"node1\">");
//		String pageLink[] = U.getValues(secPage, "<a href=\"", "\"");
//		for (String itom : pageLink) 
//		{
//			U.log(itom);
//			itom = "https://www.invernesshomesusa.com/" + itom;
//			html = U.getHTMLwithProxy(itom);
//			//U.log(html);
//			String section = U.getHtmlSection(html,
//					"<div id=\"communities-grid\">", " <div class=\"span4\">");
//
//			String values[] = U.getValues(section, "data-url=\"", "\"");
//
//			for (String link : values) 
//			{
//				//U.log(" page url :" + url + link);
//
//				addDetails(url + link);
//
//			}
//
//		}

	}

	private void addDetails(String comUrl,String comsec) throws Exception {
//				if(j==0)
				{
					//U.log("count::::::::::::"+j+":::::::::::::::::::::::::");
				String commName = null, street = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK, city = ALLOW_BLANK, latitude = ALLOW_BLANK, longitude = ALLOW_BLANK, minSq = ALLOW_BLANK, maxSq = ALLOW_BLANK;
				String pType = ALLOW_BLANK, status = ALLOW_BLANK, maxPrice = ALLOW_BLANK, minPrice = ALLOW_BLANK;
				U.log("Page Community:" + comUrl);
//				comUrl=comUrl.replace("/greenshire-commons/", "/greenshire-commons").replaceAll("bluffs-on-trebein/", "bluffs-on-trebein/");
				if(comUrl.endsWith("/")) {
					comUrl=comUrl.replaceAll("/$", "");
				}

				String comHtml = U.getHTMLwithProxy(comUrl);
				comHtml=comHtml.replace("We are NOW SELLING","");
				
//				if(!comUrl.contains("https://www.invernesshomesusa.com/dayton-ohio/trails-of-greycliff"))return;
				

				// community name

				commName = U.getSectionValue(comHtml, "<h1 class=\"title-heading-left\">", "</h1>");
				 U.log("Community Name:-"+commName);
				// address
				String add[] = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
						ALLOW_BLANK };

				String secmap = U.getSectionValue(comHtml, "><div class=\"fusion-text\">",
						"<br");
				U.log(secmap);
				if(secmap.contains("OH,"))secmap=secmap.replaceAll("OH,", "OH");
				add=U.findAddress(secmap);
				if(secmap!=null && add==null) {
					add=U.getAddress(secmap);
					add[0]=U.getNoHtml(add[0]);
				}

				// =====================lat and lng==========================
				String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
				latLng[0]=U.getSectionValue(comsec, "\"lat\":\"", "\"");
				latLng[1]=U.getSectionValue(comsec, "\"lng\":\"", "\"");
				String planhtml="";
				String AllPlanData="";
				String[] plans=U.getValues(comHtml, "<h2 class=\"entry-title fusion-post-title\">", "</a>");
				for(String plan:plans)
				{
					plan=U.getSectionValue(plan, "href=\"", "\"");
					U.log(":::::::::::::::::::::::::::::::::::"+plan);
					planhtml=U.getHTMLwithProxy(plan);
					AllPlanData += U.getSectionValue(planhtml, "<div class=\"fusion-title title fusion-title-size-three\" ", "Download Design</span>"); 
				}
				// =============================Price=============================================
				String secremove = U.getSectionValue(comHtml, "<div class=\"wpgmp_map_container", "</body>");
				comHtml=comHtml.replace(secremove, "");
//				U.log(Util.matchAll(comsec, "[\\w\\s\\W]{30}\\$300[\\w\\s\\W]{30}", 0));
				comsec=comsec.replaceAll("\"name\":\"\\$\\d{3}-\\$\\d{3},\\d{3}\"|<option value=\".*</option>", "").replace("0's", "0,000");
				U.log(comHtml.contains(secremove));
				
			
				comHtml=comHtml.replace("#8217;s", ",000");
				String price1[] = U.getPrices(comHtml+comsec+AllPlanData,
						"<td class=\"currency\">\\d{6}|\\$\\d+,\\d+", 0);
				if (price1[0] != null) {
					minPrice = price1[0];
					U.log("Minprice" + minPrice);
				}
				
				if (price1[1] != null)
					maxPrice = price1[1];
				U.log("maxPrice" + maxPrice);
				String sqft[] = U.getSqareFeet(comHtml, "\\d{4} sq. ft.|[0-9]{1},[0-9]{3} sq. ft.", 0);
				minSq = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSq = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

				// Community Type
				String drop=U.getSectionValue(comHtml, "<script type=\"text/javascript\">", "</script>");
				if(drop!=null)
					comHtml=comHtml.replace(drop, "");
				comHtml=comHtml.replace("Move-In Ready Homes", "").replace("Move", "");
				comHtml=comHtml.replace("lots available.", "");
				comHtml=comHtml.replace("now open! Inverness", "").replace("s now open at Landings at Sugarcreek", "").replace("New Phase of Homesites Just Released", "New Phase Homesites Just Released");
				comHtml=comHtml.replaceAll("map-desc\"><h2>New Section Now Selling|<h2>New Model Now Open!|\"Sinclair\" Now Open", "").replace("We are now selling at Landings", "").replace("New Model Now Open!", "").replace("move", "");
				comHtml=comHtml.replace("now open","").replace("NOW OPEN","").replace("Now Open","");
				String pStatus = U.getPropStatus(comHtml);
				comHtml=comHtml.replaceAll("villas|Villas", "");
				String newname=commName.replaceAll("village|Village", "");
				
				if(drop!=null)
					comHtml=comHtml.replace(drop, "");
				
				//U.log("::::::::::::::::::::::::::::::::::"+planhtml);
				pType = U.getPropType((AllPlanData.replaceAll("villas_at|villas-at-kettering-pointe|Villas at Kettering Pointe", "")+comHtml).replaceAll("village|Village|Carriage|carriage_trails|carriage", "")+newname);
				U.log("Property type::::"+pType);

				String geo = "false";
				latitude=latLng[0];
				longitude=latLng[1];
				String[] latlng = { latitude, longitude };

				if (comHtml.contains("font-weight: 600;\">AVAILABLE</p>") || comHtml.contains("font-weight: 600;\">PENDING</p>")) {
					{
						if (pStatus.length() > 1) {
							pStatus = pStatus + ", Quick Move-in Homes";
						} else
							pStatus = "Quick Move-in Homes";
					}
				}
				if(add[0]==ALLOW_BLANK && latitude!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlng);
					geo="true";
				}

				String comHtm=comHtml;
				
				String communityType="";
				String dType="";
				if(comHtm!=null)
				{
//					comHtm=U.getSectionValue(comHtm, "<div class=\"community-desc\"", "</div>")+U.getSectionValue(comHtm, "\">Recreation</a>", "</table>");
//					comHtm=comHtm.replaceAll("Pipestone Golf Course|Community Golf Course", "");
//					U.log(Util.matchAll(comHtm,"[\\w\\s\\W]{30}golf[\\w\\s\\W]{30}",0));

					communityType=U.getCommType(comHtm);
				}
				String remSliderBar=U.getSectionValue(comHtml, "<div class=\"sidebar\">", "</ul>");
				if (remSliderBar!=null) {
					comHtml=comHtml.replace(remSliderBar, "");
				}
				String remScripData=U.getSectionValue(comHtml, "var communities=[{\"id\":\"", "</script>");
				if (remScripData!=null) {
					U.log(":::::::::::Reomve Script::::");
					comHtml=comHtml.replace(remScripData, "");
				}
			//	U.log(comHtml);
				String moveInSec=ALLOW_BLANK;
				if (comHtml.contains(" <div id=\"tab-3\" class=\"tab-pane fade\">")) {
					moveInSec=U.getSectionValue(comHtml, "<div class=\"homes-desc-wrap\">", "<table class=\"footable\"");
				}
				U.log("moveInSec::"+moveInSec);
				pStatus=pStatus.replace("Final Phase Coming Soon, Coming Soon, Final Phase","Final Phase Coming Soon");
				pStatus=pStatus.replace("Phase 3 Now Selling, Now Selling", "Phase 3 Now Selling");
				
				comHtml=comHtml.replaceAll("story collection|whether your need is for a ranch home|three bedroom ranches", "");
//				U.log(planhtml.contains("1 1/2 story home"));

				//planhtml=planhtml.replace("5 unique levels of living.", "5 Story");
				dType=U.getdCommType((comHtml+moveInSec+planhtml+AllPlanData).replaceAll("whether your need is for a ranch|offers a wide variety of ranch", "")); //+moveInSec
				add[0]=add[0].replaceAll(", Green Township|, Miami Township", "");
				if(data.communityUrlExists(comUrl)) {
					LOGGER.AddCommunityUrl(comUrl+"::::::::::::::::::::repeated::::::::::::");
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				data.addCommunity(commName, comUrl, communityType);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSq, maxSq);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(latLng[0], latLng[1], geo);
				data.addPropertyType(pType, dType);
				data.addPropertyStatus(pStatus);
				data.addNotes("");

				// TODO Auto-generated method stub
				}
				j++;
			}

			

//			private String getDTypeOfStory(String html1) throws IOException,
//					InterruptedException {
//				String html = html1;
//				// html =
//				// U.getHTML("http://www.williamryanhomes.com/barrington-at-verrado-homes");
//				U.log(html);
//				ArrayList<String> listStory = Util.matchAll(html,
//						"class=\"btn btn-mini filter-button\">\\d+ Story", 0);
//
//				boolean oneStory = false, twoStory = false, threeStory = false, halfStory = false;
//				String dType = "-";
//				for (String story : listStory) {
//					String id = Util.match(story, "\\d+", 0);
//					if (id.contains("1") && oneStory == false) {
//						dType = dType + ",1 Story";
//						oneStory = true;
//					}
//					if (id.contains("2") && twoStory == false) {
//						dType = dType + ",2 Story";
//						twoStory = true;
//					}
//					if (id.contains("3") && threeStory == false) {
//						threeStory = true;
//						dType = dType + ",3 Story";
//					}
//				}
//
//				return dType.replace("-", "").trim().length() <= 1 ? "-" : dType
//						.replace("-", "").trim();
//
//			}
}

