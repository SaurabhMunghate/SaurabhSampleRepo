/**
 * @author Priti 
 * @date 5/6/2017
 * 
 */
package com.shatam.b_161_180;

import java.io.Writer;

import org.apache.bcel.generic.LLOAD;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractKerleyFamilyHomes extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;

	public ExtractKerleyFamilyHomes() throws Exception {
		super("Kerley Family Homes", "https://www.kerleyfamilyhomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Kerley Family Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractKerleyFamilyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Kerley Family Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
	}

	@Override
	protected void innerProcess() throws Exception {
		String baseHtml = U.getHTML("https://kerleyfamilyhomes.com/communities/");
		String sec = U.getSectionValue(baseHtml,
				"grid-100 grid-parent mobile-grid-100\">", "<footer id=\"");
		String vals[] = U.getValues(sec, "<div class=\"comm_list_block comm_card card", "<div class=\"clear\">");
//		String vals[] = U.getValues(sec, "nopadding mobile-grid-parent\">", "class=\"comm_card_a\">");
		U.log("CommLength" + vals.length);
		
		for (String val : vals) {
			String url = U.getSectionValue(val, "<a href=\"", "\"");
			//U.log(val);
			U.log("url: "+url);
			
			String commName = U.getSectionValue(val, "data-name=\"", "\"");
			U.log("commName: "+commName);
//			try {
				addDetails(url, commName, val, baseHtml);
//			} catch (Exception e) {}

		}

		LOGGER.DisposeLogger();
	}

	public void addDetails(String url, String communityName, String val, String baseHtml) throws Exception {
		// TODO : For Single Community Execution
//		 if(j == 20)
		{
//		 if(!url.contains("https://www.kerleyfamilyhomes.com/new-homes/powder-springs-ga/the-meadows/")) return;
			 
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "--repeat----");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			U.log(U.getCache(url));
				
			String html = U.getHTML(url);
			U.log(U.getCache(url));
			String fullHtml=html;
			U.log(+j+" ComUrl:::::::::::::::::::" + url);

			// U.log(html);
			// =====================================================---------------------adress======================================----------------//

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			String addressSec = U.getSectionValue(html, "<i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i>",
					"</p>");
			U.log(addressSec);
			if (addressSec == null) {
				addressSec = U.getSectionValue(html, "<i class=\"fa fa-map-marker grid-5 mobile-grid-10\" aria-hidden=\"true\" align=\"center\"></i>",
						"</a></strong>");
			}
			if (addressSec != null) {
				addressSec = addressSec.replace("<br />&nbsp;&nbsp;&nbsp;&nbsp;", ",");
				addressSec = U.formatAddress(addressSec);
				addressSec = addressSec.replace(",.,", ",").replace(", ,", ",").replace("Rd, SW,",
						"Rd SW,").replace(", NW", " NW");
				U.log("addressSec :: " + addressSec);
				String[] tempAdd = addressSec.split(",");
				if (tempAdd.length == 3) {
					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2], "\\w+").toUpperCase();
					add[3] = Util.match(tempAdd[2], "\\d+");
				}
			}
			if (addressSec == null) {
				addressSec = U.getSectionValue(html, "<div class=\"grid-90 mobile-grid-90 comm_address_block\">",
						"</a></strong>");
				if (addressSec != null) {
					addressSec = U.getSectionValue(addressSec, "https://google.com/maps/?q=", "\"");
					U.log(addressSec);
					if(addressSec!=null)
					add = addressSec.replace("+", ",").split(",");
				}
			}
			
			if (addressSec == null) {
				addressSec = U.getSectionValue(html, "<h4>Location</h4>",
						"</a></strong>");
				if (addressSec != null) {
					addressSec = U.getSectionValue(addressSec, "http://google.com/maps/?q=", "\"");
					U.log(addressSec);
					if(addressSec!=null)
					add = addressSec.replace("+", ",").split(",");
				}
			}
			
			if (addressSec == null) {
				String section = U.getSectionValue(html, "Location</h3>", " </div>");
				addressSec = U.getSectionValue(section, " target=\"_blank\">", "</a></strong>");
				addressSec = addressSec.replace("<br />", ",");
				U.log("From here: "+addressSec);
				
				if(addressSec!=null) {
					 String[] temp = addressSec.split(",");
					 add[0] = temp[0];
					 add[1] = temp[1];
					 add[2] = Util.match(temp[2], " \\w{2}");
				//U.log("add>>" +add[2]);
				add[3] = Util.match(temp[2], " \\d{5}");
				//U.log("add>>" +add[3]);
				}
			}
			
			U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2] + " add[3] " + add[3]);

			// --------------------------latlong---------------------//
			String geo = "FALSE";
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		 U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>");
			
			String latLngSec = U.getSectionValue(html, "new google.maps.LatLng(", ")");
			if(latLngSec==null && html.contains(" <a href=\"https://www.google.com/maps/dir/")) {
				latLngSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&destination=", "\"");
			}
			if (latLngSec != null && latLngSec.length()>1) {
				latLong = latLngSec.split(",");
				
			}
			if(url.contains("https://www.kerleyfamilyhomes.com/new-homes/mcdonough-ga/garden-walk/") || //for these 2 only
					url.contains("/new-homes/powder-springs-ga/the-meadows/")) {
				
				latLngSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&destination=", "\"");
				latLong = latLngSec.split(",");
			}
			
			if(latLong[0] ==  null || latLong[0].length()<2) {
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null)latLong = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
		
			
			
	U.log("LAT LNG: "+latLong[0] + ":::::::" + latLong[1]);

			// ------------------remove near by community section-------------------------
			String remNearCom = U.getSectionValue(html, "Nearby Communities</h2>", "</html>");
			if (remNearCom != null) {
				html = html.replace(remNearCom, "");
				U.log(":::::::::remove::::::::::");
			}
			String remove = ", Villa Rica,|Find your move-in ready home waiting for you|\"Quick Move-In|More Quick Move-In Homes";
			html = html.replaceAll(remove, "");

			// ---------community type,property type,property status,derived,
			String availHtml = "";
			String[] availSec = U.getValues(html,
					"<div class=\"grid-100 mobile-grid-100 tablet-grid-100 comm_listing comm_listing_count", "</h3>");
			int x = 0;
			for (String sec : availSec) {

				String aUrl = U.getSectionValue(sec, "<a href=\"", "\"");
				// if(aUrl.length()<10)continue;
				if (aUrl.contains("http://google.com/maps"))
					continue;
				if (aUrl.equals("https://www.kerleyfamilyhomes.com/"))
					continue;
				if (!aUrl.contains("www.kerleyfamilyhomes.com"))
					aUrl = "https://www.kerleyfamilyhomes.com" + aUrl;
				U.log(aUrl);
				availHtml = availHtml + U.getHTML(aUrl);
				if (x == 6)
					break;
				x++;
			}

			String florHtml = " ";
			String[] florSec = U.getValues(html, "<div class=\"plan_image grid-100 grid-parent image_fill\">", "Explore Plan</a></p>");
			U.log("florSec.length: "+florSec.length);
			int y = 0;
			for (String sec : florSec) {
				String fUrl = U.getSectionValue(sec, "<a href=\"", "\"");
				U.log("floor Url :"+fUrl);
				// U.log(U.getHTML(fUrl));
				florHtml = florHtml + U.getHTML(fUrl);
				// if(y == 6)break;
				y++;
			}
			// U.log("FLOOR"+florHtml);
			// property type---------//
			florHtml = florHtml.replace("</strong><br />", " ");
			html = U.removeSectionValue(html, "<a name=\"nearby\"></a>", "<footer");
			availHtml = U.removeSectionValue(availHtml, "<a name=\"nearby\"></a>", "<footer");
			// //html=U.removeSectionValue(html, "<a name=\"nearby\"></a>", "");

			html = html.replace("The Oaks Golf Course", "").replace("Dacula. Luxurious", "luxury homes").replace("New townhomes available now at The Enclave at Powder Springs", "")
					.replace("Executive </span>Series", "Executive Style").replace("swim and tennis community", "swim community and tennis community")
					.replace("Swim, tennis, playground", "Swim community, tennis, playground");
			String commType = U.getCommunityType(html);
			
			U.log("commType: "+commType);
			
			availHtml = U.getNoHtml(availHtml);
			

			String propType = U
					.getPropType((html + availHtml).replaceAll("farmhouse elevation|Farmhouse Elevations|apartment and unpack boxes|Brookmont Estates|hill-townhomes|real estate agent|alt=\"New townhomes|Hill Townhomes|Basement|Villas at Hickory Grove|The Farmhouse|epitomizes traditional beauty", ""));

			U.log("propType: "+propType);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{50}Executive Series[\\s\\w\\W]{50}", 0));
			
			String dpType = U.getdCommType(html.replaceAll("Branch|4th Floor|ceilings at the first floor", "")
					+ (florHtml + availHtml).replaceAll("ceilings at the first floor|First Floor|4th Floor|First-Floor|first-floor|Branch", ""));
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html+florHtml + availHtml, "[\\s\\w\\W]{30}first floor[\\s\\w\\W]{30}", 0));
			html = html.replaceAll(
					">Explore our move-in ready homes.</span>|FOR MOVE IN|\"Move-In Ready Available Homes\"|\"name\":\"Move-In Ready Available Homes\"|pricing coming soon",
					"");
			val = val.replaceAll("\"move-in ready Available Homes\"|\"name\":\"Move-In Ready Available Homes\"", "");

			//Builder Close-Out|BUILDER CLOSEOUT|Builder Close-Out
			html = html.replace("SOLD OUT &#8211; New Phase Coming Soon</p>", "SOLD OUT - New Phase Coming Soon");
			
			//removing "You might also be interested in these communities" section
			if(html.contains("You might also be interested in these communities") && html.contains("View All Communities")) {
				String intrestRemove = U.getSectionValue(html, "You might also be interested in these communities", "View All Communities");
				//U.log("intrestRemove: "+intrestRemove);
				
				html = html.replace(intrestRemove, "");
			}
 			
			html = html.replaceAll("Now Selling Final Opportunities\\s+Douglasville", "Now Selling, Final Opportunities Douglasville");
			
			String commStatus = U.getPropStatus((val + html).replaceAll(
					"<(.*)>|status=\"Sold Out\"|bubble\">Sold Out<|Now Selling in Kennesaw|status=\"Now Selling|plans decorated and ready for move-in|status=\"Builder Close-Out\"|r Close-Out From|single family homes coming soon| coming soon townhomes|Coming Soon &#8211; Kerley Family Homes|content=\"Coming Soon &#8211;|weeks of the Grand Opening|content=\"Coming Soon| golf lots available|move-in ready|\\s*MOVE IN READY! Welcome to| Quick Move-In Homes|Grand Opening Event|Join us for the Grand Opening of Ozora Lake|RiverSprings has new homes available now in Gwinnett|<p>Coming Soon</p>",
					""));
			
			U.log("commStatus :" + commStatus);
		//	U.log(">>>>>>>>>>>>"+Util.matchAll(val + html, "[\\s\\w\\W]{30}sold out[\\s\\w\\W]{30}", 0));
			//U.log(">>>>>>>>>>>>"+Util.matchAll(val + html, "[\\s\\w\\W]{30}now selling[\\s\\w\\W]{30}", 0));
			
			propType = propType.replace("Townhouse, Townhome", "Townhome");


			// --prices---//
			html = html.replaceAll("\\$\\d+’s, see them today!\" />", "")
					.replaceAll("0's|0s|0’s", "0,000").replaceAll("\\$\\d{3},\\d{3}\\.\" />", "");
			
			val = val.replace("0's", "0,000");
			if(url.contains("/new-homes/acworth/villas-hickory-grove/")) {
				html = html.replace("From the $700,000",""); //invalid value.check next time
			}
			if(url.contains("https://www.kerleyfamilyhomes.com/new-homes/kennesaw-ga/gunnerson-pointe/")) {
				html = html.replace("From the Mid $300,000","");
			}
			if(url.contains("https://www.kerleyfamilyhomes.com/new-homes/kennesaw-ga/cantrell-crossing/"))
				val = val.replace("From the Mid $300,000","");
			String remSec=U.getSectionValue(html, "You might also be interested in these communities", "View All Communities");
			
		   // U.log("KKKK"+remSec);	
			if(remSec!=null) {
				html=html.replace(remSec, "");
			}
			
			
			//U.log(">>>>>>>>>>>>"+Util.matchAll(val, "[\\s\\w\\W]{50}\\$300,000[\\s\\w\\W]{50}", 0));
			String[] price = U.getPrices(val + html,
					"\\$\\d{3},\\d{3}|Starting in the \\$\\d{3},\\d{3}|shallow\\\">\\s+\\$\\d{3},\\d{3}\\s+</p>|Low \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|<span class=\"large\">\\$\\d+,\\d+</span>|>\\$\\d+,\\d+</h4>|Mid \\$*\\d+,\\d+|Low \\$\\d+,\\d+|High \\$*\\d+,\\d+|From the \\$\\d+,\\d+|Low \\$\\d{3},\\d{3}",
					0);

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{100}518,597[\\s\\w\\W]{100}", 0));
			// -----------sqreft-----------//
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			// U.log(florHtml);

			html=html.replace("&#8211;", "-").replace("serif\">3963</h3><p>Sqft</p>", "<p>sqft 3963 Sqft</p>");
			String[] sqft = U.getSqareFeet(html + florHtml+ availHtml,
					"<p>sqft \\d{4} Sqft</p>|nearly \\d{4} square feet|>\\d,\\d{3}-\\d,\\d{3}</h3><p>Sqft|>\\d,\\d{3}</h3><p>Sqft|\\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3}\\+ square feet|ranging from \\d{4} to nearly \\d{4} square feet|from \\d{1},\\d{3} - \\d{1},\\d{3} square-feet|comfortable \\d{4}-\\d{4} square foot|\\d,\\d{3} – \\d,\\d{3} square feet|\\d,\\d+ to \\d,\\d+ square feet|\\d,\\d{3}  \\d,\\d{3} square feet|SqFt \\d{4}-\\d{4}&nbsp;|\\d{4} square feet|\\d+,\\d+ sq.ft|\\d{4}</strong> sqft|\\d{4}</strong> SqFt|SqFt \\d,\\d{3}&nbsp;|SqFt\\s*\\d{4}|up to \\d,\\d{3} square feet|\\s+\\d{4}\\s+SqFt",
					0);

			
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}3963[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(florHtml, "[\\s\\w\\W]{30}3963[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(availHtml, "[\\s\\w\\W]{30}3963[\\s\\w\\W]{30}", 0));
			
			if (add[1].length() < 3 || add[0].length() < 3) {
				add = U.getAddressGoogleApi(latLong);
				if (add == null)
					add = U.getAddressHereApi(latLong);
				geo = "TRUE";
			}

			/*if (url.contains("https://www.kerleyfamilyhomes.com/new-homes/hiram-ga/gorham-gates/")) {
				if (commStatus.length() > 1 && !commStatus.contains("Basements Available"))
					commStatus = commStatus + ", Basements Available";
				else
					commStatus = "Basements Available";
			}*/
			// ---notes-----//
			html = html.replace("opening for sales", "");
			// --------Add All--------------
	
			if (add[2].length() > 4) {
				add[2] = USStates.abbr(add[2].trim());
			}
//			if(html.contains("<span class=\"movein\"> <i class=\"fa fa-star\"></i> Move In Ready</span>")||fullHtml.contains("data-status=\"Quick Move-In\"")) {
//				if(commStatus.length()<2) {
//					commStatus="Move In Ready";
//				}else {
//					commStatus=commStatus+", Move In Ready";
//				}
//			}
//			if(html.contains("Explore our move-in ready homes")) {
//				
//			}
			if(url.contains("/sandtown-estates/") || url.contains("brookmont-estates/")) {
				 if(propType.length()<4)
					 propType = "Estate-Style Homes";
				 else
					 propType = propType+", Estate-Style Homes";
			 }
//			if(url.contains("https://www.kerleyfamilyhomes.com/new-homes/douglasville-ga/the-reserve-at-chapel-hill/")) commStatus = "Now Selling Final Opportunities";
//			if(url.contains("https://www.kerleyfamilyhomes.com/new-homes/dallas-ga/hickory-creek/"))propType+=", Farmhouse Style Homes";
			commStatus = commStatus.replace("New Homes Now Selling, Sold Out", "Sold Out").replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
//			if(url.contains("https://www.kerleyfamilyhomes.com/new-homes/hoschton-ga/overlook-hamilton-mill/"))commStatus = "Builder Close-Out, "+commStatus;
			data.addCommunity(communityName, url, commType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(commStatus);
			data.addNotes(U.getnote(html.replaceAll("Contact us for presale opportunities|build a presale home|available on presale homes|a presale home with|qualifying presale homes", "")));
            data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(ALLOW_BLANK);
		}
		j++;
	}
}
