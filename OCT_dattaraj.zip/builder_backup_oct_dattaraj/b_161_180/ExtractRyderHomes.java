/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_161_180;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRyderHomes extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;

	public ExtractRyderHomes() throws Exception {
		super("Ryder Homes", "https://www.ryderhomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Ryder Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractRyderHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Ryder Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String mainHtml = U.getHTML("https://www.ryderhomes.com/");
		String[] citis = { "communities/nevada/", "communities/california/" };
		for (String city : citis) {
			String cityHtml = U.getHTML("https://www.ryderhomes.com/" + city);
			String[] comSec = U.getValues(cityHtml, "data-community-id", "See on Map");
			for (String cSec : comSec) {
				String url = "https://www.ryderhomes.com" + U.getSectionValue(cSec, "href=\"", "\"");
				U.log("url-->" + url);
				addDetail(url, cSec);
			}
		}
		driver.quit();

		LOGGER.DisposeLogger();
	}

	private void addDetail(String comUrl, String cityData) throws Exception {
		// TODO Auto-generated method stub
//	if(j == 6)
//		try{
		{
			
//		if(!comUrl.contains("https://www.ryderhomes.com/communities/northern-nevada/cross-creek/"))return;
//		U.log(cityData);
		U.log("commUrl-->" + comUrl);
			String html = ALLOW_BLANK;
			if (comUrl.contains("https://www.ryderhomes.com/communities/nevada/ventana-at-miramonte/")) {
				html = U.getPageSource("https://www.visitventana.com/");
			} else {
				html = U.getHTML(comUrl);
			}
			
			
			
			

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "------------------> Repeated");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			// ===========================Lot Data SEction============================
			
			String map_link=U.getSectionValue(html, "<a class=\"interactiveFeature \" href=\"", "\"");
			U.log("mapUrl=="+map_link);
			String[] lotData=null;
//			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
			int sum=0;
			if(map_link!=null) {
			String map_html=U.getHTML(map_link);
			String lotDataSec=U.getSectionValue(map_html, "<h6>Legend</h6></li>", "</ul>");
			if(lotDataSec!=null) {
				 lotData=U.getValues(lotDataSec, "<span>", "</span>");
				 for(String lotdata : lotData) {
					 lotdata=U.getNoHtml(lotdata);
					 U.log("lotdata=="+lotdata);
					 sum+=Integer.parseInt(Util.match(lotdata, "\\d+"));
				 }
				 lotCount=Integer.toString(sum);
			}
			}
			
			
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(cityData, "communityUrlInfo\">", "</a>");

			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
//			U.log(cityData);
			add[0] = U.getSectionValue(cityData, "addressStreet\">", "</span>");
			if (add[0] == null) {
				add[0] = U.getSectionValue(html, "<span class=\"addressStreet\">", "</span>");
			}
			add[1] = U.getSectionValue(cityData, "addressLocality\">", "</span>");
			add[2] = U.getSectionValue(cityData, "addressRegion\">", "</span>");
			add[3] = U.getSectionValue(cityData, "postalCode\">", "</span>");
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);

			add[0] = add[0].replace("&amp;", "&");
			// --------------------------------------------------latlng----------------------------------------------------------------

			latlag[0] = U.getSectionValue(cityData, "data-latitude=\"", "\"");
			latlag[1] = U.getSectionValue(cityData, "data-longitude=\"", "\"");
			U.log("hhhh--->" + latlag[0] + "  " + latlag[1]);

			// ============================================Price and
			// SQ.FT======================================================================
			String homeHtml = "";
			if (html.contains(" <h3 class=\"xCommunityNameHeader\">")) {
				String[] url1 = U.getValues(html, "<h3 class=\"xCommunityNameHeader\">", "</h3>");
				for (String url2 : url1) {
					url2 = "https://www.ryderhomes.com" + U.getSectionValue(url2, "<a href=\"", "\"");
					homeHtml = homeHtml + U.getHTML(url2);

				}
			}

			// ====================================================for single
			// community===========================================================
			if (comUrl.contains("ventana-at-miramonte")) {
				communityName = "Ventana at Miramonte";

				homeHtml = U.getPageSource("https://www.visitventana.com/floor-plans/");
				homeHtml = homeHtml.replace("Stories: Single", " 1 Story ").replace("Stories: Two", " 2 Story ");
			}

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			html = html.replace("approximately 2,700sf to 3,500sf", "approximately 2,700 sf to 3,500 sf");
//			U.log("MATCH: " + Util.matchAll(html , "[\\s\\w\\W]{30}2,700[\\s\\w\\W]{30}", 0));
//			U.log("MATCH: " + Util.matchAll(cityData, "[\\s\\w\\W]{30}2,700[\\s\\w\\W]{30}", 0));

			
		
			html = html.replaceAll("0�s|0's|0s", "0,000");
			html = html.replace("lot sizes from 6,000 to 8,300 Sq. Ft", "");
			String prices[] = U.getPrices(html + cityData + homeHtml,
					"Priced from \\$ \\d+,\\d+|\\$\\d,\\d+,\\d+|\\$\\d{3},\\d+", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================

			html = html.replaceAll("\\d+,\\d+ Sq. Ft. Lot", "");
			String[] sqft = U.getSqareFeet(html + cityData,
					"approximately \\d,\\d{3} sf to \\d,\\d{3} sf|from \\d,\\d{3} to \\d,\\d{3} square feet|approximately \\d,\\d{3} up to just over \\d,\\d{3} sq. ft.|\\d,\\d+ to \\d,\\d+ sq. ft|\\d,\\d+ - \\d,\\d+ Sq. Ft.|\\d,\\d+ - \\d,\\d+ Square Feet|\\d{1},\\d{3} Square Feet| \\d{3} Square Feet| \\d,\\d{3} Sq. Ft.",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

//				U.log(Arrays.toString(U.getSqareFeet(
//								html+cityData,
//								"approximately \\d,\\d{3} up to just over \\d,\\d{3} sq. ft.|\\d,\\d{3} to \\d,\\d{3} sq. ft|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d{1},\\d{3} Square Feet| \\d{3} Square Feet| \\d,\\d{3} Sq. Ft.",
//								0)));
			// ================================================community
			// type========================================================

			html = html.replace("skiing, lakefront", "").replace("lake and mountain views",
					"lakefront community and mountain views");
			String communityType = U.getCommType(html + cityData);

			U.log("community type-->" + communityType);

			// ==========================================================Property
			// Type================================================
			html = html.replace("Luxuries like", "Luxury homes like");
			if (homeHtml != null)
				homeHtml = homeHtml.replace("Farmhouse exterior design", "farmhouse interpretive townhomes");
			String proptype = U.getPropType((html + cityData + homeHtml).replaceAll(
					"/hamilton-cottages/|luxurious master suite|Farmhouse exterior|Modern Farmhouse Elevation|village|village|no HOA",
					"").replaceAll("Estate Home", "- Estate home"));
			U.log(Util.matchAll(html + cityData + homeHtml, "[\\w\\s\\W]{10} Multi-Gen living space[\\w\\s\\W]{10}",
					0));

			U.log("property type-->" + proptype);

			// ==================================================D-Property
			// Type======================================================
			html = html.replaceAll("footerAnchorBackgroundColor|avilaranch|Ranch Pkwy", "");
			String dtype = U.getdCommType(
					(html).replace("Ranch R", "").replaceAll("\\d Bedroom|rAnchor|First Floor|first floor", "")
							.replace("two and three-level", "2 story and 3 story"));
			U.log("derived type" + dtype);
			// ==============================================Property
			// Status=========================================================
			String note = U.getnote((html + cityData).replaceAll("Release Now|/presales/", ""));
			cityData = cityData.replace("coming_soon.png", " coming soon .png").replace("Coming Late Spring 2019.",
					"Coming late Spring 2019");
			cityData = cityData.replaceAll(
					"FIRST RELEASE OF NEW HOMES IS NOW AVAILABLE|pre-grand opening sale|Pre-Grand Opening Sale|tipComingSoon|alt=\".*\"|Coming Soon...A New Pocket|Coming Soon...Register for|Two Income-Restricted Homes Coming Soon|production townhomes ready to move in|New Luxury Townhomes Coming Late Spring 2019|SHOW HOMES NOW OPEN|Release Pricing Now Available|Grand Opening of this Community!|coming_soon.png|tipComingSoon|This Community is Coming Soon!",
					"");
			html = html.replace("First Release of New Homes Now Available", "First Release New Homes Now Available")
					.replaceAll(
							"new homes in Stateline|Release Now Available|List is now open|Two Income-Restricted Homes Coming Soon|"
							+ "odel home and community Grand Opening. We|Don&#39;t miss out on this final chance|omoTitle\">FINAL CLOSEOUT SALE!</h2>|"
							+ "production townhomes ready to move in| Our Grand Opening is schedu|tipComingSoon|munity is Coming Soon|Coming Soon\\.\\.\\.Registe|"
							+ "is now available to own|new homesites are now available to own. |Coming Soon...Register for More Information!|SAVINGS ON QUICK MOVE|"
							+ "our four quick move|new homes in Stateline|New Homes in|new Date()|new Image()|-new-","")
					.replace("now available", " ");
			cityData = cityData.replace("images/opening.png\"", "Grand Opening").replaceAll("Coming in 2019",
					"Coming 2019");

			String[] homeStatus = U.getValues(html, "<div class=\"item  description marketingDescription\">", "</div>");

			for (String remove : homeStatus) {

				html = html.replace(remove, "");
			}

			String pstatus = U.getPropStatus(U.getNoHtml(html) + cityData);
//			U.log("MATCH: " + Util.matchAll(U.getNoHtml(html) + cityData, "[\\s\\w\\W]{30}New Phase Coming Soon[\\s\\w\\W]{30}", 0));
			U.log("status--->" + pstatus);

			String availHomeSec = U.getSectionValue(html, "<h3 class=\"\">Available Now</h3>", "<div id=\"gallery\">");

			if (availHomeSec == null)
				availHomeSec = "";
			String[] availhome = U.getValues(availHomeSec, "<li", "</li");

			int underContract = 0;
			for (String home : availhome)
				if (home.contains("alt=\"Under Contract\">"))
					underContract++;

			/*
			 * if(availhome.length > underContract &&
			 * !pstatus.contains("Homes Available Now")){ if(pstatus == ALLOW_BLANK)pstatus
			 * = "Homes Available Now"; else pstatus = pstatus+", Homes Available Now"; }
			 */
			// ============================================note====================================================================

			if (comUrl.contains("https://www.ryderhomes.com/communities/nevada/village-at-arrowcreek-apartments/")) {
				communityName = "Village At Arrowcreek";
				dtype = "1 Story";
			}

			/*
			 * if(comUrl.contains(
			 * "https://www.ryderhomes.com/communities/northern-nevada/cross-creek/"))
			 * pstatus =
			 * "Grand Opening, Now Selling, First Release New Homes Now Available, Homes Available Now"
			 * ;
			 */
			if (comUrl.contains("/northern-california/calistoga-estates/"))
				minSqft = "3,093";

			if (pstatus != null)
				pstatus = pstatus.replaceAll(
						"New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon",
						"New Phase Coming Soon");

			if (comUrl.contains("https://www.ryderhomes.com/communities/northern-california/bahia-heights"))
				proptype = proptype.replace(", Cottage", "");
			if (comUrl.contains("https://www.ryderhomes.com/communities/northern-california/hamilton-cottages")) {
				pstatus = "Sold Out";
				communityType += ", 62+ Community";
			}
			
			
//			=======================================================================
			
//			String map_link=U.getSectionValue(html, "<a class=\"interactiveFeature \" href=\"", "\"");
//			U.log("mapUrl=="+map_link);
//			String[] lot_data=null;
//			String lotCount=ALLOW_BLANK;
//			if(map_link!=null) {
//			String map_html=U.getHtml(map_link, driver);
//			String lot_sec=U.getSectionValue(map_html, "<g id=\"Lots\">", "<style>");
//			if(lot_sec!=null) {
//				lot_data=U.getValues(lot_sec, "<g id=\"Lot", "</g>");
//				if(lot_data.length>0) {
//					lotCount=Integer.toString(lot_data.length);
//					 U.log("lotCount=="+lotCount);
//					}
//			}
//			}

			add[0] = add[0].replace(".", "");
			
			
			 U.log("lotCount=="+lotCount);
			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//		}catch(Exception e) {}
	}
}
