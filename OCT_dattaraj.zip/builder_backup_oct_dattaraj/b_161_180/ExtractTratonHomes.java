/** @author Priti Chaulkar
 *  @date 05/01/2017
 */

package com.shatam.b_161_180;


import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTratonHomes extends AbstractScrapper {
	ArrayList<String> community = new ArrayList<String>();
	int i = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	String quickHtml = ALLOW_BLANK;

	public static void main(String[] ar) throws Exception {
		final long startTime = System.nanoTime();
		AbstractScrapper a = new ExtractTratonHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Traton Homes.csv", a.data().printAll());
		final long duration = System.nanoTime() - startTime;
		System.out.println(duration);
	}


	public ExtractTratonHomes() throws Exception {

		super("Traton Homes", "https://www.tratonhomes.com/");
		LOGGER = new CommunityLogger("Traton Homes");
	}

	public void innerProcess() throws Exception {
		quickHtml = U.getHTML("https://www.tratonhomes.com/quick-move-in-homes/");
		String mainHtml = U.getHTML("https://www.tratonhomes.com/communities/");
		//String[] comSec = U.getValues(mainHtml, "<div class=\"home-image one-third first\">", "<div class=\"community-amenities\">");
		
		String[] comSec=U.getValues(mainHtml, "<li><h3 class=\"community-title\">", "</h3></li>");
		U.log(comSec.length);
		for(String cSec : comSec){
			//U.log(cSec);
			//String cUrl = U.getSectionValue(cSec, "<a href=\"", "\"><img src=\"");
			String cUrl=U.getSectionValue(cSec, "<a href=\"", "\">");
			
			if(!cUrl.contains("https"))
			cUrl="https://www.tratonhomes.com/"+cUrl;
			U.log("Url is "+cUrl);
			//U.log("cUrl :: "+cUrl);
			//String tempName = Util.match(cSec, "three-fourths first\"><a href=\""+ cUrl+"\">(.*?)</a></h3>",1);
			//U.log(tempName);
			String comName=U.getSectionValue(cSec, "\">", "</a>");
			comName=comName.replace(" &#8211;|", "");
			U.log("ComNmae "+comName);
			String mainLatlng = U.getSectionValue(mainHtml, "['"+comName, "]");
			U.log(mainLatlng);
//			try {
				addDetails(cUrl,cSec,mainLatlng,comName);
//			} catch (Exception e) {}
			//break;
		}
		LOGGER.DisposeLogger();
	}



	private void addDetails(String comUrl,String comData,String mainLatlng,String comName) throws Exception {

//if(j==3)

//		if(!comUrl.contains("https://www.tratonhomes.com/communities/edgemoore-at-milford/")) return;
		
	{
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------>repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
//		if(comUrl.contains("/courtyards-at-hickory-flat/")){
//			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------returned no data");
//			return;
//		}
	//	if(comUrl.contains("/courtyards-at-hickory-flat/"))return;
		
		U.log("count :"+j);
		String html = U.getHTML(comUrl);
		U.log("mm"+Util.matchAll(comData+html, "$370s",0));
		
			U.log("comUrl:::::===========================================================> "+comUrl);
			//String commName = ALLOW_BLANK;
			//commName = U.getSectionValue(html, "<h1>", "</h1>");
			comName  = comName.replace("&#038;", "&").replace("&#8211", "");
			U.log("commName ::::::===========================================================>  "+comName);
			
			
			String[] add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo ="false";
			String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
			
			String section = U.getSectionValue(html, "<p class=\"address\">", "</p>");
			if(section != null){
				U.log("section :::::===========================================================> : "+section);
				//-------Section for Address----------
				String addSec=null;
				if(!comUrl.contains("https://www.tratonhomes.com/communities/the-village-of-fullers-chase/")){
					addSec = U.getSectionValue(section, "\"_blank\">", "</a>");//<
					U.log("addSECC"+addSec);
				}
				if (comUrl.contains("https://www.tratonhomes.com/communities/the-village-of-fullers-chase/")) {
					addSec=section;
				}
				addSec=section;
				
				U.log("addSec : "+addSec);
				if(addSec != null){
					
					addSec = addSec.replace(" GA ", ", GA  ").replace("Smyrna Georgia", "Smyrna, GA").replace("Acworth/Kennesaw", "Acworth")
							.replace("Marietta/Smyrna", "Marietta");
					addSec=addSec.replace("Marietta ", "Marietta,").replace(",,", ",").replace("<br/>Freeport FL 32439", "Freeport, FL 32439");
					addSec = U.getNoHtml(addSec);
					add = U.getAddress(addSec);
				}
				
				if(comUrl.contains("https://www.tratonhomes.com/communities/cessna-village/")) {
//					addSec=U.getSectionValue(addSec, "_blank\"", "</a>");
//					add[0]=U.getSectionValue(addSec, ">", ",");
//					add[1]=U.getSectionValue(addSec, "<br/>", "FL").trim();
//					add[2]=U.getSectionValue(addSec, "Beach", "32459").trim();
//					add[3]=U.getSectionValue(addSec, "FL", "</a>").trim();
//					addSec=addSec.replace("<br/>", "");
					add[0]="N County Hwy 393 & Gammage St";
					add[1]="Santa Rosa Beach";
					add[2]="FL";
					add[3]="32459";
				}
				if(comUrl.contains("https://www.tratonhomes.com/communities/magnolia-bay-estates/")) {
					add[0]="J Hunter's Way N & N Hammock Way";
					add[1]="Freeport";
					add[2]="FL";
					add[3]="32439";
				}
//				if(html.contains("href=\"https://www.google.com/maps/dir//") && add[0]== ALLOW_BLANK) {
//					 addSec = U.getSectionValue(html, "href=\\\"https://www.google.com/maps/dir//", "/@");
//					 U.log(addSec);
//				}
				U.log("Address is :::::==========>  "+Arrays.toString(add));
				
				//--------Section for LatLng-----------
				String latLngSec = Util.match(section, "/@(.*?),\\d+z",1);
				U.log("latLngSec : "+latLngSec);
				if(latLngSec==null) {
					latLngSec=U.getSectionValue(html, "\"point\":{", ",\"poly\"");
					U.log("my Lat lngsec"+latLngSec);
					latLng[0] = U.getSectionValue(latLngSec,"\"lat\":", ",");
					latLng[1] = U.getSectionValue(latLngSec,"\"lng\":", "}");
				}
				if(latLngSec==null && mainLatlng!=null)
				{
					latLngSec = U.getSectionValue(mainLatlng.replace("', '-", ",-"), "', '", "', 'https");
				}
				if(latLngSec != null && latLng[0].length()<2){
					latLng = latLngSec.split(",");
				}
				
				
				U.log("latLng is:::::===========================================================>   "+Arrays.toString(latLng));
			
			
			}
			
			//---------latlng from Address---------
			if(latLng[0].length()<4 && add[0].length()>4)
			{
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo = "true";
			}
			
			//------------Available homes & floor plan Data-------------------
			String allHomeAndPlans = ALLOW_BLANK;
			int quickCount = 0;
			
			
			String[] homePlansUrls = U.getValues(html, "<p class=\"name\"><a href=\"", "\"");
			
			for(String homePlansUrl : homePlansUrls){
				U.log("homePlansUrl: "+homePlansUrl);//"homePlansUrl :::::===========================================================> : "+
				
				String homeHtml = U.getHTML(homePlansUrl);
				if(homeHtml != null){
					
					//FOR QUICK STATUS
					if(homeHtml.contains("READY OCTOBER") || homeHtml.contains("Ready Fall 2022")) quickCount++;
					
					
					homeHtml = homeHtml.replace("community-tabs", "-community-tabs");
					allHomeAndPlans += U.getSectionValue(homeHtml, "<div class=\"home-header\">", "-community-");
				}
			}
			
			U.log("quickCount: "+quickCount);
			
			//-------Quick home Data from url -->"https://www.tratonhomes.com/quick-move-in-homes/"
			int comQuickCount = 0;
			String allQuickHomes = ALLOW_BLANK;
			quickHtml = quickHtml.replace("&#038;", "&");
			String[] quickSections   = U.getValues(quickHtml, "<div class=\"home-image one-third first\">", "</p></div></div></div></div>");
			U.log("quicksectionLength:::::===========================================================> :::::::"+quickSections.length);
			for(String quickSec : quickSections){
				U.log("quickSec: "+quickSec);
				
				if(quickSec.contains(comName)){
					allQuickHomes += quickSec;
					comQuickCount++;
				}
				
			}
			
			//--------------Prices---------------
			String minPrice= ALLOW_BLANK;
			String maxPrice= ALLOW_BLANK;
			//U.log(comData);
			html = html.replace("High $300's to $500's", "high $300,000 to $500,000").replace(" $600's ", "from the $600,000 ").replaceAll("0S|0’s|0's|0’s|0s|0's|0s", "0,000");
			comData=comData.replaceAll("00s|0S|0’s|0's|0’s|0s", "0,000");
			U.log("mm"+Util.matchAll(comData+html, "\\$370,000",0));
			String[] price = U.getPrices(html+comData, "Priced from Mid \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|MID-HIGH \\d{3},\\d{3}|<h4>Priced From</h4><p class=\"price\">\\$\\d{3},\\d{3}</p>|\\$\\d{3},\\d{3}|Priced from Low \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}<br />|high \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}\\s*-\\s*\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|<p class=\"price\">\\$\\d{3},\\d{3}|<p>\\$\\d{3},\\d{3}</p>|From \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|to \\$\\d{3},\\d{3} for up", 0);
			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("minPrice ::::::===========================================================>  " + minPrice + " maxPrice : " + maxPrice);
			
			
			//--------------Prices---------------
			String minSqf= ALLOW_BLANK;
			String maxSqf= ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html+comData+allHomeAndPlans, "Sq Ft</h4><p>\\d,\\d{3} - \\d,\\d{3}|Sq Ft</h4><p>\\d,\\d+|<p>\\d{1},\\d{3}</p>\\s*</div>\\s*<div class=\"one-fifth\">|sqft.svg\">\\s*</div>\\s*<p>\\d{4}</p>\\s*</div>|sqft.svg\"></div><p>\\d,\\d{3}", 0);
			
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("minSqf :::::===========================================================> : " + minSqf + " maxSqf : " + maxSqf);
			
			//--------------Community Type----------
			String comType = ALLOW_BLANK;
			
			String rem = U.getSectionValue(html, "<!-- UberMenu ", "<!-- End UberMenu -->");
			if(rem!=null)
				html = html.replace(rem, "");
			
			comType = U.getCommType((html+comData).replace("outstanding golf", "and golf").replaceAll("Hills Country Clu", ""));
			U.log("comType:::::===========================================================> "+comType);
			//------Property Type-------
			if(comUrl.contains("-estates")) html = html +", Estate Style"; 
			
			String propType= ALLOW_BLANK;
			html =html.replaceAll("<option value=\"single-family-home\">|Cottage Hill Road| S Cottage Hill Rd|\\+Cottage\\+|Single Family Home</option>|value=\"townhome\">Townhome", "");
			propType = U.getPropType((html+comData+allHomeAndPlans).replaceAll("\"courtyard-at-hickory-flat\"|COURTYARD AT HICKORY FLAT|craftsmanship|The Manor|Courtyards|\"COURTYARDS|\"courtyards", ""));
			U.log("propType:::::===========================================================> "+propType);
			
			
			allHomeAndPlans = allHomeAndPlans.replaceAll("icon-stories.svg\">\\s*</div>\\s*<p>"	, "stories ")
					.replace("First Floor", "1 Story").replace("Second Floor", "2 Story");
			//U.log(allHomeAndPlans);
			String dType= ALLOW_BLANK;
			
			//U.log("DTYPECHK"+Util.matchAll(html+comData+allHomeAndPlans+allQuickHomes,"[\\w\\W\\s]{60}stories[\\w\\W\\s]{60}",0));
			
			dType = U.getdCommType((html+comData+allHomeAndPlans+allQuickHomes).replace("optional second levels for even more living space","").replaceAll("Third Floor| 3rd Story ", " 3 Story "));
			U.log("dtype:::::===========================================================> "+dType);
			
			//----------Property status--------
			String pStatus= ALLOW_BLANK;
			html =html.replace("Coming in 2021", "Coming 2021")
					.replaceAll("HOURS COMING|Now Selling &#8211; Florida Panhandle|will be opening in Early 2022|Coming Soon to Florida Panhandle|<div class=\"agent-hours\"><p>COMING|Coming in 2021 is an exciting|ubermenu-target-text\">Quick Move-in Homes|CLOSE-OUT PRICING|Plan Now Available \\(Limited Availability\\)!|Close-Out Pricing|BIG Close-Out|Schools</h3><p>Coming", "")
					.replace("<div class=\"agent-hours\"><p>Coming Soon</p>", "").replace("Only ONE Home Remains", "Only one Home Remains").replace("Phase One - SOLD OUT", "Phase I Sold Out");

//	        if(comUrl.contains("https://www.tratonhomes.com/communities/tapp-farm/")) {
//	        	html=U.removeSectionValue(html, "<div class=\"wrap\">", "<script>");
//	        }
			pStatus = U.getPropStatus((html+comData)
					.replace("PHASE 2 - NOW SELLING", "PHASE 2 NOW SELLING")
					.replaceAll("will be opening in Early 2022|Homes Ready NOW for Quick Move-In", ""));
		
			U.log("comQuickCount :: "+comQuickCount);
			//if(homePlansUrls.length>0||comQuickCount>0 && !pStatus.contains("Quick"))
				if(quickCount>0 && !pStatus.contains("Quick")){
				if(pStatus.length()<4){
					U.log("XXXXX");
					pStatus = "Quick Move in Homes";
				}
				else{
					U.log("YYYY");
					pStatus = pStatus + ", Quick Move in Homes";
				}
			}
			
			String note=U.getnote(html);
			pStatus = pStatus.replace("Final 3 Opportunities, Only 3 Opportunities Remain", "Only 3 Opportunities Remain");
			U.log("pstatus:::::===========================================================> "+pStatus);
			
//			U.log(Util.matchAll(html+comData+allHomeAndPlans+allQuickHomes, "[\\w\\s\\W]{60}phase 2[\\w\\s\\W]{60}", 0));
			
			pStatus = pStatus.replace("Only 1 Opportunity Remains, 1 Opportunity Remains", "Only 1 Opportunity Remains");
			pStatus = pStatus.replace("Limited Number Of Basement Homesites Available, Over 75% Sold, Basement Homesites Available", "Limited Number Of Basement Homesites Available, Over 75% Sold");
			pStatus=pStatus.replace("Phase 2 Opening Early 2022, Sold Out, Opening Early 2022", "Phase 2 Opening Early 2022, Sold Out");
			
			if(comUrl.contains("/tapp-farm/")) {
				pStatus=pStatus.replace(", Quick Move In Homes", "");
			}
			if(pStatus.equals("Phase 2 Opening Summer 2022, Coming Soon, Opening Summer 2022, Phase I Sold Out")) {
				pStatus="Phase 2 Opening Summer 2022, Coming Soon, Phase I Sold Out";
			}	
			
			U.log("prop stat"+pStatus);		
			if(comUrl.contains("https://www.tratonhomes.com/communities/1825-stilesboro/"))pStatus+=", Final Home";
			if(comUrl.contains("https://www.tratonhomes.com/communities/logans-walk/"))geo="False";
//			if(comUrl.contains("https://www.tratonhomes.com/communities/east-park-village/")) {minPrice="$300,000"; maxPrice="$370,000"; }
			
			
			LOGGER.AddCommunityUrl(comUrl);
			
			if(add[0].contains("SW, Marietta")){
				add[0] = add[0].replace(" SW, Marietta", " SW");
				add[1] = "Marietta/Smyrna";
			}
			if(comUrl.contains("https://www.tratonhomes.com/communities/kirk-ridge/")) pStatus = pStatus + ", Quick Move-in Homes";
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propType,dType);
			
			data.addPropertyStatus(pStatus.replace("Only 1 Opportunity Remains, Only 1 Opportunity Remain, 1 Opportunity Remains", "Only 1 Opportunity Remains").replace("Coming Summer 2021, Coming Soon, Coming In 2021", "Coming Summer 2021, Coming Soon"));
		
			data.addPrice(minPrice, maxPrice);
			
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(U.getnote(html));
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

	
		}j++;
	}
}