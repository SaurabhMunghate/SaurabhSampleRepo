/*sampada santosh*/
package com.shatam.b_181_200;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.bcel.generic.ALOAD;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractCandleLightHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "http://www.candlelighthomes.com/";
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCandleLightHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/Candlelight Homes.csv", a
				.data().printAll());

	}

	public ExtractCandleLightHomes() throws Exception {

		super("Candlelight Homes", "http://www.candlelighthomes.com/");
		LOGGER = new CommunityLogger("Candle Light Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String basehtml = U.getHtml("https://www.candlelighthomes.com/new-homes",driver);
		basehtml = U.removeComments(basehtml);
		
		
		String[] commSections = U.getValues(basehtml, "class=\"tile tile-commmunity\"", "Distance from you");
		U.log(commSections.length);
		for(String commSec : commSections){
			U.log("=="+commSec);
			String commUrl = Util.match(commSec, "data-id=\"(.*?)\" href=\"(.*?)\"",2);
			String commName = U.getSectionValue(commSec, "h5 hide-in-popup\">", "</div>").trim();
			U.log(commUrl);
			addDetails(commUrl, commName,commSec);
			//break;
		}
		driver.close();
		try{
			driver.quit();
		}
		catch (Exception e) {}
	}

	public void addDetails(String url, String communityName,String commSec) throws Exception {
	//if(j==12)
	{
		U.log("================");
		U.log(j+" ::\t"+url+" ::\t"+communityName);
		//U.log(commSec);
		if (!url.startsWith("http")) {
			url="https://www.candlelighthomes.com"+url;
		}
		
		String comHtml =U.getHtml(url, driver);
		
		//------------_Address-------------
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String addSec= U.getSectionValue(comHtml, "<div class=\"mailing-address h4\">", "</div>");
		U.log(addSec);
		
		if(addSec!=null){
			addSec = addSec.replaceAll("SOLD OUT<br>|Model Home Coming Soon!<br>", "").replace("<br>", ",");
			String[] tempAdd = addSec.split(",");
			
			if(tempAdd.length==3){
				add[0] = 	tempAdd[0].trim();
				add[1] = 	tempAdd[1].trim();
				add[2] = 	Util.match(tempAdd[2], "\\w+");
				if(add[2].length()>2){
					add[2]= USStates.abbr(add[2]);
				}
				add[3] = 	Util.match(tempAdd[2], "\\d+");
			}
		}
		U.log("Address : " + Arrays.toString(add));
		
		//-------------latlng-------------
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		
		String latLngSec = U.getSectionValue(comHtml, "maps.google.com/maps?ll=", "&amp");
		if(latLngSec!=null){
			latLng = latLngSec.split(",");
		}
		U.log("latlng is "+Arrays.toString(latLng));
		
		//---------fetching address from latlng-----------
		if(add[0].length()<5 && latLng[0].length()>4){
			add = U.getAddressGoogleApi(latLng);
			geo = "TRUE";
		}
		U.log("geo :: "+geo);
		//-----------------fetching floorPlan data----------------
		String allFloorPlanData = ALLOW_BLANK;
		ArrayList<String> floorUrls = Util.matchAll(comHtml	, "<a href=\"(.*?)\" class=\"tile tile-home-design",1);		
		U.log("Total floor :: "+floorUrls.size());
		for(String floorUrl : floorUrls ){
		U.log("floorUrl :: "+floorUrl);
		String floorHtml = U.getHtml(floorUrl,driver);
		allFloorPlanData +=  U.getSectionValue(floorHtml, "home-detail model", "home-info-graphics");
		
		//break;
		}
		//------------Fetching Quick Movein Homes data--------------
		String allQuickHomesData = ALLOW_BLANK;
		String[] quickUrls = U.getValues(comHtml, "]\" href=\"", "\"");
		U.log("Total quick :: "+quickUrls.length);
		for(String quickUrl : quickUrls ){
		U.log("quickUrl :: "+quickUrl);
		String quickHtml = U.getHtml(quickUrl,driver);
		allQuickHomesData +=  U.getSectionValue(quickHtml, "home-detail model", "home-info-graphics");
		//U.log(allQuickHomesData);
		//break;
		}
				
		//---------------Price---------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comHtml = comHtml.replace("00<span class=", "00,000<span class=");
		allFloorPlanData = allFloorPlanData.replace("<span class=\"lowercase\">s</span>", ",000</span>");
		
		String[] prices = U.getPrices(comHtml + commSec +allFloorPlanData, "\\$\\d+,\\d+<span class=|\\$\\d+,\\d+</span>", 0); 
		
		minPrice = (prices[0] ==null) ? ALLOW_BLANK : prices[0]; 
		maxPrice = (prices[1] ==null) ? ALLOW_BLANK : prices[1]; 
		
		U.log(minPrice +"\t" + maxPrice);
		
		
		//-----------Square feet---------------
		String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
		
		allFloorPlanData = allFloorPlanData.replace("\\s*</span>\\s*SQ Ft", " SQ Ft");
		//U.log(allQuickHomesData);
		String[] sqFt = U.getSqareFeet(comHtml + commSec +allFloorPlanData + allQuickHomesData , "square-footage-total h4\">\\s*\\d,\\d+ sq ft", 0); 
		
		minSqFt = (sqFt[0] ==null) ? ALLOW_BLANK : sqFt[0]; 
		maxSqFt = (sqFt[1] ==null) ? ALLOW_BLANK : sqFt[1]; 
		
		U.log(minSqFt +"\t" + maxSqFt);
		
		//---------------replace section
		comHtml = comHtml.replaceAll("No HOA fees|flag sold-out|item.soldOut\">Sold Out</div>|comingSoon\">Coming Soon</div>","");	
		comHtml  = comHtml.replace(" and craftsman-style, ", " and craftsman-style homes, ");
		allFloorPlanData = allFloorPlanData.replace("SECOND <span class=\"emphasis\">level", " 2 story ");
		
		//----------------Comunity Type --------------------
		String comType = U.getCommunityType(comHtml);
		
		//-------------PropertyType-----------
		String propType = U.getPropType(comHtml+allFloorPlanData+allQuickHomesData);
		
		//-----------deriverTYpe -----------
		String dType = U.getdCommType(comHtml+allFloorPlanData+allQuickHomesData);
		
		//-----------------Status--------------
		comHtml=comHtml.replaceAll("Quick Move-Ins|Quick Move-In","");
		comHtml = U.removeSectionValue(comHtml, "<div rv-if=\"item.comingSoon", "</a>");
		String propStatus = U.getPropStatus(comHtml);
		
		if(quickUrls.length!=0 && !propStatus.contains("Quick Move-Ins")){
			//int count = quickUrls.length;
			if(propStatus.length()<5){
				propStatus= "Quick Move-Ins";
			}
			else{
				propStatus = propStatus + ", Quick Move-Ins";
			}
		}
		
		
		data.addCommunity(communityName, url	, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(ALLOW_BLANK);
		
		
		
	}j++;
	}
}