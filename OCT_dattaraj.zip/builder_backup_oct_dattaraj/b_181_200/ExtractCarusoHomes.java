/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_181_200;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCarusoHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractCarusoHomes()
			throws Exception {
		super("Caruso Homes","https://www.carusohomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Caruso Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractCarusoHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Caruso Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	HashMap<String,String> map1=new HashMap<>();
	WebDriver driver= null;
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String mainHtml=U.getHTML("https://www.carusohomes.com/");
		String quikData=U.getHTML("https://www.carusohomes.com/move-in-now/?id=MD/")
				+U.getHTML("https://www.carusohomes.com/move-in-now/?id=NC");
//		String mainSec=U.getSectionValue(mainHtml, "Where We Build</h1>","FIND YOUR HOME</h1>");
		String mainSec=U.getSectionValue(mainHtml, "Select Metro Area","FIND MY NEW HOME");
		//String[] sec=U.getValues(mainSec, "<img src=\"","<div class=\"overlay\">");
		//String[] sec=U.getValues(mainSec, "<div class=\"oi-aspect-content text-center text-white z-1\">","<div class=\"overlay\">");
		String[] sec=U.getValues(mainSec, "class=\"drop-cookie font-regular text-uppercase ls-1\"","</a></li>");
		U.log("sec==="+sec.length);
		for(String s:sec)
		{
			U.log("s: "+s);
			
			String url = U.getSectionValue(s, "href=\"", "\">");
		
			if(url==null)return;
			
			//for charlottee region
			if(url.contains("/nc/charlotte/floor-plans")) {
				url = url.replace("/new-homes/nc/charlotte/floor-plans/", "/new-homes/nc/charlotte/");
			};
			
			U.log("RegionUrl: "+"https://www.carusohomes.com"+url);
			
			String secHtml=U.getHtml("https://www.carusohomes.com"+url, driver);
			String[] commSec=U.getValues(secHtml, "<div class=\"col-md-6 col-sm-6 model-card community-card","View Community</a>");
			U.log("commSec==="+commSec.length);
			for(String value:commSec)
			{
				String comUrl="https://www.carusohomes.com"+U.getSectionValue(value, "href=\"","\"").replace("&amp;", "&");
//				try {
					addDetails(comUrl,value);
//				} catch (Exception e) {}
				U.log("url-->"+comUrl);
			}
			
		}
		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String oldData) throws Exception {
		// TODO Auto-generated method stub
//if(j == 7)
		//try{
	{

//		if(!comUrl.contains("https://www.carusohomes.com/new-homes/nc/garner/brant-station/10917/")) return;
		
		comUrl = comUrl.replace("�", "'");
		
		U.log("Count :"+j);
		
		if(comUrl.contains("https://www.carusohomes.com/new-homes/md/millers/shelleys-fields/3684/")){
			LOGGER.AddCommunityUrl(comUrl+"<=========== Page Not Found");
			return;
		}
		if(comUrl.contains("https://www.carusohomes.com/new-homes/de/camden-wyoming/quick-delivery-homes/8619/")){
			LOGGER.AddCommunityUrl(comUrl+"<=========== Return");
			return;
		}
		
	   if(comUrl.contains("https://www.carusohomes.com/new-homes/nc/cary/wellfield/5505/")) {
		   LOGGER.AddCommunityUrl(comUrl+"<=========== Not Found On region Page");
			return; 
	   }
	   if(comUrl.contains("https://www.carusohomes.com/new-homes/md/upper-marlboro/oakmont-estates/1488/")) {
		   LOGGER.AddCommunityUrl(comUrl+"<=========== Not Found On region Page");
			return; 
	   }
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"<=========== Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		U.log(j+"   commUrl-->"+comUrl);
//		U.log("commData-->"+oldData);
		String html=U.getHtml(comUrl, driver);
		String html2=html;
//		html=html.replaceAll("Princeton - Craftsman|<span class=\"subtitle\">Craftsman</span>", "Craftsman style details");
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(oldData, "<div class=\"flex-fill\">","<");
//		communityName=communityName;
		communityName = communityName.replace("’s", "'s");
		communityName = communityName.replace("�", "'");
		U.log("community Name---->"+communityName);
		
		
		//==========================================================================================
		String rem = U.getSectionValue(html, "Recommended For You</h1>", "<script type=\"text/javascript\">");
		
		if(rem!=null)
			html = html.replace(rem, "");
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=null;
		
		oldData = oldData.replaceAll("</div><div class=\"model-address font-small pb-\\d+\">", ",");
		addSec=U.getSectionValue(html,"COMMUNITY ADDRESS</h2>","<br></div>");
	//	U.log("HTML::"+html);
		if(addSec==null)
		 addSec=U.getSectionValue(html,"MODEL ADDRESS</h2>","</div>"); 
		
		U.log("addSec1 : "+addSec);
//		if(addSec==null)
//		 addSec=U.getSectionValue(html,"MODEL ADDRESS</h2>","<br>\n" + 
//		 		"                    </div>");
		
		if(addSec==null)
			addSec=U.getSectionValue(html,"SELLING FROM</h2>","</a>");
		
		
		U.log("addSec : "+addSec);
//		if(addSec!=null) {
//			
//			addSec = addSec.replaceAll("<br />|<br>", ",").replaceAll("Washington Overlook,|Windsor Manor,|Oakmont Estates,", "");
//			addSec = ">>> "+addSec+"<";
////			U.log("addSec : "+addSec);
//			addSec = U.getSectionValue(addSec, ">>>", "<");
//					
//		}
	/*	if(addSec!=null) {
			addSec=addSec.replaceAll("<br />|<br>", ",").replaceAll("Washington Overlook,|Windsor Manor,|Oakmont Estates,","");
		    add=U.getAddress(addSec);
		}*/
		if(addSec!=null) {
			addSec=addSec.replaceAll("<br />|<br>", ",").replaceAll("Washington Overlook,|Windsor Manor,|Oakmont Estates,","");
		addSec=addSec.replaceAll("Call for appointment|</h2>", "").replace("(GPS: 1525 Pointer Ridge Place)", "");
		}
//		U.log("addSec : "+addSec);
		
		if(addSec!=null)
		{
			addSec=addSec.replace("Cary NC", "Cary, NC").replace("GPS address:","").replace("Ave. Towson", "Ave, Towson").replace("Raleigh NC", "Raleigh, NC");
			add=U.getAddress(addSec);
//			U.log(add[0]);
			add[0]=add[0].replace("Wellfield, ", "");
			add[0]=add[0].replace("16580 Fife Way (GPS: 1525 Pointer Ridge Place)","16580 Fife Way");
			U.log("My Address is "+Arrays.toString(add));
		}
		
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
		
		String latSec=U.getSectionValue(html, "https://www.google.com/maps/@","z/data=");
		if(latSec==null) {
			latSec=U.getSectionValue(html, "<a target=\"_blank\" href=\"https://www.google.com/ma","\">");
		}
		if(latSec==null) {
			latSec=U.getSectionValue(html, "href=\"//maps.google.com/maps?q=","\"");
		}
		U.log(latSec);
		//latSec=U.getSectionValue(latSec, "212d","%212");
//		U.log(latSec);
		if(latSec!=null)
		{
			String[] lat=latSec.split(",");
			latlag[0]=Util.match(lat[0],"\\d+\\.\\d+");
			latlag[1]=Util.match(lat[1],"-\\d+\\.\\d+");
			U.log(latlag[0]+"\t"+latlag[1]);
		}
		if (addSec==null||addSec.equals("")||add[0].length()<4) {
			add=U.getAddressGoogleApi(latlag);
			if(add==null)add=U.getGoogleAddressWithKey(latlag);
			geo="TRUE";	
		}
		if(latlag[0] == ALLOW_BLANK && (latlag[1] == null || latlag[1] == ALLOW_BLANK)){
			if(add[0] != ALLOW_BLANK && add[3]!= ALLOW_BLANK){
				latlag = U.getlatlongGoogleApi(add);
				geo ="True";
			}
		}
		add[0]=add[0].replace("Lot 1 - King Farms Road", "King Farms Road");
				
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
	
		//=========================== Move In Ready ====================
		
				String moveInSection = U.getSectionValue(html, "Quick Move-in Homes</h1>", "Available Floor Plans</h1>");
				
				if(moveInSection ==null)
					moveInSection = U.getSectionValue(html, "Quick Move-in Homes</h1>", "id=\"area-map\"");

				String allMoveHomeData = ALLOW_BLANK;
				int moveInCount = 0;
				int dateCount = 0;
				
				U.log("moveInSection: "+moveInSection);
				
				//for status from quick
				int quickCount = 0;
				String quick = ALLOW_BLANK;
				
				if(moveInSection.contains("Jun 2022")) {
					
					quick = Util.match(moveInSection, "Jun 2022");
					U.log("quick: "+quick);
				}
				
				if(moveInSection != null){
//					String[] moveUrlSection = U.getValues(moveInSection, "<div class=\"card h-100 border-0", "</div>\n" + 
//							"		</div>\n" + 
//							"	</div>\n" + 
//							"</div>");
					//String[] moveUrlSection = U.getValues(moveInSection, "<div class=\"card h-100 border-0", "<a class=\"model-banner bg-primary text-white d-flex");
					String[] moveUrlSection = U.getValues(moveInSection, "<div class=\"card h-100 border-0", "<div class=\"model-status position");
					U.log("moveUrlSection length: "+moveUrlSection.length);
					
					for(String moveInSec : moveUrlSection){
						U.log("moveInSec: "+moveInSec);
						
						if(moveInSec.contains("2021"))
							dateCount++;
						String moveUrl ="https://www.carusohomes.com"+ U.getSectionValue(moveInSec, "href=\"", "\"");
						moveUrl = moveUrl.replace("amp;", "");
			
						U.log("moveUrl : "+moveUrl);
						
						
						String moveHtml = U.getHTML(moveUrl);
						allMoveHomeData += moveHtml;//U.getSectionValue(moveHtml, "<title>", "<div id=\"locationsMa");
					}

					moveInCount = moveUrlSection.length;
					U.log(moveInCount+"move in count");
					

				}
				
				//=========================== Floor In Ready ====================
				
				String floorInSection = U.getSectionValue(html, "Available Floor Plans</h1>", ">Explore The Area</h1><");
//				U.log(floorInSection);
				String allfloorHomeData = ALLOW_BLANK;
				int floorInCount = 0;
				if(floorInSection != null){
					String[] floorUrlSection = U.getValues(floorInSection, "<div class=\"card h-100 border-0\">", "</div></div>");
					for(String floorInSec : floorUrlSection){
						//U.log(moveInSec);
						String floorUrl ="https://www.carusohomes.com"+ U.getSectionValue(floorInSec, "href=\"", "\"");
						floorUrl = floorUrl.replace("amp;", "");
			
						U.log("floorUrl : "+floorUrl);
						
						
						String floorHtml = U.getHTML(floorUrl);
						U.log(U.getCache(floorUrl));
						allfloorHomeData += floorHtml;//U.getSectionValue(moveHtml, "<title>", "<div id=\"locationsMa");
					}

					floorInCount = floorUrlSection.length;
					U.log(floorInCount+"floor in count");
					

				}
//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		oldData=oldData.replaceAll("1 million|1&nbsp;million","1,000,000").replace("0s","0,000").replace("1.1 Million", "1,100,000");
		html=html.replaceAll("0s|0's|0s|0&#8217;s","0,000").replace("From the </span>$379s", "From the \\$379,000");
		html = html.replace("$1.6 million", "$1,600,000").replace(" $1 Million", "$1,000,000");
		//oldData+allMoveHomeData
		String prices[] = U.getPrices(html+oldData + allfloorHomeData + allMoveHomeData,
				"Base Price \\$\\d{3},\\d{3}|<div class=\"price\">\\$\\d{3},\\d{3}</div>|to \\$\\d,\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}</span>|From the </span>\\$\\d{3},\\d{3}|From the </span>\\d{3},\\d{3}|Upper \\$\\d{3},\\d{3}|&nbsp;\\$\\d+,\\d+,\\d+|the \\$\\d,\\d+,\\d+|mid \\$\\d{3},\\d+|low \\$\\d{3},\\d+|mid \\$\\d{3},\\d+|the \\$\\d{3},\\d+|stivaProductPrice\">\\&#36;\\d{3},\\d{3}|&nbsp;\\$\\d+,\\d+|the \\$\\d+,\\d+|to \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|to \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",0);
		//U.log(html);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		//if(comUrl.contains("https://www.carusohomes.com/new-homes/nc/raleigh/meadows-of-banks/5299/"))maxPrice="$728,727";
//======================================================Sq.ft===========================================================================================		
		
	
		
		String[] sqft = U
				.getSqareFeet(
						html+oldData+allMoveHomeData + allfloorHomeData,
						"with \\d{4}\\+ square feet|with \\d{4}\\+ sq ft|from \\d{4} to over \\d{4} square feet|\\d,\\d{3} - \\d,\\d{3} Sq Ft|\\d,\\d{3}-\\d,\\d{3} Sq Ft|\\d,\\d{3} Sq Ft|from \\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d{3} square feet|Sq. Ft. \\d,\\d{3} – \\d,\\d{3}|Sq. Ft. \\d,\\d{3} - \\d,\\d{3}|Sq. Ft. \\d,\\d{3} – \\d{3},\\d{3}|Sq. Ft. \\d+,\\d+  \\d+,\\d+|Sq. Ft. \\d+,\\d+|up to \\d,\\d{3} square feet|Sq.<span> Ft.</span> \\d{4}<|Sq. Ft. Starting at \\d,\\d{3}",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);

		

//================================================community type========================================================
		html=html.replace("\"after 55\" lifestyle.", "55+ community").replaceAll("homes, active adult|custom luxury homes|luxury single family|Prospect Bay Country|Harbor Golf|Creek Golf|\\/masterplans\\/","")
				.replace("Waterfront Series", "Waterfront Community");
		String communityType=U.getCommType((html+oldData));
		
//==========================================================Property Type================================================
		//html = html.replaceAll("Center Hours:</strong><br />\\s+ Coming Soon|Price: Coming|base\">Coming|--Coming|--Now sell", "");
		html = html.replaceAll("Loaded with Luxury| luxury and function", "luxury home").replace("feature luxury owner's", "luxury homes").replaceAll("new section opens.|content=\"luxury|Courtyard by Marriot", "");
		
		html = html.replaceAll("Quick Move|items-center\">\n\\s+Now Selling|items-center\">\n\\s+Community Close-Out", "");
		
		html=U.getNoHtml(html.replace("craftsman.jpg", ""));
		String remHoaSec=U.getSectionValue(allfloorHomeData, "<span class=\"input-group-addon\">", "Calculate</button>");
		if(remHoaSec==null)
			remHoaSec=U.getSectionValue(allMoveHomeData, "<span class=\"input-group-addon\">", "Calculate</button>");
		
		if(allfloorHomeData!=null){
			allfloorHomeData = allfloorHomeData.replace("craftsman styles", "Craftsman Collection").replaceAll("two-story", " 2 Story")
			.replace("elevations, including brick and stone combination fronts and craftsman styles","");
		
			if(remHoaSec!=null)
				allfloorHomeData = allfloorHomeData.replaceAll(remHoaSec, "");
		}
		if(remHoaSec!=null)
			allMoveHomeData=allMoveHomeData.replace(remHoaSec, "");
		
		
		String proptype=U.getPropType((html+oldData+allMoveHomeData+allfloorHomeData)
				.replace("Luxury 2-Car Garage Townhomes", "luxuries 2-Car Garage Townhomes")
				.replaceAll("celebrated luxury home builder|-hoa-|hoa mb|hoa\"|'hoa'|\"HOA\"|traditional holiday|patio in the back is a great place|estate homesite|luxury baths|farmhouse sink|Farmhouse Sink", ""));
		
//		U.log("<<<<< "+Util.matchAll((html+oldData+allMoveHomeData+allfloorHomeData), "[\\s\\w\\W]{30}Townhome[\\s\\w\\W]{30}", 0));
		
		if(comUrl.contains("https://www.carusohomes.com/communities/olde-mill-trace?id=Olde Mill Trace&state=NC"))
			proptype = proptype.replace(", Farmhouse Style Homes", "");
		
		if(comUrl.contains("https://www.carusohomes.com/new-homes/md/bowie/amber-ridge/8720/"))
			proptype = proptype.replace(", Townhome", "");
		if(proptype.contains("Townhouse, Townhome")) {
			proptype ="Townhouse";
		}
		U.log("proptype: "+proptype);
//==================================================D-Property Type======================================================
		html=html.replace("Four level","4 Story");//.replace("second-floor", "");
		String dropRemSec=ALLOW_BLANK;
		if(allfloorHomeData.contains("<div class=\"dropdown\">"))
			dropRemSec=U.getSectionValue(allfloorHomeData, "<div class=\"dropdown\">", "</div>");
		
		if(allMoveHomeData.contains("<div class=\"dropdown\">"))
			dropRemSec=U.getSectionValue(allMoveHomeData, "<div class=\"dropdown\">", "</div>");
		
		allfloorHomeData=allfloorHomeData.replace(dropRemSec, "").replaceAll("text-underline\">First Floor Owner Suites</span>|name=\"First Floor \">First|r plan-img-1\" data-plan-name=\"First Floor \">First Floor<img src=\"https|downMenuButton\" type=\"button\">First Floor</button><ul aria-labelledby=|data-plan-name=\"First Floor\">First Floor<img alt=\"First F|r plan-img-1\" data-plan-name=\"First Floor \">First Floor<img src=\"https|alt=\"First Floor \" class=\"d-none\"", "");
		allMoveHomeData=allMoveHomeData.replace(dropRemSec, "");
		String dtype=U.getdCommType((html+allMoveHomeData+allfloorHomeData).replace(dropRemSec, "").replace("2nd level", "second level").replace(" second floor ", " second story ").replace(" 3rd floor", "3 story")
		.replaceAll("one-of-a-kind ranch floor", "")); ///|First Floor Owner|2nd Floor
//		U.log("mmm: "+Util.match(allfloorHomeData, "[\\w\\s\\W]{30}Second Floor[\\w\\s\\W]{30}"));
		U.log("dtype: "+dtype);
//==============================================Property Status=========================================================
	//	html=html.replace("COMING SOON!", "");
		oldData=oldData.replace("COMING SOON!", "");
//		U.log("oldData====="+oldData);
		html = html.replace("New Section -- Coming Soon", "New Section Coming Soon")
				.replaceAll("Lots are available by monthly|Now selling from|our list of currently available move-in|Hours:\\s*Coming Soon| Now selling from   Washington Overlook", "");
		oldData=oldData.replace("New Section -- Coming Soon", "New Section Coming Soon").replaceAll("our list of currently available move-in|Hours:\\s*Coming Soon", "");
		
		String pstatus=U.getPropStatus((oldData + html).replaceAll("Coming Soon--Join Our VIP List|last remaining opportunity at The Reserve at Wackena|Last Opportunity at Magnolia Cove|Grand Opening offer|[q|Q]uick [d|D]elivery|Now Selling --|grocery store opening this Fall|<p>Now selling from <a|Currently selling out of|Now selling by appointment|Now Selling from   Oakmont|Now Selling from <b>|Move-In Homes Available NOW", ""));

//		U.log("mmm: "+Util.match(oldData + html, "[\\w\\s\\W]{30}Now selling[\\w\\s\\W]{30}"));

		if(quick.equals("Jun 2022")){ // && moveInCount>dateCount){
			if(pstatus == ALLOW_BLANK){
				U.log("hhhi");
				pstatus = "Quick Move-in Homes";}
			else{
				U.log("byee"); 
				pstatus = pstatus+", Quick Move-in Homes";}

		}
		else
		{
			pstatus=pstatus.replace(", Move-in Ready Homes", " ");
			U.log(pstatus);
		}
		if(pstatus.contains("Quick Move-in Homes")) {
			pstatus=pstatus.replace("Move-in Ready,", "");
		}
		pstatus = pstatus.replace("Only 3 Opportunities Left, Only 3 Opportunities Remain", "Only 3 Opportunities Remain").replace("One Opportunity Left, One Opportunity Remaining", "One Opportunity Remaining");
		if(comUrl.contains("https://www.carusohomes.com/new-homes/nc/raleigh/meadows-of-banks/5299/"))
		pstatus=pstatus.replace("Last Remaining Opportunity, Only 1 Opportunity Remains, Only 1 Opportunity Remain, 1 Opportunity Remains, ","");
		
		
		U.log("pstatus ======== : "+pstatus);
		
//		U.log("mmm: "+Util.match(html+oldData, "[\\w\\s\\W]{30}Opportunity Remains[\\w\\s\\W]{30}"));
//============================================note====================================================================
		String note=U.getnote(html.replace("no more pre-sale opportunities", ""));
		//===================================================================================================
		if(comUrl.contains("https://www.carusohomes.com/new-homes/md/brandywine/magnolia-cove/4030/"))pstatus = pstatus.replace("One Opportunity Remains", "Only One Opportunity Remains");
		
		//=====================siteplan===============
		String sitePlanSec=U.getSectionValue(html2,"Interactive Siteplan</h1>", "</iframe></div></div></div></div></div>");
		String noOfUnits=ALLOW_BLANK;
		int lotCount=0;
		if(sitePlanSec!=null) {
			U.log("hello");
			U.log(sitePlanSec);
		String iframe=U.getSectionValue(sitePlanSec, "<iframe", ">");
		U.log("Iframne"+iframe);
		String siteMapUrl=U.getSectionValue(iframe, "src=\"", "\"").replace("amp;", "").replaceAll("\\s+", "");
		U.log("siteMap Url"+siteMapUrl);
		String siteMapHtml=U.getHtml(siteMapUrl, driver);
		U.log("Path::"+U.getCache(siteMapUrl));
		//String [] lotadata=U.getValues(siteMapHtml, "<img id=\"topoImgLot", ">");
		String [] lotadata=U.getValues(siteMapHtml, "<img id=", ">");
		lotCount=lotadata.length;
		noOfUnits=Integer.toString(lotCount);
	    
		if(noOfUnits.equals("0"))
	    	noOfUnits=ALLOW_BLANK;
		}
		U.log("No.of units= "+noOfUnits);		
		
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("Delaware Regional Office, ", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);
	}
	j++; 
		//}catch (Exception e) {}
	}

}