package com.shatam.b_181_200;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import org.apache.bcel.generic.LADD;
import org.omg.CORBA.INTERNAL;

import java.net.*;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
//import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractClasicBuilders extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	HashMap<String, String> comLatLng = new HashMap<>();
	private static final String BUILDER_URL = "http://classicbuildersiowa.com/";
	//static Hashtable<String, String[]> LatLong = new Hashtable<String, String[]>();
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractClasicBuilders();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Classic Builders.csv", a.data()
						.printAll());

	}

	// t https://www6.software.ibm.com/reg/rational/rational-i
	public ExtractClasicBuilders() throws Exception {

		super("Classic Builders", BUILDER_URL);
		LOGGER=new CommunityLogger("Classic Builders");
	}

	public void innerProcess() throws Exception {
		
		String developmentHtml = U.getHTML("http://classicbuildersiowa.com/developments/");
//		U.log(developmentHtml);
		String [] comlatlngSections = U.getValues(developmentHtml, "<h2><a href=", "</div>");
		U.log("comlatlngSections : "+comlatlngSections.length);
		String planListingHtml=U.getHTML("http://classicbuildersiowa.com/listings");
		String page=U.getSectionValue(planListingHtml, "<ul class='page-numbers'>", ">Next");
//		U.log(page);
		String lastpage=Util.match(page, "href='https://classicbuildersiowa.com/listings/page(/\\d/'>(\\d))</a></li><li><a class=\"next",2);//U.getSectionValue(page, "</a></li><li><a class='page-numbers'", "<a class=\"next");
		for(int i=2;i<=Integer.parseInt(lastpage);i++){
			planListingHtml+=U.getHTML("http://classicbuildersiowa.com/listings/page/"+i);
		}
		for(String comLatLngSec: comlatlngSections){
			String cName = U.getSectionValue(comLatLngSec, "\">", "</a>");
			comLatLng.put(cName, comLatLngSec);
		}
		String plans[]=U.getValues(planListingHtml, "<div class=\"es-property-info\">", "Details");
//		U.log(plans.length);
		String html = U.getHTML("http://classicbuildersiowa.com/");
		String section = U.getSectionValue(developmentHtml, ">Developments</a>",">Commercial</a>");
//		U.log(section);
		String comUrlSection[] = U.getValues(section, "><a","/a>");
		for (String comUrlSec : comUrlSection) {
			int k=0;
			U.log("Community :::::::::::::::::::::::::::::::::::::::::");
			if(comUrlSec.contains("href=\"#\""))continue;
			String comName=U.getSectionValue(comUrlSec,">", "<");
			//U.log(comName);
			String comUrl = U.getSectionValue(comUrlSec,"href=\"", "\"");
//			if(!comName.toLowerCase().contains("KINGS LANDING".toLowerCase()))continue;
			String planData=ALLOW_BLANK;
			for(String p:plans){
					String planHtml=U.getHTML(U.getSectionValue(p, "href=\"", "\"").replaceAll("https:", "http:"));
//					U.log(planHtml);
					String temPlanSec = U.getSectionValue(planHtml, "rel=\"tag\">Residential", "<h3>Rooms Description</h3>");
//					U.log(temPlanSec);
					if(temPlanSec==null)continue;
//					U.log(temPlanSec.toLowerCase().contains(comName.toLowerCase()));
					if(temPlanSec.toLowerCase().contains(comName.toLowerCase())){
						planData+=temPlanSec;
//						U.log(k++);
//						U.log(planData);
					}

			}
			findCommunityDetails(comUrl.replaceAll("https:", "http:"),comUrlSec,planData);

		}
		
	
		LOGGER.DisposeLogger();
	}
	private void findCommunityDetails(String comUrl, String comSec,String plandata)throws Exception{
	//if(j == 25)
//if(!comUrl.contains("http://classicbuildersiowa.com/developments/painted-woods/"))return;
	{
		
		
		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
			return;
		}
		if (!comUrl.contains("developments")){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"\turl:::"+comUrl);
		String html = U.getHTML(comUrl);
	//	U.log("html:1::::::::::::::"+html+"::::::::::::::::::::");
		//=========== CommName ================
		String comName = Util.match(comSec,">(.*?)$",1);
		U.log("comName:::"+comName);
		
		//============== Address ==================
		String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "False";
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String addSec = ALLOW_BLANK;
		if(comLatLng.containsKey(comName)){
			U.log("::::::::::::::IF :::::::::::::::::Address & LatLng From Region Pages");
			addSec = U.getSectionValue(comLatLng.get(comName), "https://www.google.com/maps/place/", "/");
			addSec = addSec.replaceAll("\\+", " ");
			U.log(addSec);
			addSec = addSec.replaceAll("<(.*?)>", "");
			add = U.getAddress(addSec);
			
			String latlngSec = U.getSectionValue(comLatLng.get(comName), "/@", ",17z");
			latLng = latlngSec.split(",");
		}
		else{
			U.log("::::::::::::::ELSE:::::::::::::::::");
			addSec = U.getSectionValue(html, "href=\"https://www.google.com/maps", "Directions</a>");
			if(addSec == null) {
			if(comUrl.contains("http://classicbuildersiowa.com/developments/36-west/")) {
				addSec="/place/Ankeny,+IA,+USA/@41.7441442,-93.6337652,1166m/data=!3m1!1e3!4m5!3m4!1s0x87ee8513f1d17fc9:0x85b00ee7d535dcec!8m2!3d41.7317884!4d-93.6001278";
				geo="TRUE";

			}
			if(comUrl.contains("http://classicbuildersiowa.com/developments/painted-woods/")) {
				 addSec="/place/3109-3059+Ashworth+Rd,+Waukee,+IA+50263,+USA/@41.5756636,-93.8927421,847m/data=!3m2!1e3!4b1!4m13!1m7!3m6!1s0x87ec22e37f3a3b7b:0xe27af47a5bde824c!2sPainted+Woods+Dr,+Waukee,+IA+50263,+USA!3b1!8m2!3d41.5703999!4d-93.8783142!3m4!1s0x87ec2320a91b8699:0x73d7d735ea568072!8m2!3d41.5756596!4d-93.8905481";
					geo="TRUE";
				}
			}
			if(comUrl.contains("http://classicbuildersiowa.com/developments/eagle-grove/"))
			{
				addSec = "https://www.google.com/maps/place/42%C2%B039'34.1%22N+93%C2%B053'20.0%22W/@42.659463,-93.8899838,426m/data=!3m2!1e3!4b1!4m14!1m7!3m6!1s0x87f21a9c3d4e68e9:0x17a4cca86ce107cc!2sEagle+Grove,+IA+50533!3b1!8m2!3d42.6641396!4d-93.9044473!3m5!1s0x0:0x0!7e2!8m2!3d42.6594634!4d-93.8888918?shorturl=1";
				geo="TRUE";
			}
			if(comUrl.contains("http://classicbuildersiowa.com/developments/trestle-ridge-estates/")){
				addSec = "https://www.google.com/maps/place/41%C2%B045'10.8%22N+93%C2%B038'25.1%22W/@41.753,-93.6424943,860m/data=!3m2!1e3!4b1!4m6!3m5!1s0x0:0x0!7e2!8m2!3d41.7529928!4d-93.640303";
				geo="TRUE";
			}
			if(comUrl.contains("http://classicbuildersiowa.com/developments/painted-woods/")){
				addSec = "https://www.google.com/maps/place/3109-3059+Ashworth+Rd,+Waukee,+IA+50263,+USA/@41.5756596,-93.8927368,680m/data=";
				geo="TRUE";
			}
			if(comUrl.contains("http://classicbuildersiowa.com/developments/deer-creek/")) {
				addSec="https://www.google.com/maps/place/41%C2%B044'46.6%22N+93%C2%B033'39.1%22W/@41.7462778,-93.5630498,678m/data=!3m2!1e3!4b1!4m6!3m5!1s0x0:0x0!7e2!8m2!3d41.7462874!4d-93.5608585";
			}
			if(comUrl.contains("http://classicbuildersiowa.com/developments/kings-landing/")) {
				addSec="https://www.google.com/maps/place/41%C2%B032'33.5%22N+93%C2%B050'43.2%22W/@41.5426389,-93.847522,680m/data=!3m2!1e3!4b1!4m9!1m2!10m1!1e2!3m5!1s0x0:0x0!7e2!8m2!3d41.5426339!4d-93.8453191";
			}

		U.log("=-=-="+addSec);
		
		if(addSec != null){
			if(addSec.contains("/data=") && !addSec.contains("/@")){
				addSec = U.getSectionValue(addSec, "/place/","/data=");
				U.log("=-=-=-=-"+addSec);
				add = U.getAddress(addSec.replace("+", " "));
			}
			
			if(addSec.contains("/data=") && (addSec.contains("Ankeny,+IA+50023")||addSec.contains("+IA+500")|| addSec.contains("+IA+50263"))){
				String addSec1 = U.getSectionValue(addSec, "/place/","/@");
				U.log("==="+addSec1);
				add = U.getAddress(addSec1.replace("+", " "));
				if(add[2]==null) {
					add=addSec1.replaceAll(",\\+USA|\\+", " ").replace("IA 50263", "IA,50263").split(",");
				}
			}
			if(add[0]==ALLOW_BLANK&&addSec.contains("+IA+")){
				String addSec1 = U.getSectionValue(addSec, "!2s","!3b");
				U.log("==="+addSec1);
				add = U.getAddress(addSec1.replace(",+USA", "").replace("+", " "));
			}
			if(addSec.contains("/@")){
				Matcher mat = Pattern.compile("\\d{2}\\.\\d{3,},-\\d{2}\\.\\d{3,}",Pattern.CASE_INSENSITIVE).matcher(addSec);
				while(mat.find()){
					latLng = mat.group().split(",");
				}
			}
			
		}
		}
		U.log("Add:::"+Arrays.toString(add));
		//============== LatLng ===================
		
		
		U.log("LatLng:::"+Arrays.toString(latLng));
		if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK){
			latLng = U.getlatlongGoogleApi(add);
			geo = "True";
		}
		if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK ){
			if((add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK )|| add[0].contains("Unnamed Road")){
				add = U.getAddressGoogleApi(latLng);
				geo = "True";
			}
		}
//		if(comUrl.contains("http://classicbuildersiowa.com/developments/kings-landing/")||comUrl.contains("http://classicbuildersiowa.com/developments/deer-creek/")){
//			//https://goo.gl/maps/EaQHTNHH9Xy ---->map link
//			latLng[0]="41.54264";
//			latLng[1]="-93.84533";
//			add = U.getAddressGoogleApi(latLng);
//			geo = "TRUE";
//		}
		//U.log(plandata);
		//============ Price ====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//U.log("html:::::::::::::::"+html+"::::::::::::::::::::");
		String[] price = U.getPrices(html+plandata,
						"<b>Price: \\d+,\\d+|Price: \\$\\d{2},\\d{3}&lt|\\$\\d+,\\d+|\\$ \\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		//=============== Sqft ======================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
//		String[] sqft = U.getSqareFeet(	html,
//						" <dd>\\d+,\\d+</dd>|>\\d{1},\\d{3}\\-sq|\\d{4}-sq|\\d{4}-Sq Ft|\\d,\\d+ sq. ft.",
//						0);
		String [] sqft=U.getSqareFeet(html+plandata, "Area: </strong>\\d{4} sq ft</li>", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqf :" + minSqf + " MaxSqf:" + maxSqf);

		if(comUrl.contains("https://classicbuildersiowa.com/developments/kings-landing/")){
			minPrice = "$359,900";maxPrice="$399,900";minSqf="823";maxSqf="1235";//from Image
		}
		//================= Proerty Types =================
		html = html.replaceAll("Villas at Stone|Multi Family|villas-at-stone|villas-brinmore-estates/\">Villas|villas-at-stonehaven/\">Villas|hoa-info/home\">HOA", "").replace("HOA</a>", " HOA ");
		String propType = U.getPropType(html+comName);
		
		//================= Derived Types ===================
		html =html.replaceAll("Story</a>|two-story-plans|ranch-plans/\">Ranch</a>", "");
		String dType = U.getdCommType(html);
		
		//================= Community Types =================
		String comType = U.getCommunityType(html);
		
		//================= Property Status ==================
		String pStatus = U.getPropStatus(html);
		
		//================= Notes ========================
		String notes = ALLOW_BLANK;
		if(comUrl.contains("/developments/kings-landing/")) {
			minPrice="$359900";
			maxPrice="$399900";
			minSqf="1610";
			maxSqf="1868";
		}
		data.addCommunity(comName.replaceAll("<", ""), comUrl, comType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(notes);
		
	}
	j++;
	}

	private void addDetails(String urls) throws Exception {
		// if(j==6)
		{
			U.log(urls);
			String htm = U.getHTML("http://www.classicbuildersiowa.com/");
			urls = "http://www.classicbuildersiowa.com" + urls;
			
			//404 error
			U.log(urls);
			if(urls.contains("http://www.classicbuildersiowa.com/developments/sienna-falls-plat-2-ankeny"))return;
			String html = U.getHTML(urls);

			String priceSec = U.getSectionValue(html, "hover(function(){",
					"clearTimeout");
			// U.log("pri==========="+priceSec);
			String name = urls.replaceAll(
					"http://www.classicbuildersiowa.com/developments/", "")
					.replace("-", " ");

			// U.log("=====pname=="+name);

			// latlng
			String dirrHtml = "";
			String direction = U.getSectionValue(html,"Contact Us</span>","Directions</span>");
			if(direction!=null)
			{
	//			direction = direction.replace("<a href=\"/documents/", "");
				U.log("direction::"+direction);
				String diru = U.getSectionValue(direction, "<a href=\"","\"");
				
				if (!diru.contains("#")) {
					U.log("diru::"+diru);
					dirrHtml = U.getHTML(diru);
					//U.log(dirrHtml);
				} else {
					U.log("Bye");
					diru = "https://goo.gl/maps/rHRPr61GWH92";
					dirrHtml = U.getHTML(diru);
				}
			}
		

			// sqft prices

			String availHtml = U
					.getHTML("http://www.classicbuildersiowa.com/available-homes");
			String avlHtmlNext = U
					.getHTML("http://www.classicbuildersiowa.com/available-homes?start=20");
			String availUrlSec[] = U.getValues(availHtml, " <a href=\"",
					"\"ip-property-header-accent\">");
			String avlHtml = "";
			String a = "";
			for (String aUrl : availUrlSec) {
				aUrl = Util.match(aUrl, "<a href=\"(.*?)\" class=", 1);
				a = aUrl;
				 U.log("---------------------------------------"+a);
				avlHtml = U.getHTML("http://www.classicbuildersiowa.com" + a);
			}
			if(!avlHtmlNext.contains("Sorry, no records were found. Please try again."))
			{
			String availUrlSec1[] = U.getValues(avlHtmlNext, " <a href=\"",
					"\"ip-property-header-accent\">");
			String avlHtml1 = "";
			String a1 = "";
			for (String aUrl1 : availUrlSec1) {
				aUrl1 = Util.match(aUrl1, "<a href=\"(.*?)\" class=", 1);
				a1 = aUrl1;
				// U.log("---------------------------------------"+a1);
				avlHtml1 = U.getHTML("http://www.classicbuildersiowa.com" + a1);
			}
			}
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			String[] price = U
					.getPrices(
							priceSec + html,
							"<b>Price: \\d+,\\d+|Price: \\$\\d{2},\\d{3}&lt|\\$\\d+,\\d+",
							0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			
			String[] sqft = U
					.getSqareFeet(
							html,
							" <dd>\\d+,\\d+</dd>|>\\d{1},\\d{3}\\-sq|\\d{4}-sq|\\d{4}-Sq Ft|\\d,\\d+ sq. ft.",
							0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("MinSqf :" + minSqf + " MaxSqf:" + maxSqf);

			String geo = "TRUE";
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			String latlngs[] = { ALLOW_BLANK, ALLOW_BLANK };

			if (dirrHtml != null&&dirrHtml!="") {
				
				latlngs[0] = Util.match(dirrHtml, "\\d{2}\\.\\d+]").trim();
				latlngs[0] = latlngs[0].replace("]", "");
				latlngs[1] = Util.match(dirrHtml, "-\\d{2}\\.\\d+").trim();
				U.log("latlngs :: "+latlngs[0]+"  "+latlngs[1]);
			}
			//U.log("name :: "+name);
			add[2] = "IA";
			add[1] = name;
			if (latlngs[0] != ALLOW_BLANK && add[0] == ALLOW_BLANK
					&& add[1] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latlngs);

				geo = "TRUE";
			}
			String status = U.getPropStatus(html);
			
			/*minPrice = "$159900";
			maxPrice = "$271900";*/
			minSqf = "1354";
			maxSqf = "2418";
			
			//to remove city name from community name
			add[1]=add[1].trim().toLowerCase();
			name=name.trim().toLowerCase();
			//if((name.endsWith(add[1]))&& (!add[1].contains("centennial pointe")))name=name.replace(add[1], "");
			name=name.replaceAll("ankeny|grimes", "");
			U.log("commName:"+name+":City::"+add[1]);
			String notes=U.getnote(html);
			if(latlngs[0].length()<5)
			{
				U.log("commName:"+add[2]+":City::"+add[1]);
				add[1]=add[1].replaceAll("autumn crest plat 5 ankeny|centennial pointe west plat 3 ankeny|stonehaven plat 1|trestle point plat 3 ankeny","ankeny");
				latlngs=U.getlatlongGoogleApi(add);
				geo="TRUE";
				notes="Address Taken From City And State";
			}
			if(add[0].length()<5)
			{
				add=U.getAddressGoogleApi(latlngs);
				geo="TRUE";
			}
			//if(urls.contains("http://www.classicbuildersiowa.com/developments/trestle-point-plat-3-ankeny"))geo="false";
			
			html = html.replaceAll("map/villas_at_stonehaven.|Classic Two Stories|2-Story-Packet|classic-2-story|/Ranch-Packet|Classic Ranches|images/classic-ranch|Classic XL Ranches|classic-xl-Ranches-| HOA Info|common areas,|HOA Fees typically|HOA please contact: HOA|hoa-info/home\">HOA Info", "");
			name=name.replaceAll("plat 1|plat 3|plat 5","");
			
			//Add Data
			data.addCommunity(name, urls, U.getCommunityType(html));
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlngs[0].trim(), latlngs[1].trim(), geo);
			data.addPropertyType(U.getPropType(html), U.getdCommType(html.replaceAll("Stonehaven two|Stonehaven 2-Story","")));
			data.addPropertyStatus(status);
			data.addNotes(notes);

		}

		j++;
		
	}
	public static String getRedirectedURLConnection(String url) throws IOException{	
		String newUrl=null;	
		URL obj = new URL(url);	
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
		int status = conn.getResponseCode();
		U.log(status);
		//if (status != HttpURLConnection.HTTP_OK) {	
			
			if (status == HttpURLConnection.HTTP_MOVED_TEMP	|| status == HttpURLConnection.HTTP_MOVED_PERM|| status == HttpURLConnection.HTTP_SEE_OTHER){	
				newUrl = conn.getHeaderField("Location");			
				}
			U.log("new Url:::::::"+newUrl);
			return newUrl;		
		/*}
		else	
			return url;	
			*/
		}

}