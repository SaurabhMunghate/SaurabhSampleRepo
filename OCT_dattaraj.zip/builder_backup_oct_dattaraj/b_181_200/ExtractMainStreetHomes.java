package com.shatam.b_181_200;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMainStreetHomes extends AbstractScrapper {

	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	int i = 1;
	private final static String BUILDER_URL = "https://www.gomsh.com";
	
	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new ExtractMainStreetHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Main Street Homes.csv", a.data().printAll());
	}

	public ExtractMainStreetHomes() throws Exception {

		super("Main Street Homes", BUILDER_URL);
		LOGGER = new CommunityLogger("Main Street Homes");
	}
	
	public void innerProcess() throws Exception {
		long startTime = System.currentTimeMillis();
		String url = "https://www.gomsh.com/find-your-home";
		String html = U.getHTML(url);
		
		int in=1;
		String mainSec=U.getSectionValue(html, "PRELOADED_STATE__ =", "</script>");
		String comSection[] = U.getValues(mainSec, "{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"");
		U.log(">>>>> "+comSection.length);
		
		for(String com:comSection) {
			String published = U.getSectionValue(com, "\"published\":", ",\"");
			if(published.equals("false")) continue; 
			
			//String parent_community = U.getSectionValue(com, "\"parent_community\":\"", "\",");
			//if(parent_community != null) continue;
			String sharedName = U.getSectionValue(com, "\"sharedName\":\"", "\",");	
			in++;
//			U.log("com====="+com);
//			String comUrl="https://www.gomsh.com/communities/"+U.getSectionValue(com, "\"area\":\"", "\",").toLowerCase()+"/"+
//					U.getSectionValue(com, "\"sharedName\":\"", "\",");
//	U.log(" comUrl: "+comUrl);
			getDetails(com, html);	
		}
		
		U.log("Count: "+in);
		LOGGER.DisposeLogger();
		U.log("Time Taken: "+(System.currentTimeMillis() - startTime));
	}

	private void getDetails(String comSec, String html) throws Exception {
//		if(i>=0 && i<=10)
		{
		//========= Community Url
		String comUrl="https://www.gomsh.com/communities/"+U.getSectionValue(comSec, "\"area\":\"", "\",").toLowerCase()+"/"+
						U.getSectionValue(comSec, "\"sharedName\":\"", "\",");
		
		//For url changes
		if(comUrl.equals("https://www.gomsh.com/communities/chesterfield/cosby-village-2story-townhomes")) {
			comUrl = "https://www.gomsh.com/communities/chesterfield/cosby-village-2-story-townhomes#detail";
		}
		if(comUrl.equals("https://www.gomsh.com/communities/chesterfield/cosby-village-3story-townhomes")) {
			comUrl = "https://www.gomsh.com/communities/chesterfield/cosby-village-3-story-townhomes#detail";
		}
		if(comUrl.equals("https://www.gomsh.com/communities/chesterfield/harpers-mill-glen-royal")) {
			comUrl = "https://www.gomsh.com/communities/chesterfield/harpers-mill-glen-royal#detail";
		}
		if(comUrl.equals("https://www.gomsh.com/communities/chesterfield/harpers-mill-fishers-green")) {
			comUrl = "https://www.gomsh.com/communities/chesterfield/harpers-mill-fishers-green#detail";
		}
		if(comUrl.contains("collington-east-")) {
			comUrl = comUrl+"#detail";
		}
		if(comUrl.contains("harpers-mill-haynes-bridge")) {
			comUrl = comUrl+"#detail";
		}
		
//----- SINGLE EXECUTION
//		if(!comUrl.contains("https://www.gomsh.com/communities/chesterfield/westerleigh")) return;
		
		
//		U.log("com==="+comSec); //Get data of community.
		U.log(+i+" comUrl: "+comUrl);
		//============ Community Logger
		if(comUrl.equals("https://www.gomsh.com/communities/chesterfield/harpers-mill") ||
				comUrl.equals("https://www.gomsh.com/communities/chesterfield/cosby-village") || 
				comUrl.equals("https://www.gomsh.com/communities/chesterfield/collington-east")) {
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------RETURNED");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//========= Community Name
		String comName = U.getSectionValue(comSec, "com\",\"name\":\"", "\",");
		comName = comName.replaceAll(" 3-Story Townhomes$| 2-Story Townhomes$| Townhomes$", "");
		U.log("comName: "+comName);
		
		//============ Address
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String street = U.getSectionValue(comSec, "\"streetAddress\":\"", "\"},\"");
		if(comUrl.contains("/cosby-village-2-story-townhomes#detail")) {
			street = street.replace("15220 Dunton Avenue", "6860 Dunton Road");
		}
		if(comUrl.contains("gomsh.com/communities/goochland/tuckahoe-bridge")) {
			street = "2114 Tuckahoe Bridge Dr";//=====remm
		}
		street = street.replace("Nash Road", "8400 Highland Glen Drive");
		street = street.replace("Benton Pointe Way", "11305 Magill Terrace Drive");
		street = street.replace("Tilmans Farm Drive", "3761 Tilman's Farm Drive");
		
		String city = U.getSectionValue(comSec, "\"addressLocality\":\"", "\",\"");
		String state = U.getSectionValue(comSec, "\"addressRegion\":\"", "\",\"");
		String zip = U.getSectionValue(comSec, "\"postalCode\":\"", "\",\"");
		
		U.log("ADDRESS: "+street+" - "+city+" - "+state+" - "+zip+" - "+geo);
		
		//============ Geo Index
		String geoSec = U.getSectionValue(comSec, "\"geoIndexed\":[", "],\"");	
		String[] geoo = geoSec.split(",");
		String lat = geoo[1];
		String lon = geoo[0];
		U.log("LAT: "+lat+" LNG: "+lon);
		
		latLng[0] = lat;  
		latLng[1] = lon;
		
		//============ Unique ComKey
		String comUniqueId = U.getSectionValue(comSec, "\"_id\":\"", "\",");
		//U.log("comUniqueId: "+comUniqueId);
		
		//============ Available Floor Plan Data
		String planData = ALLOW_BLANK;
		String[] planSecs = U.getValues(html, "\"@type\":\"ProductModel\"", "\"type\":\"plan\"");
		//U.log("planSecs: "+planSecs.length);
		int floorCount=0;
		for(String plan:planSecs) {
			String[] planIds = U.getValues(plan, "\"community\":\"", "\"");
				for(String id:planIds) {
					//MATCH
					if(comUniqueId.equals(id)) {
						planData += plan;
//						U.log(plan);
						floorCount++;
					}
				}
			}
		
		U.log("floorCount ::"+floorCount);
		//============ Available Homes Data
		String homesData = ALLOW_BLANK;
		String[] homeSecs = U.getValues(html, "\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"");
		U.log("homeSecs: "+homeSecs.length);
		int quickCount=0;
		for(String homeSec:homeSecs) {
			
			String homeId = U.getSectionValue(homeSec, "\"containedIn\":\"", "\"");
			String headline = U.getSectionValue(homeSec, "\"headline\":", ",");
			
//			U.log("homeId: "+homeId +": "+comUniqueId);
			//MATCH
			if(comUniqueId.equals(homeId)) {
				homesData += homeSec; 
				U.log("homeSecs: "+homeSec);
				//Removing homes with sold status. Check next time.
				if(!headline.contains("\"SOLD!\"")) {// && !(homeSec.contains("\"excluded\":false"))
					U.log("Quick homeSecs: "+homeSec);
					quickCount++;
				}
			}
		}
		U.log("quickCount ::"+quickCount);
		//============ Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		String[] price = U.getPrices(comSec+homesData, "priceHigh\":\\d{6}|priceLow\":\\d{6}|\"price\":\\d{6}", 0);
				
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
		
		//============ Square Feet
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		comSec = comSec.replace("ranging from 1979 to 3341+ living sq ft", "ranging from 1979 to 3341 living sq ft");
		
		String[] sqft = U.getSqareFeet(comSec+homesData+planData, 
				"ranging from \\d{4} to \\d{4} living sq ft.|\"sqft\":\\d{4}|from \\d,\\d{3}-\\d,\\d{3}\\+?( living)? square feet|\"sqftHigh\":\\d{4}"
				+ "", 0);//\"sqftLow\":\\d{4}
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);	

		//============ cType
		comSec = comSec.replaceAll("\"name\":\"Birkdale Golf Club\"|>Birkdale Golf Club|\"name\":\"Brandermill Country Club\"|>Brandermill Country Club|"
				+ "\"name\":\"Independence Golf Club\"|>Independence Golf Club|>Brandermill Country Club", "");
		
		String cType = U.getCommType(comSec);
		U.log("cType: "+cType);
		//============ pType
		planData = planData.replaceAll("style\":\"Single Family", "").replaceAll("plan_type\":\"Single Family Homes", "");
		
		String pType = U.getPropType(planData+homesData+comSec);
		U.log("pType: "+pType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{100}craftman[\\s\\w\\W]{100}", 0));

		//============ dType
		String dType = U.getdCommType(planData+homesData+comSec);
		U.log("dType: "+dType);

		//============ Status
		String headline = U.getSectionValue(comSec, "\"headline\":\"", "\",");
//		headline = headline.replaceAll("Final Opportunity in Riverfront|Final Opportunity in Premiere Riverfront Commun", "");
		U.log("headline: "+headline);
		
		comSec = comSec.replaceAll(">Quick Move In Homes&nbsp|Final Opportunity in Premiere Riverfront Commun|Final Opportunity in Riverfront Community|"
				+ "New Large Homesites COMING SOON to New Kent|\"name\":\"Coming Soon - Community Parks|\"sub_header\":\"Now Selling|"
				+ "Cosby Village Clubhouse - Coming Soon|Village Clubhouse & Pool - Coming Soon|Design Studio Now Open|First Townhomes, Coming Soon|"
				+ "pavilion.  Coming Soon|Pavilion Coming Soon", "")
				.replace("pavilion. Coming Soon", "").replace("Sport Court Coming Soon", "")
				.replace("New Large Homesites NOW SELLING In New Kent", "New Homesites Now Selling In New Kent");
		
		String Status = U.getPropStatus((comSec+headline)
				.replace("status\":\"Coming Soon", "")
				.replace("\"sub_header\":\"New Homesites Now Available!\"", "")
				.replace("Quick Move-In Home Available in Section 5!", "")
				.replace("\"sub_header\":\"Quick Move-In Home Available!\",\"telephone\":\"", "")
				.replaceAll("Visit Our Grove Model Home! Now Open|pavilion. Coming Soon|Sport Court Coming Soon|Move In Ready Homes", ""));
		U.log("comSec :: "+comSec);
		
		U.log("headlline "+headline);
//		if(quickCount > 0) {
//			if(Status == ALLOW_BLANK) Status = "Quick Move-In Homes";
//			else if(Status != ALLOW_BLANK) Status += ", Quick Move-In Homes";
//		}
		U.log("Status: "+Status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+headline, "[\\s\\w\\W]{60}section open[\\s\\w\\W]{60}", 0));
		
		
		//============ Note
		planData = planData.replace("/presales/", "");
		
		String note = U.getnote(comSec+planData+homesData);	
		U.log("note: "+note);
		String updatedName = "";
		if(comUrl.contains("communities/chesterfield/harpers-mill-glen-royal#detail")) {
			updatedName ="Harpers Mill";
		}else {
			updatedName = comName;
		}
		U.log("updatedName: "+updatedName);
			

		//-------------- LOT COUNT DATA.
		
		//---GET THE LINK FORM ANY COMMUNITY PAGE. 
		//---CHECK FOR THIS "operationName":"GetSiteplanLiteByCommunityId" IN PAYLOAD. FOR THE REQUEST.
		
		String lotMapData = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetCommunityByNameLite\",\"variables\":{\"clientName\":\"msh\",\"communityName\":\""+updatedName+"\"},\"query\":\"query GetCommunityByNameLite($clientName: String!, $communityName: String!) {\\n  communityByName(clientName: $clientName, communityName: $communityName) {\\n    ...CommunityFields\\n    siteplans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      lotMetric\\n      src\\n      geoInfo(clientName: $clientName) {\\n        id\\n        __typename\\n      }\\n      lotLegend(clientName: $clientName) {\\n        id\\n        code\\n        name\\n        hex\\n        __typename\\n      }\\n      __typename\\n    }\\n    stdFeatureCategories(clientName: $clientName) {\\n      id\\n      name\\n      features(clientName: $clientName, communityName: $communityName) {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment CommunityFields on Community {\\n  id\\n  name\\n  thumb\\n  bonafide\\n  buildYourLot\\n  caption\\n  colormtd\\n  description\\n  pricing\\n  logo\\n  longitude\\n  latitude\\n  address\\n  sortType\\n  sortOrder\\n  primarySiteplan(clientName: $clientName, active: true) {\\n    id\\n    lotMetric\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    __typename\\n  }\\n  cityLocation(clientName: $clientName) {\\n    id\\n    name\\n    customName\\n    stateCode\\n    zip\\n    postCode\\n    __typename\\n  }\\n  agents(clientName: $clientName) {\\n    id\\n    email\\n    phone\\n    firstName\\n    lastName\\n    picture\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
		U.log("lotMapData: "+lotMapData);
		
//---BELOW METHOD IS FOR DELETING CACHE FILES AUTOMATICALLY HAVING ERROR MESSAGE.
		
//		if(lotMapData.contains("errors\":[{\"message\":\"Not Authorized")) {
//			
//			String requestUrl = "https://nexus.anewgo.com/api/graphql_gateway";
//			String payload = "{\"operationName\":\"GetCommunityByNameLite\",\"variables\":{\"clientName\":\"msh\",\"communityName\":\""+updatedName+"\"},\"query\":\"query GetCommunityByNameLite($clientName: String!, $communityName: String!) {\\n  communityByName(clientName: $clientName, communityName: $communityName) {\\n    ...CommunityFields\\n    siteplans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      lotMetric\\n      src\\n      geoInfo(clientName: $clientName) {\\n        id\\n        __typename\\n      }\\n      lotLegend(clientName: $clientName) {\\n        id\\n        code\\n        name\\n        hex\\n        __typename\\n      }\\n      __typename\\n    }\\n    stdFeatureCategories(clientName: $clientName) {\\n      id\\n      name\\n      features(clientName: $clientName, communityName: $communityName) {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment CommunityFields on Community {\\n  id\\n  name\\n  thumb\\n  bonafide\\n  buildYourLot\\n  caption\\n  colormtd\\n  description\\n  pricing\\n  logo\\n  longitude\\n  latitude\\n  address\\n  sortType\\n  sortOrder\\n  primarySiteplan(clientName: $clientName, active: true) {\\n    id\\n    lotMetric\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    __typename\\n  }\\n  cityLocation(clientName: $clientName) {\\n    id\\n    name\\n    customName\\n    stateCode\\n    zip\\n    postCode\\n    __typename\\n  }\\n  agents(clientName: $clientName) {\\n    id\\n    email\\n    phone\\n    firstName\\n    lastName\\n    picture\\n    __typename\\n  }\\n  __typename\\n}\\n\"}";
//			
//			String fileNameMaking = U.getCache(requestUrl+payload);
//			U.log("fileNameMaking: "+fileNameMaking);
//			U.deleteCacheFile(requestUrl+payload);
//		}
		
		JsonParser parser = new JsonParser();
		String lotIds="";
		if(!lotMapData.contains("INTERNAL_SERVER_ERROR") && !lotMapData.contains("\"siteplan\":null")){
			JsonObject jobj = (JsonObject)parser.parse(lotMapData);
			String comm_id=U.getSectionValue(jobj.toString(), "\"id\":", ",\"");
			
			U.log("jobj=="+comm_id);
			if(comm_id!=null) {
			String MapData = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetSiteplanLiteByCommunityId\",\"variables\":{\"clientName\":\"msh\",\"communityId\":"+comm_id+"},\"query\":\"query GetSiteplanLiteByCommunityId($clientName: String!, $communityId: Int!) {\\n  activeSiteplanByCommunityId(clientName: $clientName, communityId: $communityId, master: false) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    ...HotspotsFields\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      garagePosition\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    subSiteplans(clientName: $clientName, active: true) {\\n      id\\n      name\\n      info(clientName: $clientName) {\\n        siteplanId\\n        thumb\\n        fontSize\\n        x\\n        y\\n        whiteLabel\\n        showsThumb\\n        __typename\\n      }\\n      lots(clientName: $clientName) {\\n        id\\n        communityId\\n        salesStatus\\n        inventory(clientName: $clientName) {\\n          id\\n          communityId\\n          lotId\\n          planId\\n          elevationId\\n          __typename\\n        }\\n        excludedPlanElevations(clientName: $clientName) {\\n          planId\\n          elevationId\\n          planName\\n          planDisplayName\\n          elevationCaption\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment HotspotsFields on Siteplan {\\n  hotspots {\\n    id\\n    siteplanId\\n    name\\n    x\\n    y\\n    description\\n    thumb\\n    assets {\\n      id\\n      listIndex\\n      src\\n      description\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
//			U.log("MapData=="+MapData);
			
			JsonObject jobj1 = (JsonObject)parser.parse(MapData);
			lotIds = jobj1.get("data").getAsJsonObject().get("activeSiteplanByCommunityId").getAsJsonObject().get("lots").getAsJsonArray().size()+"";
			
			U.log("LOT COUNT: "+lotIds);
			
			}
//			lotIds = jobj.get("data").getAsJsonObject().get("siteplan").getAsJsonObject().get("lots").getAsJsonArray().size()+"";
//			U.log(lotIds);
		}
		if(lotIds.equals("0") || lotIds.length()<1)lotIds=ALLOW_BLANK;
		
		
		
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(street, city, state, zip);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyStatus(Status);
		data.addPropertyType(pType, dType);
		data.addNotes(note);
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);	
		i++;
	}
	}
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY2NTk5NjczMSwiZXhwIjoxNjY2MDM5OTMxfQ.SMLLgEkAT8RfwvplI7XUDoop7_Jxqv6LpV56qyHEqg0");
	        //connection.setRequestProperty("Authority", "nexus.anewgo.com");
	        connection.setRequestProperty("Content-Type", "application/json");
	        connection.setRequestProperty("Origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("Referer", "https://myhome.anewgo.com/");
//	        connection.setRequestProperty("Sec-Fetch-Dest", "empty");
//	        connection.setRequestProperty("Sec-Fetch-Mode", "cors");
//	        connection.setRequestProperty("Sec-Fetch-Site", "same-site");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");

	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
}
