/** @author
 *  @date 2/07/2012 
 */

package com.shatam.b_181_200;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPayneFamilyHome extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	private final static String builderUrl = "https://www.paynefamilyhomes.com"; 
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractPayneFamilyHome();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Payne Family Homes.csv", a.data()
				.printAll());

	}

	public ExtractPayneFamilyHome() throws Exception {

		super("Payne Family Homes", "https://www.paynefamilyhomes.com/");
		LOGGER = new CommunityLogger("Payne Family Homes");
	}

	public void innerProcess() throws Exception {

		String html = U
				.getPageSource("https://www.paynefamilyhomes.com/neighborhoods");
		String temp=U.getSectionValue(html, "<section class=\"slam_section bg-beige \">", "</section>");
		//U.log(temp);
		String values[] = U.getValues(temp, "<li id=\"neighborhood", "</a>");
		//U.log(Arrays.toString(values)+"$$$$$$$$$$$$$");
	//	//U.log(values.length);
		int totalComm = values.length / 2;
		for (int i = 0; i < values.length; i++) {
			//U.log(values[i]);
			String url = U.getSectionValue(values[i], "href=\"", "\"");

			addDetails(url, values[i]);
			k++;
			inr++;
		}
	}

	private void addDetails(String url, String info) throws Exception {
		//if(j==14)
		{
			//if(!url.contains("https://www.paynefamilyhomes.com/neighborhood/pinewoods-estates/"))return;
		
			//if(url.contains("http://www.paynefamilyhomes.com/comm_overview.php?com=52"))return;
			U.log(j+"\nPAGE :" + url);
			String html = U.getPageSource(url);
			//U.log("info is:" + info);
			// commName
			String commName = U.getSectionValue(info, "<h4 class=\"home-list-title\">", "</h4>");
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/the-villages-of-provence/"))commName ="The Villages of Provence";
			String note = ALLOW_BLANK;// U.getCommNotes(html);

			U.log(commName);
		
			if(commName.contains(",")){
				String name1 = commName.substring(commName.indexOf(",")+1);
				String name2 = commName.substring(0, commName.indexOf(","));
				commName = name1+" "+name2;
			}
			// address
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			
			// U.log("visiting ::" + "http://www.paynefamilyhomes.com" + dHtml);
		
			String ad = U.getSectionValue(html, "Directions", "</p>");

			// U.log(ad);
			if (url.contains("comm_overview.php?com=56"))
				ad = "7 Reservoir Ct" + ",Eureka, MO, 63025";
			if (ad != null) {
				//U.log(ad);
				ad=ad.replace("Traveling E or W on Hwy 364, take exit 2 to Bryan Road. You'll see Cordoba at the roundabout", "");
				ad=ad.replaceAll("Sold From Konert Lake Estates( in Fenton)?|Display:|Sold from Shady Creek|Sold from Montrachet|Sold from Bella Vista|Selling from our Newest Community, Riverdale!|Sold from","");
				
				ad = U.formatAddress(ad);
				
				ad = ad.replace("Ct,.", "Ct").replace(",,",",").replace("Street, Crossing", "Street Crossing").replace("Rd. Arnold", "Rd, Arnold")
						.replaceAll("Sold fromHuntleigh Ridge", "");
				ad=ad.replace("O'Fallon,",",O'Fallon,");
				ad=ad.replaceAll(",\n" + 
						",",",");
				//U.log("AddSec::"+ad);
				if(ad.split(",").length > 3)
					add = ad.split(",");
				if(ad.split(",").length==3) {
					add=U.findAddress(ad);
				
				}
			}
			if(add[0]==ALLOW_BLANK) {
				ad=U.getSectionValue(html, "Directions", "</b>");
				ad=ad.replace("Cottleville", "Cottleville,").replaceAll("MO,", "MO ").replaceAll(" Sold from |Shady Creek|at|Main Street Crossing", "");
				//U.log("adresssection::::::::::::"+ad);
				add=U.findAddress(ad);
			}
			if(add==null) {
				add=new String[]{ ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			}
			if(url.contains("/pinewoods-estates/")) {
				ad=U.getSectionValue(html, "Directions", "Hours");
				ad=ad.replace("Cottleville", "Cottleville,").replace("Wentzville", "Wentzville,").replaceAll("MO,", "MO ").replaceAll(" Sold from |Shady Creek|at|Main Street Crossing|Display: ", "");
				//U.log("adresssection::::::::::::"+ad);
				add=U.findAddress(ad);
			}
			U.log("Add:"+Arrays.toString(add));

			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				String addSec = U.getSectionValue(html, "address\":\"", "\",");
				if(addSec != null){
					addSec = addSec.replace("<br>", ",");
					add = U.getAddress(addSec);
					//U.log("Add:"+Arrays.toString(add));

				}
			}
			// lat
			
			String lat = U.getSectionValue(info, "data-lat=\"", "\"");
			String lng = U.getSectionValue(info, "data-lng=\"", "\"");
			String geo = "False";
			U.log(lat + "," + lng);
			if(add[1].length()<4 && lat != ALLOW_BLANK){
				String lats[]= {lat,lng};
				add=U.getAddressGoogleApi(lats);
				geo="TRUE";
			}
			
			// price
			// price
			String homeSec = U.getSectionValue(html, "<h3 class=\"section-title text-center\">",	"</section>");
			String homeHtml="";
			String check="";
			if(homeSec!=null)
			check=Util.match(homeSec, "\\s*\\n*\\s*<a href=.*\\s*\\n*\\S*\" title");
			//U.log("lllllllll"+check);
			if(check!=null)
			{
			String url1=U.getSectionValue(check, "<a href=\"","\"");
			//U.log("lllllllll"+url1);
			if(url1!=null)
			homeHtml=homeHtml+U.getHTML(url1);
			}
		
			String florUrl = U.getSectionValue(html, "<li class=\"plans\"><",	">");
			
			florUrl = U.getSectionValue(html, "a href=\"", "\"");
			//U.log("florUrl : "+florUrl);
			String floorHtml = U.getSectionValue(html, "Quick Move Homes\n" + 
					"                </h3>", "<div id=\"viewHome\"");
			if(floorHtml != null){
				String[] floorUrls = U.getValues(floorHtml, "<a href=\"", "\"");
				for(String floorUrl : floorUrls){
					String fHtml = U.getHTML(floorUrl);
				}
					
			}
//			===============================Homes====================================
			String homeUrl[] = U.getValues(html, "https://www.paynefamilyhomes.com/homes/",	"\"");
			U.log(homeUrl.length);
			String quickHomeData=ALLOW_BLANK;
			if(html.contains("<ul class=\"home-grid home-grid--quick-move-homes")){
				for(String hurl : homeUrl){
						U.log(hurl);
					 quickHomeData += U.getSectionValue(U.getHTML("https://www.paynefamilyhomes.com/homes/"+hurl), "id=\"Description\">", "</div>");
				}
					
			}

			String[] priHtml=U.getValues(homeHtml, "<div class=\"mod_text\">","<div class=\"mod_btns\">");
			String currectPrice="";
			for(String sec:priHtml)
			{
				if(sec.contains("Reduced Price:"))
				{
					sec=sec.replace("&#36;", "$");
					sec=sec.replaceAll("<span>\\s+Price:\\s*</span>\\s*\\$\\d{3},\\d{3}\\s*</h5>","");
				}
				currectPrice=currectPrice+sec;
			}
			
			html=html.replaceAll("class='strikethrough'>\\s*\\$\\d{3},\\d{3}\\s*</dd>", "");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U
					.getPrices(
							(floorHtml +currectPrice+ html + info).replaceAll("class='strikethrough'>\\s*\\$\\d{3},\\d{3}\\s*</dd>", "").replace(
									"&#36;", "$"),
							"from the mid \\$\\d{3},\\d{3}|Price:\\n*\\s*</strong>\\n*\\s*\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Red. Price</dt><dd>\\$\\d{3},\\d{3}|Base Price\\n*</dt>\\n*\\s*<dd>\\n*\\s*\\$\\d{3},\\d{3}| the \\$\\d{3},\\d{3}|priced from the \\$\\d+,\\d+|\\$\\d+,\\d+ - \\$\\d+,\\d+|Price:\\s*</span>\\s*\\$\\d{3},\\d{3}\\s*</h5>|Price Range:\\s*</span>\\s*\\$\\d+,\\d+ to \\$\\d+,\\d+|Reduced Price:\\s*</span>\\s*\\$\\d{3},\\d{3}\\s*</h5>|<dd>\\s*\\$\\d{3},\\d{3}\\s*</",0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		//U.log(html);
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							floorHtml + html + homeHtml,
							"from \\d,\\d{3} – \\d,\\d{3} square feet|Square Footage:\\n*\\s*</strong>\\n*\\s* \\d,\\d{3} to \\d,\\d{3}|Square Footage:\\n*\\s*</strong>\\n*\\s*\\d,\\d{3} - \\d,\\d{3}|ranging from \\d,\\d{3} sq. ft. to over \\d,\\d{3} sq. ft.|\\d,\\d+ to over \\d,\\d+ square feet|\\d,\\d+ to \\d,\\d+ square feet|\\d,\\d+ to nearly \\d,\\d+ sq|\\d{1}\\,\\d{3} to \\d{1}\\,\\d{3} sq.ft. The Villages|\\d{1}\\,\\d{3} to \\d{1}\\,\\d{3} sq.ft. for more information|\\d,\\d+ to nearly \\d,\\d+ sq. ft|\\d,\\d+ to nearly \\d,\\d+ sq. ft|from \\d,\\d+ to just over \\d,\\d+ square feet|\\d,\\d+-\\d,\\d+|\\d+,\\d+ to nearly \\d+,\\d+ square feet|Square Feet:\\s*</span>\\s*\\d+,\\d+|\\d+ to nearly \\d+ sq. ft|from \\d+,\\d+ to nearly \\d+,\\d+ sq. ft|Sq. Ft.:\\s*</span>\\s*\\d+,\\d+|SQFT Range:\\s*</span>\\s*\\d+,\\d+ to \\d+,\\d+|from \\d+,\\d+ to upwards of \\d+,\\d+ square feet|data-sq_ft=\"\\d{4}|data-sqft=\"\\d{4}\"",
							0);
			
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			U.log("lat :" + lat + " longi :" + lng);
			String pType = U.getPropType((html.replaceAll("luxury options|consisting of luxury|Each luxurious", "many luxury features").replace("custom build", "custom-style homes") + floorHtml+quickHomeData).replaceAll("village|Village|hoa|quality and craftsmanship", ""));
			html=html.replace("frac12"," 1.5 Story ");
			
			//U.log(html);
			html=html.replaceAll("one-and-a-half or two-story|one and half and two-story"," 1.5 Story  2 Story ");
			homeHtml=homeHtml.replace("Stories:</span> 1"," 1 Story ");
			String dType = U.getdCommType(html + floorHtml+homeHtml+quickHomeData);
			
			String Type = U.getCommunityType(U.getNoHtml(html));

			String status = ALLOW_BLANK;
			html = U.getPageSource(url);
			
			String statSec = html + info;
			
			String remove = "our Homes Ready now |Decorated Display Home Now Open| during the Grand Opening|condos coming soon|Stunning Move[-| ]*In Ready Home[s]*|\"move in ready homes\"|Homes Ready Now|homes ready now|Car Garage Home Sites Now Available!|on the final opportunities|Ready Home Available for Immediate|Coming soon... new community pool|2 New Display Homes NOW OPEN|Display Now Open|Display now open|text-link-pop\"><span>Coming Soon!<|We will be hosting our Grand Opening in April|Vintage Grove-Coming Soon!|DISPLAY NOW OPEN|Now Selling!</a>|-Now Selling|Now Selling!\\s*</h|Heritage Crossing-SOLD OUT!|Belleau Creek-Now Selling!|we have move in ready|lots|CONSTRUCTION COMING|link-pop\">\\s+<span>\\s+Coming|Hours: </span>Coming";
			statSec = statSec.replaceAll(remove, "");
			statSec = statSec.replace("are available", "available").replace("choice home sites available", "").replace(
					"Phase III lots now open", "Phase III now open").replace("Coming 2018... new community pool!", "")
					.replace("final phase of this community is", "final phase").replaceAll("Phase I home sites are now available", "Phase I homesites now available");
			// U.log(Util.match(statSec, ".*?Move In Ready Home.*?"));
			status = U.getPropStatus(statSec + commName);
			U.log("status is" + status);
			status=status.replace("Iii","III");
			status=status.replace("Ii","II");
			
			if(add[0].contains("Selling from The Grove at Belleau Creek!") || add[0].contains("By Appointment Only"))
			{
				add[0]=ALLOW_BLANK;
			}
			String latlng[] = { lat, lng };
			if (add[0] == ALLOW_BLANK) {

				add = U.getAddressGoogleApi(latlng);
				geo="True";
			}
			
			if (add[0].length() < 3)
				add[0] = ALLOW_BLANK;
			
			if (html.contains("<ul class=\"home-grid home-grid--quick-move-homes")) {
				status=status.replace(", Move-in Ready", "");
				if (status == ALLOW_BLANK) {
					status = "Quick Move In";
				} else {
					status = status + ", Quick Move In";
				}
			} else {
				/*if (status == ALLOW_BLANK) {
					status = "Quick Move In";
				} else {
					status = status + ", Quick Move In";
				}*/
			}
			if(homeHtml.contains("There are no inventory found at this time"))
			{
				if(html.contains("Coming Soon!"))
				{
					status=status.replace(", No Quick Move In", "");
				}
				
			}

			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]
					+ " Z:" + add[3]);
			add[0]=add[0].toLowerCase().replaceAll("Sold by Consulting Team|Selling From Pevely Farms!".toLowerCase(), ALLOW_BLANK);
			add[3]=add[3].replace("Hours: Mon: 11:30-5; Tues-Sat: 10-5; Sun: 11-5", "");
			if (lat != ALLOW_BLANK && (add[0] == ALLOW_BLANK|| add[0].length()<4)) {
				add = U.getAddressGoogleApi(latlng);
				geo="True";
			}
			if(url.contains("https://www.paynefamilyhomes.com/neighborhood/bordeaux/"))status=status+", Grand Opening";
			if(url.contains("/shady-creek/")) {status=status.replaceAll("Now Available", "Phase II Now Available");}
			LOGGER.AddCommunityUrl(url);
			add[0]=add[0].replace(".","");
			statSec = statSec.replace("amp;", "");
					
			String notes = U.getnote(statSec);
			
			if(status.contains("New Home Sites Just Released, Just Released"))status=status.replace("New Home Sites Just Released, Just Released", "New Home Sites Just Released");
			data.addCommunity(commName.trim(), url, Type);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status.replace("-,", ""));
			data.addNotes(notes);
			// TODO Auto-generated method stub
		}
	j++;
	}
}