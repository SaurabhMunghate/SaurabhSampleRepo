/** @author Parag Humane
 *  @date 23/04/2013 
 *  @version 1.5
 */

package com.shatam.b_181_200;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.bouncycastle.jcajce.provider.asymmetric.dsa.DSASigner.stdDSA;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSumeerHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	public static String homename="http://www.sumeerhome.com";
	CommunityLogger LOGGER ;
	static String geo=null;
	
	public static void main(String[] ar) throws Exception {
		// www.sumeerhome.com
		AbstractScrapper a = new ExtractSumeerHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Sumeer Homes.csv", a.data().printAll());

	}

	public ExtractSumeerHomes() throws Exception {

		super("Sumeer Homes", "http://www.sumeerhome.com");
		LOGGER = new CommunityLogger("Sumeer Homes");
	}

	public void innerProcess() throws Exception {

//		=================================================================================================================================================================================
		String html = U.getHTML("http://www.sumeerhome.com/properties/");
		
		String[] sec=U.getValues(html,"align=\"absmiddle\"></td>", "</tr>");
		
			
//		http://www.sumeerhome.com/properties/type.asp?iType=97
		U.log("length==================================================> "+sec.length);
			int i=0;
		for (String propUrl: sec) {
			U.log(propUrl);
			String count=U.getSectionValue(propUrl, "\">", "</td>");
			String url=U.getSectionValue(propUrl,"href=\"", "\"");
			
			if(!count.contains("(0)")){
			
			
			String PropName=U.getSectionValue(propUrl, url+"\">", "</a>");
			//PropName=U.removeHtml(PropName);
			U.log(url);
			U.log(PropName);
			 url="http://www.sumeerhome.com/properties/"+url;
			addDetails(url,PropName);
			}
			else{
				LOGGER.AddCommunityUrl(url+"===================> Community with no data Return");
				i++;
				
			}
		}
		U.log(i);
		LOGGER.DisposeLogger();
	}


	private void addDetails(String url, String name )	throws Exception
	{
		
		U.log("url=========================================================================> "+url);
//		if(!url.contains("http://www.sumeerhome.com/properties/type.asp?iType=77"))return;
//		
		/*if(url.contains("http://www.sumeerhome.com/properties/type.asp?iType=69")||url.contains("http://www.sumeerhome.com/properties/type.asp?iType=73")||url.contains("http://www.sumeerhome.com/properties/type.asp?iType=89")){
			
			LOGGER.AddCommunityUrl(url+"===================> Community Return");
			return;//er BOF or EOF is True, or the current record has been deleted.	31/08/2018
		}*/
		String html = U.getHTML(url);
		
		///----remove meta description
		html = U.removeSectionValue(html, "<meta name=\"description\"", "/>");
		
		
//		============================================================================================
		
		
		String lat=ALLOW_BLANK,lng=ALLOW_BLANK;
		
	
//		===================================================================================Address==================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		
//		String addrSection = U.getSectionValue(html, "class=\"home_text01b\">","TX<br>");
//		String geo = "TRUE";
//		
		
		add[0]=U.getSectionValue(html,"<font size=\"3\">", "</font>");
		add[1]=U.getSectionValue(html,"<strong>City: </strong>","</td>");
		add[2]="TX";
		add[3]=ALLOW_BLANK;
		
		
		String la[] = U.getlatlongGoogleApi(add);
		lat = la[0];
		lng = la[1];
		geo = "true";
		
		if(add[3]==ALLOW_BLANK)
		{
			String[] latlng={lat,lng};
			String[] aa=U.getAddressGoogleApi(latlng);
			add[3]=aa[3];
		}
		U.log(Arrays.toString(add));
		
		U.log("street:" + add[0].trim() + " City:" + add[1].trim() + " ST:"
				+ add[2] + " Z:" + add[3]);

		
		
//		if(lat!=ALLOW_BLANK)
//		add = U.getAddressGoogleApi(new String[] { lat, lng });
//
//====================================================================================================================price	
		String[] price= {ALLOW_BLANK,ALLOW_BLANK};
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			// As min and max price is common for All town comm
		 price= U.getPrices(html, "\\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//	===================================================================================================================sqft
	String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
//		String[] sqft = U.getSqareFeet(html," \\| \\d{4} sqft \\| |\\d{4} sqft", 0);
		
		String[] sqft = U.getSqareFeet(html,"SQ FT:</strong> \\d{4}</td>|SQ FT:</strong> \\d+</td>", 0);
	
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("Min Sq=================================> :" + minSqf + " Max Sq =========================================>:" + maxSqf);	
		

//		// Community Type
		String commType = U.getCommunityType(html);
		U.log("commType :" + commType);
//
		// Property Type
		String propType=U.getPropType(html.replaceAll("<meta name=(.*?)>", ""));
//		String rm=U.getSectionValue(html, "<meta name=\"description\"", "<link");
//		if(rm!=null)html=html.replace(rm, "");
//		html=html.replace("<td width=\"12%\" align=\"center\" class=\"Border\"><a href=\"../townhomes.html\">Town Homes</a></td>", "");
//		String propType = U.getPropType(html.replaceAll("VILLAGE|townhomes\\.html\">Town Homes",""));
//
//		// Stories:</b> 1</td>
//
//	//	U.log("Prop Type :" + propType);
//		
		
		
		String note = ALLOW_BLANK;
		String status = ALLOW_BLANK;
//		String statSec = html;
//		String remove = "style=\"font-weight:bold;\">Coming Soon</span>";
//		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		status = U.getPropStatus(html.replace(" alt=\"Coming Soon\" ", ""));
		U.log("Status======================>"+status);
//        html=html.replace("Stories:</b>", "story");
		
		// Derived propType
		html=html.replaceAll("<b>Stories:</b>", "story");
//		U.log(Util.matchAll(html, "[\\w*\\s*\\W*]{10}story\\s*\\d",0));
		String dProType = U.getdCommType(html);
		U.log("derivedPropType===================>"+dProType);
		
		//status
		note=U.getnote(html);
		U.log("note=============================>"+note);
		
		
		
		//		//dProType = "1 Story, 2 Story";
//		/*if(minSqf==ALLOW_BLANK)
//			dProType=ALLOW_BLANK;*/
//		commName = coName;
//		
//		if(url.contains("48")){
//			
//			dProType=ALLOW_BLANK;
//			
//		}
//		if(url.contains("http://www.sumeerhome.com/properties/type.asp?iType=68")||url.contains("http://www.sumeerhome.com/properties/type.asp?iType=78"))
//		{
//			add[0]="2404 Texas Drive";
//			add[01]="Irving";
//			add[2]="TX";
//			add[3]="75062";
//			String[] lats=U.getlatlongGoogleApi(add);
//			lat=lats[0];
//			lng=lats[1];
//			geo="true";
//			note ="Address Taken From Contact Us Page";
//			
//			
//		}
//		   if(url.contains("http://www.sumeerhome.com/properties/type.asp?iType=55")||
//              url.contains("http://www.sumeerhome.com/properties/type.asp?iType=30")||
//                url.contains("http://www.sumeerhome.com/properties/type.asp?iType=60")||
//                url.contains("http://www.sumeerhome.com/properties/type.asp?iType=57"))
//		{
//			//propType="Townhomes";
//		}
//		if(url.contains("http://www.sumeerhome.com/properties/type.asp?iType=79"))
//		{
//			lat="32.590161";
//			lng="-96.888073";
//			geo="TRUE";
//            add=U.getAddressGoogleApi(new String[]{lat,lng});
//			add[0]="1228 Ashford Dr";
//			
//		}
//		if(data.communityUrlExists(url)){
//			LOGGER.AddCommunityUrl(url+":::::::::::::Repeated:::::::::::;");
//			return;
//		}
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(name, url, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(propType, dProType);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);

	}
}