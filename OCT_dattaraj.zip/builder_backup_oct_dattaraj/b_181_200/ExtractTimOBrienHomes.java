/**
 * Author Name--Gourav Gujar
 * 
 */
package com.shatam.b_181_200;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.eclipse.jetty.util.UrlEncoded;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

import java_cup.runtime.lr_parser;

public class ExtractTimOBrienHomes extends AbstractScrapper {
	static String BASEURL = "https://www.timobrienhomes.com";
	WebDriver driver = null;
	static int j = 0;
	CommunityLogger LOGGER;

	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractTimOBrienHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Tim O'Brien Homes.csv", a
				.data().printAll());
	}
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	public ExtractTimOBrienHomes() throws Exception {

		super("Tim O'Brien Homes", BASEURL);
		LOGGER = new CommunityLogger("Tim O'Brien Homes");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
//
////		String html = getHtml("https://www.timobrienhomes.com/neighborhoods",driver);
////		html = StringEscapeUtils.unescapeJava(html);
////		html = U.removeSectionValue(html, ">window.__PRELOADED_STATE__", "</html>");
////		String comSec[]= U.getValues(html, "<a class=\"CommunityCard_imageWrapper\"", ">Visit Community</a>");
////		int i=0;
////		for(String sec:comSec) {
//////			U.log(i+++"::::::::::::::"+sec);
////			String comUrl = U.getSectionValue(sec, "href=\"", "\"");
////			addDetails(comUrl,sec);
////		}
//		String html = U.getHtml("https://www.timobrienhomes.com/neighborhoods/madison-area",driver)+U.getHtml("https://www.timobrienhomes.com/neighborhoods/milwaukee-area",driver);
//		String comSec[]= U.getValues(html, "<a class=\"CommunityCard_imageWrapper\"", ">Visit Community</a>");
//		U.log(comSec.length);
//		int i=0;
//		for(String sec:comSec) {
////			U.log(i+++"::::::::::::::"+sec);
//			String comUrl = U.getSectionValue(sec, "href=\"", "\"");
//			U.log("url "+comUrl);
//			addDetails(comUrl,sec);
//		}
//		driver.quit();
		
		//==================== JSON Code==================================
		String basehtml = U.getHtml("https://www.timobrienhomes.com/neighborhoods",driver);
//		int c=0;
		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(basehtml, "__PRELOADED_STATE__ = ", "</script>");
		if (removeScript == null)
			removeScript = "";
		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
		
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities");
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans").getAsJsonObject().get("5702c353f410954eb27d04ef");
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes");
//		String commSec[] = U.getValues(commJson.toString(), "\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");
		JsonObject lotJson = (JsonObject) jobj.getAsJsonObject().get("lots").getAsJsonObject().get("5702c353f410954eb27d04ef");

		String[] comData = U.getValues(U.removeSectionValue(commJson.toString(), "\"unpublished\":[", "receivedAt\":"), "{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");
		U.log("comData===="+comData.length);
		String plans[] = U.getValues(planJson.toString(), "\"@type\":\"ProductModel", "\"type\":\"plan\"");
		U.log("plans===="+plans.length);
		String homes[] = U.getValues(homeJson.toString(), "\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"}");
		U.log("homes===="+homes.length);
		
		
		basehtml+=U.getHtml("https://www.timobrienhomes.com/homesites",driver);
		String[] urlSec=U.getValues(basehtml, "<a class=\"CommunityCard_imageWrapper\" href=\"", "\"");
		U.log("urlSec=="+urlSec.length);
		
		String commUrl=ALLOW_BLANK;
		int h=0, p=0;
		
		for(String commSec : comData) {
			
			String commID=U.getSectionValue(commSec, "\"_id\":\"", "\"");
//			U.log("commID==="+commID);
			String sharedname=U.getSectionValue(commSec, "\"sharedName\":\"", "\"");
			String homeData=ALLOW_BLANK;
			String planData=ALLOW_BLANK;
			for (String url : urlSec) {
				if(url.contains(sharedname)) {
					commUrl="https://www.timobrienhomes.com"+url;
				}
			}
			for (String home : homes) {
				if(home.contains(commID)) {
					homeData+="\n\n"+home;
					
				}
			}
			for (String plan : plans) {
//				if(plan.contains(commID)) {
					String communitySec=U.getSectionValue(plan, "\"communities\":", "],");
					if(communitySec!=null)
					{
						String []communities=U.getValues(communitySec, "{\"community\"", "}");
						if(communities.length>0) {
							for(String comm : communities) {
								if(comm.contains(commID)) {
									if(!comm.contains("communityModelProperties\":{\"price\":null"))
									{
										planData+="\n\n"+plan;
									}
								}
							}
						}
					}
					
//					p++;
//				}
			}
			
			addDetails(commID,commUrl,commSec, homeData, planData, lotJson.toString());
		}
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}

private void addDetails(String commID,String commUrl , String commSec, String homeData, String planData, String lotData) throws Exception {
		// TODO Auto-generated method stub
		
	
//	 ........................communityurl...................................
//	 if(!commUrl.contains("https://www.timobrienhomes.com/neighborhoods/madison-area/windsor/bear-tree-farms")) return;
	 		
	U.log("\n::::::::::::: COUNT==="+j+" :::::::::::::");
	U.log("commID==="+commID);
	//U.log("commSec==="+commSec);
	

	 			U.log("commUrl==="+commUrl);
	 			U.log("commSec==="+commSec);

	 			if(data.communityUrlExists(commUrl)){
	 				LOGGER.AddCommunityUrl(commUrl+"------>repeated");
	 	 				return;
	 			}
	 			LOGGER.AddCommunityUrl(commUrl);
	
	 			String[]add= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
	 			String[] latLan={ALLOW_BLANK,ALLOW_BLANK};
	 			String geo="False";
	 			
	 			String headline = ALLOW_BLANK;
	 			if(commUrl.contains("homesites/milwaukee-area/germantown/harvest-hills")) {
	 				
	 				headline = U.getSectionValue(commSec, "headline\":\"", "highSchool").replace("at the low $500s", "at the low $500,000");
		 			U.log("headline: "+headline);
	 			}
	 		
	 			
	 			String commName=ALLOW_BLANK;
//	 			String commNameSec = U.getSectionValue(commSec, "{\"description\":\"", "}");
//	 			if(commNameSec!=null) {
//	 				commName=U.getSectionValue(commNameSec, "\"title\":\"", "|")	;
//	 			}
//	 			U.log("commName==="+commName);
//	 			if(commName==ALLOW_BLANK) {
	 				commName=U.getSectionValue(commSec, "com\",\"name\":\"", "\",")	;
//	 			}
//	 				if(commName!=null) {
//	 					commName=commName.replace("-", " ");
//	 				}
//	 				commName=WordUtils.capitalize(commName);
	 			U.log("commName==="+commName);
	 			String addSec=U.getSectionValue(commSec, "\"outOfCommunity\":{\"address\"", ",\"photos\"");
	 			if(addSec!=null && addSec.contains("\"checked\":true")) {
//	 				add[0]=U.getSectionValue(addSec, "streetAddress\":\"", "\"");
//	 				add[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
//	 				add[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
//	 				add[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\"");
	 				
	 			}
	 			else
	 			{
	 				add[0]=U.getSectionValue(commSec, "streetAddress\":\"", "\"");
	 				add[1]=U.getSectionValue(commSec, "\"addressLocality\":\"", "\"").replace("DeForest", "Deforest");
	 				add[2]=U.getSectionValue(commSec, "\"addressRegion\":\"", "\"");
	 				add[3]=U.getSectionValue(commSec, "\"postalCode\":\"", "\"");
	 			}
	 			U.log("ADDRESS==="+Arrays.toString(add));
	 			
	 			if(commUrl.contains("/milwaukee-area/lisbon/twin-pine-farm")) {
	 				add[0]=add[0].replace("Twin Pine Farm", "W279N8383 Hunter Court");
	 			}
	 			
	 			String latlngSec=U.getSectionValue(commSec, "\"geoIndexed\":[", "]");
	 			if(latlngSec!=null) {
	 				latLan[0]=Util.match(latlngSec, ",\\d+.\\d{1}\\d+").replace(",", "");
	 				latLan[1]=Util.match(latlngSec, "-\\d+.\\d{1}\\d+");
	 			}
	 			U.log("latLan==="+Arrays.toString(latLan));
	 			
	 			if(commUrl.contains("neighborhoods/milwaukee-area/germantown/wrenwood-north")) {
	 				
	 				add[0]= ALLOW_BLANK; add[1]= ALLOW_BLANK; add[2]= ALLOW_BLANK; add[3]= ALLOW_BLANK;
	 				//Due to incorrect address given on comPage.
	 			}
	 			
	 			
	 			if(add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && latLan[0]!=ALLOW_BLANK)
	 			{
	 				add=U.getAddressGoogleApi(latLan);
	 				geo="True";
	 			}
	 			
				commSec=U.removeSectionValue(commSec, "\"com_description\":\"", "\",");
						commSec=U.removeSectionValue(commSec, "\"headline\":\"", "\",");

	 			
	 			String price[]= {ALLOW_BLANK,ALLOW_BLANK};
	 			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
	 			
	 			
	 			commSec=commSec.replaceAll("0's|0s", "0,000");
	 			price = U.getPrices((commSec+homeData+planData+headline).replaceAll("Priced Was <!-- /react-text --><!-- react-text: \\d+ -->\\$\\d{3},\\d{3}<!-- /react-text -->|<span class=\"PriceSection_priceWas\" data-reactid=\"\\d+\">\\$\\d{3},\\d{3}</span>", ""),
				"at the low \\$\\d{3},\\d{3}|\"price\":\\d{6},|\\$\\d{3},\\d{3}|starting in the upper \\$\\d{3},\\d{3}|starting_at\":\"in the upper \\$\\d{3},\\d{3}", 0);//
	 			U.log("price==="+Arrays.toString(price));
//	 			U.log("homeData==="+homeData);
//	 			U.log("planData==="+planData);
	 			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
	 			
//				U.log("MMMMMMMMM "+Util.matchAll((commSec+homeData+planData), "[\\s\\w\\W]{50}\\$500[\\s\\w\\W]{50}", 0));
//				FileUtil.writeAllText("/home/shatam-10/Desktop/data/HOMES.txt", homeData);
	 			
	 			
	 			planData=planData.replaceAll("\"sqft\":", "\"Plan_sqft\":");
	 		
	 			commSec=commSec.replace("+\",", "\"");
	 			sqft= U.getSqareFeet(
								(commSec+homeData+planData),
								"\"sq_ft_range\":\"\\d,\\d{3}+\"|\"Plan_sqft\":\\d{4},|\"sq_ft_range\":\"\\d,\\d{3}-\\d,\\d{3}\"",0);
	 			
	 			U.log("sqft==="+Arrays.toString(sqft));
	 			
	 			String minsqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				String maxsqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	 			
//			U.log("MMMMMMMMM "+Util.matchAll((commSec), "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{100}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll((homeData), "[\\s\\w\\W]{100}\\$400[\\s\\w\\W]{30}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll((planData), "[\\s\\w\\W]{100}\\$400[\\s\\w\\W]{100}", 0));

	 			String commType=ALLOW_BLANK;
	 			String proptype=ALLOW_BLANK;
	 			String dtype=ALLOW_BLANK;
	 			String prpoStatus=ALLOW_BLANK;
	 			String note=ALLOW_BLANK;
	 			
	 			proptype = U.getPropType((commSec+homeData+planData));
	
				U.log("proptype: "+proptype);
				
				dtype = U.getdCommType(commSec+homeData+planData);//
				U.log("dtype: "+dtype);
//				U.log("MMMMMMMMM "+Util.matchAll((commSec), "[\\s\\w\\W]{100}Ranch Home[\\s\\w\\W]{30}", 0));
//				U.log("MMMMMMMMM "+Util.matchAll((homeData), "[\\s\\w\\W]{100}Ranch Home[\\s\\w\\W]{30}", 0));
//				U.log("MMMMMMMMM "+Util.matchAll((planData), "[\\s\\w\\W]{100}Ranch Home[\\s\\w\\W]{100}", 0));


				 commType=U.getCommType(commSec);
				U.log("commType: "+commType);
				
				prpoStatus=U.getPropStatus((commSec)
						.replaceAll("\"customHover\":\"Coming Soon\"", "")
						.replace("lots available in North Cape", ""));
				U.log("prpoStatus: "+prpoStatus);
				
				
				int q=0;
				if(homeData!=null) {
					String homes[]=U.getValues(homeData, "\"_created\":", "\"uniqueName\":");
					U.log("homes===="+homes.length);
					for(String home : homes) {
						if(home.contains("\"status\":\"Active\","))
						{
							q++;
						}
					}
				}
				
//				if(commUrl.contains("s/milwaukee-area/lisbon/the-preserve-at-harvest-ridge") || commUrl.contains("/milwaukee-area/grafton/river-bend-meadows"))
//					prpoStatus="Move-In Ready";
//				
//				if(commUrl.contains("/madison-area/windsor/bear-tree-farms"))
//					prpoStatus=prpoStatus+", Move-In Ready";				
				
				note=U.getnote(commSec);
				U.log("note: "+note);
				
				
				if(commUrl.contains("neighborhoods/milwaukee-area/lisbon/hillside-ridge"))
				{
					add[0]="N75W25219 Beverly Lane";
				}
				
//	 			FileUtil.writeAllText("/home/shatam-50/Documents/maranoJson1.txt", lotData);

				
				String lotCount=ALLOW_BLANK;
				int count=0;
				String tempname=commName.toLowerCase().replace(" ", "-");
				U.log("tempname==="+tempname);

				String[] lot_data=U.getValues(lotData, "_created\":", "\"type\":\"lot\"");
				U.log("lot_data==="+lot_data.length);
				if(lot_data.length>0) {
					for(String lot : lot_data) {
						String id=U.getSectionValue(lot, "\"containedIn\":\"", "\",");
						
						
						if(id.equals(commID) || lot.contains(tempname)) {
//							U.log("id==="+id);
							count++;
						}
					}
				}
				
				U.log("count==="+count);
				if(count==0) {
					lotCount=ALLOW_BLANK;
				}
				else
				{
					lotCount=Integer.toString(count);
				}
				
				data.addCommunity(commName.trim(),commUrl, commType);
				data.addAddress(add[0].replace("984 Griffin Way Under Construction-phone For Private Tour", "984 Griffin Way").replace(",", ""), add[1], add[2].trim(), add[3]);
				data.addLatitudeLongitude(latLan[0], latLan[1], geo);
				data.addPropertyType(proptype, dtype);
				data.addPropertyStatus(prpoStatus.replace("IIi", "III"));
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minsqft, maxsqft);
				data.addNotes(note);
				data.addUnitCount(lotCount);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				j++;
				
				
	}

//	public void addDetails(String url, String info) throws Exception {
//	//	if (j == 4)
//	
//		{
//		
//			// ........................communityurl...................................
//
//
////			if(!url.contains("/neighborhoods/madison-area/cottage-grove/kennedy-hills")) return;
//		
//			if(data.communityUrlExists(url)){
//				LOGGER.AddCommunityUrl(url+"------>repeated");
//
//				return;
//			}
//			LOGGER.AddCommunityUrl(url);
//			
//			U.log(j+"\t"+BASEURL +url);
//
//			
//			// .....................community
//			// name.................................
//			String commName = U.getSectionValue(info, "<!-- react-text:", "<!-- ");
//			commName = commName.replaceAll(", Home| \\d+ -->", " ");
//			U.log(commName);
//			//............for fecthing data of ready home and floorplan url......
//			//String chtml = U.getHTML(url);
//			U.log(U.getCache(BASEURL +url));
//			String chtml=U.getHtml(BASEURL +url,driver);
//			chtml = U.removeSectionValue(chtml, ">window.__PRELOADED_STATE__", "</html>");
//			String floorHtml=ALLOW_BLANK;
//			String readyHtml=ALLOW_BLANK;
//			String modelHtml=ALLOW_BLANK;
//			String floorPlanHomeDetails=ALLOW_BLANK;
//			String readyhomeDetails=ALLOW_BLANK;
//			chtml=chtml.replaceAll("view of waterfront community Summit|nearby trails and golf courses or the beautiful", "");
//			String comType = U.getCommType(chtml);
////			U.log("MMMMMMMMM "+Util.matchAll((chtml), "[\\s\\w\\W]{30}500's[\\s\\w\\W]{30}", 0));
//			//Move-in-ready homes------------------------------
//			String moveIns[]=U.getValues(chtml, "<div class=\"HomeCard_imageWrapper", "View Detail</a>");
//			U.log("SIZE"+moveIns.length);
//			int j=0,k=0,noMvIn=0;
//			for(String home:moveIns) {
//				
//				U.log("HHHOMe "+home);
//				if(home.contains("Jul. 20")||home.contains("Aug. 20")||home.contains("Sept. 20")||home.contains("Oct. 20")||home.contains("Nov. 20")||home.contains("Dec. 20"))
//					noMvIn++;
//				String homeurl = U.getSectionValue(home, "href=\"", "\"");
//				U.log("homeurl==="+homeurl);
//				readyHtml =getHTML(BASEURL+homeurl);
//				readyhomeDetails += U.getSectionValue(readyHtml, "<div class=\"css-1mgn83c PriceSection\"", "<style data-emotion-css=\"upspeu\">")+U.getSectionValue(readyHtml, "<h2 class=\"About_preTitle\"", "</p>");
////				if(j>5)break;
////				j++;
//			}
////			U.log(readyhomeDetails);
//			//FloorPlans------------------------------
//			String plans[]=U.getValues(chtml, "<div class=\"PlanCard_imageWrapper", "View Detail</a>");
//			for(String home:plans) {
//				String homeurl = U.getSectionValue(home, "href=\"", "\"");
//				U.log(homeurl);
//				if(homeurl.contains("/plan/brookdale-estates/alpine")) {
//					continue;
//				}
//				floorHtml = getHTML(BASEURL+homeurl);
////				U.log(U.getSectionValue(floorHtml, "<h2 class=\"About_preTitle\"", "</p>"));
//				floorPlanHomeDetails += U.getSectionValue(floorHtml, "<li class=\"PriceSection_listItem", "</ul></div><style data-emotion-css")+U.getSectionValue(floorHtml, "<h2 class=\"About_preTitle\"", "<h3 class=\"DetailSection_heading"); //"</p>");
//				if(k>5)break;
//				k++;
//			}
//			U.log(floorPlanHomeDetails.contains("loft"));
//			
//			//=============address=========================
//			String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = "FALSE";
//			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//			String addSec = U.getSectionValue(chtml, "Model Home Location</h5>", "</div>");
//			if(addSec!=null) {
//				addSec = addSec.replaceAll("</span><span data-reactid=\"\\d+\">", ",").replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->|\\.|Model Address Coming Soon|W139N|W275 N|W137N", "");
//				U.log(addSec);
//				add=U.findAddress(addSec+"-->");
//			}
//			if(add==null && addSec!=null) {
//				addSec  = U.getSectionValue(addSec, "<span data-reactid", "</span");
//				
//				add=U.findAddress(addSec+"-->");
//			}
////			if(add[0] != null && add[0] != ALLOW_BLANK) add[0] = add[0].replace("N27W24075", "N27 W24075"); //.replace("N200N4888", "N200 N4888")
//			U.log(Arrays.toString(add));
//			String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
//			String latlngSec =U.getSectionValue(info, "https://www.google.com/maps/place/", "/@");
//			if(latlngSec!=null) {
//				 latlng=latlngSec.split(",");
//				 lat = latlng[0];
//				 lng = latlng[1];
//			}
//			if(add==null && lat!=null) {
//				add=U.getAddressGoogleApi(latlng);
//				if(add == null) add = U.getAddressHereApi(latlng);
//				geo="TRUE";
//			}
//			U.log(Arrays.toString(latlng));
//			
//			
//			if(add[0] == ALLOW_BLANK || add[0].length()<4) {
//				
//				add = U.getAddressGoogleApi(latlng);
//				if(add == null) add = U.getAddressHereApi(latlng);
//				geo = "TRUE";
//			}
//			add[0]=add[0].replace("984 Griffin Way under construction-phone for private tour", "984 Griffin Way");
//			//===================prices==========
//			
//			
//			info =info.replaceAll("0s|0's", "0,000");
//			chtml=chtml.replace("Upper 400's", "Upper $400,000");
//			chtml = chtml.replaceAll("0s|0's|0’s", "0,000").replaceAll("upper 400s", "upper $400,000").replace("400&#x27;s", "$400,000").replace("Lot Size: 10,486 sq. ft. to 19,471 sq. ft.", "");
//					//.replace("in the low 500", "in the low $500");
//			if(readyhomeDetails!=null)readyhomeDetails=U.removeSectionValue(readyhomeDetails, "<span class=\"PriceSection_priceWas\"", "</span").replaceAll("Stories </b><!-- react-text: \\d+ -->", "story ");
////			U.log("MM"+Util.match((info+chtml+readyhomeDetails+floorPlanHomeDetails),"in the low $500,000"));
//			String price[] = U.getPrices((info+chtml+readyhomeDetails+floorPlanHomeDetails).replaceAll("Priced Was <!-- /react-text --><!-- react-text: \\d+ -->\\$\\d{3},\\d{3}<!-- /react-text -->|<span class=\"PriceSection_priceWas\" data-reactid=\"\\d+\">\\$\\d{3},\\d{3}</span>", ""),
//					" low \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);//			String sec = U.getSectionValue(chtml,
//			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
//			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//			U.log(minPrice);
//			U.log(maxPrice);
////			if(url.contains("/neighborhoods/milwaukee-area/lisbon/hillside-ridge")) {
////				minPrice="$500000";
////				maxPrice="$559900";
////			}
//			
//			U.log(info);
//			//==================================square feet======================
//			//String rmSec=U.getSectionValue(chtml, "If they love a particular", "\"uniqueName\":\"how-much-is-this");
//		/*	String sqft[] = U
//					.getSqareFeet(
//							(info+chtml+readyhomeDetails+floorPlanHomeDetails).replaceAll("</b><!-- react-text: \\d+ --> SQFT", " SQFT"),
//							"\\d,\\d{3}\\s*-\\s*\\d,\\d{3} SQFT|\\d{4}\\s*-\\s*\\d{4} SQFT|\\d{4} Square Feet|\\d,\\d{3}\\+ SQFT|\\d,\\d{3} SQFT|\\d{4} SQFT|\\d+\\-\\d+\\sSquare Feet|\\d,\\d+ sq. ft.|\\d,\\d{3} to \\d,\\d{3} Square Feet|\\d,\\d+ to \\d,\\d+ Square Feet|\\d+,\\d sq. ft. - \\d,\\d+ sq. ft.|\\d+,\\d+ sq. ft. to \\d+,\\d+ sq. ft.|\\d+,\\d+ sq. ft. � \\d+,\\d+ sq. ft.|\\d+,\\d+ Sq. Ft. ranch, \\d+,\\d+ Sq. Ft|SQ FT:</span> \\d,\\d+|\\d{1},\\d{3} Square Feet|\\d{4}-\\d{4} SQFT",
//							0);*/
//			String sqft[] = U
//					.getSqareFeet(
//							(info+chtml.replaceAll("<!-- react-text: \\d{3,4} -->", "")+readyhomeDetails+floorPlanHomeDetails),
//							"data-reactid=\"144\">1,800+</b>|\"sqftLow\":\\d+|\\d{4}\\+</b> SQFT|\\d,\\d{3}\\+</b> SQFT|\\d,\\d{3}-\\d,\\d{3} SQFT|\\d{4}-\\d{4} SQFT|\\d{4} - \\d{4} SQFT|\\d,\\d{3}\\+ SQFT|\\d{4} SQFT",0);
//			String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
//			String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			
//			if(url.contains("/neighborhoods/madison-area/fitchburg/terravessa"))maxSqf="2504";
//			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			//Proptyes & dPropptyes============================================
////			Stories </b><!-- react-text: 147 -->
//			chtml=chtml.replace("The Estates: Home", "Estate Residences");
//			//String[] rem=U.getValues(chtml, "elevations\":[{", "}");
////			String []remove=U.getValues(readyhomeDetails,"elevations\":[{\"e_caption\"", "\"checksum\":");
////   	  	   U.log("Size"+remove.length);
////			String removing=ALLOW_BLANK;
////			for(String remove:rem){
////				U.log("DDD"+remove);
////				chtml=chtml.replace(remove, "");
////				readyhomeDetails=readyhomeDetails.replace(remove, "");
////				floorPlanHomeDetails=floorPlanHomeDetails.replace(remove, "");
////			}
//			
//			//if(remove!=null)		
//			//readyhomeDetails=readyhomeDetails.replace(remove, "");
////			U.log("Yes"+Util.match(floorPlanHomeDetails,"Traditional"));
//			U.log(Util.matchAll((readyhomeDetails),"[\\w\\W\\s]{30}traditional[\\w\\W\\s]{30}", 0));
//			floorPlanHomeDetails=floorPlanHomeDetails.replace("Traditional","");
//
//			
//			chtml=chtml.replaceAll("Collection <!-- /react-text --><b data-reactid=\"\\d+\">Traditional", "Collection: Traditional")
//					.replaceAll("Rendering of Arbordale Craftsman Elevation|Ashbury Craftsman Front Elevation Rendering","")
//					.replace("Residences and The Estates offer single family homesites", "Residences and The Estate Homes offer single family homesites");
//			
//
//			String proptype = U.getPropType((chtml+readyhomeDetails+floorPlanHomeDetails).replaceAll("cottage-grove|Cottage-Grove|Cottage Grove WI|Cottage Grove|luxurious Owner's Bathroom|luxury Bathroom", "").replaceAll("alt=\"Highlander Estates Common Area|Craftsman Front Elevation", ""));
////			U.log("KKKK"+Util.matchAll(chtml,"[\\w\\W\\s]{60}traditional[\\w\\W\\s]{100}",0));
//
//			U.log("proptype: "+proptype);
//			
//			String dtype = U.getdCommType(((chtml + info +readyhomeDetails+floorPlanHomeDetails).replaceAll("Stories </b><!-- react-text: \\d+ -->", "story ").replace("floor", "").replace("story 1", "1 story").replace("First-Floor Master Plan", "")));//
//			
//		//	U.log("MMMMMMMMM "+Util.matchAll((chtml + info +readyhomeDetails).replaceAll("Stories </b><!-- react-text: \\d+ -->", "story "), "[\\s\\w\\W]{30}split[\\s\\w\\W]{30}", 0));
////			U.log(readyhomeDetails);
//			//Status============================================
//			chtml = chtml.replaceAll("Only four homesites in Brookdale Estates left", "Only 4 homesites left")
//					.replaceAll("32 new Home and Lot Packages coming soon|>Coming Soon<|>Coming Soon!<", "");
//			String propstatus = U.getPropStatus(chtml.replaceAll("Model Address Coming Soon|Closeout – 1 Ready Home remaining!", "") + info);
////			U.log(">>>>>>>>>>>>"+Util.matchAll(chtml+ info, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{30}", 0));
//			U.log("propstatus: "+propstatus);
//			
//			ArrayList<String> soldval=Util.matchAll(chtml, "<div class=\"HomeCard_soldLabel\" data-reactid=\"\\d+\">Sold</div>", 0);
////			U.log("readyHomeCount ::::::::"+readyHomeCount+"readyHomeCount ::::::::");
////			if(moveIns.length > 0 && soldval.size()!=moveIns.length && !propstatus.contains("Move-in")){
//				int soldcount=0;
//				soldcount=soldval.size();
//				
//				U.log("soldcount= "+soldcount+"       noMvIn="+noMvIn+"           moveIns="+moveIns.length);
//		if(moveIns.length >(soldcount+noMvIn )&& !propstatus.contains("Move-in")){
//
//				if(propstatus.length()<4){
//					propstatus = "Move In Ready";
//				}
//				else{
//					propstatus = propstatus + ", Move In Ready";
//				}
//			}
////			if(url.contains("lisbon/hillside-ridge"))maxSqf="3645";
////			propstatus = propstatus.replace("Ii", "II");lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
////			//U.log("Property status is::::::: : " + propstatus);
////			
//			propstatus = propstatus.replace("Move-in Ready Homes","Move In Ready");
////			// .................... adding in  csv...............................................
//			add[1] = add[1].replaceAll(",| - 49", "");
//			
////			===================================================================
//			String lotCount=ALLOW_BLANK;
//			String[] lot_data=null;
//			String lot_sec=U.getSectionValue(chtml, "<g>", "</g>");
//			if(lot_sec!=null) {
//				lot_data=U.getValues(lot_sec, "class=\"leaflet-interactive\"", "</path>");
//			if(lot_data.length>0) {
//				lotCount=Integer.toString(lot_data.length);
//				 U.log("lotCount=="+lotCount);
//				}
//			}
//			
//			
//			
//			
//			data.addCommunity(commName.trim(), BASEURL + url, comType);
//			data.addAddress(add[0].replace("984 Griffin Way Under Construction-phone For Private Tour", "984 Griffin Way").replace(",", ""), add[1], add[2].trim(), add[3]);
//			data.addLatitudeLongitude(latlng[0], latlng[1], geo);
//			data.addPropertyType(proptype, dtype);
//			data.addPropertyStatus(propstatus.replace("IIi", "III"));
//			data.addPrice(minPrice, maxPrice);
//			data.addSquareFeet(minSqf, maxSqf);
//			data.addNotes(U.getnote(chtml+info));
//			data.addUnitCount(lotCount);
//			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
//		}
//		j++;
//	}
	
	public String callRegStatus(String key) throws Exception{
		key=key.trim();
		U.log("key::"+key);
		String data=ALLOW_BLANK;
		String[] regUrls={"milwaukee-neighborhoods","madison-neighborhoods"};
		for(String regUrl:regUrls){
			regUrl=BASEURL+regUrl;
			String regHtml=U.getHtml(regUrl, driver);
			
			String regComStatus[] = U.getValues(regHtml, "com-row ng-scope", "arrow-link");
			for(String regComStat:regComStatus){
				if(regComStat.contains(key)){
					data=data+regComStat;
				}
			}
		}
		return data;
	}
	
	public static String getHtml(String url, WebDriver driver)
			throws Exception {
		
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;
		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);
		fileName = U.getCachePath() + Dname + "/" + fileName;
		File f = new File(fileName);
		if (f.exists())
			return html = FileUtil.readAllText(fileName);
		if (!f.exists()) {
			BufferedWriter writer = new BufferedWriter(new FileWriter(f));
			synchronized (driver) {
				try {
				U.log("in gethtml==" + url);
				driver.get(url);
				Thread.sleep(1000);
				((JavascriptExecutor) driver).executeScript(
						"window.scrollBy(0,800)", ""); 
				Thread.sleep(2000);
				U.log("Current URL:::" + driver.getCurrentUrl());
				Thread.sleep(1000);
				WebElement loadmore = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[3]/div[2]/section/div[1]/div/span"));//(By.className("CommunityResults_loadMore"));//(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[3]/div[2]/section/div[1]/div/div"));
				Thread.sleep(1000);
				loadmore.click();
				Thread.sleep(1000);
				html = driver.getPageSource();
				if(loadmore.isDisplayed()) {
					loadmore = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[3]/div[2]/section/div[1]/div/span"));//(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[3]/div[2]/section/div[1]/div/div"));
					Thread.sleep(1000);
					loadmore.click();
					Thread.sleep(1000);
					html = driver.getPageSource();
				}
				}catch(Exception e) {}}
				Thread.sleep(1000);
				writer.append(html);
				writer.close();
			
		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}
		return html;

	}
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"216.169.73.65",34679));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			urlConnection.addRequestProperty("Accept-Language","en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			urlConnection.addRequestProperty("referer", "https://www.timobrienhomes.com/");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			
			U.log("gethtml expection: "+e);
			

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}