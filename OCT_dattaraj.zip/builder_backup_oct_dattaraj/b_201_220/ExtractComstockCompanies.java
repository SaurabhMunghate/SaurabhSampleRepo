package com.shatam.b_201_220;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class ExtractComstockCompanies extends AbstractScrapper {

	public ExtractComstockCompanies() throws Exception {
		super("Comstock Companies", "https://comstockcompanies.com/");
		// TODO Auto-generated constructor stub
		 LOGGER = new CommunityLogger("Comstock Companies");
	}
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractComstockCompanies();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Comstock Companies.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://comstockcompanies.com/residential/");
		String sec=U.getSectionValue(mainHtml, "<div class=\"hb-main-content col-12\">", "<!-- END .hb-main-content -->");
//		String[] commSections = U.getValues(mainHtml, "<div class=\"vc_row element-row vc_inner row\">", ">MORE INFO</a>");
//		U.log(commSections.length);
		String[] commUrl=U.getValues(sec, "<div class=\"wpb_wrapper\">", "</div></div></div></div></div></div></div></div><div");
		for(String CommSec : commUrl){
			if(CommSec.contains(">MORE INFO</a>")) {
		String url=U.getSectionValue(CommSec, "<a href=\"", "\" class");
//		U.log("headSec=="+CommSec+"\n\n");
		
		
//		try {
			addDetails(url,CommSec);
//		} catch (Exception e) {}
		
		
			}
		}
		
	}

	private void addDetails(String commUrl, String commSec) throws Exception {
		// TODO Auto-generated method stub
		
		

		
		
		if(data.communityUrlExists(commUrl))	{
			LOGGER.AddCommunityUrl(commUrl+"********repeated*************");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		if(commUrl.contains("http://")) {
			commUrl=commUrl.replace("http://", "https://");
		}
		U.log("Count== "+j+"\nComUrl=="+commUrl);
		
		//================= Single Run.
		
//		if(!commUrl.contains("https://blvdansel.com/")) return;
		
		
		String html = U.getHTML(commUrl);
		
		//======================Community name
		
		String commName=U.getSectionValue(commSec, "<h1>BLVD |", "</h1>");
		commName=commName.replace("Metro Plaza District |", "");
		
		U.log("commName === "+commName);
		
		//=================community Type==========================
		
		String commType=U.getCommType(html);
		U.log("commType==="+commType);

		//==============================Floorplan & 
		
		String floorData="";
		String amenities="";
		String locationHtml="";
		
		String urlSec=U.getSectionValue(html, "<ul id=\"main-nav\"", "</ul>");
//		U.log("urlSec=="+urlSec);
		if(urlSec==null)
			urlSec=U.getSectionValue(html, "<div class=\"navbar-inner\">", "</nav>");
		U.log("url==\n"+urlSec);
		
		
		if(urlSec!=null) {
		String[] urls=U.getValues(urlSec, "href=\"", "\"");
		U.log("urls=="+urls.length);
		
		for(String url : urls) {
//			if(url.contains("floorplan") || url.contains("amenities"))
//			U.log("url=="+url);
			if(url.contains("floorplan") ) {
				if(!url.contains("https://")) {
					url=commUrl+url;
				}
				U.log("floorurl=="+url);

				floorData+=U.getHTML(url);
			}
			if(url.contains("amenities") ) {
				if(!url.contains("https://")) {
					url=commUrl+url;
				}
				U.log("amenities url=="+url);

				amenities+=U.getHTML(url);
			}
			if(url.contains("location/") ||url.contains("commons.blvdloudoun")||url.contains("gramercyeast.blvdloudoun")||url.contains("flats.blvdloudoun"))
			{
				if(!url.contains("https://")) {
					url=url.replace("http://", "https://");
				}
				if(!url.contains("location/")) {
//					url=commUrl+url;
					U.log("url=="+url);
					String html1=U.getHTML(url);
					String section=U.getSectionValue(html1, "<ul class=\"menuitemcontainer nav\">", "</ul>");
					String[] link=U.getValues(section, "href=\"", "\"");
					for(String a : link) {
//					U.log("link=="+a);
						if(a.contains("amenities") ) {
							if(!a.contains("https://")) {
								a=url+a;
							}
							U.log("amenities url=="+a);

							amenities+=U.getHTML(a);
						}
						if(a.contains("floorplan") ) {
							if(!a.contains("https://")) {
								a=url+a;
							}
							U.log("floorurl=="+a);

							floorData+=U.getHTML(a);
						}
					}
				}
				else {
//					U.log("************************"+url);
					locationHtml=U.getHTML(url);
				}
				
			}
		}
		}
		
		//------FLOORDATA----//
		String amenitiesData = ALLOW_BLANK;
		
		if(commUrl.contains("https://www.blvdfortyfour.com/")) {
			
			String floors = U.getHTML("https://www.blvdfortyfour.com/floorplans");
			
			floors = floors.replaceAll("Sq. Ft.</span>", "Square Feets</span>").replace("<span class='sr-only'>to</span>", "");
			floorData += floors;
		}
		
		if(commUrl.contains("https://blvdansel.com/")) {
			
			String floors = U.getHTML("https://blvdansel.com/floorplans/");
			
			floors = floors.replaceAll("sq. ft.", "SqFts.</span>");
			floorData += floors;
			
			
			amenitiesData = U.getHTML("https://blvdansel.com/amenities/");
		}

		//================================================Address section===================================================================

		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		
		
		String addSec=U.getSectionValue(html, "no-separator widget-column\">","<a href=");
		
		U.log("addSec=="+addSec);
		if(addSec==null)
		{
			addSec=U.getSectionValue(html, "navigation__contact\">","</a>");
			
		}
		if(addSec!=null) {
			addSec=addSec.replace("<br>", ", ");
			addSec=U.getNoHtml(addSec);
		addSec=addSec.replaceAll("OPEN DAILY|Mon–Fri: 9 AM – 6 PM|Sat: 10 AM – 5 PM|Sun: 12 PM – 5 PM|Visit Us", "").trim()
				.replaceAll("Reston,", ", Reston,")
				.replaceAll("22050 Eastside Dr, \n" + 
						"Ashburn, VA 20147, ,", "22050 Eastside Dr, Ashburn, VA 20147");
		
		U.log("addSec here ======= "+addSec);
		add=U.getAddress(addSec);
		
		}
		
	
		else {
		add[0]=U.getSectionValue(html, "address_street\">", "</div>").trim();
		add[1]=U.getSectionValue(html, "address_city\">", "</span>");
		add[2]=U.getSectionValue(html, "address_state\">", "</span>");
		add[3]=U.getSectionValue(html, "address_zip\">", "</span>");
		}
		
		add[0]=add[0].replace("&nbsp;", "");
	
	
		U.log("Address==="+Arrays.toString(add));



		//=================latlng==========================

		latlag[0]=U.getSectionValue(html, " var latitude = \"", "\";");
		latlag[1]=U.getSectionValue(html, "var longitude = \"", "\";");


		if(latlag[0]==null && locationHtml.length()>20) {
			String latlngSec=U.getSectionValue(locationHtml, "\"map_center\":\"", "\",");
			latlag=latlngSec.split(",");
		}
		
		U.log("latlag==="+Arrays.toString(latlag));
		U.log("geo==="+geo);
		
		if(latlag[0]==null && commUrl.contains("https://blvdreston.com/")) {
			
			String geoSec = U.getSectionValue(amenities, "<p><iframe style=", "width=");
			U.log("geoSec: "+geoSec);
			
			latlag[0] = Util.match(geoSec, "3d\\d+.\\d{5}").replace("3d", "");
			latlag[1] = Util.match(geoSec, "2d-\\d+.\\d{5}").replace("2d", "");
			
			U.log("LATLONG: "+Arrays.toString(latlag));

		}
		
		if(latlag[0]==null && commUrl.contains("https://www.blvdfortyfour.com/")) {
			
			String geoSec = U.getSectionValue(html, "@type\": \"GeoCoordinates\"", "},");
			U.log("geoSec: "+geoSec);
			
			latlag[0] = U.getSectionValue(geoSec, "latitude\": \"", "\"");
			latlag[1] = U.getSectionValue(geoSec, "longitude\": \"", "\"");
			
			U.log("LATLONG: "+Arrays.toString(latlag));

		}
			
			
		if(latlag[0]==null && add[0]!=null && add[1]!=null && add[2]!=null && add[3]!=null) {
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		
		//============================================Price and SQ.FT======================================================================
				
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				String prices[] = U.getPrices(floorData+html,"\\$\\d{3},\\d{3}", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
				//======================================================Sq.ft===========================================================================================		
				
				
				String[] sqft = U.getSqareFeet(html+floorData,
								"\\d{4} - \\d{4} SqFts.|\\d{3} - \\d{3} SqFts.|\\d{4} SqFts.|\\d{3} SqFts.|\\d,\\d{3} Square Feets</span>|\\d{3} Square Feets</span>|\\d,\\d{3} -<span class='sr-only'>to</span> \\d,\\d{3}<span class=\"sr-only\">Square Foot|\\d,\\d{3}<span class=\"sr-only\">Square Foot|\\d{3} -<span class='sr-only'>to</span> \\d{3}<span class=\"sr-only\">Square Foot|\\d{3}<span class=\"sr-only\">Square Foot",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				
				U.log("SQ.FT--->"+minSqft+"   "+maxSqft);
//				U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(html+floorData , "[\\w\\s\\W]{30}672[\\w\\s\\W]{100}", 0));
				
				//==========================================================Property Type================================================
				html=html.replace("luxury studio", "Featuring luxury Style studio")
						.replaceAll("floor-courtyard|Floor Courtyard", "");
				
				String proptype=U.getPropType((html+floorData+amenitiesData).replaceAll("title=\"Patio \" |alt=\"Large covered patio near the pool|floor-courtyard|9th Floor Courtyard</a>", ""));
//				U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(amenitiesData, "[\\w\\s\\W]{30}courtyard[\\w\\s\\W]{100}", 0));

				//==================================================D-Property Type======================================================
						String dtype=U.getdCommType((html+floorData).replace(".single-floorplans", "")
								.replaceAll("[f|F]loor", ""));

				//==============================================Property Status=========================================================
					
						String pstatus=U.getPropStatus((html+commSec).replaceAll("__sold-out", ""));

				//============================================note====================================================================
						
						String note=U.getnote(html+commSec);
						
			//===============================================================
						
						data.addCommunity(commName,commUrl, commType);
						data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
						data.addPrice(minPrice, maxPrice);
						data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
						data.addSquareFeet(minSqft, maxSqft);
						data.addPropertyType(proptype, dtype);
						data.addPropertyStatus(pstatus);
						data.addNotes(note); 
						data.addUnitCount(ALLOW_BLANK);
						data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
						j++;
	}
	
	

}
