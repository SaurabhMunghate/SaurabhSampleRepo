package com.shatam.b_201_220;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDornHomes extends AbstractScrapper {
	
	public ArrayList<String> setofcomm = new ArrayList<String>();
	CommunityLogger LOGGER;
	static int j = 0;
	String base_Url = "https://www.dornhomes.com";
	static int i;
    WebDriver driver = null;
    
    HashSet<String> commurl = new HashSet<>();
    HashSet<String> regionurl = new HashSet<>();
    
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractDornHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Dorn Homes.csv", a.data().printAll());
	}

	public static String homeurl = "https://www.dornhomes.com";

	public ExtractDornHomes() throws Exception {
		super("Dorn Homes", homeurl);
		LOGGER = new CommunityLogger("Dorn Homes");
	}

	int a = 0;

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML(homeurl);
		
		
		String urlsection=U.getSectionValue(html, "The Perfect Home For You Is In...", "Your Arizona</span>"); //"<a href=\"/find-a-home/dorn-homes-at-tubac/\"");
		//U.log("urlsection: "+urlsection);
		
		String regSectionUrls[]=U.getValues(urlsection, "href=\\\"/find-your-home", "\"");
		U.log("regSectionUrls length: "+regSectionUrls.length);
		
		for(String regSectionUrl :regSectionUrls){
			
			regSectionUrl = "https://www.dornhomes.com/find-your-home"+regSectionUrl;
			
			//U.log("regSectionUrl :"+regSectionUrl);

			//adding in region set.
			regionurl.add(regSectionUrl);
		}
			//adding sedona region url.
			regionurl.add("https://sedonaranchaz.com/");
		
		U.log("regionurl size: "+regionurl.size());
		
		
			
		for(String regionUrl:regionurl) {
			
			regionUrl = regionUrl.replace("\\", "");
			U.log("regionUrl ==== "+regionUrl);
			
			String reghtml=U.getHtml(regionUrl, driver);
			
			//----sedonaranchaz is a community----------
			if(regionUrl.contains("sedonaranchaz.com") || regionUrl.contains("madera-estates")) {
				
//				try {
					commDetails(regionUrl, ALLOW_BLANK);
//				} catch (Exception e) {}
				
			}
			else if(reghtml.contains("Our Communities")) {
				
				String comSection = U.getSectionValue(reghtml, "<div id=\"bdx-cards_01_12-08-2021", "View Details</span>");
//				U.log("comSection: "+comSection);

				String comurl = "https://www.dornhomes.com" + U.getSectionValue(comSection, "href=\"", "\"");
				U.log("comurl: "+comurl);
		
//				try {
					commDetails(comurl, comSection);
//				} catch (Exception e) {}

			}
		}
			
					
	LOGGER.DisposeLogger();
	try{
		driver.quit();
		}catch (Exception e) {}

	}

	public void commDetails(String commUrl, String comSec) throws Exception {
//
//	try{

//		 if(!commUrl.contains("https://prescott.dornhomes.com/morningstar-coming-soon"))return;
//		 if(!commUrl.contains("https://www.dornhomes.com/find-a-home/wickenburgaz/estates-at-wickenburg-ranch/"))return;
//		if(j>=6)
		{

		//	U.log("COMSEC: "+comSec);
			
//			if(commUrl.contains("https://www.dornhomes.com/find-a-home/wickenburgaz/dorn-homes-at-wickenburg-ranch/")) {
//				LOGGER.AddCommunityUrl(commUrl);
//				return;
			
			U.log(j + " COMMUNITY URL ======" + commUrl);
			
			if(commUrl.contains("http://hillsideaz.com"))commUrl="https://hillsideaz.com";
			
			commUrl=commUrl.replace("http://www.sedonaranchaz.com","https://www.sedonaranchaz.com");
			String html1 = "";
			if(commUrl.contains("pinnacle-views-at-prescott-lakes")) {
				 html1=U.getHtml(commUrl, driver);
			}
			else {
				 html1 = U.getHTML(commUrl);
			}

			
			String mHtml=html1;
			// removing find your homes section
			html1 = U.removeSectionValue(html1, "<nav", "</nav");
			if (data.communityUrlExists(commUrl)) {
				LOGGER.AddCommunityUrl(commUrl + "---------------------------------repeat");
				return;
			}
//			
//			if(commUrl.contains("http://hillsideaz.com")) {
//				return;/// coming soon
//			}
//		
			LOGGER.AddCommunityUrl(commUrl);
 
			// ============= Community Name ==================
			String commName = ALLOW_BLANK;
			commName = U.getSectionValue(html1, "<h1 class=\"communityName\">", "</h1>");
			if (commName == null)
				commName = U.getSectionValue(html1, "<title>", " - ");
			
			//U.log("Community Name :" + commName);
			if (commUrl.contains("https://www.dornhomes.com/saddlewood/")
					|| commUrl.contains("https://www.dornhomes.com/talkingrock/")) {
				commName = U.getSectionValue(html1, "<span class=\"breadcrumbCurrentPage breadcrumbFontSize\">",
						"</span>");
				if (commName.contains("-"))
					commName = commName.replace("-", " ");
			}
			 if(commUrl.contains("https://prescott.dornhomes.com/morningstar-coming-soon"))commName= "Morningstar";
			if (commUrl.contains("https://www.dornhomes.com/find-a-home/wickenburgaz/dorn-homes-at-wickenburg-ranch/"))commName= "Wickenburg Ranch";
			if(commUrl.contains("pinnacle-views-at-prescott-lakes"))commName=U.getSectionValue(html1, "<span class=\"breadcrumbCurrentPage breadcrumbFontSize\">", "</span>");
			if(commUrl.contains("www.sedonaranchaz.com")) commName = "Sedona Ranch";
			if (commUrl.contains("https://prescott.dornhomes.com/en/hidden-hills-coming-soon"))commName= "Hidden Hills";
			if(commUrl.contains("https://hillsideaz.com")) {
//				commUrl="https://hillsideaz.com";
				commName = "Hillside";}
			commName=commName.replace("&#8211; On the Banks of Oak Creek", "");
			
			U.log("hhhhhh>"+commName);

			// ===================== Address ========================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec = U.getSectionValue(html1, "<div class=\"communityAddress \">", "</div>");
		//	U.log("addSec1 : " + addSec);
			
			
				
			if (addSec == null) {
				addSec = U.getSectionValue(html1, "<p><span class=\"fadd\">", "</p>");
			}
			
			
			//U.log("addSec : " + addSec);
			if (addSec != null) {
				if (addSec.contains("addressStreet"))
					add[0] = U.getSectionValue(addSec, "addressStreet\">", "</span>");
				if (addSec.contains("addressCity"))
					add[1] = U.getSectionValue(addSec, "addressCity\">", "</span>");
				if (addSec.contains("addressState"))
					add[2] = U.getSectionValue(addSec, "addressState\">", "</span>");
				if (addSec.contains("addressZipCode"))
					add[3] = U.getSectionValue(addSec, "addressZipCode\">", "</span>");
				add[0] = add[0].trim();
				add[1] = add[1].replace(",", "");
				add[0] = add[0].trim();
				add[2] = add[2].trim();
				add[3] = add[3].trim();
			}
			
			U.log("Add : " + Arrays.toString(add));

			// =============== LatLng =========================
			String flag = "False";
			String note = ALLOW_BLANK;
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			if(commUrl.contains("https://prescott.dornhomes.com/westwood")) {
				 add[1]="Prescott";
			add[2]="AZ";
			latlng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlng);
			flag="TRUE";
		note="Address Taken From City And State";
			}
			if(commUrl.contains("/madera-estates")) {
				add[1]="Sahuarita";
				add[2]="AZ";
				latlng=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlng);
				flag="TRUE";
			note="Address Taken From City And State";
			}
if(commUrl.contains("www.sedonaranchaz.com")) {
				
				//, Sedona, AZ 
				add[0]="12 Lagos Court";
				 add[1]="Sedona";
			add[2]="AZ";
			add[3]="86336";
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null)latlng = U.getGoogleLatLngWithKey(add);
			flag="TRUE";
		commName="Sedona Ranch";
		
				
}
if(commUrl.contains("https://prescott.dornhomes.com/morningstar-coming-soon")) {
	
	//, Sedona, AZ 
	 add[1]="Prescott Valley";
add[2]="AZ";
latlng=U.getlatlongGoogleApi(add);
if(latlng == null)latlng = U.getGoogleLatLngWithKey(add);
add=U.getAddressGoogleApi(latlng);

flag="TRUE";
}
  if(commUrl.contains("/hillside-coming-soon")||commUrl.contains("/hillsideaz.com")) {
	
	//, Sedona, AZ 
	 add[1]="Sedona";
      add[2]="AZ";
     latlng=U.getlatlongGoogleApi(add);
     if(latlng == null)latlng = U.getGoogleLatLngWithKey(add);
     add=U.getAddressGoogleApi(latlng);

     flag="TRUE";
     note="Address is taken from city and state";
}
if(commUrl.contains("find-a-home/wickenburgaz/dorn-homes-at-wickenburg-ranch/")) {
	add[0]="3440 Maverick Dr ";
	add[1]="Wickenburg";
	add[2]="AZ";
	add[3]="85390";
	latlng=U.getlatlongGoogleApi(add);
	
}

if(commUrl.contains("https://prescott.dornhomes.com/pinnacle-views")) {
	add[0]=ALLOW_BLANK;
	add[1]="Prescott";
	add[2]="AZ";
	latlng=U.getlatlongGoogleApi(add);
	if(latlng == null)latlng = U.getGoogleLatLngWithKey(add);
	add=U.getAddressGoogleApi(latlng);
	flag="TRUE";
}
if (commUrl.contains("https://prescott.dornhomes.com/en/hidden-hills-coming-soon")) {
	add[0]=ALLOW_BLANK;
	add[1]="Prescott";
	add[2]="AZ";
	latlng=U.getlatlongGoogleApi(add);
	if(latlng == null)latlng = U.getGoogleLatLngWithKey(add);
	add=U.getAddressGoogleApi(latlng);
	flag="TRUE";
}

if(commUrl.contains("find-a-home/dorn-homes-at-tubac")) {
	//600 W. Gurley St., Ste 100  , AZ 86305
	add[0]="600 W. Gurley St. Ste 100";
	add[1]="Prescott";
	add[2]="AZ";
	add[3]="86305";
	
	latlng=U.getlatlongGoogleApi(add);
	flag="TRUE";
	
}
			String LLSec = U.getSectionValue(html1, "<div class=\"geolocationHolder \">", "</div>");
			if (LLSec != null) {
				if (LLSec.contains("Latitude:"))
					latlng[0] = U.getSectionValue(LLSec, "Latitude:</span>", "</span>");
				if (LLSec.contains("Longitude"))
					latlng[1] = U.getSectionValue(LLSec, "Longitude:</span>", "</span>");
				latlng[0] = latlng[0].trim();
				latlng[1] = latlng[1].trim();
			}
			if (LLSec == null) {
				String ssl = U.getSectionValue(html1, "<a href=\"https://www.google.com/maps/dir//", "/@");
				if (ssl != null) {
					latlng = ssl.split(",");
				}
			}
			if (latlng[0]==ALLOW_BLANK) {
				latlng[0]=U.getSectionValue(html1, "data-center-latitude=\"", "\"");
				latlng[1]=U.getSectionValue(html1, "data-center-longitude=\"", "\"");
			}
			U.log("LatLng = " + Arrays.toString(latlng));
			if (latlng[0] != ALLOW_BLANK || latlng[1] != ALLOW_BLANK) {
//				flag = "FALSE";
				}
			else {
				if (add[0] != ALLOW_BLANK || add[1] != ALLOW_BLANK || add[2] != ALLOW_BLANK || add[3] != ALLOW_BLANK) {
					latlng = U.getlatlongGoogleApi(add);
					flag = "TRUE";
				}
			}
			if (add[0]==ALLOW_BLANK&&latlng[0]!=ALLOW_BLANK&&latlng[0]!=null) {
				add=U.getAddressGoogleApi(latlng);
				flag = "TRUE";
			}
			if ((add[0] == ALLOW_BLANK || add[1] == ALLOW_BLANK || add[2] == ALLOW_BLANK || add[3] == ALLOW_BLANK)
					&& flag == "FALSE") {
				String[] addr = U.getAddressGoogleApi(latlng);
				addr[0] = addr[0].trim();
				addr[1] = addr[1].trim();

				if (add[1].contains(addr[1])) {
					add[0] = addr[0];
					flag = "TRUE";
				}
			}
			 if(commUrl.contains("prescott/pinnacle-views-at-prescott-lakes/")) {
				 add=U.getAddressGoogleApi(new String[] {"34.59114","-112.450783"});
				 latlng[0]="34.59114";
				 latlng[1]="-112.450783";
				 flag="TRUE";
			 }
			 String allplandata="";
//			 if(commUrl.contains("pinnacle-views-at-prescott-lakes")) {
//				 String floorhtml=U.getHTML("https://dornhomes.lotvue.com/lotbuzz/render_communitylegend_view?legendtype=Floor+Plan&community=Pinnacle&community_without_spaces=Pinnacle&lotbuzz_site_url=&is_touch=0&split_map=&building_name=&floor=&parcel=&phase_name=");
//				 String planid[]=U.getValues(floorhtml, "floor_plan_image_modal_", "\"");
//				 for(String id:planid) {
//					 U.log(id);
//					  allplandata+=U.getHTML("https://dornhomes.lotvue.com/tbldata/legend_plan_details?project=Marketing&plan_view=lotbuzz_click_view&community=Pinnacle&plan_id="+id);
//				 }
//			 }
//			
			 String priceforSedonaRanch=ALLOW_BLANK;
			 String availhtml ="",floor="";
			 if(commUrl.contains("sedonaranchaz")) {
			  availhtml = U.getHTML("https://sedonaranchaz.com/houses-for-sale/");
			  floor = U.getHTML("https://sedonaranchaz.com/floorplans/");
			  String homesites = U.getHTML("https://sedonaranchaz.com/homesites/");
			  priceforSedonaRanch = availhtml+ floor+homesites;
			 }
//			 U.log(Arrays.toString(U.getPrices((priceforSedonaRanch), "\\$\\d,\\d{3},\\d{3}", 0)));
			// ========== Price =====================
//			 U.log("MATCH ALL: "+Util.matchAll(html1+priceforSedonaRanch, "[\\s\\w\\W]{50}\\$2,490,000[\\s\\w\\W]{50}", 0));
			String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
			html1 = html1.replaceAll("0s|0's", "0,000");
			prices = U.getPrices((html1+priceforSedonaRanch), "\\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+", 0);
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;

			// =========== Sqft =====================
			String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
			sqft = U.getSqareFeet(html1+allplandata+priceforSedonaRanch,
					"\\d,\\d{3} S.F.|\\d,\\d{3} to \\d,\\d{3} square feet| \\d,\\d+ square feet|\\d,\\d+ Square feet|\\d{4}SqFt|\\d,\\d{3} - \\d,\\d{3} SF|SQUARE FEET: \\d,\\d{3} - \\d,\\d{3}|SQUARE FEET: \\d,\\d{3}", 0);
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			// ======== Community Type ====================
			String commType = ALLOW_BLANK;

			String rem = U.getSectionValue(html1, "Find a Home</a>", " style=\"background:");

			html1 = html1.replaceAll("Craftsman", "craftsmen style homes");
			html1 = html1.replaceAll(" American Farmhouse", "The Farmhouse").replace("Tubac - Coming Soon", "");
			commType = U.getCommunityType((html1 + commName).replaceAll("Tubac Golf Resort</a>", ""));

			// ============== Property Type =====================

			String quickMoveInSec = U.getSectionValue(html1, "Quick-Move In Homes</h3>",	"<div class=\"directionsSection\"");
			if(quickMoveInSec == null) quickMoveInSec = U.getSectionValue(html1, "Quick Move-In Homes</h2>",	"<div id=\"defaultSearchLoadingInfo");
			U.log(quickMoveInSec);
			int quickMoveInHome = 0;
			if (quickMoveInSec != null) {
				String[] quickUrlSection = U.getValues(quickMoveInSec, "<h3 class=", "</h3>");
				U.log("Quick Home =" + quickUrlSection.length);
				quickMoveInHome = quickUrlSection.length;
			}
			String desc = U.getSectionValue(html1, "<p class=\"communityDescription\">",
					"class=\"amenityWrapper communities\">");
			html1 = html1.replaceAll("\\d\\d homesites|\\w{3} homesites", "");
			
			//U.log(comSec);
//			comSec=comSec.replaceAll("alt=\"Grand Opening of|closeout.png|tipCloseout", "");
			html1 = html1.replaceAll("plan is temporarily sold", "")
					.replaceAll(";\">opening \\d{4}</span>", "opening 2022");
			
			
			String pStatus = U.getPropStatus((comSec + desc + html1).replaceAll("Homes coming late 2021", ""));
			U.log("status :: " + pStatus);
			U.log("MATCH ALL: "+Util.matchAll(comSec, "[\\s\\w\\W]{50}QUICK MOVE-IN HOMES[\\s\\w\\W]{50}", 0));
			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll(desc + html1, "[\\s\\w\\W]{50}QUICK MOVE-IN HOMES[\\s\\w\\W]{50}", 0));
			
			pStatus = pStatus.replace(", Under Construction", "");
			
			if(pStatus.contains("Limited Homesites Remaining"))
				pStatus = "Limited Homesites Remaining";
			if(pStatus.contains("Quick Move-in Homes"))
				pStatus = pStatus.replace(", Quick Move-in Homes", "").replace("Quick Move-in Homes", "");
//			if(pStatus.contains("Coming Soon,"))
//				pStatus = pStatus.replace("Coming Soon,", "Coming Soon");
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott-valley/ridgeline/")) pStatus = pStatus.replace("Coming Soon", ALLOW_BLANK);
			
			
			//pStatus=pStatus.replaceAll(", Coming In 2022|Coming In 2022, ", "");
			
			
			// ============== Property Type =====================

			String allPlanData = getPlanData(html1);
//			U.log(Util.matchAll(comSec + html1, "[\\w\\s\\W]{30}farmhouse[\\W\\s\\w]{30}", 0));
			if(commUrl.contains("https://www.sedonaranchaz.com")){
				allPlanData = U.getHTML("https://sedonaranchaz.com/houses-for-sale/");
			}
			html1 = html1.replace("The Villas</a> – old", " Villas Homes – old")
					.replace("Farmhouse and Country Estates architecture", "Farmhouse style and Country Estates homes architecture")
					.replace("craftsmen leave", "Craftsman style");

			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(allPlanData + html1+priceforSedonaRanch,"[\\s\\w\\W]{50}Farmhouse[\\s\\w\\W]{30}", 0));	
			String propType = U.getPropType(((allPlanData + html1+priceforSedonaRanch)
					.replaceAll("Sedona home courtyard|%20Modern%20Farmhouse%20Elevation|Sonoma Modern Farmhouse Elevation| Modern Farmhouse Elevation |The Villas|the-villas|luxurious bathroom|alt=\"Community with Low HOA", "")));
			U.log("PropType:::::" + propType);

			// =========== Derived Community Type ====================
			// fetching plan data

			String[] detailUrks = U.getValues(html1, "<a class=\"viewDetails\" href=\"", "\"");
			String detilHtml = "";
			for (String details : detailUrks) {
				detilHtml = detilHtml + U.getHTML("http://www.dornhomes.com/" + details);
				detilHtml = detilHtml.replace("Pronghorn Ranch</a>", "");
			}
			String dType = U.getdCommType((html1 + detilHtml + allPlanData+allplandata+priceforSedonaRanch)
					.replaceAll("wickenburg-ranch|sedonaranchaz|active-branch|Outlat at Wickenburg Ranch</a>|-ranch| Ranch</a>|RANCH|rAnch|Ranch Rd|Ranch to inquire|rAnch", ""));
			U.log("dtype :: " + dType);

			
//			 U.log("MATCH ALLDD: "+Util.matchAll(html1 + detilHtml + allPlanData+allplandata+priceforSedonaRanch, "[\\s\\w\\W]{50}ranch[\\s\\w\\W]{50}", 0));

			
			//============= Quick HOmes =====================
			//https://www.dornhomes.com/find-a-home/move-in-ready-homes-prescott/
//			String quickHtml = U.getHTML("https://www.dornhomes.com/find-a-home/move-in-ready-homes-prescott/");
//			String[] quickSec = U.getValues(quickHtml, "<div class=\"frame\">", "View Details");
//			
//			int m =0;
//			for(String quickData : quickSec) {
//				U.log(quickData.toLowerCase().contains(commName.toLowerCase()));
//				if(quickData.toLowerCase().contains(commName.toLowerCase()) && (!quickHtml.contains("New Homes Under Construction")))
//				{
//					if(!pStatus.contains("Move")) {
//						
//						if(pStatus.length()<3)
//							pStatus = "Quick Move-In Homes";
//						else if(pStatus.length()>3) pStatus += ", Quick Move-In Homes";
//						 
//					}
//				}
//			}
			
//			if(m>0)
//				if(!pStatus.contains("Move")) {
//					
//					if(pStatus.length()<3)
//						pStatus = "Quick Move-In Homes";
//					else if(pStatus.length()>3)
//						pStatus += ", Quick Move-In Homes";
//				}
			
			// ================= Notes =================

			if (commName == null) {
				commName = U.getSectionValue(html1, "pageTitle\">", "</h1>");
			}

			if (add[2] == ALLOW_BLANK) {
				add[2] = "AZ";
				add[1] = "Prescott";
			}
			add[0] = add[0].toLowerCase();
			add[0] = add[0].replaceAll("suite 200|,", "");
  
		//	U.log(commName);
			if(commUrl.contains("https://prescott.dornhomes.com/westwood"))
				commName="Westwood";
			
			
	if(commUrl.contains("www.sedonaranchaz.com")) {
					
					//, Sedona, AZ 
					
			commName="Sedona Ranch";
			commType ="Gated Community";
			//pStatus=ALLOW_BLANK;
//			sqft[0]="2418";
//			sqft[1]="5258";
//			prices[0]="$2,900,000";
//		prices[1]=ALLOW_BLANK;
					
	}
if(commUrl.contains("find-a-home/wickenburgaz/outlaw-at-wickenburg-ranch")) {
	add[0]="3440 Maverick Dr ";
	
	
}
if(commUrl.contains("find-a-home/dorn-homes-at-tubac/"))
	commName="Tubac";


if(commUrl.contains("https://prescott.dornhomes.com/westwood")) {
	pStatus=pStatus.replace(", Quick Move-in Homes", "");
	commName="Westwood At Deep Well Ranch";
}

if(commUrl.contains("/find-a-home/dorn-homes-at-tubac/"))
	pStatus=pStatus.replace(", Grand Opening", "").replace("Temporarily Sold Out, Closeout, Sold Out", "Temporarily Sold Out, Closeout");
			commName = commName.replace("Golf Resort|golf resort|Coming Soon", "");
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott/westwood")) propType+=", Craftsman Style Homes";
            if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott/westwood/")) propType+=", Farmhouse Style Homes";//image
            if(commUrl.contains("sedonaranchaz.com")){prices[0]="$2,995,000"; prices[1]=ALLOW_BLANK; }
			if(commName.length()>1000)commName = U.getSectionValue(html1, "<title>", "</title>");
			commName = commName.replace("Hillside Coming Soon", "Hillside").replace(" VIP List", "");
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott-valley/ridgeline"))pStatus=ALLOW_BLANK;
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott/saddlewood/"))pStatus="Temporarily Sold Out, Closeout";
			
			if(commUrl.contains("https://prescott.dornhomes.com/madera-estates"))pStatus="Coming Soon";
			if(commUrl.contains("/hillside-coming-soon"))pStatus = pStatus+", Opening 2022";
			//loturl
//			https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community=Westwood&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D
			String updatedName ="";
			if(commUrl.contains("estates-at-wickenburg-ranch/")) {
				updatedName = "Wickenburg Ranch";
			}
			else if(commUrl.contains("/tubac/tubac/")){
				updatedName ="Tubac Golf Resort";
			}else {
				updatedName = commName;
			}
//			String lotMapHtml = U.getHTML("https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community="+updatedName+"&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D");
//			
//			U.log("lot url== "+ "https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community="+updatedName+"&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D");
//			U.getCache("https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community="+updatedName+"&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D");
			
			
			//ju
			String lotIds="";
			String lotId=ALLOW_BLANK;
			if(mHtml.contains("https://americansouthernhomes.lotvue.com")) {
			
			String lotMapHtml = U.getHtml("https://americansouthernhomes.lotvue.com/marketing/"+updatedName,driver);
			U.log(">>>>>>>>>>>>>>"+U.getCache("https://americansouthernhomes.lotvue.com/marketing/"+updatedName));
			
			String[] lotData=U.getValues(lotMapHtml, "<span class=\"legend_text \"", "</div>");
			int lot=0;
			int totallots=0;
			for(String ltData:lotData) {
//				U.log(ltData);
				ltData=U.getNoHtml(ltData);
//				U.log("==="+ltData);
				String lots=Util.match(ltData, "\\(\\s*\\d+\\s*\\)").trim();
				lot=Integer.parseInt(Util.match(lots, "\\d+").trim());
				totallots=totallots+lot;
				U.log("lot Count "+lots);
			}
		
			U.log("total lots= "+totallots);
			
			lotId=Integer.toString(totallots);
//			U.log("lotId= "+lotId);
			    if(lotId.equals("0"))lotId=ALLOW_BLANK;
			}
			
//			if(lotMapHtml!=null)
//			lotIds = Util.matchAll(lotMapHtml, " var svg_lot ", 0).size()>0?Util.matchAll(lotMapHtml, " var svg_lot ", 0).size()+"":ALLOW_BLANK;
//			if(lotIds.length()<1)lotIds=ALLOW_BLANK;
			
			data.addCommunity(commName, commUrl, commType);
			data.addPrice(prices[0], prices[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1], flag);
			data.addUnitCount(lotId);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//	}catch(Exception e){}
	}

//Method not called
	public String getPlanData(String cHtml) throws IOException {

		String allPlanData = ALLOW_BLANK;

		String[] planUrls = U.getValues(cHtml, "<a class=\"image-box\" href=\"", "\"");

		for (String planUrl : planUrls) {
			planUrl = "https://www.dornhomes.com" + planUrl;
			U.log("planUrl:::" + planUrl);
			String planHtml = U.getHTML(planUrl);
			allPlanData = U.getSectionValue(planHtml, "homeDetailBox", "amenityWrapper")
					+ U.getSectionValue(planHtml, " <h3>Plan Amenities &amp; Living Areas</h3>", "</div>")
					+ allPlanData;
			allPlanData = allPlanData.replace(" split floor plan ", "split floor-plan");
		}

		return allPlanData;

	}
//Method not called
	public void getCommDetails(String comUrl) throws Exception {
		{
			comUrl = comUrl.replace("http://www.sedonaranchaz.com", "https://sedonaranchaz.com");
			U.log(j + "======" + comUrl);

			String html1 = U.getHTML(comUrl);
			// removing find your homes section
			html1 = U.removeSectionValue(html1, "<nav", "</nav");
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			// ============= Community Name ==================
			String commName = ALLOW_BLANK;
			commName = U.getSectionValue(html1, "<title>", "</title>").replace("&#8211; On the Banks of Oak Creek", "").replaceAll("Sedona Arizona Luxury Homes for Sale \\|", "");
			U.log("Community Name :" + commName);
			// ===================== Address ========================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec = U.getSectionValue(html1, "<span class=\"fadd\">Sedona Ranch <br>", "</span>");
			//U.log("addSec : " + addSec);
			if (addSec != null) {
				addSec = addSec.replaceAll("<br>", ",");
				add = U.getAddress(addSec);
				add[0] = add[0].trim();
				add[1] = add[1].replace(",", "");
				add[0] = add[0].trim();
				add[2] = add[2].trim();
				add[3] = add[3].trim();
			}
			U.log("Add : " + Arrays.toString(add));

			// =============== LatLng =========================
			String flag = ALLOW_BLANK;
			String note = ALLOW_BLANK;
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String contactUrl = U.getSectionValue(html1, "<h2>Schedule Your Tour Of Sedona Ranch</h2>", "Contact Us");
			//U.log(contactUrl);
			if (contactUrl != null) {
				String contactHtml = U.getHTML(U.getSectionValue(contactUrl, "<a href=\"", "\""));
				String LLSec = U.getSectionValue(contactHtml, "https://www.google.com/maps/dir//", "/@");
				if (LLSec != null) {
				//	U.log(LLSec);
					latlng = LLSec.split(",");
				}
			}
			if (comUrl.contains("https://sedonaranchaz.com")) {
				add[0] = "12 Lagos Court";
				add[1] = "Sedona";
				add[2] = "AZ";
				add[3] = "86351";
				latlng[0] ="34.8179444";
				latlng[1] ="-111.814754";

			}
			
			U.log("LatLng = " + Arrays.toString(latlng));

			//===========Available Home ============
			
			String availHtml = U.getHtml("https://sedonaranchaz.com/sedona-arizona-luxury-homes-for-sale/available-homes/", driver);
			String[] availSec = U.getValues(availHtml, "<a id=\"slider-", "View Details");
			
			String aAvilData = "";
			for(String aSec : availSec) {
				aSec = aSec.replace("href=\"#popmake", "");
				String aUrl = U.getSectionValue(aSec, "href=\"", "\"");
				U.log("Avail Url: "+aUrl);
				if(!aUrl.contains("#pop"))
				aAvilData += U.getHTML(aUrl)+aSec;
			}
			
			
			// ========== Price =====================
			String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
			html1 = html1.replaceAll("0s|0's", "0,000").replace("0K", "0,000");
			prices = U.getPrices(html1+aAvilData, "\\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+", 0);
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;

			// =========== Sqft =====================
			String homeHtml1  = U.getHtml("https://sedonaranchaz.com/sedona-arizona-luxury-homes-for-sale/", driver);
			String homeHtmlSec = U.getSectionValue(html1, "<h2>Our <br> Models</h2>", "</ul");
			String homeHtml = ALLOW_BLANK;
			if (homeHtml1 != null) {
				String homeSites[] = U.getValues(homeHtml1, "gem-button-container gem-button-position-inline", "View Home Plan");
				for (String modelHome : homeSites) {
					String hUrl = U.getSectionValue(modelHome, "href=\"", "\"");
					U.log("Home Url: "+hUrl);
					//U.log(modelHome);
					homeHtml += U.getHTML(hUrl);
				}
			}
			String AvailHome=U.getHTML("https://sedonaranchaz.com/sedona-arizona-luxury-homes-for-sale/available-homes/");
			
			String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
			sqft = U.getSqareFeet(html1 + homeHtml+ aAvilData, " \\d,\\d{3} </rs|approximately \\d,\\d{3} square feet|\\d{4} Sq. Ft.", 0);
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			
			
			// ======== Community Type ====================
			String commType = ALLOW_BLANK;
			commType = U.getCommunityType((html1 + commName).replaceAll("Golf Resort</a>|Tubac Golf Resort</a>", ""));
			U.log("commType: "+commType);

			// ============== Property Type =====================

			String desc = U.getSectionValue(html1, "<p class=\"communityDescription\">",
					"class=\"amenityWrapper communities\">");
			html1 = html1.replace("north of our sold out ", "north of our");
			String pStatus = U.getPropStatus((desc + html1));
			U.log("status :: " + pStatus);
			
			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll(desc + html1, "[\\s\\w\\W]{30}Sold Out[\\s\\w\\W]{30}", 0));
			
			
			if(availHtml.contains("")) {
				if(pStatus.length()>2) {
					if (pStatus.contains("Quick Move")) {
						pStatus+=", Quick Move-In Homes";
					}
				}else
					pStatus="Quick Move-In Homes";
			}
			// ============== Property Type =====================

			String propType = U.getPropType(homeHtml + html1+aAvilData);
			U.log("PropType:::::" + propType);

			// =========== Derived Community Type ====================
			homeHtml = homeHtml.replaceAll("split-living floorplan", "split floor-plan");
			String dType = U.getdCommType((html1 + homeHtml+aAvilData));
			U.log("dtype :: " + dType);

			// ================= Notes =================
  
			note = U.getnote(html1);
			if(comUrl.contains("https://www.dornhomes.com/find-a-home/prescott/saddlewood/"))pStatus="Temporarily Sold Out, Closeout";
			if(comUrl.contains("https://prescott.dornhomes.com/madera-estates"))pStatus="Coming Soon";
			
			data.addCommunity(commName, comUrl, commType);
			data.addPrice(prices[0], prices[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1], flag);

		}

	}
}