/** @ modified by Priti -2017 
 * @author Sanket Patil
 *  @date 16/04/2012 
 */

package com.shatam.b_201_220;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSimmonsHomes extends AbstractScrapper {
	int k = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.simmonshomes.com";
	public static void main(String[] ar) throws Exception {
		

		AbstractScrapper a = new ExtractSimmonsHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Simmons Homes.csv", a.data().printAll());
	}

	public ExtractSimmonsHomes() throws Exception {

		super("Simmons Homes", builderUrl);
		LOGGER = new CommunityLogger("Simmons Homes");
	}
	WebDriver driver = null;
	public void innerProcess() throws Exception {
	//	U.setUpChromePath();
		//driver = new ChromeDriver();
		
		
		U.setUpGeckoPath();
		driver= new FirefoxDriver();
		
		
		String html=U.getHtml("https://www.simmonshomes.com/communities", driver);
		
		
		String comSec1[]=U.getValues(html,"<li class=\"result ng-scope ng-isolate-scope\"","</div> </li>");
		U.log("Total :: "+comSec1.length);
		for(String cSec:comSec1)
		{
			//U.log(":::::::::::::::::::::::::"+cSec);
			
			addDetails(cSec);
			j++;
			//break;
		}
		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	//TODO ::
	private void addDetails(String comSec) throws Exception {
//	if(j >= 8)
//		try{
		{
		String notevar = ALLOW_BLANK;
		//U.log(comSec);
		String comUrl=builderUrl+U.getSectionValue(comSec, "href=\"", "\"");
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"****************repeated*************");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//============= Run =======================================================================
//		if(!comUrl.contains("https://www.simmonshomes.com/communities/glenpool/glenn-hills"))return;
		
		U.log(j+" Community Url:"+comUrl);
		U.log(U.getCache(comUrl));
		String html1=U.getHtml(comUrl,driver);
		String comName=U.getSectionValue(comSec,"class=\"ng-binding\">", "</a>").trim();
		U.log("Community Name:"+comName);

		//------------Addresses---------------------
		String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addr=U.getSectionValue(html1, "community.homes | filter:isModel | limitTo: 1 -->", "</p>");
		U.log("Address :"+addr);
		if (addr!=null) {
			addr=addr.replaceAll("<br />\\s*PH \\(\\d+\\) \\d+ - \\d+", "").replace("&amp;", "&");
		}
//		U.log("Address =:"+addr);
		if(addr.contains("<span") && addr.contains(" -->")){
			String rem = U.getSectionValue(addr, "<span ng", " -->");
//			U.log("Remove =="+rem);
			if(rem != null) addr = addr.replace(rem, "");
		}

		
		addr=addr.replaceAll("<br />PH|<br>PH", "").replaceAll("<br />|<br>", ",")
				.replaceAll("Conveniently Located In|Conveniently Located in|<span ng -->| \\(\\d+\\) \\d+ - \\d+ ", "");
			
		U.log("Address 1:"+addr);
		String tempAdd[] =addr.split(",");
		if(tempAdd.length==3){
			add[0] = tempAdd[0].trim();
			add[1] = tempAdd[1].trim();
			add[2] = Util.match(tempAdd[2], "\\w+");		
			add[3] =Util.match(tempAdd[2], "\\d+");		
		}
		
		U.log("street:"+add[0]+"\n"+"city:"+add[1]+"\n"+"state:"+add[2]+"\n"+"zip:"+add[3]);
		
		//-----------------latLng---------------------
		String geo="FALSE";
		String latsec=U.getSectionValue(html1, "center=\"[", "]\"");
		String latLng[]={ALLOW_BLANK,ALLOW_BLANK};
		if (latsec!=null) {
			latLng=latsec.split(",");
			U.log("lat :"+latLng[0]+"lng :"+latLng[1]);
			geo="FALSE";
		}
		
		
		if(latLng[0]==ALLOW_BLANK||latsec==null) {
			latsec=U.getSectionValue(html1, "href=\"https://www.google.com/maps/", "\"").replace("%2C+",",");
			latLng[0]=U.getSectionValue(latsec,"destination=", ",");
			latLng[1]=Util.match(latsec, "\\-\\d+.\\d+");
		}//jjune
		
		
		U.log("MMM>>>>>>>>>>>>>"+Arrays.toString(latLng));
		if(comUrl.contains("https://www.simmonshomes.com/communities/collinsville/stone-lake")) {
		add=U.getAddressGoogleApi(latLng);
		U.log(">>>>>>>>>>>>>"+Arrays.toString(add));
		geo="TRUE";
		notevar="Address is taken from latlong";
		}
		add[0]=add[0].replaceAll("By Appointment|Coming Soon to|Conveniently Located In|Model Under Construction|Located at Southern Reserve Model Home", ALLOW_BLANK).replaceAll("\\(BY APPOINTMENT\\)", "");
		if (add[0].length()<4 && latsec==null) {
			U.log(">>>>>>>>>>>>>.."+Arrays.toString(add));
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			
			notevar="Address and Lat Long Are Taken From City And State";
		}
		U.log(latsec+"=====================>"+add[0]);
		if(add[0]==ALLOW_BLANK||add[0].trim().length()<4)
		{
			U.log("---------------------->");
			String[] aaddr=U.getAddressGoogleApi(latLng);
			if(aaddr == null) aaddr = U.getAddressHereApi(latLng);				
			add[0]=aaddr[0];
			geo="TRUE";
		}
		
		add[0]=add[0].trim().replace("Coming Soon", ALLOW_BLANK);
		if(add[1].length()<4){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);		
			geo="TRUE";
		}
		if(latLng[0].length()<4 && add[0].length()>4){
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo = "TRUE";
		}
		
		//----------------MinMax Price--------------------
				String min=ALLOW_BLANK;
				String max=ALLOW_BLANK;
				String remove = U.getSectionValue(html1, "<div class=\"homes-filter-bar\">", "</ul>");
				if(remove != null) html1 = html1.replace(remove, "");
				
				html1 =html1.replaceAll("ng-pristine ng-untouched ng-valid ng-empty\" />\\s*\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\\s*</div>", "");
				html1 = html1.replaceAll("0's|0s|0s", "0,000");
				String priceSec[]=U.getPrices(html1, "ng-scope\">\\$\\d{3},\\d{3}</h5>|low \\$[0-9]{3},[0-9]{3}|Priced from: \\$\\d+,\\d+|Priced from: &#36;\\d,\\d+,\\d+|from the \\$\\d{3},\\d{3}|\\$\\d+,\\d+", 0);
				min = (priceSec[0] == null) ? ALLOW_BLANK : priceSec[0];
				max = (priceSec[1] == null) ? ALLOW_BLANK : priceSec[1];
				U.log("MinPrice :"+min+"maxPrice :"+max);
				
		//------------------Sqft----------------------
				String minSq=ALLOW_BLANK;
				String maxSq=ALLOW_BLANK;
				String squareSec[]=U.getSqareFeet(html1+comSec, 
						"ranging from \\d,\\d{3} - \\d,\\d{3} square feet|plans starting from \\d,\\d{3} sq. ft.|than \\d{4} sqft|\\d,\\d{3} -  SQ FT|\\d,\\d{3} - \\d,\\d{3} SQ FT|ng-binding\">\\d,\\d{3}</span><br />Sqft</div>|Home Size\\?</span><br />\\d,\\d{3} - \\d,\\d{3} SQ FT</p>|>\\d,\\d+ <|> \\d,\\d+<|SQ FT: \\d,\\d+|\\d{4} sqft", 0);//(floorHtml,"SQ FT:","</h5>");
				minSq = (squareSec[0] == null) ? ALLOW_BLANK : squareSec[0];
				maxSq = (squareSec[1] == null) ? ALLOW_BLANK : squareSec[1];
				U.log("MinSq :"+minSq+"maxSq :"+maxSq);
				
		String rem=U.getSectionValue(html1, "Find Your Home</a>","Floor Plans</a>");
		String rem1=U.getSectionValue(html1, "footer_text_row","</body>");
		if(rem==null)
			rem=ALLOW_BLANK;
		if(rem1==null)
			rem1=ALLOW_BLANK;
		String statusHtml=html1.replace(rem, "");
		statusHtml=statusHtml.replace(rem1, "")+U.getSectionValue(html1, "<div class=\"detail-page-description-row\">", "<!-- end ngIf: community.community_body_copy -->");
	

		
		//-----------------Property Type and Derived Property Type-------------------
		//---------fetchinh individual plan data-----------------
		String allFloorPlanData="";
		String floorPlanSec=U.getSectionValue(html1, "Community Floor Plans", "</section");
		if (floorPlanSec!=null) {
			String[] plansPlanUrl=U.getValues(floorPlanSec, "plan in plansFiltered = (community.plans  | filter:filterCheckbox | orderBy:order_field_plans)", "</li>");
			U.log("Total floor plans :: "+plansPlanUrl.length);
			for(String planurl:plansPlanUrl)
			{
				planurl=U.getSectionValue(planurl, "ref=\"", "\"");
//				U.log("planurl::"+builderUrl+planurl);
				String htmlp=U.getHtml(builderUrl+planurl,driver);
				allFloorPlanData += U.getSectionValue(htmlp, "<div class=\"inside-header ng-scope\">", "<h3>Elevations</h3>");
			}
		}
		
		//---------fetching individual quick homes data-----------------
		String allQuickHomeData = ALLOW_BLANK;
		String quickSec=U.getSectionValue(html1, "<!-- ngIf: community.homes.length == 0 -->", "</section");
		int soldCount = 0;
		int quickCount =0;
		if (quickSec!=null) {
			
		String[] quickUrls = U.getValues(quickSec, " <div class=\"result-info-group\"> <a ", "View Home Details");
		U.log("Total quick Home :: "+quickUrls.length);
		for(String quickUrl : quickUrls){
			if(quickUrl.contains("Status <span class=\"ng-binding\">Sold</span>"))
				soldCount =soldCount+1;
			quickUrl=U.getSectionValue(quickUrl, "ref=\"", "\"");
//			U.log("quickUrl :: "+builderUrl+quickUrl);
			String myQuickHtml = U.getHtml(builderUrl+quickUrl,driver);
			if (myQuickHtml.contains("Traditional")) {
				U.log("FOUND");
			}
			quickCount++;
			//myQuickHtml = U.removeComments(myQuickHtml);
			allQuickHomeData += U.getSectionValue(myQuickHtml, "Home Description</h3>", "class=\"detail-page-home");
//			U.log(U.getSectionValue(myQuickHtml, "Home Description</h3>", "class=\"detail-page-homes-section"));
			//U.log(allQuickHomeData);
		}
		}
		allQuickHomeData = allQuickHomeData.replaceAll("The Villas of Spring Creek|village", "").replace("split floor plan", "split levels");
		html1=html1.replace("craftsman charm or farmhouse edge", "craftsman charm or farmhouse style homes edge")
				.replaceAll("Community: White Hawk Golf Villas|energy efficient single family|energy efficient single family", "");
		allFloorPlanData=allFloorPlanData.replaceAll("energy efficient single family|energy efficient single family|villa|Villa|Traditional and Classic\"", "");
		statusHtml=statusHtml.replaceAll("Community: White Hawk Golf Villas|energy efficient single family|energy efficient single family", "");
//		U.log(html1);
		
		allFloorPlanData = allFloorPlanData.replaceAll("<div ng-repeat=\"photo in plan.elevationPhotos\".* Traditional</span>|Drake Traditional|_traditional.jpg|_traditional_", "");
		String pType =U.getPropType((statusHtml+html1+comName+allQuickHomeData+allFloorPlanData)
				.replaceAll("Bungalows in Bixby|Morrow Home Place|row homes\"", ""));
//		U.log("pType==="+comName);

		U.log("pType==="+pType);
		
		String dpType = U.getdCommType((statusHtml+allFloorPlanData+allQuickHomeData+html1).replaceAll("Floor|floor", "").replace("single story home features", "1 story"));
		U.log("dpType==="+dpType);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(statusHtml+html1+comName+allQuickHomeData+allFloorPlanData, "[\\s\\w\\W]{30}two-story[\\s\\w\\W]{30}", 0));
		
		//------------------propertyStatus------------------------------
		//View move-in ready new homes and available lots in Morrow, a community in Owasso, Oklahoma by Tulsa area new home builder, Simmons Homes
		html1=html1.replace("HOMESITE RELEASE: NEW PHASE NOW OPEN", "HOMESITE RELEASE NEW PHASE NOW OPEN")
				.replaceAll("NEW PHASE OPENING FALL 2021!", "")//.replace("New Phase Under Development - Coming 2022", "NEW PHASE COMING 2022")
				.replace("new phase, opening this Summer", "new phase opening Summer")
				.replace("New Phase Under Development - Coming 2022", "New Phase Coming 2022")
				.replace("new phase, opening this Fall", "new phase opening this Fall")
				.replace("final opportunities in our first phase", "final opportunities in first phase")
				.replace("New Phase Under Development - Coming Late 2022", "New Phase Coming Late 2022")
				.replaceAll("and the Grand Opening is planned for the|NEW PHASE OPENING FALL 2021|pdates on our Grand Opening|\\(coming soon!\\)|'Coming  Soon'|Tours Now Available|Quick Move-In <|> Coming Soon|'Coming Soon'|>COMING SOON:</li>|COMING SOON! Community Pool &amp; Playground|Quick Move-In</a>|Quick Move-In Homes</a>|View move-in ready new homes and available lots in| now available to tour by appointment| homesites are selling fast| Limited opportunities remain!&nbsp;Please|New Homes Available Now|Move-In Ready|com/move-in-ready-homes\" class=|Move-In Ready Homes</a></div>|<a href=\"/move-in-ready-homes\">Quick Delivery Homes</a></li>|<li>COMING SOON:</li>|and coming soon a neighborhood|Model Under Construction|Neighborhood Pool - Coming Soon|Playground - Coming Soon|Coming Soon,  Broken| Coming Soon<br />|Quick Delivery Homes|layout is coming soon|PHASE OPEN FOR RESERVATIO", "");

//		 if(comUrl.contains("www.simmonshomes.com/communities/bixby/willow-creek-bungalows"))
//			 html1=html1.replace(">New Phase Coming Soon, Fall 2022!</h6>", "");


		String pstatus=ALLOW_BLANK;
		 pstatus=U.getPropStatus(html1
				 .replace("Coming Soon! Join the VIP List!</h6>", "")
				 .replace("Final Phase 1 Quick-Move-In Home Available Now!", "")
				 .replaceAll("New Phase Coming Soon, Fall 2022|NEW PHASE COMING SOON, FALL 2022","NEW PHASE COMING SOON FALL 2022")
				 .replace("New Phase coming soon in early Fall 2022", "New Phase coming soon early Fall 2022")
				 .replaceAll("New Phase Under Development|This final phase will be sold-out before you know it|quick-move-in|VIP list for our new phase opening Summer|=\"center\">\\s*Quick Move-In", ""));
		 U.log("==========="+pstatus);
		 U.log(quickCount+"@@@@@@@"+soldCount);
		 U.log(":::::::::::::::::"+Util.matchAll(html1, "[\\w\\s\\W]{30}Final phase[\\w\\s\\W]{30}",0));
		
//		 if(comUrl.contains("https://www.simmonshomes.com/communities/glenpool/glenn-hills"))pstatus="First Phase Final Opportunity, New Phase Coming Soon";
		 if (allQuickHomeData.length()>100 && !pstatus.contains("Quick") && quickCount>soldCount) {
			 if (pstatus.length()>1) {
				pstatus+=", Quick Move-In";
			}else {
				pstatus="Quick Move-In";
			}
		}
		 
		
		comName=comName.replaceAll("Golf Villas Overview|Villas Overview| &#8211; CareFree Homes|Overview", "");
		if (notevar!=ALLOW_BLANK) {
			String n=U.getnote(html1);
			if (n!=ALLOW_BLANK) {
				notevar+=", "+n;
			}	
		}else {
			notevar=U.getnote(html1);
		}
		
		
		
		 String ctype = U.getCommunityType(statusHtml.replace("resortstyle amenities", "resort-style amenities"));
		 //U.log(":::::::::::::::::"+Util.matchAll(statusHtml, "[\\w\\s\\W]{30}two-story[\\w\\s\\W]{30}",0));
			
		pstatus = pstatus.replace("New Phase Coming Fall 2022, New Phase Coming Soon", "New Phase Coming Fall 2022").replace("Opening Spring 2021, New Phase Open", "Opening Spring 2021")
				.replace("New Phase Coming, Coming This Spring", "New Phase Coming This Spring")
				.replace("Opening This Summer, Final Opportunities, New Phase Opening Summer 2021, New Phase Open", "Final Opportunities, New Phase Opening Summer 2021").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		
		//geo="TRUE";
		
		pstatus = pstatus.replace("New Phase Opening Summer 2021, New Phase Opening Summer", "New Phase Opening Summer 2021")
				.replace("New Phase Coming 2021, New Phase, Coming 2021", "New Phase Coming 2021")
				.replace("New Phase, New Phase Now Open", "New Phase Now Open").replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
	
		
	if(pstatus.contains("Coming 2022") && pstatus.contains("New Phase Coming 2022")) {
		pstatus=pstatus.replace("Coming 2022, ", "");
	}
		
	 if(comUrl.contains("simmonshomes.com/communities/owasso/magnolia-ridge"))
		 pstatus=pstatus.replace("New Phase, Now Selling", "New Phase Now Selling");
//	 if(comUrl.contains("simmonshomes.com/communities/owasso/vintage-oaks"))
//		 pstatus="New Phase Coming 2022, Final Phase";
	
	 pstatus=pstatus.replace("New Phase Now Open, Now Open", "New Phase Now Open");
		data.addCommunity(comName.replace("Bungalows", ""), comUrl, ctype);
		data.addAddress(add[0].replace(".", ""), add[1], add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(pType, dpType);
		data.addPropertyStatus(pstatus.replace("New Phase Coming 2021, Coming 2021", " New Phase Coming 2021"));
		data.addPrice(min,max);
		data.addSquareFeet(minSq, maxSq);
		data.addNotes(notevar);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
//		}catch (Exception e) {
			// TODO: handle exception
//		}
}
}
	
