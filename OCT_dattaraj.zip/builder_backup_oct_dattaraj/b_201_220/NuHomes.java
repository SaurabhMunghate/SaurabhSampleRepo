package com.shatam.b_201_220;

import java.util.Arrays;

import org.jsoup.parser.ParseError;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class NuHomes extends AbstractScrapper {

	public NuHomes() throws Exception {
		super("Nu Homes Oklahoma", "https://www.nuhomesoklahoma.com");
		LOGGER = new CommunityLogger("Nu Homes Oklahoma");
		// TODO Auto-generated constructor stub
	}

//4cornerhomes
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new NuHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Nu Homes Oklahoma.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainhtml = U.getHTML("https://www.nuhomesoklahoma.com/communities");
		String comSections[] = U.getValues(mainhtml, "class=\"CommunityCard_media\"",
				"<div class=\"CommunityCard_detailButton\"");
		U.log(comSections.length);
		for (String comSec : comSections) {
			String comUrl = "https://www.nuhomesoklahoma.com"
					+ U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");

			U.log(comUrl);
//			try {
				addDetails(comUrl);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comUrl) throws Exception {

//		if(!comUrl.contains("https://www.nuhomesoklahoma.com/communities/jones/cordillera-ranch")) return;
		
		
		String commHtml = U.getHTML(comUrl);

		String communityName = ALLOW_BLANK;

		communityName = U.getSectionValue(commHtml, "<h2 class=\"DetailOverview_heading\"",
				"<span class=\"DetailOverview_subheading\"");
		communityName = communityName
				.replaceAll("data-reactid=\"\\d{3}\"><!-- react-text: \\d{3} -->|<!-- /react-text -->", "");
		
		if(communityName.contains("Ranch")) {
			
			communityName = communityName.replaceAll(" Ranch$", "");
		}
		
		U.log(communityName);

		// ==================commdescribtion
		String commdesc = U.getSectionValue(commHtml, "name=\"description\"", "<link rel=\"manifest\"")+U.getSectionValue(commHtml, ">Description</h3>", "Site Map</h3>");;

		// =============community address
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";

		String addresssection = U.getSectionValue(commHtml, "<span class=\"DetailOverview_subheading\"",
				"</span></h2>");
		addresssection = addresssection.replaceAll(
				"Highland Meadows|data-reactid=\"\\d{3}\"><!-- react-text: \\d{3} -->|<!-- /react-text -->|<!-- react-text: \\d{3} -->",
				"");
		U.log(addresssection);

		String address[] = addresssection.split("[|,]");
		U.log(Arrays.toString(address));
		U.log(address.length);
		add[0] = address[0];
		add[1] = address[1];

		// String address2[]=add[2].split("[ ]");
		// U.log(Arrays.toString(address2));
		// U.log(address2.length);
		add[2] = "OK";
		add[3] = Util.match(addresssection, "\\d{5}").replace("10597", "73049");
		U.log(Arrays.toString(add));

		U.log(address.length);

		String latlongsection = U.getSectionValue(commHtml, "<a href=\"https://www.google.com/maps/place/", "/@");
		latLong = latlongsection.split(",");

		U.log(Arrays.toString(latLong));

		if (add[1] != ALLOW_BLANK && latLong[0] == ALLOW_BLANK) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong == null)
				latLong = U.getlatlongHereApi(add);
			// latlag=U.getBingLatLong(add);

			geo = "TRUE";
		}
		if ((add[0].length() < 2 || add[2] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if ((add[0].trim().length() < 3 || add[0] == null) && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add == null)
				add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[3] == null && latLong[0] != ALLOW_BLANK) {
			String[] add1 = U.getAddressGoogleApi(latLong);
			if (add1 == null)
				add1 = U.getAddressHereApi(latLong);

			add[3] = add1[3];
			add1 = null;
			geo = "TRUE";
		}
		if (add[2].length() < 2) {
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
		}

		U.log("GEO: " + geo);

		/// avaialable hoem plans section

		String availfloorplans = comUrl + "#plans";
		String availhtml = "";
		String avasec = "";
		availhtml = U.getHTML(availfloorplans);
		String availhomehtml = "";
		String availdesc = "",storysection="";
		String availplans[] = U.getValues(availhtml, "<div class=\"PlanCard_media\"", "<div class=\"PlanCard_inner\"");
		// String floorplandesc=U.getSectionValue(availhtml,
		U.log("====="+availplans.length);
		// "pdf\"},\"description\":\"", "\"garages\"");
		for (String availplansec : availplans) {
		//	U.log("Plan: "+"https://www.nuhomesoklahoma.com/" + U.getSectionValue(availplansec, "href=\"/", "\""));
			availhomehtml = U
					.getHTML("https://www.nuhomesoklahoma.com/" + U.getSectionValue(availplansec, "href=\"/", "\""));

			storysection += U.getSectionValue(availhomehtml, "<div class=\"DetailOverview_headingWrapper\"", "Download Brochure");
			availdesc += U.getSectionValue(availhomehtml,  "Description</h3>", "Elevations</h3>");
			avasec += availplansec;

		}

		//// quick move in homes
		int homesCount = 0;
		
		String quickurls = comUrl + "#homes";
		String quickhtml = U.getHTML(quickurls);
		String quicsecdet = "", quickdesc="",quickStorySec="";
		String quickhomehtml = "";
		String quicksections[] = U.getValues(quickhtml, "<div class=\"HomeCard_wrapper\" ",
				"</div></div></div></div>");
		U.log("quick move ins: ====="+quicksections.length);
		for (String qu : quicksections) {
			
		//	U.log(qu);
		//	String quicurl= 
	//		U.log("====="+U.getSectionValue(qu, "href=\"", "\""));
			
			//for taking quick status from homes. Removing Sold and Under Construction
			if(qu.contains("Under Construction") || qu.contains("Sold")) {
				
			}
			else {
				homesCount++;
			}
			
			U.log("quickUrl: "+"https://www.nuhomesoklahoma.com" +U.getSectionValue(qu, "href=\"", "\""));
			quickhomehtml = U.getHTML("https://www.nuhomesoklahoma.com" +U.getSectionValue(qu, "href=\"", "\""));
			
			quickStorySec+=U.getSectionValue(quickhomehtml, "<h2 class=\"DetailOverview_heading\"", "<span class=\"DetailOverview_sectionItem\"");
			quickdesc+=U.getSectionValue(quickhomehtml, "Description</h3>", "Floor Plan</h3>");
			quicsecdet += qu;
		}
		
		U.log("homesCount: ====="+homesCount);
		
		/// prices

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK;
		String maxPrice = ALLOW_BLANK;

		prices = U.getPrices((commdesc + avasec + quicsecdet).replaceAll("0s", "0,000"), "starting in the \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}<", 0);

		minPrice = prices[0];
		maxPrice = prices[1];

		U.log(Arrays.toString(prices));

		// ======================sqft

		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String minsqft = ALLOW_BLANK;
		String maxsqft = ALLOW_BLANK;

		
		sqft = U.getSqareFeet(commdesc + avasec + availdesc + quicsecdet + quickdesc, "\">\\d{1},\\d{3}<|over \\d,\\d{3}\\+ square feet", 0);

		minsqft = sqft[0];
		maxsqft = sqft[1];

		U.log(Arrays.toString(sqft));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commdesc + avasec + availdesc + quicsecdet + quickdesc, "[\\s\\w\\W]{30}2,300[\\s\\w\\W]{30}", 0));

		// communtiyg type
		String commtype = U.getCommunityType(commdesc);
		U.log(commtype);

//		if(availdesc!=null)
//			availdesc = availdesc.replace("perfect luxury home", "perfect luxury homes ");
		
		String ptype = U.getPropType((commdesc + availdesc + quickdesc).replace("Each estate will", "Estate Residences"));
		U.log(ptype);

		//U.log(Util.matchAll(commdesc + availdesc + quickdesc, "[\\s\\w\\W]{30}estate[\\s\\w\\W]{30}", 0));

		storysection=storysection.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">1</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "1 Story")
				.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">2</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "2 Story")
				.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">3</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "3 Story");
		
		
		quickStorySec=quickStorySec.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">1</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "1 Story")
				.replaceAll("<span class=\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">2</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "2 Story")
				.replaceAll("<span class=\\\"DetailOverview_listItemValue\" data-reactid=\"\\d{3}\">3</span><span class=\"DetailOverview_listItemLabel\" data-reactid=\"\\d{3}\">Stories", "3 Story");
		String dtype = U.getdCommType(storysection+commdesc+quickStorySec);
		U.log(dtype);
 
		String quickmoveinsection="";
		String comDetailSec=""	;	
		try {
			quickmoveinsection=U.getSectionValue(commHtml, "<span class=\"DetailOverview_sectionItem DetailOverview_sectionItem-count\"", "</a></span></div>");
		//quickmoveinsection=quickmoveinsection.replaceAll("<!-- /react-text --><span class=\"badge\" data-reactid=\"\\d{3}\">", "");
		//U.log(quickmoveinsection);
			comDetailSec = U.getSectionValue(commHtml, ">Description</h3>", "Site Map</h3>");
		}
		catch(NullPointerException ne ) {
			
		}
		if(comDetailSec!=null)comDetailSec= comDetailSec.replace("Nu Homes is now selling homes", "");//.replace("Availability is limited!", "Limited Availability")
		commdesc=commdesc.replace("Nu Homes is now selling homes", "");
		
		String pstatus = U.getPropStatus((commdesc+quickmoveinsection+comDetailSec).replace("Quick Move-In Homes", ""));
		
		
		if(homesCount > 0) {
			if(pstatus == ALLOW_BLANK)
				pstatus = "Quick Move-In Homes";
			else if(pstatus != ALLOW_BLANK)
				pstatus = pstatus + ", Quick Move-In Homes";	
			}

		U.log("pstatus: "+pstatus);
//		U.log(Util.matchAll(commdesc+quickmoveinsection, "[\\w\\s\\W]{30}Quick Move-in Homes[\\w\\s\\W]{30}", 0));
		
		note = U.getnote(commHtml);
		if (maxPrice == null)
			maxPrice = ALLOW_BLANK;
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "*************repeated************");

			return;
		}
		if(comUrl.contains("https://www.nuhomesoklahoma.com/communities/moore/timberline"))ptype+=", Luxury Homes";
		String json = U.getSectionValue(commHtml, "window.__PRELOADED_STATE__ = ", "</script>");
		JsonParser parser = new JsonParser();
		JsonObject jobject = (JsonObject)parser.parse(json);
		JsonArray jarray = jobject.get("cloudData").getAsJsonObject().get("communities").getAsJsonObject().get("5f0872d04db0486522f3f518").getAsJsonObject().get("data").getAsJsonArray();
		String platMapUrl = "";
		int lotsSize =0;
		for(JsonElement ele :jarray) {
			JsonObject joJsonObject =(JsonObject)ele;
			//U.log(joJsonObject);
			if(joJsonObject.isJsonNull())continue;
//			U.log(joJsonObject.get("name").getAsString()+":"+communityName);
			if(joJsonObject.get("name").getAsString().trim().contains(communityName.trim()) && joJsonObject.toString().contains("zplaturl")) {
				platMapUrl = joJsonObject.get("zplaturl").toString();
				if(platMapUrl!=null) {
					String comId = U.getSectionValue(platMapUrl, "com=", "&nocache=");
					U.log(comId);
					String platMapHtml = U.getPageSource("https://api.mybuildercloud.com/api/v1/communities?where={%22_id%22:%22"+comId+"%22}");
					JsonObject platJson = (JsonObject)parser.parse(platMapHtml);
					JsonArray platjarray = (JsonArray)platJson.get("_items").getAsJsonArray();
					for(JsonElement platele: platjarray) {
						JsonObject obj = (JsonObject)platele;
						//U.log(obj);
						if((obj.toString()).contains("geoJSON"))
							lotsSize = obj.get("zPlatMap").getAsJsonObject().get("geoJSON").getAsJsonArray().size();
					}
				}
//				U.log();
			}
		}
		U.log("lotSize: "+lotsSize);
		String lotIds = lotsSize>0?lotsSize+"":ALLOW_BLANK;
		LOGGER.AddCommunityUrl(comUrl);
		data.addCommunity(communityName, comUrl, commtype);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("&amp;", " & "), add[1], add[2], add[3]);
		data.addSquareFeet(minsqft, maxsqft);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);		
	}

}