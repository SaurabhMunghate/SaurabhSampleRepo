/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.IOException;
import java.util.Arrays;

import org.apache.regexp.recompile;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractClassicaHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractClassicaHomes()
			throws Exception {
		super("Classica Homes","https://www.classicahomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Classica Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractClassicaHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Classica Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	} 

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.classicahomes.com/new-homes/communities");
		String[] comSec=U.getValues(mainHtml, "<div class=\"MoreHomesBox","data-toggle=\"modal");
		for(String comData:comSec)
		{
			String comUrl="https://www.classicahomes.com"+U.getSectionValue(comData, "<a href=\"","\"");
			if(U.getSectionValue(comData, "<a href=\"","\"")==null) {
				comUrl="https://www.classicahomes.com"+U.getSectionValue(comData, "href='","'");
			}
			//U.log(comUrl);
			addDetails(comUrl,comData);
			//break;
		}
		//addDetails("http://www.classicahomes.com/communities/ChevalMeadows/","<b>Cheval</b> low $500's to Mid $700's  </a>near</em>13620 Castleford Dr, Mint Hill, NC 28227 </div>");
		U.log(comSec.length);
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//		try{
		{
		
//		if(!comUrl.contains("https://www.classicahomes.com/new-homes/Communities/Charlotte-NC/Huntersville-Lake-Norman/Torance")) return;
			
			if(data.communityUrlExists(comUrl))
			{
			LOGGER.AddCommunityUrl(comUrl+"========>Repeated");
			k++;
			return;
			}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"   commUrl-->"+comUrl);
		if(comUrl.contains("https://www.classicahomes.com/emailsignup") || comUrl.contains("https://www.classicahomes.comnull"))return;
		String html=U.getHTML(comUrl);
		String comHtml = html;
		
		U.log(U.getCache(comUrl));	
		
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "TextBlue\">","<");
		if(communityName != null && communityName.contains("-")){
			communityName = communityName.replaceAll(" - (.*?)$", "").trim();
		}
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String note="";
		html = html.replaceAll("Preselling.jpg|title=\"Huntson Reserve - Now Preselling", "");
		note=U.getnote(html);
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		
		String addSec=U.getSectionValue(html, "<p class=\"TextCaption TextGrey\">","<br /><br />");
//		U.log("addSec :  "+addSec);
		
		if(comUrl.contains("/Communities/Charlotte-NC/South-Charlotte/Livingston-Drive") ||
				comUrl.contains("/Communities/Charlotte-NC/Cornelius-Lake-Norman/The-Reserve-At-Washam-Potts")) {
			
			addSec=U.getSectionValue(html, "<p class=\"TextCaption TextGrey\">","</p>");
		}
		
		
		if(addSec==null && comHtml.contains("<p class=\"txtBold_SansSerif\">")) {
			addSec=U.getSectionValue(comHtml, "<p class=\"txtBold_SansSerif\">","</p>").replace("<br />", ", ");
			U.log("addSecOne ::  "+addSec);
		}
		String addSec2=U.getSectionValue(comHtml, "<span class=\"txtBold\">Oak Farm</span><br>", "</p>");
		 if(addSec2!=null && addSec==null) {
			 addSec=addSec2.replace("<br>", ", ");
			 U.log("addSecTwo :: "+addSec);
		 }
		
		if(addSec!=null && addSec.contains(","))
		{
			addSec=addSec.replace("Fort Mill Southern Bypass, ", "");
//			addSec=U.getNoHtml(addSec);
			//.replace("2026 Thatcher Way", "2026 Thatcher Way,");
				add=U.getAddress(addSec);				
				U.log("Address is :: "+Arrays.toString(add));
				U.log("Geocode is :: "+geo);
		}

//--------------------------------------------------latlng----------------------------------------------------------------
		
		String latSec=U.getSectionValue(comData, "https://www.google.com/maps?q=loc:","')");
		
		U.log("------------------------->"+latSec);
		if(latSec!=null)
		{
			latlag[0]=Util.match(latSec, "\\d{2,3}[.]\\d{4,}");
			latlag[1]=Util.match(latSec, "-\\d{2,3}[.]\\d{4,}");
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		U.log("Geocode: "+geo);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==null)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
			U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		}
		
		
//-----------Model Homes Data--------------
		int quickCount = 0;
		String allModelHomesData = ALLOW_BLANK;
		String[] modelUrls = U.getValues(html, "<div class='MoreHomesBox'><a href='", "'>");
		U.log("Total Model Homes : "+modelUrls.length);
		for(String modelUrl : modelUrls){
			try {
			U.log("modelUrl : "+modelUrl);
			if(!modelUrl.contains("floorplan"))
				quickCount++;
			String modelHtml = U.getHTML("http://www.classicahomes.com"+modelUrl);
			allModelHomesData += U.getSectionValue(modelHtml, "<div class=\"details\">", "<div id=\"VirtualTour");}
			catch(Exception e) {}
		}
		//U.log(allModelHomesData);
		
//----Floor and Quick homes data---------
		String allFlrQuckHomeData = ALLOW_BLANK;
		String[] flrQuckUrls = U.getValues(html, "<div class=\"owl-carousel owl-theme\">", "<img "); 
		U.log("total flrQuckUrls : "+flrQuckUrls.length);
		
		
		for(String flrQuckUrl : flrQuckUrls){
			try {
				flrQuckUrl = U.getSectionValue(flrQuckUrl, "<a href='", "'");
				U.log("flrQuckUrl : "+flrQuckUrl);
				
				if(!flrQuckUrl.contains("floorplan"))
					quickCount++;
				String flrQuckHtml = U.getHTML("https://www.classicahomes.com"+flrQuckUrl);
				
				String rm = U.getSectionValue(flrQuckHtml, "div id=\"galleria", "<script");
				flrQuckHtml = flrQuckHtml.replace(rm, "");
				if(flrQuckUrl.contains("floorplans")){
				//	U.log("floor");
					allFlrQuckHomeData += U.getSectionValue(flrQuckHtml, "<div class=\"details\">", "<div id=\"VirtualTour");
				}
				if(flrQuckUrl.contains("for-sale")){
				//	U.log("quick");
					allFlrQuckHomeData += U.getSectionValue(flrQuckHtml, "<div id=\"details\" class=\"section FixedWidth\" >", "<div class=\"Right\">"); 
				}
			}
			catch(Exception e) {}

		}
		
		String Secction = U.getSectionValue(html, "<p class=\"SectionTitle TextWhite\">Quick Move-in Homes</p>", "</script>");
		U.log(Secction);
		if(Secction == null)Secction = "";
		String[] QuckUrls = U.getValues(html, "<div class=\"item\">", "<img "); 
		U.log("total QuckUrls : "+QuckUrls.length);
		
		
		for(String QuckUrl : QuckUrls){
			try {
				
				if(QuckUrl.contains("floorplan")) continue;
				QuckUrl = U.getSectionValue(QuckUrl, "<a href='", "'");
				U.log("QuckUrl : "+QuckUrl);
				
				if(!QuckUrl.contains("floorplan"))
					quickCount++;
				String QuckHtml = U.getHTML("https://www.classicahomes.com"+QuckUrl);
				
				String rm = U.getSectionValue(QuckHtml, "div id=\"galleria", "<script");
				QuckHtml = QuckHtml.replace(rm, "");
				if(QuckUrl.contains("floorplans")){
				//	U.log("floor");
					allFlrQuckHomeData += U.getSectionValue(QuckHtml, "<div class=\"details\">", "<div id=\"VirtualTour");
				}
				if(QuckUrl.contains("for-sale")){
				//	U.log("quick");
					allFlrQuckHomeData += U.getSectionValue(QuckHtml, "<div id=\"details\" class=\"section FixedWidth\" >", "<div class=\"Right\">"); 
				}
			}
			catch(Exception e) {}

		}
//============================================Price and SQ.FT======================================================================
		
	
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		
		html=html.replace("$800&#39;s-$1M&#39;s", "$800,000-$1,000,000").replace("$790&#39;s-$1M&#39;s", "$790,000-$1,000,000").replace(" starting in the $80,000s", "starting in the $80,000").replace("0&#39;s","0,000").replace("1&#39;s", "1,000").replace("&#39;s", ",000")
				.replace("Pricing: $770&#39;s - $1M&#39;s", "Pricing $770,000 - $1,000,000")
				.replace("$590&#39;s-$750&#39;s", "$590,000-$750,000").replace("LtBlueBG\">$1.2M-$1.3M</td>", "LtBlueBG\">$1,200,000-$1,300,000</td>")
				.replaceAll("LtBlueBG\">\\$(\\d)\\.(\\d)M-\\$(\\d)\\.(\\d)M<","LtBlueBG\">\\$$1,$200,000-\\$$3,$400,000<")
				.replaceAll("-\\$(\\d)\\.(\\d)M<","-\\$$1,$200,000<")
				.replace("Pricing: $770,000 - $1M,000", "Pricing: $770,000 - $1,000,000")
				.replace("Pricing: $860,000 - $1M,000", "Pricing: $860,000 - $1,000,000");
				
		comData = comData.replace("TextBlue'>660's-900's<", "TextBlue'>$660,000-$900,000<")
				.replace("TextBlue'>1M-1.1M</div>", "TextBlue'>$1,000,000-$1,100,000</div>")
				.replace("LtBlueBG\">$1.2M-$1.3M</td>", "LtBlueBG\">$1,200,000-$1,300,000</td>");
				
		
		String prices[] = U.getPrices(html+comData,"Pricing: \\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|\\| \\$\\d,\\d{3},\\d{3}</p>|txtBold_SansSerif'>\\$\\d{3},\\d{3}</span>|Pricing: \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</p>|LtBlueBG\">\\$\\d{3},\\d{3}-\\$\\d,\\d{3},\\d{3}|From: \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}</div>|\\$(\\d,)?\\d{3},\\d{3}-\\$(\\d,)?\\d{3},\\d{3}|\\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</div>|From \\$<b>\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}</span>", 0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
//		U.log(Util.matchAll(html, "[\\w\\s\\W]{30}860[\\w\\s\\W]{50}", 0));
		
//======================================================Sq.ft===========================================================================================		
		html = html.replaceAll("<SPAN class='MoreHomesBox_Details TextBlack'> SF", " SF")
				.replaceAll("\\s*<SPAN class='MoreHomesBox_Details_Center TextDarkGrey'> SF", " SF");
		String[] sqft = U
				.getSqareFeet(
						html+comData,
						"\\d+ - \\d+ SF|\\d{4} SF|</SPAN> \\d,\\d+ SF</SPAN>|</SPAN> \\d{4} SF</SPAN> |\\d{4} - \\d{4}</span> SF</p>|\\d,\\d{3}SF</p>|"
						+ "SansSerif\">\\d{4}</span> SF</p>",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);

//		U.log(Util.matchAll(html, "[\\w\\s\\W]{30}4627[\\w\\s\\W]{50}", 0));
		
//================================================community type========================================================
		html = html.replace("Country Club with golf", "Country Club with golf course")
				.replaceAll("Club\"|CountryClub\\.jpg|Charlotte Country Club", "");
		String communityType=U.getCommType(html+comData);
		
//==========================================================Property Type================================================
		html = html.replaceAll("entry custom-designed homes|newest custom", "exceptional custom home").replace("_Cottage_", "");
		html = html.replaceAll("Modern Farmhouse, French Country, American Cottage, English Cottage, and Craftsman elevations|Modern Farmhouse| and Craftsman", "").replaceAll("luxury living|luxury and reflect|luxury of living|luxury designs", "luxury home");
		if(allFlrQuckHomeData != null) allFlrQuckHomeData = allFlrQuckHomeData.replaceAll("data-title=\".*\"", "");
		String proptype=U.getPropType((allFlrQuckHomeData+html+comData+ " Luxury Communities").replace("3-car side entry custom", ""));
//			U.log("MMMMMMMM "+Util.matchAll(allFlrQuckHomeData+html+comData, "[\\w\\s\\W]{30}custom-designed[\\w\\s\\W]{30}", 0));
		U.log("prpType=======================================================================> "+proptype);
		
//==================================================D-Property Type======================================================
		
		//html = html.replaceAll("first and second floor", "")
		String dtype=U.getdCommType(html+comData+allFlrQuckHomeData+allModelHomesData);
		
//==============================================Property Status=========================================================
		html=html.replace("Opening in Spring 2019", "Opening Spring 2019").replace("Opening in 2019", "Opening 2019")
				.replaceAll("Quick Move-In|Quick Move-In Home", "") //check next time if required
				.replaceAll("eeding a quick move-in|quick move-inClassica|have no quick move|Inactive and Sold Out communities|Now Open with three model|data-title=\"Final Opportunit|data-title=\"Just One Opportunity|title=\"Huntson Reserve - Phase 1 Available| NC \\| Quick Move-In", "");
		String pstatus=U.getPropStatus(html+comData);
		U.log("pstatus: "+pstatus);
//		U.log("MMMMMMMM "+Util.matchAll(allFlrQuckHomeData+html+comData, "[\\w\\s\\W]{30}Quick Move[\\w\\s\\W]{30}", 0));
		
		html = U.removeComments(html);
		
		if(!html.contains("TextWhite\">Quick Move-in Homes")) {
			//pstatus=pstatus.replace("Quick Move-in Homes","No Quick Move-in Homes");
			pstatus=pstatus.replace("Quick Move-in Homes","");
			pstatus = pstatus.replaceAll("^,|,$", "").trim();
		}
		pstatus = pstatus.replaceAll("^,|,$", "").trim();
		if(pstatus.length() < 2) pstatus = ALLOW_BLANK;
		
		if(comUrl.contains("/Charlotte-NC/Greater-Charlotte/Model-Leaseback"))quickCount = 0;
		if(comUrl.contains("/Charlotte-NC/Greater-Charlotte/On-Your-Lot"))quickCount = 0;

//		if(quickCount>0 && !pstatus.contains("Quick")) {
//			
//			if(pstatus == ALLOW_BLANK) pstatus = "Quick Move-in Homes";
//			else
//				pstatus = pstatus + ", Quick Move-in Homes";
//		}
//============================================note====================================================================
		
		if(add[0].contains("<p") || comUrl.contains("Charlotte-NC/Cornelius-Lake-Norman/JettonPlace") || 
				comUrl.contains("https://www.classicahomes.com/new-homes/Communities/Charlotte-NC/South-Charlotte/ProvidenceRetreat")
				|| comUrl.contains("https://www.classicahomes.com/new-homes/Communities/Charlotte-NC/Huntersville-Lake-Norman/Torance"))
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		
		//From Img
		if(comUrl.contains("Cornelius-Lake-Norman/RobbinsPreserve") || comUrl.contains("/Concord-NC/Christenbury-Glen")
				|| comUrl.contains("Charlotte-NC/Concord-NC/Christenbury-Hall") || comUrl.contains("Charlotte-NC/Huntersville-Lake-Norman/Torance")
				|| comUrl.contains("Charlotte-NC/Cornelius-Lake-Norman/JettonPlace") || comUrl.contains("Charlotte-NC/South-Charlotte/Blakeney-Retreat")
				|| comUrl.contains("Charlotte-NC/Midtown-Charlotte/Cotswold-Retreat") || comUrl.contains("Charlotte-NC/Mint-Hill/ChevalMeadows")
				|| comUrl.contains("Charlotte-NC/Waxhaw-NC/Cureton") || comUrl.contains("/Charlotte-NC/Midtown-Charlotte/PlazaMidwood")
				|| comUrl.contains("/Charlotte-NC/South-Charlotte/Livingston-Drive")
		||comUrl.contains("/Cornelius-Lake-Norman/The-Reserve-At-Washam-Potts")
				) {
			
			pstatus = "Sold Out";
		}

		if(comUrl.contains("shttp://www.classicahomes.com/communities/robbinspreserve")||comUrl.contains("https://www.classicahomes.com/communities/takeout"))
			geo="False";
		
		U.log("Address---->MMMMMMm"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
	j++;
//		}catch(Exception e){}
	}

}