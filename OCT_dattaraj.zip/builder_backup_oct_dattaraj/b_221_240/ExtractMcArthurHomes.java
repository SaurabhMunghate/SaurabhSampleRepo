package com.shatam.b_221_240;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;


import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityList;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;





public class ExtractMcArthurHomes extends AbstractScrapper {
	static int i;
	CommunityLogger LOGGER;
	static int j=0;
	WebDriver driver = null;
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractMcArthurHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McArthur Homes.csv", a.data()
				.printAll());
	}

	public static String homeurl = "https://www.mcarthurhomes.com";

	public ExtractMcArthurHomes() throws Exception {
		super("McArthur Homes", homeurl);
		LOGGER = new CommunityLogger("McArthur Homes");
	}

	//int a = 0;

	public void innerProcess() throws Exception {
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();
				
		
		U.log(homeurl + "/new-homes/");
//		U.bypassCertificate();
		String html = U.getHTML(homeurl + "/new-homes/");
		//U.log(html);
		
		html = U.getSectionValue(html, "<div class=\"callouts communities clearfix\">",	"<div class=\"ask block\">");
		// U.log(html);
		String[] urls = U
				.getValues(html, "<div class=\"w33 columns\">", "</div>");
	//	U.log(Arrays.toString(urls)+"###########");
		for (String loc : urls) {
//			U.log(loc);
			String Type = U.getPropType(loc);
			loc = loc.replace("0s", "0,000");
			
			
			
			 //U.log(loc);
		String	loc1 = U.getSectionValue(loc, "href='", "'");
			//loc1 = homeurl + "/" + loc1;
			U.log(loc1);
			String locHtml=U.getHTML(loc1);
			//U.log(locHtml);
			locHtml=locHtml.replace("0s", "0,000").replace(" mid 300&#8217;s", "$300,000");
		//	U.log("loc= "+loc);
			String[] Prices = U.getPrices(locHtml+loc,
					"\\$\\d+,\\d+-\\d+,\\d+|\\$\\d+,\\d+|\\$\\d+,\\d+([,\\s])?-([,\\s])?\\$\\d+,\\d+", 0);
			//U.log("min price= "+Prices[0]);
			//U.log("max price "+Prices[1]);
			
			
			commDetails(loc1, Type, Prices);
			
			
		}
		LOGGER.DisposeLogger();
	}

	public void commDetails(String commUrl, String Type, String[] Prices)throws Exception {
//		try{
//		if(j>=5)
		{
		//TODO:

//		if(!commUrl.contains("https://mcarthurhomes.com/new-home-communities/harvest-park-mapletonutah/")) return;
		
			U.log(j+"=="+commUrl);
			U.log(Type+"sunrisers1111111111");
//			U.bypassCertificate();

			String html = U.getHTMLwithProxy(commUrl);
			
			String commName = U.getSectionValue(html,"<title>", "<");
			
			commName = Util.match(html, "<div class=\"slide-text\">\\s+<h1>(.*?)</h1>",1);
			commName = commName.replaceAll("-SOLD OUT| - Sold Out|Townhomes", "");
//			if(commName.contains("-"))
//			{
//				commName = U.getSectionValue(html,"<title>", "-");
//			}
//			if(commName.contains("|"))
//			{
//				commName = U.getSectionValue(html,"<title>", "|");
//			}
//			if(commName.contains(" at "))
//			{
//				commName = U.getSectionValue(html,"<title>", " at ");
//			}
			
			html=html.replaceAll("Ranches\",\"url|parks and 1 golf course", "");
			String commType = U.getCommunityType(html);
			String drop=U.getSectionValue(html, "<ul class=\"main-nav\">", "Request Info</a></li>");
			if(drop!=null)
				html=html.replace(drop, "");
			html=html.replace("New Homes in the Lehi Area Now Available", "New Homes Now Available").replaceAll("coming soon|Grand Opening|New Townhomes|New townhomes|new townhome|Office Hours:</strong><br />Coming ", "");
			String Status = U.getPropStatus(html.replace("New Homes in the Lehi Utah Area Now Available!", "New Homes Now Available!").replaceAll("<!-- GRAND OPENING|New homes in Herriman now available at Miller Crossing|Now Available From|New Homes Coming Soon|now available for all our new homes|New homes and townhomes in Herriman, UT under construction now|Last Chance To Build|available now in American|Quick Move|townhomes available now", ""));
			U.log("Status: "+Status);
			
			String qSec = U.getSectionValue(html, "<!-- Available Homes", "<!-- container -->");

			if(qSec==null)
				qSec = "";
			
			int soldCount = 0;
			String[] qData = U.getValues(qSec, "<div class=\"element\">", "</div>");
			U.log("quick ::"+qData.length);
			for(String data : qData)
				if(data.contains("SOLD</strong>"))
					soldCount++;
			
			if(html.contains("Quick Move-In Homes") && qData.length > 0 && qData.length>soldCount){
				if(Status.length()>4){
					if(!Status.contains("Quick"))
						Status=Status+", Quick Move-In Homes";
				}else{
					Status="Quick Move-In Homes";
				}
			}
			
			String AllPlanData=ALLOW_BLANK;
			
				String secval[]=U.getValues(html, "<div class=\"element\">", "</div>");
				U.log("Total plan::" + secval.length);
				
				if(secval.length == 0) {
					String homesVal[] = U.getValues(html, "<div class=\"element flex-center\">", "View Details</a>");
					U.log("homesVal length::" + homesVal.length);
					for(String home:homesVal){
						String urlSec = U.getSectionValue(home, "GALLERY, FLOOR PLAN and more", "class=\"btn\">");
						//U.log("urlSec:: "+urlSec);
						String homeUrl = U.getSectionValue(urlSec, "<a href=\"", "\"");
						U.log("homeURL:: "+homeUrl);
						AllPlanData += U.getHTMLwithProxy(homeUrl); 
					}
				}
				
				for(String s:secval){
					U.log("homeURL:: "+U.getSectionValue(s, "<a href=\"", "\""));
					String planHtml=U.getHTMLwithProxy(U.getSectionValue(s, "<a href=\"", "\""));
					AllPlanData += U.getSectionValue(planHtml, "<div class=\"w60 columns\">", "<!-- container -->");
				}
				
				if(AllPlanData!=null)
					AllPlanData = AllPlanData.replace("Craftsman Base", "Craftsman style details").replace("upstairs study loft", "with Loft ");
				
				String html1=U.getNoHtml(html);
			Type = U.getPropType((AllPlanData+html1+commName+Type)
					.replace("Miller Crossing Estates Community in Herriman", "")
					.replace("Juniper Vista Estate lots", "Juniper Vista Estate Style Living lots.")
					.replaceAll("the-villas-at-rockwell-townhomes|rockwell-townhomes|McArthur Homes back patio view|McArthur Homes condo view from the sidewalk|Townhouse Drive|New townhomes available now in Herriman at|Patio-|Single family homes built|-loft|studio loft|loft studio", ""));
			U.log("pType:: "+Type);
			
//			U.log(">>>>>>>>>>>>"+Util.matchAll((AllPlanData+html1+commName+Type), "[\\s\\w\\W]{30}estates[\\s\\w\\W]{30}", 0));

//			U.log("HHHhh"+planHtml);
			String dType = U.getdCommType((html+AllPlanData).replaceAll("Rockwell Ranch|American Fork and The Ranches|single-floorplans|Boulder Ranch|Ranch</a>|Ranch - Sold Out</a>|Ranches\"|Your_Story_2",""));

			U.log("dType:: "+dType);
			U.log(">>>>>>>>>>>>"+Util.matchAll((html+AllPlanData), "[\\s\\w\\W]{30}ranch[\\s\\w\\W]{30}", 0));
			
			
			String notes = U.getnote(html);
			String SQsec = U.getSectionValue(html, ">Floor Plans", "<a id=\"Panel2");
		
			String[] area = { ALLOW_BLANK, ALLOW_BLANK };
		
			area = U.getSqareFeet(html+AllPlanData, "from \\d,\\d{3} to \\d,\\d{3} square feet|\\d{4} sf|\\d{4} Sq Ft.|up to \\d,\\d{3} square feet", 0);
			area[0] = (area[0] == null) ? ALLOW_BLANK : area[0];
			area[1] = (area[1] == null) ? ALLOW_BLANK : area[1];
			U.log("minSq: "+area[0]+" maxSq: "+area[1]);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html+AllPlanData, "[\\s\\w\\W]{30}4,041[\\s\\w\\W]{30}", 0));
			
			String addSec = U.getSectionValue(html, "Address:", "</div>");
			U.log("addSec==="+addSec);
			
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			if (addSec != null) {
				addSec=addSec.replace(" (13200 S.)", "").replace("<br />",",").replaceAll("</strong>,", "")
						.replace("Juniper Trail Dr. (4685 W.) Birkdale Dr.", "4685 W. Birkdale Dr.");
				U.log(addSec+"FFF");
			add = U.getAddress(addSec.replaceAll("Model Home: ",""));				
			}
			U.log(Arrays.toString(add));
			String LLSec = U.getSectionValue(html, "google.com/maps", "\"");
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String flag = "FALSE";
			if (LLSec != null) {
				U.log("latLngSec :::"+LLSec);
				latlng[0] = Util.match(LLSec, "\\d{2}\\.\\d+");
				
				latlng[1] = Util.match(LLSec, "-\\d{2,3}\\.\\d+");
				U.log(Arrays.toString(latlng));
//				flag = "FALSE";
			}
			if(add[0] != ALLOW_BLANK && add[3]!= ALLOW_BLANK){
				if (latlng[0] != ALLOW_BLANK || latlng[1] != ALLOW_BLANK)
					flag = "FALSE";
			}
			if (latlng[0] == ALLOW_BLANK || latlng[1] == ALLOW_BLANK)
				if (add[0] != null && add[3] != null) {
					latlng = U.getlatlongGoogleApi(add);
					if(latlng == null) latlng = U.getlatlongHereApi(add);
					flag = "TRUE";
				}
			add[2] = add[2].replace("  ", "");
			if(add[3].length()<4 || add[0].length()<4){
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				flag="TRUE";
			}
			add[0] = add[0].replaceAll("\\(13200 S\\)", "").replaceAll("\\(|\\)", "");
			U.log(latlng[0]);
			U.log(latlng[1]);
			if (Prices[0] == null) {
				U.log("hii");
				html = html.replaceAll("0s", "0,000").replace("mid 300’s.", "mid $300,000");
				Prices = U.getPrices(html, "\\$\\d+,\\d+-\\d+,\\d+", 0);
				if (Prices[0] == null)
					Prices[0] = ALLOW_BLANK;
				if (Prices[1] == null)
					Prices[1] = ALLOW_BLANK;
			}
			i++;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] prices = U.getPrices(AllPlanData+Prices[0]+Prices[1] , "\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
					maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
			LOGGER.AddCommunityUrl(commUrl);
			//LOGGER.countOfCommunity(i);
			//latlng=U.getlatlongGoogleApi(add);
			if(commUrl.contains("https://www.mcarthurhomes.com/new-home-communities/brundisi-village/"))minPrice="$300,000";
			Type=Type.replace("Townhouse, Luxury Homes, Townhome", "Luxury Homes, Townhome");
			commName = commName.replaceAll("^Townhomes at", "").trim();
			commName=commName.replaceAll("McArthur Homes</title>|McArthur Homes","").replace("|","");
			if(commName.contains(" - SOLD OUT"))commName=commName.replace(" - SOLD OUT", "");
			U.log(commName);
			if(area[1]==null)area[1]=ALLOW_BLANK;
//			if(commUrl.contains("https://www.mcarthurhomes.com/new-home-communities/brundisi-village/"))Status+=", Quick Move-In Homes";
			
			//-----------Unit COunt -----------------------
			
			String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
			String mapData = ALLOW_BLANK;
			int totalCount = 0;
			
			if(html.contains("Site Plan</h1>")) {
				
				String frameSec = U.getSectionValue(html, "Site Plan</h1>", "</iframe>");
				U.log("frameSec: "+frameSec);
				
				if(frameSec != null) {
					frameUrl = U.getSectionValue(frameSec, "data-src=\"", "\""); 
					U.log("frameUrl: "+frameUrl);
					if(frameUrl==null) frameUrl = U.getSectionValue(frameSec, "src=\"", "\"");
					
					mapData = U.getHtml(frameUrl, driver);
					
					if(mapData.contains("<div id=\"hotspot_")) {
						
						ArrayList<String> pins = Util.matchAll(mapData, "<div id=\"hotspot_", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}

				}
				
			}
		
			data.addCommunity(commName, commUrl, commType);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(area[0], area[1]);
			data.addPropertyType(Type, dType);
			data.addPropertyStatus(Status);
			data.addNotes(notes);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
			data.addUnitCount(totalUnits);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//		}catch(Exception e){}
	}
}