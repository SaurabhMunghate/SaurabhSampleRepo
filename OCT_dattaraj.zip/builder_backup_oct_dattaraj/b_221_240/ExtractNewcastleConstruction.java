package com.shatam.b_221_240;

/**
 *  @Newcode : By Priti 
 * @date : 10-07-2017
 *  @Modify : Sawan 
 * @date : 10-05-2017
 * @author Rakesh Chaudhari
 * @date 08-07-2015
 *
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNewcastleConstruction extends AbstractScrapper {
	static String BASEURL = "https://newcastle-homes.com";
	 CommunityLogger LOGGER;
	 WebDriver driver = null;
	 static int j=0;
	 int i = 0;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractNewcastleConstruction();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Newcastle Homes.csv", a.data().printAll());
	}

	public ExtractNewcastleConstruction() throws Exception {

		super("Newcastle Homes", BASEURL);
		LOGGER = new CommunityLogger("Newcastle Homes");
	}

//	private WebDriver setProxy(String ip, String port) {
//		Proxy proxy = new Proxy(); 
//		proxy.setHttpProxy(ip+":"+port); 
//		proxy.setSslProxy(ip+":"+port); 
//
//		DesiredCapabilities capabilities = DesiredCapabilities.chrome(); 
//		capabilities.setCapability("proxy", proxy); 
//		Map<String, Object> prefs = new HashMap<String, Object>();
//	      // browser setting to disable image
//	    prefs.put("profile.managed_default_content_settings.images", 2);
//		ChromeOptions options = new ChromeOptions();
//	//	options.addExtensions(new File("/home/shatam-50/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
//		options.addExtensions(new File("/home/shatam-10/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
//		options.setExperimentalOption("prefs", prefs);		
//		options.addArguments("start-maximized"); 
//
//		capabilities.setCapability(ChromeOptions.CAPABILITY, options); 
//
//		return new ChromeDriver(capabilities);
//		
//	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String mainHtml = U.getHtml("https://newcastle-homes.com/", driver);
		
		String[] regionValues = U.getValues(mainHtml, "<li class=\"Areas_listItem", "</div></a></li>");
		U.log("regionValues: "+regionValues.length);
		
 		for(String regsec:regionValues) {
 			
 			//U.log("regsec: "+regsec);
 			String regUrl = "https://newcastle-homes.com" + U.getSectionValue(regsec, "href=\"", "\"");
 			U.log("regUrl: "+regUrl);
 			
 			String regHtml = U.getHtml(regUrl, driver);
 			
 			String[] comCards = U.getValues(regHtml, "<div class=\"CommunityCard_wrapper", "</div></div></div>");
 			//U.log("communites in this region: "+comCards.length);
 			
 			for(String comSec:comCards) {
 				
 				//U.log("comSec: "+comSec);
 				
 				String comUrl = "https://newcastle-homes.com" + U.getSectionValue(comSec, "href=\"", "\"");
 				//U.log("comUrl: "+comUrl);
 				
// 				try {
 					getDetails(comUrl, comSec);
// 				} catch (Exception e) {}
 					U.log(" ");
 									
 			}
 		}

	}
	
	public void getDetails(String comUrl, String comSec) throws Exception {
		
		U.log("Count: "+i+" comUrl: "+comUrl);

		
//--SINGLE EXECUTION--------------------------------------------------------------------------		
//		if(!comUrl.contains("https://newcastle-homes.com/communities/leeds-al/unali-at-grand-river")) return; 
		
		{
			String comHtml = U.getPageSource(comUrl);
			U.log(U.getCache(comUrl));	
			//important---
			comHtml = comHtml.replaceAll("<!-- react-text: \\d+ -->", "<replaced>");
			
			
			//--------COMMUNITY NAME
			String section = U.getSectionValue(comHtml, "<h2 class=\"Carousel_h2", "Carousel_list"); 
			//U.log("section: "+section);
			
			String comName = U.getSectionValue(section, "<replaced>", "<!-- /react-text -->").trim();
			U.log("comName: "+comName);
			
			if(comName!=null) {
				comName = comName.replace("Henley in Helena", "Henley");	
			}
			
			//--------ADDRESS AND LATLONG
			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latLong = {ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			
			String addressLine = U.getSectionValue(section, "<!-- /react-text -->", "</span>");
			addressLine = addressLine
					.replace(" | ", ", ")
					.replaceAll("<span class=\"DetailsPage_h2\" data-reactid=\"\\d+\">", "").trim();
			U.log("addressLine: "+addressLine);
			
			add = U.getAddress(addressLine);
			U.log("ADDRESS: "+Arrays.toString(add));
			
			//LATLONG
			U.log("comSec: "+comSec);
			
			String latLngSec = U.getSectionValue(comSec, "https://www.google.com/maps", "target=");
			U.log("latLngSec: "+latLngSec);
			if(latLngSec == null) latLngSec = U.getSectionValue(comHtml, "https://www.google.com/maps", "target=");
			U.log("latLngSec--: "+latLngSec);
			
			String latlng = U.getSectionValue(latLngSec, "place/", "/@");
			U.log("latlng: "+latlng);
			
			String[] latlngSplit = latlng.split(",");
			latLong[0] = latlngSplit[0];
			latLong[1] = latlngSplit[1];
			
			U.log("LATLONG: "+Arrays.toString(latLong));
			U.log("GEOCODE: "+geo);
			
			//--------AVAILABLE HOMES DATA
			String availableData = ALLOW_BLANK;
			
			comHtml = comHtml.replaceAll("</div>\\s+</div>\\s+</div>\\s+</div>", "</div></div></div></div>");
			
			if(comHtml.contains("Available Floor Plans")) {
				
				String[] availablePlans = U.getValues(comHtml, "<div class=\"PlanCard_wrapper", "</div></div></div></div>");
				U.log("availablePlans: "+availablePlans.length);
				
				for(String plans:availablePlans) {
					
					String planUrl = "https://newcastle-homes.com" + U.getSectionValue(plans, "<a class=\"\" href=\"", "\"");
					U.log("planUrl: "+planUrl);
					String planHtml = U.getPageSource(planUrl);
					
					//removing 
					if(planHtml.contains("window.__PRELOADED_STATE__ =")) {
						String remove = U.getSectionValue(planHtml, "window.__PRELOADED_STATE__ =", "</html>");
						planHtml = planHtml.replace(remove, "");
					}
					
					if(planHtml.contains("<![CDATA") && planHtml.contains("You need to enable JavaScript")) {
						String remove = U.getSectionValue(planHtml, "<![CDATA", "You need to enable JavaScript");
						planHtml = planHtml.replace(remove, "");
					}
					
					
					availableData += planHtml;
				}
				

			}
			
			//--------QUICK HOMES DATA
			String quickData = ALLOW_BLANK;
			
			if(comHtml.contains("Quick Move-In Homes")) {
				
				String[] quickHomes = U.getValues(comHtml, "<div class=\"HomeCard_wrapper", "</div></div></div>");
				U.log("quickHomes: "+quickHomes.length);
				
				for(String quick:quickHomes) {
					
					String quickUrl = "https://newcastle-homes.com" + U.getSectionValue(quick, "<a class=\"\" href=\"", "\"");
					U.log("quickUrl: "+quickUrl);
					String quickHtml = U.getPageSource(quickUrl);
					
					//removing 
					if(quickHtml.contains("window.__PRELOADED_STATE__ =")) {
						String remove = U.getSectionValue(quickHtml, "window.__PRELOADED_STATE__ =", "</html>");
						quickHtml = quickHtml.replace(remove, "");
					}
					
					if(quickHtml.contains("<![CDATA") && quickHtml.contains("You need to enable JavaScript")) {
						String remove = U.getSectionValue(quickHtml, "<![CDATA", "You need to enable JavaScript");
						quickHtml = quickHtml.replace(remove, "");
					}
					
					
					quickData += quickHtml;
				}
			}
			
			//removing json script section
			String removeJson = U.getSectionValue(comHtml, "window.__PRELOADED_STATE__ =", "</html>");
			comHtml = comHtml.replace(removeJson, "");
			
			String remove = U.getSectionValue(comHtml, "<![CDATA", "You need to enable JavaScript");
			comHtml = comHtml.replace(remove, "");
			
			//--------PRICES--------------
			String minPrice = ALLOW_BLANK; String maxPrice = ALLOW_BLANK;
			
			//replacing comments
			comHtml = comHtml.replaceAll("<!-- /react-text -->\\s+<!-- react-text: \\d+ -->\\s+", "")
					.replaceAll("<!-- /react-text -->\\s+<replaced>\\s+(\\d{3},\\d{3})", " \\$$1 ");
			
			String[] price = U.getPrices(comHtml, "\\$\\d{3},\\d{3}", 0); //+quickData+availableData 


			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("Price---> minPrice: "+minPrice+" maxPrice: "+maxPrice);
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{300}507[\\w\\s\\W]{300}",0));
			
			//---------SQUARE FEET------------------
			String maxSqft = ALLOW_BLANK;
			String minSqft = ALLOW_BLANK;
			
			comHtml = comHtml
					.replaceAll("(\\d,\\d{3})\\s+</span>\\s+<span class=\"HomeCard_iconListLabel\" data-reactid=\"\\d+\">\\s+SQ FT", " $1 SQ FT ")
					.replaceAll("(\\d,\\d{3})\\s+</span>\\s+<span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">\\s+SQ FT", " $1 SQ FT ");
			
			
			String[] sqFt = U.getSqareFeet(comHtml, "\\d,\\d{3} SQ FT", 0); 
			
			minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			
			U.log("Sqft---> minSqft: "+minSqft+" maxSqft: "+maxSqft);
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{60}1,986[\\w\\s\\W]{60}",0));
			
			//---------------- PROPERTY TYPE ------------------
			String pType = ALLOW_BLANK;
			
			pType = U.getPropType((comHtml+quickData)); //+quickData+availableData
			
			U.log("pType: "+pType);
			
//			U.log(">>>>>>>>"+Util.matchAll(comHtml+modelHomesData+inventryHomesData, "[\\w\\s\\W]{30}Patio[\\w\\s\\W]{30}",0));
			
			//---------------- DERIVED PROPERTY TYPE ------------------
			String dType = ALLOW_BLANK;
			
			dType = U.getdCommType((comHtml+quickData+availableData)
					.replaceAll("3 bedroom home|ranch style living", ""));
			U.log("dType: "+dType);
			
//			U.log(">>>>>>>>"+Util.matchAll(quickData, "[\\w\\s\\W]{30}story 3[\\w\\s\\W]{30}",0));
//			U.log(">>>>>>>>"+Util.matchAll(availableData, "[\\w\\s\\W]{90}ranch[\\w\\s\\W]{90}",0));
//			U.log(">>>>>>>>"+Util.matchAll(quickData, "[\\w\\s\\W]{30}story 3[\\w\\s\\W]{30}",0));
//			U.log(">>>>>>>>"+Util.matchAll(availableData, "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}",0));
			
			//---------------- COMMUNITY TYPE ------------------
			String cType = ALLOW_BLANK;
					
			cType = U.getCommType((comHtml));
			
			U.log("cType: "+cType);
			
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}resort[\\w\\s\\W]{30}",0));
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}golf[\\w\\s\\W]{30}",0));
			
			//---------------- STATUS ------------------
			String status = ALLOW_BLANK;
			
			comHtml = comHtml.replace("Phase 9 of Sweetwater is Coming Soon", "Phase 9 Coming Soon")
					.replace("Phase 8 is sold out", "Phase 8 sold out")
					.replaceAll("favorite one from our limited homesite options", "");
			
			status = U.getPropStatus(comHtml);
			
			if(status.contains("Move-in Ready")) status = status.replace("Move-in Ready", "Quick Move-In Homes");
			
			U.log("status: "+status);
			
			
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}golf[\\w\\s\\W]{30}",0));
			
			//---------------- NOTES ------------------
			String note = ALLOW_BLANK;
			note = U.getnote(comHtml);
			U.log("note: "+note);
			
			// ------------------ UNITS COUNT ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			
			//------------------- ADDING DATA ------------------------
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(comName, comUrl, cType);
			data.addLatitudeLongitude(latLong[0], latLong[1], geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status);
			data.addNotes(note);
			

			
			
		}
				
		i++;
	}
	

	public void addDetails(String commUrl, String commName) throws Exception {
//	if(j == 2)
	//	if(!commUrl.contains("https://newcastle-homes.com/communities/camellia-ridge"))return;
		{
		// ............................Community Url...........................
		
		U.log("count : "+j+"\nPage Url: " + commUrl+"\n"+U.getCache(commUrl));
		
		if (data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl(commUrl + "::::::::::repeated");
			return;
		}
			 if( commUrl.contains("/mckessie-crossing")  || commUrl.contains("/melrose-landing")) { LOGGER.AddCommunityUrl("no data=="+commUrl); return; }
			
		LOGGER.AddCommunityUrl(commUrl);
		
		U.log("commName : "+commName);
		
		String html = getHtml(commUrl,driver,commName);//U.getHTMLwithProxy(commUrl);
		// driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		// ...........................Community Name...........................
			/*
			 * String cName = U.getSectionValue(html, "<h1>", "</h1>");
			 * if(!cName.equals(commName))commName = cName;
			 */
	  
		//----------------
		String note = ALLOW_BLANK;
		String[] add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String[] latLng ={ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		
		//---------Lat-Lng-----------
		//String latLngSec= U.getSectionValue(html, "coords: [", "]");
		String latLngSec= U.getSectionValue(html, "\"geo\": {", "},");
		latLng[0]=U.getSectionValue(latLngSec, "latitude\": \"", "\"").trim();
		latLng[1]=U.getSectionValue(latLngSec, "\"longitude\": \"", "\"").trim();
		
		if(latLngSec != null){
			U.log("latLngSec : "+latLngSec);
//			
//			if(!latLngSec.contains("0.000000, 0.000000")){
//				latLng = latLngSec.split(", ");
		//	}
		}
		U.log("Lat-Lng is : " + Arrays.toString(latLng));
		U.log(latLng.length);
		
		//----------------Address---------------------
		
		String addSec = U.getSectionValue(html, "Furnished Model Home: <strong>", "</strong>");
		if(commUrl.contains("/communities/old-cahaba")){
			add[2]="AL";add[1]="Cahaba";
		}
		if(commUrl.contains("communities/The-Cove")) {
			add[2]="AL";add[1]="Helena";
		}
        if(commUrl.contains("/communities/griffin-park")) {
        	add[2]="AL";add[1]="Birmingham";
        }
        if(commUrl.contains("communities/taylors-crossing")) {
        	add[2]="AL";add[1]="Moody";
        }
        if(commUrl.contains("/communities/sweetwater")) {
        	add[2]="AL";add[1]="Springville";
        }
		U.log("addSec : "+addSec);
		if(addSec != null){
			String tempAdd[] = addSec.split(",");
			U.log(tempAdd.length);
			if(tempAdd.length == 3 ){
				add[0] = tempAdd[0];
				add[1] = tempAdd[1];
				add[2] = tempAdd[2];
			}
		}
		
		add[0]=add[0].replace("1670 BAXTER AVENUE", "1670 Baxter Avenue");
		
		U.log("Address is : " + Arrays.toString(add));
		

		
		if(latLng.length==0||latLng[0]==ALLOW_BLANK||latLng[1]==ALLOW_BLANK)
		{
			latLng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latLng);
			geo = "TRUE";
			
			note = "Address And Lat-Lng Taken From City State";
		}
		if(commUrl.contains("/communities/melrose-landing") || commUrl.contains("/communities/unali-grand-river")){
			add[0] = "121 Bishop Circle";
			add[1] = "Pelham";
			add[2] = "AL";
			add[3] = "35124";
			note = "Address Is Taken From Contact Us";
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo = "TRUE";
		}
		
		if((add[3].length()<4 && add[0].length()>4) && latLng[0].length()<4){
			
			latLng = U.getGoogleLatLngWithKey(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo = "TRUE";
			U.log("New Address is : " + Arrays.toString(add));
		}
		
		//--------Fetching zip from lat-lng------------------
		if((add[3].length()<4 || add[0].length()<4) && latLng[0].length()>4){
			String add1[] = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			if(add[3].length()<4) add[3] = add1[3];
			if(add[0].length()<4) add = add1;
			geo = "TRUE";
			U.log("New Address is : " + Arrays.toString(add));
		}

/*		if(add[0].length()<4 && latLng[0].length()>4){
			add = U.getAddressGoogleApi(latLng);
			geo = "TRUE";
			U.log("New Address is : " + Arrays.toString(add));
		}
*/		//-------if address and latlong both are not present on community page
		//------then extracted address using sitemap details(street name) and city state-----
		String cityState = U.getSectionValue(html, "<h3>", "</h3>");
		U.log("cityState is : "+cityState);
		if(add[0].length()<4 && latLng[0].length()<4 && cityState != null)
		{
			
			if(cityState.contains(",")){
				add[1] = cityState.substring(0, cityState.indexOf(",")); //city
				add[2] = cityState.substring(cityState.indexOf(",")+2, cityState.length()).trim(); //state
			}
			U.log("city is : " + add[1] + "\nstate is : " + add[2]);
			
			//Below is the hardcoded street address from sitemap image //-----plz verify and update the street name from the sitemap image.
			if(commName.equals("camellia ridge")){
				add[0] = "Bearden Road";
			}
			if(commName.equals("griffin park")){
				add[0] = "Griffin Park Circle";
			}
			if(commUrl.contains("/highland-corners")){
				add[0] = "Sulphur Springs Rd & Al Seier Rd";
			}
			if(commUrl.contains("/communities/hunters-creek")){
				add[0] = "Hunters Creek Dr";
			}
			if(commUrl.contains("/communities/taylors-crossing")){
				add[1] = "Moody";
				add[2] = "AL";
			}
				
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			
			String add1[] = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			U.log(Arrays.toString(add1));
			add[0]=add1[0];
			add[1]=add1[1];
			add[2]=add1[2];
			add[3]=add1[3];
			geo = "TRUE";
			
			note = "Address And Lat-Lng Taken Using Sitemap Details";
		}
		
		if(commUrl.contains("/communities/taylors-crossing")){
			add[1] = "Moody";
			add[2] = "AL";
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);

			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);

			geo = "TRUE";
			
			note = "Address And Lat-Lng Taken From City & State";

		}
		
		
		//------------fetching specific community Quick Move Homes data from ==>"http://newcastle-homes.com/homes/?community="
		String quickSec=U.getSectionValue(html, "<ul class=\"list-menu\">", "Quick");
		String allquickData=ALLOW_BLANK;int k=0;
		String quickHtml =ALLOW_BLANK;
//		U.log(U.getSectionValue(quickSec, "href=\"", "\""));
		if(quickSec!=null) {
			quickHtml = getHtml(("https://newcastle-homes.com/"+U.getSectionValue(quickSec, "href=\"", "\"")).replace("m//homes", "m/homes"),driver ,commName);
			
			U.log("https://newcastle-homes.com/"+U.getSectionValue(quickSec, "href=\"", "\""));
			String qHomes[]=U.getValues(quickHtml, "data-href=\"", "\"");
			U.log("quickHome :"+qHomes.length);
			for(String home:qHomes){
				U.log(home);
				if(k>5)break;
				allquickData+=U.getHtml("http://newcastle-homes.com/homes"+home, driver);
				k++;
			}
		}
		//--------Prices--------------
		String maxPrice = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK;
		
		html = html.replace("Priced from: <strong>500's", "Priced from: 500,000")
				.replaceAll("0's</strong></div>", "0,000</strong></div>").replaceAll("0's|0'S", "0,000")
				.replace("Low $300's", "Low $300,000").replace("Mid $300's - Mid $400's", "Mid $300,000 - Mid $400,000")
				.replace("<strong>$299 - $390</strong", "<strong>$299,000 - $390,000</strong");
		
		String[] price = U.getPrices(html+quickHtml, "Priced from: \\d{3},\\d{3}|PRICED FROM: \\$\\d{3},\\d{3}|PRICED FROM: THE MID \\$\\d{3},\\d{3}|PRICED FROM: \\$\\d{3},\\d{3}|PRICED FROM: THE \\d{3},\\d{3} TO \\d{3},\\d{3}|PRICED FROM: THE HIGH \\$\\d{3},\\d{3}|Mid \\$\\d+,\\d+ - Mid \\$\\d+,\\d+|<div class=\"listing-overlay\">\\$*\\d{2,3},\\d{3}</div>|THE UPPER \\$*\\d{3},\\d{3}|THE MID \\$*\\d{3},\\d{3}|The Low \\$*\\d{3},\\d{3}|THE \\$*\\d{3},\\d{3}|Priced from:\\s*</?strong>\\s*\\$\\d{3},\\d{3}(\\s?-\\s?\\$\\d{3},\\d{3})?|Low \\$\\d{3},\\d{3}|The High \\$\\d{3},\\d{3}", 0); 
//		U.log("mmmmmm=="+Util.matchAll(html+allquickData, "[\\w\\s\\W]{30}Mid \\$300[\\w\\s\\W]{30}", 0));

		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		//---------Square Feet------------------
		String maxSqft = ALLOW_BLANK;
		String minSqft = ALLOW_BLANK;
		String[] sqFt = U.getSqareFeet(html+allquickData, "SQ FT: \\d{4} - \\d{4}|sq ft: <strong>\\d{4} - \\d{4}|Square feet:</strong> \\d{4}|Square feet:</strong> \\d,\\d{3}|\\d,\\d{3} sqft", 0); 
		
		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		
		
		//------------communityType------------------
		String communityType = ALLOW_BLANK;
		communityType = U.getCommunityType(html.replaceAll("Broker for the master planned development", ""));
		//-----------propType--------
		String propType =ALLOW_BLANK;
		allquickData=allquickData.replace("open one level living plan", "Level 1");
		html=html.replace("scenic walking trails, common areas", "")
				.replace("1 estate home left", "1 Estate Style Living home left");
		propType = U.getPropType((html+allquickData).replace("custom home builder|two car courtyard garage", ""));

		//---------------------Note----
		if (note==ALLOW_BLANK) {
			note=U.getnote(html);
		}else{
			String eNote=U.getnote(html);
			if(eNote.length()>3)note=note+", "+eNote;
		}
		//--------Derived TYpe-----------
		html = html.replaceAll("Levels:</strong>", "Stories");
		
		String dType= ALLOW_BLANK;
		dType = U.getdCommType(html+allquickData);
		
		//---------Status-----------------
		String rem = "167 are Move-In Ready and can clo|And Coming Soon!&nbs|Move-In Ready homes may|Now Selling Building 3|currently 30 homesites available |<div class=\"well\">Coming soon|Floor Plan Coming Soon";
		html = html.replaceAll(rem, "").replaceAll("Phase 5 is now selling", "Phase 5 now selling").replace("ONLY TWO HOMESITES REMAIN", "ONLY TWO HOMESITES REMAIN");


		
		html = html.replace("Coming Soon, 2018", "Coming Soon 2018");
		if(commUrl.contains("/shelby-farms"))propType="Craftsman Style Homes";
			
		String propStatus = ALLOW_BLANK;
		html=html.replace(">Quick Delivery homes<", "")//.replaceAll("Phase&nbsp;6 is Now Selling|Phase 6 is Now Selling", "Phase 6 Now Selling")
				.replaceAll("Phase 7 is Now Selling", "Phase 7 Now Selling")
				
				.replaceAll("home in this final phase of our beautiful|Ready and can", "")
				.replace("Soon...</div>", ""); //.replace("ONLY TWO HOMESITES REMAIN", "ONLY TWO HOMESITES REMAIN");
//		html=html.replace("Phase 7 is almost sold out", "Phase 7 almost sold out");
//		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}phase 8[\\w\\s\\W]{30}", 0));
//		if(commUrl.contains("/hunters-creek"))propStatus="Quick Delivery Homes";
		
		html=html.replace("only have a few basement homesites remaining", "only a few basement homesites remaining")
				.replace("Only 1 estate home remains", "Only 1 home remains")
				.replace("two estate basement homesites left", "Two Basement Homesites Left")
				.replace("Only a Few Basement Homesites are Left in Phase 2", "Only a Few Basement Homesites Left in Phase 2");
		
		if(commUrl.contains("https://newcastle-homes.com/communities/meadow-brook"))
	    {
			html=html.replace("Coming Soon", "");
		}
		
		propStatus = U.getPropStatus((html).replace("Coming soon...", ""))
				.replace("home in this final phase of our beautifulFinal Homes, Closeout Community, Final Homesites", "Closeout Community, Final Homesites");
		if(k > 0 &&!quickHtml.contains("There are no results based on your search credentials.") && !propStatus.contains("Quick")){
			U.log("hello");
			
			propStatus=propStatus.replace("Move-in Ready,", "");
				
				  if(propStatus.length()>4){ propStatus = propStatus +
				  ", Quick Delivery Homes"; } else { propStatus = "Quick Delivery Homes"; }
				 
		}
		U.log("propStatus======="+propStatus);
		add[2]=add[2].replace("AL 35080", "AL");
		if(commUrl.contains("https://newcastle-homes.com/communities/sweetwater")) {
			propType=propType.replace(", Courtyard Home", "");
			dType=dType.replace(", 1.5 Story", "");
		}
//		if(commUrl.contains("https://newcastle-homes.com/communities/old-cahaba"))propStatus =propStatus.replace("Almost Sold Out", "Phase 7 almost sold out");
		if(commUrl.contains("https://newcastle-homes.com/communities/camellia-ridge"))propStatus +=", Only a Few Basement Homesites Remaining";
		//if(commUrl.contains("https://newcastle-homes.com/communities/The-Cove"))propStatus ="Quick Delivery Homes, Basement Homes available";
		if(commUrl.contains("https://newcastle-homes.com/communities/henley-in-helena"))propStatus ="Quick Delivery Homes";
		commName=commName.replace(" in Helena", "");
		data.addCommunity(commName, commUrl, communityType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);	
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addPrice(minPrice,maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
	}j++;
}
	
	public static String getHtml(String url, WebDriver driver, String commName) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		commName = commName.trim().replace(" ", "-");
		
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url+commName);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		U.log("fileName from getHtml: "+fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
		}

		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
										
					driver.get(url);
					
					try{	
						Thread.sleep(10000);
						U.log("commName :"+commName +"::");
						Select dropdown = new Select(driver.findElement(By.xpath("//*[@id=\"community-search\"]")));//Select Community
						dropdown.selectByValue(commName);
					}
					catch(Exception e){
						U.log("Element  not found");
					}
					Thread.sleep(5000);
					html = driver.getPageSource();
					for(int i =1 ; i<=4 ; i++){
						try{	
							
							WebElement next = driver.findElement(By.xpath(" //*[@id=\"filtered\"]/div[2]/div/div/ul/li["+i+"]/a")); //next page
							next.click();
							html += driver.getPageSource();
							Thread.sleep(2000);
						}
						catch(Exception e){
							U.log("NExt page  not found");
						}
					}
					
					U.log("Current URL:::" + driver.getCurrentUrl());
					//html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		
	}

}