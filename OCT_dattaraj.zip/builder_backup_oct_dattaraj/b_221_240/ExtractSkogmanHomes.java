/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractSkogmanHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.skogmanhomes.com";
	
	public ExtractSkogmanHomes() throws Exception {
		super("Skogman Homes", builderUrl);
		// TODO Auto-generated constructor stub
		LOGGER= new CommunityLogger("Skogman Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSkogmanHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Skogman Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML(builderUrl);
		//String regSec=U.getSectionValue(mainHtml, "\"/communities/\">COMMUNITIES</a>", "</ul>");
		
	//	U.log("regSec::::"+regSec);
		
		String[] regUrls=U.getValues(mainHtml, "class=\"dropdown-item\" tabindex=\"-1\" href=\"", "\""); 
		U.log("Total region urls"+regUrls.length);
		for(String regUrl : regUrls){
			if(regUrl != null && regUrl.equals("#"))continue;
			regUrl = builderUrl+regUrl;
			U.log("regUrl:::"+regUrl);
			
			String regHtml=U.getHTML(regUrl);
			//String section = U.getSectionValue(regHtml, "communitiesListings xMarketCommunityResults", "");
			String[] comSec=U.getValues(regHtml, "<div class=\"col-sm-12 col-md-6\" style=\"margin-bottom: 30px;\">","<span class=\"more\">LEARN MORE");
			U.log(comSec.length);
			for(String comData:comSec)
			{
				String comUrl=builderUrl + U.getSectionValue(comData,"<a class=\"hover-zoom\" href=\"","\"");
//				U.log("Community Urls are"+comUrl);
				addDetails(comUrl,comData);
			}
		}
		
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	try{
	{
//	if(!comUrl.contains("https://www.skogmanhomes.com/find-your-home/iowa/cedar-rapids-metro/marion/bowman-meadows"))return;
		
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"==================repeated==========");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHTML(comUrl);
	
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "<h5>","</h5>");
		communityName=communityName.replace("Mt. Vernon", "").replaceAll("\\(|\\)", "");
		communityName=communityName.replace("Offsite Homes Corridor Area", "Offsite Homes Corridor");
		U.log("community Name---->"+communityName);
		
	//================================================Address section===================================================================
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		String addSec=U.getSectionValue(html, " <div class=\"card-body text-center\">","</p>");
		U.log("addSec : "+addSec);
		if(addSec!=null)
		{
			addSec  = addSec.replace("<p class=\"card-text\">", "").trim()
					.replace("816 Crossbow Court Marion", "816 Crossbow Court, Marion")
					.replace("Marion Cedar Rapids", "Marion")
					.replace("Mt. Vernon", " ,Mt Vernon")
					.replace("Falcon Ridge Waterloo", "Falcon Ridge, Waterloo").replace("MacBride Place Solon,", "MacBride Place, Solon,").replace("E Cedar Rapids", "E, Cedar Rapids").replace("W Cedar Rapids", "W, Cedar Rapids").replace("Cedar Falls", ",Cedar Falls").replace("Vernon", ",Vernon")
					.replace(" Oak Court Marion,", " Oak Court, Marion,").replace(",Mt ,Vernon", ",Mt Vernon");
			addSec = U.formatAddress(addSec);
			add = U.getAddress(addSec);
			U.log(Arrays.toString(add));
			if(add[0]==null || add[0].length()<3 && add[0]!= ALLOW_BLANK) {
				addSec=addSec.replaceAll("Iowa", "IA");
				String temp[]=addSec.split(",");
				add[3]=Util.match(temp[1], "\\d{5}");
				add[0]=temp[0];
				add[1]=U.getCityFromZip(add[3]);
				add[2]=Util.match(temp[1], "\\w{2}");
				U.log(add[2]);
	//								add=U.findAddress(addSec);
			}
		}
		
		
	 	if (add[0].toLowerCase().equals(add[1].toLowerCase())) {
			add[0]=ALLOW_BLANK;
		}
	 	
	 	
		U.log("Address---->"+add[0]+":city:"+add[1]+":state:"+add[2]+":zip:"+add[3]);
		
		
	//--------------------------------------------------latlng----------------------------------------------------------------
		String latlNgSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/Current+Location/", "\"");
		
		if(latlNgSec!=null)
		{
			latlng = latlNgSec.split(",");
		
		}
		U.log("hhhh--->"+latlng[0]+"  "+latlng[1]);
		
		if(add[1]!=ALLOW_BLANK && latlng[0]==ALLOW_BLANK)
		{
			latlng=U.getlatlongGoogleApi(add);
			
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null) && latlng[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlng);
			geo="TRUE";
		}
		U.log("hhhh1--->"+latlng[0]+"  "+latlng[1]);
		

	//================================================community type========================================================
	
		String communityType=U.getCommType((html+comData).replaceAll("golf course\\. \",|\"Golf Course Lots", ""));
		
	//==========================================================Property Type================================================
		//-----fetch property type from homes-------
		
//		String allPlanData=getPlanData(html);
		String allPlanData = null;
		String floorPlanSection = U.getSectionValue(html, "<div id=\"floorplans\"", "<div id=\"direction\"");
		if(floorPlanSection != null){
			String floorUrlSection[] = U.getValues(floorPlanSection, "<thead>", "</thead>");
			for(String floorUrlSec : floorUrlSection){
				String planUrl="https://www.skogmanhomes.com"+U.getSectionValue(floorUrlSec, "<a href=\"", "\"");
				//U.log("PlanUrls::::::"+planUrl);
				String planHtml=U.getHTML(planUrl);
				allPlanData+=U.getSectionValue(planHtml, "<div class=\"tab-pane fade show active\"", "<div class=\"newsletter\">");
			}
		}
		

		String combinedAvailableHomeHtml = null;
		int quickCount=0;
		String availableHomeSection = U.getSectionValue(html, "<div id=\"availablehomes\"", "</section>");
		if(availableHomeSection != null){
			String availableUrlSections[] = U.getValues(availableHomeSection, "<thead>", "</thead>");
			for(String availableUrlSec : availableUrlSections){
				String availableUrl="https://www.skogmanhomes.com"+U.getSectionValue(availableUrlSec, "<a href=\"", "\"");
				U.log("availableUrls::::::"+availableUrl);
				String availableHtml=U.getHTML(availableUrl);
				
				String moveInInfo=U.getSectionValue(availableHtml, "<tr><th>Quick Info</th></tr>", "<strong>Community:</strong>"); ///june ||moveInInfo.contains("Summer 2022")
				if(moveInInfo.contains("<strong>Ready:</strong> Move-in-Ready")||moveInInfo.contains("<strong>Ready:</strong> Move in Ready")||moveInInfo.contains("<strong>Ready:</strong> Now")
						||moveInInfo.contains("<strong>Ready:</strong> Immediate")||moveInInfo.contains("<strong>Ready:</strong> 6-10-22")) {
					quickCount++;
				}
						
				combinedAvailableHomeHtml+=U.getSectionValue(availableHtml, "<div class=\"tab-pane fade show active\"", "<div class=\"newsletter\">");
			}
		}
		
//=========================================================================================
		
	//============================================Price and SQ.FT======================================================================
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comData=comData.replaceAll("�s|'s",",000").replace("$260's", "$260,000");
		comData=comData.replace("$216s", "$216,000");
		String val=Util.match(comData, "\\dk|\\d+s");
		if(val!=null)
		{
		String newVal=val.replace("k",",000").replaceAll("s", ",000");
		comData=comData.replace(val,newVal);
		}
		comData=comData.replace("0’s", "0,000").replace("Homes Starting at $265,00", "");
//		U.log(comData);
		html=html.replaceAll("0�s|0's|0&#8217;s|0k's","0,000").replaceAll("Move-in-Ready Homes Starting at \\$277,396|Homes starting at \\$245,000", "");
		U.log("=========="+Util.matchAll(comData, "[\\w\\W\\s]{50}\\$400[\\w\\W\\s]{50}", 0));
		String prices[] = U.getPrices(html+comData,"from mid \\$\\d{3},\\d{3}|Starting in the low \\$\\d{3},\\d{3}|Starting in the Mid \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Starts in the low \\d{3},\\d{3}|Homes From the \\$\\d{3},\\d{3}|Homes from \\$\\d{3},\\d{3}|Starting From \\$\\d+,\\d+|Starting at \\$\\d+,\\d+|Priced at \\$\\d+,\\d+|\">\\s*\\$\\d+,\\d+\\s*</a>",0);
	
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
	//======================================================Sq.ft===========================================================================================		
		String[] sqft = U
				.getSqareFeet(
						html+comData,
						"\\d+,\\d+ - \\d+,\\d+ Sq.Ft|SQFT:</strong>\\s*\\d+ - \\d+|\\d+,\\d+ Sq.Ft.|\\d,\\d+ SQFT</small>",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		
		
		
		
	
		String proptype=U.getPropType((html+comData+allPlanData+combinedAvailableHomeHtml).replaceAll("duplex-style condos\\.\"|duplex-style condos\\.\"|single-family community in Marion|These are single-family zoned homesites|attached condo community|offering Condos and Single family homes right on", ""));
//		U.log(allPlanData.contains("SINGLE FAMILY"));
	//==================================================D-Property Type======================================================
		html=html.replaceAll("dropdown-menu multi-level|footerAnchor", "");
		String dtype=U.getdCommType((html+comData+allPlanData+combinedAvailableHomeHtml).replaceAll("Floor|floor", ""));
		
	//==============================================Property Status=========================================================
		
		html = U.removeSectionValue(html, "data = eval(", "</script>");
		html=html.replace("daylight, and walk out homesites available", "daylight and walk out homesites available")
				.replaceAll("Newest Addition of Country Ridge Coming Spring|<p>Opening Summer 2021!</p>|paving will be coming this fall of 2021|<p>Coming Soon! Our New Westfield II Model&nbsp;projected|<p>Coming Soon! The New Model of Westfield II Plan&nbsp;is coming soon|Coming Soon!&nbsp; The new Westfield II Model Home|\"<p>Coming Soon|Plan&nbsp;is coming soon|Coming Soon! Our New Westfield|Homes Available Now|,\"TAGLINE\":\"\\d Lots left!\",|ddition now open|\"TAGLINE\":\"8 Lots left available\"|\"TAGLINE\":\"6 Lots left available\"|addition is NOW OPEN|\"11 Lots left|TAGLINE\":\"Final Chance- BEST lots in the Westside|Final Opportunity\",\"PROPE|\"MARKETINGSTATUS\":\"Grand Opening\"", "");
		comData=comData.replace("ots available on a cul-de-sac", "");
		html=html.replace("Coming Spring of 2022", "").replace("daylight, and walk out homesites available ", "daylight and walk out homesites available ");
		String pstatus=U.getPropStatus(html+comData.replace("now open for new builds",""));
		
//		U.log(">>>>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}Coming Spring 2022[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>>>"+Util.matchAll(comData, "[\\s\\w\\W]{30}Coming Spring 2022[\\s\\w\\W]{30}", 0));

		
		//status from img
//		if(comUrl.contains("https://www.skogmanhomes.com/find-your-home/iowa/cedar-rapids-metro/cedar-rapids/country-ridge"))
//			pstatus = "New Lots Now Open";

//		if(combinedAvailableHomeHtml != null && 
//				(combinedAvailableHomeHtml.contains("Ready:</strong> Move-in-Ready") || combinedAvailableHomeHtml.contains("Ready:</strong> Move-in Ready")
//						|| combinedAvailableHomeHtml.contains("<strong>Ready:</strong> NOW") || combinedAvailableHomeHtml.contains("<strong>Ready:</strong> Now")||combinedAvailableHomeHtml.contains("<strong>Ready:</strong> Today"))){
//			if(pstatus != ALLOW_BLANK) pstatus = pstatus+", Move-in Ready Homes";
//			else if(pstatus == ALLOW_BLANK) pstatus = "Move-in Ready Homes";
//		}
		U.log("status :::::::: "+pstatus);
		
		U.log("Quick count=="+quickCount);
		
		if(html.contains("Currently there are no inventory homes available in this community")) {
			U.log("no available homes");
		}
		else if(html.contains("<span class=\"status-overlay\">")&& quickCount>0){
			U.log("there are available homes");
			if(pstatus.length()>4 ) {
				pstatus+=", Move-in Ready Homes";
			}
			else {
				pstatus="Move-in Ready Homes";
			}
		}
		
		
		
	//============================================note====================================================================
		
		if(add[0].equalsIgnoreCase("North") && add[1].equalsIgnoreCase("Liberty")) {
			add=U.getAddressGoogleApi(latlng);
			geo="TRUE";
		}
		
		 note=U.getnote(html.replaceAll("Pre-Selling\",\"PROPERTY", ""));
		communityName=communityName.replace("Villas", "");
		add[0]=add[0].replace("IA 52302", "").replace("N.E. Mt. Vernon", "Mt. Vernon")
				.replace("Ave, SW", "Ave SW");
		add[0] = add[0].replaceAll("Solon$|Waterloo$", "");
//		if(comUrl.contains("https://www.skogmanhomes.com/find-your-home/iowa/cedar-rapids-metro/marion/bridge-creek"))minPrice="$300,000";
		//if(comUrl.endsWith("find-your-home/iowa/cedar-rapids-metro/marion/bowman-meadows"))pstatus += ", Daylight And Walk Out Homesites Available";
		if(comUrl.contains("https://www.skogmanhomes.com/find-your-home/iowa/cedar-rapids-metro/cedar-rapids/knollwood"))minPrice="$262,500";
//		if(comUrl.contains("https://www.skogmanhomes.com/find-your-home/iowa/cedar-rapids-metro/marion/bowman-meadows-villas"))pstatus = "Lots Now Available, "+pstatus;//Img
		
		String lotIds = "";
		String lotMaUrl = U.getSectionValue(html, "$(\"#interactive-siteplan iframe\").attr('src', '", "'");
		U.log(lotMaUrl);
		if(lotMaUrl!=null) {
			String mapHtml = U.getPageSource(lotMaUrl);
			String lotIdSec = U.getSectionValue(mapHtml, "VIP.Main.setup('", "'");
			U.log(lotIdSec);
			mapHtml =U.getHTML("https://contradovip.com/site.get.php?rid="+lotIdSec);
			lotIds = Util.matchAll(mapHtml, " displayname=\"Homesite ", 0).size()>0?Util.matchAll(mapHtml, " displayname=\"Homesite ", 0).size()+"":ALLOW_BLANK;
		}
		if(lotIds.length()<2)lotIds=ALLOW_BLANK;
		//if(comUrl.contains("https://www.skogmanhomes.com/find-your-home/iowa/cedar-rapids-metro/cedar-rapids/kirkwood-village"))pstatus="New Paving Coming Spring 2021";//Img
		pstatus =pstatus.replace("New Lots Now Available, Now Available", "New Lots Now Available");
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
		j++;
//	}catch(Exception e){}
	}

	private String getPlanData(String cHtml) throws IOException {
		String allData=ALLOW_BLANK;
		String planUrls[]=U.getValues(cHtml,"<div class=\"modelimageholder\">" ,"class=\"gtm-modeldetail\">");
		for(String planUrl : planUrls){
			planUrl="https://www.skogmanhomes.com"+U.getSectionValue(planUrl, "<a href=\"", "\"");
			U.log("PlanUrls::::::"+planUrl);
			String planHtml=U.getHTML(planUrl);
			allData=U.getSectionValue(planHtml, "<div class=\"tab-pane fade show active\"", "<div class=\"newsletter\">")+allData;
//			if(allData.contains("SINGLE FAMILY")){
//				break;
//			}
		}
				return allData;
	}

}