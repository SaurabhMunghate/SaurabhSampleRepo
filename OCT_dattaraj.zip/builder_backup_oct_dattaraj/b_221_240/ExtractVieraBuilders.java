package com.shatam.b_221_240;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
/**
 * @author Rakesh Chaudhari
 * @date 08-07-2015
 * 
 */
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.AddSelection;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractVieraBuilders extends AbstractScrapper {
	static String BASEURL = "https://www.vierabuilders.com";
	WebDriver driver = null;
	CommunityLogger LOGGER;
	/**
	 * @param args
	 * @throws Exception
	 */
	int j = 0;
	HashMap<String, String> addrss = new HashMap<String, String>();

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractVieraBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Viera Builders.csv", a.data().printAll());
	}

	public ExtractVieraBuilders() throws Exception {

		super("Viera Builders", BASEURL);
		LOGGER = new CommunityLogger("Viera Builders");
	}

	public void innerProcess() throws Exception {

		int count = 0;

		U.setUpGeckoPath();
		driver = new FirefoxDriver();

		String html = U.getHTML(BASEURL);
		String[] comSec = U.getValues(html, "class=\"CommunityCard_media\"", "Visit Neighborhood");
		U.log("comSec=="+comSec.length);
		for (String com : comSec) {

			String comUrl = U.getSectionValue(com, "href=\"", "\"");
			comUrl = BASEURL + comUrl;
			try {
				addCommunity(comUrl, com);
			} catch (Exception e) {}

		}

		// getAddress();

		// U.log(urls_section);
		// String community_urls_names[] = U.getValues(urls_section, "<a href=\"",
		// "\"");
		// for (String url_name : community_urls_names) {
		// U.log("count: "+count);
		// boolean flag = url_name.endsWith("single-family-homes/")
		// | url_name.endsWith("photo-gallery/")
		// | !url_name.contains("http");
		// if (!flag) {
		// //U.log("Community Link: " + url_name);
		// addDetails(url_name);
		// count++;
		//
		// }
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}

	}

	private void addCommunity(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
//	try{
		{
			
//			if(!comUrl.contains("https://www.vierabuilders.com/communities/avalonia"))return;

			
			U.log("\nCount: " + j);
			
			U.log(comUrl);
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl("repeated ***********"+comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			
			//========= Single Run ===========================================================================
			
			String rmsec  = U.getSectionValue(html, "><script>window.__PRELOADED_STATE__ = {", "</htm");
			html=html.replace(rmsec, "");
			// ============ ComName =============
			String comName = U.getSectionValue(com, "alt=\"", "\"");

			if (comName == null) {
				comName = U.getSectionValue(html, "<h1 class=\"DetailHeader_heading\"", "<br");

				comName = U.getNoHtml(comName);
				comName = comName.replaceAll("data-reactid=\"\\d+\">", "").trim();
			}

			comName = comName.replaceAll("- CLOSEOUT|- Closeout", "");
			U.log("ComName: " + comName);

			// ========== Address =======================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "Model Home</strong>", "</strong>");

			if (addSec != null) {

				addSec = Util.match(addSec, ".*<a href=");
				if (addSec != null)

					addSec = addSec.replaceAll("<br data-reactid=\"\\d+\"/>", ",").trim()
							.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->|<a href=", "");
				add = U.getAddress(addSec);
			}

			add[0] = add[0].replaceAll(",", "");
			U.log("Address: " + Arrays.toString(add));

			// ========== Latlong ===============
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };

			String latSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place/", "/");
			if (latSec != null) {
				latlng = latSec.split(",");
			}

			U.log("Latlng: " + Arrays.toString(latlng));

			if (add[0] == ALLOW_BLANK || add[0].length() < 3) {

				add = U.getAddressGoogleApi(latlng);
				geo = "TRUE";
				U.log("Google Address: " + Arrays.toString(add));
			}
			if (latlng[0] == ALLOW_BLANK || latlng[0].length() < 5) {

				latlng = U.getlatlongGoogleApi(add);
				U.log("Google Latlng: " + Arrays.toString(latlng));
				geo = "TRUE";
			}

			// =========== Quick Move=========
			String quickHtml = getHtml("https://www.vierabuilders.com/homes", driver);
			String quikData = "";
			String[] quickSec = U.getValues(quickHtml, "HomeCard_content", "View Details");
			U.log("Quick Section: " + quickSec.length);

			for (String quick : quickSec) {

				if (quick.contains(comName)) {

					String qUrl = U.getSectionValue(quick, "href=\"", "\"");
					if (qUrl != null) {

						qUrl = BASEURL + qUrl;
						U.log("Quick Url: " + qUrl);
						try {
							quikData += U.getSectionValue(U.getHTML(qUrl), "About This Home", "</div>") + quick;
						} catch (Exception e) {
							// TODO: handle exception
						}
					}
				}
			}

			// ============ Floor Data ===============
			String[] floorSec = null;
			if(html.contains("View Plan Details"))
					floorSec = U.getValues(html, "PlanCard_content", "View Plan Details");

			String floorData = "";
			if(floorSec!=null)
			for (String floor : floorSec) {

				String fUrl = U.getSectionValue(floor, "href=\"", "\"");
				if (fUrl != null) {

					fUrl = BASEURL + fUrl;	
					U.log("Floor Url: " + fUrl);
					try {
						floorData += U.getSectionValue(U.getHTML(fUrl), "About This Plan", "</div>") + floor;
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}

			// ============= Price =================
			html = html.replace("low $400’s", "Low $400,000").replaceAll("0's|0’s|0s", "0,000");

			String[] price = U.getPrices(html + com + quikData + floorData, "mid \\$ \\d{3},\\d{3}|Starting At: </span>\\$d{3},\\d{3}|from the low \\$ \\d{3},\\d{3}|-->\\$\\d{3},\\d{3}<!--|\\$\\d{3},\\d{3}",
					0);

			price[0] = (price[0] == null) ? ALLOW_BLANK : price[0];
			price[1] = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("Price: " + Arrays.toString(price));

			// =============== Sqft =============
			String[] sqft = U.getSqareFeet(com + html + quikData + floorData, " \\d{4} sq. ft. of living space|\">\\d,\\d{3}</strong></span><span class=\"HomeCard_iconListValue|\\d,\\d{3} – \\d,\\d{3} square feet.|\\d{4} Sq. Ft. to \\d{4} Sq. Ft.|\\d{4} Square Feet to \\d{4} Square Feet|-->\\d,\\d{3}<!--", 0);

			sqft[0] = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			sqft[1] = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("Square Feet: " + Arrays.toString(sqft));

				
			
			// ================== remove ==========
			String remove = U.getSectionValue(html, "__PRELOADED_STATE__", "</body>");
			
			if (remove != null)
				html = html.replace(remove, "");
			html = U.getNoHtml(html);

		
			// ========= Com TYpe =========
				html =html.replace("Beautiful waterfront lots", "waterfront community");
						String comType = U.getCommType(html);
						U.log("Community Type: " + comType);
			
			// ======== Property Type ===========
						
			html = html.replaceAll("styled Farmhouse lighting|details to chance, from traditional Craftsman columns|Craftsman, Modern Coastal, and Farmhouse elevations|Farmhouse elevations", "").
					replaceAll("Estates Series and the Mediterranean Series", "Estates homes Series and the Mediterranean Series")
					.replace("featuring an all new Modern Coastal design", "featuring an all new Modern Coastal Classic design")
					.replace("These customizable homes showcase a luxurious array", "These customizable homes showcase a luxury homes array");
						
			String propType = U.getPropType(html + quikData + floorData);
			U.log("Property Type: " + propType);

			// ========== Derived Type ============
			html=html.replace("  1   Stories ", "1 story").replaceAll("  (\\d)\\s+Stories", " $1 Stories");

			String dType = U.getdCommType((html + quikData + floorData).replaceAll("Floor", "").replaceAll("Spanish Colonial Tile Roof", ""));
			U.log("Derived Type: " + dType);
//			U.log(Util.matchAll(html, "[\\w\\s\\W]{30}stor[\\w\\s\\W]{30}",0));

			// ====== Status =============
			html = html.replace("More premium lots are available", "More premium lots available")
					.replaceAll("Quick Move-(i|I)n", "");
		//	String quisec=U.getSectionValue(html, "class=\"HeaderMenu_menuItem HeaderMenu_singleItem\"", "</li>");
//			U.writeMyText(html);
			String status = U.getPropStatus(html + com+comName);
			U.log("Status: " + status);
//        if(comUrl.contains("https://www.vierabuilders.com/communities/kerrington-closeout")) {
//        	status=status.replace(", Quick Move-ins", "");
//        }
//        else {
//        	if(status.length()>4) {
//        		status=status+", Quick Move-Ins";
//        	}
//        	else {
//        		status="Quick Move-Ins";
//        	}
//        }
			if (quikData.length() > 5) {

				if (!status.contains("Quick")) {

					if (status.length() < 3)
						status = "Quick Move-In";
					else
						status = status + ", Quick Move-In";
				}
			}
			
			
			//==========siteMap
			String lotCount=ALLOW_BLANK;
//			try {
			String comName2=comName;
			
			if(html.contains("Site Map")) {
			comName2=comName2.replace("The ", "");
			String siteUrl="https://nexus.anewgo.com/api/graphql_gateway";
			String lotInfo=sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", 
					"{\"operationName\":\"GetCommunityByNameLite\",\"variables\":{\"clientName\":\"vierabuilders\",\"communityName\":\""+comName2+"\"},\"query\":\"query GetCommunityByNameLite($clientName: String!, $communityName: String!) {\\n  communityByName(clientName: $clientName, communityName: $communityName) {\\n    ...CommunityFields\\n    siteplans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      lotMetric\\n      src\\n      geoInfo(clientName: $clientName) {\\n        id\\n        __typename\\n      }\\n      lotLegend(clientName: $clientName) {\\n        id\\n        code\\n        name\\n        hex\\n        __typename\\n      }\\n      __typename\\n    }\\n    stdFeatureCategories(clientName: $clientName) {\\n      id\\n      name\\n      features(clientName: $clientName, communityName: $communityName) {\\n        id\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment CommunityFields on Community {\\n  id\\n  name\\n  thumb\\n  bonafide\\n  buildYourLot\\n  caption\\n  colormtd\\n  description\\n  pricing\\n  logo\\n  longitude\\n  latitude\\n  address\\n  sortType\\n  sortOrder\\n  primarySiteplan(clientName: $clientName, active: true) {\\n    id\\n    lotMetric\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    __typename\\n  }\\n  cityLocation(clientName: $clientName) {\\n    id\\n    name\\n    customName\\n    stateCode\\n    zip\\n    postCode\\n    __typename\\n  }\\n  agents(clientName: $clientName) {\\n    id\\n    email\\n    phone\\n    firstName\\n    lastName\\n    picture\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
			U.log("Lot Info "+lotInfo);
			
			JsonParser parser=new JsonParser();
	        JsonObject arr=parser.parse(lotInfo).getAsJsonObject().get("data").getAsJsonObject();
	        String commID=U.getSectionValue(arr.toString(), "communityByName\":{\"id\":", ",\"");
	        U.log("commID:: "+commID);
	        String lotData=sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", 
					"{\"operationName\":\"GetSiteplanLiteByCommunityId\",\"variables\":{\"clientName\":\"vierabuilders\",\"communityId\":"+commID+"},\"query\":\"query GetSiteplanLiteByCommunityId($clientName: String!, $communityId: Int!) {\\n  activeSiteplanByCommunityId(clientName: $clientName, communityId: $communityId, master: false) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    ...HotspotsFields\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      garagePosition\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    subSiteplans(clientName: $clientName, active: true) {\\n      id\\n      name\\n      info(clientName: $clientName) {\\n        siteplanId\\n        thumb\\n        fontSize\\n        x\\n        y\\n        whiteLabel\\n        showsThumb\\n        __typename\\n      }\\n      lots(clientName: $clientName) {\\n        id\\n        communityId\\n        salesStatus\\n        inventory(clientName: $clientName) {\\n          id\\n          communityId\\n          lotId\\n          planId\\n          elevationId\\n          __typename\\n        }\\n        excludedPlanElevations(clientName: $clientName) {\\n          planId\\n          elevationId\\n          planName\\n          planDisplayName\\n          elevationCaption\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment HotspotsFields on Siteplan {\\n  hotspots {\\n    id\\n    siteplanId\\n    name\\n    x\\n    y\\n    description\\n    thumb\\n    assets {\\n      id\\n      listIndex\\n      src\\n      description\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
	        JsonParser parser1=new JsonParser();
	        JsonObject arrobj=parser1.parse(lotData).getAsJsonObject().get("data").getAsJsonObject().get("activeSiteplanByCommunityId").getAsJsonObject();//.get("subSiteplans").getAsJsonObject()
//	        U.log("Arr:: "+arrobj.toString());
	        if(!arrobj.toString().contains("\"subSiteplans\":null"))
//	        int s=arrobj.get("subSiteplans").getAsJsonArray().size();
//	        U.log("Arr:: "+s);
//	        if(s>0) 
	        {
	        	JsonArray arr1=arrobj.get("subSiteplans").getAsJsonArray();
	        JsonArray lots1;
	        int sum=0;
	        for(int i=0;i<arr1.size();i++) {
	        	 lots1=arr1.get(i).getAsJsonObject().get("lots").getAsJsonArray();
//	        	 U.log("Arr:: "+lots1.size());
	        	 for(int j=0;j<lots1.size();j++) {
	 	        	JsonObject lot1=lots1.get(j).getAsJsonObject();
//	 	        	 U.log("Arr:: "+lot1.toString());
	 	        	String a=lot1.toString();
	 	        	if(!a.contains("\"salesStatus\":\"UNRELEASED\"")) {
	 	        		sum++;
	 	        	}
	 	        }
	        }
	        lotCount=Integer.toString(sum);
	        }
	        else 
	        {
	        	JsonArray ar=arrobj.get("lots").getAsJsonArray();
	        	U.log("Arr:: "+ar.size());
	        	 lotCount=Integer.toString(ar.size());
	        }
	        
	        
	       
//	        String []lot_Data=U.getValues(arr1.toString(), "\"lots\":[", "")
		    
//	        int lotdata=0;
//	        lotdata=arr.size();
//	        
	        U.log("lotCount==="+lotCount);
//	        lotCount=Integer.toString(lotdata);
	        
//	        if(lotCount.equals("0")) {
//	        	String siteMapIFrame=U.getSectionValue(html, "<iframe title=\"Home Designer\"", "</iframe>");
//	        	U.log("IFRAME"+siteMapIFrame);
//	        }
			
	        if(lotCount.equals("0"))
	        	lotCount=ALLOW_BLANK;
			}
//			}catch(Exception e) {}
			// ==========================================
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
			data.addPrice(price[0], price[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(status.replace(", Quick Move-ins, Quick Move-Ins", ", Quick Move-Ins").replace("Quick Move-ins, Quick Move-Ins", "Quick Move-Ins"));
			data.addNotes(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(lotCount);
			
		}
		j++;
//	}catch(Exception e){}
	}

	private String getHtml(String url, WebDriver driver2) throws Exception {
		String html = null;
		String Dname = null;
		// driver.navigate().to(url);
		// driver.manage().deleteAllCookies();
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();

		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{
			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.manage().window().maximize();
					driver.get(url);
					// U.log("after::::"+url);
					Thread.sleep(5000);

					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,document.body.scrollHeight)", "");

					try {

						WebDriverWait wait = new WebDriverWait(driver, 20);

						while (driver.findElements(By.xpath("//*[@id=\"mainContent\"]/div[3]/div[4]/div[2]/button"))
								.size() > 0) {
							wait.until(ExpectedConditions.visibilityOf(driver
									.findElement(By.xpath("//*[@id=\"mainContent\"]/div[3]/div[4]/div[2]/button"))));
							// Thread.sleep(2000);
							WebElement loadBtn = driver
									.findElement(By.xpath("//*[@id=\"mainContent\"]/div[3]/div[4]/div[2]/button"));// --------//load
																													// more
																													// button
							loadBtn.click();
							U.log(":::::::::::::CLick Success:::::::::::::::");
							Thread.sleep(5000);

							((JavascriptExecutor) driver).executeScript("window.scrollBy(0,document.body.scrollHeight)",
									"");
						}
					} catch (Exception e) {
						U.log(":::::::::::::CLick UnSuccess:::::::::::::::" + e.getMessage());
					}

					Thread.sleep(8000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
	
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36");
	      //  connection.setRequestProperty("referer", "https://myhome.anewgo.com/client/vierabuilders/community/Rutherford%20Collection%20at%20Reeling%20Park/siteplan");
	        connection.setRequestProperty("path", "/api/graphql_gateway");
	        connection.setRequestProperty("date", "Thu, 23 Jun 2022 05:04:55 GMT");
	        connection.setRequestProperty("Content-Type", "application/json");
	        connection.setRequestProperty("authority", "nexus.anewgo.com");
//	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1MzM1ODI0MCwiZXhwIjoxNjUzNDAxNDQwfQ.xgZFAjGJpO5eqQmZIqQRycuQjUvLzbDZAIjq2tMMMC8");
	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1NTk2MDY5MywiZXhwIjoxNjU2MDAzODkzfQ.jVtdzcg_sTdIuXUdaB-gKfOxlVfQ0K7PL67myon573E");

	        connection.setRequestProperty("accept", "*/*");
//	        connection.setRequestProperty("accept-encoding", "gzip, deflate, br");
	        connection.setRequestProperty("accept-language", "en-GB,en-US;q=0.9,en;q=0.8");
	      
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	

	// addDetails("https://www.vierabuilders.com/view-our-neighborhoods/single-family-townhomes/stadium-villas/about-stadium-villas/");

	private String[] getPrices(String commUrl) throws IOException {

		String comHtml = U.getHTMLwithProxy(commUrl);
		String html1 = "";

		if (commUrl.contains("https://www.vierabuilders.com/about-reeling-park/")) {
			html1 = U.getHTMLwithProxy(
					"https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/reeling-park/reeling-park-quick-move-in-homes/");
		}
		if (commUrl.contains("trasona-cove-east/")) {
			html1 = U.getHTMLwithProxy(
					"https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/trasona-cove-east/trasona-cove-east-quick-move-in-homes/");
			html1 = html1 + U.getHTMLwithProxy(
					"https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/trasona-cove-east/trasona-cove-east-neighborhood-map/");
		}
		comHtml = comHtml.replace("0�s", "0,000MyPrice");
		comHtml = comHtml.replaceAll("0's|0&#8242;s|0&#8217;s", "0,000");
		String commUrl1 = commUrl.replace("about-", "");
		// floor Link
		String linkfloorPlane = commUrl1 + "-floor-plan";
		linkfloorPlane = linkfloorPlane.replace("/-", "-");
		String flowHtml = U.getHTMLwithProxy(linkfloorPlane);

		// Quick move Home link
		String linkquick = ALLOW_BLANK;
		U.log("Community Link: " + commUrl);

		if (commUrl.contains("stadium-villas") || commUrl.contains("kerrington"))
			linkquick = commUrl1 + "-quick-move-homes";
		else if (commUrl.contains("about-stonecrest/"))
			linkquick = "https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/stonecrest/stonecrest-quick-move-homes/";
		else if (commUrl.contains("about-reeling-park/"))
			linkquick = "https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/reeling-park/reeling-park-quick-move-in-homes/";
		else
			linkquick = commUrl1 + "-quick-move-in-homes";

		linkquick = linkquick.replace("/-", "-");

		String quickHtml = U.getHTMLwithProxy(linkquick);
		comHtml = comHtml.replaceAll("’s|�s", ",000");
		String[] prices = { ALLOW_BLANK, ALLOW_BLANK };

		if (quickHtml != null)
			quickHtml = quickHtml.replace("Sales Price |", "Sales Price")
					.replace("Stories</div><div class=\"right-map\">", "Story");
		if (flowHtml != null)
			flowHtml = flowHtml.replace("Sales Price |", "Sales Price")
					.replace("Stories</div><div class=\"right-map\">", "Story");

		prices = U.getPrices(flowHtml + quickHtml + comHtml + html1,
				"Sales Price \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d+,\\d+</div>|\\$\\d+,\\d+|Mid \\$\\d+,\\d{3}", 0);

		prices[0] = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		prices[1] = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		return prices;

	}

	String total = ALLOW_BLANK;

	private String[] getSqft(String commUrl) throws IOException {

		String comHtml = U.getHTMLwithProxy(commUrl);
		String html1 = "";
		if (commUrl.contains("https://www.vierabuilders.com/about-reeling-park/")) {
			html1 = U.getHTMLwithProxy(
					"https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/reeling-park/reeling-park-quick-move-in-homes/");
		}
		if (commUrl.contains("https://www.vierabuilders.com/about-trasona-cove-east/")) {
			html1 = U.getHTMLwithProxy(
					"https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/trasona-cove-east/trasona-cove-east-quick-move-in-homes/");
		}
		commUrl = commUrl.replace("about-", "");

		// floor Link
		String linkfloorPlane = commUrl + "floor-plans/";

		linkfloorPlane = linkfloorPlane.replace("/floor", "-floor");

		// U.log("floorUrl:::"+linkfloorPlane);
		String flowHtml = U.getHTML(linkfloorPlane);

		// Quick move Home link
		String linkquick = ALLOW_BLANK;
		if (commUrl.contains("stadium-villas"))
			linkquick = commUrl + "-quick-move-homes";
		else if (commUrl.contains("stonecrest/about-stonecrest/")) {
			linkquick = "https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/stonecrest/stonecrest-quick-move-homes/";
		} else
			linkquick = commUrl + "-quick-move-in-homes";

		linkquick = linkquick.replace("/-", "-");
		String quickHtml = U.getHTMLwithProxy(linkquick);

		total = flowHtml + quickHtml;
		String[] sqFt = { ALLOW_BLANK, ALLOW_BLANK };

		comHtml = comHtml.replace(" &#8211; ", " - ");
		// U.log(comHtml);
		sqFt = U.getSqareFeet(flowHtml + quickHtml + comHtml + html1,

				"\\d{1},\\d{3} - \\d{1},\\d{3} square feet|\\d{4} Sq. Ft|\\d{4} Square Feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|SQ.FT.</div><div class=\"right-map\">\\d+,\\d+|SQ.FT.</div>\\s+<div class=\"right-map\">\\d+,\\d+",
				0);

		sqFt[0] = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		sqFt[1] = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

		return sqFt;

	}

	private String[] getAddress() throws IOException {
		String linkDir = "https://www.vierabuilders.com/directions/";
		String html = U.getHTMLwithProxy(linkDir);
		String sec = U.getSectionValue(html, "mapp.data.push(", ");");
		sec = StringEscapeUtils.unescapeJava(sec);
		// U.log("###############"+sec+"***********");
		String values[] = U.getValues(sec, "!important;", "url\"");

		// U.log(html);

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

		U.log(values.length);

		for (String addSec : values) {
			// U.log("address: " + addSec);

			String name = U.getSectionValue(addSec, "title\":\"", "\"");
			name = name.replace("Village Office", "Village");
			U.log(":" + name + ":");

			// U.log("address: " + add[0]);
			addrss.put(name, addSec);

			// break;
		}

		return null;
	}

	public void addDetails(String commUrl) throws Exception {

		// ............................Community Url...........................
		U.log("Page Url: " + commUrl);

		// if(!commUrl.contains("https://www.vierabuilders.com/about-trasona-cove-east/"))return;
		if (commUrl.contains(
				"https://www.vierabuilders.com/view-our-neighborhoods/single-family-townhomes/stadium-villas/about-stadium-villas/"))
			return; // 404 Error- Page Not Found
		// ...........................Community Name...........................

		String html = U.getHTMLwithProxy(commUrl);

		// comm Name
		String commName = ALLOW_BLANK;

		commName = U.getSectionValue(html, "<i>A</i>bout", "</h1>");

		U.log("commName::" + commName);

		// Add

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addSec = ALLOW_BLANK;
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
		String flag = "FALSE";
		String note = ALLOW_BLANK;
		note = U.getnote(html);
		U.log("Community NAme: " + commName);

		String addLLSec = addrss.get(commName.trim().replaceAll(" East| West", ""));
		U.log(addLLSec);
		if (addLLSec != null) {
			addSec = U.getSectionValue(addLLSec, "\">", "</div>");
			if (addSec != null) {
				addSec = addSec.replaceAll("Mecina Model<br />\\s*", "");
				addSec = addSec.replace("<br />", ",");
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}
			latLng[0] = U.getSectionValue(addLLSec, "lat\":", ",");
			latLng[1] = U.getSectionValue(addLLSec, "lng\":", "}");
			U.log(Arrays.toString(latLng));
		}
		if (latLng[0] == null && add[0].length() > 4) {
			latLng = U.getlatlongGoogleApi(add);
			if (latLng == null)
				latLng = U.getlatlongGoogleApi(add);
		}
		// U.log("HHHh"+add[0]+" "+add[1]+" HHHH");

		if (commUrl.contains("stonecrest") || commUrl.contains("sierra-cove")) {
			add = new String[] { "Addison Drive", "Vierra", "FL", "32940" };
			latLng = U.getlatlongGoogleApi(add);
			if (latLng == null)
				latLng = U.getlatlongGoogleApi(add);
			flag = "TRUE";
			note = "Address and Lat-Lng Taken Using Community Map Details";
		}
		if (commUrl.contains("stadium-villas")) {
			add = new String[] { "Sedge drive", "Vierra", "FL", "32955" };
			latLng = U.getlatlongGoogleApi(add);
			if (latLng == null)
				latLng = U.getlatlongGoogleApi(add);
			flag = "TRUE";
			note = "Address and Lat-Lng Taken Using Community Map Details";
		}
		// Price

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] prices = getPrices(commUrl);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		// Sqft

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sqFt = getSqft(commUrl);
		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

		// Community Type
		String communitytype = U.getCommunityType(html);
		// html=html.replaceAll("Single-Family Townhomes|single-family-townhomes|Stadium
		// Villas|stadium-villas|villa|Villa", "");
		html = html.replaceAll("Single-Family Townhomes|single-family-townhomes|Stadium Villas|stadium-villas", "");

		// Property Type
		html = html.replace("Estates Series", "Estate style homes").replaceAll("single-family-townhomes|Villas|villas",
				"");
		String proptype = U.getPropType(commUrl + html + commName);

		// Derive Prop
		if (commUrl.contains("https://www.vierabuilders.com/about-reeling-park/"))
			html = html + " 2 story ";
		html = html.replace("one and two story ", " 1 Story   2 Story ");
		total = total.replaceAll("Stories</div>\\n*\\s*<div class=\"right-map\">", "Story ");
		String dtype = U.getdCommType((html + total).replaceAll("(F|f)loor", ""));

		html = html.replace("premium lots are available", "premium lots available");
		// Status
		String propstatus = U.getPropStatus(html);
		// U.log("MMMMMMMMMMMMMMM "+Util.matchAll(total,
		// "[\\s\\w\\W]{30}Story[\\s\\w\\W]{30}", 0));

		if (html.contains("Quick</span> Move-In Homes</a></li>")) {
			if (commName.contains("Reeling Park"))
				commUrl = "https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/reeling-park/about-reeling-park/";
			if (commName.contains("Trasona Cove East"))
				commUrl = "https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/trasona-cove-east/about-trasona-cove-east/";

			String qlink = commUrl + "-quick-move-in-homes/";

			if (commName.contains("Stadium Villas"))
				qlink = qlink.replace("quick-move-in-homes", "quick-move-homes");
			qlink = qlink.replace("/-", "-").replace("about-", "");
			if (commUrl.contains("/stonecrest/about-stonecrest/"))
				qlink = "https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/stonecrest/stonecrest-quick-move-homes/";

			String qHtml = U.getHTMLwithProxy(qlink);
			if (qHtml != null) {
				if (propstatus.length() > 2) {
					if (qHtml.contains("floor-plan clearfix")) {
						propstatus = propstatus + ", Quick Move-In Homes";
					} else {
						propstatus = propstatus + ", No Quick Move-In Homes";
					}
				} else {
					if (qHtml.contains("floor-plan clearfix")) {
						propstatus = "Quick Move-In Homes";
					} else {
						propstatus = "No Quick Move-In Homes";
					}
				}
			}
		}

		if (latLng[0] == null) {
			latLng[0] = latLng[1] = ALLOW_BLANK;
		}

		if (commUrl.contains("about-kerrington")) {
			propstatus = "Quick Move-In Homes";
			maxPrice = "$684,101";
			proptype = proptype + ", Estate-Style Homes, Mediterranean Style Homes";
		}
		// if(commUrl.contains("https://www.vierabuilders.com/view-our-neighborhoods/single-family-homes/arrivas-village/about-arrivas-village/"))
		// {flag="TRUE";}
		if (commUrl.contains("https://www.vierabuilders.com/about-trasona-cove-east/"))
			dtype = dtype + "1 Story";
		if (commUrl.contains(
				"https://www.vierabuilders.com/view-our-neighborhoods/single-family-townhomes/loren-cove/about-loren-cove/"))
			dtype = "1 Story";
		if (commUrl.contains("/single-family-homes/reeling-park/about-reeling-park/")) {
			minPrice = "$351,900";
			maxPrice = "$532,900";
		}

		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(note);
		j++;
	}
}