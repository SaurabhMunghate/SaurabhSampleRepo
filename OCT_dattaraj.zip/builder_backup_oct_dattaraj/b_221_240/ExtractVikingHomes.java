/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.IOException;

import org.jboss.netty.util.HashedWheelTimer;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractVikingHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static String builderUrl = "https://vikinghomes.com/";
	public ExtractVikingHomes()	throws Exception {
		super("Viking Homes", builderUrl);
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Viking Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractVikingHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Viking Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://vikinghomes.com/north-idaho-communities/");
		
		String[] regUrl=U.getValues(mainHtml, "<div class=\"elementor-image-box-wrapper\">","</div>");
		U.log(regUrl.length);
		for(String reg:regUrl)
		{
			String comUrl=U.getSectionValue(reg, "href=\"", "\"");
			addDetails(comUrl.replace("http:", "https:"));
			
		}
		
	}
	int i=0;
	private void addDetails(String comUrl) throws Exception {
//		try{
//		if(!comUrl.contains("https://vikinghomes.com/montrose-post-falls/")) return;
//		if(j>=6)
		{
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHTML(comUrl);
		
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(html, "<title>","|");
		communityName = communityName.replace(" | ", " ");
		communityName=U.getNoHtml(communityName);
		communityName=communityName.replaceAll("Limited Supply Left|<p class=\"btn","");
		U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		String addSec=U.getSectionValue(html, "Address:","</p>");
		U.log(addSec);
		if(addSec!=null) {
			 addSec=addSec.replaceAll("<br />|</strong>","");
			 String[] add1=addSec.split(",");
			 if(add1.length>2) {
				 add[0]=add1[0];
				 add[1]=add1[1];
				 add[3]=Util.match(add1[2],"\\d{4,}");
				 if(add[3]!=null) {
				 add[2]=add1[2].replace(add[3],"").trim();
				 }
				 else {
					 add[2]=add1[2];
				 }
			 }
			 else if(add1.length==2) {
				 add[1]=add1[0];
				 add[3]=Util.match(add1[1],"\\d{4,}");
				 add[2]=add1[1].replace(add[3],"").trim();
			 }
		 }
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
		if(html.contains("center_lat\":")) {
			latlag[0]=U.getSectionValue(html, "center_lat\":\"","\"");
			latlag[1]=U.getSectionValue(html, "center_lng\":\"","\"");
		}//-116.874169
		if(comUrl.contains("https://vikinghomes.com/timber-glade-rathdrum-idaho/"))
		{
			latlag[1]="-116.874169";
		}
		if(comUrl.contains("westwood-pines-rathdrum-idaho/"))
		{
			latlag[1]="-116.86672";
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK){
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK){
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		}
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		
		//============================================Price and SQ.FT======================================================================
				
				
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			html=html.replaceAll("0s|0's|0&#8217;s|0s|0k's","0,000");
			String prices[] = U.getPrices(html,"Priced from \\$\\d+,\\d+ to \\$\\d+,\\d+|price\">\\$\\d+,\\d+|the \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}", 0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
				
				
		String[] sqft = U.getSqareFeet(html,"\\d{3,} SF|\\d{4} sq ft ",0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		//============== Ready To Own Section ==============
		String readyToOwnSec = U.getSectionValue(html, "<div class=\"listings_available-slides\">", "<div class=\"testimonial-slider\">");
		String combinedReadyOwnHomeHtml = null;
		if(readyToOwnSec != null){
			String [] readyToOwnHomeUrls = U.getValues(readyToOwnSec, "<h3 class=\"name\"><a href=\"", "\"");
			for(String readyToOwnHomeUrl : readyToOwnHomeUrls){
				U.log("home  :: "+builderUrl+readyToOwnHomeUrl);
				String homeHtml = U.getHTML(builderUrl+readyToOwnHomeUrl);
				combinedReadyOwnHomeHtml += U.getSectionValue(homeHtml, "_full_description\">", "</div>");
			}
		}
		
		
		
		//============== Ready To Build Section ==============
		String readyToBuildSec = U.getSectionValue(html, "<h2>Ready To Build</h2>", "<div class=\"column small-6\">");
		String combinedReadyToBuildData = null;
		//int readyHomeCount = 0;
		if(readyToBuildSec != null){
		String [] readyToBuildHomeUrls = U.getValues(readyToBuildSec, "<h3 class=\"name\"><a href=\"", "\"");
		//readyHomeCount = readyToBuildHomeUrls.length;
		for(String readyToBuildHomeUrl : readyToBuildHomeUrls){
			U.log("Ready to Build home  :: "+builderUrl+readyToBuildHomeUrl);
			String homeHtml = U.getHTML(builderUrl+readyToBuildHomeUrl);
			combinedReadyToBuildData += U.getSectionValue(homeHtml, " <h2>Home Features</h2>", "</div>");
		}
		}
		//============== FloorPlan Section ==============
				String[] floorPlanSec = U.getValues(html, "<h2 class=\"houzez_section_title\">", "Floor Plan</span>");
//				U.log(floorPlanSec);
				String combinedfloorPlanSecData = null;
				//int readyHomeCount = 0;
				U.log("floorPlanSec  :: "+floorPlanSec.length);
				if(floorPlanSec.length>0){
					for(String fpSec : floorPlanSec) {
				String readyToBuildHomeUrls = U.getSectionValue(fpSec, "<a href=\"", "\"");
//				for(String readyToBuildHomeUrl : readyToBuildHomeUrls){
					U.log("floorPlanSec  :: "+readyToBuildHomeUrls);
					String homeHtml = U.getHTML(readyToBuildHomeUrls);
					U.bypassCertificate();
					combinedfloorPlanSecData += U.getSectionValue(homeHtml, "<h2 class=\"elementor-heading-title elementor-size-default\">", "</section>")+U.getSectionValue(homeHtml, "<h3 class=\"elementor-heading-title elementor-size-default\">Floor Plan</h3>", "</section>");
				}
				}
		//<h2 class=\"elementor-heading-title elementor-size-default\">Floor Plans in", "</section>
		//================================================community type========================================================
	 
		String remsec=U.getSectionValue(html, "</title>", "<script type=\"text/javascript\">");
		html=html.replace(remsec, "");
		String communityType=U.getCommType(html);
//		U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(combinedfloorPlanSecData, "[\\w\\s\\W]{30}flex[\\w\\s\\W]{30}", 0));

				
		//==========================================================Property Type================================================
		
		String proptype=U.getPropType((html+combinedReadyOwnHomeHtml+combinedfloorPlanSecData).replace("Den/flex space", "Den/Flex space").replaceAll("style trim", ""));
				
		//==================================================D-Property Type======================================================
				
		String dtype=U.getdCommType((combinedfloorPlanSecData+html+combinedReadyOwnHomeHtml+combinedReadyToBuildData).replace("second floor", " 2 Story ").replaceAll("Sunset Ranch|Colonial white|Colonial White", ""));
				
		//==============================================Property Status=========================================================
		html=html.replaceAll(">Coming soon. Contact agent|Model home address:Coming soon", "").replace("New Phase is now available", "New Phase now available");
		U.log(Util.match(html,"[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}"));
		html=html.replace("Phase 3 - ONE Home Left", "Phase 3 ONE Home Left");
		String pstatus=U.getPropStatus(html.replaceAll("Model home photos and address: <strong>Coming soon</strong>|Just Released!!<|COMING SOON!!|title=\"Phase 3 - Now Available\"|Phase 3 - Now Available</div>|Soon! Contact|Center Now| <div>Coming Soon | Contact Agent Details</div>|Coming Soon! - Contact Age", ""));
			
		U.log("property status is:::::"+pstatus);
		//============================================note====================================================================
				
		 note=U.getnote(html);
		
//		proptype+=", Loft";
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl);
			k++;
			return;
		}
		//communityName=communityNae.replace("","").trim();
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//		}catch(Exception e){}
	}
	

}