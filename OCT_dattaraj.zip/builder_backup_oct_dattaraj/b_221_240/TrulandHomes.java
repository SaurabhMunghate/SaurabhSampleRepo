package com.shatam.b_221_240;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class TrulandHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public static int i = 0;
	int k = 0;
	static int j=0;
	WebDriver driver= null;
	public int inr = 0;
	private static final String builderUrl = "https://trulandhomes.com";
	public static void main(String[] ar) throws Exception {
		
		AbstractScrapper a = new TrulandHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Truland Homes.csv", a.data().printAll());
	}

	public TrulandHomes() throws Exception {
		super("Truland Homes", "https://trulandhomes.com/");
		LOGGER = new CommunityLogger("Truland Homes");
	}
	
	String homehtml = "";
	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		
		homehtml = U.getHTML("https://trulandhomes.com/neighborhoods/");
		String[] comSec = U.getValues(homehtml, "class=\"col-12 mb-3 px-0\"", "gold my-2");
		U.log(comSec.length); 
		for(String com : comSec) {
			
			//U.log("com: "+com); 
			String comUrl = U.getSectionValue(com, "href=\"", "\"");
			if(!comUrl.startsWith("https:")) 
				comUrl="https://trulandhomes.com"+comUrl;
			U.log("comUrl: "+comUrl); 
				
//			try {
				findCommunityDetails(comUrl, com);
//			} catch (Exception e) {}
			
			
			
		}
		//driver.quit();
	}
	private void findCommunityDetails(String communityUrl, String communityInfo)throws Exception{
//		if(i>21)
//		try
		{
		
//		if(!communityUrl.contains("https://trulandhomes.com/new-homes/fl/milton/yellow-river-ranch/8890/")) return;
		
		U.log("Count :"+i);

		
		if(communityUrl.contains("class=\"row"))
			communityUrl = communityUrl.replace("class=\"row", "");
		
		U.log("CommunityUrl : "+communityUrl);	
		U.log(U.getCache(communityUrl));

		
		String commHtml = U.getHTML(communityUrl);
		LOGGER.AddCommunityUrl(communityUrl);
		String communityName = U.getSectionValue(communityInfo,"<div class=\"garamond text-darkgreen fs-3\">", "</div>");
		U.log("Community Name : "+communityName);
		
		if(communityName.contains("Estates")) {
			communityName = communityName.replaceAll(" Estates$", "");
		}
		if(communityName.contains("Ranch")) {
			communityName = communityName.replaceAll(" Ranch$", "");
		}
		
		U.log("Community Name ===== "+communityName);
		
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
//		communityName=communityName.replaceAll("Buxton's", "Buxtons").replaceAll("Mill at Hammock Bay", "Mill");
		communityName=communityName.replaceAll("The Retreat", "Retreat").replaceAll("The Village", "Village").replace("The Reserve at Blackstone Lakes", "Blackstone Lakes");
		U.log("Community Name : "+communityName);
		
		//==================== Address & Lat-Lng  ====================
		String[] add ={ ALLOW_BLANK, ALLOW_BLANK ,ALLOW_BLANK, ALLOW_BLANK }; 
		String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String geo = "FALSE";
		
//		String addSec = U.getSectionValue(communityInfo,"<div class=\"avenir medium fs-6 text-color text-uppercase ls-md\">","</div>");
//		String addSec = U.getSectionValue(commHtml,"Model Home","<a class=\"text-color button");
		
		//-----addresses taken from model home section
		String addSec = U.getSectionValue(commHtml,"avenir medium ls-sm fs-4 mb-2\">","</p>"); 
		
		if(addSec != null) {
			
			addSec = addSec.replace("<br/>", ", ");
			
			U.log("Address Section : "+addSec);
			
			add = U.getAddress(addSec);
			U.log("Address ======= "+Arrays.toString(add));
			
		}
		
		latlng[0]=U.getSectionValue(communityInfo, "data-latitude=\"", "\"");
		latlng[1]=U.getSectionValue(communityInfo, "data-longitude=\"", "\"");
		U.log(Arrays.toString(latlng));
		
		if(add[0] == ALLOW_BLANK && latlng[0] != ALLOW_BLANK) {
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
			
			U.log("GOOGLE ADDRESS ======= "+Arrays.toString(add));
		}

		U.log("========"+Arrays.toString(add));
		
		//==================== Available  & Floor Homes ====================
		String[] homeUrl = U.getValues(commHtml, "<a class=\"card grid overflow-hidden h-100\" href=\"", "/\">");
		String allPlanData="";
		String planHtml="";
		for(String planUrl : homeUrl) {
			if(!planUrl.startsWith("https:"))
				planUrl="https://trulandhomes.com"+planUrl;
			U.log("planUrl: "+planUrl);
			
			planHtml = U.getHTML(planUrl);
			allPlanData += U.getSectionValue(planHtml, "<div class=\"col-12 col-lg-10\">", "<div class=\"pagejump\" id=\"contact\"></div>");
//			U.log(allPlanData);
//			break;
//			break;
		}
		//================ Price ================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commHtml=commHtml.replaceAll("00s|00's", "00,000")
				.replace("starting in the high $200s", "starting in the high $200,000").replace("starting in the high $300s", "starting in the high $300,000");
		
		String[] price = U.getPrices(communityInfo+allPlanData+commHtml, "starting in the high \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|fs-3\">\\$\\d{3},\\d{3}</div>|center\">\\$\\d{3},\\d{3}</div>", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice :" + maxPrice);
		//================ SquareFeet ================
		String minsqf = ALLOW_BLANK, maxsqf = ALLOW_BLANK;
		String[] sq = U.getSqareFeet(communityInfo+commHtml+allPlanData, "<div>\\d,\\d{3} Sq\\. Ft\\.</div>|</span> \\d,\\d{3} - \\d,\\d{3} Sq\\. Ft\\.</div>|</span> \\d,\\d{3} Sq\\. Ft\\.</div>", 0);
		minsqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
		maxsqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];
		U.log("minSqf :" + minsqf + " maxSqf:" + maxsqf);
		//================ Derived Community Type ================
		commHtml = commHtml.replace("and the picturesque Fairhope waterfront", "and the picturesque Fairhope waterfront community")
				.replace("this 10-lot water-view community", "this 10-lot waterfront community");
		
		String ctype = U.getCommunityType(communityInfo+commHtml+allPlanData);		
		U.log("ctype :" + ctype);
		//================ Derived Property Type ================	
		String dtype = U.getdCommType((commHtml+allPlanData).replaceAll("river-ranch/8890|River Ranch</a>", ""));
				
		//=============== Property Type ===================		
		commHtml = commHtml.replace("a traditional small southern neighborhood", "a traditional style small southern neighborhood")
				.replace("home a statement of luxury", "home a statement of luxury living");
		
			

		
		String propType = U.getPropType((commHtml+allPlanData).replaceAll("craftsmanship|villa-del-sol|-village-|Villa Del Sol|Village|-village|village", "").replace("luxury hardwood floors", "Luxury features hardwood floors").replaceAll("\"throw homes together\"", ""));
				
		//=============== Property Status =====================
		int quickCount = 0;
		
		commHtml = commHtml.replaceAll("/quick-move-ins/|View Quick Move-Ins", "");				
		String pStatus = U.getPropStatus((commHtml).replaceAll("Community Pool Coming Late Spring 2023|quick-move-ins/\">|View Quick Move-Ins<div",""));
		
		//for quick move status------------------
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commHtml,"[\\s\\w\\W]{50}Available Fall 2022[\\s\\w\\W]{30}", 0));
		
		if(commHtml.contains("Available Fall 2022")) {
			quickCount++;
		}
		
		U.log("quickCount: "+quickCount);
		
		if(quickCount > 0) {
			if(pStatus == ALLOW_BLANK)
				pStatus = "Quick Move-Ins";
			else if(pStatus != ALLOW_BLANK)
				pStatus = pStatus + ", Quick Move-Ins";	
			}
		//--------------------------------------
		
		U.log("pStatus: "+pStatus);
		
		//------------------------LOT DATA--------------------------
		String lotMapData=ALLOW_BLANK;
		int sum=0;
		String lotCount=ALLOW_BLANK;
		
		
		String mapLinkSec=U.getSectionValue(commHtml, "><iframe class=\"lotvue Phases\"", "</iframe>");
		if(commHtml.contains("COMMUNITY MAP") && mapLinkSec!=null) {
			String lotUrl=U.getSectionValue(mapLinkSec, "src=\"", "\">");
			if(lotUrl!=null)
				lotMapData=U.getHtml(lotUrl,driver);
			U.log("lotUrl ::"+lotUrl);
			String[] lotSection=U.getValues(lotMapData, "Sales Status\"></label>", "</div>\n" + 
					"        </div>");
			U.log("lotSection.length :"+lotSection.length);
			
			for(String lotData : lotSection) {
				lotData=U.getNoHtml(lotData);
				U.log("lotData :"+lotData.trim());
				sum+=Integer.parseInt(Util.match(lotData, "( \\d+ )"));
			}
			
			U.log("sum :"+sum);
			}
		if(sum==0) {
			lotCount=ALLOW_BLANK;
		}
		else {
			lotCount=Integer.toString(sum);
		}
		
			
				note=U.getnote(commHtml+communityInfo);
				data.addCommunity(communityName,communityUrl,ctype);
				data.addAddress(add[0].trim(),add[1].trim(),add[2].trim(),add[3].trim());
				data.addSquareFeet(minsqf, maxsqf);
				data.addPrice(minPrice,maxPrice);
				data.addLatitudeLongitude(latlng[0], latlng[1], geo);
				data.addPropertyType(propType, dtype);
				data.addPropertyStatus(pStatus);
				data.addNotes(note);
				data.addUnitCount(lotCount);
				data.addConstructionInformation(startDt, endDt);
				i++;
	}
//		catch(Exception e) {}
		
}
	
}