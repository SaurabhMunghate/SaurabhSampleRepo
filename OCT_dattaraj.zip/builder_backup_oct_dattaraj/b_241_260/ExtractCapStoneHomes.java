package com.shatam.b_241_260;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCapStoneHomes extends AbstractScrapper {
	public int inr = 0;
	static int j=0;
	String base_url = "https://www.capstonehomes-mn.com/";
	WebDriver driver=null;
	HashMap<String, String> pricedata=new HashMap<>();
	CommunityLogger LOGGER;
	public ExtractCapStoneHomes() throws Exception {
		super("Capstone Homes", "https://www.capstonehomes-mn.com/");		
		LOGGER = new CommunityLogger("Capstone Homes");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractCapStoneHomes();
		
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"Capstone Homes.csv", a.data()	
				.printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver=new ChromeDriver();
	/*	if (driver==null) {
			driver=new ChromeDriver();
		}*/ 
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String html = U.getHTML("https://www.capstonehomes-mn.com/communities");
		html = U.removeComments(html);
		html = html.replaceAll("<!---->", "");
		String comSections [] = U.getValues(html, "<div class=\"CommunityCard_content\"", "</a></div></div></div>");
		U.log(comSections.length);
		for(String comSec : comSections){
			//U.log(comSec);
			comSec = comSec.replace("</span> Quick", " Quick");
			String comLink = "https://www.capstonehomes-mn.com"+ U.getSectionValue(comSec, "CommunityCard_link\" href=\"", "\"");
			String comName = Util.match(comSec, "<h4 data-reactid=\"\\d+\">(.*?)</h4><h5 data-",1);
			//U.log(comName+"\t::\t"+comLink);
//			try {
				addDetails(comName,comLink,comSec);
//			} catch (Exception e) {}
			//break;
		}
		
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}
	//TODO:
	private void addDetails(String comName, String comUrl, String comSec) throws Exception {
		
//		try{
		{
//		if (!comUrl.equals("https://www.capstonehomes-mn.com/communities/riverhills")) return;
			
			U.log(j+"   commUrl-->"+comUrl);
			
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			String html = getHTML(comUrl);
			U.log("CommunitySec>> "+comSec);
			String availHtml = ALLOW_BLANK;
			String allAvailData = ALLOW_BLANK;
			String floorHtml = ALLOW_BLANK;
			String allfloorHtml = ALLOW_BLANK;
			
			String siteMapUrl=ALLOW_BLANK;
			
			int availHomesCount = 0;
			int availQuickCount=0;
			String availUrl=ALLOW_BLANK;
			String pageMenuItems [] = U.getValues(html, "class=\"PageMenu_listItem", "</a>");
			for(String pageMenuItem : pageMenuItems){
				String navUrl = U.getSectionValue(pageMenuItem, "href=\"", "\"");
				U.log("NAV URL "+navUrl);
				if(navUrl.contains("/homes")){
					availHtml = getHTML("https://www.capstonehomes-mn.com"+navUrl);
					//String [] availHomeUrls = U.getValues(availHtml, "<div class=\"css-opsktm", "<style data-emotion-css=");
					String [] availHomeUrls = U.getValues(availHtml, "<div class=\"HomeCard_mediaImageCallout ", "<style data-emotion-css=");
					availHomesCount = availHomeUrls.length;
					U.log("Availabloe homes count"+availHomeUrls.length);
					for(String availHome : availHomeUrls){
						availUrl ="https://www.capstonehomes-mn.com" + U.getSectionValue(availHome, "href=\"", "\"");
						U.log("availUrl : "+availUrl);
						
						allAvailData += getHTML(availUrl);
						if(availHome.contains("Active")&&availHome.contains(comName) ) {
							availQuickCount++;
						}
					}
				}
				if(navUrl.contains("/plans")){
					floorHtml = getHTML("https://www.capstonehomes-mn.com"+navUrl);
					String [] availHomeUrls = U.getValues(floorHtml, "PlanCard_wrapper", "Details");
					U.log(availHomeUrls.length);
					for(String availUrl2 : availHomeUrls){
						availUrl = U.getSectionValue(availUrl2, "href=\"", "\"");
						U.log("floorUrl : "+availUrl);
						availUrl ="https://www.capstonehomes-mn.com"+availUrl;
						U.log("floorlUrl : "+availUrl);
						allAvailData += getHTML(availUrl);
					}
				}
				if(navUrl.contains("/siteplan")) {
					siteMapUrl="https://www.capstonehomes-mn.com"+navUrl;
				}
				
			}
			
			
			//================================================Address section===================================================================
			String note="";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String[] latLng={ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String addSec=U.getSectionValue(html, "<h1 class=\"DetailAddress\" data-reactid=","</span></h1>");
			if(addSec!=null)
			{
				addSec = addSec.replaceAll("\"\\d+\">(.*?)\">", "");
				
				U.log(addSec);
				add = U.getAddress(addSec);
				
			}
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					
					
			//--------------------------------------------------latlng----------------------------------------------------------------
			String latSec=U.getSectionValue(html, "</div><a href=\"https://www.google.com/maps/place/","/@");
			U.log("latSec : "+latSec);
			if(latSec!=null)
			{
				latLng = latSec.split(",");
			}
			U.log("hhhh--->"+latLng[0]+"  "+latLng[1]);
			
			/*if(add[0].length()<4 && latlag[0].length()>4){
				add[0] = U.getAddressGoogleApi(latlag)[0];
				geo = "TRUE";
			}*/
			if (add[0].equals("15026")) {
				add=U.getGoogleAddressWithKey(latLng);
				geo="TRUE";
			}
			floorHtml = floorHtml.replaceAll("<span data-reactid=\"\\s+\">", " ");
			html = html.replaceAll("<span data-reactid=\"\\s+\">", " ");
			availHtml = availHtml.replaceAll("<span data-reactid=\"\\s+\">", " ");
			//allAvailData = allAvailData.replaceAll("Story</li>", "Story </li>");
//			U.log(allAvailData);
			//============================================Price and SQ.FT======================================================================
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html=html.replaceAll("0’s|0s|0S|0's", "0,000");
			//allAvailData=allAvailData.replace("\\$48,990</span>", "");
			html=U.removeComments(html);
//			U.log("JJJ"+Util.matchAll(html+comSec+availHtml+floorHtml +allAvailData, "[\\w\\W\\s]{70}Starting at[\\w\\W\\s]{100}",0));
			String prices[] = U.getPrices((html+comSec+availHtml+floorHtml +allAvailData).replaceAll("</span><span class=\"DetailPrice\" data-reactid=\"\\d{3}\">",""),"\\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|STARTING AT\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",0);//.replaceAll(">\\$\\d{3},\\d{3}</span>", ""), 0);
			
			
			
			//U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(allAvailData, "[\\w\\s\\W]{30}392,990[\\w\\s\\W]{30}", 0));
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Price--->"+minPrice+" "+maxPrice);
		//	if(comUrl.contains("https://www.capstonehomes-mn.com/communities/greenbriar-hills"))maxPrice="$493,990";
			//if(comUrl.contains("https://www.capstonehomes-mn.com/communities/towne-lakes-villas"))maxPrice="$451,990";
			//======================================================Sq.ft===========================================================================================		
			availHtml =availHtml.replaceAll("<span data-reactid=\"\\d+\">SQ FT", " SQ FT");
			floorHtml =floorHtml.replaceAll("<span data-reactid=\"\\d+\">SQ FT", " SQ FT");
			//U.log(availHtml);
			String[] sqft = U.getSqareFeet(html+comSec+availHtml+floorHtml,"\\d,\\d+\\s*SQ FT",0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
			
			//================================================community type===================================================
			
			String communityType=U.getCommType(html+comSec);
					
			//==========================================================Property Type================================================
			String propType=U.getPropType((html+comSec+allAvailData+availHtml+floorHtml).replaceAll("Legacy Bay Farms Villas", ""));
					
			//==================================================D-Property Type======================================================
			String dType=U.getdCommType((html+comSec+allAvailData+availHtml+floorHtml).replaceAll("2 Story</li>", "2-story")
					.replaceAll("Single Level|one-level", ""));
			
			U.log("dType: "+dType);
					
			//==============================================Property Status=========================================================
			if(availHomesCount==0){
				html = html.replaceAll("Quick|quick", "");
				comSec = comSec.replaceAll("Quick|quick", "");
			}
			
		
			
//			U.log(comSec);
			html=html.replace("quick move-in homes", "").replaceAll("quick move-in homes|\\d+ Quick Move-in Home|Quick Move-in Homes|quick move-in homes|\\d+ Quick Move-in Homes", "").replace("4 available homes in the beautiful Pine", "").replaceAll("Now Open by Appointment", "");
			html=html.replace("ONLY 7 LEFT", "").replace("ONLY 9 LEFT","Only 9 Homes Left").replace("presents its final phase located on The Links at North","");
			
			U.log("SSS"+Util.match(comSec,"Quick Move-in"));
			U.log("LLL"+comSec);
			String pStatus=U.getPropStatus(html);//dt comSec 26 may 22
			U.log("before replace "+pStatus);
			if(pStatus.contains("Quick Move-in Homes")) {
			  
				pStatus = pStatus.replace("Quick Move-in Homes, ", "").replaceAll("Quick Move-in Homes|, Quick Move-in Homes|Quick Move-in Homes, |\\d+ Quick Move-in Homes|\\d+ Quick Move-in Home", "");
			U.log("aftr replace "+pStatus);
				
				if(pStatus.length()==0){
				 pStatus=ALLOW_BLANK; 
			 }

			}
			U.log("counti=="+availQuickCount);
			if(availQuickCount>0) {
				if(!pStatus.contains("Quick Move-in Homes")&& pStatus.length()<4) {
					pStatus="Quick Move-in Homes";
				}
				
				else if(!pStatus.contains("Quick Move-in Homes")&&pStatus.length()>4)
					pStatus=pStatus+", Quick Move-in Homes";
			}
		
			U.log("pStatus: "+pStatus);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+html, "[\\s\\w\\W]{30}FINAL PHASE[\\s\\w\\W]{30}", 0));
			
		//	pStatus = pStatus.replaceAll("\\d+ Quick Move-in Homes, |, \\d+ Quick Move-in Home", "Quick Move-in");
//			if (comUrl.contains("https://www.capstonehomes-mn.com/communities/towne-lakes-villas")) pStatus ="Coming Soon";
			if(comUrl.contains("https://www.capstonehomes-mn.com/communities/pearson-place")) pStatus ="Sold Out"; //From Img
		//	if (comUrl.equals("https://www.capstonehomes-mn.com/communities/settlers-bluff"))pStatus=ALLOW_BLANK;
		//	if(comUrl.contains("https://www.capstonehomes-mn.com/communities/legacy-bay-farms-villas"))pStatus="3 Quick Move-in";
//			if((comUrl.contains("/communities/stonegate-at-rush-creek") || comUrl.contains("/communities/towne-lakes-villas")) && !pStatus.contains("Now Open")){
//				
//				if(pStatus == ALLOW_BLANK)pStatus = "Now Open"; //From Image
//				else if(pStatus != ALLOW_BLANK)pStatus += ", Now Open";
//			}

			//pStatus=pStatus.replace("Quick Move-in", "Quick Move-in Homes");
			U.log(comName);
			comName = comName.replaceAll(" Villas$", "");
			
			//===================== Number of Units=============
			
			int lotCount=0;
			String noOfUnits=ALLOW_BLANK;
			if(html.contains("Site Plan</a>")) {
				U.log("Site map Url "+siteMapUrl);
				String siteHtml=U.getHtml(siteMapUrl,driver);
				U.log("Site maphtml path: "+U.getCache(siteMapUrl));
				String[] lotData=U.getValues(siteHtml, "<path class=\"leaflet-interactive\"", "/>");			
				lotCount=lotData.length;
				noOfUnits=Integer.toString(lotCount);
				if(noOfUnits.equals("0"))
					noOfUnits=ALLOW_BLANK;
			
			}
			
			U.log("noOfUnits==="+noOfUnits);
			
			
			data.addCommunity(comName, comUrl,communityType );//U.getCommunityType(homeHtml + html+flrHtml)
			
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(propType,dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(html));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
		}j++;
//		}catch(Exception e){}
	}

	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode = U.CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"181.215.130.32", 3128));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			Thread.sleep(3000);
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language",
					"en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			html = U.removeComments(html);
			html = html.replaceAll("<!---->", "");
			html = U.removeSectionValue(html, "<script>window", "</body>");
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	private void addDetails(String comInfo,String moveInHomes,String[] moveIn) throws Exception {
//	if(j==17)
		{
		// TODO Auto-generated method stub
		U.log("INFO::" + comInfo);
		
		String minsqf = ALLOW_BLANK;
		String maxsqf = ALLOW_BLANK;
		// String url=Util.match(url1, "<a href=\"/neighborhoods([^>])+");
		// U.log(url);
		String url = U.getSectionValue(comInfo, "Visit Community", "class=");
		url=U.getSectionValue(url, "a href=\\\"\\", "\\\"");
		url=url.replace("&amp;", "&");
		U.log(url);
		if (url == null) {
			url = "\\/page.php?p=3&com=7";

		}
		//url = url.replace("/", "");
		url = url.replace("\\", "/");
		String comUrl = "https://www.capstonehomes-mn.com" + url;
		comUrl = RedirectedURL(comUrl).replace("-floorplans", "");
		
		
		U.log("Page::" + comUrl);
//		if (!comUrl.contains("/page.php?p=5&com=38")) return;
		String html = getHtml(comUrl,driver);
		U.log(U.getCache(comUrl));
		/*if (html == null) {
			return;
		}*/
		
		String commName = U.getSectionValue(comInfo, "\"", "\",");
		commName=commName.replace(" in Otsego","");
		U.log("Community Name----->"+commName);
		U.log(commName);
		String priceData=pricedata.get(commName.toLowerCase());
		
		U.log("Price::::::"+priceData);
		String urlc=U.getSectionValue(priceData, "<a ng-href=\"","\"");
		comUrl="https://www.capstonehomes-mn.com"+urlc;
		U.log("Acturl URL::::"+comUrl);
		 html = getHtml(comUrl,driver);
		 U.log(U.getCache(comUrl));
		 String communityType = U.getCommType(html);
		//======================= Address =========================
		// Address is taken from main source pg
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "TRUE";
		String addSec = U.getSectionValue(comInfo, "\"address\":\"", "\"");
		if(addSec != null){
			addSec = addSec.replaceAll(" Burnsville ", ", Burnsville, ")
					.replace(" Ramsey ", ", Ramsey, ").replace(" Savage", " Savage,").replace(" Otsego ", ", Otsego, ").replace(" Lake Elmo ", ", Lake Elmo, ")
					.replace(" Andover ", ", Andover, ").replace(" Dayton ", ", Dayton, ").replace(" Zimmerman ", ", Zimmerman, ").replace(" Hugo ", " Hugo,")
					.replace(" Elk River ", ", Elk River, ").replace("Cottage Grove", ",Cottage Grove,").replace(" Blaine ", ", Blaine, ").replace("Lino Lakes",", Lino Lakes,").replace("Champlin", ", Champlin,");
			U.log(addSec);
			if(addSec.length()>20 && addSec.contains(","))
			add = U.getAddress(addSec);
		}
		U.log("Add ::"+Arrays.toString(add));
		//=================== LatLng ================
		String latlng = Util.match(comInfo, "\" value=\"([^\"])+\"");
		U.log(latlng);
		
		latlng = U.getSectionValue(comInfo, "coords\":[\"", "\"]");
		latlng = latlng.replace("\"", "");
		String latLng[] = latlng.split(",");
		U.log(latLng.length);
		
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
		}
		if(add[0] != ALLOW_BLANK && add[3] == ALLOW_BLANK){
			add[3] = U.getAddressGoogleApi(latLng)[3];
			geo = "True";
		}
		/* String html=U.getHTML(url); */
		
		String homeUrl = comUrl+"-homes";
		String homeHtml = ALLOW_BLANK;
		if (homeUrl != null)
			homeHtml = getHtml(homeUrl, driver);
		U.log("Home url "+homeUrl);
		String home_DATA = ALLOW_BLANK;
		String homeSec=U.getSectionValue(homeHtml, "<div class=\"homes\">", "<div class=\"clearfix\">");
		//U.log(homeSec);
		String status=ALLOW_BLANK;
		if(homeSec != null){
			String[] h_VALS = U.getValues(homeSec, "<div class=\"result-col-btn\"> <a ng-href=\"", "\"");
			for(String fff : h_VALS){
				//fff = U.getSectionValue(fff, "href=\"", "\"");
				for (String move : moveIn) {
					//U.log("move: "+move+" fff: "+fff);
					if (move.contains(fff.replace("/", ""))) {
						status=" Quick move in home ";
					}
				}
				fff = "https://www.capstonehomes-mn.com"+fff;
				U.log(fff);
				
				String loc_html = getHtml(fff, driver);
				if(loc_html!=null){
					home_DATA = home_DATA+loc_html;
				}
			}
		}
		commName = commName.replace(" ~ COMING SOON!!!", "");

		// sqft

		String sqHtml = ALLOW_BLANK;
		//https://www.capstonehomes-mn.com/rose-bluff
		String flrUrl = comUrl+"-floorplans";
		U.log("floor url "+flrUrl);
		String flrHtml = getHtml(flrUrl, driver);
		
		
		
		String FLOOR_DATA = ALLOW_BLANK;
		String flooSec=U.getSectionValue(flrHtml, "<div class=\"plans\">", "<div class=\"container\">");
		//U.log(flooSec);
		if(flooSec != null){
		String[] F_VALS = U.getValues(flooSec, "class=\"btn\" href=\"", "\">");
		for(String fff : F_VALS){
			//fff = U.getSectionValue(fff, "href=\"", "\"");
			fff = "https://www.capstonehomes-mn.com"+fff;
			//U.log(fff);
			String loc_html = getHtml(fff, driver);
			if(loc_html!=null){
				FLOOR_DATA = FLOOR_DATA+loc_html;
			}
			FLOOR_DATA=FLOOR_DATA.replace("Single Level Living", "1 story");
		}
		}
		homeHtml = homeHtml.replace("<option value=\"11\" label=\"Villas of Miske Meadows\">Villas of Miske Meadows", "");
		//U.log(homeHtml);
		String titleData = U.getSectionValue(html, "<title>", "</title>");
		String sec=U.getSectionValue(html, "<h4>Community Amenities</h4>","</aside>");
		String ss="";
		if(comUrl.contains("villa")) {
			ss=" Villas ";
		}
		
		String pType=U.getPropType((U.getNoHtml(homeHtml+titleData+sec+FLOOR_DATA)).replaceAll("Village|village|Villas|Cottage Grove|\\| Custom Homes in", "")+ss);
		
		String[] sqft = U.getSqareFeet(flrHtml+FLOOR_DATA+homeHtml, "Sq Ft: \\d+,\\d+|Sq Ft: \\d+|SQFT:</span> \\d,\\d+|SQFT:</span> \\d+",0);
		minsqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxsqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minsqf + " maxSqf:" + maxsqf);
		
		priceData=priceData.replaceAll("0's|0s|0S", "0,000");
		
		String[] Prices = U.getPrices(homeHtml+flrHtml+html+FLOOR_DATA+priceData, "\\$\\d+,\\d+|Starting in the High \\d{3},\\d{3}|Starting in the Mid \\d{3},\\d{3}|Starting in the Low \\d{3},\\d{3}", 0);
		if(Prices[1]==null)Prices[1]=ALLOW_BLANK;
		if(Prices[0]==null)Prices[0]=ALLOW_BLANK;
		
		String ADD_VAL = ALLOW_BLANK;
		String[] add_vals = U.getValues(homeHtml, "class=\"ng-binding\">", "<");
		for(String aaa : add_vals){
			if(aaa.contains(add[1])){
				ADD_VAL = aaa;
				break;
			}
		}
		if(ADD_VAL!=null&&ADD_VAL!=ALLOW_BLANK){
			add[0] = U.getSectionValue(comInfo, "address\":\"", add[1]);
			
			U.log(add[0]+"here");
		}
		
		//=============== Description =============
		String comDesc = U.getSectionValue(html, "Description</h4>", "<h4>");
		if(comDesc != null) comDesc = comDesc.replace("SOOON", "SOON");
		String stat = ALLOW_BLANK;
		
		if(comUrl.contains("https://www.capstonehomes-mn.com/mississippi-dunes-estates")||comUrl.contains("https://www.capstonehomes-mn.com/oneka-place"))
			status= "Coming Soon";
		if(comUrl.contains("https://www.capstonehomes-mn.com/sara-jean-estates")|| comUrl.contains("/pine-bluff"))
			status= "Coming Soon";
		if(comUrl.contains("https://www.capstonehomes-mn.com/hidden-acres")||comUrl.contains("https://www.capstonehomes-mn.com/brookfield-7th-add")||comUrl.contains("https://www.capstonehomes-mn.com/century-farm-north-6th-add"))status= "Sold Out";
		if(comUrl.contains("https://www.capstonehomes-mn.com/brookfield-7th")||comUrl.contains("https://www.capstonehomes-mn.com/century-farm-north-6th")||comUrl.contains("/rush-creek-landing"))status= "Sold Out";

		if(comUrl.contains("https://www.capstonehomes-mn.com/radisson-cove")|| comUrl.contains("https://www.capstonehomes-mn.com/creekside-meadows"))status= "Quick Move-in";
		if(comUrl.contains("https://www.capstonehomes-mn.com/settlers-bluff"))status=ALLOW_BLANK;
		U.log(Util.matchAll(status+U.getSectionValue(homeHtml + html+flrHtml, "<h2>", "</h2>")+comDesc, "[\\w\\s\\W]{30}sold[\\w\\s\\W]{30}", 0));
		stat = U.getPropStatus(status+U.getSectionValue(homeHtml + html+flrHtml, "<h2>", "</h2>")+comDesc);
		
		if(!homeHtml.contains("No homes match this criteria")){
			U.log("Hello");
			if(stat.length()<4){
				stat = "Quick Move-in Homes";
			}
			else{
				stat = stat + ", Quick Move-in Homes";
			}
		}
	
		//U.log(homeHtml);

		if(add[0]==null || add[0].length()<2)
		{
			add=U.getAddressGoogleApi(latLng);
			geo="TRUE";
		}
		
		if(comUrl.contains("century-farm-north")||comUrl.contains("willowfield")) {
			stat="Sold Out";
		}
		
		if(add[0].trim().endsWith(","))add[0] = add[0].replace(",", ""); 

			
		data.addCommunity(commName, comUrl,communityType );//U.getCommunityType(homeHtml + html+flrHtml)
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minsqf, maxsqf);
		data.addPrice(Prices[0], Prices[1]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(pType,U.getdCommType(homeHtml + html+flrHtml+home_DATA+FLOOR_DATA));
		data.addPropertyStatus(stat);
		data.addNotes(U.getnote(html+flrHtml));
	}j++;
	}
	
	
	
	public String RedirectedURL(String url) throws Exception
	{
		URLConnection con = new URL(url).openConnection();
		//System.out.println( "orignal url: " + con.getURL() );
		con.connect();
		//System.out.println( "connected url: " + con.getURL() );
		InputStream is = con.getInputStream();
		//System.out.println( "redirected url: " + con.getURL() );
		String RedUrl = con.getURL().toString();
		is.close();
		return RedUrl;
		
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {
					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					/*
					 * driver.manage() .addCookie( new
					 * Cookie("visid_incap_612201",
					 * "gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"
					 * ));
					 */
		///			driver.manage().window().maximize();
					driver.get(url);
					// Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); // y value '400' can
					// be
			
					
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
						// U.log(e.toString());
						U.log("click unsuccess");
					}
					Thread.sleep(2000);
					html = driver.getPageSource();
					

					
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}

	}

}