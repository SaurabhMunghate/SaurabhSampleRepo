/** @author Sawan
 *  @modify 28 Aug 2020
 *  @author Rakesh 
 *  @date 02/08/2013 
 */
package com.shatam.b_241_260;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCheldanHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	WebDriver driver = null;

	public static void main(String[] ar) throws Exception { 

		AbstractScrapper a = new ExtractCheldanHomes();
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath() + "Cheldan Homes.csv", a.data().printAll());
	}
	
	private static final String BUILDER_URL = "https://www.cheldanhomes.com";

	public ExtractCheldanHomes() throws Exception {
		super("Cheldan Homes", BUILDER_URL);
		LOGGER = new CommunityLogger("Cheldan Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String html = U.getHtml("https://www.cheldanhomes.com/cheldan-communities", driver);
		String comSections[] = U.getValues(html, "<h3 class=\"caption-title", "Button</span>");
		U.log("total comms"+comSections.length );
		
		
		for(String comSec : comSections){
			String comUrl = U.getSectionValue(comSec, "\" href=\"", "\"");
			if(comUrl !=null && !comUrl.startsWith("http")) comUrl = BUILDER_URL +comUrl;
			
			if(comUrl ==null || comUrl.contains("all-communities"))continue;
			
			
			addDetails(comUrl, comSec, driver); 
		}
		
		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	int j = 0;
	
	
	//TODO: Extract Communities Details
	private void addDetails(String comUrl, String comSec, WebDriver driver )throws Exception{
	//if(j == 2)
		
//		if(!comUrl.contains("https://www.cheldanhomes.com/pyramid-acres"))return;
	{
			U.log(j+" comUrl :"+comUrl);

			
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+" ============ Repeat ");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			U.log("commSec=="+comSec);
			String html = U.getHtml(comUrl, driver);
			
			//============== Community Name ===================
			String comName = U.getSectionValue(comSec, ">", "</h3>");
			U.log("comName :"+comName);
			
			//================ Address =====================
			String add[] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
			String addSec=ALLOW_BLANK;
			String geo = "False";
			
			addSec = U.getSectionValue(comSec, "<p class=\"rteBlock\">", "</p>");
//			if(addSec.contains(" – ")) {
//				addSec = U.getSectionValue(comSec, "Directions:", "/data=");
//				U.log("addSec!!="+addSec);
//			}
			U.log("addSec1 :"+addSec);
			if(addSec != null){
//				addSec = addSec.replace(" &ndash; ", ", ").replace("12608 – Kollmeyer Way", "12608 , Kollmeyer Way");
//						.replace("12608, Kollmeyer", "12608 Kollmeyer").replace(" – ", " ")
//						.replace(" Dr ", " Dr, ").replace("Crown Valley ", "Crown Valley, ")
//						.replace(" Drive ", " Drive, ");
//				addSec=U.getSectionValue(addSec, "<p class=\"rteBlock\">", "</p>");
//				addSec=addSec.replaceAll("\\–", ", ");
//				if(addSec.contains("Dr –")) {
//					addSec = U.getSectionValue(html, "Directions:", "/data=");
//					U.log("addSec!!="+addSec);
//				}
				addSec = addSec.replace("12608 – Kollmeyer Way, TX 76126", "12608 – Kollmeyer Way, Fort Worth, TX 76126").replace("113 Wilson Cliff Dr – White Settlement", "113 Wilson Cliff Dr , White Settlement").replace("Independence Dr - Joshua", "Independence Dr , Joshua");
				U.log("addSec="+addSec);
				String vals[] = addSec.split(",");
				U.log(vals[0]);
				
				if(vals.length == 2){
					add[0] = vals[0];
					add[3] = Util.match(vals[1], "\\d{5}");
					add[2] = Util.match(vals[1], "[A-Z]{2}");
				}
				if(vals.length == 3){
					add = U.findAddress(addSec);
				}
			}
			add[0]=add[0].replaceAll("�|White Settlement", "");
			U.log("Add :"+Arrays.toString(add));
			
			
			
//			if(comUrl.contains("https://www.cheldanhomes.com/crown-valley")) 
//			{
//				add[0] = "118 Crown Valley";
//				add[1] = "Weatherford";
//				add[2] = "TX";
//				add[3] = "76087";
//													
//			}
			

			//======================Lat-Lng =================
			String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
			String latLngSec = U.getSectionValue(html, "Directions:</b>", "CLICK TO VIEW");
//			U.log("latlongSec: "+latLngSec);
			if(latLngSec != null){
				latLngSec = Util.match(latLngSec, "\\d{2}\\.\\d{3,},-\\d{2,3}\\.\\d{3,}");
				U.log(latLngSec);
				if(latLngSec != null) latLng = latLngSec.split(",");
			}
			if(latLng[0]==ALLOW_BLANK) {
				latLngSec=U.getSectionValue(html, "Directions:", "CLICK TO VIEW");
				U.log("latLngSec ::"+latLngSec);
				latLngSec = Util.match(latLngSec, "\\d{2}\\.\\d{3,},-\\d{2,3}\\.\\d{3,}");
				if(latLngSec != null) latLng = latLngSec.split(",");
			}
			
			U.log("LatLng :"+Arrays.toString(latLng));
			
			if(add[0] != ALLOW_BLANK && add[1] == ALLOW_BLANK){
				if(latLng[0].length() > 3){
					String add1[] = U.getAddressGoogleApi(latLng);
					if(add1 == null) {
						add1 = U.getAddressHereApi(latLng);
						
					}
					
					add[1] = add1[1];
					U.log("Adress=== "+Arrays.toString(add));
					geo = "TRUE";
				}
			}
			if(add[0] != ALLOW_BLANK && add[1] != ALLOW_BLANK){
				if(latLng[0].length() < 3){
					latLng = U.getlatlongGoogleApi(add);
					if(latLng == null) latLng = U.getlatlongHereApi(add);
					geo = "TRUE";
				}
				//geo="TRUE";
			}
			
//			if(comUrl.contains("https://www.cheldanhomes.com/pyramid-acres")) {
//				add[1] = "Fort Worth";
//				geo = "True";
//			}
//			String iframeUrl = U.getSectionValue(html, "<iframe src=\"", "\"");
//			U.log("iframUrl :"+iframeUrl);
			String homeHtml = "";
//			if(iframeUrl!=null)
//			homeHtml = U.getHtml(iframeUrl, driver);
//			
//			
			String quickHomeSection = U.getSectionValue(homeHtml, "<div id=\"quickMoveInResults\">", "<div id=\"readyToBuildResults\">");
//			
			String readyHomeSection = U.getSectionValue(homeHtml,"<div id=\"readyToBuildResults\">", "<h2>No homes were found for your");
			
//			String moveinUrl=BUILDER_URL+"/move-in-ready-homes";
			String moveinUrl="https://twix.newhomesource.com/cheldanhomes/HOMES";
			String moveInHtml="";
if(moveinUrl!=null) {
	U.log("KKKKKKKKKKK");
	 moveInHtml=U.getHtml(moveinUrl, driver);
}
			
			
			
			String floorUrl="https://www.cheldanhomes.com/find-your-floorplan";
			String floorHtml=U.getHtml(floorUrl, driver);
			
			
			if(moveInHtml.contains("415,000"))
				
				U.log("FOUND");
			
			
			String[] mvHomes=U.getValues(moveInHtml, "<div class=\"address-plan-name\">", "Request More Info");
			String moveHtml=ALLOW_BLANK;
			for(String mHome:mvHomes) {
				if(mHome.contains(comName)) {
					moveHtml+=mHome;
				}
			}
			
			
			
			
			
			
			//====================Price ================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			comSec = comSec.replace("0's", "0,000");
			html = html.replaceAll("0'S", "0,000");
			
			U.log("mmKKKKKKK"+Util.matchAll(html+comSec + quickHomeSection+readyHomeSection, "[\\w\\s\\W]{30}\\$200[\\w\\s\\W]{30}", 0));

			
			String prices[] = U.getPrices(html+comSec + quickHomeSection+readyHomeSection+moveHtml,//moveHtml jn
					"\\$\\d{3},\\d{3}|STARTING FROM THE MID \\$\\d{3},\\d{3}|MID \\$\\d{3},\\d{3}|(Starting from the|STARTING FROM THE) \\$\\d{3},\\d{3}|from</span> \\$\\d{3},\\d{3}", 0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Price--->"+minPrice+" "+maxPrice);
			U.log("mmKKKKKKK"+Util.matchAll(html+comSec + quickHomeSection+readyHomeSection, "[\\w\\s\\W]{30}\\$300[\\w\\s\\W]{30}", 0));
			//====================Sqft ================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

			String[] sqft = U.getSqareFeet(	html+comSec+ quickHomeSection+readyHomeSection+moveHtml,
							"2,121 sq.ft.|range from \\d,\\d{3} to \\d,\\d{3} square feet|footage\">\\d,\\d{3} sq.ft.",0);
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
			
			
			
			
			//============Quick Homes =======================
			int quickHomeCount = 0;
			String combinedQuickHtmls = null;
			if(quickHomeSection != null){
				String quickHomeUrls[] = U.getValues(quickHomeSection, "-homes-card\"><a href=\"", "\"");
				quickHomeCount = quickHomeUrls.length;
				for(String quickUrl : quickHomeUrls){
					if(!quickUrl.startsWith("http")) quickUrl = "https://twix.newhomesource.com" + quickUrl;
					U.log("quickUrl ::"+quickUrl);
					
					String quickHtml = U.getHTML(quickUrl);
					combinedQuickHtmls += U.getSectionValue(quickHtml, "<div class=\"hd-heading", "Floor plan</div>");
				}
			}
			
			//============Ready Homes =======================
			int moveInHomeCount = 0;
			String combinedReadyHtmls = null;
			if(readyHomeSection != null){
				String readyHomeUrls[] = U.getValues(readyHomeSection, "-homes-card\"><a href=\"", "\"");
				moveInHomeCount = readyHomeUrls.length;
				for(String readyUrl : readyHomeUrls){
					if(!readyUrl.startsWith("http")) readyUrl = "https://twix.newhomesource.com" + readyUrl;
					U.log("readyUrl ::"+readyUrl);
					
					String readyHtml = U.getHTML(readyUrl);
					combinedReadyHtmls += U.getSectionValue(readyHtml, "<div class=\"hd-heading", "Floor plan</div>");
				}
			}
			
			String propType = U.getPropType((html + combinedQuickHtmls+ combinedReadyHtmls).replace("Sun View Estates", ""));
			U.log("mm"+Util.matchAll(html + combinedQuickHtmls+ combinedReadyHtmls, "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}", 0));
			String dType = U.getdCommType((html + combinedQuickHtmls+ combinedReadyHtmls).replace("branch",""));
			
			String comType = U.getCommunityType(html.replaceAll("Golf Club as some of the many possibilities|ggregated", ""));
			U.log("commType: "+comType);
			html = html.replaceAll("Move In Ready Home|combination of move-in", "");
			String pStatus = U.getPropStatus((html+ comSec).replace("/move-in-ready-homes", "").replaceAll("Pyramid Acres-Coming Soon|-Coming Soon&#10|Wilson Cliff- Coming Soon", ""));
/*			if(!pStatus.contains("Quick Move") && quickHomeCount > 1){
				if(pStatus == ALLOW_BLANK)	pStatus = "Quick Move In Homes";
				else if(pStatus != ALLOW_BLANK)	pStatus += ", Quick Move In Homes";
			}*/
//			if(!pStatus.contains("Move-in") && moveInHomeCount > 1){
//				if(pStatus == ALLOW_BLANK)	pStatus = "Move-in Ready Homes";
//				else if(pStatus != ALLOW_BLANK)	pStatus += ", Move-in Ready Homes";
//			}
			
			String payload = "{\"request\":{\"PartnerId\":829,\"SiteUrl\":\"cheldanhomes\",\"State\":\"\",\"MarketIds\":\"\",\"Cities\":\"\",\"CommunityIds\":\"\",\"Type\":\"Default\",\"BrandIds\":\"\",\"Facets\":{\"NumberOfBedrooms\":-1,\"NumberOfBathrooms\":-1,\"NumberOfGarages\":-1,\"MinimumPrice\":-1,\"MaximumPrice\":-1,\"Builder\":0,\"Community\":0,\"Builders\":[19566]}}}";
			String qhtml = sendPostRequestAcceptJson("https://twix.newhomesource.com/Homes/Default", payload);
			String[] qSec = U.getValues(qhtml, "{\"ResultFacets\":", "HasBuilderReviews");
			
			for(String data : qSec)
				if(data.contains(comName))
					if(!pStatus.contains("Move-in") && data.contains("Ready to Build")){
						if(pStatus == ALLOW_BLANK)	pStatus = "Move-in Ready Homes";
						else if(pStatus != ALLOW_BLANK)	pStatus += ", Move-in Ready Homes";
					}
			
			if(comUrl.contains("https://www.cheldanhomes.com/pyramid-acres")) {
//				maxPrice = "$330,000";
//				minSqft = "2,007";
//				maxSqft = "2,118";
//				pStatus = pStatus.replaceAll("Move-in Ready Homes","Quick Move in Homes");
				//geo="False";
			}
			
			if(comUrl.contains("/pyramid-acres"))pStatus =pStatus.replace("Sold Out", "Currently Sold Out");
//			pStatus = pStatus.replaceAll("Move-in Ready Homes","Quick Move in Homes");
			add[0] = add[0].replace("�", "");
			add[0] = add[0].replace("�", "");
		
//			if(comUrl.contains("https://www.cheldanhomes.com/heritage-ii")) {
//				maxPrice="$425,000"; 
//				minSqft="1958";  maxSqft="2598";      
//				propType="Patio Homes";
//				dType="1 Story, 2 Story";
//			}
//			
//			if(pStatus.contains("Quick Move In Homes, Move-In Ready Homes"))pStatus=pStatus.replace("Quick Move In Homes, Move-In Ready Homes", "Move-In Ready Homes");
//			if(comUrl.contains("https://www.cheldanhomes.com/heritage-ii")) {
//				maxPrice="$385,000"; 
//			}
			if(comUrl.contains("https://www.cheldanhomes.com/heritage-ii"))
				pStatus=pStatus.replace("Quick Move In Homes", "Move-In Ready Homes");
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].replace(" � White Settlement", "").replace(" �", " ").trim().replace(" –", ""), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType,dType);
			data.addPropertyStatus((pStatus).replace("Quick Move In Homes", "Move-In Ready Homes"));
			data.addNotes(ALLOW_BLANK);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);

		}
		j++;
	}
	
	public void innerProcess1() throws Exception {

		String html = U.getHTML("http://www.cheldanhomes.com/Communities");
		String readtHomeHtml = U.getHTML("http://www.cheldanhomes.com/homes-ready-when-you-are/");
		String section = U.getSectionValue(html,
				"<div class=\"col-xs-12 comm-grid no-padding\">",
				"<div class=\"overlay\">");
		String[] communitiesInfo = U.getValues(section,
				"<a href=\"http://www.cheldanhomes.com", "</a>");
		// U.log(Arrays.toString(communitiesInfo));
		String commLine;
		int totalComm = communitiesInfo.length / 2;
		for (String communitieInfo : communitiesInfo) {
//			if (j == 0) 

			{
				// if(inr==0||inr==totalComm||inr==totalComm+1||inr==communitiesInfo.length-1)
				{
					String communityName = U.getSectionValue(communitieInfo,
							"<h3 class=\"highlight semi-bold name\">", "</h3>");
					commLine = communityName;
					// U.log("============comm"+commLine);

					if (communityName.contains("-"))
						communityName = U.getSectionValue(communitieInfo, ">",
								"-");
					String communityUrl = "http://www.cheldanhomes.com/" + U.getSectionValue(communitieInfo, "/", "\">");
					U.log(communityUrl);

					String html1 = U.getHTML(communityUrl);

					html1 = html1
							.replace(
									"<p>&#8220;Cheldan Homes made buying our first home an amazing experience! We recommend them to everyone we know! We are extremely happy with our new home!&#8221;</p>",
									"");
					html1 = html1.replace(
							"<div class=\"testimonials-container\">", "");
					html1 = html1
							.replace(
									"<div class=\"col-lg-5 col-lg-offset-1 no-padding\">",
									"");
					html1=U.removeSectionValue(html1, "<!-- This site is optimized with the Yoast SEO", "<!-- / Yoast SEO plugin. -->");

					// ------------Prices-------------------
					String priceArr[] = { ALLOW_BLANK, ALLOW_BLANK };

					String prihtml = "";
					if (html1.contains("Home</a></p>")) {
						String prisec = U.getSectionValue(html1,
								"<div class=\"swiper-slide showcase-slide\">",
								"<div class=\"col-md-6 contact-us\">");
						String prival[] = U.getValues(prisec, "<a href=\"",
								"\">");
						for (String val : prival) {
							U.log("Plan Url :: " + val);
							prihtml = prihtml + U.getHTML(val);
						}
					}
					if (html1.contains("<strong>AVAILABLE HOMES")) {
						String avaiSec = U.getSectionValue(html1,"<strong>AVAILABLE HOMES", "</a></p>");
						if (avaiSec != null) {
							String avaiString[] = U.getValues(avaiSec,"href=\"", "\"");
							for (String val : avaiString) {
								U.log("Plan Url :: " + val);
								String availHtml=U.getHTML(val);
								if (availHtml!=null) {
									if (!availHtml.contains("Page not found")) {
										prihtml = prihtml + availHtml;
									}
								}
								
								
							}
							// U.log(avaiSec);
						}
					}
					html1 = html1.replace("$180s", "$180,000");
					html1 = html1.replace("'s</p>", ",000");
					html1 = html1.replace("0&#039;s", "0,000");
					communitieInfo = communitieInfo.replace("0s", "0,000");
					// U.log("===========communitieInfo========"+communitieInfo);
					// html=html.replace("160&#039;s", "$160,000");//
					priceArr = U
							.getPrices(
									html1 + prihtml + communitieInfo,
									"<li>\\$[0-9]{3},[0-9]{3}</li>|Base Price: <span class=\"highlight\">\\$\\d{6}|\\$[0-9]{3},[0-9]{3}</span>|Starting from the \\$[0-9]{3},[0-9]{3}|From the \\d{3},\\d{3}|From the \\$\\d+,\\d+|Price: </strong>\\d+,\\d+",
									0);
					// U.log(priceArr[0]);
					// U.log(priceArr[1]);

					// ---------Finding address---------
					String geo = "FALSE";
					String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
							ALLOW_BLANK };
					String addSec = U.getSectionValue(html1,"<div class=\"sub-line\">", "</div>");
					U.log("AddSec ::"+addSec);
					if (addSec != null) {
						addSec = addSec.replace("<span class=\"highlight\">–</span>", "").replace("Marina, Dr 76020", "Marina Dr, TX 76020")
								.replace(" White Settlement", ", White Settlement").replace(" Weatherford , TX", ", Weatherford , TX")
								.replaceAll("\\s{2,}", " ");
						U.log("addSec :: " + addSec);
						String[] tempAdd = addSec.split(",");
						if (tempAdd.length == 3) {
							U.log("****************");
							add[0] = tempAdd[0];
							add[1] = tempAdd[1];
							add[2] = Util.match(tempAdd[2], "\\w+");
							add[3] = Util.match(tempAdd[2], "\\d+");
						}
						if (tempAdd.length == 2) {
							add[0] = tempAdd[0];
							add[2] = Util.match(tempAdd[1], "\\w+");
							add[3] = Util.match(tempAdd[1], "\\d+");
						}
					}
					U.log("Address : " + Arrays.toString(add));
					if(add[0] != ALLOW_BLANK && add[1]== ALLOW_BLANK && add[3] != ALLOW_BLANK){
						html1 = U.removeComments(html1);
						addSec = U.getSectionValue(html1,"<p class=\"show-home-loc\">", "</p>");
						if(addSec != null){
							addSec = addSec.replace("&nbsp;", ",").replaceAll("\\s{2,}", "").trim();
							String[] vals = U.getAddress(addSec);
							U.log("Temp Add :"+Arrays.toString(vals));
							if(vals[1] != ALLOW_BLANK) add[1] = vals[1]; 
						}
					}

					// ------------- Finding latLng
					String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
					String latLngSec = U.getSectionValue(html1,
							"<h3>Map / Directions</h3>", "Click to View");
					U.log("latLngSec:::::::" + latLngSec);
					if (latLngSec != null) {
						latLng[0] = Util.match(latLngSec, "\\d{2,}.\\d{4,}");
						// latLng = latLng.replace(lng, "");
						latLng[1] = Util.match(latLngSec, "-\\d{2,}.\\d{4,}");
					}
					U.log("Lat-lng are :: " + latLng[0] + "::::::::"+ latLng[1]);

					// Fetching address using latlng
					if (latLng[0] == null && add[3] != null) {
						latLng = U.getlatlongGoogleApi(add);
						if(latLng == null) latLng = U.getlatlongHereApi(add);
						geo = "TRUE";
					}

					if (add[0].length() < 4 && latLng[0].length() > 4) {
						add = U.getAddressGoogleApi(latLng);
						if(add == null) add =U.getAddressHereApi(latLng);
						geo = "TRUE";
					}

					// Finding Sq.area
					String[] areas = U.getValues(html1, "Sq. Ft.:", "/h4>");
					ArrayList<String> arl = new ArrayList<String>();
					for (String area : areas) {
						arl.add(GetLink.getNumber(area));
					}
					String[] minMaxArea = GetLink.getMaxMin(arl);
					// U.log(minMaxArea[0]);U.log(minMaxArea[1]);
					if (minMaxArea[0] == null) {
						minMaxArea[0] = ALLOW_BLANK;
					}
					if (minMaxArea[1] == null) {
						minMaxArea[1] = ALLOW_BLANK;
					}

					String status = ALLOW_BLANK;

					String statSec = commLine;
					// U.log("==========stat="+communityName);
					String remove = "e offering a combination of move-in ready h|Currently selling out of the Mistletoe Hill model|content=\"COMING SOON|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|close out phase with only 2 homes left";
					statSec = statSec.toLowerCase().replaceAll(
							remove.toLowerCase(), "");

					if (communityUrl
							.contains("http://www.cheldanhomes.com//communities/marine-creek-ranch/")) {
						html1 = html1
								.replaceAll(
										"content=\"Marine Creek Ranch is currently in close out phase with only 2 homes left",
										"");

					}

					html = html.replace(remove, "");
					html1 = html1
							.replaceAll(
									"Currently selling out of the Mistletoe Hill model|content=\"Mistletoe Hill is currently in CLOSE OUT with only 1 home available|content=\"COMING SOON|<a href=\"Available-Homes\">Move-In Ready Homes|combination of move-in",
									"");
					html1 = html1
							.replace(
									"only <span style=\"text-decoration: underline;\">two</span> homes available",
									"only two homes available").replace(
									"close-out", "close out").replace("<strong>close-out phase</strong>", "close out phase");

					html1 = html1
							.replace(
									" only <span style=\"text-decoration: underline;\">one</span> home available",
									"only one home available");
					html1 = html1.replace("only 1 home available",
							"only 1�home available");

					status = U.getPropStatus(statSec + communityName + html1);
				//	status=status.replaceAll("Move-in Ready Homes", "Quick Move in Homes");

					U.log("**********" + status);
					
					
					
					//Ready Homes Data
					int comReadyCount = 0;
					ArrayList<String> readyHomeUrl = Util.matchAll(readtHomeHtml, "<li class=\"home-entry\">\\s*<a href=\"(.*?)\"", 1);
					U.log(readyHomeUrl.size());
					for(String readyUrl : readyHomeUrl){
						String readyHtml = U.getHTML(readyUrl);
						String tempSection = U.getSectionValue(readyHtml, "<div class=\"bottom-exert\">", "Back to Available Homes");
						if(tempSection.contains(communityName)){
							comReadyCount = comReadyCount+1;
						}
					}
					U.log(communityName+"\t: ready home count : "+comReadyCount);
					if(comReadyCount!=0 && !status.contains("Ready")){
						status = "Move In Ready Homes";
					}
					
					// property type and sqvalues

					// --------------Square Feet----------------
					String[] sqft = U
							.getSqareFeet(
									html1 + prihtml,
									"[0-9]{4} Sq. Ft.|[0-9]{4} sq ft|<li>[0-9]{4} Sq. Ft.</li>|[0-9]{1},[0-9]{3} square feet to [0-9]{1},[0-9]{3} square feet|<p>Sq Ft: <span class=\"highlight\">[0-9]{4}</span></p>|Sq. Ft.: </strong>\\d,\\d+|Sq. Foot: </strong>\\d,\\d+|Sq. Foot: </strong>\\d+,\\d+",
									0);
					minMaxArea[0] = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
					minMaxArea[1] = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
					// Statu
					// }
					html1 = html1.replace(
							"<a href=\"Available-Homes\">Move-In Ready Homes",
							"");
					String type = U.getCommunityType(html1);
					if (priceArr[1] == null)
						priceArr[1] = ALLOW_BLANK;

					communityName = communityName.replace("- COMING SOON!", "");
					communityName = communityName.replace("- NOW OPEN!", "");
					communityName = communityName.replace("- Now Selling!", "");
					communityName = communityName.replace("-SOLD OUT", "");
					communityName = communityName.replace("- SOLD OUT", "");
					communityName = communityName.replace(
							"Phase VII GRAND OPENING", "");

					

				
					add[0]=add[0].toLowerCase().replace(add[1].toLowerCase(),"").trim();
					// ---fetch story-----------
					String floorLink = communityUrl.replace(
							"community_overview", "community_floorplans");
					

					



					//U.log(prihtml);
					LOGGER.AddCommunityUrl(communityUrl);
					data.addCommunity(communityName, communityUrl, type);
					data.addAddress(add[0].replace(".", ""), add[1].trim(),
							add[2].trim(), add[3].trim());
					data.addLatitudeLongitude(latLng[0].trim(),
							latLng[1].trim(), geo);
					data.addPropertyType(U.getPropType(html1 + prihtml),
							U.getdCommType((communityUrl
									+ html1.replaceAll("ranch|Ranch", "") + prihtml.replaceAll("Stories</li>\\s*<li>2", "2 Stories")
										.replaceAll("ranch|Ranch", ""))
									.replace(">one story", "")
									+ getStoryHtml(floorLink) + communityName));
					
					data.addPropertyStatus(status);
					data.addPrice(priceArr[0], priceArr[1]);
					data.addSquareFeet(minMaxArea[0], minMaxArea[1]);
					data.addNotes(ALLOW_BLANK);
					i++;
					inr++;
				}

			}
			j++;
		}
		LOGGER.DisposeLogger();
	}

	private String getStoryHtml(String url) throws IOException {

		{
			String combineHtml = ALLOW_BLANK;
			U.log("Floor : " + url);
			String html = U.getHTML(url);
			html = html.replaceAll(">one story", "");
			String values[] = U.getValues(html,
					"\"community_floorplans_detail.php?", "\"");
			U.log("Getting: ");
			for (String link : values) {

				link = "http://www.cheldanhomes.com/community_floorplans_detail.php?"
						+ link;
				U.log("Getting: " + link);
				combineHtml += U.getHTML(link);
				combineHtml = combineHtml.replace(
						"Marine Creek Ranch </a></h4>", "");
			}

			return combineHtml;

		}

	}
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Accept-Language", "en-GB,en-US;q=0.9,en;q=0.8");
	        connection.setRequestProperty("Connection", "keep-alive");
	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Mobile Safari/537.36");
	        connection.setRequestProperty("Cookie", "ASP.NET_SessionId=tukn2nawzmiqm1uq0r44sqiu; _ga=GA1.2.893358895.1653455007; _gid=GA1.2.1355253681.1653455007; _gat_UA-40843711-13=1");
//	        connection.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
//	        
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

}