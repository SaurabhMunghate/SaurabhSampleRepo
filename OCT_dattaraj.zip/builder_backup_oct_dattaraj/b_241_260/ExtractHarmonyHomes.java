/**@author Aditya.
 * Date- 01-06-2015
 * Date Modified-03-06-2015
 * 
 */
package com.shatam.b_241_260;

import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.opera.core.systems.scope.services.ums.UmsServices;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHarmonyHomes extends AbstractScrapper {
	public static String HOME_URL = "https://harmonyhomes.com/";
	WebDriver driver = null;
	static int j=0;
	
//	HashMap<String, String> latLngList=new HashMap<>();
	CommunityLogger LOGGER;
	public ExtractHarmonyHomes() throws Exception {
		super("Harmony Homes", HOME_URL);
		LOGGER = new CommunityLogger("Harmony Homes");
	}	

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractHarmonyHomes(); 
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Harmony Homes.csv", a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {

		String stateHtml = U.getHTML("https://harmonyhomes.com/");
		U.setUpChromePath();
		driver=new ChromeDriver();
		
		String comSec1=U.getSectionValue(stateHtml, "ul class=\"dropdown","</ul>");
		//U.log(comSec1);
		String[] comSections = U.getValues(comSec1, "id=", "</li>");
		for(String comSec  : comSections){
			String cUrl = U.getSectionValue(comSec, "href=\"", "\"");
			U.log("cUrl : "+cUrl);
			addComDetails(cUrl,comSec);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	public void addComDetails(String cUrl, String comSec) throws Exception {
//TODO:
//	if(j==1)
	{
		
		
//		if(!cUrl.contains("https://harmonyhomes.com/serenity-place/")) return;
		//https://harmonyhomes.com/quail-ridge/
            
		if(cUrl.contains("https://harmonyhomes.com/move-in-ready/"))return;
		 if(cUrl.contains("//harmonyhomes.com/featured"))return;
		U.log("Count :"+j);
		// ******************Community Name***************************
		String comName = U.getSectionValue(comSec, "/\">", "</a>");
	 U.log("commName=="+comName+"::::::::::");
//	 U.log("cSec:::"+comSec);
		comName = comName.trim();
		

		
		// ******************Community Prices************************

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		

		// ******************Community Url****************************

		String communityUrl = cUrl;
		String florHtml = "";
//		if(!communityUrl.contains("https://harmonyhomes.com/quail-park/"))return;
		U.log(communityUrl);
		if (communityUrl != null) {
			florHtml = U.getHTML(communityUrl);
		}
		
		
		if (data.communityUrlExists(communityUrl)){
			LOGGER.AddCommunityUrl(communityUrl+ "---------------------------------repeat");
			return;
		}
		
		LOGGER.AddCommunityUrl(communityUrl);
				
		String[] homeSec=U.getValues(florHtml, "<h4 class=\"text-white mb-12\">","</h4>");
		String homeHtml="";
		for (String string : homeSec) {
			String hUtl=U.getSectionValue(string, "href=\"", "\"");
			U.log("hhhhh"+hUtl);
			homeHtml=homeHtml+U.getHTML(hUtl);
		}
		
		//U.log(florHtml);
		// ******************Community Area [SqrFeet]******************
		//cSec = cSec.replace("0s", "0,000");
		florHtml = florHtml.replaceAll("(\\$\\d{3})s", "$1,000").replace("'", "");
	//	U.log("*****************\n"+U.getSectionValue(florHtml, "<div class=\"residence-price-b\">", "<"));
		comSec = comSec.replace("'s", ",000");
		florHtml = florHtml.replaceAll("0's|0s", "0,000");
		homeHtml = homeHtml.replace("s<", ",000<");
		//U.log(florHtml);
		comSec=comSec.replace("$251s", "$251,000");
//		homeHtml=homeHtml.replace(" From the $188,000<br />", "");
	//	U.log(Util.match(comSec+ florHtml+homeHtml, "[\\w\\s\\W]{30}1208[\\w\\s\\W]{30}", 0));
		String[] price = U.getPrices(comSec+ florHtml+homeHtml, "\\$\\d+,\\d+", 0);
		//U.log(">>>>>>>>"+Util.matchAll(florHtml+homeHtml, "[\\w\\s\\W]{50}261,990[\\w\\s\\W]{50}", 0));
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice+"::::::::::::::::"+maxPrice);
		String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(comSec + florHtml,
				"<span>\\d{4}</span>|[\\(]+\\d{4} sq ft[\\)]+|FOOTAGE:</span> \\d,\\d+ - \\d,\\d+|\\d,\\d+ - \\d,\\d+|FOOTAGE:</span> \\d+,\\d+|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3} square feet.|\\d{4} Sqft", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		// ******************Adding Data*******************************
		florHtml = florHtml.replaceAll("Super Loft|, Loft, ", ", Loft Home ");
	    if(homeHtml!=null)homeHtml = homeHtml.replace("loft &amp;", "spacious loft");
	    String propertyType=U.getPropType((florHtml+homeHtml).replace("Retire to the luxury and comfort", "Retire to the luxury homes").replace("craftsmanship", ""));
		florHtml=florHtml.replaceAll("or may be under |For Coming Soon|SCHOOLS &#8211; COMING SOON!|luxurious oversized|Luxurious Master Suite|Now selling</span> </div>|content=\"now selling|value=\"coming-soon\">\\s*Coming Soon\\s*</option>", "");
		florHtml = florHtml.replace("<h2>Quick Close! Quick Move-in!</h2>", "Quick Move-in").replaceAll("<div class=\"residence-price-b\">\\W+\\s*Sold out|SOLD OUT", "").replace("(Coming Soon)", "");
		comSec=comSec.replace("Coming Soon, December 2018", "Coming Soon December 2018");
		
		String propertyStatus = U.getPropStatus(florHtml+comSec);
		U.log("propertyStatus=="+propertyStatus);

		String communityType = U.getCommunityType(comSec);
		florHtml=florHtml.replaceAll("Mountain Ranch State Park|near Whitney Ranch and Stephanie|Whitney Ranch and Stephanie", "");
		comSec=comSec.replace("near Whitney Ranch and", "");
		//U.log(florHtml);

		florHtml=florHtml.replaceAll("STORIES:</span>\\s*2", " 2 story ").replaceAll("STORIES:</span>.*?\\s+(\\d)\\s+<", "$1 story");
		
		
		
		// ******************Community Address************************
				String address[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String geoCode = "FALSE";
				String lat = "";
				String lng = "";

				//---------Address-------
//				String mapSection = U.getSectionValue(florHtml, "<div class=\"wpb_map_wraper\">", "</iframe>");
//				U.log(mapSection);
//				if(mapSection !=null){
//					String addSec = U.getSectionValue(mapSection, "!2s", "!5e");
//					if(addSec !=null)
//					{
//						addSec =  addSec.replace("+", " ").replace("%2C", ",").replace("%26", "&");
//						address = U.getAddress(addSec);
//					}
//					U.log("Address is "+Arrays.toString(address));
//					
//					lng = U.getSectionValue(mapSection, "!2d", "!3d");
//					lat = U.getSectionValue(mapSection, "!3d", "!2m");
//					U.log("LATLNG is "+lat+"\t"+lng);
//				}
				
				
				String addresslatlng_sec = U.getSectionValue(florHtml, "<a href=\"https://www.google.com/maps/place/", "data");
				U.log("addresslatlng_sec==="+addresslatlng_sec);
				if(addresslatlng_sec!=null) {
					addresslatlng_sec="Start "+addresslatlng_sec;
					U.log("addresslatlng_sec-1==="+addresslatlng_sec);
				
					String addSec=U.getSectionValue(addresslatlng_sec, "Start", "/@").trim();
					
					if(addSec!=null) {
						addSec=addSec.replace("+", " ");
						U.log("addSec==="+addSec);
						address=U.getAddress(addSec);
					}
					lat=Util.match(addresslatlng_sec, "/@\\d{2}.{1}\\d+");
					if(lat!=null) {
						lat=lat.replace("/@", "");
					}
					lng=Util.match(addresslatlng_sec, "-\\d+.{1}\\d+");
//					U.log("lng==="+lng);
					if(lng!=null) {
						lng=lng.replace("/@", "");
					}
//					U.log("lng==="+lng);
				}
				
				else {
					addresslatlng_sec = U.getSectionValue(florHtml, "<div class=\"wpb_map_wraper\"><iframe src=\"", "\"");
					U.log("addSec==="+addresslatlng_sec);
					if(addresslatlng_sec!=null) {
					String pgSource=U.getPageSource(addresslatlng_sec);
//					U.log(">>>>>>>>"+Util.matchAll(pgSource, "[\\w\\s\\W]{50}655 Pickled Pepper Pl[\\w\\s\\W]{50}", 0));
					String addSec = U.getSectionValue(pgSource, "\"Housing development\",\"", "\"");
					U.log("addSec==="+addSec);
					address=U.getAddress(addSec);
//					String latlng=Util.match(addresslatlng_sec, "\\[[\\d{2}\\.\\d");
					
					lat=Util.match(pgSource, ",\\d{2}.{1}\\d+");
					lng=Util.match(pgSource, "-\\d{3}.{1}\\d+");
					lat=lat.replace(",", "");
					U.log("latlng_sec-2==="+lat+"   "+lng);
				}
				}
				
				
				U.log("Address--->"+Arrays.toString(address));
				U.log("LatLong--->"+lat+"\t"+lng);

				//-----------------
				if(address[0].length()<4 && lat.length()>4){
					address = U.getAddressGoogleApi(new String[]{lat,lng});
					if(address == null) address = U.getAddressHereApi(new String[]{lat,lng});
					geoCode = "TRUE";
				}
				
				String note=ALLOW_BLANK;
				if(lat.trim().length()<4 ){
					address[0]="8912 Spanish Ridge Avenue Suite #200";
					address[1]="Las Vegas";
					address[2]="NV";
					address[3]="89148";
					String[] ll=U.getlatlongGoogleApi(address);
					if(ll == null) ll = U.getlatlongHereApi(address);
					lat=ll[0];
					lng=ll[1];
					U.log(lat+"  "+lng);
					geoCode="TRUE";
					note="Address Taken From Contacts";
				}
		
				
		//U.log("***************"+U.getSectionValue(florHtml, "<div class=\"residence-price-a\">PRICE:", "<li><span>SQ. FOOTAGE:"));
				homeHtml=homeHtml.replace("one and two-story", " 1 Story  2 Story  ").replace("Stories:</strong>", "Stories:");
				String derivedPropertyType = U.getdCommType((florHtml+comSec+homeHtml).replaceAll(">Near the intersection of N. Rancho Dr.|floor", "").replace("open-concept first floor,", ""));
//				U.log(">>>>>>>>"+Util.matchAll(florHtml+homeHtml+comSec, "[\\w\\s\\W]{50}ranch[\\w\\s\\W]{50}", 0));
				if(communityUrl.contains("https://harmonyhomes.com/riverstone/")) derivedPropertyType = "2 Story";
				//data taken from image
				if(communityUrl.contains("https://harmonyhomes.com/highlands/"))propertyStatus ="Final Opportunity";//Img
				if(communityUrl.contains("https://harmonyhomes.com/riverstone/"))propertyStatus ="Final Opportunity";//Img
				if(communityUrl.contains("https://harmonyhomes.com/brookfield/")) {
					propertyStatus ="Sold Out";
					propertyType="Single Family";
					derivedPropertyType="2 Story";
					minPrice="$100,000";maxPrice="$200,000";
					minSqFeet="1106";maxSqFeet="1559";
				}
        comName=U.getCapitalise(comName.toLowerCase());
        U.log(lat+" hh "+lng);
     //https://harmonyhomes.com/bellapark/
//https://harmonyhomes.com/northridge/

        if(communityUrl.contains("https://harmonyhomes.com/bellapark/")) {
        	minPrice = "$234,900";
        	propertyStatus = "Builder Closeout";
        }
        if(communityUrl.contains("https://harmonyhomes.com/northridge/")) {
        	minPrice = "$286,990";
        	propertyStatus = "Builder Closeout";
        }
        //https://harmonyhomes.com/quail-ridge/

        if(communityUrl.contains("https://harmonyhomes.com/quail-ridge/") ){
			address[0]="312 Quail Finch Drive";
			address[1]="Henderson";
			address[2]="NV";
			address[3]="89012";
			String[] ll=U.getlatlongGoogleApi(address);
			if(ll == null) ll = U.getlatlongHereApi(address);
			lat=ll[0];
			lng=ll[1];			
			geoCode="TRUE";	
		//	minPrice="$200,000";
			//maxPrice="$300,990";
		//	propertyStatus="Now Selling";
		}
        //312 Quail Finch Drive, Henderson, NV 89012
        
    //    if(communityUrl.contains("https://harmonyhomes.com/bellapark/") || communityUrl.contains("https://harmonyhomes.com/northridge/"))
    //    	minPrice = "$200,000"; // From Reg. Pg(means Home Pg.) Img.
        	
        //from image
        if(communityUrl.contains("https://harmonyhomes.com/quail-ridge/") || communityUrl.contains("/blue-ridge/")) {
        	//propertyStatus="Now Selling";
        	minPrice="$200,000";
        }
        String noOfUnits=ALLOW_BLANK;
      //  int lotCount=0;
        //String siteMapSec=U.getSectionValue(florHtml, "<div class=\"vc_btn3-container vc_btn3-inline", "Interactive Map</a>");
        if(florHtml.contains("Interactive Map")) {
        	String siteMapUrl=U.getSectionValue(florHtml, "https://salesarchitect.exsquared.com", "\"");
        	U.log("SiteMap Urll:: "+siteMapUrl);
        	String siteMapHtml=U.getHtml("https://salesarchitect.exsquared.com"+siteMapUrl,driver);
        	String comId=U.getSectionValue(siteMapUrl, "CommunityID=", "&");
        	//int lotCount=0;
        	if(comId==null)	
        		comId=U.getSectionValue(siteMapHtml, "communityId:", ",").trim();
        	
        	U.log("ccomId"+comId);
        	String mapUrl="https://salesarchitect.exsquared.com/api/GeoJsonAPI/GetGeoJsonData?bdxCommunityID="+comId+"&communityNumber=";
        	
        	U.log("MAin Site map Urll:: "+mapUrl);
        	String siteMapHtmlMain=U.getHtml(mapUrl,driver);
        //	
        	U.log("SitePath:: "+U.getCache(mapUrl));
			//U.log(">>>>>>>>"+Util.matchAll(siteMapHtmlMain, "[\\w\\s\\W]{50}internalReference[\\w\\s\\W]{50}", 0));

        	String[] lotData=U.getValues(siteMapHtmlMain,"internalReference&gt;Lot", "description");
        	U.log("lot Count"+lotData.length);
        	int lotCount=lotData.length;
        	U.log("lot Count"+lotCount);
        	noOfUnits=Integer.toString(lotCount);
        	
        	if(noOfUnits.equals("0"))
        		noOfUnits=ALLOW_BLANK;
        }
        
        U.log("No. Of Units"+noOfUnits);
        
        //status from img - 25 may dattaraj
        if(cUrl.contains("https://harmonyhomes.com/arcadia/")) propertyStatus = "Grand Opening";
        
       // if(communityUrl.contains("/quail-park/"))	minSqFeet="1121";
		data.addCommunity(comName, communityUrl, communityType);
		data.addAddress(address[0], address[1], address[2].trim(), address[3]);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geoCode);
		data.addPropertyType(propertyType, derivedPropertyType);
		data.addPropertyStatus(propertyStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFeet, maxSqFeet);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);

	}
j++;
}
}