package com.shatam.b_241_260;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHomesbyTaber extends AbstractScrapper {
	
	static int i=0;
	CommunityLogger LOGGER;
	
	public ExtractHomesbyTaber() throws Exception {
		super("Homes by Taber","https://www.homesbytaber.com");
		LOGGER = new CommunityLogger("Homes by Taber");
	}
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractHomesbyTaber();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Homes by Taber.csv", a.data().printAll());
	}
	

	@Override
	protected void innerProcess() throws Exception {
		String mainHtml = U.getPageSource("https://www.homesbytaber.com/communities");
		U.log(U.getCache("https://www.homesbytaber.com/communities"));
		String[] comSections  = U.getValues(mainHtml, "@type\":\"GatedResidenceCommunity", "\"type\":\"community\"");
		U.log("comSections.length: "+comSections.length);
		int c=0;
		for(String comsec : comSections) {
			String published = U.getSectionValue(comsec, "\"published\":", ",\"");
			if(published.equals("false")) continue;
			
			String hide = U.getSectionValue(comsec, "\"hide_from_results\":", ",\"");   //for removing undisplayed comm.
			//U.log("hide: "+hide);
			
			if(hide == null || hide.equals("false")) {
				U.log(" "+c+" "+hide+" published: "+published);
				c++;
				getDetails(comsec, mainHtml);
				U.log(" ");
			}
		}
		//U.log("Total Communities: "+c);
		LOGGER.DisposeLogger();
	}
	
	public void getDetails(String comsec, String mainHtml) throws Exception {
		
		//============ Community Name	
		String name = U.getSectionValue(comsec, ".com\",\"name\":\"", "\",\"");
		U.log("NAME: "+name);
		
		//============ SINGLE EXECUTION WITH COMMUNITY NAME 
//		if(!(name.equals("The Estates at Nichols Creek"))) return;
		
//		if((name.equals("Woodland Trails at Washington Lane"))) {
//			//returning 404 ERROR
//			return;
//		}
		
		//============ Community Url
		String comUrl = ALLOW_BLANK;
		String sharedName = U.getSectionValue(comsec, "\"sharedName\":\"", "\"");
		//U.log("sharedName: "+sharedName);
		
		String[] redirects = U.getValues(mainHtml, "\"to\":\"/communities", "\"");
		for(String link:redirects) { 
			  if(link.contains("/"+sharedName)) {
			  //U.log("link: "+link); 
				  comUrl = "https://www.homesbytaber.com/communities"+link; 
				  U.log("comUrl: "+comUrl);
				  }
			  }
		 
		if(comUrl == ALLOW_BLANK) {
			String[] okc = U.getValues(mainHtml, "href=\"/communities/oklahoma-city-area/", "\"");
			for(String okcLink:okc) {
				if(okcLink.contains("/"+sharedName)) {
					U.log("okcLink: "+okcLink);
					comUrl = "https://www.homesbytaber.com/communities/oklahoma-city-area/"+okcLink;
					U.log("comUrl: "+comUrl);
					break;
				}
			}
		}
		
		if(comUrl == ALLOW_BLANK) {
			String[] tulsa = U.getValues(mainHtml, "href=\"/communities/tulsa-area/", "\"");
			String addLoc = U.getSectionValue(comsec, "\"addressLocality\":\"", "\"").toLowerCase();
			addLoc = addLoc.replace("broken arrrow", "broken-arrow");
			U.log("addLoc: "+addLoc);
		
			for(String tulsaLink:tulsa) {
				comUrl = "https://www.homesbytaber.com/communities/tulsa-area/"+tulsaLink+"/"+sharedName;
				U.log("comUrl E: "+comUrl);
				if(comUrl.contains("/"+addLoc+"/")) {
				U.log("comUrl: "+comUrl);
				break;
				}		
			}
		}
		
		//============ Community Logger
		
		LOGGER.AddCommunityUrl(comUrl);

		//============= Data
		String description = U.getSectionValue(comsec, "\"description\":\"", "\"directions\"");
		if(description == null) {
			description = U.getSectionValue(comsec, "\"description\":\"", "\"geoIndexed\"");
		} 
		U.log("description: "+description);
		
		String customDes = U.getSectionValue(comsec, "\"custom_description\":\"", "\"description\"");
		//U.log("comsec: "+comsec);
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		//============ Geo Index
		String geoSec = U.getSectionValue(comsec, "\"geoIndexed\":[", "],\"");	
		String[] geoo = geoSec.split(",");
		String lat = geoo[1];
		String lon = geoo[0];
		U.log("LAT: "+lat+" LNG: "+lon);
		
		latLng[0] = lat;  
		latLng[1] = lon;
		
		//============ Address
		String street = ALLOW_BLANK;
		String city = U.getSectionValue(comsec, "\"addressLocality\":\"", "\",\"");
		String state = U.getSectionValue(comsec, "\"addressRegion\":\"", "\",\"");
		String zip = U.getSectionValue(comsec, "\"postalCode\":\"", "\",\"");
		
		if(street == ALLOW_BLANK) {
			street = U.getSectionValue(comsec, "\"streetAddress\":\"", "\"},\"");
			geo = "TRUE";
		}
		U.log("ADDRESS: "+street+" - "+city+" - "+state+" - "+zip+" - "+geo);
		
		//============ Unique ComKey
		String comUniqueId = U.getSectionValue(comsec, "\"_id\":\"", "\",");
		U.log("comUniqueId: "+comUniqueId);
		
		//============ Available Homes Data
		
		int quickCount = 0;
		
		String homesData = ALLOW_BLANK;
		String[] homeSecs = U.getValues(mainHtml, "\"@type\":\"SingleFamilyResidence\"", "\"type\":\"home\"");
		//U.log("homeSecs: "+homeSecs.length);
		int homeCount = 0;
		for(String homeSec:homeSecs) {
			String homeId = U.getSectionValue(homeSec, "\"containedIn\":\"", "\"");
			if(comUniqueId.equals(homeId)) {
				//U.log(" "+homeCount+" Matched home: "+homeId);
				//String homeDes = U.getSectionValue(homeSec, "\"description\":\"", "\"elevationPhotos\"");
				
				//U.log("homeSec: "+homeSec);
				
				homesData += homeSec; 
				//U.log(" "+m+" homes data inserted");
				homeCount++;
				
				if(homeSec.contains("status\":\"Active"))  quickCount++;
			}
		}
		U.log("homeCount: "+homeCount);
		
		U.log("quickCount: "+quickCount);
		
		//============ Available Floor Plan Data
		String planData = ALLOW_BLANK;
		String[] planSecs = U.getValues(mainHtml, "\"@type\":\"ProductModel\"", "\"type\":\"plan\"");
		U.log("planSecs: "+planSecs.length);
		
		for(String plan:planSecs) {
			//String[] planIds = U.getValues(plan, "\"community\":\"", "\"");
			//U.log("plan: "+plan);
			String[] planIds = U.getValues(plan, "\"community\":\"", "\"");
			
			for(String id:planIds) {
				//U.log("id: "+id);
				//MATCH
				if(comUniqueId.equals(id)) {
					//U.log(" "+n+" Matched plan: "+id);
					//String planDes = U.getSectionValue(plan, "\"description\":\"", "\"directions\"");
					planData += plan;
					//U.log(" "+quickCount+" data inserted");
					
				}
			}
		}
		
		//============ Prices
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		description = description.replace("400’s", "400000");
		String[] price = U.getPrices(comsec+homesData, "edb\",\"price\":\\d{6}|\\$\\d{6}|Lower \\$\\d{6}|upper \\$\\d{3},\\d{3}|\"priceLow\":\\d{6}|priceHigh\":\\d{6}|"
				+ "starting in the \\$\\d{3},\\d{3}|price\":\\d{6}", 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comsec, "[\\s\\w\\W]{30}494,090[\\s\\w\\W]{30}", 0));
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homesData, "[\\s\\w\\W]{30}494090[\\s\\w\\W]{30}", 0));
		
		//============ Square Feet
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		comsec = comsec.replace(" living space to 3,350 square feet", "");
		String[] sqft = U.getSqareFeet(comsec+homesData, "begin at \\d,\\d{3} sq ft|Composition\",\"sqft\":\\d{4}|\"sqftLow\":\\d{4}|\"sqftHigh\":\\d{4}|\\d,\\d{3} square feet|\\d{4} square feet|\\d,\\d{3} to \\d,\\d{3} square feet|"
				+ "\\d{4} square feet|starting at \\d,\\d{3} sq ft - \\d,\\d{3} sq ft", 0);
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqft: "+minSqft+" maxSqft: "+maxSqft);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comsec, "[\\s\\w\\W]{50}1,800[\\s\\w\\W]{50}", 0));
		//U.log("comsec: "+comsec);
		//============ cType
		String cType = U.getCommType(description);
		U.log("cType: "+cType);
		
		//============ Series data [RED series and WHITE series] - This data can be used for pType and SQFT.
		String series = U.getSectionValue(comsec, "\"feature_series\":\"", "\"");
		String seriesDesSec = ALLOW_BLANK;
		if(series != null) {
//			U.log(">>>>>>>>>>>>"+Util.matchAll(mainHtml, "[\\s\\w\\W]{30}44fafaea80d1445e[\\s\\w\\W]{30}", 0));
			seriesDesSec = U.getSectionValue(mainHtml, "\"_id\":\""+ series +"\"", "ImageObject");
			//U.log("seriesDesSec"+seriesDesSec);
		} 
		
		//============ pType
		description = description.replace("and luxury that Taber LeBlanc himself", "and luxury homes that Taber LeBlanc")
				.replace("Traditional, & Urban Farmhouse Design Opt", "Traditional Style, & Urban Farmhouse Style Design Opt");
		seriesDesSec = seriesDesSec.replace("Traditional, &amp; Urban Farmhouse Design Opt", "Traditional Style, & Urban Farmhouse Style Design Opt");
		
		String pType = U.getPropType(planData+homesData+description+customDes+seriesDesSec);
		U.log("pType: "+pType);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(description, "[\\s\\w\\W]{30}Traditional[\\s\\w\\W]{30}", 0));
		//U.log(">>>>>>>>>>>>"+Util.matchAll(planData, "[\\s\\w\\W]{30}Traditional[\\s\\w\\W]{30}", 0));
		//U.log(">>>>>>>>>>>>"+Util.matchAll(homesData, "[\\s\\w\\W]{30}Traditional[\\s\\w\\W]{30}", 0));
		//U.log("comsec: "+comsec);
		//============ dType
		String dType = U.getdCommType(planData+homesData+description+customDes);
		U.log("dType: "+dType);
		
		//============ Status
		//String status = U.getSectionValue(comsec, "\"status\":\"", "\"");
		//status = status.replace("Closeout", "");
		//U.log("status: "+status);
		String headline = U.getSectionValue(comsec, "\"headline\":\"", "\",");
		headline = headline.replace("Now selling in the Final Phase", "Now selling Final Phase").replace("New Homes in Mustang Coming Soon", "New Homes Coming Soon");
		U.log("headline: "+headline);
		
		description = description.replace("The first phase in Woodland Park sold out extremely quickly", "The first phase sold out")
				.replace("Now selling in the Final Phase", "Now selling Final Phase").replace("Phase 3 is now selling and these new homes in Edmond","Phase 3 now selling")
				.replaceAll("Check out our quick move-in homes and site plan to see|Now selling in the final phase with gorgeous tree-lined homesites available|"
				+ "Homes are now being sold in|Be sure to check out our quick move-in homes and available homesites|Coming Soon to the Mustang Area|basketball court coming soon|"
				+ "opening Fall 2021|community sold out, Highgarden has gained even m, ent Phase Sold Out. Join the VIP List to Purchas|Highgarden is sold out|"
				+ "Black Series community sold out|Now Selling in Phase II|Choose one of our move-in ready homes for sale right", "");
		
		customDes = customDes.replaceAll("Now Selling in Phase II|Choose one of our move-in ready homes for sale right|"
				+ "Be sure to check out our quick move-in homes and available", "");
		String statusFromcomSec = U.getSectionValue(comsec, "\"status\":", "\",");
		
		String Status = U.getPropStatus((description+headline+customDes+statusFromcomSec)
				.replace("park nearby\\u003c/a> coming soon", "").replace("park nearby coming soon", "")
				.replace("Homes by Taber floor plan. \\u003c/span>\\u003c/p>\",\"Grand Opening", "")
				.replace("Now selling in the newest phase", "Now selling")
				.replaceAll("community park nearby coming soon|park nearby\\u003c/a> coming soon|p>\",\"Coming Soon|p>\",\"Grand Open|Canyons are selling fast|gt;\\u003cp&gt;\\u003c/p&gt;\",\"Grand Op|nearby\\u003c/a&gt; coming so", ""));
		//U.log(">>>>>>>>>>>>"+Util.matchAll(description+headline+customDes+statusFromcomSec, "[\\w\\s\\W]{3}Now Selling[\\w\\s\\W]{50}", 0));

//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/statussec.txt", description+headline+customDes+statusFromcomSec);

		U.log("quickCount: "+quickCount);
		
		if(quickCount>0) {
			if(Status == ALLOW_BLANK) Status = "Quick Move-In Homes";
			else if(Status != ALLOW_BLANK) Status += ", Quick Move-In Homes";
		}
		
		String quickHtm = U.getHTML("https://www.homesbytaber.com/homes");
		String rmSec = U.getSectionValue(quickHtm, ">window.__PRELOADED_STATE__", "</html");
		if(rmSec!=null)
		quickHtm =quickHtm.replace(rmSec, "");
//		U.log(quickHtm);
		if(quickHtm.toLowerCase().contains(name.toLowerCase())) {
			if(Status == ALLOW_BLANK) Status = "Quick Move-In Homes";
			else if(Status != ALLOW_BLANK) Status += ", Quick Move-In Homes";
		}
		U.log("Status: "+Status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(description+headline+customDes+statusFromcomSec, "[\\s\\w\\W]{30}Now Selling[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(description, "[\\s\\w\\W]{30}Quick[\\s\\w\\W]{30}", 0));
		
		
//		if(Status.equals("New Phase Coming Soon, Coming Soon")) Status = "New Phase Coming Soon";
//		if(Status.equals("New Phase Coming Soon, Coming Soon, Current Phase Sold Out")) Status = "New Phase Coming Soon, Current Phase Sold Out";
		
		//============ Note
		String note = U.getnote(comsec+planData+homesData);
		U.log("note: "+note);
		String lotIdsSec = Util.matchAll(comsec, "\"properties\":\\[\\],\"type\":\"Feature", 0).size()>0?Util.matchAll(comsec, "\"properties\":\\[\\],\"type\":\"Feature\"", 0).size()+"":ALLOW_BLANK;
		U.log(lotIdsSec);
		data.addCommunity(name, comUrl, cType);
		data.addAddress(street, city, state, zip);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyStatus(Status);
		data.addPropertyType(pType, dType);
		data.addNotes(note);
		data.addUnitCount(lotIdsSec);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

	}

}












