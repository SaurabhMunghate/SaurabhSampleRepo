/*sampada santosh*/
package com.shatam.b_241_260;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSunRiverStGeorgeDevelopmentLC extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://sunriver.com/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractSunRiverStGeorgeDevelopmentLC();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"SunRiver Communities.csv",
				a.data().printAll());

	}

	public ExtractSunRiverStGeorgeDevelopmentLC() throws Exception {

		super("SunRiver Communities", "https://www.sunriver.com/");
		LOGGER = new CommunityLogger("SunRiver Communities");
	}

	public void innerProcess() throws Exception {
		WebDriver driver = null;
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String basehtml = U.getHTML("https://www.sunriver.com/");
		
		HashMap<String, String> homesMap = new HashMap<>();
		String homeHtml = U.getHTML("https://www.sunriver.com/find-a-home");
		String[] homesSection = U.getValues(U.getSectionValue(homeHtml, "Find the community that fits", "</section>"), "<div class=\"sqs-block html-block sqs-block-html\" data-block-type=", "</div></div><div class=\"sqs-block image-block sqs-block-image\"");
		U.log(homesSection.length);
		for(String homeSec : homesSection){
			String homeUrlSec =null; //U.getSectionValue(homeSec, "Explore Community", "</a>");
			String comUrl = U.getSectionValue(homeSec, " href=\"", "\"");
			
			
			if(!comUrl.contains("http"))comUrl = "https://www.sunriver.com"+comUrl;
//			U.log(comUrl);
			
			addDetails(homeUrlSec,comUrl,homeSec, driver);
//			homesMap.put(homeUrlSec, key);
		}
//		U.log("Total Home : "+homesMap.size());
		
		
		String sec = U.getSectionValue(basehtml, "<strong>Communities</strong", "</div></div></div><div class=\"col sqs-col-3");
//		U.log(sec);
		if(sec==null) {
			sec=ALLOW_BLANK;
		}
		String comSections [] = U.getValues(sec, "<p class=\"\" style=\"white-space:pre-wrap;\">", "a></p>");
//		U.log(comSections.length);
		
		for(String comSec : comSections){
//			U.log(comSec);
			
			String comName  = U.getSectionValue(comSec, ">", "</").replaceAll("Villas", "");
			String comUrl = U.getSectionValue(comSec, "href=\"", "\"");
//			U.log(comUrl);
//			String extractHomesData = homesMap.get(comUrl);
			
			if(comName.contains("SunRiver") && !comUrl.contains("http"))comUrl = "https://www.sunriver.com"+comUrl;
//			U.log(comUrl);
//			U.log(" "+extractHomesData);
			addDetails(comName,comUrl, comSec,driver);
			//break;
		}
		LOGGER.DisposeLogger();
//		driver.quit();

	}

	private void addDetails(String comName, String comUrl, String regionSec, WebDriver driver) throws Exception {
		
//		if(!comUrl.contains("https://www.sunriver.com/sunriver-firelight")) return;
		
		U.log(":::::::::::"+comUrl+":::::::::::::::"+U.getCache(comUrl));
		
		String comHtml = U.getHTML(comUrl);
		
		if(comName==null) {
			comName=U.getSectionValue(comHtml, "<title>", "&");
		}
		comName=comName.replace("St. George", "SunRiver St. George");
		U.log("comName::"+comName);
		
		
		if(data.communityUrlExists(comUrl)) {
			
			LOGGER.AddCommunityUrl(comUrl+"=============Repeated=================");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		

		String florUrl = "";
		String floorPlanHtml = "";
		String allFlrPlanData = "";
		if(comUrl.contains("sunriver")&&!comUrl.contains("https://www.sunriver.com/st-george")){           //==
//			florUrl = "https://www.sunriver.com"+ Util.match(extractHomesData, "<a href=\"(.*?)\" class=\"sqs-block-button-element--large ",1);
			florUrl = comUrl+"/floor-plans";
			U.log("iF florUrl : "+florUrl);
				try {
			floorPlanHtml = U.getHTML(florUrl);
			
			for(String fUrl :  Util.matchAll(floorPlanHtml, "<a href=\"(.*?)\" class=\"sqs-block-button-element--small sqs-block-button-element\" >See More Details",1)){
				U.log(fUrl);
	
				String tempHtml = U.getHTML("https://www.sunriver.com"+fUrl);
				allFlrPlanData += U.getSectionValue(tempHtml, "Back to all floor plans", "</section>");
				
			}
				}
				catch(Exception e) {}
			
		}
		else{
//			if(extractHomesData!=null) {
//			florUrl = U.getSectionValue(extractHomesData, "<a href=\"", "\"");//Util.match(extractHomesData, "<a href=\"(.*?)\" class=\"sqs-block-button-element--small sqs-block-button-element\" target=\"_blank\">\\s*$",1);
//			if(!florUrl.contains("https"))florUrl="https://www.sunriver.com"+florUrl;
//			U.log("Else florUrl : "+florUrl);
//			if(comUrl.contains("https://www.hamblinestates.com")){
//				florUrl = florUrl.replace("/homes/", "/homes-for-sale");
//				floorPlanHtml = U.getHtml(florUrl, driver);
//			}
//			
//			else {
//				floorPlanHtml = U.getHTML(florUrl);
//				if(comUrl.contains("https://www.sunriver.com/st-george"))floorPlanHtml = U.getHtml(florUrl,driver);
//			}
//			}
		}
		
		if(comUrl.contains("bloomingtonvillas")) {
			florUrl = comUrl+"/ownership";
			floorPlanHtml = U.getHTML(florUrl);

		}	
		
		U.log(">>>>>>>>>>>>>>>>>>>> "+comUrl+"\t"+U.getCache(comUrl));
		
		//withProxy
		
		String homesHtml = ALLOW_BLANK,amenitiesHtml=ALLOW_BLANK,lifeStyleHtml = ALLOW_BLANK;
		String navbarSections = U.getSectionValue(comHtml, "<div class=\"Mobile-overlay\">", "<button class=\"Mobile-overlay-close");
		String navUrls [] = U.getValues(navbarSections, "<a href=\"", "\"");
		for(String navUrl : navUrls){
			U.log("navUrl ::"+navUrl);
			if(navUrl.contains("/homes"))homesHtml=U.getHTML(comUrl+navUrl);
			if(navUrl.contains("lifestyle"))lifeStyleHtml=U.getHTML(comUrl+navUrl);
			if(navUrl.contains("amenities"))amenitiesHtml=U.getHTML(comUrl+navUrl);
		}
		String[]add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE",note =ALLOW_BLANK;
		if(comUrl.contains("sunriver")){
			add = new String[] {"4782 S Wallace Dr","St. George", "UT", "84790"};
//			latLng = U.getlatlongGoogleApi(add);
			latLng = new String[] {"37.026365","-113.609799"};
			geo= "TRUE";
			note ="Address & LatLong Taken From Contact";
					
		}
		if(comUrl.contains("hamblinestates")){
			add = new String[] {"3174 S Bloomington Dr E","St. George", "UT", "84790"};
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo= "TRUE";	
		}
		if(comUrl.contains("bloomingtonvillas")){
			add = new String[] {"3080 S Bloomington Dr. E","St. George", "UT", "84790"};
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			geo= "TRUE";	
		}
		// ---------community type,property type,property status,derived,property type---------//
		comHtml=comHtml.replaceAll("SunRiver Villas|Villas<|Bloomington Villas|/villas|bloomingtonvillas.com\"|Discovery Villa", "")
				.replaceAll("tagline\">Resort Style|siteTagLine\":\"Resort", "");

		String commType = U.getCommunityType(comHtml);
		String propType = U.getPropType(comHtml+ allFlrPlanData +floorPlanHtml+amenitiesHtml);
		String dpType = U.getdCommType(comHtml);
		
		//making changes for sunriver fireflight community.
		regionSec = regionSec.replace("Spring of 2023</p><h2 style=\"text-align:center;white-space:pre-wrap;\"><strong>COMING SOON"
				, "Coming Soon Spring 2023");
		
		
		String commStatus = U.getPropStatus(regionSec+comHtml.replaceAll("Golf Course Homes Now Available", ""));   //+extractHomesData
		
		U.log("commStatus: "+commStatus);
		
//		U.log(Util.matchAll(regionSec+comHtml , "[\\w\\s\\W]{150}coming soon[\\w\\s\\W]{30}", 0));
		
		
		comHtml = comHtml.replace("alt=\"$499,900\" ", "").replace("<p><strong>$499,900</strong></p>", "");
		//allFlrPlanData=allFlrPlanData.replace("alt=\"$499,900\" ", "").replace("<p><strong>$499,900</strong></p>", "");
//		U.log(Util.matchAll(allFlrPlanData , "[\\w\\s\\W]{30}499[\\w\\s\\W]{30}", 0));

		String[] price = U.getPrices((regionSec+comHtml+floorPlanHtml+allFlrPlanData).replace("00’s", "00,000"), "\\$\\d{3},\\d+", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		comHtml = comHtml.replaceAll("\\d+ sq. ft. clubhouse", "");
		String[] sqft = U.getSqareFeet(comHtml+floorPlanHtml+allFlrPlanData, " \\d,\\d+ sq.ft|\\d{4} Sq. Ft.|\\d{4} sqft|Total SqFt:</strong>(&nbsp;)?\\d,\\d+", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		
//		if(comUrl.contains("https://www.hamblinestates.com")){
//			// values taken from img present at Homes  
//			minSqf = "1890";
//			minPrice = "$349,900";
//		}
		if(comName.contains("Estates") && !propType.contains("Estate")) {
			if(propType.length()<2)propType="Estate-Style Homes";
			else propType=propType+", Estate-Style Homes";
		}
		if(comUrl.contains("https://www.sunriver.com/st-george")) {
//			minSqf = "2,045";
			minPrice = "$399,900";
//			maxPrice="$825,000";
//			maxSqf="4,222";
		}
//		if(comUrl.contains("https://www.hamblinestates.com")){
//			commStatus=ALLOW_BLANK;
//			//from homes images
//			minSqf = "1890";
//			maxSqf = "3325";
//			minPrice = "$264,900";
//			maxPrice = "$699,900";
//			commStatus ="Sold Out";
//		}
//		if(comUrl.contains("https://www.bloomingtonvillas.com"))commStatus="New Phases Coming Soon";
		if(comUrl.contains("https://www.sunriver.com/villas"))comName="SunRiver Villas";
		if(comUrl.contains("https://www.sunriver.com/villas") )
			commType = commType+", 55+ Community"; //From Regionn Img
		if(commStatus.equals("Coming Soon Spring 2023, Coming Soon")) commStatus = "Coming Soon Spring 2023";
		
		
		data.addCommunity(comName, comUrl, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}

	

}