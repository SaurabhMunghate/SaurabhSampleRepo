/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_241_260;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtratAlphaConstruction extends AbstractScrapper {

    WebDriver driver = new FirefoxDriver();
    static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	static String BASE_URL="https://www.alphaconstruction.com/";
	
	static String Builder_Name="Alpha Construction";
	
	public ExtratAlphaConstruction() throws Exception {
	
		super(Builder_Name,BASE_URL);
		LOGGER=new CommunityLogger("Alpha Construction");
		
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) throws Exception
	{
		AbstractScrapper a = new ExtratAlphaConstruction();
		
		a.process();
		
		FileUtil.writeAllText(U.getCachePath()+"Alpha Construction.csv",a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}
	
	@Override
	protected void innerProcess() throws Exception {
	
		// TODO Auto-generated method stub
		
		String mainHtml = U.getHtml("https://www.alphaconstruction.com/general-contractor-galleries-ca/", driver);
		String mainSec=U.getSectionValue(mainHtml, "<h3>Projects</h3>","<h3>Alpha Construction</h3>");
		String[] progValues=U.getValues(mainSec, "<a href=\"","\"");
		for(String progUrl:progValues)
		{
			String progHtml=U.getHtml(progUrl, driver);
			if(progHtml.contains("<ul class=\"pagination clearfix\">"))
			{
				String section=U.getSectionValue(progHtml, "<ul class=\"pagination clearfix\">","Next");
				String[] nextUrl=U.getValues(section, "<li><a href=\"","\"");
				for(String nU:nextUrl)
				{
					U.log(nU);
					progHtml=progHtml+U.getHtml(nU, driver);
				}
			}
			String[] comSec=U.getValues(progHtml, "<li class=\"gallerySet medium-4 columns\">","<div class=\"projectGallery owl-carousel");
			for(String sec:comSec)
			{
				sec=U.removeComments(sec);
				String comUrl=U.getSectionValue(sec, "<a href=\"","\"");
				addDetails(comUrl,sec);
			}
		}
		
		driver.quit();
	}
	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
		
			//if(!comUrl.contains("https://www.alphaconstruction.com/project/california-state-university-northridge/"))return;
			U.log(comData);
			U.log(j+"   commUrl-->"+comUrl);
					String html=U.getHtml(comUrl, driver);
					
					/*String rem=U.getSectionValue(html, "<head>","$919,990");
					html=html.replace(rem,"");*/
					//============================================Community name=======================================================================
					String communityName=U.getSectionValue(comData, "<span class=\"linkTitle\">","</span>").toLowerCase();
					communityName=communityName.replace(", Northridge","");
					if(communityName.endsWith(" townhomes"))communityName =communityName.replace(" townhomes", "");
					if(communityName.endsWith(" condominiums"))communityName =communityName.replace(" condominiums", "");
					U.log("community Name---->"+communityName+"<------");
					
			//================================================Address section===================================================================
					String note="";
					String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
					String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
					String geo="FALSE";
					String addSec=U.getSectionValue(comData, "</p>","<br />");
					if(addSec==null)
					{
						addSec=U.getSectionValue(comData, "</p>","</p>");
					}
					if(addSec==null)
					{
						addSec=U.getSectionValue(comData, "<p>","<br />");
					}
					if(addSec!=null)
					{
						addSec=addSec.replace("<p>","").replaceAll("2200, 2242 &amp|Matador Bookstore Complex,","");
						U.log(addSec);
						if(addSec.contains("</p>"))
						{
							addSec=Util.match(addSec, "</p>[\\s*\\d*\\w*.?,]*");
							addSec=addSec.replace("</p>","");
						}
						String[] add1=addSec.split(",");
						if(add1.length>2)
						{
							add[0]=add1[0];
							add[1]=add1[1];
							add[2]=add1[2];
							if(add1.length==4)
							{
								add[3]=add1[3];
							}
						}
					}
					
					U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					
					if(comUrl.contains("https://www.alphaconstruction.com/project/lime-house-senior-living/")||comUrl.contains("https://www.alphaconstruction.com/project/hollywood-bowl-shell-remodel/"))
					{
						add[0]="14601 AETNA STREET";
						add[1]="VAN NUYS";
						add[2]="CA";
						add[3]="91411";
						geo="TRUE";
						note="Address Taken From Contact";
					}
			//--------------------------------------------------latlng----------------------------------------------------------------
					add[0]=add[0].trim();
					String laSec="" ;//latlong not given on page
					
					
					if(add[0]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
					{
						add=U.getAddressGoogleApi(latlag);
						geo="TRUE";
					}
					if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
					{
						add[0] = add[0].replace("12230 &amp; 12232 ", "12232 ");
						latlag=U.getlatlongGoogleApi(add);
						
						geo="TRUE";
					}
					if((add[3]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
					{
						add[3]=U.getAddressGoogleApi(latlag)[3];
						U.log(add[3]+":::::::::");
						geo="TRUE";
					}
					
					U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
					
			//============================================Price and SQ.FT======================================================================
						
					
					String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
					String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
					
					html=html.replaceAll("0�s|0's|0&#8217;s|0s","0,000");
					String prices[] = U.getPrices(html+comData,"price\">\\$\\d+,\\d+|Starting at \\$\\d+,\\d+|start at \\$\\d+,\\d+", 0);
					
					minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
					maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
					
					U.log("Price--->"+minPrice+" "+maxPrice);
					
			//======================================================Sq.ft===========================================================================================		
					
					
					String[] sqft = U
							.getSqareFeet(
									html+comData,
									"[1-9]\\d+</span> Sq Ft|[1-9],\\d+ square feet",
									0);
					minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
					maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
					U.log("SQ.FT--->"+minSqft+" "+maxSqft);
					
			//================================================community type========================================================
					html=html.replaceAll("country-club|RIVERA COUNTRY CLUB","");
					String communityType=U.getCommType(html+comData);
					
			//==========================================================Property Type================================================
					html=html.replaceAll("multi-family-gallery|Condos</a>|condos menu|Condos|condos|POINT CONDOMINIUMS|point-condominiums|VILLA SENIOR|Villa Senior|Villas at Gower|villas-at-gower|villa-senior|morrison-townhomes|Morrison Townhomes|Courtyard-patio|Redbury-Patio|Jordan Condominiums|jordan-condominiums","");
					if(comUrl.contains("villa"))
						html=html+" villas ";
					String proptype=U.getPropType(html+comUrl);
					
			//==================================================D-Property Type======================================================
					
					String dtype=U.getdCommType(html+comData);
					
			//==============================================Property Status=========================================================
					String pstatus=U.getPropStatus(html+comData);
					
			//============================================note====================================================================
					
					
					
					
					if(data.communityUrlExists(comUrl))
						{
						LOGGER.AddCommunityUrl(comUrl);
						k++;
						return;
						}
					add[0]=add[0].replace(";","").replace("12230 &amp","");
					U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					add[2]=add[2].replace("CA�","CA");
						data.addCommunity(communityName,comUrl, communityType);
						data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
						data.addPrice(minPrice, maxPrice);
						data.addAddress(add[0].toLowerCase().trim(), add[1].toLowerCase().trim(), add[2].trim().replace("…", ""), add[3].trim());
						data.addSquareFeet(minSqft, maxSqft);
						data.addPropertyType(proptype, dtype);
						data.addPropertyStatus(pstatus);
						data.addNotes(note); 
						j++;
		
	}	
}

