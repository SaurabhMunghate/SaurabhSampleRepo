/**
 * @author Priti
 * @date July2018
 * 
 */
package com.shatam.b_261_280;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractAntaresHomes extends AbstractScrapper{
	static int j=0;
	int i=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	
	private static final String BUILDER_URL = "https://www.antareshomes.com";
	public ExtractAntaresHomes() throws Exception {
		super("Antares Homes",BUILDER_URL);
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Antares Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractAntaresHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Antares Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}
	MultiValueMap availhomeDataMap=new MultiValueMap();
	MultiValueMap floorPlanmap=new MultiValueMap();
	@Override
	protected void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String mainHtml=U.getHTML("https://www.antareshomes.com/neighborhoods");
		

		String redirectSec=U.getSectionValue(mainHtml, "{\"redirects\":[", "]");
		String redirects[]=U.getValues(redirectSec, "{", "}");
//		U.log(redirects.length);
		HashMap<String, String>redirectMap=new HashMap<>();
		for (String red : redirects) {
//			U.log(red);
			redirectMap.put(U.getSectionValue(red, "\"from\":\"", "\""), "https://www.antareshomes.com"+U.getSectionValue(red, "\"to\":\"", "\""));
//			break;
		}
		redirectMap.put("/new-homes-godley/timber-creek-estates", "https://www.antareshomes.com/neighborhoods/undefined/timber-creek-estates");
		String homeData[]=U.getValues(mainHtml, "{\"@type\":\"SingleFamilyResidence\"", ",\"type\":\"home\"}");
//		U.log(homeData.length);//{"data":{"plan":{"
		for (String homes : homeData) {
			String key=U.getSectionValue(homes, "\"containedIn\":\"", "\"");
			availhomeDataMap.put(key, homes);
		}
		String planData[]=U.getValues(mainHtml, "{\"data\":{\"plan\":{\"", "}}");
		for (String plans : planData) {
			String key=U.getSectionValue(plans, "\"cmod_communityId\":", ",");
//			U.log(key);
			floorPlanmap.put(key, plans);
		}
		
		
		Map<String,String> commDataMap = new HashMap<>();
		
		String commData[]=U.getValues(mainHtml, "{\"data\":{\"community\":", "\"type\":\"community\"");

//		U.log(floorPlanmap.size());
		U.log(commData.length);
		int i=0;
		for (String comm : commData) {
			
			String commName=U.getSectionValue(comm, "\"com_name\":\"", "\"");
			String commUrl=U.getSectionValue(comm, "\"url\":\"", "\"");
//			U.log(commName+"\t"+commUrl);
			if(commUrl.contains("/page.php?"))continue;
			

			i++;	
			commUrl=redirectMap.get(commUrl);
			commDataMap.put(commUrl, comm);
//			addDetails(commUrl,commName,comm);
		}
			
		String comSections[] = U.getValues(mainHtml, "<div class=\"Community_status\"", "</div></div></div></div>");
		U.log(comSections.length);
		
		for(String comSec : comSections){
//			U.log(comSec);
			String comUrl = U.getSectionValue(comSec, "CommunityCard_detailButton\" href=\"", "\"");
//			U.log("Found"+comUrl);
			String commName = U.getSectionValue(comSec, "<h4 data", "</h4>");
			if(commName != null)commName = commName.replaceAll("-reactid=\"\\d+\">", "");
//			U.log(commName);
			if(!comUrl.startsWith("http")) comUrl = BUILDER_URL+comUrl;
			
			
//			try {
				addDetails(comUrl,commName,commDataMap.get(comUrl)+comSec);
//			} catch (Exception e) {}

		}
		

			j++;
		
		LOGGER.DisposeLogger();
	}

	@SuppressWarnings("unchecked")
	private void addDetails(String commUrl, String commName, String commData) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!commUrl.contains("https://www.antareshomes.com/neighborhoods/saginawnorth-fort-worth/pioneer-point")) return;
		
//		if(i>=12)
		{
		if(data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl(commUrl+"++++++++Repeated+++++");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		U.log("Count= "+i+"\n commUrl=="+commUrl);
//		String commhtml=U.getHTML(commUrl);
		
		String commhtml = U.getHtml(commUrl, driver);
		U.log(U.getCache(commUrl));
		
		
		//-------- FOR QUICK STATUS.----------
		int quickCount = 0;
		
		String[] quickSection = U.getValues(commhtml, "<div class=\"HomeCard_headlineBanner\"", "/div>");
		U.log("quickSection length: "+quickSection.length);
		
		for(String quick:quickSection) {
			
			if(quick.contains("Quick Move-In")) quickCount++;
		}
		
		U.log("quickCount ========= "+quickCount);
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(commhtml, commUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		U.log("regionData: "+commData);
		String detailssec=U.getSectionValue(commData, "\"com_description\":\"", "\"");
		if(detailssec == null) detailssec = ALLOW_BLANK;
		U.log("detailssec: "+detailssec);
		
		String communityName=U.getSectionValue(commData, "\"com_name\":\"", "\"");
		if(communityName == null) communityName = commName;
		
		if(communityName.contains("Manor")) {
			communityName = communityName.replaceAll(" Manor$", "");
		}
		if(communityName.contains("Ranch")) {
			communityName = communityName.replaceAll(" Ranch$", "");
		}
		if(communityName.contains("Estates")) {
			communityName = communityName.replaceAll(" Estates$", "");
		}
		
		U.log("communityName: "+communityName);
		
		//--------------------------------------------Address-----------------------------------------------------------
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLon[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		if (add[0].length()<2&&commhtml.contains("Sales Center Location:</li>")) {
			String addSec=U.getSectionValue(commhtml, "Sales Center Location:</li>", "</ul>");
			
		if(addSec.contains("<li class=\"Detail_infoListItem\"")) {
			
			addSec = addSec.replaceAll("<li class=\"Detail_infoListItem\" data-reactid=\"\\d+\">"
					+ "|<!-- react-text: \\d+ -->|<!-- /react-text -->", "")
					.replace("1004 Norcross Court</li>Crowley, TX 76036</li>(817) 203 - 3192</li>", "1004 Norcross Court, Crowley, TX 76036")
					.replace("Aria Court</li>Forney, TX 75126</li>(817) 736 - 1289</li>", "Aria Court, Forney, TX 75126")
					.replaceAll("</li>", ", ");
		}	
			
			U.log("addSec: "+addSec);
			
			if(addSec!=null) {
				addSec=U.getNoHtml(addSec).replace("Timber Creek Estates   Godley ", "Timber Creek Estates , Godley ")
						.replace("Pkwy   Grand Prairie", "Pkwy,   Grand Prairie").replace("7020 Monterrey Oak Way   Ovilla", "7020 Monterrey Oak Way,   Ovilla")
						.replace("  Heartland  ,   TX     75126   (817) 435 - 4918 ", ",  Heartland  ,   TX     75126")
						.replace("Godley  ,   TX     76044  ", ", Godley  ,   TX     76044  ")
						.replace("Bellingham Road   Saginaw ", "Bellingham Road, Saginaw ")
						.replace("Clairemont Blvd   Cleburne  ,   TX     76033   (817) 854 - 2229", "Clairemont Blvd, Cleburne, TX 76033");
				//U.log("addSec==="+addSec);
				add=U.findAddress(U.getNoHtml(addSec));
				if(add==null&&addSec!=null) {
					add=U.getAddress(addSec);
				}
			}
			
		}
		
		if ((add[0]==null||add[0].length()<3) && commData.contains("\"com_street1\":\"")) {
			add[0]=U.getSectionValue(commData, "\"com_street1\":\"", "\"");
			add[1]=U.getSectionValue(commData, "\"city_name\":\"", "\"");
			add[2]=U.getSectionValue(commData, "\"state_code\":\"", "\"");
			add[3]=U.getSectionValue(commData, "\"com_zip\":\"", "\"");
//			latLon[0]=U.getSectionValue(commData, "\"com_lat\":", ",");
//			latLon[1]=U.getSectionValue(commData, "\"com_lng\":", ",");
		}
		
		latLon[0]=U.getSectionValue(commData, "\"com_lat\":", ",");
		latLon[1]=U.getSectionValue(commData, "\"com_lng\":", ",");
		if(latLon[0]==null) {
			String latSec = U.getSectionValue(commData, "https://www.google.com/maps/place/", "/@");
			latLon = latSec.split(",");
		}
		if(latLon[1] == null)
			latLon[0] = latLon[1] = ALLOW_BLANK;
		U.log("Address: "+Arrays.toString(add));
		U.log("Latlon: "+Arrays.toString(latLon));
		if (add[0].length()<2&& latLon[0].length()>3) {
			add=U.getAddressGoogleApi(latLon);
			if(add == null)add = U.getAddressHereApi(latLon);
			geo="TRUE";
		}
		if (add[0].length()>2&& latLon[0].length()<3) {
			latLon=U.getlatlongGoogleApi(add);
			if(latLon == null) latLon = U.getlatlongHereApi(add);
			if(latLon == null) latLon = U.getNewBingLatLong(add);
			geo="TRUE";
		}
		//--------------------------------------------HomeData-----------------------------------------------------------------
//		String commId=U.getSectionValue(commData, "\"com_id\":", ",");
//		U.log(commId);
//		Collection<String>floorPlans=null;

//		if (floorPlanmap.containsKey(commId)) {
//			floorPlans=(Collection<String>) floorPlanmap.get(commId);
//			U.log("floorPlans: "+floorPlans.size());
//			if(floorPlans!=null&&floorPlans.size()>0) {
//				for (String floorPlan : floorPlans) {
//					floorPlansData+=floorPlan;
//				}
//			}
//		}
//		
//		String idforAvailHome=U.getSectionValue(commData, "html?com=", "&");
//		U.log(idforAvailHome);
//		Collection<String>availHomes=null;
//		
//		if (availhomeDataMap.containsKey(idforAvailHome)) {
//			availHomes=(Collection<String>) availhomeDataMap.get(idforAvailHome);
//			U.log("Avail Home: "+availHomes.size());
//			if(availHomes!=null&&availHomes.size()>0) {
//				for (String availPlan : availHomes) {
//					availHomeData+=availPlan;
//				}
//			}
//				
//		}
		String availHomeData="";
		String floorPlansData="";
		//HomeData 
		String homes[] = U.getValues(commhtml, "<a class=\"HomeCard_imageWrapper\"", "</a></div></div>");
		U.log(homes.length);
		for(String home:homes) {
		
			U.log("homeLink: "+U.getSectionValue(home, "<a class=\"HomeCard_addressLink\" href=\"", "\""));
			
			String homeHtm = U.getHTML("https://www.antareshomes.com"+U.getSectionValue(home, "<a class=\"HomeCard_addressLink\" href=\"", "\""));
			String datSec = U.getSectionValue(homeHtm, "<div class=\"Detail_infoListWrap ", "Visit Community</a></div>")+U.getSectionValue(homeHtm, ",\"brand\":\"Antares Homes\",\"description\":\"", "</script");
			availHomeData += datSec;
		}
		String availHome = U.getSectionValue(commhtml, "Available Homes</h3>", "Available Plans</h3>");
		String availPlan = U.getSectionValue(commhtml, "Available Plans</h3>", "Photo Gallery</h3>");
		
		String planCombinedPrice = null;
		String planPrices[] = U.getValues(commhtml, "<div class=\"planPrice\"", "<div class=");
		for(String planPrice : planPrices) planCombinedPrice+= planPrice;
		//------------------------------------------------SQFT------------------------------------------------
		String minSqFeet=ALLOW_BLANK,maxSqFeet=ALLOW_BLANK;
		//availHomeData+floorPlansData+
		String detailSec = U.getSectionValue(commhtml, "<div class=\"Detail_infoWrapper\" ", "</div>") +
		U.getSectionValue(commhtml, "Community Floor Plans</h3>", ">Photo Gallery</h3>");
		if(detailSec!=null)detailSec=detailSec.replaceAll("<!-- /react-text --><!-- react-text: \\d+ -->\\+<!-- /react-text --></strong><br data-reactid=\"\\d+\"/><!-- react-text: \\d+ -->", " ");

		String homesSec[]=U.getValues(commhtml, "css-17kuv2i m-3", "</a></div></div></div></div>");
		U.log(homesSec.length);
		
		String homesdata="";
		
		
		for(String hs:homesSec) {
			
			homesdata+=hs;
			
		}
		
		availHomeData = availHomeData.replaceAll("</strong><br data-reactid=\"\\d+\"/><!-- react-text: \\d+ -->SQ. FT.<", " SQ FT");
		
		String sqft[]=U.getSqareFeet(commData+availHome+availPlan+detailSec+homesdata+availHomeData, "\\d,\\d{3} SQ FT|\">\\d,\\d{3}</span>|inv_sqft\":\\d{4}|\"mod_sqft\":\\d{4},|\"sqftLow\":\\d{4},\"|\\d,\\d{3} SQ FT", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		

//		U.log("MMMMM"+Util.matchAll(availHomeData,"[\\w\\W\\s]{100}1,991[\\w\\W\\s]{100}",0));
//		U.log("MMMMM"+Util.matchAll(availHomeData,"[\\w\\W\\s]{100}1,638[\\w\\W\\s]{100}",0));
//		U.log("MMMMM"+Util.matchAll(availHomeData,"[\\w\\W\\s]{100}1,730[\\w\\W\\s]{100}",0));
		
		U.log("sqft"+Arrays.toString(sqft));
		//------------------------------------------------SQFT------------------------------------------------
		String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
		if(commUrl.contains("/neighborhoods/red-oak/woods-of-red-oak")||
				commUrl.contains("neighborhoods/saginawnorth-fort-worth/bar-c-ranch") || commUrl.contains("/neighborhoods/waxahachie/the-estates-at-north-grove")){
			commData = commData.replaceAll("com_priceLow\":\\d+", "");
			availHomeData = availHomeData.replaceAll("com_priceLow\":\\d+", "");
		}
		
		String homePrices = ALLOW_BLANK;
		
		if(commhtml.contains("<span class=\"HomeCard_price")) {
			String[] homePricesCom = U.getValues(commhtml, "<span class=\"HomeCard_price", "</div></div>");
			for(String home:homePricesCom) {
				
				U.log("home: "+home);
				home = home.replaceAll("<span class=\"HomeCard_price\" data-reactid=\"\\d+\">\\$(\\d{3},\\d{3})</span>", " \\$$1 ");
				U.log("home: "+home);
				
				homePrices += home;
			}
		}
		
//		U.log(planCombinedPrice);
//		U.log(commData);
//		U.log(availPlan);
//availHomeData+floorPlansData + 
		String prices[]=U.getPrices(availHome+availPlan
				+commData+ planCombinedPrice+homesdata+homePrices, "Priced at </span> \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</span>|\">\\$\\d{3},\\d{3}</span></div>|com_priceHigh\":\\d{6,7}|inv_price\":\\d{6,7}|Price \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}<", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log("Price"+Arrays.toString(prices));
		
		//U.log("MMMMM"+Util.matchAll(commhtml,"[\\w\\W\\s]{100}417,128[\\w\\W\\s]{100}",0));
		//U.log("MMMMM"+Util.matchAll(availHome+availPlan+commData+ planCombinedPrice+homesdata,"[\\w\\W\\s]{100}417,128[\\w\\W\\s]{100}",0));
		//-------------------------------------------------propety Type----------------------------------------
		
		if(commUrl.contains("-manor")) commData = commData + ", The Manors";
		if(commUrl.contains("-estates")) commData = commData + ", Estate Style";
		
		String[] homeSec = U.getValues(commhtml, "<a class=\"btn btn-arrow-white btn-brand2 PlanCard_detailButton\" href=\"", "\"");
		String homeData = ALLOW_BLANK;
		for(String home : homeSec) {
			
			home = "https://www.antareshomes.com"+home;
			homeData += U.getSectionValue(U.getHTML(home), "<h3 class=\"CommunityAbout_title\"", "Elevations</h3><");
			
		}
		
//		U.log("MMMMM"+Util.matchAll(homeData + availHomeData+detailssec+commData,"[\\w\\W\\s]{50}Luxury[\\w\\W\\s]{50}",0));
		
		String propType=U.getPropType((homeData + availHomeData+detailssec+commData)
				.replace("By living in The Estates", "By living in The Estate Style Homes")
				.replace("spacious luxury feel", "Luxury Homes").replaceAll("Wood-Look Tile Flooring in Common Areas|_series\":\"Single Family\"", ""));
		
		if(commUrl.contains("https://www.antareshomes.com/neighborhoods/granbury/abes-landing"))
			propType="Luxury Homes";
		
		//U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(homeData + availHomeData+detailssec+commData, "[\\w\\s\\W]{30}estate[\\w\\s\\W]{30}", 0));
		//-------------------------------------------------derived prop Type----------------------------------------
		if(availHomeData!=null) {
			
			availHomeData = availHomeData.replaceAll("</strong><br data-reactid=\"\\d+\"><!-- react-text: \\d+ -->Story<!-- /react-text --></span>", " story")
					.replaceAll(">(\\d{1})</strong><br data-reactid=\"\\d+\"/><!-- react-text: \\d+ -->Story<", " $1 story");
		}
		commData = commData.replaceAll("imageAltTag\":\".*\"", "");
				
		
//		U.log("=========="+Util.matchAll(commData+availHomeData, "[\\w\\s\\W]{80}story[\\w\\s\\W]{40}",0));
		String derivPropType=U.getdCommType(homeData + detailssec+commData+availHomeData);
		//-------------------------------------------------prop Status----------------------------------------
		detailssec = detailssec.replace("Final Opportunities for the current phase", "Final Opportunities for current phase");
		if(detailssec == null || detailssec == ALLOW_BLANK) 
			detailssec = U.getSectionValue(commhtml, "<meta data-react-helmet=\"true\" name=\"description\"", "<meta");
		
		//U.log(">>>>>"+commData);
		
//		U.log("DETAILSECV"+detailssec);
//		U.log("MMCOMM DATA"+commData);
		String propStatus=U.getPropStatus((detailssec+commData).replace("Opportunites", "Opportunities")
				.replace("hase 2 is coming soon! We are n", "")
				.replaceAll("data-reactid=\"730\">Coming Soon</div></a>|community is coming soon! Join our VIP list|This phase is Coming Soon! Join our VIP list", "")
				.replaceAll("Sales Office Coming Soon|coming soon pricing information|\"447\">Grand Opening</div>|grand opening communities|view our FINAL|z_comImageTitle\":\"close|close out\",\"inv|\"status\":\"Closeout\"|out\",\"com_street1|CLoseout|_closeout_|Trails Close|\"com_status\":\"Grand Opening\"|closeout_wro.png\"|_status\":\"Closeout\"|geTitle\":\"Closeout WRO|geTitle\":\"Coming Soon\"|003cp>Coming Soon|he community \\(coming soon\\)|_status\":\"Coming Soon\"|Coming Soon - Join the VIP Interest List|know about new phases", ""));

		U.log("propStatus: "+propStatus);	
//		U.log(">>>>>>>>>>>>"+Util.matchAll(detailssec+commData, "[\\s\\w\\W]{10}Coming Soon[\\s\\w\\W]{10}", 0));	
		
		//-------- QUICK STATUS-------------
		U.log("quickCount here ==== "+quickCount);
		
		if(quickCount > 0) {
			if(propStatus == ALLOW_BLANK)
				propStatus = "Quick Move-In";
			else if(propStatus != ALLOW_BLANK)
				propStatus = propStatus + ", Quick Move-In";	
			}
		
		
		//-------------------------------------------------Comm Type----------------------------------------
		String commType = ALLOW_BLANK;
		if(detailssec != ALLOW_BLANK) {
			commType = U.getCommType(detailssec.replaceAll("bike lanes to Disc Golf courses|great golfing,|wonderful city golf|coming frisbee golf", ""));
		}
		
		//-------------------------------------------------note----------------------------------------
		String note=U.getnote(detailssec);
		//----------------------------------------------------Image------------------------------------------


		if(commUrl.contains("https://www.antareshomes.com/neighborhoods/keene/bristol-oaks")){
			propType = "Patio Homes";
			derivPropType = "1 Story"; //region section is not properly fetched
		}
		
		if (commUrl.contains("https://www.antareshomes.com/neighborhoods/fort-worth/rosemary-ridge")) {
			propStatus=addStatus(propStatus,"Only 3 Homes Left");
			U.log(propStatus);
//			propStatus = propStatus.replace("Final Opportunities", "Final Opportunities In Phase Four");
			minPrice ="$240,000";
		}
		communityName=communityName.replace("Abe&#x27;s Landing","Abes's Landing");
		if (commUrl.contains("https://www.antareshomes.com/neighborhoods/burleson/bluebird-meadows"))propStatus="Brand New Homesites In The New Phase";
		//if(commUrl.contains("https://www.antareshomes.com/neighborhoods/fort-worth/woodland-springs")) propStatus= "Coming Soon";  //from img on front page - 25 Jan dattaraj
		if(commUrl.contains("https://www.antareshomes.com/neighborhoods/frisco/glen-view")||commUrl.contains("https://www.antareshomes.com/neighborhoods/fort-worth/kingspoint"))propStatus="Sold Out";
		


		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(communityName, commUrl, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLon[0], latLon[1], geo);
		data.addPropertyStatus(propStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFeet, maxSqFeet);
		data.addPropertyType(propType, derivPropType);
		data.addNotes(note);
		
		i++;
		}
	}
	
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("<path class=\"leaflet-interactive")) {
			
			ArrayList<String> pins = Util.matchAll(html, "<path class=\"leaflet-interactive", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());

		}
		
		
		return totalUnits;
	}

	private String addStatus(String propStatus, String string) {
		if (propStatus.length()<3) {
			propStatus=string;
		}else {
			propStatus=propStatus+", "+string;
		}
		return propStatus;
	}

	
}