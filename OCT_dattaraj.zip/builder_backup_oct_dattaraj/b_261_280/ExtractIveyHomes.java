/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractIveyHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static String builderUrl = "https://www.iveyhomes.com";
	public ExtractIveyHomes() throws Exception {
		super("Ivey Homes",builderUrl);
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Ivey Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractIveyHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ivey Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k); 

	}
	WebDriver driver= null;
	MultiValueMap quickHomes=new MultiValueMap();
	@Override
	protected void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver  = new FirefoxDriver();
		String mainHtml=U.getHtml("https://www.iveyhomes.com/communities",driver);
		String quickSec=U.getHtml("https://www.iveyhomes.com/homes",driver);
		String quickHomesSecs[]=U.getValues(quickSec, "class=\"shadow\"", "Details</a>");
		U.log(quickHomesSecs.length);
		for (String quickHome : quickHomesSecs) {
//			U.log(quickHome);
			if(quickHome.contains("Under Construction"))
				continue;
			String commName=U.getNoHtml(U.getSectionValue(quickHome, "<span>Community:</span>", "</a>")).trim();
//			U.log(commName);
			quickHomes.put(commName, quickHome);
		}
		String[] comSec=U.getValues(mainHtml, "class=\"result-title ng-binding","Visit Neighborhood");
		U.log(comSec.length);
		for(String comData:comSec)
		{
			String comUrl=builderUrl+U.getSectionValue(comData, "ng-href=\"","\"");
			addDetails(comUrl,comData);
			
		}
		
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.iveyhomes.com/sinclair-at-crawford-creek"))return;
		
//		try 
//		if(j>4)
		{
		U.log("::::::::::::::::"+j+"\ncommUrl-->"+comUrl);
		
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"*************Repeated*************");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHtml(comUrl, driver);
	
		//============================================Community name=======================================================================
				String communityName=U.getSectionValue(comData, "\">","<").replace("&#8217;","");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				String note=ALLOW_BLANK;
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				String addSec=U.getSectionValue(html,"<span class=\"ng-binding\">","</span>");
				
				if(addSec!=null)
				{
					String add1[]=addSec.split(",");

					U.log(Arrays.toString(add1));
					
					if(add1.length==3)
					{
						add[0]=add1[0];
						add[1]=add1[1];
						add[2]=add1[2];
					}
				}
				
				if(comUrl.contains("https://www.iveyhomes.com/brighton"))
					addSec = U.getSectionValue(html, "Our Model Home is now open! Visit us at", ".&nbsp;");
				
				if(addSec!=null)
				{
					String add1[]=addSec.split(",");

					//U.log(Arrays.toString(add1));
					
					if(add1.length==3)
					{
						add = U.getAddress(addSec);
					}
				}
				if(comUrl.contains("https://www.iveyhomes.com/sinclair-at-crawford-creek")) {
					
					add[0]="2045 Sinclair Drive";
					add[1]="Grovetown";
					add[2]="GA";
				
					latlag=U.getlatlongGoogleApi(add);
					add=U.getAddressGoogleApi(latlag);
					geo="True";
				}
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		//--------------------------------------------------latlng----------------------------------------------------------------
				String latSec=U.getSectionValue(html, "http://maps.google.com/?q=","\"");
				
				if(latSec==null)
					latSec = U.getSectionValue(html, "href=\"http://maps.google.com/?q=", "\"");
				
				if(latSec!=null)
				{U.log(latSec);
					latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
					latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
				}
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}
				if((add[0].length()<4 || add[3]==null) && latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressGoogleApi(latlag);
					geo="TRUE";
				}
				if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
				{
					String[] add1=U.getAddressGoogleApi(latlag);
					if(add1 == null) add1 = U.getAddressHereApi(latlag);
					
					add[3]=add1[3];
					add1 = null;
					geo="TRUE";
				}
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
		//============================================Price and SQ.FT======================================================================
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				String homeHtml=U.getHtml(comUrl+"-homes", driver);
				String floorHtml=U.getHtml(comUrl+"-floorplans", driver);
				homeHtml=homeHtml.replaceAll("<option value=(.*?)</option>", "");
				floorHtml=floorHtml.replaceAll("<option value=(.*?)</option>", "");

				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k|0’s","0,000").replace("$1 million","$1,000,000");
				comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
//				U.log(Util.matchAll(html+comData+homeHtml+floorHtml, "[\\w\\s\\W]{50}quick[\\w\\s\\W]{50}",0));
				String prices[] = U.getPrices(html+comData+homeHtml+floorHtml,"from the \\$\\d{3},\\d{3}|From the \\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d+|\\$\\d{3},\\d+", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
				String[] sqft = U
						.getSqareFeet(
								html+comData+homeHtml+floorHtml,
								"\\d+,\\d+ Sq. Ft.|\\d+,\\d+ sq. ft|\\d+,\\d+ Sq.Ft.",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
		//=============== Available Home ===================
				String combinedAvailHtml = ALLOW_BLANK;
				String [] availableHomeSec = U.getValues(homeHtml, "<h4 class=\"result-title", "<div class=\"clearfix\">");
				for(String availableSec : availableHomeSec){
					String availableUrl = U.getSectionValue(availableSec, "ng-href=\"", "\"");
					U.log("availableUrl::::::"+availableUrl);
					String hHtml =U.getHtml(builderUrl+availableUrl, driver);
					combinedAvailHtml += U.getSectionValue(hHtml, "<h3 ng-if=\"home.inv_street1\"", "ng-if=\"home.districts.length");
					
					combinedAvailHtml = combinedAvailHtml.replace("home is the very definition of luxury", "home is the very definition of luxury homes ").replace("first floor is a guest ", "first story is a guest ");
				}
		//===============all floor Data============
				String combinedFloorlHtml = ALLOW_BLANK;
				String [] floorUrls = U.getValues(floorHtml, "<h4 class=\"result-title", "<div class=\"clearfix\">");
				for(String floorUrl : floorUrls){
					try {
					floorUrl = U.getSectionValue(floorUrl, "ng-href=\"", "\"").replace("&amp;", "&");
					U.log("floorUrl::::::"+floorUrl);
					String fHtml =  U.getHtml(builderUrl+floorUrl, driver);
					combinedFloorlHtml += U.getSectionValue(fHtml, "<h3 class=\"ng-binding\">", "l-detail-main detail\">");
					
					}catch(Exception e) {}
					}
//				U.log(combinedFloorlHtml);
		//================================================community type========================================================
				html=html.replaceAll("Master Plan</a>|/master-plan-map","");
				String communityType=U.getCommType(html+comData);
				
		//==========================================================Property Type================================================
				html = html.replaceAll("Village|Windsor Townhomes", "").replaceAll("southern traditional", "traditional homes").replace("href=\"/homes\">Quick Move-In Homes</a>", "");
				U.log(Util.matchAll(html+comData+combinedFloorlHtml+combinedAvailHtml, "[\\w\\s\\W]{50}Villa[\\w\\s\\W]{50}", 0));

				String html1=U.getNoHtml(html);
				String proptype=U.getPropType((html1+comData+combinedFloorlHtml+combinedAvailHtml).replace("luxurious Owner", ""));
				U.log("proptype===="+proptype);
		//==================================================D-Property Type======================================================
				String dtype=U.getdCommType(html1+comData+homeHtml+floorHtml+combinedAvailHtml+combinedFloorlHtml);
				U.log("dtype===="+dtype);
		//==============================================Property Status=========================================================
				html=html.replaceAll("Community Closeout|Community Closeout Incentive", "").replace(" Premium Home sites are available", "Premium Home sites available").replaceAll("Current Close-Out Incentives Available:|playground coming in 2019|Pool Now Open|Self-Guided Tours Now Available", "");
				String pstatus=U.getPropStatus(html1+comData);
				U.log("pstatus===="+pstatus);
		//============================================note====================================================================

				
				Collection<String[]> quickData=quickHomes.getCollection(communityName);
//				U.log(quickData.size());
				if (quickData!=null&&quickData.size()>0) {
					if (pstatus.length()>2) {
						pstatus+=", Quick Move-in Home";
					}else {
						pstatus="Quick Move-in Home";
					}
				}
				
				communityName=communityName.replace("Eagle Eye Single Family","Eagle Eye");
				
				geo="TRUE";
//					if(comUrl.contains("/tillery-park"))pstatus=pstatus+", Coming Soon";
					
					
//					===========================================================================
//					U.log(Util.matchAll(html, "[\\w\\s\\W]{30}Neighborhood Layout[\\w\\s\\W]{30}", 0));
					String lotCount=ALLOW_BLANK;
					String mapHtml=ALLOW_BLANK;
						String mapLinkSec=U.getSectionValue(html, "Neighborhood Layout", "</li>");
						U.log("mapLinkSec=="+mapLinkSec);
						if(comUrl.contains("crawford-creek")) {
							mapLinkSec=U.getSectionValue(html, "Neighborhood Layout<img", "</li></ul>");
						}
						U.log("mapLinkSec-2=="+mapLinkSec);
						if(mapLinkSec!=null) {
						String[] mapLinks=U.getValues(mapLinkSec, "<a href=\"", "\"");
						U.log("mapLinkSec-2=="+mapLinks.length);
						for(String mapLink : mapLinks) {
							U.log("mapLink=="+mapLink);
						if(!mapLink.contains("https:")) 
							mapLink="https://www.iveyhomes.com"+mapLink;
						
						if(mapLink!=null) {
							
//							if(mapLink.equals("https://www.iveyhomes.com"))return;
							
							mapHtml+=U.getHtml(mapLink, driver);
						
					}
						}
//						String lotDataSec=U.getSectionValue(mapHtml, "<div class=\"im_map_container\"", "<script");
						String [] lotData=U.getValues(mapHtml, "<div class=\"im_point\"", "</div>");
						U.log("lotData=="+lotData.length);
						if(lotData.length>0) {
							lotCount=Integer.toString(lotData.length);
						}
						else
							lotCount=ALLOW_BLANK;
						
						}
						U.log("lotCount=="+lotCount);
					
					
					
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addUnitCount(lotCount);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
					
		}
		j++;
//					catch(Exception e){}
	}
}