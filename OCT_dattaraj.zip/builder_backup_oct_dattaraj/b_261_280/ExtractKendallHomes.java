/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKendallHomes extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.kendallhomes.net";
	
	public ExtractKendallHomes() throws Exception {
		super("Kendall Homes", "https://www.kendallhomes.net/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Kendall Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractKendallHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Kendall Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
		

		
		
		
	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml = U.getHTML("https://www.kendallhomes.net/communities/");
//		String[] comSec = U.getValues(mainHtml, "<div class=\"communitylist-item communitylist-home-item\">","View More");
		
		String[] comSec = U.getValues(mainHtml, "</wix-image></div>","More Info</span>");
		
		U.log("Total Community<<<<<<" + comSec.length);
		for (String comData : comSec) {
//			U.log(comData);
			String comUrl = U.getSectionValue(comData, "href=\"", "\"");
			//String communityName = U.getSectionValue(comData, "<h3>", "</h3>");
			String communityName = U.getSectionValue(comData, "<span class=\"color_15\">", "</span>");
			if(!comUrl.startsWith("http")){
				comUrl = builderUrl + comUrl.replaceAll("^\\.", "");
			}
			U.log(comUrl);
			addDetails(comUrl, communityName, comData);
		}
		addDetails("https://www.kendallhomes.net/communities-1/Rose-Hill-Estates", "Rose Hill Estates", "");
/*		mainHtml = U.getHTML("https://www.kendallhomes.net/");
		mainHtml = U.getSectionValue(mainHtml, "<li id=\"menu-item-1671\"", "</ul>")
				+ U.getSectionValue(mainHtml, "<li id=\"menu-item-1903\"", "</ul>");
		// U.log(mainHtml);
		U.log("Total Community>>>>>" + comSec.length);
		for (String comData : comSec) {
			comData = comData.replaceAll("id=(.*?)>", "");
			if (comData.contains("communities/communities/"))
				continue;
			String comUrl = U.getSectionValue(comData, "href=\"", "\"");
			// U.log(comData);
			String communityName = U.getSectionValue(comData, "\">", "</a>");
			addDetails(comUrl, communityName, comData);
		}*/
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String communityName, String comData) throws Exception {
		// TODO Auto-generated method stub
//		 if(j == 3)
		{


		if (!comUrl.contains("https://www.kendallhomes.net/communities-1/Brazos-Country"))return;
//			
//			if(comUrl.contains("https://www.kendallhomes.net/communities-1/Forest-Creek")) {
//				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Return");
//				return;
//			}
			
			U.log(j + "   commUrl-->" + comUrl);
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + ":::::::::::::::::::::::::::Repeat");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getPageSource(comUrl);
			//String htmlNew = U.getHTML();
			html = U.removeComments(html);
//			html = removeScriptAndStyle(html);
			U.log(U.getCache(comUrl));
			html=U.removeSectionValue(html, "<footer ", "</html");
			U.log("community Name---->" + communityName);
			
			comData = comData.replaceAll("Homes from \\$(\\d{3})&#39;s", "Homes from \\$$1,000");
//			U.log(">>>>>>>>"+comData);

			
			
			// ===============Address section==========

			String note = ALLOW_BLANK;
			note = U.getnote(U.getNoHtml(html.replaceAll("Reserve \\| Pre-Selling|From\":\"Pre-Selling|Pre-Selling Now \"", "")));
			
			
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			
			String addSec = U.getSectionValue(html, "Model Home", "<p class=\"font_7\" style=\"font-size:18px;");
			
//			U.log("addSec ::"+addSec);
			if(addSec != null){
				
				addSec = U.getNoHtml(addSec).trim();
				U.log("addSec ::"+addSec);
				addSec = addSec.replace("Manor Conroe", "Manor, Conroe").replaceAll(", USA", "");
				addSec = addSec.replaceAll(" (Ln|Dr|Rd|Ave|Blvd)\\. ", " $1, ");
				add = U.getAddress(addSec);
			}
			U.log("Add :"+Arrays.toString(add));
			
			if(comUrl.contains("https://www.kendallhomes.net/communities-1/Brazos-Country")){
//				add = U.getAddress("413 Briar Creek Ln, Sealy, TX 77474"); //Region Page Map Direction
				add[0]="-";
				add[1]="Brazos Country";
				add[2]="TX";
				add[3]="-";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latlng);
				note="Address Is Taken From City & State";
				geo = "TRUE";
			}
				
			if (add[0].length() > 4 && latlng[0].length() < 4) {
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo = "TRUE";
			}

/*			if (latlng[0].length() > 4 && add[0].length() < 4) {
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo = "TRUE";
			}*/

			
			if(comUrl.contains("https://www.kendallhomes.net/communities-1/Hill-and-Dale-Ranch")){			
				add[0]="427 Mason Park Blvd";
				add[1]="Katy";
				add[2]="TX";
				add[3]="77450";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				note="Address Is Taken From Contact";
				geo = "TRUE";

			}
			if(comUrl.contains("https://www.kendallhomes.net/communities-1/Rose-Hill-Estates")
					||comUrl.contains("https://www.kendallhomes.net/communities-1/Forest-Creek")
					)
			{
				add[0]="-";
				add[1]="Willis";
				add[2]="TX";
				add[3]="-";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latlng);
				note="Address Is Taken From City & State";
				geo = "TRUE";
			}
			if(comUrl.contains("https://www.kendallhomes.net/communities-1/Bullinger-Creek"))
			{
				add[0]="-";
				add[1]="Sealy";
				add[2]="TX";
				add[3]="-";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latlng);
				note="Address Is Taken From City & State";
				geo = "TRUE";
			}
			//============== Move In Ready ==================
			

			String moveInSection = U.getSectionValue(html, "Move in Ready", "Load More");
			String storiesSection = "",descriptionSec ="";
			String combinedMoveInHtml = "";
			int moveInCount = 0;

			//U.log(moveInSection);
			if(moveInSection != null){
//				U.log( Util.match(moveInSection, "<a data-testid=\"linkElement\" href=\"(.*?)\"", 1));
				ArrayList<String> moveInUrlList = Util.matchAll(moveInSection, "<a data-testid=\"linkElement\" href=\"(.*?)\"", 1);
				Set<String> uniqueSet = new HashSet<>(moveInUrlList);
				moveInUrlList.clear();
				moveInUrlList.addAll(uniqueSet);
				U.log("Total Move In :"+moveInUrlList.size());
				for(String moveInUrl : moveInUrlList){
					if(!moveInUrl.startsWith("http")) moveInUrl = builderUrl + moveInUrl;
					U.log("moveInUrl ::"+moveInUrl);
					String moveInHtml = U.getHTML(moveInUrl);
					combinedMoveInHtml += U.getSectionValue(moveInHtml, "<div id=\"comp-k9eozslq\"", "<div id=\"comp-ka8njrja\"");
					storiesSection += U.getSectionValue(moveInHtml, "<div id=\"comp-k8xx04gq\"",	"</h2");
					descriptionSec += U.getSectionValue(moveInHtml, "id=\"comp-k8xmmz60\">",	"</p>");

//					"top:145px;bottom:;left:160px;right:;width:120px;height:auto;position:absolute;min-height:76px;pointer-events:none\" data-min-height=\"76\" class=\"txtNew\" id=\"comp-k8xx04gq\">",
					//U.log(storiesSection);
					moveInCount++;
				}
			}
			//=========== Ready To Build ================
/*			String readyToBuild = U.getSectionValue(html, "Ready to Build", "Load More");
			
			if(readyToBuild != null){
				ArrayList<String> readyUrlList = Util.matchAll(readyToBuild, "<a href=\"(.*?)\"", 1);
				Set<String> uniqueSet = new HashSet<>(readyUrlList);
				readyUrlList.clear();
				readyUrlList.addAll(uniqueSet);
				U.log("Total Ready To Build :"+readyUrlList.size());
				for(String readyToBuildUrl : readyUrlList){
					U.log("readyToBuildUrl ::"+readyToBuildUrl);
					String readyHtml = U.getHTML(readyToBuildUrl);
					storiesSection += U.getSectionValue(readyHtml, 
							" class=\"txtNew\" id=\"comp-k8xx04gq\">",
							"</h2");
//					"top:145px;bottom:;left:160px;right:;width:120px;height:auto;position:absolute;min-height:76px;pointer-events:none\" data-min-height=\"76\" class=\"txtNew\" id=\"comp-k8xx04gq\">",
					//U.log(storiesSection);
				}
			}
			
	*/		//========= Avail HOme ============
			String[] availSec = U.getValues(html, "<h4 class=\"font_2\"", "More Info");
			U.log("AvailHome Count::::"+availSec.length);
			for(String avail : availSec) {
//				U.log("----->"+avail);
				String avilUrl = U.getSectionValue(avail, "<a data-testid=\"linkElement\" href=\".", "\"");
				if(avilUrl == null)continue;
				U.log("avail Url:: "+avilUrl);
				
				if(!avilUrl.startsWith("http")) avilUrl = builderUrl + avilUrl;
				String availhtml = U.getHTML(avilUrl);
				storiesSection  += U.getSectionValue(availhtml, "id=\"comp-k8xx04gq\"",	"</h2");
			}
			// ---------------Fetching Quick Move in Plans
			// Data------------------------------
			/*String allQuickPlanData = ALLOW_BLANK;

			String quickSec = U.getSectionValue(html, "<h3>Quick Move-ins</h3>", "<form method=\"POST\"");
			// U.log(quickSec);

			if (quickSec != null) {
				String[] quickUrls = U.getValues(quickSec, "<h4><a href=\"", "\"");
				for (String quickUrl : quickUrls) {
					U.log("quickUrl::::" + quickUrl);
					String quickHtml = U.getHTML(quickUrl);
					allQuickPlanData += U.getSectionValue(quickHtml, "<h4>Elevations</h4>",
							"<h3 class=\"widget-title\">Elevations</h3>");
				}
			}

			String planData = "";
			String[] planUrl = U.getValues(html, "<div class=\"comlist-item-details2\">", "<h3>");
			for (String string : planUrl) {
				U.log(U.getSectionValue(string, "<a href=\"", "\""));
				String data = U.getHTML(U.getSectionValue(string, "<a href=\"", "\""));
				planData = planData + U.getSectionValue(data, "Specifications</h3>", "Elevations");
			}*/

			//HOMES DATA available and quick using payload
			 
			String availHtml = "";
			String quickHtml  = "";
			for(int i = 0; i <= 1 ; i++) { 
				if(i == 1) i = 9;
				availHtml += sendPostRequestAcceptJson("https://www.kendallhomes.net/_api/cloud-data/v1/wix-data/collections/query", 
					"{\"collectionName\":\"QUICKMOVEINHOMES\",\"dataQuery\":{\"filter\":{\"$and\":[{\"neighborhood\":{\"$eq\":\"" + communityName + "\"}},{\"moveInReady\":{\"$eq\":\"NO\"}}]},\"sort\":[{\"fieldName\":\"story\",\"order\":\"ASC\"},{\"fieldName\":\"sqftNumber\",\"order\":\"ASC\"}],\"paging\":{\"offset\":"+ i +",\"limit\":9}},\"options\":{},\"include\":null,\"segment\":\"LIVE\",\"appId\":\"79401c36-308e-4f35-aafc-0bd6c3de0e0d\"}");
			
				quickHtml += sendPostRequestAcceptJson("https://www.kendallhomes.net/_api/cloud-data/v1/wix-data/collections/query", 
					"{\"collectionName\":\"QUICKMOVEINHOMES\",\"dataQuery\":{\"filter\":{\"$and\":[{\"neighborhood\":{\"$eq\":\""+ communityName +"\"}},{\"moveInReady\":{\"$eq\":\"NO\"}}]},\"sort\":[{\"fieldName\":\"story\",\"order\":\"ASC\"},{\"fieldName\":\"sqftNumber\",\"order\":\"ASC\"}],\"paging\":{\"offset\":"+ i +",\"limit\":9}},\"options\":{},\"include\":null,\"segment\":\"LIVE\",\"appId\":\"79401c36-308e-4f35-aafc-0bd6c3de0e0d\"}");
			}
			
			
			
			String allplanData =ALLOW_BLANK;
			String dynamicApiData = U.getHTML("https://www.kendallhomes.net/_api/v2/dynamicmodel");
			String floorplanApi = U.getSectionValue(html, "\"floor-plans\":{\"urlData\":", "},\"optionsData\":");
			String url_parameter = U.getSectionValue(floorplanApi, "\"queryParams\":\"", "&");
			String appapi = U.getSectionValue(floorplanApi, "\"appDefinitionId\":\"", "\"");
			String wixcode = U.getSectionValue(dynamicApiData, appapi+"\":", "}");
			if(wixcode!=null)wixcode= U.getSectionValue(wixcode, "{\"instance\":\"", "\"");
			U.log(url_parameter+":::"+appapi+"::"+wixcode);
			String homeDataurl = "https://www.kendallhomes.net/_api/wix-code-public-dispatcher/siteview/wix/data-web.jsw/find.ajax?"+url_parameter+"&instance="+wixcode+"&viewMode=site";
			String payload = "[\"QUICKMOVEINHOMES\",{\"$and\":[{\"neighborhood\":{\"$eq\":\"Meadow Glen\"}},{\"moveInReady\":{\"$eq\":\"NO\"}}]},[{\"story\":\"asc\"},{\"sqftNumber\":\"asc\"}],0,100,null,null]";
			allplanData = U.sendPostRequestAcceptJson(homeDataurl, payload);
			if(!allplanData.contains(communityName)) {
				allplanData =ALLOW_BLANK;
			}
			//U.log("allplanData: "+allplanData);
			//U.log("availHtml: "+availHtml);
			//U.log("quickHtml: "+quickHtml);
			// ==========Price and SQ.FT===========

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replace("�s", ",000");
			html = html.replaceAll("0�s|0's|0&#8217;s|0s|0&rsquo;s|0k's|0k|0&prime;s|0&rsquo;s|0’s", "0,000")
					.replace("$1 million", "$1,000,000").replace("'s</p>", ",000</p>");
			comData = comData.replaceAll("0&#8217;s|0�s|0's", "0,000");
			
			String remainHomeHtml = U.sendPostRequestAcceptJson("https://www.kendallhomes.net/_api/wix-code-public-dispatcher/siteview/wix/data-web.jsw/find.ajax?gridAppId=79401c36-308e-4f35-aafc-0bd6c3de0e0d&instance=wixcode-pub.72a4db851fed86581152b0e609a22e5a88def53e.eyJpbnN0YW5jZUlkIjoiMGE5M2E3OGYtY2ZjNi00OGUxLTljMWYtNTBjOWUzODE2ODEyIiwiaHRtbFNpdGVJZCI6ImM4OGRhZTAyLWI4MDItNDM2My1iODE3LTkyOWU4ZWViZThjMiIsInVpZCI6bnVsbCwicGVybWlzc2lvbnMiOm51bGwsImlzVGVtcGxhdGUiOmZhbHNlLCJzaWduRGF0ZSI6MTYzNTM5NzY5Mzc4OCwiYWlkIjoiNmM0YmE2NDktNGY2YS00NzQ4LTg0YjYtMTAwYTI1NjhlMjcyIiwiYXBwRGVmSWQiOiJDbG91ZFNpdGVFeHRlbnNpb24iLCJpc0FkbWluIjpmYWxzZSwibWV0YVNpdGVJZCI6IjcwZWNmNjZlLWNhOGItNDFkYS04MDViLTUxYTJjOTM4MGJlOSIsImNhY2hlIjpudWxsLCJleHBpcmF0aW9uRGF0ZSI6bnVsbCwicHJlbWl1bUFzc2V0cyI6Ikhhc0RvbWFpbixTaG93V2l4V2hpbGVMb2FkaW5nLEFkc0ZyZWUsSGFzRUNvbW1lcmNlIiwidGVuYW50IjpudWxsLCJzaXRlT3duZXJJZCI6Ijc3NzhlNmRlLTY1MDctNDRmNS1hY2ZiLTU2MGM0MWY2MTM2ZCIsImluc3RhbmNlVHlwZSI6InB1YiIsInNpdGVNZW1iZXJJZCI6bnVsbH0=&viewMode=site",
					"[\"QUICKMOVEINHOMES\",{\"$and\":[{\"neighborhood\":{\"$eq\":\""+communityName.trim()+"\"}},{\"moveInReady\":{\"$eq\":\"NO\"}}]},[{\"story\":\"asc\"},{\"sqftNumber\":\"asc\"}],null,null,null,null,null]");
//			U.log(comData);
			html = html.replace("$260,000", "").replace("$330,000", "").replace("$290,000","");
			String prices[] = U.getPrices((html + comData+allplanData +remainHomeHtml+availHtml+quickHtml).replaceAll("from $290,000</span>", ""),
					"\"price\":\"\\$\\d{3},\\d{3}\"|price: \"\\$\\d{3},\\d{3}\"|\\$\\d{3},\\d{3}\\s+</h1>|value\">\\$\\d+,\\d+|From the \\$\\d+,\\d+| the \\$\\d{3},\\d+|Homes from \\$\\d{3},\\d{3}|Price from \\d{6}|Price from [\\$]*\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|to the \\$\\d{3},\\d{3}|the Mid \\$\\d{3},\\d{3}|\"price\":\"\\$\\d{3},\\d{3}\"",
					0);
			
			allplanData=allplanData.replaceAll("sqFt\":\"2,597", "");
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			
			U.log("Price--->" + minPrice + " " + maxPrice);

//			U.log(">>>>>>>>>>"+Util.matchAll(allplanData ,"[\\w\\s\\W]{30}\\$245[\\w\\s\\W]{30}", 0));

			// ====================Sq.ft==============
			html = html.replaceAll("sans-serif\">\\s*\\$\\d,\\d{3}", "");
			ArrayList<String> sqfts= Util.matchAll(html, ">(\\d,\\d{3})\\s*</span>", 1);
			//U.log(Arrays.toString(sqfts.toArray()));
			String sqftlist="";
			for(String sqft:sqfts) {
				sqftlist+=sqft+" sq. ft.::::::::";
			}

			html = html.replaceAll(">\\s*(\\d,\\d{3})\\s*</span>\\s*</span>\\s*</span>\\s*</p>\\s*</div>\\s*<div id=\".*\" class=\".*\" data-testid=\"richTextElement\">\\s*<h1 class=\"font_0\" style=\"font-size:\\d+px; text-align:center;\">\\s*<span style=\"font-size:\\d+px;\">\\s*SQ FT.\\s*</span>", 
					">$1 SQ FT.</span>");
			
			//U.log(html);
			//U.log(sqftlist);
			html = html.replaceAll("<div data-packed=\"true\".*>", "")
					.replaceAll("<span style=\".*\">", "")
					.replaceAll("<h1 class=\"font_0\" style=\".*\">", "")
					.replaceAll("</span>\\s+</span>\\s+</span>\\s+</p>\\s+</div>\\s+", "")
					.replaceAll("<div id=\"(.*?)\" class=\"_1Z_nJ\" data-testid=\"richTextElement\">", "");
			
			availHtml=availHtml.replaceAll("sqFt\":\"2,597|sqftNumber\":(2597.0|2481.0)", "");
			quickHtml=quickHtml.replaceAll("sqFt\":\"2,597|sqftNumber\":(2597.0|2481.0)", "");
			allplanData=allplanData.replaceAll("sqftNumber\":(2597|2481)", "");
			
			
			String[] sqft = U.getSqareFeet((html + comData+sqftlist+allplanData+availHtml+quickHtml),
					"\"sqftNumber\":\\d{4}|\\d,\\d{3}\\s+SQ FT\\.|\\d{1},\\d{3}\\s+SQ FT\\.|value\">\\d{4}|value\">\\d{1},\\d{3}|\\d,\\d{3} <span class=\"dull-txt\">Sq Ft|\\d{4} <span class=\"dull-txt\">Sq Ft|>\\d,\\d{3} sq. ft.|\\d,\\d{3} sq. ft.|\"sqftNumber\":\\d{4}",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			//for load more - 2 comm.
//			if(comUrl.contains("https://www.kendallhomes.net/communities-1/Lake-Conroe-Hills") ||
//					comUrl.contains("https://www.kendallhomes.net/communities-1/Grand-Oaks-Reserve")) maxSqft = "2597";
			
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
			// ============ Community type========
			html = html.replace("Elongated", "");
//			String rem = U.getSectionValue(html, "<div class=\"sub_footer\">", "</body>");
//			html = html.replace(rem, "");
			String communityType = U.getCommType(html + comData);

			// =============Property Type========
			String[] vals = U.getValues(html, "<script>", "</style>");
			for(String val : vals) html = html.replace(val, "");
			
			html = html.replace("Homeowner&#39;s", "Homeowner's").replaceAll("LUXURIOUS\\s+</span>\\s+</h6>", "luxury homes");
			String proptype = U
					.getPropType((html+descriptionSec.replaceAll("HOA - Steve Durham|HOA fees are not included|Custom-Community|Fran BornKendall Custom Homes|Custom Community", "")
							+ (comData).replaceAll("Custom|custom", "") + combinedMoveInHtml).replace("Laurel Manor", ""));


			
			// ================= D-Property Type==============
			html = html.replaceAll("Ranch|ranch", "");
//			planData = planData.replaceAll("Stories</span><br>\\s*|<span class=\"dull-txt\">Stories", "Story ");
			// U.log(planData);
			html = html.replace("Stories <span class=\"value\">", "Story ");
			U.log(descriptionSec);
			if(storiesSection != null) 
				storiesSection = storiesSection.replaceAll("</span>\\s*</span>\\s*</span>", " Story</span>");
//			U.writeMyText(storiesSection);
			String dtype = U.getdCommType(html + comData + storiesSection);

			// ====Property Status=========
			
			html = html.replaceAll("financing available through USDA|content=\"Forest Creek New Homes Coming Soon Coming Soon", "");
			comData = comData.replace("BUILDER CLOSE-OUT", "");

//			 U.log(html);
			String pstatus = U.getPropStatus(html + comData);
			
			if(moveInCount > 0){
				if (pstatus.length() < 4) pstatus = "Move In Ready";
				else	pstatus = pstatus + ", Move In Ready";				
			}
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html + comData, "[\\s\\w\\W]{30}New Homes Coming Soon[\\s\\w\\W]{30}", 0));
			// ======= Note============
			
//			if(comUrl.contains("/Kirby-Woods")){
//				if(!proptype.contains("Luxury Home")){
//					if(proptype == ALLOW_BLANK) proptype = "Luxury Homes";
//					else if(proptype != ALLOW_BLANK) proptype += ", Luxury Homes";
//				}
//			}

			if (comUrl.contains("communities-1/Brazos-Country"))minPrice = ALLOW_BLANK;
			add[0] = add[0].replaceAll("\">", "").trim();
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(communityName.replace("-", ""), comUrl, communityType);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;
	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	        connection.setRequestProperty("commonConfig", "%7B%22brand%22%3A%22wix%22%2C%22BSI%22%3A%2265c9492d-6abb-4ac5-b8e2-703455567d4b%7C1%22%7D");
	        connection.setRequestProperty("authorization", "wixcode-pub.c79f055dd120cecdeced2054a6b90689bbcb76f0.eyJpbnN0YW5jZUlkIjoiMGE5M2E3OGYtY2ZjNi00OGUxLTljMWYtNTBjOWUzODE2ODEyIiwiaHRtbFNpdGVJZCI6ImM4OGRhZTAyLWI4MDItNDM2My1iODE3LTkyOWU4ZWViZThjMiIsInVpZCI6bnVsbCwicGVybWlzc2lvbnMiOm51bGwsImlzVGVtcGxhdGUiOmZhbHNlLCJzaWduRGF0ZSI6MTY0NTYxMDgyMjM4MCwiYWlkIjoiZWUyYjU2ZDgtYWY2My00YzkzLWFmOWUtMDI1NzEwYmNiMzg3IiwiYXBwRGVmSWQiOiJDbG91ZFNpdGVFeHRlbnNpb24iLCJpc0FkbWluIjpmYWxzZSwibWV0YVNpdGVJZCI6IjcwZWNmNjZlLWNhOGItNDFkYS04MDViLTUxYTJjOTM4MGJlOSIsImNhY2hlIjpudWxsLCJleHBpcmF0aW9uRGF0ZSI6bnVsbCwicHJlbWl1bUFzc2V0cyI6Ikhhc0VDb21tZXJjZSxTaG93V2l4V2hpbGVMb2FkaW5nLEhhc0RvbWFpbixBZHNGcmVlIiwidGVuYW50IjpudWxsLCJzaXRlT3duZXJJZCI6Ijc3NzhlNmRlLTY1MDctNDRmNS1hY2ZiLTU2MGM0MWY2MTM2ZCIsImluc3RhbmNlVHlwZSI6InB1YiIsInNpdGVNZW1iZXJJZCI6bnVsbH0=");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36");
	        connection.setRequestProperty("Referer", "https://www.kendallhomes.net/_partials/wix-thunderbolt/dist/clientWorker.bf7e6b7e.bundle.min.js");
	        connection.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	
	private static String removeScriptAndStyle(String html){
		String[] vals = U.getValues(html, "<style ", "</style>");
		for(String val : vals) html = html.replace("<style "+val+"</style>", "");
		vals = U.getValues(html, "<script", "</script>");
		for(String val : vals) html = html.replace(val, "");
		
		/*html = html.replaceAll("<style.*>(.*?)</style>", "")
				.replaceAll("<script.*>(.*?)</script>","");*/
		return html;
	}

}