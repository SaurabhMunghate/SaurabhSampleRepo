/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMyClearviewHome extends AbstractScrapper{

	static int j=0;
	static int k=0;
	HashMap<String, String>hm=new HashMap<String,String>();
	CommunityLogger LOGGER;
	public ExtractMyClearviewHome() throws Exception {
		super("My Clearview Home","https://www.myclearviewhome.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("My Clearview Home");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a=new ExtractMyClearviewHome();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+ "My Clearview Home.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}
	//WebDriver driver= null;
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
//		U.setUpGeckoPath();
//		driver  = new FirefoxDriver();
		
		String mainHtml=U.getHTML("https://www.myclearviewhome.com/");
		
		String section=U.getSectionValue(mainHtml, "<span>On Your Lot</span>", "</section>	</div>"); 
//		U.log(section);
//		if(section!=null) {
//		section=section.replace("communitynote white\">Grand Opening</span>", "ccommunitynote white\">Grand Opening!</span>");
		
		section=section.replace("'s", ",000");	//.replace("</div>","<a")
//		String commUrl="https://www.myclearviewhome.com/community?com="+U.getSectionValue(comSec, "com=", "\"");
		
		section=section.replaceAll("</span>\\s*</div>|</div>\\s*</div>", "</div>SECTIONEND");
		//U.log("section: "+section);
		
		String[] comSections =U.getValues(section, "<a class=\"group\"", "</div>SECTIONEND");	
		U.log("comSections.length: "+comSections.length);


		int i=0;
		for(String comSec:comSections)
		{
			//U.log(i++ +" regComSec="+comSec);
			
		//	U.log("***********************");
//			String comUrls=U.getSectionValue(comSec, "com=", "\"");
//			U.log("===cmurl: "+comUrls);

			String cUrl="https://www.myclearviewhome.com"+U.getSectionValue(comSec, "href=\"", "\"");
			U.log("cUrl::::"+cUrl);
			
			
			addDetails(cUrl,comSec);
		}
		//addDetails("https://www.myclearviewhome.com/community?com=FuhrmannWoods", U.getHTML("https://www.myclearviewhome.com/community?com=FuhrmannWoods"));
	
		LOGGER.DisposeLogger();
//		driver.quit();
	}

	private void addDetails(String comUrl, String comSec) throws Exception {
		// TODO Auto-generated method stub
//	if(j == 0)
//		try
	{
//		if(!comUrl.endsWith("https://www.myclearviewhome.com/community?com=ManitouHills"))return;
		
//		if(!comUrl.contains("https://www.myclearviewhome.com/communities/park-ridge-at-stonewood")) return;
		
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=null")||comUrl.contains("https://www.myclearviewhome.com/community?com=FuhrmannWoods"))return;
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=Barabeau"))return; //sold community, link not visible on front
		if(data.communityUrlExists(comUrl))	{
			LOGGER.AddCommunityUrl(comUrl+"<========== Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		U.log(j+"   commUrl-->"+comUrl);
//		U.log("comSec="+comSec);
		//comUrl=comUrl.replace("http:","https:");
		String html=U.getHTML(comUrl);
		
		String custom = U.getSectionValue(html, "<div class=\"wrapper listcolor2\"", "</article>");
		
//============================================Community name=======================================================================
//		String communityName=U.getSectionValue(html, "<h2 class=\"pad_bot1\" style=\"float: left;\">","<");
//		communityName=communityName.replaceAll(", Village of Oxford|0000 |, Troy|, Rochester|, Oxford|, Holly|, Independence Twp.|, Brighton", "");
	
		U.log("comSec: "+comSec);
		
		comSec=comSec.replaceAll("<!--|-->","");
		String communityName=U.getSectionValue(comSec, "<span class=\"comdesc pl-0\">","<");
		
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=FuhrmannWoods"))communityName="Furhrmann Woods";
		if(communityName == null) communityName=U.getSectionValue(comSec, "\"comdescs\">+","<");
		if(communityName == null) communityName=U.getSectionValue(comSec, "duration-100 comdesc pl-0\">","</span>");
		
		
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
	    note = U.getnote(comSec.replace("Pre-construction Pricing Now Available","Pre Construction Pricing"));
		String addSec=U.getSectionValue(html, "href=\"https://www.google.com/maps/dir/","/a>");
		U.log("AddSec =="+addSec);
		if(addSec!=null) {
			addSec=U.getSectionValue(addSec, ">", "<").replace("Rd.", "Rd,");
//			U.log("AddSec =="+addSec);
			add=U.getAddress(addSec);
		}
		if(addSec!=null && add[0].length()<2)
		{
			String addPart= U.getSectionValue(addSec, "!2s","!5e");
			if(addPart!=null){
				addPart=addPart.replace("+"," ").replace("%2C",",");
//				U.log("addPart:::::::"+addPart);
				String[] add1=addPart.split(",");
			
				if(add1.length>2){
					add[0]=add1[0];
					add[1]=add1[1];
					add[3]=Util.match(add1[2],"\\d{4,}");
					if(add[3]!=null) {
						add[2]=add1[2].replace(add[3],"").trim();
					}
					else{
						add[2]=add1[2];
					}
				}
			}
		}
		
		
		if(add[0].length()<3 || add[3].length()<3){
			
			String locationSec = U.getSectionValue(html, "Community Location", "Communities");
			
			String addIFRAMEUrl =U.getSectionValue(locationSec, "<iframe src=\"", "\"");
			U.log("addIFRAMEUrl::::::::::::"+addIFRAMEUrl);
			
			if(addIFRAMEUrl != null){
				String addIFrameHtml=U.getHTML(addIFRAMEUrl);
				U.log(U.getCache(addIFRAMEUrl));
				
				String newAddSec=U.getSectionValue(addIFrameHtml, "null,null,null,null,null,null,null,null,null,\"", "\"");
				U.log("newAddSec:::::::::::"+newAddSec);
				
				
//				if(newAddSec!=null && newAddSec.contains("Independence Charter Township, MI 48346"))
//				{
//					newAddSec=newAddSec.replace("Independence Charter Township, MI 48346", "Maple Ridge Ct, Independence Charter Township, MI 48346");
//				}
				U.log("newAddSec here:::::::::::"+newAddSec);
				if(newAddSec!=null &&newAddSec.contains("CNftooiGyI3ISBICcGwd17YIYSW7FMFY")){
					newAddSec=U.getSectionValue(addIFrameHtml, "],[\"\",\"", "\"");
				}
				if(newAddSec!=null){
					String[] tempAdd=newAddSec.split(",");
					if(tempAdd.length==3){
						add[0]=tempAdd[0];
						add[1]=tempAdd[1];
						add[2]=Util.match(tempAdd[2], "\\w+");
						add[3]=Util.match(tempAdd[2], "\\d+");
					}
				}
				else {
					String lat = U.getSectionValue(addIFRAMEUrl, "3d", "!");
					String lng = U.getSectionValue(addIFRAMEUrl, "!2d", "!");
					latlag =new String[] {lat,lng};
					add = U.getAddressGoogleApi(latlag);
					geo = "True";
				}
			}else{
				String comAdd = U.getSectionValue(html, "communityAddress", "\";");
				U.log(comAdd);
				if(comAdd != null){
					comAdd = comAdd.replaceAll("\"", "").replace("St. Oxford", "St., Oxford");
					add = U.getAddress(comAdd);
				}
			}
		}
		
//		if(comUrl.contains("https://www.myclearviewhome.com/community?com=Bridlewood")) {
//			addSec=U.getSectionValue(html,"<div class=\"place-desc-large\">","</div> </div>");
//			U.log("ADDRESS "+addSec);
//			add[0]=U.getSectionValue(addSec, "jsan=\"7.place-name\">","</div>");
//			add[1]=U.getSectionValue(addSec, "san=\"7.address\">",",");
//			String add2[]=U.getSectionValue(addSec,",","</div>").split("\\s");
//			add[2]=add2[0];
//			add[3]=add2[1];
//			latlag=U.getlatlongGoogleApi(add);
//			geo="TRUE";
//			
//			
//		}
			if(comUrl.contains("https://www.myclearviewhome.com/community?com=Bridlewood")) {
				add[0]="Parker Lane";
				add[1]="Brandon Twp";
				add[2]="MI";
				add[3]="48462";
//				latlag=U.getlatlongGoogleApi(add);
//				geo="TRUE";
			}

		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
						
	//--------------------------------------------------latlng----------------------------------------------------------------
		U.log("addSec===>"+addSec);
		if(addSec!=null)
		{	
			if(!addSec.contains("/maps/embed"))
				addSec=U.getSectionValue(html, "https://www.google.com/maps/embed?pb=","\"");
			String latSec=U.getSectionValue(addSec, "!2d","!2m");
			if(latSec==null)
			{
				latSec=U.getSectionValue(addSec, "!2d","!3m");
			}
			String[] lat1=latSec.split("!3d");
			latlag[0]=lat1[1];
			latlag[1]=lat1[0];
		}
		else
		{
			U.log("IIIIIIIIIIIIIIIIII");
			addSec=U.getSectionValue(html, "\"https://www.google.com/maps/embed?pb","\"");
			//U.log(addSec);
			if(addSec!=null)
			{
//				String lat1=U.getSectionValue(addSec, "sll=","&amp");
//				latlag=lat1.split(",");
				latlag[0]=U.getSectionValue(addSec, "!3d","!");
				latlag[1]=U.getSectionValue(addSec, "!2d","!");
				
			}
		}
		if(latlag[0] == ALLOW_BLANK){
			String latLngSec = U.getSectionValue(html, "initMap()", "});");
			if(latLngSec != null){
				latlag[0] = U.getSectionValue(latLngSec, "lat:", ",").trim();
				latlag[1] = U.getSectionValue(latLngSec, "lng:", "}").trim();
			}
			
		}
//		if(latlag[0].length()==4) {
//			if(comUrl.contains("https://www.myclearviewhome.com/community?com=null")) {
//				latlag[0]="42.802597";
//				latlag[1]="-83.261987";
//			}
//			String latLongSec=U.getSectionValue(html, "var communities = [", "];");
//		
//			String[] arr=U.getValues(latLongSec, "{", "}}");
//			String valSec=ALLOW_BLANK;
//			String[] latlngurls= {};
//			for(String ar:arr)	{
//				//U.log(ar);	
//				latlngurls=ar.split(",");
//				String keySec=latlngurls[1];
//				U.log(keySec);
//				valSec=ar;
//				U.log(valSec);
//				
//				hm.put(keySec, valSec);
//			}
//		}
//		U.log("cmurl:"+cmurl);
//		if (hm.containsKey(cmurl)) {
//			String latLonSec = ALLOW_BLANK;
//			latLonSec = hm.get(cmurl);
//
//			U.log("--" + latLonSec);
//			latlag[0] = Util.match(latLonSec, "\\d{2}\\.\\d{5,}");
//			latlag[1] = Util.match(latLonSec, "-\\d{2,3}\\.\\d+");
//			//U.log(latlng[0] + " " + latlng[1]);
//		}
		
//		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK){
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null || add[3]==ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		}
/*		if(add[1]==ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			add[0]="811 East South Boulevard";
			add[1]="Rochester Hills";
			add[2]="MI";
			add[3]="48307";
			latlag=U.getlatlongGoogleApi(add);
			note="Address Taken From Contact";
			geo="TRUE";
			
		}*/
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=OrchardsOfCommerce")) latlag = "42.5954051,-83.5820618".split(",");
;		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
						
//============================================Price and SQ.FT======================================================================
		
		U.log("floorPlan==="+comUrl.replace("community","floorplans"));
		
		String floorHtml = "";
		String floorplanData = "";
		String floorurl=comUrl.replace("community","floorplans");

		//if(U.removeComments(html).contains("Home Designs</a>"))
			floorHtml =U.getHTML(floorurl);
	U.log("floorurl: "+floorurl);
	String[] planData=U.getValues(floorHtml, " <div class=\"cbp-plan-info pb-0 px-0\"> <!--cbp-l-grid-work-title -->", "</a>");
	if(planData.length>0) {
		for(String plan_data : planData) {
			floorplanData+=plan_data;
		}
	}
			
/*			String remove = U.getSectionValue(floorHtml, "<div class=\"wrapper hide\">", "</section>");
			if(remove != null) floorHtml = floorHtml.replace(remove, "");
*/			//floorHtml = "";
		String qurl=comUrl.replace("community","qo");
	//U.log(qurl);
		String qOH=U.getHTML(comUrl.replace("community","qo"));
		
		
		//=========== PRICES AND SQFT SECTION =======================
		
		String priceSqftSec = ALLOW_BLANK;
		String homeDesignUrl = comUrl + "/home-designs";
		U.log("homeDesignUrl: "+homeDesignUrl);
		
		String priceSqftData = U.getHTML(homeDesignUrl);
		
//		U.log(">>>>>>>>>>> "+Util.matchAll(priceSqftData, "[\\w\\s\\W]{60}\\$[\\w\\s\\W]{60}", 0));
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0's|0s|0k","0,000").replace("$1 million","$1,000,000").replaceAll("<span class=\"floorplanlisting\">\\$\\d{3},\\d{3}</span>", "");
		comSec=comSec.replace("'s", ",000").replaceAll("<span class=\"floorplanlisting\">\\$\\d{3},\\d{3}</span>", "");		//.replace("From the $374,000", "")
	//	if(floorHtml.contains("<div class=\"wrapper hide\">"))floorHtml=U.removeSectionValue(floorHtml, "<div class=\"wrapper hide\">", "<div class=\"our-locations-header");
	//	if(floorHtml.contains("<div class=\"wrapper hide\">"))floorHtml=U.removeSectionValue(floorHtml, "<div class=\"wrapper hide\">", "<div class=\"wrapper listcolor2\">");
		
		//		U.log(">>>>> floor : "+floorHtml);
//		floorHtml=floorHtml.replaceAll("<span class=\"floorplanlisting\">\\$\\d{3},\\d{3}\\s*</span>", "");
		
//		U.log("comSec:::::::::"+comSec);
		String prices[] = U.getPrices(comSec+html+floorplanData+qOH+priceSqftData, "text-xl\">\\$\\d{3},\\d{3}</div>|From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d+|<span class=\"plan-info-large\">\\$\\d{3},\\d{3}</span>", 0);
//		String prices[] = U.getPrices(comSec+html+,"\\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}", 0);

		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//		U.log(Util.matchAll(qOH, "[\\w\\s\\W]{10}\\$249[\\w\\s\\W]{10}", 0));

						
//======================================================Sq.ft===========================================================================================		
	
//		U.writeMyText(floorHtml);
	//	U.log(Util.matchAll(html+floorHtml, "[\\w\\s\\W]{10}2205[\\w\\s\\W]{10}", 0));
		String[] sqft = U.getSqareFeet(html+floorHtml+priceSqftData, ">\\d{4}</span>\\s+Sq. Ft.|\\d{4}Sq. Ft.|\\d{4}</span>\\s*Sq. Ft.|>\\d{4}</span>\\s+Sq. Ft.",0); //|\"floorplanlisting\">\\d{4}
		
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		html=html.replace("delegated", "");
		
		
		String communityType=U.getCommType(html+comSec);
		
//======================= Home Design ==============================
		String comDesign = U.getSectionValue(html, "Community</a>", "\" class=");
		//U.log(comDesign);
		String comDesignHtml = null;
		if(comDesign != null){
			comDesign=U.getSectionValue(comDesign, "\"", "\"");
			//U.log("comDesign : "+comDesign.replace("<a href=\".", "").trim());
//			U.log("comDesign : "+comDesign.replace("<a href=\"", "").trim());//.replaceAll("%20","").trim());
//			comDesign=comDesign.replace("<a href=\"", "").trim();
			comDesignHtml = U.getHTML("https://www.myclearviewhome.com"+comDesign);//.replace("<a href=\".", "").replace("%20","").trim());
		}
		
//==========================================================Property Type================================================
		
		if(comUrl.contains("-estates")) html = html + ", Estate Style";
		if(comUrl.contains("/communities/manors-of-westlake")) html = html + ", Manor Style Homes";
		
		qOH = qOH.replace("(Custom)<br>", "custom homes<br>").replace("Custom with Finished Basement", "exceptional custom home");
		String proptype=U.getPropType((html+floorHtml+qOH).replace("flex space-", ""));
		
		
		U.log("proptype: "+proptype);
		
//			U.log(Util.matchAll(html, "[\\w\\s\\W]{10}manor[\\w\\s\\W]{10}", 0));
//			U.log(Util.matchAll(floorHtml, "[\\w\\s\\W]{10}manor[\\w\\s\\W]{10}", 0));
//			U.log(Util.matchAll(qOH, "[\\w\\s\\W]{10}manor[\\w\\s\\W]{10}", 0));
			

//==================================================D-Property Type======================================================
		html=html.replace("Stories <span class=\"value\">", "Story ");
		//U.log(floorHtml);
		if(floorHtml != null) {
			floorHtml=floorHtml.replaceAll(">Colonial</div>", "The Colonial").replace("1st Floor Master", "1 Story").replace("Ranch"," ranch ");
		}
		
		
		String dtype=U.getdCommType(html+floorHtml+comDesignHtml+qOH);
		
//==============================================Property Status=========================================================
		html=U.removeComments(html);
		comSec = comSec.replace("Wooded, &amp; Walkout Lots Remaining", "Wooded & Walkout Lots Remaining").replace("&amp;", "&");
		comSec = comSec.replace(", & ", " & ");
		String pstatus=U.getPropStatus(html+comSec+floorHtml+qOH);
//		U.log(movHtm.contains(communityName.trim()));
//		if(movHtm.contains(communityName.trim()) || html.contains("class=\"buttontextwide list-group-item list-group-item-action\">Quick Occupancy</a>")){
//			if(pstatus.length()<3){
//				pstatus="Quick Occupancy Homes";
//			}else{
//				pstatus=pstatus+", Quick Occupancy Homes";
//			}
//		}
		
		
//		if(qOH.contains(communityName)) {
//			if(pstatus.length()<3){
//				pstatus="Quick Occupancy Homes";
//			}else{
//				pstatus=pstatus+", Quick Occupancy Homes";
//			}
//		}else {
//			pstatus= pstatus.replace(", Quick Occupancy Homes|Quick Occupancy Homes,|Quick Occupancy Homes", "");
//		}
		
		
		pstatus = pstatus.replaceAll("Quick Delivery Homes, Quick Occupancy Homes|Immediate Occupancy, Quick Occupancy Homes", "Quick Occupancy Homes");
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=OAKRIDGE"))pstatus = pstatus + ", 1 Immediate Occupancy Home Remain";
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=Copperleaf")) {
			maxSqft ="3494";
		}

		//============================================note====================================================================
	
		add[2]=add[2].replace(".","");
		add[0] = add[0].replace("= ", "");
		if(add[1].contains("Charter Twp of Clinton")) add[1] = "Clinton Twp";
		if(note.length()<3)note = ALLOW_BLANK;
		if(comUrl.contains("Estates"))proptype="Estate Style Homes";
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=FuhrmannWoods"))pstatus="Sold Out";
		U.log("street ::"+add[0]);
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=ManorsOfWestlake"))proptype="Manor Homes";
//		if(comUrl.contains("community?com=WaldonMeadows"))pstatus+=", Quick Occupancy Homes";
//		if(comUrl.contains("community?com=BridgeValley"))pstatus="Quick Occupancy Homes";
		if(comUrl.contains("https://www.myclearviewhome.com/community?com=ManitouHills"))geo="False";
			data.addCommunity(communityName.replace("Furhrmann", "Fuhrmann"),comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note); 
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	} 
//		catch(Exception e) {}
	j++;
	}

}