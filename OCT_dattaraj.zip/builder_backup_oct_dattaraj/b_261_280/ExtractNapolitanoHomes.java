/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.IOException;
import java.util.ArrayList;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNapolitanoHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractNapolitanoHomes() throws Exception {
		super("Napolitano Homes","https://www.napolitanohomes.com");
		LOGGER = new CommunityLogger("Napolitano Homes");	
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractNapolitanoHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Napolitano Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
/*		String mainHtml=U.getHTML("https://www.napolitanohomes.com/our-communities");
		String[] comSec=U.getValues(mainHtml, "class=\"featured-details\">","View Details");
		U.log(comSec.length);
		for(String comData:comSec)
		{
			String comUrl="https://www.napolitanohomes.com"+U.getSectionValue(comData, "href=\"","\"");
			addDetails(comUrl,comData);
		}
*/		
		String html = U.getHTML("https://www.napolitanohomes.com/find-your-home");
		html = html.replace("id=\"village-pointe\"></noscript>", "id=\"village-pointe\"></noscript><i class=\"fa fa-info-circle\" aria-hidden=\"true\"></i>");
		String comSectionSec = U.getSectionValue(html, "<span class=\"fyh-city-inner\">All Communities</span>", "<div class=\"google-map-display-wrap\">"); //" class=\"individual-community-item\">");
		
		String comSection[] = U.getValues(comSectionSec, "<div class=\"individual-community-item-heading\">", " <img alt=\"View on Map\" ");
		
		U.log(comSection.length);
		
		for(String comSec : comSection){
		//	U.log(comSec);
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
			U.log(comUrl);
//			try {
				addDetails(comUrl,comSec+"<");
//			} catch (Exception e) {}
	//		break;
		}
				
		LOGGER.DisposeLogger();
//		addDetails("http://www.napolitanohomes.com/point-chesapeake", "<h3>POINT CHESAPEAKE IN VIRGINIA BEACH COMING SOON</h3>");
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
		if(!comUrl.contains("https://www.napolitanohomes.com/new-homes/suffolk/community/nansemond-reserve")) return;
//		if(j == 5)	
	{
		
		if(comUrl.contains("https://www.napolitanohomes.com/new-homes//community/vp")){
			LOGGER.AddCommunityUrl(comUrl+"-----------------> Page Not Found");
			k++;
			return;
		}
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"-----------------> Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
//		U.log(comData);
		U.log(j+"   commUrl-->"+comUrl);
		U.log("commUrl-->"+comUrl);
				String html=U.getHTML(comUrl);
				
				String bottomHeader = U.getSectionValue(html, "<div class=\"bottom-header-right\">", " <script type=\"text/javascript\">");
				if(bottomHeader!=null)
					html = html.replace(bottomHeader, "");
				
				
		//============================================Community name=======================================================================
				String communityName=U.getSectionValue(comData, "<h5>","<");
				communityName=U.getCapitalise(communityName.toLowerCase());
				communityName=communityName
						.replace(": A 55+ Active Adult Community", "")
						.replaceAll(" By Napolitano Homes|One Remaining Opportunity|Is Sold Out| In Virginia Beach", "")
						.replace("&#8217;", "'");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				
				String note=ALLOW_BLANK;
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latLng={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
			
				String addSec=U.getSectionValue(html, "Sales Office: </strong>","</tr>");
				U.log("addSec:======= "+addSec);
				
				if(addSec==null) {
					addSec=U.getSectionValue(html, "Location:</strong></td>","</tr>");
					U.log("addSec here ======= "+addSec);
					
				}
				if(addSec==null) {
					addSec=U.getSectionValue(html, "var infocontent =","\";");
					if(addSec!=null) {
						String temp=communityName.replace("Nansemond Reserve At Sleepy Hole", "Nansemond Reserve");
						addSec=addSec.replaceAll(temp, "-").replace("\"- •", "").replace("•", ", ");
						U.log("addSec here-2 ======= "+addSec);
					}
					
					
				}
				
				if(addSec!=null){
//					U.log("Adress:--"+addSec);
//					addSec = addSec.replace("<br>", ",").replace(" VA,", " VA").replace("NC, 27958", "NC 27958").replaceAll("By Appointment Only|Across from KFV Middle School|Model Home Under Constructio", "");
					if(comUrl.contains("new-homes/suffolk/community/hallstead-reserve-55-active-adult-community"))
					{
						addSec=U.getSectionValue(addSec, "rel=\"noopener\">", "</a>");
					}
					addSec = addSec
//							.replace("Community Entrance:, ", "")
//							.replace(",,,Sales Office:,The Tuscany ,1701 Acadian Dr., Suffolk, VA 23434", "")
							.replaceAll("(Chesapeake Way|Victory Court)</p>", "$1,");
					addSec = addSec.replace("</a></p>", ",").replaceAll("<.*?>", "").replace("&#8217;", "'")
							.replaceAll("The Waterford Model|Under Construction:", "").trim();

					addSec=addSec.replace("Model","");
					addSec = addSec.replace("Open by Appointment Only","").replace("\n", ",").replace(",Model Open by Appointment Only", "").replace(",Opening August 2021!,(All Showings by Appointment Only)", "");
					
					if(addSec.contains("1013 Paragon Way, Suffolk, VA 23435,")) {
						addSec = "1013 Paragon Way, Suffolk, VA 23435";
					}
					
					U.log("addse:::"+addSec);
					add=U.getAddress(addSec);

				}
				
				U.log("Address---->"+add[0]+":>"+add[1]+":>"+add[2]+":>"+add[3]);
				
				U.log("Address=======---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		//--------------------------------------------------latlng----------------------------------------------------------------
				/*String latSec=U.getSectionValue(html, "https://www.google.com/maps/dir","\"");//please cheak latlong present or not in page
				
				if(latSec!=null)
				{
					latLng[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
					latLng[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
				}*/
				latLng[0] = U.getSectionValue(html, "var latitude = \"", "\"");
				latLng[1] = U.getSectionValue(html, "var longitude = \"", "\"");
				if(latLng[0] == null || latLng[1] == null)
					latLng[0] = latLng[1] = ALLOW_BLANK;
				U.log("hhhh--->"+latLng[0]+"  "+latLng[1]);
				
				if(add[1]!=ALLOW_BLANK && latLng[0]==ALLOW_BLANK)
				{
					latLng=U.getlatlongGoogleApi(add);
					
					geo="TRUE";
				}
				
				add[0] = add[0].replaceAll("By Appointment Only|Neighborhood Clubhouse|Model Coming Soon", "");
				if((add[0].length()<4 || add[3]==null) && latLng[0]!=ALLOW_BLANK)
				{
					String add1[] =U.getAddressGoogleApi(latLng);
					if(add1 == null) add1 = U.getAddressHereApi(latLng);
					if(add[0].length() < 2) add = add1;
					if(add[3] == null) add = add1;
					geo="TRUE";
				}
				if(comUrl.contains("https://www.napolitanohomes.com/new-homes/suffolk/community/array")) {
					add[0]="4307 Abercorn Drive";
					add[1]="Suffolk";
					add[2]="VA";
					add[3]="23435";
					latLng=U.getlatlongGoogleApi(add);
					geo="FALSE";
				}
				U.log("hhhh1--->"+latLng[0]+"  "+latLng[1]);
				
		
		//============================================Price and SQ.FT======================================================================
				
				
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

				html=html.replace("$1.196M", "$1,196,000").replace("<p>396,830</p>", "<p>$396,830</p>").replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's","0,000").replace("$1 million","$1,000,000").replace("</strong>   &#36;", " $");
				comData=comData.replaceAll("0&#8217;s|0s|0's","0,000");
				html=html.replace(" $370s ", " $370,000 ");
				html =html.replace("Priced from</span> LOW 300", "Priced from</span> $300").replace("</span> MID 300,000</li>", "</span> $300,000</li>");
				html=html.replace("0s","0,000").replace("lower $300,000.", "").replace("Low 300,000", "Low $300,000")
						.replaceAll("<div class=\"modelbox-top-right\">\n\\s*", "<div class=\"modelbox-top-right\">\n\\$");
				comData=comData.replace("9k","9,000");
				U.log(U.getSectionValue(html, "<h2 style=\"text-align: center;\"><a", "5pm</li>"));
				String prices[] = U.getPrices((comData +html).replaceAll("472,445", ""),
						"\\$\\d,\\d{3},\\d{3}<br>|Low \\$\\d{3},\\d{3} to Low \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}<|<p>\\$\\d{3},\\d{3}</p>|Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|Priced from</span> \\d{3},\\d{3}", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
//				U.log(Util.matchAll(comData +html, "[\\w\\s\\W]{30}\\$300[\\w\\s\\W]{30}", 0));
				
		//======================================================Sq.ft===========================================================================================
				html = html.replaceAll("Sq. Ft. Range: </strong></td>\\s*<td style=\"height: 71px; vertical-align: middle; width: 58.466%;\">2,434 to 3,564", "Sq. Ft. Range: 2,434 to 3,564").replaceAll("<td style=\"height: \\d+px; vertical-align: middle;\">", "<td>")
						.replaceAll("Sq\\. Ft\\. Range: </strong></td>\\s+<td style=\"height: \\d+px; vertical-align: middle; width: \\d+\\.\\d+%;\">", "Sq. Ft. Range: </strong></td>  <td>")
						.replaceAll("Sq\\. Ft\\.: </strong></td>\n\\s+<td>", "Sq. Ft.: ");
				String[] sqft = U
						.getSqareFeet(
								html+comData," \\d,\\d{3} SF</p>| \\d,\\d{3} SF</strong>|<td>\\d,\\d{3}</td>|Sq\\. Ft\\. Range: </strong></td>\\s+<td>\\d,\\d{3} to \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}<br>\\s+<span>SQ\\.FT|Square Feet</strong> \\d+,\\d+ - \\d+,\\d+|Sq. Ft. Range: \\d,\\d{3} to \\d,\\d{3}|Range</span> \\d+,\\d+ to \\d+,\\d+|Square Feet</strong> \\d+,\\d+|\\d,\\d{3} SF",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
				//------------------------------------floor and available homes data---------------//
				String allHomesData = ALLOW_BLANK;
//				ArrayList<String> homesUrls = Util.matchAll(html, "href=\"(.*?)\" dummy=\"\" class=\"btn\" rel=\"\"\\s*style=",1);
				String[] homeUrlSection = U.getValues(html, "<div class=\"modelthmwrap\">", "</div>");
				U.log("Total Homes : "+homeUrlSection.length);
				for(String homeUrl : homeUrlSection){
					homeUrl = U.getSectionValue(homeUrl, "<a href=\"", "\"");
					U.log("homeUrl : "+homeUrl);
					String homeHtml = U.getHTML(homeUrl);
					if(homeHtml != null)
						allHomesData += U.getSectionValue(homeHtml, "<div id=\"content\"", "</table>");
				}
				//U.log(allHomesData);
				allHomesData = allHomesData
						.replaceAll("Stories:</strong></td>\\s+<td style=\"height: \\d+px; vertical-align: middle; width: \\d+\\.\\d+%;\">(\\d+)</td", " $1 Story ");
	//					.replaceAll("Stories:</span>", "Stories");
		//============Quick Move In ================
				String quickHomeSection[] = U.getValues(html, "<div class=\"quickmovein-image\">", "</a>");
				String combinedQuickHtmls = null;
				for(String quickHomeSec : quickHomeSection){
					String quickUrl = U.getSectionValue(quickHomeSec, "<a href=\"", "\"");
					U.log("QuickUrl :"+quickUrl);
					String quickHtml=U.getHTML(quickUrl);
					if(quickHtml==null)
					{
						//page Not Found
						 	continue;
						
					}
					combinedQuickHtmls+= U.getSectionValue(quickHtml, "<section>", "</section>");  
					
				}
		//================================================community type========================================================
				html = html.replaceAll("Three golf courses are within 10 minutes, and the | master-planned neighborhoods.", "");
				//U.log(comData);
				String communityType=U.getCommType((html+comData));	//.replaceAll("Sleepy Hole Golf", "")
				
		//==========================================================Property Type================================================
				html  = html.replace("and luxury","and luxury homes")
						.replace("Luxurious Three-Story Condominiums", "Luxury living Three-Story Condominiums");
				
				if(allHomesData!= null)
					allHomesData = allHomesData.replace("multi-generation floorplan", "multi-generation suite");//<p>Single Family Homes</p>
				
				String proptype=U.getPropType((html+comData+allHomesData).replaceAll("plicable HOA fees|and a patio door|new single-family community", "").replace(" multi-generation floorplan", "Multigenerational neighborhood"));
				
		//==================================================D-Property Type======================================================
				if(combinedQuickHtmls != null) combinedQuickHtmls = combinedQuickHtmls.replaceAll("Stories:</strong></td>\\s+<td style=\"vertical-align: middle;\">(\\d)</td>", " $1 Story ");
				String dtype=U.getdCommType((html+comData+allHomesData+communityName+combinedQuickHtmls).replace("Stories:</strong>\\s*</td>\\s*<td style=\"height: 27px; vertical-align: middle; width: 50.2833%;\">\\s*", "Stories ")
						.replaceAll("graduate of First Colonial High School|level|branch|BRANCH|(f|F)loor|floor",""));
				
				U.log("dtype: "+dtype);
//				U.log(Util.matchAll(html+comData+allHomesData+communityName+combinedQuickHtmls, "[\\w\\s\\W]{30}Colonial[\\w\\s\\W]{30}", 0));
		//==============================================Property Status=========================================================
				String remSec =U.getSectionValue(html, "<span>find your</span>", "</header>");
				if(remSec!=null){
					html=html.replace(remSec, "");
				}
//				U.log(comData);
				
				comData = comData.replace("now selling in its third and final phase", "now selling third and final phase")
						.replaceAll("Coming in early 2019", "Coming early 2019")
						.replaceAll("now selling new homes in Moyock", "");
				html=html.replaceAll("homesites are selling FAST|Quick Delivery Homes</a>|Quick Move-In Homes|QUICK DELIVERY HOMES</a>|alt=\"NEW PHASE NOW SELLING\"|title=\"NEW PHASE NOW SELLING\"","");
				html=html.replace("Quick|quick|QUICK","");
				html=html.replace("\"/coming-soon-communities\">Coming Soon Communities</a>","");
				html=html.replace(" now selling in Phase 2", " now selling Phase 2").replace("now selling in Phase 3", "now selling Phase 3")
						.replace("now selling in the newest phase", "now selling newest phase")
						.replaceAll("Limited availability in the Final Phase", "Limited availability in Final Phase");
				html=html.replaceAll("<td><strong>SOLD OUT!</strong></td>|SOLD OUT!\"|Nansemond Reserve &#8211; SOLD OUT!</a>|SOLD-OUT\\.png|the-cove-is-sold-out|The Cove is SOLD OUT|Only 1 Quick Move-In home remaining|FLOORPLANS ARE SOLD OUT | Avalon SOLD OUT!<br|Madison SOLD OUT|Birmingham SOLD OUT|remaining options|SOLD OUT\\s*</a>|sold-out\">","")
						.replaceAll("SOON!</a>|SOON!\" href", "");
/*						.replace("Coming soon in 2017", "")
						.replaceAll("Coming in early 2019", "Coming early 2019");
*///				U.log(comData);
				String pstatus=U.getPropStatus(html.replaceAll("New Quick Move-In Condominiums|wrapper\">Quick Move-In</a>|\">Coming Summer 2021</td>|side Estates is Sold Out|Coming Spring 2021</td>", "")+comData);
					
				pstatus=pstatus.replace("Coming Soon,","");
				pstatus=pstatus.replace("Quick Delivery Homes,","");
				pstatus=pstatus.replace("Quick Delivery Homes","");
				if(pstatus.length() < 5){
					pstatus=ALLOW_BLANK;
				}
				pstatus = pstatus.trim().replaceAll(",$", "");
				
//				U.log(Util.matchAll(html+comData, "[\\w\\s\\W]{30}sold out[\\w\\s\\W]{30}", 0));
				
				U.log("pstatus: "+pstatus);
	
		//============================================note====================================================================
				
				if(comUrl.contains("https://www.napolitanohomes.com/chesapeake/western-branch-reserve")) {
					pstatus="3 Move-In Ready Homes";
				}
				
//				if(comUrl.contains("https://www.napolitanohomes.com/new-homes/virginia-beach/community/point-chesapeake-on-the-bay"))
//					minPrice = "$1,465,000";
				if(comUrl.contains("https://www.napolitanohomes.com/chesapeake/fieldstone")) pstatus = "Selling Fast";
				if(comUrl.contains("https://www.napolitanohomes.com/suffolk/the-cove-is-sold-out")) pstatus = "Sold Out";
				if(comUrl.contains("https://www.napolitanohomes.com/moyock/countryside-estates-one-remaining-opportunity"))pstatus = pstatus+", One Remaining Opportunity";
//				if(comUrl.contains("https://www.napolitanohomes.com/new-homes/suffolk/community/hallstead-reserve"))pstatus = "Coming Soon";
				//if(comUrl.contains("wentworth-at-currituck-reserve"))maxPrice="$472,445";
				note = U.getnote(html.replaceAll("Presale Pricing|pecial Pre-Sale|Call Our Sales Agent for Pre-Grand Opening", "")+comData);
				
				
//				if(comUrl.contains("https://www.napolitanohomes.com/new-homes/suffolk/community/array-at-bennetts-creek-quarter"))note+=", Now Pre-Selling";
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addUnitCount(ALLOW_BLANK);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
					
	}
	j++;
		
	}

}