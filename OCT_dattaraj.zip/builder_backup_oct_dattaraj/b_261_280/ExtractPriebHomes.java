/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPriebHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private String builderUrl = "https://www.priebhomesinc.com/";
	public ExtractPriebHomes() throws Exception {
		super("Prieb Homes","https://www.priebhomesinc.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Prieb Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractPriebHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Prieb Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	WebDriver driver= null;
	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		
		String mainHtml=U.getHtml("https://www.priebhomesinc.com/communities-2/where-we-build", driver);
//		String[] comSec=U.getValues(mainHtml, "<div class=\"result-media\">","Visit Community");
		String[] comSec=U.getValues(mainHtml, "<div class=\"text-block-13\">","VIEW&nbsp;COMMUNITY");

		U.log("total Community-->"+comSec.length);
		for(String comData:comSec)
		{
			
//			String comUrl="https://www.priebhomesinc.com"+U.getSectionValue(comData, "ng-href=\"","\"");
			String comUrl="https://www.priebhomesinc.com"+U.getSectionValue(comData, "<div class=\"communities-message-dropdown\"><a href=\"","\"");

//			try {
				addDetails(comUrl,comData,mainHtml);
//			} catch (Exception e) {}
			
		}
		
		//driver.quit();
		LOGGER.DisposeLogger();
	}

	//TODO : Extract Communities Details Here
	private void addDetails(String comUrl, String comData,String mainHtml) throws Exception {
//		try{
		{
//		if(!comUrl.contains("https://www.priebhomesinc.com/communities/stonebridge-meadows")) return;
		
		U.log(U.getCache(comUrl));
		U.log(j+"   commUrl-->"+comUrl);
				String html=U.getHtml(comUrl,driver);
				comData="Start "+comData;
				/*String rem=U.getSectionValue(html, "<head>","class=\"dropdown-menu\">");
				html=html.replace(rem,"");*/
		//============================================Community name=======================================================================
				U.log(comData);
//				String communityName=U.getSectionValue(html, "<div class=\"comm-header\"><h1>","</h1>");
				String communityName=U.getSectionValue(comData, "Start ","</div>");

				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				
				String note=ALLOW_BLANK;
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
			
				String addSec=U.getSectionValue(html, "list-unstyled\">","</h4></li></ul>");
				
				U.log(addSec);
				if(addSec!=null)
				{

					add[0]=U.getSectionValue(addSec, "<h3 class=\"ng-binding\">", "</h3>");
					add[1]=U.getSectionValue(addSec, "community.com_city\" style=\"color:#B59C75\" class=\"ng-binding ng-scope\">", "</span>");
					add[2]=U.getSectionValue(addSec, "community.com_state\" style=\"color:#B59C75\" class=\"ng-binding ng-scope\">,", "</span>");
					if(add[2] == null)
						add[2] = U.getSectionValue(addSec, "com_state\" class=\"ng-binding ng-scope\">,", "</span>");
					if(add[2]==null)add[2]=ALLOW_BLANK;
					add[3]=ALLOW_BLANK;
				}
//				
 				if(add[2].contains("Kansas")) add[2] = "KS";
				

				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				add[0] = add[0].replace("Houston", "");
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				
				String latSec=U.getSectionValue(html, "https://maps.google.com/?q","\"");
				
				String iframurl=U.getSectionValue(mainHtml, "class=\"html-embed w-embed w-iframe\"><iframe src=\"", "\"");
				String iframHtml=U.getHTML(iframurl);
				String[] commSec=U.getValues(iframHtml, "var infoWindow = new SnazzyInfoWindow({", "var marker = new google.maps.Marker(markerOptions);");
				for(String comsec : commSec)
				{
					if(comsec.contains(communityName))
					{
						latlag[0]=U.getSectionValue(comsec, "lat:", ",");
						latlag[1]=U.getSectionValue(comsec, "lng:", ",");
					}
				}
				if(latSec!=null)
				{
					latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
					latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
				}
				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}
				if((add[0].length()<2 ||add[2]==null)&& latlag[0]!=ALLOW_BLANK)
				{	U.log(Arrays.toString(add));
					add=U.getAddressGoogleApi(latlag);
					if(add== null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if((add[0]==ALLOW_BLANK || add[2] == ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK)
				{
				
					add=U.getAddressGoogleApi(latlag);
					if(add== null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)	{
					String add1[]=U.getAddressGoogleApi(latlag);
					if(add1== null) add1 = U.getAddressHereApi(latlag);
					add[3]=add1[3];
					geo="TRUE";
				}
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				if(comUrl.contains("woods-at-prairie-haven")) {
					String sec= U.getSectionValue(comData, "<div class=\"text-block-32\">", "</div>");
					String[] a=sec.split(",");
					latlag=U.getlatlongGoogleApi(new String[] {"",a[0],a[1],""});
					add=U.getAddressGoogleApi(latlag);
					geo="TRUE";
				}
				
		//============================================Price and SQ.FT======================================================================
/*				String homeHtml="";
				if(html.contains("result-content\">"))
				{
					String[] homeUrl=U.getValues(html, "result-content\">","View Detail");
					for(String url1:homeUrl)
					{
						url1=U.getSectionValue(url1, "<a class=\"btn\" ng-href=\"","\"");
						U.log("homeUrl :::http://www.priebhomesinc.com"+url1);
						homeHtml=homeHtml+U.getHtml("http://www.priebhomesinc.com"+url1,driver);
					}
				}
*/				//===============Available Home and Plans ==================
				
//				String[] homeSections = U.getValues(html, "<h4 class=\"result-title", "View Detail</a>");
//				U.log("Home count ::"+homeSections.length);
//				for(String homeSec : homeSections){
//					String homeUrl = U.getSectionValue(homeSec, "ng-href=\"/", "\"");
//					U.log("homeUrl : "+builderUrl+homeUrl);
//					if(homeUrl!=null)
//					combinedHomeHtml += U.getHtml(builderUrl+homeUrl, driver);
//					
//					
//				}
				String combinedHomeHtml = ALLOW_BLANK;
				String availHomeHtml=U.getHtml("https://www.priebhomesinc.com/available-homes", driver);
//				String[] homeSections = U.getValues(availHomeHtml, "<div class=\"div-block-141\">", "MLS&nbsp;Listing</a></div>");
				
				String[] homeSections = U.getValues(availHomeHtml, "<div role=\"listitem\"", "MLS&nbsp;Listing</a>");
				String homeData2=null;
				
				for(String homeData: homeSections)
				{
					if(homeData.contains(communityName))
					{
						String homeUrl=U.getSectionValue(homeData, "Ask Us About This Property</a><a href=\"", "\"");
						U.log("HomeUrl>>>>>>"+homeUrl);
						
						if(!homeUrl.contains("#")) { 
						String homeHtml=U.getHTML(homeUrl);
						 homeData2=U.getSectionValue(homeHtml, "<h2>Interested in touring this home?<", "Services availability");
						 if(homeData2==null) {
							 homeData2=U.getSectionValue(homeHtml, "<div class=\"rich-text-block w-richtext\"><p>", "</p><p><br/></p>");
//							 U.log(homeData2);
						 }
						if(homeData2!=null)
						combinedHomeHtml+=homeData+homeData2;
						else {
							 homeData2=U.getSectionValue(homeHtml, "<h1 class=\"indiv-floorplan-heading\">", " class=\"heading-17\">ALL ELEVATIONS");
							 combinedHomeHtml+=homeData+homeData2;
						}
						}else
							combinedHomeHtml+=homeData;
					}
				}
				
				int moveInHomeCount = 0;
				String availableSection = U.getSectionValue(html, "<h3 class=\"detail-header\">Available Homes", "</dir-pagination-controls>");
				if(availableSection != null){
					moveInHomeCount = U.getValues(availableSection, "<h4 class=\"result-title", "View Detail</a>").length;
				}
				
				
				//inventoryHomes=================================
//				String invdata = U.getHTML("https://www.priebhomesinc.com/API/homes.json");
//				String comId = U.getSectionValue(html, "$_GET['com']='", "'");
//				U.log(comId);
//				String plans[]= U.getValues(invdata, "\"inv_community\":"+comId+",", "\"timestamp\":");
//				for(String plan:plans) {
//					combinedHomeHtml+=plan;
//				}
				
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000").replace("Mid $400,000 to $500+","Mid $400,000 to $500,000");
				
				ArrayList<String> pri=Util.matchAll(combinedHomeHtml, "inv_price\":\\d+", 0);
				ArrayList<String> newPri=new ArrayList<String>();
				for(String val1:pri) {
					val1=val1.replace("inv_price\":", "inv_price\":$").replace("$500+", "$500,000");
					newPri.add(val1);
				}
				U.log(Arrays.toString(U.getPrices(newPri+"", "\\$\\d+|Mid \\$\\d+,\\d+ to \\$\\d+,\\d+", 0)));
				
				comData=comData.replaceAll("0&#8217;s|0�s|0's|0s","0,000");
				combinedHomeHtml=combinedHomeHtml.replaceAll("<div class=\"ah-price\">Mid $450s", "<div class=\"ah-price\">Mid $450,000");
//				U.log("kkkkkkkkkk "+Util.matchAll(html, "[\\s\\w\\W]{30}to mid[\\s\\w\\W]{30}", 0));
				String prices[] = U.getPrices(newPri+html+comData+combinedHomeHtml,"\\$\\d{3},\\d{3} to mid \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|"
						+ "Mid \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|<div class=\"ah-price\">\\$\\d{3},\\d{3}|<div class=\"ah-price\">Mid \\$\\d+,\\d+|<div class=\"ah-price\">\\$\\d+,\\d+|Price:</span> \\$\\d+,\\d+|Priced From: Homes starting at \\$\\d+,\\d+|Upper \\$\\d+,\\d+|Mid \\$\\d+,\\d+|Priced From \\$\\d+,\\d+|Price:</span> \\$\\d+,\\d+|From: \\d{3},\\d{3}|High \\$\\d+,\\d+|Low \\$\\d+,\\d+|mid \\d{3},\\d{3}|\\$\\d+", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
				
		//======================================================Sq.ft===========================================================================================		
				String[] sqft = U
						.getSqareFeet(
								html+comData+combinedHomeHtml,
								"text-block-\\d+\">\\d{4} SqFt</div>|text-block-\\d+\">\\d,\\d{3} SqFt</div>|\\d,\\d+ sq.ft.</div></div><div>|\\d+ sq.ft.</div></div><div>|SQFT:</span> \\d,\\d{3}|\\d{4}\\+? square feet| \\d{1},\\d+ sq ft|SQFT:</strong> \\d,\\d{3}|inv_sqft\":\\d{4}",
								0);
				
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//				U.log(">>>>>>>> "+Util.matchAll(combinedHomeHtml, "[\\s\\w\\W]{30}SqFt[\\s\\w\\W]{30}", 0));

		//================================================community type========================================================
	
				html = html.replace("Canyon Lakes offers Walking", "Canyon Lakeside community offers Walking");
				String communityType=U.getCommType(html+comData.replaceAll("alt=\"Arbor Lake Community Sign|Arbor Lake community", ""));
				
//				U.log("kkkkkkkkkk "+Util.matchAll(html+comData, "[\\s\\w\\W]{100}lake community[\\s\\w\\W]{100}", 0));

				
		//==================================================D-Property Type======================================================
				html=html.replace("Stories <span class=\"value\">", "Story ");

				String dtype=U.getdCommType((html+comData+combinedHomeHtml)
						.replace("two-story", "two story")
						.replaceAll("first floor|floor|Floor", ""));
//				U.log("kkkkkkkkkk "+Util.matchAll(html+comData+combinedHomeHtml, "[\\s\\w\\W]{100} two-story[\\s\\w\\W]{100}", 0));

	//==========================================================Property Type================================================
				
//				if(dtype.length()>3)
//				{
//					combinedHomeHtml=combinedHomeHtml+" covered patio ";
//				}
//				U.log(Util.matchAll(html+comData+combinedHomeHtml, "[\\w\\s\\W]{10}custom", 0));
				html=html.replace("estate lot community", "Estate Residences");
				String proptype=U.getPropType((html+comData+combinedHomeHtml).replaceAll("craftsman_elev| Custom-Designed Hood|Craftsman Elev|Traditional Boot Bench|traditional boot", ""));
				
				
		//==============================================Property Status=========================================================
				html = html.replaceAll("Models that will be Opening|quick\">Quick|ready-homes\">Move-In", "");
				html=html.replaceAll("Phase 4 is now open", "Phase 4 now open");
				String pstatus=U.getPropStatus(html+comData);
				
/*				if(combinedHomeHtml.contains("home.mod_id") && !pstatus.contains("Move")){
					U.log(":::::::::::::::");
*/				if(moveInHomeCount > 0 && U.getHTML("https://www.priebhomesinc.com/move-in-ready-homes").toLowerCase().contains(communityName.toLowerCase().trim())){
					if(pstatus.length()<4)
						pstatus = "Move-In Ready Homes";
					else
						pstatus = pstatus+", Move-In Ready Homes";
				}
				
		//============================================note====================================================================
				
//		if(comUrl.contains("https://www.priebhomesinc.com/grayson-place")) {
//			minPrice="$304,950";
//			maxPrice="$306,950";
//		}

				
				
				if(data.communityUrlExists(comUrl))
					{
					LOGGER.AddCommunityUrl(comUrl);
					k++;
					return;
					}
				LOGGER.AddCommunityUrl(comUrl);
				
				add[2]=add[2].replace(",","").trim();
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

					data.addUnitCount(units);
					data.addConstructionInformation(startDt, endDt);	
					data.addCommunity(communityName,comUrl.replace("http:", "https:"), communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note);
		}
					j++;
//		}catch(Exception e){}
	}

}