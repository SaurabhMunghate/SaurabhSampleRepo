/**
 * @author Upendra Singh 
 * @date 27/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRayLeeHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractRayLeeHomes()
			throws Exception {//https://pacificcommunities.com/
		super("RayLee Homes","http://www.rayleehomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("RayLee Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractRayLeeHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"RayLee Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("http://rayleehomes.com/our-communities/");
		String comSec=U.getSectionValue(mainHtml, "Custom Home Communities Albuquerque\"","<li id=\"menu-item-13").replace("<a href=\"http://rayleehomes.com/our-communities/\"><span class=\"grve-item\">Our Communities","");
		
		if(comSec!=null)
			comSec = comSec.replace("<li id=\"menu-item-3581\" class=\"menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-3581\"><a href=\"#\"><span class=\"grve-item\">Our Communities</span></a>", "");
		
		String[] comValues=U.getValues(comSec, "<li id=\"menu-item","</a></li>");
		U.log(comValues.length);
		for(String comData:comValues)
		{
			String comUrl=U.getSectionValue(comData, "<a href=\"","\"");
			U.log(comUrl);
//			U.log("----------- "+comData);
			if(comUrl.contains("http://rayleehomes.com/our-communities/"))continue;
			
			
//			try {
				addDetails(comUrl,comData);
//			} catch (Exception e) {}
		}
		
		addDetails("http://rayleehomes.com/rio-compuesto/", "<li id=\"menu-item-3582\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-3582\"><a href=\"http://rayleehomes.com/rio-compuesto/\"><span class=\"grve-item\">Rio Compuesto</span></a></li>");
		LOGGER.DisposeLogger();		
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("http://rayleehomes.com/volterra/")) return;
		
		if(comUrl.equals("#"))return;

		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+":::::::::: Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
	
		U.log(j+"   commUrl-->"+comUrl);
				String html=U.getHTML(comUrl);
				
				
		if (comUrl.contains("http://rayleehomes.com/the-peaks-at-mariposa/")) {
			String rem = U.getSectionValue(html, "<div class=\"vc_tta-container\"", "<!-- End Content -->");
			if (rem != null)
				html = html.replace(rem, "");
		}
		
		if (comUrl.contains("http://rayleehomes.com/mirador/")) {
			String rem = U.getSectionValue(html, "<p><strong>Signature Collection (50ft Lot)</strong></p>", "<!-- End Content -->");
			if (rem != null)
				html = html.replace(rem, "");
		}
		
		String rem = U.getSectionValue(html, "<h3>Lomas Encantadas II</h3>", "<!-- End Content -->");
		if (rem != null)
			html = html.replace(rem, "");
		
		//============================================Community name=======================================================================
//				U.log(comData);
				String communityName=U.getSectionValue(comData, "grve-item\">","&#8211;");
				if(communityName == null) communityName=U.getSectionValue(comData, "grve-item\">","</span>");
				U.log("community Name---->"+communityName);
				communityName = communityName.replace("<div class=\"mobile-break\"></div>", "");
				if(comUrl.contains("http://rayleehomes.com/la-pradera/"))communityName="La Pradera";
				
		//================================================Address section===================================================================
				
				String note="";
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
			
			
				String addSec=U.getSectionValue(html, "<h5>Our Model Home is Located at:</h5>","</div>");
				if(addSec == null) addSec=U.getSectionValue(html, "<strong>Model Home</strong><br />","</p>");
				
				U.log("addSec: "+addSec);
				if(addSec!=null)
				{
					addSec=addSec.replace("<strong>Lomas Encantadas I</strong><br />", "");
					if(addSec.contains("<p>") && addSec.contains("</p>"))
						addSec=U.getSectionValue(addSec, "<p>","</p>");
					addSec=addSec.replaceAll("<br />|,<br />|,,",",").replace("Rio Rancho","Rio Rancho,").replace("Rio Rancho,,","Rio Rancho,");
					//U.log(addSec);
					String[] add1=addSec.split(",");
					
					if(add1.length>2)
					 {
						 add[0]=add1[0];
						 add[1]=add1[1];
						 add[3]=Util.match(add1[2],"\\d{4,}");
						 if(add[3]!=null)
						 {
						 add[2]=add1[2].replace(add[3],"").trim();
						 }
						 else
						 {
							 add[2]=add1[2];
						 }
					 }
				}else{
					if(html.contains("https://www.google.com/maps/place/")){
						addSec=U.getSectionValue(html, "https://www.google.com/maps/place/", "/").replace("+", " " );
						add=U.getAddress(addSec);
					}
				}
				// if(comUrl.contains("http://rayleehomes.com/the-peaks-at-mariposa/") || comUrl.contains("http://rayleehomes.com/la-pradera/")||comUrl.contains("http://rayleehomes.com/portella-bellisimo/"))//address taken from contact
				// {
				// 	add[0]="4131 Barbara Loop";
				// 	add[1]="Rio Rancho";
				// 	add[2]="NM";
				// 	add[3]="87124";
				// 	note="Address Taken From Contact";
				// }
				
				if(add[0]==ALLOW_BLANK) {
					addSec = U.getSectionValue(html, "<h5>Our Community is Located at:</h5>", "</div>");
					U.log("addSec---: "+addSec);
					if(addSec!=null) {
					addSec = addSec.replace("<p class=\"LC20lb DKV0Md\">", "")
							.replace("90 Camino de Claudio Corrales, NM 87048</p>", "90 Camino de Claudio, Corrales, NM 87048");
					
					U.log("addSec---: "+addSec);
					
					add = U.getAddress(addSec);
					U.log("ADDRESS: "+Arrays.toString(add));
				}
				}
				
				
				if(comUrl.contains("http://rayleehomes.com/rio-compuesto/"))
				{
					//ADDRESS FROM IMAGE.
					add[0]=ALLOW_BLANK;
					add[1]="Corrales";
					add[2]="NM";
					add[3]="87048";
					//note="Address Taken From Image";
				}
				
				if(comUrl.contains("http://rayleehomes.com/volterra/"))
				{
					add[0]="1820-1800 Popejoy St SE";
					add[1]="Albuquerque";
					add[2]="NM";
					add[3]="87123";
					note="Address Taken From Lot Map";
				}
				
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				
				String latSec=U.getSectionValue(html, "https://www.google.com/maps/place","\"");
				
				if(latSec==null)
					latSec=U.getSectionValue(html, "https://www.google.com/maps/dir/","\"");
					
				if(latSec!=null) {
					
					U.log("latSec: "+latSec);
					
					if(comUrl.contains("rayleehomes.com/mirador/")) {
						
						//LATLONGS ARE EXCEDING - SEPT 2022
						String geoSec = U.getSectionValue(latSec, "/", "/@");
						U.log("geoSec: "+geoSec);
						
						String[] geos = geoSec.split(",");
						
						latlag[0] = geos[0];
						latlag[1] =	geos[1];							
					}
					else {
						U.log("latSec here: "+latSec);
						
						latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
						latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
					}
				
				}
				
				U.log("LATLONG hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}
				if((add[0].length()<2 ||add[2]==null)&& latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
				{
					String [] add1=U.getAddressGoogleApi(latlag);
					if(add1 == null) add1 = U.getAddressHereApi(latlag);
					
					add[3]=add1[3];
					add1 = null;
					geo="TRUE";
				}
				
				
				
//				if(comUrl.contains("http://rayleehomes.com/mirador/")) {
//					
//					String[] remSec = U.getValues(html, "<p><strong>Details</strong><br />", "</p>");
//					
//					for(String remove : remSec) {
//						
//						html = html.replace(remove, "");
//					}
//					
//				}
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
			
				
		//--------------remove common section-------------------
				String[] dropMainNav=U.getValues(html, "<nav id=\"grve-main-menu", "</nav>");
				U.log("total drop sec::"+dropMainNav.length);
				for(String dropNav : dropMainNav){
					html=html.replace(dropNav, "");
					U.log("removed main navigation bar");
				}
				html=html.replaceAll(" now available with the Ocotillo Hills|Pitched Coming Soon|Coming Soon – Tuscan| &amp; townhouses", "");
				
				
		//============ Inventary Home ====================================
		String inventoryHtml=U.getHTML("http://rayleehomes.com/inventory-homes/");
		inventoryHtml=inventoryHtml.replace("The Peaks @ Mariposa", "The Peaks At Mariposa")
						.replaceAll("Mirador-\\d+.jpg\"|mirador/\">|grve-item\">Mirador|mirador-lottery|Mirador Lottery|homes in Mirador|homeowners in Mirador|Mirador Website|Mirador \\||Mirador\\.jpg\" ", "");
				
		String[] invSec = U.getValues(inventoryHtml, "<h3 class=\"grve-element grve-align", "<h3 class=\"grve-element grve-align");
		
//		if(comUrl.contains("http://rayleehomes.com/portella-bellisimo"))
//			invSec = U.getValues(inventoryHtml, "Portella Bellisimo</span></h3>", "Portella Bellisimo</span></h3>");
		
		String ivenData = "";
		String[] dataCount = null;
		int sold = 0;
		for(String data : invSec ) {
			
			if(data.contains(U.getCapitalise(communityName.trim().toLowerCase()))) {
				
				 dataCount = U.getValues(data, "<div class=\"wpb_column grve-column-1-4\">", "</ul>");
				
				for(String check : dataCount) {
//					U.log(check);
					if(check.contains("Raylee_SOLDHomeImages"))
						sold++;
				}
				
				String[] ivenUrl = U.getValues(data, "<a href=\"", "\"");
				
				for(String url : ivenUrl){
					U.log("inventory ::"+url);
					if(url.contains("/portal/agent-listings/Active/detail/")){
						U.log("********** redirecting  url **********");
						continue;
					}
					ivenData+=U.getHTML(url)+data;
				}
			}
				
			
		}
		
		//============================================Price and SQ.FT======================================================================
				

				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
//				String pricedata=U.getHTML("http://rayleehomes.com/wp-admin/admin-ajax.php?action=mapdata&map=11");
						
//				String priceSec=U.getSectionValue(pricedata, "locations\":[", "]}]");
//				String price1[]=U.getValues(priceSec, "{\"id\":\"", "},");
//				U.log(">>>>>>>>>"+price1.length);
				
//				for(String priceData : price1)
//				{
//					U.log(">>>>>>>>>%%%%%");
//					if(priceData.contains(comUrl))
//					{
//						comData=comData+priceData;
//					}
//				}
				
				comData=comData.replace("Homes starting in the $370′s", "Homes starting in the $370,000").replace("$320′s", "$320,000").replace("Homes Starting in the 390's", "Homes Starting in the $390's");
				html=html.replaceAll("2,988|410,085", "").replace("0&#8217;s", ",000").replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
				html=html.replace("the $150’s", "the $150,000");
				
				comData=comData.replace("2,988|410,085", "").replaceAll("0&#8217;s|0�s|0's|0s","0,000");
				ivenData=ivenData.replace("410,085", "");
				
				String prices[] = U.getPrices(html+comData,"Homes starting in the \\$\\d{3},\\d{3}|<div class=\"t-title--larger\">\n\\s+\\$\\d{3},\\d{3}|price\">\\$\\d{3},\\d{3}</div>|range from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\\$\\d{1},\\d+,\\d+|\\$\\d+,\\d+", 0);
			
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			//	U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(html+comData+ivenData, "[\\s\\w\\W]{30}410,085[\\s\\w\\W]{30}", 0));
				U.log("Price--->"+minPrice+" "+maxPrice);
	
				
		//======================================================Sq.ft===========================================================================================		

				String[] sqft = U
						.getSqareFeet(
								html+comData+ivenData,
								"\\d,\\d{3} SQFT</p>|<span>\\d,\\d{3} SF</span>|\\d{4} SQFT|\\d,\\d{3} Square Feet",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
//				U.log(Util.matchAll(html, "[\\w\\s\\W]{30}SQFT[\\w\\s\\W]{30}", 0));
				
		//================================================community type========================================================
				html=html.replaceAll("Maravillas|village|Village","");
				String communityType=U.getCommType(html+comData);
				
		//==========================================================Property Type================================================
				String titleSec=U.getSectionValue(html, "<title>", "</title>");
				html=html.replaceAll("Luxury Homebuilder|Custom Home Builders|Rio Rancho Luxury Homes|Luxury Collection Lottery|Luxury Collection homes only|value='Custom Home' >Custom Home</option>", "");
				U.log(titleSec);
				String proptype=U.getPropType((html+comData+titleSec).replaceAll("Custom Home Builders Corrales", ""));
				
//				U.log(">>>>>>>>>>>>>>"+Util.matchAll(html+comData+titleSec, "[\\s\\w\\W]{30}custom home[\\s\\w\\W]{30}", 0));
//				FileUtil.writeAllText("/home/shatam-10/Desktop/data/CUSTOM.txt", html+comData+titleSec);

		//==================================================D-Property Type======================================================
				html=html.replace("Stories <span class=\"value\">", "Story ").replaceAll("\\d{4} two story|2 Stories | 3 or 4 Bed|two story \\d{4}", "");
				String dtype=U.getdCommType((html+comData).replaceAll("Rancho", ""));
				
//				U.log(">>>>>>>>>>>>>>"+Util.matchAll(html+comData, "[\\s\\w\\W]{30}stories[\\s\\w\\W]{30}", 0));

		//==============================================Property Status=========================================================
				html=html.replaceAll("Home Closeout|Coming Soon|The Lottery is Now Open|Information Coming Spring","")
						.replace("70ft lots coming late 2019/early 2020", "");
				comData=comData.replaceAll("Home Closeout","");
				String pstatus=U.getPropStatus(html+comData);
				
//				U.log(">>>>>>>>>>>>>>"+Util.matchAll(html+comData, "[\\s\\w\\W]{30}Inventory Homes Available[\\s\\w\\W]{30}", 0));

				
				String checkString = U.getSectionValue(inventoryHtml, "<div id=\"page-902\"", "<footer id=\"grve-footer\" ");
//				U.log(checkString);
//				if(checkString != null && checkString.toLowerCase().contains(communityName.trim().toLowerCase()) && dataCount.length>sold) {
//					if(pstatus.length()<4)
//						pstatus="Inventory Homes Available";
//					else
//						pstatus=pstatus+", Inventory Homes Available";
//				}
				
		//============================================note====================================================================
				pstatus=pstatus.replace("Only 3 Lots Left, 3 Lots Left, Inventory Homes", "Only 3 Lots Left, Inventory Homes");
				
				//from images
				if(comUrl.contains("http://rayleehomes.com/mirador/")){
					pstatus = "Coming 2022";
					minPrice = "$700,000";
				}
				
				if(comUrl.contains("http://rayleehomes.com/primo-pequenos/")){
					if(pstatus==ALLOW_BLANK)
						pstatus = "Coming 2022";
					else
						pstatus += ", Coming 2022";
					
					minPrice="$800,000";
				}
				
				//if(comUrl.contains("/mirador/"))pstatus="Estate Lots Coming Soon";
				
				//if(comUrl.contains("http://rayleehomes.com/portella-bellisimo")) minPrice="$374,990";
//					
//					minSqft="2114";
//					maxSqft="2917";
//				}

				//if(comUrl.contains("http://rayleehomes.com/volterra"))minPrice="$362,490";
				if(note.length()<3) note =  ALLOW_BLANK;
				
				add[2]=add[2].replace(",","").trim();
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
					String counting=ALLOW_BLANK;
					String startDt=ALLOW_BLANK;
					String endDt=ALLOW_BLANK;
				
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note);
					data.addUnitCount(counting);
					data.addConstructionInformation(startDt, endDt);
					j++;
	}

}