/* @Sampada Santosh */
package com.shatam.b_261_280;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.StringEscapeUtils;

//import com.gargoylesoftware.htmlunit.util.StringUtils;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractShugartEnterPrises extends AbstractScrapper {
	
	public int inr = 0;
	static int j = 0;
	static int k=0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://buyshugart.com/communities/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractShugartEnterPrises();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Shugart Enterprises.csv", a.data().printAll());

		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	public ExtractShugartEnterPrises() throws Exception {
		super("Shugart Enterprises", "https://www.buyshugart.com");
		LOGGER = new CommunityLogger("Shugart Enterprises");	
	}

	public void innerProcess() throws Exception {
	
		String baseUrl=U.getHTML("https://buyshugart.com/communities/");
		//String sec=U.getSectionValue(baseUrl,"All Communities</a></li><li","About Shugart</a></li><li");
		String vals[]=U.getValues(baseUrl, ",\"title\":", "\"}");
		U.log(vals.length);
		    for(String val:vals){
		    	//if(!val.contains("Arcadia Ridge"))continue;
		    	val = StringEscapeUtils.unescapeJava(val);
		    	//U.log(val);
		    	String valSec= U.getSectionValue(val,"linkd\":\"","\"");	
		    	if(!valSec.contains("http"))valSec = "https://buyshugart.com"+valSec;
		    	String name=U.getSectionValue(val,"\"","\",");
		    	if(name.contains("Arcadia Ridge"))valSec = "https://buyshugart.com/communities/arcadia-ridge/";
		    	//U.log(name+valSec);
		    	addDetails(valSec,name);
		    	
		    }
		    LOGGER.DisposeLogger();
	}
	
	public void addDetails(String url,String communityName) throws Exception {
	//if(j == 6)
	{
//		if(!url.contains("https://buyshugart.com/communities/sedge-hollow/"))return;
		if(!url.contains("communities"))return;
		if(url.contains("glen-haven"))url=url.replace("glen-haven", "glenhaven");
		String html = U.getHTML(url);

		if(url.contains("planters-walk")||url.contains("/river-gate/"))return; //404error
		
		communityName = communityName.replaceAll(" - Now Selling| - 2 New Phases| - New Phase| - Only 1 Home Remaining| - Last Phase| - Now Phase| - Coming Soon!", "");
		
//		html=html.replace("FINAL PHASE!!","FINAL PHASE");
//		html=html.replace("TWO NEW PHASES NOW SELLING!!","TWO NEW PHASES NOW SELLING");
//		html=html.replace("BASEMENT HOMESITES AVAILABLE!","BASEMENT HOMESITES AVAILABLE");
		U.log("url::::::::::::::::"+url);
		if(communityName.contains("Stone Mill Village"))communityName = "Stone Mill";
		U.log(communityName);
		if(url.contains("https://buyshugart.com/communities/hideaway-village") || url.contains("communities/big-mill-junction/"))return;//page not found
		//-------------------------latlong--------------------------//
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "\"https://www.google.com/maps/dir/",
				"@");
		if (latLongsec != null) {

			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		
		
		
		
		//---------------------------adresss---------------------//
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;

		String ad = U.getSectionValue(html, "Location</span>", "</div></div><div");
		U.log(ad+"ad::::::");
		if (ad != null) {
			ad = ad.replace("</h4></div><div", "");
			ad = ad.replace("class=\"medium-7 small-12 columns\">", "");
			
			String a[] = ad.split("<br>");
			add[0] = a[0].trim().replaceAll("\\s+", " ");
			a[1]=a[1].replaceAll("\\s+","");
			
			String adr[] = a[1].split(",");
			add[1] = adr[0].trim();
			
			String array[] = adr[1].trim().split("&nbsp;");
		
			U.log("array::" + array.length);
			add[2] = array[0].trim().toUpperCase();
			
			U.log(array.length+"***********************");
			if (add[2].length() > 2) {
				add[2] = USStates.abbr((array[0].trim()));
			}
			U.log(add[2]+"add[2]");
			if(array.length>1)
			{
				add[3]=array[1].trim();
			}
		}
		add[0] = add[0].toLowerCase();
		add[1] = add[1].toLowerCase();
		
		if (add[3].length()<3) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		
			U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
					+ " add[3] " + add[3]);
		
		//============= Quick Home Html ==================
		String [] homeUrlSection = U.getValues(html, "class=\"card-image\">", "</a>");
		String combinedQuickHtmls = ALLOW_BLANK;
		for(String homeUrlSec : homeUrlSection){
			String homeUrl = U.getSectionValue(homeUrlSec, "href=\"", "\"");
			if(homeUrl.contains("property-listing")){
				U.log("QuickUrl::"+homeUrl);
				combinedQuickHtmls += U.getHTML(homeUrl);
			}
		}
		combinedQuickHtmls = combinedQuickHtmls.replace("Elevation Townhome Design\"", "");
	// ---------community type,property type,property status,derived,
			
		// property type---------//
		String commType = U.getCommunityType(html);
		String propType = U.getPropType(html+combinedQuickHtmls);
		String dpType = U.getdCommType(html.replaceAll("Ranch |ranch |Branch","")+communityName+combinedQuickHtmls.replaceAll("Branch", ""));
		
		html=html.replace("with only 12 homesites available","").replaceAll("fa-home\"></i> Quick|name\">Quick|View Quick", "");

		String commStatus = U.getPropStatus(html);

		if(html.contains("https://buyshugart.com/property-listings/") && !commStatus.contains("Quick"))
		{
			if(commStatus.length()<4){
				commStatus = "Quick Move-Ins";
			}
			else{
				commStatus = commStatus + ", Quick Move-Ins";
			}
		}
		
		//Quick move in status
		ArrayList< String > quickcontainer = Util.matchAll(html, "small-up-1 medium-up-2 large-up-4", 0);
		U.log("::::::::::::::::"+quickcontainer.size());
				
		//U.log(html);
		// --prices---//
		html = html.replace("0s ", "0,000");
		String[] price = U.getPrices(html, "\\$\\d+,\\d+ |\\$\\d+,\\d++", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		html=html.replace("SQFT</h6><p>", "SQFT ");
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html, "square footage ranges from \\d{4} up to \\d{4}|\\d,\\d+ to over \\d,\\d+ sq ft|\\d{4}-\\d{4}|\\d+</span> sqft|SQFT \\d{4}", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// ---notes-----//
		U.log("hello-->"+commStatus);
		commStatus=commStatus.replace("Ii", "II");
		if(url.contains("/beeson-oaks/"))commStatus=commStatus+", Phase II Now Selling";
		if(data.communityUrlExists(url))
		{
		LOGGER.AddCommunityUrl(url+"**************************repeat");
		k++;
		return;
		}
		LOGGER.AddCommunityUrl(url);
	//U.log(html);
	
	


	
	
		add[1]=add[1].replace("Winston-Salem","Winston Salem");
		add[1]=add[1].replace("HighPoint","High Point");
		data.addCommunity(communityName.replaceAll("!$", ""), url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus.replace("IIi", "III"));
		data.addNotes(U.getnote(html));
	}
	j++;	
		
	
	}
	
	
}