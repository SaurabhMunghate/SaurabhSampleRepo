package com.shatam.b_261_280;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/*Sampada santosh*/
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSpinellHomes extends AbstractScrapper {

	static String BASE_URL = "http://spinellhomes.com";
	static String Builder_Name = "Spinell Homes";
	WebDriver driver = null;

	CommunityLogger LOGGER;
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractSpinellHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Spinell Homes.csv", a.data().printAll());
	}

	public ExtractSpinellHomes() throws Exception {
		super(Builder_Name, BASE_URL); 
		LOGGER=new CommunityLogger(Builder_Name);
	}

	@Override
	protected void innerProcess() throws Exception {
		
	//	U.setUpChromePath();
		
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
//		
//		ChromeOptions options = new ChromeOptions ();
//		options.addExtensions (new File("/home/shatam/CRX/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
//		DesiredCapabilities capabilities = new DesiredCapabilities ();
//		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//
//		driver = new ChromeDriver(capabilities);
	//	driver=new ChromeDriver();

	//	Thread.sleep(6000);
		
		
		//String mainHtml = U.getHTMLwithProxy("http://spinellhomes.com/find-a-home/");
	
		String mainHtml = U.getHtml("http://spinellhomes.com/find-a-home/",driver);
		//U.bypassCertificate();
//		String commSec = U.getSectionValue(mainHtml, "All Spinell Communities",	"</ul></div>"); //"<div id=\"defaultSearchLoadingInfo\" style=\"display:none;\">");
	//	String mainHtml=U.getPageSource("http://spinellhomes.com/find-a-home/");																		  ///<ul  class="footerLinks footerLinksMobile footerMenuBackgroundColor setActiveNav">	
	//	U.log(commSec);
		String[] commarr = U.getValues(mainHtml, "<div id=\"card_body_comm", "View Details</span>");
		U.log(commarr.length);
		for (String arr : commarr) {
			String comUrl = U.getSectionValue(arr, "<a href=\"", "\"");
//			try {
				addDetails(comUrl,arr);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
		//driver.quit();
	}
	
	private void addDetails1(String comUrl,String arr) throws Exception {
		
		String commUrl = BASE_URL + comUrl;
		String html = getHtml(commUrl,driver); 
		
		U.log(U.getCache(commUrl));
	}
	
	int j =0;
	//TODO : Extract Communities Details Here
	private void addDetails(String comUrl,String arr) throws Exception {
//		try{
		
		{
		// ----------------COMMUNITY URL---------------//
		
		
		String commUrl = BASE_URL + comUrl;
		
      
//		U.log(arr);
		//===================Single Community======================
		
//		if (!commUrl.contains("http://spinellhomes.com/community-details/Owls-Nest-150017")) return;
		
		
		
		U.log("Count==="+j);
		U.log("commUrl==="+commUrl);
//		U.log(arr);
		
		commUrl = commUrl.replace(	"\" class=\"communityNameInfo communityUrlInfo", "");

		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"-----------> Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
//		String html = U.getHtml(commUrl,driver);
		String html = getHtml(commUrl,driver); 
		
//		String html = U.getPageSource(commUrl);
		U.log(U.getCache(commUrl));

		// ---------------COMMUNITY NAME----------------//

		String commSect = U.getSectionValue(arr, "/find-a-home/", "</h3>");
		
		String commName = U.getSectionValue(html, "<title>", "</title>");
		if(commName.endsWith("Townhomes"))commName = commName.replace("Townhomes", "");
		commName=commName.trim();
		U.log("---------------COMMUNITY NAME=" + commName);

		// ---ADRESS AND LATLONG---------------//

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		String geo = "False";
		String ad = U.getSectionValue(html,"class=\"gaBDXClickTracking bdxApiLogEventInformation \">","  </a>");
       
		U.log("ad:::" + ad + "???");
	/*	if (ad != null) {
	
			add[0] = U.getSectionValue(ad, "addressStreet\">", "</span>");
			add[1] = U.getSectionValue(ad, "addressCity\">", "</span>");
			add[2] = U.getSectionValue(ad, "addressState\">", "</span>");
			add[3] = U.getSectionValue(ad, "addressZipCode\">", "</span>");
			add[1] = add[1].replaceAll(",", "");
		}
		else
		{
			 ad = U.getSectionValue(arr,"<div><div class=\"card_address card_text\">","</div></div></div>");
			 ad=U.getNoHtml(ad).replace("AK", "AK, ");
			 String[] add1= ad.split(",");
			 add[0]=ALLOW_BLANK;
			 add[1]=add1[0].trim();
			 add[2]=add1[1].trim();
			 add[3]=add1[2].trim();
			 
			
		}*/
    	String address[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addSec = U.getSectionValue(html, "<span class=\"address-text\"","</a>");
		U.log("addSec ======= "+addSec);
		
		if(addSec.contains("$")) addSec = ALLOW_BLANK;
		
		if(addSec != null) {
			
			addSec = addSec.replaceAll("</span>\\s+<span class=\"address-text city-state-info\">", ", ");
			U.log("addSec here: "+addSec);
			
			addSec = addSec.replace(">Lois Drive", "Lois Drive")
					.replace(">Grey Owl Way,", "Grey Owl Way");
			
			U.log("addSec: "+addSec);
		}
		
		
		
		
//		String addSec1[]=addSec.split(",");
//		address[1]=addSec1[0];
//		String addSec2[]=addSec1[1].split(" ");
//		address[2]=addSec2[0];
//		address[3]=addSec2[1];
		
		add = U.getAddress(addSec);
		
		U.log("Add::: "+Arrays.toString(add));
		
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
//		String latSec=U.getSectionValue(html, "<script>function initMapmap()", "</script>");
////String latSec=U.getSectionValue(html, "var myLatLng = {", ";");
//		
//latLong[0] =U.getSectionValue(latSec, "lat:", ",");
//latLong[1] =U.getSectionValue(latSec, "lng:", "}");

	//date 24 feb	
		String mapData=U.getPageSource("https://www.spinellhomes.com/_dm/s/rt/actions/sites/b0b498ce/collections/Search%20Comms/ENGLISH");
		//String[] latLngData=U.getValues(mapData, "\\\"uuid\\\"", "\"IsManufactured\\\"");
		//String[] latLngData=U.getValues(mapData, "\\\"data\\\":", "\"Brand\\\":");
		String[] latLngData=U.getValues(mapData, "\\\"data\\\":", "\"page_item_url\\\":");
		U.log("https://www.spinellhomes.com/_dm/s/rt/actions/sites/b0b498ce/collections/Search%20Comms/ENGLISH");
		U.log("Latlng::length: "+latLngData.length);
		for(String data : latLngData) {
			
			//String nameSec=U.getSectionValue(data, "NumModelsHomes", "}]");
//			String nameSec=U.getSectionValue(data,"\"Name\\\":",",");
//			if(nameSec==null)nameSec=U.getSectionValue(data, "\"IsBoyl\\\":", "\"Desc\\\"");
//			U.log(">>>>>>>>"+nameSec);
		//	U.log("Data"+data);
			//if(nameSec.contains(commName))
			if(data.contains(commName))
			{
//				U.log(">>>>>>>>"+data);
			//	latLong[0] =U.getSectionValue(data, "\\\"Lat\\\":\\\"", "\\\"");
				latLong[0] =U.getSectionValue(data,"\"Lat\\\":\\\"","\\\",");
			//	latLong[1] =U.getSectionValue(data, "Lng\\\":\\\"", "\\\"");
				latLong[1] =U.getSectionValue(data,"\\\"Lng\\\":\\\"","\\\",");
				
			}
		}
//		latLong[0] = Util.match(html, "Latitude:</span>\\s*(\\d+.\\d+)</span>",1).toString();
//		latLong[1] = Util.match(html, "Longitude:</span>\\s*(-\\d+.\\d+)</span>",1).toString();
		U.log("Latlng::: "+Arrays.toString(latLong));
		
		
		
	/*	///date feb 24
		
		String MylatlngSec=U.getSectionValue(html, "<script>function initMapmap() {", "</script>");
		
		String latLngSec=U.getSectionValue(MylatlngSec, "var myLatLng = ", ";");
		latLong[0]=U.getSectionValue(latLngSec, "{lat: ", ",").trim();
		latLong[1]=U.getSectionValue(latLngSec,"lng:", "}").trim();
		if(add[0]==ALLOW_BLANK) {
			// add=U.getAddressGoogleApi(latLong);
			add=U.getAddressFromLines(address);
				//if(add == null)add[0] = U.getAddressHereApi(latLong)[0];
				geo="TRUE";
		}
*/
		if(commUrl.contains("https://spinellhomes.com/find-a-home/owls-nest/")){
			add[0] ="2 N Eagle River Loop Rd"; //Pg has given wrong latlng
			geo = "TRUE";
		}
		
		
//		if(add[0]== null && add[3] != ALLOW_BLANK){
//			if(latLong[0] != ALLOW_BLANK && latLong[1] != ALLOW_BLANK){
//				String addr[] = U.getAddressGoogleApi(latLong);
//				if(addr == null)addr = U.getAddressHereApi(latLong);
//				add[0] = addr[0];
//				geo = "TRUE";
//			}
//		}
		if(add[0]==ALLOW_BLANK||add[0]==null) {
			add=U.getAddressGoogleApi(latLong);
			geo="True";
			
		}
		U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]	+ " add[3] " + add[3]);
		
		// ========= Plan & Home available Urls Sec ==============
		String combinedHomeHtml = ALLOW_BLANK;
//		String [] homeUrlSection = U.getValues(html, "<h3 class=\"xCommunityNameHeader\">", "</h3>");
		String [] homeUrlSection = U.getValues(html, "<div id=\"card_header_plan", "Request More Information");

		U.log("Available Plans Count =="+homeUrlSection.length);
		for(String homeUrlSec : homeUrlSection){
			String homeUrl = U.getSectionValue(homeUrlSec, "<a class=\"card_anchor\" href=\"", "\"");
			U.log("home url::"+homeUrl);
			
			combinedHomeHtml += U.getHtml(BASE_URL+homeUrl,driver);
			combinedHomeHtml=U.getSectionValue(combinedHomeHtml, "<div class=\"stickyHeaderSpacer\"", "Floor Plans</span></h3>")+combinedHomeHtml.replaceAll(" Loft\\s*</li>", "a loft");
//			if (combinedHomeHtml.contains("Tri-plex")) {
//				U.log("FOUNDTRI");
//			}
		}
		
		
		//============ Available Homes ===================
		
//		if(html.contains("Available Plans to Build")) {
//			
//			String [] homesSection = U.getValues(html, "<div class=\"card_row card-row", "Request More Information");
//			U.log("Available Home Count =="+homesSection.length);
//			for(String homeUrlSec : homesSection){
//				String homeUrl = U.getSectionValue(homeUrlSec, "href=\"", "\"");
//				U.log("home url::"+"https://www.spinellhomes.com"+homeUrl);
//				
//				combinedHomeHtml += U.getHtml("https://www.spinellhomes.com"+homeUrl,driver);
//				
//			}
//			
//		}
		
		String [] homesSection = U.getValues(html, " data-card-spec-column-id=\"card_specs_spec", "Request More Information");
		U.log("Available Home Count =="+homesSection.length);
		for(String homeUrlSec : homesSection){
			String homeUrl = U.getSectionValue(homeUrlSec, "href=\"", "\"");
			U.log("home url::"+"https://www.spinellhomes.com"+homeUrl);
			
			combinedHomeHtml += U.getHtml("https://www.spinellhomes.com"+homeUrl,driver);
			combinedHomeHtml=U.getSectionValue(combinedHomeHtml, "<div class=\"stickyHeaderSpacer\"", "Floor Plans</span></h3>")+combinedHomeHtml.replaceAll(" Loft\\s*</li>", "a loft");
			if (combinedHomeHtml.contains("Tri-plex")) {
				U.log("FOUNDTRI");
			}
		}
//		U.log("FOUNDTRI=="+homesSection.length);
		
		
		//============ Quick Move Homes ===================
		String quickMoveHtml = U.getHtml("http://spinellhomes.com/find-a-home/quick-move-ins/",driver);
	//	String [] quickHomeSections = U.getValues(quickMoveHtml, "<div class=\"listingHeader\">", "<div class=\"free-link-wrap\">");
		String [] quickHomeSections = U.getValues(quickMoveHtml,"<div class=\"card_row card-row-3 \"","Request More Information");
		int quickHomeCount = 0;
		String quickHomeContent = null;
		for(String quickHomeSec :  quickHomeSections){
			//String comName = U.getSectionValue(quickHomeSec, "homeCommunityName\">", "</div>");
			String comName = U.getSectionValue(quickHomeSec,"<span class=\"card_subtitle \" card_spec\"=\"\">","</span></div></div></div>");
            
			if(comName.trim().toLowerCase().equals(commName.toLowerCase())){
				//U.log(comName);
				quickHomeContent += quickHomeSec;
				quickHomeCount++;
			}
		}
		U.log("Quick Home Count= "+quickHomeCount);
		// ---------community type=============
		String commType = U.getCommunityType(html.replaceAll("aggregated account|data.config.Gated|Aggregated|dm_gaq.gaAggregatedEventAttributes|_dm_gaq.systemAggregatedGaqID|apiText = \"Green Community\";|IsGated|config.Gated|apiText = \"Master Planned\";|setMasterPlanned", "").replace("Ruby Estates offers beautiful mountain and lake views", "Ruby Estates offers beautiful mountain and The Lakeside Estates views"));
		//U.log("ooo"+Util.matchAll(html, "[\\w\\s\\W]{20}gated[\\w\\s\\W]{30}", 0));
		
		//====== property type---------//
		combinedHomeHtml=U.getNoHtml(combinedHomeHtml);
//		U.log(Util.matchAll(arr+html+combinedHomeHtml, "[\\w\\s\\W]{10}condo[\\w\\s\\W]{20}", 0));

		String propType = U.getPropType((arr+html+combinedHomeHtml).replaceAll("Pancho Villa|IsCondo|data.config.CondoOrTownhome|apiText = \"Multi Family\"|CUSTOM FEATURES|config.MultiFamily|IsTownHome|CondoOrTownhome|apiText = \"Single Family\"|townhouse|Coastal Trail is conveniently|Triplex at Dove Tree|Duplex Elevation|Triplex Second Floor|Triplex First Floor|Triplex Elevation", "").replace("participation",""));
		
		U.log("propType: "+propType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(arr+html+combinedHomeHtml, "[\\s\\w\\W]{30}single[\\s\\w\\W]{30}", 0));
		
		//========= Derived Community Type ================
		String dpType = U.getdCommType((html+quickHomeContent+combinedHomeHtml.replace("Hidden Ranch", "")).replace("rAnchor", "")+commName);
//		U.log("MMMMMMMMMMM"+Util.matchAll((html), "[\\s\\w\\W]{30}Ranch[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMM"+Util.matchAll((quickHomeContent), "[\\s\\w\\W]{30}Ranch[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMM"+Util.matchAll((combinedHomeHtml), "[\\s\\w\\W]{30}2-story[\\s\\w\\W]{30}", 0));

		//=========== Property Status =============
		//-----REMOVING SCRIPT SECTION
		if(html.contains("window.customWidgetsFunctions") && html.contains("<script id=\"ssr-script\" type=\"text/javascript\">")) {
			
			String remove = U.getSectionValue(html, "window.customWidgetsFunctions", "<script id=\"ssr-script\" type=\"text/javascript\">");
			//U.log("remove: "+remove);
			html = html.replace(remove, "");
		}
		
		html = html.replaceAll("<span>QUICK|Anchor\">QUICK|Anchor\">\\s+QUICK", "");
		
		String commStatus = U.getPropStatus((arr+ html).replaceAll("Dove Tree lots are going fast|views closing out|Grand Opening Special:|IGrand Opening Special:|sCommingSoonGrandOpening|IsGrandOpening|closeoutImage|IsCloseOut|comingSoonImage|grandOpeningImage|closeoutImage|CG Coming Soon Grand Opening|C -Coming Soon|G -Grand Opening|X - Close Out","").replace("Lots are selling quickly", "Lots selling quickly").replace("Homes Available Now", "").replace("There are still several lots available that", ""));
		
		if(quickHomeCount > 0 && html.contains("Homes Available Now")){
			if(commStatus != ALLOW_BLANK)
				commStatus += ", Quick Move In Homes";
			else if(commStatus == ALLOW_BLANK)
				commStatus = "Quick Move In Homes";
		}
		if(quickHomeContent!=null) {
			quickHomeContent=quickHomeContent.replace("Priced at $285,000", "");
		}
		
		U.log("commStatus: "+commStatus);
		
//		U.log("MMMMMMMMMMM"+Util.matchAll(html, "[\\s\\w\\W]{30}closing[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMM"+Util.matchAll(arr, "[\\s\\w\\W]{30}closing[\\s\\w\\W]{30}", 0));
		
		//----prices----------------------------//
		
		//removing unwanted price list section
		if(html.contains("function getPriceMappingValue")) {
			String removePrices = U.getSectionValue(html, "function getPriceMappingValue", "return priceRangeMapping");
			//U.log("removePrices: "+removePrices);
			html = html.replace(removePrices, "");
		}
		
		String[] price = U.getPrices(html+quickHomeContent+arr,
				"Starting at \\$\\d{3},\\d{3}<|\\$\\d+,\\d+ |\\$\\d+,\\d+|STARTING at \\$\\d+,\\d+", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
//		U.log("MMMMMMMMMMM"+Util.matchAll(html, "[\\s\\w\\W]{30}999,000[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMM"+Util.matchAll(arr, "[\\s\\w\\W]{30}999,000[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMM"+Util.matchAll(quickHomeContent, "[\\s\\w\\W]{30}999,000[\\s\\w\\W]{30}", 0));
		
		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html+quickHomeContent+arr+combinedHomeHtml,
						"over \\d,\\d{3} square feet|\\d{4} - \\d{4}|\\d{4} to \\d{4} square feet|\\d+,\\d+ sq.ft|\\d{1},\\d{3} Square Feet|\\d+,\\d+ Square Feet",
						0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// ---notes-----//
		
		if(commUrl.contains("http://www.spinellhomes.com/find-a-home/colt/"))add[0] = "Canyon Rd";
//		if(commUrl.contains("http://spinellhomes.com/community-details/The-Terraces-92917"))commStatus=commStatus.replace("Closing Out Soon", "Close Out Soon");

		U.log("::::::"+latLong[0].length()+"::::::::::::");
		data.addCommunity(commName, commUrl, commType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		}
		j++;
//		}catch(Exception e){}
	}
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
//					Thread.sleep(10000);
					driver.get(url);
					//U.log("after::::"+url);
				//	Thread.sleep(60000);
				//	((JavascriptExecutor) driver).executeScript(
				//			"window.scrollBy(0,400)", ""); 
					Thread.sleep(15000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}