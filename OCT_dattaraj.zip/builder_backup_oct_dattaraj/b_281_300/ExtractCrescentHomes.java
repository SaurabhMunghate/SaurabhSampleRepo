/* @Modify : Sawan
 * @Date : 12-07-2017
 * Modification Aditya..
 */
package com.shatam.b_281_300;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCrescentHomes extends AbstractScrapper {
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractCrescentHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Crescent Homes.csv", a.data()
				.printAll());
	}

	public static String homeUrl = "https://www.crescenthomes.net";

	public ExtractCrescentHomes() throws Exception {
		super("Crescent Homes", homeUrl);
		LOGGER = new CommunityLogger("Crescent Homes");
	}

	int count = 0;
//	WebDriver driver = new FirefoxDriver();
	public void innerProcess() throws Exception {
		String html = U.getHTML(homeUrl);
		String regionSections = U.getSectionValue(html, "<ul class=\"nav nav-tabs\" id=\"myTabs\"", "</ul>");
		String [] regionUrls = U.getValues(regionSections, "<a href=\"", "\"");
		for(String regionUrl : regionUrls){
			regionUrl = regionUrl.replace("http:", "https:");
			U.log("RRRR------------->"+regionUrl);
//			String html1 = U.getHTML(homeUrl + "/new-homes/");
			
			String html1 = U.getHTML(regionUrl);
			String newdata=U.getSectionValue(html1, "<div class=\"communities pt-5em pb-3em ptb-mb-2em\">", "<div class=\"contact-us-communities ptb-6em ptb-mb-2em\">");
			newdata=newdata.replace("<section class=\"thin-line\">", "  <div class=\"col-md-4 col-sm-6 pb-2em\">");
			String[] urls = U.getValues(newdata, "<div class=\"col-md-4 col-sm-6 pb-2em\">", "</span></div>");
			U.log("lenth"+urls.length);
			for (String loc : urls) {
				String loc1=U.getSectionValue(loc, "<a href=\"", "\">");
				loc1 = homeUrl + loc1;
//				U.log("loc1==="+loc);
//				try {
					commDetails(loc1,loc);
//				} catch (Exception e) {}
			}
		}
		
//		String html = U.getHtml(url, driver);
		LOGGER.DisposeLogger();
	}

	public void commDetails(String commUrl,String comsec) throws Exception {
	//TODO :	
//	if(count==11)
	{

//	if(!commUrl.contains("https://www.crescenthomes.net/new-homes/sc/greer/saddlebrook-farm/6138/"))return;
		
		
//		U.log(comsec);
		if (data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		String html = U.getHTML(commUrl);
		U.log("count::"+count+"\t"+commUrl);
		U.log(U.getCache(commUrl));
		
		html = U.removeSectionValue(html, "<head>", "</head>");
		//===================== Community Name ======================
		String commName = U.getSectionValue(html, "<h1>", "</h1>");
		commName = U.getNoHtml(commName).trim();
		
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/mt-pleasant/copahee-sound/10073/")) commName = "Copahee Sound";
		
		U.log("commName::"+commName);


	
		//==================== Notes =========================
		String notes = ALLOW_BLANK;

		notes = U.getnote(html.replaceAll("Announces New Phase Pre-Selling in Spring|announces-new-phase-pre-selling-in-spring/", ""));

		
		// ================= LatLong Section ===================
		String geo = "False";
	
		String lat = ALLOW_BLANK;
		String lng = ALLOW_BLANK;
		lat=U.getSectionValue(html, "CENTER_LATITUDE':'", "'");
		lng=U.getSectionValue(html, "CENTER_LONGITUDE':'", "'");
		
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
		
		if(lat.contains("33°10&#39;46.8&quot;N")) {
			lat =  ALLOW_BLANK;
			lng =  ALLOW_BLANK;
		}
		
		U.log("lat ::"+lat+ "  lng ::"+lng);
		
		//===================== Address =================
		html = html.replace("community location:</h4>", "community Address:</h4>")
				.replace("Agent on Site", "community Address:")
				.replace("Model Home Address:</h4>", "community Address:</h4>");
		String addSec = U.getSectionValue(html, "Address:</h4>", "</p>");
		if(addSec == null)
			 addSec = U.getSectionValue(html, "ADDRESS</h4>", "</p>");
		U.log("AddSec ==="+addSec);
		if(addSec != null){
			addSec  =addSec.replaceAll(", Summerville, SC, , Summerville, SC", ", Summerville, SC")
					.replaceAll(", Summerville, SC 29483, Summerville, SC 29483", ", Summerville, SC 29483");
			addSec = addSec.replaceAll("<p>", "");
			addSec =U.getNoHtml(addSec);
			
			add = U.getAddress(addSec);
		}
		
		
		if(lat != null && lng != null && add[0] == ALLOW_BLANK){
			String latlng[]={lat,lng};
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			add[0] = add[0].trim();
			add[1] = add[1].trim();
			add[2] = add[2].trim();
			add[3] = add[3];
			geo = "TRUE";
		}
		if(lat == ALLOW_BLANK && lng == ALLOW_BLANK && add[0] != ALLOW_BLANK){
			String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			lat=latlng[0];
			lng=latlng[1];
			geo = "TRUE";
		}
		
		if (addSec==null&&lat==null) {
			//if (commUrl.contains("https://www.crescenthomes.net//new-homes/sc/greenville/carilion-estates/1559/")) {
				String cityState = U.getSectionValue(html, "</h1><h3>", "</h3>");
/*				add[2] = "SC";
				add[1] = Util.match(cityState, "(.*?), "+add[2],1);
*/				
				if(cityState != null && cityState.contains(",")){
					add[1] = cityState.split(",")[0].trim();
					add[2] = cityState.split(",")[1].trim();
				}
				String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
				latlng=U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				lat=latlng[0];
				lng=latlng[1];
				add=U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);

				notes="Address And Lat Long Taken Using City State";
				geo = "TRUE";
			//}
		}
		U.log("Address :::"+Arrays.toString(add));
		if(add[3].length()<4 && lat.length()>4){
			String add1 [] = U.getAddressGoogleApi(new String[]{lat,lng});
			if(add1 == null) add1 = U.getAddressHereApi(new String[]{lat,lng});
			add[3] = add1[3];
			geo = "TRUE";
		}
		
//		if(commUrl.contains("https://www.crescenthomes.net/new-homes/tn/murfreesboro/kingsbury/5002/")){
//			add = "Desinda Dr, Murfreesboro,TN,37129".split(",");
//			String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
//			latlng=U.getlatlongGoogleApi(add);
//			if(latlng == null) latlng = U.getlatlongHereApi(add);
//			lat=latlng[0];
//			lng=latlng[1];
//			notes="Street Is Taken From Plat Map";
//			geo = "TRUE";
//		}
		//============== Homes Plan Htmls ===============
		String planHtml="";
		
		String [] planUrls = U.getValues(html, "<span class=\"plan-name\"><a href=\"", "\"");
		if(planUrls.length==0)planUrls = U.getValues(html, "<span class=\"spec-name\"><a href=\"", "\"");
		
		U.log("Total plan : "+ planUrls.length);
		for(String planUrl : planUrls){
			planUrl = "https://www.crescenthomes.net"+planUrl;
			U.log("planUrl " + planUrl);
			planHtml += U.getHTML(planUrl);
		}
		
		String AllQuickData = "";
		String qSec  =U.getSectionValue(html, ">plat map</span></h1>", "</map></section>");
		if(qSec!=null){
		for(String qUrl : U.getValues(qSec, "href=\"", "\"")){
			if(qUrl.contains("None"))continue;
			
			qUrl = "https://www.crescenthomes.net"+qUrl;
			
			if(qUrl.contains(".pdf"))continue;
			
			
			
			U.log("qUrl :: "+qUrl);
		
			String qHtml = U.getHTML(qUrl);
			AllQuickData += U.getSectionValue(qHtml, "about this home</span>", "get directions</span>");
			
		}
		}
		
		String seriesvalue=U.getSectionValue(html, "data-tag=\"", "\">");
		//inventoryHomes
		String inventoryHomesListing[] = {};
		String allInventoryData = ALLOW_BLANK;
		String invHtml="";
		for(int i=1;i<=3;i++) {
		String invUrl=commUrl+"?i=0&tag="+seriesvalue+"&page="+i+"&planspecs=1";
		U.log(invUrl);
		invHtml+=U.getHTML(invUrl);
		
		
		}
		
		if(html.contains("<a>Inventory Homes</a>")) {
			
		String inUrl = U.getSectionValue(html,"<span class=\" btn-right btn-inactive section_button \" data-href=\"","\"");
		if(inUrl == null)inUrl =U.getSectionValue(html,"section=specs\" data-url=\"","\" id=\"btn-move-in\">");
		
		U.log("inUrl==="+inUrl);
		if(inUrl!=null) {
		
		String inventoryHomesPage = U.getHTML("https://www.crescenthomes.net"+inUrl);
		String pageSection = U.getSectionValue(inventoryHomesPage, "<ul class=\"pagination\">", "</ul></div>");
		if(pageSection!=null) {
			inventoryHomesListing = U.getValues(pageSection, "href=\"", "\"");	
			for(String qUrl : inventoryHomesListing){
				
				U.log("pageqUrl :: "+qUrl);
			
				String qHtml = U.getHTML("https://www.crescenthomes.net"+qUrl);
				String homePlansData[]  = U.getValues(qHtml, "class=\"spec-name\"><a href=\"", "\"") ; 
				for(String home:homePlansData) {
					U.log("inventoryUrl :: "+home);
					String htm = U.getHTML("https://www.crescenthomes.net"+home);
					allInventoryData+=U.getSectionValue(htm, "<div id=\"main-content\">", "<h1><span class=\"white-line\">Contact ");
				}
			}
		}
		else {			
				String homePlansData[]  = U.getValues(inventoryHomesPage, "class=\"spec-name\"><a href=\"", "\"") ; 
				for(String home:homePlansData) {
					U.log("qUrl :: "+home);
					String htm = U.getHTML("https://www.crescenthomes.net"+home);
					allInventoryData+=U.getSectionValue(htm, "<div id=\"main-content\">", "<h1><span class=\"white-line\">Contact ");
				}
			
		}
		}
		}
		//================== Property Type ====================
		html=html.replaceAll("craftsman style trim package|Cottages at Stono|Cottages At Stono","").replaceAll("cottages-at","").replace("Estates Homes</a>", "")
				.replace("luxury of an exclusive", "Luxury Homes");
		//U.log(AllQuickData);
		String pType = U.getPropType(commName+(html+planHtml+AllQuickData+allInventoryData).replaceAll("with no HOA|<img alt=\"Redefining the custom home|The Cottages at|Cottages at Stono|Cottages At Stono","").replaceAll("cottages-at","").replaceAll("The Cottages at Stono Ferry|detached garages|detached 2 car garage|luxurious bath|Cottages at Stono|cottages-at-|The Cottages at Stono|-townhomes-|Alderly Townhomes|Note: HOA",""));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(allInventoryData, "[\\w\\s\\W]{30}craftsman style home[\\w\\s\\W]{30}", 0));

		U.log("propType: "+pType);
		
		
		//================ Derived Property Type =================
		planHtml=planHtml.replaceAll("Stories:</span>\\W+<span class=\"catItemExtraFieldsValue\">", "story ").replace("stories\">1.5</span>", " 1.5 Story")
				.replace("stories\">2", " 2 Story ").replace("stories\">1<", " 1 Story ").replace("stories\">3</span>", "3 story");
		html=html.replaceAll(">1-2 Story Plans|1-2-story|1- 2 Story Home"," 1 Story 2 Story ").replaceAll("1-3 Story|1-3 story plans"," 1 Story,3 Story ");
		String dType = U.getdCommType((html+planHtml+AllQuickData+allInventoryData).replaceAll("modern 1-3 story floor plans|floor|floor, tile","").replace("one and two story ","1 story 2 story").replace("1 to 3 Stories"," 1 story 2 story 3 story").replace("1 to 2-story","1 story 2 story").replace("1-2 story"," 1 story  2 story ").replace("1 - 3 story plans", "1 story 2 story 3 story plans").replaceAll("stories\">\\s*\\n*\\s*2", " 2 Story ").replaceAll("stories\">\\s*\\n*\\s*1", " 1 Story ").replaceAll("stories\">\\s*\\n*\\s*3", " 3 Story "));
		U.log("DTYpe::"+dType);
		
		
		
		
		// ============== Prices =============
		html=html.replace("0�s","0,000");
		html=html.replaceAll("0s|�s|0’s|0's", "0,000");
		html=html.replace("’s</li>",",000");
		comsec = comsec.replace("0's", "0,000").replace("Low 200", "$200");
		//U.log("KKKKKKKK"+html);
		
		if (html.contains("move-in ready homes")) {
			planHtml=planHtml+U.getPageSource(commUrl.replace(".net//", ".net/")+"?section=specs");
		}
		String[] Prices = U.getPrices(html+comsec+AllQuickData+planHtml+allInventoryData+invHtml, "price : </a></small>\\$\\d{3},\\d{3}|Base Price: \\$[0-9]{3},[0-9]{3}|\\$\\d{3},\\d{3}", 0);
		
		
		if (Prices[0] == null)
			Prices[0] = ALLOW_BLANK;
		if (Prices[1] == null)
			Prices[1] = ALLOW_BLANK;
		U.log("Max Price::"+Prices[0]+"\tMin Price::"+Prices[1]);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comsec, "[\\s\\w\\W]{30}\\$514,900[\\s\\w\\W]{30}", 0));

		// ============ Area =========================
		
		//==================== SQFT =========================
		html=html.replace("–", "-");
//		U.log(html);
		String[] area = U.getSqareFeet((html+planHtml+allInventoryData+invHtml).replace("7,000 Square Feet of Commercial Space", ""), 
				"Ranging from \\d,\\d{3} - \\d,\\d{3} Sq Ft|\\d{4} square feet|Ranging from \\d{4} SF - \\d{4} SF|Ranging from \\d,\\d{3} - over \\d,\\d{3} |Sq.Ft. :</a></small>\\d,\\d{3} - \\d,\\d{3}</span>|homes ranging from \\d,\\d{3} to over \\d,\\d{3} square feet|Floorplans ranging \\d{4}-\\d{4} Square Feet|ranging up to \\d,\\d{3}\\+ square feet|\\d+,\\d+-\\d+,\\d+ sq.ft.|\\d+,\\d+\\+ sq. ft|roughly \\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3}\\+ Square Feet|\\d,\\d{3} to \\d,\\d{3}\\+ square feet|\\d{4} - \\d{4}\\+ Sq Ft|\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\+ Sq|from ranging \\d,\\d{3}-\\d,\\d{3} Square Feet </li>|from ranging \\d{4}-\\d{4} Square Feet|from \\d,\\d{3} - \\d,\\d{3} SF|\\d,\\d{3}\\s?-\\s?\\d,\\d{3} (s|S)quare (f|F)eet|[0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3} square feet|\\d{4} \\- \\d,\\d{3} Sq. Ft|\\d,\\d{3} Square Fee|\\d,\\d{3} sq. ft|sq-ft\">[0-9]{1},[0-9]{3}|from: \\d,\\d{3} to \\d,\\d{3} sq. ft.|\\d,\\d+ sq. ft. to \\d,\\d+ sq. ft|\\d{4} sq. ft. - \\d{4} sq. ft.|Square Feet:\\d+,\\d+|>\\d,\\d+</span>|\\d+ - \\d+ square feet|up to \\d,\\d+ to \\d,\\d+|\\d{4} - \\d{4} square feet|\\d{4}-\\d{4} sq.ft.|\\d{4}-\\d{4} sq.ft.|sq-ft\">\\d,\\d{3}|from \\d{4}|\\d,\\d{3} \\+ sq. ft.",
				0);
		if (area[0] == null)
			area[0] = ALLOW_BLANK;
		if (area[1] == null)
			area[1] = ALLOW_BLANK;
		
		U.log("Min SQ::"+area[0]+"\tMax SQ::"+area[1]);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(html+planHtml+allInventoryData+invHtml, "[\\s\\w\\W]{30}7,000 Square Feet[\\s\\w\\W]{30}", 0));
		// ========================= Community Type ===================
		html=html.replaceAll("Near Golf Courses|Golf Courses Near Indigo|near-golf-courses/|masterplans|Square Master Plan|masterplan|Golf Courses Near Summerville|gables-golf-courses/|Gated dog", "");
		String commType = U.getCommunityType(html);

		//===================== Property Status ======================
		html = html.replaceAll("h only one opportunity remaining to live in a Cre|>The Cottages at|grocery store are now open|Elementary Now Open|Indigo Palms Announces New Phase Now Selling|inal phase of this community is certainly|school opening Fall 2017|Last Chance to|leg\">Move|content=\"Now Selling!\"|<title>Now Selling!</title>","")
				.replaceAll("Pool Coming|School Coming|school opening Fall|School Now Open|soon to Greer|Currently Selling from Drayton", "");
	//	U.log(comsec);
		if(commUrl.contains("/charleston/oak-bluff/863/"))html = html.replace("banner-loc-detail\"><p>Coming Soon!</p>", "");
		comsec = comsec.replace("figurecaption\">Available Now</div></div></a>", "");
		
		String Status = U.getPropStatus((comsec + html).replaceAll("Elementary is now open|Under Plans Now|Announces New Phase Now Open", ""));
		U.log("Status: "+Status);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comsec + html, "[\\s\\w\\W]{30}Available Now[\\s\\w\\W]{30}", 0));
//		notes=U.getnote(html);

		if (commName.contains("</")) {
			commName = ">" + commName;
			commName = U.getSectionValue(commName, ">", "</");
		}
		if(commUrl.contains("https://www.crescenthomes.net//new-homes/tn/hendersonville/mansker-farms/1498/")) {
			Status=Status+", Home With Basement Available";
		}	

/*		if(commUrl.contains("new-homes/sc/summerville/hampton-woods/2775/")) {
			Status=Status.replace("Final Opportunities", "Final Opportunities In Phase 1");//image
		}*/
		
//		if(commUrl.contains("https://www.crescenthomes.net//new-homes/sc/travelers-rest/poinsett-crossing/4023/")) {
//			Prices[0]="$200,000";//image
//		}
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/fountain-inn/foxchase/7074")) {
			Prices[1]="$408,990";//image
		}

		if(lat == null){
			lat = ALLOW_BLANK;
			lng = ALLOW_BLANK;
		}
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/johns-island/waterloo-estates/806"))
			Status=Status.replace(", Coming Soon", "");
		
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/charleston/oak-bluff/863"))
			Status=Status.replace(", Coming 2021", "");
		
		
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/summerville/drayton-oaks/3000"))
			Status=Status.replace(", Final Phase Now Selling", "");
		
		
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/simpsonville/the-villages-at-red-fearn/1874"))
			pType="Craftsman Style Homes";
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/charleston/nelliefield/6042")) {
			//Nelliefield Creek Drive, Charleston, SC 29492
			add[0]="Nelliefield Creek Drive";
			add[1]="Charleston";
			add[2]="SC";
			add[3]="29492";
			lat="32.92423565555348";
			lng="-79.85026545435335";
			
			geo="FALSE";
		}
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/charleston/the-retreat-at-river-reach/6043")) {
			//River Reach Drive, Charleston, SC 29492 
			add[0]="River Reach Drive";
			add[1]="Charleston";
			add[2]="SC";
			add[3]="29492";
			lat="32.921062019199624";
			lng="-79.84680910555726";
			
			geo="FALSE";
		}
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/tn/murfreesboro/kingsbury/5002")) {
			//5213 Pointer Place, Murfreesboro, TN 37129
			
			addSec = U.getSectionValue(html, "<br/><h4>Model Home for Kingsbury</h4><p>", "</p>");
			U.log(addSec+":::::::new address ection");
			add=U.getAddress(addSec);
			geo="FALSE";
		}

		Status=Status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
	//s	if(commUrl.contains("https://www.crescenthomes.net/new-homes/tn/spring-hill/wilkerson-place/6159"))Status="Now Available";
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/summerville/hampton-woods/2775"))Status ="New Homesites Coming Soon";
		if(commUrl.contains("https://www.crescenthomes.net/new-homes/sc/charleston/avenue-of-oaks/6279/")) commName = "Avenue Of Oaks";
		
		
		
//		===================================================================================
		
		String[] lot_data=null;
		String lotCount=ALLOW_BLANK;
		String lot_Sec=U.getSectionValue(html, "usemap=\"#platmap_map\"/>", "<div class=\"sitemap-key\">");
		if(lot_Sec!=null) {
			lot_data=U.getValues(lot_Sec, "<a class=\"dot\"", "</a>");
			if(lot_data.length>0) {
			lotCount=Integer.toString(lot_data.length);
			 U.log("lotCount=="+lotCount);
			}
		}
		
		
		
		
		
		data.addCommunity(commName, commUrl, commType);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPrice(Prices[0], Prices[1]);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(area[0], area[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(Status.replace("Final Phase, Now Selling Final Phase", "Now Selling Final Phase").replace("New Phase Coming Soon, New Phase Coming 2021", "New Phase Coming Soon"));
		data.addNotes(notes);
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		count++;
	}
	
	}
}