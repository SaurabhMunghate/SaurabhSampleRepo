/**
 * @author Upendra Singh 
 * @date 27/01/2017
 * 
 */
package com.shatam.b_281_300;

import java.io.IOException;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractEDCHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractEDCHomes()
			throws Exception {
		super("EDC Homes","www.edchomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("EDC Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractEDCHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"EDC Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("http://www.edchomes.com/new-home-communities/norfolk-va-communities/");
		String[] comSec=U.getValues(mainHtml, "<div class=\"community-info\">","View Details");
		U.log("total Community-->"+comSec.length);
		for(String comData:comSec)
		{
			String comUrl="http://www.edchomes.com"+U.getSectionValue(comData, "<a href=\"","\"");
			addDetails(comUrl,comData);
		}
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
	//	if(!comUrl.contains("http://www.edchomes.com/new-home-communities/norfolk-va-communities/bayshore-dunes/"))return;
		
		
				U.log(j+"   commUrl-->"+comUrl);
						String html=U.getHTML(comUrl);
						
						/*String rem=U.getSectionValue(html, "<head>","class=\"dropdown-menu\">");
						html=html.replace(rem,"");*/
				//============================================Community name=======================================================================
						
						String communityName=U.getSectionValue(html, "<h1>","</h1>").replace("&#39;","");
						U.log("community Name---->"+communityName);
						
				//================================================Address section===================================================================
						
						String note="";
						String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
						String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
						String geo="FALSE";
					
						String addSec=U.getSectionValue(html, "<div class=\"address\">","</div>");
						
						U.log(addSec);
						if(addSec!=null)
						{
							addSec=addSec.replace("<br/>",",");
							
							U.log(addSec);
							String[] add1=addSec.split(",");
							
							if(add1.length>2)
							 {
								 add[0]=add1[0];
								 add[1]=add1[1];
								 add[3]=Util.match(add1[2],"\\d{4,}");
								 if(add[3]!=null)
								 {
								 add[2]=add1[2].replace(add[3],"").trim();
								 }
								 else
								 {
									 add[2]=add1[2];
								 }
							 }
						}
						
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
						
				//--------------------------------------------------latlng----------------------------------------------------------------
						
						String latSec=U.getSectionValue(html, "https://www.google.com/maps/place","\"");
						
						if(latSec!=null)
						{
							latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
							latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
						}
						
						U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
						
						if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
						{
							latlag=U.getlatlongGoogleApi(add);
							
							geo="TRUE";
						}
						if((add[0].length()<2 ||add[2]==null)&& latlag[0]!=ALLOW_BLANK)
						{
							add=U.getAddressGoogleApi(latlag);
							geo="TRUE";
						}
						if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
						{
							add[3]=U.getAddressGoogleApi(latlag)[3];
							geo="TRUE";
						}
						
						
						U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
						
				//============================================Price and SQ.FT======================================================================
						

						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
						
						html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
						
						comData=comData.replaceAll("0&#8217;s|0�s|0's|0s","0,000");
						
						String prices[] = U.getPrices(html+comData,"\\$\\d{1},\\d+,\\d+|\\$\\d+,\\d+", 0);
						
						minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
						maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
						
						U.log("Price--->"+minPrice+" "+maxPrice);
						
				//======================================================Sq.ft===========================================================================================		
						String[] sqft = U
								.getSqareFeet(
										html+comData,
										"\\d{1},\\d+ to \\d{1},\\d+ square feet|Square Ft:</strong> \\d{1},\\d+ - \\d{1},\\d+|Square Footage:</strong>  \\d{1},\\d+",
										0);
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						U.log("SQ.FT--->"+minSqft+" "+maxSqft);
						
				//================================================community type========================================================
			
						String communityType=U.getCommType(html+comData);
						
				//==========================================================Property Type================================================
						
						String proptype=U.getPropType(html.replaceAll("-townhouse-|Craftsman Style Doors|luxurious bathrooms|Carriage Style Overgead Garage|Carriage Style Garage", "")+comData);
						
				//==================================================D-Property Type======================================================
						html=html.replace("Stories <span class=\"value\">", "Story ");
						html=html.replace("2<sup>nd</sup>"," 2 Story ");
						html=html.replace("3<sup>rd</sup>", " 3 Story ");
						
						String dtype=U.getdCommType(html+comData);
						
				//==============================================Property Status=========================================================
						
						String pstatus=U.getPropStatus(comData);
						
						
				//============================================note====================================================================
						
						
						
						if(data.communityUrlExists(comUrl))
							{
							LOGGER.AddCommunityUrl(comUrl);
							k++;
							return;
							}
						add[2]=add[2].replace(",","").trim();
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
							data.addCommunity(communityName,comUrl, communityType);
							data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(proptype, dtype);
							data.addPropertyStatus(pstatus);
							data.addNotes(note); 
							j++;
	}

}
