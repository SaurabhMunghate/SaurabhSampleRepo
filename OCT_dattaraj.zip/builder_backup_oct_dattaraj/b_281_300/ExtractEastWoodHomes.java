/**
 * @author Sampada Santosh
 * @date 10-03-2017
 * @modify Sawan
 * @date 07-10-2017
 */
package com.shatam.b_281_300;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractEastWoodHomes extends AbstractScrapper {
	static int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	public static int repeated = 0;
	static int k = 0;
	static int zzz = 0;
	int nulll=0;
	public static WebDriver driver= null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractEastWoodHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Eastwood Homes.csv", a.data().printAll());

		System.out.println("Total Repeated :" + repeated);
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
		U.log("null url" + zzz);
	}

	public ExtractEastWoodHomes() throws Exception {
		super("Eastwood Homes", "https://www.eastwoodhomes.com/");
		LOGGER = new CommunityLogger("Eastwood Homes");
	}

	int a = 0;

	static HashMap<String, String> latlongMap = new HashMap<String, String>();
	
	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String baseUrl = getHtml("https://www.eastwoodhomes.com/find-your-home",driver);

		String regSec = U.getSectionValue(baseUrl, "var divisionsAtlasRTX = {", "};");
		String regnames[] = regSec.split(",");
//		

		
		JsonParser parser = new JsonParser();
		for (String regVal : regnames) {
			String regName = regVal.split(":")[0].replace("\"", "");
			U.log("https://www.eastwoodhomes.com/api/search?query="+regName.trim());
			String regHtml = U.getHTML("https://www.eastwoodhomes.com/api/search?query="+regName.trim());
//			findCommunity(comVal);
			U.log("regName===="+regName);
			
			JsonObject json = (JsonObject) parser.parse(regHtml);

			
			JsonArray communityJson = json.get("communities").getAsJsonArray();
			U.log("Communities in "+ regName +" "+ communityJson.size());
			
			for(JsonElement comJson : communityJson){
				String commData=comJson.toString();
				
				String latitude = U.getSectionValue(commData, "latitude\":\"", "\",");
				String longitude = U.getSectionValue(commData, "longitude\":\"", "\",");
				
				
				String latLongSec = latitude + ", " + longitude;
				
//				U.log("latitude: "+latitude+ " longitude: "+longitude);
//				U.log("latLongSec: "+latLongSec);
				
				
				
				if(commData.contains("\"communities\"")) {
					
				}
				
				String comUrl=  "https://www.eastwoodhomes.com/"+regName.toLowerCase().trim()+"/"+U.getSectionValue(comJson.toString(), "\"region_slug\":\"", "\"")+"/"+U.getSectionValue(comJson.toString(), "\"slug\":\"", "\"");
				if(comUrl.contains("harrisburg-village-community")) {
					comUrl="https://www.eastwoodhomes.com/charlotte/harrisburg/harrisburg-village-community";
				//U.log("KKK");
				
				}
				if(comUrl.contains("1158-place")) {
					comUrl="https://www.eastwoodhomes.com/raleigh/wilson/1158-place-community";
				//	U.log("KKK");
				}
				
				String comName= U.getSectionValue(comJson.toString(), ",\"name\":\"", "\"");
				comName=comName.replace(" - 55+ Community","");
				U.log("cpom Name and comm Urls are \n"+comName+" "+comUrl);
				
				String pgHtm =null;
				if (comUrl.contains("https://www.eastwoodhomes.com/columbia/lexington-sc/hadleigh-park")
						||comUrl.contains("www.eastwoodhomes.com/columbia/blythewood/autumn-pond")){
					pgHtm =null;
				} 
				pgHtm=U.getHTML(comUrl);
//				U.log("page html======"+pgHtm);
				
				
				//-------------BELOW FLOW FOR SUB-COMMUNITIES---------
				if(pgHtm !=null && pgHtm.contains("The Neighborhoods of ")) {
					
					U.log("IN SUBCOM SECTION ------------");
					
					//String subSec[]= U.getValues(pgHtm, "<div class=\"c-card-housing-condensed__container\">", "Learn More");
					String subSec[]= U.getValues(pgHtm, "c-card-housing-condensed__content\">", "Learn More");
					U.log("subSec: "+subSec.length);
					
					for(String sec:subSec) {
						String url= U.getSectionValue(sec, "<a class=\"c-card-housing-condensed__link\" href=\"", "\"");
						
						if(url.contains("1158-place"))
							url="https://www.eastwoodhomes.com/raleigh/wilson/1158-place-community";
						
						String name=U.getSectionValue(sec, "<p class=\"c-card-housing-condensed__name\">", "<");
						//U.log("chking url 1"+url.contains("1158-place"));
						
						if(!url.contains("https")) {
							url="https://www.eastwoodhomes.com/"+url;
						}
						
						U.log("SUB COMURL ======= : "+url);
						
						addDetails(url,name, sec,latLongSec);
					}
					
				} 
				//-------------BELOW FLOW FOR MAIN-COMMUNITIES---------
				else {
						
					
					//U.log("chking comUrl 2"+comUrl.contains("1158-place"));
					U.log("MAIN COMURL------: "+comUrl);
					addDetails(comUrl,comName,comJson.toString(),latLongSec);
					
				}
				
			}
			
//			String communitySec=U.getSectionValue(regHtml, ",\"communities\":", "\"homes_mir\":");
//			
//			if(communitySec != null) {
//				
//				String comvalues[]= U.getValues(communitySec, "\"id\":", "\"rtb\":");// "\"rtb\":"); //"}}]}"); //"\"types\":[");
//				U.log(comvalues.length);
//				for(String val:comvalues) {
//					if(!val.contains("\"from_the\":"))continue;
//					val =val.replaceAll("\"name\":\"Community Pool\",|\"name\":\"Smart Home\"|\"name\":\"Adult Lifestyle\"", "");
//					String comUrl=  "https://www.eastwoodhomes.com/"+regVal.toLowerCase().trim()+"/"+U.getSectionValue(val, "\"region_slug\":\"", "\"")+"/"+U.getSectionValue(val, "\"slug\":\"", "\"");
//					
//					U.log("comUrl: "+comUrl);
//					String comName= U.getSectionValue(val, ",\"name\":\"", "\"");
//					U.log("comName: "+comName);
//					addDetails(comUrl,comName,val);
//				}
//			}

		}
	//	U.log("null urls>>"+nulll);
		LOGGER.DisposeLogger();
		driver.quit();
		}

	public void addDetails(String url, String communityName ,String val, String latLongSec) throws Exception {
//		 try{
		
//	if(j>=40 )	
		{
  
			//TODO : Execute sFor single community
//		if(!url.contains("/ford-meadows")) return;

//  if(!url.contains("/ashton-lakes")) return;
//			if(!url.contains("/glens-scott-place")) return;

			String geoSection = latLongSec;
			U.log("latLongSec: "+latLongSec);
			
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "----------------------REPEAT");
				k++;
				return;
			}
//			if (url.contains("www.eastwoodhomes.com/columbia/blythewood/autumn-pond")||
//					url.contains("https://www.eastwoodhomes.com/columbia/lexington-sc/hadleigh-park")) {
//				LOGGER.AddCommunityUrl(url + "************500 Server Error**************");
//				return;
//			}
			
			
			LOGGER.AddCommunityUrl(url);
//U.log("====>"+s);
			U.log("count=="+j);
			String html = U.getPageSource(url);
			
			
			String mainHtm = html;
			U.log(j+"\t"+url);
			//String json=U.getSectionValue(html,"data = {\"","</script>");
			//U.log("J"+json.length());
			//html=html.replace(json,"");
			html = html.replace("New Phase is selling now", "New Phase selling now");
//			html=U.removeSectionValue(html, "<section id=\"community\">", "</html>");
			String oldlatLongsec = U.getSectionValue(html, ",\"community_site_plan\":", "\"meta_description\":");

			String rm = U.getSectionValue(html, "<section id=\"community\">", "</section>");
			if(rm!=null)
			html = html.replace(rm, "");
			
			String rmSec = U.getSectionValue(html, "<section class=\"community-map\">", "</html>");
			if(rmSec!=null)
			html = html.replace(rmSec, "");
			
			//U.log(url + "url:::::::::" + communityName);
			
			String rem = U.getSectionValue(html, "<head>", "</head>");
			if(rem != null) html = html.replace(rem, "");
			// ---------------------latlong---------------------//

			String geo ="FALSE";
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			String latLongsec = U.getSectionValue(html, "new google.maps.LatLng", ");");
			U.log(latLongsec);
			if (latLongsec != null) {

				latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
				latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
				U.log("latlong" + latLong[0]);
				U.log("latlong" + latLong[1]);
//				if(latLong[0].contains("\t")) latLong[0].replace("\t","").trim();
//				if(latLong[1].contains("\t")) latLong[1].replace("\t", "").trim();
				if(latLong[0].contains("37.336746\\t")) latLong[0]="37.336746";
				if(latLong[1].contains("-77.433473\\t")) latLong[1]="-77.433473";
				U.log("latlong" + latLong[0]);
				U.log("latlong" + latLong[1]);
				geo = "FALSE";
				
			}
			if (latLongsec == null && oldlatLongsec!=null) {
				U.log("this is ;latsec::::::::::"+oldlatLongsec);
				latLong[0] = U.getSectionValue(oldlatLongsec, "latitude\":\"", "\"");
				latLong[1] = U.getSectionValue(oldlatLongsec, "\"longitude\":\"", "\"");
				U.log("latlong" + latLong[0]);
				U.log("latlong" + latLong[1]);
				geo = "FALSE";
				if(latLong[0].contains("\t")) latLong[0].replace("\t","").trim();
				if(latLong[1].contains("\t")) latLong[1].replace("\t","").trim();
				if(latLong[0].contains("37.336746\\t")) latLong[0]="37.336746";
				if(latLong[1].contains("-77.433473\\t")) latLong[1]="-77.433473";
				U.log("latlong" + latLong[0]);
				U.log("latlong" + latLong[1]);
			}
			
			U.log("LATLONG ======= "+Arrays.toString(latLong));
			
			U.log("FROM REGION - geoSection: "+geoSection);
			
			if(latLong[0] == ALLOW_BLANK && geoSection != null) {
				
				latLong = geoSection.split(",");
				U.log("LATLONG FROM REGION ======= "+Arrays.toString(latLong));
			}
			
			/////////// -------------------------------adress------------------------///

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			String addsec = U.getSectionValue(html, "-header__address\">", "<");
			 add= U.getAddress(addsec);
			U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2] + " add[3] " + add[3]);
			
			
			//if (add[0].length() < 4) \
			if(add[0].length() < 4){
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				geo = "TRUE";
			}
			//latLong[0]=latLong[0].replace("\t","");
			U.log("latLong[0] : ==== "+latLong[0]);
			
			if((latLong[0]==null || latLong[0]==ALLOW_BLANK) && add[0].length()>4){
				latLong=U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				if(latLong == null) latLong = U.getNewBingLatLong(add);
				geo="True";
			}

			// ---------------Fetch houses Data------------------
			String allHomeData = ALLOW_BLANK;
			int x = 0;
			int quickcount=0;
			String home_sec=U.getSectionValue(html, "<div class=\"c-tabs-homes__content\">", "<section id=\"amenities\">");
			if(home_sec!=null) {
			String[] homeUrls = U.getValues(home_sec, "<a class=\"c-card-housin", "</a>");
			U.log("total homes : " + homeUrls.length);
			
			for (String homeUrl : homeUrls) {
				homeUrl = "https://www.eastwoodhomes.com"
						+ U.getSectionValue(homeUrl, "href=\"", "\"");
				U.log("homeUrl :: " + homeUrl);
				String homeHtml = U.getPageSource(homeUrl);
//				U.log(homeHtml);
//				if(homeUrl.contains("oversized loft area.")){
//					U.log("FOUND");
//				}
				if(homeUrl.contains("floor-plan")){
					allHomeData += U.getSectionValue(homeHtml, "<section class=\"ready-to-build-description\">","Mortgage Calculator");
				}
				if(homeUrl.contains("home")){
					allHomeData += U.getSectionValue(homeHtml, "<section class=\"move-in-ready-description\">","Mortgage Calculator");
					quickcount++;
				}
						
				x++;
				if (x == 10)
					break;
			}
			}

			// ---------community type,property type,property status,derived,
			String moveCount = Util.match(html, "<span class=\"c-tabs-homes__toggle__text\">\\s*Move-In Ready \\((\\d+)\\)", 1);
			String[] soldCountSec =  U.getValues(html, "<div class=\"c-card-housing__sold c-badge-sold\">", "</div>");
			int soldCount = soldCountSec.length;
			U.log(quickcount+"::::::"+soldCount);
			if(moveCount==null)moveCount ="0";
			allHomeData = allHomeData.replace("featuring a loft and ", "featuring a loft homes and ").replaceAll("Kitchen also features a farmhouse", "");
			html = html.replaceAll(
					"luxurious new-home|luxury features|luxury included features|luxury interiors including ",
					" Luxury Homes ");
			html = html.replace("single, and two-story", " 1 Story 2 Story")
					.replaceAll("Stories:\\s*</strong>\\s*2-3", " 2 Stories 3 Stories ").replaceAll("Stories\\s+</span>\\s+2-3\\s+</span>", " 2 Stories 3 Stories ")
					.replaceAll("Stories:\\s*</strong>\\s*1-2", " 1 Story 2 Story ").replaceAll("Stories\\s*</span>\\s*1.5", "1.5 Story")
					.replaceAll("Stories:\\s*</strong>\\s*2|Stories\\s*</span>\\s*2", " 2 Story")
					.replaceAll("Stories:\\s*</strong>\\s*1|Stories\\s*</span>\\s*1", " 1 Story")
					.replaceAll("Stories\\s*</span>1.5", "1 1/2 story home")
					.replaceAll("Stories:\\s*</strong>\\s*3|Stories\\s*</span>\\s*3", " 3 Story ");

			// -------community type-------
			html = html.replace(" luxurious first floor ", "luxury homes").replaceAll("waterfront homesites", "waterfront community"); //|waterfront and marsh views
	//		U.writeMyText(html);
			String commType = U.getCommunityType(html.replace("and waterfront fun by the lake", "and waterfront community fun by the lake").replaceAll("Winterlake Community|Timberlake Community Plan|Golf Course\"|Country Club\"|title\":\"Providence Golf Club\",|\"The Tradition Golf Club|The Effortless Golf Center\"|\"Raintree Country Club\"|\"Cedarwood Country Club\"|\"Carmel Country Club\"|Golf Club nearby|\"Columbia Country Club\"|Active Adult Communities", ""));
//			U.log(Util.matchAll(html+allHomeData,"[\\w\\s\\W]{30}patio[\\w\\s\\W]{100}",0));

			// -------property type--------

			String propType = U.getPropType((html + allHomeData).replaceAll("farmhouse style sink", ""));
			
			 U.log("propType==="+propType);
			
			html=html.replaceAll("one and two story plans|one-and-two story plans", "1 story, 2 story").replaceAll("Stories\\s+</span>\\s+2-3\\s+</span>", "2 story , 3 Story ")
					.replaceAll("DW\\d+ Story|DW \\d+ Story|CC \\d+ Story|CC\\d+ Story|DF \\d+ Story|DF\\d+ Story|DM \\d+ Story|DF\\d+ Story", "")
					.replace("third-floor options", " 3 Story").replaceAll("Stories\\s*</span>\\s*1-2", "1 story, 2 story");
		//	U.log(allHomeData.contains("loft"));
			String dpType = U.getdCommType((html + allHomeData).replaceAll("Stories\\s*</span>\\s*1-2", "1 story, 2 story").replaceAll("Stories\\s*</span>\\s*1.5",  "One and a half-story").replaceAll("The Avery is a one-and-a-half story&nbsp;plan with four bedrooms|Rancharita|One-and-a-half story|first floor|Floor|First floor|floor", ""));
			 U.log("dpType==="+dpType);
			// ----------status------------
			
			
			html=html.replace("Basement and golf course homesites available", "Basement homesites available").replace("Basement homesites are available", "Basement homesites available").replace("coming in 2020", "coming 2020").replaceAll("<strong>Coming soon|<em>\\s*Coming soon!\\s*</em>|strong>\\s*Coming soon", " COMING SOON ");
			html = html.replaceAll("movein\">\\s*Quick Move-In Homes\\s*</label>|_flyout_content\":\"(.*)\"|\"closeout\":1|\"label\":\"Comi|alt\":\"Coming Soon\"|alt=\"Coming Soon\"| quick move-in townhomes |content\":\"Now Selling!\"|enjoy grand opening incentive", "")
					.replaceAll("Move-in|Move in|Move In|move-in|Banks SOLD OUT|Mill SOLD OUT|Homes ready now for quick move-in|Pick-Up Now Available", "");
			html = html.replace("Coming in late Spring 2017", "Coming late Spring 2017")
					.replace("Basement and cul-de-sac homesites are also available", "Basement homesites available");
			html = html.replace("special grand opening incentives", "");
			html = html.replace("Coming soon! Join our", "Coming Soon").replace("coming in 2017", "").replaceAll("s - coming soon|a - coming soon", "")
					.replace("Coming soon!", "");//.replace("Coming Soon!", "");
			html = html.replaceAll("Pricing Coming Soon|image coming |all coming soon|Grand Opening Promotions|Currently selling from our|announce the grand opening|<p>\\s*Coming Soon!\\s*</p>", "");

			// html=html.replace("/assets/images/coming-soon.gif","/assets/images/ coming soon ");
			html = html.replace("Only 8 wooded homesites available", "Only 8 homesites available"); //.replace("New townhomes coming soon", "coming soon")
			html = html.replaceAll("coming soon in an outstanding New Kent County|Homes are currently sold |pool - coming soon|olleyball - coming soon|--coming-soon|<h4>Basement homesites available</h4>|coming soon\\.JPG |Sidewalk - coming soon|Pool - now open|selling townhomes|Supermarket - Now", "");
			//U.log(Util.match(html, ".*?coming soon.*"));
			html=html.replace("Large scenic and wooded homesites available", "Large and wooded homesites available")
					.replaceAll("<span class=\"u-home-status__text\">Coming Soon</span>", "")
					.replace("Basement homesites are available", "Basement homesites available")
					.replace("100% USDA financing is available", "100% USDA financing available");
			
			if(url.contains("charlotte/waxhaw/wrenn-creek"))html=html.replace("class=\"u-home-status__text\">Coming Soon</span>", "");
			if(url.contains("/woodleigh-park-at-lake-carolina"))html=html.replace("Homes coming soon", "");
			html=U.removeSectionValue(html, "<section id=\"related\">", "</html>");
//			String sts=U.getSectionValue(html, "<span class=\"u-home-status__text\">", To)
			
		

			
			// --prices---//
			html = html.replaceAll("0's|0’s", "0,000");//.replaceAll("<span>\\s+SOLD\\s+</span>\\s+</div>\\s+<div class=\"c-card-housing__tag-area--bottom\">\\s+<span class=\"c-card-housing__price-tag\">\\s+\\$\\d{3},\\d{3}\\s+</span>", "")
			html = html.replace("0s", "0,000").replace("price range of $400k-$500k", "price range of $400,000-$500,000");
			String[] price = U.getPrices(html,
					"from the mid $\\d{3},\\d{3}|price-tag\">\\$\\d,\\d{3},\\d{3}</span>|price-tag\">\\$\\d{3},\\{3}</span>|starting at \\$\\d{3},\\d{3}|price-tag\">\\$\\d{3},\\d{3}</span>|From the mid \\$\\d{3},\\d{3}|From the low \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|From the High \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
					0);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			if(url.contains("https://www.eastwoodhomes.com/charleston/moncks-corner/cooper-estates")) maxPrice=ALLOW_BLANK;
			if(url.contains("https://www.eastwoodhomes.com/greenville/easley/caledonia"))maxPrice="$360390";
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// -----------sqreft-----------//
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			html=html.replaceAll("\\+\n" + 
					"sq ft", "-sq ft").replaceAll("Starting at</span>(\\d{4})\\s+sq ft</span>", " $1 sq ft ");
			
			//U.log(Util.matchAll(html, "[\\w\\s\\W]{50}1480[\\w\\s\\W]{50}", 0));

			
			String[] sqft = U.getSqareFeet(html,
					" ranging from over \\d,\\d{3} sq. ft. to over \\d,\\d{3} sq. ft. |\\d{4} <span>sq\\s*ft</span>|\\d{4}-sq ft|>\\d+\\+ sq ft<|range in size from \\d,\\d{3} to over \\d,\\d{3} square feet|from \\d,\\d{3}&nbsp;to over \\d,\\d{3} square feet|Starting at\\s+</span>\\s+\\d{4}\\+ sq ft\\s+</span>|\\d,\\d+ to over \\d,\\d+ square feet |\\d,\\d+ to over \\d,\\d+ square feet|\\d,\\d{3} and \\d,\\d{3} square feet|Sq. Ft:\\s*</strong>\\s*\\d{4}\\+|Sq. Ft:\\s*</strong>\\s*\\d{4} |Sq. Ft:\\s*</strong>\\s*\\d,\\d{3}|\\d{1},\\d{3}-\\d{1},\\d{3} square ft.|from \\d,\\d{3} to \\d,\\d{3} square feet|from \\d,\\d{3} to \\d,\\d{3} sq ft|from \\d{4} to&nbsp;over \\d{4} square feet|Sq. Ft:\\s*\\d{4}|Sq. Ft:\\s*\\d{1},\\d{3}|\\d{1},\\d{3} sq.f|\\d{4} sq ft",
					0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			if(url.contains("https://www.eastwoodhomes.com/charleston/moncks-corner/cooper-estates")) {
//				minSqf=ALLOW_BLANK;
//				maxSqf=ALLOW_BLANK;
//			}
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			//------------------------ property status ------------------------
//			if(html.contains("More Homes Near You in")) {
//			U.getSectionValue(code, From, To)
		
//				String remHomeSecHtml=U.getSectionValue(html, "<h3 class=\"c-carousel-location-select__menu-title color--chathams\">", "</section>");
//				U.log(remHomeSecHtml);
//				if(remHomeSecHtml!=null) {
//					html=html.replace(remHomeSecHtml, "");					
//				}
////			}
			String commStatus = U.getPropStatus(U.getNoHtml(html.replaceAll("alt=\"Coming Soon\"|<span class=\"u-home-status__text\">\\s+Coming Soon\\s+</span>|Paved walking trail - now open|[M|m]ove-[I|i]n|New phase coming late Fall 2020|New homes ready now for| amenity center opening soon|Charlotte-area move|\"Coming|Soon!\"|ownhomes ready now|our single-family homes coming|\"closeout\":0|\"name\":\"Now Selling\"|Homes ready now for quick move-in", "")));
			//.replace("Finished Basement","Basement Homesite Available").replace("basement homesites offer", "Basement Homesite Available")
//			}
			html = html.replace("Move-In Ready (0)", "").replaceAll("Move-In Ready (\\d)", "Move-In Ready (3)");
			
//			U.log(">>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{30}financing[\\w\\s\\W]{30}", 0));
		
			if((!commStatus.contains("Move-in Ready") && Util.match(html, "<span class=\"c-tabs-homes__toggle__text\">\\s*Move-In Ready")!=null) && html.contains("<span class=\"c-tabs-homes__toggle__text\">Move-In Ready (3)</span>")) {//
				if(commStatus.length()<2)commStatus ="Move-in Ready Home";
				else commStatus=commStatus + ", Move-in Ready Home";
			}
			if(commStatus.equals("New Section Coming Soon, Coming Soon")) {
				commStatus = "New Section Coming Soon";
			}
			
			// ---notes-----//
			if(url.contains("neighborhood/glenmere"))commStatus="Coming Soon, "+commStatus;
			if(html.contains("<img src=\"/assets/images/coming-soon.gif\"") && !commStatus.contains("Coming")) {
				if (commStatus.length() < 3) commStatus = "Coming Soon";
				else commStatus =  "Coming Soon, "+commStatus;
			}
			
			if(url.contains("https://www.eastwoodhomes.com/greenville/greenville/harrington"))commStatus="New Phase Coming Soon";
			if(url.contains("https:/www.eastwoodhomes.com/charleston/charleston/landings-at-sweetwater"))commStatus =commStatus.replace("Coming Soon", "New Homesites Coming Soon") ;
			if(url.contains("https://www.eastwoodhomes.com/charlotte/charlotte/mckee-grove"))commStatus = "Coming Soon";
//			if(url.contains("https://www.eastwoodhomes.com/atlanta/canton/sunrise-cove-at-great-sky"))commStatus += ", Coming Soon";
/*			if(url.contains("https://www.eastwoodhomes.com/richmond/henrico/castleton")) {
				
				dpType = ALLOW_BLANK;
				minPrice = ALLOW_BLANK;
				minSqf = ALLOW_BLANK;
			}
*///			if(url1.contains("https://www.eastwoodhomes.com/charlotte/denver/rock-creek"))commStatus= "New Phase Coming Late Summer 2020";

			/*			if (data.communityUrlExists(url1)) {
				return;
			}*/
			//if(soldCount >= Integer.parseInt(moveCount))commStatus = commStatus.replaceAll(", Move-in Ready|Move-in Ready,|Move-in Ready", "");
			if(commStatus==null)commStatus=ALLOW_BLANK;
			communityName=communityName.replace(" - An Active Adult Community", "").replaceAll(" Paired Villas$| - An Age Restricted Community", "");
			U.log(mainHtm.contains("class=\"u-home-status__text\">Quick Move In") );
			if(!commStatus.contains("Move") &&html.contains("<section class=\"community-homes\" id=\"homes\">") && html.contains("<div class=\"c-card-featured-housing__card") && (mainHtm.contains(" class=\" \">Quick Move In") || mainHtm.contains("alt=\"Quick Move In\"")) ) {
				if(commStatus.length()<2) {
					commStatus ="Quick Move In";
				}
				else {
					commStatus=commStatus+", Quick Move In";
				}
			}
			if(commStatus.length()<3)
				commStatus = ALLOW_BLANK;
			commStatus = commStatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			
			//status formatting Aug27th21
			if(url.contains("/wesley-chapel/heritage"))commStatus = commStatus.replace("Coming Soon", "New Phase Coming Soon");
			url = url.replace("//", "/");
			if(url.contains("charlotte/matthews/mckee-grove"))commStatus ="Coming Soon, Only 16 Opportunities";
			
			
			
			data.addCommunity(communityName.replace("- Coming Soon!", ""), url, commType);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(propType, dpType);
			data.addPropertyStatus(commStatus);
			data.addNotes(U.getnote(html.replace("pre-sales are no longer available", "")));
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//		 }catch(Exception e){}
	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					Thread.sleep(10000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

	
}