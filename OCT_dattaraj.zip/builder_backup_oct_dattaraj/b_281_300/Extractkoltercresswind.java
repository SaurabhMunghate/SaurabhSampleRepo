package com.shatam.b_281_300;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class Extractkoltercresswind extends AbstractScrapper {
	static int i = 1;
	static String BASEURL = "http://www.cresswind.com";
	static String BASEURL2 = "https://www.kolterhomes.com";
	CommunityLogger LOGGER;
	int j = 0;
	
	
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new Extractkoltercresswind();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Kolter Residential - Cresswind.csv",
				a.data().printAll());
	}

	public Extractkoltercresswind() throws Exception {

		super("Kolter Residential - Cresswind", BASEURL);
		LOGGER = new CommunityLogger("Kolter Residential - Cresswind");
	}
	
	public void innerProcess() throws Exception {
		
		String html = U.getHTML("https://www.kolterhomes.com/maps/data.js?v=2&mtid=1&nmtid=0");
		HashMap<String, String []> communityData=preprocess(html);
		
		for(String commUrl : communityData.keySet()){
			U.log(commUrl);
			String commSec[]=communityData.get(commUrl);
			Matcher mat = Pattern.compile("\\$\\d{3}s",Pattern.CASE_INSENSITIVE).matcher(commSec[1]);
			while(mat.find()){
				String priceMatch = mat.group().replace("s", ",000");  //$230s
				commSec[1] = commSec[1].replace(mat.group(), priceMatch);
			}
			findCommunityDetails(commUrl,commSec);
//			U.log(commUrl);
		}
	//	U.log(U.getCache(BASEURL));
		LOGGER.DisposeLogger();
	}
	private HashMap<String, String[]> preprocess(String html) {
		HashMap<String, String[]>communitydata=new HashMap<>();
		String commNamesSec=U.getSectionValue(html, "\"COMMUNITYNAME\":[", "]");
		String commNames[]=commNamesSec.split("\",\"");
		String commDescSec=U.getSectionValue(html, "\"LISTDESCRIPTION\":[", "]");
		String commDescs[]=commDescSec.split("\",\"");
		String commAddressSec=U.getSectionValue(html, "\"ADDRESS1\":[", "]");
//		U.log(commAddressSec);
		String commAddresss[]=commAddressSec.split("\",\"");
		String commCitiesSec=U.getSectionValue(html, "\"CITYNAME\":[", "]");
//		U.log(commCitiesSec);
		String commCitys[]=commCitiesSec.replace("null,", "\"\",").split("\",\"");
		String commStatesSec=U.getSectionValue(html, "\"STATEABB\":[", "]");
		String commStates[]=commStatesSec.split("\",\"");
		String commZipsSec=U.getSectionValue(html, "\"ZIPCODE\":[", "]");
		String commZips[]=commZipsSec.split("\",\"");
		String commUrlsSec=U.getSectionValue(html, "\"COMMUNITYSLUG\":[", "]");
		String commUrlss[]=commUrlsSec.split("\",\"");
		String commLatsSec=U.getSectionValue(html, "\"LAT\":[", "]");
		String commLatss[]=commLatsSec.split(",");
		String commLonsSec=U.getSectionValue(html, "\"LON\":[", "]");
		String commLons[]=commLonsSec.split(",");
		String commCommTypeSec=U.getSectionValue(html, "\"MAPTYPE\":[", "]");
		String commCommTypes[]=commCommTypeSec.split("\",\"");
		U.log(commNames.length+" == "+commDescs.length+" == "+commAddresss.length+" == "+commCitys.length+" == "+commStates.length+" == "+commZips.length+" == "+commUrlss.length+" == "+commLatss.length+" == "+commLons.length+" == "+commCommTypes.length);
		for (int i = 0; i < commUrlss.length; i++) {
			String commData[]=new String[9];
			commData[0]=commNames[i].replace("\"", "");
			commData[1]=commDescs[i].replace("\"", "");
			commData[2]=commAddresss[i].replace("\"", "");
			commData[3]=commCitys[i].replace("\"", "");
			commData[4]=commStates[i].replace("\"", "");
			commData[5]=commZips[i].replace("\"", "");
			commData[6]=commLatss[i].replace("\"", "");
			commData[7]=commLons[i].replace("\"", "");
			commData[8]=commCommTypes[i].replace("\"", "");
//			U.log(Arrays.toString(commData[i]));
			communitydata.put("https://www.kolterhomes.com/new-homes/"+commUrlss[i].replace("\"", ""), commData);
		}
		return communitydata;
	}

	private void findCommunityDetails(String commUrl,String commSec[])throws Exception{
		//if(j == 7)
		{
			U.log("Count :: "+j);
			U.log(commUrl);			
			if (data.communityUrlExists(commUrl)){
				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
				return;
			}
			if (commUrl.contains("https://www.kolterhomes.com/new-homes/peachtree-city-georgia-active-adult-cresswind-peachtree-city")) {
				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------extra");
				return;
			}
//			if(!commUrl.contains("https://www.kolterhomes.com/new-homes/sarasota-bradenton-cresswind-lakewood-ranch"))return;
			
			String html = U.getHTMLwithProxy(commUrl);
		
			
			//========== Community Name ====================
			String communityName = commSec[0];
			communityName = communityName.replaceAll("\\s{2,}", "");
			U.log("commName::"+communityName);
			
			//============== Notes ==============
			String note = U.getnote(html);
			
			//================ Address ======================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String directionSec = U.getSectionValue(html,"<li id=\"directions\"", "<span>");
			String directionHtml = ALLOW_BLANK;
			if(directionSec != null)directionHtml = U.getHTML(BASEURL2+U.getSectionValue(directionSec, "<a href=\"", "\""));
				
			String addSec = U.getSectionValue(directionHtml, "<address>","</address>");
			if(addSec != null){
				addSec = addSec.replaceAll("\\s{2,}", "").replace("<br />", ",").replace("<br/>", ",");
				U.log(addSec);
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}
			
			//================== LatLng Section ====================
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String geo = "False";
			String latLngSec = U.getSectionValue(directionHtml, "div id=\"map_canvas\">", "</a>");
			if(latLngSec != null){
			String latLngVal = U.getSectionValue(latLngSec, "@", "/");
			U.log(latLngVal);
				if(latLngVal != null){
					String val[] = latLngVal.split(",");
					lat = val[0];
					lng = val[1];
				}else{
					lat = U.getSectionValue(directionHtml, "lat:parseFloat(\"", "\"");
					lng = U.getSectionValue(directionHtml, "lon:parseFloat(\"", "\"");
				}
			}
			//U.log(commSec);
			U.log("Lat::"+lat+"\tLng::"+lng);
			if(lat != ALLOW_BLANK && lng != ALLOW_BLANK){
				if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
					String [] latLong = {lat,lng};
					add = U.getAddressGoogleApi(latLong);
					geo = "True";
				}
			}
			if(lat.length()<4 && add[0].length()<4){
				add[1] = commSec[3];
				add[2] = commSec[4];
				U.log("city : "+add[1] + "\t state : "+add[2]);
				String[] latLng = U.getlatlongGoogleApi(add);
				lat = latLng[0];
				lng = latLng[1];
				add = U.getAddressGoogleApi(latLng);
				geo ="TRUE";
				note = "Address And Lat-Lng Taken Using City And State";
			}
			
			//=========== Quick Homes =========================
			String quickHomeSec = U.getSectionValue(html, "<li id=\"move-in-ready\"", "<span>");
			String quickHomeHtml = null;
			
			if(quickHomeSec != null){
				U.log("Quick Url::"+BASEURL2+U.getSectionValue(quickHomeSec, "<a href=\"", "\""));
				quickHomeHtml = U.getHTMLwithProxy(BASEURL2+U.getSectionValue(quickHomeSec, "<a href=\"", "\""));
			}
				
			U.log(quickHomeHtml);
			//String combinedQuickHtml = null;
			String quickUrls [] = {};
			if(quickHomeHtml != null){
				String quickSection = U.getSectionValue(quickHomeHtml, "Move-In Ready Homes</h1>", "</section>");
				U.log(quickSection);
				if(quickSection!=null)quickUrls = U.getValues(quickSection, "<a href=\"", "\"");
				if(commUrl.contains("/fort-myers-florida-active-adult-verandah/")) {
					if(quickSection!=null)quickUrls = U.getValues(quickSection, "<a href=\"/new-homes/", "\"");
					for(String url:quickUrls) {
						U.log("https://www.kolterhomes.com/new-homes/"+url);
						quickHomeHtml+=U.getHTMLwithProxy("https://www.kolterhomes.com/new-homes/"+url);
						U.log(quickHomeHtml.contains("Stories"));
						quickHomeHtml=quickHomeHtml.replace("Stories</th> <td>", "story");
					}
				}
			}
			
			
			
			//============ Model Homes ===========================
			
			String	homeHtml= U.getHTMLwithProxy(BASEURL2+U.getSectionValue(html, "id=\"homes\" class=\"\"> <a href=\"", "\""));
			
		//	U.log("modelHomeUrls : " +BASEURL2+U.getSectionValue(homeSec, "<a href=\"", "\""));
			String combinedHomeHtml = null;
			if(homeHtml != null){
				//String homeSection = U.getSectionValue(homeHtml, "Homes</h1>", "</section>");
				//U.log("=="+homeSection);
				ArrayList<String> homeUrls = Util.matchAll(homeHtml, "data-ifp=\"\\d\"> <a href=\"(.*?)\"", 1);//U.getValues(homeHtml, " data-ifp=\"0\"> <a href=\"", "\" title=\"");
				U.log(homeUrls.size());
				for(String homeUrl : homeUrls)
				{
					U.log("homeUrl : "+homeUrl);
					combinedHomeHtml += U.getHTMLwithProxy(BASEURL2+homeUrl);
					if (combinedHomeHtml.contains("duplex")) {
						U.log("Found");
					}
				}
			}
			
			//================= Feature ===========================
			String featureSec = U.getSectionValue(html, "<li id=\"features", "<span>");
			String featureHtml = null;
			U.log(featureSec);
			if(featureSec != null){
				featureHtml = U.getHTMLwithProxy(BASEURL2+U.getSectionValue(featureSec, "<a href=\"", "\""));
//				U.log("hererere"+featureHtml.contains("luxury"));
				if (featureHtml!=null && featureHtml.contains("HOA")) {
					U.log("Found");
				}
				featureHtml=featureHtml.replace("Estate Home Features", "Estate-style homes Features").replaceAll("any luxury home", "luxurious lifestyle");
			}
//			if (!commUrl.contains("https://www.kolterhomes.com/new-homes/fort-myers-florida-active-adult-verandah/")) {
//				featureHtml=null;
//			}
			//================== SQFT ====================
			String maxSqf = ALLOW_BLANK, minSqf = ALLOW_BLANK;
			String sqft[] = U.getSqareFeet(quickHomeHtml+homeHtml,
							"\\d,\\d{3} Total Sq. Ft.",
							0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			//================ Price =====================
			Matcher mat = Pattern.compile("\\$\\d{3}s",Pattern.CASE_INSENSITIVE).matcher(html);
			while(mat.find()){
				String priceMatch = mat.group().replace("s", ",000");  //$230s
				html = html.replace(mat.group(), priceMatch);
			}
			U.log(commSec);
			if(quickHomeHtml!=null)
			quickHomeHtml=quickHomeHtml.replace("$700s", "$700,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String price[] = U.getPrices(quickHomeHtml+homeHtml+html+commSec[1],
					"From \\$\\d{3},\\d{3}|\\$\\d+,\\d+|\\$\\d+,\\d+MyPrice", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//			U.log(Util.matchAll(quickHomeHtml+homeHtml+html, "[\\w\\s\\W]{50}\\$400,\\d{3}[\\w\\s\\W]{30}",0));
			U.log("minPrice::"+minPrice+"\tmaxPrice::"+maxPrice);
			//=============== Community Type =================
			html = html.replace("55&#x2b;", "55+").replaceAll("55 Plus Community", "55 and greater.");
			String communityType = U.getCommunityType(html+commSec[1]+commSec[8]);
			U.log("CType::"+communityType);
			//U.log(html);
			//============== Property Type =============
			U.log(Util.matchAll(html, "[\\w\\s\\W]{30}New Phase Release[\\w\\s\\W]{30}", 0));
			html =  html.replace("No HOA for", "").replaceAll("NEW PHASE Release - New Homesites available</h2|<h2 class=\"headerContentAd \">New Phase Release- New homesites available</h2>", "");
			
			String propertyType = U.getPropType((html.replace(" leisure and luxury", " leisure and luxury homes")+quickHomeHtml+homeHtml+featureHtml).replaceAll("townhomes-|townhouse|village|Village|lorida townhomes with elevator|townhome[s]*,",""));
			U.log("PType::"+propertyType);
			
			//============== Property Status ==========
			html = html.replaceAll("Quick Delivery|id=\"fontSizeFP\">NEW PHASE Release - New Homesites available</h2|NOW UNDER CONSTRUCTION OPENING 2019|lawn : Coming Summer 2019", "");
			commSec[1] = commSec[1].replace("Opening in 2017 - register now f", "");
			//U.log(commSec);
			String propertStatus = U.getPropStatus((html.replace("New Phase</strong> Coming this spring 2019", "New Phase Coming this spring 2019").replaceAll("event lawn : Coming Spring 2019|full video coming soon.|on select Move-In Ready|Now Open|NOW OPEN|Limited-Time Special for Move-In Ready|<span>Move-In Ready</span>| Move-In Ready Homes </a> </li>|<mark>COMING IN&nbsp;2018:</mark>&nbsp; Cresswind&nbsp;neighbors also can access the new| This is a limited time offer, please call to schedule.", "")+commSec[1]).replace("- Opening Spring 2019",""));
			if(quickUrls.length > 0){
				if(propertStatus != ALLOW_BLANK)
					propertStatus += ", Move-In Ready Homes";
				if(propertStatus == ALLOW_BLANK)
					propertStatus = "Move-In Ready Homes";
			}
			
			//============== Derived Community Type ==========
			
			if(combinedHomeHtml != null)
			{
				combinedHomeHtml = combinedHomeHtml.replaceAll("<th>Stories</th>\\s*<td>", " Stories ").replaceAll("\"></div> 19-Story|Ocean&#x20;19-Story", "");
			}
				
			//U.log(combinedHomeHtml);
			html=html.replace("three-story clubhouse","");
			String dType = U.getdCommType((featureHtml+quickHomeHtml+homeHtml+html+combinedHomeHtml).replaceAll("2nd Floor|Second Floor|41-Story|46-Story|Lakewood Ranch|lakewood-ranch", ""));
			U.log("Dtype::"+dType);
			//U.log("result::::::::::::::"+Util.match(html, ".*?Opening .*?"));
			if(commUrl.contains("fort-myers-florida-active-adult-verandah/"))dType="1 Story";
			propertStatus=propertStatus.replaceAll("Move-in Ready,Move-In Ready Homes", "Move-In Ready Homes");
			propertStatus=propertStatus.replaceAll("Move-in Ready Homes,Move-In Ready Homes", "Move-In Ready Homes");
			propertStatus=propertStatus.replaceAll("Phase Ii Coming Soon", "Phase II Coming Soon").replace("New Phase Coming This Spring 2019", "New Phase Coming Spring 2019");
			
			LOGGER.AddCommunityUrl(commUrl);
			data.addCommunity(communityName, commUrl, communityType.replace("55\\+", "55+"));
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(propertyType, dType);
			data.addPropertyStatus(propertStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			
		}
		j++;
	}
	public void addDetails(String url, String commName, String info, String communitytype, String propstatus,String addsec1) throws Exception {
	//if (!url.contains("https://www.kolterhomes.com/new-homes/fort-myers-florida-active-adult-verandah/")) return;
//		 8
		 
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK, minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		String geo = "False";
		String html = U.getHTML(url);

		String dtype = ALLOW_BLANK;
		// U.log(dtype);
		String drop = U.getSectionValue(html, "</style>", " </div> <script>");
		// html=html.replace(drop, " ");
		String proptype = ALLOW_BLANK;
		String secCommType = U.getSectionValue(html, "Request Information</a>", "Connect:");
		if(secCommType==null)
	secCommType = U.getSectionValue(html, "Arial, sans-serif; line-height: 1.4em;\">", "</span></p> <p class=\"defaultfont\" align=\"center\" style=\"margin: 0in 0in 8pt;");
		//U.log("=================================>"+secCommType);
		String proType = U.getSectionValue(html,
				"</h1> <div><span style=\"font-size: small;\">",
				"type=\"text/javascript\">");
		if (proType == null)
			proType = ALLOW_BLANK;
		if (secCommType == null)
			secCommType = ALLOW_BLANK;
		
		html=html.replace("three-story clubhouse","");
		html = html.replaceAll("3-story|</div> 41\\-Story Iconic Downtown|19-Story|41-Story", "");
		
	//	 U.log(html);
		dtype = U.getdCommType(html.replace("Seabranch", ""));
		U.log(dtype);
		U.log(url + "================" + "======" + i);

		String []add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String address1[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		// U.log(add[3]);
		String url1 = url + "directions/";
		U.log(url + "#########");
		String addhtml = U.getHTML(url1);
		String addsec=ALLOW_BLANK;
		if(addhtml!=null)
		 addsec = U.getSectionValue(addhtml, "address : ", "};");
		U.log(addsec);
		if(addsec!=null)
		address1 = addsec.split(",");
		// U.log(add[3]);
		U.log(Arrays.toString(address1) + "&&&&&");
		U.log(address1[2]);
		add[0] = address1[0];
		add[1] = address1[1];

		add[3] = Util.match(address1[2], "[0-9]{5}");
		if (add[3] == null) {
			if(addhtml.contains("lat : parseFloat("))
			{
			String latsec = U.getSectionValue(addhtml, "lat : parseFloat('",
					"')").trim();
			String lngsec = U.getSectionValue(addhtml, "lon : parseFloat('",
					"')").trim();
			String latlong[] = { latsec, lngsec };
			U.log(Arrays.toString(latlong));
			add = U.getAddressGoogleApi(latlong);
			}
		}
		// U.log(address1[3]);
		if(address1[2]!=null && add[3]!=null)
		add[2] = address1[2].replace(add[3], "");
		U.log(Arrays.toString(add));

		String address_section = U.getSectionValue(html,
				"<span>Community</span>", "id=\"models\"");
		U.log(address_section);

		String addresshtml = null, pricesefthtml = null;

		String dir_mod[] = U.getValues(address_section, "<a href=\"",
				"\" id=\"directions\"");
		for (String dm : dir_mod) {
			U.log(dm);
			if (dm.contains("directions")) {
				addresshtml = U.getHTML(BASEURL2 + dm);
				U.log(">>>>>>>>>" + BASEURL2 + dm);

			} else if (dm.contains("models")) {
				// pricesefthtml = U.getHTML(BASEURL2 + dm);
				// U.log(">>>>>>>>>"+BASEURL2+dm);
			}
		}

		
		U.log(url + "^^^^^^^^^^^");
		String csec1=U.getSectionValue(html,"</center><center><b ", "</div> </div> </div> </div>");
		String aminity=U.getHTML(url+"lifestyle/");
		String feature=U.getHTML(url+"features/");
		String feature1=U.getSectionValue(feature,"</div> <div> <h1 class", "<div id=\"footer\"> <div");
		String aminity1=U.getSectionValue(aminity,"Amenity Siteplan</a>", "</span></p> <p></p>");
		String ctype = U.getCommunityType(secCommType+csec1+aminity1+feature1);
		proptype = U.getPropType(secCommType+csec1+aminity1+feature1+"single family");
		
		pricesefthtml = U.getHTML(url + "models/");
		info = info.replace("0s", "0,000MyPrice");
		U.log("My Info:  " + info);
		String price[] = U.getPrices(pricesefthtml + info,
				"\\$\\d+,\\d+|\\$\\d+,\\d+MyPrice", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		if (add[2].length() > 4)
			add[2] = USStates.abbr(add[2]);
		if (add[0].length() > 3) {

			latLng = U.getlatlongGoogleApi(add);

			geo = "false";
			// 31.000968

			if (latLng[0].contains("31.000968")
					|| latLng[0].equals("33.791703")
					|| latLng[0].contains("33.791703")
					|| latLng[0].equals("90")
					|| latLng[0].contains("27.6648274"))
			{
				latLng[0] = ALLOW_BLANK;
				latLng[1] = ALLOW_BLANK;
			}

			if (latLng[0] == ALLOW_BLANK && add[0] != ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}

			U.log(latLng[0]);
			U.log(latLng[1]);

			add[2] = add[2].trim();
		}
		U.log("#############" + pricesefthtml);
		String sqft[] = U
				.getSqareFeet(
						pricesefthtml,
						"</div> </td> <td class=\"text-center\">[0-9]{1},[0-9]{3}</td>",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		propstatus = U.getPropStatus(html);
		
		if (url.contains("http://www.kolterhomes.com/communities/49/cresswind-peachtree-city/")) {
			if (latLng[0] == ALLOW_BLANK) {

				latLng[0] = "33.431302";
				latLng[1] = "-84.617266";
				add = U.getAddressGoogleApi(latLng);
				geo = "TRUE";
			}

		}
		if (url.contains("http://www.kolterhomes.com/communities/9/verano/")) {

			if (latLng[0].contains("31.000968")) {
				latLng[0] = ALLOW_BLANK;
				latLng[1] = ALLOW_BLANK;
			}
			// 27.325834, -80.421525
			if (latLng[0] == ALLOW_BLANK) {

				latLng[0] = "27.325834";
				latLng[1] = "-80.421525";
				add = U.getAddressGoogleApi(latLng);
				geo = "TRUE";
			}

		}
		if(url.contains("http://www.kolterhomes.com/new-homes/peachtree-city-georgia-active-adult-cresswind-peachtree-city/"))
		{
			proptype="Luxury Homes";
			geo = "TRUE";
		}

		U.log(latLng[0]+" "+latLng[1]);
		if (add[0].length() < 3 && latLng[0]!=ALLOW_BLANK)
			{add = U.getAddressGoogleApi(latLng);
		geo="True";}
		if (add[3] == null)
			add[3] = ALLOW_BLANK;
		html = html.replaceAll("New Luxury Residences from \\$2 Million Coming Soon|&#x7c; New Homes Coming Soon|COMING SOON: New Cresswind Active Adult Community in Peachtree City|New Luxury Residences from $2 Million Coming Soon|th_Grand Opening Clubhouse|Ultra-Modern Design Coming Soon|COMING SOON: true Sarasota|Community coming soon to Peachtree City", "");
		if(add[0].length()<3)
		{
			 String[] add2=addsec1.split(",");
			 add[1]=add2[0];
			 add[2]=add2[1];
			 latLng=U.getlatlongGoogleApi(add);
			 add=U.getAddressGoogleApi(latLng);
			 geo="TRUE";
		}
		
		if(addhtml!=null)
		{
			String a=U.getSectionValue(addhtml, "address:\"","\"}");
			if(a.length()>35)
			{
			add[0]=U.getSectionValue(addhtml, "address:\"",",");
			add[0]=add[0].replace(add[1], "");
			geo="FALSE";
			}
			latLng[0]=U.getSectionValue(addhtml,"lat:parseFloat(\"", "\")");
			latLng[1]=U.getSectionValue(addhtml,"lon:parseFloat(\"", "\")");
			
		}
		
		if(url.contains("http://www.kolterhomes.com/new-homes/fort-myers-florida-active-adult-verandah/"))
			proptype=proptype.replace(",Patio Homes","");
		html=html.replace("<span>Quick Delivery</span>", "Quick Delivery Home").replaceAll("on select Move-In Ready|Now Open|NOW OPEN|now open|Limited-Time Special for Move-In Ready|WC3 JUST Released|lawn : Coming Summer 2019", "");
		
		String pStatus=U.getPropStatus(html);
		U.log(pStatus);
		pStatus=pStatus.replaceAll("Move-in Ready,Move-In Ready Homes", "Move-In Ready Homes");
		pStatus=pStatus.replaceAll("Move-in Ready Homes,Move-In Ready Homes", "Move-In Ready Homes");
		pStatus=pStatus.replaceAll("Phase Ii Coming Soon", "Phase II Coming Soon");
		
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(commName, url, ctype.replace("55\\+", "55+"));
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(html + info));

	}
}
