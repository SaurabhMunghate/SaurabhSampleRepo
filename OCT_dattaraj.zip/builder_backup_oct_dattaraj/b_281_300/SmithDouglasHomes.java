/*
 * new code by Upendra
 */
package com.shatam.b_281_300;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import javax.swing.text.DefaultEditorKit.PasteAction;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class SmithDouglasHomes extends AbstractScrapper {
	public static int k = 0;
	public int inr = 0;
	static int j = 0;
	static String Builder_name = "Smith Douglas Homes";
	static String HOME_URL = "https://smithdouglas.com";
	CommunityLogger LOGGER;
	WebDriver driver = null;
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new SmithDouglasHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Smith Douglas Homes.csv", a.data().printAll());
		U.log("Repete:-->"+k);
	}

	public SmithDouglasHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger("Smith Douglas Homes");

	}

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String html = U.getHTML("https://smithdouglas.com/");
		String regSection = U.getSectionValue(html, ">Find a Home<span", "</ul>");
//		U.log(regSection);
		String [] regUrls = U.getValues(regSection, "href=\"", "\"");
		U.log(regUrls.length);
		for(String regUrl : regUrls){
			U.log("regUrl==="+regUrl);
			//U.log(U.getCache("https://smithdouglas.com"+regUrl));
			String regHtml  = U.getHtml("https://smithdouglas.com"+regUrl,driver);
			String [] comSections = {};
			if(!regUrl.contains("/find-a-home/charlotte/")){
				comSections = U.getValues(regHtml, "<div id=\"card_header_comm_", "View Community");
				U.log(comSections.length);
				for(String comSec : comSections){
					String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
					adDetails("https://smithdouglas.com"+comUrl, comSec);
				}
			}else{
				comSections = U.getValues(regHtml, "<div id=\"card_header_comm_", "View Community");
				U.log(comSections.length);
				for(String comSec : comSections){
					String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
					adDetails("https://smithdouglas.com"+comUrl, comSec);
				}
			}
		}
		String comSections[] = U.getValues(U.getHTML("https://smithdouglas.com/find-a-home/dalton/"), "<div id=\"card_header_comm_", "View Community");
		U.log(comSections.length);
		for(String comSec : comSections){
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
		adDetails("https://smithdouglas.com"+comUrl, comSec);
		}
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	//TODO :
	public void adDetails(String comUrl,String comData) throws Exception {
//	if(!comUrl.contains("https://smithdouglas.com/nashville-communities/Honey-Run-Springs-166092"))return;
	
	//try{
//	if(j == 36)
//		if(j >= 76)
	{
		
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+" ============ Repeat ");
			k++;
			return;
		}
		if(comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/collington/")) {
			LOGGER.AddCommunityUrl(comUrl+" ============ Repeated in 2 regions ");
			k++;
			return;
		}
		
		if(comUrl.contains("raleigh-communities/Settlers-Pointe-151075")) {
			LOGGER.AddCommunityUrl(comUrl+" ============ Page Not Found");
			k++;
			return;
		}
		
		
		
		LOGGER.AddCommunityUrl(comUrl);
//	U.log(comData);
	U.log(j+"   commUrl-->"+comUrl);
	String html1=U.getHtml(comUrl,driver);
	String html=U.getSectionValue(html1, "<title>", "Quick Links</span>");
	 
	
	
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "card_link\"=\"\">","</span>");
		communityName = communityName.replace("Carter???s", "Carter's").replace("at the Country Club", "").replaceAll("Villas$", "");
		if(communityName.endsWith("Townhomes"))communityName = communityName.replace("Townhomes", "").replaceAll("Estates|estates", "").replaceAll("Manor|manor", "");
		if(communityName.endsWith("Manor")) communityName = communityName.replaceAll("Manor|manor", "");
		if(communityName.endsWith("Estates")) communityName = communityName.replaceAll("Estates|estates", "");
				
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		html = html.replace("Pre-Grand Opening Pricing is NOW AVAILABLE", "Pre-Grand Opening Pricing").replace("pre-sell opportunities late Fall 2021", "Pre sell late Fall 2021")
				.replaceAll("PRESALES BEGINNING END OF SUMMER|Pre-Sales for New Construction is Anticipated|Pre-Sales for new construction is anticipated ", "");
		comData=comData.replaceAll("PRESALES BEGINNING END OF SUMMER|Pre-Sales for New Construction is Anticipated|Pre-Sales for new construction is anticipated ", "");
		String note=U.getnote((comData+ html).replace("Pre-Selling Late 2022", "Pre-Selling 2022").replaceAll("Pre-Sales for New Construction is Anticipated|advantage of pre-sale opportunities|Pre-sales are expected to begin this Spring|Presales expected to begin this Spring", "").replaceAll("PRE-GRAND OPENING INCENTIVE|content=\"Now pre-selling|is NOW AVAILABLE and sales will start in|inventory homes and pre-sale opportunities|kept informed of pre-sale opportunities", ""));
		U.log("Note:: "+note);//                                                              (Presales begin this Spring)
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}Pre-selling[\\w\\s\\W]{50}", 0));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comData, "[\\w\\s\\W]{30}Pre-selling[\\w\\s\\W]{50}", 0));

		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
	
		
		
		
		String addSec=U.getSectionValue(html, "<span class=\"address-text\">","</a>");
//		if(addSec==null) {
//			addSec=U.getSectionValue(html, From, To)
//		}
//		if(addSec==null)
//			addSec = U.getSectionValue(html, "<div class=\"salesAddress blockBorder\">", "</a>");
		
		if(addSec!=null)addSec = addSec.replace("Sales Office<br />","");
		if( comUrl.contains("/Honey-Run-Springs-166092")||
				comUrl.contains("/Settlers-Pointe-151075"))
			addSec =U.getSectionValue(html,"<span class=\"address-text city-state-info\">","</span>");
		U.log("addSec==="+addSec);
		if(addSec!=null)
		{
			addSec=addSec.replace("White House, TN 37188", "Emmett Drive, White House, TN 37188");
//			add[0]=U.getSectionValue(addSec, "<span class=\"addressStreet\">","</span>");
//			
//			if(add[0] != null && add[0].contains("1002 Thornton Branch Harvest AL 35749")) {
//				add[0] = "1002 Thornton Branch";
//			}
//			
//			add[1]=U.getSectionValue(addSec, "<span class=\"addressCity\">","</span>");
//			add[2]=U.getSectionValue(addSec, "<span class=\"addressState\">","</span>");
//			add[3]=U.getSectionValue(addSec, "<span class=\"addressZipCode\">","</span>");
			
			addSec=U.getNoHtml(addSec).trim();
			add=U.getAddress(addSec);
			

		}
		
		
		if(add[0] != null){
			add[0] = add[0].replaceAll("\\(.*?\\)", "")
					.replaceAll(" Benson NC| Four Oaks NC| Smithfield NC 27577|. Montevallo AL|Zebulon NC|Sanford NC|Coming Soon!", "")
					.replaceAll("Intersection Of Hwy 70 And Hwy 26 AL", "Intersection Of Hwy 70 And Hwy 26")
					.replace("Leeds AL", ALLOW_BLANK);
			add[0]=add[0].replaceAll("Raleigh 27603|Cramerton| NC|Call Agent in River Park for Appointment.|Located at the Intersection of|Contact Agent for Info| Call Agent for Appointment","");
			add[0] = add[0].replace("500 Crantock Rd Smithfield NC 27577", "500 Crantock Rd").trim();
			add[0] = add[0].replaceAll("GPS:|Benson NC$| Four Oaks NC$", "");
			//add[0]=add[0].replace("From I-65 North", "");
					
		}
		if(add[0]==null && html.contains("<div class=\"builderDirectionsText")) {
			addSec =U.getSectionValue(html, "<div class=\"builderDirectionsText bdxRTEWrapper\">", "div>\n" + 
					"");
			String tempAddSec=U.getSectionValue(addSec, "For GPS, use ", "</");		
			if(addSec!=null) {
				addSec=addSec.replace("Use GPS Address ", "")
						.replaceAll("From I-459|From 431 N, past Meridianville", "");
				
				String tempad[] = U.getAddress(addSec);
				add[0]=tempad[0];
				if(add[0].length() > 100) add[0] = ALLOW_BLANK;
				U.log(add[0]);
			}
			
			if(tempAddSec!=null&& (add[0]==ALLOW_BLANK || add[0]==null)) {
				add=U.getAddress(tempAddSec);
			}
		}
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		add[0]=add[0].replace("From I-65 North, take exit 108 for TN-76 toward Springfield","");
		add[0]=add[0].replace("2815 Parkwest Drive Sales Office is at our Locust Town Center Model", "");
//--------------------------------------------------latlng----------------------------------------------------------------
		String latlngSec=U.getSectionValue(comData, "https://www.google.com/maps?z=18&amp;q", "\">");
		if(latlngSec!=null) {
			latlag[0]=Util.match(latlngSec, "=\\d{2}.\\d{1}\\d+").replace("=", "");
			latlag[1]=Util.match(latlngSec, "-\\d{2}.\\d{1}\\d+");
		}
		
//			latlag[0]=U.getSectionValue(comData,"data-latitude=\"","\"");
//			latlag[1]=U.getSectionValue(comData,"data-longitude=\"","\"");
		
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=null && (latlag[0]==ALLOW_BLANK || latlag[0]==null))
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if((add[0]==null || add[3]==null) && latlag[0]!=null)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(add[0].length()<4 && latlag[0]!=null)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		
//============================================Price and SQ.FT======================================================================
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String rem1=U.getSectionValue(html, "<meta name=\"description", "/>");
		if(rem1!=null) {
			html=html.replace(rem1, "");
		}
		html=html.replaceAll("0s|0s|0's|0&#8217;s|0s|0&rsquo;s|0k's|0k|0’s","0,000").replace("$1 million","$1,000,000");
		comData=comData.replaceAll("0s|0&#8217;s|0s|0's","0,000");
		String prices[] = U.getPrices(html+comData,
				"low-\\$\\d{3},\\d{3}|Mid-\\$\\d{3},\\d{3}|high-\\$\\d{3},\\d{3}|from High \\$\\d{3},\\d{3}|mid-to-high \\d{3},\\d{3}|dealPrice\">\\$\\d{3},\\d{3}</span>|Priced from \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d+|Priced at \\$\\d{3},\\d+|(low|mid)* \\$\\d{3},\\d+|the mid \\d{3},\\d{3}|upper-\\$\\d{3},\\d{3}", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		String[] sqft = U
				.getSqareFeet(
						html+comData,
						"from \\d,\\d{3}sf to \\d,\\d{3}sf|ranging from \\d,\\d{3} to \\d,\\d{3} sq.ft|ranging from \\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d{3} up to \\d,\\d{3} square feet|from \\d{1},\\d{3}-\\d{1},\\d{3} sq. ft|\\d{1},\\d+ - \\d{1},\\d+ Sq. Ft.|\\d{1},\\d+ Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} sf",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		String aminitySec = U.getSectionValue(html, "<h3>Local Area Amenities</h3", "</ul");
		//U.log("aminitySec: "+aminitySec);
		String rem=U.getSectionValue(html, "<div class=\"sub_footer\">","</body>");
		if(rem!=null)
		{
		html=html.replace(rem,"");
		}
		if(aminitySec!=null)
		aminitySec = aminitySec.replace("Golf &amp; Country Club", "Golf & Country Club").replaceAll("CommunityTypeAdult\">Adult", "Active Adult");
		String animSec = U.getSectionValue(html, " <div class=\"amenityWrapper communities", "<div class=\"topRight\">");
		 String communityType=ALLOW_BLANK;
		 if(animSec!=null)
           communityType=U.getCommType((html+comData+aminitySec).replace(animSec, "").replaceAll("COUNTRY CLUB DR | Country Club Dr", ""));
		 else
	           communityType=U.getCommType((html+comData+aminitySec).replaceAll("COUNTRY CLUB DR | Country Club Dr", ""));
 
//====================== Home Section =========================
		String [] homeSection = U.getValues(html, "<div id=\"card_titles_plan_", "View Plan");
		String combinedHomeHtml = null;
		U.log("Home Count=: "+homeSection.length);
		int x = 0;
		for(String homeSec : homeSection){
			String homeUrl = U.getSectionValue(homeSec, "<a href=\"", "\"");
			//U.log(homeUrl);
			combinedHomeHtml += U.getHTML(HOME_URL+homeUrl);
//			if(x == 5)break;
//			x++;
		}
//=============== Quick Home Section =========================
		int quickCount = 0;
		String quickHomeSec = U.getSectionValue(html, "Quick Move-in Homes</h3>", "</ul>");
		if(quickHomeSec != null){
			String [] quickHomeUrlSec = U.getValues(quickHomeSec, "<h3 class=\"xCommunityNameHeader\">", "</a>");
			U.log("Quick Home count=: "+quickHomeUrlSec.length);
			quickCount = quickHomeUrlSec.length;
		}
//====================================Property Type================================================
		if(comData==null) {
			comData=ALLOW_BLANK;
		}
		if(combinedHomeHtml==null) {
			combinedHomeHtml=ALLOW_BLANK;
		}
		html = html.replace(" luxury of being close to major roadways", "luxury homes").replaceAll("Description\">\\s+Traditional", "Traditional Homes").replaceAll("Description\">\\s+Craftsman|craftsman-style housing", "Craftsman Style Homes");
		String proptype=U.getPropType((U.getNoHtml(html)+U.getNoHtml(comData)+U.getNoHtml(combinedHomeHtml)).replace("Unexpected luxuries", "luxury homes").replaceAll("Colonial\\+Drive|title=\"Arizona Luxury Homes\"|Colonial Drive|participation|HOA and other fees not included.|Village|village", ""));
		proptype = proptype.replace("Townhouse,Single Family,Townhomes", "Single Family,Townhomes");
		if(proptype.contains("Townhome") && proptype.contains("Townhouse"))
			proptype = proptype.replaceAll(",Townhouse|Townhouse,", "");
		
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(combinedHomeHtml, "[\\w\\s\\W]{30}Condo[\\w\\s\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(combinedHomeHtml, "[\\w\\s\\W]{30}Multi Family[\\w\\s\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(combinedHomeHtml, "[\\w\\s\\W]{30}craftsman[\\w\\s\\W]{30}", 0));

		
//=============================D-Property Type======================================================
		html=html.replace("Stories <span class=\"value\">", "Story ");
		String dtype=U.getdCommType((comData+html+combinedHomeHtml).replaceAll("Story Ray|113 Story Ray St|117 Story Ray St|119 Story|colonial curb|Colonial Promenade|AMC Colonial|Colonial\\+Drive|Colonial Drive|footerAnchorBackgroundColor|floor|Floor", ""));
		
//==============================================Property Status=========================================================
		
		comData = comData.replaceAll("model home coming in Spring 2021|\">Coming Summer 2021|Model home coming in Summer 2021|descriptionWeb\">Coming Spring 2021|descriptionPhone\">Coming Spring 2021|Model home coming in Spring 2021", "").replace("Phase 2 is Coming Soon", "Phase 2 Coming Soon")
				.replaceAll("half way sold out|his Community Is Sold Out|Now selling new homesites in the Estates|Now Available!  Special price of \\$229,990|this fast selling community|plan is now available|chance for new construction|Now Selling on 12 exclusive Sanford, NC homesites|above is now available|Salisbury is now open|model home is now available|New community opening soon|New Townhomes Coming Winter 2018/2019!|2018 move-in ready homes |advantage of closeout pricing|model now open|Final Opportunities!!  See|Final Opportunities - Don’t |Now Selling, by Appointment only|tipCloseout|plans now available|Quick|comparable to our SOLD|Oakdale, coming", "");
		
		html = html
				.replace("Winston Pointe South is sold out of its current phase", "Winston Pointe South is of its current phase sold out")
				.replaceAll("model home coming in Spring 2021|\">Coming Summer 2021|Model home coming in Summer 2021|descriptionWeb\">Coming Spring 2021|descriptionPhone\">Coming Spring 2021|Model home coming in Spring 2021", "").replace("Grand opening expected Fall 2021", "Grand opening Fall 2021").replace("bdxRTEWrapper\">HOMES READY NOW|Phase I is selling out quickly", "Phase I selling out quickly").replace("New lots are now available", "New lots now available")
				.replace("Phase I is SOLD OUT", "Phase I SOLD OUT").replaceAll("let this final chance|New lots are now available|Homes are selling FAST so come|pool are now open| Q, coming in September 2020.|Final few opportunities remain at Belle Arbor| garage coming soon|model coming|before they're SOLD|before we're completely sold|sales coming|Model Home - Coming Soon|Few Opportunities Remain - Hurry|Design is Now Available|half way sold out|sold out before construction|selling now so come make|Community Model coming Spring 2020|build are coming soon with|Coming Soon\\.  Join|Coming Soon\\.  By Appointment|Model home opening|Limited opportunities are going away quickly|half-way sold out before|Now selling by appointment|Model is now open|NOW OPEN!  Mon|plans just released|Grand opening to purchase|concept designs priced from the mid \\$\\d{3},\\d{3} are selling|Homes are selling fast|alt=\"Selling Quickly|this fast selling community|plan is now available|chance for new construction|We have one opportunity remaining|is now available and ready for immediate move-in| alt=\"Final Home Available\"|Move|move|homes ready now|Grand opening expected|Salisbury is now open|alt=\"Whitfield is SOLD OUT|model home is now available|Phase V coming later this year|Quick Move-In Homes now available and ready |Model Coming fall 2019|move-in ready September 2019|expected to be ready for move-in|coming soon to Salisbury|model homes are now open|Now Open at Carter|ool is now open|Sales Office is now open| has homes ready now|Move-In Ready Package|Ammersee Lakes has now opened our Lathem Model |purchased with limited opportunities|selection of homesites available now|expected to be ready for move-in by Early 2019|Coming Soon!  Appointment Only|Coming 2019|with Move-In Ready Homes|Coming Soon to Carter|area communities now open|marketingDescription\">\\s*COMING SOON|Quick Move|quick move|ready homes, you|In Ready in April|Model Coming Summer 2017|built and ready for move|expansion of our SOLD|alt=\"Final Home|We're currently selling|ON A MOVE|are selling fast, so|furnished and now| Drakes Branch is coming", "")
				.replaceAll("availability and close|construction homes available|Branch are now available|Coming Soon!  By Appointment|This community will feature 19 homesites available|Soon!  Join|Chance to tour our", "")
				.replace("Coming in Early 2021", "Coming Early 2021")
				.replaceAll("Now Selling the remaining Basement Homesites|Now Selling the remaining Basement Homesites", "Now Selling Basement Homesites").replace("New lots are now available", "New lots now available").replace("Final Phase of homesites is now available", "Final Phase now available")
				.replace("Final Phase of homesites is now available", "Final Phase of homesites now available").replace("new lots that are available", "new lots available")
				.replace("Phase 1 is SOLD OUT", "Phase 1 SOLD OUT").replace("USDA, $0 down / 100% financing", "USDA 100% financing")
				.replace("LAST 2021 OPPORTUNITY", "LAST OPPORTUNITY").replace("Now selling our new phase", "Now selling new phase").replace("Phase I & II have SOLD OUT", "Phase I and II SOLD OUT").replace("Now Selling the remaining Basement Homesites", "Now Selling remaining Basement Homesites");
		
		comData=comData.replace("New Lots Are Coming Soon", "New Lots Coming Soon").replaceAll("nearby and coming|Nearly half way sold out|before we're SOLD OUT|in our new phase|Move|move|homes ready now| garage coming soon|our final homes|Just 8 opportunities left!", "");
		comData = comData.replace("Only nine homes remain", "Only 9 homes remain").replace("Phase 1 is SOLD OUT", "Phase 1 SOLD OUT")
				.replace("Now selling our new phase", "Now selling new phase").replace("Homesites Are Selling Fast", "Homesites Selling Fast");
		
//		
		if(comUrl.contains("https://smithdouglas.com/find-a-home/raleigh/settlers-pointe/"))comData=comData.replace("tipComingSoon", "tip Coming Soon");
		
		
		html = html.replace("current homes are Sold Out", "current homes Sold Out").replace("Current phase is now sold out", "Current phase sold out");
		comData = comData.replace("Townhome Models Coming This Spring","").replace("Current Phase Is Now Sold Out", "Current phase sold out");
		
//		U.log(comData);
		
		String pstatus=U.getPropStatus((comData+ html).replace("One Final Home Remains - The Carlyle", "").replace(" Kimbro Woods Selling Now", "").replace("NEW PHASE COMING END OF SUMMER", "NEW PHASE COMING SUMMER").replace("Coming 2023 From the $200", "").replace("Now Selling For Early 2023", "Now Selling Early 2023").replace("now selling our new phase", "New Phase Now Selling")
				.replaceAll("two car garages located in Shelbyville, TN coming late Fall 2021|Learn About Our New Phase Release|Neighborhoods Selling Now|Coming Soon! Contact us for more |Buffington model. Our final phase will be released soon|Model Opening This Summer|To Learn About New Opportunities Coming|MODEL NOW OPEN!|Now Open! Come Tour|Now open, come tour|descriptionWeb\">NOW SELLING |descriptionPhone\">NOW SELLING|limited homesite release process is in place|[I|i]nventory homes available|[M|m]odel [c|C]oming|homes are currently sold|descriptionWeb\">Coming Fall 2021|descriptionPhone\">Coming Fall 2021|Model home coming in Fall 2021|HOMES READY NOW|Homes Ready Now|new lots that are available ", ""));

		U.log("pstatus: "+pstatus);
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comData, "[\\w\\s\\W]{30}Final Phase[\\w\\s\\W]{30}", 0));
		
		String imgStatus = "";
		if(comData.contains("wacdn-img3.secure.footprint.net/media/11645/web_banners_122x39-06.png?v=636554243960000000") && (!pstatus.contains("Opportunities")))
			imgStatus = "Final Opportunities";
		
		if(quickCount > 0 && !pstatus.contains("Quick")){
			if(pstatus == ALLOW_BLANK)
				pstatus = "Quick Move-In Homes";
			else if(pstatus != ALLOW_BLANK)
				pstatus = pstatus+", Quick Move-In Homes";
		}
		
		if(!imgStatus.isEmpty()){
			if(pstatus == ALLOW_BLANK)pstatus = imgStatus;
		else if(pstatus != ALLOW_BLANK && !pstatus.contains(" Final"))
			pstatus = pstatus+", "+imgStatus;
		}
		pstatus = pstatus.replace("Homesites Are Selling Fast, Selling Fast", "Homesites Are Selling Fast").replace("Quick Move-in", "Quick Move-In Home").replace("New Phase, New Phase Just Released", "New Phase Just Released");
		pstatus = pstatus.replace("Just 8 Opportunities Left, Only 8 Opportunities Remain", "Just 8 Opportunities Left");
		
		if(comUrl.contains("/raleigh/settlers-pointe/"))pstatus = "Limited Opportunities";//Img 
		
//		if(comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/willowbrook-at-the-villages/"))pstatus = pstatus.replace("Selling Now", "New Phase Now Selling");
		pstatus = pstatus.replace("Lots Are Now Available, Usda 100% Financing, Now Available", "Lots Are Now Available, Usda 100% Financing").replace("Lots Are Now Available, Grand Opening, Now Available", "Lots Are Now Available, Grand Opening");
		pstatus = pstatus.replace("New Lots Now Available, Lots Are Selling Fast, Now Available", "New Lots Now Available, Lots Are Selling Fast").replace("New Lots Now Available, Now Available", "New Lots Now Available");
		pstatus = pstatus.replace("Only 1 Opportunity Remains, 1 Opportunity Remains", "Only 1 Opportunity Remains").replace("Only A Few Opportunities Remain, Almost Sold Out, Only A Few Homesites Remain, Final Opportunities", "Almost Sold Out, Only A Few Homesites Remain, Final Opportunities");
		pstatus=pstatus.replace("Coming Spring 2022, Coming Soon","Coming Spring 2022");
		pstatus=pstatus.replace("Coming This Spring, Coming Soon", "Coming This Spring");
		pstatus=pstatus.replace("Coming This Summer, Coming Soon","Coming This Summer");
		pstatus=pstatus.replace("Coming Early 2022, Coming Soon", "Coming Early 2022");
		pstatus=pstatus.replace("New Phase Coming In Summer 2022, Coming This Summer, Currently Sold Out", "New Phase Coming In Summer 2022, Currently Sold Out");
		pstatus=pstatus.replace("Coming Spring 2022, Selling Out, Coming Soon", "Coming Spring 2022, Selling Out");
		pstatus=pstatus.replace("Coming Summer 2022, Coming Soon","Coming Summer 2022");
		pstatus=pstatus
				.replace("Coming Soon, Future Phase Coming Soon, Future Phases Coming Early Summer 2022", "Future Phase Coming Soon, Future Phases Coming Early Summer 2022")
				.replace("Now Selling In Phase 1a","Now Selling In Phase 1A");
		
		//============================================note====================================================================
		
		
		if(comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/emerald-oaks-estates/")
				|| comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/worley-preserve/"))note= "Now Pre-Selling"; //From Image
		U.log(add[2]+" "+add[0]);
		add[0]=add[0].replace("\">","").replace(".", "").replace(add[2], "").replace("Raleigh 27603", "").trim();
		add[2]=add[2].replace(".","");
		
		if(pstatus.contains("New Lots Now Available,") && pstatus.contains(", Now Available"))
			pstatus = pstatus.replaceAll(", Now Available", "");
		if(pstatus.contains("New Lots Available,") && pstatus.contains(", Now Available"))
			pstatus = pstatus.replaceAll(", Now Available", "");
		if(pstatus.contains("Final Opportunities Now Available,") && pstatus.contains(", Now Available"))
			pstatus = pstatus.replaceAll(", Now Available", "");
		pstatus = pstatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		if(comUrl.contains("https://smithdouglas.com/find-a-home/charlotte/stanly-farms/"))pstatus=pstatus.replace(", Final Opportunities", "");
	
		if(comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/chastain-overlook/"))proptype="Single Family";
		pstatus=pstatus.replace("Coming Soon, 100% Financing, Coming This Summer", "Coming Soon, 100% Financing").replace("Currently Sold Out, Sold Out", "Currently Sold Out");
		note=note.replaceAll("Now Pre-selling, Now Pre Selling|Now Pre-selling, Pre-sale", "Now Pre-selling");
		
		if(comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/escalades"))latlag[1]="-84.5932";
		if(comUrl.contains("/find-a-home/nashville/nichols-vale/"))pstatus=pstatus.replace("Final Opportunities, Selling Now", "Final Opportunities Selling Now");
		//Status from images
//		if(comUrl.contains("communities/Armstrong-Meadows-163725"))pstatus = "Next Phase Release Coming Summer 2022, Currently Selling Out";//====remm
		if(comUrl.contains("/nichols-vale/"))pstatus=pstatus.replace("Coming Soon", "Final Phase Coming Soon");
//		if(comUrl.contains("find-a-home/raleigh/east-hampton/"))pstatus+=", Final Opportunities";
		//if(comUrl.contains("/find-a-home/charlotte/river-park/"))pstatus ="Final Phase";
		pstatus=pstatus.replace("Now Selling, Over 60% Sold Out, Limited Homesite", "Now Selling, Over 60% Sold Out")
				.replace("New Phase, Now Selling New Phase", "Now Selling New Phase")
				.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling")
				.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		
		//from img 28 march
		if(comUrl.contains("https://smithdouglas.com/find-a-home/raleigh/huntington-park/")) pstatus = "Now Selling Summer 2022";
		if(comUrl.contains("https://smithdouglas.com/find-a-home/huntsville/gardens-at-ivy-hills/"))note="Now Preselling New Phase";
		if(comUrl.contains("https://smithdouglas.com/find-a-home/atlanta/chastain-overlook/"))pstatus="Final Opportunities, Final Homes";
		if(comUrl.contains("atlanta-communities/Emerald-Oaks-Estates-153316")) pstatus = pstatus.replace("New Phase, Selling Fast", "New Phase Selling Fast");//==========remm
		if(comUrl.contains("communities/Winston-Pointe-South-147173")) pstatus = pstatus.replace("Coming This Summer, ", "");//==========remm

		if(comUrl.contains("communities/78-South-163818")) add[0] = "1195 Tramway Rd";//==========remm
		if(comUrl.contains("communities/Tryon-Pointe-157515")) add[0] = "3204 Sanderford Rd.";//==========remm

		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		U.log("Note:: "+note);
		
		//siteplan====
		
		String myLotData=ALLOW_BLANK;
		int sum=0;
		if(html.contains("Community Lot Map")||html.contains("Real Time Availability Map")) {
			String siteMapUrlSec=U.getSectionValue(html, "data-feature-type=\"ISP\">", "target=\"_blank\"");
			if(siteMapUrlSec==null)
				siteMapUrlSec=U.getSectionValue(html, "<li class=\"interactiveFeatureListItem noFlash\" data-feature-type=\"XCH\">", "target=\"_blank\"");
			if(siteMapUrlSec!=null) {
			String siteMapUrl=U.getSectionValue(siteMapUrlSec, "href=\"", "\"");
			U.log("siteMapUrl=="+siteMapUrl);
			String siteMapHtml=U.getHtml(siteMapUrl,driver);
			U.log("PPP:: "+U.getCache(siteMapUrl));
//			String[] lotdata=U.getValues(siteMapHtml, "class=\"MuiTypography-root jss158 jss151 MuiTypography-overline\"", "</span></span>");
//			U.log("mmm"+Util.match(siteMapHtml, "MuiTypography-overline css-1i29yre\">"));
			//U.log("VV:: "+siteMapHtml);
			String[] lotdata=U.getValues(siteMapHtml, "MuiTypography-overline css-1i29yre\">", "</span></span>");
			U.log("PP:: "+lotdata.length);
			for(String lotD:lotdata) {
				myLotData+=" "+lotD;
			}
			String mLot=U.getNoHtml(myLotData);
			U.log("mLot:: "+mLot);
			ArrayList<String> lots=Util.matchAll(mLot, "\\d+", 0);
			Iterator it = lots.iterator();
			while(it.hasNext()) {
			String  lotNumber= (String) it.next();
			int lotNo=Integer.parseInt(lotNumber);
			sum+=lotNo;
			}
			U.log("Sum Of lot Count: "+sum);
		}
		}
		String noOfUnits=ALLOW_BLANK;
		
		noOfUnits=Integer.toString(sum);
		if(noOfUnits.equals("0"))
			noOfUnits=ALLOW_BLANK;
		
		add[0]=add[0].replace("143 Beverly Place, Four Oaks,","143 Beverly Place");

		
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace("&amp;", "&").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Ii", "II"));
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
	}
	j++; 
	//}catch(Exception e){}

	}
}