/*
 * @modify : Sawan
 * @date : 07-10-2017
 */
package com.shatam.b_301_324;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractAvillaHomes extends AbstractScrapper{
	WebDriver driver = null;
	private static String builderUrl = "https://www.avillahomes.com";
	private static String builderName = "Avilla Homes";
	private static String fileUrl = U.getCachePath()+"Avilla Homes.csv";
	private static CommunityLogger LOGGER;
	int j = 0;
	HashMap<String, String> comListMap = new HashMap<>();
	
	public ExtractAvillaHomes()throws Exception {
		super(builderName, "https://www.avillahomes.com/");
		LOGGER = new CommunityLogger(builderName);
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
//		 TODO Auto-generated method stub
		AbstractScrapper a = new ExtractAvillaHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Avilla Homes.csv", a.data()	.printAll());
		LOGGER.DisposeLogger();
	}

//	HashMap<String,String> address=new HashMap<>();
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub

		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		U.bypassCertificate();
		
		
		String mainHtml=U.getHTML("https://www.avillahomes.com");
//		String section = U.getSectionValue(mainHtml, "class=\"fusion-dropdown-svg\">", "<span class=\"menu-text\">");
		String [] regUrls = U.getValues(mainHtml, "col-lg-3", "</a>");
		int i=0;
		for (String reg : regUrls) {
//			U.log(reg);
			String regionUrl="https://www.avillahomes.com/"+U.getSectionValue(reg, "href=\"/", "\"");
//			U.log(regionUrl);
			U.bypassCertificate();
			String regHtml=U.getHTML(regionUrl);
			regHtml=regHtml.replace("Contact Rental", "Apply Now");
		//	String commSecs[]=U.getValues(regHtml, "span5 view-image", "title=\"Apply Now\"");
			String commSecs[]=U.getValues(regHtml, "<div class=\"parameters hidden mapPoint\">", "title=\"Apply Now\"");
//			U.log(commSecs.length);
			for (String comSec : commSecs) {
			
				comSec=comSec.replace("href=\"javascript:void(0)\"", "");
			//	U.log((i++)+comSec);
//				U.log("==========");
				String comUrl=U.getSectionValue(comSec, "<a href='", "'");
			//	U.log(comUrl);
				String comName=U.getSectionValue(comSec, "title='", "'");
				addDetails(comUrl, comName,comSec);
			}
			//return;
		}
	
		driver.quit();
		
	}
		


	private void addDetails(String commUrl,String comName, String comSec) throws Exception {
		// TODO Auto-generated method stub
//	try{
//		U.log("Count: " + j + "\t" + commUrl);
//		if(!commUrl.contains("https://www.avillaoakridge.com?rcstdid=MzI%3d-GJOvflXL	v8M%3d"))return;
//		if(!comName.contains("Avilla Northside")) return;
	{
		if(commUrl==null)return;
		if(commUrl.contains("http:/"))commUrl = commUrl.replace("http:/", "https:/");
		
		
		
		
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"repeated**********");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		if(!commUrl.contains("http")) {
			commUrl="https://avillahomes.com/"+commUrl;
		}
		
//		if(!commUrl.contains("https://www.avillamagnolia.com?rcstdid=MzI%3d-GJOvflXLv8M%3d")) return;
		
		U.log(j+" comUrl---"+commUrl);
		U.log(U.getCache(commUrl));
		String html = ALLOW_BLANK;
		if(commUrl.contains("php?cID"))
			html=U.getHTML(commUrl);
		else
			html=U.getHTML(commUrl);
		String floorHtml  =ALLOW_BLANK;
		String allFloorHtml = ALLOW_BLANK;
		String amentiesHtml  =ALLOW_BLANK;
		if(commUrl.contains("")){
			String navSec = U.getSectionValue(html, "<nav class=\"navigation widget", "</nav>");
			if(navSec!=null){
				for(String navUrl : U.getValues(navSec, "<a href=\"", "\"")){
					U.log("navUrl : "+navUrl);
					if(navUrl.contains("/apartments/az/gilbert/why-avilla") && amentiesHtml.length()<4){
						amentiesHtml  = U.getHTML(commUrl+navUrl);
					}
					if(navUrl.contains("/apartments/az/gilbert/floor-plans") && floorHtml.length()<4){
						floorHtml  = U.getHTML(commUrl+navUrl);
						
					}if(navUrl.contains("apartments/az/queen-creek/floor-plans") ){
						floorHtml  = U.getHTML(commUrl+navUrl);
						
					}
					if(navUrl.contains("/apartments/co/commerce-city/why-avilla") && amentiesHtml.length()<4){
						amentiesHtml  = U.getHTML(commUrl+navUrl);
					}
					if (navUrl.contains("/apartments/co/commerce-city/floor-plans")&& floorHtml.length()<4) {
						floorHtml  = U.getHTML(commUrl+navUrl);
					}
					if (navUrl.contains("floor-plans")&& floorHtml.length()<4) {
						floorHtml  = U.getHTML(commUrl+navUrl);
					}
				}
			}
		}
		if(commUrl.contains("avillagraceliving")) {
			amentiesHtml = U.getHTML("https://www.avillagraceliving.com/apartments/az/chandler/why-avilla");
		} if(commUrl.contains("avillalehicrossing")){
			amentiesHtml = U.getHTML("https://www.avillalehicrossing.com/apartments/az/mesa/why-avilla");

		}if( commUrl.contains("avillameadows")) {
			amentiesHtml = U.getHTML("https://www.avillameadows.com/apartments/az/surprise/why-avilla");

		}
		if( commUrl.contains("avillavictoria")) {
			amentiesHtml = U.getHTML("https://www.avillameadows.com/apartments/az/surprise/why-avilla");

		}
		//>>>>>>>>>>>>>>>>>MAp Details>>>>>>>>>
	//	U.log("COMSEC"+comSec);
		String propName=U.getSectionValue(comSec,"<span class=\"propertyShortName\">","</span>");
		U.log("prop Nmae"+propName);
		String pointId=U.getSectionValue(comSec, "<span class=\"pointId\">","</span>");
	    U.log("point id"+pointId);
		String mapUrl="https://www.avillahomes.com/rcloadcontent.ashx?contentclass=mapballoon&mapBalloonMode=0&mapballoonproperty="	
	   +propName+"&mapballoonnumber="+pointId+"&UnitId=null&cafeportalkey=MjQ0MDA1NCM5MDA%253d-ChH0IkaAiio%253d";
		String mapHtml=U.getHTML("https://www.avillahomes.com/rcloadcontent.ashx?contentclass=mapballoon&mapBalloonMode=0&mapballoonproperty="	
				   +propName+"&mapballoonnumber="+pointId+"&UnitId=null&cafeportalkey=MjQ0MDA1NCM5MDA%253d-ChH0IkaAiio%253d");
		String sqftSec=U.getSectionValue(mapHtml, ">Square Foot</span>", "</span> </li>");
		sqftSec=U.getNoHtml(sqftSec);
		U.log("SQERft Sec"+sqftSec);
	    
	    
	//===========================================Community Name==============================================
		comName = comName.replace("Victoria I", "Victoria");
		U.log("community name--->"+comName);
	//==========================================Address Sec==================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latLong={ALLOW_BLANK,ALLOW_BLANK};
		String note=ALLOW_BLANK;
		String geo="FALSE";
	
	//	U.log(comSec);
		String addSec= U.getSectionValue(comSec, "/strong><br>", "<a");
		if(addSec== null) addSec = U.getSectionValue(html, "\"address\": \"", "\"");
		
		if(commUrl.contains("az/")) {
			addSec=U.getSectionValue(html, "span4 prop-address", "</div>").replaceAll("\\s+\\s+|<ul >|<li>|,</ul>", "").replace("</li>", ",");
		}
		
		
		
		//U.log(addSec);
		if(addSec!=null){
			U.log("AddSec ::"+addSec);
			addSec=addSec.replace("\">2501 W. Orange Grove Rd.,Tucson, AZ 85741,</ul>", "2501 W. Orange Grove Rd,Tucson, AZ 85741").replace("4050 W. Aerie Dr.,Tucson, AZ 85741,</ul>", "4050 W Aerie Dr, Tucson, AZ 85741");
		addSec=addSec.replace("\">", "").replace(",</ul>", "").replace(".", "");
			
			addSec=addSec.replaceAll("\\\\r\\\\n", "");
			addSec = addSec.replace("Ave. Phoenix", "Ave., Phoenix").replace("Road Tucson", "Road, Tucson")
					.replace("Drive Plano", "Drive, Plano").replaceAll("Dr. Grand", "Dr, Grand").replace("Avenue McKinney", "Avenue, McKinney").replaceAll("Dr. Goodyear", "Dr, Goodyear")
					.replace(" Rd Phoenix", " Rd, Phoenix");
			add = U.getAddress(addSec);
			U.log("AddSec ::"+addSec);
		}
	//	U.log("ggggggg  "+comSec);
	//	latLong[0]=Util.match(comSec, "\\d{2}.\\d{5}");
	//	latLong[1]=Util.match(comSec, "-\\d{2,3}.\\d{5}");;//U.getSectionValue(comSec, "longitude\":\"","\"");
		
		if(commUrl.contains("https://www.avillabuffalorun.com/")) {
			add[0]="11940 Jasper St";
			add[1]="Commerce City";
			add[2]="CO";
			add[3]="80022";
			latLong[0]="39.9124534";
			latLong[1]="-104.8045657";
		}
		
		if(add[0]==null||add[0].length()<3){
			add[0]=U.getSectionValue(html, "address: \"", "\"");
			add[1]=U.getSectionValue(html, "city: \"", "\"");
			add[2]=U.getSectionValue(html, "state: \"", "\"");
			add[3]=U.getSectionValue(html, "zip: \"", "\"");
			
		}
	
		
/*		if(addSec != null){
			U.log(addSec);
			add = U.findAddress(addSec);
		}*/
		if(latLong[0] == null && latLong[1] == null){
			latLong[0] = U.getSectionValue(html, "\"latitude\": \"", "\"");
			latLong[1] = U.getSectionValue(html, "\"longitude\": \"", "\"");
		}
		
		if(latLong[0] == null || latLong[0].length()<4){
			latLong[0] = U.getSectionValue(html, "latitude\": \"", "\"");
			latLong[1] = U.getSectionValue(html, "longitude\": \"", "\"");
		}
		if(latLong[0] == null || latLong[0].length()<4){
			
			String latSec = U.getSectionValue(html, "href=\"https://maps.google.com/maps?ll=", "&");
			if(latSec!=null)
			latLong = latSec.split(",");
		}
		if(html.contains("<span class='propertyLat'>")) {
			latLong[0]=U.getSectionValue(html, "<span class='propertyLat'>", "</span>");
			latLong[1]=U.getSectionValue(html, "<span class='propertyLng'>", "</span>");
		}
			
		if(latLong[0] == null || latLong[0].length()<4){
			
			String latSec = U.getSectionValue(html, "https://www.google.com/maps/embed?pb=", "\"");
			if(latSec!=null) {
			latSec = Util.match(latSec, "-\\d+\\.\\d+.*\\d+\\.\\d+");
			U.log("=================="+latSec);
			if(latSec!=null)
			latLong = latSec.replaceAll("!\\d\\w", ",").split(",");
			
			String lat = latLong[0];
			latLong[0] = latLong[1];
			latLong[1] = lat;
			}
			else {
				latLong=U.getlatlongGoogleApi(add);
			}
		}
		
		U.log("Addtress-->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		U.log("LatLong---->"+latLong[0]+" "+latLong[1]);
	//-------------floor--------
		
//		for (String navUrl : navUrls) {
//			if (navUrl.contains("floor-plans")) {
//				U.log("FloorPlan:: "+commUrl+navUrl);
//				allFloorHtml = U.getHtml(commUrl+navUrl,driver);
//			}
//		}
		//if(floorHtml.length()>4){
//		U.log(commUrl+"/apartments/"+add[2].toLowerCase()+"/"+add[1].toLowerCase()+"/floor-plans#/categories/all/floorplans");
			
		if(add[1]!=null)
		allFloorHtml = U.getHTML(commUrl+"/apartments/"+add[2].toLowerCase()+"/"+add[1].toLowerCase().replace(" ", "-")+"/floor-plans#/categories/all/floorplans");
		
		
		
		//======================site Map======================
		String avilableUnitUrl = ALLOW_BLANK;
		String floorUrlSite=ALLOW_BLANK;
		
		String noOfUnits=ALLOW_BLANK;
		if(html.contains(">Interactive Site Map  </a>")||html.contains("Interactive site map")||html.contains("Interactive Property Map")||html.contains(">Interactive Property Map  </a>")) {
			U.log("Hekllo");
			avilableUnitUrl= commUrl+"interactivepropertymap";
			if(!commUrl.endsWith("/"))avilableUnitUrl = commUrl.replaceAll("\\?.*", "")+"/interactivepropertymap";
			
			U.log("floorUrl::::::::"+avilableUnitUrl);
			noOfUnits=getUnit(avilableUnitUrl);

		}
		if(floorUrlSite==ALLOW_BLANK) {
			floorUrlSite=U.getSectionValue(html, "<a class=\"btn btn-primary\" href=\"", "\">");
			
		}
		U.log("floorUrl::::::::"+floorUrlSite);
//	==================================================Price Sec================================================
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		String[] price=U.getPrices(comSec+html,"\\$\\d{3},\\d{3}",0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
	//=====================================================Sq.FT Sec============================================
		String minSqf=ALLOW_BLANK;
		String maxSqf=ALLOW_BLANK;
		floorHtml = floorHtml;//.replace("<span data-v-80d2466a=\"\">1,236 Sq.Ft</span>", "")
				//.replace("<span data-v-80d2466a=\"\">1,244 Sq.Ft</span>", "");
		//U.log(floorHtml); 
		String[] sqft=U.getSqareFeet(comSec+html+allFloorHtml+floorHtml+avilableUnitUrl+sqftSec,"\\d{3} - to  \\d{4} Sq.Ft.|\\d{4}<span>Sq.Ft.|\\d,\\d{3} Sq.Ft|\\d{3} Sq.Ft.|>\\d,\\d{3} Sq.Ft</span>|\\d,\\d{3} sq ft|\\d{3,4} sq ft|<td>\\d{3,4}</td>|(\\d,)*\\d{3} Sq. Ft|\"SquareFeet\": \\d{3,4}",0);
	
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		if(commUrl.contains("https://www.avillaoakridge.com?rcstdid=MzI%3d-GJOvflXLv8M%3d")) {
			minSqf="637";
		    maxSqf="1236";
		}
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
	//==================================================CommunityType=============================================
		html=html.replace("3 floor levels"," 3 Story ");
		html = html.replace("Golf Resort", "Golf Course Resort").replace("Top Golf", "golf courses");
		String communityType=U.getCommunityType(comSec+html.replaceAll("2604 Country Club|name\":\"Eldorado Country Club\",", "")+amentiesHtml);
	
	//==================================================D Property Type============================================
		html=html.replaceAll("lofts|Lofts","");
		
		String dPType=U.getdCommType((comSec+html).replace("single-story", "1 Story").replaceAll("back Ra|backranch|code-branch|Ashton Ranch|-ranch|backranch.|Camelback Ranch|Saddle Ranch|Avilla Camelback Ranch|Ranch apartments in Phoenix, Arizona\"|Ranch in Phoenix Arizona\"|Ranch\" |_Ranch_|content=\"Avilla Camelback Ranch|iz/avilla-camelback-ranch-phoenix\"|k.com/AvillaCamelbackRanch|a-camelback-ranch/services/thumbnail_fyabni.jpg\",|ou at Avilla Camelback Ranch.\",|on\": \"Here at Avilla Camelback Ranch,|-avilla-camelback-ranch\",| \\| Avilla Camelback Ranch</title>|:\"Avilla Camelback Ranch\",|\"content\":\"<strong>Avilla Camelback Ranch</strong>|<strong>Avilla Camelback Ranch</strong>|:\"Avilla Camelback Ranch\",|(F|f)loor|FLOOR|\"name\":\"Avilla Camelback Ranch\"|/span>Avilla Camelback Ranch</span>|ckranch.com\"| value='Avilla Camelback Ranch' >Avilla Camelback Ranch</option>", ""));

		if(comName.contains("Avilla Northside")) dPType="1 Story";;
	//================================================== Property Type============================================
		//U.log(html);
		html = html.replace(" Our spacious detached\nhomes include private backyar", " Our spacious detached villa homes include private backyar");
		
		if(commUrl.contains("https://www.avillahomes.com/locations/tucson-metro-communities/avilla-tanque-verde/")) comSec= comSec +"single story, detached homes "; //from reg. pg

		String pType=U.getPropType((comSec+html+floorHtml).replace("level and fully detached* luxury homes", "level and fully detached homes and luxury homes")
				.replaceAll("Live a life of luxury every day", "life of luxury homes every day")
				.replaceAll("\"Apartment|-apartment-|/Apartment/|Avilla|avilla|Villa De Paz|AVILLA_|AVILLA", ""));
	
		U.log("pType: "+pType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+html, "[\\s\\w\\W]{30}luxury[\\s\\w\\W]{30}", 0));
		
	//==================================================Status Sec================================================
		html=html.replaceAll("Our office is now open |NOW OPEN!:</strong>|&#8211; NOW OPEN!|<p>Coming Soon!</p>|Hours:</h2>\\s+<p>Opening","");
		String pStatus=U.getPropStatus((comSec+html).replaceAll("Now Open\\!\\s+</button>|aria-label=\"Now Open|head\">Now Open", ""));
		
		U.log("pStatus: === "+pStatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec+html, "[\\s\\w\\W]{30}now open[\\s\\w\\W]{30}", 0));
		
		if(html.contains("Leasing Office")) {
			
			String addS=U.getSectionValue(html, "Leasing Office","</p> ");
			if(addS!=null) {
				addS=addS.replace(comName, "").replace("<p><br />", "");
				addS=addS.replace("<br />", ",").replace("<p> ,", "").replaceAll("Avilla Marana I|</div>", "").replace("<br>Tucson", ", Tucson");
				add=U.getAddress(U.getNoHtml(addS));
				U.log("ffffff"+addS);
			}
		}
		

		if(commUrl.contains("https://www.avillaeastlake.com/")) {
			
			add[0]="12230 Washington Center Pkwy";
			add[1]="Thornton";
			add[2]="CO";
			add[3]="80241";
			
			
			latLong[0]="39.9193709";
			latLong[1]="-104.9746069";
			geo="FALSE";
		}

		if(commUrl.contains("https://www.avillareserve.com/")) {
			
			
			//address": ", ,  ",
		     
			add[0]="1104 State Highway 114";
			add[1]="Justin";
			add[2]="TX";
			add[3]="76247";
			
			
			latLong[0]="33.0342749";
			latLong[1]="-97.3334961";
			geo="FALSE";
		}
		
		if(commUrl.contains("https://www.avillalago.com/")) {
			add[0]="10310 W Beardsley Rd";
			add[1]="Peoria";
			add[2]="AZ";
			add[3]="85382";
			
			
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		
		if(commUrl.contains("https://www.avillaenclave.com/")) {
			add[0]="8433 E Guadalupe Rd";
			add[1]="Mesa";
			add[2]="AZ";
			add[3]="85212";
			
			
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if(latLong[0]==null) {
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		//

			if(commUrl.contains("https://www.avillapaseo.com/")) {
				pStatus=ALLOW_BLANK;
			}
			U.log(latLong[0]+"  "+latLong[1]);
			//
			//,  
		if(add[0]!=null)
			add[0] = add[0].replaceAll("Avilla Marana I, 4050 W Aerie Drive", "4050 W Aerie Drive").replace(",", "");
		
		note = U.getnote(html);
	  //  if(commUrl.contains("https://www.avillasuncoast.com"))pType=pType+", Apartment Homes";
		if(commUrl.contains("https://www.avillalehicrossing.com"))comName ="Avilla Lehi Crossing";
		
		if(commUrl.contains("avilla-marana-i")||commUrl.contains("avilla-preserve0")||commUrl.contains("avilla-tanque-verde0")||commUrl.contains("avilla-river0")) {
			minSqf="635";
			maxSqf="1244";
			pStatus=ALLOW_BLANK;
		}
		
		//========siteMap
//		if(html.contains("Interactive Site Map")) {
//		  String noOfUnits=getUnit(html,commUrl);
//		}
		
		data.addCommunity(comName, commUrl, communityType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(),geo);
		data.addPropertyType(pType, dPType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);
	}
	j++;
//	}catch(Exception e){}
	}


	private String getUnit(String avilableUnitUrl) throws Exception {

		String avaialbelUnitHtml=U.getHtml(avilableUnitUrl, driver);
		U.log("path"+U.getCache(avilableUnitUrl));
		
		String avilableUnitSec = U.getSectionValue(avaialbelUnitHtml, "var available_units =", ";");
	    JsonParser parser=new JsonParser();
	    JsonArray arr=(JsonArray) parser.parse(avilableUnitSec);
	    
	    int lotCount=arr.size();
	   String noOfUnit=Integer.toString(lotCount);
	   
	   if(noOfUnit.equals("0"))
	    	noOfUnit=ALLOW_BLANK;
		
		return noOfUnit;
	}
}