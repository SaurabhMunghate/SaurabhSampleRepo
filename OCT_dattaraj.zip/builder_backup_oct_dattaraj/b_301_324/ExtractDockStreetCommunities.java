package com.shatam.b_301_324;

import java.io.IOException;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDockStreetCommunities extends AbstractScrapper {
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractDockStreetCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Dock Street Communities.csv", a.data().printAll());
	}

	public static String homeurl = "http://dockstreetcommunities.com/";

	public ExtractDockStreetCommunities() throws Exception {
		super("Dock Street Communities", homeurl);
	}

	int a = 0;

	public void innerProcess() throws Exception {
		String html = U.getHTML(homeurl);
		html = U.getSectionValue(html, "<h3 class=\"sec-title\">TOUR our COMMUNITIES</h3>", "<div class=\"dark-gray\" id=\"request_info\">");
		String[] urls = U.getValues(html, "<figure>", "Learn more</a>");
		for (String loc : urls) {
			U.log(loc);
			String commName = U.getSectionValue(loc, "<h3>", "</h3>");
			String address = U.getSectionValue(loc, "<h4>", "</h4>");
			//commName = commName.replace("\">", "");
			//commName = commName.trim();
			loc = U.getSectionValue(loc, "<a href=\"", "\" ");
			
			if (loc.contains("http://www.cascadessa.com"))
				continue;
			commDetails(loc, commName,address);
		}
		
			comData("http://dockstreetcommunities.com/wp-content/uploads/2016/05/15-DSC-1069_Cascades-at-World-Golf-Village-PDF.compressed.pdf");
	}
	public void comData(String pdfUrl) throws Exception{
		data.addCommunity("Cascades At World Golf Village", "http://dockstreetcommunities.com/wp-content/uploads/2016/05/15-DSC-1069_Cascades-at-World-Golf-Village-PDF.compressed.pdf", "Active Adult,Resort Style");
		data.addAddress("5351 Church Rd", "St Augustine", "FL", "32092");
		data.addLatitudeLongitude("29.9129131", "-81.505837", "TRUE");
		data.addPropertyType(ALLOW_BLANK, ALLOW_BLANK);
		data.addPropertyStatus(ALLOW_BLANK);
		data.addPrice("$250,000", "$385,000");
		data.addSquareFeet(ALLOW_BLANK, ALLOW_BLANK);
		data.addNotes("Address And Latlong Taken From City And State");
	}
	public String[] getAddress(String commurl) throws IOException {

		String html = U.getHTML(commurl);
		html=html.replace("including courtyards, park space and common area</p>","");
		html=html.replace("<h4>1802 sq ft</h4>","");
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String sectionAdd = U.getSectionValue(html, "Site Map</a></li>", "|");
		if (sectionAdd != null)
			add = U.findAddress(sectionAdd);
		// else {
		sectionAdd = U.getSectionValue(html, "<div id=\"FooterText\">", ";");
		// }
		if (sectionAdd != null) {
			add = U.findAddress(sectionAdd);
		}
		add[1] = add[1].replace("Suite 100�", "").trim();
		return add;

	}

	public String[] getPrices(String commUrl) throws IOException {
		String price[] = { ALLOW_BLANK, ALLOW_BLANK };
		if (commUrl.contains("http://www.seasonsmi.com")) {

			String htmlPrice = U
					.getHTML("http://www.seasonsmi.com/floorplans.php");
			htmlPrice = htmlPrice
					+ U.getHTML("http://www.seasonsmi.com/availablehomes.php");

			price = U.getPrices(htmlPrice,
					"Starting at \\$\\d{3}\\,\\d{3}|\\$\\d+,\\d+</h3>", 0);
			return price;
		}

		if (commUrl.contains("thehomesatmarketcommon.com")) {
			price[0] = "$230,000";
			price[1] = "$529,900";
			
		}
		
		return price;

	}

	public String[] getSqft(String commUrl) throws IOException {
		String sqFt[] = { ALLOW_BLANK, ALLOW_BLANK };
		if (commUrl.contains("http://www.seasonsmi.com")) {

			String htmlPrice = U
					.getHTML("http://www.seasonsmi.com/floorplans.php");
			htmlPrice = htmlPrice
					+ U.getHTML("http://www.seasonsmi.com/availablehomes.php");

			sqFt[0]="1720";
			sqFt[1]="2501";
		}
		if (commUrl.contains("http://www.thehomesatmarketcommon.com")) {
			sqFt[0] = "965";
			sqFt[1] = "3325";
		}
		if (commUrl.contains("http://www.stjamestownhomes.com")) {
			sqFt[0] = "1383";
			sqFt[1] = "1710";
		}
		if (commUrl.contains("http://www.seasidetownhomes.com")) {
			sqFt[0] = "2052";
			sqFt[1] = "2338";
		}
		if (commUrl.contains("http://thehomesatmarketcommon.com")) {
			sqFt[0] = "1383";
			sqFt[1] = "3325";
		}
		return sqFt;

	}

	public void commDetails(String commUrl, String commName,String addres) throws Exception {
		// ............................Community Url...........................
		//if(!commUrl.contains("http://www.stjamestownhomes.com"))return;
		U.log("Page Url: " + commUrl);
		if(commUrl.contains(".pdf"))return;
		// ...........................Community Name...........................
		U.log(commName);
	
		U.log(addres);
	//	commName = commName.substring(0, commName.indexOf("-"));

		// .......................comunity type,property type, property

		String html = U.getHTML(commUrl);

		// Add

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		add = getAddress(commUrl);
		if (add[0] == ALLOW_BLANK) {

			String sl[] = addres.split(",");
			add[1] = sl[0].trim();
			add[2] = sl[1];

		}
		// Price

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] prices = getPrices(commUrl);
		minPrice = prices[0];
		maxPrice = prices[1];
		// if()

		// Sqft

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String sqFt[] = getSqft(commUrl);
		minSqft = sqFt[0];
		maxSqft = sqFt[1];
		// LatLng

		String flag = ALLOW_BLANK;
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		if (add[0] != ALLOW_BLANK) {
			latLng = U.getlatlongGoogleApi(add);
			flag = "TRUE";
		}

		// Community Type
		html=html.replaceAll("coming|Coming|Best Master-Planned Communities|carriage townhomes|Carriage Townhomes|SINGLE FAMILY MOVE-IN READY HOMES", "");
		String communitytype = U.getCommunityType(html);

		// Property Type
		String proptype = U.getPropType(html);

		// Derive Prop
		html=html.replace("1st & 2nd Floor"," 1 Story 2 Story ");
		String dtype = U.getdCommType(html);

		// Status
		String propstatus = U.getPropStatus(html);
		if(add[0].length()<2)
		{
			add[0]=ALLOW_BLANK;
		}
		//note
		String note="";
		
		
		if(add[0]==ALLOW_BLANK && add[1]!=ALLOW_BLANK)
		{
			String aaaa=U.getHardcodedAddress("Hardcode_DockStreetCommunities", commUrl);
		    U.log("------->"+aaaa);
		    if(aaaa!=null)
		    {
		    String[] aaa=aaaa.split(",");
		    add[0]=aaa[0];
		    add[1]=aaa[1];
		    add[2]=aaa[2];
		   latLng=U.getlatlongGoogleApi(add);
		 flag="true";
		    
		   
		   // String[] latlng={lat,lng};
		   add=U.getAddressGoogleApi(latLng);
		  //  add[3]=aa[3];
		    }
		}
	//	add[1]=add[1].replace("100¬†","");
		if (commUrl.contains("http://www.stjamestownhomes.com")) 
		{
			minPrice="$220,000";maxPrice="$269,000";
			 latLng[0]="33.7234296";
			 latLng[1]="-78.8689692";
	}
		
		if (commUrl.contains("http://www.seasidetownhomes.com")) 
		{
			minPrice="$220,000";
			proptype=proptype+",Homeowner Association";
			proptype=proptype.replace("Townhomes,","");
			 note="Now Preselling";
			 latLng[0]="33.6684456";
			 latLng[1]="-79.0098849";
			
		}
		
		if (commUrl.contains("http://www.seasonsmi.com")){
		
			proptype=proptype+",Townhomes,Luxury Homes";
		}
		if(commUrl.contains("http://www.seasonsmi.com")){
		commName="Seasons At Prince Creek";
		propstatus="Selling Out Fast,Move in Ready Homes";
		}
		if(add[0].trim().length()<4 || add[3].length()<4)
		{
			latLng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLng);
			flag="TRUE";
		}
		if(commUrl.contains("http://thehomesatmarketcommon.com")){
			add[0]="3038 Nevers Street";
		U.log(add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		dtype="2 Story";
		proptype="Single family,Traditional Homes,Townhomes,HOA,Courtyard Homes";
		flag="FALSE";
		}
		if(propstatus == ALLOW_BLANK)
			propstatus = "New Homes Available";
		else
			propstatus = propstatus+", New Homes Available";
		
		if(commUrl.contains("http://dockstreetcommunities.com/wp-content/uploads/2016/05/15-DSC-1069_Cascades-at-World-Golf-Village-PDF.compressed.pdf"))
		{
			note="Adress And Latlong Taken From City And State";
		}
		
		// Add All
		//if(commUrl.contains("http://www.seasidetownhomes.com"))add[0]="Take Highway Us 17 North From Myrtle Beach For Approximately 30 Miles. At The Intersection Of Nc 904 And Highway Us 17 Take A Right At The Traffic Light. Proceed East On Nc 904 For Approximately Two Miles To The Intersection Of Nc 904 And Nc 179 (Sunset Boulevard). At The Traffic Signal Turn Right Onto Nc 179 (Sunset Boulevard) And Continue For .25 Mile To Queen Anne Street And Turn Right Into Seaside Village At Sunset Beach";
		//if(commUrl.contains("http://www.stjamestownhomes.com"))add[0]="Take Highway Us 17 Bypass North From Highway 501 To The Traffic Light At The Intersection Of 29th Avenue North And Highway Us 17 Bypass. Turn Right At The Traffic Light Onto 29th Avenue North And Continue To Robert Grissom Parkway. Take A Left Onto Robert Grissom Parkway. St. James Square Is Located Across From Eagle Crest.";
		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(note);
	}
}