/**
 *Author Name-Gourav Gujar
 * 
 */
package com.shatam.b_301_324;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLCHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int j = 0;
	static String BASEURL = "https://www.lchomesde.com";
	HashMap< String, String> mainLatLngSec = new HashMap<>();
	WebDriver driver=null;

	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractLCHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "LC Homes.csv", a.data().printAll());
	}

	public ExtractLCHomes() throws Exception {
		super("LC Homes", BASEURL);
		LOGGER = new CommunityLogger("LC Homes");
	}

	public void innerProcess() throws Exception {

		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam-10/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		//driver = new ChromeDriver(capabilities);
		 
	//	String html = getHTMLwithProxy("https://www.lchomesde.com/find-your-home");
		String html=U.getHtml("https://www.lchomesde.com/find-your-home", driver);
		
		//------for finding com-lnglng------
		for(String LLSec : U.getValues(html, "itemName: \"Work\",", "}")){
//			mainLatLngSec.put(U.getSectionValue(LLSec, "<h2>", "</h2>"), LLSec);
			mainLatLngSec.put(U.getSectionValue(LLSec, "'&lt;h2&gt;", "&lt;/h2&gt;'"), LLSec);

		}
		
		
		//---------For finding comsec with comUrls
		String urls_Section = U.getSectionValue(html, "<div class=\"listing-max\">", "<div class=\"listing-map\"");

		String urls_communitynames[] = U.getValues(urls_Section, "<a ", "</a>");
		U.log("Total community :  " + urls_communitynames.length);
		for (String url_community : urls_communitynames) {
			// U.log("========"+url_community);
			String url = BASEURL + U.getSectionValue(url_community, "href=\"", "\"");
			// if(url.contains("rehoboth-crossing/"))
//			try {
				addDetails(url, url_community);
//			} catch (Exception e) {}
		}
		
		
		LOGGER.DisposeLogger();
		//try{driver.quit();}catch (Exception e) {}
	}

	public void addDetails(String url, String oldData) throws Exception {
//		 if(j>4)
		{
			U.log("count"+j+"URL: "+url);
	//		U.log(oldData);
			
//			if (!url.contains("https://www.lchomesde.com/find-your-home/lighthouse-view")) return;
			
			
			//if (!url.contains("https://www.lchomesde.com/find-your-home/big-oak"))return;
			if (data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
				return;
			}
//			if(url.contains("https://www.lchomesde.com/find-your-home/darley-green")) {
//				LOGGER.AddCommunityUrl(url+ "---------------------------------");
//				return;
//			}
			LOGGER.AddCommunityUrl(url);
			
		//	String html = U.getHTML(url);
		//	String html=U.getHTMLwithProxy(url);
			String html=U.getHtml(url, driver);
			// =================================Community
			// Name=======================================
			//U.log(oldData);
			String commName = U.getSectionValue(oldData, "title=\"", "\"");

			// ==================================Address
			// Sec========================================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latlng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String note = ALLOW_BLANK;
			String addsec = U.getSectionValue(oldData, "</span>--><span>", "</span>");
			U.log(addsec);
			addsec = addsec.replaceAll("Newark ", "Newark, ").replace(" Townsend ", ", Townsend, ")
					.replace("Drive Fenwick", "Drive, Fenwick").replaceAll(" REHOBOTH| Rehoboth", ", Rehoboth").replace("Court ", "Court, ").replace(" Way ", " Way, ").replace("Road ", "Road, ")
					.replace("Dr # 188 Milton", "Dr # 188, Milton");
			addsec = U.getCapitalise(addsec.toLowerCase());
			if (!addsec.contains(",")) {
				addsec = "105 Foulk Rd, Wilmington, DE 19803";
				note = "Address Taken From Contacts";
			}
			add = U.getAddress(addsec);
			U.log(Arrays.toString(add));

			String comLatLngSec = mainLatLngSec.get(commName);
			U.log(comLatLngSec);
			if(comLatLngSec != null){
				comLatLngSec = U.getSectionValue(comLatLngSec, "itemAddress: [", "]");
				latlng = comLatLngSec.split(", ");
			}
			U.log("Lalng is "+Arrays.toString(latlng));
			if (latlng[0] == ALLOW_BLANK && add[0] != null) {
				latlng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			String homeData = "";
//			String homSec = U.getSectionValue(html, "<div class=\"properties-slider btm-margin-lg\">",
//					"<div class=\"community-map clearfix\" ");
			String myHomesdata=U.getSectionValue(html, "<h2 class=\"hdr3 c2 center\">Explore Home Designs</h2>","Community Site Map");
			String myhomesData[]=U.getValues(myHomesdata, "<a href","</a>");
			String homeHtml=ALLOW_BLANK;
			String  homedata=ALLOW_BLANK;
			for(String myhome:myhomesData) {
				String homeUrl=BASEURL+U.getSectionValue(myhome, "=\"", "\"");
				//homeHtml=U.getHtml(homeUrl, driver);
				U.log("Home URL"+homeUrl);
				homeHtml+=U.getHTML(homeUrl);
						
				homedata+=" "+myhome;
			}
			/*if (homSec != null) {
				String[] homedata = U.getValues(homSec, "<a href=\"", "\"");
				for (String url1 : homedata) {
					String homeHtml =  U.getHTML("https://www.lchomesde.com" + url1);
					U.log("HOME URL: "+url1);
					homeData += U.getSectionValue(homeHtml, "<div class=\"property-hero-title\">", "<section id=\"property-model-elv\"");
				}
			}*/
			

			// =======================================Price And
			// SF=========================================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			homeData=homeData.replace("mid-$200s", "mid $200,000");
//			U.log(Util.matchAll(   html, "[\\w\\s\\W]{30}only 1 homesite[\\w\\s\\W]{30}", 0));
//			homeData=homeData.replace("<span>\\$d{3},900</span>", "");
			html = html.replaceAll("0s|0's|0K|0’s|0s|0s", "0,000");
			String price[] = U.getPrices(oldData + html+homeHtml ,
					"\\$\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}</span>|\\$\\d,\\d{3},\\d{3}(\\.)?\\d{2}|\\$\\d{3},\\d{3}|start in the low \\$?\\d{3},\\d{3}|STARTING AT \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|STARTING AT \\$\\d,\\d{3},\\d{3}|upper- \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|to \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|STARTING AT \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>|the \\$\\d{3},\\d{3}",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log(minPrice);
			U.log(maxPrice);

			String sqft[] = U.getSqareFeet((oldData + html+homedata+homeHtml).replace("47622", "4762"), "\\d,\\d{3} Total Square footage|\\d{4}Square Feet|\\d{4,5} Sqft", 0);
			String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			// ====================================Property
			// Type===========================================
			html=html.replace("luxurious new community", "luxury homes");
			homeData = homeData.replace("construction custom home", "Custom Homes").replaceAll("coastal home", "Coastal Style Homes");
			U.log("prppppp"+Util.match(homeHtml, "luxurious owner’s suite"));
			String proptype = U.getPropType((commName+oldData + html + homeData+homeHtml).replace("<span>Patio</span>", "Patio-style home").replaceAll("Villas\"|Townhomes for Sale Claymont|Canal Villas|realestate_communities", ""));
			if (url.contains("https://www.lchomesde.com/find-your-home/breakwater-beach")) proptype = "Custom Homes, Coastal Style Homes";
			
			U.log("Property Type: "+proptype);
			proptype = proptype.replace("Townhouse, Townhome", "Townhome");
			//U.log("MATCH: "+Util.matchAll(commName+(oldData + html + homeData), "\\w+ custom \\w+|\\w+ coastal \\w+", 0));
			
			
			// ====================================Communuity
			// Type========================================
			String communitytype = U.getCommunityType(html);

			// ====================================Derive prop
			// Type========================================
//			html = html.replace("first-floor owner", " 1 Story");
//			U.log(Util.matchAll(commName+(oldData + html + homeData), "[\\w\\s\\W]{30}villa[\\w\\s\\W]{30}", 0));

			homeData = homeData.replace(", 2 level villa ", ",2-story villa ");
			String dtype = U.getdCommType((html + homeData+homeHtml).replaceAll("floor|Floor|FLOOR", ""));
			// =====================================Status
			// Sec=============================================
			html=html.replace("Quick move-in homes allow","");
			String stat=ALLOW_BLANK;
			String[] datasec=U.getValues(oldData, "href=\"", "<div class=\"listing-addy\">");
			for(String sec:datasec) {
				if(sec.contains(url.replace("https://www.lchomesde.com/", "").trim())) {
					stat=sec.replaceAll("</span>MOVE-IN READY", " MOVE-IN READY");
				}
			}
//			U.log(stat);
			if(stat!=null) {
				stat=U.getSectionValue(stat, "<span class=\"move-in-quantity\">", "</div>");
//				U.log(stat);

			}
//			stat=stat.replaceAll("</span>", "");
			html=html.replace("fast-selling", "fast selling").replaceAll("We’re currently selling homes in Cedar| Quick Delivery homes|Quick Delivery Homes", "");
			
//			U.log(html);
			String propstatus = U.getPropStatus((html+stat+oldData).replace("Coming soon a lot home package", "").replaceAll("<br>", ""));
			U.log("STATUS: "+propstatus);
			U.log(Util.match(html+stat, "", 0));
			
//			U.log("MMM"+Util.matchAll((stat+oldData),"[\\w\\W\\s]{70}unit left[\\w\\W\\s]{70}",0));
			
			/*if (html.contains("</span>MOVE-IN READY</div>")) {
				if (propstatus.length() < 4) {
					propstatus="Move In Ready";
				} else {
					propstatus=propstatus+",Move In Ready";
				}
			}*/
			//U.log(homeData);
			propstatus = propstatus.replace("Only 1 Homesite remaining", "Only 1 Homesite Remaining");
			if(propstatus.contains("Now Open")&&propstatus.contains("Last Phase Now Open")) {
				propstatus=propstatus.replaceAll(", Now Open", "");
			}
			if(propstatus.contains("3 Lots Remaining")) propstatus = propstatus.replace(", 3 Lots Remaining", "");
//			if(url.contains("find-your-home/darley-green"))minPrice="$416,900";
			note=U.getnote(html.replace("Grove at pre-construction prices", ""));
			
			if(url.contains("https://www.lchomesde.com/find-your-home/lighthouse-view")) {
				communitytype="Waterfront Community";
		//		propstatus=
			}
				
//			if(url.contains("https://www.lchomesde.com/find-your-home/breakwater-beach")) propstatus="One Lot Left";
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);	
			data.addCommunity(commName, url, communitytype);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1].trim(), geo);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(propstatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);

		}
		j++;
	}
	
	public static String getHTMLwithProxy(String path) throws IOException {

	//	 System.setProperty("http.proxyHost", "104.130.132.119");
	//	 System.setProperty("http.proxyPort", "3128");
	//	 System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);

		//U.log("filename:::" + fileName);

		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		// int respCode = CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);
			
		{
			
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"20.47.108.204",8888));//"165.138.4.41",8080));//"198.229.231.13",8080));//"63.151.67.7",8080));//"23.225.92.19	",30022));//"216.228.69.202",32170));//"198.143.178.77",3128));//"66.82.22.79	",80)
			final URLConnection urlConnection = url.openConnection(proxy);

			// Mimic browser
			try {
				urlConnection
						.addRequestProperty("User-Agent",
								"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");
				urlConnection
						.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
				urlConnection.addRequestProperty("Accept-Language",
						"en-GB,en-US;q=0.9,en;q=0.8");
				urlConnection.addRequestProperty("Cache-Control", "max-age=0");
//				urlConnection.addRequestProperty("Connection", "keep-alive");
				// U.log("getlink");
				final InputStream inputStream = urlConnection.getInputStream();

				html = IOUtils.toString(inputStream);
				// final String html = toString(inputStream);
				inputStream.close();

				if (!cacheFile.exists())
					FileUtil.writeAllText(fileName, html);

				return html;
			} catch (Exception e) {
				U.log(e);

			}
			return html;
		}

	}
}