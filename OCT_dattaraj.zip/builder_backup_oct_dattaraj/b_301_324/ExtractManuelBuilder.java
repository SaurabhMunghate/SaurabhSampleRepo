/**
 * Modified by : Priti(Feb 2018)
 * @author Aditya.
 * Date- 29-05-2015
 * Date Modified-03-06-2015
 * 
 */

package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;

import org.apache.commons.collections.map.MultiValueMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractManuelBuilder extends AbstractScrapper{
	int i=0;
	CommunityLogger LOGGER;
	static String BASEURL="https://www.manuelbuilders.com/";
	public static void main(String[] args) throws Exception{
		AbstractScrapper a = new ExtractManuelBuilder();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"ManuelBuilders.csv", a.data().printAll());
	}
	public ExtractManuelBuilder() throws Exception {
		super("Manuel Builders",BASEURL);
		LOGGER=new CommunityLogger("Manuel Builders");
	}
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String,String>();
	public void innerProcess() throws Exception{
		String html=U.getHTML("https://www.manuelbuilders.com/communities");
        String[] communityList=U.getValues(html, "class=\"css-r1j2cr\"", "Visit Community");
        U.log(communityList.length);
        JsonParser jsonparser = new JsonParser();
        String removeScript=U.getSectionValue(html, "__PRELOADED_STATE__ = ", "</script>");
        if(removeScript==null) removeScript="";
//      FileUtil.writeAllText("/home/shatam12/Desktop/Desktop/data.txt", removeScript);
        JsonObject jObj=(JsonObject) jsonparser.parse(removeScript).getAsJsonObject().get("cloudData").getAsJsonObject();            
        JsonObject comJson = jObj.get("communities").getAsJsonObject();
        JsonObject planJson = jObj.get("plans").getAsJsonObject();
        
        for(Entry<String, JsonElement> ele : planJson.entrySet()) {
        	
        	JsonArray array = ele.getValue().getAsJsonObject().get("data").getAsJsonArray();
        	U.log("Plans/Quick Move in count :"+array.size());

        	for(JsonElement e : array) { 
        		String d=e.toString();
//        		U.log("ee======"+d);
        		String[] comms=null; 
    			if(d.contains("communityModelProperties")) {
    				comms= U.getValues(d, "{\"community\"", "}}");
    			}
    			else {
    				comms= U.getValues(d, "{\"community\"", "}");
    			}            	for(String com:comms) {
            		String comunityIn = U.getSectionValue(com, "\"", "\"");
//            		U.log("comunityIn=="+comunityIn);
        			plansData.put(comunityIn, e.toString());
            	}
        	}
        }
        
        JsonObject homeJson = jObj.get("homes").getAsJsonObject();
        
        String plans[]=U.getValues(planJson.toString(), "{\"@type\":\"ProductModel", "type\":\"plan\"");
        U.log("plans==="+plans.length);
        String homes[]=U.getValues(homeJson.toString(), "{\"@type\":\"SingleFamilyResidence", "type\":\"home\"}");
        U.log(homes.length);
        for(String home:homes) {
        	String communityIn =U.getSectionValue(home, "containedIn\":\"", "\"");
        	homesData.put(communityIn,home);
        }
/*        for (String plan : plans) {
        	String[] comms=U.getValues(plan, "{\"community\":", "}]");
        	for(String com:comms) {
        		String comunityIn = U.getSectionValue(com, "\"", "\"");
    			plansData.put(comunityIn, com);
        	}
		}
*/    
        U.log("plansData=="+plansData.size());
		U.log(homesData.size());
		String comSection[] = U.getValues(U.removeSectionValue(comJson.toString(), "\"unpublished\":[", "receivedAt\":"),"{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");

		for (String comSec : comSection) {
			//FileUtil.writeAllText("/home/shatam12/Desktop/Desktop/Data.txt", comSec);
			commDatas.put(U.getSectionValue(comSec, "\"sharedName\":\"", "\""), comSec);
			String commUrl="https://www.manuelbuilders.com/communities/"+U.getSectionValue(comSec, "addressLocality\":\"", "\"").toLowerCase().replace(" ", "-")+"/"+U.getSectionValue(comSec, "\"sharedName\":\"", "\"").replaceAll("ville-de-ct-gele", "ville-de-cote-gelee");//+U.getSectionValue(comSec, "\"url\":\"", "\",");
			addDetails(commUrl, comSec,plans);
		}
        LOGGER.DisposeLogger();
	}
	public void addDetails(String comUrl,String comSec,String[] plans) throws Exception{
		
		{
		U.log("Count :"+i);
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"**************REPEATED");
		}
		LOGGER.AddCommunityUrl(comUrl);
		
//		if(!comUrl.contains("https://www.manuelbuilders.com/communities/lafayette/la-cour-beausoleil-phase-ii"))return;
		
		U.log("comUrl: "+comUrl);
		U.log("CACHE:"+U.getCache(comUrl));
		String comHtml=U.getHTML(comUrl);
		comHtml=U.removeSectionValue(comHtml, "window.__PRELOADED_STATE_", "</script>");
//		U.log("comHTml"+comHtml);
		FileUtil.writeAllText("/home/shatam12/Desktop/data.txt", comHtml);
//		comHtml=U.getSectionValue(comHtml, "class=\"DetailHeader_info\"", "</style>");
		String comNameSec=U.getSectionValue(comSec, "\"modifier_email\":\"", "\"photos\":");
		String comName=U.getSectionValue(comNameSec, "\"name\":\"", "\"").replaceAll("Ville de Côté Gelée", "Ville De Cote Gelee");
		U.log("Community Name:"+comName);
//		U.log(">>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}223,200[\\s\\w\\W]{30}", 0));
		U.log("comSec:"+comSec);
		
		String comId = U.getSectionValue(comSec, "\"_id\":\"", "\"");
		//======ADDRESS & LATLNG=======
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="TRUE";
		
		String latlngSec=U.getSectionValue(comSec, "\"geoIndexed\":[", "]");
		latlng[0]=latlngSec.split(",")[1];
		latlng[1]=latlngSec.split(",")[0];
		U.log("latlng :"+Arrays.toString(latlng));

		add=U.getAddressGoogleApi(latlng);
		U.log("latlng :"+Arrays.toString(latlng));
		U.log("add :"+Arrays.toString(add));
		////====Quick=====
		ArrayList<String> homeData = (ArrayList<String>) homesData.get(comId);
		String homesecs = ALLOW_BLANK;
		int homesCount = 0; 
		if (homeData != null) {
			U.log("homes ==:"+homeData);
			for (String home : homeData) {
				homesecs += home;
				homesCount++;
			}
//			U.log("homescount :"+homeData.size());
			
			
		}
		
		U.log("homes :"+homesCount);
		
		//====FlorPlan=====
		String storySec=ALLOW_BLANK;
		ArrayList<String> planData = (ArrayList<String>) plansData.get(comId);
		String plansecs = ALLOW_BLANK;
		int planCount = 0;
		if (planData != null) {
			for (String plan : planData) {
//				U.log("homes ==:"+plan);
				plansecs += plan;
//				planCount++;
			}
		}	
		
		String commId=U.getSectionValue(comSec, "\"_id\":\"", "\",");
//		U.log("plans========"+plans.length);
		String plan_Data=ALLOW_BLANK;
		for(String plan : plans) {
//			U.log("plan====="+plan);
			if(plan.contains(commId)) {
				plan_Data+=plan;
				
				planCount++;
			}
//			break;
		}
//		String plans[]=U.getValues(comHtml, "<div class=\"PlanCard_wrapper\"", "</a></li></ul></div></div></div></div></div>");
//		U.log("plans=="+plans.length);
//		if(plans)
		
		
		U.log("planCount :::"+planCount);
//		U.log(plansecs);
//		if(plansecs.contains("Aden Farmhouse"))
//			U.log("FOUND");
		
		String desc=U.getSectionValue(comSec, "\"description\":\"", "\",");	
		
		
		//===Price===
		comHtml=comHtml.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
		String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
		String[] price=U.getPrices(comHtml, "\\$\\d{3},\\d{3}</span>|from \\$\\d{3},\\d{3}|priceHigh\":\\d{6}|\"priceLow\":\\d{6}|\"price\":\\d{6}", 0);
		minPrice = (price[0]==null)? ALLOW_BLANK:price[0];
		maxPrice = (price[1]==null)? ALLOW_BLANK:price[1];
		U.log("minPrice :"+minPrice+" maxPrice :"+maxPrice);

//		U.log(">>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Colston Craftsman[\\s\\w\\W]{30}", 0));
		
//		//===Sqft===
		String minsqft=ALLOW_BLANK,maxsqft=ALLOW_BLANK;
		comHtml=comHtml.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">", " ");
		comSec=comSec.replaceAll("com_sqftLow\":1557,", "");
		String[] sqft=U.getSqareFeet(comHtml, "\\d,\\d{3} SQ FT|\"sqftHigh\":\\d{4}|sqftLow\":\\d{4}|\"sqft\":\\d{4}", 0);
		minsqft = (sqft[0]==null)? ALLOW_BLANK:sqft[0];
		maxsqft = (sqft[1]==null)? ALLOW_BLANK:sqft[1];
		U.log("minsqft :"+minsqft+" maxsqft :"+maxsqft);
		
//		U.log(">>>>>>"+Util.matchAll(plansecs, "[\\s\\w\\W]{60}Cottage[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{100}1526[\\s\\w\\W]{30}", 0));

//		//=======Comm type
		String ctype=U.getCommType(comSec+desc);
//		//=======prop type
//		U.log(">>>>>>"+Util.matchAll(plansecs+homesecs+comHtml, "[\\s\\w\\W]{60}villa[\\s\\w\\W]{30}", 0));

		String ptype=U.getPropType((plansecs+homesecs+comHtml).replace("history of custom home building", "").replace("Creole Cottage", "").replaceAll("frenchi_greek_villa.jpg|Rosette Cottage|Jacques Cottage|Segura Cottag|rosette-cottage|jacques-cottage|segura-cottage-|Village|village|French, Creole Cottage", "")
				.replace(">Colston Farmhouse<", ">Colston Farmhouse Series<")
				.replace(">Colston Craftsman<", ">Colston Craftsman-style exterior<"));
//		
//		if(comUrl.contains("https://www.manuelbuilders.com/communities/lafayette/beau-savanne")||
//				comUrl.contains("https://www.manuelbuilders.com/communities/lafayette/la-cour-beausoleil-phase-ii")) {
//			
//			if(ptype!=ALLOW_BLANK)
//				ptype +=", Farmhouse Style Homes";
//			else
//				ptype +="Farmhouse Style Homes";
//		}

		
//		//=======D Comm type
		String dtype=U.getdCommType((plansecs+homesecs).replaceAll("stories\":1", "1 Story").replaceAll("stories\":2", "two-story"));
//		//=======prop sttaus
		String pstatus=U.getPropStatus((comSec+desc).replace("COMING SOON in 2022", "COMING SOON 2022")
				.replaceAll("PHASE 2 IS COMING SOON", "PHASE 2 COMING SOON").replaceAll("for 100% financing|<h2>Coming Soon!</h2>|span>Coming Soon! <", ""));
		
		int quickCount=0;
		if(comHtml.contains("Quick</span> Move-In Homes</h3>")) {
			comHtml=comHtml.replaceAll(" data-reactid=\"\\d+\"", "");
			String[] quickData=U.getValues(comHtml, "<div class=\"HomeCard_inner\"", "View<br/>Details");
			U.log("quickData=="+quickData.length);
			for(String quickHome : quickData) {
				if(!quickHome.contains("Under Contract")) {
					U.log("quickData=="+quickHome);

					quickCount++;
				}
			}
//			if(pstatus!=ALLOW_BLANK)
//			pstatus += ", Quick Move-In Homes";
//			else
//				pstatus = "Quick Move-In Homes";
		}
		
		
		
		U.log("quickCount=="+quickCount);
		if(quickCount>0 ) {
				if( pstatus!=ALLOW_BLANK  )
			pstatus += ", Quick Move-In Homes";
			else
				pstatus = "Quick Move-In Homes";
		}
		
//		U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}view[\\s\\w\\W]{30}",0));

		U.log("pstatus: "+pstatus);
		
		String count=ALLOW_BLANK;
		String startdt=ALLOW_BLANK;
		String enddt=ALLOW_BLANK;	
	//	if(comUrl.contains("https://www.manuelbuilders.com/communities/broussard/ville-de-cote-gelee")) maxPrice = ALLOW_BLANK;
		String note=U.getnote(comSec);
		data.addCommunity(comName, comUrl, ctype);
		data.addAddress(add[0].trim(),add[1].trim(),add[2].trim(),add[3].trim());
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		i++;
	}
	}
}