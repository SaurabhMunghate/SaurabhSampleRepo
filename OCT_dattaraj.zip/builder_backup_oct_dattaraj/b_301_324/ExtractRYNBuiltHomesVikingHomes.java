package com.shatam.b_301_324;

import org.jboss.netty.util.internal.jzlib.ZStream;

import com.shatam.b_261_280.ExtractNapolitanoHomes;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRYNBuiltHomesVikingHomes extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://www.rynbuilthomes.com";

	public ExtractRYNBuiltHomesVikingHomes() throws Exception {
		super("RYN Built Homes", builderUrl);
		LOGGER = new CommunityLogger("RYN Built Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRYNBuiltHomesVikingHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "RYN Built Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}

	@Override
	protected void innerProcess() throws Exception {

		String mainHtml = U.getHTML(builderUrl);

		String regionData = U.getSectionValue(mainHtml, "<li class=\"find-your-neighborhood \">", "</ul>");

		String[] regionSec = U.getValues(regionData, "<a href=\"", "\"");
		for (String region : regionSec) {

			String regionHtml = U.getHTML(builderUrl + region);

			String[] commSec = U.getValues(regionHtml, "community-list__column\" data-equalizer-watch>", "</div>");

			for (String com : commSec) {

				String comUrl = U.getSectionValue(com, "<a href=\"", "\"");
				comUrl = builderUrl + comUrl;

				getDetail(comUrl, com);
			}
		}
		
		LOGGER.DisposeLogger();
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
//		try {
//		if(!comUrl.contains("https://www.rynbuilthomes.com/listings/community/tri-cities-washington/southridge-estates-signature-series-kennewick-wa/"))return;
		
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			U.log(com);
			if(comUrl.contains("https://www.rynbuilthomes.com/listings/community/northern-idaho/coming-soon/")
					|| comUrl.contains("https://www.rynbuilthomes.com/listings/community/missoula-montana/coming-soon/")){
				LOGGER.AddCommunityUrl("500 Error===Return===== " +comUrl);
				return;
			}
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			String html = U.getHTML(comUrl);
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(html, "<title>", "|");
			communityName = U.getCapitalise(communityName.toLowerCase());
			communityName = communityName.replace("&#8217;", "'");
			U.log("community Name---->" + communityName);


			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<h3 class=\"heading\">Model Home Information</h3>", "</div>");
			
			if (addSec != null) {
				
				U.log("Adress:--" + addSec);
				
				U.log(addSec);
				add = U.getAddress(U.getNoHtml(addSec));

			}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
			String latSec = U.getSectionValue(html, "parseFloat", "]);");
			latLng[0] = U.getSectionValue(latSec, "('", "'),");
			latLng[1] = U.getSectionValue(latSec, "parseFloat('", "')");
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			
			// =========== Ready To Build ========================
			String allHomesData = ALLOW_BLANK;
		
			String buildSec = U.getSectionValue(html, "<h2>Ready To Build</h2>", "<h2>Ready To Own</h2>");
			String[] homeUrlSection = U.getValues(html, "<div class=\"column small-3 listing-list", "</a>");
			U.log("Total Homes : " + homeUrlSection.length);
			for (String homeUrl : homeUrlSection) {
				homeUrl = U.getSectionValue(homeUrl, "<a href=\"", "\"");
				U.log("homeUrl : " +homeUrl);
				String homeHtml = U.getHTML(builderUrl+homeUrl);
				if (homeHtml != null)
					allHomesData += U.getSectionValue(homeHtml, "<div class=\"listing-detail\">", "<div class=\"listing_photos\">") +
							U.getSectionValue(homeHtml, "<h2>Home Features</h2>", "</div>");
			}
	
			// ============Ready To Own ================
			
			String ownSec = U.getSectionValue(html, "<h2>Ready To Own</h2>", "<footer class=\"site-footer-a\">");
			String quickHomeSection[] = U.getValues(ownSec, "<div class=\"column small-3 listing-list", "</a>");
			String combinedQuickHtmls = null;
			int soldCount = 0;
			for (String quickHomeSec : quickHomeSection) {
				String quickUrl = U.getSectionValue(quickHomeSec, "<a href=\"", "\"");
				U.log("QuickUrl :" + quickUrl);
				String quickHtml = U.getHTML(builderUrl+quickUrl);
				
				if(quickHtml.contains("<div class=\"callout warning\">SOLD!</div>"))
					soldCount++;
				
				combinedQuickHtmls += U.getSectionValue(quickHtml, "<div class=\"listing-detail\">", "<footer class=\"site-footer-a\">");
			}
			
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("0s", "0,000"); 
			String prices[] = U.getPrices(com + html+allHomesData+combinedQuickHtmls,
					"<div class=\"price\">\\$\\d{3},\\d{3}</div>|<div class=\"listing-detail__price\">\n\\s+\\$\\d{3},\\d{3}</div>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			if(combinedQuickHtmls != null) combinedQuickHtmls = combinedQuickHtmls.replaceAll("Potential to finish \\d+", "");
			if(allHomesData != null) allHomesData = allHomesData.replaceAll("Potential to finish \\d+", "");
			
			html = html.replaceAll("Homes (under|over) \\d+ SF: \\d+ gallon|Homes over \\d+ SF: \\d+-gallon electric hybrid water heater|Homes under \\d+ SF: \\d+-gallon gas water heater", "");
			
			String[] sqft = U.getSqareFeet(com + html+allHomesData+combinedQuickHtmls,
					"\\d{4} SF|<li>\\d{4} square feet</li>",0);
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================

			String proptype = U.getPropType((html + com + allHomesData+communityName));
			// ==================================================D-Property
			// Type======================================================
			
			String dtype = U.getdCommType((html + com + allHomesData).replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName + combinedQuickHtmls);

			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>", "");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			
			
			String pstatus = U.getPropStatus((html + com)); //replace("HOMES COMING SOON", ""
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html + com, "[\\s\\w\\W]{30}New Phase Now Available[\\s\\w\\W]{30}", 0));
			
			if(quickHomeSection.length > 0 && quickHomeSection.length > soldCount){
				if(!pstatus.contains("Ready To Own")){
					if(pstatus == ALLOW_BLANK) pstatus = "Ready To Own";
					else if(pstatus != ALLOW_BLANK) pstatus += ", Ready To Own";
				}
			}
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(comUrl.contains("https://www.rynbuilthomes.com/listings/community/tri-cities-washington/southridge-estates-signature-series-kennewick-wa/"))
			{
				pstatus=pstatus.replace(", New Phase", ", Now Released");
				proptype=proptype+", Estate-Style Homes";
			
		}

			//=========================================================================================================================
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

		}
		j++;
//		}catch(Exception e){}

	}

}
