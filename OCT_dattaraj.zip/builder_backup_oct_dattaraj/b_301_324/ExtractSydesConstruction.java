package com.shatam.b_301_324;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.internal.seleniumemulation.GetHtmlSource;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.net.URL;
//import java.util.Arrays;
//import java.util.HashMap;
//
//import org.openqa.selenium.Proxy;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.remote.DesiredCapabilities;
//
//import com.shatam.scrapper.AbstractScrapper;
//import com.shatam.utils.CommunityLogger;
//import com.shatam.utils.FileUtil;
//import com.shatam.utils.U;

public class ExtractSydesConstruction extends AbstractScrapper {
	static String BASEURL = "https://www.asydesconstruction.com";
	CommunityLogger LOGGER;
	static int i;
	static int j= 0 ;
	WebDriver driver=null;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSydesConstruction();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"A Sydes Construction.csv", a.data().printAll());
		
	}
	HashMap<String, String> inventoryHomesdata=new HashMap<String,String>();
	public ExtractSydesConstruction() throws Exception {

		super("A Sydes Construction", BASEURL);
		LOGGER = new CommunityLogger("A Sydes Construction");
	}
	
	
//	private WebDriver setProxy(String ip, String port){
//		Proxy proxy = new Proxy(); 
//		proxy.setHttpProxy(ip+":"+port); 
//		proxy.setSslProxy(ip+":"+port); 
//
//		DesiredCapabilities capabilities = DesiredCapabilities.chrome(); 
//		capabilities.setCapability("proxy", proxy); 
//
//		ChromeOptions options = new ChromeOptions(); 
//		options.addArguments("start-maximized"); 
//
//		capabilities.setCapability(ChromeOptions.CAPABILITY, options); 
//
//		return new ChromeDriver(capabilities);
//		
//	}
	public void innerProcess() throws Exception {
		
		U.setUpChromePath();
		ChromeOptions options1 = new ChromeOptions();
		options1.addExtensions (new File("/home/shatam-10/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options1);
		//driver = new ChromeDriver(capabilities);
	 
		
		 String html = U.getHtml("https://www.asydesconstruction.com/communities",driver);

		String[] comSections = U.getValues(html, "class=\"community-overlay\">","</div>");
	    U.log("length "+comSections.length);
		
		
//		 U.log(urls_section);
//		String inventoryHomeData=U.getHTMLwithProxy("https://www.asydesconstruction.com/inventory");
		String inventoryHomeData=U.getHtml("https://www.asydesconstruction.com/inventory",driver);

		String optionSec=U.getSectionValue(inventoryHomeData, "<option value=\"all\">", " </select>");
//		U.log("=="+optionSec);
		String[] options=U.getValues(optionSec, "<option", "option>");
		for (String opt : options) {
//			U.log(opt);
			String key=U.getSectionValue(opt, "\">", "<");
//			U.log(key);
			String id=U.getSectionValue(opt, "value=\"", "\"");
//			U.log(id);
			String invHomes[]=U.getValues(inventoryHomeData, "lass=\"col-lg-3 col-md-4 col-sm-6 col-xs-12 inventory comm_"+id+"\">", "</a>");
//			U.log(invHomes.length);  //"+id+"\">
			if (invHomes.length!=0) {
				String val=Arrays.toString(invHomes);
//				U.log("val"+val);
				inventoryHomesdata.put(key, val);
//				break;
			}
		}
 
		for (String cSec : comSections) {
			
			String cUrl = "https://www.asydesconstruction.com"+U.getSectionValue(cSec, "<a class=\"community-btn\" href=\"", "\"");
			//U.log("cSec : "+cSec);
//			U.log("cUrl : "+cUrl);

//			try {
				addDetails(cUrl,cSec);
//			} catch (Exception e) {}
			
			//break;
		}
		LOGGER.DisposeLogger();
		//driver.quit();
	}
//	
//	//TODO:
	public void addDetails(String commUrl,String comSec) throws Exception {
//		if(j >= 17)
		{
		// ............................Community Url...........................
		//U.log("Page Url: " + commUrl);	
			
//			if(!commUrl.contains("https://www.asydesconstruction.com/communities/paradise-point-at-onslow-bay")) return;
		
		if (data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+ "----------------------- Repeat");
			return;
		}	
		LOGGER.AddCommunityUrl(commUrl);
		// ...........................Community Name...........................
		U.log("===>"+j);
		U.log(commUrl);
//		String html = U.getHTMLwithProxy(commUrl);
		String html = U.getHtml(commUrl,driver);

		U.log(U.getCache(commUrl));
		String commName = U.getSectionValue(html, "<title>", "</title>");
//		if(commName==null)
//			commName = U.getSectionValue(html, "<title>", "</title>");
		
	if(commUrl.contains("https://www.asydesconstruction.com/communities/camden-woods"))commName="Camden Woods";
//	if(commUrl.contains("https://www.asydesconstruction.com/communities/bendigo-bay-at-bluewater-rise"))commName="Bendigo Bay At Bluewater Rise";
	if(commUrl.contains("https://www.asydesconstruction.com/communities/paradise-point-at-onslow-bay")) commName="Paradise Point At Onslow Bay";
	
		U.log("commName : "+commName);

		//floor plan data
		String allHOmesData=ALLOW_BLANK;
		if(html.contains("<li class=\"col-md-3 col-sm-6 col-xs-12 \">")){
			String homes[]=U.getValues(html, "<li class=\"col-md-3 col-sm-6 col-xs-12 \">", " </li>");
			for(String home:homes){
				String url=U.getSectionValue(home, "href=\"", "\"");
				U.log("homeUrl : https://www.asydesconstruction.com/"+url);
				if(url.endsWith("/home-plans/"))continue;

//				String hhtml =U.getHTMLwithProxy("https://www.asydesconstruction.com/"+url);
				String hhtml =U.getHtml("https://www.asydesconstruction.com/"+url, driver);

				allHOmesData += U.getSectionValue(hhtml, "<div class=\"col-sm-12 text-left title\">", "<footer id=\"footer_five\">");
			}
		}
		//------------------------Price-------------------
	
		
//		String invHomes="";
		//String[] mvHome=null;
//	int qcount=0,underConstr=0;
//		if (inventoryHomesdata.containsKey(commName)) {
//			U.log("indide"+commName);
//			invHomes=inventoryHomesdata.get(commName);
//			
//			//U.log("+qHome"+invHomes);
//			ArrayList<String> mvHome=Util.matchAll(invHomes, "Under Construction|Sold", 0);
//			Iterator it=mvHome.iterator();
//			qcount++;
////			if(invHomes.contains("Under Construction")||invHomes.contains("Sold")) {
////				underConstr++;
////			}
////		
//		}
//		
//		U.log("qHome=="+qcount);
//		U.log("underConstr=="+underConstr);
		
		
		int i=0;
		String invHomes="";
		if (inventoryHomesdata.containsKey(commName)) {
			invHomes=inventoryHomesdata.get(commName);
//			U.log(invHomes);
			
		}
		int qcount=0,underConstr=0;
		String[] quickHomeData=U.getValues(invHomes, "<a class=\"community-wrapper\" data-mh=\"inventory\" ", "Lot #");
		for(String qHome:quickHomeData) {
			if(qHome.contains("Under Construction")||qHome.contains("Sold"))
				underConstr++;
			if((qHome.contains("Model")||qHome.contains("Move-In Ready"))&& !qHome.contains("img src=\"/images/cropped_sutton_rvt_2018-jul-19_05-05-37pm-000_3d_view_4_jpg_web_1532022005.jpg\"") )
				qcount++;
			
		}
		
		
		
		U.log("i ======= "+i);

		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] prices = U.getPrices(comSec+invHomes,"Starting at: \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d+,\\d+</div>",0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
	
		U.log("prices="+minPrice+" "+maxPrice);
		//--------------------Sqft--------------------
		//html=html.replaceAll("<div class=\"sqft\">\\s*Sq. Ft.\\s*<span>2,013 - 2,618</span>\\s*</div>", "\\d{1},\\d{3} - \\d{1},\\d{3} square feet");
	
		String detail = U.getSectionValue(html, "<div class=\"community-detail-info\">", "Directions</a>");
//		U.log(detail);

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String[] sqFt = U.getSqareFeet(comSec+invHomes+detail, "Sq\\.\\s*Ft\\.\n\\s*<span>\\d{4}-\\d{4}</span>|Sq. Ft.</span> \\d,\\d{3}</div>|<span>\\d,\\d+ Sq. Ft.</span>|Sq. Ft.\\s*<span>\\d{4}-\\d{4}</span>|Sq. Ft.\\s*<span>\\d,\\d{3} - \\d,\\d{3}\\s*</span>|\\d{4} square feet|Sq. Ft.\\s*<span>\\d,\\d{3}</span", 0);
		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("Sqrfeet="+minSqft+" "+maxSqft);
		
		//U.log(">>>>>>>>>>>>"+Util.matchAll(invHomes, "[\\s\\w\\W]{60}1,800[\\s\\w\\W]{60}", 0));
		
		// -------------Address-----------------
		String flag ="false";
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		
		
		String addSection = U.getSectionValue(html, "<a class=\"directions\" href=\"https://www.google.com/maps/dir/", "\" target=\"");
		if(addSection!=null){
			addSection = addSection.replace("+NC", ",NC").replace("+Jacksonville", ", Jacksonville").replace("+", " ").replace("Rocky Point", ",Rocky Point").replace("Sneads Ferry", ",Sneads Ferry").replace("Surf City", ",Surf City");
		
			addSection = addSection.replace("%2C", "").replace("Suite C Holly Ridge North Carolina", "Suite C, Holly Ridge, NC");
			addSection = U.formatAddress(addSection);
		U.log("addSection : "+addSection);
		add = U.getAddress(addSection);
		}
		U.log("address is =: "+Arrays.toString(add));
		// ------------LatLng--------------
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String latLngSec = U.getSectionValue(html, "setView([", "]");
		U.log("latLngSec : "+latLngSec);
		if(latLngSec != null){
			latLng = latLngSec.split(",");
		}
		U.log("lat lng is =: "+Arrays.toString(latLng));
		if(latLng[1].contains("-77479833")) {
			U.log("hello");
			latLng[1]="-77.479833";
		}
		
		if(add[0].length()<4 && latLng[0].length()>4){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add =U.getAddressHereApi(latLng);
			flag="true";
		}
		
		if(commUrl.contains("https://www.asydesconstruction.com/communities/everett-place-at-onslow-bay")) {
			add[1]="Jacksonville";
			add[2]="NC";
			add[3]="28546";
			latLng=U.getlatlongGoogleApi(add);
			add[0]=U.getAddressGoogleApi(latLng)[0];
			flag="true";
		}///bcz latalong is showing address in lake
		U.log("m ADD== "+Arrays.toString(add));
		U.log("m lattlng== "+Arrays.toString(latLng));
		//----------Community Type-----------
		String communityType = U.getCommunityType(html);

		//----------Property Type-----------
		html = html.replace("custom features throughout", "custom homes features throughout");
		String propType = U.getPropType((html+allHOmesData)
				.replace("-manor\"", "")
				.replace("Mackerel Manor</div>", "").replaceAll("Village|village|Customer Care &amp", ""));
		U.log(Util.matchAll(html+allHOmesData, "[\\w\\s\\W]{30}manor[\\w\\s\\W]{30}", 0));
		//-----------Derived Type-----------
		//U.log(Util.matchAll(html, "[\\w\\s\\W]{30}custom[\\w\\s\\W]{30}", 0));

		allHOmesData=allHOmesData.replace("Levels: 1.5 ", " 1.5 Story ").replace("Levels: 2", " 2 Story ").replace("Levels: 1 ", " 1 Story ");
		allHOmesData=allHOmesData.replaceAll("Levels: ", "story ");
		allHOmesData = allHOmesData.replaceAll("\\s*</div>", "</div>");
	//	U.log(Util.matchAll(html, "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}", 0));

		//U.log(Util.matchAll(allHOmesData, ".*?Stories 1.*",0));
		String dType = U.getdCommType(html.replace("Branch", "")+allHOmesData.replace("Levels: 1", "1 story"));
		if(!allHOmesData.contains("Stories 1</div>"))dType = dType.replaceAll("1 Story, ", "");
		if(allHOmesData.contains("1 Story</div></div>")&& !dType.contains("1 Story"))dType = "1 Story, "+dType;
		U.log(dType);
		
		//----------Property Status-------------
		html=html.replaceAll("Move-in Ready Homes|move-in-ready|move-in ready|<i>Move In Ready Homes</i><|View All Move In Ready Homes|<a title=\"Move-in Ready Homes\" href=\"/move-in-ready\">Move-in Ready Homes</a>", "");


//		U.log("chk"+Util.matchAll(html, "[\\w\\s\\W]{50}move-in ready[\\w\\s\\W]{50}", 0));
		String propStatus = U.getPropStatus(html);
		
		
		String moveinSec="";
		String[] moveIHomes=null;
		int quickCount=0;
		int noOfHomes=0;
		try {
//		moveinSec=U.getSectionValue(html, "<div id=\"move-in-ready-wrapper\">", "</ul>");
//		moveIHomes=U.getValues(moveinSec, "<li class=\"col-md-3 col-sm-6 col-xs-12", "</li>");
		moveIHomes=U.getValues(html, "<a class=\"inventory-wrapper\"", "</li>");
//		
//		for(String qhome:moveIHomes) {
//			if(qhome.contains("Under Construction"))
//		}
		}
		catch(NullPointerException ne) {}
//		if(!html.contains("data-mh=\"inventory\"")) {
//			propStatus=propStatus.replace("Move-in Ready Homes", ALLOW_BLANK);
//		}
//		propStatus=propStatus.replace("Move-in Ready", " ");
		
		U.log("qcount="+qcount);
		U.log("underConstr="+underConstr);

		if(moveIHomes!=null&&moveIHomes.length>0 && (qcount>0)) {
		//	if(html.contains("href=\"/move-in-ready/"))
				if(propStatus==null||propStatus.length()<3 && !propStatus.contains("Move-in Ready")) {
					propStatus="Move-in Ready";
				}
				else {
					if(propStatus.contains("Move-in Ready")) {
						propStatus=propStatus+"";
					}else {
					propStatus=propStatus+", Move-in Ready";
					}
				}
		}
		if(commUrl.contains("/communities/summerhouse-on-everett-bay"))flag="True";
		if(commUrl.contains("/the-burroughs-at-carolina-plantations"))minPrice="$117,000";
		LOGGER.countOfCommunity(i);
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"++++++++++++repeated");
			return;
		}
		
		if((commUrl.contains("https://www.asydesconstruction.com/communities/atlantic-cove-at-onslow-bay")))
			flag="TRUE";
		
		if((commUrl.contains("https://www.asydesconstruction.com/communities/fenwick-isle-at-bluewater-rise")))
			flag="TRUE";
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		
		LOGGER.AddCommunityUrl(commUrl);

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(commName, commUrl, communityType);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(ALLOW_BLANK);
		
		
	}j++;
	}

}