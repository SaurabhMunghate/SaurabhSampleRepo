package com.shatam.b_301_324;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWciTampa extends AbstractScrapper{
	static String builderName="WCI Tampa", builderUrl="https://wcitampabay.com";
	private CommunityLogger LOGGER;
	public static void main(String[] args)  throws Exception {
			AbstractScrapper abs=new ExtractWciTampa();
			abs.process();
			FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abs.data().printAll());
	}
	public ExtractWciTampa() throws Exception {
		super(builderName, builderUrl);
		LOGGER=new CommunityLogger(builderName);
	}

	@Override
	protected void innerProcess() throws Exception {
		String mainHtml=U.getHTML(builderUrl);
		String comSecs[]=U.getValues(mainHtml, "<div class=\"commid\">", "VIEW COMMUNITY</a>");
		for (String comSec : comSecs) {
//			U.log(comSec);
			String commUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
//			commUrl=U.getRedirectedURL(builderUrl, commUrl);
			U.log(commUrl);
			
				addDetails(commUrl,comSec);
			
//			break;
		}
		LOGGER.DisposeLogger();
	}
	private void addDetails(String commUrl, String comSec) throws Exception{
//		if (!commUrl.contains("https://wcicordoba.com/")) return;
		{
		
		String featuhtml="";
		String floorPlan="";
		String floorPlan1="";
		String avaHome="";
		if(!commUrl.contains("https://wcitampabay.com/c/monterey-villas-at-waterside/") && !commUrl.contains("https://wcitampabay.com/c/monterey-estates-at-waterside/")) {
			String wrongHtml=U.getHTML(commUrl);
			
			if(wrongHtml.contains("window.location.replace")) {
				commUrl=U.getSectionValue(wrongHtml, "window.location.replace('","')").replace("http:", "https:");
				U.log("url::> "+commUrl);
				String tempHtml=U.getHTML(commUrl);
				U.log(U.getCache(commUrl));
				floorPlan=U.getSectionValue(tempHtml, "<div class=\"hero-content\">", "</main>");
				floorPlan1=U.getHTML(commUrl+"/floorplans/");
				avaHome=U.getHTML(commUrl+"/available-now/");
				
				String sec=U.getSectionValue(tempHtml, "<nav class=\"nav\">","</nav>");
				if(sec!=null) {
				String[] alData=U.getValues(sec, "class=\"\">","<li ");
				featuhtml=U.getSectionValue(U.getHTML("https://wcicordoba.com/features/"),"<div class=\"hero-content\">", "</main>");
				}
			}
		}
		if(commUrl.contains("https://wcitampabay.com/c/monterey-villas-at-waterside/")) {
			commUrl="https://watersidewci.com/the-arbors-features/";
			String tempHtml=U.getHTML(commUrl);
			floorPlan=U.getSectionValue(tempHtml, "<div class=\"hero-content\">", "</main>");
			floorPlan1=U.getHTML(commUrl.replace("features", "floorplans"));
			avaHome=U.getHTML(commUrl+"available-homes/");
			String sec=U.getSectionValue(tempHtml, "<nav class=\"nav\">","</nav>");
			String[] alData=U.getValues(sec, "class=\"\">","<li ");
		}
		if(commUrl.contains("https://wcitampabay.com/c/monterey-estates-at-waterside/")) {
			commUrl="https://watersidewci.com/the-estates-features/";
			String tempHtml=U.getHTML(commUrl);
			floorPlan=U.getSectionValue(tempHtml, "<div class=\"hero-content\">", "</main>");
			floorPlan1=U.getHTML(commUrl.replace("features", "floorplans"));
			String sec=U.getSectionValue(tempHtml, "<nav class=\"nav\">","</nav>");
			String[] alData=U.getValues(sec, "class=\"\">","<li ");
		}
		if(commUrl.contains("https://tarramorwci.com/")) commUrl = commUrl.replaceAll("/$", "");

		//TODO : For Single Community Execution
//		if (!commUrl.contains("https://wciestancia.com/santeri-villas-at-estancia/"))return;//Single Run
		
		if (this.data().communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl(commUrl+"---->Repeated");
			return;
		}
		if (commUrl.contains("lennar") || commUrl.contains("https://medleysouthshorebay.com/floorplan-the-villas/")) {
			LOGGER.AddCommunityUrl(commUrl+"---->Retun");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		U.log(commUrl);
//		U.log(comSec);
		String commHtml=U.getHTML(commUrl);
		//U.log(commHtml);
		String commName=U.getSectionValue(commHtml, "<h1 class=\"p2\" style=\"text-align: center;\">", "</h1>");
		if(commName==null) {
		commName=U.getSectionValue(commHtml, "<h1>", "</h1>");
		}
		if(commName==null) {
			commName=U.getSectionValue(commHtml, "<title>", "</title>");
			}
		
		commName=commName.replace("What's Nearby", "Tarramor");
		U.log(commName);
		String mainSec=U.getSectionValue(commHtml, "<div class=\"Index-page-content \">", "<div class=\"sqs-gallery\">");
		if (mainSec==null) {
			mainSec=U.getSectionValue(commHtml, "<div class=\"hero-content\">", "</main>");
		}
		String addSec=U.getSectionValue(commHtml, "Welcome Home Center</strong></p>", "</a>");
		U.log("aaaaaa"+addSec);
		if(addSec==null) {
			addSec=U.getSectionValue(commHtml, "Medley at Mirada<br>", "</a>");
		}
		if (addSec==null) {
			addSec=U.getSectionValue(commHtml, "Welcome Home Center<br />", "</p>");
			
		}
		if (addSec==null) {
			addSec=U.getSectionValue(commHtml, "<h3>Sales Gallery</h3>", "</p>");
		}
		if (addSec==null) {
			addSec=U.getSectionValue(commHtml, "<h3>Sales Gallery</h3>", "<h3 class=\"hours\">");
		}
		if (addSec==null) {
			addSec=U.getSectionValue(commHtml, "rel=\"noopener\">", "</p>");
		}
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		if (addSec==null) {
			addSec=U.getSectionValue(commHtml, "<h3>Welcome Home Center</h3>", "<h3 class=\"hours\">");
		}
		
		if (commUrl.contains("https://www.southportwci.com/") || commUrl.contains("https://www.southportwci.com/")) {
			addSec=U.getSectionValue(commHtml, "OPEN HOUSE<br>", "<br>(");
		}
		
		if (commUrl.contains("https://www.medleysouthshorebay.com")) {
			addSec=U.getSectionValue(commHtml, "<h3>WELCOME HOME CENTER</h3>", "</a>");
		}
		
		if (commUrl.contains("https://www.sanctuarycovefla.com")) {
			addSec=U.getSectionValue(commHtml, "<h3>Welcome Home Center</h3>", "</a>");
		}
		
		if (commUrl.contains("https://wcicordoba.com/") || commUrl.contains("https://www.promenadewci.com/") || commUrl.contains("https://tarramorwci.com")) {
			addSec=U.getSectionValue(commHtml, "<h3>Sales Gallery</h3>", "</a>");
		}
		if(commUrl.contains("https://wciestancia.com/santeri-villas-at-estancia/"))
			addSec = "4375 Barletta Court, Wesley Chapel, FL 33543";
		if (addSec!=null) {
			U.log(addSec);
			add=U.getAddress(U.getNoHtml(addSec.replaceAll("</p>\\s+<p>", ",").replaceAll("<br>|<br />", ",").replace("Wesley Chapel", ",Wesley Chapel").replace("Welcome Home Center", "").replace("&nbsp;", " ")));
		}
		String geo="FALSE";
		U.log("Add---> "+Arrays.toString(add));
		String latLon[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		latLon[0]=U.getSectionValue(commHtml, "data-lat=\"", "\"");
		latLon[1]=U.getSectionValue(commHtml, "data-lng=\"", "\"");
		if (latLon[0]==null&&addSec!=null) {
			latLon[0]=Util.match(addSec, "\\d{2}\\.\\d+");
			latLon[1]=Util.match(addSec, "-\\d{2,3}.\\d+");
		}
		
		if(commUrl.contains("https://www.southportwci.com/")) {
			
			latLon[0] = U.getSectionValue(commHtml, "mapLat&quot;:", ",");
			latLon[1] = U.getSectionValue(commHtml, "mapLng&quot;:", ",");
			geo = "FALSE";
		}
		if (commUrl.contains("southshoreyachtclubfla")) {
			commName="SouthShore Yacht Club";
		}
		if (commUrl.contains("wcicordoba")) {
			commName="Cordoba Estates";
		}
		if(commUrl.contains("https://tarramorwci.com")){
			floorPlan=U.getHTML("https://tarramorwci.com/floorplans/");
			floorPlan1=U.getHTML("https://tarramorwci.com/available-now/");
		}
			
		if (commUrl.contains("https://medleysouthshorebay.com")) {
			commName="Medley At Southshore Bay";
			add[0]="16875 Scuba Crest Street";
			add[1]="Wimauma";
			add[2]="FL";
			add[3]="33598";
			geo="FALSE";
			floorPlan=U.getHTML("https://medleysouthshorebay.com/floorplan-the-estates/");		
		}
		U.log("Add ::"+Arrays.toString(add));
		if (commUrl.contains("watersidewci")) {
			commName="Monterey Grand Waterside: "+U.getSectionValue(commHtml, "<h1 style=\"text-align: center;\">", "</h1>").replaceAll("Features", "");
			String locationHtml=U.getHTML("https://watersidewci.com/location/");
			latLon[0]=U.getSectionValue(locationHtml, "data-lat=\"", "\"");
			latLon[1]=U.getSectionValue(locationHtml, "data-lng=\"", "\"");
			addSec=U.getSectionValue(commHtml, "<h3>Sales Gallery</h3>", "</p>").replace("<br />", ",");
			addSec=U.getNoHtml(addSec);
			U.log(addSec);
			add=U.getAddress(U.getNoHtml(addSec.replaceAll("<br>|<br />", ",")));
		}
		if (commUrl.contains("sanctuarycovefla")) {
			commName="Sanctuary Cove ";
			String locationHtml=U.getHTML("https://www.sanctuarycovefla.com/location/");
			latLon[0]=U.getSectionValue(commHtml, "data-lat=\"", "\"");
			latLon[1]=U.getSectionValue(commHtml, "data-lng=\"", "\"");
			geo = "FLASE";

		}
		if (commUrl.contains("https://inletpark.com")) {
			commName="Inlet Park";
			String locationHtml=U.getHTML("https://inletpark.com/location/");
			latLon[0]=U.getSectionValue(locationHtml, "data-lat=\"", "\"");
			latLon[1]=U.getSectionValue(locationHtml, "data-lng=\"", "\"");

		}
		if(commUrl.contains("medleymirada.com")){
			mainSec = commHtml;
			latLon = "28.3281058!4d-82.2991644".split("!4d");
		}

		
		if (commUrl.contains("https://www.meridianwci.com/")) {
			commName="Meridian at Meadow Pointe";
			}
		
		if (commUrl.contains("https://www.promenadewci.com/")) {
			commName="The Promenade At Lake Park";
			}
		if (latLon[0]==null) {
			latLon=U.getlatlongGoogleApi(add);
			if(latLon == null) latLon = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if (add[1].length()<3 && latLon[0]!=null) {
			add=U.getAddressGoogleApi(latLon);
			if(add == null) add = U.getAddressHereApi(latLon);
			geo="TRUE";
		}
		U.log("LatLon---> "+Arrays.toString(latLon));
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String prices[]=U.getPrices((mainSec+comSec+floorPlan+floorPlan1).replaceAll("0s", "0,000"), "<li>PRICED FROM : \\$\\d{3},\\d{3}</li>|<li>PRICE FROM: \\$\\d{3},\\d{3}</li>|UPPER \\d{3},\\d{3}|LOW \\d{3},\\d{3}|<li>PRICED FROM: \\$\\d{3},\\d{3}</li>|MID \\d{3},\\d{3}|PRICE FROM:</td><td>\\$\\d{3},\\d{3}</td>|the mid \\$\\d{3},\\d{3}", 0);
		U.log(Arrays.toString(prices));
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String sqft[]=U.getSqareFeet(mainSec+comSec+floorPlan+floorPlan1, "from \\d,\\d{3}–\\d,\\d{3} square feet|from \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} square feet|<li>SQUARE FOOTAGE: \\d,\\d{3}</li>|<br>\\d,\\d{3} - \\d,\\d{3} SQ. FT.|FOOTAGE:</td><td>\\d,\\d{3}</td></tr>", 0);
		U.log(Arrays.toString(sqft));
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		//================ Derived Community Type ====================
		String dCommType=U.getdCommType((mainSec+floorPlan+floorPlan1).replace("STORIES:</td><td>1</td>", "STORIES: 1</td>").replace("STORIES:</td><td>2</td>", "STORIES: 2</td>").replace("STORIES:</td><td>3</td>", "STORIES: 3</td>").replace("ranch ", "")+comSec);
		//================ Community Type ====================
		String commType=U.getCommType(mainSec+comSec);
		//================ prop Type ====================
		String propType=U.getPropType((mainSec+comSec+featuhtml+floorPlan).replace("carriage", ""));
		//================ prop Type ====================
		String propStatus=U.getPropStatus(mainSec+comSec);
		
		if(commUrl.contains("https://tarramorwci.com")){
			minPrice = "$400,000";
			//propStatus = "Grand Opening"; // Pop Up Msg. Img
		}
		
		if(commUrl.contains("https://watersidewci.com/the-arbors-features/") || commUrl.contains("https://watersidewci.com/the-estates-features/")) commType = commType + ", Lakefront Community";
//		if(commUrl.contains("https://tarramorwci.com"))minPrice = "$400,000";

		data.addCommunity(U.getNoHtml(commName), commUrl, commType);
		data.addAddress(add[0].replace(",", "").trim(), add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLon[0], latLon[1], geo);
		data.addPropertyType(propType, dCommType);
		data.addPropertyStatus(propStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(mainSec));
	}
	}
}
