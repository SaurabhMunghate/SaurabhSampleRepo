/*
 * @author : Pallavi
 * @date : 27/04/2019
 */
package com.shatam.b_301_324;

import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.shatam.utils.USStates;

public class ExtractYourViewHomes extends AbstractScrapper{
	int i = 0;
	WebDriver driver;
	public static CommunityLogger LOGGER;
	private static final String BUILDER_URL = "https://yourviewhome.com";
	public ExtractYourViewHomes() throws Exception {
		super("View Homes", "https://yourviewhome.com/");
		LOGGER = new CommunityLogger("View Homes");
		

	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractYourViewHomes();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"View Homes.csv", a.data()
						.printAll());
		LOGGER.DisposeLogger();	
	}
	
	static HashMap<String, String> latlongMap = new HashMap<String, String>();
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
		U.setUpChromePath();
		driver=new ChromeDriver();
		String html = U.getHTML("https://yourviewhome.com/");
		
		String regUrlSections=U.getSectionValue(html,"<div class=\"nav-mega\">", "id=\"nav-mega-page-2\">");

		//"<div class=\"section--regions\">", "</section>");
		
		if(regUrlSections != null){
			String regUrlSection[] = U.getValues(regUrlSections, "<li class=\"heading\">", "</a>");
			for(String regUrlSec : regUrlSection){
				String[] regUrls=U.getValues(regUrlSec, "<a href=\"", "\"");
				for(String regUrl : regUrls){
					U.log("Region Url ::: "+regUrl);
					String regHtm=U.getHTML(regUrl);
					
					//---------------------LATLONG FROM REGION--------------------
					if(regHtm.contains("var communitiesData =")) {
						
						U.log("JSON LATLONG PRESENT ---------- ");
						
						String regionJson = U.getSectionValue(regHtm, "var communitiesData =", ";");
						//FileUtil.writeAllText("/home/shatam-10/Desktop/data/regionJson.txt", regionJson);
						
						JsonParser json = new JsonParser();
						JsonArray comArray = json.parse(regionJson).getAsJsonArray();	
						
						U.log("comArray size: "+comArray.size());
						
						for(JsonElement com:comArray) {
							
							//U.log("com: "+com.toString());
							String community = com.toString();
							
							String latitude = U.getSectionValue(community, "latitude\":\"", "\",");
							String longitude = U.getSectionValue(community, "longitude\":\"", "\",");
							String comUrl = "https://yourviewhome.com" + U.getSectionValue(community, "url\":\"", "\",");
							
							String latLongSec = latitude + ", " + longitude;
							
							//U.log("latitude: "+latitude+ " longitude: "+longitude+ " comUrl: "+comUrl);
							
							latlongMap.put(comUrl, latLongSec);
							
						}
						
					}
					
					U.log("latlongMap size: "+latlongMap.size());
					//-----------------------------------------------------------------------------------
					
					String comSection[] = U.getValues(regHtm, "<div class=\"item item-listing community\"", "Learn More</a>");
					U.log(comSection.length);
					
					for(String comSec : comSection){
						
						//U.log("comSec: "+comSec);
						
						String url = U.getSectionValue(comSec, "<a href=\"", "\"");
						if(!url.startsWith("http")) url = BUILDER_URL +url;
//						try {
							addDetails( url, comSec, regHtm);
//						} catch (Exception e) {} 
					}
				}
			}
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	private static String[] sqftExp = {
			"\\d,\\d{3}&ndash;\\d,\\d{3} sq. ft",
		"\\d,\\d{3} to \\d,\\d{3} square fee|From:</span> \\d{4} <span>sq ft</span>",
		
		"\\d,\\d{3}–\\d,\\d{3} sq. ft",
		"ranging from \\d,\\d{3} to \\d,\\d{3} square feet",
		"class=\"sqft\">\\s+\\d{3} <span>sq ft</span>",
		"\\d,\\d{3} - \\d,\\d{3} sq.ft.","\\d,\\d{3} - \\d,\\d{3} sqft",
		"up to \\d,\\d{3} sq. ft",
		"\\d,\\d{3}-\\d,\\d{3}sqft",
		
	};
	
	private static String[] priceExp = {"upper \\$\\d{3},\\d{3}","low-\\$\\d{3},\\d{3}","the high-\\$\\d{3},\\d{3}","the mid-\\$\\d{3},\\d{3}",
			"(in|from) the mid \\$\\d{3},\\d{3}",
			"starting in the \\$\\d{3},\\d{3}",
			"from the high-\\d{3},\\d{3}",
		"class=\"price\">\\s+From \\$\\d{3},\\d{3}",
		"Starting At:</dt>\\s+<dd>$413,995</dd>",
		"<span class=\"price\">\\s*\\$\\d{3},\\d{3}"
	};
	
	public void addDetails(String url,String comSec, String regHtm) throws Exception {
//	if(i>30)
		{		
//		if(!url.contains("https://yourviewhome.com/colorado/northern-colorado/johnstown/new-homes/the-ridge-at-johnstown")) return;
			

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "\t*********Repeated******\t");
				return;
			}
			
//			if(url.contains("https://yourviewhome.com/texas/el-paso/el-paso/new-homes/rancho-desierto-bello"))return;
//			LOGGER.AddCommunityUrl(url+ "\t*********Return  Page is not available******\t");
			
			
			LOGGER.AddCommunityUrl(url.replace("http://", "https://"));
			
			U.log(i+"::::::::::communityUrl:::::::::::::::::"+url);
			String comHtml = U.getHTML(url);
		//	
			U.log(U.getCache(url));
			
			//==========com Name ===========
			String comName= Util.match(comSec, "\">(.*?)</a>", 1);
			comName = comName.replaceAll("&#039;", "'").replaceAll(" Foot Thoughtful| - Close Out Opportunities!$| at TRP$|- Coming Soon|- Final Opportunities$", "");
			U.log("comName::"+comName+"::");
			comName=U.getNoHtml(comName);
			U.log("comName::"+comName+"::");
			
			comHtml = comHtml.replace("Pre-sales are available now", "Pre-sales available now");
			
			String notes = U.getnote(comHtml);
			
			//==============Address ======================
			
	//		U.log("comSec::::::::"+comSec);
			
			String add[] ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
			add[0] = U.getSectionValue(comHtml, "'spec': '", "'");
			add[1] = U.getSectionValue(comHtml, "'city': '", "'");
			add[2] = U.getSectionValue(comHtml, "'state': '", "'");
			String addSec = U.getSectionValue(comHtml, "community-address\">", "</a>");
			U.log("addSec ::"+addSec);

			U.log(Arrays.toString(add));
			if(addSec != null){
				addSec = addSec.replace("78045 Laredo", "78045").trim();
				add[3] = Util.match(addSec, "\\d{5}$");
			}
			if(add[2] != null && add[2].length() > 2)
				add[2] = USStates.abbr(add[2]);
			
			U.log(Arrays.toString(add));

			//==================Lat-Lng==================
			
			String geo="FALSE";
			String[] latLng= {ALLOW_BLANK,ALLOW_BLANK};
			
			String latLngSec = U.getSectionValue(comHtml, "<ul class=\"contact\">", "community-address\">");
			
			U.log("latLngSec ::"+latLngSec);
			
			if(add[0] == null || add[0].isEmpty()) add[0] = ALLOW_BLANK;
			if(add[3] == null || add[3].isEmpty()) add[3] = ALLOW_BLANK;
			add[0] = add[0].replace(" Laredo, TX 78045", "");
			U.log("Address is ::::::"+ Arrays.toString(add));

//			if(url.contains("https://yourviewhome.com/texas/el-paso/el-paso/new-homes/sandstone-view")) {
//				add[0]="11401 Sandstone View Ln";
//				add[1]="El Paso";
//				add[2]="TX";
//				add[3]="79934";
//			//	latLng=U.getlatlongGoogleApi(add);
//				latLng[0]="18.8154265";
//				latLng[1]="-76.7751434";
//				geo="TRUE";
//			}
//			if(url.contains("https://www.yourviewhome.com/texas/greater-san-antonio/san-antonio/new-homes/waterford-park")) {
//				add[3]="78254";
//				//latLng[0]="29.5109109";
//			//	latLng[1]="-98.7709408";
//			}
//			if(url.contains("https://yourviewhome.com/colorado/colorado-springs/colorado-springs/new-homes/the-trails-at-aspen-ridge")) {
//			//	add[3]="78254";
//				latLng[0]="21.0993152";
//				latLng[1]="-79.1117824";
//				geo="TRUE";
//			}
			
			
			//--------------GETTING VALUES FROM latlongMap-------------
			
			String latLongSec = latlongMap.get(url);
			U.log("latLongSec from map: "+latLongSec);
			
			if(latLongSec != null) {
				
				String[] geos = latLongSec.split(",");
				
				latLng[0] =  geos[0];
				latLng[1] =  geos[1];
				
				U.log("LATLONG FROM MAP: "+Arrays.toString(latLng));
			}
			
			
			
			if( (add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK)){
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				geo="TRUE";
			}

			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK && add[2] != ALLOW_BLANK){
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add =U.getGoogleAddressWithKey(latLng);
				notes = "Address And Lat-Long Is Taken From City & State";
				geo="TRUE";
			}
			
			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				String add1[] = U.getAddressGoogleApi(latLng);
				if(add1 == null) add1 =U.getGoogleAddressWithKey(latLng);
				if(add[0] == ALLOW_BLANK)add[0] = add1[0];
				if(add[3] == ALLOW_BLANK)add[3] = add1[3];
				geo="TRUE";
			}
			

			
			//===========Available and floor Home Plans=======
			String combinedPlanHtml=ALLOW_BLANK;
		String floorhtml="";
			int x = 0;
			String floorPlanUrlSection[] = U.getValues(comHtml, " <div class=\"item item-listing inventory plan\"", "</a>");
			U.log("floor count :"+floorPlanUrlSection.length);
			for(String floorPlanUrlSec : floorPlanUrlSection) {
				//if(x++ == 5)break;
				String floorUrl = U.getSectionValue(floorPlanUrlSec, "<a href=\"", "\"");
				U.log("floorUrl: "+floorUrl);
				
				if(!floorUrl.startsWith("http")) floorUrl = BUILDER_URL + floorUrl;
				//U.log("floorUrl ::"+floorUrl);
				floorhtml+=U.getHTML(floorUrl);
				U.log(":::::::::::::"+floorUrl);
				combinedPlanHtml += U.getSectionValue(U.getHTML(floorUrl), "<section id=\"model\"", "</section>")+U.getSectionValue(U.getHTML(floorUrl), "  <section id=\"elevations\" ", "</section>");
			}
			
			String quickUrlSection[] = U.getValues(comHtml, "<div class=\"item item-listing inventory move-in\"", "</a>");
			U.log("quick count :"+quickUrlSection.length);
			int quickCount = quickUrlSection.length;
			
			for(String quickUrlSec : quickUrlSection){
				String quickUrl = U.getSectionValue(quickUrlSec, "<a href=\"", "\"");
				if(!quickUrl.startsWith("http")) quickUrl = BUILDER_URL + quickUrl;
//				U.log("quickUrl ::"+quickUrl);
				
				combinedPlanHtml += U.getSectionValue(U.getHTML(quickUrl), "<section id=\"model\"", "</section>");
			}
			
	

			//U.log(Util.matchAll( comHtml, "[\\w\\s\\W]{30}from the mid-$500s[\\w\\s\\W]{30}", 0));
			//========Prices================
			String minPrice = ALLOW_BLANK,maxPrice=ALLOW_BLANK;
			comHtml = comHtml.replace("the mid-$200s", "the mid $200,000").replaceAll("00's|00s", "00,000")
					.replaceAll("starting in the \\$(\\d{3})s", "starting in the \\$$1,000");
		String description=U.getSectionValue(comHtml, "col-12 col-md-8", "brochure-social-wrapper");
			if(description!=null)description=description.replace("mid-100,000", "mid-$100,000");
//			U.log(description);
			
			combinedPlanHtml=combinedPlanHtml.replaceAll("  <div class=\"elevationPriceContainer\">\n\\s*<span class=\"price\">\\$\\d+,\\d+</span>", "");
			
			comHtml=U.removeSectionValue(comHtml, "<meta name=\"description\"", ">");
			String[] prices = U.getPrices(description+comSec + comHtml.replace("from the high-$200,000", "").replace("the mid-$500s", "the mid-$500,000")+ combinedPlanHtml,	String.join("|", priceExp), 0);
			
			//U.log(Util.matchAll(  combinedPlanHtml, "[\\w\\s\\W]{30}293,900[\\w\\s\\W]{30}", 0));
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("minPrice:"+minPrice+ " maxPrice::"+maxPrice);
			
			//=========Squarefeet===========
			String minSqft=ALLOW_BLANK,maxSqft=ALLOW_BLANK;
			
			comHtml = comHtml.replace("size between 1,500-1,900,000qft", "size between 1,500-1,900sqft");
			
			String[] sqft = U.getSqareFeet( comSec+ comHtml, String.join("|", sqftExp), 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
//			U.log(Util.matchAll( comHtml, "[\\w\\s\\W]{30}1,500[\\w\\s\\W]{30}", 0));
			
			U.log("minSqft--->"+minSqft+"  maxSqft-->"+maxSqft);

//			//=======community Type,Property Type, dType PropStatus=======

			comHtml=comHtml.replace("Villa Sport", "");
			String comType=U.getCommType(comHtml);
			U.log("comType:::"+comType);
			
			comHtml = comHtml.replace(" luxurious indoor features", "luxury homes").replace("and luxury with", " and luxury homes with");
			String propType=U.getPropType((comHtml+combinedPlanHtml).replace("stunning single-", "")
					.replaceAll("/villas|- Craftsman</h3>|Craftsman</h3>|Traditional</h3>|887 Cottage|elevationPriceContainer\">, <h3 class=\"h3\">Farmhouse</h3>|Farmhouse</h3>", ""));
			
			U.log("propType:::"+propType);
//			U.log(Util.matchAll( comHtml+combinedPlanHtml, "[\\w\\s\\W]{30}Farmhouse<[\\w\\s\\W]{100}", 0));
			
			String floorhtml1="";
			String flooruls[]=U.getValues(comHtml, "<div class=\"item item-listing inventory ", "Learn More");
			for(String f:flooruls) {
			//	U.log(f);
				String fu="https://www.yourviewhome.com"+U.getSectionValue(f, "<a href=\"", "\"");
//				U.log(fu);
				floorhtml1+=U.getHTML(fu);
			}
			
			String dType=U.getdCommType(comHtml.replaceAll("Branch|branch","")+combinedPlanHtml+floorhtml1.replace("2 stories", "2 Story").replace("1 stories", "1 Story"));
			 
			U.log("dType:::"+dType);
			
//		U.log("comSec======"+comSec);
//			//------------status-----------
			comHtml = U.removeComments(comHtml);

			
			String propStatus=U.getPropStatus(comHtml.replace(" VIP grand opening event", "")//.replace("available now", "now available")
					.replaceAll("new homes available now with half brick|information coming|few walkout lots available|View Homes is now open|available today|including $0 down financing", "").replace("several move-in ready options", ""));
		//	U.log("MMMMMMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{30}now open[\\s\\w\\W]{1}",0));
		
			U.log("PropStatus:::"+propStatus);
	
			U.log("quickcount ::"+quickCount);
//			if(quickCount>0){
//				if(propStatus != ALLOW_BLANK && !propStatus.contains("Quick Move Ins"))
//					propStatus = propStatus + ", Quick Move Ins";
//				else if(propStatus == ALLOW_BLANK) propStatus = "Quick Move Ins";
//			}
			
			if(propStatus.equals("New Phase Coming 2022, Coming Soon")) propStatus = "New Phase Coming 2022";// check next time.
			
			if(url.contains("https://yourviewhome.com/texas/laredo/laredo/new-homes/wolf-creek-coming-soon") && !propStatus.contains("New Phase Coming Soon"))
				propStatus = propStatus.replace("Coming Soon", "New Phase Coming Soon");
			//From Image
			if(url.contains("https://yourviewhome.com/texas/greater-san-antonio/san-antonio/new-homes/texas-research-park-hidden-bluffs")
					|| url.contains("https://yourviewhome.com/colorado/colorado-springs/unincorporated-el-paso-county/new-homes/the-trails-at-aspen-ridge")
					|| url.contains("https://yourviewhome.com/colorado/colorado-springs/monument/new-homes/willow-springs")){
				
				if(propStatus != ALLOW_BLANK && !propStatus.contains("Coming Soon"))propStatus = propStatus + ", Coming Soon";
				else if(propStatus == ALLOW_BLANK) propStatus = "Coming Soon";
			}
//			if(url.contains("https://www.yourviewhome.com/texas/greater-san-antonio/schertz/new-homes/parklands")) {
//				add[1]="Schertz";
//				add[3]="78124";
//				latLng=U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latLng);
//				geo="TRUE";
//			}
//				if(url.contains("https://www.yourviewhome.com/texas/laredo/laredo/new-homes/wolf-creek-coming-soon")) {
//					add[1]="Laredo";
//					add[3]="78046";
//					latLng=U.getlatlongGoogleApi(add);
//					add=U.getAddressGoogleApi(latLng);
//					geo="TRUE";
//				}
//			if(latLng[0]==ALLOW_BLANK||latLng[1]==ALLOW_BLANK) {
//				if(add[0].contains("1069 Nepal Sky"))add[0]="1069 S El Paso St";
//				latLng=U.getlatlongGoogleApi(add);
//				geo="TRUE";
//			}
			if(add[0]==ALLOW_BLANK||add[3]==ALLOW_BLANK) {
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
		
			String noOfUnits=ALLOW_BLANK;
			if(comHtml.contains("Site Plan</h2>")) {
			  String sitemapSec=U.getSectionValue(comHtml, "<iframe id=\"interactive_siteplan\"", "</iframe>");
			 if(sitemapSec!=null) {
			  noOfUnits=getLotCount(sitemapSec,driver);
			  U.log("Number Of Units: "+noOfUnits);
			 }
			 }
			
			
			
			
			data.addCommunity(comName,url, comType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus.replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon"));
			data.addNotes(notes); 
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
		}
		
		i++;
	}

	private String getLotCount(String sitemapSec, WebDriver driver) throws Exception {
		String siteMapUrl=U.getSectionValue(sitemapSec, "src=\"", "\"");
		String siteMapHtml=U.getHtml(siteMapUrl, driver);
		U.log("Path:: "+U.getCache(siteMapUrl));
//		String[] lotData1=U.getValues(siteMapHtml, "<path id=\"Lot", "/>");
//		String[] lotData2=U.getValues(siteMapHtml, "<polygon id=\"Lot", "/>");
		String[] lotData=U.getValues(siteMapHtml, "id=\"Lot_", "/>");
		
	///	int lotCount=lotData1.length+lotData2.length;
		int lotCount=lotData.length;
		String noOfUnit=Integer.toString(lotCount);
		 
		if(noOfUnit.equals("0"))
			noOfUnit=ALLOW_BLANK;
		
		return noOfUnit;
	}
	
}