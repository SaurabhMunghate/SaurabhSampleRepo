package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class GHOHomes extends AbstractScrapper {
	public static int i = 0;
	int k = 0;
	static int j=0;
	public int inr = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	
	private static final String builderUrl = "https://www.ghohomes.com/"; 

	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new GHOHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"GHO Homes.csv", a.data().printAll());
	}

	public GHOHomes() throws Exception {

		super("GHO Homes", builderUrl);
		LOGGER = new CommunityLogger("GHO Homes");
	}
 
	
	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String html = U.getHTML("https://www.ghohomes.com/our-communities.cfm");

		String[] communitiesInfo = U.getValues(html, "<tr class=\"hover\">","</tr>");
		U.log(communitiesInfo.length);
		
		for (String communityInfo : communitiesInfo) {

			String communityUrl = builderUrl+U.getSectionValue(communityInfo, "<a href=\"","\"").replaceAll("^/", "");
//			try {
				findCommunityDetails(communityUrl,communityInfo);
//			} catch (Exception e) {}

		}
		LOGGER.DisposeLogger();
	}
	
	private void findCommunityDetails(String communityUrl, String communityInfo)throws Exception {
	// TODO : For Single Community Execution
//	if(j== 20)
//	if(!communityUrl.contains("https://www.ghohomes.com/community-stoney-brook-farm-5.cfm")) return;
	
	{
		
		U.log(j+"  comURL:: " + communityUrl);
		

		if(data.communityUrlExists(communityUrl)){
			LOGGER.AddCommunityUrl(communityUrl+"=======>>>Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(communityUrl);
		
		String commHtml = U.getHTML(communityUrl);
		U.log(U.getCache(communityUrl));	
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(commHtml, communityUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		//============= Community Name ================
		String communityName = U.getSectionValue(communityInfo,"cfm\">", "<");
//		if(communityName.contains("Build On Your Lot - St. Lucie")) {
//			LOGGER.AddCommunityUrl(communityUrl+"===============repeated");
//			return;
//		}
		U.log("comName::"+communityName);
		
		String notes = ALLOW_BLANK;
		//================ Address ========================
		String geo = "False";
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addSection = U.getSectionValue(commHtml,"Address:</strong>", "<strong>");
		U.log("AddSec:::"+addSection);
		if(addSection != null){
			addSection=addSection.replace("Blvd. Port", "Blvd., Port").replaceAll("2172 Timberlake Cir Vero Beach, Florida 32966 Vero Beach, FL\\s*<br><br>", "2172 Timberlake Cir, Vero Beach, FL 32966");
			addSection = addSection.replaceAll("<br> ", "").replace(" Vero Beach", ", Vero Beach").replaceAll("Sebastian", ", Sebastian")
					.replaceAll(" Port St\\.? Lucie", ", Port St Lucie").replace(" Fort Pierce", ", Fort Pierce").replace("Florida", "FL")
					.replaceAll("Vero Beach, FL 32966, Vero Beach, FL 32966", "Vero Beach, FL 32966")
					.replaceAll("NOW OPEN!", "");
			U.log("AddSec:::"+addSection);
			add = U.getAddress(addSection);
		}
		
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]+ " Z:" + add[3]);

		//================= Lat-lng ifrme section ===================
		String latlng[] = { ALLOW_BLANK, ALLOW_BLANK };

		String iFremeSec = U.getSectionValue(commHtml,"frameborder=\"0\" ", "allowfullscreen");
		
		U.log("latLngSec=="+iFremeSec);
		String lat = Util.match(iFremeSec, "\\d{2,}\\.\\d{3,}");
		String lng = Util.match(iFremeSec, "-\\d{2,}\\.\\d{3,}");

		latlng[0] = lat;
		latlng[1] = lng;
		
		if (latlng[0] == null) {
			latlng[0] = latlng[1] = ALLOW_BLANK;
		}
		
	
		
		
		
		if(latlng[0] == ALLOW_BLANK && add[0] == ALLOW_BLANK){
			String directionUrl = Util.match(commHtml, "<a href=\"(.*?)\">Directions</a>", 1);
			U.log(directionUrl);
			if(directionUrl != null){
				String directionHtml = U.getHTML(builderUrl+directionUrl);
				addSection = U.getSectionValue(directionHtml, "our sales office at", ".</p>");
				if(addSection != null){
					add = U.getAddress(addSection);
				}
			}
				
		}
		if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK){
			if(latlng[0] == ALLOW_BLANK && latlng[1] == ALLOW_BLANK){
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo = "True";
			}
		}
		if(latlng[0] != ALLOW_BLANK && latlng[1] != ALLOW_BLANK){
			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo = "True";
			}
		}
		if(add[0] != ALLOW_BLANK && add[3] == ALLOW_BLANK){
			if(latlng[0] != ALLOW_BLANK && latlng[1] != ALLOW_BLANK){
				String add1[] = U.getAddressGoogleApi(latlng);
				if(add1 == null) add1 =U.getAddressHereApi(latlng);
				add[3] = add1[3];
				geo = "True";
			}
		}
		U.log("LatLng::"+Arrays.toString(latlng));

		add[0]  = add[0].replace(",", "");
		add[0] = U.getCapitalise(add[0].toLowerCase());
		if(communityUrl.contains("/community-build-on-your-lot")) {
			add[1]="Vero Beach";
			add[2]="FL";
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add =U.getAddressHereApi(latlng);
			notes ="Address and LatLng Taken From City & State";
			geo = "True";
		}
		
		
		
		if(communityUrl.contains("/community-villas-at-summer-lake-north-43.cfm")) {
			add[1]="Vero Beach";
			add[2]="FL";
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add =U.getAddressHereApi(latlng);
			notes ="Address and LatLng Taken From City & State";
			geo = "True";
		}
		
		if(communityUrl.contains("/community-stoney-brook-farm-5.cfm")) {
			add[1]="Vero Beach";
			add[2]="FL";
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add =U.getAddressHereApi(latlng);
			notes ="Address and LatLng Taken From City & State";
			geo = "True";
		}
		
//		if (communityUrl.contains("https://www.ghohomes.com/community-build-on-your-lot-platinum-series-13.cfm")){
//			latlng[0] = "27.6102159";
//			latlng[1] = "-80.4985276";
//			geo = "TRUE";
//			add = U.getAddressGoogleApi(latlng);
//			notes = "Lat-Long Taken From Floorplan Home";
//		}
//
//		if(communityUrl.contains("https://www.ghohomes.com/community-villas-at-summer-lake-north-43.cfm") ){
//			latlng[0] = "27.7332764";
//			latlng[1] = "-80.4531863";
//			add = U.getAddressGoogleApi(latlng);
//			notes = "Address Taken From City And State";
//			geo = "True";
//		}
//		
		
		//=================== Content From Community Images =================
		if(communityUrl.contains("https://www.ghohomes.com/community-the-strand-54.cfm")) communityInfo += "single family, luxury homes";
		
		String commHSection = U.getSectionValue(commHtml,"<h2> Floorplans", "Community Profile Information");
		if(commHSection==null)commHSection=U.getSectionValue(commHtml, "<h2> Floorplans", "<div class=\"container\"");
		if(commHSection==null)commHSection=U.getSectionValue(commHtml, " Floorplans</h2>", "<h2>Community Profile Information</h2>");
        if (commHSection==null)
        	 commHSection = ALLOW_BLANK;
        
//        U.log(communityInfo);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log("commHSection::"+commHSection);
		commHSection = commHSection.replaceAll("0'S|0's|0s|0&rsquo;s", "0,000");
		communityInfo = communityInfo.replaceAll("0'S|0's|0s", "0,000")
				.replaceAll("\\$(\\d) Million", "\\$$1,000,000");
		if(communityUrl.contains("/community-st-lucie-collection-31.cfm"))commHtml = commHtml.replaceAll("\\$\\d{3},\\d{3}.\\d{2}", "");
		//=========== Price =========================
		String price[] = U.getPrices(commHSection+communityInfo+commHtml, "\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice+"\t"+maxPrice+"\tprice");
		//================ Sqft ========================
		
		String[] sqft = U.getSqareFeet(commHtml, "homes all over \\d,\\d{3} sq. ft|>\\d{1},\\d{3}|\\d,\\d+ square fee to over \\d,\\d+ square ", 0);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log(minSqf+"\t"+maxSqf+"\tSqft");
		commHtml=commHtml.replace("<br>Ungated", "");
		
		//============ community Type =====================
		//if(communityUrl.contains("boulevard-village-tennis-club-37"))commHtml=commHtml+"Country Club";
//		U.log(communityInfo);
		commHtml = commHtml.replace("Lakefront Series", "spacious lakefront homesite").replaceAll("Community Lak[e|es]", "Lake community");
		
		String communityType = U.getCommunityType(communityInfo+commHtml.replaceAll("outside golf and marina|tennis, golf, or a generally|Lakefront Series \\(lots 34-57\\)|Summer Lake Community -", ""));
		
		commHtml = commHtml.replace(" Private Roads, Common Area Maintenance", "").replaceAll("Luxury-Series|Luxury Bathrooms", "");
		commHtml = commHtml.replaceAll("Village|-Villa-|Villa\",", "");
		
		String navSec = U.getSectionValue(commHtml, "<ul class=\"nav navbar-nav",  "</ul>");
//		U.log(navSec);
		String  featureUrl = null;
		if(navSec != null){
			String[] navUrls = U.getValues(navSec, "<li><a href=\"", "\"");
			for(String navUrl : navUrls){
				if(navUrl.contains("features")){
					featureUrl = navUrl;
					break;
				}
			}
		}
		
		//U.log(commHtml);
	//	String url1=U.getSectionValue(commHtml, "<li><a href=\"index","\">Features");
		String feturhtml="";
		U.log("featureUrl::::"+builderUrl+featureUrl);
		if(featureUrl != null){
			feturhtml=U.getHTML(builderUrl+featureUrl);
			feturhtml=feturhtml.replaceAll("Luxury-Series|Luxury Bathrooms","");
			feturhtml = feturhtml.replace(U.getSectionValue(feturhtml, "<META NAME=", "<script") , "");
			feturhtml = feturhtml.replace(">Custom Homes<", "");
		}

		String inventoryHtmls = null;
		String inventorySection = U.getSectionValue(commHtml, "<h2>Inventory Homes</h2>", "</table>");
		if(inventorySection != null){
			String inventoryHomeSection[] = U.getValues(inventorySection, "<tr>", "</tr>");
			for(String inventoryHomeSec : inventoryHomeSection){
				String inventoryUrl = U.getSectionValue(inventoryHomeSec, "<td><a href=\"", "\"");
				if(inventoryUrl == null) continue;
				if(!inventoryUrl.startsWith("http")) inventoryUrl = builderUrl +inventoryUrl.replaceAll("^/", "");
				U.log("inventoryUrl ::"+inventoryUrl);
				String inventoryHtml =U.getHTML(inventoryUrl);
				
				inventoryHtmls += U.getSectionValue(inventoryHtml, "<div class=\"container\">", "<h2>Photo Gallery");
				
			}
		}
		commHtml = commHtml.replaceAll(">Custom Homes<|Villas at Summer Lake North |community-villas-at-summer-lake-north-43|7674FieldstoneRanchSquare|floorplan-fieldstone-ranch-carmel-12-0-2-126", "");
		feturhtml=feturhtml.replaceAll(">Custom Homes<|Villas at Summer Lake North |community-villas-at-summer-lake-north-43", "");
		commHtml = commHtml.replace("custom home pricing", "exceptional custom home").replace("multiple lakefront and Grande Series lots available", "multiple lakefront lots available").replace("Luxury Series", "Luxury homes");
		commHtml = U.removeSectionValue(commHtml, "var availableTags = [", "</script>");
		commHtml = commHtml.replace("looking for luxury ", "looking for luxury homes ")
				.replaceAll("Estate Sized Homesites|estate home community|Estate home lots|Oversized Estate Homesites ", "Estate Style Living");
		
		communityInfo=communityInfo.replace("single family, luxury homes", "");
		
		String propertyType = U.getPropType((communityInfo+commHtml+feturhtml+inventoryHtmls).replaceAll("Garage & Courtyard|Mediterranean-elevation|Mediterranean Elevation|Mediterranean optional elevation|Traditional optional elevation|ada-courtyard|Ada Courtyard", ""));
//		U.log("ths is golf::::::"+Util.matchAll(communityInfo+commHtml+feturhtml+inventoryHtmls, "[\\w\\s\\W]{10}single[\\w\\s\\W]{10}",0));
//		U.log("ths is golf::::::"+Util.matchAll(commHtml, "[\\w\\s\\W]{10}single family[\\w\\s\\W]{10}",0));
//		U.log("ths is golf::::::"+Util.matchAll(feturhtml, "[\\w\\s\\W]{10}single family[\\w\\s\\W]{10}",0));
//		U.log("ths is golf::::::"+Util.matchAll(communityInfo, "[\\w\\s\\W]{10}single family[\\w\\s\\W]{10}",0));
		
//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/communityInfo.txt", communityInfo);

		String drop = U.getSectionValue(commHtml, "var availableTags = [", "</script>");
		commHtml = commHtml.replace(drop, "");
		
		
		String derivedPropertyType = U.getdCommType(commHtml);


//		communityInfo = communityInfo.replace(">New Villas NOW AVAILABLE<", "");
		communityInfo=communityInfo.replace("Move In Ready from", "Move In Ready Homes")
				.replace("Phase 1 - Nearing Sellout", "Phase 1 Nearing Sellout");
		commHtml = commHtml.replaceAll("SOLD-OUT_|slider_closed", "");
		
		communityInfo=communityInfo.replace("Final Opportunities in Phase 1", "Final Opportunities Phase 1").replace("Lake Front Homesites Available", "Lakefront Home Sites Available");
		String propertyStatus = U.getPropStatus((commHtml+communityInfo).replaceAll("Lot: 11 Coming Soon|Lot: 23 Coming Soon|with Move-in Ready Homes|Ask About Move-in Ready Homes|New sales office coming soon|option of move-in ready homes|expected to be sold out, |NOW OPEN! Monday|NOW OPEN! \\d+ Scott|New Tacoma Model - Move-in Ready Homes|New Villas NOW AVAILABLE|Models Now Open|MODEL AND SALES NOW OPEN","")); //Move-In|move-in

		U.log("propertyStatus: "+propertyStatus);
//		U.log("ths is golf::::::"+Util.matchAll(commHtml, "[\\w\\s\\W]{10}Limited[\\w\\s\\W]{10}",0));
//		U.log("ths is golf::::::"+Util.matchAll(communityInfo, "[\\w\\s\\W]{10}Limited[\\w\\s\\W]{10}",0));
		
		FileUtil.writeAllText("/home/shatam-10/Desktop/data/communitySTATUS.txt", communityInfo);
		
		String moveInPage =U.getHTML("https://www.ghohomes.com/move-in-ready-homes.cfm");
		moveInPage=U.removeSectionValue(moveInPage, "var availableTags = [", "</script>");
		

		

		//========= From image ================ Updated 2 March 2021
		
//		if (communityUrl.contains("https://www.ghohomes.com/community-summer-lake-north-44.cfm")){
//			propertyStatus="Nearing Closeout, Limited Opportunities Remain";
//		}
		

		if (communityUrl.contains("https://www.ghohomes.com/community-oak-harbor-57.cfm") && !communityType.contains("55+ Community")){
			if(communityType.length() > 1)communityType=communityType+", 55+ Community";
			else communityType="55+ Community";
		}

		if(communityUrl.contains("https://www.ghohomes.com/community-the-strand-54.cfm")
				|| communityUrl.contains("https://www.ghohomes.com/community-the-boulevard-village-tennis-club-37.cfm")){
			if(!propertyStatus.contains("Now Selling") && propertyStatus.length() > 1)propertyStatus=propertyStatus+", Now Selling";
			else propertyStatus="Now Selling";
		}

		if(communityUrl.contains("https://www.ghohomes.com/community-sommers-place-62.cfm")){
			if(!propertyStatus.contains("Only Two Opportunities Remain") && propertyStatus.length() > 1)propertyStatus=propertyStatus+", Only Two Opportunities Remain";
			else propertyStatus="Only Two Opportunities Remain";
		}
		if(communityUrl.contains("/community-segovia-lake-40.cfm")) {
			propertyType=propertyType+", Luxury Homes";
		}
		
//		if(moveInPage.contains(communityName) && communityInfo.contains(" Inventory")) {
//			if(propertyStatus.length()<2 )propertyStatus =" Move-in Ready Homes";
//			else if(!propertyStatus.contains("Move"))propertyStatus = propertyStatus +", Move-in Ready Homes";
//		}
		
		//if(propertyStatus.contains("New Lots Now Available, Now Available"))propertyStatus=propertyStatus.replace("New Lots Now Available, Now Available", "New Lots Now Available");
		
		//U.log(communityName);

//		if(communityUrl.contains("https://www.ghohomes.com/community-fischer-lake-island-61.cfm")) communityType = communityType + ", Lakefront Community"; //From Image
			
		if(communityUrl.contains("https://www.ghohomes.com/community-oak-harbor-57.cfm")) { //Img
			
//			communityType = communityType + ", 55+ Community";
			propertyType = propertyType + ", Luxury Homes";
			
		}
		
		add[0]=add[0].replaceAll("Future Model: ", "");
//		}
		if(communityUrl.contains("https://www.ghohomes.com/community-bent-pine-preserve-53.cfm"))minPrice ="600,000";
		communityName=communityName.replace("- Luxury Series","");
//		if(communityUrl.contains("https://www.ghohomes.com/community-st-lucie-collection-31.cfm")) {
//			add[0]="590 NW Mercantile Place";
//			add[1]="Port St Lucie";
//			add[2]="FL";
//			add[3]="34986";
//			
//			latlng=U.getlatlongGoogleApi(add);
//			geo="TRUE";
//			notes="Address Taken From Contact us";
//		
//		}
//		if(communityUrl.contains("community-oak-harbor-57.cfm"))minPrice ="$500,000";
//		if(communityUrl.contains("https://www.ghohomes.com/community-fischer-lake-island-61.cfm"))maxSqf ="3,598";
		if(communityUrl.contains("https://www.ghohomes.com/community-bent-pine-preserve-53.cfm")) {
			propertyStatus="Phase 2 Selling Soon";
			minPrice="$500,000";
		}
//		U.log("PropStatus==="+propertyStatus);
		if(communityUrl.contains("community-the-strand-54.cfm"))minPrice="$1,000,000";// frm img
//		if(communityUrl.contains("https://www.ghohomes.com/community-bella-vista-isles-47.cfm")) {
//			propertyStatus="Final Closeout, Limited Opportunities Remain";///img
//		}
		propertyStatus = propertyStatus.replaceAll("Now Selling, Move-in Ready Homes|Now Selling, Move-in Ready", "Now Selling, Move-in Ready Homes");
//		if(notes!=null || notes!=ALLOW_BLANK)notes=U.getnote(commHtml+communityInfo);
		U.log("PropStatus==========>"+propertyStatus);
		
//		if(communityUrl.contains("https://www.ghohomes.com/community-bent-pine-preserve-53.cfm")) propertyStatus = propertyStatus + ", Phase II Now Selling"; //from img 26 march
//		if(communityUrl.contains("https://www.ghohomes.com/community-oak-hollow-64.cfm")) propertyStatus = propertyStatus + ", Limited Opportunities"; //from img 26 march
		if(communityUrl.contains("https://www.ghohomes.com/community-villas-at-summer-lake-north-43.cfm")) propertyStatus = "100% Sold Out"; //from img 26 march
		if(communityUrl.contains("https://www.ghohomes.com/community-laurel-reserve-50.cfm")) propertyStatus = "Now Selling"; //from img 27 June
		if(communityUrl.contains("https://www.ghohomes.com/community-fischer-lake-island-61.cfm")) propertyStatus = "100% Sold Out"; //from img 27 June


		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(communityName, communityUrl, communityType);
		data.addAddress(add[0], add[1], "FL", add[3]);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPropertyType(propertyType, derivedPropertyType);
		data.addPropertyStatus(propertyStatus.replace("Sold Out, Now Selling", "Sold Out"));
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(notes);
	}
	j++;
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		HashSet<String> unitCounts = new HashSet<String>();
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalLotCount = 0;
		
		if(html.contains("Site Plan</a></li>")) {
			

			String frameSec = U.getSectionValue(html, " <ul class=\"nav navbar-nav community-navigation-bar\">", "Site Plan</a></li>");
			frameSec = frameSec.replace("<li><a href=\"#floorplanList\">Floorplans</a></li>", "");
			
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "<a href=\"", "\""); 
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.startsWith("/?method=ourcommunities")) {
					
					frameUrl = "https://www.ghohomes.com" + frameUrl;
					U.log("complete frameUrl: "+frameUrl);
					
					mapData = U.getHtml(frameUrl, driver);
					U.log(U.getCache(frameUrl));
					
					//------------ for map containing multiple phases -----------------
					if(mapData.contains("method=ourcommunities_interactive")) {
						
						U.log("--------- Map with Multiple Phases --------- ");
						
						String[] phaseLinks = U.getValues(mapData, "href=\"/?method=ourcommunities_interactive", "\"");
						U.log("phaseLinks Lengths: "+phaseLinks.length);
						
						for(String phaselink:phaseLinks) {
							
							HashSet<String> unitCountsPhase = new HashSet<String>();
							
							phaselink = "https://www.ghohomes.com/?method=ourcommunities_interactive" + phaselink;
							phaselink = phaselink.replace("&amp;", "&");
							U.log("phaselink: "+phaselink);
							
							String phaseData = U.getHtml(phaselink, driver);
							U.log(U.getCache(phaselink));
							
							String[] countSec = U.getValues(phaseData, "<strong>Lot:</strong>", "<br />");
							U.log("countSec: "+countSec.length);
							for(String count:countSec) {
								
								//HashSet is defined to avoid duplicate values from above countSec. 
								//U.log("count: "+count);
								
								unitCountsPhase.add(count);
							}
							U.log("unitCounts.size from map with phases: "+unitCountsPhase.size());
							totalLotCount += unitCountsPhase.size();
							//break;
						}
						U.log("Lot Count From Phases: "+totalLotCount);
					}

					//------------- for map without phases ---------------------
					else {
						
						String[] countSec = U.getValues(mapData, "<strong>Lot:</strong> ", "<br />");
						U.log("countSec: "+countSec.length);
						for(String count:countSec) {
							
							//HashSet is defined to avoid duplicate values from above countSec. 
							//U.log("count: "+count);
							
							unitCounts.add(count);
						}
						U.log("unitCounts.size: "+unitCounts.size());
						totalLotCount = unitCounts.size();
					}
					

					totalUnits = String.valueOf(totalLotCount);
					U.log("Lot Count : "+totalUnits);
				}
			}

		}
		
		return totalUnits;
	}
	
	
	
}