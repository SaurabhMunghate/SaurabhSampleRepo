package com.shatam.b_301_324;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class GreenECOBuilders extends AbstractScrapper {
	public static int i = 0;
	int k = 0;
	public int inr = 0;
	static int j = 0;
	static CommunityLogger LOGGER;
	WebDriver driver = null;
	static int dupli = 0;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new GreenECOBuilders();
		// U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "csv/GreenECO Builders.csv", a.data().printAll());

	}

	public GreenECOBuilders() throws Exception {

		super("GreenECO Builders", "http://greenecobuilds.com/");
		LOGGER = new CommunityLogger("GreenECO Builders");

	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
//		U.setUpChromePath();
		driver = new FirefoxDriver();// new ChromeDriver();
		String html = U.getHTML("http://greenecobuilds.com/green-home-communities.php");
		// U.log(html);
		html = U.removeComments(html);

		String section = U.getSectionValue(html, "<ul class=\"list2", " </ul>");

		html = html.replaceAll("</i>\\s*<br />", " ");

		// String[] communitiesInfo = U.getValues(section, "<li><a class=\"l",")</i>");
		section = section.replaceAll("</i>\\s*<br />", "");
		// U.log(section);
		String[] communitiesInfo = U.getValues(section.replaceAll("</i>", "</li>"), "<li><a", "</li>");

		U.log(communitiesInfo.length);

		for (String communityInfo : communitiesInfo) {
			//U.log(communityInfo);
			findCommunityDetails(communityInfo, driver);

		}
		LOGGER.DisposeLogger();
		// driver.close();
		driver.quit();
	}

	private void findCommunityDetails(String communityInfo, WebDriver driver) throws Exception {
//		 if (j == 9)
		{

			U.log("count :  " + j);
			String communityName = U.getSectionValue(communityInfo, ".php\">", "</a>");
//			U.log(communityInfo);
			String community = U.getSectionValue(communityInfo, "href=\"", "\">");
			if (community.contains("#")) {
				LOGGER.AddCommunityUrl(communityName + "***********************No Url");
				return;
			}

			String communityUrl = "http://greenecobuilds.com/" + community;
			
			//TODO : Execute for single community
//		 if (!communityUrl.contains("http://greenecobuilds.com/trails-at-bay-colony.php"))return;
			 
			// return; //for single community
			U.log("communityUrl::::::" + communityUrl);

			if (data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl(communityUrl + "***********************repeated");
				dupli++;
				return;
			}
			/*if(communityUrl.contains("/still-creek-ranch.php")) //communityUrl.contains("/hidden-creek.php")
			{
				LOGGER.AddCommunityUrl(communityUrl + "***********************no data");
				return;

			}*/
			String commHtml = U.getHtml(communityUrl, driver);
			String homeLHtml = U.getHtml(communityUrl, driver, true);// id = "available-homes"//sahil

			// ---------------------------------------------------------------------
			String hmesHtml = "", allHomeData = ALLOW_BLANK;

			String homesUrls[] = U.getValues(commHtml, "href=\"http://search", "\"");// sahil
			for (String hUrl : homesUrls) {
				try {
					U.log("hUrl::::::::::::::::" + "https://search"+hUrl);
					if(hUrl.endsWith("NA"))continue;
					hmesHtml = U.getPageSource("https://search" + hUrl);
					if (hmesHtml != null) {
						
						allHomeData = U.getSectionValue(hmesHtml, "div class=\"listing_left\">",
								"Additional Information") + allHomeData;
//						String temp1=U.getdCommType(allHomeData);
//						U.log(temp1);
					}
				} catch (Exception e) {
					// TODO: handle exception
				}

			}
			
			
			
			// ----------------------Price-------------------------
//			communityInfo = communityInfo.replace("0's", "0000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			commHtml = commHtml.replace("low 100�s", "\\$100000").replace("$&nbsp;", "\\$ ");
			commHtml = commHtml.replace("0’s|0's", "0,000");
			communityInfo = communityInfo.replace("0's", "0,000");

			 U.log(communityInfo);

			String price[] = U.getPrices(communityInfo + commHtml + homeLHtml + allHomeData,
					"\\$\\s*\\d+,\\d+|\\$&nbsp;\\d{3},\\d{3}",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			 U.log(minPrice);
			U.log(U.getCache(communityUrl));
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(commHtml + homeLHtml,
					"\\d+�sqft|</td><td>\\d{4}</td><td>|</td><td>\\d,\\d{3}</td><td>|\\d{4} to \\d{4} square feet|<td>\\d{4}/\\d{4}</td>|<td>[0-9]{4}&nbsp;sqft</td>|<td>\\d{4} sqft</td>",
					0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			// --------------community Type-----------------------------------------
			String communityType = U.getCommunityType(commHtml); //.replace("Master Suite", "Master Plan Community")

			commHtml = commHtml.replace("-�Under Construction</a>", "");

			// --------------Status------------------------
			commHtml = commHtml.replace("Palo Duro Canyon Lane - MLS#�-�Under Construction", "");
			commHtml = commHtml.replaceAll("Under Construction</a>|Coming 2019-2020<br>", "");
			String propertyStatus = ALLOW_BLANK;
//			U.log(communityInfo);
			propertyStatus = U.getPropStatus(commHtml.replace("oon", "") + communityInfo);

//			if (communityUrl.contains("http://greenecobuilds.com/sugar-pine-pavilion.php")) {
//				propertyStatus = "3 Homes Remaining,Final Oportunity";
//			}
			U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{30}move[\\w\\s\\W]{40}", 0));
			if (propertyStatus.length() == 0) {
				propertyStatus = ALLOW_BLANK;
			}
			if (commHtml.replace("&nbsp;", " ").contains("Immediate Move-in")) {
				if (propertyStatus.length() > 2) {
					propertyStatus = propertyStatus + ", Immediate Move-in Homes";
				} else {
					propertyStatus = "Immediate Move-in Homes";
				}
			}
			U.log("propertyStatus::::::::::::==========================================================================>:"
					+ propertyStatus);

			// -------------------------Address-------------------------------
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			// commHtml=commHtml.replace("u>Our Sales Office is open:", "Contact Sales
			// Executive");
			// U.log("commHtml=="+commHtml);
	
			String commAddr = U.getSectionValue(commHtml, "<li><u>Sales Office Address</u><br>",
					"Our Sales Office is open");
			if (commAddr==null) {
				commAddr=U.getSectionValue(commHtml, "<li><u><strong>Sales Office Address</strong></u><br />",
						"Phone");
			}
			if (commAddr==null) {
				commAddr=U.getSectionValue(commHtml, "<li><u>Sales Office Address</u><br />",
						"</li>");
			}
			if (commAddr != null) {
				commAddr = commAddr.replace("By Appointment Only", "");
			}
			U.log("--------------------------------------------------" + commAddr);
			if (commAddr != null) {
				// commAddr=U.removeComments(commAddr);
				commAddr = commAddr.replaceFirst("<br>|<br />", ",").replace("<br>", "");
				commAddr = commAddr.replace(" <!---->	", " ");
				commAddr = commAddr.replace("<!-- 11226 Lovington Drive, -->	", " ");
				commAddr=commAddr.replaceAll("Key Map No. – 333F	<br />&nbsp;<br />", "");
				commAddr = commAddr.replace("2915 Star Peak", "2915 Star Peak,");
				U.log("sahil" + commAddr);

				// commAddr=commAddr.replace(Texas, 0);
				// if (commAddr != null) {
				String[] addr = commAddr.split(",");
				if (addr.length > 2) {
					U.log("0==" + addr[0]);
					// add[0] = Util.match(addr[0],"\\d{5}\\w+");
					add[0] = addr[0].trim();
					add[1] = addr[1].trim();
					// U.log("first=="+addr[1] + add[1]);
					add[2] = Util.match(addr[2], "\\w+");
					add[3] = Util.match(addr[2], "\\d{5}");
					U.log("add[3]==" + add[3]);
				}

			} // }
				// else if(commAddr== null)
			else {

				commAddr = U.getSectionValue(commHtml, "<li><u>Sales Office Address</u><br>", "</li>");
				if (commAddr == null) {
					commAddr = U.getSectionValue(commHtml, "<li><u><strong>Sales Office Address</strong></u><br>",
							"</li>");
				}
				if (commAddr != null) {

					 U.log("--------------------------------------------------" + commAddr);
					commAddr = commAddr.replaceFirst("<br>|<br />", ",").replace("<br>", "");
					commAddr = commAddr.replace(" <!---->	", " ");
					commAddr = commAddr.replace("<!-- 11226 Lovington Drive, -->	", " ");

					commAddr = commAddr.replace("2915 Star Peak", "2915 Star Peak,");
					// U.log("sahil" + commAddr);

					// commAddr=commAddr.replace(Texas, 0);
					// if (commAddr != null) {
					String[] addr = commAddr.split(",");
					// U.log("0==" + addr[0]);
					// add[0] = Util.match(addr[0],"\\d{5}\\w+");
					if(addr.length > 2){
						add[0] = addr[0];
						add[1] = addr[1];
						// U.log("first=="+addr[1] + add[1]);
						add[2] = Util.match(addr[2], "\\w+");
						add[3] = Util.match(addr[2], "\\d{5}");
						U.log("add[3]==" + add[3]);
					}
				} else {
					commAddr = U.getSectionValue(commHtml, "<u>Sales Office Address</u><br />",
							"Contact Sales Executive");
					if (commAddr != null&&!commAddr.contains("By Appointment Only")) {

						U.log("--------------------------------------------------" + commAddr);
						commAddr = commAddr.replaceFirst("<br>|<br />", ",").replace("<br>", "").trim();
						commAddr = commAddr.replace(" <!---->	", " ");
						commAddr = commAddr.replace("<!-- 11226 Lovington Drive, -->	", " ");

						commAddr = commAddr.replace("2915 Star Peak", "2915 Star Peak,");
						// U.log("sahil" + commAddr);

						// commAddr=commAddr.replace(Texas, 0);
						// if (commAddr != null) {
						String[] addr = commAddr.split(",");
						// U.log("0==" + addr[0]);
						// add[0] = Util.match(addr[0],"\\d{5}\\w+");
						add[0] = addr[0];
						add[1] = addr[1];
						// U.log("first=="+addr[1] + add[1]);
						add[2] = Util.match(addr[2], "\\w+");
						add[3] = Util.match(addr[2], "\\d{5}");
						U.log("add[3]==" + add[3]);
					}
				}
			}
			
			
			// state = USStates.abbr(state);

			String geo = "true";
			if (add[0] == null)
				add[0] = ALLOW_BLANK;
			if (add[1] == null) {
				add[1] = ALLOW_BLANK;
				geo = "";
			}
			add[2]="TX";
			if (add[3] == null)
				add[3] = ALLOW_BLANK;

			if (add[2].length() != 2)
				add[2] = USStates.abbr(add[2]);

			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);

			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			if (add[0] != ALLOW_BLANK) {
				U.log("");
				add[0] = add[0].trim();
				add[1] = add[1].trim();
				add[2] = add[2].trim();
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				if(latlng == null) latlng = U.getNewBingLatLong(add);
			}
			if (latlng[0] == null) {
				latlng[0] = ALLOW_BLANK;
				latlng[0] = ALLOW_BLANK;
				geo = ALLOW_BLANK;
			}
			// U.log(latlng[0]);

			if (add[2] == null)
				add[2] = ALLOW_BLANK;

			if (add[0] != ALLOW_BLANK && add[3] == ALLOW_BLANK) {
				if (latlng[0] != ALLOW_BLANK) {
					String add1[] = U.getAddressGoogleApi(latlng); 
					if(add1 == null) add1= U.getAddressHereApi(latlng);
					add[3] = add1[3];
				}
			}
			// ---------------Derived TYpe-------------------------------
			String Dtype = ALLOW_BLANK;
            commHtml = commHtml.replace(" 2 Story 1857 sq ft", " 2 Story, 1857 sq ft");
			String values[] = U.getValues(commHtml, "<tr", "</tr>");
			HashSet<String> dval = new HashSet<String>();
			for (String s : values) {
				String[] valdtype = U.getValues(s, "<td>", "</td>");
				if (valdtype.length == 8) {
					dval.add(valdtype[4]);

				}
			}
			for (String d : dval) {
				U.log(d);
				if (Dtype == ALLOW_BLANK)
					Dtype = d + " Story";
				else
					Dtype += ", " + d + " Story ";
				U.log("Dtype==================================== : " + Dtype);
			}
			if (latlng[0] == ALLOW_BLANK)
				geo = ALLOW_BLANK;
			String note = U.getnote(commHtml + communityInfo);
			if (communityUrl.contains("http://greenecobuilds.com/avondale.php")) {
				String addressSec="Inverness Path Lane, Houston, TX , 77045";
				add=addressSec.split(",");	
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo = "TRUE";
				
			}
			if(communityUrl.contains("http://greenecobuilds.com/old-seabrook-village.php")){
				add[0]="N Meyer Rd";
				add[1]="Seabrook";
				add[2]="TX";
				add[3]="77586";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo = "TRUE";
				note="Address Taken From Sitemap";
			}
/*			if(communityUrl.contains("http://greenecobuilds.com/hidden-creek.php")){
				add[0]="Avenue M";
				add[1]="Conroe";
				add[2]="TX";
				add[3]="77301";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo = "TRUE";
				note="Address Taken From Sitemap";
			}*/
			
			if(communityUrl.contains("http://greenecobuilds.com/sugar-pine-pavilion.php")) {
				add[0]="23303 Briarstone Harbor Trail";
				add[1]="Katy";
				add[2]="TX";
				add[3]="77493";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				geo = "TRUE";
//				note="Address Taken From Sitemap";
			}
			if(communityUrl.contains("http://greenecobuilds.com/edgewater-by-the-bay-river-series.php")) {
				note="Address Taken From Sitemap";
			}
			 U.log(Dtype);
			Dtype = U.getdCommType((commHtml + Dtype +" "+ allHomeData).replaceAll(
					"4934|3 Bdrms-Study-Gameroom-|4 Beds - Study-|3706|4 Sides Brick with Stone Elevation|-4 Sides Brick w/Stone B|Offers 4 Beds-Study-Gameroom|4 Beds-Study-3 Baths|4 Beds|3 bedroom|3 Bedrooms |Branch|Ranch High|ranch high|-ranch-high",
					""));

			Dtype = Dtype.replace("1 Story,2 Story,3 Story", "1 Story, 2 Story");

			// --------------Property Type --------------------------------
//			U.log(allHomeData);
			if(allHomeData != null)
				allHomeData = allHomeData.replaceAll("77539 Apartments|League City Apartment|Apartments for Rent|Garage Apartment", "");
			String propertyType = U.getPropType((commHtml + allHomeData).replace("-Loft-", "with Loft ").replace("Homeowner’s Association", " HOA "));

			U.log("propType========================================================================>" + propertyType);
			propertyStatus = propertyStatus.replace("Close-out", "Close Out");

			if (add[0].length() < 4 && latlng[0].length() > 4) {
				String add1[] = U.getAddressGoogleApi(latlng); 
				if(add1 == null) add1= U.getAddressHereApi(latlng);
				add[0] = add1[0];
				geo = "TRUE";
			}
/*
			if (communityUrl.contains("http://greenecobuilds.com/lakes-of-savannah.php")) {
				propertyStatus = "Lake Homesites Available";
			}*/
			 if (communityName.contains("Heron's Landing"))add[1]="Texas City";


			// LOGGER.countOfCommunity(i);
			LOGGER.AddCommunityUrl(communityUrl);
			data.addCommunity(communityName, communityUrl, communityType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());

			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);

			data.addPropertyType(propertyType, Dtype);
			data.addPropertyStatus(propertyStatus);

			data.addPrice(minPrice, maxPrice);

			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);

		}
		j++;
	}
	
}