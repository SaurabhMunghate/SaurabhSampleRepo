/*
 * @author : Chinmay
 * @date : 21/07/2017
 */
package com.shatam.b_301_324;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ThriveHomeBuilder extends AbstractScrapper{
	CommunityLogger LOGGER;
	static String builderName="Thrive Home Builders";
	static String builderUrl="https://www.thrivehomebuilders.com";
	static int dupli = 0;
	WebDriver driver = null;
	public static void main(String[] args) throws Exception {
			U.log(builderUrl);
			AbstractScrapper abs=new ThriveHomeBuilder();
			abs.process();
			FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abs.data().printAll());
	}
	public ThriveHomeBuilder()
			throws Exception {
		super(builderName, builderUrl);
		LOGGER=new CommunityLogger(builderName);
	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		

		String commHtml=U.getHTML("https://www.thrivehomebuilders.com/find-your-new-home/")
				+U.getHTML("https://www.thrivehomebuilders.com/find-your-new-home-fort-collins/");
		//U.log(commHtml);
		int i=0;
		String[] comms=U.getValues(commHtml, "community-column wpb_column vc_column_container vc_col-sm-4", "Bathrooms</p>");
		U.log(comms.length);
		for (String comm : comms) {
			U.log("\n-------------"+i+"------------------");
			
//			String forStatus=U.getSectionValue(comm, "<div class=\"wpb_wrapper\">", "</div>");
			String forStatus=U.getSectionValue(comm, "<div class=wpb_wrapper>", "</div>");
//			forStatus=forStatus
//			U.log(forStatus);
			//----------------------------- Community URL-----------------------------
			String commURL=U.getSectionValue(comm, "<a href=\"", "\">");
//			String commURL=U.getSectionValue(comm, "<a href=", " >");
			
//			if (!commURL.contains("community/panacea-collection/"))continue;
			U.log("Community URL "+commURL);
//			U.log("pp==="+comm);
//			U.log(comm);
			String desc=U.getSectionValue(comm, "<p>", "<div class=\"baths");
			
			
			
			//----------------------------- Community Name-----------------------------
			String commName=Util.match(comm, "community-title\"><a href=https://www.thrivehomebuilders.com/.*>.*</a></h4>", 0);
			U.log(commName);
			if(commName == null)commName= U.getSectionValue(comm, "community-title\"><a href="+commURL, "<");
			commName=U.getSectionValue(comm,"community-title\"><a href=\""+commURL+"\">","<");
			if(commName == null)commName= U.getSectionValue(comm, "data-title=\"", "\"");
			if(commURL.contains("community/panacea-collection/"))
				commName ="Panacea Collection";
			U.log("Community Name=="+commName);
//			String address=U.getSectionValue(comm, "<em>", "</em>");
			//U.log(address);
			if (data.communityUrlExists(commURL)) {
				LOGGER.AddCommunityUrl(commURL+"***********************repeated");
				dupli++;
				return;
			}
			//----------------------------- Community Address-----------------------------
//			String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//			add[0]=U.getSectionValue(address, "<span class=\"addressStreet\">", "</span>");
//			add[1]=U.getSectionValue(address, "<span itemprop=\"addressLocality\">", "</span>");
//			add[2]=U.getSectionValue(address, "<span itemprop=\"addressRegion\">", "</span>");
//			add[3]=U.getSectionValue(address, "<span itemprop=\"postalCode\">", "</span>");
//			U.log("Coummunity Address: Street: "+add[0]+" City: "+add[1]+" State: "+add[2]+" zip: "+add[3]);
			//if(i==4)
//			if(add[0]!= null)
//			add[0]=add[0].replaceAll("By Appointment Only|Our Office is Currently at our Superior Location - Please Call Scott for Great Information!", ALLOW_BLANK);
//			U.log("commURL===="+commURL);
			
//			try {
				addDetails(commURL,commName.replace(">", ""),forStatus,comm,i);
//			} catch (Exception e) {}
			
			i++;
		}
		
		//driver.quit();
		LOGGER.DisposeLogger();
	}

	
//	public int j = 0;
	//TODO ::
	private void addDetails(String commURL, String commName,String forStatus,String Desc,int i) throws Exception {
		

//	if(j == 0)
		try
	{
		if(commURL.contains("/community/arista-3-story-rows/")) {
			LOGGER.AddCommunityUrl(commURL+"::::::::::::page giving 404 error");
			return;
		}

		
//--------- SINGLE EXECUTION ---------------------------------		
//		if(!commURL.contains("https://www.thrivehomebuilders.com/community/lorettoheights-denver/")) return;
		
		
		
		String latlngsec=null;
		String latlngHtml=U.getHTML("https://www.thrivehomebuilders.com/wp-json/wpgmza/v1/features/base64eJyrVkrLzClJLVKyUqqOUcpNLIjPTIlRsopRMopR0gEJFGeUFni6FAPFomOBAsmlxSX5uW6ZqTkpELFapVoABXgWuw");
		String latlngSec=U.getSectionValue(latlngHtml, "\"markers\":", "}]");
		
		String[]latlngData=U.getValues(latlngSec, "\"map_id\":", "html\":");
		U.log("latlngData length =="+latlngData.length);
		
		
		for(String latlng_data :latlngData) {
			latlng_data=latlng_data.replace("\\/", "/");
			if(latlng_data.contains(commURL)) {
				latlngsec=latlng_data;
//				if(latlng_data.contains("\"retina\":\"1\"") )
				U.log("latlng_data==="+latlng_data);
			}
		}
		
	
		commName=commName.replace("2-Story Rowhomes", "");
		
		String commHtml=U.getHTML(commURL);
			
			
		//--------------- QUICK STATUS ------------------
			int quickCount = 0;
			
			//U.log(">>>>>> "+Util.matchAll(commHtml,"[\\w\\W\\s]{40}Available Now[\\w\\W\\s]{40}", 0));
			
			if(commHtml.contains("<div class=\"property-available-now\">Available Now</div>")) {
				quickCount++;
			}
			
			U.log("quickCount: "+quickCount);
			
			
			String geoCode="False";
//			U.log("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< "+Desc);
			String[] commAdd= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//			if(commAdd[0] == null) {
				
				String addSec = U.getSectionValue(commHtml, "<h5>Sales Office Location</h5>", "</a>");
				
				
				//U.log(addSec);
				if(addSec!= null) {
					
					addSec = addSec.replace("<br />", ",");
					addSec = U.getNoHtml(addSec);
					
					commAdd = U.getAddress(addSec);
					U.log("ADDDD: "+Arrays.toString(commAdd));
				}
//			}
			
			if(commAdd[0].length()<5 ||commAdd[0] == ALLOW_BLANK) {
				
				String add = U.getSectionValue(Desc, "<em>", "</em>");
				
				if(add!= null) {
					
					String[] add1 = {ALLOW_BLANK,ALLOW_BLANK};
					
					add1 = add.split(",");
					
				}
			}
			//----------------------------- Community latitude longitude-----------------------------
			
			String lat=ALLOW_BLANK,lon=ALLOW_BLANK,note=ALLOW_BLANK;
			String sec=U.getSectionValue(commHtml, "<div class=\"wpb_column vc_column_container vc_col-sm-6\">", "target=\"");
		
			
			if(latlngsec!=null) {
				lat=U.getSectionValue(latlngsec, "\"lat\":\"", "\",");
				lon=U.getSectionValue(latlngsec, "\"lng\":\"", "\",");
			}
            // String latlong[]=U.getlatlongGoogleApi(commAdd);
            // lat=latlong[0];
         //   lon=latlong[1];
			
			
			
//			if(commURL.contains("https://www.thrivehomebuilders.com/community/vitality-collection/")) {
//				lat="39.980146";
//				lon="-105.014674";
//			}
			U.log("Latitude "+lat);
			U.log("Longitude "+lon);
			
			//------Address from city state.---------
			if(commURL.contains("/community/lorettoheights-denver")) {
				
				commAdd[0] = ALLOW_BLANK;
				commAdd[1] = "Denver";
				commAdd[2] = "CO";
				commAdd[3] = ALLOW_BLANK;
				
				U.log("Address ---- "+Arrays.toString(commAdd));
				
				String latLng[] = U.getlatlongGoogleApi(commAdd);
				lat = latLng[0];
				lon = latLng[1];
				
				commAdd = U.getAddressGoogleApi(latLng);
				geoCode = "TRUE";
				
				U.log("Address Final ---- "+Arrays.toString(commAdd));
			}
			
			
			if(commAdd[0].length()<3 && lat!=null) {
				commAdd[0]=U.getAddressGoogleApi(new String[] {lat,lon})[0];
				geoCode="TRUE";
			}
			
			U.log("Street::::"+commAdd[0]);
			
			
			if((lat== null || lat == ALLOW_BLANK) && (commAdd[0]!=ALLOW_BLANK)) {
				
				String[] latlng = U.getlatlongGoogleApi(commAdd);
				if(latlng == null) latlng = U.getlatlongHereApi(commAdd);
				if(latlng!= null) {
					lat = latlng[0];
					lon = latlng[1];
				}
				
				geoCode = "TRUE";
			}
			
			if(commURL.contains("/elements-income-qualified-rowhomes-at-central-park/")) {
				commAdd = new String [] {"1875 Lawrence Street","Denver","CO","80202"};
				String latLng[] = U.getlatlongGoogleApi(commAdd);
				lat=latLng[0];
				lon = latLng[1];
				geoCode = "TRUE";
				note = "Address Taken From Contact Page";
			}
			
			if(commAdd[0].contains("COMING SOON")) {
				
				commAdd = U.getAddressGoogleApi(new String[] {lat,lon});
				geoCode="TRUE";
			}
			

			
			//----------------------------- -----------------------------
			commHtml=commHtml.replace(" 2,800+ square feet", "2,800 square feet");
			String listSec=U.getSectionValue(commHtml, "<div class=\"communityDescription bdxRTEWrapper\">", "</div>")+U.getSectionValue(commHtml, "<div class=\"homeListingExpandSection\">", "<!-- directions -->");
			listSec=listSec.replace("THE MID $400’s.", " $400,000").replace("mid $500s.", "$500,000");
			listSec=listSec.replace(" 1,837 to 3,250 sq. ft.", "1,837 sq. ft. to 3,250 sq. ft.");
			commHtml=commHtml.replaceAll("collections are now available | Fireplace, MOVE-IN Ready", " ");
			//commHtml=commHtml.replace("Thrive Home Builders collections are now available in Hyland Village ", "Thrive Home Builders collections Hyland Village ");
			//commHtml=commHtml.replace(" Indoor/Outdoor Fireplace, MOVE-IN Ready", "Revel Zero Energy, Main Floor Master, Finished Basement, Indoor/Outdoor Fireplace,");
			//commHtml=commHtml.replace("data-moveindate=\"1/1/0001 12:00:00 AM\"", "");
			/*if (i==4) {
				U.log(listSec);
				U.log(commHtml);
			}*/
			String[] commSecs=U.getValues(commHtml, "<h3 class=\"xCommunityNameHeader\">", "</h3>");
			String plansHtml="";
			for (String commSec : commSecs) {
				commSec=U.getSectionValue(commSec, "<a href=\"", "\"");
				U.log(builderUrl+commSec);
				plansHtml=plansHtml+U.getHTML(builderUrl+commSec).replaceAll("Lot JUST RELEASED", "");
				
			}
			if (plansHtml!=null||plansHtml!="") {
				plansHtml=plansHtml.replaceAll("collections are now available | Fireplace, MOVE-IN Ready", " ");
			}
			//plansHtml=plansHtml.replace("Revel Zero Energy, Main Floor Master, Finished Basement, Indoor/Outdoor Fireplace, MOVE-IN Ready", "Revel Zero Energy, Main Floor Master, Finished Basement, Indoor/Outdoor Fireplace,");
			/*if (i==1) {
				//U.log(plansHtml);
				U.log(commHtml);
			}*/
			String planSec=U.getSectionValue(plansHtml, "<div class=\"communityDescription bdxRTEWrapper\">", "</div>");
			
			//============== Home Urls =================
			String combinedHtml = "";
			String[] homeUrls = U.getValues(commHtml, "custom_heading property-title\"><a href=\"", "\"");
			for(String homeUrl : homeUrls){
				U.log("homeUrl :"+homeUrl);
				String homeHtml= U.getHTML(homeUrl);
				
				if(homeHtml!=null)
					combinedHtml += U.getSectionValue(homeHtml, "<div class=\"sections", "<ul class=\"property-list\">");
			}
			//U.log(planSec);
			//----------------------------- Community min and max Sqft-----------------------------
			
			String sqFt[]=U.getSqareFeet((commHtml+listSec+planSec).replace("&#8211;", "-"), "<p>\\d{1},\\d{3} - \\d{1},\\d{3} Square Feet|\\d,\\d{3}-\\d,\\d{3} Square Feet|from \\d,\\d{3} to \\d,\\d{3} square feet|<li class=\"area\">\\d,\\d{3} - \\d,\\d{3} Square Feet</li>| from \\d,\\d{3} to \\d,\\d{3} sq. ft.|\\d{4} square feet|(\\d,\\d{3}\\sSquare\\sFeet)|(\\d,\\d{3}\\ssq.\\sft.)", 0);
			String minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];//Square
			String maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		
			U.log("Min Sqft "+minSqFt);
			U.log("Max Sqft "+maxSqFt);
			//----------------------------- Community min and max Price-----------------------------
			listSec=listSec.replace(" mid $300’s", "$300,000");
			
			commHtml = commHtml.replaceAll("0�s|0’s", "0,000")
//					.replace("Priced from the low $500’s", "Priced from the low $500’s")
					.replace("lower $400’s", "lower $400,000").replace("Mid $300s", "Starting at $300,000<").replace("0s", "0,000");
			Desc =Desc.replace("0�s", "0,000").replace("$400s", "$400,000");
			String price[]=U.getPrices(commHtml+listSec+Desc, "upper \\$\\d{3},\\d{3}|Upper \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}<|(\\$\\d{3},\\d{3})|(\\$\\d,\\d{3},\\d{3})", 0);
			 U.log(Util.matchAll(Desc, "[\\w\\s\\W]{30}$400[\\w\\s\\W]{30}", 0));
			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("Min Price "+minPrice);
			U.log("Max Price "+maxPrice);
//			if(commURL.contains("https://www.thrivehomebuilders.com/community/westridge/"))minPrice="$400,000";
//			if(commURL.contains("https://www.thrivehomebuilders.com/community/vitality-collection/"))
//			{
//				commAdd[0]="2251 W 156th Ave";
//				commAdd[1]="Denver";
//				commAdd[2]="CO";
//				
//				String latlng[]=U.getlatlongGoogleApi(commAdd);
//				commAdd=U.getAddressGoogleApi(latlng);
//			}
			
			//----------------------------propStatus----------------------------
			commHtml=commHtml.replaceAll("Courtyard Rendering|Courtyard_Render_|<div class=\"property-sold-out\">Sold Out</div>|Lot JUST RELEASED|Contemporary Farmhouse elevations|Contemporary Farmhouse Exterior", "");

			String remove = U.getSectionValue(commHtml, "<head>", "</head>");
			if(remove != null) commHtml = commHtml.replace(remove, "");
			
			String propStatus=U.getPropStatus((
					commHtml.replaceAll("-coming-soon\">Coming Soon|Fall 2017 Move-I|Ready To Move In October", "") 
			+plansHtml.replaceAll("Fall 2017 Move-In|With a move in date of Fall 2017|Ready To Move In October", "")
					+forStatus+Desc)
					.replaceAll("sold-out\\{background|property-sold-out|Ready To Move In October|class=\"sold-out\"|Lot JUST RELEASED|Lot JUST RELEASED|content=\"Now|description\":\"Now", ""));
		
			commHtml=commHtml.replaceAll("Superior 3-Story|Arista 3-Story Rows|arista-3-story-rows/|superior-3-story/|WestRidge 3-Story Rows", "");
			
			if(commURL.contains("https://www.thrivehomebuilders.com/community/domore-rows-at-baseline/")) {
				geoCode="false";
				//propStatus="Move In Ready Home";
			}
			
			U.log("quickCount: "+quickCount);
			
			if(quickCount > 0) {
				if(propStatus == ALLOW_BLANK)
					propStatus = "Quick Move-In";
				else if(propStatus != ALLOW_BLANK)
					propStatus = propStatus + ", Quick Move-In";	
			}
			
			
			U.log("propStatus ------------- "+propStatus);
			
//			U.log(">>>>>> "+Util.matchAll(commHtml,"[\\w\\W\\s]{40}sold-out[\\w\\W\\s]{40}", 0));
			
			
			//----------------------------- Writing Community data to file-----------------------------
			if(commHtml.contains(" <h3 class=\"\">Homes Available Now</h3>"))
				if(propStatus.length()<3)propStatus="Homes Available Now";
				else propStatus=propStatus+", Homes Available Now";
			propStatus=propStatus.replace("Ii", "II"); 
			
			LOGGER.AddCommunityUrl(commURL);
			note =U.getnote((commHtml).replaceAll("property-pre-selling-now", ""));
			
			U.log("note: "+note);
//			U.log(">>>>>> "+Util.matchAll(commHtml+plansHtml+Desc+combinedHtml,"[\\w\\W\\s]{40}pre-[\\w\\W\\s]{40}", 0));
			
			
			commHtml=commHtml.replace("luxury Panacea Home ", "luxury Home ");
			String ptype = U.getPropType((commHtml+plansHtml+Desc+combinedHtml).replace("<span>Downtown  Rowhomes</span>", "")
					.replaceAll("rowhomes|ROWHOMES", "row homes")
					.replaceAll("Retreat - Courtyard|_Courtyard", ""));
			
			//U.log("SQFT"+Util.matchAll(commHtml+plansHtml+Desc+combinedHtml,"[\\w\\W\\s]{40}row homes[\\w\\W\\s]{40}", 0));

			
			commName = commName.replaceAll(" 3-Story Rowhomes| In North End Neighborhood Of Central Park| In Central Park| Income Qualified Rowhomes at Stapleton", "").toLowerCase();
			
//			String latlagsec[]=U.getlatlongGoogleApi(commAdd);
//			lat=latlagsec[0];
//			lon=latlagsec[1];
//			geoCode="TRUE";
			//if(j==0)geoCode="FALSE";
			
			
//			================================================================================
			
			String lotCount=ALLOW_BLANK;
    		String mapLink=U.getSectionValue(commHtml, "<iframe class=\"new-community-site-plan\" src=\"", "\"");
    		U.log("mapLink=="+mapLink);
    		if(mapLink!=null) {
    			String mapHtml=U.getHtml(mapLink, driver);
    			if(mapHtml!=null) {
//    				String lotSec=U.getSectionValue(mapHtmls, "<g id=\"Lots\">", "")
    				String[] lot_data=U.getValues(mapHtml, "<g id=\"Symbol", "</g>");
    				U.log("lotCount=="+lot_data.length);
    				if(lot_data.length>0) {
    					lotCount=Integer.toString(lot_data.length);
    					 U.log("lotCount=="+lotCount);
    				}
    			}
    		}
    		
    		
    		//--------------- CtYpe---------------
    		
    		commHtml = commHtml.replace("spaces for active 55+ homeowners", "spaces for active adult and 55+ community homeowners");
    		
    		String cType = U.getCommunityType((commHtml+plansHtml));
    		
    		U.log("cType: "+cType);
    		
			
			//-------------------------------------------------------------
			
			data.addCommunity(commName, commURL, cType);
			data.addAddress(commAdd[0], commAdd[1], commAdd[2], commAdd[3]);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lon, geoCode);
			data.addPropertyType(ptype, U.getdCommType(commHtml.replaceAll(" 3-Story Rows|arista-3-story-rows/\" data-ps2id-api=\"true\">Arista 3-Story|floor|Floor", "")+Desc+plansHtml.replaceAll("First Floor|second story deck|2nd floor deck off|deck off the 2nd floor|round 2nd floor deck on|Floor|floor| deck on the second level", "")));
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			}catch(Exception e) {}
		}
	}
	
		
	

