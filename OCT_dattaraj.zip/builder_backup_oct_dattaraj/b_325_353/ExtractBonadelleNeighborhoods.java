package com.shatam.b_325_353;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBonadelleNeighborhoods extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractBonadelleNeighborhoods() throws Exception {
		super("Bonadelle Neighborhoods", "https://bonadelle.com/");
		LOGGER = new CommunityLogger("Bonadelle Neighborhoods");
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractBonadelleNeighborhoods();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Bonadelle Neighborhoods.csv", a.data().printAll());

	}
	@Override
	protected void innerProcess() throws Exception {
		String regHtml=U.getHTML("https://bonadelle.com/");
		
		String[] comSecs=U.getValues(regHtml, "<div class=\"wpb_content_element featured-box community-callout", "</p>");
//		String commSec=U.getSectionValue(regHtml, "<a href=\"#\">Communities</a>", "</ul>");
//		String[] comUrls=U.getValues(commSec, "<a href", "a></li>");
		for(String comSec:comSecs) {
//				U.log(comSec);
				String commName="";
				String comUrl=U.getSectionValue(comSec, "href=\"", "\"");
				if(comUrl.contains("https://harvestbonadelle.com")) {
					commName=U.getSectionValue(comSec, "<p>A unique new community, ", " is built");
				}else if(comUrl.contains("https://elpaseobonadelle.com")) {
					commName=U.getSectionValue(comSec, "<p>", " is a private");
				}else {
					commName=U.getSectionValue(comSec, "<p>", " features");
				}
//				U.log(comUrl+" name: "+commName);
				try {
					addDetails(comUrl,commName,comSec);
				}catch(Exception ex) {
					
				}
//			break;
		}
		LOGGER.DisposeLogger();
	}
		
	
	private void addDetails(String comUrl, String commName, String comSec) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://grovebonadelle.com"))return;
		
		// ----------------- Community Url-----------------------
		U.log("communityURL===> "+comUrl);
		
		if (comUrl.contains("#")) {
			LOGGER.AddCommunityUrl("-------Redirect community url not present-------" + comUrl);
			return;
		}
		
		String comHtml = U.getHTML(comUrl);
	
		U.log(U.getCache(comUrl));
//		U.log("comSec====> "+comSec);
		// ----------------- Community Name-----------------------
		U.log("comName====> "+commName);
		if(commName==null)
			commName=U.getSectionValue(comHtml, "<title>", "</title>");
		if(comUrl.contains("https://grovebonadelle.com")) {
			commName="The Grove IV";
		}
		commName=commName.replace("Wisteria Creek at Loma Vista - Bonadelle Neighborhoods", "Wisteria Creek");
		U.log("comName====> "+commName);
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				String addSec=U.getSectionValue(comHtml, "Location        </h4>", "@bonadelle.com</");
				if(addSec==null)
					addSec=U.getSectionValue(comHtml, "Location        </h4>", "@Bonadelle.com</");
				String address=U.getSectionValue(comHtml, "data-markjs=\"true\">", "</span>");
				if(address==null) {
					latLong[0]=U.getSectionValue(comHtml, "\"lat\":\"", "\"");
					latLong[1]=U.getSectionValue(comHtml, "\"lng\":\"", "\"");
					U.log(">>>>>>>"+latLong[0]+"");
//					if(latLong[0]!=null)
//					add=U.getAddressGoogleApi(latLong);
//					geo="True";
					address=U.getSectionValue(comHtml, "Address:", "</span>");
					
					
					if(address!=null) {
						
						address=U.getNoHtml(address);
						address=address.replace("Clovis,", ", Clovis,");
						add=U.getAddress(address);
					}
					
					if(comUrl.contains("shannonranchbonadelle")) {
						add[3]="93291";
					}
					U.log(">>>>>>>"+address);
				}else {
					add=U.getAddress(address);
					addSec=addSec.replace("https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3189.6725962348974!2d-119.80369937372399!3d36.92209173804992!", "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!3d36.92209173804992!2d-119.80369937372399!");
					latLong[0]=Util.match(addSec, "\\d{2}.\\d{5,}");
					latLong[1]=Util.match(addSec, "-\\d{2,3}\\.\\d{5,}");
				}
				if(add[0]==ALLOW_BLANK&&latLong[0]!=ALLOW_BLANK) {
					add=U.getAddressGoogleApi(latLong);
					geo="TRUE";
				}
				U.log("Address ::"+Arrays.toString(add));
				U.log(Arrays.toString(latLong));
				
				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
				String homeData="";
				String homeSec=U.getSectionValue(comHtml, "<ul id=\"mega_main_menu_ul\" class=\"mega_main_menu_ul\">", "</a> 	</li> 	</ul><!-- /.mega_dropdown --> </li> <li id=\"menu-item-");
				if(homeSec!=null) {
//				U.log(">>>>>>>>"+homeSec);
				String[] homeUrls=U.getValues(homeSec, "<a href=\"", "\"");
//				int c=0;
				U.log(">>>>>>>>"+homeUrls.length);
				
				for(String homeUrl:homeUrls) {
					if(!homeUrl.contains("#")) {
//					c++;
//					U.log(c+"== "+homeUrl);
						String _homeHtml = U.getHTML(homeUrl);
						String rem = U.getSectionValue(_homeHtml, "<head>", "</head>");
						if(rem != null) _homeHtml = _homeHtml.replace(rem, "");
						
						homeData += _homeHtml;
					}
				}
				}

					
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml+homeData,	"\\d,\\d{3} Sq.Ft.|\\d,\\d{3} Sq. Ft|\\d,\\d{3} to \\d,\\d{3} square feet", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				comHtml=comHtml.replace("Canyon Creekside Bonadelle homes start from the low $200,000", "")
						.replaceAll("alt=\"Lineage - Tuscan Starting from \\$\\d{3},\\d{3}|alt=\"Tradition - Spanish Starting from \\$\\d{3},\\d{3}", "");
				
				String price[] = U.getPrices(comSec+comHtml+homeData, "Starting from the \\$\\d{3},\\d{3}|<strong>\\$\\d{3},\\d{3}</strong>|from the low \\$\\d{3},\\d{3}|STARTING FROM \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
//				U.log(Util.matchAll(comSec, "[\\s\\w\\W]{30}300[\\s\\w\\W]{30}", 0));

				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				comHtml=comHtml
						.replace("exterior elevation choices, including modern farmhouse.", "exterior elevation choices, including modern Farmhouse exterior.")
						.replaceAll("a custom-quality|Luxurious Features", "");
				
				propType=U.getPropType((comHtml+homeData).replace("custom quality features", "a custom-quality features").replaceAll("Modern Farmhouse|American Traditional, Craftsman|Choose from Cottage|jeffreyscottagency", "").replace("craftsmanship and exceptional attention to detail", "").replace(" including modern farmhouse.", "").replace("Choose from American Traditional, Craftsman, or Farmhouse", ""));
				

				U.log("PType========>:::"+propType);
//				U.log(Util.matchAll(homeData, "[\\s\\w\\W]{30}craftsman[\\s\\w\\W]{30}", 0));
				
				//=========== Community Type ========================
				
				commType = U.getCommType(comHtml.replaceAll("Sherwood Forest Golf Club|RESORT-STYLE SWIMMING POOLS", ""));
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType(comHtml+homeData);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
			
				comHtml=comHtml.replaceAll("Move-In Ready|Move-in Ready", "");
				
				propStatus=U.getPropStatus(comHtml);

				U.log("PStatus========>:::"+propStatus);
				
		
				
				if(comUrl.contains("shannonranchbonadelle"))commName="Shannon Ranch";		

				if(comUrl.contains("https://harvestbonadelle.com/"))commName="Harvest II";
				
				//Status from images
				if(comUrl.contains("https://harvestbonadelle.com/") ||
						comUrl.contains("https://grovebonadelle.com")||
						(comUrl.contains("https://shannonranchbonadelle.com/"))||
						(comUrl.contains("https://wisteriacreekbonadelle.com"))) {
					
					propStatus = "Now Selling";//from img
				}
				if(propStatus.length()==0)
					propStatus= ALLOW_BLANK;
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
				data.addCommunity(commName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
		
	}

	

}