package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCedarCreek extends AbstractScrapper {
	
	static int i = 0;
	CommunityLogger LOGGER;
	public static String builderUrl = "https://cedarcreek-kc.com";
	WebDriver driver;

	public ExtractCedarCreek() throws Exception {
		// TODO Auto-generated constructor stub
		super("Cedar Creek", builderUrl);
		LOGGER = new CommunityLogger("Cedar Creek");
	
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractCedarCreek();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Cedar Creek.csv", a.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		String dataUrl = "https://cedarcreek-kc.com/neighborhoods/";
		
		String mainHtml = getHtml(dataUrl, driver);
		U.log(U.getCache(dataUrl));
		
		String mainSection = U.getSectionValue(mainHtml, "aria-current=\"page\">Neighborhoods</a>", "</ul>");
		//U.log("mainSection: "+mainSection);
		
		String[] communities = U.getValues(mainSection, "<li class=\"menu-item menu-item-type-post", "</li>");
		U.log("Total Communities: "+communities.length);
		
		for(String comSec:communities) {
			
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\">");
			U.log("comUrl: "+comUrl);
			
			addDetails(comUrl, comSec);
			
		}
		
		LOGGER.DisposeLogger();
		//driver.quit();
	}
	
	
	public void addDetails(String comUrl, String comSec) throws Exception {
	
		
		U.log("Count: "+i+"  comUrl: "+comUrl);

//------SINGLE EXECUTION BELOW-------//
		
//		if(!comUrl.contains("https://cedarcreek-kc.com/neighborhoods/the-meadows-at-valley-ridge/")) return;
		
//		if(i>=3)
		
		{
		
		String comHtml = getHtml(comUrl, driver);
		U.log(U.getCache(comUrl));
		
		// ------------------ UNITS COUNT ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		
		
		//---------------- COMMUNITY NAME ------------------ 
		//PLEASE NOTE: We are getting model homes and inventry homes data by matching the
		// comName. Please make sure they are in proper format.
		
		String comName = U.getSectionValue(comHtml, "<strong>Welcome to ", "</strong>"); 
//		comName = comName.replace("The Meadows at Valley Ridge","The Meadows").trim();
		
		if(comUrl.contains("/neighborhoods/hidden-lake-estates/")) comName = "Hidden Lake Estates";
		if(comUrl.contains("/the-villas-at-hidden-lake/")) comName = "The Villas at Hidden Lake";
		if(comUrl.contains("/neighborhoods/the-ridge-at-shadow-glen/")) comName = "The Ridge";
		if(comUrl.contains("/neighborhoods/the-meadows-at-valley-ridge/")) comName = "The Meadows";
		
		U.log("comName: "+comName);
		
		//---------------- ADDRESS AND LATLONG ------------------
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };	
		String geo = "FALSE";
		
		
		String[] latLong =  getLatLng(comUrl, comHtml);
		U.log("latLong: "+Arrays.toString(latLong));
		
		
		//----------- ADDRESS FROM MAP GIVEN INSIDE ------------------------ 
		if(comUrl.contains("/neighborhoods/the-meadows-at-valley-ridge/")) {
			
			String iframeUrl = U.getSectionValue(comHtml, "src=\"https://www.google.com/maps/embed", "\"");
			iframeUrl = "https://www.google.com/maps/embed" + iframeUrl;
			
			U.log("iframeUrl here: "+iframeUrl);
			
			String dataForAddress = U.getHTML(iframeUrl);
			U.log(U.getCache(iframeUrl));
			
			if(dataForAddress != null) {
				
				String addSec = U.getSectionValue(dataForAddress, "Meadows at Valley Ridge,", "\",[").trim();
				U.log("addSec: "+addSec);
				
				add = U.getAddress(addSec);
				U.log("ADDRESS ====== "+Arrays.toString(add));
			}
		}
		
		if(latLong[0] != ALLOW_BLANK && add[0] == ALLOW_BLANK) {
			
			add = U.getAddressGoogleApi(latLong);
			geo = "TRUE";
			U.log("ADDRESS: "+Arrays.toString(add));
		}
		
		
		//---------------- MODEL HOMES DATA ------------------
		String modelHomesData = ALLOW_BLANK;
		
		modelHomesData = getModelData(comName);
		
		//---------------- INVENTRY HOMES DATA ------------------
		String inventryHomesData = ALLOW_BLANK;
				
		inventryHomesData = getInventryData(comName);
		
		
		//--------- REMOVING SECTIONS --------------
		String storiesSec = U.getSectionValue(comHtml,"House style I am interested in:</label>", "</p>");
		//U.log("storiesSec: "+storiesSec);
		if(storiesSec != null) comHtml = comHtml.replace(storiesSec, "");
		
		String priceRangeSec = U.getSectionValue(comHtml,"title\">Price Range:</span>", "</span></span>");
		//U.log("priceRangeSec: "+priceRangeSec);
		if(priceRangeSec != null) comHtml = comHtml.replace(priceRangeSec, "");
		
		//Replacing Lot Prices below
		comHtml = comHtml.replaceAll("Lots sizes range from 1/4 to 1/2 acre with prices ranging from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Lot prices range from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|"
				+ "Lot prices range from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}", "");
			
		//---------------- PRICES ------------------
		String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comHtml = comHtml.replaceAll("00’s|00’s", "00,000")
				.replace("Homes start in the $600’s", "Homes start in the $600,000");
		
		prices = U.getPrices(comHtml+modelHomesData+inventryHomesData, "ACTIVE\\s+\\$\\d{3},\\d{3}|in the \\$\\d{3},\\d{3}|the upper \\$\\d{3},\\d{3}|the low \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|over \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log(Arrays.toString(prices));
//		U.log(">>>>>>>>"+Util.matchAll(comHtml+modelHomesData+inventryHomesData, "[\\w\\s\\W]{60}999,999[\\w\\s\\W]{60}",0));
		
		//---------------- SQUARE FEETS ------------------	
		String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		
		sqft = U.getSqareFeet(comHtml+modelHomesData+inventryHomesData, "\\d,\\d{3}\\s+Square Feet|square-feet\"> Sq. Ft.: \\d,\\d{3} </div>|<b> \\d,\\d{3} </b> <br /> SqFt", 0);
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log(Arrays.toString(sqft));
//		U.log(">>>>>>>>"+Util.matchAll(comHtml+modelHomesData+inventryHomesData, "[\\w\\s\\W]{60}3,045[\\w\\s\\W]{60}",0));
		
		//---------------- PROPERTY TYPE ------------------
		String pType = ALLOW_BLANK;
		
		if(comUrl.contains("-estates")) comHtml = comHtml + "Estate Style"; 
		
		pType = U.getPropType((comHtml+modelHomesData+inventryHomesData).replaceAll(">Home Owner’s Association</a>|luxurious bathroom", ""));
		
		U.log("pType: "+pType);
		
//		U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}luxur[\\w\\s\\W]{30}",0));
//		U.log(">>>>>>>>"+Util.matchAll(modelHomesData, "[\\w\\s\\W]{30}luxur[\\w\\s\\W]{30}",0));
//		U.log(">>>>>>>>"+Util.matchAll(inventryHomesData, "[\\w\\s\\W]{30}luxur[\\w\\s\\W]{30}",0));
		
		//---------------- DERIVED PROPERTY TYPE ------------------
		String dType = ALLOW_BLANK;
		
		dType = U.getdCommType((comHtml+modelHomesData+inventryHomesData).replaceAll("[f|F]loor", ""));
		U.log("dType: "+dType);
		
		//---------------- COMMUNITY TYPE ------------------
		String cType = ALLOW_BLANK;
				
		cType = U.getCommType((comHtml).replaceAll("\"Old Golf Section from Amenities|shadow-glen-golf-club/\">Shadow Glen Golf Club|content=\"Welcome to Resort-style Living in Olathe|Welcome to Resort-style Living in Olathe", ""));
		
		U.log("cType: "+cType);
		
//		U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}resort[\\w\\s\\W]{30}",0));
//		U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}golf[\\w\\s\\W]{30}",0));
		
		//---------------- STATUS ------------------
		String status = ALLOW_BLANK;
		
		status = U.getPropStatus((comHtml).replaceAll("many brand new lots available", ""));
		U.log("status: "+status);
		
		
		
		//---------------- NOTES ------------------
		String note = ALLOW_BLANK;
		note = U.getnote(comHtml);
		U.log("note: "+note);
		
		//---------------------Status from images and videos---------------------------
		if(comUrl.contains("https://cedarcreek-kc.com/neighborhoods/valley-ridge/")) status = "Phase 6 Now Open";
		
		//------------------- ADDING DATA ------------------------
		
		if(comUrl.contains("/neighborhoods/the-ridge-at-shadow-glen/")) comName = "The Ridge At Shadow Glen";
		if(comUrl.contains("/neighborhoods/hidden-lake-estates/")) comName = "Hidden Lake";
		
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(comName, comUrl, cType);
		data.addLatitudeLongitude(latLong[0], latLong[1], geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);
		
		
		U.log("");
		
		}
		
		i++;
		
	}
	
	public String[] getLatLng(String comUrl, String comHtml) throws Exception {
		
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
		
		if(comHtml.contains("https://www.google.com/maps/embed")) {
			
			U.log("From getLatLng Method");
			
			String iframeUrl = U.getSectionValue(comHtml, "src=\"https://www.google.com/maps/embed", "\"");
			iframeUrl = "https://www.google.com/maps/embed" + iframeUrl;
			
			U.log("iframeUrl: "+iframeUrl);
			
			//----- getting latLong from iframeUrl ------
			
			latLng[0] = Util.match(iframeUrl, "!3d\\d{2}.\\d{5,9}");
			latLng[0] = latLng[0].replace("!3d", "");
			
			latLng[1] = Util.match(iframeUrl, "!2d-\\d{2}.\\d{5,9}");
			latLng[1] = latLng[1].replace("!2d", "");
			
			U.log(Arrays.toString(latLng));
		}
		
		return latLng;
	}
	
	
	public String getModelData(String comName) throws Exception {
		
		String modelHomesData = ALLOW_BLANK;
		
		String modelHomesHtml = U.getHtml("https://cedarcreek-kc.com/model-homes/", driver);
		
		//String[] modelValues = U.getValues(modelHomesHtml, "<div class=\"ihf-grid-result col-xs-4", "</div> </div> </div> </div> </div>");
		String[] modelValues = U.getValues(modelHomesHtml, "<div class=\"ihf-grid-result col-xs-4", "</div> </div> </div> </div> </div>");
		U.log("modelValues: "+modelValues.length);
		
		for(String model:modelValues) {
			
			String modelUrl = U.getSectionValue(model, "<a href=\"", "\">");
			U.log("modelUrl: "+modelUrl);
			
//			if(modelUrl.contains("/25262-W-112TH-TERRACE-OLATHE-KS-66061/2247486/76/")) continue;
			
			String modelHomes = getHtml(modelUrl, driver);
			U.log(U.getCache(modelUrl));
			
			//String subDivision = U.getSectionValue(modelHomes, "title\">Subdivision:</span>", "</div>");
//			String subDivisionSec = U.getSectionValue(modelHomes, "Subdivision</p>", "</div></div></div>");
//			U.log("subDivisionSec: "+subDivisionSec);
			
			String subDivision = U.getSectionValue(modelHomes, "Subdivision", "MLS Area");
			subDivision = subDivision.replace("Cedar Creek - ", "").trim();
			U.log("subDivision: "+subDivision);
//			U.log("comName: "+comName);
//			
			if(comName.equals(subDivision)) {
				
				U.log("MATCHED MODEL");
				U.log("subDivision: "+subDivision);
				U.log("modelUrl: "+modelUrl);
				
				modelHomesData += model + modelHomes;
			}
		}
		
		return modelHomesData;
		
	}
	
	
	public String getInventryData(String comName) throws Exception {
		
		String inventryHomesData = ALLOW_BLANK;
		
		String inventryHomesHtml = U.getHtml("https://cedarcreek-kc.com/home-inventory/new-home-inventory/", driver);
		
		//String[] inventryValues = U.getValues(inventryHomesHtml, "<div class=\"ihf-grid-result col-xs-4", "</div> </div> </div> </div> </div>");
		String[] inventryValues = U.getValues(inventryHomesHtml, "<div class=\"ihf-grid-result col-xs-4", "</div> </div> </div> </div> </div>");
		U.log("inventryValues: "+inventryValues.length);
		
		for(String inventry:inventryValues) {
			
			String inventryUrl = U.getSectionValue(inventry, "<a href=\"", "\">");
			//U.log("inventryUrl: "+inventryUrl);
			
			String inventryHomes = getHtml(inventryUrl, driver);
			U.log(U.getCache(inventryUrl));
			
//			String subDivision = U.getSectionValue(inventryHomes, "title\">Subdivision:</span>", "</div>");
			String subDivision = U.getSectionValue(inventryHomes, "Subdivision", "MLS Area");
			if(subDivision!=null) {
				
				subDivision = subDivision.replaceAll("Cedar Creek- |Cedar Creek - ", "").trim();
				U.log("subDivision: "+subDivision);
			}
			
			if(comName.equals(subDivision)) {
				
				U.log("MATCHED INVENTRY");
				U.log("subDivision: "+subDivision);
				U.log("inventryUrl: "+inventryUrl);
				
				inventryHomesData += inventry + inventryHomes;
				
			}
		}
		
		
		return inventryHomesData;
		
	}
	
	
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("<iframe class=\"pwgt-iframe-xL5s1rWJ\" src=\"https://platwidget.com")) {
			
			
			frameUrl = U.getSectionValue(comHtml, "<iframe class=\"pwgt-iframe-xL5s1rWJ\" src=\"https://platwidget.com", "\""); 
			frameUrl = "https://platwidget.com" + frameUrl;
			U.log("frameUrl: "+frameUrl);
			
			if(frameUrl.contains("platwidget.com")) {
				
				mapData = U.getHtml(frameUrl, driver);
				U.log(U.getCache(frameUrl));
				
				if(mapData.contains("class=\"pw-lots mkr\"")) {
					
					ArrayList<String> pins = Util.matchAll(mapData, "class=\"pw-lots mkr\"", 0);
					U.log("Count Pins: "+pins.size());
					totalUnits = String.valueOf(pins.size());
				}
				
				if(mapData.contains("class=\" mkr\"") && comUrl.contains("/neighborhoods/the-ridge-at-shadow-glen/")) {	
					
					ArrayList<String> pins = Util.matchAll(mapData, "class=\" mkr\"", 0);
					U.log("Count Pins: "+pins.size());
					totalUnits = String.valueOf(pins.size());
				}
				
				if(mapData.contains("class=\"pw-lot mkr\"") && comUrl.contains("/neighborhoods/hidden-lake-estates/")) {
					
					ArrayList<String> pins = Util.matchAll(mapData, "class=\"pw-lot mkr\"", 0);
					U.log("Count Pins: "+pins.size());
					totalUnits = String.valueOf(pins.size());
				}
				
				
			}
			

		}
		
		
		return totalUnits;
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
//					Thread.sleep(10000);
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(9000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,9000)", ""); 

					//U.log(div);
				//	Thread.sleep(000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();

					try {
						html += driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div[2]/div/div[1]/article/div")).getText();
					}catch(Exception e) {}
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}


}