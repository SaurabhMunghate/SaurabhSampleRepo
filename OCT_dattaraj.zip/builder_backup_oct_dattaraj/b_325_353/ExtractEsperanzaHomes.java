package com.shatam.b_325_353;
import java.util.Arrays;

/**
 * @author MJS
 * @date 01/04/2021 
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEsperanzaHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.esperanzahomes.com";

	public ExtractEsperanzaHomes() throws Exception {
		super("Esperanza Homes", builderUrl);
		LOGGER = new CommunityLogger("Esperanza Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractEsperanzaHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Esperanza Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {

//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.esperanzahomes.com/new-homes/");
		String[] mainSec = U.getValues(html, "<div class=\"col-12 col-md-6 col-lg-12 mb-3 px-2\">", "</div></div></div></div></div>");
		U.log("mainSec length: "+mainSec.length);
		
		
		for(String main : mainSec) {
			
			String comUrl = builderUrl + U.getSectionValue(main, "href=\"", "\"");
			U.log("comUrl: "+comUrl);
			
//			try {
				getDetail(comUrl, main);
//			} catch (Exception e) {}
			
		}
		//driver.quit();
		LOGGER.DisposeLogger();
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/villas-on-freddy/5529/")) return;
		
		U.log("Count: " + j + "\t" + comUrl);
		
//		if(j==0)
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHtml(comUrl, driver);
			// ============================================Community
			// name=======================================================================
			
			U.log("com: "+com);
			
			String communityName = U.getSectionValue(com, "<div class=\"card-title\">","</div>");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'").replace("ñ", "n").replace("So�ador Coves", "So�ador Coves");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "Sales Office</div>", "GET DIRECTIONS</a>");
			U.log("addSec: "+addSec);
			
			if(addSec!=null) {
				
				String addVal = U.getSectionValue(addSec, "overpass\"><div>", "</div><div class=");
				
				if(addVal!=null)
					addVal = addVal.replace("</div><div>", ", ")
					.replace("Paso Real Hwy. (FM 509) &amp; Haine Dr.", "Paso Real Hwy")
					.replace("2401 Mile 1 South Road,", "2401 Mile 1 South Road")
					.replaceAll("<span class=\"d-inline-block mb-3\">", ",")
					.replaceAll("NC,", "NC ").replace("3612 Harvard Ave, McAllen, TX 78504 ,McAllen, TX 78504", "3612 Harvard Ave, McAllen, TX 78504")
					.replace("SC,", "SC ")//.replace("<span class=\"d-inline-block mb-3\">McAllen, TX 78504</span>", "")
					.replace("Ave McAllen", "Ave, McAllen")
					.replaceAll("</span>", "");
				
				U.log(addVal);
				add = U.getAddress(addVal);
			}
			if(add[0]!=null)
			add[0]=add[0].replace("3612 Harvard Ave, McAllen, TX 78504", "3612 Harvard Ave");
			
			U.log("Address----> "+Arrays.toString(add));

			// --------------------------------------------------latlng----------------------------------------------------------------
			if(addSec!=null) {
				
				String latSec = U.getSectionValue(addSec, "maps.google.com/maps?q=", "\"");
				latLng = latSec.split(",");
			}
			
			
//			U.log(addSec);
			U.log(Arrays.toString(latLng));
			if(latLng.length==0) {
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				
				if (add[3] == null||add[3].length() < 5)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//====== Floor Plans ================================
//			String floorPart = U.getSectionValue(html, "<section class=\"py-5\" id=\"activeplans\">", "</section>");
			String floorPart = U.getSectionValue(html, "Available Floor Plans</div>", "</section>");
			//U.log("floorPart: "+floorPart);
			
			if(floorPart==null)
				floorPart = "";
			
			String[] floorSec = U.getValues(floorPart, "<div class=\"col-12 col-md-6 mb-3\">", "</div></div></a></div></div>");
			U.log("floorSec length :"+floorSec.length);
			
			String floorData = ALLOW_BLANK;
			int i = 0;
			for(String floor : floorSec) {
//				U.log(floor);
				
				String floorUrl = builderUrl + U.getSectionValue(floor, "href=\"", "\"");
				U.log("floorUrl: "+floorUrl);
				
				String floorHtml=U.getHtml(floorUrl, driver);
				//String remSec=U.getSectionValue(floorHtml, "EXPLORE THIS HOME", "button type=\"button\" class=\"next-arrow slick-arrow\"");
				
//				if(remSec!=null) {
//					floorHtml=floorHtml.replace(remSec, "");
//				}
//				floorData += U.getSectionValue(floorHtml, "<div class=\"container py-5\">", "</div></div></div>");

				
//				if(i>5)
//					break;
//				else
//					i++;
					
			}
			//====== Available Homes ================================
			//String homePart = U.getSectionValue(html, "<section id=\"availablehomes", "</section>");
			String homePart = U.getSectionValue(html, "Quick Move-Ins</div>", "</section>");
			if(homePart==null)
				homePart = "";
			boolean avail = false;
			
			String[] homeSec = U.getValues(homePart, "<div class=\"col-12 col-md-6 mb-3\">", "</div></div></div></div></div>");
			U.log("homeSec length: "+homeSec.length);
			
			String homeData = ALLOW_BLANK;
			int k = 0;
			
			for(String home : homeSec) {
//			U.log(home);
			
			//---- For Quick Move In Status ------------------------	
			if(home.contains("Available Oct 2022")) {
				avail = true;
			}	
					

				String homeUrl = builderUrl + U.getSectionValue(home, "<a href=\"", "\"");
				U.log("homeUrl: "+homeUrl);
				
				homeData += U.getHtml(homeUrl, driver);

			}
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0’s|0s|0's", "0,000").replaceAll("From</div><div class=\"price\">\\$(\\d{3},\\d{3})</div>", "From \\$$1</div>");
			
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
						
			String prices[] = U.getPrices(com + html + floorData + homeData, "From the high \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|price-title\">From \\$\\d{3},\\d{3}</div>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log(">>>>>>>>>>>>>> "+Util.matchAll(com + html + floorData, "[\\s\\w\\W]{60}From the high[\\s\\w\\W]{60}", 0));

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html + floorData + homeData,">\\d,\\d{3} Sq. Ft.</div>",0);
			
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			U.log(">>>>>>>>>>>>>> "+Util.matchAll(html , "[\\s\\w\\W]{100}1,395[\\s\\w\\W]{60}", 0));

			

			// ================================================community
			// type========================================================
			
			String communityType = U.getCommType((html + com).replaceAll("Elongated|Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================
			
			String proptype = U.getPropType((html + com + floorData + homeData).replaceAll("Village|village|villas-on-freddy|Villas on Freddy|farmhouse|Farmhouse|FARMHOUSE","").replaceAll("FARMHOUSE_HARDIE|\\d+ <br>Single Family</p>|Villas on Freddy|villas-on-|Villas On Freddy", ""));
//			U.log("kkkkkkkkkk "+Util.matchAll(html + com, "[\\s\\w\\W]{100}patio[\\s\\w\\W]{100}", 0));
//			U.log("kkkkkkkkkk "+Util.matchAll(homeData+floorData, "[\\s\\w\\W]{100}patio[\\s\\w\\W]{100}", 0));
			// ==================================================D-Property
			// Type======================================================
			String dtype = U.getdCommType((html + com + floorData + homeData).replaceAll("Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor|<li>Tri-level (T|t)errace</li>", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
//			U.log(com);
			html = html.replaceAll("coming soon!|>Coming Soon</a>|=coming-soonlocations coming soon|McAllen now open|Quick Delivery|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("coming soon!|>Coming Soon</a>|=coming-soon|locations coming soon|Quick Delivery|Coming soon, neuhouse|Price<br/> Coming Soon", "");
			
//			U.log("kkkkkkkkkk "+Util.matchAll(html + com, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{100}", 0));

			
			String pstatus = U.getPropStatus((html + com)
					.replace("Phase 2, now selling", "Phase 2 Now Selling")
					.replace("Coming soon to San Juan", "").replaceAll("\\s*Coming Soon",""));

			U.log("pstatus: "+pstatus);
//			U.log(">>>>>>>>>>>>>> "+Util.matchAll(html + com, "[\\s\\w\\W]{100}now selling[\\s\\w\\W]{100}", 0));

			// ============================================note====================================================================

			//========== Hard Code Data ==================================price from slider img
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/campo-de-suenos/7016/"))
//					minPrice = "$100,000";
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/cascada-at-tres-lagos/7147/"))
//				minPrice = "$200,000";
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/ensenada-at-tres-lagos/4108/"))
//				minPrice = "$300,000";
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mission/rio-plata-at-bentsen-palm/6924/"))
//				minPrice = "$160,000";
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mcallen/villas-on-freddy/5529/"))
//				minPrice = "$200,000";

			if(homeSec!=null && homeSec.length>0 && avail == true)
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-Ins";
				else if(!pstatus.contains("Quick"))
					pstatus += ", Quick Move-Ins";
			
			U.log("pstatus here: "+pstatus);
			
			note=U.getnote(html);
			U.log("note: "+note);
			

//			//below pstatus come from image source
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/brownsville/palo-alto-groves/7522/")) pstatus ="phase I sold out, phase II coming soon, Quick Move-In Homes";
//			if(comUrl.contains("https://www.esperanzahomes.com/new-homes/tx/mission/sendero-at-bentsen-palm/9628/"))pstatus="Coming Summer 2022";//frm image
			
			
			U.log("Address >>>>>>>> "+add[0]+">>>"+add[1]+">>>"+add[2]+">>>"+add[3]);


			
			
			//======Site Map======
			int lotCount=0;
			String noOfUnits=ALLOW_BLANK;
			if(html.contains("Interactive Lot Map")|| html.contains("Interactive Site Map")) {
				noOfUnits=getUnits(html);
				/*String frameSec=U.getSectionValue(html, "<iframe allowfullscreen=", "</iframe>");
				String siteMapUrl=U.getSectionValue(frameSec, "src=\"", "\">");
				U.log("siteMapUrl:: "+siteMapUrl);
				String siteMapHtml=U.getHtml(siteMapUrl,driver);
				U.log("SSS"+U.getCache(siteMapUrl));
				String lotData[]=U.getValues(siteMapHtml, "<span class=\"legend_text \"", "</div>");
				for(String lots:lotData) {
					String lot=U.getNoHtml(lots);
			//		U.log("lot= "+lot);
					String lotNum=Util.match(U.getSectionValue(lot, "(", ")"), "\\d+");
				//	U.log("Num "+lotNum);
					lotCount+=Integer.parseInt(lotNum);
				}
				noOfUnits=Integer.toString(lotCount);
				
				
			*/
			}
			
			U.log("no. 0f Units= "+noOfUnits);
			//=========================================================================================================================
			data.addCommunity(communityName.replace("So�ador Coves", "Sonador Coves").replace(",", ""), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());//.replace(",", "")
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
	        data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	        data.addUnitCount(noOfUnits);

		}
		j++;
	}

	private String getUnits(String html) throws Exception {
		String frameSec=U.getSectionValue(html, "<iframe allowfullscreen=", "</iframe>");
		String siteMapUrl=U.getSectionValue(frameSec, "src=\"", "\">");
		
		if(siteMapUrl.contains("\" title=\"Community Map")) {
			siteMapUrl = siteMapUrl.replace("\" title=\"Community Map", "");
		} 
		
		U.log("siteMapUrl:: "+siteMapUrl);
		
		
		String siteMapHtml=U.getHtml(siteMapUrl,driver);
		U.log("SSS"+U.getCache(siteMapUrl));
		String lotData[]=U.getValues(siteMapHtml, "<span class=\"legend_text \"", "</div>");
		int lotCount=0;
		String noOfUnits=ALLOW_BLANK;
		for(String lots:lotData) {
			String lot=U.getNoHtml(lots);
	//		U.log("lot= "+lot);
			String lotNum=Util.match(U.getSectionValue(lot, "(", ")"), "\\d+");
		//	U.log("Num "+lotNum);
			lotCount+=Integer.parseInt(lotNum);
		}
		noOfUnits=Integer.toString(lotCount);
		
		if(noOfUnits.equals("0"))
			return ALLOW_BLANK;
		else
			return
				noOfUnits;
	}
}