package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFlagshipHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractFlagshipHomes() throws Exception {
		super("Flagship Homes", "https://www.forsail.com/");
		LOGGER = new CommunityLogger("Flagship Homes");
	}

	

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractFlagshipHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Flagship Homes.csv", a.data().printAll());
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String regHtml=U.getHTML("https://www.forsail.com/");
//		String[] comSecs=U.getValues(regHtml, "<div class=\"community-info\">", "details</a>");
		String commSec[]=U.getValues(regHtml, "<div class=\"community-info\">", "button\">details</a>");
		for(String comSec:commSec) {
		String comUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
		comUrl="https://www.forsail.com"+comUrl;
		String commName=U.getSectionValue(comSec, "community-title\">", "<");
		U.log(comUrl+" name: "+commName);
		
		
//		try {
			addDetails(comUrl,commName);
//		} catch (Exception e) {}
		
		}
//		addDetails(comUrl,commName);
		LOGGER.DisposeLogger();
	}



	private void addDetails(String comUrl, String commName) throws Exception {
		// TODO Auto-generated method stub
		
		// ----------------- Community Url-----------------------
				U.log("communityURL===================> "+comUrl);
				String comHtml = U.getHTML(comUrl);
				
				
				// ----------------- Community Name-----------------------
				U.log("comName============> "+commName);
				
				// ----------------- Community LOGGER-----------------------
				if (data.communityUrlExists(comUrl)) {
					LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				
				
				//======Single run=====
//				if(!comUrl.contains("https://www.forsail.com/communities/harmony")) return;
				
				
				//====================================Note ======================================
				String note=ALLOW_BLANK;
				note= U.getnote(comHtml);
				
				// ----------------- Community Address-----------------------
						String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
						String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
						String geo="False";
//						U.log(comHtml);
						comHtml=comHtml.replace(" Eagle Mountain", ", Eagle Mountain");
//						String address=U.getSectionValue(comHtml, "class=\"community-address\">", "</div>");
//						add=U.getAddress(U.getSectionValue(comHtml, "</h1></div><div class=\"community-address\">", "</div></div><div style"));
						
						String aa=U.getSectionValue(comHtml, "</h1></div><div class=\"community-address\">", "</div></div><div style");
//						
						U.log("aa>>>>>>>>>>>>>>"+aa);
						aa=aa.replace("Drive American","Drive,American").replace("WEST MAPLETON", "WEST, MAPLETON")
								.replace("1926 West 1800 South Mapleton, UT 84664", "1926 West 1800, South Mapleton, UT 84664");
						
						U.log("add section ===== "+aa);
						
						add=U.getAddress(aa);
						String latlngSec = U.getSectionValue(comHtml, "coordinates: [", "]");
						U.log("latlngSec :"+latlngSec);
						if(latlngSec != null){
							String coordinate[] = latlngSec.split(",");
							if(coordinate.length == 2){
								if(coordinate[0].trim().startsWith("-")){
									latLong[0] = coordinate[1].trim();
									latLong[1] = coordinate[0].trim();
								}
								else if(coordinate[1].trim().startsWith("-")){
									latLong[0] = coordinate[0].trim();
									latLong[1] = coordinate[1].trim();									
								}
							}
						}
						else{
							latLong=U.getGoogleLatLngWithKey(add);
							geo="true";
						}
						if(latLong[0]==ALLOW_BLANK||latLong[0]==null||latLong[0].isEmpty()||latLong[0]=="-") {
							latLong=U.getGoogleLatLngWithKey(add);
							geo="true";	
						}
						U.log("Address ::"+Arrays.toString(add));
						U.log(Arrays.toString(latLong));
						
						U.log("Note========>:::"+note);
						
						//------------------Quick Move-In Home Data-------------------
						String qdata=null;
						String quickHtml=U.getHTML("https://www.forsail.com/quick-move-ins");
						String quickData=U.getSectionValue(quickHtml, ">Move-In Ready</h1>", ">About Us</a>");
						String[] quickHomeData=U.getValues(quickData, "class=\"heading-5\">", ">For Sale</div>");
						U.log("quickHomeDa=="+quickHomeData.length);
						String quickhomeHtml="";
						for(String quick : quickHomeData)
						{
							if(quick.toLowerCase().contains(commName.toLowerCase())) {
						
							U.log("quick11::::::"+quick);
							String quickUrl=U.getSectionValue(quickData, "<a href=\"", "\"");
									quickUrl="https://www.forsail.com"+quickUrl;
									U.log("quickUrl::::::"+quickUrl);
									 quickhomeHtml=U.getHTML(quickUrl);
						}
						}
						//------------------Home For Sale Data-------------------
						String homedata=null;
						String homeHtml=U.getHTML("https://www.forsail.com/homes-for-sale");
//						String homeData1=U.getSectionValue(homeHtml, ">Move-In Ready</h1>", ">About Us</a>");
						String[] homeforsaleData=U.getValues(homeHtml, "<div role=\"listitem\"", "</div></div></div></div></div></a>");
						U.log("homeforsaleData=="+homeforsaleData.length);
						String homeforSaleHtml="";
						for(String home : homeforsaleData)
						{
//							U.log("homeforsaleData=="+home);

							if(home.contains(commName)) {
								U.log("quick::::::"+home+"   "+commName);
							String homeUrl=U.getSectionValue(home, "<a href=\"", "\"");
							homeUrl="https://www.forsail.com"+homeUrl;
									U.log("homeUrl-----::::::"+homeUrl);
									homeforSaleHtml+=U.getHTML(homeUrl);
							}
						}
						//------------------Available Home Data-----------------------
						String homeData="";
						String homeSec=U.getSectionValue(comHtml, "Subdivisions in this Community</h3>", ">Details</a></div></div></div></div></div></div></div>");
						
//						U.log(">>>>>>>>"+homeSec);
						if(homeSec!=null) {
						
						String[] homeUrls=U.getValues(homeSec, "<a href=\"", "\"");
						int c=0;
						for(String homeUrl:homeUrls) {
							c++;
							homeUrl="https://www.forsail.com"+homeUrl;
							U.log(c+"== "+homeUrl);
							homeData+=U.getHTML(homeUrl);
						}
						}
						//------------------Floor Plan Data-----------------------
						String floorPlanHtm =U.getHTML("https://www.forsail.com/floor-plans");
						String planData="";
						String[] planUrls=U.getValues(floorPlanHtm, "<a id=\"w-node-_", "</a>");
						for(String plan:planUrls) {
							if(plan.contains(commName)) {
								planData+= plan.replace("feet.png\" width=\"20\" alt=\"\"/></div><div class=\"columntext\">", "Sq. Ft. ");
							}
						}

						// ----------------- Community Sqft-----------------------
						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						homeforSaleHtml=homeforSaleHtml.replace("</div><div class=\"featuretext\">Sq Feet", " Sq Feet").replace("</div><div class=\"text inline\">", " ");
						String[] sqft = U.getSqareFeet((comHtml+homeData+planData+homeforSaleHtml).replaceAll("Sq. Ft. 1757</div>|Sq. Ft. 1506</div>", ""),	"\\d{4} Sq. Ft.|\\d{4}</div><div class=\"featuretext\">Sq Feet|\\d,\\d{3} Sq.Ft.|\\d,\\d{3} Sq. Ft|\\d,\\d{3} to \\d,\\d{3} square feet|Sq. Ft. \\d{4}", 0);
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						
//						minSqft="1487";
//						maxSqft="5490";
						
						if(comUrl.contains("https://www.forsail.com/communities/silver-lake")) {
						 sqft = U.getSqareFeet((comHtml+homeData+planData+homeforSaleHtml).replaceAll("Sq. Ft. 1757</div>|Sq. Ft. 1506</div>", ""),	"\\d{4} Sq. Ft.|\\d{4}</div><div class=\"featuretext\">Sq Feet|\\d,\\d{3} Sq.Ft.|\\d,\\d{3} Sq. Ft|\\d,\\d{3} to \\d,\\d{3} square feet|Sq. Ft. \\d{4}", 0);
							minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
							maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						}
						
						U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//						U.log(">>>>>>>>"+Util.matchAll(homeforSaleHtml, "[\\w\\s\\W]{100}5000 sq[\\w\\s\\W]{100}",0));

						// ----------------- Community Price-----------------------
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//						comHtml=comHtml.replace("", "");
						String price[] = U.getPrices(comHtml+homeData+quickhomeHtml+homeforSaleHtml, ">\\$\\d,\\d{3},\\d{3}</div|\">\\$\\d,\\d{3},\\d{3}</div>|>\\$\\d{3},\\d{3}<|\">\\$\\d{3},\\d{3}</h3>|Starting at \\$\\d{3},\\d{3}", 0);
						
						if(comUrl.contains("https://www.forsail.com/communities/silver-lake")) {
							 price = U.getPrices(comHtml+homeData+homeforSaleHtml, "\">\\$\\d,\\d{3},\\d{3}</div>|>\\$\\d{3},\\d{3}<|\">\\$\\d{3},\\d{3}</h3>|Starting at \\$\\d{3},\\d{3}", 0);
						}
						
						
						minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
						maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
						
						U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);


						// ----------------- Community Data-----------------------
						String propType = ALLOW_BLANK;
						String propStatus = ALLOW_BLANK;
						String drvPropType = ALLOW_BLANK;
						String commType = ALLOW_BLANK;
						
						//============================================ Property Type =========================================================================
						comHtml = comHtml.replace("Town Homes", "townhomes");
						
//						U.log(Util.matchAll(comHtml+homeData+quickhomeHtml, "[\\w\\s\\W]{30}Town Homes[\\w\\s\\W]{30}",0));
						
						propType=U.getPropType((comHtml+homeData+quickhomeHtml).replaceAll("Villages at Vintaro|_Plex_Townhomes_|Town Homes are available", ""));
			
						U.log("PType========>:::"+propType);
					
						//=========== Community Type ========================
						
						commType = U.getCommType((comHtml).replace("Silver Lake is one of Utah", "Silver lakeside living is one of Utah"));
						
						U.log("commType========>:::"+commType);
//						U.log(Util.matchAll(comHtml+homeData+quickhomeHtml, "[\\w\\s\\W]{30}lake[\\w\\s\\W]{30}",0));
						
						//============================================ dProp Type =========================================================================
						drvPropType=U.getdCommType(comHtml+homeData+quickhomeHtml);
			
						U.log("PdrvType========>:::"+drvPropType);
						
						if(comUrl.contains("https://www.forsail.com/communities/silver-lake")) {
							drvPropType=U.getdCommType(comHtml+homeData+quickhomeHtml+homeforSaleHtml);	
							U.log("PdrvType========>:::"+drvPropType);
						}
						//====================================Property Status ======================================
				
						String remForStat=U.getSectionValue(comHtml, "Subdivisions in this Community","<div class=\"map-container\">");
						comHtml=comHtml.replace(remForStat,"");
						comHtml=comHtml.replaceAll("\">Coming Summer 2021</h3>|/quick-move-ins|>Move-In Ready</a>|>Quick Move-Ins</a><", "");
						propStatus=U.getPropStatus((comHtml).replaceAll("New Homes Now Available|New inventory is now available", ""));

						U.log("PStatus========>:::"+propStatus);
						
//						U.log(Util.matchAll(comHtml+homeData+quickhomeHtml, "[\\w\\s\\W]{60}Quick Mov[\\w\\s\\W]{60}",0));
						U.log(Util.matchAll(quickhomeHtml, "[\\w\\s\\W]{60}Quick Mov[\\w\\s\\W]{60}",0));
						
						if(quickhomeHtml.contains("Quick Move-Ins")) {
							
							if(propStatus == ALLOW_BLANK)
								propStatus = "Quick Move-Ins";
							else if(propStatus != ALLOW_BLANK)
								propStatus = propStatus + ", Quick Move-Ins";	
						}
						
						

						// ----------------- Community Data-----------------------
						data.addCommunity(commName, comUrl, commType);
						data.addLatitudeLongitude(latLong[0], latLong[1], geo);
						data.addPrice(minPrice, maxPrice);
						data.addAddress(add[0], add[1], add[2], add[3]);
						data.addSquareFeet(minSqft, maxSqft);
						data.addPropertyType(propType, drvPropType);
						data.addPropertyStatus(propStatus);
						data.addNotes(note);
						data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
						data.addUnitCount(ALLOW_BLANK);
						
						
	}

}