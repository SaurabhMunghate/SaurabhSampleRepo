package com.shatam.b_325_353;

import java.util.Arrays;

import org.apache.commons.lang3.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGarmanHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractGarmanHomes() throws Exception {
		super("Garman Homes", "https://www.garmanhomes.com/");
		LOGGER = new CommunityLogger("Garman Homes");
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractGarmanHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Garman Homes.csv", a.data().printAll());
	}
	@Override
	protected void innerProcess() throws Exception {
		String regHtml=U.getHTML("https://www.garmanhomes.com/communities");
		String[] comSecs=U.getValues(regHtml, "<div class=\"CommunityCard_media\" data-reactid=\"", ">Visit Community</a>");
		for(String comSec:comSecs) {
//			U.log(comSec);
			String comurl=U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");
			comurl="https://www.garmanhomes.com"+comurl;
			String commName=U.getSectionValue(comSec, "<h4 data-reactid=", "/h4>");
			commName=U.getSectionValue(commName, ">", "<").replace("&amp;", "&");
			U.log(comurl+" name: "+commName);
			try {
				addDetails(comurl,commName,comSec);
			} catch (Exception e) {}
//			break;
		}
		LOGGER.DisposeLogger();

	}
	private void addDetails(String comUrl, String comName, String comSec) throws Exception {
		// TODO Execute for single community
		
//	if(!comUrl.contains("https://www.garmanhomes.com/communities/pittsboro/chatham-park")) return;
		
		// ----------------- Community Url-----------------------
		U.log("communityURL==> "+comUrl);
		String comHtml = U.getHTML(comUrl);
		U.log(U.getCache(comUrl));
		
		
		String rmsec = U.getSectionValue(comHtml, "window.__PRELOADED_STATE__", "</html>");
		comHtml = comHtml.replace(rmsec, "");
		// ----------------- Community Name-----------------------
		U.log("comName==> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);

		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				String addSec=U.getSectionValue(comHtml, "<h1 data-reactid=\"", "/span></div>");
				addSec=addSec.replace("Wake Forest, NC, 27587", "Wake Forest, NC 27587, USA")
						.replaceAll("<br data-reactid=\"\\d+\"/>", ", ")
						.replaceAll("<span data-reactid=\"\\d+\">", "<span data-reactid=")
						.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replace("=\"121\">", "=\"121\"> ,");
				
				
//				if(comUrl.contains("/communities/wake-forest/holding-village")) {
//					addSec = "<span data-reactid=109 Kimber Lane, Wake Forest, NC, 27587<";
//				}
				
				U.log("addSec: "+addSec);
				add=U.getAddress(U.getSectionValue(addSec, "<span data-reactid=", "<"));
				
				U.log("Address Here::"+Arrays.toString(add));
				
				String latLongSec=U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "/@");
				latLong=latLongSec.split(",");
				
				U.log("Latlong Here::"+Arrays.toString(latLong));
				
				if(add[0] == ALLOW_BLANK && latLong[0] != ALLOW_BLANK) {
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
				}
				

				U.log("Address ::"+Arrays.toString(add));
				U.log("Latlong ::"+Arrays.toString(latLong));
			

//				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
				String homeData="";
//				String homeSec="";
				String[] homeUrls= {};
				String hhtml=ALLOW_BLANK;
				int c=0;
				homeUrls=U.getValues(comHtml, "<div class=\"PlanCard_wrapper\"", "View Details</a></div>");
					for(String homeSecs:homeUrls) {
//						homeSec=homeSecs;
						String homeUrl=U.getSectionValue(homeSecs, "<a class=\"\" href=\"", "\"");
						c++;
						homeUrl="https://www.garmanhomes.com"+homeUrl;
						U.log(c+"== "+homeUrl);
						 hhtml = U.getHTML(homeUrl);
//						rmsec = U.getSectionValue(hhtml, "window.__PRELOADED_STATE__", "</html>");
//						U.log(hhtml.contains(rmsec));
//						hhtml = hhtml.replace(rmsec, "");
						homeData+=U.getSectionValue(hhtml, "<div class=\"HomeDetails_top\"", "</p></div></div><style data-emotion-css=\"");
					}
				comSec=comSec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
				if(homeData!=null)
				homeData = homeData.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
			//	U.log(homeData);
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml+homeData+comSec,	"\\d,\\d{3} - \\d,\\d{3}  SQ FT|>\\d,\\d{3}</span>|>\\d{3}</span><span", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				comHtml = comHtml.replace("From $400ks", "From $400,000")
						.replace("0k&#x27;s", "0,000").replace("$300k's", " $300,000").replace("$300ks", "$300,000");
//				comHtml=comHtml.replace("low as the mid $300’s.", "low as the mid $300,000").replace("Starting in the low $300’s", "Starting in the low $300,000");
				String price[] = U.getPrices(comHtml+homeData+comSec, "From \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</span></span>|>\\$\\d{3},\\d{3}</span></div>|Low \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Priced from: </strong>\\$\\d{3},\\d{3}", 0);  //|Starting From \\$\\d{3},\\d{3}
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);

//				U.log(Util.matchAll(homeData, "[\\w\\s\\W]{50}379900[\\w\\s\\W]{30}", 0));
//
//				U.log(Util.matchAll(homeData, "[\\w\\s\\W]{50}379,900[\\w\\s\\W]{30}", 0));
//				if(comUrl.contains("https://www.garmanhomes.com/communities/pittsboro/chatham-park"))minPrice="$324000";

				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//====== Sec============
				String descSec=U.getSectionValue(comHtml, "<div class=\"CommunityDetails_namePrice\"", "Photo Gallery</h3>");
				String desc2=U.getSectionValue(comHtml, "Find Your Home","Photo Gallery</a></li>");
				String HomeDescSec=""; 
				String homes[] =null;
				if(homeData.contains("HomeDetails_top") && homeData.contains("Photo Gallery</h3>")) {
				homes = U.getValues(homeData, "<div class=\"HomeDetails_top\"", "Photo Gallery</h3>");
					//U.getSectionValue(homeData, "<div class=\"HomeDetails_top\"", "Photo Gallery</h3>");
				for(String s: homes) {
	//					U.log(s);
						HomeDescSec+=s+":::::\n";
					}
				if(HomeDescSec!=null)HomeDescSec=HomeDescSec.replaceAll("Stories: </strong><!-- react-text: \\d+ -->", "story ");
				}
				//============================================ Property Type =========================================================================
				U.log("HomeDescSec::"+HomeDescSec);
				homeData = homeData.replaceAll("Stories: </strong>1</li>", "one-story")
						.replaceAll("Stories: </strong>2</li>", "two-story")
						.replace("that offers the luxury of larger living spaces", "that offers the luxury style of larger living spaces");
				
				propType=U.getPropType(homeData+descSec.replace("Farmhouse, we designed", "classic farmhouse style design, we designed")+HomeDescSec);
	
				U.log("PType========>:::"+propType);
				//U.log(Util.matchAll(homeData, "[\\w\\s\\W]{50}luxury[\\w\\s\\W]{50}", 0));
				//=========== Community Type ========================
				
				commType = U.getCommType(descSec);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType((descSec+HomeDescSec+homeData).replace("floor", "").replace("Stories:</b> 2", "2 story").replace("Stories:</b> 1.5", "one-and-one-half story"));
	
				U.log("drvPropType========>:::"+drvPropType);
//				U.log(Util.matchAll(homeData, "[\\w\\s\\W]{50}stories[\\w\\s\\W]{50}", 0));
				
				//====================================Property Status ======================================

				descSec=descSec.replaceAll("commHoursValue\" data-reactid=\"129\">COMING SOON - Email|NOW AVAILABLE:|ready to move in|Quick Move-In Homes", "");
				//descSec=descSec.replaceAll("NOW AVAILABLE:|ready to move in", "");
				descSec=descSec.replace("COMING IN 2022: The Roshambo Collection","");
				propStatus=U.getPropStatus(descSec.replace("Thales Academy now open", "").replace(" newest phase of Holding Village is now selling", "newest phase now selling").replace("coming this Summer/Fall from Garman Homes", "")+comSec).replace("Now Open at Chatham Park", "");
				U.log(Util.matchAll(descSec, "[\\w\\s\\W]{50}now open[\\w\\s\\W]{30}", 0));
				
				
//				if(comUrl.contains("https://www.garmanhomes.com/communities/wake-forest/live-oaks")) propStatus="Quick Move-In";
//				if(comUrl.contains("https://www.garmanhomes.com/communities/wendell/wendell-falls")
//						||comUrl.contains("https://www.garmanhomes.com/communities/pittsboro/chatham-park"))
//					propStatus="Quick Move-In";
				
				
				
//				U.log(Util.matchAll(descSec+comSec, "[\\w\\s\\W]{60}coming 20[\\w\\s\\W]{60}", 0));
				U.log("PStatus========>:::"+propStatus);
				add[0]=add[0].replace("469 Piney-Grove Rawls Rd", "469 Piney Grove Rawls Rd");
				add[1]=add[1].replace("Fuquay-Varina", "Fuquay Varina");
				if(comUrl.contains("/communities/greensboro/montrose-village-at-grandover"))propStatus=propStatus.replace(", Coming This Summer", "");// summer 2021  is gone
				// ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0], add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
				data.addUnitCount(ALLOW_BLANK);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
}

	

