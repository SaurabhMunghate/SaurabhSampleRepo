package com.shatam.b_325_353;
import java.util.Arrays;

/**
 * @author MJS
 * @date 30/03/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGraniteRidgeBuilders extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://graniteridgebuilders.com";

	public ExtractGraniteRidgeBuilders() throws Exception {
		super("Granite Ridge Builders", builderUrl);
		LOGGER = new CommunityLogger("Granite Ridge Builders");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractGraniteRidgeBuilders();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Granite Ridge Builders.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String html = U.getPageSource("https://graniteridgebuilders.com/find-your-home/communities");
		String[] mainSec = U.getValues(html, "var latLng", "</header>");
		U.log(mainSec.length);
		
		for(String data : mainSec)
		{
			String comUrl = U.getSectionValue(data, "<a href=\"", "\"");
			
//			try {
				getDetail(builderUrl+comUrl, data);
//			} catch (Exception e) {}
			
		}
		
		LOGGER.DisposeLogger();
		
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
//		try {
		
//		if(!comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/brownstone-manor")) return;
				
		U.log("Count: " + j + "\n\t" + comUrl);
		{
			
//			U.log(com);
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			
			
			// ---------- 14 communities. === PAGE NOT FOUND ERROR. SEPT - 2022 : CHECK NEXT TIME.
			if (comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/aslan-passage") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/eagle-crest") ||
			
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/heritage-lake") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/mayerling-estates") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/stratford-forest") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/milagro") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/the-fountain-at-covington") ||
			
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/the-summit") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/tuscany-warsaw") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/villa-nova-estates") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/whisper-rock") ||
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/wooded-hills") ||
			
			comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/falcon-creek")) {
				
				LOGGER.AddCommunityUrl(comUrl + " =================== PAGE NOT FOUND ERROR. SEPT - 2022");
				return;
			}
			
			
			
			LOGGER.AddCommunityUrl(comUrl);
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			String html = U.getPageSource(comUrl);
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(com, "<span class=\"name\">", "<");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<span class=\"location\">", "<");
			
			if (addSec != null) {
				
				U.log("Adress:--" + addSec);
				
				addSec = Util.match(addSec, "!2s.*!\\d");
				U.log(addSec);
				if (addSec != null){
					
					addSec = addSec.replace("%20", " ").replace("+", " ").replace("%2C", ",");
					add = U.getAddress(U.getNoHtml(addSec));
				}

			}
			
			
			
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
		
				String latSec = U.getSectionValue(html, "LatLng(", ");");
				if (latSec != null) {
					latLng = latSec.split(",");
				}
			
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);
			
			
			if(addSec==null) {
				String[] addr=null;
				addSec = U.getSectionValue(html, "<div class=\"subtitle\">", "<").trim();
				String zip=Util.match(addSec, "\\d{5}");
				addSec=addSec.replace(zip, ", "+zip);
//				addr = U.getAddress(addSec);
				U.log("addSec==="+addSec);
				addr=addSec.split(",");
//				U.log("zip==="+addr.length);
				if(addr.length==3) {
					add[1]=addr[0];
					add[2]=addr[1];
					add[3]=addr[2];
					add[0]=U.getAddressGoogleApi(latLng)[0];
					U.log("Address-2---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
					geo = "TRUE";
				}
			}
			

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			
			//========== Move In Homes ==================================================
			String moveHtml = U.getPageSource("https://graniteridgebuilders.com/find-your-home/available-homes")+U.getPageSource("https://graniteridgebuilders.com/find-your-home/available-homes/p4")
			+U.getPageSource("https://graniteridgebuilders.com/find-your-home/available-homes/p3")+U.getPageSource("https://graniteridgebuilders.com/find-your-home/available-homes/p2");
			
			String[] movSec = U.getValues(moveHtml, "var latLng", "</header>");
			U.log(movSec.length);
			String moveData = ALLOW_BLANK;
			for(String data : movSec) {
				//U.log(data);
				data=data.replaceAll("107 The Villas of Forest at Foxwood|114 Villas of Forest at Foxwood|138 Villas of Forest at Foxwood", "The Villas of Forest at Foxwood");
				if(data.toLowerCase().contains(communityName.toLowerCase()) && !comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/forest-at-foxwood") ) {
					String url = U.getSectionValue(data, "<a href=\"", "\"");
					U.log("Move Url: "+url);
					String mhtml = U.getSectionValue(U.getPageSource(builderUrl+url), "<section class=\"details-agent\">", "</section>");
					moveData += data+mhtml;
				}
			}
			
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("0s", "0,000").replaceAll("Homes over \\d+ SF: \\d+ gallon electric hybrid water heater|Homes under \\d+ SF: \\d+ gallon gas water heater|Homes over \\d+ SF: \\d+-gallon electric hybrid water heater|Homes under \\d+ SF: \\d+-gallon gas water heater", "");
			String prices[] = U.getPrices((com + html + moveData).replace("<span class=\"price\">374,900</span>", ""), "<span class=\"price\">\\d,\\d{3},\\d{3}</span>|<span class=\"price\">\\d{3},\\d{3}</span>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
//			U.log("mmmmmm"+Util.matchAll( moveData  , "[\\w\\s\\W]{30}374,900[\\w\\s\\W]{30}", 0));
			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html + moveData	,
					"nearly \\d,\\d{3} square-feet|<div class=\"value\">\\s*\\d{4}\\s*</div>",
					0);
//			U.log("mmmmmm"+Util.matchAll(com + html + moveData  , "[\\w\\s\\W]{30}374,900[\\w\\s\\W]{30}", 0));
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
			
			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com)
					.replace("waterfront &amp; cul-de-sac lots", "waterfront lots & cul-de-sac lots")
					.replace("These waterfront lots are located on a crystal clear bay", "")
					.replace("Crystal Bay is a beautiful lake home community", "Crystal Bay is a beautiful lakeside community")
					.replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf|Heritage Lake community", ""));

			U.log(">>>>communityType  =   "+communityType);
//			U.log("mmmmmm"+Util.matchAll(html  , "[\\w\\s\\W]{30}waterfront[\\w\\s\\W]{30}", 0));			

			// ==========================================================Property
			// Type================================================

			html=html.replace("Villa</div>", "The Villas</div>").replace("Shadow Lake Estates is a beautiful community", "Shadow Lake estate communityis a beautiful community").replace("Estates", "Estate style")
					.replaceAll("Build a custom home with Granite Ridge Builders|build a new custom home by Granite Ridge Builders|This community is the perfect place to build a custom home with Granite RIdge Builders|this community if the perfect place to build a new custom home with Granite Ridge Builders|Build a custom home with Granite Ridge Builders in this beautiful community|Build a new custom home with Granite Ridge Builders|Indiana with a few lots for sale to build a new custom home|perfect for building a brand new custom home with Granite Ridge Builders|build a custom home with Granite Ridge Builders|Build a brand new, custom home with Granite Ridge Builders|is the perfect place to build a new custom home with Granite Ridge Builders", "");
			
			String proptype = U.getPropType((html + com + moveData).replaceAll("The craftsman style exterior sets this home|new custom-built home|The custom-built homes", "exceptional custom home")
					.replace("luxury million-dollar model home", "luxury living million-dollar model home")
					.replaceAll("\"single-family|home sites to build a brand new custom home|custom kitchen|custom organizer shelving|custom painted cabinetry |custom stained cabinets|custom cabinets|custom cabinet|custom cabinetry|is the perfect place to call home and build a custom home with Granite Ridge Builders|figure.aspect.traditional|customer-care|Customer Care", ""));

//			U.log("mmmmmm"+Util.matchAll(moveData  , "[\\w\\s\\W]{30}craftsman style[\\w\\s\\W]{30}", 0));			
			U.log(">>>>proptype  =   "+proptype);
						
			// ==================================================D-Property
			// Type======================================================
			if(moveData!=null)
				moveData = moveData.replaceAll("Stories\n\\s*</div>\n\\s*<div class=\"value\">\n\\s*", "Story ");
			
			String dtype = U.getdCommType((html + com + moveData)
//					.replaceAll("Stories</div>\\s*<div class=\"value\">", "Stories ")
					.replaceAll("Story 1.5", " 1.5 Story")
					.replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName);

			U.log(">>>>dtype  =   "+dtype);
//			U.log("mmmmmm"+Util.matchAll(moveData  , "[\\w\\s\\W]{30}Story[\\w\\s\\W]{150}", 0));
			// ==============================================Property
			// Status=========================================================
	
			
			
			
			html = html.replaceAll("content=\".*>|large lots available with|Grey Hawk is eligible for USDA home loans and special|lots available to build|\"Coming|[M|m]ove-[I|i]n|qualifies for USDA home loan|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("pond and wooded lots as well as quiet cul-de-sac lots", "pond & wooded lots & cul-de-sac lots available")
					.replace("wooded lots as well as quiet cul-de-sac lots", "wooded & cul-de-sac lots available")
					.replace("large lots with pond lots available", "large lots available")
//					.replace("pond view lots and cul-de-sac lots", "Pond view and cul de sac lots available")
					.replace("pond and wooded lots as well as quiet cul-de-sac lots.", "pond and wooded and cul de sac lots available")
					.replace("waterfront lots and wooded lots", "waterfront lots and wooded lots available").replace("wooded lots as well", "wooded lots available as well")
					.replace("only 30 home sites still available", "only 30 home sites available").replace("Plenty of lots are still available", "Plenty of lots available").replace("Water lots and daylight lots are available", "Water lots and daylight lots available").replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available").replaceAll("There are a variety of lots available, including pond and cul-de-sac lots| cul-de-sac lots are still available", " cul-de-sac lots available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			
			String pstatus = U.getPropStatus((html + com)
					.replace("Allen County School District.  cul-de-sac lots available. This", "Allen County School District.pond and cul-de-sac lots available. This")
					.replace("This community offers pond view lots and cul-de-sac lots", "This community offers pond and cul-de-sac lots available")
					.replace("community offers beautiful pond & wooded lots & cul-de-sac lots available", "community offers beautiful pond & wooded lots available")
					.replace("variety of lots available including pond and cul-de-sac lots", "variety of cul-de-sac lots available")
					.replace("This community offers pond view lots and cul-de-sac lots", "This community offers pond view lots and cul-de-sac lots available")
					.replace("Fifteen affordable building lots are available", "15 lots available")
					.replace("There are only 30 home sites available so don’t miss your chance", "There are only 30 homesites available so don’t miss your chance")
					.replace("eligible for USDA Financing", "USDA Financing eligible").replace("lots are available", "lots available").replace("30 home sites still available", "Only 30 Homesite Available")
					.replace("beautiful pond and wooded and cul de sac lots available", "beautiful pond and wooded lots available")
					.replace("community offers Pond view and cul de sac lots available", "community offers Pond and cul de sac lots available"));
			
			
			
			U.log(">>>>pstatus  =   "+pstatus);
//			U.log("mmmmmm"+Util.matchAll(html + com, "[\\w\\s\\W]{50}cul-de-sac lots[\\w\\s\\W]{80}", 0));
			
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "");
			
			//coming from video on community page that's why taken hardcoted
			if(comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/carroll-creek-villas")) pstatus="Coming Soon";
			if(comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/cardinal-creek")) pstatus = "Coming Soon";
			if(moveData!=null && moveData.length()>7)
//				if(comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/forest-at-foxwood"))
//				{
//					pstatus=pstatus.replace("Move-In Ready Homes", "     ");
//				}
				if(pstatus==ALLOW_BLANK)
					pstatus = "Move-In Ready Homes";
				else if(!pstatus.contains("Move-In Ready Homes"))
					pstatus += ", Move-In Ready Homes";
			
//			if(comUrl.equals("https://graniteridgebuilders.com/find-your-home/communities/lakes-of-leo-creek"))pstatus = ALLOW_BLANK;
			
			//Status from video - 26 April 2022
//			if(comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/cambridge-crossing")) pstatus = pstatus + ", Coming Soon";
//			if(comUrl.contains("https://graniteridgebuilders.com/find-your-home/communities/carroll-creek-villas")) pstatus = pstatus + ", Coming Soon";
			
			
			//formatting commnity name
			communityName = communityName.replaceAll("&#039;|&#8217;", "'").replaceAll(" Villas$", "");
			if(comUrl.contains("/communities/the-grove-at-cobble-creek"))proptype=proptype+", Estate-Style Homes";
			
			//=========================================================================================================================
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);

		}
		j++;
//		}catch(Exception e){}

	}

}