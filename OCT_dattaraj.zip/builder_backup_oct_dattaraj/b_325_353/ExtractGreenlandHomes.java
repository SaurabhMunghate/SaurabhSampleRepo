package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGreenlandHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;

	public ExtractGreenlandHomes() throws Exception {

		super("Greenland Homes", "https://greenlandhomesiowa.com/");
		LOGGER = new CommunityLogger("Greenland Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractGreenlandHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Greenland Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		
        String mainHtml=U.getHTML("https://greenlandhomesiowa.com/#");
		
		String comSections[]=U.getValues(mainHtml, "menu-item menu-item-type-post_type menu-item-object-community menu-item", "/a></li>");
		U.log("comSections=="+comSections.length);
		for(String comSec:comSections) {
			//U.log(comSec);
			addDetails(comSec);
		}
		
		LOGGER.DisposeLogger();
	}
	
	
	public void addDetails(String comSec) throws Exception {
		
		String comUrl=U.getSectionValue(comSec, "<a href=\"", "\"");
		U.log("=============================="+j);
		U.log("comUrl=="+comUrl);
		
//		if(!comUrl.contains("https://greenlandhomesiowa.com/aspen-ridge-estates/")) return;
		
		
		LOGGER.AddCommunityUrl(comUrl);
		String comName=U.getSectionValue(comSec, "/\">", "<");
		U.log("comName===="+comName);
		comName = comName.replaceAll(" Villas$", "");
		
		if(comName.endsWith("Townhomes") || comName.contains("Townhomes (2-Story)")) {
			comName = comName.replaceAll(" Townhomes$", "").replace("Townhomes (2-Story)", "");
		}
		
		String comHtml=U.getHTML(comUrl);
		U.log(U.getCache(comUrl));
		//U.log(Util.matchAll(comHtml, ".*sq.*", 0));

		//==========================address Section==========================================
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String note  = ALLOW_BLANK;
		String geo = "FALSE";
		
		try {
		add[1]=U.getSectionValue(comHtml, "\"addressLocality\"", "</span>").replace(">", "");
		add[2]=U.getSectionValue(comHtml, "\"addressRegion\"", "</span>").replace(">", "");
		}
		catch(Exception ne) {
			add[1]=U.getSectionValue(comHtml, "\"page-title\"", "</h2>");
			
		}
//		U.log(">>>>>>>>>>>>|"+add[1]+"|>>>>>>"+add[2]+">>>>"+(add[1].equals(">Madrid")));
		if(add[1].equals(">Madrid")&&add[2].length()<2) {
			add[2]="NM";
		}
		if(comUrl.contains("https://greenlandhomesiowa.com/landing-at-oxley-creek/")||
				comUrl.contains("https://greenlandhomesiowa.com/oxley-creek-west/")) {
			add[1]="Granger";
			add[2]="IA";
		}
		if(comUrl.contains("https://greenlandhomesiowa.com/autumn-park-west-grimes/")) {
			
			add[0]="Autumn Park";
			add[1]="Grimes";
			add[3]="IA";
		}
		if(comUrl.contains("https://greenlandhomesiowa.com/westview-heights-huxley/")) {
			add[1]="Huxley";
			add[2]="IA";
		}
		if(comUrl.contains("https://greenlandhomesiowa.com/chateau-88/")) {
			add[0]="450 S Jordan Creek Pkwy";
			add[1]="West Des Moines";
			add[2]="IA";
		}
		if(comUrl.contains("https://greenlandhomesiowa.com/timberview-west/")) {
			add[1]="Adel";
			add[2]="IA";
		}

		
		U.log("BEFORE: "+Arrays.toString(add));
		
		//for note------------------------------------------
		if((add[0] == ALLOW_BLANK && add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK && add[0] == ALLOW_BLANK) ||
				(add[0] == ALLOW_BLANK && add[1] != ALLOW_BLANK && add[2] == ALLOW_BLANK && add[0] == ALLOW_BLANK)) {
			note = "Address taken from city state";
			U.log("NOTE TAKEN");
		}
		
		latlag=U.getlatlongGoogleApi(add);
		add=U.getAddressGoogleApi(latlag);
		geo="TRUE";
		
		
		if(comUrl.contains("https://greenlandhomesiowa.com/aspen-ridge-estates/")) {
			add[1]=ALLOW_BLANK; add[2]=ALLOW_BLANK;
			
			if(comHtml.contains("src=\"https://www.google.com/maps/embed")) {
				
				String section = U.getSectionValue(comHtml, "src=\"https://www.google.com/maps/embed", "\" width");
				U.log(section);
				
				latlag[0] = Util.match(section, "\\!3d\\d{2}.\\d{5}").replace("!3d", "");
				latlag[1] = Util.match(section, "\\!2d-\\d{2}.\\d{5}").replace("!2d", "");
				
				U.log("LATLONG: "+Arrays.toString(latlag));
				
				add=U.getAddressGoogleApi(latlag);
				geo="TRUE";
				note = "Address taken from latitude longitude";
			}
		}
		
		U.log(Arrays.toString(latlag));
		U.log(Arrays.toString(add));
		U.log(geo);
		String dType = ALLOW_BLANK;
		String floorSec[]=U.getValues(comHtml, "<div class=\"photo-card\"", "</a>");
		String floorHtml="";
	
		U.log("floorSec---=-="+floorSec.length);
		for(String fs:floorSec) {
//			U.log(fs);
			String floorUrl=U.getSectionValue(fs, "href=\"", "\"").replace(",000", "s");
			String floorsData=U.getHTML(floorUrl);
			
			if(floorsData.contains("<li id=\"menu-item-709\"") && floorsData.contains("Why Greenland")) {
				
				String remove = U.getSectionValue(floorsData, "<li id=\"menu-item-709\"", "Why Greenland");
				floorsData=floorsData.replace(remove, "");
			}
			
			floorHtml += floorsData;
			
			//storySec+=U.getSectionValue(floorHtml,"", "");
		}
		floorSec=U.getValues(comHtml, "<div class=\"col-4 col-sm-12\">", "</p>");
		U.log("---=-="+floorSec.length);
		for(String fs:floorSec) {
			U.log("fs==="+fs);
			String floorUrl=U.getSectionValue(fs, "href=\"", "\"").replace(",000", "s");
			
			String floorsData=U.getHTML(floorUrl);
			
			if(floorsData.contains("<li id=\"menu-item-709\"") && floorsData.contains("Why Greenland")) {
				
				String remove = U.getSectionValue(floorsData, "<li id=\"menu-item-709\"", "Why Greenland");
				floorsData=floorsData.replace(remove, "");
			}
			floorHtml+=floorsData;
			//storySec+=U.getSectionValue(floorHtml,"", "");
		}
		
		floorSec=U.getValues(comHtml, "<div class=\"col-3 col-sm-12\">", "</p>");
		U.log("---=-="+floorSec.length);
		for(String fs:floorSec) {
//			U.log("fs==="+fs);
			String floorUrl=U.getSectionValue(fs, "href=\"", "\"");
			U.log("floorUrl==="+floorUrl);
			if(floorUrl!=null) {
				floorUrl=floorUrl.replace(",000", "s");
			}
			else continue;
			
			
			String floorsData=U.getHTML(floorUrl);
			
			if(floorsData.contains("<li id=\"menu-item-709\"") && floorsData.contains("Why Greenland")) {
				
				String remove = U.getSectionValue(floorsData, "<li id=\"menu-item-709\"", "Why Greenland");
				floorsData=floorsData.replace(remove, "");
			}
			floorHtml+=floorsData;
			//storySec+=U.getSectionValue(floorHtml,"", "");
		}
		
		//============================sqft-========================================
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		sqft=U.getSqareFeet(comHtml+floorHtml, "\\d{4} sq ft|\\d{1},\\d{3} sqft|<li>Total \\d{4} sq ft</li>", 0);
//		U.log(">>>>>>>>"+Util.matchAll(floorHtml, "[\\w\\s\\W]{100}1439[\\w\\s\\W]{100}",0));

		U.log("sqft=="+Arrays.toString(sqft));
		
		//=====================prices==========================================
//		U.log(U.getCache(comUrl));
		comHtml=comHtml.replace("at $179", "$179,000");
		//comHtml=comHtml.replace("$250�s", "$250,000");
		 String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		// low $280’,000
		comHtml=comHtml.replaceAll("&#8217;s|’s", "s");
		U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}300[\\w\\s\\W]{30}", 0));
			prices=U.getPrices(comHtml.replace("s", ",000"), "\\$\\d{3},\\d{3}", 0);
			
			

			U.log(Arrays.toString(prices));

			
			
			
			String cType=U.getCommType(comHtml);
			U.log(cType);
			

			
			// ============================dproptype=================================
			
				dType = U.getdCommType((comHtml+floorHtml)
						//.replace("(2-Story)", "")
						.replaceAll("<li>2-Story|2nd level", " 2 Story ").replaceAll("2nd floor laundry f", ""));
			
			U.log("dType::::::" + dType);
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}<h2>Properties</h2>[\\w\\s\\W]{100}",0));
			
			//========================property type=======================================================
			String pType=ALLOW_BLANK;
			
			if(comHtml.contains("<li id=\"menu-item-709\"") && comHtml.contains("Why Greenland")) {
				
				String remove = U.getSectionValue(comHtml, "<li id=\"menu-item-709\"", "Why Greenland");
				comHtml=comHtml.replace(remove, "");
			}
			
			comHtml=comHtml.replaceAll("RIdge-Townhomes|RIdge Townhomes plat|Ridge Townhomes|-townhomes|townhome-series|Townhome Series", "")
					.replaceAll("Deer Creek Townhomes|>Arbor Ridge Villa|/arbor-ridge-villa|/deer-creek-townhome|/\">Deer Creek Townhome,000</a>", "");
			floorHtml=floorHtml.replaceAll("/deer-creek-townhome|/\">Deer Creek Townhome,000</a>|>Deer Creek Townhomes<", "");
			pType = U.getPropType((comHtml+floorHtml).replaceAll("aspen-ridge-townhomes/\">Aspen Ridge Townhomes", ""));
		
			U.log("pType::::::" + pType);
//			U.log(">>>>>>>>"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}Townhomes[\\w\\s\\W]{100}",0));
//			U.log(">>>>>>>>"+Util.matchAll(floorHtml, "[\\w\\s\\W]{100}Townhomes[\\w\\s\\W]{100}",0));
//			if(comUrl.contains("https://greenlandhomesiowa.com/aspen-ridge-estates/"))pType=pType+", Estate-Style Homes";
			
			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;

			pStatus = U.getPropStatus((comHtml));
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			
			
			
			
//			if(comUrl.contains("https://greenlandhomesiowa.com/deer-creek/")||comUrl.contains("https://greenlandhomesiowa.com/orchard-view/"))prices[0]="$250,000";
//			if(comUrl.contains("https://greenlandhomesiowa.com/chateau-88/"))prices[0]="$240,000";
//			if(comUrl.contains("https://greenlandhomesiowa.com/aspen-ridge-townhomes"))sqft[0]="1450";
//			//if(comUrl.contains("spring-creek-sports-complex")||comUrl.contains("/deer-creek")||comUrl.contains("trestle-ridge-ankeny/"))dType="2 Story";
//			if(comUrl.contains("trestle-ridge-ankeny/")) {
//				
//				sqft[0] = "1166"; sqft[1]="1866";
//			}
			
			//sqft from images - 28 May dattaraj
			if(comUrl.contains("https://greenlandhomesiowa.com/village-townhomes/")) sqft[0] = "1844"; 
			if(comUrl.contains("https://greenlandhomesiowa.com/aspen-ridge-townhomes/")) sqft[0] = "1450";
			
			//pType from image - 28 June
			if(comUrl.contains("https://greenlandhomesiowa.com/village-townhomes/")) pType = pType + ", Homeowner Association";
			
			
			data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replaceAll(" / Somerset Apartments", "").replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	
		j++;
		
	}
	
}