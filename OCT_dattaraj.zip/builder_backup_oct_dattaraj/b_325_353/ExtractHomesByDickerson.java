package com.shatam.b_325_353;
/**
 * @author MJS
 * @date 01/04/2021 
 * 
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHomesByDickerson extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.homesbydickerson.com";

	public ExtractHomesByDickerson() throws Exception {
		super("Homes By Dickerson", builderUrl);
		LOGGER = new CommunityLogger("Homes By Dickerson");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractHomesByDickerson();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Homes By Dickerson.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.homesbydickerson.com");
//		U.log(">>>>>>>>"+html);
		String sec = U.getSectionValue(html, "<div class=\"nav-item\"><a href=\"/find-your-home\"", "</ul>");
//		U.log("<>>>>>"+sec);
		String[] mainSec = U.getValues(sec, "<a href=\"", "\"");
		
		for(String main : mainSec) {
			String regSlug = main;
			String regionUrl = builderUrl+main;
			U.log("regionUrl: "+regionUrl);
			String regHtml = U.getHtml(regionUrl, driver);
			String[] comSec = U.getValues(regHtml, "<div class=\"community", "</a></div>");
			U.log(comSec.length);
			for(String com : comSec) {
				U.log(regSlug);
				String comUrl = U.getSectionValue(com, "<a href=\"", "\"");
//				if(comUrl!=null)
				try {
					getDetail(builderUrl+comUrl, com, regSlug, regHtml);
				} catch (Exception e) {}
			}
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void getDetail(String comUrl, String com, String regSlug, String regHtml) throws Exception {
		// TODO Auto-generated method stub
//		if(j>4) 
//		{
//		if(!comUrl.contains("https://www.homesbydickerson.com/communities/nexton")) return;
		
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			if(comUrl.contains("https://www.homesbydickerson.com/find-your-home"))return;
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = getHtml(comUrl, driver);
			
			String remove = U.getSectionValue(html, "<script>window.__NUXT__", "</html>");
			
			if(remove!=null)
				html = html.replace(remove, "");
			// ============================================Community
			// name=======================================================================
//			U.log(">>>>>>>> "+com);
			String communityName = U.getSectionValue(com, "<div class=\"community__title\">","<");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'");
			U.log("community Name---->" + communityName);
//			U.log(Util.match(html, "\""+communityName+"\",\"ACTIVE\"",0));
			
			
			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps", "</a>");
			if(addSec!=null) {
				
				String addVal = U.getSectionValue(addSec, "<div class=\"address__street\">", "</span></div>");
				if(addVal!=null)
					addVal = addVal.replaceAll("</div>\\s*<div>\\s*<span>|</span>\\s*,\\s*<span>", ",").replaceAll("NC,", "NC ")
					.replace("SC,", "SC ");
				U.log(addVal);
				add = U.getAddress(addVal);
			}
			add[0]=add[0].replace("TOMATO FARM CIRCLE", "Tomato Farm Circle");
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			
			
			//-----LAT LONG
			
			if(comUrl.contains("/communities/hollycrest") ||
					comUrl.contains("/communities/pinehurst-national-no-9")) {
				
				String section = U.getSectionValue(regHtml, "}}})}}}", "</script>");
				//U.log("section: "+section);
				//FileUtil.writeAllText("/home/shatam-10/Desktop/data/sections.txt", section);
				String[] splitUrl = comUrl.split("/");
				for(String url:splitUrl) {
//					U.log("url: "+url);
				}
				String search = splitUrl[4];
				U.log("search: "+ splitUrl[4]); 
//				U.log(">>>>>>>>>>>>> "+Util.match(section , "[\\w\\s\\W]{30}"+search+"[\\w\\s\\W]{100}"));
				
				String geoData = Util.match(section , "[\\w\\s\\W]{30}"+search+"[\\w\\s\\W]{100}");
				U.log("geoData: "+ geoData);
				
				latLng[0] = Util.match(geoData, "\\d{2}\\.\\d{5}");
				latLng[1] = Util.match(geoData, "-\\d{2}.\\d{5}");
				
				U.log("LATLONG: "+Arrays.toString(latLng));
			}

			
			// --------------------------------------------------latlng----------------------------------------------------------------
		
		
		   U.log(U.getSectionValue(remove, "\",\"ACTIVE\",", "\""+regSlug.replace("/find-your-home/", "")+"\""));
		    String latSec = U.getSectionValue(remove,"\",\"ACTIVE\"", "\""+regSlug.replace("/find-your-home/", "")+"\"");
		    U.log("latSec: ==== "+latSec);
		    if(latSec==null) {
		    	//getting latlong my matching comName-------------------------------------
		    	
		    	  if(communityName.contains("At "))  communityName = communityName.replace("At", "at");
		    	
		    	String communityNameHere = "\",\""+communityName+"\",\"";
		    	U.log(">>>>>>>>>>>>>MATCH:  "+Util.match(remove, "[\\w\\s\\W]{30}"+communityName+"[\\w\\s\\W]{500}"));
		    	
		    	latSec = Util.match(remove, "[\\w\\s\\W]{30}"+communityName+"[\\w\\s\\W]{500}");
		    	
		    	if(comUrl.contains("https://www.homesbydickerson.com/communities/mangum")) {
		    		latSec = Util.match(remove, "[\\w\\s\\W]{30}\"Mangum\",\"mangum\"[\\w\\s\\W]{500}");
		    	}
		    }
		    
		    if(latSec!=null) {
		    	U.log("Address----> HERE " + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
		    	U.log("latSec: ======== >> "+latSec);
		    	
		    	String temp = latSec;
		    	
		    	latSec = U.getSectionValue(latSec, "\""+add[3]+"\",", ",\"");
		    	if(latSec==null && temp != null) latSec = Util.match(temp, "\\d+.\\d+,\\-\\d+.\\d+");  
		    	
			    U.log(">>>>>>>>>>latSec : "+latSec);
		    	if(latSec!=null)
			    latLng= latSec.split(",");
		    }
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);
			
			
			
//not getting proper section latlng present in source and map given on reg so geo = false 
			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}

			
			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("LAT LONG HERE: " + latLng[0] + "  " + latLng[1]);

			//====== Quick Homes ================================
			String[] floorSec = U.getValues(html, "<div class=\"plan__title\">", "</a></div>");
			String floorData = ALLOW_BLANK;
			for(String floor : floorSec) {
				
				floor = U.getSectionValue(floor, "<a href=\"", "\"");
//				U.log(">>>>>>"+floor); 
				floorData += U.getSectionValue(U.getHtml(builderUrl+floor, driver), "description\"><p>", "</p>")
						+U.getSectionValue(U.getHtml(builderUrl+floor, driver), "<div class=\"page-container\">", "</section>")+U.getSectionValue(U.getHtml(builderUrl+floor, driver), "<section class=\"features", "</section>");
				if(floorData.contains("ranch")) {
					U.log("Found");
				}
			}
			
			String floorMainUrl=U.getHtml(comUrl+"#floor-plans",driver);
			
			String fUrls[]=U.getValues(floorMainUrl, "\"/communities", "\"");		
			String fhtml="";
			String storySec="";
			for(String fu:fUrls) {
				
				fhtml=U.getHtml("https://www.homesbydickerson.com/communities"+fu, driver);	
				storySec+=U.getSectionValue(fhtml, "\"ewr-button-group\"", "</div>");
			}
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000")
					.replace("Starting in the $1.2 Millions", "Starting in the $1,200,000 Millions")
					.replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
					.replace("Starting in the $1.6 millions", "Starting in the $1,600,000 millions")
					.replace("$1.2 millions", "$1,200,000")
					.replace("</strong>   &#36;", " $").replace("Starting in the $1Ms", "Starting in the $1,000,000")
					.replace("Starting in the $1.6 Millions", "Starting in the $1,600,000")
					.replace("Starting in the $1.3Ms", "Starting in the $1,300,000");
			
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("0s", "0,000");
			String prices[] = U.getPrices(com + html + floorData , "From the \\$\\d{3},\\d{3}|Starting in the \\$\\d,\\d{3},\\d{3}|qmi__price\">\\$\\d,\\d{3},\\d{3}|From the High \\$\\d{3},\\d{3}|From the Upper \\$\\d+,\\d+|From the Mid \\$\\d+,\\d+|Starting in the \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d,\\d{3},\\d{3}|Starting in the \\$\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}/span>|<div class=\"qmi__price\">\\$\\d{3},\\d{3}</div>|Starting at \\$\\d{3},\\d{3}|price\"><span>\\$\\d,\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log("mmmmmm"+Util.matchAll(html , "[\\w\\s\\W]{70}From the \\$[\\w\\s\\W]{70}", 0));
			
			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html + floorData,
					"\\d,\\d{3}-\\d,\\d{3} Sq Ft|<div class=\"inventory__sqft\">\n\\s*\\d,\\d{3}|<span>\\d,\\d{3}</span>",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replaceAll("Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================
			html=html.replace("quality and craftsmanship you expect", "")
					.replace(">Custom Plan<", ">Custom Floor Plans<")
					.replace("highest quality of custom built homes", "highest quality of a custom-quality design homes")
					//.replace("outstanding craftsmanship await", "outstanding Craftsman style details await")
					.replace("two-story homes combine customizable design", "two-story homes combine a custom-quality design");
			String proptype = U.getPropType((html + com + floorData)
					.replace("ready to be customized", "ready to be custom-quality homes")
					.replace("estate-style plans", "Estate Residences")
					.replace("design with traditional details", "design with Poplar Traditional details").replace("luxury of a single family", "luxuries of a single family").replace("custom designs", "custom-built home")
					.replaceAll("craftsmanship await|Village|The Farmhouse Café|Cottage Way|Cottage\\+Wa", ""));

			// ==================================================D-Property
			// Type======================================================
			
			
			
			String dtype = U.getdCommType((html + com + floorData+storySec).replace("3rd Floor", "3 Story").replace("1st Floor", "1 Story").replace("2nd Floor", "2 Story").replaceAll("with all the quality and craftsmanship you expect|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
					+ communityName);
//			U.log("mmmmmm"+Util.matchAll(storySec , "[\\w\\s\\W]{70}Ranch[\\w\\s\\W]{70}", 0));
//			U.log("mmmmmm"+Util.matchAll(floorData, "[\\w\\s\\W]{70}ranch plan[\\w\\s\\W]{70}", 0));

			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("Townhomes Coming Soon|Coming Soon:|TOWNHOMES COMING SOON|Coming soon to 751 South will be|price--coming-soon|community__coming-soon|Quick Delivery|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available")
					.replace("Coming soon to 751 South will be a large central Amenity", "")
					.replaceAll("coming-soon-unit__price\">Coming Soon", "");
			
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("Coming Soon:|TOWNHOMES COMING SOON|Coming soon to 751 South will be|price--coming-soon|Townhomes Coming Soon|community__coming-soon|Quick Delivery|Coming soon, neuhouse", "");
			String pstatus = U.getPropStatus((html + com)
					.replace("Homesites & custom homes available!", "Homesites available")
					.replaceAll("<h2>Quick delivery homes</h2>", ""));
			
			U.log("pstatus: "+pstatus);
//			U.log("mmmmmm"+Util.matchAll(html+com, "[\\w\\s\\W]{30}Quick Delivery Homes[\\w\\s\\W]{30}", 0));
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			if(floorSec!=null && floorSec.length>0 && floorData.contains("<div class=\"move-in-ready\">"))
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-Ins";
				else if(!pstatus.contains("Quick"))
					pstatus += ", Quick Move-Ins";
			
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
//			if(comUrl.contains("https://www.homesbydickerson.com/communities/pinehurst-national-no-9")) {
//				pstatus="Quick Delivery Homes";
//			}
			
//			if(comUrl.contains("https://www.homesbydickerson.com/communities/pinehurst-national-no-9")) 
//				pstatus=pstatus+", Homesites available";
			
			
			
//			========================================================================
			
			String mapLinkSec=U.getSectionValue(html, "<iframe id=\"community-site-plan\"", ">");
//			U.log("mapLink=="+mapLinkSec);
			String lotcount=ALLOW_BLANK;
			int sum=0;
			if(mapLinkSec!=null) {
				String mapLink=U.getSectionValue(mapLinkSec, "src=\"", "\"");
				if(mapLink!=null) {
					mapLink=mapLink.replace(" ", "%20");
					String mapHTML=U.getHtml(mapLink,driver);
					if(mapHTML!=null) {
						String[] arr=U.getValues(mapHTML, "<span class=\"jss135\">", "</span>");
						U.log("arr.length=="+arr.length);
						if(arr.length==0)
							arr=U.getValues(mapHTML, "MuiTypography-overline\">", "</span>");
						if(arr.length>0) {
							for(String a : arr) {
//						String  data=Util.match(a, "(\\d+ homesites)");
								a=a.replaceAll("jss\\d+", "");
//						U.log("data=="+a);
						sum+=Integer.parseInt(Util.match(a, "\\d+"));
						
						}
						}
					}
				}
				U.log("sum=="+sum);
				lotcount=Integer.toString(sum);
				U.log("mapLink=="+mapLink);
			}
			
			if(lotcount.equals("0"))
				lotcount=ALLOW_BLANK;
			
			
			
			
			
			//=========================================================================================================================
			data.addCommunity(communityName.replace("Blanton�s Creek", "Blantons Creek").replace("�s", "s").replace(",", ""), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Final Phase, Opening Soon", "Final Phase Opening Soon"));
			data.addNotes(note);
			data.addUnitCount(lotcount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
//		}
		j++;

	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,1000)", ""); 
					try {
						WebElement element = driver.findElement(
								By.xpath("/html/body/div[1]/div/div/div[6]/div/div[2]/section[1]/div[2]/button"));
						if (driver.findElement(By.xpath(
								"/html/body/div[1]/div/div/div[6]/div/div[2]/section[1]/div[2]/button")) != null) {
							driver.findElement(
									By.xpath("/html/body/div[1]/div/div/div[6]/div/div[2]/section[1]/div[2]/button"))
									.click();
							U.log("Element Found");
						} else
							U.log("Element Not Found");
					} catch (Exception e) {
						// TODO: handle exception
					}
						
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,800)", ""); 
					
					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}

}