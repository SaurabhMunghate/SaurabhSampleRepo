package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHubbellHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	WebDriver driver=null;
	static int j = 0;

	public ExtractHubbellHomes() throws Exception {

		super("Hubbell Homes", "https://www.hubbellhomes.com/");
		LOGGER = new CommunityLogger("Hubbell Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractHubbellHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Hubbell Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
      String mainHtml=U.getHTML("https://www.hubbellhomes.com/communities");
		
//      String comSection=U.getSectionValue(mainHtml, "<div class=\"product-grid items communityList\">", "  <div class=\"product-grid items communityList\">");
     
    //  String[] comSections = U.getValues(mainHtml, "<a class=\"item product\"", "</a>");
   //   String[] comSections = U.getValues(mainHtml, "class=\"homefinder-result-teaser\"", "</a>");
      
      String[] comSections = U.getValues(mainHtml, "<div class=\"item product\">", "</a>");
      U.log(comSections.length);
      for(String comSec:comSections) {
    	  String comUrl="https://www.hubbellhomes.com"+U.getSectionValue(comSec,"href=\"","\"");
    	  U.log(comUrl);
//    	  try {
    		  addDetails(comUrl, comSec);
//    	  } catch (Exception e) {}
      }
      	driver.quit();
		LOGGER.DisposeLogger();
	}
	
	
	public void addDetails(String comUrl, String comData) throws Exception {
		
//		if(j>=15) 
		{
	
	//TODO:		
		if(!comUrl.contains("https://www.hubbellhomes.com/communities/danamere-farms"))return;
		
		//===================uncomment for only first time extraction
		//driver.get(comUrl);
	//	Thread.sleep(10000);
		String comHtml=U.getHTML(comUrl);
		//U.log(U.getCache(comUrl));
		U.log(comUrl);
//		U.log(comData);
		U.log(U.getCache(comUrl));
		String comName=U.getSectionValue(comData, "<div class=\"title\">", "</div>");
		//MuiTypography-alignCenter">
		//if(comName==null) {
			
			
		//	comName=U.getSectionValue(comHtml, "", "");
	//	}
		comName=comName.replace(">", "");
		if(comUrl.contains("https://www.hubbellhomes.com/communities/grays-station"))
			comName="Gray's Station";
		U.log(comName);
		LOGGER.AddCommunityUrl(comUrl);
		//===================address=================================================
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
	




		
		latlag[0]=U.getSectionValue(comHtml, "{ lat: ", ",").trim();
		latlag[1]=U.getSectionValue(comHtml, ", lng: ", " };").trim();
		U.log(Arrays.toString(latlag));
		
		try {
		add=U.getAddressGoogleApi(latlag);
		}catch (Exception e) {
			// TODO: handle exception
			if(add==null || add[0]==ALLOW_BLANK)
				add = U.getAddressHereApi(latlag);
		}
		
		geo="TRUE";
		if(comUrl.contains("/communities/greens-at-woodland-hills"))
		{
			add[0]="620 NE 66th Ave";
			add[1]="Des Moines";
			add[2]="IA";
			add[3]="50313";//===remmm
											
		}
		U.log("LATLONG: "+Arrays.toString(latlag));
		U.log("ADDRESS: "+Arrays.toString(add));
		U.log("GEO: "+geo);
		
		//===================================available homes section============================================
		String availUrl="";
		String availHtml="";
		String floorUrl="";
		String floorHtml="";
		
	//	try {
//		for(int i=1;i<=2;i++) {
//		 availUrl=comUrl+"/inventory-search?page="+i+"";
//		U.log(availUrl);
//		availHtml+=U.getSectionValue(getHtml(availUrl, driver),"<div class=\"MuiGrid-root undefined MuiGrid-container MuiGrid-item\">","<div class=\"MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12\"></div>")+U.getSectionValue(getHtml(availUrl, driver), "><div class=\"MuiGrid-root jss166 MuiGrid-container MuiGrid-spacing-xs-2\">", "<div class=\"MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12\">")
//		+U.getSectionValue(getHtml(availUrl, driver), "</h4><h4 class=\"MuiTypography-root", "</h4>");
//		
//		}
		
		//String[] availUrls = U.getValues(comHtml, "<a class=\"item product\" href=\"", "\"");
		String[] availUrls = U.getValues(comHtml, "<div class=\"item product\">", "</a>");
		for(String murl : availUrls) {
			String url=U.getSectionValue(murl, "<a href=\"", "\"");
            U.log("Avail Url:: "+url);
			availHtml += U.getSectionValue(U.getHtml("https://www.hubbellhomes.com"+url,driver), "<h2>More About This Home:</h2>", "<div class=\"container\">");
            //availHtml +=U.getHtml("https://www.hubbellhomes.com"+url,driver);
		
		}
		
		//=========================floor========================================================
//		floorUrl=comUrl+"/model-search";
//		floorHtml=getHtml(floorUrl, driver);
//		
//		String count = Util.match(floorHtml, "of \\d+ results",0);
//		U.log("breakCount: "+count);
//		
//		if(count!=null) {
//		int breakCount = Integer.parseInt(count.replaceAll("[a-z]*|[A-Z]*", "").trim()); 
//		
//		int check  = Math.incrementExact(breakCount/10);
//		
//		for(int i=1;i<=check;i++) {
//			
//			floorUrl=comUrl+"/model-search?page="+i;
//			 floorHtml+=getHtml(floorUrl, driver);
//			
//			}
//		
//		}
		
//		}
//		catch(NullPointerException|FileNotFoundException ne) {}
//		
		
		
		
		//=====================prices==========================================
		
		availHtml=availHtml.replace("0's", "0,000");
		floorHtml=floorHtml.replace("0's", "0,000");
		comHtml=comHtml.replaceAll("0's|0s", "0,000");
		comData = comData.replaceAll("0s", "0,000");
		
		 String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			prices=U.getPrices(comData+comHtml+floorHtml+availHtml, "mid \\$\\d{3},\\d{3}|<span class=\"\">\\$\\d{3},\\d{3}</span>|High \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
			//U.log(Util.matchAll(availHtml, "[\\w\\s\\W]{30}287,400[\\w\\s\\W]{30}",0));
			U.log("PRICES: "+Arrays.toString(prices));
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(comHtml+floorHtml+availHtml, "<div class=\"sqft\">\\d{3} sf</div>|>\\d{4} sf</div>|\\d,\\d{3} - \\d,\\d{3} square feet|\\d{4} Sq\\.Ft|\\d{3} Sq.Ft|\\d{4} Sq.Ft", 0);
			
			if(comUrl.contains("https://app.hubbellhomes.com/community-search/community/crosshaven"))sqft[1]="2741";
			
			
			
			U.log("SQFT: "+Arrays.toString(sqft));
			
		//==================cType===============================================
			String cType=U.getCommType(comHtml);
			U.log(cType);
			
			
			String pType=ALLOW_BLANK;
			comHtml = comHtml.replace("Forrester - Villa", "Forrester - Villas")
					.replace("urban living coupled with unparalleled luxury", "urban living coupled with unparalleled luxury homes ");
			
			
			pType = U.getPropType(availHtml+comHtml.replaceAll("Trail offers single family home|condo downtown|Edison Condos in", "").replace("of elegance and luxury", "luxury homes").replaceAll("Edison Condos in Downtown|HOA Portal</a>|glynn-village|Glynn_Village|Village|village", ""));
			
			U.log("pType::::::" + pType);
//			U.log(Util.matchAll(availHtml+comHtml, "[\\w\\s\\W]{50}villa[\\w\\s\\W]{50}",0));
			
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			
			dType = U.getdCommType(comHtml+floorHtml);
		
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;

			pStatus = U.getPropStatus((comData+comHtml).replace("100% USDA Rural Development Financing available","100% USDA Financing available").replace("MuiTypography-subtitle1\">Coming soon</h6>", ""));
			U.log("status:::::::" + pStatus);
			
			if(pStatus.equals("New Homes Coming Soon, Coming Soon"))pStatus = pStatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon");
			if(comUrl.contains("communities/heritage-park-at-prairie-trail") 
					|| comUrl.contains("/communities/edison")
					|| comUrl.contains("communities/waterford-landing"))
				pStatus = pStatus.replace("Coming Soon", "New Homes Coming Soon");

			
			if(comUrl.contains("https://www.hubbellhomes.com/communities/aventura"))cType = "55+ Community";

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(comHtml));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
			
			
			
			
		
		
		U.log("==========================="+j);
		}
		j++;
		
		
	}


	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(10000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,800)", ""); 
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					Thread.sleep(5000);
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	
}