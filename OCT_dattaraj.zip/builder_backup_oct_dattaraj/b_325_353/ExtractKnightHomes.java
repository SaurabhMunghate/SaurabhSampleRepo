package com.shatam.b_325_353;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author MJS
 * @date 30/03/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractKnightHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://www.knighthomes.com";
	WebDriver driver = null;

	public ExtractKnightHomes() throws Exception {
		super("Knight Homes", builderUrl);
		LOGGER = new CommunityLogger("Knight Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractKnightHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Knight Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String html = U.getHTML("https://www.knighthomes.com/find-new-homes/");
		String[] mainSec = U.getValues(html, "<li class=\"hproduct marketPage", "</li>");
		U.log(mainSec.length);
		for(String data : mainSec)
		{
			String comUrl = U.getSectionValue(data, "href=\"", "\"");
			
//			try {
				getDetail(builderUrl+comUrl, data);
//			} catch (Exception e) {}
			
		}
		driver.quit();
		LOGGER.DisposeLogger();
		
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
//		try {
//		if(!comUrl.contains("https://www.knighthomes.com/find-new-homes/cedar-grove-commons/"))return;
		
		U.log("Count: " + j + "\t" + comUrl);
		{
			
//			U.log(com);
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			String html = U.getHTML(comUrl);
			U.log(U.getCache(comUrl));
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, comUrl, driver);
			U.log("Total Units : "+units);
			// ---------------------------------------------------------
			
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(com, "communityUrlInfo\">", "<");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "<div class=\"communityAddress \">", "</div>");
			
			if (addSec != null) {
				
				add[0] = U.getSectionValue(addSec, "<span class=\"addressStreet\">", "<").trim();
				add[1] = U.getSectionValue(addSec, "<span class=\"addressCity\">", "<").trim();
				add[2] = U.getSectionValue(addSec, "<span class=\"addressState\">", "<").trim();
				add[3] = U.getSectionValue(addSec, "<span class=\"addressZipCode\">", "<").trim();
				
			}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
		
				latLng[0] = U.getSectionValue(html, "data-center-latitude=\"", "\"");
				latLng[1] = U.getSectionValue(html, "data-center-longitude=\"", "\"");
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0].length() < 2)
					add[0] = add1[0];
				if (add[3] == null)
					add[3] = add1[3];
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			
			//========== Move In Homes ==================================================
			String moveHtml = U.getHTML("https://www.knighthomes.com/available-homes/");
			String[] movSec = U.getValues(moveHtml, "<li class=\"hproduct homeDataInformation", "</li>");
			String moveData = ALLOW_BLANK;
			for(String data : movSec)
				if(data.contains(communityName)) {
				
					String url = U.getSectionValue(data, "<a href=\"", "\"");
					
					String mhtml = U.getSectionValue(U.getHTML(builderUrl+url), "<div class=\"homeDetailBox homePageDetailBox featureRight\">", "<!--Configurable tabs-->");
					moveData += data+mhtml;
				}
			
			//========== floors ==================================================
			String[] floorSec = U.getValues(html, "<li class=\"hproduct homeDataInformation", "</li>");
			String floorData = ALLOW_BLANK;
		//	String floorData1="";
			for (String data : floorSec) {
				
				String url = U.getSectionValue(data, "<a href=\"", "\"");

			//	U.log(url);
				String floorHtml=U.getHTML(builderUrl + url);
			//	floorData1+=floorHtml;
				String fhtml = U.getSectionValue(floorHtml,
						"<div class=\"homeDetailBox homePageDetailBox featureRight\">", "<!--Configurable tabs-->");
				floorData += data + fhtml;
			}
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replace("Mid $300s", "Mid $300,000").replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's|0s", "0,000");
			
			html = html.replace("0s", "0,000").replaceAll("Homes over \\d+ SF: \\d+ gallon electric hybrid water heater|Homes under \\d+ SF: \\d+ gallon gas water heater|Homes over \\d+ SF: \\d+-gallon electric hybrid water heater|Homes under \\d+ SF: \\d+-gallon gas water heater", "");
			String prices[] = U.getPrices(com + html + moveData + floorData, "Mid \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|Price point \\$\\d{3},\\d{3}|prices: \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}<|dealPrice\">\\$\\d{3},\\d{3}</span>|Priced at</span> \\$\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			if(moveData!=null)
				moveData = moveData.replaceAll("<div class=\"label\">Square Feet</div>\n\\s*<div class=\"value\">", "Square Feet");
			html=html.replace("4000+", "4000");
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}3200[\\w\\s\\W]{30}", 0));
			String[] sqft = U.getSqareFeet(com + html + moveData + floorData,
					"\\d{4}-\\d{4} square feet|\\d{4} sq ft – \\d{4} sq ft.|\\d{4} to \\d{4} square feet|\\d{4} - \\d{4} square feet|\\d{1},\\d{3} sq, ft.|\\d{1},\\d{3} to over \\d{1},\\d{3} square feet|\\d{4} – \\d{4} square feet|\\d,\\d{3} - \\d,\\d{3} Square Feet|\\d,\\d{3} Square Feet </li>",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
			
			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================
			html = html.replaceAll("craftsman and farmhouse style elevations", "");
			String proptype = U.getPropType((html + com + moveData +floorData));

			// ==================================================D-Property
			// Type======================================================
			if(moveData!=null)
				moveData = moveData.replaceAll("<div class=\"label\">Stories</div>\n\\s*<div class=\"value\">", "Story");
			String dtype = U.getdCommType((html + com + moveData).replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
	
			html = html.replace("selling so fast", "Selling Fast").replaceAll("Coming end of 2021|Homes Available Now|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			String pstatus = U.getPropStatus(html + com);
			
			U.log("pstatus: "+pstatus);
//			U.log("mmmmmm"+Util.matchAll(html + com, "[\\w\\s\\W]{30}opening late[\\w\\s\\W]{30}", 0));
			
			//
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "");
			
			if(moveData!=null && moveData.length()>7 && !moveData.contains("Under Construction"))
				if(pstatus==ALLOW_BLANK)
					pstatus = "Homes Available Now";
				else if(!pstatus.contains("Homes Available Now")) 
					pstatus += ", Homes Available Now";
			
			if(comUrl.contains("https://www.knighthomes.com/find-new-homes/luella-grove")) {
//				minSqft="3100";
//				maxSqft="4300";
				communityType="Gated Community";
			}
			if(comUrl.contains("https://www.knighthomes.com/find-new-homes/rowland-place/"))add[0]="208 Zora Place";
			//=========================================================================================================================
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replaceAll("McDonough Georgia|,", "").trim(), add[1].replace(",", "").trim(), add[2].replace(",", "").trim(), add[3].replace(",", "").trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Iii", "III").replace("Ii", "II").replace("Coming Mid Fall, Coming Later This Spring, Coming Soon", "Coming Mid Fall, Coming Later This Spring"));
			data.addNotes(note);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);

		}
		j++;
//		}catch(Exception e){}

	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("Site Map</span>") || html.contains("Interactive Plat</span>") ||
				html.contains("Interactive plat</span>")) {
			
			String frameSec = U.getSectionValue(html, "<a class=\"interactiveFeature", "Site Map</span>");
			if(frameSec == null) frameSec = U.getSectionValue(html, "<a class=\"interactiveFeature", "Interactive Plat</span>");
			if(frameSec == null) frameSec = U.getSectionValue(html, "<a class=\"interactiveFeature", "Interactive plat</span>");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "href=\"", "\""); 
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.contains("platwidget.com")) {
					
					mapData = U.getHtml(frameUrl, driver);
					
					if(mapData.contains("class=\"pw-str mkr-6\">") || mapData.contains("class=\"pw-str mkr-3\">")) {
						
						ArrayList<String> red = Util.matchAll(mapData, "class=\"pw-str mkr-6\">", 0);
						U.log("Count Red Circle: "+red.size());
						
						ArrayList<String> green = Util.matchAll(mapData, "class=\"pw-str mkr-3\">", 0);
						U.log("Count Green Circle: "+green.size());
						
						ArrayList<String> greenLight = Util.matchAll(mapData, "class=\"pw-str mkr-1\">", 0);
						U.log("Count Light Green Circle: "+greenLight.size());
						
						int circleCount = red.size() + green.size() + greenLight.size();
						totalUnits = String.valueOf(circleCount);
					}
				}
			}
		}
		return totalUnits;
	}

}