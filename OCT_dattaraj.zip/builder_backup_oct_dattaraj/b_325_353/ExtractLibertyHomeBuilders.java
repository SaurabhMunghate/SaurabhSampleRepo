package com.shatam.b_325_353;
/**
 * @author MJS
 * @date 02/04/2021 
 * 
 */

import static org.junit.Assert.assertArrayEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLibertyHomeBuilders extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://www.libertyhomebuilders.com";

	public ExtractLibertyHomeBuilders() throws Exception {
		super("Liberty Home Builders", builderUrl);
		LOGGER = new CommunityLogger("Liberty Home Builders");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractLibertyHomeBuilders();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Liberty Home Builders.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	static HashMap<String, String> latlongMap = new HashMap<String, String>();
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String html = U.getHTML("https://www.libertyhomebuilders.com/communities");
		String[] regionSec = U.getValues(html, "<div class=\"detail-section add\">", "COMMUNITIES</a>");
		
		for(String region : regionSec) {
			
			String regionUrl = U.getSectionValue(region, "<a href=\"", "\"");
				try {
					getCommunities(builderUrl+regionUrl);
				} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}

	private void getCommunities(String regionUrl) throws Exception {
		// TODO Auto-generated method stub
		
		U.log("regionUrl: "+regionUrl);
		
		String html = U.getHTML(regionUrl);
		
		//-------------STORING LATLONG AND ADDRESSES---------
		
		
		if(html.contains("var _markers = [")) {
			
			//Below data has latlong and address - only using latlong here
			String markers = U.getSectionValue(html, "var _markers = [", "];");
			//U.log("markers: "+markers); 
			
			String[] comData = U.getValues(markers, "[", "]");
			U.log("comData length: "+comData.length);
			
			for(String comdata:comData) {
				
				//U.log("comdata: "+comdata);
				
				String[] addArray = comdata.split("\",");
				//U.log("addArray: "+addArray.length);
				
				String[] latlongArray = addArray[1].split(",\"");
				//U.log("latlongArray: "+latlongArray.length);
				
				String latlongregion = latlongArray[0];
				U.log("latlongregion: "+latlongregion);
				
				String comurl = "https://www.libertyhomebuilders.com" + addArray[4].replace("\"/", "/");
				U.log("comurl: "+comurl);
				
				latlongMap.put(comurl, latlongregion);
			}
			
		}
		
		String[] mainSec = U.getValues(html, "<div class='community-details'>", "View Community</a>");
		
		for(String main : mainSec) {
			
			String comUrl = U.getSectionValue(main, "<a href='", "'>");
			getDetail(builderUrl+comUrl, main);
			
		}
		
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/stone-creek-ranch")) return;
		
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, "<h3>","<");
			if(communityName==null)
				communityName = U.getSectionValue(html,"<h3>", "<");
			
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(com, "<div class='community-address'>", "/div>");
		
			
			if(addSec!=null) {
				
				String addVal = U.getSectionValue(addSec.replace("<div style='display: inline-block;'>", ""), "<div>", "<");
				if(addVal!=null)
				add = U.getAddress(addVal);
				else {
					
					addVal = U.getSectionValue(addSec, "</a>", "<");
					String[] add1 = addVal.split(",");
					add[0] = ALLOW_BLANK;
					add[1] = add1[0];
					add[2] = add1[1];
					add[3] = ALLOW_BLANK;
					
					latLng = U.getlatlongGoogleApi(add);
					add = U.getAddressGoogleApi(latLng);
					geo = "TRUE";
				}
			}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			U.log("addSec here: "+addSec);

			if(addSec!=null) {
				
				String latSec = U.getSectionValue(addSec, "/@", "/");
				if(latSec!=null) {
					latSec = latSec.replaceAll(",\\d{2}[a-z]", "");
					latLng = latSec.split(",");
					
				}
				
			}
			if(addSec.contains("maps/embed")) {
				
				String latSec = U.getSectionValue(addSec, "<a href='https://www.google.com/maps/", "'");
			
				
				if(latSec!=null) {
					
					U.log("latSec: "+latSec);
					
					latSec = Util.match(latSec, "-\\d+\\.\\d+.*\\d+\\.\\d+").replaceAll("!\\d+[a-z]", ",");
					latLng = latSec.split(",");
					String lat = latLng[0];
					latLng[0] = latLng[1];
					latLng[1] = lat; 
				}
				
			}
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			
			U.log("LATLONG --->" + latLng[0] + "  " + latLng[1]);
			
			if(latLng[0]==ALLOW_BLANK && latLng[1]==ALLOW_BLANK) {
				
				//getting latlong from region
				String latlongregion = latlongMap.get(comUrl);
				
				
				if(latlongregion != null) {
					
					U.log("latlongregion inside ========== : "+latlongregion);
					
					latLng = latlongregion.split(",");
					U.log("LATLONG REGION: "+Arrays.toString(latLng));
				}
				
			}
			
			
			
			//---------------------------
			
			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//====== Available Homes ================================
			String[] homeSec = U.getValues(html, "<a class=\"home-overlay\"", "<span>View Home</span></a>");
			String homeData = ALLOW_BLANK;
			for(String home : homeSec) {
				
				home = U.getSectionValue(home, "href=\"", "\"");
				U.log("homeURL:   "+builderUrl+home);
				homeData += U.getSectionValue(U.getHTML(builderUrl+home), "<div class='house-description'>", "<div class='container'>")+U.getSectionValue(U.getHTML(builderUrl+home), "<span class='current-page'>", "<div class='community-row house-btn-row'>");
			}
			//====== Available Floor ================================
			String comId = U.getSectionValue(html, "var community = ", ";");
			String floorData = ALLOW_BLANK;
			if (comId != null)
				floorData = U.getHTML(
						"https://www.libertyhomebuilders.com/gethouselisting?sortBy=HomePrice&sortOrder=ASC&listType=floorPlan&layout=tile&community="
								+ comId);
			
//			U.log(">>>>>>>>>.>>>>>>>>>>>>>>"+floorData);
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			
			html = html.replace("0s", "0,000");
			
//			U.log(">>>>>>>>"+Util.matchAll(floorData, "[\\w\\s\\W]{100}355,990[\\w\\s\\W]{100}",0));
			
			String prices[] = U.getPrices(com + html + floorData , "starting in the high \\$\\d{3},\\d{3}|starting in the \\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|<span class='info-data price'>\\$\\d{3},\\d{3}</span>|\\$<span class='info-data price'>\\d+</span>|low \\$\\d{3},\\d{3}|<span class='price'>\\$\\d{3},\\d{3}</span>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		    html= html.replaceAll("content=\".*\"", "");
			String[] sqft = U.getSqareFeet(com + html + floorData,
					"\\d,\\d{3} SF - \\d,\\d{3} SF|<span class='info-data'>\\d+</span>|from \\d,\\d{3} sqft to \\d,\\d{3} sqft|from \\d+ sqft to \\d+ sqft|\\d,\\d{3} SF to \\d,\\d{3} SF|\\d,\\d{3} SF to almost \\d,\\d{3} SF|\\d,\\d{3} SF - \\d,\\d{3} SF",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replaceAll("Anderson Lake community|golf, lake activities|such as the Golf Club|resort style amenities including a Junior Olympic-size pool|navigated|information about the Anderson Lake community|Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================

			html = html.replace("crafted homes feature Mediterranean", "crafted homes feature Mediterranean-Style Homes")
					.replace("features Mediterranean", "features Mediterranean-Style Homes")
					.replace("Mediterranean and Craftsman styles", "Mediterranean-Style Homes and Craftsman styles")
					.replace("Mediterranean, Tuscan and traditionally styled exterior designs", "Mediterranean-Style Homes, Tuscan and traditionally styled exterior designs");
			String proptype = U.getPropType((html + com + floorData).replace("Lyle Manor Drive", "").replace("School District and attend Kings Manor Elementary", ""));
//			U.log(">>>>>>>>>>>"+Util.matchAll(html + com + floorData , "[\\s\\w\\W]{100}manor[\\s\\w\\W]{100}", 0));

			// ==================================================D-Property
			// Type======================================================
			com = com.replaceAll("Stories<br>\n\\s*<span class='enlarge'>\n\\s*1-2", " Story 1  2 Story ")
					.replaceAll("Stories<br>\n\\s*<span class='enlarge'>\n\\s*1", " Story 1 ")
					.replaceAll("Stories<br>\n\\s*<span class='enlarge'>\n\\s*2", " Story 2 ");
			if(floorData!=null)
				floorData = floorData.replaceAll("STORIES</span> <br>\n\\s*pan class='info-data'>1</span>", " Story 1 ")
						.replaceAll("STORIES</span> <br>\n\\s*pan class='info-data'>2</span>", "2 Story");
			if(homeData!=null)
				homeData = homeData.replaceAll("STORIES</span> <br>\\s*<span class='info-data'>1</span>", " Story 1 ")
						.replaceAll("STORIES</span> <br>\\s*<span class='info-data'>2</span>", "2 story");
			floorData=floorData.replaceAll("<br>\n" + 
					"<span class='info-data'>", "").replace("STORIES</span> 2", "2 Story");
			
			//for colonial
//			ArrayList<String> colonialCount = Util.matchAll(html, "colonial", 0);
//			U.log("Count Colonial: "+colonialCount.size());
//			
//			if(colonialCount.size() == 18) {
//				U.log("IN HERE"+colonialCount.size());
//				html = html.replace("colonial", "");
//			}

			String dtype = U.getdCommType((html + (com + floorData + homeData))
					.replaceAll("Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
					+ communityName);
			
			//U.log(">>>>>>>>>>>"+Util.matchAll(com + floorData + homeData , "[\\s\\w\\W]{60}colonial[\\s\\w\\W]{60}", 0));
			
			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("LagoonLife coming 2021|lagoon. Now open,|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("Coming soon, neuhouse", "");
			
//			U.log(">>>>>>>>>>>"+Util.matchAll(html + com , "[\\s\\w\\W]{100}now open[\\s\\w\\W]{100}", 0));

			String pstatus=ALLOW_BLANK;
			pstatus = U.getPropStatus(html + com);
	  U.log("PROPsTATUS1"+pstatus);
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			if(comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/kings-mill")||comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/sierra-vista") || 
					comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/ladera")||
					comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/the-overlook-at-creekside") ||
					comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/parklands")|| comUrl.contains("communities-homes-list/anderson-lake")) {
				if(pstatus==ALLOW_BLANK)
					pstatus = "Now Open";
				else
					pstatus += ", Now Open";
			}
			  U.log("PROPsTATUS1"+pstatus);
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
			U.log(homeData.contains("<span class='info-data'>Move-in Ready</span>"));
			if(homeData.contains("Move-in Ready")) {
				if(pstatus==ALLOW_BLANK)
					pstatus = "Move-in Ready";
				else
					pstatus += ", Move-in Ready";
			}
			
			
			//if(comUrl.contains("https://www.libertyhomebuilders.com/communities-homes-list/kings-mill"))pstatus=pstatus+", Now Open";
//			pstatus=pstatus.replaceAll("Move-in Ready|, Move-in Ready", "");
//			if(pstatus.length()==0) {
//				pstatus=ALLOW_BLANK;
//			}
//			
			//=========================================================================================================================
			data.addCommunity(communityName.replace(",", ""), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].replace(",", "").trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;

	}

}