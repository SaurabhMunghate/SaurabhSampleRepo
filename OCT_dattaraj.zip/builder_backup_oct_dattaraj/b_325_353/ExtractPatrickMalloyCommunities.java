package com.shatam.b_325_353;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.regexp.recompile;
import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author MJS
 * @date 01/04/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPatrickMalloyCommunities extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	static String builderUrl = "https://www.pmcommunities.com";
	WebDriver driver = null;
	
	public ExtractPatrickMalloyCommunities() throws Exception {
		super("Patrick Malloy Communities", builderUrl);
		LOGGER = new CommunityLogger("Patrick Malloy Communities");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractPatrickMalloyCommunities();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Patrick Malloy Communities.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String html = U.getHTML("https://www.pmcommunities.com/new-homes/");
		String[] mainSec = U.getValues(html, "<div class=\"comm_list_block card", "View Community</a>");
		
		for(String main : mainSec) {
			
			String comUrl = U.getSectionValue(main, "<a href=\"", "\"");
			try {
				getDetail(comUrl, main);
			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();

	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
		
		{
		//D
//			U.log("Count: " + j + "\t" + comUrl);
//				comUrl = "https://uppereastriver.com/";
			U.log("comUrl: "+comUrl);
			
			if (comUrl.contains("https://www.pmcommunities.com/new-homes/canton-ga/soleil/")) {
				LOGGER.AddCommunityUrl("Not Open======== " + comUrl);
				return;
			}
			if (comUrl.contains("https://www.pmcommunities.com/new-homes/canton-ga/soleil-belmont-park/")) {
				comUrl="https://soleilbelmontpark.com/";
			}else {			
				comUrl=U.getRedirectedURL("https://www.pmcommunities.com", comUrl);
			}
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			if (comUrl.contains("http://soleilbelmontpark.com")) {
				LOGGER.AddCommunityUrl("Redirect======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
//			comUrl=comUrl.replace("http:", "https:");
			String html = U.getHTML(comUrl);
			
//-------SINGLE EXECUTION			
//			 if(!comUrl.contains("https://www.pmcommunities.com/new-homes/acworth/the-reserve-governors-towne-club/")) return;
			
			 //U.log(">>>>>>>>>>>>>>>>>>>>>>>>\n"+com);
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, " data-name=\"","\"");
			
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'");
			communityName=communityName.replace("In Historic Roswell", "");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
//			U.log(com);
			String addSec = U.getSectionValue(com, "Sales Office Address", "<div><a").replace(":</div>", "");
			if(addSec!=null) {
//				U.log(addSec);
				String address[]=U.getValues(addSec, "<div>", "</div>");
				U.log(Arrays.toString(address));
				add[0]=address[0];
				address[1]="start"+address[1];
				add[1]=U.getSectionValue(address[1], "start", ",");
				add[2]=U.getSectionValue(address[1], ", ", " ");
				add[3]=Util.match(address[1], "\\d{5}");
			}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			if(comUrl.contains("uppereastriver")) {
				latLng[0]="32.076421";
				latLng[1]="-81.076812";
			}
			if(com.contains("data-lat=\"")) {
				latLng[0]  = U.getSectionValue(com, "data-lat=\"", "\"");
				latLng[1]  = U.getSectionValue(com, "data-long=\"", "\"");

			}
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//====== Floor Plans ================================
			String[] floorSec = U.getValues(html, "<div class=\"plan_block", "View Plan</a>");
			String floorData = ALLOW_BLANK;
			for(String floor : floorSec) {
				
				floor = U.getSectionValue(floor, "<a href=\"", "\"");
//				U.log("floorUrl --->"+floor);
				floorData += U.getSectionValue(U.getHTML(floor), "<main>", "Request More Information</a>");				
			}
			
			if(comUrl.contains("https://soleillaurelcanyon.com/")){
				floorData = U.getHTML("https://soleillaurelcanyon.com/floorplans/");
			}
			if(comUrl.contains("https://soleilbelmontpark.com/"))
				floorData = U.getHTML("https://soleilbelmontpark.com/floorplans/");
			
			if(comUrl.contains("https://uppereastriver.com/"))
				floorData = U.getHTML("https://uppereastriver.com/neighborhood/");
			//====== Available Homes ================================
			String[] homeSec = U.getValues(html, "<div class=\"listing_block", "View Details</a>");
			String homeData = ALLOW_BLANK;
			String myHomeData=ALLOW_BLANK;
			String realEstHome=ALLOW_BLANK;
			for(String home : homeSec) {
				
				home = U.getSectionValue(home, "<a href=\"", "\"");
//				U.log("homeUrl -->"+home);
				homeData += U.getSectionValue(U.getHTML(builderUrl+home), "<main>", "<!-- location and contact -->");
			}
			if(comUrl.contains("https://soleilbelmontpark.com/")) {
				myHomeData=U.getHTML("https://soleilbelmontpark.com/home-search/shared_search/7bb0d51ea7");
			    String[] Myhomes=U.getValues(myHomeData, "title=\"Real Estate Property Link\" href=\"","\"");
			    
			    for(String myrHome:Myhomes) {
			    	U.log("myrHome=="+myrHome);
			    	realEstHome+=" "+U.getHTML(comUrl+myrHome);
			    }
			}
//			if(comUrl.contains("https://uppereastriver.com/")) {
//				myHomeData=U.getHTML("https://uppereastriver.com/homes-at-upper-east-river/");
//				String[] Myhomes=U.getValues(myHomeData,"<div class=\"home-style\">","<p class=\"homes-clear\">");
//				 for(String myrHome:Myhomes) {
//				  String MyHomeUrl=U.getSectionValue(myrHome,"<a href=\"","\"");
//				  U.log("ooo :"+MyHomeUrl);
//				  realEstHome+=" "+U.getHTML(myrHome);
//				 
//				 }
//			
//			}
			
			if(comUrl.contains("https://uppereastriver.com/")) {
				String[] homeStyle=U.getValues(floorData, "<a href=\"http://uppereastriver.com/neighborhood/","\">");
				for(String homest:homeStyle) {
				String HomeStyle=U.getHTML("http://uppereastriver.com/neighborhood/"+homest);
				realEstHome+=" "+HomeStyle;
				}
			}
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replace("from the $600,000s to the $4 millions", "from the $600,000 to the $4,000,000")
					.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's|0’s", "0,000").replaceAll("\\$1 [M|m]illion", "\\$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's|0s", "0,000");
			html=html.replace("From $1 Million", "From $1,000,000");
			html = html.replace("0s", "0,000");
			realEstHome=realEstHome.replaceAll("0s|0's","0,000");
			String prices[] = U.getPrices(com + html + floorData + homeData+myHomeData+ realEstHome, 
					"shallow\">\\$\\d{3},\\d{3}</div>|\\$\\d{3},\\d{3}|From the High \\$\\d+,\\d+|<h4>Starting at \\$\\d{3},\\d{3}|From The \\$\\d{3},\\d{3} To The \\$\\d{3},\\d{3}</h2>|From \\$\\d{1},\\d{3},\\d{3}|From the \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} to the \\$\\d,\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|From the Low \\$\\d{3},\\d{3}|from the mid \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</div>|>\\$\\d,\\d{3},\\d{3}</div>|\\$\\d{3},\\d{3}</h3>|\\$\\d,\\d{3},\\d{3}</h3>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			
//			U.log(">>>>>>>>"+Util.matchAll(com + html + floorData + homeData, "[\\w\\s\\W]{10}760[\\w\\s\\W]{10}",0));
			
/*			if(comUrl.contains("soleillaurelcanyon")) {
				minPrice="$300,000";
				maxPrice="$440,000";
			}*/
			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html + floorData + homeData,
					"\\d,\\d{3} sq.ft|\\d,\\d{3} sq\\.ft\\.|<br />\\d,\\d{3} sq. ft.</span|\\d{4}<span>SqFt</span>|\\d,\\d{3}<span>SqFt</span>",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			if(comUrl.contains("uppereastriver")) {
				minSqft="1894";
				maxSqft="4491";
			}
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================
			html =html.replace("Resort-level", "resort style pool").replace("Resort-style amenities ","resort-style living amenities" );
			String communityType = U.getCommType((html + com).replaceAll("Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));
			
			//U.log(">>>>>>>>"+Util.matchAll(html + com, "[\\w\\s\\W]{50}55-and-better[\\w\\s\\W]{50}",0));
			// ==========================================================Property
			// Type================================================

			html = html.replace("crafted homes feature Mediterranean", "crafted homes feature Mediterranean-Style Homes")
					.replace("features Mediterranean", "features Mediterranean-Style Homes").replace("Inspired by the understated elegance of traditional southern architecture", "Inspired by the understated elegance of traditional-style homes")
					.replace("Mediterranean and Craftsman styles", "Mediterranean-Style Homes and Craftsman styles")
					.replace("Mediterranean, Tuscan and traditionally styled exterior designs", "Mediterranean-Style Homes, Tuscan and traditionally styled exterior designs");
		if(comUrl.contains("soleillaurelcanyon")) {
			homeData=U.getHTML("https://soleillaurelcanyon.com/homes/");
			}
			
		homeData = homeData.replace("Luxury Charleston inspired", "Luxury Homes Charleston inspired");
			html = html.replace("luxury gated", "luxury homes gated").replace("fine finishes fitting for luxury", "fine finishes fitting for luxury living");
			String proptype = U.getPropType((html + com + floorData + homeData+realEstHome).replaceAll("= ENCLAVE AT ELM CREEK VILLAS =|/* Enclave at Elm Creek Villas|Winner in the Townhouses|hide\">Single Family|townhouses", ""));

			U.log("proptype: "+proptype);

			// ==================================================D-Property
			// Type======================================================
			String dtype = U.getdCommType((html + com + floorData + homeData).replaceAll("franchisee|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
					+ communityName);
			
			// ==============================================Property
			// Status=========================================================
	
			html = html.replace("Final Phase – Homesites 45 -98 Now Available", "Final Phase Homesites Now Available").replaceAll("\">Final Phase –|98 Now Available|amenity center coming soon|center is coming soon|Park that is coming soon|Sold Out</a>|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available")
					.replaceAll("Homesites \\d+ -\\d+ Now Available", "");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("\">Final Phase –|98 Now Available|Park that is coming soon|Coming soon, neuhouse", "");
			String pstatus = U.getPropStatus(html + com);
//			U.log(Util.matchAll(html + com , "[\\s\\w\\W]{30}final phase[\\s\\w\\W]{30}", 0));
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

//			int contract = 0;
//			for (String val : homeSec) {
//				if (val.contains("Under Contract</h3>"))//
//					contract++;
//			}
//			if(homeSec != null && homeSec.length>contract)
//				if(pstatus==ALLOW_BLANK)
//					pstatus = "Quick Move-In Homes";
//				else if(!pstatus.contains("Quick Move-In Homes")) 
//					pstatus += ", Quick Move-In Homes";
			
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon")
					.replace("Sold-out", "Sold Out");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
			
			if(comUrl.contains("https://uppereastriver.com/"))proptype+=", Courtyard Home, Homeowner Association";
			if(comUrl.contains("/new-homes/powder-springs-ga/kyle-farm/"))pstatus=pstatus+", Final Phase Homesites Now Available";
			if(comUrl.contains("https://uppereastriver.com/")) {
				//minPrice="$400,000";
				//minSqft="800";
				dtype="2 Story, 4 Story";}
			
			if(comUrl.contains("soleilbelmontpark")) {
				proptype=proptype.replace(", Townhouse", "");
			}

			// ------------------ No. of units ------------------------------------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			String totalUnits = ALLOW_BLANK;
			
			if(html.contains("Sitemap")) {
				
				String frameSec = U.getSectionValue(html, "Sitemap</h1>", "</iframe>");
				U.log("frameSec: "+frameSec);
				
				if(frameSec != null) {
					String frameUrl = U.getSectionValue(frameSec, "src=\"", "\"");
					U.log("frameUrl: "+frameUrl);
					
					String mapData = U.getHtml(frameUrl, driver);
					
//					if(mapData.contains("<text id=\"Txt_IL_150_HI_HI")) {
//						
//						ArrayList<String> pins = Util.matchAll(mapData, "<text id=\"Txt_IL_150_HI_HI", 0);
//						U.log("Count Pins: "+pins.size());
//						totalUnits = String.valueOf(pins.size());
//						units = totalUnits;
//					}
					
					if(mapData.contains("</tspan></text>")) {
						
						ArrayList<String> pins = Util.matchAll(mapData, "</tspan></text>", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
						units = totalUnits;
					}
				}
				
			}
			
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].replace(",", "").trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace(", Only Three Homes Remain", ""));
			data.addNotes(note);

		}
		j++;

	}

}