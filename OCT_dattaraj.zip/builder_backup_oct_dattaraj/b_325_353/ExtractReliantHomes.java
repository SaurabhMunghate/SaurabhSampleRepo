package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractReliantHomes extends AbstractScrapper{
	CommunityLogger LOGGER;
WebDriver driver=null;
	 int j = 0;

	public ExtractReliantHomes() throws Exception {

		super("Reliant Homes", "https://www.relianthomes.com/");
		LOGGER = new CommunityLogger("Reliant Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractReliantHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Reliant Homes.csv", u.data().printAll());
		
	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver=new FirefoxDriver();
		
//		driver = new ChromeDriver();
		
		String mainHtml=getHtml("https://www.relianthomes.com/communities", driver);
		String regUrls[]=U.getValues(mainHtml, "<div class=\"community-", "</community-card>");
		
		
		JsonParser jparser = new JsonParser();
		
		
		String communityUrl="https://api.mybuildercloud.com/api/v1/communities?where={%22published%22:true,%22builder%22:%22577750d4371e2f630a853b16%22}&max_results=9999";
        String commData= U.getHTML(communityUrl);
        
		JsonArray commJson = (JsonArray) jparser.parse(commData).getAsJsonObject().get("_items");
			U.log("commJson==="+commJson.size());
        
        String homeUrl="https://api.mybuildercloud.com/api/v1/homes?where={%22published%22:true,%22builder%22:%22577750d4371e2f630a853b16%22}&max_results=9999";
        String homeData= U.getHTML(homeUrl);
        
        JsonArray homeJson = (JsonArray) jparser.parse(homeData).getAsJsonObject().get("_items");
		U.log("homeJson==="+homeJson.size());
        
        String planUrl="https://api.mybuildercloud.com/api/v1/plans?where={%22published%22:true,%22builder%22:%22577750d4371e2f630a853b16%22}&max_results=9999";
        String planData= U.getHTML(planUrl);
        
        JsonArray planJson = (JsonArray) jparser.parse(planData).getAsJsonObject().get("_items");
		U.log("planJson==="+planJson.size());
		
		for(int i=0;i<commJson.size();i++)
			
		{
			String comm=commJson.get(i).toString();
			String sharedName=U.getSectionValue(comm, "\"sharedName\":\"", "\",");
			
			for(String regU:regUrls) {
				//U.log(regU);
				String commUrl="URL=https://www.relianthomes.com/"+U.getSectionValue(regU, "href=\"", "\"")+"=END";
				U.log("commUrl==="+commUrl);
				
				if(commUrl.contains(sharedName))
				{
					comm=commUrl+comm;
				}
				
//				regHtml+=getHtml(regUrl, driver);
				
			}
			
			
			addDetails2(comm, homeJson,planJson);
		}
		
		
        
//		U.log("comUrl==="+q);
		//	String comSections[]=U.getValues(regHtml, "\"comm-comm-item ng-scope ng-isolate-scope\"", "</community-card>");
//			String comSections[]=U.getValues(regHtml, "<li ng-if=\"community.name\" ", " </a><div class=\"fav-wrap\"");
//			U.log(comSections.length);
//			for(String comSec:comSections) {
//				
//				String comUrl="https://www.relianthomes.com"+U.getSectionValue(comSec, "href=\"", "\"");
//				U.log("comUrl==="+comUrl);

//				try {
//					addDetails(comUrl, comSec);
//				} catch (Exception e) {}
//			}
//		}
		//driver.quit();
		LOGGER.DisposeLogger();
		
	}
	
	
	
	public void addDetails2(String comm, JsonArray homeJson, JsonArray planJson) throws Exception 
	{
		
		
//		U.log("===============Count================="+j);
		String comUrl=U.getSectionValue(comm, "URL=", "=END").replace("//communities", "/communities");
		
		//==========================Single Run==================================
//		if(comUrl.contains("https://www.relianthomes.com/communities/winder/calgary-downs"))
		
		
//		if(j>=8)
		{
			U.log("\n===========count="+j+"===================\n");
			U.log("comUrl====="+comUrl);
			LOGGER.AddCommunityUrl(comUrl);
			U.log("comm====="+comm);
			String commDesc=U.getSectionValue(comm, "\"description\":\"", "\",");
			String commName=U.getSectionValue(comm, "\"sharedName\":\"", "\",").replace("-", " ");
			U.log("commName====="+commName);
			
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "True";
			
			String addSec=U.getSectionValue(comm, "\"address\":{\"@type\"", "},");
			if(addSec!=null) {
				add[0]=U.getSectionValue(addSec, "\"streetAddress\":\"", "\"");
				add[1]=U.getSectionValue(addSec, "\"addressLocality\":\"", "\"");
				add[2]=U.getSectionValue(addSec, "\"addressRegion\":\"", "\"");
				add[3]=U.getSectionValue(addSec, "\"postalCode\":\"", "\"");
			}
			U.log("Address====="+Arrays.toString(add));
			String latlngSec=U.getSectionValue(comm, "\"geoIndexed\":", "]");
//			U.log("Address====="+latlngSec);
			if(latlngSec!=null)
			{
				latlag[1]=Util.match(latlngSec, "-\\d+.\\d{3}\\d+");
				latlag[0]=Util.match(latlngSec, ",\\d+.\\d{3}\\d+").replace(",", "");
			}
//				
			U.log("latlng====="+Arrays.toString(latlag));
			
			int homeCount=0,planCount=0;
			String homeData=ALLOW_BLANK, homePriceSec=ALLOW_BLANK, homeSQFTSec=ALLOW_BLANK;
			String planData=ALLOW_BLANK, planPriceSec=ALLOW_BLANK, planSQFTSec=ALLOW_BLANK;
			
			int quickCount=0;
			String commID=U.getSectionValue(comm, "\"_id\":\"", "\"");
			
			U.log("commID==="+commID);
			for(JsonElement home:homeJson)
			{ 
				String homecommID=U.getSectionValue(home.toString(), "\"containedIn\":\"", "\"");
//				if(home.toString().contains(commID))
					if(homecommID.equals(commID))
				{
					if(!home.toString().contains("\"status\":\"Sold\"")
							&& !home.toString().contains(",\"construction_status\":\"Pending\""))
					{
					homeCount++;
//					U.log("home===="+home.toString());
					
					homeData+=home.toString();
					if(home.toString().contains("\"status\":\"Active\"") 
							
//							&& !home.toString().contains("\"status\":\"Under Construction\"")
							)
					{
						quickCount++;
						U.log("Found==="+home.toString());
					}
					if(!home.toString().contains("\"status\":\"Pending\""))
					homePriceSec+=U.getSectionValue(home.toString(), "],\"plan\":\"", "\"uniqueName\"")
					+U.getSectionValue(home.toString(), "\"description\":\"", "\",");
					homeSQFTSec+=U.getSectionValue(home.toString(), "],\"plan\":\"", "\"uniqueName\"");
					}
				}
				
			}
			
			for(JsonElement plan:planJson)
			{
				if(plan.toString().contains(commID))
				{
					if(plan.toString().contains("</iframe>"))
					{
					planCount++;
//					U.log("plan===="+plan.toString());
					planData+=plan;
					if(plan.toString().contains("1603 Jasper Drive"))
					{
						U.log("Found==="+plan.toString());
					}
					
					planPriceSec+=U.getSectionValue(plan.toString(), "],\"plan\":\"", "\"uniqueName\"")
							+U.getSectionValue(plan.toString(), "\"description\":\"", "\",");;
					planSQFTSec+=U.getSectionValue(plan.toString(), "],\"plan\":\"", "\"uniqueName\"");
				}
				}
				
			}
			
			U.log("planCount==="+planCount);
			U.log("homeCount==="+homeCount);
			
			U.log("planPriceSec==="+planPriceSec);
			U.log("homePriceSec==="+homePriceSec);
			
			U.log("quickCount==="+quickCount);
			
			//============================prices=============================
		      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		      
				
				prices=U.getPrices(comm+homePriceSec + planPriceSec, "\"priceLow\":\\d{6}|\"price\":\\d{6}", 0);
				String	minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				String	maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("PRICE:::::::"+Arrays.toString(prices));
				
//				U.log(Util.matchAll(comm, "[\\w\\s\\W]{30}498941[\\w\\s\\W]{30}",0));
//				U.log(Util.matchAll(planPriceSec, "[\\w\\s\\W]{30}498941[\\w\\s\\W]{30}",0));
//				U.log(Util.matchAll(homePriceSec, "[\\w\\s\\W]{30}498941[\\w\\s\\W]{30}",0));
				
				
				//============================sqft-========================================
				String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
							
				sqft=U.getSqareFeet(comm+homeSQFTSec + planSQFTSec, "\"sqftHigh\":\\d{4}|\"sqftLow\":\\d{4}|\"sqft\":\\d{4},", 0);
				String	minSqFt = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				String		maxSqFt = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQFT:::::::"+Arrays.toString(sqft));
				
				
				
				
				String cType=U.getCommType(comm).replace(",Country Club", ", Country Club")
						.replace(",Active Adult", ", Active Adult").replace(",Resort Style", ", Resort Style");
				
				

				
				U.log("cType===="+cType);
			
			
				String pType=ALLOW_BLANK;
				pType = U.getPropType((comm+planPriceSec+homePriceSec).replace("(Courtyard Java)", "")
						.replace("\"type\":\"Single Family\"", "")
						.replace("traditional ranch home", "Traditional Style house ranch home")); 
				U.log("pType::::::" + pType);
				// ============================dproptype=================================
				String dType = ALLOW_BLANK;
				

				
				if(planData!=null)
					planData = planData.replaceAll("</span> Stories", " Story");
				
				if(homeData!=null)
					homeData=homeData
							.replaceAll("</span> Stories", " Story")
					.replace("The split bedroom plan offers", "The split plan with over bedroom plan offers");
				
				if(planPriceSec!=null)
				{
					planPriceSec=planPriceSec.replace("\"stories\":1,", " 1 Story ");
				}
				
				
				if(homePriceSec!=null)
				{
					homePriceSec=homePriceSec.replace("\"stories\":1,", " 1 Story ")
							.replace("\"stories\":2,", " 2 Story ")
							.replace("\"stories\":1.5,", " 1.5 Story ")
							.replaceAll("1.5 Story 4 Bedroom", "1.5 Story")
							.replace("/2 Story Fam/", "");
				}
				
				dType = U.getdCommType(comm+planPriceSec+homePriceSec)
						
						.replace("The split bedroom plan offers", "The split plan with over bedroom plan offers")
						.replace(",2 Story",", 2 Story")
						.replace(",Ranch",", Ranch");
				
				
//				U.log(Util.matchAll(comm, "[\\w\\s\\W]{30}Story 4[\\w\\s\\W]{30}",0));
//				U.log(Util.matchAll(planPriceSec, "[\\w\\s\\W]{30}Story 4[\\w\\s\\W]{30}",0));
//				U.log(Util.matchAll(homePriceSec, "[\\w\\s\\W]{30}Story 4[\\w\\s\\W]{30}",0));


				U.log("dType::::::" + dType);

				// =======================propertyStatus===================================

				String pStatus = ALLOW_BLANK;

				pStatus = U.getPropStatus((comm).replace("== 'Coming Soon'", ""));
				
				U.log("status:::::::" + pStatus);
				//U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
				
				
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				
				String mapUrl=U.getSectionValue(comm, "\"zplaturl\":\"", "\"");
				U.log("mapUrl===="+mapUrl);
				if(mapUrl!=null) {
				units = getUnits(mapUrl, driver);
				}
				U.log("Total Units : "+units);
				
				
				
				if(commName.endsWith("estates"))
				{
					if(pType.length()>3)
					{
						pType+=", Estate-Style Homes";
					}
					else {
						pType="Estate-Style Homes";
					}
				}
				
				if(quickCount>0)
				{
					if(pStatus.length()>3)
						pStatus+=", Quick Move-In Homes";
					else
						pStatus="Quick Move-In Homes";
				}
		
				
				//------------adding data here-----------------------
				
				data.addCommunity(commName, comUrl, cType);
				data.addLatitudeLongitude(latlag[0], latlag[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
				data.addSquareFeet(minSqFt, maxSqFt);
				data.addPropertyType(pType, dType);
				data.addPropertyStatus(pStatus);
				data.addNotes(U.getnote(comm));
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
				
		}
		j++;
		
	}
	

	/*
	public void addDetails(String comUrl, String comSec) throws Exception {

		//U.log(comSec);
//	if(j>=6)
//		try
		{
		U.log("===============Count================="+j);
		U.log("comUrl: "+comUrl);
		
		//TODO:
//		if(!comUrl.contains("https://www.relianthomes.com/communities/monroe/clubside-estates"))return;
		
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String comHtml=getHtml(comUrl, driver);
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		//String comName=U.getSectionValue(comSec, "class=\"ng-binding ng-scope\" style=\"\">", "</li>");
		String comName=U.getSectionValue(comHtml, "<h1 class=\"ng-binding\">","</h1>");
				if(comUrl.contains("https://www.relianthomes.com/communities/monroe/belmont"))
				{
					comName="Belmont";
				}
				if(comUrl.contains("https://www.relianthomes.com/communities/loganville/bentley-farms"))
				{
					comName="Bentley Farms";
				}
				
				if(comUrl.contains("https://www.relianthomes.com/communities/winder/calgary-downs"))
				{
					comName="Calgary Downs";
				}
			if(comUrl.contains("https://www.relianthomes.com/communities/monroe/clubside-estates"))
				{
					comName="Clubside Estates";
				}
	
	if(comUrl.contains("https://www.relianthomes.com/communities/monroe/grand-haven-at-alcovy-mountain"))
		{
			comName="Grand Haven at Alcovy Mountain";
		}
	if(comUrl.contains("https://www.relianthomes.com/communities/monroe/reserve-at-flat-creek"))
	{
		comName="Reserve At Flat Creek";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/monroe/the-fields-at-alcovy-mountain"))
	{
		comName="The Fields at Alcovy Mountain";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/anderson/willow-haven-at-cobbs-glen"))
	{
		comName="Willow Haven at Cobb's Glen";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/hull/woodbury"))
	{
		comName="Woodbury";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/greenville/reedy-springs"))
	{
		comName="Reedy Springs";
	}
	if(comUrl.contains("https://www.relianthomes.com/communities/loganville/bullock-estates"))
	{
		comName="Bullock Estates";
	}
	
		U.log("comunityname=>"+comName);
		if(comUrl.contains("https://www.relianthomes.com//communities/anderson/axman-oaks"))comName="Axman Oaks";
		if(comUrl.contains("https://www.relianthomes.com//communities/greenville/reedy-springs"))comName="Reedy Springs";
		if(comUrl.contains("https://www.relianthomes.com//communities/anderson/willow-haven-at-cobbs-glen"))comName="Willow Haven at Cobbs Glen";
		
		//============================address section==============================================
		
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
//		String addressSec=U.getSectionValue(comHtml, "Location:", "</h4>");
//		U.log(addressSec);
//		add=U.getAddress(addressSec);
		U.log(U.getCache(comUrl));
		String latlagSec=U.getSectionValue(comHtml, "\"https://www.google.com/", "\"");
		
		
		U.log("comSec==="+comSec);
		String sec=U.getSectionValue(comSec, "class=\"small-text ng-binding ng-scope\" style=\"\">", "<");
		String add1[]=sec.split(",");
		
		U.log("add1==>"+Arrays.toString(add1));
		
		String addSec=U.getSectionValue(latlagSec, "place/", "/@");
		if(addSec!=null && add1.length==2)
		{
			addSec=addSec.replace(add1[0], ", "+add1[0])
					.replace(add1[1],  ", "+add1[1]);
			U.log("addSec==="+addSec);
			add=U.getAddress(addSec);
		}
		U.log("add==>"+Arrays.toString(add));

	//String latlagSec=U.getSectionValue(comHtml, "latitude", "longitude");
		U.log("lat===="+latlagSec);
		if(latlagSec != null) {
			latlag[0]=U.getSectionValue(latlagSec, "/@", ",");
			latlag[1]="-"+U.getSectionValue(latlagSec, ",-", ",");
		}
			
		
		if(latlag[0]==null)
		{
			latlag[0]=	U.getSectionValue(comHtml, "latitude\":", "\"");
			latlag[1]=U.getSectionValue(comHtml, "longitude\":", "\"");
		}
		if(comName.equals("Individual Home Sites") || comName.equals("Reserve At Flat Creek") || comName.equals("Calgary Downs")) {

			latlag[0]=	U.getSectionValue(comHtml, "\"latitude\": \"", "\"");
			latlag[1]=U.getSectionValue(comHtml, "\"longitude\": \"", "\"");
		}
		
		if(add[0]==ALLOW_BLANK || add[0]==null)
		{
		
		try{
		add=U.getAddressGoogleApi(latlag);
		}
		catch(Exception e){
			
			add=U.getAddressHereApi(latlag);
		}
		geo="TRUE";
		}
		
		if(add[0]!=null || add[1]!=null || add[2]!=null  &&  add[3]==null)
		{
			U.log("UUUUUUUUUUUUU");
			add[3]=U.getAddressGoogleApi(latlag)[3];
			geo="TRUE";
		}
		
		
		U.log(Arrays.toString(add));
		U.log("latlong==>"+Arrays.toString(latlag));
		U.log(geo);
		
		
		String[] floorSec = U.getValues(comHtml, "<plan-card plan=\"plan\"", "</plan-card> </div>");
		
		String floorData = ALLOW_BLANK;
		
		if(!comHtml.contains("class=\"home-tile col-lg-3 ng-scope ng-hide\""))
		for(String plan : floorSec) {
			
			plan = U.getSectionValue(plan, "href=\"", "\"");
			U.log("Plan: "+plan);
			String pHtml = U.getHtml("https://www.relianthomes.com"+plan, driver);
//			Thread.sleep(10000);
			floorData = floorData + U.getSectionValue(pHtml, "<section class=\"homm-det-header", "</section>")+
					U.getSectionValue(pHtml, " id=\"description\"> ", "</section>");
		}
		
		String homeHtml = null;
		String[] planUrls = U.getValues(comHtml, "<div class=\"home-image\"> <a href=\"", "\"");
		U.log("planUrls.length: "+planUrls.length);
		
		
		
		for(String planUrl : planUrls){
			//
			U.log("planUrl -->"+"https://www.relianthomes.com"+planUrl);
			String planHTML=U.getHtml("https://www.relianthomes.com"+planUrl, driver);
//			Thread.sleep(10000);
			homeHtml += U.getSectionValue(planHTML, "<section class=\"homm-det-header", "</section>")+
					U.getSectionValue(planHTML, "<h4>Property <span>Description</span></h4>", "<h3 class=\"home-list-title\">Other Homes in this Community</h3>");;
			
//					if(homeHtml.contains("559,285"))
//					{
//						U.log("FOUND");
//					}
			//homeHtml += U.getHtml("https://www.relianthomes.com"+planUrl, driver);
					
					
					
		}
//		U.log(Util.matchAll(floorData, ".*loft.*", 0));
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			prices=U.getPrices(comHtml+comSec + homeHtml, "\\$\\d{3},\\d{3}", 0);
			
			U.log(Arrays.toString(prices));
//			U.log(Util.matchAll(comHtml ,"[\\w\\s\\W]{500}559,285[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll(homeHtml, "[\\w\\s\\W]{30}559,285[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll(comSec, "[\\w\\s\\W]{30}559,285[\\w\\s\\W]{30}",0));

			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			if(comHtml.contains("class=\"home-tile col-lg-3 ng-scope ng-hide\""))
				comHtml = comHtml.replaceAll("\\d,\\d+ SQ FT</span>", "");
			
			sqft=U.getSqareFeet(comHtml+comSec, "\\d{1},\\d{3} - \\d{1},\\d{3}|\\d{1},\\d{3} SQ", 0);
			
			U.log(Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comHtml).replace(",Country Club", ", Country Club")
					.replace(",Active Adult", ", Active Adult").replace(",Resort Style", ", Resort Style");
			U.log(cType);
//			String homeUrl=ALLOW_BLANK;
//			String homeData=ALLOW_BLANK;
//			String[] homeSecUrls=U.getValues(comHtml,"<div class=\"home-image\">", "<div class=\"home-content\">");
//			for(String homeUrlSec: homeSecUrls) {
//				homeUrl=U.getSectionValue(homeUrlSec, "<a href=\"", "\"");
//				homeData=homeData+U.getHTML("")
//				
//			}
				
			String pType=ALLOW_BLANK;
			pType = U.getPropType(comHtml+homeHtml+floorData); 

			U.log("pType::::::" + pType);
//			U.log(Util.matchAll(comHtml+homeHtml, "[\\w\\s\\W]{30}loft[\\w\\s\\W]{30}",0));
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			

			
			if(floorData!=null)
				floorData = floorData.replaceAll("</span> Stories", " Story");
			
			if(homeHtml!=null)
				homeHtml=homeHtml
						.replaceAll("</span> Stories", " Story")
				.replace("The split bedroom plan offers", "The split plan with over bedroom plan offers");
			
			
			dType = U.getdCommType(comHtml+floorData+homeHtml)
					.replace("The split bedroom plan offers", "The split plan with over bedroom plan offers")
					.replace(",2 Story",", 2 Story")
					.replace(",Ranch",", Ranch");
			U.log("dType::::::" + dType);
//			U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}split[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll(homeHtml, "[\\w\\s\\W]{30}stories[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll(floorData, "[\\w\\s\\W]{30}split[\\w\\s\\W]{30}",0));

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;

			pStatus = U.getPropStatus((comHtml).replace("== 'Coming Soon'", ""));
			//U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			
			if(comUrl.contains("https://www.relianthomes.com/communities/winder/sims-crossing")) {
				dType="2 Story, 1.5 Story";
			}
			if(comUrl.contains("https://www.relianthomes.com//communities/bethlehem/berry-springs"))sqft[0]="2,300";
			if(comUrl.contains("https://www.relianthomes.com//communities/winder/calgary-down"))dType="2 Story, 1 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/winder/sims-crossing"))dType="2 Story, 1 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/monroe/grand-haven-at-alcovy-mountain"))dType+=", 2 Story, 1 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/anderson/axman-oaks"))dType="2 Story";
			if(comUrl.contains("https://www.relianthomes.com//communities/loganville/fairwinds")) {
				prices[1]="$379,900";
				sqft[1]="3300";
			}
			if(comUrl.contains("https://www.relianthomes.com//communities/monroe/belmont"))add[0]="70 Bella Dr";
			

			if(comUrl.contains("https://www.relianthomes.com//communities/winder/sims-crossing"))sqft[1]="2938";
			
			if(comUrl.contains("https://www.relianthomes.com/communities/monroe/clubside-estates"))dType="2 Story";
			if(comUrl.contains("https://www.relianthomes.com/communities/monroe/grand-haven-at-alcovy-mountain"))
				{
				dType="Split Level, Ranch, 1 Story";
				pType="Patio Homes, Traditional Homes";
				}
			
			
			
			
			if(comUrl.contains("https://www.relianthomes.com/communities/loganville/bentley-farms"))pType="Loft";
			if(comUrl.contains("https://www.relianthomes.com/communities/winder/calgary-downs"))pType="Loft";
			if(comUrl.contains("https://www.relianthomes.com/communities/hull/woodbury"))pType="Loft";
		
			
			
			data.addCommunity(comName, comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(comHtml));
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
		
		
		
		
		}
//			catch(Exception e) {}
		j++;
		
	}
	
	
	*/
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(12000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					int i=0;
					
					try{
						if(driver.getPageSource().contains("AVAILABLE HOMES") ) {
							driver.findElement(By.xpath("//*[@id=\"homes\"]/div/div[1]/ul/li[1]/a[1]")).click();
							U.log("click ------>  AVAILABLE HOMES");
							Thread.sleep(4000);
							html += driver.getPageSource();
							
						}
					}catch(Exception e){
						U.log("Not Click on  --> AVAILABLE HOMES");
					}
					try{
						if (driver.getPageSource().contains("UNDER CONTRACT")){
							U.log("click ------>  UNDER CONTRACT");
	
							driver.findElement(By.xpath("//*[@id=\"homes\"]/div/div[1]/ul/li[2]/a[1]")).click();
							Thread.sleep(4000);
							html += driver.getPageSource();
						}			
					}catch(Exception e){
						U.log("Not Click on  --> AVAILABLE HOMES");
					}
					try{
						if(driver.getPageSource().contains("FLOOR PLANS")) {
							U.log("click ------> FLOOR PLANS");
	
							driver.findElement(By.xpath("//*[@id=\"homes\"]/div/div[1]/ul/li[3]/a[1]")).click();
							Thread.sleep(1000);
							html += driver.getPageSource();
						}
					}catch(Exception e){
						U.log("Not Click on  --> FLOOR PLANS");
					}
/*					String urlsplitted[]=url.split("/");
					U.log(urlsplitted.length);
					if(urlsplitted.length==7) {
						

						
							html += driver.getPageSource();
					}
					else {
					
					}
*/
					html += driver.getPageSource();
					
					Thread.sleep(3000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	
	public static String getUnits(String mapUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK;  
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
//		if(comHtml.contains("src=\"https://www.mybuildercloud.com")) {
//			
//			
//			frameUrl = U.getSectionValue(comHtml, "src=\"https://www.mybuildercloud.com", "\""); 
//			frameUrl = "https://www.mybuildercloud.com" + frameUrl;
//			U.log("frameUrl: "+frameUrl);
//			
//			if(frameUrl.contains("PlatMaps")) {
				
				mapData = U.getHtml(mapUrl, driver);
				U.log(U.getCache(mapUrl));
				
				if(mapData.contains("<path class=\"leaflet-interactive")) {
					
					ArrayList<String> pins = Util.matchAll(mapData, "leaflet-interactive home statu", 0);
					U.log("Count Pins: "+pins.size());
					totalUnits = String.valueOf(pins.size());
				}
		
		return totalUnits;
	}	
}