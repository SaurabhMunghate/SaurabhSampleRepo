package com.shatam.b_325_353;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSmithbiltHomes extends AbstractScrapper {
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver = null;

	public ExtractSmithbiltHomes() throws Exception {

		super("Smithbilt Homes", "https://smithbilthomes.com/");
		LOGGER = new CommunityLogger("Smithbilt Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractSmithbiltHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Smithbilt Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		String mainHtml = U.getHTML("https://smithbilthomes.com/community/");
		

		String comSections[] = U.getValues(mainHtml, "<a href=\"https://smithbilthomes.com/community",
				"</li></ul>");
		 U.log(comSections.length);
		for (String comSec : comSections) {
			addDetails(comSec);
		}
	//	try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comSec) throws Exception {

		U.log("====================" + j);

//		 U.log("comSec"+comSec);
		String comUrl = "https://smithbilthomes.com/community/" + U.getSectionValue(comSec, "/", "/\">");
		U.log(comUrl);
		//LOGGER.AddCommunityUrl(comUrl);
		
		///=====single run======
//		 if(!comUrl.contains("https://smithbilthomes.com/community/the-preserve")) return;
	
		 
		 if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		
		String comHtml = U.getHTML(comUrl);
		//String comHtml =U.getHtml(comUrl, driver);

		String comName = U.getSectionValue(comHtml, "<h3>", "</h3>");
	//	String comName=U.getSectionValue(comSec, "<title>", "</title>");
		
		U.log(comName);

		// U.log(comSec);
		// =================================address======================================================

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";

		String latlagSec = U.getSectionValue(comHtml, "https://www.google.com/maps/", "'").replace(", -", ",-");
		U.log(latlagSec);

		
		latlag[0] = U.getSectionValue(latlagSec, "q=", ",");
		latlag[1] = "-"+U.getSectionValue(latlagSec, ",-", "&");
		
		String mapHtml=ALLOW_BLANK;
		String addSec1=U.getSectionValue(comHtml, "iframe height='390' width='600'","allowfullscreen></iframe>");
		String mapUrl=U.getSectionValue(addSec1, "src='","'");
		U.log("mapUrl: "+mapUrl);
		
		
		if(mapUrl!=null)
		  mapHtml=U.getHTML(mapUrl);
		U.log("MAPURL: "+U.getCache(mapUrl));	
		
			if(mapHtml!=null) {
				
				mapHtml = U.getPageSource(mapUrl);
				
			}
			
//			U.log(U.getCache("https://www.google.com/maps/embed/v1/place?key=AIzaSyA92nN-N1WdLJaOq0HpR5NTlkbOkZjLZOo&q=36.058259,%20-83.881338&maptype=satellite"));	
		
//		  U.log("mapHtml"+mapHtml);
        if(mapHtml!=null) {
        	
        	U.log("HELLO");
        	String addSec2=U.getSectionValue(mapHtml,"function onEmbedLoad() {","]]);");
        	addSec2=addSec2.replace("null,","");
        	//U.log(addSec2);
        //	addSec2=addSec2.replace(oldChar, newChar)
        	String addSec3=U.getSectionValue(addSec2, "\"],\"",",[1],");
            U.log("addSec3:: "+addSec3);
        	//String addSec=U.getSectionValue(addSec3, "[\""+latlag[0]+", "+latlag[1]+"\"]","\"");
            String addSec=U.getSectionValue(addSec3,"\"],\"", ", USA\"");
            
            U.log("addSec ============  "+addSec);
            
            if(addSec == null) addSec = U.getSectionValue(addSec3,"\"],\"", "\"");
            U.log("addSec Here ============  "+addSec);
            
            add=U.getAddress(addSec);
        }
        
		U.log("LALONG::  "+Arrays.toString(latlag));
//		add = U.getAddressGoogleApi(latlag);
//		geo = "TRUE";

        if(add[0]==ALLOW_BLANK||add[0]==null) {
        	add = U.getAddressGoogleApi(latlag);
    		geo = "TRUE";
        }
        
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log(geo);

		// =======================================floors==================================================

		String communityFLoorNames = U.getSectionValue(comHtml, "Floor Plan Series: </span>", "</p>");
		String floorData = "";
		String Names[] = null;
		U.log("::::::floornames::::"+communityFLoorNames);
			Names = U.getValues(communityFLoorNames, "/'>", "</a>");

			if(Names.length==0 && communityFLoorNames.contains("href"))Names = U.getValues(communityFLoorNames, "'>", "</a>");
			U.log(Arrays.toString(Names));
			String floorName = "";
			
			String seriesData = ALLOW_BLANK;

			// =========================imperial series
			String imperialData = "Square Footage Range: 1,718 � 2,102,Starting in the upper $200,000 ,Imperial";

			// =========================FOUNDER SERIES
			String founderData = "Square Footage Range: 2,083 � 2,910,Starting in the upper $300,000 ,Founders";

			// =========================SIGNATURE SERIES
			String signatureData = "Square Footage Range: 2,100 � 2,700,Starting in the upper $300,000 ,Signature";

			// =========================CRAFTSMAN SERIES
			String craftsmanData = "Square Footage Range: 1,823 � 4,000, The Craftsman series features Traditional floor plans,Starting in the upper $300,000 ,Craftsman";
			
			String[] floorDetails = { imperialData, founderData, signatureData, craftsmanData };

			for (String na : Names) {
				U.log("========"+na);
				
				for (String f : floorDetails) {
					U.log("f here ========"+f);
					
					if (f.contains(","+na)) {
						seriesData += f;
					}
				}
			}
			
			U.log("seriesData ---------- "+seriesData);
		
			String floorPlanData[] = U.getValues(communityFLoorNames, "<a href='", "'");
			U.log(floorPlanData.length);
			for(String floor:floorPlanData) {
				U.log(floor);
				floorData+=U.getHTML(floor);
			}
		
      //     floorData=floorData.replace("Signature and Traditional floor plans with a \"craftsman\" twist","");
			
			String remJsn[]=U.getValues(floorData, "{\"@context\":","</script>");
			for(String rem:remJsn) {
				floorData=floorData.replace(rem, "");
			}
		//	floorData=floorData.replace(remJsn, "");
		// ============================prices=============================
		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };

		floorData = floorData.replace("0s", "0,000");
		prices = U.getPrices(comHtml + comSec + floorData  + seriesData, "Starting Price: </span>\\$\\d{3},\\d{3}|Starting in the upper \\$\\d{3},\\d{3}", 0);
//		U.log(Util.matchAll(floorData, "[\\w\\s\\W]{30}now open[\\w\\s\\W]{30}", 0));

		U.log(Arrays.toString(prices));
		
		// ============================sqft-========================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };

		comHtml = comHtml.replaceAll("content=\".*\"|\"description\":\".*\"", "");
		floorData = floorData.replaceAll("content=\".*\"", "");
		sqft = U.getSqareFeet(floorData+comHtml, "Square Footage Range: \\d{1},\\d{3} � \\d{1},\\d{3}|Square Feet: \\d{1},\\d{3}|Footage Range: \\d{1},\\d{3} � \\d{1},\\d{3}|\\d,\\d{3} sqft.", 0);

		U.log(Arrays.toString(sqft));

		String cType = U.getCommType(comHtml);
		U.log(cType);

		String pType = ALLOW_BLANK;
		
		pType = U.getPropType((comHtml+floorData+communityFLoorNames).replace("estate-size lots", "Estate Residences").replace("craftsman-homes'>Craftsman<", "Craftsman style details").replace(" Plan Series: </span>Traditional", "Traditional exterior").replace("hoa@", ""));
		
//		U.log(":::::::::::::"+Util.matchAll(floorData, "[\\w\\s\\W]{100}Traditional[\\w\\s\\W]{100}", 0));
		U.log("pType::::::" + pType);
		// ============================dproptype=================================
		String dType = ALLOW_BLANK;

		dType = U.getdCommType((comHtml));
//				
		U.log("dType::::::" + dType);

		// =======================propertyStatus===================================

		String pStatus = ALLOW_BLANK;

		pStatus = U.getPropStatus((comHtml).replace("phase 2 and is NOW OPEN", "phase 2 NOW OPEN").replaceAll("now open For more information contact|Inventory FYI: NOW OPEN|NOW OPEN For more information contact|mes.com/move-in-ready/|<span>Move-In Ready</span>", ""));
//		U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}now open[\\w\\s\\W]{30}", 0));
		U.log("status:::::::" + pStatus);
		pStatus=pStatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon");
		
		
		//=================siteMap==============
		int lotCount=0;
		String noOfUnits=ALLOW_BLANK;
		int temp=0;
		int exactnum=0;
		if(comHtml.contains("Interactive Sales Map")) {
		//	U.log("Hello");
			String saleMapUrlSec=U.getSectionValue(comHtml, "<h5>Interactive Sales Map</h5><iframe", "</iframe>");
			//U.log("saleMapUrlSec= "+saleMapUrlSec);
			String siteMapUrl=U.getSectionValue(saleMapUrlSec, "src='", "'>");
			U.log("siteMapUrl:: "+siteMapUrl);
			String siteMapHtml=U.getHTML(siteMapUrl);
			U.log("siteMapUrlCache:: "+U.getCache(siteMapUrl));
	    	String lotData[]=U.getValues(siteMapHtml, "shape=\"poly\"", ">");
	    	
	    	for(String lotD:lotData) {
	    		if(lotD.contains("title=\"Lots")) {
	    			temp++;
	    			String rangeSec=U.getSectionValue(lotD, "title=\"Lots ", "\"");
	    			
	    			if(rangeSec.contains("and")&& rangeSec.contains("-")) {
	    				String mRange[]=rangeSec.split("and");
	    				String[] lowRange=mRange[0].split("-");
	    				String[] uprRange=mRange[1].split("-");
	    				int lower1=Integer.parseInt(lowRange[0].trim());
		    			int upper1=Integer.parseInt(lowRange[1].trim());
		    			exactnum+=Math.abs(upper1-lower1);
		    			
		    			int lower2=Integer.parseInt(uprRange[0].trim());
		    			int upper2=Integer.parseInt(uprRange[1].trim());
		    			exactnum+=Math.abs(upper2-lower2);
	    				
	    			}
	    			if(rangeSec.contains("and") && !rangeSec.contains("-") ) {
	    			//	U.log("hhhh");
	    				String [] range=rangeSec.split("and");
		    			int lower=Integer.parseInt(range[0].trim());
		    			int upper=Integer.parseInt(range[1].trim());
		    			exactnum+=Math.abs(upper-lower);
	    			}
	    			
	    			if(rangeSec.contains("-")&& !rangeSec.contains("and")) {
	    			//	U.log("MMM");
	    			String [] range=rangeSec.split("-");
	    			int lower=Integer.parseInt(range[0].trim());
	    			int upper=Integer.parseInt(range[1].trim());
	    			exactnum+=Math.abs(upper-lower);
	    			}
	    			
	    			
	    		}
	    	}
//			
			lotCount=lotData.length-temp+exactnum;
			noOfUnits=Integer.toString(lotCount);
			
			//String lotSec=U.getSectionValue(siteMapHtml, "alt=\"Lot", "\"");
			
			
		}
		if(noOfUnits.equals("0"))
			noOfUnits=ALLOW_BLANK;
		
		U.log("No Of Units:: "+noOfUnits);

		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;
		
		//----------------------------------------------------------------------------------------
	
		data.addCommunity(comName, comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(U.getnote(comHtml));
        data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
        data.addUnitCount(noOfUnits);
		j++;

	}
}