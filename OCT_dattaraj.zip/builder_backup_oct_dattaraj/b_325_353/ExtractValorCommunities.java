package com.shatam.b_325_353;
import java.util.Arrays;

/**
 * @author MJS
 * @date 30/03/2021 
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractValorCommunities extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.valorcommunities.com";

	public ExtractValorCommunities() throws Exception {
		super("Valor Communities", builderUrl);
		LOGGER = new CommunityLogger("Valor Communities");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractValorCommunities();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Valor Communities.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		String html = U.getHtml("https://www.valorcommunities.com/new-homes-in-birmingham/",driver)
				+ U.getHtml("https://www.valorcommunities.com/new-homes-in-huntsville/",driver);
		String[] mainSec = U.getValues(html, "<div class=\"wpgmp_locations\"", "View Homes</span></a>");
		U.log(mainSec.length);
		for(String data : mainSec)
		{
			String comUrl = U.getSectionValue(data, "title=\"View Homes\" href=\"", "\"");
			U.log("comUrl ::"+comUrl);
			getDetail(comUrl, data);
			
		}
		
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("https://www.valorcommunities.com/new-homes-in-huntsville/anslee-farms-the-estates/"))return;
//		if(!comUrl.contains("https://www.valorcommunities.com/new-homes-in-huntsville/windermere-coming-soon/")) return;
//		if(j>=4)
		U.log("Count: " + j + "\t" + comUrl);
//	try
	{
			
//			U.log(com);
			if(comUrl.contains("https://www.valorcommunities.com/new-homes-in-huntsville/windemere-coming-soon/")){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Page Not Found");
				return;
			}
			if(comUrl.contains("/new-homes-in-birmingham/carroll-cove-2021/")) {
				LOGGER.AddCommunityUrl("Returned======== " + comUrl);
				return;
			}
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			String html = U.getHtml(comUrl, driver);
			
			String remove = U.getSectionValue(html, "<header class=\"fusion-header-wrapper\">", "</header>");
			if(remove!=null)
				html = html.replace(remove, "");
			//==================Unit Count==========
	        String counting=ALLOW_BLANK;
	        String startDt=ALLOW_BLANK;
	        String endDt=ALLOW_BLANK;
	        int lotCount=0;
	       String[] mapdata=null;
	        String noOfUnits=ALLOW_BLANK;
			
	        if(html.contains("Community Map")) {
	        	U.log("hello mm");
//	        	 noOfUnits=getUnits(html);
	        	mapdata=getUnits(html);
	        	 
	        }	
//	        for(String l :mapdata) {
////		        U.log("data ::"+l);
//
//	        }
	        noOfUnits=mapdata[0];
	        String mapPrice=mapdata[1];
	 /*       String siteMapPart=U.getSectionValue(html, "<iframe class=", "</iframe>");
//	        U.log("siteMapPart ::"+siteMapPart);
	        if(siteMapPart==null) {
	        	 siteMapPart=U.getSectionValue(html, "<iframe id=\"frame_comm_filing\"", "</iframe>");	
	        }
	        String lotUrl=U.getSectionValue(siteMapPart, "src=\"", "\"");
	        U.log("lotUrl== "+lotUrl);
	        String lotHtml=U.getHtml(lotUrl, driver);
	        U.log("MMMM"+U.getCache(lotUrl));
//	        //String lotPart=U.getSectionValue(lotHtml, "id=\"pw-lots", "</svg>");
//	        String[] lotSection=U.getValues(lotHtml, "<g id=\"", "</g>");
//	        lotCount=lotSection.length;
//	        noOfUnits=Integer.toString(lotCount);
//	        
	\*/      // int lotCount=0;

	/*        String[] lotData=U.getValues(lotHtml, "<div class=\"legend_data\">", ")</span>");
	        for(String lots:lotData) {
	        	String lot2=U.getNoHtml(lots);
	        	U.log(lot2);
	        	String num=Util.match(lot2, "\\d+");
	        	lotCount+=Integer.parseInt(num);
	        	
	        }*/
	        
//	        noOfUnits=Integer.toString(lotCount);	
//			if(noOfUnits.equals("0"))
//				noOfUnits=ALLOW_BLANK;
			U.log("Number of Units"+noOfUnits);
			// ============================================Community
			// name=======================================================================
			html=html.replace("other common areas such", "");
			com = com.replaceAll("class=\"place_title\" data-zoom=\"\\d+\" data-marker=\"\\d+\">", "class=\"place_title>");
		
			String communityName = U.getSectionValue(com, "javascript:void(0);\" class=\"place_title>", "<");
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'").replaceAll("-now Selling New Phase|\\{sold Out \\� |\\{sold Out –|\\}|: Coming Soon|:coming Soon", "").replace("�", "");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			
			String addlatSec= U.getSectionValue(html, "href=\"https://www.google.com/maps/dir/", "\" style=");
			if(addlatSec==null) {
				addlatSec=U.getSectionValue(html, "href=\"https://www.google.com/maps/place", "\" style=");
			}
			U.log("addlatSec---->" + addlatSec);
			if(addlatSec!=null) {
			String addSec= U.getSectionValue(addlatSec, "/", "/");
			
			if(addSec!=null) {
				addSec=addSec.replace("%7C+", "").replace("+", " ").replace("Valor Communities Carrol Cove ", "");
				addSec=addSec.replace(" New Market", ", New Market").replace(" Madison", ", Madison").replace(" Huntsville", ", Huntsville").replace(" Alabaster", ", Alabaster").replace(" Hueytown", ", Hueytown").replace(" Warrior", ", Warrior").replace("McCalla", ", McCalla").replace(" Springville", ", Springville");
				U.log("addSec---->" + addSec);
				add=U.getAddress(addSec);
			}
			String latlngSec= U.getSectionValue(addlatSec, "@", "/");
			
			if(latlngSec!=null) {
			U.log("latlngSec---->" + latlngSec);
			latLng=latlngSec.split(",");
			latLng[1]=latLng[1].replaceAll(", 15z|, 16z|, 18z|, 17z", "");
			U.log("latLng---->" + Arrays.toString(latLng));		
			}
			}
			
//			String addSec = U.getSectionValue(html, "<div class=\"communityAddress \">", "</div>");
//			
//			if (addSec != null) {
//				
//				add[0] = U.getSectionValue(addSec, "<span class=\"addressStreet\">", "<").trim();
//				add[1] = U.getSectionValue(addSec, "<span class=\"addressCity\">", "<").trim();
//				add[2] = U.getSectionValue(addSec, "<span class=\"addressState\">", "<").trim();
//				add[3] = U.getSectionValue(addSec, "<span class=\"addressZipCode\">", "<").trim();
//				
//			}
//			 addSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "/data");
//			U.log("11===="+ addSec);
//			if(addSec!=null && !addSec.contains("/@")) {
//				addSec = addSec.replace("+", " ");
//				add = U.getAddress(addSec);
//			}
//			if(addSec!=null && addSec.contains("/@")) {
//				addSec = Util.match(addSec, ".*/@");
//				addSec = addSec.replace("+", " ").replace("/@", "");
//				add = U.getAddress(addSec);
//			}
//			
//			if(addSec==null) {
//				
//			}
			add[0]=add[0].replace("Valor Communities ", "");
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
//			String latSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");
//			if(latSec!=null) {
//				U.log("Sec::::"+latSec);
//			}
//			if(latSec!=null && latSec.contains("@")) {
//				
//				U.log(latSec);
//				try {
//				latSec = Util.match(latSec, "\\d+\\.\\d+,-\\d+\\.\\d+");
//				latLng = latSec.split(",");
//				}
//				catch(Exception e){
//					
//					addSec = Util.match(latSec, ".*/");
//					if(latSec!=null) {
//						addSec = addSec.replace("+", " ");
//						add = U.getAddress(addSec);
//					}
//				}
//				
//			}
//			else {
//				
//				addSec = U.getSectionValue(com, "<span style=\"listing-location;\">", "<");
//				
//				String[] add1 = addSec.split(",");
//				add[0] = ALLOW_BLANK;
//				add[1] = add1[0];
//				add[2] = add1[1];
//				add[3] = ALLOW_BLANK;
//				
//				latLng = U.getlatlongGoogleApi(add);
//				if(latLng!=null)
//					add = U.getAddressGoogleApi(latLng);
//				
//				geo = "TRUE";
//			}
					
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			
			//========== Move In Homes ==================================================
			String[] movSec = U.getValues(html, "<div class=\"row ihf-result\"", "<div class=\"ihf-results-listingnum hidden-xs\">");
			U.log("movSec :::"+movSec.length);
			String moveData = ALLOW_BLANK;
			for(String data : movSec){
				
				U.log(data);
					String url = U.getSectionValue(data, "<a href=\"", "\"");
					
					String mhtml = U.getSectionValue(U.getHtml(url,driver), "<main id=\"main\" class=\"clearfix \">", "</main>");
					moveData += mhtml;
				}
			
			//========== Move In Homes ==================================================
			String[] floorSec= {};
			String floorData = ALLOW_BLANK;
			html=html.replace("<em>SOLD OUT&nbsp;</em>", "<em>SOLD OUT</em>");
//			if(!comUrl.contains("/new-homes-in-birmingham/briar-ridge/")||!comUrl.contains("/new-homes-in-birmingham/carrington-lakes-enclave/")) {
			//!html.contains("<em>SOLD OUT&nbsp;</em>")||
			if(!html.contains("<em>SOLD OUT</em>")) {
				floorSec = U.getValues(html, "<div class=\"fusion-layout-column", "View Tour</a>");
//				U.log(Arrays.toString(floorSec));
				if(floorSec!=null) {
					for (String data : floorSec) {
						floorData += data;
					}
				}
			}
//			}
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			if(mapPrice!=null)
				mapPrice=mapPrice.replace("$(\"#dialog_toolltip #sales_price\").html('", "price:  ");
			
//			U.log("mapPrice===="+mapPrice);


			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("High 400,000", "High $400,000")
					.replace("</strong>   &#36;", " $")
					.replace("New homes from the High 500s", "New homes from the High 500,000");
			com = com.replaceAll("0&#8217;s|0s|0's|0s", "0,000");
			html=html.replaceAll("New homes from the <span style=\"font-size: 32px;\">(\\$\\d{3},\\d{3})", "New homes from the $1");
			html = html.replace("0s", "0,000").replaceAll("Homes over \\d+ SF: \\d+ gallon electric hybrid water heater|Homes under \\d+ SF: \\d+ gallon gas water heater|Homes over \\d+ SF: \\d+-gallon electric hybrid water heater|Homes under \\d+ SF: \\d+-gallon gas water heater", "")
					.replace("New homes from the <span style=\"font-size: 32px;\">$370,000","New homes from the $370,000")
					.replace("New homes from the <span style=\"font-size: 32px;\">$380,000","New homes from the $380,000");
			
			String prices[] = U.getPrices(com + html + moveData + floorData+mapPrice, "<span>\\$\\d{3},\\d{3}|price:  \\$\\d{3},\\d{3}|New homes from the High \\d+,\\d+|price from the \\$\\d{3},\\d{3}|Starting from the \\$\\d{3},\\d{3}|Starting from the \\d{3},\\d{3}|<span class=\"ihf-for-sale-price\"> \\$\\d{3},\\d{3} </span>|from the low \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log(">>>>>"+Util.matchAll(html+com, "[\\w\\s\\W]{30}New homes from the[\\w\\s\\W]{80}",0));
			// ======================================================Sq.ft===========================================================================================
		
			if(moveData!=null)
				moveData = moveData.replaceAll("<div class=\"label\">Square Feet</div>\n\\s*<div class=\"value\">", "Square Feet");
			String[] sqft = U.getSqareFeet((com + html + floorData).replaceAll("master suites offer up to \\d+ square feet", ""),//+ moveData 
					
					"Sq\\. Ft\\.: \\d,\\d{3}|<strong> \\d,\\d{3} </strong>|to \\d,\\d{3} square feet|<br>\\d+ square feet<br>|\\d{4} square feet",0);//\\d,\\d{3} to \\d,\\d{3} SQ FT
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			U.log("mm"+Util.matchAll(html + com + floorData, "[\\w\\s\\W]{30}5,500[\\w\\s\\W]{30}", 0));
//			U.log("mm"+Util.matchAll(moveData, "[\\w\\s\\W]{30}5,500[\\w\\s\\W]{30}", 0));
			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================
			html = html.replace("Our luxurious Carroll Cove new home community offers a variety", "Our luxury style Carroll Cove new home community offers a variety");
			String proptype = U.getPropType((html + com + moveData));
			U.log("proptype: "+proptype);
			// ==================================================D-Property
			// Type======================================================
			if(moveData!=null)
				moveData = moveData.replaceAll("<div class=\"label\">Stories</div>\n\\s*<div class=\"value\">", "Story");
			html=html.replace("Level 2 Trim Series", "2 story").replaceAll("1.5 &amp; 2 story", "1.5 & 2 story");
			String dtype = U.getdCommType((html + com + moveData).replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName);
			
			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("</a>\\(Coming Soon\\)<br>|</a>\\(Coming Soon\\)<br />|</a> \\(Coming Soon\\)</p>|<p><b>Coming Soon</b></p>|coming-soon/\" class=\"fusion-bar-highlight\"><span>Windermere : Coming Soon|Financing Available\\.\"|[M|m]ove-[I|i]n|-coming-soon/\"|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			
			String pstatus = U.getPropStatus((html + com).replaceAll("Windermere: Coming Soon|title=\"Sold Out Communities|<span>Sold Out Communities</span>|"
					+ "title=\"Quick Move In Homes|>Quick Move In</span><", ""));
			
			U.log("pstatus: "+pstatus);
//			U.log("mm"+Util.matchAll(html + com, "[\\w\\s\\W]{30}Sold Out[\\w\\s\\W]{30}", 0));
//			U.log("mm"+Util.matchAll(html + com, "[\\w\\s\\W]{30}Quick Move[\\w\\s\\W]{30}", 0));

			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

//			if(comUrl.contains("https://www.valorcommunities.com/new-homes-in-huntsville/merrimack-the-park/"))
//				dtype+="";
			
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "");
//U.log(moveData);
//			if(movSec!=null && movSec.length>0 && !moveData.contains("Under Construction"))
//				if(pstatus==ALLOW_BLANK)
//					pstatus = "Available Homes";
//				else if(!pstatus.contains("Available Homes")) 
//					pstatus += ", Available Homes";
			communityName = communityName.replace("–", "-");
			//=========================================================================================================================

			
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(noOfUnits);
			data.addConstructionInformation(startDt, endDt);
			}//catch(Exception e) {}
		j++;
	
	}
	private String[] getUnits(String html) throws Exception {
		 String siteMapPart=U.getSectionValue(html, "<iframe class=", "</iframe>");
//	        U.log("siteMapPart ::"+siteMapPart);
	        if(siteMapPart==null) {
	        	 siteMapPart=U.getSectionValue(html, "<iframe id=\"frame_comm_filing\"", "</iframe>");	
	        }
	        String lotUrl=U.getSectionValue(siteMapPart, "src=\"", "\"");
	        U.log("lotUrl== "+lotUrl);
	        String lotHtml=U.getHtml(lotUrl, driver);
	        U.log("MMMM"+U.getCache(lotUrl));
//			U.log("mm"+Util.matchAll(lotHtml, "[\\w\\s\\W]{30}519,576[\\w\\s\\W]{30}", 0));

	        int lotCount=0;
	        String noOfUnits=ALLOW_BLANK;
	        String remSec=U.getSectionValue(lotHtml, "Floor Plan<a", "<script");
	        if(remSec!=null)
	        lotHtml=lotHtml.replace(remSec, "");
	        String[] lotData=U.getValues(lotHtml, "<div class=\"legend_data\">", ")</span>");//<div class=\"legend_data\">
	        if(lotData.length<=0) {
	        	lotData=U.getValues(lotHtml, "<span class=\"badge badge-left\">", "</span> </a>");
	        }
	        String[] mapPrice=U.getValues(lotHtml, "<span>Available Inventory Home</span>", "</span>");
	        if(mapPrice.length==0) {
	        	mapPrice=U.getValues(lotHtml, "$(\"#dialog_toolltip #sales_status\").html('Available Spec Home');", "$(\"#dialog_toolltip #description\")");
	        }
        	U.log("mapPrice====="+mapPrice.length);

	        String mapPriceSection=ALLOW_BLANK;
	        if(mapPrice.length>0) {
	        for(String mapPriceSec : mapPrice) {
	        	mapPriceSection+=mapPriceSec;
	        }
	        }
	        
	        for(String lots:lotData) {
//	        	U.log("lots====="+lots);
	        	String lot2=U.getNoHtml(lots);
	        	U.log(lot2);
	        	if(lot2.contains("Not Released ")||lot2.contains("Unavailable / Not For Sale"))
	        		continue;
	        	String num=Util.match(lot2, "\\d+");
	        	lotCount+=Integer.parseInt(num);
	        	
	        }
	        U.log("coUnt "+lotCount);
	        noOfUnits=Integer.toString(lotCount);	
 			if(noOfUnits.equals("0"))
 				noOfUnits=ALLOW_BLANK;
 			
 			String[] mapData= {noOfUnits,mapPriceSection};
 			
 			return mapData;
}
}