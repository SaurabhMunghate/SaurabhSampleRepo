package com.shatam.drhorton;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class TestDrHorton extends AbstractScrapper {

	static int x = 0;
	final static String BUILDER_URL = "http://www.drhorton.com/";
	final static String BUILDER_NAME = "D.R. Horton";
	static CommunityLogger LOGGER;
	
	static public ArrayList<String> setofcomm = new ArrayList<String>();
	static int j = 0;
	int communityCounter = 0;
	
	public TestDrHorton() throws Exception {
		super("D.R. Horton", "http://www.drhorton.com/");
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new TestDrHorton();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"D.R. Horton.csv", a.data().printAll()); 
		
	}
	@Override
	protected void innerProcess() throws Exception {
		String html = U.getHTML("http://www.drhorton.com/No-Results-Found.aspx?searchterm=Search+for+a+city%2c+community+or+zip");
		String regionSections = U.getSectionValue(html, "<h4>Search Tips:</h4>", "Start: OpenHtmlSublayout");
		
		if(regionSections != null ){
			String[] cityUrls = U.getValues(regionSections, "<li>", "</li>");
			//U.log(cityUrls.length);
			for(String cityUrl : cityUrls){
				cityUrl = BUILDER_URL+U.getSectionValue(cityUrl, "\" href=\"/", "\"");
				//U.log("cityUrl : "+cityUrl);
				String cityHtml = U.getHTML(cityUrl);
				
				String [] comSections = U.getValues(cityHtml, "<div class=\"statelink brandedcityListing ", "<div class=\"divider\">");
				LOGGER.AddRegion(cityUrl, comSections.length);
				//U.log(comSections.length);
				for(String comSec : comSections){
					String comUrl = BUILDER_URL + U.getSectionValue(comSec, "<h3><a class=\"statelink\"  href=\"/", "\"");
					//U.log("comUrl : "+comUrl);
					//try{
					addDetails(comUrl,comSec);
					communityCounter++;
					/*}
					catch(Exception e){
					}*/
				}
			}
		}
		LOGGER.DisposeLogger();
		U.log("Total Community : "+communityCounter);
	}
	private void addDetails(String comUrl, String comSec) throws Exception {
//		if(!comUrl.contains("http://www.drhorton.com/Pennsylvania/Pennsylvania/Downingtown/Dowlin-Forge-Station"))return;
//		if(j==404)return;
//		if(j>900)
//		if(j >=1420 && j<=1458)
		{
		if(comUrl.contains("/Emerald-The-Villas-at-Riverstone") || comUrl.contains("/Clermont/Egret-Village")|| comUrl.contains("/Clermont/Express-Heron-Village")
				|| comUrl.contains("/Dallas/Lancaster/Tribute")||comUrl.contains("/Ellensburg/Palomino") || comUrl.contains("/Albany/Acadian-Trace"))return; //redirect	
		U.log(j+"\t:comUrl : " + comUrl);
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl + "************Repeat***********");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String comHtml = U.getHTML(comUrl);
		
		//-------fetching price & SQft from Floor Tab Using post request----
		String floorHtml = ALLOW_BLANK;
		int pageNumber = 1;
		String pageId = U.getSectionValue(comHtml, "\"PageId\": \"{", "}");
		String cacheKey =  U.getSectionValue(comHtml, "'cacheKey': '", "'");
		//String tempFlrHtml = ALLOW_BLANK;
		do{
		String payloadForFloor= "{'communityPageId': '{"+pageId+"}','sortType': '','cacheKey': '"+cacheKey+"','pageNumber': '"+pageNumber+"','facets': '&st=' }";
		String requestUrlForFloor="http://www.drhorton.com/"+"marketing/PlanList.asmx/GetFloorPlans?&overview&home-floor-plans&st=";
		//U.log(payloadForFloor+"\n"+requestUrlForFloor+"\n");
		floorHtml = sendPostRequest(requestUrlForFloor, payloadForFloor, pageId,pageNumber+"");
		//floorHtml += tempFlrHtml; 
		pageNumber++;
		}while(floorHtml.contains("HasNextPage\":true}}"));
		U.log("pageId:::"+pageId);
		
		//-------fetching price & SQft from QMI Tab Using post request----
		String qmiHtml = ALLOW_BLANK;
		String payloadForQMI= "{'communityPageId': '{"+pageId+"}','sortType': '','facets': '&overview&quick-move-in' }";
		String requestUrlForQMI="http://www.drhorton.com/marketing/QmiList.asmx/GetQmiPlans?&overview&quick-move-in&st=";
		//U.log(payloadForQMI+"\n"+requestUrlForQMI);
		qmiHtml = sendPostRequest(requestUrlForQMI, payloadForQMI, pageId,"");
		
		
		//--------Community Name--------
		String comName = U.getSectionValue(comHtml, "<h1>", "</h1>");
		comName = formatComName(comName);
		//change 17DEC2018
		if(comName==null || comName.length()<2) {
			comName=U.getSectionValue(comHtml, "<div class=\"breadcrumb clearfix\">", "</span>");
			comName=U.getSectionValue(comHtml, "<b>", "</b>");
			comName = formatComName(comName);
		}//
		U.log("comName : "+comName);
		
		//-------Address-----
		String [] add = {ALLOW_BLANK , ALLOW_BLANK , ALLOW_BLANK, ALLOW_BLANK};
		String [] latLng = {ALLOW_BLANK,ALLOW_BLANK};
		String geoCode = "FALSE";
		
		String addSec = U.getSectionValue(comHtml, "<h4>Address</h4>", "Directions</a>");
		U.log(addSec);
		if(addSec != null){
			//addSec=U.getNoHtml(addSec);
			
			addSec = Util.match(addSec, "([\\w*\\s*\\W*]*\\s+\\d{5})",1);//U.getSectionValue(addSec, "<p>", "<a href=");
//			U.log(addSec);
			if(addSec!=null)//change added 17DEC2018
			{
			addSec = addSec.replaceAll("<span style=\"font[\\w*|\\W*\\d*]*</span>", "");
			addSec = addSec.replaceAll("<span calibri[\\w*|\\W*|\\d*]*</span> ", "");
			addSec = addSec.replaceAll("<br />\\s*\\[\\(\\d+\\)\\s*\\d+-\\d+\\]\\s*<br />|<br />\\s*<p class=\"MsoPlainText\">\\(\\d+\\)\\s*\\d+-\\d+<o:p></o:p></p>\\s*<br />|<br />\\s*\\(\\d*\\)\\s*\\d*\\-\\d*\\s*<br />| Model not open yet<br />| New Model Open!<br />| MODEL FOR SALE!<br />|Model Open during renovations<br />", "");
			//U.log(addSec);
			addSec=addSec.replaceAll("near Boat Race Road<br />|Model Now Open!<br />|Call for an Appointment<br />|off Tukwet Canyon Pkwy.<br />|MODEL HOME NOW OPEN<br />| off JD Miller Road<br />|\\(Patriot Drive \\&amp\\; Brown Road\\)<br />", "");
			//format address
			String street=U.getSectionValue(addSec, "<p>", "<br />");
			addSec = ignoreAddress(addSec);
			addSec = addSec.replaceAll("<br />", ",").replaceAll(",\\s+,|,\\s*,", ",");
			
			addSec = U.getNoHtml(addSec);
			addSec = addSec.trim();
			//U.log("::::::::::::::::"+addSec);
			String tempAdd[] = addSec.split(","); 
			
			if(tempAdd.length==2){
				add[1] = tempAdd[0].trim();
				add[3] = Util.match(tempAdd[1], "\\d{5}");
				add[2] = tempAdd[1].replace(add[3], "");//Util.match(tempAdd[1], "\\w+");
				if(add[2].length()>2)add[1] = USStates.abbr(add[2].trim());
				//change added 17DEC2018
				if(add[1].length()==2) {add[1]=tempAdd[0].trim();add[2]=USStates.abbr(tempAdd[1].trim().replace(add[3], ""));}
				
			}
			if(tempAdd.length==3){
				add[0] = tempAdd[0].trim();
				add[1] = tempAdd[1].trim();
				add[3] = Util.match(tempAdd[2], "\\d{5}");
				add[2] = tempAdd[2].replace(add[3], "").trim(); //Util.match(tempAdd[2], "\\w+");
				if(add[2].length()>2)add[2] = USStates.abbr(add[2].trim());
				
			}
//			if(tempAdd.length>3 && add[0].length()<5) {
//				add[0] = tempAdd[tempAdd.length-3].trim();
//			}
			if(tempAdd.length>3){	
				add[0] = tempAdd[tempAdd.length-3].trim();
				if(add[0].contains("Model") || add[0].contains("GPS") || add[0].contains(")"))add[0]=street;
				add[1] = tempAdd[tempAdd.length-2].trim();
				add[3] = Util.match(tempAdd[tempAdd.length-1], "\\d{5}");
				add[2] = tempAdd[tempAdd.length-1].replace(add[3], "");//Util.match(tempAdd[tempAdd.length-1], "\\w+");
				if(add[2].length()>2)add[2] = USStates.abbr(add[2]);
				
			}
			
		}//
			//change 17DEC2018
			if(comUrl.contains("http://www.drhorton.com/California/Palm-Springs/Palm-Desert/Spanish-Walk")) {
				add[0]="230 Paseo Gusto";
				add[2]="CA";
			}//
			U.log("Address : "+ Arrays.toString(add));
		}
		else{
			//U.log(":::::::Address NULL::::::::");
		}
		
		if(comUrl.contains("http://www.drhorton.com/Illinois/Chicago/Elmhurst/Emerald-Spot-Lots-1")){
			//Honda On Grand, 300 W Grand Ave, Elmhurst, IL 60126, USA
			add[0] = "300 W Grand Ave";
			geoCode = "TRUE";
		}
		if(comUrl.contains("http://www.drhorton.com/Oregon/Salem/Salem/Express-Whispering-Heights")){
			add[0] = "4755 Liberty Rd S";
		}
		
		//-------LatLng-----
		latLng[0] = U.getSectionValue(comHtml, "var communitylattitude = \"", "\"");
		latLng[1] = U.getSectionValue(comHtml, "var communitylongitude = \"", "\"");
		U.log("latLng : "+ Arrays.toString(latLng));
		U.log("latLng :"+ latLng[0]+":");
		U.log("latLng :"+ latLng[1]+":");
		if(latLng[0] == null){
			String latLngSec = U.getSectionValue(comHtml, "center: new window.Microsoft.Maps.Location(", ")");
			if(latLngSec !=null){
				if(latLngSec.contains(","))latLng = latLngSec.split(",");
			}
		}
		U.log("New latLng : "+ Arrays.toString(latLng));
//		U.stripAll(latLng);
		if(comUrl.contains("http://www.drhorton.com/Washington/Greater-Seattle/Bothell/The-Ponds"))latLng[1]="-122.21035";
		if(add[3].length()>4 && latLng[0] == null){
			latLng = U.getlatlongGoogleApi(add);
			geoCode = "TRUE";
		}
		
		//------remove invalid street-------
		if(add[0].trim().startsWith("("))add[0] = add[0].replace("(", "");
		if(add[0].trim().endsWith(")"))add[0] = add[0].replace(")", "");
		
		if(add[0].trim().equals(comName.trim())){
			add[0] = ""; //comname in street
		}
		
		String ignoreStreet = "\\*\\*Model Offsite\\*\\*|To Be Determined|MODEL HOME NOW OPEN|Model not currently open|Please Call for Information|Model Coming Soon\\!|Contact Ronda for information\\.|Close Out Community|Pre-Selling from Augusta Meadows|TEMPORARY SALES OFFICE|Community located between |Off Sight Sales|by appointment only|Townhomes: |Selling from Sorrento:|Please reach out to a\\s*sales representative below for more information|Model is now closed|Model\\s*(is)*\\s*currently closed|Model Now Open|Model - |Please Call for Locations|Please call for info|Please call for\\s*[an]*\\s*appointment|GPS\\s*(Address)*: |By Appointment Only|Call for an [a|A]ppointment|Call Ronda for Information|Call Ronda [f|F]or [I|i]nformation|Call for appointment|CALL FOR DIRECTIONS|[c|C]all\\s*[f|F]or\\s*[L|l]ocations|Call for information|Call For More Info|CALL FOR INFO|\\*\\*MODEL OFF-SITE\\*\\*|\\*Model Off Site\\s*\\*|Please Reach Out To Asales Representative Below For More Information|Coming June 1|Coming Fall 2018|Address Coming Soon|MODEL HOME COMING SOON|Coming Spring 2019|Coming Soon|COMING SOON|Coming Summer 2018|Preselling Now|Now Preselling|Model Opening Soon|Model Coming Spring 2019|Coming Early 2019|Model is closed|!|Now Selling";
		add[0] = add[0].replaceAll(ignoreStreet, ALLOW_BLANK);
		add[0]=add[0].trim();
		U.log("add[0] :::: "+add[0]);
		
		if((add[0].length()<4 || add[3].length()<4) && latLng[0].length()>4){
			add = U.getAddressGoogleApi(latLng);
			geoCode = "TRUE";
		}
		U.log("add[0] :::: "+add[0]);

		add[0] = U.getCapitalise(add[0].toLowerCase());
		//--------End Address-Latng--------------
		comHtml = U.removeSectionValue(comHtml, "Price:</option>", "</select>")
				.replaceAll("Construction from the Mid \\d+s", "");
		 
		//code for matching prices in this "Homes from $1.1 M" format <b>Homes from $1.6 M</b><br/>
		Matcher millionPrice = Pattern.compile("<b>Homes from \\$\\d{1}\\.\\d{1} M</b><br/>",Pattern.CASE_INSENSITIVE).matcher(comHtml);
		while(millionPrice.find()){
		//U.log(mat.group());
		String priceMatch = millionPrice.group().replace(" M</b><br/>", "00,000").replace(".", ",");  //$1.3 M</b><br/>
		comHtml	 = comHtml.replace(millionPrice.group(), priceMatch);
		}//end millionPrice
		
		//code for matching prices in this "Homes from $1.1 M" format <b>Homes from $1.6 M</b><br/>
		millionPrice = Pattern.compile("<b>Homes from \\$\\d\\.\\d M</b><br/>",Pattern.CASE_INSENSITIVE).matcher(comSec);
		while(millionPrice.find()){
		//U.log(mat.group());
		String priceMatch = millionPrice.group().replace(" M</b><br/>", "00,000").replace(".", ",");  //$1.3 M</b><br/>
		comSec	 = comSec.replace(millionPrice.group(), priceMatch);
		}//end millionPrice
		
		//format "$149s" price
		floorHtml=floorHtml.replace("$999,999,999", "");
		comHtml=comHtml.replace("$999,950,000 - $999,999,999", "");
		comSec = comSec.replace("s</b><br/>", ",000</b><br/>").replace("$999,950,000 - $999,999,999", "");
		comHtml = comHtml.replaceAll("00’s|00s|00ks|00’s", "00,000").replaceAll("0's|0’s|0s", "0,000").replace("K’s", ",000");
		floorHtml=floorHtml.replace("\"Price\":\"$286,675\",\"Address1\":\"324 Wheat Fi", "");
		qmiHtml=qmiHtml.replace("\"Price\":\"$286,675\",\"Address1\":\"324 Wheat Fi", "");
		U.log(Util.matchAll(floorHtml,"\\$999,999[\\w\\s\\W]{10}",0));
		//----------Price---------
		String minPrice = ALLOW_BLANK , maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices(comHtml+floorHtml+qmiHtml+comSec, "Homes from \\$\\d{1},\\d{3},\\d{3}|priced from the \\$\\d{3},\\d{3}(.*)\\$\\d{3},\\d{3}|Mid\\s*[-]*\\s*\\$\\d{3},\\d{3}|Low\\s*[-]*\\s*\\$\\d{3},\\d{3}|Homes from the \\$\\d{3},\\d{3}|Priced from the \\$?\\d+,\\d+|starting in the \\$?\\d+,\\d+|Starting from the \\$\\d{3},\\d{3}|\\d+,\\d+, Call today and come|\\$\\d{3},\\d{3} - $\\d{3},\\d{3}|Mid \\d+,\\d+ to the \\d+,\\d+|Mid \\d+,\\d+|<strong>\\$\\d+,\\d+</strong>|\"price\">\\$\\d,\\d+,\\d+|from the \\$\\d+,\\d+|from the \\d+,\\d+|in the \\$\\d{3},\\d{3}| the low \\d{3},\\d{3}|high \\$\\d{3},\\d{3}|ranging from the high \\$?\\d{3},\\d{3}|PriceText\":\"Priced from \\$\\d,\\d{3},\\d{3}|\"Price\":\"\\$\\d,\\d{3},\\d{3}\"|PriceText\":\"Priced from \\$\\d{3},\\d{3}|\"Price\":\"\\$\\d{3},\\d{3}\"|[U|u]pper[-]*\\s*\\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("Price : "+minPrice+" \t" + maxPrice);
		
		//----------Price---------
		comHtml = comHtml.replace("4,200 square foot clubhouse", "");
		
		String minSqft = ALLOW_BLANK , maxSqft = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(comHtml+floorHtml+qmiHtml+comSec, " \\d,\\d{3} sf - \\d,\\d{3} sf|from \\d,\\d{3} -\\d,\\d{3} SF|footages ranging from \\d,\\d{3}-\\d,\\d{3}|approx. \\d,\\d{3} - \\d,\\d{3} sq ft|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|ranging from \\d,\\d{3} - \\d,\\d{3}|square footage of \\d{4}-\\d{4}|from \\d,\\d{3} - \\d,\\d{3} HSF|\\d{4} SF to \\d{4} SF|ranging from \\d{4} SF to \\d{4} SF|<p>\\s*\\d{3}�square feet|starting from \\d{4} sq|from \\d,\\d{3} to \\d,\\d{3} sq.ft.|plans available from \\d,\\d{3} sq.ft. � \\d,\\d{3} sq.ft and|square footages ranging from \\d{4} to \\d{4}|\\d,\\d{3}�square feet|from \\d,\\d{3} to\\s+\\d{1},\\d{3} square feet|\\d+,\\d+ - \\d+,\\d+ square feet|square footage from \\d{4} to over \\d{4}|\\d{4}sqft -\\d{4}sqft|\\d{1},\\d{3} sq.ft. – \\d{1},\\d{3} sq.ft|\\d{1},\\d{3} SF to \\d{4} SF|\\d{4} to \\d{4} SF|\\d{1},\\d{3} to over \\d{1},\\d{3} square feet|\\d{4} square feet – \\d{4} square feet|from \\d{4} -\\d{4} square fee|spacious \\d,\\d{3} to \\d,\\d{3} sq.ft|\\d,\\d{3} – \\d,\\d{3} sq. ft.|\\d,\\d{3} and \\d,\\d{3} square feet|\\d,\\d{3} – \\d,\\d{3} square feet|Spacious \\d,\\d{3} sq. ft. – \\d,\\d{3} sq. ft.|Large \\d,\\d{3} – \\d,\\d{3} sq. ft.|\\d,\\d{3} sq. ft. to approximately \\d,\\d{3} sq. ft.|\\d+ - \\d+ sq|\\d+sf-\\d+sf|\\d+ square feet – \\d+ square feet|plans ranging from \\d+ to \\d+ sq|floorplans ranging from \\d{4}| \\d+ to \\d+ (square feet|sq)|over \\d{4} sq. ft.|[\\d,]*\\d+ to \\d+ sq. ft|\\d{4}sf to \\d{4}sf|\\d+,\\d+ to \\d+ square feet|\\d+,\\d+ sq ft. to \\d+,\\d+ sq. ft|\\d+,\\d+ square feet|\\d{4} square feet to \\d{4} square fee|\\d,\\d+ - \\d,\\d+ Square Fee|\\d{4} to \\d{4}\\+ sqf|\\d,\\d+ s.f. up to \\d,\\d+ s.f|\\d{4}-\\d{4} sq. feet.|\\d{4}-\\d{4} sq. ft|\\d{4} to \\d{4} sq.ft.|\\d{4} sq ft to \\d{4} sq ft|\\d,\\d{3} - \\d,\\d{3} sq. ft.|floor plans ranging from \\d,\\d+ - \\d{4}|\\d,\\d+â€“\\d,\\d+ sq. ft|\\d,\\d+ sq ft. to \\d,\\d+ sq. ft|\\d{1},\\d+ Â to over \\d{1},\\d+ sq. ft.|\\d,\\d+ and \\d,\\d+ sq. ft.|from \\d,\\d+ to \\d,\\d+ SF|\\d{1},\\d+ square feet to approximately \\d{1},\\d+ square feet|\\d,\\d+\\-\\d,\\d+ Square Fee|\\d,\\d+ square feet to approximately \\d,\\d+ square feet|\\d{4} to over \\d{4} square fee|\\d{4} to \\d{4} square|\\d,\\d+ to \\d,\\d+ SF|sizes from \\d,\\d+ to \\d,\\d+ SF|[\\d,]*\\d+-\\d+ square feet| \\d{3}Â square feet|from \\d,\\d+ - \\d,\\d+ Sq. Ft.|\\d,\\d+ sq. ft. to \\d,\\d+ sq. ft|\\d+,\\d+ sq ft - \\d,\\d+ sq ft|\\d,\\d+ to \\d,\\d+ Square Feet|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d+ to \\d+ square feet|\\d{4} to \\d{4} sq. ft|\\d,\\d+ to \\d,\\d+ Sq. Ft.|\\d,\\d+ to \\d,\\d+ Sq Ft|\\d,\\d+ to \\d{4} square feet|from \\d,\\d+ to \\d,\\d+</li>|\\d,\\d+ square foot|approx. \\d{4}sf to \\d{4}sf|approximately \\d,\\d+ square feet to approximately \\d{1},\\d+ square feet| \\d+ - \\d+ sq. ft.|\\d+,\\d+ to \\d+,\\d+ sq. ft.|\\d+,\\d+Â square feet|\\d{4} sq. ft| \\d{3} square feet| \\d{3}Â square feet|Over \\d{1},\\d+ sq ft|up to \\d{4} Square Feet|\\d,\\d{3} sq. ft. - \\d,\\d{3} sq. ft|approximately \\d,\\d{3} sq. ft|\\d,\\d{3} - \\d,\\d{3} sq. ft.|approximately \\d,\\d{3} square fee|<p>\\s*\\d{3} square feet|Plans up to \\d,\\d{3} square feet|range from \\d{4}|sf-\\d{4}sf|ranging from \\d{4} square feet to \\d{4} square feet|from \\d+,\\d{3} square feet to \\d{4} square feet|\\d,\\d+ square feet|\\d,\\d{3} - \\d,\\d{3} s.f|\\d,\\d{3}-\\d,\\d{3} sq.ft|\\d,\\d{3} square feet|Homes up to \\d,\\d{3} sq. ft.|from \\d,\\d{3} sq. feet|\"SquareFeet\":\"\\d,\\d{3}\"|homes at \\d{4} square feet|size up to \\d,\\d{3} square|approximately \\d{1}[,]*\\d{3} square", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("sqft : "+minSqft+" \t" + maxSqft);
		
		//--------content for fetching property type, deriver type and status
		comHtml = comHtml.replaceAll("Golf Club\" width|caption=\"Mooresville Golf", "")
				.replace("Open&#160; For", "Open For");
		String comContent = U.getSectionValue(comHtml, "<div id=\"tabs\" class=\"tabs-bottom\">", "<h2>Nearby Communities</h2>");
		if(comContent==null)comContent=ALLOW_BLANK;
		//-----removing all the image src for correcting the property type
		comContent = comContent.replaceAll("<img src=\"(.*?)/>" ,"");
		
		//-------ComType-----------
		String comType = U.getCommType(comSec+comContent);
		U.log("comType : "+comType);
		
		//-------propType-----------
		comSec = comSec.replaceAll(" alt=\"New townhouses| alt=\"Townhouses|<img(.*?)>|Quick Move-in Townhomes Available|Now Selling - Model Open", "");
		comContent = comContent.replaceAll("[p|P]atio\\.ashx|ew [t|T]ownhouses for sale|Now Selling - Model Open|quick move-in homes available|caption=\"Townhouses| alt=\"Townhouses|-Coast-BaldwinTownhomesExpress|_patio\\.ashx|N[o|O] HOA|Tangipahoa|new duplex home coming soon|new townhouse sites|townhouses for sale|Cottages are in close proximity|Rancho Cucamonga|drh-hometype=\"Single Family|Townhome/Condo|<div class=\"togglePanel(.*?)</div>", "");
		comContent=comContent.replaceAll("Craftsman, and Cottage architectural stylings|Craftsman, and French architectural stylings", "Craftsman-style architecture");
		String propType = U.getPropType(comSec+comContent);
		//U.log("propType : "+propType);
//			U.log(Util.match(comSec, ".*?hoa.*?"));	
		//-------dType-----------
		qmiHtml = qmiHtml.replaceAll("\"FloorQty\":\"|Stories\":\"", " Stories ");
		floorHtml = floorHtml.replaceAll("\"FloorQty\":\"|Stories\":\"", " Stories ");
		comSec = comSec.replace("Rancho Cucamonga", "");
		String dType = U.getdCommType((comSec+comContent+floorHtml+qmiHtml).replaceAll("Rancho|rancho|George Ranch High|Ranch Blvd|/.*-Story", ""));
		//U.log("dType : "+dType);
		
		//------ignore status---------
		comSec = comSec.replace("NOW SELLING IN NEW SECTION", "NOW SELLING NEW SECTION").replaceAll("=\"Close out pic|/Close-out", "Only 1 Home Remains")
				.replaceAll("Move-In|Move-In Ready Homes Avai</span>|Coming Soon in Pleasant View|alt=\"Springview Woods - Coming Soon|New homes and quick move-in homes available|Grand Opening December 15th|Community Pool NOW OPEN|Courtyard Homes Now Available|Move-in Ready Homes Available NOW|Sugar Land TX selling now|choose between quick move-in homes| about local grand openings|Move-In Ready Homes Available| Cabana Coming Soon!|MOVE IN READY HOME|[M|m]ove [i|I]n [R|r]eady [H|h]ome|New Townhomes Coming Soon to Mundelein|NEW HOMES MOVE-IN READY|Now Selling Crystal Lake|Now Selling Luxury|Homes Coming Soon|Amenity Complex Now Open|=\\s*\"[C|c]*oming [S|s]*oon|Master Suites Coming Soon|New Model  Coming Soon|Move In Ready Homes!", "");
		
		String ignoreStatus = "Move-[I|i]n| pavilion is now open|Quick Move-in Townhomes Available|Quick move-in homes and new home|See New Communities Coming Soon|Coming Soon in Pleasant View|NASH-ComingSoon\">Coming Soon</a>|ComingSoon| Pool and Cabana Now Open|NOW SELLING FROM THE ENCLAVE|store coming Summer 2019|- Coming Summer 2019</p>|community local grand openings|Coming soon amenities|<p>Coming 2019\\!\\&nbsp\\;<br>|Amenity Details Coming Soon|shopping with quick move-in homes|Grand Opening December 15th|Four new communities coming soon|just 20 quick move-in |move-in homes will be available|[I|i]nformation Coming Soon|Builder Coming Soon|about the grand opening|MODEL COMING \\w* 2019|marsh front homesites are now available|Sugar Land TX selling now|LAGOON OPENING SOON|Community Pool NOW OPEN!|Courtyard Homes Now Available|coming this fall to Odessa|<li>Quick delivery homes available</li>|Valley Coming 2019|limited number NOW AVAILABLE | hammock park, and Coming Soon|amenities. Coming|\\*Coming Soon\\*| fire pit. Coming Soon|about the grand opening|currently selling from|Soon*<br>|grand opening events|floor plans, and grand opening|offers quick move-in homes|model homes are coming soon|#c00000;\">COMING SOON!</span></em></strong>|<i><b>COMING SOON:</b>|font-weight: 700;\">Coming Soon|Pickle Ball Court \\(Coming Soon\\)</li>| fire pit\\. Coming Soon|LAGOON OPENING SOON|<div>Coming Soon\\!</div>|School \\(opening August 2018\\)|Now Selling Hawthorne Meadows|amenities\\. Coming Soon| models are now open|Coming soon is a secondary|Community amenities are coming soon|Single Family New Homes Available|upcoming grand opening event|Amenities - Coming Soon| alt=\"Springview Woods - Coming Soon|choose between quick move-in homes| about local grand openings|Move-In Ready Homes Available|Now selling out of the Mission | Cabana Coming Soon!|MOVE IN READY HOME|[M|m]ove [i|I]n [R|r]eady [H|h]ome|Clubhouse Coming Spring 2018|Final Opportunities in Hillcrest|New Townhomes Coming Soon to Mun|Model Coming Fall 2018|&nbsp;Coming Fall 2018<br>|\\*COMING FALL 2018\\*|Move-In Ready Homes Available|NEW HOMES MOVE-IN READY|move-in ready|Move In Ready Homes!|Now Selling Crystal Lake|School is Coming Soon|now selling in the newest sectio|homes are also coming soon|More information coming soon|Now Selling Luxury|Currently selling by appointment|amenity center is now open|Amenity Complex Now Open|river- NOW OPEN|ready to move in homes|PAD COMING SOON|Homes <em>\\(Coming Soon!\\)</em>|Also coming soon to the community| #c00000;\">Coming Soon</span>|Model pictures coming soon|Info Coming Soon|coming soon to Plainfield|Coming Soon!&nbsp;&nbsp;Experience|one coming soon, the clubhouse|Horton homes are coming soon to the area|more info on this COMING SOON community|Neighborhood\">\\s*<div class=\"main-content\">\\s*<p>coming soon</p>|School \\(Coming Soon|weight: bold;\">Coming Soon!</span>|=\"Now selling\"|collection of homes now selling|Waterside Resort is a coming soon|skate park is coming soon| - Coming Soon&nbsp;<br />|Playground - Coming Soon|Amenities</h4>\\s*<p>COMING SOON!&nbsp;</p>|Coming soon with Granite|Image Coming Soon|DRH Coming Soon|Information Coming Soon|[C|c]*oming [S|s]*oon[!]*</li>|Amenities</h4>\\s*<p><strong>Coming Soon|Amenities</h4>\\s*Coming Soon|=\\s*\"[C|c]*oming [S|s]*oon|[p|P]*ool [h|H]*ouse [c|C]oming [s|S]oon|New Model&#160; Coming Soon|tot lot coming soon</li>|</ul>\\s*<p>Coming Soon</p>\\s*<ul>|Amenities</h4>\\s*<p>Coming Soon!</p>|[A|a]menity [C|c]enter [C|c]oming [s|S]oon|[d|D]ock \\([C|c]oming [S|s]oon\\)|[p|P]ool \\([C|c]oming [S|s]oon\\)|pool coming soon!|Master Suites Coming Soon|Soon\\*<br>";
		if(comContent != null){
			comContent = comContent.replaceAll(ignoreStatus, "");
			comContent = comContent.replace("Phase Two is now open", "Phase Two now open");
			comContent=comContent.replaceAll("=\"Close out pic|/Close-out", "Only 1 Home Remains");
		}
//
//		U.log(Util.match(comSec+comContent+floorHtml+qmiHtml, ".*?4-Story.*?"));			
		//-------status-----------
		if(comContent != null){
			comContent = U.removeSectionValue(comContent, "<div id=\"calloutPromoSlider\">", "</ul>"); //promoslider
			comContent=comContent.replace("Coming Late&#160;2018", "COMING LATE 2018").replace("water front home sites available", "waterfront home sites available");
		}
		
		
		comSec=comSec.replace("Now Selling in NEW SECTION", "Now Selling NEW SECTION").replace("Closing out of current phase", "Closing out current phase");
		String status = U.getPropStatus(comSec+comContent);
		//U.log("status : "+comSec);
		//U.log(comContent);
		//--Modified Status----
		if(status.contains("Bay Front Lots Now Available") && status.contains(", Now Available"))status = status.replace(", Now Available", "");
		if(status.contains("Selling Fast,") && status.contains(", Now Open And Selling Fast"))status = status.replace("Selling Fast,", "");
		if(status.contains("Move-in") || status.contains("Move In"))status = status.replaceAll("Move-in Ready Homes|Move-in Ready|Quick Move-in Homes|Quick Delivery Homes", "Quick Move In Homes");

		//from image
		if(comUrl.contains("http://www.drhorton.com/Florida/Tampa/Thonotosassa/Express-Grand-Oak-Glen"))status = status+", Only 1 Home Remains";
		if(comUrl.contains("http://www.drhorton.com/Georgia/Atlanta/Newnan/Genesee"))status = "Coming Soon";
		if(comUrl.contains("/Atlanta/Parkway-Villages"))status = "Phase II Coming Soon";
		if(comUrl.contains("/Rio-Rancho/Cleveland-Heights"))status = "Coming Soon";
//		U.log("qmiHtml:::"+qmiHtml);
		U.log(Util.matchAll(comSec+comContent, "[\\w\\s\\W]{30}quick move[\\w\\s\\W]{30}", 0));
		if(!status.contains("Move In") && qmiHtml.contains("\"Status\":\"Available\"")){
			if(status.length()<3)
				status="Quick Move In Homes";
			else
				status=status+",Quick Move In Homes";
		}
		U.log(latLng[1]);
		if(comUrl.contains("Marysville/Crest-View"))
			latLng[0]="48.029509";
		if(comUrl.contains("Baytown/Express-Goose-Creek-Reserve"))
			maxPrice="$259,990";
    	if(latLng[1]!=null) {
    		latLng[1] =StringEscapeUtils.unescapeJava(latLng[1]);
    		latLng[1] = Util.match(latLng[1], "\\-\\d+\\.\\d+");
    	}
    	if(status.contains("Homes Ready Now,Quick Move In Homes"))status="Quick Move In Homes";
    	if(status.contains("Only 4 Opportunities Left, Only 1 Opportunity Left"))status="Only 4 Opportunities Left, Quick Move In Homes";
    	if(status.contains("Quick Move In Homes, Now Selling, Selling Quickly"))status="Quick Move In Homes, Now Selling Quickly";
    	if(comUrl.contains("/Greenville/Greer/Franklin-Pointe"))status=status+", Final Phase";
    	if(comUrl.contains("/Houston/Rosenberg/Summer-Park"))status = "Coming Soon";
		data.addCommunity(comName, comUrl, comType);
		
		data.addAddress(add[0],add[1],add[2],add[3]);
		data.addLatitudeLongitude(latLng[0].trim(),latLng[1].trim(), geoCode);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status.replace("Ii", "II").replace("Iii", "III"));
		data.addNotes(U.getnote(U.getnote(comContent.replace("New Phase&#160; Now Preselling", "New Phase Now Preselling"))));
		}
		j++;
	}
	
	private String formatComName(String comName) {
		comName = comName.replace("&#160", "")
				.replaceAll(" - D.R. Horton| by D.R. Horton|Twin [Homes|homes]| - Townhomes", "")
				.replace(" @ ", " at ")
				.replace("at;", "at ");
		if(comName.trim().endsWith(";"))comName = comName.replace(";", "");
		if(comName.trim().startsWith(";"))comName = comName.replace(";", "");
		return comName;
	}
	private String ignoreAddress(String addSec) {
		
		addSec = addSec.replace("&amp;", "&")
				.replace("&#39;s", "'s").replace("O&#39;Fallo", "O'Fallo")
				.replaceAll("&#160;", " ").replace("&#39;", "'")
				.replace("&lt;br&gt;", "")
				.replace("21526 45th Ave SE Bothell, WA 98021", "21526 45th Ave SE")
				.replaceAll("Lane<br />\\s*Building 2<br />", "Lane Building 2<br />")
				.replaceAll("Drive<br />\\s*Unit 1204<br />", "Drive Unit 1204<br />")
				.replaceAll("642 Kakala St.<br />\\s*Unit 1612<br />", "642 Kakala St Unit 1612<br />")
				.replaceAll("Woodbury, Minnesota<br />\\s*Woodbury,  Minnesota", "Woodbury, Minnesota")
				.replaceAll("1285 Mako Loop<br />\\s*Off Fort Morgan Road", "1285 Mako Loop<br />")
				.replaceAll(", Powder Springs, GA 30127<br />\\s*Powder Springs,  Georgia 30127", ", Powder Springs, Georgia 30127")
				.replaceAll("Ave, Buckeye, AZ 85396\\s*<br />\\s*Buckeye,  Arizona 85396\\s*", "Ave, Buckeye, AZ 85396")
				.replaceAll("<br />\\s*#7109\\s*<br />", "<br />")
				.replaceAll("<br />\\s*Fresno,  California 93722", "")
				.replaceAll("<br />\\s*Fresno,  California 93725", "")
				.replaceAll("<br />\\s*(Model Closed - Call for appointment|New Model Coming[!]*|Model is closed|Model closed)<br />|Model Now Open<br />|Model Opening Soon<br />", ",");
		addSec = addSec.replaceAll("Mailing Address: Propser, TX 75078|\\(Selling From Gardenia Estates\\)|Off Hwy 64, east of Pollard<br />|\\s*3975 Tommy Lee Cook Road<br />|Off of Boat Race Road<br />|\\(Old Lexington Hwy & Pebblebranch Dr\\)<br />|Now Selling From:\\s*<br />|Selling From Arbor Trail:|MODEL SOLD! Call for Appt\\.<br />|CALL FOR APPOINTMENT<br />|E-Mail Us At\\: PohakalaSales\\@drhorton.com<br />|Coming Soon<br />|NOW Pre-Selling\\s*Please call for more information|Model Temp Closed - Please Call<br />|Model not open<br />|\\*\\*Model Located Off Site\\*\\*|\\*\\* MODEL OFFSITE \\*\\*|\\d{3}-\\d+-\\d+<br />|No Office On-Site<br />|GPS address:  1730 Clifford Rd Garner NC 27529|FOR GPS:1811 Daves Creek Dr.|For GPS Purposes: 253 Red Rider Road, Dawsonville, GA, 30534|\\*\\*Please visit Copper Cove next door to speak to a Sales Professional\\.|Selling [f|F]rom: |For GPS: ", "");
		addSec = addSec.replace("3975 Tommy Lee Cook Road<br />|Off Hwy 64, east of Pollard,", "Off Hwy 64 east of Pollard,")
				.replace("16168 Aberdeen AVENUE", "16168 Aberdeen Avenue").replace("19420 39Th Ave SE Bothell<br />", "19420 39Th Ave SE<br />")
				.replaceAll("<br />\\s*\\d{1}\\s*<br />\\s*", "")
				.replaceAll("^<p>\\s*", "");
		//U.log(addSec);
		return addSec;
	}
	public static String sendPostRequest(String requestUrl, String payload, String pageId,String pageNumber) {
		String html = ALLOW_BLANK;
		StringBuffer jsonString = new StringBuffer();
	    try {
	    	String fileName = U.getCache(requestUrl+pageId+pageNumber);
			File cacheFile = new File(fileName);
			if (cacheFile.exists())
				return FileUtil.readAllText(fileName);
	        
			URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("Accept", "application/json");
	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	        
	        html = jsonString.toString();
	        if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	   
	}

}
