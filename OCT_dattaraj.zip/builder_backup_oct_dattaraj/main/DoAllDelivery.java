package com.shatam.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TimerTask;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
//import com.shatam.b_080_089.ExtractVanMeterHomes;

public class DoAllDelivery extends TimerTask {

	static HashMap<Integer, Integer> builderIndexMap = new HashMap<Integer, Integer>();
	static HashSet<String> builderAdded = new HashSet<String>();

	static ArrayList<Integer> indexces = new ArrayList<Integer>();
	static ArrayList<String> names = new ArrayList<String>();
	static ArrayList<AbstractScrapper> extracters = new ArrayList<AbstractScrapper>();

	static void scrapData(int builderIndex, String name,
			AbstractScrapper extracter) throws Exception {

		// Check for already added builders
		if (builderAdded.contains(extracter.getClass().getName())) {
			throw new Exception(extracter.getClass().getName()
					+ " Already added");
		} else {
			builderAdded.add(extracter.getClass().getName());
		}

		if (builderAdded.contains(name)) {
			throw new Exception(name + " Already added");
		} else {
			builderAdded.add(name);
		}

		extracter.setBuilderName(name);

		int subIndex = 0;
		// U.log("A] "+name + "="+builderIndexMap.containsKey(builderIndex));
		if (builderIndexMap.containsKey(builderIndex)) {
			subIndex = builderIndexMap.get(builderIndex);
			subIndex++;
		}
		builderIndexMap.put(builderIndex, subIndex);
		// U.log("B] "+name + "="+builderIndexMap.containsKey(builderIndex));

		// U.log(name);
		
		
		String deliveryRoot = "";
		
		String OS = System.getProperty("os.name").toLowerCase();
		if(OS.indexOf("win") >= 0){
			deliveryRoot="C:\\BuilderDelivery\\";
		}
		if( (OS.indexOf("nix") >= 0) || (OS.indexOf("nux") >= 0) || (OS.indexOf("aix")>0)){
			String userHome = System.getProperty( "user.home" );
			deliveryRoot= userHome+"/BuilderDelivery/";
		}
		

		
		FileUtil.makeDir(deliveryRoot);

		String builderFileName = String.format("%03d", builderIndex) + "_"
				+ subIndex + "_"
				+ extracter.getBuilderName().replaceAll("[\\W]+", " ");
		// U.log(builderFileName);
		builderFileName = extracter.getBuilderName();
		extracter.process();

		if (extracter.data().getCount() == 0) {
			throw new Exception("No data for builder : "
					+ extracter.getBuilderName());
		}
		FileUtil.writeAllText(deliveryRoot + builderFileName + ".csv",
				extracter.data().printAll());

	}

	public static void add(int builderIndex, String name,
			AbstractScrapper extracter) {
		indexces.add(builderIndex);
		names.add(name);
		extracters.add(extracter);
	}
	
	public  static void retry(int index,String name,AbstractScrapper extracter,String exception)  {
		int time;
		for(int i=1; i<6;i++){
			time=i*10000;
			try {
			U.log("["+name+"] Sleep "+time+" Sec for "+exception );	
			Thread.sleep(time);
			builderIndexMap.remove(index);
			builderAdded.remove(name);
			builderAdded.remove(extracter.getClass().getName());
			scrapData(index, name,extracter );
			break;
			}
			catch (UnknownHostException  E){
				continue;
			}
			catch(Exception ex){ }
			
		}
	}

	public static void runBuilders() throws Exception {
		// add(106, "Westin Homes and Properties", new
		// ExtractWestinHomesandProperties());
		// add(n,name, ext);
		String name;
		int index;
		AbstractScrapper extracter;
		
		//U.log("Started");

		for (int i = 0; i < names.size(); i++) {
			
			name=names.get(i);
			index=indexces.get(i);
			extracter=extracters.get(i);
			
			try {
				scrapData(indexces.get(i), names.get(i), extracters.get(i));
			} catch (UnknownHostException  ex) {
				retry(index,name,extracter,"UnknownHostException "+ex.getMessage());
			} catch(java.io.FileNotFoundException ex){
				retry(index,name,extracter,"FileNotFoundException "+ex.getMessage());
			}
			
			catch (Exception e) {
				e.printStackTrace();
				String errMsg = "#--- "+names.get(i)+" ---#\r\n#--- "+extracters.get(i).getClass().getName()+" ---#";
				StackTraceElement[] err = e.getStackTrace();
				for (StackTraceElement ste : err) {
					errMsg = errMsg +"\r\n"+ ste.toString();
				}
				errMsg+="\r\n\r\n[Builder Error]:\r\n\r\n"+e.getMessage();
				storeLog(e.getMessage(),names.get(i),extracters.get(i).getClass().getName());
				//MailClient.sendNotification(errMsg);
				continue;
			}

		}
		
		
		U.log("Sleep for 60 sec !");
		Thread.sleep(60000);
		U.log("Restart Builders Again !!!");
		main(null);
		
		

	}
	
	private static void storeLog(String msg,String name,String clsName) throws Exception{
		String deliveryRoot = "";
		
		String OS = System.getProperty("os.name").toLowerCase();
		if(OS.indexOf("win") >= 0){
			deliveryRoot="C:\\BuilderDelivery\\";
		}
		if( (OS.indexOf("nix") >= 0) || (OS.indexOf("nux") >= 0) || (OS.indexOf("aix")>0)){
			String userHome = System.getProperty( "user.home" );
			deliveryRoot= userHome+"/BuilderDelivery/";
		} 
		
		File aFile = new File(deliveryRoot+"ErrorLog_"+new SimpleDateFormat("dd_MM_yyyy").format(new Date())+".txt");
		 Date now= new Date();
		 String log="\r\n\r\n["+new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").format(new Date())+"]#--- "+name+" ---#\r\n["+clsName+"] -----------#\r\n"+msg;
	        //use buffering
	        Writer output = new BufferedWriter(new FileWriter(aFile, true));
	        try {
	            output.write(log);
	        } finally {
	            output.close();
	        }
	}

	public static void main(String[] args) throws Exception {

		builderIndexMap.clear();
		builderAdded.clear();
		names.clear();
		indexces.clear();
		extracters.clear();
		//new DeleteDirectory().main(null);
		
	/*	add(1, "D.R. Horton", new ExtractDRHorton());
		add(2, "Pulte Group - Centex Homes", new ExtractCentex());
		add(2, "Pulte Group - Pulte Homes", new ExtractPulteHomes());
		add(2, "Pulte Group - Del Webb Homes", new ExtractDelWebb());
		add(2, "Pulte Group - DiVosta Homes", new ExtractDivosta());
		add(3, "Lennar Homes", new ExtractLennarCorp());
		add(4, "NVR - Ryan Homes", new ExtractRyanHomes());
		add(4, "NVR - NV Homes", new ExtractNVHomes());
		add(4, "NVR - FoxRidge Homes", new ExtractFoxRidgeHomes());
		add(5, "KB Home", new ExtractKBHomes());*/


		/*
		// -- First 100
		
		add(1, "D.R. Horton", new ExtractDRHorton());
		add(2, "Pulte Group - Centex Homes", new ExtractCentex());
		add(2, "Pulte Group - Pulte Homes", new ExtractPulteHomes());
		add(2, "Pulte Group - Del Webb Homes", new ExtractDelWebb());
		add(2, "Pulte Group - DiVosta Homes", new ExtractDivosta());
		add(3, "Lennar Homes", new ExtractLennarCorp());
		add(4, "NVR - Ryan Homes", new ExtractRyanHomes());
		add(4, "NVR - NV Homes", new ExtractNVHomes());
		add(4, "NVR - FoxRidge Homes", new ExtractFoxRidgeHomes());
		add(5, "KB Home", new ExtractKBHomes());
		add(6, "K. Hovnanian Homes", new ExtractHovnanian());
		add(7, "Ryland Group", new ExtractTheRylandGroup());
		add(8, "Beazer Homes", new ExtractBeazerHomesUSA());
		add(9, "Meritage Homes", new ExtractMeritageHomes());
		add(10, "M.D.C. Holdings (Richmond American)",
				new ExtractMDCHoldingsRichmondAmerican());
		add(11, "Standard Pacific Homes", new ExtractStandardPacific());
		add(12, "Toll Brothers", new ExtractTollBrothers());
		add(13, "Taylor Morrison", new ExtractTaylorMorrison());
		add(14, "MI Homes", new ExtractMIHomes());
		add(15, "The Villages of Lake Sumter", new ExtractTheVillages());
		add(16, "Weyerhaeuser - Camberley Homes",	new Extractcamberleyhomes());
		add(16, "Weyerhaeuser - Quadrant Homes", 	new ExtractQuadrantHomes());
		add(16, "Weyerhaeuser - Maracay Homes", 	new ExtractMaracayHomes());
		add(16, "Weyerhaeuser - Pardee Homes", 		new ExtractPardeeHomes());
		add(16, "Weyerhaeuser - Trendmaker Homes", 	new ExtractTrendMakerHomes());
		add(16, "Weyerhaeuser - Winchester Homes", 	new ExtractWinchesterHomes());
		add(17, "Shea Homes", new ExtaractSheaHomes());
		add(18, "David Weekley Homes", new ExtractDavidWeekleyHomes());
		add(19, "Highland Homes", new ExtractHighLandHomes());
		add(20, "Related Group", new ExtractRelatedGroup());
		add(21, "Drees Company", new ExtractDreesHomes());
		add(22, "Woodside Homes", new ExtractWoodsideHomes());
		add(23, "Perry Homes", new ExtractPerryHomes());
		add(24, "Ashton Woods Homes", new ExtractAshtonWoods());
		add(25, "McBride & Son Companies", new ExtractMCBridgeHomes());
		add(26, "Gehan Homes", new ExtractGehanHomes());
		add(27, "MHI McGuyer - Plantation Homes",
				new ExtractPlantationHomes());
		add(27, "MHI McGuyer - Coventry Homes",
				new ExtractCoventryHomes());
		add(27, "MHI McGuyer - Carmel Builders",
				new ExtractCarmelBuildersTx());
		add(27, "MHI McGuyer - Wilshire Homes",
				new ExtractWilshireHomes());
		add(28, "First Texas Homes", new ExtractFirstTexasHomes());
		add(29, "GL Homes", new ExtractGLHomes());
		add(30, "Epcon Communities Franchising",
				new ExtractEpconCommunitiesFranchising());
		add(31, "William Lyon Homes", new ExtractWilliamLyonHomes());
		add(32, "Rausch Coleman Homes", new ExtractRauschColemanHomes());
		add(33, "Fischer Homes", new ExtractFischerHomes());

		add(34, "Mungo Companies", new ExtractMungo());
		add(35, "Westport Homes", new ExtractWestportHome());
		 add(36, "Polygon Northwest", new ExtractPolygonHomes());
		 add(37, "American West Development", new
		 ExtractAmericanwestHomes());
		 add(38, "Hayden Homes", new ExtractHaydenHomes());
		 add(39, "Mattamy Homes", new ExtractMattamyHomes());
		 add(40, "Corky McMillin Companies", new
		 ExtractTheCorkymcMillin());
		 add(41, "Brookfield Homes", new ExtractBrookFieldHomes());
		 add(42, "True Homes", new ExtractTrueHomesUSA());
		 add(43, "Dominion Homes", new ExtractDominionHomes());
		 add(44, "Legend Classic Homes", new ExtractLegendClassicHomes());
		 add(45, "Desert View Homes", new ExtractDesertViewHomes());
		// add(46, "NeighborWorks America", NeighborWorks America());
		add(47, "Dan Ryan Builders", new ExtaractDanRyanBuilders());
		//add(48, "HearthStone Homes", HearthStoneHomes());
		add(49, "CBH Homes", new Extract_049_CBHHomes());
		 add(50, "Fulton Homes", new Extract_050_FultonHomes());

		 add(51, "H and H Homes", new ExtractHHhomes());
		add(52, "Caviness and Cates Communities",
				new ExtractCavinessCatesCommunities());
		add(53,"Hunter Communities", new ExtractHunterCommunities());		
		 add(54, "Ivory Homes", new ExtractIvoryHomes());
		add(55, "Armadillo Construction", new ExtraxtArmadiloCons());
		add(56, "Home Creations", new ExtractHomeCrations());
		add(57, "LGI Homes", new ExtractLgiHomes());
		add(58, "Castle Rock Communities", new ExtractCastleRock());
		 add(59, "Ball Homes", new ExtractBallHomes());
		add(60, "United Built Homes", new ExtractUBHHomes());
		add(62, "Heartland Homes", new ExtractHeartLandHomes());
		add(63, "Saratoga Homes", new ExtractSaratogaHomes());
		 add(64, "FieldStone Homes", new ExtractFieldStoneHomes());
		add(65, "John Wieland Homes and Neighborhoods",
				new ExtractJohnWielandHomes());
		add(66, "Centerline Homes", new ExtractCenterLineHomes());
		 add(67, "Tilson Homes", new ExtractTilesonHomes());
	     add(68, "Darling Homes", new ExtractDarlingHomes());
		add(69, "Allen Edwin Homes", new ExtractAllenEdwinHomes());

		 add(70, "Essex Homes", new ExtractEssexHomes());
		 add(71, "Wayne Homes", new ExtractWayneHomes());
		add(72, "Stanley Martin Homes", new ExtractStanleyMartinHomes());
		add(73, "History Maker Homes", new ExtractHistoryMakerHomes());
		add(74, "DSLD Homes", new ExtractDSLD_Homes());
		add(75, "Betenbough Homes", new ExtractBetenboughHomes());
		add(76, "ICI Homes", new ExtractICI_Homes());
		add(77, "Oakwood Homes", new ExtractOakwoodHomes());

		add(78, "Chesmar Homes", new ExtractChesmarHomes());
		add(79, "Signature Homes", new ExtractSignatureHomes());
		add(80, "Holiday Builders", new ExtractHolidayBuilders());
		add(81, "Grand Homes", new ExtractGrandHomes());
		//add(82, "The Rottlund Co.", new ExtractRottlundHomes());
		add(83, "Bill Clark Homes", new ExtractBillClarkHomes());
		add(84, "Van Metre Apartments", new ExtractVanMetreCos());
		add(84, "Van Metre Homes", new ExtractVanMetreHomes());
		add(85, "Sivage Homes",
				new ExtractSivageHomes());
		add(86, "Bloomfield Homes", new ExtractBloomfieldHomes());
		add(87, "Cheldan Homes", new ExtractCheldanHomes());
		add(88, "Granite Ridge Builders", new ExtractGraniteRidgeBuilders());
		add(89, "Ideal Homes", new ExtractIdealHomes());
		add(90, "Gemcraft Homes", new ExtractGemcraftHomes());
		add(91, "Craftmark Group - Craftmark Homes", new ExtractCraftMarkHomes());
		add(92, "Gentry Homes", new ExtractGentryHomes());
		add(93, "Neal Communities", new ExtractNealCommunities());
		add(94, "Ole South Properties", new ExtractOleSouthProperties());
		add(95, "Miller and Smith", new ExtractMillerSmith());
		add(96, "Century Communities", new ExtractCenturyCommunity());
		add(97, "Jagoe Homes", new ExtractJagoeHomes());
		add(98, "Jones Company", new ExtractTheJonesCompany());
		add(99, "Highland Holdings", new ExtractHighlandHoldings());
		add(100, "Simmons Homes", new ExtractSimmonsHomes());
		
		 */
		
		//----- From 100 to 199
	  /*
		 add(101, "Keystone Custom Homes", new ExtractKeystoneCustomHomes());
		 add(102, "Buffington Homes", new ExtractMyBuffington());
		 add(103, "WCI Communities", new ExtractWciCommunities());
		 add(104, "Lombardo Homes", new ExtractLombardoHomes());
		 add(105, "Forever Homes", new ExtractForeverHomes());
		 add(106, "Westin Homes and Properties", new ExtractWestinHomesandProperties());
		 add(107, "S&A Homes", new ExtractSaHomes());
		 //add(108, "Sares-Regis Group", new ExtractForeverHomes());
		 add(109, "Shugart Enterprises", new ExtractShugartEnterPrises());
		 add(110, "West Hills Development Co", new ExtractWestHillDevlopment());
		 add(111, "Olson Company", new ExtractTheOlsonCo());
		 //add(112, "Quality Built Homes", new ExtractForeverHomes());
		 add(113, "Hills Communities", new ExtractHillsCommunities());
		 add(114, "Wade Jurney Homes", new ExtractWadeJurneyHomes());
		 add(115, "Compass Pointe Homes", new ExtractCompassPointHomes());
		 add(116, "Jeff Benton Homes", new ExtractJeffBentonHomes());
		 //add(117, "Nichols Partnership", new ExtractForeverHomes());
		 add(118, "Elliott Homes", new ExtractElliotteHomes ());
		 add(119, "Wathen Castanos Hybrid Homes", new ExtractWathenCastanosHybridHomes());
		 add(120, "Landon Homes", new ExtractLondonHomes());
		 add(121, "Ryan Building Group", new ExtractRyanBuildingGroup());
		 add(122, "Classic Homes", new ExtractClassicHomes());
		 add(123, "Park Square Homes", new ExtractParkSquareHomes());
		 add(124, "Vitalia", new ExtractAvatarHoldings());
		 add(125, "Grayhawk Homes", new ExtractGrayHawkHomes());
		 add(126, "Beechwood Organization", new ExtractBeechWoodOrganization());
		 add(127, "Gateway Homes", new ExtractGatewayHomes());
		 add(128, "Goodall Homes", new ExtractGoodallHomes());
		 //add(129, "The Estridge Cos.", new ExtractJeffBentonHomes());
		 add(130, "Traton Homes", new ExtractTratonHomes());
		 add(131, "MBK Homes", new ExtractMBKHomes());
		 add(132, "Providence Homes", new ExtractProvidanceHomes());
		 add(133, "Heritage Building Group", new ExtractHeritageBuildingGroup());
		 add(134, "Sumeer Homes", new ExtractSumeerHomes());
		 add(135, "Tempest Homes", new ExtractTempestHomes());
		 add(136, "Neighborhoods of EYA", new ExtractEYA());
		 add(137, "SummerHill Homes", new ExtractSummerHillHomes());
		 add(138, "Scott Felder Homes", new ExtractScottfelderHomes());
		 add(139, "Manor Homes", new ExtractManorHomes());
		 //add(140, "Vantage Builders", );
		 add(141, "HHHunt Corporation",new ExtractHHHunt_Homes());
		 add(141, "HHHunt Corporation - The Villages of Charter Colony", new ExtractCharterColony());
		 add(141, "HHHunt Corporation - Rutland", new ExtractRutlandHomes());
		 //add(141, "HHHunt Corporation - White Hall", new ExtractWhitehallNewHomes());
		 add(142, "Chesapeake Homes", new ExtractChesapeakeHomes());
		 add(143, "Marrano-Marc Equity", new ExtractMarranoHomes());
		 add(144, "Streetman Homes", new ExtractStreetmanHomes());
		 add(145, "Eagle Construction", new ExtractEagleConstruction());
		 add(146, "John Mourier Construction", new ExtractJMC_Homes());
		 add(147, "Kettler", new ExtractKettler());
		 add(148, "Schell Brothers", new ExtractSchellBrothers());
		 add(149, "Charter Homes and Neighborhoods", new ExtractCharterHomes());
		 add(150, "Cornell Homes", new ExtracExtractCornellHomes1());
		 //add(150, "Cornell Homes 3", );
		 
		 add(151, "Southern Home Builders", new ExtractSouthernHomeBuilders());
		 //add(152, "HPH Properties", );
		 add(153, "Woodland Homes of Huntsville", new ExtractWoodlandHomes());
		 add(154, "American Properties Realty", new ExtractAmericanProperties());
		 //add(155, "Pacesetter Homes", );
		 add(156, "TriStone Homes", new ExtractTriStoneHomes());
		 //add(157, "Unmistakably Premier Homes", new ExtractWoodMontpa());
		 add(158, "Sitterle Homes", new ExtractSitterleHomes());
		 //add(159, "Minks Custom Homes", );
		 add(160, "Magellan Development Group", new ExtractMagellanDevelopment());
		 add(161, "Capital Pacific Homes", new ExtractCapitalPacificHomes());
		 add(162, "SoundBuilt Homes", new ExtractSoundBuiltHomes());
		 add(163, "Bozzuto Group", new ExtractBozzutoGroup());
		 add(164, "Arthur Rutenberg Homes", new ExtractArthurRutenbergHomes());
		 //add(165, "T.W. Lewis Co.", );
		 add(166, "Keystone Group", new ExtractKeystoneGroup());
		 //add(167, "Southern Homes", new ExtractSouthernHomes());
		 add(168, "StyleCraft Homes", new ExtractStyleCraftHomes());
		 add(169, "Main Street Homes", new ExtractMainStreetHomes());
		 add(170, "Wynn Construction", new ExtractWynnConstruction());
		 //add(171, "Artistic Homes", );
		 add(172, "Forino Company", new ExtractForinoCo());
		 add(173, "McCaffrey Group", new ExtractTheMcCaffreyGroup());
		 add(174, "Warmington Group", new ExtractWarmingtonGroup());
		 add(175, "Vintage Homes", new ExtractVintageHomes());
		 add(176, "Shumaker Homes", new ExtractShumakarHomes());
		 add(177, "Pratt and Associates", new ExtractPrattAndAssociates());
		 add(178, "Ence Homes", new ExtractEnceHomes());
		 add(179, "Grand View Builders", new ExtractGrandViewBuilders());
		 //add(180, "Brookstone Homes", );
		 add(181, "Capital Homes Residential Group", new ExtractCapitalHomesResidentialGroup());
		 add(182, "Kendall Homes", new ExtractKendallHomes());
		 add(183, "Pacific Communities Builder", new ExtractPacificCommunitiesBuilder());
		 add(184, "Shaddock Homes", new ExtractShaddockHomes());
		 add(185, "Armstrong Homes", new ExtractArmstrongHomes());
		 add(186, "4 Corners Homes", new Extract4CornersHomes());
		 add(187, "Miramonte Homes", new ExtractMiramonteHomes());
		 add(188, "Onyx Homes", new ExtractOnyxHomes());
		 add(189, "Payne Family Homes", new ExtractPayneFamilyHome());
		 add(190, "James Engle Custom Homes", new ExtractJamesEngleCustomHomes());
		 add(191, "Tim Lewis Communities", new ExtractTimLewisCommunities());
		 //add(192, "Consolidated Development Group", );
		// add(193, "Premier Communities", new ExtractPremierCommunities());
		 add(194, "Rodrock Homes", new ExtractRodrockHomes());
		 add(195, "Braselton Homes", new ExtractBraseltonHomes());
		 add(196, "Imagine Homes", new ExtractImagineHome());
		 add(197, "Pacific Lifestyle Homes", new ExtractPacificLifestyleHomes());
		 add(198, "Devon Street Homes", new ExtractDevonStreetHomes());
		 add(199, "Petros Homes", new ExtractPetrosHomes());
		
	 // */
		 
		 
		runBuilders();
		 //FileNotFoundException
		 
		 
		// End of main
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
