package com.shatam.main;


import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailClient {

	public void sendMail(String from, String to, String subject,
			String messageBody) throws MessagingException, AddressException {
		// Setup mail server
		String host = "smtp.gmail.com";
		String username = "builderscode@gmail.com";
		String password = "code100builders";
		Properties props = new Properties();
		props.put("mail.smtps.auth", "true");

		// Get a mail session
		Session session = Session.getDefaultInstance(props, null);

		// Define a new mail message
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		message.setSubject(subject);

		message.setText(messageBody);

		// Send the message
		Transport t = session.getTransport("smtps");
		try {
			t.connect(host, username, password);
			t.sendMessage(message, message.getAllRecipients());
			System.out.println(" Message finished");
		} finally {
			t.close();
		}

	}

	public static void sendNotification(String errMsg) {
		try {
			MailClient client = new MailClient();
			String from = "builderscode@gmail.com";
			//String to = "27526418@way2sms.com";   //sanket way2sms id
			//String to = "8329108@way2sms.com";
			//String to = "23943956@way2sms.com";      //parag way2sma id
			//String to = "sanket231089@gmail.com";
			String subject = "Error in Builder code check mail";
			String message = "ERROR in Builder code \r\n\r\n[ErrorStackTrace] :\r\n"+errMsg;
			
			//client.sendMail(from, to, subject, message);
			client.sendMail(from, "shyamal.aaditi@gmail.com", subject, message);
			client.sendMail(from, "rakesh.shatam@gmail.com", subject, message);
			client.sendMail(from, "ashish.shatam@gmail.com", subject, message);
			client.sendMail(from, "parag.shatam@gmail.com", subject, message);
			
			
			//client.sendMail(from, "shivhare2009monu@gmail.com", subject, message);
			//System.exit(0);
		} catch (Exception e) {
			e.printStackTrace(System.out);
			
		}

	}
}
