package com.shatam.main;

import java.io.File;

import com.shatam.utils.U;

public class RemoveZeroCache {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int deleteCount = 0 ;
		String gmapFolderPath = U.getCachePath()+File.separator+"maps.googleapis.com";
		File gmapFolder = new File(gmapFolderPath);
		//U.log("Total no of files : " + listOfFiles.length);
		if(gmapFolder.isDirectory()){
			System.out.println("::::Directory Present::::::");
			File[] listOfFiles = gmapFolder.listFiles();
			
			for (int i = 0; i < listOfFiles.length; i++) {
			      if (listOfFiles[i].isFile()) {
			    	double bytes = listOfFiles[i].length();
					double kilobytes = (bytes / 1024);
					
			        if(kilobytes<1){
			        	 System.out.println("File " + listOfFiles[i].getName() + "\t Size : " + listOfFiles[i].length()); //return length in bytes
			        	 System.out.println("File size in KB : "+kilobytes);
			        	listOfFiles[i].delete();
			        	deleteCount++;
			        }
			      }
			    }
			System.out.println("Total files deleted : " + deleteCount);
		}
	}

}
