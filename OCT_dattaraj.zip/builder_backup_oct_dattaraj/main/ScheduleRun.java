package com.shatam.main;

import java.util.Timer;

import com.shatam.utils.U;

class ScheduleRun {

	   public static void main(String[] args) {
	       Timer timer = new Timer();

           U.log("Running"); 
	       // Schedule to run after every 3 hrs(3*60*60*1000)
	      // timer.schedule( new DoAllDeliv(), 1000*60);  
	       U.log("Run end"); 
	   }
}

class DoAllDeliv{
	public void run(){
		
	}
}