package com.shatam.main;

import java.io.File;
import java.util.logging.LogManager;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

import com.shatam.utils.U;

public class TestNewSelenium {

	public static void main(String[] args) {
		
		/*System.setProperty("webdriver.gecko.driver", System.getProperty("user.home")+File.separator+"geckodriver");
		U.clearFirefoxConsoleLogs();
		//Set Firefox Headless mode as TRUE
		FirefoxOptions options = new FirefoxOptions();
		options.addArguments("--headless");
		
		//Instantiate Web Driver
		WebDriver driver = new FirefoxDriver(options);*/
		
		/*System.setProperty("webdriver.chrome.driver",System.getProperty("user.home")+File.separator+"chromedriver");
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless");
		options.addArguments("--headless");
		WebDriver driver = new ChromeDriver(options);*/
	
	System.setProperty("phantomjs.binary.path", System.getProperty("user.home")+File.separator+"phantomjs");
	System.out.println(System.setProperty("phantomjs.binary.path", System.getProperty("user.home")+File.separator+"phantomjs"));
	// To declare and initialize PhantomJSDriver
		WebDriver driver = new PhantomJSDriver();
		driver.get("http://www.google.com");
		System.out.println("Page title is - " + driver.getTitle());
		
		//Search on Google
		driver.findElement(By.name("q")).sendKeys("selenium webdriver");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//Display number of results on Console
		System.out.println("Total Results - " + driver.findElement(By.id("resultStats")).getText());
		
		driver.close();

	}

}
