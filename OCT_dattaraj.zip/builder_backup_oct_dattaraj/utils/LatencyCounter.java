package com.shatam.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

public class LatencyCounter {
	private HashMap<String, Date> timeMap = new HashMap<>();
	private HashMap<String, Long> milliMap = new HashMap<>();

	public void start(String key) {
		timeMap.put(key, Calendar.getInstance().getTime());
	}

	public void end(String key) {
		Date t1 = Calendar.getInstance().getTime();
		Date t2 = timeMap.get(key);
		long diffInMillies = t1.getTime() - t2.getTime();

		long millis = milliMap.containsKey(key) ? milliMap.get(key) : 0;
		milliMap.put(key, millis + diffInMillies);
	}

	@Override
	public String toString() {
		String str = "*** LatencyCounter *** ";
		for (Entry<String, Long> pair : milliMap.entrySet()) {
			str += "\n";
			str += pair.getKey() + "\t=" + pair.getValue();
		}
		return str;
	}

}
