package com.shatam.utils;

import java.io.File;

public class MapsRemoveSizeZero {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String mapsDirPath = "/home/shatam-3/MexicoDB/Cache/pek.mx";//U.getCachePath()+"maps.googleapis.com";
		System.out.println(mapsDirPath);
		
			File mapsDir = new File(mapsDirPath);
			File[] files = mapsDir.listFiles();
			for(File f: files){
				//System.out.println("File Name : "+f.getName() + ":::::::::: "+f.length() );
				double bytes = f.length();
				double kilobytes = (bytes / 1024);
				//System.out.println(kilobytes);
				if(kilobytes ==0){
					System.out.println("File Name : "+f.getName() + ":::::::::: "+f.length() );
					f.delete();
					//System.out.println("remove");
				}
				//break;
			}
	}

}
