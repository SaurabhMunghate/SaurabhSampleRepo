package com.shatam.utils;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Util {

    public static String match(String txt, String findPattern) {

        Matcher m = Pattern.compile(findPattern, Pattern.CASE_INSENSITIVE).matcher(txt);
        while (m.find()) {
            String val = txt.substring(m.start(), m.end());
            val = val.trim();

            val = val.replaceAll("\\s+", " ").trim();
            return val;
        }
        return null;
    }// match


    public static String match(String html, String expression, int groupNum) {

        Matcher m = Pattern.compile(expression, Pattern.CASE_INSENSITIVE).matcher(html);
        
        if (groupNum <= 0) {
            if (m.find()) {
            	return m.group();
            }
            else {
                return null;
            }
        }

        if (m.find(groupNum)) {
            return m.group(groupNum).trim();
        }
        else {
            return null;
        }
    }


    public static ArrayList<String> matchAll(String html, String expression, int groupNum) {

        Matcher m = Pattern.compile(expression, Pattern.CASE_INSENSITIVE).matcher(html);


        ArrayList<String> list = new ArrayList<String>();

        while (m.find()) {
            //Util.log(m.group(groupNum));
            list.add(m.group(groupNum).trim());
        }
        return list;

    }


    public static String toString(int[] arr) {

        String s = "";
        for (int i : arr) {
            if (s.length() > 1)
                s += ",";
            s += i;
        }
        return s;
    }


    public static void log(Object o) {

        System.out.println("" + o);
    }

    
    
public static String getUnits(String mapHtml) throws Exception {
		
		String totalUnits = "";
		String mapdata = "";
		String [] latData=null;
			
			String[] mapSec=U.getValues(mapHtml, "<div id=\"FocusSitemapSVGpanzoom\"", "<g id=\"footprints\"");
			if(mapSec.length==0) {
				 mapSec=U.getValues(mapHtml, "<div id=\"FocusSitemapSVG", "</svg>");
			}
			
			if(mapSec.length==0) {
				 mapSec=U.getValues(mapHtml, "<g id=\"Symbol", "</g>");
			}
			if(mapSec.length==0) {
				// map Section for Arbor Homes
				 String mapSec1=U.getSectionValue(mapHtml, "<g id=\"Lots\">", "<g id=\"");
				 if(mapSec1!=null)
				 mapSec=U.getValues(mapSec1, "id=\"Lot", "</");
				 
			}
			if(mapSec.length==0) {
				// map Section for Arbor Homes
				 String mapSec1=U.getSectionValue(mapHtml, "<g id=\"Lots\">", "</svg>");
				 if(mapSec1!=null)
				 mapSec=U.getValues(mapSec1, "id=\"Lot", "</");
				 
			}
			U.log(">>>>mapSec>>>>>>>>>>"+mapSec.length);
			if(mapSec.length>0) {
				for(String mapData : mapSec) {
					mapdata+=mapData;
				
				}
				latData=U.getValues(mapdata, "<g id=\"lot_", "</g>");
				if(latData.length==0) {
					latData=U.getValues(mapdata, "data-lotId=", ">");
				}
				if(latData.length==0) {
					latData=U.getValues(mapdata, "_", ">");
				}
				totalUnits = Integer.toString(latData.length);
			}
			else
				totalUnits ="0";
//			U.log(">>>>latData>>>>>>>>>>"+latData.length);
				
				
		
		return totalUnits;
	}
	


public static String getUnitsByMatch(String mapHtml) throws Exception {

	int sum=0;
	String[] lotDataSec1=U.getValues(mapHtml, "<div id=\"statuses-container\"", "</section>");
	if(lotDataSec1.length==0)
		lotDataSec1=U.getValues(mapHtml, "<span class=\"LotLegend-typographyStandard", "</div>");
	
	if(lotDataSec1.length==0)
		lotDataSec1=U.getValues(mapHtml, "<span class=\"LotLegend-typographyStandard LotLegend-inlineItem", "</span>");
	
	if(lotDataSec1.length==0)
		lotDataSec1=U.getValues(mapHtml, "<g class=\"css-1ep8pva\">", "</svg></g></g>");
	
	if(lotDataSec1.length==0)
		lotDataSec1=U.getValues(mapHtml, "<h6 class=\"MasterSiteplanLegend-typographyLotCount MuiTypography-root MuiTypography-subtitle2 css-1dlhfnb\">(", ")</h6>");
	
	FileUtil.writeAllText("/home/shatam-10/Desktop/data/mapHtml.txt", mapHtml);
	U.log("lotDataSec1 length == "+lotDataSec1.length);
	
	int lotcount = 0;
	String lotDataSec=null;
	if(lotDataSec1.length>0) {
		

		
		for(String lotdata : lotDataSec1) {
			U.log("lotdata=="+lotdata);
			
			//---FOR MCKEE HOMES
			if(lotdata.contains("homesites")) {
				
				lotdata = lotdata.replace("homesites", "").trim();
				U.log("lotdata here: "+lotdata);
				
				lotcount += Integer.parseInt(lotdata);
			}
			
			
	lotDataSec+=lotdata;
	
		}
		
		U.log("lotcount: "+lotcount);
		
	}
	if(lotDataSec!=null ) {
		String[] lotData=U.getValues(lotDataSec, "<label>", "</div>") ;
		if(lotData.length==0)
			lotData=U.getValues(lotDataSec, "\">", "</span>") ;
	
//		U.log("lotData=="+lotData.length);
		if(lotData.length>0) {
			for(String lotdata : lotData) {
				lotdata=U.getNoHtml(lotdata).trim();
//				U.log("lotdata=="+lotdata);
				sum+=Integer.parseInt(Util.match(lotdata, "\\d+"));
			}
		}
		
		
		if(sum == 0 && lotcount != 0) {
			
			//U.log(lotDataSec);
			sum = lotcount;
		}
		
		
		U.log("sum ==== "+sum);
	}
	return Integer.toString(sum);
}


    
    

}
