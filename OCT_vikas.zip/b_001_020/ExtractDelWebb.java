/**
 * @author Upendra Singg
 * @date 19/04/2018
 * 
 */
package com.shatam.b_001_020;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
//import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractDelWebb extends AbstractScrapper {
	public int i = 0;
	static int count = 0;
	public int inr = 0;
	public int dup = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	String status;
	List<String> comData = new ArrayList<String>();
	//private static LatencyCounter LATENCY = null;
	static String Builder_Url = "https://www.delwebb.com";
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		/*LATENCY=new LatencyCounter();
		LATENCY.start("Time");*/
		AbstractScrapper a = new ExtractDelWebb();
		a.process();
		try {
			FileUtil.writeAllText(U.getCachePath() + "Pulte Group - Del Webb Homes.csv", a.data().printAll());
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		U.log("count==" + count);
		/*LATENCY.end("Time");
		U.log(LATENCY);*/
	}

	public ExtractDelWebb() throws Exception {
		super("Pulte Group - Del Webb Homes", "https://www.delwebb.com/");
		LOGGER = new CommunityLogger("Pulte Group - Del Webb Homes");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();

		String MainHtml = U.getHTML(Builder_Url);
		String regionState = U.getSectionValue(MainHtml, "<select class=\"form-control State\"", "</select>");
//		 U.log(regionState);
		String[] state = U.getValues(regionState.replaceAll("<option value=\"\">", ""), "<option value=\"", "\">");
		for (String string : state) {
		//	if(string.contains("California")) {
			String stateHtml = U
					.getHTML("https://www.delwebb.com/api/marker/mapmarkers?brand=Del+Webb&state=" + string + "&qmi=false");
			String stateData = U.getHTML("https://www.delwebb.com/API/community/Search?qmi=false&brand=Del+Webb&state="
					+ string + "&productType=community&pageSize=99&pageNumber=0&flag=state&data=" + string);
		//	U.log("stateHtml Url:: "+"https://www.delwebb.com/api/marker/mapmarkers?brand=Del+Webb&state=" + string + "&qmi=false");
		//	U.log("stateData Url:: "+"https://www.delwebb.com/API/community/Search?qmi=false&brand=Del+Webb&state="
		//			+ string + "&productType=community&pageSize=99&pageNumber=0&flag=state&data=" + string);
			String[] comdata1 = U.getValues(stateData, "<hr class=\"visible-xs\" />", "<hr class=\"visible-xs\">");
			String[] comdata = U.getValues(stateHtml, "{\"Id\":", "\"exact\"");
			 U.log("comdata length::"+comdata.length);
			 U.log("comdata1 legth"+comdata1.length);
			for (int i = 0; i < comdata.length; i++) {
//				if (comdata[i].contains("cypress-falls-at-the-woodlands-209208")) {
//					U.log(string);
//					break;
//				}
				
				comData.add(comdata1[i] + comdata[i]);
			}
	//	}
	}
		 U.log(comData.size());
		Iterator<String> ite = comData.iterator();
		while (ite.hasNext()) {
			String data = ite.next();
			
			String url = U.getSectionValue(data, "<a href=\"", "\"");
			U.log("URL"+url);
			if(!url.contains("http")) url = Builder_Url + url;
		//	U.log("dta---------"+data);
//			try {
				addDetails(data, url);
//			} catch (Exception e) {}
			
			
		}

		LOGGER.DisposeLogger();
 
	}
	
	// ===================================================Community
	// Info=======================================================================
	//TODO :
	private void addDetails(String comSec, String comUrl) throws Exception {
		
//		try{
//			if (j <= 30)
//		if (j >= 9)
		{
			comSec =  StringEscapeUtils.unescapeJava(comSec);
			
//	if(!comUrl.contains("https://www.delwebb.com/homes/illinois/chicago/aurora/lincoln-prairie-by-del-webb-210962")) return;
			
			U.log("\ncount::" + j + "\ncomUrl::" + comUrl);
			U.log("Path::" + U.getCache(comUrl));
			
			if (comUrl.contains("www.pulte.com")) {
				LOGGER.AddCommunityUrl("*****************PulteHhome**************" + comUrl);
				dup++;
				return;
			}
			
			if (comUrl.contains("www.divosta.com")) {
				LOGGER.AddCommunityUrl("*****************DivostaHomes**************" + comUrl);
				dup++;
				return;
			}
			
			if (comUrl.contains("https://www.delwebb.com/homes/texas/houston/richmond/del-webb-sweetgrass-16365")) {
				LOGGER.AddCommunityUrl("*****************Redirected**************" + comUrl);
				dup++;
				return;
			}
			
//			if(!comUrl.contains("https://www.delwebb.com/homes/arizona/phoenix/buckeye/sun-city-festival-11852")) return;
			
			if (this.data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			
			String comHtml = U.getHTML(comUrl).replaceAll("<div class=\"hours-item(.*?)</div|u-noPad\">Coming Soon</span>|<div class=\"StatusTag\">Last Chance</div>", "");
			//U.log("comHtml--"+comHtml);
			
			String unitSection = ALLOW_BLANK;
			if(comHtml.contains("<h2></strong>Homesite Map</strong> </h2>")) {
				unitSection = U.getSectionValue(comHtml, "<h2></strong>Homesite Map</strong> </h2>", "Open Interactive Map");
				U.log("unitSection-1: "+unitSection);
				if(unitSection == null && comHtml.contains("<div class=\"Lot-cta\">")) {
					unitSection = U.getSectionValue(comHtml, "<div class=\"Lot-cta\">", "See Available Homesites");
					U.log("unitSection-2: "+unitSection);
				}
			}
			
			String comDetails=U.getSectionValue(comHtml, "CommunityHero__about\"","</div>");
			
			String statusSec=U.getSectionValue(comHtml, "<h4 class=\"CommunityHero__status\" data-automation=\"communityStatus\">", "</h4>");
			U.log("statusSec: "+statusSec);
//			String statusSec2=U.getSectionValue(comHtml, "<h4 class=\"status\">", "</h4>");

			// ======================================= remove
			// Sec==================================
			String rem = U.getSectionValue(comHtml, "nearbyMarkers =", "</script>");
			if (rem != null)comHtml = comHtml.replace(rem, "");
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "community-name\">", "<");
			U.log("Com Name::::::::" + comName);
			if(comName ==null) {
				comName = U.getSectionValue(comSec, "community-name|Del Webb\">", "<");
			}
			if(comName ==null) {
				comName = U.getSectionValue(comSec, "\"Name\":\"", "\"");
			}
			if(comName ==null) {
				comName = U.getSectionValue(comHtml, "<title>", "|");
			}
			
			comName = comName.replaceAll("Del Webb at |Del Webb | By Del Webb|Del Webb&#174;  - |&#174;| by Del Webb", "");
			U.log("Com Name_One::::::::" + comName);
			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			comSec = comSec.replace("Del Webb Sweet Grass", "");
			add[0] = U.getSectionValue(comSec, "Street1\":\"", "\"");
			add[0] = add[0].replace("Off Bayshore Rd. 1 mile west of I-75", "Off Bayshore Rd");
			
			add[1] = U.getSectionValue(comSec, "City\":\"", "\"");
			add[2] = U.getSectionValue(comSec, "State\":\"", "\"");
			add[3] = U.getSectionValue(comSec, "ZipCode\":\"", "\"");
			U.log(Arrays.toString(add));
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latlong[0] = U.getSectionValue(comSec, "Latitude\":\"", "\"");
			latlong[1] = U.getSectionValue(comSec, "Longitude\":\"", "\"");
			U.log(Arrays.toString(latlong));

			if ((add[0] == null ||add[0].length()==0) && latlong[0] != null) {

				add = U.getAddressGoogleApi(latlong);
				
				geo = "TRUE";
			}
			if (add[0] != null && latlong[0] == null) {

				latlong = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			// ==============================================================Price &&
			// SF============================================
//			U.log(comSec);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec = comSec.replaceAll("0s|0S|0's|0&#39;s", "0,000");
			comHtml = comHtml.replaceAll("0s|0S|0's|0&#39;s", "0,000").replaceAll("\"ComingPriceRange\":\"\\$\\d{3},\\d{3}\"", "");
			comHtml = comHtml.replaceAll("\\$\\d+,\\d+ / \\d% assessment|Lot assessed at \\$\\d+,\\d+|options equaling \\$\\d+,\\d+ that are made available by Del Webb|\\$\\d+,\\d+ in options|Over \\d+,\\d+ square feet|data-value u-no-empty-collapse stat-line\">\\s*\\$\\d+,\\d+\\s*</div>\\s*<div class=\"data-label\">Was|\\$\\d+,\\d+ in Savings|<div class=\"data-value u-no-empty-collapse\">\\s*\\$\\d+,\\d+\\s*</div", "");
			comHtml=comHtml.replace("0Ks","0,000");
			
//			U.log(Util.matchAll(comSec, "[\\w\\s\\W]{60}\\$482,990[\\w\\s\\W]{60}", 0));
			String[] prices = U.getPrices(comHtml + comSec.replaceAll("\"ComingPriceRange\":\"\\$\\d{3},\\d{3}\"", ""), "From \\$\\d{3},\\d{3}|<div class=\"CommunityHero__startingAtData\">\\s+\\$1,029,990\\s+</div>|<div class=\"starting-at-data\">\\s+\\$\\d,\\d{3},\\d{3}\\s+</div>|starting-at\">\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			comHtml=comHtml.replaceAll("ith an anticipated opening date of Summer 2022, you can expect 8,100 square feet full of uproarious fun|8,100 square foot Amenity Center", "");
			String[] sqft = U.getSqareFeet(comHtml,
					"\\d,\\d{3} to \\d,\\d{3} sq|\\d,\\d{3} - \\d,\\d{3} sf.|<h4>\\s+\\d{3}\\s+</h4>|\\d,\\d{3} � \\d,\\d{3} square feet|<div class=\"td\">\\d,\\d{3}</div>|from \\d,\\d{3}–\\d,\\d{3} sq.ft.|\\d{1},\\d{3} to more than \\d{1},\\d{3} Sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} Sq.Ft.|\\d{4}-\\d{4} SF|\\d{1},\\d{3}–\\d{1},\\d{3} sq. ft.|<h4>\\d{1},\\d{3}</h4>|<h4>\\d{3,4}</h4>|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.| \\d{1},\\d{3}\\+ Square Feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+\\+ sq. ft.|\\d,\\d+ to \\d,\\d+\\+ square feet|\\d,\\d+-\\d,\\d+\\+ Sq. Ft.|\\d+ - \\d+\\+ Square Feet|\\d,\\d+-\\d,\\d+\\+Square Feet|\\d,\\d+-\\d,\\d+\\+Sq. Ft.|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+\\+ Sq. Ft.|\\d{1},\\d{3} Square Feet|\\d,\\d+-\\d,\\d+ S.F.|\\d{4}-\\d{4} sq ft|From \\d{1},\\d{3} sq. ft|<h4>\\s*\\d,\\d{3}\\+*\\s*</h4>|ranging from \\d,\\d{3}-\\d,\\d{3} sq ft|homesite, at least \\d+,\\d{3} sf",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);

			//============= Home Data =================
			String homeUrlSection[] = U.getValues(comHtml, "HomeDesignCompact__title\">", "</div>");
			int x = 0;
			String combinedHomeHtml = null;
			for(String homeSec : homeUrlSection){
				String homeUrl = U.getSectionValue(homeSec, "<a href=\"", "\"");
				if(!homeUrl.contains("http")) homeUrl = Builder_Url + homeUrl;
				if(x++ == 5) break;
				U.log("homeUrl ::"+homeUrl);
				String homeHtml = U.getHTML(homeUrl);
				try{
				combinedHomeHtml += U.getSectionValue(homeHtml, "data-description=\"", "\"") + U.getSectionValue(homeHtml, "<div class=\"Inspiration-copy\">", "</button>");
				}catch(Exception e){}
			}
			// ==============================================================Community
			// type============================================
			
			rem = U.getSectionValue(comHtml, "<div class=\"Disclaimer", "</div>");
			if(rem != null) comHtml = comHtml.replace(rem, "");
			comHtml = comHtml.replaceAll("(empty-collapse\">\\s+|completion\">)Coming", "");
			comHtml = comHtml.replaceAll("Active Adult</a>|\"del webb active adult|located in a master-planned community with new construction|active adults\\.\"|del webb active adult|masterplan of Nocatee|premier over 55 living at Sun|jpg shot for Pulte 55 active adult|master planned community. The Hilltop Club|=\"HOA\"|>\\s*HOA\\s*</div>|Amenities </strong><em>\\(coming 2019\\)</em>|find active-adult communities|Pulte Homes&#174; Active Adult|del webb active adult communities|Private Lake Access", "");
			comHtml= comHtml.replace("community for those 55", "seniors 55 and over").replace("renowned golf", "Golf Course");
			comHtml = U.getNoHtml(comHtml);
			String comType = ALLOW_BLANK;
			comSec = comSec.replace("Live in a waterfront paradise", "Live in a waterfront community paradise");
			comType = U.getCommType(comSec+comHtml.replace("active adults 55 and greater", "active adults 55+").replace("&amp;", "&"));

			// ==============================================================Property
			// type============================================
			
			U.log("::::::::::::::::::::"+Util.match(comSec, ".*?gated.*?"));
			String propType = ALLOW_BLANK;
			
			comHtml=comHtml.replaceAll("Villas are only available|Each Villa is a|Luxurious Owners Bath|Luxurious owners bath|Vacation Villa Kitchen|This single family home series includes plans from 978 - 2|Single family homes from 1,600 to 2,831| series of single-family home designs within the master-plan", "")
					.replace("Craftsman | Stone", "Craftsman-style home")
					.replaceAll("luxurious owner&#39;s suite|luxurious owner's suite", "luxury homes");
			comSec=comSec.replace("single-family home designs within the master-plan", "");
			propType = U.getPropType(comHtml+comSec+combinedHomeHtml);
//			U.log("::::::::::::::::::::"+Util.match(comSec+comHtml, ".*?masterplan.*?"));
//			U.log("MMMMMMMMMMMMMMm "+comSec);

			// ==============================================================Property
			// type============================================
			String dType = ALLOW_BLANK;
			
			comHtml  =comHtml.replaceAll("Multi-level countertop|LocationSelectionData.locations =(.*?)}\\];", "");//remove script
			
			comHtml=comHtml.replace("single- and two-level home designs", "one story and 2-story").replaceAll("1-level", "one-story").replaceAll("First Floor Owner&#39;s Suites|First Floor Owner's Suites|[R|r]ancho|(f|F)irst (f|F)loor|(f|F)loor", "");
			comSec=comSec.replaceAll("[R|r]ancho ", "").replaceAll("one- and two-level designs|single- and two-level home designs", "one story and 2-story");
			//U.log("MMM"+Util.matchAll(comHtml + comSec,"[\\w\\W\\s]{30}second story[\\w\\W\\s]{30}", 0));
			dType = U.getNewdCommType((comHtml + comSec + combinedHomeHtml).replaceAll("Alamo Ranch|Branch|branch|Desert Ranch|ancho|Lakewood Ranch|past Taylor Ranch Trail|LakewoodRanch|-Ranch|-ranch|kitchen features multi-level|first floor|(f|F)loor", ""));
			//U.log("::::::::::::::::::::"+Util.match(comHtml, ".*?ranch.*?"));


			// ==============================================================Property
			// Status============================================
			//U.log(o);
			comHtml= U.removeSectionValue(comHtml, "Model Grand", "Request Info");
			//U.log("_______________________"+comHtml+"-----------------------------");
//			
			comHtml=comHtml==null?"":comHtml;
			comHtml = comHtml.replaceAll("Amenity Now|Center Now|Amenities now|caption\">New Homes Coming|description=New Homes Coming Soon\"|\"New Homes Coming Soon\"", "");
			comSec = comSec
					.replace("</span> Home Designs Available", " Home Designs Available")
					.replaceAll("Coming soon! Carolina|Details coming soon|Grand Opening anticipated for June,|community\\. Now ", "")
					.replace("<p>Coming Soon!</p>", "").replaceAll("Coming soon from the high", "")
					.replaceAll("PriceStatus\":\"Price Coming", "").replaceAll("\"CommunityStatus\":\"Coming", "")
					.replaceAll("\"PriceStatus\":\"Price Coming Soon\"","").replaceAll("\"CommunityStatus\":\"Coming Soon\"","");
			
			comHtml = comHtml.replaceAll("session is sold out|calendar is now open|session-is-sold-out!-see-details|guarantee all homes sold by Seller|currently sold out of tickets|The Estates collection is now available and nearly 50% sold out|Celebrate the Grand Opening |Orlando community is actively selling|Amenity Center Grand Opening|our grand opening event|Spa [G|g]*rand [O|o]*pening|[M|m]*odel [P|p]*ark [G|g]*rand [O|o]*pening|residents with unlimited opportunities|data-alt=\".*\"|<span class=\"caption\">.*</span>|data-image-caption=\".*\"|Coming Soon - Multi-Use Trails|Coming Soon - Resistance Pool|Coming Soon - Community Garden|Coming Soon - Dog Park|Coming Soon - Bocce Ball|Coming Soon - Community Poo|The Meridian - Coming Soon|Cluhouse Opening Late 2019|, coming late 2018\\s*|your last chance to own at Carolina |move-in are now selling|Park, coming late 2018|model homes that are opening soon|Homes are selling fast|miss the final chance|Network is now available|features now available|approaching sellout and the final opportunities |Join Us for a New Phase Release|Available in early 2018|ready for move-in early 2018", "")
					.replace("new section of private homesites are now available", "new section now available")
					.replace("final phase is now selling", "final phase now selling")
					.replaceAll("Coming Soon - Satellite Pool|Quick Move|quick move|Homesites Available October", "")
					.replaceAll("Coming soon from the high|Construction Now|Ready to Move in In January|Final Phase - Vista|opening September 21st", "")
					.replaceAll("<div class=\"StatusTag\">Sold Out</div>|Models Now Open|House Now Open|PriceStatus\":\"Price Coming", "").replaceAll("\"CommunityStatus\":\"Coming", "")
					.replaceAll("\\s+|<p>Temporarily Sold Out</p>", " ")
					.replaceAll("offices are now|Satellite Pool - Coming|Coming Soon - Satellite|Sold Out <img class=|cta=\"\" > Coming soon <i|Coming soon! Carolina|caption\">Coming soon</span>|Coming soon\"|Construction Coming Soon|\"CommunityStatus\":\"Coming", "");
//			U.log(comSec);
//			U.log("::::::::::::::::::::"+Util.match(comHtml.replaceAll("Coming Soon: |Coming Soon: 17,000 Sq. Ft. Clubhouse|Coming Soon - The Meridian|description=Coming Soon - |data-image-caption=\"Coming Soon -|<span class=\"caption\">Coming Soon - |data-alt=\"Coming Soon - |Coming Soon - Bocce Ball|Coming Soon - Community Pool|The Meridian - Coming Soon|Rec Center Coming Soon|Coming soon to Sun City Festival", "").replace("Coming Soon!", "").replace("Price Coming Soon", "").replace("our coming soon Lifestyle Director", "").replace("Details coming soon", ""), "[\\w\\s\\w]{30}Spring 2020[\\w\\s\\W]{30}"));
			
//			U.log(comSec);
			comSec = comSec.replace("we’re 90% sold", "");
			
			//U.log(comHtml);
			comHtml = comHtml.replace("Opening in Mid-2022", "Opening Mid 2022").replace("Opening in Early 2022", "Opening Early 2022").replace("Opening in Late 2021", "Opening Late 2021").replaceAll("Like Coming soon|> Coming Soon <|Price Coming Soon|Webb Oasis is a coming soon","").replace("100% Financing Through USDA", "USDA 100% Financing Through ").replace("Opening in Mid-2022", "Opening Mid 2022")
					.replace("Opening in Late 2022", "Opening Late 2022")
					.replace("Coming in Late 2021", "Coming Late 2021")
					.replace("Opening in Early 2023", "Opening Early 2023")
					.replace("Opening in Early 2022", "Opening Early 2022").replace("Opening in Late 2022", "Opening Late 2022");
			
	//		U.log("??????????????11"+Util.matchAll(statusSec+comSec +comDetails,"[\\w\\s\\W]{30}Coming Soon[\\w\\s\\W]{30}",0));

			
			String propertyStatus = U.getNewPropStatus((statusSec+comSec +comDetails)
					.replaceAll("New Homes Coming Soon to Del Webb North Myrtle Beach|Classic Series now selling|Coming soon just North|col-sm-6 Coming soon|Like Coming soon|> Coming Soon <|Price Coming Soon|Webb Oasis is a coming soon","").replaceAll("campus is now open|Complex is Now Open|Opening 2021, Del Webb","")
					+ comHtml.replace("Coming Soon to Nassau County|New Homes Coming Soon to Del Webb North Myrtle", "Coming Soon to Del Webb North Myrtle")
					.replaceAll("Passport series are coming soon|Model Park Now Open|Coming Soon to Nassau County|Del Webb is now open. Click/Call|Oxford Greens by Del Webb is coming soon|our of the beautiful amenity, coming soon|Coming Soon - Clubhouse|Coming Soon Pickle Ball Courts|The Flats at Montebello Coming Soon|Classic Series now selling|Clubhouse is now open|Coming Soon Classes|Coming Soon-Resort|Coming Soon Pickle|day Coming Soon|Sold Out Elevation|condos coming later|grand opening event|grand opening detail|<div class=\"StatusTag\" data-automation=\"\">Sold Out</div>|coming 201\\d|Clubhouse Grand|Last Chance <img|Campus, Now Open|Complex is Now Open|campus is now open|Coming soon just North|col-sm-6 Coming soon|Price Coming Soon|Webb Oasis is a coming soon|Coming soon to Manatee|campus is now open|Complex is Now Open|Opening 2021, Del Webb|Garden COMING|Park COMING SOON|Coming Soon <i data-tool|caption\">Coming Soon|\"Coming Soon\"|amenities coming soon|Models are Now Open|Innsbrook are now open|Now Available Now Anticipated|final phase!\"|Ready To Move In Now\\?| Crosswater Park \\(Opening Spring 2020|Lifestyle House Coming Spring 2020|Amenity Opening Spring 2020|Coming Soon Pickle Ball Courts|<p>Temporarily Sold Out</p>|StatusTag\">Sold Out</div>|Marketplace Coming Soon|CtaQmiText\":\"2 Quick Move-Ins|ata-alt=\n" + 
					">\n*\\s*\n*\\s*\n*\\s*\n*\\s*\n*\\s*New Homes Coming Soon|Stunning home ready for move in |opening, amenities|Now Open in Westfield|Brand New Homes Available Now|caption\">New Homes Coming|description=New Homes Coming Soon\"|\"New Homes Coming Soon\"|Canyon Coming|Pine Spring Coming|Overlook Coming Soon|Price Coming|Pictures coming soon|Resort Now Open|New Neighborhood Grand Opening Event|Join Us at Our Amenity Grand Opening on December 14th|Quick Move In Last Chance|Grand Opening anticipated |get ready for our grand opening coming Summer|Almost Sold Out! The Villa|Coming Soon: |Coming Soon - The Meridian|description=Coming Soon - |data-image-caption=\"Coming Soon -|<span class=\"caption\">Coming Soon - |data-alt=\"Coming Soon - |Coming Soon - Bocce Ball|Coming Soon - Community Pool|The Meridian - Coming Soon|Rec Center Coming Soon|Coming soon to Sun City Festival", "").replace("Coming Soon!", "").replace("Price Coming Soon", "").replace("our coming soon Lifestyle Director", ""));
			
			U.log("propertyStatus: "+propertyStatus);
//			U.log("??????????????"+Util.matchAll(statusSec+comSec +comDetails ,"[\\w\\s\\W]{30}Coming Soon[\\w\\s\\W]{30}",0));
//			U.log("??????????????"+Util.matchAll(comHtml,"[\\w\\s\\W]{30}Coming Soon[\\w\\s\\W]{30}",0));

//			U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll( comHtml.replaceAll("\\s+|<p>Temporarily Sold Out</p>|Coming Soon-Resort|Coming Soon Pickle", " ")
//					, "[\\s\\w\\W]{30}Coming Soon[\\s\\w\\W]{40}", 0));
		//	U.log("_______________________"+comHtml+"-----------------------------");
			//comHtml = comHtml.replace("Patio.jpg", "");
			propertyStatus=propertyStatus.replace("Final Opportunity,10 Opportunities Remain", "Final 10 Opportunities Remain")
					.replace("Quick Move-ins Available", "Quick Move-ins");
			if(comUrl.contains("/maryland/dc-metro/clarksburg/courts-of-clarksburg-209869"))
				propertyStatus=propertyStatus.replace("New Section Now Available,Now Available", "New Section Now Available");
			if(comUrl.contains("/florida/jacksonville/jacksonville/del-webb-etown-210300")||comUrl.contains("/florida/jacksonville/ponte-vedra/del-webb-nocatee-210299")|| comUrl.contains("/ohio/columbus/new-albany/nottingham-trace-210258"))
				{propertyStatus=propertyStatus.replace("Coming Soon,","");}	
//			if(comUrl.contains("/florida/orlando/davenport/del-webb-orlando-11890"))propertyStatus=propertyStatus.replace(", Now Selling","");
		    
			String notes = U.getnote(comHtml.replace("12:00PM - 6:00PM Pre-Selling Offsite at", ""));
			
			U.log("notes: "+notes);
			//U.log(">>>>>>>>>>>>>>>>>"+Util.matchAll(comHtml ,"[\\w\\s\\W]{30}selling[\\w\\s\\W]{30}",0));
			
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]).trim();
			}
			if (comUrl.contains("https://www.delwebb.com/homes/indiana/indianapolis/plainfield/vandalia-by-del-webb-209483")) {
				propertyStatus=propertyStatus.replaceAll(", New Homesites Available|, Now Available", "");
			//	propertyStatus=propertyStatus+", New Phase of Lots Now Available";
			}
			//if(comUrl.contains("/jacksonville/ponte-vedra/del-webb-nocatee-21029"))propertyStatus=propertyStatus+", Coming Soon";
			add[0] =add[0].replace("County Road 101 + County Road 30", "County Road 101").replaceAll("GPS: ", "");
			
			if (comUrl.contains("del-webb-in-chambers-creek-210915"))propertyStatus="Coming Soon In 2022"; 
			if(comUrl.contains("illinois/chicago/aurora/lincoln-prairie-by-del-webb-210962")) propertyStatus="Coming Soon, "+propertyStatus;  //from Img
			if (comUrl.contains("https://www.divosta.com/homes/florida/sarasota/venice/islandwalk-at-the-west-villages-16219")) propertyStatus = propertyStatus.replace(", Sold Out", "");
			if(propertyStatus.contains("Final Opportunity, 10 Opportunities Remain") && comHtml.contains("Final 10 Opportunities Remain"))propertyStatus=propertyStatus.replaceAll("Final Opportunity, 10 Opportunities Remain", "Final 10 Opportunities Remain");
			if (comUrl.contains("https://www.delwebb.com/homes/arizona/tucson/marana/del-webb-at-dove-mountain-209187")) propertyStatus = propertyStatus.replace("New Homes Available, ", "");
			if(comUrl.contains("https://www.delwebb.com/homes/south-carolina/hilton-head/bluffton/sun-city-hilton-head-12002")) propertyStatus="New Plans Now Available";  //from Img
			propertyStatus = propertyStatus.replaceAll("\\d+ Quick Move-ins Available|Quick Move-in Homes", "Quick Move-ins");
			if (comUrl.contains("https://www.delwebb.com/homes/texas/dallas/little-elm/del-webb-at-union-park-210013"))minPrice="$288,990";
			//@added on 13 July 21
//			if(comUrl.contains("https://www.delwebb.com/homes/pennsylvania/philadelphia/hatfield/del-webb-north-penn-210651") && !propertyStatus.contains("Coming Soon")){
//				if(propertyStatus.length() < 5 || propertyStatus == ALLOW_BLANK)propertyStatus = "Coming Soon";
//				else if(propertyStatus.length() > 5) propertyStatus += ", Coming Soon";
//			}
//				if(comUrl.contains("https://www.delwebb.com/homes/south-carolina/hilton-head/bluffton/sun-city-hilton-head-12002")) {
//					propertyStatus+=", Quick Move-ins";
//				}
				
//				if(comUrl.contains("del-webb-at-river-islands-210653") ){
//					if(propertyStatus.length() < 5 || propertyStatus == ALLOW_BLANK)propertyStatus = "Opening Late 2022";
//					else if(propertyStatus.length() > 5) propertyStatus += ", Opening Late 2022";
//				}
				
				if(comUrl.contains("jacksonville/del-webb-etown-210300") )
					propertyStatus=propertyStatus.replace("Quick Move-ins, ", "");
				
		//=============================== Number of Units ================
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;		
		String jsonData = ALLOW_BLANK; String jsonLink = ALLOW_BLANK;	
		
		if(unitSection != null) {
			String mapUrl = U.getSectionValue(unitSection, "href=\"", "\"");
			U.log("mapUrl: "+mapUrl);
			
			if(mapUrl != null) {
				if(mapUrl.contains("OLAId=") && mapUrl.contains("&amp")) {
					String subMapUrl = U.getSectionValue(mapUrl, "OLAId=", "&amp");
					U.log("subMapUrl-1: "+subMapUrl);
					
					if(subMapUrl.contains("==") || subMapUrl.contains("+")) {
						String subMapUrlEncode = URLEncoder.encode(subMapUrl, "UTF-8");
						String guiIdLink = "https://services.alpha-vision.com/api/apiola/IsAlphamapActive?olaId=" + subMapUrlEncode;
						U.log("guiIdLink: "+guiIdLink);
						String guiHtml = U.getHTML(guiIdLink);
						U.log(U.getCache(guiIdLink));
						String guiId = U.getSectionValue(guiHtml, "\"GUID\":\"", "\"");
						U.log("guiId: "+guiId);
						
						String jsonUrl = "https://apps.alpha-vision.com/olajson/" + guiId + ".json";
						U.log("jsonUrl guiId: "+jsonUrl);
						jsonLink = jsonUrl;
					}
					else {
						String jsonUrl = "https://apps.alpha-vision.com/olajson/" + subMapUrl + ".json";
						U.log("jsonUrl_One: "+jsonUrl);
						jsonLink = jsonUrl;
					}
					
				} 
				else {
					String[] sub =  mapUrl.split("OLAId=");
					String subMapUrl = sub[1];
					U.log("subMapUrl-2: "+subMapUrl);				
					
					String jsonUrl = "https://apps.alpha-vision.com/olajson/" + subMapUrl + ".json";
					U.log("jsonUrl_Two: "+jsonUrl);
					jsonLink = jsonUrl;
				}
			}

		}
		
		U.log("jsonLink Final: "+jsonLink);
		if(jsonLink != ALLOW_BLANK) {
			jsonData = U.getPageSource(jsonLink);
			U.log(U.getCache(jsonLink));
			
			//String[] lotCounts = U.getValues(jsonData, "\"LotCount\":", ",\"");
			String[] lotCounts = U.getValues(jsonData, "\"LotLabel\":\"", "\"");
			U.log("lotCounts: "+lotCounts.length);
			for(String lot:lotCounts) {
				//U.log(lot);
			}
			
			int totalUnits = lotCounts.length;
			units = String.valueOf(totalUnits);
			U.log("units: "+units);
		}
			
		
		
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(notes);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}

}