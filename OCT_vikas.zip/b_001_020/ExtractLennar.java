/**
 * @author Upendra
 * Date- July 12 2018
 */
package com.shatam.b_001_020;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLennar extends AbstractScrapper {
	CommunityLogger LOGGER;
	int j = 0, k = 0;
//	WebDriver driver = null;

	int totalNum = 0;
	int subComCount = 0; 
	static String postUrl = "https://www.lennar.com/api/graphql";

	public static void main(String[] args) throws Exception {

		long startTime = System.currentTimeMillis();
		AbstractScrapper a = new ExtractLennar();
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "Lennar Homes.csv", a.data().printAll());
		long endTime = System.currentTimeMillis();
		U.log(endTime - startTime);
	}

	public ExtractLennar() throws Exception {
		super("Lennar Homes", "https://www.lennar.com/");
		LOGGER = new CommunityLogger("Lennar Homes");
	}
	
	public void innerProcess() throws Exception {
		//String payLoad = "{\"operationName\":\"SearchResultsQueryNew\",\"variables\":{\"context\":{\"first\":5000},\"filters\":[{\"code\":\"homesiteMapCoordinates\",\"options\":[\"76.31396647474268\",\"-42.316978875\",\"-37.28814238478955\",\"-154.992760125\"]},{\"code\":\"commMapCoordinates\",\"options\":[\"76.31396647474268\",\"-42.316978875\",\"-37.28814238478955\",\"-154.992760125\"]}]},\"query\":\"query SearchResultsQueryNew($context: SearchContextInputType, $filters: [SearchFilterInputType!]) {\\n  filteredSearch(context: $context, filters: $filters) {\\n    communityMapResults {\\n      ...SearchResultsMapFragment\\n      __typename\\n    }\\n    homesiteMapResults {\\n      ...SearchResultsMapFragment\\n      __typename\\n    }\\n    pagedCommunityResults {\\n      community {\\n        ...SearchResultsPagedCommunityFragment\\n        __typename\\n      }\\n      mpc {\\n        ...SearchResultsPagedMpcFragment\\n        __typename\\n      }\\n      __typename\\n    }\\n    pagedHomesiteResults {\\n      homesite {\\n        ...SearchResultsPagedHomesiteFragment\\n        __typename\\n      }\\n      plan {\\n        ...SearchResultsPagedPlanFragment\\n        __typename\\n      }\\n      __typename\\n    }\\n    totalCommunityResults\\n    totalHomesiteResults\\n    __typename\\n  }\\n}\\n\\nfragment SearchResultsMapFragment on MapResultType {\\n  id\\n  communityLocation\\n  parentBounds\\n  parentId\\n  latitude\\n  longitude\\n  text\\n  status\\n  type\\n  __typename\\n}\\n\\nfragment SearchResultsPagedCommunityFragment on CommunityType {\\n  ...TooltipFragmentCommunity\\n  number\\n  mapOutline\\n  mapBounds\\n  types\\n  __typename\\n}\\n\\nfragment TooltipFragmentCommunity on CommunityType {\\n  name\\n  heroImage {\\n    ...Image\\n    __typename\\n  }\\n  status\\n  name\\n  city {\\n    ...CityFragment\\n    __typename\\n  }\\n  badge\\n  basePrice\\n  overview\\n  url\\n  id\\n  customPrice\\n  __typename\\n}\\n\\nfragment Image on ImageType {\\n  alt\\n  url\\n  __typename\\n}\\n\\nfragment CityFragment on CityType {\\n  name\\n  market {\\n    code\\n    state {\\n      code\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SearchResultsPagedMpcFragment on MpcType {\\n  ...TooltipFragmentMpc\\n  communities {\\n    basePrice\\n    number\\n    mapBounds\\n    types\\n    __typename\\n  }\\n  mapOutline\\n  __typename\\n}\\n\\nfragment TooltipFragmentMpc on MpcType {\\n  name\\n  heroImage {\\n    ...Image\\n    __typename\\n  }\\n  status\\n  name\\n  city {\\n    ...CityFragment\\n    __typename\\n  }\\n  overview\\n  url\\n  id\\n  customPrice\\n  searchPrice\\n  __typename\\n}\\n\\nfragment SearchResultsPagedHomesiteFragment on HomesiteType {\\n  id\\n  elevationImage {\\n    ...ElevationImage\\n    __typename\\n  }\\n  status\\n  address\\n  baths\\n  beds\\n  price\\n  badge\\n  sqft\\n  url\\n  plan {\\n    name\\n    customPrice\\n    startingPrice\\n    community {\\n      name\\n      priceRange\\n      stateCode\\n      city {\\n        name\\n        market {\\n          code\\n          __typename\\n        }\\n        __typename\\n      }\\n      mpc {\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    elevationImages {\\n      image {\\n        ...Image\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment ElevationImage on TitleImageType {\\n  image {\\n    ...Image\\n    __typename\\n  }\\n  desc\\n  title\\n  __typename\\n}\\n\\nfragment SearchResultsPagedPlanFragment on PlanType {\\n  id\\n  name\\n  url\\n  sqft\\n  beds\\n  baths\\n  badge\\n  halfBaths\\n  customPrice\\n  startingPrice\\n  status\\n  number\\n  heroImage {\\n    ...Image\\n    __typename\\n  }\\n  elevationImages(first: 1) {\\n    image {\\n      url\\n      alt\\n      __typename\\n    }\\n    __typename\\n  }\\n  community {\\n    name\\n    mpc {\\n      name\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}";
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();

//		String mainHtml=getHtml("https://www.lennar.com/find-a-home?tab=1&zoom=4",driver);
		
		String payLoad = "{\"operationName\":\"SearchResultsQueryNew\",\"variables\":{\"context\":{\"first\":5000},\"filters\":[{\"code\":\"homesiteMapCoordinates\",\"options\":[\"76.96377741792551\",\"-48.206937616576994\",\"-39.492261192976244\",\"-149.105375116577\"]},{\"code\":\"commMapCoordinates\",\"options\":[\"76.96377741792551\",\"-48.206937616576994\",\"-39.492261192976244\",\"-149.105375116577\"]}]},\"query\":\"query SearchResultsQueryNew($context: SearchContextInputType, $filters: [SearchFilterInputType!]) {\\n  filteredSearch(context: $context, filters: $filters) {\\n    communityMapResults {\\n      ...SearchResultsMapFragment\\n      __typename\\n    }\\n    homesiteMapResults {\\n      ...SearchResultsMapFragment\\n      __typename\\n    }\\n    pagedCommunityResults {\\n      community {\\n        ...SearchResultsPagedCommunityFragment\\n        __typename\\n      }\\n      mpc {\\n        ...SearchResultsPagedMpcFragment\\n        __typename\\n      }\\n      __typename\\n    }\\n    pagedHomesiteResults {\\n      homesite {\\n        ...SearchResultsPagedHomesiteFragment\\n        __typename\\n      }\\n      plan {\\n        ...SearchResultsPagedPlanFragment\\n        __typename\\n      }\\n      __typename\\n    }\\n    totalCommunityResults\\n    totalHomesiteResults\\n    __typename\\n  }\\n}\\n\\nfragment SearchResultsMapFragment on MapResultType {\\n  id\\n  communityLocation\\n  parentBounds\\n  parentId\\n  latitude\\n  longitude\\n  text\\n  status\\n  type\\n  __typename\\n}\\n\\nfragment SearchResultsPagedCommunityFragment on CommunityType {\\n  ...TooltipFragmentCommunity\\n  number\\n  mapOutline\\n  mapBounds\\n  types\\n  __typename\\n}\\n\\nfragment TooltipFragmentCommunity on CommunityType {\\n  name\\n  heroImage {\\n    ...Image\\n    __typename\\n  }\\n  status\\n  name\\n  city {\\n    ...CityFragment\\n    __typename\\n  }\\n  badge\\n  basePrice\\n  overview\\n  url\\n  id\\n  customPrice\\n  __typename\\n}\\n\\nfragment Image on ImageType {\\n  alt\\n  url\\n  __typename\\n}\\n\\nfragment CityFragment on CityType {\\n  name\\n  market {\\n    code\\n    state {\\n      code\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SearchResultsPagedMpcFragment on MpcType {\\n  ...TooltipFragmentMpc\\n  communities {\\n    basePrice\\n    number\\n    mapBounds\\n    types\\n    __typename\\n  }\\n  mapOutline\\n  __typename\\n}\\n\\nfragment TooltipFragmentMpc on MpcType {\\n  name\\n  heroImage {\\n    ...Image\\n    __typename\\n  }\\n  status\\n  name\\n  city {\\n    ...CityFragment\\n    __typename\\n  }\\n  overview\\n  url\\n  id\\n  customPrice\\n  searchPrice\\n  __typename\\n}\\n\\nfragment SearchResultsPagedHomesiteFragment on HomesiteType {\\n  id\\n  elevationImage {\\n    ...ElevationImage\\n    __typename\\n  }\\n  status\\n  address\\n  baths\\n  beds\\n  price\\n  badge\\n  sqft\\n  url\\n  plan {\\n    name\\n    customPrice\\n    startingPrice\\n    community {\\n      name\\n      priceRange\\n      stateCode\\n      city {\\n        name\\n        market {\\n          code\\n          __typename\\n        }\\n        __typename\\n      }\\n      mpc {\\n        name\\n        __typename\\n      }\\n      __typename\\n    }\\n    elevationImages {\\n      image {\\n        ...Image\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment ElevationImage on TitleImageType {\\n  image {\\n    ...Image\\n    __typename\\n  }\\n  desc\\n  title\\n  __typename\\n}\\n\\nfragment SearchResultsPagedPlanFragment on PlanType {\\n  id\\n  name\\n  url\\n  sqft\\n  beds\\n  baths\\n  badge\\n  halfBaths\\n  customPrice\\n  startingPrice\\n  status\\n  number\\n  heroImage {\\n    ...Image\\n    __typename\\n  }\\n  elevationImages(first: 1) {\\n    image {\\n      url\\n      alt\\n      __typename\\n    }\\n    __typename\\n  }\\n  community {\\n    name\\n    mpc {\\n      name\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}";
//		 U.log("SSSSSSSs=="+postUrl+ payLoad);
		String html = U.sendPostRequestAcceptJson(postUrl, payLoad);
//		 U.log(html);
		JsonParser jparser = new JsonParser();
		JsonObject jobj = (JsonObject) jparser.parse(html).getAsJsonObject().get("data");
		JsonObject mainJson = (JsonObject) jobj.getAsJsonObject().get("filteredSearch");
		JsonArray comJson = (JsonArray) mainJson.getAsJsonObject().get("pagedCommunityResults");
		JsonArray HomeJson = (JsonArray) mainJson.getAsJsonObject().get("pagedHomesiteResults");
		U.log("HomeJson.size: "+HomeJson.size());

		//JsonArray comJson = (JsonArray) mainJson.getAsJsonObject().get("communityMapResults");
		U.log("comJson.size: "+comJson.size());
		int count = 0;
		int num = 1;

		for (JsonElement jsonElement : comJson) {

			
//			U.log("jsonElement==="+jsonElement.toString());
			
			// if(jsonElement.toString().contains("copperleaf")) {
			JsonObject communityObject = jsonElement.getAsJsonObject();
			JsonObject maindata;
			if (communityObject.toString().contains("\"mpc\":null,")) {
				maindata = communityObject.getAsJsonObject("community");
			} else {
				maindata = communityObject.getAsJsonObject("mpc");

			}
			JsonElement commurlJson = maindata.get("url");
//			String commurl = "https://www.lennar.com"
//					+ commurlJson.toString().replace("\"", "").replace("https://www.lennar.com/", "") + ".json";
			
			String commurl = "https://www.lennar.com"
					+ commurlJson.toString().replace("\"", "").replace("https://www.lennar.com/", "");
			//U.log(num+"  commurl: "+commurl);
			num++;
			String mainCommHtml = U.getHTML(commurl);
			
			//---- FLOW FOR SUBCOM -----------
			
			if (mainCommHtml.contains("\"communityCount\":")) {
				String communtiesSecs = U.getSectionValue(mainCommHtml, "\"communities\":", "],");
				String communitesRefID[] = U.getValues(communtiesSecs, "{\"__ref\":\"", "\"");
				
				
				for (String communitesRef : communitesRefID) {
					String subCommMainSec = U.getSectionValue(mainCommHtml, "\"" + communitesRef + "\":",
							"\"zipCode\":\"");
//					U.log("subCommMainSec: "+subCommMainSec);
					
					String jsonLink=U.getSectionValue(subCommMainSec, "status\":\"", "\"divisionNumber\":");
					jsonLink = U.getSectionValue(jsonLink, "\"url\":\"", "\"");
					
					commurl = "https://www.lennar.com"+jsonLink;
					
					//U.log("    "+numbs+" subComUrl: "+commurl);
					subComCount++;
					String url = U.getSectionValue(subCommMainSec.replace("\"url\":\"https://cdn.lennar.net", ""), ",\"url\":\"", "\""); //.replaceAll("https://www.lennar.com", "");
					if(!url.startsWith("http")) url = "https://www.lennar.com" + url;
//					U.log("subcommm:"+url);
					
					totalNum++;
					
//					try {
						addDetails(url,"",HomeJson);
						//addDetails("https://www.lennar.com/new-homes/minnesota/minneapolis-st-paul/lakeville/avonlea/the-grove-at-avonlea");
//					} catch (Exception e) {}
					// break;
				}
			} 
			else {
				String url = commurlJson.toString().replace("\"", "");
				if(!url.startsWith("http")) url = "https://www.lennar.com" + url;
//				U.log("mainComUrl: "+url);
				totalNum++;
//				try {
					addDetails(url,jsonElement.toString(),HomeJson);
//				} catch (Exception e) {}

				count++;
				// break;
			}
//			break;
		}
		U.log("mainCom Count: "+count);
		U.log("subCom Count: "+subComCount);
		U.log("TotalCom: "+totalNum);
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	
//	private void addDetails1(String url) throws Exception{
//		url = url.replace("//new-homes", "/new-homes");
//		if (data.communityUrlExists(url)) {
//			LOGGER.AddCommunityUrl(url +"===========Repeated===========");
//			return;
//		}
//		if (url.contains("https://www.lennar.com/new-homes/georgia/atlanta/alpharetta/artisan")){
//			LOGGER.AddCommunityUrl(url+ "=======Redirected=========");
//			return;
//		}
//		LOGGER.AddCommunityUrl(url);
//		
//	}
	
	private void addDetails(String url, String maindata, JsonArray HomeJson) throws Exception {
//		 if(!url.contains("san-francisco-bay-area/lafayette/the-brant/"))return;
//		 if(!url.contains("https://www.lennar.com/new-homes/texas/san-antonio/converse/willow-view"))return;
		 //U.log(U.getCache(url));
//		if (j >=900)
//		if (j >=958 && j<1100)
//		 try{
//		if(j>=1168 && j<1400)
//		if(j>=0 && j<=300) //===
//		if(j>=100) //===
//		if(j>=812 && j<=900) 
//		
//			U.log				 
//		U.log(url);
		{
			url = url.replace("//new-homes", "/new-homes");
			// TODO: Single Run
			
//			 if(url.contains("/images/"))return;

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url +"===========Repeated===========");
				return;
			}
//			if(url.contains("https://www.lennar.com/new-homes/california/la-orange-county/lake-forest/serrano-summit/covera")) {
//				LOGGER.AddCommunityUrl(url+ "---------------------------------ERROR");
//				return;
//			}
			
			if (url.contains("https://www.lennar.com/new-homes/georgia/atlanta/alpharetta/artisan") ||
					url.contains("https://www.lennar.com/new-homes/minnesota/minneapolis-st-paul/rosemount/highlands-of-falmoor-glen")
					||
					url.contains("https://www.lennar.com/new-homes/florida/jacksonville-st-augustine/jacksonville/osprey-landing") 
					||
					url.contains("https://www.lennar.com/new-homes/texas/houston/baytown/sterling-point-at-baytown-crossings/brookstone-collection") 
					||
					url.contains("https://www.lennar.com/new-homes/texas/houston/fulshear/cross-creek-west/brookstone-collection") 
					||
					url.contains("https://www.lennar.com/new-homes/texas/houston/baytown/sterling-point-at-baytown-crossings/wildflower-iv-and-brookstone-collections")
					|| url.contains("https://www.lennar.com/new-homes/texas/san-antonio/san-antonio/the-ridge-at-salado-creek/barrington-collection")
					|| url.contains("https://www.lennar.com/new-homes/texas/san-antonio/san-antonio/the-ridge-at-salado-creek/watermill-collection")) {
				LOGGER.AddCommunityUrl(url+ "=======Redirected=========");
				return;
			}
			
			if (url.contains("https://www.lennar.com/new-homes/california/la-orange-county/west-covina/asteria")
					||url.contains("/georgia/atlanta/marietta/white-oaks")
					||url.contains("/florida/tampa/apollo-beach/lynwood/the-estates")
					||url.contains("new-homes/texas/dallas-ft-worth/crandall/wildcat-ranch")
					||url.contains("san-francisco-bay-area/oakley/woodbury-at-emerson-ranch"))
			{
				return;
			}
			
			

//			if(url != null) return;

			
			U.log("\nCommunity Count: " + j);
			U.log(url);

//			String html = U.getPageSource(url);
//			Thread.sleep(1000);
			String html = U.getHTML(url);
			if(html.contains("/api/images/-/media/Com/Images/Version10/Error/Error")
					||html.contains("Error/Error"))
			{
				LOGGER.AddCommunityUrl(url+ "=======Return=========");

				return;
			}
			LOGGER.AddCommunityUrl(url);
//			U.log("html :"+html);
			String overview=U.getSectionValue(html, "data-testid=\"community-info-paragraph-text\"", " aria-label=\"Legal disclaimers\"")
					+"\n"+U.getSectionValue(maindata, "\"badge\":", ",")
					+"\n"+U.getSectionValue(html, "class=\"Overview_address", "</p>");

			U.log(U.getCache(url));
			String rem="";
			
			
			
			
//			U.log(">>>>>>>>"+U.getSectionValue(html, "\"overview\":\"", "\"ROOT_QUERY\":"));
			String [] homeDesc=U.getValues(html, "\"overview\":\"", "\""); //"\"ROOT_QUERY\":");
			
//			if(html==null)
//				homeDesc=U.getValues(html, "\"overview\":\"", "\"ROOT_QUERY\":");
			
			String homesDescription="";
			for(String hD:homeDesc) {
//				if(hD.contains("\"url\":\""))
				
				homesDescription+=hD;
				//U.log(">>>>>>"+hD);
				
			}
			
			//---------------homes data---------
			String homesData = ALLOW_BLANK;
			String exterior = ALLOW_BLANK;
			String availableExterior = ALLOW_BLANK;
			String oversection=ALLOW_BLANK;
			
			if((html.contains("Explore homes in this collection")||html.contains("Explore homes in this community")
					||html.contains("Explore homes in this community</h2>")
					||html.contains("Explore homes in this collection</h2>"))) {
				
				String homeSec = U.getSectionValue(html, "Explore homes in this collection", "Approximate HOA fees");
				if(homeSec==null)  homeSec = U.getSectionValue(html, "Explore homes in this collection", "Approximate monthly HOA fees");
				if(homeSec==null)  homeSec = U.getSectionValue(html, "Explore homes in this community", "Approximate HOA fees");
				if(homeSec==null)  homeSec = U.getSectionValue(html, "Explore homes in this collection", ">Availability</h2>");
				if(homeSec==null)  homeSec = U.getSectionValue(html, "Explore homes in this community</h2>", ">Availability</h2>");
				if(homeSec==null)  homeSec = U.getSectionValue(html, "Explore homes in this collection</h2>", "Approximate tax rate");

				U.log("homeSec: "+homeSec);
			
				if(homeSec != null) {
					
					String[] homesec = U.getValues(homeSec, "<a class=\"SinglePlan_anchor", "</p></div></div></div></a>"); 
					U.log("home sections: "+homesec.length);
					
					for(String home:homesec) {
						
						//U.log("home: "+home);
						
						String homeLink = U.getSectionValue(home, "href=\"", "\"");
						homeLink = "https://www.lennar.com" + homeLink; 
						U.log("homeLink: "+homeLink);
						
						String homeHtml = U.getHTML(homeLink);
						
						oversection=U.getSectionValue(homeHtml, "\"overview\":\"", "\"");
						if(oversection==null) {
							oversection=ALLOW_BLANK;
						}
						//for exterior
						
						if(homeHtml.contains("elevation-title\">Exterior</h2>") && homeHtml.contains("Included in this home")) {
							
							exterior = U.getSectionValue(homeHtml, "elevation-title\">Exterior</h2>", "Included in this home");
							//U.log("exterior: "+exterior);
						}
						
						//for available exterior
						if(homeHtml.contains(">Available Exteriors<") && homeHtml.contains("Included in this home")) {
							
							String avaExteriorSec = U.getSectionValue(homeHtml, ">Available Exteriors<", "Included in this home");
							
//							U.log("avaExteriorSec: "+avaExteriorSec);
							availableExterior += avaExteriorSec; 
						}
						
						if(homeHtml.contains("{\"props\":{\"pageProps\":")) {
							String exterior1 = U.getSectionValue(homeHtml, "pageProps", "closingCostIncentive");
							exterior+=exterior1;
						}
						
//						U.log("exterior========"+exterior);

					}
				}
				else {
					U.log("------------Home Section Null Here---------------");
				}
			}
			U.log("maindata :"+maindata);
			U.log("overSec :: "+oversection);
			
		//	U.log("YYYY"+Util.matchAll(html,"[\\w\\W\\s]{30}\\$204,999[\\w\\W\\s]{30}",0));
			String remove = U.getSectionValue(html, "<h2 class=\"Typography_subheadlineLarge__1AHKa\">", "Copyright");
			if (remove != null)
				html = html.replace(remove, "");
			 
//			String remove2 = U.getSectionValue(html, "\"homesites\":[", "</script>");
//			if (remove2 != null)
//				html = html.replace(remove2, "");
			// ============= Community Name ============
		//	U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));
			String comNameType = ALLOW_BLANK;

			String comName = U.getSectionValue(html, "{\"pageHead\":{\"title\":\"", "New Home Community");
			//U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{30}pageHead[\\s\\w\\W]{30}", 0));
			if(comName == null) {
				comName = U.getSectionValue(html, "{\"pageHead\":{\"title\":\"", "New Home Plan");
			}
			// {"pageHead":{"title":"
			
			if(url.contains("angeline/villas"))
				comName="Villas At Angeline";
						
			U.log("=========="+comName);
			if (comName != null) {
				comName = comName.replace("\\u0026", "&").replaceAll("[n|N]eighbourhood(s)$\\| Active Adult 55\\+|By Lennar|by LENNAR", "");
			comName=comName.replace("Dartmoor at Mountain Crest at Mountain Crest", "Dartmoor at Mountain Crest");
			comName=comName.replace("Villages at Spring Hill Single Homes at Villages at Spring Hill","Villages At Spring Hill Single Homes");
			comName=comName.replace("Auburn Meadows | Active Adult 55+", "Auburn Meadows");
			comName=comName.replace("Elements at Viridian | Active Adult 55+","Elements At Viridian");
			comName=comName.replace("Brookstone II, Westfield, & Barrington at Potranco Run","Brookstone II, Westfield & Barrington At Potranco Run");
			comName=comName.replace("Lantern Ridge Traditional Townhomes at Lantern Ridge ","Lantern Ridge")
					.replace("Residences II Collection at Fendol Farms","Residences II Collection")
					.replace("The Carnegie at Westside at Shady Grove Metro","The Carnegie")
					.replace("Brookstone Collection at Old Hickory","Brookstone Collection")
					.replace("The Generations Collection at Central Park","The Generations Collection")
					.replace("Lennar at ", "")
					.replace("at Lindera Preserve at Cane Bay Plantation ", "")
					.replace("Horizon Phase II at Cadence","Horizon Phase II").replace("Summit at Northbrook","Summit")
					.replaceAll("Estates | Active Adult 55+ at Heritage El Dorado Hills","Estates at Heritage").replaceAll("River Hall Country Club", "River Hall")
					.replaceAll(" Golf \\u0026 Country Club", "").replaceAll("HeritageWatermill", "Heritage Watermill")
					.replaceAll("HeritageCornerstone", "Heritage Cornerstone").replaceAll("HeritageVenture", "Heritage Venture")
					.replace("(24s) at Carlton North","Carlton North 24s").replace("(20s) at Carlton North","Carlton North 20s")
					.replace("(30s) at Carlton North","Carlton North 30s")
					.replace("Heather Ridge Duplex", "Heather Ridge")
					.replace("Frisco Springs Lakeside", "Frisco Springs")
					.replace("Shale Creek Cottage", "Shale Creek")
					.replace("Liberty Villas", "Liberty")
					.replace("Row Collection at Stonoview on Johns Island", "Row Collection at Stonoview");
			
			
			if(comName.contains("| Active Adult 55+")) {
				comName = "\"" + comName;
				comName = U.getSectionValue(comName, "\"", "|");
			}
			}
			
			if(comName!=null) {
				comName=comName.replace("0's at Tributary", "0's");
				comName=comName.replaceAll(" Heritageat | heritageat ", " ");
			}
		
			U.log("ComName: " + comName);
			

			if (comName == null) {

				comName = U.getSectionValue(html, "bar-headline\"", "<");
				if (comName != null)
				comName = comName.replace(">", "");
			}
			if (comName == null) {
				comName = U.getSectionValue(maindata, "\"name\":\"", "\",");
//				if (comName != null)
//				comName = comName.replace(">", "");
			}
			
			String homeDetail=ALLOW_BLANK;

			String tempName=U.getSectionValue(html, "data-testid=\"action-bar-headline\">", "<");
			U.log("tempName===="+tempName);
			int homeC=0;
			if(tempName!=null && !tempName.trim().equals("Townhomes")) {
			for(JsonElement hData : HomeJson) {
				String homedata= hData.toString();
				if(homedata.contains(tempName)) {
					homeDetail+=homedata;
//					U.log("homedata: " + homedata);

					homeC++;
				}
			}	
			}
			U.log("homeC: " + homeC);

//			U.log("=========="+Util.matchAll(homeDetail, "[\\s\\w\\W]{30}craftman[\\s\\w\\W]{30}", 0));


			String com = ALLOW_BLANK;
			// for(String data : comSec)
			// if(data.contains(comName))
			// com += data;

			comNameType += " " + comName;

			if (comName.startsWith(":"))
				comName = comName.replace(":", "");
			U.log("Com Name: " + comName);

			// ============ Address ===============
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
//			String addSec = U.getSectionValue(html, "<span class=\"Link_innerText__QtIgX\" aria-hidden=\"true\"><p class=\"bodycopyLargeNew Typography_bodycopyLargeNew__SM1pj\">", "</p>");
			String addSec = U.getSectionValue(html, "<p class=\"bodycopyLargeNew Typography_bodycopyLargeNew__SM1pj\">", "</p>");

//			 U.log("eeeeeee===" + addSec);
			if (addSec != null)
				addSec = addSec.replace("__2xFl2\" aria-label=\"", "").trim();
			if (addSec != null && !addSec.contains("community-info")) {
//				 U.log("eeeeeee1 " + addSec);
//				 U.log("eeeeeee----- " + addSec);
				addSec = addSec
						.replaceAll("InfoWrapper__eUgAK\" data-testid=\"whcHours-message\"><a class=\"Link_root__AHBaj TextButton_textbutton__Vzm45 TextButton_root__srV5y Overview_address__xX4Fu\" aria-label=\"", "")
						.replace("Welcome Home Center at Call for information, 804-391-4131", "")

						.replaceAll(
						"Welcome Home Center at|addressCall for information|at\n|Welcome Home Center|InfoWrapper__\\dTA_v\">|<a class=\"Link_root__\\duYbA TextButton_textbutton__hvWNi TextButton_root__\\dmYVo Overview_address|v-show=\"collection == \\d+\">|<p>|<p class=\"lh12\">|Hollywood @ Alto|Lennar Valencia| \\(GPS\\)|GPS Address:|Pioneer Meadows|Now Selling",
						"").replace("304-355-9863", "").replace("Pioneer Meadows", "").replace("<br>", ",").replaceAll("Coming soon|coming soon|Coming Soon", "")
						.replaceAll("BY APPOINTMENT ONLY|Model Home|Sold Out|- GPS use 15944 NW 97 Ave", "").replace("Folsom, Folsom,", ", Folsom,")
						.replace("&amp;", "&").replace("Newhall Ranch, Santa Clarita", ", Santa Clarita").trim();
				
//				U.log("KKKKKKKKK"+Util.matchAll(addSec, "[\\w\\s\\W]{30}Call[\\w\\s\\W]{30}", 0));
				 addSec=addSec.replaceAll("Virtual WHC|Virtual Tour Only |Call for information|Selling Offsite|Offsite", "");
				
				addSec = U.getNoHtml(addSec);
				
				 U.log("eeeeeee----- " + addSec);
				add = U.getAddress(addSec);
//				add[0]=add[0].replaceAll("InfoWrapper__2TA_v\" data-testid=\"whcHours-message\">\\s*", "");
				 U.log("add[0]----- " + add[0]);
				if (add[0] != null)
					add[0] = add[0].replaceAll(
							"By Appointment|Durham|Now Preselling|Fremont, CA|Kent WA 98031|SOLD OUT|By Appointment Only|Model Coming Soon|Coming Soon|COMING SOON|Call for Information|, Monroe, NJ|GPS:|,|Call For Information",
							"");
				 U.log("add[0]----- " + add[0]);
				 
				add[0]=add[0]
						.replace("1350 East Talbot Drive Kaysville UT", "1350 East Talbot Drive")
						.replace("By Appt", "").replace("Now selling virtually", "")
						.replace("WildcTrail", "Wildcat Trail")
						.replace("301-246-3046", "").replace("at 804-391-4131", "").replace("8920 UpbeWay", "8920 Upbeat Way")
						.replace("Csll for information", "")
						.replace("5296 Trimonti Circle Antioch CA 94531", "5296 Trimonti Circle").replaceAll("Dodson Road @ Deer Run Street", "Dodson Road at Deer Run Street");
			}
			if(url.contains("https://www.lennar.com/new-homes/virginia/va-dc-metro/centreville/glenbury/glenbury-estates/")) {
				add[0]="42809 Souther Dr";
				geo="TRUE";
			}
			if(url.contains("https://www.lennar.com/new-homes/virginia/va-dc-metro/centreville/glenbury/glenbury-manors/")) {
				add[0]="42809 Souther Dr";
				add[1]="South Riding";
				add[2]="VA";
				add[3]="20152";
				geo="TRUE";
			}
			if(add[0].equals("Virtual") || add[0].equals("Coming soon!")) {
				add[0] = null;
			}
			if(add[0].toString().trim().equals("Only")) {
				 add[0]=ALLOW_BLANK;
			 }
			if(add[0].toString().trim().equals("Sold out")) {
				 add[0]=ALLOW_BLANK;
			 }
			U.log("adddddd[0]====="+add[0]);
			
			
			
			
			
			U.log("Address: " + Arrays.toString(add));
			

			// =========== LatLng ===========
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };

			latlng[0] = U.getSectionValue(html, "\"latitude\":", ",");
			latlng[1] = U.getSectionValue(html, "\"longitude\":", ",");

			U.log("Latlong: " + Arrays.toString(latlng));
			
			
			
			if (latlng[0] != null && latlng[0] != ALLOW_BLANK)
				if (latlng[0].startsWith("-") && !latlng[1].startsWith("-")) {
					String temp = latlng[0];
					latlng[0] = latlng[1];
					latlng[1] = temp;
				}
			
			if(url.contains("https://www.lennar.com/new-homes/texas/austin-central-texas/elgin/elm-creek/cottage-ii-collection")) {
				add[3]=U.getAddressGoogleApi(latlng)[3];
				geo="TRUE";//====remm
			}
			
			U.log("Address: " + Arrays.toString(add));
//			if(add[0].equals("") && add[1] != null && add[2] != null && add[3] != null) {
//				U.log(">>>>>>>>>>>>>>>>>>>>>>>>");
//				add[0]=U.getAddressGoogleApi(latlng)[0];
//				if(add == null)add[0] = U.getAddressHereApi(latlng)[0];
//				geo="TRUE";
//			}

			if(add[0].length()<2 || add[0] == null && add[1] != null && add[2] != null && add[3] != null) {
//				U.log(">>>>>>>>>>>>>>>>>>>>>>>>");
				add[0]=U.getAddressGoogleApi(latlng)[0];
				if(add == null)add[0] = U.getAddressHereApi(latlng)[0];
				geo="TRUE";
			}
			if (add[0] == null || add[1] == null || add[2] == null || add[3] == null) {

				add = U.getAddressGoogleApi(latlng);
				if (add == null)
					add = U.getGoogleAddressWithKey(latlng);

				U.log("Google Address Here: " + Arrays.toString(add));
				geo = "TRUE";
			}

			if (add[0] == null || add[0].length() < 5 || add[3] == ALLOW_BLANK) {

				String[] add1 = U.getAddressGoogleApi(latlng);
				
				U.log("<<<<<<<<"+Arrays.toString(add1));
				if (add1 == null)
					add1 = U.getGoogleAddressWithKey(latlng);
				
				if (add[0] == null || add[0].length() < 5 || add[3]==ALLOW_BLANK)
					add = add1;
				
				
				else if (add[3] == ALLOW_BLANK)
					add[3] = add1[3];
				
				else if(add[3]==ALLOW_BLANK)
					add = add1;

				U.log("Google Address: " + Arrays.toString(add));
				geo = "TRUE";
			}

			if (latlng[0] == null || latlng[0].length() < 5) {

				latlng = U.getlatlongGoogleApi(add);
				if (latlng == null)
					latlng = U.getlatlongHereApi(add);
				U.log("Google Latlong: " + Arrays.toString(latlng));
				geo = "TRUE";
			}

			
			U.log("Address1 : " + Arrays.toString(add));
			
			// U.log(Util.matchAll(html, ".*1,800sq\\. ft &ndash; 2,019 sq\\. ft\\..*", 0));
		//	U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));
			

			// ========== Price =================
//			U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{30}HomesiteType[\\s\\w\\W]{30}", 0));
//			U.log("YYYY"+Util.matchAll(html,"[\\w\\W\\s]{30}\\$300[\\w\\W\\s]{30}",0));
			String priceSec2=null;
			int moveInReadyCount = 0;
			int lotid=0;
//			int UNDER_CONSTRUCTION=0;
//			int SOLD=0;
//			U.log(html);
			String[] priceSec=U.getValues(html, "\"HomesiteType\",\"plan\":", "address\":");
			
			
			
			String Lotid=ALLOW_BLANK;
			U.log("price sec count :::"+priceSec.length);
			for(String price :priceSec )
			{
//				U.log("}}}}}==="+price);

//				String stsSec=U.getSectionValue(price, "lotSize", ",\"");
//				U.log("}}}}}"+stsSec);
				if(price.contains("UNDER_CONSTRUCTION") || price.contains("MOVE_IN_READY")|| price.contains("SOLD") ||price.contains("COMING_SOON") ) 
				{
					//for move in ready status
					if(price.contains("MOVE_IN_READY"))
						moveInReadyCount++;
					
//					if(price.contains("UNDER_CONSTRUCTION"))
//						UNDER_CONSTRUCTION++;
//					
					if(price.contains("lotid")) {
						lotid++;
						
					}
					if(!price.contains("\"formattedPrice\":null") || price.contains("\"formattedPrice\":\"\"") ) {
//						
						priceSec2=priceSec2+price;
					
					}
					else {
						priceSec2=priceSec2+price;
					}
					
					
				}
			}
			Lotid=Integer.toString(lotid);
//			Lotid="Wa";
			U.log("Lots: "+Lotid);
			U.log("moveInReadyCount: "+moveInReadyCount);
			
//			U.log("UNDER_CONSTRUCTION :"+UNDER_CONSTRUCTION);
			
			U.log("Lotid :"+lotid);
			
//			U.log("}}}}}"+priceSec2);
			
			
			if(html.contains("Community_collectionList"))
				 rem=U.getSectionValue(html, "<div class=\"Community_collectionList__1vQkn\">", " <footer class=\"Footer_root__3HQ7N\">");
			if(rem!=null)	
			html=html.replace(rem, "");
			

			
			
			String remJson=U.getSectionValue(html, "type=\"application/json\">", "</script>");
			html=html.replace(remJson, "");
			
//			if(priceSec2!=null)
//			priceSec2=priceSec2.replaceAll("37425|20025|46825|35025|37425|34425","");
					
			// U.log("MMMM"+Util.match(html, "now pre-selling"));
			
//			
			html=html.replace("Mid $1.3 Millions", "Mid $1,300,000").replace("Upper $1.1 Millions", "Mid $1,100,000")
					.replace("Low $2 Millions", "Low $2,000,000");
			html = html.replace("456,999", "458,999")
					.replace("Low $300&#x27;s", "Low $300s").replaceAll("537,990", "").replaceAll("(\\$\\d+,\\d+)'?s", "$1");
         
			html = html
					.replace("From the Mid 900s", "From the Mid 900,000")
					.replace("0sq", "0 sq").replace("0s", "0,000").replace("0's", "0,000")
					.replaceAll("\"highlightedAttribute\":\".*\"|\"customPrice\":\".*\"|wasprice\":\"\\$\\d+,\\d+", "")
					.replace("$1.2 Millions", "$1,200,000").replace("$1.4 Millions", "$1,400,000 Millions")
					.replace("$1 Millions", "$1,000,000 Millions")
					.replace("Low $1.5 Millions", "Low $1,500,000")
					.replace("Upper $1.3 Millions", "Upper $1,300,000")
					.replace("Mid $1.3Ms", "Mid $1,300,000")	
					.replace("Low $1.6 Millions", "Low $1,600,000");
					
				//for changing Ms values like 1.7Ms and so on
			html = html.replaceAll("\\$(\\d).(\\d)Ms", "\\$$1,$2Ms ").replaceAll("(\\d)Ms", "$100,000");
			
  String priceSec3=U.getSectionValue(html, "<div class=\"InfoPriceRange_info__3OHMO\">","</div>");
//  U.log("price Sec3"+priceSec3);
  if(priceSec3!=null)
  priceSec3=priceSec3.replaceAll("\\s*</p>\\s*|\\s*<div>\\s*|\\s*<h2 class=\"Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\">\\s*|\\s*</h2>\\s*","");
  //U.log("price Sec3"+priceSec3);
  html=html.replace("\n" + 
  		"                          </h2>\n" + 
  		"                          <h2 class=\"headline2New Typography_headline2New__2k_KH\">\n" + 
  		"                            ", " ");


	
  String status=ALLOW_BLANK;
  //U.log("priceSec2 :"+priceSec2);
  if(priceSec2!=null) {
	  
	  priceSec2 = priceSec2.replaceAll("\"price\":\\d{6,7},\"lotSize\":0,\"status\":\"SOLD\"|price\":\\d{6,7},\"lotSize\":0,\"status\":\"MODEL_HOME|price\":\\d{6,7},\"lotSize\":0,\"status\":\"NO_PLAN", "")
			 			  .replace("0K", "0,000"); 
  }
  html = html.replaceAll("\"price\":\\d{6,7},\"lotSize\":0,\"status\":\"SOLD\"|price\":\\d{6,7},\"lotSize\":0,\"status\":\"MODEL_HOME", ""); 

  //remove other collection
  remove = U.getSectionValue(html, "<p class=\"bodycopyLargeNew Typography_bodycopyLargeNew__11xIQ Consultants_info__1pJUw", "</body>");
  if(remove != null) html = html.replace(remove, "");
	  
	//U.log("1=========="+Util.matchAll(html, "[\\s\\w\\W]{100}From the [\\s\\w\\W]{100}", 0));
  
  //for non-showing up values
//  if(url.contains("/new-homes/washington/seattle/puyallup/stewart-crossing")) {
//	  
//	  if(priceSec2.contains("status\":\"MOVE_IN_READY")) {
//		  priceSec2 = Util.match(priceSec2, "[\\s\\w\\W]{40}status\":\"MOVE_IN_READY");
//		  //U.log("priceSec2: " + priceSec2);
//	  }
//		  
//  }
  
  //removing other colloection section
  if(html.contains("Other collections in") && html.contains("Lennar builds new homes in")) {
	  String remSec = U.getSectionValue(html,"Other collections in", "Lennar builds new homes in");
	  html = html.replace(remSec, "");
  } 
  
  if(maindata.contains("\"community\":{\"name\":")) {
	  String basePrice=U.getSectionValue(maindata, "\"basePrice\":", ",");
if(basePrice!=null)
	basePrice=basePrice.replace(".0", "");
//if(maindata.contains("\"customPrice\":\"\"")) {
//	String min="$"+Util.match(basePrice, "\\d{3}")+",000";
//	U.log("min::"+min);
//	priceSec2+="\nFrom the "+min;
//}
	  U.log("basePrice::"+basePrice);

  }
  U.log("priceSec2::"+priceSec2);
//  priceSec2=ALLOW_BLANK;
//  priceSec3=ALLOW_BLANK;
  html = html.replace("K&#x27;s", ",000").replaceAll(" \\$\\d{3}s", " \\$$1,000").replaceAll(" \\$(\\d)\\.(\\d) Millions?", " \\$$1,$200,000")
		  .replaceAll(" \\$(\\d) Millions?", " \\$$1,000,000").replaceAll("&#x27;", "")
		  .replace("Upper $1.6 Millions</p>", "Upper $1,600,000</p>")
		  .replace("11xIQ\">874,950</p>", "11xIQ\">From the $874,950</p>");
  
			String[] price = U.getPrices((html+priceSec2+priceSec3).replace("\"number\":\"0331\",\"price\":267499,", "").replaceAll("price\":999999,\"lotSize\"", "").replaceAll("00s", "00,000"),
					"Upper \\$\\d,\\d{3},\\d{3}</p>|\"formattedPrice\":\"High \\$\\d{3},\\d{3}|\"formattedPrice\":\"Mid \\$\\d{3},\\d{3}|From the Mid \\d{3},\\d{3}|cSyn\">\\$\\d{3},\\d{3}|Upper \\$\\d{3},\\d{3}|Ent Offer \\$\\d{3},\\d{3}|>\\s*(High|Mid|Low) \\$(\\d,)?\\d{3},\\d{3}\\s*</p>|From the \\$\\d{3},\\d{3}|2k_KH\">\\$\\d{3},\\d{3}|\"price\":\\d{6,7},|from \\$\\d+,\\d+\n\\s*</p>|From the Low \\$\\d,\\d{3},\\d{3}|From the Mid \\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+-\\$\\d+,\\d+\n\\s*</p>|\\$\\d+,\\d+ - \\$\\d+,\\d+\n\\s*</h2>|Upper \\$\\d+,\\d+|From the High \\$\\d{3},\\d{3}|From the high \\$\\d+,\\d+|from the \\$\\d{3},\\d{3}|Price Range\\$\\d{3},\\d{3} -\\$\\d{3},\\d{3}|Upper \\$\\d,\\d+,\\d+|Mid \\$\\d,\\d{3},\\d{3}|\\$\\d{2},\\d{3}|Mid \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} Starting price|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} -\\d{3},\\d{3}|\\$\\d{3},\\d{3} Starting price|\\$\\d{3},\\d{3} Starting price|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}",
					0);

			
			price[0] = (price[0] == null) ? ALLOW_BLANK : price[0];
			price[1] = (price[1] == null) ? ALLOW_BLANK : price[1];
			
            
			
			//if(url.contains(""))
			U.log("Prices: " + Arrays.toString(price));
//			U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{30}\\$587,990[\\s\\w\\W]{100}", 0));
//			U.log("=========="+Util.matchAll(priceSec2, "[\\s\\w\\W]{30}530100[\\s\\w\\W]{30}", 0));
//			U.log("=========="+Util.matchAll(priceSec3, "[\\s\\w\\W]{30}400K[\\s\\w\\W]{30}", 0));
			
			//U.log("priceSec2: " + priceSec2);
			
			//
			// ========= Sqft ====================

			String[] sqft = U.getSqareFeet((html), "\\d{3} ft|\\d,\\d{3} ft", 0);

			sqft[0] = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			sqft[1] = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SquareFeet: " + Arrays.toString(sqft));

			
			
			// ========== Community type ===============

			String comType = U.getCommType((html)
					.replace("Lakeside at Blue Ridge Plantation is a new community", "Lakeside community")
					.replace("Golf lovers will appreciate", "Golf course lovers will appreciate")
					.replace("Residents can enjoy a lake-side community", "Residents can enjoy a lakeside community")
					.replace("beaches, resorts, entertainment", "beaches, resort-style living, entertainment")
					.replaceAll(
					"a disc golf course|Active Adult</a>|Active Adult Living</a>|\"Active Adult\"|about lake living|waterfront homesite availability|golf courses within \\d+ miles|premium waterfront homesites|Water Front Lot: We offer waterfront|d\":\"We offer waterfront|\"Water|lakefront clubhouse",
					""));
			
			//U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{30}golf[\\s\\w\\W]{30}", 0));
			U.log("Commuinty Type: " + comType);

			// ========== Property TYpe ================
			html = html.replace("Towns &amp; Villas", "Towns & Villas").replace("villas offering luxury and value",
					"luxury homes");

			html = html.replace("Approximate HOA Fees", "by Homeowner Association")
					.replace("offering the Craftsman,", "offering the Craftsman homes ,")
					.replace("Farmhouse and Italianate styles", " Farmhouse Collection and Italianate styles")
					.replace("Colonial Patriot Collection", "colonial home plans Patriot Collection")
					.replace("Florida Coastal and British West Indies Designs", "coastal-inspired architecture")
					.replace("Colonial Manor Collection", "colonial home plans Manor Collection")
					.replace("Grassy Manor", "Grassy Manor Collection").replace(" C Craftsman", " C Craftsman style");

			html = html.replace("luxurious, classy, and comfortable home in this community",
					"luxury homes , classy, and comfortable home in this community")
					.replaceAll("Fendol Farms Villas Collection Overview|VillasCollection_Hero","");
			comNameType = comNameType.replace(": Estate", "Estate home sites")
					.replace(": Executive", "executive home sites").replace(": Manor", "Manors Collection");
html=html.replace("plans ideal for multigenerational households", "plans ideal for multi-generation living households");
			
	homesDescription = homesDescription.replace("full bathroom, perfect for multigenerational living. In the main home", ""); 
if(homeDetail.length()>10)
	homeDetail=homeDetail.replace("An exterior with craftsman", "An craftsman exterior with");

			String propType = U.getPropType((html+homesDescription+exterior+availableExterior+homeDetail)
					.replace("\"title\":\"Modern Coastal A\"", "\"title\":\"Modern coastal vibes A\"")
					.replaceAll("Head to Lake Hartwell State Park for a cabin", "")
					.replace("An exterior design with craftsman influences", "An craftsman exterior design with influences")
					.replace("Cypress Park Estates, a solar community of new single-family", "Cypress Park Estates collection, a solar community of new single-family")
					.replace("Forestbrook Estates offers a variety of spacious single-family", "Forestbrook Estates collection offers a variety of spacious single-family")
					.replace("Auburn Estates is the first Lennar community", "Auburn Estates collection is the first Lennar community")
					.replace("Estates is a collection", "Estates collection")
					.replace("ideal for multigenerational households", "ideal for multigenerational living")
					.replaceAll("A life of luxury at Polo Run|luxury, and simplicity ", "luxury homes")
					.replaceAll("Craftsman, or American-style|Craftsman, and Monterey-style", "Craftsman style details")
					.replaceAll("Executive Collection Pelican A|Condors play hockey|Single Family Graham Farmhouse Exterior|Trinity-Lakes Estate Collection Harrisburg|-Townhomes/|\"Single Family\"|cottage-grove|Cottage Grove|craftsman-style cabinetry|Lennar\",\"cname\":null,\"ctns\":\\[\"Single Family\"|traditional study",
							""));

			if (propType.contains("Townhouse") && propType.contains("Townhomes"))
				propType = propType.replace("Townhouse", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");

			U.log("propType=="+propType);
//			U.log("=========="+Util.matchAll(html+homesDescription+exterior+availableExterior+homeDetail, "[\\s\\w\\W]{30}Estates[\\s\\w\\W]{30}", 0));
//			U.log("=========="+Util.matchAll(exterior, "[\\s\\w\\W]{30}exterior design with craftsman[\\s\\w\\W]{30}", 0));

			// ========== Derived Type =================
			//U.log("homesDescription: "+homesDescription);
			
			homesDescription = homesDescription.replaceAll("include a second level with a bonus|open-concept second floor with|The third floor hosts a private|"
					+ "The first floor showcases an open-plan layout|On the first floor, the living|found on the first floor|heart of the first floor|"
					+ "The first floor features an open|The first floor is host to an open|space on the first floor|layout on the first floor|offers an open first floor for entertaining|Featured on the first floor are a family room","")
					.replace("four-level townhome features", "four-story townhome features").replace("colonial-cottage-collections","The Colonial cottage collections")
					.replaceAll("open living occupy the first floor|on the first floor|on the first floor along with the open","");	
			U.log("dervided "+oversection);
			String derivedType = U.getdCommType((homesDescription+html+availableExterior+exterior)
					
					.replace("2<sup>nd</sup> level", "two story")
					.replaceAll("[L|l]evel|[f|F]loor|Rancho|living area is on the second floor|The second floor has a Great Room for family|The first floor features an open-plan layout|first floor of this contemporary|Grand Two-Story Foyer|Striking Two-Story Foyer|\\d bedroom|4-story Bridgeland ", "")
					.replace(" 2<sup>nd</sup> level", " 2-level").replace("One and Two Story", " 1 Story  2 Story ")+oversection);
			

			U.log("Derived Property: " + derivedType);
//			U.log("=========="+Util.matchAll(availableExterior, "[\\s\\w\\W]{30}single[\\s\\w\\W]{30}", 0));

			// =========== Status ================

			
			html = html.replace("Homesites are selling fast", "Homesites selling fast")			
					.replace("Opening in early 2022", "Opening early 2022")
					.replace("Grand Opening in late Spring 2022", "Grand Opening late Spring 2022")
					.replace("New section and new plans now available", "New Plans now available")
					.replace("nearby Lennar Community Coming Soon", "").replace("Click Here for Homes Ready NOW", "")
					.replace("Future Pool Coming Soon", "").replace("Amenity Center Coming Soon", "")
					.replace("make every home move-in ready", "")
					.replaceAll("even walking trails, are also now open|Elementary School is now open|tennis courts, pocket parks and playgrounds, and even walking trails, are now open|playground are now open|Model Release Coming Soon|swimming pool that is coming soon|Coming Soon Community|pool are coming|New Homes Available in Tampa", "");

			if (addSec != null)
				html = html.replace(addSec, "");

			String homeRemove = U.getSectionValue(html, "Explore homes in this collection", "Location");
			if (homeRemove != null)
				html = html.replace(homeRemove, "");
			else {
				homeRemove = U.getSectionValue(html, "Explore homes in this collection", "Availability_title");
				if (homeRemove != null)
					html = html.replace(homeRemove, "");
			}

			if (addSec != null)
				html = html.replace(addSec, "");

			String headingSection="";
			
			headingSection=U.getSectionValue(html,"Info_details__3KlPK", "CommunityAmenities_root__2qXqk");
			
		//	U.log(headingSection);
			
			if(headingSection!=null)
				headingSection = headingSection.replaceAll("Price Range\n\\s*</p>\n\\s*<div>\n\\s*<p class=\"Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\">\n\\s*FINAL MOVE-IN READY HOME| Price Range\n\\s*</p>\n\\s*<div>\n\\s*<p class=\"Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\">\n\\s*SOLD OUT", "");
			
			html=html.replace("move-in ready by early 2022", "move-in ready early 2022");
			html=html.replace("The community offers amenities that are fun for all ages, coming 2023","");
			html=html.replace("Future amenities include a pool and cabana! Coming Fall 2021","");
			html=html.replace("Anticipated to open early 2022","");
			
			
//			U.log("SSS"+Util.match(html, "SOLD OUT"));
			String rem3="";
			if(html.contains("Welcome Home Center")) {
				rem3=U.getSectionValue(html, "<div class=\"Overview_addressInfoWrapper", "</span>");
//				rem4+=U.getSectionValue(html, " Explore homes in this community", " Approximate HOA fees");
			html=html.replace(rem3, "");
			}
			

			html=html.replaceAll("class=\"Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\">\n" + 
					"                            Coming 2022", " Coming 2022")
					.replace("Typography_bodycopyLargeNew__11xIQ DefaultCard_description__21qOz\">\n" + 
							"                                Coming Soon", "")
					.replaceAll("Typography_bodycopyLargeNew__11xIQ\">\n" + 
							"        Coming Soon", "")
					.replaceAll("Typography_bodycopyLargeNew__11xIQ SinglePlan_highlightedText__9Ix_E\">\n\\s*Final opportunity|Typography_bodycopyLargeNew__11xIQ SinglePlan_highlightedText__9Ix_E\">\n\\s*Last Chance+", "")
					.replace("Typography_bodycopyLargeNew__11xIQ SinglePlan_highlightedText__9Ix_E\">\n" + 
							"        Now Selling", "")
					.replaceAll("Typography_bodycopyLargeNew__11xIQ SinglePlan_highlightedText__9Ix_E\">\n\\s*Now Selling", "")
					.replaceAll("11xIQ\">\n\\s*Sold Out|11xIQ\">\n\\s*[SOLD OUT|sold out]", "")
					.replace("**SOLD OUT**", "").replace("Orchid Terrace is currently being sold out of the North", "")
					.replaceAll("<span class=\"imageEyebrow Typography_imageEyebrow__2nuTN\">\\s+Sold out\\s+</span>","")
					.replaceAll("9Ix_E\">\\s+Sold out\\s+</p>","")
					.replace(" Classic Parks is a collection of new single-family homes now available"," Classic Parks is a collection of new single-family homes")
					.replaceAll("Now selling from 920 Tryon Palace", "");
					
			html=html.replace("Grand opening in February", "").replace("Opening in late 2022", "Opening late 2022")
//					.replace("Coming to Great Park Neighborhoods Winter 2022", "Coming Winter 2022")
					.replace("Opening in mid 2022", "Opening mid 2022")
					.replace("Opening in late 2023", "Opening late 2023")
//					.replace("Coming to Great Park Neighborhoods Summer 2022", "Coming Summer 2022")
					.replace("New Homes Coming in Winter 2022 to Fort Worth", "New Homes Coming Winter 2022 to Fort Worth")
					.replaceAll("river and walking trails are coming soon|headline2New Typography_headline2New__2k_KH InfoItem_info__1Q-cZ\">Coming Soon\\!*</p>", "") //removing coming soon for price range
					.replaceAll("bodycopyLargeNew Typography_bodycopyLargeNew__11xIQ\">Coming Soon\\s*\\!*</p>", "")
					.replaceAll("\"bodycopyLargeNew Typography_bodycopyLargeNew__11xIQ\">COMING SOON</p>", "")
					.replaceAll("headline2New Typography_headline2New__2k_KH InfoItem_info__1Q-cZ\">COMING SOON</p>", "")//removing coming soon from homes
					.replaceAll("subheadlineSmall Typography_subheadlineSmall__2eHeA Overview_badge__2p-QZ\">Coming soon</p>", "Coming Soon") //taking coming soon from above community name
					.replaceAll("DefaultCard_description__21qOz\">NOW OPEN\\!*", "")
					.replaceAll("bodycopyLargeNew__11xIQ\">sold out|info__1Q-cZ\">Sold out|highlightedText__9Ix_E\">Sold Out|imageEyebrow__2nuTN\">Sold out|InfoItem_info__1Q-cZ\">Sold out!</p>|bodycopyLargeNew__11xIQ\">Last chance</p>|bodycopyLargeNew__11xIQ\">Sold out</p>|highlightedText__9Ix_E\">Last Chance|InfoItem_info__1Q-cZ\">SOLD OUT</p>", "")
					.replace("New phase coming in spring 2023", "New phase coming spring 2023")
					.replaceAll("DefaultCard_description__21qOz\">Coming Soon</p>|"
							+ "DefaultCard_description__21qOz\">Coming Soon!</p>", "");
			
//			U.log(")))))))))==="+U.getSectionValue(html, "Legal disclaimers</h5>", "Join our interest list to receive the latest updates"));
			String comSec=U.getSectionValue(html, "Legal disclaimers</h5>", "Join our interest list to receive the latest updates")
					+U.getSectionValue(html, "</div><div class=\"Overview_root_", "</h5></a></div></div><div");
//			U.log("overview=="+overview);
//			U.log("=========="+Util.matchAll(overview, "[\\s\\w\\W]{30}sold out[\\s\\w\\W]{30}", 0));
//if(!comSec.contains("\">Sold Out</p>")) {
			comSec=U.removeSectionValue(comSec, "</span><div class=\"InfoItem_root_", "Price Range");
			comSec=U.removeSectionValue(comSec, ">Explore homes in this community", "</div></div></div></div><div");
//}
			
			U.log("overview===="+overview);
			
			overview=U.removeSectionValue(overview, "</span><div class=\"InfoItem_root_", "Price Range");
			comSec=comSec
					.replace("New Homes Coming in Winter 2022", "New Homes Coming Winter 2022")
					.replace("Grand Opening August 6th, 2022", "Grand Opening")
					.replace("Grand Opening October 8th, 2022", "Grand Opening")
					.replace("Coming in early 2023", "Coming early 2023")
					.replace("Parkeside Preserve at Quiet Waters is a community of new townhomes coming soon", "Parkeside Preserve at Quiet Waters is a community of new townhomes coming soon-")
					.replace("Highlands is a collection of new homes for sale, coming soon to Cool Springs", "Highlands is a collection of new homes for sale, coming soon- to Cool Springs");
			
			String comStatus = U.getPropStatus((comSec.replace("Grand Opening October 22nd", "Grand Opening October 2022").replace("now available for sale", "").replace("Now selling in Phase 4", "Phase 4 Now selling").replaceAll("Vincent’s, which is coming soon|Coming soon the community are picnic|Center at Coming Soon|school coming soon| homes coming soon|coming soon to|homesites coming soon to Walkertown|amenties coming soon|new series of homes coming soon|1dKFk\">SOLD OUT<|9Ix_E\">Final opportunity<|1xIQ\">SOLD OUT<|model is is the last opportunity|Attribute\":\"Last Chance|9Ix_E\">Last chance|for sale, coming soon to the Bastrop|Model opening Summer 2022|Anticipated to open summer|Images coming soon|Coming soon, the community swimming pool features palm trees|Kids will spend hours splashing in the water at the community swimming pool, coming early 2023|Welcome Home Center at \n" + 
					"Now Selling|coming soon to the Wexford Reserve|Now Selling Offsite|move-in ready by early|NOW OPEN!|NOW OPEN! Residents|NOW OPEN! On-site tennis|1qOz\"> NOW OPEN!|Dog Park NOW OPEN|NOW OPEN in Grand Central|Complex is Coming Soon|\"Coming Soon!\",\"images\"|Coming Soon to Grand Central Park|coming soon to the Northbrook masterplan|detailHeadline__LH2Wp\"> Coming Soon </p>|homes for sale coming soon|Clubhouse coming 2021|garages coming soon to", ""))//.replaceAll("\\s{2,}", " ")
					.replaceAll("Attribute\":\"Last Chance|9Ix_E\">Sold out|9Ix_E\">Now Selling<|2nuTN\">Sold out</span>|\"customPrice\":\"SOLD OUT\"|11xIQ\">Sold Out</p>|spacious homesites coming soon|Price Range</p><div><p class=\"Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\">FINAL MOVE-IN READY HOME|move-in ready early|\"status\":\"TEMPORARILY_SOLD_OUT\"|Price Range </p> <div> <p class=\"Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\"> SOLD OUT|\"Temporarily Sold|Price Range </p>(.*)?</p>|\"CLOSE|\"SOLD|Plan_highlightedText__9Ix_E\"> Sold|\"Sold Out|coming soon to this popular|coming soon to the Greywall|Coming Soon, Cypress|coming soon to the Marvida|coming soon to the Innovation|coming soon to the Becker|Coming Soon, Hockley|Overview_detailHeadline__LH2Wp\"> Coming|Typography_headline2__2bGlH Overview_detailHeadline__LH2Wp\">",
					"")
					.replace("single-family homes now available", "single-family homes available")
					.replaceAll("New Homes Coming in Winter 2022", "New Homes Coming Winter 2022")+overview.replace("now available for sale", "")
					.replace("trails are coming ", "")
					.replace("Waterfront homesites are available", "Waterfront homesites available")
					);
			
//			U.log("=========="+Util.matchAll(comSec, "[\\s\\w\\W]{30}coming late fall 2022[\\s\\w\\W]{30}", 0));
//			U.log("=========="+Util.matchAll(overview, "[\\s\\w\\W]{70}sold out[\\s\\w\\W]{60}", 0));
			
//			String comStatus = U.getPropStatus(headingSection+html);
			
			if(url.contains("https://www.lennar.com/new-homes/oregon/portland/hillsboro/reeds-crossing/the-legacy-collection/"))comStatus="Sold Out";
			if(url.contains("https://www.lennar.com/new-homes/florida/jacksonville-st-augustine/st-augustine/trailmark/"))comStatus="Next Phase Coming Soon";
			if(url.contains("seattle/sultan/daisy-crossing/"))comStatus=ALLOW_BLANK;
			//for move-In ready status
			if(moveInReadyCount > 0) {
				if(comStatus == ALLOW_BLANK) 
					comStatus = "Move-in ready";
				
				if(comStatus != ALLOW_BLANK && !comStatus.contains("Move-in ready"))
					comStatus = comStatus + ", Move-in ready";
			}

			if(comStatus.equals("Next Phase Coming Soon, Coming Soon")) comStatus = "Next Phase Coming Soon"; 
			
			comStatus=comStatus
					.replace("New Phase Coming Fall 2022, New Phase", "New Phase Coming Fall 2022")
					.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
			U.log("Community Status:---- " + comStatus);

			// ======== Note ================
//     U.log(Util.match(html, "now pre-selling"));
			String rem1="";
			

			
//			if(html.contains("Explore homes in this community")) {
//			 rem1=U.getSectionValue(html, "Explore homes in this community", "FAQs\\s*</h3>");
//			U.log(">>>>"+rem1);
//			html=html.replace(rem1, "");
//			}
			
//			U.log("<>>>>>\n"+rem1);
			
			String note = U.getnote(comSec.replaceAll(
					"<span class=\"Typography_caption__8uCyZ SinglePlan_highlightedText__9Ix_E\">\n" + 
					"          Now Preselling|OPENING FOR SALES THIS FALL|Take Advantage of Pre-Grand Opening Pricing NOW|Register for Pre-Sales|<p class=\"dscr\">New Section open for Sale!</p>",
					"").replace("Summer&nbsp;", "Summer "));
			 if(url.contains("https://www.lennar.com/new-homes/california/la-orange-county/simi-valley/sycamore-grove/sorrell/")) note = "Now Pre-selling";
//				U.log("=========="+Util.matchAll(html, "[\\s\\w\\W]{100}Preselling[\\s\\w\\W]{30}", 0));


			U.log("Note: " + note);
			
			 if(url.contains("https://www.lennar.com/new-homes/california/san-francisco-bay-area/fremont/innovation/revo/"))comStatus = comStatus+", Sold Out";

			 
			 
			 
			 U.log("comName =======  " + comName);
			 
			 if(comName.contains("Bungalows"))
			 {
				 
				 if(propType.length()>1)
					 propType=propType+", Bungalow Homes";
				 else
					 propType="Bungalow Homes";
			 }
			 if(comName.contains("Waterfront"))
			 {
				 
				 if(comType.length()>1)
					 comType=comType+", Waterfront Community";
				 else
					 comType="Waterfront Community";
			 }
			 
			 if(comName.equals("Midtown"))
			 {
				 comName="Midtown townhomes";
			 }
			 
			 String startdt=ALLOW_BLANK;
			 String enddt=ALLOW_BLANK;
			 comName=comName.replaceAll(" Neighborhoods| El Dorado Hills| by Lennar", "")
					 .replace("Stonegate Duplex", "Stonegate").replace(" ,Icon", ", Icon")
					 .replace("- Duplexes", " Duplexes")//.replace(" - Townhomes", " Townhomes")
					 .replace(" - Single Family", " Single Family")
					 .replaceAll("- Townhomes", "")
					 .replace("Barrington, Broadview, ", "Barrington, Broadview ")
					 .replace("At Mountain Crest At Mountain Crest", "At Mountain Crest")
					 .replace("The Pines Villas", "The Pines")
					 .replace("Legend Lakes Townhomes", "Legend Lakes");
			 
//			 U.log("comName ::"+comName);
			 comStatus=comStatus
					 .replace("New Phase, New Phase Coming Spring 2023", "New Phase Coming Spring 2023")
					 .replaceAll("\\d Homes Available", "");
			 
			 if(url.contains("san-francisco-bay-area/lafayette/the-brant/"))note=ALLOW_BLANK;
			 
			 add[0]=add[0].replaceAll("InfoWrapper__eUgAK\" data-testid=\"whcHours-message\"><a class=\"Link_root__AHBaj TextButton_textbutton__Vzm45 TextButton_root__srV5y Overview_address__xX4Fu\" aria-label=\" ", "");
			 
			 if(url.contains("florida/perdido-key/pensacola/lost-key/townhomes"))
			 {
				 price[1]="$378,000";
				 if(propType.length()>0) {
					 propType+=", Coastal Style Homes";
				 }
				 else {
					 propType="Coastal Style Homes";//=====remm
				 }
			 }
			 if(url.contains("https://www.lennar.com/new-homes/nevada/las-vegas/henderson/emerson/orson-collection")
					 || url.contains("https://www.lennar.com/new-homes/washington/seattle/kent/lexington"))
			 {
				 comStatus="Sold Out";//===remm
			 }

			 if(url.contains("new-homes/south-carolina/myrtle-beach/myrtle-beach/berwick-at-windsor-plantation"))
			 {
				 comStatus=comStatus.replace(", Sold Out", "");//===remm
			 }
//			 if(url.contains("new-homes/california/central-california/clovis/ellingsworth-coronet-series"))
//			 {
//				 comStatus+=", Now Selling";//===remm
//		     }
			 if(url.contains("https://www.lennar.com/new-homes/california/central-california/visalia/river-island-ranch/coronet-series"))
			 {
				 price[1]="$510,100";//===remm
			 }
			 U.log("price[1] ::"+price[1]);
			 
			 if(Lotid.equals("0")) {
				 Lotid=ALLOW_BLANK;
			 }
			if(com!=null) {
				 comName=comName.replace("Single-Family Homes", "Single Family Homes").replace("Iii", "III").replace("Astor - Two-Story", "Astor").replace("IIi", "III").replace("-  New Phase", "").toLowerCase();
			}
			
			data.addCommunity(U.getCapitalise(comName),url, comType);
			data.addAddress(add[0].replace("&#x27;s", "'s").toLowerCase(), add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPrice(price[0], price[1]);
			data.addLatitudeLongitude(latlng[0].replace("-", "").trim(), latlng[1].trim(), geo);
			data.addPropertyType(propType, derivedType);

			if (comStatus.length() < 4)
				comStatus = ALLOW_BLANK;
			else if (comStatus.contains("New Phase Coming Soon, Coming Soon"))
				comStatus = comStatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			comStatus = comStatus.trim().replaceAll("^,|,$", "").replace(", ,", ",").trim();
			data.addPropertyStatus(comStatus.replace("Ii", "II"));
			data.addNotes(note);
			data.addUnitCount(Lotid);
			data.addConstructionInformation(startdt, enddt);
		}
		j++;

//		 }catch (Exception e) {}

	}

	public static String sendPostRequestAcceptJsonForHome(String requestUrl, String payload, String homeType)
			throws IOException {
		String fileName = U.getCache(requestUrl + payload + homeType);
		File cacheFile = new File(fileName);
		U.log("--|" + fileName);
		if (cacheFile.exists()) {
			return FileUtil.readAllText(fileName);
		}
		StringBuffer jsonString = new StringBuffer();
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Accept", "application/json, text/plain, */*");
			connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
			//connection.setRequestProperty("cookie",
			//"btpdb.t4tmU86.dGZjLjc0Njc0OTU=UkVRVUVTVFMuOQ; btpdb.t4tmU86.dGZjLjc0NTQwOTI=UkVRVUVTVFMuOQ; ASP.NET_SessionId=bt5f3wsggp5vtbfxdqy4qilx; optimizelyEndUserId=oeu1652246479821r0.9928744912916023; _gid=GA1.2.163109870.1652246481; _gcl_au=1.1.609946332.1652246481; _cat=CAT1.3.1428518171.1652246482012; _fbp=fb.1.1652246482411.1551005493; _clck=xjl3q3|1|f1d|0; _pin_unauth=dWlkPU9HVTVPRFJqTURZdFlXTmpZaTAwTXpBeUxUazJaamN0WW1FME9Ea3pOR0V5WW1Waw; marketCode=PHO; _hjSessionUser_398706=eyJpZCI6IjYxNzlmNWY0LTJlZjctNTc0YS05NTJiLWEyNzQ4ZmU4YTIzMCIsImNyZWF0ZWQiOjE2NTIyNDY0ODIxNDUsImV4aXN0aW5nIjp0cnVlfQ==; AKA_A2=A; _hjSession_398706=eyJpZCI6ImQ2YTNmNThjLTk0OGItNDJlYS1hZTI3LTNhY2Y4MmEyYzdkZSIsImNyZWF0ZWQiOjE2NTIyNTg0MzA3MDYsImluU2FtcGxlIjp0cnVlfQ==; _hjAbsoluteSessionInProgress=1; _hjSessionRejected=1; _hjIncludedInPageviewSample=1; _hjIncludedInSessionSample=1; _ga=GA1.2.1127299486.1652246481; _clsk=z9kg3b|1652261789208|12|1|b.clarity.ms/collect; _uetsid=31d956e0d0ea11ec9835a5734b5e9146; _uetvid=b43986c0a34d11ec8953a16446349c3b; invoca_session=%7B%22ttl%22%3A%222022-05-18T09%3A36%3A32.110Z%22%2C%22session%22%3A%7B%22invoca_id%22%3A%22i-45921969-6fc2-494f-d83a-d405aeee1c75%22%7D%2C%22config%22%3A%7B%22ce%22%3Atrue%2C%22fv%22%3Afalse%2C%22rn%22%3Afalse%7D%7D; _ga_ZYJPP0E66P=GS1.1.A16648AE-0F33-4621-945B-21193DA70D8B.2.1.1652261882.0; RT=\"z=1&dm=www.lennar.com&si=3e21787d-e6ca-483a-ac82-fe1362cdc3c7&ss=l31dtzpd&sl=2&tt=4du&obo=1&rl=1\"; mprtcl-v4_F5AFB216={'gs':{'ie':1|'dt':'us1-0579633ea8846a43abee653a45ea4049'|'cgid':'1e95a4cd-f6fc-44e8-bc00-552ae084313d'|'das':'63662287-4d7f-4fc4-ad11-7ceb3077576b'|'csm':'WyIzNzMzODA4ODIzMTk2MzM4OTA3Il0='|'sid':'A16648AE-0F33-4621-945B-21193DA70D8B'|'les':1652261494915|'ssd':1652261494902}|'l':false|'3733808823196338907':{'fst':1652246481199|'ua':'eyJQSUQiOiJjMjdlMGVlNi00ZTAwLTRkZjktODg1MC04MmEyN2E0N2RiOTUiLCJnYVRyYWNrSWQiOiJVQS1YWFhYLVkiLCJnYUNsaWVudElkIjoiMTEyNzI5OTQ4Ni4xNjUyMjQ2NDgxIiwic2Vzc2lvbklkIjoiQTE2NjQ4QUUtMEYzMy00NjIxLTk0NUItMjExOTNEQTcwRDhCIn0='}|'cu':'3733808823196338907'}; _gat_mpgaTracker1=1; _gat_UA-7542894-1=1");
			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
			writer.write(payload);
			writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line;
			while ((line = br.readLine()) != null) {
				jsonString.append(line);
			}
			br.close();
			connection.disconnect();
		} catch (Exception e) {
			// throw new RuntimeException(e.getMessage());
		}
		if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
		return jsonString.toString();
	}
	
	
	
	
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(1000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,5000)", ""); 
//					Thread.sleep(100);
					try {
						WebElement option = null;
						for (int i = 0; i < 100; i++){

						option = driver.findElement(By.linkText("Load more communities"));//--------//*[@id="cntQMI"]
						option.click();
						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,5000)", ""); 

						Thread.sleep(1000);
//						option.click();
//						Thread.sleep(3000);
						U.log("::::::::::::click succusfull1:::::::::");
						}
					} catch (Exception e) {
						U.log("click unsuccusfull1" + e.toString());
					}
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(15000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

}