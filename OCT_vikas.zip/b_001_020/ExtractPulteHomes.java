/**
 * @author Upendra Singg
 * @date 
 */
package com.shatam.b_001_020;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.LatencyCounter;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractPulteHomes extends AbstractScrapper {
	static int count = 0;
	public int dup = 0;
	CommunityLogger LOGGER;
	static String Builder_Url = "https://www.pulte.com";
	static int j = 0;
	String status;
	List<String> comData = new ArrayList<>();
//	private static LatencyCounter LATENCY = null;

	public static void main(String[] args) throws Exception {
		
//		LATENCY = new LatencyCounter();
//		LATENCY.start("Community State");
		AbstractScrapper a = new ExtractPulteHomes();
		a.process();
//		LATENCY.end("Community State");
		FileUtil.writeAllText(U.getCachePath() + "Pulte Group - Pulte Homes.csv", a.data().printAll());
//		System.out.println(LATENCY);
	}

	public ExtractPulteHomes() throws Exception {

		super("Pulte Group - Pulte Homes", "https://www.pulte.com/");
		LOGGER = new CommunityLogger("Pulte Group - Pulte Homes");
	}

	public void innerProcess() throws Exception {

		String MainHtml = U.getHTML(Builder_Url);
		String regionState = U.getSectionValue(MainHtml, "<div class=\"Disclaimer-lists-cont row\">", " <!-- load concatenated scripts managed");
//		 U.log(regionState);
//		String regionState1 = U.getSectionValue(regionState, "</ul><ul class=\"list-unstyled\">", "</select>");

		String[] state = U.getValues(regionState, "</ul><ul class=\"list-unstyled\">", "</li>");
//		U.log("state.length::::::"+state.length);
		for (String string : state) {
			String regionName=U.getHtmlSection(string, "<li><a href", "/a>");
			String regionName1=U.getHtmlSection(regionName, "\">", "<");
			regionName1=regionName1.replace("New Construction Homes in ", "").replace("NEW CONSTRUCTION HOMES IN ", "").replace("\">", "");
//			U.log("Region Name :: "+regionName1);
			U.log("Url :: "+"https://www.pulte.com/api/marker/mapmarkers?brand=Pulte&state=" + regionName1 + "&qmi=false");
			String stateHtml = U.getHTML("https://www.pulte.com/api/marker/mapmarkers?brand=Pulte&state=" + regionName1 + "&qmi=false");
//			U.log(stateHtml);
			String stateData = U.getHTML("https://www.pulte.com/API/community/Search?qmi=false&brand=Pulte&state="
					+ regionName1 + "&productType=community&pageSize=150&pageNumber=0&flag=state&data=" + regionName1);
			
			String[] comdata1 = U.getValues(stateData, "<hr class=\"visible-xs\" />", "<hr class=\"visible-xs\">");
			String[] comdata = U.getValues(stateHtml, "{\"Id\":", "\"exact\"");
			
//			U.log(comdata.length);
//			U.log(comdata1.length);
			for (int i = 0; i < comdata.length; i++) {
//				try {
//				U.log("comdata1[i]====="+comdata1[i]);
//				U.log("comdata[i]====="+comdata[i]);
				comData.add(comdata1[i] + comdata[i]);
//				}catch(Exception e) {}
			}

		}
		
		Iterator<String> ite = comData.iterator();
		while (ite.hasNext()) {
			String data = ite.next();
			String url = U.getSectionValue(data, "<a href=\"", "\"");
			if (!url.startsWith("https:")) {
				url=Builder_Url+url;
			}
			
//			LOGGER.AddCommunityUrl(url);
			
//			if(url.startsWith("https:")) {
//			}
			//try{
			addDetails(data, url);// **check
			/*}catch(Exception e){
				U.log("Error Found :"+url);
			}*/
		}

		LOGGER.DisposeLogger();

//		U.log(dup);
	}

	// ===================================================Community
	// Info=======================================================================
	
	HashSet<String> uniqueUrlSet = new HashSet<>();
	private void addDetails(String comSec, String comUrl) throws Exception {
//		try
//		{
//		if(j>600)//count::391
//			if(j>=520 && j<600)
		{
		//TODO : For single community execution

			//========== SINGLE RUN ===============================================================================
//		if(!comUrl.contains("https://www.pulte.com/homes/florida/fort-myers/babcock-ranch/verde-at-babcock-ranch-211019"))return;

			U.log("count::" + j + "\ncomUrl::" + comUrl);
			
			U.log("Path::" + U.getCache(comUrl));
//			if (comUrl.contains("https://www.pulte.com/homes/arizona/phoenix/mesa/bella-via-209264"))return;//redirected

			if (comUrl.contains("https://www.pulte.com/homes/arizona/phoenix/mesa/bella-via-209264") || comUrl.contains("https://www.pulte.com/homes/georgia/atlanta/tyrone/river-crest-209900")
					|| comUrl.contains("https://www.pulte.com/homes/massachusetts/greater-boston-area/south-weymouth/woodstone-crossing-209501")) {
				LOGGER.AddCommunityUrl("*****************REDIRECTED**************" + comUrl);
				dup++;
				return;
			}
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			if(!uniqueUrlSet.add(comUrl)){
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			
			if(comUrl.contains("https://www.jwhomes.com")){
				LOGGER.AddCommunityUrl("*****************JohnWielandHomes**************" + comUrl);
				dup++;
				return;
			}
			if(comUrl.contains("americanwesthomes.com")){
				LOGGER.AddCommunityUrl("*****************americanwesthomes**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.centex.com/"))) {
				LOGGER.AddCommunityUrl("*****************CentexHomes**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.delwebb.com/"))) {
				LOGGER.AddCommunityUrl("*****************DelWebbHomes**************" + comUrl);
				dup++;
				return;
			}
			if ((comUrl.contains("https://www.divosta.com/"))) {
				LOGGER.AddCommunityUrl("*****************DivostaHomes**************" + comUrl);
				dup++;
				return;
			}
		
			if(comUrl.contains("https://www.pulte.com/homes/maryland/dc-metro/gaithersburg/crown-210179")
					||comUrl.contains("https://www.pulte.com/homes/ohio/cleveland/medina/enclave-at-woodside-preserve-210538")
					||comUrl.contains("https://www.pulte.com/homes/texas/san-antonio/boerne/the-overlook-at-cielo-ranch-210243")) {
				LOGGER.AddCommunityUrl("*****************Redirected**************" + comUrl);
				return;
			}
			
			LOGGER.AddCommunityUrl("*********************avaialble communities********* "+comUrl);
//			U.log("comSec=="+comSec);
			
			String comHtml = U.getHTML(comUrl);
			
			String additionFeatures=U.getHtmlSection(comHtml, "<h3>Additional Features</h3>", "<div class=\"content-container");
			
			if(additionFeatures==null) {
				additionFeatures=ALLOW_BLANK;
			}else{
				additionFeatures=additionFeatures.replace("00&#39;s", "00,000").replace("00s", "00,000");
			}
			String descriptionStatus=U.getHtmlSection(comHtml, " <div class=\"description\">", "</div>");
			if(descriptionStatus==null) {
				descriptionStatus=ALLOW_BLANK;
			}
			String statusFlag=U.getHtmlSection(comHtml, "<div class=\"Community-status-flag\"", "</div>");
			if(statusFlag==null) {
				statusFlag=ALLOW_BLANK;
			}
			String propertyTypeSec=U.getHtmlSection(comHtml, "<!-- Community Status Flag -->", "<!-- Lead Form -->");
//			U.log(propertyTypeSec);
			if(propertyTypeSec==null) {
				propertyTypeSec=ALLOW_BLANK;
			}
			
			String sqftSection=U.getSectionValue(comHtml, "<div class=\"CommunityOverview__home-sqft-and-plan-types\">", "</div>");
			if(sqftSection==null) {
				sqftSection=ALLOW_BLANK;
			}
			
			String priceComHtml=U.getHtmlSection(comHtml, "<div class=\"CommunityOverview__home-price\">", "<div class=\"amenities-title\">");
			if(priceComHtml!=null) {
				priceComHtml=priceComHtml.replace("00&#39;s", "00,000");
				priceComHtml=priceComHtml.replace("M&#39;s", ",000,000");
			}
			if(priceComHtml==null) {
				priceComHtml=ALLOW_BLANK;
			}
			String ametitesSec=U.getHtmlSection(comHtml, "<div class=\"amenities-title\">", "</ul>");
			if(ametitesSec==null) {
				ametitesSec=ALLOW_BLANK;
			}
			String ametitesSeeMore=U.getHtmlSection(comHtml, "<ul class=\"neighborhood-feature-list\">", "</ul>");
			if(ametitesSeeMore==null) {
				ametitesSeeMore=ALLOW_BLANK;
			}
			String descriptionSec=U.getHtmlSection(comHtml, "<div class=\"description\">", "</div>");
			if(descriptionSec==null) {
				descriptionSec=ALLOW_BLANK;
			}
			if(descriptionSec!=null) {
				descriptionSec=descriptionSec.replace("4th story", "4 story");
				descriptionSec=descriptionSec.replace("00Ks", "00,000");
				
			}
			String  removeSec=U.getSectionValue(comHtml, "<meta name=\"description\" content=\"", "\">")
					+U.getSectionValue(comHtml, "data-fb-pixel-model=\"", ">")
					+U.getSectionValue(comHtml, "\"communityDescription\":\"", "\",");
			String [] remove1=U.getValues(comHtml, "data-description=\"", "\"");
			if(remove1.length>0) {
				for(String a:remove1) {
					removeSec+=a;
				}
			}
			String [] removeScripts=U.getValues(comHtml, "<script", "</script>");
			if(removeScripts.length>0) {
				for(String a:removeScripts) {
					removeSec+=a;
				}
			}
//			U.log("removeSec=="+removeSec);
			
			if(removeSec!=null) {
				comHtml=comHtml.replace(removeSec, "");
			}
			
			String comHtml2=comHtml;
			
			String additionalFeatures = ALLOW_BLANK;
			if(comHtml.contains("<h3>Additional Features</h3>")) {
				additionalFeatures = U.getSectionValue(comHtml, "<h3>Additional Features</h3>", "</ul>");
				//U.log("additionalFeatures: "+additionalFeatures);
			}
			String imageCaption = ALLOW_BLANK;
			if(comHtml.contains("<div class=\"ImageCaption vertical-rule  \">")) {
				imageCaption = U.getSectionValue(comHtml, "<div class=\"ImageCaption vertical-rule  \">", "</div>");
				//U.log("imageCaption: "+imageCaption);
			}
			
			String comAbt=U.getSectionValue(comHtml, "<div class=\"CommunityHero__about\">","</div>");
			String rem3=U.getSectionValue(comHtml, "[{\"Id\"","}]");
			//U.log(rem3);
			comHtml = comHtml.replaceAll("now available for sale|Earliest Move|\"communityDescription\":\".*\"|data-fb-pixel-model=\".*\"|content=\".*\"", "");
//			String rem4[]=U.getValues(comSec, "<div class=\"GridItemLabel--small \">","</ul>");
//			String removingSec=ALLOW_BLANK;
//			for(String remov:rem4) {
//				 removingSec=removingSec+remov;
//			}
//			U.log("Remmm"+rem4);
//			comSec=comSec.replace(removingSec, "");
			
			// ======================================= remove
			// Sec==================================
			String rem = U.getSectionValue(comHtml, "nearbyMarkers =", "</script>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");
			
			String rem1=U.getSectionValue(comHtml, "<h3>Area Details</h3>", "<h2></strong>Homesite Map</strong>");
			if (rem1 != null)
				comHtml = comHtml.replace(rem1, "");
			
			
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "target=\"_blank\">", "<");
			if(comName==null) {
				comName = U.getSectionValue(comSec, "community-name\">", "<");
			}
			if(comName==null) {
				comName = U.getSectionValue(comSec, "community-name|Pulte\">", "<");
			}
			comName=comName.replace("&#174;","");
			if(comName.endsWith("Country Club"))comName = comName.replaceAll("Country Club", "");
			if(comName.endsWith(" Townhomes"))comName = comName.replaceAll(" - Townhomes| Townhomes", "");
			comName = comName.replaceAll(" - Active Adult Community| - Single Family| - 2-Story Homes| - Ranch Homes", "");
			comName=comName.replace("Chasewood Villas", "Chasewood").replace(" – ", " - ");
			if(comName.endsWith("Estates"))comName=comName.replace("Estates", ""); 
			U.log("Com Name::::::::" + comName);

			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			U.log(comHtml.contains("\"Address\": {"));
			comHtml=comHtml.replace("Off Collier", "Collier").replace("By Appointment Only", "");
			if(comHtml.contains("\"Address\": {")){
				U.log("address::::1111111111");
					String addSec=U.getSectionValue(comHtml, "\"Address\": {", "}");
					addSec=addSec.replaceAll("Coming Soon|Mobile Sales Center,","")
							.replace("(Tavistock Lakes \\u0026 Karrer)","")
							.replace("(W. Chapman Rd. & Storybook Lane)", "")
							.replace("&#39;", "'").replace("(SR 210 and US-1)", "")
							.replace("(Selling from Settlers Ridge)", "")
							.replace("(Selling from Hawthorn Hills)", "")
							.replace("\\u0026", "&").replace("&amp;", "&")
							.replace("Sold Out", "").replace("Corner of Curry Creek Trail and Cypress Parkway", "Cypress Parkway")
							.replace("2329 Wind Charm Street, Unit 104", "2329 Wind Charm Street Unit 104");	
					
					add[0] = U.getSectionValue(addSec, "Street1\": \"", "\"");
					if(add[0].length()==0)
						add[0] = U.getSectionValue(addSec, "Street2\": \"", "\"");
//					U.log("add[0]==="+add[0].length());
//					if(comUrl.contains("https://www.pulte.com/homes/nevada/mesquite/mesquite/suntero-210969"))
//						add[0] = U.getSectionValue(addSec, "\"Street2\": \"", "\"");
					
					add[1] = U.getSectionValue(addSec, "City\": \"", "\"");
					add[2] = U.getSectionValue(addSec, "State\": \"", "\"");
					add[3] = U.getSectionValue(addSec, "ZipCode\": \"", "\"");
			}
			else {
				U.log("address::::22222222222222");
				comSec=StringEscapeUtils.unescapeHtml(comSec);
				comSec=comSec.replace("Coming Soon","").replace("(Tavistock Lakes \\u0026 Karrer)","").replace("(SR 210 and US-1)", "").replace("\\u0026", "&").replace("&amp;", "&");
				add[0] = U.getSectionValue(comSec, "Street1\":\"", "\"");
				add[1] = U.getSectionValue(comSec, "City\":\"", "\"");
				add[2] = U.getSectionValue(comSec, "State\":\"", "\"");
				add[3] = U.getSectionValue(comSec, "ZipCode\":\"", "\"");
			}
			
			add[0]=add[0].replaceAll("Visit Sun City Mesquite for info: ", "").replace("coming soon", "")
					.replace("0.3 Miles West of N University Dr.", "N University Dr.")
					.replace("Off Atlantic Avenue", "Atlantic Avenue").replace("Off Collier Blvd Near Vanderbilt Beach Rd", "Collier Blvd Near Vanderbilt Beach Rd")
					.replace("Off Lakewood Ranch Blvd", "Lakewood Ranch Blvd").replace("Off Panacea Blvd", "Panacea Blvd").replace("Off Pratt Whitney Rd", "Pratt Whitney Rd")
					.replaceAll("Off US-41, 2 Miles Southeast of Collier Blvd", "Off US-41 2 Miles Southeast of Collier Blvd")
					.replace("Pinto Drive + Aster Road", "795 Lilium Trail").replace("(Tavistock Lakes & Karrer)", "")
					.replace("0.2 Miles South on ", "")
					.replace("26700 Grandflora Dr.  Magnolia", "26700 Grandflora Dr.")
					.replace("1449 Briar Creek Road Charlotte", "1449 Briar Creek Road")
					.replace("33026 Cinsault Circle (Washington/Abelia)","33026 Cinsault Circle")
					.replace("33031 Cinsault Circle (Washington/Abelia)", "33031 Cinsault Circle");
//			U.log("address::::"+add[1]);
			add[1]=add[1].replace("O\\u0027","O'");
			
			U.log("address::::"+Arrays.toString(add));
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
			latlong[0] = U.getSectionValue(comSec, "Latitude\":\"", "\"");
			latlong[1] = U.getSectionValue(comSec, "Longitude\":\"", "\"");

			U.log("LatLong ::"+Arrays.toString(latlong));
			if ((add[0] == null||add[0].length()<4) && latlong[0] != null) {
				if(!add[3].isEmpty()){
					String add1[] = U.getAddressGoogleApi(latlong);
					if(add1 != null) add[0] = add1[0];
					if(add[0] == null || add[0].isEmpty())
						add1 = U.getNewBingAddress(latlong);
					if(add1 != null) add[0] = add1[0];
					add1 = null;
				}else{
					add = U.getAddressGoogleApi(latlong);
					if(add == null)
						add = U.getNewBingAddress(latlong);
				}
//				add = U.getAddressGoogleApi(latlong);
				geo = "TRUE";
			}
			if (add[0] != null && latlong[0] == null) {
				latlong = U.getlatlongGoogleApi(add);
//				latlong = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
//			U.log(add[0]);
			
			add[0] = add[0].replaceAll(" \\(at Leander Blvd\\)|Homestead Park Office:|Model Closed| \\(Near 110 and Mozart St.\\)|, gps 528 Boston Post rd| \\(GPS: 528 Boston Post Rd\\)| \\(GPS: 528 Boston Post Rd\\)|, Gps 528 Boston Post Rd|\\(|\\)|\\\\t", "");
			
			// ==============================================================Price &&
			// SF============================================
			//U.log(U.getSectionValue(comSec, "starting-at-data ", "</div>"));
//			U.log(comSec);
			String remVals[] = U.getValues(comHtml, "<div id=\"popover-accordion", "</div>");
			for(String remVal : remVals) comHtml = comHtml.replace(remVal, ""); 
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec=comSec.replace("$500&#39;s", "$500,000");
			comSec = comSec.replaceAll("0s|0S|0's|0&#39;s|0Ks", "0,000").replace("Mid $1.0M&#39;s", "Mid $1,000,000 ");
			comSec=comSec.replaceAll("\\s*\\$\\d{3},\\d{3} in Savings|<h4>\\s*\\$525,990|\\$\\d{3},\\d{3}\\s*</div>", "");
			comHtml=comHtml.replaceAll("\\s*\\$\\d{3},\\d{3} in Savings|stat-line\">\\n*\\s*\\$\\d{3},\\d{3}\\s*</div>|Community Center is a 146,000 sq. ft. facil|76,000 Sq. Ft. Golf|ers: 7,000 sq. ft. Wellness Floor|4,000 Sq. Ft. Clubhouse|5,000 Sq. Ft. Zero Entry|<li>Large 7,800 Sq. Ft. Homesite!</li>|<h4>\\s*\\$525,990", "");
			comHtml = comHtml.replace("$1.5M&#39;s", ",1,500,000").replaceAll("0s|0S|0's|0’s|0&#39;s|0Ks|0ks", "0,000");
			comHtml = comHtml.replace("$1M&#39;s", "$1,000,000").replaceAll("\\$1 Million|\\$1 million", "\\$1,000,000").replaceAll("\\$200,000 in Vero Beach", "")
					.replace("$400’s", "$400,000").replace("in $300's", "High $300,000").replace("Low $1.1M&#39;s", "Low $1,100,000").replace("Low $1.0M&#39;s", "Low $1,000,000");
			comHtml=comHtml.replaceAll("collapse stat-line\">\\n*\\s*\\$\\d,\\d{3},\\d{3}|\\d{2,3},\\d{3} in Savings|\\$\\d{2,3},\\d{3}\\s+</div>\\s+<div class=\"data-label\">in Savings</div>","");
			comHtml=comHtml
					.replace("+</span>", "</span>")
					.replace("$1.2M&#39;s", "$1,200,000").replace("Low $1M's", "to over $1,000,000").replace("to over $1M", "to over $1,000,000").replaceAll("collapse\">\\n*\\s*","Upper ").replaceAll("\n\\s*\n\\s*</div>\n\\s*<div class=\"data-label\">Sq. Ft.</div>", "</div><div class=\"data-label\">Sq. Ft.</div>");
			
			comHtml = comHtml.replaceAll("\\d+,\\d+ square feet of restaurants", "");
			comHtml=comHtml
					.replace("+ Sq Ft", " Sq Ft")
					.replace("12,000 sq. ft. Community Center", "");
			
			if(rem3!=null) {
			comHtml=comHtml.replace(rem3, "");
			}
			
			String[] homeUrl=U.getValues(comHtml, "<div class=\"HomeDesignCompact__title\">","View Home");
			String homeData="";
			U.log(homeUrl.length);
			int p=0;
			if(homeUrl.length>0) {
			for (String string : homeUrl) {
//				if(p++ == 6)break;
				String hUrl="https://www.pulte.com"+U.getSectionValue(string, "<a href=\"","\"");
				U.log("homeUrl : "+ hUrl);
				String homeHtml=U.getHTML(hUrl);
//				U.log("homeUrl : "+ hUrl);
//				if(homeHtml.contains("Home Features</h3>")) U.log("FOUND");
	
				String [] remove_Scripts=U.getValues(homeHtml, "<script", "</script>");
				if(remove_Scripts.length>0) {
					for(String a:remove_Scripts) {
						removeSec+=a;
					}
				}
//				U.log("removeSec=="+removeSec);
				
				if(removeSec!=null) {
					comHtml=comHtml.replace(removeSec, "");
				}
				try{
							//homeData=homeData+U.getSectionValue(U.getHTML(hUrl), "data-description=\"", "\"");
					homeData=homeData+U.getSectionValue(homeHtml, "data-description=\"", "\"")+string +"\n"+U.getSectionValue(homeHtml, "<h3>\n" + 
							"              Home Features\n" + 
							"            </h3>", "</section>");
				}catch(Exception e){}
			}
			}
			int quick_Count=0;
			boolean quickHomeAvailCurrentMonth=false;
			boolean quickHomeAvail=false;
			if(comHtml.contains("community QmiSummary--listview\">")) {
				homeUrl=U.getValues(comHtml, "<div class=\"HomeDesignSummary--qmi","View Home");
//				U.log(Arrays.toString(homeUrl));
				int quickTotalCount=homeUrl.length;
				U.log("quick homes==="+homeUrl.length);
				
				quickHomeAvail=true;
//				homeQuickSecDate=U.getHtmlSection(, From, To)
//				=====
	
				
				if(homeUrl.length>0 ) {
				for (String string : homeUrl) {
//					if(p++ == 6)break;
//					U.log("string=========="+string);
//					String homeQuickSecDate=U.getHtmlSection(string, "<div class=\"data-label\">Starting From</div>", "<div class=\"data-label\">Anticipated Completion Date:</div>");
//					U.log(homeQuickSecDate);
					if((string.contains("2022") || string.contains("2023")) && !string.contains("Aug 2022")) {
						quick_Count++;
						U.log("quick Move home Count :: "+quick_Count);
					}
					
					if(string.contains("Aug 2022")) {
						quickHomeAvailCurrentMonth=true;
					}
//					if((string.contains("Available Now")||string.contains("Contact Us")) && dateAvailableOrNotCount==0 ) {
//						quick_Count++;
//						U.log(quick_Count);
//					}
					
					String hUrl="https://www.pulte.com"+U.getSectionValue(string, "<a href=\"","\"");
					//U.log("homeUrl : "+ hUrl);
					String homeHtml=U.getPageSource(hUrl);
					String [] remove_Scripts=U.getValues(homeHtml, "<script", "</script>");
					if(remove_Scripts.length>0) {
						for(String a:remove_Scripts) {
							removeSec+=a;
						}
//						break;
					}
//					U.log("removeSec=="+removeSec);
					
					if(removeSec!=null) {
						comHtml=comHtml.replace(removeSec, "");
					}
					try{
					//homeData=homeData+U.getSectionValue(U.getHTML(hUrl), "data-description=\"", "\"");
						homeData=homeData+U.getSectionValue(homeHtml, "data-description=\"", "\"")+string;
						
					}catch(Exception e){}
				}
				}
			}
			
			if(quickHomeAvailCurrentMonth) {
				U.log("is Avaialble");
				quick_Count=0;
			}
			
			String comm_Detail=U.getSectionValue(comHtml, " <section id=\"CommunityOverview\"", "</section>");
			comHtml=comHtml.replaceAll("data-description=\"With new homes starting in the upper \\$200,000, now is a great time to buy at Woodcreek|new homes starting in the low \\$300,000, now is a great time to buy at Oakfield. Click or call", "");
//			String[] prices = U.getPrices(comHtml
//					.replaceAll("at Brighton from the Mid \\$300,000. Click or call|data-description=\"With new homes starting in the upper \\$200,000, now is a great time to buy at Woodcreek", "")
//					.replaceAll("New townhomes at Holding Village in Wake Forest from the upper $200", "")
//					.replaceAll("data-description=\\\"With new homes starting in the $310,000, now is a great time to buy at The Crossvine", "")
//					+ comSec, "<span class=\\\"price-amount\\\">\\$\\d{3},\\d{3}|to over \\$\\d{1},\\d{3},\\d{3}|<div class=\"CommunityHero__startingAtData\">\\s+\\$\\d{3},\\d{3}\\s+</div|Mid \\$\\d,\\d{3},\\d{3}|high \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the Mid \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</h4>|Upper \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|C00000\">\n*\\s*\\$549,990|C00000\">\\n*\\s*\\$\\d{3},\\d{3}|collapse\">\\n\\s*\\$\\d{3},\\d{3}|starting-at-data\">\\s*\\$\\d{3},\\d{3}|Starting in the \\$\\d{3},\\d{3}|starting in \\$\\d{3},\\d{3}|Upper-\\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|class=\"td starting-at\">\\$\\d{3},\\d{3}<|mid-\\$\\d{3},\\d{3}|(High|Mid) \\$\\d{3},\\d{3}|Upper  \\$\\d{3},\\d{3}", 0);
			additionalFeatures=additionalFeatures.replace("Single Family Homes From the Low $400’s", "Single Family Homes From the Low $400,000");
			String[] prices = U.getPrices((additionFeatures+priceComHtml+ametitesSec+ametitesSeeMore+descriptionSec+comm_Detail+homeData)
					.replace("$1.5M&#39;s", "$1,500,000").replace("$1.6M&#39;s", "$1,600,000")
					.replaceAll("at Brighton from the Mid \\$300,000. Click or call|data-description=\"With new homes starting in the upper \\$200,000, now is a great time to buy at Woodcreek", "")
					.replaceAll("New townhomes at Holding Village in Wake Forest from the upper $200", "")
					.replaceAll("data-description=\\\"With new homes starting in the $310,000, now is a great time to buy at The Crossvine", "")
					+ comSec+additionalFeatures, "$\\d{1},\\d{3},\\d{3}|<h4>\\$\\d{3},\\d{3}</h4>|<span class=\\\"price-amount\\\">\\$\\d{3},\\d{3}|to over \\$\\d{1},\\d{3},\\d{3}|<div class=\"CommunityHero__startingAtData\">\\s+\\$\\d{3},\\d{3}\\s+</div|Mid \\$\\d,\\d{3},\\d{3}|high \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the Mid \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</h4>|Upper \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|C00000\">\n*\\s*\\$549,990|C00000\">\\n*\\s*\\$\\d{3},\\d{3}|collapse\">\\n\\s*\\$\\d{3},\\d{3}|starting-at-data\">\\s*\\$\\d{3},\\d{3}|Starting in the \\$\\d{3},\\d{3}|starting in \\$\\d{3},\\d{3}|Upper-\\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|class=\"td starting-at\">\\$\\d{3},\\d{3}<|mid-\\$\\d{3},\\d{3}|(High|Mid) \\$\\d{3},\\d{3}|Upper  \\$\\d{3},\\d{3}", 0);
			
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
//			U.log(">>>>>>>>"+Util.matchAll(homeData,"[\\w\\W\\s]{50}\\$540,990[\\w\\W\\s]{50}",0));
			if(comUrl.contains("virginia/northern-virginia/reston/reston-arboretum-210533")) {
				minPrice="$700,000";//{Dt.:15 June jayashree}
			}
			
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
//			U.log(Util.match(comHtml, ".*3,3337.*"));
			
			String quicksec=U.getSectionValue(comHtml, "<div class=\"stat-container starting-at col-xs-6\">", " <div class=\"stat-container garage col-xs-6\">");
			//U.log(quicksec);
			
			if(quicksec==null)quicksec="";
			
//			String[] sqft = U.getSqareFeet((comHtml+quicksec+additionalFeatures).replace("4,000 Sq. Ft. Fitness Center", "").replace("3,3337", "3,337").replaceAll("12,000 sq. ft. Community Center|12,000 Sq. Ft. Community Center|The hospital is 325,000 square feet| with a new 65,000 sq. ft. open-air", ""),
//					"\\d,\\d{3} - \\d,\\d{3}</span> sqft|\\d,\\d{3}</span> sqft|\\d,\\d{3}-\\d,\\d{3} Square Feet|\\d,\\d+ – \\d,\\d+ sq. ft|homes from \\d{1},\\d{3}|data-value u-no-empty-Upper \\d{1},\\d{3}|from \\d,\\d{3} sq\\.ft\\. – \\d,\\d{3} sq\\.ft|from \\d,\\d{3} - \\d,\\d{3}\\+ Sq.Ft|\\d,\\d+</div><div class=\"data-label\">Sq. Ft.</div>|Home designs starting at \\d{4} square feet|ownhomes Starting at \\d,\\d{3} sq. ft|Townhomes Starting at \\d,\\d{3} sq ft|Ranging from \\d,\\d{3} – \\d,\\d{3} sq\\. ft\\.</|from \\d,\\d{3} – \\d,\\d{3}\\+ s\\.f\\.|townhomes over \\d,\\d{3} sq\\.ft\\.|-\\d,\\d{3} SF\\.?|\\d{4}-\\d{4}\\+ SF|\\d,\\d{3} � \\d,\\d{3} square feet|from \\d,\\d{3}s?\\s?-\\s?\\d,\\d{3} SF|\\d,\\d{3} to \\d,\\d{3,4} sq. ft.|<div class=\"td\">\\d,\\d{3}</div>|from \\d,\\d{3}–\\d,\\d{3} sq.ft.|\\d{1},\\d{3} to more than \\d{1},\\d{3} Sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} Sq.Ft.|\\d{4}-\\d{4} SF|\\d{1},\\d{3}–\\d{1},\\d{3} sq. ft.|<h4>\\d{1},\\d{3}</h4>|<h4>\\d{3,4}</h4>|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}\\+ Square Feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+\\+ sq. ft.|\\d,\\d+ to \\d,\\d+\\+ square feet|\\d,\\d+-\\d,\\d+\\+ Sq. Ft.|\\d+ - \\d+\\+ Square Feet|\\d,\\d+-\\d,\\d+\\+Square Feet|\\d,\\d+-\\d,\\d+\\+Sq. Ft.|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+\\+ Sq. Ft.|\\d{1},\\d{3} Square Feet|\\d,\\d+-\\d,\\d+ S.F.|\\d{4}-\\d{4} sq ft|From \\d{1},\\d{3} sq. ft|<h4>\\s*\\d,\\d{3}\\+*\\s*</h4>|ranging from \\d,\\d{3}-\\d,\\d{3} sq ft|homesite, at least \\d+,\\d{3} sf|<h4>\\s+\\d{3,4}\\s+</h4>\\s+<span class=\"label\">Sq. Ft|empty-collapse\">\\s+\\d,\\d{3}\\s+</div>\\s+<div class=\"data-label\">Sq. Ft.|Homes Ranging from \\d,\\d{3} – \\d,\\d{3} sq. ft.|Ranging From \\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d+ Sq. Ft",
//					0);
//			U.log("additionFeatures"+additionFeatures);
			String[] sqft = U.getSqareFeet(((additionFeatures+ametitesSec+ametitesSeeMore+descriptionSec+comm_Detail+homeData)+sqftSection+quicksec+additionalFeatures).replace("</span> sqft", " sqft").replaceAll("Tower &amp; Whitestone plans from 1,662 to 3,307 sq. ft. Enjoy flexible floor plans|\\d+,\\d+ sq. ft. Clubhouse|5,000 Square Feet Clubhouse|5,000 sq. ft. clubhouse|Clubhouse Community with 5,000 Sq. Ft.|14,000 Sq. Ft. Clubhouse|14,000 sq. ft. clubhouse|4,000 Sq. Ft. Fitness Center|13,000 square feet for social interaction", "").replace("3,3337", "3,337").replaceAll("12,000 sq. ft. Community Center|12,000 Sq. Ft. Community Center|The hospital is 325,000 square feet| with a new 65,000 sq. ft. open-air", ""),
					"\\d,\\d{3} to \\d,\\d{3}\\+ sq. ft.|\\d,\\d{3} - \\d,\\d{3} sqft|\\d,\\d{3} to \\d,\\d{3}\\+ Sq Ft|\\d{1},\\d{3} – \\d{1},\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3}</span> sqft|\\d,\\d{3}</span> sqft|\\d,\\d{3}-\\d,\\d{3} Square Feet|\\d,\\d+ – \\d,\\d+ sq. ft|homes from \\d{1},\\d{3}|data-value u-no-empty-Upper \\d{1},\\d{3}|from \\d,\\d{3} sq\\.ft\\. – \\d,\\d{3} sq\\.ft|from \\d,\\d{3} - \\d,\\d{3}\\+ Sq.Ft|\\d,\\d+</div><div class=\"data-label\">Sq. Ft.</div>|Home designs starting at \\d{4} square feet|ownhomes Starting at \\d,\\d{3} sq. ft|Townhomes Starting at \\d,\\d{3} sq ft|Ranging from \\d,\\d{3} – \\d,\\d{3} sq\\. ft\\.</|from \\d,\\d{3} – \\d,\\d{3}\\+ s\\.f\\.|townhomes over \\d,\\d{3} sq\\.ft\\.|-\\d,\\d{3} SF\\.?|\\d{4}-\\d{4}\\+ SF|\\d,\\d{3} � \\d,\\d{3} square feet|from \\d,\\d{3}s?\\s?-\\s?\\d,\\d{3} SF|\\d,\\d{3} to \\d,\\d{3,4} sq. ft.|<div class=\"td\">\\d,\\d{3}</div>|from \\d,\\d{3}–\\d,\\d{3} sq.ft.|\\d{1},\\d{3} to more than \\d{1},\\d{3} Sq. ft|\\d{1},\\d{3} to \\d{1},\\d{3} SF|\\d{1},\\d{3} to \\d{1},\\d{3} Sq.Ft.|\\d{4}-\\d{4} SF|\\d{1},\\d{3}–\\d{1},\\d{3} sq. ft.|<h4>\\d{1},\\d{3}</h4>|<h4>\\d{3,4}</h4>|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}\\+ Square Feet|\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d+ - \\d,\\d+\\+ sq. ft.|\\d,\\d+ to \\d,\\d+\\+ square feet|\\d,\\d+-\\d,\\d+\\+ Sq. Ft.|\\d+ - \\d+\\+ Square Feet|\\d,\\d+-\\d,\\d+\\+Square Feet|\\d,\\d+-\\d,\\d+\\+Sq. Ft.|\\d,\\d+-\\d,\\d+ Sq. Ft.|\\d,\\d+\\+ Sq. Ft.|\\d{1},\\d{3} Square Feet|\\d,\\d+-\\d,\\d+ S.F.|\\d{4}-\\d{4} sq ft|From \\d{1},\\d{3} sq. ft|<h4>\\s*\\d,\\d{3}\\+*\\s*</h4>|ranging from \\d,\\d{3}-\\d,\\d{3} sq ft|homesite, at least \\d+,\\d{3} sf|<h4>\\s+\\d{3,4}\\s+</h4>\\s+<span class=\"label\">Sq. Ft|empty-collapse\">\\s+\\d,\\d{3}\\s+</div>\\s+<div class=\"data-label\">Sq. Ft.|Homes Ranging from \\d,\\d{3} – \\d,\\d{3} sq. ft.|Ranging From \\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d+ Sq. Ft|\\d,\\d{3} sqft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);
//			U.log(">>>>>>>>"+Util.matchAll(comm_Detail+homeData,"[\\w\\W\\s]{30}3,307[\\w\\W\\s]{30}",0));
//			U.log(">>>>>>>>"+Util.matchAll(quicksec+additionalFeatures,"[\\w\\W\\s]{30}3,307[\\w\\W\\s]{30}",0));

			//==================== Home Plan Html =======================
			
			
			
/*			//TODO:Remove
			if(comUrl != null){
				j++;
				return;
			}*/
			
			//------------------replace section----------
			comHtml = comHtml.replaceAll("family-friendly master-planned community with abundant|Pulte Active Adult|Pulte Homes&#174; Active Adult|Anthem is a master-planned|tennis at El Conquistador Golf Course and Oro Valley Country Club|La Mirada, a new construction master plan|Golf Cart Storage|Greyhawk at Golf Club|exploring world-class golf|nearby golf|Victory Golf|Conquistador Golf", "");
			comHtml=comHtml.replaceAll("55\\+ buyer|55 &amp; over", " seniors 55 and over");
			rem = U.getSectionValue(comHtml, "<div class=\"Disclaimer", "</div>");
			if(rem != null) comHtml = comHtml.replace(rem, "");
			// ==============================================================Community type============================================
//			String desc=U.getSectionValue(comHtml, "<div class=\"description\">", "</div>");
			String featureListData=ALLOW_BLANK;
			 featureListData = U.getSectionValue(comHtml, " <ul class=\"feature-list\">", "</ul");
			String comType = ALLOW_BLANK;
		//	U.log("ABT"+comAbt);
			comHtml=comHtml.replace("green spaces and waterfront areas", "green spaces and Waterfront Homesites areas");
//			comType = U.getCommType((comAbt+comHtml.replace("easy access to recreation and cultural events, from parks and golfing to upscale shopping and dining", "") + comSec).replaceAll("196-acre master-planned development with|resort-style swimming pool|resort-style pool|Resort-style swimming pool|Aurora’s premium outlets are just a short drive away, and golfers will love being minutes from 6 different public/private golf courses|Resort and Spa|irrigated|family-friendly master-planned community with abundant|Beautiful gated courtyard entry", ""));
//			U.log("descriptionSec :: "+descriptionSec);
	
			comType = U.getCommType((descriptionSec+descriptionStatus+ametitesSec+ametitesSeeMore+descriptionSec+comAbt+(comm_Detail+additionalFeatures+featureListData).replace("easy access to recreation and cultural events, from parks and golfing to upscale shopping and dining", "") + comSec).replaceAll("196-acre master-planned development with|resort-style swimming pool|resort-style pool|Resort-style swimming pool|Aurora’s premium outlets are just a short drive away, and golfers will love being minutes from 6 different public/private golf courses|Resort and Spa|irrigated|family-friendly master-planned community with abundant|Beautiful gated courtyard entry", ""));

			U.log("comType :::::"+comType);
			// ==============================================================Property type============================================
			String propertyTypeSecGet=U.getHtmlSection(comHtml, "<h3 class=\"header\">Home Collections</h3>", "<div class=\"tab-content");
			if(propertyTypeSecGet==null) {
				propertyTypeSecGet=ALLOW_BLANK;
			}
			if(propertyTypeSecGet!=null) {
				propertyTypeSecGet=propertyTypeSecGet.replace("data-toggle=\"tab\">Estate</a>", "estate home").replace("data-toggle=\"tab\">Bungalow</a>", "Bungalow Homes");
			}
			//	U.log(featureListData);
			if(featureListData==null)featureListData=ALLOW_BLANK;
			comHtml = comHtml.replaceAll("<span class=\"caption\">Plan \\d Farmhouse</span>", "Farmhouse-style exteriors")
					.replaceAll("<span class=\"caption\">\\d-Plex Coastal Exterior</span>", "coastal home features");
			String propType = ALLOW_BLANK;
			comHtml = comHtml.replace("data-toggle=\"tab\">Estate Series </a>", "data-toggle=\"tab\">Estate Series </a>");
//
			featureListData= featureListData.replace("Custom Architectural Designs ", "CUSTOM LOTS");
			comHtml = comHtml.replace("Custom Architectural Designs ", "additional custom").replaceAll("modern luxury at an affordable price", "modern luxury homes at an affordable price")
					.replaceAll("Traditional Front-Load Garage|traditional formal dining|traditional front load garages|Traditional Front-Load Garage Plans|Farm House Playscap|Cabin Restaurant|traditional driveways|Traditional driveways|The Mark Apartments|Farmhouse Sink in Kitchen|school are coming soon|Farmhouse Sink in Island|s/Cottage-Grove\"|CityName\":\"Cottage|City(Name)?\":\"Cottage|New Home Communities|stair rail in craftsman|No HOA dues|participation|CHOA at|(v|V)illage|every square foot. Pulte’s single-family", "");
			if(homeData != null) homeData = homeData.replaceAll("Farmhouse Sink in Island|(courtyard|carriage style) garage|car carriage style|City(Name)?\":\"Cottage|Courtyard Gate|courtyard draws|Aloravita - Estate Series|stair rail in craftsman|(v|V)illage|Duplex Cat|Villas at Inglewood", "");
//			propType = U.getNewPropType(U.getNoHtml((homeData+comHtml.replaceAll("data-copy=\".*\"", "")
//					.replace("not include HOA", ""))+comSec+featureListData)
//					.replaceAll("Traditional Front-Load Garage", ""));
//			U.log(priceComHtml);
//			U.log(propertyTypeSecGet);
			//
			propType = U.getNewPropType((propertyTypeSecGet.replace("Manor</a>", "Manor Homesites").replace("Estate</a>", "estate home").replace("Executive Townhomes</a>", "executive-style homes")+priceComHtml+propertyTypeSec+ametitesSec+ametitesSeeMore+descriptionSec+U.getNoHtml((comm_Detail+homeData.replaceAll("data-copy=\".*\"", "")
			.replace("not include HOA", ""))+comSec+featureListData).replace("Series: Gardens", "Series Gardens")
			.replaceAll("Traditional Front-Load Garage", "")).replace("<li>Townhome</li>", ""));
			if(comUrl.contains("https://www.pulte.com/homes/california/bay-area/santa-clara/anza-at-agrihood-210784")) {
				propType+=", Condominium";
			}
			U.log("propType :::::"+propType);
//			U.log(propertyTypeSec);
//			
//			
//			U.log("1>>>>>>>>>>>:::::"+Util.match(priceComHtml+propertyTypeSec+ametitesSec+ametitesSeeMore+descriptionSec, 
//					"[\\s\\w\\W]{100}townhome[\\s\\w\\W]{100}",0));

			// ==============================================================dProperty type============================================
			comHtml = comHtml.replaceAll("3 and 4-story townhomes have arrived at our newest community","3 Story, 4 Story").replaceAll(" Ranch,|Ranch Road|1st Floor|Branch|rancho| Ranch\"|Ranch&nbsp;|ranch- |3-Story Rock Climbing Wall|Lakewood Ranch Waterside, |Rancho|2nd Floor|-Ranch| Alamo Ranch", "").replace("single- and two-story homes", "single-story and two-story homes");
			homeData = homeData.replaceAll("3 and 4-story townhomes have arrived at our newest community","3 Story, 4 Story").replaceAll(" Ranch,|1st Floor|Branch| Ranch\"|Ranch&nbsp;|ranch- |3-Story Rock Climbing Wall|Lakewood Ranch Waterside, |Ranch Rd|Rancho", "").replace("single- and two-story homes", "single-story and two-story homes");
			comHtml=comHtml.replace("tri-level ", "3 story").replaceAll("one-and two-story |one-and two-story|one and two-story|1 & 2 Story Home Designs|1 &amp; 2 Story Home Designs", " 1 Story  2 Story ").replace("1 &amp; 2-Story Homes", " 1-Story  2-Story ")
					.replace(" 3rd Floor Retreat", " 3 Story Retreat")
					.replace("second-floor loft", "Two Story loft")
					.replace("three-story Bloomingdale’s|", "")
					.replace("1 &amp; 2-Story", "1 & 2 Story")
					.replace("4-story condominium building", "");
			additionalFeatures = additionalFeatures.replace("1 &amp; 2-Story", "1 Story & 2 Story");
			
			String dType = ALLOW_BLANK;
			if(ametitesSec!=null) {
				ametitesSec=ametitesSec.replace("2- and 3-Story", "2 Story and 3 Story");				
			}
//			U.log("ametitesSec"+ametitesSec);
//			dType = U.getNewdCommType(comHtml.replace("three-story Bloomingdale’s","")+homeData.replaceAll("floor|Floor|Ranch Road|-Ranch| Ranch Rd |Cabin Restaurant", "") + comSec.replaceAll("26 Storybook Lane|Ranch Road|-Ranch| Ranch Rd ", "")
//					+ additionalFeatures);
			dType = U.getNewdCommType(ametitesSec.replace("2-story and 3-story", "2 Story and 3 Story")+ametitesSeeMore+descriptionSec+(comm_Detail+featureListData).replace("three-story Bloomingdale’s","")+homeData.replaceAll("floor|Floor|Ranch Road|-Ranch| Ranch Rd |Cabin Restaurant", "") + comSec.replaceAll("26 Storybook Lane|Ranch Road|-Ranch| Ranch Rd ", "")
			+ additionalFeatures);
//			U.log(Util.matchAll(comHtml+homeData.replaceAll("floor|Floor", "") + comSec.replace("26 Storybook Lane", ""), "[\\w\\s\\W]{30}ranch[\\w\\s\\W]{30}", 0));
			if(comUrl.contains("https://www.pulte.com/homes/tennessee/nashville/hendersonville/norman-creek-209997"))dType="1 Story";
			U.log("dType :::::"+dType);
			
//			U.log(">>>>>>>"+Util.matchAll(ametitesSec,"[\\w\\W\\s]{100}2- and 3-story[\\w\\W\\s]{100}", 0));
		
			
			// ==============================================================Property Status============================================
			String globalFeat=ALLOW_BLANK;
			String statusTag=ALLOW_BLANK;
			 statusTag = U.getSectionValue(comHtml, "<h4 class=\"CommunityHero__status\"", "</h4>")+
					 U.getSectionValue(comHtml, "<div class=\"Community-status-flag\"", "</div>");
			if(statusTag!=null)statusTag=statusTag.replace("Opening in Mid-2021", "Opening Mid 2021");
			  globalFeat = U.getSectionValue(comHtml, "GlobalMapsObj.featuresMarkers", "</script>");
			if(globalFeat != null) globalFeat = globalFeat.replaceAll("Price Coming|CommunityStatus\":\"Coming", "");
			
			String carouselSection =  U.getSectionValue(comHtml, "Carousel-placeHolder carouselHasModal\">", "Carousel-slide\" data-type=\"form\">");
			
			comSec = comSec.replace("</span> Home Designs Available", " Home Designs Available")
					.replace("pool is now open", "");
			comSec=comSec.replaceAll("data-description=\".*\"|\"Final Opportunities in |\"communityDescription\":\"(.*?)\",", "").replaceAll("Opening March 2019, our Pinnacle Serie|design is coming soon||data-description=\"Only 1 home remains|content=\"Only 1 home remains|New Construction Coming Soon|ice rink coming soon| Final opportunities now selling|Now selling final opportunities by appointment|Grand Opening Summer 2019|\"CommunityStatus\":\"Coming Soon\",|Price Coming Soon|\"CtaQmiText\":\"1 Quick Move-Ins Available\",\"Latitude\":\"42.455571\"|Final Home Now Selling|span class\"caption\">New Homes Available Now</span>|\"Street1\":\"Coming Soon\"|</i>Coming Soon,|Coming Soon:|Now Open, Locke", "");
			comHtml = comHtml.replaceAll("communities, is now open|Only 1 home remains! New homes for sale|design is coming soon|design coming soon|ice rink coming soon|New Construction Coming Soon| Final opportunities now selling|Now selling final opportunities by appointment|Grand Opening Summer 2019|2nd Amenity Coming Soon|Gaming Lawn Coming Soon to Wynfield|-Coming Soon|and Ready to Move In</li>|295 Homesites Released in Sections</li|Coming Soon to the Estates|playgrounds coming soon|Amenities coming soon|ready for move in with an open floor plan|<li>ready for move in August</li>|Slab Lots Available|waterfront community is down to the final opportunities|Final Opportunities Here\\s+</a>|Restaurant is NOW OPEN|Opening March 2019, our Pinnacle Serie|VIP! Coming Soon in|<li><p>The coming soon community will be on your right|located in South Austin, is now selling homes from the high|Pricing Just Released|Just Released: |<div class=\"hours-item\">.* Coming Soon</div>|Monday Coming Soon|Price Coming Soon|Final Home Now Selling|Coming Winter 2018!\"|Pre-Sales Trailer will be on the Left|ready for move in with included basements and access to amenities. Only a few homes remain|<li>Ready to Move In Now!</li>|New Homesites Available\\!|<li>Ready for Move In Now!</li>|<li>Opening Spring 2018</li>|Just Released\\&quot; Amenity|NOW SELLING from Lochaven|home in the coming soon community of| is Coming Soon to Reston|\"Street1\":\"Coming Soon\"| <li>Coming Fall 2018</li>|</i>Coming Soon,|>\\s*Coming Soon,|Closing soon, limited inventory remains|<p><p>Homes are selling fast|Our first release|in our first release|pool is now open|community opening in early 2018|schools opening this fall|Opening Spring 2019, Pulte|Retail Area Opening Soon|CRYSTAL LAGOON OPENING SOON|Spradley, opening fall 2018|Final opportunity for the Lynwood |<li>Final Opportunity for 2018|slated to open in early 2018|caption\">Coming Winter 2018|<li>Grand Opening this Winter<|Exteriors Coming Soon|Coming Soon: a multi|Amenity Center Coming Fall 2018|Gathering Area - Coming 2019|Grand Opening of the Continental|Last chance to move in |year&nbsp;and homesites are selling fast| stores now open|Designs Now Available|is now available|Model Opening September 2018|Spacious Lots Available</li>|sac Lots Available|Grand Opening August|grand opening on Saturday|grand opening in August|New Building Grand Opening|tours are now open|now available for your new dream|grand opening information|grand opening on July|div class=\"StatusTag\">Sold Out</div>|now available for quick move-in|The Coming Soon Community will be|more information on this Coming Soon community|Clubhouse Opening Soon|courts - are opening soon|US, opening soon|Quick Move|quick move|now available at|Quick move| fast selling|Lake Coming Winter 2018|Dining Coming Soon|Price Coming Soon|>Coming Soon|\"Coming Soon|- Coming Soon|Coming Soon -|\"Coming Soon:|Temporarily sold out", "")
					.replaceAll("data-description=\".*\"", "").replaceAll("<meta name=\"description\" content=\"(.*?)\">|data-description=\".*\"|communityresults':\\s+\\{.*\\}", "").replace("(coming soon)","").replace("Launch) Coming Soon", "")
					.replace("Coming in Summer 2022", "Coming Summer 2022")
					.replaceAll("now selling from an offsite|Collection will opening soon|Beachwood Coming Soon|qmi-inventory hidden-xs\">\\s+<ul>\\s+<li>READY TO MOVE|(Center|Amenities) Opening|span class\"caption\">New Homes Available Now</span>|span class\"caption\">New Homes Available Now|<li>Ready to Move In|Farms. Coming late 2020", "")
					.replaceAll("(course) home site|We are currently selling in Del|offices are now open|plan is currently Sold Ou|Final Opportunities in |Acre\\+ Home Sites|(P|p)ool now|Coming later this year. Click or |clearfix\">\\s+<p>Currently Sold|class=\"hours-item\"> Currently Sold|Center (is )?Now |Opening of \\d Models|our official Grand|Lucero (New )?Homes Now Available|Series Homes Now|Available Now in Peoria|Released: (Amenity|Entry|View)|renderings just|Map Now|chance to own new|Opportunity for an End|to Move in February|Now Selling Brand", "")
					.replaceAll("first for coming soon information|Station coming Summer 2021|Drop Zone&quot; - Now Open|Final Opportunities for the Savanna |Final Opportunities for the Hemingway|Building 2 is already over 85% sold|Grand Opening 1st Quarter 2021|about grand opening|Ridge. Final opportunities.|class=\"StatusTag\">Last Chance|opening Fall 2019. Join our|hours-item\"> Almost Sold|<p>Almost Sold Out!|hours-item\"> Grand Opening Fall 2019|Now Open, Locke Pointe|Now Available with Optional|class=\"hours-item\"> Grand Opening (Late Summer|this Winter|January 2020)", "")
					.replace("Opening in Early 2022", "Opening Early 2022").replace("final homesites are coming soon", "final homesites coming soon").replaceAll("(data-alt=|data-image-caption=|Grand Opening in 4th Quarter|B Commons, coming soon,|span class=\"caption\">|;description=)\"?(Brand |Marana )?New Homes Coming Soon\"?|\\d+ Homesites Coming|COMMUNITY EXPANSION COMING|Soon with Sports|<li>Ready to", ""); //<li>Grand Opening this|
			
		//	U.log("---"+statusTag);
//			U.log(comHtml);
//			U.log(comSec);
			String eventSec=ALLOW_BLANK;
			 eventSec = U.getSectionValue(comHtml, "<h3>Events & Announcements</h3>", "Take Advantage of Low Interest Rates");
//			U.log("event: "+eventSec);
			//====== Remove Section =====
//			 rem=U.getSectionValue(comHtml, "<div class=\"GlanceViewSection plangallery active\">", To)
			
			rem = U.getSectionValue(comHtml, "<section id=\"plOffersEvents", "</section>");
			if(rem != null)comHtml = comHtml.replace(rem, "");
			
			rem = U.getSectionValue(comHtml, "<ul class=\"list-unstyled\">", "</ul>");
			if(rem != null)comHtml = comHtml.replace(rem, "");
			
			rem = U.getSectionValue(comHtml, "  GlobalMapsObj.nearbyMarkers =", "</script");
			if(rem != null)comHtml = comHtml.replace(rem, "");
			/*			String [] remVals = U.getValues(comHtml, "class=\"hidden-xs hours-container\">", "<div class=\"col");
			for(String rem1 : remVals)
				if(rem1 != null)comHtml = comHtml.replace(rem1, "");
*/			
			/*
			 * This section is used to replace 'quick move' property status which it is present in 'Nearby Neighborhood' content, 
			 * but it doesn't have quick move toggle button.
			 */
			if(!comHtml.contains("data-type=\"qmi\"")){
				if(globalFeat != null) globalFeat = globalFeat.replaceAll("CtaQmiText\":\"\\d+ Quick Move-Ins Available", "");
				if(comSec != null) comSec = comSec.replaceAll("CtaQmiText\":\"\\d+ Quick Move-Ins Available", "");
//				String quickMove = Util.match(comHtml, "");
			}
//			U.log(comSec);
			comHtml = comHtml.replace("new phase in now available", "new phase now available").replace("next section of the Legacy Collection will opening soon", "next section opening soon")
					.replace("final home is now available", "final home now available")
					.replace("Grand Opening in 2022", "Grand Opening 2022").replace("Grand Opening 1st Quarter of 2021", "Grand Opening in 1st Quarter 2021")
					.replaceAll("Now open for pre-sale|new townhome community coming soon.</p>|new townhome community coming soon.\"|coming soon\\)</li>|Pulte Homes is coming soon|grand opening events|<li>Ready for move in| Coming late 2021. Click or|Ready for Jan 2022|Ready for move in NOV|Ready for move in September 2021|Deneweth East. Coming late 2021|class=\"StatusTag\">Almost Sold|Park. Coming late 2021|(\"clearfix\">\\s+<p>|class=\"hours-item\"> )\\d+ Final Opportunities(</p>|</div>)", "")
					.replaceAll("soon to Shelby|no CDD. Coming Summer 2021| grand opening events|hours-item\"> (Coming|Now)| <div class=\"StatusTag\" data-automation=\"\">Last Chance</div>|Price Coming Soon\",\"CommunityStatus\":\"Coming|Sold Out. The Overlook|school coming|(description=)Now Selling|data-(alt|image-caption)=\"Now Selling|We're now selling in our second|We&#39;re now selling in our second", "");//class="caption">Now Selling!
			
//			U.writeMyText(comHtml);
			String imageVerticalStatus=ALLOW_BLANK;
			 imageVerticalStatus=U.getSectionValue(comHtml, "<div class=\"ImageCaption vertical-rule", "</div>");
	//		U.log("::::::::::::::::::"+statusTag+":::::::::::::::::::::::::::::::::::");
	//		U.log("::::::::::::::::::"+imageVerticalStatus+":::::::::::::::::::::::::::::::::::");
//			U.writeMyText(comSec + globalFeat+ comHtml +statusTag + imageVerticalStatus);
			 if(imageVerticalStatus!=null)
			  imageVerticalStatus=imageVerticalStatus.replace("Now Selling!", "Now Selling");
			String comstatussec=ALLOW_BLANK;
			comstatussec=U.getSectionValue(U.getHTML(comUrl), "<div class=\"col-xs-12 col-md-7 u-xs-noPad\">", "<div class=\"CommunityHero__addressContainer\"");
			//U.log(comstatussec);
//			String quickCount=ALLOW_BLANK;
//			 quickCount=U.getSectionValue(comHtml, " data-analytics=\"homes-glance|toggle|qmis\">", " </div>");
//			//U.log(quickCount);
//			if(quickCount!=null && quickCount.contains("(0)"))quickCount="";
//			else if(quickCount!=null){
//				String data=Util.match(quickCount, "-In (\\(\\d+\\))",1);
//				data = data.replaceAll("\\(|\\)","");
//				data = data+" Quick Move-ins Available";
//				quickCount = data;
//				U.log("qkcount=="+data);
//			}
			
			
//			=======================Quick home count============================
			
//			String[] quickHomes=U.getValues(comHtml, "<h3 class=\"u-no-empty-collapse\">", "View Home");
			
			
			
			if(comstatussec!=null)
				comstatussec = comstatussec.replaceAll("content=\".*\"", "").replace("Grand Opening in 2022", "Grand Opening 2022");
			if(featureListData!=null)
				featureListData = featureListData.replaceAll("content=\".*\"", "").replace("Grand Opening in 2022", "Grand Opening 2022");
			
			String remove[] = U.getValues(comHtml, " <div class=\"HomeDesignCompact__images\">", "</div>");
			for(String s: remove) {
				comHtml= comHtml.replace(s, "");
				
			}
			comHtml = comHtml.replace("Grand Opening in 2022","Grand Opening 2022");
			String directions=ALLOW_BLANK;
			if(comUrl.contains("https://www.pulte.com/homes/new-mexico/albuquerque/albuquerque/petroglyph-estates-210551")) {
			directions=U.getSectionValue(comHtml, "<div class=\"col-sm-7 col-sm-offset-1 Map-directionsSteps\">","<script>");
			comHtml=comHtml.replace(directions,"");
			}
			String rem2=ALLOW_BLANK;
			
		//	U.log("MMMMMMMMMMMMM"+Util.matchAll(comHtml, "[\\s\\w\\W]{100}class=\"iconmapinteractive[\\w\\s\\W]{100}",0)); 

		//    U.log("rem frm all"+rem2);
		    if(rem!=null) {
			comHtml=comHtml.replace(rem2,"");	
		    }
//			U.log("mmmmmm"+Util.matchAll(comHtml+quickCount +comstatussec+comSec + globalFeat+ statusTag + imageVerticalStatus+featureListData+eventSec + carouselSection +imageCaption, "[\\w\\s\\W]{100}Homesites Remaining[\\w\\s\\W]{100}", 0));

		    if(comstatussec!=null)
		    	comstatussec = comstatussec.replace("Opening in Mid-2022", "Opening Mid 2022")
		    	.replace("Opening in Early 2023", "Opening Early 2023")
		    	.replace("Opening in Early 2022", "Opening Early 2022");
//		    U.log("statusTag: "+comstatussec);
		    
//		    U.log("************"+comHtml.matches("<div data-analytics-zone="));
		    String remSec=U.getSectionValue(comHtml, "div class=\"GlanceViewSection planlist\">", "data-analytics-zone=\"Area Details\">");
		    		if(remSec!=null) {
		    			comHtml=comHtml.replace(remSec, "");
		    		}
		    		String remm=U.getSectionValue(comHtml, "<div class=\"GlanceView\">", "<h3>Area Details</h3>");
		    if(remm!=null)
		    	comHtml=comHtml.replace(remm, "");
		    else
//		    	U.log(">>>>>>> nulllllllll");
		    		
		    comHtml = comHtml
		    		
		    		.replace("opening in Spring of 2022", "opening Spring 2022")
		    		.replaceAll("data-alt=\"New Homes Available Now\"", "")
		    		.replace("oversized homesites are now selling in the gated, boutique community of Hawks Reserve", "")
		    		.replace("final home is now available", "final home now available")
		    		.replaceAll("Join the VIP list today to receive information about our grand opening|Register as a VIP for Grand Opening updates|Join our VIP interest list today to be the first to hear about upcoming milestones, grand opening events, pricing and more|Join Our VIP List for Grand Opening Updates", "");
		   
		//   U.log("ProCHK"+Util.matchAll(comHtml +comstatussec+comSec + globalFeat+ statusTag + imageVerticalStatus+quickCount+featureListData+eventSec+carouselSection,"[\\w\\W\\s]{30}coming Soon[\\w\\W\\s]{30}", 0));
			//U.log("IMG"+imageVerticalStatus);
		    if(imageVerticalStatus!=null)
			imageVerticalStatus=imageVerticalStatus.replace("<span class=\"caption\">Now Selling</span>","Now Selling");
		
		  //  U.log("imageCaption: "+imageCaption);
		    imageCaption = imageCaption.replaceAll("<li>Coming Soon: The Midtown|<li>Coming Soon: The Living Room", "");

//			String propertyStatus = U.getNewPropStatus((comHtml+quickCount +comstatussec+comSec + globalFeat+ statusTag + imageVerticalStatus+featureListData+eventSec)
//					.replace("Coming Soon, Willow Ridge will offer new construction home designs in Montverde", "")
//					.replaceAll("including the coming soon Lake Nona|Price Coming Soon|Our models are now open|new homes at Ascent at Montelena. Coming Summer 2022. Click or call", "")
//					.replace("Quick Move-In (3)", "3 Quick Move-ins Available")
//					.replace("Quick Move-In (4)", "4 Quick Move-ins Available")
//					.replace("Now Selling!", "Now Selling")
//					.replaceAll("Opening In Early|OPENING IN EARLY", "Opening Early")
//					.replace("Grand Opening in 2022", "Grand Opening 2022")
//					.replaceAll("content=\"Emerson Park is nearly sold out|content=\".*\"|now available choose|<li>New phase coming soon</li>|no CDD. Coming Summer 2021|about last opportunities at Blue Ridge Creek|<li>Lake View Lots Available</li>|\"CtaQmiText\":\"3 Quick Move-Ins Available\"|<li>Greenbelt home sites available</li>|<li>Greenbelt Homesites Available</li>| coming soon is the Founders |Price Coming Soon|<li>New Phase Coming Soon!</li>|new schools coming soon|Dover are coming soon|Now Open in Fuquay-Varina|den, tot lot and common areas coming soon|StatusTag\" data-automation=\"\">Sold Out", "").replaceAll("&#39;","").replaceAll("Grand Opening this Fall","Grand")
//					.replace("Phase 3 - Now Selling", "Phase 3 Now Selling")
//					.replace("lakefront, homesites available", "lakefront homesites available")
//					.replaceAll("New Home Builder Now Open|tours of our final home available|Join the VIP list today to receive information about our grand opening|New homesites and model coming early 2022|Anticipated Opening Late 2021|\"PriceStatus\":null,\"CommunityStatus\":\"Sold Out\"|<div class=\"StatusTag\" dataautomation=\"\">Sold Out</div>|<div class=\"hours-item\">\\s*Coming Soon|Model Homes coming soon|\"CommunityStatus\":\"Grand Opening\"|grand opening event|Center coming soon|Price Coming Soon|\"CommunityStatus\":\"Coming Soon\"|Coming Soon Lake|Township is coming soon|Now open, the newest|\\(coming soon\\)</li>| Phase 2 now available. Join interest|Now Selling new single-family|Now Open! Union Park’s quick access|data-description=\"Now Ope|Ready for move in July 2021|coming soon to The|Now Open in Fishers|are coming soon to Sagewood|Tradition Trail COMING SOON|COMING SOON! Pool and Tot Lot|103 Homesites Coming Soon|Swings Coming Soon| grand opening events|our Grand Opening details|complex and more. Coming Fall 2021|OPEN in Novi|Grand Opening in 4th Quarter|Spring 2020|open for sales|new homes coming soon in Spicewood|B Commons, coming soon,|road to 429 coming soon|selling offsite|grand opening details|Grand Opening events|community grand opening|happens\\. Now selling final homesites|Model opening|One 90\\. Coming summer 2021|Borelle at One 90\\. Coming spring|Station coming Spring|Coming soon -100-acre Gray|Brighton are selling|selling now!\"|Chapel are now available|<span class=\"caption\">(.+?)</span>|ours-item\"> Now open for pre-sale! Schedule an |Move-In Ready Homes<|Move-In Ready Homes\"|Coming soon - O-|<p>Now Selling Sunset Preserve|data-copy=\"Coming soon|Brand New Homes Coming Soon|uckeye Homes Coming Soon|Final opportunity for Venice plan|Inspiration is Coming Soon|Soon\"|Soon!\"|Stella Coming|data-.*\"|homes are selling fast</li>|Cul-de-Sac Lots|\"Coming|Opening!\"|Coming Summer 2020\\. Click|Park is Now Selling|Sold Out \\| A limited number|Now available with a|LIMITED AVAILABILITY ON SELECT HOMESITES|Limited Opportunity for this Floor|School Coming|Park Now|Models Now Open|Last opportunity for a Pulte home|Homes Now Available at The Meadows|Meadows Now Availabl|Pool Now|Amenity Coming|track coming|Grand Opening Saving|\"PriceStatus\":\"Price Coming Soon\",\"CommunityStatus\":\"Coming|\"PriceStatus\":\"Price Coming Soon\"|Amenities Now Open|Amenities now open|club living is now selling |One of the Last Chances|Now Selling from The|Now selling fro|one Quick Move-In Home|(model home and|about our) quick move|more coming soon|Inspiration Coming Soon|The Grove at Beulah Park. Coming this Fall.|we're selling fast!|and entertainment coming soon.|\"Price Coming Soon\"|Final opportunities to buy a new home at close-out pricing", "")
//					.replaceAll("<div class=\"hoursitem\"> Almost sold out</div>|Recreation Area Coming Soon|<li>Coming Soon: The Midtown|<li>Coming Soon: The Living Room|Vista Reserve! Less than 10 opportunities remain|oversized homesites are now selling in the gated|construction and opening soon|Minutes to coming soon|Price Coming Soon", "")
//					+ carouselSection +imageCaption)
//					;
		    
		    
		    
		    String propertyStatus = U.getNewPropStatus(((additionFeatures.replace("Water-View and Greenspace Homesites Available", "Water-View Homesites Available")+descriptionStatus+comm_Detail +comstatussec+comSec + globalFeat+ statusTag + imageVerticalStatus+featureListData+eventSec)
		    		.replace("Amenity Center Now Open", "")
		    		.replace("Mid-2022", "Mid 2022")
		    		.replace("Brand New Homes Available No", "")
		    		.replace("Time Offer", "")
		    		.replace("Ask About Final Opportunities", "")
					.replace("Coming Soon, Willow Ridge will offer new construction home designs in Montverde", "")
					.replaceAll("including the coming soon Lake Nona|Price Coming Soon|Our models are now open|new homes at Ascent at Montelena. Coming Summer 2022. Click or call", "")
					.replace("Quick Move-In (3)", "3 Quick Move-ins Available")
					.replace("Quick Move-In (4)", "4 Quick Move-ins Available")
					.replace("Now Selling!", "Now Selling")
					.replaceAll("Opening In Early|OPENING IN EARLY", "Opening Early")
					.replace("Grand Opening in 2022", "Grand Opening 2022")
					.replaceAll("quick move-|Quick Move-", "")
					.replaceAll("content=\"Emerson Park is nearly sold out|content=\".*\"|now available choose|<li>New phase coming soon</li>|no CDD. Coming Summer 2021|about last opportunities at Blue Ridge Creek|<li>Lake View Lots Available</li>|\"CtaQmiText\":\"3 Quick Move-Ins Available\"|<li>Greenbelt home sites available</li>|<li>Greenbelt Homesites Available</li>| coming soon is the Founders |Price Coming Soon|<li>New Phase Coming Soon!</li>|new schools coming soon|Dover are coming soon|Now Open in Fuquay-Varina|den, tot lot and common areas coming soon|StatusTag\" data-automation=\"\">Sold Out", "").replaceAll("&#39;","").replaceAll("Grand Opening this Fall","Grand")
					.replace("Phase 3 - Now Selling", "Phase 3 Now Selling")
					.replace("lakefront, homesites available", "lakefront homesites available")
					.replaceAll("New Home Builder Now Open|tours of our final home available|Join the VIP list today to receive information about our grand opening|New homesites and model coming early 2022|Anticipated Opening Late 2021|\"PriceStatus\":null,\"CommunityStatus\":\"Sold Out\"|<div class=\"StatusTag\" dataautomation=\"\">Sold Out</div>|<div class=\"hours-item\">\\s*Coming Soon|Model Homes coming soon|\"CommunityStatus\":\"Grand Opening\"|grand opening event|Center coming soon|Price Coming Soon|\"CommunityStatus\":\"Coming Soon\"|Coming Soon Lake|Township is coming soon|Now open, the newest|\\(coming soon\\)</li>| Phase 2 now available. Join interest|Now Selling new single-family|Now Open! Union Park’s quick access|data-description=\"Now Ope|Ready for move in July 2021|coming soon to The|Now Open in Fishers|are coming soon to Sagewood|Tradition Trail COMING SOON|COMING SOON! Pool and Tot Lot|103 Homesites Coming Soon|Swings Coming Soon| grand opening events|our Grand Opening details|complex and more. Coming Fall 2021|OPEN in Novi|Grand Opening in 4th Quarter|Spring 2020|open for sales|new homes coming soon in Spicewood|B Commons, coming soon,|road to 429 coming soon|selling offsite|grand opening details|Grand Opening events|community grand opening|happens\\. Now selling final homesites|Model opening|One 90\\. Coming summer 2021|Borelle at One 90\\. Coming spring|Station coming Spring|Coming soon -100-acre Gray|Brighton are selling|selling now!\"|Chapel are now available|<span class=\"caption\">(.+?)</span>|ours-item\"> Now open for pre-sale! Schedule an |Move-In Ready Homes<|Move-In Ready Homes\"|Coming soon - O-|<p>Now Selling Sunset Preserve|data-copy=\"Coming soon|Brand New Homes Coming Soon|uckeye Homes Coming Soon|Final opportunity for Venice plan|Inspiration is Coming Soon|Soon\"|Soon!\"|Stella Coming|data-.*\"|homes are selling fast</li>|Cul-de-Sac Lots|\"Coming|Opening!\"|Coming Summer 2020\\. Click|Park is Now Selling|Sold Out \\| A limited number|Now available with a|LIMITED AVAILABILITY ON SELECT HOMESITES|Limited Opportunity for this Floor|School Coming|Park Now|Models Now Open|Last opportunity for a Pulte home|Homes Now Available at The Meadows|Meadows Now Availabl|Pool Now|Amenity Coming|track coming|Grand Opening Saving|\"PriceStatus\":\"Price Coming Soon\",\"CommunityStatus\":\"Coming|\"PriceStatus\":\"Price Coming Soon\"|Amenities Now Open|Amenities now open|club living is now selling |One of the Last Chances|Now Selling from The|Now selling fro|one Quick Move-In Home|(model home and|about our) quick move|more coming soon|Inspiration Coming Soon|The Grove at Beulah Park. Coming this Fall.|we're selling fast!|and entertainment coming soon.|\"Price Coming Soon\"|Final opportunities to buy a new home at close-out pricing", "")
					.replaceAll("Coming Soon, Avon Lake|Coming Soon, Wadsworth|<div class=\"hoursitem\"> Almost sold out</div>|Recreation Area Coming Soon|<li>Coming Soon: The Midtown|<li>Coming Soon: The Living Room|Vista Reserve! Less than 10 opportunities remain|oversized homesites are now selling in the gated|construction and opening soon|Minutes to coming soon|Price Coming Soon", "")
					+ carouselSection +imageCaption).replaceAll("Move-In Ready Homes|Quick Move-Ins|Quick move-in", ""))
					;
		    
		    propertyStatus=propertyStatus.replaceAll("\\d+ Quick Move-Ins Available", "");
		    
//			U.log("===1====="+Util.matchAll((comHtml)
//			, "[\\s\\w\\W]{100}72 Available Homesites[\\s\\w\\W]{100}", 0));
//		    U.log(propertyStatus);
//		    U.log("quickHomes=="+quickHomes.length);
//			for(String quickHome :quickHomes) {
//				if(quickHome.contains("<div class=\"data-value u-no-empty-collapse\">\n" + 
//						"                        Available Now")
//						||quickHome.contains("<div class=\"data-value u-no-empty-collapse\">\n" + 
//								"                        Contact Us") ) {
//					quick_Count++;
//				}
//			}
//		    U.log("quick_Count=="+quick_Count);
		    U.log(quick_Count);
			if(quick_Count==0 && quickHomeAvail==true) {
			if(propertyStatus.length()>2) {
				propertyStatus+=", Quick Move-ins";
			}
			else {
				propertyStatus="Quick Move-ins";
			}
			}
		    
//			U.log("===1====="+Util.matchAll((comHtml+quickCount +comstatussec+comSec + globalFeat+ statusTag + imageVerticalStatus+featureListData+eventSec + carouselSection +imageCaption)
//					, "[\\s\\w\\W]{100}Coming Soon[\\s\\w\\W]{100}", 0));
//			

		//<span class="caption">Now Open for Pre-Sales!</span>
//			U.log("propertyStatus===== "+propertyStatus);
						


			if(propertyStatus.contains("Quick Move-ins") && propertyStatus.contains("Coming Soon")) {
				propertyStatus=propertyStatus.replace("Coming Soon","");
				propertyStatus=U.getNewPropStatus(propertyStatus);
			}
			U.log("*** "+propertyStatus);
//			if(comUrl.contains("https://www.pulte.com/homes/washington/seattle/bellevue/90-degrees-210635"))propertyStatus="Coming Sonn";
			propertyStatus=propertyStatus.replace("3 Quick Move-ins Available, Quick-move In Homes", "3 Quick Move-ins Available");
//			if(comUrl.contains("https://www.pulte.com/homes/michigan/detroit/plymouth/andover-forest-210470"))
//				propertyStatus = propertyStatus.replace("Grand Opening", "Grand Opening 2020");
			propertyStatus = propertyStatus.replace("Now Selling Final Phase, Now Selling", "Now Selling Final Phase");
			propertyStatus = propertyStatus.replace("Final Homes Now Selling, Now Selling", "Final Homes Now Selling");
			propertyStatus = propertyStatus.replace("Now Selling Out, Now Selling", "Now Selling Out");
			propertyStatus = propertyStatus.replace("New Phase Now Available, New Phase Available", "New Phase Now Available");
			propertyStatus = propertyStatus.replace("Selling Now, Selling Now", "Selling Now");
			if(imageVerticalStatus == null)
				imageVerticalStatus = "";

			comHtml = comHtml.replaceAll("pre-selling information", "");
			if(comUrl.contains("https://www.pulte.com/homes/washington/seattle/seattle/357-degrees-210789"))propertyStatus="7 Quick Move-ins Available, Now Selling";
			if(propertyStatus.contains("Coming Sonn"))propertyStatus=propertyStatus.replace("Coming Sonn", "Coming Soon");
			comHtml=comHtml.replace("Now Pre-Selling!", "Now Pre-Selling");
			statusFlag=statusFlag.replace("Now Pre-Selling", "Now Pre-selling");
			String notes = U.getnote(comHtml
					.replace("<p>We are preselling from 17305 Bracken Fern", "")
					.replaceAll("Call to schedule your informational appointment today. Presales coming soon|Call to schedule your informational appointment today. Pre-sales coming soon!", "")
					.replace(imageVerticalStatus, "")
					.replaceAll("Directions to PreSale Location|Directions to Pre-Sale Location|pre-selling information|We are pre-selling from \\d+|Pre-Sale Location|selling now!\"|now available choose|Foxtail for pre-sale|Pre-selling by appointment|ours-item\"> Now open for pre-sale! Schedule an |=\".*(\n)?\"|Pulte Homes is Now Pre-Selling|Pre-Selling from Marinwood|Pre-Sales Gallery|<title>New Homes for Sale| homes for sale at Montecito Vistas|Now for sale at La Orilla|Pre-Selling from Urbane Village|our new homes for sale|Find new homes for sale|is open for sale from the Pre-Sales Gallery|open for sale from|Pulte’s new homes for sale|call home. Pre-selling|<div class=\"hours-item\"> Now open for pre-sale", "")+statusFlag);
//			U.log(Util.matchAll(comHtml, "pre-sale", 0));
//			U.log("===1====="+Util.matchAll((comHtml)
//					, "[\\s\\w\\W]{100}preselling[\\s\\w\\W]{100}", 0));
			if(comUrl.contains("https://www.pulte.com/homes/michigan/detroit/clinton-township/hillcrest-210475")) {
				notes="New Phase Now Pre-Selling";
			}
			if(comUrl.contains("https://www.pulte.com/homes/ohio/columbus/columbus/sugar-farms-210812")) {
				notes="Now Pre-selling";
			}
			if(add[0].length()<1) {
				String add1[] = U.getAddressGoogleApi(latlong);
				if(add1 == null) add1 = U.getGoogleAddressWithKey(latlong);
				add[0] = add1[0];
//				add[0]=U.getAddressGoogleApi(latlong)[0];
				geo="TRUE";
			}
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]).trim();
			}
			if(add[0].contains(",")) {
				String temp[]=add[0].split(",");
				add[0]=temp[0];
				
			}
			add[0]=add[0].toLowerCase().replace("&amp;", "").replace("gps: ", "");
			if(comUrl.contains("https://www.pulte.com/homes/minnesota/the-twin-cities/cottage-grove/bailey-woods-expressions-collection-210437"))propertyStatus="Sold Out";
			if(propertyStatus.contains("New Section Now Available") && propertyStatus.contains(",Now Available"))propertyStatus=propertyStatus.replaceAll(",Now Available", "");
			if(propertyStatus.contains("Grand Opening This Fall"))propertyStatus=propertyStatus.replaceAll("Grand Opening This Fall, Opening This Fall", "Grand Opening This Fall");
			if(propertyStatus.contains("New Section Now Available,") && propertyStatus.contains(", Now Available"))propertyStatus = propertyStatus.replace(", Now Available", "");
			if(propertyStatus.contains(" Phase Three Now Open, Now Open"))propertyStatus=propertyStatus.replaceAll(" Phase Three Now Open, Now Open", " Phase Three Now Open");
	
			if(add[0].contains("+") || add[0].contains("/")) {
				add[0]=add[0].replaceAll("\\+", "&");
				add[0]=add[0].replaceAll("/", " & ");
			}
			if(propertyStatus.contains("New Section Now Available") && propertyStatus.contains(", Now Available"))propertyStatus=propertyStatus.replace(", New Section Now Available, Now Available", ", New Section Now Available");
			if(propertyStatus.contains("Final Opportunities, ") && propertyStatus.contains(", Now Selling") && comHtml.contains(" Final opportunities now selling")) {
				propertyStatus=propertyStatus.replace("Final Opportunities,", "");
				propertyStatus=propertyStatus.replace(", Now Selling", "");
				propertyStatus= propertyStatus+", Final Opportunities Now Selling";
			}
			
			U.log("Comm Status:" + propertyStatus);
			
			if(propertyStatus.contains("Lakefront") && comType.contains("Lakefront Community"))
				comType = comType.replaceAll("Lakefront Community,|Lakefront Community", "");
			
			propertyStatus = propertyStatus.replace("Now Open, New Phase Now Open", " New Phase Now Open");
			
			//From Image
			
			
			   propertyStatus=propertyStatus.replace("Only 2 Remaining,", "");
			propertyStatus = propertyStatus.replace("Final Home Remaining, Only 1 Home Remaining", "Only 1 Final Home Remaining")
					.replace("Only 2 Homesites Remain, Only 2 Homes Remaining", "Only 2 Homesites Remain");
			
			comType = comType.replace("Lakefront Community, Lakeside Community", "Lakefront Community");
			
			if(comUrl.contains("florida/orlando/st-cloud/live-oak-lake-210142"))propertyStatus=propertyStatus.replace("Coming Soon, ", "");

			// ============================ Number of Units =============================
			String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			
			String totalUnits=ALLOW_BLANK;
			String sitemapJsonurl = ALLOW_BLANK;
			String noOfUnits1=ALLOW_BLANK; String sitemapJsonData = ALLOW_BLANK;
			int lotLableCount=0;
			int lotCCount=0;
			
			String siteMapSec = U.getSectionValue(comHtml2,"<h2></strong>Homesite Map</strong> </h2>", "Open Interactive Map</a>");
			
			if(siteMapSec == null && comHtml2.contains("<div class=\"Lot-cta\">")) {
				siteMapSec = U.getSectionValue(comHtml2,"<div class=\"Lot-cta\">", "See Available Homesites");
			}
			
			//U.log("SiteSec:: "+siteMapSec);
			
			if(siteMapSec!=null) {
				
			String siteMapUrl=U.getSectionValue(siteMapSec, "href=\"", "\"");
			U.log("1ST sitemap Url: "+siteMapUrl);
			
			if(siteMapUrl.contains("OLAId=") && siteMapUrl.contains("&amp")) {
			
				String partKey=U.getSectionValue(siteMapUrl, "OLAId=", "&amp");
//				U.log("PartKey"+partKey);
				if(partKey.contains("==") || partKey.contains("+")) {
					String subMapUrlEncode = URLEncoder.encode(partKey, "UTF-8");
					String guiIdLink = "https://services.alpha-vision.com/api/apiola/IsAlphamapActive?olaId=" + subMapUrlEncode;
//					U.log("guiIdLink: "+guiIdLink);
					String guiHtml = U.getHTML(guiIdLink);
//					U.log("path:: "+U.getCache(guiIdLink));
					String guiId = U.getSectionValue(guiHtml, "\"GUID\":\"", "\"");
//					U.log("guiId: "+guiId);
					
					String jsonUrl = "https://apps.alpha-vision.com/olajson/" + guiId + ".json";
//					U.log("jsonUrl guiId: "+jsonUrl);
					sitemapJsonurl = jsonUrl;
				}
				else {
					String jsonUrl = "https://apps.alpha-vision.com/olajson/" + partKey + ".json";
//					U.log("jsonUrl_One: "+jsonUrl);
					sitemapJsonurl = jsonUrl;
				}
			}	
			else
			{
				String[] olaIds = siteMapUrl.split("OLAId=");
				sitemapJsonurl="https://apps.alpha-vision.com/olajson/"+olaIds[1].trim()+".json";
				sitemapJsonurl=sitemapJsonurl.replaceAll("==&amp;languageId=1|&amp;languageId=1","");
//				U.log("Sitemap JSON url:: "+sitemapJsonurl);
				
			}
			
			sitemapJsonData=U.getPageSource(sitemapJsonurl);
//			U.log("Path:: "+U.getCache(sitemapJsonurl));
			
			//Below code for site map with different sub communities [only if part] ---------------
			if(comUrl.contains("/merit-at-banner-park-210687") || comUrl.contains("/crest-at-banner-park-210688") ||
			comUrl.contains("/heritage-at-banner-park-210681")) {
				
			//String[] lotLabel=U.getValues(sitemapJsonData, "\"AttributeName\":\"LotLabel\"", "\",");
			String[] lotLabel=U.getValues(sitemapJsonData, "\"LotNumber\":", "\",");
			lotLableCount=lotLabel.length;
			
			String MapJsonData=U.getSectionValue(sitemapJsonData, "pre-wrap;\">", "</pre></body></html>");
			JsonParser parser =new JsonParser();
			Object obj=null;
			if(MapJsonData!=null)
				obj =parser.parse(MapJsonData);
			else
				obj=parser.parse(sitemapJsonData);
			JsonObject siteJsonObj = (JsonObject)obj;
			JsonArray lotGroups=(JsonArray) siteJsonObj.get("LotGroups");
			
			for(int i=0;i<lotGroups.size();i++)
			{
				JsonObject lot=(JsonObject) lotGroups.get(i);
				String lotCount=lot.get("LotCount").getAsString();
				lotCCount +=Integer.parseInt(lotCount);
			}
			
			totalUnits = Integer.toString(lotLableCount);
		}
			
			else {
				
				String unitsData = getUnits(sitemapJsonurl, sitemapJsonData);
//				U.log("unitsData: "+unitsData);
				totalUnits = unitsData;
			}
		}
			else {
//				U.log("sitemapSec NULL");
			}
	
		   if(totalUnits.equals("0")) totalUnits = ALLOW_BLANK;
		   U.log("Number Of Units: "+totalUnits);
			
	
		   propertyStatus=propertyStatus.replaceAll("\\d+ Quick Move-ins Available", "Quick Move-in");
	
			data.addCommunity(comName.replace(" - Condominium Collection", "").replace("Oak Forest Manor", "Oak Forest"), comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2], add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus.replace("-,", ""));
			data.addNotes(notes.replaceAll("Now Pre-selling, Pre-selling|Now Pre-selling, Pre-sale|Preselling", "Now Pre-selling").replace("Now Now Pre-selling", "Now Pre-selling"));
            data.addConstructionInformation(startDt, endDt);
            data.addUnitCount(totalUnits);
		}
		j++;
//		}catch(Exception e) {}
	}
	
	public static String getUnits(String sitemapJsonUrl, String sitemapJsonData) throws IOException {
		
		String unitsNumber = ALLOW_BLANK;
		int countOfLots = 0;
		
		//FLOW 1 - for site maps containing phases
		if(sitemapJsonData.contains("layers/main_lots") && sitemapJsonData.contains("/layers/zones.svgz")) {
			
//			U.log("MAP WITH PHASES >>>>>> "+Util.matchAll(sitemapJsonData, "[\\s\\w\\W]{50}layers/main_lots[\\s\\w\\W]{30}", 0));
			ArrayList<String> mainLotUrls = 
					Util.matchAll(sitemapJsonData, "/homebuilders/\\d+/communities/\\d+/siteplans/\\d+/layers/main_lots_\\d+.svgz", 0);
//			U.log("mainLotUrls size: "+mainLotUrls.size());
			
			for(String mainLotUrl : mainLotUrls) {
//				U.log("mainLotUrl: "+mainLotUrl);
				String urlForCountOne = "https://apps.alpha-vision.com" + mainLotUrl;
				
//				U.log("urlForCountOne: "+urlForCountOne);
				
				String dataForCountOne = U.getPageSource(urlForCountOne);
//				U.log(U.getCache(urlForCountOne));
				
				String[] getCountWithPhase = U.getValues(dataForCountOne, "class=\"lot\"", ">");
//				U.log("getCount: "+getCountWithPhase.length);
				
				countOfLots = countOfLots + getCountWithPhase.length;
			}
			unitsNumber = String.valueOf(countOfLots);
		}
		
		else {
			//FLOW 2 - for site maps without phases
			
//			U.log("MAP WITHOUT PHASES >>>>>> "+Util.matchAll(sitemapJsonData, "[\\s\\w\\W]{50}layers/main_lots[\\s\\w\\W]{30}", 0));
			String urlForCount = Util.match(sitemapJsonData, "/homebuilders/\\d+/communities/\\d+/siteplans/\\d+/layers/main_lots_\\d+.svgz");
			
			urlForCount = "https://apps.alpha-vision.com" + urlForCount;
		
			
//			U.log("urlForCount: "+urlForCount);
			
			String dataForCount = U.getPageSource(urlForCount);
//			U.log(U.getCache(urlForCount));
			
			String[] getCount = U.getValues(dataForCount, "class=\"lot\"", ">");
//			U.log("getCount: "+getCount.length);
			
			unitsNumber = String.valueOf(getCount.length);
		}
		
		return unitsNumber;
	}

}