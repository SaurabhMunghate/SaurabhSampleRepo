/*
 * Modification Aditya.
 */
package com.shatam.b_001_020;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class NV_Homes extends AbstractScrapper {

	CommunityLogger LOGGER;
	static int m=0;
	public int j = 0;
	public int k = 0;
	public int i = 0;
	public int inr = 0;
	static int duplicates = 0;
	private static String HOME_URL = "https://www.nvhomes.com";

	public WebDriver driver =null;
	ArrayList<String> setofcomm = new ArrayList<String>();
 
	
	
	public static void main(String[] args) throws Exception {
		
		
		long startTime = System.currentTimeMillis();
		AbstractScrapper a = new NV_Homes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"NVR - NV Homes.csv", a.data().printAll());
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("total time :: "+totalTime);
		U.log("No of Duplicates Entry: "+duplicates);
	}

	public NV_Homes() throws Exception {

		super("NVR - NV Homes", HOME_URL);
		LOGGER = new CommunityLogger("NVR - NV Homes");

	}

	public void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver= new FirefoxDriver();

		String html = U.getHTML("https://www.nvhomes.com/");
		String regSec[] = U.getValues(html, "<div class=\"market-names-buttons\">", "</a>");

		U.setUpChromePath();
		driver = new ChromeDriver();

		for(String reg : regSec) {
		
		String regUrl = U.getSectionValue(reg, "<a href=\"", "\"");
		int cnt = 0;
		int subCnt = 0;
		
		//for(String regUrl : regUrls){
		U.log("regUrl: "+regUrl);
			//if(regUrl.contains("-"))continue;
			U.log("Reg Url ::"+HOME_URL+regUrl);
			String regHtml = U.getHtml(HOME_URL+regUrl,driver);
			String comSections [] = U.getValues(regHtml, "<div class=\"card card-body-search-results\"", "<div class=\"search-results-city-state\">");
			//U.log(comSections.length);
			for(String comSec : comSections){
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");     //https://www.nvhomes.com/new-homes/communities/10222120150955/delaware/lewes/marsh-farms
				
				//U.log(cnt+"=="+comUrl);
				
				 //* This below section is used to find subcommunities and property status from main community page.
				
				//if(comUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151612/virginia/arlington/arlington-heights")){   //---------- comment this line for run single community
//					U.log("Com Url=="+comUrl);       //		/new-homes/communities/10222120151692/pennsylvania/west-chester/greystone
					String comHtml = U.getHTML(HOME_URL+comUrl);
					if(comHtml.contains("<h3 class=\"mpc-collections-title nv-text-white\">")) {
						String [] subComSections = U.getValues(comHtml, "<div class=\"card mpc-card-link\">", "<div class=\"search-results-city-state\">");
					//U.log("Sub Comm Count ::"+subComSections.length);
					if(subComSections.length > 0){
						for(String subComSec : subComSections){
	//						U.log("==="+subComSec);
							String subComUrl = U.getSectionValue(subComSec, "<a href=\"", "\"");
							U.log("sub Com Url =="+subComUrl);
							
							addDetails(subComUrl,regHtml, subComSec+comSec); //---second args is having sub community data from main community page and main community data from reg page
//							cnt++;
							subCnt++;
						}}
					}
					else{
						addDetails(comUrl,regHtml, comSec);
						
						
						/*if(comSec.contains("west-fenwick-island/overlook"))
							comSec = comSec;
						addDetails("/neighborhoods/de/sussex/west-fenwick-island/overlook", comSec);*/
						
						if(comSec.contains("mpc-two-rivers"))
							comSec = comSec;
//						addDetails("/new-homes/communities/9449720020131/maryland/odenton/two-rivers", comSec);
					}
				//}//------------ comment this line for close if statement
				cnt++;
			}//eof for 
			//break;
			U.log(cnt);
		}
		
		LOGGER.DisposeLogger();
		driver.quit();
	}

	
	int count = 0;

	//TODO : Extract Community Details
	public void addDetails(String url,String regHtml, String info) throws Exception {
		
	  //   if(!url.contains("10222120150805"))return;
//	if(j>=17)
		
//	try
	//	if(j==17)
		{
//		String url = U.getSectionValue(URL, "<a href=\"", "\"");
		String url1=HOME_URL + url;
//		U.log("Url1: "+url1);	
		
//		if(!url1.contains("https://www.nvhomes.com/new-homes/communities/10222120152016/maryland/new-market/lake-linganore-oakdale-singles")) return;
		

		
//		U.log("Count =="+info);
		U.log("MMMMMMMMMMCount =="+j);
		//U.log("Count =="+count);

		U.log("Page: " + url1 );	
		String html = U.getHTML(HOME_URL + url);
		U.log("pppppppp==> "+url1);
		if (data.communityUrlExists(url1)) {
			LOGGER.AddCommunityUrl("Repeated------------->"+url1);
			duplicates++;
			return;
		}
		LOGGER.AddCommunityUrl(url1);
		
		html = html.replaceAll("IsMasterPlanCommunity","");
		String fullHtml =html;
		
		
		ArrayList<String> plansUrls = Util.matchAll(html, "<li class=\"schedule-home\">\\s*<a href=\"(.*?)#visit", 1);// U.getValues(html, "<li class=\"schedule-home\"><a href='", "#visit");
		//U.log("=== 0 =="+plansUrls[0]);
		String plan = U.getSectionValue(html, "<section id=\"hometype-community\">", "</section>");
		String[] plans = {};
		if(plan != null) {
			plans = U.getValues(plan, "<a href='", "'>");}
		String plansHtml = "",allPlanData=ALLOW_BLANK;
		U.log("Total :: "+plans.length);
		if(plans.length!=0){
		for(String planUrl:plans)
		{
			U.log("Plans :"+HOME_URL+planUrl);  
			//try{
				if(!planUrl.contains("visit"))
				plansHtml=U.getHTML(HOME_URL+planUrl);
				allPlanData += U.getSectionValue(plansHtml, "<h1>", "<div class=\"chat-message\">");
				//U.log("--------------------------"+U.getSectionValue(plansHtml, "<h1>", "<div class=\"chat-message\">"));
			/*}catch(Exception e){
				U.log(e.toString());
			}*/
			
		}
		}
		
		//==================== New Home Plan Html =======================
		int p=0;
		String[] homeUrls=U.getValues(html, "<div class=\"card-body\">","<div class=\"product-title\">");
		U.log(homeUrls.length);
		for (String string : homeUrls) {
			if(p++ == 6)break;
			String hUrl="https://www.nvhomes.com"+U.getSectionValue(string, "<a href=\"","\">");
			U.log("homeUrl : "+ hUrl);
			try{
				allPlanData=allPlanData+U.getSectionValue(U.getHTML(hUrl), "<p id=\"product-about-long-description\">", "</p>")+U.getSectionValue(U.getHTML(hUrl), "<section id=\"homes\"", "</section>");
			}catch(Exception e){}
		}
		
	
		String commUrl = HOME_URL + url;
		String geo = "FALSE";
		

		//*******com name*****
		//	U.log("info------"+info);
			String name = U.getSectionValue(info, "<div class=\"collection-name\">", "</div>");
			if(name==null)name = U.getSectionValue(info, "class=\"search-results-name\">", "</div>");
		//	U.log(info);
			if(name==null)
			name = U.getSectionValue(info, "data-marketing-name=\"", "\">");
			//U.log("comName =="+name+"========");
			if(name == null)
				name = U.getSectionValue(html, "<span class=\"sub-text\">", "</span>");
			
			String Cname = name;
			
			if(name != null)
				name = name.trim();
			U.log("comName =="+name+"========");
			name = name.replace("First-Floor Owner's Suite Collection", "").replaceAll("Estate Homes|Executive Homes| 55&#x2B;", "");
			name = name.replace("55+", "");
			name = name.replace("Homes", "");
			name = name.replaceAll("Carriage| Luxury Singles$|Condominiums$", "");
			if(name.trim().endsWith("Villas") || name.trim().endsWith("- Villas")){
				name = name.replace("Villas", "");
				name = name.trim().replaceAll("[-]", "");
			}
			name=name.trim();
			
			U.log("name::"+name);/*
			if(name.endsWith("Townhomes"))name=name.replace("Townhomes", "");
			if(name.endsWith("Condominiums"))name=name.replace("Condominiums", "");*/
			if(name.trim().startsWith("Active Adult at"))
				name=name.replace("Active Adult at", "");
			name = name.replaceAll("Executive Homes|Twin and Townhomes|^Active Adult ", "");
				name=name.replace("Key and Nash Townhomes and Condos", "Key and Nash");
		
		
		// *********************Address***********************
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		if (!html.contains("Page not Found")) {
			html = html.replaceAll("Location\\W+</h2>", "Location</h2>");
			String addSec = U.getSectionValue(html, "Location</h2>", "Phone Number");
			//String myHtml = html.replaceAll("\\s{3,}", "");
		
			if (addSec != null) {
				//U.log("addSec is Here : " + addSec);

				addSec = addSec.replaceAll("., #", " #");
				addSec = addSec.replaceAll("<br />", ",").trim();
		//		addSec = addSec.replace("(Single Family Model)", "").replace(" MD, MD", " MD").replace("2121 John Stuart Road, Unit A", "2121 John Stuart Road Unit A")
						//.replace(" Blvd, Suite", " Blvd Suite");
			
				//U.log("===="+addSec);
				String addSplit[] = addSec.split(",");
				add[0] = addSplit[0].replace("<p>", "").trim();
				add[1] = addSplit[1].trim();
				addSplit = addSplit[2].split(" ");
				add[2] = addSplit[1];
				add[3] = addSplit[2];
			//	U.log("Street::"+add[0]+" City::"+add[1]+" State:: "+add[2]+" Zip::"+add[3]);
			
			}
			if (addSec == null || add[0] == null) {
				String newAdd = U.getSectionValue(html, "Location", "<a href");
				if(newAdd==null){
					newAdd = ALLOW_BLANK;
				}else if(newAdd.length() > 200){
					add[0] = add[1] = add[2] = add[3] =  ALLOW_BLANK;
				}
				else {
					newAdd = newAdd.replaceAll("<p>|Sussex County <br />|Chatham County <br />|Prince George&#39;s County <br />","").trim();
					newAdd = newAdd.replace(" <br />", ",").trim();
					add = U.getAddress(newAdd);	
					U.log("address is--->"+add);
				}
			}
		}

		add[0] = add[0].replaceAll("\\(.*?\\)|<br />", "");
		add[1] = add[1].replaceAll("<br />", "");

		U.log("Street::"+add[0] + "::::" + add[1] + ":::" + add[2] + ":::" + add[3]);
		
		
		String comHtml = U.getHTML(HOME_URL + url);
		comHtml  = comHtml.replaceAll("IsMasterPlanCommunity", "");
		
		
		//remove nearby sec-----------
		String remNear = U.getSectionValue(comHtml, "<h2>Nearby Neighborhoods</h2>", "</body>");
		if(remNear!=null){
			html = html.replace(remNear, "");
			comHtml =comHtml.replace(remNear, "");
			U.log(":::::::remNear:::::::::::");
		}
		//remove JSONData sec-----------
				remNear = U.getSectionValue(comHtml, "window._JSON_DATA = ", "</script>");
				if(remNear!=null){
					html = html.replace(remNear, "");
					comHtml =comHtml.replace(remNear, "");
					U.log(":::::::remNear:::::::::::");
				}
		remNear = U.getSectionValue(comHtml, "<div class=\"modal-inner\">", "</div>");
		if(remNear!=null) comHtml = comHtml.replace(remNear, "");
		
		// ***********************Lat-long**************************
		String lat = ALLOW_BLANK;
		String lng = ALLOW_BLANK;
		String latUrl = ALLOW_BLANK;
		
		String mainSec = U.getSectionValue(comHtml, "<head>",
				"var communityHtml");
		
	    
		if(mainSec==null){
			mainSec=U.getSectionValue(html, "<head>", "<section id=\"find-model-listing\"");
		}
		if(mainSec!=null)
		mainSec = mainSec.replaceAll("IsMasterPlanCommunity", "");

		String latUrlSec = ALLOW_BLANK;

		latUrl = Util
				.match(comHtml, ">\\s*<a href=\"/directions/(.*?)\"", 1);
		U.log("llllllllll------>"+latUrl);

		if(latUrl==null) {
			latUrl=U.getSectionValue(html, "<input data-disabled type=\"checkbox\" id='", "'");
		}
		if(latUrl!=null && latUrl.length()<10) {
			latUrl=U.getSectionValue(html, "secondaryId=", "'");
		}
		String check = latUrl;
		latUrl = HOME_URL + "/directions/" + latUrl;
		
		
		
		if (check != null) {
			if(!check.contains("10111420130328")){
				U.log("My  URL---" + latUrl);
				String latLngHtml = U.getHTML(latUrl);
				
				String newadd = U.getSectionValue(latLngHtml, "<div id=\"directions-addressinfo\">", "</div>").replace("<br />", ",");
				newadd = U.getNoHtml(newadd);
				
				newadd = newadd.replace("-", "").replaceAll("Call\\s*\\d+", "").replaceAll("\\s*\n\\s*,", "");
				U.log("AAAAAAAAA"+newadd);
				add = U.getAddress(newadd);
				
				if(commUrl.contains("https://www.nvhomes.com/neighborhoods/pa/chester/west-chester/woodlands-greystone")) {
					latLngHtml="{\"Id\":10222120151378,\"DistanceFromCenterPoint\":0.01,\"BuilderCode\":\"N\",\"MarketingName\":\"Greystone Executive Homes\",\"City\":\"West Chester\",\"State\":\"PA\",\"Zip\":\"19380     \",\"County\":\"Chester\",\"UniqueSellingProposition\":\"Luxury single-family homes in a park-like setting with lakes and trails near 202, the 322 bypass, and West Chester Borough\",\"Latitude\":39.987394, -75.595364,";
				}
	
				String latLngLine = Util.match(latLngHtml, "\\d{2,}.\\d+, -\\d{2,}.\\d+");
				if(latLngLine == null) latLngLine = Util.match(latLngHtml, "google.maps.LatLng\\((\\d{2,}.\\d+,  -\\d{2,}.\\d+)\\)", 1);
				U.log("::>"+ latLngLine);
				String latLng[] ={ALLOW_BLANK,ALLOW_BLANK};
				if(latLngLine!=null){
					latLng = latLngLine.split(",");
					U.log(lat = latLng[0].trim());
					U.log(lng = latLng[1].trim());
				}else{
					 latLngLine=U.getSectionValue(latLngHtml,"LatLng(",")");
					 if(latLngLine!=null) {
						String[] ss1=latLngLine.split(",");
						lat=ss1[0].trim();
						lng=ss1[1].trim();
					 }
				}
			}
		}

		else {
			String mylatLng = comHtml.replaceAll("\\s{2,}", "");
			String secLatLng = U.getSectionValue(mylatLng, "Location</h2>",
					"class=\"block\">");
			U.log("My Section: " + secLatLng);

			if (secLatLng != null) {
				String latLngLine = Util.match(secLatLng,
						"\\d{2,}.\\d+,-\\d{2,}.\\d+");
				if (latLngLine != null) {
					String latLng[] = latLngLine.split(",");
				}
			}
		}

		if (add[0].length() < 3)
			add[0] = ALLOW_BLANK;
		//U.log("LatURl ::" + latUrl + "Add[1]" + add[1] + "::::::::::::");
		
		//=============================New Sec
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		
		String directionUrl = U.getSectionValue(comHtml, "var url = '", "';");
		U.log(U.getCache(HOME_URL+directionUrl));
		U.log("directionUrl : "+directionUrl);
		if(directionUrl == null && url.contains("neighborhoods/pa/allegheny/wexford/englishfarms"))
			directionUrl = "/directions/10222120151326"; //taken from its region page
		
		if(directionUrl != null && comHtml.contains("Directions</button>")){
//			String dirHtml = U.getHTML(HOME_URL+directionUrl);
			String dirHtml = U.getPageSource(HOME_URL+directionUrl);
			String latlngSec = U.getSectionValue(dirHtml, "var communityMapCoordinates = {", " }");
			if(latlngSec == null) {
				latlngSec = U.getSectionValue(dirHtml, "https://www.google.com/maps/search/?api=1&query=", ";");
				latlngSec = latlngSec.replaceAll("'|\\+","");
				U.log(latlngSec);
			}
			U.log("latlng Sec: "+latlngSec);
			latLng = latlngSec.replaceAll("lat:|lng:", "").split(",");
		
			
//			dirHtml = dirHtml.replaceAll("ADDRESS\\s*</div>", "ADDRESS</div>");\
			
			
			dirHtml = dirHtml.replaceAll("<div class=\"row no-wrap address-title\">\\s*ADDRESS\\s*</div>", "ADDRESS</div>");
			String addSec = U.getSectionValue(dirHtml, "ADDRESS</div>", "<div class=\"address-button-container GoogleMaps\">");

			U.log("Address Section original: "+addSec);
			if(addSec==null)
				addSec = U.getSectionValue(dirHtml, "ADDRESS</div>", "<div class=\"col-6 model-hours\">");
			if(addSec==null)
				addSec = U.getSectionValue(dirHtml, "ADDRESS</div>", "<hr class=\"directions-hr\"/>");
//			if(addSec==null)
//				addSec = U.getSectionValue(dirHtml, "ADDRESS</div>", "</div>\n" 
//						"                </div>");
			
			if(addSec==null) {
				addSec=U.getSectionValue(dirHtml, "ADDRESS", "<div class=\"ils-box\">");
				addSec=U.getNoHtml(addSec);
			}
			
			//U.log("Address Section original: "+addSec);
			String modelHr=U.getSectionValue(addSec, "<div class=\"col-6 model-hours\">", "<div class=\"row no-wrap directions-hours-text\">");
			if (modelHr!=null) {
				addSec=addSec.replace(modelHr, "").replaceAll("<div class=\"col-md-6\">\\s+Sun\\s+</div>\\s+<div class=\"col-md-6\">\\s+12pm-5pm\\s+</div>", "");
			}
			addSec = addSec.replaceAll("\\s+<div class=\"row no-wrap address-padding\">\\s+|<div class=\"row no-wrap address-padding\">\\s+Frederick County\\s+</div>|<div class=\"row no-wrap address-padding\">\\s+Sussex County\\s+</div>|</div>\\s+</div>", "").replace("</div>", ",").replace("<div class=\"row no-wrap address-padding\">", "").trim();
			addSec = addSec.replaceAll("\n\\s*\n\\s*\n\\s*|\n\\s*\n\\s*,", ",").replaceAll(",Prince William County,|,Loudoun County,|,Loudoun County|,Chester County|,Baltimore County,|,Prince George's County,|,Sussex County,?|,Howard County,|,Fairfax County,|,Montgomery County,|,Anne Arundel County,|,Frederick County,|,Frederick County", "");
			addSec=addSec.replace("12303 Hidden Bay Drive West Ocean City", "12303 Hidden Bay Drive, West Ocean City")
					.replace(",Worcester County", "");
			U.log("Address Section: "+addSec);
			
			add = U.getAddress(addSec);
			U.log("ADDRESS===="+Arrays.toString(add));
//			add = U.getAddress(add[0]);
			U.log("GGGGGGGGGGGG==="+add[3]);
			lat = latLng[0];
			lng = latLng[1];
		}
		U.log(Arrays.toString(latLng));
		U.log(Arrays.toString(add));
		if(latLng[0] == null || latLng[0].length()<4) {
//		String latSec = U.getSectionValue(info, "var communityMapCoordinates = {", " }");
//		latLng = latSec.replaceAll("lat:|lng:", "").split(",");
			
		lat = U.getSectionValue(info, "data-lat=\"", "\"");
		
		lng = U.getSectionValue(info, "data-lng=\"", "\"");
		U.log("LATITUDE: "+lat+" LONGITUDE:- "+lng);
		}
		
		
			
		
		// ******************Community Prices****************************
       
		
		if (mainSec == null)
			mainSec = "";
		mainSec=mainSec.replace("&#x2B;", "").replace("Up to 3,800sq. ft.", "Up to 3,800  sq. ft.").replaceAll("Regional Library, a 25,000 sq. ft. state-of-the|2,500 sq. ft. fitness center|15,000 sq|15,000\\W+ sq|15,000 square feet clubhouse", "").replace("15,000 sq. ft. community center","");
		mainSec = mainSec.replace("<sup>$</sup></span>", "$").replace("Upper <span class=\"price-display-dollar\"><sup>$</sup></span>", "$").replaceAll("0&#39;s|0's|0s", "0,000");
		mainSec = mainSec.replaceAll("\\.(\\d) Million", ",$100,000").replaceAll("loan amount of \\$\\d{3},\\d{3}|Save up to \\$\\d+,\\d+", "");
		mainSec = mainSec.replaceAll("\\$(\\d) Million", "\\$$1,000,000");
		mainSec=mainSec.replace("$1.3 million","$1,300,000 Million").replace("$1 million", "$1,000,000 Million")
				.replace("$1.04 Million", "$1,040,000 Million").replace("$1.5 million", "$1,500,000");
		
		
		
		mainSec = mainSec.replace("1.09 Million", "$1,090,000 Million").replaceAll("Save up to \\$100,000|upcoming 15,000 square feet|6,000 sq. ft. clubhouse|upgrades galore for just \\$999,990", "").replaceAll("0s|0's", "0'000").replaceAll("\\$(\\d)\\.(\\d+) Million", "\\$$1,$20,000 Million").replace("3955", "").replace("2628", "")
				.replace("$100,000! See sales", "");
		mainSec = mainSec.replace("0’s", "0,000");
		
		if(info!=null){
			info = info.replace("0s", "0,000");
			info = info.replaceAll("15,000 sq|15,000\\W+ sq", "");
		}
		// String secprice[]=U.getValues(comHtml,"<div class=\"starting-from-bar-container\">","</div>");
		//U.log("info is ===========>"+mainSec);
//		U.log(Util.matchAll(mainSec + info, "[\\w\\s\\W]{30}\\$395[\\w\\s\\W]{30}", 0));
		String minp=null;
		
		//String minprice=U.getSectionValue(, From, To)
		String regpricesec=U.getSectionValue(regHtml, "<div class=\"search-results-price-display\">", "</div>").replace("<sup>$</sup></span>", "$")
				.replace("500 - ", "500,000").replace("1.14 MILLIONs", "1,140,000");
		
		//comHtml=U.removeSectionValue(comHtml, "searchResultsPages", "search-results-map");
	
		comHtml = comHtml.replace("total loan amount of $372,977. Principal", "").replace("$1 mil +", "$1,000,000")
				.replace("$1mil+", "$1,000,000");
		regpricesec=regpricesec.replace("display-dollar\">$500,000UPPER", "");
		mainSec = mainSec.replace("$1million", "$1,000,000")
				.replaceAll("from&nbsp;\\$(\\d)\\.(\\d) - \\$(\\d)\\.(\\d) million", "from \\$$1,$200,000 - \\$$3,$400,000");
		String price[] = U.getPrices((mainSec + info+regpricesec+comHtml.replace(">$2,219,990</div>", "")).replace("$1,140,000", "") ,"mid \\$\\d+,\\d+ to \\$\\d,1million|\\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|Starting at \\$\\d,\\d+,\\d+|\\$\\d,\\d{3},\\d{3} Million|\\$\\d{3},\\d{3}|Starting at \\$\\d+,\\d+|\\$\\d,\\d+,\\d+ Million|From the \\$\\d,\\d+|<strong>\\W+\\$\\d,\\d+,\\d+|</strong>\\s+\\$\\d+,\\d+,\\d+|Low \\$\\d{3},\\d+|\\$\\d\\,\\d+,\\d+|Starting from \\$\\d,\\d{3},\\d+|\\$\\d{3},\\d+|<strong>\\s+Upper \\$\\d{3},\\d+\\s+</strong>|low \\d{3},\\d+",
						0);
	
	  
		price[0] = (price[0] == null) ? ALLOW_BLANK : price[0];
		price[1] = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		if(commUrl.contains("10222120151965"))price[1]="$1,199,990";
		
		
		U.log("MinPrice="+price[0]+" MaxPrice="+price[1]);
		//U.log("KKKKKKK"+Util.matchAll(comHtml , "[\\w\\s\\W]{50}\\$1[\\w\\s\\W]{50}",0));
		

		// ******************Community Area [SqrFeet]******************
		//U.log("********"+mainSec);
		
		mainSec = mainSec.replaceAll("\\d+,\\d+ sq\\. ft\\. state-of-the|bath can provide more than \\d,\\d+ square", "");
		
		String sqft[] = U
				.getSqareFeet(
						mainSec.replace("<sup>+", "<sup>") + info,
						">\\d,\\d{3} sq\\.ft</div>|\\d,\\d{3}&nbsp;sq\\. ft\\. of elegance|\\d,\\d+ sq.ft|<strong>\\d+<sup></sup></strong> Sq. Ft|\\d,\\d+ to \\d,\\d+ square feet|<strong>\\d{4}<sup></sup></strong> Sq. Ft</dd>|\\d,\\d{3} – \\d,\\d{3} sq. ft|\\d{1},\\d{3}-\\d{1},\\d{3} sq. ft|townhomes of \\d{1},\\d{3} square-feet| \\d{1},\\d{3} luxury square feet|over \\d{1},\\d{3} sq. ft|Up to \\d{1},d{3} square feet|" +
						"\\d{4} square feet|Up to \\d{1},\\d{3} sq. ft|\\d{1},\\d{3} sq. ft|\\d{1},\\d{3}\\+ sq. ft|\\d{1},\\d{3} square feet|\\d{4}\\W+</strong>\\W+Sq. Ft" +
						"|\\d+,\\d+ square feet|\\d+,\\d+sq|\\d+</strong> Sq|Up to \\d+,\\d+ sq|\\d+,\\d+\\+ sq|\\d,\\d+ to over \\d,\\d+ square feet|" +
						"<strong>\\d{4}<sup>\\+</sup></strong> Sq. Ft|<dd>\\s+<strong>\\s+\\d{4}\\s+<sup>|"
						+ "\\d{1},\\d{3} square feet to \\d{1},\\d{3} square feet|\\d{1},\\d{3} sq. feet|\\d{1},\\d{3} sq. ft.|Up to \\d,\\d+  sq. ft.|" +
						"\\d,\\d+-\\d,\\d+ luxury square feet|offering over \\d{1},\\d{3} sq. ft|\\d{4}\\s*<sup/>\\s*</strong>\\s*Sq. Ft|\\d,\\d{3} luxury sq. ft",
						0);
		//U.log(Util.matchAll(mainSec+info, "[\\w\\s\\W]{20}800[\\w\\s\\W]{10}",0));
		sqft[0] = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		sqft[1] = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		//if(commUrl.contains("10222120151903")) {sqft[1]="5667";}
		
		U.log("square feet==" + sqft[0] + ":::" + sqft[1]);

		//========================= Derived Property Type ==================
		html = html.replace("IsFirstFloorOwner", "");
		
		allPlanData = allPlanData.replaceAll("Resort Living for Active Adults|resort-like atmosphere|Resort living 365 days a year|branch|Branch|Colonial, Federal, and European|bedroom for a first-floor owner", ""); //.replace("second floor", " 2 Story ").replace("first-floor", " 1 story ");
		html =html.replaceAll("Resort Living for Active Adults|resort-like atmosphere|Resort living 365 days a year|branch|Branch", "").replace("two or three levels", " 2 Story 3 Story").replaceAll("fourth level with loft|4th-level loft", " 4 story loft").replaceAll("3- and 4-level|Three- or four-level", " 3 story or 4 story").replace("two-level condominiums", "two story condominiums");
		String dType = U.getdCommType((html+allPlanData).replace("1st-floor", "one story"));
		
//		U.log("MMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html+allPlanData, "[\\s\\w\\W]{30}Resort living[\\s\\w\\W]{30}", 0));
		//U.log("allPlanData : "+allPlanData);
		
		// **************Community info*************
		String typeSec = null;

		if (html.contains("Amenities<span>")) {
			typeSec = U
					.getSectionValue(html,
							"<span href=\"\" class=\"icon-white-share\">",
							"</section>");
		}

		//U.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM "+mainSec);
		mainSec = mainSec.replace("golf onsite", "golf and")
				.replace("Resort/Beach Homes", "Resort-Style").replace("resort lifestyle community", "Resort-Style");
		mainSec=mainSec.replaceAll("3 miles of four golf clubs|nearby parks and golf courses|Spa and golf at Turf Valley Resort|golf, dining, and shopping|world-renowned golf courses|resort style pool|Concord Country Club|(areas finest|ark miniature) golf", "");
		String aboutDetails="";
		
		aboutDetails=U.getSectionValue(comHtml, "<p id=\"areaLongDescription\">", "<br /><br />");
		
		String comType = U.getCommType(mainSec+aboutDetails+Cname) ; //+comHtml);
		html=html.replace("Twins- only 4 remain", " Twins  only 4 homes remain");
		String header = U.getSectionValue(html, "<header>", "</header>")+" "+U.getSectionValue(html, "<section id=\"about-overview\">", "<aside>")+" "+U.getSectionValue(html, "<ul class=\"callouts callouts-comm-fix\">", "<");

		header = header
				.replace(
						"NVHomes also offers luxury homes in other sought-after neighborhoods close to this one.",
						"");
		header = header + U.getSectionValue(html, "<aside class=\"key-features\">", "</aside>");
		header = header +U.getSectionValue(fullHtml, "Key Features", "Join Now")+U.getSectionValue(html, "<div class=\"supplementalinfo-cover\">", "<section id=\"supplemental-information\">"); 
		header = header.replace("resort lifestyle community", "Resort-Style");
		header = header.replaceAll("Village Center|Villages of Urbana", "");
		header = header + U.getSectionValue(fullHtml, "<hr class=\"icon-white-home\"/>", "</header>")+U.getSectionValue(html, "About This Neighborhood", "</header>");
		header = header + U.getSectionValue(fullHtml, "<header id=\"nvUrban\">","<div id=\"join-container\">");
		header = header + U.getSectionValue(fullHtml, "<figure id=\"photo-tour-container\"", "<header id=\"nvUrban\">");
		header = header + U.getSectionValue(fullHtml, " <header id=\"header-community\">", "Join our");
		header=header+U.getSectionValue(fullHtml, "<header id=\"header-community\">", "</header>");
		header=header.replace("estate-style kitchen", "estate-style home").replaceAll("Craftsman style trim", "Craftsman style homes");

		if(header!=null)header = header.replace("Elegant NV townhomes", "");
		//U.log("header is : " +header);
		String pstat=U.getSectionValue(comHtml, "custom-message","Proximity");
		String luxuryHmesec=U.getSectionValue(html, "<section id=\"supplemental-information\">", "<div class=\"block\" id=\"joinnow\">");
//		U.log(pstat);
		String propType = ALLOW_BLANK;
		////============================================   property type       ================================
		
		String remLower = U.getSectionValue(html, "<div id=\"communitiesNearby\">", "<script>");
		if(remLower != null) html = html.replace(remLower, "");
		
		html = html.replace("ESTATE-STYLE FLOORPLANS", "Estate style homes");
		
		propType = U.getPropType((html+allPlanData+header+pstat+info+luxuryHmesec).replaceAll("NV Homes condo townhouse development. Nicely built four story townhouses|process of building our Townhouse|I bought our townhouse in Coastal Club|click here to check out Coastal Club Villa Townhomes|Cabin Branch|cabin-branch|craftsman-like details|elevations featuring traditional or craftsman|Greystone Executive Homes|Greystone Estate Homes|raftsmanship|traditional, craftsman, and manor elevations|participation|Cabin Branch", "")
				.replace(" loft ", " loft homes").replace("HOA fee not", "").replace("Tired of all the traditional", "").replace("Elegant NV townhomes near", "").replace("modern townhouse with", "").replace("and-go townhome design", "").replace("Executive Townes", "executive style townhomes").replace("comfort and luxury in an ideal location", "luxury homes"));
		//U.log(info);
		
		propType = propType.replace("Townhome,Townhouse", "Townhome");
		//U.log("hrll"+Util.match(header, ".*?townhomes.*?"));
		U.log("propType:::"+propType);
//		U.log("MMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}estate[\\s\\w\\W]{30}", 0));
		
		String rem = U.getSectionValue(html, "Nearby Neighborhoods",
				"</script>");
		String rem2 = U.getSectionValue(html,
				"<section id=\"about-amenities\">", "</section>");
		if (rem2 != null)
			html = html.replace(rem2, "");
		if (rem != null)
			html = html.replace(rem, "").replaceAll("Town Center - Coming Soon|on-site, coming soon|Prices Coming Soon|coming 2017|dining and more, on-site, coming soon|Clubhouse Coming in 2015|<a href=\"/quick-move-in\">","");

			//html = html.replace(rem, "").replaceAll("Town Center - Coming Soon|on-site, coming soon|Prices Coming Soon|coming 2017|% Sold Out|% SOLD OUT|% sold out|dining and more, on-site, coming soon|Clubhouse Coming in 2015|<a href=\"/quick-move-in\">","");
		html = html.replaceAll(	"shops coming soon|Shops coming soon|href=\"/quick-move-in\">MORE QUICK MOVE-IN HOMES</a>|href=\"/quick-move-in\">",	"");
		html = html.replaceAll("Wine Bar \\(Coming Soon!|class=\"model-label\">Last Chance</div>|for our Grand Opening|Wegmans coming soon|COMMUNITY CLUBHOUSE IS NOW OPEN|celebrate the Grand Opening|options now available|Quick Move In Now Available|QUICK MOVE IN NOW AVAILABLE|Quick Move in Now Available!|Now selling the Carolina Place|Harris Teeter - now open|Course - Now Open|social space - now open|restaurant\\) now open!|\"GrandOpening\",\"Is|informed of grand opening updates|grand opening pricing|Stone Springs Hospital Center - now open|Dulles Landing Shopping Center - now open|Dulles Landing NOW OPEN|Potomac Shores VRE Station - Coming 2017|Quick Move-In Homes|quick move-in home|Shopping Center now open|Fall Fest Now Open|Landing - Now Open|Center now open|New floor plans are now available!", "")
				.replace("New wooded homesites just released", "New homesites just released")
				.replace("Phase 1 is sold", "Phase 1 sold").replace("Phase 2 is now", "Phase 2 now")
				.replace("New 3 car entry garage homesites just released", "New homesites just released")
				.replaceAll(" Station - Coming 2017|House, opening Fall 2021|New homes are arriving Summer 2021 |stunning views Now Available|View Homesites Now Available|homesites now available at|Last chance for holiday |before we are sold out |fast; in fact|with over 300|open for|features now|soon to the|offering our final|soon, enjoy Pleasant|soon, enjoy Pleasant|we have sold|Run. Now|open in Centre|open in Centr", "");
		//U.log(Util.match(html, ".*?now open.*?"));


		//U.log("reglast"+reglast); 
		info = info.replaceAll("our final| open in Centre", "");
	
		String remm = U.getSectionValue(html, "text-bottom\">Schedule a Visit</div>", "<div class=\"pagination-container\">");
		if(remm != null)
			html = html.replace(remm,"");
			
		
		if (commUrl.contains("https://www.nvhomes.com/neighborhoods/va/loudoun/ashburn/the-estates-in-willowsford-grant")||commUrl.contains("https://www.nvhomes.com/neighborhoods/va/loudoun/leesburg/village-walk")) {
			html=html.replaceAll("GrandOpening|Grand", "");
			info=info.replaceAll("GrandOpening|Grand", "");
		}
/*		if (commUrl.contains("https://www.nvhomes.com/neighborhoods/va/prince-william/dumfries/potomacshores-fairwayscrossing")) {
			html=html.replaceAll("Coming 2018|coming 2018", "");
			info=info.replaceAll("Coming 2018|coming 2018", "");
		}
*/		html=html.replace("Phase II is Now Open!", "Phase 2 Now Open");
		html=html.replaceAll("Estate Living is Coming Soon|coming this Summer", "");
		html=html.replaceAll("(on-site - coming soon)|single family homesite is now available!|Prices Coming Soon|On-site VRE station coming soon!|villas coming soon|Onsite shops coming soon|comingsoon-text|Our final single family homesite is now available!", "");
		html=html.replaceAll("one homesite remaining.", "1 homesites remaing.")
				.replace("new phase is now open", "new phase now open")
				.replace("new phase of homes is coming soon", "new phase coming soon");

		
		info=info.replaceAll("Estate Living is Coming Soon|Prices Coming Soon", "");
		html=html.replace("Corner (coming soon)", "").replace("Closeout Party", "").replace("s now available in this community", "").replace("water view homesites, is now available", "water view homesites now available");
		html=html.replaceAll("marina is now open|quick-move-in-homes\">Quick Move-In</a>|Chalfont View is sold out|Closeout savings|sac homesites - now available!|class=\"model-label\">Last Chance</div>|Last chance to own a new NVHome|Prices Coming Soon|Shops Coming Soon|shops Coming Soon|homes are sold out at Bay Forest|School coming 2019|Prices Coming Soon|closeout incentives|clubhouse is now open|facilities now ope|CommunityStatus!='ComingSoon'|class=\"comingsoon-text\"|Silver Line access to the airport and Tyson&#39;s Corner (coming soon)|and grand opening incentives.|Longwood is now available|now selling in Howard|area – coming this|gas is now ", "");
		
		html=html.replace("The final section of this community is now open", "The final section now open").replaceAll("walkout homesites - just released|Just released – new wooded homesites|golf course view homesites just|COMING SOON FROM THE LOW|look at the final homesites now|final phase is underway|overlay\">Grand Opening|data-status=\"Grand Opening|overlay\">Last Chance|data-status=\"Last Chance|Prices Coming Soon|overlay\">Coming Soon|data-status=\"Coming Soon|communityStatus === \"ComingSoon|our villa townhomes coming", "")
				.replaceAll("wooded cul-de-sac lots now available in Bowie’s", "Wooded Lots Now Availble").replaceAll("Phase 2 homesites are now available", "Phase 2 homesites now available")
				.replaceAll("Building Tours Now|QUICK DELIVERY NOW|Homes had some great lots|(acre homesites|flats) are now|now selling( by appointment|&nbsp;from our decorated)|opening of our club|homesite remains! Don't|personalized-title baseFontH6\">\\s+LAST|chance for pre-mode|just a few", "")
				.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">", "$1 ")
				.replace("now selling our final phase", "now selling final phase")
				.replace("final homesites are now released", "final homesites now released");
		
		html = html.replaceAll("(\\d+)\\s+</div>\\s+<div class=\"fomo-block-option1-description\">(.+?)</div>", "$1 $2");
		
		//U.log("::::::::::::::::"+html+info);
//		U.log("ghfh============"+url1html);
		String status=null;
		String homegoing=null;
		
		try {
		if(url1.contains("https://www.nvhomes.com/new-homes/communities/10222120150955/delaware/lewes/marsh-farms")
				||url1.contains("https://www.nvhomes.com/new-homes/communities/10142220131223/delaware/lewes/coastal-club")||
				url1.contains("https://www.nvhomes.com/new-homes/communities/10222120151677/delaware/lewes/coastal-club-towns")||
				url1.contains("https://www.nvhomes.com/new-homes/communities/10222120151429")||
				url1.contains("https://www.nvhomes.com/new-homes/communities/10222120151404/pennsylvania/wayne/wayneglen")||
				url1.contains("https://www.nvhomes.com/new-homes/communities/10222120151308/virginia/herndon/woodland-park-station")) {
		homegoing=U.getSectionValue(html.replaceAll("</div>\n\\s+</div>", "</div></div>"),"<div class=\"homes-going\">","</div></div>").replaceAll("div class=\"fomo-block-option1-remaining\">","</div></div>").replaceAll("5 homesites","5 homesites left").replaceAll("1 homesites","1 homesites left").replaceAll("<div class=\"fomo-block-option1\">"," ").replaceAll("</div>","").replaceAll("3 Highly Desirable Estates Homesites Remaining","3 Homesites Remaining").replaceAll(" 1 homesite", "1 homesite left").replaceAll("1 Homesite","1 homesite left");

		
		
		//		U.log("homegoing:::::::::::::::::::::::::;;"+homegoing);
		
		homegoing = U.getNoHtml(homegoing).replaceAll("\\s+", " ").replaceAll("of\\s+\\d+", "").replaceAll("\\s+", " ");
	//	U.log("homegoing:::::::::::::::::::::::::;;"+homegoing);

		}
		}
		catch(NullPointerException ne) {
			
		}
		
		String statushome=null;
		String statussec=U.getSectionValue(comHtml,"<div class=\"personalized-title baseFontH6\">","</div>");
		if(statussec!=null)
		 statushome=U.getSectionValue(html,"<div class=\"personalized-description bodyCopyFont\">","</div>").replaceAll("The final phase of homesites has just been released","Final Phase Just Released");
		String phsec=U.getSectionValue(comHtml,"<div class=\"newHomesIn-proposition\""," </div>");
		html=html.replace("Phase&nbsp;3&nbsp;is coming soon", "Phase 3 coming soon")
				.replace("3 new wooded cul-de-sac homesites just released", "3 wooded cul-de-sac homesites just released")
				.replace("&amp;", "&").replace("Phase&nbsp;3&nbsp;is coming soon", "Phase 3 coming soon")
				.replaceAll("PHASE (\\d+) IS COMING FALL 2021", "PHASE $1 COMING FALL 2021")
				.replaceAll("\n\\s*</div>\n\\s*<div class=\"fomo-block-option1-description\">", "")
				.replace("Homesite Special Remains", "Homesite Remains")
				.replaceAll("\"Quick Move In\"|Brand New YMCA is Now Open|New homes are&nbsp;now selling!&nbsp|Shops and Dining Coming Soon|SHOPS AND DINING COMING SOON", "")
				.replace("s in An Elevator Building Are Coming Soon", "Building Are");
		
		html=html.replaceAll("\n\\s*</div>\n\\s*<div class=\"fomo-block-option1-description\">", "")
				.replaceAll("Quick Move-In Townhomes Available|Home Remains for October Move-In|immaculate homesites|Immaculate homesites|stunning homesites with private|gorgeous homesites?", "");
				
		//special section
			/*
			 * String number = U.getSectionValue(html,
			 * "<div class=\"fomo-block-option1-remaining\">", "</div>"); String line =
			 * U.getSectionValue(html, "<div class=\"fomo-block-option1-description\">",
			 * "</div>"); String numberLine = (number+line).trim(); U.log(" "+numberLine);
	 		 */
		html=html.replace("4\\s*</div>\n\\s*<div class=\"fomo-block-option1-description\">Wooded Homesites Remain</div>", "4 Wooded Homesites Remain");
		
		html=html.replace("1\n\\s*</div>\n\\s*<div class=\"fomo-block-option1-description\">Wooded Homesite Remains In Our Current Release</div>", "1 Wooded Homesite Remains");
	 html=html.replace("2\n\\s*</div>\n\\s*<div class=\"fomo-block-option1-description\">Walk-Out Wooded Homesites Just Released</div>","2 Walk-Out Wooded Homesites Just Released");
		html=html.replaceAll("Our final phase is selling fast", "final phase selling fast").replaceAll(" wooded surrounds", "");
		
		status = U.getPropStatus((html.replaceAll("PHASE 3 IS NOW SELLING|PHASE 3 IS NOW SELLING", "PHASE 3 NOW SELLING")+info+statushome+homegoing+statussec+phsec).replaceAll("PHASE 3 IS NOW SELLING|PHASE 3 IS NOW SELLING", "PHASE 3 NOW SELLING").replace(" newest phase is now open", "newest phase now open")
				.replaceAll("choose from the new homesites now available|now available</a>|Access Coming|Immediate move-ins are available", "")
				.replace("wonderful, but limited opportunity", "")
				.replace("Wooded &amp; pond view backyards &amp; base, area. Wooded &amp; pond view backyards", "Wooded & pond view backyards & basements available")
				.replace(" selling quickly", "Selling Quickly").replace("1 luxury homesite remaining", "1 homesite remaining")
				.replaceAll("Urbana - coming this Spring|unity-features-box\">Coming Spring 2021 from the|Now selling Phase 2|Creek will be opening soon|91 homesites remaining at Wayne Glen|Estate Living is Coming Soon|Urbana are now|Access is Now|alt='VIP Access is Now|6 of the communitie&rsquo;s 32 home sites remain|designs are now available|quick move in now available|community is now open|clubhouse is now open|amenity center is now open|view homesites, is now available|arina homesites are now available|Move in Now Available|LIMITED-TIME OFFER!|Limited-Time Offer|Ellicott City now selling|before this community is sold out|homes are sold out at Bay Forest|now selling in Howard|Our clubhouse is now open|Prices Coming Soon|chance to overlook |celebrate the grand opening|CommunityStatus\":\"GrandOpening|School coming 2019|<span class=\"price\"> Prices Coming Soon</span>|Quick Move in Now Available|on-site - coming soon|Now Available!</h3>|href=\"/quick-move-in\">Quick Move-In Homes|our close-out savings|town center - coming soo|quick|under construction|chipotle coming soon|grand opening special|know about our grand opening|casino coming soon|social space - coming early 2016|Move-in Ready|Phase 1 sold out",	"")
				.replaceAll("dates are now available|\"Quick Move In\"|Immediate move|station - coming soon|coming soon&nbsp;Wawa|coming soon Wawa|station \\(coming|Move-in ready for Summer|opening in the fall of 2019|Immediate Move-In|NV is coming soon|Finished Basements Available|family homes are now|suite homes are now selling|garage homesite now available|receive grand opening updates|QUICK MOVE IN NOW AVAILABLE!|included on our final|Greens is sold out|models now|Wegmans - Now|Tours Now|residences are now|flats are now","")
				.replace("Wooded Homesites Available, ", "").replace("Prices Coming Soon", "").replace("data-status=\"Coming Soon\"", "")
				.replace("s in An Elevator Building Are Coming Soon", "Building Are").replace("overlay\">Coming Soon</span>", "")
				.replaceAll("Don't miss out on your final opportunity to purchase! Only 3 townhomes remain|immaculate homesites|Immaculate homesites|stunning homesites with private|now open!</p>|gorgeous homesites?", "").replaceAll("Quick move-ins and to-be-built|for Quick Move-In</div>", ""));

//	U.log("MMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(info+statushome+homegoing+statussec+phsec, "[\\s\\w\\W]{50}final[\\s\\w\\W]{50}", 0));
//	U.log("MMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));
//	U.log("MMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{30}Final Phase[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMMMMMMMMMMMM11111111 "+Util.matchAll(info+statushome+homegoing+statussec+phsec, "[\\s\\w\\W]{30}Quick Move[\\s\\w\\W]{30}", 0));
			
		
		if(commUrl.contains("10222120151405"))status="Selling Fast, Quick Move-in";
	//if(commUrl.contains("10222120150756"))status="Now Selling";
	status=status.replace("New Wooded & Pond Homesites Available, Wooded Homesites Available", " ");
			
		U.log("status:::::::::::::::::"+status);
		
	
		
		
		status=status.replace("Phase Iii Now Open", "Phase III Now Open");
		if(commUrl.contains("/md/frederick/urbana/55-villas-boxwood-urbana")||commUrl.contains("/neighborhoods/de/sussex/west-fenwick-island/overlook"))
			status=U.getPropStatus(html);
		U.log("status:::::::::::::::::"+status);
		
		
		
		
		
		if(commUrl.contains("https://www.nvhomes.com/neighborhoods/va/fairfax/herndon/waterview-at-woodland-park") || commUrl.contains("https://www.nvhomes.com/neighborhoods/de/sussex/ocean-view/seagrove"))
			status=U.getPropStatus((info+html).replaceAll("Corner (coming soon)| Prices Coming Soon|\"CommunityStatus\":\"ComingSoon\"|class=\"comingsoon-text\"|wooded\\s*(backyards|backdrops|trails|lots|lands)", "").replaceAll("New Premier Homesites Coming Soon", "Homesites Coming Soon"));
		//U.log(status);
		if(status.contains("Only 1 Home Remain, Only A Few Homes Left"))status=status.replaceAll("Only 1 Home Remain, Only A Few Homes Left", " Only A Few Homes Left");
		
		status = status.replace("Only 1 Homesite Remaining, Only 1 Homesite Remaining", "Only 1 Homesite Remaining").replace("Homesites Coming Soon", "5 Homesites Coming Soon");
		//if(url.contains("bethany-beach-area/the-estuary"))status = status + ", New Phase Coming Soon";
		//U.log("Status**************==" + html);
//		if(commUrl.contains("/neighborhoods/md/howard/clarksville/gaithers-chance"))
//			status=status+ ",Now selling";
		
		commUrl = HOME_URL + url;

		if ((add[0] == null || add[0] == ALLOW_BLANK)
				&& (add[3] == null || add[3] == ALLOW_BLANK)
				&& (lat == null || lat.trim().length()<5)) {
			
			
			String adSec = U.getSectionValue(html, "Location</h2>", "<a href");
			if (adSec != null) {
				add[3] = Util.match(adSec, "\\w{2}\\s\\d{5}");
				add[2] = Util.match(add[3], "\\w{2}");
				add[3] = Util.match(add[3], "\\d{5}");
				add[0] = U.getSectionValue(adSec, "p>", "<");
				add[1] = U.getSectionValue(adSec, "br/>", ",");
			}
			String Lsec = U.getSectionValue(header, "/directions/", "\"");
			U.log("hhhhh"+Lsec);
			if(add[0]==null && info.contains("<div class=\"model-location\""))
			{
				add[1] = U.getSectionValue(info, "<span itemprop=\"addressLocality\">", "<");
				add[2] = U.getSectionValue(info, "<span itemprop=\"addressRegion\">", "</span>");
				add[3] = U.getSectionValue(info, "<span class=\"hidden-xs\">,", ",");

			}
			if(Lsec==null)
			{
				String lasec = U.getSectionValue(html, "communityMapCoordinates", "}");
				U.log("lasec :"+lasec);
				if(lasec != null){
					if(!lasec.contains("1,  -1")) {
					lng = Util.match(lasec, "-\\d+.\\d+");
					lasec = lasec.replace(lng, "");
					lat = Util.match(lasec, "\\d+.\\d+");
					geo = "FALSE";
					}
				}else{

					if(add[0]== ALLOW_BLANK && add[1] == ALLOW_BLANK){
						if(url.contains("howard/sykesville/walker-meadows")){
							add[1]="Sykesville";
							add[2]="MD";
							add[3] = "21784";
						}
						if(url.contains("arlington/arlington/arlington-row")){
							add[1]="Arlington";
							add[2]="VA";
							add[3] = "22205";
						}else if(url.contains("baltimore/baltimore/greenleigh")){
							add[1]="Baltimore";
							add[2]="MD";
							add[3] = "21162";
						}
					}
					U.log("Add : "+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					
					String[] latlong={ALLOW_BLANK,ALLOW_BLANK};
					latlong=U.getGoogleLatLngWithKey(add);
					lat =latlong[0];
					lng =latlong[1];
					geo = "FALSE";
				}
			}
			if (Lsec != null) {
				
				String Lhtml = U.getHtml("https://www.nvhomes.com/directions/" + Lsec, driver);
				String Lhtml1=Lhtml;
				Lhtml = U.getSectionValue(Lhtml,
						"latitude and longitude coordinates", "<");
				
				lng = Util.match(Lhtml, "-\\d+.\\d+");
				Lhtml = Lhtml.replace(lng, "");
				lat = Util.match(Lhtml, "\\d+.\\d+");
				geo = "FALSE";
				
			} else {
				if (lat == ALLOW_BLANK && add[0].length()>4) {
					String[] latt = U.getGoogleLatLngWithKey(add);
					lat = latt[0];
					lng = latt[1];
					geo = "TRUE";
				}
			}

		}
		String Lsec = U.getSectionValue(html, "<a href=\"https://www.google.com/map", "class");
		//U.log("sec is : "+Lsec);
		if (Lsec != null) {
			
		
			lng = Util.match(Lsec, "DULLES-\\d+.\\d+");
			Lsec = Lsec.replace(lng, "");
			lat = Util.match(Lsec, "\\d+.\\d+");
			geo = "FALSE";
			
		}
		
		//U.log("-=-=-=-=-:"+lat);
		if(lat.length()<5)
		{
			U.log("here");
			String lasec = U.getSectionValue(html, "position:  new google.maps.LatLng(", ")");
			if(lasec!=null && !lasec.contains("1,  -1"))
			{
			lng = Util.match(lasec, "-\\d+.\\d+");
			lasec = lasec.replace(lng, "");
			lat = Util.match(lasec, "\\d+.\\d+");
			geo = "FALSE";
			}
			else
			{
				lat = U.getSectionValue(fullHtml, "Latitude\":", ",");
				U.log(lat);
				lng = U.getSectionValue(fullHtml, "Longitude\":", ",");
				geo = "FALSE";
			}
		}
		
		if (add[0].contains("Content/Assets/svg/locations.svg")) {
			add[0] = ALLOW_BLANK;
		}


	status  = status.replace("Close-out!", "Close Out");
	status=status.replace("Grand Townhomes", "");
	if(status.contains("Spring Move-ins Available") && status.contains("Quick Move-in"))
		status=status.replace("Spring Move-ins Available,", "");
		
		// For Address

		if (add[0] == ALLOW_BLANK && lat != ALLOW_BLANK && lat != null) {

			add = U.getGoogleAddressWithKey(new String[] { lat, lng });
			if(add[0].isEmpty())
				add = U.getAddressGoogleApi(new String[] { lat, lng });
			
			geo = "TRUE";
		}

		if (lat == null) {
			lat = ALLOW_BLANK;
			lng = ALLOW_BLANK;
		}

		//new latlng section from get directions
		String latlngSection =ALLOW_BLANK;
		
		if(comHtml.contains("\">Get Directions</a></dd>")&&add[0]!=ALLOW_BLANK&&comHtml.contains("https://www.google.com/maps?daddr")){
			U.log("Hello");
			comHtml=comHtml.replace("<a href = \"https://www.google.com/maps?daddr", "<dd><a href=\"https://www.google.com/maps?daddr");
			latlngSection=U.getSectionValue(comHtml, "<dd><a href=\"https://www.google.com/maps?daddr", "target=\"");
			lat=U.getSectionValue(latlngSection, "=", ",-");
			lng=U.getSectionValue(latlngSection, ",", "\"");
			U.log(lat+"   "+lng);
			geo="False";
		}						
		
		add[0] = add[0].replace("&amp;", "&");
		
		
		U.log("***********************************************************************************************"
				+ geo);
		
		add[0]=add[0].replaceAll("\\.|,", "");
		add[1]=add[1].replace("Spotsylvania Courthouse", "Spotsylvania");	
		String note = ALLOW_BLANK;
 		name=name.replace("THE OVERLOOK -","The Overlook").replace("Key&amp;Nash", "Key & Nash");
/*		if(commUrl.contains("https://www.nvhomes.com/neighborhoods/va/loudoun/dulles/towns-at-arcola-town-center")) {
			add[0]=ALLOW_BLANK;
			add[1]="Dulles";
			add[2]="Virginia";
			add[3]=ALLOW_BLANK;
			String[] latLng = U.getlatlongGoogleApi(add);
			if(latLng == null)
				latLng = U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latLng);
			if(add == null)
				add = U.getAddressHereApi(latLng);
			note ="Address Taken From City State";
		}*/
		if(note.length()<2) {
			note =U.getnote(html);
		}
		status = status.replace("Quick Move-in, Quick Move In Now Available", "Quick Move-in");
		if(url1.contains("ellicott-city/bethany-ridge") || url1.contains("odenton/two-rivers")) status = status.replace(", Now Selling", "");
		if(url.contains("10222120150510"))name = "Willowsford Estates At The Greens Village";
		if(url.contains("10222120151364"))name = "Willowsford At The Grove Village";
		if(url.contains("10222120150692"))name = "Willowsford At The Grant Village"; 	
		if(url.contains("9449720020131"))name = "The Regency At Two Rivers"; 	
		if(url.contains("ocean-view/bay-forest-at-bethany"))status = status.replace("Final Phase", "Final Section Now Open") ;
		
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151612/virginia/arlington/arlington-heights")) {
			//U.log("Address: "+addec);
			//2320 N. Underwood Street,Arlington, VA 22205,Arlington County,
			add[0] = "2320 N. Underwood Street";
			add[1] = "Arlington";
			add[2] = "VA";
			add[3] = "22205";
		}
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120150805/maryland/ellicott-city/westmount")) {
			add[0] = "3700 Three Graces Road";
			add[1] = "Ellicott City";
			add[2] = "MD";
			add[3] = "21042";
		}
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120150946/maryland/ellicott-city/fairways-at-turf-valley")) {
			add[0] = "2710 Vardon Lane";
			add[1] = "Ellicott City";
			add[2] = "MD";
			add[3] = "21042";
		}
		
/*		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120150756/maryland/maple-lawn/maple-lawn-south")) {
			add[0] = "11545 Scaggsville Road";
			add[1] = "Maple Lawn";
			add[2] = "MD";
			add[3] = "20759";
		}*/
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151794/maryland/ellicott-city/turf-valley-singles")) {
			add[0] = "10348 Puccini Lane";
			add[1] = "Ellicott City";
			add[2] = "MD";
			add[3] = "21042";
		}
		if(url1.contains("https://www.nvhomes.com/new-homes/communities/10222120151985/pennsylvania/media/ponds-edge")) {
			add[0] = "237 Ponds Edge Dr";
			add[1] = "Media";
			add[2] = "PA";
			add[3] = "19063";
		}
		System.out.println(Arrays.toString(add));
		
		
		
		
//		if(url.contains("urbana/villages-of-urbana-stonebarn"))status = "Coming Soon";
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151404/pennsylvania/wayne/wayneglen")) {
			price[0]="$900,000";
			price[1]="$959,990";
			sqft[1]=ALLOW_BLANK;
		}
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151429")) {
			price[0]=ALLOW_BLANK;
			price[1]=ALLOW_BLANK;
		}


		if(propType.contains("Townhouse") && propType.contains("Townhomes")){
			propType = propType.replace("Townhouse", "").replace(", ,", ",").trim().replaceAll(",$|^,", "").trim();
		}
		//synchronized (data) {
		
		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120150805/maryland/ellicott-city/westmount"))
			if(status.endsWith("Phase 3 Coming"))
			status=status.replace("Phase 3 Coming","Phase 3 Coming Soon");
		
		
		if(add[2]==null) {
			String statezip[]=add[1].split(" ");
			String streetaddress[]=add[0].split(" ");
		
			add[0]=add[0].replace(streetaddress[streetaddress.length-1], "");
			
			
			U.log("---"+statezip.length+"=="+Arrays.toString(statezip));
			add[2]=statezip[0];
			add[3]=statezip[1];
			add[1]=streetaddress[streetaddress.length-1];
			U.log("====="+Arrays.toString(add));
			
			
		}
		
		status=status.replace("Quick Move-in","Quick Move-ins");
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(info, "[\\s\\w\\W]{30}new homesites[\\s\\w\\W]{30}", 0));
//		
//		status = status.replace("Homes Are Selling Fast, Selling Fast", "Homes Are Selling Fast");
//		if(url.contains("10222120151377"))comType="55+ Community, Gated Community, Active Adult";
//        if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151429"))comType="Golf Course";
//		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151404/pennsylvania/wayne/wayneglen"))sqft[0]="4821";
//		if(commUrl.contains("https://www.nvhomes.com/new-homes/communities/10222120151465/pennsylvania/exton/malverncrossing"))sqft[1]="3476";
//		if(url.contains("10222120151667"))status="Now Selling";
//		if(commUrl.contains("10222120150805"))status="Phase 3 Now Selling";
//		if(url1.contains("https://www.nvhomes.com/new-homes/communities/10222120150831/delaware/bethany-beach-area/the-estuary")) 
//			status = "3 New Wooded Cul-de-sac Homesites Just Released, Newest Phase Now Open, Homesites Available"; 
//		if(url1.contains("https://www.nvhomes.com/new-homes/communities/10222120151405/virginia/tysons/bexley-condos-tysons-corner"))
//			status = "Now Selling";
//		if(status.contains("9 Quick Move-in Homes")) status = status.replace("9 Quick Move-in Homes", "Quick Move-in Homes");
//		if(url1.contains("https://www.nvhomes.com/new-homes/communities/10222120152066/virginia/herndon/flats-at-woodland-park-station"))
//			status = status.replace("Sold Out", "50% Sold Out");
//		if(url1.contains("https://www.nvhomes.com/new-homes/communities/10222120150756/maryland/maple-lawn/maple-lawn-south"))
//			status = status.replace("Homesites Available,", "");
//			
		
			count++;
			U.log("count********************" + count);
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			data.addCommunity(name, commUrl, comType);
			data.addAddress((add[0]), add[1], add[2], add[3].trim());
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPrice(price[0], price[1]);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(status);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
	//		j++;
		//}
	}//catch(Exception e) {}
	j++;
		
	}
}