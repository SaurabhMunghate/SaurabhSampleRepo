/**
 * @author Sawan
 * @date 16 Feb 2021
 */
package com.shatam.b_001_020;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.http.client.params.AllClientPNames;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.AddSelection;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class TriPointeHomes extends AbstractScrapper {
	String state;
	int count = 0;
	static int i=0;
	static int j = 0;
//	WebDriver driver;
	CommunityLogger LOGGER ; 
	static String builderUrl = "https://www.tripointehomes.com";
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new TriPointeHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Tri Pointe Homes.csv", a.data().printAll());
//		U.log("repeated::"+i);
	}
	

	public TriPointeHomes() throws Exception {
		super("Tri Pointe Homes","https://www.tripointehomes.com/");
		LOGGER = new CommunityLogger("Tri Pointe Homes");
	}

	int communityCount = 0;
	public void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		//Json State url
		String html = U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/state_community");
//		U.log(html);

		String stateSection = U.getSectionValue(html, "{\"state\":", "},\"submarket");
		if(stateSection != null){
			String stateIds[] = U.getValues(stateSection, "{\"id", "}");
//			U.log("Total states :"+stateIds.length);
			
			for(String stateId : stateIds){
				int pageNo = 1;
				String id = U.getSectionValue(stateId, "\":", ",");
//				if(id != "11")continue;
				String stateName = U.getSectionValue(stateId, "name\":\"", "\"");
				//if(!stateName.contains("arizona"))continue;
				String stateUrl = "https://www.tripointehomes.com/find-your-home?filter_state="+id;
//				U.log("stateUrl :"+stateUrl);
//				
//				
//				U.log("Id :"+id+ " state :"+stateName);
//				U.log("stateJsonUrl :: https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/"+id+"?&paged="+pageNo);
				String stateJsonHtml = U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/"+id+"?&paged="+pageNo);
				String maxPageSection = U.getSectionValue(stateJsonHtml, "\"maxPages\":", ",");
//				U.log(maxPageSection);
				int maxPage = Integer.parseInt(maxPageSection);
				
				//extract for 1st page
				extractCommunity(stateJsonHtml);////
				
				//Extract other paging page
				if(maxPage > 1){
					for(int i = pageNo+1; i <= maxPage; i++){
//						U.log("maxPage :"+i);						
//						U.log("stateJsonUrl :: https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/"+id+"?&paged="+i);
						//stateJsonHtml += U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/"+id+"?&paged="+i);
						String stateJsonHtml1 = U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/"+id+"?&paged="+i);
//						U.log(U.getCache("https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/"+id+"?&paged="+i));
						//extract for remaining pages
						extractCommunity(stateJsonHtml1);////
					}
				}
				
/*				String jsonOutputSection[] = U.getValues(stateJsonHtml, "\"cmd\":{", "\"maxPages\":");
				if(jsonOutputSection.length != maxPage){
					U.log("Not Same");
				}
				U.log(jsonOutputSection.length);
				for(String section : jsonOutputSection){
					U.log(section);
					//break;
				}
				*/
				//break;
//				driver.quit();
				LOGGER.AddRegion(stateName+" :: "+stateUrl, communityCount);

				communityCount = 0;
			}//EOF for
		}
		
		LOGGER.DisposeLogger();
	}
	
	private void extractCommunity(String html) throws Exception{
		JsonParser parser = new JsonParser();
//		String html = U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/find_your_home/208?&paged=1"); //for eg.
		
		Object obj = parser.parse(html);
		JsonObject json = (JsonObject)obj;
		//U.log(((JsonObject) json.get("data")).get("cmd"));
		String dataString="{\"dummy\":"+ ((JsonObject) json.get("data")).get("cmd")+"}";
		//Contains JsonObject
//		U.log("dataString ::"+dataString);
		if(json.toString().contains("\"cmd\"")){
			JsonObject  communitiesJson = (JsonObject)parser.parse(dataString);//(JsonObject) ((JsonObject) json.get("data")).get("cmd");
//			U.log("this is json::::::"+(JsonObject) communitiesJson.get("dummy"));
			JsonArray rows = communitiesJson.getAsJsonArray("dummy");
			for (int i = 0; i < rows.size(); i++) {
				JsonObject  communityJson = (JsonObject) rows.get(i);
				//U.log("this is json::::::"+communityJson);
				if(communityJson == null)continue;
				//U.log("--->"+communityJson);
				
				//Contains Sub-communities
				if(communityJson.get("type").getAsString().equals("community")){
	//				U.log("Contains sub comm.");
					
					String subRegUrl = U.getSectionValue(communityJson.toString(), "\"permalink\":\"", "\"");
		//			U.log(subRegUrl);
					
					//Get JsonArrays containing sub-communities
					JsonArray subCommunityJson = communityJson.get("neighborhoods").getAsJsonArray();
					//U.log(communityJson.get("neighborhoods"));

//					U.log("Total Subcomm :"+subCommunityJson.size());
					
					LOGGER.AddSubRegion(subRegUrl, subCommunityJson.size());
					for(JsonElement comJson : subCommunityJson){
						communityCount++;
						//U.log("<><>"+comJson);
						addDetails(comJson.toString());
					}
				
				}//Contains main communities
				else if(communityJson.get("type").getAsString().equals("neighborhood")){
					communityCount++;
					//U.log("This is community");
					addDetails(communityJson.toString());
				}
				
			}

		}
		//Contains JsonArrays
		else if(json.toString().contains("\"cmd\":[{")){
			//U.log("Got Json Array");
			JsonArray  communitiesJson = (JsonArray) ((JsonObject) json.get("data")).get("cmd");
			
			for(JsonElement comJson : communitiesJson){
				communityCount++;
//				U.log("<><>"+comJson);
				//addDetails(comJson.toString());
			}
		}//EOF Else IF
		
	}//EOF extractCommunity()
	
	private String priceRegex [] ={	
			"price_value\":\"Priced at \\$\\d{1},\\d{3},\\d{3}",
			"from the \\$(\\d,)?\\d{3},\\d{3}",
			"(from|in) the (high|low|mid) \\$?(\\d,)?\\d{3},\\d{3}",
			"from the low \\$\\d{3},\\d{3}",
			"price_value\":\"Priced from \\$(\\d,)?\\d{3},\\d{3}",
			"to (high|low|mid) \\$?(\\d,)?\\d{3},\\d{3}", "start in the \\$\\d{3},\\d{3}","to \\$\\d{3},\\d{3}",
			"Priced at \\$\\d+,\\d+",
			"Priced from the mid \\$\\d{3},\\d{3}",
			"from the mid \\$\\d{3},\\d{3} - \\$\\d{3},d{3}",
			"- \\$\\d{3},d{3}",
			"Priced from the \\d{3},\\d{3}",
			"Priced from \\$\\d{3},\\d{3}",
			"from \\$\\d{3},\\d{3}",
			"\\$\\d,\\d{3},\\d{3}",
			"mid \\$\\d{3},\\d{3}",
			"mid \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}"
			
	};
	
	private String sqftRegex [] ={
			"\\d{1},\\d{3} to \\d{1},\\d{3} square feet",
			"(min|max)_sq_feet\":\"\\d{4}\"",
			"square_feet\":\"\\d,\\d{3} - \\d,\\d{3}\"",
			"\"square_feet\":\"\\d,\\d{3}\"",
			"range from \\d,\\d{3} to \\d,\\d{3} sq. ft.",
			
	};
	
	public void addDetails(String comSec) throws Exception{
//		try{
//		if(j>=0 && j<=50)
	//if(j>=50 && j<=100)
//		if(j>=100 && j<=200)
		//if(j>=150 && j<=200)
//		if(j>=200)
//		U.log(o);
	{
		String comUrl = U.getSectionValue(comSec, "\"permalink\":\"", "\"");
		
		//TODO: Run for single community
		if(!comUrl.contains("https://www.tripointehomes.com/tx/austin/park-collection-at-bar-w-ranch/"))return;

//		U.log(comSec);
		//		{
//	String html2=U.getHtml(comUrl,driver);
		
		U.log("Count ::"+j);

//		U.log("COMSEC===="+comSec);
		U.log("comUrl ::"+comUrl);
		
		if(comUrl.contains("https://www.tripointehomes.com/az/phoenix-metro/arroyo-seco/")){
			LOGGER.AddCommunityUrl(comUrl+"::::::::Redirected:::::::::"); //18 Feb 21
			return;
		}
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"::::::::Repeated:::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

		//========== Community Name =============
		String comName = U.getSectionValue(comSec, "\"title\":\"", "\"");
		if(comName != null) comName = comName.replace(" Craftsman Bungalows", "").replace("|", "").replace("Branch Manor Townhomes", "Branch").replaceAll("55\\+", "").replace("Paired Homes", "");
		U.log("comName :"+comName);
		String jsonCommunityName = U.getSectionValue(comSec, "\"name\":\"", "\"");
//		U.log("jsonCommunityName====="+jsonCommunityName);
		
		String html = U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/global_component/"+jsonCommunityName);
		U.log("comJsonUrl :"+"https://www.tripointehomes.com/wp-json/tpgsite/v1/global_component/"+jsonCommunityName);
		
		
		String neighbourhoodHtml = U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/neighborhood_info/"+jsonCommunityName);
//		U.log("neighbourhoodUrl :: "+"https://www.tripointehomes.com/wp-json/tpgsite/v1/neighborhood_info/"+jsonCommunityName);
		if(neighbourhoodHtml.contains("\"success\":false,")) {
			neighbourhoodHtml  =U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/community_info/"+jsonCommunityName);
			U.log("neighbourhoodUrl :"+"https://www.tripointehomes.com/wp-json/tpgsite/v1/community_info/"+jsonCommunityName);
		}else {
		U.log("neighbourhoodUrl :"+"https://www.tripointehomes.com/wp-json/tpgsite/v1/neighborhood_info/"+jsonCommunityName);
		}
		String marketingHeadLine = U.getSectionValue(html+neighbourhoodHtml,"\"neighborhood_marketing_headline\":\"","!\"");
//		U.log("=============DP1 "+Util.matchAll(neighbourhoodHtml, "[\\w\\W\\s]{50}5 plex[\\w\\s\\W]{50}", 0));

		if(neighbourhoodHtml!=null) {
			neighbourhoodHtml=neighbourhoodHtml.replace("Models ,", "");
		}
		String communityID=U.getSectionValue(html, "CommunityID=", "&Listings");
	U.log("communityID-1="+communityID);
	if(communityID==null) {
		communityID=U.getSectionValue(neighbourhoodHtml, "CommunityID=", "&Listings");
		U.log("communityID-2="+communityID);
	}
	
		//============= Lat - Long =================
		String geo = "FALSE";
		String latLong[] = {ALLOW_BLANK, ALLOW_BLANK};
//		latLong[0] = U.getSectionValue(comSec, "\"latitude\":\"", "\"");
//		latLong[1] = U.getSectionValue(comSec, "\"longitude\":\"", "\"");
		String latlngSec=U.getSectionValue(neighbourhoodHtml, "\"map_directions_link\":\"", "\",");
		
		if(latlngSec!=null)
		{
		latLong[0]=Util.match(latlngSec,"\\@\\d{2,3}[.]\\d{6}");
		
		if(latLong[0]!=null) {
			latLong[0]=latLong[0].replace("@", "");			
		}
		
		latLong[1]=Util.match(latlngSec,"-\\d{2,3}[.]\\d{6}");
		}
		
		if(latLong[0]==null || latLong[1]==null || latLong[0].contains("30.10835")) {
			latLong[0] = U.getSectionValue(comSec, "\"latitude\":\"", "\"");
			latLong[1] = U.getSectionValue(comSec, "\"longitude\":\"", "\"");
		}
		
		String noteSec=ALLOW_BLANK;
		U.log("Lat-Long :"+Arrays.toString(latLong));
		
		//================= Address  ===================
		String add[] = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		//neighbourhoodHtml=neighbourhoodHtml.replace("", newChar)
		add[0] = U.getSectionValue(neighbourhoodHtml, "\"streetAddress\":\"", "\"");
		if(add[0]!=null && add[0]!=ALLOW_BLANK) {
			add[0]=add[0].replace("Models", "1372 Horizon Circle");
		}
		add[3] = U.getSectionValue(neighbourhoodHtml, "\"postalCode\":\"", "\"");			
		add[1] = U.getSectionValue(comSec, "\"city\":\"", "\"");
		add[2] = U.getSectionValue(comSec, "\"state\":\"", "\"");
		
		if(neighbourhoodHtml.contains("\"hide_address\":true")) {
			geo="True";
		}
		
		if(add[0]!=null) {
			add[0]=add[0].replaceAll("Insert address here", ALLOW_BLANK).replace("612 Lake Cove Dr, Little Elm, TX 75068", "612 Lake Cove Dr");
			
			//geo="TRUE";
		}
		if(comUrl.contains("https://www.tripointehomes.com/dc/washington-dc/brookland-grove/")) {
			add[1]="Washington";
		}
		
		if(comUrl.contains("https://www.tripointehomes.com/ca/sacramento/everly-at-natomas-meadows/")) {
			add[0]="1655 Aleppo Lane";
		}
		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/villas-at-the-reserve/")) {
			add[0]="3302 Dover Valley Dr";
			geo="TRUE";
				
		}
		if(add[0].contains("00 Address Coming Soon")) {
			add=U.getAddressGoogleApi(latLong);
		}
		if(add[0].equals("3825 Bainbridge Cove") && add[1].equals("Round Rock"))
		{
			add[0] = ALLOW_BLANK;
			add[1] = ALLOW_BLANK;
		}
		U.log("Add ::"+Arrays.toString(add));
		
		if(add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK && latLong[0] != ALLOW_BLANK){
			add=U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getGoogleAddressWithKey(latLong);
			geo = "TRUE";
		}
		//U.log(add[0]);
		if(add[0] != null) {
			add[0] = add[0].replace("East side of Lindsay Rd., South of Ocotillo Rd.", "E Lindsay Rd & S Ocotillo Rd")
				.replace(",", "");
		add[0] = add[0].replaceAll("Insert Address Here|\\[|\\],", "")
				.replaceAll("insert address here|Insert Address|New Model Coming Soon!|Aleppo Lane Sacramento CA", "");
		
		}
		
		if(add[0] ==null || (add[0].length() < 5 && add[3] != ALLOW_BLANK)){
			String add1[] = U.getAddressGoogleApi(latLong);
			if(add1 == null) add1 = U.getGoogleAddressWithKey(latLong);
			add[0] = add1[0];
			geo = "TRUE";

		}
		if(add[3] ==null || (add[3].length() < 3 && add[3] != ALLOW_BLANK)){
			String add1[] = U.getAddressGoogleApi(latLong);
			if(add1 == null) add1 = U.getGoogleAddressWithKey(latLong);
			add[3] = add1[3];
			geo = "TRUE";

		}
		if(comUrl.contains("/ca/san-diego-county/citro/")){
			add[1] = "Fallbrooke";
			add[2]="CA";
		    latLong = U.getlatlongGoogleApi(add);
		    add= U.getAddressGoogleApi(latLong);
			geo = "TRUE";
			noteSec="Address is taken from city and state";
		}
//		if(comUrl.contains("https://www.tripointehomes.com/az/phoenix-metro/estates-at-the-meadows/")){
//			add[1] = "Peoria";
//			add[2]="AZ";
//		    latLong = U.getlatlongGoogleApi(add);
//		    add= U.getAddressGoogleApi(latLong);
//			geo = "TRUE";
//			noteSec="Address is taken from city and state";
//		}
		
//		if(comUrl.contains("https://www.tripointehomes.com/va/loudoun-county/west-park-at-brambleton/")) geo = "TRUE"; //Map is not present on page
//		if(comUrl.contains("https://www.tripointehomes.com/tx/dallas-fort-worth/lakes-of-river-trails/")) geo = "TRUE";
		
		//U.log(" ==="+geo);
		
		//=============== Price ====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comSec = comSec.replaceAll("0s|0's", "0,000")
				.replaceAll(" \\$(\\d)\\.(\\d) Millions", " \\$$1,$200,000")
				.replaceAll(" \\$(\\d) Millions", " \\$$1,000,000").replace("$2 Millions", "$2,000,000").replaceAll(" $200s", " $200,000");
		html = html.replaceAll("Ks|K's", ",000").replaceAll("0s", "0,000");
		neighbourhoodHtml = neighbourhoodHtml.replace("$2 millions", "$2,000,000").replace("$1 millions", "$1,000,000").replaceAll("Ks|K's", ",000").replaceAll("0s", "0,000");
		String planSec= U.getSectionValue(neighbourhoodHtml, "\"data\":{\"residence\"", "],\"neighborhood_details\":");
		
		String priceStr="";
		if(planSec!=null) {
		String priceSec[] = U.getValues(planSec, "\"show_photo_gallery\"", "}");
		for(String sec:priceSec) {
			if(!sec.contains("Sold Out")) {
				priceStr +=sec;
			}
		}
		}
		priceStr = priceStr+ U.getSectionValue(neighbourhoodHtml, "\"neighborhood_details\":", "\"virtual_tour\":");
		if(priceStr!=null) {
			priceStr=priceStr.replace("from the 200s", "from the $200,000").replace("0Ks", "0,000").replace("0s","0,000");
		}
		comSec=comSec.replace("$1.15 Millions","$1,150,000");
//		U.log("Match======"+Util.matchAll((neighbourhoodHtml+comSec + html + priceStr),"[\\w\\W\\s]{100}\\$656,274[\\w\\W\\s]{100}",0));
		//String[] price = U.getPrices(comSec + html + priceStr+neighbourhoodHtml, String.join("|", priceRegex), 0);
		String[] price = U.getPrices((neighbourhoodHtml+comSec + html + priceStr).replace("price_value\":\"Priced at $656,274\"", "").replace("Priced from $1,010,810", ""), String.join("|", priceRegex), 0);
		if(comUrl.contains("https://www.tripointehomes.com/va/loudoun-county/birchwood-carriages-at-brambleton/"))
		{
			price[0]=ALLOW_BLANK;
			price[1]=ALLOW_BLANK;
		}
		if(comUrl.contains("https://www.tripointehomes.com/tx/austin/park-collection-at-turners-crossing/")) {
			price[1]="$600,000";
		}
		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/woodforest-50/")) price[0]="$300,000";
		if(comUrl.contains("https://www.tripointehomes.com/tx/austin/terrace-collection-at-bar-w-ranch/"))price[1]="$500,000";
//		if(comUrl.contains("https://www.tripointehomes.com/tx/austin/park-collection-at-bar-w-ranch/"))price[1]="$600,000";

		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice :" + maxPrice);
    
//		U.log("Match======"+Util.matchAll((neighbourhoodHtml+comSec + html + priceStr),"[\\w\\W\\s]{100}\\$600,000[\\w\\W\\s]{100}",0));

		
        
        //============= SQFT ========================
		
		
        String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
        String[] sqft = U.getSqareFeet(comSec + html + neighbourhoodHtml, String.join("|", sqftRegex), 0);
		minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
		maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		
		
		//=============== Community Type =================

		
		if(neighbourhoodHtml != null){
			String remove = U.getSectionValue(neighbourhoodHtml, "{\"reviews\"", "}}");
			if(remove != null) neighbourhoodHtml = neighbourhoodHtml.replace(remove, "");
			
			String removeSection [] = U.getValues(neighbourhoodHtml, "{\"image\":{", "}");
			for(String rem : removeSection) neighbourhoodHtml = neighbourhoodHtml.replace(rem, "");
			
			neighbourhoodHtml = neighbourhoodHtml.replaceAll("image_(title|caption)\":\"(Farmhouse|Craftsman) Style Exterior", "");
		}
		
	//	U.log("=============com "+Util.matchAll(comSec + html + neighbourhoodHtml, "[\\w\\W\\s]{30}master-planned[\\w\\s\\W]{30}", 0));
		
		String comType = U.getCommunityType((comSec + html + neighbourhoodHtml).replace("water front homesites", "Waterfront Homes").replaceAll("in Gig Harbor. In this master-planned community|Snoqualmie Ski Resort features|Snoqualmie Pass Ski Resort|nearby ski resort|McCormick Woods Golf Course|Gated Entry|Resort Style Pool at Creeks of Legac|alt\":\"Resort Style|creeks-of-legacy-resort-pool|Creeks-Of-Legacy-Resort-Pool", ""));
		
//		U.writeMyText(neighbourhoodHtml);
		//========== Property Type =================
		

		String imageDetails=ALLOW_BLANK;
		html = html.replace("Instead of a traditional HOA", "Instead of a HOA");
		String ImgSec1=U.getSectionValue(neighbourhoodHtml, "\"gallery_images\":[", "],");
//		U.log("ImgSec1:"+ImgSec1);
		if(ImgSec1!=null) {
		String[] myImageSec=U.getValues(ImgSec1, "\"image\": {", "\"image_type\":");
		U.log("ll"+myImageSec.length);
		if(myImageSec!=null)
		{		
		for(String imageJs:myImageSec) {
			if(imageJs.contains("\"status\": \"inherit\",")) continue;
			else
				imageDetails+=imageJs;
		}
		}
		}
	//	U.log("IMage Sec"+ImgSec1);
		//String removeImgSec2=U.getSectionValue(neighbourhoodHtml, "\"image_caption\": \"", "\",");
//		U.log("NNNN"+neighbourhoodHtml);
		
		String imageName=ALLOW_BLANK;
		
		String[] imagesTitle=U.getValues(neighbourhoodHtml, "\"image_title\":\"", "}");
	//	U.log("hELLO"+ImgSec1);
				
		  for(String img_tit:imagesTitle) {
			
			if(img_tit.contains("elevation")||img_tit.contains("Elevation")) {
				neighbourhoodHtml=neighbourhoodHtml.replace(img_tit, "");
			//	U.log("iimmm gg"+img_tit);
			}
			
				
		}
/*		  String[] images=U.getValues(neighbourhoodHtml, "\"image_caption\":\"", "\"");
	//	  U.log("good"+ImgSec1);
			
		  for(String img_cap:imagesTitle) {
		//	U.log("iimmm gg"+img_cap);
			if(img_cap.contains("elevation")||img_cap.contains("Elevation")) {
		//		U.log("iimmm gg"+img_cap);
				neighbourhoodHtml=neighbourhoodHtml.replace(img_cap, "");
			}
		}*/
		  
//		if(removeImgSec2!=null)
//		neighbourhoodHtml=neighbourhoodHtml.replace(removeImgSec2, "");
		  
		//  U.log("NNNN"+neighbourhoodHtml+"/n============");
		  neighbourhoodHtml=neighbourhoodHtml.replaceAll("farmhouse kitchen|\"Farmhouse - B Elevation\"|farmhouse-kitchen|Farmhouse Kitchen|Calla-at-Valencia-\\d-Plex-|Calla at Valencia \\d-Plex", "");
		  comSec=comSec.replaceAll("Calla-at-Valencia-\\d-Plex-|Calla at Valencia \\d-Plex", "");
		  html=html.replaceAll("farmhouse kitchen|\"Farmhouse - B Elevation\"|farmhouse-kitchen|Farmhouse Kitchen|Calla-at-Valencia-\\d-Plex-|Calla at Valencia \\d-Plex|calla-at-valencia-\\d-plex", "");

	//	U.log("=============PPPP "+Util.matchAll(neighbourhoodHtml, "[\\w\\W\\s]{100}plex[\\w\\s\\W]{100}", 0));
		String propType = U.getPropType((comSec + html +neighbourhoodHtml)
				.replace("guests or multi-generational living","")
				.replace("\"image_title\":\"Flex Room\",\"image_caption\":\"Savannah Floor", "").replace("<li>Flex Room<\\/li>\\n<\\/ul>\\n\",\"price_value\":\"Priced from", "")
				.replace("Traditional Spanish and Modern Architecture", "Traditional Homes")// dt may 2022 
				.replace("Schools, HOA + Tax, BDX Amenities", "Schools, by HOA+ Tax, BDX Amenities")
				.replaceAll("-chatham-park-th_th-4-plex|Chatham-Park-TH_TH-4-Plex-Lots|Tri Pointe NC Pennant Square TH HT 5 Plex CS|Valencia 4-Plex|4-Plex-Modern|Calla-at-Valencia-5-Plex-|Calla at Valencia 5-Plex\"|Calla-at-Valencia-4-Plex-Coastal-|Calla at Valencia 4-Plex\"|5-Plex_CS-|5-plex_cs-|5-plex_cs-01|4-plex_cs-1231|5-Plex_CS-01|4-Plex_CS-1231|-farmhouse-kitchen|Farmhouse kitchen|-farmhouse-kitchen|farmhouse-kitchen|In Farmhouse Kitchen|intimate community features 17 single-family residences|ecognize the exploding popularity of modern farmhouse architecture|Craftsman homes have an alluring charm that|Schools, HOA|Find yourself grabbing breakfast at the famous Cottage at Blue Ridge Bakery|Thai and Caribbean to Asian and Mediterranean|It brings a touch of modern to this more traditional home|mix of traditional and modern finishes|EVERY single-family home from Tri Pointe Homes|modern-farmhouse painted brick|charming painted brick exterior, giving that prefect modern farmhouse|Elevation B is a two story full brick traditional home design|Elevation B is a single story full brick traditional home design|The covered patio off the casual dining area|Covered Patio\",\"image|area next to a covered patio where you can grill|2-car garage and a functional loft with a powder|2-car garage. With a loft upstairs|Caprock | 2nd Floor, Loft\",\"image_type\":\"interior\"|Elevation F is a two story cottage|Elevation E is a two story cottage inspired home design with bri|Elevation F is a single story cottage inspired home design with bri|Schools,  \\+ Tax|Cabin'? Branch|Web Cabin|Cabin (Picnic|Playground|Pool)", ""));
		propType=propType.replace("Claasic Row Homes", "Row Homes");
		U.log("propType :: "+propType);
//		U.log("propType===="+propType);
//		U.log("=============DP "+Util.matchAll(comSec + html +neighbourhoodHtml, "[\\w\\W\\s]{50}Flex Room[\\w\\s\\W]{50}", 0));
//
//		U.log("=============DP "+Util.matchAll(html, "[\\w\\W\\s]{50}4-Plex[\\w\\s\\W]{50}", 0));
//		U.log("=============DP "+Util.matchAll(neighbourhoodHtml, "[\\w\\W\\s]{50}4-Plex[\\w\\s\\W]{50}", 0));

		
						//============= Derived Type ============================
		
//	U.log("=============DP "+Util.matchAll(neighbourhoodHtml, "[\\w\\W\\s]{50}5 plex[\\w\\s\\W]{50}", 0));
		
		neighbourhoodHtml = neighbourhoodHtml.replaceAll("\"stories\":\"(\\d)\"", " $1 Story ");
		//String dType = U.getdCommType((comSec + html + neighbourhoodHtml).replaceAll("Cross Creek Ranch|Casen Ranch Lane|model home in Chisholm Trail Ranch|model home in chisholm trail ranch|at-sterling-ranch|trail-ranch", ""));
		                      
		                                //+html dt 16 may 22 
		String dType = U.getdCommType((comSec  + neighbourhoodHtml).replaceAll("Ranch Elementary|-ranch/|folsom-ranch|Ranch Elementary|yranch|ranch life|\\+ranch!|\\+Ranch\\+|audiemurphyranch|Ranch House|Murphy Ranch|AudieMurphyRanch|-ranch-|Rancho Viejo|amberly-at-sterling-ranch|trail-ranch|chisholm-trail-ranch", "").replaceAll("chisholm-trail-ranch|Waterson North HT 40 7 Ranch A CS 03 HR|Waterson-North_HT-40-7-Ranch-A_CS-03_HR|Waterson North HT 3505 Ranch A CS 02 HR|waterson-north_ht-3505-ranch-a_-cs-03|Waterson-North_HT-3505-Ranch-A_CS-02_HR", "").replaceAll("waterson-north_ht-3003-ranch-a_-cs-03|Waterson North HT 3003 Ranch A CS|Arizona-Waterson-North_HT-3003-Ranch-A", "").replaceAll("Cross Creek Ranch|Casen Ranch Lane|model home in Chisholm Trail Ranch|model home in chisholm trail ranch|at-sterling-ranch|trail-ranch", ""));
		 if(comUrl.contains("https://www.tripointehomes.com/va/fairfax-county/bren-pointe/")){
			dType=dType.replace("1 Story, 2 Story, 3 Story", "3 Story, 4 Story") ;
		 }
		
		
		
						//==========Property Status ==============
		
		String sliderSection = U.getSectionValue(neighbourhoodHtml, "slider_heading", ",\"");
		//U.log(marketingHeadLine);
		html = html.replace("New phase opening in spring 2021", "New phase opening spring 2021")
			.replaceAll("released at grand opening|great final chance to call|final phase only has", "");
//		
//		U.log("<><><><><><<>>>>>>"+marketingHeadLine);
//		
//		marketingHeadLine="START "+marketingHeadLine;
//		
//		U.log("<><><><><><<>>>>>>"+marketingHeadLine);
		

		
		if(marketingHeadLine != null)
			marketingHeadLine = marketingHeadLine.replace("<strong>Coming Summer 2022<\\/strong><\\/p>\\n<p", "")
			.replace("limited opportunities for exploration", "")
			.replace("\"promo_snipe\":\"Final Homes Now Selling\",\"promo_description\":\"", "");
		
		html=html.replace("limited opportunities for exploration", "REPLACE");
		
		
		html = html.replaceAll("<strong>Coming Summer 2022<\\/strong>", "").replace("[_info\":\"\",\"long_description\":\"Coming soon to Fontana, CA, carriage and]", "")
				.replace("<strong>Coming Summer 2022<\\/strong><\\/p>\\n<p", "");
		
		comSec = comSec.replaceAll("Only one move-in|ready homes positioned", "");
	
//		String propStatus = U.getPropStatus((comSec + html+sliderSection+marketingHeadLine).replace("Limited homesites are remaining in the final sections", "Limited homesites remaining in final sections").replace("last one", "").replace("Virtual Tours Now Available", "")
//				.replaceAll("headline_part_2\":\"Coming Soon\"|We are currently sold out of homes at Adonea,|sub_text\":\"Final Opportunity|Sedella offers the final opportunity|grand opening of our community|Gallery- Coming Fall|[h|H]ours [c|C]oming|description\":\"<p><strong>Coming Summer 2022<\\/strong><\\/p>\\n<p>Splash|:\"Final opportunity to own the Plan|now open 25-acre|is now open for residents|promo_snipe\":\"New Homesites Coming Soon|frame_heading\":\"New Homesites Coming Soon\",|\"headline\":\"More Homesites Coming Soon\"|\"image_caption\":\"New Homes Coming Soon to Edmonds|Communities are coming in 2021 to <a|\":\"Coming Soon 3-Step Homebuying Process|New townhomes coming soon|New Townhomes Coming Soon to Lynnwood|\"promo_snipe\":\"New Homesites Now Available\"|:\"Only 18 homesites available from Tri Pointe Homes|\"promo_snipe\":\"Final Opportunities Now Selling\"|through the final phase of the home build|\"promo_snipe\":\"Limited Opportunities\"|<p>Coming soon to Natomas Meadows|[M|m]ove-[I|i]n|[M|m]ove [I|i]n", ""));
//		
		//neighbourhoodHtml
		
		//U.log("PROPMATCH"+Util.match(marketingHeadLine,"Final Birchwood Homesites Now Selling"));
		if(marketingHeadLine!=null) {
		  marketingHeadLine=marketingHeadLine.replaceAll("Sitemap CloseOut|-Sitemap_CloseOut|sitemap_closeout","");
		 marketingHeadLine=marketingHeadLine.replace("Final Birchwood Homesites Now Selling","Final Homesites Now Selling");
		U.log(marketingHeadLine.contains("closeout"));
		}
		if(sliderSection!=null)
		  sliderSection=sliderSection.replace("Sitemap CloseOut|-Sitemap_CloseOut|sitemap_closeout", "");
		html=html.replaceAll("Sitemap CloseOut|-Sitemap_CloseOut|sitemap_closeout","");
      //  U.log("SSSS"+Util.matchAll(marketingHeadLine,"[\\w\\W\\s]{50}Only 3 Opportunities Remain[\\w\\W\\s]{50}",0));
		
		
		
		String rem[]=U.getValues(priceStr, "\"post_status\":", "\",");
		if(rem.length>0) {
			for(String remove : rem) {
				priceStr=priceStr.replace(remove, "");
			}
		}
		html=html.replaceAll(">Coming Soon<\\/p>", "");
		
		String proStatSecfrmJJson=U.getSectionValue(neighbourhoodHtml, "\"community_status\":\"","\"" );
		U.log("MM Sec::-"+proStatSecfrmJJson);
		//U.log("nEIGHB"+neighbourhoodHtml);
		
//			U.log("============= "+Util.matchAll(marketingHeadLine, "[\\w\\W\\s]{100}opening summer 2022[\\w\\s\\W]{100}", 0));
//			U.log("============= "+Util.matchAll(priceStr, "[\\w\\W\\s]{100}opening summer 2022[\\w\\s\\W]{100}", 0));
//			U.log("============= "+Util.matchAll(proStatSecfrmJJson, "[\\w\\W\\s]{100}opening summer 2022[\\w\\s\\W]{100}", 0));
//		U.log("============= "+Util.matchAll(html+sliderSection+marketingHeadLine+priceStr+proStatSecfrmJJson, "[\\w\\W\\s]{100}Last home now selling[\\w\\s\\W]{100}", 0));		
//		U.log("PROPMATCH"+Util.matchAll(html+sliderSection+marketingHeadLine+priceStr+proStatSecfrmJJson,"[\\w\\W\\s]{50}Final Opportunities[\\w\\W\\s]{50}",0));
//		U.log("match1::"+Util.matchAll(proStatSecfrmJJson, "[\\w\\W\\s]{100}Coming Soon[\\w\\s\\W]{100}", 0));

		String propStatus = U.getPropStatus((html+sliderSection+marketingHeadLine+priceStr+proStatSecfrmJJson)
				.replace("Gordon-Reed Elementary &#8211; NEW! (opening Fall 2022)", "").replace("Arrowhead Model Now Selling\",\"community_", "")
				.replace("Limited Homesite Release in September 2021", "Limited Homesite Release September 2021")
				.replace("New Townhomes Coming Soon to Bethesda", "")
				.replace("\"master_community_snipe\":false,\"neighborhood_marketing_headline\":\"New Homes Just Released", "")
				.replace("<p>With only two opportunities available for this plan, this limited availability", "")
				.replace("s_heading\":\"<p>Future New Home Gallery Coming Early 2023", "").replace("\"qmi_status\":\"Coming Soon\"", "")
				.replace("<p>Carol Ann North Elementary (onsite and opening August 2022!)", "")
				.replaceAll("nullMove-in Ready Homes Available|Final Move-in Ready Homes Now Selling", "Move-in Ready")
				.replace("nullAlmost Sold Out of the Groves", "Almost Sold Out of the Groves").replace("Limited homesites are remaining in the final sections", "Limited homesites remaining in final sections").replace("last one", "").replace("Virtual Tours Now Available", "")
				.replaceAll("\"promo_sub_text\":\"Final opportunities\"|New Tri Pointe Communities are now selling in|Home Gallery Opening Summer 2022|New Home Gallery is Now Open", "").replaceAll("Under-Construction Homes Now Selling|\"iframe_subtext\":\"now selling\"|New Homes Coming Soon to Lincoln|Gallery Grand Opening|Model Grand Opening|Model and New Home Gallery Opening Summer 2022|New Home Gallery Now Open|last chances to get in on the action|last opportunities to purchase a new Tri Pointe home|New Homes Now Selling in Roseville|Modern, spacious new homes now selling|Priority Group for Overland is now open|Model Info Coming Soon|\"headline\":\"Texas Heritage Parkway\",\"headline_part_1_color\":\"#\\d{6}\",\"headline_part_2\":\"Now Open", "")
				.replaceAll("Coming Soon Variation - Homebuying Process Block|Priority Group is now open|Priority Group Now Open|load garage has limited availability |Model Homes Coming Soon|description\":\"<p style=\\\"text-align: left;\\\">Coming Soon<\\/p>|Construction Homes Coming Soon to Priority Group|\"iframe_subtext\": \"coming soon\"|PID: coming soon|primary suite offers a truly grand finale|Grand Opening of the Model|Coming Summer 2022\"|Texas Heritage Parkway\",\"headline_part_1_color\":\"#969696\",\"headline_part_2\":\"Now Open!|New Home Gallery Coming Soon|Not to mention the grand opening of the new Texas Heritage Par|post_status\":\"Temporarily Sold Out|Last home until sold out!|we will be completely closed out of The Groves|Delia Plan 1 Coming Soon|Birch Bend Plan 5 Coming Soon|Birch Bend Plan 4 Coming Soon|Birch Bend Plan 3 Coming Soon|Birch Bend Plan 2 Coming Soon|Birch Bend Plan 1 Coming Soon|before we are sold out|Lake City! Now selling the final homes|\"headline_part_2\":\"Now Selling!\"|headline_part_2\":\"Coming Soon\"|We are currently sold out of homes at Adonea,|sub_text\":\"Final Opportunity|Sedella offers the final opportunity|grand opening of our community|Gallery- Coming Fall|[h|H]ours [c|C]oming|description\":\"<p><strong>Coming Summer 2022<\\/strong><\\/p>\\n<p>Splash|:\"Final opportunity to own the Plan|now open 25-acre|is now open for residents|promo_snipe\":\"New Homesites Coming Soon|frame_heading\":\"New Homesites Coming Soon\",|\"headline\":\"More Homesites Coming Soon\"|\"image_caption\":\"New Homes Coming Soon to Edmonds|Communities are coming in 2021 to <a|\":\"Coming Soon 3-Step Homebuying Process|New townhomes coming soon|New Townhomes Coming Soon to Lynnwood|\"promo_snipe\":\"New Homesites Now Available\"|:\"Only 18 homesites available from Tri Pointe Homes|\"promo_snipe\":\"Final Opportunities Now Selling\"|through the final phase of the home build|\"promo_snipe\":\"Limited Opportunities\"|<p>Coming soon to Natomas Meadows|[M|m]ove-[I|i]n|[M|m]ove [I|i]n", ""));
U.log("match2::"+Util.matchAll(priceStr, "[\\w\\W\\s]{100}coming soon[\\w\\s\\W]{100}", 0));
//	U.log("price :: "+priceStr);
//html+sliderSection+marketingHeadLine+priceStr
//		if(propStatus.contains("Now Selling, Final Homes"))
//		{
//			propStatus=propStatus.replace("Now Selling, Final Homes", "Final Homes Now Selling");
//		}
		if(comUrl.contains("https://www.tripointehomes.com/az/phoenix-metro/cadence/")) propStatus+=", Now Selling";
		if(comUrl.contains("https://www.tripointehomes.com/tx/austin/terrace-collection-at-turners-crossing/"))propStatus="Now Selling";
		if(comUrl.contains("https://www.tripointehomes.com/ca/orange-county/claret-at-canvas/"))
		{
			propStatus=propStatus.replace("Currently Sold Out", "Sold Out");
		}
		//if(comUrl.contains("https://www.tripointehomes.com/nc/charlotte/mclean-overlake/")) propStatus="Only 2 Opportunities Remain, Grand Closeout, Final Homes Now Selling"; 
//		if(comUrl.contains("https://www.tripointehomes.com/tx/austin/park-collection-at-bar-w-ranch/"))	propStatus="Limited Availability";	
		
		if(comUrl.contains("https://www.tripointehomes.com/ca/bay-area/glisten-at-one-lake/"))propStatus+=", Coming Soon";
		if(comUrl.contains("https://www.tripointehomes.com/ca/riverside-county/avid/"))propStatus="Sold Out";
		if(comUrl.contains("https://www.tripointehomes.com/wa/greater-seattle-area/cypress/"))propStatus="Now Selling";
		propStatus=propStatus.replace("Limited Homesite Release in November 2021", "Limited Homesite Release November 2021");
		if(comUrl.contains("https://www.tripointehomes.com/ca/riverside-county/avid/")) propStatus="Sold Out";
		if(comUrl.contains("https://www.tripointehomes.com/nv/las-vegas/arden/"))propStatus=propStatus.replace(", Now Selling","");
		if(comUrl.contains("https://www.tripointehomes.com/ca/riverside-county/overland"))propStatus="Final Homes Now Selling";
       
		
		U.log("propStatus: "+propStatus);
		
		propStatus=propStatus.replaceAll("Move-In Ready|Move-In Ready, |, Move-In Ready", "");
		
		//=======qmi=============
		int quickCount=0;
		String qckmvSec=U.getSectionValue(neighbourhoodHtml, "qmi\":[", "\"neighborhood_details\":");
		if(qckmvSec!=null) {
			String [] quickHomes=U.getValues(qckmvSec, "{\"post_id\":", "state");
			for(String quick:quickHomes) {
				String postStat=U.getSectionValue(quick, "\"post_status\":\"", "\"");
				if(postStat!=null) {
				if(postStat.contains("Move-In June 2022")||postStat.contains("Now Selling")|| postStat.contains("Model Home Now Selling") || postStat.contains("Move-In Ready Only")||postStat.contains("Ready to Move-In") || postStat.contains("Final Homes Now Selling")|| postStat.contains("MODEL HOME NOW SELLING")) {
					U.log("hello");
					quickCount++;
				}
				}
			}
			
		}
		U.log("quickCount="+quickCount);
		
		
		//U.log(">>>>>>>>>"+Util.matchAll(html  , "[\\w\\s\\W]{30}Coming Summer[\\w\\s\\W]{50}", 0));
		
//		if(neighbourhoodHtml.contains("\"post_status\":\"Ready to Move-In\"") && !propStatus.contains("Move-In")){
//			if(propStatus == ALLOW_BLANK) propStatus = "Ready To Move-In";
//			else if(propStatus != ALLOW_BLANK) propStatus += ", Ready To Move-In";
//		}
		
		if(quickCount>0){
			if(propStatus == ALLOW_BLANK) propStatus = "Move-In Ready";
			else if(propStatus != ALLOW_BLANK) propStatus += ", Move-In Ready";
		}
		
	//	if(comUrl.contains("poulsbo-meadows")) propStatus=propStatus+", Move-In Ready";
		
		
		
		String notes = ALLOW_BLANK;//;U.getnote((comSec + html+neighbourhoodHtml+ noteSec).replace("org-4000420\\/presales", "").replace("\\/", "/").replaceAll("/org-\\d+/presales", "") );
		U.log("notes :: "+notes);
		if(propStatus!=null) {
			propStatus = propStatus.replace("New Phase Opening Spring 2021, New Phase Open", "New Phase Opening Spring 2021");
			
			if(propStatus.contains("Final Opportunities Now Selling") && propStatus.contains("Final Opportunities,"))
				propStatus = propStatus.replace("Final Opportunities,", "");
		}
		
		if(propStatus.contains(", New Phase Open") && propStatus.contains("New Phase Opening Spring 2021"))	{
			propStatus =propStatus.replace(", New Phase Open", "");
		}
		
		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/traditions-at-hidden-arbor/"))	propStatus = propStatus.replace("Now Selling, ", "")+", Final Homes Now Selling";
		
		
//		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/haven-at-seven-lakes-40/"))
//			propStatus+=", Now Selling";//Img
			
		if(!latLong[1].contains("-"))latLong[1]="-"+latLong[1];
		if(comUrl.contains("/austin/highlands-at-mayfield-ranch-50/"))propStatus=propStatus.replace(", Move-In Ready", "");
		
		if(comUrl.contains("https://www.tripointehomes.com/tx/austin/rancho-sienna-50/"))propStatus=propStatus.replace("Sold Out", "Currently Sold Out");
		
		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/villas-at-the-groves-50/"))propStatus = propStatus.replace("Ready To Move-In", "Move in Ready");
        if(comUrl.contains("https://www.tripointehomes.com/ca/riverside-county/cassis-at-rancho-soleo/"))propStatus=" Final Homes Now Selling";
		propStatus=propStatus.replace("Final Homes Now Selling, Final Phase, Now Selling", "Final Homes Now Selling, Final Phase").replace("Now Selling, Only 1 Opportunity Remains, Last Opportunity, Only 1 Opportunity Remain, Grand Closeout, 1 Opportunity Remains", "Now Selling, Only 1 Opportunity Remains, Last Opportunity, Grand Closeout");
		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/harvest-green-75/"))propStatus=propStatus.replace("Only 3 Homes Remaining, Move-In Ready", "Only 3 Move-In Ready Homes Remaining");
//		if(comUrl.contains("https://www.tripointehomes.com/az/phoenix-metro/loma-at-avance/"))minPrice = "$500,000";
		if(comUrl.contains("https://www.tripointehomes.com/tx/houston/villas-at-the-reserve/"))propStatus=propStatus.replace("Two Homes Remain, ","");
		if(propStatus.contains("Ready To Move-In"))propStatus=propStatus.replace("Ready To Move-In", "Move-In Ready");
		if(comUrl.contains("https://www.tripointehomes.com/ca/riverside-county/cassis-at-rancho-soleo/")) {
			maxPrice=ALLOW_BLANK;
		}
		if(comUrl.contains("https://www.tripointehomes.com/va/loudoun-county/birchwood-carriages-at-brambleton/"))propType+=", Carriage Home";
		if(comUrl.contains("https://www.tripointehomes.com/az/phoenix-metro/ranger-at-avance/"))propStatus = "Final Homes Now Selling, Move-In Ready";
		if(comUrl.contains("https://www.tripointehomes.com/ca/sacramento/timbercove-at-sierra-pine/")) {price[0]=ALLOW_BLANK; dType="2 Story, Colonial";}
        if(comUrl.contains("https://www.tripointehomes.com/tx/austin/terrace-collection-at-turners-crossing/"))propStatus="Limited Availability";
		//if(comUrl.contains("https://www.tripointehomes.com/az/phoenix-metro/estates-at-the-meadows/"))propStatus="Sold Out";
      

        
        //		================================ No of Unites =========================================
		
		String html1=U.getPageSource("https://salesarchitect.exsquared.com/api/GeoJsonAPI/GetGeoJsonData?bdxCommunityID="+communityID+"&communityNumber=");
			String[] lotData=U.getValues(html1, "{\"id\":", "CTAs\":[]");
			String lotCount=ALLOW_BLANK;
			String site_mapHtml="";
//			U.log("lotCount>>>>>>>>>"+lotData.length);
			if(lotData.length==0) {
				String c=U.getSectionValue(html1.replace("<d2p1:LotCount>", "LotCount="), "LotCount=", "<");
				lotCount=c;
			}
			else {
			 lotCount=Integer.toString(lotData.length);
			}
			U.log("lotCount>>>>>>>>>"+lotCount);
			
			if(lotCount==null) {
			String	site_link="https:"+U.getSectionValue(html, "\"cta_link\":\"https:", "\",");
			U.log("site_link-1>>>>>>>>>"+site_link);
//			if(site_link==null) {
//				String new_Html=U.getHTML("https://www.tripointehomes.com/wp-json/tpgsite/v1/neighborhood_info/"+jsonCommunityName);
//				site_link="https:"+U.getSectionValue(new_Html, "\"cta_link\":\"https:", "\",");
//			}
			
			U.log("site_link-2=="+site_link);
			if(site_link!=null && !site_link.contains("site")) {
				site_link=U.getSectionValue(neighbourhoodHtml, "\"sitemap_url\":\"", "\"");
			}
			if(site_link!=null) {
			site_link=site_link.replace("\\/", "/");
			}
			if(site_link!=null && site_link.contains("site/")) 
			{
				 site_mapHtml=U.getHTML(site_link);
				U.log("cache=="+U.getCache(site_link));
				if(site_mapHtml.contains("VIP.Main.setup")) 
				{
					String part_key=U.getSectionValue(site_mapHtml, "VIP.Main.setup('", "',");
					if(part_key!=null) 
					{
						String map_xml_data=U.getHTML("https://contradovip.com/site.get.php?rid="+part_key);
						if(map_xml_data!=null) {
							String[] lot_data=U.getValues(map_xml_data, "<option id=\"", ">");
							U.log("lot_data=="+lot_data.length);
							 lotCount=Integer.toString(lot_data.length);
							 U.log("lotCount2=="+lotCount);
						}
					}
				}
				
			}
//			else if(!site_link.contains("site")) {
//				site_link="https:"+U.getSectionValue(neighbourhoodHtml, "\"sitemap_url\":\"", "\"");
//				site_link=site_link.replace("\\/", "/");
////				U.log("site_link-3=="+site_link);
//				 site_mapHtml=U.getHTML(site_link);
//				 if(site_mapHtml!=null) {
//						String[] lot_data1=U.getValues(site_mapHtml, "<div id=\"hm", "</div>");
//						U.log("lot_data=="+lot_data1.length);
//						if(lot_data1.length!=0) {
//						 lotCount=Integer.toString(lot_data1.length);
//						 U.log("lotCount5=="+lotCount);
//			}
//				 }
//			}
			else {
				if(site_link!=null && (site_link.contains("site-plan") || site_link.contains("siteplan"))) {
				 site_mapHtml=U.getHTML(site_link);
				if(site_mapHtml!=null) {
					String[] lot_data=U.getValues(site_mapHtml, "<div id=\"hm", "</div>");
					U.log("lot_data=="+lot_data.length);
					if(lot_data.length!=0) {
					 lotCount=Integer.toString(lot_data.length);
					 U.log("lotCount4=="+lotCount);
					}
					else {
						lot_data=U.getValues(site_mapHtml, "allHomesitesArray.push({", "});");
						U.log("lot_data=="+lot_data.length);
						if(lot_data.length!=0) {
						 lotCount=Integer.toString(lot_data.length);
						 U.log("lotCount4=="+lotCount);
					}
				}
			}
				}	
			
			if(lotCount==null) {
				String id=U.getSectionValue(neighbourhoodHtml, "propertyID=", "\",");
				 U.log("id=="+id);
				 if(id!=null) {
				String site_MapHtml=U.getHTML("https://apps.focus360.com/focus360API/assets/"+id+"/SingleFamilySiteMaps/interactive_site_map.svg?");
				if(site_MapHtml!=null) {
						String[] lot_data=U.getValues(site_MapHtml, "<div id=\"vis_lot", "</div>");
						U.log("lot_data=="+lot_data.length);
						 lotCount=Integer.toString(lot_data.length);
						 U.log("lotCount3=="+lotCount);
					}
			}
			}
			}
			}
		
			
			if(lotCount==null||lotCount.equals("0")) {  //dt
//				String c=U.getSectionValue(html1.replace("<d2p1:LotCount>", "LotCount="), "LotCount=", "<");
				lotCount=ALLOW_BLANK;
			}
			propStatus=propStatus.replace("Coming Soon, Coming Early 2022", "Coming Early 2022")
					.replace("Coming Soon, Coming Spring 2022", "Coming Spring 2022");
					
					
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0].replace("Mansfield Texas 76063", "").toLowerCase().trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(lotCount);
	}
		j++;
		
	
			
//		}catch(Exception e) {}
	}
	
	//TODO:
	//------------ Here Old Code Before Feb 2021--------------
	public void innerProcess1() throws Exception {
		
/*		String html = U.getHTML("https://www.tripointehomes.com/wp-admin/admin-ajax.php?action=get_communities");
		html=StringEscapeUtils.unescapeJava(html);
		//U.log(html);
		String[] val=U.getValues(html,"region_id","neighborhood_order");
		U.log(val.length);
		
		for(int i=0;i<val.length;i++){
//		if(i==1){
//		U.log(val[i]);
			adDetails(val[i]);
		}
//		}
		
*/
		String html = U.getHTML(builderUrl);
		String regSection = U.getSectionValue(html, "<div class=\"Explore_Section\">", "<div class=\"explore_about_section");
		String regUrls[] = U.getValues(regSection, "<a href=\"", "\"");
		for(String regUrl : regUrls){
			U.log("regUrl :"+builderUrl+regUrl);
			String regHtml = U.getHTML(builderUrl+regUrl);
			
			String comSection = U.getSectionValue(regHtml, "var cmPositions =", "cmPositions =");
			comSection = StringEscapeUtils.unescapeJava(comSection);
			comSection = comSection.replace("\\/", "/");
//			U.log(comSection);

			String comSections[] = U.getValues(comSection, "{", "}");
			U.log(comSections.length);
			for(String comSec : comSections){
				
				String comUrl = U.getSectionValue(comSec, "card_Url\":\"", "\"");
				findSubCommunities(comUrl, comSec);
			}
		}
		LOGGER.DisposeLogger();
	}
	
	
	public void innerProcess2() throws Exception {
		
		String html = U.getHTML(builderUrl);
		String regionSec = U.getSectionValue(html, "Choose your location", "</div>");
		ArrayList<String> regions = Util.matchAll(regionSec, "class=\"region\">(.*?)</a>", 1);
		
		for(String name : regions) {
			
			name = name.toLowerCase().replace(" ", "-");
			String mainhtml = U.getHTML("https://www.tripointehomes.com/find-your-home/?filter_region="+name+"&sort=default");
			
			String[] commSec = U.getValues(mainhtml, "<div class=\"card-place-name\">", "class=\"card-btn\">");
				//U.log(commSec.length);
				for(String comSec : commSec) {
					
					String[] comUrls = U.getValues(comSec, "<a href=\"", "\"");
					for(String comUrl : comUrls) {
					//U.log(comUrl);
					if(comUrl.contains("city"))continue;
					findSubCommunities(comUrl, comSec);
					}
		
				}
		}
		
		
		//LOGGER.DisposeLogger();
	}
	private void findSubCommunities(String mainComUrl, String comSec) throws Exception{
		String html = U.getHTML(mainComUrl);
		
		String detailSection[] = U.getValues(html, "<div class=\"card-place-name\">", "class=\"card-btn\">");

		if(html.contains("<span>NEIGHBORHOODS</span>")) {
		for(String details : detailSection){
			String[] subCommUrl = U.getValues(details, " <a href=\"", "\"");
			
			for(String subCommSec : subCommUrl){
				
				if(subCommSec.contains("city"))continue;
				
				adDetails(subCommSec + details);
				
			}
		}}else{
	
			adDetails("<a href=\""+mainComUrl+"\""+comSec);
		}
	}
	
	//TODO 
	public void adDetails(String sec) throws Exception{
//	if(j >40)
	{
		
//		if(!sec.contains("https://www.tripointehomes.com/tx/houston/westridge-cove-50/caddo/"))return;
		U.log("===========================================================*s");
		U.log("Count ==="+j);
		//U.log(sec);
		
		String communityURL=U.getSectionValue(sec, "card_Url\":\"", "\"");
		if(communityURL == null)
			communityURL=U.getSectionValue(sec, "<a href=\"", "\"");
        U.log("commUrl::"+communityURL);
        
        if(sec.contains("https://www.tripointehomes.com/southern-california/community/weston/")) {
			LOGGER.AddCommunityUrl(communityURL+"::::::::redirect to main page:::::::::");
			return;
			}
		if(data.communityUrlExists(communityURL)){
			LOGGER.AddCommunityUrl(communityURL+"::::::::repeated:::::::::");
			i++;
			return;
		}
		
		
		LOGGER.AddCommunityUrl(communityURL);
		
        String html=U.getHTML(communityURL);
        String html1 = html;
        
        
        String commName=U.getSectionValue(sec, "title\":\"", "\"");
        if(commName == null)
        	commName=U.getSectionValue(sec, "<h3>", "</h3>");
        if(commName == null)
        	commName=U.getSectionValue(html, "<title>", "</title>").replaceAll("&#8211; Paired Homes|Coming Soon|- Coming Soon|, CO|\\|(.*)|\\| (.*?), CA|- TRI Pointe Homes", "");
/*        if(commName.contains("|"))
        	commName=U.getSectionValue(sec, "card__value\">", "|");
        if(commName.trim().endsWith("Villas")){
        	
*/      if(commName != null)
        	commName=commName.replace("&#8211; Paired Homes", "");  
        
	U.log("ComName::"+commName);

        html=html.replaceAll("Models opening Summer 2018!| and choices that range from the \\$400,000s to the \\$1 millions", " ");
        String formSec=U.getSectionValue(html, "<div class=\"rightSection\" id=\"rightsidebar\">", "Financing availability and terms will depend on your situation.");
        if(formSec != null) html=html.replace(formSec, "");
        String footerSec=U.getSectionValue(html, "<div class=\"regionnews text-center\">", "</footer");
        if(footerSec!=null)  	html=html.replace(footerSec, "");
        
        String geo="FALSE";
        String notes="";
		String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
//        U.log(html.contains("common area"));
//        if(html.contains("daddr=")){
//        	latlong=U.getSectionValue(html, "daddr=", "\"").split(",");
//        }
		
		
//        
        if (latlong[0]==ALLOW_BLANK||latlong[1]==ALLOW_BLANK) 
        {
        	latlong[0]=U.getSectionValue(sec, "lat\":\"", "\"");
        	latlong[1]=U.getSectionValue(sec, "long\":\"", "\"");
        	if(latlong[1] == null)
        		latlong[1]=U.getSectionValue(sec, "lng\":\"", "\"");
			U.log("latlong : " + latlong[0]);
			U.log("latlong : " + latlong[1]);
			geo="FALSE";
		}
        if(latlong[0] == null && latlong[1] == null){
        	String latLngSec = Util.match(sec, "[\""+commName.trim()+"\"],(.*?),\"https", 1);
        	if(latLngSec != null)
        		latlong = latLngSec.split(",");
        }
        
        String latHtml = U.getHTML(communityURL+"directions/");
        if(latlong[0] == null && latlong[1] == null){
        	
        	String latSec = U.getSectionValue(latHtml	,"href=\"https://www.google.com/maps","Get Directions</a>" );
        	U.log("latSec== "+latSec);
        	if(latSec != null) {
        	String latLngSec = Util.match(latSec, "@(.*?)\\d+z",1);
        	if(latLngSec != null)
        		latlong = latLngSec.split(",");
        	U.log("latlong : " + latlong[0]);
			U.log("latlong : " + latlong[1]);
			geo="FALSE";
        	}
        }
        
        if(latlong[0] == null && latlong[1] == null){
         	
         	if(latHtml != null) {
         latlong[0] = U.getSectionValue(latHtml, "{lat: ", ",");
         latlong[1] = U.getSectionValue(latHtml, "lng:", "}");
         	U.log("latlong : " + latlong[0]);
 			U.log("latlong : " + latlong[1]);
 			geo="FALSE";
         	}
        }
    
        //====================================================== ADDRESS ===================
        String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
        geo="FALSE";
        
        String addresSec = U.getSectionValue(sec, "complete_address", "}");
        
       if(addresSec == null) addresSec = U.getSectionValue(html, "<div class=\"neigh_address\">", "</li>");
       U.log("addressSec is = " + addresSec);
       
       if(addresSec != null) {
    	   addresSec = addresSec.replaceAll("<strong>Coming Soon to Raleigh</strong><br>", "");
    	   addresSec = U.getNoHtml(addresSec);
    	   addresSec = addresSec.replace("915 Jones Franklin Road  Raleigh, NC 27606", "915 Jones Franklin Road, Raleigh, NC 27606").replaceAll("Coming Soon to|Get Directions  |Drop-in: 3-6pm Tues, Thurs, &amp; Sat-Sun  By Appointment Only Thurs-Tues: 10am-6pm &amp; Wed 1-6pm|Ashburn New Home Gallery|Drop-in: 3-6pm Tues, Thurs, & Sat-Sun  By Appointment Only Thurs-Tues: 10am-6pm & Wed 1-6pm|Coming Soon to|Sales Office is Closed -  Call for an Appointment", "")
    			   .replace("26049 E. 1st Ave  Aurora,", "26049 E. 1st Ave,  Aurora,").replace("Way, Unit 112", "Way Unit 112").replace(" Corona", ", Corona").replace(" Southeast Aurora", ", Southeast Aurora").replace("Drive  Castle Pines", "Drive, Castle Pines")
    			   .replace(" Fort Mill", ", Fort Mill").replace("Drop-in: 3-5pm Tues, Thurs, &amp; Sat-Sun By Appointment Only Thurs-Tues: 10am-5pm &amp; Wed 1-5pm", "").replace(" San Francisco", ", San Francisco")
    			   .replace("3706 Red Fir Lane  Rocklin, CA 95677", "3706 Red Fir Lane,  Rocklin, CA 95677")
    			   .replace(" Westminster", ", Westminster").replace(" Dublin", ", Dublin").replace(" Fairfield", ", Fairfield").replace(" Oakland", ", Oakland").replace(" Lincoln", ", Lincoln")
    			   .replace(" Morgan Hill", ", Morgan Hill").replace(" Fremont", ", Fremont").replace(" Pleasant Hill" , ", Pleasant Hill").replace(" Gilroy", ", Gilroy")
    			   .replace(" Folsom", ", Folsom").replace(" Lathrop", ", Lathrop").replace(" Petaluma", ", Petaluma").replace(" Santa Clarita", ", Santa Clarita")
    			   .replace(" Temecula", ", Temecula").replaceAll("\\s+Thronton", ",  Thronton").replace(" Anaheim", ", Anaheim").replace(" Irvine", ", Irvine")
    			   .replace(" Rancho Cucamonga", ", Rancho Cucamonga").replace(" Huntington Beach", ", Huntington Beach").replace(" Ontario", ", Ontario")
    			   .replace(", Folsom CA 95630, Folsom, CA 95630", "Folsom, CA 95630").replace("Model and New Home Gallery- Coming Soon", "")
    			   .replace(" Rancho Mission Viejo", ", Rancho Mission Viejo").replace(" Chino", ", Chino").replace(" Mountain House", ", Mountain House")
    			   .replace("1575 Springsteen Road Rock Hill, SC 29730", "1575 Springsteen Road,  Rock Hill, SC 29730").replace("806 Amley Place  Apex, NC 27523 ", "806 Amley Place,  Apex, NC 27523 ")
    			   .replace("4627 Streambed Dr., , Folsom CA 95630,", "4627 Streambed Dr.").replace("13109 Anne Blount Alley  Davidson", "13109 Anne Blount Alley,  Davidson")
    			   .replace("10730 Reunion Pkwy Commerce City", "10730 Reunion Pkwy, Commerce City").replace("8941 Fraser River St  Littleton", "8941 Fraser River St,  Littleton").replace(" Castle Rock", ", Castle Rock").replace(" Arvada", ", Arvada").replace("806 Amley Place 806 Amley Place", "806 Amley Place").replace(" Santee", ", Santee");
    	   addresSec=addresSec.replaceAll("Sun-Mon 1pm - 6pm \\| Tue-Wed, Sat 10am - 6pm \\| Thurs-Fri - Closed|Drop-in: 3-5pm Tues, Thurs, &amp; Sat-Sun  By Appointment Only Thurs-Tues: 10am-5pm &amp; Wed 1-5pm|Model and New Home Gallery- NOW OPEN|Located off of Dominguez Road between Pacific Street and", "");
    	  U.log(addresSec);
    	   add = U.getAddress(addresSec);
    	  
       }
       add[0]=add[0].replace(" Washington D.C.", "Washington");
        
        U.log("Address: "+Arrays.toString(add));
        
   
//        if(communityURL.contains("colorado/amberly-at-sterling-ranch/"))
//	       {
//	    	   add[1]="Littleton";
//	    	   add[2]="CO";
//	    	   latlong=U.getlatlongGoogleApi(add);
//	    	   if(latlong == null) latlong = U.getNewBingLatLong(add);
//	    	   add=U.getAddressGoogleApi(latlong);
//	    	   if(add == null) add = U.getNewBingAddress(latlong);
//	    	   geo="TRUE";
//	    	   notes = "Address And LatLng Taken Using City And State";
//	    	   
//	       }
        if(communityURL.contains("/tesoro-at-trails-at-crowfoot/"))
	       {
	    	   add[1]="Parker";
	    	   add[2]="CO";
	    	   latlong=U.getlatlongGoogleApi(add);
	    	   if(latlong == null) latlong = U.getNewBingLatLong(add);
	    	   add=U.getAddressGoogleApi(latlong);
	    	   if(add == null) add = U.getNewBingAddress(latlong);
	    	   geo="TRUE";	  
	    	   notes = "Address And LatLng Taken Using City And State";

	       }  
        if(communityURL.contains("/colorado/duet-at-sunstone-village-in-terrai"))
	       {
	    	   add[1]="Castle Rock";
	    	   add[2]="CO";
	    	   add[3]="80108";
	    	   latlong=U.getlatlongGoogleApi(add);
	    	   if(latlong == null) latlong = U.getNewBingLatLong(add);
	    	   add=U.getAddressGoogleApi(latlong);
	    	   if(add == null) add = U.getNewBingAddress(latlong);
	    	   geo="TRUE";	    	   
	       }  
        
//        if(addresSec==null && latlong[0]!=null)
//        {
////        	addresSec = addresSec.replace(" Drive  Folsom", " Drive,  Folsom").replace("Daily 10am - 5pm  Wednesday 1pm - 5pm", "").trim();
//        	//Format the address Section
//        	add[0]=U.getSectionValue(sec, "address\":\"", "\"");
//        	add[1]=U.getSectionValue(sec, "city\":\"", "\"");
//        	add[2]=U.getSectionValue(sec, "state\":\"", "\"");
//        	add[3]=U.getSectionValue(sec, "zip_code\":\"", "\"");
//        	 U.log("Add ::::"+Arrays.toString(add));
//        	 if(add[0] != null)
//            add[0]=add[0].replace("Coming Soon", ALLOW_BLANK);
//        	
//        }
        
       if(addresSec==null){
    	   addresSec = U.getSectionValue(html, "<div class=\"neigh_address\">", "<li class=\"time\">");
           U.log("addressSec is = " + addresSec);
          

    	   if(addresSec != null){
    		   addresSec = addresSec.replace(" Drive  Folsom", " Drive,  Folsom").replaceAll("<.*?>", "").trim();
	   			U.log(addresSec);
	   			String [] vals = addresSec.split(",");
   				add[3] = Util.match(vals[vals.length-1], "\\d{5}");
   				add[2] = vals[vals.length-1].replace(add[3], "").trim();

	   			if(vals.length == 2){
	   				add[1] = U.getSectionValue(html, "addressLocality\": \"", "\"");
	   				add[0] = vals[0].replace(add[1], "").trim();
	   			}
	   			if(vals.length == 3){
	   				add[1] = U.getSectionValue(html, "addressLocality\": \"", "\"");
	   				add[0] = vals[0]+" "+vals[1].replace(add[1], "").trim();
	   			}
   			}
       }
       
       if(addresSec==null || add[0].length()<3){
    	   if(latHtml!=null)
    	    addresSec = U.getSectionValue(latHtml, "<li class=\"city\">", "<br>");
    	   if(addresSec!=null) {
    		   U.log(addresSec);
    	    addresSec = addresSec.replace(".", ",").replace("Coming Soon to", ",").replace(" Santa Clarita", ", Santa Clarita").replace(" Temecula", ", Temecula").replace("  Thronton", ",  Thronton").replace(" Anaheim", ", Anaheim");
    	   add = U.getAddress(addresSec);
    	   }
    	   
       }
       
       if(add[0].length()>3)
    	   add[0] = add[0].replace("4627 Streambed Dr.,, Folsom CA 95630", "4627 Streambed Dr")
    	   .replaceAll("Model and New Home Gallery- Coming Soon", "");
       
       U.log("Hello-----"+add[0]);
       
       if(add[0] == null || add[0]== ALLOW_BLANK) {
    	   
    	   if(latlong[0] != null && latlong[0]!= ALLOW_BLANK) {
    		   
    		   add  = U.getAddressGoogleApi(latlong);
    		   if(add == null)add = U.getGoogleAddressWithKey(latlong);
    		   geo = "TRUE";
    	   }
       }
      
       String note = ALLOW_BLANK;
       if(add[0]== null || add[0] ==ALLOW_BLANK) {
    	   
    	   String addnew = U.getHTML("https://www.tripointehomes.com/contact/");
    	   if(communityURL.contains("colorado") && add[0].length()<3) {
    		   add[0] = "8055 E Tufts Avenue Suite 675";
    	   		add[1] = "Denver";
    	   		add[2] = "CO";
    	   		add[3] = "80237";
    	   		note = "Addresss Taken From Contact";
    	   }
    	   
    	   if(communityURL.contains("carolinas") && add[0].length()<3) {
    		   add[0] = "3436 Toringdon Way, Suite 210";
    	   		add[1] = "Charlotte";
    	   		add[2] = "NC";
    	   		add[3] = "28277";
    	   		note = "Addresss Taken From Contact";
    	   }
    	   
    	   if(communityURL.contains("California")) {
    		   add[0] = "5 Peters Canyon Road Suite 100";
    	   		add[1] = "Irvine";
    	   		add[2] = "CA";
    	   		add[3] = "92606";
    	   }
    	    note = "Addresss Taken From Contact";
    	   
       }
       
       if(communityURL.contains("https://www.tripointehomes.com/neighborhood/cerro/")) {
    	   
    	   add[0] = "45430 Via Nubes";
	   		add[1] = "Temecula";
	   		add[2] = "CA";
	   		add[3] = "92592";
       }
       
       if(communityURL.contains("https://www.tripointehomes.com/southern-california/stratapointe/")) {
    	   
    	   add[0] = "5849 Spring Street";
	   		add[1] = "Buena Park";
	   		add[2] = "CA";
	   		add[3] = "90620";
       }
       
       //Lat-Lng taken from region page
       if(communityURL.contains("/southern-california/cava/") ||communityURL.contains("/southern-california/cerise/") || communityURL.contains("/southern-california/cassis/") || communityURL.contains("/southern-california/claret/") || communityURL.contains("/southern-california/violet/")){
    	   latlong[0] = "33.8329766";
    	   latlong[1] = "-117.9060498";
       }
       U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+latlong[0]);
       if(add[0] == ALLOW_BLANK||add[0].length()<2 || add[3] == ALLOW_BLANK)
       {
  		//U.log("Hello-----");
    	   
    	if(latlong[0].length()>3 && latlong[0] != null) {
    		if(latlong[0] == null || latlong[0]== ALLOW_BLANK)
    			latlong = U.getlatlongGoogleApi(add);
       	add=U.getAddressGoogleApi(latlong);
       	if(add == null) add = U.getNewBingAddress(latlong);
       	if(add == null) add = U.getAddressHereApi(latlong);
       	geo="TRUE";
    	}
       }
       
       
       if(latlong[0] == null||latlong[0] == ALLOW_BLANK||latlong[0].length()<2)
       {
  	//	U.log("Hello-----");
       	latlong=U.getAddressGoogleApi(add);
       	//if(latlong == null) latlong = U.getNewBingAddress(add);
       	if(latlong == null) latlong = U.getlatlongHereApi(add);
       	geo="TRUE";
       }

       if(latlong[0]==null) {
       	
       	String latSec = U.getSectionValue(latHtml, "<div class=\"utility-nav__chunk utility-nav__primary\">", "</nav>");
       	latSec =	U.getSectionValue(latSec	,"<a href=\"https://maps.google.com/maps?saddr=&daddr=","\"" );
       	latlong =latSec.split(",");
       	geo = "TRUE";
       	}
     
       /*//FloorPlans Data     
       String homeHtml="";
       if(html.contains("<div class=\"floorPlanPage"))
       {
    	   int k=0;
    	   String[] urlSec=U.getValues(html, "<h1>", "View Floor Plan Details");
    	   for(String url:urlSec)
    	   {
    		   if(k>5)break;
    		   url=U.getSectionValue(url, "<a href=\"","\"");
    		   String homeHtml1=U.getHTML(url);
    	       footerSec=U.getSectionValue(homeHtml1, " <h1 class=\"plan_floor_head\">", "</footer");
    	       homeHtml1=homeHtml1.replace(footerSec, "");
    	       homeHtml1=homeHtml1.replace(formSec, "");
    	       homeHtml+=homeHtml1;
    	   }
       }*/
       
     //============= Floor Plans===============
		String allFloorHtml = ALLOW_BLANK;
		String planUrlSections[] = U.getValues(html, "<div class=\"card-main-div\">", "</div>");
		for(String planUrlSec :planUrlSections){
			String planUrl = U.getSectionValue(planUrlSec, "<a href=\"", "\"");
			U.log("planUrl ::"+planUrl);
			String planHtml = U.getHTML(planUrl);
			allFloorHtml += U.getSectionValue(planHtml, "class=\"print_div\">", "class=\"photoGallery\"");;
		}
       
		
		String allMoveInReadyHtml = ALLOW_BLANK;
       //getting move-in homes data main page
       int moveinCount = 0;
		String moveInHtml=U.getHTML(communityURL+"move-in-ready-homes");
       if(moveInHtml!=null){
    	   moveInHtml=moveInHtml.replace("anticipated between $700,000", "");
    	   
    	   String moveInReadyUrlSections[] = U.getValues(moveInHtml, "<div class=\"card-main-div\">", "</div>");
    	   moveinCount =moveInReadyUrlSections.length;
    	   for(String moveInReadyUrlSec :moveInReadyUrlSections){
	   			String moveInReadyUrl = U.getSectionValue(moveInReadyUrlSec, "<a href=\"", "\"");
	   			U.log("moveInUrl ::"+moveInReadyUrl);
	   			String moveInReadHtml = U.getHTML(moveInReadyUrl);
	   			if(moveInReadHtml == null)moveInReadHtml = ALLOW_BLANK;
	   			allMoveInReadyHtml += U.getSectionValue(moveInReadHtml, "class=\"print_div\">", "class=\"photoGallery\"");
   			
   			}
//    	   moveInHtml=moveInHtml.replace(U.getSectionValue(moveInHtml, "<div class=\"regionnews text-center\">", "</footer"), "");
       }
       //Getting prices
    	String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
    	html = html.replace("299s", "299,000").replaceAll("00,000'(S|s)", "00,000");
    	html=html.replace("$600,000's", "$600,000").replace("Priced from the $600's - $800's", "Priced from the $600,000 - $800,000").replaceAll("back to the 1800’s", "").replaceAll("800's","0,000");
    	sec=sec.replace("$1 Millions", "\\$1,000,000").replace("anticipated between $700,000", "");
    	sec=sec.replaceAll("300's|300s|300Ks","300,000");
    	html=html.replace("300Ks", "300,000").replace("Anticipated between $700s", "");
    	html=html.replaceAll("300's|300s|300Ks","300,000");
    	html=html.replace("600s", "600,000");
    	html=html.replace(" $500’s", " $500,000");
    	html=html.replace("$1 millions", "$1,000,000").replace("from the $1.2 to $1.4 millions", "from the $1,200,000 to $1,400,000 millions");
    	html=html.replace("500s", "500,000").replaceAll("800s|800's", "800,000").replace("700s", "700,000").replace("900s", "900,000").replace("0Ks", "0,000");
    	html=html.replaceAll("400s|400’s", "400,000");
    	html=html.replaceAll("0s|0's|0S", "0,000").replace("$800,000,000", "$800,000");
//    	if(Pattern.matches( "\\$\\d{3},\\d{2}", html))
//    		html=html.replace("0s", "0,000");
    	html=html.replace("from the High $500's", "from the High $500,000").replace("$400's", "\\$400,000");
    	html=html.replace("Mid $400s", "Mid $400,000").replace("$1.2 Millions", "$1,200,000").replace("$1.3 Millions", "$1,300,000");
    	html=html.replace("High $1.1 to $1.3 millions"," High $1,100,000 to $1,300,000 millions").replace("$1.2", "$1,200,000")
    			.replace("$2 Millions", "$2,000,000")
    			.replace("$1.4 Millions", "$1,400,000");
    	html = html.replace("Anticipated from the $300,000,000", "Anticipated from the $300,000");
//    	html = formatMillionPrices(html);
//    	sec=formatMillionPrices(sec);
//	U.log(html);
//    	moveInHtml=formatMillionPrices(moveInHtml);

    	String sec1 = U.getSectionValue(sec, commName, "Baths");
//		U.log(Util.matchAll(html, "[\\s\\w\\W]{30}300[\\w\\s\\W]{10}", 0));

    	String[] price = U
				.getPrices(
						html+sec1+moveInHtml+allMoveInReadyHtml,
						"from the \\$\\d,\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3} millions|Priced from the Mid \\d{3},\\d{3}|Priced from the High \\d{3},\\d{3}|from the \\d{3},\\d{3}|from the Low \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3}|(l|L)ow \\$\\d,\\d{3},\\d{3}|Priced from \\$\\d,\\d{3},\\d{3}|MID \\$\\d{3},\\d{3}|Starting from \\$\\d{3},\\d{3}|<label>\\s*\\$\\d{3},\\d{3}\\s*</label>|High \\$\\d+,\\d+,\\d+ to \\$\\d+,\\d+,\\d+ millions|\\$\\d+,\\d+,\\d+|Low \\$\\d+,\\d+ to Low \\$\\d Millions|from \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice :" + maxPrice + "------");
        html =html.replace("sf &#8211;", "sf -");
      //U.log(sec1); 
    
        
        //getting SQFT
        String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
        html=html.replaceAll("as 27,000 square feet of commercial/|approximately 5,000 square feet of space ","");
        sec=sec.replace("0s", "0,000");
        String[] sqft = U.getSqareFeet(sec1+html+moveInHtml, "approximately \\d,\\d+ sq.ft to \\d,\\d+ sq. ft|to \\d,\\d{3} square feet|range from \\d,\\d{3} to \\d,\\d{3} sq. ft. |\\d,\\d{3} sf - \\d,\\d{3} sf|\\d,\\d{3} square feet|\\d+,\\d+ - \\d+,\\d+|\\d+,\\d+-\\d+,\\d+|card__value\">\\d+,\\d+</span>|\\d,\\d{3} to \\d,\\d{3} square feet|Sq Ft:  \\d{1},\\d{3}</p>|<br>\\d{1},\\d{3} sq. ft <br>",0);
		minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
		maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//Getting Status
		
		String remove="home or common area will offer|floor|New Townhomes Now Selling \\| TRI Pointe Homes|homeowner’s association dues|purchasing a single family home and primary residence|Farmhouse Style Exterior|Coming Soon – |Coming 2018|NOW OPEN: 3-story attached townhomes|Ranch Golf|content=\"Coming soon|Rancho|99 Ranch Market| Rancho Milpitas Middle School|Tustin Ranch Golf Club|Ranch View Elementary School K to 6|Vail Ranch Resort|Village".toLowerCase();
		html=html.replace("JUST RELEASED","NEW HOMESITES JUST RELEASED");
		html=html.replace("NEW HOMESITES BACKING TO OPEN SPACE JUST RELEASED","NEW HOMESITES JUST RELEASED");
		html=html.toLowerCase().replaceAll(remove, "");
		sec=sec.toLowerCase().replace(remove, "");
		if(moveInHtml!= null && allFloorHtml != null){
			moveInHtml=moveInHtml.replaceAll(remove, "").replace("Farmhouse Style Exterior", "");
			allFloorHtml=allFloorHtml.replaceAll(remove, "").replace("Farmhouse Style Exterior", "");
		}
		String rem=U.getSectionValue(html,"<p class=\"accordion__tab__extra\">","<a href");
		if(rem!=null)
		html=html.replaceAll(rem,"");
		
		html = html.replaceAll("coming summer decor|status == \"coming_soon\"|coming soon – new jordan|coming soon to the canyonview neighborhood at candelas|coming soon duet|class=\"card-time\">\\s*<span>\\s*coming soon|Now Selling in the San Gabriel|now selling in the San Gabriel|Coming soon to the Canyonview|title\">one home lef|>Sold Out|tab__title\">sold|new homes coming soon to irvine|title\">temporarily sold out</div>|homes coming soon", "");
		html=html.replaceAll("model home now selling! view|<p class=\"card-time \"><span>Now Selling</span></p>|loved Coming soon early 2017|originally are now available|Coming soon to the Canyonview|coming soon &#8211; early 2017", "Coming soon early 2017").replace("only a few homes left","");
		html=U.removeSectionValue(html, "<div class=\"mortgage-calculator\">", "class=\"mortgage-calculator__close");
		html=U.removeSectionValue(html, "<footer", "</body");
		sec=sec.replaceAll("coming summer decor|status == \"sold out\"|status == \"temporary sold out\"|<p class=\"card-time\"><span>sold out</span>|coming soon – new jordan|coming_soon|model home now selling!|now selling in the San Gabriel|Now Selling in the San Gabriel|Coming soon to the Canyonview","");
		html=html.replaceAll("lucera at aliento now selling|<span class=\"plan-status-floor\">(.*?)<|status == \"sold out\"|status == \"temporary sold out\"|<p class=\"card-time\"><span>sold out</span>|<span class=\"plan-status-\">(.*?)</span>", "");
		sec=sec.replaceAll("\"Temporary|card-time \"><span>temporarily|<span class=\"plan-status-floor\">(.*?)<|\"driving_directions\":\"<p>coming soon!|on a move-in ready home|move-in ready homes positioned", "");
//		U.log(sec);
		html=html.replace("craftsman, agrarian and", "and Craftsman").replace("coming this fall 2019", "Coming Fall 2019")
				.replaceAll("status == \"sold out\"|status == \"temporary sold out\"|<p class=\"card-time\">\\s*<span>sold out</span>|<p class=\"card-time\">\\s*<span>coming soon", "")
				.replaceAll("models now selling|\"Temporary|coming soon\">|card-time\"><span>temporarily sol|card-time\"><span>now selling|status == \"sold|coming 2020 - relax|crowfoot coming|class=\"card-time \"><span>(C|c)oming|soon &#8211; model|model home opening|tierno at aliento now|now selling in south", "");
//		
		
		String status=U.getPropStatus(html.replaceAll("chance to live|card-time \"><span>sold|<p class=\"card-time \"><span>now selling</span></p>|loved Coming soon early 2017|great park neighborhoods now selling|new homes now selling at cadence park in irvine|model home now selling|p class=\"card-time\"><span>coming soon|coming soon duet|flowers-coming-soon-|coming-soon-duet|model(s)? now selling|ew homes coming soon to aurora|flowers-coming-soon|prelude collection at adonea coming soon|card-time \"><span>temporarily sold|newport now selling|about our grand opening|Coming Soon Crescendo Collection|coming soon crescendo collection|park coming soon|coming soon to|coming_soon|final opportunities now selling from viridian|Coming Soon – New Jordan Ranch|now selling in the San Gabriel|Now Selling in the San Gabriel|Coming soon to the Canyonview|pre-sales coming spring 2017|MODEL HOMES NOW AVAILABLE!|floorplans coming soon\\*\\*</p>|pricing coming soon|\">coming soon</div>|>coming soon &#8211; new jordan ranch school| model homes are coming soon|coming early 2017.</p>|parasol park. coming early 2017|Currently Sold Out|under construction|Sold</span>|status == \"sold out\"|status == \"temporary sold out\"|coming_soon|&amp; Coming soon early 2017 <a href=|attached model homes now available|a community of brand new homes coming this Fall|New Homes Now Selling in Rancho ","")
				+ sec.replaceAll("chance to live|card-time \"><span>sold|new homes now selling at cadence park|loved Coming soon early 2017|model home now selling|model(s)? now selling|coming-soon-duet|coming soon duet|card-time \"><span>temporarily sold|Coming Soon Crescendo Collection|coming soon crescendo collection|Sold</span>|coming_soon|Coming Soon – New Jordan Ranch|status == \"sold out\"|status == \"temporary sold out\"|\"sold out\",\"|new homes coming this Fall|New Homes Now Selling in", ""));
		//replace content from main comm. pg
		//U.log("KKKKKKKKKKKKKKKKK"+Util.matchAll(html+sec, "[\\s\\w\\W]{30}Floor Plans Available[\\s\\w\\W]{30}", 0));
		
		 if(communityURL.contains("/cassis/"))
			sec = sec.replaceAll("3-story townhomes|2-story duplex and triplex homes", "");
		
		else if(communityURL.contains("/cava/"))
			sec = sec.replaceAll("2-story single-family detached homes|2-story duplex and triplex homes", "");
		
		else if(communityURL.contains("/cerro/"))
			sec = sec.replaceAll("2-story single-family detached homes|3-story townhomes", "");
		 html = html.replace("casual luxury of single-story living", "casual luxury homes of single-story living")
				 .replaceAll("european cottage style exterior|cottage_\\d|Cottage_\\d|Adob-|insurance premiums, homeowner’s association|home or common area will offer|farmhouse exterior|farmhouse architecture|- craftsman exterior|farmhouse style exterior|homes\\. these detached home|backpatio", "");
		
		 
		 //============================PropertyTypes
		
		 
		 		 
		 html=html.replace("architecture featuring craftsman", "California Craftsman").replace("Transitional Ranch, Farmhouse", "Transitional Ranch, Farmhouse-style exteriors").replace("designs featuring farmhouse", "Farmhouse-inspired architectura");
		String ptype=U.getPropType((html+allMoveInReadyHtml+allFloorHtml+sec)
				.replaceAll("learn about these detached home|european cottage style exterior|cottage_\\d|European Cottage Style Exterior|European Cottage|Cottage_\\d|insurance premiums, homeowner’s association|home or common area will offer|village|Village|caption=\"Traditional|farmhouse architecture|- craftsman exterior<|farmhouse style exterior", ""));
		
		
		//==============================Derived PropertyTypes
		
		html=html.replaceAll("2-3 story homes", "2 story homes-3 story homes");
		html = html.replaceAll("itle\": \"irvine ranch|\"name\": \"irvine ranch|name\">irvine ranch|Rancho|99 Ranch Market| Rancho Milpitas Middle School|Tustin Ranch Golf Club|Ranch View Elementary School K to 6|Vail Ranch Resort", "");
		html = html.replaceAll("Ranch Golf Club|floor|Ranch Golf|Rancho|Branch|branch|99 Ranch|rancho|99ranch| models coming soon with ranch|RANCHO|Rancho", "");
		allFloorHtml=allFloorHtml.replace("Rancho Solano Golf Course", "");
		html=html.replace(" one- and two-story", " 1 Story  2 Story ").replace("single and two-story", " 1 Story  2 Story ");
		String dtype=U.getdCommType((html.replace("one-and two-story ","1 Story 2 Story")+allFloorHtml+moveInHtml).replaceAll("Rancho", ""));if(communityURL.contains("southern-california/cassis/"))dtype="1 Story";
		
		
		//================================community types
		
		String lifestylePage=U.getHTML(communityURL+"lifestyle/");
		html = html.replace("<div class=\"masterplan\">", "").replace("west woods golf course", "").replace("Country Club</li><li itemprop=\"nam", "").replace("Tracy Golf and Country Club", "").replace("name\">tracy golf and country", "").replace("e\": \"tracy golf and country", "").replace("<p><a class=\"masterplan", "");
		html = html.replaceAll("golf club\"|golf club</li|dublin ranch golf course|green tree golf club|spring valley golf course|Hayword Golf Course|hayword golf course", "");
		String commtype=U.getCommunityType(html+sec+lifestylePage);
		commName=commName.replaceAll("\\.", "");
		if(communityURL.contains("redstone")){
			maxPrice="$724,900";
		}
		//if(communityURL.contains("https://www.tripointehomes.com/northern-california/blanc-at-glen-loma/"))maxPrice = "$790,990";
        if(communityURL.contains("southern-california/citron-at-bedford/"))status=status.replace("Coming Soon, ","");
		if(communityURL.contains("southern-california/tempo-at-the-resort/"))status=status.replaceAll(" Coming This Fall, Coming Fall 2019"," Coming This Fall 2019");
		if(communityURL.contains("southern-california/celestia-at-skyline/")||communityURL.contains("southern-california/mystral-at-skyline/"))status=status.replaceAll(" Coming This Fall,","");
//		if(communityURL.contains("southern-california/windbourne/")) status=status+", New Homes Now Selling"; 
		if(communityURL.contains("/lucera-at-aliento/")) {
			status = status.replaceAll("Now Selling", "Last Chance");
		}
		if(communityURL.contains("https://www.tripointehomes.com/bay-area/apex-mission-stevenson/") || communityURL.contains("https://www.tripointehomes.com/southern-california/st-james-at-park-place/")
				|| communityURL.contains("https://www.tripointehomes.com/colorado/prelude-collection-ravenwood-village-terrain/")) {
			ptype = ptype.replace(", Homeowner Association", "");
		}
		
		if(sec.contains("https://www.tripointehomes.com/southern-california/celestia-at-skyline/")) {
			
			ptype = "Farmhouse Style Homes";
			dtype += ", Ranch";
		}
		
		status = status.replace("Now Selling, New Homes Now Selling", "New Homes Now Selling");
		add[2] = add[2].replace("Daily 10am - 5pm  Wednesday 1pm - 5pm", "").trim();
		 add[0] = add[0].replaceAll("TBD|Coming Soon", "").trim();
		 
		ArrayList<String> soldCount = Util.matchAll(html, "<p class=\"card-time \"><span>Sold Out</span></p>",0);
		U.log(soldCount.size()+":::"+moveinCount);
		if(soldCount.size()>=moveinCount) {
			status = status.replaceAll("Move-in Ready Homes,|Move-in Ready Homes", "");
		}
	
		
		status = status.trim().replaceAll("^,|,$", "").trim();
		data.addCommunity(commName, communityURL, commtype);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(html));
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
		data.addNotes(note);
		}
		j++;
	}
		
	
	
	//Format million price
		private String formatMillionPrices(String html){
			Matcher millionPrice = Pattern.compile("\\$\\d\\.\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
				while(millionPrice.find()){
				//U.log(mat.group());
				String floorMatch = millionPrice.group().replace(" M", "00,000").replace(".", ",");  //$1.3 M
				html	 = html.replace(millionPrice.group(), floorMatch);
				}//end millionPrice
			return html;
	}
}
	