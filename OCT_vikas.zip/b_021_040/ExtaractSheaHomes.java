/*Modification Aditya
 * 14-07-15
 *  Ashish Shivhare
 *  28 Aug 2013
 */
package com.shatam.b_021_040;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtaractSheaHomes extends AbstractScrapper {
	static int sitecounter = 0;
	CommunityLogger LOGGER;
	public int i = 0;
	public int inr = 0;
	static int j = 0;
	static int duplicates = 0;
	WebDriver driver;
	static ArrayList<String> s = new ArrayList<String>();
	private static final String builderUrl = "https://www.sheahomes.com";

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtaractSheaHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Shea Homes.csv", a.data().printAll());
	}

	public ExtaractSheaHomes() throws Exception {

		super("Shea Homes", builderUrl);
		LOGGER = new CommunityLogger("Shea Homes");
	}

	public void innerProcess() throws Exception {
					//		U.setUpGeckoPath();
					//		driver = new FirefoxDriver();
		U.setUpChromePath();
		driver = new ChromeDriver();
		String baseUrl = "http://www.sheahomes.com/new-homes/";
		String commuityListPage = getHtml(baseUrl, driver);
		String communitySec = U.getSectionValue(commuityListPage,
				"<label class=\"home-search-form-data-label\" aria-hidden=\"true\">",
				"class=\"home-search-form-data-label\"");
		//U.log(communitySec);
		String values[] = U.getValues(communitySec, "{&quot;Name", "IsFavorite");
		U.log(values.length);
		for (String comSec : values) {
			comSec = StringEscapeUtils.unescapeHtml3(comSec);
			String comUrls = U.getSectionValue(comSec, "\"Url\":\"", "\"");
//			U.log(comUrls);
			getCommunityUrl(comSec, builderUrl + comUrls);
			// break;

		}
		LOGGER.DisposeLogger();
//		try{
			driver.quit();
//		}catch (Exception e) {}
		
	}

	//TODO:
	private void getCommunityUrl(String commSec, String commUrl) throws Exception {
//		try{
//		if(j>=0  && j<=10)
//		if(j>=60)
//			if(j>=51)
//		if (!commUrl.contains("https://www.sheahomes.com/new-homes/texas/houston-area/spring/harmony-50-series-at-vivace")) return;
		{
			
		
			U.log("COUNT-============= "+j);
		U.log(commSec);
		U.log(commUrl);
		
		
//		if(commUrl.contains("https://www.sheahomes.com/new-homes/virginia/northern-virginia/lake-frederick/trilogy-at-lake-frederick")) {
//			
//			LOGGER.AddCommunityUrl("=========== Redirect ============== "+commUrl); 
//			return;
//		}
		
		if(data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl("=========== Repeated ============== "+commUrl); 
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		String comHtml = getHtml(commUrl, driver);
//		U.log("22=====" + Util.matchAll(comHtml,"[\\w\\s\\W]{100}New Homesites Releasing[\\w\\s\\W]{100}", 0));

		String MetaName  = U.getSectionValue(comHtml, "<meta property=\"og:title\" content=\"", "\"");
		
		
		String removeSection= U.getSectionValue(comHtml, "<section id=\"communitylist-prepopulated-cards\" ", "</htm");
		if(removeSection!=null)
		comHtml =comHtml.replace(removeSection, "");
//		U.log("11=====" + Util.matchAll(comHtml,"[\\w\\s\\W]{100}New Homesites Releasing[\\w\\s\\W]{100}", 0));
		String removeSection1= U.getSectionValue(comHtml, "<h4>WHAT'S HAPPENING AT SHEA</h4>", "</ul>");
		if(removeSection1!=null)
		comHtml =comHtml.replace(removeSection1, "");
		String quickSec=U.getSectionValue(comHtml, "<section id=\"qmi-homes\" class=\"quick-move-in none\"", "</section>");
//		U.log(">>>>>>>>>"+quickSec);
		U.log("KKKKKKKKKKk======" + U.getCache(commUrl));
		// ========================================Address======================================
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String flag = "FALSE";
		
		String addressSec = U.getSectionValue(comHtml, "<p class=\"header\">Address</p>", "</p>");
		if(addressSec == null) addressSec = U.getSectionValue(comHtml, "class=\"info_header\">Community Address</p>", "</p>");

		if(addressSec == null) 
			addressSec = U.getSectionValue(comHtml, "Community Address", "</p>");
//		U.log("addressSec==="+addressSec);
		//U.log(addressSec);
		if(addressSec!=null && addressSec.contains("<span itemprop=\"streetAddress\">")) {
			add[0]= U.getSectionValue(addressSec, "<span itemprop=\"streetAddress\">", "<");
			add[1]= U.getSectionValue(addressSec, "<span itemprop=\"addressLocality\">", "<");
			add[2]= U.getSectionValue(addressSec, " <span itemprop=\"addressRegion\">", "<");
			add[3]= U.getSectionValue(addressSec, "<span itemprop=\"postalCode\">", "<");

		}

		U.log(Arrays.toString(add));
		add[0] = add[0].replace("Coming Soon", "");
		// =========================================Latlon=======================================
		// String latlonSec=U.getSectionValue(commSec, "", "");
		String latLon[] = { ALLOW_BLANK, ALLOW_BLANK };
		latLon[0] = U.getSectionValue(commSec, "\"Lat\":\"", "\"");
		latLon[1] = U.getSectionValue(commSec, "\"Long\":\"", "\"");
		U.log(Arrays.toString(latLon));

		if (latLon[0].length() < 4 && add[1].length() > 4) {
			latLon = U.getlatlongGoogleApi(add);
			if(latLon == null) latLon = U.getlatlongHereApi(add);
			flag = "TRUE";
		}
		
		//5760-5998 E Richlawn Ln
		//https://www.sheahomes.com/new-homes/colorado/denver-area/littleton/reflection-at-solstice
		if ((add[0].length()<4||add[1].length() < 4) && latLon[1].length() > 4) {
			add = U.getAddressGoogleApi(latLon);
			if(add == null) add =U.getGoogleAddressWithKey(latLon);
			flag = "TRUE";
		}
		if(commUrl.contains("/austin/highpointe-80s-platinum-heights")) {
			latLon = new String[] {"30.166070", "-97.999504"};
		}
		if(add[0].length()>3 && add[1].length()>3 && add[3].length()<5) {
			add[3] = U.getAddressGoogleApi(latLon)[3];
			flag = "TRUE";
		}
		add[0]  =add[0].replace("Teresina", "");

		
		// ============= Community Name ===================
		comHtml = comHtml.replace("Shea Homes® at", "").replace("Shea Homes? at", "");
		String communityName = U.getSectionValue(comHtml,"<p class=\"community-desktop-sticky_community-name\">","<");//U.getSectionValue(comHtml, " <h1 class=\"caption-title\">", "</h1>");
		U.log(communityName+":::::::::this is comm name::::::::"+MetaName);
		
		if (communityName == null)
			communityName = U.getSectionValue(comHtml, "'community': '", "',");
		if (communityName == null)
			communityName = U.getSectionValue(comHtml, "<title>", "|");
		if(communityName== null && MetaName != null) communityName = MetaName;
		if (communityName!= null && communityName.contains("</title>"))
			communityName = communityName.substring(0, communityName.indexOf("in"));
		String remove = " Resort Community| Town Homes| <!--%#-->|- townhome-style living|- Townhome Style Living|New Homes In The|By Shea|- Shea3D At Colliers Hill|New In|Gated Communities And New In|, FL|Shea At|Shea Homes At|Shea3d At|mountain house - |the woodlands:|Villas$|^shea homes®";
		if (communityName!= null) {
		communityName = communityName.toLowerCase().replaceAll(remove.toLowerCase(), "");
		communityName = communityName.replace("monta?a", "Montana");
		communityName = communityName.replace("� ", "").replace("Resort Community", "");
		communityName = communityName.replace("�", "");
		}
		//Encanterra� A Trilogy�
		if(communityName== null || !communityName.contains(MetaName))communityName = MetaName;
		U.log("CommName::" + communityName);

		// ===================================================================================
		
		String nearCommunities = U.getSectionValue(comHtml, "<section id=\"region-community-cards\"", "</section>");
		if(nearCommunities== null) nearCommunities = "";

		comHtml = comHtml.replace(nearCommunities, "");

		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comHtml=comHtml.replaceAll("57,000 square feet of amenity", "")
				.replaceAll("0's|0&#39;s|0’s|0s", "0,000");
		comHtml=comHtml.replace("50’ Series From the $300,000","")
				.replaceAll("square feet that start in the \\$300,000.|description\" content=\"Discover elegant one and two-story homes, square feet that start in the $300,000.", "")
				.replace("Series From the $260,000", "").replace("lots that start in the $260,000", "").replace("Series From the $280,000", "").replace("set on 50-foot lots that start in the $280,000", "")
				.replace("that start in the $370,000", "")
				.replace("Anticipated pricing from $3.1 Million", "Anticipated pricing from $3,100,000");
		String[] price = U.getPrices( comHtml+ commSec,
				"Anticipated pricing from \\$\\d,\\d{3},\\d{3}|upper \\$\\d{3},\\d+ to the lower \\$\\d{3},\\d+|\\$\\d{3},\\d+ to \\$\\d{3},\\d+|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|Priced at\\s*<span>\\s*\\$\\d{3},d{3}\\s*</span|\\$\\d{3},\\d{3}",
				0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice :" + maxPrice + "==");

//		U.log("MMMMMMM "+Util.matchAll(comHtml , "[\\s\\w\\W]{30}260[\\s\\w\\W]{100}", 0));
//		U.log("MMMMMMM "+Util.matchAll(commSec  , "[\\s\\w\\W]{30}\\$1,061,000[\\s\\w\\W]{100}", 0));

		
		// =====================================================================================

		comHtml = comHtml.replaceAll("floorplans range from approx. \\d,\\d+-\\d,\\d+ sq", "")
				.replaceAll("This 40’ Series community includes new homes ranging from ~1,624 to 2,588 square feet on 40-foot homesites|\\d+,\\d+ square feet of covered porches|over \\d+,\\d{3} square feet of indoor and outdoor|\\d,\\d{3} SF of Fitness|"
						+ "homesites average \\d{2},\\d{3} square feet|\\d,\\d{3} square feet of space dedicated to your daily exercise|z-index:1800000000}|"
						+ "The 50’ Series community includes new homes ranging from ~1,800 to 2,776 square feet.", "");
		
		String[] sqft = U.getSqareFeet( comHtml.replace("25,000 square feet of resort", "") + commSec,
				"(\\d,)?\\d{3}-\\d,\\d{3} Sq. Ft|from \\d,\\d{3} to \\d,\\d{3}( |&nbsp;)square feet|from ~\\d,\\d{3}( |&nbsp;)to( |&nbsp;)~\\d,\\d{3} square|<span>\\s+\\d,\\d{3}\\s+</span>\\s+Sq. Ft.| approx. \\d+-\\d,\\d+ sq. ft|\\d,\\d{3} to ~\\d,\\d{3} square feet|\\d{1},\\d{3} sq. ft. – \\d{1},\\d{3} sq. ft. |\\d{4} to ~\\d{4} square feet|\\d{1},\\d{3} - \\d{1},\\d{3} sq. ft.|\\d,\\d+-\\d,\\d+ Square Feet|approx. \\d,\\d+- \\d,\\d+ sq ft.|\\d,\\d+- \\d,\\d+ sq ft|\\d,\\d+- \\d,\\d+ square feet|\\d,\\d+\\-\\d,\\d+ Sq. Ft.|approx.\\d+,\\d+\\- \\d,\\d+ square feet.|\\d,\\d+</span> Sq. Ft.|from \\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}\\+ sq ft|\\d,\\d+ to \\d,\\d+ sq. ft.|\\d,\\d{3} Sq. Ft.|\\d,\\d+ to \\d,\\d+ square feet|\\d,\\d{3} Square Feet|\\d,\\d{3}\\s?-\\s?\\d,\\d{3} Square Feet|\\d,\\d{3}</span> Sq. Ft|\\d,\\d+ Sq. Ft",
				0);
		
		minSqf = (sqft[0] != null) ? sqft[0] : ALLOW_BLANK;
		maxSqf = (sqft[1] != null) ? sqft[1] : ALLOW_BLANK;
		
		if(commUrl.contains("https://www.sheahomes.com/new-homes/california/bay-area/brentwood/vista-dorado")) {
			minSqf = "3264";}
		
		U.log("minSqf :" + minSqf + " maxSqf :" + maxSqf);
		//U.log("MMMMMMM "+Util.matchAll(comHtml+commSec , "1800", 0));

		// =======================================================================================
		comHtml=comHtml.replace("Farmhouse, Traditional, and Prairie", "Farmhouse homes , Traditional, and Prairie")
				.replace("single-level floorplans&nbsp;with&nbsp;a custom", "single-level floorplans with a custom features").replaceAll("traditional garages", "").replace("Homeowners Association (HOA) Overview", "")
				.replace("Traditional Brownstone/Contemporary design", "Poplar Traditional").replace(",&nbsp;lofts,", ", lofts,").replace("-style&nbsp;", "-style ")
				.replaceAll("alt=\"Shea Homes Condo|-a-condo|>Buying a Condo", "").replace("Craftsman-style&nbsp;new&nbsp;homes", "Craftsman-style new homes");
		
		if(commSec!=null)
		commSec = commSec.replace("\"Community Sports Fields\",\"Loft", ", lofts,");
		
		String homeSection = U.getSectionValue(comHtml, "<section id=\"home-plans\" ", "</section>");
		String homeFeature = ALLOW_BLANK;
		if(homeSection!=null) {
			String[] urls = U.getValues(homeSection, "<a href=\"/new-homes/", "\"");
			
			for(String url : urls) {
				if(url.contains("#site-map"))continue;
				url = "https://www.sheahomes.com/new-homes/"+url;
			
				U.log(">>>>>>"+url);
				String homes = U.getHTML(url);
				//U.log(U.getCache(url));
				if(homes.contains("<div class=\"media-captions text-right\">")) {
					String homeName = U.getSectionValue(homes, "<div class=\"media-captions text-right\">", "</div>");
					homeFeature+= homeName + U.getSectionValue(homes, "<section id=\"home-plan-features", "</section>");
				}
				else
					homeFeature += U.getSectionValue(homes, "<section id=\"home-plan-features", "</section>");
			}
		}
		
		homeFeature = homeFeature.replaceAll("Exterior C: Craftsman &nbsp|Contemporary Craftsman", "Craftsman Style Homes");
		comHtml=comHtml.replace("Rancho Mission Viejo", "");
		
		String rem11=U.getSectionValue(comHtml, "<div class=\"testimonial-slide\">", "<!-- end card bottom -->");
		if(rem11!=null) {
			comHtml=comHtml.replace(rem11, "");
		}
		
		
		String pType = U.getPropType((comHtml + commSec + homeFeature).replace("American Traditional, French Countryside", "American Traditional exterior, French Countryside")
				.replaceAll("single-family.png|Rancho Mission|6020 Patio|Patio.jpg|a 2-car traditional|_patio_|_Patio_|alt=\"\\d-plex\"|alt=\"\\d-Plex\"|condos|condos-|condos-townhomes|farmhouse sink|carinovillas|Duplex_|Village|vilage|Villa Lindo|_Craftsman", "")
				.replace("old-world manor", "The Manors home"));
//		U.log("=====" + Util.matchAll(homeFeature,"[\\w\\s\\W]{100}farmhouse[\\w\\s\\W]{100}", 0));
//		U.log("=====" + Util.matchAll(comHtml ,"[\\w\\s\\W]{100}farmhouse[\\w\\s\\W]{100}", 0));
//		U.log("=====" + Util.matchAll(commSec,"[\\w\\s\\W]{100}farmhouse[\\w\\s\\W]{100}", 0));
		


		comHtml=comHtml.replaceAll(">Home Levels:</span> <span>(\\d)</span></p>", "> $1 Story </p>")
				.replace("<span>2 Story</span>", " Story 2 ").replaceAll("three-and four-story|three- and four-story", " 3 Story  4 Story  ").replace(" two and three-story", "two story , three-story")
				.replace("Alamar, a master planned community within the beautiful Sonoran Desert", "");
		
		commSec=commSec.replace("StoriesMin\":1", " 1 Story ").replace("StoriesMax\":2", " Story 2 ").replace("\"CommunityTypes\":[\"Master Plan Communities\"]", "");
		
		String dType = U.getdCommType((comHtml + commSec + homeFeature).replaceAll("alt=\"exterior image of a 3 story home|Story 2 ,\"BedroomsMin\":0,\"BedroomsMax|Trilogy Story|alt=\"Rome Exterior E Colonial Craftsman|Ranch Water", ""));
		U.log("DType :"+dType);
//		U.log("=====" + Util.matchAll(comHtml ,"[\\w\\s\\W]{100}multi-level[\\w\\s\\W]{100}", 0));
//		U.log("=====" + Util.matchAll(commSec ,"[\\w\\s\\W]{100}multi-level[\\w\\s\\W]{100}", 0));
//		U.log("=====" + Util.matchAll(homeFeature ,"[\\w\\s\\W]{100}multi-level[\\w\\s\\W]{100}", 0));

		String comType = U.getCommunityType((comHtml + commSec).replace("=\"master-plan-|CommunityTypes\":[\"Master Plan Communities", "").replace("CommunityTypes\":[\"Resort Style\"]", "")
				.replaceAll("guard-gated enclave|Frederick is Trilogy's first resort|Open!\",\"Lat\":\"33.6713675\"|Outdoor Resort Pool|outdoor  resort-style  pool|Best Master-Planned Communities|Gated Entry|Encanterra Country Club|Master planned golf course community|Master Down|Resort-style living is here|master-plan-second", ""));
		
		
		comHtml=comHtml.replaceAll("unite-grand-opening|Excite - Grand Opening!|Court \\(Now Open!\\)|Grand Opening two gorgeous New |Model\\u0027s Now Open|Grand Opening pricing|Grand Opening 7 New Models|VIRTUAL GRAND OPENING|GRAND OPENING 7 NEW| Tour Brand New Floorplans Now Selling at Trilogy|Final Opportunities in Vintage village|We only have a few opportunities |>SOLD OUT!&nbsp;</div>|excite-grand-opening|Unite - Grand Openi|GRAND OPENING A NEW MODEL HOME|Grand Opening a New|home-grand-opening/|Grand Opening New Model Home|details on the final home available|Barcelona Model Homes Grand Opening|new homes available at|New Homesites Available at|flats coming soon|Carlsbad Coming Soon|\\(Coming Soon!\\)|New Models Grand Opening|Grand Opening of New Model Homes|Outlook Club Grand Opening Celebration|>Grand Opening 10 New Models|Club Grand Opening|spa coming soon|Pricing Coming Soon|trails are coming soon|retail center are now open|<p>\\s+Coming soon to Esencia|Dog Park is now open|Sports Park is coming soon|playground are coming soon|limited opportunity to own one of these desirable open-concept homes|Two Homes Left - Call For Info|<meta name=\"description\" content=\".*\"|t=\"New Homes in La Habra! Now selling|ontent=\"Shea Homes has move-in ready|<h4>Now Selling at|Shea Urban Grand Opening Event|Resort Club coming soon|small\">Quick Move-In </p>|Pricing Coming Soon|Coming Soon to Highland Park|"
				+ "Now Open! Visit|Now Open! Inspire, a new Shea3D now open|Visit new homes available|Freedom Collection Grand Opening|see the new homes available|"
				+ "\"Coming Soon", "");

		String remSec=U.getSectionValue(comHtml, "<section class=\"promotions-carousel full-width-carousel\">", "Second slide details.<");
		if (remSec!=null) {
			comHtml=comHtml.replace(remSec, "");
		}
		

		//-----Status------
		String[] replceSec = U.getValues(comHtml, "label status-label", "<");
		if(replceSec != null)
		for(String r : replceSec) {
			
			comHtml = comHtml.replace(r, "");
		}
		//StatusLabel\":\"SOLD OUT\"
		commSec = commSec.replaceAll("Quick Move-In Homes Now Available|QUICK MOVE-IN HOMES NOW AVAILABLE|Info Center Now Open|INFO CENTER NOW OPEN|PriceMinString\":\"Pricing Coming Soon|Pricing Coming Soon|Homes Open by Appointment", "");

		String com = U.getSectionValue(commSec, "\"StatusLabel\":\"", "\",");
		if(com == null) com = "";
		String remove1 = "<a href=\"/move-in-ready/\">Quick Move-ins</a>|ImageAltText\":\"Coming Soon\",\"HasQuickMoveIns\":false|Pricing Coming Soon|before it is SOLD OUT|BEFORE WE ARE SOLD OUT|center are now open|now open for|Final Homes Now Selling&nbsp;</div>|Temporarily Sold Out&nbsp;</div>|the Grand Opening of Azure|COMMUNITY CLOSEOUT MODEL |final opportunities at Habersham|status-label  '>Final Homes Now Sell|Coming Soon - Sign up|Reserves Estates at Eastmark - Coming Soon|Pricing Coming Soon|<div class=\"label status-label  \">SOLD OUT|StatusLabel\":\"SOLD OUT\"|status-label trilogy \">Sold Out&nbsp;</div>|<div class=\"label status-label  \">SOLD OUT&nbsp;</div>|<div class=\"label status-label  \">Final Home Now Selling&nbsp;</div>|Quick Move-In Homes Now Available|QUICK MOVE-IN HOMES NOW AVAILABLE|Info Center Now Open| INFO CENTER NOW OPEN|before it is SOLD OUT| Before We Are SOLD OUT|Visitor Center Now Open|model homes are now open|Model Homes Now Open|PriceMinString\":\"Pricing Coming Soon|Model Homes Just Released For Sale|Just Released 11 Models For Sale|JUST RELEASED FOR SALE|<div class=\"label status-label  \">Coming Soon!&nbsp;</div>|SQUARE COMING SOON|OCEAN PLACE COMING SOON|Pricing Coming Soon|<div class=\"label status-label  \">Sold Out&nbsp;</div>|walkthroughs are now available|APPOINTMENTS NOW AVAILABLE|Pricing Coming Soon|Brentwood Coming|Model Homes Coming|(Appointments|Tours) Now|walkthroughs are now"
				+"|status-label  '>Final Homes Now Selli|<strong>Grand Opening</strong> two gorgeous|Grand Opening New Models Now|and now available |\"Model\\u0027s Now Open!|status-label  '>Final Home Now Availabl|status-label  '>Temporarily Sold Out|&quot;Final Home Now Selling|SOLD OUT&nbsp;</div>|Temporarily Sold Out&nbsp;</div>|Exteriors Just|remaining\\. Call";
		
		String event = U.getSectionValue(comHtml, "<section class=\"whats-happening none", "</section>");
		
		if(event == null) event = "";
		comHtml = comHtml.replace("Now Selling our FINAL PHASE", "Now Selling FINAL PHASE").replace(event, "");
//		commSec =commSec.replace("StatusLabel\":\"Single-Family Homes Now Selling", "");
		String sec = (com + commSec).replace("New Plans - Just Released", "New Plans Just Released").replace("New Homesite Release Coming Soon", "New Homesite Release Coming Soon").replace("Coming Soon\":", "");
		
		comHtml = comHtml.replace("Final Homes at Elan are selling", "Final Homes selling")
//				.replace("Next Homesite Release is Coming Soon", "New Homesite Release Coming Soon")
//				.replace("Pre-Sales Opportunities are Sold Out", "Pre-Sales Opportunities Sold Out")
				.replace("New Phase &amp; Homesites", "New Phase & Homesites").replace("New Homesites - Just Released", "New Homesites Just Released").replace("New Plans - Just Released", "NEW PLANS JUST RELEASED")
				.replaceAll("Model Home Now Selling|Office is now open|Model Grand Opening Coming Soon|Floorplans Just|Coming Soon For Sale|doors are now open|Ball Court \\(Now Open|Spa \\(Now Open|Models Coming Fall 2021|ONLY 7 QUICK MOVE-IN HOMES LEFT|Clubhouse Now Open|just released brand new&nbsp;|just released&nbsp;brand|(Floor Plans|Appointments) Now|model homes are now|Information Just|plan coming|Available Now! </h4>Find your dream|Closed</p>Coming", "")
				.replace("New Homesite Release Coming Soon!&nbsp;</div>", "").replace("New Homesite Release Coming Soon! Join the Interest List", "").replace("New Homesite Release Coming in May", "New Homesite Release Coming May").replace("Now Selling Homesites with Full Driveways", "Now Selling");
		comHtml=comHtml.replace("Coming Soon- Winter 2021", "").replace("Single-Family Homes Now Selling", "")
				.replaceAll("Trilogy Valor- Coming Soon Trailer|Coming soon. Our sales office|With great spaces, coming soon|find it on the Sports Courts, coming soon|Homes for sale coming soon|"
						+ "Coming soon, take your fitness goals|>Quick Move-Ins</a></li>|move-ins\">Quick Move-ins available|>View quick move-in</a>|Available Quick Move-In Homes</h2|"
						+ "Preserve Coming Soon</h4><p>|>New Homesite Release Coming Soon!&nbsp;</div>|New Homesite Release!</h2>", "")
				.replace("GRAND OPENING A BRAND NEW PHASE", "GRAND OPENING NEW PHASE")
				.replaceAll(">PLAN 2201 HOMES AVAILABLE NOW</h4><p>We currently have two Plan 2201 homes available. We expect to have more Plan 2201 homes|Beach House at The Dunes</p><h2>New Homesites Coming May 14th", "")
				.replace("Quick Move-ins", "Quick Move-ins Available");
		sec=sec.replace("Coming Soon- Winter 2021", "").replace("Closing Out\"", "");//.replace("Single-Family Homes Now Selling", "").replace("Homes Now Selling", "")
		
//		U.log("=====" + Util.matchAll(comHtml ,"[\\w\\s\\W]{100}final home[\\w\\s\\W]{100}", 0));
//		U.log("=====" + Util.matchAll(sec ,"[\\w\\s\\W]{20}final few [\\w\\s\\W]{100}", 0));

		
		
String pStatus = U.getPropStatus((sec +comHtml).replaceAll("Quick Move-In|Coming Soon to Black Diamond|Right now we are Grand Opening a Brand New Phase and we've just released|Trilogy Valor- Coming Soon|Coming soon. Our sales office is not open|Coming soon, take your fitness goals to t, find it on the Sports Courts, coming soon. Pickleball, Bocce, a Fitness, t Trilogy! With great spaces, coming soon, like the Lakeside Ledge and|Homes for sale coming soon", "")
				.replaceAll("We just released a limited number of brand new, premium homesites at Trilogy", "")
				.replaceAll("We are currently sold out of new build homes|Sold Out Until April 1st Homesite Release|New Langston homesites coming March 19th|including plans for our GRAND OPENING|<p class=\"lotmap-cnt-label lotmap-cnt-label-unavailable p-small\">Sold</p>|Sold Out Until March 19th Release|quick move-in homes|<h4>Quick Move-In Homes</h4>|Quick Move-ins Available</a></li>|Quick Move-In Homes</h2>|Models Coming 2022|\\:\"Closing Out\"|MODELS NOT YET OPEN! - Planned opening Spring 2022|AFTER HOURS TOURS NOW AVAILABLE|<div class=\"label status-label(.*)?</div>|GRAND OPENING 8 NEW MODELS|about is coming soon|Grand Opening New Models|Grand Opening 8 New Models|Models Opening Early 2022|Models Open Early 2022|Release Coming Soon|Model Sale Coming Soon|Jaxon's Cove Now Open|Pricing Coming Soon|New Home Release Coming Soon| Cove, now open|Models Opening|YET OPEN - Planned Opening|Sales Opportunities are Sold|Move-in Homes Available|\"Homesites Coming|Homesite Release is Coming|Grand Opening 2 New Floorplans|construction homes coming soon|iAdditionalHoursInfo\">Coming Soon|Pricing Coming Soon|Models Coming Fall 2021|Homes for sale coming soon|oursInfo\">Coming soon.| is-active\">Trilogy Valor- Coming |Before we are SOLD|Pricing Coming Soon|Only 7 QUICK MOVE-IN H|just released brand new&nbsp;|just released&nbsp;brand|coastal community coming in 2021|Model is availabe and ready to move|Center Now Open|CENTER NOW OPEN|Now Open -&nbsp;&nbsp;<a href|Shea Homes Barcelona</a>, Coming Soon|Spa \\(Coming|Coming Soon - Bay Area|Grand Opening New Clubhouse Now|New Clubhouse Grand Opening|Grand Opening Soon of The Maple Club|Grand Opening New Model|Grand Opening of The Maple Club- Coming Soon|Clubhouse \\(Coming Soon|status-label trilogy '>Available Lots Coming Soon|Grand Opening&nbsp;Coming Soon of the Maple Club|Grand Opening Coming Soon of the Maple Club|Left - Schedule|2 Homes Remaining. Sales |before it is SOLD OUT|Grand Opening New Models| Grand Opening 2 New |open and <strong>Grand Opening</strong>| Now Open!\"|rilogy plan coming soon|/coming-soon-tril.jpg| Clubhouse \\(Coming Soon!\\)|Models [g|G]rand [o|O]pening|Grand Opening Now - Two New Field Model|Club Grand Opening|Grand Opening Now &ndash; Newly Outfitted Model|Grand Opening Now – Newly Outfitted Model|GRAND OPENING NOW – NEW MODEL|Grand Opening Now - New Model|<div class=\"info-list\">\n\\s*Coming Soon|Pricing Coming|Closing Out! Sales office|before we're SOLD|Leaseback Opportunity Now|Artisan Studio Grand|ARTISAN STUDIO GRAND|Grand Opening Celebration of our Artisan|Grand Opening Celebration of the New Artisan|scroll\" data-t=\"2r4o1j-t\">Quick Move|href=\"/move-in-ready/\">Quick Move|scroll=\"\">Quick Move-In|events/alc-twr-go/\">Grand Opening Now!</a>|Club Grand Opening|Grand Opening events|Grand Opening Now – Newly|Grand Opening Now &ndash; Newly|Grand Opening Now - Five|Grand Opening \\d+ New Model|Square Grand Opening|class='label status-label  '>Grand Opening|Model Grand Opening|Model Home Grand Opening Celebration", "").replaceAll(remove1, "")); 

//		U.log("match=====" + Util.matchAll(sec +comHtml,"[\\w\\s\\W]{100}Coming Soon[\\w\\s\\W]{100}", 0));
			
		//U.log("sec "+sec);
		U.log("pStatus "+pStatus);

		pStatus = pStatus.replace("Coming Spring 2021, New Homesite Release Coming Spring 2021", "New Homesite Release Coming Spring 2021").replace("Grand Opening Soon, Opening Soon,","Grand Opening Soon,").replace("Coming Soon, New Homesite Release Coming Soon", "New Homesite Release Coming Soon");
		
		if(comHtml.contains("no quick move-in homes available")) {
			pStatus=pStatus.replaceAll("Quick Move-in Homes|Quick Move-in", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");// "No Quick Move-in Homes");
		}
		comHtml= comHtml.replace("Shea Homes Sunterra 50&#39; is preselling now", "Shea Homes Sunterra 50&#39; is Now Pre-Selling").replaceAll(" PRE-SALES/SALES WILL BE HANDLED VIA THE|Virtual Pre-Sales Opportunities|"
				+ "Pre-Selling from Acclaim at Alamar", "");
		
		String note = U.getnote((comHtml+commSec).replace(" Pre-Sales Opportunities Coming Soon", " Pre-Sales Coming Soon").replaceAll("\"StatusLabel\":\"Virtual Pre-Sales\"|Virtual Pre-Sales Opportunities|Virtual Pre-Sales|Pre-Sales \"The|\"Pre-Sales|Model Homes Just Released For Sale|Pre-Sales Anticipated", ""));
		U.log("note "+note);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{50}Pre-Sales[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commSec, "[\\s\\w\\W]{50}Pre-Sales[\\s\\w\\W]{30}", 0));

		// ===============================================================================================
		
		
	
		int  q=0;
//		U.log("quickSec==="+quickSec);
		if(quickSec!=null) {
		String[] quickHomes=U.getValues(quickSec, "<div class=\"card home-card\">", "View quick move-in");
		U.log("quickHomes=="+quickHomes.length);
		if(quickSec!=null) {
		if(quickSec.contains("There are currently no quick move-in homes available at this community")) {
			pStatus=pStatus.replace("Quick Move-ins Available", "");
		}
		else 
		{
			for(String quickHome:quickHomes) 
			{
				if(!quickHome.contains("<div class=\"label status-label \">") ||
						quickHome.contains("<div class=\"label status-label \">\n" + 
								"        Immediate Move-In")) {
					q++;
				}
			}
			
		}
		}
		}
		if(q>0) {
		if(!pStatus.contains("Quick Move-in")) {
			if(pStatus.length()>2) {
				pStatus=pStatus+ ", Quick Move-ins Available";
			}
			else {
				pStatus="Quick Move-ins Available";
			}
				
		}
		}
		
		if(add[1].contains("Charlotte") && add[2]==null)add[2]="NC";
		
		if (commUrl.contains("/charlotte-area/denver/killian-s-pointe-vintage"))pStatus = pStatus + ", Final Opportunities";
		if (commUrl.contains("https://www.sheahomes.com/new-homes/virginia/northern-virginia/lake-frederick/trilogy-at-lake-frederick"))comType = comType.replace("Resort Style,", "");
		if(pStatus.endsWith("Quick Move-in")) pStatus = pStatus.replace("Quick Move-in", "Quick Move-in Homes"); 
		if (commUrl.contains("https://www.sheahomes.com/new-homes/california/central-coast/orcutt/rice-ranch"))pType = pType + ", Patio Homes, Single Family, Detached Home";
		if(commUrl.contains("https://www.sheahomes.com/new-homes/california/bay-area/tracy/vente-at-tracy-hills"))pType = pType + ", Multi-Gen Homes";
		if (commUrl.contains("https://www.sheahomes.com/new-homes/washington/seattle-area/maple-valley/meadowridge-at-maple-centre"))pStatus = pStatus.replace("Grand Opening,", "");
		if (commUrl.contains("https://www.sheahomes.com/new-homes/north-carolina/charlotte-area/denver/killian-s-pointe-traditions"))pStatus = pStatus.replace(", Now Available", "");;
		
		if (commUrl.contains("new-homes/idaho/boise-area/kuna/trilogy-valor"))pStatus = "New Homesites Just Released, Grand Opening Coming Soon, Quick Move-ins Available";
		if (commUrl.contains("new-homes/florida/central-florida/ocala/ocala-preserve"))pStatus = "Grand Opening New Phase";

			if (commUrl.contains("https://www.sheahomes.com/new-homes/arizona/phoenix-area/queen-creek/encanterra-a-trilogy-resort-community"))pStatus = "Premium Homesites Available";

		if (commUrl.contains("https://www.sheahomes.com/new-homes/north-carolina/charlotte-area/concord/lantana"))pType += ", Craftsman Style Homes";
		if (commUrl.contains("https://www.sheahomes.com/new-homes/california/san-diego-area/san-diego/asana-at-3-roots"))pType += ", Loft";
		if(commUrl.contains("new-homes/nevada/las-vegas-area/las-vegas/trilogy-in-summerlin")) {
			
			dType=dType.replaceAll(", 3 Story|, Multi-Level", "");
		}
		
		if(pStatus.contains("Grand Opening, Quick Move-in Homes, Grand Opening New Phase"))pStatus = "Grand Opening New Phase, Quick Move-in Homes";
		
		if(pStatus.contains("Grand Opening New Phase") && pStatus.contains(", Opening New Phase"))
			pStatus = pStatus.replaceAll(", Opening New Phase", "");
		
		if(pType.contains("Townhouse") && pType.contains("Townhome")){
			pType = pType.replaceAll("Townhouse,|Townhouse", "");
		}
		pStatus = pStatus.replace("Quick Move-in,", "Quick Move-ins Available,").replace("Quick Move-in Homes", "Quick Move-ins Available").replace("Grand Opening, Quick Move-ins Available, Grand Opening New Phase", "Quick Move-ins Available, Grand Opening New Phase");
		if(pStatus.length() < 5) pStatus =  ALLOW_BLANK;
		
		pStatus = pStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		if(commUrl.contains("https://www.sheahomes.com/new-homes/california/central-coast/nipomo/trilogy-at-monarch-dunes"))pStatus="New Homesite Release Coming Soon";
	
//		if (commUrl.contains("https://www.sheahomes.com/new-homes/washington/seattle-area/bonney-lake/trilogy-at-tehaleh"))pStatus="currently sold out";
		if (pStatus.contains("Opening New Phase, Grand Opening"))pStatus=pStatus.replace("Opening New Phase, Grand Opening", "Grand Opening New Phase");

		if(commUrl.contains("/houston-area/katy/cane-island"))pType=pType.replace("Loft, ", "");
		
//		============================== Lot Data======================
		
		String part_keySec=U.getSectionValue(comHtml, "title=\"Community Lot Map\"", "</iframe>");
		U.log("part_keySec=="+part_keySec);
		String part_key=U.getSectionValue(comHtml, "OLAId=", "\"");
		U.log("part_key=="+part_key);
		String lotHtml=U.getPageSource("https://apps.alpha-vision.com/olajson/"+part_key+".json?_=");
//		U.log("lotHtml>>>>>>>>>>>>"+"https://apps.alpha-vision.com/olajson/"+part_key+".json?");
//		U.log(">>>>>>>>>>>>"+Util.matchAll(lotHtml, "[\\s\\w\\W]{30}LotCount[\\s\\w\\W]{30}", 0));
		String lotCount=U.getSectionValue(lotHtml, "\"LotCount\":", ",");
		U.log("lotCount=="+lotCount);
		if(part_key==null) {
			lotCount=ALLOW_BLANK;
		}
		
		data.addCommunity(communityName.replaceAll("Resort Community|shea at|®|™", "").trim(), commUrl, comType);
		data.addAddress(add[0].replaceAll("Barcelona|amp;", "").replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLon[0].trim(), latLon[1].trim(), flag);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replace("Ii", "II"));
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(lotCount);
		}j++;
		
//	}catch (Exception e) {}
		
	}

	private String[] getAddress(String line) {
		String[] ad = line.split(",");

		String[] add = new String[] { "-", "-", "-", "-" };
		int n = ad.length;
		//U.log("ad length is ::"+ad.length);
		if (ad.length >= 3) {
			for (int i = 0; i < n - 2; i++)
				add[0] = (i == 0) ? ad[i].trim() : add[0] + ", " + ad[i].trim();
			add[0] = add[0].trim().replaceAll("\\d+.\\d+\\s*,\\s*-\\d+.\\d+",
					"");
			add[1] = ad[n - 2].trim();// city
			add[2] = Util.match(ad[n - 1], "\\w+", 0); // State--or-->\\w+ OR
														// [a-z\\sa-z]+
			add[2] = (add[2] == null) ? "-" : add[2].toUpperCase();
			if (add[2] == null)
				add[2] = "-";
			if (add[2].length() > 2)
				add[2] = USStates.abbr(add[2]);
			add[3] = Util.match(ad[n - 1], "\\d{5}", 0);
			if (add[3] == null)
				add[3] = "-";
		}
		for (int i = 0; i < 1; i++) {
			if (!add[i].equals("-") && add[i].length() < 3)
				add[i] = "-";
		}

		return add;
	}


	public String getHomesData(String html) {
		String comHtml = html;
		String sec = U.getSectionValue(comHtml, "<div class=\"plans\">", "<div class=\"news\">");
		// U.log("sec::"+sec);
		String homeData = ALLOW_BLANK;
		if (sec != null) {

			String[] homeUrls = U.getValues(sec, "<div class=\"col1\">", "<img src=");

			for (String homeUrl : homeUrls) {
				homeUrl = U.getSectionValue(homeUrl, "<a href=\"", "\"");
				U.log("homeUrl :: " + homeUrl);
				try {
					String homeHtml = U.getPageSource(homeUrl);
					homeData = U.getSectionValue(homeHtml, "movein_features", "</div>") + homeData + " ";

				} catch (Exception e) {
					U.log(e.toString());
				}
				if (homeData != null) {
					homeData = homeData.replace("luxurious master bath", "");
					homeData = homeData.replace("second-floor covered", "2 Story");
				}
			}
		}
		// U.log("homeData:::"+homeData);

		return homeData;
	}

	// ======================================================================================================

	public static String getHtml(String url, WebDriver driver) throws Exception {
		//driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();

		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.get(url);
					U.log("after::::"+url);
					Thread.sleep(50000);
//					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
//					Thread.sleep(2000);
					// U.log("Current URL:::" + driver.getCurrentUrl());

					html = driver.getPageSource();

					/*if (html.contains("p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore")) {
						WebDriverWait wait = new WebDriverWait(driver, 40);
						wait.until(ExpectedConditions.elementToBeClickable(
								By.xpath("//*[@id=\"p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore\"]")));
						WebElement click = driver.findElement(
								By.xpath("//*[@id=\"p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore\"]"));
						click.click();
						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
						html = driver.getPageSource();
					}
					Thread.sleep(5000);*/
					/*if (html.contains("p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore")) {
						WebDriverWait wait = new WebDriverWait(driver, 40);
						wait.until(ExpectedConditions.elementToBeClickable(
								By.xpath("//*[@id=\"p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore\"]")));
						WebElement click = driver.findElement(
								By.xpath("//*[@id=\"p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore\"]"));
						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
						html = driver.getPageSource();
					}*/
					//Thread.sleep(5000);
					/*if (html.contains("p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore")) {
						WebDriverWait wait = new WebDriverWait(driver, 40);
						wait.until(ExpectedConditions.elementToBeClickable(
								By.xpath("//*[@id=\"p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore\"]")));
						WebElement click = driver.findElement(
								By.xpath("//*[@id=\"p_lt_ctl03_pageplaceholder_p_lt_ctl06_QMIHomes_btnViewMore\"]"));
						click.click();
						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
						html = driver.getPageSource();
					}
					Thread.sleep(5000);*/
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}