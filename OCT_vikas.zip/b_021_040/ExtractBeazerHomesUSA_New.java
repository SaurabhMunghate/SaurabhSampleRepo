/**
@author: Priti Chaulkar
@Date : Feb 2018
 */
package com.shatam.b_021_040;

/*
sagar
*/
import java.util.ArrayList;
import java.util.Arrays;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBeazerHomesUSA_New extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i=0;
	final static String BASEURL="https://www.beazer.com/";
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractBeazerHomesUSA_New();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Beazer Homes USA.csv", a.data().printAll());
	}
	public ExtractBeazerHomesUSA_New() throws Exception {
		super("Beazer Homes USA", BASEURL);
		
		LOGGER = new CommunityLogger("Beazer Homes USA");
	}
	ArrayList<String> cityUrlsSec = new ArrayList<String>();
	public void innerProcess() throws Exception {
		String reghtml =U.getHTML("https://www.beazer.com/site-map");
		String regUrlSec = U.getSectionValue(reghtml, ">Favorites</a></li>", "<footer >");
//		cityUrlsSec=Util.matchAll(regUrlSec, "<li><a href=\"/(.*?)\">(.*?) Homes</a></li>",1);
//		U.log(">>>>>"+regUrlSec.length());
		String cityurls[]=U.getValues(regUrlSec, "<li><a href=\"/search", "\">");
		
		for(String cityUrl:cityurls) {
			cityUrl=BASEURL+"/search"+cityUrl;
//			U.log(">>>>>>>>>>"+cityUrl);
			String cityHtml = U.getHTML(cityUrl);
			String comSection[] = U.getValues(cityHtml, "{\"@context\":\"https://schema.org\",\"@type\":\"ListItem\",\"item\":{\"@type\":\"Place\"", "telephone\":\"");
			for(String comSec :comSection) {
				String comUrl = U.getSectionValue(comSec, "\"url\":\"", "\",");
//				U.log(">>>>>>>>>>"+comUrl);
				String comhtml = U.getHTML(comUrl);
				if(comUrl.contains("https://www.beazer.com/indianapolis-in/creekside") || comUrl.contains("https://www.beazer.com/houston-tx/marisol")) continue;
				
				comhtml=U.getSectionValue(comhtml, "</title>", "</main>");
				
				if(comhtml.contains("Explore Plans")) {
				String subSec =U.getSectionValue(comhtml, "<div id=\"homeSeries\" class=\"palegrey padded bzh_views_view\">", "<div id=\"quickMoveIns\"");
				if(subSec!=null) {
					String[] subcommSection =U.getValues(subSec, "class=\"card_list_item", "<div class=\"footer\">");
//					U.log("Subcom length :"+subcommSection.length);
					if(subcommSection.length>0) {
						for(String subComSec:subcommSection) {
							String subComUrl =U.getSectionValue(subComSec, "<h2 class=\"font24 bold OneLinkNoTx\"><a href=\"", "\"");
							subComUrl=BASEURL+subComUrl.replaceAll("^/", "");//   ^/--->starts with
							
//							U.log(">>>>>>>>>>"+subComUrl);
							String subComHtml  = U.getHTML(subComUrl);
							subComHtml=U.getSectionValue(subComHtml,"</title>","</main>");
//							U.log("***********"+subSec);
							String subComSection = U.getSectionValue(subComHtml, "{\"@context\":\"https://schema.org\",\"@type\":\"SingleFamilyResidence\"", "\"telephone\":");
							addDetails(subComSection+subComSec, subComUrl, subComHtml); 
//							break;
						}
					}
				}
				}
				else {
					//U.log("lllll "+comUrl);
					addDetails(comSec, comUrl, comhtml);
				}
			}
		}
		LOGGER.DisposeLogger();
	}
	public void addDetails(String comSec, String comUrl, String comhtml) throws Exception
	{
//		if (!comUrl.contains("https://www.beazer.com/myrtle-beach-sc/bella-vita-gardens"))return;
		
//		if(i>=123 && i<=125) 
		{

		LOGGER.AddCommunityUrl(comUrl);
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl + "*********REPEATED**********");
			return;
		}
		
		//======================================== SINGLE RUN ======================================================================================================

//		if (!comUrl.contains("https://www.beazer.com/houston-tx/the-highlands")) return;// redirecting to region page
		
		U.log(U.getCache(comUrl));
		U.log("Count :"+i);
//		U.log("subSec==="+comSec);
		U.log("community URL :"+comUrl);
//		if (comUrl.contains("https://www.beazer.com/houston-tx/the-highlands")) {
//		LOGGER.AddCommunityUrl(comUrl + "\t*********Return******\t");
//		return;
//	    }
		comhtml=comhtml.replace("&#39;s", "'s").replace("&#174;", "");
		//comhtml=comhtml.replace(" Farmhouse exterior", "Farmhouse & craftsman style exteriors");
		String comName = U.getSectionValue(comhtml,"<h1 class=\"font40 bold uppercase OneLinkNoTx\">","</h1>");
		comName=comName.replaceAll(", 1-Car Garage| Two-Car Garage", "");
		if(comName.contains("Two-Story")) {
			comName = comName.replace(" Two-Story","");
		}
		if(comName.contains(" Villas")) {
			comName = comName.replace(" Villas","");
		}
		if(comName.equals("Windrose Sevilla at IronWing")) {
			comName = "Windrose Sevilla at Ironwing";
		}
		if(comName.endsWith("Estates")) comName=comName.replace("Estates", "");
		if(comName.endsWith("Ranch")) comName=comName.replace("Ranch", "");
		
		//comName=comName.replaceAll("Long Gate Overlook Two Car Garage", "Long Gate Overlook");
		U.log("commmunity Name:"+comName);
		//======ADDRESS & LAT-LNG==========
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String note=ALLOW_BLANK;

		add[0]=U.getSectionValue(comhtml, "streetAddress\":\"", "\"},");
		U.log(add[0]);
		add[0]=add[0].replace(" On Boggy Creek Road just West of Tindall Acres Road", "On Boggy Creek Road").replace("Court, Unit A", "Court Unit A");
		add[0]=add[0].replace("#447", "");
		add[1]=U.getSectionValue(comhtml, "addressLocality\":\"", "\",");
		add[2]=U.getSectionValue(comhtml, "addressRegion\":\"", "\",");
		if(add[2]==null)
		add[2]=U.getSectionValue(comhtml, "addressCountry\":\"", "\",");
		add[3]=U.getSectionValue(comhtml, "postalCode\":\"", "\",");
		U.log(Arrays.toString(add));

		
		latlng[0] = U.getSectionValue(comhtml,"data-map-latitude=\"","\""); 
		latlng[1] = U.getSectionValue(comhtml,"data-map-longitude=\"","\"");
		U.log(Arrays.toString(latlng));
		//========AVAILABLE HOMES=========
		String homehtml="";
		String homePlansData="";
		if(comhtml.contains("View Plan")) {
				String avaHomeSec =U.getSectionValue(comhtml, "<div id=\"homeDesigns\" class=\"no-padding\">", "<div class=\"card_list_index\"><span>");
				String[] avaHomes = U.getValues(avaHomeSec, "<h2 class=\"font24 bold\">", "View Plan</a>");
				for(String avaHome:avaHomes) {
					String homeurl=U.getSectionValue(avaHome, "<a href=\"/", "\"");
					homeurl=BASEURL+homeurl;
					U.log("homeurl==="+homeurl);
					homehtml =U.getHTML(homeurl);
					if(homehtml!=null)
					homePlansData +=U.getSectionValue(homehtml, "OVERVIEW</p>", "<div class=\"background-image margin-xlarge\"><");
	
				}
		}
		
		int q=0;
//		String qhome[]=U.getValues(comHtml, "<div class=\"HomeDesignSummary--qmi","View Home");
//		for(String hData:qhome) 
//		{	
//		if(hData.contains("Available</span>\n" + 
//				"					<b class=\"bold uppercase\">Jul"))
//		{
//			q++;
//		}
//		}
//		U.log("&&&&&&&&&&   "+q);
		
		//=========Quick MOVE-IN==========
		String QuickhomeSec=U.getSectionValue(comhtml, "<div id=\"quickMoveIns\" class=\"no-padding\">", "</section>");
//		U.log("QuickhomeSec=====   "+QuickhomeSec);

		String quickhtml="";
		String quickhtmldata="";
		if(QuickhomeSec!=null) {
		String[] QuickHomes=U.getValues(QuickhomeSec, "class=\"info\"", "View Home</a>");
		for(String quickhome:QuickHomes) 
		{
			quickhome=quickhome.replaceAll("Available</div>\n" + 
					"                <b class=\"bold block uppercase\">", "Available ");
			String quickUrl=U.getSectionValue(quickhome, "<h2 class=\"font24 bold\"><a href=\"/", "\"");
//			U.log("quickhome=====   "+quickhome);
			quickUrl=BASEURL+quickUrl;
			U.log(quickUrl);
			quickhtml =U.getHTML(quickUrl);
			if(quickhtml!=null)
				quickhtmldata +=U.getSectionValue(quickhtml, "OVERVIEW</p>", "<div class=\"background-image margin-xlarge\"><");
//			quickhtmldata=quickhtmldata+quickhome;
			
			if(quickhome.contains("<div class=\"light\">Available Now</b>") || quickhome.contains("<div class=\"light\">Available Oct</b>"))
			{
				q++;
			}
		}
		}
		U.log("count=====   "+q);
		//================ PRICES ==============
		comhtml=comhtml.replaceAll("0s|0's", "0,000");
		String minPrice =ALLOW_BLANK, maxPrice =ALLOW_BLANK;
		comhtml=comhtml.replace("0s", "0,000").replace(" - ", " - ");
		
		String [] price = U.getPrices(homePlansData+comhtml+comSec+quickhtmldata, 
				"Low \\$\\d{3},\\d{3}|mid-\\$\\d{3},\\d{3}</div>|Starting from High \\$\\d{3},\\d{3}|margin-large\">\\$\\d{3},\\d{3}</div>|Starting from the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}</p>|From \\$\\d,\\d{3},\\d{3}|from \\$\\d{3},\\d{3}</div>|Starting from Low \\$\\d{3}\\d{3}"
				+ "from Low \\$\\d{3},\\d{3}|from the high \\$\\d{3},\\d{3}|from the mid \\$\\d{3},\\d{3}|from mid \\$\\d{3},\\d{3} to mid \\$\\d{3},\\d{3}|Starting from Mid\\s+\\$\\d{3},\\d{3}|from upper \\$\\d{3},\\d{3}", 0);
		
		minPrice = (price[0]==null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1]==null) ? ALLOW_BLANK : price[1];
//		U.log("ooooooooooooo "+Util.matchAll(homePlansData+comhtml+comSec+quickhtmldata  , "[\\s\\w\\W]{200}\\$400[\\s\\w\\W]{200}", 0));

		U.log("min price==="+minPrice + " ::maxprice== "+ maxPrice);
		//========SQ.FT========
		String minsq =ALLOW_BLANK, maxsq =ALLOW_BLANK;
		comhtml = comhtml.replaceAll("<span class='lbl'>Sq. Ft.", "Sq. Ft.");
		homePlansData=homePlansData.replace("&nbsp;", "").replace(" - ", " - ");
		
		String [] sqft = U.getSqareFeet((homePlansData+comhtml+comSec+quickhtmldata), "\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|\"sqft\">\\d,\\d{3} Sq. Ft.</span>|</span>\\d,\\d{3} - \\d,\\d{3} Sq. Ft.</span>|</span>\\d,\\d{3} - \\d,\\d{3} Sq. Ft.</li>|</span>\\d,\\d{3} - \\d,\\d{3} Sq. Ft.</div>|\\d2,\\d{3} Sq. Ft.</div>|</span>\\d,\\d{3}|\\d,\\d{3} Sq Ft\"", 0);
		minsq = (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
		maxsq = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
//		U.log("MMMMMMM "+Util.matchAll(comhtml  , "[\\s\\w\\W]{200}Starting from the[\\s\\w\\W]{200}", 0));

		U.log("minsq: "+minsq+" maxsq: "+ maxsq);
		//============== Derived Community Type ====================
		comhtml=U.removeSectionValue(comhtml, "{\"@context\":\"https://schema.org\",\"@type\":\"SingleFamilyResidence\"", "</script>");
		comhtml = comhtml.replace("charming lake-side community offering", "charming lakeside community offering")
				.replaceAll("&amp; Country Club|panish Ranchos|Cypress Ranch|townhomes coming Fall 2022|-ranchos-way|rancho|Rancho|Brookstone Golf and Country Club|Pinetree Country Club|Canyon Crest Country Club|&amp; Country Club|Rivertowne Country Club|Dunes West Golf and Country Club|Forest Country Club|The Golf Club|Brook Golf Club|Cascata Golf Course|Valley Golf Course|Belle Meade Country Club| Houston National Golf Course|Blackhorse Ranch Golf Club|Park Golf Course|Hills Golf Club|National Golf Course", "");
		comhtml = comhtml.replaceAll("Waterfront, green space, and cul-de-sac", "waterfront lifestyle, green space, and cul-de-sac");
		comhtml=comhtml.replace("Farmhouse-style exteriors", "Farmhouse & craftsman style exteriors");
		//
		String ctype = U.getCommunityType(comhtml.replaceAll("Ballard Green [C|c]ommunity|Canyon Crest Country Club|Bentwater Yacht &amp; Country Club|any access gate|gated content form|\"Gated\">|icon gated-community|_gated_container\">|elongated glass|Hermitage Golf Course|Falcon Point Golf Club", ""));
		U.log("ctype :: "+ ctype);
		//U.log("ppppppppppp "+Util.matchAll(comhtml  , "[\\s\\w\\W]{30}farmhouse[\\s\\w\\W]{30}", 0));
		//============== Derived Property Type ====================
		quickhtmldata = quickhtmldata.replace("an open kitchen, and a 2nd-level loft", "an open kitchen, and a two-story loft");
		
		String dType = U.getdCommType((homePlansData.replace("single-story", "One Story")+comhtml+quickhtmldata)
				.replaceAll("floor|Floor", "")
				//.replaceAll("Blackhorse Ranch Golf Club|Spanish Ranchos Ways|mortgagecalculatorAnchor", "")
				.replaceAll("exterior rendering of 2-story condos coming soon| Spanish Colonial |SCL - Spanish Colonial|Spanish Colonial A\" class|Valley Ranch|Blackhorse Ranch",""));
		dType=dType.replace("Blackhorse Ranch Golf Club|Spanish Ranchos Ways|mortgagecalculatorAnchor", "");
		//U.log("MMMMMMM "+Util.matchAll(homePlansData  , "[\\s\\w\\W]{200}Ranch[\\s\\w\\W]{200}", 0));

		U.log("dType :: "+ dType);
		//=============== Property Type ==================
		
		String propType = U.getPropType(homePlansData+comhtml.replace("No HOA", "")+quickhtmldata);
		//propType=propType.replace("farmhouse and craftsman", "Farmhouse & craftsman style exteriors");
		
		
		U.log("propType :: "+ propType);
//		
		
		//=============== Property Status =====================
//		comhtml = comhtml.replaceAll(">Coming Soon</span>|Coming Soon</p>|for coming soon|Out Coming Soon\"|Center Coming Soon\"|Park Coming Soon\"|Coming Soon</div>", "")
		comhtml = comhtml.replace("COMING Summer 2022", "Coming Summer 2022")
				.replaceAll("Quick Move-ins|quick move-in", "")
				.replaceAll("\"value\":\"Coming Soon\"},\"number|\"no-margin\">Coming Soon</p>|(image-flag\">|bold\">)COMING SOON</div>|dates, coming|(More Information|home-price\"></span>) Coming|>Coming Soon\\s*</li>|are now open during|for coming soon|right;\">Coming Soon</span>|Out Coming Soon\"|Center Coming Soon\"|Park Coming Soon\"|(The Lookout|The Hangout|Harvest Park)\\s*Coming Soon</div>|>Coming Soon</span>|-flag\">COMING Summer 2022</div>|bold\">COMING Summer 2022</div>|pool sized lots available</li>|quick-move-ins\" rel|\"#quickMoveIns\">|Quick Move-ins 0|in a closed position", "");
//		String pStatus = U.getPropStatus(comhtml.replaceAll("(description\":\"\\*SOLD OUT\\*|container\">\\s*\\*SOLD OUT\\*|description\">\\*SOLD OUT\\*)\\s*Provence has sold its final|<li>We are sold out!</li>|<p>We are sold out at Provence!|no-margin\">Close Out</p>|(image-flag\">|font13 bold\">|)CLOSE OUT</div>|SERIES CLOSING OUT</div>|home-price\"></span>Close Out</li>|(image-flag\">|font13 bold\">)COMING Spring 2022</div>|\"value\":\"Coming Soon\"}|(top\">|bottom\">)NOW SELLING</h3>|<img alt=\"NOW SELLING\"|(horiz-header\">|vert-header\">)Limited Availability</p>", ""));
		String pStatus = U.getPropStatus(((comSec+comhtml)
				.replace("condos coming soon", "")
				.replace("4/12</span>Amenity Center Coming Soon", "").replace("wnstone in New Whiteland, IN- Coming", "")
				.replace("Move", "").replaceAll(" towards closing costs on select Quick Move-Ins|closing costs on select Quick Mov|\">Quick Move-In homes</span>|contracts for quick move-in homes at Gatherings|closing on contracts for Quick Move-in homes |closing costs on Quick Move-in Homes|in Closings Costs on Quick Move-in Homes|<li>Move-in ready homes this summer</li>|on select Quick Move-Ins|on Select Quick Move-in Homes|>Load More Quick Move-ins</button>|Houston-area move-in ready homes signed|Only 1 quick move-in home left|Braxton quick move-in|Crafts L quick move-in|Mediterranean A quick move-in|or quick move-in|Colonial L quick move-in|Tuscan A quick move-in|Morgan quick move-in|on move-in ready homes|on quick move-in |out our quick move-in|More Quick Move-ins|Crafts N quick move-in|possible with our move-in ready Brighton|community pool \\(coming soon\\)</li>|New single-family homes coming this Summer to Mt|icon home-price\"></span>\\s+Coming Soon\\s+</div>|(description\":\"\\*SOLD OUT\\*|container\">\\s*\\*SOLD OUT\\*|description\">\\*SOLD OUT\\*)\\s*Provence has sold its final|<li>We are sold out!</li>|<p>We are sold out at Provence!|(image-flag\">|font13 bold\">)COMING Spring 2022</div>|\"value\":\"Coming Soon\"}|(top\">|bottom\">)NOW SELLING</h3>|<img alt=\"NOW SELLING\"|(horiz-header\">|vert-header\">)Limited Availability</p>", ""))
				.replaceAll("class=\"bzh-icon home-price\"></span>Coming Soon</li>|header\">Limited Availability<|brick-front townhomes coming spring 2022|Woodside Place brick-front townhomes coming spring 2022\" /> |</span>Plano Gateway Townhomes Coming Soon</div>|Coming soon - community clubhouse|Jasper Point coming May 2022|pool and pavilion coming soon|More Information Coming Soon|More information on pricing, plans, amenities and launch dates, coming soon", "").replaceAll("Quick Move|Quick move|quick move|MOVE-IN READY|Move-in Ready", ""));
		pStatus=pStatus.replace("Limited Availability,", "");
		U.log("ppppppppppp "+Util.matchAll(comSec+comhtml  , "[\\s\\w\\W]coming soon{30}[\\s\\w\\W]{30}", 0));

		U.log("pStatus :: "+ pStatus);
		
		U.log("MMMMMMM "+Util.matchAll(comSec+comhtml.replaceAll(" towards closing costs on select Quick Move-Ins|closing costs on select Quick Mov|\">Quick Move-In homes</span>|contracts for quick move-in homes at Gatherings|closing on contracts for Quick Move-in homes |closing costs on Quick Move-in Homes|in Closings Costs on Quick Move-in Homes|<li>Move-in ready homes this summer</li>|on select Quick Move-Ins|on Select Quick Move-in Homes|>Load More Quick Move-ins</button>|Houston-area move-in ready homes signed|Only 1 quick move-in home left|Braxton quick move-in|Crafts L quick move-in|Mediterranean A quick move-in|or quick move-in|Colonial L quick move-in|Tuscan A quick move-in|Morgan quick move-in|on move-in ready homes|on quick move-in |out our quick move-in|More Quick Move-ins|Crafts N quick move-in|possible with our move-in ready Brighton|community pool \\(coming soon\\)</li>|New single-family homes coming this Summer to Mt|icon home-price\"></span>\\s+Coming Soon\\s+</div>|(description\":\"\\*SOLD OUT\\*|container\">\\s*\\*SOLD OUT\\*|description\">\\*SOLD OUT\\*)\\s*Provence has sold its final|<li>We are sold out!</li>|<p>We are sold out at Provence!|(image-flag\">|font13 bold\">)COMING Spring 2022</div>|\"value\":\"Coming Soon\"}|(top\">|bottom\">)NOW SELLING</h3>|<img alt=\"NOW SELLING\"|(horiz-header\">|vert-header\">)Limited Availability</p>", "")  , "[\\s\\w\\W]{50}Quick Move-in[\\s\\w\\W]{30}", 0));

		//------------- Number Of Units -------------------------------------------------------//

		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		if(q>0)
		{
			if(pStatus.length()>3) {
				pStatus=pStatus+", Quick Move-Ins";
			}
			else
			{
				pStatus="Quick Move-Ins";
			}
		}
		
		note=U.getnote(homePlansData+comhtml);
		data.addCommunity(comName, comUrl,ctype);
		data.addAddress(U.getNoHtml(add[0]).trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minsq, maxsq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPropertyType(propType,dType );
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		i++;
	}
		
	}
}
