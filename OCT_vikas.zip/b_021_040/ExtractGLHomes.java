package com.shatam.b_021_040;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGLHomes extends AbstractScrapper {
	public static int j,i=0;

	CommunityLogger LOGGER;
	public int inr = 0;
	WebDriver driver = null;
	public static String mainUrl="https://www.glhomes.com";
	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		AbstractScrapper a = new ExtractGLHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"GL Homes.csv", a.data().printAll());
	}

	public ExtractGLHomes() throws Exception {

		super("GL Homes", "https://www.glhomes.com");
		LOGGER = new CommunityLogger("GL Homes");

	}

	public void innerProcess() throws Exception {
		String comName=ALLOW_BLANK;
//		U.setUpGeckoPath();
//		driver= new FirefoxDriver();;
		HashMap<String,String>  map=new HashMap<String,String>();
	
	
		String mainHtml=U.getHTML("https://www.glhomes.com/");
//		String[] ComSecData=U.getValues(mainHtml,"<span class=\"sub-nav-pull\">Our Communities <i class=\"fa fa-caret-down\">" , "   <li class=\"nav__item\">") ;
		String[] ComSecData=U.getValues(mainHtml,"fa fa-caret-down" , " <li class=\"nav__item\">") ;
		for(String comSec:ComSecData){
			comSec = StringEscapeUtils.unescapeJava(comSec);
			comName=U.getSectionValue(comSec, " <span class=\"sub-nav__main-text\">","</span>");
			map.put(comName, comSec);
			}
		
		
			//Footer communities
			String footerComSec=U.getSectionValue(mainHtml, "OUR COMMUNITIES</h6>", "</nav>");
			String[] ComUrls=U.getValues(footerComSec, "<a ", "a>");
//			U.log(ComUrls.length);
			String url="";
			String namme="";
			String data1 = "";
			for(String cUrl:ComUrls){
				url=(U.getSectionValue(cUrl, "href=\"", "\"")+"/").replace(":443", "");
				url = url.replace("//", "/");
//				U.log(url);
				cUrl=cUrl.replace("<br>", " ");
				/*if(cUrl.contains("wiregrass-ranch")){
					 namme = U.getSectionValue(cUrl, "title=\"", "\"");
				}
				else{
					 namme = U.getSectionValue(cUrl, ">", "<");
				}*/
				namme = U.getSectionValue(cUrl, ">", "<");
//				U.log(url);
				data1 = map.get(namme);
				if(url.contains("http")) {
					getDetails(url,namme,data1);	
				}else {
					getDetails(mainUrl+url,namme,data1);	
				}
			}
			LOGGER.DisposeLogger();
//		driver.close();
	// findAddress("http://www.glhomes.com/marina-bay");
	}

	private void getDetails(String comUrl, String comName,String comData)throws Exception {
		//TODO : For Single Execution
//		if(j == 3)
		{
//			if(!comUrl.contains("https://www.glhomes.com/valencia-walk-at-riverland/"))return;

			U.log("Count =="+j);
		U.log(comUrl);
		//U.log("COMDATA"+comData);
		
		if(data.communityUrlExists(comUrl))	{
			LOGGER.AddCommunityUrl(comUrl+"*********repeated***********");
			j++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
			
		String html=U.getHTML(comUrl);
		
		String statusHtml=U.getHtmlSection(html, "VALENCIA WALK IS A RESOUNDING SUCCESS!</h2", "</p>");
		if(statusHtml==null) {
			statusHtml=ALLOW_BLANK;
		}
		String collectionPrice = U.getSectionValue(html, " <ul class=\"secondary-nav\">", "</ul>");
		
		//--------Find specific community data from the head section
		String headComSec = U.getSectionValue(html, "sub-nav__main-text\">"+comName, "</span>");//StringEscapeUtils.unescapeJava(U.getSectionValue(html, "name\":\""+comName, "}"));
		U.log("headComSec : "+headComSec);
		
		//----------remove common header---------
		html = U.removeSectionValue(html, "<nav class=\"nav-wrapper\">", "</nav>");
	
	
	//=============================Community Url===========================
		
		U.log("commUrl-->"+comUrl);
	
	//=============================Community Name=========================================
		if(comName!=null)
			comName = comName.replaceAll("&#174;", "");
		U.log("ComName-->"+comName);
	
	//<--------nav Section--------->
		
		String mainNavSec = U.getSectionValue(html, "<ul class=\"secondary-nav\">", "</ul>");
		String[] subNavUrls=U.getValues(mainNavSec,"<a","</a>");
		//String hourUrlHtml=ALLOW_BLANK;
		String earlyMoveHtml=ALLOW_BLANK;
		String collectionHtml=ALLOW_BLANK;
		String strandardFreaturesUrlHtml = ALLOW_BLANK;
		String modelForSale=ALLOW_BLANK;
		//String strandardFreaturesUrlHtml=ALLOW_BLANK;
		//String aminitiesUrlHtml=ALLOW_BLANK;
		U.log("length : "+subNavUrls.length);
		for(String nUrl : subNavUrls){
			nUrl  = U.getSectionValue(nUrl, " href=\"", "\"");
//			U.log(nUrl);
			if(nUrl.contains("early-move-in")){
				earlyMoveHtml = U.getHTML("https://www.glhomes.com/"+nUrl);
			}
			if(nUrl.contains("-collection")){
				collectionHtml = U.getHTML("https://www.glhomes.com"+nUrl);
				U.log("Collection:: "+nUrl);
			}
			if(nUrl.contains("lifestyle")){
				strandardFreaturesUrlHtml = U.getHTML("https://www.glhomes.com/"+nUrl);
			}
			if(nUrl.contains("models-for-sale")) {
				modelForSale = U.getHTML("https://www.glhomes.com/"+nUrl);
			}
		}
		


	//=============================Community address=========================================
		
		String note=ALLOW_BLANK;
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
	
		
		String addrSec= U.getSectionValue(html, "Address:", "/a>");
		String addSec=U.getSectionValue(addrSec, "target=\"_blank\">", "<");
		add=U.getAddress(addSec);
		U.log(addSec);
		

		
		
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		U.log(latlag[0]);
	//=============================LatLng=========================================
	
		
		String latSec=U.getSectionValue(html, "data-location=\"","\"");
		if(latSec!=null) {
			latlag=latSec.split(",");
			U.log("latlng secv"+Arrays.toString(latlag));
			geo="FALSE";
		}
		//if(latlag[0] != ALLOW_BLANK || latlag[0] != null){
		if(latlag[0]== ALLOW_BLANK || latlag[0] == null){
			String mapUrlSec = Util.match(U.getSectionValue(html, "Address:</strong>", "</a>"), "@\\d{2}\\.\\d{3,},-\\d{2}.\\d{3,}");
			
			U.log(mapUrlSec);
			if(mapUrlSec == null){
				geo="TRUE"; //latlng doesn't visible on page
			}
		}
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK )
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null)
				latlag = U.getlatlongGoogleApi(add);
			if(latlag == null)
				latlag = U.getNewBingLatLong(add);
			geo="TRUE";
		}
		if((add[0].length()<2 ||add[2]==null)&& latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(add[3]==null && latlag[0]!=ALLOW_BLANK)
		{
			String add1[] = U.getAddressGoogleApi(latlag);
			if(add1 == null) add1 = U.getNewBingAddress(latlag);
			add[3]=add1[3];
			geo="TRUE";
		}
	
		
		
		
		
		U.log("By Geocoding--->"+latlag[0]+"  "+latlag[1]);
		
	
		

		//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String rem=U.getSectionValue(html, "<ul class=\"nav navbar-nav\">"," </li>");
		if(rem!=null) {
			html=html.replace(rem, "");
		}
		rem = U.getSectionValue(html, "<div class=\"block communityprogressblock", "<div class=\"block communitydirectionsblock");
		if(rem != null) html=html.replace(rem, "");
		rem = U.getSectionValue(html, "<div class=\"block communityareamapblock", "<div class=\"block promobannerblock");
		if(rem != null) html=html.replace(rem, "");
		
		
		//U.log(rem);
		html=html.replaceAll("0�s|0's|0s|0k's|0k","0,000").replace("$1 million","$1,000,000").replace("$1M", "$1,000,000")
				.replace("from $1.2M", "from $1,200,000").replace("from $1.7M ", "from $1,700,000");
		html=html.replaceAll("0�s|0's|0s","0,000").replace("from $1.3M", "from $1,300,000").replace("$1.4M", "$1,400,000").replace("second-line heading-size-3\">Coming Soon from the $500", "")
				.replace("only $949,900 with the Huntington", "").replace("from $1.6M", "from $1,600,000").replace("from $1.1M", "from $1,100,000");
		
		if(headComSec!=null)headComSec  = headComSec.replaceAll("00s", "00,000");
		
		earlyMoveHtml = earlyMoveHtml.replaceAll("Was <span class=\"early-move__original-price\">\\$\\d{3},\\d{3}</span>|Was <span class=\"early-move__original-price\">\\$\\d,\\d{3},\\d{3}</span>|<span class=\"early-move__original-price\">Was \\$(\\d,)?\\d{3},\\d{3}</span>", "");
		
//		U.log("mmmmmm"+Util.matchAll(headComSec, "[\\w\\s\\W]{30}5,160 a/c sq. ft. | 6,736 total sq. ft.[\\w\\s\\W]{30}", 0));
		
		
//		U.log(Util.matchAll(earlyMoveHtml, "\\$788,293",0));
		
		if(collectionPrice!=null)
			collectionPrice = collectionPrice.replaceAll("0s", "0,000");
		
		String prices[] = U.getPrices(headComSec + html +earlyMoveHtml +collectionHtml+comData,
				"from \\$\\d{3},\\d{3}|Build From: <strong>\\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d*|from the \\$\\d{3}\\,\\d*|\\$\\d{3}\\,\\d*",
				0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log("mmmmmm"+Util.matchAll(html , "[\\w\\s\\W]{30}500,000[\\w\\s\\W]{30}", 0));




		//====================Sq.ft=====================

		String[] sqft = U.getSqareFeet(modelForSale+html+earlyMoveHtml+collectionHtml+comData,
				"\\d,\\d{3} total sq. ft.|\\d,\\d{3} total sq. ft.|\\d{1,2},\\d+ total sq. ft|\\d,\\d{3}total sq. ft.",0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("Price--->"+minPrice+" "+maxPrice);
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);

		//================================================community type========================================================
		
		
		html=U.removeSectionValue(html, "<head>", "</head>");
		html=html.replaceAll("There will be exciting updates coming soon with information|delivery_popbar_left\">QUICK DELIVERY HOME</div>|\"Valencia Cay Grand Opening\"|\"Florida's premier active adult|12 designer-decorated models, now open!| golf courses, airports", "");
		String remAreaMap = U.getSectionValue(html, "<div class=\"area-map\">", "<section class=\"promo-banner");
//		U.log(remAreaMap);
		if(remAreaMap != null)	html = html.replace(remAreaMap, "");
		remAreaMap = U.getSectionValue(html, "const poiData =", "</script>");
		if(remAreaMap != null)	html = html.replace(remAreaMap, "");
		remAreaMap = null;
		if(strandardFreaturesUrlHtml==null)strandardFreaturesUrlHtml=ALLOW_BLANK;
		strandardFreaturesUrlHtml=strandardFreaturesUrlHtml.replace("Active Adult", "");
		String communityType=ALLOW_BLANK;
		communityType=U.getCommType((strandardFreaturesUrlHtml+comData+html).replaceAll("Golf|golf|golfing|Golfing|GOLF", "").replaceAll("The active adult lifestyle|specifically to an active-adult lifestyle", ""));
		
		
		if(communityType!=ALLOW_BLANK) {
			communityType+=", Golf Course";
			
		}
		else {
			communityType="Golf Course";
		}
		U.log("Community type--->"+communityType);
		//U.log(comData);
		
		//==========================================================Property Type================================================
		
		//newHomeUrlHtml = newHomeUrlHtml.replace("<br> Loft<br>", "<br> Loft homes<br>");
		U.log("singl"+Util.match(comData+html+strandardFreaturesUrlHtml+earlyMoveHtml+collectionHtml, "single-family"));
		html = html.replaceAll("class=\"secondary-sub__item\">\n*\\s+Coastal Collection", "coastal-style homes");
		html=html.replace("Mediterranean","Mediterranean Style");
		U.log("Mesetr"+Util.match(html,"Mediterranean"));
		if(strandardFreaturesUrlHtml != null) strandardFreaturesUrlHtml = strandardFreaturesUrlHtml.replaceAll("traditional tables", "");
		if(earlyMoveHtml != null) earlyMoveHtml = earlyMoveHtml.replaceAll("-mediterranean-style.jpg", "");
		
		collectionHtml = collectionHtml.replaceAll("Winding Ridge,Single Family Homes|Chapel Florida features single family|"
				+ "1 Half Bath, Multi-Gen Suite|Florida features single-family residences", "");
		
		String propType= U.getPropType((comData+html+strandardFreaturesUrlHtml+earlyMoveHtml+collectionHtml).replaceAll("patio bar caf|luxurious resort-style pool", ""));
			
		U.log("Property type--->"+propType);
		U.log("MATCH -- "+Util.match(comData+html+strandardFreaturesUrlHtml+earlyMoveHtml+collectionHtml, "[\\w\\s\\W]{30} Multi-Gen [\\w\\s\\W]{30}"));

		//==================================================D-Property Type======================================================
		
		String derivedType= U.getdCommType((comData+html+strandardFreaturesUrlHtml).replaceAll("Ranch|ranch|Parkway and Colonial ", "")+comName);//+html+aminitiesUrlHtml+strandardFreaturesUrlHtml);
		U.log("Derived Property type--->"+derivedType);
		
		//==============================================Property Status=========================================================

		if(html.contains("Early Move-In") || html.contains("Early-Move-In") || html.contains("Early Move-in")|| html.contains("EARLY MOVE-IN")) {
			//html=html.replaceAll("Early Move-(I|i)n|Early-Move-In", "Move-in Ready Homes");
			html=html.replaceAll("Early Move-(I|i)n|Early-Move-In", "Early Move-in");
		}
		html=html.replace("Lake View Homesites Available Now", "Lakeview Homesites Available Now").replace(">(sold out) <", "");
		html=html.replaceAll("community coming soon|New Clubhouse, Now Open|Contemporary style now available|model grand opening|CLOSEOUT SALE! SAVE UP |GRAND OPENING SET FOR APRIL |The Grand Opening of Valencia |grand opening set |closeout-sale-|celebrated the grand opening of six | Model Grand Opening Event|Sales Office Is Now Open|MODEL GRAND OPENING|celebrate the grand opening of ten |model-grand-opening|dreamed of is now available|FINAL HOMES TO BE |NOW SELLING FROM VALENCIA BAY|HOME DESIGNS COMING SOON|new homes are coming soon as Lotus|elevation designs that are coming soon|Model Grand Opening|CELEBRATES SUCCESSFUL GRAND OPENING|-grand-opening|Lotus model grand opening |MODEL GRAND OPENING|grand opening and tour||Model Grand Opening March 30|Opening March 30</p>|opening-may-|Office Is Now Open|models now open|homes sold, development|Clubhouse at The Ridge is now|text--sm\">NOW SELLING|clubhouse is now open|since\\s*\\w* grand opening|grand opening of Valencia Cay at Riverland|HOME DESIGNS COMING SOON|now available for only|AMENITIES NOW OPEN| Clubhouse is now open|Amenities Are Now Open| designs that are coming soon|now selling the all new Modern Collection", "");
		html=html.replaceAll("LIFESTYLE CENTER COMING|Racquet Club Now Open|CLASS RACQUET CLUB NOW OPEN|Shop&#160;that is now open|SHOP - NOW OPEN| heading-size-2\">NOW OPEN!</div>|MODELS FOR SALE COMING SOON|Models For Sale Coming Soon|lifestyle-center-coming-soon|now available for only|now available and|Clubhouse is now|Now Open from Valencia|spectacular new homesites just|model is coming soon|Club is now open|homes sold to date|hero closeout|hero-closeout|NEW HOMESITES AVAILABLE THIS|Center, now", "");
		html=html.replace("<span>(coming soon)</span>", "").replace("inner\">(coming soon)</span>", "").replace("<small>(coming soon) </small>", "")
				.replaceAll("that are now", "");
		
		html = U.removeSectionValue(html, "VALENCIA SOUND UPDATES", "</section>");
		String propStatus=U.getPropStatus((statusHtml+comData+html).replace("grand opening on August 27", "grand opening August 27").replaceAll("Boca Raton coming soon|- \\(coming soon|appointment to view the final homes availabl|Opening March 30</p>|opening-may-", "").replace(">(sold out)<", ""));
		U.log("Property Status--->"+propStatus);
//		U.log(Util.matchAll(comData+html, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0));

		//============================================note====================================================================
		


		if(propStatus.contains("New Homesites Available, Move-in Ready Homes, New Homesites Now Available"))propStatus=propStatus.replace("New Homesites Available, Move-in Ready Homes, New Homesites Now Available", "Move-in Ready Homes, New Homesites Now Available");
//		if(comUrl.contains("/valencia-trails/") || comUrl.contains("/winding-ridge/"))communityType = communityType+", Golf Course";
		//propStatus = propStatus.replace("Move-in Ready", "Early Move-in");
		//propStatus = propStatus.replace("Move-in Ready", "Early Move-in");
			/*
			 * if(comUrl.contains("https://www.glhomes.com/valencia-bonita/")) maxPrice =
			 * "$822,900";
			 */
		if(comUrl.contains("https://www.glhomes.com/valencia-sound/"))
			propType=propType+", Mediterranean Style Home";
		
		String units=ALLOW_BLANK;
		String startDt=ALLOW_BLANK, endDt=ALLOW_BLANK;
		
			add[2]=add[2].toUpperCase();
			add[2]=add[2].replace(",","").trim();
			
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			data.addCommunity(comName,comUrl, communityType);//
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);//
			data.addPrice(minPrice, maxPrice);//
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());//
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, derivedType);//
			data.addPropertyStatus(propStatus);//
			data.addNotes(note); //
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);

		}
		j++;
	}
}