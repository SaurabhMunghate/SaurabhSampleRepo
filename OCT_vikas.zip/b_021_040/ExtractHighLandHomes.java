/**
 * @Author:sanket
 * @Date:15/3/2012
 */
package com.shatam.b_021_040;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.jasper.tagplugins.jstl.core.Catch;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHighLandHomes extends AbstractScrapper {
	public int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int duplicates = 0;
	ArrayList<String> comm = new ArrayList<String>();
	WebDriver driver = null;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractHighLandHomes();
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath() + "Highland Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public ExtractHighLandHomes() throws Exception {

		super("Highland Homes", "https://www.highlandhomes.com");
		LOGGER = new CommunityLogger("Highland Homes");
	}

	static MultiValueMap jsonComDetails = new MultiValueMap();
	
	public void innerProcess() throws Exception {

//		U.setUpGeckoPath();
//		DesiredCapabilities capabilities = DesiredCapabilities.firefox(); 
//		FirefoxProfile profile = new FirefoxProfile();
//		profile.setPreference("permissions.default.image", 2);
//		capabilities.setCapability("firefox_profile", profile);
//		driver = new FirefoxDriver(capabilities);
		
		U.setUpChromePath();
		driver = new ChromeDriver();

//		driver = new FirefoxDriver();
		
//-----IMPORTANT NOTE: Get the cache of regions from direct by coping from inspect----------------------
		
		String[] region = { "austin", "dfw", "houston", "san-antonio" };	
		//String[] region = { "austin" };
		//String[] region = { "dfw", "houston", "san-antonio" };
		// https://www.highlandhomes.com/dfw/

		for (int j = 0; j < region.length; j++) {
			
			//----------------------Data for no. of units storing data in map.--------------------------
			String comJsonUrl = ALLOW_BLANK; String subJsonUrl = ALLOW_BLANK;
			String mainHtml = U.getHTML("https://www.highlandhomes.com/" + region[j]);
			//for coms. json
			String jsonComData = U.getSectionValue(mainHtml, "var communities =", "];");
			//U.log("jsonData: "+jsonComData);
			String[] secJson = U.getValues(jsonComData, "{\"", "]");
//			U.log("secJson: "+secJson.length);
			for(String sec:secJson) {
//				U.log("sec: "+sec);
				String comId = U.getSectionValue(sec, "objectID\":\"community-", "\",");
				comJsonUrl = U.getSectionValue(sec, "\"url\":\"", "\",");
				comJsonUrl = "https://www.highlandhomes.com/" + comJsonUrl.replace("\\/", "/");
				//U.log("comId: "+comId);
				//U.log("comJsonUrl: "+comJsonUrl);
				jsonComDetails.put(comJsonUrl, comId);
			}
			//for sub-coms. json
			String jsonSubData = U.getSectionValue(mainHtml, "var subdivisions =", "];");
			//U.log("jsonSubData: "+jsonSubData);
			String[] subJson = U.getValues(jsonSubData, "{\"", "]");
			//U.log("subJson: "+subJson.length);
			for(String sub:subJson) {
				//U.log("sub: "+sub);
				String subId = U.getSectionValue(sub, "objectID\":\"section-", "\",");
				subJsonUrl = U.getSectionValue(sub, "\"url\":\"", "\",");
				subJsonUrl = "https://www.highlandhomes.com/" + subJsonUrl.replace("\\/", "/");
//				U.log("subId: "+subId);
//				U.log("subJsonUrl: "+subJsonUrl);
				jsonComDetails.put(subJsonUrl, subId);
			}
			
			//--------------------------------- For communities data extraction see below -----------------------
			
//			U.log("https://www.highlandhomes.com/" + region[j]);
			String regionUrl="https://www.highlandhomes.com/"+region[j];
//			U.log("regionUrl :: "+regionUrl);
			String html = U.getHtml(regionUrl, driver);
			// if(region[j].equals("houston"))
			
			{
//				U.log("https://www.highlandhomes.com/" + region[j]);
				String[] comSections = U.getValues(html, "<div class=\"community-name\">", "</div></div></div>");
//				U.log("comSections length: "+comSections.length);
				
				
				int totalCount = 0;
				for (String comSec : comSections) {
					String statusSec = U.getSectionValue(comSec, "span class=\"sidenote\"", "<div");
					comSec = comSec.replace("</span></a>", "</a>");


					comSec = comSec.replaceAll("</span>(</a> <!---->)? <span style=\"opacity: 0.7; font-size: 0.9em; white-space: nowrap;\">", "");
					String[] subComSections = U.getValues(comSec, "<a href=", "</span>");// U.getValues(comSec, "<a
																							// href=", "</span>");
					// U.log(subComSections.length);
					for (int k = 1; k < subComSections.length; k++) {
						String comUrl = U.getSectionValue(subComSections[k], "\"", "\"");
						// if(!comUrl.contains("http")){
						 //try{
						addDetail("https://www.highlandhomes.com" + comUrl,	subComSections[0] + "\n" + subComSections[k] + "\n" + statusSec, driver, comJsonUrl);
						 //}catch(Exception e){}
						// }

						totalCount++;
					}
				}
				
				U.log(totalCount);
			}

			// U.log(i);
			inr = 0;

		}

		LOGGER.DisposeLogger();
//		driver.quit();
		try{
			driver.quit();
		}catch (Exception e) {}
	}

	int j = 0;

	private void addDetail(String url, String comminfo, WebDriver driver,  String comJsonUrl) throws Exception {
	
	//	 try {
		
//		if(j >= 100 && j < 150)
//		if(j >=150) 
		{
			//SINGLE EXECUTION -------------------
//			if(!url.contains("https://www.highlandhomes.com/houston/katy/sunterra")) return;
//			U.log(comminfo);
			 U.log("Count: " + j);
//			if (url.contains("https://www.highlandhomes.com/san-antonio/bNow Pre-Selling Phase 1ulverde/ventana/65ft-lots/section"))return;
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "--------REPEATED-------");
				return;
			}
			
			if (url.contains("www.huntingtonhomestx.com")) {
				LOGGER.AddCommunityUrl(url + "-------- Redirected to huntingtonhomestx -------");
				return;
			}
			//17 Feb 2021
			if(url.contains("https://www.highlandhomes.com/dfw/northlake/the-ridge-at-northlake") ||
					url.contains("https://www.highlandhomes.com/dfw/flower-mound/canyon-falls")){
				LOGGER.AddCommunityUrl(url + "-------- Redirected  -------");
				return;
			}
			LOGGER.AddCommunityUrl(url);

			 U.log("INFO  "+comminfo);

			String html1 = ALLOW_BLANK;
			// url = url.replace("/section/explore", "").replace("/explore", "");
			U.log("url : " + url);
			html1 = U.getHtml(url, driver);// U.getHtml(url, driver);
			String forStatus = html1;
			U.log(U.getCache(url));	

			// ----remove footer section-----
			html1 = U.removeSectionValue(html1, "<footer class=\"cf\">", "</html>");
			// U.log("::::::::::::::::::::::::::::::This is INfo"+comminfo);
			// comminfo = comminfo.replace(oldChar, newChar)
			//U.log(comminfo + "\nPAGE :" + url);
			//U.log(U.getCache(url));
			if (html1.contains("<h2>Page Not Found</h2>")) {
				duplicates++;
				LOGGER.AddCommunityUrl(url + "::::::::::::::::::404 Error:::::::::");
				return;
			}

			// ------------CommunityName------
			String communityName = U.getSectionValue(html1, "<h1><strong>", "</strong></h1>");
			if (communityName == null)
				communityName = U.getSectionValue(html1, "<title>", "</title>");
			communityName = communityName.replaceAll(
					"New Homes in |lots - Home Builder in Bulverde TX|<span class=\"comingSoon\">Coming Soon</span>|<span class=\"comingsoon\">coming soon</span>",
					"");
			// U.log(communityName);
			if (communityName == null || communityName.length() < 2) {
				// U.log("::::::::::::::::::::::::::::::This is INfo"+comminfo);

				communityName = U.getSectionValue(comminfo, " font-weight: bold;\">", "</a>");
				U.log(communityName);
			}
			//if(url.contains("https://www.highlandhomes.com/san-antonio/san-antonio/cantera-manor"))communityName  = "Cantera";
			
			communityName = communityName.toLowerCase().trim()
					.replace("bridgeland: townhomes", "bridgeland")
					.replace(": townhomes", "")
					.replaceAll(": townhomes$|- the\\s*\\w*| - front entry| -rear entry|- estate sized homesites|Explore|explore|: townhomes$", "");

			U.log("communityName: "+communityName);
			//communityName = communityName.replaceAll(":", "");
			
			// address
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			//============Move In Sectio==============
			String moveSec = U.getSectionValue(html1, "<h5>Explore Site Plan</h5>", "<h3>Have a Question about one of these Homes?</h3>");
			if(moveSec == null) {
				moveSec = U.getSectionValue(html1, "<h5>Explore Site Plan</h5>", "Site Plan");
			}
			//U.log("moveSec:::::::::: "+moveSec);
			String moveHtml = "";
			if(moveSec != null) {
			String[] moveUrls = U.getValues(moveSec, "<a href=\"", "\"");
			U.log("moveUrls:::::::::: "+moveUrls.length);
			
			for(String moveUrl : moveUrls) {
				moveUrl="https://www.highlandhomes.com"+moveUrl;
				U.log("Move Homes:::::::::: "+moveUrl);
				String moveHtmlfull = U.getHtml(moveUrl, driver);
				moveHtml += U.getSectionValue(moveHtmlfull,"id=\"overview\"","</section>");
			}
			}
			String addressSec = U
					.getNoHtml(U.formatAddress(U.getSectionValue(html1, "<p class=\"secondLine\">", "</p>")));
			 U.log(addressSec);
			if (addressSec != null) {
				addressSec=addressSec.replace("Cottages of Celina", "");
				add = U.getAddress(addressSec);
			}
			
			if(add[0].equals("15900 La Cantera Pkwy. Ste. 26110")) {
				add[0] = add[0].replace("15900 La Cantera Pkwy. Ste. 26110", "15900 La Cantera Pkwy.");
			}
			
			if(add[0] != null) {
				//removing comName from street
				add[0] = add[0].replaceAll("Bel Air Village| Townhomes|Bridgeland|Cross Creek West|Mesa Western|Veramendi 40s|Veramendi 70s", "").replace("Bryson", "").replace("704 Street, side Lane", "704 Streetside Lane").replace("Painted Tree", "");
			}
			
			U.log("ADDRESS: "+Arrays.toString(add));
			
			if (add[0] == null)
				add[0] = ALLOW_BLANK;
			add[0] = add[0].replaceAll("Model -|Creekwood Model:|Cinco Ranch Model -", "");
			// Price

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String minsqft = ALLOW_BLANK, maxsqft = ALLOW_BLANK;
			comminfo = comminfo.replace("0s", "0,000").replace("lowPrice\":", "lowPrice\":\\$");
			// comminfo = comminfo.replace("highPrice\":", "highPrice\":\\$");
			// U.log("MMMMMMMMM "+comminfo.contains("$270"));
			String price[] = U.getPrices(html1 + comminfo, "from the \\$\\d{3},\\d{3}|\\$\\d{3}(,)*\\d{3}|\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("minPrice :"+minPrice+" maxPrice :"+maxPrice);
			
		
			
			
			String sqft[] = U.getSqareFeet(html1,
					">\\d{4}</span> <span class=\"label\">base sq ft|\\d{4} to \\d{4} sqft|\\d{4}-\\d{4} square feet|square footages up to \\d{4} square feet|\\>\\d,\\d+\\<|from \\d+,\\d{3}\\-\\d+,\\d{3} square",
					0);
			minsqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxsqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("MinSq :"+minsqft+" MaxSq :"+maxsqft);

			// lat and lang
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;

			// property Type

			// --------pType------------
			String pType = ALLOW_BLANK;
			if(moveHtml!=null)moveHtml=moveHtml.replace(" @ patio</p>", "your patio");
			html1 = html1.replace("Estate Sized Homesites", "Estate Homes")
					.replace("experience of luxury", "luxury homes")
					.replaceAll(">Back Patio<|\\+Patio\\+|alt=\"Back Patio|>Patio<|=Patio+|alt=\"Patio\"|devonshire/townhomes/section|"
							+ ">Townhomes<|fees and/or Homeowner's Association dues", "");
			pType = U.getPropType(html1+moveHtml.replaceAll("crafted|Carriage House Amenity Center|Loft_|with a cabin and fishing dock", ""));
			
//			U.log(">>>>> pType >>>>>"+Util.matchAll(html1,"[\\w\\W\\s]{60}Homeowner's Association[\\w\\W\\s]{60}", 0));
			//U.log(">>>>> pType >>>>>"+Util.matchAll(moveHtml,"[\\w\\W\\s]{60}townhomes[\\w\\W\\s]{60}", 0));
			U.log("pType::: "+pType);
			
			// -------Derived_Type-------------
			String derivedPType = ALLOW_BLANK;
			html1 = html1.replace("</span><span class=\"label\">stories", " Stories").replaceAll("<p><span class=\"numeral\">1</span> <span class=\"label\">stories</span></p>", " 1 Story")
					.replaceAll("<p><span class=\"numeral\">2</span> <span class=\"label\">stories</span></p>", " 2 Story").replaceAll("<p><span class=\"numeral\">3</span> <span class=\"label\">stories</span></p>", " 3 Story")
					.replaceAll("Ranch Elementary|Oaks Ranch|Ranch High", "");
			derivedPType = U.getdCommType(communityName + url + html1);
//			U.log(">>>>> pType >>>>>"+Util.matchAll(moveHtml,"[\\w\\W\\s]{6}stories[\\w\\W\\s]{6}", 0));
			// -------Address--------------
			String geo = "FALSE";
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String latlNgSec = U.getSectionValue(html1, "<a href=\"https://maps.google.com/maps?q=loc:", "(");
			if (latlNgSec != null) {
				latLng = latlNgSec.split(",");
				lat = latLng[0];
				lng = latLng[1];
				if (lng.contains("target")) {
					lng = lng.substring(0, lng.indexOf("\""));
				}
			} else {
				lat = U.getSectionValue(comminfo, "lat\":\"", "\"");
				lng = U.getSectionValue(comminfo, "lon\":\"", "\"");
			}
//			if(url.contains("https://www.highlandhomes.com/san-antonio/cibolo/mesa-western")) {
//				latLng[0] = lat.trim();
//				latLng[1] = lng.trim();
//				String[] lati = { latLng[0], latLng[1] };
//				add[0]= U.getAddressGoogleApi(lati)[0];
//			}
			if (add[0].length() < 3 && (add[1].length()>3)) {
				latLng[0] = lat.trim();
				latLng[1] = lng.trim();
				U.log("latLng size:: " + latLng.length + ":::" + latLng[0] + "::::" + latLng[1]);
				String[] lati = { latLng[0], latLng[1] };
				String adds[] = U.getAddressGoogleApi(lati);
				if (adds == null)
					adds = U.getGoogleAddressWithKey(lati);
				if (adds == null)
					adds = U.getAddressHereApi(lati);
				// String adds[] = adds=U.getBingAddress(latLng[0],latLng[1]);
				// if(adds == null) adds=U.getBingAddress(latLng[0],latLng[1]);
				add[0] = adds[0];
//				add[1] = adds[1];
//				add[2] = adds[2];
//				add[3] = adds[3];
				geo = "TRUE";
			}	
			if (add[0].length() < 3 && (add[1].length()<3)) {
				latLng[0] = lat.trim();
				latLng[1] = lng.trim();
				U.log("latLng size:: " + latLng.length + ":::" + latLng[0] + "::::" + latLng[1]);
				String[] lati = { latLng[0], latLng[1] };
				String adds[] = U.getAddressGoogleApi(lati);
				if (adds == null)
					adds = U.getGoogleAddressWithKey(lati);
				if (adds == null)
					adds = U.getAddressHereApi(lati);
				// String adds[] = adds=U.getBingAddress(latLng[0],latLng[1]);
				// if(adds == null) adds=U.getBingAddress(latLng[0],latLng[1]);
				add[0] = adds[0];
				add[1] = adds[1];
				add[2] = adds[2];
				add[3] = adds[3];
				geo = "TRUE";
			}	
			if (communityName.contains("The Ranch At Brushy Creek")) {
				add[0] = "102 N Frontier Ln";
				add[1] = "Cedar Park";

			}
			if (add[0].length() > 100)
				add[0] = ALLOW_BLANK;

			add[0] = add[0].replace("(pre-selling from Heatherwood in McKinney, TX), -", "");
			add[1] = add[1].replaceAll(
					"parks and a resort-style pool. Stay tuned for more details on this upcoming community!|dining and entertainment is just minutes away! Stay tuned for more information on this exciting new development!",
					ALLOW_BLANK);
			if (add[2] == null)
				add[2] = ALLOW_BLANK;
			add[0] = add[0].replace("Coming Soon!", ALLOW_BLANK);
			add[0] = add[0].replace("By Appointment Only", ALLOW_BLANK).replaceAll(",", "");
			add[0] = add[0].replace("Selling From Our Creekside Park Model:", "");
			add[1] = add[1].replace("coming this Summer!", ALLOW_BLANK);
			if (maxPrice.contains("null"))
				maxPrice = ALLOW_BLANK;

			add[0] = add[0].toLowerCase().replace("sales office: ", "");
			add[2] = add[2].replaceAll("Texas|texas", "TX");
			
			
		
			
			if (add[0] == ALLOW_BLANK || add[0].length() < 4) {
				U.log(" not found address :: ");
				String laton[] = { lat, lng };
				add = U.getAddressGoogleApi(laton);
				geo="True";
				if (add == null) {
					add = U.getAddressHereApi(laton);
				}
			}

			// -------------CommunityType--------------
			html1 = html1.replace("value=\"Golf\" /> Golf</div>", "value=\"Golf\"/> Golf Course </div>");
			html1 = html1.replace("Hackberry Country Club", "").replaceAll("Golf Club|Ranch Golf", "golf course")
					.replace("Golf &amp; Country Club", "golf course &amp; Country Club");
			String communityType = U.getCommunityType((html1).replace("resort-caliber", "Resort Style")
					.replaceAll("Resort Style Living in|Left on Country Club| Golf", "")+ comminfo);

			// --------Status-------------
			String pStatus = ALLOW_BLANK;

			html1 = html1.replaceAll(
					"\\d+ Coming Soon|Coming Soon: Poolside|The Farm Stand Market Now Open|elementary school coming soon|Model Now Open - Now Selling|1 Coming Soon|Blvd Now Open|Model Now Open - Now Selling|Model Now Open|time_frame\":\"New Phase Now Open|ISD Elementary School Now Open",
					"");
			html1 = html1.replaceAll(
					"14 Available Lots|\\d Coming Soon|Coming Soon - Call for Appointment|and move-in ready homes from any device|elementary school now open|Center Coming Soon|Move In|Move-in|Elementary Coming Soon|coming-soon",
					"");
			html1 = html1.replaceAll(
					"shopping experience is now|Creek lots available|Exclusive Golf Course Lots Available|Model Now Open - Now Selling|New Hill Country Lots Available in Leande|\"Available Now\"|Available Now|New homes available|school opening Fall 2017",
					"");
			comminfo = comminfo.replace("Model Now Open - Now Selling", "").replaceAll(
					"Quick Move-Ins Available|Frisco</span></a>\\s*<span class=\"comingSoon\">\\s*Coming Soon|Quick Move-In Homes|Coming Soon - Call for Appointment|Golf Course Lots Available|Lakeside Amphitheater Now Open|Amenity Center Now Open|The Farm Stand Market Now Open",
					"");

			// -------below code will remove all "Move-in Ready" but not this content -> "6
			// move-in ready homes"
			if (!html1.contains("thumbnail home-container homeSpec")) {
				html1 = html1.replaceAll("[M|m]ove-[i|I]n [R|r]eady", "");
			}
			
//			U.writeMyText(comminfo + html1);
			if(url.contains("/san-antonio/san-antonio/fronterra-at-westpointe/50ft-lots/section"))comminfo = comminfo.replace("Final Opportunity in 65s", "");
			html1=html1.replace("New Phase coming end of 2021", "New Phase coming end 2021")
					.replace("Final Opportunities-New Phase 2022", "Final Opportunities New Phase 2022");
			//comminfo= comminfo.replace("Final Opportunities in Phase 2", "Final Opportunities Phase 2");
			
			String replaceString=U.getHtmlSection(comminfo, "<span>", "</span>");
			if(replaceString!=null) {
				comminfo=comminfo.replace(replaceString, "");
			}
			pStatus = U.getPropStatus((comminfo + html1)
					.replace("padding-bottom: 0.35em;\">Brand New Phase Now Open</span>", "")
					.replace("padding-bottom: 0.35em;\">Now Selling New Phases</span>", "")
					.replace("<h3>Lake Lots &amp; Treed Lots Available</h3>", "")
					.replace("padding-bottom: 0.35em;\">Final Opportunities + New 45’ Lots Coming Soon</span> <!DOCTYPE html>", "")
					.replace(" style=\"display: block; padding-bottom: 0.35em;\">Now Selling</span> <!DOCTYPE html><html", "")
					.replace("quick move-in homes", "").replaceAll("QUICK MOVE|Quick Move|quick move", "") //removing Quick Move-in Homes 
					.replaceAll("Quick Move-In &amp; Builds Available|favorite floor plans and quick move-in homes from any device|Now Selling in Parkland Village|District is coming soon|New Homesites Coming Fall 2021|development coming soon|School Coming Soon|\\d+ Coming Soon|New Phase Coming Summer 2021|New Phase Coming Late Summer 2021|Now Selling from New Model|plans\">Coming Soon</a>|Coming Soon</nobr>|<section class=\"small_header\" id=\"plans\" data-magellan-target=\"plans\">\n\\s*<h2 class=\"row column\">Coming Soon</h2>|Now Pre-Selling Final Phase|New School Coming Soon|<nobr>\\d+ Coming Soon| Ready Homes Available", ""));

			U.log(">>>>> pStat >>>>>"+Util.matchAll(comminfo + html1,"[\\w\\W\\s]{60}lots available[\\w\\W\\s]{60}", 0));
//			U.log(">>>>> pStat >>>>>"+Util.matchAll(html1,"[\\w\\W\\s]{60}new phase open[\\w\\W\\s]{60}", 0));

			
			U.log("pStatus :----" + pStatus);
			//quick move-ins from completed homes only
			if(forStatus.contains("Complete & Move-in Ready") || forStatus.contains("Complete &amp; Move-in Ready")) {//||forStatus.contains("Est. Completion - Aug '22")
				if(pStatus == ALLOW_BLANK)
					pStatus = "Quick Move-in";
				else if(pStatus != ALLOW_BLANK && !(pStatus.contains("Quick Move-in")))
					pStatus = pStatus + ", Quick Move-in";
			}
//			U.log(">>>>> status >>>>>"+Util.matchAll(comminfo + html1,"[\\w\\W\\s]{60}complete[\\w\\W\\s]{60}", 0));
			
			pStatus = pStatus.replace("New Lots Now Available, Now Available", "New Lots Now Available");
			pStatus = pStatus.replace("Final Phase, Move-in Ready Homes, Final Phase Now Selling",
					"Move-in Ready Homes, Final Phase Now Selling").replace("New Phase Opening Spring 2021, New Phase Open", "New Phase Opening Spring 2021");
			pStatus=pStatus.replace("Move-in Ready Homes","Move-in Ready");
			pStatus=pStatus.replace("Now Selling, Move-in Ready, Now Selling New Section", "Move-in Ready, Now Selling New Section");
//			pStatus=pStatus.replace("Move-in Ready, Now Selling, Now Selling New Sections", "Move-in Ready, Now Selling New Sections");
//			pStatus=pStatus.replace("Sold Out Fast, Now Selling, Now Selling New Phase", "Sold Out Fast, Now Selling New Phase");
//			pStatus=pStatus.replace("Move-in Ready, Now Selling, Now Selling New Phase", "Move-in Ready, Now Selling New Phase");
			
			// ------Notes---------
			String noteVar = U.getnote(html1 + comminfo);
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			String jsonUrl = ALLOW_BLANK;
			
			if(html1.contains("Site Plan</a>")) {
				
				U.log("-------- SITE PLAN PRESENT ------------");
				
				ArrayList<String> forComId = (ArrayList)jsonComDetails.get(url);
				for(String comid:forComId) {
					U.log("comid: "+comid);
					
					if(url.contains("/townhomes/section")) continue; 
					
					if(url.contains("ft-lots/section") || url.contains("/section")) {
						//for sub-communities
						jsonUrl = "https://www.highlandhomes.com/subdivision/json/"+ comid +"/all";
						U.log("jsonUrlOne: "+jsonUrl);
					}
					else {
						//for communities directly
						jsonUrl = "https://www.highlandhomes.com/community/json/"+ comid +"/all";
						U.log("jsonUrlTwo: "+jsonUrl);
					}
					break;   //processing required for only one comId 
				}
				U.log("jsonUrl: "+jsonUrl);
				//FileUtil.writeAllText("/home/shatam-10/Desktop/data/urls.txt", jsonUrl);
				
				
				if(jsonUrl != ALLOW_BLANK) {
					String jsonInfo = U.getPageSource(jsonUrl);
					U.log("Json Cache: "+U.getCache(jsonUrl));
//					FileUtil.writeAllText("/home/shatam-10/Desktop/data/cacheurls.txt", U.getCache(jsonUrl));
					
					JsonParser json = new JsonParser();
					JsonObject jsonObj = (JsonObject) json.parse(jsonInfo);
					//U.log("jsonObj: "+jsonObj);
					
					JsonArray solds = new JsonArray();
					JsonArray lots = new JsonArray();
					JsonArray specs = new JsonArray();
					JsonArray models = new JsonArray();
					
					solds = (JsonArray) jsonObj.get("solds");
					int sold = solds.size();
					U.log("sold: "+sold);
					
					lots = (JsonArray) jsonObj.get("lots");
					int lot = lots.size();
					U.log("lot: "+lot);
					
					specs = (JsonArray) jsonObj.get("specs");
					int spec = specs.size();
					U.log("spec: "+spec);
					
					models = (JsonArray) jsonObj.get("models");
					int model = models.size();
					U.log("model: "+model);
					
					int totalUnits = sold + lot + spec + model; 		
					U.log("totalUnits: "+totalUnits);
					units = String.valueOf(totalUnits);
					U.log("units: "+units);
				}
				
			}
			

				
			data.addCommunity(communityName.toLowerCase(), url, communityType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(pType, derivedPType);
			data.addPropertyStatus(pStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minsqft, maxsqft);
			data.addNotes(noteVar);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
		}
	//		 }catch (Exception e) { }
		j++;
	}
}
