/*
 * Modification Aditya..
 */
package com.shatam.b_021_040;

import java.io.File;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractHorizon extends AbstractScrapper 
{
	public int i = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	public int inr = 0;
	ArrayList<String> comm = new ArrayList<String>();
	//FirefoxDriver driver = new FirefoxDriver();
	WebDriver driver = null;
	public static void main(String[] ar) throws Exception 
	{

		AbstractScrapper a = new ExtractHorizon();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Highland Homes - Horizon Homes.csv",
				a.data().printAll());
	}

	public ExtractHorizon() throws Exception 
	{

		super("Highland Homes - Horizon Homes", "http://www.horizonhomes.com/");
		LOGGER = new CommunityLogger("Highland Homes - Horizon Homes");
	}

	public void innerProcess() throws Exception 
	{
		U.setUpGeckoPath();
		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		// String html=U.getHTML("http://www.horizonhomes.com/");
		String hmUrl = "http://www.horizonhomes.com/";
		String html = U.getHtml(hmUrl, driver);
		
		
		String[] comVal = U.getValues(html," <div class=\"col-sm-4\">","<div class=\"locational-nav-container\">");
		
		for (String comSec : comVal) 
		{
	
			
			String comUrl="http://www.horizonhomes.com"+U.getSectionValue(comSec,"href=\"","\"");
			
			String comHtml = U.getHtml(comUrl, driver);
			
			U.log("ComUrl:" + comUrl);
			
			String commsec[] = U.getValues(comHtml,"{\"display_name\":", "}");
			
			ArrayList<String> URL_LIST = new ArrayList<String>();
			for (String section : commsec) 
			{
				URL_LIST.add(section);
			}
			// LOGGER.countOfCommunity(URL_LIST.size());
			for (String section : URL_LIST) 
			{
				//U.log(section);
				String name = U.getSectionValue(section, "\"", "\"");
				String url = U.getSectionValue(section, "fullUrl\":\"", "\"")
						.replace("\\/", "/");
				String lat = U.getSectionValue(section, "lat\":\"", "\"");
				String lng = U.getSectionValue(section, "lon\":\"", "\"");
				if (this.data.communityUrlExists("http://www.horizonhomes.com"
						+ url))
					continue;
				addDetail(url, name, lat, lng, section);
			}
		}
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addDetail(String url, String name, String lat, String lng,	String info) throws Exception {
		/* try{ */
//		if(j==0)
		{
		U.log("lat :: "+lng);
		url = "http://www.horizonhomes.com" + url;
		//if(!url.contains("http://www.horizonhomes.com/dfw/wylie/bozman-farms-50s-60s"))return;
		U.log("URL==" + url);
		String html = U.getHtml(url, driver);
		String movePart = U.getSectionValue(html, "<div ng-show=\"community.specs.length &gt; 0\" class=\"home-plans cf\">", "</div>");
		U.log(movePart);
		if (html == null)
			html = U.getHTML(url + "/explore");
		
		
		U.log("Name==" + name);
		name = name.replace("\\", "");
		
		String[] latlng = { lat, lng };
		
		String addLine =ALLOW_BLANK;
		if(addLine==ALLOW_BLANK){
			addLine= U.getSectionValue(html, "no-mobile\">", "</span>").trim();
		}
		
		
		U.log("@@@  " + addLine);
		String add[] = U.getAddress(addLine);
		if (add[0] == null)
			add[0] = ALLOW_BLANK;
		String addSec1 = U.getSectionValue(html, "://maps.google.com/maps", "/a>");
		U.log(addSec1);
		String addVal = U.getSectionValue(addSec1, ">", "<");
		add = U.getAddress(addVal);
		U.log("street=" + add[0] + "city=" + add[1] + "::state=" + add[2]+ "::zip==" + add[3]);
		String geo = "FALSE";
		if (lat != null && (add[0] == null || add[0].length() < 3)) {
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
		}
		info = info.replaceAll("low_price\":\"", "low_price\":\"\\$");
		// info=info.replaceAll("high_price\":\"", "high_price\":\"\\$");
		info = info.replace("0\",", "0,000\",");
		U.log(info);
		add[1]=U.getSectionValue(info, "\"city\":\"", "\"");
		if (this.data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url + "\t*********Repeated******\t");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String minsqft = ALLOW_BLANK, maxsqft = ALLOW_BLANK;
		String jsonLink = U.getSectionValue(html, "$http.get(\"", "\"");
		U.log("Before" + url);
		String explrHtml = U.getHTML(url + "/explore");
		U.log(jsonLink);
		String jsonHtml = "";
		if (jsonLink != null)
			jsonHtml = U.getHTML("http://www.highlandhomes.com" + jsonLink);
		U.log("Jeson---" + jsonLink);
		jsonHtml=jsonHtml.replace("common areas, with", "");
		jsonHtml = jsonHtml.replace("calcPrice\":\"", "calcPrice\":\"$");
		
		//================= Price===========================
		String price[] = U.getPrices(	html + explrHtml + info,
						"calcPrice\":\"\\$\\d+|price\":\"\\$\\d+,\\d+|binding\">\\$\\d+,\\d+",	0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice + "---------------" + maxPrice);

		//================ Square feet ==============================
		String sqft[] = U.getSqareFeet(jsonHtml + html + explrHtml,
						"\\d,\\d+ to over \\d+ square feet|squareFootage\":\"\\d+|squareFootage\":\\d+|ng-binding\">\\d,\\d{3}</td>",	0);
		minsqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxsqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		String typeSec = U.getSectionValue(html, "<li class=\"nav-item-3\">","</body>");

		//========== Community Type ======================
		explrHtml = explrHtml.replace("Golf\"/> Golf</div>", "Golf\"/> Golf Course</div>");
		
		String communityType = U.getCommunityType(typeSec + jsonHtml+explrHtml);
		
		//============== Property Status =================
		String pStatus = ALLOW_BLANK;
		pStatus = U.getPropStatus((info + typeSec + jsonHtml).replaceAll("move|Move", ""));
		U.log("movePart"+movePart);
		if(movePart!=null)
		{
		movePart = movePart.replaceAll("Move In Ready Homes \\([1-8]+\\)",	"My Move In Ready");
		movePart = movePart.replaceAll("Move In Ready Homes \\(10\\)","My Move In Ready");
		movePart = movePart.replaceAll("Move In Ready Homes \\([1-9]\\)","My Move In Ready");
		if (movePart.contains("My Move In Ready")) {
			U.log("i am here");
			pStatus = "Move In Ready Homes";
		}

		}
		pStatus = U.getPropStatus(info+pStatus);//+"Now Selling"); //Now Selling from main page

		if(url.contains("http://www.horizonhomes.com/dfw/wylie/bozman-farms-50s-60s")){
			pStatus=pStatus+",Now Selling Phase 4"; //taken from image
		}

		//============ Property Type =========================
		String pType = U.getPropType(jsonHtml);
		
		//============= Derived Community Type ================
		String derivedPType = U.getdCommType(typeSec + jsonHtml + html	+ explrHtml);
		String arr[] = U.getValues(html, "<tbody>", "</tbody>");
		derivedPType = ALLOW_BLANK;
		boolean st1 = false, st2 = false, st3 = false;
		for (String item : arr) 
		{
			// U.log("stry"+item);
			String sec = item;

			String secValues[] = U.getValues(item, "<td class", "</td>");

			if (secValues[0].contains("1") && st1 == false) 
			{
				derivedPType = derivedPType + ",1 Story";
				st1 = true;
			}
			if (secValues[0].contains("2") && st2 == false) 
			{
				derivedPType = derivedPType + ",2 Story";
				st2 = true;
			}
			if (secValues[0].contains("3") && st3 == false) 
			{
				derivedPType = derivedPType + ",3 Story";
				st3 = true;
			}
		}
		if(url.contains("http://www.horizonhomes.com/houston/rosenberg/summer-lakes-50s"))
		{
			
            
			pType=pType.replace("Patio Homes",ALLOW_BLANK);
			
		}
		if(url.contains("http://www.horizonhomes.com/houston/houston/city-park"))
		{
			
			pType=pType.replace("Patio Homes",ALLOW_BLANK);
			
		}
		if(url.contains("http://www.horizonhomes.com/houston/houston/sommerall-park")||url.contains("http://www.horizonhomes.com/houston/cypress/stablewood-farms"))
		{
			
			pType=pType.replace("Patio Homes",ALLOW_BLANK);
			
		}
		derivedPType = derivedPType.replace("-,","");
		pType=pType.replace("-,","");
		U.log("Name:::"+name);
		derivedPType = U.getdCommType(derivedPType+name);
		U.log("Dtype::"+derivedPType);
		U.log(U.getCache(url));
		String noteVar = U.getnote(html);
        add[0]=add[0].replaceAll("\\.", "");
		
		data.addCommunity(name.toLowerCase(), url, communityType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(noteVar);
	}j++;
	}
	/*
	 * catch (Exception e){
	 * 
	 * }
	 */

}