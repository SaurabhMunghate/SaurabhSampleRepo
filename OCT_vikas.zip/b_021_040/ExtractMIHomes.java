package com.shatam.b_021_040;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.function.Predicate;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.URLConnection;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;
//import javax.xml.crypto.dsig.CanonicalizationMethod;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.text.StrTokenizer;
import org.apache.commons.lang3.StringEscapeUtils;
import org.bouncycastle.crypto.modes.CCMBlockCipher;
import org.json.*;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
//import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMIHomes extends AbstractScrapper {
	public ExtractMIHomes() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}
	static int subComCoun=0;
	int counter = 0;
	static int count = 0;
	CommunityLogger LOGGER;
	WebDriver driver;

	private static String builderName = "MI Homes";
	private static String builderUrl = "https://www.mihomes.com";

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractMIHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + builderName + ".csv", a.data().printAll());
		
	}

	private static DateTimeFormatter readyDateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
	private static LocalDate todayDate = LocalDate.now();
	
	private static Predicate<String> isMonthReadyHome = (readyDate)-> {
		
		LocalDateTime inputReadyDate = LocalDateTime.parse(readyDate, readyDateFormatter);
		
		if(todayDate.getYear() < inputReadyDate.getYear())return false; //test weather ready date year is greater than current year
		if(todayDate.getYear() > inputReadyDate.getYear())return true; //test weather ready date year is less than current year, then we are considering the ready now homes.
		
		int monthDiff= Period.between(todayDate, inputReadyDate.toLocalDate()).getMonths(); //test ready date for current month		
		if(monthDiff <= 0)return true; //if it is for current month or previous months
		return false;
	};

	
	@Override
	protected void innerProcess() throws Exception {

//		{	
//			U.log("I ki value"+i);
	//dt 17 may 2022
//	    U.setUpChromePath();
//		driver = new ChromeDriver();
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String communityJson = getHtml("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?search=United%20States%20of%20America&typeahead_type=markets&x1=65.30096673187684&x2=-8.967737863249164&y1=-25.70126971616196&y2=-161.93173846616196&zoom=3",driver);//
		// WRNgString
		// communityJson=U.getPageSource("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?search=United%20States%20of%20America&typeahead_type=markets&x1=65.30096673187684&x2=-8.967737863249164&y1=-25.70126971616196&y2=-161.93173846616196&zoom=3");
		U.log(U.getCache(
				"https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?search=United%20States%20of%20America&typeahead_type=markets&x1=65.30096673187684&x2=-8.967737863249164&y1=-25.70126971616196&y2=-161.93173846616196&zoom=3"));
		U.log("main JZSON URL== "
				+ "https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?search=United%20States%20of%20America&typeahead_type=markets&x1=65.30096673187684&x2=-8.967737863249164&y1=-25.70126971616196&y2=-161.93173846616196&zoom=3");
	

	//	}//dt2
//		U.setUpChromePath();
//		driver = new ChromeDriver(); 
		String CommJson=U.getSectionValue(communityJson, "pre-wrap;\">", "</pre></body></html>");
		JsonParser parser =new JsonParser();
		Object obj=parser.parse(CommJson);
		JsonObject commJsonObj = (JsonObject)obj;
		
	//	String data=(String)parser.parse(results);
		JsonArray array=(JsonArray)commJsonObj.get("results");

		U.log("Total Communities"+array.size());
		for(int i=0;i<array.size();i++) {
			String homesData1="";
			String quickdata1="";
			JsonObject community=(JsonObject) array.get(i);
			String url=community.get("url").getAsString();
			url=builderUrl+url;
//			U.log("main Comm url"+url);
		//	if(!url.contains("/new-homes/florida/sarasota-metro/palmetto/trevesta"))continue;		
			String commSec1=community.toString();
			//String commSec1=stringify(community);
			String mainCommName=community.get("name").getAsString();
			String homeDataSection=getHtml("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(mainCommName, StandardCharsets.UTF_8.toString())+"&searchtype=plans&typeahead_type=markets",driver);
//			U.log("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(mainCommName, StandardCharsets.UTF_8.toString())+"&searchtype=plans&typeahead_type=markets");
//			U.log("HOMES DATA CACHE"+U.getCache("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(mainCommName, StandardCharsets.UTF_8.toString())+"&searchtype=plans&typeahead_type=markets"));
			String homeDataSec=U.getSectionValue(homeDataSection,"pre-wrap;\">", "</pre></body></html>");
			JsonObject homeData=null;
			if(homeDataSec!=null)
				homeData=(JsonObject)parser.parse(homeDataSec);
			homesData1 = homeData+"";
			//U.log("Hpome data Json"+homeData.toString());
//			U.log("total home plans"+homesPlan.size());
//			for(int k=0;k<homesPlan.size();k++) {
//				JSONObject home=new JSONObject(homesPlan);
//				 homesData+=" "+home.toString();
//			}
			
			String quickHome1=getHtml("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(mainCommName, StandardCharsets.UTF_8.toString())+"&searchtype=inventory&typeahead_type=markets",driver);
//			U.log("quickHome1 DATA CACHE"+U.getCache("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(mainCommName, StandardCharsets.UTF_8.toString())+"&searchtype=inventory&typeahead_type=markets"));
			
			String quickHome=U.getSectionValue(quickHome1, "pre-wrap;\">", "</pre></body></html>");
			JsonObject quickHomesobj=null;
			if(quickHome!=null)
				quickHomesobj=(JsonObject)parser.parse(quickHome);
			quickdata1=quickHomesobj+"";
			

			
			
			
			
			JsonArray series=(JsonArray)community.get("series");
//			U.log("total Series"+series.size());
			subComCoun+=series.size();
			if(series.size()>0) {
				for(int j=0;j<series.size();j++) {
					String homesData2="";
					String quickdata2="";

					
					JsonObject subComm=(JsonObject)series.get(j);
					String subCommUrl=subComm.get("Url").getAsString();
					String subCommId=subComm.get("Id").getAsString();
					subCommUrl=builderUrl+subCommUrl;
	//				U.log("sub Comm url"+subCommUrl);
					String subComName1=subComm.get("Name").getAsString();
					
				//	U.log("subComName1 ::"+subComName1);
					String subComName=mainCommName+" - "+subComName1;
					String homeDataSub="";
					String commSec2=subComm.toString();

					//home plans data\if
					if(homeData!=null){
						JsonArray arr=(JsonArray)homeData.get("results");
						for(JsonElement ele: arr) {
							String data = ele+"";
	//						U.log("MM!"+data);
							
						//	if(data.contains(subComName.replace(("-"+mainCommName), "").trim())) {
							if(data.contains(subComName1))	{//The
						//	U.log("DATAChk::::::::::"+data);
								homesData2+=data;
							}
						}
					}
					// quick homes data
	//				quickHomesobj
					if(quickHomesobj!=null) {
						JsonArray quickarr=(JsonArray)quickHomesobj.get("results");
						for(JsonElement ele: quickarr) {
							String data = ele+"";
		//					U.log(data);
							//if(data.contains(subComName.replace(mainCommName, "").trim())) {
							if(data.contains(subComName1)) {
		//						U.log("DATA::::::::::"+data);
								quickdata2+=data;
							}
						}
					}
				    //addDetails(subComm,subCommUrl,community,subCommId);
	//				U.log(homesData);
					addDetails(subCommUrl,commSec1,commSec2,homesData2,quickdata2,subComName);//+commSecc1
				}
			}
			else {
				
				addDetails(url,"",commSec1,homesData1,quickdata1,mainCommName); // for main  comm
			}	
		
		}		//dt
		U.log("TotalComm -> " + (array.size()+subComCoun));
		LOGGER.DisposeLogger();
//date 17 may22		
		driver.quit();
	//}
	//i++;
	}
	// TODO :
	private void addDetails(String commUrl, String commSec1,String commSec2,String homeplan,String quickHomeData, String commName) throws Exception {

		
//	if (!commUrl.contains("https://www.mihomes.com/new-homes/michigan/metro-detroit/shelby-township/valencia-of-shelby"))return;
//		if(count >=100 && count <= 150)
//		if(count>=210)
//		try{
		{	
//			U.log("==============================\n"+commSec);
			U.log("==============================\n");

			U.log("Name:"+commName);
			if (commUrl.contains("https://www.mihomes.com/new-homes/texas/greater-austin/austin/hills-at-estancia"))	{
				LOGGER.AddCommunityUrl(commUrl+"===============Community No Longer Available ===========");
				return;
			}
			
		//U.log("HH"+homeplan);
		U.log(U.getCache(commUrl));
		U.log("========================\nComm Count --> "+count);
		
		U.log("Comm Url --> "+commUrl);
		String myUrl;
		//U.log("Com Section : "+commSec);
		String commHtml = U.getHtml(commUrl,driver);
		FileUtil.writeAllText("/home/shatam12/Desktop/vi.txt", commHtml);
		String html2=commHtml;
	
		if(commHtml==null) {	
//			U.log(">>>>>>>>");
			LOGGER.AddCommunityUrl(commUrl+ "-----------------site is not open----------------");
			return;
		}
		String subName=ALLOW_BLANK;
		String subCommNameSec[]=commName.split("-");
		U.log("sbCommS="+subCommNameSec.length);
		if(subCommNameSec.length>1)
		   subName=subCommNameSec[1].trim();
		
		U.log("sssName"+subName);
		//for add june
//		String jsnAddSec=U.getSectionValue(html2,"\"url\": "+commUrl+"\"", "\"geo\":");
		if(commUrl.contains("https://www.mihomes.com/new-homes/ohio/central-ohio/dublin/jerome-village-pearl-creek/series/regency-collection"))
			subName="Regency Collection";
		if(commUrl.contains("https://www.mihomes.com/new-homes/ohio/central-ohio/dublin/jerome-village-pearl-creek/series/signature-collection"))
			subName="Signature Collection";
		
		
		
		String[] UnwantedJson=U.getValues(commHtml,"<script type=\"application/ld+json\">{","}</script>");
		for(String Ujsn:UnwantedJson) {
			commHtml=commHtml.replace(Ujsn,"");
		}

		String pric=U.getHtmlSection(commHtml, "class=\"product-flag product-flag-blue  \"", "</u>");
		U.log(pric);
		if(pric==null) {
			pric=ALLOW_BLANK;
		}
		pric=pric.replace("$400s", "$400,000");
		
		if (data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		String linkSec = U.getSectionValue(commHtml, "<div class=\"link-block-community-series\">", "</a>");
		if(linkSec != null)
			commHtml = commHtml.replace(linkSec, "");
		
		String nearBy = U.getSectionValue(commHtml, "id=\"neraby\">", "</a>");
		if(nearBy != null)
		commHtml = commHtml.replace(nearBy, "");
		String explore = U.getSectionValue(commHtml, "Explore similar communities", "</html>");
		if(explore ==null)explore = U.getSectionValue(commHtml, " Explore Other Home Series ", "</html");
		if(explore != null)
		commHtml = commHtml.replace(explore, "");
	
		String rem = U.getSectionValue(commHtml, "<head>", "</head>");
		if(rem != null) commHtml = commHtml.replace(rem, "");
		
		commHtml = commHtml.replaceAll("<meta itemprop=\"priceRange\" content=\"\\d+-\\d+\" />", "");
				
		U.log("commNamw"+commName);
		String comName1 = commName;
		
		String geo="FALSE";
		String lat=U.getSectionValue(commSec1+commSec2, "\"Latitude\":", ",");
		String lon=U.getSectionValue(commSec1+commSec2, "\"Longitude\":", "}");
		
		if (lat==null) {
			String latlngSec=U.getSectionValue(commSec1+commSec2, "\"https://maps.google.com/maps?", "_blank\">");
			if((latlngSec!=null)) {
			lat=U.getSectionValue(latlngSec, "q=", ",");
			lon=U.getSectionValue(latlngSec, ",", "\"");
			}
		}
		if (lat==null) {
			String latlngSec=U.getSectionValue(commHtml, "\"https://maps.google.com/maps?", "target=\"_blank\">");
			if((latlngSec!=null)) {
			lat=U.getSectionValue(latlngSec, "q=", ",");
			lon=U.getSectionValue(latlngSec, ",", "\"");
			}
		}
		
		if (lat==null) {
			lat=U.getSectionValue(commHtml, "itemprop=\"latitude\" content=\"", "\"");
			lon=U.getSectionValue(commHtml, "itemprop=\"longitude\" content=\"", "\"");
		}
		//U.log("CommHtml"+commHtml);
		if(lat==null) {
			lat=U.getSectionValue(commHtml, "\"latitude\":",",");
			lon=U.getSectionValue(commHtml, "\"longitude\":", "},");
		}
		if(lat==null) {
			lat=U.getSectionValue(commHtml, "\"Latitude\":", ",");
			lon=U.getSectionValue(commHtml, "\"Longitude\":", "}");
		}
		if(lat==null) {
			String latlngSec=U.getSectionValue(commHtml, "\"https://www.google.com/maps/dir/", "_blank\">");
			if(latlngSec!=null) {
			lat=U.getSectionValue(latlngSec, "/", ",");
			lon=U.getSectionValue(latlngSec, ",", "/");
			}
		}
		String[] Latlng= {lat,lon};
		commHtml=commHtml.replace("South Carolina", "SC").replace("North Carolina", "NC");
		commSec1=commSec1.replace("South Carolina", "SC").replace("North Carolina", "NC");

        U.log("Latlng======"+Arrays.toString(Latlng));

		String addSec=U.getSectionValue(commHtml, "itemprop=\"address\" content=\"", "\" />");
		if(addSec==null)addSec=U.getSectionValue(commSec1, "target=\"_blank\">", "</a>");
		if(addSec==null)addSec=U.getSectionValue(commHtml, "<a class=\"event-click button-plain gami-directions-exit\"", " </div>");
		if(addSec!=null && addSec.contains("data-event-category=\"external-map\""))addSec = U.getSectionValue(addSec, ">", "<");

		if(addSec==null)addSec=U.getSectionValue(commSec1, "itemprop=\"address\" content=\"", "\" />");
      //  if(addSec==null)addSec=U.getSectionValue(commHtml, "<a class=\"event-click button-plain gami-directions-exit\"", "</a>");
		
		//		if(addSec.length()<4) addSec= null;
		U.log("addSe11111c=="+addSec);
		//////////

		if(addSec==null) addSec=U.getSectionValue(commSec1, "var address = \"", "\";");
		U.log("addSec=="+addSec);
		
		if(addSec==null || addSec.length()<4) addSec = U.getSectionValue(commHtml, "var address = \"", "\";");
		if(addSec==null)addSec=ALLOW_BLANK;
		
		String add[]=U.getAddress(addSec.replace(" Drive Minnetrista", " Drive, Minnetrista").replace(", Winter", ", Winter Garden").replace(", ,", ",").replace("&amp;", "&").replace("&#39;", "'"));
		
	
		
		/// dt june if(addSec==null || add[0].length()<2)
	   if(add[0].length()<2)
		{
			U.log("Hello in here");
			if(addSec != null)
				addSec = U.getSectionValue(html2, "var address = \"", "\"");
			U.log("addSec=="+addSec);

			if(addSec!=null){
				addSec = addSec.replace(" Drive Minnetrista", " Drive, Minnetrista");
				add = U.getAddress(addSec.replace("Holly Springs", ",Holly Springs").replace(" Parrish", ", Parrish"));
			}
		}
	   
		if(add[0].length()<2|| add[0]==ALLOW_BLANK) {
			
			String jsnAddSec=U.getSectionValue(html2,"\"name\": \""+subName+"\"", "\"geo\":");

//			U.log("ADDSC= "+jsnAddSec);
			U.log("hello enter" );
//			add[0]=U.getSectionValue(commSec1, "\"StreetAddress\":\"", "\"");
//			add[1]=U.getSectionValue(commSec1, "\"City\":\"", "\"");
//			add[2]=U.getStateAbbr(U.getSectionValue(commSec1, ",\"State\":\"", "\""));
//			add[3]=U.getSectionValue(commSec1, "\"Zip\":\"", "\"");
			
			add[0]=U.getSectionValue(jsnAddSec, "\"streetAddress\": \"", " \"");
			add[1]=U.getSectionValue(jsnAddSec, "\"addressLocality\": \"", "\"");
			add[2]=U.getStateAbbr(U.getSectionValue(jsnAddSec, "\"addressRegion\": \"", "\""));
			add[3]=U.getSectionValue(jsnAddSec, "\"postalCode\": \"", "\"");
			U.log("Inner add"+Arrays.toString(add));

		}
		
		add[0]=add[0].replace("Paza Drive/Wilkinson Drive", "Paza Drive & Wilkinson Drive");
		U.log("Address: "+Arrays.toString(add));
//		String InventoryHomeCount=U.getSectionValue(commSec, "\"Inventory\":\"", "\"");
	//	U.log("comsec: "+commSec);
		//=================Old Value
		String[] oldPrice = U.getValues(commHtml, "home-card-price-old\">", "</span>");
		
		if(oldPrice!= null)
			for(String price : oldPrice) {
				
				commHtml = commHtml.replace(price, "");
			}
		String homePlanData="";

		//String platmapHtm = getHtml(("https://www.mihomes.com/"+U.getSectionValue(commHtml, "<a class=\"button button-icon-right event-click gami-siteplan-view\" href=\"", "\""),driver);
		
//		U.log("https://www.mihomes.com/"+U.getSectionValue(commHtml, "<a class=\"button button-icon-right event-click gami-siteplan-view\" href=\"", "\""));
		myUrl="https://www.mihomes.com"+U.getSectionValue(commHtml, "<a class=\"button button-icon-right event-click gami-siteplan-view\" href=\"", "\"");

		U.log(myUrl);
		U.log(U.getCache(myUrl));
		
		String platmapHtm = getHtml(myUrl.replace("amp;", ""), driver);
		
		
		if(platmapHtm==null) platmapHtm = ALLOW_BLANK; 
		String homesDataFromPlatmap[] = U.getValues(platmapHtm, "{\"categoryid\"", "}");
		U.log(homesDataFromPlatmap.length);
		if(homesDataFromPlatmap.length!=0) {
			String comid=U.getSectionValue(platmapHtm, "G.communityID = '", "'");
			for(String plan: homesDataFromPlatmap) {
				if(plan.contains("#c6c7c9")|| plan.contains("#d30e45") || plan.contains("#f26633")|| plan.contains("#ffc650"))continue;
//				U.log("HOME ID pplan"+plan);
				String homeid = U.getSectionValue(plan, "javascript: showInfo('", "'");
//				U.log(plan);
				if(homeid==null || homeid.length()<4)continue;
				//U.log("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api-Controllers/PlatMapDetailApi/"+plan+"?community="+comid);
				String htm = getHtml("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api-Controllers/PlatMapDetailApi/"+homeid+"?community="+comid,
						driver);
				//while(check) {
				myUrl="https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api-Controllers/PlatMapDetailApi/"+homeid+"?community="+comid;
//				U.log("Home plan DFata"+U.getCache(myUrl));
		
				if(htm.contains(commUrl))
				  homePlanData+=htm;
				
				
			}
		}//}}
		String noOfUnits=ALLOW_BLANK;
	    int lotCount=0;
	    if(commHtml.contains("Become a part of this community")) {
	   
	    String[] lots=U.getValues(platmapHtm, "<polygon fill=", "</g>");
	    lotCount=lots.length;
	    U.log("No . Lots== "+lotCount);
	    noOfUnits=Integer.toString(lotCount);  
	    
	    if(noOfUnits.contains("0"))
	    	noOfUnits=ALLOW_BLANK;
	    }
		

		
		//date feb 2022
		
		String myQuickSec=U.getSectionValue(commHtml,"data-toggle-button=\"#quick-move-in","</button>");
		int qval=0;
		if(myQuickSec!=null) {
		String numOfQuick=U.getSectionValue(myQuickSec, "<span class=\"text\">Quick Move-In</span>",")");
		numOfQuick=numOfQuick.replace("(","");
		U.log("numofQuicl"+numOfQuick);
		numOfQuick=numOfQuick.trim();
		qval=Integer.parseInt(numOfQuick);
		//-qval=Util.match(numOfQuick, "\\d+");
		}/// date feb 2022
		

		String modelHomeData="";
		String modelHome=null;
		
		 modelHome=getHtml("https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(commName, StandardCharsets.UTF_8.toString())+"&searchtype=models&typeahead_type=markets",driver);
//		U.log("MODELHOME****"+"https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(commName, StandardCharsets.UTF_8.toString())+"&searchtype=models&typeahead_type=markets");
	//	}
		myUrl="https://www.mihomes.com/sitecore/api/ssc/MIHomes-Feature-Website-Api/Search?community="+URLEncoder.encode(commName, StandardCharsets.UTF_8.toString())+"&searchtype=models&typeahead_type=markets";
	
		
		//end of mu=yncode
		String modelHomes[]=U.getValues(modelHome, "{\"id\":\"", "\"IsActive\":true");
		U.log("ModelHome--->"+modelHomes.length);
		for (String homesPlan : modelHomes) {
			String dataUrl="https://www.mihomes.com"+U.getSectionValue(homesPlan, "\"url\":\"", "\"");
		//	U.log("ModelHomeURl:-> "+dataUrl);
			String data=getHtml(dataUrl,driver);
		
			if(data!=null) 
				modelHomeData+=homesPlan+U.getSectionValue(data, "<section class=\"plan-specification\">", "<div class=\"contact-card__main-information\">");
			else
				modelHomeData+=homesPlan;
		}
		
		homePlanData +=homeplan;
		//U.log("plandata"+homePlanData);
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		commHtml = U.removeSectionValue(commHtml, "<a class=\"featured-grid-item-content", "</html");
		
		commHtml=commHtml.replaceAll("<span class=\"calculator-slider__value\">\\$\\d+</span>|data-default=\"259990\"", "")
				.replace("$500s to $1M", "Mid $500,000 to $1,000,000").replaceAll("Mid \\$(\\d{3})s to \\$(\\d)M", "Mid \\$$1,000 to \\$$2,000,000")
				.replaceAll("start in the 300's", "start in the $300,000")
				.replace("$400s", "$400,000")
				.replace("starting in the upper 300s", "starting in the upper 300,000").replace("$747,060", "").replace("747060", "")
				.replace("upper $400s", "upper $400,000").replace("from the $300s to $500s", "from the $300,000 to $500,000");
		
		commHtml=commHtml.replace("$400&#39;s", "From the $400,000").replaceAll("0&#39;s|0's|0’s|0s|0k", "0,000");
		
		commHtml = commHtml.replaceAll("\\$300,000.\" />", "").replaceAll(" \"priceRange\": \"\\$511995-651995\",", "");
		
		
	
		
		if(homePlanData!=null)homePlanData = homePlanData.replaceAll("\"Price\":\\d+|content=\"\\$\\d+ - \\$\\d+", "")
				.replace("\"doNotPublish\":false,\"salePrice\":\"$298,585", "");
		
		if(quickHomeData!=null)quickHomeData = quickHomeData.replaceAll("\"Price\":\\d+|content=\"\\$\\d+ - \\$\\d+", "");
		

		String pricesection = ALLOW_BLANK;
		if(commHtml.contains("<span class=\"text\">Quick Move-In</span>"))
			pricesection=commHtml+quickHomeData+homePlanData;
		else
			pricesection=commHtml+homePlanData;

		
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((commHtml),"[\\s\\w\\W]{30}\\$400[\\s\\w\\W]{30}", 0));
		
		
		pricesection=pricesection.replaceAll("<meta itemprop=\"priceRange\" content=\"\\$?\\d+\\s?-\\s?\\$?\\d+\" />", "");
		
		//U.writeMyText(homePlanData);
		String priceheader=U.getSectionValue(commHtml, "<div class=\"product-header-price\">", "</span>");
		String prDesc=U.getSectionValue(commHtml, "<meta property=\"og:description\"", "/>");
//		U.log("Myp[rSec"+prDesc);
		if(prDesc!=null)
		prDesc=prDesc.replaceAll("0s|0's", "0,000");
//      U.log("priceCDKFGH "+Util.matchAll(commHtml+quickHomeData+homePlanData,"[\\w\\W\\s]{100}354900[\\w\\W\\s]{100}", 0));
//		String prices[]=U.getPrices((pricesection), 
//				"Starting at \\$\\d{3},\\d{3}|\"minPrice\": \\d{6,7}.0,|starting in the upper \\d+,\\d+|price of \\$\\d+,\\d+|Mid \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|Starting in the \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|low \\$\\d+,\\d+|mid \\$\\d{3},\\d{3}|\"Price\":\\d{6,7},|under \\$\\d{3},\\d{3}|\"minPrice\":\\d{6,7}.0,|From the \\$\\d{3},\\d{3}|the High \\$\\d{3},\\d{3}|start in the \\$\\d{3},\\d{3}|<span class=\"home-card-price\">\\s*<span>\\$\\d,\\d{3},\\d{3}</span>\\s*</span>|Priced from:\\s*<span>\\s*<span itemprop=\"price\" content=\"\\d{6,7}\">\\$\\d,\\d{3},\\d{3}</span>|<span class=\"home-card-price\">\\s*<span>\\$\\d{3},\\d{3}</span>|Starting at\\s*<span class=\"home-card-price\">\\s*<span>\\$\\d{3},\\d{3}</span>|price\" content=\"\\d{3},\\d+\">\\$\\d{3},\\d+|price\" content=\"\\d+\">\\$\\d{3},\\d+|home-card-price\">\\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|salePrice\":\"\\$\\d{3},\\d{3}\"|<span>\\$\\d{3},\\d{3}", 0);
		U.log(pric);
		
		String prices[]=U.getPrices((pric+pricesection+priceheader+prDesc).replace("747060", "").replace("747,060", ""),
				"\\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} </li>|start in the upper \\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|Priced from:\n\\s*<span>\\$\\d{3},\\d{3}</span>|\\$\\d{3},\\d{3}</li>|Starting at \\$\\d{3},\\d{3}|\"StartingPrice\":\\d{6}",0);
		
		
		//		U.log(Arrays.toString(prices));
//		U.log("quickHomeData====\n"+quickHomeData);
		



		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		String minSqf=ALLOW_BLANK;
		String maxSqf=ALLOW_BLANK;
		
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
		
		
		if(commUrl.contains("https://www.mihomes.com/new-homes/texas/greater-san-antonio/san-antonio/winding-brook/series/40-smart-series")) maxPrice="$360,990";
		
		commHtml = commHtml.replaceAll("Sq Ft\\s*<span class=\"home-card-meta-value\">\\s*2,051 - 2,060", "from 2,051 sq. ft. to 2,060 sq. ft.");
		
		//quickHomeData
		String description=U.getSectionValue(commHtml, "<div class=\"product-header-row product-header__top\">", "<h2 id=\"product-homes-list\">");
        if(description==null)description=U.getSectionValue(commHtml,"<div class=\"product-header-row product-header__top\">","<h3>Overview</h3>");
        
   //     U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((description+homePlanData+modelHomeData+quickHomeData+commHtml+prDesc),"[\\s\\w\\W]{60}3,012[\\s\\w\\W]{100}", 0));
		if(description!=null)
        description=description.replace("size from 1,800 to 2,800+ square feet","size from 1,800 to 2,800 square feet").replace("size from 2300 - 3900+ square feet", "size from 2300 - 3900 square feet").replace("2,242 square feet to 4,099+ square feet","2,242 square feet to 4,099 square feet");
		String sqft[]=U.getSqareFeet((description+homePlanData+modelHomeData+quickHomeData+commHtml+prDesc).replace("and 1,947", "").replaceAll("new 96,000 square foot Celina Campus|golf course boasts a 32,000 square foot|homesites, range from 2,200-4,100 square feet|the Reserve Series offers 1,800 to 3,300 square feet", "").replace("27,000 Square Foot Clubhouse", ""), 
				"\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} to just over \\d{1},\\d{3} square feet|\\d{1},\\d{3}-\\d{1},\\d{3} sq.ft.</li>|\\d,\\d{3} sq. ft. to \\d,\\d{3}\\+ sq. ft.|from \\d,\\d{3} - \\d,\\d{3}\\+ square feet |\\d,\\d{3} SF|ranging from \\d,\\d{3} to \\d,\\d{3} standard square feet|\\d,\\d{3} to \\d,\\d{3} square foot|\\d,\\d{3} square feet to \\d,\\d{3} square feet|\\d,\\d{3} sq. ft.|from \\d,\\d{3}-\\d,\\d{3} sq. ft.|\"MinSqft\":\\d{4}|\\d,\\d{3} to \\d,\\d{3} sq. ft.|spacious \\d,\\d{3} sq. ft. |starting at \\d,\\d{3} sq. ft.|\\d,\\d+ to \\d,\\d+ square feet,|square footage from \\d,\\d+ to \\d,\\d+|\\d,\\d+ to nearly \\d,\\d+ square feet|size from \\d{4} - \\d{4} square feet|size from \\d,\\d{3} to \\d,\\d{3} square feet|range from \\d,\\d{3} to \\d,\\d{3} square feet|over \\d,\\d+ square feet to over \\d,\\d+ square feet|\\d{1},\\d{3} square foot|Ranging from \\d,\\d{3} - \\d,\\d{3} square feet|from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq ft.|range from \\d,\\d{3} square feet to \\d,\\d{3}\\ square feet|\\d,\\d{3} to \\d,\\d{3} sq ft|square footage ranges from \\d,\\d{3} – \\d,\\d{3}|\"square\":\"\\d,\\d{3}-\\d,\\d{3}|[from|between] \\d,\\d+ sq. ft. to \\d,\\d+ sq. ft.|\\d,\\d+-\\d,\\d+ square feet|square footage range of \\d,\\d{3} to \\d,\\d{3}|\"square\":\"\\d,\\d{3}\",|\"square\":\"\\d,\\d{3}-\\d,\\d{3}\"|from \\d{4} up to \\d{4} square feet|from \\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft. |Sq Ft\\n*\\s*<span class=\"home-card-meta-value\">\n*\\s*\\d,\\d{3}|\\d,\\d{3} – \\d,\\d{3} square feet|\\d,\\d{3}-\\d,\\d{3} square feet | \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} sq-ft |\\d,\\d{3} to over \\d,\\d{3} square feet|<p class=\"home-card-meta-item\">Sq Ft\\s*<span class=\"home-card-meta-value\">\\s*\\d{3,4}\\s*</span>|<p class=\"home-card-meta-item\">Sq Ft\\s*<span class=\"home-card-meta-value\">\\s*\\d,\\d{3} - \\d,\\d{3}\\s*</span>|<dd>\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}\\s*\\n*\\s*</span>\\s*\\n*\\s*Sq Ft|\\d,\\d{3} sq ft|\\d{4} sq ft|\\d{4}\\s*\\n*\\s*</span>\\s*\\n*\\s*Sq Ft|Sq. Footage</dt>\\s*\\n*\\s*<dd>\\d,\\d+</dd| \\d,\\d+ square feet|over \\d,\\d{3} square feet|\\d,\\d{3} sq.ft. condos", 0);
		
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((description+homePlanData+modelHomeData+quickHomeData+commHtml+prDesc),"[\\s\\w\\W]{30}500[\\s\\w\\W]{30}", 0));


		
		U.log("Sqft "+Arrays.toString(sqft));
		
		
		if(commUrl.contains("https://www.mihomes.com/new-homes/ohio/greater-cincinnati/batavia/estrella/series/smart-series"))
		{
			sqft[0]="1700";
			sqft[1]="3000";
		}
		if(commUrl.contains("https://www.mihomes.com/new-homes/florida/tampa-bay-area/zephryhills/cobblestone")) {
			sqft[0]="1556";
			sqft[1]="3531";
		}
		
//		if(commUrl.contains("https://www.mihomes.com/new-homes/illinois/chicagoland/naperville/chelsea-manor")) {
//			minPrice="$2900000";
//		}
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		String mainSec=U.getSectionValue(commHtml, "<div class=\"product-header\">", "d=\"communityInfo\" data-subnav-page-link=\"Community Information\"");
		if(mainSec==null)mainSec = U.getSectionValue(commHtml, "<div class=\"product-header-subnav-spacer\"", "<div class=\"content-sidebar-right\">");
		//================================================================CommTYPE========================================
		
		String driverSec = U.getSectionValue(commHtml, "<div class=\"faq__question-item driving-directions\">", "</div>");
		if(driverSec!=null)
			commHtml = commHtml.replace(driverSec, "");
		
		String neighbour = U.getSectionValue(commHtml, "<div class=\"box box-full box-last box-dark\">", "<div class=\"box box-full box-no-padding-top-bottom \"");
		if(neighbour!=null)
			commHtml = commHtml.replace(neighbour, "");
		commHtml=commHtml.replace("Oneka Ridge Golf Course are just down the road","");
//		String communityType=U.getCommunityType((commSec+U.getNoHtml(commHtml)).replaceAll("Weaver Lake Community Park|Run Golf Club|Summerlake|lakefront town|Jordan Lake|Northlake community|Lakefront Park|Lakefront Lot|limited selection of wooded lakefront|Choose between stunning lakefront", ""));
//		
//		
//		if(commUrl.contains("https://www.mihomes.com/new-homes/michigan/metro-detroit/white-lake-township/trailside-meadow/series/single-family-collection")||commUrl.contains("https://www.mihomes.com/new-homes/michigan/metro-detroit/white-lake-township/trailside-meadow/series/ranch-series"))
//			communityType="Golf Course";
//		
//			
//		if(commUrl.contains("https://www.mihomes.com/new-homes/texas/dallas-fort-worth-metroplex/corinth/lake-sharon-estates"))communityType=communityType.replace("Golf Course,","Golf Course");
		//================================================================Note============================================
		commHtml = commHtml.replaceAll("Move into One of Our Final Homes|<title>Final Homes for Sale in Wake Forest|time of a pre-sale", "");

		String note=U.getnote(U.getNoHtml(commHtml).replaceAll("Pre-selling is anticipated to begin in the spring!|Pre-Selling New Townhomes Near Naperville in Spring 2022", ""));
		//================================================================PropType========================================
		comName1 = comName1.replace("/Cottages", "").replace("/bungalow", "").replace("Estate", "Estate home lots").replace("Executive", "executive home");
		if(homePlanData!=null)//replace(name, "")
		homePlanData = homePlanData.replace("/bungalow", "").replace("These custom-feel one", " Custom-feel ranch");
		if(mainSec!=null)
			mainSec=mainSec
			.replace("Gresham 3-Car Elevation Craftsman","")
			.replace("luxurious two-story homes", "luxury residential two-story homes")
			.replace("architectural styles range from traditional", "Traditional exterior")
			.replace("exteriors inspired by a modern farmhouse, craftsman, and traditional", "Farmhouse-inspired architectura,Craftsman style details,Traditional exterior")
			.replace("traditional to craftsman-style exteriors", "Traditional exterior,craftsman-styled exterior")
			.replace("Bethel Creek is now selling custom-feel", "a custom-quality")
			.replace("architectural styles such as traditional, craftsman", "Traditional exterior,craftsman-styled exterior")
			.replace("traditional Craftsman-style townhome","Traditional exterior,craftsman-styled exterior,townhome" )
			.replaceAll("luxurious Spring Series ", "luxury homes Spring Series").replace("home with convenience and luxury", "home with convenience and luxury homes")
			.replace("Traditional, Farmhouse, Manor and", "Traditional exterior , Prairie, Farmhouse , manor house").replace("Craftsman, Traditional, Farmhouse, Manor, and Artisan exterior styles","The Manors, -inspired architectura, Craftsman style details,Traditional exterior");
        String newdDesc=U.getSectionValue(commHtml, "<p class=\"marginless small\">","<a class=\"button-plain button-plain-alt");
		
        
     //   
        String comm_NameSec=U.getSectionValue(quickHomeData,"\"communitynames\":[", "]");
        String comm_SeriesSec=U.getSectionValue(quickHomeData, "\"communityseriesnames\":[", "]");
        if(comm_NameSec!=null) {
   //     	U.log("hOIIII");
        quickHomeData=quickHomeData.replace(comm_NameSec,"");
        }
        if(comm_SeriesSec!=null)
        {
    //     U.log("hOIIII2");
        quickHomeData=quickHomeData.replace(comm_SeriesSec,"");
        }
        String comm_NameSec2=U.getSectionValue(homePlanData,"\"communitynames\":[", "]");
        String comm_SeriesSec2=U.getSectionValue(homePlanData, "\"communityseriesnames\":[", "]");
        if(comm_NameSec2!=null) {
   //     	U.log("helllooooooo");
        	homePlanData=homePlanData.replace(comm_NameSec2,"");
        }
        if(comm_SeriesSec2!=null) {
    //    	U.log("helllooooooo2");
            	homePlanData=homePlanData.replace(comm_SeriesSec2,"");
        }
        

        
        //quickHomeData=quickHomeData.replaceAll("The Villas at Link Crossing|Villas at Wynne Farms", "");
        String pType=U.getPropType((comName1+mainSec+homePlanData+quickHomeData+modelHomeData+commName+newdDesc).replaceAll("elevation&mdash;traditional, craftsman, and farmhouse&mdash;the|elevations—traditional, craftsman, and farmhouse—|elevations—traditional, craftsman, and farmhouse—which|elevations&amp;mdash;traditional, craftsman, and farmhouse&amp;mdash;the opportunities|elevations—traditional, craftsman, and farmhouse—the", "").replaceAll("elevations&amp;mdash;traditional, craftsman, and farmhouse&amp;mdash;|cabinet colors|historic cabin|elevations—traditional, craftsman, and farmhouse—|village|Village|Drexel Elevation CO Cottage|Austin Elevation CO Cottage|Berkley Elevation CM Craftsman", "").replace("you prefer a 3- or 4-plex", "3-plex or 4-plex")
				.replace("From traditional  ", "traditional floorplans").replace("which is part of your HOA", "by Homeowner Association")
				.replace("Traditional Florida design", "traditional design").replaceAll("left onto IL-59/Cottage Street|rent a cabin|Apartment Therapy|Craftsman elevations |bungalow inspired exterior elevation|ncluding glamping, cabin rentals|/manor-series|/majestic-gardens|garden-style tub|garden style tub|garden tub|[m|M]ajestic [g|G]ardens|classic or bungalow inspired exterior elevation|farmhouse sink|cottage-collection|MillBridge - Cottage Collection|Carriage House Blvd take|[c|C]arriage-[h|H]ill|carriage hill|Carriage Hill", ""));
        if(commUrl.contains("https://www.mihomes.com/new-homes/minnesota/twin-cities/newport/bailey-meadows/series/hans-hagen-villa-collection"))
        {
        	pType="Single Family, Luxury Homes, Villas, Patio Homes";
        }
        if(commUrl.contains("https://www.mihomes.com/new-homes/texas/greater-san-antonio/san-antonio/fronterra-at-westpointe/series/heritage-series"))
        {
        	pType="Single Family, Villas";
        }
        	
        if(commUrl.contains("https://www.mihomes.com/new-homes/indiana/indianapolis-metro/greenwood/riley-meadows")) {
        	pType="Loft, Single Family, Flex Homes, Villas, Craftsman Style Homes";
        }
        	//================================================================Derived PropType================================
		if(mainSec==null) mainSec = "";
		mainSec=mainSec.replace("one- and two-story", " 1 Story  2 Story  ").replace("second-level bonus", "2 story");
		if(homePlanData!=null)
		homePlanData = homePlanData.replace("\"stories\":\"2\"", "2 Story").replace("\"stories\":\"1 \"", " 1 Story").replace("\"stories\":\"3\"", "3 Story");
		if(modelHomeData!=null)
		modelHomeData=modelHomeData.replace("The laundry room is also located on the first floor","");
//		U.log("SSS"+Util.matchAll((commSec1+commSec2+mainSec+homePlanData+quickHomeData+modelHomeData),"[\\w\\W\\s]{50}split-level[\\w\\W\\s]{50}",0));
	mainSec=mainSec.replace("This exclusive collection of single family, first-floor living homes", "This exclusive collection of single family, 1 story living homes");

		String dPType=U.getdCommType((commSec1+commSec2+mainSec+homePlanData+quickHomeData+modelHomeData).replaceAll("1.5-Story|1.5-story", "One-and-a-half story").replaceAll("Colonial elevation|Alamo Ranch|Branch|branchOf|floor|K Bar Ranch|Branch|branchOf|Arrowhead\\+Ranch|Arrowhead Ranch|Starkey Ranch|3 bedroom|4 bedroom|Long Lake Ranch|-ranch|Branch", "")
				.replaceAll("stories</span>\n\\s*<strong class=\"plan-specification-item__value\">\n\\s*", "stories ")
				.replaceAll("stories 1 - 2", "1 story, 2 story")
				.replaceAll("Colonial Trail|First Floor|Second Floor|Third Floor", "").replaceAll("This entire second floor is dedicated to your living space|Stained oak stairs from foyer to second floor|The stained oak stairs lead you from the front door to your main living area on the second floor|our main living area is located on the second floor","")
				.replace("\"stories\":\"1-1&lt;span&gt; &amp;#189&lt;/span&gt;\"", "1 1/2 story home").replaceAll("\"stories\":\"2\"", "2 Story").replace("\"stories\":\"1-2\"", "1 Story, 2 Story").replace("\"stories\":\"1\"", "1 Story"));
		

		
		if(commUrl.contains("https://www.mihomes.com/new-homes/texas/dallas-fort-worth-metroplex/prosper/lilyana")||commUrl.contains("https://www.mihomes.com/new-homes/texas/dallas-fort-worth-metroplex/corinth/lake-sharon-estates")) {
			dPType=dPType.replace(", 1.5 Story","");
		}
		
		U.log("dPType==="+dPType);
		//=================================================================PropStatus=====================================

		mainSec = mainSec.replace("Our first phase in Vista Ridge sold out fast", "Our first phase sold out fast");
//		commHtml =commHtml.replace("Re-Opening Fall 2021", "REOPENING FALL 2021");
		String tag = U.getSectionValue(commHtml, "<small class=\"product-flag-subtext\">", "<")+U.getSectionValue(commHtml, "<ul class=\"product-flags\">", "<div class=\"image-banner\">");
		
		mainSec = mainSec.replace("Coming in 2020", "Coming 2020")
				.replace("opening in fall 2020", "opening fall 2020").replace("Phase one of this highly desirable community sold out", "Phase one sold out").replace("Final Low-Maintenance Section of Homes in Saddle Club Just Released", "Final Section Just Released")
				.replace("just released its final section", "just released final section").replace("Phase two is opening this summer", "Phase two opening this summer")
				.replace("New Phase of Homesites Coming Soon", "New Phase Homesites Coming Soon").replace("opening in Spring 2020", "opening Spring 2020")
				.replace("Now selling a second phase", "Now selling second phase")
				.replace("just released a new section", "just released new section")
				.replace("first phase of homesites sold out", "first phase sold out")
				.replaceAll(" first phase of 79 new homes sold out", " first phase sold out")
//				.replace("New Phase of Single Family Homes Now Available!", "New Phase Now Available")
				.replace("new section of 60-foot and 70-foot homesites is now available", "new section now available").replaceAll("(W|w)ith over 160 lots|with our limited( |-)time|Selling Fast in Parkland|, move-in ready|Choose a quick|Coming Soon: New Single|maintenance are coming|lots coming in|ground and is selling", "");
		
	
		
		String flagsec[] = U.getValues(commHtml, "<span class=\"product-flag-text\">", "<");
		String flagStatus ="";
		for(String flag : flagsec)
			flagStatus+=" "+flag+" ";
//		U.log("flagStatus::::: "+flagStatus);
		
		if(flagStatus!=null) {
			flagStatus=flagStatus.replace("Coming Soon  New Homesites Coming Soon","New Homesites Coming Soon").trim();
			flagStatus = flagStatus.replace("Basement Homesites","Basement Homesites Available").replace("QUICK MOVE-IN HOMES COMING SOON","").trim();
		  //  flagStatus=flagStatus.replace("New Homesites","New Homesites Available").trim();
		}
		if(flagStatus==null)flagStatus=ALLOW_BLANK;
//		U.log("flagStatus222::::: "+flagStatus);
		//product-flag-text">Basement Homesites</span>
		commSec2 = commSec2.replace("<span class=\"product-flag-text\">Basement Homesites</span>", "<span class=\"product-flag-text\">Basement Homesites Available</span>")
				.replace("Final Section of Luxurious Homesites Just Released", "Final Section Just Released").replace("first phase of homesites sold out", "first phase sold out")
				.replaceAll("restaurants are now open|celebrated the Grand Opening|will be grand opening|will be ready to move into|Status</dt>\\s+<dd>Closeout|released for sale|community with over \\d+ lots", "");
//		U.log(commSec);
		String news = U.getSectionValue(commHtml, "<h4>Upcoming Events</h4>", "</article>");
		if(news == null) news = "";
		
//		U.writeMyText(tag+commSec+mainSec+flagStatus);
		String mainPageStatus="";
		
		mainPageStatus=U.getSectionValue(commHtml, "header-seo-h1", "</h1>");
		U.log(mainPageStatus);

		commSec2 = commSec2.replaceAll("they are selling fast", "");
		mainSec=mainSec.replace("Don't miss one of the final opportunities to make the move", "").replace("only a few opportunities remaining","only a few opportunities remain");
		
      if(commUrl.contains("https://www.mihomes.com/new-homes/texas/greater-san-antonio/live-oak/vista-ridge")) {
    	  tag=tag.replace("<span class=\"product-flag-text\">Coming Soon</span>", "");
      }
      
      String myStatSec=ALLOW_BLANK;
      String commStatSec=U.getSectionValue(commHtml, "<dt>Community Status</dt>","</dl>");//date feb 2022
      if(commStatSec!=null)
    	  myStatSec=U.getSectionValue(commStatSec,"<dd>","</dd>");
//      U.log("myStatSec  "+myStatSec);
		
//		U.log("LLLL"+Util.matchAll(tag+mainSec+flagStatus+mainPageStatus+myStatSec,"[\\w\\W\\s]{30}Now Available[\\w\\W\\s]{30}", 0));
		String pStatus=U.getPropStatus((tag+mainSec+flagStatus+mainPageStatus+myStatSec)
				.replaceAll("Graham models are now open|Model Grand Opening|Join us for the grand opening", "").replace("re currently selling from an", "")
				.replace("Andelina Farms Grand Opening Celebration", "").replace("amenity center is now open", "")
				.replace("A new phase of homes is coming this summer", "").replace("homes listed below are now available for sale","")
				.replace("anticipated new townhome community coming soon", "")
				.replaceAll("quick move|Quick Move|QUICK MOVE", "")
				.replace("Our homes in Novi, MI are move-in ready", "")
				.replace("see our available and coming soon homes", "")
			     .replace("New Phase of Single Family Homes Now Available!", "New Phase Now Available")
				.replaceAll("your last chance to own|Our model homes is now open| show up under Quick Move-In tab|and pool house coming soon|move right into a move-in ready home|QUICK MOVE-IN HOMES COMING SOON|Quick Move-In Homes Coming Soon", "")
				.replace("Opening Spring of 2022", "Opening Spring 2022")
				.replace("first phase of new Grandview Yard townhomes homes sold out", "first phase sold out")
				.replace(" coming towards the spring of 2022"," coming spring 2022")
				.replace("they're selling fast", "selling fast")
				.replace("it will appear in the Quick Move-In tab on this page", "")
				.replace("it will show up under Quick Move-In homes on this page","")
				.replace("before we are sold out","")
				.replace("20 spacious lots available","20 Lots Available")
				.replace("We expect to have more homesites available for sale in 2022.","")
				.replace("Re-Opening Spring 2022","")
				.replace(" selling out of our brand new mode", "")
				.replace("Check out our final new home opportunity for sale:", "")

				.replace("your home is move-in ready", "")
				.replace("quickly sold out of our second phase of homesites", "second phase sold out"));
//				.replace("second phase of homesites is selling fast", "second phase homesites selling fast").replaceAll("second and final phase|are move-in ready for you|dream home in our new phases now available| celebrated the Grand Opening|Coming This Fall|Choose a quick move|These move-in ready|Coming Soon on the West Side|OH—Only a Few Opportunities Remain|Villas Coming Soon|are coming soon to Estrella|homes coming soon for sale|Homes for Sale Coming Soon|before this luxurious new community is sold|Coming soon to Washington St|curated quick move-in home|sections are coming soon|uick move-in homes coming soon|nd your home is move-in ready|ready to move into come|shopping center just opened|about the new phase of homes coming soon|homesites coming soon to this community|homesites coming soon in Selwyn|and inventory homes are selling fast|community with just a final few opportunities|hurry as few opportunities remain|With \\d+ homesites available, Bolingbrooke|Designs Are Now|only a few remaining homes|County are Selling Fast|Now available at the Village|close with only a few opportunities remaining|new phase open with more homesites|right into a move-in|Springs Coming Soon|community coming|Coming Soon: New Smart|Coming soon to the area|community, coming|New Homes Coming|content=\"Coming|M/I Homes coming|they're selling|re now available for sale|move-in ready home - we’re just|New homesites are now available|Orlando - Limited Opportunities Remain|There are just a few remaining new homes |Stunning homesites are now available|Road and is currently selling from our|Coming soon to the northwest side |With only a few homes remaining, these wonderfu|New Construction Homes Coming Soon|Square is selling|Indiana Coming Soon|coming soon in Hendricks |summer! Our|summer! Sign|Move In|center will be opening|was just released|anticipated final phase|that are coming|, and grand opening information|, grand opening dates, |With phase two now selling, the Smart Series homes|Check out our move-in ready|Sports Park coming in 2020|enjoy coming summer|Section of Homes in Saddle Club Just Released|Bridgehaven is now open for sales|Affordable New Homes Available in Superior Township|until we are sold out|With only a few opportunities remaining, time|M/I will also offer quick move|homebuyers can tour one of our Quick Move|about this community with very limited|Now Selling by Appointment|uick move-in opportunities and floorplans |new homes now selling in Brownsburg|Schools Now Selling| before we are sold out|Development Coming Soon |model home coming soon|coming soon near|Near Geist: Final Section Just Released|phase of homesites is now|find the largest lots|See what lots|homesites were just released|plans coming soon|New Townhomes Coming Soon to Thriving Village|final new home opportunities in Carmel Creek|now available with many homesites|New home community with final homesites|Vista Ridge sold out|pool house coming soon|Coming soon, Cinco|Coming soon Cinco Lakes|amenity center coming soon|clubhouse are coming soon|community experts, as well as available Move-In Ready homes and opportunities|currently selling by appointment|are currently selling|new, coming soon|Estates Grand Opening\"|Model Grand Opening|New townhomes downtown are coming soon|entertainment options coming soon|menities are also coming soon|currently selling offsite by Appointment Only:|Model Grand Opening|Join us for the grand opening of the new model|Choose from a quick move-in home or build from the ground up|(services|model is|homesites are) coming|opportunity remains to build|Run is selling|Home Remains in Frisco|designs are now|are all sold|ready home is what|Move-In Ready|park, coming|Quick Move-In Homes Coming Soon", "")
//				.replace(news, "").replace("60-ft wide homesites available", "").replaceAll("New Phase of Single Family Homes Now Available|some partially wooded homesites available|update you on the current homesites available",""));
		
//		U.log("MMMMMMMMMMMMMMMMMM 45"+Util.matchAll((tag+commSec+mainSec+flagStatus+mainPageStatus),"[\\s\\w\\W]{100}Quick Move-in[\\s\\w\\W]{100}", 0));
		pStatus=pStatus.replace("New Homes Coming Soon, Coming Soon","New Homes Coming Soon");
		pStatus=pStatus.replace("New Homesites Coming Soon, Coming Soon", "New Homesites Coming Soon");
		
		pStatus=pStatus.replace("Opening Summer 2022, Coming Soon, Opening This Summer", "Opening Summer 2022, Coming Soon");

		
		U.log("pStatus 0= "+pStatus);
		pStatus=pStatus.replaceAll("Move-in Ready Homes|, Quick Move-in Homes|Quick Move-in Homes, |Quick Move-in Homes|, Quick Move-in|Quick Move-in, |Quick Move-in", "");
		
		if(pStatus.isEmpty()) {
			pStatus=ALLOW_BLANK;
		}
		U.log("pStatus1::::::::::::::::"+pStatus);
		
	
		/////=================================communityType====================
		
		commHtml=commHtml.replace("the Park Collection and Lakeside Collection", "the Park Collection and lakeside living Collection");

		
		String communityType=U.getCommunityType((commSec1+tag+U.getNoHtml(commHtml)).replaceAll("Weaver Lake Community Park|Run Golf Club|Summerlake|lakefront town|Jordan Lake|Northlake community|Lakefront Park|Lakefront Lot|limited selection of wooded lakefront|Choose between stunning lakefront", ""));
		                                          //+commSec
		
		if(commUrl.contains("https://www.mihomes.com/new-homes/michigan/metro-detroit/white-lake-township/trailside-meadow/series/single-family-collection")||commUrl.contains("https://www.mihomes.com/new-homes/michigan/metro-detroit/white-lake-township/trailside-meadow/series/ranch-series"))
			communityType="Golf Course";
		
			
		if(commUrl.contains("https://www.mihomes.com/new-homes/texas/dallas-fort-worth-metroplex/corinth/lake-sharon-estates"))communityType=communityType.replace("Golf Course,","Golf Course");
		U.log("communityType==="+communityType);
//		============================================================================================
		
		
		String[] inventry = U.getValues(homePlanData, "\"Inventory\":\"", "\"");
		
		int total = 0;
		for(String iven : inventry) {
			
			int n = Integer.valueOf(iven);
			total += n;	
		}
		
		//========= Quick Home Section ===============
		int quktotal=0;
		String [] quickSection = U.getValues(commHtml, "home-card home-card--inventory\">", "</a>");
		U.log("Total Quick Home ::"+quickSection.length);
		quktotal=quickSection.length;
		for(String quk:quickSection) {
			//U.log("KKKK "+quk);/// url can get frm here
		}
		
		int Qkcount=0;
		if(quickHomeData!=null) {
			String [] quickMv=U.getValues(quickHomeData, "\"series\":", "\"url\"");
			U.log("jsn quic=="+quickMv.length);
			
			for(String qu:quickMv) {
				U.log(">>>>>>"+qu);
	
				String dateSec=U.getSectionValue(qu, "\"readyDate\":\"", "\"");
				
				U.log("Date :: "+dateSec);
				if(dateSec != null && isMonthReadyHome.test(dateSec)){ 
					Qkcount++;
				}
			}
		}
		
		U.log("Qkcount== "+Qkcount);
//		if(nQkcount<quktotal) 
		if(Qkcount>0) 	{
			if((pStatus.length()<4) ||(pStatus.equals(ALLOW_BLANK))){
				pStatus = "Quick Move-in";
			}
			else {
				 pStatus = pStatus + ", Quick Move-in";
			}
		}
		
		U.log("pStatus2::::::::::::::::"+pStatus);
		commName = commName.replaceAll("- Townhomes|- Single Family$|- Carriage Homes$|-Villas$", "");
		pStatus = pStatus.replace("Quick Move-in Homes", "Quick Move-in").replace("Move-in Ready Homes", "Quick Move-in").replace("Quick Move-in Home", "Quick Move-in");	
		
		U.log(commName);
		commName = commName.replace("-", " - ").replace("  ", " ").trim();


		if(commSec2.contains("<span class=\"product-flag-text\">Basement Homesites Available</span>")){
			if(pStatus == ALLOW_BLANK) pStatus = "Basement Homesites Available";
			else if(pStatus != ALLOW_BLANK && !pStatus.contains("Basement Homesites Available")) pStatus += ", Basement Homesites Available";
		}
		
		
		
		if(commUrl.contains("https://www.mihomes.com/new-homes/minnesota/twin-cities/minnetrista/woodland-cove/the-ridge-at-woodland-cove/series/hans-hagen-villa-collection") || 
				commUrl.contains("https://www.mihomes.com/new-homes/minnesota/twin-cities/minnetrista/woodland-cove/the-ridge-at-woodland-cove/series/summit-collection")) {
			
			addSec = "7044 Huckleberry Drive, Minnetrista, MN 55331";
			add = U.getAddress(addSec);
		}
		
		if(add[0].length()<3) {
			String[] latlng = {lat,lon};
			add = U.getAddressGoogleApi(latlng);
			if(add == null)add = U.getGoogleAddressWithKey(latlng);
			geo = "TRUE";
		}
		if(pStatus.contains("0 Opportunity Remain,")||pStatus.contains(",0 Opportunity Remain"))
			pStatus=pStatus.replaceAll("0 Opportunity Remain,|,0 Opportunity Remain", "");
			
		if(pStatus.contains(",,"))pStatus=pStatus.replace(",,", ",");
		if(commUrl.contains("texas/greater-austin/kyle/6-creeks"))pStatus=pStatus.replace("Now Available", "New Homesites Now Available");
		if(commUrl.contains("https://www.mihomes.com/new-homes/north-carolina/charlotte-metro/indian-trail/harpers-run"))
			pType=pType+", Multi-Gen Homes";

		
		if(commUrl.contains("wesley-chapel/epperson/manor"))pStatus+=", New Phase";
//		if(commUrl.contains("https://www.mihomes.com/new-homes/north-carolina/the-triangle/holly-springs/honeycutt-farm/carriage-homes")) {
//			pStatus=pStatus+", New Homes Coming Soon";
//		}
		if(commUrl.contains("https://www.mihomes.com/new-homes/texas/dallas-fort-worth-metroplex/argyle/canyon-falls")){ pStatus+=", Final Opportunities";}
		if(commUrl.contains("https://www.mihomes.com/new-homes/texas/dallas-fort-worth-metroplex/garland/riverset"))pStatus="Quick Move-in, Now Selling, New Phase";
		note=note.replace("Now Pre-selling, Now ","Now Pre-selling");
		commName = commName.replace(" - City Townhome Series", "");
		commName=commName.replace("WaterGrass", "Watergrass");
		//if(commUrl.contains("/dallas-fort-worth-metroplex/northlake/canyon-falls"))pStatus=pStatus+", New Phase";
		
		//=============No Of Units
		

		
		
		
		
		
		
		
		data.addCommunity(commName.replace(" - Smart Series Townhomes", " - Smart Series").replace("Hidden Lake Townhomes", "Hidden Lake").replaceAll(" - Manor$| - Executive Homes| - Executive$| Villas$| - Estate$", "").replace(" - Single Family Homes", "").replace("K - Bar Ranch - Hawk Valley -", "K - Bar Ranch - Hawk Valley"), commUrl, communityType);
		data.addAddress(StringEscapeUtils.unescapeHtml3(add[0].replace(",", "").trim()), StringEscapeUtils.unescapeHtml3(add[1].trim()), StringEscapeUtils.unescapeHtml3(add[2].trim()), add[3].trim());
		data.addLatitudeLongitude(lat.trim(), lon.trim(),geo);
		data.addPropertyType(pType, dPType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);
		
		data.addNotes(note);
		
		}
		count++;
		
//		}catch (Exception e) {
			// TODO: handle exception
//			}
	}
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		
		
		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					driver.manage().deleteAllCookies();
					driver.manage().window().maximize();
					driver.get(url);
					//U.log("after::::"+url);
//					Thread.sleep(5000);
//					((JavascriptExecutor) driver).executeScript(
//							"window.scrollBy(0,400)", ""); 
					Thread.sleep(3000);
//					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(3000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		
	}

	public boolean isBlocked(String myHtml) {
		if (myHtml.contains("Sorry, you have been blocked"))
			return true;
		return false;
	}
}