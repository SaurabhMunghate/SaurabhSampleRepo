/*
 * Modification Sahil...
 */

package com.shatam.b_021_040;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.bcel.generic.DDIV;
//import org.openqa.jetty.html.Link;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;


public class ExtractWilliamLyonHomes extends AbstractScrapper {
	public static CommunityLogger LOGGER;
	public static int i;
	static String  cUrl=null;
	static HashSet<String> set=new HashSet<String>();
	
	public ExtractWilliamLyonHomes() throws Exception {
		// TODO Auto-generated constructor stub
		super("William Lyon Homes","https://lyonhomes.com");
		LOGGER= new CommunityLogger("William Lyon Homes");
	}
	
	
	
	public static void main(String[] args) throws Exception{
		AbstractScrapper a= new ExtractWilliamLyonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"William Lyon Homes.csv", a.data().printAll());
		U.log("Repeated-->"+i);
		LOGGER.DisposeLogger();
	}

	public static String getRedirectedURLConnection(String url) throws IOException{
		String newUrl=null;
		URL obj = new URL(url);
		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
		int status = conn.getResponseCode();
		if (status != HttpURLConnection.HTTP_OK) {
			if (status == HttpURLConnection.HTTP_MOVED_TEMP
				|| status == HttpURLConnection.HTTP_MOVED_PERM
					|| status == HttpURLConnection.HTTP_SEE_OTHER){
				newUrl = conn.getHeaderField("Location");
			}
			return newUrl;
		}
		else
		return url;

	}
	
	public static String getHardcodedAddress(String comUrl)
			throws Exception {
		cUrl = comUrl;
		String newFile = "/home/ranjna/Harcoded Builders/Lyon Homes.csv";
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {
			if (count > 0) {
				// U.log(newCsvRow.size());
				// builderName=newCsvRow.get(1);
				String aaa = getBuilderObj(newCsvRow);
				if (aaa != null){
					return aaa;
				}
			}
			count++;
		}

		newFileReader.close();
		return null;
	}

	public static String getBuilderObj(List<String> newCsvRow) {

		if (cUrl.equals(newCsvRow.get(4).trim())) {
	
				return (
				      newCsvRow.get(5).trim() + ","+ newCsvRow.get(6).trim() + "," 
				      + newCsvRow.get(7).trim() + ","+ newCsvRow.get(8).trim() + "," 
				      + newCsvRow.get(9).trim() + "," + newCsvRow.get(10).trim()+ "," +newCsvRow.get(11).trim()
						);
		}
		return null;

	}

	public static String formatMillionPrices(String html){
		Matcher millionPrice = Pattern.compile("\\$\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
		
			Matcher millionPrice1 = Pattern.compile("\\$\\d.\\d Millions",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice1.find()){
			U.log(millionPrice1.group());
			String floorMatch = millionPrice1.group().replace(" Millions", "00,000").replace(".", ",");  //$1.3 M
			U.log(floorMatch);
			html	 = html.replace(millionPrice1.group(), floorMatch);
			}//end millionPrice
			while(millionPrice.find()){
//				U.log(mat.group());
				String floorMatch = millionPrice.group().replace("Millions", "000,000").replace(" ", ",");  //$1.3 M
				html	 = html.replace(millionPrice.group(), floorMatch);
				}//end millionPrice
		return html;
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String cityName = ALLOW_BLANK;
		String cityUrl = ALLOW_BLANK;
		String mainHtml=U.getHTML("https://lyonhomes.com");
		String citySec=U.getSectionValue(mainHtml, "Select a Location</h2>", "<div class=\"modal-body");
		String[] cities=U.getValues(citySec,"<div class=","</div>");
		for(String city:cities){
			//U.log(city);
			if(city.contains("nav-item nav-link-plus map-region collapsed"))continue;
			cityUrl="https://lyonhomes.com"+U.getSectionValue(city, "<a href=\"", "\"");
			cityName=Util.match(city, "<a href=.*?>(.*?)</a>$",1);//U.getSectionValue(city, ">", "</a");
			U.log(cityUrl+"\t"+cityName);
			//if(cityName.equals("Oregon"))
				getCityHtml(cityUrl,cityName);
		}
	}
	
	public static void getCityHtml(String url,String name)throws Exception{
		String cityHtml=ALLOW_BLANK;
		String comHtml=ALLOW_BLANK;
		String comUrl1= ALLOW_BLANK;
		String getHomes;
		cityHtml=U.getHTML(url);
		U.log(url);
		//cityHtml=cityHtml.replaceAll("</ul>\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "endSection");
		//cityHtml=U.removeSectionValue(cityHtml, "<div class=\"region-filters clearfix\">", "<div class=\"container neigbhorhoods-listings\"");
		String[] Communities=U.getValues(cityHtml, "<div class=\"row neigbhorhoods","<div class=\"row neighborhood-buttons d");
		U.log(Communities.length);
		String sec=U.getSectionValue(cityHtml, "regionNeighborhoods =", "}];");
		for(String comm:Communities){
			comm=comm.replace("Currently Selling From the", " ");
			//U.log(comm);
			String temp=U.getSectionValue(comm, "<h3><a href=\"", "\"");
			U.log(temp);
			if(set.contains(temp))continue;
			if(!temp.contains("http")){
				comUrl1="https://lyonhomes.com"+temp;
				comHtml=U.getHTML(comUrl1);
				comHtml=comHtml.replaceAll("<li>COMING SOON </li>", "-");
				
			//if(comUrl1.contains("https://lyonhomes.com/oregon/eastridge-ii-at-river-terrace"))
					getDetails(comHtml,comUrl1,comm,sec);
		
			
			}
			else{
				comUrl1=getRedirectedURLConnection(temp);
				if(comUrl1.contains("https://OvationMeridian.com/"))
					{
					LOGGER.AddCommunityUrl(comUrl1 + ":::::::::::: Site not Open::::::::::::::");// Please check. Date 18/5/2019
					return;
					}
				comHtml=U.getHTML(comUrl1);
			//	if(comUrl1.contains("https://OvationMeridian.com/"))return;
				comHtml=comHtml.replaceAll("<li>COMING SOON </li>", "-");
//				if(comUrl1.contains("https://ovationflorapark.com/"))
			getDetailsOfCommunities(comUrl1,comHtml,comm);
				
			}	
			set.add(temp);

		}

	}
	public static String getQuickHomes(String comm,String name)throws Exception {
		//getting Quick delivery homes
		String allQuickHomesHtml=ALLOW_BLANK;
		//U.log(comm);
		name=name.replace("á", "a");
		if(comm.contains("Quick")){
			String quickMoveInMainHtml=ALLOW_BLANK;
			U.log("<---------------Fetching Quick delivery homes-------------->");
			String quickMoveinSec=Util.match(comm, "(.*?)quick-move-in-homes(.*?)\"");
			U.log(Util.match(comm, "(.*?)quick-move-in-homes(.*?)\""));
			if(quickMoveinSec!=null){
				U.log("https://lyonhomes.com"+ U.getSectionValue(quickMoveinSec,"href=\"", "\""));
				 quickMoveInMainHtml=U.getHTML("https://lyonhomes.com"+U.getSectionValue(quickMoveinSec, "href=\"", "\""));
			String[] quickMoveInHomes=U.getValues(quickMoveInMainHtml, "class=\"neigbhorhoods-listing clearfix", "class=\"btn btn-secondary pull-right");
			for(String home:quickMoveInHomes){
				home=home.replace("á", "a");
				String[] availHomes=U.getValues(home, "href=\"", "\"");
				for(String value:availHomes){
//				U.log(home);
				if(home.contains(name)){
				allQuickHomesHtml += U.getHTML("https://lyonhomes.com"+value);
				}
				}
			}}
		}
		return allQuickHomesHtml;
	}
	
	public  static void getDetailsOfCommunities(String comUrl,String comHtml,String comm)throws Exception{
	
		U.log("==================Fetching Details=================");
		String comName=ALLOW_BLANK;
		comHtml=comHtml.replaceAll("</li>\\s*</ul>\\s*</div>", "endSec");
		comHtml=comHtml.replace("Two Brand New Single-Story Residences Now Available", " "); 
		comHtml=comHtml.replace("<p>Models are now open! Be among the first to get exciting news and stay tuned to what is happening at Ovation at Mountain Falls. Wonderful things are coming your way!</p>", " " );
		comHtml=comHtml.replace("SALES GALLERY NOW OPEN ", " ");
		comm=comm.replace("SALES GALLERY NOW OPEN ", " ");

		//=============================Community Url===========================

			U.log("comUrl-->"+comUrl);			
			
		//=============================Community Name=========================================
			 
			/*String tempName=U.getSectionValue(comm, "<h3>","</h3>");
			comName=U.getSectionValue(tempName, "target=\"_blank\">","</a");*/
			comName = Util.match(comm, "\">(.*?)</a></h3>",1);
			U.log("ComName-->"+comName);
		//=============================Community address=========================================
			String allNavMenuHtml=ALLOW_BLANK;String resihtml=ALLOW_BLANK;
			String note="";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
			
			if(comUrl.contains("http://www.ovationmeridian.com/")){
				U.log("getting data from Ovation at Meridian");
					String[] addressToGetLatLng={"","Queen Creek","Arizona",""};
					latlng =U.getlatlongGoogleApi(addressToGetLatLng);
					U.log("By Geocoding--->"+latlng[0]+"  "+latlng[1]);
					add=U.getAddressGoogleApi(latlng);
					geo="TRUE";
					note="Address Calculated using City,state.";		
			}
			else{
		//<---------------NavBar Data------------>
			String navSec;				
			String mapHtml=ALLOW_BLANK;

			if(comName.equals("Ovation at Flora Park"))
				navSec=U.getSectionValue(comHtml, "<div class=\"collapse", "endSec");
			else if(comName.equals("Silver Ridge")||comName.equals("Ovation at Mountain Falls"))
				navSec=U.getSectionValue(comHtml, "<div class=\"menu-main-nav-container", "endSec");
			else if(comName.equals("Lago Vista"))
					navSec=U.getSectionValue(comHtml, "<div class=\"menu-menu-1-container", "endSec");
			else
				navSec=U.getSectionValue(comHtml, "<div class=\"navbar-collapse", "endSec");
				navSec=navSec.replace("_blank", " ");
				navSec=U.removeSectionValue(navSec, "menu-item-205\">", "<");
				navSec=U.removeSectionValue(navSec, "id=\"menu-item-233", "Mountain Falls");
				navSec=U.removeSectionValue(navSec, "	<li id=\"menu-item-365\"", "<");
				navSec=U.removeSectionValue(navSec, "class=\"interest-list hidden-sm\">", "height=\"11\">");
			String[] navMenus=U.getValues(navSec,"<li", "</a");
			
			for(String menu:navMenus){
				U.log(menu);
				if(!menu.contains("http")){
					U.log(U.getSectionValue(menu, "<a href=\"", "\""));
					allNavMenuHtml +=U.getHTML(comUrl+U.getSectionValue(menu, "<a href=\"", "\""));
				}
				else if(comName.equals("Lago Vista")){
					allNavMenuHtml +=U.getHTML("http://lyonlagovista.com/"+U.getSectionValue(menu, "<a href=\"http://lyonlagovista.com/", "\""));
				}
				else{
					allNavMenuHtml +=U.getHTML(U.getSectionValue(menu, "href=\"", "\""));
				}
				//Visit_US page data
				if(menu.contains("/visit-us") && !menu.contains(comUrl)) {
					mapHtml=U.getHTML(comUrl+U.getSectionValue(menu, "href=\"", "\""));
					U.log(mapHtml.contains("https://www.google.com/maps"));
				}
				if(menu.contains("/contact/") && !menu.contains(comUrl)) {
					mapHtml=U.getHTML(comUrl+U.getSectionValue(menu, "href=\"", "\""));
					U.log(mapHtml.contains("https://www.google.com/maps"));
				}
//				if(menu.contains("/contact-us") ) {
//					mapHtml=U.getHTML(U.getSectionValue(menu, "href=\"", "\""));
//					U.log(mapHtml.contains("https://www.google.com/maps"));
//				}
			}

				allNavMenuHtml=allNavMenuHtml.replaceAll("<h3>Now Open</h3>","");
				comHtml=comHtml.replace("<p>Models are now open!", "");
				comm=comm.replace("NOW OPEN! - Three Collections","");
				if(comUrl.contains("https://ovationoaktree.com/")){
					String residenceshtml=U.getHTML("https://ovationoaktree.com/residences/the-beech");
					String sec=U.getSectionValue(residenceshtml, "<ul class=\"nav subnav\">", "Home Features");
					String residencesUrl[]=U.getValues(sec, "href=\"", "\"");
					for(String home:residencesUrl){
						resihtml+=U.getHTML("https://ovationoaktree.com"+home);
					}
				}
			
			String address=ALLOW_BLANK;
			//<-----------Address from hardcoded csv------------>
			String addSec=U.getSectionValue(mapHtml, "https://www.google.com/maps/place/", "\"");
			if(addSec!=null) {
				addSec=addSec.replace("+", " ");
				add=U.findAddress(addSec);
				String latString=U.getSectionValue(addSec, "/@", "/data");
				U.log(latString);
				latlng[0]=Util.match(addSec, "\\d{2,3}\\.\\d+");
				latlng[1]=Util.match(addSec, "-\\d{2,3}\\.\\d+");
			}
			else if(comUrl.contains("http://ovationmountainfalls.com/")) {
				addSec=U.getSectionValue(U.getHTML("http://ovationmountainfalls.com/contact-us"), "Monday’s</p>", "</p>");
				add=U.findAddress(addSec);
				latlng=U.getlatlongGoogleApi(add);
				geo="True";
			}
			else if(comUrl.contains("https://ovationflorapark.com/")) {
				addSec=U.getSectionValue(U.getHTML("https://ovationflorapark.com/visit/"), "pm</h3>", "</p>");
				U.log(addSec);
				add=U.findAddress(addSec);
				String latString=U.getSectionValue(U.getHTML("https://ovationflorapark.com/visit/"), "src=\"https://www.google.com/maps/embed?pb=", "\"");
				U.log(latString);
				latlng[0]=U.getSectionValue(latString, "3d", "!");//Util.match(addSec, "\\d{2,3}\\.\\d+");
				latlng[1]=U.getSectionValue(latString, "!2d", "!");//Util.match(addSec, "-\\d{2,3}\\.\\d+");
//				latlng=U.getlatlongGoogleApi(add);
//				geo="True";
			}
			else if(comUrl.contains("http://lyonthegrandmonarch.com")) {
				addSec=U.getSectionValue(U.getHTML("http://lyonthegrandmonarch.com/contact/"), "Sales Gallery</strong></span><br />", "<br />");
				U.log(addSec);
				add=U.findAddress(addSec);
				latlng=U.getlatlongGoogleApi(add);
				geo="True";
			}
			else {
			address=getHardcodedAddress(comUrl);
			U.log(address);
			add=address.split(",");
			add[0]=add[0].trim();
			add[1]=add[1].trim();
			add[2]=add[2].trim();
			add[3]=add[3].trim();
			latlng[0]=add[4];
			latlng[1]=add[5];
			geo=add[6];
			}
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
	
			
			
			U.log("LatLng---->"+latlng[0]+" "+latlng[1]);

			
			U.log("Geocode---->"+geo);
			}
			//============================================Price and SQ.FT======================================================================
			comHtml=formatMillionPrices(comHtml);
			comm=formatMillionPrices(comm);
			comHtml=comHtml.replace("$3 Millions", "$3,000,000");
			allNavMenuHtml=formatMillionPrices(allNavMenuHtml);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String prices[] = U.getPrices(comHtml+comm+allNavMenuHtml+resihtml,
					"\\$\\d{1},\\d{3},\\d*|\\$\\d{3}\\,\\d*",
//					"Low \\$\\d{3}\\,\\d*|Mid \\$\\d{3}\\,\\d*|High \\$\\d{3}\\,\\d*|From the \\$\\d{3}\\,\\d*|From the Low \\$\\d{3}\\,\\d*|From the Mid \\$\\d{3}\\,\\d*|From the High \\$\\d{3}\\,\\d*|\\$\\d{3}\\,\\d*|\\$\\d{1},\\d{3},\\d*|Low \\$\\d{1},\\d{3},\\d*|Mid \\$\\d{1},\\d{3},\\d*|High \\$\\d{1},\\d{3},\\d*|the \\$\\d{1},\\d{3},\\d*",
					0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Prices----->"+minPrice+ " "+maxPrice);
			
			//====================Sq.ft=====================
			
			String[] sqft = U.getSqareFeet(comHtml+comm+allNavMenuHtml+resihtml,"\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|Approx. \\d{1},\\d{3}-\\d{1},\\d{3} Sq. Ft.|Approx. \\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3}-\\d{1},\\d{3} Sq.Ft.</li>|\\d{1},\\d{3} Sq. Ft.",0);
				
			minSqft = (sqft[0] == null)	? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);

			//================================================community type========================================================
			
			String commType=U.getCommType(comm+comHtml);
			U.log("community type---->"+commType);
			
			//==========================================================Property Type================================================
			comHtml=comHtml.replace(" luxury interior features", "custom luxury");
//			U.log(Util.matchAll(allNavMenuHtml,"loft",0));
			String propType=U.getPropType(comHtml+comm+allNavMenuHtml);
			U.log("Property type---->"+propType);

			//==================================================D-Property Type======================================================
			String dPropType=U.getdCommType((comHtml+comm+allNavMenuHtml).replaceAll("[B|b]ranch|Ladera [R|r]anch|ladera-ranch|Ladera\\+Ranch", ""));
			U.log("Derived Property type---->"+dPropType);
			
			//==============================================Property Status=========================================================
		
			comm=comm.replace("3&nbsp;Quick&nbsp;Move-In Homes&nbsp;Available&nbsp;&gt;&gt;", "3 Quick Move-In Homes").replaceAll("Designer Homes Available Now", "");
			comHtml=comHtml.replace(" and unlimited opportunities await.", "").replaceAll("<br>Move-in Ready,|Coming Late 2018|<h3>Now Open!\\s*</h3>\\s*<p>| of any one of our&nbsp; move-in ready homes.&nbsp;|Three Brand New Residences Now Available|Coming soon to Cypress", "");
			String propStatus=U.getPropStatus(comHtml+comm.replaceAll("Move-in Ready|Models Coming Late 2018", ""));
			U.log("Property Status---->"+propStatus);
			if(propStatus.contains("3 Quick Move-in Homes"))propStatus=propStatus.replaceAll("3 Quick Move-in Homes", "Quick Move-in Homes");
			//============================================note====================================================================
			
			
			if(data.communityUrlExists(comUrl))
			{
				LOGGER.AddCommunityUrl(comUrl+"*********repeated***********");
				i++;
				return;
			}
				LOGGER.AddCommunityUrl(comUrl);
				U.log(add[2]);
				if(add[2].length()>2){
					add[2]=USStates.abbr(add[2]);
				}
				U.log(Arrays.toString(add));
				add[2]=add[2].toUpperCase();
				add[2]=add[2].replace(",","").trim();
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				data.addCommunity(comName,comUrl, commType);
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, dPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note); 
				
			
	}
	
	
	public static void getDetails(String comHtml,String comUrl,String commSec,String dataSec) throws Exception{
			//if(!comUrl.contains("https://lyonhomes.com/oregon/ridgeline-at-bethany"))return;
			U.log("==================Fetching Details=================+");
			String comName=ALLOW_BLANK;
			String floorPlansHtml=ALLOW_BLANK;
			comHtml=U.removeSectionValue(comHtml, "<head>", "</head>");
			comHtml=U.removeSectionValue(comHtml, "class=\"navbar hidden-print", "</nav>");
			comHtml=U.removeSectionValue(comHtml, "<h4>Directions to Sales Gallery:", "</div>");
			//U.log(commSec);

		//=============================Community Url===========================
			U.log("comUrl-->"+comUrl);
		//=============================Community Name========================================= 
			String tempName=U.getSectionValue(commSec, "<h3>","</h3>");
			if(tempName.contains("Townhomes")){
				tempName=tempName.replace("Townhomes", "");
			}
			comName = Util.match(commSec, "\">(.*?)</a></h3>",1).replaceAll("ō", "o").replaceAll("é", "e").replaceAll("á", "a").replace("–", "-");
			U.log("ComName-->"+comName);
//			U.log(commSec);
			String homes=getQuickHomes(commSec,comName);
		//=============================Community address=========================================
			String note="";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo="FALSE";
			String[] latlng={ALLOW_BLANK,ALLOW_BLANK};
			String[] add1={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
			/*if(comName.equals("Towne38")){
				//=============================Community address Using City and State=========================================
				String[] addressToGetLatLng={"","Campbell","California",""};
				latlng=U.getlatlongGoogleApi(addressToGetLatLng);
				add=U.getAddressGoogleApi(latlng);
				geo="TRUE";
				note="Address Calculated using City,state.";
			}
			else if(commSec.contains("/northern-california/masterplans/sohay")){
				String[] addressToGetLatLng={"","Hayward","California",""};
				latlng=U.getlatlongGoogleApi(addressToGetLatLng);
				add=U.getAddressGoogleApi(latlng);
				geo="TRUE";
				note="Address Calculated using City,state.";
			}
			else{
			String addrSec=U.getSectionValue(comHtml," <p class=\"margin-top-small print-no-margin", "</p>");
			if(addrSec!=null){
			addrSec=addrSec.trim();
			String tempAddSec=U.getSectionValue(addrSec,"\">", "<strong>");
				if(tempAddSec.contains("<br")){
					tempAddSec=tempAddSec.replace("<br class=\" hidden-print\" />", ",").replaceAll("Open House ", "");
				}
			add1=tempAddSec.split(",");
			add1[0]=add1[0].trim();
			}		
			if(add1.length>2)
			{
				 add[0]=add1[0];
				 add[1]=add1[1];
				 add[3]=Util.match(add1[2],"\\d{4,}");
				 if(add[3]!=null)
				 {
					add[2]=add1[2].replace(add[3],"").trim();
				 }
				 else
				 {
					add[2]=add1[2];
				 }
			}
			if(comUrl.contains("https://lyonhomes.com/arizona/heritage-at-meridian")){
				U.log("getting data from heritage at Meridian");
					String[] addressToGetLatLng={"","Queen Creek","Arizona",""};
					latlng =U.getlatlongGoogleApi(addressToGetLatLng);
					U.log("By Geocoding--->"+latlng[0]+"  "+latlng[1]);
					add=U.getAddressGoogleApi(latlng);
					geo="TRUE";
					note="Address Calculated using City,state.";		
			}
			if(comUrl.contains("/northern-california/wayland")){
//				addrSec=U.getSectionValue(comHtml, "</span></p>", "&nbsp;</h2>").replaceAll("<h2>Visit our Open House at", "").replaceAll("Livermore CA 94550", "Livermore,CA 94550");
				String[] addressToGetLatLng={"","Livermore","California",""};
				latlng=U.getlatlongGoogleApi(addressToGetLatLng);
				add=U.getAddressGoogleApi(latlng);
				geo="TRUE";
				note="Address Calculated using City,state.";
			}
			if(add[0].length()<4 && !comHtml.contains("maps")){
				addrSec=U.getSectionValue(comHtml, "<h2>", "</h2>").replaceAll("Visit our Open House at", "").replaceAll("Livermore CA 94550", "Livermore,CA 94550").replaceAll("Newark", ",Newark");
				U.log(addrSec);
				add=U.getAddress(addrSec);
			}*/
			String address = "";
			address = U.getSectionValue(comHtml, "sales-gallery-address\">", "</p>").replace("<br class=\" hidden-print\" />", ",");
			add = U.getAddress(U.getNoHtml(address));
			
			if(add[0]!=null)add[0]=add[0].replaceAll("By Appointment Only", "");
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			//=============================LatLng=========================================
			latlng=U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/dir//", "\"").split(",");
			if(comName.equals("Towne38")){
				add=U.getAddressGoogleApi(latlng);
				geo="TRUE";
				//note="Address Calculated using City,state.";
			}
			/*if(latLngSec!=null){
				latlng[0]=Util.match(latLngSec, "\\d{2,3}.\\d{5}");
				latlng[1]=Util.match(latLngSec, "-\\d{2,3}.\\d{5}");
			}else{
				String values[]=U.getValues(dataSec, "{\"id\":\"", "\"}");
				for(String s:values){
					if(comName.equalsIgnoreCase(U.getSectionValue(s, "\"nameLong\":\"", "\""))){
						latlng[0]=U.getSectionValue(s, "\"altLat\":\"", "\"");
						latlng[1]=U.getSectionValue(s, "\"altLng\":\"", "\"");
						U.log(Arrays.toString(latlng));
					}
				}
				
			}
			
			if(add[0]!=ALLOW_BLANK && latlng[1]==null && latLngSec==null)
			{
				latlng=U.getlatlongGoogleApi(add);
				geo="TRUE";
			}
			if((add[0].length()<2 ||add[2]==null) && latlng[0]!=ALLOW_BLANK){
				add=U.getAddressGoogleApi(latlng);
				geo="TRUE";
			}
			if(add[3]==null){
				add=U.getAddressGoogleApi(latlng);
				geo="True";
			}
			if(add[3]!=null && add[0]!=null && latlng[0]==ALLOW_BLANK){
				latlng=U.getlatlongGoogleApi(add);
				geo="True";
			}
			}
			
			if(add[2].length()>2){
				add[2]=USStates.abbr(add[2]);
			}*/
			U.log("LatLng---->"+latlng[0]+" "+latlng[1]);
			U.log("GeoCoding---->"+geo);	
			
			//========getting Floorplans for data==========
				comHtml=comHtml.replaceAll("</li>\\s*</ul>\\s*</div>", "endSec");
				String[] floorPlans=U.getValues(comHtml, "neigborhood-floorplans-list margin-bottom-medium\">", "Floorplan</a>");
				for(String value:floorPlans){
					try{
					U.log("https://lyonhomes.com"+U.getSectionValue(value , "href=\"", "\""));
					floorPlansHtml+=U.getHTML("https://lyonhomes.com"+U.getSectionValue(value , "href=\"", "\""));
					floorPlansHtml=floorPlansHtml.replaceAll("<header(.*?)</header>", " ");
					}
					catch(Exception e){}

				}
			//============================================Price and SQ.FT======================================================================
			comHtml=comHtml.replaceAll("0's|0s","0,000").replace("$1 Millions","$1,000,000").replaceAll("&rsquo;s", ",000");
			commSec=commSec.replace("$300,00s", "$300,000").replaceAll("0's|0s","0,000").replace("$1 Millions","$1,000,000");
			//U.log(comHtml);
			comHtml=formatMillionPrices(comHtml);
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			U.log(homes);
			String prices[] = U.getPrices(comHtml+commSec+homes+floorPlansHtml,
					"\\$\\d{1},\\d{3},\\d*|Low \\$\\d{1},\\d{3},\\d*|Mid \\$\\d{1},\\d{3},\\d*|High \\$\\d{1},\\d{3},\\d*|\\$\\d{1},\\d{3},\\d*|Low \\$\\d{1},\\d{3},\\d*|from the \\$\\d{3},\\d{3} to the \\$\\d{3},\\d{3}|Mid \\$\\d{3}\\,\\d*|High \\$\\d{3}\\,\\d*|From the \\$\\d{3}\\,\\d*|From the Low \\$\\d{3}\\,\\d*|From the Mid \\$\\d{3}\\,\\d*|From the High \\$\\d{3}\\,\\d*|\\$\\d{3}\\,\\d*",
					0);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Prices----->"+minPrice+ " "+maxPrice);
			
			//====================Sq.ft=====================
//			U.log(commSec);
			String[] sqft = U.getSqareFeet(comHtml+commSec+homes+floorPlansHtml,"Approx Sq. Ft</div>\\n*\\s*<div class=\"description\">\\d{3}|Approx Sq. Ft</div>\\n*\\s*<div class=\"description\">\\d,\\d{3}|from \\d{3} to \\d,\\d{3} sq. ft.|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|<li>Approx. \\d{1},\\d{3} – \\d{1},\\d{3} Sq. Ft.</li>|<li>Approx. \\d{1},\\d{3}-\\d{1},\\d{3}</li>|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d{1},\\d{3}-\\d{1},\\d{3} Sq.Ft.</li>|Approx. \\d{1},\\d{3} Sq\\. Ft\\.|\\d,\\d{3} Sq\\. Ft\\.|\\d{1},\\d{3} Sq\\. Ft\\.|Approx. \\d{3} Sq. Ft.",0);
				
			minSqft = (sqft[0] == null)	? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			U.log("SQ.FT--->"+minSqft+" "+maxSqft);
			
			//================================================community type========================================================
			//comHtml=comHtml.replace("Ovation<br><small>55+ Active Lifestyle", "");
			String commType=U.getCommType(comHtml+commSec);
			U.log("community type---->"+commType);
			
			//==========================================================Property Type================================================
			comHtml=comHtml.replace("Traditional Texas Hill Country architectural styles", "Traditional homes").replaceAll("luxurious details found", "luxury homes");
			String propType=U.getPropType((comHtml+commSec+homes+floorPlansHtml).replaceAll("<img(.*?)>|11394 Villa Bellagio Drive|left on Villa Bellagio|alt=\"Patio\"| Patio\\s*</div>", ""));
			U.log("Property type---->"+propType);
			
			//==================================================D-Property Type======================================================
			commSec=commSec.replaceAll("Valley Ranch Blvd", "");
			floorPlansHtml=floorPlansHtml.replaceAll("Building Levels 1,2&nbsp;&amp; 3", "1 Story,story 2,story 3").replaceAll("Building Levels 2 &amp; 3", "story 2,story 3").replaceAll("Building Level[s]*", "story");
			homes=homes.replaceAll("Building Level", "story").replace("single or split-level ", "single story or split-level ")
					.replaceAll("2<sup>nd</sup> Floor", "2 story").replaceAll("3<sup>rd</sup> floor", "3 story").replaceAll("1st Floor| first-floor", "1 story");
			comHtml=comHtml.replace(" 3- and 4-level ", "3 story and 4 story").replace("1-to&nbsp;3-level", "1 story,story 3").replace( "2- and 3-level plans", "story 2,story 3");
			String dPropType=U.getdCommType((comHtml+commSec+homes.replaceAll("Floor|Stonewall\\s*Ranch|\\+Ranch|Stillwater\\s*Ranch|Valley Ranch Blvd|Rex Ranch|rancho-mission-viejo|Rancho|Rancho Mission Viejo", "")+floorPlansHtml.replaceAll("Floor|rancho-mission-viejo|Rancho|Rancho Mission Viejo|Valley Ranch", "")).replaceAll("[B|b]ranch|[R|r]ancho|Rancho|rancho|Ladera Ranch|Murphy Ranch|murphy-ranch|<img(.*?)>", ""));
			U.log("Derived Property type---->"+dPropType);
			//==============================================Property Status=========================================================
			//U.log("Hollaaaaaaaaaaaaa"+commSec);
			comHtml=comHtml.replace("Opening in 2019", "Opening 2019").replaceAll("COMING SOON IN APRIL 2019", "COMING SOON APRIL 2019");
			comHtml=comHtml.replaceAll("<h3>Move-In Ready Homes|Move-in Ready|Sales Hub Now Open|target=\"_blank\">Move-In Ready</a>|<li>SOLD OUT|<h4>Move-In Ready Homes!\\s*</h4>| - Move-In Ready|SOLD OUT endSec|Currently Selling [F|f]rom|Model Homes Coming Soon|>\\s*Coming Soon\\s*<|alt=\"Grand Opening \"|Temporarily Sold Out\\s*endSec|Gallery:</h4>\\s*<p>Coming Soon!</p>|Coming Soon to The Cliffs Village|Coming Soon endSec|MODELS COMING LATE 2018|/Coming_soon_1000x600_thumbnail_1.jpg|</li>\\s*<li>\\s*SOLD OUT\\s*</li>|Model Homes Selling Now|Sales Gallery Hours Coming Soon|Seven stunning models are now open|Models and Welcome Center Now Open!|Move-In Ready Homes on the Golf Course Available!|any one of our  move-in ready homes.", "");
			commSec=commSec.replaceAll("Move-in Ready|<h4>Move-In Ready Homes!\\s*</h4>| - Move-In Ready|>\\s*Coming Soon\\s*<|4 Bedroom Homes Coming Soon |Coming Soon to The Cliffs Village|Pool Opening in 2019|Models Coming Late 2018|Designer Homes Available Now|COMMUNITY POOL NOW OPEN FOR MERIDIAN HOMEOWNERS|Close Out of Final Homes at The Grand Collection at Sterling Ridge!|Move In Ready Homes Available|Models and Welcome Center Now Open!", "");
			String propStatus=U.getPropStatus(comHtml+commSec);//+commSec+homes+floorPlansHtml);
			U.log("Property Status---->"+propStatus);
			if(propStatus.contains("Only 4 Homes Left")&& propStatus.contains("Only 4 Homes Remain"))propStatus=propStatus.replaceAll(", Only 4 Homes Remain", "");
			//============================================note====================================================================	
			if(note.length()<1){
				note=U.getnote(comHtml+commSec);
			}
			if(propStatus.contains("Quick Move-in") || propStatus.contains("Move-in Ready"))propStatus=propStatus.replaceAll("Move-in Ready Homes|Quick Move-in Homes|Quick Move-in|Move-in Ready", "Quick Move-in Homes");

			if(comName.endsWith("Estates"))propType=propType+", Estate-Style Homes";
			if(data.communityUrlExists(comUrl))
			{
				LOGGER.AddCommunityUrl(comUrl+"*********repeated***********");
				i++;
				return;
			}
				LOGGER.AddCommunityUrl(comUrl);
				if(add[2].length()>2){
					add[2]=USStates.abbr(add[2]);
				}
				add[0]=add[0].replace("&nbsp;", "");
				add[2]=add[2].toUpperCase();
				add[2]=add[2].replace(",","").trim();
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				data.addCommunity(comName.toLowerCase(),comUrl, commType);
				data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(),geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, dPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note); 
				
		}
	
	
	
	
}