/**@@author Sawan
 * @date 24-11-2017  
 */
package com.shatam.b_021_040;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

//import org.openqa.selenium.internal.seleniumemulation.GetHtmlSource;

public class ExtractWinchesterHomes extends AbstractScrapper {
	int i = 0;
	int counter = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.winchesterhomes.com";
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractWinchesterHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(	U.getCachePath()+"TRI Pointe Group - Winchester Homes.csv", a
						.data().printAll());
	}

	public ExtractWinchesterHomes() throws Exception {

		super("TRI Pointe Group - Winchester Homes",builderUrl);
		LOGGER = new CommunityLogger("TRI Pointe Group - Winchester Homes");
	}

	public void innerProcess() throws Exception {
		
		String html = U.getHTML(builderUrl);

		String section = U.getSectionValue(html, "Your Home</a>","</ul>");
//		U.log(section);
		String[] regionUrls = U.getValues(section, "href=\"", "\"");
		
		for(String regionUrl : regionUrls){
			
			String regionHtml = U.getHTML(regionUrl);
			String [] comSections = U.getValues(regionHtml, "<div class=\"col-lg-4 col", "communLearnMore btn-group");
			U.log(comSections.length+"::::::::::::::"+regionUrl);
			
			for(String comSec : comSections){
				
				//if(z==3)comSec=comSec+" 55+ community ";
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
				U.log(comUrl);
				findCommunityDetails(comUrl,comSec);
			}
		}

		LOGGER.DisposeLogger();
	}
	
	public void findNewCommunity(String regionHtml) throws Exception {
		
		String [] comSections = U.getValues(regionHtml, "<div class=\"col-lg-4 col", "communLearnMore btn-group");
		U.log(comSections.length);
		for(String comSec : comSections){
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
//			U.log(comUrl);
			findCommunityDetails(comUrl,comSec);
		}
	}
	
	int j = 0;
	private void findCommunityDetails(String comUrl, String comSec)throws Exception {
		
//		if(j==6)
	{
		
		if (data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		
		
		
		U.log(j+"\n"+comUrl);
		String html1 =  U.getHTML(comUrl);
		if(html1.contains("<h2><span>Neighborhoods</span></h2>")){
			findNewCommunity(html1);
			return;
		}
		
		
		
		
		if(comUrl.contains("https://www.winchesterhomes.com/community/vistas-at-lansdowne/"))return;//redirected
		
		//For Single Execution
//		if(!comUrl.contains("https://www.winchesterhomes.com/maryland/tworivers/"))return;
		
		String html = ALLOW_BLANK;
		if(comUrl.contains("https://www.winchesterhomes.com/maryland/tworivers/")){
			html =  getHTML(comUrl);  
		}else{
			html = U.getHTML(comUrl);
		}
		/*String h=U.getSectionValue(html," <button type=\"button\" class=\"btn selling_btn\">Now Selling</button>","<address class=\"address\">");
		U.log(h);*/
		//U.log(html);
		//========== Community Name ==================
		String comName = U.getSectionValue(html, "<h1>", "</h1>");
		comName = comName.replace("&#8211;", "-").replace("&#038;", "&").trim();
		comName=comName.replaceAll("Landsdale Single Family Homes","Landsdale");
		if(comName.endsWith("Townhomes"))comName = comName.replace("Townhomes", "");
		U.log("comName:"+comName);
		String notes =ALLOW_BLANK;
		//=============== Navigate Section =====================
		String navSec = U.getSectionValue(html, "nav navbar-nav\">", "</ul>");
		String floorPlanHtml = null, mapHtml = null,moveHtml = null;
		if(navSec != null){
			String navUrls[] = U.getValues(navSec, "href=\"", "\"");
			for(String navUrl : navUrls){
				U.log(navUrl);
				if(navUrl.contains("floorplans")){
					//U.log("floorPlan:::"+navUrl);
					floorPlanHtml = U.getHTML(navUrl);
				}
				if(navUrl.contains("map-direction")){
					if(!navUrl.contains("http")) {
						navUrl=comUrl+navUrl;
					}
					//U.log("map url:::"+navUrl);
					mapHtml = U.getHTML(navUrl);
				}
				if(navUrl.contains("move-in-ready")){
					//U.log("moveIn::"+navUrl);
					moveHtml = U.getHTML(navUrl);
				}
			}
		}
		
		//============ Address && LatLng ========================
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "False";
		String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String cityState = U.getSectionValue(comSec, "<span class=\"title\">", "</span>");
		U.log("cityState : "+cityState);
		String[] vals = cityState.split(",");
		add[1] = U.getNoHtml(vals[0].trim());
		add[2] = U.getNoHtml(vals[1].trim());
		if(mapHtml !=null){
		mapHtml = mapHtml.replace("Ashburn, VA 20148 Ashburn, VA 20148", "VA 20148");
		String addSec = U.getSectionValue(mapHtml, "markers = [[", "];");
		if(addSec!=null) {
			U.log(addSec);
			U.log(comUrl);
			addSec=U.getSectionValue(addSec, "/\"","]");
			addSec=Util.match(addSec, "[0-9a-z ]+(.*?)\\d{5}\"",0);
			addSec=addSec.replace("\"","");
		}
		U.log("addSec : "+addSec);
		String addVal[] = addSec.split(",");
		if(addVal.length==4)
		{
			add=addVal;
		}
		}
		if(add[0]==ALLOW_BLANK) {
			String newAddSec=U.getSectionValue(html, comName+"</strong><br>", "<a");
			if(newAddSec!=null) {
			newAddSec=newAddSec.toLowerCase().replaceAll(Util.match(newAddSec.toLowerCase().trim(), add[1].toLowerCase().trim()), ","+add[1].toLowerCase().trim());
			add=U.findAddress(newAddSec);
			String latlngSec=U.getSectionValue(html, "https://maps.google.com/maps?saddr=&daddr=", "\"");
			latLng=latlngSec.split(",");}
		}
		U.log("ADD::"+Arrays.toString(add));
	
		if(mapHtml != null){
			String latLngSec = U.getSectionValue(mapHtml, "&daddr=", "\"");
			latLng[0]=Util.match(latLngSec, "\\d{2,3}.\\d{2,}");
			latLng[1]=Util.match(latLngSec, "-\\d{2,3}.\\d{2,}");
		}
		if(comUrl.contains("https://www.winchesterhomes.com/maryland/tworivers/")){
			add = U.getAddress("2880 Dragon Fly Way, Odenton, MD 21113");
			latLng = "39.0174761,-76.7221919".split(",");
		}
		
		U.log("LatLng =="+Arrays.toString(latLng));
//		U.log(mapHtml);
		add[0] = add[0].replace("Call For Availability -", "");
		if(mapHtml==null && latLng[0]==ALLOW_BLANK)
		{
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null)
				latLng = U.getNewBingLatLong(add);
			
			add=U.getAddressGoogleApi(latLng);
			if(add == null)
				add = U.getNewBingAddress(latLng);
			
			geo="TRUE";
		}
		if(add[0]==null||add[0].length()<4 && latLng[0]!=null)
		{
			add=U.getAddressGoogleApi(latLng);
			if(add == null)
				add = U.getNewBingAddress(latLng);

			geo="TRUE";
		}
		
		if(add[0].isEmpty() && add[3] != ALLOW_BLANK){
			String add1[]=U.getAddressGoogleApi(latLng);
			if(add1 == null)
				add1 = U.getNewBingAddress(latLng);

			add[0] = add1[0];
			geo = "True";
		}
		//------------
		
		//----------------
		//============== SqFt =======================
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

		String[] sqft = U.getSqareFeet(html+comSec+floorPlanHtml+moveHtml, 
				"Up to \\d,\\d{3} square feet|\\d,\\d{3}\\s?-\\s?\\d,\\d{3} Sq. Ft.|Sq. Ft.: \\d,\\d{3}\\s?-\\s?\\d,\\d{3}|\\d,\\d{3} Sq. Ft.", 0);
		minSqft = (sqft[0] != null)? sqft[0] : ALLOW_BLANK;
		maxSqft = (sqft[1] != null)? sqft[1] : ALLOW_BLANK;
		
		//================ Price ====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html = html.replace("'s<", ",000<").replace("0’s", "0,000").replace("8's", "8,000").replace("0's", "0,000");
		html = convertMillonPrice(html);
		html=html.replace("0's", "0,000");
		comSec = comSec.replace("0's", "0,000").replaceAll("'s\\s+</aside>", ",000</aside>").replace("$1 Millions", "$1,000,000");
		comSec = convertMillonPrice(comSec);
		//h=h.replace("'s<", ",000<").replace("0’s", "0,000").replace("8's", "8,000");
		//h = convertMillonPrice(h);
//		U.log(comSec);
		String [] price = U.getPrices(html+comSec+floorPlanHtml+moveHtml, 
				"from the low \\$\\d{3},\\d{3}|from the mid \\$\\d{3},000|Priced\\s*[At|at|From|from]*\\s*(the)*\\s*\\$(\\d,)?\\d{3},\\d{3}|Priced from the\\s*(low|mid|high)\\s*\\$(\\d,)?\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|Sales Price \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}", 0);		
		
		minPrice = (price[0] != null)? price[0] : ALLOW_BLANK;
		maxPrice = (price[1] != null)? price[1] : ALLOW_BLANK;
		
		
		//============= Community Type ===================
		String overview = U.getSectionValue(html, "<i>Overview</i>", "<ul class=\"features");
		String comType = U.getCommunityType(overview+comSec);
		
		//============ Combined Floor Html =====================
		String combinedFloorHtml = null;
		if(floorPlanHtml != null){
			String[] floorUrlSec = U.getValues(floorPlanHtml, "<h3>", "</h3>");
			for(String floorSec : floorUrlSec){
				String floorUrl = U.getSectionValue(floorSec, "<a href=\"", "\"");
				U.log("floorUrl::"+floorUrl);
				String floorHtml="";
				if(floorUrl!=null) {
				floorHtml = U.getHTML(floorUrl);
				combinedFloorHtml += U.getSectionValue(floorHtml, "class=\"neighLiving\">", "class=\"floorPlanImages\">").replace("Oakley model for a taste of modern farmhouse styling", "");
				}
			}
		}
		//================ Combined Move In Html =================
		String combinedMoveHtml = null;
		int moveInCount = 0;
		if(moveHtml != null){
			String[] moveUrlSec = U.getValues(moveHtml, "class=\"regionContent_head\">", "</a>");
			moveInCount = moveUrlSec.length;
			U.log("moveInCount : "+moveInCount);
			for(String moveSec : moveUrlSec){
				String moveUrl = U.getSectionValue(moveSec, "<a href=\"", "\"");
				U.log("moveIn::"+moveUrl);
				String moveInHtml = U.getHTML(moveUrl);
				combinedMoveHtml += U.getSectionValue(moveInHtml, "class=\"neighLiving\">", "class=\"overviewRight\">");
			}
		}
		
		//============= Property Type ====================
	//html = html.replace("Townhouse", "");
		String propType = U.getPropType((html+floorPlanHtml+moveHtml).replaceAll("common area will offer|Townhouse|taste of modern farmhouse styling|premiums, homeowner", "")+combinedFloorHtml);
		propType=propType.replaceAll("Townhouse,","");
		propType=propType.replaceAll(",Common Area","");
		//=============== Property Status ================
		if(overview != null)
			overview = overview.replaceAll("School coming", "");
		if(moveHtml!=null && html.contains("Move-In Ready</a></li>")) {
			overview=overview+" Move In Ready Homes ";
		}
		//U.log(overview);
		String ss=U.getSectionValue(html, "<div class=\"overview\">","<address class=\"address\">");
		
		html=html.replaceAll(" School coming soon|Sports fields and elementary school coming soon","");
		//U.log(html);
		//ss=ss.replace("Final Homesite Remains!", "Final Homesite Remains");
		String sec=U.getSectionValue(html,"<nav class=\"navigation\">", "</nav>");
		html=html.replace("bathhouse coming soon", "");
		html=html.replaceAll(" pool opening Summer 2019| Homestyles Now Available| temporarily sold out with new homesites coming soon.|The Fuller Now Available | miss out on the last chance for the resort|courts coming soon|courts coming soon|LAST OPPORTUNITY\"| LAST OPPORTUNITY</a| SOLD OUT\"| SOLD OUT</a", "");
		html=html.replace("park coming soon", "");
		html=html.replace(sec, "");
//		U.log(comSec);
		String propStatus =  U.getPropStatus((comSec+html).replaceAll("Winchester Homes is now selling new homes|now selling new homes in the growing|courts coming soon|bathhouse coming soon|park coming soon|<h4>Move-in Ready|Chicago Now Available", ""));
		//U.log(Util.match(html, ".*?coming soon.*?"));
		
		if(moveInCount>0 && !propStatus.contains("Move")){
			if(propStatus.length()<4)propStatus="Move-In Ready";
			else propStatus = propStatus+", Move-In Ready";
		}
		
		//============== Derived Type ====================
//		U.log(overview);
		String dType = U.getdCommType((overview+floorPlanHtml+moveHtml+combinedFloorHtml).replaceAll("second floor", "2-Stories"));
		
		

		
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addNotes(notes);
		
	}
	j++;
	}
	
	private String convertMillonPrice(String html){
		Matcher mat = Pattern.compile("\\$\\d\\.\\d+ Millions",Pattern.CASE_INSENSITIVE).matcher(html);
		while(mat.find()){
			String val1 = Util.match( mat.group(), "\\$\\d\\.");
			val1 = val1.replace(".", "");

			String val2 = Util.match( mat.group(), "\\.\\d+");
			val2 = val2.replace(".", ",");
			if(val2.length() == 3) val2 = val2+"0,000";
			if(val2.length() == 2) val2 = val2+"00,000";
			String val = val1+val2;
			html = html.replace(mat.group(), val);
		}
		return html;
	}

	private String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path+"Abc");
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode = U.CheckUrlForHTML(path);
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"181.215.130.32", 3128));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language",
					"en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;

	}
}