package com.shatam.b_021_040;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class HuntingtonHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public int i = 0;
	public int inr = 0;
	static int j = 0;
	static int duplicates = 0;
	ArrayList<String> comm = new ArrayList<String>();
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new HuntingtonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Highland Homes - Huntington Homes.csv", a.data().printAll());
		U.log(duplicates);
	}
	

	public HuntingtonHomes() throws Exception {

		super("Highland Homes - Huntington Homes", "https://www.huntingtonhomestx.com/");
		LOGGER = new CommunityLogger("Highland Homes - Huntington Homes");
	}

	public void innerProcess() throws Exception {
		// System.setProperty("phantomjs.binary.path",
		// System.getProperty("user.home")+File.separator+"phantomjs");
		U.setUpChromePath();
		//U.setUpGeckoPath();
		//driver = new FirefoxDriver();
		driver=new ChromeDriver();
	String html = U.getHTML("https://www.huntingtonhomestx.com");
	//U.log(""+html);
	//	String html = U.getPageSource("https://www.huntingtonhomestx.com");
//		String sec = U.getSectionValue(html, "<a class=\"has-sub\">Communities</a>", "</ul>");
		String sec = U.getSectionValue(html, "<a class=\"has-sub\">", "</ul>");
		String regUrl[] = U.getValues(sec, "<a href=\"", "\"");
		for (String reg : regUrl) {
			String base = "https://www.huntingtonhomestx.com";
			
			U.log("reg==" + reg);
//			if(reg.contains("/dfw"))continue; // Dt.15th Jul 2021 there are no communitites in DFW
//			html = U.getHTML(base + reg);
			html = U.getPageSource(base + reg);
			sec = U.getSectionValue(html, "var communities = [{", "]");
			String regUrl1[] = U.getValues(sec, "display_name", "tagline\":");
			for (String reg1 : regUrl1) {
				addDetail(reg1);
			}
		}
		LOGGER.DisposeLogger();
		driver.quit();
	}

	//TODO :
	private void addDetail(String info) throws Exception {
//		 if(j == 0)
		//try{
		
		{

			
			String base = "https://www.huntingtonhomestx.com";
			String url = U.getSectionValue(info, "fullUrl\":\"", "\"").replace("\\", "");
			info=info.replace("$1.1 Mils", "$1,100,000");
//			 if(!url.contains("woodforest-noble-greens"))return; 
			U.log("URL=" + url);
			U.log(info);
			url = base + url;
			String html = U.getHtml(url, driver);
			//U.log("html driver: "+html);
			LOGGER.AddCommunityUrl(url);
			
			//Single Run
//			if(!url.contains("https://www.huntingtonhomestx.com/houston/montgomery/woodforest-100s"))return;

			String Ehtml = U.getHtml(url + "/explore", driver);
			
			U.log("url :"+url + "/explore");
			String name = U.getSectionValue(info, ":\"", "\"");
			//homedata 15thJul21
			String allHomesData = ALLOW_BLANK;
			String homes[] = U.getValues(html,"<a class=\"button-home btn\" data-price=\"0\" ng-href=\"","\"");
			//String homes[] = U.getValues(html,"home-plans cf","col-xs-12 col-sm-3");
			//U.log("HOMES LENGTH: "+homes.length);
			for(String home:homes) {
				String homeHtm = U.getHtml(base+home, driver);
				allHomesData+=homeHtm;
			}
			
			
			
			// Price

			
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			info = info.replace("\"1 Mils\"", "\"$1,000,000\"");
			info = info.replace("\"760\"", "\"$760,000\"");
			info = info.replace("\"750\"", "\"$750,000\"");
			info = info.replace("\"740\"", "\"$740,000\"");
			info = info.replace("\"880\"", "\"$880,000\"");
			info = info.replace("\"780\"", "\"$780,000\"");
			info = info.replace("\"630\"", "\"$630,000\"");
			String lowPrice = null;
			// info=info.replaceAll("low_price\":\"\\d+", "low_price\":\"\\$\\d+,000");
			if (url.contains("/dfw/frisco/edgestone-at-legacy-90s")) {
				lowPrice = U.getSectionValue(info, "\"low_price\":\"", "\"");
				lowPrice = lowPrice + ",000MyPrice   ";
				U.log(lowPrice);
			}
			//1181990
			Matcher mat = Pattern.compile("low_price\":\"\\d{3}\"", Pattern.CASE_INSENSITIVE).matcher(info);
			while (mat.find()) {
				// U.log(mat.group());
				// U.log(mat.group().replaceAll("\"$", ",000\"").replace("\":\"", "\":\"$"));
				String priceMatch = mat.group().replaceAll("\"$", ",000\"").replace("\":\"", "\":\"$"); // $230s
				info = info.replace(mat.group(), priceMatch);
			}
			// info = info.replace("\",\"high_price\":", ",000\",\"high_price\":");
//			U.log(info);
			// U.log("!!!!!!!!!!!!!!!"+html+"############");

			String[] price = U.getPrices(html + info + lowPrice+allHomesData,
					"\\$\\d,\\d{3},\\d{3}MyPrice|\\$\\d+,\\d+MyPrice|low_price\":\"\\$\\d,\\d{3},\\d{3}|low_price\":\"\\$\\d+,\\d+|\\$\\d+,\\d+,\\d+|class=\"ng-binding\">\\$\\d,\\d{3},\\d{3}|class=\"ng-binding\">\\$\\d{3},\\d+|\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}<meta itemprop=\"price\" ",
					0);
			U.log("price[0]::" + price[0]);
			U.log("price[1]::" + price[1]);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];

			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
			
			// Sq Ft
			
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html + Ehtml,
					"<td class=\"ng-binding\">\\d+,\\d+</td>|\\d,\\d+ to \\d,\\d+ square feet", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			
			
			// Add - Lat - Long
			
			
			String lat = "", lng = "";
			if (html.contains("<a href=\"https://maps.google.com/maps?q=loc:")) {
				String latSec=U.getSectionValue(html, "<a href=\"https://maps.google.com/maps?q=loc:","\"");
				lat=Util.match(latSec, "\\d{2,3}.\\d{3,}");
				lng=Util.match(latSec, "-\\d{2,3}.\\d{3,}");
			} else {
				lat = U.getSectionValue(info, "lat\":\"", "\"");
				lng = U.getSectionValue(info, "lon\":\"", "\"");
			}
			info = U.getSectionValue(info, "time_frame\":\"", "\"");
			String latlngs[] = { lat, lng };
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String addSec = U.getSectionValue(html, "<h3 class=\"page-subtitle\">", "</a>");

			
			if (addSec != null) {
				addSec = addSec.replaceAll("<a href=\"(.*?)\">|</h2>", "").replace("The Fields", "").replace("Windsong Ranch Huntington", "");
				U.log(addSec);

				String[] tempAdd = addSec.split(",");
				if (tempAdd.length == 3) {
					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2], "\\w+");
					add[3] = Util.match(tempAdd[2], "\\d+");
				}
				if (tempAdd.length == 2) {
					// add[0] = tempAdd[0];
					add[1] = tempAdd[0];
					add[2] = Util.match(tempAdd[1], "\\w+");
					add[3] = Util.match(tempAdd[1], "\\d+");
				}
			}
			if (add[0].length() < 4 && latlngs[0].length() > 4) {
				add = U.getAddressGoogleApi(latlngs);
				if(add == null)
					add = U.getGoogleAddressWithKey(latlngs);
				
				geo = "true";
			}

			html = html.replaceAll("Branch", "");
			
			html = html.replaceAll("class=\"ng-hide\">Call</span></td>\\s+<td class=\"ng-binding\">(\\d)</td>", "class=\"ng-hide\">Call</span></td>\\s+<td class=\"ng-binding\"> $1 Story </td>");
			
			String[] secPT = U.getValues(html, "<tbody>", "</tbody>");
			String customPStat = ALLOW_BLANK;
			StringBuilder builder = new StringBuilder();
			boolean one = false, two = false, three = false, onep = false, zero = false;
			for (String str : secPT) {
				// String stori=Util.match(aaa, "<td class=\"ng-binding\">\\d</td>");
				if (str.contains(">0.5") && zero == false) {
					str = str.replaceAll("<td class=\"ng-binding\">0.5", "0.5 Story");
					builder.append(str + ",");
					zero = true;
				}
				if (str.contains(">1.5") && onep == false) {
					str = str.replaceAll("<td class=\"ng-binding\">1.5", ">1.5 Story");
					onep = true;
					builder.append(str + ",");
				}
				if (str.contains(">1") && one == false) {
					str = str.replaceAll("<td class=\"ng-binding\">1", "1 Story");
					one = true;
					builder.append(str + ",");
				}

				if (str.contains(">2") && two == false) {
					str = str.replaceAll("<td class=\"ng-binding\">2<", "> 2 Story <");
					builder.append(str + ",");
					two = true;
				}
				/*
				 * if(str.contains(">3") && three==false){ str =
				 * str.replaceAll("<td class=\"ng-binding\">3", "3 Story"); builder.append(str +
				 * ","); three = true; }
				 */
			}
//			 U.log("My Story String: " + builder);
			// System.exit(1);
			customPStat = U.getdCommType(html+builder.toString()+ name);

			customPStat = customPStat.replaceAll(", ,", ",");
			// String PTYP=U.getdCommType(html);
			// if(PTYP!=ALLOW_BLANK)customPStat=customPStat+", "+PTYP;
			html = html.replaceAll("/luxury\">Luxury Homes<|/SingleFamilyResidence", "");
			allHomesData = allHomesData.replaceAll("/luxury\">Luxury Homes|alt=\"Courtyard\"|description=Courtyard", "");
			// ADD DATA

			


			String combinePro = Ehtml + html;
			
//			combinePro= combinePro.replaceAll("/luxury\">Luxury Homes|alt=\"Courtyard\"|description=Courtyard", "");
//			combinePro = combinePro.replaceAll("Luxur|luxu", "");
			
//			U.log("[[[[[[[[[[[[[[[[[[[["+Util.matchAll(combinePro, "[\\w\\s\\W]{10}Custom Home[\\w\\s\\W]{10}", 0));
//			U.log("[[[[[[[[[[[[[[[[[[[["+Util.matchAll(info, "[\\w\\s\\W]{10}Custom Home[\\w\\s\\W]{10}", 0));

			combinePro=combinePro.replace("Sanders Custom Builder", "");
			
			String propertyType = U.getPropType((combinePro + info));
//			U.log("[[[[[[[[[[[[[[[[[[[["+propertyType);

			if (propertyType.length() < 2) {
				propertyType = ALLOW_BLANK;
			}

			/*
			 * if(url.contains(
			 * "http://www.huntingtoncustomhomes.com/dfw/celina/light-farms-parkview"))
			 * html=html.toLowerCase().
			 * replaceAll("MOVE IN READY HOMES|Move In Ready Homes|move in ready homes|remove"
			 * ,"");
			 */
			html = html.replaceAll(
					"new homes available|New homes available|Now Selling from|Move In Ready Homes \\(0\\)</h3>|nav-title\">Move In Ready Homes", "");
		//	U.log("======"+Util.matchAll(combinePro + info, "[\\w\\s\\W]{30}Luxury[\\w\\s\\W]{30}", 0));
			String status = U.getPropStatus((info+html).replace("Move", ""));
			
			// U.log("################"+status+"###########");
			// U.log("################"+html+"###########");
			if (status.length() < 4)
				status = ALLOW_BLANK;
//			 U.log("======"+info+"=====");
			 
			 if(url.contains("https://www.huntingtonhomestx.com/dfw/frisco/edgestone-at-legacy-90s"))
				 status+=", Final Home Coming Soon";

			Ehtml = Ehtml.replace("Golf\" /> Golf</div>", "Golf\"/> Golf Course</div>");
			// U.log(Ehtml);
			
//			==================================================================================
			String lotCount=ALLOW_BLANK;
			String mapLink=url + "/homesites";
			 U.log("lotCount=="+mapLink);
			 U.log("url=="+url);
			String mapHtml=ALLOW_BLANK;	
			if(mapLink!=null) {
				 mapHtml=U.getHTML(mapLink);
				
				 if(mapHtml!=null) {
					 String [] lot_data=U.getValues(mapHtml, "job#", "/>");
					 U.log("lotCount=="+lot_data.length);
					 if(lot_data.length>0)
					 lotCount=Integer.toString(lot_data.length);
					 }
			}
			U.log("lotCount=="+lotCount);
			
			
			String communityType=U.getCommunityType(html + Ehtml);
			U.log("community Type :: "+communityType);
//				U.log("======"+Util.matchAll(html + Ehtml, "[\\w\\s\\W]{30}golf club[\\w\\s\\W]{30}", 0));

			
			data.addCommunity(name.trim().toLowerCase(), url, communityType);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(propertyType, customPStat);
			data.addPropertyStatus(status);
			data.addNotes(U.getnote(html + info));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(lotCount);
		}
		j++;
		//}catch (Exception e) {}
	}

	public static String dProStatOne(String STR) throws Exception {
		// if(STR==ALLOW_BLANK){
		// STR="1 Story";
		// if(STR.contains("2")){
		if (!STR.contains("1")) {
			STR = "1 Story, " + STR;
		}
		// }
		return STR;
	}

	public static String dProStatTwo(String STR) throws Exception {
		// if(STR==ALLOW_BLANK){
		// STR="2 Story";
		// }else if(STR.contains("1")){
		if (!STR.contains("2")) {
			STR = STR + ", 2 Story";
		}
		// }
		return STR;
	}
}