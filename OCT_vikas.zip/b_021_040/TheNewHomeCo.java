/**
 * @author Priti Chaulkar
 * @date 30/07/2018
 * 
 */

package com.shatam.b_021_040;

import static org.junit.Assert.assertArrayEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class TheNewHomeCo extends AbstractScrapper {
	int count = 0;
	static String HOME_URL = "https://www.nwhm.com";
	static String BUILDER_NAME = "The New Home Companies";
	static int duplicates = 0;
	CommunityLogger LOGGER;
	public int inr = 0;
	String baseUrl = "https://www.nwhm.com";
	WebDriver driver=null;

	static ArrayList<String> COMM_LIST = new ArrayList<String>();

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new TheNewHomeCo();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "The New Home Companies.csv", a.data().printAll());
		U.log(duplicates);
	}

	public TheNewHomeCo() throws Exception {
		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public void innerProcess() throws Exception {
		
		U.setUpChromePath();
		driver=new ChromeDriver();
		String html = U.getHTML("https://www.nwhm.com");
	//	String[] regUrls = U.getValues(html, "class=\"sf-depth-3 sf-no-children\"><a href=\"", "\" class=\"sf-depth-3");
		String regSec=U.getSectionValue(html, "Find Your New Home</span>", "</ul>");
		String[] regUrls = U.getValues(regSec, "<a href=\"", "\"");
		for(String url:regUrls) {
			U.log("Rg Url"+url);
		}
		
		int count = 0;
		String regHtml=ALLOW_BLANK;
		for (String regUrl : regUrls) {
//			 if(!regUrl.contains("san-diego"))return;
			//U.log("::::::::::::::::::::" + "https://www.nwhm.com" + regUrl);
			if(!regUrl.contains("https:")) {
//				U.log("Reg Url"+regUrl);
			   regHtml = U.getHTML("https://www.nwhm.com" + regUrl);
			}
			else {
//				U.log("Reg Url"+regUrl);
			    regHtml = U.getHTML(regUrl);
			}
			String sec = U.getSectionValue(regHtml, "all-neighborhoods-container neighborhood-group",
					"class=\"now-selling-container");
			 if(regUrl.contains("san-diego"))	{
				 sec = U.getSectionValue(regHtml, "all-neighborhoods-container neighborhood-group",
							"class=\"sold-out-container");
//				 	U.log(sec);
			 }
//		if (sec == null) {
//			continue;
//			}//date 16April 22
			// U.log(sec);
			//String comSections[] = U.getValues(sec, "class=\"all-neighborhoods-container neighborhood-group\">", "class=\"now-selling-container neighborhood-group\">");
			if(sec!=null) {
			String comSections[] = U.getValues(sec, "<div class=\"field__item\">", "<div  class=\"regional-map-container row no-gutters\">");
			for (String comSec : comSections) {
				String comUrl = "https://www.nwhm.com" + U.getSectionValue(comSec, "<a href=\"", "\" rel=\"bookmark");
//				U.log("Com Url1::"+comUrl);
				
				String comHtml = U.getHTML(comUrl);
				count++;
				String subSec = U.getSectionValue(comHtml,
						"field field--name-field-masterplan-neighborhood-re field--type", "modal fade modalCalculato");
				if (subSec != null) {
					String[] subComSections = U.getValues(subSec, "<h2>", "regional-map-container");
					for (String subComSec : subComSections) {
						String subComUrl = "https://www.nwhm.com"
								+ U.getSectionValue(subComSec, "<a href=\"", "\" rel=\"bookmark\">");
//						U.log("SubCom Url1::"+subComUrl);
						LOGGER.AddCommunityUrl(":::::::::::::::::Sub Community Url:::::::::::::::::" + comUrl);
//						U.log("sub== "+subComUrl);
						String subComHtml = U.getHTML(subComUrl);
						count++;
					addDetails(subComSec, subComUrl, subComHtml);
					}
				} else {
					LOGGER.AddCommunityUrl(":::::::::::::::::Community Url:::::::::::::::::" + comUrl);
//					U.log("Com Url2::="+comUrl);
					count++;
				addDetails(comSec, comUrl, comHtml);
				}
			}
			}else {
			//============= Colordo Communities ================
//			String colUrl = U.getSectionValue(html, "class=\"sf-depth-2 sf-no-children\"><a href=\"", "\" class=\"sf-depth-2 sf-external\">Colorado</a>");
//			String colHtml = U.getHTML(colUrl);
//			String[] commSec = U.getValues(colHtml, "<article class=\"community\"", "</article>");
			
			
			
			if(regUrl.contains("liveepichomes")) {
				String colHtml=U.getHTML(regUrl);
//				U.log("Reg commUrl::"+regUrl);
				String[] commSec = U.getValues(colHtml, "<article class=\"community\"", "</article>");
			
			for(String comSec : commSec) {
//				U.log("Hello");
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
				count++;
//				U.log("Col commUrl::"+comUrl);
				LOGGER.AddCommunityUrl(":::::::::::::::::Community Url:::::::::::::::::" + comUrl);
				addColoradoDetails(comSec, comUrl);
			}
		}}}///
		driver.quit();
		LOGGER.DisposeLogger();
		System.out.println("Community Count:\t" + count);
	}
 
	private void addColoradoDetails(String comSec, String comUrl) throws Exception {
		// TODO Auto-generated method stub	
//				U.log("commmmmmmmmmmmmm    "+comUrl);
//		if(!comUrl.contains("https://liveepichomes.com/find-your-home/wild-plum/"))return;
//		try {
		
		
		if((comUrl.contains("https://www.nwhm.com/region/sacramento/long-meadow"))||
				(comUrl.contains("https://www.nwhm.com/region/sacramento/primrose-spring-lake"))) return;
		
		
		//comUrl.contains("https://www.nwhm.com/region/inland-empire/ellis-bedford") ||comUrl.contains("https://www.nwhm.com/region/inland-empire/monroe-bedford")
	//Openin g in july	
		
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(":::::::::::::::::Repeated:::::::::::::::::" + comUrl);
			return;
		}
		
		String html = U.getHTML(comUrl);
		
		//====== ComName ================
		String comName = U.getSectionValue(comSec, "<h3 class=\"community-name\">", "<");
		
		U.log("comName: "+comName);
		
		//====== Address ================
		String flag = "FALSE";
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addSec = U.getSectionValue(html.replaceAll("<br />\n\\s*<a href", "<br /><a href"), "<p><strong>sales office</strong></p>", "<br /><a href");
		if(addSec==null)
			addSec = U.getSectionValue(html, "<p><strong>sales office</strong></p>", "<p><a");
		
		if(addSec!=null){
			
			addSec = U.getNoHtml(addSec.replaceAll("</p>\n\\s*<p>|<br />", ",").replace("<p>", ""));
			
			addSec = addSec.replace("Parker CO", "Parker, CO").replaceAll("Rose   Mallow", "Rose Mallow");
			add = U.getAddress(addSec);
			
		}
		
//		U.log("Address: "+Arrays.toString(add));
		//====== NOte ==========
		String note = U.getnote(html+comSec);

		
		//====== LAtlong =============
		String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
		String latSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place", "\"");
		if(latSec!=null){
			
			latSec = U.getSectionValue(latSec, "/@", "/");
			latSec = latSec.replaceAll(",\\d{2}\\w", "");
			latlng = latSec.split(",");
			
		}
		U.log("latlng: "+Arrays.toString(latlng));
		
		if(latlng[0]==ALLOW_BLANK && latlng[0]==ALLOW_BLANK && add[0]==ALLOW_BLANK ) {
			String findHomeAdd=U.getHtml("https://liveepichomes.com/find-your-home/", driver);
			String addSection=U.getSectionValue(findHomeAdd, "<i class=\"fas fa-chevron-right\"></i></a><a href=\"", "\" class");
			if(addSection!=null) {
				addSection=addSection.replace("https://www.google.com/maps/dir//", "").replace("+", " ");
				U.log(addSection);
				latlng[0]=Util.match(addSection,"\\d{2,3}[.]{1}\\d+");
				latlng[1]=Util.match(addSection,"-\\d{2,3}[.]{1}\\d+");
				U.log(Arrays.toString(latlng));
				String removeSection2=U.getSectionValue(addSection, "/", "z");
				
				if(removeSection2!=null) {
					addSection=addSection.replace(removeSection2, "");
				}
				add = U.getAddress(addSection);
				latSec=ALLOW_BLANK;
			}
		}
		
		if(comUrl.contains("https://liveepichomes.com/find-your-home/anthem-reserve/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Broomfield";
			add[2] = "CO";
			add[3] = ALLOW_BLANK;
			note = "Address And LatLong Taken From City & State";
			latlng = U.getlatlongGoogleApi(add);
			U.log("Indide if3"+Arrays.toString(latlng));
			
			add = U.getAddressHereApi(latlng);
			U.log("Indide if4"+Arrays.toString(add));
			
			flag = "TRUE";
		}

		if(latSec==null || latlng[0]==ALLOW_BLANK) {
			
			latlng = U.getlatlongGoogleApi(add);
			flag = "TRUE";
		}
		U.log(flag);
		
		U.log("Note: "+note);
		
		
		//========= FloorPlan =============
		String[] floorSec = U.getValues(html, "<article class=\"model\"", "</article>");
		String floorData = ALLOW_BLANK;
		for(String floor : floorSec) {
			
			String floorUrl = U.getSectionValue(floor, "<a href=\"", "\"");
			U.log("floorUrl: "+floorUrl);
			String floorHtml = U.getHTML(floorUrl);
			floorData += floorHtml;
		}
		
		//========= FloorPlan =============
		String[] quickSec = U.getValues(U.getHTML("https://liveepichomes.com/quick-move-in-homes/"), "<section class=\"page-section community-inventory\">", "</section>");
		String quickData = ALLOW_BLANK;
		for (String quick : quickSec) {

			if(quick.contains(comName)) {
				quickData = quick; 

			String[] qUrl = U.getValues(quick, "<a href=\"https://liveepichomes.com", "\"");
			for(String url : qUrl) {
			quickData += U.getSectionValue(U.getHTML("https://liveepichomes.com"+url), "<section class=\"page-section floorplan-drawings\">", "</section>");
			U.log("quick Urls :: https://liveepichomes.com"+url);
			}
			}
		}

		//======= Price =============
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replace("0&#039;s", "0,000");
		
		String[] price = U.getPrices((html + comSec + quickData + floorData)
				.replace("price green-txt\">$800,000</span>", "")
				.replace("0&#039;s", "0,000").replace("00s", "00,000"),
				"FROM \\$\\d,\\d{3},\\d{3}|Starting From \\$\\d,\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</span>|STARTING FROM \\$\\d{3},\\d{3}|Starting From \\$\\d{3},\\d{3}",0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("Price is :" + minPrice + "\t" + maxPrice);
		U.log("TTTT: "+Util.match( floorData, "[\\w\\s\\W]{30}779,900[\\w\\s\\W]{30}"));

		//========= SQFT ==================
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

		String[] sqft = U.getSqareFeet(html + comSec + quickData,
				">\\d,\\d{3} to \\d,\\d{3} sq. feet<|>\\d,\\d{3} sq ft",0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("sqft is " + minSqft + "\t" + maxSqft);
		
		//===== Community Type ==========
		String cType = U.getCommType(html+comSec);
		U.log("CType: "+cType);
		
		
		//====== D-Property Type ==========
		String dType = U.getdCommType(html+comSec+quickData);
		U.log("DType: "+dType); 
		
		//===== Status =================
		html=html.replace("NOW SELLING! A new home community in Aurora", "").replaceAll("<span class=\"price green-txt\">Sold Out</span></h3>", "");
		String status = U.getPropStatus((html+comSec).replaceAll("<p>COMING SOON</p>|Marketplace now|[Q|Q]uick [M|m]ove", ""));
//		U.log("TTTT: "+Util.match(html+comSec, "[\\w\\s\\W]{30}Now Selling[\\w\\s\\W]{30}"));
		U.log("Status: "+status);
		
	
//		if(!quickData.contains("there are no quick move-in homes"))
//			if(status==ALLOW_BLANK)
//				status = "Quick Move-in Homes";
//			else
//				status += ", Quick Move-in Homes";

		//=======siemap
		String iSiteMapUrlSec=U.getSectionValue(html, "<div class=\"community-siteplan-container\">", "</div>");
		String lotCount=ALLOW_BLANK;
		String lot=ALLOW_BLANK;
		if(iSiteMapUrlSec!=null) {
		String siteMapUrl=U.getSectionValue(iSiteMapUrlSec, "data-src=\"", "\"");
		U.log("siteMapUr::"+siteMapUrl);
		
		String siteMapHtml=U.getHTML(siteMapUrl);
		U.log("cache path of sitemap"+U.getCache(siteMapUrl));
		
		String communityId=U.getSectionValue(siteMapHtml, "communityId: ", ",");
		String siteMapJsonUrl="https://salesarchitect.exsquared.com/api/Lotv2/getbybdxcommunityid/?bdxCommunityId="+communityId+"&communityNumber=";
		
		U.log("siteMapJsonUrl:: "+siteMapJsonUrl);
		String siteMapJson=U.getHTML(siteMapJsonUrl);
		U.log("json path::  "+U.getCache(siteMapJsonUrl));
		int lotsCount=0;
		
	//	U.log("Json:: "+siteMapJson);
//		String lotSec=U.getSectionValue(siteMapJson,"<d2p1:LotData>", "</d2p1:LotData>");
//		String lotDataSec[]=U.getValues(lotSec, "<d2p1:SiteOverviewLot>", "</d2p1:SiteOverviewLot>");
		if(siteMapJsonUrl.contains("salesarchitect.exsquared.com")) {
			String lotSec=U.getSectionValue(siteMapJson,"<d2p1:LotData>", "</d2p1:LotData>");
			String lotDataSec[]=U.getValues(lotSec, "<d2p1:SiteOverviewLot>", "</d2p1:SiteOverviewLot>");
			lotsCount=lotDataSec.length;
		}
		else {
		JsonParser parser =new JsonParser();
		
	
		
//		Object obj=parser.parse(siteMapJson);
//		JsonObject commJsonObj = (JsonObject)obj;
		
		JsonArray array= parser.parse(siteMapJson).getAsJsonObject().get("Model").getAsJsonObject().get("LotData").getAsJsonArray();
		U.log("tiotal lots"+array.size());
		for(JsonElement element : array) {
			//U.log(element.toString());
			lot+=" "+element.toString();
		}
		
		  lotsCount=array.size();
		 lotCount=Integer.toString(lotsCount);
		}
		
		if(lotCount.equals("0"))
			lotCount=ALLOW_BLANK;
		
		U.log("No. Of Units:: "+lotCount);
	}
		//===== Property TYpe ===========
				String pType = U.getPropType(html+comSec+quickData+lot);
				U.log("PType: "+pType);
				
		
		//		for(int i=0;i<array.size();i++) {
//			JsonObject lot=(JsonObject) array.get(i);
//			String lotData=lot.getAsString();
//			U.log("Lot in String"+lotData);
//		}
//		
		
		/*String lot=ALLOW_BLANK;
		for(String lotData:lotDataSec) {
			lot+=" "+lotData;
		}*/
		

				
		
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latlng[0], latlng[1], flag);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status.replace("Quick Move-in Homes","Move-in Ready"));   
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(lotCount);
//	}catch(Exception e) {};

	}

	private void addDetails(String comSec, String comUrl, String comHtml) throws Exception {
		// if(inr==1)
		// if(count==1)
//		U.log("cooooooooooooo   "+comUrl);

		//single run
//		if(!comUrl.contains("https://liveepichomes.com/find-your-home/wild-plum/"))return;
		
//			try {
		// :TODO
//		if(comUrl.contains("https://www.nwhm.com/region/inland-empire/ellis-bedford"))return; //no data opening in July
        if(comUrl.contains("https://www.nwhm.com/region/phoenix/coming-soon-surprise"))return;//no data
//		if(comUrl.contains("https://www.nwhm.com/region/inland-empire/monroe-bedford"))return;// no data  opening in July
		
		if (comUrl.contains("https://www.nwhm.com/region/bay-area/ellison-park"))return;
		if (comUrl.contains("https://www.nwhm.com/region/bay-area/tidewater-river-islands"))return;
		if (comUrl.contains("https://www.nwhm.com/region/sacramento/park-view-whitney-ranch"))return; //redirect to build-community url
        
		if(comUrl.contains("https://www.nwhm.com/index.php/region/inland-empire/ellis-bedford"))return;//coming soon
		if(comUrl.contains("https://www.nwhm.com/index.php/region/inland-empire/monroe-bedford"))return;//CS
		if(comUrl.contains("https://www.nwhm.com/region/sacramento/ridgeview"))return;//cs
		if(comUrl.contains("https://www.nwhm.com/region/coming-soon-roseville")) return;//cmng soon
		
		if(comUrl.contains("https://www.nwhm.com/region/sacramento/long-meadow")) return;//not opening
		if(comUrl.contains("https://www.nwhm.com/region/sacramento/primrose-spring-lake")) return;//not opening
			
		
		
		
		
//		if (!comUrl.contains("https://liveepichomes.com/find-your-home/wild-plum/"))return;
		
		
//		https://www.nwhm.com/region/inland-empire/parson-bedford
//		U.log(comSec);

		U.log("comUrl : " + comUrl);
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(":::::::::::::::::Repeated:::::::::::::::::" + comUrl);
			return;
		}
		if (comUrl.contains("/region/sacramento/mckinley-village"))
			comHtml += U.getHTML("https://mckinleyvillage.com/residences");
		if (comUrl.contains("region/sacramento/russell-ranch"))
			comHtml += U.getHTML("https://www.liverussellranch.com/homes");

		// -----remove nearby communities-----
		// comHtml = comHtml.replace(U.getSectionValue(comHtml, "<div
		// class=\"neighborhood-callout-slideshow\" >", "</article>"), "");
		
		String comName = U.getSectionValue(comHtml, "name-title field--type-string field--label-hidden\">", "</span>");
		
		if(comName.contains("Neighborhoods"))
		{
			comName=comName.replace("Neighborhoods", "");
		}
		
		U.log("comName : " + comName);
		if (comName == null) {
			comName = U.getSectionValue(comHtml, "<title>Residences | ", "</title>");
		}

	
		String remove = U.getSectionValue(comHtml, "<div class=\"mosaic-boxes hidden\">", "</footer>");
		if (remove != null) {
			comHtml = comHtml.replace(remove, "");
		}

		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		latLng[0] = U.getSectionValue(comSec, "latlon latlon-lat\">", "<");
		latLng[1] = U.getSectionValue(comSec, "latlon latlon-lon\">", "<");
		if (latLng[0] == null) {
			latLng[0] = U.getSectionValue(comHtml, "latlon latlon-lat\">", "<");
			latLng[1] = U.getSectionValue(comHtml, "latlon latlon-lon\">", "<");

		}
		U.log("Latlng is1:" + Arrays.toString(latLng));
		if (latLng[0] == ALLOW_BLANK || latLng[0] == null) {
			if (comHtml.contains("<div class=\"field field--name-field-directions-link")) {
				String latLngSec = U.getSectionValue(comHtml, "<div class=\"field field--name-field-directions-link",
						">Directions</a>");
				if(latLngSec==null)
					latLngSec=U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/", "data=");
				String latLngSec1 = U.getSectionValue(latLngSec, "/@", ",17z");
				if (latLngSec1 == null)
					latLngSec1 = U.getSectionValue(latLngSec, "/@", "z/");
				if (latLngSec1 != null)
					latLng = latLngSec1.split(",");
			}
		}

		U.log("Latlng is :" + Arrays.toString(latLng));
		

		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		String note = U.getnote(comHtml.replaceAll(
				"<div class=\"field__label\">Is this Pre-Selling</div>\\s+<div class=\"field__item\">No</div>|field-is-this-pre-selling field|is-this-pre-selling field-|Is this Pre-Selling",
				""));
		add[0] = U.getSectionValue(comHtml,
				"location-address-line-one field--type-string field--label-hidden field__item\">", "</div>");

		if(add[0]!=null)
			add[0]=add[0].replace("Paseo Ontario", "Paseo, Ontario").replace("4546 S. Riata Street, #101", "4546 S. Riata Street").replace(", #102", "");
		if (add[0] != null && add[0].contains("AZ 85255")) {
			add = U.getAddress(add[0].replace(", #4003 |", ","));
		}
		String addSec = U.getSectionValue(comHtml,
				"location-address-line-two field--type-string field--label-hidden field__item\">", "<");
		U.log("MMMM " + add[0]);
		U.log(addSec + "::|::::::M");
		
		if (addSec != null && add[0] != null) {
			U.log("isValid");
			if (addSec.contains(", CA") || addSec.contains("CA")) {
				addSec = addSec.replace(" CA, 94536", " CA 94536").replace("Irvine CA,", "Irvine, CA").replace("241 Merit", "241 Merit, ")
						.replace("Rancho Cucamonga CA 91730", "Rancho Cucamonga, CA, 91730").replaceAll("CA,", "CA");
				String[] temp = addSec.split(",");
				add[1] = temp[0];
				add[2] = Util.match(temp[1], "\\w+");
				add[3] = Util.match(temp[1], "\\d{5}");
			}
			if (addSec.contains(", AZ")) {
				add[0] = add[0].replaceAll(",", "");
				String[] temp = addSec.split(",");
				add[1] = temp[0];
				add[2] = Util.match(temp[1], "\\w+");
				add[3] = Util.match(temp[1], "\\d{5}");
			}
			if (add[0] == null)
				add[0] = ALLOW_BLANK;
		}
		
		if(add[0]!=null && add[0].contains(",") & add[1]==ALLOW_BLANK && add[2]==ALLOW_BLANK && add[3]==ALLOW_BLANK) {
			add[0]=add[0].replace("CA 91762", "CA, 91762");
			U.log(add[0]);
			String[] addSection=add[0].split(",");
			for(int i=0;i<addSection.length;i++) {
				add[i]=addSection[i];
			}
		}
		
		U.log("Address is :" + Arrays.toString(add));
		if (comUrl.contains("https://www.nwhm.com/region/phoenix/mosaic-layton-lakes")
				|| comUrl.contains("https://www.nwhm.com/index.php/region/phoenix/mosaic-layton-lakes")) {
			add[1] = "Gilbert";
			add[2] = "AZ";
			latLng = U.getlatlongGoogleApi(add);
			if (latLng == null)
				latLng = U.getGoogleLatLngWithKey(add);
			add = U.getAddressGoogleApi(latLng);
			geo = "TRUE";
			note = "Address taken from City & State";
		}

		if (comUrl.contains("https://www.nwhm.com/region/orange-county/azure-esencia")) {
			add[0] = "181 Alienta Ln";
			add[1] = "Rancho Mission Viejo";
			add[2] = "CA";
			add[3] = "92694";
			latLng[0] = "33.549193";
			latLng[1] = "-117.598639";
			geo = "False";
		}
		if (add == null)
			add = U.getGoogleAddressWithKey(latLng);
		if (add[3] == null)
			add[3] = ALLOW_BLANK;
		if (add[3] == null)
			add[3] = ALLOW_BLANK;
		if ((add[0] == null || add[3].length() < 4) && latLng[0] != null && latLng[0].length() > 4) {
			add = U.getAddressGoogleApi(latLng);
			if (add == null)
				add = U.getGoogleAddressWithKey(latLng);
			geo = "TRUE";
		}

		if (comUrl.contains("https://www.nwhm.com/region/sacramento/russell-ranch")) {
			add[0] = ALLOW_BLANK;
			add[1] = "Folsom";
			add[2] = "CA";
			add[3] = ALLOW_BLANK;
			
			latLng = U.getlatlongGoogleApi(add);
			if(latLng==null)latLng = U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
		}

		add[0]=add[0].replace("Power Inn & Vista Brook (NB)", "Power Inn & Vista Brook");		
    		// --------price----------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comHtml = U.removeSectionValue(formatMillionPrices(comHtml), "<div class=\"brighton-landing-boxes hidden\">",
				"</footer>");
		comHtml = comHtml.replace("0&#039;s", "0,000").replace("From $1.825 Million", "From $1,825,000 Million");
		comSec = comSec.replace("0s", "0,000");
		comSec=comSec.replace("<li>From the High $400,000,000</li>", "<li>From the High $400,000</li>");
//		comSec=comSec.replace("From the Mid $500,000,000", "From the Mid $500,000");
//		U.log(comHtml);
		String newhtml=U.getHTML(comUrl);
		
//		U.log("------------------------mmmmmm\n"+Util.matchAll(newhtml, "[\\w\\s\\W]{30}$500,000s[\\w\\s\\W]{30}", 0));
//		U.log("------------------------mmmmmm\n"+Util.matchAll(comSec, "[\\w\\s\\W]{30}$500[\\w\\s\\W]{30}", 0));

		//========= FloorPlan =============
				String[] floorSec = U.getValues(comHtml, "teaser-image-wrapper\">", "</article>");
				String floorData = ALLOW_BLANK;
				int qCount=0;
				for(String floor : floorSec) {
					if(floor!=null) {
						if(floor.contains("Move-In: 09/2022") || floor.contains("Move-In 09/2022")) {
							qCount++;
						}//<div class="field field--name-field-strike-through-price field--type-string field--label-hidden field__item">
						String removeSec=U.getSectionValue(floor, "<div class=\"field field--name-field-strike-through-price field--type-string field--label-hidden field__item\">", "</div>");
						if(removeSec!=null) {
							floor=floor.replace(removeSec, "");
						}
					}
					
					String floorUrl = U.getSectionValue(floor, "<a href=\"", "\"");
					U.log("floorUrl: "+floorUrl);
//					String floorHtml = U.getHTML("https://www.nwhm.com"+floorUrl);
//					floorData += floorHtml;
				}
				U.log("qCount :: "+qCount);
				
		String FooterSec=U.getSectionValue(newhtml, " <div class=\"brighton-landing-boxes hidden\">", "</footer>");
//		U.log("***********"+FooterSec);
		String footersec=null;
		if(comName.contains(" Brighton Landing"))
		{
			String[] newSec=U.getValues(FooterSec, " <label class=\"form-check-label\" for=\"", "</label>");
			for(String Newsec : newSec)
			{
				if(Newsec.contains(comName))
				{
					footersec =Newsec;
				}
			}
		}
		
		String[] removeSec=U.getValues(comHtml, "<div class=\"field field--name-field-strike-through-price field--type-string field--label-hidden field__item\">", "</div>");
		if(removeSec.length>0) {
			for(String removeSection:removeSec) {
				comHtml=comHtml.replace(removeSection, "");
		}
			
		}
		
//		U.log("***********"+footersec);
		String[] price = U.getPrices(comHtml + comSec+footersec,
				"\"> \\d{3},\\d{3}</a>|From the Mid \\$\\d{3},\\d{3}s|From \\$\\d,\\d{3},\\d{3} Million|<li>From the Low \\$\\d{3},\\d{3}s to Low \\$\\d{3},\\d{3}s</li>|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
				0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		// if(comUrl.contains("https://www.nwhm.com/region/sacramento/mckinley-village"))
		// maxPrice=maxPrice.replace("$900,000", "$800,000");
//		String unwanted=U.getSectionValue(comHtml,"<p class=\"checkbox-intro\">","</footer>");
//		U.log("UUU"+unwanted);
//		comHtml=comHtml.replace(unwanted, "");
		U.log("Price is :" + minPrice + "\t" + maxPrice);
		if(comUrl.contains("https://www.nwhm.com/region/bay-area/bristol-brighton-landing")) {minPrice="$600,000";maxPrice=ALLOW_BLANK;}

		// --------price----------
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		// U.log(Util.match(comHtml, ".*973.*"));
		// comHtml = U.removeSectionValue(comHtml, "Select your neighborhood(s) of
		// interest:</div>", "</html");
		String[] sqft = U.getSqareFeet(
				comHtml.replace("00s", "00,000").replaceAll("li>10,973 Square Feet Lot Size</li>|14,608 Square Feet Lot", "") + comSec,
				"\\d,\\d{3} - \\d,\\d{3} SQ. FT.|\\d,\\d{3} to \\d,\\d{3} Sq. Ft. of Living Space|\\d,\\d{3}-\\d,\\d{3} Sq\\. Ft\\. of Living Space|>\\d,\\d{3} to \\d,\\d{3} Square Feet|\\d,\\d{3} Sq. Ft. of Living Space|\\d,\\d{3} to \\d,\\d{3} Square Feet of Living Space|<li>\\d{3} to \\d,\\d{3} Square Feet of Living Space|\\d,\\d{3} sq. ft. to \\d,\\d{3} sq. ft|\\d,\\d{3} to \\d,\\d{3} Square Feet|\\d,\\d{3} Square Feet|\\d,\\d{3} Sq. Ft",
				0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		U.log("sqft is " + minSqft + "\t" + maxSqft);
//		 U.log(Util.matchAll(comSec + comHtml, ".*2,209.*", 0));
		if(comUrl.contains("https://www.nwhm.com/region/coming-soon-roseville"))minSqft=ALLOW_BLANK;

		// ------comtype---------
		comHtml = comHtml.replace("field__item\">Masterplan</div>", "master-plan community")
				.replaceAll("Paradise Valley Country Club|Bay Golf Club|>Sliverleaf Country Club|>The Country Club at DC Ranch", "");
		String comType = U.getCommunityType((comHtml + comSec).replace("label-hidden field__item\">TopGolf</div>", "")
				.replaceAll("Woodcreek Golf Club </div>|Golfland Sunsplash</div>|Casino Resort </div>", ""));
		
		
		if (comUrl.contains("https://www.nwhm.com/region/orange-county/azure-esencia")
				|| comUrl.contains("https://www.nwhm.com/region/orange-county/cobalt-esencia")
				
				|| comUrl.contains("https://www.nwhm.com/region/sacramento/park-view-whitney-ranch"))
			comType = "Master planned";
		U.log("comType : " + comType);

//		U.log("=============: "+Util.match(comHtml+comSec, "[\\s\\w\\W]{30}Single-Family Detached[\\s\\w\\W]{30}"));
		comHtml = comHtml.replace("detached two-story", "detached homes two-story")
				.replace("farmhouse urban", "Farmhouse-inspired architectura")
				.replace("Luxury, Single-Family", "Luxury homes , Single-Family").replaceAll("VillaSport|custom-question|customer-care|custom-modal|Customer|customer|customer service", "");
		String propType = U.getPropType(
				(comHtml + comSec).replace("flex options", "flex room").replace("<li>Collectible Cottage Interior Design  </li>", "")
				.replaceAll("Style Condominium </li>|Cottage Elevation|craftsmanship|Village|Traditional School", ""));
		U.log("propType : " + propType);

		// ------dType---------
		comHtml = comHtml.replaceAll(
				"Ranch Elevation|Ranch Park</div|DC Ranch|The Ranch Rocks|Rancho|Colonial Revival Elevation|Spanish Colonial Elevation","")
				.replaceAll("Single-&amp; Two-Story Homes", "one story and two story")
				.replace("Single-&amp; Two-Story Floorplans", "1 Story and 2 Story Floorplans");
		
		String dType = U.getdCommType((comHtml + comSec).replaceAll("Orchard Ranch Elementary </div>|DC Ranch|Rancho|[F|f]irst [f|F]loor", ""));
		if (comUrl.contains("https://www.nwhm.com/region/inland-empire/nova-rancho-cucamonga-resort"))
			dType = dType.replace(", Ranch", "");
		U.log("dType : " + dType);
		
		if(comUrl.contains("https://www.nwhm.com/region/coming-soon-roseville"))dType=ALLOW_BLANK;

		// ---------ignore------
		comHtml = comHtml.replaceAll(
				"its final phase of residences|item\">Now Selling</div>|nav-move-in\">Move-In Ready</div>|height=\"300\" alt=\"Grand Opening\"|grand-opening-gallery\">Grand Opening|hidden field__item\">Sold Out</div>|container\">\\s*<li>Sold Out</li>|Homes Coming Winter 2018|Grand Opening Gallery|Grand Opening Image Gallery|<p>COMING THIS FALL",
				"");
		
		
		// ------pStatus---------
		comHtml = comHtml.replace("Move-In Ready", "Move-In Ready Homes").replace("First 4 Neighborhoods Now Open &amp; Selling", "");
		comSec=comSec.replace("Now Open &amp; Selling in Folsom", "");
		comHtml = comHtml.replaceAll("Quick Move-In Homes</a>|First 4 Neighborhoods Now Selling|label-hidden field__item\">Now Selling!</div>", "")
				.replaceAll("ld--label-hidden field__item\">Now Selling</div>|selling active-nav\">Now Selling</div>", "");
	
		if(comHtml!=null) {
			comHtml=comHtml.replace("Now Open &amp; Selling", "Now Open And Selling");
		}
		
		String pStatus = U.getPropStatus((comHtml.replace("&amp;", "&").replace("<li>SOLD OUT</li>", "")+ comSec)
				.replaceAll("move|MOVE|Move", "")
				.replaceAll(
				"Pricing Coming Soon|PRICING COMING SOON|nav-item nav-now-selling active-nav\">Now Selling|type--move-in-ready-residence|field field--name-field-move-in-ready-|ld__item\">Information Trailer Now Open!</div>|label-hidden field__item\">Coming Soon</div>|hidden field__item\">New Homes Coming Soon|<li>Temporarily Sold Out</li>|INCENTIVES ON MOVE-IN|READY HOMES</a>|move-in\">Move-In|Coming 2019|item even\">SOLD OUT</div>|ast collection of homes now selling|Grand Opening Gallery|alt=\".*\"|alt=\"Sky Ranch Grand Opening\"|Grand Opening Gallery|modern design. Coming 2019.</div>",
				"")
				.replaceAll("Move-In Ready Homes|move-in-ready|", ""));
		
		
		if(qCount>0)
		if(pStatus==ALLOW_BLANK)
			pStatus = "Move-In Ready";
		else
			pStatus += ", Move-In Ready";

		if(comUrl.contains("https://www.nwhm.com/region/sacramento/silver-crest-russell-ranch")) {
			pStatus="Now Open And Selling";
		}
     	if(comUrl.contains("https://www.nwhm.com/region/bay-area/bristol-brighton-landing"))pStatus="Now Selling, Sold Out";
	    if(comUrl.contains("https://www.nwhm.com/index.php/region/sacramento/silver-crest-russell-ranch"))pStatus="Now Selling, Now Open";
	    
	    
//	    U.log("------------------------mmmmmm\n"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Now Open[\\w\\s\\W]{30}", 0));
//	    U.log("------------------------mmmmmm\n"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}Now Selling[\\w\\s\\W]{30}", 0));
	    
		U.log("pStatus : " + pStatus);

		if (comUrl.contains("https://www.nwhm.com/region/inland-empire/nova-rancho-cucamonga-resort"))
			propType = propType + ", Apartment Homes";
	

		if (comUrl.contains("https://www.nwhm.com/index.php/region/bay-area/preston-brighton-landing")
				|| comUrl.contains("https://www.nwhm.com/index.php/region/bay-area/sheffield-brighton-landing"))
			pStatus = pStatus.replace(", "
					+ "", "");


		if (comUrl.contains("https://www.nwhm.com/region/phoenix/cottages-mariposa"))
			pStatus = pStatus.replaceAll(", Move-in Ready Homes|Move-in Ready Homes,|Move-in Ready, ", "");

		if (comUrl.contains("https://www.nwhm.com/region/phoenix/towns-mosaic-layton-lakes")
				|| comUrl.contains("https://www.nwhm.com/region/phoenix/rows-mosaic-layton-lakes"))
			propType = propType.replaceAll("Condominium,", "");

		if (add[0] == null) {
			add[0] = ALLOW_BLANK;
		}

		add[0] = add[0].replace(",", "");
		comName = comName.toLowerCase();
		// LOGGER.AddCommunityUrl(comUrl);
		System.out.println("=========M"+Arrays.toString(latLng));
		if (add[0] != null && add[0] != ALLOW_BLANK && latLng[0] == null) {
			latLng = U.getGoogleLatLngWithKey(add);
			geo = "True";
		}
		
		if (latLng[0] == null)
			latLng[0] = latLng[1] = ALLOW_BLANK;
		
		
		if(add[0].contains("Coming Soon"))
		{
			add=U.getAddressGoogleApi(latLng);
		}
		System.out.println(Arrays.toString(latLng));
		
		pStatus=pStatus.replace("-, Move-In Ready", "Move-In Ready");
		pStatus=pStatus.replace("Now Open & Selling, Now Open", "Now Open And Selling");
		pStatus=pStatus.replace("Now Open & Selling, Now Selling, Now Open", "Now Open And Selling");
		pStatus=pStatus.replace("Coming Soon, Coming 2023", "Coming 2023");	
		
		
		//=======site map========
		String lotCount=ALLOW_BLANK;
		String iSiteMapUrlSec=U.getSectionValue(comHtml, "<div class=\"field field--name-field-site-plan-url", "</a>");
		if(iSiteMapUrlSec!=null)
		{
		String siteMapUrl=U.getSectionValue(iSiteMapUrlSec, "<a href=\"", "\"");
		U.log("SiteMap Url"+siteMapUrl);
		
		String siteMapHtml=U.getHtml(siteMapUrl,driver);
		U.log("Path:: "+U.getCache(siteMapUrl));
		
		String[]lotsData=U.getValues(siteMapHtml, "<g id=\"lot_", "</g>");
		int lotsCount=lotsData.length;
		lotCount=Integer.toString(lotsCount);
		 if(lotCount.equals("0"))
			 lotCount=ALLOW_BLANK;
	}		
		U.log("No. Of Units:: "+lotCount);		
		
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(U.getCapitalise(add[0].toLowerCase().trim()), add[1], add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].replaceAll(",.*", "").trim(), geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus.replace("&", "and"));
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(lotCount);
		
//		}catch(Exception e) {};

	}

	// Format million price
	public static String formatMillionPrices(String html) {
		Matcher millionPrice = Pattern.compile("\\$\\d Million", Pattern.CASE_INSENSITIVE).matcher(html);
		while (millionPrice.find()) {
			// U.log(mat.group());
			String floorMatch = millionPrice.group().replace(" Million", ",000,000"); // $3 M
			html = html.replace(millionPrice.group(), floorMatch);
		} // end millionPrice
		Matcher millionPrice2 = Pattern.compile("\\$\\d\\.\\d Million", Pattern.CASE_INSENSITIVE).matcher(html);
		while (millionPrice2.find()) {
			// U.log(millionPrice2);
			String floorMatch = millionPrice2.group().replace(" Million", "00,000").replace(".", ","); // $1.3 M
			html = html.replace(millionPrice2.group(), floorMatch);
		} // end millionPrice
		return html;
	}

}