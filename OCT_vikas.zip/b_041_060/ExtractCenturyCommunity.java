/** @author Parag Humane
 *  @date 27/05/2013 
 *  Modification Priti...
 *  
 */

package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.regexp.recompile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;

public class ExtractCenturyCommunity extends AbstractScrapper {
	int i = 0,  duplicate = 0;
	public int inr = 0;
	static int k=0,j=0,count=0,m=0;
	WebDriver driver=null;

	CommunityLogger LOGGER;
	static String BASEURL = "https://www.centurycommunities.com/";
	
	//date 18 dec2021
	
	

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractCenturyCommunity();
		a.process();
		//a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Century Communities.csv", a.data()
				.printAll());
	}

	public ExtractCenturyCommunity() throws Exception {

		super("Century Communities", "https://www.centurycommunities.com/");
		LOGGER = new CommunityLogger("Century Communities");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();

		
		String baseHtml=U.getHTML("https://www.centurycommunities.com/");
//		String stateSecUrl=U.getSectionValue(baseHtml, "Find Your Home</a>", "<a href=\"/homebuying-process\">Homebuyers</a>");
//		String[] metroStateUrls=U.getValues(stateSecUrl, "<a href=\"", "\">");
//		for(String subMetro:metroStateUrls) {
//			
//		}
		
//		String stateSec=U.getSectionValue(baseHtml, "Select Location", "</select>");
//		String[] regions=U.getValues(stateSec,"\">","</option>");
//		
//		String subRegSec=U.getSectionValue(baseHtml, "name=\"InterestedInMetro\" ","</select>");
//		String [] subRegion=U.getValues(subRegSec, "<optgroup", "</optgroup>");
//		for(String mainReg:subRegion) {
//			String state=U.getSectionValue(mainReg, "label=\"", "\">");
//			U.log("State"+state);
//			String metroSec[]=U.getValues(mainReg, "<option value=\"", "</option>");
//			for(String metro:metroSec) {
////				U.log("Mterp"+metro);
//			//	metro=metro.replaceAll("<option value=\"\\d+\">", "").trim();
//				metro=metro.replaceAll("\\d+\">|,", "");
//				metro=metro.replace("/","-");
//				if(metro.contains("Colorado Springs "))
//					metro="colorado springs metro";
//				if(metro.contains("SC Charlotte Metro"))
//					metro=metro.replace("SC ", "");
//				String regUrl="https://www.centurycommunities.com/find-your-home/"+state.toLowerCase().replace(" ", "%20");
//			    U.log(regUrl);
//			    if(regUrl.contains("https://www.centurycommunities.com/find-your-home/north%20carolina/greensboro/high-point-metro"))
//			      continue;
			    String stateSecUrl=U.getSectionValue(baseHtml, "Find Your Home</a>", "<a href=\"/homebuying-process\">Homebuyers</a>");
				String[] metroStateUrls=U.getValues(stateSecUrl, "<a href=\"", "\">");
				for(String regionUrls:metroStateUrls) {
					regionUrls="https://www.centurycommunities.com"+regionUrls;
//					U.log("regionUrls :: "+regionUrls);
					if(regionUrls.contains("https://www.centurycommunities.com/find-your-home/florida/southeast-florida-metro")) {
			    		continue;
			    	}
			    String regHtml=U.getHTML(regionUrls);
			  //  U.log("rr"+regHtml);
			    String[] commSec=U.getValues(regHtml, "<div class=\"col-xl-4 col-lg-6 col-sm-6 community-column\">", "<a class=\"btn community-button\"");
//			    U.log(commSec.length);
			    if(commSec==null)
			    	commSec=U.getValues(regHtml, "<h2 class=\"title\">", "<div class=\"button-link\">");
			   
			 //   String[] commSec=U.getValues(regHtml, "<a class=\"btn community-button\"", "View Homes");
//			    U.log("comm in reg"+state+">>"+metro+"are::"+commSec.length);
			    for(String comSec:commSec) {
			    //	U.log("COMSEC"+comSec);
			    	String comUrl=U.getSectionValue(comSec, "<a href=\"", "\">");
			    	comUrl="https://www.centurycommunities.com/"+comUrl;
//			    	U.log("Url"+comUrl);
			    	String comNameSec=U.getSectionValue(comSec,"<p class=\"company-name\">", "/a>");
			    //	U.log("Com namew Sec"+comNameSec);
			    	String comName=U.getSectionValue(comNameSec,"\">", "<");
//			    	U.log("Community name"+comName);
			    	addDetails(comUrl,comName,comSec);
			    	m++;
			    }
			}
			
			//if(state.contains("Indiana")) {
			
			
			//}
//			}
			
			String mregUrl="https://www.centurycommunities.com/find-your-home/indiana/louisville-metro";
		    String mregHtml=U.getHTML(mregUrl);
		    String mcommSec[]=U.getValues(mregHtml, "<div class=\"col-xl-4 col-lg-6 col-sm-6 community-column\">","<a class=\"btn community-button\"");
		   for(String mcomSec:mcommSec) {
//			   U.log("Inside indiana="+mcommSec.length);
		    String comUrl=U.getSectionValue(mcomSec, "<a href=\"", "\">");
	    	comUrl="https://www.centurycommunities.com/"+comUrl;
//	    	U.log("Url"+comUrl);
	    	String mcomNameSec=U.getSectionValue(mcomSec,"<p class=\"company-name\">", "/a>");
		    //	U.log("Com namew Sec"+comNameSec);
		    	String mcomName=U.getSectionValue(mcomNameSec,"\">", "<");
//		    	U.log("Community name="+mcomName);
		    	addDetails(comUrl,mcomName,mcomSec);
		    	m++;
		    	U.log("total"+m);
		}
//			driver.quit();		


		LOGGER.DisposeLogger();
//		
	}

	
	private void addDetails(String comUrl, String communityName, String comInfo) throws Exception {
//		try{
		//if(j>=277)
//		if(j>=0 && j<=50)//d
//			if(j>=50 && j<=100)//d
//				if(j>=100 && j<=150)
//					if(j>=150 && j<=200)
//						if(j>=200 && j<=250)
//		if(j>=140 && j<=200)
//			if(j>=211 && j<=250)
//		if(j>340)
		{

			//TODO :		
//			if(!comUrl.contains("https://www.dsldhomes.com/communities/louisiana/lafayette/briars-cove"))return;
		
			/**
			 * @author Sawan Meshram
			 * @date 17 Jan 2022
			 */
//			if(comUrl.contains("https://www.centurycommunities.com//find-your-home/washington/seattle-metro/puyallup/pines-at-sunrise")){
//				LOGGER.AddCommunityUrl(comUrl+"-------------> Page Not Found");
//				return;
//			}

			if(comUrl.contains("https://www.centurycommunities.com//find-your-home/texas/austin-metro/leander/crystal-springs/crystal-springs-falls")) {
				LOGGER.AddCommunityUrl("=======Page Not found======"+comUrl);
				return;
			}
			
		if(this.data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"**************************repeat");
			k++;
			return;
		}	
		LOGGER.AddCommunityUrl(comUrl);
		
		
		if(communityName != null)
			communityName  = communityName.replaceAll("Paired Homes|Manor", "").replaceAll("Cottages$|- Parker City| - SOLD OUT| - Winterville| - Lake City", "");
		U.log("\n:::::::::::::::"+j+":::::::::::::::::::::::::\n");
		communityName=communityName.replaceAll("Cross Creek - Freeport","Cross Creek")
				.replaceAll("Stonewall Villas","Stonewall")
				.replaceAll("American Fork Crossing Villas","American Fork Crossing");
		U.log("communityName======= "+communityName);
		U.log("comUrl::::::::"+comUrl);
		U.log(U.getCache(comUrl));
		
		String html=U.getHTML(comUrl);
		String galleryflagStatu= U.getSectionValue(html, "<div class=\"gallery_flags\">", "</div");
		U.log("flag status:::"+galleryflagStatu);
		
		String overviewSec=U.getSectionValue(html, " <div class=\"overview-description \">", "</div")+U.getSectionValue(html, "\"description\":\"", "\"")
		+U.getSectionValue(html, "<div class=\"overview-description full\">", "</div>");
		
		
		/*
		 * Remove section
		 */
		String[] remove = U.getValues(html, "<div class=\"modal-body\">", "</button>");
		for(String rem : remove) html = html.replace(rem, "");
		
		remove = U.getValues(html, "<div class=\"per-month-price price_container hide-content\">", "<div class=\"starting-price\">");
		for(String rem : remove) html = html.replace(rem, "");
		

		String remove1 = U.getSectionValue(comInfo, "<div class=\"community-per-month-price price-container hide-content\">", "<div class=\"community-starting-price\">");
		if(remove1!=null)comInfo = comInfo.replace(remove1, "");
		
		
		remove1=U.getSectionValue(html, "<div class=\"similar-communities\" data-name=\"\">","<script type=\"text/javascript\">");
		if(remove1!=null) html=html.replace(remove1, "");
		
		//-------------notes-----------

		html = html.replaceAll("Now Open for Pre-Sales!!  Be among|Pre-Sales are now officially", "");

		String notes=U.getnote(html.replace("Now Preselling By Appointment", "")); //replace("Pre-Sales will begin in December 2021", "Pre Sale December 2021")
	
		//------------------------adress-----------------//
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		//U.log(comInfo);
		String addSec=U.getSectionValue(html, "<p class=\"community-page-address\">", "</p>");
		U.log("addSec:::::"+addSec);
		addSec=addSec.replaceAll("\\s*,<br />\n\\s*2301 Knob Creek Rd<br />\\s*", "2301 Knob Creek Rd, ")
				.replaceAll("<br />\n" + 
				"                        Sultan, WA 98294", "<br /> Sultan, WA 98294")
				.replace("Visit Vista II at ", "")
				.replace("&amp;", "& ").replaceAll("Located in Maricopa AZ|Located on Southside Rd", "")
				.replace("Killion Road SE, Iverson Road SE", "Killion Road SE")
				.replace("124th St SE &amp; Rosewood Dr Sultan", "124th St SE &amp; Rosewood Dr, Sultan")
				.replaceAll("Located In Port Charlotte FL,<br />", "")
				.replace("FL,<br />", "");
		U.log("addSec:::::"+addSec);
		
		if(addSec!=null){
			addSec=addSec.replace("Located in Palm Bay", "").replaceAll(",\\s*\\#\\w<br>|, Suite 210<br>|, Homesite 189<br>", ",").replace("Sales Center East located at: 19234 Coliseum Ln Sales Center West located at:", "")
					.replace("(home site 299)", "").replace("Way, #C", "Way #C")
					.replaceAll(",<br />|, <br>", ",").replace("<br>", ",").trim().replaceAll(", #102|, #1|,  #A|,  Suite 210", "").replace(", Suite 103", " Suite 103").replaceAll(",\\s+,|,,", ",")
					.replaceAll("Los Altos Model Home Address", "")
					.replace("124th St SE &  Rosewood Dr Sultan,", "124th St SE &  Rosewood Dr, Sultan,");
			
			String[] tempAdd =addSec.split(",");
			U.log(tempAdd.length+"-------------------------->"+Arrays.toString(tempAdd));
			if(tempAdd.length==3){
				add[0]=tempAdd[0].trim();
				add[1]=tempAdd[1].trim();
				add[3]=Util.match(tempAdd[2], "\\d+");
				if(add[3]==null)add[3]=ALLOW_BLANK;
				U.log(add[3]+":::::::zip");
				add[2]=tempAdd[2].replace(add[3], "").trim();
				//add[2]=Util.match(tempAdd[2], "\\w+(\\s*\\w*)");
				U.log(add[2]+":::::::state");
				if(add[2].length()>2){
					add[2] =USStates.abbr(add[2]);
				}
				add[0]=add[0].replaceAll("&amp; ", "& ");
			}
			add[0]=add[0].replace("8318 County Rd 46 &#189;","8318 County Rd 46");
					
		}

		add[0]=add[0].replace("Located In Port Charlotte", "");
		
		U.log("Address is "+Arrays.toString(add));
		add[0]=add[0].replace("Located In Port Charlotte FL","Port Charlotte Fl");
		add[0]=add[0].replace("SW Bayshore Blvd and SW Port St Lucie Blvd", "SW Bayshore Blvd");
			
		//----------------------latlong------------------//
		
		String geo = ALLOW_BLANK;
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String[] latLong ={ALLOW_BLANK,ALLOW_BLANK};
		geo="FALSE";

		
		
		if(html.contains("Get Directions") && !comUrl.contains("doraville/carver-hills")){
			String dirUrl=comUrl+"/driving-directions";
			String dirHtml=U.getPageSource(dirUrl);
			String LatLngSec=U.getSectionValue(dirHtml, "Current+Location/", "\"");
			U.log(LatLngSec);
			if(LatLngSec!=null){
				if(!LatLngSec.equals(","))latLong=LatLngSec.split(",");
			}
		}
		U.log(latLong[0]+ "::::::::::"+latLong[1]);
		
		/**
		 * @date 15 Jan 2022
		 * @author Sawan Meshram
		 * 	Lat-Lng on community page are location on ocean, so I have taken address on 'Palm Bay Studio' given at page
		 */
          
		if(comUrl.contains("https://www.centurycommunities.com//find-your-home/florida/central-florida/palm-bay/palm-bay-signature")){
			add[0] = "1155 Malabar Road NE Suite 8";
			add[1] = "Palm Bay";
			add[2] = "FL";
			add[3] = "32907";
			latLong = U.getGoogleLatLngWithKey(add);
			geo="True";
		}
		if(comUrl.contains("https://www.centurycommunities.com//find-your-home/washington/seattle-metro/redmond/rose-hill-west")) {
			add[0]="9717 138th Ave NE";
			add[1]="Kirkland";
			add[2]="WA";
			add[3]="98033";
		}
		//--------------------incorrect wrong street name-----------------------
		add[0]=add[0].replaceAll("Located In |Located In Pontiac MI|Located In Macon GA|Century Communities Los Altos|Located in Katy TX|Located in Salisbury|Located In|Offsite Sales Office|Coming soon!|Contact for Appointment|By Appointment Only", ALLOW_BLANK);
		add[0] =  add[0].replace("Model Home Coming Soon ", "")
				.replace("Currently selling from ", "");
		
		
		//-----------------------Address from latlng----------------------
		if((add[2].length()<2 || add[0].length()<4 || add[3].length()<4) && latLong[0].length()>4){
			String add1[] = U.getAddressGoogleApi(latLong);
			if(add1 == null) add1 = U.getAddressHereApi(latLong);
			
			if(add[0].length()>4){
		
				/*if(add[3].length()<4)add[3] = U.getAddressGoogleApi(latLong)[3];
				if(add[2].length()<2)add[2] = U.getAddressGoogleApi(latLong)[2];*/
				if(add[3].length()<4) add[3] = add1[3];
				if(add[2].length()<2) add[2] = add1[3];
			}
			else{
				add = add1;
			}
			geo="TRUE";
		}
		
		
		
		//----------Address and latlng Using City And State----------
		if(add[1].length()<3 && add[3].length()<4 && latLong[0].length()<4){
		
			String cityState=U.getSectionValue(html, "<div class=\"comunity-description\">                  \n" + 
					"                        <h2>", "</h2> ");
			if (cityState==null||cityState.trim().length()==1) {
				cityState=U.getSectionValue(comInfo, "<div class=\"dl-home-content-location\">", "</div>");
			}
			
			if(comUrl.contains("https://www.centurycommunities.com/find-your-home/south-carolina/north-myrtle-beach-metro/georgetown/mcdonald-village")) {
				add[1]="Georgetown";
				add[2]="SC";
				add[3]="29440";
				latLong=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latLong);
				geo="True";
				
			}
			if(comUrl.contains("https://www.centurycommunities.com/find-your-home/washington/seattle-metro/redmond/rose-hill-west")) {
				add[0]="9717 138th Ave NE";
				add[1]="Kirkland";
				add[2]="WA";
				add[3]="98033";//bcz extra add ius given
			}
			if(comUrl.contains("https://www.centurycommunities.com/find-your-home/south-carolina/north-myrtle-beach-metro/georgetown/mcdonald-village")) {
				add[1]="Georgetown";
				add[2]="SC";
				add[3]="29440";
				latLong=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latLong);
				geo="True";
			}
			else {
			U.log("----------City and State is-------------"+cityState);
			if(cityState!=null){
				U.log(cityState);
				cityState=cityState.replaceAll("<label>|</label>|<h4>|</h4>|\\d+", "");
				String[] CS =cityState.split(",");
				add[1]=CS[0].trim();
				add[2]=CS[1].trim();
				if(add[2].length()>2){
						add[2]=USStates.abbr(add[2]);
				}
			}
			}
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			
			notes="Address & Lat-Long Taken Using City & State";
			geo="TRUE";
		}
		
		///////////latlong section
		String latsec=U.getSectionValue(html, "<img src=\"https://maps.googleapis.com/maps/api/staticmap?", "zoom");
		U.log("latsec ::"+latsec);
		latsec=latsec.replace(".&amp;", "&amp;");
		latLong[0]=U.getSectionValue(latsec, "=", ",").replace("%22", "");
		latLong[1]=U.getSectionValue(latsec, ",", "&").replace("%20", "").replace("%22", "");
		
		if(latLong[0].equals(latLong[1])) {
			latLong=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if(add[0].length()<3) {
			add=U.getAddressGoogleApi(latLong);
			geo="TRUE";
		}
        
		
		
		//----------latLng from address------------
		if(latLong[0].length()<5){
			if(comUrl.contains("https://www.centurycommunities.com/find-your-home/utah/salt-lake-city-metro/springville/ashton-springs")) {
				add[0]="600 W & 800 S";
				add[1]="Springville";
				add[2]="UT";
				add[3]="84663";
				latLong[0]="40.159037";
				latLong[1]="-111.625711";
		}

			else {
				
		//	latLong = U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getGoogleLatLngWithKey(add);
			if(latLong == null)  latLong = U.getlatlongHereApi(add);
			geo ="TRUE";
			}
		}
		
		
		add[0]  = add[0].replace("Sales Center located at: 13130 Chamberlain Ave Sales Center West located at: ", "");
		
		
		if(add[0]==null || add[0].length()<3 && latLong[0].length()>3) {
			add = U.getAddressGoogleApi(latLong);
			if(add == null)add = U.getGoogleAddressWithKey(latLong);
			geo = "TRUE";
		}
		latLong[0]=latLong[0].replace("%20", "");
		latLong[1]=latLong[1].replace("%20", "");
		
     
				
		//=========fetch homes data
		String allHomesData=ALLOW_BLANK;
		
		String homeUrlSec = U.getSectionValue(html, "<div class=\"floor-plan-container", "data-name=\"area-amenities\">");
		
		if(homeUrlSec==null)
			homeUrlSec = U.getSectionValue(html, "<div class=\"floor-plan-container", "data-name=\"homesite-map\">");
		if(homeUrlSec==null)
			homeUrlSec= U.getSectionValue(html, "<div class=\"right-section floor-plan-card-container", "<script type=\"text/javascript\">");
		if(homeUrlSec==null)
			homeUrlSec = "";
		
	
		String[] homeUrls = U.getValues(homeUrlSec, "<a class=\"btn button-link button-2\" href=\"", "\"");
		
		U.log("total Homes ::::::::: "+homeUrls.length);
		int y=0;
		for(String homeUrl : homeUrls){
			homeUrl="https://www.centurycommunities.com"+homeUrl;
//			U.log("homeUrl::::"+homeUrl);
			try {
			String homeHtml= U.getPageSource(homeUrl);
//			if(homeHtml.contains("<small>floor</small>"))
//			{
//				U.log("found");
//			}
			allHomesData=U.getSectionValue(homeHtml, "div class=\"text_block_contain\" data-name=\"overview\">", "<div class=\"communities-block\" data-name=\"community-information\">")+allHomesData+U.getSectionValue(homeHtml, "<div class=\"product_detail_contain", "    <div data-name=\"elevations\" class=\"elevations_contain\">");
			y++;
//			if(y==10){
//				break;
//			}
			}catch(Exception e) {}
		}
		//U.log(allHomesData);
		//------Amenitie Data------------
		String amenitiesData = U.getSectionValue(html, "data-name=\"area-amenities\">", "</div><div>");
		
		//U.log(amenitiesData);
		//==============
		
		// ---------community type,property type,property status,derived,
				// property type---------//
				String commType = U.getCommunityType((html+amenitiesData).replaceAll("55\\+ Community in Dacula GA|Long Lake community|Lakeside community park|Exposed Aggregate|Elongated", ""));
//				U.log(Util.matchAll(html, "[\\w\\s\\W]{100}age quali[\\w\\s\\W]{100}", 0));

				//-----------property type---------
				allHomesData=allHomesData.replaceAll("Loft in Lieu|Options: Loft| Loft \\| Owner's suite", " Loft Home")
						.replaceAll("bonus room or apartment", "");
				html = html.replace("luxury finish", "luxury homes").replace("detached, single family condominium", "detached homes , single family condominium")
						.replace("singles, small young families", "single family")
						.replaceAll("plex-a-th|plex-b-th-", "");
				allHomesData =allHomesData.replace("Duplex Craftsman", "<strong>Duplexes");
				String propType = U.getPropType((html+allHomesData+comInfo).replace("multi-gen layouts and expansive garages", "multi-generation living layouts and expansive garages")
						.replace("features a luxurious lineup", "features a luxuries lineup")
						.replace("luxury resort", "luxury home")
						.replaceAll("/building-\\d+-plex|creek-6-plex|traditional-plans-and-cottages|alt=\" - traditional plans and cottages - plan|HOA assessments are additional and not included in the above payment", ""));
				//U.log(html);
//				U.log("MMMMMMMM "+Util.matchAll( html   ,"[\\s\\w\\W]{30}4 plex[\\s\\w\\W]{30}", 0));
//				U.log("MMMMMMMM "+Util.matchAll( allHomesData   ,"[\\s\\w\\W]{30}4 plex[\\s\\w\\W]{30}", 0));
//				U.log("MMMMMMMM "+Util.matchAll( comInfo   ,"[\\s\\w\\W]{30}4 plex[\\s\\w\\W]{30}", 0));

				//============dericved Type=========
				html=html.replace(U.getSectionValue(html, "<head>", "</head>"), "");
				html = html.replace("3 floor plans", "3 Story plans")
						.replace("variety of rambler ", "variety of rambler style ")
						.replace("two -story homes", "two-story homes").replaceAll("RANCHO |Rancho|1890 Ranch shopping| at Star Ranch|2-story and ranch-style homes for sale |floor", "").replace("main level or second level", " one story or second level");
				allHomesData=allHomesData.replaceAll(" 1\n" + 
						"                                        \n" + 
						"                    <small>\n" + 
						"                      floor\n" + 
						"                    </small>", " 1-story").replaceAll("\\s*<small>\\s*floors\\s*</small>", " story").replace("floor", "");
				String dpType = U.getdCommType((html+allHomesData+amenitiesData).replaceAll(" 3-bedroom | 4-bedroom| at Star Ranch", ""));
				
//				U.log("MMMMMMMM "+Util.matchAll( html+allHomesData+amenitiesData   ,"[\\s\\w\\W]{30}6 plex[\\s\\w\\W]{30}", 0));


				//---------------------Status-----------------------------
				String rem = U.getSectionValue(html, "<table id=\"salesHours\">", "</table>");
				if(rem != null) html = html.replace(rem, "");
				rem = U.getSectionValue(html, "<table id=\"salesHoursMobile\">", "</table>");
				if(rem != null) html = html.replace(rem, "");
				
				html=html.replace("Move-in Ready only","").replace("&nbsp;", " ");
				html=html.replace("move_in_ready=1\">","").replaceAll("New Section and Model Now Open", "New Section Now Open");
				html=html.replaceAll("Model Now Open|Ã¢â‚¬â€�Now Open!</em>|2-story and ranch-style homes for sale|GRAND OPENING MARCH 16TH|Crystal Springs is now open in Leander| Homes will vary in sizes from 1,200 sq. ft. to 3,800 sq. ft|New Section\\s*Coming Soon\\s*Leander|New Section Coming Soon in Leander|data-text=\"Move-In Ready\">move-in ready</span>|\">Move-In Ready","")
						.replace("Move-In Ready","");
				html=html.replaceAll("<span class=\"price\">\n\\s+Coming soon|<span class=\"price\">\n\\s*Coming soon|<p><strong>Coming Soon:</strong></p>|coming soon to Palm|Move-in ready homes now available|New & Move-In Ready Homes for|move-in ready homes today|move-in ready</|=\"Move-In Ready\"|<title>Move in Ready Homes|content=\"Move in Ready Homes|<title>Move-in Ready Homes|content=\"Move-in Ready Homes|Move-in Ready Homes for Sale|Move-in Ready homes available|Move-in Ready only","")
						.replace("move_in_ready","").replace("move_in_ready","");
				html = html.replaceAll("-  Sold out\n\\s+</p>|<strong>Coming Soon:</strong></p>|its new releases, and community progress|#4a104a;\">\n\\s+Temporarily Sold Out|about Grand Opening updates|Floor Plans Available|out\"|#bd\\d+;\">\n\\s*SOLD|Brighton - SOLD|grand opening of our( | decorated )model|Last Model Home Now Selling|and is now selling! Stop |Collection is Coming Soon|Move-In Ready|Move-in Ready only|sold-out this summer|Now open,&nbsp;an inviting|<p>Opening Summer 2019</p>|Coming Spring&nbsp;2019<|<div class=\"text \"><p>Coming Spring 2019</p>|alt=\".*\"|New Homes &amp; Move-in Ready Homes at |Now selling!&nbsp;Contact|-be-built and move-in read|Savings on move-in read|now available in the northwest|Coming in 2018, Sign up|information coming soon|\"Now selling|Coming soon,|Phase 3 Information Coming Soon|Currently selling from|Sales Office Opening Soon|Hours:</h4>\\s+<p>Coming |Opening events|Hours:</h4>\\s+<p>COMING|(s|S)ale-(c|C)oming|<span data-text=\"Coming|capitalize;\">coming|ready homes Coming|distance \\(coming|flag-dark-purple\">\\s+Coming ", "")
						.replaceAll("Soon:</strong><br />Green|flag-light-purple\">\\s+(Last|Now)", "");
				comInfo = comInfo.replaceAll("#4a104a;\">\n\\s+Temporarily Sold Out|Floor Plans Available", "");
				//
				html = html.replace("Phase 3 will be coming this spring", "Phase 3 coming this spring");
				//U.log("::::::::::" + Util.match(html, ".*?Now open.*"));

				String commStatus = ALLOW_BLANK;
				String comDesc1="";
				if(galleryflagStatu!=null)
				{
					galleryflagStatu=galleryflagStatu
							.replaceAll("\n\\s*</span>\n\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\n\\s*|\\s*</span>\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\\s*", " ");

					galleryflagStatu = galleryflagStatu.replaceAll("Limited Release\\s*</span>\\s*Inventory Available\\s*</span>", "Limited Release Inventory Available");
				//	U.log(galleryflagStatu);
					
					galleryflagStatu = galleryflagStatu.replaceAll("FUTURE RELEASE COMING Summer 2022", "Future Release Coming Summer 2022");
				}
				
				
				comInfo = comInfo.replaceAll("<div class=\"quick-special-offer-icon\">\n\\s*<span class=\"flags_icon custom-flag1-icon flag-dark-purple\">\n\\s*New Phase Coming", "");
				
				
				comDesc1=U.getSectionValue(html, "overview-description", "</div>")+U.getSectionValue(html, "<div class=\"gallery_flags\">", "</div>")
					+ U.getSectionValue(html, "<div class=\"community-price_", "</div>");
				
				comDesc1=comDesc1.replace(" more—plus future amenities within the Eastwood section coming soon","");
				
				if(comDesc1!=null)comDesc1 =comDesc1.replaceAll(" New Phase Coming\\s*</span>\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\\s*Winter 2021", "New Phase Coming Winter 2021");
				comDesc1=comDesc1.replace("more—plus future amenities within the Eastwood section coming soon!", "");

				comInfo=comInfo.replace("Community is Sold Out", "");
				
				
//				U.log(comInfo+comDesc1+galleryflagStatu);
				if(comInfo!=null ) {
				comInfo=comInfo
						.replaceAll("\n\\s*</span>\n\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\n\\s*|\\s*</span>\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\\s*", " ");
				comInfo = comInfo.replaceAll("FUTURE RELEASE COMING Summer 2022", "Future Release Coming Summer 2022");

				}
				
				if(comDesc1!=null ) {
				comDesc1=comDesc1
						.replaceAll("\n\\s*</span>\n\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\n\\s*|\\s*</span>\\s*<span class=\"gallery_flags_icon custom-flag2-icon flag-light-purple\">\\s*", " ");
				comDesc1 = comDesc1.replaceAll("FUTURE RELEASE COMING Summer 2022", "Future Release Coming Summer 2022");

				}
				
				
				commStatus = U.getPropStatus((comDesc1+galleryflagStatu+comInfo)
						.replace("flag1-icon flag-light-purple\">\n                            Sold Out", "")
						.replaceAll("Inheritance Estates offers limited opportunities with 3-4 bedroom|future amenities within the Eastwood section coming soon", "")
//						.replace("New Section Coming Soon - Summer of 2022", "New Section Coming Summer 2022")
						.replace("FUTURE RELEASE COMING Summer 2022", "Future Release Coming Summer 2022")
						.replaceAll("Heights </strong><strong>Coming Spring 2022|coming late 2021|[m|M]ove-[i|I]n|Coming Soon! Rockwell Meadows|\"Coming|New Phase Coming Soon!! Call to Join|<div class=\"quick-special-offer-icon\">\n\\s*<span class=\"flags_icon custom-flag1-icon flag-dark-purple\">\n\\s*New Phase Coming", "")
						.replace("New Phase!! Now Selling", "New Phase Now Selling")
						
						.replace("Coming in Summer, 2021", "Coming Summer 2021").replace("0 Move-in Ready", ""));
//class=\"price\">\\s*Coming soon\\s*<

				U.log("commStatus=="+commStatus);
				U.log("Match===="+Util.matchAll(comDesc1+galleryflagStatu+comInfo, "[\\w\\s\\W]{100}sold out[\\w\\s\\W]{200}", 0));
//				U.log("Match===="+Util.matchAll(comDesc1, "[\\w\\s\\W]{100}future release coming[\\w\\s\\W]{200}", 0));
//				U.log("Match===="+Util.matchAll(galleryflagStatu, "[\\w\\s\\W]{100}future release coming[\\w\\s\\W]{100}", 0));
//				U.log("Match===="+Util.matchAll(comInfo+comDesc1+galleryflagStatu, "[\\w\\s\\W]{100}New Section Coming Soon[\\w\\s\\W]{100}", 0));

				
				if(commStatus!=null) {
					commStatus=commStatus.replace("Currently Sold Out, Sold Out", "Currently Sold Out");
				}
				commStatus=commStatus.replaceAll("Quick Move-in Homes,|Quick Move-in( Homes)?|Quick Move-in( Homes)?","");
				

				String quickData =Util.match(html, "<div class=\"quick-icon flag-dark-purple\">\\s*Quick Move-In\\s*</div>", 0);
				if(quickData==null)quickData="";
				if(!commStatus.contains("Move-in") && html.contains("<div class=\"quick-move-in-container") && !html.contains("ALREADY TAKEN") && quickData!=""){
					if(commStatus.length()<3){
						commStatus="Quick Move-In Homes";
					}
					else{
						commStatus=commStatus+", Quick Move-In Homes";
					}
				}
				if(commStatus.contains("Coming Soon Spring 2022")&&commStatus.contains("Coming Soon")) {
					commStatus=commStatus.replaceAll(", Coming Soon|Coming Soon, ","");
				}

//					
					// --prices---//

				String remSec="";
				String psec="";
				remSec=U.getSectionValue(html, "<div class=\"similar-communities\" data-name=\"\">", "Homeowner reviews");
				if(remSec!=null) {
				html=html.replace(remSec, "");
				psec=psec.replace(remSec,"");
						
				}
				String pricesec[]=U.getValues(html, "<h3 class=\"price\">", "</h3>");
				//String psec="";
				for(String pri:pricesec) {
					if(commStatus.contains("Sold")) {
						psec="";
					}
					else {
					psec+=","+pri.trim();
					}
				}
				
				String pSec1[]=U.getValues(html, "<span class=\"price\">", "</span>");
				String pval="";
				for(String s:pSec1) {
					pval+=","+s;
				}
			//	U.log("===="+psec+"======"+pval);
				//String RemPriceSec[]=U.getValues(code, From, To)
				psec=(psec+U.getSectionValue(html, "<div class=\"overview-description full\">", "</div>")).replaceAll("&rsquo;s|&#39;s", ",000") ;
				pval=pval + U.getSectionValue(html, "<div class=\"community-price_contain price_contains\">", "</div>").replace("&#39;s", ",000");
		
				html=html.replaceAll("square feet of finished living space|loan in the amount of \\$249,925|\\$180,340 with an interest rate|\\$307,825 with an interest", "").replace("mid&nbsp;$200s", " mid $200,000");
				html=html.replace("$170's.", "$170,000").replace("z-index:99999", "").replaceAll("0k|0â€™s|&rsquo;s|0's|0s", "0,000").replace("low $180's.", "low $180,000").replaceAll("00s|00's|00â€™s|00&rsquo;s", "00,000").replace("Ã¢â‚¬â€œ", "-");
				comInfo=comInfo.replaceAll("241,250|350,285", "").replace("&#39;s", ",000");
				psec=psec.replace("0's", "0,000");
				pval=pval.replace("0s","0,000");
				//String priceSection=U.getNoHtml(comInfo+psec+pval);

				String[] price = U.getPrices(psec+pval.replaceAll("oan in the amount of \\$\\d+,\\d+|sales price of \\$209,990|sales price of \\$\\d+,\\d+|amount of \\$\\d+,\\d+ with|\\$193,990\\s*</h3>", ""),
						"Coming Soon from the Low \\$\\d{3},\\d{3}|from the Low \\$\\d{3},\\d{3}|from the mid \\$\\d{3},\\d{3}|Mid \\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|,\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|<span class=\"price\">\\s*\\$\\d,\\d{3},\\d{3}\\s*</span>|<h3 class=\"price\">\n\\s+\\$\\d,\\d{3},\\d{3}|<h3 class=\"price\">\n\\s+\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}", 0);
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
				
				if(comUrl.contains("https://www.centurycommunities.com//find-your-home/texas/austin-metro/leander/crystal-springs/crystal-springs-the-lakes")) {
					minPrice = ALLOW_BLANK;
				   maxPrice = ALLOW_BLANK;
				}


				// -----------sqreft-----------//
				comInfo = comInfo.replaceAll("Sq Ft\\s*</span>\\s*<span class=\"dl-home-content-model-box-dim\">\\s*", "sq ft ");
//				U.log(comInfo);
				
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;//.replace("&nbsp;", "")
				String sqftsec[]=U.getValues(html, "data-sqft=\"", "\"");
				ArrayList<String> homeSqs =Util.matchAll(html, "\\d{4} - \\d{4} <small>\\s*sq ft", 0);
				String sqfsec="";
				for(String s:sqftsec) {
					sqfsec+=","+s+ " sq ft";
				}
				for(String s:homeSqs) {
					sqfsec+=","+s+" sq ft";
				}
//				U.log("sqfsec==="+sqfsec);
//				U.log("overviewSec==="+overviewSec);
				
				String[] sqft = U.getSqareFeet((sqfsec+overviewSec), 
						"range from \\d,\\d{3} sq ft to \\d,\\d{3} sqft|\\d,\\d{3} sq ft|\\d,\\d{3} sq ft to \\d,\\d{3} sqft| \\d,\\d{3}&ndash;\\d,\\d{3}(\\s|&nbsp;)square feet of finished living|ranging from \\d,\\d{3}(\\s|&nbsp;)to over \\d,\\d{3} sq. ft. |plans from \\d,\\d{3}sq ft to \\d,\\d{3}sq ft|up to \\d,\\d{3} sq\\. ft\\.|\\d{4} - \\d{4} <small>\\s*sq ft|ranging from \\d{3} sqft to \\d,\\d{3} sqft|\\d{4} sq\\. ft\\. to \\d{4} sq\\. ft|\\d{4} - \\d{4} sqft|\\d{4} to \\d{4} sqft|\\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} square feet|\\d{4} <small>\\s*sq ft</small>| from \\d,\\d{3} to over \\d,\\d{3} sq. ft|from \\d,\\d{3} to \\d,\\d{3} SF|from \\d,\\d{3} â€“ \\d,\\d{4} square feet|from \\d,\\d{3} &ndash; \\d,\\d{3}|from \\d{4} to \\d{4} feet|\\d,\\d{3} -\\d,\\d{3} sq. ft|\\d{4} <small>sq ft.|\\d,\\d{3} to \\d,\\d{3} square feet|\\d{3} to \\d,\\d{3} square feet|up to \\d,\\d{3} sq. ft.|\\d{4} sq ft", 0);

//				U.log(Util.matchAll(sqfsec+overviewSec, "[\\w\\s\\W]{100}2,621[\\w\\s\\W]{100}", 0));
//				U.log(Util.matchAll(sqfsec+overviewSec, "[\\w\\s\\W]{100}2621[\\w\\s\\W]{100}", 0));


				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

				if(comUrl.contains("https://www.centurycommunities.com//find-your-home/texas/austin-metro/leander/crystal-springs/crystal-springs-the-lakes")) {
					minSqf=ALLOW_BLANK;
							}
				
				// ---notes-----//


				//========comNAme====
				communityName=communityName.trim();
				U.log(communityName.trim()+":::::::::::::::::::::::");
				communityName = communityName.replace("- Active Adult - From the Low $200s", "").replace(" - Condos", "");
				if(communityName.endsWith(" - Townhome Collection")||communityName.endsWith(" - Townhomes") || communityName.endsWith("Townhomes")){
					communityName=communityName.replaceAll(" - Townhome Collection| - Townhomes|Townhomes", "");
				}
				if(communityName.endsWith(" - Single Family Collection") || communityName.endsWith(" - Single Family") || communityName.endsWith("- Single Family Homes")){
					communityName=communityName.replaceAll(" - Single Family Collection| - Single Family Homes|- Single Family", "");
				}
				if(communityName.endsWith(" - The Cottages")){
					communityName=communityName.replace(" - The Cottages", "");
				}
				if(communityName.endsWith(" - Active Adult")){
					communityName=communityName.replace(" - Active Adult", "");
				}
				if(communityName.endsWith(" | A 55+ Community")) {
					communityName=communityName.replace("| A 55+ Community", "");
				}
				if(commStatus.contains("Move-in Ready Homes,"))commStatus=commStatus.replace("Move-in Ready Homes,", "");
				
				commStatus = commStatus.replace("New Phase Coming, New Phase Coming 2021, Coming 2021", "New Phase Coming 2021");
				if(comUrl.contains("https://www.centurycommunities.com/find-your-home/texas/san-antonio-metro/new-braunfels/hidden-springs")) {
					
					add[1]="New Braunfels";
					add[2]="TX";
					add[3]="78130";
					latLong[0]="29.704873";
					latLong[1]="-98.068497";
					//latLong=U.getlatlongGoogleApi(add);
					add=U.getAddressGoogleApi(latLong);
					geo="TRUE";
					
				}
              
				if(propType.contains("Townhouse") && propType.contains("Townhome"))
					propType = propType.replaceAll("Townhouse", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
				
				if(propType.length()<3)
					propType = ALLOW_BLANK;
				
				add[0]= add[0].replace("GPS: ", "");
				add[0]=add[0].toLowerCase();
//				propType = propType.replace("Townhouse, Townhome", "Townhome").replace(", ,", ",").trim().replaceAll("^,|,$", "");
				
//				if(comUrl.equals("https://www.centurycommunities.com/find-your-home/georgia/atlanta-metro/buford/sardis-falls"))commStatus+=", New Phase Coming Soon";
				
				if(commStatus==null || commStatus.length()<3)
					commStatus = ALLOW_BLANK;
				
				commStatus = commStatus.replace(", ,", ",").trim().replaceAll("^,|,$", "");
				if(add[1].contains("Alta Way<br />"))
					{add=U.getAddressGoogleApi(latLong);
					geo="TRUE";
					}
				if(add[3]==ALLOW_BLANK) {
					add=U.getAddressGoogleApi(latLong);
				}
				
				
				if(comUrl.contains("san-antonio-metro/san-antonio/los-altos")) {
					
					add[0]="9907 Tierra Alta Way";
					add[1]="San Antonio";
					add[2]="TX";
					add[3]="78224";
					geo="FALSE";
					
				}
				
				if(comUrl.contains("https://www.centurycommunities.com/find-your-home/florida/central-florida/palm-bay/palm-bay-classic")) {
					latLong[0]="27.952909";
				//	latLong[1]="";
				}
				
				if(comUrl.contains("central-california-metro/kerman/the-crossings-ii"))commStatus="Coming Soon";//frm img
				if(comUrl.contains("florida/central-florida/brooksville/hill-n-dale"))commStatus="Currently Sold Out";//frm img

//				=================================================================================
				String[] lot_data=null;
				String lotCount=ALLOW_BLANK;
				String maplink_Sec=U.getSectionValue(html, "<a class=\"btn button-secondary\" href=\"", "\"");
				U.log("maplink_Sec >>>>>>>>"+maplink_Sec);
				String mapHtml=ALLOW_BLANK;
				if(maplink_Sec!=null) {
				mapHtml=U.getHtml(maplink_Sec, driver);
				if(mapHtml!=null) {
				if(maplink_Sec.contains("SiteMapPreview") || maplink_Sec.contains("SiteOverview")) {
					lotCount=Util.getUnits(mapHtml);
				}
				else if(maplink_Sec.contains("photos/maps") ) {
					String Sec=U.getSectionValue(mapHtml, "<svg version", "</svg>");
					lot_data=U.getValues(Sec, "id=\"lot", ">");
					lotCount= Integer.toString(lot_data.length);
				}
				else {
				lotCount=Util.getUnitsByMatch(mapHtml);
				}
				}
				}
				
//				if(maplink_Sec!=null) {
//					String map_link=U.getSectionValue(maplink_Sec, "href=\"", "\"").replace("&amp;", "&");
//					U.log("map_link >>>>>>>>"+map_link);
//					if(map_link!=null) {
//						String map_Html=U.getHtml(map_link, driver);
//						if(map_Html!=null) {
//							String lot_dataSec=U.getSectionValue(map_Html, "<g id=\"Lots\">", "<g id=\"Street_Names\">");
//							if(lot_dataSec!=null) {
//								 lot_data=U.getValues(lot_dataSec, "tabindex", "</g>");
//								U.log(" lot_data=="+lot_data.length);
//								 lotCount=Integer.toString(lot_data.length);
//								 U.log("lotCount=="+lotCount);
//							}
//							else {
//								U.log("KKKKKKKKKKKKKK");
//								lot_dataSec=U.getSectionValue(map_Html, "<g id=\"Lots\">", "<g id=\"Trees");
//								if(lot_dataSec!=null) {
//								 lot_data=U.getValues(lot_dataSec, "tabindex=\"", "</g>");
//								 U.log(" lot_data=="+lot_data.length);
//								 if(lot_data.length==0) {
//									 if(lot_dataSec.contains("id=\"Lot")) {
//											lot_data=U.getValues(lot_dataSec, "id=\"Lot", ">");
//											U.log(" lot_data-1=="+lot_data.length);
//											if(lot_data.length>1) {
//											 lotCount=Integer.toString(lot_data.length);
//											 U.log("lotCount3=="+lotCount);
//											}
//								 }
//								 }
//								 else {
//									 lotCount=Integer.toString(lot_data.length);
//									 U.log("lotCount1=="+lotCount);
//								 
//								}
//							}
//							}
//							if(lot_dataSec==null) {
//								U.log("MMMMMMMMMMMMMM");
//
//								lot_dataSec=U.getSectionValue(map_Html, "<g id=\"Lots\">", "</g>");
//								if(lot_dataSec!=null) {
//								if(lot_dataSec.contains("id=\"Lot")) {
//								lot_data=U.getValues(lot_dataSec, "id=\"Lot", ">");
//								U.log(" lot_data=="+lot_data.length);
//								if(lot_data.length>1) {
//								 lotCount=Integer.toString(lot_data.length);
//								 U.log("lotCount2=="+lotCount);
//								}
//								}
//								}
//							}
//							 
//							
//						}
//												
//						
//						if(map_link.contains("photos/maps/")) {
//							lot_data=U.getValues(map_Html, "id=\"lot", ">");
//							U.log(" lot_data=="+lot_data.length);
//							if(lot_data.length>1) {
//							 lotCount=Integer.toString(lot_data.length);
//							 U.log("lotCount2=="+lotCount);
//						}
//						}
//					}
//					U.log("lotCount3=="+lotCount.length());
//					
////					if(lotCount==ALLOW_BLANK && !map_link.contains("/SiteMapPreview/")) 
////					{
////						String link=Util.match(map_link, "\\d{5}");
////						if(map_link.contains("https://myscp.ml3ds-iconstage.com/scp/117539") || map_link.contains("https://myscp.ml3ds-iconstage.com/scp/137844")) {
////							link=Util.match(map_link, "\\d{6}");
////						}
////						U.log("========"+link);
////						if(link!=null && (lotCount==null || lotCount==ALLOW_BLANK)) 
////						{
////						String iframe_link_Html=getHTML("https://argo.ml3ds-cloud.com/api/communities/"+link+"?dataLevel=2&filterToActiveOnly=true");
////
////						String[] dd=U.getValues(iframe_link_Html, "{\"MappedFloorPlanIds\"", "\"Tags\":[]");
//////						U.log(" lot_data=="+lot_data.length);
////						if(dd.length>1) {
////							 lotCount=Integer.toString(dd.length);
////							 U.log("lotCount3=="+lotCount);
////						}
////					}
////					}
//
//				}
				
				
				U.log("======lotCount=="+lotCount);
				
				if(lotCount.equals("0")) {
					lotCount=ALLOW_BLANK;
				}
				
				
				
				commStatus=commStatus
						.replace("New Phase, Now Selling New Phase", "Now Selling New Phase")
						.replace("New Phase, New Phase Coming Spring 2022", "New Phase Coming Spring 2022");
			data.addCommunity(communityName.replace("|", "").replaceAll("- Swartz Creek|- Wickenburg|Premier Series|Signature Series", ""), comUrl, commType);
				data.addAddress(add[0].replace("&#39;s", "'s"), add[1].replace("&#39;", "'"), add[2].trim(), add[3]);
				data.addLatitudeLongitude(latLong[0].replace("%", "").trim(), latLong[1].replace("%", "").trim(), geo);
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minSqf, maxSqf);
				data.addPropertyType(propType, dpType);
				data.addPropertyStatus(commStatus.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling").replace("New Section Coming Soon, New Section Coming Soon", "New Section Coming Soon").replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon").replace("Iii", "III").replace("Ii", "II").replace("Iv", "IV"));
				data.addNotes(notes);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				data.addUnitCount(lotCount);
		
	}
		j++;
		
//	}catch (Exception e) {}
	}
	

	
	public  String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName =U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode =U.CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "application/json, text/plain, */*");
//			urlConnection.addRequestProperty("Accept-Language","en-us,en;q=0.5");
			urlConnection.addRequestProperty("Referer", "https://myscp.ml3ds-icon.com/");
			urlConnection.addRequestProperty("x-ml-date", "Wed, 20 Apr 2022 12:21:41 GMT");
			urlConnection.addRequestProperty("Authorization", "converge.apiuser@medialabinc.local BbFockVcW28KhRFvQ4x83ER6i7bks6qM51z9jGre0S8=");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}
