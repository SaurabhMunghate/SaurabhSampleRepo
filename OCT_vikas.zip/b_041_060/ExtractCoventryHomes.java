/**
 * @author Parag Humane 
 * @date 10/3/2012
 * Modification Aditya..
 */
package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;
import org.bouncycastle.crypto.tls.AlertLevel;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import java.net.Proxy;
import java.io.InputStream;
import java.net.InetSocketAddress;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCoventryHomes extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	CommunityLogger LOGGER;
//	String str;
//	String city;
//	String zip;
//	String state;
	public int inr = 0;
	static ArrayList<String> extraComm = new ArrayList<String>();

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCoventryHomes();
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "MHI-McGuyer Homebuilders - Coventry Homes.csv", a.data().printAll());
		U.log(extraComm.size());
		for (int i = 0; i < extraComm.size(); i++) {
			U.log(extraComm.get(i));
		}
	}

	public ExtractCoventryHomes() throws Exception {

		super("MHI-McGuyer Homebuilders - Coventry Homes", "https://www.coventryhomes.com/");
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Coventry Homes");
	}

	public void innerProcess() throws Exception {
		String regsApiUrl="https://app.mhinc.com/api/DBAMetros/?DBACode=cov";
		String regionAPiHTml=getHTML(regsApiUrl);
		String regions[]=U.getValues(regionAPiHTml, "{", "}");
		for (String region : regions) {
			//U.log(region);
			//https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid=h&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=990.99&zipcode=&zipcoderadius=&amenities=&projectid=
			String metroid=U.getSectionValue(region, "\"metroid\":\"", "\"");
			String metroUrl=U.getSectionValue(region, "\"metroseourlname\":\"", "\"").toLowerCase()+"/";
			String commDataAPI=getHTML("https://app.mhinc.com/api/MetroMapBySections/?DBACode=cov&metroid="+metroid.toLowerCase()+"&metrosection=&city=&schooldistrict=&MinPrice=0&MaxPrice=990.99&zipcode=&zipcoderadius=&amenities=&projectid=");
//			U.log(commDataAPI);
			String commDataSecs[]=U.getValues(commDataAPI, "\"rowindex\":", ",\"Waitlist\":\"");
//			U.log(commDataSecs.length);
			for (String comData : commDataSecs) {
//					U.log(comData);
				
					String subComms[]=U.getValues(comData, "{\"ProjectId\"", "\"PriceSeriesSeoUrlName\"");
					for (String subComm : subComms) {
						//U.log("subComm here: "+subComm);
						String seoTracker=U.getSectionValue(subComm, "\"CommunitySeoUrlName\":\"", "\"");
						String comUrl="https://www.coventryhomes.com/"+metroUrl+seoTracker;
						//U.log(comUrl);
						String comAPIURL="https://app.mhinc.com/api/CommunityDetails?DBACode=cov&metroid="+metroid.toLowerCase()+"&CommunitySeoUrlName="+seoTracker;
//						try {
							addDetails(comUrl, subComm,comAPIURL, comData);
//						}catch (Exception e) {}
					//	break;
					}
				
			//	break;
			}
			//break;
		}
		LOGGER.DisposeLogger();
		//U.log(regionAPiHTml);
	}
	private void addDetails(String comUrl, String subComm, String comAPIURL, String comData) throws Exception {
		// TODO Auto-generated method stub

//-------------Single Run
//		if(!comUrl.equals("https://www.coventryhomes.com/austin/new-homes-kyle-tx-6-creeks-55ft")) return;
		
//		if(i<=50) 
		
		{
		
		
//		U.log("subComm here: "+subComm);
		
		if(comAPIURL.contains("https://app.mhinc.com/api/CommunityDetails?DBACode=cov&metroid=h&CommunitySeoUrlName=merion-at-midtown-park"))return;
		U.log("comAPIURL: "+comAPIURL);
		String comHtmlAPI=getHTML(comAPIURL);

		String comHtmlAPI1 = comHtmlAPI;
		
		U.log("====="+comHtmlAPI);
		if(comHtmlAPI.contains("Projects\":[{\"rowindex"))
		comHtmlAPI = U.getSectionValue(comHtmlAPI, "{\"", "Projects\":[{\"rowindex");
		
		U.log("====="+comHtmlAPI);
		U.log(subComm+"\n"+comUrl);

		
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"==========repeated");
			return;
			
		}
		if (comUrl.contains("https://www.coventryhomes.com/dallas-ft-worth/dominionofpleasantvalley-50ft-homesites-garlandisd")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-50ft-homesites")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-60ft-homesites")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-50ft-homesites")
				|| comUrl.contains("https://www.coventryhomes.com/austin/parksideontheriver-60ft-homesites")
				||comUrl.contains("https://www.coventryhomes.com/dallas-ft-worth/sandbrockranch")
				||comUrl.contains("https://www.coventryhomes.com/austin/the-estates-at-flintrock")) {
			LOGGER.AddCommunityUrl(comUrl + "==========Return");
			return;

		}
		LOGGER.AddCommunityUrl(comUrl);
		String comName=U.getSectionValue(comHtmlAPI, "\"SubdivisionName\":\"", "\"");
		String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";

		add[0]=U.getSectionValue(comHtmlAPI, "\"Address\":\"", "\"");
		if(add[0].contains("<br>"))add[0]=add[0].replace("<br>", "");
		if(add[0].contains("Coming Soon"))add[0]=add[0].replace("Coming Soon", "");
		//if(add[0].contains("By Appointment Only"))add[0]=add[0].replace("By Appointment Only", "");
		
		
		add[1]=U.getSectionValue(comHtmlAPI, "\"City\":\"", "\"");
		add[2]=U.getSectionValue(comHtmlAPI, "\"State\":\"", "\"");
		add[3]=U.getSectionValue(comHtmlAPI, "\"Zip\":\"", "\"");
		
		if(add[0]!=null)
		add[0]=add[0].replace("\\t", "")
		.replace("BY APPOINTMENT ONLY", "")
		.replaceAll("Visit us at our 65’ model:  |Visit us at our 60’ model:  |Visit us in Harvest Green:  ", "")
					 .replace("2500 Forest Creek Drive, #2502", "2500 Forest Creek Drive")
					 .replaceAll("By Appointment Only |By Appointment Only|Please Visit Us at Coastal Point:|Visit us in Hidden Lakes: <br>|Visit us in Harvest Green: <br> |We're available to meet you at any of our area model homes\\.", "");
		String latLng[]=new String[] {ALLOW_BLANK,ALLOW_BLANK};
		
		U.log("ADDRESS: "+Arrays.toString(add));
		
//		U.log("mmmmmm"+Util.matchAll(comHtmlAPI, "[\\w\\s\\W]{30}29.7851890000[\\w\\s\\W]{30}", 0));
		latLng[0]=U.getSectionValue(comHtmlAPI, "\"Latitude\":\"", "\"");
		latLng[1]=U.getSectionValue(comHtmlAPI, "\"Longitude\":\"", "\"");
		U.log(Arrays.toString(latLng));
		
		if(add[0].length()==0) {
			add=U.getAddressGoogleApi(latLng);
			geo="TRUE";
		}
		
//		geo="TRUE";
		
		String descSec=U.getSectionValue(comHtmlAPI, "\"Description\":\"", "\",")+U.getSectionValue(comHtmlAPI, "\"PriceRangeMin\":\"", "\"");
//		U.log("descSec: "+descSec);
		String amenitiesSec=U.getSectionValue(comHtmlAPI, "\"Amenities\":[{", "],");
//		U.log(amenitiesSec);
		
		String availData="";
		String floorData="";
		try {
		String avaiSecs=U.getSectionValue(comHtmlAPI, "\"HomeItems\":[", "]");
		String availHomes[]=U.getValues(avaiSecs, "{\"JobId\":", "\"Scale\":null");
		for (String availHome : availHomes) {
			U.log("availHome::");
			availData+=availHome;
		}
		
		String floorPlanSecs=U.getSectionValue(comHtmlAPI, "\"Plans\":[{", "]");
		String floorPlans[]=U.getValues(floorPlanSecs,"{\"ProjectId\":", "\"PortfolioItemId\":null");
	
		for (String floorHome : floorPlans) {
			U.log("floorHome::");
		floorData+=floorHome;
		}
		}
		catch(NullPointerException ne) {
			
		}
//		U.log("&&&&&&&&&&&&&&"+Util.matchAll(comHtmlAPI+floorData+amenitiesSec+descSec+availData,"[\\w\\s\\W]{50}$470[\\w\\s\\W]{20}",0));

		comHtmlAPI=comHtmlAPI.replace("0's", "0,000").replace("0s", "0,000");
		
	//	U.log("&&&&&&&&&&&&&&"+Util.matchAll(comHtmlAPI+floorData+amenitiesSec+descSec+availData,"[\\w\\s\\W]{50}400[\\w\\s\\W]{50}",0));
		String prices[]=U.getPrices((comHtmlAPI+floorData+amenitiesSec+descSec+availData).replaceAll("FullPrice\":\"\\d+\",\"IsDiscounted\":\"1\"", ""), "From the \\d{3},\\d{3}|Upper \\d+,\\d+|SuggestedPrice\":\"\\d+|\\$\\d{3},\\d{3}|FullPrice\":\"\\d+\"|\"PriceRangeMin\":\"From the \\$\\d{3},\\d{3}|\"BasePrice\":\"\\d{6}\"", 0);
		U.log("PRICES: "+Arrays.toString(prices));
		
		
		String sqft[]=U.getSqareFeet(floorData+amenitiesSec+descSec+availData, "\\d,\\d{3} - \\d,\\d{3} sq. ft.|\"SqFt\":\"\\d{4}\"", 0);
		U.log("SQFT: "+Arrays.toString(sqft));
	
		String cType=ALLOW_BLANK;
		String descShortSec="";
		
		descShortSec=U.getSectionValue(comHtmlAPI, "\"DescriptionShort\":\"", "\"")
				+U.getSectionValue(comHtmlAPI, "\"PriceRangeMin\":\"", "\"");
		U.log(descShortSec);
		
		
		cType=U.getCommType((descSec+amenitiesSec+descShortSec)
				.replace("community of Lakeside", "Lakeside community")
				.replace("beautiful waterfront","Waterfront Community"));
		
//		U.log(">>>>>>>>>>>>>>>>>>"+Util.matchAll(descSec+amenitiesSec+descShortSec,"[\\w\\s\\W]{50}lakeside[\\w\\s\\W]{50}",0));
		
		String pType=ALLOW_BLANK;
		String[] imgSliderTxt = U.getValues(comHtmlAPI, "\"AltText\":\"", "\"");
		for(String img : imgSliderTxt)
			descSec+=img;
		if(comHtmlAPI.contains("\"HOA\":\""))
			descSec+=" HOA ";
		pType=U.getPropType((descSec+amenitiesSec+floorData+availData)
				.replace("craftsmanship and award-winning", "")
				.replace("coastal experience", "coastal homes"));
		
//		

//		U.log("&&&&&&&&&&&&&&"+Util.matchAll(descSec+floorData+availData+amenitiesSec,"[\\w\\s\\W]{50}patio[\\w\\s\\W]{40}",0));
		String dType=ALLOW_BLANK;
		dType=U.getdCommType((descSec+floorData+availData+amenitiesSec).replace("\"Stories\":\"1.0\"", "1 Story").replace("\"Stories\":\"2.0\"", "2 Story")
				.replaceAll("floor|Graham Branch Creek|fabulous one-and-a-half story home is perfect", ""));
		
		U.log("dprop type:::::::::::"+dType+"\n");
		
//		U.log("&&&&&&&&&&&&&&"+Util.matchAll(descSec+floorData+availData+amenitiesSec,"[\\w\\s\\W]{50}Story[\\w\\s\\W]{40}",0));
//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/stories.txt", descSec+floorData+availData+amenitiesSec);
		
		String pStatus=ALLOW_BLANK;
		
		String[] sec = U.getValues(comHtmlAPI, "\"DescriptionShort\":\"", "\"");
		for(String s : sec) {
			U.log(s);
			descShortSec+=s.replace("Opportunities |", "Opportunities \\|");
		}
		U.log(descShortSec);
		

		
		if(descShortSec!=null)
			descShortSec = descShortSec.replace("Move-In Ready Homes Available Now", "Move-In Ready Homes");
		pStatus=U.getPropStatus((descShortSec+descSec+amenitiesSec).replace("high school (opening fall 2022)", "")
				.replace("new homes available in Sienna today", "").replace("new homes available at Palmera Ridge", "")
				.replace("School Coming Fall 2024", "").replace("Pavilion (Coming Soon)", "")
				.replace("\"Canine Cove Coming Soon", "")
				.replace("about the new homes available in", "")
				.replace("New Model Now Open", "").replace("Elementary, now open", "").replace("high school, now open", "")
				.replace("Lake View & Oversized Homesites Available", "Lake View Oversized Homesites Available")
				.replace("Now Selling in Final Section", "Now Selling Final Section")
				.replaceAll("proximity is now available|school is now open|Lake House Now Open|Adventure Cove is coming in 2022|Coming Soon- The Grove will include|new adventure is coming soon|Learn more about the spacious new homes available in the prestigious|learn more about the new homes available in|Learn more about the family-friendly new homes available in|learn more about the new homes available in Paloma Lake|Elementary School Now Open|Camp Coming|Coming soon — a|Coming soon will|Dock \\(Coming|\"Amenity\":\"Coming|ConstructionStageText\":\" Coming|Coming Soon - The Dock|Coming 2021! The Grove|wetlands and coming|New Model Coming Soon|Coming Soon!Elev|school \\(opening fall 2021|Village \\(Coming|High \\(Coming Fall| Elementary, now open|Great selection of wooded and oversized lots available", ""));
		
//		U.log(Util.matchAll(descShortSec+descSec+amenitiesSec+subComm,"[\\w\\s\\W]{20}coming soon[\\w\\s\\W]{10}",0));
		if(sqft[0]==null)sqft[0]=ALLOW_BLANK;
		if(sqft[1]==null)sqft[1]=ALLOW_BLANK;
		
		if(prices[0]==null)prices[0]=ALLOW_BLANK;
		if(prices[1]==null)prices[1]=ALLOW_BLANK;
//		if(comUrl.contains("https://www.coventryhomes.com/houston/kleinorchard"))pStatus+=", New Section Now Open";
		if(comUrl.contains("https://www.coventryhomes.com/houston/thehighlands-60ft-homesites") || comUrl.contains("https://www.coventryhomes.com/houston/thehighlands-45ft-homesites"))
		if(!comName.contains("The Highlands"))
			comName = "The Highlands "+comName;

		if(comName.contains("Inventory"))
		{
			comName=comName.replace("Inventory", "");
		}
		if(pStatus.equals("New Homes Available, Now Available"))
		{
			pStatus=pStatus.replace("New Homes Available, Now Available", "Homes Now Available");
		}
		
		U.log("GEO HERE: "+geo);
			
		comName=comName.replace("Ii", "II");
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0],add[1].replace("Spring/Conroe", "Conroe"), add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPrice(prices[0], prices[1]);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replaceAll("Move-in Ready Homes|Move-in Ready", "Quick Move-in Homes"));
		data.addNotes(U.getnote(comHtmlAPI));
		data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		U.log("=============");
		
		}
		i++;
		j++;
		
	}

	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"216.169.73.65",34679));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language","en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			urlConnection.addRequestProperty("authorization", "Basic Y292Ym95bDo3OEJGMDQ4Ri04OEY5LTREQTMtODdBNS1FRUY0NkE2NzVBRkU6RkRFN0ZDM0YtMTM1Qi00OENFLUFDMDQtMjhBRTQ4QTQ2QTcz");
			urlConnection.addRequestProperty("referer", "https://www.coventryhomes.com/");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			
			U.log("gethtml expection: "+e);
			

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
//================================================================================================================================================================================================

	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;
		U.log(url);

		String host = new URL(url).getHost();
		host = host.replace("www.", "");

		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();

		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.get(url);
					// U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,800)", "");
					Thread.sleep(15000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}