package com.shatam.b_041_060;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractPerryHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static int siteCounter = 0;
	int i = 0;
	static int j = 0;
	int k=0;
	public int inr = 0;

	private static final String builderUrl = "https://www.perryhomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractPerryHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Perry Homes.csv", a.data().printAll());
	}

	public ExtractPerryHomes() throws Exception {

		super("Perry Homes", "https://www.perryhomes.com/");
		LOGGER = new CommunityLogger("Perry Homes");
	}

	public void innerProcess() throws Exception {

		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		HashSet<String> brittonHomes = new HashSet<String>();
		String html = U.getHTML("https://www.perryhomes.com/");
		U.log("===============");
	//	String mainhtml=U.getHtml("https://www.perryhomes.com/", driver);
		String regionsUrl[]=U.getValues(html,"<li class=\"section-header\"><a href=\"/communities-near-me/\">Search Near Me</a></li>","<li class=\"section-header\"><a href=\"/texas/new-homes/new-designs/\">New Designs</a></li>");
		String regHtml="";
		//int count=1;
		String CommSec=null;
		for(String rurl:regionsUrl) {
			String regionurl[]=U.getValues(rurl,"<li class=\"section-header\"><a href=\"","\">");
//			U.log("total regions::"+regionurl.length);
			for(String a:regionurl) {
				String regiUrl="https://www.perryhomes.com"+a;
//				U.log("regiUrl====="+regiUrl);
				
				
				 regHtml=U.getHTML(regiUrl);
				 
				
				String urls[]=U.getValues(regHtml,"<div style=\"text-align: left;\">", "</a></h4>");
				U.log("total communities in this region"+urls.length);
				int s=1,c=1;
				for(String b:urls) {
//					U.log(c+"=="+b);
					String bu=null;
					
					if(b.contains("href=\"https://www.brittonhomestexas.com/community")) {
						brittonHomes.add(b);
						continue;
					}
//					U.log(c+"=="+b);
					bu="https://www.perryhomes.com"+U.getSectionValue(b,"href=\"","\" >");//Community url
//					U.log("FIRST");
//					U.log(c+"=="+bu);
					String bhtml=U.getHTML(bu); //community html
					
//					try {
						addInfo(bu,bhtml.replaceAll("\"/gallery-of-homes/patios/\">Patios</a>", ""),b);
//					} catch (Exception e) {}
					c++;
				}
//				U.log("br Homes: "+s);
			}
		}
		U.log(brittonHomes.size());
		for(String b:brittonHomes) {
			//U.log(c+"=="+b);
			String bu=null;
			//U.log("=="+b);
			bu=U.getSectionValue(b,"href=\"","\"");
//			U.log("SECOND");
//			U.log("=="+bu);
			String commSec=U.getSectionValue(regHtml, "<input id=\"sectJson\" type=\"hidden\" value=\"", "\" />");
			commSec=commSec.replace("&quot;", "");
			findBrittonHomesDetails(bu, b);	/////	
		}
//		
		try{driver.quit();}catch(Exception e) {}
		LOGGER.DisposeLogger();
	
	}



	// TODO : Extract Perry Homes details here
	private void addInfo(String cUrl, String comInfo,String comna) throws Exception {
//		if(k > 100)             commurl      //community Html     //region url
		
//		if(!cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/vida/389/")) return;
 
//		if(!cUrl.contains("/meridiana/356/")) return;
		U.log("k="+k);  
	//	try{
//		if(k>=100)
		{
           U.log("C url is"+cUrl);
		//	if(!cUrl.contains("https://www.perryhomes.com/new-homes-houston/meridiana/356/"))return;
//			U.log(U.getCache(cUrl));

		//	if (cUrl.contains(""))return;// Url Of direction page
   
//			U.log(":::::" + k + ":::::::::"+comInfo);
			//U.log(k + " ==>" + cUrl);
//			 U.log(comInfo);
			
			
			U.log(cUrl);
			String comHtml = null;
			if (!cUrl.contains("sales-center-map")) {// if map is not present then it ewill take html by driver
				comHtml = U.getHtml(cUrl, driver);
			} else {
				// for coming soon communities
				comHtml = U.getHTML(cUrl);//subComm 
				U.log("AAA"+U.getCache(cUrl));
			}
			String statusFromName=ALLOW_BLANK;
			if(comHtml!=null) {
				statusFromName=U.getHtmlSection(comHtml, "<title>", "</title>");				
			}
			
			U.log("Cache URL: "+U.getCache(cUrl));
			String subCommSection[] = U.getValues(comHtml, "<div class=\"col-xs-12 col-md-6\">", "REGISTER FOR UPDATES</div></a>");
			//U.log("SUB COMM Sec!!"+subCommSection.length);
			if(subCommSection.length > 0){
				U.log("----------> Return community, since there is no sub community.");
				LOGGER.AddCommunityUrl(cUrl + "=============> Main community page url with subcommunity.");
				return;
			}

			if (data.communityUrlExists(cUrl)) {
				LOGGER.AddCommunityUrl(cUrl + "=============> Repeated");
				return;
			}
			
			if(cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/johnson-ranch/317/")) {
				LOGGER.AddCommunityUrl(cUrl+ "---------------------------------REDIRECTED");
				return;
			}
			
			LOGGER.AddCommunityUrl(cUrl);

			
			String cc = U.getSectionValue(comHtml, "<script type=\"application/ld+json\">", "</script>");//json
			//U.log("gggggggggg> " + cc);
			comHtml = comHtml.replaceAll(
					"RANCH ROAD|RANCHROAD|Ranch Town|Ranch and|Oaks Ranch|OAKS RANCH|href=\"mailto:.*\"|}],\"description\": \".*\"",
					"");
			
			//removing unwanted sections-----------------
			if(comHtml.contains("<script type=\"application/ld+json\">")) {
				
				String remOne = U.getSectionValue(comHtml, "<script type=\"application/ld+json\">", "</script>");
				
				//U.log("remOne: "+remOne);
				comHtml = comHtml.replace(remOne, "");
			}
			
			if(comHtml.contains("title=\"Email a friend\">")) {
				
				String remTwo = U.getSectionValue(comHtml, "title=\"Email a friend\">", "aria-hidden=\"true\">");
				
				//U.log("remTwo: "+remTwo);
				comHtml = comHtml.replace(remTwo, "");
			}
			
			// ================commName===============
			String commName=null;
		
			try {
			commName = U.getSectionValue(comHtml,"style=\"font-size: 1.5em; font-weight: bold; text-align: center;\">","</h1>");
			}
			catch(NullPointerException ne) {
				
			}
			if (commName == null)
				commName = U.getSectionValue(comInfo, "<h4 style=\"color:black\">", "</h4>");
			
			if (commName == null)
				commName = U.getSectionValue(comHtml, " padding:20px 2% 0px 2%;\"><b>", "</b>");
			if (commName == null)
				commName = U.getSectionValue(comna, "/\" >", "- ");
if(!commName.contains("'")) {
			commName=commName.replaceAll("&#39;","'");
			}
			
String comNameStatus = " "+commName;	

			if (commName != null) {
				commName = commName.replace("&#39;", "'");
			    commName=commName.replace("45&#39;", "");	
			}
			if (cUrl.contains("https://www.perryhomes.com/new-homes-austin/la-cima/"))
				commName ="La Cima 60'";
			if (cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/balcones-creek/266/"))
				commName ="Balcones-Creek Half Acres";
			if (cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/vintage-oaks/157/"))
				commName ="Vintage Oaks";
			
			comNameStatus += " "+commName;
			U.log("commName:::::::::::" + commName + ":::::::::::");
			commName = commName.replaceAll(
					"RANCH$|Ranch$| \\| Perry Homes</title>| by Perry Homes|- Gated|- Now Available| - Coming Soon| - Now Open| Gated Community| by Perry Homes | - Final Opportunity",
					"");
			if (commName.endsWith("Townhomes")) {
				commName = commName.replace("Townhomes", "");
			}
			if (commName.trim().endsWith("Ranch")) {
				commName = commName.replace("Ranch", "");
			}
			
			commName=commName.replaceAll("&#39|;","");
			comNameStatus += " "+commName;
			
			
			U.log("commName:::::::::::" + commName + ":::::::::::"+comNameStatus);
			if(commName!=null) {
				commName=commName.replace("VIDA 50'", "Vida 50'");
			}
			// ===========Address && latLng============\
			String MylatSec=U.getSectionValue(comHtml,"{\"@context\"","</head>");
//			U.log("my alat Sevcf"+comHtml.contains("{\"@context\"")+ MylatSec);
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String mapHtml=ALLOW_BLANK;
			String latLngSec = Util.match(comHtml, "/@(.*?),\\d+(.*?)z", 1);
			U.log("1st latlng sec"+latLngSec);
			if (latLngSec == null) {
				 mapHtml = U.getHTML(builderUrl + "/sales-center-map"
						+ U.getSectionValue(comHtml, " href=\"/sales-center-map", "\""));
//				U.log(mapHtml);
				latLng[0] = U.getSectionValue(mapHtml, "lat: ", ",");
				latLng[1] = U.getSectionValue(mapHtml, "lng: ", "}");
			}
			U.log("2nd latlng sec"+latLngSec);
			if (latLngSec != null)
				latLng = latLngSec.split(",");

			if (latLng[0] == null || latLng[0] ==null||latLng[0]==ALLOW_BLANK||latLng[1]==ALLOW_BLANK) {
				latLng[0] = U.getSectionValue(comHtml, " \"latitude\": \"", "\",");
				latLng[1] = U.getSectionValue(comHtml, " \"longitude\": \"", "\"}");
			}
			/**
			 * @date 21 Dec 2018
			 */
			if (latLng[0] == null && latLng[1] == null) {
				latLng[0] = U.getSectionValue(comHtml, "{ lat:", ",");
				latLng[1] = U.getSectionValue(comHtml, ", lng:", "};");
			}
			U.log("latlng is " + latLng[0] + "::::::" + latLng[1]);
			
		//	String MylatSec=U.getSectionValue(comHtml, "<a target=\"_blank\" rel=\"noopener\" href=\"https://maps.google.com/maps?ll=","&amp;");
//			
//			String MylatSec=U.getSectionValue(comHtml,"<td class=\"line-content\">{\"@context\": \"http://schema.org\",\"@type\": \"HomeAndConstructionBusiness\",\"url\": \"https://www.perryhomes.com/new-homes-san-antonio/weston-oaks/375/\",\"logo\": \"https://www.perryhomes.com/content/_images/PerryHomesLogo.svg\",\"image\": \"https://www.perryhomes.com//content/_gallery\\homes\\san_antonio\\weston_oaks/weston-oakscommunityphoto_413149_w1060_h596.jpg?id=a797fb6a-1397-46a9-8482-a3f45bf97e86/\",\"hasMap\":[\"\"],\"address\":[{\"@type\": \"PostalAddress\", \"addressLocality\": \"San Antonio\", \"addressRegion\": \"TX\",\"postalCode\": \"78245\", \"streetAddress\": \"812 Fort Stockton\"}],\"description\": \"Located in Northwest San Antonio, Weston Oaks offers an ideal location and plenty of amenities for the entire family. This beautiful master-planned community boasts a bike and hike trail, a clubhouse, two sparkling pools, sports courts and a playground. Residents enjoy a wide array of entertainment, shopping and dining options, just minutes from the community. This northwest oasis is also a short drive from popular destinations such as JBSA Lackland AFB, Northwest Community College, Sea World, The University of Texas at San Antonio and much more. Students within the community attend the highly-rated Northside ISD including on-site Edmund Lieck Elementary School. As part of our Tradition of Excellence all Perry homes feature smart home technology and an industry-leading warranty. Register for updates to receive additional information about this family-friendly community.\",\"name\": \"Perry Homes - Weston Oaks 55' - Now Available\", \"telephone\": \"(210) 236-3618\",\"openingHours\": [\"Mo,Tu,We,Th,Fr,Sa 10:00 - 18:00\", \"Su 12:00 - 18:00\"],\"geo\": {\"@type\": \"GeoCoordinates\", \"latitude\": \"29.4246894\", \"longitude\": \"-98.740116\"},\"priceRange\": \"$450s\",\"sameAs\" : [ \"https://www.facebook.com/perryhomes\",\"https://twitter.com/perryhomes\", \"https://www.instagram.com/perryhomestexas/\"]}\n" + 
////					"</td>", "<td class=\"line-content\">{\"@context\": \"http://schema.org\",\"@type\": \"HomeAndConstructionBusiness\",\"url\": \"https://www.perryhomes.com/new-homes-san-antonio/weston-oaks/375/\",\"logo\": \"https://www.perryhomes.com/content/_images/PerryHomesLogo.svg\",\"image\": \"https://www.perryhomes.com//content/_gallery\\homes\\san_antonio\\weston_oaks/weston-oakscommunityphoto_413149_w1060_h596.jpg?id=a797fb6a-1397-46a9-8482-a3f45bf97e86/\",\"hasMap\":[\"\"],\"address\":[{\"@type\": \"PostalAddress\", \"addressLocality\": \"San Antonio\", \"addressRegion\": \"TX\",\"postalCode\": \"78245\", \"streetAddress\": \"812 Fort Stockton\"}],\"description\": \"Located in Northwest San Antonio, Weston Oaks offers an ideal location and plenty of amenities for the entire family. This beautiful master-planned community boasts a bike and hike trail, a clubhouse, two sparkling pools, sports courts and a playground. Residents enjoy a wide array of entertainment, shopping and dining options, just minutes from the community. This northwest oasis is also a short drive from popular destinations such as JBSA Lackland AFB, Northwest Community College, Sea World, The University of Texas at San Antonio and much more. Students within the community attend the highly-rated Northside ISD including on-site Edmund Lieck Elementary School. As part of our Tradition of Excellence all Perry homes feature smart home technology and an industry-leading warranty. Register for updates to receive additional information about this family-friendly community.\",\"name\": \"Perry Homes - Weston Oaks 55' - Now Available\", \"telephone\": \"(210) 236-3618\",\"openingHours\": [\"Mo,Tu,We,Th,Fr,Sa 10:00 - 18:00\", \"Su 12:00 - 18:00\"],\"geo\": {\"@type\": \"GeoCoordinates\", \"latitude\": \"29.4246894\", \"longitude\": \"-98.740116\"},\"priceRange\": \"$450s\",\"sameAs\" : [ \"https://www.facebook.com/perryhomes\",\"https://twitter.com/perryhomes\", \"https://www.instagram.com/perryhomestexas/\"]}\n" + 
////							"</td>");
			
//			U.log("My latSec"+cc);
			if((latLng[0]==null||latLng[1]==null||latLng[0]==ALLOW_BLANK)&& cc!=null) {
				
					
				latLng[0]=U.getSectionValue(cc, " \"latitude\": \"", "\",");
				    latLng[1]=U.getSectionValue(cc,"\"longitude\": \"","\"}");
			}

			String addSec = U.getSectionValue(comHtml, " <a href=\"https://www.google.com/maps/place", "</a>");
			// Call for an Appointment!
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/grand-central-park/323/")) {
				addSec=U.removeSectionValue(addSec, "/Perry+Homes+-+Grand+Central+Park", "\" target=\"_blank\"");
				add[0]=U.getSectionValue(addSec, ">", "<br />");
				
			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/grand-central-park/195/")){
				addSec=U.removeSectionValue(addSec, "/Perry+Homes+-+Grand+Central+Park", "\" target=\"_blank\"");
				add[0]=U.getSectionValue(addSec, ">", "<br />");
			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/kinder-ranch/278/")) {
				addSec=U.removeSectionValue(addSec, "/Perry+Homes+-+Grand+Central+Park", "\" target=\"_blank\"");
				add[0]=U.getSectionValue(addSec, ">", "<br />");
			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/kinder-ranch/278/")) {
				addSec=U.removeSectionValue(addSec, "/Perry+Homes+-+Grand+Central+Park", "\" target=\"_blank\"");
				add[0]=U.getSectionValue(addSec, ">", "<br />");
			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/kinder-ranch/278/")) {
				addSec=U.removeSectionValue(addSec, "Perry+Homes+-+Kinder+Ranch", "target=\"_blank\">");
				add[0]=U.getSectionValue(addSec, ">", "<br />");
			}
			
			
			//String 
			if(addSec!=null) {
				addSec=addSec.replace("/Sienna+65&#39;+Valencia+by+Perry+Homes/@29.4743583,-95.5294776,17z/data=!3m1!4b1!4m5!3m4!1s0x8640f1fb9e3b0403:0x749ca15dfe0f6092!8m2!3d29.4743583!4d-95.5294776\" target=\"_blank\">", "");
			}
			U.log("addSec 1 is::::::" + addSec);
			if (addSec == null) {
				addSec = U.getSectionValue(comHtml, "Sales Center:</strong></i>", "<div class=\"container");
//				U.log("My Add sec 2"+addSec);
				if (addSec != null)

					addSec = U.getSectionValue(addSec, "<div></div>", "</div>");
//				U.log("inner Add Sec"+addSec);
			}
          
			if (addSec == null) {
				addSec = U.getSectionValue(comHtml, "<table align=\"center\"", "</table>");
//				U.log("----------------->>>>>>>"+addSec);
				
				if (addSec != null && addSec.contains("<b>")) {
//					U.log("1===>"+addSec);
					addSec = U.getSectionValue(addSec, "<tr>", "<b>");
					addSec = addSec.replaceAll("<br />", ",").replaceAll("<.*?>", "").trim();
				}
				if (addSec != null && (addSec.contains("<br/>") || addSec.contains("<br />"))) {
					String _addSec = U.getSectionValue(addSec, "<br/>", "</td>");
//					U.log("3rd add Sec"+addSec );
					if (_addSec == null)
						_addSec = U.getSectionValue(addSec, "<br />", "</td>");
					addSec = "," + _addSec.replaceAll("<.*?>", "").trim();
//					U.log("__addSec"+addSec);
//					U.log("2===>"+addSec);
					// addSec = Util.match(_addSec, "(.*?)<br/>",1);
				}
//				U.log(addSec);
			}
			if (addSec != null) {
				addSec = addSec.replace("<br>Fair ,", "<br>Fair Oaks Ranch ,").replaceAll("<br />|<br>", ",");
				addSec = addSec.replaceAll("/Perry(.*?)_blank\">", "").replace("San Antonio, in 78245", "San Antonio, TX 78245");
				addSec = addSec.replaceAll("/Perry(.*?)blank&quot;>", "");
				addSec = addSec.replaceAll("Call for (A|a)n (A|a)ppointment(!)?|Please call for more information", "");
				addSec = addSec.trim().replace("Call for Appointment", "");
				U.log("MAIN ADD SEC1"+addSec);
				String tempAdd[] = addSec.trim().split(",");
				if (tempAdd.length == 3) {

					add[0] = tempAdd[0];
					add[1] = tempAdd[1];
					add[2] = Util.match(tempAdd[2], "\\w+");
					add[3] = Util.match(tempAdd[2], "\\d+");
				} else {
					add = U.getAddress("," + addSec);
				}
			}
			if(addSec==null||add[0].length()<3) {
				addSec=U.getSectionValue(cc,"\"address\":[{\"@type\": \"PostalAddress\"", ",\"description\"");
				U.log("MAIN ADD SEC2"+addSec);
				addSec=addSec.replace("Call For an Appointment", "");
				add[0]=U.getSectionValue(addSec, "\"streetAddress\": \"","\"}");
				add[1]=U.getSectionValue(addSec, "\"addressLocality\": \"", "\",");
				add[2]=U.getSectionValue(addSec, "\"addressRegion\": \"", "\",");
				add[3]=U.getSectionValue(addSec, "\"postalCode\": \"", "\",");
			}
			
			
			
//			if(add[0].contains("Call for an appointment"))
//				add[0]=null;
			
			
			U.log("------------------->" + Arrays.toString(add));

			String zip = ALLOW_BLANK;
			if (add[3] != ALLOW_BLANK)
				zip = add[3];
			// -------------fetching address from latlng-----------------
			add[0] = add[0].trim().replaceAll("Contact the Internet Home Consultant|Coming Soon|Call For Appointment|Call for an appointment|"
					+ "Call for an Appointment", ALLOW_BLANK);
			add[0] = U.getNoHtml(add[0]);
			U.log("adddd *********" + add[0]);
			if (add[0] == null || add[0] == "") {
				add[0] = ALLOW_BLANK;
			}
			if (latLng[0] == null) {
				latLng[0] = ALLOW_BLANK;
				latLng[1] = ALLOW_BLANK;
			}
			
			
			
			if ((add[0] == null || add[0].length() < 3) && (latLng[0] != null && latLng[0].length() > 3)) {
				U.log("add *********" + add[0]);
				String[] add1 = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);

				add[0] = add1[0];
				geo = "TRUE";
				if (add[3].equals(ALLOW_BLANK)) {
					add = add1;
				}
				add1 = null;
			}
			add[2] = add[2].replace("Texas", "TX");
			if(add[0]==null) add[0]=ALLOW_BLANK;
			U.log("Add ::" + Arrays.toString(add));
			if (add[3] == null && zip != ALLOW_BLANK)
				add[3] = zip;

			String mapUrlSec = U.getSectionValue(comHtml, "<div id=\"SalesOfficeHolder\"", "Directions\"></a>");
			if(mapUrlSec==null) mapUrlSec=U.getSectionValue(comHtml, "<div id=\"SalesOfficeHolder\"", "Directions\" /></a>");
			String mapUrl = null;
			if (mapUrlSec != null) {
				mapUrl = U.getSectionValue(mapUrlSec, "<a href=\"", "\"");
				if (mapUrl != null && mapUrl.contains("maps")) {
					mapUrl = U.getValues(mapUrlSec, "<a href=\"", "\"")[1];
				}
				if (mapUrl != null && !mapUrl.startsWith("http")) {
					mapUrl = builderUrl + mapUrl;
				}
			}
			U.log("mapUrl ::" + mapUrl);
			
			if (latLng == null || mapUrl == null) {
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null){
//					latLng = U.getlatlongHereApi(add);
					latLng = U.getGoogleLatLngWithKey(add);
					geo = "TRUE";
				}
			}
			
			if (add[0].length()<4 && latLng[0].length() < 4) {//lenght<4
				// U.log(comInfo);
				// mapUrl = builderUrl+ U.getSectionValue(comInfo, "<a
				// class=\"ClkEvnt-Com-Btn-Vw-Map-Dir\" href=\"", "\"");
				String dirHtml = U.getPageSource(mapUrl);
				latLng[0] = U.getSectionValue(dirHtml, "lat: ", ",");
				latLng[1] = U.getSectionValue(dirHtml, "lng: ", " };");
				add = U.getAddressGoogleApi(latLng);
				if (add == null){
//					add = U.getAddressHereApi(latLng);
					add = U.getGoogleAddressWithKey(latLng);
				}
				geo = "TRUE";
			}

			if (latLng[0] == null || latLng[0].length() < 4) {
				// mapUrl = builderUrl+ U.getSectionValue(comInfo, "<a
				// class=\"ClkEvnt-Com-Btn-Vw-Map-Dir\" href=\"", "\"");
				String dirHtml = U.getHTML(mapUrl);
				latLng[0] = U.getSectionValue(dirHtml, "lat: ", ",");
				latLng[1] = U.getSectionValue(dirHtml, "lng: ", " };");
			}
		//	add[0] = add[0].replaceAll("([\\w\\s\\W\\d]*)>", "");
			
			
			// ============= Quick Move in Home ======================

			String quickMoveInHtml = U.getHtml("https://www.perryhomes.com/texas/new-homes/move-in-ready-homes",
					driver);
			int quickHomeCnt = 0;
			String quickHomeDetails = null;
			if (quickMoveInHtml != null) {
				String[] quickHomes = U.getValues(quickMoveInHtml, "class=\"row InventoryGallery marginLR-0\">",
						"<div class=\"halfBathInfo\">");
				U.log(quickHomes.length);
				String tempComName = commName.trim();
				tempComName = tempComName.replaceAll("\\d{2}'/\\d{2}'$|\\d{2}'$|- of Lakeland Heights", "").trim();
				U.log("Temp name::" + tempComName);
				for (String quickHome : quickHomes) {
					String comSec = U.getSectionValue(quickHome, "<div style=\"background-color", "</div>");
					if (comSec.contains(tempComName)) {
						U.log("found one");
						quickHomeDetails += quickHome;
						quickHomeCnt++;
					}
				}
			}
			U.log("Quick  Home count===" + quickHomeCnt);
			// ========Price==========
			if (quickHomeDetails != null) {
				quickHomeDetails = quickHomeDetails.replaceAll("<div class=\"homeDetail\">", "");
			}
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			comInfo = comInfo.replace("0s", "0,000");
			comHtml = comHtml.replace("From the $1Ms", "From the $1,000,000");

			String[] prices = U.getPrices(comHtml + comInfo + quickHomeDetails,
					"\\$\\d,\\d{3},\\d{3}|From the \\$\\d,\\d{3},\\d{3}|salesPrice text-center\">\\$\\d{3},\\d{3}</div>|From the \\$\\d{3},\\d{3}|salesPrice\">\\$\\d{3},\\d{3}</div>|salesPrice\">\\$\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
	//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml + comInfo + quickHomeDetails, "[\\s\\w\\W]{30}$1,073,900[\\s\\w\\W]{30}", 0));
			U.log("Price are :: " + minPrice + ":::::" + maxPrice);

			// ===========Square Feet===========
			String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;

			// U.log(comInfo);
			String[] sqFt = U.getSqareFeet(comHtml + comInfo + quickHomeDetails,
					"\\d,\\d{3} sq. ft.|\\d{1},\\d{3}\\s*-\\s*\\d{1},\\d{3}\\s*Sq.| \\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|sqftInfo\">\\d{4}",
					0);

			minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

			U.log("Sq feet are :: " + minSqFt + ":::::" + maxSqFt);

			// ========Remove Meta Content========
			String remove1 = U.getSectionValue(comHtml,
					"<a class=\"ClkEvnt-Sec-Pull-Out-SBtn-Em-Fr\" href=\"mailto:?subject=", "Email a Friend");
			if (remove1 != null) {
				comHtml = comHtml.replace(remove1, "");
				U.log("success of remove1");
			}
			
//			U.log("mmmmmm1"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}New Section Coming Soon[\\w\\s\\W]{100}", 0));


			
			String breadCrumbData = U.getSectionValue(comHtml, " <div class=\"breadcrumb ", "</div");
			//U.log(breadCrumbData);
			String remMeta = U.getSectionValue(comHtml, "<meta content=", "<script type=");
			if (remMeta != null) {
				comHtml = comHtml.replace(remMeta, "");
				U.log("success of remMeta");
			}
			
			

			comHtml = comHtml.replace("Move-in Ready Homes</a></li>", "");

			// ============Community Type==============
			
			//comInfo + 
			String comType = U.getCommunityType((comHtml).replaceAll(
					"Experience resort living at its finest|luxurious resort-style amenities|Residents enjoy resort-style amenities|Colony features resort-style amenities|beautiful master-planned community near Dallas|The Groves is a 1,000-acre master-planned community|the master planned community of Veranda promises a quaint|resort-style pool|features of a larger master-planned community and the personal lifestyle of a small community|resort-style living|master-planned Georgetown community also boasts|a 492-acre master-planned community located just|pavilion, a resort style pool, outdoor|WhiteStone Golf Club, and several|small community, enjoy lakeside living in this modest-sized|A 3,700-acre master planned community in Fort|Magnolia Creek is an established master|welcome in our lovely gated community|a beautiful master-planned community|make this gated community",
					""));
			
			U.log("comType: "+comType);

			// ===========property Type=========
			// TODO : Property Type
			//+ comInfo
			
			String homesHtml = getDataOfHomes(comHtml.replaceAll("patios/\">Patios</a|<a href=\"/gallery-of-homes/patios/\">Patios</a>",""));
			comHtml = comHtml.replaceAll("well-planned common areas|meeting room, covered patio and a junior Olympic|where luxury meets with the natural|VILLA DRIVE|(V|v)illage|CABIN DRIVE|gallery-of-homes/patios/\">Patios</a>",
					"");
			// U.log(homesHtml);;
			String psec=(comHtml + homesHtml).replaceAll("Walsh is not merely a traditional master-planned community", "").replaceAll("patios/\">Patios</a|<a href=\"/gallery-of-homes/patios/\">Patios</a>","");
			
	
			String propType = U.getPropType(psec);
			
//			U.log("PROPTYP"+Util.matchAll(comInfo , "[\\w\\W\\s]{60}covered patio[\\w\\W\\s]{60}", 0));
//			U.log("PROPTYP"+Util.matchAll(homesHtml , "[\\w\\W\\s]{60}covered patio[\\w\\W\\s]{60}", 0));
//			U.log("PROPTYP"+Util.matchAll(comHtml , "[\\w\\W\\s]{60}covered patio[\\w\\W\\s]{60}", 0));

			// ==========Derived TYpe =========
			comHtml = comHtml.replace("</div><div class=\"detailLabel\">", " ");
			if (quickHomeDetails != null) {
				quickHomeDetails = quickHomeDetails.replaceAll("2</div><div class=\"detailLabel\">Story", " 2 story ")
						.replaceAll("1</div><div class=\"detailLabel\">Story", " 1 story ")
						.replaceAll("Rancho|rancho|Cypress Ranch", "");

			}
			comHtml = comHtml.replaceAll("<div>Coming Soon|Rancho|RANCHO|rancho|Cypress Ranch|jordanranch|1890 Ranch",
					"");
//
/*			comHtml = comHtml
					.replace("storyInfo\">\n" + "                                    <div class=\"homeDetail\">2",
							" 2 Story ")
					.replace("storyInfo\">\n" + "                                    <div class=\"homeDetail\">1",
							" 1 Story ");
*/			
			comHtml = comHtml.replaceAll("<div class=\"storyInfo\">\\s+<div class=\"homeDetail\">2</div>", "2 Story");
			comHtml = comHtml.replaceAll("<div class=\"storyInfo\">\\s+<div class=\"homeDetail\">1</div>", "1 Story");
			String dType = U.getdCommType((comHtml + quickHomeDetails).replaceAll(
					"RanchCommunityPhoto|The Ranches at Creekside|\\+Ranch|ranchcommunityphoto|Rock Ranch|[r|R]anch/|Kinder Ranch|Ranch</option>|Wolf Ranch|Rita Ranch|Ranch\"",
					""));
			U.log("derived type:::::::" + dType);
			


			// =========Property Status=======
			String pStatus = ALLOW_BLANK;
//			String rem = U.getSectionValue(comHtml, "</h1>", "</div>");
//			if(rem!=null)
//				comHtml = comHtml.replace(rem, "");
			comHtml = comHtml//.replace("Final Home Opportunity in Phase I", "Final Home Opportunity Phase I")
					.replace("New Section with Premium Lots Available Now", "")
					.replaceAll(
					"New Section Available|</h1>(.*)?</div>|Luxurious Homes Ready Now in Katy|Homes Now Available in New Top-Rated Comal ISD|Homes Ready Now in Fort Worth|Homes Ready Now in NISD |limited opportunity to live in a master-planned community in the City of Friendswood which is known for its small town charm. %0A%0Ahttp://www.perryhomes.com/new-homes-houston/west-ranch/223/\">|t miss the rare and limited opportunity to live in a master-planned community in the City of Friendswood which is known for its small town charm. \"|&body=Coming Soon|description\": \"Coming Soo|Opening Summer 2018, contact|this great location before they are sold out|Now Open</a>",
					"").replace("New Section with Open-Concept Homes Available Now", "")
					.replace("Oversized Lots Still Available in New Section", "Oversized Lots Available in New Section")
					.replaceAll("The Tribute 40&#39; - Now Available |- Now Available located in The Colony|=\"The Tribute - Now Available\"|The Tribute - Now Available|"
							+ "The Tribute 40&#39; - Now Available", "");
			
			breadCrumbData = breadCrumbData.replaceAll("The Tribute - Now Available|The Tribute 40&#39; - Now Available", "");
					
//			U.log("mmmmmm"+Util.matchAll(comHtml+comNameStatus +breadCrumbData, "[\\w\\s\\W]{80}now open[\\w\\s\\W]{80}", 0));
			
			pStatus = U.getPropStatus((comNameStatus +breadCrumbData).replaceAll("Now Available The Tribute 40|Now Available Watercress 80|- Now Available|"
					+ "- Now Open|- Now Available|- Now Available</a>","")
					+ U.getNoHtml(comHtml.replace("Prominent Katy ISD Coming Soon</div>", "").replaceAll(
					"- Now Open|- Now Available|Now Available located in Haslet|Now Available Watercress 80|Watercress - Now Available|The Tribute - Now Available|The Tribute 40&#39; - Now Available|Gated - Now Open \\| New Homes Katy TX|Firethorne - Now Open|Move-In Ready Homes in Georgetown|Amenities with Homes Ready Now|Walsh - Coming Soon|Move-in Ready|Move-in Ready Homes|move in ready homes, new construction homes for sale|Homes for Sale with Amenities for all Ages Coming Soon",""))+statusFromName);
			U.log("statusFromName "+statusFromName);
//			U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{80}coming[\\w\\s\\W]{80}", 0));
	//		U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{80}Now Available[\\w\\s\\W]{80}", 0));
			if ((quickHomeCnt > 0 || comHtml.contains("salesStatus\">Ready for Move-In"))
					&& !pStatus.contains("Ready For Move")) {
				if (pStatus != ALLOW_BLANK) {
					pStatus += ", Ready For Move-in";
				} else {
					pStatus = "Ready For Move-in";
				}
			}
//			if(cUrl.contains("https://www.perryhomes.com/new-homes-austin/old-town-east/364/") || cUrl.contains("https://www.perryhomes.com/new-homes-austin/parkside-on-the-river/357/")||cUrl.contains("https://www.perryhomes.com/new-homes-austin/parkside-on-the-river/358/")||cUrl.contains("https://www.perryhomes.com/new-homes-austin/parkside-on-the-river/359/")) {
//				pStatus="Now Open";
//			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/sunterra/379/")) {
				pStatus+=", Now Open";
			} 
			
			if(cUrl.contains("https://www.perryhomes.com/new-homes-dallas/liberty/288/"))
				pStatus=pStatus.replace(", New Phase Open", "");
//			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/cane-island/162/"))
//				pStatus="Ready For Move-in";
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/copper-bend/295/")) {
				pStatus="New Section Now Open, Final Opportunity";
			}
			U.log("Property Status:::: " + pStatus);


/*			if (cUrl.contains("https://www.perryhomes.com/new-homes-dallas/canyon-falls/344/")) {
				add[0] = "U.S Rte 377";
				geo = "TRUE";
			}
*/			
/*			if (cUrl.contains("https://www.perryhomes.com/new-homes-austin/bryson/329/")) {
				maxSqFt = "3000";
				maxPrice = "";
			}
			if (cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/balcones-creek/264/")) {
				maxSqFt = "3100";
				maxPrice = "";
			}
			if (cUrl.contains("https://www.perryhomes.com/new-homes-austin/blanco-vista/204/")) {
				comType = comType.replace("Master Planned", "");
			}
			if(cUrl.contains("https://www.perryhomes.com/texas/new-homes-houston/candela/"))
				commName="Candela";
*/			
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]);
			}
			if (add[0].length() < 2) {
				add[0] = ALLOW_BLANK;
			}
			if (maxPrice.length() < 4) {
				maxPrice = ALLOW_BLANK;
			}
/*			if(cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/river-rock-ranch/"))
			{
				minSqFt="2,400"; 
				maxSqFt="4,100";
			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/candela/"))
			{
				minSqFt="1,500"; 
				maxSqFt="3,800";
			}
			
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/candela/"))
			{
				commName="Candela";
			}
			
			if(cUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/fronterra-at-westpointe/214/"))
			{
				minPrice="$430,000";
				maxPrice="$537,900";
				minSqFt="2400";
				maxSqFt="3400";
							

			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/pomona/228/"))
			{
				maxPrice="$459,990";
				minPrice="$361,990";
				minSqFt="1984";
				maxSqFt="2694";
							

			}
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/pomona/229/"))
			{
				maxPrice="$488,900";
				minPrice="$399,990";
				minSqFt="2354";
				maxSqFt="3299";
							

			}
			
			if(cUrl.contains("https://www.perryhomes.com/new-homes-dallas/liberty/288/"))pStatus=pStatus.replace("Opening Soon, ", "");

			if(cUrl.contains("/new-homes-austin/6-creeks/"))pStatus ="Now Open";
*/			if (pStatus.length() < 4) {
				pStatus = ALLOW_BLANK;
			}
			
			if(add[0]==null || add[0].length()<3) {
				
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getGoogleAddressWithKey(latLng);
				geo = "TRUE";
			}
			
			if(cUrl.contains("https://www.perryhomes.com/new-homes-houston/firethorne/13/"))
			{
				pStatus=pStatus+", Final Homes";
			}
		
			pStatus = pStatus.replace("Coming Summer 2021, New Section Coming Summer 2021", "New Section Coming Summer 2021");
			add[0] = add[0].replace(",", "");
			
			data.addCommunity(commName, cUrl, comType);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);

		}
		k++;
	//	}catch (Exception e) {}
	}

	// TODO : Extract Britton Home Details
	private void findBrittonHomesDetails(String comUrl, String comSec) throws Exception {

		try {
//		if(!comUrl.contains("https://www.perryhomes.com/new-homes-houston/sienna/396/"))return;
		// //for single execution
//		if(!comUrl.contains("https://www.perryhomes.com/new-homes-san-antonio/johnson-ranch/317/")) return;
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "=============>repeated");
			return;
		}
//		if (comUrl.contains("https://www.brittonhomestexas.com/community/castle-hills-50/")) {
//			LOGGER.AddCommunityUrl(comUrl + "=============>No Data Return");
//			return;
//		}
		LOGGER.AddCommunityUrl(comUrl);

		U.log("comUrl: " + comUrl);
		
		
		
		U.log(">>>>>"+comSec);

		String html = U.getPageSource(comUrl);
		U.log(U.getCache(comUrl));
		
		
//		 String UrlPart=Util.match(comUrl, "/community/\\.*");
//		 U.log("Url paqrt:: "+UrlPart);
		String brRegHtml=U.getHTML("https://www.brittonhomestexas.com/communities");
		
		String nwRegSec=ALLOW_BLANK;
		String[] brRegSec=U.getValues(brRegHtml, "<a class=\"card-link-block w-inline-block\"", "</a>");
		for(String regSection:brRegSec)	{
			String innerUrl=U.getSectionValue(regSection, "href=\"", "\">");
			
			if(comUrl.contains(innerUrl)) {
				nwRegSec+=regSection;
				U.log("mnw regSec"+nwRegSec);
			}
		}
		
		
		
		// =========== Community Name ===============
		String comName = U.getSectionValue(html, "brown-heading\">", "</h1>");
		if (comName != null)
			comName = comName.replaceAll("Welcome to", "").replaceAll("&#039;'|&#039;", "'").trim();
		U.log("comName ==" + comName);
		// ============ Notes ===========
		String notes = ALLOW_BLANK;

		// ============ Desciption Section ===========
		String desciptionSection = U.getSectionValue(html, "<main role=\"main\">", "<div class=\"inner-section");

		// =============== Homes Section ===================
		//String homeSection = U.getSectionValue(html, "<div class=\"inner-section", "<div class=\"map-section");
		String homeSection = U.getSectionValue(html, "<div class=\"inner-section", "id=\"directions\">");
		// ============ Address ====================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addSection = U.getSectionValue(html, "id=\"directions\">", "</p>");
		// U.log("addSection: "+addSection);
		if (addSection != null) {
			String addSec = U.getSectionValue(addSection, "class=\"body-link\">", "</a>");
			if (addSec != null) {
				U.log("" + addSec);
				addSec = addSec.replaceAll("<br (.*?)>", ",").replaceAll("Call for an Appointment|Coming Soon", "");
				add = U.getAddress(addSec);
			}
		}
		U.log("Add:::" + Arrays.toString(add));

		// ========== LatLng =================
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		latLng[0] = U.getSectionValue(html, "maplat=\"", "\"");
		latLng[1] = U.getSectionValue(html, "maplon=\"", "\"");
		if (latLng[0] == null)
			latLng[0] = ALLOW_BLANK;
		if (latLng[1] == null)
			latLng[1] = ALLOW_BLANK;

		U.log("LatLng:::" + Arrays.toString(latLng));

		if (add[0] == ALLOW_BLANK || add[3] == ALLOW_BLANK) {
			if (latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latLng);
				geo = "True";
			}
		} else if (add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK) {
			if (latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK) {
				add[0] = U.getAddressGoogleApi(latLng)[0];
				geo = "True";
			}
		}
		if (comUrl.contains("https://www.brittonhomestexas.com/community/castle-hills-50/")) {
			//add[0] = ;
			add[1] = "Lewisville";
			add[2] = "TX";
			latLng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latLng);
//			add[0] = U.getAddressGoogleApi(latLng)[0];
			geo = "True";
			notes = "Street Address Taken From Community Overview";

		}
		if (comUrl.contains("https://www.brittonhomestexas.com/community/Walsh-70")) {
			add[0] = "Walsh Dr";
			add[1] = "Fort Worth";
			add[2] = "TX";
			latLng = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latLng);
			geo = "True";
			notes = "Address And Lat-Lng Taken From City And State";
		}
//		if (comUrl.contains("https://www.brittonhomestexas.com/community/the-tribute-60")) {
//			add[1] = "The Colony";
//			add[2] = "TX";
//			latLng = U.getlatlongGoogleApi(add);
//			add = U.getAddressGoogleApi(latLng);
//			geo = "True";
//			notes = "Address And Lat-Lng Taken From City And State";
//		}
		// ============ Homes Htmls ===========
		String combinedHomeHtmls = ALLOW_BLANK;
	
		
		if (homeSection != null) {
			U.log("HELLOOO");
			/*String[] homeUrls = U.getValues(homeSection, "<a role=\"article\" about=\"", "\"");
			
			int x = 0;
			for (String homeUrl : homeUrls) {
				 U.log(homeUrl+"::::::::::::::::::::::::::::");
				String homeHtml = U.getPageSource("https://www.brittonhomestexas.com" + homeUrl);
				combinedHomeHtmls += U.getSectionValue(homeHtml, "<main role=\"main\"", "<div class=\"home-media");
//				if (x == 8)
//					break;
//				x++;
			}
			if(homeUrls==null||homeUrls.length==0) {*/
				String[] homeUrlSec = U.getValues(homeSection, "<div role=\"article\" about=\"", "\"");
				for(String homeUrl:homeUrlSec) {
					 U.log(homeUrl+"::::::::::::::::::::::::::::");
					String homeHtml = U.getPageSource("https://www.brittonhomestexas.com" + homeUrl);
				//	combinedHomeHtmls += U.getSectionValue(homeHtml, "Community Overview</h2>", "</p>");
					combinedHomeHtmls += U.getSectionValue(homeHtml, "<main role=\"main\"", "<div class=\"home-media");
				}
			//}
		}
		if (combinedHomeHtmls.length() > 4) {
			combinedHomeHtmls = combinedHomeHtmls.replaceAll("Stories\\s*</div>\\s*<div>\\s*", "Stories ");
		}
		// U.log("Home DATA: "+combinedHomeHtmls);
		// ============ Price ==================

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		nwRegSec=nwRegSec.replaceAll("0s|0's|0'S", "0,000");
		comSec = comSec.replace("0s", "0,000");
		if (desciptionSection != null)
			desciptionSection = desciptionSection.replace("0s", "0,000").replace("From the $1Ms", "From the $1,000,000");
		String[] prices = U.getPrices(desciptionSection + homeSection + comSec+ nwRegSec,
				"From the \\$\\d,\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|pricing-h4\">\\s*\\$\\d,\\d{3},\\d{3}|From the mid \\$\\d+,\\d+|From the( low |\\s)\\$\\d{3},\\d{3}|salesPrice\">\\$\\d{3},\\d{3}</div>|salesPrice\">\\$\\d{3},\\d{3}|pricing-h4\">\\s+\\$\\d{3},\\d{3}",
				0);

		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
	//	U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}770[\\s\\w\\W]{30}", 0));
		U.log("Price are :: " + minPrice + ":::::" + maxPrice);

		// ===========Square Feet===========
		String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;

		String[] sqFt = U.getSqareFeet(desciptionSection + homeSection + comSec+ nwRegSec,
				"\\d,\\d{3} - \\d,\\d{3} sq ft|-bit-text\">\\s*\\d,\\d+ - \\d,\\d+\\s*</div>| \\d,\\d{3} - \\d,\\d{3} sq ft|\\d{1},\\d{3} - \\d{1},\\d{3}   Sq.| \\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|sqftInfo\">\\d{4}|quick-bit-text\">\\s+\\d,\\d{3} sq ft",
				0);

		minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

		U.log("Sq feet are :: " + minSqFt + ":::::" + maxSqFt);

		// ============== Property Status =================
		
		

		String pStatus = U.getPropStatus((desciptionSection + comSec)
				.replaceAll("- Now Open|- Now Available|school just opened", ""));
		
//		U.log("mmmmmm"+Util.matchAll(comSec, "[\\w\\s\\W]{30}Now Available[\\w\\s\\W]{30}", 0));
//		U.log("mmmmmm"+Util.matchAll(desciptionSection, "[\\w\\s\\W]{30}Now Available[\\w\\s\\W]{30}", 0));
		
//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/statusssss.txt", comSec+desciptionSection);
		
		if (homeSection != null) {
			// U.log(homeSection);
			String moveInBanner = Util.match(homeSection, "READY FOR Move-In", 0);
			U.log("Banner:::" + moveInBanner);
			if (moveInBanner != null && !pStatus.contains("Move-In")) {
				if (moveInBanner.contains("Move-In")) {
					if (pStatus != ALLOW_BLANK)
						pStatus += ",Ready For Move-in";
					else
						pStatus = "Ready For Move-in";

				}
			}
		}
	
		U.log("Property Status:::::::::::::::" + pStatus);

		// =============== Property Type ==============
		if (desciptionSection != null)
			desciptionSection = desciptionSection.replaceAll("(V|v)illage", "");
		String pType = U.getPropType((desciptionSection + combinedHomeHtmls).replace("detached 2-story modern designs", "Detached Homes").replace("<a href=\"/gallery-of-homes/patios/\">Patios</a>",""));

		// ================ Community Type =============
		String cc = U.getSectionValue(html, "<script type=\"application/ld+json\">", "</script>");
		//U.log("gggggggggg> " + cc);
		
		//desciptionSection = desciptionSection.replace("sides of the community being lakefront, residents can enjoy", "");
		
		String comType = U.getCommunityType((desciptionSection + cc).replace("lakefront, residents", "lakefront community"));
		//U.log(">>>>>>>>>>>>"+Util.matchAll(cc, "[\\s\\w\\W]{30}lakefront[\\s\\w\\W]{30}", 0));
		U.log("comType> " + comType);
		// ============= Derived Type ================
		String dType = U
				.getdCommType((desciptionSection + homeSection + combinedHomeHtmls).replaceAll("Rancho|floor", ""));
		U.log("Derived property type:::" + dType);
		
		
		
		if(comUrl.contains("villas-at-legacy-west"))
		{
			pStatus=pStatus.replace("Final Opportunity", ALLOW_BLANK);
		}

		if(pStatus!=null)
			pStatus = pStatus.replace("Phase 2 Coming, Phase 2 Coming Fall 2021", "Phase 2 Coming Fall 2021");
		
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0], latLng[1].trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);

		}catch (Exception e) {}

	}

	// /Home-Details/SPEC
	public String getDataOfHomes(String comHtml) throws IOException {

		String combineHtml = ALLOW_BLANK;
		if (comHtml != null) {
			ArrayList<String> values = Util.matchAll(comHtml, "<div class=\"row marginLR-0\">\\s*<a href=\"(.*?)\"", 1);// U.getValues(comHtml,
																														// "<a
																														// style=\"z-index:
																														// 500;\"
																														// href=\"",
																														// "\"");

			U.log("Total Homes : " + values.size());
			for (String link : values) {

				link = "https://www.perryhomes.com/" + link;
				// U.log(link);
				U.log("Home Url: " + link);
				String hhtml = U.getHTML(link);
				combineHtml=combineHtml.replaceAll("gallery-of-homes/patios/\">Patios", "");
				combineHtml = U.getSectionValue(hhtml.replaceAll("<a href=\"/gallery-of-homes/patios/\">Patios</a>", ""), "<div id=\"HomeDescription", "</div>") + combineHtml.replaceAll("<a href=\"/gallery-of-homes/patios/\">Patios</a>", "");
				// U.log(combineHtml);
				if (combineHtml.contains("patio")) {
					U.log("found patio");
					break;
				}
			}
		}
		return combineHtml; 
	} 

}