/**
 * @author Sawan
 * @date 19/01/2017
 * 
 */
package com.shatam.b_041_060;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.*;
//import org.eclipse.jdt.internal.compiler.lookup.UpdatedMethodBinding;
import java.net.URL;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPlantationHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j = 0;
	static int dupli = 0;
	ArrayList<String> commList = new ArrayList<String>();
	CommunityLogger LOGGER;
	static WebDriver driver = null;
	private String baseUrl = "https://www.plantationhomes.com/";
	public static void main(String[] args) throws Exception {
		/*U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		Proxy p=new Proxy();
		p.setHttpProxy("108.162.192.0:18");
		DesiredCapabilities cap=new DesiredCapabilities();
		cap.setCapability(CapabilityType.PROXY, p);
		driver=new FirefoxDriver(cap);*/
		U.setUpChromePath();
		ChromeOptions options=new ChromeOptions();
		options.addExtensions(new File("/home/shatam-3/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		options.addArguments("–load-extension=" + new File("/home/shatam-3/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		DesiredCapabilities cap=new DesiredCapabilities().chrome();
		cap.setCapability(ChromeOptions.CAPABILITY, options);
		driver=new ChromeDriver(cap);
		AbstractScrapper a = new ExtractPlantationHomes();
		a.process();
//		a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"MHI-McGuyer Homebuilders - Plantation Homes.csv", a.data().printAll());
		U.log(dupli);
	}

	public ExtractPlantationHomes() throws Exception {

		super("MHI-McGuyer Homebuilders - Plantation Homes","https://www.plantationhomes.com/");
		LOGGER = new CommunityLogger("MHI-McGuyer Homebuilders - Plantation Homes");
	}

	public void innerProcess() throws Exception {
		
		
		String html = getHtml(baseUrl, driver);
		String regionSection = U.getSectionValue(html, ">Where We </span>Build ", "</ul>");
		String regionUrls[] = U.getValues(regionSection, "href=\"", "\">");
		for(String regionUrl : regionUrls){
			findCommunity(baseUrl+regionUrl);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	private void findCommunity(String regionUrl)throws Exception{
		U.log("RegionUrl::"+regionUrl);
		String regHtml = getHtml(regionUrl.replace(".com//", ".com/"),driver);
		String seccomList = U.getSectionValue(regHtml, "<div class=\"inventoryContainer whereWeBuild\">","</wherewebuild>");
		U.log(seccomList);
		String commSecs[] = U.getValues(seccomList, "div class=\"itemListing\"", "<div class=\"buttonContainer\">");
		for (String commSec : commSecs) {
			String comLink=U.getSectionValue(commSec, "<a href=\"", "\"");
			if (comLink==null) continue;
			U.log("comLink : "+comLink);
			if (comLink.endsWith("/communities")) {
				U.log("SUBREGION =====================================================================> :" + baseUrl+comLink);
				
				if((baseUrl+comLink).contains("dallas-ft-worth/parkside-west/communities"))continue;
				
				regHtml=getHtml((baseUrl+comLink).replace(".com//", ".com/"),driver);
				String subCommunitySec=U.getSectionValue(regHtml, "<div class=\"details highlightBox\">", "</ul>");
				String subCommSecs[]=U.getValues(subCommunitySec, "<li>", "</li>");
				for (String subCommSec : subCommSecs) {
					comLink=U.getSectionValue(subCommSec, "<a href=\"", "\"");
					U.log("--------------------------------------"+i+"---------------------------------------");
					U.log("Sub comLink=====================================================================> "+comLink);
					findCommunityDetails(baseUrl+comLink,subCommSec+commSec);
					i++;
					//break;
				}
			}else {
				U.log("--------------------------------------"+i+"---------------------------------------");
				//U.log(comLink);
				
				findCommunityDetails(baseUrl+comLink,commSec);
				
				i++;
			}
			//break;
		}
		U.log(i);
	}
	//TODO : Extract Communities details here
	private void findCommunityDetails(String comLink, String commSec)throws Exception{
//		if(!comLink.contains("/dallas-ft-worth/wildridge-60"))return;
//		if(j==4 )
		{
		String commHtml=getHtml(comLink, driver);
//		U.log(commSec);
		U.log("comSec=====================================================================> "+commSec);
		
		

		
		String commName=U.getSectionValue(commHtml, "<h1>", "</h1>");
		String n;
		U.log("ComName::::::::"+commName+"::::::::::::;");
		if(commName == null){
			commName =U.getSectionValue(commSec, "\">", "</a>");
		}
		String parentComName= U.getSectionValue(commHtml, "<span class=\"light\">", "</span>");
		if(parentComName!=null){
			
			parentComName=parentComName.replaceAll("<a id=\"project\">|</a>", "")
					.replaceAll("40'|50'|60'|70'|55'|65'","").replace(" &amp;", "").trim();
			
			if(!commName.startsWith(parentComName))commName=parentComName+" "+commName;
		}
		U.log("parentComName : "+parentComName+":");
		if(commName.contains("Unit"))
		{
			U.log("====================================================================================================================================0000000009999999999");
			commName="Kinder Ranch"+" "+commName;
		}
		commName=commName.replaceAll(" - Patio Homes|- Gated|- Traditional","");
		
		
		
		U.log("comName=========================================================================> "+commName);
		String mainSec=U.getSectionValue(commHtml, "<div class=\"contentWrapper\">", "</community>");
		
		//----------RemoveNearByCOmmunities--------
		commHtml = U.removeSectionValue(commHtml, "<h3>Nearby Communities</h3>", "<h3>Promotions");
		
		//---------Newz Section-----------
		commHtml = U.removeSectionValue(commHtml, "container featuredSliderContainer", "<div _ngcontent-c0=\"\" class=\"social\">");
		
		//-------------------------------------------------Address Latlon Sec---------------------------------
		String detailAddSec=U.getSectionValue(commHtml, "mapaddress", "</p>");
	
		U.log("detailsAddSec====================> "+detailAddSec);
		
		
		
		String latlonSec=null;
		String addSec=null;
		if(detailAddSec!=null){
				
			latlonSec=U.getSectionValue(detailAddSec, "?q=", "&amp;");
			 addSec=U.getSectionValue(detailAddSec,"<span class=\"fas fa-map-marker\">", "</a>");
				
				if (addSec==null)
				{
					addSec=U.getSectionValue(detailAddSec,"<span class=\"fa fa-map-marker\">","</a>");

				}
				if(latlonSec == null){
					String googleMapUrl = U.getSectionValue(detailAddSec, "href=\"", "\"");
					String googleMapHtml = U.getHTML(googleMapUrl);
//					FileUtil.writeAllText("/home/glady/filename_1.txt", googleMapHtml);
					latlonSec = Util.match(googleMapHtml, "USA/@(\\d{2}\\.\\d{3,},-\\d{2}\\.\\d{3,}),", 1);
				}
				
		}
		String latlon[]= {ALLOW_BLANK,ALLOW_BLANK};
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String note=ALLOW_BLANK;
		String geo="FALSE";
		if (latlonSec!=null) {
			latlon=latlonSec.split(",");
		}
		
	
//		addSec=addSec.replace("Visit our Plantation Homes model:<br>","");
//		addSec=addSec.replace("<span>Please visit us in Sienna Plantation","");
		if (addSec!=null) {
			addSec=addSec.replace("Visit our Plantation Homes model:<br>","");
			addSec=addSec.replace("<span>Please visit us in Sienna Plantation","");
			addSec =addSec.replace("Visit our sales office in Jordan Ranch:<br>", "");
			addSec=addSec.replaceAll("</span>|<span>", "").replace("<br>", ",");
			U.log("addSec" +addSec);
			add=U.getAddress(addSec);
			U.log(Arrays.toString(add));
		}
		
		
		
		String lat = latlon[0];
		String lng = latlon[1];
		U.log("::::::::::::"+lat+","+lng);
		if (add[0]==ALLOW_BLANK&&latlon[0]!=null&&latlon[0]!=ALLOW_BLANK)
		{
			if(!lng.contains("-"))
				lng="-"+lng;;
		//	add=U.getGoogleAddressWithKey(latlon);
				add=U.getBingAddress(lat, lng);
			geo="TRUE";
			U.log(Arrays.toString(add));
		}
//		U.log(add[0]);
		if(latlon[0].length()<4 && add[0].length()>4 ){
			latlon = U.getlatlongGoogleApi(add);
			lat=latlon[0];
			lng=latlon[1];
			geo="TRUE";
		}
		if(latlon[0].length()>4){
			add = U.getAddressGoogleApi(latlon);
//			lat=latlon[0];
//			lng=latlon[1];
			geo="TRUE";
		}
		
		//-------------------------------------------------PriceSec---------------------------------

		String price[]= {ALLOW_BLANK,ALLOW_BLANK};
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commHtml=U.removeSectionValue(commHtml, "{&q;G.https://app.mhinc.com/api/","</html>");
		commHtml=U.removeSectionValue(commHtml, "class=\"promoContainer container","</footer>");

		//U.log(commHtml);
		commHtml=U.removeSectionValue(commHtml, "<div class=\"calculatorResults\">","<div class=\"disclaimer\">");
		commHtml=U.removeSectionValue(commHtml, "<label>Mobile Phone</label>","<p><input class=\"button full\" name=\"submit\" value=\"Send\" type=\"submit\"></p>");
		mainSec=mainSec.replace("0's", "0,000").replace("$1.05 Million", "$1,050,000 Million");
		commHtml = commHtml.replaceAll("Up to \\$\\d+,\\d+ in savings on move-in ready homes", "");
		String remSec=U.getSectionValue(commHtml,"<h3>Nearby Communities</h3>", "<div class=\"tabItem mediumWeight\" data-id=\"content_promotions\">");
		//U.log(remSec);
		if (commName.contains("Signature Series")) {
			commSec=commSec.replace("From the $200's |", "$200,000</div>");
		}else if (commName.contains("Executive Series")) {
			commSec=commSec.replace("$250's</div>", "$250,000</div>");
		}
		if(remSec!=null)
			commHtml=commHtml.replace(remSec,"");
		//mainSec=mainSec.replace("From the $380's", "From the $380,000");
		commHtml=commHtml.replace("0's","0,000").replace("$1.05 Million","$1,050,000 Million").replaceAll(" value=\"\\$\\d{3},\\d{3} \\+\">\\$\\d{3},\\d{3} \\+</option>|value=\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\">\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</option>|<span class=\"strikethrough\">\\$\\d{3},\\d{3}</span>", "");
		//U.log(commHtml);
		price=U.getPrices(commHtml+commSec,"\\$\\d{3},\\d{3}</div>|<div class=\"price\"> \\$\\d{3},\\d{3}</div>|\\$\\d{1},\\d{3},\\d{3} Million|From \\$\\d{1},\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		//-----------------------------------------------Sqft-----------------------------------------
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(mainSec+commSec,
				"\\d{4} to \\d{4} sq. ft.|\\d{4} to \\d{4} Sq.Ft.|\\s+\\d{4} sqft\\s+", 0);
		
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("Min Sq :" + minSqf + " Max Sq :" + maxSqf);
		
		
		//---------------------------------------com type---------------------------------
		commHtml=commHtml.replaceAll("country club|Country Club|pools including a gated toddler pool|Fair Oaks Ranch Golf and Country Club| office in Jordan Ranch", "");
		String Type = U.getCommunityType(commHtml);
		U.log(Type);
		
		//------------Derived Type-----------------

		String dPropType = U.getdCommType(commHtml+commSec) ;
		U.log(dPropType);
		//--------------------property type----------	
		//U.log(commSec);
		//commSec.replace("<div class=\"movein\">","");
		String proptype;
		
	
		commHtml=commHtml.replaceAll("Estimated dues|content=\"New homes for sale|<title>New Homes for Sale|content=\"The new homes for sale|Homeowner Services</a></span>|homeowners association fees|feedback of every homeowner|Chinese \\(Traditional","");
		//U.log(commHtml);
		commSec=commSec.replace("New Model Now Open\\!", "");
		proptype = U.getPropType(commHtml+commSec);
		commHtml=commHtml.replace("Now Selling in Final Section", "Now Selling Final Section");
		//---------------------prop status----------------
		String propStatus = ALLOW_BLANK;
		commSec=commSec.replace("Close-Out Specials!","Close-Out");
		commSec=commSec.replace("now Selling Functional","Now Selling")
				.replace("New Community Coming Soon", "");
		commHtml=commHtml.replaceAll("about the new homes available|New Model Now Open\\!| Elementary, now open,|Explore the new homes available from Plantation|now available in the popular|under construction or ready for move-in|before the community's Grand Opening|in savings on move-in ready homes|New Community Coming Soon!|receive Grand Opening and |Coming Soon Contact|Grand Opening Event|Grand Opening and Sales|Coming Soon Contact|is now open in the Prosper community|Edgestone at Legacy Now Open|Home Now Open in Star Trail|Coming May 2018!|<div class=\"movein\">|\"bannerHeadline\">Move-In Ready Homes Available!|\"movein\"><span>|now open!|new homes available in Pomona|new homes available in the prestigious|new homes available in Grand Mesa at Crystal|grand opening of its newest Aus...|oversized lots available|Backyard (- )?Coming Spring|Additionally, coming","");

		propStatus=U.getPropStatus(commHtml+commSec).replace("Ii","i");
		if(comLink.contains("https://www.plantationhomes.com//houston/villasatkingsharbor"))commName="Villas At King Harbor";
		if(comLink.contains("https://www.plantationhomes.com//dallas-ft-worth/churchtract"))commName="Parkside East Homesites";
		note=U.getnote(commHtml.replace("content=\"The new homes for sale|", ""));
		if(comLink.contains("firethorne")) {
			add[1]="Katy";
			add[2]="TX";
			add[3]="77494";
			latlon=U.getlatlongGoogleApi(add);
			lat=latlon[0];
			lng=latlon[1];
			add[0]=U.getAddressGoogleApi(latlon)[0];
			geo="TRUE";
			note="Address take from City,State & Zip";
		}
		if(data.communityUrlExists(comLink)) {
			LOGGER.AddCommunityUrl(comLink+":::::::::::::::::::::::::::::::repeated");
		}
		LOGGER.AddCommunityUrl(comLink);
		data.addCommunity(commName, comLink.replace("com//", "com/"), Type);
		data.addAddress(add[0],add[1],add[2],add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(proptype, dPropType);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		}
		j++;
	}
		
	
	private static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;
		
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					Thread.sleep(15000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
//			driver.quit();
			return html;

		}

		// else{
		// return null;
		// }
	}

}


