/** @author Rakesh Chaudhari
 *   
 */

package com.shatam.b_041_060;

import java.io.IOException;
import java.util.ArrayList;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRoyalOakHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractRoyalOakHomes();
		//U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"AV Homes - Royal Oak Homes.csv", a
				.data().printAll());
	}

	public ExtractRoyalOakHomes() throws Exception {

		// super("Avatar Holdings", "http://www.avatarhomes.com/"); Change to
		// BElow NAme
		super("AV Homes - Royal Oak Homes ", "http://www.royaloakhomesfl.com/");
		LOGGER = new CommunityLogger("AV Homes - Royal Oak Homes");
	}

	public void innerProcess() throws Exception {

		String htm = U.getHTML("http://www.royaloakhomesfl.com/");
		String communitySection = U.getSectionValue(htm,
				"find a community</a>", "</ul>");

		String sec[] = U.getValues(communitySection, "<li><a href=\"", "\"");

		for (String item : sec) {
			//U.log(item);
			item = "http://www.royaloakhomesfl.com" + item;
			String html = U.getHTML(item);
			String[] urlsec = U.getValues(html,
					"<td class=\"title\"><a class=\"scalable-this\" href=",
					"/a>");
			if (item.contains("florida-new-home-communities"))
				continue;
			addDetails(item);
			inr++;
			// i++;
			// break;
		}

		LOGGER.DisposeLogger();
	}

	private String getDerivedTypeHtml(String commUrl) throws IOException {
		String html = U.getHTML(commUrl);
		String homes[] = U.getValues(html, "<h4><a href=\"", "\"");
		String combineHtml = ALLOW_BLANK;
		for (String link : homes) {

			link = "http://www.royaloakhomesfl.com" + link;
			U.log("Fetching Page:   " + link);
			combineHtml = combineHtml + U.getHTML(link);
		}

		return combineHtml;

	}

	private void addDetails(String url) throws Exception {
		//if(!url.contains("http://www.royaloakhomesfl.com/community-overview-spring-ridge-estates"))return;
		
	//if(i==1)
	{
		U.log("\nPage:" + url);
		String htm = U.getHTML(url);

		// Comm Name
		String commName = U.getSectionValue(htm, "<h3>", "</h3>");

		
		commName = commName.replaceAll("#|\\d+|;|&|\\.| by AV Homes| - NOW SELLING!", "");
		U.log(commName);

		// Address
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		// U.log(htm);
		String sectionaddress = U.getSectionValue(htm, "\"address\":",
				"\\t\\t\"");

		sectionaddress = sectionaddress.replaceAll("\\\\t\\\\t\\\\t\\\\t|\"",
				"");
		add = U.getAddress(sectionaddress);

		U.log("street :" + add[0] + " city :" + add[1] + " state:" + add[2]
				+ " Zip:" + add[3]);

		// Lat Long
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;

		String sectionLatLng = U.getSectionValue(htm, "\"coords\":[\"", "\"]");
		sectionLatLng = sectionLatLng.replaceAll("\"", "");
		String latLng[] = sectionLatLng.split(",");
		lat = latLng[0] != null ? latLng[0] : ALLOW_BLANK;
		lng = latLng[1] != null ? latLng[1] : ALLOW_BLANK;

		U.log("Lat :" + lat + "  Long :" + lng);

		// Price Section

		// quick Move Homes

		String quickMove = url.replace("community-overview-", "")
				+ "-available-homes";
		U.log("Quick Move:  " + quickMove);
		String quickHtml = U.getHTML(quickMove);
		quickHtml = quickHtml.replaceAll("&#36;", "");
		String avlurl=url+"-floorplans";
		
		
		
		
		
		avlurl=avlurl.replace("community-overview-", "");
		U.log(avlurl+")))))))))");
		String avlhtml=U.getHTML(avlurl);
		// Get the data from floor Plans..
		String floorHtml=ALLOW_BLANK;
		String subFloor=U.getSectionValue(avlhtml," <div style=\"position:relative;","<img src=\"/");
		U.log("subFloor:::::::::::::::"+subFloor);
		if(subFloor!=null){
		String floorVals[]=U.getValues(subFloor," <a href=\"","\">");
		for(String floorVal:floorVals){
			floorVal="http://www.royaloakhomesfl.com"+floorVal;
			floorHtml=U.getHTML(floorVal);
			floorHtml=floorHtml.replace("luxurious master bath","");
			floorHtml=floorHtml.replace("luxurious master","");
		}
		}
		String floorLinksSection = U.getSectionValue(htm,
				"Community Overview</a></li>", "</ul>");
		String links[] = U.getValues(floorLinksSection, "<a href=\"", "\">");
		String floorPlanCom = ALLOW_BLANK;
		for (String link : links) {
			// http://www.royaloakhomesfl.com/community-directions-waterview-by-av-homes
			
			if (!(link.contains("community-map") || link
					.contains("community-directions"))){
				U.log("Fetching:  " + "http://www.royaloakhomesfl.com" + link);	
				floorPlanCom = floorPlanCom
						+ U.getHTML("http://www.royaloakhomesfl.com" + link);
			}

		}
	
		htm=htm.replace("&#36;", "$").replace("0s","0,000").replace("0's", "0,000");
		avlhtml=avlhtml.replace("&#36;", "$");
		quickHtml=quickHtml.replace("&#36;", "$");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String secPrice[] = U
				.getPrices(
						quickHtml+avlhtml+htm,
						"<h4>\\s+\\d+,\\d+|From:</span> \\$\\d+,\\d+ - \\$\\d+,\\d+<br />|\\$[0-9]{3},[0-9]{3}</h4>|\\$[0-9]{3},[0-9]{3} - \\$[0-9]{3},[0-9]{3}|\\$[0-9]{3},[0-9]{3}",
						0);
		minPrice = (secPrice[0] == null) ? ALLOW_BLANK : secPrice[0];
		maxPrice = (secPrice[1] == null) ? ALLOW_BLANK : secPrice[1];
		U.log("minPrice :" + minPrice + "  MaxPrice :" + maxPrice);

		// Square Feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String secsqFt[] = U
				.getSqareFeet(
						htm + quickHtml+avlhtml,
						"\\d,\\d+ to \\d,\\d+ sq. ft|\\d,\\d+ square feet|Sq. Ft. Range: </span>\\d,\\d+-\\d,\\d+<br/>|Living Area:</span> \\d,\\d+|</span> [0-9]{1},[0-9]{3}</h5>|[0-9]{1},[0-9]{3} to over [0-9]{1},[0-9]{3} square feet",
						0);

		minSqf = (secsqFt[0] == null) ? ALLOW_BLANK : secsqFt[0];
		maxSqf = (secsqFt[1] == null) ? ALLOW_BLANK : secsqFt[1];
		U.log("minSQF :" + minSqf + "  MaxSQF :" + maxSqf);

		String pStatus = ALLOW_BLANK;
		String statSec = htm;
		String badProStatus = U.getSectionValue(htm, "From The Blog</h3>",
				"Visit Blog");
		statSec = statSec.replace(badProStatus, "");
		String remove = "\">william&#39;s preserve - now selling|Ardmore Pool Grand Opening|now open|Grand Opening Prices|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|<strong> NOW open 7 days|Information Center NOW OPEN|Quick Move-Ins|quick move|Quick Move|Models opening soon!";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
//		U.log(statSec+"********");
		pStatus = U.getPropStatus(statSec.replaceAll("-sold-out\">|- sold out</a></li>|under construction|now selling from|breckenridge(-|\\s)close-out|close-out pricing", ""));
		//U.log("$$$$$$$$$$$$$"+Util.match(statSec, ".*?Now Selling.*?"));
		if (add[1].length() > 30)
			add[1] = ALLOW_BLANK;
		if (add[2].length() > 2)
			add[2] = ALLOW_BLANK;
		geo = "FALSE";

		if (add[0] == ALLOW_BLANK && lat != ALLOW_BLANK) {

			add = U.getAddressGoogleApi(new String[] { lat, lng });
			geo = "TRUE";
		}

		if (quickHtml != null	&& !quickHtml	.contains("There are no available homes found at this time")) {
			if (pStatus != ALLOW_BLANK) {
				pStatus = pStatus + ", Quick Move-Ins";
			}else
				pStatus = "Quick Move-Ins";
		}

		if (pStatus.length() < 3)
			pStatus = ALLOW_BLANK;

		htm = htm.replace("golf courses,", "");
		add[0] = add[0].replace(".", "");
		add[0]=add[0].replace("(GPS)", "").replace("(GPS Address)", "");
		// htm = htm.substring(beginIndex
		String note=U.getnote(htm);
		
		htm=htm.replace("55+", "");
		String comType = U.getCommunityType(htm.replaceAll("Resort and has convenient|Newest Resort", ""));
		String combineHtml = getDerivedTypeHtml(quickMove);
		String dType = U.getdCommType((htm + floorPlanCom+floorHtml).replaceAll("Village|village", ""));
		String lati[]={ALLOW_BLANK,ALLOW_BLANK};
	
		//U.log( Util.match(floorPlanCom, ".*?HOA.*?"));
		String ptype = U.getPropType((htm+floorPlanCom+floorHtml).replaceAll(
				"Winter Garden Home|Living: Heritage Run Townhomes|townhomes\">Emerald Lake Townhomes|Patio3|patio3|townhomes\">Heritage Run Townhomes", ""));
		U.log(commName);
		if(url.contains("http://www.royaloakhomesfl.com/community-overview-hammock-trails"))pStatus="Phase 2 Now Open";
		commName=commName.replaceAll("Townhomes$|- Sold Out","");
		
		//Quick Move-Ins
		if(!pStatus.contains("Quick Move")){
			if(pStatus == ALLOW_BLANK) pStatus ="No Quick Move-Ins";
			else if(pStatus != ALLOW_BLANK) pStatus = pStatus+", No Quick Move-Ins";
		}
		
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(commName.trim(), url, comType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(ptype, dType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
	}
	i++;
	}
}
