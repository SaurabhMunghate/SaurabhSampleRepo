package com.shatam.b_041_060;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTheVillages extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int count = 0;
	static int repeat = 0;
	HashMap<String, String> series = new HashMap<>();

	public ExtractTheVillages() throws Exception {
		super("The Villages of Lake Sumter", "https://www.thevillages.com");
		LOGGER = new CommunityLogger("The Villages of Lake Sumter");
	}

	@Override
	protected void innerProcess() throws Exception {
		/**
		 * Open this url => https://www.thevillages.com/homefinder
		 * find file name '.ws?v=5&ns=the-villages-app'  in network
		 * Copy content from 'Messages' and paste into villageMain.txt	
		 */
		String consoleJsonFile = FileUtil.readAllText(U.getCachePath() + "villageMain.txt");
		String seriesHtml=U.getHTML("https://www.thevillages.com/homefinder/assets/series/series.json");
		String [] series_data=U.getValues(seriesHtml, "{", "}");
		U.log("LLLLLLLLL===="+series_data.length);
		for(String series_Data : series_data) {
//			U.log("series_data==="+series_Data);
			String key=U.getSectionValue(series_Data, "\"alt\": [", "]").replace("\",\"", ", ").replace("\"", "");
			key=key.replace("Keys Villa, Savannah Villa, Bungalow Villa, Cabana Villa", "Keys Villa");
			U.log("key :" + key);
			String value=U.getSectionValue(series_Data, "\"description\": \"", "\"");
			if(key!=null)
				
			series.put(key.replace("\"", ""), value);
//			break;
		}
		U.log("comm_Key :" + series.size());
//		String attributesSecs[] = U.getValues(consoleJsonFile, "\"-", "VirtualTourId");
		String attributesSecs[] = U.getValues(consoleJsonFile, "\"-", "VLSNumber");
		U.log(attributesSecs.length);
		for (String attributeSec : attributesSecs) {
			addDetails(attributeSec);
			// break;
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String attributeSec) throws Exception {
//		 try {

		String urlKey = U.getSectionValue(attributeSec, "\"ULIKey\":\"", "\"");
		String communityUrl = "https://api.thevillages.com/hf/search/homedetail?uliKey=" + urlKey;
//		 U.log("======================="+urlKey);
		
		
		
		//TODO : For Single comm. execution
//		if(!communityUrl.contains("S136V.55"))return;
		
		if(urlKey!=null)
//	if(count >=150)
		{   //||urlKey.equals("M839.1")||urlKey.equals("M839.2")||urlKey.equals("M839.3")
			if (urlKey.equals("L31.36")||urlKey.equals("https://api.thevillages.com/hf/search/homedetail?uliKey=S1")||urlKey.equals("S15V.37")|| urlKey.equals("S725.40") || urlKey.equals("L10.2248")
					|| urlKey.equals("S144.38") || urlKey.contains("S143.86") || urlKey.contains("S820.	16383")) {
				LOGGER.AddCommunityUrl(
						"https://www.thevillages.com/HomeFinder/Results/detail/" + urlKey + "  ====Returned");
				return;
			}
			U.log("count======"+count);
			attributeSec=attributeSec.replaceAll("\\s*16384\\s*10:30:08.846\\s*", "");
			U.log("attributeSec====="+attributeSec);
			U.log(U.getCache(communityUrl));
			U.log("comUrl :" + communityUrl);
			String communityHtml = U.getHTML(communityUrl);
//			U.log("CACHE::::"+U.getCache(communityUrl));
			String comm_Key=U.getSectionValue(communityHtml, "\"Series\":\"", "\"");
			U.log("comm_Key :" + comm_Key);
			if(comm_Key.contains("Savannah Villa") || 
					comm_Key.contains("Bungalow Villa") ||
					comm_Key.contains("Cabana Villa") ) 
			{
				comm_Key=comm_Key.replace(comm_Key, "Keys Villa");
			}
			
			
			if(series.containsKey(comm_Key)) {
//				String a=series.get(comm_Key);
//				U.log("sssss==="+a);
				communityHtml=communityHtml+series.get(comm_Key);
			}
//			U.log(communityHtml);
			if (communityHtml == null) {
				LOGGER.AddCommunityUrl("https://www.thevillages.com/homefinder/Results/detail/" + urlKey + "  ==== URL Not open");
				return;
			}
//			U.log("communityHtml=="+communityHtml);
//			if(communityHtml.contains("IsError\":true")) {
//				
//				LOGGER.AddCommunityUrl("https://www.thevillages.com/homefinder/Results/detail/" + urlKey + "  ==== URL Not open");
//				return;
//			}
			
			String communityName = U.getSectionValue(attributeSec, "\"Model\":\"", "\",");
			if (communityName==null)
				communityName = U.getSectionValue(communityHtml, "\"Model\":\"", "\",");
			U.log("communityName :"+communityName);
			if (communityName==null || communityName.isEmpty()) {
				LOGGER.AddCommunityUrl(
						"https://www.thevillages.com/HomeFinder/Results/detail/" + urlKey + "  ====Returned");
				return;
			}
			communityName=communityName.replace("Lantana-4 bed / Ivy", "Lantana");
			U.log("Communnity Name:--" + communityName);
//			U.log("attributeSec-111====="+attributeSec);

			communityName=communityName.replace("Whispering Pine\"	16384	\n" + 
					"00:59:11.936\n" + 
					",\"OpenHouse\":{\"End\":\"", "Whispering Pine");

			communityUrl = communityUrl.replace("https://api.thevillages.com/hf/search/homedetail?uliKey=",
					"https://www.thevillages.com/HomeFinder/Results/detail/");
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			add[0] = (U.getSectionValue(attributeSec, "Address\":\"", "\",") != null)
					? U.getSectionValue(attributeSec, "Address\":\"", "\",")
					: ALLOW_BLANK;
			add[0] = U.getCapitalise(add[0].toLowerCase());
			add[1] = "The Villages";
			add[2] = "FL";
			add[0] = add[0].replaceAll("Undisclosed Address", "");
			U.log(add[0] + "\t" + add[1] + "\t" + add[2]);
			add[0]=add[0].replace("4113 Sil 16384 19:29:10.980 Vana Way", "").replace("387 16384 19:29:10.937 Naragansett Ct", "").replace("4954 Okahumpka Run 16384 09:47:27.123", "4954 Okahumpka Run").replace("4544 16384 09:47:27.163 Whittington Cir", "4484  Whittington Cir").replace("76 16384 00:59:12.013 6 Santa Fe St","Santa Fe St").replace("1 16384 09:47:26.727 585 Blythewood Loop","1585 Blythewood Loop");
			
			if(add[1].contains("The Villages"))add[3]="32162";
			if(add[1].equals("The Villages") ){
				if(add[3]==null)add[3]="32162";
			}
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			if(attributeSec!=null) {
				attributeSec=attributeSec.replaceAll("\\d{4,}\\s*\\d{2}:\\d{2}:\\d{2}\\.\\d{3,}", "");
			}		
			
			attributeSec=attributeSec.replace("Lat\":", "GISLat\":");
			
			latLng[0] = U.getSectionValue(attributeSec, "GISLat\":", ",").trim();
			try {
			latLng[1] = U.getSectionValue(attributeSec, "GISLong\":", ",").trim();
			}
			catch(NullPointerException ne) {
				latLng=U.getlatlongGoogleApi(add);
			}
			U.log("latlong :: "+latLng[0] + "\t" + latLng[1]);
			
			
			
			if(latLng[0] != null) latLng[0] = latLng[0].replaceAll("\\s+", "");
			if(latLng[1] != null) latLng[1] = latLng[1].replaceAll("\\s+", "");
			
			if(latLng!=null && latLng[0].contains("28.7858615"))latLng[0]="28.7858615";
			if(communityName.contains("Gardenia")) {
				latLng[1]="-81.94334786";
			}
			
			if(communityUrl.contains("S56V.63")) {
				add[0]="585 Robert Road";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("S56V.98")) {
				add[0]="594 Coker Court";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("S53V.39")) {
				add[0]="406 Gilson Loop";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("S56V.125")) {
				add[0]="578 Robert Road";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("S817.41")) {
				add[0]="1781 Foliage Ln";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("S56V.124")) {
				add[0]="572 Robert Road";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("S53V.40")) {
				add[0]="402 Gilson Loop";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
//			U.log("attributeSec-2222====="+attributeSec);
			if(communityUrl.contains("S65V.18")||communityUrl.contains("S65V.15")||communityUrl.contains("S65V.14")||communityUrl.contains("S55V.51")||communityUrl.contains("S55V.50")||communityUrl.contains("S55V.49")||communityUrl.contains("S55V.35")||communityUrl.contains("S55V.33")||communityUrl.contains("S55V.8")||communityUrl.contains("S56V.52")||communityUrl.contains("S56V.126")||communityUrl.contains("S817.43")||communityUrl.contains("S56V.103")||communityUrl.contains("S56V.102")||communityUrl.contains("S56V.61")||communityUrl.contains("S56V.62")||communityUrl.contains("S56V.116"))add[3]="32162";
			//			String url = "http://dev.virtualearth.net/REST/v1/Locations/" + latLng[0] + "," + latLng[1]
//					+ "?o=json&jsonp=GeocodeCallback&key=Anqg-XzYo-sBPlzOWFHIcjC3F8s17P_O7L4RrevsHVg4fJk6g_eEmUBphtSn4ySg";
//			U.log(U.getCache(url));
//			String htm = U.getHTML(url);
//			U.log(htm);
//			if (htm.contains("\"postalCode\":\"")) {
//				add[3] = U.getSectionValue(htm, "\"postalCode\":\"", "\"");
//				U.log("hello");
//			} else {
//				add[3] = U.getBingAddress(latLng[0], latLng[1])[3];
//				if (add[3].length() < 4) {
			if((latLng[0].startsWith("28.78") ||latLng[0].startsWith("28.81")|| latLng[0].startsWith("28.79") || latLng[0].startsWith("28.80")) 
					&& (latLng[1].startsWith("-81.98")||latLng[1].startsWith("-82.01") || latLng[1].startsWith("-81.99") || latLng[1].startsWith("-82.02") || latLng[1].startsWith("-82.03")))
				add[3] = "34785";
			
			if ((latLng[0].contains("28.79")||latLng[0].contains("28.78")||latLng[0].contains("28.80")||latLng[0].contains("28.81")) && (latLng[1].contains("-82.01")||latLng[1].contains("-82.00")||latLng[1].contains("-81.97"))) {
					add[3] = "34785";
			} else {
				if(add[3].length() < 2){
					
					String[] add1 = U.getAddressGoogleApi(latLng);
					U.log(Arrays.toString(add1));
					if(add1 == null)
						add1 = U.getGoogleAddressWithKey(latLng);
					if(add1 == null)
						add1 = U.getAddressHereApi(latLng);
					
					if(add1[3] == ALLOW_BLANK){
						add1 = U.getAddressHereApi(latLng);
					}
					add[3] = add1[3];
					if(add[0].isEmpty() || add[0] ==ALLOW_BLANK || add[0]==null || add[0].length()<3)
						add[0] = add1[0];
					add1 = null;
				}
/*						add[3] = U.getAddressGoogleApi(latLng)[3];
						add[3] = U.getGoogleZipFromAddressWithKey(add);
						add[3]=ALLOW_BLANK;
*/					}
//					add[3]=add[3]==null?ALLOW_BLANK:add[3];
//				}
//			}
			U.log(add[0].contains("FL-91"));
			if(add[0].contains("FL-91") && add[1].contains("Wildwood") && add[2].contains("FL")) {
				U.log("i am in");
				add[3]="34785";
			}
			
//			U.log("attributeSec-333====="+attributeSec);
			if(add[0].length()==0 || add[0]==ALLOW_BLANK || add[0].toString().trim().equals("-")) {
				add = U.getAddressHereApi(latLng);
			}
			U.log("***** ZIP *****" + Arrays.toString(add));
			// add[3] = U.getBingAddress(latLng[0], latLng[1])[3];

			String geoCode = "TRUE";
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			communityHtml = communityHtml.replaceAll("\"Price\": \"\\$\\d{3},\\d{3}|\"SquareFeet\":1932,", "");
			String prices[] = U.getPrices(communityHtml + attributeSec,
					"CurrentPrice\":\"\\$\\d,\\d+,\\d+|\"CurrentPrice\":\"\\$\\d+,\\d{3}\"", 0);
			minPrice = (prices[0] != null && prices[0] != ALLOW_BLANK) ? prices[0] : ALLOW_BLANK;
			maxPrice = (prices[1] != null && prices[1] != ALLOW_BLANK) ? prices[1] : ALLOW_BLANK;
			U.log(Arrays.toString(prices));
//			U.log("MMMMMMM "+Util.matchAll(communityHtml  , "[\\s\\w\\W]{5}299,900[\\s\\w\\W]{50}", 0));
//			U.log("MMMMMMM "+Util.matchAll(attributeSec  , "[\\s\\w\\W]{5}299,900[\\s\\w\\W]{50}", 0));
			
//			U.log("attributeSec====="+attributeSec);
			communityHtml = communityHtml.replaceAll("\\d+ square feet of garage space", "");
			String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
			String Sqfts[] = U.getSqareFeet(communityHtml + attributeSec,
					"almost \\d{4} sq\\. ft\\.|\\d{4} square feet|\"SquareFeet\":\\d{4},|\"SquareFeet\":\\d{4},|\"SquareFeet\":\\d{3},", 0);

//			U.log("MMMMMMM "+Util.matchAll( attributeSec  , "[\\s\\w\\W]{50}3700[\\s\\w\\W]{50}", 0));

			
			U.log(Arrays.toString(Sqfts));
			minSqFeet = (Sqfts[0] != null && Sqfts[0] != ALLOW_BLANK) ? Sqfts[0] : ALLOW_BLANK;
			maxSqFeet = (Sqfts[1] != null && Sqfts[1] != ALLOW_BLANK) ? Sqfts[1] : ALLOW_BLANK;
			
			communityHtml = communityHtml.replace("STUNNING WATERFRONT POOL HOME", "STUNNING Waterfront Community POOL HOME")
					.replaceAll("Stunning waterfront, expanded|Water Front View", "WaterFront Community").replace("Golf & Water Front", "Golf & WaterFront community");
			
			
			String commType = U.getCommunityType((communityHtml).replaceAll("discover executive golf|golf car ride away|Area to play a round of golf|golf, swimmin|Golf Car", ""));
			

			U.log("commType: "+commType);

			communityHtml = communityHtml
					.replace("tiled roof (coming soon)", "")
					.replace("Barrel Tiled roof (coming soon)", "")
					.replace("Oversized Homesite", "oversized homesites available ").replace("MOVE-IN-READY", "MOVE-IN READY")
					.replaceAll("Roof is coming|olony Cottage Recreation|Roof Coming|area coming|[p|P]ublix [n|N]ow [o|O]pen|Great Location and Ready to Move|This home is move-in ready|move-in ready cottage|Edgewater Bungalows Gate|some cabin fever|[c|C]abinets|Cabinetry|ready to move|Ready to move in|house coming|move in day|Connection \\(coming |Center will be opening|center coming", "");

			
			String propertyStatus = U.getPropStatus(communityHtml
					.replace("including the NOW OPEN Sawgrass Grove just", "")
					.replaceAll("Barrel Tiled roof (coming soon)|A new roof is coming in 2022|spectacular home that is READY to move into then please call|the new Sawgrass which is opening soon where you will have an abundance|entertainment and amazing eateries opening soon|fantastic neighborhood, but is also MOVE-IN Ready|you will find a clean move in ready home|MOVE-IN READY|Sawgrass Grove and market coming soon|the coming soon Sawgrass Grove Market|shutters coming soon|oversized homesites|e Newest Coming Soon Town Square|\"oversized homesites|\"oversized homesites available \"|NOW OPEN Magnolia Shopping|Publix is Now Open|Publix Now Open|center \\(coming early 2021|will be opening soon|coming soon to the South|roof is coming soon|Roof Coming Soon|Golf Course and comes move-in ready|but now available|roof coming|this move-in|Center and coming soon|(Center|Roof|pictures|mention|video|those|Center and) (c|C)oming|-coming this summer-which|coming soon Magnolia Plaza|(ROOF|Plaza) (COMING|coming|\\(coming)|opportunities for meal|soon Magnolia|more at the coming soon Sawgrass", ""));

			U.log("propertyStatus: "+propertyStatus);
//			U.log("MMMMMMM "+Util.matchAll(communityHtml , "[\\s\\w\\W]{50}Now Open[\\s\\w\\W]{50}", 0));
			String proData=checkProp.get(communityName.toLowerCase().trim());
			
			//U.log("==============="+Util.match(communityHtml + attributeSec, "[\\s\\W\\w]{30}cottage[\\s\\W\\w]{30}", 0));
			communityHtml = communityHtml.replace("Bungalow Villa","Bungalow Series and villas").replace("traditional elegance","Traditional Style Homes")
					.replace("Cottage Villas", "Cottage Villas Homes").replace("Designer Villas", "Designer Villas homes").replace("Savannah Villa", "Villa homes:").replace("Villa:", "Villas homes");
//			U.log("MMMMMMM "+Util.matchAll(communityHtml , "[\\s\\w\\W]{50}Villa[\\s\\w\\W]{50}", 0));

			String propType = U.getPropType((communityHtml+proData).replaceAll("Weston Manor Dr|Villages|VillageDescription|village|Village|thevillages", ""));

			U.log("propType: "+propType);
			
			communityHtml = communityHtml.replace("first-floor benefits", " Story 1 ")
					.replaceAll("counter tops w/trending single level counter|entertaining with plentiful one level counter space", "");
			String dtype = U.getdCommType((communityHtml+proData).replaceAll("Ranchero|multi-level deck| popular one level counter|one level high definition laminate |single level counter top| one level quartz", ""));
			U.log("dtype: "+dtype);
			String note = U.getnote(communityHtml);
			U.log("note: "+note);
			maxPrice =ALLOW_BLANK;
//			if (communityName == null) {
//				LOGGER.AddCommunityUrl(count + " " + communityUrl + "**********No Community Name***********s");
//				repeat++;
//				return;
//			}
			if (this.data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl(count + " " + communityUrl + "***********repeated***********");
				repeat++;
				return;

			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S800.6")) {
				add[0]="991 Buster Pl";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S817.33")) {
				add[0]="1829 Foliage Ln";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S817.65")) {
				add[0]="1796 Foliage Ln";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/M215.9")) {
				add[0]="9341 SE 172nd Garden St";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/M215.28")) {
				add[0]="9370 SE 173rd Hyacinth St";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/M215.35")) {
				add[0]="9316 SE 173rd Hyacinth St";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/M215.82")) {
				add[0]="9347 SE 173rd Hyacinth St";
				add[1]="The Villages";
				add[2]="FL";
				add[3]="32162";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S6F.48")||communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S6F.104"))commType+=", Waterfront Community";
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S83V.28"))add[0]="5507 Br 16384";
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S211.131")) {
				add[0]="2969 Kuzman 16384";
				propType="Custom Home";
			}
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S127.214"))add[0]="2 Alora St";
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S86V.17")) {
				add=U.getAddressGoogleApi(latLng);
			}
			 if(communityUrl.contains("S32.13"))dtype = "Split Level";
			
			propertyStatus = propertyStatus.replace("makes this home move-in ready", "").replaceAll("Move In Ready Home|Move-in Ready Homes", "Move-in Ready");
			if(communityUrl.contains("S18V.24") || communityUrl.contains("S31V.70"))minPrice=ALLOW_BLANK;
			communityName=communityName.replace("\"	,\"OpenHouse\":{\"End\":\"", "").replace("IVY/LANTANA-4", "Ivy/Lantana-4").replace("PARADISE FOUND III", "Paradise Found III");
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S717.37")) {
			add[0]="1063 Burnettown Pl";
			add[1]="The Villages";
			add[2]="FL";
			add[3]="32162";
		}
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S717.60")) {
			add[0]="2289 Swansea Terrace";
			add[1]="The Villages";
			add[2]="FL";
			add[3]="32162";
		}

		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S50V.54"))add[0]="805 Joyce Ln";
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S47V.125"))propType="Executive Style Homes";
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/M232.39"))propType+=", Bungalow Style Homes";
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S19V.63"))propType="Luxury Homes";		
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S31V.67"))commType="Waterfront Community";
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S20V.10"))commType+=", Waterfront Community";
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/S966.87"))propType+=", Courtyard Home";
		if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/L31.58"))propType+=", Traditional Homes";

		if(communityUrl.contains("L6.746"))maxSqFeet=ALLOW_BLANK;

		if(communityUrl.contains("S73V.21"))
		{
			if(propType.length()>0)
				propType=propType+", Bungalow Homes";
			else
				propType="Bungalow Homes";
		}
//		U.log("comm======="+communityName);
			if(propertyStatus==null)propertyStatus=ALLOW_BLANK;
			propertyStatus = propertyStatus.replace("Va Or Fha Financing", "VA Or FHA financing");
			if(communityUrl.contains("https://www.thevillages.com/HomeFinder/Results/detail/L105.54"))communityName="Anaheim";
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			
			
			
			LOGGER.AddCommunityUrl(count + " " + communityUrl);
			data.addCommunity(U.getCapitalise(communityName.replace("CLARE", "Clare").toLowerCase()), communityUrl.trim(), commType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqFeet, maxSqFeet);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geoCode);
			data.addPropertyType(propType, dtype);
			data.addPropertyStatus(propertyStatus);
			data.addNotes(note);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			// } /*catch (Exception e) {
			// e.printStackTrace();

		}
		count++;
//		 }catch (Exception e) {}

	}
	static HashMap<String, String> checkProp=null;
	private static void addPropType() throws IOException {
		checkProp=new HashMap<>();
		String proHtml=U.getHTML("https://www.thevillages.com/homefinder/assets/models/models.json");
		U.log(U.getCache("https://www.thevillages.com/homefinder/assets/models/models.json"));
		String[] comwice=U.getValues(proHtml, "\"status\":", "}");
		for (String data : comwice) {
			String key=U.getSectionValue(data, "name\": \"", "\"");
			checkProp.put(key.toLowerCase().trim(), data);
		}
		U.log("Size::::::::"+checkProp.size());
	}

	public static void main(String[] args) throws Exception {
		addPropType();
		AbstractScrapper abs = new ExtractTheVillages();
		abs.process();
		FileUtil.writeAllText(U.getCachePath() + "The Villages of Lake Sumter.csv", abs.data().printAll());
		U.log("Total count:- " + count + "  reapeat:- " + repeat);

	}
}