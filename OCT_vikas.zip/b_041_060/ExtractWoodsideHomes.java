/**
 * @author Parag Humane 
 * @date 17/3/2012
 * 
 */
package com.shatam.b_041_060;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.ArrayList;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
public class ExtractWoodsideHomes extends AbstractScrapper {
	public static int dupli=0;
	int i=0;
	public int inr=0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	private static final String builderUrl = "https://www.woodsidehomes.com";
	public static void main(String[] args) throws Exception {
		
		

		AbstractScrapper a = new ExtractWoodsideHomes();
		
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Woodside Homes.csv", a.data().printAll());
		U.log(dupli);
	}

	public ExtractWoodsideHomes() throws Exception {

		super("Woodside Homes", "https://www.woodsidehomes.com/");
		LOGGER = new CommunityLogger("Woodside Homes");
	}

	public void innerProcess() throws Exception {

		U.setUpChromePath();
		driver = new ChromeDriver();

		String html = U.getHTML(builderUrl);
		//String section = U.getSectionValue(html, "FIND YOUR NEW HOME", "<li class=\"divider\"");
		String section=U.getSectionValue(html, "<ul class=\"footer-nav__regions-container\"","<g><g>");
		String [] regUrls = U.getValues(section, "<a href=\"", "\""); 
		for(String regUrl : regUrls){
			U.log("regUrl:::::::"+regUrl);
			int count=0;
			String regHtml = U.getHTML(builderUrl+regUrl);
			//String [] comSection = U.getValues(regHtml, "class=\"system large-12","<div class=\"medium-3  columns");
			String [] comSection=U.getValues(regHtml, "<div class=\"community-overview__content\"", "</path></g></svg>");
			U.log(comSection.length);
			for(String comSec : comSection){
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
//				U.log((count++)+"=-="+comUrl);
//				if(comUrl.contains("quick-move-in")) {LOGGER.AddCommunityUrl(comUrl+ "---------------------------------quick-movie-in");continue;}
//				if(comUrl.length() < 5) {LOGGER.AddCommunityUrl(comUrl+ "---------------------------------null url");continue;}
				//U.log(builderUrl+comUrl);
//				try {
					addDetails(builderUrl+comUrl,comSec);
//				} catch (Exception e) {}
			}
			LOGGER.AddRegion(builderUrl+regUrl, comSection.length);
		}
		
		LOGGER.DisposeLogger();
		driver.quit();
	}

	
	int pageCount = 0;

	//TODO : Extract Communities details here
	private void addDetails(String url,String comSec) throws Exception {
		
//------ SINGLE EXECUTION --------		
//	if(!url.contains("https://www.woodsidehomes.com/findmyhome/central-california/red-porch-at-farmstead")) return; 
		
//		if(pageCount >= 9 && pageCount <= 20)
//		if(pageCount <= 5)
//		if(pageCount >= 62)
			
		{
			if(url.contains("https://www.woodsidehomes.com/findmyhome/arizona/village-at-heritage-crossing")) {
				LOGGER.AddCommunityUrl(url+ "-------------------------------Not showing siteMap thats why returned for testing");
				return;
			}//date 8 April2022
			
			
	
		if(url.contains("/california-community-nova-at-bedford") || url.contains("/california-community-everview-at-sommers-bend")) {
			LOGGER.AddCommunityUrl(url+ "---------------------------------hidden from region page");
			return;
		}
			
		if(url.contains("/california-community-addington-at-brighton-landing") || url.contains("/california-community-silver-trail") || url.contains("/california-community-dakota-at-audie-murphy-ranch")) {
			LOGGER.AddCommunityUrl(url+ "---------------------------------present in code hidden from page");
			return;
		}
		
		if (data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
			return;
		}
		if (url.contains("https://www.woodsidehomes.com/nevada/nevada-community-pinyon-chase-at-skye-canyon") ||
				url.contains("https://www.woodsidehomes.com/california-central-valley/california-community-monticello")){
			LOGGER.AddCommunityUrl(url+ "---------------------------------Return");
			return;
		}
		
		if (url.contains("https://www.woodsidehomes.com/nevada/nevada-community-san-carlo-townhomes") ||
				url.contains("https://www.woodsidehomes.com/nevada/nevada-community-park-place-in-cadence")){
			LOGGER.AddCommunityUrl(url+ "---------------------------------No Data Return");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		
//		if(pageCount<78)return;
		U.log("\n===============\nPAGE [" + pageCount + "]:" + url);
		U.log("url: "+url);

		String html = getHtml(url,driver);
		
		U.log("comm Cache path"+U.getCache(url));
		
		//removing unwanted section from mainHtml
		if(html.contains("Copyright 2022 Woodside Homes, All Rights Reserved")) {
			
			String remove = U.getSectionValue(html, "Copyright 2022 Woodside Homes, All Rights Reserved", "Maximize space with optimal floorplans and tons of storage");
			html = html.replace(remove, "");
		}
		
		String html1=html;
		
		
		String overview = U.getSectionValue(html, "<a href=\"#panel1\">", "SALES OFFICE");
		// commName
		String section = U.getHtmlSection(html, "class=\"communityName\">",	"</td>");
//		String commName=U.getSectionValue(html, "<h1 class=\"communitytitle\"", "</h1>");
		
		String commNameSec=U.getSectionValue(html, "<h1 class=\"headline-one\"", "</div>");
		String commName=U.getSectionValue(commNameSec, ">", "</h1>");
//		U.log(commName);
		if(commName.contains("<"))
			commName = U.getSectionValue(commName, ">", "<");
		else
			commName = commName.replace(">", "");
	//	U.log("Cname:::"+commName);
		commName = commName.replaceAll("\\?|Woodside Homes at", "")
				.replaceAll("\n", "").trim();
		commName =		commName.replace(" 					  ", "");
		commName=commName.replaceAll("Falcon Crest in Summerlin", "Falcon Crest").replaceAll("Obsidian in Summerlin", "Obsidian");
		
		U.log("CommName::"+commName+":::::::");
		U.log(url);
//		U.log("COMSEC==="+comSec);
		
		String homesHtml=ALLOW_BLANK;
		String homeDataReg=ALLOW_BLANK;
		String homes[]=U.getValues(html,"<div class=\"panel-home__content\">","</div>");
		U.log("total homes"+homes.length);
		for(String home:homes) {
			String homeUrl=U.getSectionValue(home,"<a href=\"", "\"");
			U.log("home Url: "+(builderUrl+homeUrl));
			
			String homeData = U.getHTML(builderUrl + homeUrl); 
			
			//removing unwanted sections
			if(html.contains("Copyright 2022 Woodside Homes, All Rights Reserved")) {
				
				String remove = U.getSectionValue(homeData, "Copyright 2022 Woodside Homes, All Rights Reserved", "Maximize space with optimal floorplans and tons of storage");
				homeData = homeData.replace(remove, "");
			}
			
			homesHtml += "  " + homeData;
//			FileUtil.writeAllText("/home/shatam12/Desktop/Desktop/woodside.txt", homeUrl);
			homeDataReg+=" "+home;
		}

		
		
		
		String minP = ALLOW_BLANK, maxP = ALLOW_BLANK;
//		if (section != null||prisec!=null) {
		html=html.replace("mid $300s!\"/>", "")
				.replace("0s", "0,000").replace("0’s", "0,000").replace("0's.", "0,000").replace("0's", "0,000")
				.replaceAll("Starting at\\s+</span> <!----> <span>$1,035,990</span>", "Starting at \\$\\d,\\d{3},\\d{3}</span>");
		homesHtml=homesHtml
				.replace("A MUST SEE MODEL that Features over $200,000 Upgrades", "")
				.replaceAll("\n" + 
				"                </span> <!----> <span data-v-\\daaf\\de\\da>", " ")
				.replace("Starting at $716K", "Starting at $716,000")
				.replace("0K", "0,000");
		String[] price = U.getPrices((homesHtml+homeDataReg+section+html).replace("$482K", "$482,000").replace("$463K", "$463,000").replaceAll("0K", "0,000").replace("$1.08MM", "$1,080,000"),
			"Starting at\n" + 
			"      </span>\n" + 
			"      \\$\\d,\\d{3},\\d{3}|<span>\\$\\d,\\d{3},\\d{3}</span>|Starting at </span><span data-v-ea6fb95a>\\$\\d,\\d{3},\\d{3}|Starting at </span><span data-v-ea6fb95a>\\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+\\s*to\\s*\\$\\d+,\\d+| high \\d+,\\d+ to \\d+,\\d+|low \\$\\d{3},\\d{3}|low \\$[0-9]{3},[0-9]{3}|Starting From \\$\\d+,\\d+<br />|\\$[0-9]{3},[0-9]{3}", 0);
		minP = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxP = (price[1] == null) ? ALLOW_BLANK : price[1];

		U.log("MinPrice :" + minP + " MaxPrice:" + maxP);
		
		
//		U.log(">>>>>>>>>>>"+Util.matchAll(homesHtml, "[\\s\\w\\W]{40}716K[\\s\\w\\W]{90}",0));
//		U.log(">>>>>>>>>>>"+Util.matchAll(homeDataReg, "[\\s\\w\\W]{40}716K[\\s\\w\\W]{90}",0));
//		U.log(">>>>>>>>>>>"+Util.matchAll(section, "[\\s\\w\\W]{40}716K[\\s\\w\\W]{90}",0));
//		U.log(">>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{40}716K[\\s\\w\\W]{90}",0));

		
		html = html.replace("from 2,0002", "from 2,002");
		String sqftsec=U.getSectionValue(html, "<article>", "</article>");

		// sqft
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		html=html.replaceAll("approximately 2,311 sq.ft. to 3,565 sq.ft", "approximately 2,311 sq.ft to 3,565 sq.ft");
		html=html.replace("10,000", "");
		String[] sqft = U.getSqareFeet(homesHtml+homeDataReg+html+sqftsec, 
				"from \\d,\\d{3} to \\d,\\d{3} interior square feet|approximately \\d,\\d{3} sq.ft to \\d,\\d{3} sq.ft|approximately \\d,\\d{3} sq\\. ft\\. to \\d,\\d{3} sq\\. ft|floorplans with \\d{4}-\\d{4} square feet|from \\d,\\d{3} Sq\\. Ft\\. to \\d,\\d{3} Sq\\.|from \\d,\\d{3} s.f to \\d,\\d{3} s.f|\\d,\\d{3} and \\d,\\d{3} sq ft|\\d,\\d{3} to \\d,\\d{3} square feet|from \\d,\\d{3} s.f. to \\d,\\d{3} s.f.|from \\d,\\d{3} to \\d,\\d{3} finished square feet|approximately \\d,?\\d{3} sq. ft to \\d,?\\d{3} sq. ft.|anging from approximately \\d+,\\d+ - \\d+,\\d+|\\d+,\\d+ -\\d+,\\d+ finished square feet|\\d+,\\d+ to \\d+,\\d+ total square feet| \\d+,\\d+ and \\d+,\\d+ square feet |\\d+,\\d+\\s*to\\s*\\d+,\\d+ [sS]q|\\d+,\\d+ SF|\\d+,\\d+ sq ft|\\d+,\\d+ up to \\d+,\\d+ square feet|\\d+,\\d+ square feet|[0-9]{4} up to [0-9]{4} square feet|[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3} sq. ft.|\\d,\\d+-\\d{4} square feet|from approximately \\d,\\d{3} to \\d,\\d{3}", 0);
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);


		
		// minsqf minsqf revised
		
		
		if (minSqf == ALLOW_BLANK || maxSqf==ALLOW_BLANK) {
			if(sqftsec!=null)
			{
				
			String[] sqft1 = U.getSqareFeet(html+sqftsec, "approximately \\d,\\d{3} sq\\. ft\\. to \\d,\\d{3} sq\\. ft|approximately \\d,\\d{3} sq.ft. to \\d,\\d{3} sq.ft|from \\d,\\d{3} to \\d,\\d{3} finished square feet|\\d+ sq. ft to \\d+ sq. ft.|ranging from approximately \\d+,\\d+ - \\d+,\\d+|\\d+,\\d+ Sq. Ft|\\d+,\\d+ SF to &nbsp;over \\d+,\\d+ SF|[0-9]{4} to [0-9]{4} square feet", 0);
			minSqf = (sqft1[0] == null) ? ALLOW_BLANK : sqft1[0];
			maxSqf = (sqft1[1] == null) ? ALLOW_BLANK : sqft1[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		}
		}
		

		// Lat Long
		
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, flag = "FALSE";
		String latlong[]={ALLOW_BLANK,ALLOW_BLANK};

		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };
		String latlngSec=U.getSectionValue(html, "dir=\"ltr\"","Back to Region");
		U.log("latlngSec: "+latlngSec);
		
		if(latlngSec == null) latlngSec=U.getSectionValue(html, "Open this area in Google Maps","<div style=");
		U.log("latlngSec---: "+latlngSec);
		
		
		String lat1=ALLOW_BLANK;
		String long1=ALLOW_BLANK;
		if(latlngSec!=null) {
		lat1=U.getSectionValue(latlngSec, "href=\"https://www.google.com/maps/@",",");
		long1=U.getSectionValue(latlngSec, ",", "/");
		long1=long1.replaceAll(",12z", "");
		}
		lat=lat1;
		lng=long1;
		String addSec=U.getSectionValue(html, "<a href=\"https://www.google.com/maps","</div>");
		String addLine=U.getSectionValue(addSec, ">","</a>");
		U.log("adfdLine"+addLine);
		ArrayList<String> zip=Util.matchAll(addLine, "\\d{5}", 0);
		U.log("Zip"+zip.get(0));
	
		addLine=addLine.replaceAll("\\,\\s*\\d{5}","");
		
		add=U.getAddress(addLine);
		if(add[3]==ALLOW_BLANK)
		 add[3]=zip.get(0);

		latlong[0]=lat1;
		latlong[1]=long1;
		add[0]=add[0].replace("&amp;","&");
		U.log("Address:"+add[0]+"<>"+add[1]+"<>"+add[2]+"<>"+add[3]);
		
//		if(latlong[0].length()<3 && latlong[1].length()<3) {
//			latlong[0]=U.getSectionValue(html, From, To)
//		}
		
		U.log("Latlong="+latlong[0]+" "+latlong[1]);
		
		
		
		//=============== Comm Type,Property Type, Derived TYpe, Status====================
		String pType = ALLOW_BLANK;
		
		String sec=null;
		
		
		//TODO : Property Status
		//
		String pStatus = ALLOW_BLANK;
//		String secP = U.getSectionValue(html, "font-size:14px;\">",	"</strong></div>");
		int quickCount = 0;
		String quickMoveCardSection[] = U.getValues(html1, "<div class=\"panel-home__header-controls-left\">", "</div>");
		for(String cardSection : quickMoveCardSection) {
			if(cardSection.contains("Quick Move In")) quickCount++;
		}
		
		html=html.replace("Park Place is now open", "").replace("New phases coming 2021", "New phase coming 2021")
				.replace("COMING SOON, JUNE 2018", "COMING SOON JUNE 2018").replace("COMING SOON, JANUARY 2017", "COMING SOON JANUARY 2017").replace("Model homes  NOW OPEN!", "").replace("COMING SOON, FALL 2016", "COMING SOON FALL 2016");
		String remove="Floorplan Coming Soon|<br>Coming Soon<br><br>|<h3 style=\"color:#555555;font-size:14px;line-height:16px\">\\s*Coming Soon<br/>|Woodside Homes is now open|Hours: Coming Soon|NOW SELLING MODELS|coming soon family on bikes|move|Community Pool - Coming Soon 2016|Coming Soon photo|Hours: Coming Soon|_Coming Soon_main|Coming Soon, Join our|Coming Soon Plan|2015|Brand New Models NOW OPEN|New Luxury Style Homes in San Antonio|Amenities are coming soon";
		html= html.toLowerCase().replaceAll(remove.toLowerCase(), "");
		html = html.replace("-�last home", "last home");
		html = html.replace("/images/Slideshow/com_1109_", "Coming soon");//coming soon inside image
		html=html.replaceAll("<h4 style=\"color:#555555;font-size:14px;line-height:16px\">\\s+Coming Soon\\s+<br/>|Sold Out top right corner |Amenities are coming soon|amenities are coming soon|plans for this community are coming soon|sales trailer now open|opening late 2016, this|golf and cultural experiences.|information about this new phase release.".toLowerCase(),"");
		html=html.replace("alt=\"now selling family","");
		html=html.replace("efficient, single family homes","");
		html=html.replace("Opening late 2016, this carefree","");
		html=html.replace("/images/soldoutsmall.png\"","");
		html=html.replace(" alt=\"Sold Out ","");
		html=html.replace("alt=\"sold out","").replace("grand opening april 18, 2020", "Grand Opening April 18 2020");
		html=html.replaceAll("large lots available|<meta name=\"description.*?>|salesofficetext\">\\s*coming soon|models are now open|new school coming soon|amenities are coming soon|Models now open|looking to open spring 2018|coming soon banner|sales office is now open:|are now open!\"/>|now open 2-thumbnail.jpg\"/>|now open 2.jpg\"|models opening fall","")
				.replaceAll("communitystatus' : '(c|C)lose", "");

		comSec = comSec.replace("/images/sold.png", "/images/Sold Out.png")
				.replace("/images/finalphase.png", "/images/Final Phase.png");
		
		
		html = html.replaceAll("bathrooms\n\\s*<br/>\n\\s*<br/>\n\\s*coming soon|CREEK_FINAL|creek_final|aquatic center coming|CENTER COMING|grand opening saturday|school - coming soon|/slideshow/coming|/Coming Soon |now open for pre\\s*[-]*\\s*sale|\"/images/soldoutsmall.png|Coming Soon, Join|coming soon! tramonte| models coming| models opening spring 2018!|opening soon coupled|Coming Soon_|Model homes are now available|winter 2020", "")
				.replace("this community is now sold out|images/Sold Out.png", "");
		comSec = comSec.replaceAll("CREEK_FINAL|Now open for pre\\s*[-]*\\s*sale|OW OPEN FOR PRES|Coming Soon_| Model homes are now available", "");
		
//		U.log("comSec:: "+comSec);
		comSec=comSec.replaceAll("c>\\s*coming soon", "");
		//===================================================================================================
		pStatus= U.getPropStatus((html +comSec).replaceAll("Bathrooms<br/>\n\\s*<br>Coming Soon<br><br>|sold out\"|models opening|MODELS OPENING LATE 2021|upton_ coming|Upton_ Coming Late Fall 2021|SOLD OUT\"|-sold-out-| Model homes are now available","")
				.replaceAll("our new community coming winter 2021", ""));
		
//		U.log(">>>>>>>>>>>"+Util.matchAll(html + comSec, "[\\s\\w\\W]{40}Quick Move In[\\s\\w\\W]{30}",0));

		
		pStatus = pStatus.replace("Selling Out, Now Selling", "Now Selling Out").replace("Close Out, Sold Out", "Sold Out").replace("New Phase Coming 2021, Coming 2021,", "New Phase Coming 2021, ");
		U.log("result:::::::::::::"+Util.matchAll(comSec+html, "[\\s\\w\\W]{300}sold out[\\s\\w\\W]{300}",0));
		U.log("pStatus ::"+pStatus);
		String newhtml=U.getHTML(url);
		newhtml=newhtml.replaceAll("line-height:16px;\">\\s+MOVE-IN READY", "height:16px;\">MOVE-IN READY");
		if(comSec.contains("/images/newphase.png"))
		{
			if(pStatus!=ALLOW_BLANK)pStatus=pStatus+", New Phase";
			else {
				pStatus="New Phase";
			}
		}
		if(comSec.contains("/images/finalphase.png") || comSec.contains("/images/Final Phase.png"))
		{
			if(pStatus!=ALLOW_BLANK && !pStatus.contains("Final Phase"))pStatus=pStatus+", Final Phase";
			else {
				pStatus="Final Phase";
			}
		}
		
		if(quickCount > 0){
			if(pStatus != ALLOW_BLANK)pStatus = pStatus + ", Quick Move In";
			else pStatus = "Quick Move In";
		}
		

		U.log("---Status---------> "+pStatus);
///california-community-the-hills-at-paradiso
		if(url.contains("https://www.woodsidehomes.com/california-community-ventana-at-creekside-village"))pStatus="Now Open"; //from img
		if(url.contains("california-inland-empire/california-community-upton-at-sommers-bend"))pStatus+=", Coming Winter 2021"; //from img
		if (comSec.contains("/images/Slideshow/ComingSoon_Encore-Web-resized-650.jpg")) {
			pStatus="Phase II Coming Soon"; //from img
		}
		
		if(url.contains("https://www.woodsidehomes.com/california-east-bay-sacramento/california-community-the-cottages-at-spring-valley"))
			pStatus=pStatus.replace(", Move-in Ready",""); //Sold Move In
		
//-------------------------status from image-----------------------------------------------------
		String secthtml="";
	 
		if(url.contains("https://www.woodsidehomes.com/utah/utah-community-lakeside-at-talons-cove"))pStatus=pStatus.replace("Now Open, ","");
		

		//Region Page Image Tag
		if(url.contains("https://www.woodsidehomes.com/california-east-bay-sacramento/california-community-addington-at-brighton-landing"))pStatus = getImageStatus(pStatus, "Final Phase");
		
		if(pStatus.contains("New Phase, New Phase"))
			pStatus=pStatus.replace("New Phase, New Phase","New Phase");
		
		String securl[]=U.getValues(newhtml, "<a class=\"\" href=\"/", "\">");
		for(String sect:securl)
		{
			sect="https://www.woodsidehomes.com/"+sect;
			U.log(sect);
			String homeHtml = U.getHTML(sect);
			secthtml+= U.getSectionValue(homeHtml, "<h1 style=", "row hide-for-large-up");//"DOWNLOAD BROCHURE</a>");
		}

		
		// Notes info variable
		String noteVar = ALLOW_BLANK;
		noteVar = U.getnote((html+overview).replace("NOW PRE_SELLING", "Now Pre-Selling"));
		
		//TODO : Community Type
		html = html.replace("resort-quality pools", "resort-style pool")
				.replaceAll("las vegas master plans|best masterplan in las vegas|folsom lake", "");
		String communityType = U.getCommunityType(html);
		
		
		//TODO : Derived Property Type
				String derivedPType = ALLOW_BLANK;
				String myStory=ALLOW_BLANK;
				String remSec[]=U.getValues(homesHtml,"Stories","</div>");
				for(String storySec:remSec) {
					storySec=U.getNoHtml(storySec);
					storySec=storySec+"Stories";
					myStory+=" "+storySec;
				}	
			//	U.log("story Sec"+myStory);
			
				
				html = html.replace("multi-generational space", "multi-generational homes space")
						.replaceAll("ranch elementary|Ranch Elementary|Ranchos|ranchos|\\d+ Ranch|\\d+ ranch|single story homes for sale in las vegas|AZ featuring single- and two-story homes|With NO HOA| Spanish Colonial Elevation", "").replaceAll("2 Story\n\\s*<br/>", " Story 2 ");
				derivedPType = U.getdCommType(myStory+homeDataReg+homesHtml+secthtml+html.replace("Hanson Ranch", "").replace("Ranch View", "").replace(" rambler ", " Ranch ").replace("Ranch Elevation", ""));
				U.log("derivedPType ::: "+derivedPType);
		
		if(derivedPType.length()<2)derivedPType=ALLOW_BLANK;
		U.log("derivedPType ::: "+derivedPType);

		//TODO : Property TYpe
		html = html+overview;
		
		U.log("***********"+html.contains("farmhouse"));
		html = html.replace("singlefamilysitemapshtml", "").replace("81-839 villa palazzo", "");
		secthtml = secthtml.replace("luxurious master suite", "")
				.replaceAll("Cottage elevation", "");
		//U.log(Util.match(secthtml, ".*?luxur.*?"));
		String rem = "bedroom with patio|model patio|(v|V)illapaseo|(T|t)raditional utility cost";

		String commDesc=U.getSectionValue(html, "class=\"description body", "</p>");
		
		html = html.replaceAll("as special as your neighborhood, in farmhouse, craftsman, stucco bungalow", "as special as your neighborhood, in farmhouse-style home, Craftsman-style exterior, Bungalow Series")
				.replace(" Stucco Bungalow,", "Bungalow Series")
				.replace("farmhouse living in clovis", "farmhouse-style home living in clovis")
				.replaceAll("Farmhouse Victorian|and Farmhouse in a community", "Farmhouse-inspired architectura")
				.replaceAll("With Mediterranean, Spanish|Mediterranean and Tuscan designs|Mediterranean Revival", "mediterranean-style Homes");
		
		commDesc=commDesc
				.replace("distinct floorplans (stucco bungalow, craftsman, farmhouse, and european cottage) and woodside’s", "distinct floorplans (Bungalow Series, Craftsman-style exterior, farmhouse, and european cottage) and woodside’s")
				.replaceAll("as special as your neighborhood, in farmhouse, craftsman, stucco bungalow", "as special as your neighborhood, in farmhouse-style home, Craftsman-style exterior, Bungalow Series");
		
		html=html.replace("and flex spaces create the personalized", "and Flex space create the personalized")
				.replaceAll("and no hoa dues.</p>", "and no hoa dues").replaceAll("no hoa restrictions","").replaceAll("luxurious, stylish, and expansive home designs", "Luxury Homes");
		pType=U.getPropType((commDesc+homeDataReg+homesHtml+secthtml+html)
								.replace("Bonus room/ Loft/ Teen room", "Bonus room/ Oversized Loft/ Teen room")
				.replaceAll("luxury kitchen|luxury vinyl plank flooring|Zion - Craftsman|Yellowstone - Craftsman|yosemite - craftsman|Craftsman.jpeg|with no hoa fee|luxurious bath|luxurious bubble|luxurious shower|luxurious walk-in shower|luxury kitchen|and no hoa dues|With NO HOA ","").replace("designs such as farmhouse", "red brick farmhouse").replaceAll("NO HOA|traditional school|Traditional School", "").replaceAll(rem,""));

		U.log("pType: "+pType);
//		U.log("MMMMMM"+Util.matchAll(homeDataReg, "[\\w\\W\\s]{50}flex space[\\w\\W\\s]{50}", 0));
//		U.log("MMMMMM"+Util.matchAll(homesHtml, "[\\w\\W\\s]{50}flex space[\\w\\W\\s]{50}", 0));
//		U.log("MMMMMM"+Util.matchAll(html, "[\\w\\W\\s]{50}Farmhouse[\\w\\W\\s]{50}", 0));
//		U.log("MMMMMM"+Util.matchAll(secthtml, "[\\w\\W\\s]{50}Farmhouse[\\w\\W\\s]{50}", 0));

		
		if(url.contains("https://www.woodsidehomes.com/findmyhome/arizona/views-at-verrado"))pType="Courtyard Home, Patio Homes, Loft";
		//		U.log(Arrays.toString(add));
	
		if(add[3]==null)add[3]=ALLOW_BLANK;
		commName = commName.replaceAll("\\s{3,}", "");
		U.log(commName);
		U.log("GEo:::"+flag);
		
		
          commName=commName.replaceAll("¬†|�","").trim();
          
//        if(url.contains("/california-community-hamlet-at-natomas-meadows") || url.contains("/california-community-stonewater-at-park-place"))pStatus = pStatus.replace(", Move-in Ready", "");
        if(noteVar.contains("Presale"))noteVar="Pre-Selling Now";
        
        pStatus = pStatus.replace("Fha Financing Available", "FHA Financing Available");
        
        if(url.contains("https://www.woodsidehomes.com/findmyhome/utah/vista-at-salt-point"))pStatus="Quick Move In";//frm image
	  
		  add[0] = add[0].replace("11541Jack Street", "11541 Jack Street");

		  
		String noOfUnits=ALLOW_BLANK;
		String start_date=ALLOW_BLANK;
		String end_date=ALLOW_BLANK;
		int inactiveTotal=0;
		int noOfUnit=0;
		int lotsTotal=0;
		int linesSecTotal=0;

		String homeSiteSec=U.getSectionValue(html1,"One step closer<br data-v-7db9b4c0", "<div class=\"panel__asset --square\">");
		// U.log("homeSiteSec:: "+homeSiteSec);
		  if(homeSiteSec!=null) {
			  String siteMapUrl=U.getSectionValue(homeSiteSec, "<a href=\"", "\">");
			  U.log("SiteMapUrl:: "+siteMapUrl);
			  
			  if(siteMapUrl.contains("salesarchitect")) {
			  U.log("hello");
			  String sitemMapHtml=U.getHtml(siteMapUrl,driver);
			  U.log("Path1:: "+U.getCache(siteMapUrl));
			  //String gIdInactive=U.getSectionValue(sitemMapHtml, "<g id=\"Inactive\">", "<g id=\"Lines\">");
			  String gIdInactive=U.getSectionValue(sitemMapHtml, "<g id=\"Inactive\">", "</g>");
			 
			  if(gIdInactive!=null) {
			  String[] path1=U.getValues(gIdInactive, "<path", "\"/>");//<path d=
			  String[] polygon1=U.getValues(gIdInactive, "<polygon", "/>");//<polygon points=
			 
			  inactiveTotal=path1.length+polygon1.length;
			  
			  U.log("Inactive Total= "+inactiveTotal);
			  }
		      
			  //String lotsSec=U.getSectionValue(sitemMapHtml, "<g id=\"Lots\">", "<g id=\"Inactive\">");
			  String lotsSec=U.getSectionValue(sitemMapHtml, "<g id=\"Lots\">", "</g>");
			 
			  if(lotsSec!=null) {
			  String[] path2=U.getValues(lotsSec, "<path", "\"/>");
			  String[] polygon2=U.getValues(lotsSec, "<polygon", "/>");
			  String[] rect=U.getValues(lotsSec, "<rect","/>");
			  
			  lotsTotal=path2.length+polygon2.length+rect.length;
			  
			  U.log("lots Total= "+lotsTotal);
			  }
			  
			 // String lineSec=U.getSectionValue(sitemMapHtml, "<g id=\"Lines\">", "<g id=\"Amenities\">");
			  String lineSec=U.getSectionValue(sitemMapHtml, "<g id=\"Lines\">", "</g");
			  if(lineSec!=null) {
			  String[] path3=U.getValues(lineSec, "<path", "\"/>");
			  String[] polygon3=U.getValues(lineSec, "<polygon", "/>");
			  linesSecTotal=path3.length+polygon3.length;
			  U.log("lines Total= "+linesSecTotal);
			  }

			  noOfUnit=lotsTotal;//linesSecTotal++inactiveTotal
			  }
			  else if(siteMapUrl.contains("contradovip")) {
				 String sitemMapHtml2=U.getHtml(siteMapUrl,driver);
				//  String sitemMapHtml=U.getPageSource(siteMapUrl);
				  U.log("Path2::"+U.getCache(siteMapUrl));
				//  U.log("Site Html"+sitemMapHtml);
				 // String lotDataSec=U.getSectionValue(siteMapUrl, "<g id=\"gPlan\">","</g><g id=\"v.1\">");
				  String[] lotArr=U.getValues(sitemMapHtml2, "<g id=\"v.1.opt","<g>");
				  U.log("total units in map contradovip"+lotArr.length);
				  noOfUnit=lotArr.length;
			  }
			  else if(siteMapUrl.contains("focus360.")) {
				  String siteMapHtml3=U.getHtml(siteMapUrl, driver);
				  U.log("Path3::"+U.getCache(siteMapUrl));
				  String hiddenLots=U.getSectionValue(siteMapHtml3, "<g id=\"hideLots\"", "</g></g></svg>");
				  if(hiddenLots!=null)
				      siteMapHtml3=siteMapHtml3.replace(hiddenLots, "");
				  String[] lotArr=U.getValues(siteMapHtml3, "<g id=\"lot_", ">");
				  noOfUnit=lotArr.length;
			  }
			  
		  }
		  noOfUnits=Integer.toString(noOfUnit);
		  if(noOfUnits.equals("0"))
			  noOfUnits=ALLOW_BLANK;
		  U.log("NO Of Units="+noOfUnits);
		  
		pStatus = pStatus.replace("Closeout", "Close Out");
        data.addCommunity(commName.trim(), url, communityType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minP, maxP);
		data.addLatitudeLongitude(lat, lng, flag);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(pStatus);
		data.addNotes(noteVar);
		data.addConstructionInformation(start_date, end_date);
		data.addUnitCount(noOfUnits);
		

		}
		pageCount++;
	}

	private static String getImageStatus(String propStatus, String imageStatus){
		if(propStatus.length()<4) propStatus = imageStatus;
		else propStatus = propStatus + ", "+imageStatus;
		return propStatus;
	}
	private static boolean isMatchedLocation(String[] add,String[] addr){
		boolean isMatched=false;
		if(addr[3].equals(add[3]))
			isMatched=true;
		else{
			if(addr[1].equalsIgnoreCase(add[1]) && addr[2].equalsIgnoreCase(add[2]))
				isMatched=true;
			else{
				if(addr[2].equalsIgnoreCase(add[2]) 
						&& add[3].substring(0, 3).equals(addr[3].substring(0, 3)))
					isMatched=true;
			}
		}
		return isMatched;
	}
	
	public static boolean isValidLatLong(String[] latLon,String[] add) throws Exception{
		boolean isValid=false;
		if(latLon==null || add==null)
			return isValid;
		
//		U.log("lat :"+latLon[0]+ " Long :"+latLon[1]);
		
		if(latLon[0]==ALLOW_BLANK ||latLon[1]==ALLOW_BLANK ||add[3]==ALLOW_BLANK || add[1]==ALLOW_BLANK || add[2]==ALLOW_BLANK )
			return isValid;
		
		boolean isMatched=false;
		String[] addr=null;
		addr= U.getGoogleAdd(latLon[0],latLon[1]);
		if(addr!=null){
		isMatched= isMatchedLocation(add,addr);
		if(isMatched)
			return true;
		}
		addr=U.getGoogleAdd(latLon[0],latLon[1]);
		isMatched=isMatchedLocation(add,addr);
		if(isMatched)
			return true;
		
		return isValid;
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
//					Thread.sleep(10000);
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(6000);
					U.log("---------------------------------Scrolling------------------------");
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,5600)", ""); 
					Thread.sleep(10000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	
}