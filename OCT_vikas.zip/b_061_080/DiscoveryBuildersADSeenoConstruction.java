package com.shatam.b_061_080;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringEscapeUtils;
//import com.shatam.b_000_009.ExtractAbstractNVR;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class DiscoveryBuildersADSeenoConstruction extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	MultiValueMap quickMoveInData=new MultiValueMap();
	static String Builder_name = "Discovery Builders A.D. Seeno Construction";
	static String HOME_URL = "https://www.discoveryhomes.com/";
	
	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new DiscoveryBuildersADSeenoConstruction();
		//U.logDebug(true);
		a.process();
		
		FileUtil.writeAllText(U.getCachePath()+"Discovery Builders A.D. Seeno Construction.csv", a.data().printAll());
	}

	public DiscoveryBuildersADSeenoConstruction() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger("Albert D. Seeno Construction Co. Discovery Builders");

	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
		
		String quickMoveInHtml=U.getHTML("https://www.discoveryhomes.com/quick-move-ins");
//		String quickhtml=U.getHTML(quickMoveInURl);
		String quickSec=U.getSectionValue(quickMoveInHtml, "div is=\"quick-move-ins\">", "</main>");
		String indiQuicks[]=U.getValues(quickSec, "section class=\"elevation\">", "span class=\"icon-floorplan-icon\"></span>");
		U.log(indiQuicks.length);
		for (String quickMoveIn : indiQuicks) {
//			U.log(quickMoveIn);
			String commname=U.getNoHtml(U.getSectionValue(quickMoveIn, "<div class=\"qmi-card__community\">", "</div>")).trim();
			quickMoveInData.put(commname, quickMoveIn);
//			break;
		}
		String html =U.getHTML("https://www.discoveryhomes.com/#section-2");
		html =html.replaceAll("\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "end sections");
		String[] comSections = U.getValues(html, "class=\"community-list-card\">", "end sections");
		U.log(comSections.length);
		
		for(String comSec : comSections){
			//U.log(comSec);
			String comUrl = "https://www.discoveryhomes.com"+U.getSectionValue(comSec, "<a href=\"", "\"");
			String comName = U.getSectionValue(comSec, "<div class=\"card__title\">", "</div>").trim();
			//U.log(comName+"\t"+comUrl);
			addDetails(comSec,comName,comUrl);
			//break;
		}
		driver.quit();
    LOGGER.DisposeLogger();
}

	//TODO:	
	private void addDetails(String comSec, String comName, String comUrl) throws Exception {
		
//		try {
//	if(!comUrl.contains("https://www.discoveryhomes.com/fairfield-ca/summerwalk-at-the-villages"))return;
		
		
		U.log("Count=="+j);
	String comHtml = U.getHTML(comUrl);
	
	String json = U.getSectionValue(comHtml, "let JsonData = {", "</script>");
	if(json!=null)
		comHtml = comHtml.replace(json, "");
	
	comHtml = StringEscapeUtils.unescapeJava(comHtml);
	
	/*//----Remove comon contact form section------
	comHtml = U.removeSectionValue(comHtml, "<footer class=\"footer\">", "</find-your-home-navigation>");
	*/
	String comDetailSec = U.getSectionValue(comHtml, "<div id=\"overview\">", "</contact-and-directions-map>")+U.getSectionValue(comHtml,"<div class=\"community__snapshot-price\">", "</div>");
	
	comName = comName.replace(" - Coming Soon", "");
	
	//------------address-----------
	String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
	String latLng [] ={ALLOW_BLANK,ALLOW_BLANK};
	String geo = "FALSE";
	String addSection = U.getSectionValue(comHtml, "contact-lower-address\">", "</div>");	
	if(addSection!=null)
	{
		String tempaddsection=addSection;
		addSection = U.getSectionValue(addSection, "</span><br />", "<a");
		if (addSection==null) {
			addSection = U.getSectionValue(tempaddsection, "</span><br />", "</p>");	
		}
		addSection = addSection.trim().replace("<br />", ",");
		U.log("addSection : "+addSection);
		
		if(addSection != null && addSection.contains("1504 Millennium Way")) addSection = addSection.replace("1504 Millennium Way,,", "1504 Millennium Way,");
		
		add = U.getAddress(addSection);
		add[0]=add[0].replaceAll(" - OPEN BY APPOINTMENT ONLY|- open by appointment only", "");
		U.log("Address is : "+Arrays.toString(add));
	}
	
	//----------Latlng-----
	String latLngSec = U.getSectionValue(comHtml, "href=\"https://maps.google.com/maps?q=", "\"");
	if(latLngSec != null)
		latLng = latLngSec.split(",");
	U.log("latlng is : "+Arrays.toString(latLng));
	
	if((add[0].length()<4 || add[3].length()<4) && latLng[0].length()>4)
	{
		String add1[] = U.getAddressGoogleApi(latLng);
		if(add1 == null) add1 = U.getAddressHereApi(latLng);
		
		if(add[0].length() < 4) add[0] = add1[0];
		if(add[3].length() < 4) add[3] = add1[3];
		geo = "TRUE";
	}
/*	if(add[3].length()<4 && latLng[0].length()>4)
	{
		add[3] = U.getAddressGoogleApi(latLng)[3];
		geo = "TRUE";
	}
*/	//---------Price from for Siteplan overlay-------
	String availableHomeprice = ALLOW_BLANK;
	String sitePlanPriceSec = U.getSectionValue(comHtml, "\"meta_title\":\"", "overview-gallery\"}");
	if(sitePlanPriceSec !=null){
		for(String siteSec : U.getValues(sitePlanPriceSec, "\"status\":\"available", "short_description") ){
			availableHomeprice += siteSec;
		}
	}
	String plansHtml="";
	String patioHtml="";
	String floorPlanMainSecs[]=U.getValues(comHtml, " <div class=\"floorplan-list-card\">", "</section>");
	for (String floorplanSec : floorPlanMainSecs) {
		String planUrl=U.getSectionValue(floorplanSec, "href=\"", "\"");
		String PlanHtml=U.getHTML("https://www.discoveryhomes.com"+planUrl);
		U.log("PLAN: "+"https://www.discoveryhomes.com"+planUrl);
		plansHtml+=PlanHtml;
		
		String patioUrl = planUrl.replaceAll(".*/", "");
		patioHtml+=U.getHTML("https://www.discoveryhomes.com/smartplans/config/"+patioUrl+".js");
		
	}
	
	if (quickMoveInData.containsKey(comName)) {
		@SuppressWarnings("unchecked")
		List<String>quickdata=(List<String>) quickMoveInData.getCollection(comName);
		for (String quick : quickdata) {
//			U.log(quick);
			availableHomeprice+=quick;
		}
		U.log("FOUND");
	}
	//-----------price--------
	String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	
//	comDetailSec = comDetailSec.replace("Starting at $799", "Starting at $799,000");
	
	String [] prices = U.getPrices(comDetailSec+comSec+availableHomeprice, "Starting at \\$\\d{3},\\d{3}|<div class=\"qmi-card__price\">\\s+\\$(\\d,)?\\d{3},\\d{3}\\s+</div>|Starting at \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}", 0);
	minPrice = (prices[0]==null) ? ALLOW_BLANK : prices[0];
	maxPrice = (prices[1]==null) ? ALLOW_BLANK : prices[1];
//	U.log(Util.matchAll(comDetailSec, "[\\w\\s\\W]{30}876,760[\\w\\s\\W]{30}", 0));
//	U.log(Util.matchAll(availableHomeprice, "[\\w\\s\\W]{30}876,760[\\w\\s\\W]{30}", 0));

	U.log(minPrice+"\t"+maxPrice);
	
	//---------sqft--------
	String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
	String sqft [] = U.getSqareFeet(comDetailSec+comSec, "approximately \\d,\\d{3} square feet to \\d,\\d{3} square feet|size from \\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3} square feet to \\d,\\d{3} square feet |\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*sq. ft.|>\\d,\\d{3}\\s*sq. ft.<", 0);
	minSqft = (sqft[0]==null) ? ALLOW_BLANK : sqft[0];
	maxSqft = (sqft[1]==null) ? ALLOW_BLANK : sqft[1];
	U.log(minSqft+"\t"+maxSqft);
	
	//----community type-----
	String comType = U.getCommType(comDetailSec+comSec);
	U.log("comType : "+comType);
	
	//----property type-----
	comDetailSec = comDetailSec.replaceAll("craftsmanship|property=\"single-family\"| property=\"townhome\"", "").replace("single and two story", "one story and two story")
			.replaceAll("where executive living", "Executive Collection");
	String propType = U.getPropType((comDetailSec+comSec+patioHtml).replaceAll("loftDoors|Loft tDoor|Villa Vista|%20Cottage%20", ""));
	U.log("propType"+propType);
	
//	U.log(Util.matchAll(comDetailSec+comSec+patioHtml, "[\\w\\s\\W]{30}loft[\\w\\s\\W]{30}", 0));
//	FileUtil.writeAllText("/home/shatam-10/Desktop/data/loftnew.txt", comDetailSec+comSec+patioHtml);
	
	
	//----derived property type-----
	String dType = U.getdCommType((comDetailSec+comSec+plansHtml).replace("Single and two story floor ", "Single story and two story floor ").replaceAll("Brook Ranch|Ranch</option>|Floor|floor", ""));
	U.log("dType : "+dType);

	
	//----property status-----
	comSec = comSec.replace("grand-opening-flag", " grand opening flag");
	comDetailSec=comDetailSec.replaceAll("<li class=\"community-price\">\\s+Temporarily Sold Out\\s+</li>|Move-In", "").replaceAll("limited </span></font><span style=\"font-size: 18px;\">home sites</span><span style=\"font-size: 13.5pt;\"> available", "limited home sites available");
	if(comHtml.contains("class=\"tagline\">Quick Move-In Homes Available")) {
		comDetailSec=comDetailSec+" Quick Move-In Homes Available ";
	}

	comDetailSec = comDetailSec.replaceAll("<li class=\"community-price\">\n\\s*Sold Out|>Now Selling by Appointment!</span>|Now open by appointment", "");
	
	String propStatus = U.getPropStatus(comDetailSec+comSec);
//	if(comUrl.contains("https://www.discoveryhomes.com/chico-ca/meadow-brook-ranch"))propStatus ="New Release Available";
//	U.log(Util.matchAll(comDetailSec+comSec, "[\\w\\s\\W]{30}now selling[\\w\\s\\W]{30}", 0));
	U.log("propStatus"+propStatus);
	
//	================================================================================
	String lotCount=ALLOW_BLANK;
	String mapLink=comUrl+"#site-plan";
	U.log("mapLink=="+mapLink);
	if(mapLink!=null)
	{
		String mapHtml=U.getHtml(mapLink, driver);
		String[] lot_data=U.getValues(mapHtml, "title=\"\" tabindex=\"-1\">", ">");
		U.log("lot_data.length==="+lot_data.length);
		lotCount=Integer.toString(lot_data.length);
	}
	if(lotCount.equals("0"))
		lotCount=ALLOW_BLANK;
	
	
	if(propStatus.equals("Closeout, Sold Out")) propStatus = "Closeout";
	
	LOGGER.AddCommunityUrl(comUrl);
	data.addCommunity(comName.trim(), comUrl, comType);
	data.addAddress(add[0], add[1], add[2], add[3]);
	data.addLatitudeLongitude(latLng[0], latLng[1], geo);
	data.addPropertyType(propType, dType);
	data.addPropertyStatus(propStatus);
	data.addPrice(minPrice, maxPrice);
	data.addSquareFeet(minSqft, maxSqft);
	data.addNotes(ALLOW_BLANK);
	data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	data.addUnitCount(lotCount);
	j++;
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
}

	
}