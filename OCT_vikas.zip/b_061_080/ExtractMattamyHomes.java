/** @author Upendra
 *  @date 20 April 2018
 */
package com.shatam.b_061_080;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.*;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.server.browserlaunchers.HTABrowserLauncher;

import com.gargoylesoftware.htmlunit.javascript.host.Set;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMattamyHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int register, j = 0, count = 0;
	static int dup = 0;
	List comData = new ArrayList<String>();
	CommunityLogger LOGGER;
	WebDriver driver;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractMattamyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Mattamy Homes.csv", a.data().printAll());
		// U.log(dup);
		// U.log(register);
	}

	public ExtractMattamyHomes() throws Exception {

		super("Mattamy Homes", "https://www.mattamyhomes.com/");
		LOGGER = new CommunityLogger("Mattamy Homes");
	}

	public void innerProcess() throws Exception {

		U.setUpGeckoPath();
		driver = new FirefoxDriver();

		String mainHtml = U.getHTML("https://www.mattamyhomes.com/");

		String stateSection[] = U.getValues(mainHtml, "{\"state\"", "doNotSearch\":false}");

		JsonParser parser = new JsonParser();

		int totalCount = 0;

		for (String stateSec : stateSection) {
			if (!stateSec.contains("country\":\"USA"))
				continue;
//			U.log("stateSec: " + stateSec);

			String region = U.getSectionValue(stateSec, "\"", "\"");
//			U.log("region -->" + region);

			String url = "https://mattamyhomes.com/sitecore/api/layout/render/jss?item=/search-data&sc_apikey={8C3D041E-BB12-4CC6-908A-4CF43E542E5B}&market="
					+ region + "&IsState=1";
//			U.log(url);
//			U.log(U.getCache(url));
			String html = U.getHTML(url);

			JsonObject obj = (JsonObject) parser.parse(html).getAsJsonObject().get("sitecore").getAsJsonObject()
					.get("route").getAsJsonObject().get("placeholders").getAsJsonObject().get("jss-main")
					.getAsJsonArray().get(0).getAsJsonObject().get("fields").getAsJsonObject();

			/*
			 * community collection
			 */
			JsonArray commArr = obj.get("communityCards").getAsJsonObject().get("value").getAsJsonArray();
//			U.log("Comm. count ::" + commArr.size());

			JsonArray otherCommArr = obj.get("mpcCards").getAsJsonObject().get("value").getAsJsonArray();
			// U.log("Other Comm. count ::"+otherCommArr.size());

			commArr.addAll(otherCommArr); // community collection
//			U.log("Community count ::" + commArr.size());

			totalCount += commArr.size(); // for total count
			// U.log(">>>>>>>****"+totalCount);

			/*
			 * plan home collection
			 */
			ArrayList<String> plansData = new ArrayList<>();
			JsonArray planCards = obj.get("planCards").getAsJsonObject().get("value").getAsJsonArray();

			for (JsonElement planObj : planCards) {
				plansData.add(planObj.toString());
			}
			// U.log(plansData.size());

			/*
			 * quick home collection
			 */
			ArrayList<String> qmiData = new ArrayList<>();
			JsonArray qmiCards = obj.get("qmiCards").getAsJsonObject().get("value").getAsJsonArray();

			for (JsonElement qmiObj : qmiCards) {
				qmiData.add(qmiObj.toString());
			}
			// U.log("qmiData ::"+qmiData.size());

			/*
			 * send community data for extract here
			 */
			for (JsonElement comObj : commArr) {
				String comUrl = "https://mattamyhomes.com" + comObj.getAsJsonObject().get("url").getAsString();
				// U.log(comUrl);
				// U.log(">>>>11111");
				addDetails(comObj.toString(), comUrl, plansData, qmiData);
				// break;
			}
			// break;
		} // eof for outer

//		U.log("total count :::" + totalCount);

		LOGGER.DisposeLogger();
		driver.quit();
	}

	// TODO : Extract Communities details here..
	private void addDetails(String comSec, String comUrl, ArrayList<String> plansData, ArrayList<String> qmiData)
			throws Exception {
//		 if (j>=70)
//		 if (j>=50 && j<=55)
//		 try{
		{
//			 if (!comUrl.contains("https://mattamyhomes.com/texas/dallas/farmers-branch/kensington")) return;
//			if(!comUrl.contains("https://mattamyhomes.com/florida/naples-fort-myers/naples/compass-landing")) return;

			U.log("count::" + j + "\ncomUrl::" + comUrl);
		//	U.log("count::" + j + "\ncomUrl::" + comSec);
			U.log("Path::" + U.getCache(comUrl));
			String comHtml = getHtml(comUrl, driver);
			String remSec1 = U.getSectionValue(comHtml, "pageEditing", "</script><script>");
			comHtml = comHtml.replace(remSec1, "");
			//String backupHtm = comHtml;
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("*****************REPEATED**************" + comUrl);
				dup++;
				return;
			}
			if (comUrl.contains("Register.aspx")) {
				LOGGER.AddCommunityUrl("*****************Register**************" + comUrl);
				dup++;
				return;
			}

			if (comUrl.equals("https://mattamyhomes.com/arizona/phoenix/queen-creek/malone-estates-mpc")
					| comUrl.equals("https://mattamyhomes.com/florida/jacksonville/st-johns/rivertown")
					| comUrl.equals("https://mattamyhomes.com/florida/port-st-lucie/port-st-lucie/tradition")
					| comUrl.equals("https://mattamyhomes.com/florida/sarasota-bradenton/venice/wellen-park")
					| comUrl.equals("https://mattamyhomes.com/florida/orlando/celebration/celebration")) {
				LOGGER.AddCommunityUrl("*****************Main communities**************" + comUrl);
				dup++;
				return;
			}

			LOGGER.AddCommunityUrl(comUrl);
			U.log("ComSec---------" + comSec);

			// ======= ComID =======================
			String comId = U.getSectionValue(comSec, "\"idCommunity\":\"{", "}");
			U.log("comId---------" + comId);
			String homeCards = U.getSectionValue(comHtml, "\"cards\":[{\"", "}]}}}}");
			//U.log(homeCards);
			String descriptionsec = U.getSectionValue(comHtml,
					",\"headline\":\"Designed For the Way You Live \",\"copy\":\"", "\"showFavorites\":true}}}}");
			// ======================================= remove;
			// Sec==================================
			String rem = U.getSectionValue(comHtml, "template-compare-community", " </body>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");

			rem = U.getSectionValue(comHtml, "<head>", "</head>");
			if (rem != null)
				comHtml = comHtml.replace(rem, "");

			String jss = U.getSectionValue(comHtml, "><script type=\"application/json\" id=\"__JSS_STATE__\">",
					"</script><script>(function(document)");// );</script><div style=\"width:0px; h
			if (jss != null)
				comHtml = comHtml.replace(jss, "");

			String mypropSec = U.getSectionValue(comHtml, "<span class=\"richtext\">", "</span></p>");

		//	 U.log("kkk222"+comHtml);
			
			
			// =============================================Community
			// Name==============================================
			String comName = U.getSectionValue(comSec, "\"title\":\"", "\""); // "\"", "\"");
			U.log("Com Name::::::::" + comName);

			if (comName != null) {
				comName = comName.replaceAll("- A Master-Planned Community", "");
				comName=comName.replace("Solara Resort", "Solara");
			}

			// ============================================Address
			// Sec==================================================

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			
			String addSec=U.getSectionValue(comHtml, "<h3 class=\"text-white font-graphie tracking-tighter leading-relaxed\">", "</h3>");
			
			if(addSec==null)
			    addSec = U.getSectionValue(comHtml, "<a href=\"https://maps.google.com/maps?q=", "</div>");

			U.log(">>>>>addSec : " + addSec);
			if (addSec != null) {
				addSec = addSec.replace("Timberdale Ave", "4357 Cloud Hopper Way").replace("Fort Hamer Rd at Golf Course Rd", "12002 Golf Course Rd").replace("Sold out  Tampa Florida 33625", "Tampa Florida 33625").replace("Orando", "Orlando")
						.replace("12589 N. Ellie Ave From Tangerine/Midfield Rd - N on Midfield Rd. Around roundabout. Continue on Mike Etter Bvd. Left at Rihl Dr.", "12589 N. Ellie Ave");
				
				//addSec = U.getSectionValue(addSec.replace("</a><a ", ",<a "), "noopener noreferrer\">", "</a>");
			
				addSec = addSec.replaceAll("COMING SOON - nearby community at|Sold out,|NOW SOLD OUT,|NOW SOLD OUT|SOLD OUT,|Coming Soon[,]",
						"");
				addSec = U.getNoHtml(addSec);
				U.log("AddSec: " + addSec);
				add = U.getAddress(addSec);
			}
			if (comUrl.contains("/st-johns/rivertown/gardens")) {
				addSec = "90 Lanier Street , Saint Johns, FL 32259";
				U.log(addSec);
				add = U.getAddress(addSec);
			}
			add[0] = add[0].replace("11722 Wrought Pine Loop, 11722 Wrought Pine Loop", "11722 Wrought Pine Loop")
					.replace(" %26 ", " & ").replaceAll(
							"Selling by appointment only|By Appointment Only|Community location\\:, \\(just off Wesley Chapel Blvd\\. south of Hay Rd\\.\\)|COMING SOON|,",
							"");
			// ===============================================Lat-Long==================================================
			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
//			if (comUrl.contains("https://mattamyhomes.com/florida/orlando/celebration/celebration/island-village")) {
//				add[0] = "Celebration Blvd";
//				add[1] = "Orlando";
//				add[2] = "FL";
//				add[3] = "33896";
//			}
			latlong[0] = U.getSectionValue(comSec, "latitudeCommunity\":\"", "\"");
			latlong[1] = U.getSectionValue(comSec, "\"longitudeCommunity\":\"", "\"");
			U.log(Arrays.toString(latlong));
			if ((add[0] == null || add[0] == ALLOW_BLANK || add[0].length() < 4 || add[0].contains("Coming Soon")
					|| add[2] == null) && latlong[0] != null || add[2].contains("US")) {

				add = U.getAddressGoogleApi(latlong);
				U.log("============");
				// if(add == null) add = U.getGoogleAddressWithKey(latlong);
				if (add == null)
					add = U.getAddressHereApi(latlong);
				geo = "TRUE";
			}

			if (add[0] != null && latlong[0] == null) {

				latlong = U.getlatlongGoogleApi(add);
				if (latlong == null)
					latlong = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			if (add[3] == ALLOW_BLANK && latlong[0] != null) {
				String add1[] = U.getAddressGoogleApi(latlong);
				if (add1 == null)
					add1 = U.getAddressHereApi(latlong);
				add[3] = add1[3];
				geo = "TRUE";
			}
			if (add[2].length() > 2) {
				add[2] = USStates.abbr(add[2]).trim();
			}
			
			
			//-----------------	AVAIALABLE FLOORPLANS ---------------------------------
			String floorData = ALLOW_BLANK;
			
			if(comHtml.contains("<li class=\"BrainhubCarouselItem") && comHtml.contains("</button></div></div></li>")) {
				
				String[] floorPlans = U.getValues(comHtml, "<li class=\"BrainhubCarouselItem", "</button></div></div></li>");
				U.log("floorPlans length: "+floorPlans.length);
				
				for(String floor:floorPlans) {
					
					String floorlink = "https://mattamyhomes.com" + U.getSectionValue(floor, "<a href=\"", "\"");
					U.log("floorlink: "+floorlink);
					
					String floorhtml = U.getHtml(floorlink, driver);
					floorData += U.getSectionValue(floorhtml, "Home Design Details", "</div></div></section>");
					//U.log("floorData: "+floorData);
					//break;
				}
			}
			

			// ============================FlorPlan And QuickPlan
			// Data=============================

			String planHtml = ALLOW_BLANK;
			Iterator<String> plan = plansData.iterator();

			int countPlan=0;
			for(int i=0;i<plansData.size();i++) {
				if(plansData.get(i).contains(comId)) {
					String planUrl = "https://mattamyhomes.com"
							+ U.getSectionValue(plan.next(), "\"url\":\"", "\"");
					U.log("planUrl :" + planUrl);

					String pHtml = U.getHTML(planUrl);
					if (pHtml.contains("courtyard")) {
						U.log("Found");
					}
					planHtml += plan.next();

					planHtml += U.getSectionValue(pHtml, ">Request Updates</div>", "</span></p></div></div></div>");
					countPlan++;
				}
			}
			U.log(countPlan);
			
//			while (plan.hasNext()) {
//
//				if (comId == null)
//					break;
//				if (plan.next().contains(comId)) {
//					try {
//
//						String planUrl = "https://mattamyhomes.com"
//								+ U.getSectionValue(plan.next(), "\"url\":\"", "\"");
//						U.log("planUrl :" + planUrl);
//
//						String pHtml = U.getHTML(planUrl);
//						if (pHtml.contains("courtyard")) {
//							U.log("Found");
//						}
//						planHtml += plan.next();
//
//						planHtml += U.getSectionValue(pHtml, ">Request Updates</div>", "</span></p></div></div></div>");
//
//					} catch (Exception e) {
//						// TODO: handle exception
//					}
//				}
//			}

			// U.log("Plan====="+planHtml);

			
			
			String quickHtml = ALLOW_BLANK;
			Iterator<String> qmi = qmiData.iterator();
			
			
			int countQuickHome2=0;
			for(int i=0;i<plansData.size();i++) {
				if(plansData.get(i).contains(comId)) {

						U.log("quick link::::::::::" + "https://mattamyhomes.com"
								+ U.getSectionValue(qmi.next(), "\"url\":\"", "\""));
						quickHtml += qmi.next() + U.getSectionValue(
								U.getHTML(
										"https://mattamyhomes.com" + U.getSectionValue(qmi.next(), "\"url\":\"", "\"")),
								">Request Updates</div>", "</span></p></div></div></div>");
					countQuickHome2++;
					
				}
			}
			U.log("quick Home count :: "+countQuickHome2);
			
			
			int myQcount = 0;
			int nqmi=0;
			int mqmi=0;

//			while (qmi.hasNext()) {
//               //  U.log("==="+qmi.next());
//				if (comId == null)
//					break;
//				if (qmi.next().contains(comId)) {
//					myQcount++;
//					try {
//						U.log("quick link::::::::::" + "https://mattamyhomes.com"
//								+ U.getSectionValue(qmi.next(), "\"url\":\"", "\""));
//						quickHtml += qmi.next() + U.getSectionValue(
//								U.getHTML(
//										"https://mattamyhomes.com" + U.getSectionValue(qmi.next(), "\"url\":\"", "\"")),
//								">Request Updates</div>", "</span></p></div></div></div>");
//					
//						
//					
//					} catch (Exception e) {
//						// TODO: handle exception
//					}
//					
//					
//					
//					///june 22
////					if(qmi.next().contains("\"availableDateMessage\":\"Ready October 2022\"")||qmi.next().contains("\"availableDateMessage\":\"Ready November 2022\"")||qmi.next().contains("\"availableDateMessage\":\"Ready December 2022\"")||qmi.next().contains("\"availableDateMessage\":\"Ready September 2022\"")||qmi.next().contains("\"availableDateMessage\":\"Ready August 2022\"")||qmi.next().contains("\"availableDateMessage\":\"Ready Jully 2022\""))
////					{
////						nqmi++;
////					}
////				
//				
//				}
//				
//			}
         U.log("quickhmCount= "+myQcount);
         U.log("quickhmCount= "+mqmi);

			// U.log("=============="+quickHtml);
			// ================== Quick Data =====================
			String quickData = "";
			String[] quick = null;
			if (quickHtml != null) {

				quick = U.getValues(quickHtml, "<div class=\"sc-oTBUA hXGkGv", "</a></div></div>");

				for (String url : quick) {

					url = U.getSectionValue(url, "href=\"", "\"");
					U.log("////////////////////////////" + url);
					url = "https://mattamyhomes.com" + url;
					U.log("Quick URl: " + url);
					try {
						quickData += U.getHtml(url, driver);
					} catch (Exception e) {
						// TODO: handle exception
					}
				}

			}

			String murl = U.getSectionValue(comHtml, "a href=\"/search?productType=qmi", "\"");
			U.log("move in url-----------------" + murl);
			String Qhtml = null;
			if (murl != null) {
				murl = "https://mattamyhomes.com/search?community=" + comName.replaceAll("\\s+", "+")
						+ "&country=USA&hideMap=true&metro=" + U.getSectionValue(comSec, "\"metro\":\"", "\"")
						+ "&productType=qmi";
				U.log("murl::" + murl);
				Qhtml = U.getHtml(murl, driver);
			}
			quickData = quickData + Qhtml;
			// ==============================================================Price &&
			// SF============================================

			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec = comSec.replaceAll("0s|0S|0's|0's|0&#39;s", "0,000").replace("'s", ",000");
			comHtml = comHtml.replaceAll("0s|0S|0's|0's|0'S|0&#39;s", "0,000").replace("'s", ",000");
			planHtml = planHtml.replaceAll(
					"\"price\":\"\\$395,990\",\"|\"price\":314700|\"price\":249700|price\":239990|price\":245990|\"price\":260000,",
					"");
			// String[] prices = U.getPrices(comHtml+comSec+planHtml+quickHtml, "PRICED FROM
			// THE \\$\\d{3},\\d{3}|PRICING FROM \\$\\d{3},\\d{3} -
			// \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</h4>|price\":\"\\$\\d{3},\\d{3}|price\">\\$\\d{3},\\d{3}|\"price\":\\d{6}|Upper
			// \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|Mid
			// \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}\\+|Mid-\\$\\d{3},\\d{3}", 0);

			String pagePrices[] = U.getValues(comHtml,
					"<p class=\"text-white text-2xl font-trade-gothic-20 leading-6 mt-2\">", "<");
			for (String pr : pagePrices) {

				U.log("page prices" + pr);
			}
			String remSec = U.getSectionValue(comHtml, "Explore neighborhoods in this community",
					"sc-fznLxA gAWKOS bg-footer flex flex-col items-center pt-12 lg:mb-0 pb-12 w-screen flex flex-col items-center justify-start bg-footer flex flex-col items-center pt-12 lg:mb-0 pb-12");
			if (remSec != null)
				comHtml = comHtml.replace(remSec, "");

			// ======== Plan Data =================================
			String allPlan = ALLOW_BLANK;
			if (comHtml.contains("/search?productType=plan")) {

				String url = "https://mattamyhomes.com/search?community=" + comName.replaceAll("\\s{1,}", "+")
						+ "&country=USA&hideMap=true&metro="
						+ U.getSectionValue(comSec, "\"metro\":\"", "\"").replaceAll("\\s{1,}", "+")
						+ "&productType=plan";
				U.log("product type plan:: " + url);
				allPlan += U.getHtml(url, driver);

			}
			comHtml = comHtml.replace("0s", ",000");
			String[] prices = U.getPrices(comHtml + comSec + homeCards +quickHtml+ quickData + allPlan,
					"Starting From \\$\\d{3},\\d{3}</a>|Starting From \\$\\d{3},\\d{3}|Starting in the \\$\\d+,\\d+|> \\$\\d{3},\\d{3}</p>|>\\$\\d{3},\\d{3}<|mid \\$\\d{3},\\d{3}|price\":\"\\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|the Upper \\$\\d{3},\\d{3}|PRICED FROM THE \\$\\d{3},\\d{3}|PRICING FROM \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</h4>|price\":\"\\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}\\+|Mid-\\$\\d{3},\\d{3}|\"price\": \\d{6}|\"price\":\\d{6}|Starting From \\$\\d{3},\\d{3}",
					0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("minPrice::" + minPrice + " maxPrice::" + maxPrice);

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

			comHtml = comHtml.replace("<td class=\"space\">2,800+</td>", "2800 Sq. Ft.")
					.replaceAll("label\":\"\\d,\\d+ Sq. Ft.", "")
					.replaceAll(
							"The Bridges’ \\d,\\d+ sq. ft. clubhouse|Enjoy over \\d,\\d+ sq. ft. of amenity|</p>\\s*<p class=\"text-center font-graphie text-mattamy-blue text-base leading-5 mb-2\">",
							" ")
					.replace("<td class=\"space\">1840 - 2840</td>", "1840-2840 SQ. FT")
					.replaceAll("<td class=\"space\">1,700 - 3,000</td>", "1,700-3,000 SQ. FT");
			planHtml = planHtml.replaceAll(
					"The \\d,\\d+ sq. ft. Atlantic|label\":\"\\d,\\d+ Sq. Ft.\"|ruler\",\"label\":\"\\d,\\d+ - \\d,\\d+ Sq. Ft.|throughout the \\d,\\d{3} sq. ft. Gateway",
					"");

			
		//	U.log("MMMMMMMMM "+Util.matchAll(comHtml + comSec + planHtml + quickHtml + descriptionsec, "[\\w\\s\\W]{30}1,333[\\w\\s\\W]{30}", 0));
			
			String[] sqft = U.getSqareFeet(
					comHtml + comSec + planHtml + quickHtml.replaceAll("label\":\"\\d,\\d+ Sq. Ft.", "")
							+ descriptionsec,
					"ranging from \\d{3} sq ft. to \\d,\\d{3} sq ft.|\\d,\\d{3} Sq. Ft.</span>|\\d,\\d{3} Sq. Ft.|homes ranging from \\d,\\d{3} sq ft. to \\d,\\d{3}\\+ sq ft.|\\d{1},\\d{3} - \\d{1},\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3}\\+ square feet|\\d,\\d{3} to \\d,\\d{3} square foot|offer \\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} sq ft to \\d,\\d{3} sq ft|from \\d,\\d{3} sq ft\\. to \\d,\\d{3} sq ft|<td class=\"space\">\\d,\\d{3} - \\d,\\d{3}</td>| <td class=\"space\">\\d{4}-\\d{4}</td>|squareFootageMax\":\\d{4}|\\d{4}-\\d{4} SQ. FT|\\d,\\d{3}\\s*–\\s*\\d,\\d{3}[+]*\\s*SQ.\\s*FT|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3}\\s*-\\s*\\d,\\d{3}[+]* sq.\\s*ft|\\d,\\d{3} TO \\d,\\d{3}(?) SQ. FT|Sq ft.</dt>\\s*\\n*\\s*<dd class=\"space\">\\d{4}|squareFootage\":\\d{4}|squareFootageMin\":\\d{4}|\\d{4} Sq. Ft|\\d,\\d{3} SQ. FT",
					0);

			// U.log("\n>>>>>>>>>>>>>>>>");
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft:" + minSqft + " maxSqft:" + maxSqft);
			if (comUrl.contains("https://mattamyhomes.com/florida/orlando/kissimmee/soleil")) {
				minPrice = ALLOW_BLANK;
				maxPrice = ALLOW_BLANK;
				minSqft = ALLOW_BLANK;
				maxSqft = ALLOW_BLANK;
			}
			if (comUrl.contains("https://mattamyhomes.com/north-carolina/raleigh/garner/oak-park")) {
				minPrice = "$448,900";
				maxPrice = "$541,900";
				minSqft = "2500";
				maxSqft = "3471";
			} // cache issue
			
			if(comUrl.contains("https://mattamyhomes.com/florida/sarasota-bradenton/lakewood-ranch/harmony-at-lakewood-ranch")) {
				minSqft = "1333";
				maxSqft = "1807";
			}//cache issue
				// ==============================================================Community
				// type============================================
			comHtml = comHtml.replaceAll(
					"aggregated|Nearby golf|near golf|nearby to Orange County National Golf|NC Ridgewater Lake", "")
					.replace(" lake view homesites with", " lake community view homesites with");
			String comType = ALLOW_BLANK;

			String comTypeSec = comHtml + comSec;
			comTypeSec = comTypeSec.replace("waterfront dining", "");
			comType = U.getCommType(comTypeSec);

			U.log("community type************" + comType);
			// ==============================================================Property
			// type============================================

			String propType = ALLOW_BLANK;
			comHtml = comHtml.replaceAll("GTA Condos|gtacondo", "").replace("luxury, quality and ", "luxury home");
			comHtml = U.removeSectionValue(comHtml, "<input type=\"hidden\" name=\"locationDataUrl",
					"All Contacts</a></div>");
			comHtml = comHtml.replaceAll("<img=(.*?)>", "")
					.replaceAll("single- and two-story", "single-story and two-story")
					.replace("Single and Two-Story", " 1 Story  2 Story "); // .replace("one and two-story", " 1 Story 2
																			// Story ");
			planHtml = planHtml.replace("productLine\":\"Estate Series\"", " Estate Series ")
					.replaceAll(
							"<div class=\"headline\">Craftsman</div>|options, including Craftsman| - Craftsman</div>",
							"Craftsman style details")
					.replace("_craftsman_", " craftsman style ");
			// .replaceAll("elevationfarmhouse|_farmhouse_|isCondo|garage apartment|detached
			// garage", "");

			String rm = U.getSectionValue(planHtml, "{\"sitecore\":{\"context\":{\"pageEditing\"",
					"</script></body></html>");

			// U.writeMyText(comHtml);

			planHtml = planHtml.replaceAll("isCondo", "");

			planHtml = planHtml.replace("isCondo", "replace");
			comHtml = comHtml.replace("owner,000", "owner's").replaceAll("isCondo|Gaines Model Farmhouse Elevation", "")
					.replace("Exterior styles include Craftsman, Farmhouse, and Florida Traditional and",
							"Exterior styles include Craftsman style, Farmhouse style homes, and Florida Traditional and");
			comSec = comSec.replaceAll("isCondo", "");

			comHtml = comHtml.replace("Traditional School", "")
					.replace(" including Craftsman, Rustic Spanish", " including craftsman style, Rustic Spanish")
					.replaceAll("\"value\":\"Townhome|The Preserve at La Paloma Patio in Sun City", "");
			
			
			//U.log("JJJJ"+Util.matchAll(planHtml + comHtml + quickData, "[\\w\\s\\W]{70}loft[\\w\\s\\W]{50}",0));
			
			propType = U.getNewPropType((planHtml + comHtml +quickData + floorData).replaceAll("\"productLines\":\"Executive Series\"", "").replaceAll(
					"\"value\":\"Townhome\"|<div class=\"headline\">Craftsman</div>|options, including Craftsman| - Craftsman</div>",
					"Craftsman style details").replaceAll(
							"and any HOA fees|isCondo|courtyard\\.jpg|Executive Series\"|with multi level hanging racks|craftsman_groundfloorplan|Johnson Ranch|courtyardjpg|feel of a manor home|elevationcraftsman|elevationcolonial|Elevation Colonial|headline\">Colonial|_colonial_|\"alt\":\"(.*)\"",
							""));
		
			
			if (comUrl.contains("sarasota/sunrise-preserve-at-palmer-ranch"))
				propType = U.getNewPropType(comHtml + comSec);
			U.log("propType************  " + propType);

			// ====================== Property type
			// ============================================

			String dType = ALLOW_BLANK;

			planHtml = planHtml.replace("_colonial_ground", " Colonia style ")
					.replaceAll("elevationcolonial|isCondo\":false", "");
			// U.log(planHtml);

			dType = U.getNewdCommType((comHtml + comSec + planHtml  + quickData + floorData).replace("2-story", "2 Story").replaceAll("1st floor|1st-floor", "1 Story").replaceAll(
					"Mattamy's Classic Series of three-story|\"label\":\"3 Stories\"|Multi-Level Covered Deck|Ranch\"|brick ranch|-ranch|multi level hanging racks|<p>The 3-story Harmony plan",
					""));
//floorData
//			U.log("MMMMMMMMM "+Util.matchAll(  floorData, "[\\w\\s\\W]{30}Alameda[\\w\\s\\W]{30}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll(  quickData, "[\\w\\s\\W]{30}Alameda[\\w\\s\\W]{30}", 0));
			 
//			 U.log("MMMMMMMMM "+Util.matchAll( comSec, "[\\w\\s\\W]{30}l bedrooms on the second floor each have their own walk-in closets and share a second full bath.[\\w\\s\\W]{30}", 0));
//			 U.log("MMMMMMMMM "+Util.matchAll( planHtml + quickHtml + quickData + floorData, "[\\w\\s\\W]{30}three-story[\\w\\s\\W]{30}", 0));

			U.log("dType :: "+dType);
			// U.log("HELLO--");

			// ==================Property Status============================================

			comHtml = comHtml.replace("Second Phase of homesites is now available", "Second Phase now available");
			comHtml = comHtml.replace("new Phase of homesites is now available", "").replace("COMING&nbsp;FALL 2019",
					"COMING FALL 2019");
			comHtml = comHtml.replace("Just Released - New Phase of Homesites", "Just Released New Phase of Homesites")
					.replace("Coming in Fall 2021", "Coming Fall 2021")
					.replace("New 70' Homesites Released", "New Homesites Released")
					.replace("The Final Phase is Now Open", "The Final Phase Now Open")
					.replace("Limited homesites are currently available", "Limited homesites currently available");

			comSec = comSec.replace("</span> Home Designs Available", " Home Designs Available").replaceAll(
					"\"bannerText\":\"Now Selling\"|\"priceDesc\":\"Coming Soon\"|\"status\":\"Coming Soon\"|Models Coming Early 2020|New Home Designs - Now Available|Basement Quick Move-In Homes Now Available|\"bannerText\":\"Grand Opening! \"|\"bannerText\":\"Now Open\"|coming soon to Buckeye|Amenities Now Open|PRICING COMING SOON|ncentives and the first release|gated community, only a few homes remain.|Models Now Open|park is now open|center is now open|models are now open|homes coming soon to Chandler|Only 3 Quick Move-In Homes Remaining|Quick Move-In Homes From|Park Now Open|estate homes now available |resort community now availabl|Patio Homes coming soon|highrise\",\"bannerText\":\"Now Selling New Phase",
					"").replaceAll(
							"bannerText\":\"(Now Selling!|Final Opportunities)|highrise\",\"bannerText\":\"Grand", "");
			comHtml = comHtml.replace("NOW SELLING IN PHASE I AND PHASE II", "NOW SELLING PHASE I AND PHASE II")
					.replaceAll(
							"\"priceDesc\":\"Coming Soon\"|\"status\":\"Coming Soon\"|Models Coming Early 2020|New Home Designs - Now Available|PRICING COMING SOON|Basement Quick Move-In Homes Now Available|coming soon to the heart|\"bannerText\":\"Now Selling\"|status\":\"Coming Soon\"|Models Now Open|TWO NEW MODEL HOMES\\s*NOW OPEN FOR TOURING|amenities are now open|gated community, only a few homes remain|park is now open|Grand Opening Celebration|Amenity Center Grand Opening|center is now open|Models Are Now Open|models are now open|quick move|(c|C)enter is (N|n)ow|amenities are now|pricing\">|street from our nearly sold",
							"");

			String headline = U.getSectionValue(comHtml, "<div class=\"headline\">", "community-contact");
			// U.log("headline--"+headline);

			String description = U.getSectionValue(comHtml, "<section id=\"ProductOverview\"", "</section>"); // "<div
																												// class=\"community-intro-wrap\">",
																												// "</div>");

			if (description != null)
				description = description.replace("Townhomes Coming in 2019", "Townhomes Coming 2019")
						.replace("new selection of single-family homes were just released",
								"new selection just released")
						.replaceAll(
								"and grand opening opportunities|Family Homes coming soon|coming soon to Buckeye|PRICING COMING SOON",
								"")
						.replace("Townhomes Coming in 2020", "Townhomes Coming 2020")
						.replace("New larger homesites are now available", "New larger homesites now available")
						.replace(" USDA eligible, providing 100% financing", " USDA eligible 100% financing")
						.replace("Current Phase of Homes is Sold Out", "Current Phase Sold Out");

			rem = "floorplans coming soon|villas are now available|New larger homesites are now available|Family Homes coming soon|A new community coming soon to Buckeye|content=\"A new community coming|family homes now open in Mesa|highrise\",\"bannerText\":\"New Phase Open|Valrico\\. New homesites are now available|out with all homesites|model homes are now|New Models - Now|of Estate Homesites Coming Soon|with grades K-8 opening Fall 2019|Pricing Coming Soon|opening information|Virtual Grand|open in the heart|Tours Now|villas is now|home opportunities remain at Crestwood";

			String comPage = U.getSectionValue(comHtml,
					"%>\">Coming|floorplans coming|status == 'Coming|community-intro-wrap\">", " </div>")
					+ U.getSectionValue(comHtml, "<div class=\"subhead\">", "<");
			String mainPageStat = U.getSectionValue(comHtml, "-mt-3 leading-7\"><span class=\"richtext\">", "<");
			// U.log("stat"+mainPageStat);
			String subheadline = U.getSectionValue(comHtml, "<div class=\"subhead\">", "<");
			// U.log(subheadline);
			String quickSec = U.getSectionValue(comHtml,
					"border-mattamy-blue-dark\" aria-label=\"\"><div href=\"/search?productType=qmi", "</button>");

			// U.log("####333"+quickSec);
			if (mainPageStat != null)
				mainPageStat = mainPageStat.replace("Arriving to the town of Queen Creek in late 2022 ",
						"Arriving late 2022");

			String commstatus = U.getSectionValue(comSec, "communityStatus\":\"", "\",\"");
			
			String upperLine = ALLOW_BLANK;
			upperLine = U.getSectionValue(comHtml, "<span class=\"richtext\">", "</span>");
			
			String upperHeading = ALLOW_BLANK;
			upperHeading = U.getSectionValue(comHtml, "<p class=\"text-center font-trade-gothic-20 uppercase text-sm tracking-wide leading-3 mt-1\">", 
					"</p>");

			String propertyStatus = U.getNewPropStatus(
					(commstatus + quickSec + mainPageStat + comPage + description + headline + subheadline + upperLine + upperHeading)
							.replace("Coming to Harnett County Spring 2022", "Coming Spring 2022")
							.replace("Coming SoonnullGrand Opening", "Grand Opening").replace("Coming to Lillington in 2023", "Coming 2023")
							.replaceAll(
									"Coming Soonnullnullnullnull class=\"sc-fzoMdx|community coming soon to Garner|Grand Opening - Two beautifully styled townhome|Grand Opening of New Models|coming soon to nearby Citrus Park|Move-In Homes in this beautifully|Grand opening of new models|4 new model townhomes are now open.|we are now open by appointment only|New Mattamy townhomes are now selling at our nearby|for new single-family homes now selling.|Now selling by appointment|Preview Appointments are now available|communityType\":\"highrise\",\"bannerText\":\"Final Opportunity\"|bannerText\":\"Coming|price\":\"Coming Soon|>\">Coming Soon</div>|Coming Soon'\\)|Coming Soon</td>|Site Plan Coming|no-break\">Coming Soon - New Townhomes|Coming This Spring/Summer|priceDesc\":\"Quick Move|description\":\"Coming Soon\"|content=\"Coming Soon\"|now selling beautiful townhomes|New larger homesites now available|acres and is currently",
									"")
							.replaceAll(rem, ""));
			U.log("propertyStatus before =========== " + propertyStatus);
			
			propertyStatus=propertyStatus.replace("Quick Move-in Homes", "Quick Move-In");
			propertyStatus=propertyStatus.replaceAll("Quick Move-In|, Quick Move-In|Quick Move-In, ", "");
			
			
			if((quickData.contains("Ready July 2022")) || quickHtml.contains("Ready August 2022")) {
				if(!propertyStatus.contains("Quick Move")&& propertyStatus.length()>5)
				propertyStatus = propertyStatus + ", Quick Move-In";
				else
					propertyStatus="Quick Move-In";
			}

			U.log("propertyStatus =========== " + propertyStatus);
            
//			propertyStatus=propertyStatus.replace("Coming Soon, Coming Summer 2022", "Coming Summer 2022");
//			propertyStatus=propertyStatus.replace("Coming Soon, Coming Early 2022", "Coming Early 2022");
			
			
			U.log("propertyStatus: " + propertyStatus);
			
			U.log("MMMMMMMMM "+Util.matchAll(commstatus + quickSec + mainPageStat + comPage + description + headline + subheadline + upperLine, "[\\w\\s\\W]{30}coming late[\\w\\s\\W]{30}", 0));
//			U.log("MMMMMMMMM "+Util.matchAll(commstatus + quickSec + mainPageStat + comPage + description + headline + subheadline + upperLine, "[\\w\\s\\W]{30}now selling[\\w\\s\\W]{30}", 0));
//			FileUtil.writeAllText("/home/shatam-10/Desktop/data/statusSS.txt", commstatus + quickSec + mainPageStat + comPage + description + headline + subheadline + upperLine);
			
			// =========== SiteMap ====================
			String unitCount = ALLOW_BLANK;
			//https://mattamy.secure.footprint.net/-/media/images/mattamywebsite/usa/tucson/glenmere-at-gladden-farms/masthead-image-or-video/mattuc_glenmereatgladdenfarms_sitemap-1800x1200.jpg
//			if (comHtml.contains("Take a closer look at the community sitemap and get familia")&&!(comHtml.contains("_sitemap-1800x1200.jpg")||comHtml.contains("_1800x1200_map.jpg"))) {

				// https://medialabazure.blob.core.windows.net/productdata/Mattamy%20Homes_26/Arroyo%20Seco_85798/Arroyo%20Seco_78522/Arroyo%20Seco_78522.svg
//				String sitemMapIframe = U.getSectionValue(comHtml,
//						"<iframe title=\"floorplan\" style=\"min-height: 500px; width: 100%;\" src=\"", "\"");
//				// String sitemapDataHtml =
//				// getHTML("https://argo.ml3ds-cloud.com/api/communities/"
//				// + U.getSectionValue(sitemMapIframe, "scp/", "/site") +
//				// "?dataLevel=2&filterToActiveOnly=true");
//				U.log(sitemMapIframe);
//				String siteMapUrl = "https://medialabazure.blob.core.windows.net/productdata/Mattamy%20Homes_26/"
//						+ comName.replace("Brookside at ", "").replace(" ", "%20") + "_"
//						+ U.getSectionValue(sitemMapIframe, "scp/", "/site") + "/"
//						+ comName.replace("Brookside at ", "").replace(" ", "%20") + "_"
//						+ U.getSectionValue(sitemMapIframe, "site-map/", "?") + "/"
//						+ comName.replace("Brookside at ", "").replace(" ", "%20") + "_"
//						+ U.getSectionValue(sitemMapIframe, "site-map/", "?") + ".svg";
//				U.log(siteMapUrl);
//				String siteMaphtml = U.getSectionValue(comHtml, "<g id=\"LotMap_BG\">", "<script src=\"");
//				if (siteMaphtml != null) {
					// String lotSec = U.getSectionValue(siteMaphtml, "<g id=\"Lots\">", "<g
					// id=\"Future\">");
			if(comHtml.contains("Explore the community")) {	
			String lotSec=U.getSectionValue(comHtml, "<g id=\"Lots\">", "<g id=\"Street_Names\">");
		     if(lotSec==null){
			  lotSec=U.getSectionValue(comHtml, "<div class=\"parent\" id=\"ownermaplayoutdiv\">", "</svg>") ;
		      }
		    if(lotSec!=null){//dt 18 may 
		    U.log("kkk"+Util.match(comHtml, "<g id=\"Street_Names\">"));
		    
			String lots[] = U.getValues(lotSec, "<g id=\"TEXT_", "</g>");//2nd commHtml dt 18 may22
	      	U.log(lots.length);
	      	if(lots.length<=0) {
	      		lots=U.getValues(lotSec, "<polygon id=\"lot", "</polygon>");
	      	}
					if (comHtml.contains("<g id=\"Future\">")) {
						String futureLots = U.getSectionValue(comHtml, "<g id=\"Future\">",
								"<g id=\"Street_Names\">");
						String futureLotData[] = U.getValues(futureLots, "<polygon style=\"fill:#B3B3B3;\"", "</polygon>");//\"/>
						U.log(futureLotData.length);
						unitCount = (lots.length - (futureLotData.length * 2)) + "";
					} else {
						unitCount = (lots.length) + "";
					}
					if(unitCount.equals("0"))
						unitCount=ALLOW_BLANK;
			}//dt 18 amy
					U.log("No.Of UNITs"+unitCount);
						
				}
			U.log("No.Of UNITs2"+unitCount);
//			}
			// =========== Notes ====================
			String notes = U
					.getnote(comHtml.replaceAll("Open For Sale|preSellingHome|homesites now released for sale", ""));
			add[0] = add[0].replace("By Appointment Only: ", "");

			/*
			 * if(comUrl.contains(
			 * "https://mattamyhomes.com/florida/orlando/orlando/meridian-parks")) {
			 * propType="Executive Style Homes, Farmhouse Style Homes, Loft, Craftsman Style Homes, Detached Home, Single Family, Traditional Homes, Homeowner Association, Patio Homes"
			 * ; }
			 */
//			if (comUrl.contains("https://mattamyhomes.com/florida/tampa/wesley-chapel/volanti")) {
//				add[0] = "South Of Hay Rd";
//
//				notes = ALLOW_BLANK;
//			}

			comHtml = comHtml.replace("Phase III will be opening for sale summer 2021",
					"Phase III opening for sale summer 2021");
			notes = U.getnote((comHtml + comSec).replaceAll("preSellingHome|homesites now released for sale", ""));
			
			if (comUrl.contains("https://mattamyhomes.com/texas/dallas/dallas/tenison-village") ||
					comUrl.contains("https://mattamyhomes.com/florida/jacksonville/st-johns/rivertown/rivertown-gardens-north") ||
					comUrl.contains("https://mattamyhomes.com/texas/dallas/north-richland-hills/city-point")) {
				propType = propType + ", Farmhouse Style Homes"; //from img
			}
			

			data.addCommunity(comName.replaceAll(" - NOW SELLING!$", ""), comUrl, comType);
			data.addAddress(add[0].trim().replace("&amp;", "&"), add[1].trim(), add[2], add[3].trim());
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(unitCount);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propertyStatus.replace("Ii", "II"));
			data.addNotes(notes.replace("Iii", "III"));

		}
		j++;
//		 }catch (Exception e) {}

	}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
//					Thread.sleep(50000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(6000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					try {
					WebElement fr = driver.findElement(By.xpath("//*[@id=\"sitemapid\"]/iframe"));
					driver.switchTo().frame(fr);
					html+=driver.getPageSource();
					}catch (Exception e) {
						
					}
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;
		try {
			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("102.64.120.168", 8085));
		final URLConnection urlConnection = url.openConnection();
		try {

			urlConnection.addRequestProperty("User-Agent",
					"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "application/json, text/plain, */*");
			urlConnection.addRequestProperty("Accept-Language", "en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Authorization",
					"converge.apiuser@medialabinc.local ivAWB7o62AKC1vL+HSwOvuVC6c5YteZfZrZdSoxJbf4=");
			urlConnection.addRequestProperty("x-ml-date", "Fri, 22 Apr 2022 12:46:27 GMT");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {

			U.log("gethtml expection: " + e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
}