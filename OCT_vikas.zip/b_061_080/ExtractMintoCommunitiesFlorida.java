/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */

package com.shatam.b_061_080;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMintoCommunitiesFlorida extends AbstractScrapper {

	static int j = 0;
	static int k = 0;
	static CommunityLogger LOGGER;
	static WebDriver driver =null;
	public ExtractMintoCommunitiesFlorida() throws Exception {
		super("Minto Communities - Florida", "https://www.minto.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Minto Communities - Florida");
	}  

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		AbstractScrapper a = new ExtractMintoCommunitiesFlorida();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Minto Communities - Florida.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml = U.getHTML("https://www.minto.com/florida/new-homes/projects.html");

		String[] comSec = U.getValues(mainHtml, "<header class=\"row regional-overview-listing-projects-project-title\"", "View Community</a>");
		U.log(comSec.length);
		for (String comData : comSec) {
			String comUrl = "";
			if (!comData.contains("https://")) {
				comUrl = "https://www.minto.com" + U.getSectionValue(comData, "href=\".", "\"");
			} else {
				comUrl = U.getSectionValue(comData, "href=\"", "\"");
			}
//			U.log("===>"+comData);
			if (comUrl.contains("tel:"))
				continue;
			U.log("comUrl-1 : " + comUrl);
			U.log(comUrl + "\n");
			if(!comUrl.contains("/Anna-Maria-Island-new-homes/Harbour-Isle-on-Anna-Maria-Sound/main.html")&&comData.contains(comUrl)) {
//				try {
					addDetails(comUrl, comData);
//				} catch (Exception e) {}
				
			}
			//addDetails(comUrl, comData);
		}
		
		String newComSec[] = U.getValues(mainHtml, "<div class=\"container-fluid\">", ">Learn More</a>");
		U.log("newComSec:::::::::::"+newComSec.length);
		for (String comData : newComSec) {
			String comUrl = "";
			if (!comData.contains("https://")) {
				comUrl = "https://www.minto.com" + U.getSectionValue(comData, "href=\".", "\"");
			} else {
				comUrl = U.getSectionValue(comData, "href=\"", "\"");
			}
			if (comUrl.contains("tel:"))
				continue;
			U.log("comUrl : " + comUrl);
			U.log(comUrl + "\n");
			if(comUrl.contains("/Anna-Maria-Island-new-homes/Harbour-Isle-on-Anna-Maria-Sound/main.html")) {
				
//				try {
					addDetails(comUrl, comData);
//				} catch (Exception e) {}
				
			}
			
		}
//		addLatitudeMargaritavilleWaterSound("https://www.latitudemargaritaville.com/watersound");
		
		
		
		
		//addDetails("https://www.latitudemargaritaville.com/watersound", U.getHTML("https://www.latitudemargaritaville.com/watersound"));
		// addDetails("https://www.latitudemargaritaville.com/daytona-beach", "<span
		// class=\"location\">Daytona Beach, Florida</span></a>");
		// addDetails("https://www.latitudemargaritaville.com/hilton-head", "<span
		// class=\"location\">Hilton Head, South Carolina</span></a>");
		U.log(comSec.length);
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub

		
//		try {
	
		if (comUrl.contains(
				"https://www.minto.com/usa/florida/new-homes/Latitude-Margaritaville/Request-Information~1892.html"))
			return;
		if (comUrl.contains("https://www.minto.com/florida/Palm-Beach-new-homes/PortoSol/main.html"))
			return;// redirect to main Page please check every time when executing....
//		if (comUrl.contains("https://www.latitudemargaritaville.com"))
//			comUrl = "https://www.latitudemargaritaville.com/hilton-head";
//		if (comUrl.contains("/Latitude-Margaritaville-Daytona-Beach/main.html"))
//			comUrl = "https://www.latitudemargaritaville.com/daytona-beach";
		
		//============ Single Execution====================
//	 if(!comUrl.contains("https://www.minto.com/usa/florida/new-homes/Westlake/main.html"))return;
//	 if(!comUrl.contains("https://www.minto.com/usa/florida/new-homes/Westlake/main.html"))return;
//	 if(!comUrl.contains("https://www.latitudemargaritaville.com/daytona-beach"))return;
//	 if(!comUrl.contains("https://www.latitudemargaritaville.com/hilton-head"))return;
	// if(!comUrl.contains("https://www.latitudemargaritaville.com/watersound"))return;

		U.log(j + "   commUrl-->" + comUrl);
		U.log(U.getCache(comUrl));
		String html = U.getHtml(comUrl,driver);
/*		if (comUrl.contains("www.latitudemargaritaville.com")) {
			html = U.getPageSource(comUrl);
		}*/
//U.log(comData);	
		// ============================================Community
		// name=======================================================================
		// String communityName=U.getSectionValue(comData, "<span class=","/span>");
		// U.log("community Name---->"+communityName);
		String communityName = U.getSectionValue(comData, "data-field=\"name\">", "<");
		if(communityName== null)communityName =U.getSectionValue(html, "\"Name\":\"", "\"");
		if(communityName== null)communityName =U.getSectionValue(html, "<title>", "-");
		if(comUrl.contains("/watersound")) communityName = "Watersound";
		if(comUrl.contains("/hilton-head")) communityName = "Hilton Head";
		if(comUrl.contains("new-homes/Westlake/main.html")) communityName = "Westlake";
		
		U.log("community Name---->" + communityName);
		communityName = communityName.replaceAll(", Florida|, South Carolina|</a>", "");
		/*
		 * if (comUrl.contains("https://www.latitudemargaritaville.com/")) {
		 * communityName="Latitude Margaritaville"; }
		 */
		// ============================================note====================================================================
		String note = "";
		note = U.getnote(html);
		// ================================================Address
		// section===================================================================
		String Location = U.getHTML(comUrl + "/location.html");

		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		html = U.removeComments(html);
		html = U.removeComments(html);
		String addSec = U.getSectionValue(html, "itemprop=\"address\"", "</div>");
//		U.log("addsec== "+addSec);
		if (addSec != null) {
			add[0] = U.getSectionValue(addSec, "streetAddress\" class=\"address-line\">", "</span>");
			add[1] = U.getSectionValue(addSec, "addressLocality\" class=\"address-line\">", "</span>");
			add[2] = U.getSectionValue(addSec, "addressRegion\" class=\"address-line\">", "</span>");
			add[3] = U.getSectionValue(addSec, "postalCode\" class=\"address-line\">", "</span>");
			if (add[0] == null)
				add[0] = ALLOW_BLANK;
		} 
		else {
			addSec = U.getSectionValue(comData, "target=\"_blank\">", " </a>");
			if(addSec==null||addSec.length()<6)
				addSec = U.getSectionValue(comData, "target=\"_blank\" rel=\"noopener\">", "</a>");
//			U.log("elseAddsec== "+addSec);
			if (addSec != null) {
				addSec = addSec.replaceAll("<br />|, <br />", ",").replace(".", "");
				// if(!addSec.contains("Naples\\s*,"))
				addSec = addSec.replaceAll("Naples FL 34113", "Naples, FL 34113").replaceAll("Daytona Beach",
						"Daytona Beach,").replace("Davenport FL", "Davenport, FL");
//				U.log(addSec);
				add = U.findAddress(addSec);
			}
		}
		if(comUrl.contains("/Anna-Maria-Island-new-homes/Harbour-Isle-on-Anna-Maria-Sound/main.html")) {
//			 U.log(comData);
			 String addSec1 = U.getSectionValue(comData, "<a href=\"https://www.google.com/maps?cid=", "</a>");
			 addSec1 = addSec1.replace("15591585298510618305&authuser=1&_ga=2.5847603.1057115559.1542744118-1775470291.1517415768\" target=\"_blank\">", "");
//			 U.log(addSec1);
		}
		if(add[0]== ALLOW_BLANK && !comUrl.contains("latitude")) {
			addSec = U.getSectionValue(html, "Sales Center </h2>", "<p><strong>").replaceAll("Ave\\. West|Ave\\.&nbsp;West", "Ave West,");
			String street = U.getSectionValue(addSec, "<div><a", "</a");
	//		U.log(street);
			if(street!=null) {
			addSec =addSec.replace(street, "");
			street =  U.getSectionValue(street, "\">", ",");
			}
			String secondAddresssec = U.getSectionValue(addSec, "\">", "<");
			if(secondAddresssec== null)secondAddresssec ="";
			String dummadd[]  = secondAddresssec.split(" ");
			U.log(Arrays.toString(dummadd));
			if(street!=null)add[0]=street;
			if(dummadd.length == 3) {
			add[1] = dummadd[0].replace(",", "");
			add[2] = dummadd[1].replace(",", "");
			add[3] = dummadd[2].replace(",", "");
			}
			if(dummadd.length > 3) {
				addSec = U.getSectionValue(html, "Sales Center </h2>", "<p><strong>");
				add = U.findAddress(addSec);
			}
		}
		U.log(add[1]);
		

		U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);

		// --------------------------------------------------latlng----------------------------------------------------------------

		latlag[0] = U.getSectionValue(Location, "latitude\">", "</span>");
		latlag[1] = U.getSectionValue(Location, "Longitude\">", "</span>");
		
		if(latlag[0]==null || latlag[0].length()<4) {
			latlag[0] = U.getSectionValue(html, "Latitude\":\"", "\"");
			latlag[1] = U.getSectionValue(html, "Longitude\":\"", "\"");
		}
//		U.log("hhhh1--->" + latlag[0] + "  " + latlag[1]);
		if(latlag[0]==null && latlag[1]==null) {
			String latlongSecS=U.getSectionValue(comData, "regional-section-map-projects-address", "data=");
			U.log("latlongSecS: "+latlongSecS);
			if(latlongSecS==null)latlongSecS = ALLOW_BLANK;
			latlag[0] = Util.match(latlongSecS, "\\d{2}.\\d{5,}");
			latlag[1] = Util.match(latlongSecS, "-\\d{2}.\\d{5,}");
		}
//		 U.log("hhhh--->"+latlag[0]+" "+latlag[1]);
		 if (comUrl.contains("https://www.latitudemargaritaville.com/daytona-beach"))
		 {
		 add[0]="2400 Lpga Boulevard";
		 add[1]="Daytona Beach";
		 add[2]="FL";
		 add[3]="32124";
		 latlag[0]="29.2188975";
		 latlag[1]="-81.1096996";
		 geo="FALSE";
		 }
		if (comUrl.contains("https://www.latitudemargaritaville.com/hilton-head")) {
			add[0] = "356 Latitude Boulevard";
			add[1] = "Hardeeville";
			add[2] = "SC";
			add[3] = "29927";
			latlag[0] = "32.303324";
			latlag[1] = "-81.1087867";
			geo = "FALSE";
		}
		if (comUrl.contains("https://www.minto.com/usa/florida/Orlando-new-homes/Laureate-Park-at-Lake-Nona/main.html")) {
			add[0] = "4400 W. Sample Road";
			add[1] = "Coconut Creek";
			add[2] = "FL";
			add[3] = "33073";
			note="Address Taken From Contact";
			geo = "TRUE";
		}
		if (comUrl.contains("https://www.latitudemargaritaville.com/watersound"))
		 {
		
		 latlag[0]="30.2993551";
		 latlag[1]="-85.8554008";
		 geo="FALSE";
		 }
		
		if(!comUrl.contains("latitudemargaritaville") && (latlag[0]== null || latlag[0].length()<3 )) {
			String latSec = U.getSectionValue(html, "/maps?ll=", "&amp;");
			if(latSec!=null)
				latlag =latSec.split(",");
		}
		////

		if (add[1] != ALLOW_BLANK && latlag[0] == null) {
			latlag = U.getlatlongGoogleApi(add);

			geo = "TRUE";
		}
		
//		if(comUrl.contains("https://www.minto.com/usa/florida/Naples-new-homes/TwinEagles/main.html")) {
//			add[0]="12405 Lockford Lane";
//			add[1]="Naples";
//			add[2]="FL";
//			add[3]="-";
//			latlag=U.getlatlongGoogleApi(add);
//			geo="TRUE";
//			add[3]=U.getAddressGoogleApi(latlag)[3];
//		}
//		if(comUrl.contains("https://www.minto.com/usa/florida/Orlando-new-townhomes-condos/Festival/main.html")) {
//			add[0]="1503 ChampionsGate Blvd. West";
//			add[1]="Davenport";
//			add[2]="FL";
//			add[3]="-";
//			latlag=U.getlatlongGoogleApi(add);
//			geo="TRUE";
//			add[3]=U.getAddressGoogleApi(latlag)[3];
//		}
		
		U.log(add[1]+"ffffff"+latlag[0]);
		if(latlag[0]==null && add[1]!=ALLOW_BLANK) {
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		if ((add[0] == ALLOW_BLANK || add[3] == null) && latlag[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo = "TRUE";
		}
		U.log("hhhh1--->" + latlag[0] + "  " + latlag[1]);

		// String floH=U.getHTML(comUrl+"-floor-plans");
		// String liSy=U.getHTML(comUrl+"-lifestyle");

		// ============================================Price and
		// SQ.FT======================================================================

		String url1 = comUrl.replace("/main.html", "");
		String floorHtml = "";
		String allfloorHtml = "";
		if (html.contains("collections.html")) {
			U.log("collections.html: "+url1 + "/collections-tag"+U.getSectionValue(html, url1 + "/collections-tag", "\""));
			floorHtml = U.getHTML(url1 + "/collections-tag"+U.getSectionValue(html, url1 + "/collections-tag", "\""));
		}
		int k=0;
		if(floorHtml!=null && !comUrl.contains("latitudemargaritaville")) {
			String floorplans[]=U.getValues(floorHtml, "<div class=\"regional-community-list-series-serie", "View</a>");
			U.log("floorplans: "+floorplans.length);
			for(String plan:floorplans) {
			//	U.log("Hello : "+U.getSectionValue(plan, "<a href=\"", "\""));
				k++;
//				if(k>6)break;
				allfloorHtml +=" "+U.getHTML(U.getSectionValue(plan, "<a href=\"", "\""));
			}
		}
		if (comUrl.contains("daytona-beach")) {
			floorHtml = U.getHTML("https://www.latitudemargaritaville.com/daytona-beach-floor-plans");
			String furls[] = U.getValues(floorHtml, "</p><p><a href=\"", "\"");
			for(String plan:furls) {
				k++;
				if(k>6)break;
				allfloorHtml +=U.getHTML("https://www.latitudemargaritaville.com"+plan);
			}
		}
		if (comUrl.contains("/hilton-head")) {
			floorHtml = U.getHTML("https://www.latitudemargaritaville.com/hilton-head-floor-plans");
			String furls[] = U.getValues(floorHtml, "</p><p><a href=\"", "\"");
			U.log("LEN: "+furls.length);
			for(String plan:furls) {
				U.log("PLAN LINK : "+plan);
				k++;
				if(k>6)break;
				allfloorHtml +=U.getHTML("https://www.latitudemargaritaville.com"+plan);
			}	

		}
		if (comUrl.contains("/watersound")) {
			floorHtml = U.getHTML("https://www.latitudemargaritaville.com/watersound-floor-plans");
			String furls[] = U.getValues(floorHtml, "</p><p><a href=\"", "\"");
			for(String plan:furls) {
				k++;
				if(k>6)break;
				allfloorHtml +=U.getHTML("https://www.latitudemargaritaville.com"+plan);
			}
			
		}
		
		// U.log("floorHtml::"+floorHtml);
//		U.log("===="+comUrl);
		String rem = U.getSectionValue(html, "<select class=\"mobile-sub\"", "</select>");
		if(rem!=null)
			html = html.replace(rem, "");
//			if(( comUrl.contains("https://www.minto.com/usa/florida"))//comUrl.contains("https://www.minto.com/usa/florida/new-homes/Westlake") ||
//					&& html.contains("collections.html")){
//				floorHtml+=U.getHTML(url1 + "/collections.html");
//				
//				U.log(">>>>>>>>>>"+url1 + "/collections.html");
//			}

		U.log("hell--> " + url1 + "/collections.html");
		String quckHtml = ALLOW_BLANK, quickHomeHtml = ALLOW_BLANK;
		String moveReg = Util.match(html, url1 + "/Move-in-Soon~\\d+[.]html");
		if(url1.contains("https://www.latitudemargaritaville.com")&&!comUrl.contains("/watersound"))
			moveReg = url1+"-move-in-soon";
			
		if (moveReg != null) {
/*			if(url1.contains("https://www.latitudemargaritaville.com")){
				quckHtml = U.getHtml("https://twix.newhomesource.com/mintocommunities/community/121696", driver);
			}*/
			
			if(comUrl.contains("latitudemargaritaville"))
				if(!moveReg.startsWith("http"))
					quckHtml = U.getHtml(url1 + "/" + moveReg,driver);
				else
					quckHtml = U.getHtml(moveReg,driver);
			
			if(!moveReg.startsWith("http"))
				quckHtml = U.getHTML(url1 + "/" + moveReg);
			else
				quckHtml = U.getHTML(moveReg);
			
				
//			U.log("moveReg : " + moveReg);
	//		U.log("Quick Url:: "+quckHtml);
			String quickHomes[] = U.getValues(quckHtml, "<p class=\"text-center\"><a href=\"", "\"");
			for (String sec : quickHomes) {
				U.log(sec);
				if(sec.length()>4) {
					quickHomeHtml = quickHomeHtml + U.getHTML(sec);
				}
			}
			
			String[] data = U.getValues(quckHtml, "<div class=\"home-result-grid readyToBuild custom-homes-card\">", "</button>");
			for (String sec : data) {
				// U.log(sec);
				quickHomeHtml = quickHomeHtml + U.getHTML(sec);
			}
			
	//		U.log("---->  " + url1 + "/" + moveReg);
		}
		

		U.log("moveReg : " + moveReg);

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html = html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k|00'S", "0,000").replace("$1 million", "$1,000,000");
		html = html.replace("$200s", "$200,000");
		html = html.replace("0s", "0,000").replaceAll("=\"PRICE_RANGE(.*?)</optio", "");
		// U.log(floorHtml);
		floorHtml = floorHtml.replace("$<span class=\"sort-price\">", "$").replace("&nbsp;a/c&nbsp;sq.&nbsp;ft.",
				" sq. ft.").replaceAll("high \\$(\\d{3})s", "high \\$$1,000");
		if(comUrl.contains("latitudemargaritaville")) {
			String fpUrl=comUrl+"-floor-plans";
			U.log(">>>>>>"+fpUrl);
		}
		allfloorHtml=allfloorHtml.replace("Starting From $388,990", "");
				
		String prices[] = U.getPrices((html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml).replaceAll("0s|0's","0,000").replaceAll("$300s", "$300,000"),
				"Mid \\$\\d{3},\\d{3}|priced from the \\$\\d{3},\\d{3}|<strong>Starting From \\$\\d{3},\\d{3}</strong>|\\$\\d{3},\\d{3} </div>|in the \\$\\d{3},\\d{3}|the high \\$\\d{3},\\d{3}",0);
		
//		U.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml, "[\\w\\s\\W]{300}\\$400[\\w\\s\\W]{300}",0));
//		U.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml, "[\\w\\s\\W]{300}401,990[\\w\\s\\W]{300}",0));
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		U.log("Price--->" + minPrice + " " + maxPrice);

		// ======================================================Sq.ft===========================================================================================
		
		//  String[] sqft = U.getSqareFeet((html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml), "\"price\": \"\\d{3},\\d{3} square feet\"",0);
		
		  String[] sqft = U.getSqareFeet((html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml),
				  "\\d,\\d{3} a/c sq. ft.|\\d,\\d{3} sq.ft.|<br>\\s+\\d,\\d{3} total sq. ft.<br><strong>", 0); //|class=\"data-area\">\\d,\\d{3}</span>" \\d,\\d{3}</span> square feet<
		  
		//  U.log("MATCHING: "+Util.matchAll(html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml, "[\\w\\s\\W]{300}<br>\\s+\\d,\\d{3} total sq. ft.<br><strong>|class=\"data-area\">\\d,\\d{3}</span>[\\w\\s\\W]{300}" , 0));
		 
		
//		U.log("MMMMMMMM "+Util.matchAll(html + comData + floorHtml + quckHtml + quickHomeHtml + allfloorHtml, 
//				"[\\w\\s\\W]{30}1,204[\\w\\s\\W]{30}",0));
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->" + minSqft + " " + maxSqft);
		
		// ==============================================Property Status=========================================================
		html = html.replace("Move-in Ready Homes Available Now", "Move-In Ready Homes").replaceAll("Only Three New Minto Homes Remain", "Only 3 Homes Remains");
		html = html.replace("Final Phase at Historic Sun City Center is Now Selling", "Final Phase Now Selling");
		html = html.replaceAll(
					"Collier Preserve. Now available|Beach County, now available |Coming Soon: Compass|label-coming-soon|Sky Villas now available|Coming Soon - Compass by Margaritaville Hotel and Floridays Restaurant|Models Opening Early 2018| - Move in Ready Homes |- Move-In|In Ready</a>|and residences now available|residences now|Residences are now|Ready Homes","");
		html = html.replace("Only One New Minto Home Remains", "Only One New Home Remains").replace("Only Three New Minto Homes Remain", "Only 3 Homes Remain").replace("Only One New Minto Home Remains", "only one home remain").replaceAll(
					"residences are now available | Grill Now Open| Coach Home, now available|entertaining space. Now available\"|content=\"New waterfront residences are now available in |Harbour is now open|and pricing in the final phase |Incentive is available on select homes"
					+ "|Open: Compass","");
		String pStatus = ALLOW_BLANK;
		pStatus = U.getPropStatus((html + comData).replaceAll(
				"13 models now open|Watersound now open|models now open|/Move-In-Ready~2162.html|ppage2162 move-in-ready|ppage1183 move-in-ready|Community Closeout|Final Closeout! Don't miss your chance|celebrate the grand opening|Model Grand Opening|residences are now available| TwinEagles. Now |sold-out|Move-In Ready Vacation|Naples, now available|Terrace Homes now available|9 Models Now Open|Marina Under Construction &ndash; Opening Summer 2018!|Margaritaville now open in Dayton| Homes Grand Opening|Hilton Head Grand Opening 2018</a>|Margaritaville now open in Hilton",
					""));
//		U.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html+comData, "[\\w\\s\\W]{30}Now Open[\\w\\s\\W]{30}",0));
		U.log("pStatus: "+pStatus);
		// ================================remove com Header
		// Section=====================================================================================
		String remHeader = U.getSectionValue(html, "<div id=\"site-wrapper\"", "<div id=\"site-content\">");
		if (remHeader != null) {
			U.log("Suucess remHeader ");
			html = html.replace(remHeader, "");
		}

		// ========================remove Footer=================
		String remFooter = U.getSectionValue(html, "<h2>Check Out Minto&rsquo",
				"for access to our privacy policy.</span>");
		if (remFooter != null) {
			U.log("Suucess remFooter ");
			html = html.replace(remFooter, "");
		}
		// ==================remove dropdown==============
		String comList = U.getSectionValue(html, "Award-Winning Florida Communities</div>",
				" <div class=\"clearboth\">");
		if (comList != null) {
			html = html.replace(comList, "");
		}
		// ========================================================================
		String remove = "townhomes in Sunrise, Florida.\" />|alt=\"View the Artesia sunrise townhomes|models are now open";
		html = html.replaceAll(remove, "");

		// ========== Feature Section ========================
		String featureUrlSec = U.getSectionValue(html, "premium explore \">", "Features</a>");
		String featureHtml = null;
		if (featureUrlSec != null) {
			String featureUrl = U.getSectionValue(featureUrlSec, "<a href=\"", "\"");
			U.log(featureUrl);
			featureHtml = U.getHTML(featureUrl);
		}
		// ================================================community
		// type========================================================
		
		html = html.replace("Waterfront Residences", "serene waterfront community").replaceAll("Lifestyle -  Over 55|premier “55|inspired active adult|Palm Beach County with resort", "")
				.replace("<title>55+ Community", "<title> 55+ Community");
//		U.writeMyText(html);
		String communityType = U.getCommType((html + comData).replace("Westlake", ""));

		// ==========================================================Property
		// Type================================================
		html = html.replaceAll(
				"quality craftsmanship|Condos</a>|homes-condos| and condos, apartment re|omes and condos, apartment rentals, furnished|-condos/|New Florida Single|Orlando Single|alt=\"Single|offers new single|Apartments</a>|apartment-|-apartments|-townhomes|Luxurious Mohawk|Luxurious 3/8",
				"");
		html = html.replace("Luxury Paired Villas", "luxury homes Paired Villas");
		

		html = U.removeSectionValue(html, "<head>","</head>"); // "<meta name=\"description\" ", "/>");
		if (featureHtml != null)
			featureHtml = featureHtml.replaceAll(
					"Luxurious Mohawk| Luxurious drop|Condos</a>|-condos/|new-townhomes-condos|New Florida Single|Orlando Single|alt=\"Single|offers new single|Apartments</a>|apartment-|-apartments|-townhomes|Luxurious Mohawk|Luxurious 3/8",
					"");
		String floorSec = ALLOW_BLANK;
		if (floorHtml != html) {
			floorSec = U.getSectionValue(floorHtml, "<div class=\"last_updated\">", "/form>");
		}
		if (comUrl.contains(
				"https://www.minto.com/usa/florida/Anna-Maria-Island-new-homes/One-Particular-Harbour/main.html")) {
			floorSec += "condos";
		}
		if (comUrl.contains("https://www.latitudemargaritaville.com/daytona-beach")) {
			floorSec = U.getSectionValue(floorHtml, "View Our Community</span>", "</section>");
		}
		if (floorSec == null) {
			floorSec = ALLOW_BLANK;
		}
		
		
		String footerSec = U.getSectionValue(html, "<div class=\"container-fluid global-footer-bottom\">", "<p>Follow us:</p>");
		if(footerSec!=null)
			html = html.replace(floorSec, "");
		
		String proptype = U.getPropType((html + comData + featureHtml + quickHomeHtml +allfloorHtml+floorHtml
				+ floorSec.replaceAll("alt=\"luxury|alt=\"Luxury", ""))
				.replace("This area, with its many small coastal towns", "This area, with its many small coastal vibes towns")
				.replaceAll(
						"apartment-|-apartment|mintoapartment|Apartment|Upgraded Cottage White|Luxury Condos - Bradenton|Waterfront Condos|Nautica luxury condos| erfront luxury condos |-homes-condos|Maria-Island-Condo|content=\"New Courtyard Homes,|and condos, apartment rentals, furnished|-condos",
						"").replaceAll("apartments/projects.html\">| RENTALS_HOMESTYLE_TOWNHOME", "")
						.replaceAll("-condos/projects.html|MCC Pages  New Homes and Condos|/new-homes-condos/projects.html\">New Homes &amp; Condos</a>|homes and condos, apartment re|Island-Condos|homes-condos|homes and condos, apartment", "")
						.replaceAll("-condo-|waterfront luxury condos by Minto Communities|portfolio tops 6,500 apartments|pet-friendly rental apartments|rent-an\">Rent an apartment|fully designed new homes and condos</a>|developers of homes, condominiums, rental properties|New Homes and Condos for Sale \\||pers of homes, condominiums, rental, new homes and condos|glass windowed condos agains|homes and condos, apartment rent|new homes and condos in|garden and townhomes, and furnished|company offering new\n\\s+homes and condos, apartment rentals|new-townhomes-condos|-condos", "").replace(floorSec, ""));
		
		U.log("proptype: "+proptype);
//		U.log(Util.matchAll(html + comData + featureHtml + quickHomeHtml +allfloorHtml+floorHtml+floorSec, "[\\w\\s\\W]{30}Condo[\\w\\s\\W]{30}",0));

		// ==================================================D-Property
		// Type======================================================

		floorHtml = floorHtml.replaceAll("\\s*stories ", " stories ");
		floorHtml = floorHtml.replaceAll("\\s*\\n*story", " story ");
		// U.log("floorHtml::"+floorHtml);
		String dtype = U.getdCommType(html + comData + floorHtml + quckHtml + quickHomeHtml+allfloorHtml);
		U.log("dtype--> " + dtype);
		

		// if
		// (comUrl.contains("https://www.minto.com/usa/florida/Sunrise-new-homes/Artesia/main.html"))
		// {
		// if(pStatus.length()>4){
		// pStatus = pStatus + ", Final Phase";
		// }
		// else{
		// pStatus = "Final Phase";
		// }
		// }
		U.log(moveReg);
		if (!comUrl.contains("latitudemargaritaville") && quckHtml.contains("VIEW FLOORPLANS AND MORE") && !pStatus.contains("Move")&&!comUrl.contains("https://www.latitudemargaritaville.com/watersound")) {
			if (pStatus.length() > 4) {
				pStatus = pStatus + ", Move-in Soon";
			} else {
				pStatus = "Move-in Soon";
			}
		}
		if(comUrl.contains("latitudemargaritaville")&&!pStatus.contains("Move")&&!comUrl.contains("https://www.latitudemargaritaville.com/daytona-beach")&&!comUrl.contains("https://www.latitudemargaritaville.com/hilton-head")&&!comUrl.contains("https://www.latitudemargaritaville.com/watersound")){
			if (pStatus.length() > 4) {
				pStatus = pStatus + ", Move-in Soon";
			} else {
				pStatus = "Move-in Soon";
			}
		}
		if (comUrl.contains("/Festival/main.html"))
			communityType = communityType.replaceAll(", Lakeside Community", "");
		if(comUrl.contains("/florida/Sunrise-new-homes/Artesia/main.html"))
			pStatus ="Final Closeout, "+pStatus;
		
		if(comUrl.contains("https://www.minto.com/usa/florida/LakePark-new-homes/LakePark-at-Tradition/main.html")) {
			
//			pStatus ="Community Closeout, "+pStatus;//Img
			dtype = "1 Story";
		}

		/*
		 * if(comUrl.equals(
		 * "https://www.minto.com/usa/florida/new-homes/Westlake/main.html")) {
		 * proptype=proptype.replace(", Condominium", ", Luxury Homes"); }
		 */
//		if(comUrl.contains("https://www.latitudemargaritaville.com/hilton-head")) {
//			minSqft="1,204";
//			maxSqft="2,564";
//			maxPrice="$362,490";
//		}
//		if(comUrl.equals("https://www.latitudemargaritaville.com/daytona-beach"))minSqft="1,204";
		
		if(comUrl.contains("https://www.minto.com/usa/florida/new-homes/Westlake/main.htm"))maxSqft="6,188";
		if(comUrl.contains("/new-homes/The-Isles-of-Collier-Preserve")) {
			proptype=proptype.replace(", Condominium", "");
			//maxPrice = "$636,900";
		}
		 if(comUrl.contains("https://www.minto.com/usa/florida/Anna-Maria-Island-new-homes/One-Particular-Harbour/main.html"))dtype = "1 Story";
		// if(comUrl.contains("https://www.latitudemargaritaville.com/hilton-head"))maxPrice = "$466,910"; 
		 if(comUrl.contains("latitudemargaritaville"))
			 if(communityType==ALLOW_BLANK)
				 communityType = "Resort Style";
			 else
				 communityType+= ", Resort Style";
		 
		// ------------------------------
		if(comUrl.contains("/One-Particular-Harbour/main.html"))pStatus=pStatus.replace("Closeout", "Final Closeout");
		// ----------------------------------
		add[0] = add[0].replace(",", ".").replaceAll("1503 ChampionsGate Blvd", "1503 Champions Gate Blvd");
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + ":::::::::::Repeated");
			k++;
			return;
		}
		
		// ------------------------- Number of Units ---------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		
		LOGGER.AddCommunityUrl(comUrl + ":::::::::::");
		
		U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
		data.addCommunity(communityName, comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		j++;
		
		
//		}catch (Exception e) {}
	}

	public void addLatitudeMargaritavilleWaterSound(String url) throws Exception{
		String comurlString=url;
		
		String comname="Latitude Margaritaville Watersound";
		
		String html=U.getHTML(url);
		String ctype=U.getCommType(html);
		
		String floorplanhtml=U.getHTML(url+"-floor-plans");
		
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlag[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		add[0]="9201 HIGHWAY 79";
		add[1]="Panama City";
		add[2]="FL";
		add[3]="32413";
		latlag[0]="30.2993551";
		latlag[1]="-85.8554008";
		
		
//		html=html.replace("$200S", "$200,000");
	String prices[]=U.getPrices(html+floorplanhtml, "FROM THE MID \\$\\d{3},\\d{3}", 0);
		
		
		String sqft[]=U.getSqareFeet(html+floorplanhtml, "\\d,\\d{3} a/c sq. ft. to \\d,\\d{3} a/c sq.ft.|\\d{1},\\d{3} a/c sq. ft|to \\d{1},\\d{3} a/c sq.ft", 0);
		
		String ptype=ALLOW_BLANK;
		ptype=U.getPropType(html+floorplanhtml);
		
		String dtype=ALLOW_BLANK;
		dtype=U.getdCommType(floorplanhtml+html);
		
		
		String pstatus=ALLOW_BLANK;
		pstatus=U.getPropStatus(html);
		
//		U.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}Move[\\w\\s\\W]{30}",0));
		
		String note=U.getnote(html);
		
		if(prices[1]==null)prices[1]=ALLOW_BLANK;
		prices[0]="$200,000";
		LOGGER.AddCommunityUrl(url + ":::::::::::");

		U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
		data.addCommunity(comname, url, ctype);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		j++;
		
	}
		
	
}