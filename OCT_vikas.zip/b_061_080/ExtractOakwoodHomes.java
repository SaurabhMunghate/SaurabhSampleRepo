/**
 * @author Priti
 * @date June 2017
 * 
 */
package com.shatam.b_061_080;

import java.io.*;
import java.sql.Connection;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.zip.Adler32;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractOakwoodHomes extends AbstractScrapper {

	public int inr = 0;
	Connection con;
	static int j = 0, i = 0;

	CommunityLogger LOGGER;

	public static void main(String arg[]) throws Exception {

		AbstractScrapper a = new ExtractOakwoodHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Oakwood Homes.csv", a.data().printAll());
	}

	public ExtractOakwoodHomes() throws Exception {

		super("Oakwood Homes", "https://www.oakwoodhomesco.com/");
		LOGGER = new CommunityLogger("Oakwood Homes");
	}

	public void innerProcess() throws Exception {
		// U.setUpGeckoPath();

//		String mainHtml = U.getHTML("https://oakwoodhomesco.com");

		/*
		 * String[] regSections = U.getValues(mainHtml,
		 * "<ul role=\"navigation\" class=\"communities mt-0\">", "</ul>");
		 * 
		 * for(String regSec : regSections){ //U.log(regSec);
		 * 
		 * 
		 * String[] comUrls = U.getValues(regSec, "<a href=\"", "\"");
		 * //U.log(comUrls.length); for(String comUrl : comUrls){
		 * //U.log("comUrl :: "+comUrl); addDetails(comUrl); } }
		 */

		/**
		 * To get this below urls, u need to go builder region pages such as
		 * "https://oakwoodhomesco.com/region/colorado/",
		 * "https://oakwoodhomesco.com/region/utah/", etc.<br>
		 * and find below url's at network on browser with respect to region url's.
		 */
		String regUrls[] = {
				"https://oakwoodhomesco.com/wp-admin/admin-ajax.php?action=get_geojson&layers=vip,communities,offices&term=27&community=&force=", // colorado
				"https://oakwoodhomesco.com/wp-admin/admin-ajax.php?action=get_geojson&layers=vip,communities,offices&term=8&community=&force=", // utah
				"https://oakwoodhomesco.com/wp-admin/admin-ajax.php?action=get_geojson&layers=communities,offices&term=878&community=&force=" };

		for (String regUrl : regUrls) {
			U.log("regUrl :" + regUrl + "\n" + U.getCache(regUrl));
			String html = U.getHTML(regUrl);
			String section = U.getSectionValue(html, "offices\":{\"type\":\"FeatureCollection", "}}]}}"); // "vips\":{\"type\":\"FeatureCollection");
			String comSection[] = U.getValues(section, "{\"type\":\"Feature\",\"properties", "geometry\":{\"type\"");
			U.log("Comm. count ::" + comSection.length);

			for (String comSec : comSection) {
				comSec = comSec.replace("\\/", "/");
//				U.log(comSec);
				String comUrl = U.getSectionValue(comSec, "collectionLink\":\"", "\"");
				U.log(comUrl);
				addDetails(comUrl, comSec);
//				break;
			}
//			break;
		}

		LOGGER.DisposeLogger();

	}

	private void addDetails(String comUrl, String comSec) throws Exception {
		// TODO Auto-generated method stub
//		if (!comUrl.contains("https://oakwoodhomesco.com/collection/horizon-collection-at-reunion"))return;
//	if(i<20)
//		try{
		{
			U.log(i + "\tcomUrl :: " + comUrl);

			if (this.data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
 
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

//			U.log(comSec);
			String comHtml = U.getHTML(comUrl);

			U.log(U.getCache(comUrl));
			// --------Com name---------------
			/*
			 * String comName = Util.match(comHtml, "<h1><span>(.*?)</span>(.*?)</h1>",2);
			 * if(comName == null) comName = Util.match(comHtml, "<h1>(.*?)</h1>",1);
			 */ String comName = U.getSectionValue(comSec, "title\":\"", "\"");
			U.log("comName :: " + comName);
			comHtml = U.removeComments(comHtml);
			// U.log("KKKKKKKK"+Util.matchAll((comHtml +
			// comSec),"[\\w\\s\\W]{30}\\$500[\\w\\s\\W]{30}", 0));
			// -----------Address---------------
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			String note = ALLOW_BLANK;

			String section = U.getSectionValue(comHtml, "Address</span>", "</div>");
//			U.log(section);

			if (section != null) {
				// ---address----
//				if (comUrl.contains("https://oakwoodhomesco.com/collection/american-dream-at-green-valley-ranch"))
//					add[0] = ALLOW_BLANK;
//				else {
					add[0] = U.getSectionValue(section, "<span class=\"street-address\">", "</span>");
					if (add[0] == null)
						add[0] = U.getSectionValue(section, "<span class=\"street-address ok-block\">", "</span>")
//								.replace("Call for Office Location/Appointment", ALLOW_BLANK)
								;
//				}
				add[1] = U.getSectionValue(section, "<span class=\"locality\">", "</span>");
				add[2] = U.getSectionValue(section, "<span class=\"region\">", "</span>").trim();
				add[3] = U.getSectionValue(section, "<span class=\"postal-zip\">", "</span>");
				if (add[3] == null)
					add[3] = ALLOW_BLANK;
				// ---latlng-----
				String latlngSec = U.getSectionValue(section, "https://www.google.com/maps?daddr=", "\"");
				if (latlngSec != null) {
					latLng = latlngSec.split(",");
				}
			}
			U.log("add is  :: " + Arrays.toString(add));
			
			U.log("add is  :: " + Arrays.toString(add));
			U.log("latlng is  :: " + Arrays.toString(latLng));
			if(add[0]!=null && add[0]!=ALLOW_BLANK)
			{
				add[0]=add[0].replace(" (Office Opening Soon)", "")
						.replace("Reunion", "");
			}
			U.log("add is ==== :: " + add[0]);
			
			if(add[0]==null)
				add[0]=ALLOW_BLANK;
			// ---------Address taken using city and state-------------

			String cityStateSec = U.getSectionValue(comHtml, "<h1><span>", "</span>");

			if (add[0].length() < 4 && latLng[0].length() < 4 && cityStateSec != null) {
				String[] tempAdd = cityStateSec.split(",");
				add[1] = tempAdd[0];
				add[2] = tempAdd[1];
				latLng = U.getlatlongGoogleApi(add);
				if (latLng == null)
					latLng = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latLng);
				if (add == null)
					add = U.getAddressHereApi(latLng);
				geo = "TRUE";
				note = "Address And Lat-Lng Taken Using CIty And State";
			}
			// ---------Address taken using city and state-------------
			String[] stateSecs = U.getValues(comHtml, "<h2 class=\"h4 text-allcaps text-bold\"><a href=\"",
					"</section>");
			String state = ALLOW_BLANK, city = ALLOW_BLANK;
			if (add[0].length() < 4 && latLng[0].length() < 4)
				for (String stateSec : stateSecs) {

					String[] citySecs = U.getValues(stateSec, "<div id=", "</div>");
					for (String citySec : citySecs) {
//					U.log(citySec);
						if (citySec.contains(comName)) {
							state = U.getSectionValue(stateSec, "\">", "</a></h2>");
							U.log("state : " + state);
							city = U.getSectionValue(citySec, "\"", "\" class=\"region\">");
							U.log("city : " + city);
							add[1] = city;
							add[2] = state;
							note = "Address And Lat-Lng Taken Using CIty And State";
							if (comUrl.contains("https://oakwoodhomesco.com/communities/cottages-at-valley-station/")) {
								add[0] = "Soldier Hollow Resort"; // street Address Is Taken From Community Details
								// note = "Street Address Is Taken From Community Details";
							}
							if (comUrl.contains("https://oakwoodhomesco.com/communities/kantons-at-village-green/")) {
								add[0] = "Midway Lane"; // Street Address Is Taken From Area Map at link of available
														// homesites
							}
							latLng = U.getlatlongGoogleApi(add);
							if (latLng == null)
								latLng = U.getlatlongHereApi(add);
							add = U.getAddressGoogleApi(latLng);
							if (add == null)
								add = U.getAddressHereApi(latLng);
							geo = "TRUE";

						}

					}

				}
//			if(comUrl.contains("https://oakwoodhomesco.com/collection/american-dream-at-banning-lewis-ranch"))

			if (add[0] != ALLOW_BLANK && add[3] == ALLOW_BLANK) {
				if (latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK) {
					add[3] = U.getAddressHereApi(latLng)[3];
					geo = "TRUE";
				}
			}
			if (add[0] == ALLOW_BLANK || add[0].length() < 3) {
				if (latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK) {
					add[0] = U.getAddressGoogleApi(latLng)[0];
					geo = "TRUE";
				}
			}
			// ------------Prices-----------------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String remSec = U.getSectionValue(comHtml, "<div id=\"request-info\"", "</body>");
			if (remSec != null)
				comHtml = comHtml.replace(remSec, "");

			comSec = comSec.replaceAll("From the mid \\$(\\d{3})s", "From the mid \\$$1,000");

			comHtml = comHtml.replaceAll("<meta (.*?)>|content=\".*?\">|<script.*</script>", "");
			comHtml = comHtml.replace("0s</span>", "0,000</span>");
			comHtml = comHtml.replaceAll("0s|0S|0's", "0,000");
			

			String[] price = U.getPrices(comHtml + comSec,
					"mid \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</p>|From the low \\$\\d{3},\\d{3}|From the mid \\$\\d{3},\\d{3}|i-pr\">\\$\\d{3},\\d{3}|From the high \\$\\d{3},\\d{3}|pricenice=\"\\$\\d,\\d{3},\\d{3}",
					0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("min Price : " + minPrice + " max Price : " + maxPrice);
			
//			U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}600[\\w\\s\\W]{30}", 0));
			
			// U.log("comSec :: "+comSec);

			/*
			 * if(comUrl.contains(
			 * "https://oakwoodhomesco.com/collection/mesa-collection-at-cross-creek-ranch")
			 * ||comUrl.contains(
			 * "https://oakwoodhomesco.com/collection/park-house-at-thompson-river-ranch"))
			 * { minPrice=ALLOW_BLANK; maxPrice=ALLOW_BLANK; }
			 * 
			 * if(comUrl.contains(
			 * "https://oakwoodhomesco.com/collection/bungalows-collection-at-banning-lewis-ranch"
			 * )) { maxPrice="$538990"; }
			 */

			/*
			 * if (comUrl.contains(
			 * "https://oakwoodhomesco.com/collection/park-house-at-thompson-river-ranch"))
			 * { minPrice = ALLOW_BLANK; maxPrice = ALLOW_BLANK; }
			 */

			// if(comUrl.contains("https://oakwoodhomesco.com/collection/carriage-house-at-erie-highlands"))minPrice=ALLOW_BLANK;
			// ------------Sqft----------------
			String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
			// From Img
			if (comUrl.contains("https://oakwoodhomesco.com/communities/american-dream/")) {
				comHtml += " 987–1,701 sqft 2 Story ,3 Story";
			}
			String sqFt[] = U.getSqareFeet(comHtml.replace("data-sqftmax=\"120\" ", ""),
					"\\d,\\d{3}–\\d,\\d{3}sqft|plans up to \\d,\\d{3} sq ft|plans up to \\d,\\d{3} sq. ft.|2,213 � 4,160 sq ft|ranging from \\d,\\d{3}–\\d,\\d{3} total sq ft|floorplans up to \\d,\\d{3} sq. ft| \\d{3}–\\d,\\d{3} sqft|\\d,\\d{3}–\\d,\\d{3} sqft|i-sq\">\\d,\\d+-\\d,\\d+ sqft</span>|i-sq\">\\d{4}-\\d{4} sqft</span>|i-sq\">\\d,\\d+ sqft</span>|i-sq\">\\d{4} sqft</span>|data-sqftmin=\"\\d+\"|data-sqftmax=\"\\d+\"|\\d,\\d+–\\d,\\d+ sqft",
					0);
			minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

			U.log("minSqFt: " + minSqFt + " maxSqFt : " + maxSqFt);
			/*
			 * if(comUrl.contains(
			 * "https://oakwoodhomesco.com/collection/carriage-house-at-erie-highlands")) {
			 * minSqFt="1,434"; maxSqFt="3,776"; }
			 */
//			if(comUrl.contains("https://oakwoodhomesco.com/collection/carriage-house-at-green-valley-ranch"))
//			{
//				maxPrice="$440,000";
//			}

			// --------remove footer section -------------------
			comHtml = comHtml.replaceAll("adventure lifestyle. Set an appointment", "");
			String remFooter = U.getSectionValue(comHtml, "Set an appointment to visit one o", "</html>");
			String Header = U.getSectionValue(comHtml, "<head", "</header>");

			if (remFooter != null) {
				comHtml = comHtml.replace(remFooter, "");
				comHtml = comHtml.replace(Header, "");
				U.log("::::::::remFooter::::::::::::: ");
			}

			comHtml = comHtml.replaceAll("New lots are now open| center coming soon", "");
			comHtml = comHtml.replace("golfing at", " golf course ")
					.replace("Luxury at every level.", "Luxury Home at every level.")
					.replace("description\">55+ Active Adult</small>", "");
			// U.log(comHtml);
			// ------------Community Type-------------
			String comType = ALLOW_BLANK;
			comType = U.getCommunityType(comHtml);
//			U.log("MMMMMMMMM " + Util.matchAll(comHtml, "[\\s\\w\\W]{30}Adult[\\s\\w\\W]{30}", 0));
			U.log("comType : " + comType);

			// ================ Quick Homes ===============
			String combinedQuickHtmls = null;
			comHtml = comHtml.replace("qmi-modal", "");
			int quickHomeCount = 0;
			String quickHomeSection[] = U.getValues(comHtml, "id=\"qmi-", "data-marketingname="); // "title=");
			// U.log(quickHomeSection.length);
			for (String quickHomeSec : quickHomeSection) {
				String quickUrl = U.getSectionValue(quickHomeSec, "data-modal-iframe-url=\"", "\"");
				U.log("quickUrl ::" + quickUrl);
				if (quickUrl.length() > 3) {
					String quickHtml = U.getHTML(quickUrl);
					combinedQuickHtmls += U.getSectionValue(quickHtml, "<div class=\"model-info\">",
							"<section id=\"request-info\"");
					quickHomeCount++;
				}
			}
			U.log("Total Quick Home :" + quickHomeCount);
			// -----------Property Type--------------
			String propType = ALLOW_BLANK;
			comHtml = U.removeComments(comHtml);
			// String rem=U.getSectionValue(comHtml, "<h3 class=\"section-title\">Where We
			// Build</h3>", "<div class=\"footer-menu\">");
//		    if(rem!=null) {
//		    	comHtml=comHtml.replace(rem, "");
//		    }
			comHtml = comHtml.replaceAll(
					"Combining luxury and functionality|Thoughtfully designed livable luxury|unique collection offers livable luxury|luxury floorplans|luxury Marquee Collection of home|luxury choices, will give you the enriching experience",
					"luxury homes").replaceAll(
							"(C|c)ottages(-|\\s)at(-|\\s)(V|v)alley|Briarwood Bungalows |(F|f)airway(-|\\s)(V|v)illas|(v|V)illage",
							"").replace("BBQ, covered patio, covered front|Bungalows Collection at Banning Lewis", "Bungalows Homes Collection at Banning Lewis");
			
//			combinedQuickHtmls = combinedQuickHtmls.replaceAll("extension, Covered Patio, covered porch|porch, covered patio, unfinished basement|BBQ, covered patio, covered front", "");
			// + combinedQuickHtmls
			
			propType = U.getPropType((comHtml + comName).replace("bonus/flex rooms will give you plenty space", "bonus/FLEX Homes will give you plenty space"));

//			U.log("MMMMMMMMM " + Util.matchAll(combinedQuickHtmls, "[\\s\\w\\W]{30}flex room[\\s\\w\\W]{30}", 0));
//			U.log("MMMMMMMMM " + Util.matchAll(comHtml, "[\\s\\w\\W]{30}flex room[\\s\\w\\W]{30}", 0));

			U.log("propType : " + propType);

			// ----------Derived Type------------
			String dType = ALLOW_BLANK;
			
			if(combinedQuickHtmls != null) {
				combinedQuickHtmls = combinedQuickHtmls.replaceAll("desirable single story floor plan that effortlessly", "");
			}
			
			
			dType = U.getdCommType(comName+comHtml.replace("2 and 3-story", "2 Story 3 Story").replaceAll(
					"at Banning Lewis Ranch|dream-at-banning-lewis-ranch|Dream at Banning Lewis Ranch|AMERICANDREAM Collection in Green Valley Ranch|Cross Creek Ranch|Thompson River Ranch",
					"").replaceAll("Green Valley Ranch|-ranch/\">.*</a>|single-floorplan", "") + combinedQuickHtmls);

			//U.log("KKKKKKKK"+Util.matchAll((comHtml+combinedQuickHtmls), "[\\w\\s\\W]{30}single story[\\w\\s\\W]{30}", 0));
			if (comUrl.contains("https://oakwoodhomesco.com/collection/sanctuary-collection-at-the-reserve"))
				dType = ALLOW_BLANK;
			U.log("dType : " + dType);
			// U.log(communityQuickData);
			/*
			 * if(comUrl.contains("/adonea/")||comUrl.contains("/green-valley-ranch/")||
			 * comUrl.contains("/the-meadows/")||comUrl.contains("/banning-lewis-ranch/")||
			 * comUrl.contains("/reunion/")||comUrl.contains("/erie-highlands/")||comUrl.
			 * contains("/thompson-river-ranch/")||comUrl.contains("/riverdale/"))
			 * dType="1 Story, 2 Story, 3 Story"; if(comUrl.contains("/the-enclave/")||
			 * comUrl.contains("/springhouse-village-daybreak/")) dType="1 Story, 2 Story";
			 * if(comUrl.contains("/fairway-villas/")) dType="1 Story, 2 Story, Ranch"; //
			 * if(comUrl.contains("/american-dream/"))dType="1 Story, "+dType;
			 * if(comUrl.contains("/briarwood-bungalows-banning-lewis-ranch/"))
			 * dType="1 Story, "+dType;
			 */
			if (comUrl.contains("https://oakwoodhomesco.com/collection/bungalows-collection-at-the-reserve"))
				comType += ", 55+ Community";
			// ----------Property Status-----------------

			comHtml = U.removeComments(comHtml);
			comHtml = U.removeSectionValue(comHtml, "<aside>", "</aside>");
			// U.log(comHtml);

			comHtml = comHtml.replaceAll(
					"More homes coming 2019|Only a few Quick Move-in Homes Left|Quick move-ins availabl|Quick Move-Ins<|tab=\"Quick Move-ins|our model or quick move-in homes|Our Grand Opening Event|Only 3 Quick Move-in Homes Left|community coming May 2018| alt=\"Now Selling at The Meadows|price-point\">Quick Move|Coming Soon\" width|Lodge, coming",
					"");
			comHtml = comHtml.replaceAll(
					"Aurora Grand| RENT COMING SOON|amenities in , is coming|Villas, is coming|Lodge, coming|Collection Coming|coming soon to Thompson|alt=\".*?\"",
					"").replace("new homesites are now available", "new homesites now available").replace(
							" Now</span><span class=\"script\"> Se</span><span class=\"script\">lling", " Now Selling");

			comHtml = comHtml.replaceAll(
					"school is now open|school is coming|Interest List Now Open|Wander (Grand|- Now)|open at Wander|complex is NOW| rent coming|events\\. Coming|clubhouse \\(?coming|Opening- The Horizon",
					"");
//			U.log(comHtml);
			String propStatus = U.getPropStatus(comHtml.replace("Office Opening Soon", ""));
			U.log("propStatus : " + propStatus);
			// U.log(comHtml);
//			U.log("MMMMMMMMM "+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Opening Soon[\\s\\w\\W]{30}", 0));
			// if(comHtml.contains("href=\"https://oakwoodhomesco.com/quick-move-in/")){
			if (quickHomeCount > 0) {
				propStatus = propStatus.replaceAll(", Quick Move-in|Quick Move-in,*", "");
				if (propStatus.length() < 4)
					propStatus = "Quick Move-ins";
				else
					propStatus = propStatus + ", Quick Move-ins";
			}
			propStatus = propStatus.replace("Now Available, New Homesites Now Available",
					"New Homesites Now Available");

			// Status Coming from Image (present at Main Page)
			/*
			 * if(comUrl.contains("/adonea/")){
			 * 
			 * propStatus = getImageStatus(propStatus, "Limited Homesite Release"); }
			 */
//			if (comUrl.contains("https://oakwoodhomesco.com/collection/bungalows-collection-at-banning-lewis-ranch"))// ||
//			// comUrl.contains("https://oakwoodhomesco.com/collection/bungalows-collection-at-the-reserve"))
//			{
//				if (propType.length() > 1)
//					propType = propType + ", Bungalow Homes";
//				else
//					propType = "Bungalow Homes";
//
//			}
//					minPrice=ALLOW_BLANK;
//					maxPrice=ALLOW_BLANK; 
//					minSqFt=ALLOW_BLANK;
//					maxSqFt=ALLOW_BLANK;
//			}

			add[0] = add[0].replaceAll("\\(Carriage House\\)", "");
			propStatus = propStatus.replace("Ii", "II");
			comName = comName.replaceAll(" Villas$", "");
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);

		}
		i++;

//		}catch (Exception e) {}

	}

	private static String getImageStatus(String propStatus, String imageStatus) {
		if (propStatus.length() < 4)
			propStatus = imageStatus;
		else
			propStatus = propStatus + ", " + imageStatus;
		return propStatus;
	}

}