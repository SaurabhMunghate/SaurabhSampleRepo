/**@author Sawan
 * @date 31-01-2018
 */
package com.shatam.b_061_080;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;
import org.eclipse.jetty.client.Synchronizable;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractStockDevelopment extends AbstractScrapper {
	int i = 0;
	private final static String HOME_URL = "https://www.stockdevelopment.com";
	
	CommunityLogger LOGGER;
	 WebDriver driver= null;

	public ExtractStockDevelopment() throws Exception {
		super("Stock Development", HOME_URL);
		LOGGER = new CommunityLogger("Stock Development");
	}
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractStockDevelopment();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Stock Development.csv", a.data().printAll());
	}


	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		
//		String html = getHtmlWithChromeBrowser("https://www.stockdevelopment.com/Homes/Search", driver);
		String html=U.getHTML("https://www.stockdevelopment.com/Projects/Search?id=communities&sortBy=1");
		String comSection[] = U.getValues(html, "<div class=\"card ", "<i class=\"mdi mdi-chevron-right\"></i></a>");
		U.log(comSection.length);
		for (String comSec : comSection) {
			String comUrl = HOME_URL +  U.getSectionValue(comSec, "<a class=\"mt-1 mt-md-3 lead\" href=\"", "\"").replaceAll("/about|/floorplans|/inventory", "");
			U.log("comUrl ::"+comUrl);
			
//			try {
//				addDetails(comUrl,comSec);
//			} catch (Exception e) {}
			
			addDetails(comUrl,comSec);
			
			i++;
//			break;
		}
		LOGGER.DisposeLogger();
		driver.quit();
	}
	public void addDetails(String comUrl, String comSec) throws Exception {
		
//		if(!comUrl.contains("https://www.stockdevelopment.com/projects/citria"))return;
		
//		U.log("comSec: "+comSec);
		//Coming Fall 2022
//		try {
			
		U.log(i + "---comURL:::" + comUrl);
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------------->Repeated");
			return;
		}
		
//		if(comUrl.contains("https://www.stockdevelopment.com/projects/estero-crossing")){
//			LOGGER.AddCommunityUrl(comUrl+"------------->Return");
//			return;
//		}
		
//		String geo="TRUE";
		String geo="FALSE";
		String[] modelSecUrls;
		String modelSectionHtml=ALLOW_BLANK;
		
		LOGGER.AddCommunityUrl(comUrl);
		String commHtml=U.getHTML(comUrl);

		String rmSec=U.getSectionValue(commHtml, "<h4 class=\"text-white\">STOCK Family of Companies</h4>", "<div class=\"row mt-3 mt-md-4\">");
		
		//----remove nav bar------
		commHtml = U.removeSectionValue(commHtml, "<body>", "<section class=\"header-3 p-0\">");
		commHtml = U.removeSectionValue(commHtml, "<footer class=\"", "</html>");
		
		
//		if(commHtml.contains("</i> Visit website</a>")) {
//			String url_section=U.getSectionValue(commHtml, "<h4>Navigation</h4>", "Visit website");
//			if(url_section!=null) {
//				String commLink=U.getSectionValue(url_section, "href=\"", "\"");
//				U.log("commLink=="+commLink);
//			}
//		}
//		

		String aboutCommHtml= "",floorPlanHtml ="", movePlanHtml = "",modelCollection = "",website="";
		String mapHTML="";
		String[] sideUrls_sec =  U.getValues(commHtml, "content-between align-items-center mb-lg-0\"", "</span>");
		U.log("sideUrls.length: "+sideUrls_sec.length);
		String commLinkHtml="";
		for(String sideUrl_sec : sideUrls_sec){
			String sideUrl=U.getSectionValue(sideUrl_sec, "href=\"", "\"");
			if(sideUrl_sec.contains("Visit website")) {
				String commLink=U.getSectionValue(sideUrl_sec, "href=\"", "\"").replace("//", "");
//				U.log("commLink=="+commLink);
//				commLink=commLink.replace("inspiranaples.com", "");
				if(commLink!=null) {
					commLink=commLink.replace("www.citrialiving.com", "https://citrialiving.com/")
							.replace("www.stockcustomhomes.com", "https://www.stockcustomhomes.com/")
							.replace("www.alluranaples.com/", "https://www.alluranaples.com/")
							;
					U.log("commLink=="+commLink);
//					if(commLink!=null) {
					if(commLink.contains("inspiranaples.com"))continue;
					commLinkHtml=U.getHtml(commLink,driver);
					commHtml+=commLinkHtml;

					if(commLinkHtml!=null) {
						String navSec=U.getSectionValue(commLinkHtml, "<nav class=\"navbar", " </nav>");
						if(commLink.contains("https://www.alluranaples.com/"))
							navSec=U.getSectionValue(commLinkHtml, "data-auto=\"navigation-pages\">", "</nav>");
						if(navSec!=null) {
							String[] navUrls=  U.getValues(navSec, "<a href=\"", "\"");
							if(navUrls.length>0) {
								for(String nav_url:navUrls) {
									U.log("navUrls=="+nav_url);
									if(nav_url.contains("inventory")) {
										movePlanHtml+=U.getHtml(commLink+nav_url, driver);
									}
									if(nav_url.contains("/floor-plans")) {
										floorPlanHtml+=U.getHtml(commLink+nav_url, driver);
									}
									if(nav_url.contains("/amenities")) {
										commHtml+=U.getHtml(commLink+nav_url, driver);
									}
									if(nav_url.contains("/interactive-map")) {
										mapHTML+=U.getHtml(commLink+nav_url, driver);
									}
								}
							}
						}
					}
//					}
					
				}
				
			}
			U.log("sideUrl : "+sideUrl);
			if(sideUrl.contains("floorplans")) { 
				floorPlanHtml = U.getHtml("https://www.stockdevelopment.com"+sideUrl,driver);
				U.log(U.getCache("https://www.stockdevelopment.com"+sideUrl));
			}
				
			if(sideUrl.contains("inventory"))
				movePlanHtml = U.getHTML("https://www.stockdevelopment.com"+sideUrl);
			if(sideUrl.contains("models")) {
				modelCollection = U.getHTML("https://www.stockdevelopment.com"+sideUrl);
				String modelSec=U.getSectionValue(modelCollection, "<tbody>", "</tbody>");
//				U.log("modelSec>>>>>>>>>>"+modelSec);
				if(modelSec!=null) {
				modelSecUrls=U.getValues(modelSec, " <a href=\"", "\"");
				modelSecUrls=(modelSecUrls==null)?new String[] {}:modelSecUrls;	
				for(String modelSecUrl:modelSecUrls) {
					if(!modelSecUrl.contains("/Homes/VirtualTour/")) {
						U.log("modelSecUrl: "+modelSecUrl);
						if(modelSecUrl.contains("/projects/")) {
							modelSectionHtml+=U.getHTML("https://www.stockdevelopment.com/"+modelSecUrl);
						}else {
							modelSectionHtml+=U.getHTML("https://www.stockdevelopment.com/"+modelSecUrl);
						}
					}
				}
			}
			}
			if(sideUrl.startsWith("//www."))
				website = U.getHTML(sideUrl.replace("//www", "https://www"));
		}
		
		aboutCommHtml = U.getHTML(comUrl+"/about");
//rmsec		
		aboutCommHtml=aboutCommHtml.replace(rmSec,"").replace("the two-story clubhouse", "").replace("two-story, 10,000", "").replace("a two-story 10,000 SF clubhouse", "");
		String aboutSection=U.getSectionValue(aboutCommHtml, "<div class=\"col-12 col-lg-8\">", "</div>");
		
		
		floorPlanHtml = U.removeSectionValue(floorPlanHtml, "<body>", "<section class=\"header-3 p-0\">");
		floorPlanHtml = U.removeSectionValue(floorPlanHtml, "<footer class=\"", "</html>");
		movePlanHtml = U.removeSectionValue(movePlanHtml, "<body>", "<section class=\"header-3 p-0\">");
		movePlanHtml = U.removeSectionValue(movePlanHtml, "<footer class=\"", "</html>");
//		U.log(comSec);
		String note = U.getnote(commHtml+comSec);
		//-----CommName
		String commName=StringEscapeUtils.unescapeHtml4(U.getSectionValue(commHtml, "<h1 class=\"display-4 d-block text-white\">", "</h1>"));
		commName=commName.replace("ARYA", "Arya");
		U.log("Communtiy Name "+commName);
		//-----Address
		String addSec=U.getSectionValue(aboutCommHtml, "<address class='d-block'>", "</address>");
		if(addSec==null) {
			String addSec1=U.getSectionValue(commHtml, "text header__text--address\">", "</a>");
			U.log("addSec::::::::::"+addSec1);
			if(addSec1!=null) {
				addSec1=U.getSectionValue(addSec1, "<span>", "</span>").replace("<br>", ", ");
				addSec=addSec1;
			}
		}
		
//		U.log("MMMMMMM "+Util.matchAll(commHtml, "[\\s\\w\\W]{30}16210 Allura Cir[\\s\\w\\W]{30}", 0));

		
		if(addSec!=null)
			addSec = addSec.replace("<br />", ", ").replace("Opening Spring 2019, Call for more information", "");
		
//		U.log("MMMMMMM "+Util.matchAll(commHtml, "[\\s\\w\\W]{30}26.3017726[\\s\\w\\W]{30}", 0));

		U.log("addSec::::::::::"+addSec);
		
		String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latLon[] ={ALLOW_BLANK,ALLOW_BLANK};
		String latlonSec=U.getSectionValue(commHtml, " href=\"https://www.google.com/maps/@", "/");
				if(latlonSec!=null) {
					latlonSec=latlonSec.replaceAll(",\\d+z", "");
					U.log("latlonSec::::::::::"+latlonSec);
					latLon=latlonSec.split(",");
				}
//				latLon[1]=latLon[1].replaceAll(", \\d+", "");
				U.log("LatLon "+Arrays.toString(latLon));
				
		
		if(addSec!=null)
			add=U.getAddress(addSec);
		
		if (comUrl.contains("https://www.stockdevelopment.com/projects/babcock-ranch")) {//Community Page address currently unavailable on maps so taking from zip and state "42191 Lake Timber Drive,	Babcock Ranch, FL 33928"
			note="Add-LatLong Is  Taken From State,Zip";
			add[0]="8502 FL-31";
			add[1]="Punta Gorda";
			add[2]="FL";
			add[3]="33982";
		}
		if(comUrl.contains("https://www.stockdevelopment.com/projects/estero-crossing"))
		{
			add[1]="Estero";
			add[2]="FL";
			latLon=U.getlatlongGoogleApi(add);
			U.log("Latlng"+Arrays.toString(latLon));
			
			if(latLon != null){
				add = U.getAddressGoogleApi(latLon);
				geo="TRUE";
				note="Address taken from City And State";
			}
			
		}
		if(comUrl.contains("https://www.stockdevelopment.com/projects/inspira"))
		{
			add[1]="Naples";
			add[2]="FL";
			latLon=U.getlatlongGoogleApi(add);
			if(latLon != null){
				add = U.getAddressGoogleApi(latLon);
				geo="TRUE";
				note="Address taken from City And State";
			}
			
		}
		
		
		
		
		if (comUrl.contains("https://www.stockdevelopment.com/projects/spectra")) {//Community Page address currently unavailable on maps so taking from zip and state "42191 Lake Timber Drive,	Babcock Ranch, FL 33928"
			note="Add-LatLong Is  Taken From City,State";
			add[0]="Emerson Square Boulevard";
			add[1]="Fort Myers";
			add[2]="FL";
			add[3]=ALLOW_BLANK;
			
			latLon=U.getlatlongGoogleApi(add);
			if(latLon == null) latLon = U.getlatlongHereApi(add);
			
			if(latLon != null){
				add = U.getAddressGoogleApi(latLon);
				if(add == null)add = U.getAddressHereApi(latLon);
				geo="TRUE";
				note="Address taken from City And State";
			}
			
		}
		
		
		
		U.log("Address "+Arrays.toString(add));
		//-----LatLon
		if( latLon==null || latLon[0].length()<5 || latLon[0]==ALLOW_BLANK ) {
		 latLon =U.getlatlongGoogleApi(add);
		 geo="TRUE";
		}
		if(latLon == null) latLon = U.getlatlongHereApi(add);
		
		if(comUrl.contains("https://www.stockdevelopment.com/projects/allura"))
		{
			addSec=U.getSectionValue(commHtml, "<span class=\"font-size-16 m-font-size-13\" style=\"display: initial;\">", "</span>").replace("Cir. Naples", "Cir., Naples");
			add=U.getAddress(addSec);
			latlonSec=U.getSectionValue(commHtml, "google.com/maps/place/Allura/", "/");
			U.log("latlonSec::::::::::"+latlonSec);
			latLon[0]=U.getSectionValue(latlonSec, "@", ",");
			latLon[1]="-"+U.getSectionValue(latlonSec, ",-", ",");
			geo="FALSE";
		}
		
		
		U.log("LatLon "+Arrays.toString(latLon));
		
		//--=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-
		String floorPlansHtml="";
		String floorPlanSecs[]=U.getValues(floorPlanHtml, "<a class=\"mt-3 lead\" href=\"", "\">");
		for (String floorPlan : floorPlanSecs) {
			//try{
			U.log("floor Plans ::"+HOME_URL+floorPlan);
			String floorTempHtml=U.getHTML(HOME_URL+floorPlan);
			if(floorTempHtml.contains("2,409,990")) {
				U.log("FOUND");
			}
			floorPlansHtml+=U.getSectionValue(floorTempHtml, "<ul class=\"list-inline stats stats-full\">", "</section>");
		//	}catch(Exception e){}
		}
		
		floorPlansHtml += floorPlanHtml;
		
		String inventoryPlansHtml="";
		String inventoryPlanSecs[]=U.getValues(movePlanHtml, "<a class=\"card row no-gutters flex-column flex-md-row hover-effect\" href=\"", "\">");
		for (String inventoryPlan : inventoryPlanSecs) {
			//try{
			String floorTempHtml=U.getHTML(HOME_URL+inventoryPlan);
			inventoryPlansHtml+=U.getSectionValue(floorTempHtml, "<ul class=\"list-inline stats stats-full\">", "</section>");
			//}catch(Exception e){}
		}
		String extrastatus="";
		U.log("inventoryPlanSecs-0-0-0   "+inventoryPlanSecs.length);
		if (inventoryPlanSecs.length>0) {
			extrastatus=" Move In Ready Home";
		}
		U.log(">>>>>>>>>>   "+extrastatus);
		//========== Prices ================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comSec = comSec.replaceAll("0s|0k", "0,000").replace("$2M to over $7M", "$2,000,000 to over $7,000,000");
		commHtml = commHtml.replaceAll("0s|0k", "0,000");
		
		comSec = comSec.replace("<li>Starting from $4.5M</li>", "<li>Starting from $4,500,000</li>").replaceAll(" Million", ",000,000").replace("to over $4M</li>", "to over $4,000,000</li>").replace("<li>Starting from $2M</li>", "<li>Starting from $2,000,000</li>");
		commHtml = commHtml.replaceAll(" Million", ",000,000").replace("from the $ 300’s to over $ 600 thousand", "from the $300,000 to over $600,000");
		comSec = comSec.replace("5k", "5,000").replace("over $2M", "over $2,000,000")
				.replace("4M", "4,000,000").replace("1.5M", "1,500,000").replace("1M", "1,000,000").replace("3M", "3,000,000").replace("Now leasing from the $1,500,000", "");
//			U.log(comSec);		
//		U.log("MMMMMMM "+Util.matchAll(modelSectionHtml+comSec + commHtml+floorPlansHtml+inventoryPlansHtml+movePlanHtml, "[\\s\\w\\W]{30}\\$1[\\s\\w\\W]{30}", 0));
			
		String[] price = U.getPrices(modelSectionHtml+comSec + commHtml+floorPlansHtml+inventoryPlansHtml+movePlanHtml,
						"Offered furnished at</span> \\$\\d,\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3} to over \\$\\d,\\d{3},\\s{3}|from the \\$\\d,\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} to over \\$\\d{3},\\d{3}|over \\$\\d,\\d{3},\\d{3}|Starting from \\$\\d,\\d{3},\\d{3}|Offered at \\$[\\d,]*\\d{3},\\d{3}\\s*<|<p class=\"mb-1\">Offered at \\$\\d,\\d{3},\\d{3} <i|<p>Starting from \\$\\d{3},\\d{3}</p>|High \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|from \\$\\d,\\d{3},\\d{3}|from the High \\$\\d{3},\\d{3}\\s*<|from the Mid \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|to over \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|from the High \\$\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|Offered at</span> \\$\\d,\\d{3},\\d{3}| \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Starting from</span> \\$\\d{3},\\d{3}|the Low \\$\\d{3},\\d{3}|the Mid \\$\\d{3},\\d{3}|offered at</span> \\$\\d{3},\\d{3}|Starting from(</span>)? \\$\\d,\\d{3},\\d{3}",
						0);

		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice); 
		
		//========== Sqft =================
		
		
		commHtml=commHtml.replaceAll("The clubhouse also includes a 3,000-square-foot|workout awaits you at our 3,000 square-foot|Your fitness dreams have finally come true with our 3,000 sq. ft", "");
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet((modelSectionHtml+commHtml+comSec+floorPlansHtml+floorPlanHtml+inventoryPlansHtml +movePlanHtml)
				.replaceAll("workout awaits you at our 3,000 square-foot state-of-the-art|The clubhouse also includes a 3,000-square-foot", ""),
				"\\d{4} to<br />\\d{4} sq.ft.|\\d{3} to<br />\\d{4} sq.ft.|\\d{3} to<br />\\d{3} sq.ft.|\\d{3}</span> sq.ft.|\\d{4}</span> sq.ft.|\\d,\\d{3} Living|Homes from \\d,\\d+ to over \\d,\\d+|Homes from \\d,\\d{3} to \\d,\\d{3} sq. ft.|from \\d,\\d{3} to over \\d,\\d{3} Sq. Ft.</li>|from \\d{3} to \\d{4} Sq. Ft.|li class=\"list-inline-item\">\\s+\\d,\\d{3} Living\\s+</li>|from \\d,\\d+ to \\d,\\d+ square feet| \\d,\\d+ - \\d,\\d+ sq. ft.| \\d,\\d+ sq.ft| \\d,\\d+ Sq. Ft.", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		
//		U.log("MMMMMMM "+Util.matchAll(movePlanHtml, "[\\s\\w\\W]{100}3,000[\\s\\w\\W]{30}", 0));

		
		//============ Property Status ===========
		//U.log(comSec);
		for (String str : Util.matchAll(comSec, "</i> \\d+ \"Move in ready\" Homes </li>", 0)) {
			comSec=comSec.replace(str, str.replace("\"", ""));
		}
//		U.log(website);
//		U.log("::::::::::"+U.getSectionValue(commHtml, "<div class=\"badge-bottom\">", "</div>"));
		commHtml=commHtml.replace("designed and furnished move-in-ready estate homes", "")
				.replace("Coming in Spring 2022","Coming Spring 2022")
				.replaceAll("href=\"/homes/search\">Move in Ready Homes</a></li>|With the grand opening of our spectacular 70,000-square-foot ", "");
		if(website != null) website = website.replaceAll("COMING SOON|HOURS<br />\n\\s*COMING SOON|Hours Coming", "");
		String pStatus = U.getPropStatus(extrastatus+(commHtml+comSec+website).replaceAll("data-type~=sold-out|[M|m]ove [I|i]n|[M|m]ove-[I|i]n|construction and coming Winter 2021|projects coming|Coming soon is Estero", ""));
		
//		+comSec+floorPlansHtml+floorPlanHtml+inventoryPlansHtml+movePlanHtml+aboutSection
		
		U.log("status===="+pStatus);
		
		//============== Property Type =============
		commHtml = commHtml.replace("masterful craftsmanship", "masterful Craftsman style details")
				.replace("estate community", "estate homes").replace(" luxury define the residences", "luxury homes");
		floorPlansHtml = floorPlansHtml.replaceAll("\">Manor</h4>|Regency Manor", "manor style homes").replaceAll(">Estate</h4>", "\">Estate Homes</h4>");
		
		String pType = U.getPropType((commHtml+comSec+floorPlansHtml+floorPlanHtml+inventoryPlansHtml+movePlanHtml+aboutSection).replaceAll("participation|content=\"Learn more about STOCK Luxury Apartment Living at Citria|construction and craftsmanship |Mediterranean-style clubhouse|\">Apartment Living</a></li>", ""));
		U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0));

		U.log("pType: "+pType);
		//=========== Community Type ===========
		commHtml = commHtml.replaceAll("Sarasota Polo Club as well as five pier golf courses|Country Club East|span class=\"h5 mb-0\">\"Move in Ready\" Homes</span>|<span class=\"h6 d-block mb-0\">Move in Ready Homes</span>", "");
		String comType = U.getCommunityType((commHtml+aboutCommHtml+comSec)
				.replaceAll("resort-style swimming pool|Resort Style Pool", ""));


		//=========== Derived Type ============
		U.log("Matching"+Util.match(commHtml, "The social hub of the community will be the three-story"));
		aboutCommHtml=aboutCommHtml.replace("The social hub of the community will be the three-story", "");
		commHtml=commHtml.replaceAll("consist of 304 units in five 3-story buildings on 35.92 acres|The social hub of the community will be the three-story","");	
		String dType = U.getdCommType((commHtml+comSec+floorPlansHtml+floorPlanHtml+inventoryPlansHtml+movePlanHtml+aboutCommHtml
				.replace("two-story", "2 story").replace("story 1", "story  1"))
				.replaceAll("Floor|Lakewood Ranch|consist of 304 units in five 3-story buildings on 35.92 acres", ""));
//		U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{30}3-story[\\w\\s\\W]{30}",0));
//		U.log(Util.matchAll(floorPlansHtml, "[\\w\\s\\W]{30}3-story[\\w\\s\\W]{30}",0));
//		U.log(Util.matchAll(comSec, "[\\w\\s\\W]{30}3-story[\\w\\s\\W]{30}",0));
//		U.log(Util.matchAll(floorPlanHtml, "[\\w\\s\\W]{30}3-story[\\w\\s\\W]{30}",0));
//		U.log(Util.matchAll(commHtml+comSec+floorPlansHtml+floorPlanHtml+inventoryPlansHtml+movePlanHtml+aboutCommHtml, "[\\w\\s\\W]{30}3-story[\\w\\s\\W]{30}",0));

		
		
		
		U.log("dType: "+dType);
		//========= Notes ==============
		
		
		String moveHtml = U.getHTML("https://www.stockdevelopment.com/Homes/_SearchResult");
		String[] moveSec = U.getValues(moveHtml, "<span class=\"h3 text-white mb-0\">", "<");
		
		for(String moveName : moveSec) {
//			U.log("moveName >>>>>>>"+moveName);
			
			if(moveName!=null)
				moveName = moveName.replace("&#x27;", "'") ;
			
			if(commName.contains(moveName))
				if(pStatus==ALLOW_BLANK)
					pStatus = "Move In Ready Home";
				else
					pStatus += ", Move In Ready Home";
			
		}
		
		
		//Trim array string
		//U.stripAll(add);
		//U.stripAll(latLong);
		add[0] = add[0].replace("Opening Spring 2019, Call for more information", ALLOW_BLANK);
		if(add[0].length()<4 && latLon[0].length()>4){
			add=U.getAddressGoogleApi(latLon);
			if(add == null) add = U.getAddressHereApi(latLon);
			geo="TRUE";
		}
		if(comUrl.contains("https://www.stockdevelopment.com/projects/country-club-east")) commName = "Country Club East";
		if(comUrl.contains("resort")) comType = "Resort Style, "+comType;
//		if(comUrl.contains("https://www.stockdevelopment.com/projects/citria")){
//			pStatus=pStatus.replace("Coming Soon, ", "");
//		}
		if(comUrl.contains("custom-homes"))pStatus=ALLOW_BLANK;
		if(comUrl.contains("com/projects/inspira"))dType= dType+", 2 Story";
		
			if(comUrl.equals("https://www.stockdevelopment.com/projects/allura"))comUrl="https://www.alluranaples.com/";
			if(comUrl.equals("https://www.stockdevelopment.com/projects/citria"))comUrl="https://citrialiving.com/";

		// ------------------------- Number of Units ---------------------------
		
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

			
			if(comUrl.equals("https://www.alluranaples.com/")) {
			String iframUrl=U.getSectionValue(mapHTML=U.getSectionValue(mapHTML, "<div class=\"rrac_interactive_leasing_view\">", "</iframe>"), "src=\"", "\"");
			U.log("iframUrl==="+iframUrl);
			int sum=0;
			mapHTML= U.getHtml(iframUrl,driver);
			String [] lotCount=U.getValues(mapHTML, "<div class=\"secondary", "</td>");
			for(String lot_count :lotCount) {
				lot_count=lot_count.replace("</span><span>Units", " Units");
				U.log("lot_count==="+lot_count);
				String count=Util.match(lot_count, "\\d+ Units");
				count=Util.match(count, "\\d+");
//				U.log("count==="+count);
				sum+=Integer.parseInt(count);
			}
			units=Integer.toString(sum);
		}
			


		data.addCommunity(commName, comUrl, comType);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLon[0], latLon[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replace("Move In Ready Home, Move In Ready Home", "Move In Ready Home"));
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		
//		}catch (Exception e) {}
	}
	public void findDetails(String comUrl, String comSec,String cHtml,String combinedHomeHtml) throws Exception {
		//if(i == 29)
		{
			
		//	if(!comUrl.contains("https://www.stockdevelopment.com/projects/residences-on-sixth"))return;
			U.log(i + "---comURL:::" + comUrl);
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+"------------->Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			//String html = getHtmlWithChromeBrowser(comUrl,driver);
			U.log(U.getCache(comUrl));
			
//			U.log(comSec);
			//=========== Homes Html ============
			String homeUrlSec[] = U.getValues(cHtml, "class=\"rich-block\">", "</a>");
			
			U.log(homeUrlSec.length);
			if(combinedHomeHtml == "combinedHomeHtml" ){
			for(String homeSec : homeUrlSec){
				String homeUrl = HOME_URL + U.getSectionValue(homeSec, "<a href=\"", "\"");
				U.log("homeUrl::::"+homeUrl);
				if(homeUrl.contains("floorplans/"))
				{
					U.log(":::::::::if success:::::::");
					String homeHtml = U.getHTML(homeUrl);
					String sec = U.getSectionValue(homeHtml, "<div class=\"jumbotron\" ", "</ul>");
					if(sec != null)
					combinedHomeHtml += sec; 
				}
			}
			}
			//if(!comUrl.contains("Country+Club+East"))return;
			
			//================ Community Name ===================
			//U.log(cHtml);
			String regName = U.getSectionValue(cHtml, "hiDivision\" name=\"hiDivision\" type=\"hidden\" value=\"", "\"");
			
			String comName =regName + " "+ U.getSectionValue(cHtml, "<strong>", "</strong>");
			comName = comName.replaceAll("Country Club East |Single Family Homes| Estate Homes| Custom Home Estates", "")
					.replace("WildBlue WildBlue", "WildBlue");
			U.log(comName);
			/*if(comUrl.contains("https://www.stockdevelopment.com/Communities/Quail+West/Single+Family+Homes?brand=Signature"))\
			comName = "Quail West";*/
			//================= Address ===================
			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addSec = U.getSectionValue(cHtml, "mdi mdi-map-marker\"></i>", "</p>");
			U.log(addSec);
			if(addSec != null){
				addSec  =addSec.replace(", Florida,", ", FL");	
				add  =U.getAddress(addSec);
			}			
			U.log("Add::"+Arrays.toString(add));
			
			//================== LatLong ==================
			String[] latLong = {ALLOW_BLANK, ALLOW_BLANK};
			String geo = "False";
			//U.log(comSec);
			String mainCommunitySection = U.getSectionValue(comSec, "<==><==>", "_blank");
			U.log("mainCommunitySection ::"+mainCommunitySection);
			if(mainCommunitySection != null) comSec = comSec.replace(mainCommunitySection, "");
			else mainCommunitySection = comSec;
			String latLngSec = U.getSectionValue(mainCommunitySection, "http://maps.google.com/?q=", "\" target=\"");
			U.log(latLngSec);
			if(latLngSec != null){
				latLong = latLngSec.split(",");
			}
			U.log("latLng::"+Arrays.toString(latLong));
			add[0] = add[0].replace("Opening Spring 2019, Call for more information", "");
			if(add[0].length()<4){
				add = U.getAddressGoogleApi(latLong);
						geo="TRUE";
			}
			
			
			
			//========== Prices ================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec = comSec.replaceAll("0s|0k", "0,000");
			cHtml = cHtml.replaceAll("0s|0k", "0,000");
			
			comSec = comSec.replaceAll(" Million", ",000,000");
			cHtml = cHtml.replaceAll(" Million", ",000,000");
			
			comSec = comSec.replace("5k", "5,000");
			//	U.log(comSec);		
			String[] price = U.getPrices(comSec + cHtml +combinedHomeHtml,
							"High \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|from \\$\\d,\\d{3},\\d{3}|from the High \\$\\d{3},\\d{3}\\s*<|from the Mid \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|to over \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|from the High \\$\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|Offered at</span> \\$\\d,\\d{3},\\d{3}| \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|Starting from</span> \\$\\d{3},\\d{3}|the Low \\$\\d{3},\\d{3}|the Mid \\$\\d{3},\\d{3}|offered at</span> \\$\\d{3},\\d{3}|Starting from</span> \\$\\d,\\d{3},\\d{3}",
							0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
			
			//========== Sqft =================
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(cHtml+comSec+combinedHomeHtml, "from \\d,\\d+ to \\d,\\d+ square feet| \\d,\\d+ - \\d,\\d+ sq. ft.| \\d,\\d+ sq.ft| \\d,\\d+ Sq. Ft.", 0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
			
			//============ Property Status ===========
			U.log("::::::::::"+U.getSectionValue(cHtml, "<div class=\"badge-bottom\">", "</div>"));
			String pStatus = U.getPropStatus(cHtml+comSec);
			
			//============== Property Type =============
			String pType = U.getPropType((cHtml+combinedHomeHtml).replaceAll("Mediterranean-style clubhouse|\">Apartment Living</a></li>", ""));
			
			//=========== Community Type ===========
			cHtml = cHtml.replaceAll("Country Club East|resort-style pool|resort-style and family swimming pool| resort-style swimming pool|resort-style pool|Resort Style Pool", "");
			String comType = U.getCommunityType(cHtml);
			
			//=========== Derived Type ============
			String dType = U.getdCommType((cHtml+combinedHomeHtml).replaceAll("Lakewood Ranch", ""));
			
			//========= Notes ==============
			String note = U.getnote(cHtml);
			
			//Trim array string
			//U.stripAll(add);
			//U.stripAll(latLong);
			if(add[1]==ALLOW_BLANK && latLong[0].length()>4){
				add=U.getAddressGoogleApi(latLong);
				geo="TRUE";
			}
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLong[0], latLong[1], geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
		}
		i++;
	}

	private void findApartmentDetails(String apartmentUrl, String apartmentSec, WebDriver driver) throws Exception {

		if (!apartmentUrl.startsWith("http")) {
			if (apartmentUrl.contains("www.inspiranaples.com"))
				apartmentUrl = "http://" + apartmentUrl;
			else
				apartmentUrl = "https://" + apartmentUrl;
		}

		U.log("aprtmenturl ---->" + apartmentUrl);
		String html = U.getHTML(apartmentUrl);

		// ============= Community Name =============
		String comName = U.getSectionValue(apartmentSec, "<h3>", "</h3>");

		if (comName != null) {
			comName = comName.replace("<small>coming soon</small>", "").trim();
		}

		// ================ Address =============
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		add[0] = U.getSectionValue(html, "address\":\"", "\"");
		add[1] = U.getSectionValue(html, "city\":\"", "\"");
		add[2] = U.getSectionValue(html, "state\":\"", "\"");
		add[3] = U.getSectionValue(html, "zip\":\"", "\"");

		if (add[2] != null && add[2].length() > 2) {
			add[2] = USStates.abbr(add[2]);
		}

		// =============== LatLong ===============
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		latLong[0] = U.getSectionValue(html, "latitude\":\"", "\"");
		latLong[1] = U.getSectionValue(html, "longitude\":\"", "\"");

		// ========== Navigate Menu ===============
		String floorplan = null, amenties = null, feature = null;
		String navSection = U.getSectionValue(html, "<nav>", "</ul>");
		if (navSection != null) {
			String navUrl = U.getSectionValue(navSection, "<a href=\"", "\"");
			if (navUrl.contains("floorplans"))
				floorplan = U.getHTML(navUrl);
			if (navUrl.contains("amenities"))
				amenties = U.getHTML(navUrl);
			if (navUrl.contains("features"))
				feature = U.getHTML(feature);
		}

		// ============= Sqft =============
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html + apartmentSec + floorplan, "(\\d,)?\\d{3} Sq. Ft.", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// ======== Community Type =========
		String comType = U.getCommunityType(html + amenties + apartmentSec);

		// ============= Property Type ============
		String pType = U.getPropType(html + apartmentSec + feature);

		// ============ Property Status =========
		String pStatus = U.getPropStatus(html + apartmentSec);

		// ============ Derived Type ===========
		String dType = U.getdCommType(html + apartmentSec);

		// ==========Notes ==========
		String note = ALLOW_BLANK;

		if (apartmentUrl.contains("www.inspiranaples.com")) {
			add = U.getAddress("Grand Lely Dr, Naples, FL");
			latLong = U.getlatlongGoogleApi(add);
			add[3] = U.getAddressGoogleApi(latLong)[3];
			geo = "True";
			note = "Street Name Is Taken From Area Map";
		}
		// Grand Lely Dr, Naples Florida, Area Map
		// U.stripAll(add);
		// U.stripAll(latLong);

		data.addCommunity(comName, apartmentUrl, comType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(ALLOW_BLANK, ALLOW_BLANK);
		data.addLatitudeLongitude(latLong[0], latLong[1], geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);

	}

	public static String getHtmlWithChromeBrowser(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new ChromeDriver();

		String html = null;

		String fileName = U.getCache(url);
		File f = new File(fileName);
		if (f.exists()) {
			return FileUtil.readAllText(fileName);
		}

		if (!f.exists()) {
			synchronized (driver) {

				BufferedWriter writer = new BufferedWriter(new FileWriter(f));
				driver.get(url);
				Thread.sleep(2000);

				//((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); // y value '400' can

				Thread.sleep(10000);
				U.log("Current URL:::" + driver.getCurrentUrl());
				html = driver.getPageSource();
				Thread.sleep(5000);
				writer.append(html);
				try {
					WebElement click = driver.findElement(By.xpath("//*[@id=\"resultSide\"]/div[2]/div/ul/li[3]/a"));
					click.click();
					U.log("Click success....");
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); // y value '400' can
					Thread.sleep(10000);
					html += driver.getPageSource();
					writer.append(html);
				} catch (Exception e) {
					U.log("click unsuccess....");
				}
				writer.close();

			}
		}
		return html;
	}
}
