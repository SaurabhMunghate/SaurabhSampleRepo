// modified =17/03/2022

package com.shatam.b_061_080;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class FirstTexasHomes extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	static int i = 0;
	static CommunityLogger LOGGER;
	static int j = 0;
	WebDriver driver=null;
	HashMap<String, String> hm = new HashMap<String, String>();

	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new FirstTexasHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "First Texas Homes.csv", a.data().printAll());
		

	}

	public FirstTexasHomes() throws Exception {

		super("First Texas Homes", "https://www.firsttexashomes.com/");
		LOGGER = new CommunityLogger("First Texas Homes");
	}

	// WebDriver driver=new FirefoxDriver();
	public void innerProcess() throws Exception {
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();


		String html = U.getHtml("https://www.firsttexashomes.com/communities", driver);//("https://www.firsttexashomes.com/communities");

		String urlSec=U.getSectionValue(html, "Communities\n" + 
				"                                        <span class=\"icon icon-angle-down\">", "Financing\n" + 
						"                                        <span class=\"icon icon-angle-down\">");
		String[] regionsSec = U.getValues(html, "<div class=\"card_row card-row-4 isDividedRow\" ", "View Community</span>");
		U.log("Total Community:::>" + regionsSec.length);
		for (String data : regionsSec) {
			String comNames = U.getSectionValue(data, "<span class=\"card_title \" card_link\"=\"\">", "<");
			
			String commUrl = "https://www.firsttexashomes.com"+U.getSectionValue(data, "<div class=\"card_title\"><a href=\"", "\"");

			addDetail(commUrl, data, comNames);

		}
//		 driver.quit();
		LOGGER.DisposeLogger();
	}

	public void addDetail(String commUrl, String dataa, String commName) throws Exception {
//		try{	
//		if(j >=35 && j<40 )
	{
		
			//TODO : Execute for single community
		
//		if(!commUrl.contains("https://www.firsttexashomes.com/communities/Mercer-Crossing--Kensington-Townhomes-150018"))return;
		

		U.log(j+"\nPage:" + commUrl + "\n com name : " + commName.trim() + "::::::::");
		if(commName!=null) {
			commName=commName.replaceAll("Estates|estates", "");
		}
		if (data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + commUrl);
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
//		U.log("dataa====\n"+dataa);	
	
		String html = U.getHtml(commUrl, driver);
		//String html = U.getPageSource(commUrl);
//		String html = U.getHTMLwithProxy(commUrl);
		
		
		html=U.removeSectionValue(html, "<!-- ========= JS Section ========= -->", "</body>");
		
		String  quickSec=U.getSectionValue(U.getHtml("https://www.firsttexashomes.com/quick-move-in",driver), "\" data-auto=\"page-text-style\">Quick Move-in<", "</ul>");
		
//		String  quickSec=U.getSectionValue(U.getHTMLwithProxy("https://www.firsttexashomes.com/quick-move-in"), "\" data-auto=\"page-text-style\">Quick Move-in<", "</ul>");

		String[] quicRegnUrl=U.getValues(quickSec, "<a href=\"", "\"");
		String quickRegnHtml="";
		U.log("???????????=="+quicRegnUrl.length);
		for(String url: quicRegnUrl)
		{
			String regnURL="https://www.firsttexashomes.com"+url;
//			U.log("QuickregnURL=="+regnURL);
			 quickRegnHtml += U.getHtml(regnURL, driver);
		}
		int count=0;
		int qhmcountt=0;
		String [] quickHomes=U.getValues(quickRegnHtml, "<div id=\"card_header_home", "View Community");
		U.log("quickHomes==="+quickHomes.length);
		for(String home : quickHomes) {
			
			
			if(home.contains(commName)) {
				count++;
//				U.log("MMMMMM===="+home);
				
			}
		
		}
		U.log("count==="+count);
		
		
		
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
		String flag = "FALSE";
//U.log("data=="+dataa);
		String addSec=U.getSectionValue(html, "<span class=\"address-text\">", "</span>");
//		U.log("data=="+dataa);
		if(addSec!=null) //dt june
		  add=U.getAddress(addSec);
		if( add[0].contains("${addr ? `${addr}")) {
//	U.log("KKKKKKKKK");
			addSec=U.getSectionValue(dataa, "<a href=\"https://www.google.com/maps?z=18&amp;q=", "\"");
//			U.log("addSec=="+addSec);
			add=addSec.split(",");
		}
		
		
		
		if(addSec==null) {
		if (dataa.contains("<span class=\"addressStreet\">")) {
			add[0] = U.getSectionValue(dataa, "<span class=\"addressStreet\">", "</span>");
			add[1] = U.getSectionValue(dataa, "<span itemprop=\"addressLocality\">", "</span>");
			add[2] = U.getSectionValue(dataa, "<span itemprop=\"addressRegion\">", "</span>");
			add[3] = U.getSectionValue(dataa, "<span itemprop=\"postalCode\">", "</span>");
			if(add[0].length()<4) {
				add[0]=U.getSectionValue(html, "<span class=\"addressStreet\">", "</span>");
			}
			if(add[0]!=null) {
				add[0]=add[0].replace("Coming Soon", "");
			}
			U.log("Address:::" + Arrays.toString(add));
		}
		}
		
		//**jume
		if(add[0].length()<4||add[0].equals(ALLOW_BLANK)) {
			addSec=U.getSectionValue(html, "<span class=\"address-text\">", "</a></div>");
			addSec=U.getNoHtml(addSec);
			add=U.getAddress(addSec.replace("target=\"_blank\">", ""));
		}
		
		
		String latlngSec=U.getSectionValue(html, "<div class=\"add-container\"><a href=\"https://www.google.com/maps/place/", "\"");
//		U.log("latSec==="+latlngSec);
		if(latlngSec!=null) {
		latLong=latlngSec.split(",");
		
		}else
		{
			 latlngSec=U.getSectionValue(html, "console.log(\"initMap, map\");", " window.map");

//		 latlngSec=U.getSectionValue(html, "href=\"https://maps.google.com/maps?ll=", "&amp");
			 if(latlngSec!=null) {
           
				 latLong[0]=U.getSectionValue(latlngSec, "lat:", ",");
			     latLong[1]=U.getSectionValue(latlngSec, "lng:", "}");
			
			 }
			 else {
			       latlngSec=U.getSectionValue(html,"<a href=\"https://www.google.com/maps/place","</a></div> ");
			       if(latlngSec!=null) {
			       latLong[0]=U.getSectionValue(latlngSec, "/", ",");
				   latLong[1]=U.getSectionValue(latlngSec, ",", "\"");
			       }
			 }

//		 latLong=latlngSec.split(",");
		}
		U.log("Latlong:::" + Arrays.toString(latLong));
		

		if (dataa.contains("data-latitude=\"")) {
			latLong[0] = U.getSectionValue(dataa, "data-latitude=\"", "\"");
			latLong[1] = U.getSectionValue(dataa, "data-longitude=\"", "\"");
			U.log("Latlong:::" + Arrays.toString(latLong));
		}
		if(add[0].length()<4 && latLong[0].length()>4) {
			add=U.getAddressGoogleApi(latLong);
			flag="TRUE";
		}
		
		if(add[0].length()>3)
			add[0] = add[0].replaceAll("sames@firsttexashomes.com", "");
		if(add[0]!=null) {
			add[0]=add[0].replace("Coming Soon!!!", "");
		}
		if(add[0].length()==0) {
			add=U.getAddressGoogleApi(latLong);
			flag="TRUE";
		}
		U.log("address:- " + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
		//String[] planUrls = U.getValues(html, "<a class=\"image-box\" href=\"", "\"");
		String[] planUrls = U.getValues(html, "<div class=\"card_row card-row-3", "class=\"card_image_container \">");
		
		String planHtml = ""; int k=0;
		String planhtml="";
		String planSec="";
		String planSec2="";
		if (planUrls.length > 1) {
			for (String purl : planUrls) {
				k++;
				//if(k<5)continue;
			//	U.log("Purl"+purl);
				String planUrl=U.getSectionValue(purl, "<a class=\"card_anchor\" href=\"", "\">");
//			U.log("plan Url:: "+"https://www.firsttexashomes.com" + planUrl);
			planhtml=U.getHtml("https://www.firsttexashomes.com" + planUrl,driver);
			planhtml =U.removeSectionValue(planHtml, ">Available in These Communities<", "</script> ");
				planHtml = planHtml + planhtml;
				
				if(planHtml.contains("461,950")) {
					U.log("FOUND");
				}
				U.bypassCertificate();
				
				if(planHtml.contains("928,950"))
				{
					U.log("FOUND==928,950");
				}
				
				 planSec+=" "+U.getSectionValue(planHtml, "<div class=\"communityAndHomesDetails\">", ">Photo Gallery</h3>");
				 planSec2+=" "+U.getSectionValue(planHtml, "<div class=\"inline-data-binding-markup\"", "</div> ");			
			}

		}

		// =====================================================================================================================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html + planHtml + dataa,
				">\\d,\\d{3} - \\d,\\d{3} Sq. Ft|sqft\">\\d,\\d{3}</li>| \\d,\\d+ Sq. Ft|\\d,\\d+ to \\d+,\\d+ plus square feet|\\d+,\\d+ to \\d+,\\d+ square feet|\\d,\\d+ and \\d,\\d+ plus square feet|\\d,\\d+ and \\d,\\d+ square feet",
				0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		// =========================================================================================================================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replaceAll("0’s|0's", "0,000");
		String[] price = U.getPrices(html + planHtml + dataa,
				"begin in the low \\$?\\d{3},\\d{3}|Priced at \\$\\d{3},\\d{3}|starting in the high \\$\\d{3},\\d{3}|tarting at <span>\\$\\d{3},\\d{3}</span></p>|Priced at \\$\\d{3},\\d{3} |dealPrice\">\\$\\d{3},\\d{3}|<span>\\$\\d+,\\d+</span>|starting at \\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|From the high \\$\\d+,\\d+",
				0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html , "[\\s\\w\\W]{30}461,950[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll( planHtml , "[\\s\\w\\W]{30}461,950[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll( dataa, "[\\s\\w\\W]{30}461,950[\\s\\w\\W]{30}", 0));

		
		// ============================================================================================================================
		
		
		String removeSec=U.getSectionValue(html, "<!-- ========= JS Section ========= -->", "</body>");
		if(removeSec!=null) {
			html=html.replace(removeSec, "");
		}
		html=html.replaceAll("config.Gated|data.IsGated", "");
		String commType = U.getCommType(html );
		U.log("commType=="+commType);
		
	//====================================================================================	
		
		String remSec=U.getSectionValue(html, "COMMUNITIES</a>", ">MULTIMEDIA</a>");
		if(remSec!=null) {
			html=html.replace(remSec, "");
		}
		
		String htmlSec=U.getSectionValue(html, "<h1 class=\"communityName\">", ">Photo Gallery</h3>");
//		U.log("htmlSec==="+htmlSec);
		html=html.replace("HOA:", "Farms HOA");
		if(htmlSec!=null) {
		htmlSec=htmlSec.replace("HOA:", "Farms HOA").replace("Estates is a gorgeous", "Estate Residences").replace("Spring View Estates ", "Spring View Estates Homes")
				.replaceAll("Kensington Townhomes Community|Gallery Custom Homes|townhomes/\"", "")
				.replace("luxury, custom homes", "luxury homes , custom homes");
		}
		planSec=planSec.replaceAll("Kensington Townhomes Community|Gallery Custom Homes|story 3 bedroom|custom architectural detail throughout|townhomes/\"", "")
				.replace("Custom or Harwood Home you ", "Custom Home you ");
	//U.log("PlanSec2 "+planSec2);
		
		
		String reomveSection=U.getSectionValue(html, "<!-- ========= Site Content ========= -->", "<div class=\"stickyHeaderSpacer\" id=\"stickyHeaderSpacer\" data-new=\"true\"></div>");
		if(reomveSection!=null) {
			html=html.replace(reomveSection, "");
		}
		
		
		String pType = U.getPropType((planSec+html+planSec2)
				
				.replace("communities/Estates-of-Cole-Manor-123675", "").replace("data-link-text=\"\n" + 
				"             Estates of Cole Manor", "").replace("Estates of Cole Manor<span class=\"", "").replaceAll("Townhomes Community|Townhomes-150018|ovilla|-Villages-|villages|Ovilla|Villages|village|Gallery Custom Homes", ""));
//.replace("Estates of Cole Manor", "")
		U.log(">>>>>>>>>>>>"+Util.matchAll((planSec+html+planSec2) , "[\\s\\w\\W]{50}manor[\\s\\w\\W]{30}", 0));

		
		
		U.log("pType====="+pType);

		// ===============================================================================================================================
		html=html.replaceAll("[r|R]anchview|[r|R]anch [r|R]oad|Ranch</a>|[r|R]ancho|footerAnchorBackgroundColor|[B|b]ranch", "").replaceAll("-ranch/\"|-ranch-|LeTara Ranch|creek-ranch|Harmon Ranch|harmon-ranch|rAnchor|[B|b]ranch", "");
		planHtml=planHtml.replaceAll("[r|R]anchview|[r|R]anch [r|R]oad|[r|R]ancho|Ranch</a>|-ranch/\"|-ranch-|LeTara Ranch|creek-ranch|Harmon Ranch|harmon-ranch|rAnchor|[B|b]ranch", "");
		String derivedPType = U.getdCommType((U.getNoHtml(html+planHtml)).replace("Spiritas Ranch", "").replaceAll("(Adkisson|Parker|Bower) Ranch|creek-ranch|Harmon Ranch|harmon-ranch|ranch/\"|Creek Ranch|story 4|content=\".*\"|Floor|floor| Ranch Elementary School", ""));
		
		// =================================================================================================================================
		html=html.replace("Beautiful Inventory Homes Remaining", "Inventory Homes Remaining").replace("Phase II Coming in 2022", "Phase II Coming 2022")
				.replaceAll("Coming \\d+-\\d+ school|<div class=\"item  description marketingDescription\">\n\\s*Final Opportunities|<div class=\"item  description marketingDescription\">\n\\s*Final Opportunities|Limited Number of Water View Lots Available", "Water View Lots Available").replaceAll(">\\s*QUICK MOVE-IN\\s*</a>|<a href=\"/quick-move-in/|Floorplans &amp; Quick Move-Ins", "");
		String htmlSEC=U.getSectionValue(html, "</span></span></h1>", "value=\"SUBMIT\">SUBMIT</button>");
		String statSec=U.getSectionValue(html, "<span id=\"text-marketing-headline\"", "</span>");
		//dd
		
		String statSec2=U.getSectionValue(html, "\"dynamic_page_collection.Desc\">","</span>");
		
		dataa=dataa.replace("coming-soon-banner.png", "coming soon")
				.replace("grand-opening-banner.png", "grand opening")
				.replaceAll("Currently Sold Out\\s*New Phase Coming|Currently Sold Out - \\s*New Phase Coming", "Currently Sold Out, New Phase Coming");
		
		
		String propstatus = U.getPropStatus((dataa + htmlSEC +statSec+statSec2).replace("rep/multi/coming soon\"", "").replace("rmatted\">Coming soon</span></d", "").replace(">New Phase Coming Soon!!!", "New Phase Coming Soon").replaceAll("Water View Lots Available year: Willow|Inventory Homes Coming|inventory homes coming|Water View Lots Available!!!\n\\s*</|Community is Coming Soon|class=\"qmis\">Quick Move-Ins|QUICK MOVE-IN\n*\\s*</a>|href=\"/quick-move|Now Pre-Selling New Phase", ""));
          U.log("propstatus======"+propstatus);
          
			propstatus=propstatus.replaceAll("[q|Q]uick [m|M]ove-[i|I]n,|, [q|Q]uick [m|M]ove-[i|I]n|[q|Q]uick [m|M]ove-[i|I]n", "");
//dt june
//          propstatus=propstatus.replace(", Quick Move-Ins|Quick Move-Ins, |Quick Move-Ins", "");
  		U.log(">>>>>>>>>>>>"+Util.matchAll(dataa + htmlSEC +statSec+statSec2 , "[\\s\\w\\W]{10}Coming Soon[\\s\\w\\W]{10}", 0));

          
//		String qData = U.getSectionValue(html, "<h3 class=\"collapseExpandButton\">Quick Move-Ins</h3>", "<h2>Media Gallery</h2>");
		
//		String qData = U.getSectionValue(html, "<h5 class=\"bannerHeadline\" title=\"MOVE IN READY\">MOVE IN READY</h5>", "<div class=\"modal-content-error container-compare-cards\"");
  		String qData = U.getSectionValue(html, "Homes Available</span>", "Media Gallery</span>");

//		if(qData==null)
//			qData = U.getSectionValue(html, "", "<div class=\"modal-content-error container-compare-cards\"");

//			qData = ALLOW_BLANK;
//		String[] qCount = U.getValues(qData, "<li class=\"hproduct", "</li>");
		String[] qCount = U.getValues(qData, "<div id=\"card_image_container\"", "View Details");
        U.log("st length"+qCount.length);
		int contractOrSold=0; int availabledt=0;
		for(String qString : qCount) {
//			U.log("QQQ"+qString);
			if(qString.contains("under-contract-banner.png") || qString.contains("alt=\"Sold\">"))//||qString.contains("<span class=\"card_available_date\">")
				contractOrSold++;
			if(qString.contains("<span class=\"card_available_date\">Available 06/")||qString.contains("<div><span class=\"card_available_date\">Available Now"))
				availabledt++;
			
			
		}
		
	//	if((html.contains("<h3 class=\"\">Quick Move-Ins</h3>") || html.contains("<h3 class=\"collapseExpandButton\">Quick Move-Ins</h3>"))&&  
			
		U.log("contractOrSold= "+contractOrSold);
		U.log("qCountlE= "+qCount.length);
		U.log("avail="+availabledt);
		if(((qCount.length)>contractOrSold) && (availabledt > 0)) {
//		{// && qCount.length>contractOrSold){
				U.log("pASS");
//			propstatus=propstatus.replaceAll("[q|Q]uick [m|M]ove-[i|I]n,|, [q|Q]uick [m|M]ove-[i|I]n|[q|Q]uick [m|M]ove-[i|I]n", "");
			if(propstatus.length()>3 && propstatus!=ALLOW_BLANK ){
				propstatus=propstatus+", Quick Move-Ins";
			}
			else{
				propstatus="Quick Move-Ins";
			}
		}///date  18 aPRIL 22
		if(commUrl.contains("https://www.firsttexashomes.com/communities/carter-ranch/") || commUrl.contains("/communities/harmon-ranch-at-presidio-west/"))propstatus = propstatus.replace("Final Closeout", "Closeout");
		// ==============================================================================================================================


		if(html.contains("<img class=\"tipComingSoon") && !propstatus.contains("Coming Soon"))
			if(propstatus!=ALLOW_BLANK)
				propstatus+=", Coming Soon";
			else
				propstatus = "Coming Soon";
		
		
		html=html.replace("Phase 2 which we are Now Pre-Selling", "Phase 2 Now Pre-Selling");
		html = html.replace("Phase 2 which we are Now Pre-Selling", "Phase 2 Now Pre-Selling");
//if(propstatus.contains("Quick Move-Ins"))
//{
//	propstatus=propstatus.replace("Quick Move-Ins", "Quick Move-in");
//}
if(commUrl.contains("communities/bear-creek/")||commUrl.contains("communities/mercer-crossing-kensington-townhomes/")|| commUrl.contains("communities/steeplechase/"))propstatus=propstatus.replaceAll(", Quick Move-in,| Quick Move-in,|Quick Move-in", "");
		
if(propstatus.length()<1)
			propstatus=ALLOW_BLANK;


//if(count>0) {
//	if(propstatus.length()>2) {
//		propstatus+=", Quick Move-In Homes";
//	}
//	else
//		propstatus="Quick Move-In Homes";
//}
////bcz sold out is given in image form so can not differntiate between quick move in sold homes
//if(commUrl.contains("https://www.firsttexashomes.com/communities/Parker-Ranch-112519")||commUrl.contains("https://www.firsttexashomes.com/communities/Wellspring-Estates-138353")||commUrl.contains("https://www.firsttexashomes.com/communities/Inspiration-109934"))propstatus="New Phase Coming Soon";
//if(commUrl.contains("https://www.firsttexashomes.com/communities/Woodbridge-Estates-54855"))propstatus="Final Opportunities, Close Out, Quick Move-Ins";
//if(commUrl.contains("https://www.firsttexashomes.com/communities/Parker-Ranch-112519"))
//	propstatus=propstatus.replace(", Currently Sold Out", ", Currently Sold Out New Phase Coming");


		//====================================================================================
		commName = commName.replace(" – ", " - ");
		data.addCommunity(commName, commUrl, commType);
		data.addAddress(add[0], add[1], "TX", add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), flag);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(propstatus.replaceAll("Ii", "II").trim());
		data.addNotes(U.getnote(dataa + html).replaceAll("Ii", "II"));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
        data.addUnitCount(ALLOW_BLANK);
	}
	j++;
//		}catch (Exception e) {}

	}

	public String getDerivedData(String url) throws IOException {
		String dType = ALLOW_BLANK;

		String html = U.getHTML(url);
		html=html.replaceAll("footerAnchorBackgroundColor|[B|b]ranch", "");
		// U.log(html);
		String[] StorySec = U.getValues(html, "<td class=\"td_tabz_2\" style=\"text-align: center; width:55px;\">",
				"</tr>");
		for (String story : StorySec) {

			dType = story.replace("</td>", " Story ") + dType;
			// U.log("story====="+dType);
		}
		ArrayList<String> quickStories = Util.matchAll(html,
				"<td class=\"td_tabz_3\" style=\"text-align:center;\">(.*?)</td>\\s*</tr>", 1);
		String quickStory = ALLOW_BLANK;
		for (String qStor : quickStories) {
			quickStory = qStor + " Story" + " , " + quickStory;
		}
		// U.log("quickStory:::::::::::::::::::"+quickStory);

		return dType + quickStory;

	}

	private static int[] getSqareFeet(String code) throws IOException {
		String htm = code;

		String section = U.getSectionValue(htm, "<div id=\"second\"", "<div id=\"third\"");

		ArrayList<String> sqf = Util.matchAll(htm,
				"style=\"width:55px;\">\\s*(\\d+,\\d+)|<td style=\"text-align:center;\">(\\d+,\\d+)</td>", 1);

		int[] intSqf = new int[sqf.size()];
		for (int i = 0; i < sqf.size(); i++) {
			intSqf[i] = Integer.valueOf(sqf.get(i).replaceAll(",", ""));
		}
		if (intSqf.length != 0) {
			intSqf = U.getMaxAndMin(intSqf);
			return new int[] { intSqf[1], intSqf[0] };
		}
		return new int[] { 0, 0 };

	}

	private static int[] getPrice(String code) throws IOException {
		String htm = code;

		String section = U.getSectionValue(htm, "<div id=\"second\"", "<div id=\"third\"");

		ArrayList<String> price = Util.matchAll(htm, "style=\"width:75px;\">\\s*\\$(\\d+,\\d+)", 1);
		int[] intprice = new int[price.size()];
		for (int i = 0; i < price.size(); i++) {
			intprice[i] = Integer.valueOf(price.get(i).replaceAll(",", ""));
		}
		if (intprice.length != 0) {
			intprice = U.getMaxAndMin(intprice);
			return new int[] { intprice[1], intprice[0] };
		}
		return new int[] { 0, 0 };

	}
	
	
	//###########################################frm mi
	

}