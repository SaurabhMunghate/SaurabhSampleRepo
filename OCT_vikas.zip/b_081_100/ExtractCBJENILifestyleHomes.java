/**
 * @modify Sawan
 * @date 31-10-2017
 */
package com.shatam.b_081_100;
import java.io.*;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCBJENILifestyleHomes extends AbstractScrapper {
	CommunityLogger LOGGER;

	static int j=0;
	WebDriver driver;
	public  final static String HOME_URL = "https://cbjenihomes.com";
	public final static String quickMoveUrl = "https://cbjenihomes.com/find-your-home/new-now/"; // "https://www.cbjenihomes.com/quick-move-ins/";

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractCBJENILifestyleHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Green Brick Partners - CB JENI Lifestyle Homes.csv",
				a.data().printAll());
	}
  
	
	public ExtractCBJENILifestyleHomes() throws Exception {
		super("Green Brick Partners - CB JENI Lifestyle Homes", HOME_URL);
		LOGGER = new CommunityLogger("Green Brick Partners - CB JENI Lifestyle Homes");
	}



	public void innerProcess() throws Exception {

//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
	
		String html = U.getHTML("https://cbjenihomes.com/communities/"); //"/communities/");
		
		String commLinks[] = U.getValues(html, "<div class=\"home-wrap","View Community</a>"); //" <li class=\"hproduct marketPage ",	"<div class=\"view-link \">");

		U.log("comCount:::"+commLinks.length);
		for (String link : commLinks) {
			
			String url = U.getSectionValue(link, "href=\"", "\"");
//			U.log(url);
			commDetails(url,link);
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	//TODO : Execution for single community
	public void commDetails(String commUrl,String comSec)throws Exception {
//		if( j == 17)
//		try{
		{
			U.log(j+"  comUrl===="+commUrl);

//			if(!commUrl.contains("https://cbjenihomes.com/communities/celina-hills/"))return ;
				
				
		if (data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"============ Repeated");
			return;
		}
		
		if (commUrl.contains("https://cbjenihomes.com/communities/iron-horse-commons/")){
			LOGGER.AddCommunityUrl(commUrl+"============ Redirected");
			return;
		}
		
		LOGGER.AddCommunityUrl(commUrl);
		
		String html = U.getPageSource(commUrl);
//		U.log(html);

		//=============------------ Community Name ----------==================
		
		String communityName = U.getSectionValue(comSec, "<h3>", "</h3>");
		if(communityName != null)
			communityName = communityName.trim().replaceAll(" Villas$", "").replaceAll("The Grove Frisco", "The Grove");
		U.log("comName :::"+communityName);

		//-------------- Prices --------------------
		
		html = html.replaceAll("0s", "0,000");
		html = html.replaceAll("0's", "0,000");
//		U.log(Util.match(html, ".*289,000.*"));
		
		String[] prices = U.getPrices((html+comSec).replace("00's", "00,000"),
				"From the low \\$\\d{3},000|mid \\$\\d{3},\\d{3}|<h4>\\s*\\$\\d{3},\\d{3} - \\$(\\d,)?\\d{3},\\d{3}\\s*</h4>|price\">\\s*<div class=\"col-6 \">\\s*(From)?\\s?\\$\\d{3},\\d{3}|<h5>\\$\\d{3},\\d{3}\\s?-\\s?\\$\\d{3},\\d{3}</h5>", 0);
//						"<h5>\\$\\d{3},\\d{3}\\s?-\\s?\\$\\d{3},\\d{3}</h5>|data-price=\"\\d{6,7}\"|h2Styles\">\\s*\\$\\d{3},\\d{3}</div>|Starting at \\$\\d{3},\\d{3}|<br />\\$\\d+,\\d+|From the \\$\\d+,\\d+ to the \\$\\d+,\\d+|From the \\$\\d+,\\d+|From the \\d+,\\d+|upper \\$\\d+,\\d+|From the Low \\$[0-9]{3},[0-9]{3}|Priced at \\$\\d+,\\d+",0);
		U.log(Arrays.toString(prices));
		prices[0] = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		prices[1] = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		

		//----------- SqFt -------------------------

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

		String[] sqft = U.getSqareFeet(html+comSec, 
				"Sq. Ft. <span>\\d,\\d{3} - \\d,\\d{3}|from \\d{4} sqft to over \\d{4} sqft|data-area=\"\\d{3,4}\"|<li class=\"area\">\\d,\\d{3} - \\d,\\d{3} Sq.Ft.</li>|ranging from \\d,\\d{3}-\\d,\\d{3} sq.ft.|<br />\\d+,\\d+ sq.ft.|\\d,\\d{3} Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|Sq. Ft. <span>\\d,\\d{3} - \\d,\\d{3}", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);

		//-------------- address -----------------------
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addSec = U.getSectionValue(comSec, "Directions\" target=\"_blank\">", "<i class=");
		if(addSec != null){
			addSec = addSec.replaceAll("<.*>", "").replaceAll("amp;", "");
			add = U.getAddress(addSec);
		}
/*		String secAdress = U.getSectionValue(html, "data-google-label=\"Community Address\"", "</div>");
		U.log("secAdress: " + secAdress);
		if (secAdress != null) {
			add[0] = U.getSectionValue(secAdress.replaceAll("<span class=\"addressStreet\">By Appointment only </span>|Model Home Coming Soon! ","").replace("<span class=\"addressStreet\">By Appointment Only </span>", ""), "addressStreet\">", "</span>");
			add[1] = U.getSectionValue(secAdress, "addressCity\">", "</span>");
			add[2] = U.getSectionValue(secAdress, "addressState\">", "</span>");
			add[3] = U.getSectionValue(secAdress, "addressZipCode\">", "</span>");
		}
		if(add[1] != null) add[1] = add[1].replace(",", "");
		if(add[0] != null) add[0] = add[0].replace("amp;", "");
		
		
*/		
/*		if(add[0].length()>3)
			add[0] = add[0].replace(communityName, "");
*/		
		U.log("add[0]:::::::::::"+add[0]+"::::");
		U.log(add[1]);
		U.log(add[2]);
		U.log(add[3]);
		//-------------- Lat/Lng ----------------
		String geo = "False";
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
/*		latLng[0] = U.getSectionValue(html, "Latitude:</span>", "</span>");
		latLng[1] = U.getSectionValue(html, "Longitude:</span>", "</span>");
*/		
		
		add[0] = add[0].replace("Coming Soon", "").replace("SOLD OUT", "");
		add[0] = add[0].replace(" Please visit our Frisco Springs sales office", "");

		
		String latLngSec = U.getSectionValue(comSec, "<a class=\"community-directions-link\"", "rel=\"noreferrer noopener\"");//"Current+Location/", "\"");
		if(latLngSec != null) latLngSec = Util.match(latLngSec, "\\d{2}\\.\\d{3,},-\\d{2}\\.\\d{3,}");
		/*if(latLngSec == null){
			latLngSec = U.getSectionValue(html, "Driving Directions</h4>", "title=\"Opens Google Map Directions");
			if(latLngSec == null)
				latLngSec = U.getSectionValue(html, "Driving Directions</h4>", "title=\"Opens Google Map Directions");
			
			if(latLngSec != null) latLngSec = U.getSectionValue(latLngSec, "daddr=", "\" rel=\"noreferrer");
			
			if(latLngSec != null && latLngSec.length() == 1) latLngSec = null; 
		}*/
		U.log("latLngSec ==="+latLngSec);
		if(latLngSec != null) latLng = latLngSec.split(",");
		
		if(latLng[0] != null && latLng[0].isEmpty())latLng[0] = latLng[1] = ALLOW_BLANK;
		if (latLng[0] != null && latLng[1] != null){
			if (add[0] == null&& add[3] != null ) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if(add1 == null) add1 = U.getAddressHereApi(latLng);
				add[0] = add1[0];
				geo = "TRUE";
			}
		}
		if (latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK){
			if (add[0].length() > 4 && add[3].length() > 4) {
				latLng = U.getGoogleLatLngWithKey(add);
				geo = "TRUE";
			}
		}
		
		/*if(add[0].length()<4)
		{
			String add1[] = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			add[0] = add1[0];
			geo = "TRUE";
		}*/

		
		//====== Plan Available Homes==================
		String combinedPlanHtmls = null;
		String planSection = U.getSectionValue(html, "<section id=\"floorplans\"","</section>"); //"View All Floorplans</button>"); //"Plans Available</h3>", "id=\"anchorLinkHomeListTitle\">");
//		U.log(planSection);
		if(planSection != null){
			String[] planUrls = U.getValues(planSection, "mt-auto\" href=\"","\""); //"<a class=\"image-box\" href=\"", "\"");
			U.log("Plan Home Count ::"+planUrls.length);
			for(String planUrl : planUrls){
				String planHtml = U.getPageSource(planUrl);
				U.log("planUrl::"+planUrl);
				combinedPlanHtmls += U.getSectionValue(planHtml, "<header class=\"page-header","</section>");//"<section id=\"homeOverview\"","</section>") //"class=\"homeName\">", "id=\"plansJumpLocation\">");
			}
		}
		
	//	U.log("PPPOP1"+Util.matchAll(combinedPlanHtmls,"[\\w\\W\\s]{40}loft[\\w\\W\\s]{40}",0));
		//======== Homes Available Now Homes ==================
		int homeAvailableCount = 0;
		String combinedHomeAvailables = null;
		String homeAvailableSection = U.getSectionValue(html, "<section id=\"availableProperties\"","</section>"); //"Available Homes</h3>", "id=\"amenitiesJumpLocation\"");
		if(homeAvailableSection != null){
			String homeAvailableUrls[] =  U.getValues(homeAvailableSection, "mt-auto\" href=\"","\""); //"<a class=\"image-box\" href=\"", "\"");
			
			U.log("Home Available Count ::"+homeAvailableUrls.length);
			for(String homeAvailableUrl : homeAvailableUrls){
				String homeAvailableHtml = U.getPageSource(homeAvailableUrl);
				U.log("HomeAvailUrl::"+homeAvailableUrl);
				combinedHomeAvailables += U.getSectionValue(homeAvailableHtml, "<section id=\"homeOverview\"","</section>"); //"class=\"homeName\">", "id=\"plansJumpLocation\">");
//				U.log("Homes data :: "+combinedHomeAvailables);
				homeAvailableCount = homeAvailableUrls.length;
			}
		}
		
		//========== Community Description =================
		String comDesc = U.getSectionValue(html, "<h3 class=\"\">","<ul class=")
				+ U.getSectionValue(html, "Community Details</h4>", "</ul>")+U.getSectionValue(html, "<div class=\"community-description-wrap text-white mt-5\">", "</p>"); // "class=\"communityName", "class=\"communityAddress");
		
		//==========  Property Type ================
		comDesc = comDesc.replace("designed for luxury", "designed for luxury homes");
		
		if(combinedPlanHtmls != null)
			combinedPlanHtmls= combinedPlanHtmls.replace(" &#8211; Craftsman", "Craftsman-style home")
			.replace("&#8211; Colonial", "- Colonial");
	//	U.log(communityName+comDesc);
	//	U.log("PPPOP"+Util.matchAll(combinedPlanHtmls,"[\\w\\W\\s]{40}loft[\\w\\W\\s]{40}",0));
		String propType = U.getPropType((communityName+html+comDesc+combinedPlanHtmls+combinedHomeAvailables)
				.replace("These homes were designed for luxury","Luxury Homes")
				.replace("luxurious inside finishes","Luxury Homes")
				.replaceAll(":\".*\"|=\".*\"|Townhomes in |townhome with Old World stone elevatio|Harvest Townhomes in Argyle|Townhomes for Sale in Dallas|Frisco! Brand new townhome|what sets our luxury DFW townhomes apart today|Townhomes in Frisco|Townhomes for Sale in Dallas|Villas at Southgate|Flower Mound, TX: Villas at Southgate|/villas|villas/|Villages|New Construction Townhomes|Discover what sets our luxury townhomes", ""));
		
//		U.log(Util.matchAll(communityName+" "+html+comDesc+combinedPlanHtmls+combinedHomeAvailables, "[\\s\\w\\W]{30}townhome[\\s\\w\\W]{30}", 0));
		
		//============== Derived Type ====================


		String dType = U.getdCommType((html+combinedPlanHtmls).replaceAll("Heritage Ranch|Ranch</a>|-ranch/|(McKinney|Craig|Storybook) Ranch|mckinney-ranch/|McKinney - McKinney Ranch</a>|footerAnchor|Branch|Ranchview|First Floor", ""));
		
		//-------------- Community Type  ---------------------
		String commType = U.getCommunityType(comDesc+html);

	
		//======= Propert Status ===================
		String headerSec = U.getSectionValue(html, "<div class=\"calloutBody", "</div>");
//		U.log("homeAvailableHtml : "+combinedHomeAvailables);
		String quickDataSec=U.getHtmlSection(html, "<section id=\"availableProperties\"", "</section>");
		String readyNowSec[]=U.getValues(html, "<div class=\"snipe left move-in\">", "</div>");
		String quickData="";
		
		if(quickDataSec!=null && quickDataSec.contains("Quick Move-in Homes")) {
			
			for(String data:readyNowSec) {
				U.log(data);
				quickData+=data;
			}
		}
	
////	
	
		if(!commUrl.contains("https://cbjenihomes.com/communities/heritage-creekside/")) {
			comDesc=comDesc.replace("Quick Move", "");//-In Homes
			comSec=comSec.replace("Quick Move", "");
		}
		if(comDesc != null)
			comDesc = comDesc.replace("Phase IV is now selling", "Phase IV now selling")
			.replaceAll("Hills is now|(Model|Map) Coming", "");
		comSec = comSec.replace("/closeout-red", " close out red").replaceAll("Floorplans Coming", "").replace("snipe right sold-out", "snipe right sold out");
		
		//U.log(Util.matchAll(comDesc+comSec, "[\\w\\s\\W]{30}sold-out[\\w\\s\\W]{30}", 0));
		String pStatus = U.getPropStatus((comDesc+comSec +headerSec).replaceAll("View Quick Move-in Homes|View Quick Move-in Homes", "").replace("for luxury", "luxury homes").replace("hoa", "HOA").replace("Phase II Coming Soon!", "").replace("Villas at Southgate – PH II", "").replaceAll("\">|community is now|\"Grand|Model Home Coming Soon", ""));
//		.replace("ate-phase-2", "")
		
//		if(homeAvailableCount > 0){
//			if(pStatus == ALLOW_BLANK) pStatus = "Quick Move-In Homes";
//			else pStatus = pStatus+ ", Quick Move-In Homes";
//		}

		
		String notes = U.getnote(html);
	//https://www.cbjenihomes.com/communities/majestic-gardens/
		if(propType.contains("Townhouse") && propType.contains("Townhomes")){
			propType = propType.replace("Townhouse", "").trim().replaceAll("^,|,$", "").replace(", ,", ",");
		}
	

		if(commUrl.contains("https://www.cbjenihomes.com/communities/majestic-gardens/"))
			pStatus = pStatus+ ", Now Selling"; //from img	
		
//		if(commUrl.contains("https://www.cbjenihomes.com/communities/meridian-at-southgate/")|| commUrl.contains("/communities/silverado/"))pStatus = "Now Selling"; //from img	
		if(commUrl.contains("https://www.cbjenihomes.com/communities/hometown/"))pStatus = pStatus+ ", Final Opportunities"; //from img
//        if(commUrl.contains("https://cbjenihomes.com/communities/silverado/"))propType="Loft";
        	
		//Remove unwated text..
		
		if(propType.contains("Townhome") && propType.contains("Townhouse"))
			propType = propType.replaceAll("Townhouse,|Townhouse", "");
		
		if(comSec.contains("<img class=\"tipGrandOpening") && !pStatus.contains("Grand")) {
			
			if(pStatus.length()<3) {
				pStatus = "Grand Opening";
			}else {
				pStatus = "Grand Opening, "+pStatus;
			}
		}
		if(comSec.contains("<img class=\"tipComingSoon") && !pStatus.contains("Coming")) {
			if(pStatus.length()<3) {
				pStatus = "Coming Soon";
			}else {
				pStatus = "Coming Soon, "+pStatus;
			}
		}
		
		if(quickData.contains("Ready Now") || quickData.contains("Ready August")) {
			if(pStatus == ALLOW_BLANK) pStatus = "Quick Move-In Homes";
			else pStatus = pStatus+ ", Quick Move-In Homes";
		}
		U.log(pStatus);
////		
//		if(commUrl.contains("https://cbjenihomes.com/communities/riverset/"))pStatus ="Phase II Coming Soon";
//		communityName = communityName.replace(" - PH II", "");
		
		// ------------------------- Number of Units ---------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		String frameData = ALLOW_BLANK; String frameUrl = ALLOW_BLANK;
		int countOfUnits = 0;
		
		//String comData = U.getHtml(commUrl, driver);
		
	
			
			if(html.contains("<iframe id=\"f360_interactivesitemap")) {
				
				String iframeSec = U.getSectionValue(html, "<iframe id=\"f360_interactivesitemap", "</iframe>");
				U.log("iframeSec: "+iframeSec);
				
				frameUrl = U.getSectionValue(iframeSec, "src=\"", "\"");
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl != null) {
					frameData = U.getHtml(frameUrl, driver);
					
					if(frameData != null) {
						
						//brown
						if(frameData.contains("<path fill=\"#9d3222\"")) {
							String[] colorBrown = U.getValues(frameData, "<path fill=\"#9d3222\" stroke=\"none", "\"");
							U.log("colorBrown: "+colorBrown.length);
							
							countOfUnits = countOfUnits + colorBrown.length;
						}
						
						//cream
						if(frameData.contains("<path fill=\"#fcf5f1\"")) {
							String[] colorCream = U.getValues(frameData, "<path fill=\"#fcf5f1\" stroke=\"none", "\"");
							U.log("colorCream: "+colorCream.length);
							
							countOfUnits = countOfUnits + colorCream.length;
						}
						
						//green
						if(frameData.contains("<path fill=\"#7a968d\"")) {
							String[] colorGreen = U.getValues(frameData, "<path fill=\"#7a968d\" stroke=\"none", "\"");
							U.log("colorGreen: "+colorGreen.length);
							
							countOfUnits = countOfUnits + colorGreen.length;
						}
						
						//black
						if(frameData.contains("<path fill=\"#31343b\"")) {
							String[] colorBlack = U.getValues(frameData, "<path fill=\"#31343b\" stroke=\"none", "\"");
							U.log("colorBlack: "+colorBlack.length);
							
							countOfUnits = countOfUnits + colorBlack.length;
						}
						
						//silver
						if(frameData.contains("<path fill=\"#d8d7d5\"")) {
							String[] colorSilver = U.getValues(frameData, "<path fill=\"#d8d7d5\" stroke=\"none", "\"");
							U.log("colorSilver: "+colorSilver.length);
							
							countOfUnits = countOfUnits + colorSilver.length;
						}
					}
				}
			}
			
			units = String.valueOf(countOfUnits);
			U.log("Total Units: "+units);
		
			if(units.equals("0"))  units = ALLOW_BLANK;
			
		data.addCommunity(communityName, commUrl, commType);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus.replace("Ii", "II"));
		data.addNotes(notes);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		}j++;
		
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
}
