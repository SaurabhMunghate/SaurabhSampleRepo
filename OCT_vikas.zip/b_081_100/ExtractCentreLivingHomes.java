/**
 * @author Priti Chaulkar
 * @date Aug 2017
 * 
 */

package com.shatam.b_081_100;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.bcel.generic.AALOAD;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ExtractCentreLivingHomes extends AbstractScrapper {
	static String BASEURL = "https://www.centrelivinghomes.com";
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public static void main(String args[]) throws Exception {
		AbstractScrapper a = new ExtractCentreLivingHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Green Brick Partners - Centre Living Homes.csv", a.data().printAll());
	}

	public ExtractCentreLivingHomes() throws Exception {
		super("Green Brick Partners - Centre Living Homes", "https://www.centrelivinghomes.com/");
		LOGGER = new CommunityLogger("Green Brick Partners - Centre Living Homes");
	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		String html=U.getHTML("https://centrelivinghomes.com/new-homes/");
//		U.log(html);
		String mainSec = U.getSectionValue(html,"<div class=\"result-list row m-0\">","<div class=\"splitter\"></div>");
//		U.log(mainSec+"=====");
		String[] urlSecs = U.getValues(mainSec, "<div class=\"oi-map-item item location-map-item loc-card col-12", "</p>");
		 U.log("URLSEC: "+urlSecs.length);

		for (String urlSec : urlSecs) {
			
			String comurl = U.getSectionValue(urlSec, "href=\"", "\"");
			comurl=BASEURL+comurl;
//			U.log(urlSec);

			U.log(comurl);
			addDetails(comurl,urlSec);
		}
		LOGGER.DisposeLogger();
//		try{driver.quit();}catch(Exception e) {}

	}

	private void addDetails(String url, String comSec) throws Exception {
//		 if(j ==4)
		{
			
			U.log("COMMUNITYURL:---  "+url);
			//TODO:
//			if (!url.contains("erion-at-midtown-park/9354/"))return;

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url+"::::::::::::Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(url);
			

//			U.log("COMMUNITYURL:  "+url);
			String comHtml = U.getHtml(url,driver);
			comHtml=U.getSectionValue(comHtml, "</title>", "Other Communities You May Love");
			
//			String statusName=name;
			String fPlan = U.getSectionValue(comHtml, "<div class=\"col-title\">", "View Floorplans");

			// if(fPlan == null) return;

			// ----CommunityName------------
			String comName=U.getSectionValue(comHtml, "<span class=\"flex-fill\">", "</span>");

			U.log("comName : " + comName);

			String geo = "FALSE";
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latlngSec = ALLOW_BLANK;
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			// U.log(comSec);

			
		
			String addressSection = U.getSectionValue(comSec, "<div class=\"model-address\">", "</span>");
			addressSection=addressSection.replaceAll("<span>|<br>","").replace("\n", ", ").trim();//;
			U.log(">>>>>>>>>>>"+addressSection);
			add=U.findAddress(addressSection);
			if(add==null){
			add=U.getAddress(addressSection);
			}
			
			U.log("ADD>>>>>>>>>>>"+Arrays.toString(add));
//				
			latLng[0] = U.getSectionValue(comSec, "data-latitude=\"", "\"");
			 latLng[1] = U.getSectionValue(comSec, "data-longitude=\"", "\""); 
			  U.log("lat : " +latLng[0] + " lng : " +latLng[1]);
			  String notes=ALLOW_BLANK;
			  
			  if(add[0]==ALLOW_BLANK||add[0]==null) {
				  add=U.getAddressGoogleApi(latLng);
				  geo="True";
			  }
			  if(url.contains("https://www.centrelivinghomes.com/new-homes/tx/waxahachie/dove-hollow/10116/")||url.contains("https://www.centrelivinghomes.com/new-homes/tx/waxahachie/ellis-ranch-estates/10179/")) {
					add[1]="Waxahachie";
					add[2]="TX";
					add[0]=U.getAddressGoogleApi(latLng)[0];
					add[3]=U.getAddressGoogleApi(latLng)[3];
					geo="True";
					notes="Address is taken from City,State";
				}
			  if(url.contains("/newman-village/10180/")) {
				  add[1]="Frisco";
				  add[2]="TX";
				  latLng=U.getlatlongGoogleApi(add);
				  add=U.getAddressGoogleApi(latLng);
//				  add[0]=U.getAddressGoogleApi(latLng)[0];
//				  add[3]=U.getAddressGoogleApi(latLng)[3];
				  geo="True";
				  notes="Address is taken from City,State";
				  
				  U.log("ADD2>>>>>>>>>>>"+Arrays.toString(add));
				 }
				
			String drop = U.getSectionValue(comHtml,
					"<div id=\"folderNav\" data-content-field=\"navigation-folderNav\">", "</nav>");
			// U.log(drop);
			if (drop != null)
				comHtml = comHtml.replace(drop, "");

			String remMeta = U.getSectionValue(comHtml, "charset=utf-8>", "</head>");
			if (remMeta != null)
				comHtml = comHtml.replace(remMeta, "");
			comHtml = comHtml.replace("src=\"https://static.centrelivinghomes.com/centrelivinghomes/images/icon-stories.svg?v=1650f8a\" ", "")
					.replace("<img alt=\"Stories\" /><span>", "Stories ")
					.replace("1-2 story homes ", "1 story 2 story homes ").replace("Master on 1st floor", "Master on 1 Story").replace("2 and 3 stories",
					" 3 Story  2 Story ");

			// Community type, property type derived property type and status
			String cType = ALLOW_BLANK;
			String pType = ALLOW_BLANK;
			String dType = ALLOW_BLANK;
			String status = ALLOW_BLANK;
			comHtml = comHtml
					.replace("ample flex and office space", "ample flex space and office space")
					.replaceAll("mejs.chinese-traditional\":\"Chinese \\(Traditional\\)|Patio.jpg|Stevens Park Townhomes</a>|-townhomes/", "").replace("WINNETKA ESTATES and BUNGALOWS.", "WINNETKA Estate Residences and Bungalow Series");
			cType = U.getCommunityType(comHtml);
			comSec = comSec.replace("Luxury duplex", "luxury homes duplex");
//			U.log(comSec);
			comHtml = comHtml.replace("The Commons at Spring Creek Townhouses in Richardson|Midtown Park Townhouses in Dallas, Texas.", "").replace("Winnetka Bungalows", "Winnetka Bungalow Home").replace("Winnetka Estate ", "Winnetka Estate Homes");
			pType = U.getPropType(comSec+comHtml.replaceAll("Merion at Midtown Park Single Family Homes and Townhouses in Dallas, Texas</a>|The Commons at Spring Creek Townhouses|Stephens Park Townhome|Park Townhomes- Ft ", ""));
//			U.log("MMMMMMMMM"+Util.match(comSec+comHtml, "[\\s\\w\\W]{50}Townhouse[\\s\\w\\W]{50}", 0));

			//from img - 18 Jan
			if (url.contains("https://centrelivinghomes.com/communities/buffalo-ridge/")) pType = pType + ", Patio Homes";
			U.log("pType: "+pType);
			
			comHtml = comHtml.replace("1-2 story homes ", " Story 1 Story 2")
					.replace("2 and 3-story townhomes", "2 story, and 3-story townhomes").replace(" 2-3 Stories ", " 2 story-3 Stories ").replaceAll("2-story Single Family|second floor porch overlooking", " 2 Story ")
					.replaceAll(" (\\d)-(\\d) Stories", " $1 Story - $2 Story")
					.replace("second story porch", "");
				
			if(url.contains("https://www.centrelivinghomes.com/new-homes/tx/waxahachie/ellis-ranch-estates/10179/"))
				 dType = U.getdCommType(comHtml);
			else
		         dType = U.getdCommType((comHtml).replaceAll("Ellis Ranch Estates New Homes|ellis-ranch-estates|Ellis Ranch Estates in Waxahachie",""));
			U.log("dType: "+dType);

			
			comHtml = comHtml.replace("Phase 1- Almost Sold Out", "Phase 1 Almost Sold Out").replaceAll("Colvin Court- SOLD OUT|ground up lots", "")
					.replace("Phase I available for Spring 2020", "Phase I available Spring 2020").replace("1  HOME REMAINING", "1 HOME REMAINING")
					.replaceAll("Phase (\\d)- ", "Phase $1 ");
			
			String com_desc=U.getSectionValue(comHtml, "<div class=\"overlay\">", "<h3>INTERACTIVE SITEPLAN</h3>");
			U.log("com_desc==="+com_desc);
			
			if(com_desc!=null)
		      status = U.getPropStatus((com_desc).replaceAll("\\d+ Available Homes|2 Available Homes", "").replaceAll("<h3>COMING SOON</h3>", "").replace("Merion at midtown park model hours Model home coming soon", ""));
			else
				 status = U.getPropStatus(comSec);
			if (url.contains("https://centrelivinghomes.com/communities/midtown-at-merion/"))
				status = ALLOW_BLANK;

			U.log("STATUS:-------- " + status);

			String removeHomeSec = U.getSectionValue(comHtml, " <div id=\"image-map-", "div class=\"wrapper fitb-video\"");
//			U.log(removeHomeSec);
			String footerSec = U.getSectionValue(comHtml," <div class=\"footer wrapper\">", "</body>");
			if(removeHomeSec!=null) {
			ArrayList<String> rmSec = Util.matchAll(removeHomeSec, " <div id=\"(.*)\" class", 1);
			for(String sec:rmSec) {
				String newsec=sec.replace("-plot", "");
				int count = Util.matchAll(footerSec,newsec , 0).size();
				if(count<1) {
				 String rmstr = U.getSectionValue(comHtml, "<div id=\""+sec, "<div class=\"btm-bttns\">");
				 comHtml=comHtml.replace(rmstr, "");
				}
			}
			}
			// Price
			comHtml = comHtml.replace("$1.1 - $1.5M", "$1,100,000 - $1,500,000").replace("$1.3- $1.5M",
					"$1,300,000- $1,500,000").replaceAll("<h3>Ross Heights</h3>\\s*<span>\\$569,900</span>", "");
			comHtml = comHtml.replaceAll("0's|0’s", "0,000").replace("$469k", "$469,000").replace("99k", "99,000").replace("$655,00!", "$655,000!")
					.replace("private yards from $409k", "private yards from $409,000").replaceAll("From \\$(\\d{3})k", "From \\$$1,000")
					.replace("From&nbsp; $450k</span>", "From $450,000</span>").replace("$399k", "$399,000").replace("Starting at $499K ", "$499,000")
					.replaceAll("townhomes priced from the high \\$\\d{3}’s.", "")
					.replace("from $399k", "from $399,000").replace("from $485k", "from $485,000");
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			String[] price = U.getPrices(comHtml + fPlan+comSec,
					"PRICED AT</div><div class=\"model-price bold\">\\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|private yards from \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}\\s*-\\s*\\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
			

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			

			// Square feet
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			comHtml = comHtml.replace("1,610 – 1,789 Square Feet", "1,610 - 1,789 Square Feet");
			String[] sqft=U.getSqareFeet(comHtml, "<span>\\d,\\d{3}-\\d,\\d{3}</span>", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft :" + minSqft + " maxSqft:" + maxSqft);

			notes = U.getnote(comHtml);

				U.log(notes);
			comName = comName.replace("@ ", "At ");
			
			if(url.contains("https://www.centrelivinghomes.com/new-homes/tx/richardson/the-commons-at-spring-creek/9356/"))pType="Townhome";
			if(url.contains("https://www.centrelivinghomes.com/new-homes/tx/dallas/merion-at-midtown-park/9354/"))pType=pType.replace(", Townhome", "");

			//==============siotemap====
			String noOfUnits=ALLOW_BLANK;
			int lotCount=0;
			if(comHtml.contains("<h3>INTERACTIVE SITEPLAN</h3>")) {
			String []lotData=U.getValues(comHtml, "<div class=\"oi-isp-point oi-isp-point-type-", "</div>");
			lotCount=lotData.length;
			noOfUnits=Integer.toString(lotCount);
			}
			if(noOfUnits.equals("0"))
				noOfUnits=ALLOW_BLANK;
			U.log("NO OF UNITS:: "+noOfUnits);
			
			
			data.addCommunity(comName.replace("COMING SOON - ", ""), url, cType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addNotes(notes);
			data.addUnitCount(noOfUnits);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			

		}
		
		j++;
	}
	
	public static String[] getlatlongGoogleApi(String add[]) throws IOException {
		String addr = add[0] + "," + add[1];
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address=" + URLEncoder.encode(addr, "UTF-8");
		U.log(addr);
		U.log(U.getCache(addr));
		String html = U.getHTML(addr);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		U.log("GMAP Address Status Without Key : " + status);
		if (!status.contains("OVER_QUERY_LIMIT") && !status.contains("REQUEST_DENIED")) {
			String sec = U.getSectionValue(html, "location", "status");
			if (sec != null) {
				String lat = U.getSectionValue(sec, "\"lat\" :", ",");
				if (lat != null) {
					lat = lat.trim();
					String lng = U.getSectionValue(sec, "\"lng\" :", "}");
					if (lng != null)
						lng = lng.trim();
					String latlng[] = { lat, lng };
					// U.log(lat);
					return latlng;
				}
			}
		}

		else {
			return getGoogleLatLngWithKey(add);
		}
		return null;
	}

	public static String[] getGoogleLatLngWithKey(String add[]) throws IOException {
		String addr = add[0] + "," + add[1];
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address=" + URLEncoder.encode(addr, "UTF-8")
				+ "&key=AIzaSyAeG9lLU8fWh8rWcPivHDwxLAM4ZCInpmk";
		U.log(addr);
		U.log(U.getCache(addr));
		String html = U.getHTML(addr);

		String sec = U.getSectionValue(html, "location", "status");

		String lat = U.getSectionValue(sec, "\"lat\" :", ",");
		if (lat != null)
			lat = lat.trim();
		String lng = U.getSectionValue(sec, "\"lng\" :", "}");
		if (lng != null)
			lng = lng.trim();
		String latlng[] = { "", "" };
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		if (status.trim().equals("OK")) {
			latlng[0] = lat;
			latlng[1] = lng;
			return latlng;
		} else
			return latlng;
	}

	public static String getHTMLwithProxy(String path)
			throws IOException, NoSuchAlgorithmException, KeyManagementException {


		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);

		// U.log("filename:::" + fileName);

		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(new KeyManager[0], new TrustManager[] { new DefaultTrustManager() }, new SecureRandom());
		SSLContext.setDefault(ctx);

		// chk responce code

		// int respCode = CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);

		{

			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("65.152.119.226	",46620));

			final URLConnection urlConnection = url.openConnection();

			// Mimic browser
			try {
				urlConnection.addRequestProperty("User-Agent",
						"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
				urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
				urlConnection.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
				urlConnection.addRequestProperty("Cache-Control", "max-age=0");
				urlConnection.addRequestProperty("Connection", "keep-alive");
				// U.log("getlink");
				final InputStream inputStream = urlConnection.getInputStream();

				html = IOUtils.toString(inputStream);
				// final String html = toString(inputStream);
				inputStream.close();

				if (!cacheFile.exists())
					FileUtil.writeAllText(fileName, html);

				return html;
			} catch (Exception e) {
				U.log(e);

			}
			return html;
		}

	}

}

class DefaultTrustManager implements X509TrustManager {
	@Override
	public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		// TODO Auto-generated method stub
	}

	@Override
	public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		// TODO Auto-generated method stub
	}

	@Override
	public X509Certificate[] getAcceptedIssuers() {
		// TODO Auto-generated method stub
		return null;
	}

}