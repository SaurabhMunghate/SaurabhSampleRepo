/** @author Parag Humane
 *  @date 19/04/2013 
 */
package com.shatam.b_081_100;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.AddSelection;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractHHHunt_Homes extends AbstractScrapper {
	int k = 0;
	public int inr = 0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static int j = 0;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractHHHunt_Homes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "HHHunt Corporation - HHHunt Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public ExtractHHHunt_Homes() throws Exception {

		super("HHHunt Corporation - HHHunt Homes", "https://www.hhhunthomes.com/");
		LOGGER = new CommunityLogger("HHHunt Corporation - HHHunt Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String htm = getHtml("https://www.hhhunthomes.com/", driver); // using driver for fetching the communities under
																	// "show more" button
		U.log(U.getCache("https://www.hhhunthomes.com/"));
		String htmlSec = U.getSectionValue(htm, "<li class=\"find-your-home-navigation__other","</div>"); //"<div class=\"find-your-home-navigation__component--left\">", "</div>");
		String[] nextSec = U.getValues(htmlSec, "href=\"", "\"");
		U.log(nextSec.length);
		for (String comSec : nextSec) {
			String regUrl = "https://www.hhhunthomes.com" + comSec;
			U.log(regUrl);
			String regHtml = U.getHTML(regUrl);
//			String[] comUrlSec = U.getValues(regHtml, "<div class=\"community-list-card\">", "Visit Community");
//			String[] comUrlSec = U.getValues(regHtml, "<a class=\"community-list-card\"", "Visit <span class=\"mobile-hidden\">Community");
			String[] comUrlSec = U.getValues(regHtml, "<article class=\"community-list-card", "</article>");
			U.log(comUrlSec.length);
			for (String string : comUrlSec) {
				String comUrl = "https://www.hhhunthomes.com"+ U.getSectionValue(string, " href=\"", "\""); // + U.getSectionValue(string, "<a href=\"", "\">");
//				U.log(comUrl);
				addDetails(comUrl, string);
			}

		}

		LOGGER.DisposeLogger();
	///	driver.close();
//		driver.quit();
	}

	//TODO : Extract communities details here
	private void addDetails(String cUrl, String info) throws Exception {
//		if (j >= 15)
		{
//			if (!cUrl.contains("https://www.hhhunthomes.com/property-search-results/richmond-va/river-mill"))return;
//	 U.log(info);
			
//			if(cUrl.contains("https://www.hhhunthomes.com/property-search-results/richmond-va/magnolia-green")) {
//				
//				LOGGER.AddCommunityUrl("404 Return -=============== "+ cUrl);
//				return;
//			}
			if(data.communityUrlExists(cUrl)) {
				
				LOGGER.AddCommunityUrl("Repeated -=============== "+ cUrl);
				return;
			}
			if(cUrl.contains("https://www.hhhunthomes.com/property-search-results/raleigh-nc/granite-falls-estates")) {
				LOGGER.AddCommunityUrl("ReDirect to Region page ===============");
				return;
			}
			LOGGER.AddCommunityUrl(cUrl);
			
			
			U.log(j + "======>" + cUrl);
			
			String html = getHtml(cUrl, driver);
			String statusHtml=U.getSectionValue(html, "<section class=\"description\">", "</section>");
			if(statusHtml==null){
				statusHtml=ALLOW_BLANK;
			}
			// =================================================Community
			// ?Name=============================
			//String commName = U.getSectionValue(html, "microsite-hero-slideshow-banner__title\">", "</h1>");
			String commName = U.getSectionValue(html, "microsite-hero-slideshow-banner__title\" ", "</h1>");
			if(commName == null)
				commName = U.getSectionValue(html, "microsite-hero-slideshow-banner__title\">", "</h1>");
			U.log(commName);
			if(commName != null)
				commName = commName.replace("&#039;", "'").replaceAll("data-ce-key=\"\\d+\">|<p data-ce-key=\"\\d+\">", "").trim();
			if (commName.endsWith("Cottage"))
				commName = commName.replace("Cottage", "");
			if (commName.endsWith("Townhomes"))
				commName = commName.replace("- Townhomes", "").replace("Townhomes", "");
			if (commName.endsWith("Villas"))
				commName = commName.replace("Villas", "");
			U.log("commName===="+commName);

			// ============================================Address===========================================
			
//			U.log("info===="+info);
			U.log("direction url ::"+cUrl + "/contact-and-directions");
			String directionHtml = getHtml(cUrl + "/contact-and-directions", driver);
			
		
			
			String geo = "FALSE";
			String note = "";
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
//			if(cUrl.contains("https://www.hhhunthomes.com/property-search-results/new-kent-va/maidstone-village")) {
//				add[1]="New Kent";
//				add[2]="VA";
//				latLng=U.getGoogleLatLngWithKey(add);
//				U.log("add:==="+Arrays.toString(add));
//				add=U.getAddressGoogleApi(latLng);
//				U.log("add:==="+Arrays.toString(add));
//			}

			String addrSec = "";
			note = U.getnote(html);
			
			if (html.contains("/contact-and-directions")) {

				if (html.contains("contact-and-directions\">Contact"))
					addrSec = Util.match(directionHtml,
							"class=\"text-link\">\\s*(.*?)\\s*</a></p></div>\\s*<div class=\"address-hours", 1);

				U.log("addrSec : " + addrSec);
				if (addrSec != null) {

					addrSec = addrSec.replaceAll("\\s+", " ");
				}
				if (addrSec == null || addrSec.length() < 5) {
					addrSec = Util.match(directionHtml,
							"class=\"address-hours__item\">\\s*(.*?)class=\"text-link\">\\s*(.*?)\\s*<br>", 2);
				}
				if (addrSec != null && addrSec.contains("By Appointment Only")) {
					addrSec = U.getSectionValue(directionHtml, "class=\"directions\"><p>Address:", "</p>");
					if (addrSec != null)
						addrSec = addrSec.replaceAll("&nbsp;", " ").replaceAll("<.*?>", "");
				}

				U.log("addrSec : " + addrSec);
				if (addrSec != null) {
					addrSec = addrSec.replace("(our Ridgefield Green community)", "");
					add = U.getAddress(addrSec);
				}
				if (cUrl.contains("/hampton-roads-va/cypress-creek")) {
					addrSec = U.getSectionValue(directionHtml, "<p>Address: For GPS use, ", "</p>");
					if (addrSec != null)
						addrSec = addrSec.replace("Smithfield VA", "Smithfield, VA");
					U.log("addrseddddd::::" + addrSec);
					add = U.findAddress(addrSec);
				}

				if (addrSec == null || add[0].length() < 3) {
					U.log("ENTER");

					String addsec = U.getSectionValue(directionHtml, "<div class=\"address-hours__item\">", "</div>");

					if (addsec.contains("href=\"https://maps.google"))
						addrSec = U.getSectionValue(addsec, "\">", "<br />");
					if (addrSec != null)
						add = U.getAddress(addrSec);

				}

				U.log(add[0] + " == " + add[1] + " == " + add[2] + " == " + add[3]);
				
				String latlngSec = U.getSectionValue(directionHtml, "400&amp;zoom=10&amp;center=", "&amp;markers");
//				U.log("latLongSec: "+latlngSec);
				
				if(latlngSec==null) {
					latlngSec = U.getSectionValue(directionHtml, "<a href=\"https://maps.google.com/?q=","\"");
					U.log("latlng==");
				}
				if(latlngSec==null){
					U.log("1latlng==");
					latlngSec = U.getSectionValue(directionHtml, "class=\"text-link\" href=\"https://maps.google.com/?q=","\"");
				}
				
				if (latlngSec != null) {
					latLng = latlngSec.split(",");
				}
//==
				if(latLng[0]==ALLOW_BLANK && add[0]!=ALLOW_BLANK) {
					latLng=U.getlatlongGoogleApi(add);
				}
//==
			}
			else if(directionHtml!=null) {
				String addSec=U.getSectionValue(directionHtml, "<h4 class=\"address-hours__header\">", "</p>");
				if(addSec!=null) {
					String latlngSec=U.getSectionValue(addSec, "href=\"https://maps.google.com/?q=", "\"");
					if(latlngSec!=null) {
						latLng=latlngSec.split(",");
					}
					U.log("addSec==&&&&===="+addSec);
					addSec=U.getNoHtml(U.getSectionValue(addSec, "<div class=\"address-hours__item\">", "</a>").trim());
					if(addSec!=null) {
						add=U.getAddress(addSec);
					}
				}
			}
			else {
				
				String cityState = U.getSectionValue(info, "|</span>", "</div>").trim();
				String get[] = cityState.split(",");

				
				add[0]=ALLOW_BLANK;
				add[1]=get[0];
//				U.log("==============="+add[1]);
				add[2]=get[1];
//				U.log("==============="+add[2]);
				add[3]=ALLOW_BLANK;
				
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "true";
				note="Address taken from city and state";	
				
				
			}
//			U.log("nt:::::"+note);
			
			
//			
//			if(cUrl.equals("https://www.hhhunthomes.com/property-search-results/richmond-va/river-mill")) {
//				add[0]=ALLOW_BLANK;
//				add[1]="Glen Allen";
////				U.log("==============="+add[1]);
//				add[2]="VA";
////				U.log("==============="+add[2]);
//				add[3]=ALLOW_BLANK;
//				
//				latLng=U.getlatlongGoogleApi(add);
//				if(latLng == null) latLng = U.getlatlongHereApi(add);
//				add=U.getAddressGoogleApi(latLng);
//				if(add == null) add = U.getAddressHereApi(latLng);
//				geo = "true";
//				note="Address taken from city and state";
//			}
			
			
			U.log("LatLng : " + Arrays.toString(latLng));
			if (add[1].length() > 3 && latLng[0].length() < 4) {
//				 latLng=U.getlatlongGoogleApi(add);
				latLng = U.getBingLatLong(add);
				geo = "true";

			}
			
			
/*			if(cUrl.contains("/richmond-va/taylor-farm")) {
				add[0]=ALLOW_BLANK;
				add[1]="Mechanicsville";
				add[2]="VA";
				add[3]=ALLOW_BLANK;
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "true";
			}*/

			if (add[0].length() < 4 && latLng[0].length() > 4) {
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "true";
			}
			
			// ==========================================Price-Squre
			// Feet======================================
			String floorHtml = getHtml(cUrl + "/floorplans", driver);
			if(!html.contains("Floor Plans</a>"))
				floorHtml = "";
			
			String quickHtml = getHtml(cUrl + "/move-in-ready-homes", driver);
			if(!html.contains("move-in-ready-homes\">Move-in"))
			quickHtml = "";
			
			// ------HomesData------
						String allFloorData = ALLOW_BLANK;
						ArrayList<String> flrUrls = Util.matchAll(floorHtml,
								"<div class=\"card-floorplan__body\">\\s*<a href=\"(.*?)\"></a>", 1);
						U.log("Total Floor : " + flrUrls.size());
						for (String flrUrl : flrUrls) {
							U.log(flrUrl);
							String fHtml = U.getHTML("https://www.hhhunthomes.com" + flrUrl);
							allFloorData += U.getSectionValue(fHtml, "<ul class=\"tabs__title\">", "</main>");
						}
						
			allFloorData=allFloorData.replaceAll("Price:</span></td>\\s*<td>", "low ");
//			U.log(Util.matchAll(allFloorData, "low\\s*\\$",0));
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			 //U.log(info);
			info = info.replaceAll("0’s|0's|0s|0&rsquo;s", "0,000");
			html = html.replaceAll("0’s|0's|0s", "0,000");
			floorHtml = floorHtml.replaceAll("0’s|0's|0s", "0,000");
			quickHtml = quickHtml.replaceAll("0’s|0's|0s", "0,000");
//			U.log(Util.matchAll(floorHtml, "\\w*\\s*\\W*\\$200,000", 0));
			String[] price = U.getPrices(html + floorHtml + quickHtml + info+allFloorData,
					"upper \\$\\d{3},\\d+|price\">\\$\\d{3},\\d+|mid \\$\\d{3},\\d+|low\\s*\\$\\d{3},\\d{3}", 0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// =============== Square Feet ===============
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html + info + floorHtml + quickHtml,
					"\\d,\\d{3} - \\d,\\d{3}</li>|>\\d,\\d{3}</li>|>\\d,\\d{3}</span>|<span>\\d,\\d{3}</span>", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log(minSqf + "    " + maxSqf);
//U.log("MMMMMMMMMM "+Util.matchAll(html + info, "[\\s\\w\\W]{30}master[\\s\\w\\W]{30}", 0));
			

			// =======================================Community
			// type=====================================================
			html=html.replace("popular Magnolia Green community", "").replace("master-planned-communities.html", "");
			String cType = U.getCommunityType(html + info);

			// ===================================================property
			// type=============================================
			// U.log(allFloorData);
			allFloorData = allFloorData.replaceAll("First Floor", " 1 Story ");
			allFloorData = allFloorData.replaceAll("Second Floor", " 2 Story ");
			allFloorData = allFloorData.replaceAll("Third Floor", " 3 Story ");
			info=info.replace("Luxury Low-Maintenance", "luxury homes").replace("Luxury 3-Story", "Luxury homes 3-Story");
			html = html.replace("Homesite Limited Release", "Limited Homesite Release").replaceAll("apartmentliving_|com/apartment|Apartment Living</div>", "").replaceAll("luxury of your spacious home|Luxurious Designer Touches", "luxury homes");
			String PType = U.getPropType(html + info);
//			U.log(Util.matchAll("MMMMMMMMMMMMmm "+( html + info), "[\\w\\s\\W]{30}two-story[\\w\\s\\W]{30}", 0));

			String dType = U.getdCommType((html.replace("two-story garage townhomes offer", "").replace("one or two-story options.", "1 Story or two-story options.") + info + floorHtml + quickHtml + allFloorData).replaceAll("Colonial Williamsburg|floor|Floor", ""));

			// ==================================================Status===============================================
			String remVals[] = U.getValues(html, "{\"@context\":", "</script>");
			for(String rem : remVals) html = html.replace(rem, "");
			 

			html = html.replace("miss out on the final opportunities to own an HHHunt Home in Willoughby", "final opportunities to own an HHHunt Home in Willoughby")
					.replaceAll("available in Giles � now selling at|New construction townhomes coming soon|New Homes Coming Soon |NOW OPEN - Brand New 8 lighted tennis|Willoughby - Only 2 Homes Remain|NOW OPEN - 8 lighted|Quick Move-Ins!</a>|now selling luxury townhomes |miss out on the final opportunities|Townhomes SELLING QUICKLY|\\s*NOW SELLING - 3 Story|NOW SELLING New Garage|Single-Family Homes NOW SELLING|New Townhomes COMING SOON|HHHunt Homes closeout community|Coming Spring 2019 - 8 lighted|Dog park now open|<span>Single-Family Homes</span>\\|<span>Coming Soon</span>|NOW OPEN - brand|grand opening to the public|Garage Townhomes Coming Spring 2018|COMING SOON:|Clubhouse coming soon!|new homesites available lining","")
					.replace("Now Selling in our NEW section", "Now Selling NEW section")
					.replace("New Section in Timberstone Now Selling", "New Section Now Selling")
					.replaceAll("soon\\. Contact", "");
			
			// from image
			info = info.replace("soldout-flag", "sold out-flag").replaceAll("Final Opportunity now available in the Villas", "")
					.replace("New Section, NOW SELLING", "New Section NOW SELLING");
			info = info.replace("comingsoon-flag", "coming soon-flag").replaceAll("NOW SELLING - 3 Story Garage ", "");;
			info = info.replace("grandopening-flag", "grand opening-flag").replace("New Section, NOW SELLING", "New Section NOW SELLING")
					.replace("Limited number of homesites remain", "Limited homesites remain")
					.replace("Home are selling quickly", "Homes selling quickly")
					.replace("Garage Townhomes are Selling", "")
					.replace("Townhomes are Selling Quickly in the New Section", "Townhomes Selling Quickly in New Section")
				     .replace("Townhomes SELLING QUICKLY", "  SELLING QUICKLY")
				     .replace("community clubhouse (NOW OPEN)", "");

			String htmlSec=U.getSectionValue(html, "<h1 class=\"microsite-hero-slideshow-banner", "<footer>");
//			U.log(Util.matchAll("MMMMMMMMMMMMmm "+(htmlSec), "[\\w\\s\\W]{30}New Section, Now Selling![\\w\\s\\W]{30}", 0));

//
			htmlSec=htmlSec.replace("community clubhouse (NOW OPEN)", "");
			String status = U.getPropStatus((statusHtml+info.replaceAll("New Homesites Coming Soon - Join", "")
					.replace("New Garage Townhomes NOW SELLING in New Kent", "New Townhomes Now Selling In New Kent") + htmlSec ).replaceAll("now selling in a new section", "new section now selling").replace("New Section, Now Selling", "new section now selling")
					.replaceAll("New amenities in Quarterpath are coming in 2022|Coming Summer 2022 - Resort-style pool|Hammock Creek, that are now open to VIPs|community clubhouse (NOW OPEN)|New Homes Now Selling in Hanover|Join our VIP list for our Limited Homesite Release|model home in Glen Abbey at Magnolia Green is now available for sale.|New section coming soon in Goochland VA|Thoughtfully Designed Homes NOW SELLING in FoxCreek|content=\".*\"|content=\"Sold out.\"|Move-In Ready Homes|New Homes coming soon in|New Homes sold out in|Coming soon. Join the VIP list!\"|New homes coming soon in| Coming soon.\"|Townhomes Are Selling Quickly!| NOW SELLING in New Kent|Now selling!\">|<div class=\"price\">\\s*Coming Soon|New Townhomes Coming Soon to|available in Giles – now selling |Single Family Homes Coming Soon|coming soon-flag|single-family homes coming soon|Chester, VA\\. now selling|Landing NOW SELLING|Community with only a few opportunities|(m|M)ove-(i|I)n", ""));
			
//			U.log(Util.matchAll("MMMMMMMMMMMMmm "+( info+ htmlSec), "[\\w\\s\\W]{30}coming[\\w\\s\\W]{30}", 0));

			
			
			U.log("STATUS===="+status);
			
			
			
			if(cUrl.contains("https://www.hhhunthomes.com/property-search-results/new-kent-va/maidstone-village")) {
				status=status.replace("New Homes Coming Soon, ", "");
			}
			if(cUrl.contains("property-search-results/williamsburg-va/mason-park")) {
				status=status.replace("Only 1 Opportunity Remaining, ", "Only 2 Opportunity Remaining, ");
			}
			if (info.contains("/new-phase-flag.svg")) {
				if (status.length() > 2) {
						status = status + ", New Phase";
				} else {
					status = "New Phase";
				}
			}
			
			
			
			if(quickHtml!=null) {
			///quickHtml = getHtml(cUrl + "/move-in-ready-homes", driver);
				String homeslen[]=U.getValues(quickHtml, "<div class=\"qmi-card__listing\">", " <address class=\"qmi-card__address\">");
				int soldlen=Util.matchAll(quickHtml, "<span class=\"qmi-card__status sold\">",0).size();
				U.log(homeslen.length+"::::::::"+soldlen);
				status=status.replaceAll(", Quick Move-ins|Quick Move-ins,|Quick Move-ins|, Quick Move-in|Quick Move-in,|Quick Move-in", "");
				
				
//				if ((html.contains("move-in-ready-homes\">Move-in") && soldlen!=homeslen.length) || quickHtml.contains("<span class=\"qmi-card__status available_now\">")) {
//					
//					if (status.length() > 2) {
//						if (!status.contains("Move-in")) {
//							status = status + ", Move-in Ready Homes";
//						}
//					} else {
//						status = "Move-in Ready Homes";
//					}
//				}
			}
//			if(cUrl.contains("results/richmond-va/governors-retreat")) {
//				status=status+", Coming Soon";
//			}
			
			if(info.contains("community/coming soon-flag.svg"))
//				U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+status.length());
			{
				if(status.length()>5) {
					status=status+", Coming Soon";
				}
				else
					status="Coming Soon";
			}
//			U.log("============="+info);
//			if (info.contains("/community/coming soon-flag.svg\"") && !status.contains("Coming Soon")) {
//				if (status!=ALLOW_BLANK) {
//						status = status + ", Coming Soon";
//				} else {
//					status = "Coming Soon";
//				}
//			}
			if(status.equals("Coming Soon, Coming Soon"))status="Coming Soon";

			if(cUrl.contains("/richmond-va/ridgefield-green"))status=status.replaceAll("Just Released", "Final Building Just Released");
			if(cUrl.contains("/williamsburg-va/landfall-at-jamestown"))status=status+", Wooded Homesites";
			if(cUrl.contains("/property-search-results/richmond-va/bexley-meadows"))status=status.replaceAll(", Closeout,", ", Community Closeout,");
//			if(cUrl.contains("/hampton-roads-va/meadows-landing"))status=status+", New Homesites Coming Soon";
			if(cUrl.contains("/hampton-roads-va/oyster-point"))status = status+", Coming Soon"; //direction page is missing
			// ================================================note==================================================
			if(cUrl.contains("https://www.hhhunthomes.com/property-search-results/richmond-va/wescott")) {
				status=status.replace("Homes Are Selling Quickly, ", "");
				}
			if(cUrl.contains("https://www.hhhunthomes.com/property-search-results/richmond-va/governors-retreat")) {
				status=status.replace("New Homes Coming Soon, ","");
			}	
			if(cUrl.contains("/richmond-va/watermark")||cUrl.contains("/richmond-va/watermark-townhomes")) {
				cType=cType+", Lakeside Community";
			}
			if(status.length()<4) {
				status=ALLOW_BLANK;
			}
			
//			if(status.equals("Coming Soon, Coming Soon"))
//			{
//				status=status.replace("Coming Soon, Coming Soon", "Coming Soon");
//			}
//			if(status.contains("New Homesites Coming Soon, Coming Soon"))
//			{
				status=status.replace("New Homesites Coming Soon, Coming Soon", "New Homesites Coming Soon")
						.replace("New Townhomes Coming Soon, Coming Soon", "New Townhomes Coming Soon");
//			}
			if(status.contains("Final 3 Opportunities, 3 Opportunities Remain"))
			{
				status=status.replace("Final 3 Opportunities, 3 Opportunities Remain", "Final 3 Opportunities Remaining");
			}
			if(status.contains("New Section Coming Soon, Coming Soon"))
			{
				status=status.replace("New Section Coming Soon, Coming Soon", "New Section Coming Soon");
			}
			
//			if(status.contains("New Homes Coming Soon, Coming Soon"))
//			{
//				status=status.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon");
//			}
			
			status = status.replace("Only 2 Opportunities Remain, Closeout, Only Two Opportunities Remain,", "Only 2 Opportunities Remain, Closeout,")
					.replace("Limited Homesites Remaining, Limited Homesite Release", "Limited Homesites Remaining")
					.replace("Next Phase Coming Summer 2022, Coming Soon", "Next Phase Coming Summer 2022")
					.replace("Homes Are Selling Quickly, Selling Quickly,", "Homes Are Selling Quickly, ").replace("Limited Homesites Remain, Limited Homesites", "Limited Homesites Remain");
			data.addCommunity(commName.replaceAll(" Courtyard$", ""), cUrl, cType);
			data.addAddress(add[0].replace("&amp;", "&").replace(",", "").trim(), add[1].trim(), add[2], add[3]);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(PType, dType);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(ALLOW_BLANK);
		}
		}
	

	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);

		}

		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(new FileWriter(f));

					driver.get(url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); // y value '400' can
					// be
					try {
						WebElement click = driver.findElement(By.xpath("//*[@id=\"super_map_list_1471\"]/div[3]")); // -------show
																													// button
																													// of
																													// region
																													// "Richmond"
						click.click();
						click.click();
						U.log("Click Sucess");
					} catch (Exception e) {
						U.log(e.toString());
					}

					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}