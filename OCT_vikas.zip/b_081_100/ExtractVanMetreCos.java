package com.shatam.b_081_100;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractVanMetreCos extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractVanMetreCos();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Van Metre Apartments.csv", a.data()
				.printAll());
		//U.log(duplicates);
	}

	public ExtractVanMetreCos() throws Exception {

		super("Van Metre Apartments", "http://www.vanmetreapartments.com");
		LOGGER = new CommunityLogger("Van Metre Apartments");
	}

	public void innerProcess() throws Exception {
		// String

		// ************kirti Misal*******************//

		//String url = "http://communities.vanmetreapartments.com/?_ga=1.218063446.1962541637.1435231651";
		String url = "http://www.vanmetreapartments.com/searchlisting.aspx?ftst=&locationgeoid=0&renewpg=1&";
		String html = U.getHTML(url);
		U.log(html);
		/*String sec = U.getSectionValue(html,
				"<div id='resultHeader' class='clearfix sticky'><",
				"<div class='paginationWrap bottom'>");*/
		String linksSec[] = U.getValues(html,
				"parameters hidden mapPoint",
				"link-details row-fluid");
		int totalComm = linksSec.length / 2;
		for (String linkSection : linksSec) {
		//	U.log("------------------->"+linkSection);
			String commUrl = U.getSectionValue(linkSection,
					"itemprop='url' href='", "' class='");

			//U.log(commUrl);
//	if(commUrl!=null)
	{
			if(commUrl==null)
			{continue;}
			if (this.data.communityUrlExists(commUrl)) {
				duplicates++;
				continue;

			}
	
			// if(i<2)

			// if(inr==0||inr==totalComm||inr==totalComm+1||inr==linksSec.length-1)
			addDetails(linkSection);
			inr++;
			i++;

		}
		LOGGER.DisposeLogger();
		// addDetails(linksSec[0]);
	}
	}
	/*
	 * Apache Ant is a Java based build tool from Apache Software Foundation.
	 * Apache Ant's build files are written in XML and they take advantage of
	 * being open standard, portable and easy to understand.
	 * 
	 * This tutorial should show you how to use Apache ANT to automate the build
	 * and deployment process in simple and easy steps. After completing this
	 * tutorial, you should find yourself at a moderate level of expertise in
	 * using Apache Ant from where you may take yourself to next levels.
	 */
	
	//

	private void addDetails(String linkSec) throws Exception {
		//if(i==11)
		{
	
	//if (linkSec.contains("http://www.saratogasquareapt.com"))
			//	|| linkSec.contains("http://www.livefahrenheitapts.com"))
			//return;

		//U.log(linkSec);
		String commUrl = U.getSectionValue(linkSec, "itemprop='url' href='",
				"' class='");
		//U.log(":::::::::::::::::" + commUrl);
	//	if(commUrl.contains("http://www.thevintage.com"))
		{
			String html = U.getHTML(commUrl);
		// U.log(html);
		String apurl = ALLOW_BLANK;

		// apurl= U.getSectionValue(links[j],"href=\"" , "\"");
		U.log("comUrl::::::::::" + commUrl);
		String lat = U.getSectionValue(linkSec, "propertyLat\">", "<");
		String lng = U.getSectionValue(linkSec, "propertyLng\">", "<");
		String Street = U.getSectionValue(linkSec,
				"streetAddress\">", "<");
		String city = U.getSectionValue(linkSec, "addressLocality\">", "<");
		String state = U.getSectionValue(linkSec, "addressRegion\">", "<");
		String zip = U.getSectionValue(linkSec, "postalCode\">", "<");
		String comName = U.getSectionValue(linkSec, "propertyName\">", "<");

		//U.log(Street);
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String pType = ALLOW_BLANK, dType = ALLOW_BLANK;
		String pStatus = ALLOW_BLANK;
		// String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
		pType = U.getCommType(html);
		String type = U.getCommunityType(html);
		linkSec = linkSec
				.replaceAll("propertyMinRent\">\\d+\\.\\d+</span>", "");
		String floorPlan = U.getHTML(commUrl + "/floorplans.aspx");

		// U.log(floorPlan);
		String priceSec="";
		if(floorPlan!=null)
		 priceSec = U.getSectionValue(floorPlan, "<tbody id='divFPRows'",
				"<div class=\"container-fluid\">");
		String minPrice =ALLOW_BLANK,maxPrice=ALLOW_BLANK;
        if(priceSec!=null){
		String price[] = U.getPrices(priceSec, "\\$\\d{4}|\\$\\d+-\\$\\d+", 0);
        
		//U.log("minprice=" + price[0]);
		//U.log("maxprice=" + price[1]);
        
		 minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		 maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
        }
		String sqFt[] = U.getSqareFeet(linkSec+floorPlan, "\\d{3,4} -<span class='sr-only'>to</span> \\d{3,4} sq.ft|class='tcolumn text-center'>\\d{3,4}</td>",
				0);
		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

		if (Street == null)
			Street = U.getSectionValue(html, "span itemprop='streetAddress'>",
					"</span>");
		if (city == null)
			city = U.getSectionValue(html, "<span itemprop='addressLocality'>",
					"<");
		if (state == null)
			state = U.getSectionValue(html, "<span itemprop='addressRegion'>",
					"<");
		if (zip == null)
			zip = U.getSectionValue(html, "<span itemprop='postalCode'>", "<");
		
		
		comName=comName.replace(">", "");
		//U.log(Street +  city + state + zip);
		String ameUrl = commUrl + "/amenities.aspx";
		//U.log("ameUrl=="+ameUrl);
		String ameHtml = U.getHTML(ameUrl);
		
		if(!commUrl.contains("http://www.themissionon14.com"))
		html = html.replaceAll("Townhouses|common areas", "");
		Street=Street.replace(",", "").replace(".","");
		//U.log("html=====\n"+html);
		String commType = U.getCommunityType(html+ameHtml+linkSec);
		pStatus=U.getPropStatus(html+linkSec);
		html=U.getNoHtml(html);
		String pType1=U.getPropType((ameHtml+html).replaceAll("detached garages|our common areas, exterior",""));
		if(pType1.contains("Townhouse,Townhome")){
			
			pType1=pType1.replace("Townhouse,","");
		}
		data.addCommunity(comName, commUrl, commType);
		data.addAddress(Street, city, state.trim(), zip.trim());
		data.addPropertyStatus(pStatus);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, "FALSE");
		data.addPropertyType(pType1, U.getdCommType(ameHtml+html.replace("three-story shopping", "")));
		data.addNotes("");

	}
		i++;
		}
	}
	
}
