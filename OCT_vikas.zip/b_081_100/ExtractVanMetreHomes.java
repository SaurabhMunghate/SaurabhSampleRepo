/** @author Sanket Patil
 *  @date 19/04/2012 
 */

package com.shatam.b_081_100;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractVanMetreHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	
	private static String builderUrl = "https://vanmetrehomes.com";
	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new ExtractVanMetreHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Van Metre Homes.csv", a.data()
				.printAll());
	}
  
	public ExtractVanMetreHomes() throws Exception {

		super("Van Metre Homes", "https://www.vanmetrehomes.com/");
		LOGGER = new CommunityLogger("Van Metre Homes");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String html = U.getHTML("https://vanmetrehomes.com/our-communities/");
		String[] comListing = U.getValues(html, "<div class=\"heading\">", "</script>");
//		U.log("MMMMMM "+comListing.length);
/*		for(String comList : comListing){
			//U.log(comList);
			String[] comSec1 = U.getValues(html, "<div class=\"heading\">", "</script>");
			String comUrl = "https://vanmetrehomes.com"+U.getSectionValue(comList, "href=\"", "\"");
			String comName = U.getSectionValue(comList, "\">", "<");
			String comSec="";
			for (String string : comSec1) {
				if(string.contains(comName)) {
					comSec=string;
				}
			}
//			U.log(comSec);
		//	addDetails(comUrl,comName,comSec);
		//break;	
		}*/
		
		String remainComm = U.getSectionValue(html, "<li class=\"state\">", " <li class=\"extra\">");
		
		//String[] com = U.getValues(remainComm, "<a", "/a>");
		String[] com = U.getValues(html, "<h4>", "</script>"); //"<div class=\"phone\">");
		
		for(String getData : com) {
//			U.log(getData);
			if(getData.contains("class=\"county\"") || getData.contains("class=\"city\"") || getData.contains("class=\"state\"")) continue;
//			System.out.println("--------------"+getData);
			
				addDetails("https://vanmetrehomes.com"+U.getSectionValue(getData, "href=\"", "\""), U.getSectionValue(getData, ">", "<"),	getData);
			//break;
		}
		
		/*String[] communitiesInfo = U.getValues(html,"<h3 class=\"name title\">","View Community</a></div>");
		U.log("=============" + communitiesInfo.length);
		for (String communityInfo : communitiesInfo) {
			addDetails(communityInfo);
		}*/
		
		String navUrlSection = U.getSectionValue(html, "<ul class=\"navigation\">", "<li class=\"basic-menu main\">");
		if(navUrlSection != null){
			String citySection[] = U.getValues(navUrlSection, "<li class=\"city\">", " </ul>");
			for(String citySec : citySection){
				String comUrlSection[] = U.getValues(citySec, "<li>", "</li>");
				for(String comUrlSec : comUrlSection){
					String comUrl = builderUrl + U.getSectionValue(comUrlSec, "\" href=\"", "\"");
					String comName = U.getSectionValue(comUrlSec, "\" title=\"", "\"");
//					U.log(comName);
					addDetails(comUrl, comName, comUrlSec);
				}
			}
		}
		addDetails("https://vanmetrehomes.com/our-communities/va/loudoun/broadlands/hillside", "Hillside At Broadlands", "");
		LOGGER.DisposeLogger();
//		driver.quit();
	}

	//TODO ::
	private void addDetails(String url,String comName,  String commInfo) throws Exception {

//		if(j== 3)
//		try{
		{
			 

		
//	if(!url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/brambleton/west-park"))return;
			
			
			if (data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
				return;
			}
			
			U.log(j+">>>>>>>>>>" + url);		
		//	U.log(commInfo);
			LOGGER.AddCommunityUrl(url);
			
		
			
//			String commHtml = U.getHtml(url, driver);
//			U.log(U.getCache(url));
			String commHtml = U.getHTML(url);
			
			String remove = U.getSectionValue(commHtml, "<header id=\"theme-header\">", "</header>");
			if(remove!=null) {
			commHtml = commHtml.replace(remove, "").replace("amp;", "");
			}
			String rem = U.getSectionValue(commHtml, "More communities you may be interested in:", "</section>");
			if(remove!=null) {
				commHtml = commHtml.replace(remove, "");
			}
			String rem1 = U.getSectionValue(commHtml, "<div class=\"mobile-bar\">", "</masthead>");
			if(rem1!=null) {
				commHtml = commHtml.replace(rem1, "");
			}
			//------------ Community Name -----------------------------------
			
			U.log(comName);
			if (comName.contains("Ashburn, VA")) {
				comName = "Belmont Glen Village";
			}
			U.log("CommName::"+comName);
			comName=comName.replaceAll("Golf Club|Condos","");
			
			//---------------------- SQFT ------------------------
			String[] minMaxArea = new String[2];
			//
			String nearby = U.getSectionValue(commHtml, "<div class=\"interior  dark-mode\">", "</section>");
			if(nearby!=null)
			commHtml = commHtml.replace(nearby, "");
			//U.getSectionValue(commHtml, "<div class=\"interior  dark-mode\">", "</section>")			
			String rmsec=U.getSectionValue(commHtml, "More communities you may be interested in:", "</html");
			if(rmsec!=null) {
				//U.log("remmmmmmmm");
			commHtml=commHtml.replace(rmsec, "");
			}
			commHtml = commHtml.replace("boast at least 5,000 sq. ft. of planned amenities", "");
			commInfo =commInfo.replace("0Ks", "0,000").replaceAll("0s","0,000");

			String sqft[] = U.getSqareFeet(commHtml+commInfo,
							"Up to \\d,\\d{3} sq\\. ft|<p>Up to \\d,\\d{3} sq\\. ft\\.|Sq.Ft.\">\\d,\\d{3}<|\"Sq.Ft.\">\\d,\\d{3}-\\d,\\d{3}<|up to \\d,\\d+ square feet|into \\d{1},\\d{3}\\+ square feet |\\d,\\d{3}\\+ square feet|Square Footage:\\s*</strong>\\s*\\d{1},\\d{3}|\\d{4}\\+ square feet |\\d,\\d{3} sq. ft. ",
							0);
			minMaxArea[0] = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			minMaxArea[1] = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("Sqaure Feet is : "+sqft[0] + " ::: " +sqft[1]);

			//--------------- Price --------------------------
			String[] myPrices = new String[2];
			//U.getHtmlSection(commHtml, "Similar�Van Metre Communities", "</section>")
						
			commHtml = commHtml.replace("0s</strong></p>", "0,000</strong></p>");
			commHtml=commHtml.replaceAll("0s|0S|0's", "0,000");
			
			if(commInfo!=null)commInfo = commInfo.replace("$1Ms", "$1,000,000").replace("00s", "00,000").replaceAll("0s|0s", "0,000");
			
			U.log(">>>>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{60}\\$627[\\s\\w\\W]{60}", 0));

			String[] prices = U.getPrices((commInfo + commHtml).replace("$1.2Ms", "$1,200,000"),"Upper \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|Lower \\$\\d{3},\\d{3}|From: \\$\\d{3},\\d{3}|Priced From: Upper \\$\\d{3},\\d{3}|Priced From: Low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</strong>\\s*</p>|Priced:\\s*</strong>\\s*\\$\\d{3},\\d{3}|Priced From:\\s*</strong>\\s*\\$\\d{3},\\d{3}	|\\$\\d{3},\\d{3}",0);
			// U.log("MySection: " + sectionMy);
			myPrices[0] = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			myPrices[1] = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price is :: "+myPrices[0] + "  ::: " +myPrices[1]);
			String note = ALLOW_BLANK;
			
			
			//---------------_Address------------
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
		
			String addressSec =  U.getSectionValue(commHtml, "<strong>Address</strong><br />", "</p>");
			if(addressSec == null)addressSec =  U.getSectionValue(commHtml, "<strong>Address</strong></span><br />", "</p>");
			if(addressSec == null)addressSec =  U.getSectionValue(commHtml, "<strong>Community Address</strong><br />", "</p>");
			if(addressSec==null) addressSec=U.getSectionValue(commHtml, "<strong>Model Address</strong><br />", "<strong>");
			if(addressSec==null) addressSec=U.getSectionValue(commHtml, "<strong>Model Address</strong></span><br />", "</p>");
			if(addressSec==null) addressSec=U.getSectionValue(commHtml, "<strong>Model Address</strong><br />", "</p>");
			if(addressSec==null) addressSec=U.getSectionValue(commHtml, "\">Model Address</span><br />", "</p>");
			if(addressSec==null) addressSec=U.getSectionValue(commHtml, "<strong>Model&nbsp;Address</strong><br />", "<strong>");
			
			U.log("addressSec :: "+addressSec);
			if(addressSec!=null){
				U.log("AddSec::"+addressSec);
				if(addressSec.length() > 20){
					
					add = U.findAddress(addressSec.replace("<br />", ",").replace("n’s", "n's").replace("</span>", ""));
				}
				if(add.length>1) {
					add[0]=add[0].replaceAll("Offsite Sales Office", "");
				}
				U.log("add is :: "+ Arrays.toString(add));
			}
			
//			if(addressSec==null) {
//				addressSec=U.getSectionValue(commHtml, "<strong>Model Address</strong></span><br />", "</p>");
//				if(addressSec!=null) {
//					addressSec=addressSec.replace("&nbsp;", "").replace("<br />", ", ");
//				}
//			}
			if(addressSec==null && commInfo.length()>3){
				
//				add[0] = U.getSectionValue(commInfo, "\"street\":\"", "\"");
//				add[1] = U.getSectionValue(commInfo, "\"city\":\"", "\"");
//				add[2] = U.getSectionValue(commInfo, "\"state\":\"", "\"").replace("Virginia", "VA");
//				add[3] = U.getSectionValue(commInfo, "\"zip\":\"", "\"");
			}
			//----------latlng-----------
			String[] latlng = {ALLOW_BLANK,ALLOW_BLANK};
			String LatLngSec = U.getSectionValue(commHtml, "<input type=\"hidden\" name=\"daddr\" value=\"", "\"");
			
			if(LatLngSec != null){
				latlng = LatLngSec.split(",");
			}
			else
			{
				
				latlng[0] = U.getSectionValue(commInfo, "\"lat\":", ",");
				latlng[1] = U.getSectionValue(commInfo, "\"lng\":", "}");
				
			}
			U.log("latlng is :: "+ Arrays.toString(latlng));
			//

			if(add[0] == null) add[0] = ALLOW_BLANK;
				
			//---------fetching latlng from add

//			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/aldie/hartland")) {
//				add[0] = ALLOW_BLANK;
//				add[1] = "Aldie";
//				add[2] = "VA";
//				add[3] = ALLOW_BLANK;
//				latlng=U.getlatlongGoogleApi(add);
//				
//				add = U.getAddressGoogleApi(latlng);
//				if(add == null) add = U.getGoogleAddressWithKey(latlng);
//				geo = "TRUE";
////				note = "Address And Lat-Lng Taken Using City And State";
//			}
			

			if(add[0].length()>4 && latlng[0].length()<4){
				
				latlng=U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			//---------fetching add from latlng
			
			if(add[0].length()<4 && latlng[0].length()>4){
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getGoogleAddressWithKey(latlng);
				geo = "TRUE";
			}
			
			//----------Address taken using city and State---------
			if(add[0].length()<4 && latlng[0].length()<4){
				String cityStateSec = U.getSectionValue(commHtml, "<h2>", "</h2>");
				if(cityStateSec != null  && !cityStateSec.contains(","))
					cityStateSec = U.getSectionValue(commHtml, "<div class=\"content\"><p>", "</p>");
				
				U.log(cityStateSec);
				if(cityStateSec != null  && cityStateSec.contains(",")){
					cityStateSec = cityStateSec.replaceAll("(Condominiums|Single Family Homes) and Townhomes in ", "");
					String temp [] = cityStateSec.split(",");
					add[1] = temp[0];
					add[2] = temp[1];
					latlng = U.getlatlongGoogleApi(add);
					if(latlng == null) latlng = U.getGoogleLatLngWithKey(add);
					add = U.getAddressGoogleApi(latlng);
					if(add == null) add = U.getGoogleAddressWithKey(latlng);
					geo = "true";
					note = "Address And Lat-Lng Taken Using City And State";
				}
			}
			//================unit count && constrinform
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			int lotcount=0;
			
			if(commHtml.contains("interactivesitemap")) {
				String siteMap=U.getSectionValue(commHtml, "<iframe id='f360_interactivesitemap", "</iframe>");
				String lotUrl=U.getSectionValue(siteMap, "src='", "'");
				U.log("loturl :"+lotUrl);
				String lotHtml=U.getHtml(lotUrl, driver);
				U.log("comm Ccache path"+U.getCache(lotUrl));
				String[] lotSection=U.getValues(lotHtml, "<g id=\"lot_", "onpointerdown=");
				for(String lotSec :lotSection) {
					if(lotSec.contains("lotItem"))
						lotcount++;
				}
				counting=Integer.toString(lotcount);
			}
			U.log("counting :"+counting);
			//=============
			String comType = ALLOW_BLANK;
			String pStatus = ALLOW_BLANK;
			String dType = ALLOW_BLANK;
			String propertyType = ALLOW_BLANK;
			
			//===== Home section ===========
			String homeUrls[] = U.getValues(commHtml, "<h4><a href=\"", "\">");
			U.log("Total homes :"+homeUrls.length);
			String combinedHtml = null;
			for(String homeUrl : homeUrls){
				if(!homeUrl.startsWith("http")) homeUrl = builderUrl + homeUrl;
				//U.log("homeUrl :"+homeUrl);
				combinedHtml += U.getHTML(homeUrl);
				//combinedHtml += U.getSectionValue(U.getHTML(homeUrl), "<section id=\"theme-area-3\"", "</section>");
			}
			
			String removeFooter = U.getSectionValue(commHtml, "<footer", "</body>");
			if(removeFooter != null) commHtml = commHtml.replace(removeFooter, "");
			
			String comDetailsSec = U.getSectionValue(commHtml, "<div class=\"main-content content\">", "</div>");
			//U.log(commInfo);
			comDetailsSec = comDetailsSec.replace("<h3>Estates Collection</h3>", "The Estate section").replace("Brambleton, a 55+ Active Adult community", "")
					.replace("resort-level pool", "resort-style level pool");
			//---------Community TYpe ------------
			comType = U.getCommType((comDetailsSec+commInfo+U.getNoHtml(commHtml)).replaceAll("elongated", "")
					.replace("masterfully-planned place", "masterfully-planned community")
					.replace("Welcome center &amp; gate", "Gated Community"));
			
			//---------Property Type--------
			comDetailsSec = comDetailsSec.replace("Farmhome Soul", "Farmhouse style");
			commHtml=commHtml.replaceAll("Traditional  single family homes", "Traditional single family homes");
			propertyType = U.getPropType((comDetailsSec+commInfo+U.getNoHtml(commHtml)).replace("combination of luxury", "luxury homes")
					.replaceAll("insurance and HOA Fees are not included|townhome\">|townhome condo\">|condominiums\">Condominiums</li>|single-family townhome\"|“back-to-back” townhouse style units|	single-family\"", ""));
			
//			U.log(">>>>>>>>>"+Util.matchAll(comDetailsSec+commInfo+U.getNoHtml(commHtml), "[\\s\\w\\W]{30}townhome[\\s\\w\\W]{30}", 0));
			
			//----------Derived Type------
			
//			U.log("chhkkkk"+Util.matchAll(comDetailsSec+commInfo+commHtml, "[\\s\\w\\W]{50}floor[\\s\\w\\W]{50}", 0));

			
			if(combinedHtml != null) combinedHtml = combinedHtml.replaceAll("3-Level", "three story").replace("2-Level", "two story").replace("the 2nd, 3rd & 4th levels", "the 2 Story , 3 Story & 4 Story");
			
			commInfo=commInfo.replace("Move-In Ready Homes Available", "").replace("One, two, three and four level", "One story, two story, three story and four story").replace("One, two, and three level ", "1 story, 2 story, and 3 story");
			
			dType = U.getdCommType((comDetailsSec+commInfo+U.getNoHtml(commHtml)).replace("four-level", "4 story").replace("3 levels", "3 Story").replace("2 Level Traditional-Style", "2 Story").replace("two-level", "2 Story") //.replace("first-floor ", "1 Story").
					+ combinedHtml);
//			comDetailsSec+commInfo+U.getNoHtml(commHtml))+ combinedHtml
			U.log("chhkkkk"+Util.matchAll(commInfo, "[\\s\\w\\W]{50}story[\\s\\w\\W]{50}", 0));
//			U.log("chhkkkk"+Util.matchAll(U.getNoHtml(commHtml), "[\\w\\w\\s]{50}level[\\w\\w\\s]{50}", 0));
//			U.log("chhkkkk"+Util.matchAll(combinedHtml, "[\\w\\w\\s]{50}level[\\w\\w\\s]{50}", 0));

			
			U.log("dType: "+dType);
			//--------property status----------
			comDetailsSec=comDetailsSec.replace("ONLY ONE BRADLEY HOMESITE REMAINING IN THE LIFTS COLLECTION!", "ONLY ONE HOMESITE REMAINING IN THE LIFTS COLLECTION!").replace("architecture.. Coming soon", "").replaceAll("eadowbrook Farm - The Estates - Coming Soon|coming-soon-estates.jpg| Lake views and premium lots available", "");
			pStatus = U.getPropStatus(comDetailsSec+commInfo);
			pStatus = pStatus.replace("Move-in Ready Homes Available", "Move-in Ready Homes");
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/broadlands/hillside")) pStatus="Now Open";
			U.log("pStatus: "+pStatus);
			
			//status from Image
//			if(url.contains("/loudoun/brambleton/downtown-brambleton"))propertyType =propertyType+", Multi-Gen Homes";
//			if(comUrl.contains("/va/loudoun/aldie/tanglewood"))pStatus =pStatus+", Only 2 Homes Left";
			if((comName.contains("Estates") || commHtml.contains("<h3>Estates Collection</h3>")) && !propertyType.contains("Estate"))propertyType = propertyType+", Estate-Style Homes";
//			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/aldie/stone-mill-corner"))dType = dType + ", 2 Story";
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/leesburg/lofts-village-walk") || url.contains("/va/loudoun/dulles/gateway-commons"))pStatus =   "Sold Out";//Img
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/aldie/stone-mill-corner"))dType = "4 Story";
			if(url.contains("https://vanmetrehomes.com/our-communities/va/fairfax/lorton/liberty"))pStatus = "Sold Out";//Img
			if(url.contains("loudoun/leesburg/meadowbrook-farm"))pStatus = "New Homesites Now Selling";//Img
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/ashburn/goose-creek"))dType=ALLOW_BLANK;
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/chantilly/prosperity-plains"))pStatus="1 Townhome Remains";//From Image
			if( url.contains("https://vanmetrehomes.com/our-communities/va/frederick/winchester/valley-view"))
				pStatus = pStatus.replace("Currently Sold Out", "Sold Out");//Img
//			if(url.contains("https://vanmetrehomes.com/our-communities/va/prince-william/gainesville/robinson-manor"))
//					pStatus = pStatus + ", 75% Sold Out";	
			//4208-4214 Frost St
			//Marshall, VA 20115
			
			

			
/*			if(url.contains("https://vanmetrehomes.com/our-communities/va/fauquier/marshall/heritage")) {
				add[0] = "4208-4214 Frost St";
				add[1] = "Marshall";
				add[2] = "VA";
				add[3] = "20115";
			}
*/			
			String [] moveSec = U.getValues(commHtml, "<h4>", "</h4>");
			String quickDate=U.getSectionValue(commHtml, "<div class=\"teaser\">", "</div>");
			U.log(quickDate);
			if(quickDate==null) {
				quickDate=ALLOW_BLANK;
			}
			int count = 0;
			for(String move : moveSec) {
				if(move.contains("move-in-ready") && !quickDate.contains("2022 Fall Delivery") && !quickDate.contains("<span>Model Now Open!</span>") ) {
//					U.log("djsfooajj"+count);
					count++;					
				}
					
			}
			U.log("quick Count :: "+count);
			
			if(count>0 && !pStatus.contains("Move") && !quickDate.contains("<span>Temporarily Sold Out </span>") && !quickDate.contains("Only 1 Home Remaining!</span>")) {
				
				if(pStatus.length()>3)
					pStatus = "Move-in Ready Homes, "+pStatus;
				else
					pStatus = "Move-in Ready Homes";
				
			}
			
			pStatus = pStatus.replace("-,", "");
			
			//From Images
			if(url.contains("https://vanmetrehomes.com/our-communities/va/fairfax/alexandria/crest-of-alexandria"))
				pStatus = "Sold Out";//Img

/*			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/brambleton/birchwood"))
				pStatus  = "Coming Soon, "+pStatus;//Img
*/
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/broadlands/the-signature")
					|| url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/purcellville/montrose-farm-estates")){
				if(pStatus == ALLOW_BLANK) pStatus="Sold Out";
				else if(pStatus != ALLOW_BLANK && !pStatus.contains("Sold Out")) pStatus += ", Sold Out";
			}
			
			
//			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/purcellville/montrose-farm-estates"))pStatus = pStatus.replace("Move-in Ready Homes", "Sold Out");//Img

			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/leesburg/meadowbrook-farm")) {
				pStatus="Last Chance, Final Phase Almost Sold Out";
			}//IMG\
			
			if(url.contains("https://vanmetrehomes.com/our-communities/va/prince-william/haymarket/robinson-village")) {
				pStatus+=", 5 Homesites Remain";
			}//IMG\
			
			if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/brambleton/west-park")) {
				pStatus="Over 70% Sold Out";
				}//IMG
		
				if(url.contains("https://vanmetrehomes.com/our-communities/va/loudoun/aldie/stone-mill-corner")) {
					pStatus="Sold Out";
					}
			
	
			U.log(Arrays.toString(add));
			data.addCommunity(comName, url, comType );
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(),add[3].trim());
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
			
			data.addPropertyType(propertyType, dType);
			
			data.addPropertyStatus(pStatus);
			data.addPrice(myPrices[0], myPrices[1]);
			data.addSquareFeet(minMaxArea[0], minMaxArea[1]);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
}