/** @author Parag Humane
 *  @date 19/04/2013 
 */
package com.shatam.b_081_100;

import java.util.ArrayList;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class HHHuntCorpHHHuntCommunities extends AbstractScrapper {
	int k = 0;
	static int j = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	ArrayList<String> list = new ArrayList<String>() {
		{
			add("http://www.hhhuntcommunities.com/community/white-hall/index.php");
			add("http://www.hhhuntcommunities.com/community/charter-colony/index.php");
			add("http://www.hhhuntcommunities.com/community/rutland/index.php");
		}
	};

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new HHHuntCorpHHHuntCommunities();
		a.process();
		// HHHunt Corporation
		FileUtil.writeAllText(U.getCachePath() + "HHHunt Corporation - HHHunt Homes.csv", a.data().printAll());
		// a.data().printAll();

	}

	public HHHuntCorpHHHuntCommunities() throws Exception {
		super("HHHunt Corporation - HHHunt Homes", "https://www.hhhunthomes.com");
		LOGGER = new CommunityLogger("HHHunt Corporation - HHHunt Homes");
	}

	public void innerProcess() throws Exception {

		String html = U.getPageSource("https://www.hhhunthomes.com");

		String regionsSection = U.getSectionValue(html, "Pick Your Region", "</ul>");

		String regions[] = U.getValues(regionsSection, "<a href=\"", "\"");

		for (String reg : regions) {
			reg = "https://www.hhhunthomes.com" + reg;
			U.log("region::" + reg);
			String htm = U.getPageSource(reg);

			String[] commSections = U.getValues(htm, "<a class=\"community-list-card\"", "<button class=\"button-square--darkbeige solid");

			for (int i = 0; i < commSections.length; i++) {
				// U.log(commSections[i]);
				addDetails(commSections[i], reg);
			}

		}
	}

	private void addDetails(String comSec, String regUrl) throws Exception {
//		 if(j>=15 && j<=30)
		{

			// U.log(htm);
			/*
			 * String url = U.getSectionValue(htm, "\"", "\">"); if
			 * (!url.contains("https:")) url = "https://www.hhhunthomes.com/" + url;
			 */
			String url = U.getSectionValue(comSec, "href=\"", "\"");
			if (!url.contains("http"))
				url = "https://www.hhhunthomes.com" + url;

			//============== Single Run =======================
//			if (!url.contains("https://www.hhhunthomes.com/property-search-results/richmond-va/taylor-farm-townhomes"))return;
			
			U.log("\n\nCount:: "+j);
			U.log("Community URL :" + url);

			if(data.communityUrlExists(url)) {
				
				LOGGER.AddCommunityUrl("=========== Repeated ========== "+url);
			}
			LOGGER.AddCommunityUrl(url);
			
			String comHtml = U.getPageSource(url);

			comHtml = comHtml.replace("Garage Townhomes", "");
			// U.log(comHtml);
			comHtml = comHtml.replace("<title>Williamsburg Homes - ", "<title>");
			// ============= commName =======================
			String commName = U.getSectionValue(comSec, "<h3 class=\"card__title\">", "<");

			commName = commName.replaceAll(" - Community Overview", "").trim();
			U.log("Name :" + commName);

			// ============ community Type ====================
			comHtml = comHtml.replace("master-planned community", "master planned community").replaceAll("Magnolia Green|master-planned", "");
			//comHtml = comHtml.replace("Planned community", "master plan");
			String commType = U.getCommunityType(comHtml + comSec);
			U.log("Type :" + commType);

			// =========== Note =======================
			String noteVar = ALLOW_BLANK;

			// ================== Address ====================
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String dir = url + "/contact-and-directions";
			U.log("Direction Url::: " + dir);
			String directionHtml = U.getPageSource(dir);
			String addSection = U.getSectionValue(directionHtml, "<h4 class=\"address-hours__header\">", "</a>");
			// U.log("addSection::"+addSection);

			if (addSection != null) {
				addSection = U.getNoHtml(addSection).replace("<br>", ",").replace("North Carolina", "NC");
				addSection = addSection.replaceAll("\\(.*\\)?|Sales Center|Community Club House", "").replace(",8400 Combs Dr", "8400 Combs Dr");
				addSection = addSection
						.replace("Henrico County - Glen Allen, Virginia", "1101 Charter Colony Pkwy,  Midlothian")
						.replace("<br/>", ",");
				U.log("addSection::" + addSection);

				add = U.getAddress(addSection);
				add[0] = add[0].replaceAll(",", "");
			}

			if(add[0] ==null || add[0]==ALLOW_BLANK) {
				
				addSection = U.getSectionValue(comHtml, "Address:", "</p>");
				if(addSection!=null) {
				addSection = U.getNoHtml(addSection.replaceAll("\\(.*\\)?", ""));
				add = U.getAddress(addSection);
				}
			}
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);
			
			// ================ LatLng =================================
			String latLon[] = { ALLOW_BLANK, ALLOW_BLANK };
			String latLngSection = U.getSectionValue(directionHtml, "href=\"https://maps.google.com/?q=", "\" ");
			if (latLngSection == null) {
				U.getSectionValue(directionHtml, "data-widget-latlng=\"", "\"");
			}
			// U.log(latLngSection);
			if (latLngSection != null) {
				latLon[0] = Util.match(latLngSection, "\\d{2}\\.\\d{4,}");
				latLon[1] = Util.match(latLngSection, "-\\d{2}\\.\\d{4,}");
			}
			if (latLon[0] == null) {
				latLon[0] = ALLOW_BLANK;
				latLon[1] = ALLOW_BLANK;
			}

			if (latLon[0] == ALLOW_BLANK && add[0] != ALLOW_BLANK) {
				latLon = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}
			if (latLon[0] != ALLOW_BLANK && add[0] == ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latLon);
				geo = "TRUE";
			}

			if (url.contains("https://www.hhhunthomes.com/townes-at-north-salem/community-overview.html")) {

				if (latLon[0] == ALLOW_BLANK && latLon[0] == ALLOW_BLANK) {

					add[1] = "Apex";
					add[2] = "NC";
					latLon = U.getlatlongGoogleApi(add);
					geo = "TRUE";
					add = U.getAddressGoogleApi(latLon);
					noteVar = "LatLong And Address Taken From City & State";
				}
			}

			if (url.contains("https://www.hhhuntcommunities.com/river-mill/index.html")) {

				String locationHtml = U.getHTML("https://www.hhhuntcommunities.com/river-mill/location.html");
				String addSec = U.getSectionValue(locationHtml, "<h1 class=\"h1-rm\">LoCATION</h1>",
						"<div class=\"section body\">");

				if (addSec != null) {

					String addrs = U.getSectionValue(addSec, "<div class=\"rm-hero-overlay-text\">", "</div>")
							.replace("<br>", ",");
					add = U.getAddress(addrs);
					latLon[0] = "37.6787105";
					latLon[1] = "-77.4667222";
				}
			}

			if (url.contains("https://www.hhhuntcommunities.com/rutland-grove/community-overview.html")
					|| url.contains("https://www.hhhuntcommunities.com/rutland-grove/community-overview.html")) {

				add[0] = "9665 Chamberlayne Rd";
				add[0] = "Mechanicsville";
				add[0] = "VA";
				add[0] = "23116";

				latLon[0] = "37.66862201229536";
				latLon[1] = "-77.391981542569";
			}

			if (url.contains("https://www.hhhuntcommunities.com/wescott/index.html")) {

				add[0] = "4001 Lonas Pkwy";
				add[0] = "Midlothian";
				add[0] = "VA";
				add[0] = "23112";
				if (latLon[0] == ALLOW_BLANK && latLon[0] == ALLOW_BLANK) {
					latLon = U.getlatlongGoogleApi(add);
					geo = "TRUE";
					add = U.getAddressGoogleApi(latLon);
				}
			}

			if (add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) {
				if (latLon[0] == ALLOW_BLANK && latLon[0] == ALLOW_BLANK) {
					latLon = U.getlatlongGoogleApi(add);
					geo = "TRUE";
					add = U.getAddressGoogleApi(latLon);
					noteVar = "LatLong And Address Taken From City & State";
				}
			}
			if (add[3] == ALLOW_BLANK || add[3] == null && latLon[0] != ALLOW_BLANK) {
				String addrs[] = U.getAddressGoogleApi(latLon);
				add[3] = addrs[3];
				add[2] = addrs[2];
				geo = "True";
			}
			U.log("Lat :" + latLon[0] + " Long :" + latLon[1]);

			// ============== Home Section ========================
			String homeUrl = ALLOW_BLANK;
			String htmlHtml = ALLOW_BLANK;
			homeUrl = url + "/floorplans";
			U.log("homeUrl::>" + homeUrl);
			htmlHtml = U.getPageSource(homeUrl);

			String[] floorSec = U.getValues(htmlHtml, "<div class=\"card-floorplan__body\">", "View Details");
			String floorHtml = "";

			for (String floor : floorSec) {

				String floorUrl = U.getSectionValue(floor, "<a href=\"", "\"");
				U.log("Floors:::: "+floorUrl);
				try {
					floorHtml += U.getPageSource("https://www.hhhunthomes.com" + floorUrl) + floor;
				} catch (Exception e) {
					// TODO: handle exception
				}
			}

			// ================ Quick Data ================
			String  quickUrl = url + "/move-in-ready-homes";
			U.log("QuickUrl::>" + quickUrl);
			String quikHtml =  U.getPageSource(quickUrl);
			
			String[] quickData = U.getValues(quikHtml, "<div class=\"qmi-card__listing\">", "<div class=\"qmi-card__body\">");
			if(quickData.length == 0)
				quickData = U.getValues(quikHtml, "<div class=\"qmi-card__listing\">", " <span class=\"qmi-card__details\">");
			
			String quickHtml = "";
			for (String quick : quickData) {
				
				quickHtml += quick; 
			}

			// ================ Price =========================
			comHtml = comHtml.replaceAll("'s", ",000s");// 240's
			comHtml = comHtml.replaceAll("0s", "0,000s");// 240's
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comHtml = comHtml.replaceAll("0's|0s", "0,000").replaceAll("<span>\\n*\\s*\\n*\\s*", "<span>");
			floorHtml = floorHtml.replaceAll("0's|0s", "0,000").replaceAll("<span>\\n*\\s*\\n*\\s*", "<span>");
			quickHtml = quickHtml.replaceAll("0's|0s", "0,000").replaceAll("<span>\\n*\\s*\\n*\\s*", "<span>");
		
			String[] price = U.getPrices(comHtml + floorHtml + quickHtml,
					"\\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log(minPrice+"\t"+maxPrice);

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;

			// ==================== Sqft =====================
			String[] sqft = U.getSqareFeet(comHtml + (floorHtml + quickHtml).replaceAll("svg\"/>\\n*\\s*\\n*\\s*", "svg\"/>"),
					"<span>\\d,\\d{3} - \\d,\\d{3}|svg\"/>\\d,\\d{3} - \\d,\\d{3}|svg\"/>\\d,\\d{3}|svg\"/>\\d,\\d{3} - \\d,\\d{3}",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			
			U.log("minSqft :" + minSqft + " maxSqft:" + maxSqft);

			// ================ propety Status ===================
			String status = ALLOW_BLANK;
			String statSec = U.getPageSource(url);
			String remove = "Move-in|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|Village-Coming Soon|basement lots now available|html\">\\s+Coming|court \\(Coming Summer/Fall";
			statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
			statSec = statSec.replace("area (coming", ""); // .replace("new-section-coming-soon", "new section coming
															// soon");
			if (url.contains("providence/community-overview.html"))
				comSec = comSec.replace("New section opening soon", "");
			
			status = U.getPropStatus((statSec + comSec)
					.replaceAll("now open -|now open - brand new|park now |[Q|q]uick [M|m]ove|planned community with only a few|coming soon\\. contact|now open - brand new community clubhouse", ""));
			
			if (add[0] == ALLOW_BLANK) {
				String aaaa = U.getHardcodedAddress("Hardcode_TRI Pointe Group-Pardee Homes", url);
				U.log("------->" + aaaa);
				if (aaaa != null) {
					String[] aaa = aaaa.split(",");
					add[0] = aaa[0];
					add[1] = aaa[1];
					add[2] = aaa[2];
					String[] latl = U.getlatlongGoogleApi(add);
					latLon[0] = latl[0];
					latLon[1] = latl[1];

					noteVar = aaa[6];
					String[] latlng = { latLon[0], latLon[1] };
					String[] aa = U.getAddressGoogleApi(latlng);
					add[3] = aa[3];
					add[0] = aa[0];
					geo = "true";
				}
			}

			// =============== Property Type ===========
			String commHtm = U.getPageSource(url);
			String propStatus = ALLOW_BLANK;

			String hoaHtmlSec = ALLOW_BLANK;
			// U.log("------------------------"+commHtm.contains("HOA "));

			if (commHtm.contains("HOA ")) {
				String hoaUrl = url.replace("/community-overview.html", "/homeowners-association.html");
				String hoaHtml = U.getPageSource(hoaUrl);
				hoaHtmlSec = U.getSectionValue(hoaHtml, " <h1 class=\"h1-community hoa\">", "</p>");
				// U.log("hoaHtmlSec::"+hoaHtmlSec);
			}

			// --------- From Image ----------------
			if (url.contains("/holloway-at-wyndham-forest/community-overview.html")) {
				minPrice = "$390,000";
				status = "Now Selling";
			}
			if (url.contains("/midtowne-at-meridian/community-overview.html"))
				status = "Only 1 Home Remaining";
			if (url.contains("the-villages-of-charter-colony/community-overview.html"))
				status = "Only 5 Waterfront Homesites Remaining";

			comSec = comSec.replace("condominiums quietly", "").replace("luxury built", " luxury homes");
			htmlHtml = htmlHtml.replaceAll(
					"condominiums quietly|Apartment Living</div>|http://hhhunt.com/apartments.html|HHHuntApartmentLiving.com|Cabin:|Cabin Condensed:|link\">\\s+Apartment Living",
					"");
			commHtm = commHtm.replaceAll(
					"\">Apartment Living</div>|condominiums quietly|Apartment Living</div>|http://hhhunt.com/apartments.html|HHHuntApartmentLiving.com|Cabin:|Cabin Condensed:|/hoa-login.html|link\">\\s+Apartment",
					"");
			commHtm = commHtm.replace("Luxury ranch", "Luxury homes ranch");

			commName = commName.replaceAll("Homes $|Community $", "");
			if (url.contains("/ridgefield-green/community-overview.html"))
				commName = "Ridgefield Green";

			String remSec1 = U.getSectionValue(commHtm, "<h4 class=\"footer-title\">",
					"<div class=\"wrapper-common-footer\">");
			if (remSec1 == null)
				remSec1 = "";
			commHtm = commHtm.replace(remSec1, "");

			// String rem=U.getSectionValue(comHtml,"<div
			// class=\"wrapper-common-footer-links\">","</a>");
			commHtm = commHtm.replaceAll("Garage Townhomes", "");
			commHtm = commHtm.replace("Luxurious Designer Touches", "luxury homes");
			String propType = U.getPropType((commHtm + comSec + htmlHtml + hoaHtmlSec + floorHtml + quickHtml)
					.replaceAll("LandingLoft|%20[b|B]ungalow|Loft\\d|Loft\\.jpg|\\([t|T]raditional\\)", ""));
			U.log("Property Type::: "+propType);
//			U.log("MMMMMMMM"+Util.matchAll((commHtm + comSec + htmlHtml + hoaHtmlSec + floorHtml + quickHtml).replaceAll("Loft\\d|LandingLoft", ""), "[\\s\\w\\W]{30}Bungalow[\\s\\w\\W]{30}", 0));
			propType = propType.replace(",Apartment Home", "");
			// propType=propType.replace("Common Area,","");
			if (propType.length() == 0) {
				propType = ALLOW_BLANK;
			}
			
			if(comSec.contains("new-phase-flag.svg\"")) {
				
				if(!propStatus.contains("New Phase")) {
				if(status.length()<3) status  = "New Phase";
				else
					status += ", New Phase";
				}
		}
			
if(comSec.contains("grandopening-flag.svg\"")) {
				
	if(!propStatus.contains("Grand Opening")) {
				if(status.length()<3) status  = "Grand Opening";
				else
					status += ", Grand Opening";
	}
		}
			
			U.log("Move in Count:: "+quickData.length);
			if(quickData.length>0) {
				if(status.length()<3) status  = "Move-in Ready Homes";
				else
					status += ", Move-in Ready Homes";
			}
			
			U.log("Property Type :" + propType);
			U.log("CommType::" + commType);

			if (this.data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(url);

			data.addCommunity(commName, url, commType);
			data.addAddress(add[0], add[1], add[2].toUpperCase(), add[3]);
			data.addLatitudeLongitude(latLon[0].trim(), latLon[1].trim(), geo);
			data.addPropertyType(propType, U.getdCommType(commHtm + htmlHtml + floorHtml));
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addNotes(noteVar);
			data.addSquareFeet(minSqft, maxSqft);
		}
		j++;
	}
}