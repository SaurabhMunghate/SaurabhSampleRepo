/** @author Priti
 *  @date Sept/2016
 */

package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.james.mime4j.codec.EncoderUtil.Usage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractBeechWoodOrganization extends AbstractScrapper {
	int k = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractBeechWoodOrganization();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Beechwood Homes.csv", a.data().printAll());
	}

	public ExtractBeechWoodOrganization() throws Exception {

		super("Beechwood Homes", "https://www.beechwoodhomes.com/");
		LOGGER = new CommunityLogger("Beechwood Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String html = U.getHtmlHeadlessFirefox("https://beechwoodhomes.com/", driver);
		String remove=U.getSectionValue(html, "<section class=\"elementor-section elementor-top-section elementor-element elementor-element-f0385df elementor-section-boxed elementor-section-height-default elementor-section-height-default\" data-id=\"f0385df\"", "</section>");
		//String comSec[] = U.getValues(html, "<h3 class=\"h3",	"</h3>");//"<h3 class=\"mb-2\">");
		if(remove!=null)
		html=html.replace(remove, "");
		//String comSec[] = U.getValues(html, "<a class=\"elementor-cta",	"</h4>");
		String comSec[] = U.getValues(html, "<a class=\"elementor-cta\"",	"</a>");
		U.log("No. of communities:" + comSec.length);
//		String latlngSections[] = U.getValues(html, "\"comm\":\"", "id\":");
//		U.log("latlngSections length::" + latlngSections.length);

		for (String comInfo : comSec) {
			comInfo = comInfo.replaceAll("href=\"javascript:", "");
			//String comName = U.getSectionValue(comInfo, "<h4 class=\"elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow\">", "</h4>");
			String comName = U.getSectionValue(comInfo,"<h4 class=\"elementor-cta__title elementor-cta__content-item elementor-content-item\">","</h4>");
			//U.log(comName);
			if(comName != null)
				comName = comName.replaceAll("<br> |<a href=(.*)?\">|</a>", "");
//			U.log(">>"+comInfo);
//			for (String latlngSec : latlngSections) {
////				U.log(latlngSec);
//				if (latlngSec.contains(comName)) {
//					addInfo(comName, comInfo, latlngSec);
//				} 
///*				else {
//					latlngSec
//					addInfo(comName, comInfo, ALLOW_BLANK);
//				}
//*/			}
			// break;
			
			String comUrl = U.getSectionValue(comInfo, "href=\"", "\""); 
			if(!comUrl.contains("www.beechwoodhomes.com")) {
				comUrl="https://www.beechwoodhomes.com/"+comUrl;
			}
			if(comUrl.contains("https://www.oakridgebeechwood.com/")) {
				comUrl="https://www.oakridgebeechwood.com/";
			}
			if(comUrl.contains("https://www.beechwoodcarolinas.com/"))
				comUrl="https://www.beechwoodcarolinas.com/";
			if(comUrl.contains("https://beechwoodhomes.com/the-selby/"))
				comUrl="https://beechwoodhomes.com/the-selby/";
//				U.log(">>"+comInfo);
			U.log(comName);
				U.log(comUrl);
			String quickHtml=U.getHTML("https://www.beechwoodhomes.com/quick-move-in/")	;
				
			//if(comUrl.contains("/meadows"))comName = "Country Pointe Meadows Yaphank";
			//+U.getSectionValue(comInfo, "<h2 class=\"modal-title\"><a href=\"", "\"");
			
		//	LOGGER.AddCommunityUrl("https://beechwoodhomes.com/plainview/retail"+":::::Redirect to plainview retail page");
			
			if(comUrl.contains("https://www.beechwoodcarolinas.com/")) {
				
				addInfo("https://www.beechwoodcarolinas.com/ferncliff/", "Ferncliff At Cotswold", comInfo,quickHtml);
				addInfo("https://www.beechwoodcarolinas.com/lakeside-pointe/", "Lakeside Pointe", comInfo,quickHtml);
				addInfo("https://www.beechwoodcarolinas.com/weddington-glen/", "Weddington Glen", comInfo,quickHtml);
				addInfo("https://www.beechwoodcarolinas.com/broadmoor/", "Broadmoor", comInfo,quickHtml);
				
			}else
				addInfo(comUrl, comName, comInfo,ALLOW_BLANK);
		}
     	try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private void addInfo(String comUrl, String comName, String comInfo,String quickHtml) throws Exception {
//		if(j >= 15)
		{
			// ------Com Url and Com Html----------
//			if(comUrl.contains("countrypointeridge"))
//				comUrl = "https://countrypointeridge.com/";
//			if(comUrl.contains("tidesnyc"))
//				comUrl = "https://tidesnyc.com";
//			if(comUrl.contains("oakridgebeechwood"))
//				comUrl = "https://oakridgebeechwood.com/";
			
//			TODO:Single-exe
//		if(!comUrl.contains("https://www.beechwoodcarolinas.com/broadmoor/")) return;  //-------- Single com execution
				
//			U.log(comInfo);
			if(comUrl.contains("https://www.beechwoodhomes.com/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjI4NzE3IiwidG9nZ2xlIjpmYWxzZX0%3D")) {
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Redirected to main page");
				return;
			}
			if(comUrl.contains("https://www.beechwoodhomes.com/country-pointe-plainview/retail/")||comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/community/")) {
				LOGGER.AddCommunityUrl(comUrl+"=========Retail");
				return;
			}
			
			comName=comName.replace("Country Pointe Meadows | Yaphank", "Country Pointe Meadow");
			 comName=comName.replace("Oak Ridge | Saratoga NY", " Oak Ridge").replace("Village of Westhampton Beach", "").replace("Village Of Westhampton Beach", "");
			 comName=comName.replace("Meadowbrook Pointe Gardens | East Meadow", "Meadowbrook Pointe Gardens");
			 comName=comName.replace("Oneck Landing | Westhampton Beach","Oneck Landing");
			 comName=comName.replace("The Vanderbilt | Westbury", "The Vanderbilt");
			 comName=comName.replace("The Selby | Westbury", "The Selby");
			 comName=comName.replace("The Latch | Southampton Village", "The Latch");
			 comName=comName.replace("Meadowbrook Pointe East Meadow","Meadowbrook Pointe");
			 comName=comName.replace("Marina Pointe East Rockaway", "Marina Pointe")
					 .replace("Country Pointe Estates<br> Westhampton Beach", "Country Pointe Estates");
			 comName=comName.replace("Oneck Landing<br>Village of Westhampton Beach","Oneck Landing");	
			 comName=comName.replace("Country Pointe Estates<br />Village of Westhampton Beach","Country Pointe Estates");
			 U.log("comName: "+comName);
//			if(comUrl.contains("/the-selby") || comUrl.contains("/latch"))return;//redirect
			if(comUrl.contains("/find/?id=8361") || comUrl.contains("null") || comUrl.contains("javascript"))return; //redirect
			 
					 
					 
			U.log("\n\nStarted Here:::::::::::::;; "+comUrl+" j = "+j);
			
			if (this.data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "------repeated-----");

				return;
			}
			
			LOGGER.AddCommunityUrl(comUrl);
			
			//comUrl = comUrl.replace(".com//", ".com/");
			String comHtml = U.getHTML(comUrl);
			
			
			comHtml = U.removeComments(comHtml);
			
			String[] MyStatusSec2=U.getValues(comHtml, "<h2 class=\"elementor-heading-title elementor-size-default\">","</h2>");	
			
			
			String nwStatSec=ALLOW_BLANK;
			for(String mstat:MyStatusSec2) {
				nwStatSec+=" "+mstat;
			}
			U.log("my stat sec2"+nwStatSec);
			
			String contactUrl=ALLOW_BLANK;
			String contactHtml=ALLOW_BLANK;
			String addSec;
			ArrayList <String> al=new ArrayList<>();
			String quick[]=U.getValues(quickHtml,"<h3 class=\"elementor-heading-title elementor-size-xl\">","<div class=\"elementor-button-wrapper\">");
//			for(String quickHome:quick) {
//				al.add(quickHome);
//			}
			//U.log("QUICK SIZE"+al.size());
			//-----------allHomesData----------
			String allHomesData = ALLOW_BLANK;
			String homeHtml=ALLOW_BLANK;
			String lifestyle=ALLOW_BLANK;
			 HashSet<String> set=new HashSet<String>(); 
			 HashSet<String> set2=new HashSet<String>(); 
			 String navUrl;
			 String floordata=ALLOW_BLANK;
			 String homesData=ALLOW_BLANK;
//			String navSec = U.getSectionValue(comHtml,"data-element_type=\"section\" id=\"od-menu\"","<span class=\"elementor-screen-only\">Menu</span>");
//			//String navSec[] = U.getValues(comHtml, "<li class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item", "\">");
//			if(navSec==null) {
//				navSec=U.getSectionValue(comInfo,"<nav class=\"elementor-nav-menu--dropdown elementor-nav-menu__container\" role=\"navigation\" aria-hidden=\"true\">","</nav>");
//			}
//			
//			
//			
//			
//			U.log(navSec);
//			if(navSec!=null)
			String[] navUrls=U.getValues(comHtml, "href=\"", "\"");
			//U.log("comHtml: "+comHtml);
			U.log("navUrl : "+navUrls.length);
			for(String Url:navUrls) {
				
				set.add(Url);
			}
			U.log("SIZE"+set.size());
					 
			Iterator<String> itr=set.iterator(); 
			 while(itr.hasNext()) {
				navUrl= itr.next();
				
				if(navUrl.contains("residences")||navUrl.contains("apartments")||navUrl.contains("/homes")||navUrl.contains("homes/")|| navUrl.contains("apartments")||
						navUrl.contains("condominium-collection")||navUrl.contains("villas")||navUrl.contains("/carriage-homes")){
					
//					U.log("HomenabvUrl"+navUrl);	
//					if(!navUrl.contains("https://beechwoodhomes.com"))
//					homeHtml += U.getHTML("https://beechwoodhomes.com"+navUrl);
//					else {
						homeHtml+= U.getHTML(navUrl);
						
						 HashSet<String>homes=new HashSet<String>();
						 
						 String homesUrl[]=U.getValues(homeHtml, "<a href=\"","\"");
						 for(String homeUrl:homesUrl) {
//							 U.log("homeUrl: "+homeUrl);
							 if(homeUrl.contains("residences/")||homeUrl.contains("model/")||homeUrl.contains("/homes")||homeUrl.contains("homesite"))
							 homes.add(homeUrl);
						 }
						 Iterator<String> itr2=homes.iterator();
						 while(itr2.hasNext()) {
							 String home=itr2.next();
							 U.log("floor Url :: "+home);
							 floordata = U.getHTML(home);
							//only homes data
							 if(home.contains("/homes")||home.contains("/homesite")) {
								 homesData += U.getHTML(home);
								 U.log("home Url :: "+home);
							// U.log("MMMMMMM "+Util.matchAll((homesData), "[\\s\\w\\W]{30}2 Levels[\\s\\w\\W]{30}", 0));
							 }
						 	}
						 }
				
					
				
				
				if(navUrl.contains("/lifestyle")||navUrl.contains("amenities")||navUrl.contains("the-clubhouse")){
					
  				U.log("lifestyle url"+ navUrl);
//					if(!homeUrl.contains("https://beechwoodhomes.com"))
//						lifestyle += U.getHTML("https://beechwoodhomes.com"+navUrl);
//					else
						lifestyle += U.getHTML(navUrl);
				//}
				}
				
				
				if(navUrl.contains("/contact")||navUrl.contains("/contact-us")) {
					U.log("CONTACT Url"+navUrl);
					contactUrl=navUrl;
					if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/"))
						contactUrl="https://www.beechwoodhomes.com/tidesnyc/contact/";
				 if(comUrl.contains("https://www.oakridgebeechwood.com"))
					 contactUrl="https://www.oakridgebeechwood.com/contact/";
					
//					if(contactUrl.contains(comUrl)) {
//					  contactHtml=U.getHTML(contactUrl);
//					  
//					}
//					else {
						//contactUrl=comUrl+contactUrl;
						contactHtml+=U.getHTML(contactUrl);
					//}
				}
				
				
			 }
			
                ///Price
			 String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			 String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			 String[] price= {ALLOW_BLANK,ALLOW_BLANK};
			 String lat= ALLOW_BLANK;
			 String lng= ALLOW_BLANK;
			 comHtml=comHtml.replace("$</sup>1.8mil", "$1,800,000").replace("<sup>$</sup>1.1mil", "$1,100,000").replace("0s", "0,000").replace("1million", "1,000,000").replace("4million", "4,000,000");
//			 U.log(comHtml.matches("Home Price: $5,749,000"));
			 homeHtml = (homeHtml).replace("Home Price: $7,500,000 to 9,900,000", "");
//			 U.log("LLLLL"+Util.matchAll(homeHtml, "[\\w\\W\\s]{50}1,815,000[\\w\\W\\s]{50}",0));
			 homeHtml=homeHtml.replace("Lower Corner Villa | ","Lower Corner Villa $");
			 U.log("LLLLL2"+Util.match(comHtml, "1,800,000"));
			
			 
			 price=U.getPrices((comHtml+homeHtml+floordata)
					 .replace("low $2 millions", "low $2,000,000")
					 .replace("Priced from the upper <sup>$</sup>1.1mil to <sup>$</sup>1.8mil</p>", "Priced from the upper $1,100,000 to $1,800,000"),"Home Price: \\$\\d{1},\\d{3},\\d{3}|Starting at \\$\\d{3}\\d{3}|Priced From: \\$\\d,\\d{3},\\d{3}|"
			 		+ "low \\$\\d,\\d{3},\\d{3}|Pricing Starting From: \\$\\d{6}|Starting from the low \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|Starting From <sup>\\$</sup>\\d{6}|Starting From <sup>\\$</sup>\\d{3},\\d{3}|STARTING FROM <SUP>\\$</SUP>\\d,\\d{3},\\d{3}</strong>|Starting at \\$\\d,\\d{3},\\d{3}|Priced from the upper \\$\\d,\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|Priced from the low \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|Priced from the low \\$\\d{3},\\d{3} to \\$\\d{3}\\d{3}|Leases starting from \\$\\d,\\d{3}|Home Price: \\$\\d,\\d{3}\\d{3}|"
			 		+"<strong>\\d{3},\\d{3}</strong>|Offered at \\d,\\d{3},\\d{3}|"
			 		+ "Priced From: \\$\\d{6}|Priced From: \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3} – \\$\\d,\\d{3},\\d{3}|Offered at \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d,\\d{3},\\d{3}", 0);
			 minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			 maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
 
			 U.log("Prices min  "+price[0]+" max  "+price[1]);
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+homeHtml+floordata, "[\\s\\w\\W]{30}Starting from the low[\\s\\w\\W]{30}", 0));
			 
			 //SQFT
			 String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			 U.log("ssss"+Util.match(homeHtml+comHtml,"4792 Sq. Ft."));
			 String sqftSec=ALLOW_BLANK;
				if(floordata!=null) {
					sqftSec=U.getSectionValue(floordata, "Upcoming Availiabilty</h2>", "HOME RESIDENCES FEATURES & FINISHES</h2>");
				}
			
			if(sqftSec!=null) {
				sqftSec=sqftSec.replaceAll("<p>(\\d,\\d{3})</p>", "low $1 sqft");
//				sqftSec=sqftSec.replaceAll("<p>(\\d{3})</p>", "low $1 sqft");
				sqftSec=sqftSec.replaceAll("<p>(\\d{3,4})</p>", "low $1 sqft");
				
				U.log("sqft sec :: "+sqftSec);
			}
			else {
				sqftSec=ALLOW_BLANK;
			}
			
			 String[] sqft=U.getSqareFeet((sqftSec+homeHtml+comHtml).replaceAll("1498", "1,498"),
					 "\\d,\\d{3} Square Feet|\\d{3} Square Feet|\\d{3} Sq. Ft.|\\d{4} – \\d{4} sq ft |from \\d,\\d{3} – \\d,\\d{3} sq. ft|The spacious \\d{4} – \\d{4} sq.ft.|\\d,\\d{3} Sq. Ft.|spacious \\d{4} – \\d{4} sq\\.ft|\\d{3} – \\d{3} Sq. Ft.|\\d{5}+ sf floorplans|"
			 		+ "\\d{4} Sq\\. Ft\\.|\\d{4} SQ\\. FT\\.|\\d{1},\\d{3} Sq Ft|\\d{4} Sq\\. Ft\\.|"
			 		+"at \\d,\\d{3}\\+ square feet|"
			 		+ "<div class=\"elementor-widget-container\">\\s+\\d,\\d{3}\\s+</div>|"
			 		+ "\\d,\\d{3} – over \\d,\\d{3} square feet|low \\d,\\d{3} sqft|low \\d{3} sqft|low \\d{4} sqft",0); //|\\d{3} Sq. Ft
			
			// String[] sqft = U.getSqareFeet((comHtml+homeHtml+floordata).replaceAll("<span class=\"no-decoration\">2,878 sq ft</span>", ""),
			//			"\\d,\\d{3} sq ft|>\\d,\\d+ sq ft</span>|\\d,\\d{3} sq.ft. Living|from \\d{3,}\\+ sq ft to \\d,\\d{3}\\+ sq ft|\\d,\\d{3}\\+ sq ft to \\d,\\d{3}\\+ sq ft.|align-middle living\">\\d{3}\\+</td>|align-middle living\">\\d,\\d{3}\\+</td>|Grand Total: <span><strong>\\d{4}|\\d+,\\d{3}	sq. ft.|Total Sq.Ft.<strong>\\d{4}|total\">\\d{4}|\\d{1},\\d{3} square feet|\\d{3,4} Sq. Ft|Total - \\d+,\\d{3} sq. ft|\\d,\\d{3} sq.ft|>\\d{3} sq.ft.|living\">\\d,\\d{3}|living\">\\d{3}|\\d{3} – \\d{3} Sq. Ft.",0);
			 
			 
			 
			 minSqf = (sqft[0] == null)? ALLOW_BLANK :sqft[0];
			 maxSqf = (sqft[1] == null)? ALLOW_BLANK :sqft[1];
//			 
			 U.log("SQFT "+sqft[0]+" "+sqft[1]);
			 
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(floordata+comHtml, "[\\s\\w\\W]{60}500[\\s\\w\\W]{50}", 0));
			 
			//// ------Property Status
			 String status=ALLOW_BLANK;
			 
			 comHtml = comHtml.replaceAll("JUNIPER RESTAURANTS - NOW OPEN|information on this limited opportunity", "")
					 .replaceAll(">More Info Coming Soon<", "");
			comInfo = comInfo.replaceAll(">More Info Coming Soon<", "");
					 
			String MyStatusSec=U.getSectionValue(comInfo, "<div class=\"elementor-ribbon-inner\">","</div>");	
			if(MyStatusSec != null) {
				MyStatusSec = MyStatusSec.replace("1 Home Remaining", "Only 1 Home Remaining");
			}
			U.log("my stat sec"+MyStatusSec);
			//String MyStatusSec2=ALLOW_BLANK;
			
			
			
			comHtml=comHtml.replace("JUNIPER RESTAURANT - NOW OPEN","");
			
			 status=U.getPropStatus(comInfo+comHtml+MyStatusSec+nwStatSec);
//			U.log("MMMMMMM "+Util.matchAll((comInfo+comHtml+MyStatusSec), "[\\s\\w\\W]{30}ONLY 1 HOME REMAINING[\\s\\w\\W]{30}", 0));
			 
			 Iterator<String> iter = set2.iterator();
			 for(String quickHome:quick) {
				 set2.add(quickHome);
				 //U.log(quickHome);
				 }
			 U.log("total"+set2.size());
			// while(iter.hasNext()) {
			 for(String setid:set2) {
				// U.log("inside"+iter.next());
				// U.log("inside"+setid);
				 if(setid.contains(comName)) {
					 if(!status.contains("Quick Move-in Homes"))
					 status="Quick Move-in Homes";
					// U.log("XX");
				 }else {
					 status=U.getPropStatus(comHtml);
				 }
			 }
			 //status=status+", "+U.getPropStatus(comInfo+comHtml);
			 
			 
//			 status = status.replace("1 Home Remaining", "Only 1 Home Remaining");
			 
			 U.log("prop Status: "+status);
			// if(comUrl.contains("https://beechwoodhomes.com/the-selby/"))status="Coming Soon";//from Image
			 
			 //commType
			//comHtml=comHtml.replace("A 62+ ACTIVE ADULT COMMUNITY","62+ Community");
			String comType=ALLOW_BLANK;
			comHtml=comHtml.replace("Waterfront or Water View","waterfront community");
			U.log("PPP"+Util.match(comHtml, "A 62+ ACTIVE ADULT COMMUNITY"));
			
			comType= U.getCommType(comHtml+comInfo+lifestyle);
			
			U.log("community type"+comType);
			
			if(comUrl.contains("/meadowbrook-pointe-east-meadow/"))
				comType="62+ Community";
				
				
				//	U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+lifestyle), "[\\s\\w\\W]{30}ACTIVE ADULT[\\s\\w\\W]{30}", 0));
			/*
			 * if(comUrl.contains(
			 * "https://www.beechwoodhomes.com/meadowbrook-pointe-east-meadow/"))
			 * comType="62+ Community, Resort";
			 */
			 //propTypen& derved			
			String propType = ALLOW_BLANK;
			String dType = ALLOW_BLANK;
//			 U.log("HHH"+Util.matchAll(comHtml+comInfo+homeHtml+floordata,"[\\w\\W\\s]{100}Homeowners Association[\\w\\W\\s]{100}",0));
			propType = U.getPropType((comHtml+comInfo+homeHtml+floordata)
					.replaceAll("unparalleled luxury|Modern luxury", "luxury homes")
					.replaceAll("Village|village|%7CCabin%3A100%|craftsmanship|Townhouses|Townhouse-8-kitchen|homeowners association includes|This is a homeowners association and|membership in the homeowners asso", ""));
			
			
			U.log("propType::" + propType);
			
//			if(comUrl.contains("https://www.oakridgebeechwood.com/"))
//			 propType="Single Family";
			if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/"))propType="Apartment Homes, Patio Homes";
//			U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+homeHtml+floordata), "[\\s\\w\\W]{30}luxury[\\s\\w\\W]{30}", 0));
			
			comHtml = comHtml.replaceAll("second floor primary suites", "");
			homesData = homesData.replace(" | 2 Levels | ", " | two story | ").replace(" | 1 Levels | ", " | one story | ").replaceAll("first &amp", "first floor")
					.replace("3 Levels", "three story")
				;
			
//			U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+homeHtml+floordata+homesData), "[\\s\\w\\W]{30}Level[\\s\\w\\W]{30}", 0));
			dType=U.getdCommType((comHtml+comInfo+homeHtml+floordata+homesData).replace("branch", "").replace("2 Levels", "two story").replace("1 Levels", "one story"));
            U.log("Derived prop tyupr"+dType);
 //           U.log("MMMMMMM "+Util.matchAll((comHtml+comInfo+homeHtml+floordata+homesData), "[\\s\\w\\W]{30}level[\\s\\w\\W]{30}", 0));
            
            //Address
            String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
            String geo = "FALSE";
            String note=ALLOW_BLANK;
            
            String latLng[]= {ALLOW_BLANK,ALLOW_BLANK};
            addSec=Util.match(contactHtml,"href=\"https://goo.gl/maps.*</a>");
            comHtml=comHtml.replace("New York","NY");
			 U.log("Addsec"+addSec);
			 
//			 U.log("MMMMMMM "+Util.matchAll((contactHtml), "[\\s\\w\\W]{30}5 Atlantic Avenue East[\\s\\w\\W]{80}", 0));
			 
			
			 
			 if(addSec!=null) {
			 addSec = U.getNoHtml(addSec.replaceAll("\\.|\\s+\\,|<br>|<span class=\"nowrap\">", ",")).replaceAll(".*>", "");
			 addSec=addSec.replaceAll("\\s+\\,","");
			 addSec=addSec.replace("190 Beach 69th Street  Arverne, NY 11692   888 500 5480 ", "190 Beach 69th Street, Arverne, NY 11692");
			 addSec=addSec.replace("New York","NY");
			// addSec=addSec.replace(",,", ",");
			 U.log("NEW ADD SEC"+addSec);
			 add=U.getAddress(addSec);
			 U.log("Address"+Arrays.toString(add));
			 
			 }else {
				String addSection=U.getSectionValue(contactHtml, "<div class=\"elementor-custom-embed\">", "aria-label=");
				
				 if(addSection == null && comName.contains("The Vanderbilt")) {
					String addSectionHere =  U.getSectionValue(contactHtml, "EJtARmMgYS82\"", "</h2>");
					 U.log("From here: "+addSectionHere);
					 add[0] = U.getSectionValue(addSectionHere, ">", "<br>");
					 String sec = U.getSectionValue(addSectionHere, "<br>", "</a>");
					 sec = sec.replace("New York", "NY,");
					 String[] split = sec.split(",");
					 add[1] = split[0];
					 add[2] = split[1];
					 add[3] = split[2];
					 
					 U.log("ADDRESS INSIDE: "+Arrays.toString(add));
				 }
				 if(comName.equals("The Selby")) {
						String addSectionHere =  U.getSectionValue(contactHtml, "Address</strong>", "<strong>");//..</p>
						addSectionHere = addSectionHere.replace("New York", "NY,");
						 U.log("From here: "+addSectionHere);
						 String[] split = addSectionHere.split(",");
						 add[0] = split[0];
						 add[1] = split[1];
						 add[2] = split[2];
						 add[3] = split[3];
//						 
//						 add[1]="Westbury";
//						 add[2]="NY";
//						 latLng=U.getlatlongGoogleApi(add);
//						 if(latLng==null) {
//							 latLng=U.getlatlongHereApi(add);
//						 }
//							add=U.getAddressGoogleApi(latLng);
//							lat=latLng[0];
//							lng=latLng[1];
//							geo="TRUE";
//							note="Address is taken from city and state"	;
						 
						 U.log("ADDRESS: "+Arrays.toString(add));
					 }
				
				if(addSection!=null) {
				addSection = addSection.replace("123 Merrick Avenue East Meadow, New York 11554", "123 Merrick Avenue, East Meadow, NY 11554").replace("845 East Meadow Avenue East Meadow, New York 11554", "845 East Meadow Avenue, East Meadow, NY 11554");	
				addSec=U.getSectionValue(addSection, "title=\"","\"");
				add=U.getAddress(addSec);
				U.log("LL"+addSection);
				
				}else {
					addSec=U.getSectionValue(comHtml,"<h2 class=\"h3\">Address</h2><p>","</p><section");
					if(addSec!=null) {
						add=U.getAddress(addSec);
					U.log("MM"+addSec);
					}
				}
				
				//else
//				{
//				 addSection=U.getSectionValue(contactHtml, "<a href=\"https://beechwoodhomes.com/latch/contact\">", "</span></a></p");
//				 addSec=addSec.replace(" <span class=\"nowrap\">", "");
//				 addSec=addSec.replace("101 Hill Street", "101 Hill Street,");
//				 add=U.getAddress(addSec);
//				U.log("JJJ");
//				}
//				String latLngSec=U.getSectionValue(contactHtml, "", To)
				
				if(addSection==null || addSection==ALLOW_BLANK)// added in june
				{
					addSection=U.getSectionValue(contactHtml, "<i aria-hidden=\"true\" class=\"fas fa-warehouse\">", "</li>");
					if(addSection!=null) {
					U.log("New Add Sec:== "+addSection);
					addSection=addSection.replace("<br>", ",");
					addSection=U.getNoHtml(addSection).trim();
					U.log("New Add Sec After removing html:== "+addSection);
					add=U.getAddress(addSection);
					U.log("oak add"+Arrays.toString(add));
					}
					else {
						addSection=U.getSectionValue(contactHtml, "<p class=\"p1\">", "</span></a></p>");
						if(addSection!=null) {
							addSection=addSection.replace(" <span class=\"nowrap\">", ", ");
							addSection=U.getNoHtml(addSection).trim();
							add=U.getAddress(addSection);
							U.log("E meadow add"+Arrays.toString(add));
						}
						else {
							addSection=U.getSectionValue(contactHtml, "<div class=\"elementor-element elementor-element-8d43a28 elementor-widget", "</a></p>");
							if(addSection!=null) {
								addSection=addSection.replace(" <span class=\"nowrap\">", ", ");
//							addSection=U.getNoHtml(addSection).trim();
							
							addSection=U.getSectionValue(addSection, "<div class=\"elementor-widget-container\">", "</span>");
							addSection=U.getNoHtml(addSection).replace("101 Hill Street, Southampton, New York 11968", "101 Hill Street, Southampton, NY 11968").trim();
							U.log("New Add Sec After removing html:== "+addSection);
							add=U.getAddress(addSection);
							U.log("latch add"+Arrays.toString(add));
							}
						}
					}
				
				
				}
			 }
			 
			 /*
			  * Lat-Lng is getting at iFrame Html
			  */
			 if(comUrl.equals("https://www.beechwoodhomes.com/country-pointe-estates-westhampton/")) {
				 String section = U.getSectionValue(comHtml, "<iframe loading", "</iframe>");
				 U.log("section: "+section);
				 String frameUrl = U.getSectionValue(section, "data-lazy-src=\"", "\"");
				 if(frameUrl != null) frameUrl = frameUrl.replace("amp;", "");
				 U.log("frameUrl: "+frameUrl);
				 String frameData = U.getHTML(frameUrl); 
//				 FileUtil.writeAllText("/home/shatam-10/Desktop/data/frame.txt", frameData);
//				 U.log("MMMMMMM "+Util.matchAll((frameData), "[\\s\\w\\W]{30}86 Depot Rd[\\s\\w\\W]{80}", 0));
				 
				 String latlngSec = U.getSectionValue(frameData, "[[null,[", "]],");
				 U.log("latlngSec ::"+latlngSec);
				 if(latlngSec != null && latlngSec.contains(","))
					 latLng = latlngSec.split(",");
				 
				 if(latLng[0] != null) {
					 add=U.getAddressGoogleApi(latLng);
					lat=latLng[0];
					lng=latLng[1];
					geo="TRUE";
				 }
			 }
			 
			 if(comUrl.contains("https://www.beechwoodhomes.com//oneck-landing-westhampton")) {
				 add[1]="Westhampton";
				 add[2]="NY";
				 latLng=U.getlatlongGoogleApi(add);
				 if(latLng==null) {
					 latLng=U.getlatlongHereApi(add);
				 }
					add=U.getAddressGoogleApi(latLng);
					lat=latLng[0];
					lng=latLng[1];
					geo="TRUE";
					note="Address is taken from city and state"	;
			 }
			 if(comUrl.contains("https://www.beechwoodcarolinas.com/weddington-glen/")) {
				 String addSection=U.getSectionValue(contactHtml, "<b>WEDDINGTON GLEN SALES OFFICE</b>", "<BR><BR><B>Sales Office Number:");
				 addSection=addSection.replace(" <br>", ", ");
				 addSection=U.getNoHtml(addSection);
				 add=U.getAddress(addSection);
			 }
			 if(comUrl.contains("https://www.beechwoodcarolinas.com/broadmoor/")) {
				 String addSection=U.getSectionValue(contactHtml, "<b>BROADMOOR SALES OFFICE</b>", "<br><br><b>Sales Office Number:");
				 addSection=addSection.replace(" <br>", ", ");
				 addSection=U.getNoHtml(addSection);
				 add=U.getAddress(addSection);
			 }
			 
			 //july below
			 if(comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-gardens-east-meadow/")||comUrl.contains("https://www.beechwoodhomes.com/marina-pointe/")||comUrl.contains("https://www.beechwoodhomes.com/meadowbrook-pointe-east-meadow/")||comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/")) {
				 String frameUrlSec=U.getSectionValue(contactHtml, "<iframe loading=", "</iframe>");
				 String frameUrl=U.getSectionValue(frameUrlSec, "data-lazy-src=\"", "\">");
				 String frameData=U.getHTML(frameUrl);
//				 U.log("MMMMMMMMMMMMMMMMMMMM  "+U.getCache(frameUrl));
				 String latlngSec=U.getSectionValue(frameData, "https://maps.google.com/maps/api/staticmap?center", "zoom=");
				 lat=U.getSectionValue(latlngSec, "=", "%2C");
				 lng=U.getSectionValue(latlngSec, "%2C", "&amp;");
			 }
			 
			 
			 

				
				if(comUrl.contains("https://www.beechwoodcarolinas.com/")) {
	
					String latlngSec=U.getSectionValue(comHtml, "https://maps.google.com/maps?q=", "\">"); 
//					U.log("fffff "+latlngSec);
					if(latlngSec!=null) {
						latLng[0]=U.getSectionValue(latlngSec, "title=\"", ",");
						latLng[1]=U.getSectionValue(latlngSec, ",", "\"");
						
//						add=U.getAddressGoogleApi(latLng);
//						geo="TRUE";
					}
					lat=latLng[0].trim();
					lng=latLng[1].trim();
					
					U.log("beechwoodcarolinas latLng"+Arrays.toString(latLng));
					
					
					
					
					
					
					
					if(comUrl.contains("https://www.beechwoodcarolinas.com/lakeside-pointe/")||comUrl.contains("https://www.beechwoodcarolinas.com/ferncliff")) {  //
				/*	    latlngSec=U.getSectionValue(comHtml, "https://maps.google.com/maps?q=", "\">"); 
					U.log("fffff "+latlngSec);
					if(latlngSec!=null) {
						latLng[0]=U.getSectionValue(latlngSec, "title=\"", ",");
						latLng[1]=U.getSectionValue(latlngSec, ",", "\"");
						
						add=U.getAddressGoogleApi(latLng);
						geo="TRUE";
					}
					lat=latLng[0].trim();
					lng=latLng[1].trim();
					U.log("inner latlng= "+Arrays.toString(latLng));*///june
//						add=U.getAddressGoogleApi(latLng);
//						geo="TRUE";//june
					String addUrl=U.getSectionValue(comHtml, "src=\"https://maps.google.com/", "\"");
					addUrl="https://maps.google.com/"+addUrl;
					U.log("addUrl "+addUrl);
					String addHtml=U.getHTML(addUrl);
					addHtml=U.getNoHtml(addHtml);
//					FileWriter fw= new FileWriter("/home/shatam/Cache/beechwoodFile");
//                    fw.write(addHtml.replace("null,", ""));
                    addHtml=addHtml.replace("null,", "");
					U.log("addhtml cache"+U.getCache(addUrl));
//					-U.log("addhtml: "+addHtml);
					String addLine=U.getSectionValue(addHtml, "[[[1,0]],1,0,0]],\\\"", ", USA\\\"");
					if(addLine!=null)
					   add=U.getAddress(addLine);
					else {
						add=U.getAddressGoogleApi(latLng);
						geo="True";
					}
					U.log("Address:  "+Arrays.toString(add));
					}
				}
				
			
			 if((lat==ALLOW_BLANK||lng==ALLOW_BLANK) && (addSec!=null || add[0] != ALLOW_BLANK)) { 
				 latLng=U.getlatlongGoogleApi(add); 
				 geo="TRUE"; 
				 lat=latLng[0];
				 lng=latLng[1]; 
//				 U.log("NNNNNNNNNNNNN");
			 }
			 
				add[0]=add[0].replace("The Vanderbilt 990 Corporate Dr","990 Corporate Dr");
				add[0]=add[0].replace("The Tides at Arverne by the Sea 190 Beach 69th St","190 Beach 69th St");
				add[0]=add[0].replace("1 Charles B Wang Blvd,","1 Charles B Wang Blvd").trim();
				add[0]=add[0].replace("298 Silver Timber Drive ,", "298 Silver Timber Drive").trim();
				
//				if(comUrl.contains("https://www.oakridgebeechwood.com/")) {
//					minPrice="$975000";
//					maxSqf="5000";
//				}
					
//				if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/")) {
//					add[0]="190 Beach 69th Street";
//					add[1]="Queens";
//					add[2]="NY";
//					add[3]="11692";
//				}
//				
				if(comUrl.contains("https://www.beechwoodcarolinas.com/ferncliff"))propType="Single Family, Custom Home, Townhome, Estate-Style Homes, Craftsman Style Homes, Multi-Family, Luxury Homes";
				if(comUrl.contains("https://www.beechwoodhomes.com/country-pointe-estates-westhampton/"))dType="1 Story, 2 Story";
//				if(comUrl.contains("https://www.beechwoodhomes.com/vanderbiltli/")) {minSqf="904";maxSqf="1438";}
                if(comUrl.contains("oneck-landing-westhampton")){minSqf="5737";}//Frm Image 
                if(comUrl.contains("https://www.oakridgebeechwood.com/"))status=ALLOW_BLANK; //only cmhg soon
				if(comUrl.contains("https://www.beechwoodhomes.com/marina-pointe/")){minSqf="1698";maxSqf=ALLOW_BLANK;}
				
				
				//				if(add[0]==null||add[0]==ALLOW_BLANK) {
//					add=U.getAddressGoogleApi(latLng);
//					if(add[0]==null||add[0]==ALLOW_BLANK) {
//						add=U.getAddressHereApi(latLng);
//					}
//				}
				comHtml = comHtml.replace("now pre leasing","now pre-leasing");
				
				note=U.getnote(comInfo+comHtml.replaceAll("Lot For Sale: ", ""));
//				if(comUrl.contains("https://www.beechwoodhomes.com/tidesnyc/"))
//				 note="Building 2 is Now Leasing";
//				U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}Now Pre Leasing[\\s\\w\\W]{30}", 0));
			
				
				String units=ALLOW_BLANK;
				int count=0;
				if(comHtml.contains("VIEW SITEPLAN</span>")) {
					String siteUrl=comUrl+"/siteplan/";
					String mapData=U.getHtml(siteUrl, driver);
					if(mapData!=null) {
						String iframeUrl=U.getSectionValue(mapData, "class=\"Phases\" src=\"", "\"");
						if(iframeUrl!=null) {
							String dataSe=U.getHtml(iframeUrl, driver);
							U.log("Done");
							String[] lotCount=U.getValues(dataSe, "<path d=\"", "\"");
							count=lotCount.length;
							U.log(count);
						}
					}
				}
				
				if(count!=0) {
					units=String.valueOf(count);
				}
				
//				String lotSection=U.getSectionValue(comHtml, "", To)
				
				U.log("m add"+Arrays.toString(add));
			
				data.addCommunity(comName.replace("<br />", " "), comUrl.replace(".com//", ".com/"),comType);
				data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),add[3].trim());
				data.addLatitudeLongitude(lat, lng, geo);
				data.addNotes(note);
				data.addPrice(minPrice,maxPrice);
				data.addPropertyStatus(status);
				data.addPropertyType(propType, dType);
				data.addSquareFeet(minSqf,maxSqf);
				data.addConstructionInformation(ALLOW_BLANK,ALLOW_BLANK);
				data.addUnitCount(units);
		}
		j++;
	}

	static String commUrl = ALLOW_BLANK;

	public static String getBuilderObj(List<String> newCsvRow) {
		// U.log("Hello1");
		if (commUrl.contains(newCsvRow.get(1).trim())) {

			return (newCsvRow.get(2) + "," + newCsvRow.get(3) + ","
					+ newCsvRow.get(4) + "," + newCsvRow.get(5) + ","
					+ newCsvRow.get(6) + "," + newCsvRow.get(7) + ","
					+ newCsvRow.get(8) + "," + newCsvRow.get(9) + "," + newCsvRow
						.get(13)

			);
		}
		return null;

	}

	public static String getHardcodedAddress(String comUrl) throws Exception {
		commUrl = comUrl.trim();
		String newFile = System.getProperty("user.home")+"/Harcoded Builders/"+ "Hardcode_BeechwoodOrganization" + ".csv";
		// U.log("Suucess=============");
		CsvListReader newFileReader = new CsvListReader(new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {

				String aaa = getBuilderObj(newCsvRow);

				if (aaa != null)
					return aaa;
			}
			count++;
		}

		newFileReader.close();
		return null;
	}
}