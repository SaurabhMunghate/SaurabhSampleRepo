/**
 * Modified By: Priti(27 Nov 2018).
@author Parag Humane 
 * @date 7/5/2012
 * 
 */
package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBillClarkHomes extends AbstractScrapper {
	private static final String BUILDER_NAME = "Bill Clark Homes";
	static int duplicates;
	int i = 0;
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static int count = 0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractBillClarkHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Bill Clark Homes.csv", a.data().printAll());
	}

	public ExtractBillClarkHomes() throws Exception {

		super("Bill Clark Homes", "https://www.billclarkhomes.com/");
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	WebDriver driver = null;
	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		// Your code here
		String mainhtml = U.getHtml("https://www.billclarkhomes.com/", driver);

		String regUrl[]=U.getValues(mainhtml, "\"AreaCard_wrapper\"", "\"AreaCard_name\"");
		
		for(String rurl:regUrl) {
		//	U.log(rurl);
			String regurl="https://www.billclarkhomes.com"+U.getSectionValue(rurl, "href=\"", "\"");
			String regHtml=U.getHtml(regurl,driver);
			U.log(U.getCache(regurl));
			String comSections[]=U.getValues(regHtml, "CommResults_listItem", "View Details");
			U.log(comSections.length);
			for(String comS:comSections) {
				String urlSec=U.getSectionValue(comS, "href=\"/communities", "\"");
				if(urlSec==null) {
					urlSec=U.getSectionValue(comS, "<a href=\"", "\"");
					String comurl=urlSec;
					String html=U.getHtml(comurl, driver);
					
					addDetails(html, comurl);
				}
				else {
			String comurl="https://www.billclarkhomes.com/communities"+urlSec;
			String html=U.getHtml(comurl, driver);
			
			addDetails(html, comurl);
				}
				
		
			
			
			
			
			}
			
		}

		try{driver.quit();}catch (Exception e) {}
		U.log("duplicates--> " + duplicates);
		LOGGER.DisposeLogger();
	}

	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					
//					if(driver.findElement(ByXPath.xpath("//*[@id=\"root\"]/div/div/div/div[3]/div[6]/div/div[3]/div/div/div[2]/span")) != null)
//						driver.findElement(ByXPath.xpath("//*[@id=\"root\"]/div/div/div/div[3]/div[6]/div/div[3]/div/div/div[2]/span")).click();
					
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); 
					
					Thread.sleep(5000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

	private void addDetails(String html, String url) throws Exception {
//		try
//		if(j>=20)
		{
			//TODO:
//	  if(!url.contains("https://www.billclarkhomes.com/communities/wilmington/hanover-lakes")) return;

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(":::::::::::::Repeated::::::::::::::" + url);
				return;
			}

			/*
			 * * if (url.contains(".com/available-homes") ||
			 * url.contains("find-my-home/available-homes")) {
			 * LOGGER.AddCommunityUrl(":::::::::::::Avaiable Home Url Return::::::::::::::"
			 * + url); return; }
			 */
			LOGGER.AddCommunityUrl(url);

			 U.log(U.getCache(url));
//			 String html = U.getHTML(url);
			U.log(j + "\tCOM URL :: " + url);
			// CommName
			// String name1 =U.getSectionValue(html,"<h4>", "</h4>");
			// U.log(html);
			html=html.replaceAll("data-reactid=\"\\d{3}\">", "");
			String commName = U.getSectionValue(html, "<h1 class=\"TitleOverlay_titleHeading\"", "</h1>");
			
			if(commName != null) commName = commName.trim().replaceAll(" \\| COMING SOON$", "");
			U.log("CommName :" + commName);
			
        html=html.replaceAll("<p data-reactid=\"654\"|data-reactid=\"760\">|data-reactid=\"790\">", "");
            String commtypesection=ALLOW_BLANK;
            commtypesection = U.getSectionValue(html, "<script data-react-helmet=\"true\"",
					"</head><body><noscript>");
            if(commtypesection==null) {
            	commtypesection=U.getSectionValue(html,"<script data-react-helmet=\"true\"","}");
            	U.log("KKKK"+commtypesection);
            }
            String commdesc="";
            if(commtypesection!=null) {
			 commdesc = U.getSectionValue(commtypesection, "\"description\":", "\",\"address\"");
            }
			
			// --------Address & LatLong-----------
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			String note = ALLOW_BLANK;
			String geo = "FALSE";

			/*
			 * String mapUrl =
			 * U.getSectionValue(html,"<div class=\"direction_img","</div>");
			 * mapUrl=U.getSectionValue(mapUrl, "href=\"", "\"");
			 * U.log("map uRl ::: "+mapUrl);
			 * //U.log(U.getCache("http://www.billclarkhomes.com" + mapUrl)); String maphtml
			 * = U.getHTML(mapUrl);
			 */
			String addresssection = U.getSectionValue(html, "<span class=\"DetailInformation_communityLocation_streetName\"",
					"</h5></div><div");
			U.log("addresssection==="+addresssection);
			if(addresssection==null) {
				addresssection = U.getSectionValue(html, "<span class=\"DetailInformation_communityLocation_streetName\"",
						"</h5></div><div");
			}
			
			if(addresssection!=null) {
				addresssection=U.getNoHtml(addresssection);
			addresssection=addresssection.trim().replaceAll("   &nbsp;   ", ", ")
					.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->", "");
			U.log("addresssection==="+addresssection);
			add=U.getAddress(addresssection);
			}
//			else {
//				addresssection = U.getSectionValue(html, "<span class=\"DetailInformation_communityLocation_streetName\"","</h5></div><div");
//				addresssection=addresssection.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->", "")
//						.replace(" &nbsp;</span>", ",");
//				U.log("addresssection-2==="+addresssection);
//				add=addresssection.trim().split(",");
//			}
			if(url.contains("communities/greenville/the-villages-at-langston-farms")) {
				add[0]="Rounding Bend Dr";
				add[1]="Winterville";
				add[2]="NC";
				add[3]=ALLOW_BLANK;
			}
			

			U.log(Arrays.toString(add));

			String latLongSec = U.getSectionValue(html, "<li class=\"HeaderButtons_listItem MapPin_btn\"",
					"<img class=\"MapPin_btnIcon\"");
			U.log("::::::::" + latLongSec);
			if(latLongSec!=null) {
			String latLongsec1 = U.getSectionValue(latLongSec, "<a href=\"https://www.google.com/maps/place/", "/");
			U.log(latLongsec1);
			latLong = latLongsec1.split(",");
			}

			U.log("latLong : " + Arrays.toString(latLong));
			
			U.log("add----- : " + add[0]+"  "+add[1]+ "  "+add[2]);
			U.log("add----- : " + add[3].length());
			if(add[0]!=null && add[1]!=null && (add[3]==ALLOW_BLANK )|| add[3]==null) {
				add[3]=U.getAddressGoogleApi(latLong)[3];
				geo = "TRUE";
			}
			

			if(add[0]==ALLOW_BLANK|add[1]==ALLOW_BLANK||add[2]==ALLOW_BLANK||add[3]==ALLOW_BLANK)
			{
				add=U.getAddressGoogleApi(latLong);
//				if(add == null) add = U.getAddressHereApi(latLong);
				geo="TRUE";
			}
			if(latLong[0].length()<4||latLong[1].length()<4){

				latLong=U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				geo="TRUE";
			}
			U.log("ADDRESS:::::::"+Arrays.toString(add));
			// =========================prices=====================================

			String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;

			String pricesection = U.getSectionValue(html, "<div class=\"BodySection_priceRange my-2\"",
					"<div class=\"BodySection_priceRange");
//			U.log(commdesc);
			String pricesection1[] = U.getValues(html, "<div class=\"PlanCard_InformationSection\"",
					"View Details</span>");
			//U.log(pricesection1);\
			String homesec=null;
			for(String homep:pricesection1) {
			homesec += homep.replaceAll("</span><span class=\"Card_label\" data-reactid=\"661\">| <!-- /react-text --><!-- react-text: \\d{4} -->|data-reactid=\"\\d{4}\">", "");	
			}
			String availhomesec[]=U.getValues(html, "<div class=\"HomeCard_StatusBox\" ", "View Details</span>");
			String availhomsec=null;
			for(String avh:availhomesec) {
				availhomsec +=avh;	
				}
			String incudedfe=U.getSectionValue(html, "Included Features</h", "</li></ul>");
			

			//low to upper $300s.
			prices = U.getPrices((pricesection + pricesection1+homesec+availhomsec+incudedfe+commdesc)
					.replaceAll("s|'s|’s", ",000"), "tart in the low \\d{3},\\d{3}|the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|start in the mid \\$\\d{3},\\d{3}|Homes starting in the \\$\\d{3},\\d{3}|start in the \\$\\d{3},\\d{3}|low to mid \\$\\d{3},\\d{3}|low to upper \\$\\d{3},\\d{3}|to upper \\$\\d{3},\\d{3}|start in the \\$\\d{3},\\d{3}|low to mid \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|", 0);
			minPrice = prices[0];
			maxPrice = prices[1];

			U.log(Arrays.toString(prices));
			
			// =============================sqft=============================================

			String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
			String minSqft = ALLOW_BLANK;
			String maxSqft = ALLOW_BLANK;

			String sqftsection = U.getSectionValue(html, "<img src=\"/images/icons/icon-sqft.svg\"",
					"<img src=\"/images/icons/icon-beds.svg\"");
			
			
			if(sqftsection!=null)
				sqftsection = sqftsection.replaceAll("<!-- react-text: \\d+ -->", "");
				
			
			String sqftsection1 = U.getSectionValue(html, "<span class=\"Card_numericalValue\"",
					"<div class=\"Visit_buttonWrapper\"");
			
			if(sqftsection1!=null)
				sqftsection1 = sqftsection1.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->|</span><span class=\"Card_label\"", "");
//			U.log(sqftsection1);
			if(availhomsec!=null)
			availhomsec=availhomsec.replaceAll("</span><span class=\"HomeCard_label center\" Sq. Ft.", " Sq. Ft.");
			
			sqft = U.getSqareFeet((sqftsection + sqftsection1+incudedfe+homesec+availhomsec+commdesc), "\\d,\\d{3} Sq. Ft.|\\d{4} - \\d{4}  Sq\\. Ft|\\d,\\d{3} - \\d,\\d{3}</b> Sq\\. Ft|>\\d{1},\\d{3}</b>|\\d{4}Sq. Ft|ranging from \\d{1},\\d{3}|to \\d{1},\\d{3} square|range from \\d{1},\\d{3} |to \\d{1},\\d{3} square|– \\d{1},\\d{3} sq. ft|\\d{1},\\d{3} |- \\d{1},\\d{3}|measuring up to \\d{1},\\d{3} square|\\d,\\d{3} square feet", 0);
			

			minSqft = sqft[0];
			maxSqft = sqft[1];
			if(url.contains("https://www.billclarkhomes.com/communities/wilmington/the-villas-at-sunset-ridge"))maxSqft="2219";

			U.log(Arrays.toString(sqft));
			

			// ==============================commtype==========================================
			

			String commtype = U.getCommType((commdesc+incudedfe).replace("Golf Cart Friendly Community", "Golf Course Cart Friendly Community"));
			U.log(commtype);
			
			

			// =======================proptype=================================

			// floor plans and comm page ,region hoga toh

			// String regPageurls=U.getSectionValue(, , );
			// String reghtml=null;
			String proptype = null;
			String planh = null;
			String avahtml = null;
			String availhtml = U.getHTML(url + "#available");
			String avahtml1=null;
			String avahomes1=null;
String avahomes=U.getHTML(url+"#home-plans");
			String availurl[] = U.getValues(availhtml, "<a class=\"HomeCard_imageWrapper\"", "data-reactid=\"");

			String avahomesurl[]=U.getValues(avahomes, "<a class=\"Card_btn Card_visit\"", " data-reactid=\"");
			String ahprices=null;
			for(String ah:avahomesurl) {
				String planurls1[] = U.getValues(ah, "href=\"", "\"");
				for (String ph : planurls1) {
					String avaurl;
					if(url.contains("legacy")) 
						avaurl = "https://legacyhomesbybillclark.com" + ph;
					else
						avaurl = "https://billclarkhomes.com" + ph;
					
					avahtml1 = U.getHTML(avaurl);
					
ahprices=U.getSectionValue(avahtml1, " alt=\"Price Starting From\" ", "</div><div");
avahomes1=U.getSectionValue(avahtml1, "<span class=\"Card_numericalValue\"", "</span><span");
				
					
				}
			}
			for (String av : availurl) {
				String planurls[] = U.getValues(av, "href=\"", "\"");
				for (String pu : planurls) {
					String avaurl = "https://billclarkhomes.com" + pu;
					avahtml = U.getHTML(avaurl);

				}
			}
			String availhomesqft=null;
			String neighsec=null;
			String avsec = null;
			
			
			if (avahtml != null) {
				avsec = U.getSectionValue(avahtml, ">Home Description</h3>", "</div></div></div>");
			availhomesqft=U.getSectionValue(avahtml, "src=\"/images/icons/icon-sqft.svg\"", "</div><div class=\"BodySection_communityType mr-4 mb-3\"");
			neighsec=U.getSectionValue(avahtml, "<div class=\"Accordion_content\"","</li><li>Double Car Garages");
						}
			// https://billclarkhomes.com/communities/greenville/langston-west#available

			commdesc = commdesc.replace("Homes here are characterized by spacious open layouts, luxurious owner suites", "Homes here are characterized by spacious open layouts, luxury homes owner suites")
					.replace("traditional to the more modern New American", "traditional architecture").replace("designed in the craftsman style", "Craftsman style details");
			proptype = U.getPropType((commdesc + avsec + incudedfe)
					.replace("courtyard entry garages", "")
					.replace("The estates will sit on larger homesites where garages face", "The Estate Residences will sit on larger homesites where garages face")
					.replace("intercoastal access", "coastal lifestyle")
					.replaceAll("Coastal Carolinas|coastal and active lifestyle", "Coastal Homes")
					.replace("to the Villas Town", "").replace("Homestead Estate", "Estate Residences").replace("Luxury Finishes Throughout Homes", "Luxury homes Finishes Throughout Homes"));
			
//			U.log("MATCH===="+Util.matchAll(commdesc + avsec + incudedfe, "[\\w\\s\\W]{100}The estates will sit on larger[\\w\\s\\W]{100}", 0));

			
			U.log("proptype::::::: "+proptype);

			
			
			
			String pstatus = ALLOW_BLANK;

			String dtype = ALLOW_BLANK;
			String storysec=null;
			// ==========================dtype==========================
			String planhtml = U.getHTML(url + "#home-plans");
//			 U.log(">>>>>>>>>>>>>"+url + "#home-plans");
			String[] floorplans = U.getValues(planhtml, "<a class=\"PlanCard_imageWrapper\"",
					"View Details</span>");
//			 U.log("KKKKKK"+floorplans.length);
			String plandesc = null;
//			if (floorplans != null) {
//				String planurls[] = U.getValues(floorplans, "href=\"", "\" data-reactid=\"");
//				 U.log("planurls.length===="+planurls.length);

				for (String p : floorplans) {
					
					String planu ;
					String planUrl=U.getSectionValue(p, "href=\"", "\""); 
					
					if(url.contains("legacy")) 
						planu = "https://legacyhomesbybillclark.com" + planUrl;
					else
						planu = "https://billclarkhomes.com" + planUrl;
					
					planh = U.getHTML(planu);
                storysec =storysec+ U.getSectionValue(planh, "src=\"/images/icons/icon-stories.svg\"", "</li><li ");

				}
				
				if (planh != null)
					try {
						plandesc = U.getSectionValue(planh, "<b class=\"d-block\"", "Stories<!-- /react-text -->")
								.replaceAll(">2</b>", "2 Story").replaceAll(">1</b>", " Story")
								.replaceAll(">3</b>", "3 Story");
					} catch (NullPointerException ne) {

					}
				if(storysec!=null) {
					storysec=storysec.replaceAll("alt=\"\" data-reactid=\"\\d{3}\"/><b class=\"d-block\" data-reactid=\"\\d{3}\">|</b><!-- react-text: \\d{3} -->", "");
				  
				}
				
//			}
			
				commdesc = commdesc.replace("two or three-story", "two-story or three-story");
				dtype = U.getdCommType((plandesc + commdesc+storysec).replaceAll("\"\\d+\"\\d Story", ""));

				U.log(dtype);
//				U.log("MATCH===="+Util.matchAll(storysec, "[\\w\\s\\W]{100}Story[\\w\\s\\W]{100}", 0));


				// =========================================pstatus
			//	U.log(">>>>>>>>> "+commdesc);
				commdesc=commdesc.replaceAll("parks to shops and restaurants offering unlimited opportunities","").replace("NEW LOTS & PRICING COMING SOON", "NEW LOTS COMING SOON");
				 commdesc=commdesc.replace("NEW LOTS & PRICING COMING SOON", "NEW LOTS COMING SOON")
						 .replace("NEW LOTS & PRICING COMING SOON", "NEW LOTS COMING SOON");
			
			
				 
				 pstatus = U.getPropStatus(commdesc);
				 pstatus=pstatus
						 .replace("New Lots Coming Soon, Coming Soon", "New Lots Coming Soon");
//				 .replace("", newChar)
				// region comm

				//
				/*
				 * if(latLong[0].length()<4){ latLong[0] = ALLOW_BLANK;latLong[1] =ALLOW_BLANK;
				 * } if(latLong[0].length()>4){ add = U.getAddressGoogleApi(latLong);
				 * if(add==null)add = U.getGoogleAddressWithKey(latLong); geo="TRUE"; }
				 * 
				 * if(add[0].length()<4 && latLong[0].length()<4){ String cityStateSec =
				 * url.substring(url.indexOf("homes-")+6,url.lastIndexOf("/"));
				 * U.log("cityStateSec : "+cityStateSec); if(cityStateSec !=null){ add[2] =
				 * cityStateSec.substring(cityStateSec.lastIndexOf("-")+1,cityStateSec.length())
				 * .toUpperCase(); U.log("State : "+add[2]); add[1] = cityStateSec.replace("-",
				 * " ").replaceAll(add[2].toLowerCase()+"$", ""); add[1] =
				 * U.getCapitalise(add[1]); U.log("city : "+add[1]); latLong =
				 * U.getlatlongGoogleApi(add); if (latLong==null)latLong =
				 * U.getGooglelatLongWithKey(add); add = U.getAddressGoogleApi(latLong);
				 * if(add==null)add = U.getGoogleAddressWithKey(latLong); geo = "TRUE"; note =
				 * "Address And latLong Taken Using City & State"; } }
				 * 
				 * 
				 * //--------homesec-------// String homeHtml=ALLOW_BLANK; String
				 * coSec=ALLOW_BLANK; String homes=U.getSectionValue(
				 * html,"<div id=\"sectionA\" class=\"tab-pane fade in active\">"
				 * ,"<div class=\"direction_img col-md-12\"");
				 * 
				 * if(homes!=null){ String vals[]=U.getValues(homes,"<figure><a href=\"","\"");
				 * for(String val:vals){ U.log("::::::::::::::"+val); homeHtml=U.getHTML(val);
				 * // if(homeHtml.contains("$309"))U.log(U.getCache(val)); coSec=coSec +
				 * U.getSectionValue(homeHtml,
				 * "class=\"homesliderbotom\">","<div class=\"communityhomeplans"); } }
				 * 
				 * 
				 * //========== Community Home Plans ================ String homePlanSection =
				 * U.getSectionValue(html, "<div id=\"sectionB\" class=\"tab-pane fade\">",
				 * "<div id=\"sectionC\""); String combinedHomePlans = null; int x = 0;
				 * if(homePlanSection != null){ String vals [] =
				 * U.getValues(homePlanSection,"<figure><a href=\"","\""); for(String val :
				 * vals){ // U.log("222222222222222222222222"+val); if(val.length()>35)
				 * combinedHomePlans += U.getSectionValue(U.getHTML(val),
				 * "class=\"homesliderbotom\">","<div class=\"communityhomeplans\"");
				 * //"</div>");
				 * 
				 * if(x ==5)break; x++; // U.log(Util.matchAll(combinedHomePlans,
				 * ".*?\\d+,\\d+.*?", 0)); } } // Price //U.log("pricePage :" + url +
				 * "/floor_plans/"); //String dataHtml = U.getPageSource(url + "/floor_plans/");
				 * 
				 * 
				 * 
				 * 
				 * 
				 * //================================ Replece Section =======================
				 * String[] neighbourSec; if (combinedHomePlans != null) { neighbourSec =
				 * U.getValues(combinedHomePlans, "padright neighborhood \">", "</div>");
				 * 
				 * for (String neighbour : neighbourSec) {
				 * 
				 * if (combinedHomePlans != null) combinedHomePlans =
				 * combinedHomePlans.replace(neighbour, ""); if (coSec != null) coSec =
				 * coSec.replace(neighbour, ""); }
				 * 
				 * }
				 * 
				 * String dhtml = html.replaceAll("0�s|0's|0s", "0,000");
				 * dhtml=dhtml.replace("homesites starting at $39,000", "");
				 * html=html.replace("homesites starting at $39,000", ""); //
				 * info=info.replaceAll("<br>",",000<br>"); coSec=coSec.replaceAll("$309", "");
				 * // U.log(U.getSectionValue(dhtml, "community-highlights\">", "Directions"));
				 * html=html.replace("’s", ",000");
				 * 
				 * // U.log(U.getSectionValue(html, "Neighborhood Highlights:",
				 * "throughout living areas and")); String minPrice = ALLOW_BLANK, maxPrice =
				 * ALLOW_BLANK; html=html.replaceAll("0’s|0’S|0’s","0,000");
				 * html=html.replace("0s","0,000"); if(combinedHomePlans != null){
				 * combinedHomePlans = combinedHomePlans.replace("mid-upper $200s",
				 * "mid-upper $200,000"); combinedHomePlans =
				 * combinedHomePlans.replace("Prices from the $320's", "$320,000")
				 * .replace("00s", "00,000"); } String[] price =
				 * U.getPrices(dhtml+html+coSec+combinedHomePlans,
				 * " mid-\\$\\d{3},\\d+|mid \\$\\d{3},\\d+|low \\$\\d{3},\\d{3}|in the \\d{3},\\d{3}|starting in \\d{3},\\d+|the mid \\d{3},\\d{3}|PriceRange\":\\d{2,}+|\\$\\d{3},\\d+|\\$\\d{3},\\d{3}|From \\$\\d{3},\\d+|Price \\$ \\d{3},\\d{3}|upper \\$\\d{3},\\d{3}"
				 * , 0); minPrice = (price[0] == null) ? ALLOW_BLANK : price[0]; maxPrice =
				 * (price[1] == null) ? ALLOW_BLANK : price[1]; U.log("MinPrice :" + minPrice +
				 * " MaxPrice:" + maxPrice); String inhtml=ALLOW_BLANK; String
				 * insec[]=U.getValues(html,
				 * "<div class=\"home_plan_bx no_image hpb_img_box\">", "</a>");
				 * //U.log(Arrays.toString(insec));
				 * 
				 * 
				 * for(String in:insec) { in=U.getSectionValue(in, "<a href=\"", "\"");
				 * inhtml=inhtml+U.getHTML(in); }
				 * 
				 * neighbourSec = U.getValues(inhtml, "padright neighborhood \">", "</div>");
				 * for(String neighbour : neighbourSec) {
				 * 
				 * if(inhtml!= null) inhtml = inhtml.replace(neighbour, "");
				 * 
				 * } // Square Feet String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				 * 
				 * String[] sqft = U .getSqareFeet( html + dhtml+inhtml+coSec+combinedHomePlans,
				 * "<br> (\\d,\\d{3}|0) - \\d,\\d{3} sq. ft.|starting at approximately \\d,\\d{3} square feet|starting around \\d{4} square feet|\\d,\\d+- \\d,\\d+ square feet |\\d,\\d{3}-\\d{4} square feet|SQ. FT.<br><span  class=\"pln\" class=\"pln\">\\d,\\d+| \\d{4} -\\d,\\d+ square feet |from \\d{4} to \\d{4}\\+ sqft|\\d+ to almost \\d+ square feet|\\d{1},\\d{3} -\\d{1},\\d{3} square feet|\\d{1},\\d{3} over \\d+|from \\d+ to almost \\d+ square feet|\\d{4} to \\d{4} heated square feet|\\d{4} to over \\d{4} square feet|[0-9]{4} to [0-9]{1},[0-9]{3} square feet|[0-9]{4}</span>|\\d{4} - \\d{4} sq. ft|\\d{4} to \\d{4} Sqft|from \\d{4} square feet to over \\d{4} square feet|\\d,\\d+ – \\d,\\d+ square feet| \\d,\\d+ sf|\\d,\\d+-\\d,\\d+ Square Feet|\\d,\\d+ to \\d,\\d+ sq. ft.|\\d+ - \\d+ Sqft|\\d+ Sqft|\\d,\\d{3}</span><br />Sq. Ft|SquareFeet\":\\d{2,}+|\\d,\\d{3} - \\d,\\d{3} Sq Ft|\\d,\\d{3} square feet|\\d{4}Sq Ft|Square Footage From [0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}|[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{4} Sq Ft"
				 * ,
				 * 
				 * 0); minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0]; maxSqf = (sqft[1] ==
				 * null) ? ALLOW_BLANK : sqft[1]; U.log("minSqf :" + minSqf + " maxSqf:" +
				 * maxSqf);
				 * 
				 * 
				 * // CommType String rm = U.getSectionValue(html+coSec,
				 * "<script type='text/javascript'>", "</script>"); if(rm != null) html =
				 * html.replace(rm, ""); String hh = U.getSectionValue(html,
				 * "<div class=\"listing\">", "</footer>"); if(hh!=null) html = html.replace(hh,
				 * ""); // html = html.replaceAll("Townhomes|Condos, Townhomes|,", ""); String
				 * remS = U.getSectionValue(html, "<title>", "text/css"); String stHtml = html;
				 * if(remS != null){ stHtml = html.replace(remS, ""); }
				 * 
				 * stHtml = stHtml.replaceAll("coastal retreat", "coastal homes").
				 * replace("new home buyers have the luxury of personalizing their homes",
				 * "luxury homes").replace("custom plan", "custom home").
				 * replaceAll(" for sale, Condos, |com/condos/view/|Luxurious Master Suites with Cerami"
				 * , ""); stHtml = stHtml.replace(rm,
				 * "").replace("Gazebo and Common Area back up to the Ponds",
				 * "").replace("HOA Maintained Lawns are Gorgeous", ""); stHtml = stHtml.
				 * replaceAll("Village|village|the-villas-at|Villas at|Cottages at|the-cottages"
				 * , "").replace("custom plan", "custom luxury homes"); stHtml =
				 * stHtml.replaceAll("luxurious owner suites|three stories of luxurious living",
				 * "luxury homes").replaceAll("the Estates", "Estate Style Living");
				 * 
				 * // String hh = U.getSectionValue(html, "<div class=\"listing\">",
				 * "</footer>"); // U.log(stHtml); // U.log(coSec);
				 * stHtml=stHtml.replace("styles from the traditional", "Poplar Traditional");
				 * String propType = U.getPropType((stHtml+coSec+combinedHomePlans+commName).
				 * replaceAll("courtyard entry garages", ""));
				 * 
				 * // PropType String commType = U.getCommunityType(html+coSec);
				 * 
				 * String status = ALLOW_BLANK; String statSec =
				 * html.replace("Now Selling the final phase", "Now Selling Final Phase");
				 * String remove =
				 * "acre lots available</li><li>|clubhouse coming soon|Move In Ready|MoveInReady"
				 * ;
				 * 
				 * // U.log("Statsection----> "+statSec);
				 * 
				 * statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
				 * statSec=statSec.replace("Coming Fall 2016","").replace("lots available","");
				 * status = U.getPropStatus(statSec);
				 * 
				 * // if (coSec.length() > 3) { // if (status.length() < 3) // status =
				 * "Available Home"; // else // status += ", Available Home"; // }
				 * 
				 * 
				 * if(url.contains("/homes-wilmington-nc/Hanover-Lakes-Cottages")) {
				 * maxPrice="$305,900"; }
				 * if(url.contains("homes-greenville-nc/kensington-at-paramore")) {
				 * propType="Custom Home"; } if(url.contains(
				 * "http://www.billclarkhomes.com/community-detail/homes-new-bern-nc/Grantham-Place"
				 * )) maxSqf = "1900";
				 * 
				 * 
				 * 
				 * 
				 * if(commName==null) { commName=U.getSectionValue(info,
				 * "<div class=\"caption\" style=\"text-align: left;\"> ", "</div>"); }
				 * 
				 * if(commName.endsWith("Cottages"))commName=commName.replaceAll(
				 * "Cottages|cottages", ""); U.log(commName+":::::::::::::");
				 * html=html.replace("one or two story", " 1 Story  2 Story ");
				 * 
				 * String dType=U.getdCommType(html+coSec+combinedHomePlans);
				 * 
				 * status=status.replace("Usda Financing","USDA financing availability");
				 * if(url.contains("/homes-fayetteville-nc/Stonegate"))
				 * note="Waterfront Lots Available For Presale"; count=count+1;
				 */
				
//			}
			if (maxPrice == null) {
				maxPrice = ALLOW_BLANK;
			}
			if (minPrice == null) {
				minPrice = ALLOW_BLANK;
			}
			if(url.contains("https://www.billclarkhomes.com/communities/greenville/the-hollows-at-grey-fox-run")) {
				minSqft="1638";
			maxSqft="1888";
			}
			//starting in the low $200s
			/*
			 * if(url.contains(
			 * "https://www.billclarkhomes.com/communities/greenville/heritage-at-paramore")
			 * ) minPrice="$200,000";
			 */
//			if(url.contains("https://www.billclarkhomes.com/communities/greenville/the-villages-at-langston-farms")) {
//				minPrice="$160,000";
//			   //maxPrice="$300,000";
//			}
			
			if(url.contains("https://www.billclarkhomes.com/communities/greenville/bedford-west")) {
				dtype="2 Story";
			}

			

			if(url.contains("https://www.billclarkhomes.com/communities/greenville/colony-woods-south"))
				commName="Arbor Hills South II";
			
			
			if(url.contains("https://www.billclarkhomes.com/communities/greenville/davenport-farms"))
				dtype="1 Story, 2 Story";

			if(url.contains("https://www.billclarkhomes.com/communities/wilmington/channel-watch"))
				dtype="1 Story, 2 Story";
			
			 
			 if(url.equals("https://www.billclarkhomes.com/communities/greenville/arbor-hills-south"))
					minPrice="$170,000";
			 if(url.equals(" https://www.billclarkhomes.com/communities/wilmington/river-oaks"))
					minPrice="$330,000";
			
			 
if(url.contains("https://www.billclarkhomes.com/communities/wilmington/compass-pointe"))
	commName="Compass Pointe";

			
			  if(url.contains("https://www.billclarkhomes.com/communities/greenville/colony-woods-south"))
			  commName="Colony Woods South";
			  
			if(url.contains("https://www.billclarkhomes.com/communities/new-bern/croatan-crossing"))
				dtype=dtype+", 2 Story";
if(url.contains("wilmington/riverlights")) {minPrice=ALLOW_BLANK;maxPrice=ALLOW_BLANK;}
			 if(maxSqft==null) {
				 maxSqft=ALLOW_BLANK;
				 
			 }
			 
			 if(pstatus!=null)
				 pstatus = pstatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
			 
			 pstatus = pstatus.replace("Coming In 2022, Coming Soon", "Coming Soon");
//			 =============================================================================
			 
			 
			 String[] lot_data=null;
				String lotCount=ALLOW_BLANK;
				String lot_Sec=U.getSectionValue(html, "<g>", "</g>");
				if(lot_Sec!=null) {
					lot_data=U.getValues(lot_Sec, "<path class=", "</path>");
					if(lot_data.length>0) {
					lotCount=Integer.toString(lot_data.length);
					 U.log("lotCount2=="+lotCount);
					}
				}
			 
			 
			 
			 
			 if(minSqft==null)minSqft=ALLOW_BLANK;
				data.addCommunity(commName, url, commtype);
				data.addAddress(add[0].replace("DONALD DRIVE", "Donald Drive"), add[1].replace("WINTERVILLE", "Winterville"), add[2].trim(), add[3]);
				data.addSquareFeet(minSqft, maxSqft);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
				data.addPropertyType(proptype, dtype);
				data.addPropertyStatus(pstatus.replace("New Phase, Coming Soon", "New Phase Coming Soon"));
				data.addNotes(note);
				data.addUnitCount(lotCount);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				
		}
			
				j++;
	
//				catch(Exception e) {}
		
	
	}
}
