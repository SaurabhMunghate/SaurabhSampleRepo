/**
 * @author Parag Humane 
 * @date 24/04/2013
 * 
 */
package com.shatam.b_101_120;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractElliotteHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	static int j = 0;
	WebDriver driver = null;

	private static final String builderUrl = "https://www.elliotthomes.com";

	public static void main(String[] args) throws Exception {
 
		AbstractScrapper a = new ExtractElliotteHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Elliott Homes.csv", a.data().printAll());
	}

	public ExtractElliotteHomes() throws Exception {

		super("Elliott Homes", "https://www.elliotthomes.com/");
		LOGGER = new CommunityLogger("Elliott Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHTML("https://www.elliotthomes.com/communities");

		String comSection[] = U.getValues(html, "<div class=\"CommunityCard_media\"", "</div></div></div></div></div>");
		U.log(comSection.length);
		for (String comSec : comSection) {
			String comUrl = U.getSectionValue(comSec, "<a class=\"\" href=\"", "\"");
			String comName=U.getSectionValue(comSec, "class=\"CommunityCard_communityName\"", "</span>");
			U.log("comName :: "+comName);
			U.log(comUrl);
//			if(comUrl.contains("/master-planned/"))
//				findSubCommunity(builderUrl + comUrl, comSec);
//			else 
			 addDetailsNew(builderUrl + comUrl, comSec.replaceAll("<!-- /react-text -->|<!-- react-empty: \\d+ -->|<!-- react-text: \\d+ --|data-reactid=\"\\d+\"", ""));
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	

	
	private void addDetailsNew(String url, String comSec) throws Exception {
//		 if(j==6)
//		try{
		{
			//TODO : Execute for single community
//	if(!url.contains("https://www.elliotthomes.com/communities/california/sacramento/turkey-creek-estates")) return;

			if (data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+ "------------  repeat");
				return;
			}
			if(url.contains("https://www.elliotthomes.com/communities/undefined/"))return;// not present on reg dt:20 Sep 21
			LOGGER.AddCommunityUrl(url);
			
			U.log("Count == "+j+"\r\nPAGE :" + url);

			String htm = U.getHtml(url, driver);
			U.log(U.getCache(url));
			
			
			String removeSec=U.getSectionValue(htm, ">Community Hours", "Preferred Lender</h4>");
			if(removeSec!=null) {
				htm=htm.replace(removeSec, "");
			}
			String preloadSec= U.getSectionValue(htm, "window.__PRELOADED_STATE__", "</htm");
			htm = htm.replace(preloadSec, "");
			U.log("<<<<<<<<<<<<<<<<<<<<<<<<<, "+comSec);
			// CommName
			
			String commName = U.getSectionValue(comSec, "<span class=\"CommunityCard_communityName\" >", "<");
			if (commName.contains("-"))
				commName = commName.split("-")[0];
			commName=commName.replace("é", "e")
					.replaceAll("Welcome to |, Custom Homes| Custom Lots$|is SOLD OUT!|, Custom Lots|<BR>JULY SALE!|<br>NOW AVAILABLE|Estates Custom Lots<BR>A SELECT FEW!","");
			U.log("Community Name :" + commName);

//			// ------------------- Address & lat-lng----------------------------------
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			geo = "FALSE"; String ll[] = new String[2];

			String latlngSec = ALLOW_BLANK;
			htm = htm.replace("<a href=\"https://www.google.com/maps/place/undefined,undefined/", "");
			latlngSec = U.getSectionValue(htm, "href=\"https://www.google.com/maps/place/",
					"/@");
			U.log(latlngSec);
			if(latlngSec!=null) {
				ll=latlngSec.split(",");
				lat=ll[0];
				lng=ll[1];
			}
			U.log("Lat: "+lat +" LLLLL"+" Lng: "+lng);

			// U.log(lng);
			String addSec= U.getSectionValue(htm, "<h2 class=\"DetailHeader_subheading\"", "</h2>");
			if(addSec!=null) {
				addSec = addSec.replaceAll("data-reactid=\"\\d+\">", "").replace("|", ",");
				add=U.getAddress(addSec);
				add[0]=add[0].replace("&amp;", "&");
			}
			U.log(Arrays.toString(add));
			
			if(add[0].contains("Please see out of community sales office")||add[0].contains("No Sale Office")) {
				add = U.getAddressGoogleApi(ll);
				if(add == null) 
					add = U.getAddressHereApi(ll);
				geo = "TRUE";
			}
//			
//			String quick = Util.match(url, "https://www.elliotthomes.com/\\w{2}/(.*?)/");
//			U.log("quick::" + quick);
//
//			if (quick != null) {
//				quick = "https://www.elliotthomes.com/quick-delivery-homes?community=" + url.replace(quick, "");
//				U.log("quick::" + quick);
//				quick = U.getHTML(quick);
//				// U.log("quick::"+quick);
//			}
			
			//floorPlandata
			String allFloorData=ALLOW_BLANK, allQuickData =ALLOW_BLANK;
			String plans[] = U.getValues(htm, "<div class=\"PlanCard_wrapper\"", "/div></div></div></div></div>");
			U.log("floorLength: "+plans.length);
			for(String plan: plans) {
				String planUrl = builderUrl+ U.getSectionValue(plan, "<a class=\"\" href=\"", "\"");
				String planHtm = U.getHTML(planUrl);
				allFloorData +=U.getSectionValue(planHtm, "<h1 class=\"DetailHeader_heading\" data-", "Map &amp; Contact Info</h3></div>");
				
			}
//			// U.log(htm);
//			// Price
//			htm=htm.replace("Lot sizes range between 6,000 and 23,000 square", "");
//			if(quick!=null)
//			quick = quick.replaceAll("Original Purchase Price was \\$\\d{3},\\d{3}| Lot sizes range between 6,000 and 23,000 square feet", "");// 144}
//			
//			htm = htm.replaceAll(" / \\$\\d+,\\d+|move-in ready and specially priced at \\$\\d+,\\d+|/ \\d{3},\\d{3} Sq Ft.", "")
//					.replaceAll("High \\$(\\d{3})s", "High \\$$1,000"); //lot sqft
//					
			htm = htm.replace("0s", "0,000")
					.replace("<!-- /react-text -->", "")
					.replaceAll("<span data-reactid=\"(\\d{2,3})\">", "")
					.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">|<!-- /react-text -->|data-reactid=\"\\d+\"|<!-- react-text: \\d+ -->|<span data-reactid=\"\\d+\">|</span></span><span class=\"DetailHeader_listLabel\" data-reactid=\"\\d+\">"," ");
//			htm = htm.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">"," ");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//			U.log(htm);
			String[] price = U.getPrices(htm +comSec+ allFloorData,"Low \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|>\\$\\d,\\d{3},\\d{3}</span>|FROM \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d+|From\\s*<b>\\$\\d+,\\d+|at \\$\\d+,\\d+|From\\s*\\$\\d+,\\d+|FROM \\$\\d+,\\d+", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// Square Feet
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(htm +comSec+ allFloorData,
					"\\d,\\d{3}  -  \\d,\\d{3}  SQ FT|under \\d,\\d{3} square feet|almost \\d,\\d{3} square feet|\\d,\\d{3} square feet to \\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} SQ FT|Sq Ft\\s+\\d,\\d{3}\\s+-\\s+\\d,\\d{3}|\\d,\\d{3} SQ FT|range between \\d,\\d{3} and \\d{1,2},\\d{3} square feet| Sq Ft: \\d,\\d+ - \\d,\\d+|Sq Ft\\s+\\d,\\d{3}|Sq Ft[\\n\\s]*\\d,\\d{3}[-\\n\\s]*\\d,\\d{3}|\\d{1,3},\\d{3} Sq Ft|Sq Ft:\\s*<b>\\s*[^<]+|\\d+,\\d+ SF|\\d{4} square feet to \\d{4} square feet|range from \\d{4} to \\d{4} square feet|\\d,\\d{3} and \\d{1,2},\\d{3} square feet",
					0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			if(url.contains("/lakeview-oaks-at-empire-ranch-custom-lots")) {minSqf=ALLOW_BLANK;maxSqf=ALLOW_BLANK;}
			if(url.contains("/terraces-west")) {minSqf="2496";maxSqf="2929";}
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			U.log("=========="+Util.matchAll(htm , "[\\w\\s\\W]{50}1,609[\\w\\s\\W]{30}", 0));

			//status
			String status = ALLOW_BLANK;
			String statSec = htm;
			String remove = " <p class=\"small\">COMING SOON</p>| two-story home is now available|Custom Lots<br>NOW AVAILABLE|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|-SOLD OUT - FOLSOM</option>|limited availability of larger |Quick Move|Quick-Move|- COMING FALL 2018|- COMING SOON|Stoneridge - Coming Soon\\s+</a>|Hours:</b><br/>\\s+Opening February 2017|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
			statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
			statSec = statSec.replaceAll("Temporarily Sold Out|\"headline\":\"Sold Out!\"|status\":\"Sold Out\"|\"headline\":\"SOLD OUT\"|Custom Lots are Sold Out", "");
			status = U.getPropStatus((statSec).replaceAll("<div class=\"plancard_headlinebanner\"  >temporarily sold out|price\">\n\\s*[s|S]old|price\">\n\\s*[t|T]emporarily [s|S]old|temporarily sold out<br/>|is now available and|model homes are now available|with limited|lovely home is move-in ready!|Custom Lots<br>NOW AVAILABLE|\"headline\":\"Sold Out!\"|headline\":\"Custom Lots are Sold Out!\"|status\":\"Sold Out\"|CUSTOM LOTS&lt;BR&gt;NOW AVAILABLE|floorplans<br /> coming|is move-in|plancard_headlinebanner\" >temporarily sold out</div>", "") + comSec.replaceAll("Custom Lots<br>NOW AVAILABLE", ""));
			
//			status = status.replace("Sold Out", ALLOW_BLANK);
//			U.log("=========="+Util.matchAll(statSec, "[\\w\\s\\W]{50}Sold Out[\\w\\s\\W]{30}", 0));
//			U.log("=========="+Util.matchAll(comSec, "[\\w\\s\\W]{50}Temporarily Sold Out[\\w\\s\\W]{30}", 0));
			U.log("status: "+status);
			
			//commtype
			String communityType = U.getCommunityType((htm+comSec).replaceAll("Elongated|elongated|data-master_plan_community", ""));
			U.log("communityType: "+communityType);

			//propType =
			allFloorData=allFloorData.replace("inviting courtyard and portico", "inviting Courtyard and portico");
			String prpType=U.getPropType(commName.replace("Villa ", "") + (htm+comSec+allFloorData)
					
					.replaceAll("Villa Fiore|Custom Homes</a>|Spanish Colonial Trim|"
					+ "the inviting courtyard and portico|duplex GFCI|\">ESTATE SERIES|Estate Series|Terraces Townhomes", ""));
			U.log("propType: "+prpType);
//			U.log("=========="+Util.matchAll(allFloorData, "[\\w\\s\\W]{50}courtyard[\\w\\s\\W]{30}", 0));
			
			//dtype
			String dType=U.getdCommType(commName+url+(htm+comSec+allFloorData).replaceAll("rancho|Rancho|floor|", ""));
//			U.log("=========="+Util.matchAll((commName+htm+comSec+allFloorData), "[\\w\\s\\W]{50}villa[\\w\\s\\W]{30}", 0));

			U.log("dType: "+dType);
			
			
//			====================================================================================
			
			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
			String lot_Sec=U.getSectionValue(htm, "<g>", "</g>");
			if(lot_Sec!=null) {
				lot_data=U.getValues(lot_Sec, "<path class=", "</path>");
				if(lot_data.length>0) {
				lotCount=Integer.toString(lot_data.length);
				 U.log("lotCount2=="+lotCount);
				}
			}
			
			

			String note = U.getnote(htm+comSec);
			data.addCommunity(commName.replaceAll(" Custom Lots!|, Custom Homes & Lots", ""), url, communityType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(prpType,dType);
			
			data.addPropertyStatus(status);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);


		}
		j++;
//		}catch(Exception e) {}
	}
	

}