/**
 * @modified by : Priti
 * @Date :1st Sept 2017
 * 
 */
package com.shatam.b_101_120;

import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
//import org.openqa.selenium.internal.seleniumemulation.IsVisible;

public class ExtractEssexHomes extends AbstractScrapper {
	int i = 0;
	static int duplicates = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractEssexHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Essex Homes.csv", a.data()	.printAll());
		U.log(duplicates);
	}

	public ExtractEssexHomes() throws Exception {

		super("Essex Homes", "http://www.essexhomes.net/");
		LOGGER = new CommunityLogger("Essex Homes");
	}

	public void innerProcess() throws Exception {

		String basehtml=U.getHTML("http://www.essexhomes.net/");
		String regSec=U.getSectionValue(basehtml,"Neighborhoods</a><div class='menu-children","</ul></div></li>");
		String regVals[]=U.getValues(regSec,"<a target=\"_self\" href=\"","\" >");
		U.log("regVals:::"+regVals.length);
		
		for(String regVal:regVals ){
			if(!regVal.contains("http://www.essexhomes.net/"))regVal = "http://www.essexhomes.net"+regVal;
			U.log(regVal);
			findCommunity(regVal);
		}
		
		LOGGER.DisposeLogger();
	}
	
	public void findCommunity(String regUrl) throws Exception {
	//	regUrl=regUrl;
		String regHtml=U.getHTML(regUrl);
		
		
		String comVals[]=U.getValues(regHtml,"<h3><a ","</h3>");
		U.log("comLength of "+regUrl+":::::::::::"+comVals.length);
		LOGGER.AddRegion("http://www.essexhomes.net/"+regUrl, comVals.length);
		for(String comVal:comVals ){
			String url=U.getSectionValue(comVal,"href=\"","\"");
			
			String name=U.getSectionValue(comVal,">","</a>");
			
			
			addDetails(comVal,url,name);
			
		}
		
	}
	
	public void addDetails(String comSec,String url,String communityName) throws Exception {
		
//if(j== 21)
	{	
		String url1="http://www.essexhomes.net"+url;
		String html=U.getHTML(url1);
		U.log(j+"::::::::::"+url1);
		
		//if(!url1.contains("http://www.essexhomes.net/neighborhoods/whispering-pines-at-the-palisades"))return;
		
		if (data.communityUrlExists(url1)) {
			LOGGER.AddCommunityUrl(url1+"<<================ Repeat");
			return;
		}
		LOGGER.AddCommunityUrl(url1);
		String bannerSec=U.getSectionValue(html, "<div class=\"banner-text\">", "</div>");
		//U.log(bannerSec);
	
	
		
		
		
		//-----------------------latlong----------//
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "var centerPosition = new ",");");
		if (latLongsec != null) {

			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		U.log("name*********"+communityName);
		
		//----------------------Adress--------------------------------- 
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;

		String ad = U.getSectionValue(html,"<li>Address:", "</li>");
		U.log("ad:::::::::::::"+ad);
	
		if(ad != null && ad.contains("<br>")){
			//ad = ad.trim().replaceAll("^(?!\\((.*?)\\))", "");
			ad = ad.trim().replace("<br>", ",").replace("TBD", "").replaceAll("Model Address: 104 Milkweed Road,|GPS Address: 6504 Hawfield Road,|GPS address: Old Barnwell Rd and Enterprise Parkway|&nbsp;|1226 Marthan Road|1840 Felts Parkway|Pineview Road|Knollside Drive|Needle Leaf Drive", " ").trim()
					.replaceAll("1071 Waterlily Drive,9537 Possum Hollow Drive", "1071 Waterlily Drive")
					.replace("Across from ", "").replace("887 Centennial Drive,Pinnacle", "Pinnacle");
		
			if(ad.startsWith("(")){
				ad = ad.replaceAll("\\(|\\)|:|GPS Address", "");
			}else
				ad =ad.replaceAll("\\((.*?)\\)", "");
			ad = ad.replace(",,", ",");
			U.log(ad);		
			add = U.getAddress(ad);
		}else if(ad != null && !ad.contains("<br>")){
			ad = ad.replace("&nbsp;", " ");
			String[] vals = ad.split(",");
			add[1] = vals[0];
			if(vals[1].length() > 3){
				add[2] = vals[1].trim().split(" ")[0];
				add[3] = vals[1].trim().split(" ")[1];
			}else
				add[2] = vals[1].trim();
		}
		if(add[2] == null)add[2] = ALLOW_BLANK;

		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			if(latLong[0] != ALLOW_BLANK && latLong[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLong);
				geo = "True";
			}
		}
		U.log("Add ::"+Arrays.toString(add));
		if (add[0] == ALLOW_BLANK) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[0] = addr[0];
			geo = "TRUE";
		}
		
		if (add[2] == ALLOW_BLANK ||add[2].length()==0) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[2] = addr[2];
			geo = "TRUE";
		}
		if (add[3] == ALLOW_BLANK ||add[3].length()==0) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		
		U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
				+ " add[3] " + add[3]);
		
		//---------sec for communities-------------
		String sec=ALLOW_BLANK;
		sec=U.getSectionValue(html,"<div id=\"details\" class=\"small-12 medium-6 columns end\">","<div class=\"small-8 left columns\">");
		//----------------------available homes--------------//	
		String allAvailData=ALLOW_BLANK;
		ArrayList<String> availUrls = Util.matchAll(html, "<li><a href=\"(.*?)\">View\\s*Plan\\s*Details</a></li>",1);
		U.log("Total available Homes " + availUrls.size());	
			for(String availUrl : availUrls ){
				availUrl="http://www.essexhomes.net"+availUrl;
				U.log("availUrl : "+availUrl+"**********");
				String availHtml = U.getHTML(availUrl);
				allAvailData += U.getSectionValue(availHtml, "<div class=\"large-6 columns left\">", "Download Brochure</a></b></li>");
		}
		
		allAvailData = allAvailData.replaceAll("<li>Stories: <span>", "<li>Stories: ");
		//U.log(allAvailData);
		//--------------quick move in -------------
		String quickMove=ALLOW_BLANK;
		String quick=url1+"#move_in_homes";
		quickMove=U.getHTML(quick);
		
		String allQuickData=ALLOW_BLANK;
		String quickSec=U.getSectionValue(html, "id=\"move_in_homes\">","<a name=\"neighborhood_map\">");
		ArrayList<String> quickUrls= Util.matchAll(quickSec, "<a href=\"(.*?)\">Learn",1);
		U.log("Total quick Url : " + quickUrls.size());
		for(String quickUrl : quickUrls )
		{
			quickUrl = "http://www.essexhomes.net"+quickUrl;
			U.log("Quick Url : "+quickUrl);
			String quickHtml = U.getHTML(quickUrl);
			allQuickData += U.getSectionValue(quickHtml, "<h3 class=\"spec-name\">", "id=\"home_gallery\">");
		}
		allQuickData = allQuickData.replaceAll("<li>Stories: <span>", "<li>Stories: ")
				.replaceAll("split design |Split plan so", "split floor plan ");
		//--------------------neighbourhood feature----------
		
		String neigbourFea=ALLOW_BLANK;
		String neighbour=url1+"#neighborhood_features";
		String neighbour1=U.getHTML(neighbour);
		neigbourFea=U.getSectionValue(neighbour1,"<div class=\"small-8 column display_list\">"," <div class=\"content\" id=\"neighborhood_map\">");
		
		// ---------community type,property type,property status,derived,
		//===========Community type---------//
		
		String commType = U.getCommunityType(sec+bannerSec);
		
		
		//==================== Property Type ===================
		 html=html.replaceAll("Insulated Carriage style|Carriage style garage|Carriage lights|Carriage style insulated","");
		 if(neigbourFea!=null)
          neigbourFea=neigbourFea.replaceAll("Insulated Carriage style|Carriage style garage|Carriage lights|Carriage style insulated","");
		String propType = U.getPropType((sec+neigbourFea).replaceAll("residential luxury", "luxury homes"));
		//U.log(sec);

		//=============== Derived Type ===============
		String dpType = U.getdCommType(sec+neigbourFea+allQuickData+allAvailData);
		
		
		//==================== Property Status ==================
	//U.log(sec);
		sec = sec.replaceAll("in ready house", "");
		if(bannerSec != null)
			bannerSec = bannerSec.replaceAll("Coming soon", "");
		String commStatus = U.getPropStatus((bannerSec+sec).replaceAll("Pricing: Coming Soon|banner-text\">Coming soon</div>|Hours: Coming Soon|Move-in Ready Homes Available|gated community are selling fast|No quick move-in homes available|Quick Move-In Homes</a></li>|Quick Move-In Homes\\s*</option>|Limited opportunities await the discerning homebuyer i|to take advantage of the limited opportunities that remain|selection of one of the 19|Amenities are now open", ""));
		if(html.contains("No quick move-in homes available for this community.")){
			if(commStatus.length()<4)
				commStatus="No Quick move-in Homes";
			else
				commStatus=commStatus+", No Quick move-in Homes";
		}
		else{
			if(commStatus.length()<4)
				commStatus="Quick move-in Homes";
			else
				commStatus=commStatus+", Quick move-in Homes";
		}
		commStatus = commStatus.replace("Only 9 Opportunities Remain, Only 9 Homes Remain", "Only 9 Opportunities Remain")
				.replace("2 Opportunities Left, Two Opportunities Remain", "2 Opportunities Left")
				.replace("2 Opportunities Left, Only 2 Opportunities Remain", "2 Opportunities Left").replace("Only 5 Opportunities Remain, Only 5 Homes Remain", "Only 5 Opportunities Remain");

		// --prices---//
		html=html.replace("0's","0,000");
		html=html.replace("0s","0,000");
		String[] price = U.getPrices(html+allAvailData+quickMove,
				"Pricing: \\$\\d+,\\d+|High \\d+,\\d+|From the \\$\\d+,\\d+|Upper \\$\\d+,\\d+|High \\$\\d+,\\d+|Mid \\$\\d+,\\d+|Starting in the \\d+,\\d+|<li>Price: <span>\\$\\d{3},\\d+|Reduced Price: <span>\\$\\d+,\\d+|mid \\d{3},\\d{3}|the \\$\\d{3},\\d{3}|Low \\$\\d+,\\d+|Reduced Price:\\n*\\s*<span>\\$\\d{3},\\d{3}", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		allQuickData=allQuickData.replaceAll("<li>Square Feet: 4,911</li>", "");
		allAvailData=allAvailData.replaceAll("<li>Square Feet: 4,911</li>", "");
		html=html.replace("<li>Square Feet: 4,911</li>", "");
		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html+allAvailData+quickMove,
				"over \\d,\\d{3} to nearly \\d,\\d{3} square feet|Square Feet: \\d{1},\\d{3}|Sq. Ft. Range:  \\d{1},\\d{3} - \\d{1},\\d{3}|SQ FT: \\d{1},\\d{3}|Sq. Ft. Range: \\d{1},\\d{3} - \\d{1},\\d{3}|Sq. Ft. Range: 0 - \\d,\\d+", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		
		communityName=communityName.replaceAll(" - spacious homesites| - half acre, wooded homesites","");
		add[0]=add[0].replace("(GPS Address: 10900 Robinson Church Rd.)","10900 Robinson Church Rd");
		add[0]=add[0].replace("(GPS Address: 1226 Marthan Road)","1226 Marthan Road");
		add[0]=add[0].replace("(GPS Address: 7749 Garners Ferry Road)","7749 Garners Ferry Road");
		add[0]=add[0].replace(",", "");
		
		// ---notes-----//

		data.addCommunity(communityName, url1, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));

		
	}
	j++;
	}
	
}