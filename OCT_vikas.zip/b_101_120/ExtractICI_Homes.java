/** New Modification Aditya...
 *
 @author Parag Humane 
 * @date 07/04/2012
 * 
 */
package com.shatam.b_101_120;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;

import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractICI_Homes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;

	private static final String builderUrl = "https://icihomes.com";
	CommunityLogger LOGGER;
	static int j = 0;

	WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractICI_Homes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "ICI Homes.csv", a.data().printAll());
	}

	public ExtractICI_Homes() throws Exception {

		super("ICI Homes", "https://www.icihomes.com/");
		LOGGER = new CommunityLogger("ICI Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
//		String html = U.getHTML("http://www.icihomes.com/");
		String html = getHtml("https://www.icihomes.com/", driver);
//		U.log(html);
		String section = U.getHtmlSection(html, "id=\"nav-find-hover\"", "<li id=\"nav-movein\">");
		String region[] = U.getValues(section, "<li><a href=\"", "\"");

		for (String item : region) {
			if (item.contains("collection"))
				continue;
			U.log("Region :https://www.icihomes.com" + item);
//			html = U.getHtml("http://www.icihomes.com" + item, driver);
			html = U.getHTML("https://www.icihomes.com" + item);
			String commSec = U.getSectionValue(html, "Area Communities</li>", "id=\"tabbar-contact-us\"");
			if (commSec == null)
				commSec = "";
			commSec = commSec.replace("/on-your-lot/", "#/on-your-lot/");
			// U.log(commSec);
			String comm[] = U.getValues(commSec, "<li data-", "</a></li>");

			String data = U.getSectionValue(html, "<h3>", "</p><style");
//			U.log(Arrays.toString(comm)+"!!!!!!!!!!!!!!!!!!!!!!!!");
//			U.log(comm.length);

			for (String info : comm) {
				// U.log("Info:" + info);
				String url;
				String name = U.getSectionValue(info, "data-communityname=\"", "\"");
				String location = U.getSectionValue(info, "</p><span>", "</span>");

				if (info.contains("on-your-lot")) {
					url = "http://www.icihomes.com" + U.getSectionValue(info, "<a href=\"#", "\"");
					// U.log(url + "\t"+name);
//-					addbuild(url,  name ,location);
				} else {
					url = "http://www.icihomes.com" + item + U.getSectionValue(info, "<a href=\"#", "\"");
					U.log(url + "\t" + name);
					addDetails(url, name, info, data);
				}
//				U.log("URL::" + url);

				inr++;
				i++;
			}
			inr = 0;
		}

		LOGGER.DisposeLogger();
//		driver.quit();
	}

	
	// TODO : Extract Communities details here
	private void addDetails(String url1, String commName, String info, String mainComdata) throws Exception {
		// if(j>=12)
		{
			// LOGGER.countOfCommunity(i);

			url1 = url1.replace("http:", "https:");

			// ================== Single Run =====================================
			
//		if (!url1.contains("https://www.icihomes.com/a/2/tampa/persimmon-park"))return;
			
			String html1 = U.getHTML(url1);

//			U.log("");
			
			String hearBySec = U.getSectionValue(html1, "<h2><strong>Nearby Attractions</strong></h2><ul", "</ul></div>");
			if(hearBySec!=null)
				html1 = html1.replace(hearBySec, "");
			
			String remove1 = U.getSectionValue(html1, "Jacksonville New Home Builder - ICI Homes</h2>", "");
			if(remove1!=null)
				html1 = html1.replace(remove1, "");
			
//		U.log(info);
			U.log(U.getCache(url1));
			U.log(j + " <--\nPAGE :" + url1);
			String[] latLong = new String[] { ALLOW_BLANK, ALLOW_BLANK };
			String lat = ALLOW_BLANK;
			String lng = ALLOW_BLANK;
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			add[0] = U.getSectionValue(html1, "itemprop=\"streetAddress\">", "</span>");

			add[1] = U.getSectionValue(html1, "itemprop=\"addressLocality\">", "</span>");
			add[2] = U.getSectionValue(html1, "itemprop=\"addressRegion\">", "</span>");
			add[3] = U.getSectionValue(html1, "itemprop=\"postalCode\">", "</span>");

			U.log("street : " + add[0]);
			U.log(Arrays.toString(add));
			String geo = ALLOW_BLANK;

			if (url1.contains("https://www.icihomes.com/a/2/tampa/bexley")) {
				add[0] = "16754 Courtyard Loop";
				add[1] = "Land O'Lakes";
				add[2] = "FL";
				add[3] = "34638";
				geo = "FALSE";
			}

			if (url1.contains("https://www.icihomes.com/a/1/jacksonville/tamaya")) {
				add[0] = "2938 Danube Court";
				add[1] = "Jacksonville";
				add[2] = "FL";
				add[3] = "32246";
				geo = "FALSE";
			}
			U.log(add[0]);
			U.log(add[1]);
			U.log(add[2]);
			U.log(add[3]);

//		html1 = html1.replace("name':'Brown\'s Landing", "name':'Brown's Landing");
			String tempName = commName.trim() + "','pin':new google.maps.LatLng(";
			U.log(tempName + U.getSectionValue(html1, tempName, ")}"));
			String latLngSec = U.getSectionValue(html1, tempName, ")}");
			if (url1.contains("daytona-beach/brown-s-landing"))
				latLngSec = U.getSectionValue(html1, "Brown\\'s Landing','pin':new google.maps.LatLng(", ")}");
			U.log("latLngSec::::::::::" + latLngSec + ":::::::::::::::");
			if (latLngSec != null && !latLngSec.contains("0,0") && add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
				latLong = latLngSec.split(",");
				lat = latLong[0];
				lng = latLong[1];
				geo = "FALSE";
				U.log("Success if");
			} else {
				if (add[0] != null) {
					String[] temp = add;
					temp[0] = temp[0].replace("13006 Pechora Court", "Pechora Court");
					latLong = U.getlatlongGoogleApi(temp);
					if(latLong == null) latLong = U.getlatlongHereApi(temp);
					geo = "True";
					lat = latLong[0];
					lng = latLong[1];
					U.log("Success else");
				}
			}
			U.log("lat lng is " + Arrays.toString(latLong));
			if (add[0] == null) {
				add[0] = ALLOW_BLANK;
				add[1] = ALLOW_BLANK;
				add[2] = ALLOW_BLANK;
				add[3] = ALLOW_BLANK;
			}
			String latlng[] = { ALLOW_BLANK, ALLOW_BLANK };
			String note = ALLOW_BLANK;
			if (url1.contains("https://www.icihomes.com/a/4/daytona-beach/palm-coast")) {
				add[1] = "Palm Coast";
				add[2] = "FL";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				lat = latlng[0];
				lng = latlng[1];
				geo = "TRUE";
			}
			if (url1.contains("https://www.icihomes.com/a/3/orlando/avilla")) {
				add[1] = "Kissimmee";
				add[2] = "FL";
				latlng = U.getlatlongGoogleApi(add);
				if(latlng == null) latlng = U.getlatlongHereApi(add);

				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				lat = latlng[0];
				lng = latlng[1];
				geo = "TRUE";
				note = "Address And Lat-Lng Taken Using City And State";
			}
			if (add[2] == null)
				add[2] = ALLOW_BLANK;
			if (latLong[0] == null || latLong[0] == null) {
				latLong[0] = ALLOW_BLANK;
				latLong[1] = ALLOW_BLANK;
			}

			// -----------------------
			String quickHtml = "";
			String quickComSec = ALLOW_BLANK;
			if (html1.contains("button-quickmovein\"")) {
				String quickLink = U.getSectionValue(html1, "<a class=\"button-quickmovein\" href=\"", "\"");
				U.log("quickLink:::::::::::::" + "https://icihomes.com" + quickLink);
				quickLink = "https://icihomes.com" + quickLink;
				quickHtml = U.getHtmlHeadlessFirefox(quickLink, driver);
//			quickHtml=U.getHTML(quickLink);
				U.log(commName + "::::::::::");
				String tempCName = commName + "<span>";
				quickComSec = U.getSectionValue(quickHtml, tempCName, "</section>");
				U.log("quickComSec:::::::::::" + quickComSec);
			} else {
				String navSec = U.getSectionValue(html1, "id=\"nav-movein-hover\"", "</ul>");
				String[] moveAreaUrls = U.getValues(navSec, "<a href=\"", "\"");
				for (String moveAreaUrl : moveAreaUrls) {
					U.log(moveAreaUrl);
					String moveHtml = U.getHTML(builderUrl + moveAreaUrl);
					String comMoveInHomeSections[] = U.getValues(moveHtml, "<h4 id=\"", "</section>");
					for (String comMoveInHomeSec : comMoveInHomeSections) {
						String _comName = U.getSectionValue(comMoveInHomeSec, "\">", "<span>");
						if (commName.toLowerCase().contains(_comName.toLowerCase())) {
							quickComSec = comMoveInHomeSec;
							break;
						}
					}
				}
			}

			String[] priceSecs = U.getValues(html1, "<header>", "</header>");
			String pricSec = "";
			for (String priceSec : priceSecs) {
				if (priceSec.contains(commName))
					pricSec = priceSec;
			}

			String[] sqftSecs = U.getValues(html1, "<h3 itemprop=\"name\">", "</section>");
			String sqfSec = "";
			for (String sqftSec : sqftSecs) {
				if (sqftSec.contains(commName.substring(1, 5)))
					sqfSec = sqftSec;
			}
			commName=commName.replace("eTown", "Etown");
			U.log("commName::" + commName);
			commName = commName.replace("//Palm Coast", "Palm Coast");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			html1 = html1.replace(" mid-200s", "</small> $200,000").replace("mid-$200s ", "mid $200,000 ")
					.replace("high $200&#39;s", "</small> $200,000")
					.replace("over $1 million", "over $1,000,000")
					.replace("the low $200&#39;s", "class=\"floorplan-price\">$200,000").replace("0&#39;s", "0,000").replace("0s", "0,000");
			// Price </span>|<p class=\"pricerange\">\\$\\d+,\\d+ - \\$\\d+,\\d+</p>
			String[] price = U.getPrices(html1 + quickComSec,
					"from the \\$\\d{3},\\d{3} to over \\$\\d,\\d{3},\\d{3}|the high-\\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|</small> \\$\\d+,\\d+|class=\"floorplan-price\">\\$\\d{3},\\d{3},\\d{3}</span>|class=\"floorplan-price\">\\$\\d{3},\\d+|mid \\$\\d{3},\\d{3}|\"floorplan-price\">\\$[0-9]{1},[0-9]{3},[0-9]{3}|floorplan-price\">\\$[0-9]{1},[0-9]{3},[0-9]{3}</span>|\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			if (maxPrice.equals(minPrice))
				maxPrice = ALLOW_BLANK;
			
//			U.log(Util.matchAll(html1 , "[\\w\\s\\W]{30}\\$600[\\w\\s\\W]{50}", 0));
//			U.log(Util.matchAll( quickComSec, "[\\w\\s\\W]{30}\\$1,404[\\w\\s\\W]{30}", 0));

			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			html1 = html1.replaceAll(
					"estate-sized homes over 4,000 sqft|to estate sized homes over 4,000 sqft. in the popular area| estate sized homes over 4,000 sqft, in Jacksonville",
					"").replace("from just under 1,500 sqft. to estate sized homes over 5,000 sqft",
							"Estate Residences from 1,500 to over 5,000 sqft");
			// Square Feet
			String reg = "\\d,\\d+ to \\d,\\d+ square feet|\\d+,\\d+ FT";
			String[] sqft = U.getSqareFeet(sqfSec + html1,
					"just over \\d,\\d{3} sqft.|\\d,\\d+ sqft</span> to over <span class=\"spBold\">\\d,\\d+ sqft|from \\d{4} SF to almost \\d{4} SF|range from just over \\d,\\d{3} sq ft|ranging from just under \\d,\\d{3} sqft|from \\d,\\d+ to \\d,\\d+\\+ sqft|from \\d,\\d{3} to over \\d,\\d{3} sqft|floorplan-sqft\">\\d,\\d+ ft|\\d,\\d+ - \\d,\\d+\\+ sqft|from \\d+,\\d{3} to \\d+,\\d{3} square feet|ranging from just over \\d,\\d{3} sqft|over \\d,\\d{3} sqft.| to over \\d,\\d{3} sqft|family homes over \\d,\\d{3} sqft|homes near \\d,\\d{3} sqft.",
					0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			
			html1 = html1.replaceAll(" with Traditional, Mediterranean and Spanish architectural","Traditional exterior and , Mediterranean Series")
					.replaceAll("Mediterranean and Spanish architectural styles|Mediterranean, and Spanish architectural styles", "Mediterranean Series")
					.replaceAll("building a custom estate home on|luxury homes and communities in the Jacksonville|new custom homes in Daytona Beach|low maintenance townhomes and single-family homes from 1,500 sqft.",
							"")
					.replaceAll("Courtyard Loop|kitchen patio|Model Home Patio|patio-", "");

			
			String rem1 = U.getSectionValue(html1, "<h3>Jacksonville Area</h3>", "<div class=\"area-map\">");

			if (rem1 != null)
				html1 = html1.replace(rem1, "");
			html1 = html1.replaceAll("retirment to grand estate", "");

			String dsec = U.getSectionValue(html1, "<h4>Floorplans</h4>", "Contact Us");

			html1 = U.removeSectionValue(html1, "<div class=\"reviews-table", "</footer>");

			int t = 0;
/*			String pType = U.getPropType(U.getNoHtml(html1.replaceAll(
					"low maintenance townhomes and single-family homes from 1,500 sqft.|Traditional|The Farmhouse\"></a>",
					"")));
*/			
			String flrhtml = ALLOW_BLANK;

			String dType = null;
			if (dsec != null) {
				String flrlink[] = U.getValues(dsec, "<div class=\"series-floorplan\" ", "data-hook");
				// U.log(Arrays.toString(flrlink));
				U.log("floor length::" + flrlink.length);
				for (String flr : flrlink) {
					if (t > 14)
						break;
					String flrurl = U.getSectionValue(flr, "<a href=\"", "\">");
					flrurl = "https://icihomes.com" + flrurl;
					U.log("flr url: " + flrurl);
					// flrhtml=U.getHTML(flrurl);
					try {
					String floorHtml = U.getHTML(flrurl);
					flrhtml += U.getSectionValue(floorHtml, "id=\"contentarea\"", "id=\"floorplan-media\"")
							+ U.getSectionValue(floorHtml, "<div id=\"floorplan-infobox\">", "View Floorplan</a>");
					// U.log(flrhtml);
					t++;
					}
					catch(UnknownHostException u) {
						
					}
				}
			}
			
			//remove gallary content
			String removeGallery[] = U.getValues(html1, "<div id=\"gallery-pbayg", "</div>");
			for(String remGallery : removeGallery) html1 = html1.replace(remGallery, "");
			
				html1 = html1.replace("beachside luxury ", "luxury home")
						.replace("Phase 2 - Coming Soon", "Phase 2 Coming Soon")
						.replace("Coastal, Craftsman, Vernacular and Farmhouse architectural styles",
								"Craftsman style details, coastal-style homes, Farmhouse architectural styles")
						.replace("craftsman and coastal architectural styles",
								"Craftsman style details, coastal-style homes")
						.replace("feature traditional", "traditional homes");

				if (flrhtml != null)
					flrhtml = flrhtml.replace("The Craftsman", "Craftsman style details")
							.replace("The Coastal", "coastal-style homes").replaceAll("Courtyard Loop", "");
				
//				U.log(flrhtml);
				String remSec=U.getSectionValue(html1, "Area Communities</li>", "On Your Lot</li>");
				if(remSec!=null) {
					html1=html1.replace(remSec, "");
				}
				html1=html1.replaceAll("coastal-style homes Modern|- The Coastal Modern|Appointments Coming Soon|- The Coastal\"", "").replace("coastal-style homes</span>", "");
				flrhtml=flrhtml.replaceAll("coastal-style homes Modern|- The Coastal Modern|Appointments Coming Soon|- The Coastal\"", ""); //.replace("coastal-style homes</span>", "");
				String pType = U.getPropType((html1 + flrhtml).replaceAll("The Coastal\">", "").replaceAll(
						"-townhomes-|townhomesbanner|garage apartments|quaint cottage with|The Farmhouse|16754 Courtyard Loop|16685 Courtyard Loop",
						""));
//				U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(html1 + flrhtml,"[\\w\\s\\W]{30}townhomes[\\w\\s\\W]{30}",0));

				U.log("pType===>" + pType);
				dType = U.getdCommType(flrhtml.replace("Enter the home through a split covered entry", "Enter the home through a Split-Level covered entry").replace(" 2 Stories", "2 story").replaceAll("ranch|Ranch|RANCH", ""));
				U.log("dType===>" + dType);
			
			String status = ALLOW_BLANK;
			String statSec = html1;
			String statusSection=U.getHtmlSection(statSec, "mmH2\">Persimmon Park Phase 2", "<p>");
			if(statusSection==null) {
				statusSection=ALLOW_BLANK;
			}
			String remove = "Model homes opening|<b>FOR A LIMITED TIME ONLY</b> |<img alt=\"Only 22 Lots Left| Get a|community-grand-opening\">Grand Opening|Move-In|<p>Move-In Ready</p>|omes expected to open Spring 2020|Asturia: Phase II Now Open|Closeout|Coming Soon!</span><p>|Club Coming Soon|Quick Move-in Homes Available|community are coming soon|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|<h2>Quick Move-in Homes Available in";
//			U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(statSec,"[\\w\\s\\W]{30}coming[\\w\\s\\W]{30}",0));

			statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "").replaceAll("<!--(.*)?-->", "");
			status = U.getPropStatus((statusSection+statSec + info));

			
			
			U.log("quickComSec: "+quickComSec);
			if (quickComSec != null && quickComSec.length() > 4 ) {

				if (status.length() > 1) {
					status = status + ", Move-In Ready Homes";
				} else
					status = "Move-In Ready Homes";
				
			}

			html1 = html1.replace("Grand Opening", "");
			html1 = html1.replace("<li title=\"Gated Community\"", "");
//			U.log(mainComdata);
			if(mainComdata!=null)
				mainComdata=mainComdata.replaceAll("shopping, restaurants, golf courses, and have easy access|beaches, fishing, golf, and ", "")
					.replace("residents gated privacy", "Gated Community");
			html1=html1.replaceAll("shopping, restaurants, golf courses, and have easy access|Golf Course\"| beaches, fishing, golf|Manned, Gated Security|community-grand-opening\">Grand Opening|fishing, golf, and you|that offer residents gated privacy|golf courses, and|privacy, golf|Golf Course\"|golfcourse-large|gated privacy|Gated Community\"|Resort Style Pool|resortstylepool|Manned, Gated Security|, beaches, fishing, golf, and you only want to unpack once? No problem! Tampa is a g",
					"");
			html1=html1.replaceAll("- Gated Section|Resort-Style Pool", "");
			String type = U.getCommunityType((mainComdata+html1).replace("resort-style pool|Gated Section", ""));
			if (dType == null)
				dType = ALLOW_BLANK;



			U.log("comName::" + commName);
			// status=status.replace("Grand Opening,","");
			status = status.replaceAll("Ii", "II");

			if (status.length() == 0) {
				status = ALLOW_BLANK;
			}
			if (url1.contains("/tampa/bexley"))
				pType = pType + ", Traditional Homes";
			if(url1.contains("https://www.icihomes.com/a/4/daytona-beach/chelsea-place")) {
				status=status.replace(", Move-In Ready Homes", "");
				status=status.replace("Move-In Ready Homes", "");
			}
			if (url1.contains("https://www.icihomes.com/a/4/daytona-beach/mosaic"))
			pType=pType.replace(", Estate-Style Homes, Traditional Homes", ", Estate-Style Homes");
			if(url1.contains("https://www.icihomes.com/a/1/jacksonville/etown"))
				pType=pType+", Craftsman Style Homes, Cottages";
//			if(url1.contains("brown-s-landing")) status=status+", Now Open";
////				minPrice="$341000";
////				maxPrice="$669900";
////				dType="Split Level, 1 Story";
//				pType +=", Mediterranean Style Homes";
//			}
			if(url1.contains("https://www.icihomes.com/a/2/tampa/bexley"))
				pType=pType.replace(", Patio Homes", "");
			if(status.length()==0)status=ALLOW_BLANK;
			if(url1.contains("https://www.icihomes.com/a/2/tampa/connerton")) {
				status=status+", premium home sites available";
			}
			
			
			
			LOGGER.AddCommunityUrl(url1);
			data.addCommunity(commName, url1, type);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status.replace("Opening Soon, New Phase Opening Soon", "New Phase Opening Soon"));
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
	}

	private String getHomesHtml(String url) throws IOException {

		String combineHtml = U.getHTML(url);

		return combineHtml;

		// String html

	}

	private String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;

		File folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);
		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);

		if (!f.exists()) {
			BufferedWriter writer = new BufferedWriter(new FileWriter(f));

			driver.get(url);
			// Thread.sleep(5*1000);
			U.log("Current URL:::" + driver.getCurrentUrl());
			html = driver.getPageSource();
			// Thread.sleep(5*1000);

			writer.append(html);
			writer.close();

		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}
		return html;

	}
}