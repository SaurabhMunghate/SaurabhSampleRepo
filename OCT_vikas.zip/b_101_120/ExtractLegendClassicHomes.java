package com.shatam.b_101_120;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.openqa.selenium.Alert;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLegendClassicHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int j = 0;
	private static final String baseUrl = "https://legendhomeshouston.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractLegendClassicHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Legend Classic Homes.csv", a.data().printAll());
	}

	public ExtractLegendClassicHomes() throws Exception {

		super("Legend Classic Homes", baseUrl);
		LOGGER = new CommunityLogger("Legend Classic Homes");
	}

	public void innerProcess() throws Exception {
		String html = U.getPageSource(baseUrl);

		String latdata = U.getSectionValue(html, "{\"path\":", "}}");
		String[] links = U.getValues(html, "<div class=\"w-clearfix community-card\">", "Community Details");
		U.log(links.length);
		int totalComm = links.length / 2;
		for (String link : links) {

			String url1 = baseUrl + U.getSectionValue(link, "href=\"", "\"");
			// if(inr==0||inr==totalComm||inr==totalComm+1||inr==links.length-1)
//			try {
				addDetails(url1, link + latdata);
//			} catch (Exception e) {}
			inr++;
			i++;
		}
		// addDetails("https://legendhomeshouston.com/communities/deerbrook-estates-marquis");
		// addDetails("https://legendhomecorp.com/communities/community.aspx?cid=57");
		// addDetails("https://legendhomecorp.com/communities/community.aspx?cid=47");
		LOGGER.DisposeLogger();

	}

	private void addDetails(String url, String commSec) throws Exception {
//		 if(j>= 15)
//TODO:
//		 try{
		{

//    if(!url.contains("https://legendhomeshouston.com/communities/alamosa-springs")) return;
			// Single Run
			 U.log("\n\nCount::::::::::::" + j);
			U.log("\nComm :" + url);
			
//			U.log("commSec==="+commSec);

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + ":::--REPEATED--:::::");
				return;
			}
			LOGGER.AddCommunityUrl(url);

			
			String html = U.getPageSource(url);
			html = html.replaceAll("<a(.*?)Soon</a>", "");
			
			int qCount=0;
			String quickSecHoll=U.getSectionValue(html, "Quick Move-In Homes", "Plan Designs Offered in This Community");
			if(quickSecHoll!=null) {
				String[]quickSection=U.getValues(quickSecHoll, "<div class=\"homes-label highlight\">", "</div>");
				U.log(quickSection.length);
				for (String quickUrl : quickSection) {
					if(quickUrl.contains("READY IN SEP")||quickUrl.contains("Ready to Move-In")) {
						qCount++;
					}
				}
				U.log("qCount :: "+qCount);				
			}
			
			
			//======= Near Community ==================================
			String remove = U.getSectionValue(html, " <h2>Nearby Communities</h2>", "<footer");
			if(remove!=null)
				html = html.replace(remove, "");
			//Event section
			remove = U.getSectionValue(html, "Events and Promotions</h2>", "<div class=\"section-amenities");
			if(remove!=null)html = html.replace(remove, "");
			
			// Community Name
			String commName = U.getSectionValue(commSec, "<span>", "</span>").trim();
			commName=commName.replaceAll(" - Close out| - Sold out|- Close out!|- Coming 2022|- Coming 2023| - Sold out!", "");
			U.log(j+" : Name :" + commName);
			
			if(commName!=null)
				commName = commName.replaceAll(" - Close out| - Sold out|- Close Out!|- Coming Soon(!)?|- Sold Out!| - Almost Sold Out!| - Now Open$", "");

			// Address
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geoFlag = ALLOW_BLANK;
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			
			
			String addSec = U.getSectionValue(html, "SALES OFFICE", "</a>");
//			 U.log("addsec is " + addSec);
			String rem = Util.match(addSec, "<a class=.*?\">");
			addSec = addSec.replaceAll("<a class=(.*?)>", "");
					
//			U.log("addsec is " + addSec);
			addSec = addSec.replace("<br/>", ",").replaceAll("\\s{2,}", "").trim().replaceAll("^,", "");
			U.log("addsec is " + addSec);
			String[] adds = addSec.split(",");
			U.log(Arrays.toString(adds));
			
			if(adds.length == 3) {
				
				add[0] = adds[0];
				add[1] = adds[1];
				add[2] = ALLOW_BLANK;
				add[3] = adds[2];
				
				U.log("ADDRESS FROM HERE : "+Arrays.toString(add));
				
			}
			
			

//			String cityState=U.getSectionValue(commSec, "</h4>\n" + 
//					"                                        <h4>", "</h4>");
//			U.log("cityState=="+cityState);
//			String[] citystate=cityState.trim().split(",");
//			U.log("citystate====="+citystate[0]+"       "+citystate[1]);
//			
//			add[0] = adds[0];
//			add[1] = adds[1];
//			add[3] = adds[2];
//			U.log("length====="+add[2].length());
//			
//			
//			if(add[0]!=null && add[1]!=null && add[3]!=null && add[2].length()<2 || add[2]==null) {
//				
//				add[2] = citystate[1];
//			}
			
//			if(adds[2] != null && adds[2].length() > 5){
//				
//				add[3] = Util.match(adds[2], "\\d{5}");
//				U.log(add[3]);
//				add[2] = Util.match(adds[2], "\\w{2}").replaceAll("\\d{2}", ALLOW_BLANK);
//				
//			}	
			
			add[0] = add[0].replaceAll("Legend Homes - City Park,", "");
			U.log("ADDRESS: street:" + add[0].trim() + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);

			// Lat Long
			
			// field_geofield_address_rendered":"POINT (-95.6160549 30.0971621)"
			
			commSec = U.getSectionValue(commSec, "{\"title\":\"" + commName, "\"}");
			String latlongSec=U.getSectionValue(html, "<div>SALES OFFICE", "<div class=\"sales-info");
//			U.log("latlongSec==="+latlongSec);
			if(latlongSec!=null) {
				String latlng=U.getSectionValue(latlongSec, "href=\"http://www.google.com/maps/", ">");
				lat=U.getSectionValue(latlongSec, "place/", ",");
				lng=U.getSectionValue(latlongSec, ",", "\"");
			}else {

			lat = U.getSectionValue(commSec, "\"lat\":", ",");
			lng = U.getSectionValue(commSec, "\"lon\":", ",");
			}
			if (lat == null)
				lat = ALLOW_BLANK;
			if (lng == null)
				lng = ALLOW_BLANK;
			/*
			 * if(lat!=null) geoFlag="false";
			 */
			geoFlag = "FALSE";
			String[] latlng = { lat, lng };

			if (lat == ALLOW_BLANK && add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
				String[] latLong = U.getGooleLatLong(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				lat = (latLong[0] != null) ? latLong[0] : ALLOW_BLANK;
				lng = (latLong[1] != null) ? latLong[1] : ALLOW_BLANK;

			}

			U.log("Lat:" + lat + " Long:" + lng + "add[2]:::" + add[2]);
			
			//---- Getting address from here--------
			//adding only state name into address using api.
			if(add[2] == ALLOW_BLANK) {

				String[] addresses = U.getAddressGoogleApi(latlng);
				U.log("addresses: ------ "+Arrays.toString(addresses));
				
				add[2] = addresses[2];
				U.log("FINAL ADDRESS: ------ "+Arrays.toString(add));
				
				geoFlag = "TRUE";
			}
			
			
			U.log(">>>>>  street:" + add[0].trim() + " City:" + add[1] + " ST:" + add[2] + " Z:" + add[3]);

			
//			// U.log(lat != ALLOW_BLANK && );
//			if (lat != ALLOW_BLANK && (add[2].length() < 2)) {
//				
//				String[] add1 = U.getAddressGoogleApi(new String[] { lat, lng });
//				if(add1 == null) add1 = U.getGoogleAddressWithKey(new String[] { lat, lng });
//				
//				if(add[0].length() < 2 && add[3].length() < 2)add = add1;
//				else{
//					if(add[2].length() < 2) add[2] = add1[2];
//					if(add[3].length() < 2) add[3] = add1[3];
//				}
//				geoFlag = "TRUE";
//
//			}
			
			U.log(Arrays.toString(add));
			// if(Util.match(add[2], "\\d+")!=null && add[3].startsWith("77")) {
			// add[2]="TX";
			// }

			//removes promotions and nearby community
			String news = U.getSectionValue(html, "<div class=\"views-element-container\">", "View All Promotions");
			if (news != null)html = html.replace(news, "");
			news = U.getSectionValue(html, "<div class=\"more-communities\">", "</main>");
			if (news != null)html = html.replace(news, "");
			
			// Price
			html = html.replaceAll("Was \\$\\d+,\\d+", "").replace("From the 190s", "From the $190,000")
					.replaceAll("From the \\$(\\d{3})s", "From the \\$$1,000")
					.replaceAll("From the \\$\\s+<span class=\"inline-element\">\\s+<div>\\s+(\\d{3})\\s+</div>", "From the \\$$1,000");
			
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replaceAll("</div><div class=\"details-title\">|<span class=\"inline-element\"><div>", "")
					.replace("From the $<span class=\"inline-element\"><div>", "From the $").replace("&#039;", "'");
			html = html.replaceAll("0's|0</div></span>s", "0,000");

//			U.writeMyText(html);
			
			String[] price = U.getPrices(html, "views-field-field-price[^>]+>\\s*\\$\\d+,\\d+|\\$\\d+,\\d+", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			if (minPrice == ALLOW_BLANK) {
				html = html.replaceAll("0's", "0,000s");
				price = U.getPrices(html.replace("365,490", ""), "\\$\\d+,\\d+s", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			}
//			 U.log(Util.matchAll(html, "[\\w\\s\\W]{30}365,490[\\w\\s\\W]{30}", 0));
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// Square Feet
			html = html.replace("<div class=\"detail-text detail-sq-ft\">", "Sqft ");
			
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html, "\\d{4}Sq. Ft.|Sqft\\s+\\d{4}", 0);
			//
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

			// =========== Available Plan Section ======================
			String availableSec = U.getSectionValue(html, "Plan Designs Offered in This Community", "<div class=\"views-element-container\">");
			String combinedAvailHtml = null;
			if (availableSec != null) {
				String[] availUrls = U.getValues(availableSec, "href=\"", "\"");
				U.log("total avail homes :"+availUrls.length);
				int k = 0;
				for (String availUrl : availUrls) {
				//	U.log("availUrl ::"+baseUrl+availUrl);
					combinedAvailHtml = combinedAvailHtml + U.getSectionValue(U.getPageSource(baseUrl + "/" + availUrl), "<div class=\"home-info-section\">", "<div class=\"home-views");
//					if (k == 10)
//						break;
					k++;
				}
			}
			// ========= Property Type ====================
//			String planData = getDTypeOfStory(url);
			String planData = combinedAvailHtml;
			
			String remSec = "hreflang=\"en\">Traditional Series|TRADITIONAL SERIES|Village|village|- Traditional|traditional|Evergreen Villas Hidden Meadow|Villa Nature|Villa+Nature|evergreen-villas-hidden-meadow|Katy Creek Ranch</a>|ities/valley-ranch-50s|Valley Ranch 50s</a>|valley-ranch|Valley Ranch";
			html = html.replaceAll(remSec, "");
			html = html.replaceAll("class=\"first\">Lake Lots Available", "").replace("feature\">Lake Lots Available",
					"");
			if (combinedAvailHtml != null)
				combinedAvailHtml = combinedAvailHtml.replaceAll(remSec, "");
//			
			String pType = ALLOW_BLANK;
			html = html.replace("Luxury Vinyl Plank Flooring", "luxury finishes Vinyl Plank Flooring")
					.replaceAll("<h4 class=\"heading-3\">\n\\s*Traditional Series", "<h4 class=\"heading-3\">\n" + 
							"                                    - Traditional Series")
					.replaceAll("<div class=\"series\"><div>Traditional Series</div></div>|<div>TRADITIONAL SERIES</div></a>", "Traditional exterior");
			
			pType = U.getPropType((html + planData + combinedAvailHtml + commName).replaceAll(
					"Katy Creek Ranch Traditional|files/community/Traditional|Merrylands Traditional|TRADITIONAL SERIES|Village|Villa", ""));
			 
//			U.log("MMMMMMMM "+Util.matchAll(html, "[\\s\\w\\W]{100}Traditional[\\s\\w\\W]{100}", 0));

			 U.log("pType====="+pType);
			 // =============== Derived Property Type==========================
			String derivedPType = ALLOW_BLANK;
//			derivedPType = U.getdCommType(html);

			// Property Status
			String pStatus = ALLOW_BLANK;
			String unwanted=U.getSectionValue(html, "<h2>Nearby Communities</h2>","  </main>");
			if(unwanted!=null)
				html=html.replace(unwanted, "");
			pStatus = U.getPropStatus(html);
			
			
			String note = ALLOW_BLANK;

			String ss = U.getSectionValue(html, "<p id=\"community-directions\">", "<br /");
			if (ss != null && ss.trim().length() > 6)
				add[0] = ss;

			html = html.replaceAll("Ranch|ranch", "");
			
			if(planData != null)
				planData = planData.replace("Stories</h4><h3 class=\"input\">1</h3>", " Stories 1")
				.replaceAll("Stories\\s+</h4>\\s+<h3 class=\"input\">\\s+(\\d\\.?\\d?)\\s+</h3>", " $1 Story ");
			
//			U.writeMyText(planData);
			
			//U.log("planData::" + planData);
			String dType = U.getdCommType(html + commName + url + planData);
			U.log("dType====="+dType);

			// ======== Quick Sec =============
			HashSet<String> quickUrlSet = new HashSet();
			String quickSec = U.getSectionValue(html, "Quick Move-In Homes", "Plan Designs Offered in This Community");
//			U.log(quickSec);
//			U.log("quickSec==="+quickSec);
			int q=0;
			if (quickSec != null) {
				String[] quickUrls = U.getValues(quickSec, "<div class=\"homes-label\">", "DETAILS");
				U.log("quickUrls=="+quickUrls.length);
				for (String quickUrl : quickUrls) {
					quickUrlSet.add(quickUrl);
					if(quickUrl.contains("READY IN SEP")||quickUrl.contains("READY TO MOVE-IN")) {
						q++;
					}
				}
					
			}
			U.log("q Count :: "+q);
			html = html.replace(
					"No homes available</div></div></div><div class=\"w-clearfix w-tab-pane\" data-w-tab=\"Tab 3\">",
					""); // floorplan


			
			html = html.replace("Quick Move-In Homes", "");
			String status = U.getPropStatus((html
					.replace("USDA Financing ", "")
					.replaceAll("move|Move|MOVE", "")).replaceAll(
					"Waterfront Lots Available|<h2>Quick Move-In Homes</h2>|close-out\"|sold-out\"|<p class=\"first\">Waterfront Lots Available</p>|>Coming Soon</a></div></div><|currently under construction",
					""));
//			 U.log(Util.matchAll(html, "[\\w\\s\\W]{30}usda[\\w\\s\\W]{30}", 0));
			System.out.println("Status:\t" + status);
//			if (quickUrlSet.size() > 0) {
				if (q > 0||qCount>0) {
//				if (!status.contains("Quick Move")) {
					if (status == ALLOW_BLANK)
						status = "Quick Move-In Homes";
					else
						status += ", Quick Move-In Homes";
//				}
			}
             
			status=status.replace("Coming Soon, Coming 2023","Coming 2023").replace("Coming Soon, Coming 2022","Coming 2022");
			
			commName = commName.replace(" - Traditional", "");

//			if (url.contains("https://legendhomeshouston.com/communities/hunters-creek"))
//				status = "Quick Move-In Homes";// Img
			// U.log(html);
//			U.log(Util.matchAll(html, ".*Close Out.*", 0));
			
			
			html = html.replace("Messina Hof Winery and Resort", "Messina Hof Winery and Resort experience")
					.replace("lakeside restaurants and resorts", "lakeside restaurants and Resort experience ");
			
			if(url.contains("https://legendhomeshouston.com/communities/hunters-creek-coming-soon"))add[2]="TX";
			if(url.contains("https://legendhomeshouston.com/communities/enchanted-bay-coming-soon"))minSqf="863";
			
			if(url.contains("communities/alamosa-springs"))status=status.replace(", Quick Move-In Homes", "");

			//---------------- cType--------------
			String cType = ALLOW_BLANK;
			cType = U.getCommunityType(html.replaceAll(
					"Waterfront Lots Available|\"Thorntree Golf Club|title\":\"(The Golf Club at Cinco|Southwyck Golf)|title\":\"Cypresswood Golf|title\":\"Meadowbrook Golf Course\"|Top Golf|BPgolFZRm5kKd-4y4NV49EG9U|Topgolf|title\":\"Traditions Golf|Country View Golf|title\":\"Pine Forest Country|Terrace Golf Course|Oakhurst Country Club|Bayou Golf Course|Pines Golf Course|Eagle Pointe Golf| 55s</a><a | 55s</span>", ""));
			
			U.log("cType====="+cType);
			
			//----------------------------------------------------------------------------------------------------
			
			data.addCommunity(commName.replace("&#039;", "'").replace("- Close Out!", ""), url, cType);
			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(lat, lng, geoFlag);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);

		}
		j++;
//		 }catch (Exception e) {
//		 // TODO: handle exception
//		 }
	}

	private String getDTypeOfStory(String url) throws IOException {
		String cHtml = U.getHTML(url);
		// U.log("tttttt"+cHtml);
		String homeHtml = ALLOW_BLANK, storiesSec = ALLOW_BLANK;
		if (cHtml.contains("w-clearfix details-link\" href=\"")) {
			String[] homeUrls = U.getValues(cHtml, "w-clearfix details-link\" href=\"", "\"><div class=\"details\">");
			// U.log("Total Homes Urls:::"+homeUrls.length);

			for (String homeUrl : homeUrls) {
				U.log("homeUrl::" + homeUrl);
				homeHtml = U.getHTML(baseUrl + homeUrl) + homeHtml;
				storiesSec = U.getSectionValue(homeHtml, "Stories</h4><h3 class=\"input\">", "</h3") + " Stories ,"
						+ storiesSec;
				if (homeHtml.contains("Covered Patio")) {
					storiesSec = storiesSec + " Covered Patio ";
				}
				// storiesSec=storiesSec + " Story ,";
				if (storiesSec.contains("2 Story") && storiesSec.contains("1 Story")) {
					break;
				}
			}
		}
		return storiesSec;

	}

}