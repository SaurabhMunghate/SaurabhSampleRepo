/**
 * @author Parag Humane 
 * @date 24/04/2012
 * 
 */
package com.shatam.b_101_120;

import java.io.IOException;
import java.lang.reflect.Array;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSchellBrothers extends AbstractScrapper 
{
	int k = 0;
	static int j=0;
	public int inr = 0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	private static String[] commTypes = new String[] { "Condo", "Town Home","Twin Home", "Single Family" };

	public static void main(String[] args) throws Exception 
	{
		AbstractScrapper a = new ExtractSchellBrothers();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Schell Brothers.csv", a.data()
				.printAll());
		U.log(duplicates);
	}

	public ExtractSchellBrothers() throws Exception 
	{

		super("Schell Brothers", "https://schellbrothers.com/");
		LOGGER = new CommunityLogger("Schell Brothers");
	}

	public void innerProcess() throws Exception 
	{
		U.setUpChromePath();
		driver=new ChromeDriver();
		// Your code here
		String[] cummunitylist={
				"https://schellbrothers.com/find-new-homes/delaware-beaches/",
				//"https://schellbrothers.com/find-new-homes/northern-delaware/",
				"https://schellbrothers.com/find-new-homes/richmond-virginia/"
				};
		
		for(String l:cummunitylist)
		{
			String html = U.getHTML(l);
			U.log(U.getCache(l));
			
			html = html.replaceAll("<!--.*?-->", "");
			String[] comm = U.getValues(html, "<td data-community-name", "</tr>");
			U.log("comm.length: "+comm.length);
	
			for (int i = 0; i < comm.length; i++) 
			{
				//U.log("==="+comm[i]);
				
				Set<String> uniqueUrlSet = new HashSet<>();
				String[] comUrls = U.getValues(comm[i], "<a href=\"", "\"");
				for(String comUrl : comUrls){
					if(comUrl.equals("javascript:;"))
						continue;
				
					U.log("comUrl: "+comUrl);
//					try {
						addDetails(comUrl, comm[i]);
//					} catch (Exception e) {}
				}
				
				uniqueUrlSet = null;
				
			}
		}
		LOGGER.DisposeLogger();
//		driver.quit();
	}

	//TODO : Extract communities details here
	private void addDetails(String url, String info) throws Exception 
	{
		
		{
//	if(!url.contains("https://schellbrothers.com/find-new-homes/richmond-virginia/river-mill/")) return;
	//	SINGLE RUNJ		 
//		if(!url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/haileys-glen/"))return; //to execute single community
		
		U.log("Count: "+j);
		U.log("PAGE :" + url);
		//Please check for next month
		 
		 if (url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/discover-coastal-delaware/")) {
			 return; 
		 }
	//	U.log(info);
		String commTypeSec=U.getSectionValue(info, "<div class=\"community-oneliner show-for-landscape show-for-large-up\">", "</div>");
		if (this.data.communityUrlExists(url)) 
		{
			duplicates++;
			LOGGER.AddCommunityUrl(url+"::::::::::Repeated::::::");
			return;
		}
//		if(url.contains("https://schellbrothers.com/find-new-homes/richmond-virginia/newmarket/")) {
//			LOGGER.AddCommunityUrl(url+"::::::::::ReDirected to region::::::");
//			return;
//		}
//		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/haileys-glen/")) {
//			LOGGER.AddCommunityUrl(url+ "---------------------------------404 ERROR");
//			return;
//		}
//		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/welches-pond/") ||
//		   url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/estate-lots-on-new-road/")) {
//			LOGGER.AddCommunityUrl("=======redirected============"+url);
//			return;
//		}
		
		LOGGER.AddCommunityUrl(url);
		
       // U.log(info);
//		String html=U.getHtml(url, driver);
		String html = U.getHTML(url);
		U.log(U.getCache(url));
		//U.log("MMMMM"+Util.matchAll(html,"[\\w\\s\\W]{30}\\$389,900[\\w\\s\\W]{30}", 0));
		String nearcommSec = U.getSectionValue(html, "<div id=\"communities\">", "<div class=\"block-osc-help\">");
		if(nearcommSec!=null)
		html=html.replace(nearcommSec, "");
		html=html.replaceAll("cottage/\" >Coastal Cottage Series|Old Landing Golf Course|content=\"Coastal Club in Lewes is a luxury resort new hom", "");
		html=html.replaceAll("\"series\">Coastal Cottage Series", ""); 
		html=html.replaceAll("\"legend-title\">Coastal Cottage Homesites", ""); 
		html=html.replaceAll("cottage\"></div>", ""); 
		html=html.replaceAll("Coastal Cottage Series\">", ""); 
		html=html.replaceAll("New Phase\">", ""); 
		html=html.replaceAll("now open!", ""); 
		
		String nbcomm = U.getSectionValue(html, "Nearby Communities</h5>", "</html>");
		if(nbcomm!=null)
		html = html.replace(nbcomm, "");
		

		// commName
		String commName = U.getSectionValue(info, "<span class=\"community-name\">", "<");
		commName=commName.replace("Your Lot, Our Home", "Your Lot");
		U.log("Name :" + commName);
	
		String geo = "FALSE";
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String sectionMapLink = U.getSectionValue(info,
				"data-bounds=\"in\" data-location=\"", "\"");
		if (sectionMapLink != null) 
		{

			lat = Util.match(sectionMapLink, "\\d{2}\\.\\d{3,}");
			lng = Util.match(sectionMapLink, "-\\d{2}\\.\\d{3,}");

			if (lat == null) 
			{
				lat = ALLOW_BLANK;
				lng = ALLOW_BLANK;
			}

		}

		U.log("Lt: " + lat + " Lng: " + lng);

		

		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK };

		// String[] addr = U.getGoogleAddress(gglHtm);
//		U.log(info);
		info=info.replace("<br/>(302)&nbsp;778-9668", "");
		String adds = U.getSectionValue(info, ".png\">", "</div>");
		
		U.log("adds::"+adds.trim());
		
		if(adds != null) {
			adds = adds.replace("27117 SAILSIDE DR ", "27117 Sailside Dr");
			U.log("adds inside: "+adds.trim());
		}
		if(url.contains("/richmond-virginia/forest-hills-at-magnolia-green/")) adds = ALLOW_BLANK; //not showing up
		
//         if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/marlin-chase/")) {
//			add[1]="Ocean View";
//			add[2]="DE";
//			String[]latlng=U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latlng);
//			
//		}
	
		
		if(add[0]==ALLOW_BLANK && adds!=null && adds.trim().length()>13)
		{
		adds = adds.replace("<br/>", ",");
		U.log("adds::"+adds);
		adds =adds.replaceAll(",\\s*,", ",");
		String[] addr = adds.split(",");
		add[0] = addr[0];
		add[1] = addr[1];
		
		
		add[2] = Util.match(addr[2], "\\w{2}");
		add[3] = Util.match(addr[2], "\\d{5}");

		if (lat == ALLOW_BLANK) 
		{
			String[] latlng = U.getlatlongGoogleApi(add);
			lat = latlng[0];
			lng = latlng[1];
			geo = "true";
		}
		}
		

		U.log("street:" + add[0].trim() + " City:" + add[1] + " ST:" + add[2] + " Z:"
				+ add[3]);

		// Price
		
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String temp = U.getSectionValue(html,
				"<div id=\"block-holiday-schedule\">", "</ul>");
//		U.log(Util.match(html, ".*\\$500.*"));//<strong>\\$\\d,\\d{3},\\d{3}</strong>
		html=html.replaceAll("content=\"Single-Family homes from the high \\$500s|<strong>\\$1,900,000</strong>|<span class=\"nowrap\">\\$\\d,	\\d{3},\\d{3}</span>|<span class=\"nowrap\">\\$\\d{3},\\d{3}</span>\\s+<span class=\"nowrap\">-\\s+\\$\\d+,\\d+\\s+<!--limited-->\\s+incentive</span>", "").replace("$300s to $3M", "$300,000 to $3,000,000 ").replace("<strong>$2,100,000</strong>", "");
		//U.log(html);
		html = html.replace("high $200s</li>", "high $200,000");
		html = html.replaceAll("high \\$(\\d+)s", "\\$$1,000");
		html = html.replaceAll("<br/>- \\$\\d+,\\d+", "");
		html = html.replaceAll("0s|0’s", "0,000");
		html=html.replace("0k", "0,000");
		//U.log("MMMMM"+Util.matchAll(html,"[\\w\\s\\W]{30}\\$389,900[\\w\\s\\W]{30}", 0));

//		U.writeMyText(html);
		String[] price = U
				.getPrices(
						(html).replace("<strong>$785,880</strong>", ""),
						"\\$\\d{3},\\d{3}.*|for Quick Move-In\\s+<strong>\\$\\d{3},\\d{3}</strong>|\\$\\d{3},\\d{3} to \\$\\d{1},\\d{3},\\d{3}|Townhomes from the low \\$\\d{3},\\d{3}|Single-family homes from the low \\$\\d{3},\\d{3}|high \\$\\d+,\\d+|from the (high|mid) \\$\\d+,\\d+|from the \\$\\d+,\\d+|strong class=\\\"price\\\">\\$\\d,\\d{3},\\d{3}|strong class=\"price\">\\$\\d{3},\\d+|Single family homes from the(.*?)\\$\\d{3},\\d+|class=\"price\">\\s*from\\s*<strong>\\$\\d{3},\\d+|"
						+ "From <strong>\\s*\\$(\\d{3},\\d+)|from the high \\$\\d{3},\\d+|from</span>\\s*\\$\\d{3},\\d+<sup>|<strong>\\$\\d,\\d{3},\\d{3}</strong>|the high \\d{3},\\d{3}",
						0); //+info
		
		
						//for Quick Move-In\\s+<strong>\\$\\d{3},\\d{3}</strong>
//		U.log(Util.match(html, ".*\\$2,10.*"));
//		U.log("MMMMM"+Util.matchAll(info,"[\\w\\s\\W]{30}769,900[\\w\\s\\W]{30}", 0));
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		if (minPrice == ALLOW_BLANK) 
		{
			price = U.getPrices(html, "<strong>\\s*\\$(\\d{3},\\d+)", 1);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		}
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log("MMMMM"+Util.matchAll(html,"[\\w\\s\\W]{30}769,900[\\w\\s\\W]{30}", 0));
//		U.log("MMMMM"+Util.matchAll(info,"[\\w\\s\\W]{30}769,900[\\w\\s\\W]{30}", 0));
		
		
		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/peninsula-lakes/"))minPrice="$389900";
//		if(url.contains("https://schellbrothers.com/find-new-homes/richmond-virginia/mosaic-at-west-creek/")) {
//			minPrice="$504900";
//			maxPrice="$579900";
//		}
		
		
		
		// Square Feet//
		html=html.replaceAll("</strong>\\s*<small>Heated Sqft</small>", " Heated Sqft");
		String[] sqft= {};
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;// class="sqftage">
//		String sec = U.getSectionValue(html, "<span class=\"sqftage\">","<div id=\"sidebar\"");
		//U.log("secSqreeFeet:" + U.getSectionValue(html, "<ul class=\"detail-stats large-block-grid-1 small-block-grid-1\">", "<small>Heated Sqft</small>"));
		if(url.contains("https://schellbrothers.com/find-new-homes/richmond-virginia/the-highlands/")) {
			String[] floorplansUrls=U.getValues(html, "<td data-quick-name data-sort-value=", "<div class=\"large-3 medium-3 small-3 columns\">");
			String fHtml="";
			for(String floorUrl:floorplansUrls) {
				
				floorUrl=U.getSectionValue(floorUrl, "href=\"", "\"");
//				U.log("floorUrl::: "+floorUrl);
				fHtml+=U.getHTML(floorUrl);
			}
			sqft = U
					.getSqareFeet(
							html+fHtml,
							"<strong>\\d,\\d{3}|xpansive \\d,\\d{3} square foot mansion |<strong>\\s*\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*</strong>|\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*Heated Sqft|\\d,\\d{3}\\s*Heated Sqft",
							0);
			//<strong>\\d,\\d{3}\\W+\\s*\\- \\d,\\d{3}</strong>|<strong>\\d,\\d+\\s+- \\d,\\d+</strong>\\s+<small>Total Sqft</small>\\s+|\\d,\\d+\\s+Total Sqft|<strong>\\d,\\d+\\s+</strong>\\s+Total Sqft|<strong>\\d,\\d{3} \\W+\\- \\d,\\d{3}</strong>
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		}else {
		sqft = U
				.getSqareFeet(
						html,
						"xpansive \\d,\\d{3} square foot mansion |<strong>\\s*\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*</strong>|\\d,\\d{3}\\s*-\\s*\\d,\\d{3}\\s*Heated Sqft|\\d,\\d{3}\\s*Heated Sqft",
						0);
		//<strong>\\d,\\d{3}\\W+\\s*\\- \\d,\\d{3}</strong>|<strong>\\d,\\d+\\s+- \\d,\\d+</strong>\\s+<small>Total Sqft</small>\\s+|\\d,\\d+\\s+Total Sqft|<strong>\\d,\\d+\\s+</strong>\\s+Total Sqft|<strong>\\d,\\d{3} \\W+\\- \\d,\\d{3}</strong>
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		}
		html = html
				.replace("Options range from a 2,500 square foot “bungalow”", "Options range from a 2,500 square foot “bungalow homes”")
				.replaceAll("-cottage-|courtyard/\" >Courtyard Series</a>|craftsmanship|2 years of HOA fees, in addition to Toda|luxurious kitchens|luxurious entrance|a traditional|HOA offices|about HOA|The HOA|the HOA|the hoa|maintenance of the common areas.</p>|of the common areas|common area landscaping and|Most of the common areas will be sodded|>The Estates at Redd", "");
		// Property Type
		String propertyType = ALLOW_BLANK;
		

		

		add[0] = add[0].replace("(", "");
		
		String status = ALLOW_BLANK;//.replaceAll("Basements Available\"></div>|title\">Basements Available</div>", "").replace("basements","Basement Available")
		String statSec = html.replace("Walk out <br/>basements available", "Walkout basements available")
				
				.replace("only <strong>81 unique homesites</strong> available", "only 81 homesites available").replace("New Homesites <span class='nowrap'>Just Released", "New Homesites Just Released").replace("Basement lots <br/> available", "Basement lots available").replace("2 Signature Homesites Available", "2 Homesites Available").replace("Now selling our final homesites", "Now selling final homesites")
				.replace("Only 2 basement <br>opportunities remain", "Only 2 basement opportunities remain").replace("up\">Quick Move-In opportunity</div>", "up\">Quick Move-in Homes</div>").replace("only <strong>81 unique homesites</strong> available", "only 81 unique homesites available")
				.replaceAll("<span class=\"info label\">\\s+Coming Soon|<strong>Lakefront lots</strong>|<strong>Basement<br/> homesites</strong>|<strong>Wooded<br/> homesites</strong>", "")
				.replace("walk out basement lots", "walk out basement available");
		String remove = "quick move-in</h2>|content=\"Best homesites now available.\"/>|25 homes sold in 2018|le\">Quick Move In Home</div>|Opening Soon:</span>|This is the final phase|view lots now available|Croix Grand Opening|promotion quick-move-in\">|y\">Quick Move-In</div>|Now Open Onsite|special grand opening incentive|get our grand opening incentive of|now available at Bayside in| radius\">Coming Soon</span> Construction will begi|Best homesites now available|Incentives now available|alert\">Coming Soon|Model Now Open|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT|Clubhouse coming soon|New Model Now Open|Take advantage of close out savings up|Club: Now|Selling Twin|Selling in Nantucket|is your last|neighborhood sold|Neighborhood Selling|Twin Homes Now|Selling Nantucket|Shearwater Grand|newport grand|model grand|opening of our|Chesapeake Grand|Models are Now";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		statSec = U.removeComments(statSec);
		
//		U.log(">>>>>>>>>"+Util.matchAll(statSec+info, "[\\s\\w\\W]{30}Basement Available[\\s\\w\\W]{30}", 0));

	
		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/solitude-on-white-creek/")) info =  info.replace("Available for Quick", "");
		info = info.replace("features lakefront & wooded homesites", "");

			if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/governors/")) {
				statSec=statSec.replace("coming soon", "");
			}
		status = U.getPropStatus((statSec+info).replaceAll("wanted with walk out basement|school – coming|[Q|q]uick [M|m]ove|content=\"Best homesites now available|label=\"walden: grand|(c|C)?enter(s)? are now|lilac grand opening|model grand opening|and we have limited|have just released|grand opening incentive|Model Grand Opening|19 homes sold on our launch weekend|Base price includes lot cost. Some lots have |Basement homesites available|neighborhood almost sold out|<div class=\"legend-title\">Available Homesites</div>|<div class=\"legend-title\">Available Homesites</div>|Now Selling</h2>|now selling</h2>|now selling\">",""));
	
		U.log("Status: "+status);
		if (status.equals("Quick Move-in")) {
			status="Quick Move In Homes";
		}
		status=status.replaceAll("New Homesites Coming Soon", "");
		
		if(statSec.contains("ready to move? no need to wait")) status=status.replaceAll("Quick Move-in Homes", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
		/*
		 * U.log(latLong[0]); U.log(latLong[1]);
		 */


		if (temp != null)
			temp = Util.match(temp, "\\$\\d{3}");

		if (temp != null)
			minPrice = Util.match(temp, "\\$\\d{3}").trim() + ",000";

		// Add all
		add[2] = "DE";
		if (url.contains("https://schellbrothers.com/seagrass-plantation/"))
			status = "Only 2 Homesites Remain";
      //  if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/peninsula-lakes"))status="Basement and Wooded Homesites Available, Lakefront Lots";
		if (html.contains("Quick Move-in Homes</small>") || html.contains("<h2> Quick Move-In Homes </h2>") || html.contains("<div class=\"show-for-medium-up\">Quick Move")) 
		{
			
			if (status == ALLOW_BLANK) 
			{
				status = "Quick Move-in Homes";
			} else
				status = status + ", Quick Move-in Homes";
		}
		status  =status.replace("New Lots Now Available, Now Available", "New Lots Now Available");
		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/on-your-property/"))
		{
			lat = "38.695086";
			lng = "-75.2151";
			add = U.getAddressGoogleApi(new String[]{lat,lng});
			if(add == null)add = U.getAddressHereApi(new String[]{lat,lng});
			geo = "True";
		}
		
		if(add[0].length()<4 || add[3].length()<4) {
			String[] lalong= {lat,lng};
			add=U.getAddressGoogleApi(lalong);
			if(add == null) add = U.getAddressHereApi(lalong);
			geo="TRUE";
		}
		
		add[0]=add[0].replace("(", "").replace(".", "").replace(",", "");
		
		//=======Unit Count=======================
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		if(html.contains("interactive-siteplan")) {//interactive-siteplan
		String lotUrl=url+"#community-siteplan";
		U.log("lotUrl ::"+lotUrl);
		
		String lotHtml=U.getHtml(lotUrl, driver);
		U.log("comm cache path"+U.getCache(lotUrl));
		int lotCount=0;
		if(lotHtml!=null) {
			String[] lotPart1=U.getValues(lotHtml, "<polygon id=\"", "\"/>");
			for(String lotSec:lotPart1) {
				lotCount++;
			}
			String[] lotPart2=U.getValues(lotHtml, "<path id=\"", "\"/>");
			for(String lotSec:lotPart2) {
				lotCount++;
			}
			String[] lotPart3=U.getValues(lotHtml, "<rect id=\"", "\"/>");
			for(String lotSec:lotPart3) {
				lotCount++;
			}
			counting=Integer.toString(lotCount);
		}
		}
		
		U.log("counting ::"+counting);
		
		//-------derived Type---------------
		//--------------code to fetch 1 story & 2story from floor present on individual plan page ---------------------
		String StoryFromPlan=getPlan(html);
		html=html.replaceAll("<dd><a href=\"#\" data-filter=(.*?)</dd|Branch ", "").replaceAll("(f|F)loor", "");
//		U.log(StoryFromPlan);
		if(StoryFromPlan != null)StoryFromPlan = StoryFromPlan.replaceAll("(f|F)loor|-cottage-", "");
		
		html = html.replaceAll("data-filter-ranch\\s+>", "data-filter-ranch> Ranch Style");
//		U.log(Util.match(html, "data-filter-ranch"));

		String filter=ALLOW_BLANK;
		if(html.contains("data-filter-master_down")) {
			filter=" 1 Story ";
			
		}
		if(html.contains("data-filter-master_up")) {
			filter=" 2 Story ";
		}
		if(html.contains("data-filter-master_up") && html.contains("data-filter-master_down")) {
			filter=" 2 Story  1 Story ";
		}
//		U.log("StoryFromPlan ::"+StoryFromPlan);
		String nohtmlStory = ALLOW_BLANK;
		if(StoryFromPlan != null) {
			nohtmlStory = U.getNoHtml(StoryFromPlan);
		}
		String dType=U.getdCommType((html+StoryFromPlan +filter));
//		
	
		propertyType = U.getPropType((html+nohtmlStory).replaceAll("Single Family Floor Plans|common area maintenance|common areas are also included|Single Family Floor Plans|patio bar|elevated patios|upstairs loft|Estate Lots on New Road|common area maintenance including ponds|Optional Elevation Craftsman|Optional Elevation Modern Farmhouse|alt=\"The Jasmine Optional Elevation Modern Farmhouse\"|\\d+,\\d+ square foot “bungalow|title\">Available Villa|Village|title=\"Available Villa|available-villas\"", ""));
		/*if (propertyType == ALLOW_BLANK)
			propertyType = "Single Family";*/
		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/the-peninsula/"))propertyType=propertyType.replace("Single Family, ","");
		U.log("Type:" + propertyType);

		U.log("dType:::"+dType);
		
		html=html.replace("irrigated", "");
		
		if(url.contains("/delaware-beaches/the-peninsula/?neighborhood=sailside")){
			commName = "Sailside";
			maxPrice="$459,900";
		}
//		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/independence/"))
//			status=status+", Homesites Now Available";
		

		String rem = U.getSectionValue(html, "<head>", "</head>");
		if(rem != null)
			html = html.replace(rem, "");
		//status = status.replace("Quick Move-in", "Quick Move-in Homes");

//		if(url.contains("https://schellbrothers.com/find-new-homes/delaware-beaches/the-peninsula/")) {
//			
//			status=ALLOW_BLANK;
//			propertyType+=", Bungalow Homes";
//		}
//		U.log("nnnnn"+Util.matchAll(html,"[\\w\\W\\s]{30}Lakefront[\\w\\W\\s]{30}",0));
		html = html.replaceAll("<strong>Lakefront lots</strong>|Lakefront\n\\s*lots", "Lakefront Community").replace("sparkling community lake", "Lakefront Community");
//		U.log("nnnnn1"+Util.matchAll(html,"[\\w\\W\\s]{100}Lakefront Community[\\w\\W\\s]{100}",0));
		String cType= U.getCommunityType((html+commTypeSec).replaceAll("Resort style living at its best!|master-planned lifestyle community|Lake oriented resort-style community|resort-style clubhouse|Beach resort area|with resort living in mind", ""));

		if(status!=null)
			status = status.replace("Sold-out", "Sold Out");
		
		
		
		
		//-----------Added data in csv-----------------

		
		data.addCommunity(commName, url,cType);
		data.addAddress(add[0], add[1],
				add[2], add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(propertyType, dType);
		data.addPropertyStatus(status.replace("-,", ""));
		data.addNotes(U.getnote(html.replace("opening for sales in late August", "")));
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);

		}
		j++;
	}
	private String getPlan(String cHtml) throws IOException
	{
		String[] planUrls=U.getValues(cHtml, "<div class=\"panel\" data-equalizer-watch>", "<div class=\"status-icon\">");
		int x = 0;
		String combinedHtml = null;
		U.log("Home counts ::"+planUrls.length);
		for(String planUrl: planUrls)
		{
			planUrl = U.getSectionValue(planUrl, "<a href=\"", "\"");
//			U.log("planUrl::"+planUrl);
			String planHtml=U.getHTML(planUrl);
			String section = U.getSectionValue(planHtml, "<h1 class=\"subheader", "<div class=\"block-osc");
			combinedHtml += section;
			if(x++ == 10)break;
		}
		return combinedHtml;
	}
	

}