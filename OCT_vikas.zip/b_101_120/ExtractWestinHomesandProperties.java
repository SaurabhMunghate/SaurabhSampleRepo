/* Modification Aditya
 *  @ ashish shivhare */
package com.shatam.b_101_120;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.apache.regexp.recompile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;

import netscape.javascript.JSObject;

public class ExtractWestinHomesandProperties extends AbstractScrapper {
	public int inr = 0;
	CommunityLogger LOGGER;
	String geo;
	String latlngs[];
	static WebDriver driver = null;

	public static void main(String[] arg) throws Exception {
//		U.setUpGeckoPath();
//		driver =new FirefoxDriver();
		
		AbstractScrapper a = new ExtractWestinHomesandProperties();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Westin Homes.csv", a.data()
				.printAll());
	}

	public ExtractWestinHomesandProperties() throws Exception {
	
		super("Westin Homes", "https://www.westin-homes.com/");
		LOGGER = new CommunityLogger("Westin Homes");

	}
	
	public void innerProcess() throws Exception{
		String regHtml ="";
		String regions[] = {"Austin","Houston"};//add new regions if avialble in future
		String homeHtm= U.getPageSource("https://www.westin-homes.com/_dm/s/rt/actions/sites/118b5d99/collections/Search%20Homes/ENGLISH");
		String plansHtml = U.getPageSource("https://www.westin-homes.com/_dm/s/rt/actions/sites/118b5d99/collections/Search%20Plans/ENGLISH");
		String homes[] = U.getValues(StringEscapeUtils.unescapeJava(homeHtm.replace(" – ", " - ")), "{\"uuid\":", "\"page_item_url\":");
		String plans[] = U.getValues(StringEscapeUtils.unescapeJava(plansHtml.replace(" – ", " - ")), "{\"uuid\":", "\"page_item_url\":");
		U.log(homes.length+":"+plans.length);
		for(String reg:regions) {
			String regUrl = "https://www.westin-homes.com/_dm/s/rt/actions/sites/118b5d99/collections/"+reg+"%20Comms/ENGLISH";
			regHtml= U.getPageSource(regUrl);
//			U.log(regUrl);
 			String commSec[] = U.getValues(StringEscapeUtils.unescapeJava(regHtml), "{\"uuid\":", "\"page_item_url\":");
// 			U.log(commSec.length);
 			for(String sec:commSec) {
 				sec = sec.replaceAll("\".*\",\"data\":", "{\"data\":")+"}";
 				sec = sec.replace("},}", "}}");
 				JsonParser parser = new JsonParser();
 				JsonObject jsObject =(JsonObject)parser.parse(sec);
// 				U.log(jsObject);
 				String homeHtml = "";
 				String planHtml="";
 				
 				//comUrl 
 				String comUrl = "https://www.westin-homes.com/communities/"+jsObject.get("data").getAsJsonObject().get("DudaUrl").toString().replace("\"", "");
// 				U.log("comUrl: "+comUrl);
 				
 				// community name
 				String commName = jsObject.get("data").getAsJsonObject().get("Name").toString().replace("\"", "");
 				commName = commName.replace("â", "-").replace("ARTAVIAÂ®", "ARTAVIAA").toLowerCase();
// 				U.log("comName: "+commName.replace("â", "-"));
 				
 				//homeHtml 
 				final String parentComID = U.getSectionValue(sec, ",\"Id\":", ",");
// 				U.log(parentComID);
 				
 				//homelist contains all plans and homes as well
 				List<String> homesList = Arrays.asList(homes).stream().filter(x -> x.contains(parentComID)).map(pm ->pm).collect(Collectors.toList());;
// 				U.log("homesList: "+homesList.size());
// 				List<String> plansList = Arrays.asList(plans).stream().filter(x -> x.contains(parentComID)).map(pm ->pm).collect(Collectors.toList());;
// 				U.log("plansList: "+plansList.size());
 				
 				//address 
 				String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
 				String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
 				String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
 				add[0] = jsObject.get("data").getAsJsonObject().get("Addr").toString().replace("\"", "");
 				add[1] = jsObject.get("data").getAsJsonObject().get("City").toString().replace("\"", "");
 				add[2] = jsObject.get("data").getAsJsonObject().get("State").toString().replace("\"", "");
 				add[3] = jsObject.get("data").getAsJsonObject().get("Zip").toString().replace("\"", "");
// 				U.log("addrs: "+Arrays.toString(add));
 				lat = jsObject.get("data").getAsJsonObject().get("Lat").toString().replace("\"", "");
 				lng = jsObject.get("data").getAsJsonObject().get("Lng").toString().replace("\"", "");
 				latLong = new String[] {lat,lng};
// 				new FileWriter(new File("/home/shatam-17/Cache/dummy.txt")).write(homesList.toString());
// 				try {
 					addDetailsNew(comUrl, commName, latLong,add,homesList, jsObject.toString());
// 				} catch (Exception e) {}

 			}
		}
		LOGGER.DisposeLogger();

	}
	
	

	private void addDetailsNew(String comUrl, String commName, String[] latLong, String[] add, List<String> homesList, String comSec) throws Exception{
		// TODO Auto-generated method stub
		if(comUrl.contains("https://westin-homes.com/subdivision/creekside-park-west-65")) {
			LOGGER.AddCommunityUrl("=======return"+comUrl);
			return;
		}
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("=======repeated"+comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

//SINGLE EXECUTION----------------------------------------------------		
//		if(!comUrl.contains("https://www.westin-homes.com/communities/Oaks-of-San-Gabriel-168490")) return;
		
		U.log("comSec: "+comSec);
		U.log("Lat-Lng: "+ Arrays.toString(latLong));
		String comType = U.getCommType(comSec);
		U.log("comType: "+comType);
		String maxSq = ALLOW_BLANK, minSq = ALLOW_BLANK, minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log(homesList.toString());
		String price[] = U.getPrices((comSec+homesList.toString()),//.replaceAll("From $\\d{3},\\d{3}", "")
				"PriceLo\":\\d{7}|PrLo\":\\d{6}|PriceHi\":\\d{6}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+|\"PriceHi\":\"\\d{6}\"|\"PriceLo\":\"\\d{6}\"", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice: " + minPrice + "maxprice: " + maxPrice);
		// 3,077 sqft.<br />
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((comSec+homesList.toString()),"[\\w\\s\\W]{30}price[\\w\\s\\W]{30}",0));
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll((comSec+homesList.toString()),"[\\w\\s\\W]{30}939[\\w\\s\\W]{30}",0));
		//FileUtil.writeAllText("/home/shatam-10/Desktop/data/homeswest.txt", homesList.toString());
		
		String Sqft[] = U
				.getSqareFeet(
						comSec+homesList.toString(),
						"\"SftHi\":\\d{4}|\"SftLo\":\\d{4}|d=\"plans-sqft\">\\d{4}</div>|\\d{4} sqft|\\d,\\d+ sqft|<td>\\d+,\\d+</td>|\\d,\\d+ to \\d,\\d+ square feet|16,000 square feet|[0-9]{4} sqft.</label>|[0-9]{4}</td>",
						0);
		minSq = (Sqft[0] == null) ? ALLOW_BLANK : Sqft[0];
		maxSq = (Sqft[1] == null) ? ALLOW_BLANK : Sqft[1];
		U.log("minSq" + minSq + "maxSq" + maxSq);
//		U.log(homesList.toString());
		String propType = U.getPropType((comSec+homesList.toString()).replaceAll("Desc\":\"Courtyard at front entry|IsCondo|IsTownHome", ""));
		U.log("propType: "+propType);
//		U.log(Util.matchAll(comSec+homesList.toString(), "[\\w\\s\\W]{30}courtyard[\\w\\s\\W]{30}", 0));
		
		String dPropType = U.getdCommType((comSec+homesList.toString())
				.replaceAll("[F|f]irst [F|f]loor|[F|f]loor|Floor", ""));
		
		U.log("dPropType: "+dPropType);
		
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(comSec.toString(),"[\\w\\s\\W]{30}Story[\\w\\s\\W]{30}",0));
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(homesList.toString(),"[\\w\\s\\W]{30}Story[\\w\\s\\W]{30}",0));
		
		//data was given on the community page but html is not extracted thus values are hardcoded
		/*
		 N - Active
	     C -Coming Soon
	     G -Grand Opening
	     X - Close Out
	     CG Coming Soon Grand Opening
	     M - Model Home
		*/
		String statusSec = U.getSectionValue(comSec, "\"Status\":\"", "\"");
		if(statusSec.equals("C"))statusSec = "Coming Soon";
		if(statusSec.equals("X"))statusSec = "Close Out";
		if(statusSec.equals("CG"))statusSec = "Coming Soon, Grand Opening";
		String status = U.getPropStatus((comSec+statusSec).replace("Now open, the 12-acre ", "").replace("school, now open ", "").replace("school coming soon.", ""));
		U.log("status: "+status);
		
		/*
		 * Status Taken from Images
		 */
		if(comUrl.contains("https://www.westin-homes.com/communities/Cross-Creek-West---45-172406")||comUrl.contains("https://www.westin-homes.com/communities/Cross-Creek-West---55-172407"))
			status = getImagePropertyStatus.apply(status, "Grand Opening");
		
		String notes = U.getnote(comSec);
		
	
		data.addCommunity(commName.replace("artaviaa", "Artavia"), comUrl,comType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSq, maxSq);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), "FALSE");//geo taken false as all the add and lat lng ws presnt in comsec
		data.addPropertyType(propType, dPropType);
		data.addPropertyStatus(status.replace("Temporarily Sold Out, Sold Out", "Temporarily Sold Out").replace("Sold Out, Move-In Ready", "Move-In Ready"));
		data.addNotes(notes);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}

	private BiFunction<String, String, String> getImagePropertyStatus = (status, imageStatus)->{
		if(status == ALLOW_BLANK) status = imageStatus;
		else if(status != ALLOW_BLANK && !status.contains(imageStatus)) status = imageStatus;
		return status;
	};
	
	private void findSquareFeet(String planHtml) throws Exception {
		
		String html = planHtml;
		html = html.replace("&#8217;", "'");
		String regionPrice=Util.match(html,"\\$\\d+(s</div>)",1);
		if(regionPrice!=null)
		html = html.replace(regionPrice,",000");
		html = html.replace("'s", ",000").replace("’s", ",000");
		String maxSq = ALLOW_BLANK, minSq = ALLOW_BLANK, minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		// String tempSection = section;
		String priceSec = U.getSectionValue(html, "margin: 0in", "<div style");
		if (priceSec != null) {
			priceSec = priceSec.replace("0s", "0,000");
			priceSec = priceSec.replace(" million", ",000,000");
		}
		planHtml = planHtml.replace("'s", ",000")
				.replace("s</label>", ",000</label>").replace("&#8217;", "'");
		planHtml = planHtml.replace(" million", ",000,000");

		String price[] = U.getPrices((planHtml + priceSec + html),//.replaceAll("From $\\d{3},\\d{3}", "")
				"\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice" + minPrice + "maxprice" + maxPrice);
		// 3,077 sqft.<br />
//		U.log("MMMMMMMMMMMMMMMMMM "+Util.matchAll(planHtml + html,"[\\w\\s\\W]{30}From \\$551[\\w\\s\\W]{30}",0));
		String Sqft[] = U
				.getSqareFeet(
						planHtml + html,
						"d=\"plans-sqft\">\\d{4}</div>|\\d{4} sqft|\\d,\\d+ sqft|<td>\\d+,\\d+</td>|\\d,\\d+ to \\d,\\d+ square feet|16,000 square feet|[0-9]{4} sqft.</label>|[0-9]{4}</td>",
						0);
		minSq = (Sqft[0] == null) ? ALLOW_BLANK : Sqft[0];
		maxSq = (Sqft[1] == null) ? ALLOW_BLANK : Sqft[1];
		U.log("minSq" + minSq + "maxSq" + maxSq);

		

	}
	
	public static String getHardcodedCommType(String comUrl)
			throws Exception {
		
		String newFile = U.getHardCodedPath() + "Hardcode_WestinHomes_CommTypes.csv";
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {
//				 U.log(newCsvRow);
				// builderName=newCsvRow.get(1);
				if(comUrl.equals(newCsvRow.get(1))) {
					if(newCsvRow.get(2)!=null)
						return newCsvRow.get(2);
					else 
						return ALLOW_BLANK;
				}
				
			}
			count++;
		}

		newFileReader.close();
		return null;
	}

}