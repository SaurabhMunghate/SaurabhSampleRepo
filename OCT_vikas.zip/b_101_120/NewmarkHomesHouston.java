/**
 * @author Pallavi Meshram
 * @date 30/05/2018
 * 
 */
package com.shatam.b_101_120;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class NewmarkHomesHouston extends AbstractScrapper {
	static int k = 0;
	public int inr = 0;
	static String Builder_name = "Newmark Homes Houston";
	static String HOME_URL = "https://newmarkhomes.com/";
	static CommunityLogger LOGGER;
	WebDriver driver= null;

	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new NewmarkHomesHouston();
		a.process();
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Newmark Homes Houston.csv", a.data()
				.printAll());
		
		LOGGER.DisposeLogger();
	}

	public NewmarkHomesHouston() throws Exception {
		super(Builder_name, HOME_URL);
		LOGGER=new CommunityLogger(Builder_name);
	}

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
//		String findUrl = "https://newmarkhomes.com/communities";	
//		String html = U.getHTML(findUrl);
//		String comName=ALLOW_BLANK,comUrl=ALLOW_BLANK,addSec=ALLOW_BLANK;
//		//U.log("Hello");
//		String allComSec=U.getSectionValue(html, "<div class=\"midBlock\">", "<div class=\"mobileonly homeFinderPlacement\"></div>");
//		String[] sections=U.getValues(allComSec, "<div class=\"item\">", "Homes</a></div>");
//		U.log(sections);
//		//		html=html.replaceAll("</a>\\s*</div>\\s*</div>\\s*</div>\\s*</div>", "endComSec");
////		String sec[] = U.getValues(html, " <div class=\"item\">", "endComSec");
//		for (String com : sections) {
//			comName=U.getSectionValue(com, "<h4>", "</h4>");
//			comUrl="https://newmarkhomes.com"+U.getSectionValue(com, "href=\"", "\"");
//		//	U.log(comName+"::::::::::::::::::"+com);
//			comName=comName.replaceAll("\\d*\\W|\\d*\\', \\d*\\'|\\d*\\', \\d*\\', \\d*\\'"," ");
//			addSec=U.getSectionValue(com, "<div class=\"location\">", "</div>");
//					//checkComSec(comName,sections);
////			adDetails(comName,comUrl,addSec,com);
		
		String findHouston="https://newmarkhomes.com/new-homes/houston/communities";
		String findAustin = "https://newmarkhomes.com/new-homes/austin/communities";
		String html= U.getHTML(findHouston)+"::"+U.getHTML(findAustin);
		String comName=ALLOW_BLANK,comUrl=ALLOW_BLANK,addSec=ALLOW_BLANK;
		
		html = html.replaceAll("</div>\n\\s*</div>\n\\s*</div>", "</div></div></div>");
	
		String allComSec[]=U.getValues(html, "<div class=\"table\">", "</div></div></div>");
		U.log("ALL ComSecLength: "+allComSec.length);
		
		for(String sec:allComSec) {
					
				comName =U.getSectionValue(sec, "<h4>", "<");
				comUrl="https://newmarkhomes.com"+U.getSectionValue(sec, "<div class=\"visit\"><a href=\"", "\"");
				addSec=U.getSectionValue(sec, "<div class=\"location\">", "</div>");
				adDetails(comName,comUrl,addSec,sec);
			
		}
		adDetails("Bridgeland - Sheldon Lake", "https://newmarkhomes.com/new-homes/houston/cypress/fedrick-harris-estate-homes", "</h4></a><div>19311 Round Prairie Lane, Cypress, TX 77433</div>", "");
//		try{driver.quit();}catch(Exception e) {}
}
	public String checkComSec(String name,String[] data){
	   String comSec=ALLOW_BLANK;
//	   name=name.replaceAll("\\d*\\W|\\d*\\', \\d*\\'|\\d*\\', \\d*\\', \\d*\\'"," ");
		for(String section :data ){
			String conditionSec=U.getSectionValue(section, ">", "</a>'");
			//U.log(name+"::::::::::::::::::"+conditionSec);
			if(conditionSec.equals(name.trim())){
				 comSec=section;
			}
			
		}
		return  comSec;
				
	}

	public void adDetails(String comName,String comUrl,String addSec,String comSec) throws Exception {

//	try{
//TODO:
//		if(!comUrl.contains("https://newmarkhomes.com/new-homes/houston/cypress/fedrick-harris-estate-homes"))return;
		{
			String geoCode = "FALSE";
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//		U.log(comSec);
		U.log("ComName:::"+comName);
		U.log(k+"\tcomUrl:::"+comUrl);

		String comHtml = U.getHtml(comUrl,driver);
		comHtml=comHtml.replace("Coming Soon: Sheldon Lakes Phase 3", "Phase 3 Coming Soon");
		String statusSec=U.getSectionValue(comHtml, "<div class=\"\" id=\"content_communitydetail", "</div>");
		if(statusSec==null){
			statusSec=ALLOW_BLANK;
		}
//		U.log("MMMMMMMMM"+Util.matchAll(comHtml, "[\\s\\w\\W]{50}coming soon[\\s\\w\\W]{30}", 0));

		comHtml=U.removeSectionValue(comHtml, "<header>", "</header>");
		comHtml=U.removeSectionValue(comHtml, "<footer>", "</footer>");
		String lat = ALLOW_BLANK;
		String lng = ALLOW_BLANK;
		U.log("addSec: "+addSec);
		comSec=comSec.replace("Model Home Coming Soon", ALLOW_BLANK);
		String latlngSec = U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "/data");
		if(latlngSec==null)
			latlngSec = U.getSectionValue(comHtml, "<div class=\"modelhomes\">", "DRIVING DIRECTIONS");
		U.log("latlngSec: "+latlngSec);
		if(latlngSec!=null && latlngSec.contains("/@")) {
			latlngSec = U.getSectionValue(comHtml, "/@", "z");
			U.log("latlngSec==1: "+latlngSec);
			lat = latlngSec.split(",")[0];
			lng = latlngSec.split(",")[1];
		}
		U.log("lat is :" + lat);
		U.log("lng is :"+lng);
		String address = U.getSectionValue(comSec, "<div class=\"location\">", "</div");//U.getSectionValue(comHtml,"Plan</h4>", "<a onClick=\"toggleElement");
		U.log(address+"Hello");
		if(address!=null){
			address=address.replaceAll("<br />", ",");
			address =address.replaceAll("</div>\\s+<div>", ",");
			String add1[]=address.split(",");
			U.log("Adddress1 from here: "+Arrays.toString(add1));
			add[0]=add1[0].trim();
			if(add[0].isEmpty()) {
				add[0] = ALLOW_BLANK;
			}
			//U.log("add[0]: "+add[0]);
			add[1]=add1[1].trim();
			add[2]=Util.match(add1[2].trim(), "\\w+").trim();
			
			if(Util.match(add1[2].trim(), "\\d{5}") != null) {
				add[3]=Util.match(add1[2].trim(), "\\d{5}").trim();
				U.log("add[3]: "+add[3]);
			}
			
			if(add[3].isEmpty() || add[3] == null) {
				add[3] = ALLOW_BLANK;
			}
			U.log("Adddress from here: "+Arrays.toString(add));
		}
		else{
			address = U.getSectionValue(addSec,"</h4></a><div>", "</div>");
			if(address != null){
			address =address.replaceAll("<br />", ",");
			String add1[]=address.split(",");
			add[0]=add1[0].trim();
			add[1]=add1[1].trim();
			add[2]=Util.match(add1[2].trim(), "\\w+").trim();
			add[3]=Util.match(add1[2].trim(), "\\d{5}").trim();
			}
			U.log(Arrays.toString(add));
		}
		
		U.log("address :: "+address);
		String latLng[] = { lat, lng };
		if (address == ALLOW_BLANK && lat != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLng);
			address = add[0];
			geoCode = "TRUE";
		}
		if (add[1] == null && lat != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLng);
			geoCode = "TRUE";
		}
		
		if ((add[0] == null || add[0].trim().length()<3)&& lat != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLng);
			geoCode = "TRUE";
		}
		if (add[3] == null && lat != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLng);
			geoCode = "TRUE";
		}
		
		if ((lat == null || lat == ALLOW_BLANK) && add[0]!=null) {
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			lat = latLng[0];
			lng = latLng[1];
			geoCode = "TRUE";
		}

		//Lat-Lng exceed on page
//		if(comUrl.contains("https://newmarkhomes.com/communities/provence") || comUrl.contains("https://newmarkhomes.com/new-homes/houston/cypress/fedrick-harris-estate-homes")){
//			latLng = U.getlatlongGoogleApi(add);
//			if(latLng == null) latLng = U.getlatlongHereApi(add);
//			lat = latLng[0];
//			lng = latLng[1];
//			geoCode = "TRUE";
//		}
//		U.log(add[0]);
		U.log(latLng[0]);
		if(add[0].equals(ALLOW_BLANK)&&latLng[0]!=ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latLng);
			U.log(Arrays.toString(add));
		}
		
//		if(comUrl.contains("https://newmarkhomes.com/new-homes/houston/cypress/dunhampointe"))
//		{
//			add = U.getAddressGoogleApi(latLng);
//			geoCode = "TRUE";
//		}
		//derived type
		//data from floor-plans and homes
		comHtml=comHtml.replace("<div class=\"item \">", "<div class=\"item\">");
		String floorPlanandHomesHtml=ALLOW_BLANK;
		String[] floorPlanandHomes=U.getValues(comHtml, "<div class=\"item\">", " Details");
//		if(floorPlanandHomes==null||floorPlanandHomes.length==0)
//			floorPlanandHomes=U.getValues(comHtml, "<div class=\"details\">", "View Home Details");
		U.log(floorPlanandHomes.length);
		HashSet<String> set=new HashSet<String>();
		for(String home:floorPlanandHomes){
			set.add(U.getSectionValue(home, "href=\"", "\""));
		}
		int quickcount = 0;
		for(String value:set){
			U.log("Quick: "+value);
			if(value.contains("/new-homes/"))quickcount=quickcount+1;
			String fHtml  =U.getHTML("https://newmarkhomes.com"+value);
			if(fHtml !=null)
			floorPlanandHomesHtml +=  U.getSectionValue(fHtml, "homeDetail inventorylisting", "<div class=\"innerBox noprint\">")+U.getSectionValue(fHtml, "homeDetail inventorylisting", "<div class=\"innerBox noprint floorplan-page\">");
			//floorPlanandHomesHtml=floorPlanandHomesHtml.replaceAll("<div><a href=\"/communities/cross-creek-ranch\">Cross Creek Ranch »</a></div>|<a href=\"/quick-move-in\">Move-In Ready</a>", "");

		}
//		if(comHtml.contains(">FLOOR PLANS</a></td>")) {
//			String floorplanUrl=comUrl+"#fps";
//			String floorPlanHtml=U.getHTML(floorplanUrl);
//			String[] fSec=U.getValues(floorPlanHtml, "<div class=\"item \">", "");
//		}
//		U.log(comHtml);
		//Prices and square feets
//		if(!comUrl.contains("/fedrick-harris-estate-homes")) {
		String remm=U.getSectionValue(comHtml, " <title>", "id=\"ogtitle\" />");
		if(remm==null)remm=ALLOW_BLANK;
			comHtml=comHtml.replace(remm, "");
//		}
			comSec = comSec.replace("0s", "0,000");
			comHtml = comHtml.replace(">New Homes from the $463s", ">New Homes from the $463,000")
					.replaceAll("0s|0's", "0,000").replace("$1.5 million", "$1,500,000 million")
					.replaceAll("Activity Center is 6,000 sqft|New Homes from the \\$400s</h2>", "");
		//	U.log(Util.matchAll(comHtml+comSec+floorPlanandHomesHtml, ".*\\$440.*", 0));
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U.getPrices((comHtml+comSec+floorPlanandHomesHtml), 
					"\\$\\d{3},\\d{3}|from the mid \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3} million|\\$\\d,\\d+,\\d+ million|New Homes from the \\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;

			String[] sq = U.getSqareFeet(comHtml+comSec+floorPlanandHomesHtml, "sqft\" >\\s+\\d+,\\d{3}\\s+</td>| \\d,\\d{3} sqft|\\d{3,} sqft|Sq&nbsp;Ft<br /><b>\\d,\\d{3}</b>|Sq Ft <span>\\d,\\d{3}</span>|<span class=\"sort-square_feet\">\\d,\\d{3}<",
					0);
			minSqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
			maxSqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//U.log(Util.matchAll(comHtml+comSec+floorPlanandHomesHtml, "[\\s\\w\\W]{30}\\d{3,} sqft[\\s\\w\\W]{30}", 0));
		//Property type
		comHtml =comHtml.replace("on-site farm", "farmhouse-inspired homes");
				String propType=ALLOW_BLANK;
				propType=U.getPropType((comHtml+comSec+floorPlanandHomesHtml)
						.replace("Custom Estate Homes", "Custom homes Estate Homes")
						.replaceAll("estate-homes\">|Estate Homes �</a>|The Farmhouse Recreation|Estate Homes »</a>|luxurious bath",""));
				if(propType.contains("Clubhouse"))
					propType = propType.replace("Clubhouse", "");
//				U.log(Util.matchAll(comHtml+comSec+floorPlanandHomesHtml, "[\\s\\w\\W]{30}estate[\\s\\w\\W]{50}", 0));
				U.log("propType :: "+propType);
		//		floorPlanandHomesHtml = floorPlanandHomesHtml.replaceAll(" 1.5 story is complete |1.5 Story with all bedrooms", "");
		//TODO : Derived property Type
				//\\d\\.5 Story with

		String	dtype=U.getdCommType((comName+comHtml+floorPlanandHomesHtml.replace("Stories<br /><b>1", "1 Story").replace("Stories<br /><b>2", " 2 Story")).replaceAll("cross-creek-ranch|Ranch|Cross Creek Ranch|branch| 3 bedroom |Cy-Ranch High School|https://cyranch.cfisd.net/en/|Long\\+Branch\\+Bend|Long Branch Bend|longbranch|Branch|branch|Long Branch", ""));
//		U.log(Util.matchAll(comName+comHtml+floorPlanandHomesHtml, "[\\s\\w\\W]{30}custom[\\s\\w\\W]{30}", 0));
		U.log("dtype :: "+dtype);
//		
//		U.log(floorPlanandHomesHtml.contains("patio"));
		//propstatus
		
		String propstatus=ALLOW_BLANK;
		//.replace("\"tagline\">Coming Soon!</div>", "")
		comSec = comSec.replaceAll("<div class=\"tagline\">Coming Soon|Portrait Series Now Selling", "")
				.replaceAll("New 50 ft. and 80 ft. Sections Now Open|New 50 ft. and 80 ft. Sections Now Open|New 50 Ft. and 80 Ft. Sections Now Open|New 50 Ft. Section Now Open|New 45 Ft. Section Now Open", "New Sections Now Open")
				.replaceAll("Headwaters Artisan Plan - Coming Soon", "")
				.replaceAll("Sales Trailer \\W{3}\\s\\W{4}|Sales Trailer \\w+", "")
				.replaceAll("NOW Open</span>", "");
		
		
		comHtml = comHtml.replace("NEW Sections are now available", "New Sections Now Available").replaceAll("New 50 ft. and 80 ft. Sections Now Open|New 50 ft. and 80 ft. Sections Now Open|New 50 Ft. and 80 Ft. Sections Now Open|New 50 Ft. Section Now Open|New 45 Ft. Section Now Open", "New Sections Now Open")
				.replace("NEW Sections are now available", "NEW Sections now available")
				.replace("Coming Soon: Sheldon Lakes Phase 3", "Phase 3 Coming Soon");
		comHtml = comHtml.replace("\"tagline\">Coming Soon!</div>", "")
				.replaceAll("<div class=\"resultcount\">\\d+ Available Homes</div>|<h4>Phase 3 Coming Soon</h4>|<div class=\"resultcount\">\\d Available Homes</div>|Elementary School</h4>  <p><em>Coming Fall 2020|font-weight: bold;\">Coming Soon|Portrait Series NOW Selling|Currently Selling from 70' Model|Selling Out of 70' Model|yle=\"text-align: center;\">Coming Soon!</h5>|Quick Move-In Homes</a>|Parkway is coming soon.<|<div>Coming Soon!  Currently Selling From<br />|field-item even\"><p>Currently Selling |>Model Coming Soon<|Grand Parkway is coming soon|Currently Selling out of Avalon Model|Now Model Now Open|Homesite section is Now Open|about the new homes|content=\"New homes", "")
				.replaceAll("<a>Artisan Plan - Coming Soon | Coming Soon </h4>", "")
				.replaceAll("Sales Trailer \\W{3}\\s\\W{4}|Sales Trailer \\w+", "")
				.replaceAll("Onsite Elementary Coming Fall 2025|NOW Open</span>", "");
		propstatus=U.getPropStatus((statusSec+comSec + comHtml)
				.replace("Coming Soon: Sheldon Lakes Phase 3", "Phase 3 Coming soon")
				.replaceAll("pricepoint\">Coming Soon!|Model Home Coming Soon!|Model Home Coming Soon", "").replaceAll("<div class=\"tagline\">Coming Soon|Coming Soon, Currently Selling|SECTION NOW OPEN|SECTIONS NOW OPEN".toLowerCase(), "NEW SECTION NOW OPEN")
				.replace("New 70' Homesites Now Selling", "New Homesites Now Selling")
				.replaceAll("Currently Selling from 45' Model Home|Currently selling from Newmark Towne Lake 80", ""));
		U.log("Status :: "+propstatus);
		
		
		if(comUrl.contains("https://newmarkhomes.com/communities/cross-creek-ranch"))propstatus+=", Now Selling";
		propstatus=propstatus.replace("New Homes Available,", "");
		
		propstatus = propstatus.replaceAll(" 0 Available Homes|^0 Available Homes", "").trim().replaceAll(",$|^,", "").replaceAll(", ,", ",");
		propstatus=propstatus.length()==0?ALLOW_BLANK:propstatus;
		comHtml=comHtml.replace("SALES TRAILER NOW OPEN","");
		comHtml=comHtml.replace("sales trailer is NOW Open.<","");
		//if(comUrl.contains("communities/towne-lake"))propstatus=propstatus.replace("7 Available Homes", "6 Available Homes");
		comHtml=comHtml.replaceAll("Palacious 2 story|Opening Fall 2016", "");
		if(data.communityUrlExists(comUrl)){
			inr++;
			U.log("repeated::"+inr);
		}
		if(!propstatus.contains("Quick") && quickcount>0) {
			if(propstatus.length()<2)propstatus="Quick Move-In Homes";
			else propstatus=propstatus+", Quick Move-In Homes";
		}
		add[0]=add[0].replace("16211 Lost Midden", "16211 Lost Midden Court");
		comHtml=comHtml.replace("Golf</a></li>", "golf course");
		comName = U.getSectionValue(comSec, "<h4>", "</h4>");
		if(comName == null) comName = U.getSectionValue(comHtml, "<h1>", "</h1>");
		
		comHtml = comHtml.replaceAll("lakeside views in The Village of Sheldon Lake in Bridgeland", "lakeside Community in The Village of Sheldon Lake in Bridgeland");
			if(add[2].equals("Texas"))add[2]="TX";	
		if(comUrl.contains("https://newmarkhomes.com/communities/provence"))propstatus="New Section Coming Soon";
		if(comUrl.contains("https://newmarkhomes.com/new-homes/austin/dripping-springs/headwaters"))propstatus="Quick Move-In Homes";
		if(comUrl.contains("https://newmarkhomes.com/new-homes/austin/dripping-springs/headwaters")) {
			propType="Craftsman Style Homes, Carriage Home, Bungalow Homes";
		}
//			
//			latLng=U.getlatlongGoogleApi(add);
//			geoCode="TRUE";
//		}
//if(comUrl.contains("https://newmarkhomes.com/communities/towne-lake")) {
//	//add[0]=""
//	latLng=U.getlatlongGoogleApi(add);
//	geoCode="TRUE";
//		}
//if(comUrl.contains("https://newmarkhomes.com/communities/bridgeland")) {
//	add[0]="";
//	add[1]="Cypress";
//	add[2]="TX";
//	add[3]="";
//	
//	latLng=U.getlatlongGoogleApi(add);
//add=U.getAddressGoogleApi(latLng);
//	geoCode="TRUE";
//}
//if(comUrl.contains("https://newmarkhomes.com/communities/roughollow")) {
//	latLng=U.getlatlongGoogleApi(add);
//	geoCode="TRUE";
//}
		
		
		//if(comSec.contains("<div class=\"tagline\">Coming Soon!</div>") && !propstatus.contains("Coming Soon"))propstatus="Coming Soon, "+propstatus;
//		U.log(Util.matchAll(comHtml, "[\\s\\w\\W]{30}\\d{3,}master[\\s\\w\\W]{30}", 0));
		comHtml=comHtml.replace("/master-planned-community", "");
		comName = comName.replace("’", "'").trim();
		LOGGER.AddCommunityUrl(comUrl);
		data.addCommunity(comName, comUrl, U.getCommunityType(comHtml.replaceAll("<meta(.*?)/>|content=\".*\"", "").replace("complete with waterfront amenities", "complete with Waterfront Community")));
		data.addAddress(add[0].replace("18535 Farm to Market Rd #0 1488", "18535 Farm to Market Rd 1488").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, geoCode);
		data.addPropertyType(propType,dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(U.getnote(comHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		}
		
		k++;
//	}catch (Exception e) {}
		}

}