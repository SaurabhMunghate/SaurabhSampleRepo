package com.shatam.b_101_120;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.supercsv.cellprocessor.Trim;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class RobsonCommunities extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	static String HOME_URL = "https://www.robson.com";
	static String BUILDER_NAME = "Robson Resort Communities";
	static int duplicates = 0;
	CommunityLogger LOGGER;
	public int inr = 0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new RobsonCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Robson Resort Communities.csv", a.data()
						.printAll());
		// U.log(duplicates);

	}

	public RobsonCommunities() throws Exception {

		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	int count = 0;

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.robson.com/communities");
		//String wrongSec = U.getSectionValue(html, "<html lang=\"en-US\" class=\"no-js\">", "<div class=\"hfeed site\" id=\"wrapper\">");
	//	html = html.replace(wrongSec, "");
		//String commSection = U.getSectionValue(html,"<div class=\"CommunitiesList__tab-section ", " <div class=\"CommunitiesList__tab-section CommunitiesList__tab-section--map ");
		String commsec[] = U.getValues(html, "<div class=\"homes-list__card preview-card\">","button--full\">View");//"button--full\">View"
        Set<String> urls=new HashSet<String>();
        		
		U.log(commsec.length);
		for (String commuinity : commsec) {
		//	U.log("===\n"+commuinity+"\n====");
			String url=U.getSectionValue(commuinity, "<a href=\"", "\" class=\"homes-list");
//			U.log("URL"+url);
			urls.add(url);
			Iterator<String> i = urls.iterator();
			while(i.hasNext()) {
				String MyUrl=i.next();
				addDetails(commuinity,MyUrl);
			}
			
		//	addDetails(commuinity);
			//break;
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String commsec,String commUrl) throws Exception {
//		 U.log(commsec);
		//j++;
//		if (j == 5) 
		{
//			String commUrl = U.getSectionValue(commsec, "<a href=\"", "\" class=\"homes-list");
//			U.log(">>>>>"+commUrl);
//			U.log(U.getCache(commUrl));
			
//			if(!commUrl.contains("https://www.robson.com/communities/robson-ranch-arizona/"))return;
			
			if(commUrl==null)return;
			
			if(data.communityUrlExists(commUrl)){
				LOGGER.AddCommunityUrl(commUrl+"------------repeated");
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);
			
			U.log(commUrl);
			String commName = U.getSectionValue(commsec, "heading-h4 color-primary\">", "<");
			//commName=U.getNoHtml(commName.replace("&#8211; 800.795.4663", ""));
			U.log("kkkkk>>"+commName);
			U.log("count::"+j);
			String commHtml = U.getHTML(commUrl);
			
//			String rm = U.getSectionValue(commHtml, "<div class=\"GuestStayCommunities js-guest-stay-communities module space-t-none space-b-none ", "</html");
//			if(rm!=null) {
//				commHtml =commHtml.replace(rm, "");				
//			}
			
			String removeSec=U.getSectionValue(commHtml, "<meta", "\">");
			if(removeSec!=null) {
				commHtml=commHtml.replace(removeSec, "");
				U.log("remove 1");
			}
			String removeSection2=U.getSectionValue(commHtml, "Chat with Our Team Now!</h3>", "</html>");
			
			if(removeSection2!=null) {
				commHtml=commHtml.replace(removeSection2, "");
				U.log("remove 2");
			}
			
			
			String rem = U.getSectionValue(commHtml, "id=\"community-resources\">", "Load More Posts");
//			U.log(rem);
			if(rem!=null)
				commHtml = commHtml.replace(rem, "");
	
			
			
			String priceSec = U.getSectionValue(commHtml, "<div class=\"CommunityDetails__item CommunityDetails__item--price\">", "<");

			int moveInHomeCount = 0;
			int quickCount = 0;
//			if(moveInSection != null){
//				String moveInHomes[] = U.getValues(moveInSection, "<a href=", "</a>");
//				for(String moveInHome : moveInHomes){
//					if(U.getSectionValue(moveInHome, "Community:</span><span>", "</span>").equalsIgnoreCase(commName)){
//						moveInHomeSection+= moveInHome;
//						moveInHomeCount++;
//					}
//				}
//			}
			String moveinCount = Util.match(commHtml, "<div class=\"CommunityDetails__item-text\">(\\d+)</div>\\s*Move-In Ready Homes",1);
			if(moveinCount!=null)moveInHomeCount = Integer.parseInt(moveinCount);
			U.log("Total Move In :"+moveInHomeCount);
			//U.log("**&&**" + commHtml);

			String sec = U.getSectionValue(commHtml,
					"<div class=\"span8 content_col_1\">", "<div>");
			// move in ready homes
			String moveIn = commUrl + "home-plans/?move-in-ready";
			U.log("moveIn: "+moveIn);
			
			String moveInHtml = U.getHTML(moveIn);
			
			if(moveInHtml!=null) {
				String[] homelinks = U.getValues(moveInHtml, "<div class=\"homes-list__link homes-list__list-border\">", "Details</a></div>");
				U.log("homelinks: "+homelinks.length);
				
				for(String home:homelinks) {
					//U.log("home: "+home);
					if(home.contains("Move-In Ready"))
					{
						quickCount++;
					}
					String link = U.getSectionValue(home, "<a href=\"", "\"");
					U.log("homelink: "+link);
					
					String homedata = U.getHTML(link);
					
					if(homedata.contains("<div class=\"FloorplanContent__details-text\"><p><a")) {
						//----taking only those homes where no status for homes is given.
						quickCount++;
					}
				}
			}
			
			U.log("quickCount: "+quickCount);
			
			if(rem!=null)
				moveInHtml = moveInHtml.replace(rem, "");
			
			moveInHtml = moveInHtml.replace("SERIES:</span><span>Tradition<", "SERIES:</span><span>Traditional Homes")
					.replace("SERIES:</span><span>Estate</span>", "SERIES:</span><span>Estate Series home</span>");
			//U.log(moveInHtml);
			
			commHtml = commHtml.replace("&#8217;", "");
			commHtml = commHtml.replace("&#8211;", "");
			//commHtml = commHtml.replaceAll("0s|0's|0S|0�s|0’s", "0,000");
		//	From the $230's to $1m
			commHtml = commHtml.replaceAll("From the</small> <strong>(\\$\\d{3}'s)</strong> <small>to</small> <strong>(\\$\\dm)</strong>", "From the $1 to $2")
					.replaceAll("From the</small> <strong>(\\$\\d{3}'s)</strong> <small>to</small> <strong>(\\$\\dM plus)</strong>", "From the $1 to $2");
			commHtml = commHtml.replaceAll("0's|0’s|0's", "0,000");//.replaceAll("1M|1m", "1,000,000")
					
			if(priceSec!=null)priceSec = priceSec.replaceAll("0's|0’s|0's", "0,000");
			
			
			
			//U.writeMyText(commHtml);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			priceSec=priceSec.replaceAll("\\$1m's", "\\$1,000,000")
					.replace("From the $400's ", "From the $400,000");
			commHtml=commHtml.replace("From the $400's ", "From the $400,000")
					.replaceAll("\\$1m's", "\\$1,000,000")
					.replaceAll("From the $320's to\\s*$800's", "From the $320,000 to $800,000");
			moveInHtml=moveInHtml.replace("From the $400's ", "From the $400,000");
			
			String[] price = U
					.getPrices(
							(commHtml+priceSec).replaceAll("\\$470's", "\\$470,000"),
							"From the \\$\\d{3},\\d{3} to\n" + 
							"                                \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|From the \\$\\d{3},\\d{3} to\\s*\\$\\d,\\d{3},\\d{3}|New Homes\\s+\\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|From \\$\\d{3},\\d{3} . \\$\\d,\\d+,\\d+|From the \\$\\d+,\\d+ to\\s*\\$\\d+,\\d+|From the \\$\\d+,\\d+\\s+\\$\\d+,\\d+,\\d+ plus</div>|<strong>\\$\\d{3},\\d{3}</strong>|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|Price From:</strong> \\$\\d{3},\\d{3}",
							0); //moveInHtml

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
//		U.log(">>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{100}7,500[\\s\\w\\W]{100}", 0));
//		U.log(">>>>>>>"+Util.matchAll(moveInHtml, "[\\s\\w\\W]{30}7,500[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>"+Util.matchAll(priceSec, "[\\s\\w\\W]{30}\\$900[\\s\\w\\W]{30}", 0));


			// square feetl.com
			String minSq = ALLOW_BLANK;
			String maxSq = ALLOW_BLANK;
			String sqft[] = {};
			commHtml =commHtml
					.replaceAll("\\s*<span class=\"homes-list__hide-for-list\"> Sqft", " Sqft");
			sqft = U.getSqareFeet((moveInHtml+commHtml).replaceAll("Robson Ranch lies the 17,500 sq. ft. luxurious Clubhouse|approximately 36,575 sq. ft. of added indoor amenities", ""),
					"\\d,\\d{3} sq. ft.|\\d,\\d{3}\\s*-\\s*\\d,\\d{3} Sqft|square ft:</span><span>\\d+|square ft:</span><span>\\d+</span>", 0);
			minSq = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSq = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSq :" + minSq + " maxSq:" + maxSq);

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latlngs[] = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "";
			commHtml = commHtml.replaceAll("<span itemprop=\"streetAddress\">|<span itemprop=\"addressLocality\">","").replace("</span>", "");
			String address = U.getSectionValue(commHtml, "Office</strong></div>", "<div class=\"CommunityDetails__item");
			U.log(address+"==========");
			if (address != null) {
				String remAddSec = U.getSectionValue(address, "</strong><br />", "<br />");
				if(remAddSec != null)
					address = address.replace(remAddSec, "");
				address = address.replaceAll("</strong>|s</strong>|<div>", "");
				address = address.replace("Avenue</div>", "Avenue,").replace("Blvd.</div>", "Blvd,").replace("Rd</div>", "Rd,").replace("Lane.</div>", "Lane,").replace("Blvd</div>", "Blvd,").replace("CIR</div>", "CIR,").replace("<br />", "");
				
				U.log("Addsec"+address+"==");
	
				add = U.getAddress(address);
				U.log(Arrays.toString(add));
				geo = "FALSE";
				if (add[2] == null || add[2].length() > 2) {
					add[2] = ALLOW_BLANK;
				}
				if (add[3] == null) {
					add[3] = ALLOW_BLANK;
				}
				
				if (add[0].contains("telephone")) {
					add[0] = ALLOW_BLANK;
				}

				if (commUrl.contains("https://www.robson.com/communities/robson-ranch-texas/overview/")) {
					add[2] = "TX";
				} else {
					add[2] = "AZ";
				}
			}
			if (add[0].contains("</span>")) {
				add[0] = ALLOW_BLANK;
			}
			
//			if (commUrl
//					.contains("https://www.robson.com/communities/saddlebrooke/overview/")) {
//				add[0] = "59680 East Robson Cir.";
//				add[1] = "Oracle";
//				add[2] = "AZ";
//				add[3] = "85623";
//				//geo = "FALSE";
//			}
			String latlngSec = "";
			String latSec = U.getSectionValue(commHtml, "href=\"https://www.google.com/maps", "Driving Directions"); 
//			U.log(latSec);
			if(latSec!=null){
				latlngSec = U.getSectionValue(latSec, "/@", ",18z/");
				if(latlngSec == null)
					latlngSec = U.getSectionValue(latSec, "/@", ",17z/");
				if(latlngSec!=null)
					latlngs = latlngSec.split(",");
			
			}
			if((add[0]!=null || add[0]!=ALLOW_BLANK) && (latlngs[0]!=null || latlngs[0]!=ALLOW_BLANK));
			geo = "FALSE";
			if (add[0] != ALLOW_BLANK && (latlngs[0] == ALLOW_BLANK || latlngs[0]==null)&& (latSec==null || latlngSec==null)) {
				latlngs = U.getlatlongGoogleApi(add);
				if(latlngs == null) latlngs = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			
			commHtml = U.removeComments(commHtml);
			commHtml=commHtml.replace("New Homesites <br> Released", "New Homesites Released")
					.replaceAll("Courts are now available|Courts are now available|Amenities Now Open|Dogs</a> is now open|Garden is Now Open|new Avalon plan at Robson Ranch Arizona is now available|Courts</strong> <strong>are now available|New amenities opening in early|Holes Coming Fall 2019|Holes Now Open|Also coming soon to SaddleBrooke|Grand Opening 2 new models|\">GRAND OPENING – Two New Models|Brand NEW Homesites Released in Unit|Ranch House Now Open|Ranch House is now open.|amenities is selling fast, over 50% sold out|title=\"Ready to move|>MOVE-IN READY HOMES</a>|Now Open – New Mandara Model|Move-In Ready Dream|New Ranch House Now Open|<span>Move-In Ready<br>|quick move-in Designer|Your Move-In Ready|Move-In Ready homes often|Now available, the|Ranch is now open|New Models Now Open|Center Now Open|center is now open|Villas Coming soon|Villas are coming soon|Golf Holes Coming Soon|Model is Now Open|Complex Now Open|park is now open| Montecito is now open|neighborhood is now open|Montecito Model Now Open|Model Now Open|Model Grand Opening|grand opening|Grand Opening|New Amenity Coming Soon|Complex Coming Soon|Ready<br><strong>|The new Ranch House is now open", "");
			
			commHtml = commHtml.replace("Only 7 <br /> Homes Remaining", "Only 7 Homes Remaining");
			
			if(!commUrl.contains("quail-creek/overview/")) {
				commHtml=commHtml.replaceAll("/move-in-ready/|Move-In Ready New Homes in Arizona", "");
			}
			
			String pStatus = U.getPropStatus(commHtml.replaceAll("and storage are now open|designs are now available|Robson Ranch Arizona is now open|\"move-in-ready\">Move-In Ready|sold-out\"|Move-In Ready Homes|Amenities Now Open|Garden is Now Open|Dogs is now open|available to view|Creek is now|Dogs Now Open|Dogs is now open|Robson Ranch Ready to Move|amenities opening in Spring", "")); //+ "Move-In Ready Homes");
//			U.log(Util.match(commHtml, ".*?Now Available.*?"));
	//		
//			U.log(">>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{30}now open[\\s\\w\\W]{30}", 0));

			if(!pStatus.contains("Move-in Ready") && quickCount > 0){
				if(pStatus == ALLOW_BLANK) pStatus = "Move-In Ready Homes";
				else if(pStatus != ALLOW_BLANK) pStatus += ", Move-In Ready Homes";
			}
			
			U.log("pStatus: "+pStatus);
			
			// U.log("$$$$*********"+moveInHtml);
			//U.log(commHtml);
			//U.log("CommSec=="+commsec);
			String ameUrl = commUrl + "/amenities/";
			String ameHtml = U.getHTML(ameUrl);
			if(ameHtml!=null) {
				String removeSec01=U.getSectionValue(ameHtml, "<meta", "\">");
				if(removeSec01!=null) {
					ameHtml=ameHtml.replace(removeSec01, "");
					U.log("remove 1");
				}
				String removeSection02=U.getSectionValue(ameHtml, "Chat with Our Team Now!</h3>", "</html>");
				
				if(removeSection02!=null) {
					ameHtml=ameHtml.replace(removeSection02, "");
					U.log("remove 2");
				}
			}
			
			
			
			commHtml = commHtml.replace("entry gate", "");
//			commHtml = commHtml.replaceAll("Arizona 55+|Arizona 55+ Community in Phoenix|retirement communities, active adult communties, 55 communities, 55 retirement communities|" +
//					"			Luxury Active Adult Retirement Communities|Master Planned Retirement Community for Active Adults|Quail Creek Active Adult Communtiy|an Active Adult Community in Arizona|aster Planned Active Adult Retirement Communities|active adult", "");
			commsec = commsec.replaceAll("Quail Creek Active Adult Communtiy|an Active Adult Community in Arizona|Active Adult Community|aster Planned Active Adult Retirement Communities", "");
			commHtml = commHtml.replaceAll("past the entry gate|resort-style pool with an abundance|Resort-Style Pool Complex Coming Soo|specifically for resort-style living|PebbleCreek - Clubhouse - Robson Resort Community|Arizona 55+|Arizona 55+ Community in Phoenix|Master Planned Active Adult Retirement Communities|Active Adult Living|active adult communties|title='Golf'|menu-golf|/golf/|Gated entry", "");
			commsec = commsec.replaceAll("PebbleCreek - Clubhouse - Robson Resort Community|Active Adult Living|active adult communties|title='Golf'|menu-golf|/golf/|Gated entry|Luxury Active Adult Retirement Communities", "");
			ameHtml = ameHtml.replaceAll("PCGate|The outdoor resort-style|<h4>Resort-style|<p>With covered areas the resort-style|<h4>Resort-Style|resort-style pool with an abundance|Resort-Style Pool Complex Coming Soo|specifically for resort-style living|PebbleCreek - Clubhouse - Robson Resort Community|Master Planned Active Adult Retirement Communities|retirement communities, active adult communties, 55 communities, 55 retirement communities|Luxury Active Adult Retirement Communities|Active Adult Living|Active Adult Retirement in Arizona","");
	
			
			//U.log("commsec::"+commsec);
			//String newhtml=U.getHTML(commUrl);
			commHtml = commHtml.replace("55+ Arizona Retirement", " seniors 55 and over").replace("55+ Retirement", " seniors 55 and over").replace(U.getSectionValue(commHtml, "<head>", "</head>"), "");
			commHtml=U.getNoHtml(commHtml);
			commsec=U.getNoHtml(commsec);
			ameHtml=U.getNoHtml(ameHtml);
			String ctype=U.getCommunityType((commHtml+commsec+ameHtml+" Active Adult ").replaceAll("50 Best Master-Planned Communities|[G|g]ated [E|e]ntry|Nest Country Club", ""));
			//if (j == 0) ctype=ctype+",55+";
			//U.log("commHtml======"+commHtml);
//			U.log(commHtml+"$$$$$$$$$$$$");
			commHtml = commHtml.replaceAll("(P|p)atio (P|p)arty", "");
			
			commName = commName.trim().replaceAll("Arizona$|Texas$| AZ$", "");
			
			
			if(commUrl.contains("/saddlebrooke-ranch/")||commUrl.contains("/the-preserve/"))maxPrice="$1,000,000";
		
			
			
			moveInHtml = moveInHtml.replaceAll("Ranch House at  Arizona|Ranch Texas|Saddle Ranch|[b|B]ranch|RanchHouseGrillPatio|<strong>Robson Ranch|robson-ranch|/mandara-tradition-floor-plan/|Robson Ranch|ranch-arizona|saddlebrooke-ranch|SaddleBrooke Ranch|saddle-brooke-ranch|robson-ranch-texas|Robson Ranch Texas|ranch-texas|Ranch Arizona|ranch-style|title='HOA|HOA Fees|hoa-fees|css?family|class=\"single|single- postid|body  single-", "");
			commHtml = commHtml.replaceAll("Ranch House at  Arizona|Ranch Texas|Saddle Ranch|[b|B]ranch|RanchHouseGrillPatio|<strong>Robson Ranch|relaxing lounge and the spacious covered patio|patios or in community meeting|participation|[P|P]atio\\d+|[P|P]atio-\\d+|[P|P]atio\"|[P|P]atio\\.jpg|sold-out\"|[G|g]ated [E|e]ntry|robson-ranch|/mandara-tradition-floor-plan/|Robson Ranch|ranch-arizona|saddlebrooke-ranch|SaddleBrooke Ranch|saddle-brooke-ranch|robson-ranch-texas|Robson Ranch Texas|ranch-texas|Ranch Arizona|ranch-style|title='HOA|HOA Fees|hoa-fees|css?family|class=\"single|single- postid|body  single-", ""); 
			moveInHtml = moveInHtml.replace("body  single-", "").replace("css?family", "").replace("SingleFamily", "");
					
			commHtml = commHtml.replace("body  single-", "").replace("css?family", "").replace("SingleFamily", "");
			
			U.log("Match1===="+Util.matchAll(commsec+ameHtml, "[\\s\\w\\W]{30}master-planned[\\s\\w\\W]{30}",0));
//			U.log("Match===="+Util.matchAll(moveInHtml, "[\\s\\w\\W]{30}Estate[\\s\\w\\W]{30}",0));
			add[0] = U.getCapitalise(add[0].toLowerCase());
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
			//--------from image
			if(commUrl.contains("https://www.robson.com/communities/saddlebrooke-ranch/"))pStatus += ", Limited Homesites Available";
			
			data.addCommunity(commName,commUrl,ctype);
			data.addAddress(add[0].replace(".", ""), add[1], add[2].trim(), add[3]);
			data.addSquareFeet(minSq, maxSq);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latlngs[0].trim(), latlngs[1].trim(), geo);
			
			data.addPropertyType(U.getPropType(commHtml + moveInHtml
					.replace("Series:</strong> Estate", "Series:</strong> Estate Style Living")
					.replace("Series:</strong> Tradition", "Series:</strong> Traditional Style Homes")
					.replace("Mediterranean Bruschetta", "")),
					U.getdCommType(commHtml));
			data.addPropertyStatus(pStatus);
			data.addNotes(ALLOW_BLANK);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt,endDt);
		}j++;
	}
}