/*
 * @author Priti
 * @date 30/06/2018
 */
package com.shatam.b_121_140;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class DreamFindersHomes extends AbstractScrapper {
	public int k = 0;
	static int j=0;
	public int inr = 0;
	static String Builder_name = "Dream Finders Homes";
	static String HOME_URL = "https://www.dreamfindershomes.com";
	CommunityLogger LOGGER;
	HashSet<String> regUrls = new HashSet<String>();
	WebDriver driver;

	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new DreamFindersHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Dream Finders Homes.csv", a.data().printAll());
	}

	public DreamFindersHomes() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger(Builder_name);
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.dreamfindershomes.com");//U.getHTML("https://www.dreamfindershomes.com/communities/");

		String regSec[] = U.getValues(html, "<li class=\"child-com-item\"><a href=\"", "\">");
		
		U.log(regSec.length);
		for(String reg: regSec) {
			regUrls.add(reg);
		}
		for(String regurl:regUrls) {
//			U.log(regurl);
			String regHtm = U.getHTML(regurl);
//			U.log(regHtm.contains("<!--/.row-->"));
			String comSecs[] = U.getValues(regHtm, "<div class=\"community-image-section\">", "View Community");
//			U.log(comSecs.length);
			for(String sec:comSecs) {
//				U.log(sec);
				String url = U.getSectionValue(sec, " <h3><a href=\"", "\"");
				findCommunityDetails(url, sec);
			}
		}
		LOGGER.DisposeLogger();
//		try{
//			driver.quit();
//			}catch(Exception e){};

	}
	
	//TODO ::
	private void findCommunityDetails(String comUrl, String comSec) throws Exception {
//		if(j >= 0 && j<=10)
//			if(j >= 10 && j<=30)
//				if(j >= 30 && j<=50)
//					if(j >= 70)
//		try{
		{
//	     if(!comUrl.contains("https://dreamfindershomes.com/hilton-head-bluffton/hearthstone-lakes/"))return;
				
			U.log("\nCount==="+j+":::::: comUrl======"+comUrl);
//			U.log(comSec);
			
			if(comUrl.contains("https://www.dreamfindershomes.com/halifax-plantation/"))return;
			if((comUrl.contains("=community&p=162747")) || 
					(comUrl.contains("https://dreamfindershomes.com/jacksonville/eagle-landing/"))	){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------returned no data");
				return;
			}
			if(comUrl.contains("https://www.hhhomes.com/new-homes")){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------redirecting to hh homes");
				return;
			}
			
			if(comUrl.contains("https://dreamfindershomes.com/jacksonville/holly-forest-at-silverleaf/")){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------Page Not Found");
				return;
			}
			
			String html = U.getHTML(comUrl);
			int qCount=0;
			if(!html.contains("No Quick Move-in Ready")&& html.contains("<h2>Quick Move-in Homes</h2>")) {
				qCount++;
			}
			U.log(U.getCache(comUrl));
			
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String popUp = U.getSectionValue(html, "<div class=\"special-popup-message\">", "</div>");
			
			//=========== Community Name ==================
			String comName = U.getSectionValue(html, "<h1>", "</h1>");
			if(comName==null)
				comName = U.getSectionValue(comSec, "<h3>", "<");
			comName = comName.replace("� Grand", "-");			 
			comName = comName.replace("�", "-");		
			comName = comName.replaceAll(" - Coming Soon!| - Now Pre-Selling!| - Phase 2 Coming Soon!| - Phase 2 Now Selling!| – Grand| – Now Selling!| – Single Family Homes|– Single Family|– Townhomes| – New Phase Coming Soon! Join Our VIP List Today!| – Coming Soon!|- Coming Summer 2017|Townhomes$| Villas$|Country Club$|Single Family Homes$|- COMING SOON!|- COMING SOON|- NOW SELLING!|- NOW SELLING|- Now Selling!| - New Phase ! Join Our VIP List Today!", "").replace("&#8211;", "-")
					.replaceAll("- ONLY 2 HOMES LEFT| – New Phase!| - Now Selling(!)?|- Coming Soon(!)?| - COMING SOON(!)?| - NOW SELLING!|55\\+", "").replace("–", "-")
					.replaceAll(" - MODELS NOW OPEN!| - Last Chance!| - Phase 2 Coming Soon!| - Models Open!| - New Urban Towns in Fairfax County", "");
			comName = comName.replace(" - Now Pre-Selling!", "").replace(" - Sold Out!", "");
			if(comName==null||comName.length()<1) {
				comName = U.getSectionValue(html, "\"name\":\"", "\",");
			}
			
			
			if(comUrl.contains("https://dreamfindershomes.com/jacksonville/build-on-your-lot/"))
				comName="Build on Your Lot";
			
			if(comUrl.contains("https://dreamfindershomes.com/waxpool-crossing-vip/"))
				comName="Waxpool Crossing";
			if(comName.endsWith("Estates"))comName=comName.replace("Estates", "");
			comName = comName.replace(" Coming Soon VIP List", "").replace(" VIP Page", "").replace("VIP", "");
			U.log("CommName =="+comName);
			//============= Note==============
			String note = U.getnote(html.replaceAll("Pre-Selling from Ascent|Lakewood Park &#8211; Now Pre-|Lakewood Park - Now Pre-", ""));
//			U.log("MMMMMMMMMm "+Util.matchAll(html, "[\\w\\s\\W]{30}Pre-Selling[\\w\\s\\W]{30}", 0));
			//========== Address ============================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "False";
			String city=ALLOW_BLANK;
			String addSec =U.getSectionValue(html, "<span class=\"address\">", "</span>");
			if(addSec!=null) {
			addSec=addSec.replace("11049 Blackburn Cove LaneStafford", "11049 Blackburn Cove, LaneStafford")
					.replace("294 Good Hope Road    Bluffton,", "294 Good Hope Road,  Bluffton,")
					.replace(".St. Johns", ",St. Johns")
					.replace("DriveSt. Johns", "Drive, St. Johns")
					.replace("Jefferson Square: ", "")
					.replace("9500 barnes loop ,manassas, va 20110, stafford, va, 20110", "9500 barnes loop ,manassas, va 20110")
					
					.replace(", ,", ", ");
			}
			U.log("address:::::"+addSec);
			
			if(addSec==null)addSec = U.getSectionValue(comSec, "data-address=\"", "\"");
			if(addSec!=null) {
				city = U.getCityFromZip(Util.match(addSec, ",\\s*(\\d{5})",1));
				city = city.replace("saint", "st.").replace("howey in the hills", "howey-in-the-hills");
				U.log(city);
				addSec = addSec.toLowerCase().replace(city, ","+city).replace(", ,", ", ");
				U.log("addSec========"+addSec);
			}
			if(addSec != null){
				addSec = addSec.replaceAll("sold out|model address coming soon|single family: 57 topside drive / attached villas:|<i class=\"fas fa-map-marker-alt\"></i> |model coming soon!|model coming soon|model home |coming soon!|sold out!|homesites", "")
						.replace("road bluffton", "road, bluffton")
				.replace("Jefferson Square: ", "")
				.replace("228 heatherland drive,  ,", "228 heatherland drive,")
				.replace("selling from: ", "")
				.replace("775 red spruce drive,  ,", "775 red spruce drive,")
				.replace("1238 debra lane, kernersville, nc 27284, kernersville, nc, 27284", "1238 debra lane, kernersville, nc, 27284")
				.replace("9500 barnes loop ,manassas, va 20110, stafford, va, 20110", "9500 barnes loop ,manassas, va, 20110")
				.replace("1400 hunting hawk lane, kernersville, nc 27284, kernersville, nc, 27284", "1400 hunting hawk lane, kernersville, NC, 27284")
				.replace("winsome laurel lane, reidsville, nc, reidsville, nc, 27320", "winsome laurel lane, reidsville, nc, 27320")
				;
				U.log("AddSec ==="+addSec);
			
				String [] tempAdd = addSec.split(",");
				
				U.log("AddSec ==="+addSec);
			
				for(String a:tempAdd) {
				U.log("tempAdd ==="+a);
				}
				if(tempAdd.length==4){
					add = tempAdd;
					U.log("AddSec ==="+addSec);
					
				}
				
				if(comUrl.contains("https://www.dreamfindershomes.com/trailmark-reverie-55/"))
				if(add[0].length()<3 && addSec!=null) {
					
					String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
					latLng = U.getlatlongGoogleApi(tempAdd);
					if(latLng == null) latLng = U.getGoogleLatLngWithKey(tempAdd);
					add = U.getAddressGoogleApi(latLng);
					if(add == null) add = U.getGoogleAddressWithKey(latLng);
					
				}
				
				add[0] = add[0].replaceAll("^.*?</span>", "").replaceAll("coming soon", "");
				U.log(Arrays.toString(add));
			}
			
			if (comUrl.contains("dreamfindersactiveadult")) {
				addSec = U.getSectionValue(comSec, "<h4>", "</");
				
				add = U.getAddress(U.getNoHtml(addSec));
			}
			add[0]=add[0].trim().replace("by appointment only", "");
			
			
			
			
			U.log("Address: "+Arrays.toString(add));
				
			//============= LatLng ====================
			String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
			String latlngSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/Current+Location/", "\"");
			if(latlngSec!=null) {
				latlngSec = latlngSec.replace("%2C", ",");
				latLng = latlngSec.split(",");
			}else {
			latLng[0] = U.getSectionValue(comSec, "data-lat=\"", "\"");
			latLng[1] = U.getSectionValue(comSec, "data-long=\"", "\"");
			}
			
//			if(comUrl.contains("scotland-heights/")) {
//				String[] add1= {"","Waldorf","MD",""};
//				latLng=U.getlatlongGoogleApi(add1);
//				U.log("latLng:: "+Arrays.toString(latLng));
//				add=U.getAddressGoogleApi(latLng);
//				U.log("Address: "+Arrays.toString(add));
//				geo = "TRUE";
//				
//			}
			if(comUrl.contains("wolf-creek-run-vip/")) {
				String[] add1= {"","Strasburg","CO",""};
				latLng=U.getlatlongGoogleApi(add1);
				U.log("latLng:: "+Arrays.toString(latLng));
				add=U.getAddressGoogleApi(latLng);
				U.log("Address: "+Arrays.toString(add));
				geo = "TRUE";
			}
			if(comUrl.contains("/potomac-station-marketplace-vip/")) {
				String[] add1= {"","Loudoun County","VA",""};
				latLng=U.getlatlongGoogleApi(add1);
				U.log("latLng:: "+Arrays.toString(latLng));
				add=U.getAddressGoogleApi(latLng);
				U.log("Address: "+Arrays.toString(add));
				geo = "TRUE";
			}
			
			if(comUrl.contains("/fairfax-landing-vip/")) {
				String[] add1= {"","Fairfax County","VA",""};
				latLng=U.getlatlongGoogleApi(add1);
				U.log("latLng:: "+Arrays.toString(latLng));
				add=U.getAddressGoogleApi(latLng);
				U.log("Address: "+Arrays.toString(add));
				geo = "TRUE";
		        
		        }
		if(comUrl.contains("waxpool-crossing-vip/")) {
			String[] add1= {""," Ashburn","VA",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		
		if(comUrl.contains("medlin-forest-vip/")) {
			String[] add1= {"","Monroe","NC",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		if(comUrl.contains("park-meadows-vip/")) {
			String[] add1= {"","Indian Trail","NC",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		
		if(comUrl.contains("com/baselinewest-vip/")) {
			String[] add1= {"","Baseline","CO",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		
		if(comUrl.contains("barbour-farms-vip/")) {
			String[] add1= {"","Clayton","NC",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		
		if(comUrl.contains("/barrington-townhomes-vip/")) {
			String[] add1= {"","Zebulon","NC",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		if(comUrl.contains("/knightdale-station-vip/")) {
			String[] add1= {"","Knightdale","NC",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
		
		
		if(comUrl.contains("/north-lakes-at-south-lakes-vip/")) {
			String[] add1= {"","Fuquay-Varina","NC",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
		}
			
		if(comUrl.contains("/northfield-vip/")) {
			String[] add1= {"","Fort Collins","CO",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			note="Address And Latlong Taken From City And State";
			geo = "TRUE";
			
		}
		
		if(comUrl.contains("https://dreamfindershomes.com/geos-vip/")) {
			String[] add1= {"","Arvada","CO",""};
			latLng=U.getlatlongGoogleApi(add1);
			U.log("latLng:: "+Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Address: "+Arrays.toString(add));
			
			geo = "TRUE";
			
		}
		
		
		if(comUrl.contains("https://dreamfindershomes.com/jacksonville/build-on-your-lot/")) {
//			String[] add1= {"","Fort Collins","CO",""};
			add=U.getAddress("14701 Philips Hwy Suite 300, Jacksonville, FL 32256");
			latLng=U.getlatlongGoogleApi(add);
			U.log("latLng:: "+Arrays.toString(latLng));
//			add=U.getAddressGoogleApi(latLng);
//			U.log("Address: "+Arrays.toString(add));
			note="Address Taken From Contact Us Page";
			geo = "TRUE";
			
		}
			
			U.log("latLng:: "+Arrays.toString(latLng));
			
			//
			if(latLng[0]==null||latLng[0]==ALLOW_BLANK||latLng[0].length()<2){
				String latSec=U.getSectionValue(html, "https://www.google.com/maps/embed/", "\"");
				U.log(latSec);
				if (latSec!=null) {
					latLng[0] = Util.match(latSec, "\\d+\\.\\d+");
					latLng[1] = Util.match(latSec, "-\\d+\\.\\d+");
					U.log(Arrays.toString(latLng));
				}else {
					latLng[0]=latLng[1]=ALLOW_BLANK;
				}
				
			}
			
			
			if (add[0].length()<4 && latLng[0].length()>4) {
				add = U.getAddressGoogleApi(latLng);
				if (add==null) add=U.getGoogleAddressWithKey(latLng);
				geo = "TRUE";
			}
			
			if (add[0].length()>4 && latLng[0].length()<4) {
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				geo = "TRUE";
			}
			if(add[0].length()>3 && latLng[0] == null) {
				
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				geo = "TRUE";
			}
			add[1] = U.getCapitalise(add[1].toLowerCase());
			
			U.log("add[0]   "+add[0]);
			U.log("add[0]   "+latLng[0]);
			
			
			if(add[0]==ALLOW_BLANK && latLng[0]==ALLOW_BLANK) {
				String addSection2=U.getSectionValue(html, "\">New Homes in", "&nbsp;</span>");
				String[] addSec2=addSection2.split(", ");
				String[] add1= {ALLOW_BLANK,addSec2[0],addSec2[1],ALLOW_BLANK};
				latLng=U.getlatlongGoogleApi(add1);
				U.log("latLng:: "+Arrays.toString(latLng));
				add=U.getAddressGoogleApi(latLng);
				U.log("Address: "+Arrays.toString(add));
				note="Address And Latlong Taken From City And State";
				geo = "TRUE";
				
			}
			
			
			//================== Quick Move In Homes ==================
			String combinedQuickHtmls = null;
			
			String[] quickUrls = U.getValues(html, "<div class=\"qmins-image-section\">", "</ul>");
			U.log("Total quickUrl : "+quickUrls.length);
			for(String quickUrl : quickUrls){
				quickUrl = U.getSectionValue(quickUrl, " <a href=\"", "\"");
			U.log("quickUrl : "+quickUrl);
			try {
			String quickHtml =U.getHTML(quickUrl);
			combinedQuickHtmls += U.getSectionValue(quickHtml, "<div class=\"community-title-bar\">", "<h2>Additional Homes</h2>");
			}catch (Exception e) {
				// TODO: handle exception
			}
			}		
//			U.log(combinedQuickHtmls);
			//-------AllFloorData-----
			String allFloordata = ALLOW_BLANK;
			String interactiveHTML=ALLOW_BLANK;
			HashSet<String> floorPlanUrl = new HashSet<>();
			String [] floorUrls = U.getValues(html, "<div class=\"floorplan-image-section\">", "</ul>");
			for(String fUrl : floorUrls){
				fUrl = U.getSectionValue(fUrl, " <a href=\"", "\"");
				floorPlanUrl.add(fUrl);
			}
			if(floorUrls.length==0) {
				floorUrls = U.getValues(html, "<div class=\"floorplan-info-bar\">", "View Floorplan");
				for(String fUrl : floorUrls){
					fUrl = U.getSectionValue(fUrl, "href=\"", "\"");
					floorPlanUrl.add(fUrl);
				}
			}
			U.log("Total floor Plan : "+floorPlanUrl.size());
			int k =0 ;
			for(String fUrl : floorPlanUrl){
				U.log("fUrl : "+fUrl);
				try{
				String fHtml  = U.getHTML(fUrl);
//				if(fHtml.contains("4-Plex"))
//				{
//					U.log("Found");
//				}
				
				String ptypesection=U.getSectionValue(fHtml, "inner ng-binding", "</div>");
//				U.log(ptypesection);
				fHtml=U.removeSectionValue(fHtml, "{\"@context\"", "</script>")
						+U.removeSectionValue(fHtml, "Floor Plan  Gallery", "");
				if(fHtml.contains("<div class=\"community-interative-floorplans\">"))
				{
					String iframeSec=U.getSectionValue(fHtml, "<div class=\"community-interative-floorplans\">", "</iframe>");
					
					if(iframeSec!=null)
					{
						String fpinteractiveURL=U.getSectionValue(iframeSec, "src=\"", "\"");
						U.log("fpinteractiveURL===="+fpinteractiveURL);
						interactiveHTML=U.getHtml(fpinteractiveURL, driver);
					}
				
				}
					
				allFloordata += U.getSectionValue(fHtml, "<div class=\"community-title-bar\">", "</main>")+ptypesection;
//				if(k++==5)break;
				}catch(Exception e){};
			}
			allFloordata = allFloordata
					.replaceAll("Stories:\\s+", "Stories ");
			
			//-------AllFloorData-----
			if (comUrl.contains("https://dreamfindersactiveadult.com/trailmark/")) {
				allFloordata = ALLOW_BLANK;
				floorPlanUrl = new HashSet<>();
				floorUrls = U.getValues(U.getHTML("https://dreamfindersactiveadult.com/trailmark/homes/#site-plan"), "<div class=\"wpb_single_image wpb_content_element vc_align_center",
						">VIEW</a>");
				for (String fUrl : floorUrls) {
					floorPlanUrl.add(fUrl);
				}
				U.log("Total floor Plan : " + floorPlanUrl.size());
				k = 0;
				for (String fUrl : floorPlanUrl) {
					
					try {
						String fHtml = U.getHTML(fUrl);

						allFloordata += U.getSectionValue(fHtml, "ame=\"model_name\" value=\"", "View All Floor Plans");
//						if (k++ == 5)
//							break;
					} catch (Exception e) {
					}
					;
				}
			}
			
			//=========== Community Description ==================
			String comDesc = U.getSectionValue(html, "ABOUT COMMUNITY</h3>", "</section>");
			if(comDesc ==null)
				comDesc = U.getSectionValue(html, "<div class=\"wpb_wrapper\"><h2>", "STAY CONNECTED</a>");
			if(comUrl.contains("https://www.dreamfindershomes.com/trailmark-reverie-55/"))
				comDesc = U.getSectionValue(html, "<p class=\"white\"", "</div>")+U.getSectionValue(html, "<h2>Welcome Home</h2>", "</div>");
			if(comUrl.contains("https://dreamfindersactiveadult.com/everlake/"))
				comDesc = comDesc+U.getSectionValue(html, "<h2 class=\"gold-gradient\">", "<")+U.getSectionValue(html, "<h2>Welcome Home</h2>", "</div>");
			if(comDesc ==null)
				comDesc = U.getSectionValue(html, "<div class=\"page-content\">", "</main>");
			//=============== Price ==================
			html=html.replace("from the mid 500's", "from the mid 500,000")
					.replace("from the low $400's", "from the low $400,000")
					.replace("Low 200’s", "Low $200’s").replaceAll("0s|0s|0's|0’s|0'S", "0,000");
			comSec = comSec.replaceAll("0s|0s|0's|0’s|0'S|0’s", "0,000");
//			U.log("kkkkkkkk"+comSec);
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U.getPrices(html+comSec+allFloordata+combinedQuickHtmls, 
					"from the mid \\d{3},\\d{3}|starting from the low \\$\\d{3},\\d{3}|Starting At <span>\\$\\d{3},\\d{3}</span>|Mid-\\$\\d{3},\\d{3}|clr-white\">\\$\\d,\\d{3},\\d{3}</span>|From the \\$\\d{3},\\d{3}|data-price=\"\\d{6}\"|white\">\\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|the (mid|High) \\$\\d{3},\\d{3}|<span>\\$\\d{3},\\d{3}</span>", 0);
//			U.log("MMMMMMMMMm "+Util.matchAll(html, "[\\w\\s\\W]{30}from the low \\$500[\\w\\s\\W]{30}", 0));

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//			U.log(U.getCacheFileName(comUrl));
			//================= Sqft ==============================
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			comSec = comSec.replaceAll("<br /><span>AREA", " AREA");

			html = html.replaceAll("<p>Area \\(Sqft\\)</p>\n\\s*<h3>", "<p>Area Sqft</p><h3>")
					.replace("<br /><span>AREA (SQFT)", " AREA SQFT");
			String[] sq = U.getSqareFeet(html +  comSec + allFloordata +combinedQuickHtmls,
					"\\d{4} to \\d{4} square feet|\\d,\\d{3} - \\d,\\d{3} AREA|Area (SQFT): <\\/span>\\d{4} - \\d{4}|\\d,\\d{3} AREA (SQFT)|<p class=\"plan-range\">\\d,\\d{3} - \\d,\\d{3}</p>|\\d,\\d{3}-\\d,\\d{3} square feet|ranging from \\d,\\d+ to \\d,\\d+ sq\\. ft|\\d,\\d{3} to \\d,\\d{3} square feet|with up to \\d,\\d{3} sq. ft| clr-gold\"></span>\\s+<p>\\d,\\d{3}</p>|<p>Area Sqft</p><h3>\\d,\\d+</h3>|\\d,\\d{3} and \\d,\\d{3} square feet|range from \\d,\\d{3} up to \\d,\\d{3}|\\d,\\d{3} to \\d,\\d{3} sqft|data-sqft=\"\\d{4}\"|\\d,\\d+ square feet|>\\s*\\d,\\d{3}\\s*</h2>\\s*<p>AREA \\(SQFT\\)|plan-range\">\\d,\\d{3} - \\d,\\d{3}",0);
			minSqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
			maxSqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			U.log("MMMMMMMMMm "+Util.matchAll(html +  comSec + allFloordata +combinedQuickHtmls, "[\\w\\s\\W]{30}2,106[\\w\\s\\W]{30}", 0));

			//U.log(combinedQuickHtmls);
			//U.log(comDesc);
			//============ Community Type ==============
			comSec = comSec.replace("A 55+ Community", "A 55+ community").replace("Reverie 55+", "Reverie 55+ community");
			
			String comType = U.getCommunityType((comSec+html)
					.replaceAll("alt=\"Gander Lake Community Photo", "")
					.replace("Active Adult Lifestyle<", "").replace("Trailmark 55+", "Trailmark  seniors 55 and over")
					.replace("resort and kid friendly", "resort pool and kid friendly"));
			
			//================ Property Type ===================
			String comDesc2="";
			if(html.contains("swiper-container\">")) {
			String[] comSec1=U.getValues(html, "<div class=\"container\">", "swiper-container\">");
		
			U.log("comSec1=========="+comSec1.length);
			if(comSec1.length>0) {
				for(String comdesc : comSec1) {
					comDesc2+=comdesc;
					
				}
				
			}
			}
//			U.log("comSec1=========="+comSec);
			
		
			
			comDesc2=comDesc2+U.getSectionValue(html, "<h2>Community Insights</h2>", "</div>");
			allFloordata=allFloordata.replaceAll("Mediterranean elev|Mediterranean-elev|\\d+-Plex-Unit_|\\d+ Plex Unit|-\\d+-Plex-Unit_|Mediterranean Elevation|Mediterranean_ELE|Jefferson-Square_6-Plex|Jefferson Square 6 Plex|-Patio-|Patio 1500&|Patio-1500|Patio 1500", "");
			if(combinedQuickHtmls!=null)
			combinedQuickHtmls=combinedQuickHtmls.replace("Mediterranean-elev|4-Plex-Unit_|_4-Plex_", "");
			
			if(comDesc!=null)
			comDesc = comDesc.replace("custom interior </span><span style=\"font-weight: 400;\">home", "custom homes")
					.replace("with custom designs,", "exceptional custom home").replace("luxury dream home", "luxury homes").replace("luxury maintenance-free townhome", "luxury homes maintenance-free townhome");
			String propType =U.getPropType((comDesc2+popUp + comDesc+ allFloordata +combinedQuickHtmls+comUrl.replaceAll("TownHome -|-", " "))
					.replace("Jefferson-Square_6-Plex-2-2-300x188.jpg", "")
					.replace("luxurious doggy splash", "luxurious finishes doggy splash")
					.replaceAll("Mediterranean-elev|common area for total privacy|\\d+ Plex Overland|_\\d+-Plex_Unit_|_\\d+-Plex_|Mediterranean_E|-Floor-Loft-|025 22 2nd Floor Loft", "")
					.replace("This luxury 4 Bedroom", "This luxurious finishes 4 Bedroom"));
//			U.log("MMMMMMMMMm "+Util.matchAll(comDesc2+popUp + comDesc+ allFloordata +combinedQuickHtmls+comUrl, "[\\w\\s\\W]{30}Mediterranean[\\w\\s\\W]{30}", 0));

//			U.log("MMMMMMMMMm "+Util.matchAll(popUp  , "[\\w\\s\\W]{30}Mediterranean[\\w\\s\\W]{30}", 0));

//			U.log("MMMMMMMMMm "+Util.matchAll(comDesc, "[\\w\\s\\W]{30}Mediterranean[\\w\\s\\W]{30}", 0));

//			U.log("MMMMMMMMMm "+Util.matchAll(allFloordata, "[\\w\\s\\W]{30}Mediterranean[\\w\\s\\W]{30}", 0));
////
//			U.log("MMMMMMMMMm "+Util.matchAll(combinedQuickHtmls , "[\\w\\s\\W]{30}Mediterranean[\\w\\s\\W]{30}", 0));
////			
//			U.log("MMMMMMMMMm "+Util.matchAll(comUrl , "[\\w\\s\\W]{30}Mediterranean[\\w\\s\\W]{30}", 0));

			//================ Property Status ======================
//			String rmsec = U.getSectionValue(html, "<script>//~ var row = Number(jQuery('.row_set').val());", "</html");
//			if(rmsec!=null)
//				html=html.replace(rmsec, "");
//				U.log(html);
			String popupSec=U.getSectionValue(html, "id=\"special-popup-message\" ", "<div class=\"popup-get-more-div\"> ");
			if(comDesc!=null)
				comDesc=comDesc.replaceAll("quick move-in ready homes|Quick Move in Homes<|Quick Move-In Homes Section|Move In|quick move-in ready homes available|currently selling from our Inspiration|Coming Soon! This beautiful", "")
				.replaceAll("under (\\d+) home sites are remaining", "");
			
			if(popUp != null)
				popUp = popUp.replaceAll("NEW PHASE!<br>\\s+NOW SELLING!", "NEW PHASE NOW SELLING");
	//			.replace("Lakefront &amp; Preserve Homes", "Lakefront & Preserve Homes available");
			

//			U.log(comDesc);
			
			if(popUp!=null)
				popUp = popUp.replace("Only 1 Homesite Remaning", "Only 1 Homesite Remaining").replace("New Phase Coming in Spring 2021", "New Phase Coming Spring 2021");
//			 "+Util.matchAll(popupSec , "[\\w\\s\\W]{30}Coming Soon[\\w\\s\\W]{30}", 0));
			html=U.removeSectionValue(html, "<div class=\"footer-top", "</body>");
			html=html.replaceAll("before we are sold out please reach out to our online sales|Quick Move-in Homes|quick move-in|move-in ready homes|Quick move-in, new construction homes|New Townhomes Coming Soon to Loudoun County, VA|Final Opportunity to Own in Williams Farms in Erwin, NC</option>", "");
			String removeHtml=U.getSectionValue(html, "<h2>Community Insights</h2>", "<h5>");
			if(removeHtml!=null) {
				html=html.replace(removeHtml, "");
			}
			String propStatus = U.getPropStatus((popUp+comDesc+comSec+popupSec+html)
					.replace("qualify for USDA financing", "")
					.replace("with only one home remaining before we are", "")
					.replace("with only one home remaining  consultant", "")
					.replace("description\"> Only 2 Opportunities Remain", "")
					.replaceAll("Move|move|MOVE", "")
					.replace("<div class=\"subtitle\"> Coming Soon </div> <div class=\"price-bar\"", "")
					.replaceAll("Move-in ready|MOVE-IN READY|move-in|Quick Move-in Homes|quick move-in|move-in ready homes|Quick move-in, new construction homes|New Townhomes Coming Soon to Loudoun County, VA|Final Opportunity to Own in Williams Farms in Erwin, NC</option>", "")
					.replace("Phase II is now SOLD OUT", "Phase II SOLD OUT")
					.replace("new phase of single-family homes is now selling", "new phase now selling")
					.replaceAll("MODELS ARE NOW OPEN|MODELS NOW OPEN|New floorplans coming soon|Now selling from Blackburn Townhomes|NOW SELLING FROM BLACKBURN TOWNS|NOW SELLING FROM FERNANDA PLACE:|Now Selling from Wiregrass|NOW SELLING FROM WOODLANDS AT GOOSE CREEK:|Now selling from Laureate Park model|marker-alt\"></i> Coming Soon", "").replace("new phase of single-family homes is coming soon", "new phase coming soon").replace("SOLD OUT: MODEL HOME FOR SALE", "SOLD OUT")
					.replaceAll("Selling Single-Family Homes</title>|Winter Springs - Now Selling!</title>|<.*?>|:\".*\"|-coming-soon|</i> Coming Soon|MODELS & MOVE-IN READY HOMES TODAY|-coming-soon|-coming-soon-|quick move|LD OUT: MODEL|style=\"font-weight: \\d+;\">SOLD OUT|community! With 65 available homesites and multiple|mesites available, you won't|\">NEW Showcase Homes Coming So| no Showcase Homes available i|data-href=\"#quick-move-in-homes-community-main\">Quick Move-In Homes</a>|quick-move-in-homes-community|p class=\"com-avail\">3  New Quick Move-In Homes|home&nbsp;sites available at Morningstar|cul-de-sac lots available|Now Selling: Wincey Groves|Quick Move-In|Move In", ""));
//			|Coming Soon!
			
			U.log("MMMMMMMMMm "+Util.matchAll(popUp+comDesc+comSec+popupSec+html , "[\\w\\s\\W]{30}only one home[\\w\\s\\W]{30}", 0));
//			U.log("MMMMMMMMMm "+Util.matchAll(comSec , "[\\w\\s\\W]{30}move-in ready homes[\\w\\s\\W]{30}", 0));
////			U.log("MMMMMMMMMm "+Util.matchAll(popupSec , "[\\w\\s\\W]{30}move-in ready homes[\\w\\s\\W]{30}", 0));
//			U.log("MMMMMMMMMm "+Util.matchAll(html , "[\\w\\s\\W]{30}move-in ready homes[\\w\\s\\W]{30}", 0));

			
			propStatus=propStatus.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
			propStatus=propStatus.replaceAll("Move-in Ready Homes, |Move-in Ready, |, Move-in Ready|Move-in Ready|Move-in Ready Homes,|Move-in Ready Homes", "");

			U.log("propStatus:::::::::: "+propStatus);
			
//			U.log(U.getSectionValue(html, "<h2>Quick Move-in Homes", "</section>").contains("There are currently no Showcase Homes"));
						
			if(qCount>0)
				{
				U.log("yes");
					if(propStatus.length()<3)
						propStatus = "Quick Move in Homes";
					else
						propStatus += ", Quick Move in Homes";
				}
				
				
			
			U.log("propStatus:::::::::: "+propStatus);
			//U.log(propStatus);
			if(propStatus.contains(" 3 Opportunities Left, Only 3 Opportunities Left,")){
				propStatus=propStatus.replace(" 3 Opportunities Left, Only 3 Opportunities Left", " Only 3 Opportunities Left");
			}
//			if(comUrl.contains("https://www.dreamfindershomes.com/trailmark-reverie-55/"))propStatus = "Lakefront & Preserve Homes Available";
			//U.log(comSec);
			
			if(comUrl.contains("https://www.dreamfindershomes.com/greenbrooke/")||comUrl.contains("https://www.dreamfindershomes.com/crystal-falls/"))
					propStatus="Closeout";

			if(comUrl.contains("https://www.dreamfindershomes.com/crystal-falls/"))
			propStatus=propStatus.replace("3 Homesites Remaining", "Only 3 Homesites Remaining");
			
			if(comUrl.contains("https://www.dreamfindershomes.com/tallyn-ridge-at-pinecliff-park"))
			propStatus=propStatus.replace("Final Opportunities, ", "");
			
			propStatus = propStatus.replace("New Phase Coming, New Phase Coming Spring 2021", "New Phase Coming Spring 2021");
			if(comUrl.contains("https://www.dreamfindershomes.com/blackburn-towns")) {
				add[0]="10901 Wild Ginger Cir";
				add[1]="Manassas";
				add[2]="VA";
				add[3]="20109";
				geo="TRUE";
			}
			if(comUrl.contains("https://www.dreamfindershomes.com/castlewood/")) {
				
				add[1]="Taylor";
				add[2]="TX";
				latLng=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
			
			if(comUrl.contains("https://dreamfindersactiveadult.com/everlake/")){
				
				add[1]="Mandarin";
				add[2]="FL";
				latLng=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
			
		if(add[0].equals("Model Coming Soon!")|| add[0].contains("Model Home Coming Soon")) {
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
		
		
		
		
		
		add[1] = add[1].replace("howey-in-the-hills","howey in the hills");
		if(propStatus.length()==0)propStatus=ALLOW_BLANK;
			//=================== Derived Property Type =============
//			U.log(allFloordata);
		if(combinedQuickHtmls!=null) {
		combinedQuickHtmls=U.removeSectionValue(combinedQuickHtmls, "<li class=\"stories\">", "</li>");
		}	
		
		U.log("comDesc==+"+comDesc);
		String dType = U.getdCommType((comDesc+combinedQuickHtmls+allFloordata)
				.replace("one and two-story floorplans", "One Story and 2 Story floorplans")
				.replaceAll("</h2><p>Stories</p>|</h2><p>Stories", " Stories").replaceAll("three-story water slide|COLONIAL TAVERN|\\d+ bedroom plans", "").replace(" 4BR,", ""));
			if(comUrl.contains("/jefferson-square/"))dType="3 Story";
//			U.log("MMMMMMMMMm "+Util.matchAll(allFloordata , "[\\w\\s\\W]{30}Stories[\\w\\s\\W]{30}", 0));

			
			if (add[0].length()>4 && latLng[0].length()<4) {
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				geo = "TRUE";
			}
			if(add[0].length()>3 && latLng[0] == null) {
				
				latLng = U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				geo = "TRUE";
			}
			if(html.contains("There are Currently No Quick Move-in Ready") && quickUrls.length==0) {
				U.log("hello i am here");
				propStatus = propStatus.replaceAll(", Quick Move-in Homes|Quick Move-in Homes, |Quick Move-in Homes", "");
			}
			if(propStatus==null || propStatus.length()<2)propStatus=ALLOW_BLANK;
			if(comUrl.contains("/beacon-lake/"))add[0]="47 Hutchinson Ln";
			comName = comName.replaceAll(" - Phase 2 Now Selling!| - New Phase Coming Soon!", "");
			
			if(comUrl.contains("https://www.dreamfindershomes.com/northern-oaks")) {minPrice=ALLOW_BLANK;maxPrice=ALLOW_BLANK;}
			if(comUrl.contains("https://www.dreamfindershomes.com/laureate-park"))propStatus="New Phase Coming Soon";
			if(comUrl.contains("https://www.dreamfindershomes.com/blanco-vista"))propStatus="Currently Sold Out, New Phase Coming Soon";
			
			if(comSec.contains("<div class=\"subtitle\"> Last Chance </div>"))
				if(propStatus==ALLOW_BLANK)
					propStatus = "Last Chance";
				else if(!propStatus.contains("Last Chance"))
					propStatus += ", Last Chance";
			
			if(comSec.contains("<div class=\"subtitle\"> Sold Out </div>"))
				if(propStatus==ALLOW_BLANK)
					propStatus = "Sold Out";
				else if(!propStatus.contains("Sold Out"))
					propStatus += ", Sold Out";
			
			if(comUrl.contains("https://dreamfindershomes.com/maryland/scotland-heights/")) {
				comUrl="https://dreamfindershomes.com/scotland-heights-vip/";
			}
		
			if(comUrl.contains("https://dreamfindershomes.com/northern-virginia/jefferson-square/"))propType=propType.replace(", Sixplex", "");
			
			if(comUrl.contains("https://www.dreamfindershomes.com/hammock-reserve")||comUrl.contains("https://www.dreamfindershomes.com/hartwood-landing")||comUrl.contains("https://www.dreamfindershomes.com/cypress-park-estates"))propType="Patio Homes";
			
			if(comUrl.contains("com/scotland-heights-vip/")|| comUrl.contains("/potomac-station-marketplace-vip/")|| comUrl.contains("wolf-creek-run-vip/"))note="Address & LatLong Taken From City and State";


			if(comUrl.contains("/texas/castlewood/"))propStatus="Coming Soon";//bcz stat oner extra stst given
//			==============================================================================================
			
			if(interactiveHTML.contains("Covered Patio") || interactiveHTML.contains("Extended Patio")) {
				if(!propType.contains("Patio Homes")) {
				if(propType.length()>0)
				{
					propType+=", Patio Homes";
				}
				else
					propType="Patio Homes";
				}
					
			}
			
			
			String link=U.getSectionValue(html, "Community Gallery</h2>  <ul class=\"float-md-right\">\n" + 
					"          <li><a href=\"", "\"");
			
			U.log("link===="+link);
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim().toUpperCase(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo );
			data.addPropertyType(propType.replace("Townhouse, Townhome", "Townhouse"),dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//		}catch(Exception e) {}
	}
	
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//driver.manage().window().maximize();

					//U.log("after::::"+url);
					Thread.sleep(10000);
//					Thread.sleep(5000);
//					Thread.sleep(5000);
//					Thread.sleep(5000);
//					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,4000)", "");
					U.log("Current URL:::" + driver.getCurrentUrl());
					Thread.sleep(10000);

					try{
						WebElement load;
						if(url.contains("https://www.dreamfindershomes.com/communities")){
							load = driver.findElement(By.xpath("//*[@id=\"et-main-area\"]/section[2]/div/div[2]/div[2]"));//load communities
							Thread.sleep(10000);

						}
						else {
							load = driver.findElement(By.xpath("//*[@id=\"quick-move-in-homes-community-main\"]/div/div[4]"));//load floor plans
							U.log(load);
						}
						
						while(load.isDisplayed())
						{
							load.click();
							U.log(":::::::Click Success:::::::::::");
							Thread.sleep(10000);
						}
						load = driver.findElement(By.xpath("//*[@id=\"custom-floorplan-community-main\"]/div/div/div[3]/div[8]/a"));//load floor plans
						while(load.isDisplayed())
						{
							load.click();
							U.log(":::::::Click Success:::::::::::");
							Thread.sleep(10000);
						}
						
					}
					catch(Exception e){
						U.log(":::::::Click UnSuccess:::::::::::");
						try {
						WebElement load = driver.findElement(By.xpath("//*[@id=\"custom-floorplan-community-main\"]/div/div/div[3]/div[8]/a"));//load floor plans
						while(load.isDisplayed())
						{
							load.click();
							U.log(":::::::Click Success:::::::::::");
							Thread.sleep(10000);
						}}catch(Exception h) {}
					}
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
}