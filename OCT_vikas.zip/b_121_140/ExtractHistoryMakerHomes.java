/**
 * @author Parag Humane 
 * @date 5/4/2012
 * 
 */
package com.shatam.b_121_140;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractHistoryMakerHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	public static WebDriver driver =null;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractHistoryMakerHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"HistoryMaker Homes.csv", a.data()
				.printAll());
	}

	public ExtractHistoryMakerHomes() throws Exception {

		super("HistoryMaker Homes", "https://www.historymaker.com/");
		LOGGER = new CommunityLogger("HistoryMaker Homes");
	}
	
	public void innerProcess1() throws Exception {
		String html = U.getHTML("https://www.historymaker.com");
		String section = U.getSectionValue(html, ",\"communities\":{\"5702c34df410954eb27d04aa\"", ",\"unpublished\":");
		//U.log(section);
		String comSection[] = U.getValues(section, "{\"@type\":\"GatedResidenceCommunity", "\"type\":\"community\"}");
		//U.log(comSection.length);
		for(String comSec : comSection){
			//U.log(comSec);
			break;
			
		}
	}
	
	public void innerProcess() throws Exception {


//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String mainUrl= getHtml("https://www.historymaker.com/communities", driver);
		String list[] = U.getValues(mainUrl, "<div class=\"CommunityCard_contentWrapper\"", "View Details</a></div>");
		U.log(list.length);
		for (String item : list) {
//			U.log(item);minSqf :
			String url = U.getSectionValue(item, "<a class=\"\" href=\"", "\"");
//			try {
				addDetails2("https://www.historymaker.com"+url,item);
//			} catch (Exception e) {}
		
		}
		LOGGER.DisposeLogger();
//		driver.quit();
	}

	private void addDetails2(String url,String comsec) throws Exception {
		
//		try{
//			if(j >=0 &&  j<=10)
//				if(j >22 &&  j<=33)
//					if(j >12 &&  j<=22)
//						if(j >=3 && j<=12)
//		if(!url.contains("https://www.historymaker.com/communities/hous						ton/la-porte/artesia-village")) return;

			{
//				if(!url.contains("https://www.historymaker.com/communities/dallas-fort-worth/aubrey/arrowbrooke"))return;
				
				 
		U.log("\n\ncount =="+j+"=="+url);
		
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"<=========== Repeated");
			return;																																																										
		}
		LOGGER.AddCommunityUrl(url);

		U.log(U.getCache(url));
//		U.log("comsec   === "+comsec);
		String html = getCommunityHtml(url,driver);																																																																																																																																																																																																												
		
	//	String html2=html;
		String rmsec = U.getSectionValue(html, "Nearby Communities</h3>", "</body></html>");
		
		if(rmsec==null)rmsec = U.getSectionValue(html, "<script>window.__PRELOADED_STATE", "</html");
		
		if(rmsec!=null)
		html=html.replace(rmsec, "");
		
		if(rmsec==null)
			rmsec = "";
		//============ Community Name ==============
		
		String name = U.getSectionValue(comsec, "<h4 class=\"CommunityCard_title mb-3\"", "</h4><");
		if (name != null)	name=name.replaceAll("data-reactid=\"\\d+\"", "");
		name = name.replaceAll("<strong>|&nbsp|;|-|Our|>", "").trim();
		name=name.replace("Townhomes", "");
		if(url.contains("missouri-city/sienna-townhomes-at-parkway-place"))name="Sienna Townhomes At Parkway Place";
		U.log("ComName==="+name);

		//============== Address ==============
		

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String geo = "False";
		String adLink = U.getSectionValue(html, "https://www.google.com/maps/place/", "/@");
		
		//U.log("LATLNG SECTION"+adLink);
		if (adLink != null) {
			String[] latlng = adLink.split(",");
			lat = latlng[0];
			lng = latlng[1];
			if (lat.startsWith("-")&&lng.startsWith("-")) {
				lat=lng=ALLOW_BLANK;
			}
		}
			String address = U.getSectionValue(comsec, "<hgroup class=\"mb-2 mb-lg-0 mr-lg-2\"",	"</h5></hgroup>").replace("Frwy,", "Frwy");
			if(address!=null) {
				address = address.replaceAll("</h5><h5 class=\"CommunityCard_subtitle\" data-reactid=\"\\d+\">|</h5><h5 class=\"CommunityCard_subtitle\"><!-- react-text: \\d+ -->", ",")
						.replaceAll("By Appointment Only|<!-- /react-text --><!-- react-text: \\d+ -->|SELLING FROM|Selling From|(Now )?Pre-Selling by Appointment Only|Now Selling by Appointment|Coming Soon to|Model", "");
//				U.log(address);
				add = U.findAddress(address);
				if(add == null)add = new String[]{ ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			}
			
		if(add[0].equals("2820 Fox Trail, Lane")) {
			add[0] = "2820 Fox Trail Lane";
		}	
			if(add[0].length()>6 )add[0]=add[0].replace("New Phase", "");
			U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2]+ " Z:" + add[3]);
	
		add[0] = add[0].replaceAll("Model Coming Soon|Coming Soon", ALLOW_BLANK);
		if(add[0].length()<4 && add[3] != ALLOW_BLANK){
			if(lat != ALLOW_BLANK && lng != ALLOW_BLANK){
				String [] latLng = {lat,lng};
				String add1[] = U.getAddressGoogleApi(latLng);
				if(add1 == null) add1 = U.getAddressHereApi(latLng);
				add[0] = add1[0];
				geo = "True";
			}
		}
		if (add[0]!=ALLOW_BLANK&&lat==ALLOW_BLANK) {
			String latLng[]=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			lat=latLng[0];
			lng=latLng[1];
			geo="TRUE";
		}
		if (add[0]==ALLOW_BLANK&&lat!=ALLOW_BLANK) {
			add = U.getAddressGoogleApi(new String[]{lat,lng});
			if(add == null) add = U.getAddressHereApi(new String[]{lat,lng});
			geo="TRUE";
		}
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices((html + comsec).replace("<span data-reactid=\"1883\">$362,990</span>", ""), "\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>",0);
//				"FROM \\$\\d{3},\\d{3}|Price\">\\$\\d+,\\d+|lblPrice\">\\$[0-9]{3},[0-9]{3}|priced from the \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		if (maxPrice.equals(minPrice))
			maxPrice = ALLOW_BLANK;
//		U.log(comsec);
		
	//	U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comsec+html, "[\\w\\s\\W]{50}362[\\w\\s\\W]{30}", 0));
		
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		html = html.replaceAll("</b><!-- react-text: \\d+ -->SQ FT", " SQ FT").replace("SQ FT Range <!-- /react-text --><b data-reactid=\"\\d+\">", "SQ FT Range ").replaceAll("</b><!-- react-text: \\d+ --> SQ FT", " SQ FT").replaceAll("SQ FT Range <!-- /react-text --><b data-reactid=\"\\d+\">", "SQ FT Range ");
		String[] sqft = U
				.getSqareFeet(
						comsec+html,"SQ FT Range <!-- /react-text --><b data-reactid=\"239\">1,458 - 1,742|\\d,\\d{3}-\\d,\\d{3} Square Feet|SQ FT Range \\d,\\d{3} - \\d,\\d{3}|SQ FT Range \\d{3} - \\d,\\d+|SQ FT Range \\d,\\d{3} - \\d,\\d{3}|SQ FT Range \\d,\\d{3}|\\d,\\d{3} SQ FT",0);
						//"\\d,\\d+ to \\d,\\d+ sq. ft.|from \\d,\\d{3} to \\d,\\d{3} square feet|[0-9]{1},[0-9]{3} square feet|SQUARE FOOTAGE:</strong><br />\\d+|SQUARE FOOTAGE:</strong><br />[\n,\\s]*\\d+|<td width=\"85\">\\d{4}</td>|chance to own a [0-9]{1},[0-9]{3} to [0-9]{1},[0-9]{3}|ranging from [0-9]{1},[0-9]{3} to square|lblSqft\">\\d{4}</span>",
//						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html+comsec, "[\\w\\s\\W]{50}1,742[\\w\\s\\W]{30}", 0));
		
		String newhtml=U.getHTML(url);
		String planHtml = ALLOW_BLANK,quickHtml=ALLOW_BLANK;
		String floorUrls[]= U.getValues(html, "<div class=\"PlanCard_contentWrapper", "<span class=\"CompareButton_indicator");
		for(String floordata:floorUrls) {
			String floorurl = U.getSectionValue(floordata, "<a class=\"\" href=\"", "\"");
			String fhtm = U.getHTML("https://www.historymaker.com"+floorurl);
			String rm = U.getSectionValue(fhtm, ">Additional Floor Plans</h3>", "</body></html>");
			try {
			planHtml += fhtm.replace(rm, "");
			}catch(Exception e) {U.log(e);}
		}
		String sts="";
		try {
//		String quickUrls[]= U.getValues(html, "<div class=\"HomeCard_contentWrapper\"", "View Details</a></div>");
			String quickUrls[]= U.getValues(html, "<h5 class=\"HomeCard_priceValue\"", "View Details</a></div>");
		U.log("quickcount==="+quickUrls.length);
		int quickTot=quickUrls.length;
		int nomvCnt=0;
		for(String qhm:quickUrls) {
//			U.log("Home Details "+qhm);
			if(qhm.contains("Under Construction"))
				nomvCnt++;
		}
		
		
		U.log("total quick hm "+quickTot);
		U.log("No move in hm "+nomvCnt);
		
		//if(quickUrls.length>0) {
		if(quickTot>nomvCnt) {	
			if(sts == ALLOW_BLANK)
				sts="Quick Move-In Homes";
			else if(sts != ALLOW_BLANK && !(sts.contains("Quick Move")))
				sts = sts + ", Quick Move-In Homes";
		}
		for(String qucikdata:quickUrls) {
			String quickurl = U.getSectionValue(qucikdata, "<a class=\"\" href=\"", "\"");
			String qhtm = U.getHTML("https://www.historymaker.com"+quickurl);
//			U.log(U.getCache("https://www.historymaker.com"+quickurl));
			String rm = U.getSectionValue(qhtm, "Quick Move-In Homes Nearby</h3>", "</body></html>");
			if(rm!=null)
			quickHtml += qhtm.replace(rm, "");
			
		}
		}
		catch(Exception e) {}
		
		
		
		String rmsec1 = U.getSectionValue(newhtml, "Nearby Communities</h3>", "</body></html>");
		if(rmsec1!=null)
		newhtml= newhtml.replace(rmsec1, "");
		newhtml = newhtml.replace(rmsec, "");
		String pType = U.getPropType((newhtml+quickHtml+planHtml).replaceAll("participation", ""));
		pType = pType.replaceAll("Townhouse,Townhome|Townhouse, Townhome", "Townhome");
		comsec= comsec.replaceAll("</b><!-- react-text: \\d+ -->Stories", " story");
		html=html.replaceAll("</b><!-- react-text: \\d+ --> Stories|</b><!-- react-text: \\d+ -->Stories", " story").replace("master community ", "master-planned amenities");
		String dType = U.getdCommType((html+comsec+quickHtml+planHtml).replace("Branch",""));
		String Type = U.getCommunityType(html+comsec);
		
//		String statSec = html;
//		comsec = comsec.replaceAll("</b><!-- react-text: 745 -->Quick Move-In Homes", " Quick Move-In Homes");
//		statSec =U.removeComments(statSec);
//		statSec = statSec.replace("<strong> SOLDOUT</strong>", "Sold Out");
//		String remove = "Elementary - Opening Fall 2019|alt=\"Greywood Estates Com| move in ready homes Fort Worth|Now Selling - New Model Coming Soon|Model coming soon|Town Center coming soon|move-in ready houses fort worth|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
//		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
//		statSec = statSec
//				.replaceAll(
//						"grand opening - tour terrel|tx, coming soon|coming soon: wal-mar|rptsubnav_ctl01_lnk\" style=\"\">quick move-in homes</a>|/inventories/search/\">quick move-in homes</a>|opening in the fall of 2017|\">Quick Move-in Homes</a>|>QUICK MOVE-IN HOMES</a>|>Quick Move-In Homes</a>",
//						"")
//				.replace("new phase. now selling", "New PHASE NOW SELLING");
		html=html.replace(" oversized and water view lots", "Water View and Oversized Lots Available").replace("Oversized Lots +", "Oversized Lots Available +").replace("new phase of Homestead is now selling", "new phase now selling").replace("ready to move into a larger", "");
		//.replace("$0-down", "0 down financing available")
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(newhtml+quickHtml+planHtml, "[\\w\\s\\W]{100}custom[\\w\\s\\W]{100}", 0));
		if(url.contains("dallas-fort-worth/arlington/twin-hills"))comsec=comsec.replace("<!-- react-text: 2664 -->Now Selling", "");
		
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comsec+html, "[\\w\\s\\W]{30}quick move in[\\w\\s\\W]{30}", 0));
		
		html=html.replace("You’ll even find limited opportunities for oversized and water view lots","Limited Opportunities Available Oversized and Waterview Lots available");
		//html=html.replace("oversized and water view lots","Oversized and Waterview Lots available");
		comsec=comsec.replaceAll("Coming Soon to<|Model Coming Soon", "")
				.replace("New Townhomes in Sherman Coming Soon", "New Townhomes Coming Soon")
				.replaceAll("New Home Community Coming Soon|New Homes in Texas City Coming Soon|New Homes in Godley, TX - Coming Soon", "New Homes Coming Soon");
		html=html
				.replace("$0-down financing", "0 down financing")
				.replaceAll("New Homes Coming Soon to Fulshear|New Homes in Texas City Coming Soon|New Homes in Godley, TX - Coming Soon", "New Homes Coming Soon")
				.replace("even find limited opportunities forWater View and Oversized Lots Available", "")
				.replace("New Townhomes in Sherman Coming Soon", "New Townhomes Coming Soon")
				.replaceAll(">Now Selling<|Coming Soon to<|streetAddress\":\"Coming Soon to|Model Coming Soon|-->Coming Soon<!--", "");

		String status = ALLOW_BLANK;
		if(url.contains("communities/houston/fulshear/fulshear-lakes")|| url.contains("/dallas-fort-worth/arlington/ridge-point-addition")
				|| url.contains("dallas-fort-worth/arlington/mayfield-farms"))
		{
			comsec=comsec.replace(">Coming Soon<", "");
		}
		status = U.getPropStatus((comsec+html)
				.replace("(CLOSEOUT)\\u003c", "")
				.replaceAll("Coming to Sherman Summer 2022|COMING TO SHERMAN SUMMER 2022", "COMING SUMMER 2022")
				.replaceAll("move-in ready|design — is now open at|title\":\"Last chance to live at|Quick Move-In|Model Coming Soon|HistoryMaker Homes Coming Soon To Popular Chisholm|your last chance to live at", "")
				.replace("has nearly sold out of single-family homes", "has sold out of single-family homes")
				.replaceAll("\">Limited Time Offer: Get|homes are sold out|Address\":\"Coming|Check out our quick move|react-text: 1143 -->Coming Soon|Quick Move-In Homes<!-- /react-text --></a></li>|data-reactid=\"\\d+\">Quick Move-In Homes</a>|Quick Move-In Homes</a></li><", "")+sts);
		
//		U.log("MMMMMMMMMMMMMMMM11 "+Util.matchAll(comsec , "[\\w\\s\\W]{50}financing[\\w\\s\\W]{40}", 0));
//		U.log("MMMMMMMMMMMMMMMM22 "+Util.matchAll( html, "[\\w\\s\\W]{30}financing[\\w\\s\\W]{40}", 0));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comsec + html, "[\\w\\s\\W]{30}New Homes Coming Soon[\\w\\s\\W]{40}", 0));
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comsec + html, "[\\w\\s\\W]{30}Few Opportunities Remain[\\w\\s\\W]{40}", 0));
		
		//		U.log("status>>>>>>>>>>>>>>>>>" + status);
//		U.log("comsec>>>>>>>>>>>>>>>>>" + comsec);
		if(url.contains("https://www.historymaker.com/communities/dallas-fort-worth/waxahachie/sheppards-place"))
			status="New Phase Coming Soon";  ///cache issue cache was not updating
		if(url.contains("https://www.historymaker.com/communities/houston/rosenberg/seabourne-landing")||url.contains("https://www.historymaker.com/communities/dallas-fort-worth/heartland/heartland-townhomes"))
			status="New Phase Coming Soon";  ///cache issue cache was not updating

		
		if(status.contains("0 Quick Move-in Homes")) {
			status=status.replace("0 Quick Move-in Homes", "-");
		}
		
		if (add[0]==ALLOW_BLANK || add[0].length()<3) {
			add = U.getAddressGoogleApi(new String[]{lat,lng});
			if(add == null) add = U.getAddressHereApi(new String[]{lat,lng});
			geo="TRUE";
		}
		
		if(status!=null)
			if(url.contains("houston/la-porte/artesia-village")) {
				if(status.contains("Water View Homesites Available, Lots Available"))
				{
					status=status.replace("Water View Homesites Available, Lots Available", "Water View and Oversized Lots Available");
				}
			}
			status = status.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
			status = status.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
		if(pType.length()>180)pType = ALLOW_BLANK;
		
		if(status.equals("New Homes Coming Soon, Coming Soon")) {
			status = status.replace(", Coming Soon", "");
		}
		if(status.equals("New Townhomes Coming Soon, Coming Soon")) {
			status = status.replace(", Coming Soon", "");
		}
		if(status.equals("New Homes Coming Soon, Coming Summer 2022, Coming Soon")) {
			status ="Coming Soon";
		}
//		if(status.contains(", Quick Move-in")) {
//			status = status.replace(", Quick Move-in", ", Quick Move-in Homes");
//		}
		
//		status = status.replace("Quick Move-in", "Quick Move-in Homes");
		
		
		U.log("status: " + status);
		String note = U.getnote((html+comsec).replaceAll("about our pre-grand opening", ""));
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		
		
		data.addCommunity(name.toLowerCase(), url, Type);
		data.addAddress(add[0].toLowerCase().replace(".", ""), add[1].toLowerCase(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(),geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);

	}j++;
//	}
	
//		}catch (Exception e) {
			// TODO: handle exception
//		}
	

}
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,600)", ""); 
					Thread.sleep(5000);
					try{
					WebElement loadBtn = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[6]/div[3]/div[2]/span"));
					while(loadBtn.isDisplayed()) {
					loadBtn.click();
					}
					U.log("Current URL:::" + driver.getCurrentUrl());
					}
					catch(Exception e){
						U.log(":::::::Click UnSuccess:::::::::::");
					}
					Thread.sleep(2000);
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();
				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	public static String getCommunityHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {
					driver.manage().window().maximize();
					
					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					
					//U.log("after::::"+url);
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,1000)", "");
					Thread.sleep(5000);
					
					////*[@id="sort-section"]/div[2]/div[2]/span
					////*[@id="sort-section"]/div[2]/div[2]/span
					//*[@id="sort-section"]/div[2]/div[2]/span
					
					
/*					try{
					WebElement loadmoreBtn = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[9]/div[2]/div[3]/div/div/div[2]/div[2]/span"));
					while(driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[9]/div[2]/div[3]/div/div/div[2]/div[2]/span")).isDisplayed()) {//*[@id="sort-section"]/div[2]/div[2]/span
					loadmoreBtn = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[9]/div[2]/div[3]/div/div/div[2]/div[2]/span"));
					loadmoreBtn.click();
					Thread.sleep(2000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,600)", ""); 
					}
					}
					catch(Exception e) {
						
					}*/
					try{
						WebElement loadmoreBtn = driver.findElement(By.xpath("//*[@id=\"sort-section\"]/div[2]/div[2]/span"));
						while(driver.findElement(By.xpath("//*[@id=\"sort-section\"]/div[2]/div[2]/span")).isDisplayed()) {
							loadmoreBtn = driver.findElement(By.xpath("//*[@id=\"sort-section\"]/div[2]/div[2]/span"));
							loadmoreBtn.click();
							Thread.sleep(3000);
							((JavascriptExecutor) driver).executeScript("window.scrollBy(0,600)", "");
							U.log("successfully -->click on more button");
						}
					}
					catch(Exception e) {
						U.log("unsuccessfully -->click on more button");
					}
					
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}}
		

		// else{
		// return null;
		// }
	
	}