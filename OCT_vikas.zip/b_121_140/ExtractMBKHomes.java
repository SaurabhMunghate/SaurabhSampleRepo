/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_121_140;

import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMBKHomes extends AbstractScrapper{
    CommunityLogger LOGGER;
    int j=0;
	public ExtractMBKHomes()
			throws Exception {
		super("MBK Homes","http://www.mbkhomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("MBK Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractMBKHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"MBK Homes.csv", a.data().printAll());
	}

	HashMap<String, String> list=new HashMap<>();
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("http://mbkhomes.com/home/content/neigh/map/");
		String datasec=U.getSectionValue(mainHtml, "infoWindowContent = [","];");
		String[] addSec=U.getValues(datasec,"[","]");
		for(String lists:addSec)
		{
			String rem=U.getSectionValue(lists,"<a","</a>");
			lists=lists.replace(rem,"");
			//U.log("list--->"+list);
			String name=(U.getSectionValue(lists, "I\">","</a>")).trim();
			//U.log("kkkk--->"+name);
			list.put(name, lists);
		}
		String commSec=U.getSectionValue(mainHtml, "locations = [","];");
		String[] commsecs=U.getValues(commSec, "[","]");
		U.log("Total Count----->"+commsecs.length);
		for(String com:commsecs)
		{
			String url="http://mbkhomes.com/home/content/neigh/"+U.getSectionValue(com, "../","'");
			//U.log("comUrl---->"+url);
			addCommunity(url,com);
		}
		
	}

	private void addCommunity(String comUrl, String oldData) throws Exception {
		// TODO Auto-generated method stub
		
		//if(!comUrl.contains("http://mbkhomes.com/home/content/neigh/?neigh_id=1065&page_id=I"))return;
		
		String html=U.getHTML(comUrl);
		String floorPlan=U.getSectionValue(html, "<ul id=\"sideNav\">", "</ul>");
		floorPlan=U.getSectionValue(floorPlan, "page_id=P", "Siteplan");
		U.log("floorPlan : "+floorPlan);
		floorPlan=U.getHTML(U.getSectionValue(floorPlan, "href=\"", "\""));
		floorPlan=U.getSectionValue(floorPlan, "<table", "</table>");
		U.log("floorPlan : "+floorPlan);
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(oldData, "'","'");
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		U.log("list size"+list.size());
		String addsec=list.get(communityName.trim());
		U.log("*&*&*&*"+addsec);
		String priceSec=addsec;
		U.log("addsec:::"+addsec);
	
		U.log("hrllo---->"+oldData);
		
		if(html.contains("Directions</a>")){
			String mapUrl=U.getSectionValue(html, "M';\" style=\"cursor:pointer;\"><a href=\"", "\"");
			U.log("mapUrl::"+mapUrl);
			String addSection=U.getSectionValue(html, "/b><br>", "</font>");
			U.log(addSection);
			if(addSection!=null){
				addSection=addSection.replace("<br>", ",");
				String[] myAdd=addSection.split(",");
				if(myAdd.length==3){
					add[0]=myAdd[0];
					add[1]=myAdd[1];
					add[2]=Util.match(myAdd[2], "\\w+");
					add[3]=Util.match(myAdd[2], "\\d+");
				}
			}
		}
		
//------------------------------------------------------------------------------------------------------------------
		
		String latSec=U.getSectionValue(oldData, "',",", ");
		U.log("lat--->"+latSec);
		if(latSec!=null)
		{
			latlag=latSec.split(",");
			U.log("Latlong--->"+latlag[0]+"  "+latlag[1]);
		}
		else
		{
			if(add[1]!=null && add[1]!=ALLOW_BLANK)
			{
				latlag=U.getlatlongGoogleApi(add);
			}
			geo="TRUE";
			U.log("HEllloooo");
		}
		if(add[0]==ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		}
		
//============================================Price and SQ.FT======================================================================
		String[] maltisec=U.getValues(html, "<li><a class=\"menuitem\" href=\"","\"");
		
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

	
		String prices[] = U.getPrices(html+priceSec,"\\$\\d,\\d+,\\d+|high \\$\\d{3},\\d{3}|mid \\$\\d{3},\\d{3}|the Low \\$\\d{3},\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		
		//String sqftSec = U.getSectionValue(datasec, "<div class=info_content>", "</div>']");
		
		//2,157 square feet
		String[] sqft = U
				.getSqareFeet(
						html+floorPlan+addsec,
						"\\d,\\d{3}\\s+square\\s+feet|\\d,\\d+ to \\d,\\d+ Sq. Ft|\\d,\\d+ Sq. Ft|\\d,\\d+ sq. ft|\\d,\\d{3}\\sto\\s\\d,\\d{3}\\sSq. Ft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		
//--------------------REMOVED SECTION---------------------------
		html=html.replaceAll("Coming Soon</li></ul>|Rancho", "");
		
		
//================================================community type========================================================
		String communityType=U.getCommType(html+priceSec);
		
//==========================================================Property Type================================================
		html=html.replace("No HOA","");
		html=html.replace(" farmhouse interpretive", "Farmhouse-inspired architectural").replace("architectural styles including: Spanish, French Country and Craftsman", "craftsman exterior");
		String proptype=U.getPropType(html+priceSec);
		
//==================================================D-Property Type======================================================
		html=html.replace("three-story"," 3 Story ");
		floorPlan=floorPlan.replace("two-story", "2 Story");
		String pHtml=U.getHTML(comUrl.replace("page_id=I","page_id=P"));
		
		String dtype=U.getdCommType((html+floorPlan).replaceAll("[R|r]ancho|Ladera Ranch|ranchomissionviejo", ""));
		
//==============================================Property Status=========================================================
		html = html.replace("Upgraded Homes Ready for Move-In", "").replace("homes are selling fast", "homes selling fast").replace("Coming Soon! Move-In Ready Homes", "Coming Soon!");
		String pstatus=U.getPropStatus(html);
//============================================note====================================================================
		String note=U.getnote(html);
		
		if (this.data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		if(data.communityUrlExists(comUrl))return;
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
		j++;
	}

}
