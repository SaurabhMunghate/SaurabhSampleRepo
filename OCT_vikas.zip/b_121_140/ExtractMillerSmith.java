/** @author Parag Humane
 *  @date 24/05/2013 
 */

package com.shatam.b_121_140;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMillerSmith extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	static int j=0;
	WebDriver driver= null;
	HashMap< String, String > myComList = new HashMap<String, String>();
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractMillerSmith();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Miller and Smith.csv", a.data()
				.printAll());
	}

	public ExtractMillerSmith() throws Exception {

		super("Miller and Smith", "https://www.millerandsmith.com");
		LOGGER = new CommunityLogger("Miller and Smith");

	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHtmlHeadlessFirefox("https://www.millerandsmith.com/",driver);
		String[] re= U.getValues(html, "<div class=\"home-info-box\">", "</li>");
		
//		U.log(re.length);
		for(String comSec : re) {
			
			String comName = Util.match(comSec,"<h3>.*</a></h3>");
			comName = U.getNoHtml(comName);
			
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
			String comHtml = U.getHtmlHeadlessFirefox(comUrl, driver);	
			
			String[] subComSec = U.getValues(comHtml, "<div class=\"collection-box d-flex flex-wrap align-items-center\">", "</li>");
			if(subComSec.length>0) {
				
				for(String subCom : subComSec) {
					
					if (subCom.contains("View Collection</a>")) {
						comName = Util.match(subCom, "<h3>.*</a></h3>");
						comName = U.getNoHtml(comName);
						comUrl = U.getSectionValue(subCom, "<a href=\"", "\"");
						
						addDetails(comName, subCom+comSec);
					}
					
				}
				
			}
			else {
				addDetails(comName, comSec);
			}
			
		}

		
		U.log(myComList.size());
		//---------iterating myComList---------
		Iterator it = myComList.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry myentry = (Map.Entry)it.next();
	       // System.out.println(myentry.getKey());
	        String name = myentry.getKey().toString();
	        String dataSec=myentry.getValue().toString();
	        if(dataSec.contains("<a href=\""))addDetails(name, dataSec);
	    }
		
//		driver.quit();
		try{driver.quit();}catch(Exception e){}
		LOGGER.DisposeLogger();
		i++;
	}

	private void addDetails(String cName, String info) throws Exception {
		//TODO : For Single Community Execution
	//	if(j==5)//https://www.millerandsmith.com/new-homes-for-sale-virginia/manassas/cayden-ridge
//		try{

		{
		
		U.log("count::::::::::::"+j);
		String cUrl = U.getSectionValue(info, "<a href=\"", "\"");
		
		if(cUrl.contains("page_id=58"))cUrl="/?page_id=3836";
		if(cUrl.contains("maryland/aspen-north/"))cUrl="/maryland/new-market/aspen-north/";
		
		if(cUrl.contains("/maryland/clarksburg/grapevine-ridge/") || cUrl.contains("/community/beacon-park-towns-at-belmont-bay/") || cUrl.contains("https://www.liveembreymill.com/"))return; //page not found
		
//		U.log(">>>>>>>>>>"+info);
//		========= Single Run =======================
		
		
//		if(!cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/woodbridge/beacon-park-towns-at-belmont-bay/"))return; //Single execution
		
//		U.log(">>>>>>>>>>"+info);
		
		
		if(cUrl.contains("community/eden-brook/"))cUrl ="https://www.millerandsmith.com/new-homes-for-sale-maryland/columbia/eden-brook";
		if(!cUrl.contains("http"))
		cUrl = "https://millerandsmith.com"+cUrl; 
		U.log("\nPAGE :" + cUrl);
		
		if(data.communityUrlExists(cUrl)) {
			
			LOGGER.AddCommunityUrl("============= :Repeated: ============ "+cUrl);
			return;
		}
		LOGGER.AddCommunityUrl(cUrl);
		
		String html = U.getHtml(cUrl,driver);
		String statusSec  = U.getSectionValue(html, "<a href=\""+cUrl+"\"", "</a>");
		U.log(statusSec+":::::::::::status"+U.getSectionValue(html, "<a href=\""+cUrl+"\"", "</a>"));
		String artical = U.getSectionValue(html, "<article", "</article>");
		if(artical == null) 
			artical = U.getSectionValue(html, "<div class=\"community-detail-info\">", "Read less</a>");
		String ss=U.getSectionValue(html, "<header class=\"entry-header\">", "<span class=\"corp_headquarters\">");
		String drop = U.getSectionValue(html, "data-ubermenu-target=\"ubermenu-main-2\" class=\"ubermenu-responsive", "Contact Us</span></a></li></ul></nav>");
		if(drop!=null){
			html = html.replace(drop, "");
		}

/*		drop = U.getSectionValue(html, "<head>","</header>");
		if(drop!=null)	html = html.replace(drop, "");
*/		
		
		String remnove = U.getSectionValue(html, "</head><body", "</script>");
		if(remnove != null)
			html = html.replace(remnove, "");
		

		//========= Community Name ================
		String commName =ALLOW_BLANK;
		/*= U.getSectionValue(html, "<h1 class=\"text-uppercase\">","<");
				//.replace(" - Miller &amp; Smith", "");
		if(commName==null)
			commName = U.getSectionValue(html, "<h1 class=\"entry-title\">", "<");*/
		//commName = U.getSectionValue(html, "<h1>", "</");
		commName = cName.replace("<br>", "");
		U.log("commName::"+commName);

		//=========== Address =============
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//		html += U.getHtml(url + "?cat=directions",driver);
		html =html.replace("<div class=\"col-xs-10\"><p>&nbsp;", "<div class=\"col-xs-10 wdh\"><p>");
		String addSec = U.getSectionValue(html, "<h2>Get In Touch</h2>", "</script>");

		if(addSec==null)
			addSec = U.getSectionValue(html, "<div class=\"contact-info\">", "</p></div>");
		String addSec1 = null;
		
//		
		if(addSec!= null) {
			addSec1 = U.getSectionValue(addSec, "rel=\"noopener noreferrer\">", "</a>");
			
			U.log("addSec1 inside: " + addSec);
			
			if(addSec1!=null)
			add = U.getAddress(addSec1);
		}
		
		if(addSec!= null && add[0]==null)
			addSec1 = U.getSectionValue(addSec, "target=\"_blank\">", "</a>");
		
		//U.log("addSec1 -------:" + addSec);
		if(addSec!= null && addSec1 == null && add[0]==null)
			addSec1 = U.getSectionValue(addSec, "rel=\"noopener noreferrer\">", "</a>");
		//U.log("addSec1 :" + addSec);
		
		if(addSec== null && addSec1 == null && add[0]==null)
			addSec1 = U.getSectionValue(html, "rel=\"noopener noreferrer\">", "</a>");
		
		//U.log("addSec2 :" + addSec);
		
		addSec = addSec1;
		if(addSec!=null)
		{
		
			addSec =addSec.replace("<br />", ",");
			addSec =addSec.replace("Street<br />", "Street,");
			addSec = addSec.replace("Exchange St.", "Exchange St.,").replace("Terrace Ashburn", "Terrace, Ashburn").replace(" VA", ", VA").replace(" Ashburn", ", Ashburn")
					.replace("Court New Market", "Court, New Market").replace(",,", ",")
					.replaceAll("Selling from the Windchase Model at Cayden Ridge -|<br>", "").replace(" Road, Suite 200  Vienna, Virginia", " Road Suite 200, Vienna, VA ")
					.replace(" - Columbia", " , Columbia");
			
			U.log(">>>>>11:::::"+addSec);
			addSec = U.formatAddress(addSec);
			//U.log("addSec Inn :" + addSec);
			addSec = addSec.replace("Road, Suite ", "Road Suite ").replace("Rd, Suite", "Rd Suite");
			//U.log(addSec);
			if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/manassas/cayden-ridge")||cUrl.contains("manassas/signal-hill-crossing/")) {
				addSec=" ,Manassas, VA, ";
			}
			if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-maryland/columbia/eden-brook"))
			{
				addSec="8640 Guilford Rd,Columbia,MD,21046";
				
			}
			if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-maryland/clarksburg/tapestry/"))
			{
				addSec="209 Red Oak Ridge Place, Clarksburg, MD 20871";
				
			}
			if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-maryland/ellicott-city/patapsco-crossing/"))
			{
				addSec="8639 Old Frederick Road, Ellicott City, MD 21043";
				
			}
			U.log(addSec);
			addSec=addSec.replace("209 Red Oak Ridge Place Clarksburg, MD 20871", "209 Red Oak Ridge Place,Clarksburg,MD,20871")
					.replace("Place - Suite", "Place Suite");
					
			
			String[] addrs = addSec.split(",");
			
			
			U.log("My address:"+Arrays.toString(addrs));
			if(addrs.length!=2){
				add[0] = addrs[0];
				add[1] = addrs[1];
				add[2] = Util.match(addrs[2], "\\w{2}");
				if(addrs.length==3)add[3] = Util.match(addrs[2], "\\d{5}");
				else
				add[3] = Util.match(addrs[3], "\\d{5}");
			add[0] = add[0].replace(",", "").trim();
			}
			
		}
		
		
		if(addSec==null ){//|| !cUrl.contains("http://millerandsmith.com/maryland/frederick/tallyn-ridge/")
			String addreSecNew=U.getSectionValue(html,"name=\"daddr\" value=\"","\"");
			U.log("addreSecNew= "+addreSecNew);
			if(addreSecNew!=null && addreSecNew.length()>25){
				String[] addrs = addreSecNew.split(",");
				U.log("addreSecNew= "+addreSecNew);
				
			add[0] = addrs[0];
			//U.log(add[0]);
			add[1] = addrs[1].trim();
			//U.log(add[1]);
			add[2] = Util.match(addrs[2], "\\w{2}");
			//U.log(add[2]);
			add[3]= Util.match(addrs[2], "\\d{5}");
			//U.log(add[3]);
			}
		}
//		if(cUrl.contains("/beacon-park-towns-at-belmont-bay")) {
//			addSec = "551 Harbor Side Street, Woodbridge, VA 22191";
//		//	U.log(addSec);
//			add=U.getAddress(addSec);
//			
//		}
		
//		U.log(html);
//		if(addSec==null) {
//			addSec = U.getSectionValue(html, "<a href=\"https://goo.gl/maps/", "</a>");
//			U.log(U.getSectionValue(html, "<a href=\"https://goo.gl/maps/", "</a>"));
//			add=U.findAddress(addSec);
//		}'
		
		
		
		
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"	+ add[3]);
		
		String noteVar = ALLOW_BLANK;
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
		
		String geoFlag = "False";
		html =html.replace("var center=\"", "var center = \"");
		String latsec = U.getSectionValue(html, "href=\"https://maps.google.com/maps?ll=", "&");
		//U.log("latsec="+latsec);
		
		if(latsec!=null){
			latLong = latsec.split(",");
		}	
	
		//latLong[1]="-"+latLong[1];
		

		if (add[3] == null) {
			add[3] = ALLOW_BLANK;
		}

		if(latsec == null){
			latLong[0] = U.getSectionValue(html, "data-markerlat=\"", "\"");
			latLong[1] = U.getSectionValue(html, "data-markerlon=\"", "\"");
			
			}
			
//		
		if(add[0].length() < 4 || add[0] == ALLOW_BLANK && (latLong[0].length() < 4 || latLong[0]== null)){
			
			String Addes = U.getSectionValue(html, "<h1>"+commName.trim()+"</h1>", "</span>");
			//U.log(Util.matchAll(html, ">"+commName.trim()+"<span>[\\w\\s]*</span><p>",0));
			if(Addes==null)Addes = U.getSectionValue(html, ">"+commName.trim()+"<span>", "</span><p>");
			Addes  = U.getNoHtml(Addes);
			String[] add1 = Addes.split(",");
			add[1] = add1[0];
			add[2] = add1[1];
			if(!add[1].isEmpty() && add[1].length() > 1){
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				noteVar = "Address And Lat-Long Is Taken From City And State";
				geoFlag = "true";
			}
		}
		
		//========================== Lat Long
		U.log(add[0]+"::"+add[1]+"::"+add[2]+"::"+add[3]+"::"+latLong[0]);
		if (add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK && (latLong[0]==null || latLong[0].length()<4)) {
			latLong = U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			geoFlag = "True";
		}
		if((add[0].length()<4 || add[3].length() < 5)  && latLong[0].length()>4)
		{
			
			String addr[] =U.getAddressGoogleApi(latLong);
			if(addr == null) addr = U.getAddressHereApi(latLong);
			if(add[0].length() < 2 ) add[0] = addr[0];
			if(add[1].length() < 2 ) add[1] = addr[1];
			if(add[2].length() < 2 ) add[2] = addr[2];
			if(add[3].length() < 2 ) add[3] = addr[3];
			
			geoFlag ="True";
		}
		add[1]=add[1].replace("<br/>", "");
		//U.log("street::"+add[0]);
		add[0]=add[0].replaceAll("┬á|  ", "");
		add[0]=add[0].replace(" 8955", "8955");
		if(add[1].contains("Suite 202")) {
			add[1]=add[1].replace("Suite 202", "");
			add[0]= add[0]+", Suite 202";	
		}		
		//----address and lat-lng from city and state
		String cityStateSec = U.getSectionValue(info, "<span>", "</span></h4>");
		U.log("cityStateSec : "+cityStateSec);
		if(cityStateSec!=null && add[0].length()<4 && latLong[0].length()<4){
			String[] temp = cityStateSec.split(",");
			add[1] = temp[0];
			add[2] = temp[1];
			latLong=U.getlatlongGoogleApi(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			noteVar="Address And Lat-Lng Are Taken Using City And State";
		}
		
		//for addresses not showing up on page
		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/ashburn/townes-at-one-loudoun/")) {
						
			add[1] = "Ashburn";
			add[2] = "VA";
			
			//latLong=U.getlatlongGoogleApi(add);
			
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			noteVar="Address And Lat-Lng Are Taken Using City And State";
			
			U.log("ADDRESS: "+Arrays.toString(add));
			U.log("LATLONG: "+Arrays.toString(latLong));
			geoFlag ="True";
		}
		
		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/woodbridge/beacon-park-towns-at-belmont-bay/")) {
			
			add[1] = "Woodbridge";
			add[2] = "VA";
			
			//latLong=U.getlatlongGoogleApi(add);
			
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			noteVar="Address And Lat-Lng Are Taken Using City And State";
			
			U.log("ADDRESS: "+Arrays.toString(add));
			U.log("LATLONG: "+Arrays.toString(latLong));
			geoFlag ="True";
		}
		
		//-------------Plan Collection Data-------------------
		String allCollectionData = ALLOW_BLANK;
		ArrayList< String> collectionUrls = Util.matchAll(html, "<a href=\"(.*?)\"><div class=\"btn_comm btn_coll\">View Collection</div></a>", 1);
		String allData="";
		for(String collectUrl : collectionUrls ){
			U.log("collectUrl::::"+collectUrl);
			U.log(U.getCache(collectUrl));
			String collectionHtml  = U.getHtmlHeadlessFirefox(collectUrl,driver);
			allData=allData+collectionHtml;
			allCollectionData += U.getSectionValue(collectionHtml, "container-fluid collections_wrapper", "div class=\"container community\">"); 
		}


		//============ Floor Plan Section ===================
		String [] floorUrls = U.getValues(html, "<div class=\"home-info-box\">", "View Home");
		String combinedFloorHtml = ALLOW_BLANK;
		for(String floorSec : floorUrls){
			
			if(floorSec.contains("ms-home/garden-district/"))continue;
			String floorUrl=U.getSectionValue(floorSec, " href=\"", "\"");
			U.log("floorUrl::::::::"+floorUrl);
			String floorHtml = U.getHtmlHeadlessFirefox(floorUrl,driver);
			combinedFloorHtml += U.getSectionValue(floorHtml, "<div class=\"community-detail-info\">", "</div>")+U.getSectionValue(floorHtml, " <h2>Other Models Available</h2>", "View Home &amp; Floorplans</a>");
		}
		//========== Immediate Delivery Homes ============
		
		String immediateHomeSec = null;
		String immediateHomeHtml = U.getHTML("https://www.millerandsmith.com/immediate-delivery-homes");
		String immediateHomeSection[] = U.getValues(immediateHomeHtml, "<div class=\"immediate-delivery-info\">", "</a>");
		U.log("immediate Home count ::"+immediateHomeSection.length);
		for(String sec : immediateHomeSection){
			String title = U.getSectionValue(sec, "delivery-title\">", "</div>");
			U.log(title);
			if(title != null && title.contains(commName.trim())){
				immediateHomeSec += sec;
			}
		}

		html=html.replace("0s", "0,000");
		info = info.replace("0s", "0,000").replace("0’s", "0,000");

		
		String drop2=U.getSectionValue(html, "Find Your New Home</span>","About Us</span>");
		if(drop2!=null)html=html.replace(drop2, "");
		//U.log("drop2::"+U.getSectionValue(html, " rooftop pied-à-terre sits ato", "</p></div>"));
		//U.log(info);
//		U.log(immediateHomeSec);
		//========== Price ===============
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String rem = U.getSectionValue(html, "<header class=\"d-flex align-items-center justify-content-between\">", "<script type=\"text/javascript\">");
		if(rem!= null) html = html.replace(rem, "");
		html =html.replaceAll("0's|0S|0s", "0,000").replace("mid-$800’s", "mid-$800,000").replace("from the mid $600,000, will have breathtaking views", "");
		info = info.replace("<p>Upper West Next Level Homes From $874,990<br>West Village Townhomes From $619,990</p><p>New! Uptown Row Townhomes from $709,990</p></a><p><a href=\"/?page_id=3831\"></a></p>", "");

		String moSec[]=U.getValues(html, "home-info-box", "cta-btn-link");
		String moData="";
		for(String m:moSec) {
			if(m.contains("price-14859") || m.contains("price-14857"))m=m.replaceAll("\\$\\d{3},\\d{3}", "");
			moData+=m;
		}

		String[] price = U.getPrices((info+combinedFloorHtml+allCollectionData+immediateHomeSec+moData)
				.replace("price-14857\"> From <strong> $809,990 </strong></p>", ""), //check next 
				
				"From <strong> \\$\\d,\\d{3},\\d{3}|<strong> \\$\\d{3},\\d{3} </strong>|From <strong>\\$\\d{3},\\d{3}</strong>|low \\$\\d{3},\\d{3}|<strong> \\$\\d{3},\\d{3} </strong>|the Upper \\$\\d{3},\\d{3}|mid-\\$\\d+,\\d+|</p> from \\$\\d{3},\\d{3}|From <span>\\$\\d+,\\d+|From \\$\\d+,\\d+|BIG! \\$\\d+,\\d+|mid \\$\\d+,\\d+|model_price\">\\$\\d+,\\d+|Sq. Ft.\\s*<strong>\\s*\\$\\d{3},\\d{3}</strong>", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//		U.log("KKKKKKKKKKKK"+Util.matchAll(info+combinedFloorHtml+allCollectionData, "[\\s\\w\\W]{30}\\$1,039,990[\\s\\w\\W]{30}", 0));
//		U.log("KKKKKKKKKKKK"+Util.matchAll(immediateHomeSec+moData, "[\\s\\w\\W]{30}\\$1,039,990[\\s\\w\\W]{30}", 0));

		//============= Square Feet =================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
	//	U.log("KKKKKKKKKKKK"+Util.matchAll(moData+combinedFloorHtml+allData+allCollectionData+immediateHomeSec, "[\\s\\w\\W]{30}3,000[\\s\\w\\W]{30}", 0));
		html = html.replaceAll("html\\(\"Nearly \\d{4} sq ft\"", "").replace(".html(\"Nearly 2,200 sq. ft.\");", "");
	//	immediateHomeSec=immediateHomeSec.replace("square footage is just under 3,000!", "");
		
		String[] sqft = U.getSqareFeet((moData+combinedFloorHtml+allData+allCollectionData+immediateHomeSec).replace("just under 3,000!", "").replace("html(\"Nearly 2,200 sq. ft.", "").replaceAll("square footage is just under 3,000!|Up to 2,162 sq. ft", ""),
				"Up to \\d{1},\\d{3} sq. ft|Nearly \\d{4} Sq Ft|\\d,\\d{3} to \\d,\\d{3} square feet|Up to \\d{4} sq ft|Up to \\d+,\\d+\\s+sq. ft|\\d{4} sq. ft|\\d,\\d+ square feet|Nearly \\d,\\d{3} Sq. Ft.|Garage,  \\d{4} Sq. Ft.", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
	
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		//=========== Property  Type ==============
		
		html = html.replace("5443secondopt.gif\" title=\">", "");
		html = html.replace(" luxurious interior finishes", " luxury homes interior finishes");
		String drop11 = U.getSectionValue(html, "class=\"widget-title\">SideBar Contact Form", "class=\"site-main\" role=\"main");
		if(drop11!=null)html = html.replace(drop11, "");
		String drop111 = U.getSectionValue(html, "gfield field_sublabel_below field_description_below", "class=\"site-main\" role=\"main");
		
		if(drop111!=null)html = html.replace(drop111, "");
		//U.log(html);
		
		
		//-------property sec---------
		String propSec = U.getSectionValue(html, "<h1 class=\"entry-title\">", "<h2>Area Amenities</h2>");
		if(propSec!=null){
			propSec =propSec.replaceAll("alt=\"Downtown Collection Townhomes |studio apartments|alt=\"Exteriors of Townhouses|traditional golf game", "");
			propSec = propSec.replace("luxury of having", "luxury home of having");
			
		}
		combinedFloorHtml = combinedFloorHtml.replace(" loft with", " loft home with")
				.replaceAll("traditional approach", "");
		//U.log(propSec);

		if(artical==null) artical = "";
		artical = artical.replaceAll("luxury and ease of new construction homes", "luxury homes");
		String commDetail = U.getSectionValue(html, "<div class=\"community-detail-info\">", "</div>");
		
		if(commDetail!=null)
			commDetail = commDetail.replace("luxury of having a variety of conveniences", "luxury homes of having a variety of conveniences");
		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-maryland/ellicott-city/patapsco-crossing/")) {
			commDetail = U.getSectionValue(html, "<div class=\"community-detail-info\">", "</a></p>");
		}
		String propType = U.getPropType((artical+propSec+info+ss+combinedFloorHtml+commDetail+statusSec)
				.replace("elevator townhomes", "stunning Town Home design")
				.replace("And the options for flex spaces", "And the options for Flex space")
				.replace("single level living in a luxury 3-level townhome", "single level living in a luxury living 3-level townhome")
				.replaceAll("\">Single Family Homes|New Townhomes Coming Soon|-Patio-1|patio – community|patio-2|custom designed kitchen|text-center patio – community\"|patio-1|condominiums will be located|content=\"(.*?)\"\\s*/> ", ""));
 //		U.log("CACHE::::::::::::" + U.getCache(cUrl));

//			U.log("KKKKKKKKKKKK"+Util.matchAll(artical+propSec+info+ss+combinedFloorHtml+commDetail+statusSec, "[\\s\\w\\W]{30}luxury[\\s\\w\\W]{30}", 0));

		propType=propType.replace("Townhouse,Townhome", "Townhome").replaceAll("Townhouse,", "");
		U.log("PROPERTY TYPE::::::::::::" + propType);
		
		//========= Community Type ==============
		String removeSec = U.getSectionValue(html, "<div class=\"mpfy-p-loading\">", "</body>");
		if(removeSec!=null)
		html=html.replace(removeSec,"");
		html=html.replace(" 55+ Elevator Townhomes", " seniors 55 and over");
		html=html.replaceAll("Modern Lake Living with open plans with walls|life! 55\\+ Active Adult elevator townhomes|Birchwood Active Adult|up a round of golf", "");
	
		String desc=U.getSectionValue(html, "community-detail-info-wrap", "amenities-detail");
		String commType = U.getCommunityType(desc+info);
//		U.log("MMMMMMMMMcommType "+Util.matchAll(info, "[\\w\\s\\W]{100}PRE-MODEL PRICING[\\w\\s\\W]{100}", 0));

//		if(cUrl.contains("ashburn/townes-at-one-loudoun"))commType="Resort Style";
		U.log("commType::"+commType);

		//=========== Property Status ==================
		String propStatus = ALLOW_BLANK;
		U.log("<a href=\""+cUrl+"\" data-ps2id-api=\"true\">");

		//String statSec = U.getHtmlHeadlessFirefox(cUrl,driver);
		String statSec = html.replace("Sold Out in 3", "").replace("Immediate Delivery Home is Available", "Immediate Delivery Home Available");
		
		String remove = "\">Coming Soon</p></div></div>|<p>Now Selling From|</h4><p>Coming Soon|NEW! Now Selling From |<br/> Now Selling - Townhomes|Models Now Open|Now Open|tour_union station – sold out|&#8211; SOLD OUT</a></p>|&#8211; SOLD OUT_3D|Coming in 2017 to Stafford|Coming in 2017 to Manassas|More information coming soon|models now open|Models Now Open|COMING SOON</p></a></div>|Coming Soon<|Sold Out<|SOLD OUT</a></p>|Not available on|Single Family Homes - COMING SOON</p><|<p>Townhomes - SOLD OUT</p><|Townhomes - SOLD OUT<br/>|<p>Single Family Homes - SOLD OUT</|SOLD-OUT.jpg\"|out\">Sold Out</p></div>|-<p><strong>SOLD OUT</strong>";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		html=html.replace(remove, "");
		
		html = U.removeComments(html);
		
		info=info.replaceAll("family homes now selling|townhomes now selling|Single Family Homes coming soon|Townhomes Coming Soon!</p>|Townhomes Now Selling", "");
		if(statusSec!=null)
		statusSec=statusSec.replaceAll("family homes now selling|townhomes now selling|Single Family Homes coming soon|Townhomes Coming Soon!</p>", "");
		
		//		U.writeMyText(html);
		
		
		
//		U.log(Util.match(html.replaceAll("\"description\":\"Coming Soon!|content=\"Coming Soon! Be|;\">Coming Soon</p></div></div>|<p class=\"sld-out\">Sold Out</p>|4><p>Coming Soon!</p>|NEW! Now Selling From |model_link help\">Coming|SOLD OUT</a>|<p>Now Selling From|COMING SOON: Introducing healthy|coming soon:|Now Open|now open|sold out|sold_out|>\\s*SOLD OUT\\s*<|NewDominion_Soldout|New Dominion Collection – SOLD OUT|>The New Dominion Collection is now SOLD OUT Embrey Mill|SOLD OUT(</p>|</br>)",""), ".*Coming Soon.*"));
		propStatus = U.getPropStatus((info+statusSec).replace("NEW! Townhomes Now Selling", "New Townhomes Now Selling")
				.replaceAll("homes Now Selling|Homes Now Selling|Single-Family Homes. Now Selling|\"description\":\"Coming Soon!|content=\"Coming Soon! Be|Coming Soon-->|italic;\">Coming Soon</p>|;\">Coming Soon</p></div></div>|<p class=\"sld-out\">Sold Out</p>|4><p>Coming Soon!</p>|NEW! Now Selling From |model_link help\">Coming|SOLD OUT</a>|<p>Now Selling From|COMING SOON: Introducing healthy|coming soon:|Now Open|now open|sold out|sold_out|NewDominion_Soldout|New Dominion Collection – SOLD OUT|>The New Dominion Collection is now SOLD OUT Embrey Mill|SOLD OUT(</p>|</br>)|-<p><strong>SOLD OUT</strong>|SOLD-OUT.jpg|Townhomes Coming Soon</p>",""));
		
		U.log("propStatus==="+propStatus);

		propStatus = propStatus.replace("Only 1 Single Family Home Left","Only 1 Home Left");
//		ArrayList<String> immcount=Util.matchAll(html, "<i class=\"fa fa-star\"", 0);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(info+statusSec, "[\\s\\w\\W]{30}Now Selling[\\s\\w\\W]{30}", 0));
//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/ps.txt", info+statusSec);
		
//		U.log(immcount.size());
		/*if(immcount.size()>=2 ||(immcount.size()>=1 && !U.getSectionValue(html,"Indicates an Immediate Delivery Home is Available","<h2>Gallery</h2>").contains("Check back soon for details on our new home models"))) {
			
			if(propStatus==ALLOW_BLANK){
				propStatus="Immediate Delivery Home Available";
			}
			else{
				propStatus=propStatus+", Immediate Delivery Home Available";
			}
		}*/
//		String imm = U.getSectionValue(html, "Indicates an Immediate Delivery Home is Available ", "<h2>Gallery</h2>");
//		
//		if(imm.contains("<a href=\"../../../immediate-delivery-homes")) {
//			
//			if(propStatus==ALLOW_BLANK){
//				propStatus="Immediate Delivery Home";
//			}
//			else{
//				propStatus=propStatus+", Immediate Delivery Home";
//			}
//		}
		
		//if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/ashburn/one-loudoun/upper-west-at-one-loudoun")) propStatus="Immediate Delivery Home Available";
		//U.log("result::"+Util.match(info, ".*?now open.*?"));
		//============ Derived Community Type ==============
		
		html = html.replace("1 and 2-story", "1 Story, 2 Story");

		String dproptype = U.getdCommType((html+combinedFloorHtml).replace("3-levels", "3 Story").replaceAll("content=\"(.*?)\"", "").replace("the first floor with", "1 Story"));
		commName=commName.replace(" Townhomes", "").replace("– Coming Soon!", "");
		propType = propType.replace("Townhouse,Villas,Townhomes", "Villas,Townhomes");
		propStatus = propStatus.replace("Immediate Delivery Available", "Immediate Delivery Homes");
		// Add ALL
		if(noteVar == ALLOW_BLANK) noteVar = U.getnote(info);
		if(cUrl.contains("/columbia/eden-brook"))propType ="Townhome";
		if(cUrl.contains("g/tapestry-coming-soon"))propType ="Single Family";

		// Coming from Region Image
		if(cUrl.contains("https://www.millerandsmith.com/community/eden-brook/"))			
			propStatus = "Coming Soon";
		if(cUrl.contains("manassas/signal-hill-crossing/"))minSqf="2200";
		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/ashburn/brambleton/")) {
			add[2]="VA";
		add[3]="20147";
		}
//	if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/woodbridge/beacon-park-towns-at-belmont-bay"))
//			propStatus="Now Selling";
		
		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/ashburn/brambleton")) {
			add[0]="State Rte 641";
		add[1]="Ashburn";
		}
/*		if(cUrl.contains("columbia/eden-brook")) {
			minSqf=maxSqf;
			maxSqf=ALLOW_BLANK;
		}*/
		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/manassas/cayden-ridge")||cUrl.contains("/signal-hill-crossing/"))add[3]="20110";
		
	if(cUrl.contains("ashburn/townes-at-one-loudoun/"))propStatus=propStatus.replace("Now Selling, Sold Out", "Sold Out");
	if(cUrl.contains("cascades-at-embrey-mill/"))commType="55+ Community, Active Adult";
/*		if(cUrl.contains("https://www.millerandsmith.com/new-homes-for-sale-virginia/woodbridge/beacon-park-towns-at-belmont-bay"))
		              commType += ", Waterfront Community";
*/		
		data.addCommunity(commName, cUrl, commType);
		data.addAddress(add[0].trim(), add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLong[0], latLong[1], geoFlag);
		data.addPropertyType(propType, dproptype);
		data.addPropertyStatus(propStatus.replace("New Townhomes Now Selling", "Townhomes Now Selling"));
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(noteVar);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);

	}j++;
	
//		}catch (Exception e) {}
	}

}