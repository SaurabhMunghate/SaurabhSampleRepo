/** @author Sanket Patil
 *  @date 14/04/2012 
 */

package com.shatam.b_121_140;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class ExtractOleSouthProperties extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int duplicates = 0;
	static int j=0;
	WebDriver driver = null; 
	CommunityLogger LOGGER;
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractOleSouthProperties();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ole South Properties.csv", a.data()
				.printAll());
		U.log(duplicates);
	}

	public ExtractOleSouthProperties() throws Exception {

		super("Ole South Properties", "https://www.olesouth.com/");
		LOGGER=new CommunityLogger("Ole South Properties");
	}

	public void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
		String html = U.getHtml("https://www.olesouth.com/communities", driver);
		

		String[] values = U.getValues(html, "<div class=\"card CommunityCard\"",
				"</li></ul></div></a></div>");
		U.log(values.length);
		
		for (String item : values) {
			//U.log(item);
			// item = U.getSectionValue(item, "Community: </strong><a href=",
			// "/a>");
			String link = U.getSectionValue(item, "href=\"", "\"");
			
			// if (item.matches(".+?olesouth.com/.+")){
			// if(i<2)
			U.log(link);
			
			if (this.data.communityUrlExists(link)) {
				duplicates++;
				continue;
			}
			// if(inr==0||inr==totalComm||inr==totalComm+1||inr==values.length-1)
//			try {
				addDetails("https://www.olesouth.com" + link, item);
//			} catch (Exception e) {}
			inr++;
			i++;
			// break;
			// }

		}
		//driver.close();
		// addDetails("http://olesouth.com/rivendell-woods","fd>fdfdf<fd");
		LOGGER.DisposeLogger();
//		try{driver.quit();}catch(Exception e) {}
	}

	private void addDetails(String url, String info) throws Exception {
		if (data.communityUrlExists(url)
				|| url.contains("http://olesouth.com/special.php")
				|| url.contains("http://www.nealcommunities.com/welcome-to-miramar.html")
				|| url.contains("https://www.olesouth.com/communities/murfreesboro/shelton-crossing")
				|| url.contains("https://www.olesouth.com/communities/murfreesboro/villas-at-evergreen"))	
			return;
		{
//TODO:		
		//====== Single Run =================================
//		if (!url.contains("https://www.olesouth.com/communities/murfreesboro/south-haven"))return;
	
			//	U.log(U.getCache("https://www.olesouth.com/communities/spring-hill/derryberry-estates"));
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"------>Repeated");
			return;
		}
			
			
/*			if(url.contains("https://www.olesouth.com/communities/fairview/sweetbriar-springs") || url.contains("https://www.olesouth.com/communities/smyrna/the-meadows")){
				LOGGER.AddCommunityUrl(url+"------>Return");
				return;
			}
			*/
			LOGGER.AddCommunityUrl(url);
			
			U.log("\nPAGE :" + url);
		String html = U.getHTML(url);
		html=U.removeSectionValue(html, "<script>window.__PRELOADED_STATE__ = ", "</html");
		
		
		// Community Name
		String commName = U.getSectionValue(html, "<h1 data-reactid=\"120\">", "</h1>");
		if(commName == null)commName = U.getSectionValue(html, "<h1 data", "</h1>");
		if(commName != null)
			commName = commName.replace(" - Townhomes", "").replaceAll("-reactid=\"\\d+\">", "");
		//U.log(info);
//		U.log(html);
		
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, "TN",
				ALLOW_BLANK };

		// LatLong
		String geo = "FALSE";
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String latsec =U.getSectionValue(html, "Driving Directions</h4><", "Map This Community<");
		String latstring = U.getSectionValue(latsec,
				"<a href=\"https://www.google.com/maps/place/", "/@");
		U.log(latstring);
		if (latstring != null) {
//			latstring = latstring.replaceAll("\\+", ",");
			 U.log("-----------"+latstring);
			String[] latlngs = latstring.split(",");
			lat = latlngs[0].trim();
			lng = latlngs[1].trim();
			

		}

		if (add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
			String[] latLong = U.getGooleLatLong(add);
			if(latLong == null) latLong = U.getlatlongHereApi(add);
			
			lat = (latLong[0] != null) ? latLong[0] : ALLOW_BLANK;
			lng = (latLong[1] != null) ? latLong[1] : ALLOW_BLANK;
			if (lat != ALLOW_BLANK)
				geo = "TRUE";
		}
		if (add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) {
			add = U.getAddressGoogleApi(new String[]{lat,lng});
			if(add == null) add = U.getGoogleAddressWithKey(new String[]{lat,lng});
			geo = "TRUE";
		}
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"
				+ add[3]);
		// Square Feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String sec = U.getSectionValue(html, "<div class=\"comm_nav_list\">",
				"</ul>");
//		U.log(sec);


		String combineHtml = getCombineHtml(url);
		if(combineHtml!=null) {
			combineHtml=combineHtml.replaceAll("</strong><br data-reactid=\"\\d{3}\"/><!-- react-text: \\d{3} -->SQFT", " SQFT");
		}
		html=html.replaceAll("</strong><br data-reactid=\"\\d{3}\"/><!-- react-text: \\d{3} -->SQFT", " SQFT");
//		U.log(Util.matchAll(combineHtml, "\\d,\\d{3} SQFT", 0));
		
		info = info.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").trim();
		//U.log("iiiiiiiiiiii"+info);
		String[] sqft = U
				.getSqareFeet(
						 html + combineHtml+info ,"\\d,\\d{3}-\\d,\\d{3} SQ FT|\\d,\\d{3} SQFT",
//						"SQ FT:</span>  \\d+,\\d+|SQ FT Range:</span> \\d+,\\d+ - \\d+,\\d+|\\d+ sq.|Square Ft:\\s+</strong>\\s+\\d{4}|SQ FT:</span>  \\d+ </h5>",
						0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// Price
		// U.log(html);
		// Price:</span> &#36;401,990<br />
		// 0's
		combineHtml = combineHtml.replace(" &#36;", "$");
		html = html.replaceAll("0's", "0,000MyPrice").replace(" &#36;", "$");
		html=html.replace("from the mid 100", "from the mid $100");
		html = html.replaceAll("'s", ",000MyPrice");
		//FileUtil.writeAllText("D://sample.txt", html);

	//	U.log(areaHtm);
		String[] price = U
				.getPrices(
						 html+combineHtml,"\\$\\d{3},\\d{3}<!--|\\$\\d{3},\\d{3}</span>",
//						"Price:</span> \\$\\d+,\\d+|\\$\\d{3},\\d{3}MyPrice|listingtitle\">\\s*<b>\\s*\\$?\\d+,\\d+|From the \\$\\d+,\\d+|Base Price:</span> \\$\\d+,\\d+<br />|\\$ \\d+,\\d+|align=\"center\" valign=\"top\">\\s*\\d+,\\d+|\">\\s+\\$\\d+,\\d+\\s+</h5>|<span>Price:</span>\\s*&#36;\\d{3},\\d+\\s*<br />",
						0);
		String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
//		U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(combineHtml, "[\\w\\s\\W]{20}\\$485,227[\\w\\s\\W]{10}", 0));

		if (minPrice == ALLOW_BLANK) {
			html = html.replaceAll("0's", "0,000s");
			price = U.getPrices(html, "\\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		}
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		
		// Community Type
		String commType = U.getCommunityType(html+info);
		U.log("commType :" + commType);

		// Property Type
		String fetur=U.getHTML(url+"-features");
		
		if(fetur != null) fetur = U.removeSectionValue(fetur, "<head>", "</head>");
//		String floor1=U.getHTML(url+"-floorplans");
		//U.log("hhhh"+html+"hhhh"+fetur);
		//U.log(availableHtml);
		String seca=U.getSectionValue(html, "Neighborhood Type:", "</em>");
		if (url.contains("http://olesouth.com/western-woods")){
			html=html.replaceAll("Cottage|cottage", "");
			fetur=fetur.replaceAll("Cottage|cottage", "");
			combineHtml=combineHtml.replaceAll("Cottage|cottage", "");
		}
	
		combineHtml = combineHtml.replaceAll("\\d+ - Cottage|\\d+-Cottage|(C|c)ottage(_|\\s|%20)(B|b)rochure", "");
		
		combineHtml=combineHtml.replace("Townhouse", "");
		if(fetur != null)
			fetur=U.removeSectionValue(fetur, "<script>window.__PRELOADED_STATE__ = ", "</html");

		//+fetur
		html = html.replaceAll("craftsman style town homes", "craftsman style homes town homes");
		String propType = U.getPropType((html+fetur).replaceAll("Duplex Road|The Villas at Cantrell Farms and Lee Crossing|ef30c11896d8ecf776c/Cottage%20Feature|href=\"\"", "") //|src=\".*\"
				+combineHtml.replaceAll("elevations in the Craftsman tradition|The Villas at Cantrell Farms and Lee Crossing|ef30c11896d8ecf776c/Cottage%20Feature|<a href=.*pdf", ""));
		
		U.log("prop Type:::::: :" + propType);
		
		///////////////////D-property type////////////////////////////
		
		html=html.replaceAll("Stories: <!-- /react-text --><strong data-reactid=\"\\d{3}\">2</strong></div>", "2 Story").replaceAll("Stories: <!-- /react-text --><strong data-reactid=\"\\d+\">", "story ")
					.replace("story 1.5", "1.5 story");
		combineHtml=combineHtml.replace("<span>Stories:</span>", "story");
		
//		U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(combineHtml, "[\\w\\s\\W]{20}One level[\\w\\s\\W]{50}", 0));
		
		String dtype=U.getdCommType((html.replaceAll("one and two-story","1 story 2 story") + combineHtml).replaceAll("level plan|>Branch|Popular ranch floor|\\d Bed|3 Bed 3 Full|4 Bedroom|floor|Floor|2.5 Bath,", ""));
		U.log("dprop Type:::::: :" + dtype);
		
		
		
		

		if (add[0] == ALLOW_BLANK)
			add[0] = getStreetAddress(commName);

		if (url.contains("https://www.olesouth.com/villas_at_rivendell_woods.php")) {
			minPrice = "$110,000";
		}

		String status = ALLOW_BLANK;
		String statSec = html;
		statSec = statSec.replaceAll(
				"Quick Move-In Homes</a>|Quick Move-in Homes", "")
				.replace("more homes coming in winter of 2021", "coming winter 2021")
				.replace("coming in late 2021", "coming late 2021");
		statSec = statSec.replace(
				"100% financing is available with USDA Financing",
				"100% Financing Available!  and USDA LOAN QUALIFIED");
		String remove = "location coming|will have more home sites available|Quick Move-In Homes</a>|MODEL HOME OPENING SPRING 2018|homes already under construction|\\? Coming Soon|COMING SOON</b></td>|class=\"listingtitle\">\\s*<b>\\s*COMING SOON|Hall</b> &#150; Coming Soon|Shopping</b> &#150; Coming Soon|center opening soon|class=\"listingtitle\"><b>COMING SOON|More are coming soon|\\s*Estates on Port Royal Road,\\s*opening Spring 2018|Model home opening late";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
		statSec = U.removeComments(statSec);
		statSec = statSec.replaceAll("quick move-in homes\\W+<", "");//.replace("new phase of home sites now open", "New phase now open");
		statSec = statSec.replaceAll("available homes \\(<!----><!---->", "available homes ").replace("Villa", "Villas").replace("home sites will be available in the summer of 2017","home sites are available in the summer of 2017");
		
		String homesStstus = Util.match(statSec, "available homes \\d+<");
		if(homesStstus !=null) { 
		String no = U.getSectionValue(homesStstus, "homes", "<");
		statSec = statSec.replace(homesStstus, no+" available homes");
		}
		
		statSec = statSec.replaceAll("new phase of home sites will be opening soon", "new phase of home sites opening soon")
				.replace("home sites available later in the fall of 2021", "homesites available later Fall 2021")
				.replace("new section of home sites now open", "new section now open");
		
//		U.log("------------------->>>>>mmmmmm"+Util.matchAll(html+statSec+info, "[\\w\\s\\W]{300}New section[\\w\\s\\W]{30}", 0));
		
		status = U.getPropStatus((statSec+info)
//				.replace("New section of home sites now open", "New section now open")
				.replace("new phase opening for", "").replace("home sites coming soon", "homesites coming soon").replace("opening Spring 2021", "Opening Spring 2021").replace("but we have more home sites coming soon in nearby Brandon Woods", "").replaceAll("new phase now under construction|hope to have more home sites|homes coming|>Quick Move-In Homes<|Model Home Opening February 2019", ""));
		
		status = status.replaceAll("Quick Move-in Homes,|Quick Move-in Homes","");
		if (status.length() < 2) {
			status = ALLOW_BLANK;
		}
	
		U.log(Util.matchAll(statSec+info, "[\\w\\s\\W]{50}Now Open[\\w\\s\\W]{10}", 0));
		String availHtml=ALLOW_BLANK;
		
		U.log("Awesome:: "+status.length());
		//U.log(availHtml);
		//Quick Move in status is consider when home are present is available home tab
				if(html.contains("Quick Move-In Homes</h3>")){
					U.log("Byee");
					if(status.length()<4){
						status= "Quick Move-In Homes";
					}
					else{
						status=status+", Quick Move-In Homes";
					}
				}
					
				
		
		U.log("Status::::::: "+status);
		
		
		U.log("========" + minPrice);
		commName=commName.replace("-", "");
	
		if (url.contains("https://www.olesouth.com/communities/smyrna/lee-crossing")) {
			add[0]="1002 Harold Lee Dr";
			add[1]="Smyrna";
			add[2]="TN";
			add[3]="37167";
		}
		// Add al
		
		if(propType.contains("Townhome") && propType.contains("Townhouse"))
			propType = propType.replaceAll(", Townhouse", "");
		
		if(url.contains("https://www.olesouth.com/communities/spring-hill/derryberry-estates"))
			status=status.replace("More Home Sites Coming Soon,", "");
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(commName, url, commType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(propType,dtype);
		data.addPropertyStatus(status);
		data.addNotes(ALLOW_BLANK);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);

	}j++;
	}

	private String getCombineHtml(String link) throws IOException {

		String html = U.getHTML(link);
		String combineHtml = ALLOW_BLANK;
		if(html.contains("<div class=\"HomeCard\""))
		{
		String getHosue[] = U.getValues(html, "<div class=\"HomeCard\"",
				"View Detail");
		
		for (String house : getHosue) {
			house = U.getSectionValue(house, "<a class=\"\" href=\"", "\"");
//
			house = "https://www.olesouth.com" + house;

			U.log("Getting: " + house);
			String quickhtm= U.getHTML(house);
			quickhtm = U.removeSectionValue(quickhtm, "<script>window.__PRELOADED_STATE__ = ", "</html");
			combineHtml += quickhtm+house;
		}
		}
		if(html.contains("<div class=\"PlanCard\"")) {
			String getHosue1[] = U.getValues(html, "<div class=\"PlanCard\"",
					"</div></li></ul></div></div>");
			
			for (String house : getHosue1) {
				house = U.getSectionValue(house, "<a class=\"\" href=\"", "\"");
				house = "https://www.olesouth.com" + house;

				U.log("Getting: " + house);
				String planhtm= U.getHTML(house);
				String rem = U.getSectionValue(planhtm, "<script>window.__PRELOADED_STATE__ =", "</html");
				if(rem==null)rem = "";
				planhtm = planhtm.replace(rem, "");
				combineHtml += planhtm+house;
			}
		}

		return combineHtml;

	}

	public static String getStreetAddress(String name) {
		String add = ALLOW_BLANK;
		if (name.contains("Lee Crossing"))
			add = "I-24 East to exit 70 Almaville Rd";
		if (name.contains("Belmont"))
			add = "Take I-24 East, Exit #70, turn right on Almaville Rd";
		if (name.contains("Benevento East"))
			add = "I-65 South, Exit Hwy 840 West. Exit Hwy 31 South";
		if (name.contains("Villas At,Meadowbrook"))
			add = "I-65 South, Exit Saturn Parkway Hwy 396, Exit Port Royal Road";
		if (name.contains("Old Hickory,Commons"))
			add = "I-24 East to Old Hickory blvd. (exit 62)";
		if (name.contains("Rivendell Woods"))
			add = "Interstate 24 East, Exit #59 Bell Road";
		if (name.contains("Villas at,Rivendell Woods"))
			add = "Interstate 24 East, Exit #59 Bell Road";
		if (name.contains("Arbors At Autumn Ridge"))
			add = "TN-840 West, Exit Hwy 31 - Thompsons Station, Spring Hill.";
		if (name.contains("Liberty Valley"))
			add = "From Downtown Murfreesboro, Follow Hwy 231 North/Memorial Blvd";
		if (name.contains("Garrison Cove"))
			add = "I-24, Exit 78-B Old Fort Pkwy";
		if (name.contains("Fairway Farms in Gallatin"))
			add = "I-65 to Vietnam Veterans Blvd. (TN-386) ";
		if (name.contains("Pinnacle Hills"))
			add = " I-24, take Salem Hwy (Highway 99) west to LEFT on Armstrong Valley";
		if (name.contains("Seward Crossing"))
			add = "I-24 Exit 76, Medical Center Parkway.South on Medical Center Parkway to RIGHT on Manson Pike";
		if (name.contains("Royalton Woods"))
			add = "I-65 South, Exit Saturn Parkway Hwy 396, Exit Port Royal Road";
		if (name.contains("Apple Valley"))
			add = "Downtown Nashville: I-24 East, Exit 62 Old Hickory Blvd. Right on Old Hickory Blvd";
		if (name.contains("Waldron Farms"))
			add = "From I-24, Exit 231 South, RIGHT on Stones River Road across from Christiana Schools";
		if (name.contains("Cobblestone"))
			add = "I-65 South, Exit Saturn Parkway (Hwy 396) West";
		if (name.contains("Albion Downs in Gallatin"))
			add = "Vietnam Veterans Parkway to south on Hwy 109 By-Pass";
		if (name.contains("Port Royal Estates"))
			add = "65 South to Exit 53 Saturn Parkway";
		if (name.contains("Blackman Meadows"))
			add = "From I-24 and Medical Center Parkway (Exit 76)";
		if (name.contains("Salem Glen Crossing"))
			add = "I-24 to Exit 78A. Hwy 96 W (Old Fort Pkwy), West on Highway 96";
		if (name.contains("Golf View Estates"))
			add = "I-65 South, Exit Saturn Parkway Hwy 396";
		if (name.contains("Puckett Station"))
			add = "I-24 to exit 76, (South) on Medical Center Pkwy/Manson Pike";

		return add;
	}

}