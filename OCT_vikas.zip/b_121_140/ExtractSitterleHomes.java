package com.shatam.b_121_140;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.javascript.host.Console;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;

public class ExtractSitterleHomes extends AbstractScrapper {

	CommunityLogger LOGGER;
	int j = 0;
	HashMap<String, String> regLatlngList = new HashMap();

	public ExtractSitterleHomes() throws Exception {
		super("Sitterle Homes", "https://www.sitterlehomes.com/");
		LOGGER = new CommunityLogger("Sitterle Homes");
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSitterleHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Sitterle Homes.csv", a.data().printAll());
	}

	ArrayList<String> communityUrl = new ArrayList<>();
	WebDriver driver=null;
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpChromePath();																																																													
//		driver=new ChromeDriver();

		String mainHtml = U.getHTML("https://www.sitterlehomes.com/");
		// U.log("html:-->"+mainHtml);
		String[] comSec = U.getValues(mainHtml, ">Find Your Home</a>", "</ul>");
		for (String val : comSec) {
			String[] regUrl = U.getValues(val, "<a href=\"", "\"");
			for (String url: regUrl) {
				if(!url.startsWith("http"))
					url="https://www.sitterlehomes.com"+url;
				String regHtml = U.getHTML(url);
//				System.out.println("RegionUrl ::" + url);
				
				String completeLatSec=U.getSectionValue(regHtml, "const idMap = ", "</script></div>");	
				
//				String comsec= U.getSectionValue(regHtml, "{\"objects\":[", "}]}}");
//				String communities[]= U.getValues(regHtml.replaceAll("Learn More|Join Interest List", "View Community"), "{\"id\":\"", "View Community");
////				U.log(">>>>>>>"+communities.length);
//				String communities[]= U.getValues(regHtml.replaceAll("Learn More|Join Interest List", "View Community"), "<a class=\"result--title\"", "View Community");
				String communities[]= U.getValues(regHtml, "<div class=\"single-result-container", "</div></div></div></div>");

				
//				U.log(">>>>>>>reg comm length=="+communities.length);
				
				for(String community:communities) {
					community = StringEscapeUtils.unescapeJava(community);
//					U.log(">>>>>>>>>>>>>"+community);
					String comurl = "https://sitterlehomes.com"+U.getSectionValue(community, "href=\"", "\"");
//					String comurl = U.getSectionValue(community, "href=\"", "\"");

//					U.log("******"+comurl);
					if(comurl.contains("communities-san-antonio/prospect-creek-at-kinder-ranch-55s-65s-80s/")) {
						String comHtm = U.getHTML(comurl);
						String subComm[] = U.getValues(comHtm, "<div class=\"et_pb_button_wrapper\"><a class=\"et_pb_button et_pb_promo_button\" href=\"", "\"");
						for(String subUrl:subComm) {
							
							if(!subUrl.startsWith("http"))subUrl = "https://sitterlehomes.com/communities" + subUrl;
//							U.log("######"+subUrl);
						   String comHtml=U.getHTML(subUrl);
							
//							try {
							addDetails(subUrl,community,completeLatSec);
//							} catch (Exception e) {}
						}
					}
					else if(comurl.contains("https://sitterlehomes.com/communities-san-antonio/miralomas")) {
						String html=U.getHtml("https://sitterlehomes.com/communities-san-antonio/miralomas",driver);
						
					//	String section=U.getSectionValue(html, "et_pb_row et_pb_row_1 et_pb_equal_columns et_pb_gutters1 et_pb_row_4col", "et-l et-l--footer");
					//	String section=U.getSectionValue(html,"<div class=\"et_pb_module et_pb_cta_0 et_pb_promo  et_pb_text_align_center et_pb_bg_layout_dark\">","");
						//	U.log(section);
					//	String sec[]=U.getValues(section, "et_pb_css_mix_blend_mode_passthrough", "View");
						String sec[]=U.getValues(html,"<div class=\"et_pb_promo_description\">","View</a>");
//						U.log("2nd sub Comm lenght="+sec.length);
						for(String s:sec) {
//							U.log(s);
							String subUrl=U.getSectionValue(s, "href=\"", "\"");
							
//							U.log("subUrl###=="+subUrl);
							
							if(!subUrl.startsWith("http"))subUrl = "https://sitterlehomes.com/communities" + subUrl;
							String comHtml=U.getHTML(subUrl);
//							try {
			                	addDetails(subUrl, s, completeLatSec); //			dd	
//							} catch (Exception e) {}
							
							
						}
					}
					else {	
//						U.log("comurl=="+comurl);
						String comHtml=U.getHTML(comurl);
//						try {
							addDetails(comurl,community, completeLatSec); //dd
							
//						} catch (Exception e) {}
					}
				}
			}

		} // end of comval
//		try{
//			driver.quit();
//			}catch (Exception e) {}

		U.log("total Community:--->" + communityUrl.size());
		LOGGER.DisposeLogger();
	}
	
	//TODO ::
	private void addDetails(String comUrl,String oldData, String latlngSec) throws Exception {
//		if(j >= 25)
//		try{
		{
			
	// ============= Single Run =============================================
			//https://sitterlehomes.com/community/clearwater-ranch/
//			if(!comUrl.contains("https://sitterlehomes.com/community/santa-rita-ranch"))return;
	
			U.log("count ::"+j);
			U.log("comUrl ::"+comUrl);

			
			oldData=oldData.replace("Community Type: <strong class=\"dark-strong\">Garden", "Community Type Garden");
			U.log("oldData --->"+oldData);
//	U.log(U.getCache("https://sitterlehomes.com/communities/clearwater-ranch/"));
//	U.log(oldData);
		
		
		
//		if(comUrl.contains("/communities-san-antonio"))return;
		
		comUrl = comUrl.replace(":https://sitterlehomes.comhttps://sitterlehomes.com/parmer-ranch-cottages-interest-list/", "https://sitterlehomes.com/parmer-ranch-cottages-interest-list/").replace("https://sitterlehomes.comhttps://sitterlehomes.com/highland-village-interest-list/", "https://sitterlehomes.com/highland-village-interest-list/").replace("https://sitterlehomes.comhttps://sitterlehomes.com/parmer-ranch/", "https://sitterlehomes.com/parmer-ranch/");
		
	
		
		
//		if(comUrl.contains("https://sitterlehomes.com/communities/prospect-creek-at-kinder-ranch-"))oldData = "listing_type\":\"Traditional Homes\"";
		
		
		comUrl=comUrl.replace("https://sitterlehomes.comhttps://sitterlehomes.com/vida-interest-list/", "https://sitterlehomes.com/vida-interest-list/");
		comUrl=comUrl.replace("https://sitterlehomes.comhttps://sitterlehomes.com/ranches-at-creekside-interest-list/", "https://sitterlehomes.com/ranches-at-creekside-interest-list/").replace("https://sitterlehomes.comhttps://sitterlehomes.com", "https://sitterlehomes.com")
				.replace("https://sitterlehomes.comhttps://sitterlehomes.com/cimarron-hills-villas-interest-list/", "https://sitterlehomes.com/cimarron-hills-villas-interest-list/");
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"=============repeated");
			return;
		}
		
		if(comUrl.contains("https://sitterlehomes.comhttps://sitterlehomes.com/ranches-at-creekside-interest-list/")) return;/// not opening in june
		if(comUrl.contains("https://sitterlehomes.com/audubon-interest-list/"))return;//Page not found
		
		
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml  = U.getHTML(comUrl);
		String descriptionSec=U.getHtmlSection(comHtml, "<div class=\"et_pb_text_inner\"><p style=\"text-align: left;\">", "</p></div>");
		U.log("description :: "+descriptionSec);
		if(descriptionSec==null) {descriptionSec=ALLOW_BLANK;};
		String homeSqftString="";
		String homeSqfts[]= U.getValues(comHtml, "<div class=\"listing-info\">", "</p></div></div>");
		for(String d: homeSqfts) {
			homeSqftString+="::::"+d;
		}
		
		String comIdfrLat=U.getSectionValue(oldData, "id=\"result", "onmouseenter=\"");
		String commId=U.getSectionValue(comIdfrLat, "-id-", "\"");
		U.log("commId  "+commId);
		
		
		
		
		
		
		
		
		
		
		
		//=============UnitCount============
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		int lotCount=0;
		
		if(comHtml.contains("contradovip")) {
//		String lotMapPart=U.getSectionValue(comHtml, "<div class=\"et_pb_code_inner\"><iframe", "<div class=\"et_pb_row et_pb_row");
	String lotMapPart=U.getSectionValue(comHtml, "<iframe", "</iframe>");

		String lotLink=U.getSectionValue(lotMapPart, "data-src=\"", "\"");
		String lotHtml=U.getHtml(lotLink, driver);
		
		U.log("lotLink ::"+lotLink);
		U.log(U.getCache(lotLink));
		 
		 
		 String[] lotSection=U.getValues(lotHtml, "<g id=\"v.1.opt", "\">");
			for(String lotSec:lotSection) {
				lotCount++;
			}
			counting=Integer.toString(lotCount);
		}
		if(counting.equals("0")) {
			counting=ALLOW_BLANK;
		}
		U.log("lotCount ::"+counting);
		
		
		//===========
//		U.log(homeSqftString);
		String comName = U.getHtmlSection(oldData, "<a class=\"result--title\"", "/a>");
		comName=U.getHtmlSection(comName, ">", "<").replace("&#8217;", "").replace("&#8211;", "-").replaceAll(" - Oaklands| - Parklands| - Country Club| - Villas", "").replace(">", "");
		U.log("from oldData region :: "+comName);
		String notes=ALLOW_BLANK;
		
		if(comName==null)comName = U.getSectionValue(comHtml, "title>", "|");
		
		comName = comName.replaceAll("- CLOSE OUT| - ONE HOME REMAINING|- By Appointment Only|- VILLAS|- SOLD OUT|- CLOSEOUT|- COUNTRY CLUB", "");
		if(comUrl.contains("https://sitterlehomes.com/communities/prospect-creek-at-kinder-ranch-55s"))comName="Prospect Creek At Kinder Ranch 55s";
		if(comUrl.contains("https://sitterlehomes.com/communities/prospect-creek-at-kinder-ranch-65s"))comName="Prospect Creek At Kinder Ranch 65s";
		
		if(comUrl.contains("https://sitterlehomes.com/communities/prospect-creek-at-kinder-ranch-80s"))comName="Prospect Creek At Kinder Ranch 80s";
		comName=comName.replace("- COMING SOON", "").replace("- OAKLANDS", "");
		
		comName=comName.replaceAll("Parmer Ranch Cottages Interest List |parmer ranch cottages interest list","Parmer Ranch");
		comName=comName.replace("&#038; Country Club", "").replaceAll("new homes by sitterle in santa rita ranch|New Homes by Sitterle in Santa Rita Ranch","Santa Rita Ranch");
		
		U.log("comName ::"+comName);
		
		
		
		
		
		comHtml = U.removeSectionValue(comHtml, "<head>", "</head>");
		//address and latlng
		String latlng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String geo="False";
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String address = U.getSectionValue(oldData, "\"location\":{\"address\":{\"formatted\":\"", ", USA\"");
//		String address = U.getSectionValue(oldData, "<p class=\"result--city\">", ", USA\"");
//     String addSec=U.getSectionValue(comHtml, "<div class=\"et_pb_module et_pb_text et_pb_text_4_tb_body et_clickable", "<div class=\"et_pb_module et_pb_text et_pb_text_5_tb_body");
        String addSec=U.getSectionValue(comHtml, "<div class=\"et_pb_module et_pb_text et_pb_text_4_tb_body et_clickable  et_pb_text_align_center et_pb_bg_layout_light\">", "</div><div class=\"et_pb_module et_pb_text et_pb_text_5_tb_body  et_pb_text_align_center et_pb_bg_layout_light\">");
//        U.log("addSec=="+addSec);
        if(addSec==null) {
        	addSec=U.getSectionValue(comHtml, "<div class=\"et_pb_module et_pb_text et_pb_text_4_tb_body  et_pb_text_align_center et_pb_bg_layout_light\">","<div class=\"et_pb_module et_pb_text et_pb_text_5_tb_body  et_pb_text_align_center et_pb_bg_layout_light\">");
        			
        }
       if(addSec!=null) {
    	 address=U.getSectionValue(addSec, "<div class=\"et_pb_text_inner\">", "</div>");
    	 address=address.trim();
    	
    	 U.log("addSec==2 "+addSec);
       
       }
    
		U.log(address+"-----------");
		if(address==null && (comHtml.contains("<a href=\"https://goo.gl/maps/") || comHtml.contains("https://www.google.com/maps/place/"))) {
			address = U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "<br /> <a href=\"tel");
			
			U.log("addSec ::"+address+"<<<");
			if(address ==null)
				address = U.getSectionValue(comHtml, "<a href=\"https://goo.gl/maps/", "<a href=\"tel");
			if(address != null && (address.contains("</a>") && address.contains("target=\"_blank\" rel=\"noopener noreferrer\">")))
				address = U.getSectionValue(address, "target=\"_blank\" rel=\"noopener noreferrer\">", "</a>");
			else if(address != null && (address.contains("</a>") && address.contains("target=\"_blank\" rel=\"noopener noreferrer\" title=")))
				address = U.getSectionValue(address, "target=\"_blank\" rel=\"noopener noreferrer\" title=\"", "\"");

			U.log("addressa1 == "+address);
			if(address != null) address = address.replaceAll("<.*?>", "");
		}
		
		/*if(latlng[0]==ALLOW_BLANK && oldData!="") {
			U.log("hello i am here as weelll");
			latlng[0] = U.getSectionValue(oldData, "\"lat\":\"", "\"");
			latlng[1] = U.getSectionValue(oldData, "\"lng\":\"", "\"");
		}*/
		
		
		String latlongSec=U.getSectionValue(latlngSec, "idMap.set(\""+commId+"\",", ");");
		U.log("latlongSec"+latlongSec);
		if(latlongSec!=null) {
			U.log("Hello everyone");
			latlng[0]=U.getSectionValue(latlongSec, "\"", ",");
			latlng[1]=U.getSectionValue(latlongSec, ",", "\"");

		}
		
		U.log("lat long from Region= "+Arrays.toString(latlng));
		
		if(oldData=="" || (latlng[0] == null && latlng[1] == null)) {
//			U.writeMyText(comHtml);
			String latSec = U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "\"");
			if(latSec==null) {
				latSec = U.getSectionValue(comHtml, "https:\\/\\/www.google.com\\/maps\\/place\\", "target\":\"_blank\"}");
			}
			
			U.log("latSec==  "+latSec);
			
			
			if(latSec != null && (latlng[0] == null && latlng[1] == null)){
				latSec = U.getSectionValue(latSec, "/@", ",17z");
				if(latSec!=null) {
				U.log("this is latsec:::::"+Arrays.toString(latSec.split(",")));
				latlng=latSec.split(",");
				}
			}
		}
		if(address!=null) {
		
			if(address.contains("RR 2338")) address = address.replace("RR 2338", "Rr 2338");
			address=address.replace("1000 Prescott Drive Conroe", "1000 Prescott Drive, Conroe").replace("&#039;", "'")
					.replace("Way Liberty", "Way, Liberty")
					.replace("Place Georgetown", "Place, Georgetown");
		}
		U.log("addSec ::1 "+address);
		if(address!=null)
		add = U.getAddress(address);
		U.log("add :"+Arrays.toString(add));
		if(add[0]==ALLOW_BLANK && comHtml.contains("<div class=\"et_pb_text_inner\"><p class=\"marg-bottom\" style=\"text-align: center;\"><em>")) {
			String addsec = U.getSectionValue(comHtml, "<div class=\"et_pb_text_inner\"><p class=\"marg-bottom\" style=\"text-align: center;\">", "</a>");
			if(addsec!=null)
				addsec = U.getSectionValue(addsec, "<em>", "<");
			add = U.getAddress(addsec);
			
		}
		if(address!=null)
			address = address.replace("29131 Bambi Pl", "29131 Bambi Place");
		
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			address = U.getSectionValue(comHtml, "target=\"_blank\" rel=\"noopener noreferrer\">", "</a>");
			if(address != null){
				address = address.replaceAll("<.*?>", "");
				U.log(address);
				add = U.getAddress(address);
				
//				if(add1[0] != ALLOW_BLANK)add[0] = add1[0];
			}
		}
		
		if(comUrl.contains("/communities/fronterra-at-westpointe/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "San Antonio";
			add[2] = "TX";
			add[3] = ALLOW_BLANK;
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
			
		}
		if(comUrl.contains("communities/the-lagos-at-aliana/"))
		{
			add[0] = ALLOW_BLANK;
			add[1] = "Richmond";
			add[2] = "TX";
			add[3] = ALLOW_BLANK;
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
		}
		
		
		if(comUrl.contains("/community/cibolo-crossing"))////june city n state is given
		{
			add[0] = ALLOW_BLANK;
			add[1] = "Universal City";
			add[2] = "TX";
			add[3] = "78148";
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state and zip";
		}
		
		if(comUrl.contains("ranches-at-creekside-interest-list/"))////june city n state is given
		{
			add[0] = ALLOW_BLANK;
			add[1] = "Boerne";
			add[2] = "TX";
			add[3] = ALLOW_BLANK;
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";
		}
		
       if(comUrl.contains("https://sitterlehomes.com/vida-interest-list")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "San Antonio";
			add[2] = "TX";
			add[3] = ALLOW_BLANK;
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
       
       if(comUrl.contains("https://sitterlehomes.com/highland-village-interest-list/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Georgetown";
			add[2] = "TX";
			add[3] = ALLOW_BLANK;
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
       if(comUrl.contains("https://sitterlehomes.com/parmer-ranch-cottages-interest-list")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Georgetown";
			add[2] = "TX";
			add[3] = "78633";
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
       
       if(comUrl.contains("https://sitterlehomes.com/santa-rita-ranch-interest-list/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Georgetown";
			add[2] = "TX";
			add[3] = "78628";
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
      
       if(comUrl.contains("https://sitterlehomes.com/audubon-interest-list/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Magnolia";
			add[2] = "TX";
			add[3] = "77354";
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
      
       if(comUrl.contains("https://sitterlehomes.com/high-meadow-estates-interest-list/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Magnolia";
			add[2] = "TX";
			add[3] = "77316";
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
       if(comUrl.contains("https://sitterlehomes.com/lakeview-estates-interest-list/")) {
			
			add[0] = ALLOW_BLANK;
			add[1] = "Waller";
			add[2] = "TX";
			add[3] = "77484";
			
			latlng = U.getlatlongGoogleApi(add);
			if(latlng==null)
				U.getlatlongHereApi(add);
			
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";
//			notes="address is taken from city, state.";//exec in june
		}
       
       
       
       
       
       
       
       
       
		
		if((add[0]==null || add[3].length()<3 || add[0].length()<3) && latlng[0]!=null) {//latlng[0].length()>4
			U.log(">>>>>>>>>>>>>>>");
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			geo = "TRUE";
			add[0]=add[0].replace("Benedum Wy", "Benedum Way");
		}
		
		if(latlng[0] == null || latlng[0].length()<3 && add[0].length()>3) {
			U.log(">>>>>>>>>>>>>>>1");
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			geo = "TRUE";
		}
		
		int inventoryHomeCount = 0;
		String homeSection[] = U.getValues(comHtml, "<div class=\"posting", "</div>");
		U.log(homeSection.length);
		for(String homeSec :homeSection){
			if(homeSec.contains("data-listing_status=\"1\"") && !homeSec.contains("data-status=\"Sold\"")){
				inventoryHomeCount++;
			}
		}
		U.log("Total Inventory home count :"+inventoryHomeCount);
		String rmsec = U.getSectionValue(comHtml, "<div class=\"et_pb_code_inner\"><div id=\"filters-for-postings\">", "<label>Listing Type</label>");
		if(rmsec != null)
		comHtml = comHtml.replace(rmsec, "");
		//Homes
		comHtml = comHtml.replaceAll("</p>\\s*</p></div></div>", "endSec");
		String homesData[];
		String allHomeData= ALLOW_BLANK;
		try {
		homesData= U.getValues(comHtml, "<div class=\"posting \"", "endSec");
		
		for(String data:homesData) {
//			U.log(data);
			allHomeData+=U.getHTML(U.getSectionValue(data, "<a class=\"listing-link\" href=\"", "\""));
		}
		}
		catch(NullPointerException ne) {}
		U.log(comUrl+"::"+comName+"::"+address);
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comHtml=comHtml.replace("K's", ",000");
		//Prices
		
		String sec[] = U.getValues(comHtml, "<p class=\"magnus termscontainer\">", "<");
		for(String s: sec)
			comHtml = comHtml.replace(s, "");
		
		
		comHtml=comHtml.replaceAll("data-price=\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\"|4+ Bedroom, 3+ Bath, \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|>$\\d{3},\\d{3} - \\$\\d{3},\\d{3}</option>|name=\"\\$\\d{3},\\d{3} - \\$\\\\d{3},\\d{3}\"|value=\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\"", "");
	//	oldData=oldData.replace("0s", "0,000").replaceAll("\"starting_price\":\"High \\$\\d{3},\\d{3}\"|\"starting_price\":\"Low \\$\\d{3},\\d{3}\"|\"starting_price\":\"Mid \\$\\d{3},\\d{3}\"", "");
	
		oldData=oldData.replace("From the Mid 600's", "From the Mid 600,000").replace("From the $1M+", "From the $1,000,000").replace("0s", "0,000").replace("0's", "0,000").replaceAll("price\":\"Low \\$900,000\",\"li", "");
		
		if(comUrl.contains("https://sitterlehomes.com/communities/prospect-creek-at-kinder-ranch")) {
			//removing region page prices for sub-communities.
			String remove = U.getSectionValue(oldData, "starting_price\":\"", "listing");
			oldData = oldData.replace(remove, "");
		}
		
//		U.log("oldData --->"+oldData);
		allHomeData=allHomeData.replaceAll("description\":\"$982,347|content=\"$982,347", "");
		String prices[] = U.getPrices((comHtml.replace("FROM $1M+", "FROM $1,000,000").replaceAll("data-price=\"\\$\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}\"|data-price=\"\\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}\"|=\"\\$\\d,\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}\"", "") 
				+ allHomeData + oldData) ,

				"FROM \\$\\d,\\d{3},\\d{3}|From the Mid \\d{3},\\d{3}|From the \\$\\d,\\d{3},\\d{3}|starting_price\":\"Mid \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|<p>\\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|From: \\$\\d{3},\\d+|From the \\d{3},\\d+|<p>\\$\\d{3},\\d{3}|<h2 style=\"text-align: left;\">\\$\\d{3},\\d{3}</h2>", 0);

//		U.log("MMMMMMM "+Util.matchAll(oldData, "[\\s\\w\\W]{30}\\$500[\\s\\w\\W]{100}", 0));
		
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price: "+minPrice+"\t"+maxPrice);
		// ======================================================Sq.ft===========================================================================================

		// U.log(html);
		comHtml = comHtml.replaceAll("\\d+,\\d+ sq. ft. clubhouse|=\"Santa Rita Ranch Gated Community ", "")
				.replace("\">ESTATE HOMES COMING", "")
				.replace("Sitterle homes is now", "");
		String[] sqft = U.getSqareFeet((comHtml + allHomeData+homeSqftString+oldData),//oldData  june
				"\\d{4}-\\d{4} square feet|Sq Ft: <strong class=\"dark-strong\">\\d,\\d{3} - \\d,\\d{3}| \\d{4} Sq. Ft|ranging from \\d,\\d{3} sq. ft. to \\d,\\d{3}\\+? sq. ft.|from \\d,\\d{3} to \\d,\\d{3} sq. ft|\\d,\\d+ - \\d,\\d+ square|\\d,\\d+ sq. ft.  \\d,\\d+ sq. ft.|\\d,\\d{3} Sq. Ft|\\d,\\d{3} Sq. ft.|\\d,\\d+ sq ft",
				0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		// Type================================================
//		U.log("mmmmmm"+Util.matchAll(oldData+ comHtml+allHomeData, "[\\w\\s\\W]{30}Final Opportunities Remaining[\\w\\s\\W]{30}", 0));

		String communityType = U.getCommType(comHtml + oldData + allHomeData.replaceAll("=\"Santa Rita Ranch Gated Community|a gated lock & leave|very essence of lake living|Close to outstanding facilities for golf and tennis|Towne Lake|Elongated", ""));
		System.out.println("Community type:::::" + communityType);
		// propType================================================
		comHtml = comHtml.replaceAll("(value|name|type)=\"Traditional|Traditional</option>", "");
		oldData = oldData.replace("\"listing_type\":\"Traditional\"", "\"listing_type\":\"Traditional homes\"");
		String removes[] = U.getValues(comHtml, "<p class=\"magnus termscontainer\">", "</p>");
		for(String rem : removes) comHtml = comHtml.replace(rem, "");
//				U.log(">>>>>>>"+Util.matchAll(comHtml + oldData+allHomeData, "[\\w\\s\\W]{50}Patio[\\w\\s\\W]{50}", 0));

		String propType = U.getPropType((comHtml + oldData+allHomeData+comName).replace("Community Type: <strong class=\"dark-strong\">Traditional</strong>", "traditional home").replace("Gardens Residents","Garden Homes").replace("Custom Freedom", "custom-built home").replace("Large estate lots", "Estate Style Living")
				.replaceAll("Patio-Front-Entry.jpg|Village|village", ""));
		// dpropType================================================
		
		String dpropType = U.getdCommType((comHtml + oldData+allHomeData).replaceAll("(Mayfield|Clearwater|Tank|Waggoner|Alamo|Rita) Ranch|Ranch Shopping", ""));
		// dpropType================================================
		
		comHtml=comHtml.replaceAll("Phase 2</h1>\\s+<h1 style=\"text-align: center;\">coming soon</h1>", "Phase 2 Coming Soon")
				.replaceAll("ALL LOTS</h1>\\s+<h4 style=\"text-align: center;\">Currently sold out", "ALL LOTS Currently sold out")
				.replaceAll("Phase 5</h1>\\s+<h1 style=\"text-align: center;\">coming 2022", "Phase 5 coming 2022")
				.replaceAll("Only TWO</h1>\n\\s*<h4 style=\"text-align: center;\">Inventory homes left", "Only TWO Inventory homes left")
				.replaceAll("Only three</h1>\n" + 
						"<h4 style=\"text-align: center;\">Inventory homes left</h4>", "Only three Inventory homes left");
		
		oldData = oldData.replaceAll("homes coming soon|<b> New Inventory Coming Soon|<b> Final Opportunities Remaining", "").replace("Grand Opening of New Section!", "Grand Opening New Section!");
		
		String pstatus = U.getPropStatus((descriptionSec+oldData+ comHtml)
				.replace("class=\"comm--yellow-bar-subtitle\">Now", "")
				.replace("<em>Now Selling | By Appointment Only</em>", "")
				.replace("17 homesites are available", "17 homesites available").replaceAll("New Phase Now Open! New Floorplans|creek home sites available|Final Inventory Homes Coming Soon.\"starting_price\":\"CLOSE OUT\"|Coming Soon FT image|Amenity Center Coming Soon|scription\":\"<b> New Community Now Available| & creek home sites available</li>|Center Coming|last chance master|Features Coming|Model Home Coming|soon ft", ""));
//		U.log("mmmmmm"+Util.matchAll(oldData, "[\\w\\s\\W]{50}New Phase Now Open[\\w\\s\\W]{50}", 0));
//		U.log("mmmmmm"+Util.matchAll(descriptionSec+oldData+ comHtml, "[\\w\\s\\W]{50}now open[\\w\\s\\W]{30}", 0));

		U.log("pstatus:::::::::"+pstatus);
		
//		if(inventoryHomeCount > 0){
//			if(pstatus == ALLOW_BLANK) pstatus = "Inventory Homes Available";
//			else if(pstatus!= ALLOW_BLANK) pstatus += ", Inventory Homes Available";
//		}
		
		if(comUrl.contains("https://sitterlehomes.com/communities/water-oak-at-san-gabriel"))pstatus="Final Opportunities, Closeout";
		if(comUrl.contains("https://sitterlehomes.com/communities/la-creciente-at-johnson-ranch/")) pstatus = pstatus.replace("Last Chance", "Last Chance Remaining");
		if(comUrl.contains("https://sitterlehomes.com/communities/veranda-porch-series"))add[0]="2207 Fenn Dale Ct";
		pstatus=pstatus.replace("Final Opportunities Remain, Limited Opportunities Remain", "Final Opportunities Remain");
		pstatus=pstatus.replace("Final Opportunities Remain, Limited Opportunity Remaining", "Final Opportunities Remain");
		if(comUrl.contains("https://sitterlehomes.com/communities/the-overlook-at-stonewall-estates/")) {
			add[0]="19302-19398 Strauss";
			add[1] = "San Antonio";
			add[2] = "TX";
			add[3]="78256";
			latlng=U.getlatlongGoogleApi(add);
		//	add=U.getAddressGoogleApi(latlng);
		}
		/*if(comUrl.contains("https://sitterlehomes.com/communities/clearwater-ranch/")) {
			pstatus+=", Phase 5 Coming 2022";
			//minPrice="$689,000";
		}*/
		
		String note=U.getnote(comHtml.replace("pre-selling to begin in July 2021", "pre-selling July 2021").replace("pre-selling to begin in July 2021", "pre-selling July 2021"));
		if(comUrl.contains("https://sitterlehomes.com/communities/austin-design-studio/"))add [0] = "1335 Whitestone Blvd";
		add[0] = add[0].replace("29131 Bambi Pl", "29131 Bambi Place");
		pstatus = pstatus.replace("New Lots Now Available, Now Available", "New Lots Now Available");
		if(comUrl.contains("https://sitterlehomes.com/communities/oaks-at-highland-village/"))pstatus = "New Section Coming Soon";
		if(comUrl.contains("https://sitterlehomes.com/communities/clearwater-ranch"))pstatus ="Phase 5 Coming 2022, Final Phase Coming Spring 2022";
		if(comUrl.contains("https://sitterlehomes.com/communities/lakes-of-bella-terra-west"))pstatus=pstatus.replace("Now Selling", "Final Section Now Selling");
				
		if(comUrl.contains("https://sitterlehomes.com/communities/miralomas-in-historic-boerne-65s"))minPrice = "$565,000";
//		if(comUrl.contains("https://sitterlehomes.com/communities/miralomas-in-historic-boerne-80s")) {minPrice = "$986,757";maxPrice=ALLOW_BLANK;}
		
		
		
		U.log("comName  "+comName);
		U.log("latlng[0]  "+latlng[0]);
		U.log(" latlng[1]  "+ latlng[1]);
		U.log("minPrice  "+minPrice);
		U.log("add[0]  "+add[0]);
		U.log("add[1]  "+add[1]);
		U.log("add[2]  "+add[2]);
		U.log("add[3]  "+add[3]);
		U.log("propType  "+propType);
		U.log("dpropType  "+dpropType);
		U.log("pstatus  "+pstatus);
		
		if(comUrl.contains("https://sitterlehomes.com/communities/miralomas-in-historic-boerne-80s/")) {
			minPrice="$996,757";
			maxPrice=ALLOW_BLANK;
		}
		if(comUrl.contains("https://sitterlehomes.com/community/cibolo-crossing")) {
			pstatus+=", Coming Soon";
		}
		
		if(pstatus!=null)
		pstatus=pstatus.replace("Final Section Final Section Now Selling", "Final Section Now Selling")
				.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon")
				.replace("New Phase Now Open, Now Open", "New Phase Now Open")
				.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
		
//        if((notes!=null||notes!=ALLOW_BLANK)&&(note!=null||note!=ALLOW_BLANK) )
//        	note=notes+", "+note;
		
		data.addCommunity(comName.toLowerCase().replaceAll(" - ESTATES| - CLOSEOUT|- COMING SOON!| - ONE HOME REMAINING| - Country Club", "").replace("Custom/BOYL", "Custom/boyl").replace("&#039;", ""), comUrl, communityType);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replaceAll("\\s*,\\s*", " "), add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dpropType);
		data.addPropertyStatus(pstatus.replaceAll("Final Opportunities Remaining, Final Opportunities|Final Opportunities Remaining, Final Opportunity", "Final Opportunities Remaining"));
		data.addNotes(notes);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}
	j++;
//		}catch (Exception e) {U.log(e);}
	}

	
	private void addCommunity(String oldData, String regPropType) throws Exception 
	{
//		 if(j == 18)
		{
			String comUrl = U.getSectionValue(oldData, "<a href=\"", "\"");
//			U.log(comUrl);
			// if(comUrl ==null)return;

//			if(!comUrl.contains("https://sitterlehomes.com/community/santa-rita-ranch"))return;
//			if (!comUrl.contains("https://sitterlehomes.com/community/cimarron-hills-country-club")) return;
			
			U.log("Count ===" + j);
			U.log("ComUrl--->" + comUrl);
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl+":::::::::::::::::::::::::Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			String bannerSec = U.getSectionValue(html, "<div class=\"location-banner\">", "</div>");
			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(oldData, "<span class=\"name\">", "</span>");
			if (communityName == null) {
				communityName = U.getSectionValue(html, "<h1 class=\"sec-heading sans-heading sm-marg-bottom\">","</h1>");
			}
		
			communityName=communityName.replace("SOLD OUT!", "");
			communityName=communityName.replace("- COMING SOON", "");

			U.log("community Name---->" + communityName);

			// ============================================note====================================================================
			String note = U.getnote(html + oldData);

			// ================================================Address
			// section===================================================================
			String directionHtml = ALLOW_BLANK;
			if(html.contains("btn gold-btn full-width marg-bottom\">Get Directions</a>")){
				U.log(":::::::::::in direction:::::::");
				directionHtml = U.getHTML(comUrl+"?view=directions");
			}
			
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			
			String addsec = ALLOW_BLANK;
			addsec = U.getSectionValue(oldData, "<br/>", "</p>");
			// U.log("lll"+addsec);

			if (addsec != null && !addsec.contains("@")) {
				String ss = U.getSectionValue(html, "<h2 class=\"marg-bottom\"><a", "/a>");
				if (ss != null) 
				{				
					ss = ss.replace("By Appointment Only", "");
					ss = U.getSectionValue(ss, ">", "<");
					if (ss.length() > 8)
						U.log("addsec : "+ss);
					addsec = ss;
				}
				else{
					U.log("addsec : "+addsec);
					addsec = U.getSectionValue(directionHtml, "Located at: ", "<br />");
					U.log("Direction Address : " +addsec);
				}
			}
			
			if (addsec != null) {
				addsec = addsec.replace("Williams Way Blvd. & Veranda Trails Pkwy.",
						"Williams Way Blvd & Veranda Trails Pkwy")
						.replace("Boerne, TX 78006, Boerne, TX 78006", "Boerne, TX 78006").replace("Find your new home at The Lakes at Bella Terra with Sitterle Homes.  Featuring resort style amenities and acres of lakes, to promote peacefulness and...","");
			} else {
				addsec = U.getSectionValue(html, "=directions\">", "</a>") + "<br/>";
			}
			
			if (comUrl.contains("sitterle-homes-new-homes-prospect-creek-kinder-ranch-san-antonio-texas/prospect-creek-at-kinder-ranch-80s")) {
				add[1] = "San Antonio";
				add[2] = "TX";				
				latlag = U.getlatlongGoogleApi(add);
				
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				
				String add1[] = U.getAddressGoogleApi(latlag);				
				add[0] = add1[0];
				add[3] = add1[3];
				add1 = null;
				geo = "True";
				note = "Address and Lat-Lng Taken From City and State";
				
			}
			
			if (comUrl.contains("/new-homes-in-boerne-tx-miralomas/miralomas/")||comUrl.contains("new-luxury-homes-in-ranches-at-creekside-in-boerne/ranches-at-creekside/")) {
				add[1] = "Boerne";
				add[2] = "TX";
				add[3] = "78006";
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				
				String add1[] = U.getAddressGoogleApi(latlag);
				if(add1 == null)
					add1 = U.getAddressHereApi(latlag);
				
				add[0] = add1[0];
				add[3] = add1[3];
				add1 = null;
				geo = "True";
				note = "Address and Lat-Lng Taken From City and State";				
			}
//			if (comUrl.contains("/sitterle-homes-new-homes-prospect-creek-kinder-ranch-san-antonio-texas/prospect-creek-at-kinder-ranch-"))
//			{
//				add[1] = "San Antonio";
//				add[2] = "TX";
//				add[3] = "";
//				latlag = U.getlatlongGoogleApi(add);
//				if(latlag == null) latlag = U.getlatlongHereApi(add);
//				
//				//add = U.getAddressGoogleApi(latlag);
//				if(add == null) add = U.getAddressHereApi(latlag);				
//				geo = "True";
//				note = "Address and Lat-Lng Taken From City and State";
//			}
			
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			U.log("Address---->" + Arrays.toString(latlag));
			
			if(comUrl.contains("https://www.sitterlehomes.com/new-homes/new-homes-at-salado-canyon-at-rogers-ranch-san-antonio/salado-canyon-at-rogers-ranch/")){
				add[0] = "Point Bluff Dr";
				add[1] = "San Antonio";
				add[2] = "TX";
				add[3] = "78258";
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				note = "Street Is Taken From Image At Direction Page";
				geo = "True";
			}
			if (comUrl.contains("https://www.sitterlehomes.com/new-homes/new-homes-san-antonio-the-overlook-at-stonewall-estates/the-overlook-at-stonewall-estates/")){
				add[0] = "Stonewall Hill";
				add[1] = "San Antonio";
				add[2] = "TX";
				add[3] = "78256";
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);				
				note = "Street Is Taken From Image At Direction Page";
				geo = "True";
			}
			U.log("addsec-3====" + addsec);			
			if (!addsec.contains("By Appointment Only") && addsec.contains("<br/>")) {
				if (!addsec.isEmpty())
					addsec = addsec.replaceAll("\\s{2,}|210-880-3846", "");
				if (addsec.trim().length() > 20 && add[0].length()<4 && Util.match(addsec, "\\d{5,6}")!=null) {
					U.log(addsec+"   "+addsec.length());
					add = U.findAddress(addsec);
				}
			}
			
			if (add[1].length() < 2  && addsec.trim().length()>15) {			
				add = U.getAddress(addsec);
			}
			if(comUrl.contains("https://www.sitterlehomes.com/new-homes/san-antonio/blue-skies-of-texas/"))
			{
				add = U.getAddress("5100 John D Ryan Blvd, San Antonio, TX 78245");
				note = "Street Is Taken From Image At Direction Page";
			}
			
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);

			// ------------------------------------------------------------------------------------------------------------------

			String latSec = U.getSectionValue(html, "var myLatLng = new google.maps.LatLng(", ")");

			U.log("latSec :: " + latSec);
			if (latSec != null) {
				if (latSec.contains("29°46'01.4,98°30'40.1"))
					latSec = "29.767056, 98.511139";

				latlag = latSec.split(",");
				U.log("Latlong--->" + latlag[0] + "  " + latlag[1]);
			} else {
				if (add[1] != null && add[1] != ALLOW_BLANK && latlag[0]==null) {
					latlag = U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo = "TRUE";
				}
			}
		
		
			if (add[1] != null && add[1] != ALLOW_BLANK && latlag[0]!=null && latlag[0]==ALLOW_BLANK) {
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			
			if(comUrl.contains("https://www.sitterlehomes.com/new-homes/sitterle-homes-new-homes-prospect-creek-kinder-ranch-san-antonio-texas/prospect-creek-at-kinder-ranch-65s/")) 
			{
				latlag[0] = "29.424118";
				latlag[1] = "-98.493645";
			}
			
		
			
			
			
			if(comUrl.contains("https://www.sitterlehomes.com/new-homes/sitterle-homes-new-homes-prospect-creek-kinder-ranch-san-antonio-texas/prospect-creek-at-kinder-ranch-55s/")) 
			{
				latlag[0] = "29.4241219";
				latlag[1] = "-98.4936281";
			}
			
			if (add[0].length() < 4 && latlag[0]!=null && latlag[0] !=ALLOW_BLANK) 
			{			
				add = U.getAddressGoogleApi(latlag);				
				if(add == null)	add = U.getAddressHereApi(latlag);
				geo = "True";
			}
			//29.424118, -98.493645
			U.log("latlag :: " + Arrays.toString(latlag));
			
/*			if (comUrl.contains(
					"http://www.sitterlehomes.com/new-homes/new-homes-for-sale-in-the-enclave-at-weston-oaks/the-enclave-at-weston-oaks/")) {
				add[0] = "Intersection of Cottonwood Way and Wiseman Blvd";
				add[1] = "San Antonio";
				add[2] = "TX";

				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				
				String add1[] = U.getAddressGoogleApi(latlag);
				if(add1 == null)	add1 = U.getAddressHereApi(latlag);
				add[3] = add1[3];
				add1 = null;
//				add[3] = U.getAddressGoogleApi(latlag)[3];
				geo = "True";
				note = "Street Name Is Taken From Get Direction Details";
			}
*/
/*			 if (comUrl.contains("http://www.sitterlehomes.com/new-homes/sugar-land/remodeling-renovations/")) {
				add[1] = "Sugar Land";
				add[2] = "TX";
				add[3] = "77479";
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				
				String add1[] = U.getAddressGoogleApi(latlag);
				if(add1 == null) add1 = U.getAddressHereApi(latlag);
				add[0] = add1[0];
				add1 = null;
//				add[0] = U.getAddressGoogleApi(latlag)[0];
				// add[3]=U.getAddressGoogleApi(latlag)[3];
				geo = "True";

			}
*/
			add[0] = add[0].replace("MODEL COMING SOON - ", "");
			// ============================================Price and
			// SQ.FT======================================================================
			String[] maltisec = U.getValues(html, "<li><a class=\"menuitem\" href=\"", "\"");

			String floorHtml = "";
			String featureHtml = "";
			String invenHtml = "";
			String moveHtml = ALLOW_BLANK;
			// WebDriver driver = new FirefoxDriver();
			for (String multilink : maltisec) {
				U.log("multilink::" + multilink);

				if (multilink.contains("view=plans")) {
					floorHtml = U.getHTML(multilink);
					floorHtml = floorHtml.replace("ST", "Story");
				}
				if (multilink.contains("view=specs")) {
					invenHtml = U.getHTML(multilink);
					invenHtml = invenHtml.replace("ST", "Story");
				}
				if (multilink.contains("view=features")) {
					featureHtml = U.getHTML(multilink);
				}

				if (multilink.contains("?view=moveinready")) {
					moveHtml = U.getHTML(multilink);
				}
			}
			// driver.close();

			String moveHomeHtml = ALLOW_BLANK;
			if (moveHtml != null) {
					String[] moveInurls = U.getValues(moveHtml, "<a class=\"view-details\" href=\"", "\"");
					U.log("Total Move Homes : "+moveInurls.length);
					for (String moveIn : moveInurls) {
						//String url = U.getSectionValue(moveIn, "href=\"", "\"");
						U.log("MoveIn Html: " + moveIn);
						String moHtml = U.getHTML(moveIn);
						moveHomeHtml += U.getSectionValue(moHtml, "Available Homes</h3>", "<span id=\"modal_close\">");
					}
				//}
			}

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			// U.log(floorHtml);
			html=html.replace("K's", ",000");
			String prices[] = U.getPrices(html + floorHtml + invenHtml,

					"\\$\\d,\\d+,\\d+|From: \\$\\d{3},\\d+|From the \\d{3},\\d+", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			// ======================================================Sq.ft===========================================================================================

			// U.log(html);
			String[] sqft = U.getSqareFeet(html + floorHtml + invenHtml + featureHtml,
					"ranging from \\d,\\d{3} sq. ft. to \\d,\\d{3}\\+? sq. ft.|from \\d,\\d{3} to \\d,\\d{3} sq. ft|\\d,\\d+ - \\d,\\d+ square|\\d,\\d+ sq. ft.  \\d,\\d+ sq. ft.|\\d,\\d{3} Sq. Ft|\\d,\\d+ sq ft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

			// ===================Floor Plan Htmls====================
			String combinedPlanHtmls = null;
			if (!floorHtml.isEmpty()) {
				String planSection = U.getSectionValue(floorHtml, "<div id=\"plan-listings",
						"</div><!-- span8 -->");
//				U.log(planSection);
				if (planSection != null) {
					String[] planUrls = U.getValues(planSection, "<a href=\"", "\"");
					U.log("Plan Homes Count ==" + planUrls.length);
					int x = 0;
					for (String planUrl : planUrls) {
						U.log(planUrl);
						try{
						combinedPlanHtmls += U.getSectionValue(U.getHTML(planUrl), "<h1 class=\"sec-heading", "</div>");
						}catch(Exception e){}
						if (x == 8)
							break;
						x++;
					}
				}
			}

			// =========Remove==========================================================================================================
			String remData = "Golf Course Pro|Roesner Woods are coming soon by Sitterle|Coming Soon</title>|is coming soon|sale coming soon|Estate Homes For Sale|real estate homes|Luxury Home Magazine|Luxury Builder|Now Selling!</title>|banner\"> 2 Move In Ready Homes|New Condos Online|\"menu-link \" >Move-In Ready</a></li>|Move-In Ready</a></li>|Move-In Ready</a></li>|alt=\"Move-In Ready\">";
			html = html.replaceAll(remData, "");
			featureHtml = featureHtml.replaceAll(remData, "");
			featureHtml = featureHtml.replace(" luxury low maintenance"	," luxury homes low maintenance");		
			 U.log("featureHtml::"+U.getSectionValue(featureHtml, "Hidden awa", "arklands at Th"));

			// ================================================community
			// type========================================================
//			 U.log(Util.matchAll(html + oldData + featureHtml, "[\\w\\s\\W]{10}62 years and older[\\w\\s\\W]{10}", 0));
			 
			 html = html.replaceAll("very essence of lake living", "");
			String communityType = U.getCommType(html + oldData + featureHtml.replaceAll("very essence of lake living|Close to outstanding facilities for golf and tennis|Towne Lake|Elongated", ""));
			System.out.println("Community type:::::" + communityType);
			// ==========================================================Property
			// Type================================================
			
			html = html.replaceAll("_Patio", "");
//			U.log(">>>>>>>"+Util.matchAll(html+ moveHtml + moveHomeHtml+ featureHtml, "[\\w\\s\\W]{50}custom-built home[\\w\\s\\W]{20}", 0));
			String proptype = U.getPropType((html.replace("CUSTOMf PLANS AVAILABLE!", "Custom Homes") + oldData+featureHtml.replace("HOA Dues</li>", "Farms HOA")
					+ moveHtml + moveHomeHtml).replaceAll(
							"used to live in Sitterle garden home|Lives in Garden Homes of Point|1; Garden Homes'|additional fees and/or Homeowner's Association dues.|>Luis Ochoa,|>looking at the Villas<|>Came to look at Villas|was looking for villas</option>",
							"")
					+ regPropType.replace("Luxury Garden Home Communities", "custom luxury,Garden Homes Communities"));
			
			// ==================================================D-Property
			// Type======================================================
			if (comUrl.contains("http://www.sitterlehomes.com/new-homes/san-antonio/blue-skies-of-texas/")) {
				combinedPlanHtmls = combinedPlanHtmls + "Ranch homes";
			}
			floorHtml = floorHtml.replaceAll("2 ST ", " 2 Story ");
			String dtype = U.getdCommType(communityName+((html + floorHtml + invenHtml + featureHtml +moveHomeHtml).replaceAll(" Ranch</option>|Rogers Ranch|-ranch-|Ranch'", "")+ 
					communityName + comUrl + combinedPlanHtmls).replaceAll("[C|c]*lear[W|w]*ater [R|r]*anch|[M|m]*ayfield [R|r]*anch|Rogers Ranch|rogers ranch|Kinder Ranch|kinder ranch", ""));
			//U.log(combinedPlanHtmls);
			// ==============================================Property
			// Status=========================================================
			html = html.replace("Move in Ready Homes Now Available", "");
			//
			html = html.replace("Move in Ready Homes Left", "");
			html = html.replace("ONLY 2 LUXURY PATIO HOMES REMAIN", "ONLY 2 HOMES REMAIN");
			html = html
					.replace("New GATED Garden Home Section Coming Soon","NEW GATED GARDEN HOME NEW SECTION COMING SOON")
					.replaceAll("title>Fulshear Homes Now Selling|<title>San Antonio New Homes Coming Soon|1 Move in Ready|TX are coming|TX new homes coming|In Ready|Now Available!<|Springs - CLOSE",
							"")
					.replace("2 Move  Homes Available Now", "");

			// U.log(html);
			featureHtml = featureHtml.replaceAll("san-antonio/?view=specs\" class=\"menu-link \" >Move-In Ready</a></li>", "");
			html = html.replaceAll("san-antonio/?view=specs\" class=\"menu-link \" >Move-In Ready</a></li>", "").replace("Grand Opening Ad", "");
			html = html.replace("menu-link \" >Coming Soon</a></li>", "");

			// U.log("::::::::::::::::::::::"+com.shatam.utils.Util.match(html, ".*?Move in
			// ready home.*?"));
			U.log(bannerSec);
			if(bannerSec != null) bannerSec = bannerSec.replace("Move in Ready Homes Now Available", "");
//		U.log("MMMMMMMMMMMMM "+Util.matchAll((bannerSec+html+featureHtml).replaceAll("-closeout/' />|\\(CLOSEOUT\\)' href|-san-saba-closeout|title='Belterra &#8211; The Cove at San Saba \\(CLOSEOUT\\)", ""),
//					".*Inventory Homes Left.*",0));
//			
			U.log("JJJ"+Util.matchAll(bannerSec +html+featureHtml,"limited opportunities remaining", 0));
			html = U.getNoHtml(html);
			
			String pstatus = U.getPropStatus(bannerSec+oldData +((html+featureHtml
					.replace("Grand Opening Ad</option", "").replaceAll("-closeout/' />|\\(CLOSEOUT\\)' href", "")
					.replaceAll("-san-saba-closeout|<h3 class=\"sans-heading xs-marg-bottom\">Only 6 Remaining Opportunities!</h3>|new garden homes coming soon|new homes coming soon in Willis Ranch.\"", ""))
					.replaceAll("Antonio New Homes Coming Soon at Willis|TX new homes coming soon|Terra West- COMING SOON!'|comingsoon\" class=\"menu-link \" >Coming Soon</a></li>|Oaks- Now", "")
					.replaceAll("link \" >Move-In|Homes Now Available!|have several lots", ""))
					.replace("Patio Homes Now Available", "")
					
					);
			U.log("propStatus ==>" + pstatus);
			
			// fetching move in ready statue from move in ready page
			pstatus = pstatus.replaceAll(", Quick Move-in|Quick Move-in", "").replace(", Quick Move-in Home", "").replaceAll("Quick Move-in Home,?", "");
			
			
//			pstatus = U.getPropStatus(pstatus);
			if (moveHtml != ALLOW_BLANK) {
				if (moveHtml.contains("Sorry, there are no current move-in ready homes available in this community")) {
					/*
					 * if(pstatus.length()<4) { pstatus="No Move-In Ready"; } else {
					 * pstatus=pstatus+",No Move-In Ready"; }
					 */
				} else {
					if (pstatus.length() < 4 && !pstatus.contains("Move")) {
						pstatus = "Move-In Ready";
					} else {
						pstatus = pstatus + ", Move-In Ready";
					}
				}
			}
			if(invenHtml.contains("/movein-banner.png\"")) {
				//pstatus=U.getPropStatus(pstatus+" Move-In Ready");
			}
			pstatus = pstatus.replace("Move In Ready Home, Move-In Ready", "Move-In Ready").replace("Move In Ready", "Move-In Ready");		
			pstatus = pstatus.replace("Now Open, Now Open", "Now Open");
			//
			if (comUrl.contains(
					"http://www.sitterlehomes.com/new-homes/new-homes-san-antonio-fronterra-at-westpointe/fronterra-at-westpointe/")) {
				minPrice = "$303,000";
				maxPrice = "$429,000";
				minSqft = "2054";
				maxSqft = "3409";
				communityType = "Gated Community,Master Planned";
				dtype = "Ranch,1 Story,2 Story";
				pstatus = "Move-In Ready";
			}
			
			if (communityName.endsWith("Garden Homes")||communityName.endsWith("Homes")) {
				communityName = communityName.replaceAll("- Garden Homes|Homes", "");
			}
			

			U.log("Property Type::::" + proptype);
			U.log("Property Status:::::" + pstatus);

			U.log("Property type::::::" + proptype);
			//
			if(comUrl.contains("https://sitterlehomes.com/communities/veranda-porch-series"))add[0]="2207 Fenn Dale Ct";
			pstatus=pstatus.replace("Final Opportunities Remain, Limited Opportunities Remain", "Final Opportunities Remain");
//=================================================================
			if (comUrl.contains("https://www.sitterlehomes.com/new-homes/new-homes-bulverde-at-settlers-ridge-at-kinder-ranch/settlers-ridge/")) pstatus = ALLOW_BLANK;
			if (comUrl.contains("https://www.sitterlehomes.com/new-homes/rancho-sienna-new-home-construction-georgetown-tx/rancho-sienna/") ||
					comUrl.contains("https://www.sitterlehomes.com/new-homes/new-homes-in-richmond-tx-the-lagos-at-aliana/the-lagos-at-aliana/")
					) pstatus = pstatus.replace("Closeout,", "");
			if (comUrl.contains("https://www.sitterlehomes.com/new-homes/new-homes-in-richmond-tx-lakes-of-bella-terra-west/lakes-of-bella-terra-west/")) pstatus = pstatus + ", Now Open";
			
			
			
			U.log(communityName+">>>>>");
			
			String counting=ALLOW_BLANK;
			String startDt=ALLOW_BLANK;
			String endDt=ALLOW_BLANK;
			
//			communityName=communityName.replace(" - ONE HOME REMAINING", "");
			if(pstatus.isEmpty()) pstatus = ALLOW_BLANK;
			data.addCommunity(communityName.replaceAll("- COMING SOON!", "").replace("Custom/BOYL", "Custom/boyl"), comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replaceAll("\\s*,\\s*", " "), add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
		}
		j++;

	}
	
	

	// private void addComingSoon() {
	// protected void addComingSoon() {
	// String communityName=U.getSectionValue(oldData, "<span
	// class=\"name\">","</span>");
	// U.log("community Name---->"+communityName);
	//
	// }
	// }

}