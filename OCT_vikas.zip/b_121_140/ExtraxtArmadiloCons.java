/*Modification Aditya.
 * Rakesh*/
package com.shatam.b_121_140;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtraxtArmadiloCons extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtraxtArmadiloCons();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/Armadillo Construction.csv", a.data()
				.printAll());
	}

	public ExtraxtArmadiloCons() throws Exception {

		super("Armadillo Construction", "http://www.armadillohomes.com/");
	}

	public void innerProcess() throws Exception {
		String url = "http://www.armadillohomes.com/findhome";
		String url1="http://www.armadillohomes.com/";
		
		String[] lists={"location/san-antonio","location/laredo","location/new-braunfels"};
		for(String l:lists)
		{
			String html = U.getHTML(url1+l);
			
		String section = U.getHtmlSection(html, "<ul class=\"community-column unstyled-list\">","<div class=\"map-box\" id=\"map1\">");
		// U.log(section);
		String values[] = U.getValues(section, "<li>", "</li>");
		int totalComm = values.length / 2;
		for (String itom : values) {
//	U.log(itom);
//				// if(i<2)
			String url2=U.getSectionValue(itom,"<a href=\"","\"");

				// if(inr==0||inr==totalComm||inr==totalComm+1||inr==values.length-1)
				addDetails(url2,itom);
				inr++;
				i++;
			}

		}
	}

	//TODO : Extract Communities Details here
	private void addDetails(String url,String item) throws Exception {
		//if(j==11)
		{
		String html = U.getHTML(url);

		// community name
		U.log(url+" jj");
		String header = U.getHtmlSection(html,"<header class=", "</header>");
		String footer=U.getHtmlSection(html,"<footer>","</footer>");
		// U.log(commSec);
		String commuName =U.getSectionValue(html, "<h2 class=\"page-title\">","</h2>");
		U.log("Community name: " + commuName +"result");
		String Status = ALLOW_BLANK;
		// Community Address

		
		String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String flag = "FALSE";
		String noteVar = U.getnote(html);
		String sectionAdd = U.getSectionValue(html, "<h5>Address:</h5>",
				"</div>");
		
		sectionAdd = U.getNoHtml(sectionAdd).trim();
		sectionAdd = sectionAdd.replaceAll("Tx\\.|Tx", "TX");
		U.log(sectionAdd);
		if(sectionAdd!=null){
			sectionAdd = sectionAdd.replaceAll(" Laredo TX", " Laredo, TX").replace("Dr. Laredo", "Dr, Laredo").replace("New Braunfels TX", "New Braunfels, TX");
			String [] temp = sectionAdd.split(",");
			if(temp.length==2 && sectionAdd.contains(", TX")){
				add[3] = Util.match(temp[1], "\\d{5}");
				add[2] = Util.match(temp[1], "\\w{2}");
				U.log("state : "+add[2]+"\tzip:"+add[3]);
				if(add[1]!=null){
					add[1] = U.getCity(temp[0], add[2]);
					add[0] = temp[0].replaceAll(add[1]+"$", "").trim();
					U.log("street: "+add[0]+"\tcity:"+add[1]);
				}
			}
			if(temp.length==3){
				add = U.getAddress(sectionAdd);
			}
		}
		
		//add = U.getAddress(sectionAdd);
		U.log("Address is : "+Arrays.toString(add));
		
		String latlngSec = U.getSectionValue(html, "var directionsTo = new Array(", ");");
		if(latlngSec!=null){
			if(latlngSec.contains(","))
				latlng = latlngSec.split(", ");
		}
		if (add[0]==ALLOW_BLANK&&latlng[0]==ALLOW_BLANK&&url.contains("http://www.armadillohomes.com/community/laredo/aquero")) {
			add[0]=ALLOW_BLANK;
			add[1]="Laredo";
			add[2]="TX";
			add[3]=ALLOW_BLANK;
			noteVar="Address And LatLon Taken From City And State";
		}
		U.log("latlng is : "+Arrays.toString(latlng));
		if (latlng[0] == ALLOW_BLANK  && add[1] != ALLOW_BLANK) {
			//add = U.getAddressGoogleApi(latlng);
			latlng=U.getlatlongGoogleApi(add);
			flag = "TRUE";
		}
		if (latlng[0] != ALLOW_BLANK  && add[0] == ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latlng);
			flag = "TRUE";
		}
		
		//-----------price--------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK, minSqfeet = ALLOW_BLANK, maxSqfeet = ALLOW_BLANK;
		String flohtml = "";
		// floorplans
		//if (html.contains("floorplans")) {
			String floLink = url + "/floorplan";
			String homefe = U.getHTML(url + "/featurelist/0")+U.getHTML(url + "/featurelist/45")+U.getHTML(url + "/featurelist/55");
			homefe=homefe.replaceAll("3/4","");
			flohtml = U.getHTML(floLink);
			U.log("floor");
			// String[] price = U.getPrices(flohtml+quicHtml, "\\$((\\d+,?)+)",
			// 1);
			String[] price = U.getPrices(flohtml+html+item,
					"Starting at \\$\\d+,\\d{3}|\\$\\d+,\\d+<|<td>\\$\\d+,\\d{3}</td>", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

			// String[] sqft =
			// U.getSqareFeet(flohtml+quicHtml,"SqFt:.[^\\d+]+\\d+", 0);
			String[] sqft = U.getSqareFeet(flohtml +html+item,
					"SqFt:.[^\\d+]+\\d+|\\d{4}</td>|Sq.Ft.</small>[\\n\\s]*<p>\\d{4}", 0);
			U.log("minsqft===" + sqft[0]);
			minSqfeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqfeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf :" + minSqfeet + " maxSqf:" + maxSqfeet);


		
		//U.log(U.getSectionValue(html, "", ""));
			homefe = homefe.replaceAll("elevation - craftsman, hill country, traditional, or mediterranean", "");
		String pType = U.getPropType(html+homefe);
		String status = ALLOW_BLANK;
		String statSec = html;
		String addSect = U.getSectionValue(html, "Contact Information",
				"<div class=\"height10px\"></div>");
		if (addSect != null)
			statSec = statSec.replace(addSect, "");
		String remove = "title=\"Quick Move-In\">|Park and Pool -coming soon|New HEB Coming Soon|<p>Coming Soon</p>|<div class=\"testim-content\">\\s+Coming soon\\s+<div class=\"control-box\">|<td> Coming Soon</td>|<div class=\"box_content\"> Coming Soon|line-height:15pt;\"> Coming Soon|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "").replace("close_out", "close out");
		status = U.getPropStatus(statSec.replace("close-out\">",""));
		if (!html.contains("<div class=\"quick-item-box\">")) {
			status=status.replaceAll("Quick Move-in Home[s]", "No Quick Move-in Homes");
		}

		
		//--------Community Type--------------
		html=html.replace("Golf &amp; Country Club", "Golf & Country Club");
		String communityType = U.getCommunityType(html);


/*		U.log("floor plan =="+url + "/floorplan");
		String flrpln2Html = U.getHTML(url + "/floorplan");
		if(flrpln2Html!=null)
		flrpln2Html = flrpln2Html.replace(":</span> <span style=\"font-weight: normal;\">", " ");
*/		// U.log(flrpln2Html);
		
		//-----------Derived Type----------------
		if(flohtml != null){
			String [] floorHomeSection = U.getValues(flohtml, "<div class=\"com-table-info\">", "<div class=\"com-img");
			String combinedFloorValue = null;
			for(String floorHomeSec : floorHomeSection){
				String floorValue = Util.match(floorHomeSec, "<div>\\s+<p>\\d{4}</p>\\s+<p>(\\d\\.\\d)</p>", 1);
				combinedFloorValue += " "+floorValue.replace(".0", " Story ");
				//U.log(floorValue);
			}
			flohtml += combinedFloorValue;
		}
		html=html.replaceAll("Floors</small>[\\n\\s]*<p>2.0", " 2 Story ").replaceAll("Floors</small>[\\n\\s]*<p>1.0", " 1 Story ");
		String dtype =  U.getdCommType((flohtml+html).replaceAll("ranch|Ranch", ""));
	
		
		
		if(data.communityUrlExists(url))
		{return;}
		
		
		commuName = commuName.replace("NOW OPEN!", "");
		commuName = commuName.replace("-Now Open!", "");
		
		data.addCommunity(commuName, url, communityType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
		data.addPropertyType(pType, dtype);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqfeet, maxSqfeet);
		data.addNotes(noteVar);

	}
		j++;
	}
		
}