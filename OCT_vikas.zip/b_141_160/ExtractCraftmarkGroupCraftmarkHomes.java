/** @author Paraag Humane
 *  @date 18/04/2013 
 */

package com.shatam.b_141_160;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractCraftmarkGroupCraftmarkHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	

	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractCraftmarkGroupCraftmarkHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Craftmark Homes.csv",
				a.data().printAll());
		// a.data().printAll();
	}

	public ExtractCraftmarkGroupCraftmarkHomes() throws Exception {

		super("Craftmark Homes",
				"https://www.craftmarkhomes.com");
		LOGGER = new CommunityLogger("Craftmark Homes");
	}

	public void innerProcess() throws Exception {
		//driver=new FirefoxDriver(U.getFirefoxBinary(),U.getFirefoxProfile());
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String html = U.getHtmlHeadlessFirefox("http://www.craftmarkhomes.com/locations/", driver).replace("Join our VIP List</a>", "View More</a>");
		// U.log(html);
		
		String latlongSec=U.getSectionValue(html, "var communityJsonString = [", "];");
//		if(latlongSec!=null) {
		
		String[] communitiesInfo = U.getValues(html, "<div class=\"py-4\">","<div class=\"hover-box\">");
		String comingSoonComm[] = U.getValues(html, "<div class=\"col-md-4 col-sm-6","Join our VIP List</h3>");
		String link = "",status="";
		 U.log(":::::"+communitiesInfo.length);
		 
		int totalComm = communitiesInfo.length / 2;
		for (String item : communitiesInfo) {
				
//			U.log(item);
			//String name = Util.match(item, "href=\"(.*?)\">(.*?)<", 2);
			String name = U.getSectionValue(item, "<h6 class=\"m-0 font-weight-bold\">","<");
			name=name.replaceAll(" condominiums\">| townhomes\">|singleFamily\">|comingsoon\">","");
			link = U.getSectionValue(item, "href=\"", "\"");
		U.log("====="+link+name);
		if((link+name).contains("Coming Soon")|| link==null)continue;
			if (!link.startsWith("http")) {
				link="http://www.craftmarkhomes.com"+link;
			}
//			U.log("SEC1   "+link);
			//
//			
			addDetails(link, name,latlongSec, item,driver);

		}
		for (String item : comingSoonComm) {
				
				
			//String name = Util.match(item, "href=\"(.*?)\">(.*?)<", 2);
			String name = U.getSectionValue(item, "comingsoon\">","<");
//			name=name.replaceAll(" condominiums\">| townhomes\">|singleFamily\">|comingsoon\">","");
			link = U.getSectionValue(item, "<a class=\"modalOpen\" href=\"", "\" target=\"_blank\">");
			//U.log(link+name);
			if(link==null ||link.contains("<") || link.contains("contact"))continue;
//			U.log(link+name);
//			U.log("SEC2   "+link);
			
			addDetails(link, name,latlongSec, item,driver);

		}
		
//		}
//		}

		try { driver.quit(); } catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String url, String communityName,String latlongSec	,String communityInfo, WebDriver driver) throws Exception {

		//if(i >= 18)
		{

		url=url.replace("http:", "https:");
		
		//TODO:
		if(url.contains("https://www.craftmarkhomes.com/communities/watershed/"))return;//does not contain data Apr22
		//====== Single Run =================================
		
//		if(!url.contains("/communities/darnestown-station"))return;  //Extra community
		U.log(U.getCache(url));
		String htm = "";
		//
//		if(!url.contains("https://www.craftmarkhomes.com/communities/cabin-branch/")) return;		
		if(url.contains("/quick-move-ins/home")){
			LOGGER.AddCommunityUrl(":::::::::Quick Home:::::::::"+url);
			return;
		}
		
		

		if(url.contains("https://www.craftmarkhomes.com/communities/wellspring/")) {
			LOGGER.AddCommunityUrl(url+"------>Return");
			return;
		
		}
		
		if(url.contains("communities/preserve-at-westfields/") || url.contains("/reserve-at-black-rock/")) {
			LOGGER.AddCommunityUrl(url+"------>community not present in region page");
			return;
		
		}
		
		
		if(url.contains("/hometypes.php"))
			url = url.replace("/hometypes.php", "");

		if (url.contains("/Coming Soon")||url.contains("?comingsoon")||url.contains("https://www.craftmarkhomes.com/communities/coming-soon/")){
			LOGGER.AddCommunityUrl(":::::::::ComingSoon:::::::::"+url);
			return;
		}
		
		if (url.contains("https://www.craftmarkhomes.com/#") || url.contains("https://www.craftmarkhomes.com#")){
			LOGGER.AddCommunityUrl(":::::::::ReDirected:::::::::"+url);
			return;
		}
	
		if (url.contains("/contact-us")){
			LOGGER.AddCommunityUrl(":::::::::CotactUs:::::::::"+url);
			return;
		}
		if(url.contains("comhttp")){
			LOGGER.AddCommunityUrl(":::::::::No Data:::::::::"+url);
			return;
		}
		if(data.communityUrlExists(url) || url.contains("primrose-hill-sf/") || url.contains("https://www.craftmarkhomes.com/quick-move-ins/home?id=42")){
			LOGGER.AddCommunityUrl("============repeated==========="+url);
			return;
		}
		LOGGER.AddCommunityUrl(url);
		htm = U.getHtml(url,driver);
		String html=htm;
		
		
		String rem1=U.getSectionValue(html, "<head>","<!-- Contact Today Modal -->");
		if(rem1!=null)
			html=html.replace(rem1,"");
		if(rem1!=null)
			htm=htm.replace(rem1,"");
		
		U.log(url+"===="+i);

		
		
		
		
		// -- Community Name -- //
		communityName = communityName.replace("®", "");
		U.log("communityName : " + communityName);
		String latlngData=ALLOW_BLANK;
		String [] latlongData=U.getValues(latlongSec, "{\"id\":", "\"Promotion\":");
		U.log("latlongData===="+latlongData.length);
		if(latlongData.length>0) {
			for(String latlngSec:latlongData) {
//				U.log("latlngSec===="+latlngSec);
			String name=U.getSectionValue(latlngSec, "\"name\":\"", "\",").replace("\\u00ae", "");
//			U.log("name===="+name);
			if(name.equals(communityName.trim())) {
				latlngData=latlngSec;
			}
			}
		}
		
		U.log("latlngData===="+latlngData);
		

		// -- Property Type --//
		String drop = U .getSectionValue(htm, "<html lang=\"en\">", " follow\">");
		if (drop != null) htm = htm.replace(drop, "");
		
		String remove1=U.getSectionValue(htm, "<h3>Navigation</h3>","</body>");
		if(remove1!=null) htm=htm.replace(remove1,"");
		
		remove1=U.getSectionValue(htm, "<head>","</head>");
		if(remove1!=null) htm=htm.replace(remove1,"");
	
		
		remove1=U.getSectionValue(html, "<div class=\"modal fade bottom\" id=\"savedItems\"","<!-- Saved Items Modal -->");
		if(remove1!=null) html=html.replace(remove1,"");
		
		// U.log("Property Type :" + propType);

		// -- Community Type --//
		htm=htm.replace("Gate Park", "").replaceAll("Elongated|waterfront fine dining |New Waterfront Townhomes, Coming in 2022 ", "").replace("near Chantilly National Golf &amp; Country Club", "");
		//htm=htm.replace("55+* Elevator Townhomes", "55+Elevator Townhomes").replaceAll("<div id=\"savedCommWrap.*", "<div class=\"hover-box\">");
		
//		String[]  remove=U.getValues(htm, "<div id=\"savedCommWrap", "<div class=\"hover-box\">");
//		
//		for(String r : remove)
//		{
//			htm=htm.replace(r, "");
//		}
		
//		U.log("==================mmmmmm"+Util.matchAll(htm, "[\\w\\s\\W]{300}55\\+Elevator Townhomes[\\w\\s\\W]{300}", 0));
//		htm=htm.replace("55+*", "55+");
		
//		U.log("==================mmmmmm"+Util.matchAll(htm, "[\\w\\s\\W]{300}Waterfront[\\w\\s\\W]{300}", 0));
		
		String commType = U.getCommunityType(htm);
		if(url.contains("https://www.craftmarkhomes.com/communities/cabin-branch/"))
		{
			commType=commType+", 55+ Community";
		}

		 U.log("Community Type :" + commType);

		// -- Address -- //
		String[] latLong = { ALLOW_BLANK, ALLOW_BLANK };
		String note = ALLOW_BLANK;
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		//String addSec = "";
		String addSec=ALLOW_BLANK;
		
		String addHtm = "";
		if (url.contains("index"))
			addHtm = U.getHTML(url.replaceAll("index", "directions"));
//		else {
//			U.log(url+ "/"	+ Util.match(htm,"<li><a href=\"(.*?)\">Directions</a></li>",1));
//			addHtm = U.getHTML(url+ "/"	+ Util.match(htm,"<li><a href=\"(.*?)\">Directions</a></li>", 1));
//		}

		if (addHtm == null)
			addHtm = ALLOW_BLANK;


		// U.log(addSec);
//		U.log("communityInfo:::"+communityInfo);
//		String[] addr = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "False";

		
//		communityInfo=communityInfo.replace("", "");
		
		
			addSec=U.getSectionValue(latlngData, "\"addresses\":[", "]");
		U.log("addSec==="+addSec);
		if(addSec!=null) {
			add[0]=U.getSectionValue(addSec, "\"street1\":\"", "\"");
			add[1]=U.getSectionValue(addSec, "\"city\":\"", "\"");
			add[2]=U.getSectionValue(addSec, "\"state\":\"", "\"");
			add[3]=U.getSectionValue(addSec, "\"zip\":\"", "\"");
		}
		
		if(url.contains("communities/cabin-branch"))
		{
//			U.log("},},},},},},},");
			addSec=U.getSectionValue(latlngData, "{\"label\":\"Selling from Crown Model Home\"", "},");
			if(addSec!=null) {
				add[0]=U.getSectionValue(addSec, "\"street1\":\"", "\"");
				add[1]=U.getSectionValue(addSec, "\"city\":\"", "\"");
				add[2]=U.getSectionValue(addSec, "\"state\":\"", "\"");
				add[3]=U.getSectionValue(addSec, "\"zip\":\"", "\"");
			}
		}
		
	
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"
				+ add[3]);

		//=================-- Latitude, Longitude -- =====================//
		String latLngSec = U.getSectionValue(htm, "class=\"commContact\">", "Click For Directions</a>");
		
//		U.log("latlngSec=="+latLngSec);
		if(latLngSec != null){
			if (latLngSec.contains("https://goo.gl/maps/")) {
				latLngSec = "/@"+U.getSectionValue(htm, "rel=\"noopener\" href=\"https://maps.google.com/maps?ll=", "&amp;")+"z/";
			}
			String latLngSec1 = U.getSectionValue(latLngSec, "/@", "z/");
			if(latLngSec1 == null)
				latLngSec1 = U.getSectionValue(latLngSec, "/@", ",17");
			
			if(latLngSec1!=null){
			latLong = latLngSec1.split(",");
			}
		}
		if(latLngSec==null) {
			latLngSec= U.getSectionValue(htm, "\"coords\":[", "]");
			if(latLngSec!=null) {
			latLngSec=latLngSec.replace("\"", "");
			latLong =latLngSec.split(",");
			}
		}
		note = U.getnote(htm.replaceAll("Take Advantage of Pre-Construction Prices", ""));
		if(latLong[0]==ALLOW_BLANK) {
			latLngSec=U.getSectionValue(html, "/maps?ll=", "&amp");
			if(latLngSec!= null)
			latLong = latLngSec.split(",");
		}
		U.log(latLong.length);
		
		
//		add[0]=add[0].trim();
//		U.log("=="+add[0].length()+"==");
		

		if(latlngData!=null) {
			String latlng=U.getSectionValue(latlngData, "\"coords\":[\"", "\"]").replace("\",\"", ", ");
//			U.log("latlng==="+latlng);
			if(latlng!=null) {
				latLong=latlng.split(",");
			}
		}
		
		U.log("latLong===="+Arrays.toString(latLong));

		
		
		if((add[0].trim().length()<2&&add[3].length()>3) &&(latLong.length<2 ||latLong[0]== ALLOW_BLANK )) {
			latLong = U.getlatlongGoogleApi(add);
			if (latLong==null) {
				latLong = U.getGoogleLatLngWithKey(add);
			}
			add=U.getAddressGoogleApi(latLong);
//			note="Address taken from city and state";
			geo = "TRUE";
			
		}
		if(add[0].length()==0 && latLong.length==2) {
			add=U.getAddressGoogleApi(latLong);
//			note="Address taken from city and state";
			geo = "TRUE";
		}
		if ((latLong.length<2 ||latLong[0]== ALLOW_BLANK ) && add[3].length()>3) {
			U.log("hello in here");
			latLong = U.getlatlongGoogleApi(add);
			if (latLong==null) {
				latLong = U.getGoogleLatLngWithKey(add);
			}
			geo = "TRUE";
		}
		U.log("LatLng==="+Arrays.toString(latLong));

		String priceSec = U.getSectionValue(htm, "<nav id=\"commNav\">",
				"</nav>");
		//U.log(priceSec);

		if (priceSec == null)
			priceSec = ALLOW_BLANK;
		
		String quickHtml = ALLOW_BLANK;
		String quickUrl = ALLOW_BLANK;
		//U.log(priceSec);
		priceSec=priceSec.replace("<li id=\"quickdeliveries-hide\">", "<li>");
		String[] quicks = U.getValues(priceSec, "<li>", "</a>");
	
		//U.log(priceSec);
		for(String quick : quicks){
			U.log("quick::"+quick);
			if(quick.contains("Quick Delivery")){
				quickUrl=U.getSectionValue(quick, "<a href=\"", "\"");
				U.log("quick Url::"+quickUrl);
				
				if(!quick.contains("http")){
					quickHtml=U.getHTML("http://www.craftmarkhomes.com"+quickUrl);
				}
			}
		}
		ArrayList<String> quickUrls=Util.matchAll(htm,"href=\"/quickdeliveries/details(.*?)\"",1);
		U.log(quickUrls.size());
		String newquickhtm="";
		for(String urlsq:quickUrls) {
			U.log(urlsq);
			urlsq=urlsq.replace("&amp;", "&");
			quickHtml=U.getHTML("https://www.craftmarkhomes.com/quickdeliveries/details"+urlsq);
			quickHtml=quickHtml.replaceAll("<meta(.*?)/>|<a href=\"(.*?)</a>", "");
			quickHtml=U.removeSectionValue(quickHtml, " <div id=\"footerDisclaimerPanel\"", "</html");
			newquickhtm += quickHtml;
		}
//		U.log(quickHtml);
	//--------------------------------------------------home html----------------------------
		String homeHtml1="";
		String[] homSec=U.getValues(html, "<div class=\"homeTypeListing\">","View More");
		
		if(homSec==null)
			homSec = U.getValues(html, "<div class=\"floorplan-list-v3\">", "<div>");
		
		for(String urlH:homSec)
		{
			urlH="http://www.craftmarkhomes.com"+U.getSectionValue(urlH, "<a href=\"","\"");
			U.log("urlH : "+urlH);
			homeHtml1=homeHtml1+U.getHtml(urlH, driver);
		}
	//----------------------------------------------------------------------------------	
		
		// -- Price -- //
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		htm = htm.replaceAll("s\\.", ",000");
//		minPrice = Util.match(htm, "From the (\\$\\d+,\\d+)", 1);
//		// if(minPrice.contains("mi"))
//		if (minPrice == null)
//			minPrice = Util.match(htm, "From (\\$\\d+,\\d+,\\d+)", 1);
//
//		if (minPrice == null)
//			minPrice = Util.match(communityInfo, "\\$\\d+,\\d+", 0);
//		if (minPrice == null)
//			minPrice = Util.match(communityInfo, "\\$\\d+s|\\$\\d+,\\d+,\\d+",
//					0);
//
//		if (minPrice == null)
//			minPrice = ALLOW_BLANK;

	//	minPrice = minPrice.replace("0s", "0,000");
		

		String rem = U.getSectionValue(htm, "<html", "<section id=\"community-details\">");
		if(rem!=null)
		htm = htm.replace(rem, "");
		
		// -- Square Feet -- //
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String homeHtml = U.getHtml(url + "/hometypes.php", driver);
		htm = U.removeComments(htm).replaceAll("<div>\n\\s*<div class=\"type\">Sq.Ft.</div>", "<div>Sq.Ft.</div>").replace("+", " ").replace("&nbsp;", " ").replace("the 20,000 sq. ft. of space", "");
		
		homeHtml = U.removeComments(homeHtml);
		if(quickHtml.length()>4){
			quickHtml = quickHtml.replace("&nbsp;", " ").replace("<p>4 Level", "four levels ");
		}
		htm=htm.replaceAll("A 40,000 sq\\. ft\\. retail|44,000 sq\\. ft\\. of retail space", "").replaceAll("</div>\n\\s*<div class=\"type\">Sq.Ft.</div>", "</div><div class=\"type\">Sq.Ft.</div>");//.replaceAll("<div>\n\\s*<div class=\"type\">Sq.Ft.</div>", "<div>Sq.Ft.</div>")
		homeHtml=homeHtml.replaceAll("44,000 sq. ft. of retail space|the 20,000 sq. ft. of space", "");
		String[] sqft = U
				.getSqareFeet(
						htm + homeHtml+homeHtml1 + quickHtml,
						"Up to \\d,\\d{3} sq. ft.|<li>\\d,\\d+-\\d,\\d+ sq. ft.</li>|\\d,\\d{3}  square feet|<div>\\d,\\d{3}</div><div class=\"type\">Sq.Ft.</div>|<div>\\d,\\d{3} </div>|Up to \\d{1},\\d{3} sq.ft.|<h3>\\d{3} SQ FT</h3>|\\d{1},\\d{3}\\s*sq. ft.|\\d*[,]*\\d{3} sq. ft.|\\d{4} sq. ft|\\d{4}&nbsp;sq.&nbsp;ft|\\d{4} sq ft|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d,\\d{3} - \\d,\\d{3}  sq. ft.|\\d,\\d{3} sq ft|\\d,\\d{3}? Sq. Ft.",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		if (maxPrice == ALLOW_BLANK) {
			
			
			
			String head = U.getSectionValue(htm, "<section id=\"community-details\">", "</section>");
			htm = htm.replace("starting at $1.2M", "starting at $1,200,000").replaceAll("<h6 class\\s*.*\\s*</h6", "").replace("00s", "00,000").replace("From $1.15M", "From $1,150,000");
//					.replace("$499s", "From $499,000");
			
           communityInfo = communityInfo.replace("starting at $1.2M", "starting at $1,200,000").replaceAll("from the&nbsp;$499s|From $499s", "From $499,000")
        		   .replace("from the Upper $1Ms", "from the Upper $1,000,000")
        		   .replace("From $1.1M", "From $1,100,000").replace("$1.2 Millions", "$1,200,000")
        		   .replace("0s", "0,000").replace("$1 million", "$1,000,000").replace("$1.195s", "$1,195,000");
           
           
//           U.log("===================="+Util.matchAll(html, "[\\w\\s\\W]{30}luxury single family estate homes[\\w\\s\\W]{30}", 0));
           
			String[] price = U.getPrices(htm.replace("s", ",000")  + homeHtml + quickHtml+communityInfo,
							"from the \\$\\d,\\d+,\\d+|starting at \\$\\d,\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|&#\\d+;\\d,\\d{3},\\d{3}|&#\\d+;\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{6}</p>",
							0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
		}
		//==============  Property Type ================
		String var = U.getSectionValue(htm, "var comm = [", "</script>");
		
		if(var==null) var ="";
		
		String Des=U.getSectionValue(html, "\"SubDescription\":\"", "\"");
		if(Des!=null)Des=Des.replaceAll("even the ability to add custom features|Custom Properties", "Custom homes plans").replace("Cabin Branch", "");
		
		
		
		htm = htm.replace("Mini-Split System (Loft)", "Mini-Split System ( a loft )").replace(var, "")
				.replaceAll("even the ability to add custom features|Custom Properties", "Custom homes")
				.replaceAll("Cabin Branch", "");
		html=html.replaceAll("even the ability to add custom features|Custom Properties", "Custom homes");
		
//		
		
		String propType = U.getPropType(U.getNoHtml(Des+htm.replaceAll("<h6 class=\"m-0 font-weight-normal\">\\s*.*\\s*</h6>|anticipation|Dining Room, Urban Condos, Townhomes, NW DC\"", ""))+quickHtml);
		
		U.log("//////////////   propType   "+propType);
		
		//============== Derived Property Type ================
		String featureHtml =ALLOW_BLANK;
/*		if(url.contains("fillmoreplacewestalexandria") || url.contains("libertybycraftmark"))featureHtml =ALLOW_BLANK;
		else featureHtml = U.getHTML(url+"/features.php");
*/		
		if(featureHtml==null)featureHtml = "";
		
		if(homeHtml1!=null)
			homeHtml1 = homeHtml1.replace("2-story foyer", " 2 Story ");
		
		remove1 = U.getSectionValue(html, "var comm =", "</script>");
		if(remove1 != null) html = html.replace(remove1, "");
	
		
		
		
	
	featureHtml=featureHtml.replaceAll("Colonial Base Board|Colonial Six-Panel|Colonial Roof Pitches |Colonial Panel Shutters","");
		htm=htm.replaceAll("Colonial Base Board|Colonial Six-Panel|Colonial Roof Pitches |Colonial Panel Shutters","");
		html =html.replaceAll("&nbsp;|City Colonial|Colonial Hwy|Colonial\\+Hwy|Branch|first floor|branch|2nd Floor or 2nd - 3rd Floor</li>", "");
		html=html.replaceAll("2-story foyer|2&nbsp;finished levels|Two Finished Levels"," 2 Story ")
				.replaceAll("3&nbsp;finished levels|Three Finished Levels|3 Finished Levels|<p>3-Level "," 3 Story")
				.replaceAll("4\n\\s*finished levels|4thlevel bonus suites","4th level bonus suites");
		
//		U.log("==================mmmmmm"+html);
		
		
		
		String dpType = U.getdCommType((html+featureHtml+homeHtml1+newquickhtm).replace("paces like a grand split-level foyer","paces like a grand split level foyer")
				.replaceAll("1st Floor|Rancho|split-level foyer|first floor|Ranchero|2nd floor", ""));
		dpType=dpType.replace("Colonial,","");
		
		U.log("//////////////   dpType   "+dpType);
//	U.log(">>>>>>>>>>>>"+Util.matchAll(html+featureHtml+homeHtml1+newquickhtm, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));
		// -- Community Status --//
		
		String commStatus = ALLOW_BLANK,status="";
		String statSec = U.getPageSource(url);
		String mainhtml=U.getHtml("http://www.craftmarkhomes.com/", driver);
		String statusValues[]=U.getValues(mainhtml,"<div class=\"carousel-caption\">", " </div>") ;
		for(String value:statusValues) {
			String namedumm=U.getSectionValue(value, "<h2>", "<");
			if(namedumm.toLowerCase().contains(communityName.toLowerCase())) {
				U.log(value);
				status = value;
			}
		}
		statSec = statSec.replaceAll("display: none;\"><span>SOLD", "");
		statSec=U.removeComments(statSec).replaceAll("School Coming Soon|Selling out of Long |be sold/distributed", "");
		//statSec = statSec.replaceAll("Selling By Appoint", "");
		statSec=statSec.replace("Final Phase of New Lots Releasing Soon", "Final Phase Releasing Soon").replace("Now Selling! Craftmark Homes is excited", "");
//		
//		U.log("-=-=-"+status);
		String varComm = U.getSectionValue(html, "var comm = [{", "});");
		if(varComm ==null)varComm = "";
//		
		communityInfo=communityInfo.replace("<div class=\"banner undefined\" style=\"display: none;\"><span>SOLD OUT</span>", "");
		statSec=statSec.replaceAll("Coming Soon &amp;|alt=\"Coming Soon\">|>Coming Soon</h6>|COMING SOON! Join", "");
		
//		U.log("mmmmmm"+Util.matchAll(statSec, "[\\w\\s\\W]{30}now selling[\\w\\s\\W]{30}", 0));
		
		commStatus = U.getPropStatus(communityInfo+ (statSec+status).replace(varComm, "")
				.replaceAll("Now Selling out of Clarksburg Village|Now Selling by Appointment|QUICK MOVE-IN HOMES|<h6 class=\"m-0 font-weight-normal\">\\s*.*\\s*</h6|font-weight-normal\">\n\\s*SOLD OUT|<p>SOLD OUT</p>|townhomes coming soon in Gaithersburg|ins\">QUICK MOVE|[q|Q]uick [m|M]ove|<h4>COMING SOON</h4>\\s+<h1 class=\"big-header long-header\">QUICK DELIVERIES</h1>|Quick Move-In Homes with Upgrades Included|Exciting New Development Coming Soon|MODEL GRAND OPENING| Decorated Model Coming Soon| Model Home, Quick Move-In!|Coming Soon &amp; Under Construction|Selling out of Long|New Model Now Grand Opening", ""));
		
	
		
		U.log("commStatus: "+commStatus);
		if(htm.contains("QUICK DELIVERIES</h1>")){
			
			if(commStatus==ALLOW_BLANK)
			{
				commStatus="Quick Deliveries Homes";
			}else
			{
				
				commStatus=commStatus+", Quick Deliveries Homes";
			}
		}
		
		add[0] = add[0]
				.toLowerCase()
				.replaceAll(
						"the intersection of |now selling from |selling from the|&amp;|selling from park ridge:|selling from clarksburg village:|selling from frontgate farms:",
						"");
		
		if (add[0] == ALLOW_BLANK && latLong[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if(add == null) add = U.getGoogleAddressWithKey(latLong);
			if(add == null) add = U.getAddressHereApi(latLong);
			geo = "TRUE";
		}
		if (add[0].contains("&amp;"))
			add[0] = add[0].replaceAll("&amp;", "");
		add[0] = add[0].replaceAll("\\s+", " ");

		
		
		U.log("lat :" + latLong[0] + "  Long :" + latLong[1] + "===" + geo);
//		if(url.contains("/communities/reserveatblackrock?ID")) {
//			add[1]="Montgomery Co.";
//			add[2]="MD";
//			latLong = U.getlatlongGoogleApi(add);
//			if(latLong == null) latLong = U.getlatlongHereApi(add);
//			add=U.getAddressGoogleApi(latLong);
//			if(add == null) add = U.getGoogleAddressWithKey(latLong);
//			if(add == null) add = U.getAddressHereApi(latLong);
//			geo="TRUE";
//			note ="Address taken from city and state";
//		}

		String quickSecStatus = U.getSectionValue(htm, "<div class=\"status\">", "</div>");
//		U.log(quickSecStatus);
		commStatus=commStatus.replaceAll("Move-in Ready,|, Move-in Ready|Move-in Ready", "");
		if((quickSecStatus!=null && quickSecStatus.contains("Move In Now!")) || htm.contains(" quick-move-ins-list-v2\">") || htm.contains(">QUICK MOVE-IN HOMES</h1>")
				|| htm.contains("<h3>Quick Move-In Homes</h3>")|| htm.contains("Quick Move-Ins</a>")) {
			if(commStatus==ALLOW_BLANK||commStatus.length()<3)
			{
				commStatus="Quick Move-Ins";
			}else
			{
				commStatus=commStatus+", Quick Move-Ins";
			}
		}
		propType=propType.replaceAll(",Villas|Townhouse,","");
		commStatus=commStatus.replaceAll("Quick Move-in Homes,", "");
		if(url.contains("http://www.craftmarkhomes.com/communities/clarksburgvillage-sf?ID=Clarksburg%20Village%20%28Singles%29")){
			
			commStatus="No Quick Deliveries Homes";
		}
		if(url.contains("http://www.craftmarkhomes.com/communities/clarksburgtowncenter?ID=Clarksburg Town Center"))
			commStatus = commStatus.replace(", Selling Out, Grand Opening Selling Out", ", Grand Opening Selling Out");
		if(url.contains("/primrose-th?ID=Primrose Hill (Towns)"))dpType="4 Story";
		if(url.contains("http://www.craftmarkhomes.com/georgiarow"))propType=propType+", Luxury Homes";
		if(url.contains("https://libertybycraftmark.com/"))commStatus =commStatus.replace("Now Selling, Quick Deliveries Homes", "Now Selling, Quick Move-in Homes");
		
		U.log(Arrays.toString(add));
		
		String quickSec = U.getSectionValue(html, "<section id=\"community-quick-move-ins\">", "</section>");
		if(quickSec==null)quickSec = "";
		
		if(quickSec.contains("We are currently building|We're busy building"))
			commStatus = commStatus.replaceAll("Quick Move-in,|, Quick Move-Ins|Quick Move-in", "");
		if(commStatus.length()<3)
			commStatus = ALLOW_BLANK;
			
		commStatus = commStatus.replace("Only 1 Opportunity Remains, Sold Out, 1 Opportunity Remains", "Only 1 Opportunity Remains, Sold Out");
		
		//======Image ========
		if(url.contains("https://www.craftmarkhomes.com/communities/georgia-row-at-walter-reed/"))
			commStatus += ", Final Closeout";
		
		if(url.contains("https://www.craftmarkhomes.com/communities/georgia-row-at-walter-reed/"))commStatus += ", Quick Move-Ins";
		if(url.contains("preserve-at-westfields/"))propType+=", Loft";
		
//		if(url.contains("https://www.craftmarkhomes.com/communities/clarksburg-town-center"))commStatus= "Sold Out";//Img
		if(html.contains("We're busy building!")) {
			commStatus=commStatus.replace(", Quick Move-Ins", "");
		}
		if(html.contains("We are currently building!")) {
			commStatus=commStatus.replace(", Quick Move-Ins", "");
		}
		communityName = communityName.trim().replace("?", "");
//		
		if(url.contains("communities/rainwater-run"))propType="Luxury Homes, Single Family, Estate-Style Homes";		if(url.contains("https://www.craftmarkhomes.com/communities/georgia-row-at-walter-reed/")) {
			
			
			if(propType.length()>1)
			{
				propType=propType+", Condominium";
			}
			else
				propType="Condominium";
			if(dpType.length()>1)
			{
				dpType=dpType+", Multi-Level";
			}
			else
				dpType="Multi-Level";
				
		}
		
		if(url.contains("homes.com/communities/crown/")) commStatus=commStatus+", Last Chance"; // from img
		if(url.contains("https://www.craftmarkhomes.com/communities/burnt-pine-estates/")) commStatus=commStatus+", Final Chance"; // from img 22 march dattaraj
		//quick move in formatting
		

		
		String quickSec1= U.getSectionValue(html, "<section id=\"community-quick-move-ins\"", "</section>");
		if(quickSec1!=null && quickSec1.contains("We're sold out!")) {
			commStatus =commStatus.replaceAll(", Quick Move-Ins|Quick Move-Ins,", "");
		}
		data.addCommunity(communityName.replace("�", "").replace("Alex�", "Alex"), url, commType);
		data.addAddress(add[0].replace(".", ""), add[1],add[2].trim().replace(" .", ""), add[3].trim());
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus.replace("Spring 2021 Delivery, ", "").replace("Ii", "II"));
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

	}
	i++;
//		}catch (Exception e) {}
	}
	
}