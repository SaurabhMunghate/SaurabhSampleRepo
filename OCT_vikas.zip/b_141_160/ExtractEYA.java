/**
 * @author Parag Humane 
 * @date 17/04/2012
 * 
 */
package com.shatam.b_141_160;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.regexp.recompile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEYA extends AbstractScrapper {
	int i=0;public int inr=0;
	static int j = 0;
	
	private static String baseUrl  = "https://www.eya.com/";
	static int duplicates=0;
	Connection conn;
	HashSet<String> community=new HashSet<String>();
	WebDriver driver = null;
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractEYA();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Neighborhoods of EYA.csv", a.data().printAll());
		U.log(duplicates);
		
	}

	public ExtractEYA() throws Exception {

		super("Neighborhoods of EYA", "https://www.eya.com");
		LOGGER = new CommunityLogger("Neighborhoods of EYA");
	}

	public void innerProcess() throws Exception 
	{
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String html = U.getHTML("https://www.eya.com/find-your-new-eya-home");
		//U.log(html);
//		String NowSellingSection = U.getSectionValue(html, "<p><strong>NOW SELLING", "</div>");//Status from Footer
//		NowSellingSection = NowSellingSection.replace(" <br>", " ");
//		//U.log(NowSellingSection);
		String nowSelling=U.getSectionValue(html, "var activeNeighborhoods = [", "var inactiveNeighborhoods ");
		String[] communitySections  = U.getValues(nowSelling, "{", "}");
		
		for(String comSec : communitySections){
//			U.log(comSec);
			String cUrl =U.getSectionValue(comSec, "<a href='", "\'");		
			String cName = U.getSectionValue(comSec,  "class='color--inherit'>", "</a>").replaceAll(" <br>|<br>|&nbsp;", " ");
			U.log(cName +" ----- "+cUrl);
			cName = cName.trim();	
			
//			try { 
				addDetailsNew(cUrl, cName, comSec);
//			} catch (Exception e) {}
			
			
		}
		
		//for Coming soon communities
//		html = U.getHTML("https://www.eya.com/new-homes-coming-soon");
		
		communitySections = U.getValues(html, " <a id=\"\" class=\"section--locationslist--item ", "<span class=\"btn btn--blue\">join the vip list</span>");
		
		if(communitySections!=null)
			U.log(communitySections.length);
		
		for(String comSec : communitySections){
//			U.log(comSec);
			String cUrl =U.getSectionValue(comSec, "style=\"margin-top:10px!important;\" href=\"", "\"");		
			String cName = U.getSectionValue(comSec,  "<h2 class=\"color--blue hover--color--orange hard--top\" style=\"margin-bottom:15px;\">", "<").replaceAll(" <br>|<br>|&nbsp;", " ");
			U.log(cName);
			cName = cName.trim();	
			try { addDetailsNew(cUrl, cName, comSec); } catch (Exception e) {}
			
			addDetailsNew(cUrl, cName, comSec);
		}
		
		LOGGER.DisposeLogger();
		
//		try{driver.quit();}catch(Exception e) {}
	}
	private void addDetailsNew(String url, String name , String info) throws Exception {
		
		String comUrl = url;
		if(!comUrl.contains("http"))comUrl = "https://www.eya.com"+comUrl;
		if(url.contains("https://townhomes.eya.com/rockville-md-tower-oaks-eya"))comUrl="https://www.eya.com/townhomes/rockville-md/tower-oaks";
		//try {
		//TODO ::
//		if(!comUrl.contains("https://www.eya.com/townhomes/washington-dc/riggs-park-place-fort-totten-metro")) return;

		
		U.log("cUrl:::"+comUrl);
		U.log(U.getCache(comUrl));
		String html = U.getHTML(comUrl);
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(html, comUrl);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		String	rmHtml1=U.getSectionValue(html, "<div id=\"promo-bar\" class=\"section section--promobar width--max overflow--hidden relative visuallyhidden\">", "Learn More</a>");
		
		if(rmHtml1!=null)
		html=html.replace(rmHtml1,"");
		
		String secHtml ="";
		String rmHtml = U.getSectionValue(html, "<h2>Latest News</h2>", "</htm");
		if(rmHtml==null)rmHtml=U.getSectionValue(html, " <h2>Latest <em>News</em></h2>", "</htm");
		if(rmHtml!=null)
		html=html.replace(rmHtml,"");
		
		
		if(data.communityUrlExists(comUrl)) {
			
			LOGGER.AddCommunityUrl("========= :Repeated: ============"+comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

//		String navSec = U.getSectionValue(html, "aria-label=\"Navigation Menu\">", "</div></span>");
		String navSec = U.getSectionValue(html, "aria-label=\"Navigation Menu\">", "</header>");
//		U.log("navSec == "+navSec);
		String contactHtml = null;
		if(navSec != null){
			String navUrls[] = U.getValues(navSec, "<a href=\"", "\"");
			for(String navUrl : navUrls){
				if(navUrl.contains("contact-us") || navUrl.contains("/tour")){
					U.log("contactUrl :"+navUrl);
					contactHtml = U.getHTML(navUrl);
				}
			}
		}
//		if(comUrl.contains("https://www.eya.com/townhomes/washington-dc/michigan-park")) contactHtml = null;
						
		if (comUrl.contains("https://www.eya.com/community-summary-westside-at-shady-grove")) {
			String homeSec = U.getSectionValue(html, "btn btn--white palm-btn--wide default\" href=\"",
					"\">go to neighborhood site</a>");
			if (homeSec != null) {
//				U.log("MMMMM " + homeSec);
				String html1 = U.getPageSource(homeSec); // U.getHTML(homeSec);
				// U.log(html1);
				String mhomeUrl = U.getSectionValue(html1, "main-navigation", "Homes &amp; Floorplans");
				String[] url1 = U.getValues(mhomeUrl, "<a href=\"", "\">");
				// U.log(url1[1]);
				for (String u : url1) {
					if (u != null && !u.contains("the-big-story")) {
						U.log("SSSS" + u);
						String newHome = U.getPageSource(u);
						// U.log(newHome);
						String[] newUrl = U.getValues(newHome, "class=\"available-to-move-in\">",
								"VIEW FLOORPLANS &amp; PHOTOS");

						for (String s : newUrl) {

							String surl = U.getSectionValue(s, "href=\"", "\">");
							U.log("Fllor Plan " + surl);
							String shtml = U.getPageSource(surl);
							secHtml += U.getNoHtml(shtml);
						}
					}
				}

			}
		}
		if (comUrl.contains("riggs-park-row-fort-totten-metro") || comUrl.contains("tower-oaks")) {
			String homeSec = U.getSectionValue(html, "<li class=\"hs-menu-item hs-menu-depth-2\" role=\"menuitem\"><a href=\"","\"");
			U.log("hello m here::"+homeSec);
			if (homeSec != null) {
//				U.log("MMMMM " + homeSec);
				String html1 = U.getPageSource(homeSec); // U.getHTML(homeSec);
				html1 = html1.replaceAll("Approximate Int. Sq. Ft.:\\s*</p>\\s*<p>\\s*", "Sq. Ft. ");
				secHtml += html1;
				// U.log(html1);
				String mhomeUrl = U.getSectionValue(html1, "<h1 class=\"hard--ends lighter\">", "<div id=\"hs_cos_wrapper_widget_");
				U.log("MMMMM " + mhomeUrl);
				String[] url1 = U.getValues(mhomeUrl, "href=\"", "\">");
				 U.log(url1.length);
				for (String u : url1) {
//					if (u != null && !u.contains("the-big-story")) {
						U.log("SSSS" + u);
						String newHome = U.getPageSource(u);
						secHtml += newHome;

						// U.log(newHome);
//						String[] newUrl = U.getValues(newHome, "class=\"available-to-move-in\">",
//								"See Floorplans &amp; Photos");
//
//						for (String s : newUrl) {
//
//							String surl = U.getSectionValue(s, "href=\"", "\">");
//							U.log("Fllor Plan " + surl);
//							String shtml = U.getPageSource(surl);
//							secHtml += U.getNoHtml(shtml);
//						}
//					}
				}

			}
		}
		
		if (comUrl.contains("https://www.eya.com/community-summary-montgomery-row")) {
			String homeSec = U.getSectionValue(html, "btn btn--white palm-btn--wide default\" href=\"",
					"\">Go to neighborhood site");
			if (homeSec != null) {
//				U.log("MMMMM " + homeSec);
				String html1 = U.getPageSource(homeSec); // U.getHTML(homeSec);
				// U.log(html1);
				String mhomeUrl = U.getSectionValue(html1, "main-navigation", "Homes &amp; Floorplans");
				String url1 = U.getSectionValue(mhomeUrl, "<a href=\"", "\">");
				// U.log(url1[1]);
			
					if (url1 != null && !url1.contains("the-big-story")) {
						U.log("SSSS" + url1);
						String newHome = U.getPageSource(url1);
						 //U.log(newHome);
						String[] newUrl = U.getValues(newHome, "<!-- here modal description start -->",
								"View Floorplans &amp; Photos");

						for (String s : newUrl) {

							String surl = U.getSectionValue(s, "href=\"", "\">");
							U.log("Fllor Plan " + surl);
							String shtml = U.getPageSource(surl);
							secHtml += U.getNoHtml(shtml);
						
					}
				}

			}
		}
		
		int floorCount=0;
		
		if (comUrl.contains("https://www.eya.com/community-summary-the-brownstones-at-chevy-chase-lake")) {
			String homeSec = U.getSectionValue(html, "btn btn--white palm-btn--wide palm-visuallyhidden\" href=\"",
					"\">");
			if (homeSec != null) {
	//			U.log("MMMMM " + homeSec);
				String html1 = U.getPageSource(homeSec); // U.getHTML(homeSec);
				// U.log(html1);
				String mhomeUrl = U.getSectionValue(html1, "hs-menu-children-wrapper", "Models &amp; Floor Plans");
				String[] url1 = U.getValues(mhomeUrl, "<a href=\"", "\">");
				// U.log(url1[1]);
				for (String u : url1) {
					if (u != null && !u.contains("the-big-story")) {
						u = u.replace("\" role=\"menuitem", "");;
						U.log("SSSS" +u);
						String newHome = U.getHtml(u,driver);
						 //U.log(newHome);
						String[] newUrl = U.getValues(newHome, "model-name",
								"See Floorplans &amp; Photos");

						for (String s : newUrl) {

							String surl = U.getSectionValue(s, "href=\"", "\">");
							U.log("Floor Plan " + surl);
							String shtml = U.getPageSource(surl);
							secHtml += U.getNoHtml(shtml);
							floorCount++;
						}
					}
				}

			}
		}
		
		
		
		if (comUrl.contains("https://www.eya.com/townhomes/rockville-md/tower-oaks")) {
			
			String floorHtml = U.getPageSource("https://www.eya.com/townhomes/rockville-md/tower-oaks/homes-floorplans");
			
			String floorUrls[] = U.getValues(floorHtml, "<a class=\"no--underline\" href=\"", "\"");

			for (String floorUrl : floorUrls) {
				U.log("Floor Plan " + floorUrl);
				if(floorUrl.contains("floorplans")) {
				String shtml = U.getPageSource(floorUrl);
				secHtml += U.getNoHtml(shtml);
				}
			}
		}
		
if (comUrl.contains("https://www.eya.com/townhomes/washington-dc/riggs-park-row-fort-totten-metro")) {
			
			String floorHtml = U.getPageSource("https://www.eya.com/townhomes/washington-dc/riggs-park-place-fort-totten-metro/homes-floorplans");
			
			String floorUrls[] = U.getValues(floorHtml, "<span class=\"btn btn--secondary\" href=\"", "\"");

			for (String floorUrl : floorUrls) {
				U.log("Floor Plan " + floorUrl);
				if(floorUrl.contains("floorplans")) {
				String shtml = U.getPageSource(floorUrl);
				secHtml += U.getNoHtml(shtml);
				}
			}
		}
		
		if (comUrl.contains("https://www.eya.com/townhomes/reston-va/"
				+ "")) {
			String floorHtml = U.getPageSource("https://www.eya.com/townhomes/reston-va/townhomes-at-reston-station-metro/models-floorplans"); // U.getHTML(homeSec);

			String floorUrls[] = U.getValues(floorHtml, "<span class=\"btn btn--secondary\" href=\"", "\"");

			for (String floorUrl : floorUrls) {
				U.log("Floor Plan " + floorUrl);
				String shtml = U.getPageSource(floorUrl);
				secHtml += U.getNoHtml(shtml);
			}
		}
		
		if (comUrl.contains("https://www.eya.com/community-summary-robinson-landing")) {
			String homeSec = U.getSectionValue(html, "btn btn--white palm-btn--wide default\" href=\"",
					"\">");
			if (homeSec != null) {
	//			U.log("MMMMM " + homeSec);
				String html1 = U.getPageSource(homeSec); // U.getHTML(homeSec);
				// U.log(html1);
				String mhomeUrl = U.getSectionValue(html1, "hs-menu-children-wrapper", "Find Your Condominium");
				String url1 = U.getSectionValue(mhomeUrl, "<a href=\"", "\"");
				// U.log(url1[1]);
				
					if (url1 != null && !url1.contains("the-big-story")) {
						
						U.log("SSSS" +url1);
						
						String newHome = U.getHTML(url1);
						String[] sec = U.getValues(newHome, "hard--ends uppercase bold font--14 result--item--building", "result--item--download visuallyhidden");
						 //U.log(newHome);
						for(String s : sec) {
							secHtml += U.getNoHtml(s);
						}
						
					}
				}

			}
		
		
		
		if(comUrl.contains("https://www.eya.com/townhomes/fairfax-va/sutton-heights")) {
			String floorHtml=U.getPageSource("https://www.eya.com/fairfax-va/sutton-heights/homes-floorplans");
//			if(floorHtml.contains("SEE FLOORPLANS &amp; PHOTOS")) {
//				floorHtml=floorHtml.replaceAll("SEE FLOORPLANS &amp; PHOTOS", "See Floorplans &amp; PHOTOS");
//			}
			
			String floorplans[] = U.getValues(floorHtml, "<a class=\"block no--underline", "<span class=\"btn btn--secondary");

			for (String floorPlan : floorplans) {
				String floorUrl=U.getSectionValue(floorPlan, "href=\"", "\">");
				U.log("Floor Plan " + floorUrl);
				String shtml = U.getPageSource(floorUrl);
//				if(shtml.contains("$875,000")||floorPlan.contains("$875,000")) {
//					U.log("FOUND");
//				}
				secHtml += U.getNoHtml(shtml)+floorPlan;
			}
		}
		
		
		
		
		if(comUrl.contains("https://www.eya.com/townhomes/falls-church-va/graham-park")) {
			String floorHtml=U.getPageSource("https://www.eya.com/townhomes/falls-church-va/graham-park/homes-floorplans");
//			if(floorHtml.contains("SEE FLOORPLANS &amp; PHOTOS")) {
//				floorHtml=floorHtml.replaceAll("SEE FLOORPLANS &amp; PHOTOS", "See Floorplans &amp; PHOTOS");
//			}
			
			String floorplans[] = U.getValues(floorHtml, "<a class=\"block no--underline", "<span class=\"btn btn--secondary");

			for (String floorPlan : floorplans) {
				String floorUrl=U.getSectionValue(floorPlan, "href=\"", "\">");
				U.log("Floor Plan " + floorUrl);
				String shtml = U.getPageSource(floorUrl);
//				if(shtml.contains("$875,000")||floorPlan.contains("$875,000")) {
//					U.log("FOUND");
//				}
				secHtml += U.getNoHtml(shtml)+floorPlan;
			}
		}
		
				//-----------com name------------
				String comName = name;
				U.log("cName::"+comName);
				//----Logger------------
				if(data.communityUrlExists(comUrl)){
					LOGGER.AddCommunityUrl(comUrl+"*******repeated*********");
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				//---------------
//				if(!comUrl.contains("https://www.eya.com/community-summary-grosvenor-heights"))return;
				String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
				String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String geo = "FALSE";
			
				if(contactHtml != null){
					String addSec = U.getSectionValue(contactHtml, "Sales Center", "Get Directions</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "Sales Center", "Learn More</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "Directions</h2>", "Get Directions</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "virtual appointments</em></h2>", "LEARN MORE</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "Robinson Landing<br>", "Get directions</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "above or contact us at", "Get Directions</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "to schedule an appointment.</p>", "LEARN MORE</a>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "Our onsite sales center is now open by appointment", "<br></span></p>");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "Our sales center has temporarily relocated to", "For more information");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "Our brand new onsite sales center is now open by appointment", "<img src");
					if(addSec == null)addSec = U.getSectionValue(contactHtml, "from 2-4 PM.</span></p>", "<span></span></p>");
					U.log("addSec =="+addSec);
					
					if(addSec != null){
						addSec = addSec.replace("<br>", ", ").replaceAll("T \\(<span>\\d+\\) \\d+-\\d+</span>", "").replaceAll("\\(\\d+\\) \\d+-\\d+|\\d+-\\d+-\\d+,?", "")
								.replaceAll("<.*?>|&nbsp;|!", "")
								.replaceAll(":\\s+Riggs Park Place", "")
								.replaceAll("We are now open for virtual appointments!|Open by Appointment Only|The sales center is currently open by appointment only.|Please reach out at the number below with any questions.|Our in-person sales center is coming soon.", "")
								.replace("Ln, Suite 215", "Ln Suite 215").replace(", ,", "")
								.replace(", Floor 1, Sales Gallery", "").replace("Alexandria VA 22314,", "Alexandria, VA 22314").trim().replaceAll("^,", "");
						add = U.getAddress(addSec);
						
						U.log("addSec =="+addSec);

						
						U.log("Add ::"+Arrays.toString(add));
					}
				}
			
				//----------Lat-Lng from Main Page---------------
				if(info.contains(" lat:")) {
				latLng[0]= U.getSectionValue(info, " lat:", ",").trim();
				latLng[1]= U.getSectionValue(info, " lng:", ",").trim();
				}else {
					if(url.contains("/washington-dc/michigan-park")) {
						String latlngSec = U.getSectionValue(html, "center: {", "zoom");
						latLng[0]= U.getSectionValue(latlngSec, " lat:", ",").trim();
						latLng[1]= U.getSectionValue(latlngSec, " lng:", "},").trim();
					
					}
				}
				if(latLng[0] != null && latLng[0].length()>10){
					latLng[0] = Util.match(latLng[0], "\\d{2}\\.\\d{2,}");
					latLng[1] = Util.match(latLng[1], "-\\d{2}\\.\\d{2,}");
				}
				U.log("lat lng is ::"+Arrays.toString(latLng));
				String addContactUrl=ALLOW_BLANK;
				if(add[0].length()<4 && latLng[0].length()>4) {
					U.log("yes");
					if(comUrl.endsWith("reston-station")) addContactUrl=comUrl.replace("eya-at-reston-station", "townhomes-at-reston-station-metro/contact-us");
					else addContactUrl=comUrl+"/contact-us";
					String contactUsAddSec=U.getHTML(addContactUrl);
					String addSection=U.getSectionValue(contactUsAddSec, "Sales center open by appointment</h2>", "br></span></p>");
					if(addSection!=null) {
						addSection=U.getSectionValue(addSection, "</p>", "<br><");
						if(addSection!=null) {
							U.log(addSection);
							addSection=addSection.replace("<br>", ", ").replace("<p><span>", "").trim();
							add=U.getAddress(addSection);
							U.log(Arrays.toString(add));
						}
					}if(addSection==null) {
						addSection=U.getSectionValue(contactUsAddSec, "<p>&nbsp;</p>\n<p><strong>", "</strong><br><br>");
						if(addSection!=null) {
							addSection=addSection.replace(".</strong><br><strong>", ", ");
							U.log(addSection);
							addSection=addSection.replace("<br>", ", ").replace("<p><span>", "").trim();
							add=U.getAddress(addSection);
							U.log(Arrays.toString(add));
						}
					}
					
				}
				
				
				if(add[0].length()<4 && latLng[0].length()>4){
					add= U.getAddressGoogleApi(latLng);
					if(add == null) add = U.getAddressHereApi(latLng);
					geo = "TRUE";
				}
				if(url.contains("/riggs-park-row-fort-totten-metro")) {
					String addSec = "325 Riggs Rd. NE,Washington, DC 20011";
					add= U.getAddress(addSec);
				}
				
//				if(url.contains("https://www.eya.com/townhomes/falls-church-va/graham-park")){
//					latLng[0] ="38.864978";
//					latLng[1] ="-77.198426";
//					add= U.getAddressGoogleApi(latLng);
//					if(add == null) add = U.getAddressHereApi(latLng);
//					geo = "TRUE";
//				}
				
				//----------Move-in---------------------
				int moveInCount = 0;
				String moveurl= U.getSectionValue(html, "<a class=\"btn btn--transparent--white palm-btn--wide\" href=\"", "\"");
				String moveHtml= ALLOW_BLANK;
				String moveIndata = null; 
				if(moveurl==null && !comUrl.contains("rockville-md-tower-oaks-eya")) {
					moveurl = "https://townhomes.eya.com/eya-move-in-ready-homes-for-sale#Community="+comUrl.replace("https://www.eya.com/community-summary-", "");
				}
				U.log("moveUrl ::"+moveurl);
				if(moveurl!=null){
					moveHtml =U.getHTML(moveurl);
				}
				if(moveHtml==null)moveHtml="";
				else {
					String values[]=U.getValues(moveHtml, "class=\"move-in-ready--result--item overflow--visible", "<script");
					for(String val:values) {
						
						String _comName = U.getSectionValue(val, "community-name visuallyhidden\">", "</span>");
						if(_comName != null && comName.trim().equalsIgnoreCase(_comName.trim()))
						//if(val.contains(comUrl.replace("https://www.eya.com/community-summary-", "")))
						{
							moveInCount++;
							moveIndata+=val;
						}
					}
							
				}
				
				if(url.contains("https://www.eya.com/townhomes/washington-dc/michigan-park")) {
					
					String floor = U.getHTML("https://www.eya.com/townhomes/washington-dc/michigan-park/homes-floorplans");
					String[] flooSec = U.getValues(floor, "block no--underline relative\" href=\"", "\"");
					
					for(String fUrl : flooSec) {
						U.log(fUrl);
						moveIndata += U.getSectionValue(U.getHTML(fUrl), "div class=\"body-container-wrapper\">", "<style>");
					}
				}

				if(url.contains("https://townhomes.eya.com/rockville-md-tower-oaks-eya")) {
					
					String floor = U.getHTML("https://www.eya.com/townhomes/rockville-md/tower-oaks/homes-floorplans");
					String[] flooSec = U.getValues(floor, "<span class=\"btn btn--orange btn--hover--default\" href=\"", "\"");
					
					for(String fUrl : flooSec) {
						U.log(fUrl);
						moveIndata += U.getSectionValue(U.getHTML(fUrl), "  <div class=\"motifoverlay motifoverlay--right \">", "<style>")+U.getSectionValue(U.getHTML(fUrl), "<div class=\"body-container-wrapper\">", " <div class=\"section section--divider ");
					}
				}
				if(url.contains("potomac-md/cabin-john-village")) {
					
					String floor = U.getHTML("https://www.eya.com/townhomes/potomac-md/cabin-john-village/models-floorplans");
					String[] flooSec = U.getValues(floor, "block no--underline relative\" href=\"", "\"");
					
					for(String fUrl : flooSec) {
						U.log(fUrl);
						moveIndata += U.getSectionValue(U.getHTML(fUrl), "div class=\"body-container-wrapper\">", "<style>");
					}
				}
					if(url.contains("robinsonlanding.com/")) {
						 secHtml = U.getHTML("https://www.robinsonlanding.com/townhomes")+U.getHtml("https://www.robinsonlanding.com/condominiums", driver);
					}
//				U.log(moveIndata);
				//=============== Price & Sqft====================
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				info =info.replace("0s</p>", "0,000");
				info = formatMillionPrices(info);
			//	U.log(info);
				//html = U.removeSectionValue(html, " function initMap() {", "</script");
//				if(moveHtml!=null) {
//					moveHtml=moveHtml.replaceAll("", "");
//				}
				//html = U.removeSectionValue(html, "<head>", "</head>");
				html = html.replace("$3.145M", "$3,145,000").replace("Totten Metro station. Priced from the mid-$500s", "")
						.replace("infowindow--price'>From the upper $600", "").replace("infowindow--price'>From the mid $600", "")
						.replace("Wiehle-Reston East Metro station. Priced from the upper $700s. Get details", "")
						.replace("infowindow--price'>From the $700", "")
						.replace("infowindow--price'>From the low $800", "")
						.replace("infowindow--price'>From $1,025,000", "")
						.replace("infowindow--price'>From the upper $700", "")
						.replace("low $800s", "low $800,000")
						.replaceAll("FROM\\s+$933,750", "FROM $933,750");
				secHtml = secHtml.replaceAll("From \\$(\\d).(\\d{2,4})M", " From \\$$1,$2,000");
				if(moveIndata != null) {
					moveIndata = moveIndata.replaceAll("<strong>TOWNHOMES FROM\\s+1,449,805", "TOWNHOMES FROM \\$1,449,805");
				}
				
				String[] price = U.getPrices((html.replace("$1.285 MILLION", "$1,285,000").replace("<p class='gm--infowindow--price'>From the $800,000", "").replaceAll("0s", "0,000").replace("rom $1.25 million</h4>", "rom $1,250,000</h4>").replace("$4.995M", "$4,995,000")
						+(moveIndata+info+secHtml).replace("$100,800", "")).replace("price'>From the $800", "").replace("from $1.2M", "from $1,200,000").replace("price'>From $1,12", ""),
						"from \\$\\d,\\d{3},\\d{3}|FROM \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
				
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				
			
//			U.log("mmmmmm"+Util.matchAll(html+moveIndata+info+secHtml, "[\\w\\s\\W]{100}from [\\w\\s\\W]{100}", 0));
//			U.log("mmmmmm"+Util.matchAll(secHtml, "[\\w\\s\\W]{100}\\$700[\\w\\s\\W]{100}", 0));
//			U.log("mmmmmm"+Util.matchAll(moveIndata, "[\\w\\s\\W]{100}700,00[\\w\\s\\W]{100}", 0));
			
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
			
				
				if(comUrl.contains("https://www.eya.com/community-summary-robinson-landing")) {
					moveIndata += U.getHTML("https://www.robinsonlanding.com/condominiums?__hstc=192088117.5e5056846ee4c431863b468b2f33e2c8.1582274642892.1582274642892.1582274642892.1&__hssc=192088117.10.1582274642893&__hsfp=3738122676")+U.getHTML("https://www.robinsonlanding.com/townhomes");
				}

			//	U.log(Util.matchAll(html+moveIndata+info+secHtml,"Approx\\. \\d,\\d{3}-\\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}|Sq. Ft.</p><p> \\d,\\d{3}-\\d,\\d{3}<|/p><p> Approx\\. \\d,\\d{3}</p>| \\d,\\d{3}|\\s*Approx. \\d,\\d{3}| \\d,\\d{3} sq ft| \\d,\\d{3} sq. ft.|Almost \\d,\\d{3} sq ft|Over \\d,\\d{3} sf|\\d,\\d+ sq ft |Interior sq ft: \\d,\\d+|sq footage: \\d{4}|Interior sq ft:</strong>\\s+\\d,\\d+|\\d,\\d+ SQ.FT</span></div>|APPROXIMATE SQ. FT. \\d,\\d+-\\d,\\d+|Interior sq footage: 2927|APPROXIMATE SQ. FT. \\d,\\d{3}|approximately \\d,\\d{3} sf|Approximately \\d,\\d{3} sf| Over \\d,\\d{3}|headergrey\">\\d,\\d{3}-\\d,\\d{3}</h4>|SQ. FT. \\d,\\d{3}",0));
				if(moveIndata!=null )moveIndata = moveIndata.replace(" Approx. 2,560-3,280", " Approx. 2,560-Approx. 3,280").replaceAll("alt=\"sq-ft-1\">\\s*</div>\\s*<h4 class=\"icon--label bold\"", "Approx. ");
				secHtml = secHtml.replaceAll("over 2,600 sq ft of interior", "");
				String sqFt[] = U.getSqareFeet((html+moveIndata+info+secHtml).replaceAll("5,000 homebuyers|7,000 homebuyers", ""), "Approx\\. \\d,\\d{3}-\\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} - \\d,\\d{3}|Sq. Ft.</p><p> \\d,\\d{3}-\\d,\\d{3}<|/p><p> Approx\\. \\d,\\d{3}</p>| \\d,\\d{3}|\\s*Approx. \\d,\\d{3}| \\d,\\d{3} sq ft| \\d,\\d{3} sq. ft.|Almost \\d,\\d{3} sq ft|Over \\d,\\d{3} sf|\\d,\\d+ sq ft |Interior sq ft: \\d,\\d+|sq footage: \\d{4}|Interior sq ft:</strong>\\s+\\d,\\d+|\\d,\\d+ SQ.FT</span></div>|APPROXIMATE SQ. FT. \\d,\\d+-\\d,\\d+|Interior sq footage: 2927|APPROXIMATE SQ. FT. \\d,\\d{3}|approximately \\d,\\d{3} sf|Approximately \\d,\\d{3} sf| Over \\d,\\d{3}|headergrey\">\\d,\\d{3}-\\d,\\d{3}</h4>|SQ. FT. \\d,\\d{3}", 0);
				minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
				maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
				U.log("MinSqft :" + minSqf + " MaxSqft:" + maxSqf);
//				U.log("mmmmmm"+Util.matchAll(html+moveIndata+info+secHtml, "[\\w\\s\\W]{100}700[\\w\\s\\W]{100}", 0));
				//==============CommunityType=============
				String neighborhoodhtm=U.getHTML(comUrl.replace("http://", "https://")+"neighborhood/");
//				if(neighborhoodhtm!=null)
//					neighborhoodhtm=neighborhoodhtm.replaceAll("Golf Course</h4>", "golfing");
				html=html.replace("Distinctive Waterfront Living", "waterfront community");
				
				String commType = U.getCommunityType(html+neighborhoodhtm+secHtml.replaceAll("Chase Lake community is made", ""));
//				U.log("mmmmmm"+Util.matchAll(html+neighborhoodhtm+secHtml, "[\\w\\s\\W]{100}waterfront[\\w\\s\\W]{100}", 0));
				//============ Property Status =============
				U.log("community type :: "+commType);
				String status= ALLOW_BLANK;
				//U.log("this is info::::::::"+info);
				info = info.replaceAll("<tr><td><b>coming soon|<tr><td><strong>coming soon", "");
						
				String remove= "infowindow--header'>Now Selling|header'>Now Selling</p>|move-in-ready-home\" role=\"menuitem\">Move In Ready Homes</a>|Move_in_now\">Move-in-Now</a></li>|Stanford model home grand opening:|home-grand-opening-january|the grand opening of our new Stanford model home |Harris Teeter \\(Coming Soon\\)<br />|coming 2013|Price:</strong> Coming Soon|homesites, coming soon|entertaining. Coming soon|<span class=\"red\"><strong>Now Selling|CENTER NOW OPEN|Under Construction|grand opening updates|NOW SELLING:|Price:</strong> Sold Out";
				String statHtml= html.replace("Over <strong>40 homes sold", "Over 40 homes sold")
						.replaceAll("Currently \\n*\\s*\\n*\\sSold Out", "Currently Sold Out")
						.replaceAll("move-in-ready-homes-for-|type == \"coming soon\"| target=\"_blank\">See Move-In Ready Homes| role=\"menuitem\">Move In Ready Homes|role=\"menuitem\">Now Selling|role=\"menuitem\">Coming Soon|offices are now|Private Tours Now ", "").toLowerCase().replaceAll(remove.toLowerCase(), "");
				String a=(statHtml+info)
						.replaceAll("<strong>ELEVATOR TOWNHOMES\\s+COMING SOON", "ELEVATOR TOWNHOMES COMING SOON")
						.replaceAll("sold out</a>|SOLD OUT</a>|now open by appointment|sales center is now open|now open for in-person appointments", "").replace("header'>Now Selling</p>", "");
				status= U.getPropStatus((a)
						.replaceAll("READY HOME AVAILABLE|Ready Home Available|ready home available", "Move In ready")
						.replace("header'>Now Selling</p>", "").replaceAll("</span></span> now selling|</span></span> Now Selling|'>Now Selling|mmediate move-ins|menuitem\">Now Selling|eya neighborhood coming soon|addmarkerwithtimeout\\(\"coming soon|</span>\\s*</span>\\s*coming soon|neighborhood coming soon to reston|sold-|sold-out.png|name=sold-o|content=\"new townhomes coming soon|line-2 block\">now ope|palm-hard--bottom\">move-in ready homes|infowindow--header'>Now Selling", "").replace("move-in-ready-home\" role=\"menuitem\">Move In Ready Homes</a>","").replace("role=\"menuitem\">Now Selling</a>", ""));
				
				if(html.contains("<em>Move-in-ready home available now!</em>")||html.contains("Move-in-ready home now available!")) {
						if(status == ALLOW_BLANK || status.length()<4)
							status = "Move In ready";
						else
							status+= ", Move In ready";
				
				}
				
				U.log("status: "+status);
//				U.log("mmmmmm"+Util.matchAll(a, "[\\w\\s\\W]{50}sold out[\\w\\s\\W]{50}", 0));
				
//				U.log("SSSSSSSSSSSSSSSSSSS"+Util.matchAll(statHtml+info, "[\\s\\w\\W]{30}Sold Out[\\s\\w\\W]{30}", 0));
				html = html.replace("Move_in_now\">Move-in-Now</a></li>", "");
				/*if(!comUrl.contains("rockville-md-tower-oaks-eya")&&(!status.contains("Move"))){
					if(status.length()<4){
						status ="Move-in Ready Homes";
						
					}
					else{
						status = status + ", Move-in Ready Homes";
					}
				}*/
				if(status.equals("Coming Soon, Elevator Townhomes Coming Soon")) {
					status = "Elevator Townhomes Coming Soon";
				}
				
				
				//============= Property Type ====================
				String featureHtml=ALLOW_BLANK;
				if(url.contains("westside_at_shady_grove/")) {
					featureHtml =U.getHTML("https://www.eya.com/westside-at-shady-grove/features/");
				}
				if(url.contains("grosvenor-heights/")) {
					featureHtml =U.getHTML("https://www.eya.com/grosvenor-heights/features/");
				}//http://www.eya.com/montgomery_row/
				if(url.contains("montgomery_row/")) {
					featureHtml =U.getHTML("https://www.eya.com/montgomery-row/features/");
//					featureHtml.replaceAll("", replacement)
				}
				if(url.contains("/cabin-john-village")) {
					featureHtml =U.getHTML("https://www.eya.com/townhomes/potomac-md/cabin-john-village/features");
				}
//				U.log(Util.match(html.replaceAll("/Cabin_|/cabin|content=\"Cabin|title>Cabin|Cabinetry|cabinetry",""), ".*Cabin.*"));
				html=html.replaceAll("Townhouse|townhouse|town house", "Townhomes").replace("apartment+homes", "").replaceAll("over 1,000 apartment homes ", "");
				String propType = U.getPropType((html+moveIndata+featureHtml+secHtml).replaceAll("CleanCondo|Cabin John|/Cabin_|/cabin|content=\"Cabin|title>Cabin|Cabinetry|cabinetry|branch |of the luxury features that|Standard for Single", ""));
				
				if(propType.contains("Townhouse") && (propType.contains("Townhome") || propType.contains("Townhomes"))){
					propType = propType.replaceAll("Townhouse,", "");
				}
				
				propType = propType.replace("Townhouse, Loft,Townhome,", "Loft,Townhome,").replace("Townhome,Townhouse", "Townhome");
				U.log("propType: "+propType);
				//U.log("mmmmmm"+Util.matchAll(html+moveIndata+featureHtml+secHtml, "[\\w\\s\\W]{30}flex[\\w\\s\\W]{30}", 0));
				//================= Derived Community Type =============
				//secHtml =secHtml.replace("4<sup>th</sup> level", "4 story");
				secHtml = secHtml.replace("Floor: 1", "1 story").replace("Floor: 2", "2 story").replace("Floor: 3", "3 story").replace("Floor: 4", "4 story").replace("Floor: 5", "5 story")
						.replaceAll("select all four levels", "");
				html = html.replace("Three-level homes offer optional loft level with terrace", "3 Stories homes offer optional loft level with terrace")
						.replaceAll("level", "");
				
				
				
				String dType = U.getdCommType(html+secHtml.replace("4<sup>th</sup> level", "4 story").replaceAll(" Three- and four-level", "3 story,4 story").replaceAll("level|Franchise|</strong></p></td><td><p>|branch|Branch", " ")+moveIndata);
				
				
				html= html.replaceAll("branch|Branch", "");
				/*if(comUrl.contains("https://www.eya.com/robinson-landing/")){
					status=status+", Move-in Ready Homes";
					
				}*/
				if(comUrl.contains("/westside_at_shady_grove/")){
					commType="Golf Course";
				}//http://www.eya.com/montgomery_row/
				if(comUrl.contains("http://www.eya.com/montgomery_row/")){
					commType="Country Club";
					minSqf = "2,600";
					status = "Currently Sold Out";
				}
				if(comUrl.contains("https://www.eya.com/community-summary-grosvenor-heights") || comUrl.contains("https://www.eya.com/community-summary-westside-at-shady-grove") || comUrl.contains("https://www.eya.com/community-summary-montgomery-row")){
					dType="4 Story";
				}
				
				if(comUrl.contains("/chevy-chase-lake/")) {
					commType="-";
				}

				status = status.replace("New Townhomes Coming Soon, Coming Soon", "New Townhomes Coming Soon");
				String notes = ALLOW_BLANK;
				
//				if(comUrl.contains("https://www.eya.com/townhomes/washington-dc/michigan-park"))minSqf="1420";
				if(comUrl.contains("https://www.eya.com/townhomes/washington-dc/riggs-park-row-fort-totten-metro"))maxSqf="2,100";
				
//				if(comUrl.contains("https://www.eya.com/townhomes/potomac-md/cabin-john-village"))minPrice="$1,285,000";
				
				if(comUrl.contains("https://www.eya.com/townhomes/falls-church-va/graham-park")) {
					status=status.replace("Coming Soon", "New releases coming soon");
				}
				
				
				if(comUrl.contains("https://www.robinsonlanding.com/")) {
					//status=status.replace("Move-in Ready", "Immediate move-ins");
					
				}
				
				
				notes=U.getnote(html);
				
				
				data.addCommunity(comName, comUrl,commType);
				data.addAddress(add[0], add[1], add[2].trim(), add[3]);
				data.addSquareFeet(minSqf, maxSqf);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(latLng[0].trim(), latLng[1], geo);
				data.addPropertyType(propType, dType);
				data.addPropertyStatus(status.replace("Now Selling, Now Selling", "Now Selling").replace("Move-in Ready Homes", "Move-in Ready"));
				data.addNotes(notes);
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);
				
		//}catch(Exception e){}

	}

	//TODO : Extract Communities details here
	private void addDetails(String url, String name , String info) throws Exception{
		//if(j==2)
		
		
		{
			
		String comUrl = url;
		if(!comUrl.contains("http"))comUrl = "https://www.eya.com"+comUrl;
		U.log("cUrl:::"+comUrl);
		
		
		String html = U.getHtml(comUrl, driver);
		
		//-----------com name------------
		String comName = name;
		U.log("cName::"+comName);
//		if(comUrl.contains("https://www.eya.com/montgomery_row/"))comUrl="https://www.eya.com/montgomery-row/";
		if(comName.contains("Chevy Chase Lake"))comName = "The Brownstones at Chevy Chase Lake";
		
		//----Logger------------
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"*******repeated*********");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		//---------------
		
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		//----------Lat-Lng from Main Page---------------
		String latLngSec = U.getSectionValue(info, "<td class=\"marker-location\">", "</td>");
		U.log(latLngSec);
		if(latLngSec!=null){
			latLng = latLngSec.split(", ");
		}
		U.log("lat lng is ::"+Arrays.toString(latLng));
		
		//--------Address from Community Page------------
		String addSec = U.getSectionValue(html, "<p><a class=\"phone\" href=\"tel:", "GET DIRECTIONS");
		if(addSec!=null) {
			addSec=addSec.replace("301-888-5846\" target=\"_blank\" rel=\"noopener\">301-888-5846</a><br>", "");
		}
		
		if(addSec!=null && !comName.contains("Chevy Chase Lake")){
			addSec = addSec.replaceAll("\\d+-\\d+-\\d+\">\\d+-\\d+-\\d+</a>\\s*</span><br />", "")
											.replace("<br />", ",").trim();
			U.log("addSec::::"+addSec);
		}
		
		if(comName.contains("Chevy Chase Lake")){
			addSec = U.getSectionValue(html, "Address: ", "; Phone:");
			
		}
		
		if(addSec==null) {
			addSec = U.getSectionValue(html, "<span class=\"address\">", "<a");
		}
		U.log("addSec::::"+addSec);
		if(addSec!=null){
			addSec=addSec.replace("<br>", ",");
			String[] tempAdd = addSec.split(",");
			add[0]=tempAdd[0].trim();
			add[1]=tempAdd[1].trim();
			add[2]=Util.match(tempAdd[2], "\\w+");
			add[3]=Util.match(tempAdd[2], "\\d+");
			if(add[3]==null) {
				add[3]=tempAdd[3];
			}
		}
		
		
		U.log("Address is "+Arrays.toString(add));
//		if(add[0].length()<4 && latLng[0].length()>4) {
//			U.log("yes");
//			String contactUsAddSec=U.getHTML(comUrl+"/contact-us");
//			String addSection=U.getSectionValue(contactUsAddSec, "Sales center open by appointment</h2>", "<br></span></p>");
//			if(addSection!=null) {
//				addSection=U.getSectionValue(addSection, "</p>", "<br>");
//				if(addSection!=null) {
//					addSection=addSection.replace("<br>", " ").replace("<p><span>", "").trim();
//					add=U.getAddress(addSection);
//					U.log(Arrays.toString(add));
//				}
//			}
//			
//		}
		
		if(add[0].length()<4 && latLng[0].length()>4){
			add= U.getAddressGoogleApi(latLng);
			geo = "TRUE";
		}
		
		
		html = html.replaceAll("0s", "0,000s");
		html = html.replace("$500<span", "$500,000");
		html = html.replaceAll("$1.1 Million", "$1,100,000").replace("$1.1 million", "$1,100,000");
		html = html.replace("Priced from the $600<span", "Priced from the $600,000<span");
		html=html.replace("starting at $1.5m", "starting at $1,500,000");
		html=html.replace("1.5 MILLION","1,500,000");
	//	U.log(html);
		
		//========== Model & Floor Sec ===============
		String modelflrSec = U.getSectionValue(html, "<div class=\"col span_3 links first\"", "</a>");
		if(modelflrSec == null)
			modelflrSec = U.getSectionValue(html, "<div class=\"col span_3 links\"", "</a>");
//		U.log(modelflrSec);
		String modelflrLink = "";
		if(modelflrSec!=null)
			modelflrLink = U.getSectionValue(modelflrSec, "<a href=\"", "\"");		
		String modelflrHtml = "";
		
		U.log("========"+baseUrl+modelflrLink+"==");		
		
		if(!modelflrLink.startsWith("http"))
			modelflrHtml = U.getHTML(baseUrl+modelflrLink);
		else
			modelflrHtml = U.getHtmlHeadlessFirefox(modelflrLink,driver);
		
		String allModelFloorData = ALLOW_BLANK;
		
		if(modelflrHtml.length()>4){
//			ArrayList<String> eachModelUrls = Util.matchAll(modelflrHtml, "<div class=\"available-to-move-in\">\\s+<a href=\"(.*?)\">VIEW FLOORPLANS & PHOTOS</a>",1);
			String [] eachModelUrlSec = U.getValues(modelflrHtml, "<div class=\"available-to-move-in\">", "</div>");
			U.log("model home =="+eachModelUrlSec.length);
			for(String eachModelUrl : eachModelUrlSec){
				eachModelUrl = U.getSectionValue(eachModelUrl, "<a href=\"", "\"");
				U.log("eachModelUrl : "+eachModelUrl);
				allModelFloorData += U.getPageSource(eachModelUrl.replace("http:", "https:"));
			}
		}
		allModelFloorData = allModelFloorData.replaceAll("\\*</p>\\s*</div>\\s*<span class=\"circle_text margin_left_15\">", " ");
		
		
		
		//------------Move Ready data-----------
		
		String fHtml=ALLOW_BLANK;
		if(comUrl.contains("/chevy-chase-lake/"))
		{
			fHtml=U.getHtml("https://townhomes.eya.com/chevy-chase-lake/models-and-floorplans", driver);
			//U.log(fHtml);

		}
		if(comUrl.contains("potomac-md/cabin-john-village"))
		{
			fHtml=U.getHtml("https://www.eya.com/townhomes/potomac-md/cabin-john-village/models-floorplans", driver);
			//U.log(fHtml);

		}
		//U.log("moveInofo==="+moveInofo);
		if (comUrl.contains("/robinson-landing/")) {
			fHtml=U.getPageSource("https://www.robinsonlanding.com/condominiums");//http://robinsonlanding.eya.com/condominiums
			fHtml+=U.getPageSource("https://www.robinsonlanding.com/townhomes");//http://robinsonlanding.eya.com/townhomes
			//U.log(fHtml);
		}
		
		
		String moveInofo=ALLOW_BLANK;
		int moveInHomeCnt = 0;
		String moveInHomeUrlSec = U.getSectionValue(html, "Floorplans</a></li>", "</a></li>");
		if(moveInHomeUrlSec != null && (moveInHomeUrlSec.contains("Move-In") || moveInHomeUrlSec.contains("Move-in"))){
			String moveInUrl = U.getSectionValue(moveInHomeUrlSec, "<a href=\"", "\"");
			U.log("moveINURL==="+moveInUrl);
			String moveInHomeHtml = U.getHtmlHeadlessFirefox(moveInUrl.replace("http:", "https:"), driver);
			String [] moveInHomeSection = U.getValues(moveInHomeHtml, "<h2 class=\"hard--ends\">", "Contact Sales</a>");
			U.log("len =="+moveInHomeSection.length);
			String tempName = comName;
			tempName = tempName.replace("Westside at ", "");
			for(String moveInHomeSec  : moveInHomeSection){
//				U.log("=="+moveInHomeSec);
				if(moveInHomeSec.contains(tempName.trim())){
					moveInofo += moveInHomeSec;
					moveInHomeCnt++;
				}
			}
		}else if (comUrl.contains("http://townhomes.eya.com/chevy-chase-lake/")) {
			String moveInHtml=U.getHtmlHeadlessFirefox("https://townhomes.eya.com/eya-move-in-ready-homes-for-sale#Community=chevy-chase-lake", driver);
			String moveInHomeSec[]=U.getValues(moveInHtml, "<tbody>", "</tbody>");
			for (String moveIn : moveInHomeSec) {
				if (moveIn.contains(comName)) {
					moveInHomeCnt++;
				}
			}
		}

		
		U.log("moveInCnt=="+moveInHomeCnt);
	
		
		
		//=============== Price ====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		html = html.replace("from $1.1 million", "From $1,100,000").replace("more than 7,000 homebuyers", "");
		String[] price = U.getPrices(html.replace("price'>From the low $800", "")+modelflrHtml+moveInofo+fHtml,"to \\$\\d,\\d{3},\\d{3}|From \\$\\d,\\d{3},\\d{3}|FROM \\$\\d1,\\d+,\\d+|From \\$\\d+,\\d+|Price: From \\$\\d,\\d+,\\d+|Priced from the \\$\\d+,\\d+|\\$\\d,\\d{3},\\d{3}|From \\$(\\d+,\\d+)|\\$(\\d+,\\d+)s|</strong> \\$(\\d+,\\d+)|\\$\\d+,\\d+</strong>|Price: \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		if(comUrl.contains("https://www.eya.com/community-summary-robinson-landing")) maxPrice = "$4,995,000";
		
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		
		String sqFt[] = U.getSqareFeet(modelflrHtml+moveInofo+fHtml+allModelFloorData, ">~ \\d,\\d{3} Sq. Ft.</span>|\\d,\\d+ sq ft |Interior sq ft: \\d,\\d+|sq footage: \\d{4}|Interior sq ft:</strong>\\s+\\d,\\d+|\\d,\\d+ SQ.FT</span></div>|APPROXIMATE SQ. FT. \\d,\\d+-\\d,\\d+|Interior sq footage: 2927|APPROXIMATE SQ. FT. \\d,\\d{3}"
				+"|<p>\\s+(<span style=\"color: #000000;\">\\s+)?\\d,\\d{3}\\*(</span>\\s+)?\\s+</p>\\s+</div>\\s+<span class=\"circle_text margin_left_15\">\\s+SQ.FT\\s+</span>|strong>Interior sq footage</strong>: \\d{4}", 0);
		minSqf = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqf = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("MinSqft :" + minSqf + " MaxSqft:" + maxSqf);

		
		//==============CommunityType=============
		String neighborhoodhtm=U.getHTML(comUrl.replace("http://", "https://")+"/neighborhood/");
//		if(neighborhoodhtm!=null)
//			neighborhoodhtm=neighborhoodhtm.replaceAll("Golf Course</h4>", "golfing");
		String commType = U.getCommunityType(html);
		
		//
		
		//============ Property Status =============

		String status= ALLOW_BLANK;
		U.log(info);
		info = info.replaceAll("<tr><td><b>coming soon|<tr><td><strong>coming soon", "");
				
		String remove= "VIEW MOVE-IN READY HOMES|Move_in_now\">Move-in-Now</a></li>|Stanford model home grand opening:|home-grand-opening-january|the grand opening of our new Stanford model home |Harris Teeter \\(Coming Soon\\)<br />|coming 2013|Price:</strong> Coming Soon|homesites, coming soon|entertaining. Coming soon|<span class=\"red\"><strong>Now Selling|CENTER NOW OPEN|Under Construction|grand opening updates|NOW SELLING:|Price:</strong> Sold Out";
		String statHtml= html.toLowerCase().replaceAll(remove.toLowerCase(), "");
		
		
		status= U.getPropStatus((statHtml+info).replaceAll("Ready Home Available|READY HOME AVAILABLE|ready home available", "Move In ready"));
		
		U.log("status: "+status);
		
		//U.log("mmmmmm"+Util.matchAll(statHtml+info, "[\\w\\s\\W]{60}sold out[\\w\\s\\W]{60}", 0));
		
		
		html = html.replace("Move_in_now\">Move-in-Now</a></li>", "");
		if(moveInHomeCnt > 0&&(!status.contains("Move-in Ready Homes"))){
			if(status==ALLOW_BLANK){
				status ="Move-in Ready Homes";
			}
			else{
				
				status = status + ", Move-in Ready Homes";
			}
		}
		
		//Move-in Ready Homes, Now Selling, Move In Ready

		//============= Property Type ====================
		String featureHtml=ALLOW_BLANK;
		if(url.contains("westside_at_shady_grove/")) {
			featureHtml =U.getHTML("https://www.eya.com/westside-at-shady-grove/features/");
		}
		if(url.contains("grosvenor-heights/")) {
			featureHtml =U.getHTML("https://www.eya.com/grosvenor-heights/features/");
		}//http://www.eya.com/montgomery_row/
		if(url.contains("montgomery_row/")) {
			featureHtml =U.getHTML("https://www.eya.com/montgomery-row/features/");
//			featureHtml.replaceAll("", replacement)
		}
//		U.log(featureHtml);
		html=html.replaceAll("Townhouse|townhouse|town house", "Townhomes");
		String propType = U.getPropType((html+modelflrHtml+allModelFloorData+featureHtml).replaceAll("branch |Standard for Single", ""));
		
		
		if(propType.contains("Townhouse") && (propType.contains("Townhome") || propType.contains("Townhomes"))){
			propType = propType.replaceAll("Townhouse,", "");
		}
		propType = propType.replace("Townhouse, Loft,Townhome,", "Loft,Townhome,").replace("Townhome,Townhouse", "Townhome");
		//================= Derived Community Type =============
		String dType = U.getdCommType(html.replaceAll(" Three- and four-level", "3 story,4 story").replaceAll("Franchise|</strong></p></td><td><p>|branch|Branch", " ")+allModelFloorData.replaceAll("branch|Branch", ""));
		
		
		html= html.replaceAll("branch|Branch", "");
		if(comUrl.contains("https://www.eya.com/robinson-landing/")){
			status=status+", Move-in Ready Homes";
			dType="4 Story";
		}
		if(comUrl.contains("/westside_at_shady_grove/")){
			commType="Golf Course";
		}//http://www.eya.com/montgomery_row/
		if(comUrl.contains("http://www.eya.com/montgomery_row/")){
			commType="Country Club";
			minSqf = "2,600";
			status = "Currently Sold Out";
		}
		if(comUrl.contains("https://www.eya.com/townhomes/rockville-md/tower-oaks"))maxSqf="3,280";
		
		String note=ALLOW_BLANK;
		
		
		//synchronized (data) {
		data.addCommunity(comName, comUrl,commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1], geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addNotes(note);
	//	}
		}j++;
	}

	//Format million price
	public static String formatMillionPrices(String html){
//		html="'>From $1.4 m";
		html=html.replaceAll("Million|million", "m");
		Matcher millionPrice = Pattern.compile("\\$\\d\\.(\\d*) m",Pattern.CASE_INSENSITIVE).matcher(html);
		String zeroString="";
		int i;
		while(millionPrice.find()){
			int count=millionPrice.group(1).length()+1;
			for(i=0;i<=3-count;i++) {
				zeroString+=0;
			}
			String floorMatch = millionPrice.group().replace(" m", zeroString+",000").replace(".", ",");  //$1.3 M //$1.32 M //$1.234 M
			html= html.replace(millionPrice.group(), floorMatch);
			}//end millionPrice
//		U.log(html);
		return html;
	}
	
	public static String getUnits(String html, String comUrl) throws IOException {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK; String restonData = ALLOW_BLANK; 
		int totalCount = 0;
		
		if(comUrl.contains("/townhomes/reston-va/eya-at-reston-station")) {
			
			restonData = U.getHTML("https://www.eya.com/townhomes/reston-va/townhomes-at-reston-station-metro/site-plan");
		}
		
		if(html.contains("<iframe id=\"f360_interactivesitemap") ||
				restonData.contains("<iframe id=\"f360_interactivesitemap")) {
			
			String frameSec = U.getSectionValue(html, "<iframe id=\"f360_interactivesitemap", "</iframe>");
			if(frameSec == null) frameSec = U.getSectionValue(restonData, "<iframe id=\"f360_interactivesitemap", "</iframe>");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "src=\"", "\"") + ">>";  //appending to get section
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.contains("propertyID=")) {
					propertyID = U.getSectionValue(frameUrl, "propertyID=",">>");
					U.log("propertyID: "+propertyID);
					
					mapLink = "https://apps.focus360.com/focus360API/assets/"+ propertyID +"/SingleFamilySiteMaps/interactive_site_map.svg";
					U.log("mapLink: "+mapLink);
					
					mapData = U.getPageSource(mapLink);
					
//					if(mapData.contains("<g id=\"lot_")) {
//						
//						String[] lots = U.getValues(mapData, "<g id=\"lot_", "\"");
//						U.log("lots: "+lots.length);
//						
//						totalCount = totalCount + lots.length;
//					}
//					
//					totalUnits = String.valueOf(totalCount);
					
					if(mapData.contains("<g id=\"lotNumber_")) {
						
						ArrayList<String> pins = Util.matchAll(mapData, "<g id=\"lotNumber_", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}
					
					if(mapData.contains("class=\"lotNumbers")) {
						
						ArrayList<String> lots = Util.matchAll(mapData, "class=\"lotNumbers", 0);
						U.log("Count Lots: "+lots.size());
						totalUnits = String.valueOf(lots.size());
					}
					
				}
			}
		}
		
		
		return totalUnits;
		
	}
	
	
}