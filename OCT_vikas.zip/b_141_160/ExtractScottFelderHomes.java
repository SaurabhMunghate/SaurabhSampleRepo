/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_141_160;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.By;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractScottFelderHomes extends AbstractScrapper{

	CommunityLogger LOGGER;
	static int j=0;
	static int k=0;
	WebDriver driver = null;
	private static final String builderUrl = "https://www.scottfelderhomes.com";
	public ExtractScottFelderHomes()throws Exception {
		super("Scott Felder Homes","https://www.scottfelderhomes.com/");
		
		LOGGER=new CommunityLogger("Scott Felder Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractScottFelderHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Scott Felder Homes.csv", a.data().printAll());

		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	ArrayList<String> lists=new ArrayList();
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		driver = new ChromeDriver();
		
		String mainHtml=getHtml("https://www.scottfelderhomes.com/communities/",driver);
		//U.log(mainHtml);
//		String comSec=U.getSectionValue(mainHtml,"<li class=\"click-nav\">","<li class=\"sub-nav\">");
		String[] comSec=U.getValues(mainHtml,"<div class=\"card CommunityCard\"","</a></div></div>");
		
		U.log("Total :"+comSec.length);
		for(String sec:comSec) {
			String url= U.getSectionValue(sec, "<a class=\"\" href=\"","\"");
			//U.log(url);
//			try {  } catch (Exception e) {}
			addDetail("https://www.scottfelderhomes.com"+url,sec);
			
		}

		LOGGER.DisposeLogger();
		driver.quit();
		
	}

	//TODO :
	private void addDetail(String url,String comsec) throws Exception {
		
//	if(j >=19)
//		if(j >23)
	{
		String comUrl=url;

//		U.log("commUrl-->"+comsec);

//		if(!comUrl.contains("https://www.scottfelderhomes.com/communities/austin-area/kyle/anthem")) return;
	
		U.log("\n"+j	+"=="+comUrl);
		
		
		U.log(U.getCache(comUrl));
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------>Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

		
		String html= getHtml(comUrl,driver);
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(html, comUrl, driver);
		U.log("Total Units : "+units);
		if(units.trim().equals("0")) {
			units=ALLOW_BLANK;
		}
		// ---------------------------------------------------------
		
		String rem=U.getSectionValue(html, "><script>window.__PRELOADED_STATE__","</htm");
		if(rem!=null)
		html=html.replace(rem,"");
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(html, "<h1", "</h1>");
		if(communityName!=null) {
		communityName=communityName.replace("&#8217;","");
		communityName=communityName.replace(",", "").replace("-","");
		communityName=communityName.replace("!", "").replaceAll("(Now\\s?)?Pre(-)?Selling(!)?|(Pre\\s?)?Grand Opening|Coming Soon|Final (Opportunities|Opportunity)?| Model Now Open", "");
		communityName=communityName.replaceAll("datareactid=\"121\">|datareactid=\"\\d+\">", "");
		}
		if(comUrl.contains("https://www.scottfelderhomes.com/communities/austin-area/dripping-springs/caliterra")) {
			communityName="Caliterra";
		}
		U.log("community Name---->"+communityName);
		communityName =  communityName.replaceAll("Cottages$", "");
//============================================note====================================================================
		String note=U.getnote(html);		
		
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html, "Community Office Address:","</strong>");
		U.log(addSec);
		if(addSec!=null)
			addSec=addSec.replaceAll("Coming Late 2017!|<strong>Please Call for Appointment|Appointment Only|Coming Summer of 2017!|Opening 2017!|Please call for an appointment, ","").replace("(512) 308-6826", "");
		if(addSec!=null && addSec.length()>10)
		{
			U.log(addSec);
			addSec=addSec.replaceAll("<strong>|Pre-Selling from:","").replace("415 San Donato Drive,", "415 San Donato Drive, ,");
			if(addSec.contains(","))
			{
			add=U.getAddress(addSec);
			U.log(Arrays.toString(add));
			}
		}
		add[0] = add[0].replace(",", "");
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
			
		
//--------------------------------------------------latlng----------------------------------------------------------------
		String latSec=U.getSectionValue(html,"Driving Directions</h4>","Map This Community");
		U.log(latSec);
		if(latSec != null && !latSec.isEmpty()){
			latSec=U.getSectionValue(latSec,"<a href=\"https://www.google.com/maps/place/","/");
			U.log(latSec);
			latlag=latSec.split(",");
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		}
		
		if(comUrl.contains("https://www.scottfelderhomes.com/communities/build-on-your-lot")){
			add = U.getAddress("16103 Via Shavano,San Antonio, TX 78249");
			latlag = U.getlatlongGoogleApi(add);
			if(latlag == null)
				latlag = U.getlatlongHereApi(add);
			geo = "True";
			note = "Address Is Taken From Contact Us";
		}
		if(comUrl.contains("https://www.scottfelderhomes.com/communities/san-antonio-area/schertzcibolo/the-crossvine")) {
			add[0] = "3193-2901 Abbott Rd";
			add[1] = "Converse";
			add[2] = "TX";
			add[3] = "78109";
			if(latlag == null)
				latlag = U.getlatlongHereApi(add);
			geo = "True";			
		}
		
		
		if((add[0].length()<4 || add[1].length()<4 ) && latlag[0]!=null)
		{
			add=U.getAddressGoogleApi(latlag);
			U.log(Arrays.toString(add));
			if(add == null)
				add = U.getGoogleAddressWithKey(latlag);
			if(add == null)
				add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
/*		if(add[1].length()<4  && latlag[0]!=null)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null)
				add = U.getGoogleAddressWithKey(latlag);
			if(add == null)
				add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}*/

//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		String[] remm = U.getValues(html, "HomeCard_price col-12 was", "<");
		
		for(String remove: remm) {
			
			html = html.replace(remove, "");
		}
		comsec=comsec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
		//U.log("kkkkkkkk"+comsec);
		comsec=comsec.replace("0's", "0,000").replace("$800s", "$800,000");
		html=html.replaceAll("Stories: <!-- /react-text --><strong data-reactid=\"\\d+\">", "Stories: ").replaceAll("0�s|0's|0s","0,000").replace("5's", "5,000");
		String prices[] = U.getPrices(html+comsec,"From the \\$\\d{3},\\d{3}|Price Range:\\s*\\$\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comsec, "[\\s\\w\\W]{30}800[\\s\\w\\W]{30}", 0));
//======================================================Sq.ft===========================================================================================		
		
//		html=html.replaceAll("</strong>\\s*<br data-reactid=\"\\d+\"/>\\s*<!-- react-text: \\d+ -->SQFT|</strong><br data-reactid=\"\\d+\" /><!-- react-text: \\d+ -->SQFT<!-- /react-text -->|</strong><br data-reactid=\"\\d+\"\\s+/><!--\\s+react-text:\\s+\\d+\\s+->SQFT", " SQFT");
		
		
		html = html.replaceAll("</strong>\\s*<br data-reactid=\"\\d+\" />\\s*<!-- react-text: \\d+ -->\\s*SQFT", " SQFT");
		html = html.replaceAll("</strong><br><!-- react-text: \\d+ -->SQFT", " SQFT").replaceAll("</strong><br data-reactid=\"\\d+\"><!-- react-text: \\d+ -->SQFT", " SQFT");
		U.log(Util.matchAll(html, "[\\s\\w\\W]{30}4,091[\\s\\w\\W]{100}",0));
		String[] sqft = U
				.getSqareFeet(
						html+comsec,"Square Feet Icon\"><br><div><strong>\\d,\\d{3}|\\d,\\d{3}-\\d,\\d{3} SQ FT|\\d,\\d{3} SQFT",
//						"Sq ft: <strong>\\d{1},\\d+-\\d{1},\\d+|from \\d{1},\\d+ to \\d{1},\\d+ square feet|Sq Ft: \\d{2,4}|label-op number_format\">\\d+",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		html = html.replace("golfing", "golf course").replace("waterfront amenities", "waterfront community")
				.replace("The Lakeway Resort and Spa", "The Lakeway Resort Style and Spa");
		String communityType=U.getCommType(html);
		
		//==================== Homes Details ===================
		String combinedHomeHtmls = null;
		int homesCount = 0;
		
		String [] homeUrlSections = U.getValues(html, "<div class=\"HomeCard\"", "<div class=\"HomeCard_footer\"");
		U.log("Quick Homes Count ==="+homeUrlSections.length);
		int x = 0;
		for(String homeUrlSec : homeUrlSections){
			
		//	U.log("homeUrlSec: "+homeUrlSec);
			
			String homeUrl = U.getSectionValue(homeUrlSec, "<a class=\"\" href=\"", "\"");
		//	U.log("homeURl ::"+builderUrl+homeUrl);
			String homeHtml = getHtml(builderUrl+homeUrl,driver);
			
//			if(homeHtml.contains("Under Construction")) {
//				
//			}
//			else {
//				homesCount++;
//			}
			if(homeUrlSec.contains("-->Ready Now<")) homesCount++;
			
			combinedHomeHtmls += U.getSectionValue(homeHtml, "<div class=\"container\" ", "Floor Plan</h3>");
			if(x ==8)break;
			x++;
		}
		
		U.log("homesCount for status : "+homesCount);
		
		
		String [] planUrlSections = U.getValues(html, "<div class=\"PlanCard\" ", "</li></ul></div>");
		U.log("Floor Homes Count ==="+planUrlSections.length);
		for(String planUrlSec : planUrlSections){
//			U.log(planUrlSec);
			String planUrl = U.getSectionValue(planUrlSec, "<a class=\"\" href=\"", "\"");
			U.log("planURl ::"+builderUrl+planUrl);
			combinedHomeHtmls += U.getSectionValue(getHtml(builderUrl+planUrl,driver), "<div class=\"container\"", ">Virtual Tour</h3>");
			//if(x ==8)break;
		//x++;
		}
//==========================================================Property Type================================================
		html=html.replaceAll("Cottage Promenade|cottage-|luxurious outdoor mall|custom homes located|expensive custom","")
				.replace("CCMC is more than your typical HOA", "provided by an HOA")
				.replace("utmost in luxury", "utmost in luxury homes");
		String proptype=U.getPropType((html+combinedHomeHtmls).replaceAll("HOA offices|luxury residents|Caliterra luxury|Luxury Master Suite|upgraded luxury", "luxury homes"));
		//U.log(html);
//==================================================D-Property Type======================================================
		String remo="ranch|RANCH|Ranch";
		html=html.replaceAll("Stories: <!-- /react-text --><strong>(\\d)</strong>", " $1 Stories");
//				.replaceAll("<label>Floors:</label>\\s*\\n+\\s*<div class=\"label-op\">|Stories: <!-- /react-text --><strong data-reactid=\"\\d+\">","Story ");
		String dtype=U.getdCommType(html.replaceAll(remo, "")+combinedHomeHtmls+comUrl);
		
//==============================================Property Status=========================================================
		String remove="and Elevations Coming Soon|Office Address: <strong>Coming Mid 2018!</strong>|</h2>\\s*<p>Coming Mid 2018!</p>|San Antonio New Homes Coming Soon|Coming this Summer Santiko|MODELS NOW OPEN|now open!|Address: <strong>Opening 2017|<p>Opening 2017!</p>|has new homes|Club\" is NOW";
		html = html //Home Sites and Showcase Homes Now Open
				.replace("home sites are currently available", "home sites currently available")
				.replace("USDA_ZERO_DOWN_FINANCING_AVAILABLE", "USDA ZERO DOWN FINANCING AVAILABLE")
				.replaceAll("Quick Move-In Homes|>\\s?Quick Move-In Homes<|Showcase Homes Now Open|Coming soon this summer is the 4 acre|", "")
				.replaceAll(remove, "");
		String pstatus=U.getPropStatus(html);
		
		if(homesCount > 0) {
			if(pstatus == ALLOW_BLANK)
				pstatus = "Quick Move-In Homes";
			else if(pstatus != ALLOW_BLANK)
				pstatus = pstatus + ", Quick Move-In Homes";	
			}
		
		
		
		U.log("pstatus: "+pstatus);
		
//		U.log(Util.matchAll(html, "[\\w\\s\\W]{10}Quick Move[\\w\\s\\W]{10}", 0));
		
/*		if(homeUrlSections.length==0){
			pstatus=pstatus.replace("Quick Move-in", "");
			if(pstatus.length()<4)pstatus = "No Quick Move-in Homes";
			else pstatus = pstatus + ", No Quick Move-in Homes";
		}
		else {
			//pstatus=pstatus.replace("Quick Move-in", "Quick Move-in Homes");
		}
*/	
//		if(!U.getSectionValue(html, "<h3 data-reactid=\"122\">", "</h3>").contains("Please")) {
//			add[0]=U.getSectionValue(html, "<h3 data-reactid=\"122\">", "</h3>");
//		}	
		if(comUrl.contains("https://www.scottfelderhomes.com/communities/austin-area/bastrop/the-colony-riverside"))
			proptype=proptype+", Loft";
		
		if(comUrl.contains("austin-area/bastrop/the-colony-riverside"))pstatus=pstatus.replace("Homesites Now Open, Now Open", "Homesite Now Open");

		
		
		
		data.addCommunity(communityName.trim(),comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("117 Civita Rd", "117 Civita Road"), add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
	}
		j++;
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					/*Dimension d = new Dimension(300,1080);
			     	
			     	   driver.manage().window().setSize(d);*/
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,2000)", ""); 
					Thread.sleep(10000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
					
					try{
						
						WebDriverWait wait = new WebDriverWait(driver, 20);
						
						while( driver.findElements(By.xpath("//*[@id=\"root\"]/div/div/div/div[4]/div[2]/div[2]/div[3]/div/div/div[3]/div/div/div/div/div[2]/button")).size() > 0) {
							wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[4]/div[2]/div[2]/div[3]/div/div/div[3]/div/div/div/div/div[2]/button"))));

						WebElement loadBtn = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[4]/div[2]/div[2]/div[3]/div/div/div[3]/div/div/div/div/div[2]/button"));//--------//load more button
						loadBtn.click();
						
						loadBtn = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[4]/div[3]/div[2]/div[3]/div/div/div[3]/div/div/div/div/div[2]/button"));//--------//load more button
						loadBtn.click();
						U.log(":::::::::::::CLick Success:::::::::::::::");
						Thread.sleep(5000);
						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,800)", ""); 
							}
						}
						catch(Exception e){
							U.log(":::::::::::::CLick UnSuccess:::::::::::::::"+e.getMessage());
						}
					
/*					try{
						WebElement tab = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[7]/div[1]/div/div[2]/button"));
						tab.click();
						Thread.sleep(5000);
						html += driver.getPageSource();
						U.log("successfull--> click on 'Load More' Button");
					}catch(Exception e){
						U.log("unsuccessfull-->Not click on 'Load More' Button");
					}*/
					
					html = driver.getPageSource();
					Thread.sleep(5000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("<iframe class=\"SiteMap_embed\"")) {
			
			String frameSec = U.getSectionValue(html, "<iframe class=\"SiteMap_embed\"", "</iframe>");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "src=\"", "\""); 
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.contains("/sitemap/")) {
					
					mapData = U.getHtml(frameUrl, driver);
					
					if(mapData.contains("class=\"is-not-empty")) {
						
						String[] lots = U.getValues(mapData, "class=\"is-not-empty", "\"");
						U.log("lots: "+lots.length);
						
						totalCount = totalCount + lots.length;
					}
					
					totalUnits = String.valueOf(totalCount);
				}
			}
		}
		return totalUnits;
	}
	
}