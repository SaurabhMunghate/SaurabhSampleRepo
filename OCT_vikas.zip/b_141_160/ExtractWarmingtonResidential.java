/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_141_160;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWarmingtonResidential extends AbstractScrapper{
	
	CommunityLogger LOGGER;
	static int j=0;
	static int k=0;

	public ExtractWarmingtonResidential()throws Exception {
		super("Warmington Residential","https://www.homesbywarmington.com/");

		LOGGER=new CommunityLogger("Warmington Residential");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractWarmingtonResidential();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Warmington Residential.csv", a.data().printAll());

		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.homesbywarmington.com/find-your-home");
		String[] citysec =U.getValues(mainHtml, "<a class=\"clearfix\" href=\"","\">");
		for(String city:citysec)
		{
			String urlcity="https://www.homesbywarmington.com"+city;
			String cityHtml=U.getHTML(urlcity);
			String[] comValues=U.getValues(cityHtml, "<div class=\"community\"","Visit this Community</span>");
			U.log("total comm"+comValues.length);
			for(String value:comValues)
			{
				String comUrl="https://www.homesbywarmington.com"+U.getSectionValue(value, "href=\"","\">");
				addDetails(comUrl,value);
			}
			U.log("city url-->"+ city);
		}
		String mUrl="https://www.homesbywarmington.com/nevada/mesquite/desert-ridge/site-map";
		adDetail(mUrl);
	}

	private void adDetail(String Url) throws Exception {
		// TODO Auto-generated method stub

//		if(!Url.contains("https://www.homesbywarmington.com/nevada/mesquite/desert-ridge/site-map"))return;
	
		{
		U.log("count"+j);
		String comHtml=U.getHTML(Url);
		String comName=U.getSectionValue(comHtml, "<title>", "</title>");
		comName=comName.replace("New Home Builders Mesquite | New Homes For Sale Mesquite | ", "");
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(comHtml, "data-community-address=\"", "\"");
		addSec=addSec.replace("<br/>", ",");
		add=U.getAddress(addSec);
		U.log("Address"+Arrays.toString(add));
		latlag[0]=U.getSectionValue(comHtml, "data-lat=\"", "\"");
		latlag[1]=U.getSectionValue(comHtml, "data-long=\"", "\"");
		U.log("LLATLNMG"+latlag[0]+" "+latlag[1]);
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(comHtml, "\\d,\\d{3}\n\\s*- \\d,\\d{3}\nSq. Ft.", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
		String prices[] = U.getPrices(comHtml,"\\$\\d+,\\d+",0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		String propType=U.getPropType((comHtml).replaceAll("cove-cottages|East Cove Cottages", ""));
		U.log("proptype "+propType);
//		U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}cottage[\\w\\s\\W]{30}", 0));
		
		String comType=U.getCommType((comHtml).replace("elongated toilets", ""));
		
		U.log("comType "+comType);
//		U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}gated[\\w\\s\\W]{30}", 0));
		
		String propStatus=U.getPropStatus(comHtml.replaceAll("<h4>Quick Move-In</h4>", ""));
//		U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{30}QUICK MOVE-IN[\\w\\s\\W]{30}", 0));

		U.log("propStatus "+propStatus);
		String dtype=U.getdCommType(comHtml);
		U.log("dtype "+dtype);
		String note=U.getnote(comHtml.replace("near these new town homes for sale",""));
		U.log("note "+note);
		data.addCommunity(U.getCapitalise(comName.toLowerCase()),Url, comType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(propType, dtype);
		data.addPropertyStatus(propStatus);
		data.addNotes(note);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
        data.addUnitCount(ALLOW_BLANK);
		j++;
		}
	
	}

	private void addDetails(String comUrl, String cityData) throws Exception {
		// TODO Auto-generated method stub
		//try {
//		U.log(cityData);
		
//		if(!comUrl.contains("https://www.homesbywarmington.com/nevada/mesquite/desert-ridge/site-map"))return;

		U.log("Count== "+j+"::::::::::::::: commUrl-->"+comUrl);
		
		if(data.communityUrlExists(comUrl))	{
			LOGGER.AddCommunityUrl(comUrl);
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHTML(comUrl);
		
		String rem=U.getSectionValue(html, "Find Your Home</h3>","</html>");
		html=html.replace(rem,"");
		
		
		
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(cityData, "data-name=\"","\"");
		
		U.log("community Name---->"+communityName);
		//============================================note====================================================================
		String note=U.getnote(html.replaceAll("near these new town homes for sale", ""));
//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String addSec=U.getSectionValue(html, "<a href=\"https://maps.google","</div>");
		U.log("addSec : "+addSec);
		if(addSec!=null)
			
		addSec=addSec.replaceAll(" (Patricia Ave. and Erringer Rd.)|Coming Late 2017!|Appointment Only|Coming Summer of 2017!|Opening 2017!","").replace("(Durango and Oquendo)", "");
		U.log("addSec1::::::::"+addSec);
		if(addSec!=null && addSec.length()>10)
		{
		String addSec1=U.getSectionValue(addSec, "<br/>", "</a>");
		U.log("addSec1::::::::"+addSec1);
		if(addSec1 == null)addSec1=U.getSectionValue(addSec, "<br>", "</a>");
		if(addSec1 == null)addSec1=U.getSectionValue(addSec, "<br />", "</a>");
		if(addSec1 == null)addSec1=U.getSectionValue(addSec, "<p>", "</p>");
		addSec1=addSec1.replaceAll("\\(|\\)", "")
				.replace("Now Selling from Rockpointe<br>", "").replace("Near 3475 Oakmont Dr", "3475 Oakmont Dr").replace("<br>(Tassajara Rd. at Wallis Ranch Rd.)", "").replace("<br>(Oquendo Road and Fort Apache Road)","").replace("<br>(Hacienda and Hualapai)","").replace("(Warm Springs Rd. and Buffalo Dr.) <br/>","")
				.replaceAll("near 148 Pioneer Ave\\.", "");
		addSec1 = addSec1.replace("Eldorado Lane<br>", "Eldorado Lane,");	
		U.log("kkkk-->"+addSec1);
		
		addSec1=addSec1.replace("<br />", ",");
		add=U.getAddress(addSec1);
		if (add==null) {
			add=new String[4];
		}
		
		if(add[0].contains("1754 Heywood Street Patricia Ave. and Erringer Rd")) {
			add[0] = add[0].replace("1754 Heywood Street Patricia Ave. and Erringer Rd.", "1754 Heywood Street");
		}
		
		U.log("hello-->"+Arrays.toString(add));
		}
		if(addSec==null && html.contains("data-community-address=")){
			addSec=U.getSectionValue(html, "data-community-address=\"", "\"");
			addSec=addSec.replaceAll("<br/>", ",").replaceAll("<br>(Durango and Oquendo)", "")
					.replace(" (near 148 Pioneer Ave.)", "");
			U.log(addSec);
			add=U.getAddress(addSec);
		}
		
		
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
		
		latlag[0]=U.getSectionValue(cityData, "data-lat=\"","\"");
		latlag[1]=U.getSectionValue(cityData, "data-lng=\"","\"");
		
		U.log("hello-->"+Arrays.toString(latlag));
	
		if(add[0].length()>4 && latlag[0].length()<4)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null)latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if(add[0]==ALLOW_BLANK && latlag.length>4 && !latlag[0].contains("0.0000000"))
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null)add =U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		/*if (comUrl.contains("https://www.homesbywarmington.com/nevada/mesquite/desert-ridge")) {
			
			add[0]="Mariposa Way";
			add[1]="Mesquite";
			add[2]="NV";
			add[3]="";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="true";
			note="Address And LatLon Taken From City And State";
		}*/
		if(add[0].length()<4 && latlag[0].length()>4){
			add=U.getAddressGoogleApi(latlag);
			if(add == null)add =U.getAddressHereApi(latlag);
			geo="true";
		}
//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
/*		if(comUrl.contains("https://www.homesbywarmington.com/california/south-san-francisco/bayview-twenty-two"))
			html += " $1,500,000 "; //Img
*/		
		html=html.replaceAll("0s|0's","0,000").replace("$1 millions", "$1,000,000").replace("$1,000,000 LTV and ", "").replace("low $1.2 millions", "low $1,200,000");
		html=html.replaceAll("more than \\$80,000 |oan amount of \\$588,720", "");
		String prices[] = U.getPrices(html+cityData,"low \\$\\d{1},\\d{3},\\d{3}|\\$\\d,\\d+,\\d+|\\$\\d+,\\d+|\\$600,000", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		
		
		String[] sqft = U
				.getSqareFeet(
						html+cityData,
						"\\d,\\d+ - \\d,\\d+ Sq. Ft|\\d,\\d+\\s*-\\s*\\d,\\d+\\s*Sq. Ft.|Sq Ft: \\d{2,4}|\\d,\\d+\\s*\\n*\\s*Sq. Ft",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
		html=html.replaceAll("Elongated|elongated", "");
		html=html.replace("resort-quality residential", "resort-style quality residential");
		html=html.replace("The detached residence", "detached homes");
		String communityType=U.getCommType(html+cityData);
		
//==========================================================Property Type================================================
		String remo="not custom homes|new town homes|traditional flair|HOA assessments";
		html=html.replaceAll("Luxury Flats|luxurious levels ", "Luxury HOmes")
				.replace("Game Room + Loft", "Game Room with Loft ");
		html=html.replace("traditional rear", "traditional home rear").replaceAll("Plan \\d Detached", "detached home")
				.replaceAll("cove-cottages|East Cove Cottages", "");
		
		String proptype=U.getPropType((html.replaceAll(remo, "")+cityData).replace("Flex + Game Room", "Flex room"));
		
		U.log("proptype: "+proptype);
		
//==================================================D-Property Type======================================================
		html=html.replaceAll("Ranch -|Ranch</a>| Ranch,|Ranch Rd|Ranch Drive|Rancho|floor|Floor|First Level Suite|First Level Office","");
		html=html.replace("second level"," 2 Story ");
		
//		U.log("mmmmmm"+Util.matchAll(html+comUrl+communityName, "[\\w\\s\\W]{30}one level[\\w\\s\\W]{30}", 0));
		
		String dtype=U.getdCommType(html.replace("single-level", "")
				.replace("two- and three-level homes", "2 story and three-level homes")+comUrl+communityName);
//		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}three-level[\\w\\s\\W]{30}", 0));

		if(comUrl.contains("https://www.homesbywarmington.com/california/mission-viejo/canopy-at-esencia")){
			dtype=dtype+",4 Story";
		}
		if(comUrl.contains("https://www.homesbywarmington.com/california/irvine/opus-at-beacon-park"))dtype +=",2 Story";
		
		U.log("dtype:::"+dtype);
//==============================================Property Status=========================================================
		html = html.replace("now selling its final phases", "Now Selling Final Phase")
				.replace("final homes are now selling", "final homes now selling")
				.replaceAll("Hours of Operation</h4>\n" + 
						"<p>\n" + 
						"Opening Summer 2022", "")
				.replace("final home is now selling", "final home now selling")
				.replace("now selling its final phases", "final phases now selling")
				.replace("Coming to Walnut Creek Fall 2021", "Coming Fall 2021")
				.replace("The final phase is now selling", "The final phase now selling").replaceAll("Homes are now selling. Contact Crystal|Move-in ready homes available now|about these move-in", "");
		String remove="quick-move-in|move-in ready by year|prequalification &nbsp;is now open|prequalification</a>&nbsp;is now open|ront businesses coming soon|bedroom move-in ready|\"Image coming soon\"|Now Open for Private|Models Now Open|Price Coming Soon|sold-out\">|Streetscene of move-in ready homes|The Garage, is now open|Opus is nearly sold ou|Video: Now Open|park that is opening soon|School, opening soon|Temporarily Sold Out|<p>Coming Soon!|Grand Opening Handout|Price Coming Soon|coming soon to|Models Now Open|are now open|Models open spring 2018.| <span class=\"banner-status temporarily-sold-out\">TEMPORARILY SOLD OUT</span>|<span class=\"banner-status sold-out\">SOLD OUT</span>|<br/>\\s*Coming Soon\\s*</p>| <span class=\"banner-status coming-soon\">COMING SOON</span>|<br/>\\s*Sold Out\\s*</p>|of the last opportunities|SOLD OUT</span>|<br />\\s+Sold Out|Office Opening";
		
		String pstatus=U.getPropStatus(html.replaceAll(remove, "").replaceAll("=\".*\"|MODEL GRAND OPENING SEPTEMBER|during the grand opening phase", "").replace("The final phases are now selling", "final phases now selling")+cityData);
//		if(comUrl.contains("https://www.homesbywarmington.com/california/valley-glen/the-glen-la"))
//			pstatus = pstatus + ", Only 1 Homes Remain"; //From Img

		pstatus = pstatus.replaceAll("1 Home Remain, Just 1 Home Remains", "Just 1 Home Remains");
		//status from popup images
//		if(comUrl.contains("/mountain-view/waverly"))pstatus=pstatus+", 1 Home Left";
		
//		if(comUrl.contains("/south-san-francisco/bayview-twenty-two"))
//			pstatus="Final Home Now Selling, 1 Home Left";
		
//		if(comUrl.contains("toluca-lake/skye-twenty-two"))
//			pstatus += ", 1 Home Remains";
//		if(comUrl.contains("https://www.homesbywarmington.com/california/san-marcos/orchard-knolls"))pstatus="Phase Three Now Selling";
//		if(comUrl.contains("https://www.homesbywarmington.com/california/la-mirada/paloma"))pstatus+=", 80% Sold Out";//Img
		//if(comUrl.contains("com/nevada/mesquite/desert-ridge"))pstatus=pstatus.replace(", Quick Move-in", "");//Img
		add[0]=  add[0].replace("now selling from rockpointe", "");
		add[0]= U.getNoHtml(add[0]);
		
			data.addCommunity(U.getCapitalise(communityName.toLowerCase()),comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(ALLOW_BLANK);
			j++;
		//}catch(Exception e) {}
	}


}