package com.shatam.b_141_160;

/**
 * @author Rakesh Chaudhari
 * @date 08-07-2015
 * 
 */
import java.io.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.map.MultiValueMap;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWilliamHomes extends AbstractScrapper {
	static String BASEURL = "https://www.williamshomes.com";
	static int j = 0;
	static int rep=0;
	static int count = 0;
	CommunityLogger LOGGER;
	MultiValueMap comDetails = new MultiValueMap();
	MultiValueMap floorplansMap=new MultiValueMap();
	MultiValueMap communityCards=new MultiValueMap();
	MultiValueMap moveInreadHomes=new MultiValueMap();
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractWilliamHomes();
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Williams Homes.csv", a.data()
						.printAll());
	}

	public ExtractWilliamHomes() throws Exception {

		super("Williams Homes", BASEURL);
		LOGGER = new CommunityLogger("Williams Homes");
	}
	public void innerProcess() throws Exception
	{
		String baseHtml = U.getHTML("https://www.williamshomes.com/our-communities");
		String moveInHtml=U.getHTML("https://www.williamshomes.com/move-in-ready-homes");
		String movesins[]=U.getValues(moveInHtml, "<div class=\"home__header\">", "View</span>");
		for (String moveIn : movesins) {
			String name=U.getSectionValue(moveIn, "Community:", "</a>");
			if (U.getNoHtml(name).equals("The Farm")) {
				String tempName[]= {"Topa Topa","Sespe","Olivas","Anacapa"};
				for (String string : tempName) {
					name=string;
					if (!moveInreadHomes.containsValue(U.getNoHtml(name).trim(), moveIn)) {
						U.log(U.getNoHtml(name));
						moveInreadHomes.put(U.getNoHtml(name).trim(), moveIn);
					}
				}
				
			}else if (!moveInreadHomes.containsValue(U.getNoHtml(name).trim(), moveIn)) {
				U.log(U.getNoHtml(name));
				moveInreadHomes.put(U.getNoHtml(name).trim(), moveIn);
			}
		}
		//fetching communities from the individual region page
//		String[] regUrls = U.getValues(baseHtml, "<li class=\"button-list-item\">", " </li>");
//		//U.log("total regions :: "+regUrls.length);
//		for(String regUrl: regUrls){
//			regUrl=U.getSectionValue(regUrl, "href=\"", "\"");
//			U.log("RegUrl =="+regUrl);				
//			String regHtml=U.getHTML(regUrl);
//			String comSecs[]=U.getValues(regHtml, "<li class=\"list-card__list-item\">", "</li>");
//			for (String comSec : comSecs) {
////				U.log(comSec);
//				String comUrl=U.getSectionValue(comSec, "href=\"", "\"");
////				U.log(comUrl);
//				String commName=U.getSectionValue(comSec, "<h4 class=\"list-card__item-title\">", "</h4>");
//				String comHtml=U.getHTML(BASEURL+comUrl);
		
		///////////////////////  NEW   //////////////////////////
		
		String regurlSec=U.getSectionValue(baseHtml, "<div class=\"your-home__states\">", "  <div class=\"your-home__map\" ");
		
	
		
		String[]  regUrl=U.getValues(regurlSec, "<a href=\"", "\"");
		for(String regurl : regUrl)
		{
			String regURL="https://www.williamshomes.com"+regurl;
			U.log("regUrl:::::::::"+"https://www.williamshomes.com"+regurl);
			U.log(U.getCache(regURL));
		}
		U.log(">>>>>>>"+regUrl.length);
		for(String regurl : regUrl)
		{
			String regHtml=U.getHTML("https://www.williamshomes.com"+regurl);
			String[] commSec=U.getValues(regHtml, "<header class=\"regional__item-header\">", "Visit This Community</a>");
			
//			U.log(">>>>>>>commSec"+commSec.length);
			for(String comSec: commSec)
			{
				String comUrl="https://www.williamshomes.com"+U.getSectionValue(comSec, "href=\"", "\"");
				
				U.log(">>>>>>>>>comUrl>>>>>>"+comUrl);
				
				String comHtml=U.getHTML(comUrl);
				String commName=U.getSectionValue(comSec, "<h2 class=\"regional__item-title\">", "</h2>");			
			
		
		
				//U.log("comHtml:: "+BASEURL+comUrl);
				
//				if(comUrl.contains("new-home-communities/los-angeles/williams-ranch"))continue;
				
//				String floorPlans[]=U.getValues(comHtml, "<div class=\"floorplan-card\">", "<span class=\"icon-slider-next\"></span>");
				String[] floorPlans=null;
				
				
				if(comHtml.contains("Floorplan Collections</h3>"))
				{
					U.log(">>>>COLLECTION");
					String[]  collectionUrls=U.getValues(comHtml, " <div class=\"collection__action\">\n" + 
							"            <a\n" + 
							"                href=\"", "\"");
					for (String url : collectionUrls) {
						url="https://www.williamshomes.com"+url;
						String collectionHtml=U.getHTML(url);
						floorPlans=U.getValues(collectionHtml, " <div class=\"floorplan__content\">", "  View Floorplan <span class");
					}
				}
				else {U.log(">>>>non- COLLECTION");
				 floorPlans=U.getValues(comHtml, " <div class=\"floorplan__content\">", "  View Floorplan <span class");
				}
				
				for (String floor : floorPlans) {
					
					floorplansMap.put(commName, floor);
				}
				if (comHtml.contains("navigate('communities',") ) { //&& !comUrl.contains("new-home-communities/los-angeles/williams-ranch")
					String subComs[]=U.getValues(comHtml, "navigate('communities',", " </li>"); 
					for (String subCommunity : subComs) {
						//U.log("------------------------- "+subCommunity);
						commName=U.getSectionValue(subCommunity, "<a class=\"community-nav__link\">", "</a>").trim();
						floorPlans=U.getValues(comHtml, "<div class=\"floorplan-card\">", "<span class=\"icon-slider-next\"></span>");
						String commDescs[]=U.getValues(comHtml, "<div class=\"row\" ref=\"collection\">", " <div class=\"elevation\">");
						String commCards[]=U.getValues(comHtml, "<div class=\"elevation col-xs-12\">", "View Floorplans</a>");
						for (String floor : floorPlans) 
							if (floor.contains(commName)) 
								if(!floorplansMap.containsValue(commName, floor))
									floorplansMap.put(commName, floor);
						for (String desc : commDescs) 
							if (desc.contains(commName))
								if(!comDetails.containsValue(commName, desc))
									comDetails.put(commName, desc);
						for (String cards : commCards) 
							if (cards.contains(commName))
								if(!communityCards.containsValue(commName, cards))
									communityCards.put(commName, cards);
						String subComURl=BASEURL+U.getSectionValue(subCommunity, "'", "')").replace("', '", "/");
						addDetailsInfo(subComURl, comSec, comHtml, commName);///////
					}
				}else {
//					addDetailsInfo(BASEURL+comUrl, comSec, comHtml, commName);///////
					addDetailsInfo(comUrl, comSec, comHtml, commName);
				}
			}
			
		}
			
		

//		U.log("Total count:"+comDetails.size());
		
		//fetching communties from drop down menu
	
		
		U.log(count);
		LOGGER.DisposeLogger();
	}


	int i = 0;
	//TODO : Extraction for communities
	private void addDetailsInfo(String comUrl, String comSec, String comHtml, String commName) throws Exception {
		
		//////////////////////////////////////////////////
		
//		if (!comUrl.contains("https://www.williamshomes.com/new-home-communities/los-angeles/williams-ranch"))return;
		
//try{
	{
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------>repeated");
			return;
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/los-angeles/solana")) {
			LOGGER.AddCommunityUrl(comUrl+"========error 404");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

//		U.log(comSec);
		
		
		
		
		U.log(i+"\tCommunity Url-----> "+comUrl);
		U.log(commName);
		String remSec=U.getSectionValue(comHtml, "Our Communities</button>", "Get Updates</button>");
//		U.log(">>>>>>>>>>>>"+remSec);
		if(remSec!=null) {
			comHtml=comHtml.replace(remSec, "");
			
		}
		
		String html1 = U.getHTML(comUrl);
		String welcomeCommunitySec=U.getHtmlSection(html1, "<section id=\"welcome\" class=\"community-welcome\">", "</section>");
		if(welcomeCommunitySec==null) {
			welcomeCommunitySec=ALLOW_BLANK;
		}
		String rem1=U.getSectionValue(html1, "Schedule an Appointment</button>", "type=\"submit\"");
		if(rem1!=null)
		{
			html1=html1.replace(rem1, "");
		}
		String rem2=U.getSectionValue(html1, "Our Communities</button>", "Get Updates</button>");
		if(rem2!=null)
		{
			html1=html1.replace(rem2, "");
		}
		
		String floorPlanHtml="";
		if (floorplansMap.containsKey(commName)) {
			U.log("FloorPlans Length "+floorplansMap.getCollection(commName).size());
			@SuppressWarnings("unchecked")
			Collection<String> floorplans=floorplansMap.getCollection(commName);
			for (String floor : floorplans) {
				floorPlanHtml+=floor;
			}
		}
//		U.log("floorPlanHtml>>>>\n"+floorPlanHtml);
		String commDesc="";
		if (comDetails.containsKey(commName)) {
			@SuppressWarnings("unchecked")
			Collection<String> descs=comDetails.getCollection(commName);
			for (String desc : descs) 
				commDesc+=desc;
		}
		String cards="";
		if (communityCards.containsKey(commName)) {
			@SuppressWarnings("unchecked")
			Collection<String> cardDatas=communityCards.getCollection(commName);
			for (String carddata : cardDatas) 
				cards+=carddata;
		}
		
		
		//========communtiy Type=====
		String commType=ALLOW_BLANK;
		comHtml=comHtml.replaceAll("Country Club&quot;|friendlyvalleycountryclubwebsite", "");

		comHtml = comHtml.replaceAll("elongated toilet|Hansen Dam Golf Course", "");
		String communityHtml=U.getSectionValue(comHtml, "<article class=\"community-welcome__article\">", "  <!-- footer -->");
		if (commDesc.trim().length()==0) {
			U.log(">>>>SEC 1");
			commType=U.getCommunityType(communityHtml );
		}else {U.log(">>>>SEC 2");
			commType=U.getCommType(commDesc+comSec+cards);
		}
		
		
//		U.log("mmmmmm"+Util.matchAll(commDesc+comSec+cards, "[\\w\\s\\W]{30}Master Plan[\\w\\s\\W]{30}", 0));
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comHtml = comHtml.replace("$1,190,900<\\/span>", "");
		communityHtml = communityHtml.replace("$400s", "$400,000").replace("$600s", "$600,000");
		String prices[] = {ALLOW_BLANK,ALLOW_BLANK};
		
		/*
		 * section of floor homes when there is sub-communities are present.
		 */
		String floorSection[] = U.getValues(comHtml, "<div class=\"collection-view__title\">", "class=\"container collection-view__section\"");
		U.log("commName ::"+commName);
		String foundFloorSec = null;
		for(String floorSec : floorSection){
			if(floorSec.contains(commName)){
//				U.log("found -->"+floorSec);
				foundFloorSec += floorSec;
			}
		}
		/*
		 * move in section
		 */
		
//		String moveInSection = U.getSectionValue(comHtml, "<section class=\"community-move-in-ready\">", "</section>");
		String moveInSection=U.getSectionValue(communityHtml, "<div id=\"move-in-ready\" class=\"community-homes\">", "<h3 class=\"community-siteplan__title\">"); 
		if (floorPlanHtml.trim().length()==0) {
			prices=U.getPrices((comSec + foundFloorSec).replace("price\":881157", ""), "\\$\\d,\\d{3},\\d{3}|Starting from \\$\\d{3},\\d{3}", 0);
			
			U.log("prices from 1");
		}else {
			if(floorPlanHtml != null) floorPlanHtml = floorPlanHtml.replaceAll("00's|00s", "00,000");
			
	///		U.log(floorPlanHtml);

			prices=U.getPrices((comSec+commDesc+cards+floorPlanHtml + foundFloorSec + moveInSection +communityHtml).replace("$1,472,625", "").replace("$1,142,072", "").replace("$1,519,630", "").replace("price\":881157", "").replace("$817,863", "").replace("price\":817863", "").replace("$881,157", "").replace("$1,228,900", ""), 
					"Starting from \\$\\d,\\d{3},\\d{3}| <div class=\"floorplan__price\">Starting from \\$\\d,\\d+,\\d+</div>|<span class=\"home__button-price\">\\$\\d+,\\d+</span>|Starting from \\$\\d+,\\d+|class=\"text\">Starting from \\$\\d{3},\\d{3}|(in|from) the( low to)? mid-\\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|"
					+ "Starting from \\$\\d{3},\\d{3}</span>|<p class=\"text\">Starting from \\$\\d{3},\\d{3}</p>|<div class=\"price\">\\$\\d{3},\\d{3}</div>|"
					+ "in the high \\$\\d{3},\\d{3}|from the High \\$\\d{3},\\d{3}", 0);
			
			U.log("prices from 2");
		}
//		U.log("mmmmmm"+Util.matchAll(foundFloorSec , "[\\w\\s\\W]{30}$881,157[\\w\\s\\W]{30}", 0));
//		U.log("mmmmmm"+Util.matchAll(communityHtml, "[\\w\\s\\W]{30}\\$1,185,900[\\w\\s\\W]{30}", 0));

			String geo="FALSE";
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("prices======"+Arrays.toString(prices));
		//comHtml=comHtml.replaceAll("|with \\d{1},\\d{3} approximate square feet|with \\d{1},\\d{3} to \\d{1},\\d{3} approximate square feet|</, \\d{1},\\d{3} - \\d{1},\\d{3}|</li>, \\d{1},\\d{3} - \\d{1},\\d{3}</li>|\\d{1},\\d{3} - \\d{1},\\d{3}|and \\d{1},\\d{3} - \\d{1},\\d{3} sqft, by|totaling \\d{1},\\d{3} approximate square feet|The, \\d{1},\\d{3} - \\d{1},\\d{3}|</, \\d{1},\\d{3} - \\d{1},\\d{3}", "");
		floorPlanHtml = floorPlanHtml.replaceAll("\\d,\\d+ approximate square feet with an additional", "");
		comHtml = comHtml.replaceAll("\\d,\\d+ approximate square feet with an additional", "");
		
		
		String sqftsec=U.getSectionValue(comHtml, "", "");
		
		
		String sqft[] = {ALLOW_BLANK,ALLOW_BLANK};
//		if (floorPlanHtml.trim().length()==0) {
//			sqft=U.getSqareFeet(comHtml, "\\d,\\d{3} to \\d,\\d{3} approximate square feet|approximately \\d,\\d{3} square feet|\\d,\\d{3} TO \\d,\\d{3} APPROX SQ FT|\\d,\\d{3} - \\d,\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3}</li>|<span class=\"icon-sqft\"></span>\\n*\\s+\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} approximate square feet with|<span class=\"icon-sqft\"></span>\\s+\\d,\\d{3}\\s+</li>", 0);
//		}else {
		
//		floorPlanHtml=floorPlanHtml;
			sqft=U.getSqareFeet((communityHtml+commDesc+cards+floorPlanHtml)//.replace("The spacious residence at Willson 16 is 2,446 approximate square feet with an additional 523 square feet", "")
					, "\\d{3} - \\d{3}|\\d,\\d+\n\\s*<span class=\"sr-only\">Square Feet</span>|\\d,\\d+ - \\d,\\d+\n\\s*<span class=\"sr-only\">Square Feet</span>|\\d,\\d{3} to \\d,\\d{3} approximate square feet|approximately \\d,\\d{3} square feet|\\d,\\d{3} TO \\d,\\d{3} APPROX SQ FT|\\d,\\d{3} - \\d,\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3}</li>|<span class=\"icon-sqft\"></span>\\n*\\s+\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} approximate square feet with|<span class=\"icon-sqft\"></span>\\s+\\d,\\d{3}\\s+</li>|\\d,\\d{3} SF ", 0);
	//	}

		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("sqft======"+Arrays.toString(sqft));
		//=====prop Status======//
		
		String removeJson = U.getSectionValue(comHtml, "let JsonData =", "</script>");
		if(removeJson != null) comHtml = comHtml.replace(removeJson, "");
		String propStatus=ALLOW_BLANK;
		
		
		comHtml = comHtml.replace("Phases 1 and 2 are Already Sold Out", "Phases 1 and 2 Already Sold Out")
				.replace("The Final Home at Tovara West is Now Selling", "The Final Home Now Selling");
		
		
		
		String remove = "single story home ready for|progress at Williams Ranch opening|Available for Viewing|Your last chance to live|It's the Last One and it's a Model Home|Final Homes Must Be|Move-in Ready Homes|move-in ready homes|move-in|MOVE-IN";
		comHtml=comHtml.replaceAll(":\"Coming|Quick Move|features coming|>NO HOA FEES<|No HOA", "");
//		comHtml=comHtml.replace("Builder Close-Out","");
		
		if (comUrl.contains("righetti/communities/the-paseos") || comUrl.contains("righetti/communities/the-arroyos"))
			comHtml=comHtml.replaceAll("coming-soon\">\n\\s+COMING SOON|Move-In Ready|move-in-ready-homes|Move-In Ready|Don't miss this final", "");
		
		comHtml=comHtml.replaceAll("floorplan__price\">\n\\s*Sold Out|-sold-out-|floorplan__price\">\n\\s*Temporarily Sold Out|alt=\"Temporarily Sold Out\"|&quot;Temporarily Sold|\"price_status\":\"Temporarily Sold Out|\"<p><\\/p><p>Only One Available|p&gt;Only One Available|Paseos Final Phases</span>|progress at Williams Ranch opening 2021|contact__hours\">\\s+Closed - Community Sold Out|close out each day|Move-In Ready|move-in-ready-homes|Move-In Ready|Don't miss this final", "")
				.replace("just released a New Phase", "New Phase just released")
				.replace("Only ONE Home Is Available", "Only ONE Home Available")
				.replaceAll("Luxury Attached Homes Coming Soon|luxury attached homes coming soon|Coming Soon<br>\\s*BIllings", "")
				.replaceAll("Final Homes at Tovara West are Now Selling|final homes are now selling", "Final Homes Now Selling");
		
		comSec = comSec.replace("Grand Openng", "Grand Opening")
				;
		
			String[] removeSec=U.getValues(comHtml, "<script>", "</script>");
		for(String removeSecs : removeSec) {
			comHtml=comHtml.replace(removeSecs, "");
		}
				propStatus=U.getPropStatus((welcomeCommunitySec+comHtml).replaceAll("Temporarily Sold Out...More Coming Soon|&quot;Sold Out|Sold Out\"|sold-out-|;Coming Soon&quot;|Communities coming soon!|subnav-empty\">Coming Soon!</div>|single story home ready for|<span class=\"coming-soon\">COMING SOON|y--now-selling\">|Now Selling|[M|m]ove-[I|i]n", "")+comSec
						.replaceAll(remove, "")).replace("price_range\":\"Coming Soon", "").replace("oming Soon&quot;,", "").replace(":&quot;Coming", "").replace(";Coming Soon!&lt;br", "");
//				U.log("mmmmmm"+Util.matchAll(comHtml+welcomeCommunitySec, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{100}", 0));
//				U.log("mmmmmm"+Util.matchAll(comSec, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{100}", 0));
				if(comUrl.contains("https://www.williamshomes.com/new-home-communities/helena/highland-meadows"))  propStatus="Now Selling";
			U.log("propStatus===="+propStatus);

//		}

	//	U.log(comUrl.contains("righetti")+"\t"+ moveInreadHomes.containsKey("Righetti"));
		
		if (comHtml.contains("navigate('move-in-ready")) {
			if (propStatus.length()<4) {
				propStatus="Move-In Ready";
			}else {
				propStatus+=", Move-In Ready";
			}
		}
		//======propType========
		comHtml = comHtml
				
				.replace("Duplexes in Bozeman", "Duplexes homes in Bozeman").replace("The Bungalow</b> returns to the origins", "Bungalow-style homes").replace("Crafts design", "Craftsman style details").replace("detached apartment", "detached homes")
				.replace("farmhouse inspired", "Farmhouse Style Homes").replace("The Craftsman revisits the revered Arts ", "The craftman-style homes revisits the revered Arts ")
				.replace("farmhouse inspired townhomes", "farmhouse inspired townhomes").replaceAll("Farmhouse, Modern Agrarian, and Craftsman elevations set amongst the", "")
				.replace("Mediterranean detail influences prevalent in this design", "Mediterranean-Style Homes detail influences prevalent in this design");
		String proptype=ALLOW_BLANK;
		String des[] = U.getValues(comHtml, "<div class=\"collection-view__title\">", "<div class=\"collection-view__section-residences\">");
		
		String coms=(U.getSectionValue(comHtml, "community-welcome__heading","</div>")+U.getSectionValue(comHtml, "microsite-hero__detail", "</div>")).replace("detached apartment", "detached homes, apartment homes").replace("custom-quality homes", "custom luxury homes");

		//U.getSectionValue(comHtml, "<div class=\"collection-view__description\">", "</div>")
		
			
		
		commDesc=commDesc.replaceAll("Farmhouse, Modern Agrarian, and Craftsman elevations set amongst", "");
		
		
		communityHtml=communityHtml.replace("Country Club&quot;", "")
				.replace("homes with detached apartments", "homes with detached homes")
				.replace("Craftsman, Bungalow, Farmhouse duplex and triplex designs", "Craftsman style details, Bungalow homes, Farmhouse Series duplex and triplex designs");
		//lotmapjson

		for(String d : des)
			if(d.contains(commName))
				coms+=d;
		
		if (floorPlanHtml.trim().length()==0) {
			U.log("======1");
//			proptype=U.getPropType(comHtml);
			proptype=U.getPropType((welcomeCommunitySec+communityHtml+comSec).replace("luxury attached homes", "luxury of having attached homes"));
		}else {
			U.log("======2");
			commDesc = commDesc.replace("Craftsman elevations", "craftsman style elevations");
			floorPlanHtml = floorPlanHtml.replace("-level", " story").replace("detached apartment", "detached homes, apartment homes").replace("custom-quality homes", "custom luxury homes");
			proptype=U.getPropType((welcomeCommunitySec+communityHtml+commDesc+cards+floorPlanHtml+coms+comSec).replace("luxury attached homes", "luxury of having attached homes").replaceAll("low HOA of $254 a month", ""));
		}
		
//		U.log("mmmmmm"+Util.matchAll(communityHtml+commDesc+cards+floorPlanHtml+coms+comSec, "[\\w\\s\\W]{100}[\\w\\s\\W]{100}", 0));

//		U.log("proptype====="+proptype);
		U.log("proptype====="+proptype);
		//======d-propType========
		String remSec1=U.getSectionValue(html1, "Our Communities</button>", "Get Updates</button>");
		if(remSec1.length()>20) {
			html1=html1.replace(remSec1, "");
		}
//		String html=comHtml+html1;
		String []remData=U.getValues(comHtml, "Community of Interest", "Sign up today!");
		for(String remdata : remData) {
			comHtml=comHtml.replace(remdata, "");
		}
		String []remData1=U.getValues(html1, "Community of Interest", "Sign up today!");
		for(String remdata : remData1) {
			html1=html1.replace(remdata, "");
		}
		
		comHtml = comHtml.replace(" fourth floor", " 4 Story").replace(" third floor", " 3 Story")
				.replace(" second floor", " 2 Story");
		comHtml=comHtml.replaceAll("-ranch|San Luis Ranch Community|Williams Ranch|San Luis Ranch","");
		String rem = "San Luis Ranch.|Ranch (Road|Rd)|Williams Ranch|-ranch";
		
//		U.writeMyText(comHtml+commDesc+cards+floorPlanHtml);
		String dproptype=ALLOW_BLANK;
		if (floorPlanHtml.trim().length()==0) {
			dproptype=U.getdCommType((welcomeCommunitySec+html1).replaceAll("finch-ranch|Finch Ranch", ""));
//			U.log("mmmmmm"+Util.matchAll(html1, "[\\w\\s\\W]{100}ranch[\\w\\s\\W]{100}", 0));
		
			U.log("0====");
		}else {
			
			U.log("1====");
			floorPlanHtml=floorPlanHtml.replace("second floor features a large kitchen ", "2 Story features a large kitchen ");
			dproptype=U.getdCommType((welcomeCommunitySec+html1+comHtml+commDesc+cards+floorPlanHtml).replaceAll("finch-ranch|Finch Ranch Community|floor", "")
					.replace("Floor|floor", "").replace("1 Story 3-bedroom", "1 Story     3-bedroom").replace("third floor with a spa-like bath and a deck", "3 Story with a spa-like bath and a deck").replaceAll(rem, ""));

//						U.log("mmmmmm"+Util.matchAll(html1+comHtml+commDesc+cards+floorPlanHtml, "[\\w\\s\\W]{100}ranch[\\w\\s\\W]{100}", 0));
			//U.log("0 else ===="+dproptype);
		}
		

		U.log("dproptype====="+dproptype);
		
		//======propType========
		String note=ALLOW_BLANK;
		if (floorPlanHtml.trim().length()==0) {
			note=U.getnote(comHtml);
		}else {
			note=U.getnote(commDesc+cards+floorPlanHtml);
		}

		//==========lat lng==============
		
		String add[] = {ALLOW_BLANK,ALLOW_BLANK, ALLOW_BLANK,ALLOW_BLANK};
		String latlon[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		String addLatSec=ALLOW_BLANK;
		addLatSec=U.getSectionValue(comHtml, "Community Location</h4>", "<em>View Map</em></a>");
		if(addLatSec==null) {
		addLatSec=U.getSectionValue(comHtml, "<h3 class=\"community-welcome__contact-title\">Sales Office</h3>",
				"<em>View Map</em></a>");}
		
		
		if(addLatSec==null) {
			addLatSec=U.getSectionValue(comHtml, "Welcome Center</h3>", "<em>Get Directions</em></a>");
		U.log(addLatSec);	
		}
		U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{400}28801 Hasley Canyon Road[\\w\\s\\W]{400}", 0));

		
		String addSec=null;
		 U.log(">addSec>>>>>>>   "+addLatSec);
		 
		 
		if(addLatSec==null) {
			String LatSec=U.getHTML("https://www.williamshomes.com/api/communities?min-price=0&max-price=10000000");
			//U.log(">>>>>>>> LatSec:  "+LatSec);
			
			String[] CommSec=U.getValues(LatSec, "\"region_id\":", " \"features_summary\": ");
			for(String Sec : CommSec) {
				if(Sec.contains(commName))
				{
					String lat=U.getSectionValue(Sec, "\"latitude\":", ",");
					String log=U.getSectionValue(Sec, "\"longitude\":", ",");
					latlon[0]=lat;
					latlon[1]=log;
				}
			}
		}
		else 
		{	
			
			 addSec=U.getSectionValue(addLatSec, "address\">", "<a href=").replace("&nbsp;", "").replace("<br>", ", ").replace("CA                             91384", "CA, 91384").trim();
			 U.log(">>>>>>>>   "+addSec);
			 String latlogSec=U.getSectionValue(addLatSec, "\"https://maps.google.com/maps?daddr=", "\"");
			 latlogSec=latlogSec.replace("+", ",");
//			 U.log(">>>>>>>>   "+latlogSec);
			 latlon=latlogSec.split(",");
			 add = U.getAddress(addSec);
			U.log(Arrays.toString(add));
		}
		
//		latlon[0]=U.getSectionValue(comHtml, ":lat=\"", "\"");
//		latlon[1]=U.getSectionValue(comHtml, ":long=\"", "\"");
		U.log("latLong :"+Arrays.toString(latlon));
		
		//========= Address ==========
		
		
		U.log("Add ::"+add[0]+"\t"+add[1]+"\t"+add[2]+"\t"+add[3]);
		
		if(add[0] == ALLOW_BLANK) {
			
			if(comHtml.contains("Harvest Lofts Sales Office")) {
				
				String sec = U.getSectionValue(comHtml, "sales-address\">", "<a href=").trim();
				sec = sec.replace("<br>", ", ").replace("93405,", "93405");
				
				U.log("sec: "+sec);
				
				add = U.getAddress(sec);
				U.log("ADD  :"+Arrays.toString(add));
			}
			
			if(comHtml.contains("Vineyard Sales Office")) {
				
				String sec = U.getSectionValue(comHtml, "sales-address\">", "<a href=").trim();
				sec = sec.replace("<br>", ", ").replace("91384,", "91384");
				
				U.log("sec: "+sec);
				
				add = U.getAddress(sec);
				U.log("ADD  :"+Arrays.toString(add));
			}
			
			if(comHtml.contains("Community Location")) {
				
				String sec = U.getSectionValue(comHtml, "Community Location</h4>", "<a href=").trim();
				sec = sec.replace("<br>", ", ").replaceAll("<p class=\"community-contact__address\">|&nbsp;&nbsp;&nbsp;", "");
				
				U.log("sec: "+sec);
				
				add = U.getAddress(sec);
				U.log("ADD  :"+Arrays.toString(add));
			}
		}
		
		if(add[3].isEmpty()) add[3]= ALLOW_BLANK;
		if(add[2].isEmpty()) add[2]= ALLOW_BLANK;
		if(add[1].isEmpty()) add[1]= ALLOW_BLANK;
		
		if (add[0]==ALLOW_BLANK || add[3] == ALLOW_BLANK) {
			String add1[] = U.getAddressGoogleApi(latlon);
			if(add1 == null) add1 =U.getAddressHereApi(latlon);
			if(add[0] == ALLOW_BLANK) add[0] = add1[0];
			if(add[3] == ALLOW_BLANK) add[3] = add1[3];
			if(add[1] == ALLOW_BLANK) add[1] = add1[1];
			if(add[2] == ALLOW_BLANK) add[2] = add1[2];
			geo = "True";
		}
		U.log(add[0]);
		if(add[3] == ALLOW_BLANK && add[2] == ALLOW_BLANK){
			if(latlon[0] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latlon);
				if(add == null) add =U.getAddressHereApi(latlon);
				geo = "True";
			}
		}
		
		U.log(Arrays.toString(add));
		
		U.log(add[0]);
		U.log(add[1]);
		U.log(add[2]);
		U.log(add[3]);
		
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/bozeman/willson-16")) 
		{
			add[0] = "495 N Willson Ave";
			add[1] = "Bozeman";
			add[2] = "MT";
			add[3] = "59715";
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/the-paseos")) {
			add[0]="4189 Bettenford Dr";
		}
if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/the-arroyos")) {
	add[0]="4189 Bettenford Dr";
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/bozeman/west-winds")) {
			add[0] = "1375 New Holland Drive";
			add[1] = "Bozeman";
			add[2] = "MT";
			add[3] = "59718";
		}
		
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/boise/forsythia-place")) {
			
			add[0] = "West Forsythia Drive & Hill Road";
			add[1] = "Boise";
			add[2] = "ID";
			add[3] = "83703";
			
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/san-luis-ranch/communities/fig")){
			minPrice=ALLOW_BLANK;
			minSqft = "1,346";
			maxSqft = "1,501";
			propStatus="Coming Soon";
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/san-luis-ranch/communities/heirloom")){
			minSqft = "1,544";
			maxSqft = "2,115";
			proptype = proptype.replace("Townhomes", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
			propStatus="Now Selling";
		}
		
		
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/iron-and-oak")||comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/the-arroyos")) {
			propStatus=propStatus.replace("Temporarily Sold Out, Sold Out, ", "");
		}
		
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/the-paseos")) {
			propStatus=propStatus.replace(", Move-In Ready", "");
			
//			minPrice="$806,100";
//			maxPrice=ALLOW_BLANK;
			//proptype+=", Craftsman Style Homes";
			
		}

		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/the-arroyos")) {
/*			minPrice="$877,484";
			minSqft="1722";
*/			propStatus=propStatus.replace(", Move-In Ready", "");
//			proptype+=", Craftsman Style Homes";
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/iron-and-oak")) {
			minSqft="1296";
			maxSqft="1736";
			
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/bozeman/willson-16")) {
			propStatus=propStatus.replace("Sold Out, ", "");
		
		}
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/san-luis-obispo/righetti/communities/the-arroyos")) {minPrice="$971,525";maxPrice=ALLOW_BLANK;}
		
	if(comUrl.contains("/san-luis-obispo/righetti")) { 
		commName=commName.replace("at Righetti", "");
//		san-luis-obispo/righetti
		commType="Master Planned";
		
	}
		
		if(moveInSection!=null) {
			if(propStatus.length()>1)
				propStatus=propStatus+", Move in ready";
			else
				propStatus="Move in ready";
			
		}
		
		if(comUrl.contains("east-helena/highland-meadows")||comUrl.contains("-communities/georgetown/enclave"))
		{
			if(proptype.length()>1)
				proptype=proptype+", Single Family";
			else
				proptype="Single Family";
		}
		
		
		
		String siteMap = "";
		String lotsIds="";
		if(comHtml.contains("is=\"siteplan-map\"")) {
			String lotmapData  = U.getSectionValue(U.getPageSource(comUrl), " let JsonData = {", "</script>");
//			U.log(lotmapData);
			lotsIds=Util.matchAll(lotmapData, ",\"residence_id\":", 0).size()+"";
		} 
		if(lotsIds.length()<1 || lotsIds.equals("0")) lotsIds=ALLOW_BLANK;
		U.log(lotsIds);
		propStatus=propStatus.replace("Final Phase Just Released, Final Phase", "Final Phase Just Released");
		commName = commName.replace("Villas", "");
		
		
		
		if(comUrl.contains("https://www.williamshomes.com/new-home-communities/ventura/finch-ranch")) propStatus = "Coming Soon";
		if (comUrl.contains("https://www.williamshomes.com/new-home-communities/ventura/shoreline")) propStatus = ALLOW_BLANK;
		
		data.addCommunity(commName, comUrl,commType);
		data.addAddress(add[0].replace("&amp;", "&"), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlon[0].trim(), latlon[1].trim(), geo);
		data.addPropertyType(proptype, dproptype);
		data.addPropertyStatus(propStatus.replace("Temporarily Sold Out, Sold Out", "Temporarily Sold Out").replace("Sold Out, Move-In Ready", "Move-In Ready"));
		data.addNotes(note);
		data.addUnitCount(lotsIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
	i++;
//	}catch(Exception e) {}
	}
}