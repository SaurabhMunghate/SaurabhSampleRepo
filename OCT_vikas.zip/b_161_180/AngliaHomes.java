package com.shatam.b_161_180;


import java.util.*;

import org.apache.bcel.generic.CPInstruction;
import org.hamcrest.text.X;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.mobile.AddNetworkConnection;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.Sspi.PSecHandle;

public class AngliaHomes extends AbstractScrapper {
	int i = 0;
	static String HOME_URL = "https://www.angliahomeslp.com";
	static String BUILDER_NAME = "Anglia Homes";
	static int duplicates = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	public int inr = 0;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new AngliaHomes();
		//U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath()+"Anglia Homes.csv", a.data().printAll());
		U.log(duplicates);
	}

	public AngliaHomes() throws Exception {

		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver=new ChromeDriver();
		String html = U.getHTML("https://www.angliahomeslp.com/new-homes");
		int j= 0;
		//U.log(sec);
//		String sec = U.getSectionValue(html, "data = eval({", "]});");
//		String comsec[] = U.getValues(sec, ",\"ID\":", "}");
		String comSec[] = U.getValues(html, "data-mh=\"commimagedata\">","View Community</a></div>");
		
		String latSec = U.getSectionValue(html, "var locations = [", "]");
		String comMapSec[] = U.getValues(latSec, "{", "}");
		List<String> latsecList = Arrays.asList(comMapSec);
		U.log("comSec.length:"+comSec.length);
		
		for(String commsec : comSec) {
			String url = U.getSectionValue(commsec, "<a href=\"", "\"");
			U.log(+j+" url: "+url);
			j++;
			for(String x: latsecList) {
//			latsecList.forEach(x -> {
				if(x.contains(url)) {
						U.log("url===="+"https://www.angliahomeslp.com"+url);
//						if(data.communityUrlExists(url)){
//							LOGGER.AddCommunityUrl(url+"============>>>>>>Repeated");
//						}
//						LOGGER.AddCommunityUrl(url);
//					try {
						addNewDetails(url,commsec+"\n"+x);
//					} catch (Exception e) {
						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				}
			}
//			);
//			adDetails(commsec , html);
			
		}
//		adDetails("Houston Area\",\"LOCATIONID\":1,\"ZIP\":77449,\"COMMLINK\":\"/communities/community-detail/Windstone-Colony-South-15.cfm\",\"LONGITUDE\":-95.717340,\"PHONE\":\"\",\"REGIONDESC\":\"West Houston\",\"STATE\":\"Texas\",\"TEXT\":\"Discover new home communities and houses for sale in West Houston. Anglia Homes has developments in the greater Houston areas of Katy TX, Cypress TX and Brookshire TX. New houses are growing in abundance for your single-family lifestyle. Find ranch style house floor plans and 3- to 5-bedroom home plans, as well as an inventory of move-in ready homes for sale. Check out each individual new home development to explore more about West Houston area school systems and communities with easy access to Interstate 10 and the Grand Parkway plus other several other neighborhood specific features.\",\"PRIMARYMARKER\":0,\"METAKEYWORDS\":\"\",\"REGIONID\":9,\"COMMUNITY_ID\":15,\"LEGACY\":\"\",\"COMMUNITYLISTIMAGE\":\"list image9.jpg\",\"ID\":15,\"ADDRESS1\":\"4335 Careybrook Lane \",\"TYPE\":\"\",\"ADDRESS2\":\"\",\"LONG\":-95.717340,\"METADESCRIPTION\":\"Find new home communities built by Anglia Homes just west of Houston, TX in the cities of Katy, Brookshire and Cypress with easy access to Interstate 10 and the Grand Parkway plus featuring ranch style and 2-story floor plans with 3- to 5-bedroom designs available.\",\"PRICERANGE\":\"\",\"THUMBNAIL\":\"\",\"METATITLE\":\"West Houston New Home Communities\",\"COMMUNITY_NAME\":\"Windstone Colony South\",\"NAME\":\"Windstone Colony South\",\"CITY\":\"Katy\",\"DYNAMICMAPIMAGE\":\"\",\"ADDRESS\":\"4335 Careybrook Lane \",\"TITLE\":\"New Home Communities & Houses for Sale in West Houston\",\"LATITUDE\":29.836302,\"SHORTDESCRIPTION\":\"<p>Katy, Texas 77449</p>\\r\\n<p>Single Family Homes From $190's</p>\\r\\n<p>Sq Ft 1671 - 2941</p>\",\"LAT\":29.836302,\"SECONDARYTAGLINE\":","");
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addNewDetails(String url, String commsec) throws Exception {
		// TODO Auto-generated method stub
		String commUrl =  HOME_URL+url;
		
//		if(!commUrl.contains("https://www.angliahomeslp.com/new-homes/texas/south-houston/angleton/riverwood-ranch"))return;
		//HTML 
//		U.log(o);
		String commHtml = U.getHTML(commUrl);
		//Logger
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"============>>>>>>Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		U.log("commUrl>>>>: "+commUrl);
		//ComName
//		U.log(commsec);
		String commName = U.getSectionValue(commsec, "<h2>","</h2>");
		commName = commName.replace("<small> - Coming Soon</small", "").replace("Willow Trace <small> - Coming Soon</small>", "Willow Trace")
				.replace("Bayou Bend <small> - Coming Soon</small>", "Bayou Bend").replace(">", "");
		
		U.log("commName :"+commName.replace("<small> - Coming Soon</small>", ""));
		
		//latLong 
		String latLong[] = {ALLOW_BLANK,ALLOW_BLANK};
		latLong[0] = U.getSectionValue(commsec, "lat: ", ",");
		latLong[1] = U.getSectionValue(commsec, "lng: ", ",");
		U.log("latLong: "+Arrays.toString(latLong));
		
		//Address 
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "False";
		String addSec=null;
		if(commUrl.contains("/lakes-at-crockett-martin")) {
			addSec= U.getSectionValue(commHtml, "Community Location</h4>", "<hr>").replace("Texas -> South Houston -> Texas City", "");
		}
		if(addSec==null) {
			addSec= U.getSectionValue(commHtml, "Community Location</h4>", "<hr>");
		}
//		if(addSec==null && commUrl.contains("/new-homes/texas/north-houston/spring/willow-trace")) {
//			addSec= U.getSectionValue(commHtml, "Community Location</h4>", "<br> ");
//			//U.log("addSec from here: "+addSec);
//		}
		U.log(addSec);
		if(addSec==null && commUrl.contains("/new-homes/texas/south-houston/angleton/bayou-bend")) {
			addSec= U.getSectionValue(commHtml, "Community Location</h4>", "<hr>");
			U.log("addSec from here: "+addSec);
		}
		if(addSec==null ) {
			addSec= U.getSectionValue(commHtml, "> Sales Office Location</h4>", "<h4").replace("Texas -> South Houston -> Texas City", "South Houston");
		}
		
		if(commUrl.contains("/north-houston/magnolia/audubon")) {
			addSec=addSec.replace("<br>", "").replace("40207 Bay Warbler Ct.  Magnolia, TX , TX 77354 ", "40207 Bay Warbler Ct, Magnolia, TX 77354");
		}
		
		
		U.log("addSec:::::::"+addSec);
		if(addSec.contains("Call for Appointment")) {
			addSec= U.getSectionValue(commHtml, "Community Location</h4>", "<hr>").replace("Texas -> South Houston -> Texas City", "");
		}
		add = U.findAddress(addSec.replace("<br>", ",").replace("Call for Appointments", ""));
		if(add==null)add = addSec.replace("Texas", "TX, ").replace("TX 7", "TX, 7").replaceAll("TX,\\s*City", "Texas City").replace("<br>","").split(",");
		if(add.length==3) {
			add = U.getAddressGoogleApi(latLong);
			geo = "True";
		}
		add[0]=add[0].replace(" TX", "");
		add[1]=add[1].replace(" TX", "");
		U.log(Arrays.toString(add));
		//===========================================UNIT COUNT==================
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		if(commHtml.contains("map_iframe")) {
			String mapLink=U.getSectionValue(commHtml, "<iframe name=\"map_iframe\" src=\"", "\"");
			U.log("mapLink ::"+mapLink);
			String lotHtml=U.getHtml(mapLink, driver);
			U.log(U.getCache(mapLink));
			String[] lotSection=U.getValues(lotHtml, "<area shape=\"poly", "/>");
			counting=Integer.toString(lotSection.length);
		}
		
		U.log("counting ::"+counting);
		
		//--------Quick Homes data
		String allQuickHomesData = ALLOW_BLANK;
		String allPlansData =ALLOW_BLANK;
		
		String quickHomesUrls[] =U.getValues(commHtml, "<td style=\"text-align:center\"><a href=\"", "\"");
		for(String quickHomeUrl : quickHomesUrls){
			quickHomeUrl = "https://www.angliahomeslp.com"+quickHomeUrl;
			String quickHomeHtml = U.getHTML(quickHomeUrl);
//			U.log("quickHomeUrl : "+quickHomeUrl);
			allQuickHomesData += U.getSectionValue(quickHomeHtml, "<div class=\"col-md-12 detailheader\">", "Request More Information</a>"); 
		}
		
		String allPlans[] =U.getValues(commHtml, "<div class=\"modelimageholder\">", "</table>");
		for(String planUrl : allPlans){
			planUrl = "https://www.angliahomeslp.com"+U.getSectionValue(planUrl, "<a href=\"", "\"");
			String planHtml = U.getHTML(planUrl);
//			U.log("planUrl : "+planUrl);
			allPlansData += U.getSectionValue(planHtml, "<div class=\"col-md-12 detailheader\">", "Request More Information</a>"); 
		}
		//Price
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commsec = commsec.replaceAll("0's|0’s|&rsquo;s", "0,000");
		commHtml = commHtml.replace("0&rsquo;s", "0,000")
				.replace("home designs begin from the $280s", "home designs begin from the $280,000");
		
		String[] price = U.getPrices(commHtml + commsec, "\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

//     	U.log("MMMMMMM"+Util.matchAll(commHtml, "[\\w\\s\\W]{30}home designs begin from the[\\w\\s\\W]{30}", 0));

		
		
		// Sqft
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		commHtml=commHtml.replaceAll("Square Feet:\\s*</td>\\s*<td valign=\"top\">", "Sq. Ft.: ");
		String[] sqft = U.getSqareFeet(commHtml + commsec+allQuickHomesData,
				"from \\d,\\d{3} square feet to more than \\d,\\d{3}|Sq. Ft.: \\d+,\\d+|\\d+ - \\d+ Sq.Ft.|Sq Ft \\d{4} - \\d{4}|Sq Ft</strong><br>\\s*\\d{4} - \\d{4} |Sq Ft</strong><br>\\s*\\d{4}\\s+", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//commType
		String comType =ALLOW_BLANK;
		comType=U.getCommunityType(commHtml+commsec+commName.replace("first class golf and water sports.", "first class golf course and water sports."));
		
		//Ptype 
		String propertyType = ALLOW_BLANK;
		allPlansData = allPlansData.replace("luxury owners retreat", "luxury homes");
		propertyType = U.getPropType((commHtml+commsec+allQuickHomesData+allPlansData).replace("luxury owner&#39;s retreat", "luxury homes")
				.replaceAll("Village|single-family\"|Townhomes-31.cfm\">|location paired with|Bammel Trace Single Family</a></li>", "").replaceAll("Townhomes</a>|Bammel Trace Single Family</a></li>", ""));
		
		
		
		//Dtype 
		String dtype = ALLOW_BLANK;
		dtype = U.getdCommType((commHtml+allQuickHomesData+allPlansData+commsec).replaceAll("Riverwood Ranch</a>",""));
		
		//status
		commHtml=commHtml.replaceAll("Now Selling-Model Coming Soon|Now Selling-Model Coming Soon|Now Selling,&nbsp;Model Home Coming Soon|Now Selling, Model Home Coming Soon","");
		commsec= commsec.replaceAll("Now Selling-2.jpg|TX Coming Soon|Model Coming Soon|New Model Now Open", "");
		String status = U.getPropStatus(commHtml.replaceAll("Garage, Now Available|Lagoon Coming Soon| Dog Park Now Open|New Model Homes Coming Soon|Lagoon - Coming|Optional 3-Car Garage, Now Available|Inventory Homes|Hours</h4>\\s+<p><strong>Coming|Garage, Now|New Model Homes Coming Soon|New Model Now Open", "") + commsec.replaceAll("Garage Now Available|New Model Now Open| Dog Park Now Open", ""));
//     	U.log("MMMMMMM"+Util.matchAll(commHtml, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));
//     	U.log("MMMMMMM111"+Util.matchAll(commsec+commHtml, "[\\w\\s\\W]{30}New Section Now Selling[\\w\\s\\W]{30}", 0));
if(commUrl.contains("mont-belvieu/champions-forest"))status="New Section Now Selling";





		int   invCount=0;
		if(commHtml.contains("<h2>Inventory Homes</h2>")) {
			String[] inventory_data=U. getValues(commHtml, "<td style=\"text-align:center\"><a href=", "</tr>");
			if(inventory_data.length>0) {
				for(String iData : inventory_data) {
					if(iData.contains("Available Now")) {
						invCount++;
					}
				}
			}
			
		}
		if(invCount>0) {
			if(status.length()>5) {
				status=status+", Quick Move-In";
			}
			else {
				status="Quick Move-In";
			}
		}



		
		data.addCommunity(commName, commUrl, comType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPropertyType(propertyType,dtype);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(commHtml));
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}


	
	public void adDetails(String commsec, String mainHtml) throws Exception {
	//TODO : For single community execution
//	if(j == 8)
//		try{
	{
//		U.log("count :"+ j);

		String commUrl = HOME_URL
				+ U.getSectionValue(commsec, "COMMLINK\":\"", "\"").replace(
						"\\/", "/");
//		if(!commUrl.contains("https://www.angliahomeslp.com/new-homes/texas/south-houston/angleton/heritage-park"))return;
//		U.log("MMMMMMMm "+commsec);
		
//		if(commUrl.contains("Windstone-Colony-South-15.cfm"))return;//redirected
		U.log(commUrl);
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"============>>>>>>Repeated");
		}
		LOGGER.AddCommunityUrl(commUrl);
		String commHtml = U.getHTML(commUrl);
		String commName = U.getSectionValue(commsec, "COMMUNITY_NAME\":\"",
				"\"");
		
		U.log("commName :"+commName);
		String visibleComMainSec = U.getSectionValue(mainHtml, "<h2>"+commName, "View Community"); //+" </h2>"
		
//		U.log(visibleComMainSec);
		String lat = U.getSectionValue(commsec, "LATITUDE\":", ",");
		String lng = U.getSectionValue(commsec, "LONGITUDE\":", ",");
		String address = U.getSectionValue(commsec, "ADDRESS1\":\"", "\"");
		String city = U.getSectionValue(commsec, "CITY\":\"", "\"");
		//U.log(U.getSectionValue(commsec, ":\"", "\""));
		String state = USStates.abbr(U.getSectionValue(commsec, ":\"", "\""));
		state = (state == null) ? ALLOW_BLANK : state;
		U.log("lattttt"+lat);	
		U.log("lnggggg"+lng);
		String zip = U.getSectionValue(commsec, "ZIP\":", ",\"").replaceAll(
				"\\.0", "");
		String geo = "False";
		if(address==ALLOW_BLANK)address=U.getSectionValue(commHtml, "<span itemprop=\"streetAddress\">", "</span");
		if(city==ALLOW_BLANK)city=U.getSectionValue(commHtml, "<span itemprop=\"addressLocality\">", "</span");
		if(state==ALLOW_BLANK)state=U.getSectionValue(commHtml, "<span itemprop=\"addressRegion\">", "</span");
		if(zip==ALLOW_BLANK)zip=U.getSectionValue(commHtml, " <span itemprop=\"postalCode\">", "</span");
//		newAdrress section
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addsec=U.getSectionValue(commHtml, "Sales Office Location</h4>", "</h4>");
		if(addsec!=null) {
			U.log(addsec);
			addsec=addsec.replaceAll("<br> ", ",").replaceAll("By Appointment Only|Call for Appointment", "");
			add=U.findAddress(addsec);
			U.log(Arrays.toString(add));
			if(add!=null) {
			address=add[0];city=add[1];state=add[2];zip=add[3];}
		}
		address =address.replaceAll("By Appointment Only|Call for Appointment|By Appointment Only", "");

		//--------Quick Homes data
				String allQuickHomesData = ALLOW_BLANK;
				ArrayList<String> quickHomesUrls = Util.matchAll(commHtml, "<td style=\"text-align:center\">\\s*<a href=\"(.*?)\"",1);
				for(String quickHomeUrl : quickHomesUrls){
					quickHomeUrl = "https://www.angliahomeslp.com"+quickHomeUrl;
					String quickHomeHtml = U.getHTML(quickHomeUrl);
					U.log("quickHomeUrl : "+quickHomeUrl);
					allQuickHomesData += U.getSectionValue(quickHomeHtml, "<div class=\"col-md-12 detailheader\"><h1>", "Request More Information</a>"); 
				}
	
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commsec = commsec.replaceAll("0's|0’s|&rsquo;s", "0,000");
		commHtml = commHtml.replace("0&rsquo;s", "0,000");
		
		String[] price = U.getPrices(commHtml + commsec, "\\$\\d+,\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// Sqft
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		commHtml=commHtml.replaceAll("Square Feet:\\s*</td>\\s*<td valign=\"top\">", "Sq. Ft.: ");
		String[] sqft = U.getSqareFeet(commHtml + commsec+allQuickHomesData+visibleComMainSec,
				"from \\d,\\d{3} square feet to more than \\d,\\d{3}|Sq. Ft.: \\d+,\\d+|\\d+ - \\d+ Sq.Ft.|Sq Ft \\d{4} - \\d{4}|Sq Ft</strong><br>\\s*\\d{4} - \\d{4} |Sq Ft</strong><br>\\s*\\d{4}\\s+", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//		U.log(allQuickHomesData);
		if (address.length() == 0)
			address = ALLOW_BLANK;
		lng = lng.replaceAll("\"", "");

		String standard = U.getHTML("https://www.angliahomeslp.com"
				+ U.getSectionValue(commHtml, "</a> <a href=\"", "\""));
		commHtml=commHtml.replace("GatedResidenceCommunity", "");
	//	U.log(commHtml);

		String rem = U.getSectionValue(commHtml, "<head>", "</head>");
		if(rem != null) commHtml = commHtml.replace(rem, "");
		
		String comType = U.getSectionValue(commHtml,
				"<div class=\"container\">", "<h1>");
		
		commHtml = commHtml.replace(comType, "").replace("New Section - Now Selling", "New Section Now Selling").replaceAll("More Information Coming Soon|More information coming soon", "");
		comType = U.getCommunityType(commHtml+commsec+comType+commName.replace("first class golf and water sports.", "first class golf course and water sports."));
		
		
		String statusline=U.getSectionValue(commHtml,"<h3 style=\"text-align: center;\">", "</h3>");
		commsec=commsec.replaceAll("More information coming soon| Dog Park Now Open|\"Coming Soon!-resized231.jpg|as well as an inventory of move-in ready homes|Golf Course Lots Available| Garage Now|New Model Homes Coming Soon", "");
//				.replace("Coming Soon - 2018", "Coming Soon 2018");
		//commsec = commsec.replace("COMMUNITYSTATUS\":0", "COMMUNITYSTATUS\":Coming Soon");
//		U.log("::::::"+commsec+"::::Hellllllllllllllllllllllllllllllloooooooooooooooooooooo");
     	U.log("mmmmmm"+Util.matchAll(commHtml+commsec+statusline, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));

		//.replace("oversized lots and lake lots", "oversized and lake lots available").
		String status = U.getPropStatus(commHtml.replaceAll("Lagoon Coming Soon| Dog Park Now Open|New Model Homes Coming Soon|Lagoon - Coming|Optional 3-Car Garage, Now Available|Inventory Homes|Hours</h4>\\s+<p><strong>Coming|Garage, Now|New Model Homes Coming Soon", "") + commsec+statusline);
				

		commHtml = U.getHTML(commUrl);
		if (commHtml.contains("<p>NOW SELLING</p>")) {
			if (status != ALLOW_BLANK) {
				status = status + ",Now Selling";
			} else
				status = "Now Selling";
		}
		String drop =U.getSectionValue(commHtml, "Full Community List</a></li>", "<h1>");
		//U.log("drop::"+drop);
		if(drop!=null)commHtml=commHtml.replace(drop, "");
		if (address == ALLOW_BLANK) {
			String[] latlng = { lat, lng };
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			U.log("My Address: " + Arrays.toString(add));
			if (add[1].contains(city)) {
				address = add[0];
			}
			if (address == ALLOW_BLANK) {
				address = add[0];
				state = add[2];
			}
			if(zip==ALLOW_BLANK || zip.length()<4){
				zip=add[3];
			}
			geo = "TRUE";
			U.log(state);

		}
		
		if(state==ALLOW_BLANK || state==null){
			String[] latlng = { lat, lng };
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			state=add[2];
			city=add[1];
			if(zip != null && zip.equals("\"\"")) zip = add[3];
			U.log(state);
			U.log("zip =="+zip);
		}
		// U.log("commsec : "+Util.match(commsec, ".*?MOVE-IN READY HOMES.*?"));
		if(state!=null && state.length()>2)state=USStates.abbr(state);
		
		//--------floor plans data
				String allFloorplans = ALLOW_BLANK;
				String floorplanSec= U.getSectionValue(commHtml, "<div class=\"modelimageholder", "<div class=\"row top-buffer\">");
				if(floorplanSec!=null) {
				String[] floorUrls = U.getValues(floorplanSec, "<div data-mh=\"modeltitle\"><a href=\"", "\"");

				for(String planurl : floorUrls){
//					U.log(planurl);
					planurl = "https://www.angliahomeslp.com"+planurl;
					String floorHtml = U.getHTML(planurl);
					U.log("floorHtml : "+planurl);
					allFloorplans += U.getSectionValue(floorHtml, "<h1>", "Request More Information"); 
				}}
		//-------Property Type --------
		String propertyType = ALLOW_BLANK;
		commHtml=commHtml.replaceAll("Bammel Trace Single Family", "-")
				.replace("- Farmhouse</div>", "Farmhouse architectural styles");
		commsec=commsec.replace("Anglia Homes has new single-family homes in the greater Houston", "");
		propertyType = U.getPropType((commHtml+commsec+allQuickHomesData+allFloorplans).replace("luxury owner&#39;s retreat", "luxury homes")
				.replaceAll("Riverwood Ranch</a>|Village|single-family\"|Townhomes-31.cfm\">|location paired with|Bammel Trace Single Family</a></li>", "").replaceAll("Townhomes</a>|Bammel Trace Single Family</a></li>", ""));
		if(commName.endsWith(" Townhomes"))commName=commName.replace(" Townhomes", "");
		
		if(commUrl.contains("https://www.angliahomeslp.com/new-homes/texas/north-houston/houston/imperial-green"))
			quickHomesUrls.clear();
		if(quickHomesUrls.size()>=1) {
			if(status.length()<3) {
				status="Inventory Homes Available";
			}
			else {
				status=status+", Inventory Homes Available";
			}
		}
		commHtml= commHtml.replaceAll("Stories:</td>\n\\s*<td valign=\"top\">2", "2 Story").replaceAll("Stories:</td>\n\\s*<td valign=\"top\">", "Story ")
				.replaceAll("Riverwood Ranch</a>|ranch-style single-family homes for sale\\.\">|Ranch</a></li>|-ranch\" ", "");
		String dtype=U.getdCommType(commHtml+allQuickHomesData);
		
		
		if(commUrl.contains("https://www.angliahomeslp.com/new-homes/texas/west-houston/richmond/riverwood-village"))
			dtype = dtype.replace("Ranch,", "");
		//multiple instances of now selling apperaed so added manually dt : 23Aug21
		if(commUrl.contains("/east-houston/mont-belvieu/champions-forest"))status =status.replace("Now Selling", "New Section Now Selling");
		commHtml  =commHtml.replaceAll("Stories:</td>\\s*<td valign=\"top\">", " Stories ");
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(commName, commUrl, comType);
		data.addAddress(address, city, state, zip);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(propertyType,dtype);
		data.addPropertyStatus(status);
		data.addNotes(U.getnote(commHtml));
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}
//		j++;
//		}catch(Exception e) {}
	}
	
}
