package com.shatam.b_161_180;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.GetLink;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEagleConstruction extends AbstractScrapper {
	CommunityLogger LOGGER;
	
	static int j=0;

	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new ExtractEagleConstruction();
		a.process();
		//a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Eagle Construction of Virginia.csv", a.data()
				.printAll());
	}

	public ExtractEagleConstruction() throws Exception {
		super("Eagle Construction of Virginia", "https://www.eagleofva.com/");
		LOGGER = new CommunityLogger("Eagle Construction of Virginia");
	}

	public void innerProcess() throws Exception {
		String mainHtml = U.getHTML("https://www.eagleofva.com/new-homes/");
		String[] secs = U.getValues(mainHtml, "<div class=\"card oi-map-item\"", "view community</a>");
		for(String sec:secs)
		{
			addDetails(sec);
		}
		
		LOGGER.DisposeLogger();
	}
	

	private void addDetails(String sec) throws Exception {
		// TODO Auto-generated method stub
//	if(j==1)
//		try{
		{
			//U.log(sec);
		String url = U.getSectionValue(sec, "<a href=\"", "\"");
		url = "https://www.eagleofva.com"+url;
		
//		if(!url.contains("https://www.eagleofva.com/new-homes/va/glen-allen/parkside-village/8280/")) return;
		
		
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"------>repeated");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		
		U.log("\nCount=="+j);
		U.log(url);
//		U.log();
		String commHtml = U.getHTML(url);
		
		String commName = U.getSectionValue(sec, "<h4>", "<");
		U.log("commName : "+commName);
		
		String lat = U.getSectionValue(sec, "data-latitude=\"", "\"");
		String lng = U.getSectionValue(sec, "data-longitude=\"", "\"");
		if(lat==null) {
			lat = U.getSectionValue(commHtml, "data-latitude=\"", "\"");
			lng = U.getSectionValue(commHtml, "data-longitude=\"", "\"");
		}
		String geo = "FALSE";
		
		String planHtml = ALLOW_BLANK;
		String planSec = U.getSectionValue(commHtml, "<h1>Available Floor Plans</h1>", "<h1>Community Photos</h1>");
		if(planSec != null) {
			String[] plansUrls = U.getValues(planSec, "<a href=\"/", "\"");
			U.log("plansUrls.length: "+plansUrls.length);
		
			for(String planUrl:plansUrls)
			{
				//U.log("plan:::"+plan);
				planUrl ="https://www.eagleofva.com/"+planUrl;
//				String planUrl = U.getSectionValue(plan, "<a href=\"", "\">");
//				U.log("planUrl:::"+planUrl);
				planHtml += U.getHTML(planUrl);

				//planHtml+=U.getSectionValue(planHtml, "<div class=\"detail-box\">", "</div></div></div></div></section>");
			}
		}
		//============Unit Count
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		int lotcount=0;
		
		if(commHtml.contains("community map")) {
			String[] lotSection=U.getValues(commHtml, "class=\"lot text", "/span");
			counting=Integer.toString(lotSection.length);
		}
		
		
		U.log("counting  :::"+counting);
		
		//============ Quick MoveIns
		int quickCount=0;
		String quickData = ALLOW_BLANK;
		String quickSec = U.getSectionValue(commHtml, "quick move-in homes", "</section>");
		U.log("quickSec :::"+quickSec);
		if(quickSec != null) {
			String[] quickValues = U.getValues(quickSec, "class=\"col-12 col-sm-6 col-lg-4 mb-4\"", "view home</a>");
			U.log("quickValues.length :::"+quickValues.length);	
			quickCount=quickValues.length;
			for(String quick:quickValues) {
				String qUrl = U.getSectionValue(quick, "<a href=\"", "\">");
				qUrl="https://www.eagleofva.com"+qUrl;
//				U.log("url: "+qUrl);
				quickData += U.getHTML(qUrl);
				U.log(U.getCache(qUrl));	
			}
		}
		int bannerCount=0;
		if(quickSec!=null) {
		String bannerHomes[]=U.getValues(quickSec, "<span class=\"banner-text\">", "</span></a>");
		for(String bannerHome:bannerHomes) {
			if(bannerHome.contains("Coming Soon")||bannerHome.contains("coming soon")||bannerHome.contains("late summer 2022"))
				bannerCount++;
		}
		}
		//======= Community Type ===================================
		sec = sec.replaceAll("this 55\\+|for this 55\\+", "55-and-better couples");
		commHtml = commHtml.replaceAll("newest 55\\+ section", "55-and-better couples");
		

		String ctype = U.getCommType(commHtml+sec);
		 
		
		
		commHtml = commHtml.replaceAll("first floor masters|second floor masters|first-floor-masters|/floor-plans/second-floor-", "");
		
		if(planHtml!=null) {
			planHtml = planHtml.replaceAll("src=\"https://static\\.eagleofva\\.com/eagleconstruction/images/stories\\.png\\?v=.*\"/>1", " 1 Story ");
			planHtml = planHtml.replaceAll("src=\"https://static\\.eagleofva\\.com/eagleconstruction/images/stories\\.png\\?v=.*\"/>2", " 2 Story ");
			planHtml = planHtml.replaceAll("src=\"https://static\\.eagleofva\\.com/eagleconstruction/images/stories\\.png\\?v=.*\"/>3", " 3 Story ");
		}
		
//		U.log("mmmmmm"+Util.matchAll(commHtml+planHtml, "[\\w\\s\\W]{30}multiple-level floorplans[\\w\\s\\W]{30}", 0));
		
		String dtype = U.getdCommType((commHtml+planHtml+quickData).replaceAll("level|[F|f]loor|first floor masters|second floor masters|first-floor-masters|/floor-plans/second-floor-", ""));;
		
		//U.log(">>>>>>>>>"+Util.matchAll(commHtml+planHtml+quickData, "[\\s\\w\\W]{30}2-story plan[\\s\\w\\W]{30}",0));
		
		dtype=dtype.replaceAll("Ranch,|,Ranch|Ranch,|, Ranch","");
		if(dtype.length()<4)
			dtype=ALLOW_BLANK;
		planHtml = planHtml.replaceAll("Village|village|Carriage| luxurious serenity", "");
		commHtml = commHtml.replace("CURRENT PHASES ARE SOLD OUT", "CURRENT PHASES SOLD OUT") 
				.replaceAll("\\\">coming soon</span>|quick move-in homes</a>|Coming in 2017! Located|\"Coming in 2017|\">Coming in 2017|Patio\" /></li>|Patio\" /></li>|<a href=\"/quick-move-in-homes/\" class=\"footerNavAnchor footerAnchorBackgroundColor\">quick move-in homes</a>|<a href=\"/quick-move-in-homes/\" class=\"mainNavAnchor\">quick move-in homes</a>", "");
		commHtml=U.removeSectionValue(commHtml, " <div class=\"item  description marketingDescription\"", " </div>");
		U.log("dtype========="+dtype);
		
//		U.log("mmmmmm"+Util.matchAll(commHtml+sec, "[\\w\\s\\W]{30}Closeout Homes[\\w\\s\\W]{30}", 0));
		
		String status = U.getPropStatus((commHtml+sec).replaceAll("Quick Mov|quick move", "")
				.replace("<span class=\"banner-text\">late summer 2022</span>", "") //status from home
				.replace("<span class=\"banner-text\">Coming Soon</span>", "") //status from home
				.replaceAll("Showcase Home Coming Soon|text\">\\s+coming soon\\s+</span>","")
				.replaceAll("you have questions about a move-in-ready home or building|/new-homes/available/\">quick move-ins|INFORMATION ON THE NEWEST SECTION COMING|alt=\"Grand Opening|tipGrandOpening|alt=\"This Community is Coming Soon|BDX Coming Soon|Move-in ready|move-in ready|quick move-in homes\\s*</a>|ipComingSoo", ""));
		
		if(bannerCount==quickCount) {
			status=status.replaceAll("Quick Move-in|, Quick Move-in|Quick Move-in, ", "");
		}
		
		if(status.contains("Closeout Homes")) status = status.replace("Closeout Homes", "Closeout");
		
		U.log("status:"+status);
		
		if(url.contains("http://www.eagleofva.com/our-communities/greengate")||sec.contains("nowselling.png?v")){
			status = "Now Selling"; //from image
		}
		
		//U.log("Com NAme::"+commName+":comNAme");
		
		U.log("mmmmmm"+Util.matchAll(commHtml+sec, "[\\w\\s\\W]{30}closeout[\\w\\s\\W]{30}", 0));	
		if(status.isEmpty())
			status=ALLOW_BLANK;



		planHtml = planHtml.replaceAll("<li>\\s+Loft\\s+</li>", "<li>Loft</li>");
		sec = sec.replace("luxurious, all-brick condos", "luxury homes, all-brick condos");
		
		planHtml=planHtml.replaceAll("waited for the perfect condo for us|I went the custom home route|If you are looking to build a high quality custom home", "");
		commHtml = commHtml.replace("traditional architecture", "traditional homes architecture").replace("Craftsman, European and Traditional-style", "classic craftsman design and Traditional exterior")
					.replaceAll("to build a high quality custom home|of other custom builders|I went the custom home route", "");
		quickData = quickData.replace("Luxury laminate flooring throughout", "Luxury homes laminate flooring throughout");
		
		String ptype = U.getPropType((commHtml+planHtml+sec+quickData).replaceAll("waited for the perfect condo for us as|I had heard of other custom builders|with you on custom building your dream home|Townhouse model home|townhouse|Village|village", ""));
		
//		U.log("planHtml :::"+planHtml);
//		U.log("quickData :::"+quickData);

//		U.log("mmmmmm"+Util.matchAll(commHtml+planHtml+quickData, "[\\w\\s\\W]{30}courtyard[\\w\\s\\W]{30}", 0));

		
		U.log("ptype======"+ptype);
		
		String[] add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK}; 
		String addSec = U.getSectionValue(commHtml, "<span class=\"address\">", "</span>");
		if(addSec!=null){
			
			add  =U.getAddress(addSec);
		}
		U.log("Address::::::"+Arrays.toString(add)); 
		
		commHtml=commHtml.replaceAll("0s|0's|0S", "0,000");
		if(add[0]==null)add[0]="";
		if(add[0].equals(add[1]))add[0]="";
		if(add[0]==null || add[0].length()<5)
		{
			String latLng[]= {lat,lng};
			add=U.getAddressGoogleApi(latLng);
			if(add==null)add=U.getGoogleAddressWithKey(latLng);
			geo="TRUE";
		}
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
	
		
		String[] price = U.getPrices(sec+commHtml+planHtml, "<p class=\"card-price\">\\$\\d{3},\\d{3}|</h2><h4>\\$\\d{3},\\d{3}</h4>|<h4>\\$\\d{3},\\d{3}</h4>|Priced From \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice="+minPrice+"       "+"maxPrice="+maxPrice);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(sec+commHtml+planHtml+quickData ,"over \\d,\\d{3} square feet|</i>\\s+\\d,\\d{3}\\s+</span>|</i> \\d,\\d{3} - \\d,\\d{3}</span>", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf="+minSqf+"           "+"maxSqf="+maxSqf);
		
		//U.log("mmmmmm"+Util.matchAll(sec+commHtml+planHtml, "[\\w\\s\\W]{30}2,600[\\w\\s\\W]{30}", 0));
		
		String note = U.getnote(commHtml);
		
		//================================================================================
		if(url.contains("https://www.eagleofva.com/our-communities/hickory-hill/"))geo = "TRUE";
	//	if(url.contains("/our-communities/lankfords-crossing/"))status = "Grand Opening, "+status;//Img
		
		//=========Image ============
//		if(url.contains("https://www.eagleofva.com/new-homes/va/chesterfield/kenbrook-at-harpers-mill/8169/")) status += ", New Section Coming Soon"; //From Image
				
		if(status.contains("Two Opportunities Remain, Closeout, Quick Move-in Homes, Only Two Opportunities Remain"))
			status="Two Opportunities Remain, Closeout, Quick Move-in Homes";
		if(status.contains("Grand Opening, Grand Opening"))
			status=status.replace("Grand Opening, Grand Opening", "Grand Opening");
		if(status.contains("Only 3 Opportunities Remain, Closeout, Three Opportunities Remaining"))
			status=status.replace("Only 3 Opportunities Remain, Closeout, Three Opportunities Remaining", "Only 3 Opportunities Remain, Closeout");
		if(status!=null)
			status = status.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		
		commName = commName.replaceAll("Golf Villas$", "");
		
		if(url.contains("https://www.eagleofva.com/new-homes/va/henrico/greengate/8168/")) status = ALLOW_BLANK;
		
		data.addCommunity(commName, url, ctype);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(status);
		data.addNotes(note);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}j++;
//		}catch(Exception e) {}
	}
}