/** @author 
 *  @date 
 */

package com.shatam.b_161_180;

import java.io.File;
import java.util.Arrays;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGrayHawkHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	private static String baseUrl = "https://www.grayhawkhomes.com/";

	WebDriver driver=null;
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new ExtractGrayHawkHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Grayhawk Homes.csv", a.data().printAll());
		//U.log("duplicates"+duplicates);
	}

	public ExtractGrayHawkHomes() throws Exception {

		super("Grayhawk Homes", "https://www.grayhawkhomes.com/");
		LOGGER = new CommunityLogger("Grayhawk Homes");
	}
	
	
	private void setProxyByBrowsec(){
		ChromeOptions options = new ChromeOptions ();
		
//		U.log(System.getProperty("/home/shatam-10/snap/skype/common") +"/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx");
		
		options.addExtensions (new File("/home/shatam12/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));

		DesiredCapabilities capabilities = new DesiredCapabilities ();

		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(capabilities); //capabilities
		
	}
	
	private void setProxyForDriver(String ip, int port){

		Proxy proxy = new Proxy();
		//Adding the desired host and port for the http, ssl, and ftp Proxy Servers respectively 
		proxy.setHttpProxy(ip.trim()+":"+port);
		proxy.setSslProxy(ip.trim()+":"+port);
		proxy.setSslProxy(ip.trim()+":"+port);
//		proxy.setFtpProxy(ip.trim()+":"+port);

		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(CapabilityType.PROXY, proxy);
		
		driver = new ChromeDriver(dc);
		
	}

	public void innerProcess() throws Exception {
//		  U.setUpChromePath();
//	//	U.setUpGeckoPath();		 
//		  setProxyByBrowsec();		  
	//	setProxyForDriver("209.40.237.43",8080);
		  
		
		int total = 0;
		//U.log(baseUrl);
		String html = U.getHtml(baseUrl,driver);//manual add vpn and change region from browser to get cache 
//		U.log(html);
		String regUrlSections = U.getSectionValue(html, "Find Your Home", "Build On Your Land");
		String []regionUrls = U.getValues(regUrlSections, "<a href=\"", "\">");
		for(String regionUrl : regionUrls){
			//U.log("Reg Url=="+regionUrl);
			String regionHtml = U.getHtml(regionUrl,driver);	
			if(regionUrl.contains("/georgia-new-home-communities/south-columbus-new-homes-sale/"))
			{
				regionHtml = regionHtml.replace("</span></div></div></div></div></section>", "");
			}
			
			String[] comSections = U.getValues(regionHtml, "https://www.grayhawkhomes.com/new-home-communities", "View Community");
//			U.log(comSections.length);
			LOGGER.AddRegion(regionUrl, comSections.length);
			total += comSections.length;
			for(String c : comSections){
			//	U.log(c);
				String comUrl = "https://www.grayhawkhomes.com/new-home-communities/"+U.getSectionValue(c, "/", "\"");
				String html1 = U.getHtml(comUrl,driver);
				if(comUrl != null){
					comUrl = comUrl.replace("/iowa-new-home-communities/","/iowa/");
				//	U.log("comUrl :: "+comUrl);
//					try {
						findCommunityDetails(comUrl,html1);
//					} catch (Exception e) {}
					
				}
			}//eof for inner

		}//eof for outer
		U.log("Total community ::"+total);
		LOGGER.countOfCommunity(total);
		LOGGER.DisposeLogger();
		
//		try{driver.quit();}catch (Exception e) {}
	}		
	
	public void findCommunityDetails(String comurl,String html) throws Exception {
		
//		if(j >11)
		{
			U.log("=================="+j+"\n"+comurl);
			
//---------SINGLE EXECUTION		
//	if(!comurl.contains("https://www.grayhawkhomes.com/new-home-communities/smiths-station-al-homes-rocky-ridge/")) return;
		
			U.log(U.getCache(comurl));

		if(data.communityUrlExists(comurl)) {
			LOGGER.AddCommunityUrl(comurl+":::::::::::Reapeated:::::::::::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(comurl);
		String comsec=U.getSectionValue(html, "<h1 class=\"title", "/h3>");
		
		String comname=U.getSectionValue(comsec, "\">", "</h1>").replace("PARC At AU Club", "Parc At Au Club");
		U.log(comname);
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		String minsqft=ALLOW_BLANK;
		String maxsqft=ALLOW_BLANK;
		comsec=comsec.replace("<br />", ",");
		comsec=comsec+"end";
	//	U.log(comsec);
		
		//String addsec=U.getSectionValue(comsec, "<h3>", "<end");
		String addsec=U.getSectionValue(html, "https://www.google.com/maps", "\"");
		if(addsec!=null) {
			addsec=addsec.replace("Way, Midland", "Way");
		}
		U.log("addsec: "+addsec);
		
		
//		String address[]=addsec.split(",");
//		U.log(addsec.length()+"======"+Arrays.toString(address));
//		add[0]=address[0].trim();
//		add[1]=address[1].trim();
//		add[2]=address[2].trim();
		
		if(addsec != null) {
			String addressLine = U.getSectionValue(addsec, "/dir//", "/@").replace(", USA", "");
			add = U.getAddress(addressLine);
			U.log("ADDRESS: "+Arrays.toString(add));
		}
		
		
		
		
		
		String latlongsec=U.getSectionValue(html, "https://www.google.com/maps", "\"");
		U.log("latlongsec: "+latlongsec);
		
		latlong[0]=U.getSectionValue(latlongsec, "/@", ",");
		latlong[1]="-"+U.getSectionValue(latlongsec, ",-", ",");
		U.log("LATLONG: "+Arrays.toString(latlong));
		
		if(comurl.contains("communities/smiths-station-al-homes-rocky-ridge/"))
		{
			addsec=U.getSectionValue(html, "<h1 class=\"title\">"+comname, "</h3>")
					.replace("			<br>", ", ");
			U.log("addsec-1===: "+addsec);
			addsec=U.getNoHtml(addsec).trim();
			
			U.log("addsec-1===: "+addsec);
			add=U.getAddress(addsec);
			U.log(Arrays.toString(add));
			if(add[3]==ALLOW_BLANK) {
				add[3]=U.getAddressGoogleApi(latlong)[3];
				geo="TRUE";
			}
			U.log("ADDRESS: "+Arrays.toString(add));
		}
		
		
		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/salem-al-homes-shenandoah-farms/"))
		{
			if(add[3]==ALLOW_BLANK) {
				add[3]=U.getAddressGoogleApi(latlong)[3];
				geo="TRUE";
			}
		}
		
		
		
		if(add[3]==ALLOW_BLANK || add[2]==ALLOW_BLANK ) {
			add=U.getAddressGoogleApi(latlong);
			geo="TRUE";
		}
		
		
		html=html.replace("0's", "0,000");
		
	
		
		String modelhtml="";
		try {
			String modelurl[]=U.getValues(html, "<a href=\"https://www.grayhawkhomes.com/home-builder-plans", "\"");
			for(String durl:modelurl) {
				String murl="https://www.grayhawkhomes.com/home-builder-plans"+durl;
				U.log("murl:::::::::::"+murl);
				modelhtml+=U.getHtml(murl,driver);
			}
		
		
		}
		catch(Exception ne) {
			
		}
		
		String availhtml="";
		try {
			String availurl[]=U.getValues(html, "https://www.grayhawkhomes.com/new-homes-for-sale", "\"");
			for(String aurl:availurl) {
				String avaurl="https://www.grayhawkhomes.com/new-homes-for-sale"+aurl;
				U.log("avaurl:::::::::::::::"+avaurl);
				availhtml+=U.getHtml(avaurl,driver);
			}
		
		
		}
		catch(Exception ne) {
			
		}
		U.log(modelhtml.length());
//		U.log("mmmmmm1111"+Util.matchAll(html, "[\\w\\s\\W]{60}\\$300[\\w\\s\\W]{30}", 0));
		html=html.replace("Links Crossing. Homes start in Low $300,000", "");
		html=html.replace("From the $278's", "From the $278,000").replace("From the $306's", "From the $306,000")
				.replace("00’s", "00,000");
//		U.log("mmmmmm222"+Util.matchAll(html, "[\\w\\s\\W]{60}\\$300[\\w\\s\\W]{30}", 0));
				html=html.replaceAll("Homes start in Low $300,000 and range from 1800 - 300|Homes start in Low $300&#039;s", "");
		String prices[] = U.getPrices((html+modelhtml), 
				"from the mid \\$\\d{3},\\d{3}|From the $306,000|From the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|Priced From the Mid \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}", 0);
		
		minPrice=prices[0];
		maxPrice=prices[1];
		U.log("prices=="+Arrays.toString(prices));
//		U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{60}\\$300[\\w\\s\\W]{30}", 0));

		String sqft[]=U.getSqareFeet(html+modelhtml, "\\d,\\d{3} square foot home|range in size from \\d{1},\\d{3}+|\\d{4} SqFt", 0);
		minsqft=sqft[0];
		maxsqft=sqft[1];
		U.log("sqft=="+Arrays.toString(sqft));
		html=html.replaceAll("Colonial Mall|>Golf Courses</a>|Auburn new homes are now available|center;\">Coming Soon</h2>|The Lakeside Village outlets are only|<h2>Lakeside</h2>", "");
		
		html = html.replace("with lake access", "with lakeside community");
		
		String comtype=U.getCommType(html);
		U.log("comtype:::::::::::::::"+comtype);
		
		
		String ptype=U.getPropType((html+modelhtml+availhtml).replace("Maryland II Traditional West", "Maryland II Traditional exterior West")
				.replace("home is a custom design", "home is a custom home design")
				.replace("Derby II Traditional Main Level", "Derby II Traditional exterior Main Level")
				.replace("Longleaf Traditional 1st Floor", "Longleaf Traditional exterior 1st Floor")
				.replace("Craftsman", "Craftsman Style")
				.replaceAll("<h3 style=\"text-align: center;\">Custom Design</h3>", "<h3 style=\"text-align: center;\">a custom-quality</h3>")
				.replace("Jasmine Traditional", "Jasmine Traditional exterior"));
		U.log("ptype:::::::::::::::"+ptype);

//		U.log("mmmmmm"+Util.matchAll(html+modelhtml+availhtml, "[\\w\\s\\W]{60}custom design[\\w\\s\\W]{30}", 0));
	
		
		availhtml=availhtml.replace("1st Floor", "1 Story").replace("2nd Floor", "2 Story");
		
		modelhtml=modelhtml.replace("1st Floor", "1 Story").replace("2nd Floor", "2 Story");
		
		availhtml=availhtml.replace("Spruce Euro 1 Story", "");
		
		
		String dtype=U.getdCommType(html+modelhtml+availhtml);
		
//		html = html.replaceAll("choose from and lots available", "");
		
//		
		String pstatus=U.getPropStatus(html);

		
		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (comtype == null)
			comtype = ALLOW_BLANK;
		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/midland-ga-new-homes-charleston-place/"))dtype=ALLOW_BLANK;
		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/homes-columbus-ga-lexington-hills"))pstatus=ALLOW_BLANK;
		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/auburn-new-homes-au-club/"))comname="Parc At Au Club";
		

		if(comurl.contains("columbus-ga-new-homes-roosevelt-heights/"))dtype=ALLOW_BLANK;
//		if(comurl.contains("https://www.grayhawkhomes.com/new-home-communities/homes-fortson-ga-ivy-park"))dtype="1 Story, 2 Story";
		
		 // ------------------ No. of units ------------------------
	     String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addCommunity(comname, comurl, comtype);
		data.addAddress(add[0].replaceAll("Off Site Sales Center|,", "").replace("** ", ""), add[1].trim(), add[2], add[3]);
		data.addLatitudeLongitude(latlong[0], latlong[1], geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(U.getnote(html));
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		
	}
	
	j++;
	}
	
	
	
}