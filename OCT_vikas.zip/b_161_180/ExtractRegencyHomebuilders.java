package com.shatam.b_161_180;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractRegencyHomebuilders extends AbstractScrapper {
	CommunityLogger LOGGER;	
	int j=0;
	private static final String BASEURL = "https://www.newregencyhomes.com";
//	static WebDriver driver = null;
	//WebDriver driver = new FirefoxDriver();
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRegencyHomebuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Regency Homebuilders.csv", a.data()
				.printAll());
//		driver.close();
	}
	public ExtractRegencyHomebuilders() throws Exception {
		super("Regency Homebuilders", BASEURL);
		LOGGER = new CommunityLogger("Regency Homebuilders");
	}
	WebDriver driver=null;
	public void innerProcess() throws Exception {
		U.log(BASEURL);
//		U.setUpGeckoPath();
		//driver=new FirefoxDriver(U.getFirefoxBinary(),U.getFirefoxProfile());
//		driver = new FirefoxDriver();
/*		String html = U.getHtml(BASEURL, driver);
		//U.log(html);
		String urls_section = U.getSectionValue(html, "Neighborhood Locator Map",
				"Find Your Floorplan");
		 //U.log(urls_section);
		String community_urls_names[] = U.getValues(urls_section, "<li><a",
				"</li>");
		U.log(community_urls_names.length);
		for (String url_name : community_urls_names) {

			//U.log(url_name);
			boolean flag = url_name.contains("/new-home-communities");
			if (!flag) {
			String 	url1=U.getSectionValue(url_name,"href=\"", "\">");
				//U.log(url_name);
				addDetails(BASEURL + url1,url_name);
				// break;
			}
		}
				//addDetails(BASEURL+"/the-villages-at-white-oak");
		*/
		
		String html = U.getHTML("https://newregencyhomes.com/communities");
		String comSections[] = U.getValues(html, "<li class='mb-1'>", "</li>");
		U.log(comSections.length);
		for(String comSec : comSections){
			String comUrl = U.getSectionValue(comSec, "<a href='", "' class=");
			U.log(comUrl);
			addDetails(comUrl, comSec);
		}
		
		LOGGER.DisposeLogger();
//		driver.quit();
	}
/*	private String[] getPrices(String commUrl) throws Exception {
		String html = U.getHTML(commUrl);
		String avHtml = U.getHTML("http://www.newregencyhomes.com"+U.getSectionValue(html, "<li class=\"homes\"><a href=\"", "\""));
		if(avHtml==null)avHtml=ALLOW_BLANK;
		U.log("++++>>>"+U.getSectionValue(avHtml, "<div class=\"inv_hor_mod_text_header_right hor_mod_text_header_right\">", " </div>"));
		String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
		prices = U.getPrices(html+avHtml,
		// from the $400,000
				"<h4>\\$\\d+,\\d+ </h4>|Price Range:</span> \\$\\d+,\\d+ to \\$\\d+,\\d+", 0);
		prices[0] = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		prices[1] = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		return prices;
	}*/

	
	
/*	public String[] getAddress(String commurl) throws Exception {
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String html = U.getHtml(commurl,driver);
		String section = U.getSectionValue(html,
				"class=\"container comm-header\">", "class=\"comm_nav_list\">");
		
		if(section!=null){
		String seccol[] = U.getValues(section, "class=\"comm_header_cols\">",
				"</div>");
		U.log(seccol[1]);
		seccol[1] = seccol[1].replaceAll("<p>\\W+\\W+<br />\\W+</p>|\\(address for GPS -  1734 Winchester Blvd, Collierville, TN 38017\\)", "");
		U.log(seccol[1]);
		String sectionAdd = seccol[1].substring(0, seccol[1].indexOf("<span>"));
		sectionAdd=sectionAdd.replace("<strong data=\"1\">Visit our Model at</strong><br>", "");
		sectionAdd = sectionAdd.replaceAll("<p>\\W+\\W+<br />\\W+</p>|Address for GPS - |Address for FUTURE Model -", "");
		U.log("sec  :  "+sectionAdd.trim() +" ccccccccc");
		if(sectionAdd.trim().length()>15)
		{
		
		String addr[] = sectionAdd.split("<br>");
		
		add[0] = addr[0].replace("<p>", "").replaceAll("\\(.*?\\)", "").trim();
		U.log("add[0]::::::::::::"+add[0]);
		addr = addr[1].split(",");
		add[1] = addr[0].trim();
		U.log("add[1]::::::::::"+add[1]+"::::::::::");
		U.log("addr[2]::::::::::"+addr[2]+"::::::::::");
		U.log("addr.length::::::::::"+addr.length+"::::::::::");
		if (add[0].trim().length() == 0)
			add[0] = ALLOW_BLANK;
		if(addr.length==2){
			add[3] = addr[2].replace("</p>", "").replace("<p>", "").trim();
			if (add[0].length() == 0)
				add[0] = ALLOW_BLANK;
			add[2] = addr[1];
			//U.log("::::::::::"+addr[2]+"::::::::::");
			if (!(add[2].length() == 3))
				add[2] = USStates.abbr(addr[1]);
			else {
				add[2] = ALLOW_BLANK;
			}
		}
		if(addr.length==3)
		{
			
			addr[1]=addr[1].trim();
			if(addr[1].length()>2){
				add[2] = USStates.abbr(addr[1]);
				U.log("add[2]::::::::::"+addr[2]+"::::::::::");
			}
			else{
				add[2]=addr[1].trim();
			}
			U.log("else::::::::::"+addr[1]+"::::::::::");
			addr[2]=addr[2].replaceAll("<p>|</p>", "");
			add[3]=addr[2].trim();
		}
		
		}
		}
		if(commurl.contains("http://www.newregencyhomes.com/grays-hollow"))
		{
		add[0]="9654 Grays Meadow Cove";
		add[1]="Cordova";
		add[2]="TN";
				add[3]="38016";

		}
		
		return add;
	}
		
*/	
	//TODO :
	public void addDetails(String commUrl,String oldSec) throws Exception {
//	if(j == 3)
	{
			
			 
//	 if(!commUrl.contains("https://www.newregencyhomes.com/cordova-ridge")) return;


		//--------Add All--------------
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"--repeat----");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
			
		// ............................Community Url...........................
		U.log(j+"\tPage Url: " + commUrl);
		String html = U.getHTML(commUrl);
		U.log(U.getCache(commUrl));
		U.log(oldSec);
		// ...........................Community Name...........................
		String commName = U.getSectionValue(oldSec, "text-primary'>", "</a>");
/*		if(commName==null)
		{
			commName=commUrl.replace("http://www.newregencyhomes.com/", "");
			commName=commName.replace("-", " ");
			U.log(commName);
		}
		commName=commName.toLowerCase().replaceAll("of mississippi", "");*/
		U.log(commName);

		//----------Address-------------
		String note = U.getnote(html);
		
		String flag = "False";
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		
		String addSec = U.getSectionValue(html, "Visit Our Model Home</h4>", "</h3>");
		U.log("1"+addSec);
		if(addSec != null) addSec = addSec.replace("<br />", ",");
		U.log("2"+addSec);
		if(addSec == null) addSec = U.getSectionValue(html, "Driving Directions</h3>", "</p>");
		
		U.log("addSec: "+addSec);
	
		
		if(addSec != null){
			addSec = addSec.replaceAll("<.*?>", "");
			U.log("addSec here:::"+addSec);
			
			add = U.findAddress(addSec);
			if(add == null) add = U.getAddress(addSec);
		}
		
		  U.log("add above:::::"+Arrays.toString(add));
		  
		  if(add[3]==ALLOW_BLANK) {
			  U.log("ZIP ABSENT");
			  
				if(html.contains("<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=")) {
					addSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
					
					addSec = addSec.replace("Woodland Levee Way, TN 38018", "Woodland Levee Way, Cordova, TN 38018");
					
					U.log("addSec for ======: "+addSec);
					
					if(addSec!=null) {
						addSec = addSec.replaceAll("Tennessee", "TN");
						add = U.getAddress(addSec);

					}
				}	
		  }
		  
		  if(commUrl.contains("https://www.newregencyhomes.com/woodland-hills-ii")) add[0] = ALLOW_BLANK; //check next time
		
		if(add[0]==ALLOW_BLANK && html.contains("<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=")) {
			addSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
			
			addSec = addSec.replace("Woodland Levee Way, TN 38018", "Woodland Levee Way, Cordova, TN 38018");
			
			U.log("addSec======: "+addSec);
			
			if(addSec!=null) {
				addSec = addSec.replaceAll("Tennessee", "TN");
				add = U.getAddress(addSec);

			}
		}	
		U.log("addSec: "+addSec);
//		add[0]=add[0].replace(", Memphis, TN 38133", "").replaceAll("Address for GPS: ", "");
        U.log("add:::::"+Arrays.toString(add));
        
       
//        if(commUrl.contains("comm_overview.php?com=172"))add[0]="Steffen Woods Cove";
        //if(commUrl.contains("comm_overview.php?com=160"))add[0]= "Leeward Slopes Dr";
        
		//-------LatLng-----------
        String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
        
        String latLngSec = U.getSectionValue(html, "smartMap.coords(", "),");
        
        latLng[0] = U.getSectionValue(html, "lat&quot;:", ",");
        latLng[1] = U.getSectionValue(html, "lng&quot;:", "}");
        
        if(latLng[0]==null && addSec!=null && addSec.contains(".") && addSec.contains(","))
        	latLngSec = addSec;
        if(latLngSec != null)
        	latLng = latLngSec.split(",");
        if(add[0]!=null && add[0]!=ALLOW_BLANK&& latLng[0]==ALLOW_BLANK) {
			 latLng = U.getlatlongGoogleApi(add);
			 flag = "TRUE";
		}
        
      
		U.log("latLng::"+Arrays.toString(latLng));
		
/*		if(latLng[0]==ALLOW_BLANK && latLng[0].equals("0") ){
			 latLngSec = U.getSectionValue(html, "rel=\"noopener\" href=\"https://maps.google.com/maps?ll=", "&amp;");
			if(latLngSec != null)
			latLng = latLngSec.split(",");
			U.log("latLng::"+Arrays.toString(latLng));

		}*/
		
		
/*		if (latLng[0].trim().length()==0) {
			latLng[0]=ALLOW_BLANK;
			latLng[1]=ALLOW_BLANK;
		}*/
//		add[0] = add[0].replaceAll("COMING SOON!|NEW PHASE COMING SOON", "").replaceAll("MODEL COMING SOON", "");
		
		if((latLng[0]!=ALLOW_BLANK || latLng[0].trim().length() > 3) && (add[3]==ALLOW_BLANK || add[3].length()<5)){
			String adds[]=U.getAddressGoogleApi(latLng);
			if(adds == null) adds = U.getAddressHereApi(latLng);
			if(add[3]==ALLOW_BLANK )add[3]=adds[3];
			if(add[2]==ALLOW_BLANK || add[2]== null)add[2]=adds[2];
			if(add[1]==ALLOW_BLANK )add[1]=adds[1];
			if(add[0]==ALLOW_BLANK)add[0]=adds[0];
			
			flag="True";
		}
/*		U.log(latLng[0]);
		if(latLng[0]==ALLOW_BLANK&&add[0]!=ALLOW_BLANK){
			latLng=U.getlatlongGoogleApi(add);
			flag="TRUE";
			U.log("hello12");

		}
		U.log(latLng[0]);
		if(add[2]==ALLOW_BLANK&&latLng[0].trim().length()>4)
		{
			
			add=U.getAddressGoogleApi(latLng);
			flag="TRUE";
		}
		
		if(add[0].contains("Coming Soon!")){
			add[0]=add[0].replace("Coming Soon!","");
			
		}	*/
		

/*
		if(add[1].length()<2 && latLng[0].length()>4)
		{
			add=U.getAddressGoogleApi(latLng);
			flag="TRUE";
			U.log("Heoolo");
		}
		
	
		if(latLng[0].length()<4 && add[1].length()>2)
		{
			latLng=U.getlatlongGoogleApi(add);
			U.log(Arrays.toString(latLng));
			add=U.getAddressGoogleApi(latLng);
			U.log("Heoolo4");
			flag="TRUE";
		}
		if(add[0].length()<2 && latLng[0].length()>4)
		{
			add=U.getAddressGoogleApi(latLng);
			U.log("Heoolo");
			flag="TRUE";
		}
	
		if(latLng[1].length()<4)
		{
			String section = U.getSectionValue(html,
					"class=\"container comm-header\">", "class=\"comm_nav_list\">");
			String addsec=U.getSectionValue(section, "<p>","</p>");
			addsec=addsec.replace("<br />","");
			addsec=addsec.replace("Tennessee","TN");
			String[] ll=addsec.split(",");
			add[1]=ll[0];
			add[2]=ll[1];
			add[3]=ll[2];
			latLng=U.getlatlongGoogleApi(add);
			add[0]=U.getAddressGoogleApi(latLng)[0];
			flag="TRUE";
		}
		U.log(add[0]+" jj");
		add[0]=add[0].replace("COMING SOON!", "").replaceAll("\\(address for GPS - 8038 Pleasant Hill Road\\)|\\(address for GPS-Bostick Road, Memphis, TN 38133\\)|\\(address for GPS - Bostick Road, Memphis, TN 38133\\)|Emmas Circle North \\(address for GPS -|\\)", "");
		add[2] = add[2].replace("Tn", "TN");
		
	*/

		String floorHtml = ALLOW_BLANK;
		String readyHome = ALLOW_BLANK;
				
		String navSection = U.getSectionValue(html, ">Overview</a>", "Community Map</a>");
		if(navSection != null){
			String navUrls[] = U.getValues(navSection, "<a href=\"", "\"");
			
			for(String navUrl : navUrls){
				if(navUrl.contains("/homes")){
					U.log("readyUrl :"+navUrl);
					readyHome = U.getHTML(navUrl);
				}
				else if(navUrl.contains("/floor-plans")){
					U.log("floorUrl :"+navUrl);
					floorHtml = U.getHTML(navUrl);
				} 
			}
		}
		//------------FloorPlan Data----------------
//		String allFloorPlanData = ALLOW_BLANK;
		
/*		String floorUrl = Util.match(html, "<li class=\"plans\"><a href=\"(.*?)\">Floor Plans</a></li>",1);
		U.log("floorUrl : "+floorUrl);
		if(floorUrl != null){
			floorUrl = BASEURL+floorUrl;
			U.log("floorUrl :== "+floorUrl);
			floorHtml = U.getHtml(floorUrl,driver);
			if(floorHtml.contains("<div class=\"comm-menu-column")) {
				String rem = U.getSectionValue(html, "Neighborhood Locator Map",
						"Find Your Floorplan");
				floorHtml=floorHtml.replace(rem, "");
			}
			String[] eachFlrUrls = U.getValues(floorHtml, "<h4><a href=\"", "\"");
			U.log("total floor : "+ eachFlrUrls.length);
			for(String eachFlrUrl : eachFlrUrls){
				eachFlrUrl = eachFlrUrl.replace("&amp;", "&");
				U.log("eachFlrUrl : "+eachFlrUrl);
				String tempflrHtml = U.getHtml(BASEURL+eachFlrUrl,driver);
				allFloorPlanData += U.getSectionValue(tempflrHtml, "<div class=\"inside-left-nosub\">", "</h5>");
				//break;
			}
		}*/
/*		
		String[] floorUrls = U.getValues(floorHtml, "<a class='block relative' href=\"", "\"");
		U.log("total floor : "+ floorUrls.length);
		for(String floorUrl : floorUrls){
			//floorUrl = floorUrl.replace("&amp;", "&");
			U.log("floorUrl : "+floorUrl);
			String tempflrHtml = U.getHTML(floorUrl);
			allFloorPlanData += U.getSectionValue(tempflrHtml, "<div class=\"inside-left-nosub\">", "</h5>");
			//break;
		}*/
		
		//---------Available homes data---------
		String allReadyHomesdata =ALLOW_BLANK;
/*		String availUrl  = Util.match(html, "<li class=\"homes\"><a href=\"(.*?)\">Ready Now Homes</a></li>",1);
		U.log("availUrl : "+availUrl);
		if(availUrl != null){
			readyHome = U.getHtml(BASEURL+ availUrl, driver);	
			String homeUrls[] =U.getValues(readyHome, "<li><a href=\"/home_detail.php?", "\"");
			for(String home:homeUrls) {
				home=home.replace("&amp;", "&");
				U.log("http://www.newregencyhomes.com/home_detail.php?"+home);
				allReadyHomesdata += U.getHtml("http://www.newregencyhomes.com/home_detail.php?"+home, driver);
				if(allReadyHomesdata!=null) {
					allReadyHomesdata = allReadyHomesdata.replaceAll("branch|Branch", "").replaceAll("<span>Stories</span>", "story");
				}
			}
		}*/
		
		String readyHomeUrls[] =U.getValues(readyHome, "<a class='block relative' href=\"", "\"");
		for(String readyHomeUrl:readyHomeUrls) {			
			U.log("readyHomeUrl :"+readyHomeUrl);
			allReadyHomesdata += U.getSectionValue(U.getHTML(readyHomeUrl), "About the Home</h3>","</div>");
		}
		
		//---------Sqft----------

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
//		String[] sqFt = { ALLOW_BLANK, ALLOW_BLANK };
		
/*		String j=Util.match(html, "span>SQFT Range:</span>.*?<");
		U.log("*********************"+j);
		
*/		floorHtml = floorHtml.replace("<span class='text-1p2 font-medium text-grey-600 sm:text-grey-400 uppercase'>SqFt</span>", "SqFt");
		readyHome = readyHome.replace("<span class='text-1p2 font-medium text-grey-600 sm:text-grey-400 uppercase'>SqFt</span>", "SqFt");

		String[] sqFt = U.getSqareFeet(html+floorHtml+readyHome,
		">\\d,\\d{3} - \\d,\\d{3} sqft|>\\d,\\d{3}</strong>\\s+SqFt|Range:</span> \\d,\\d+ to \\d+,\\d+|\\d,\\d+ to \\d,\\d+|Range:</span> \\d+ to \\d+,\\d+|SQ FT: </span>\\d{4}<|Square Feet:</span>\\s?\\d,\\d{3}<", 0);
		minSqft = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqft= (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log(Arrays.toString(sqFt));
		
		//--------Price------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log("++++>>>"+U.getSectionValue(readyHome, "<div class=\"inv_hor_mod_text_header_right hor_mod_text_header_right\">", " </div>"));
//		String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
		
		readyHome = readyHome.replaceAll("<h1 class='.*?'>", "<h1>");
		String[] prices = U.getPrices(oldSec + html+readyHome+floorHtml,
				"Priced from: \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|bold'>\\$\\d{3},\\d{3}<|Priced from: \\$\\d{3},\\d{3}|<h1>\\s+\\$\\d{3},\\d{3}", 0);
		// from the $400,000
//				"<h4>\\$\\d+,\\d+ </h4>|Price Range:</span> \\$\\d+,\\d+ to \\$\\d+,\\d+|Price Range:</span> \\$\\d{3},\\d{3} to|Priced From: </span>\\$\\d{3},\\d{3}", 0);
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log(Arrays.toString(prices));

		U.log("---------------------->"+Arrays.toString(add)+"<<<<<<<<<<<<<<<<<");
		

		// .......................comunity type,property type, property-------------

		// Community Type
//		html = html.replace("<h4>Community HOA Information</h4>", "");
		String communitytype = U.getCommunityType(html);


//		html = html.replace("<h4>Community HOA Information</h4>|Property taxes, insurance, and HOA fees", "");
		
/*		String remDisclaim = U.getSectionValue(html, "<strong>Disclaimer:</strong> ", "</p>");
		if(remDisclaim!=null){
			html=html.replace(remDisclaim, "");
		}*/
		//--------------Property Type---------------
		html = html.replaceAll("HOA Information", "");
		String proptype = U.getPropType(html+allReadyHomesdata);
/*		.replace("kensington manor", "kensington manor homes")
		.replaceAll("s at Carriage Crossing| with carriage style doors|carriage style garage|village|Village|carriage style doors", "")
*/
		//--------------Derive Prop--------------
		String dtype = U.getdCommType(allReadyHomesdata+html.replaceAll("Branch|branch|Ranch</span>", ""));

		//-------------Status---------------
		
/*		html=html.replaceAll("coming_sp_2017","  Coming Spring 2017  ");
		html=html.replaceAll("coming_wi_2017", " Coming Winter 2017 ");
		html=html.replaceAll("Coming Soon!\\\\u003Cbr\\\\|Village</span>\\s*Coming Soon|</span> Coming Soon!</a></li><li>|Coming Soon!</a>|Coming Soon!&|Coming Soon!<br.*>|Coming Soon!</a></li>","");
		
		if(readyHome.contains("There are no inventory found at this time")) {
			html=html.replace("Ready Now Homes", "");
		}
		
		String addremove = U.getSectionValue(html, "Visit our Model", "</p>");
		
		if(addremove!=null)
			html = html.replace(addremove, "");
	*/	
		String	propstatus = U.getPropStatus(html); //.replaceAll("Coming Soon! 170 Choctaw|text\":\"Coming Soon|address\":\"Coming Soon|Coming Soon!</a>|address\":\"COMING SOON|text\":\"COMING SOON!|DESIGNER MODEL COMING SOON|Visit our Model at.*</p>|</span> Coming Soon", "").replace("COMING SOON!\\u00", ""));
		
//		U.log("MMMMMMMMMMMMM "+Util.matchAll(html.replaceAll("Coming Soon! 170 Choctaw|text\":\"Coming Soon|address\":\"Coming Soon|Coming Soon!</a>|address\":\"COMING SOON|text\":\"COMING SOON!|DESIGNER MODEL COMING SOON|Visit our Model at.*</p>|</span> Coming Soon", "").replace("COMING SOON!\\u00", ""), "[\\w\\s\\W]{20}coming soon[\\w\\s\\W]{20}", 0));
		
		if(readyHomeUrls.length > 0){
			if(propstatus.length()<4)propstatus="Ready Now Homes";
			else propstatus=propstatus+", Ready Now Homes";
		}

//		if(commUrl.contains("https://www.newregencyhomes.com/chadwick"))proptype="Custom Home";
		
		
//		if(commUrl.contains("https://www.newregencyhomes.com/chadwick"))minPrice = "$569,900";
//		if(commUrl.contains("https://www.newregencyhomes.com/central-park")) {minPrice = "$289,900";maxPrice="$329,900";}
//		if(commUrl.contains("https://www.newregencyhomes.com/parkview")) {minPrice = "$589,900";maxPrice="$624,900";}
		if(commUrl.contains("https://www.newregencyhomes.com/rolling-meadows"))propstatus="New Phase Coming Soon";
		propstatus = propstatus.replace("New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");
		
		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		
		data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}j++;
}
}