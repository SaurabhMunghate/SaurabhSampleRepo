package com.shatam.b_161_180;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSavvyHomes extends AbstractScrapper {
	static String BASEURL = "https://www.savvyhomes.com";
	static int dup=0;
	CommunityLogger LOGGER;
	static String quickHtml = ALLOW_BLANK;


	/**
	 * @param args
	 * @throws Exception
	 */
	static int j=0;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractSavvyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/Savvy Homes.csv", a.data().printAll());
		U.log(dup);
	}

	public ExtractSavvyHomes() throws Exception {

		super("Savvy Homes", BASEURL);
		LOGGER = new CommunityLogger("Savvy Homes");
	}

	public void innerProcess() throws Exception {
		
		quickHtml = U.getHTML("https://www.savvyhomes.com/homes-for-sale");
		quickHtml=quickHtml.replace("Beau Pr&#233;", "Beau Pre");
		String html = U.getHTML("https://www.savvyhomes.com/");
		
		String regionsection = U.getSectionValue(html,
				"<a href=\"#\">Find Your Home</a>",
				"<div id=\"find-your-home-select\">");
		 U.log(regionsection);
		String regionurls[] = U.getValues(regionsection, " href=\"", "\" id=");
	//	U.log(regionurls.length);
		for (String regionurl : regionurls) {
			regionurl = BASEURL + regionurl;
			//U.log("============" + regionurl);
			findCommunity(regionurl);
		}
		LOGGER.DisposeLogger();
	}

	public void findCommunity(String regionurl) throws Exception {
	
		String html = ALLOW_BLANK;
		try {
			html = U.getHTML(regionurl);
		} catch (java.io.FileNotFoundException ex) {
			U.log("File Not Found");
			return;
		}

		if (html == null)
			return;
		// U.log(html);
		String communityurlsection = U.getSectionValue(html,
				"class=\"neighborhoodlist\">", "<script>");
		if (communityurlsection != null) {
			// U.log(communityurlsection);
					String community_urls_and_Names[] = U.getValues(
					communityurlsection,
					"class=\"views-field views-field-title\">",
					"field-community-phone-number\">");
			//U.log(community_urls_and_Names.length);
			for (String communities : community_urls_and_Names) {

				String section = U.getSectionValue(communities,
						"<span class=\"field-content\">", "</span>");
				String url = U.getSectionValue(section, "<a href='", "'");
			//	url=url.replace("264", "301");
				//U.log(url+"===================url>");
				String community_name = U.getSectionValue(section, "<strong>",
						"</strong>");
			//	U.log("======>comName"+community_name);
				community_name = community_name.replace("é", "e");
				community_name = community_name.replace("&#039;s Landing", "");
				community_name=community_name.replace("&#233;", "e - The Estates");
				

				//U.log("++++++++++++++++++++++++" + community_name);
				addCommunityDetails(url, community_name, communities);
				// break;
			}
		}
	}

	public void addCommunityDetails(String url, String community_name,
			String info) throws Exception {
		
		//if(j==1)
		{
		// community url and community name......
			//U.log(info);
			if(url==null)return;
		url = BASEURL + url;
		U.log(url);
		U.log("comName---- "+community_name);
		community_name=community_name.replace(" - The Estates", "");
		U.log("ooooooooooooooooooooooooooooooooooooooooooo" + community_name);
		String html = U.getHTML(url);
		String geo = "FALSE";

		// comunity type,property type, property status.
		html.contains("�");
		html = html.replace("�", "e");
		String communitytype = U.getCommunityType(html + info);
		//U.log(communitytype);
		
		String combineHtml = getStoryHtml(url);
		combineHtml=combineHtml.replaceAll("1st Floor Office|on the first floor| 1st Floor Living Areas|First Floor "," 1 Story  ")
				.replace(" 2nd-floor Owner", " 2 Story Owner")
				.replace("and a loft", "and a Loft Home ")
				.replace(" luxury features ", " luxury homes features ");
		String dtype = U.getdCommType(html + info +combineHtml);
		//U.log(combineHtml);
		String sectionOverview = U.getSectionValue(html, "<div id=\"overview\"", "<p style=\"text-align: center;\">");
		
		String proptype = U.getPropType(sectionOverview + info + combineHtml);
	
		

		// for lat long
		String minSqf = ALLOW_BLANK;
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String directionsection = U.getSectionValue(html,
				"\"https://maps.google.com/?q=", "\"");
		if (directionsection != null) {

			String dirSplit[] = directionsection.split(",");

			lat = dirSplit[0];

			lng = dirSplit[1];
		}

		lng = lng.replaceAll(": |:", "");

	//	U.log(lat + "============" + lng);

		// for address...
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addresssection = U.getSectionValue(html, "Model Home Address:</strong></span></p>", "<p class=\"");

		if(addresssection == null){
			addresssection = U.getSectionValue(html,"<p class=\"rtecenter\"><strong>", "</strong></p>");
		}

		if (addresssection != null) {
			
			addresssection = addresssection.replaceAll("<p>", "");
			addresssection = addresssection.replaceAll("<br />|</p>", ",");
			U.log("=====ADDRESS=====" + addresssection);
			String[] tempAdd = addresssection.split(",");
			U.log(tempAdd.length);
			if(tempAdd.length>=3){
				add[0] = tempAdd[0];
				add[1] = tempAdd[1];
				add[2] = Util.match(tempAdd[2], "\\w+");
				add[3] = Util.match(tempAdd[2], "\\d+");
			}
			U.log("Address is " + Arrays.toString(add));
		} else {
			String latlng[] = { lat, lng };
			if (latlng[0] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latlng);
				geo = "True";
			}

		}

		// prizes
		info = info.replace("0's", "0,000");
		info = info.replace("'s", ",000");
		info = info.replace("0s", ",0000");
		String availableprizesection = U.getSectionValue(html,
				"Available Homes</a>", "Get Directions</a>");
		availableprizesection=availableprizesection.replace("0&rsquo;s", "0,000");

		String overviewhtml = U.getSectionValue(html, "<div id=\"overview",
				"<div id=\"availablehomes");
		overviewhtml = overviewhtml.replaceAll("0's|0s", "0,000");
		//U.log(info);
		String price[] = U.getPrices(availableprizesection + info
				+ overviewhtml, "\\$[0-9]{3}\\-[0-9]{3},[0-9]{3}|</a><br/>\\$\\d{3},\\d{3}</div>|\\$\\d+,\\d+|the mid \\$\\d{3},\\d{3}", 0);

		String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
	//	U.log(minPrice);
	//	U.log(maxPrice);
//
		// square feet

		String floorplan_sqftsection = U.getSectionValue(html,
				"Floor Plans</span>", "Directions</span>");
		html=html.replace(" &ndash; ", " - ");
		//U.log("html" + html);
		
		// if (floorplan_sqftsection != null) {
		String sqft[] = U
				.getSqareFeet(
						floorplan_sqftsection + overviewhtml
								+ availableprizesection + html,
						"[0-9]{1},[0-9]{3} - [0-9]{1},[0-9]{3}\\+ sq. ft|[0-9]{4}\\-[0-9]{4} square feet|\\d,\\d+ to over \\d,\\d+ sq|\\d,\\d+ - over \\d+,\\d+ sq. ft|\\d,\\d+ sq. ft. to \\d,\\d+ sq.ft.|\\d+ - \\d+ sq. ft.|\\d{1},\\d{3} - \\d{1},\\d{3} sq. ft.|\\d{4} Sq. Ft.|\\d,\\d+ square feet|\\d{4} square feet",
						0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		// }

		if(url.contains("https://www.savvyhomes.com/community/The-Meadows-at-Farmlife/Pinehurst-NC/cid/270")){
			//as square feet points to other community values
			minSqf=ALLOW_BLANK; 
			maxSqf=ALLOW_BLANK;
		}
		
		
		String latlng[] = { lat, lng };
		if (add[3] == null && latlng != null) {
			add[3] = ALLOW_BLANK;
			add = U.getAddressGoogleApi(latlng);
			

		}
		

		if (this.data.communityUrlExists(url))
		{	
			LOGGER.AddCommunityUrl("repeat+++++" + url);
			dup++;
			return;
		}
		
		String dropSec = U.getSectionValue(html, "<div id=\"soldout\"", "<script type=\"text"); //remove other com details
		if(dropSec!=null)
			html=html.replace(dropSec, "");
		
		String dropSec2 = U.getSectionValue(html, ">Other Nearby Communities</h2>", "</section>"); //remove other com details
		if(dropSec2!=null)
			html=html.replace(dropSec2, "");
		
		//----------------Quick Data------------from "https://www.savvyhomes.com/homes-for-sale"-------------
		int quickCount = 0;
		String section = U.getSectionValue(quickHtml, "<ul id=\"isotope\"", "</ul>");
		String[] quickSections = U.getValues(section, "<a href=", " </a>");
		U.log("::::::::::::::: "+ quickSections.length);
		for(String quickSec : quickSections){
			if(quickSec.contains(community_name.trim())){
				quickCount++;
			}
		}
		U.log("quickCount : "+quickCount);
		//--------------------Property Status-----------------------
		String propstatus="";
		
		U.log("================Property======");
		
		html = html.replace("New Single-Family Homes <strong>Coming Soon", "").replaceAll("Coming Soon - placeholder|Quick Move-In Homes</a>|Coming Soon! From the |<strong>coming soon</strong>|images/comingsoon|Coming Soon!", "").replace("<strong>This community is closed out,", "");
		html=html.replace("Phase 2 at Brookside is !&nbsp", "Phase 2 Now Selling");
		
		propstatus = U.getPropStatus(html + info );
		
		if(quickCount>0 && !propstatus.contains("Quick")){
			if(propstatus.length()<4){
				propstatus = "Quick Move-In Homes";
			}
			else{
				propstatus = propstatus + ", Quick Move-In Homes";
			}
		}
	
		U.log("-------------------------------PROP STATUS------------" + propstatus);
		
		// adding in csv
	if(url.contains("-Landing/Angier-NC/cid/250"))//this community page latlong goes in water
	{
		lat="35.541650";
		lng="-78.750215";
				
	}
	
	//U.log(info+"sachin");
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(community_name, url, communitytype);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(html));

	}j++;
	}
	private String getStoryHtml(String url) throws IOException {

		String html = U.getHTML(url);
		String combineHtml = ALLOW_BLANK;
		String allCombineData = ALLOW_BLANK;

		String values[] = U.getValues(html, "<a href=\"/New-Homes-For-Sale", "\"");
		U.log("Total Homes :: "+values.length);
		for (String val : values) {
			val =val.replace("Beau-Pr&#233;", "Beau-Pré");
		U.log("::::::::::" +"https://www.savvyhomes.com/New-Homes-For-Sale"+ val);
		combineHtml = U.getHTML("https://www.savvyhomes.com/New-Homes-For-Sale"+ val);
		
		allCombineData += U.getSectionValue(combineHtml, "<div class=\"listinginfoinv\">", "<section id=");
		//break;
		}

		return allCombineData;
	}
}
