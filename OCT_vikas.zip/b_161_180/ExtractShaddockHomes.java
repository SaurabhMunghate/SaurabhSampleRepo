/** @author  Rakesh Chaudhari
 *  @date 15/10/2015 
 */
package com.shatam.b_161_180;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractShaddockHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	public int inr = 0;
	static int j=0;
	WebDriver driver=null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractShaddockHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Shaddock Homes.csv", a.data()
				.printAll());

	}

	public ExtractShaddockHomes() throws Exception {
		super("Shaddock Homes", "https://www.shaddockhomes.com");
		LOGGER = new CommunityLogger("Shaddock Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();

		String html = U.getPageSource("https://www.shaddockhomes.com/Communities");

		html = html.replaceAll("\\s+", " ");
		//U.log(html);
		String commSec = U.getSectionValue(html, ",\"requestedOnServer\":true,\"data\":[", "],\"unpublished\":");
		String values[] = U.getValues(commSec, "{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");
		U.log(values.length);
		int i=0;
//		int totalComm = values.length / 2;
		String urls = U.getSectionValue(html, "{\"data\":{\"redirects\":", "]");
		String homes[] = U.getValues(html, "{\"@type\":\"SingleFamilyResidence\"", ",\"type\":\"home\"}");
		String plans[]=U.getValues(html, "{\"@type\":\"ProductModel\"", ",\"type\":\"plan\"}");

		U.log(plans.length);
//		String allUrl[]=U.getValues(urls, "{\"from\":\"/", "\"");
		for (String comSec : values) {
//			if(i>0)break;
//			addInfo(comSec);
//			U.log(comSec);
			String homeData = "";
			String planData = "";
			String sharedName = U.getSectionValue(comSec, ",\"sharedName\":\"", "\"");
			U.log("sharedName=="+sharedName);
			i++;
			String comUrl = U.getSectionValue(urls, "{\"from\":\"/"+sharedName+"\",\"to\":\"", "\"");
				
//			U.log("  \nkkkkkkkkkkkkk    " +comUrl); //urls+
			if(comUrl==null && sharedName.contains("brookhollow")) {
				comUrl="/communities/prosper/"+sharedName;
			}
			if(comUrl==null && sharedName.contains("shaddock-creek-estates")) {
				comUrl="/communities/frisco/shaddock-creek-estates";
			}
			if(comUrl == null && sharedName.contains("windsong-ranch-the-summit")) {
				comUrl="/communities/prosper/windsong-ranch-the-summit";
			}
			
			if(comUrl == null && sharedName.contains("westworth-falls")) {
				comUrl="/communities/fort-worth/westworth-falls";
			}
			if(comUrl == null && sharedName.contains("windsong-ranch-6b")) {
				comUrl="/communities/prosper/windsong-ranch-6b";
			}
			if(comUrl == null && sharedName.contains("windsong-ranch-creekside")) {
				comUrl="/communities/prosper/windsong-ranch-creekside-and-the-enclave";
			}
			if(comUrl == null && sharedName.contains("edgewater")) {
				comUrl="/communities/fate/edgewater";
			}
			if(comUrl == null && sharedName.contains("the-grove-frisco")) {
				comUrl="/communities/frisco/the-grove-frisco";
			}
//			if(!comUrl.contains("fort-worth/tavolo-park"))continue;
			//
		//	
			String comName = U.getSectionValue(comSec, "\"com_name\":\"", "\"");
//			U.log(comName);
			String comId= U.getSectionValue(comSec, "\"_id\":\"", "\"");
//			U.log("this is comId::"+comId);
			int k=0;

//			for(String plan:plans) {
////				U.log(plan);
////				if(k<3)break;
//				String containedIn = U.getSectionValue(plan, "[{\"community\":\"", "\"");
////				if(containedIn==null)continue;
////				U.log(containedIn.contains(comId)+containedIn+":::"+comId);
//				if(containedIn!=null && containedIn.contains(comId)) {
//					if(plan.contains("{\"community\":\""))continue;
//					U.log(plan);
//					//					k++;
//					planData+=plan;
//				}
//			}
//			U.log(k);
			if(planData=="") {
				plans= U.getValues(html, "{\"community\":\"", ",\"last_imported\"");
				U.log("this is new length::::"+plans.length);
				for(String plan:plans) {
//					if(k>3)break;
					plan="{\"community\":\""+plan;
//					U.log(plan);
					String containedIn = U.getSectionValue(plan, "{\"community\":\"", "\"");
//					U.log(">>>>>>>>>>>>>>>>>>>"+containedIn.contains(comId)+containedIn+":::"+comId);
					if(containedIn!=null && containedIn.contains(comId)) {
						
						planData+=plan;
						k++;
					}
				}
			}
//			U.log(planData);
			for(String home:homes) {
				String containedIn= U.getSectionValue(home, "\"containedIn\":\"", "\"");
				if(containedIn.contains(comId)) {
//					U.log(home);
					if(home.contains("\"inv_show\":0"))continue;
					homeData+=home;
				}
			}
//			U.log(comUrl);
//			U.log("comName=="+comName);
//			U.log(comUrl);
			addInfo(comUrl,comName,comSec,homeData,planData,comId);
			inr++;
//			 break;
		}

		LOGGER.DisposeLogger();
		driver.quit();
	}
	
	//TODO:
	private void addInfo(String comUrl,String comName,String commSec,String homes,String plans,String comId) throws Exception {
		{
			U.log("Count=== "+j);
		//url == comUrl
//		U.log(">>>>>>>>>>)))))))))))");
		if(comUrl==null)return;
		if(comUrl.contains("/castle-hills-northpointe"))
			comUrl=comUrl.replace(comUrl, "/communities/carrollton/castle-hills-northpointe");
		comUrl= "https://www.shaddockhomes.com"+comUrl;
		
	
//		if(comUrl.contains("https://www.shaddockhomes.com/communities/prosper/windsong-ranch-creekside")) {
//			LOGGER.AddCommunityUrl(comUrl+"::::::::::::PAGE NOT FOUND:::::::::::");
//			return;
//			}
//		return;
			
			
		//TODO: Single Run
//		if(!comUrl.contains("https://www.shaddockhomes.com/communities/fate/edgewater")) return;
		
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"::::::::::::REPEATED:::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		//U.log(plans);
//		U.log("---------------------");
	//	U.log(homes);
		U.log("COMMUNITY URL: "+comUrl);
		if(comUrl.contains("/communities/frisco/the-grove-frisco"))
		{
			comName="the grove";
		}
		//name == comName
		U.log("COMMUNITY NAME: "+comName);
		String html="";
		html=U.getHTML(comUrl);
		
		U.log(U.getCache(comUrl));
//		U.log("html   "+html);
		String[] Sec=U.getValues(html, "{\"community\":\""+comId, "}");
		
		String remove=U.getSectionValue(html, "window.__PRELOADED_STATE__ = ", "}</script>");
//		html=U.removeSectionValue(html, "window.__PRELOADED_STATE__ = ", "}</script>");
		html=html.replace(remove, "");
		String scriptSec = U.getSectionValue(html, "window.__PRELOADED_STATE__", "</html");
		html=html.replace(scriptSec, "");
		if(comName==null) {
			
			comName=U.getSectionValue(html, "<title data-react-helmet=\"true\">","|");
		}
		comName=comName.replace("&#x27;", "-").replace("Lakewood at Brookhollow - 55- Lots", "Lakewood at Brookhollow - 55 Lots")
				.replaceAll("- Phase \\d", "");
		U.log("comName===="+comName);
		//------------UNIT COUNT------------
 		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK; 
		
		String lotUrl=comUrl+"#site-plan";
		
		U.log("lotUrl ::" + lotUrl);
		
		String lotHtml=U.getHtml(lotUrl, driver);
		U.log(U.getCache(lotUrl));
		
		String[] lotSection=U.getValues(lotHtml, "<path class=\"leaflet-interactive", "\"/>");
		if(lotSection.length>0)
		counting=Integer.toString(lotSection.length);
		
		U.log("counting ::"+counting);
		
		//address--------------------
		String geo = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String address[] ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		address[0] = U.getSectionValue(commSec, "\"streetAddress\":\"", "\"");
		address[1] = U.getSectionValue(commSec, "\"addressLocality\":\"", "\"");
		address[2] = U.getSectionValue(commSec, "\"addressRegion\":\"", "\"");
		address[3] = U.getSectionValue(commSec, "\"postalCode\":\"", "\"");
		U.log(Arrays.toString(address));
		//lat long==========================
		String latlngSec = U.getSectionValue(commSec, "\"geoIndexed\":[", "],\"gradeSchool\"");
		if(latlngSec!=null) {
		String latLng[] = latlngSec.split(",");
		lat =latLng[1];
		lng=latLng[0];
		}
		U.log(lat+"::"+lng);
		//String geo===
		geo = "False";
		address[0]=address[0].replaceAll("Closeout Community! By Appointment Only|By Appointment Only|Model Coming Soon|Coming Soon!|Visit our Model in Edgestone at Legacy|Visit us in Lakewood at Brookhollow - 55'!", "");
		
		//for edgewater
		if(comUrl.contains("/communities/fate/edgewater")) {
			
			String salesCenter = ALLOW_BLANK;
			if(html.contains("Sales Center</b></span>") && html.contains("a href=\"tel")) {
				
				salesCenter = U.getSectionValue(html, "Sales Center</b></span>", "a href=\"tel");
				
				salesCenter = salesCenter.replaceAll("<!-- /react-text --></span><span data-reactid=\"128\"><|<span class=\"CommunityDetails_sales\" data-reactid=\"121\">|<span class=\"CommunityDetails_sales\" data-reactid=\"122\"><!-- react-text: 123 -->|<!-- /react-text --><!-- react-text: 124 -->, <!-- /react-text --><!-- react-text: 125 -->|<!-- /react-text --><!-- react-text: 126 --> <!-- /react-text --><!-- react-text: 127 -->", "");
				salesCenter = salesCenter.replace("634 Caprice Bluff</span>FateTX75189", "634 Caprice Bluff, Fate, TX 75189");
				
				U.log("salesCenter: "+salesCenter);
				
				address = U.getAddress(salesCenter);
				U.log("ADDRESS: "+Arrays.toString(address));
				
				String latlong = U.getSectionValue(html, "https://www.google.com/maps/place/", "/@");
				U.log("latlong: "+latlong);
				
				String[] latLng = latlong.split(",");
				lat = latLng[0];
				lng = latLng[1];
			}
			
			 
		} 
		
		if(address[0].length()<2 && address[1].length()>2 && address[2]!=null && (lat!=null && lat.length()>3)) {
			address[1]= U.getAddressGoogleApi(new String[] {lat,lng})[1];
		}
		if(address[0].length()<2 && (lat!=null && lat.length()>3)) {
			String add1[] = U.getAddressGoogleApi(new String[] {lat,lng});
			if(add1 == null)
				add1 =U.getAddressHereApi(new String[] {lat,lng});			
			address[0]= add1[0];
			geo="TRUE";
		}
		if(address[1].length()>2 && lat==ALLOW_BLANK) {
			String latlng[]= U.getlatlongGoogleApi(address);
			if(latlng == null)latlng = U.getlatlongHereApi(address);
			lat=latlng[0];
			lng = latlng[1];
			geo="TRUE";
		}
		if(address[0].length()<2 && (lat!=null && lat.length()>3)) {
			String add1[] = U.getAddressGoogleApi(new String[] {lat,lng});
			if(add1 == null)add1 =U.getAddressHereApi(new String[] {lat,lng});
			
			address[0]= add1[0];
			geo="TRUE";
		}
		//String minmaxprice
//		U.log(plans);
		if(comUrl.contains("/frisco/villages-of-stonelake-estates"))plans=ALLOW_BLANK;
		plans=plans.replaceAll(",\"inv_price\":\\d+|\"sqft\":3085|inv_sqft\":\\d+|,\"com_sqftHigh\":\\d{4}|\"com_sqftHigh\":\\d{4}|,\"com_sqftLow\":\\d+|sqftLow\":\\d+|\"cmod_basePrice\":\\d+|\"com_priceLow\":\\d+", "");
		homes=homes.replaceAll(",\"com_sqftHigh\":\\d{4}|\"mod_sqftDisplay\":\\d{4}|\"sqft\":3085,\"status\":\"\",|\"sqft\":\\d{4}|\"com_sqftHigh\":\\d{4}|,\"com_sqftLow\":\\d+|sqftLow\":\\d+|\"cmod_basePrice\":\\d+|\"com_priceLow\":\\d+", "");
		 comId= U.getSectionValue(commSec, "\"_id\":\"", "\"");
		plans= plans.replace("{\"community\":\""+comId+"\",", "Community_Price:");
		homes= homes.replace("{\"community\":\""+comId+"\",", "Community_Price:");
//		U.log(plans);
		commSec = commSec.replaceAll("com_priceLow\":(705|630|390)|com_priceLow\":\\d+", "");
		String[] minmaxPrice = { ALLOW_BLANK, ALLOW_BLANK };
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	//	U.log(commSec);
		String priceSec = U.getSectionValue(html, "<div class=\"CommunityDetails_price", "</div>");
		String priceSec2= null;
//				U.getSectionValue(html, "Available Floor Plans</h3></div><div", "Site Plan</h3>");
//		priceSec2=priceSec2.replaceAll(" <!-- /react-text --><b data-reactid=\"\\d{3}\">", "");
		plans=plans.replaceAll("\"price\":763000", "");
		for(String newSec : Sec)
		{
			priceSec2+=newSec;
		}
//		U.log(">>>>>>>>>>>>>>****"+priceSec2);
		minmaxPrice = U.getPrices((priceSec + commSec+priceSec2+html),
						"HomeCard_price\" data-reactid=\"\\d+\">\\$\\d,\\d{3},\\d{3}</span>|Price Range</b><!-- react-text: \\d{3} --> From the \\$\\d+,\\d+|\"price\":\\d+|Price:\\$\\d+,\\d+| and \\$\\d,\\d{3},\\d{3}| Lots from \\$\\d,\\d{3},\\d{3}|\"com_priceLow\":\\d{6}|\"inv_price\":\\d{6}|,\"price\":\\d{6}|>\\$\\d{3},\\d{3}</span>|Community_Price:\"communityModelProperties\":\\{\"price\":\\d{6,7}|From the \\$\\d{3},\\d{3}",
						0);
//		U.log(":::::::::::::\n"+Sec);
//		U.log("mmmmmm"+Util.matchAll(priceSec + commSec+priceSec2+html, "[\\w\\s\\W]{60}1,072[\\w\\s\\W]{30}", 0));
		
		
		U.log(Arrays.toString(minmaxPrice));
		minPrice = (minmaxPrice[0]==null) ? ALLOW_BLANK : minmaxPrice[0];
		maxPrice = (minmaxPrice[1]==null) ? ALLOW_BLANK : minmaxPrice[1];
		//sqft==================
		//U.log(commSec);
		
		commSec = commSec.replace("sqftHigh", "com_sqftHigh").replaceAll("\"sqft\":\\d{4}", "");
		String[] minmaxSqft = { ALLOW_BLANK, ALLOW_BLANK };
//		U.log(">>>>>>>"+commSec);
		html=html.replaceAll("<!-- react-text: \\d+ -->", "");
		plans=plans.replace("\"mod_sqftDisplay\":3396", "");
		minmaxSqft = U.getSqareFeet(html+commSec+homes+plans,
						"\\d,\\d{3}-\\d,\\d{3} square feet|SQ FT Range</b> \\d,\\d+ - \\d,\\d+|from \\d,\\d{3} to \\d,\\d{3} square feet|\"com_sqftHigh\":\\d{4},|\"inv_sqft\":\\d{4},|\"sqft\":\\d{4},|mod_sqft\":\\d{4},|\"mod_sqftDisplay\":\\d{4}|Range</b> \\d,\\d{3} - \\d,\\d{3}",
						0);
//		U.log(Util.matchAll(plans, "[\\s\\w\\W]{100}3396[\\s\\w\\W]{100}", 0));

		
		minmaxSqft[0] = (minmaxSqft[0]==null) ? ALLOW_BLANK : minmaxSqft[0];
		minmaxSqft[1] = (minmaxSqft[1]==null) ? ALLOW_BLANK : minmaxSqft[1];
		U.log(Arrays.toString(minmaxSqft));
		
		//ctype ===========
		String ctype = U.getCommType(commSec.replaceAll("light at Country Club Estates|left at Country Club", ""));
		
		//propstatus=============
		String status=ALLOW_BLANK;
//		U.log(Util.matchAll(commSec, "[\\w\\s\\W]{30}country[\\w\\s\\W]{30}", 0));
//		commSec = commSec.replace("Two Final Inventory Opportunities", "Two Final Opportunities");
//		U.log(commSec);

		commSec = commSec.replace("NEW PHASE! NOW SELLING", "NEW PHASE NOW SELLING").replace("NEW FORT WORTH AVAILABLE LOTS", "NEW LOTS AVAILABLE")
				.replaceAll("PHASE \\d COMING SUMMER 2021", "3").replaceAll("open in early \\d{4}", "open early 2022")
				.replaceAll("kitchen coming May 2020|\"status\":\"Sold|\"SOLD OUT|NOW SELLING PHASE 7A|\\d+cstrong>NOW|\"NOW SELLING|Closeout\"|CLOSEOUT\"|retail developments coming soon |strong>Now Selling!|NOW SELLING PHASE 3!|School Coming|Soon\",\"telephone|com_street1\":\"Coming|SHADDOCK HOMES COMING|q=Coming|underline;'>FINAL |ACRE LOTS", "");
		status = U.getPropStatus(commSec.replaceAll("Lake lots available! In addition|Texas set to open early 2022", "").replace("amp; ", "&"));
		
		
//		U.log(Util.matchAll(commSec, "[\\s\\w\\W]{30}Limited Opportunities[\\s\\w\\W]{30}", 0));
//		U.log(Util.matchAll(commSec, "[\\s\\w\\W]{30}limited[\\s\\w\\W]{30}", 0));
		U.log(status);

		//proptype==============
		commSec = commSec.replace("\"stories\":2", "2 story").replace("\"stories\":1", "1 story").replace("custom options to make your home", "custom homes options to make your homes");
		String pType = U.getPropType((commSec+homes).replace("custom options to personalize your home", "custom-built home").replaceAll("\\.sold|-->Sold<!--|ColorSold|Modern Farmhouse elevation|description\":\"Lakes at Legacy model features a Modern Farmhouse|Villas at Preston Hollow|\"customFeatures\":|\"custom_description\"|find your new custom home|Village|village|villas at preston hollow|by an HOA to ensure|\"mod_style\":\"Single Family\"", ""));
		U.log(pType);
//		U.log(">>>>>>>>>>"+Util.matchAll((homes), "[\\w\\s\\W]{100}luxury options unique[\\w\\s\\W]{100}", 0));

		//dproptype==============
		html = html.replaceAll("story \\d bedroom", "story")
				.replaceAll("2</b><!-- react-text: \\d{3} --> Stories", "2 Story");
//		U.log(">>>>>>>>>>"+Util.matchAll((html), "[\\w\\s\\W]{100}luxury options unique[\\w\\s\\W]{100}", 0));

		String rem = U.getSectionValue(html, "Ready to Get Started", "</html>");
		if(rem==null)
			rem = "";
		
		if(plans!=null)
			plans = plans.replace("\"stories\":2", " 2 Story").replace("\"stories\":1", " 1 Story").replace("\"stories\":3", " 3 Story");
		if(homes!=null)
			homes = homes.replace("\"stories\":2", " 2 Story").replace("\"stories\":1", " 1 Story").replace("\"stories\":3", " 3 Story");

		
		String dType = U.getdCommType((commSec+html+plans+homes).replace(rem, "")
				.replaceAll("story \\d bed|the Pittsburg and Milano, are 1-story homes while the rest are 2-story homes|\\d{4} Floor|ranch|Ranch|RANCH", "").replaceAll(" one story ", " 1 story ").replaceAll("one and two story|one –and two-story ", " 1 Story 2 Story "));
		U.log(dType);
		String quickHomePrices[] = U.getValues(homes, "\"price\":", ",");
/*		if(homes.contains("\"inv_show\":1")) {
			status = status+", Quick Move-in Homes";
		}
*/		if(quickHomePrices.length > 0){
			if(status != ALLOW_BLANK) status = status+", Quick Move-in Homes";
			else if(status == ALLOW_BLANK) status = "Quick Move-in Homes";
		}
		status = status.replace("7a", "7A").replace("Phase 4 Coming Soon, Coming Soon", "Phase 4 Coming Soon");
		
		if(comUrl.contains("https://www.shaddockhomes.com/communities/prosper/lakewood-at-brookhollow-74-lots"))
			comName="Lakewood At Brookhollow - 74 Lots";
//		if(comUrl.contains("https://www.shaddockhomes.com/communities/frisco/edgestone-at-legacy")) { 
//				status=status.replace("Phase 4 Coming Soon", "Phase 4 Coming Mid Summer 2021");
//		}
		if(comUrl.contains("https://www.shaddockhomes.com/communities/mckinney/wilmeth-ridge"))pType+=", Luxury Homes";
		if(comUrl.contains("communities/prosper/windsong-ranch-creekside"))dType=dType+", 2 Story";
		if(comUrl.contains("https://www.shaddockhomes.com/communities/parker/kings-crossing"))status=status.replace("Sold Out","Phases 2 & 4 Sold Out");
		if(comUrl.contains("https://www.shaddockhomes.com/communities/parker/whitestone-estates"))status=status.replace("Sold Out","Phases 1 & 2 Sold Out");
		
		
		if(html.contains("Luxury Included</h3>"))
			if(pType==ALLOW_BLANK)
				pType = "Luxury Homes";
			else if(!pType.contains("Luxury Homes"))
				pType += ", Luxury Homes";
				
		//json does not contain price but page shows Dt:21jul21
		if(comUrl.contains("/parker/whitestone-estates"))pType=pType+", Luxury Homes";
//		if(comUrl.contains("/fort-worth/westworth-falls"))maxPrice="$774,000";
		if(comUrl.contains("communities/prosper/lakes-at-legacy"))status=status.replace(", Quick Move-in Homes", "");
		if(comUrl.contains("/st-paulwylie/inspiration"))pType=pType.replace(", Homeowner Association, Patio Homes", "");
//		, Homeowner Association, Patio Homes
		if(comUrl.contains("https://www.shaddockhomes.com/communities/st-paulwylie/inspiration"))pType=pType.replace(", Homeowner Association, Patio Homes, Luxury Homes", "");
		if(comUrl.contains("https://www.shaddockhomes.com/communities/st-paulwylie/inspiration")) status=ALLOW_BLANK;
		
//		U.log("pType>>>>>>>>>>"+pType);
		//notes=============


		
		String note = ALLOW_BLANK;
		commSec = commSec.replace("NEW PHASE! NOW PRE-SELLING", "NEW PHASE NOW PRE-SELLING");
		note = U.getnote(commSec);
		
//		if(comUrl.contains("https://www.shaddockhomes.com/communities/allen/the-village-at-twin-creeks"))status+=", Limited opportunities left";//from img

		
		data.addCommunity(comName, comUrl, ctype);
		data.addAddress(address[0].replace("Sales Office At:", ""), address[1], address[2], address[3]);
		data.addSquareFeet(minmaxSqft[0], minmaxSqft[1]);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status.replace("-,", ""));
		data.addNotes(note);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
		j++;
	}
	}
	//TODO :
/*	private void addInfo(String commInfo) throws Exception {
//		if(j==5)
		{
		U.log(">>>>>>>>>>");
		String comm = U.getSectionValue(commInfo, " <a href=\"", "</a");

		String commdata[] = comm.split("\">");
		String communityUrl = "https://www.shaddockhomes.com" + commdata[0];

		U.log("::::::::"+j+"\nPAGE: " + communityUrl+"\n"+U.getCache(communityUrl));
		String commHtml = U.getPageSource(communityUrl);
		//U.log("=========com+++++++++"+commHtml);
		String coHtml1 = commHtml;
		commHtml = commHtml.replace("Country Club Road", "");

		//===== Remove Section ==========
		String [] removes = U.getValues(commHtml, "<form", "</form>");
		for(String rem : removes) commHtml = commHtml.replace(rem, "");
		String rem = U.getSectionValue(commHtml, "<head>", "</head>");
		if(rem != null) commHtml = commHtml.replace(rem, "");
		
		commHtml = commHtml.replace("Lakeside section of Windsong Ranch", "Lakeside Living");
		String type = U.getCommunityType(commHtml.replace("Shaddock Creek Estates - Gated Community", ""));
		String baseCommHtml = commHtml;

		commHtml = commHtml.replaceAll("\\s+", " ");
		// Comm Name
		String commName = commdata[1].trim();

		// Lat Long
		String geo = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String adrSec = U.getSectionValue(commHtml,
				"Sales Center", "</p>");
		//U.log("**********************************"+adrSec.trim());
		String address[] ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		if(communityUrl.contains("https://www.shaddockhomes.com/villages-of-stonelake-est-phase-2b")){
			address[0]="14688 Huffman Lane";
			address[1]="Frisco";
			address[2]="TX";
			address[3]="75035";
		}
		if(communityUrl.contains("https://www.shaddockhomes.com/villages-of-stonelake-est-phase-ia-80-lots")){
			address[0]="15179 Camden Ln";
			address[1]="Frisco";
			address[2]="TX";
			address[3]="75035";
		}
		
		if(adrSec!=null&&address[0]==ALLOW_BLANK){
			adrSec=U.getSectionValue(adrSec, "\">", "</a>").replace("<br/>", ",").replaceAll("Model Coming Soon!|Coming Soon!", "");
			String adrsss[]=adrSec.split(",");
			address[0]=adrsss[0];
			address[1]=adrsss[1];
			address[2]=USStates.abbr( adrsss[2].replaceAll("\\d+", "")).trim();
			address[3]=adrsss[2].replaceAll("[A-Za-z]+", "").trim();
			
		}
		U.log("**********************************"+address.length);

		String latsec = U.getSectionValue(commHtml, "coords\":[\"", "\"]");
		String latlng[] = latsec.split(",");
		lat = latlng[0].replace("\"", "");
		lng = latlng[1].replace("\"", "");
		lat = (lat == null) ? ALLOW_BLANK : lat;
		lng = (lng == null) ? ALLOW_BLANK : lng;
		if (lat != ALLOW_BLANK)
			geo = "FALSE";
		U.log("Lat :" + lat + " Long :" + lng);

		
		//U.log((U.getSectionValue(coHtml1, " <div class=\"comm_nav_list\">", "Siteplan")));
		String homeHtml = Util
				.match(coHtml1,
						"\">\\W+<a href=\"(.*?)\">\\W+Quick Move-In Homes\\W+</a>",
						1);
		//U.log("HomeHtml::::" + homeHtml);

		homeHtml = U.getPageSource("https://www.shaddockhomes.com/" + homeHtml);
		String planUrl = Util.match(baseCommHtml,
				"cf\">\\s+<a href=\"(.*?)\">\\s+Floor Plans\\s+</a>",
				1);
		String plansHtml="";
		String qhomeH="";
		String[] qhomeurl=U.getValues(homeHtml, "<div class=\"horiz_result_right_thirds_col03\">","View Detail");
		for(String s:qhomeurl)
		{
			U.log("qUrl ::"+"https://www.shaddockhomes.com"+U.getSectionValue(s, "<a href=\"", "\""));
			String _qHtml = U.getHTML("https://www.shaddockhomes.com"+U.getSectionValue(s, "<a href=\"", "\""));			
			qhomeH=qhomeH+ _qHtml.replace(U.getSectionValue(_qHtml, "<head>", "</head>"), "");
		}
		U.log("planUrl : "+planUrl);
		plansHtml = U.getPageSource("https://www.shaddockhomes.com" + planUrl);
		//U.log("plansHtml::"+plansHtml);
		String allPlnHtml =ALLOW_BLANK;
		if(plansHtml.contains("Available Floor Plans"))
		{
			U.log("::::::::::Plan:::::;");
			ArrayList<String> plnUrls = Util.matchAll(plansHtml, " <div class=\"vert_results_box\">\\s*<a href=\"(.*?)\">", 1);
			U.log("plnUrls:"+plnUrls.size());
			for(String plnUrl : plnUrls){
				
				U.log("plnUrl::https://www.shaddockhomes.com"+plnUrl);
				String tempPlanHtml =U.getHTML("https://www.shaddockhomes.com"+plnUrl);
				if(tempPlanHtml != null)
				allPlnHtml += U.getSectionValue(tempPlanHtml, "Floor Plan Description", "</div>")
						+U.getSectionValue(tempPlanHtml, "detail_info_box", "</div>");

			}
		}
		
		
		commHtml = commHtml.replace("550&#39;s", "$550,000");
		commHtml = commHtml.replace("'s", ",000");
		commHtml = commHtml.replace("0s", "0,000");
		String[] minmaxPrice = { ALLOW_BLANK, ALLOW_BLANK };
		String availableHome = ALLOW_BLANK;
		
		String floHtml = ALLOW_BLANK;
		minmaxPrice = U
				.getPrices(
						homeHtml + plansHtml + baseCommHtml,
						"<h4>\\s+\\$\\d{1},\\d{3},\\d{3}\\s+</h4>|<h4>\\$\\d{3},\\d{3}</h4>|Base Price: \\$\\d{1},\\d{3},\\d{3}|Base Price: \\$\\d{3},\\d{3}|From the\\s*\\$\\d{3},\\d{3}|Base Price:\\s*\\$\\d{3},\\d{3}|<h4>\\s*\\$\\d{3},\\d{3}\\s*</h4>|14px;\">\\$\\d{3},\\d{3}</h3>|Base Price: \\$\\d{3},\\d{3}</h3>|\\$\\d{3},\\d{3}",
						0);
	
		if (minmaxPrice[0] == null) {
			if (!communityUrl
					.contains("https://www.shaddockhomes.com/rolling-ridge-estates---last-opportunity")) {
				availableHome = U.getPageSource(communityUrl
						+ "-Available-Homes");
				floHtml = U.getPageSource(communityUrl + "-Floorplans");
				minmaxPrice = U
						.getPrices(
								availableHome + floHtml + homeHtml,
								"<h4>\\$\\d,\\d{3},\\d{3}</h4>|14px;\">\\$\\d+,\\d+</h3>|Base Price: \\$\\d+,\\d+</h3>|\\$\\d+,\\d+|<h4>\\$\\d+,\\d+</h4>",
								0);
			}
		}
		U.log("*********Price********");
		U.log(minmaxPrice[0]);
		U.log(minmaxPrice[1]);
		
		minmaxPrice[0] = (minmaxPrice[0] == null) ? ALLOW_BLANK
				: minmaxPrice[0];
		minmaxPrice[1] = (minmaxPrice[1] == null) ? ALLOW_BLANK
				: minmaxPrice[1];
		String[] minmaxSqft = { ALLOW_BLANK, ALLOW_BLANK };
		// SQ FT: 3,857//SQ FT Range:</span> 2,700 - 4,000
		//U.log(homeHtml);
		minmaxSqft = U
				.getSqareFeet(
						homeHtml + plansHtml + commHtml + baseCommHtml +floHtml,
						"\\d,\\d{3} to \\d,\\d{3} square feet| SQ FT: \\d{4}\\s+</p>|SQ FT: \\d+,\\d+|SQ FT:\\s*\\d+,\\d+|SQ FT Range:\\s*</span>\\s*\\d+,\\d+ - \\d+,\\d+|Square Feet:</strong>[^<]+|\\d+,\\d+ square feet",
						0);
		U.log("minmaxSqft[0]::"+minmaxSqft[0]);
		if (minmaxSqft[0] == null) {
			minmaxSqft = U.getSqareFeet(availableHome + floHtml + baseCommHtml,
					"Square Feet:</strong>[^<]+|\\d+,\\d+ square feet", 0);

		}
		U.log("*********Sqft********");
		U.log(minmaxSqft[0]);
		U.log(minmaxSqft[1]);

		minmaxSqft[0] = (minmaxSqft[0] == null) ? ALLOW_BLANK : minmaxSqft[0];
		minmaxSqft[1] = (minmaxSqft[1] == null) ? ALLOW_BLANK : minmaxSqft[1];

		if (communityUrl
				.contains("https://www.shaddockhomes.com/community_profile.php?com=19"))
			minmaxPrice[0] = "$500,000";

		String status = ALLOW_BLANK;

		//================== Remove Form Section ==================
		commHtml=U.removeSectionValue(commHtml, "<div class=\"wrapper_footer\">", "</html");

//		String [] remove = U.getValues(commHtml, "<div class=\"modal fade\"", "<div class=\"clear clearfix\">");
//		U.log("Remove =="+remove.length);
//		for(String rem : remove)
//			commHtml = commHtml.replace(rem, "");
		commHtml = commHtml.replaceAll("F\\s*</span>\\s*<span style=\"color: #ff0000; text-decoration: underline;\">\\s*INAL OPPORTUNITY", "FINAL OPPORTUNITY").replaceAll("developments coming soon including", "").toLowerCase().replaceAll(
				"coming spring 2015|park-final opportunity|NEW MODEL NOW OPEN|quick|MOVE-IN READY NOW".toLowerCase(), "");
		status = U.getPropStatus(commHtml.replaceAll("Ranch-CLOSEOUT|Closeout\"|acre lots available|Acre Lots Available|ACRE LOTS AVAILABLE!|Model Coming Soon|southpointe coming soon|southpointe-coming-soon|shaddock place by the lake - coming soon", ""));
//		U.log("\"MMMMMMMMMMMMMmm \"+"+Util.matchAll(commHtml, "[\\w\\s\\W]{30}Lots Available[\\w\\s\\W]{100}", 0));

		

		if (communityUrl
				.contains("https://www.shaddockhomes.com/kings-crossing-model-coming-soon!"))
			status = "Coming Soon";
		
		//U.log(qhomeH);
		String pType = U.getPropType((qhomeH+commHtml+allPlnHtml).replaceAll("Villas at Preston Hollow|find your new custom home|Village|village|villas at preston hollow", ""));
		
//		 U.log(Util.matchAll(qhomeH+commHtml+allPlnHtml, "[\\w\\s\\W]{30}villas[\\w\\s\\W]{30}", 0));

		

	
		U.log("name is " + commName);
		commName = commName.replaceAll(
				" - Gated Community| - Last Opportunity|. Phase III &amp; V - 90' Lots|. Phase IV - 64' Lots| - Coming Soon", "");
		if (status == ALLOW_BLANK)
			status = "";
		
		
		String quick = U.getHTML(communityUrl+"-homes");
		
		if (quick.contains("<div class=\"horiz_result_item\">")) {
			if (status.length() < 1) {
				status = "Quick Move-ins Available";
			} else if (!status.contains("Quick")) {
				status += ", Quick Move-ins Available";
			}
		} else {
			if (status.length() < 1) {
				status = "No Quick Move-In";
			} else if (!status.contains("Quick")) {
				status += ", No Quick Move-In";
			}
		}

		if (communityUrl
				.contains("https://www.shaddockhomes.com/shaddock-park-final-opportunity")) {
			String latlngs[] = U.getlatlongGoogleApi(address);
			if(latlngs == null) latlngs = U.getlatlongHereApi(address);
			lat = latlngs[0];
			lng = latlngs[1];
			geo = "True";
		}
		
		address[0] = address[0].replaceAll("Visit our Sales Office at |Call Kim Stewart Today!|King's Crossing", "");
		if(address[0].length()<3){
			address=U.getAddressGoogleApi(new String []{lat,lng});
			if(address == null)address = U.getGoogleAddressWithKey(latlng);
			if(address == null)address = U.getAddressHereApi(new String []{lat,lng});
			geo="True";
		}
		address[0]=address[0].replaceAll("By Appointment Only |Visit us at Lexington Country in Frisco |Sales Office at:|Sales Center:|Visit our Sales Office at Light Farms!|See Sales Office at", "");
		U.log("*#*#   " + address[0]);
		U.log("*#*#   " + address[1]);
		U.log("*#*#   " + address[2]);
		U.log("*#*#   " + address[3]);
		if(address[0].length()<4){
			latlng[0]=latlng[0].replace("\"", "");
			latlng[1]=latlng[1].replace("\"", "");
			address = U.getAddressGoogleApi(latlng);
			if(address == null)address = U.getGoogleAddressWithKey(latlng);
			if(address == null)address = U.getAddressHereApi(latlng);
			geo ="TRUE";
		}
        U.log(commHtml);
		coHtml1=coHtml1.replaceAll("Ranch|RANCH|ranch", "");
		String dType = U.getdCommType(allPlnHtml.replaceAll("ranch|Ranch|RANCH", "")+commName+coHtml1+qhomeH.replaceAll("lots! Two floor plans, the Pittsburg and Milano, are 1-story homes while the rest are 2-story homes|ranch|Ranch|\\d+ plan","").replaceAll(" one story ", " 1 story "));
		commName = commName.toLowerCase().replaceAll("-coming spring 2015|-closeout$", "")
				.replaceAll("- now selling!", "").replaceAll("&amp;", "&");
		commName=commName.replace("phase ia", "Phase IA").replace(" phase iii", " Phase III").replace("phase iv", "Phase IV");
		U.log("commName::"+commName);
		if(commName.endsWith("estates"))pType=pType+", Estate-Style Homes";

		commHtml = U.getSectionValue(commHtml, "html", "modal-footer");
		
		
		status = status.replace("Phase 7a", "Phase 7A").replace("Phase 4 Coming Soon, Coming Soon", "Phase 4 Coming Soon");
		U.log(address[0].length());
		if(communityUrl.contains("https://www.shaddockhomes.com/communities/allen/the-village-at-twin-creeks"))status="Limited Opportunity Left";
		if(communityUrl.contains("https://www.shaddockhomes.com/communities/frisco/estates-at-rockhill-phase-3"))minmaxPrice[1]="$805,000";
		LOGGER.AddCommunityUrl(communityUrl);
		data.addCommunity(commName.replaceAll("- 74 Lots|- 55- Lots", ""), communityUrl, type);
		data.addAddress(address[0].replace("Sales Office At:", ""), address[1], address[2], address[3]);
		data.addSquareFeet(minmaxSqft[0], minmaxSqft[1]);
		data.addPrice(minmaxPrice[0], minmaxPrice[1]);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(status.replace("-,", ""));
		data.addNotes(U.getnote(commHtml));
	}
		j++;
	}
*/
}