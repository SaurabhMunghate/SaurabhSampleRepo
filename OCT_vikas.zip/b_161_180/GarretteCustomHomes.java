// @author Jayashree Dighorikar

package com.shatam.b_161_180;
import java.io.File;
import java.util.Arrays;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class GarretteCustomHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;
	static int duplicates = 0;
	CommunityLogger LOGGER;
	private static String baseUrl = "https://www.garrettecustomhomes.com/";

	WebDriver driver=null;
	public static void main(String[] ar) throws Exception {

		AbstractScrapper a = new GarretteCustomHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Garrette Custom Homes.csv", a.data().printAll());
		//U.log("duplicates"+duplicates);
	}
	public GarretteCustomHomes() throws Exception {

		super("Garrette Custom Homes", "https://www.garrettecustomhomes.com/");
		LOGGER = new CommunityLogger("Garrette Custom Homes");
	}
	
	
	private void setProxyByBrowsec(){
		ChromeOptions options = new ChromeOptions ();
		
//		U.log(System.getProperty("/home/shatam-10/snap/skype/common") +"/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx");
		
		options.addExtensions (new File("/home/shatam-50/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));

		DesiredCapabilities capabilities = new DesiredCapabilities ();

		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(capabilities); //capabilities
		
	}
	
	private void setProxyForDriver(String ip, int port){

		Proxy proxy = new Proxy();
		//Adding the desired host and port for the http, ssl, and ftp Proxy Servers respectively 
		proxy.setHttpProxy(ip.trim()+":"+port);
		proxy.setSslProxy(ip.trim()+":"+port);
		proxy.setSslProxy(ip.trim()+":"+port);
//		proxy.setFtpProxy(ip.trim()+":"+port);

		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(CapabilityType.PROXY, proxy);
		
		driver = new ChromeDriver(dc);
		
	}
	
	
	public void innerProcess() throws Exception {
		  U.setUpChromePath();
	//	U.setUpGeckoPath();		 
		  setProxyByBrowsec();		  
	//	setProxyForDriver("209.40.237.43",8080);
		  
		
		int total = 0;
		//U.log(baseUrl);
		String html = U.getHtml(baseUrl,driver);//manual add vpn and change region from browser to get cache 
//		U.log(html);
//		String regUrlSections = U.getSectionValue(html, "Find Your Home", "Build On Your Land");
		String []regionUrls = U.getValues(html, "<li class=\"uk-nav-header\"><a href=\"", "\" class");
		for(String regionUrl : regionUrls){
			U.log("Reg Url=="+regionUrl);
			String regionHtml = U.getHtml(regionUrl,driver);	
			String comSec=U.getSectionValue(regionHtml, "<li class=\"comms uk-section", "<script type=\"text/javascript\">");
//			U.log(comSec);
			
			String[] comSections = U.getValues(comSec, " <div class=\"uk-cover-container\">", "</div>\n" + 
					"				        </div>");
			U.log(comSections.length);
//			LOGGER.AddRegion(regionUrl, comSections.length);
			
			
			
//			total += comSections.length;
			for(String commSec : comSections){
			//	U.log(c);
				String comUrl = U.getSectionValue(commSec, " <a href=\"", "\"");
//				String html1 = U.getHtml(comUrl,driver);
//				if(comUrl != null){
//					comUrl = comUrl.replace("/iowa-new-home-communities/","/iowa/");
					U.log("comUrl :: "+comUrl);
					
					addDetails(comUrl,commSec);
//				}
//			}//eof for inner

		}//eof for outer
		}
		U.log("Total community ::"+total);
		LOGGER.countOfCommunity(total);
		LOGGER.DisposeLogger();
		
//		driver.quit();
			

}
	private void addDetails(String comUrl, String commSec) throws Exception {
		
		// TODO Auto-generated method stub
		
			U.log("=================="+j+"\n"+comUrl);
			
			////For Single Run
		
//		if(!comUrl.contains("https://www.garrettecustomhomes.com/new-home-communities/anderson-estates/"))return;
			if(data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl+":::::::::::Reapeated:::::::::::::::::::");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String comHtml=U.getHTML(comUrl);
		
			String comName=U.getSectionValue(comHtml, "<span class=\"current\">", "</span></p>");
			comName=comName.replace("-", "").replace("| Garrette Custom Homes", "")
					.replace("| Garrette ", "")
					.replaceAll("New Homes in Bonney Lake WA at |New Homes in Bremerton WA at |Homes in Buckley WA at Bonney |Homes in Woodland WA at | Model Home in ", "");
			U.log("comName::::::::::: "+comName);
			
			
			
			String geo="FALSE";
			
			
			
//			========================ADDRESS===============================
			
			String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
			String addsec=null;
			String addSec=null;
			 addSec=U.getSectionValue(comHtml, "Driving Directions</h2>", "target=\"outside\"");
//			 U.log("addSec::::::::::: "+addSec);
			if(addSec==null)
			{
				 addsec=U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/", "\" class=");

			}
			else
				addsec=U.getSectionValue(addSec, "GPS address: <a href=\"https://www.google.com/maps/place/", "/\" ");
		addsec=addsec.replaceAll("\\+", " ");
//		.replace("OR+", "OR ").replace("WA+", "WA ")
			
		U.log("addSec::::::::::: "+addsec);
		add=U.getAddress(addsec);
		U.log("addSec:::::::::::"+Arrays.toString(add));
		
		
//		========================LATLOG===============================

		String latlong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String latlngSec=U.getSectionValue(comHtml, "<div class=\"marker\"", "</div>");
		latlong[0]=U.getSectionValue(latlngSec, "data-lat=\"", "\" ");
		latlong[1]=U.getSectionValue(latlngSec, "data-lng=\"", "\">");
		
		U.log("latlong:::::::::::"+Arrays.toString(latlong));
		
		
		
		if(add[3]==ALLOW_BLANK) {
			add=U.getAddressGoogleApi(latlong);
			geo="TRUE";
		}
		
		
		
//		========================Quick home===============================
		String quickSec=null;
		String quickData=null;
		String quickHomeSec=null;
		 quickSec=U.getSectionValue(comHtml, "Quick Move In Homes</h2>", "</div><!-- container -->");
		if( quickSec!=null) {
			String [] quickHomes=U.getValues(quickSec, " <div class=\"uk-cover-container\">", " </div>\n" + 
					"		        </div>");
			for(String quicksec:quickHomes ) {
				String url=U.getSectionValue(quicksec, "<a href=\"", "\"");
				try {
				String quickHtml=U.getHTML(url);
				quickHomeSec=U.getSectionValue(quickHtml, "<!-- Page Title", ">Request Information</h2>");
				}catch(Exception e) {
					U.log(">>>>>"+e);
				}
				
				quickData=quickData+quickHomeSec+quicksec;
			}
			
//			U.log("quickHomes:::::::::::"+quickHomes.length);
		}
		
//		========================Presale home===============================
		String presaleSec=null;
		String presaleData=null;
		String presaleHomeSec=null;
		presaleSec=U.getSectionValue(comHtml, "Presale Homes</h2>", "</div><!-- container -->");
		if( presaleSec!=null) {
			String [] presaleHomes=U.getValues(presaleSec, " <div class=\"uk-cover-container\">", " </div>\n" + 
					"		        </div>");
			for(String presalesec:presaleHomes ) 
			{
				String url=U.getSectionValue(presalesec, "<a href=\"", "\"");
				U.log(">>>>>>>>"+url);
				try {
				String presaleHtml=U.getHTML(url);
				
				if(presaleHtml.contains("<title>Page not found -  </title>"))
					presaleHomeSec=U.getSectionValue(presaleHtml, "<!-- Page Title", ">Request Information</h2>");
				
					
				}catch(Exception e) {
					U.log(">>>>>"+e);
				}
//				U.log(presaleHtml.length());
				presaleData=presaleData+presaleHomeSec+presalesec;
			}
			
		}
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		String minsqft=ALLOW_BLANK;
		String maxsqft=ALLOW_BLANK;
		
		
		commSec=commSec.replaceAll("0s|0's", "0,000").replace("Starting at $1.1 million", "Starting at $1,100,000").replace("$1 million	", "$1,000,000");
		String prices[] = U.getPrices((commSec+presaleData+quickData), 
				"<h2 class=\"uk-text-secondary\">\\$\\d,\\d+,\\d+</h2>|Starting in the low $900s|Starting at \\$\\d,\\d+,\\d+|Starting in the high \\$\\d+,\\d+|Starting in the \\$\\d+,\\d+|>Base Price</small> \\$\\d+,\\d+</strong>|Base Price</small> \\$\\d,\\d+,\\d+</strong>", 0);
		
		minPrice=prices[0];
		maxPrice=prices[1];
		U.log("::::::::::::"+Arrays.toString(prices));
		if(minPrice==null)minPrice=ALLOW_BLANK;
		if(maxPrice==null)maxPrice=ALLOW_BLANK;
		
		
		
		String sqft[]=U.getSqareFeet(commSec+presaleData+quickData, "<li>\\d,\\d+ SqFt</li>|<span class=\"fas fa-home\"></span> \\d,\\d+	", 0);
		minsqft=sqft[0];
		maxsqft=sqft[1];
		if(minsqft==null)minsqft=ALLOW_BLANK;
		if(maxsqft==null)maxsqft=ALLOW_BLANK;
		U.log("::::::::::::"+Arrays.toString(sqft));
//		html=html.replaceAll(">Golf Courses</a>|boats, stone cottages|Auburn new homes are now available|center;\">Coming Soon</h2>|The Lakeside Village outlets are only|<h2>Lakeside</h2>", "");
		String comtype=U.getCommType(comHtml+commSec);
		U.log("comtype:::::::::::::::"+comtype);
		
		String ptype=U.getPropType(comHtml+commSec+presaleData+quickData);
		U.log("ptype:::::::::::::::"+ptype);
		
		
		
		String dtype=U.getdCommType(comHtml+commSec+presaleData+quickData);
		
		U.log("dtype:::::::::::::::"+dtype);
		
		String pstatus=U.getPropStatus(comHtml+commSec);
		U.log("pstatus:::::::::::::::"+pstatus);
		
		
		data.addCommunity(comName, comUrl, comtype);
		data.addAddress(add[0].replaceAll("Off Site Sales Center|,", "").replace("** ", ""), add[1].trim(), add[2], add[3]);
		data.addLatitudeLongitude(latlong[0], latlong[1], geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(U.getnote(comHtml));
		
		j++;
		
		
	}
}
