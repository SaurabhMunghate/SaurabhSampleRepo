package com.shatam.b_161_180;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class SaussyBurbank extends AbstractScrapper {
	int i = 0;
	static String HOME_URL = "https://www.saussyburbank.com";
	static String BUILDER_NAME = "Saussy Burbank";
	static int duplicates = 0;
	CommunityLogger LOGGER;
	public int inr = 0;
	static int j=0;
	WebDriver driver = null;
	
	HashSet< String> comHashSet = new HashSet<>();
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new SaussyBurbank();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Saussy Burbank.csv", a.data()
				.printAll());
		//U.log("duplicates = "+duplicates);
	}

	public SaussyBurbank() throws Exception {

		super(BUILDER_NAME, HOME_URL);
		LOGGER = new CommunityLogger(BUILDER_NAME);
	}

	public void innerProcess() throws Exception {
	//	System.setProperty("webdriver.chrome.driver",System.getProperty("user.home")+File.separator+"/chromedriver");		driver = new ChromeDriver();//new FirefoxDriver(U.getFirefoxCapabilities());
//		U.setUpChromePath();
//		driver=new ChromeDriver();
		String html = U.getHTML("https://www.saussyburbank.com/communities/");
		html=html.replaceAll("</p>\\s*</div>\\s*</div>", "endSec");
		html = U.removeComments(html);
	
//		String comlats[]=U.getValues(html,"<div class=\"square-header\"","<div class=\"square-gradient\">");
		String comlats[]=U.getValues(html,"<div class=\"square\">","<div class=\"square-gradient\">");
		U.log(comlats.length);
		for(String LSec:comlats)
		{	
			
			String url=U.getSectionValue(LSec,"data-url=\"","\"");
//			U.log("urls---"+url);
			String comName = U.getSectionValue(LSec, "<div class=\"h3\">", "</div>");
//			U.log("Name:"+comName);
			String cityState = Util.match(html, "<div class=\"h3\">"+comName+"</div>\\s*<div class=\"h4\">\\s*(.*?)\\s*<",1);
//			U.log("cityState:"+cityState);
			adDetails(url,cityState);
//			adDetails("https://www.saussyburbank.com/communities/papillon/","Raleigh, NC");
//			adDetails("https://www.saussyburbank.com/communities/ryans-crossing/","Chapel Hill, NC");
			
		}
	
		LOGGER.DisposeLogger();
//		driver.close();
//		driver.quit();
	}

	//TODO:
	public void adDetails(String commUrl,String cityState) throws Exception {

// if(j==4)
//		if(!commUrl.contains("https://www.saussyburbank.com/communities/wild-partridge"))return; 
//		if(!commUrl.contains("https://www.saussyburbank.com/communities/nims-village-fort-mill-sc"))return;
//		if(!commUrl.contains("https://www.saussyburbank.com/communities/cottages-marvin-gardens/"))return;
//		if(!commUrl.contains("https://www.saussyburbank.com/communities/nexton-midtown/"))return;
//		try{
        {
    	String note=""; 
		//String commUrl = U.getSectionValue(commsec, "data-url=\"", "\">");
		

		U.log("Count: "+j+"\turl----"+commUrl);
	
		String commHtml = U.getHtml(commUrl, driver);		
        //U.log("comHtml---"+commHtml);
		
		String listingitems[]=U.getValues(commHtml, "open-listing-panel", "</div></a>");
		U.log("========"+listingitems.length);
		String rm=U.getSectionValue(commHtml, "<div id=\"map-panels\">", "</html>");
		if(rm!=null)
		commHtml=commHtml.replace(rm, "");
		String commName = U.getSectionValue(commHtml, "<h1>", "</h1>");
		if(commUrl.contains("https://www.saussyburbank.com/communities/custom-infill-general-contractor/"))return;
		if(commUrl.contains("https://www.saussyburbank.com/communities/ryans-crossing/"))return;
		if(commUrl.contains("https://www.saussyburbank.com/communities/papillon/"))return;//404
		if(commUrl.contains("https://www.saussyburbank.com/communities/charlotte-nc-custom-infill-new-homes/"))
		commName="In Town";
		//U.log("lllllllll----"+commHtml);
		
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		
		
		
		String latlagSec=U.getSectionValue(commHtml, "href=\"https://maps.google.com/maps?", "z=17");
		//U.log("latsec----"+latlagSec);
		if(latlagSec!=null)
		{
			latLong[0]=U.getSectionValue(latlagSec, "ll=", "\"");
			latLong[1]=U.getSectionValue(latlagSec, ",", "&amp");
		}
		U.log("lat----"+latLong[0]+"  "+latLong[1]);
		//U.log(commUrl);
//		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		if(latLong[0]==ALLOW_BLANK ) {
			latLong[0]=U.getSectionValue(commHtml, "data-lat=\"", "\"");
			latLong[1]=U.getSectionValue(commHtml, "data-lng=\"", "\"");

		}

		U.log(Util.match(commHtml, ".*areaLat.*"));
		if(latLong[0]==ALLOW_BLANK ) {
			latLong[0]=U.getSectionValue(commHtml, "var areaLat = ", ";");
			latLong[1]=U.getSectionValue(commHtml, "var areaLng = ", ";");
			
		}
		U.log("--!="+latLong[0]);
		if(latLong[0]==ALLOW_BLANK ||latLong[0]==null) {
			latLong[0]=Util.match(commHtml, "var areaLat = (\\d{2}\\.\\d+);", 1);
			latLong[1]=Util.match(commHtml, "var areaLng = (-\\d{2,3}\\.\\d+);", 1);
			if (latLong[1]==null) {
				latLong[1]=U.getSectionValue(commHtml, "var areaLng = ", ";");
			}
			U.log("--="+latLong[0]+"");
		}
	
	String[] mainSec=U.getValues(commHtml, "<!-- level 3 new -->"," <!-- end level 3 new -->");
		
		//U.log("----hhhhh------"+mainSec);
		for(String LSec:mainSec)
		{
			String urls=U.getSectionValue(LSec, "<div class=\"item\"", " <div class=\"item-title\">");
			U.log("urls-------"+urls);
			if(urls!=null)
			{
				
			latLong[0]=U.getSectionValue(urls, "data-lat=", "\"");
			latLong[1]=U.getSectionValue(urls, "data-lng=", "\"");
			}	
		}
		
	   //  U.log("hhhhtttmmllll---"+commHtml);
		if(latLong[0]==null)latLong[0]=ALLOW_BLANK;
		U.log("latlng is"+latLong[0]);

		//U.log(U.getSectionValue(commsec, ":\"", "\""));

		String geo = ALLOW_BLANK;

		String rmsec = U.getSectionValue(commHtml,
				"<div class=\"footer-nav\">", "</html>");
		if(rmsec!=null)
			commHtml = commHtml.replace(rmsec, "");

		String florrURl = U.getSectionValue(commHtml,
				"<link rel='shortlink' href='", "/>");
		String flowid=ALLOW_BLANK,flowHtml=ALLOW_BLANK;
		if(florrURl!=null){
			flowid = U.getSectionValue(florrURl, "p=", "'");
		florrURl = commUrl + "?result_page=1&community%5B%5D=" + flowid
				+ "&status=4&order_by=price_low&search_submitted=1";
		// ?result_page=1&community%5B%5D=261&status=!3%7C!4&order_by=price_low&search_submitted=1

		U.log("florrURl : "+U.getCache(florrURl));
		 flowHtml = U.getHTML(florrURl);//,driver);
			
		rmsec = U.getSectionValue(flowHtml, "<div id=\"map-panels\">",
				"</html>");
		if(rmsec!=null)
		flowHtml = flowHtml.replace(rmsec, "");
		}
		String forsale = commUrl + "?result_page=1&community%5B%5D=" + flowid
				+ "&status=!3%7C!4&order_by=price_low&search_submitted=1";
		
		U.log("forsale::"+forsale);
		String saleHTML = ALLOW_BLANK;
		boolean darkTheme=false;
		if(!commHtml.contains("<div class=\"box item\"")){
			darkTheme=true;
			saleHTML = getHtml(forsale, driver);
		}
		else{
			saleHTML = U.getHTML(forsale);
		}
		rmsec = U.getSectionValue(saleHTML, "<div class=\"footer-nav\">",
				"</html>");
		if(rmsec!=null)
		saleHTML = saleHTML.replace(rmsec, "");
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		
		String street = ALLOW_BLANK;
		String address = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String adddata=U.getSectionValue(commHtml,"<h3>Model Home","<div class=\"column\">");
		
		
		if(adddata!=null)
		{
			
			adddata=adddata.replace("NC�", ", NC").replaceAll(".*>", "");
					//.replace("Chapel Hill NC ", "Chapel Hill, NC ");
			//U.log("adddata:::::::::::::::"+adddata);
			adddata=U.getNoHtml(adddata).replace("44 Cardinal Ridge Road,   Chapel Hill   NC&nbsp;  27516", "44 Cardinal Ridge Road, Chapel Hill, NC 27516");//,
			U.log(":::::::::::;"+adddata+":::::::::::::");
			String check=Util.match(adddata, "\\s+[SNC]{2}\\s+\\d{5}");
			//"\\s+[SNC]{2}\\s+\\d{5}");
			if(check==null)
			{
				check=Util.match(adddata, ", NC�27516");
			}
			if(check==null){
				check=Util.match(adddata, " NC 27516");
			}
			if(check==null){
				check=Util.match(adddata, " NC&nbsp;  27516");
			}
			U.log("check::::::::::::"+check+":::::::::::::::::::");
			if(check!=null)
			{
			adddata=" "+adddata;
			adddata=U.getSectionValue(adddata, " ",check);
			adddata=adddata+check;
			//U.log(adddata+"****************");
			//U.log(adddata);
			adddata=adddata.replaceAll("Mon-Sat  \n" + 
					" Sun|Open Monday-Saturday 10am-6pm; Sunday 1pm-6pm|Mon-Sat: 10-6|Now Open|Sunday: 1pm-(5|6)pm|Monday-Saturday|11am-5pm|Sun: 1-6|Overview:|:","").replace(" St."," St,").replace("�","")
					.replace("Hill NC 27516", "Hill, NC 27516").replaceAll("105 Bright Leaf Loop\\s*\\n*\\s*", "105 Bright Leaf Loop,").replaceAll("Sunday|Monday|&#8211;|Saturday|\\d+(am|pm)-\\d+pm", "");
			U.log("=="+adddata.trim());
			add=U.findAddress(adddata.trim());
			street=add[0];
			city=add[1];
			state=add[2];
			zip=add[3];
			geo="FALSE";
			}
		}
		
		if(adddata==null || street.length()<3)
			adddata = U.getSectionValue(commHtml, "<p><a href=\"https://www.google.com/maps/place/", "/@");
		
		U.log("ADDRESS SEC::: "+adddata);
		
		if(adddata!=null) {
			adddata = adddata.replace("+", " ");
			adddata = U.getNoHtml(adddata);
			U.log("ADDRESS SEC1111::: "+adddata);
			add = U.getAddress(adddata);
			street = add[0];
			city = add[1];
			state = add[2];
			zip = add[3];
			geo="FALSE";
		}
		if(adddata==null)
			adddata = U.getSectionValue(commHtml, "<p><strong>Model Home:</strong></p>", "</p>");
		if(adddata!=null) {
			adddata = U.getNoHtml(adddata.replace("<br />", ","));
			U.log("ADDRESS SEC:::2 "+adddata);
			add = U.getAddress(adddata);
			street = add[0];
			city = add[1];
			state = add[2];
			zip = add[3];
			geo="FALSE";
		}
	
		
		if (latLong[0] != ALLOW_BLANK  && add[0]==ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latLong);
			if (add==null) add=U.getGoogleAddressWithKey(latLong);
			U.log("hello1");
			geo = "TRUE";
			street = add[0];
			city = add[1];
			state = add[2];
			zip = add[3];
		}
		
		
		if(latLong[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK)
		{
			U.log("::::::::::::::::::::::::"+cityState);
			
			if(cityState!=null)
			{
			add=cityState.split(",");
			city=add[0].trim();
			try
			{
			state=add[1].trim();
			}catch(Exception e)
			{
				if(city.contains("Charlotte"))
				state="NC";
			}
			}
		}
		U.log(latLong[0]);
		
		
		commHtml=commHtml.replaceAll("District \\(under construction\\)", "").replace("NOW SELLING PHASES TWO &amp; THREE", "NOW SELLING PHASES TWO & THREE");
		//U.log(":::::::::::::::::::::::::::::::::::::::::::::::"+commHtml);
		commHtml=commHtml.replace("coming to Fort Mill in the Fall of 2022", " Coming Fall 2022")
				.replace(" Coming Soon Summer of 2021", " Coming Soon Summer 2021").replace("(Opening Fall 2019)", "").replaceAll("Coming 2017|Coming Fall 2017", "").replace("coming soon)", "").replace("NOW OPEN)", "").replaceAll("Now Open at", "");
		commHtml=commHtml.replaceAll("in South Park. Move-in ready December 2019. </strong>|>Coming Soon</span>|pool \\(NOW OPEN!\\)|Model Home:</h3>\\s*<p>Coming Soon</p>|listing-item-small\">Move-In Ready|swimming pool \\(Coming Summer 2018\\)|new homes available|Masons Bend (Coming Soon)", "");
		String cType=U.getPropStatus(commHtml);
		cType=cType.replace("Only 1 Inventory Home Remains", "Only 1 Home Remains");
		commHtml=commHtml.replaceAll("now open", "");
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{30}Coming[\\s\\w\\W]{50}", 0));
		U.log("PropStatus===="+cType);
		//========= For Sale Home Html ==============
		String combinedSaleHomeHtmls = null;
		String[] saleHomeUrls = U.getValues(saleHTML, "data-link=\"", "\"");
		if(saleHomeUrls.length == 0)
			saleHomeUrls = U.getValues(saleHTML, "<a id=\"open-listing-panel\" href=\"javascript:void(0);\" data-url=\"", "\"");
		for(String saleHomeUrl : saleHomeUrls){
			U.log("saleHome:::"+saleHomeUrl);
			combinedSaleHomeHtmls += U.getHTML(saleHomeUrl);
		}
		
		//U.log("type res="+Util.match(commHtml,".*?Villa"));
		
		String StoryData=ALLOW_BLANK;
		String storySec=U.getSectionValue(commHtml, "class=\"box item\" data-link=", "class=\"pagination");
		storySec=storySec+U.getSectionValue(saleHTML, "class=\"box item\" data-link=", "class=\"pagination");
		storySec=storySec+U.getSectionValue(flowHtml, "class=\"box item\" data-link=", "class=\"pagination");
		String saleshtml="";
		if(storySec!=null){
		String[] stVals=U.getValues(storySec, "href=\"", "\"");
		U.log(stVals.length);
		for(String aaa : stVals){
//			U.log("-->"+aaa);
			//U.log(street);
			if(street==ALLOW_BLANK&&add[0]==ALLOW_BLANK)
			{
				street=U.getSectionValue(aaa, "com/listings/", "/");
				street=street.replace("-", " ");
				String[] adddr={street, city, state};
				latLong=U.getlatlongGoogleApi(adddr);
				if (latLong==null)latLong=U.getlatlongHereApi(adddr);
				adddr=U.getAddressGoogleApi(latLong) ;
				if (adddr==null) adddr=U.getGoogleAddressWithKey(latLong);
				zip=adddr[3];
				geo="TRUE";
			}
			if(aaa.length()>30)
			{
				if(aaa.startsWith("http"))
					saleshtml=saleshtml+U.getHTML(aaa);
			/*if(local==null)continue;
			StoryData=StoryData+Util.match(local, "Stories</b></td>\\W+<td>\\d");*/
			}
			
		}
		
		if(commUrl.contains("https://www.saussyburbank.com/communities/kiawah-island/")){
			saleshtml=saleshtml+U.getHTML("https://www.saussyburbank.com/listings/421-snowy-egret-lane/");
			//U.log(saleshtml);
		}
		}
		if(darkTheme){
			String[] homeList=U.getValues(saleHTML, "<div class=\"box item\"><a href=\"", "\"");
			for(String home:homeList){
				saleshtml=saleshtml+U.getHTML(home);
			}
		}

		saleshtml=saleshtml.replaceAll("<b>Stories</b></td>\\s*<td>1</td>", " 1 story ").replaceAll("Ranch</b></td><td>Yes", " Ranch ");
		saleshtml=saleshtml.replaceAll("<b>Stories</b></td>\\s*<td>2</td>", " two story");
		
	
		
		if(commUrl.contains("https://www.saussyburbank.com/communities/mount-pleasant-infill/"))
		{
			city="Mt. Pleasant";
			state="SC";
		}
		if(commUrl.contains("hillsidetowns")) {
			U.log("hellloooooooooooooo");
			city="Charlotte";
			state="NC";
		}
		
	
			U.log("latLong=="+latLong[0]+","+latLong[1]);
		
		if(street==ALLOW_BLANK)
		{
			String[] addrss={"",city,state,""};
			latLong=U.getlatlongGoogleApi(addrss);
			if (latLong==null) latLong=U.getlatlongHereApi(addrss);
			add=U.getAddressGoogleApi(latLong);
			if (add==null) add=U.getGoogleAddressWithKey(latLong);
			street=add[0];
			zip=add[3];
			geo="TRUE";
			note="Lat/Long And Street Address Taken Using City And States";
		}
		if(state==ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latLong);
			if (add==null) add=U.getGoogleAddressWithKey(latLong);
			state=add[2];
			city=add[1];
		}
		U.log(Arrays.toString(add));
		if(latLong[0].length()<4 && add[0].length()>4)
		{
			latLong=U.getlatlongGoogleApi(add);
			if (latLong==null) latLong=U.getGoogleLatLngWithKey(add);
			if (latLong==null) latLong=U.getlatlongHereApi(add);
			geo="TRUE";
		}
			/*
			 * if(commUrl.contains("https://www.saussyburbank.com/communities/sayebrook/"))
			 * street="Myrtle Beach"; city="Socastee"; state="SC"; zip="29588";
			 */
		
		if(commUrl.contains("https://www.saussyburbank.com/communities/mt-pleasant-sc-new-homes-carolina-park/"))
			geo="FALSE";
				//saleHTML=saleHTML.replace("custom home designs", "");
			
			saleHTML=saleHTML.replace("18 Opportunities Coming Soon","");
			if(commUrl.contains("https://www.saussyburbank.com/communities/highland-park/"))
	       {cType=cType.replace("Coming Soon, ","");
				cType=cType.replace("Sold Out, Phase One Sold Out","Phase One Sold Out");
	       }
//		if(saleHTML.contains("movein-ready-banner.svg")){
//			if(cType != ALLOW_BLANK && !cType.contains("Move-")) cType += ", Move-In Ready";
//			else if(cType==ALLOW_BLANK)cType = "Move-In Ready";
//		}
		
		//prices and sq.ft.
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commHtml=commHtml.replace("0s", "0,000").replace("00’s", "00,000").replace("00&#8217;s", "00,000").replace("pricing from $559k", "pricing from $559,000");
		//<h3>From the $720s</h3>
		//commsec=commsec.replace("0s", "0,000");
		commHtml=commHtml.replace("0k", "0,000");
		//1,8003,400 sq.ft.
//		commHtml = commHtml.replace("�", "-");
	     if(rm!=null)
		saleshtml=saleshtml.replace(rm, "");
		rm=U.getSectionValue(saleHTML, "<div id=\"map-panels\">", "<div class=\"footer-nav\">");
		if(rm!=null)
		saleHTML=saleHTML.replace(rm, "");
//		U.log(saleHTML);

		
		
		//=================== Price ======================================================
		
		commHtml = commHtml.replaceAll("0s", "0,000").replaceAll(" / $465,384</h5>\\s*<h5 class=\"listing-it", "");
		saleHTML=saleHTML.replaceAll("/ $465,384</h5>", "");
		String[] price = U.getPrices((commHtml + flowHtml + saleHTML+ saleshtml).replaceAll("/ $465,384</h5>", "").replace("From the $530s","From the $530,000").replace("$1.2M","$1,200,000").replace("$1M","$1,000,000").replaceAll("garages starting in the high \\$200,000", ""),
				"From the \\$\\d{3},\\d{3}|high \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|New homes from \\$\\d+,\\d+—\\d+,\\d+|New homes from \\$\\d+,\\d+|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|FROM \\$\\d{3},\\d{3}|<p>From the \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}", 0);
		
		if(commUrl.contains("https://www.saussyburbank.com/communities/bryant-towns/"))price[0]="$492,205";
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{30}638[\\s\\w\\W]{30}", 0));
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		// Sq.ft
		commHtml=commHtml.replace("—", "-");
		//U.log(U.getSectionValue(commHtml, "<h3>Quick Glance</h3>", "<div class=\"column\">"));
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
commHtml=commHtml.replace("2600+ sq. ft.", "2600 sq. ft.");
		String[] sqft = U.getSqareFeet((commHtml + flowHtml + saleHTML + saleshtml),"\\d{4} sq. ft.|\\d{4} sqft|\\d,\\d+ sq. ft. home|from \\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3}\\+ sq. ft.|From \\d+ sqft| \\d+ sq. ft.|\\d,\\d+-\\d,\\d+ sq ft|\\d,\\d+—\\d,\\d+ sq. ft.|From \\d+ sq. ft.|\\d,\\d{3}-\\d,\\d{3}\\+ sq ft|\\d{4} sq ft|\\d{4} sqft",0);
		//String[] sqft = U.getSqareFeet((commHtml + flowHtml + saleHTML + saleshtml+commsec),"\\d,\\d+ - \\d,\\d+ sq. ft.|\\d,\\d+-\\d,\\d+ sq. ft.|\\d,\\d{3}-\\d,\\d{3}\\+ sq ft |\\d,\\d+-\\d,\\d+ sq ft|\\d,\\d+ to \\d,\\d+ square feet|\\d+-\\d+ square feet|<p>\\d,\\d+—\\d,\\d+</p>|<p>\\d+-\\d+\\+</p>|<p>\\d{4}-\\d{4}</p>|from \\d{4} sqft|~3,700 square feet|\\d{4} sqft|<p>\\d{4}\\+</p>|\\d{3,4} sqft",0);
//				"\\d,\\d+\\-\\d,\\d+\\+ sq ft|\\d{4}-\\d{4} sqft|\\d,\\d+-\\d,\\d+ sq. ft.|\\d{4} sq. ft|\\d,\\d+ sq ft|\\d,\\d+�\\d,\\d+ sq. ft.|\\d+-\\d+ sq. ft.|\\d,\\d+-\\d,\\d+ sq ft|\\d+ sqft|\\d,\\d+\\+ sq ft|\\d+ sqft|<b>Sq. Feet</b></td>\\s*<td>\\d+</td>|<p>\\~\\d,\\d+ square feet</p>", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		//prop type
		commHtml = commHtml.replaceAll("The Village|The Villages|Old Village|Park Village|<h3>Coming Soon</h3>\\s*<ul>\\s*<li>New homes on Providence Ln. W., Closeburn Rd., &amp; Dovewood Dr.</li>", "");
		commHtml = commHtml.replaceAll("\\+Cottage\\+Rd|Cottage Road", "");
		//U.log(commHtml);
		
		//String rmSec=U.getSectionValue(commHtml,"All Communities</h3>","<p><h3>Customer Service</h3>");
		
		
		//derived property type
		//U.log(U.getSectionValue(saleshtml, "<div class=\"column-half\">", "<div class=\"share\">"));
       saleshtml = saleshtml.replaceAll("range|warran|Warran|Range|\\-ranch\\-", "").replace("Stories</b></td><td>3", " 3 story ").replaceAll("Stories\\s*</b>\\s*</td>\\s*<td>", "Stories ");
       
       if(combinedSaleHomeHtmls != null)combinedSaleHomeHtmls = combinedSaleHomeHtmls.replaceAll("Stories</b></td>\\s+<td>(\\d\\.?\\d?)</td", " $1 Story ");
       
       commHtml = commHtml.replaceAll("<b>Stories</b></td>\n\\s*<td>2</td>", " Story 2 ").replace("owner’s bedroom on first floor", "owner’s bedroom on");
      // U.log(saleshtml);
       String dtype=U.getdCommType(saleshtml+commHtml.replace("-ranch-", "") + combinedSaleHomeHtmls);
//       U.log("Match======"+Util.matchAll(commHtml + saleshtml, "owner’s bedroom on first floor",0));
       U.log("DERIVED PT: "+dtype);
      
       commHtml = commHtml.replace("Street (Townhomes)", "").replace("Street (Single Family)", "").replace("coastal luxury", "coastal homes luxury homes")
    		   .replace("COTTAGE 1AW", "COTTAGE SERIES 1AW")
    		   .replace("2 custom infill homes", "2 Custom homes")
    		   .replace("Luxury finishes throughout", "luxuries finishes throughout")
    		   .replace("Study + Loft + Flex space", "Study with Loft + Flex space");
       String pType=U.getPropType((commHtml+saleHTML+saleshtml).replace("coastal luxury", "coastal luxuries").replace("Street (Single Family", "").replace("Street (Townhome", "")
    		   .replaceAll("Kiawah River includes single-family homes and is located|Single-family homes are set amidst water and wild|Cottages at Marvin|Cottages at Springfield|'Cottages|/cottages-|Townhomes for sale in Nexton|Park Townhomes|Street \\(Townhomes|Browse new townhomes|Cottage style homes for sale in Nexton Summerville|cottages-new|Cottages at Oakhurst|award-winning traditional neighborhood|Alley Custom Plan|default single|Bryant Park Townhome|content=\"A custom home|Bryant Park Townhomes|Cottages at Oa|Cottage Road| Cottage Rd|/1302-quincy-cottage| cottage-r|023_-Covered-Patio|Town Custom Homes|iconDot", "").replace("Stories</b></td><td>3", " 3 story "));
  
       U.log("pType: "+pType);
 //      U.log("Match======"+Util.matchAll(commHtml + saleHTML + saleshtml, "[\\s\\w\\W]{30}single-family homes[\\w\\s\\W]{30}",0));

        commHtml = commHtml.replaceAll("Shoals|Cottages at Oakh", "");
        commHtml = commHtml.replace(" crafts and farmhouse styles", " craftsman Homes and Farmhouse styles homes");
  //      U.log("Match======"+Util.matchAll(flowHtml + saleHTML + saleshtml, "[\\s\\w\\W]{30}\\$200,000[\\w\\s\\W]{30}",0));
        note=U.getnote(commHtml);
   
        U.log("<<<<<<<<<<<<<< "+add[0]);
        if(street!=null)
        	street = street.replaceAll("Mon-SatSun", "");
        
        
        if(commUrl.contains("https://www.saussyburbank.com/communities/davidson-hall/"))
        	cType = cType.replace("Coming Soon, Final Opportunity", "Final Opportunity Coming Soon");
        
        
        if(forsale.contains("img/movein-ready-banner.svg") && !cType.contains("Move"))
        	if(cType.length()>3)
        		cType += ", Move-in Ready"; 
        	else
        		cType = "Move-in Ready";
        
        
        if(data.communityUrlExists(commUrl)){
        	i++;
        	LOGGER.AddCommunityUrl("Repeated*************"+commUrl);
        	return;
        }
        
        commHtml = commHtml.replaceAll("Golfing one of the region|Kiawah River is a master-planned community", "");
        
        if(commUrl.contains("https://www.saussyburbank.com/communities/hillside-towns"))minPrice="$720000";
        if(commUrl.contains("https://www.saussyburbank.com/communities/raleigh-inside-beltline-2"))pType="Custom Homes";
        if(commUrl.contains("https://www.saussyburbank.com/communities/kiawah-river")) {
        	
        //	pType+=", Cottage";
        	minSqf="1778";
        	maxSqf="2232";
        	dtype = "2 Story";
        }
        if(commUrl.contains("https://www.saussyburbank.com/communities/highland-park")) {
        	//minPrice="$580000";
        	cType=cType.replace("Move-in Ready,", "");
        }
        
//        if(commName.endsWith("Custom") && !pType.contains("Custom"))
//        	if(pType==ALLOW_BLANK)
//        		pType = "Custom Home";
//        	else
//        		pType+=", Custom Home";
 //       if(commUrl.contains("https://www.saussyburbank.com/communities/kiawah-river"))minPrice="$500,000";
        if(commUrl.contains("https://www.saussyburbank.com/communities/nexton-midtown"))pType+=", Loft";
//        if(commUrl.contains("https://www.saussyburbank.com/communities/nims-village-fort-mill-sc")) {
//        	minPrice=ALLOW_BLANK;
//        	maxPrice=ALLOW_BLANK;
//        }
        
        if(commUrl.contains("https://www.saussyburbank.com/communities/highland-park"))minPrice="$582,575";
//        if(commUrl.contains("https://www.saussyburbank.com/communities/bryant-towns"))minPrice="$518,445";
        
        LOGGER.AddCommunityUrl(commUrl);
		data.addCommunity(commName.replace("–", "-"), commUrl, U.getCommunityType(commHtml.replace("age-restricted community (55+)", "55+ Community").replace("enowned resort", "renowned")));
		data.addAddress(street, city, state.toUpperCase().trim(), zip);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPropertyType(pType,dtype );
		data.addPropertyStatus(cType);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}j++;
//		}catch (Exception e) {}
}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
					
					U.log("Current URL:::" + driver.getCurrentUrl());
					
					try{
						WebElement element =driver.findElement(By.xpath("//*[@id=\"get_homes_for_sale\"]/span"));
						element.click();
						U.log(":::Click Success::::::");
					}catch (Exception e) {
						U.log(":::Click failed::::::"+e);
					}
					Thread.sleep(3000);
					html = driver.getPageSource();
					//Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}
}



