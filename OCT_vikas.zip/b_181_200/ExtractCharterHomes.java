/**
 * @author Parag Humane 
 * @date 24/04/2012
 * 
 */
package com.shatam.b_181_200;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCharterHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	public int inr = 0;
	static int k = 0;
	WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCharterHomes();
		// U.logDebug(true);
		a.process();

		FileUtil.writeAllText(U.getCachePath() + "Charter Homes & Neighborhoods.csv", a.data().printAll());
	}

	public ExtractCharterHomes() throws Exception {
		super("Charter Homes & Neighborhoods", "https://charterhomes.com/");
		LOGGER = new CommunityLogger("Charter Homes & Neighborhoods");
	}

	public void innerProcess() throws Exception {

		// Your code here
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam-50/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		
		 Proxy proxy = new Proxy();
		 proxy.setHttpProxy("138.197.209.229:3128");
		 proxy.setSslProxy("138.197.209.229:3128"); 
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			//driver = new ChromeDriver(capabilities);
		 //capabilities.setCapability("proxy", proxy);
		 driver = new ChromeDriver(capabilities);
		 Thread.sleep(4000);
		 String url, name;

//		String mainComSec = U.getSectionValue(html, "Neighborhoods</a>", "</div>");
//		mainComSec = mainComSec.replace("<h6 class=\"mt-4\"><a", "<h6><a");
////		U.log(mainComSec);
//		String[] mainComUrl = U.getValues(mainComSec, "<h6><a href=\"", "\"");
//		for(String mainUrl : mainComUrl) {
//			
//			U.log("mainUrl::::: "+mainUrl);
//			String mainHtml = U.getHTML("https://charterhomes.com"+mainUrl);
//			mainHtml = mainHtml.replaceAll("<!-- /.product__price -->\n\\s*</div>\n\\s*</div>\n\\s*</div>", "EOF");
//			
//			
// 		String commSec[] = U.getValues(mainHtml, "<div class=\"description-block\">", "<div class=\"regional-nei-images");
//		U.log(commSec.length);
//		for (String item : commSec) {
////			U.log(item);
//			String jsSection=U.getHTML("https://charterhomes.com/assets/json/pin-markers.json");
//			String comSec[]=U.getValues(jsSection, "{", "}");
//			name = U.getSectionValue(item, "'>", "<");
//			url = U.getSectionValue(item, "<a href='", "'>").replace("ions", "");
//			//url = "https://charterhomes.com" + url;
//			for(String sec:comSec) {
//				//U.log(sec.contains(name));
//				if(sec.contains(name)) {
//					
//					item=item+sec;
//					break;
//				}
//			}
//			
////			U.log(item);
////			addDetails(url, name, item);
//		}
//		
//		}
		//Comm from nave bar
		String jsonHtml = U.getHTML("https://charterhomes.com/assets/json/pin-markers.json");
		String[] newComSec =U.getValues(jsonHtml, "{", "}");
		for(String com:newComSec) {
//			U.log("data:::>  "+com);
			String comname = U.getSectionValue(com, "\"name\": \"", "\",");
			String urlVariable = comname.toLowerCase().replace(" ", "-");
			String comUrl = "https://charterhomes.com/"+urlVariable;
			U.log("comUrl:: "+comUrl);
			addDetails(comUrl,comname,com);

		}
		LOGGER.DisposeLogger();
//		driver.close();
		try{
			driver.quit();
		}catch(Exception e){}
	}

	// ==========================================================================

	private void addDetails(String url, String name, String item) throws Exception {
//		 if(k== 5)
//		try{
		{
//			String html = U.getHTML(url);
			//U.log("ppppppp::> "+url);
			//url = url.replace("http:", "https:");
			if (!url.contains("https://charterhomes.com/meeder"))return;
			{
				U.log(k + ":::PAGE :" + url);
//				 U.log(">>>>>>>>>>>>>>>>>>>>"+item);
//				if(url.contains("https://charterhomes.com/arcona"))return;//No data availble
				
				String html = U.getHTML(url);
				
				if(html== null)html=U.getHTMLwithProxy(url);
				String commHtml = html;
				// commName
				String commName = name;
				U.log("Name :" + commName);
				
				String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String lat = ALLOW_BLANK;
				String lng = ALLOW_BLANK;
				String geo = "false";
				String sec = "";
				if (html != null) {

					String addSec = U.getSectionValue(html, "Directions & Hours", "</div>");
					if (addSec != null) {
						sec = U.getSectionValue(addSec, "blank\">", "<");
						if(sec!=null) {
							sec=sec	.replaceAll("Red Lion PA", "Red Lion,PA")
									.replace("201 Market House Circle Cranberry Township", "201 Market House Circle, Cranberry Township")
								.replace("Road Cranberry Township", "Road, Cranberry Township")
								.replaceAll("Run Mechanicsburg", "Run, Mechanicsburg").replace(" Bridgeville", ", Bridgeville")
								.replaceAll("Valmere Path York", "Valmere Path, York").replace("Mechanicsburg", ", Mechanicsburg");
					
						String[] add1 = U.formatAddress(sec).replace(", ,", ",").split(",");
						U.log("formatAddress==="+U.formatAddress(sec));
						U.log(Arrays.toString(add));
						
						add[0] = add1[0];
						add[1] = U.getSectionValue(item, "data-City=\"", "\"");
						//add[0] = add1[0].replaceAll(add[1], "").replaceAll("Cranberry Township", "");
						U.log(add[0]);
						
						if (add1.length > 2) {
							add[2] = Util.match(add1[2], "\\w+");
							add[3] = Util.match(add1[2], "\\d+");
						} else {
							add[2] = Util.match(add1[1], "\\w+");
							add[3] = Util.match(add1[1], "\\d+");
						}
						if(add[1]==null)add[1] =U.getCityFromZip(add[3]);
					}
					}
					U.log(Arrays.toString(add));
					lat = U.getSectionValue(html, "data-lat=\"", "\"");
					lng = U.getSectionValue(html, "data-lng=\"", "\"");

				}
				if(lat==null) {
					String latSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/search/", "?sa=");
					U.log(latSec);
					if(latSec!=null) {
					String latLng[] = latSec.split(",+");
					lat = latLng[0];
					lng = latLng[1].replace("+", "");
					}
				}
				if(lat==null) {
					String latSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");
					U.log(latSec);
					if(latSec!=null) {
						latSec=latSec.replaceAll(",\\d{2}z/", "/");
						U.log("latSec=="+latSec);
						latSec = U.getSectionValue(html, "/@", "/");
						String latLng[] = latSec.split(",");
						lat = latLng[0];
						lng = latLng[1].replace("+", "");
					}
				}
				U.log("Street::" + add[0] + " City::" + add[1] + " State::" + add[2] + " Zip::" + add[3]);
				U.log("lat::" + lat + " lng::" + lng);
				if(url.contains("https://charterhomes.com/florin-hill")) {
					add=U.getAddressGoogleApi(new String[] {lat,lng});
					if(add == null)add =U.getGoogleAddressWithKey(new String[] {lat,lng});
					geo="True";
				}
				if(add[0] != null && add[1] != null) add[0] = add[0].trim().replaceAll(add[1].trim()+"$", "");
				
				if(add[0].length()<3) {
					U.log("--"+item);
					if (item.contains("<i class=\"fas fa-map-marker-alt\"></i>")) {
						String addSec=U.getSectionValue(item, "<i class=\"fas fa-map-marker-alt\"></i> ", "</a>");
						add=U.getAddress(addSec.replace(" Mechanicsburg", ", Mechanicsburg").replace("Way Mechanicsburg", "Way, Mechanicsburg").replace("Court Lancaster", "Court, Lancaster").replace("Run Mechanicsburg", "Run, Mechanicsburg").replace("Rd Hummelstown", "Rd, Hummelstown").replace("Place Lancaster", "Place, Lancaster").replace(",,", ","));
						if(lat==null) {
							lat=U.getSectionValue(item, "\"lat\":", ",").trim();
							lng=U.getSectionValue(item, "\"lng\": ", ",").trim();
							U.log("lat::" + lat + " lng::" + lng);
						}
					}
					if(add[0].length()<3) {	
						add[0]=U.getSectionValue(item, "\"address1\": \"", "\"");
	//					add[3]=Util.match(U.getSectionValue(item, "\"Address2\":\"", "\""), "\\d+");
						add[1]=U.getSectionValue(item, "\"address2\": \"", ",");
						add[2]=U.getSectionValue(item, add[1]+",", "\"").trim();
						if(lat==null) {
							lat=U.getSectionValue(item, "\"lat\":", ",").trim();
							lng=U.getSectionValue(item, "\"lng\": ", ",").trim();
							U.log("lat::" + lat + " lng::" + lng);
						}
						String add1[] = U.getAddressGoogleApi(new String[] {lat,lng});
						if(add1 == null)add1 = U.getGoogleAddressWithKey(new String[] {lat,lng});
						add[3]=add1[3];
						geo="True";	
					}
					U.log("|Street::" + add[0] + " City::" + add[1] + " State::" + add[2] + " Zip::" + add[3]);

				}
				
				if ((add[0] == null || add[3] == null || add[0].length() < 4) && lat != null) {
					String LL[] = { lat, lng };
					add = U.getAddressGoogleApi(LL);
					if(add == null)add =U.getGoogleAddressWithKey(LL);
					geo = "True";
				}
				if (add[1] != null && lat == null) {
					String LL[] = { lat, lng };
					LL = U.getlatlongGoogleApi(add);
					if(LL == null) LL = U.getGoogleLatLngWithKey(add);
					lat = LL[0];
					lng = LL[1];
					geo = "True";
				}
				
				// Square Feet
				String HomeHtml = "";
				String combinedHomeHtml = "";
				String[] homeSEC = U.getValues(html, "<li class=\"viewItemDetails", "</a>");
				for (String string : homeSEC) {
					try {
					String HomeID = U.getSectionValue(string, "data-id=\"", "\"");
					
					String homeUrl = "https://charterhomes.com/Umbraco/Api/CharterHomes/GetHomeSearchDetails/?type=PLAN&id="+ HomeID;
					String homeHtml = U.getHTML(homeUrl);
					if(homeHtml != null && homeHtml.contains("An error has occurred.")) homeHtml = null;
					if(homeHtml != null)
						U.log(homeUrl);
					else{
						homeUrl = "https://charterhomes.com/Umbraco/Api/CharterHomes/GetHomeSearchDetails/?type=RNH&id="+ HomeID;
						homeHtml = U.getHTML(homeUrl);
//						U.log(homeUrl);
					}
					combinedHomeHtml += homeHtml;
					homeHtml = null;
					}
					catch(Exception e) {}
					
/*					HomeHtml = HomeHtml + U.getHtml(
							"https://charterhomes.com/Umbraco/Api/CharterHomes/GetHomeSearchDetails/?type=PLAN&id="
									+ HomeID,
							driver)
							+ U.getHtml(
									"https://charterhomes.com/Umbraco/Api/CharterHomes/GetHomeSearchDetails/?type=RNH&id="+ HomeID,
									driver);
*/
				}

				if(url.contains("https://charterhomes.com/walden")) item = item.replaceAll("footage\": \"\\d,\\d+ - \\d,\\d+ Square Feet", ""); //sqft is not visible on page
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//				 U.log(Util.match(combinedHomeHtml, ".*(1000|1,000).*"));
				html = html.replace("footerAnchor", "");
				combinedHomeHtml = combinedHomeHtml.replace("\\\":", " ").replaceAll("full 1,000 sq ft unfinished basement", "");
				//U.writeMyText(html + combinedHomeHtml+item);
				if(url.contains(".com/arcona")) {
					item=item.replaceAll(" \"footage\": \"2,059 - 2,730 Square Feet\"", "");
				}
				
				String[] sqft = U.getSqareFeet((html + combinedHomeHtml+item).replaceAll("footage\": \"1,810 - 5,002 Square Feet", ""),
						"\"footage\": \"\\d,\\d{3} - \\d,\\d{3}\",| \"footage\": \"\\d,\\d{3} - \\d,\\d{3} Square Feet\",|\\d{1},\\d{3} - \\d{1},\\d{3}  Square Feet|SquareFootage \\d{4}|\\d{1},\\d{3} Square Feet|\\d{1},\\d{3} sq. ft. - \\d{1},\\d{3} sq. ft.|\\d{1},\\d{3} sq ft|from \\d{1},\\d{3} sq. ft.|SquareFootage\"\\:\\d+",
						0);
				
//				U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(item, "[\\w\\s\\W]{30}2,059[\\w\\s\\W]{30}", 0));

				
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

				// Price
				html = html.replace("inamerica.jpg?v=636108271520000000\"", "");
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				html = html.replace("0s", "0,000");
				String[] price = U.getPrices(html+item,
						"Starting at: \\$\\d+,\\d+|Starting from the low \\$\\d+,\\d+|Priced at: \\$(\\d,)?\\d{3},\\d{3}|Starting at \\$\\d+,\\d+|Priced at \\$\\d+,\\d+|From \\$\\d{3},\\d{3}",
						0);

				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
				html = html.replace("/locations/single-family-homes/", "");
				String allPlanData = ALLOW_BLANK;

				String[] fplans = U.getValues(html, "<a class=\"image-box\" href=\"", "\"");
				U.log("total plan : " + fplans.length);
				for (String plan : fplans) {
					U.log("plan : " + plan);
					String planHtml = U.getHTML("http://www.charterhomes.com" + plan);
					allPlanData += U.getSectionValue(planHtml, "<div class=\"homeName\">", "Get Driving Directions");

				}
				allPlanData = allPlanData.replace("/locations/single-family-homes/", "");

				// ---------Property Type------------
				html = html.replace("Mediterranean Villa", "Mediterranean Villas");
				html = html.replaceAll("[t|T]*ownhome\"|text\">Townhome</span>", "");

				// U.log(html);
				html = html.replace("Village Experience", "");
				html = html.replaceAll("convenience and luxury|Luxury Maintenance ", "convenience and luxury homes");
				String propertyType = ALLOW_BLANK;

				String[] protype = U.getValues(html, "data-hometype=\"", "\"");
/*				String pdata = "";
				for (String string : protype) {
					pdata += string.replace("Single Home", "Single Family Homes");
				}*/
//				U.log(combinedHomeHtml+":::::::::::::::homehtml");
				html = html.replace("modern luxury", "modern luxury homes").replaceAll("traditional-nhf", "");
				if(combinedHomeHtml.length()<2) {
					html = html.replaceAll("TOWNHOME|data-name=\"TOWNHOME\"|<span class=\"text\">FIRST FLOOR|data-name=\"FIRST FLOOR|FIRST FLOOR LIVING", "");
					combinedHomeHtml = combinedHomeHtml.replaceAll("<span class=\"text\">TOWNHOME|data-name=\"TOWNHOME\"|data-name=\"FIRST FLOOR|<span class=\"text\">FIRST FLOOR|FIRST FLOOR LIVING", "");
					allPlanData = allPlanData.replaceAll("<span class=\"text\">TOWNHOME|data-name=\"TOWNHOME\"|data-name=\"FIRST FLOOR|<span class=\"text\">FIRST FLOOR|FIRST FLOOR LIVING", "");
				}
				
				html=U.removeSectionValue(html, "<footer class=\"footer\">", "</footer>");
				propertyType = U.getPropType((html + combinedHomeHtml+allPlanData).replaceAll("-path-townhome|text\">TOWNHOME|data-name=\"TOWNHOME|Traditional Elevation|District offering single-family homes|flexible single-family floorplans|content=\"(.*?)\"|-traditional-|<span class=\"text\">Single-Family</span>|field-single-family|traditional-nhf|Traditional Elevation|Traditional Owner's bathroom", ""));
				
//				U.log("MMMMMMMMMMMMMMMMMMM "+Util.matchAll(html + combinedHomeHtml+allPlanData, "[\\w\\s\\W]{30}Apartment[\\w\\s\\W]{30}", 0));
				
				if(propertyType.contains("Townhouse") && propertyType.contains("Townhome")){
					propertyType = propertyType.replace("Townhouse,", "").replace(", Townhouse", "");
				}
				if (url.contains("https://charterhomes.com//towns-at-meridian/")) {
					propertyType = propertyType + ",Loft";
				}

				U.log("Type:" + propertyType);
				// U.log(html);
				// Homesites Available
				String propertyStatus = ALLOW_BLANK;
				String statSec = html;
				String remove = "selling in 3 nearby Mechanicsburg|neighborhood coming Spring 2019.</p>|Brewing Now Open|e spacious new home designs are ready for move-in |Homes Coming Soon|Park Now Open|is now open|just released|Grand Opening Promotions|UNTIL COMMUNITY CLOSEOUT";
				statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
				String st = U.getSectionValue(html, "communityDescription", "amenityWrapper");
				if (st != null)
					st = st.replace("e spacious new home designs are ready for move-in ", "")
							.replaceAll("Move In|move in", "");
				statSec = statSec.replaceAll("Move In|move in", "");
				// U.log(st);
				
				String regSec = ALLOW_BLANK;

				if (regSec != null) {
					regSec = regSec.replace("your last chance to build", "LAST CHANCE");
				}
				// if(regSec!=null && regSec.contains("<h4>Ready Now Homes</h4>"))
				// st=st+" Ready Now Homes ";
//				
//				U.log(statSec + st + regSec);
				propertyStatus = U.getPropStatus((statSec + st + regSec).replace("currently selling in our nearby Woodbridge", "").replaceAll("store now open|don't wait, only \\d move-in|selling in our", ""));

				if (url.contains("http://www.charterhomes.com/locations/woodside")) {
					sec = U.getSectionValue(html, "Visit The Neighborhood Home Store", "</div>");
					if (sec != null) {
						add[0] = U.getSectionValue(sec, "<span class=\"addressStreet\">", "</span>");
						add[1] = U.getSectionValue(sec, "<span class=\"addressCity\">", "</span>");
						add[2] = U.getSectionValue(sec, "<span class=\"addressState\">", "</span>");
						add[3] = U.getSectionValue(sec, "<span class=\"addressZipCode\">", "</span>");

						lat = U.getSectionValue(sec, "Latitude:</span>", "</span>").trim();
						lng = U.getSectionValue(sec, "Longitude:</span>", "</span>").trim();
					}
				}
				if(url.contains("https://charterhomes.com/sinclair-park/"))propertyType =propertyType+", Single Family";
				if (url.contains("http://www.charterhomes.com/locations/calvert-hill")) {
					propertyStatus = "Coming Soon";
					propertyType = propertyType.replace("Townhomes", "");
				}
				if(url.contains("/woodbridge"))propertyType=propertyType.replace(", Townhome", "");
				if (propertyType.length() == 0) {
					propertyType = ALLOW_BLANK;
				}

				if (!propertyStatus.contains("Ready Now")) {
					if (html.contains("data-type=\"RNH\"")) {
						if (propertyStatus.length() < 4 || propertyStatus == ALLOW_BLANK) {
							propertyStatus = " Ready Now Homes ";
						} else {
							propertyStatus = propertyStatus + ", Ready Now Homes ";
						}
					}
				}

//				html = html.replace("data-masterbedroom=\"Down\">", " 1 Story ").replaceAll("first-floor", " 1 Story ");
				
				html= html.replaceAll("data-name=\"FIRST FLOOR LIVING|<span class=\"text\">FIRST FLOOR LIVING</span>", "")
						.replace("first-floor ", "1 story").replace("first-floor living", "story 1 ");
				
				String dpropType = U.getdCommType(((html + allPlanData)+combinedHomeHtml.replace("first-floor living", "story 1 ")).replaceAll("second floor features|include a finished second floor|The second floor has a versatile upper gallery ", "2 story").replaceAll("floor|Floor", ""));
				
//				U.log("MMMMMMMMMMM "+Util.matchAll(html + allPlanData+combinedHomeHtml, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));
				if (url.contains("/chanticleer/"))dpropType ="1 Story";
				add[1] = add[1].replace(",", "");
				add[2] = add[2].replace(",", "");

				if(data.communityUrlExists(url))
				{
					LOGGER.AddCommunityUrl("========= Repeated =========: "+url);
					return;
					
				}
				propertyStatus=propertyStatus.replace("Ready Now Homes", "Move In Ready Homes");
				propertyStatus=propertyStatus.replace("Move-in-ready, Move In Ready Homes", "Move In Ready Homes");

				String counting=ALLOW_BLANK;
				String startDt=ALLOW_BLANK;
				String endDt=ALLOW_BLANK;
				
				LOGGER.AddCommunityUrl(url);
				add[0]= add[0].replace("1801 Driftstone Dr Harrisburg", "1801 Driftstone Dr");
				data.addCommunity(commName, url, U.getCommunityType(html.replace("Country Club Drive", "")));
				data.addAddress(add[0], add[1].replace("cranberry twp", "Cranberry Township"), add[2], add[3]);
				data.addSquareFeet(minSqf, maxSqf);
				data.addPrice(minPrice, maxPrice);
				data.addLatitudeLongitude(lat, lng, geo);
				data.addPropertyType(propertyType, dpropType);
				data.addPropertyStatus(propertyStatus);
				data.addNotes(ALLOW_BLANK);
				data.addUnitCount(counting);
				data.addConstructionInformation(startDt, endDt);
			}
		}
		k++;
		
//		}catch (Exception e) {}
	}

	private String getDataFromReg(String name, String item) throws IOException {
		// TODO Auto-generated method stub
		if(name.contains("Florin Hill"))return null;
		String reg = U.getSectionValue(item, "data-City=\"", "\"");
		if (reg.contains("Mechanicsburg") || reg.contains("Lancaster")) {
			U.log("https://charterhomes.com/" + U.getSectionValue(item, "data-City=\"", "\""));
			String regHtml = U
					.getHTMLwithProxy("https://charterhomes.com/" + U.getSectionValue(item, "data-City=\"", "\""));
			
			String[] sec = {};
			if( !reg.contains("Lancaster"))
				sec=U.getValues(regHtml, "<div class=\"description-block\">","<div class=\"section-regional-nei\">");
			if(sec == null) {
				sec=U.getValues(regHtml, "  <div class=\"description-block\">", "<footer class=\"footer\">");
			}
			for (String s : sec) {
				if (s.contains(name))
					return s;
			}
		}
		return null;
	}
}
