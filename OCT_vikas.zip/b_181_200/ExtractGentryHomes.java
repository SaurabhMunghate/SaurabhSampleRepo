/** @author Sanket Patil
 *  @date 9/04/2012 
 */

package com.shatam.b_181_200;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractGentryHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	CommunityLogger LOGGER;
	public static void main(String ar[]) throws Exception {

		AbstractScrapper a = new ExtractGentryHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Gentry Homes.csv", a.data().printAll());
	}

	public ExtractGentryHomes() throws Exception {

		super("Gentry Homes", "https://www.gentryhawaii.com/");
		LOGGER = new CommunityLogger("Gentry Homes");
	}

	public void innerProcess() throws Exception {
		int comm = 0;
		String html = U.getHTML("https://www.gentryhawaii.com/new-homes");
		String infoSection = U.getSectionValue(html, "<div class=\"et_pb_title_container\">", "<footer id=\"main-footer\">");
//		U.log(infoSection);
		String[] communitiesInfo = U.getValues(infoSection, "<div class=\"et_pb_promo_description\">", "/a>");
		U.log(communitiesInfo.length);


		for (String communityInfo : communitiesInfo) {
			{
//				U.log(communityInfo);
				
				String communityUrl = "https://www.gentryhawaii.com"+U.getSectionValue(communityInfo, "href=\"","\"");
//				try {
					addDetails(communityUrl, communityInfo);
//				} catch (Exception e) {}
				
			}
		}
		
//		addDetails("https://www.gentryhawaii.com/makamae/", "");
		
		LOGGER.DisposeLogger();
	}
	
	private void addDetails(String communityUrl, String communityInfo) throws Exception{
		
		if(communityUrl.contains("https://www.gentryhawaii.comhttps://www.gentryhawaii.com"))
			communityUrl = communityUrl.replace("https://www.gentryhawaii.comhttps://www.gentryhawaii.com", "https://www.gentryhawaii.com");
		
//		if (!communityUrl.contains("https://www.gentryhawaii.com/makamae")) return;
		
		if(data.communityUrlExists(communityUrl)) {
			LOGGER.AddCommunityUrl("Repeat==== "+ communityUrl);
			return;
		}
		LOGGER.AddCommunityUrl(communityUrl);
		
		U.log("--=-=-=-=-=-=-=-=-=-="+"\nurl::"+communityUrl);
		
			

		String html1 = U.getHTML(communityUrl);
		
		String communityName = U.getSectionValue(communityInfo, "<h2>","</h2>");
		if(communityName == null) communityName = U.getSectionValue(html1, "<h1 class=\"entry-title\">","</h1>");
		
		if(communityName!=null)
			communityName = communityName.replaceAll(" &#8211; Sold Out", "").replace("KEALI‘I", "Keali'i").trim();
		U.log(communityName);

//		String address = ALLOW_BLANK, geo = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK, lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		//-=-=-=-=-=-----Address
		String geo ="FALSE";
		String addressSec=U.getSectionValue(html1, "Sales Office</h3>", "</p>");
		U.log("addressSec:: "+addressSec);
		
		if(addressSec!=null)
			addressSec = addressSec.replace("<p>", "").replaceAll("<br />|<br/>", ",").replace(" St., Unit 113", " St. Unit 113").replace("Unit 19,", "Unit 19")
			.replace(", (Lot 31)", "");
		
		if(communityUrl.contains("https://www.gentryhawaii.com/coral-ridge"))
			addressSec = "733 Bishop Street Suite 1400,Honolulu, HI 96813";
		
		if(communityUrl.contains("https://www.gentryhawaii.com/kealii"))
			addressSec = "91-5408 Kapolei Parkway Unit 19,Kapolei, HI 96707";
			
		U.log("--- "+addressSec);
		if(addressSec==null)
			addressSec = "";
		String add[]=U.getAddress(addressSec);
		U.log(Arrays.toString(add));
		String latlonSec=Util.match(html1, "/@\\d{2}.\\d+,-\\d{2,3}.\\d+");
		
		if(latlonSec==null)
			latlonSec = "";
		
		String latlon[]=latlonSec.replace("/@", "").split(",");
		
		U.log(Arrays.toString(latlon));
		
		
		if(latlon[0] ==null || latlon[0].length()<3) {
			
			latlon = U.getlatlongGoogleApi(add);
			if(latlon == null) latlon = U.getlatlongHereApi(add);
			geo = "TRUE";
		}
			
		
		//=========Prices=========
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		html1=html1.replace("Starting at $1M", "Starting at $1,000,000");
//		U.log("MMMMMMM "+Util.matchAll(html1, "[\\s\\w\\W]{30}Starting at[\\s\\w\\W]{300}", 0));

		String[] price = U
				.getPrices(
						html1,
						"Starting at \\$\\d,\\d{3},\\d{3}|From High \\$\\d{3},\\d{3}|<h3>Mid \\$\\d{3},\\d{3}|>From Mid \\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		html1=html1.replace("<td>Total Net Living Area*</td>\r\n" + 
				"<td style=\"text-align: right;\">", "<td>Total Net Living Area*</td><td style=\"text-align: right;\">");
		
		String[] sqft = U.getSqareFeet(html1+communityInfo,
				"</td><td style=\"text-align: right;\">\\d,\\d{3} sq. ft.|Total Living Area\\*</td>\\s+<td style=\"text-align: right;\">\\d,\\d{3} sq. ft.|<td>Total Net Living Area\\*</td>\n\\s*<td style=\"text-align: right;\">\\d,\\d{3} sq. ft.</td>|<td>Total Living Area</td>\\s+<td style=\"text-align: right;\">\\d,\\d{3} sq. ft.</td>", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		//=========Community Type=====/
		String communityType=U.getCommType(html1);
		
//		U.log("=== "+Util.matchAll(html1.replaceAll("_Courtyard_|_Courtyard|Courtyard\"", ""), "[\\s\\w\\W]{30}Courtyard[\\s\\w\\W]{30}", 0));
		
		//=========Property Type=====
		//html1 = html1.replace("Common area front yard", "common area");
		String propType=U.getPropType(html1.replaceAll("_Patio-|Patio\\.jpg|Patio\"|Common area front yard|Common area landscaping|Patio\"|_Patio.jpg\"", "").replaceAll("_Courtyard_|_Courtyard|Courtyard\"", ""));
		//=========Derived Community Type=====
		//U.log(html1.contains("First Floor"));
		html1=html1.replaceAll("<td>First Floor</td>|plank on first floor</div>", "").replace("Second Floor", " 2 Story ");
		String dType=U.getdCommType(html1);
		//=========Property Status=====
		
		if(!communityName.contains("Coral Ridge"))
			html1 = html1.replaceAll("\\(Sold Out\\)</a>|Sold Out</a></li>", "");
		
		String pStatus=U.getPropStatus(html1);
		//=========Note=====
		String note=U.getnote(html1);
						
		add[0] = add[0].replaceAll(",", "");
		//if(communityUrl.contains("https://www.gentryhawaii.com/seabridge")) propType = propType.replace(", Common Area", "");
//		if(!communityType.contains("Golf Course"))
//		if(communityType==ALLOW_BLANK)
//			communityType = "Golf Course";
//		else
//			communityType+=", Golf Course";
//        if(communityUrl.contains("https://www.gentryhawaii.com/northpark"))propType="Loft";
        
     // ------------------ No. of units ------------------------
     String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addCommunity(communityName.toLowerCase(), communityUrl, communityType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latlon[0].trim(), latlon[1].trim(), geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		
		i++;
		inr++;
	}
	
}