package com.shatam.b_181_200;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.collect.ObjectArrays;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractJeffBentonHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	static int j=0;
	String[] both={};
	 WebDriver driver = null;
	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractJeffBentonHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Jeff Benton Homes.csv", a.data()
				.printAll());
	}
	
	public ExtractJeffBentonHomes() throws Exception {

		super("Jeff Benton Homes", "http://www.jeffbentonhomes.com/");
		LOGGER=new CommunityLogger("Jeff Benton Homes");

	}

	public void innerProcess() throws Exception {
		// http://www.jeffbentonhomes.com/communities
		U.setUpChromePath();
		driver = new ChromeDriver();
			String url = "http://www.jeffbentonhomes.com/communities";
			String base = "http://www.jeffbentonhomes.com";
			String html = U.getHtml(url, driver);

		String[] sections = U.getValues(html, "<h4><a ng-href=", "Visit Community");
		//U.log(sections[0]);
		int totalComm = sections.length / 2;
		for (String sec : sections) {
			url = U.getSectionValue(sec, "\"", "\"");
			url = url.replace("\\", "").replace("\"", "");
			//U.log(url.trim());
			if (url != null) {

				addInfo(base + url, sec);

			}

		}

		if (driver != null) {
			driver.close();
		}

		LOGGER.DisposeLogger();
	}

	private void addInfo(String url, String commInfo) throws Exception {
		//if(j==0)
//		try{
		if (!url.contains("/sage-creek"));
		{
//			if (!url.contains("http://www.jeffbentonhomes.com/sage-creek"))return;
			
			U.log("Count :"+j);
		U.log("\nPAGE :" + url);
		
			//return;*/
		
		
		if (driver == null) {
			driver = new FirefoxDriver();
		}

		String html = U.getHtml(url, driver);
		
		String comName = U.getSectionValue(html, "<title>", "|").trim();
		U.log("comName : "+comName);

		// LatLng
		String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };

		String htmlDir = U.getHtml(url + "-directions", driver);
		U.log(U.getCache(url + "-directions"));
		U.log("Directions: " + url + "-directions");

		String latLngSection = U.getSectionValue(htmlDir,"maps.google.com/?q=", "&amp;");
		U.log(latLngSection);
		latLng[0] = Util.match(latLngSection, "\\d{2}\\.\\d{4,}");
		latLng[1] = Util.match(latLngSection, "-\\d{2}\\.\\d{4,}");

		String lat = latLng[0] == null ? ALLOW_BLANK : latLng[0];
		String lng = latLng[1] == null ? ALLOW_BLANK : latLng[1];
		U.log("Lat:" + lat + " Long:" + lng);

		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		String geo = "FALSE";
		String addresSec = U.getSectionValue(html,
				"Address:<span class=\"ng-binding\">", "</h3>");
		addresSec = addresSec.replace("<span class=\"ng-binding\">", ",");
		addresSec=addresSec.replace("</span>,", ",");
		addresSec=addresSec.replace("Coming Soon,", "");
		U.log(addresSec);
		String[] addrs =addresSec.split(",");
		if(addrs.length>2)
		{
			add[0]=addrs[0];
			add[1]=addrs[1];
			add[2]=Util.match(addrs[2],"\\w{2}");
			add[3]=Util.match(addrs[2],"\\d{5}");
		}
		if(addrs.length==2){     //no street name 
			add[1]=addrs[0];
			add[2]=Util.match(addrs[1],"\\w{2}");
			add[3]=Util.match(addrs[1],"\\d{5}");
			
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			lat=latLng[0];
			lng=latLng[1];
			geo="True";
		}
		
		if(url.contains("http://www.jeffbentonhomes.com/coventry-at-mcmullen-cove"))
			add[1]= "Gurley";
		U.log(add[0]+"===="+lat+"===="+lng);
		if (lat != ALLOW_BLANK && add[0] == ALLOW_BLANK) {
			add = U.getAddressGoogleApi(new String[] { lat, lng });
			if(add == null) add = U.getAddressHereApi(new String[] { lat, lng });
			geo = "TRUE";
		}

		U.log("street:" + add[0].trim() + " City:" + add[1].trim() + " ST:"
				+ add[2] + " Z:" + add[3]);

		String sec = U.getSectionValue(html,"<ul class=\"comm_header_nav_bar\"", "</ul>");
	

		String commDescriptions = U.getSectionValue(html,	"class=\"homes-tab\"", "</nav>");
		String floHtml = ALLOW_BLANK;

		String links[] = U.getValues(commDescriptions, "<a ng-href=\"", "\"");
		String allDataHtml = ALLOW_BLANK;
		String floorPlanLink = ALLOW_BLANK;
		String availableHomesLink = ALLOW_BLANK;
		for (String link : links) {
			//U.log("link11 : "+link);
			link = "http://www.jeffbentonhomes.com" + link;
			if (link.contains("-floorplans") || link.contains("-homes")) {
				U.log("Link::  " + link);
			if (link.contains("-floorplans"))
			{
				floorPlanLink = link;
				System.out.println("floor plan link is::::"+floorPlanLink);
			}
				
			//System.out.println("floor plan link is::::"+floorPlan);
			if (link.contains("-homes"))
			{
			availableHomesLink = link;
			System.out.println("homes plan link is::::"+availableHomesLink);
			}
			
			allDataHtml += U.getHtml(link, driver);
			//	System.out.println("Avaailable homes:::"+availableHomes);
				
			}

		}
//		U.log("allDataHtml=="+allDataHtml);
		String homesHtml = getStoryHtml(allDataHtml, driver);
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		html = html.replace("0's", "0,000MyPrice");
		// FileUtil.writeAllText("D:\\sample.txt", html);
		//U.log(allDataHtml);
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sqft = U.getSqareFeet(allDataHtml+html+floHtml+homesHtml,
				"\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|\\d{1},\\d{3} - \\d{1},\\d{3} Sq\\. Ft\\.|square footage from \\d{4} - \\d{4}|class=\"ng-binding ng-scope\">\\d{1},\\d{3} SQ. FT.</li>", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

//		U.log(">>>>>>>>>>>>"+Util.matchAll(homesHtml, "[\\s\\w\\W]{30}3,750[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(allDataHtml+html+floHtml+homesHtml, "[\\s\\w\\W]{30}3,659[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(floHtml, "[\\s\\w\\W]{30}3,659[\\s\\w\\W]{30}", 0));
		String commStatus = ALLOW_BLANK;
		String statSec = html;

		
		
		//U.log(homesHtml);
		html = html+homesHtml;
		html = html.replaceAll("href=\"/hoa\"|>HOA</a>", "");
	
	
		String[] price = U
				.getPrices(
						html+ allDataHtml+homesHtml+both,
						"\\$\\d{3},\\d{3}MyPrice|class=\"ng-binding ng-scope\">\\$\\d{3},\\d{3}</li>|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}</li>",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);


		//U.log("StatSec========="+statSec);
		statSec = statSec.replaceAll("New Phase Now Open|\"ng-binding\">Coming Soon", "")
				.replaceAll("Current Phase's are SOLD OUT", "Current Phases SOLD OUT");
		html  = html.replace("Opening Spring of 2020", "Opening Spring 2020").replace("Opening Fall of 2020", "Opening Fall 2020")
				.replace("Opening Summer of 2020", "Opening Summer 2020");
		//statSec = statSec.replace("ONLY 7 HOMESITES LEFT IN PHASE 7", "ONLY 7 HOMESITES LEFT IN PHASE 7");
		
		commStatus = U.getPropStatus(statSec+html);
		
		
//		U.log("MMMMMMMMMMM::"+Util.match(statSec+html, ".*?Opening Spring 2020.*?"));
		if(add[0].trim().length()<4)
		{
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "TRUE";
			
		}
		
		commStatus=commStatus.replace("3 Homesites Left","Only 3 Homesites Left In Current Phase ");
		commStatus=commStatus.replace("1 Home Left","Only One Home Left");		
		
		String pType = U.getPropType(both+homesHtml+html);
		
		String dType = U.getdCommType(homesHtml.replaceAll("2 Story", " 2 Story ")+html+floHtml);
		
		U.log(">>>>>>>>>>>>"+Util.matchAll(homesHtml, "[\\s\\w\\W]{30}2 Story[\\s\\w\\W]{30}", 0));
		U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}2 Story[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(floHtml, "[\\s\\w\\W]{30}2 Story[\\s\\w\\W]{30}", 0));

		U.log("Propety type:::::"+pType);
		U.log("Propety Status:::::"+commStatus);
		U.log("Derived type:::::"+dType);
		U.log("Minim Price:::::"+minPrice);
		U.log("Maxim Status:::::"+maxPrice);
		if(data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+"::::::::::::::::::::::::::::Repeated::::::::::::::::::::::::::::::::::");
			return;
		}
		LOGGER.AddCommunityUrl(url);
		data.addCommunity(comName, url, U.getCommunityType(html));
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),
				add[3].trim());
		data.addLatitudeLongitude(lat, lng, geo);
		
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(commStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);	
		}
		j++;
//		}catch(Exception e) {}
	}

	private String getStoryHtml(String html, WebDriver driver) throws Exception {

		
	//	System.out.println("Watch out for floor html"+url);
		String combineHtml = ALLOW_BLANK,combineOne=ALLOW_BLANK,combineTwo = ALLOW_BLANK;
		
		//String html = U.getHTML(url);
		String pathString =U.getCache("http://www.jeffbentonhomes.com/kingsley-at-crown-pointe-floorplans");
		//System.out.println("path of index 1 is:"+pathString);
		String homeLinks[] = U
				.getValues(html, "\" class=\"btn\" href=\"", "\"");
		U.log("homeLinks:::::::::::::"+Arrays.toString(homeLinks));
		for (String link : homeLinks) {
			if(link.contains("/pine-brook-the-greystone-ii-non-luxe")) continue;
			if(link.contains("sage-creek-the-greystone-ii-non-luxe"))continue;
			link = "http://www.jeffbentonhomes.com" + link;
//			
			System.out.println("__________________-"+link);
			
			//U.log("Getting the link here:  " + link);
			
			String planHtml= U.getHtml(link, driver);
			
			if(planHtml.contains("Home Description"))
			{
				U.log("KKKKKKKKKKKKKKKKKKKK");
				combineOne += U.getSectionValue(planHtml, "Home Description", "Community Schools");//for homes
			}
			else{
				combineTwo += U.getSectionValue(planHtml, "<h3 class=\"ng-binding\">", "Back to Floor Plans");//for floor plans
			}
		
		}
		combineHtml = combineOne+combineTwo;
		U.log("%%%%%%%%%%%%%%%%%%%%%"+combineHtml);
		return combineHtml;

	}

}
