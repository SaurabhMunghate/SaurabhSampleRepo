/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_181_200;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URL;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import java.util.Arrays;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractJordanFosterConstruction extends AbstractScrapper{

	static int j=0;
	
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	public ExtractJordanFosterConstruction()
			throws Exception {
		super("Jordan Foster Construction","https://www.jordanfosterconstruction.com/");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Jordan Foster Construction");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractJordanFosterConstruction();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Jordan Foster Construction.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam12/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
		
		 Proxy proxy = new Proxy();
//		 proxy.setHttpProxy("45.145.150.50:3128");
//		 proxy.setSslProxy("138.197.209.229:3128"); 
		 proxy.setHttpProxy("12.218.209.130:53281");
		 proxy.setSslProxy("20.116.130.70:3128");
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//			driver = new ChromeDriver(capabilities);
		 capabilities.setCapability("proxy", proxy);
		 driver = new ChromeDriver(capabilities);
		Thread.sleep(10000);

//		String mainHtml=U.getHtml("https://jordanfosterconstruction.com/commercial/",driver);
////		String sec=U.getSectionValue(mainHtml,"<div class=\"et_pb_module et_pb_image","</a></p></div></div>");
//		String[] comSec=U.getValues(mainHtml,"<div class=\"et_pb_module et_pb_image","</a></p></div></div>");
//		U.log("totalCommunity-->"+comSec.length);
//		for(String com:comSec)
//		{
//			String comUrl=U.getSectionValue(com, "href=\"","\"");
//		
//			U.log("commUrl-->"+comUrl);
//			addDetail(comUrl,com);
//		}
//		String html = U.getHtml("https://jordanfosterconstruction.com/multifamily/",driver);
//		String [] comSections = U.getValues(html, "<div class=\"et_pb_module et_pb_image","</a></p></div></div>");
//		U.log(comSections.length);
//		for(String com :comSections){
//			String comUrl = U.getSectionValue(com, "href=\"", "\"");
//			U.log(comUrl);
//	     	addDetail(comUrl, com);
//		}
	///	String mainHtml=U.getHtml("https://jordanfosterconstruction.com/building-group-commercial-construction/",driver);
		String mainHtml=getMyHtml("https://jordanfosterconstruction.com/building-group-commercial-construction/",driver);

		
//		U.log(mainHtml);
		//  U.bypassCertificate();
		String[] mainUrlSec=U.getValues(mainHtml,"<div class=\"et_pb_module et_pb_image et_pb_", "</span></a>");
//		U.log(">>>>>>"+mainUrlSec.length);
		for(String urlSection:mainUrlSec)
		{
			String Url=U.getSectionValue(urlSection, "href=\"","\"");
		String urlHtml=U.getHtml(Url, driver);
		String[] buildingSection=U.getValues(urlHtml, "<div class=\"et_pb_promo_description\">", "Read More</a>") ;
//			U.log("commUrl-->"+Url);
		for(String buildingData : buildingSection) {
			String url=U.getSectionValue(buildingData, "href=\"","\"");
//			U.log("commUrl-->"+url);
			addDetail(url,buildingData);
		}
		}
		
		
		
		LOGGER.DisposeLogger();
		try{driver.quit();}catch (Exception e) {}
	}

	private void addDetail(String comUrl, String oldData) throws Exception {
		// TODO Auto-generated method stub
//	if(j >50) 
	{
		//
//		if(!comUrl.contains("https://jordanfosterconstruction.com/project/artspace-lofts/"))return;
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"::::::::::::::::::::::::::::::::::::::;repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String note=ALLOW_BLANK;
		
//		U.log(oldData);
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHtml(comUrl,driver);
		String descriptionSection=U.getHtmlSection(html, "Description:</span><br />", "</div>");
		if(descriptionSection==null) {
			descriptionSection=ALLOW_BLANK;
		}
		String projSize=U.getSectionValue(html, "Project Size:", "<span");
		U.log(projSize);
		String rem=U.getSectionValue(html, "project_next one columns\">","</body>");
		if(rem!=null)html=html.replace(rem,"");
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(oldData, ">","</a>");
		if(oldData.contains("<h2 class=\"et_pb_module_header\">"))
			communityName=U.getSectionValue(oldData, "<h2 class=\"et_pb_module_header\">","</h2>");
		if(communityName != null)
			communityName = communityName.replace("&amp;", "&").replace("&#039;","").replace("â","").replace("Ã±","n").trim().replace("r?s", "r's").replaceAll("Lofts$", "")
			.replace("–", "-");
		
		if(communityName.endsWith("Apartments")||communityName.endsWith(" Apartment Homes"))communityName=communityName.replaceAll(" Apartment Homes|Apartments", "");
		if(communityName.endsWith("Condominiums"))communityName=communityName.replace("Condominiums", "");
		U.log("community Name---->"+communityName+"<--------------------");
		String desc1="";
		desc1=projSize+U.getSectionValue(html, "et_pb_module et_pb_text et_pb_text_5  et_pb_text_align_left et_pb_bg_layout_dark", "et_pb_row et_pb_row_5 et_pb_row_3-4_1-4");
		//================================================Address section===================================================================
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="TRUE";
/*		String addSec=U.getSectionValue(html,"location_listing\">","|");
		if(addSec!=null)
		{
			String[] add1=addSec.split(",");
			if(add1.length<2)
			{
				add[0]="2211 South IH 35";
				add[1]="Austin";
				add[2]="TX";
				add[3]="78741";
				note="Address Taken From Contact";
			}
			else
			{
			add[1]=add1[0].trim();
			add[2]=add1[1].trim();
			note="Address Taken From City & State";
			
			}
		}*/
		String cityStateSec = U.getSectionValue(oldData, "<div><p>", "</p>");
		if(cityStateSec != null)
			cityStateSec = cityStateSec.replace("El, Paso", "El Paso");
		if(cityStateSec != null && !cityStateSec.contains(",")){
			cityStateSec = U.getSectionValue(html, "</h2>", "</h3>");
		}
		U.log(cityStateSec);
		if(cityStateSec != null) cityStateSec = cityStateSec.replace("<h3>", "").trim();
		if(cityStateSec != null && cityStateSec.contains(",")){
			cityStateSec = cityStateSec.replace("El, Paso", "El Paso");
			String vals[] = cityStateSec.split(",");
			if(vals.length == 2){
				add[1] = vals[0].trim();
				add[2] = vals[1].trim();
				if(add[2].length() > 2)
					add[2] = USStates.abbr(add[2]);
				//note="Address And Lat-Lng Are Taken From City & State";			
			}
			
		}
		
	
		U.log("Address111---->"+add[0]);
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
	String addSec=ALLOW_BLANK;

		String contactUsHTML=U.getHtml("https://jordanfosterconstruction.com/contact-us-v2/",driver);
		if(contactUsHTML!=null && !add[1].contains("Houston")) {
			String contactSec=U.getSectionValue(contactUsHTML, "<h2>Building Group</h2>", "<h2>Infrastructure");
			if(contactSec!=null) {
				String[] contactAddSec=U.getValues(contactSec, "<div class=\"et_pb_blurb_container\">", "</div>");
				for(String contactAddr:contactAddSec) {
					
					if(add[1].contains("Dallas") && contactAddr.contains("<span>Dallas</span>"))
					{
						addSec=U.getSectionValue(contactAddr, "<p>", "<br /><a href");
						if(addSec!=null)
						{
							addSec=addSec.replace("<br />", ", ");
						}
						U.log("Address===="+addSec);
					}
					if(add[1].contains("Austin") && contactAddr.contains("<span>Austin</span>"))
					{
						addSec=U.getSectionValue(contactAddr, "<p>", "<br /><a href");
						if(addSec!=null)
						{
							addSec=addSec.replace("<br />", ", ");
						}
						U.log("Address===="+addSec);
					}
					if(add[1].contains("El Paso") && contactAddr.contains("<span>El Paso</span>"))
					{
						addSec=U.getSectionValue(contactAddr, "<p>", "<br /><a href");
						if(addSec!=null)
						{
							addSec=addSec.replace("<br />", ", ");
						}
						U.log("Address===="+addSec);
					}
					if(add[1].contains("San Antonio") && contactAddr.contains("<span>San Antonio</span>"))
					{
						addSec=U.getSectionValue(contactAddr, "<p>", "<br /><a href");
						if(addSec!=null)
						{
							addSec=addSec.replace("<br />", ", ").replace("29250 Old Fredericksburg Road,, Suite 108", "29250 Old Fredericksburg Road Suite 108,");
						}
						U.log("Address-San Antonio===="+addSec);
					}
				}
			}
		}
//		else if(add[1].contains("Houston")){
////			U.log("oooooooooooooooooooo");
//			add[0]="";
//			add[1]="Houston";
//			add[2]="TX";
//			add[3]="";
//			latlag = U.getlatlongGoogleApi(add);
//			add = U.getAddressGoogleApi(latlag);
////			add = U.getAddress("11010 Harmony Hill Ln, Rowlett, TX 75089"); //manually google search
//			note="Address And Lat-Lng Are Taken From City & State";
//		}
		U.log("%%%%%%%%%===="+addSec);
				if(addSec!=ALLOW_BLANK) {
//					U.log("%%%%%%%%%===="+addSec);
					add=U.getAddress(addSec);
					note="Address Taken From Contact Us Page";
				}
				U.log("Address---->"+add[0]+"--- "+add[1]+" ----"+add[2]+"---- "+add[3]);

		//--------------------------------------------------latlng----------------------------------------------------------------
		/*if(addSec==null)
		{
			add[0]="2211 South IH 35";
			add[1]="Austin";
			add[2]="TX";
			add[3]="78741";
			note="Address Taken From Contact";
		}*/
				U.log("Address111---->"+add[1]);
		if(add[0]==null || add[0]==ALLOW_BLANK){
//			U.log("oooooooooooooooooooo");
			String[] addr= {"",add[1],add[2],""};
			latlag = U.getlatlongGoogleApi(addr);
			U.log("latlag:\t " + Arrays.toString(latlag));
			add = U.getAddressGoogleApi(latlag);
			U.log("Address:\t " + Arrays.toString(add));
			note="Address And Lat-Lng Are Taken From City & State";
		}
//		if(comUrl.contains("https://jordanfosterconstruction.com/project/watters-creek/")){
//			add[1]="Allen";
//			add[2]="TX";
//			latlag = getLatLong(add);
//			add = getAddress(latlag);
////			add = U.getAddress("11010 Harmony Hill Ln, Rowlett, TX 75089"); //manually google search
//			note="Address And Lat-Lng Are Taken From City & State";
////			add = U.getAddress("970 Garden Park Dr, Allen, TX 75013"); //manually google search
////			note="Address Taken From Google";
//		}
//		if(comUrl.contains("https://jordanfosterconstruction.com/project/lake-highlands-town-center/")){
//			add[1]="Dallas";
//			add[2]="TX";
//			latlag = getLatLong(add);
//			add = getAddress(latlag);
//			
////			add = U.getAddress("11010 Harmony Hill Ln, Rowlett, TX 75089"); //manually google search
//			note="Address And Lat-Lng Are Taken From City & State";
////			add = U.getAddress("7100 Wildcat Way, Dallas, TX 75231"); //manually google search
////			note="Address Taken From Google";
//		}
//		if(comUrl.contains("https://jordanfosterconstruction.com/project/the-mark-at-weatherford/")){
//			add[0]=
//					"110 N Main St";
//			add[1]="Weatherford";
//			add[3]="76886";
//			add[2]="TX";
//	//		latlag = getLatLong(add);
//	//		add = getAddress(latlag);
//			
////			add = U.getAddress("11010 Harmony Hill Ln, Rowlett, TX 75089"); //manually google search
//	//		note="Address And Lat-Lng Are Taken From City & State";
////			add = U.getAddress("7100 Wildcat Way, Dallas, TX 75231"); //manually google search
////			note="Address Taken From Google";
//		}
//		if(comUrl.contains("https://jordanfosterconstruction.com/project/zang-triangle/")||
//				comUrl.contains("https://jordanfosterconstruction.com/project/long-point/")||
//				comUrl.contains("https://jordanfosterconstruction.com/project/lake-highlands-town-center/")||
//				comUrl.contains("https://jordanfosterconstruction.com/project/dallas-childrens-advocacy-center/")||comUrl.contains("https://jordanfosterconstruction.com/project/hotel-zaza/")) {
//			add[0]="1502 Marilla St";add[3]="75201";
//			add[1]="Dallas";
//			add[2]="TX";
////			note="Address And Lat-Lng Are Taken From City & State";
//
//		//	latlag = getLatLong(add);
//		//	add = getAddress(latlag);
//			//U.log("Address1:\t " + Arrays.toString(add));
//		}
		
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
//		if(latlag[0]==ALLOW_BLANK && add[1]!=null)
//		{
//			latlag=U.getlatlongGoogleApi(add);
//			if(latlag == null) latlag = U.getlatlongHereApi(add);
//			if(latlag == null) latlag = U.getGoogleLatLngWithKey(add);
//			geo="TRUE";
//		}
		
		if(add[0]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
//			U.log(">>>>>>>>>"+Arrays.toString(latlag));
//			String tempadd[]=U.getAddressGoogleApi(latlag);
//			if(tempadd == null) tempadd = U.getGoogleAddressWithKey(latlag);
//			if(tempadd == null) tempadd = U.getAddressHereApi(latlag);
//			//if(add[1].toLowerCase().trim().equals(tempadd[1].toLowerCase().trim()))
//			{
//				add[0]=tempadd[0];
//				add[3]=tempadd[3];
				geo="TRUE";
//			}
//			note="Address And Lat-Lng Are Taken From City & State";
			
		}
		
//		if(add==null)add = new String[]{ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//		U.log(Arrays.toString(add));
//		if((add[3]==null || add[3]==ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK)
//		{
//			add[3]=U.getAddressGoogleApi(latlag)[3];
//				geo="TRUE";
//		}
		
		U.log("Address:\t " + Arrays.toString(add));
		//
//		if(add[0].contains("cm morales annex bldg.old national hi-way Binan Laguna")) {
//			add[0]="301-399 Dolorosa";add[3]="";
//			add[1]="San Antonio";
//			add[2]="Texas";
//			latlag = getLatLong(add);
//			add = getAddress(latlag);
//			//U.log("Address1:\t " + Arrays.toString(add));
//		}
//		
//		if(add[0].toUpperCase().contains("DFW") && add[0].length()==3) 
//		{
//			
//			add[0]="1699-1565 Marilla St";add[3]="";
//			add[1]="Dallas"; 					
//			add[2]="TX";
//			add[3] ="75201";
//			latlag = U.getlatlongGoogleApi(add);
//			//add= U.getAddressGoogleApi(latlag);
//			
//		}
		//1699-1565 Marilla St
		//============================================Price and SQ.FT======================================================================
					
				
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0s|0's|0&#8217;s","0,000").replaceAll("ew \\$100,000 playground|Project Size:</span> 280,934 Square-feet|clubhouse, totaling 3,450 square-feet| includes 14,000 square-feet of new grass", "");
		String prices[] = U.getPrices(html+oldData,"\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
			U.log("description sec:::::"+desc1);	
		//======================================================Sq.ft===========================================================================================		

//			U.log("--------"+Util.matchAll(comUrl+desc1+communityName+html, "[\\w\\s\\W]{50}409,088[\\w\\s\\W]{100}",0));
			html=html.replace("The 10,000-square-foot Athletes", "The 10,000 square-foot Athletes")
					.replace("Approx. 3.7 million sq. ft.", "3,700,000 sq. ft.").replaceAll("Bldg. \\d+:", "Bldg. :")
				.replaceAll("180,517 square-foot, pre-cast parking|Ballpark consists of 181,000 square-feet |154,000 square-foot warehouse|centers totaling 87,826 square-feet|25,064 square-foot concrete podium|totaling 14,940 square-feet|11,441 square-foot Leasing/Amenity Center|10,000 square-foot terminal|154,000-square-foot warehouse |29,000 square-foot podium| features a 210,000-square-foot,|8,000 square-feet of conference areas", "")
				.replaceAll("square-foot parking garage|\\d+,\\d+ net rentable square-feet|approximately \\d+,\\d+ square-feet|\\d,\\d{3} square-foot party room|parking spaces, totaling \\d+,\\d+ square-feet|finishes, range in size from 560 to 1,263|518 square-foot studios|10,000-square-foot Athletes|7,936 square-foot resident clubhouse|5,600 square-foot open terrace|This 2,879 square-foot remodel| a 6,411 square-foot clubhouse |menity Center is a 3,552|2,584 square-feet|55,000 square-foot", "").replaceAll("387,767 gross square|\\d+,\\d+-square-foot parking|I &#8211; \\d{3},\\d+ Square| \\d,\\d+ square-foot ballroom", "");
		
			if(desc1!=null)
			desc1 = desc1.replaceAll("29,000 square-foot podium", "").replaceAll("55,000 square-foot", "");
		
			//	"Project Size:</span> \\d{3},\\d{3} Square-feet|\\d+,\\d+ gross square-feet|consists of a \\d{1,2},\\d{3} square-foot|\\d{3},\\d{3} net rentable square-feet|size from \\d{3} to \\d,\\d{3} square-feet|\\d+,\\d+ Square-feet|\\d{3},\\d{3} square-foot|\\d{3},\\d{3} net rentable square-feet,|\\d{3,4} to \\d{3,4} square-feet|\\d{2},\\d{3} square-foot|\\d,\\d{3} square-foot |Project Size:\\s+</span>\\s+\\d+,\\d+ Square-feet|Description:\\s*</span>\\s*<br\\s?/>\\s*The \\d,\\d{3} square-foot|(hotel spans|with a combined|consists of) \\d{2,3},\\d{3} square-feet| \\d{3},\\d{3} square-foot hotel features|ranging in size from (\\d,)?\\d{3} square-foot studios to \\d,\\d{3} square-foot |range in size from (\\d,)?\\d{3} to \\d,\\d{3} square-feet|project_info_listing\">\\s*\\d{3},\\d{3} SF|\\d{2},\\d{3} SF|\\d{3} to \\d{4} square |project_info_listing\">\\d{3},\\d{3} sq. ft.|project_info_listing\">(\\s+)?\\d+,\\d{3},\\d{3} sq|project_info_listing\">(\\s+)?(Approx. )?\\d+,\\d{3} (sq|gross (square|sq.))|project_info_listing\">\\d{2,3},\\d{3} gross square feet|info_listing\">\\d{2,3},\\d{3} gross sq. ft|info_listing\">Approx. \\d{2,3},\\d{3} sq. ft.|\\d+,\\d+ net rentable square feet|\\d{2,},\\d+-square-foot|Building #\\d - \\d{2,},\\d{3} sq. ft|approximately \\d{2,},\\d{3} square feet| \\d{2,},\\d{3} net sq. ft| \\d{2,},\\d{3} sq. ft. of retail|retail space totals \\d{2,},\\d{3} square|Bldg. : \\d{2,},\\d{3} sq. ft.|encompassing \\d{2},\\d{3} linear feet|\\d{2},\\d{3} GSF|\\d{3},\\d{3} Gross Square-feet",0));
		String[] sqft = U
				.getSqareFeet(
						(descriptionSection+html+oldData).replace("170,360 square-foot parking", ""),
						"Amenities include \\d,\\d{3} square-feet|totaling \\d,\\d{3} square-feet|range from \\d{3} to \\d{4} square-feet|\\d{3} square-foot studios to \\d,\\d{3} square-foot|from \\d{3} to \\d{1},\\d{3} square-feet|units average \\d{3} square-feet|average unit size is \\d,\\d{3} square-feet|average unit size of \\d{3} square-feet",
						0);
		
		
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);

		
//		if(comUrl.contains("https://jordanfosterconstruction.com/project/pinnacle-bank-place-2/")) {
//			minSqft=ALLOW_BLANK;
//			maxSqft=ALLOW_BLANK;
//		}
		
		//================================================community type========================================================
		html=html.replaceAll("irrigated|corrugated|Corrugated|fixtures both lakeside", "");
		String communityType=U.getCommType(html+oldData);

//==========================================================Property Type================================================
		String html1 = html;
		html=html.replace("garden-style ", "garden home -style ")
				.replace("<h3>MULTIFAMILY </h3>", "<h3>Multi-Family</h3>");
		html=html.replaceAll("quadrangle-style luxury|luxury restaurant|luxury boutique|luxury environment|luxury suites|luxury hotel|luxury one|professional luxury", "luxury homes")
				.replaceAll("data-icon=\"=\">\\s*MULTIFAMILY|/multifamily/|Multifamily</a>| courtyard pool", "");
//		U.writeMyText(html);
		String proptype=U.getPropType(html+oldData+communityName);

//==================================================D-Property Type======================================================
		html=html.replace("one-story clubhouse", "").replace("nine-level", " 9 story")
				.replaceAll("level parking", "")
				.replaceAll("story podium|Levels 2 – 4 will| Level 5 is an amenity|six-story pre-cast concrete", "");
//		.replace("Levels 2 &#8211; 4", "Story 2, Story 4")
		html=html.replace("split buildings", "split-level buildings").replace("three and four-story", " 3 Story  4 Story  ").replaceAll("two and three stories.|two- and three-story", "  2 Story  3 Story  ")
				.replace("The first floor is", " 1 story ").replace("Level 5 ", " 5 Story")
				.replace("three- and four-story", "three-story and four-story").replace("four- and five-story", " 4 Story  5 Story ");

		rem = U.getSectionValue(html, "AWARDS</h5>", "</article>"); //award section removed
		if(rem != null) html = html.replace(rem, "");
		
		String dtype=U.getdCommType((comUrl+desc1+communityName+html).replace("four-story", "4 story").replace("three-story", "3 story").replaceAll("townhome buildings, varying between   2 Story  3 Story|The upper 4 stories consist of a complete wood frame structure|The top floor features two-story| four-story wood structure|two-story storefront window|Craig Ranch|-ranch|features include a two-story, remote|include a two-story remote control-|The one-story, property clubhouse | include a one-level,|clubhouse showcases a two-story| a two-story clubhouse| second level| one level|ranch|Ranch|RANCH|(f|F)loor|FLOOR",""));
		dtype = dtype.replaceAll("12 Story,2 Story", "12 Story");
//		U.log("--------"+Util.matchAll(comUrl+desc1+communityName+html, "[\\w\\s\\W]{50}four-story[\\w\\s\\W]{30}",0));

//==============================================Property Status=========================================================
		String pstatus=U.getPropStatus(html+oldData);
		html1 = html1.replaceAll("multifamily/\">Multifamily</a></li>|MULTIFAMILY</a>|Multifamily</a>", "");
		if((html1.contains("<h3>MULTIFAMILY</h3>") || html1.contains("\">MULTIFAMILY</a>")) && !proptype.contains("Multi-Family")) {
			if(proptype==ALLOW_BLANK || proptype.length()<3)proptype="Multi-Family";
			else proptype="Multi-Family, "+proptype;
		}
//===========================================note====================================================================
		communityName = communityName.replace("San Antonio Zoological Society - Africa Live! Exhibit Phase I & II", "San Antonio Zoological Society - Africa Live");
		if(comUrl.contains("https://www.jordanfosterconstruction.com/project/texas-army-national-guard-tang"))add[3] = "79602";
		if(comUrl.contains("https://jordanfosterconstruction.com/project/mountain-view-high-school-2/")) {
			
			minSqft = "10582";
			maxSqft = ALLOW_BLANK;
		}
		if(comUrl.contains("https://jordanfosterconstruction.com/project/hotel-st-george/")) {
			dtype="4 Story";
			proptype="Luxury Homes";
			minSqft="46,900";
		}
		if(comUrl.contains("https://jordanfosterconstruction.com/project/bienvenir-senior-health/"))dtype="3 Story";
		if(comUrl.contains("https://jordanfosterconstruction.com/project/hotel-zaza/"))proptype="Coutyard Home";
		if(comUrl.contains("https://jordanfosterconstruction.com/project/waterford-springs/")) {
			minSqft=ALLOW_BLANK;
			maxSqft=ALLOW_BLANK;
		}
		if(add[0].contains("6 Offices Across Dallas")){
			add[0]="400-498 Commerce St";
		}
		if(comUrl.contains("https://jordanfosterconstruction.com/project/parkside-towns"))add[0]="S Greenville Ave";
		if(comUrl.contains("https://jordanfosterconstruction.com/project/east-briggs-sanitary-lift-station/"))communityType="Gated Community";
		add[0]=add[0].toLowerCase();
		
		// remove , from street address
		if(add[0].contains(", ")) {
			add[0]=add[0].replace(", ", " ");
		}
		
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);	
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note); 
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
	}
	j++;
	}
	public static String getMyHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					driver.manage().deleteAllCookies();
					driver.manage().window();
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(10000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,3000)", "");
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,4000)", "");
					Thread.sleep(10000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		
	}

	
	
	
	private static String[] getLatLong(String add[]) throws Exception{
		String[]latlag=U.getlatlongGoogleApi(add);
		if(latlag == null) latlag = U.getGoogleLatLngWithKey(add);
		return latlag;
	}
	
	private static String[] getAddress(String latLng[]) throws Exception{
		String tempadd[]=U.getAddressGoogleApi(latLng);
		if(tempadd == null) tempadd = U.getGoogleAddressWithKey(latLng);
		return tempadd;
	}
}