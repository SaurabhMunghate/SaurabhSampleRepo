package com.shatam.b_181_200;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLevelHomes extends AbstractScrapper{

	static int j = 0;
	CommunityLogger LOGGER;
	WebDriver driver=null;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractLevelHomes();
		
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Level Homes.csv", a.data()
				.printAll());
	}

	public static String homeurl = "https://levelhomeslifestyle.com/";

	public ExtractLevelHomes() throws Exception {
		super("Level Homes", homeurl);
		LOGGER=new CommunityLogger("Level Homes");
	}

	int a = 0;
	public void innerProcess() throws Exception {
		
					//		U.setUpChromePath();
					//		driver=new ChromeDriver();
		U.setUpGeckoPath();
		driver= new FirefoxDriver();
		String mainUrl="https://www.levelhomeslifestyle.com/new-homes/";
        String mainHtml=U.getHtml(mainUrl, driver);		
        Thread.sleep(4000);
        String comSec[]=U.getValues(mainHtml, "<div class=\"cell card oi-map-item location-map-item\"", "View Community</a>");
       U.log("comSec=="+comSec.length);
        for(String cs:comSec) {
        	
        	
        	String comUrl="https://www.levelhomeslifestyle.com"+U.getSectionValue(cs, "href=\"", "\"");
        	String comName=U.getSectionValue(cs, "<h2 class=\"entry-title h3\">", "</h2>");
        	
//        	U.log("==========="+comUrl);
        //	U.log(comName);
        	
        	
        	addDetails(comUrl,comName,cs);
        	
        	
        	
//        	U.log("====================");
        	
        	
        }
        
        driver.close();
LOGGER.DisposeLogger();
	}

	
	
	public void addDetails(String comUrl,String comName,String comSec) throws Exception {
		
		
//		try {
//		if(j>=12)
		{
		
		if(comUrl.contains("https://www.levelhomeslifestyle.comhttp://welcome.levelhomeslifestyle.com/magnoliacrossing/"))comUrl="http://welcome.levelhomeslifestyle.com/magnoliacrossing/";
	if(comUrl.contains("https://www.levelhomeslifestyle.comhttps://welcome.levelhomeslifestyle.com/watersedge/"))comUrl="https://welcome.levelhomeslifestyle.com/watersedge/";
	if(comUrl.contains("https://www.levelhomeslifestyle.comhttps://welcome.levelhomeslifestyle.com/clare-court/"))comUrl="https://welcome.levelhomeslifestyle.com/clare-court/";
	if(comUrl.contains("https://www.levelhomeslifestyle.comhttps://welcome.levelhomeslifestyle.com/windsor-park/"))comUrl="https://welcome.levelhomeslifestyle.com/windsor-park/";

	//TODO:
//		if(!comUrl.contains("https://www.levelhomeslifestyle.com/new-homes/la/baton-rouge/materra/7799/"))return;
	
	String comHtml=U.getHtml(comUrl, driver);
		U.log("=======>"+j+"\n"+comUrl);
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("===========repeat");
			return;
		}
		
		if(comUrl.contains("https://www.levelhomeslifestyle.com/new-homes/la/plaquemine/cypress-landing-at-the-island/7867/")) {
			LOGGER.AddCommunityUrl("===========Page Not Found");
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlng[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		
		latlng[0]=U.getSectionValue(comSec, "data-latitude=\"", "\"");
		latlng[1]=U.getSectionValue(comSec, "data-longitude=\"", "\"");
		U.log("latlng=="+Arrays.toString(latlng));

		
		add=U.getAddressGoogleApi(latlng);
		U.log(Arrays.toString(latlng));
		U.log(Arrays.toString(add));
		
		geo="TRUE";
		
	
		
		String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		
	comHtml=comHtml.replaceAll("2,103|2,659|2659|753,718|311,531", "").replaceAll("0s|0's", "0,000");
	comSec=comSec.replace("0s", "0,000");
		prices=U.getPrices(comHtml+comSec, "FROM \\$\\d{3},\\d{3}|start in the \\$\\d{3},\\d{3}|HIGH \\$\\d{3},\\d{3}|Starting from the \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|\"price\">\\$\\d{3},\\d{3}</h3>|\"price\">\\$\\d{3},\\d{3}</span>", 0);
		
		// U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(availHtml, "[\\w\\s\\W]{30}311,531[\\w\\s\\W]{30}", 0));
		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		U.log(Arrays.toString(prices));
		sqft=U.getSqareFeet(comHtml, " \\d,\\d{3} - \\d,\\d{3} Sq. Ft.|from \\d,\\d{3} to \\d,\\d{3} square feet|from \\d,\\d{3} to \\d,\\d{3}\\+ square feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet |\"stat\">\\d{1},\\d{3}</span>|\\d{4} Sq. Ft.", 0);
		
	
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;
		
		U.log(Arrays.toString(sqft));
		
		
		String availDetails="";
		String availHomes[]=U.getValues(comHtml, "image-section grid-y align-justify", "card-section home-specs");
		U.log(availHomes.length);
		for(String ah:availHomes) {
			String availUrl=U.getSectionValue(ah, "href=\"", "\"");
		
//			U.log(availUrl);
			
			String availUrlHtml=U.getHtml("https://www.levelhomeslifestyle.com/"+availUrl, driver);
			
			
			availDetails+=U.getSectionValue(availUrlHtml, "columns-container loaded", "Download Home Brochure");
			
			
		}
		String quickHomeDetail="";
		String id=Util.match(comUrl, "\\d{4}");
		U.log("id===="+id);
		if(id!=null){
		String quickUrlHtml=U.getHtml("https://www.levelhomeslifestyle.com/new-homes/available/?location="+id, driver);
		U.log("quickUrl===="+"https://www.levelhomeslifestyle.com/new-homes/available/?location="+id);
		
		String quickHome[]=U.getValues(quickUrlHtml, "<div class=\"card-info", "<div class=\"community-name\">");
		
		
		
		U.log(quickHome.length);
		
		
		for(String ah:quickHome) {
//			U.log("data===="+ah);
			String homeurl="https://www.levelhomeslifestyle.com"+U.getSectionValue(ah, "<a href=\"", "\"");
//			U.log("homeurl===="+homeurl);
			String quickHomeHtml=U.getHtml(homeurl, driver);
			quickHomeDetail+=U.getSectionValue(quickHomeHtml, "<meta name=\"viewport\"", "Download Home Brochure");
//			break;
			
		}
		
		}
		
		
		String comType=U.getCommType(comHtml);
		
		comHtml=comHtml.replaceAll("The final phase of Belle Savanne|The Cottages at Terrabella|/the-cottages-at-terrabella/", "")
				.replaceAll("Riverton Single Family Homes in Darrow|>Conway Single Family Homes", "")
				.replace("home designs with office, flex, and bonus spaces", "home designs with office, Flex space, and bonus spaces");
		
		
		String pType=U.getPropType(comHtml+comSec+availDetails+quickHomeDetail).replace("img alt=\"Sweetwater Point Commercial / Multi-Family Conceptual Rendering","");
//		 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comHtml+comSec+availDetails+quickHomeDetail, "[\\w\\s\\W]{100}Single Family Home[\\w\\s\\W]{30}", 0));

		if(comUrl.contains("https://www.levelhomeslifestyle.com/new-homes/la/addis/sugar-mill-plantation/7803/"))
			pType="Single Family, Patio Homes";
		
		String dType=U.getdCommType((comHtml+availDetails+quickHomeDetail+comSec).replaceAll("one-level-menu|efficient one story 3 bed|The Bourget is a one story 3/2 with over|Spacious one story 4 bedroom|efficient one story 3 bed","1 Story"));

		comHtml = comHtml.replace("Premium water-front homesites will be available", "Premium water-front homesites available");
		comHtml=comHtml.replace("8 homes sold in first 2 hours open!","");

		String pStatus=U.getPropStatus((comHtml+comSec).replaceAll("QUICK MOVE-IN HOMES|#moveinready|<span>Quick Move-In Homes</span>|quick move|Quick Move", ""));
//		U.log(comSec);
//		U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comHtml+comSec, "[\\w\\s\\W]{30}quick[\\w\\s\\W]{30}", 0));

		pStatus=pStatus.replace("Quick Move-in", "Move-in Ready Homes")
				.replace("New Phase Now Selling, Now Selling", "New Phase Now Selling");
		
		String note=U.getnote(comHtml);
		if(comUrl.contains("la/baton-rouge/waters-edge/7929/"))note=ALLOW_BLANK;
		if(comUrl.contains("https://www.levelhomeslifestyle.com/new-homes/la/geismar/belle-savanne-at-dutchtown/7825/")) {
			pStatus="New Homes Coming Soon";
		}
		pStatus=pStatus.replaceAll(", Move-in Ready Homes|Move-in Ready Homes, |Move-in Ready Homes", "");

		data.addCommunity(comName, comUrl, comType);
		data.addPrice(prices[0], prices[1]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replace("Move-in Ready Homes Homes", "Move-in Ready Homes"));
		data.addNotes(note);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		
		}
		j++;
//		}
//		catch (Exception e) {}
	}
	
}
