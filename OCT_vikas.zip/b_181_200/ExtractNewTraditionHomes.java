package com.shatam.b_181_200;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractNewTraditionHomes extends AbstractScrapper {
	static int j=0,k=0;
	public static String HOME_URL = "https://www.newtraditionhomes.com";
	public static CommunityLogger LOGGER;
	public ExtractNewTraditionHomes() throws Exception {
		super("New Tradition Homes", HOME_URL);
		LOGGER=new CommunityLogger("New Tradition Homes");
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractNewTraditionHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"csv/New Tradition Homes.csv", a.data()
				.printAll());
		
	}
	WebDriver driver=null;

	@Override
	protected void innerProcess() throws Exception {
		String regionUrl = "https://www.newtraditionhomes.com/communities";
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
		String regionHtml = U.getHtmlHeadlessFirefox(regionUrl, driver);
		U.log(U.getCache(regionUrl));
		String comSec=U.getSectionValue(regionHtml, "communities-list","</footer></div>");
		String[] urlsec=U.getValues(comSec, "<a ng-href=\"", "</a></li>");
		int j=urlsec.length;
		U.log("Total community :-"+ j);
		for(String s:urlsec)
		{
			String url=U.getSectionValue(s, "href=\"","\">");
			url="https://www.newtraditionhomes.com"+url;
			addDetails(url,s);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	
		
////===============================Code by Upendra================================
	
	
	public  void addDetails(String url,String sec)throws Exception 
	{
		//if(j==4)
		{
			U.log(sec);
			if(data.communityUrlExists(url))
			{
				LOGGER.AddCommunityUrl(url+"::::::::::::::::::::::::::::::::::::::;repeated");
				k++;
				return;
			}
			LOGGER.AddCommunityUrl(url);
			
			//if (!url.contains("https://www.newtraditionhomes.com/hockinson-meadows"))return;
			
			String commHtml = U.getHtmlHeadlessFirefox(url, driver);
			
			
			String commName = U.getSectionValue(sec, "binding\">", "</strong>");
			commName = commName.replace("Build Anywhere (on your lot) - ", "");
			String flag="FALSE";
			U.log(commName);
		//===========================Address=====================================
		U.log("url:::::"+url);	
			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String	addrSec=U.getSectionValue(commHtml, "header-wrapper","Hours:");
		if(addrSec==null)
			addrSec=U.getSectionValue(commHtml, "header-wrapper","Phone:");
		U.log("sampada"+add[0]);
		if(addrSec!=null)
		{
			addrSec=U.removeComments(addrSec);
			U.log("hhhhh "+addrSec);
			addrSec=addrSec.replaceAll("Model Home at Archer Estates: 11504 Woodsman Drive, Pasco, WA 99301|\" class=\"ng-binding ng-scope\">|\" class=\"ng-binding ng-scope\">|\" class=\"ng-binding ng-scope\">","");
			
			add[0]=U.getSectionValue(addrSec, "<li class=\"ng-binding\">", "</li>");
			U.log(add[0]);
			add[0]=add[0].replace(", and ", " and ").replaceAll(", Battle Ground, WA, 98604|, Ridgefield, WA 98642| in Ridgefield, WA","");
			
			add[1]=U.getSectionValue(addrSec, "community.city_name","</span>");
			add[2]=U.getSectionValue(addrSec, "community.state_code","</span>");
			add[2]=add[2].replace(",", "");
			add[3]=U.getSectionValue(addrSec, "community.com_zip","</span>");
		}
		U.log("My Address::"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		//==================================LatLong==================================
		
		
		String[] latlong = {ALLOW_BLANK,ALLOW_BLANK};
		
		if(commHtml.contains("Map/Directions</a></li>")){
			String dirUrl = url+"-directions";
			String dirHtml=U.getHtmlHeadlessFirefox(dirUrl,driver);
				String latLngSec = U.getSectionValue(dirHtml, "?q=", "&");
				U.log("latLngSec:::::::::::::::::::::"+latLngSec);
				if(latLngSec!=null){
					latlong=latLngSec.split(",");
				}
				U.log(latlong[0]+":::::::::::::::"+latlong[1]);
		}
		if(add[0]==null)add[0]=ALLOW_BLANK;
		if(add[1]==null)add[1]=ALLOW_BLANK;
		if(add[1].length()>4 && latlong[0].length()<4)
		{
			String[] temp=add;
			temp[0]=temp[0].replace("8914 Bridger Ct.", "");
			 latlong = U.getlatlongGoogleApi(add);
			 flag="TRUE";
			 
		}
		
		if (add[0].length()<4) {
			add= U.getAddressGoogleApi(latlong);
			//add[0] = addr[0];
			flag = "TRUE";
		}
		/*if(url.contains("http://www.newtraditionhomes.com/build-anywhere-on-your-lot-tri-cities")){
			 latlong = U.getlatlongGoogleApi(add);
			 flag="TRUE";
		}*/
		//--------------------------floorPlan data---------------------------------
		String floorPlanHtml=ALLOW_BLANK;
		String allFloorData = ALLOW_BLANK;
		int count=0;
		if(commHtml.contains("View<br>Neighborhood<br>Plans</a>")){
			String floorPlanUrl=url+"-floorplans";
			floorPlanHtml = U.getHtml(floorPlanUrl, driver);
			
			String[] floorUrls = U.getValues(floorPlanHtml, "result-col-btn\"> <a ng-href=\"", "\"");
			for(String eachFloorUrl : floorUrls){
				U.log("eachFloor::::::::"+"http://www.newtraditionhomes.com"+eachFloorUrl);
				String flrHtml = U.getHtmlHeadlessFirefox("http://www.newtraditionhomes.com"+eachFloorUrl,driver);
				allFloorData = U.getSectionValue(flrHtml, "<h1>Floor Plan Details", "More Info")+allFloorData;
				count++;
				if(count>5){
					break;
				}
			}
		}
		
		//-----------------available homes data--------------
		String allAvailHomeHtml = ALLOW_BLANK;
		String availHomeHtml = ALLOW_BLANK;
		if(commHtml.contains("View<br />Available<br />Homes</a>")||commHtml.contains("View<br>Available<br>Homes</a>")){
			String availUrl = url + "-homes";
			U.log("availUrl:::::::::::"+availUrl);
			 availHomeHtml = U.getHtmlHeadlessFirefox(availUrl, driver);
			String[] availUrls = U.getValues(availHomeHtml, "result-col-btn\"> <a ng-href=\"", "\"");
			for(String eachavailUrl : availUrls){
				U.log("eachavailUrl::::::::"+"http://www.newtraditionhomes.com"+eachavailUrl.replace("&amp;", "&"));
				String avlHtml = U.getHtmlHeadlessFirefox("http://www.newtraditionhomes.com"+eachavailUrl.replace("&amp;", "&"),driver);
				allAvailHomeHtml = U.getSectionValue(avlHtml, "<h1>Home Details</", "More Info")+allAvailHomeHtml;
				count++;
				if(count>5){
					break;
				}
			}
		}	
		//U.log(allAvailHomeHtml);
		//======================Price==================================
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		commHtml=commHtml.replaceAll("0s|0's|0�s", "0,000").replace("00’s", "00,000");
		sec=sec.replaceAll("0's|0s","0,000");
		
		String[] price = U.getPrices(commHtml+sec+floorPlanHtml+availHomeHtml, "From the upper \\$\\d{3},\\d{3}|</strong> \\$\\d{3},\\d{3}<|<td>\\$\\d{3},\\d{3}</td>|mid \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice);
		U.log(maxPrice);
	//=========================SqrFt===============================	
		String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(commHtml+sec+availHomeHtml+floorPlanHtml,
				"SQFT:</strong> \\d,\\d+|<td>\\W+\\d{4}|\\d,\\d+ to over \\d,\\d+ square fee|Square Feet: \\d{4}|\\d,\\d+ to over \\d+,\\d+ square foot homesites", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
	//============================PropStatus===============================
		commHtml=commHtml.replace("Quick Move In Homes","");
		commHtml=commHtml.replaceAll("Wrap Cottage|Cottage Trim|Luxury Tile Shower in Master|see the brand new homesites now available|Quick Move In Homes</a>|Quick Move","");
		commHtml = commHtml.replaceAll("officially Sold Out of homesites|opening in <strong>Fall 2017|opening in&nbsp;<strong>Fall 2017", "opening Fall 2017");
		commHtml=commHtml.replace("1 is Now Open!","").replace("financing available through the USDA.", "USDA financing").replace("GRAND OPENING</strong> of Phase 2", "Grand Opening Phase II");
		String propertyStatus = U.getPropStatus(commHtml+sec.replaceAll("\'Coming Soon\'",""));
		//U.log(Util.match(commHtml, ".*grand opening.*"));
		
	//===========================PropType================================
		commHtml=commHtml.replaceAll("New Tradition Homes|newtraditionhomes","").replace("\"Custom Homes","").replace("\"custom homes","");
		String propertyType = U.getPropType((commHtml+allAvailHomeHtml+allFloorData).replace("custom",""));
		
	//==========================D-prop-Type===============================
		floorPlanHtml =floorPlanHtml.replace("Stories:</strong>", "Stories:");
		allAvailHomeHtml=allAvailHomeHtml.replace("Stories:</strong>", "Stories:");
		floorPlanHtml = U.getNoHtml(floorPlanHtml);
		String derivedPropertyType = U.getdCommType(commHtml+sec+floorPlanHtml+allFloorData+allAvailHomeHtml);
	//========================Community Type===============================
		String communityType = U.getCommunityType(commHtml);
	//==============================Notes===============================
	String	note =U.getnote(commHtml);
	
	if(url.contains("http://www.newtraditionhomes.com/broadmoor-terrace")){
		add[0]="8914 Bridger Ct";
	}

	if(url.contains("http://www.newtraditionhomes.com/brantingham-heights")){
		add[0]="4897 Highview Street";
		add[1]="Richland";
		
		add[3]="99352";
		flag="TRUE";
		propertyType="Patio Homes,Luxury Homes";
	}
	
	propertyStatus=propertyStatus.replace("Phase 2 - Coming Soon","Phase 2 Coming Soon");
	add[1]=add[1].replace("Vancouver, WA","Vancouver");
	if(data.communityUrlExists(url))return;
	propertyType=propertyType.replace(",Custom Homes|Custom Homes,","");
	propertyType=propertyType.replace("Custom Homes","").replaceAll(",$", "").replace(",,", ",");
	if(propertyType.length()==0){
		propertyType=ALLOW_BLANK;
	}
	add[0] = add[0].replace("&amp;", "&");
	U.log("Add : "+Arrays.toString(add));
	
	data.addCommunity(commName, url, communityType);
	data.addAddress(add[0].trim().replace(".", "").replace(",", ""), add[1].trim(), add[2].trim(), add[3].trim());
	data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), flag);
	data.addPropertyType(propertyType, derivedPropertyType);
	data.addPropertyStatus(propertyStatus.replace("-,", "").replace("Ii", "II"));
	data.addPrice(minPrice, maxPrice);
	data.addSquareFeet(minSqFeet, maxSqFeet);
	data.addNotes(note);
		
		}j++;
	}
}