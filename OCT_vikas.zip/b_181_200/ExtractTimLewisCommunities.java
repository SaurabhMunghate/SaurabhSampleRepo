/*sampada santosh */

package com.shatam.b_181_200;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

import bsh.commands.dir;

public class ExtractTimLewisCommunities extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	private String geo = "True";
	CommunityLogger LOGGER;
	WebDriver driver;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractTimLewisCommunities();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Tim Lewis Communities.csv", a.data().printAll());
	}

	public ExtractTimLewisCommunities() throws Exception {

		super("Tim Lewis Communities", "https://www.timlewis.com/");
		LOGGER = new CommunityLogger("Tim Lewis Communities");
	}

	public void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		HashSet<String> set = new HashSet<String>();
		String mainHtml = U.getHTML("https://www.timlewis.com/find-a-community/")+U.getHTML("https://www.timlewis.com/find-a-community/page/2/");
		String addsecs[]=U.getValues(mainHtml, "<div class=\"marker\"", "</div>");
		String comData[] = U.getValues(mainHtml, "<div class=\"community-inner\">", "View Community</a>");
		U.log(comData.length);
		for (String comSec : comData) {
			String comUrl = U.getSectionValue(comSec, "<a href=\"", "\">");
//			U.log((j++)+" "+comUrl);
			//set.add(comUrl);
//			try {
			addDetails(comUrl, comSec, mainHtml,addsecs);
//			} catch (Exception e) {}
			
		}
		LOGGER.DisposeLogger();
//		try{driver.quit();}catch (Exception e) {}
	}

	int i = 0;

	//TODO ::
	public void addDetails(String comUrl, String comSec, String mainHtml,String addsecs[]) throws Exception {
//		if(i >= 8)
//		if(!comUrl.contains("https://www.timlewis.com/communities/kingsbury-estates/")) return;

		{
			if(comUrl.contains("https://www.timlewis.com/communities/star-harbo"))comUrl="http://starharboralameda.com/";
			
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+"<=========== Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			String htmlone = html;
			
			U.log(U.getCache(comUrl));	
			
			U.log("comUrl: "+comUrl);
			
			// ------------------ No. of units ------------------------
		    String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(html, comUrl, driver);
			U.log("Total Units : "+units);

			
			String comName = U.getSectionValue(comSec, "<h3 class=\"entry-title\">", "</h3>");
			if(comName != null)
			comName = comName.replaceAll("&#8211;", "-").replace("- The Garden Homes", "").replace(" - SOLD OUT", "");
			
			U.log("comName--> " + comName);
			String statusSec = U.getSectionValue(mainHtml, "span class=\"description\">"+comName, "</span></a></li>");
			html = html.replace("</strong>", "");

			String note = U.getnote(html.replace("JUST RELEASED FOR SALE!</span>", ""));
			// --------adress----------//

			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String address[];
			String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
			String geo = "False";
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			//U.log(html);
			// String addSec = U.getSectionValue(comSec, "</h4>", "</").trim();
			String addSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place", "</p>");
			
			if(addSec==null)
				addSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps", "</p>");
			U.log("address section here-->" + addSec);
			
			if(comUrl.contains("/communities/bridle-gate/"))
			{
				addSec = U.getSectionValue(addSec, ">", "<");
				add=U.getAddress(addSec);
			}
			
			if(comUrl.contains("https://www.timlewis.com/communities/revival/")) {
				addSec = U.getSectionValue(htmlone, "Location:</strong>", "(Located off");
				U.log("addSec1: ====== "+addSec);
				add=U.getAddress(addSec);
			}
			if(comUrl.contains("https://www.timlewis.com/communities/reflections/")) {
				addSec = U.getSectionValue(htmlone, "Elk Grove - (916) 647-4493</h4>", "</p>").replace("<p style=\"font-weight: 400;\">", "");
				U.log("addSec2: ====== "+addSec);
				add=U.getAddress(addSec);
			}
			if(comUrl.contains("https://www.timlewis.com/communities/kingsbury-estates/")) {
				String addSection = U.getSectionValue(htmlone, "Located at <a", "</p>");
				addSec = U.getSectionValue(addSection, "119.7516909\">", "</a>").replace("1206 Spur Way Gardnerville", "1206 Spur Way, Gardnerville");
				U.log("addSec3: ====== "+addSec);
				add=U.getAddress(addSec);
			}
			
			
			if(addSec!=null && add[0]==ALLOW_BLANK){
				String add1=U.getSectionValue(addSec, "/", "/").replaceAll("Southampton Drive &amp; Meridian Lane|\\+", " ").replace("Meridian Ln %26 ", "").replace("%2C", ",")
						.replaceAll("\\?q=|\" target=\"_blank\">900 Lazy Trail Dr, Rocklin, CA 95765, USA<|, USA|\" target=\"_blank\">10001 Winkle Cir, Elk Grove, CA 95757", "")
						.replaceAll("(.*?) target=\"_blank\">", "");
				
				U.log("addSec-->"+addSec);
				add=U.getAddress(add1);
				if(add[0]== ALLOW_BLANK)add1 = U.getSectionValue(add1, "\">", "</a");
				 
			}
			if (addSec != null)
			{	
				addSec = U.getSectionValue(addSec, "rel=\"noopener\">", "<");
			}
			if(addSec!=null) {
			addSec = addSec.replace("14725 Toulouse Ct. Reno NV 89511", "14725 Toulouse Ct, Reno, NV 89511")
					.replace("&amp;,", "&").replace("homeowners association", "");
			addSec = addSec.replace("Roseville, CA, United States", "300 Miners Ravine Court, Roseville, CA 95661");
			if (addSec != null && addSec.length() > 10 && addSec.contains(",")) {
				addSec = addSec
						.replaceAll("Southampton Dr|, United States|Whispering Canyon, by Tim Lewis Communities \\(Nevada\\), Inc.,",
								"")
						.replace(" Reno", ", Reno").replace(" Dublin", ", Dublin");
	

				U.log("AddSec==" + addSec);
				add = U.getAddress(addSec);
			}
			}
			//U.log(addSec+"-----=-=-=-="+addsecs.length);
			
			
			if (comUrl.contains("https://www.timlewis.com/communities/zinfandel-ridge/")) {

				add[0] = "8699 Vintner Drive";
				add[1] = "Plymouth";
				add[2] = "CA";
				add[3] = "95669";
				 geo = "True";
				 				latLong=U.getlatlongGoogleApi(add);
					if(latLong == null) latLong = U.getlatlongHereApi(add);
					add = U.getAddressGoogleApi(latLong);
					if(add == null) add = U.getAddressHereApi(latLong);
					geo = "True";
				// note="Address And LatLon Taken From City And State";
			}
			else if (comUrl.contains("https://www.timlewis.com/communities/cedar-creek-galt-california-new-homes/")) {

				add[0] = "3500 Douglas Blvd Suite 270";
				add[1] = "Roseville";
				add[2] = "CA";
				add[3] = "95661";
				latLong = "38.74354027594804, -121.23113697286988".split(",");
				 geo = "True";
				// note="Address And LatLon Taken From City And State";
			}
			
			else if (comUrl.contains("/communities/sutter-park-")) {
				
				add[0]="5100 Sutter Park Way";
				add[1]="Sacramento";
				add[2]="CA";
				add[3]="95819";
				latLong = "38.5727945,-121.4399464".split(",");
/*				latLong=U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);*/
//				geo = "True";
//				note="Address And LatLon Taken From City And State";
			}else if (add[0] != null) {
				latLong[0] = U.getSectionValue(html, "data-lat=\"", "\"");
				latLong[1] = U.getSectionValue(html, "data-lng=\"", "\"");
			}
			if (latLong[0]==null) {
				String latlongSec=Util.match(html, "/@\\d{2}.\\d+,-\\d{2,3}.\\d+");
				U.log(latlongSec);
				if (latlongSec!=null) {
					latLong=latlongSec.replace("/@", "").split(",");
				}
				
			}
			if(latLong[0]==null) {
				for (String addressfromre : addsecs) {
					
					if(addressfromre.contains(comUrl)) {
						//U.log(addressfromre);
						latLong[0]=U.getSectionValue(addressfromre, "data-lat=\"", "\"");
						latLong[1]=U.getSectionValue(addressfromre, "data-lng=\"", "\"");
						addSec=U.getSectionValue(addressfromre, "</h4>", ", USA");
						if(addSec!=null&&!addSec.contains("+")) {
							add=U.getAddress(addSec);
						}
						break;
					}
				}
			}
			if ((add[0] == ALLOW_BLANK || add[3].length() < 4) && latLong[0]!=null) {
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				geo = "True";
			}
			
			if (comUrl.contains("starharboralameda")) {
				
				add[0]="12667 Alcosta Blvd., Suite 170";
				add[1]="San Ramon";
				add[2]="CA";
				add[3]="94583";
				latLong[0]="37.7745586";
				latLong[1]="-121.9610328";
			}
			
			if(comUrl.contains("https://www.timlewis.com/communities/whispering-canyon-single-family-homes-caughlin-ranch/")) {
				 
				 add = U.getAddressGoogleApi(latLong);
				 if(add == null) add = U.getAddressHereApi(latLong);
				 geo = "TRUE";
			 }
			
			
			
			
			add[0] = add[0].replace("/Bridle+Gate+by+Tim+Lewis+Communities+(Nevada) +Inc/@ 17z/data=!3m1!4b1!4m5!3m4!1s0x8099138ed7634c07:0x9ed01b95b9518b46!8m2!3d39393926!4d-119727898\"\">", "").replace(",", "")
					.replaceAll("10420 Big Horn Blvd Elk Grove CA 95757\" target=\"_blank\">|8229 Elk Grove Blvd Elk Grove CA 95758\" target=\"_blank\">", "");
			U.log("add[0]====" + add[0] + " add[1]==== " + add[1] + "add[2]===" + add[2] + "add[3]===" + add[3]);
			U.log("latlng---> " + latLong[0] + "  " + " " + latLong[1]);

			String homeData = "";
			if (html.contains("<div class=\"model-listing\">"))
				homeData = U.getSectionValue(html, "<div class=\"model-listing\">", "class=\"community-form");
			if (comUrl.contains("/communities/sutter-park-")) {
				String tempValues[]=U.getValues(html, "<div class='uabb-infobox-title-wrap'>", "<span class=\"s1\">");
				for (String temp : tempValues) {
					U.log(temp);
					homeData+=temp;
					
				}
			}
			String remFooter = U.getSectionValue(html, " class=\"community-form\">", "</body>");
			if (remFooter != null)
				html = html.replace(remFooter, "");

			String homeHtml = "";
			if (homeData != null) {
				String homeLink[] = U.getValues(homeData, "<a href=\"", "\"");
				U.log("total homes--> " + homeLink.length);

				for (String homeUrl : homeLink) {
					if(homeUrl.contains("contact"))continue;
					U.log("homeUrl--> " + homeUrl);
					homeHtml = homeHtml + U.getHTML(homeUrl.replace("http://", "https://"));
				}
			}
		
			String sutterQuick = "";
			if (comUrl.contains("/communities/sutter-park-") ) {
				
				sutterQuick = U.getHTML(comUrl.replace("https://www.timlewis.com/communities/sutter-park-", "https://sutterparkliving.com/the-garden-homes")+"qmis/");
			}
			if (comUrl.contains("https://www.timlewis.com/communities/sutter-park-the-classics/") ) {
				
				sutterQuick += U.getHTML("https://sutterparkliving.com/the-classics/qmis/");
			}
			if(comUrl.contains("https://www.timlewis.com/communities/zinfandel-ridge/"))
				homeHtml = U.getHtml("http://www.zinfandelridge.com/plans",driver);
			
//			U.log("homodata"+homeHtml);
			
			String priceSec="";
			String communityMapUrl=U.getSectionValue(html, "<section id=\"community-page-map\" class=\"community-page-map\">", "</h3>");
			if(communityMapUrl!=null) {
				String url=U.getSectionValue(communityMapUrl, "<a href=\"", "\" ");
				String html1=U.getHTML(url);
//				U.log(">>>>>>"+html1);
				if(html1!=null)
				priceSec=U.getSectionValue(html1, "<span>this Community</span>", " <div class=\"panel-group\" id=\"availablePlans\">");
				
			}
			
				homeHtml=homeHtml.replace("title\">Pricing From $795,925</h3>", "").replace("$1.2 Millions", "Priced From:$1,200,000")
						//.replace("$1 Millions", "Priced From:$1,000,000")
						.replace("Pricing From The $1 Millions", "Pricing From The $1,000,000 Millions")
						.replaceAll(">Pricing From The Priced From:\\$1,000,000</strong>|Save over \\$157,000", "")
						.replaceAll("Pricing From \\$(\\d)M", "Pricing From \\$$1,000,000")
						.replace("Pricing From The Low $1 Millions", "Pricing From The Low $1,000,000");
				
				
				html=html.replace("the 1,300,000&#8217;s", "Priced From:$1,300,000")
						.replaceAll("Lot 14 Priced At \\$1,008,065|over \\$\\d{3},\\d{3} in included upgrades", "");
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				String price[] = U.getPrices(priceSec+html + homeHtml + sutterQuick,
						"\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
						0);// |Priced From: \\$\\d{3},\\d{3}
				minPrice = (price[0] != null) ? price[0] : ALLOW_BLANK;
				maxPrice = (price[1] != null) ? price[1] : ALLOW_BLANK;
				U.log("price --> " + minPrice + "  " + maxPrice);
//				U.log(">>>>>>>>>>>>"+Util.matchAll(homeHtml, "[\\s\\w\\W]{50}Pricing From [\\s\\w\\W]{50}", 0));
				
				if(homeHtml!=null)
				homeHtml = homeHtml.replace("3,249 - 3,298", "3,249 - 3,298 sq ft");
				html =html.replace("3,249 - 3,298", "3,249 - 3,298 sq ft").replaceAll("over \\$\\d{3},\\d{3} in included upgrades|more. 10,098 sq. ft. lot|up to 4,000 square feet on 1 to 2-acre parcels", "");
				
				String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(html + homeHtml,
						"Approx. \\d,\\d{3} sq. ft.|>\\d,\\d{3} - \\d,\\d{3} sq ft<|>\\d,\\d{3} sq ft<|from \\d,\\d{3} – \\d,\\d{3} sf|class=\"s1\">\\d,\\d{3} sf,|span class=\"s1\">\\d{3,4} sf,|<p>\\d,\\d{3} sq ft<br />|<strong>\\d{4} sf|\\d,\\d{3}\\sSq. Ft.|\\d,\\d{3}\\ssquare feet|<span class=\"s1\">\\d,\\d{3} sf", 0);
				minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
				//if(minSqf.length()==2)minSqf = ALLOW_BLANK;
				//================ property type ==================
				homeHtml = homeHtml.replaceAll("<li>Loft|6 Bedrooms \\+ Loft", "loft-style").replaceAll("The Traditionals|Sacramento Townhomes|dream townhome today|\"caption\":\"Craftsman Style Home\"}", "");;
				html = html.replace("The Traditionals", "Traditional exterior").replace("Two story 4", "Two story ").replace(" single story 2,505 sq ft ", " single story, 2,505 sq ft ").replaceAll("The Traditionals|Sacramento Townhomes|dream townhome today|\"caption\":\"Craftsman Style Home\"}", "");
				
				String propType = U.getPropType(
						 (html + homeHtml+sutterQuick).replace("Executive Single-story Homes on", "executive style Single-story Homes on")
						 .replace("Patio\" width=\"200\" height=\"200\">", "")
						 
						 .replace("home offices, multi-gen,", "home offices, multi-generational living,")
						 .replace("for a custom finish", "for a custom home")
						 .replace("Farmhouse or Craftsman-inspired floorplans", "Farmhouse exterior or Craftsman-inspired floorplans")
						 .replace("plan1_c_english_cottage", "plan1_c_english").replace("title=\"English Cottage\"", "plan1_c_english")
						 .replaceAll("title=\"French Cottage|title=\"English Cottage|english_cottage.jpg|french_cottage_even.jpg|Move-In properties at The Garden Homes today|\"The Garden Homes|Quick Move-Ins - The Garden Homes - Sutter Park|value='The Garden Homes|Garden Homes' >The Garden Homes|The Garden Homes</span></a>|\"Garden Homes|value='The Traditionals' >The Traditionals|the-traditionals/\"><span class=\"s1\">The Traditionals</span></a>|English Cottage</p>|the-traditionals|French-Cottage.jpg|one of our luxurious new homes|value='French Cottage'|Modern-Farmhouse|Modern-Farmhouse.jpg|><p>English Cottage|A_Modern Farmhouse|C_French-Cottage|English-Cottage|>French Cottage</option>|/h2><div class=\"fl-slide-text\"><p>French Cottage</p>|<div class=\"fl-slide-text\"><p>Modern Farmhouse</p>|class=\"description\">The Garden Homes|Luxury New Home Builders|French Cottage<|French-Cottage|English-Cottage|<option value='(.*?)'>|The Garden Homes<|single-family-homes-caughlin-ranch|Carmel-Cottage|luxurious new homes in Elk Grove|content=\"Craftsman Style Home\"", ""));
				
				U.log("proptype--> " + propType);
				//========== community type ================
				html = html
						.replace("whitney-ranch/\">The Summit At Whitney Ranch<span ", "")
						.replace("single-story living on large homesites in the beautiful wine", "One Story living on large homesites in the beautiful wine")
						.replace("Explore The Master Plan", "Explore The Master-Planned Community");
				String comType = U.getCommType(html);
				U.log("comType--> " + comType);

				String dpropType = U.getdCommType(
						(html + homeHtml)
						.replace("\"Spanish Ranch\"", "")
						.replace("Ranch<span", "")
						.replace(" Ranch\"", "")
						.replace("on=\"Modern Ranch\">", "")
						.replace("Ranch</h3>", "")
						.replace("Ranch (Rocklin)", "")
						.replaceAll("Caughlin Ranch|Floor|single-family-homes-caughlin-ranch|whitney-ranch|Whitney Ranch", "")
								+ comName);
				U.log("dType--> " + dpropType);
//				U.log(">>>>>>>>>>>>"+Util.matchAll(html + homeHtml+comName, "[\\s\\w\\W]{20} ranch[\\s\\w\\W]{20}", 0));

				
				mainHtml = U.removeSectionValue(mainHtml, "<header", "</header>");
				
				// status section from region page
				String statSec = U.getSectionValue(mainHtml, "<li id=\"menu-item-2631\"", "<li id=\"menu-item-3367\"");
				String statDesc = "", statDesc2 = "";
				statDesc=U.getSectionValue(html, "<div id=\"community-description\" class=\"community-description\">", "<section class=\"sales-people\">");
				if (html.contains("<h1 class=\"community-title\"")) {
					statDesc2 = U.getSectionValue(html, "<h1 class=\"community-title\"", "</h1>");
				}
				String navbarDesc=U.getSectionValue(html, ">Communities</a>", "Previous Communities</a></li>");
				String navBarCommSec="";
				if (navbarDesc!=null) {
					navBarCommSec=U.getSectionValue(navbarDesc, comUrl, "</a>");
				}
				
				String forSts = ALLOW_BLANK;
				if((comUrl.contains("https://www.timlewis.com/communities/magnolia-granite-bay/"))) {
					forSts = U.getSectionValue(html, "<h2 style=\"text-align: center;\">", "</h2>");
					U.log("forSts: "+forSts);
				}
//				U.log(statusSec);
				//U.log(statDesc + statDesc2+navBarCommSec+statusSec);
				
				if((comUrl.contains("https://www.timlewis.com/communities/sutter-park-the-garden-homes/"))) {
					forSts = U.getSectionValue(html, "<h2 class=\"uabb-heading\">", "</h2>");
					U.log("forSts: "+forSts);
				}
				
				String comStatus = U.getPropStatus((forSts+statDesc + statDesc2+navBarCommSec+statusSec)
						.replace("LAST CHANCE! MODELS", "")
						.replace("Last Chance! Models", "")
						.replaceAll("move|Move|MOVE", "")
						.replace("Point II Coming Summer of 2022","Point II Coming Summer 2022")
						.replace("Newest Community Selling Now", "Newest Community Now Selling")
						.replaceAll("cription\">COMING SOON!<|cription\">COMING SOON<|Tour one of our Quick Move-In homes today|View Our Quick Move-In Specials|Sales Center Now Open!|Sales Center is Now Open|Sales Trailer Now Open|Whites Creek is currently Sold Out|Monte Vista are Now Available", ""));
				
				U.log("property status--> " + comStatus);
				U.log(">>>>>>>>>>>>"+Util.matchAll(forSts+statDesc + statDesc2+navBarCommSec+statusSec, "[\\s\\w\\W]{10}Sold out[\\s\\w\\W]{3}", 0));
//				if(html.contains("<h3>Quick Move In Homes</h3>") || html.contains(">View Our Quick Move-In Specials</span>")){
//					if(!comUrl.contains("/sutter-park-the-traditionals/")){
//						if(comStatus.length()<4)comStatus = "Quick Move In Homes";
//						else comStatus = comStatus +", Quick Move In Homes";
//					}
//				}
/*				if(comUrl.contains("https://www.timlewis.com/communities/sutter-park-the")){
					if(comStatus.length()<4)comStatus = "Now Selling";
					else comStatus +=", Now Selling";
				}
*/				
/*				if(comUrl.contains("https://www.timlewis.com/communities/monte-vista/"))comStatus=comStatus+", Currently Sold Out";
				if(comUrl.contains("https://www.timlewis.com/communities/latitudes/"))add[0] = add[0].replace("Ln", "Lane");
				if(comUrl.contains("https://www.timlewis.com/communities/cedar-creek/"))add[0]="1106 Ayers Ln";
				
*/
				if(comUrl.contains("https://www.timlewis.com/communities/zinfandel-ridge/")) {
					comType = "Master Planned";
					comUrl=comUrl.replace("https", "http");
					//comStatus ="Now Selling";
				}
//				if(comUrl.contains("https://www.timlewis.com/communities/sutter-park"))comStatus="Last Chance";
				if(comUrl.contains("https://www.timlewis.com/communities/reflections/")) {
					
					dpropType = "1 Story, 2 Story";//img
				}
				
				String notes = U.getnote(html + homeHtml);
				U.log("property notes--> " + notes);
				add[0] = add[0].replace("2101 Marston Dr Woodland CA 95776\" target=\"_blank\">", "");
				
				if(comUrl.contains("https://www.timlewis.com/communities/kingsbury-estates/")) {
					propType += ", Craftsman Style Homes, Farmhouse Style Homes"; //from img 23 may 2022 dattaraj
				}
				
				if(comUrl.contains("http://www.timlewis.com/communities/zinfandel-ridge/")) comStatus = "Phase 3 Now Selling"; //from img 23 may 2022 dattaraj
//				if(comUrl.contains("https://www.timlewis.com/communities/sutter-park")) comStatus = "Last Chance";
			   
				//----------------------------------------------------------------------------------	
				
				data.addCommunity(comName, comUrl, comType);
				data.addAddress(add[0].replace("Lyonia Dr", "Lyonia Drive"), add[1], add[2], add[3]);
				data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
				data.addPrice(minPrice, maxPrice);
				data.addSquareFeet(minSqf, maxSqf);
				data.addPropertyType(propType, dpropType);
				data.addPropertyStatus(comStatus);
				data.addNotes(note);
				data.addUnitCount(units);
				data.addConstructionInformation(startDt, endDt);

			}
			i++;
		}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK; String restonData = ALLOW_BLANK; 
		int totalCount = 0; int countPath = 0; int countPoly = 0;
		
		if(html.contains("View the Community Map") && html.contains("<a href=\"https://salesarchitect") ||
				html.contains("View the Community Map") && html.contains("<a href=\"http://salesarchitect")) {
			
			frameUrl = U.getSectionValue(html, "<a href=\"https://salesarchitect", "\"");
			
			if(frameUrl==null && comUrl.contains("/communities/whitney-ranch")) {
				
				frameUrl = U.getSectionValue(html, "<a href=\"http://salesarchitect", "\"");
				frameUrl = "http://salesarchitect" + frameUrl;
			}
			else if(frameUrl==null && comUrl.contains("/communities/bridle-gate/")) {
				
				frameUrl = U.getSectionValue(html, "<a href=\"http://salesarchitect", "\"");
				frameUrl = "http://salesarchitect" + frameUrl;
			}
			else {
				frameUrl = "https://salesarchitect" + frameUrl;
			}
				
			//if(comUrl.contains("/communities/bridle-gate")) frameUrl = "http://salesarchitect.exsquared.com/SiteOverview?siteID=1242&partnerID=29";
			
			U.log("frameUrl: "+frameUrl); //&& frameUrl.contains("null")
			
			if(frameUrl.contains("salesarchitect")) {
				
				mapData = U.getHtml(frameUrl, driver);
				U.log(U.getCache(frameUrl));
				
				if(mapData.contains("<path id=\"Lot_")) {
					
					ArrayList<String> path = Util.matchAll(mapData, "<path id=\"Lot_", 0);
					U.log("path: "+path.size());
					countPath = path.size();
				}
				
				if(mapData.contains("<polygon id=\"Lot_")) {
					
					ArrayList<String> polygons = Util.matchAll(mapData, "<polygon id=\"Lot_", 0);
					U.log("polygons: "+polygons.size());
					countPoly = polygons.size();
					
				}
				int plus = countPath + countPoly;
				U.log("plus: "+plus);
				
				totalUnits = String.valueOf(plus);
				U.log("totalUnits: "+totalUnits);
			}
		}
		
		return totalUnits;
	}
	
}
