/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_181_200;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTurnberryHomes extends AbstractScrapper{
	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	public ExtractTurnberryHomes() throws Exception {
		super("Turnberry Homes", "https://turnberryhomes.com/");
		LOGGER = new CommunityLogger("Turnberry Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractTurnberryHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Turnberry Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);
	}
	

	@Override
	protected void innerProcess() throws Exception {
		

		String mainHtml = U.getHTML("https://turnberryhomes.com/communities");

	
		String[] commurls = U.getValues(mainHtml, "https://turnberryhomes.com/community/", "\"");
		U.log("communitySection:>  " + commurls.length);
		String []section=U.getValues(mainHtml, "<h6 class=\"community__name\">", "</div>");
		for (int i=0;i<commurls.length;i++) {
			String comUrl = "https://turnberryhomes.com/community/"+commurls[i];
		//	
			addDetails(comUrl,section[i]);
	
		}
	
		LOGGER.DisposeLogger();

	}
	
	
	public void addDetails(String comurl,String section) throws Exception {
//	if(j >= 5)
	{
		U.log("=================="+j);
//			if(!comurl.contains("https://turnberryhomes.com/community/allens-green/"))return;

		//U.log(comurl);
		//returned this comm bcz data is not proper
//		if(comurl.contains("https://turnberryhomes.com/community/a-build-on-your-lot-turnberry-home/"))return;
		
		String html=U.getHTML(comurl);
		LOGGER.AddCommunityUrl(comurl);
		String commname=U.getSectionValue(html, "<h1 class=\"community-hero__heading scf\">", "</h1>");
		
		
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String latlong[]= {ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		String minPrice=ALLOW_BLANK;
		String maxPrice=ALLOW_BLANK;
		String minsqft=ALLOW_BLANK;
		String maxsqft=ALLOW_BLANK;
		
		String sec1=U.getSectionValue(html, "\"footer-contact\"", "footer-top__social");
		
		String addsec="start"+U.getSectionValue(sec1,"<p>", "</p>");
		addsec=addsec+"end";
		
		U.log(addsec);
		if(addsec!=null) {
		add[0]=U.getSectionValue(addsec, "start", "<br>");
		add[1]=U.getSectionValue(addsec , "<br>", ",");
		add[2]=U.getSectionValue(addsec , ",", "end");
		}
		
		latlong[0]=U.getSectionValue(html, "data-lat=\"", "\"");
		latlong[1]=U.getSectionValue(html, "data-lng=\"", "\"");
		
		//latlong=U.getlatlongGoogleApi(add);
		if(latlong!=null) {
		add=U.getAddressGoogleApi(latlong);
		geo="TRUE";
		}
		U.log(Arrays.toString(latlong));
		
		
		U.log(Arrays.toString(add));
		
		////////==================available home section
		String availurl="https://turnberryhomes.com/available-homes/";
		
		String availhtml=U.getHTML(availurl);
		String availhomessec="";
		String availsection[]=U.getValues(availhtml, "<a class=\"cta theme-button\" href=\"https://turnberryhomes.com/property/", "\"");
		
		for(String availhomes:availsection) {
			String aviurl="https://turnberryhomes.com/property/"+availhomes;
			String avail1html=U.getHTML(aviurl);
			
			
			String acomsec=U.getSectionValue(avail1html, "<div class=\"property-1__left-desc\">", "<div class=\"agent-contact\">");
			
			String comnamesec=U.getSectionValue(acomsec, "<h5 class=\"spf\">", "</h5>");
			if(comnamesec.contains(commname)) {
				
				availhomessec+=acomsec;
			}
			
			
		}
		//U.log(availhomessec);
		////////////floorplanssec
		String floorurl="https://turnberryhomes.com/floor-plans/";
		String floorhtml=U.getHTML(floorurl);
		String floorcommsection="";
		
		String floorsection[]=U.getValues(floorhtml, "<a href=\"https://turnberryhomes.com/home-plan", "\"");
	//	U.log(floorsection.length);
		for(String fu:floorsection) {
			String furl="https://turnberryhomes.com/home-plan"+fu;
		String fhtml=U.getHTML(furl);
		
		String fplancomsec[]=U.getValues(fhtml, "href=\"https://turnberryhomes.com/property", "\"");

		for(String fsec:fplancomsec) {
			String furl1="https://turnberryhomes.com/property"+fsec;
			String f1html=U.getHTML(furl1);
			String sec2=U.getSectionValue(f1html, "<h2 class=\"property-1__heading secf\">", "<h6 class=\"agent-contact__heading secf\">");
			String commnamefloo=U.getSectionValue(sec2, "<h5 class=\"spf\">", "</h5>");
			if(sec2.contains(commname)) {
				//U.log("hello");
				floorcommsection+=sec2;
			}
					
		}
		}
		
		section=section.replace("0's", "0,000");
		
		//U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}128,564[\\w\\s\\W]{30}", 0));
		String prices[]=U.getPrices(section+availhomessec+floorcommsection, "\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\d{3},\\d{3}|- \\d{1},\\d{3},\\d{3}", 0);
		
		
		minPrice=prices[0];
		maxPrice=prices[1];
		U.log(Arrays.toString(prices));
		String sqft[]=U.getSqareFeet(availhomessec+floorcommsection, "<p>\\d{1},?\\d{3} Square Feet</p>|<p>\\d{1},\\d{3}</p>", 0);
		
		minsqft=sqft[0];
		maxsqft=sqft[1];
		U.log(Arrays.toString(sqft));
		String comtype=U.getCommType(html.replaceAll("Green Community Feed\"", ""));
		
		

		String ptype=U.getPropType(html.replace("Nashville Luxury Homes Available</a>", "").replace("home builders for luxury homes - luxury home", "").replaceAll("alt=\"Luxury Homes|alt=\"Luxury Home Builders|Luxury Homes Available</a></li>", ""));
		String dtype=U.getdCommType(html);
//		String remove=U.getSectionValue(html, "slick-list draggable", "next-arrow slick-arrow");
		if(!comurl.contains("/community/split-log/"))html=html.replaceAll("Brentwood</p>\\s*<p>Coming Fall 2022</p>", "");
		html=html.replaceAll("<p>SOLD OUT</p>|<p>Coming Soon</p>", "");
	//	U.log("mmmmmm"+Util.matchAll(html+section, "[\\w\\s\\W]{30}sold out[\\w\\s\\W]{30}", 0));
	//.log("mmmmmm"+Util.matchAll(html+section, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));
		if(!comurl.contains("https://turnberryhomes.com/community/allens-green/")) {
//			U.log(comurl);
			html=html.replace("HOME LEFT", "");
		}
		String pstatus=U.getPropStatus(html.replace("<h4>$TBD - Coming Soon</h4>", ""));
//		U.log("mmmmmm"+Util.matchAll(html+section, "[\\w\\s\\W]{70}coming soon[\\w\\s\\W]{60}", 0));

		if (maxPrice == null) {
			maxPrice = ALLOW_BLANK;
		}
		if (maxsqft == null)
			maxsqft = ALLOW_BLANK;
		if (minPrice == null) {
			minPrice = ALLOW_BLANK;
		}
		if (minsqft == null)
			minsqft = ALLOW_BLANK;

		if (comtype == null)
			comtype = ALLOW_BLANK;
		
//		String note=ALLOW_BLANK;
//		note=U.getnote(html.replace("Pre-Selling June of 2022", "Pre-Selling June 2022"));
//		U.log("note==="+note);
		
//		U.log("mmm: "+Util.match( html, "[\\w\\s\\W]{100}Pre-Selling[\\w\\s\\W]{100}"));
		html=html.replace("Pre-Selling June of 2022", "Pre-Selling June 2022");
		html=U.removeSectionValue(html, "<head>", "</head>");
		//if(comurl.contains("https://turnberryhomes.com/community/allens-green/"))ptype += ", Custom Home"; 
		data.addCommunity(commname, comurl, comtype);
		data.addAddress(add[0].replaceAll("Off Site Sales Center|,", "").replace("** ", ""), add[1].trim(), add[2], add[3]);
		data.addLatitudeLongitude(latlong[0], latlong[1], geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minsqft, maxsqft);
		data.addNotes(U.getnote(html));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
		
	}
		j++;
		
	}
	
}