package com.shatam.b_201_220;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDornHomes extends AbstractScrapper {
	
	public ArrayList<String> setofcomm = new ArrayList<String>();
	CommunityLogger LOGGER;
	static int j = 0;
	String base_Url = "https://www.dornhomes.com";
	static int i;
    WebDriver driver = null;
    
    HashSet<String> commurl = new HashSet<>();
    HashSet<String> regionurl = new HashSet<>();
    
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractDornHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Dorn Homes.csv", a.data().printAll());
	}

	public static String homeurl = "https://www.dornhomes.com";

	public ExtractDornHomes() throws Exception {
		super("Dorn Homes", homeurl);
		LOGGER = new CommunityLogger("Dorn Homes");
	}

	int a = 0;

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String html = U.getHTML("https://www.dornhomes.com/find-your-home");
		
		
		String urlsection=U.getSectionValue(html, "\" data-auto=\"page-text-style\">Find Your Home<span class=\"icon icon-angle-down\">", "<a href=\"/find-your-home/quick-move-in-homes\" class=\"unifiedna"); //"<a href=\"/find-a-home/dorn-homes-at-tubac/\"");
	//	U.log(urlsection);
		
		
		String regSectionUrls[]=U.getValues(urlsection, "data-depth=\"2\"> <a href", "</span>");
	
			for(String comSec : regSectionUrls){
//				U.log(comSec);
				String Url=U.getSectionValue(comSec, "=\"", "\"");
				String comName=U.getSectionValue(comSec, "data-auto=\"page-text-style\">", "<span class");
				if(comName.contains(" - ")) {
					comName=U.getSectionValue(comSec, "data-auto=\"page-text-style\">", " - ");
				}
//				U.log("ComName :: "+comName);
				if(!Url.startsWith("http")) Url = homeurl+Url;
				commurl.add(Url);
				if(!Url.startsWith("http"))continue;		
//				U.log("ComURl :: "+Url);
				commDetails(Url, ALLOW_BLANK, comName);
			
		}
		
	
	LOGGER.DisposeLogger();
//		try{driver.quit();}catch (Exception e) {}

	}

	public void commDetails(String commUrl, String comSec, String commName) throws Exception {
//
//	try{

//		 if(!commUrl.contains("http://www.dornhomes.com/community-details/Madera-Estates-178092"))return;
//		 if(!commUrl.contains("https://www.dornhomes.com/find-a-home/wickenburgaz/estates-at-wickenburg-ranch/"))return;
//		if(j>=6)
		{

		//	U.log("COMSEC: "+comSec);
			
//			if(commUrl.contains("https://www.dornhomes.com/find-a-home/wickenburgaz/dorn-homes-at-wickenburg-ranch/")) {
//				LOGGER.AddCommunityUrl(commUrl);
//				return;
			
			U.log(j + " COMMUNITY URL ======" + commUrl);
			
			if(commUrl.contains("http://hillsideaz.com"))commUrl="https://hillsideaz.com";
			
			commUrl=commUrl.replace("http://www.sedonaranchaz.com","https://www.sedonaranchaz.com");
			String html1 = "";
			
//			if(commUrl.contains("pinnacle-views-at-prescott-lakes")) {
				 html1=U.getHtml(commUrl, driver);
//			}
//			e1

				 String removeSec=U.getSectionValue(html1, ">Find Your Home<span class=\"icon icon-angle-down\">", "928-442-1111</span>");
					if(removeSec!=null) {
						html1=html1.replace(removeSec, "");
					}
					
			String mHtml=html1;
			// removing find your homes section
			html1 = U.removeSectionValue(html1, "<nav", "</nav");
			if (data.communityUrlExists(commUrl)) {
				LOGGER.AddCommunityUrl(commUrl + "---------------------------------repeat");
				return;
			}
//			
//			if(commUrl.contains("http://hillsideaz.com")) {
//				return;/// coming soon
//			}
//		
			LOGGER.AddCommunityUrl(commUrl);
 
			// ============= Community Name ==================
		
			if(commName!=null) {
				commName=commName.replace("&#8211; On the Banks of Oak Creek", "");				
			}
			
			U.log("hhhhhh>"+commName);

			// ===================== Address ========================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec=U.getHtmlSection(html1, "<a href=\"https://www.google.com/maps/place/", "</div>");
//			U.log(addSec);
			if(addSec==null)addSec = U.getSectionValue(html1, "<div class=\"communityAddress \">", "</div>");
		//	U.log("addSec1 : " + addSec);
			// =============== LatLng =========================
						String flag = "False";
						String note = ALLOW_BLANK;
						String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
						
						
			
			
			//U.log("addSec : " + addSec);
			if (addSec != null) {
				addSec=U.getSectionValue(addSec, "<span class=\"address-text\">", "</a>");
//				U.log(addSec);
				if(addSec!=null){
					addSec=addSec.replace("<span class=\"address-text city-state-info\">", "").replace("</span>", "").trim();
					add=U.getAddress(addSec);
				}
			}

			if (addSec == null) {
				addSec = U.getSectionValue(html1, "Home Available for Purchase</span></h2>", "<br></span></p></div>");//<span style="display: unset; font-weight: bold;">
			}
			if(addSec!=null && add[0]==ALLOW_BLANK) {
				String[] addValues=U.getValues(addSec, "<span style=\"display: unset; font-weight: bold;\">", "</span></p>");
				for(String address:addValues) {
					if(!address.contains("S.F.")&& !address.contains("$")&& add[0]==ALLOW_BLANK && add[3]==ALLOW_BLANK) {
						add=U.getAddress(address);
						latlng=U.getlatlongGoogleApi(add);
						flag="True";
					}
				}
			}
			
			if (addSec == null) {
				addSec = U.getSectionValue(html1, "<div class=\"column collapse\">\n" + 
						"                        <p></p><p class=\"small\">", "|");
				U.log(addSec);
				if(addSec!=null && add[0]==ALLOW_BLANK) {
							add=U.getAddress(addSec);
							latlng=U.getlatlongGoogleApi(add);
							flag="True";
					
				}
			}
			
			U.log("Add : " + Arrays.toString(add));

			
			String LLSec = U.getSectionValue(html1, "<a href=\"https://www.google.com/maps/place/", "\"");
			if(LLSec!=null) {
				String[] latlong=LLSec.split(",");
				latlng[0]=latlong[0];
				latlng[1]=latlong[1];
				
			}
			
			if(add[0]==ALLOW_BLANK && latlng[0]==ALLOW_BLANK && add[3]==ALLOW_BLANK) {
				String[] addressSec = { ALLOW_BLANK, "Prescott Valley's", "AZ", ALLOW_BLANK };
				U.log(Arrays.toString(addressSec));
				latlng=U.getGoogleLatLngWithKey(addressSec);
				add=U.getAddressGoogleApi(latlng);
				note="Address & LatLong taken from City and State";
				flag="True";
			}
			
			 String allplandata="";

			 String priceforSedonaRanch=ALLOW_BLANK;
			 String availhtml ="",floor="";
			 if(commUrl.contains("sedonaranchaz")) {
			  availhtml = U.getHTML("https://sedonaranchaz.com/houses-for-sale/");
			  floor = U.getHTML("https://sedonaranchaz.com/floorplans/");
			  String homesites = U.getHTML("https://sedonaranchaz.com/homesites/");
			  priceforSedonaRanch = availhtml+ floor+homesites;
			 }
//			 U.log(Arrays.toString(U.getPrices((priceforSedonaRanch), "\\$\\d,\\d{3},\\d{3}", 0)));
			// ========== Price =====================
			String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
			html1 = html1.replaceAll("0s|0's", "0,000");
			String[] reomveSec=U.getValues(html1, "<script", "</script>");
			for(String re:reomveSec) {
				html1=html1.replace(re, "");
			}
			prices = U.getPrices((html1+priceforSedonaRanch), "\\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+", 0);
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			U.log("Prices :: "+Arrays.toString(prices));
			 U.log("MATCH ALL: "+Util.matchAll(html1+priceforSedonaRanch, "[\\s\\w\\W]{80}\\$100,00[\\s\\w\\W]{80}", 0));
			 U.log("MATCH ALL: "+Util.matchAll(html1+priceforSedonaRanch, "[\\s\\w\\W]{80}\\$1,000,00[\\s\\w\\W]{80}", 0));

			// =========== Sqft =====================
			String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
			sqft = U.getSqareFeet(html1+allplandata+priceforSedonaRanch,
					"\\d{3,4} SQ FT|\\d,\\d{3} S.F.|\\d,\\d{3} to \\d,\\d{3} square feet| \\d,\\d+ square feet|\\d,\\d+ Square feet|\\d{4}SqFt|\\d,\\d{3} - \\d,\\d{3} SF|SQUARE FEET: \\d,\\d{3} - \\d,\\d{3}|SQUARE FEET: \\d,\\d{3}", 0);
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			// ======== Community Type ====================
			String commType = ALLOW_BLANK;

			String rem = U.getSectionValue(html1, "Find a Home</a>", " style=\"background:");

			html1 = html1.replaceAll("Craftsman", "craftsmen style homes");
			html1 = html1.replaceAll(" American Farmhouse", "The Farmhouse").replace("Tubac - Coming Soon", "");
			
			String[] removeSecd=U.getValues(html1, "<script", "</script>");
			for(String re:removeSecd) {
				html1=html1.replace(re, "");
			}
			
			commType = U.getCommunityType((U.getNoHtml(html1).replace("Tubac Golf Resort", "") + commName).replaceAll("Tubac Golf Resort</a>", ""));
			U.log("com Type :: "+commType);
//			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll( html1 + commName, "[\\s\\w\\W]{50}gated[\\s\\w\\W]{50}", 0));
//			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll( html1 + commName, "[\\s\\w\\W]{50}resort[\\s\\w\\W]{50}", 0));
//			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll( html1 + commName, "[\\s\\w\\W]{50}master[\\s\\w\\W]{50}", 0));

			// ============== Property Type =====================

			String quickMoveInSec = U.getSectionValue(html1, "Quick-Move In Homes</h3>",	"<div class=\"directionsSection\"");
			if(quickMoveInSec == null) quickMoveInSec = U.getSectionValue(html1, "Quick Move-In Homes</h2>",	"<div id=\"defaultSearchLoadingInfo");
			U.log(quickMoveInSec);
			int quickMoveInHome = 0;
			if (quickMoveInSec != null) {
				String[] quickUrlSection = U.getValues(quickMoveInSec, "<h3 class=", "</h3>");
				U.log("Quick Home =" + quickUrlSection.length);
				quickMoveInHome = quickUrlSection.length;
			}
			String desc = U.getSectionValue(html1, "<p class=\"communityDescription\">",
					"class=\"amenityWrapper communities\">");
			html1 = html1.replaceAll("\\d\\d homesites|\\w{3} homesites", "");
			
			//U.log(comSec);
//			comSec=comSec.replaceAll("alt=\"Grand Opening of|closeout.png|tipCloseout", "");
			html1 = html1.replaceAll("plan is temporarily sold", "")
					.replaceAll(";\">opening \\d{4}</span>", "opening 2022");
			
			html1=html1.replace("Hidden Hills - Coming Soon", "")
					.replace("Morningstar - Coming Soon", "")
					.replaceAll("Homes coming late 2021", "")
					.replace(" Hillside - Coming Soon", "")
					.replace("unset;\">Coming Soon</span>", "")
					.replace("Pricing Coming Soon</span>", "")
					.replace("Coming Soon<span class=\"icon", "");
			
			String pStatus =ALLOW_BLANK;
			pStatus=U.getPropStatus((comSec + desc +html1).replace("homes are now available to purchase", ""));
//			U.log(html1);
			U.log("status :: " + pStatus);
//			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll( html1, "[\\s\\w\\W]{50}now ava[\\s\\w\\W]{50}", 0));

//			U.log("MATCH ALL: "+Util.matchAll(comSec, "[\\s\\w\\W]{50}QUICK MOVE-IN HOMES[\\s\\w\\W]{50}", 0));
//			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll(desc + html1, "[\\s\\w\\W]{50}QUICK MOVE-IN HOMES[\\s\\w\\W]{50}", 0));
			
			pStatus = pStatus.replace(", Under Construction", "");
			
			if(pStatus.contains("Limited Homesites Remaining"))
				pStatus = "Limited Homesites Remaining";
			if(pStatus.contains("Quick Move-in Homes"))
				pStatus = pStatus.replace(", Quick Move-in Homes", "").replace("Quick Move-in Homes", "");
//			if(pStatus.contains("Coming Soon,"))
//				pStatus = pStatus.replace("Coming Soon,", "Coming Soon");
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott-valley/ridgeline/")) pStatus = pStatus.replace("Coming Soon", ALLOW_BLANK);
			
			
			//pStatus=pStatus.replaceAll(", Coming In 2022|Coming In 2022, ", "");
			
			
			// ============== Property Type =====================

			String allPlanData = getPlanData(html1);
//			U.log(Util.matchAll(comSec + html1, "[\\w\\s\\W]{30}farmhouse[\\W\\s\\w]{30}", 0));
			if(commUrl.contains("https://www.sedonaranchaz.com")){
				allPlanData = U.getHTML("https://sedonaranchaz.com/houses-for-sale/");
			}
			html1 = html1.replace("The Villas</a> – old", " Villas Homes – old")
					.replace("Farmhouse and Country Estates architecture", "Farmhouse style and Country Estates homes architecture")
					.replace("craftsmen leave", "Craftsman style");

			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(allPlanData + html1+priceforSedonaRanch,"[\\s\\w\\W]{50}Farmhouse[\\s\\w\\W]{30}", 0));	
			String propType = U.getPropType(((allPlanData + html1+priceforSedonaRanch)
					.replaceAll("Sedona home courtyard|%20Modern%20Farmhouse%20Elevation|Sonoma Modern Farmhouse Elevation| Modern Farmhouse Elevation |The Villas|the-villas|luxurious bathroom|alt=\"Community with Low HOA", "")));

			if((commUrl.contains("Estates")||commName.contains("Estates"))&& !propType.contains("Estates")) {
				U.log("yes");
				if(propType.length()>2) {
					
						propType+=", Estate-Style Homes";
					
				}else
					propType="Estate-Style Homes";
			}
			
			U.log("PropType:::::" + propType);

			// =========== Derived Community Type ====================
			// fetching plan data

			String[] detailUrks = U.getValues(html1, "<a class=\"viewDetails\" href=\"", "\"");
			String detilHtml = "";
			for (String details : detailUrks) {
				detilHtml = detilHtml + U.getHTML("http://www.dornhomes.com/" + details);
				detilHtml = detilHtml.replace("Pronghorn Ranch</a>", "");
			}
			String dType = U.getdCommType((html1 + detilHtml + allPlanData+allplandata+priceforSedonaRanch)
					.replaceAll("wickenburg-ranch|sedonaranchaz|active-branch|Outlat at Wickenburg Ranch</a>|-ranch| Ranch</a>|RANCH|rAnch|Ranch Rd|Ranch to inquire|rAnch", ""));
			U.log("dtype :: " + dType);

			
//			 U.log("MATCH ALLDD: "+Util.matchAll(html1 + detilHtml + allPlanData+allplandata+priceforSedonaRanch, "[\\s\\w\\W]{50}ranch[\\s\\w\\W]{50}", 0));

			
			//============= Quick HOmes =====================
			//https://www.dornhomes.com/find-a-home/move-in-ready-homes-prescott/
//			String quickHtml = U.getHTML("https://www.dornhomes.com/find-a-home/move-in-ready-homes-prescott/");
//			String[] quickSec = U.getValues(quickHtml, "<div class=\"frame\">", "View Details");
//			
//			int m =0;
//			for(String quickData : quickSec) {
//				U.log(quickData.toLowerCase().contains(commName.toLowerCase()));
//				if(quickData.toLowerCase().contains(commName.toLowerCase()) && (!quickHtml.contains("New Homes Under Construction")))
//				{
//					if(!pStatus.contains("Move")) {
//						
//						if(pStatus.length()<3)
//							pStatus = "Quick Move-In Homes";
//						else if(pStatus.length()>3) pStatus += ", Quick Move-In Homes";
//						 
//					}
//				}
//			}
			
//			if(m>0)
//				if(!pStatus.contains("Move")) {
//					
//					if(pStatus.length()<3)
//						pStatus = "Quick Move-In Homes";
//					else if(pStatus.length()>3)
//						pStatus += ", Quick Move-In Homes";
//				}
			
			// ================= Notes =================

			if (commName == null) {
				commName = U.getSectionValue(html1, "pageTitle\">", "</h1>");
			}

			if (add[2] == ALLOW_BLANK) {
				add[2] = "AZ";
				add[1] = "Prescott";
			}
			add[0] = add[0].toLowerCase();
			add[0] = add[0].replaceAll("suite 200|,", "");
  
//		//	U.log(commName);
//			if(commUrl.contains("https://prescott.dornhomes.com/westwood"))
//				commName="Westwood";
//			
//			
//	if(commUrl.contains("www.sedonaranchaz.com")) {
//					
//					//, Sedona, AZ 
//					
//			commName="Sedona Ranch";
//			commType ="Gated Community";
//			//pStatus=ALLOW_BLANK;
////			sqft[0]="2418";
////			sqft[1]="5258";
////			prices[0]="$2,900,000";
////		prices[1]=ALLOW_BLANK;
//					
//	}
//if(commUrl.contains("find-a-home/wickenburgaz/outlaw-at-wickenburg-ranch")) {
//	add[0]="3440 Maverick Dr ";
//	
//	
//}	
			if(commName.contains("Tubac"))commName="Tubac";
			
			int qCount=0;
			String QData=U.getHtml("https://www.dornhomes.com/find-your-home/quick-move-in-homes", driver);
			String qUrlSec=U.getSectionValue(QData, "Quick Move-Ins</span></h3> ", "<div class=\"dmFooterContainer\"> <div id=\"fcontainer\" class=\"u_fcontainer");
			String[] urls=U.getValues(qUrlSec, "<div><div class=\"card_like_container\">", "View Details");
			for(String url:urls) {
				url=U.getSectionValue(url, "class=\"card_title\"><a href=\"", "\"");
				U.log(url);
				String qData=U.getHtml("https://www.dornhomes.com"+url, driver);
				String[] nameSec=U.getValues(qData, "<div class=\"api-text-container\" data-comm-id=\"\"> <div class=\"api-spans-container \">", "</span>");
				for(String namSe:nameSec) {
					if(namSe!=null && namSe.contains(commName)) {
						qCount++;
					}					
				}
			}
			
			if(commName.contains("Tubac"))commName="Tubac Golf Resort";
			
			U.log("qcOu t :: "+qCount);
if(commUrl.contains("find-a-home/dorn-homes-at-tubac/"))
	commName="Tubac";


if(commUrl.contains("https://prescott.dornhomes.com/westwood")) {
	pStatus=pStatus.replace(", Quick Move-in Homes", "");
	commName="Westwood At Deep Well Ranch";
}

if(commUrl.contains("/find-a-home/dorn-homes-at-tubac/"))
	pStatus=pStatus.replace(", Grand Opening", "").replace("Temporarily Sold Out, Closeout, Sold Out", "Temporarily Sold Out, Closeout");
			if(commName!=null) 
				commName = commName.replace("Golf Resort|golf resort|Coming Soon", "");
			
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott/westwood")) propType+=", Craftsman Style Homes";
            if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott/westwood/")) propType+=", Farmhouse Style Homes";//image
            if(commUrl.contains("sedonaranchaz.com")){prices[0]="$2,995,000"; prices[1]=ALLOW_BLANK; }
			if(commName.length()>1000)commName = U.getSectionValue(html1, "<title>", "</title>");
			commName = commName.replace("Hillside Coming Soon", "Hillside").replace(" VIP List", "");
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott-valley/ridgeline"))pStatus=ALLOW_BLANK;
			if(commUrl.contains("https://www.dornhomes.com/find-a-home/prescott/saddlewood/"))pStatus="Temporarily Sold Out, Closeout";
			
			if(commUrl.contains("https://prescott.dornhomes.com/madera-estates"))pStatus="Coming Soon";
			if(commUrl.contains("/hillside-coming-soon"))pStatus = pStatus+", Opening 2022";
			//loturl
//			https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community=Westwood&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D
			String updatedName ="";
			if(commUrl.contains("estates-at-wickenburg-ranch/")) {
				updatedName = "Wickenburg Ranch";
			}
			else if(commUrl.contains("/tubac/tubac/")){
				updatedName ="Tubac Golf Resort";
			}else {
				updatedName = commName;
			}
//			String lotMapHtml = U.getHTML("https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community="+updatedName+"&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D");
//			
//			U.log("lot url== "+ "https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community="+updatedName+"&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D");
//			U.getCache("https://dornhomes.lotvue.com/map_section?project=Marketing&product=Marketing&community="+updatedName+"&phase=&parcel=&menu_name=Sales+View&menu_option_name=Sales+Status&filter=&comm_type=single&building_name=&floor_number=&lot_id=&legend_keys=%5B%5D");
			
			
			//ju
			String lotIds="";
			String lotId=ALLOW_BLANK;
			if(mHtml.contains("https://americansouthernhomes.lotvue.com")) {
			
			String lotMapHtml = U.getHtml("https://americansouthernhomes.lotvue.com/marketing/"+updatedName,driver);
			U.log(">>>>>>>>>>>>>>"+U.getCache("https://americansouthernhomes.lotvue.com/marketing/"+updatedName));
			
			String[] lotData=U.getValues(lotMapHtml, "<span class=\"legend_text \"", "</div>");
			int lot=0;
			int totallots=0;
			for(String ltData:lotData) {
//				U.log(ltData);
				ltData=U.getNoHtml(ltData);
//				U.log("==="+ltData);
				String lots=Util.match(ltData, "\\(\\s*\\d+\\s*\\)").trim();
				lot=Integer.parseInt(Util.match(lots, "\\d+").trim());
				totallots=totallots+lot;
				U.log("lot Count "+lots);
			}
		
			U.log("total lots= "+totallots);
			
			lotId=Integer.toString(totallots);
//			U.log("lotId= "+lotId);
			    if(lotId.equals("0"))lotId=ALLOW_BLANK;
			}
			
//			if(lotMapHtml!=null)
//			lotIds = Util.matchAll(lotMapHtml, " var svg_lot ", 0).size()>0?Util.matchAll(lotMapHtml, " var svg_lot ", 0).size()+"":ALLOW_BLANK;
//			if(lotIds.length()<1)lotIds=ALLOW_BLANK;
			
			if(latlng[0]==null) {
				latlng[0]=ALLOW_BLANK;
				latlng[1]=ALLOW_BLANK;
			}
			if(qCount>0) {
				if(pStatus.length()>2) {
						pStatus+=", Quick Move-In Homes";
					}
				else
					pStatus="Quick Move-In Homes";
			}
		
			U.log("property :: "+pStatus);
			if(pStatus.length()==0) {
				pStatus=ALLOW_BLANK;
			}
			
			data.addCommunity(commName, commUrl, commType);
			data.addPrice(prices[0], prices[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1], flag);
			data.addUnitCount(lotId);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//	}catch(Exception e){}
	}

//Method not called
	public String getPlanData(String cHtml) throws IOException {

		String allPlanData = ALLOW_BLANK;

		String[] planUrls = U.getValues(cHtml, "<a class=\"image-box\" href=\"", "\"");

		for (String planUrl : planUrls) {
			planUrl = "https://www.dornhomes.com" + planUrl;
			U.log("planUrl:::" + planUrl);
			String planHtml = U.getHTML(planUrl);
			allPlanData = U.getSectionValue(planHtml, "homeDetailBox", "amenityWrapper")
					+ U.getSectionValue(planHtml, " <h3>Plan Amenities &amp; Living Areas</h3>", "</div>")
					+ allPlanData;
			allPlanData = allPlanData.replace(" split floor plan ", "split floor-plan");
		}

		return allPlanData;

	}
//Method not called
	public void getCommDetails(String comUrl) throws Exception {
		{
			comUrl = comUrl.replace("http://www.sedonaranchaz.com", "https://sedonaranchaz.com");
			U.log(j + "======" + comUrl);

			String html1 = U.getHTML(comUrl);
			// removing find your homes section
			html1 = U.removeSectionValue(html1, "<nav", "</nav");
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			// ============= Community Name ==================
			String commName = ALLOW_BLANK;
			commName = U.getSectionValue(html1, "<title>", "</title>").replace("&#8211; On the Banks of Oak Creek", "").replaceAll("Sedona Arizona Luxury Homes for Sale \\|", "");
			U.log("Community Name :" + commName);
			// ===================== Address ========================
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String addSec = U.getSectionValue(html1, "<span class=\"fadd\">Sedona Ranch <br>", "</span>");
			//U.log("addSec : " + addSec);
			if (addSec != null) {
				addSec = addSec.replaceAll("<br>", ",");
				add = U.getAddress(addSec);
				add[0] = add[0].trim();
				add[1] = add[1].replace(",", "");
				add[0] = add[0].trim();
				add[2] = add[2].trim();
				add[3] = add[3].trim();
			}
			U.log("Add : " + Arrays.toString(add));

			// =============== LatLng =========================
			String flag = ALLOW_BLANK;
			String note = ALLOW_BLANK;
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String contactUrl = U.getSectionValue(html1, "<h2>Schedule Your Tour Of Sedona Ranch</h2>", "Contact Us");
			//U.log(contactUrl);
			if (contactUrl != null) {
				String contactHtml = U.getHTML(U.getSectionValue(contactUrl, "<a href=\"", "\""));
				String LLSec = U.getSectionValue(contactHtml, "https://www.google.com/maps/dir//", "/@");
				if (LLSec != null) {
				//	U.log(LLSec);
					latlng = LLSec.split(",");
				}
			}
//			if (comUrl.contains("https://sedonaranchaz.com")) {
//				add[0] = "12 Lagos Court";
//				add[1] = "Sedona";
//				add[2] = "AZ";
//				add[3] = "86351";
//				latlng[0] ="34.8179444";
//				latlng[1] ="-111.814754";
//
//			}
			
			U.log("LatLng = " + Arrays.toString(latlng));

			//===========Available Home ============
			
			String availHtml = U.getHtml("https://sedonaranchaz.com/sedona-arizona-luxury-homes-for-sale/available-homes/", driver);
			String[] availSec = U.getValues(availHtml, "<a id=\"slider-", "View Details");
			
			String aAvilData = "";
			for(String aSec : availSec) {
				aSec = aSec.replace("href=\"#popmake", "");
				String aUrl = U.getSectionValue(aSec, "href=\"", "\"");
				U.log("Avail Url: "+aUrl);
				if(!aUrl.contains("#pop"))
				aAvilData += U.getHTML(aUrl)+aSec;
			}
			
			
			// ========== Price =====================
			String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
			html1 = html1.replaceAll("0s|0's", "0,000").replace("0K", "0,000");
			prices = U.getPrices(html1+aAvilData, "\\$\\d,\\d{3},\\d{3}|\\$\\d+,\\d+", 0);
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			U.log("Prices :: "+Arrays.toString(prices));
			// =========== Sqft =====================
			String homeHtml1  = U.getHtml("https://sedonaranchaz.com/sedona-arizona-luxury-homes-for-sale/", driver);
			String homeHtmlSec = U.getSectionValue(html1, "<h2>Our <br> Models</h2>", "</ul");
			String homeHtml = ALLOW_BLANK;
			if (homeHtml1 != null) {
				String homeSites[] = U.getValues(homeHtml1, "gem-button-container gem-button-position-inline", "View Home Plan");
				for (String modelHome : homeSites) {
					String hUrl = U.getSectionValue(modelHome, "href=\"", "\"");
					U.log("Home Url: "+hUrl);
					//U.log(modelHome);
					homeHtml += U.getHTML(hUrl);
				}
			}
			String AvailHome=U.getHTML("https://sedonaranchaz.com/sedona-arizona-luxury-homes-for-sale/available-homes/");
			
			String[] sqft = { ALLOW_BLANK, ALLOW_BLANK };
			sqft = U.getSqareFeet(html1 + homeHtml+ aAvilData, " \\d,\\d{3} </rs|approximately \\d,\\d{3} square feet|\\d{4} Sq. Ft.", 0);
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			
			
			// ======== Community Type ====================
			String commType = ALLOW_BLANK;
			commType = U.getCommunityType((html1 + commName).replaceAll("Golf Resort</a>|Tubac Golf Resort</a>", ""));
			U.log("commType: "+commType);

			// ============== Property Type =====================

			String desc = U.getSectionValue(html1, "<p class=\"communityDescription\">",
					"class=\"amenityWrapper communities\">");
			html1 = html1.replace("north of our sold out ", "north of our");
			String pStatus = U.getPropStatus((desc + html1)+comUrl.replace("coming-soon", "coming soon"));
			U.log("status! :: " + pStatus);
			
//			U.log("MATCH ALL STAUS:  ====== "+Util.matchAll(desc + html1, "[\\s\\w\\W]{30}coming soon[\\s\\w\\W]{30}", 0));

			
			if(availHtml.contains("")) {
				if(pStatus.length()>2) {
					if (pStatus.contains("Quick Move")) {
						pStatus+=", Quick Move-In Homes";
					}
				}else
					pStatus="Quick Move-In Homes";
			}
			// ============== Property Type =====================

			String propType = U.getPropType(homeHtml + html1+aAvilData);
			
			if((comUrl.contains("Estates")||commName.contains("Estates"))&& !propType.contains("Estates")) {
				U.log("yes");
				if(propType.length()>2) {
					
						propType+=", Estate-Style Homes";
					
				}else
					propType="Estate-Style Homes";
			}
			
			U.log("PropType:::::" + propType);

			// =========== Derived Community Type ====================
			homeHtml = homeHtml.replaceAll("split-living floorplan", "split floor-plan");
			String dType = U.getdCommType((html1 + homeHtml+aAvilData));
			U.log("dtype :: " + dType);

			// ================= Notes =================
  
			note = U.getnote(html1);
			if(comUrl.contains("https://www.dornhomes.com/find-a-home/prescott/saddlewood/"))pStatus="Temporarily Sold Out, Closeout";
			if(comUrl.contains("https://prescott.dornhomes.com/madera-estates"))pStatus="Coming Soon";
			if(latlng[0]==null) {
				latlng[0]=ALLOW_BLANK;
				latlng[1]=ALLOW_BLANK;
			}
			data.addCommunity(commName, comUrl, commType);
			data.addPrice(prices[0], prices[1]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0], latlng[1], flag);

		}

	}
}