/*
 * Name:   Rakesh Chaudhari
 * Date: 28 Jun 2015
 */

package com.shatam.b_201_220;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

import au.com.bytecode.opencsv.CSVWriter;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
//import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractGraniteRidgeBuilders extends AbstractScrapper {
	static int duplicates = 0;
	static int k=0;
	public int inr = 0;
	static int counter=0;
	FileWriter writer;// = new FileWriter("D:" + "/graniteRidge.csv");
	CSVWriter csvWriter;// = new CSVWriter(writer);
	CommunityLogger LOGGER;
	static int kount=0;
	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new ExtractGraniteRidgeBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Granite Ridge Builders.csv", a.data()
				.printAll());
		U.log(duplicates);
	}

	public ExtractGraniteRidgeBuilders() throws Exception {

		super("Granite Ridge Builders", "http://www.graniteridgebuilders.com");
		LOGGER = new CommunityLogger("Granite Ridge Builders");
	}

	@Override
	protected void innerProcess() throws Exception {
		//createCsvWriterStreetConfigFile();
		WebDriver fx = new FirefoxDriver();
		for (int i = 1; i <= 19; i++) {
			String url = "http://www.graniteridgebuilders.com/shop/communities#&&searchData=&page="
					+ i;
			//U.log(i + "===region==" + url);
			String html = getHtml(url, fx);
			String communityInfo[] = U.getValues(html,
					"<div class=\"details\">", "<div class=\"summary\">");
			int totalComm = communityInfo.length / 2;
			for (int k = 0; k < communityInfo.length; k++) {
				String name = U.getSectionValue(communityInfo[k], "<h3>",
						"</h3>");
				String comUrl = U.getSectionValue(communityInfo[k],
						"<a href=\"", "\"");
				//U.log("Sucess"+name+"==="+comUrl);
				addDetails(communityInfo[k], fx); 
				// break;
				// inr++;
				// i++;
			}

			// break;
		}
		// U.log("Community Count: " + inr++);
		// U.log("Duplicates Count: " + duplicates);
		
		fx.quit();
		LOGGER.DisposeLogger();
		
		
	}

	

	int j = 0;

	static String commUrl = ALLOW_BLANK;

	public static String[] getBuilderObj(List<String> newCsvRow) {

		if (commUrl.contains(newCsvRow.get(1).trim())) {

			return new String[] { newCsvRow.get(2), newCsvRow.get(3),
					newCsvRow.get(4),newCsvRow.get(5),newCsvRow.get(6),newCsvRow.get(7),newCsvRow.get(8), newCsvRow.get(13) };
		}
		return null;

	}

	public static String[] getHardcodedAddress(String builderName, String comUrl)
			throws Exception {
		commUrl = comUrl;
		String newFile = "D:/shatam-7/Harcoded Builders/"
				+ "Hardcode_GraniteRidgeBuilders" + ".csv";
		//U.log("=============");
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {

				String aaa[] = getBuilderObj(newCsvRow);
			//	U.log(aaa[5]);
				if (aaa != null)
					return aaa;
			}
			count++;
		}

		newFileReader.close();
		return null;
	}

	private void addDetails(String urlsec, WebDriver fx) throws Exception {
		//if(k==98)
		{
			
		String urlSec = urlsec;
		U.log("urlSec::"+urlSec);

	 	String commName = U.getSectionValue(urlSec, "\">", "</a>");
		String commUrl = U.getSectionValue(urlSec, "<a href=\"", "\"");
		U.log("Community Name " + commName);
		
		
		
		String commhtml = U.getHTML("http://www.graniteridgebuilders.com/shop/"	+ commUrl);
		U.log("Comm Url: " +"http://www.graniteridgebuilders.com/shop/"+commUrl);
		
		//U.log(commhtml);
		
		if(commhtml==null){
			counter++;
			LOGGER.AddCommunityUrl("return::"+commUrl);
			return;
		}
		
		//============= Price  =================
		String minprice = ALLOW_BLANK, maxprice = ALLOW_BLANK;
		commhtml=commhtml.replace("0's","0,000");
		String price[] = U.getPrices(commhtml ,
				"\\$\\d{3},\\d{3}|Start in the \\$\\d+,\\d{3}", 0);

		minprice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxprice = (price[1] == null) ? ALLOW_BLANK : price[1];

		//======================= Sqft =========================
		String minSqf = ALLOW_BLANK, maxsqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(commhtml,"\\d,\\d+ sq ft|\\d{4} sq ft|\\d,\\d+ Square Feet|\\d{3} sq ft", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxsqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxsqf);
		
		//================ Property Status ===================
		commhtml = commhtml.replaceAll("pool house is coming soon|Shoaff", "");
		commhtml=commhtml.replace("lots still available", "lots available");
		commhtml=commhtml.replace("Phase IV is now open", "Phase IV now open");
		commhtml=commhtml.replace("Home sites are limited", "Home sites limited");
				//.replace("home sites are still available", "homesites are available");
		commhtml=commhtml.replace("Lots are selling quickly", "Lots selling quickly");

		String status = U.getPropStatus(commhtml);
		//U.log(commhtml);
		//============== Property Type ===============
		commhtml=commhtml.replace("Custom Home Builder","").replace("homes are custom built", "custom home designs");
		String html=commhtml;
		commhtml=U.getNoHtml(commhtml);
				
		String ptype = U.getPropType(commhtml);

		//============ Derived Community Type ===================
		String dType = U.getdCommType(commhtml);

		//============= Address =====================
		String addsec = U.getSectionValue(html, "Community Address","</tr>");
		if(addsec != null)
			addsec = addsec.replace("Rd Plymouth", "Rd, Plymouth").replaceAll(":|</td>|<td>", "");
		U.log("addsec::"+addsec);
	
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		if(addsec==null)
		{
			addsec=ALLOW_BLANK;
		}
		String[] add = addsec.split(",");
		U.log("add length::"+add.length);
		if(add.length==3){
			street=add[0];
			city=add[1];
			zip = Util.match(add[2], "\\d+").trim();
			state=Util.match(add[2], "\\w+").trim();
		}
		U.log("Add:="+street+"=="+city+"=="+state+"=="+zip);
		
		if (add.length==2) {
			city = add[0].substring(add[0].indexOf("<td>") + 4);
			add[1] = add[1].replaceAll("</td>", "");
			zip=Util.match(add[1], "\\d+");
			state = add[1].replaceAll("\\d+", "").trim();
			U.log("Hello"+state+"Hello");
			if(state.length()>3)state = USStates.abbr(state);
		}
		
		U.log("ADDES::" +street +"=="+city + "===" + state + "===" + zip);
		if (city == ALLOW_BLANK){
			city = ALLOW_BLANK;
			state = ALLOW_BLANK;
			zip = ALLOW_BLANK;
		}


		if (city == ALLOW_BLANK || zip == ALLOW_BLANK) {

			String addrs = U.getSectionValue(urlSec, "Location: </strong>",	"</div>");
			U.log("addrs::"+addrs);
			if(addrs!=null){
				String[] addrss = addrs.split(",");
				if (addrss.length == 2) {
					city = addrss[0].trim();
					state = addrss[1].replaceAll("\\d+", "").trim();
					zip = Util.match(addrss[1], "\\d+");
				} else {
					state = addrss[0].replaceAll("\\d+", "").trim();
					try {
						zip = Util.match(addrss[0], "\\d+").trim();
					} catch (Exception e) {
						zip = ALLOW_BLANK;
					}
				}
			}
		}
		if(city.contains("North side of Illinois")){
			city=ALLOW_BLANK;
			state=ALLOW_BLANK;
			zip=ALLOW_BLANK;
		}
		if (state.length() > 2) {
			city = state;
			state = ALLOW_BLANK;
		}

		if (state.length() < 2)
			state = ALLOW_BLANK;

		if (city == ALLOW_BLANK)
			city = "Fort Wayne";
		
		if (state == ALLOW_BLANK)
			state = "IN";

		commUrl = "http://www.graniteridgebuilders.com/shop/" + commUrl;


		commhtml = U.getHTML(commUrl);

		String streeName = street;

		
		if (zip == null) {
			zip = ALLOW_BLANK;
		}
		streeName = streeName.replaceAll(
						";<span style=\"line-height: 1.5;\">\"Wakarusa Business Center\" sign.</span><br />| Look for a <span style=\"line-height: 1.5;\">\"Wakarusa Business Center\" sign.","");
		if (streeName.length() < 2)
			streeName = ALLOW_BLANK;
		if (streeName.contains("<span style=\"font-size: 9px;\">")) {
			streeName = ALLOW_BLANK;
		}

		String noteVar = ALLOW_BLANK;

		if (streeName.length() > 75)
			streeName = ALLOW_BLANK;

		//================ LatLng ====================
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = "False";
		String latLngSec = U.getSectionValue(commhtml, "https://www.google.com/maps/", "\"");
		if(latLngSec != null){
			latLngSec = U.getSectionValue(latLngSec, "@","/");
			if(latLngSec != null){
				String[] latLng = latLngSec.split(",");
				lat = latLng[0];
				lng = latLng[1];
			}
		}
		U.log(commName);
	
		U.log(streeName);
		U.log("Geo "+geo);
		if (streeName == ALLOW_BLANK && lat == ALLOW_BLANK) {
		
			U.log(data.getBuilderName());
			String addrs[] = getHardcodedAddress(data.getBuilderName(), commUrl);
			if(addrs!=null){
				U.log("-------------->"+addrs.length+addrs[0] + " " + addrs[1]);
				U.log(add.length);
				// if (add.length >= 4) {
				streeName = addrs[0];
				city=addrs[1];
				state=addrs[2];
				zip=addrs[3];
				lat=addrs[4];
				lng=addrs[5];
				geo=addrs[6];
				
				noteVar = addrs[7];
				if (streeName.length() == 0) {
					streeName = ALLOW_BLANK;
				}
	
				String latLng[] = U.getBingLatLong(addrs);
				lat = latLng[0];
				lng = latLng[1];
				geo = "TRUE";
			}
		}
		

		// Getting lat/lng from address... i.e Geocodeing Process
		if (lat == ALLOW_BLANK && city != ALLOW_BLANK) {

			String latLng[] = U.getBingLatLong(new String[] { streeName,
					city, state, zip });
			lat = latLng[0];
			lng = latLng[1];
			geo = "TRUE";

		}
		if (lat == null && city != ALLOW_BLANK) {
			U.log("kkkkk");
			U.log(streeName+" "+city+" "+state+" "+zip);
			String latLng[] = U.getlatlongGoogleApi(new String[] { streeName,		city, state, zip });
			lat = latLng[0];
			lng = latLng[1];
			geo = "TRUE";

		}
		U.log(geo);
		
		U.log("Lat: " + lat + "Lng: " + lng);
	if(streeName==ALLOW_BLANK)
	{
		String[] lati={lat,lng};
		add=U.getAddressGoogleApi(lati);
		streeName=add[0];
		city=add[1];
		state=add[2];
	//	zip=add[3];
		geo ="True";
	}
	if(zip==ALLOW_BLANK)
	{
		String[] lati={lat,lng};
		zip=U.getAddressGoogleApi(lati)[3];
		geo ="True";
	}
	if(lng.length()<4 && city != ALLOW_BLANK)
	{
		U.log("hello");
		U.log(streeName+" "+city+" "+state+" "+zip);
		String latLng[] = U.getBingLatLong(new String[] { streeName,
				city, state, zip });
		latLng[1]=latLng[1].replace("-85","-85.0043182");
		lat = latLng[0];
		lng = latLng[1];
		geo = "TRUE";
	}
	
	if(this.data.communityUrlExists(commUrl))
	{
		kount++;
		LOGGER.AddCommunityUrl(commUrl+"@@@@@@@@@@@@@@@@reapeated@@@@@@@@@@");
		return;
	}
	if(noteVar!=ALLOW_BLANK) noteVar =ALLOW_BLANK;
	
	if(commUrl.contains("http://www.graniteridgebuilders.com/shop/communities/detail/autumn-blaze")){
		lat="40.2346277";
		lng="-85.669533";
		streeName="104 Sunburst Cir";
		noteVar=ALLOW_BLANK;
		
	}
	
		LOGGER.AddCommunityUrl(commUrl);
		status=status.replaceAll("Phase Iv Is Now Open With 17 Lots Available","Phase IV Is Now Open,17 Lots Available");
		status=status.replace("Phase Iv Now Open", "Phase IV now open");
		commhtml = commhtml.replaceAll("Ranch Road", "");
		if(commName.endsWith("Villas"))commName=commName.replace("Villas", "");
		U.log(commName+":::::");
		if(commUrl.contains("http://www.graniteridgebuilders.com/shop/communities/detail/the-estuary-at-twin-eagles")){
			minprice="$39,900";
		}
		commhtml=commhtml.replace("1-1/2- story"," 1.5 Story ");
		commhtml = commhtml.replace("Valley&nbsp;Golf Clubs", "Valley Golf Course");
		//U.log(commhtml);
		if(commUrl.contains("http://www.graniteridgebuilders.com/shop/communities/detail/timber-ridge"))noteVar = "Lat/Long And Street Address Taken Using City And States";
		
		data.addCommunity(commName, commUrl, U.getCommType(commhtml));

		data.addAddress(streeName, city, state, zip);
		data.addSquareFeet(minSqf, maxsqf);
		data.addPrice(minprice, maxprice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
		data.addPropertyType(ptype, U.getdCommType(commhtml.replaceAll("1 ½ or 2 Story|1 &frac12; or 2 Story", " 1.5 story , 2 Story")));
		data.addPropertyStatus(status);
		data.addNotes(noteVar);

	}k++;
	
	}
	
	private void createCsvWriterStreetConfigFile() throws IOException {

		String remoteDir = System.getProperty("user.dir");

		if (writer == null) {
			writer = new FileWriter("c:/cache" + "/graniteRidge.csv");
			csvWriter = new CSVWriter(writer);
		}
		csvWriter.writeNext(new String[] { "CommName", "URL", "StreetName",
				"City", "State", "Zip" });

	}

	private String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;

		File folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);
		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);

		if (!f.exists()) {
			BufferedWriter writer = new BufferedWriter(new FileWriter(f));

			driver.get(url);
			Thread.sleep(5 * 1000);
			U.log("Current URL:::" + driver.getCurrentUrl());
			html = driver.getPageSource();
			Thread.sleep(5 * 1000);

			writer.append(html);
			writer.close();

		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}

		return html;

	}
}
