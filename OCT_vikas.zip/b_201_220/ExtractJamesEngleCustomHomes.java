/** @author Parag Humane
 *  @date 29/05/2013 
 */

package com.shatam.b_201_220;

import java.io.IOException;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractJamesEngleCustomHomes extends AbstractScrapper {
	int k = 0;
	static int dup=0;
	public int inr = 0;
	static int j=0;
	CommunityLogger LOGGER;
	static int i;
	static String dupUrl="";
	static WebDriver driver =null;
	public static void main(String[] ar) throws Exception {
		AbstractScrapper a = new ExtractJamesEngleCustomHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"James Engle Custom Homes.csv", a.data()
				.printAll());
		U.log(dupUrl);
	}

	public ExtractJamesEngleCustomHomes() throws Exception {

		super("James Engle Custom Homes",
				"https://jamesengle.com/");
		LOGGER = new CommunityLogger("James Engle Custom Homes");

	}

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver =new ChromeDriver();

		
		String html = U.getHTML("https://jamesengle.com/communities/");
		html =html.replaceAll("</div>\\s*</div>\\s*</div>", "endSec");
		String[] communitiesUrl = U.getValues(html,
				"<div class=\"card\">", "endSec");
//		LOGGER.AddCommunityUrl(communitiesUrl);
		
		int totalComm = communitiesUrl.length / 2;
		U.log(communitiesUrl.length);
		for (String link : communitiesUrl) {
			String comUrl =U.getSectionValue(link, "<a href=\"", "\"");
			// if(inr==0||inr==totalComm||inr==totalComm+1||inr==communitiesUrl.length-1)
//			addDetails("http://www.jamesengle.com/subdivisions/SubDivisionDetails.aspx?subdivisionID="
//					+ link);
//			try {
				addDetails(comUrl);
//			} catch (Exception e) {}
			
			k++;
			inr++;
			
		}//LOGGER.countOfCommunity(i);
		 i++;
		 LOGGER.DisposeLogger();
		 try{driver.quit();}catch(Exception e) {}
		// U.log(dupUrl+"hello duplicate");
	}

	//TODO :
	private void addDetails(String url) throws Exception {
//		if(j>=21)
		{
//		if(!url.contains("https://jamesengle.com/communities/wilshire-by-the-lake/"))return;
		
		if (data.communityUrlExists(url)){
			dup++;	
			dupUrl=url;
			LOGGER.AddCommunityUrl("repeated *****************************************"+url);
			return;
		}
		LOGGER.AddCommunityUrl(url);

		U.log("count : "+j+"\nPAGE :" + url); 
		String html = U.getHtml(url,driver);
		U.log(U.getCache(url));	
		// ======================CommName===========================
		
		String commName = U.getSectionValue(html, "<h2>", "<");
		U.log("Comname:::::::::::::"+commName);
		
		//=========================Address=========================
		
		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
				ALLOW_BLANK };
		html=html.replaceAll("<h2>"+commName+"</h2>", "");
		String geo="FALSE";
	
		String newAddreSec = U.getSectionValue(html, "h2>", "</h2>");
		if(newAddreSec!=null)
		{
			U.log(newAddreSec);
			newAddreSec =newAddreSec.replaceAll(" , Lenexa", " Lenexa");
			String[] addr = newAddreSec.split(",");
			add[0] = addr[0].replace("<h2>", "");
			add[1] = addr[1];
			add[2] = Util.match(addr[2], "\\w+");
			add[3] = Util.match(addr[2], "\\d{5}");
//			geo="FALSE";
		}
		if(add[0].trim().contains(add[1].trim())) {
			add[0]=ALLOW_BLANK;
		}
		
		
		    if(add[0].contains("179th St east of Switzer")||add[0].contains("Woodland and College")||add[0].contains("West side of 173rd &amp; Quivira")||add[0].contains("175th &amp; Pflumm")||add[0].contains("143rd &amp; Bluejacket")||add[0].contains("159th &amp; Melrose")||
				add[0].contains("159th Street between Quivira and Switzer")||add[0].contains("159th &amp; Quivira")||add[0].contains("171st &amp; Switzer")||add[0].contains("95th &amp; Lone Elm")||add[0].contains("143rd &amp; Pflumm")|add[0].contains("167th &amp; Hayes")){
		     geo="TRUE";
		    }
		
		
		
		add[0]=add[0].replace("159th Street between Quivira and Switzer", "159th Street And Quivira Rd").replace("167th &amp; Hayes", "167th St & Hayes Street").replace("143rd &amp; Pflumm", "W 143rd St & Pflumm Rd").replace("95th &amp; Lone Elm", "Lone Elm Rd & W 95th St").replace("171st &amp; Switzer", "S Switzer Rd & 171st St").replace("159th &amp; Quivira", "159th St & Quivira Rd").replace("159th &amp; Melrose", "159th St & Melrose St").replace("143rd &amp; Bluejacket", "Bluejacket St & W 143rd St").replace("175th &amp; Pflumm", "S Pflumm Rd & W 175th St").replace("West side of 173rd &amp; Quivira", "173rd St And Quivira Rd").replace("179th St east of Switzer","W 179th St And Switzer Rd").replace("Woodland and College", "Woodland St And College Blvd");
		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"+ add[3]);
	 
		
//		===========================LatLng======================================
		
		String latsec =ALLOW_BLANK;
		String latLng[]= {ALLOW_BLANK,ALLOW_BLANK};
		
		latsec = U.getSectionValue(html, "ll=", "&amp;z");
		if(latsec!=null) {
			latLng=latsec.split(",");
		}
		
		if(latsec==null|| latLng[0]==null|| latLng[0]==ALLOW_BLANK) {
			
			latLng[0]=U.getSectionValue(html, "data-lat=\"", "\"");
			latLng[1]=U.getSectionValue(html, "data-lng=\"", "\"");
		}
		U.log("LatLong::::::"+Arrays.toString(latLng));
		
		if((add[0]==ALLOW_BLANK || add[0].length()<2) && latLng[0]!=ALLOW_BLANK) {
			String add1[] = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			add[0] = add1[0];
			geo ="TRUE";
		}
		
		if(latLng[0]==ALLOW_BLANK || latLng[0]== null) {
			String latLng1[] = U.getlatlongGoogleApi(add);
			if(latLng1 == null) latLng1 = U.getlatlongHereApi(add);
			latLng = latLng1;
			geo ="TRUE";
		}
		add[0]=add[0].replace("170th Terrace Andamp; Quivira Road", "170th Terrace And Quivira Road");
		add[0]=add[0].replace("Andamp;", "And").replaceAll("&|&amp;", "And"); //&
		U.log(" Final : street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"+ add[3]);
//		if(url.contains("https://jamesengle.com/communities/wilshire-by-the-lake/"))
//			add[0] ="159th Street";
//		if(url.contains("https://jamesengle.com/communities/mills-ranch/"))
//			add[0] ="170th Terrace";
		//=============Homeforsale=======================
		
		String homesData =ALLOW_BLANK;
		String homeurl =U.getSectionValue(html, "/homes/?status=", "\"");
		if(homeurl!=null) {
			homeurl=homeurl.replaceAll("&amp;", "&");			
		}
		U.log("https://jamesengle.com/homes/?status="+homeurl);
		String homeHtml =U.getHTML("https://jamesengle.com/homes/?status="+homeurl);
		U.log(U.getCache("https://jamesengle.com/homes/?status="+homeurl));
		
		String[] hurls=U.getValues(homeHtml, "<a href=\"https://jamesengle.com/homes/", "\"");
		if(hurls!=null) {
			for(String home:hurls) {

				if(home.endsWith("/homes/"))continue;
				if(home.length()<2)continue;
				U.log("homeUrl :: https://jamesengle.com/homes/"+home);
				homesData +=U.getHTML("https://jamesengle.com/homes/"+home);
			}
		}
		
	//	U.writeMyText(homesData);
		//=======================modelHomesdata===========
		
		String modelHomesData =ALLOW_BLANK;
		String modelHtml =U.getHTML("https://jamesengle.com/models/");
		String[] modelurls=U.getValues(modelHtml, "<a href=\"https://jamesengle.com/models/", "\"");
		for(String model:modelurls) {
			modelHtml =U.getHTML("https://jamesengle.com/models/"+model);
			if(modelHtml != null) modelHtml = modelHtml.replaceAll("HighDrLeawood", "");
			if(modelHtml.contains(commName) && model.length()>3) {
				U.log("model ::"+"https://jamesengle.com/models/"+model);
				modelHomesData += U.getHTML("https://jamesengle.com/models/"+model);
			}
		}
		
		//===============Prices===============
		
		html=html.replaceAll("<option value=.*</option>", "")
				.replace("2 million", "2,000,000 million")
				.replaceAll(" premium view lots ranging in price from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|range from \\$\\d{2},\\d{3} to \\$\\d{3},\\d{3}-plus", "");
		
//		U.log(Util.matchAll("MMMM"+html + modelHomesData + homesData, "[\\w\\s\\W]{30}\\$700,000[\\w\\s\\W]{30}", 0));

//		html=html.replace(" $70’s", " $700,000");
		html=html.replace("mid $700,000's","mid $700,000").replace(" low $70’s", " low $70,000").replaceAll("0's", "0,000").replace("$1.5 million", "$1,500,000+").replace("$1M+", "\\$1,000,000+");
		//.replace("range from $99K to $250K", "range from $99,000 to $250,000")
		if(homesData!=null) {
			///homesData=homesData.replaceAll("700,000.", "");
			homesData=homesData.replace("from $1.0 million", "from $1,000,000")
					.replace("mid $700,000's", "mid $700,000").replaceAll("<option value=.*</option>", "")
					.replaceAll("from \\$(\\d)\\.(\\d) Million", "from \\$$1,$200,000 ")
					.replaceAll("starting at \\$(\\d)\\.(\\d) Million", "starting at \\$$1,$200,000 ");
			homesData=homesData
//					.replace("priced from $1,3 million", "priced from $1,300,000")
					.replace("$1.1 Million", "$1,100,000+").replace("from $1 Million", "from $1,000,000").replace("$1.2 million", "$1,200,000")
					.replace("$1.5 Million", "$1,500,000\\+").replace("starting at $1.1 million", "starting at $1,100,000 million")
					.replace("priced from $1.1 million", "priced from $1,100,000 million").replace("mid $700,000's","mid $700,000");
			homesData =U.formatMillionPrices(homesData);
			homesData = homesData
					.replace("Farmhouse front elevation", "");
			homesData=homesData
					.replace("priced from $1,3 million", "priced from $1,300,000");
		}
//		U.log(Util.matchAll("MMMM"+html , "[\\w\\s\\W]{30}\\$1.3[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll("MMMM"+modelHomesData , "[\\w\\s\\W]{30}\\$1.3[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll("MMMM"+homesData, "[\\w\\s\\W]{30}\\$1.3[\\w\\s\\W]{30}", 0));

		String maxPrice =ALLOW_BLANK,minPrice =ALLOW_BLANK;
		
		
		String prices[] = U.getPrices(html + modelHomesData + homesData, 
				"priced from \\$\\d,\\d{3},\\d{3}|from \\$\\d,\\d{3},\\d{3}|mid \\$700,000|low \\$\\d{3},\\d{3}'s|\\s*Base Price\n\\s*\\$\\d{3},\\d{3}|priced from \\$\\d,\\d{3},\\d{3} million|starting at \\$\\d,\\d{3},\\d{3} million|<h2>\\s+\\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3} to \\$\\s*\\d,\\d{3},\\d{3} million|priced from \\$\\d{2,3},\\d{3} to \\$\\d{3},\\d{3}|priced (from|starting at) \\$\\d,\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}\\+|mid-\\d{3},\\d{3} to \\d{3},\\d{3}|\\$\\d{2,3},\\d{3} to \\$\\d{3},\\d{3}|Base Price\\s*\\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</h2>|\\$\\d{3},\\d{3}\\+|priced from \\$\\d{3},\\d{3}| low \\$\\d{2,3},\\d{3}|mid \\$\\d{3},\\d{3}", 0);
//		U.log(Util.matchAll("MMMM"+html + modelHomesData + homesData, "[\\w\\s\\W]{30}\\$700,000[\\w\\s\\W]{30}", 0));
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log(minPrice+":::::::::::::"+maxPrice);
		
		//===============sqfts===============
		String maxSqft =ALLOW_BLANK,minSqft =ALLOW_BLANK;
//		
//		U.writeMyText(modelHomesData);
		String sqfts[] = U.getSqareFeet(html+modelHomesData+homesData, "rom \\d,\\d{3} square feet|\\s*\\d,\\d{3}&nbsp;ft|\\d,\\d{3}- to \\d,\\d{3}-square-foot", 0);
		U.log(Arrays.toString(sqfts));
		minSqft = (sqfts[0] == null) ? ALLOW_BLANK : sqfts[0];
		maxSqft = (sqfts[1] == null) ? ALLOW_BLANK : sqfts[1];
		U.log(minSqft+":::::::::::::"+maxSqft);
//		U.log(Util.matchAll("MMMM-- "+html, "[\\w\\s\\W]{30}5,854[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll("MMMM-- "+modelHomesData, "[\\w\\s\\W]{30}5,854[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll("MMMM-- "+homesData, "[\\w\\s\\W]{30}5,854[\\w\\s\\W]{30}", 0));
		
		//=========================comm type=============
		String Type =ALLOW_BLANK;
		html = html.replace("community features lake views", "community features lakeside Community ");
		Type=U.getCommType(html);
		//==================propertytypes=====================
		String propertyType = ALLOW_BLANK;
		html = html.replaceAll("Estates is known for spacious home sites|The Estates", "Estate homes").replace("The Manor - from", "The Manors home").replace("It has traditional 70' wide ", "Traditional exterior").replace("The Estates - from", "estate homes")
				.replace("luxury villas", "luxury villas homes");
		
//		U.log(">>>>>>>>>>>"+Util.matchAll(html,"[\\w\\W\\s]{50}patio[\\w\\W\\s]{50}",0));
//		U.log(">>>>>>>>>>>"+Util.matchAll(modelHomesData,"[\\w\\W\\s]{50}patio[\\w\\W\\s]{50}",0));
//		U.log(">>>>>>>>>>>"+Util.matchAll(homesData,"[\\w\\W\\s]{50}patio[\\w\\W\\s]{50}",0));
		
		propertyType = U.getPropType("James Engle Custom Homes "+(html+modelHomesData+homesData).replaceAll("Farmhouse-ElevBW|Farmhouse-ElevColor-1-1.jpg|Farmhouse elevation|Farmhouse front elevation|Traditional Elevation|Traditional front elevation|Jameson-Traditional-Elev|Traditional Front Porch elevation|-Elev-Traditional-|Traditional Front Porch front elevation|Covered-Patio\\.jpg|Craftsman Elevation|Elev-Craftsman-", ""));

		
		//===================dpropertytypes=============
		String dType = ALLOW_BLANK;
		html=html.replaceAll("reverse 1.5-story", "Reverse-one-half-Story").replaceAll("reverse 1.5 story|Reverse 1.5 Stories ", "Reverse-one-half-Story");
	//	U.writeMyText(modelHomesData+homesData);
	//	U.log("pp"+Util.matchAll(html+modelHomesData+homesData,"[\\w\\W\\s]{50}second-floor[\\w\\W\\s]{50}",0));
		dType = U.getdCommType((html+modelHomesData+homesData).replace("second-floor.jpg", ""));
        if(url.contains("https://jamesengle.com/communities/willows-the-preserve/")) dType="Reverse 1.5 Story";
		//============status=============
		html=html.replace("available homesites", "Homesites Available").replace("Only a few lots remain", "Only a few lots remaining")
				.replace("community with limited homesites.", "")
				.replaceAll("inviting overlook for many Homesites Available|homesites available in several of Cedar|available.  Continuing| coming late 2020|spring and homes are now available|<h4>Coming Soon</h4>| Models and Spec homes coming soon!|Model Coming|Lots are now", "");
//		U.log(Util.matchAll(html, "[\\w\\s\\W]{30}Homesites Available[\\w\\s\\W]{30}", 0));

		String status = U.getPropStatus(html);
//		if(url.contains("https://jamesengle.com/communities/mills-ranch/"))status="Now Available";
		if(url.contains("https://jamesengle.com/communities/arbor-lake/"))status="Lots Now Available In Phase 5";
		if(url.contains("https://jamesengle.com/communities/sundance-ridge-archers-landing/"))minPrice="$500,000";
      //  if(url.contains("https://jamesengle.com/communities/mills-crossing/"))maxPrice="$700,000";//ws nt getting bcz replacement of 0's by 0,00
		
		//		status = status.replace("Iii", "III").replace("Coming Late 2020, Phase III Coming Late 2020", "Phase III Coming Late 2020");
		//============notes=============
		String note =ALLOW_BLANK;
		note=U.getnote(html);
		commName = commName.replace("Chapel Hill Villas", "Chapel Hill");
		
		// ------------------ Website links and data section ------------------------
		String weburl = ALLOW_BLANK; String webdata = ALLOW_BLANK;
		
		if(html.contains("Visit Website") && html.contains("Map This Community")) {
			
			U.log("PRESENT");
			String section = U.getSectionValue(html, "Map This Community", "Visit Website");
			U.log("section: "+section);
			weburl = U.getSectionValue(section, "href=\"", "\"");
			
			if(weburl.equals("https://cedarcreek-kc.com/valley-ridge/")) {
				weburl = weburl.replace("https://cedarcreek-kc.com/valley-ridge/", "https://cedarcreek-kc.com/neighborhoods/valley-ridge/");
			}
			if(weburl.equals("https://plazaheights.com/")) {
				weburl = weburl.replace("https://plazaheights.com/", ALLOW_BLANK);
			}
			
			U.log("weburl: "+weburl);
			
			if(!(weburl.equals(ALLOW_BLANK))) {
				webdata = U.getHtml(weburl, driver);
			}
			
		}
		
		
		add[0]=add[0].replace("170th Terrace Andamp; Quivira Road", "170th Terrace And Quivira Road");
		add[0]=add[0].replace("K-7 Andamp; 119th St","K-7 And 119th St");
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(webdata, url, driver);
		U.log("Total Units : "+units);
		
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(commName.replace(" ~ ", " - "), url, Type);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(propertyType, dType);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addNotes(note);

	}j++;
}
	
	public static String getUnits(String webdata, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK; String restonData = ALLOW_BLANK; 
		int totalCount = 0;
		
		if(comUrl.contains("/communities/willows-the-preserve/")) {
			
			String mapPage = U.getHtml("https://www.thewillowskc.com/community-map.html", driver);
			String frameSec = U.getSectionValue(mapPage, "<iframe src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			if(frameUrl.contains("platwidget.com")) {
				
				mapData = U.getHtml(frameUrl, driver);
				
				if(mapData.contains("class=\"pw-lots mkr\"")) {
					
					ArrayList<String> lots = Util.matchAll(mapData, "class=\"pw-lots mkr\"", 0);
					U.log("Count Lots: "+lots.size());
					totalUnits = String.valueOf(lots.size());
				}
			}
		}
		
		if(comUrl.contains("/communities/timberstone-ridge/")) {
			
			String mapPage = U.getHtml("https://timberstoneridgeks.com/new-homes-near-me/", driver);
			String frameSec = U.getSectionValue(mapPage, "<iframe class=\"pwgt-iframe-xL5s1rWJ\" src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<circle class=\"mkr-shdw\"")) {
				
				ArrayList<String> lots = Util.matchAll(mapData, "<circle class=\"mkr-shdw\"", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/terrybrook-farms-maple-ridge/")) {
			
			String mapPage = U.getHtml("https://www.terrybrookfarms.com/copy-of-community-map", driver);
			String frameSec = U.getSectionValue(mapPage, "src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("class=\"cls-17 mkr\"")) {
				
				ArrayList<String> lots = Util.matchAll(mapData, "<path class=\"cls-17 mkr\"", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/southern-lakes/")) {
			
			
			String frameSec = U.getSectionValue(webdata, "<iframe src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("class=\"pw-lots mkr\"")) {
				
				ArrayList<String> lots = Util.matchAll(mapData, "class=\"pw-lots mkr\"", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/chapel-hill/")) {
			
			String mapPage = U.getHtml("https://www.chapelhillkc.com/community-map", driver);
			String frameSec = U.getSectionValue(mapPage, "src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<path class=\"pw-lots mkr\"")) {
				
				ArrayList<String> lots = Util.matchAll(mapData, "<path class=\"pw-lots mkr\"", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/mills-ranch/")) {
			
			String mapPage = U.getHtml("https://millsranch.net/lots-map/", driver);
				
			if(mapPage.contains("<circle id=\"lot_")) {
				
				ArrayList<String> lots = Util.matchAll(mapPage, "<circle id=\"lot_", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/mills-crossing/")) {
			
			String mapPage = U.getHtml("https://millscrossing.net/lots-map/", driver);
				
			if(mapPage.contains("<circle class=\"cls-1")) {
				
				ArrayList<String> lots = Util.matchAll(mapPage, "<circle class=\"cls-1", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/glen-eagles/")) {
			
			String mapPage = U.getHtml("https://gleneagleshomes.net/lots-map/", driver);
				
			if(mapPage.contains("<circle id=\"lot_")) {
				
				ArrayList<String> lots = Util.matchAll(mapPage, "<circle id=\"lot_", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/arbor-view/")) {
			
			String mapPage = U.getHtml("https://arborviewks.com/lot-map/", driver);
				
			if(mapPage.contains("<circle id=\"lot_")) {
				
				ArrayList<String> lots = Util.matchAll(mapPage, "<circle id=\"lot_", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/century-farms/")) {
			
			
			String frameSec = U.getSectionValue(webdata, "<iframe src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("class=\"pw-lots mkr\"")) {
				
				ArrayList<String> lots = Util.matchAll(mapData, "class=\"pw-str mkr-\\d+\"", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		
		if(comUrl.contains("/communities/timber-rock/")) {
			
			String mapPage = U.getHtml("https://timberrockks.com/community-map.html", driver);
			String frameSec = U.getSectionValue(mapPage, "<iframe src=\"https://platwidget.com", "\"");
			frameUrl = "https://platwidget.com" + frameSec;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<path class=\"pw-lots mkr\"")) {
				
				ArrayList<String> lots = Util.matchAll(mapData, "<path class=\"pw-lots mkr\"", 0);
				U.log("Count Lots: "+lots.size());
				totalUnits = String.valueOf(lots.size());
			}
		}
		
		if(comUrl.contains("/communities/cedar-creek-hidden-like-estates/")) {
			
			frameUrl = U.getSectionValue(webdata, "<iframe class=\"pwgt-iframe-xL5s1rWJ\" src=\"https://platwidget.com", "\""); 
			frameUrl = "https://platwidget.com" + frameUrl;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<path class=\"pw-lot mkr\"")) {
				
			ArrayList<String> pins = Util.matchAll(mapData, "<path class=\"pw-lot mkr\"", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());
			
			}
		}
		
		if(comUrl.contains("/communities/cedar-creek-valley-ridge/")) {
						
			frameUrl = U.getSectionValue(webdata, "<iframe class=\"pwgt-iframe-xL5s1rWJ\" src=\"https://platwidget.com", "\""); 
			frameUrl = "https://platwidget.com" + frameUrl;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<path class=\"pw-lots mkr\"")) {
				
			ArrayList<String> pins = Util.matchAll(mapData, "<path class=\"pw-lots mkr\"", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());
			
			}
		}
		
		if(comUrl.contains("/communities/cedar-ridge-reserve/")) {
			
			U.log("From Here ");
			
			frameUrl = U.getSectionValue(webdata, "<iframe src=\"https://platwidget.com", "\""); 
			frameUrl = "https://platwidget.com" + frameUrl;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<path class=\"cls")) {
				
			ArrayList<String> pins = Util.matchAll(mapData, "<path class=\"cls-\\d mkr\"", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());
			
			}
		}
		
		return totalUnits;
	}
	
	
	
	
//	private void addDetails(String url) throws Exception {
//		//if(j==8)
//		{
//
//		//if(!url.contains("http://www.jamesengle.com/subdivisions/SubDivisionDetails.aspx?subdivisionID=128"))return;
//		if (data.communityUrlExists(url)){
//			dup++;
//			dupUrl=url;
//			U.log("repeated *****************************************");
//			return;
//		}
//		
//		U.log("count : "+j+"\nPAGE :" + url);
//		String html = U.getHTML(url);
//		LOGGER.AddCommunityUrl(url);
//
//		// CommName
//		String sec = U.getSectionValue(html, "class=\"big_header\"",
//				"School District:");
//		String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK,
//				ALLOW_BLANK };
//		String commName = U.getSectionValue(html, "<h2 >", "<");
//		
//		
//		if(add[0].length()<4)
//		{
//			html =html.replace("Fairway, Fairway", "-,Fairway");
//			String newAddreSec = U.getSectionValue(html, "h2>", "</h2>");
//			String[] addr = newAddreSec.split(",");
//			add[0] = addr[0].replace("<h2>", "");
//			add[1] = addr[1];
//			add[2] = Util.match(addr[2], "\\w+");
//			add[3] = Util.match(addr[2], "\\d{5}");
//		}
//		U.log("street:" + add[0] + " City:" + add[1] + " ST:" + add[2] + " Z:"
//				+ add[3]);
//		String planHtml = ALLOW_BLANK;
////		String planLink = "http://www.jamesengle.com/homesforsale/default.aspx?dev="
////				+ U.getSectionValue(html, "/homesforsale/default.aspx?dev=",
////						"\"");
////		U.log("planLink:" + planLink);
////		String planHtml = U.getHTML(planLink);
//		///////////////////////////plan Data//////////////////////////////////////
////		String planSec=U.getSectionValue(planHtml, "View Current Inventory List", "</form>");
////		String plans[]=U.getValues(planSec, "<div class=\"well\">", "</span>");
////		for(String plan:plans){
////			U.log(plan);
////			planHtml+=U.getHTML("http://www.jamesengle.com/homesforsale/"+U.getSectionValue(plan, "<a href=\"", "\""));
////			if (planHtml.contains("the Farmhouse")) {
////				U.log("FOUND");
////			}
////		}
////		planHtml=planHtml.replaceAll("<option(.*?)</option", "");
//		// Square Feet
//		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		String[] sqft = U.getSqareFeet(planHtml+html, "\\d,\\d{3}-\\sto\\s\\d,\\d{3}-square-foot|\\d+ SqFt.|2835 SqFt|\\d+,\\d{3} square feet ", 0);
//		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
//		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//
//		// Price
//		html = U.removeSectionValue(html, "<div class=\"row text-center spacer", "uSearch$lstBedrooms");
//		planHtml = U.removeSectionValue(planHtml, "<div class=\"row text-center spacer", "uSearch$lstBedrooms");
//		planHtml=formatMillionPrices(planHtml);
//		U.log(planHtml.contains("$1,000,000"));
//		html = html.replace("$300 - $400k", "$300,000s - $400,000s").replace("$1.5 million","$1,500,000");
//		html = html.replace(" mid-400's to 650's+", "$400,000 to $650,000")
//				.replace("$1M+", "$1,000,000");
//		html = html.replace("$1.5M","$150,000");
//		html = html.replaceAll("400s|400's", "400,000");
//		html = html.replace("00,000's", "00,000").replace("low $70’s", "$70,000");
//		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		
//		String[] price = U.getPrices((html + planHtml).replaceAll("sales price has been reduced \\$\\d{2},\\d{3}|Sales price reduced \\$\\d+,\\d{3} to \\$\\d+,\\d{3}", ""),
//				"\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
//		//s\\$\\d,\\d{3},\\d+|\\$\\d{3},\\d{3} to \\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|from \\$\\d+,\\d{3} to \\$\\d+,\\d{3}|from \\$\\d+,\\d{3} to more than \\$\\d{1,},\\d+,\\d+|Price Range:&nbsp;&nbsp;</strong></td><td>\\$\\d+,\\d+ - \\$\\d+,\\d+|Price Range:&nbsp;&nbsp;</strong></td><td>\\$\\d{3},\\d{3}|\\$\\d+,\\d+<br>|\\$\\d,\\d{3},\\d{3}<br>|from the \\$\\d+,\\d+|starting at \\$\\d+,\\d+|the \\$\\d+,\\d+
//		//U.log(planHtml);
//		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
//		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//
//		String propertyType = ALLOW_BLANK;
//		//html = html.replaceAll("</script> James Engle Custom Homes|Custom Homes</title> |James Engle Custom Homes", "");
////		s
//		propertyType = U.getPropType("James Engle Custom Homes "+html.replaceAll("luxurious club house|courtyard garages|tradition of family","")+planHtml.replaceAll("he Farmhouse elevation|the Farmhouse front elevation", ""));
//		
//		// Type
//		//U.log("================"+html);
//		String Type = U.getCommunityType(html);
//		//html=html.replaceAll("reverse 1.5-story|Reverse 1.5 Stories|reverse 1.5|reverse story", "1.5 Reverse Story").replace("1½-story", " 1.5 Story ").replace("1½-story", " 1.5 Story ");
//		String dType = U.getdCommType(html+planHtml);
//
//		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;
//		
//		
//
//		if(add[0]==ALLOW_BLANK)
//		{
//			String planaddrsec=U.getSectionValue(planHtml, "arial;color:#525252;\">", "</td>");
//			if(planaddrsec!=null){
//			planaddrsec=planaddrsec.replace("&nbsp;", "").replace("</b><br>", ",");
//			
//			U.log(planaddrsec);
//			String[] asdr=planaddrsec.split(",");
//			add[0]=asdr[0].trim();
//			add[1]=asdr[1].trim();
//			add[3]=Util.match(asdr[2], "\\d{5}");
//			add[2]=Util.match(asdr[2], "\\w{2}");
//				
//			}
//		}
//		String note="";
//		if (!add[0].equals(ALLOW_BLANK)) {
//			String tempAdd[] =new String[4];
//			tempAdd=add;
//		
//			String rem="171st St &";
//			tempAdd[0]=tempAdd[0].replaceAll(rem, "").trim();
//			
//			tempAdd[0]=tempAdd[0].replace("179th St & Verona", "179 Street and Verona");
//			tempAdd[0]=tempAdd[0].replace("175th and Verona", "175 and Verona");
//			
//			String la[] = U.getlatlongGoogleApi(tempAdd);
//			lat = la[0];
//			lng = la[1];
//			geo = "true";
//		}//
//		if (!add[1].equals(ALLOW_BLANK)&&add[0].equals(ALLOW_BLANK)) {
//			String la[] = U.getlatlongGoogleApi(add);
//			lat = la[0];
//			lng = la[1];
//			add=U.getAddressGoogleApi(la);
//			note="Lat/Long And Street Address Taken Using City And States";
//			geo = "true";
//		}
//		if(add[3]==ALLOW_BLANK)
//		{
//			String[] latlng={lat,lng};
//			String[] aa=U.getAddressGoogleApi(latlng);
//			add[3]=aa[3];
//		}
//		add[0]=add[0].replace("179 Street &amp; Verona", "179th St & Verona");	
//		add[0]=add[0].replace("175 and Verona", "175th and Verona");		
//		/*if(url.contains("http://www.jamesengle.com/subdivisions/SubDivisionDetails.aspx?subdivisionID=145")){
//			String la[] = U.getBingLatLong(add);
//			lat = la[0];
//			lng = la[1];
//			geo = "true";
//		}*/
//		
//		String status = ALLOW_BLANK;
//		String statSec = U.getHTML(url);
//
//		U.log("===============================.>" + url);
//
//		String remove = "homes are now available|Hours:&nbsp;&nbsp;</strong></td><td>Coming Soon!</td></tr>|hours:&nbsp;&nbsp;</strong></td><td>coming soon</td></tr>|plat home sites are available now|Phase coming|are coming soon! </div>|Model Hours: </b> Coming Soon! |Model Hours: </b> Coming Soon </td>|website is currently UNDER CONSTRUCTION"
//				+"|for many available|available in several";
//		statSec = statSec.toLowerCase().replaceAll(remove.toLowerCase(), "");
//		status = U.getPropStatus(statSec);
//		
//		if(add[0].contains(add[1].trim()))
//		{
//			String[] latlng={lat,lng};
//			add=U.getAddressGoogleApi(latlng);
//		}
//		commName=commName.replaceAll("~", "-");
//		U.log("Property type::::"+propertyType);
//		U.log("Derived type::::"+dType);
//		U.log("Minimum square feet:::::"+minSqf);
//		
//		data.addCommunity(commName, url, Type);
//		data.addAddress(add[0], add[1], add[2], add[3]);
//		data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
//		data.addPropertyType(propertyType, dType);
//		data.addPropertyStatus(status);
//		data.addPrice(minPrice, maxPrice);
//		data.addSquareFeet(minSqf, maxSqf);
//		data.addNotes(note);
//
//	}j++;
//}
	
	//Format million price
	public static String formatMillionPrices(String html){
		html=html.replaceAll("Million|Millions", "M");
		Matcher millionPrice = Pattern.compile("\\$\\d\\.\\d+ M",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice.find()){
			U.log(millionPrice.group());
			String floorMatch = millionPrice.group().replaceAll(" M| m", "00,000").replace(".", ",");  //$1.3 M
			html	 = html.replace(millionPrice.group(), floorMatch);
			}//end millionPrice
			
		Matcher millionPrice1 = Pattern.compile("\\$\\d M",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice1.find()){
				U.log(millionPrice1.group());
				String floorMatch = millionPrice1.group().replace(" M", ",000,000");  //$1.3 M
				html	 = html.replace(millionPrice1.group(), floorMatch);
			}//end millionPrice1
		return html;
	}
}