/**
 * @modify Sawan
 * @date 22 July 2020
 * @author Chinmay
 * 28-Mar-2019
 */
package com.shatam.b_201_220;

import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractProvidanceHomes extends AbstractScrapper{
	static String builderName="Providence Homes";
	static String builderUrl="https://www.providencehomesinc.com";
	static int count=0;
	CommunityLogger LOGGER;
	public ExtractProvidanceHomes() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public static void main(String[] args) throws Exception {
		

		AbstractScrapper a = new ExtractProvidanceHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+builderName+".csv", a.data()
				.printAll());
	}
	@Override
	protected void innerProcess() throws Exception {
		U.log(U.getCache("https://providencehomesinc.com/communities"));
		String mainHtml=U.getHTML("https://providencehomesinc.com/communities");

		
//		String[] communitiesInfo = U.getValues(mainHtml, "<div class=\"CommunityCard_wrapper\" ", "Visit Community</div>");
		String[] communitiesInfo = U.getValues(mainHtml, "<div class=\"info\">", "More About This Community");

		
		U.log(communitiesInfo.length);
		for(String comSec : communitiesInfo){
			//U.log("==>>"+comSec);
//			String comUrl = U.getSectionValue(comSec, "<a class=\"CommunityCard_inner\" href=\"", "\"");
			String comUrl = U.getSectionValue(comSec, "a href=\"", "\"");

			U.log("raw comUrl: "+comUrl);
			if(!comUrl.startsWith("http")) comUrl = builderUrl + comUrl;
//			String comName = Util.match(comSec, "<h4 data-reactid=\"\\d+\">(.*?)</h4>", 1);
			String comName = U.getSectionValue(comSec, "<h2>", "</h2>");
			//U.log(comName);
			extractCommunityDetails(comUrl, comName, comSec);
		}
		LOGGER.DisposeLogger();
		
	}
	
	int j = 0;
	private void extractCommunityDetails(String commUrl, String commName, String commSecs) throws Exception {
		//TODO: For Single community execution
//		if(j ==2) 
		{
	
//		if(!commUrl.contains("https://www.providencehomesinc.com/communities/pioneer-village-at-nocatee/")) return;
		
		if(data.communityUrlExists(commUrl)){
			LOGGER.AddCommunityUrl(commUrl+"****************repeated*************");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		
		U.log((count++)+" --> "+commUrl);
		
		String commHtml=U.getHTML(commUrl);
		U.log(U.getCache(commUrl));	
		
		commHtml=U.removeComments(commHtml);
//		U.log(commSecs);
//		String rmSec = U.getSectionValue(commHtml, ">window.__PRELOADED_STATE__ = {\"", "</html");
		String rmSec = U.getSectionValue(commHtml, "script type=\"application/ld+json\">{", "</script>");


		commName= commName.replace("&amp;", "&").replace(" @ ", " At ").replace("&#x27;", "'");
		U.log(commName);
		
		
		String geo="False";
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		
		String [] latLng ={ALLOW_BLANK, ALLOW_BLANK}; 
		
		/*String latLngSec = U.getSectionValue(commHtml, "Map &amp; Directions</h3>", "View on Google Map");
		if(latLngSec != null){
			latLngSec = Util.match(latLngSec, "/@(\\d+\\.\\d+,-\\d+\\.\\d+),\\d+z", 1);
			U.log("latLngSec ::"+latLngSec);
			if(latLngSec != null){
				latLng = latLngSec.split(",");
				
			}
		}
		
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK && latLng[0] != ALLOW_BLANK){
			add = U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getAddressHereApi(latLng);
			geo = "True";
		}*/
		
		String addSec=U.getSectionValue(commHtml, "<div>Location: <span>", "</span></div>");
		add=U.getAddress(addSec);
		add[0]=add[0].replace("and 46 Settler’s Landing Drive", "");
		String latLngSec = U.getSectionValue(commHtml,"scheduleAVisitMapCenter = { ",";"); 
		latLng[0]=U.getSectionValue(latLngSec, "lat: ", ",").trim();
		latLng[1]=U.getSectionValue(latLngSec, "lng: ", "}").trim();
		
		
//		String quickHomes[]=U.getValues(commHtml, "<div class=\"HomeCard_wrapper\"", "</a></div></div>");
		                                            //<div id=\"EntityListd935019eb40a49c6ab2a5f2d694ca44a\"
		String QSec=U.getSectionValue(commHtml, "<h2>Available Homes in", "<h2>Floor Plans in ");
		String quickData=ALLOW_BLANK;
		int quickCount = 0;
		String quickHtml=ALLOW_BLANK;
		if(QSec!=null) {
		String quickHomes[]=U.getValues(QSec, "<div class=\"item\">", "Home Details</a>");//</a></div></div>

		
		U.log("Quick MoveIn Count: "+quickHomes.length);
		
		
		for (String quick : quickHomes) {
			
//			U.log("quick: "+quick);
			
			//for status below
			if(quick.contains("Available August 2022")) {
				quickCount++;
			}
			
			U.log(builderUrl+U.getSectionValue(quick, "<a href=\"", "\""));
			quickHtml=U.getHTML(builderUrl+U.getSectionValue(quick, "href=\"", "\""));
			if(rmSec!=null)
			quickHtml =quickHtml.replace(rmSec, "");
//			String desc=U.getSectionValue(quickHtml, "Description</h3>", "</ul></div></div>");
			String desc=U.getSectionValue(quickHtml, "<a href=\"#\">Description", "<a href=\"#\">School Info");

			String detail1=U.getSectionValue(quickHtml, "<ul class=\"DetailWrapper_LinksList\"", "<div class=\"DetailSection\"");
			String detail2=U.getSectionValue(quickHtml, "<div class=\"mainBodyCopy centered\">", "Contact Us About This Home</a>");
			quickData+=(quick+desc+detail1+detail2).replaceAll(" \\d bed", "");
		}
		}
		U.log("quickCount: "+quickCount);
		if(rmSec!=null)
		quickData = quickData.replace(rmSec, "");

		String combinedFloorHtml = "";
		
		String floorSection=U.getSectionValue(commHtml, "<h2>Floor Plans in ", "<div class=\"scheduleAVisitCallout mapExist\">");
//		String floorSections[] = U.getValues(commHtml, "<div class=\"PlanCard_media\"", "</a></li></ul>");
		if(floorSection!=null) {
		String floorSections[] = U.getValues(floorSection, "<div class=\"entitySummaryList\">", "</a></div></div></div>");
                                                        //st <div class=\"entityInfo\">
		
		for(String floorSec : floorSections){
			
			String floorUrl = builderUrl+U.getSectionValue(floorSec, "href=\"", "\"");
			U.log("floorUrl =="+floorUrl);
			String floorHtml=U.getHTML(floorUrl);
//			combinedFloorHtml += U.getSectionValue(floorHtml,"name=\"description\" content=\"","\"")+U.getSectionValue(floorHtml, "<ul><li>", "</ul></li>")
//			+U.getSectionValue(floorHtml, "<span class=\"DetailWrapper_priceValue\"", "name=\"description\"");
					//floorHtml;
			combinedFloorHtml+=U.getSectionValue(floorHtml, "<div class=\"mainBodyCopy centered\">", "Contact Us About This Floor Plan</a>");
			
		} 
		}
//		String descSec=U.getSectionValue(commHtml, "<div class=\"DetailWrapper_content\"", "</div></div>")
//				+U.getSectionValue(commHtml, "<div class=\"DetailSection_body\"", "</div></div>")
//				+U.getSectionValue(commHtml, "<div class=\"ScrollTarget\" id=\"plans\"", "<div class=\"PlanResults_showMoreContainer\"");
		String descSec=U.getSectionValue(commHtml,"<div class=\"communityInfo\">","<div class=\"icons\">")
		               +U.getSectionValue(commHtml,"<a href=\"#\">High Performance Features","<a href=\"#\">School Info");
		
		U.log("name\":\""+commName.replace("<!---->", "")+"\",\"description\"");
        if(rmSec!=null)
		descSec =descSec.replace(rmSec, "").replace("Priced from <!-- /react-text --><!-- react-text: 223 -->$407,940", "\">\\$407,940</div>");
		descSec =descSec.replace("<!-- /react-text --><!-- react-text: 178 --> to <!-- /react-text --><!-- react-text: 179 -->", " to ")
				.replaceAll("Starting at <!----><strong data-reactid=\"(.*?)\">", "Starting at ");
		
		descSec=descSec.replace("00s", "00,000").replace("$400-$700K", "$400,000 to $700,000").replaceAll("<!----><!---->", "");
		commSecs=commSecs.replaceAll("0’s", "0,000").replace("$400-$700K", "$400,000 to $700,000");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
	//	U.log(descSec);

		//+newdescSec
		String[] price = U.getPrices( (descSec+ quickData).replace("Reduced from $1,007,488 to $1,006,828", ""),
						"\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}</strong>|the high \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3}<|from \\$\\d{3},\\d{3}\\.\\d{2} to \\$\\d{3},\\d{3}.\\d{2}|\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|start in the high \\$\\d{3},\\d{3}|\"price\":\\d{6,7},|from \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\">\\$\\d{3},\\d{3}</div>|start from \\$\\d{3},\\d{3}",
						0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
//		U.log(Util.matchAll(descSec+ quickData, "[\\w\\s\\W]{488}[\\w\\s\\W]{30}", 0));

	//	if(commUrl.contains("https://www.providencehomesinc.com/communities/duval-county/kettering-etown"))maxPrice="$841421";
		//================= Square Feet ===============
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		U.log(homeData);

		
//		U.log(descSec);

		
		String[] sqft = U.getSqareFeet((descSec+commSecs+ quickData + StringEscapeUtils.unescapeJava(combinedFloorHtml)),
				"\\d{4} square feet|<div class=\"num\">\\d{4}</div>\n\\s*<div class=\"label\">sqft</div>|approximately \\d{4} to \\d{4} square feet|\\d,\\d{3} Sq\\. Ft|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} to \\d{4} Sq. Ft.|\"sqftHigh\":\\d{4},\"sqftLow\":\\d{4},|floor plans ranging from \\d{3},\\d to \\d,\\d{3} square feet|\"sqft\":\\d{4},|\">\\d,\\d{3}</span>",
						0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		//===============================================propType===========================================
		commSecs = StringEscapeUtils.unescapeJava(commSecs);

		descSec = descSec.replace("we are now building", "").replace("Markland Manor", "Markland Manor Home");
		//U.log(commSecs+descSec+quickData);
		String propType=U.getPropType((commSecs+descSec+quickData+combinedFloorHtml).replace("traditional code built homes", "traditional homes"));
//		U.log(Util.matchAll(commSecs+descSec, "[\\w\\s\\W]{60}traditional[\\w\\s\\W]{30}", 0));


		//===============================================dType===========================================
		commSecs=commSecs.replaceAll("-story \\d bedroom", "-story ");
//		commSecs = commSecs.replace("ranging from 2,671 to 4,200 square feet with elegant interiors", "");
		
		quickData = quickData.replaceAll("->(\\d)<!-- /react-text --><!-- react-text: \\d+ -->-Story<", "> $1 Story");
		if(quickData.contains("1<!-- /react-text --><!-- react-text: 233 -->-Story")) {
			
			U.log("jjjjjjjj");
		}
		quickData=quickData.replaceAll("1<.*?>-Story", " 1 Story ").replaceAll("2<!-- /react-text --><!-- react-text: \\d+ -->-Story", "2 Story");
		if(combinedFloorHtml!=null)
			combinedFloorHtml = combinedFloorHtml.replaceAll("\\d bedroom|level", "")
			.replaceAll("1<!-- /react-text --><!-- react-text: \\d+ -->-Story", "1 Story").replaceAll("2<!-- /react-text --><!-- react-text: \\d+ -->-Story|2<!-- /react-text --><!-- react-text: \\d+ -->-Story", "2 Story");
		quickData=U.getNoHtml(quickData);
		String dType=U.getdCommType((combinedFloorHtml+commSecs+descSec+quickData).replaceAll("2<!-- /react-text --><!-- react-text: \\d+ -->-Story|2<!-- /react-text --><!-- react-text: \\d+ -->-Story", "2 Story").replaceAll("1<!-- /react-text --><!-- react-text: \\d+ -->-Story", "1 Story").replace("3 Garages", "")); //+newdescSec
		
//		U.log(Util.matchAll(commSecs+descSec, "[\\w\\s\\W]{60}quick[\\w\\s\\W]{30}", 0));
		//===============================================status===========================================
//		commSecs=commSecs.replace("\u003c/strong>", "</strong>").replaceAll("headline\":\"Now Selling|Now Selling(<|\u003c)/strong> – The Colony at|Now Selling 100% ENERGY STAR|Now Selling\\u003c/strong> – The Colony at|Certified Quick Move-In [Homes]?|Now Selling ENERGY|\"sqftLow\":\\d{4},\"status\":\"Closeout\"|\"bd_status\":\"Closeout\",|Ask about our great selection of Quick Move-In|cstrong>NOW SELL|Models and Quick Move-In Homes|<p><strong>NOW SELLING|Chance - Only 2 ENERGY ", "");
		descSec=descSec.replace("\u003c/strong>", "</strong>").replaceAll("Presale lots are|Quick Move-In Homes|Certified Quick Move-In Homes|Certified Quick Move-In [Homes]?|Now Selling</strong> – The Colony at|Now Selling 100% ENERGY STAR|Now Selling ENERGY|Now Selling\\u003c/strong> – The Colony at|\"sqftLow\":\\d{4},\"status\":\"Closeout\"|Ask about our great selection of Quick Move-In", "");
//		commSecs = commSecs.replaceAll(">(\\d+)</span><!-- react-text: \\d+ --> Quick Move-In Homes", ">$1 Quick Move-In Homes");
		commSecs = commSecs.replaceAll("Quick Move-In Homes", "");
		
		String status=U.getPropStatus((commSecs+descSec)
				.replace("will begin selling in Summer 2022", "will begin selling Summer 2022"));
		
//		U.log(Util.matchAll(commSecs+descSec, "[\\w\\s\\W]{60}selling in Summer[\\w\\s\\W]{30}", 0));
		U.log("status: "+status);

		String commType=U.getCommunityType( descSec);
	
		//if (quickHomes.length!=0 && !status.contains("Quick Move"))
		
		if (quickCount > 0) {
			if (status != ALLOW_BLANK)
				status += ", Quick Move-in Homes";//allways take quick move in count from commhtml page not from region page
			else
				status = "Quick Move-in Homes";
		} 
		
//		U.log("---"+status);
		if(commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/markland") && !propType.contains("Manor Homes")) {
			if(propType == ALLOW_BLANK) propType = "Manor Homes";
			else if(propType != ALLOW_BLANK) propType += ", Manor Homes";
		}
		if(commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-west-end")) {
			propType="Patio Homes, Loft";
		}
			
		if(commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-pioneer-village"))
		{
			//commType="Lakefront Community";
			dType="Colonial";
		}
//		if(commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-settlers-landing")) {
//			dType="1 Story, 2 Story";
//		}
//		U.log("---"+status);
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(commName.replaceAll(" - |-", " "), commUrl, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latLng[0], latLng[1], geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote((commSecs+descSec).replace("pre-selling in February 2020", "pre-selling February 2020"))); //newdescSec
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
		}
		j++;
			
	}
	
	

}