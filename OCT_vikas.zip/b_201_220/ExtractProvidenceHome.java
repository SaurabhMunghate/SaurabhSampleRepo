package com.shatam.b_201_220;

import java.util.Arrays;
import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractProvidenceHome extends AbstractScrapper {
	static String builderName = "Providence Homes";
	static String builderUrl = "https://www.providencehomesinc.com";
	static int count = 0;
	CommunityLogger LOGGER;

	public ExtractProvidenceHome() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws Exception {
		// try {
		AbstractScrapper a = new ExtractProvidenceHome();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + builderName + ".csv", a.data().printAll());
		// } catch (Exception e) {
		// e.printStackTrace();
		// }
	}

//	@Override
//	protected void innerProcess() throws Exception{
//		// TODO Auto-generated method stub
//		String mainHtml = U.getHTML("https://providencehomesinc.com/communities");
//		String[] comSec = U.getValues(mainHtml, "<div class=\"CommunityCard_wrapper", "Visit Community");
//		U.log("Total Community: "+comSec.length);
//		
//		for(String com : comSec) {
//			
//			String comUrl = U.getSectionValue(com, "href=\"", "\"");
//			comUrl = builderUrl+comUrl;
//			
//			addDetails(comUrl,com);
//		}
//		
//
//	}
//	
//	int j = 0;
//	private void addDetails(String comUrl, String com) throws Exception {
//		// TODO Auto-generated method stub
//		
//		{
//			if(!comUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/markland"))return;
//			if(data.communityUrlExists(comUrl)) {
//				
//				LOGGER.AddCommunityUrl("=========== Repeated ============== "+comUrl);
//				return;
//			}
//			LOGGER.AddCommunityUrl(comUrl);
//			
//			
//			String comHtml = U.getHTML(comUrl);
//			
//			
//			
//			//================= ComName ==============================
//			String comName = U.getSectionValue(com, "<h4 data-reactid=\"", "<");
//			
//			if(comName == null)
//				comName = U.getSectionValue(comHtml, "\"name\":\"", "\"");
//			
//			if(comName != null)
//				comName =comName.replaceAll("\\d+\">", "");
//			U.log("ConName: "+comName);
//			
//			
//			//================= Address ==========================
//			
//			String latlong[] = { ALLOW_BLANK, ALLOW_BLANK };
//			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//			String geo = "TRUE";
//			
//			String latSec = U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "/");
//			
//			if(latSec!= null) {
//				
//				latlong = latSec.split(",");
//			}
//			U.log("Latlong: "+Arrays.toString(latlong));
//			
//			
//			if(add[0]== ALLOW_BLANK) {
//				
//				add = U.getAddressGoogleApi(latlong);
//				U.log("Google Address: "+Arrays.toString(add));
//			}
//			
//			
//			//============ Quick Move ========================
//			String[] quickSec = U.getValues(comHtml, "span class=\"HomeCard_mediaImageCallout\"", "Home Details");
//			String quickData = "";
//			
//			for(String quick : quickSec) {
//				
//				String qUrl = U.getSectionValue(quick, "href=\"", "\"");
//				if(qUrl != null)
//					qUrl = builderUrl+qUrl;
//				U.log("Quick Url: "+qUrl);
//				String qHtml = U.getHTML(qUrl);
//				
//				if(qHtml!= null) {
//					
//					quickData += U.getSectionValue(qHtml, "\"description\":\"", "\",");
//					String[] featureSec = U.getValues(qHtml, "<div class=\"DetailSection_body DetailSection_featuresList\"", "/div></div></div>");
//					
//					if(featureSec.length>0)
//						for(String feature : featureSec) {
//							
//							quickData += feature;
//						}
//					
//				}
//			}
//			
//			
//			
//			//=============== Floor Data ==========================
//			
//			String[] quickSec = U.getValues(comHtml, "span class=\"HomeCard_mediaImageCallout\"", "Home Details");
//			String quickData = "";
//			
//			for(String quick : quickSec) {
//				
//				String qUrl = U.getSectionValue(quick, "href=\"", "\"");
//				if(qUrl != null)
//					qUrl = builderUrl+qUrl;
//				U.log("Quick Url: "+qUrl);
//				String qHtml = U.getHTML(qUrl);
//				
//				if(qHtml!= null) {
//					
//					quickData += U.getSectionValue(qHtml, "\"description\":\"", "\",");
//					String[] featureSec = U.getValues(qHtml, "<div class=\"DetailSection_body DetailSection_featuresList\"", "/div></div></div>");
//					
//					if(featureSec.length>0)
//						for(String feature : featureSec) {
//							
//							quickData += feature;
//						}
//					
//				}
//			}
//			
//					
//			
//		}
//		
//	}

	@Override
	protected void innerProcess() throws Exception {
		String mainHtml = U.getHTML("https://providencehomesinc.com/communities");
		HashMap<String, String> redirectMap = new HashMap<>();
		String redirectSec = U.getSectionValue(mainHtml, "\"redirects\"", "\"webhooks\":");
		String redirects[] = U.getValues(redirectSec, "{\"from\"", "}");
		for (String redirect : redirects) {
			String key = U.getSectionValue(redirect, ":\"", "\"");
			String val = U.getSectionValue(redirect, "\"to\":\"", "\"");
//			if (key.equals("/nocatee-the-colony")) {
//				val = "/communities/st-johns-county/nocatee-the-colony";
//			} else if (key.equals("/nocatee-heritage-trace")) {
//				val = "/communities/st-johns-county/nocatee-heritage-trace-and-freedom-landing";
//			}
			// U.log(key+"\t"+val);
			redirectMap.put(key, val);
		}
		redirectMap.put("/nocatee-heritage-trace", "/communities/st-johns-county/nocatee-freedom-landing");
		redirectMap.put("/nocatee-the-colony", "/communities/st-johns-county/nocatee-the-colony");
		redirectMap.put("/nocatee-liberty-cove", "/communities/st-johns-county/nocatee-pioneer-village-and-liberty-cove");
		// String commdataSec=U.getSectionValue(mainHtml, ",\"communities\":{\"",
		// "\"unpublished\":[{\"@type\":\"GatedResidenceCommunity\"");
		String commDataSecs[] = U.getValues(mainHtml, "\"community\":{",
				"\"type\":\"community\"}");
		U.log(commDataSecs.length);
		for (String commSecs : commDataSecs) {
//			U.log("--"+U.getSectionValue(commSecs, "\"website\": \"", "\""));
//			U.log("--"+U.getSectionValue(commSecs, "\"url\":\"", "\""));
			String commUrl = builderUrl + redirectMap.get(U.getSectionValue(commSecs, "\"url\":\"", "\""));
//			U.log("--||"+commUrl);
			String commId = U.getSectionValue(commSecs, "\"_id\":\"", "\"");
			String homeDatas[] = U.getValues(mainHtml, "{\"community\":\"" + commId + "\"", "\"mod_exludesLand\":");
			if (commUrl.equals(builderUrl + "null")) {
				U.log(U.getSectionValue(commSecs, "\"url\":\"", "\""));
				commUrl = builderUrl + redirectMap.get(U.getSectionValue(commSecs, "\"sharedName\":\"", "\""));
			}
			if (commUrl.equals(builderUrl + "null")) {
				continue;
			}
			addDetails(commUrl, commSecs, homeDatas);
			// break;
		}
		addDetails("https://www.providencehomesinc.com/communities/duval-county/kettering-etown",
				"From $297,940  ,\"description\":\"Providence Homes, recognized as one of the most energy-efficient builders in America, is excited to announce the release of Zero Energy Ready Homes™  in Kettering at eTown. All homes in Kettering at eTown will feature attractive forward thinking “modern” elevations with one and two-story plans ranging from 1,500 to 2,750 square feet on 40’ & 50' home sites.\n\nKettering will be the only neighborhood at eTown offering homes with the US Department of Energy (DOE) Zero Energy Ready Home™  label, which are deemed to be so energy efficient, all or most annual energy consumption can be offset with renewable energy. The US Department of Energy (DOE) Zero Energy Ready Homes™ label also means each new home will receive the EPA’s ENERGY STAR® & Indoor Air-Plus label. All Providence Homes include an innovative conditioned attic system that provides for an even more energy efficient, healthier, greener and sustainable home. Providence Homes received the ENERGY STAR® Partner of the Year – Sustained Excellence Award – Four Years in a Row! \n\neTown is a highly anticipated smart-living community that is centrally located off State Road 9B and Interstate 295, and just 3 miles from St. Johns Town Center. eTown will feature world-class amenities, as well as both pedestrian and electric-cart friendly trails. Over 50 percent of eTown’s acreage will remain undeveloped to preserve much of the area’s long-leaf pine habitat. The 5-acre Recharge Amenity Center is scheduled to open in Summer 2020. \n\nCall to schedule your appointment today.\",\"geoIndexed\":[-81.508975,30.197317],",
				null);
		LOGGER.DisposeLogger();
	}

	private void addDetails(String commUrl, String commSecs, String[] homeDatas) throws Exception {
//		 if (!commUrl.contains("mmunities/duval-county/kettering-etown"))return;
		 
//		 U.log(commUrl);
//		if (commUrl.contains(
//				"https://www.providencehomesinc.com/communities/st-johns-county/nocatee-heritage-trace-and-freedom-landing"))
//			commUrl = "https://www.providencehomesinc.com/communities/st-johns-county/nocatee-freedom-landing-and-heritage-trace";
//
//		if (commUrl.equals(
//				"https://www.providencehomesinc.com/communities/st-johns-county/nocatee-freedom-landing-and-heritage-trace")
//				|| commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/gran-lake")
//				|| commUrl
//						.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-the-outlook")
//				|| commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/trailmark")
//				|| commUrl.contains(
//						"https://www.providencehomesinc.com/communities/duval-county/nocatee-timberland-ridge")||commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-liberty-cove")||commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-pioneer-village")) {
//
//			LOGGER.AddCommunityUrl("404 Error Return================= " + commUrl);
//			return;
//		}
//if(commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-freedom-landing"))return;
	
		if (data.communityUrlExists(commUrl)) {

			LOGGER.AddCommunityUrl("Repeated================= " + commUrl);
			return;
		}
		
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-the-colony") || commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/oxford-estates")) {

			LOGGER.AddCommunityUrl("Return================= " + commUrl);
			return;
		}

		U.log((count++) + " --> " + commUrl);
//		if(!commUrl.contains("CHINAMY"))return;
		String commHtml = U.getHTML(commUrl);
		commHtml = U.removeComments(commHtml);
		U.log(commSecs);
		String commName = U.getSectionValue(commHtml, "<h1 data-reactid=\"", "<br data").replace("&amp;", "&")
				.replaceAll("\"\\d+\">|\\d+\">|<!---->", "");
		// if (commName==null) {
		// commName=U.getSectionValue(commHtml, "<h1 data-reactid=\"", "<br
		// data").replaceAll("\"\\d+\">|162\">", "");
		// }
		U.log(commName);
		String geo = "TRUE";// Default set it as true as none of community page has address but, present in
							// page source
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		add[0] = U.getSectionValue(commSecs, "\"streetAddress\":\"", "\"");
		add[1] = U.getSectionValue(commSecs, "\"addressLocality\":\"", "\"");
		add[2] = U.getSectionValue(commSecs, "\"addressRegion\":\"", "\"");
		add[3] = U.getSectionValue(commSecs, "\"postalCode\":\"", "\"");
		U.log(Arrays.toString(add));
		String latlon[] = { ALLOW_BLANK, ALLOW_BLANK };
		latlon[0] = U.getSectionValue(commSecs, "\"com_lat\":", ",");
		latlon[1] = U.getSectionValue(commSecs, "\"com_lng\":", ",");
		if (latlon[0] == null) {
			String latlonSec = U.getSectionValue(commSecs, "\"geoIndexed\":[", "]");
			String tempLatLon[] = latlonSec.split(",");
			latlon[0] = tempLatLon[1];
			latlon[1] = tempLatLon[0];
		}
		U.log(Arrays.toString(latlon));
		if (add[0] == ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latlon);
		}
		String homeSec=U.getSectionValue(commHtml, ">Floor Plans in", "class=\"PlanResults_showMoreContainerCount\"");
		if (homeSec!=null) {
			homeDatas=U.getValues(homeSec, "class=\"PlanCard_media\"", "PlanCard_detailButton");
		}
		if (homeDatas != null)
			U.log("Home Count: " + homeDatas.length);
		String quickHomes[] = U.getValues(commHtml, "<div class=\"HomeCard_wrapper\"", "</a></div></div>");
		U.log("Quick MoveIn Count: " + quickHomes.length);
		String quickData = "";

		for (String quick : quickHomes) {
			// U.log(quick);
			String quickHtml = U.getHTML(builderUrl + U.getSectionValue(quick, "href=\"", "\""));
			String desc = U.getSectionValue(quickHtml, "Description</h3>", "</ul></div></div>");
			String detail = U.getSectionValue(quickHtml, "<ul class=\"DetailWrapper_LinksList\"",
					"<div class=\"DetailSection\"");
			quickData += (quick + desc + detail).replaceAll(" \\d bed", "");
		}

		String homeData = "";
		if (homeDatas != null) {

			for (String home : homeDatas) {
				 U.log("https://www.providencehomesinc.com"+U.getSectionValue(home, "<a class=\"\" href=\"", "\""));
				 String homeHtml=U.getHTML("https://www.providencehomesinc.com"+U.getSectionValue(home, "<a class=\"\" href=\"", "\""));
				 String desc = U.getSectionValue(homeHtml, "<div class=\"DetailWrapper_content\"", "class=\"DetailWrapper_buttonList mt-4\"");
					homeData += desc.replaceAll(" \\d bed|<!-- /react-text -->|<!-- react-text: \\d+ -->", "");
//					U.log("++++"+desc.replaceAll(" \\d bed|<!-- /react-text -->|<!-- react-text: \\d+ -->", ""));
				homeData += home.replaceAll(" \\d bed", "");
			}
		}
		String descSec = U.getSectionValue(commHtml, "<div class=\"DetailWrapper_content\"", "Directions</h3>");
//		 U.log("MMMMMMMMMMMMMMMMM "+descSec);
		descSec = descSec.replace("$400-$700K", "From $400,000-$700,000").replaceAll("<!----><!---->", "");
		commSecs = commSecs.replaceAll("0’s", "0,000").replace("$400-$700K", "From $400,000-$700,000").replaceAll("<!-- /react-text --><!-- react-text: \\d+ -->", "");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		U.log("SSSSSSSSSSSSSSS"+Util.match(commSecs, ".*200.*"));
		String[] price = U.getPrices(descSec + commSecs + homeData + quickData,
				"Priced from \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|start in the high \\d{3},\\d{3}|From \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|From  \\$\\d{3},\\d{3}|start in the high \\$\\d{3},\\d{3}|\"price\":\\d{6,7},|from \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\">\\$\\d{3},\\d{3}</div>|From \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}",
				0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
		// ================= Square Feet ===============

		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		// U.log(descSec);
		if(homeData!=null)
			homeData = homeData.replaceAll("<!-- /react-text --><!-- react-text: \\d+ --> SQ FT", " SQ FT");
		String[] sqft = U.getSqareFeet(descSec + commSecs + homeData + quickData,
				"\\d,\\d{3} SQ FT|\\d{3} SQ FT|\\d,\\d{3} to \\d,\\d{3} square feet|\"sqftHigh\":\\d{4},\"sqftLow\":\\d{4},|floor plans ranging from \\d{3},\\d to \\d,\\d{3} square feet|\"sqft\":\\d{4},|\">\\d,\\d{3}</span>",
				0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		// ===============================================propType===========================================
		String propType = U.getPropType(commSecs + descSec + homeData + quickData);
//		U.log(Util.match(quickData, ".*farmhouse home.*"));
		// ===============================================dType===========================================
		commSecs = commSecs.replaceAll("-story \\d bedroom", "-story ");
		if(homeData != null)
			homeData = homeData.replaceAll("<!-- /react-text --><!-- react-text: \\d+ -->-Story", "-Story");
		String dType = U.getdCommType(commSecs + descSec + homeData + quickData);
		 
//		 U.log("--"+descSec);
		// ===============================================status===========================================
		commSecs = commSecs.replaceAll(
				"Certified Quick Move-In [Homes]?|\"bd_status\":\"Closeout\",|Ask about our great selection of Quick Move-In|cstrong>NOW SELL",
				"");
		descSec = descSec.replaceAll("Certified Quick Move-In [Homes]?|Ask about our great selection of Quick Move-In","")
				.replace("Only 2 ENERGY STAR® Homes Remaining", "Only 2 Homes Remaining")
				;
		
		
		String status = U.getPropStatus((commSecs + descSec).replaceAll("strong>Now Selling|Now Selling 100% ENERGY|rovidence Homes is now selling|Now Selling! Providence Homes|&nbsp;is now selling our spectacular|NOW SELLING PIONEER VILLAGE at CROSSWATER|title\":\"Now Selling Pioneer|\"title\":\"Now Selling Phase 2 in Freedom Landing|title\":\"Nocatee-Providence Homes Now Selling|\"status\":\"Closeout\"", ""));
		// U.log("---"+descSec);
		String commType = U.getCommunityType((descSec + commSecs).replaceAll("Resort Pool", ""));
		
		if (quickHomes.length != 0) {
			if (status != ALLOW_BLANK)
				status = status + ", Quick Move-In Homes";// allways take quick move in count
																					// from commhtml page not from
																					// region page
			else
				status = "Quick Move-In Homes";
			
		}
//		 else {
//			if (status != ALLOW_BLANK)
//				status = status + ", No Quick Move-In Homes";
//			else
//				status = "No Quick Move-In Homes";
//		}

		if (add[0] == null) {
			add = U.getAddressGoogleApi(latlon);

		}
		
		
		
		//==========================================================================================================
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-pioneer-village")) {maxPrice = "$495,820";maxSqf = "2,747";}
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/oxford-estates"))minPrice = "$400,940";
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/markland")) {
		propType = propType.replace(", Craftsman Style Homes, Courtyard Home", "");}
		
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-pioneer-village")) {
			
			propType = propType.replace(", Craftsman Style Homes", "");
			dType = "1 Story, 2 Story";
			
		}
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-the-colony") ||
				commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-freedom-landing-and-heritage-trace")  )dType = "1 Story, 2 Story";
		if(commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-freedom-landing-and-heritage-trace")) propType = propType.replace(", Courtyard Home", "");
		if (commUrl.contains("https://www.providencehomesinc.com/communities/st-johns-county/nocatee-liberty-cove"))dType = "2 Story";	
		

		data.addCommunity(commName.replace("@", "at"), commUrl, commType);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addLatitudeLongitude(latlon[0], latlon[1], geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(status);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(commSecs + descSec));
	}
}
