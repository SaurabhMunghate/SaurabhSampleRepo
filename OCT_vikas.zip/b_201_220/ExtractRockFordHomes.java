/*
 *By Vicky Meshram
 *Dated-18-01-2017 
 */
package com.shatam.b_201_220;
import java.io.*;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.U;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.Util;

import bsh.StringUtil;

public class ExtractRockFordHomes extends AbstractScrapper {

    WebDriver driver = null;
	int j = 0;
	static String BASE_URL="https://www.rockfordhomes.net/";
	
	static String Builder_Name="Rockford Homes";
	CommunityLogger LOGGER;
	
	public ExtractRockFordHomes() throws Exception {
	
		super(Builder_Name,BASE_URL);
		LOGGER = new CommunityLogger(Builder_Name);
		
	}

	public static void main(String[] args) throws Exception {
		
		AbstractScrapper a = new ExtractRockFordHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Rockford Homes.csv",a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String mainhtml = U.getHtml("https://rockfordhomes.net/find-your-community/",driver);
		//String[] commSec = U.getValues(mainhtml,"<div class=\"grid-col dmach-grid-item \">","<!-- .et_pb_section -->");
		String[] commSec = U.getValues(mainhtml,"<div class=\"et_pb_row et_pb_gutters3\">","View Details </a>");
		U.log("commSec >>>>>>>> "+commSec.length);
		for(String community:commSec){
			
//			try {
				addDetails(community);
//			} catch (Exception e) {}
		}
		
		
		LOGGER.DisposeLogger();
		try{
			driver.quit();
			}catch (Exception e) {}
		
	}

	//TODO::
	private void addDetails(String community) throws Exception {
	//
//	if(j==0)

	{
		String cSec =U.getSectionValue(community,"<a class=\"et_pb_button\" href=\"","\">");
	
		//...COMMUNITY URL...//
		String commUrl = cSec;
		U.log(j+":::Community url:"+commUrl);
//		if(!commUrl.contains("nity/clark-shaw-moors/")) return;
//		if(commUrl.contains("https://rockfordhomes.net/find-your-community/clark-shaw-moors/")) {
//			LOGGER.AddCommunityUrl(commUrl+"===========noData=============");
//			return;			
//		}
		if(data.communityNameExists(commUrl)) {
			
			LOGGER.AddCommunityUrl(commUrl+"===========Repeated=============");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
		U.log(U.getCache(commUrl));
		String commhtml = U.getHtml(commUrl, driver);
		
		
		//...COMMUNITY NAME...//
		
		String commName =U.getSectionValue(community,"<h3 class=\"entry-title de_title_module dmach-post-title\">","<");
		U.log("Community name:"+commName);
		
		//...LATITUDE AND LONGITUDE...//
		
		String[] addr ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlong={ALLOW_BLANK,ALLOW_BLANK};
		String lat,lng;
		String geo = "False";
		String latlngSec = U.getSectionValue(commhtml,"https://www.google.com/maps/dir/","\">");
		
		U.log("latlngSec:: "+latlngSec);
		
		String latlngSec1 = null;
		if(latlngSec!=null)
			latlngSec1 = U.getSectionValue(latlngSec, "/@", "/");
		
		String latlngSec2 = null;
		if(latlngSec1==null && latlngSec!=null)
			latlngSec2 = U.getSectionValue(latlngSec, "/", "/");
		
		latlngSec = latlngSec1+latlngSec2;
		
//		U.log(latlngSec);
		lat=Util.match(latlngSec,"\\d{2}\\.\\d+",0);
		lng=Util.match(latlngSec,"\\d+.\\d+,(-\\d+.\\d+)",1);
		
		
		latlong[0] = (lat==null) ? ALLOW_BLANK : lat;
		latlong[1] = (lng==null) ? ALLOW_BLANK : lng;
        U.log("latitude:"+latlong[0]);
		U.log("longitude:"+latlong[1]);
		
		//...ADDRESS...//
		String addSec = U.getSectionValue(commhtml, "<h3>Model Home Location</h3>", "</p>");
		if(addSec != null){
			addSec = addSec.replace("<br>", ",");
//			U.log(addSec);
			addr = U.getAddress(U.getNoHtml(addSec));
			U.log(Arrays.toString(addr));
		}
		if(addSec==null) {
			addSec = U.getSectionValue(commhtml, "<td class=\"infowindow\" data-marker-listing-description=\"Description\">", "</p>");
//			U.log(">>>>>>>>. "+addSec);
			addSec = addSec.replace("<br>", ",");
//			U.log(StringEscapeUtils.unescapeJava(addSec));
			addr = U.findAddress((U.getNoHtml(addSec)));
		}
		if(addr[0] == ALLOW_BLANK && latlong[0] != ALLOW_BLANK){
			addr = U.getAddressGoogleApi(latlong);
			addr[0]=addr[0].trim();
//			addr[1]=addr[1].trim();
//			addr[2]=addr[2].trim();
//			addr[3]=addr[3].trim();
			geo = "True";
		}
		U.log("ADD::"+Arrays.toString(addr));
		
		//...MAX PRICE AND MIN PRICE...//
//		commhtml = commhtml.replace("s", ",000");
		
//		 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(commhtml, "[\\w\\s\\W]{30}530[\\w\\s\\W]{30}", 0));
		commhtml=commhtml.replace("From the $530", "From the $530,000");
		String remove = U.getSectionValue(commhtml, "view_swapped\" data-et-multi-view=", "data-et-multi-view-load-phone-hidden");
		if(remove != null) commhtml = commhtml.replace(remove, "");
		//=========== Move Plan Section ======================
		
		String commName1  = commName.replaceAll("Jerome Village,\\s+Orchid Hill", "Orchid Hill").replace("Jerome Village, Willowbrush", "Willowbrush");
		
		U.log("MoveUrl:: "+"https://rockfordhomes.net/move-in-ready/?filter=true&mir_community_for_search="+commName1.replaceAll("\\s+", "-"));
		String moveHtml = U.getHtml("https://rockfordhomes.net/move-in-ready/?filter=true&mir_community_for_search="+commName1.replaceAll("\\s+", "-"),driver);
		
		String[] moveCount = U.getValues(moveHtml,"<div class=\"et_pb_row et_pb_gutters", "View Details");
		
		U.log("Move count ::"+moveCount.length);
		
		commhtml = commhtml.replaceAll("&gt;From the \\$260s&lt", "");
		
		Pattern pat = Pattern.compile("\\$\\d{3}s",Pattern.CASE_INSENSITIVE);
		Matcher mat = pat.matcher(commhtml);
		while(mat.find()){
//			U.log(mat.group());
			String priceMatch = mat.group().replace("s", ",000");
			commhtml = commhtml.replace(mat.group(), priceMatch);
		}
		String maxPrice = ALLOW_BLANK ,minPrice = ALLOW_BLANK;
		if(moveHtml != null)
			moveHtml = moveHtml.replace("acf_prepend\">$</span>", "acf_prepend\">$");
		
		
		String[] price = U.getPrices(commhtml+moveHtml,"\\$\\d{3},\\d{3}",0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("Min Price:"+minPrice);
		U.log("Max Price:"+maxPrice);
		//...MAX SQFT AND MIN SQFT...//
		String minsqft=ALLOW_BLANK,maxsqft=ALLOW_BLANK;
		String[] sqf = U.getSqareFeet(commhtml+moveHtml,
				"Square Feet<span class=\"dmach-seperator\">: </span></span>\\d,\\d{3}|Square Feet<span class=\"dmach-seperator\">: </span></span>\\d,\\d{3}\\+</p>|Square Feet<span class=\"dmach-seperator\">: </span></span>\\d,\\d{3}</p>|Square Footage:</span> \\d,\\d{3}–\\d,\\d{3}|Square Footage:</span> \\d,\\d{3}</div>|Square Footage:</span> \\d,\\d{3}.\\d,\\d{3}", 0);

		minsqft = (sqf[0]==null) ? ALLOW_BLANK : sqf[0];
		maxsqft = (sqf[1]==null) ? ALLOW_BLANK : sqf[1];
		U.log("Mininum sqft:"+minsqft);
		U.log("Maximum sqft:"+maxsqft);
		
		//...COMMUNITY DATA...//
		String commType=ALLOW_BLANK;
		
		String dpropType=ALLOW_BLANK;
		
		String propStatus=ALLOW_BLANK;
		
		String note=ALLOW_BLANK;
		
		String propType=ALLOW_BLANK;
		
		//...COMMUNITY TYPE...//
		commType=U.getCommType(commhtml.replace("Kinsale Golf ", "Kinsale Golf courses "));
		U.log("Community type:"+commType);
		
		//=========== Floor Plan Section ======================
		String floorPlanSec = U.getSectionValue(commhtml, "<h2>Homes Available", "<h2>Contact Rockford</h2>");
		String combinedFloorHtml = null;
		if(floorPlanSec != null){
			String[] floorUrlSec = U.getValues(floorPlanSec, "<div class=\"et_pb_row et_pb_gutters", "View Details");
			for(String floorSec : floorUrlSec){
				String floorUrl = U.getSectionValue(floorSec, "<a class=\"et_pb_button\" href=\"", "\"");
			//	U.log("Floor"+floorUrl);
				//combinedFloorHtml = combinedFloorHtml + U.getHTML("https://www.rockfordhomes.net"+floorUrl);
				combinedFloorHtml = combinedFloorHtml +U.getHtml(floorUrl, driver);
/*				if (combinedFloorHtml.contains("Colonial. This hom")) {
					U.log("Fonund");
				}*/
//				U.log(floorUrl);
			}
			U.log("Floor plan ::"+floorUrlSec.length);
		}
		
		if(combinedFloorHtml != null){
			String remVals[] = U.getValues(combinedFloorHtml, "HomeAndConstructionBusiness", "geo\":");
			for(String remVal : remVals){
				combinedFloorHtml = combinedFloorHtml.replace(remVal, "");
			}
		}
		String rem = U.getSectionValue(commhtml, "HomeAndConstructionBusiness", "geo\":");
		if(rem != null) commhtml = commhtml.replace(rem, "");
		
		//...DERIVED PROPERTY TYPE...//
		if(combinedFloorHtml!=null)
		combinedFloorHtml=combinedFloorHtml.replace("second floor level"," 2 Story ")
					.replace(" loft, and", " loft homes, and").replace("First Floor Master", "1 story");

		dpropType = U.getdCommType((commhtml+combinedFloorHtml).replaceAll("- Colonial|Floor|floor|what split levels can", ""));
		
		
    	U.log("Derived community type:"+dpropType);
		
		
		//...PROPERTY STATUS...//
    	commhtml = commhtml.replaceAll("Selling Now</a>|Coming Soon</a>|\"name\":\"Coming Soon|name\":\"Selling Now", "");
    	propStatus=U.getPropStatus(commhtml.replace("Alder - American Farmhouse", "Alder - American Farmhouse-style exteriors"));
    	U.log("Property status:"+propStatus);
//    	U.log(">>>>>>>>"+Util.matchAll((commhtml),"[\\w\\W\\s]{50}Selling Now[\\w\\W\\s]{50}",0));
//    	U.log(">>>>>>>>"+Util.matchAll((commhtml),"[\\w\\W\\s]{50}Coming Soon[\\w\\W\\s]{50}",0));
    	
    	//...PROPERTY TYPE...//
    	
 //   	U.writeMyText(combinedFloorHtml);
    	commhtml = commhtml.replaceAll("Condominiums</a>|home/condo|Condos\">|Condos</option>|Custom homes|Custom Home Builders|Custom Homes | Olentangy Schools|Modern Farmhouse|American Farmhouse", "").replace("condo\":{", "");
    	
    	combinedFloorHtml =  combinedFloorHtml.replaceAll("luxurious master suite|Condominiums</a>|home/condo|Condos\">|Condos</option>|Modern Farmhouse|American Farmhouse", "").replace("condo\":{", "");
    	commhtml=commhtml.replace("Craftsman</span","Adorable Craftsman style");

    	combinedFloorHtml=U.getNoHtml(combinedFloorHtml);
    	commhtml=U.getNoHtml(commhtml).replace("- Bungalow", "- bungalow-style");
    	
//    	U.log("MMMMMMMMMMmm "+Util.matchAll((combinedFloorHtml+commhtml).replaceAll("the tradition of | Homes brings you a traditional", "Traditional exterior")
//   			.replaceAll("- Craftsman</span>|_craftsman|Craftsman\"|Meadow Grove Reserve Condominiums", ""), "[\\w\\s\\W]{30}Flex Room[\\w\\s\\W]{30}", 0));
//    	U.log(">>>>>>>>"+Util.matchAll((combinedFloorHtml+commhtml),"[\\w\\W\\s]{50}Flex room\\w\\W\\s]{50}",0));
    	propType=U.getPropType((commhtml+combinedFloorHtml).replaceAll("Richmond - Flex Room|Redwood - Flex Room|Manchester - Flex Room|Linden - Flex Room|Cedar - Flex Roo,|Cedar - Flex Room|Bradford - Flex|Barclay - Flex Room|Bradford - Flex Room", "").replace("what split levels can", "").replace("The Shingle, Craftsman, and Folk Victorian exterior options", "Craftsman exteriors options").replaceAll(" Homes brings you a traditional", "Traditional exterior")
    			.replaceAll("Meadow Grove Reserve Condominiums", ""));
    	U.log("Property type is:"+propType);
    	
    	//...NOTE...//
    	
    	U.getnote(commhtml);
    	
    	if(moveCount.length>0) {
    		
    			if(propStatus.length()>4) {
    				if(!propStatus.contains("Move-in Ready")) {
    				propStatus+=", Move-in Ready Homes";
    				}
    			}
    			else {
    				propStatus="Move-in Ready Homes";
    			}
    		}
    	else {
    		propStatus=ALLOW_BLANK;
    	}
    	
    	String[] farmSec = U.getValues(commhtml, "<div class=\"et_pb_de_mach_gallery_item ", "</div>");
    	for(String farm : farmSec) {
    		
    		if(farm.contains("farmhouse.jpg\""))
    			if(propType==ALLOW_BLANK)
    				propType = "Farmhouse Style Homes";
    			else
    				propType+=", Farmhouse Style Homes";
    		
    	}
    	
    	if(commUrl.contains("https://rockfordhomes.net/find-your-community/glenmead/")) {
    		
    		propType+=", Farmhouse Style Homes";
    	}
    		
    	if(commUrl.contains("https://rockfordhomes.net/find-your-community/harvest-point/")) {
    		propType+=", Craftsman Style Homes";	
    		
    	}	
//    	if(commUrl.contains("https://rockfordhomes.net/find-your-community/butler-farms/"))
//    		minPrice = "$320,000";
//    		
    		
    	U.log("Geo Code::"+geo);
    	
    	if(commUrl.contains("https://rockfordhomes.net/find-your-community/terra-alta/")) {
    		//from img
    		if(propType.length()>0) {
    			propType=propType+" ,Craftsman Style Homes, Farmhouse Style Homes";
    		}
    		else
    			propType="Craftsman Style Homes, Farmhouse Style Homes";
    	}
    	 // ------------------ No. of units ------------------------
	     String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
    	
    	data.addCommunity(commName.replace(",",""), commUrl, commType);
    	data.addAddress(addr[0].replace(",", ""),addr[1],addr[2],addr[3]);
    	data.addLatitudeLongitude(latlong[0],latlong[1],geo);
    	data.addPrice(minPrice, maxPrice);
    	data.addSquareFeet(minsqft, maxsqft);
    	data.addPropertyType(propType,dpropType);
    	data.addNotes(note);
    	data.addPropertyStatus(propStatus);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
    	
	}j++;	
	}
}