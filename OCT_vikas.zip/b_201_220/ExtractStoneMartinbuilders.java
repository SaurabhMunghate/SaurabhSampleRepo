/*
 * Modified By Priti
 * */
package com.shatam.b_201_220;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.server.browserlaunchers.HTABrowserLauncher;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

public class ExtractStoneMartinbuilders extends AbstractScrapper
{

	static String BASE_URL ="https://www.stonemartinbuilders.com/";
	static String Builder_Name ="Stone Martin Builders";
	ArrayList<String> homeD=null;
	int j= 0;
	WebDriver driver = null;

	public static CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception{
		AbstractScrapper a = new ExtractStoneMartinbuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Stone Martin Builders.csv",a.data().printAll());

	}
	MultiValueMap moveInDataList=new MultiValueMap();
	public ExtractStoneMartinbuilders() throws Exception {
		super(Builder_Name,BASE_URL);
		LOGGER = new CommunityLogger("Stone Martin Builders");

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String mainHtml = U.getHTML("https://www.stonemartinbuilders.com/new-homes/");
		String moveIndata=U.getHTML("https://www.stonemartinbuilders.com/new-homes/available/");
		String homes[]=U.getValues(moveIndata, "<div class=\"col-sm-12 col-md-6 col-lg-6 mb-3 px-2\">", "</a></div></div></div>");
		for (String ho : homes) {
			String comName=U.getSectionValue(ho, "</h4><div>", "<hr class");
			if(comName != null)comName=U.getSectionValue(comName, "</div><div>", "</div>");
			if (comName!=null) {
//				U.log(U.getNoHtml(comName).trim());
				comName = U.getNoHtml(comName).replaceAll(".*>", "");
				moveInDataList.put(U.getNoHtml(comName).replace(",", "").trim(), ho);
				U.log(comName);
			}
			
		}
		
		String[] comSec = U.getValues(mainHtml, "<div class=\"col-sm-12 col-md-6 col-lg-6 mb-3 px-2\">", "</a></div></div></div>");
		
		U.log("Community Length::: "+ comSec.length);
		for(String com : comSec) {
			
			String comUrl = U.getSectionValue(com, "href=\"", "\"");
			addDetails(comUrl, com);
			
		}
		
		//getting communites from Plans by Place 
//		String regSec =U.getSectionValue(mainHtml, "<div class=\"col-sm-12 col-md-6 col-lg-6 mb-3 px-2\">", "</a></div></div></div>");
//		String regUrls[]=U.getValues(regSec, "href=\"", "\"");
//		for(String reg:regUrls) {
//			U.log("RegUrl ::"+reg);
//			findCommunity(reg);
//		}
		driver.quit();
		LOGGER.DisposeLogger();
	}
	private void findCommunity(String regUrl)throws Exception
	{
		
		String html=U.getHTML(regUrl);
		String comSec=U.getSectionValue(html, "<div id=\"wpgmza_marker_list","</div></div></div></div></div>");
		String[] commSections = U.getValues(html, "<figure class=\"wpb_wrapper vc_figure\">", "</figure>");
		U.log(commSections.length);
		
		String moveHomeHtml=U.getHTML("https://www.stonemartinbuilders.com/ready-inventory/");
		String[] homeData=U.getValues(moveHomeHtml, "<h3 class=\"the-title\">","</article>");
		homeD=new ArrayList<>();
		for (String string : homeData) {
			//U.log(string);
			homeD.add(string);
		}
//		U.log(commSections.length);
		for(String commSec : commSections)
		{
			String commUrl = U.getSectionValue(commSec, "<a href=\"", "\"");
			if(commUrl ==null)continue;
			if(commUrl.equals("https://www.stonemartinbuilders.com/"))continue;
//			comSec+=U.getSectionValue(html, "href=\""+commUrl+"\" target=\"_self\" class=\"vc_single_image-wrapper vc_box_shadow_border", "</p>");
			addDetails(commUrl,comSec+U.getSectionValue(html, "href=\""+commUrl+"\" target=\"_self\" class=\"vc_single_image-wrapper vc_box_shadow_border", "</p>"));
//			U.log("comsec:::::::::::::::::::"+U.getSectionValue(html, "href=\""+commUrl+"\" target=\"_self\" class=\"vc_single_image-wrapper vc_box_shadow_border", "</p>"));

		}
	}
	private void addDetails(String commUrl,String comSec) throws Exception 
	{
//	if(j >= 5)
	{
		//--------COMMUNITY URL---------//
	
		U.log(j+"---Community URL ="+commUrl);
		if(commUrl ==null) {
			LOGGER.AddCommunityUrl(commUrl+"=====Null");
			return;
		}
		commUrl = commUrl.replace("https://stonemartinnew.wpengine.com/", "https://www.stonemartinbuilders.com/");
		commUrl = "https://www.stonemartinbuilders.com"+commUrl;

		//============= Single Run ===================================================
//		if(!commUrl.contains("https://www.stonemartinbuilders.com/new-homes/al/pike-road/abbington/8398/"))return;
		
//		U.log("comSec===="+comSec);
		
		commUrl = commUrl.replace("http:", "https:");
//		U.log(comSec);//http://www.stonemartinbuilders.com/available-plans/walkers-hill/
		if(commUrl.contains("https://www.stonemartinbuilders.com/buzz-building-craftsman-style-home-huntsville/")){
			LOGGER.AddCommunityUrl(commUrl+"=====returned");
			return;
		}
		if(commUrl.contains("https://www.stonemartinbuilders.com/huntsville-we-have-arrived/")){
			LOGGER.AddCommunityUrl(commUrl+"=====returned");
			return;
		}

		if(commUrl.contains("https://www.stonemartinbuilders.com/new-homes/al/headland/windmill-corner/10138/")){
			LOGGER.AddCommunityUrl(commUrl+"=====PAGE NOT FOUND");
			return;
		}
		
		U.log("ComUrl: "+commUrl);
		String commHtml = U.getHTML(commUrl);
		//--------COMMUNITY NAME--------//
		String commName=U.getSectionValue(commHtml, "<h1 class=\"hero-text\">", "<");
		U.log(commName);
		if(commName==null) {
			 commName=U.getSectionValue(comSec, "title\">", "<");
			commName=commName.replace("&#039;s", "'s");
			commName=commName.replaceAll("in Athens, AL \\| Stone Martin Builders</title>", "").replace("Celia&#8217;s Garden", "Celia's Garden");
		}
		U.log("-----------Community Name ="+commName);
		
		//-------------Square feets from individual plans----------- 
		String allPlanData = ALLOW_BLANK;
		String[] planUrls = U.getValues(commHtml, "<a class=\"card mp-card\" href=\"", "\"");
		
		U.log("total plan are = "+planUrls.length);
		
		for(String planUrl : planUrls)
		{
			U.log("planUrl :: "+planUrl);
			String planHtml = U.getHTML("https://www.stonemartinbuilders.com"+planUrl);
			allPlanData += U.getSectionValue(planHtml, "Build Details</h3>", "</p></div></div>");
		}
		

		String moveinhtml= U.getHTML("https://www.stonemartinbuilders.com/new-homes/available/");
		String pagemove="";
		String dataSec="";
//		U.log(moveInDataList.containsKey(commName.trim().replace("The Cove at Towne Lake", "The Cove at Towne Lakes"))+"::::::::::::::::::::Heklllll");
		if (moveInDataList.containsKey(commName.trim().replace("The Cove at Towne Lake", "The Cove at Towne Lakes").replace("Laurenwood Preserve", "Laurenwood").replace("The Island at The Reserve", "The Island at Reserve"))) {
//			U.log("Home::::::::::");
			ArrayList<String> moveIn=(ArrayList<String>) moveInDataList.get(commName.trim().replace("Laurenwood Preserve", "Laurenwood").replace("The Cove at Towne Lake", "The Cove at Towne Lakes").replace("The Island at The Reserve", "The Island at Reserve"));
			for (String s : moveIn) {
//				if(s.contains("482,620")) {
//					U.log("FOUND");
//				}
				String moneUrl = U.getSectionValue(s, "href=\"", "\"");
				try {
					U.log("MoveUrl:: "+moneUrl);
					String moveHtml = U.getHTML("https://www.stonemartinbuilders.com"+moneUrl);
//					if(moveHtml.contains("482,620")) {
//						U.log("FOUND");
//					}
					String moveData = U.getSectionValue(moveHtml, "Build Details</h3>", "</p></div></div>");
					dataSec+=s+moveData;
				}catch (Exception e) {
					// TODO: handle exception
				}
				
//				U.log("ssss"+s);
			}
		}
		
		
//		U.log("MMMMMMMMMMM "+dataSec);
		String sections[]=U.getValues(moveinhtml, " <li><a class=\"\" data-filter=\"", "</li>");
		for(String all:sections) {
//			U.log(all+":::::::::section");
			String dummname = U.getSectionValue(all, ">", "<");
//			U.log(dummname+"::::::::::"+commName);
			if(commName.replace("&#8217;s","").replace("The Cove at Towne Lake", "The Cove at Towne Lakes").trim().contains(dummname.replace("&#039;s", "").trim())) {
//				U.log(all);
//				dataSec+=all;
				pagemove = U.getHTML(U.getSectionValue(all, "href=\"", "\""));
			}
		}
//		U.log(pagemove);
		//----------MIN AND MAX SQUARE FEET---------//
		String minSqft=ALLOW_BLANK , maxSqft=ALLOW_BLANK;
		allPlanData=allPlanData.replace(" &#8211; ", "-");
//		U.log(comSec);
		String[] sqft = U.getSqareFeet(commHtml+allPlanData+comSec+dataSec,
				"range from \\d{4} square feet up to \\d{4}|from \\d{4} to almost \\d{4} square feet|\\d,\\d{3} square feet up to \\d,\\d{3} square feet|from \\d{4} up to \\d{4} square feet|from \\d{4} to \\d{4} square feet|\\d{4}-\\d{4} square feet|<span>\\d,\\d{3} Sq. Ft.</span>|>\\d{4} Sq. Ft.",0);
		minSqft = (sqft[0]==null) ? ALLOW_BLANK :sqft[0];
		maxSqft = (sqft[1]==null) ? ALLOW_BLANK :sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);

		//-----------MIN PRICE AND MAX PRICE-----------//
		
		String remPrice=U.getSectionValue(commHtml, "Most Recent Projects","<section id=\"mk-footer");
		if(remPrice!=null)commHtml=commHtml.replace(remPrice, "");
		String minPrice = ALLOW_BLANK ,maxPrice = ALLOW_BLANK;
		
		String homrPrice="";
//		for (String price : homeD) {
//			//U.log(price);
//			if(price.contains(commUrl.replace("available-plans", "plan-category").replace("the-", ""))) {
//				homrPrice=homrPrice+price;
//			}
//		}

		
		commHtml=commHtml.replace("0s", "0,000");
		commHtml=commHtml.replace("$307s", "$307,000");
		commHtml=commHtml.replace("$425s", "$$425,000");
		//$425s<
		//the $307s
		String prices[] = U.getPrices(commHtml+homrPrice+dataSec,"\\$\\d{3},\\d{3}</a>|\\$\\d+,\\d+ - \\$\\d+,\\d+|\\$\\d+,\\d+", 0);
//		U.log("MMMMMM "+Util.matchAll(commHtml, "[\\s\\w\\W]{30}\\$482[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMM "+Util.matchAll(homrPrice, "[\\s\\w\\W]{30}\\$482[\\s\\w\\W]{30}", 0));
//		U.log("MMMMMM "+Util.matchAll(dataSec, "[\\s\\w\\W]{300}\\$482[\\s\\w\\W]{330}", 0));

		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		//---------ADDRESS AND LAT LONG---------//
		U.log(minPrice+""+maxPrice);
		String addr[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		commHtml = commHtml.replace(" our Model Home</span></h1>", "Model Home</h2>");
		String addressSec = U.getSectionValue(commHtml, "Address:</div>", "</div>");
		
		U.log("addressSec::::::"+addressSec);
		if(addressSec == null)
			addressSec = U.getSectionValue(commHtml, "{\"address\":\"", "\"");
		if(addressSec == null) {
			commHtml=commHtml.replace("<p style=\"text-align: center;\"><span style=\"font-size: 20pt; color: #000000;\">Visit our Sales Center</span></p>", "");
			addressSec = U.getSectionValue(commHtml, "<span style=\"font-size: 20pt; color: #000000;\">", "<br />");
		}
		if(addressSec != null)
		{
			addressSec = addressSec.replace("<br/>", ",");
			addr = U.getAddress(U.getNoHtml(addressSec));
			if (addr[2]==null) {
				addr=U.findAddress(addressSec);
			}
			U.log("ADDRESS"+Arrays.toString(addr));
		}
		////new code 28/2/19
		if(addressSec==null) {
//			addressSec=U.getSectionValue(commHtml, "https://www.google.com/maps/embed?pb=", "\"");
			if(addressSec==null) {
				addressSec=findAddress(commName,comSec);
				U.log(addressSec);
				if(addressSec!=ALLOW_BLANK && addressSec!=null) {
				addressSec=addressSec.replace("Madison, AL, USA", "Madison, AL 35756, USA").replace("Huntsville, AL, USA", "Huntsville, AL 35806, USA").replace("Opelika, AL, USA", "Opelika, AL 36804, USA").replaceAll(", USA", "");
				U.log("-=--==--="+U.getSectionValue(addressSec, "address'>", "</div>"));
				addr=U.getAddress(U.getSectionValue(addressSec, "address'>", "</div>"));
			}
		}
		}
		if (addressSec==null||addressSec==ALLOW_BLANK) {
			addressSec=U.getSectionValue(commHtml, "class=\"wpb_map_wraper\">", "</iframe>");
//			U.log(addressSec);
			if (addressSec!=null) {
				addressSec=U.getSectionValue(addressSec, "!2s", "!5");
				if (addressSec!=null) {
					addr=U.getAddress(URLDecoder.decode(addressSec,StandardCharsets.UTF_8.toString()));
				}
//				U.log(addressSec);
			}
		}
		if(addr==null) {
			addr=new String []{ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		}
		String notes=ALLOW_BLANK;
		
		String lat=ALLOW_BLANK,lng=ALLOW_BLANK;
		lat = U.getSectionValue(commHtml, "'latitude':", ",");
		lng = U.getSectionValue(commHtml, "'longitude':", ",");
		U.log(commUrl);
		if (commUrl.contains("https://www.stonemartinbuilders.com/available-plans/the-retreat/")) {
			addr[0]="13 N 8th St.";
			addr[1]="Opelika";
			addr[2]="AL";
			addr[3]="36801";
			geo="TRUE";
			notes="Address Taken From Contacts";
			String lats[]=U.getlatlongGoogleApi(addr);
			lat=lats[0];
			lng=lats[1];
		}
		if (commUrl.contains("https://www.stonemartinbuilders.com/available-plans/phillips-cove/")) {
			addr[0]="Creekmound Dr";
			addr[1]="Huntsville";
			addr[2]="AL";
			addr[3]="35806";
			geo="TRUE";
			notes="Address Taken From Sitemap";
			String lats[]=U.getlatlongGoogleApi(addr);
			lat=lats[0];
			lng=lats[1];
		}
		
		if (commUrl.contains("https://www.stonemartinbuilders.com/available-plans/charleston-mills/")) {			
			addr[1]="Dothan";
			addr[2]="AL";			
			geo="TRUE";
			notes="Address is calculated using City and State";
			String lats[]=U.getlatlongGoogleApi(addr);
			lat=lats[0];
			lng=lats[1];			
			addr = U.getAddressGoogleApi(new String[] {lat,lng});
			geo="TRUE";
			
			
		}
		
		//Dothan, AL, USA
		if(lat==null) 
		{
			String latSec=U.getSectionValue(commHtml, "https://www.google.com/maps/embed?pb=","\"");
			U.log(latSec+":::::::::::::::::::::lattitide sec");
			if(latSec!=null) {
			lat=U.getSectionValue(latSec, "3d", "!2m");
			lng=U.getSectionValue(latSec, "!2d", "!");
			}
			U.log(lat+":::::::::::::::::"+lng);			
		}
		
		if( addressSec!=null &&lat==null&&addressSec.contains("https://www.google.com/maps/dir//") ) 
		{
			String latSec=U.getSectionValue(addressSec, "/@", ",17z");
			lat=Util.match(latSec, "\\d{2,3}.\\d+");
			lng=Util.match(latSec, "-\\d{2,3}.\\d+");

		}
		
		
		if(lat==null && lng==null) {
			lat=U.getSectionValue(comSec, "data-latitude=\"", "\"");
			lng=U.getSectionValue(comSec, "data-longitude=\"", "\"");
		}
		
		U.log("lat:::"+lat+"\tlng::"+lng);

		if(addr[0] == ALLOW_BLANK && addr[1] == ALLOW_BLANK && addr[2] == ALLOW_BLANK && addr[3] == ALLOW_BLANK)
		{
			if(lat != ALLOW_BLANK && lng != null)
			{
				String latLong[] = {lat.trim(),lng.trim()};
				addr = U.getAddressGoogleApi(latLong);
				if(addr == null) addr = U.getAddressGoogleApi(latLong);
			    geo = "TRUE";
			}
		}
		if(addr[3] == ALLOW_BLANK  && lat != null)
		{
			String latLong[] = {lat.trim(),lng.trim()};
			String addr1[] = U.getAddressGoogleApi(latLong);
			if(addr1 == null) addr1 = U.getAddressGoogleApi(latLong);
			addr[3] = addr1[3];
		    geo = "TRUE";
			
			
		}
		if(addr[3] != ALLOW_BLANK && lat == null)
		{
			String latLong[] = U.getlatlongGoogleApi(addr);
			if(latLong == null) latLong = U.getlatlongGoogleApi(addr);
			lat=latLong[0];
			lng=latLong[1];
		    geo = "TRUE";
			
			
		}

		//--------COMMUNITY DATA---------//
		
		String commType=ALLOW_BLANK;
		   
		String PropType=ALLOW_BLANK;
		   
		String dProptype=ALLOW_BLANK;
		   
		String propStatus=ALLOW_BLANK;
		   

		 //---------COMMUNITY TYPE---------//
		U.log(Util.match(comSec, ".*gated community.*"));
		commType = U.getCommType((commHtml+comSec)
				.replace("pool and lake access", "pool and lake lakeside living")
				.replace("Lake community page", ""));
		U.log("Commmunity Type ="+commType);
		
		//---------COMMUNITY PROPERTY TYPE-------//
		commHtml=commHtml.replaceAll("HOA|homeowners-association/|Homeowners Association\"","");
		if(dataSec!=null) dataSec = dataSec.replace("calling for luxury and comfort", "calling for luxury homes and comfort");
		if(allPlanData!=null) allPlanData = allPlanData.replace("calling for luxury and comfort", "calling for luxury home designs and comfort")
				.replace("The 2nd floor is home to a large bonus room", "The 2 story is home to a large bonus room")
				.replaceAll("2nd floor ", "");
		
//		U.log(allPlanData);
		PropType = U.getPropType((commHtml+comSec+dataSec+U.getNoHtml(allPlanData)).replaceAll("craftsmanship", ""));
		U.log("Property Type ="+PropType);
		


		//---------DERIVED PROPERTY TYPE--------//
		dProptype = U.getdCommType(commHtml.replaceAll("ranch|Ranch|one-story floor|2nd floor","")+commUrl+comSec+dataSec+U.getNoHtml(allPlanData));
		U.log("Derived Property Type ="+dProptype);

		//----------PROPERTY STATUS--------//
		String rem=U.getSectionValue(commHtml, "<section class=\"portfolio-similar-posts\">", "</section>");
		if (rem!=null) {
			commHtml=commHtml.replace(rem, "");
		}
		String comm_Sec=commHtml;
		comm_Sec=U.removeSectionValue(comm_Sec, "<span class=\"f-script text-capitalize\">Available</span> Homes</h1>", "</body>");
		
		propStatus = U.getPropStatus(comSec+comm_Sec.replaceAll("<div class=\"portfolio-categories\">Coming Soon Opelika</div>", ""));
		U.log("Property Status ="+propStatus);
//		U.log("MMMMMM "+Util.matchAll(comSec+commHtml, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{100}", 0));

		
		if(pagemove.contains("<div class=\"portfolio-meta-wrapper\">")) {
			propStatus ="Move-In Ready";
		}
		
		//============= Move Status ==========
//		U.log(dataSec);
//		if(dataSec.length()>3 && !propStatus.contains("Move")) {
//			
//			if(propStatus.length()<3)
//				propStatus = "Move-In Ready";
//			else
//				propStatus += ", Move-In Ready"; 
//		}
//		
//		//-----------NOTES-----------//
//		U.log(commName);
//		commName=U.getNoHtml(commName);
////		U.log("Notes ="+notes);
//		
//		if(commUrl.contains("https://www.stonemartinbuilders.com/available-plans/the-island-at-the-reserve/") || commUrl.contains("https://www.stonemartinbuilders.com/available-plans/celias-garden/")) 
//			propStatus = "Move-In Ready";
//		
		
//		if(commUrl.contains("https://www.stonemartinbuilders.com/new-homes/al/madison/the-crossings/6275/"))commType = "Master Planned, " + commType;//Img
		
		if(commHtml.contains("<div class=\"col-sm-12 col-lg-6 col-xl-4 loc-card") && commHtml.contains("<span class=\"f-script text-capitalize\">Design Ready</span> Homes</h1>")) {
			if(propStatus.length()<3)
				propStatus = "Quick Move-In Homes";
			else
				propStatus += ", Quick Move-In Homes"; 
		}

		if(commUrl.contains("/available-plans/cannongate-2/"))maxPrice="$334,962";
		addr[0]=addr[0].replaceAll("Visit our Sales Center at|Visit Our Neighborhood|Visit Our Model Home,|,|<h2 style=\"textalign: center;", "").replaceAll("Visit our Neighborhood\\s*<h2 style=\"textalign: center;", "");
		if(data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl(commUrl+"::::::::::::::Repated");
			return;

		}
	//	if(commUrl.contains("https://www.stonemartinbuilders.com/new-homes/al/auburn/northwoods/7740/"))propStatus="Coming Soon";
		if(lat == null ) 
		{
			lat = ALLOW_BLANK;
			lng = ALLOW_BLANK;
		}
		String updatedName = "";
		if(commUrl.contains("communities/chesterfield/harpers-mill-glen-royal#detail")) {
			updatedName ="Harpers Mill";
		}else {
			updatedName = commName;
		}
		U.log(updatedName);
		String lotIds=ALLOW_BLANK;
		//U.log(">>>>>>>>>>>>"+Util.matchAll(planData, "[\\s\\w\\W]{30}Presale[\\s\\w\\W]{30}", 0));		
//		String lotMapData = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetSiteplan\",\"variables\":{\"clientName\":\"stonemartinbuilders\",\"communityName\":\""+updatedName+"\"},\"query\":\"query GetSiteplan($clientName: String!, $communityName: String!, $siteplanName: String) {\\n  siteplan(clientName: $clientName, communityName: $communityName, siteplanName: $siteplanName, active: true) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    unreleasedLotsHandle\\n    showUnreleasedLotNumber\\n    ...SiteplanSVGFields\\n    geoInfo(clientName: $clientName) {\\n      id\\n      siteplanId\\n      neLatitude\\n      neLongitude\\n      swLatitude\\n      swLongitude\\n      geoJson\\n      __typename\\n    }\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    hotspots {\\n      id\\n      siteplanId\\n      name\\n      x\\n      y\\n      width\\n      height\\n      description\\n      thumb\\n      assets {\\n        id\\n        listIndex\\n        src\\n        videoUrl\\n        description\\n        __typename\\n      }\\n      __typename\\n    }\\n    lots(clientName: $clientName) {\\n      ...LotFields\\n      geoJson\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      excludedPlanElevations(clientName: $clientName) {\\n        planId\\n        elevationId\\n        planName\\n        planDisplayName\\n        elevationCaption\\n        __typename\\n      }\\n      inventory(clientName: $clientName) {\\n        ...InventoryFields\\n        photos(clientName: $clientName) {\\n          id\\n          src\\n          listIndex\\n          __typename\\n        }\\n        plan(clientName: $clientName) {\\n          ...PlanFields\\n          __typename\\n        }\\n        elevation(clientName: $clientName) {\\n          ...ElevationFields\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment PlanFields on Plan {\\n  id\\n  displayName\\n  name\\n  communityId\\n  defaultElevationId\\n  description\\n  bed\\n  bath\\n  cost\\n  size\\n  videoUrl\\n  interactiveInteriorIds(clientName: $clientName)\\n  bedRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  bathRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  costRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  sizeRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment ElevationFields on Elevation {\\n  id\\n  mirrorElevationId\\n  mirrorRolePrimary\\n  communityId\\n  planName\\n  planDisplayName\\n  planId\\n  caption\\n  thumb\\n  bed\\n  bath\\n  size\\n  cost\\n  defaultFloor\\n  description\\n  svgMirroring\\n  garagePosition\\n  defaultGaragePosition\\n  bedRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  bathRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  costRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  sizeRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  tags(clientName: $clientName) {\\n    categoryName\\n    tagName\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment LotFields on Lot {\\n  id\\n  communityId\\n  dataName\\n  name\\n  salesStatus\\n  premium\\n  externalId\\n  address\\n  size\\n  cityName\\n  stateCode\\n  zip\\n  postCode\\n  geoJson\\n  availableSchemes(clientName: $clientName) {\\n    id\\n    name\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment InventoryFields on Inventory {\\n  id\\n  lotId\\n  planId\\n  elevationId\\n  communityId\\n  price\\n  sqft\\n  beds\\n  baths\\n  features\\n  constructionStatus\\n  closingDate\\n  mlsId\\n  garageType\\n  garageCapacity\\n  floors\\n  schemeId\\n  photoFolder\\n  plan(clientName: $clientName) {\\n    id\\n    communityId\\n    name\\n    displayName\\n    __typename\\n  }\\n  sgtData(clientName: $clientName) {\\n    id\\n    sgtVendorId\\n    sgtExternalId\\n    sgtData\\n    __typename\\n  }\\n  appointmentsEnabled\\n  reserveHomeUrl\\n  garagePosition\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
//		U.log("lotMapData=="+lotMapData);
//		JsonParser parser = new JsonParser();
//		String lotIds="";
//		if(!lotMapData.contains("INTERNAL_SERVER_ERROR") && !lotMapData.contains("\"siteplan\":null")){
//			JsonObject jobj = (JsonObject)parser.parse(lotMapData);
//			U.log("jobj=="+jobj);
////			lotIds = jobj.get("data").getAsJsonObject().get("siteplan").getAsJsonObject().get("lots").getAsJsonArray().size()+"";
////			U.log(lotIds);
//		}
		
		String mapHtml=null;
		String mapSec=U.getSectionValue(commHtml, "Map</h1>", "View Interactive Site Map");
//		U.log("mapSec==="+mapSec);
		if(mapSec!=null) {
		String mapLink=U.getSectionValue(mapSec, "<a class=\"btn bg-light-green\" href=\"", "\"");
		U.log("mapLink==="+mapLink);
		if(mapLink!=null) {
			mapHtml	=U.getHtml(mapLink,driver);
			lotIds=Util.getUnitsByMatch(mapHtml);
		}
		}
		
		
		if(lotIds.equals("0")) {
			String[] lotData=U.getValues(mapHtml, "class=\"MasterSiteplanLegend-typography MuiTypography-root MuiTypography-subtitle1 css-", "</div>");
			if(lotData.length>0) {
				int sum=0;
				for(String lotdata : lotData) {
					lotdata=U.getNoHtml(lotdata).trim();
//					U.log("lotdata=="+lotdata);
					lotdata=U.getSectionValue(lotdata, "(", ")");
					sum+=Integer.parseInt(Util.match(lotdata, "\\d+"));
					
				}
				lotIds=Integer.toString(sum);
			}
		}
			U.log("lotIds==="+lotIds);
		
		
		
		
			if(lotIds.equals("0"))lotIds=ALLOW_BLANK;
		LOGGER.AddCommunityUrl("Commurl:::::::::::::::::::::::"+commUrl);
		data.addCommunity(commName, commUrl, commType);
		data.addAddress(addr[0],addr[1],addr[2],addr[3]);
		data.addLatitudeLongitude(lat,lng,geo);
	    data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyStatus(propStatus);
		data.addPropertyType(PropType, dProptype);
		data.addNotes(notes);
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);	
	}j++;
	}
	
	private String findAddress(String commName,String comSec) { 
		String addSec=ALLOW_BLANK;
		String comaddSec[]=U.getValues(comSec,"<div class='wpgmza-content-address-holder'>", "Directions");
		for(String addsec:comaddSec) {
			if(commName.trim().equals(U.getSectionValue(addsec, "title=\"", "\">"))){
				U.log("|||||"+addsec);
				addSec=U.getSectionValue(addsec, "div class='wpgmza-", "data=");
				if(addSec== null) {
					addSec=U.getSectionValue(addsec, "<div class='wpgmza-", "\">");
				}
			}
		}
		return addSec;
	}
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY1MDY5MTM2OCwiZXhwIjoxNjUwNzM0NTY4fQ.oNHxUfohb6XpNS5gyoiujEGrcL8rmuRPYHhdmhpHYLs");
//	        connection.setRequestProperty("Content-Length", "1824");
	        connection.setRequestProperty("Content-Type", "application/json");
	        connection.setRequestProperty("Origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("Referer", "https://myhome.anewgo.com/");
//	        connection.setRequestProperty("Sec-Fetch-Dest", "empty");
//	        connection.setRequestProperty("Sec-Fetch-Mode", "cors");
//	        connection.setRequestProperty("Sec-Fetch-Site", "same-site");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");

	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

}