package com.shatam.b_201_220;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.b_161_180.ExtractEagleConstruction;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractTerrataHomes extends AbstractScrapper{

CommunityLogger LOGGER;
	
	static int j=0;
	WebDriver driver = null;
	
	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new ExtractTerrataHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Terrata Homes.csv", a.data().printAll());
	}

	public ExtractTerrataHomes() throws Exception {
		super("Terrata Homes", "https://terratahomes.com/");
		LOGGER = new CommunityLogger("Terrata Homes");
	}
	Set<String> comurls = new HashSet<String>();
	
	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String mainHtml = U.getPageSource("https://terratahomes.com/");
		String[] secs = U.getValues(mainHtml, "\"communityurl\":\"", "\"");
		U.log("secs: "+secs.length);
		
		for(String sec:secs)
		{
			String url = "https://terratahomes.com" + sec;
			U.log("url: "+url);
			comurls.add(url);
			//U.log("comurls: "+comurls.size());
			for(String comUrl:comurls) {
				addDetails(comUrl);
			}
  			
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl) throws Exception {
		// TODO Auto-generated method stub
//	if(j>=7)

		{
			
//SINGLE EXECUTION
//			if(!comUrl.contains("oenix/segovia-at-estrella"))return;
		
		
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------>Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		U.log("\nCount=="+j);
		U.log("comUrl >>>>> "+comUrl);
//		U.log("sec=========\n"+sec);
		String commHtml = U.getHtml(comUrl, driver);
		commHtml=U.removeSectionValue(commHtml, "<h2 class=\"findyour-neighborhood__mobile-title\">", "</button>\n" + 
				"                            </div>");
		
		commHtml=U.removeSectionValue(commHtml, "var communityAmenities =", " </script>");
		commHtml=U.removeSectionValue(commHtml, "var internalAPIResponse={", " </script>");

		String commName = U.getSectionValue(commHtml, "neighborhood-hero-community-name\">", "<");
		if(commName!=null) {
				commName = commName.replace("Segovia At Estrella™", "Segovia At Estrella").replace("™", "");		
		}
		
		U.log("commName >>>>> "+commName);
		
		String planHtml = "";
//		String planSec = U.getSectionValue(commHtml, "<h1>Available Floor Plans</h1>", "<h1>Community Photos</h1>");
		String[] plansUrls = U.getValues(commHtml, " <div class=\"floorplan-listing__card-top\">", "</a>");
		for(String plan:plansUrls)
		{
			U.log("plansUrls >>>>> "+"https://terratahomes.com/"+U.getSectionValue(plan, "href=\"", "\""));
			planHtml = planHtml +U.getPageSource("https://terratahomes.com/"+U.getSectionValue(plan, "href=\"", "\""));
//			if(planHtml.contains("flex room")) {
//				U.log("FOUND");
//			}
		}
		
//		String moveInData = ALLOW_BLANK;
//		String moveinUrl = U.getSectionValue(commHtml, "<a href=\"move-in-ready","find move-in ready inventory");
//		if(moveinUrl!=null)moveinUrl = "https://terratahomes.com/move-in-ready"+moveinUrl.replace("\">", "");
//		U.log("moveurl: "+moveinUrl);
//		String moveHtm = U.getPageSource(moveinUrl.trim());
//		String homes[] = U.getValues(moveHtm, "<div class=\"home-box\">", "Garage");
//		for(String home:homes) {
//			
//			if(home.toLowerCase().contains(commName.toLowerCase().trim())) {
//				moveInData+=home;
//			}
//			
//		}
//		U.log(moveInData);
		//======= Community Type ===================================
		comUrl = comUrl.replaceAll("this 55\\+|for this 55\\+", "55-and-better couples");
		commHtml = commHtml.replaceAll("newest 55\\+ section", "55-and-better couples");
		

		String ctype = U.getCommType((commHtml+comUrl).replaceAll("resort-inspired atmosphere", ""));
		//U.log(Util.matchAll(commHtml, "[\\s\\w\\W]{30}resort[\\s\\w\\W]{30}",0));
		
		
		commHtml = commHtml.replaceAll("-ranch.php\">|Ranch</a>|first floor masters|second floor masters|first-floor-masters|/floor-plans/second-floor-", "");
		
		
		String dtype = U.getdCommType((commHtml+planHtml).replaceAll("-ranch.php\">|Ranch\\s*</a>|[F|f]loor|first floor masters|second floor masters|first-floor-masters|/floor-plans/second-floor-", ""));
		
//		U.log(Util.matchAll(commHtml, "[\\s\\w\\W]{30}Ranch[\\s\\w\\W]{30}",0));
		
		
		if(dtype.length()<4)
			dtype=ALLOW_BLANK;
		
		comUrl = comUrl.replaceAll("New Section\n\\s*<br/>\n\\s*\n\\s*Coming Soon!", "New Section Coming Soon!");
		planHtml = planHtml.replaceAll("Village|village|Carriage| luxurious serenity", "");
		commHtml = commHtml.replace("CURRENT PHASES ARE SOLD OUT", "CURRENT PHASES SOLD OUT") 
				.replaceAll("salesstatus\":\"New Homes Coming Soon|var comingSoonStatuses = 'Coming Soon|||New Section Coming Soon|New Homes Coming|var comingSoonStatuses = 'Coming Soon|var soldOutStatuses = 'Sold Out'|salesstatus\":\"Sold Out|salesstatus\":\"Move-in Ready|immediate move|quick move-in homes</a>|Coming in 2017! Located|\"Coming in 2017|\">Coming in 2017|Patio\" /></li>|Patio\" /></li>|<a href=\"/quick-move-in-homes/\" class=\"footerNavAnchor footerAnchorBackgroundColor\">quick move-in homes</a>|<a href=\"/quick-move-in-homes/\" class=\"mainNavAnchor\">quick move-in homes</a>", "");
		commHtml=U.removeSectionValue(commHtml, " <div class=\"item  description marketingDescription\"", " </div>");
		
		commHtml = commHtml.replaceAll("var soldOutStatuses = 'Sold Out'|salesstatus\":\"Move-in Ready|salesstatus\":\"Coming Soon|"
				+ "salesstatus\":\"Sold Out|salesstatus\":\"New Section Coming|var comingSoonStatuses = 'Coming Soon\\|New Section Coming Soon\\|New Homes Coming Soon';|"
				+ "var soldOutStatuses = 'Sold Out'", "")
				.replace("var comingSoonStatuses = 'Coming Soon|New Section Coming Soon|New Homes Coming Soon", "")
				.replace("var soldOutStatuses = 'Sold Out'", "").replace("New Section Coming Soon|New Homes Coming Soon'", "")
				.replace("floorplan-listing__status\">Coming Soon<", "").replaceAll("findyour-neighborhood__status\">New Homes Coming Soon<", "")
				.replaceAll("status--mobile\">New Homes Coming Soon<", "");
		
		String status = U.getPropStatus(commHtml
				.replace("Last Chance</span>", "")
				.replaceAll("href=\"move-in-ready|status--mobile\">Grand Opening</span>|-neighborhood__status\">Grand Opening</span>|neighborhood__status\">Sold Out</span>|status--mobile\">Sold Out</span>|price\">\n\\s*COMING SOON!|\"salesstatus\":\"Grand Opening\"|\"floorplan-listing__status\">Sold Out</span>", "")
				.replaceAll("quick move|\"model-price\">\\s*SOLD OUT|<span class=\"sold_out\">\\s*SOLD OUT|INFORMATION ON THE NEWEST SECTION COMING|alt=\"Grand Opening|tipGrandOpening|alt=\"This Community is Coming Soon|BDX Coming Soon|Move-in ready|move-in ready|quick move-in homes\\s*</a>|ipComingSoo", ""));
		
//	U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{50}New Section Coming Soon[\\w\\s\\W]{30}", 0));
//	U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{30}Move-in Ready[\\w\\s\\W]{20}", 0));
//	U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{30}sold[\\w\\s\\W]{20}", 0));
		U.log("ComName::"+commName);
		U.log("status:"+status);
			
//		U.log(Util.matchAll(commHtml, "[\\w\\s\\W]{50}Now Selling[\\w\\s\\W]{50}", 0));




		planHtml = planHtml
				.replaceAll("alt='Hawley single family house with three-car garage", "")
				.replaceAll("<li>\\s+Loft\\s+</li>", "<li>Loft</li>");
		comUrl = comUrl.replace("luxurious, all-brick condos", "luxury homes, all-brick condos");
		commHtml = commHtml.replace("traditional architecture", "traditional homes architecture").replace("Craftsman, European and Traditional-style", "classic craftsman design and Traditional exterior");
		
		String commSec=U.getSectionValue(commHtml, "<main>", "</main>");

		String ptype = U.getPropType((commSec+planHtml+comUrl).replaceAll("brand new luxury homes for sale in Celina near| Manor Texas|Manor, TX|insurance and HOA|Village|village", ""));
		
//		U.log(Util.matchAll(commSec, "[\\w\\s\\W]{50}luxury[\\w\\s\\W]{50}", 0));
//		U.log(Util.matchAll(planHtml, "[\\w\\s\\W]{50}luxury[\\w\\s\\W]{50}", 0));
//		U.log(Util.matchAll(comUrl, "[\\w\\s\\W]{50}luxury[\\w\\s\\W]{50}", 0));

		
		U.log("ptype===== "+ptype);
		String[] add ={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK}; 
		String latLng[] = {ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		
		String[] latSec = U.getValues(commHtml, "<script type=\"application/ld+json\">", "</script>");
		
//		for(String comm : latSec) {
//			
//		if(comm.replace("www.", "").contains("\"url\": \""+url)){
//			
//			add[0] = U.getSectionValue(comm, "\"streetAddress\": \"", "\"");
//			add[1] = U.getSectionValue(comm, "\"addressLocality\": \"", "\"");
//			add[2] = U.getSectionValue(comm, "\"addressRegion\": \"", "\"");
//			add[3] = U.getSectionValue(comm, "\"postalCode\": \"", "\"");
//			
//			latLng[0] = U.getSectionValue(comm, "\"latitude\": \"", "\"");
//			latLng[1] = U.getSectionValue(comm, "\"longitude\": \"", "\"");
//			
//		}
//		
//		}
		String addSec=ALLOW_BLANK;
		commHtml=commHtml.replace("Texas","TX");
	//	if(url.contains("/southern-pines.php") || url.contains("/the-tate-reserve.php")||url.contains("/spicewood-trails.php")||url.contains("https://terratahomes.com/whisper-valley.php")) {
		{
		
			String addSecMain = U.getSectionValue(commHtml, "neighborhood-details__right-content\">", "Get Directions</a>");
			if(addSecMain == null) {
				addSecMain = U.getSectionValue(commHtml, "neighborhood-details__right-content\">", "<div class=\"secondary-nav");
			}
			
			if(addSecMain.contains("neighborhood-details__address")) {
				String section = U.getSectionValue(addSecMain, "neighborhood-details__address\">", "</div>");
				String[] temp = section.split("</span>");
				add[0] = temp[0].replace("<span>","").trim();
				if(add[0] == null || add[0].isEmpty()) {
					add[0] = ALLOW_BLANK;
				}
				
				
				String[] tempOne = temp[1].split(",");
				add[1] = tempOne[0].replace("<span>","").trim();
				
				add[2] = Util.match(tempOne[1], " \\w+");
				add[3] = Util.match(tempOne[1], " \\d+");
				
				U.log(">>>>From Here Address: "+Arrays.toString(add));
			}
//			else {
//				String section = U.getSectionValue(addSecMain, "neighborhood-details__address\">", "</div>");
//				String[] temp = section.split("</span>");
//				add[0] = temp[0].replace("<span>","").trim();
//				if(add[0] == null)
//					add[0] = ALLOW_BLANK;
//				
//				String[] tempOne = temp[1].split(",");
//				add[1] = tempOne[0].replace("<span>","").trim();
//				
//				add[2] = Util.match(tempOne[1], " \\w+");
//				add[3] = Util.match(tempOne[1], " \\d+");
//				
//				U.log(">>>>From Here Address: "+Arrays.toString(add));
//			}
			
			
//			U.log("section: "+section);
//			U.log("temp[1]: "+temp[1]);
//			U.log("add[1]: "+add[1]);
			//add=addSec.split(",");
			
//			U.log("KKKKKKKKKKK  "+add[0].length());
			
			if(add[0].length()==0||add[0]==ALLOW_BLANK ) {
				addSec = U.getSectionValue(comUrl, "<p>", "<");
				if(addSec != null) {
					String[] add1 = addSec.split(",");
					add[0] = ALLOW_BLANK;
					add[1] = add1[0];
					add[2] = add1[1];
					add[3] = ALLOW_BLANK;
				}
				
			}
			
			//================= Lat Lng
			String geoSec = U.getSectionValue(addSecMain, "neighborhood-details__link", "target");
			if(geoSec != null) {
				latLng[0] = U.getSectionValue(geoSec, "@", ",");
				latLng[1] = Util.match(geoSec, "-\\d{2,4}.\\d{3,}");
			}
			
//			U.log("KKKKKKKKKKKK   "+add[0].trim().length());

			if(add[0].trim().length()==0   && latLng[0]==null|| latLng[0]==ALLOW_BLANK ) {			
			latLng = U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latLng);
			geo = "TRUE";
			}
			if(latLng[0]==null||latLng[0]==ALLOW_BLANK) {			
				latLng = U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latLng);
				geo = "TRUE";
				}
//			if(add[0].length()<2 || add[0]==null) {
//				add=U.getAddressGoogleApi(latLng);
//				geo = "TRUE";
//			}
		}
//		if(addSec!=null && (add[0]==null || add[0]==ALLOW_BLANK)){
//		 addSec = U.getSectionValue(sec, "<p>", "<");
//		
//
//			String[] add1 = addSec.split(",");
//			add[0] = ALLOW_BLANK;
//			add[1] = add1[0];
//			add[2] = add1[1];
//			add[3] = ALLOW_BLANK;
//			
//			latLng = U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latLng);
//			geo = "TRUE";
//			
//		}
		
		//String addSec=U.getSectionValue(commHtml, "<div class=\"third\">","</div>");
		
		
		U.log("Address::::::"+Arrays.toString(add)+" Geo: "+geo); 
		U.log("LatLng::::::"+Arrays.toString(latLng)); 
		
		commHtml=commHtml.replaceAll("0s|0's|0S", "0,000");
		comUrl=comUrl.replaceAll("0s|0's|0S", "0,000");
		if(add[0]==null)add[0]="";
		if(add[0].equals(add[1]))add[0]="";
		if(add[0]==null || add[0].length()<5)
		{
			
			add=U.getAddressGoogleApi(latLng);
			if(add==null)add=U.getGoogleAddressWithKey(latLng);
			geo="TRUE";
		}
//		sec=sec.replace("From the Mid-$700s", "From the Mid-$700,000").replace("0s", "0,000");
		commHtml=commHtml.replace("High-$400s", "High-$400,000").replace("From the Low-$500s", "From the Low-$500,000");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices(comUrl+commHtml+planHtml, "<span>\\$\\d,\\d{3},\\d{3}</span>|<span>\\s+\\$\\d,\\d{3},\\d{3}\\s+</span>|<span>\\$\\d{3},\\d{3}</span>|<span>\\s+\\$\\d{3},\\d{3}\\s+</span>|From the Low-\\$\\d{3},\\d{3}|from the \\$\\d,\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|From the Mid-\\$\\d{3},\\d{3}|High-\\$\\d{3},\\d{3}|<strong>\\s*\\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
		U.log("minPrice: "+minPrice+" maxPrice: "+maxPrice);
		//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+comsec, "[\\s\\w\\W]{30}starting[\\s\\w\\W]{30}", 0));
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(commHtml.replace("4,300-square-foot amenity center", ""),"\\d,\\d{3}-square-foot|<li>\\d,\\d{3} - \\d,\\d{3} Sq. Ft</li>|<span>\n\\s*\\d,\\d{3}\n\\s*</span>\n\\s*<span>\n\\s*square feet|\\d\\.\\d{3}</span><span>square feet|Square Feet:\\s*<strong>\\s*\\d,\\d{3}", 0);
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("minSqft: "+minSqf+" maxSqft: "+maxSqf);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commHtml, "[\\s\\w\\W]{30}3,042[\\s\\w\\W]{30}", 0));

		String note = U.getnote(commHtml);
		
		String moveHtml=null;
		String moveUrl = U.getSectionValue(commHtml, "<a href=\"move-in-ready", "\"");
		if(moveUrl!=null)
			moveHtml = U.getPageSource("https://terratahomes.com/move-in-ready"+moveUrl);

//		if(moveInData!=ALLOW_BLANK) {
//			if(status==ALLOW_BLANK)
//				status = "Move-in Ready";
//			else if(!status.contains("Move-in Ready"))
//				status+=", Move-in Ready";
//		}
		if(comUrl.contains("https://terratahomes.com/estrella.php"))add[0] = "18310 W Long Lake Road";

		//=========Image ============
		add[0] = add[0].toLowerCase();
		commName = commName.replaceAll("Golf Villas$", "");
		data.addCommunity(commName.toLowerCase(), comUrl, ctype);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(status);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);	
	}j++;
	}
	
}
