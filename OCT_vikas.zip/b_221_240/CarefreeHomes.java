package com.shatam.b_221_240;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;

import org.apache.regexp.recompile;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class CarefreeHomes extends AbstractScrapper {
	static int j=0;
	public static String homeurl = "https://www.carefreehomes.com";
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new CarefreeHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Carefree Homes.csv", a.data()
				.printAll());
	}

	

	public CarefreeHomes() throws Exception {
		super("Carefree Homes", homeurl);
		LOGGER = new CommunityLogger("Carefree Homes");
	}

	static int count = 0;

	public void innerProcess() throws Exception {
		String html = U.getHTML(homeurl);

		String[] regUrlSections = U.getValues(html, "<div class=\"fusion-column-content\">", "</h2>");
		for(String regUrlSec : regUrlSections){
//			U.log(regUrlSec);
			String regUrl = U.getSectionValue(regUrlSec, " href=\"", "\"");
			U.log("RegUrl ::"+homeurl+ regUrl);
			
			String regHtml = U.getHTML(homeurl+ regUrl);
			
			String section = U.getSectionValue(regHtml, "<div class=\"container wpv-loop", "FLOORPLAN COLLECTION</h4>");
//			U.log(section);
			if(section==null)section=ALLOW_BLANK;
			String [] comSections = U.getValues(section, "<div class=\"col-sm-4\">", "</span></a></div>");
			U.log(comSections.length);
			for(String comSec : comSections){
//				U.log("==="+comSec);
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\">");
				String comName = U.getSectionValue(comSec, "uppercase;\">", "</h4>");
//				try {
					commDetails(comUrl, comName, comSec);
//				} catch (Exception e) {}
				
			}
//			break;
		}
		LOGGER.DisposeLogger();
	}

	public void commDetails(String commUrl,String comName, String comSec) throws Exception {
		//TODO : For Single Community Execution
		//
//		if(!commUrl.contains("https://www.carefreehomes.com/communities/utah-new-homes-cecita-crest-at-divario/")) return;
//		if(j >=7)
//try{
		{
			U.log("COUNT--> "+j+"\n"+"comurl--> "+commUrl);
			if(data.communityUrlExists(commUrl))
			{
				LOGGER.AddCommunityUrl(commUrl+"*****repeated*****"); 
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);
	
			
		String html2 = U.getHTML(commUrl);
		
		int quickCount=0;
	
		String pageStatus = U.getSectionValue(html2, "<h2 class=\"title-heading-left fusion-responsive-typography-calculated\"", "</span></h2></div>");
		U.log(commUrl+"==count  ="+ comName);

		// ============ Comm type - Status - Prop Type ==============
		html2 = html2.replaceAll("Horizon Golf Course|george-golf-courses\">golf courses</a>", "");
		String commType = U.getCommunityType(html2.replace("Butterfield Trail Golf Course<br />", ""));
		
		String combinedFloorHtml = null;
		String floorPlanSection = U.getSectionValue(html2, "<div class=\"col-sm-12 community-tabs\">", "QUICK MOVE-IN HOMES</h4></a></li></ul>");
		if(floorPlanSection != null){
			String[] floorUrlSections = U.getValues(floorPlanSection, "<div class=\"col-sm-4\">", "</div>");
			U.log("Floor Homes ::"+floorUrlSections.length);
			int x = 0;
			for(String floorUrlSec : floorUrlSections){
//				U.log(floorUrlSec);
//				if(x++ == 13)break;
				String floorUrl = U.getSectionValue(floorUrlSec, "<a href=\"", "\"");
				if(floorUrl == null)continue;
//				U.log("floorUrl =="+floorUrl);
				String floorHtml = U.getHTML(floorUrl);
				if(floorHtml != null)
					combinedFloorHtml += U.getSectionValue(floorHtml, "<main id=\"main\"", "FLOORPLAN</div>");
			}
		}
		String[] quickurls= U.getValues(html2, "<a href=\"https://www.carefreehomes.com/move-in-ready/", "\"");
		U.log("combinedFloorHtml===="+quickurls.length);
		for(String data:quickurls) {
			data="https://www.carefreehomes.com/move-in-ready/"+data;
//			U.log(data);
			String quickHtm = U.getHTML(data);
			if(quickHtm != null)
				combinedFloorHtml += quickHtm;
		}
		

		//==================== Property Status ==================
		String Status = ALLOW_BLANK;
		html2=html2.replaceAll("QUICK MOVE|Currently there are no move-in ready homes|quick move|Quick Move|Car<br /><strong>\\$Coming|MODELS COMING|being constructed and will be opening |of quick move-in homes|Hours</p><p>Coming Soon|Homes is coming this Spring|sales-title\">Coming Soon!<| (q|Q)uick move-in homes offer all |find a quick move-in home today|find a move-in ready home in one|QUICK MOVE-IN HOMES</h4><|Model Homes opening in the spring of 2019|now open for pre-sale|Move|SALES OFFICE OPENING SOON|\"> Move-In Ready</option>| View Move-Ready Homes</a>|Sandstone Ranch|sandstone-ranch/|MOVE-IN READY</a></li>|quick move-in ready", "");
		html2 = html2.replaceAll("Phase 2<br />\\s+<span>NOW SELLING", "Phase II Now Selling").replaceAll(" all Quick Move|For quick move", "").replace("Arriving<br /> <span>SUMMER 2020", "Arriving SUMMER 2020")
				.replaceAll("few home sites remaining", "Few Homesites Remain")
				;
	//	U.log(Util.matchAll(html2, "[\\w\\s\\W]{30}now selling[\\w\\s\\W]{30}", 0));
		html2 = html2.replace("Move", "").replaceAll("Coming<br />\\s*<span>SOON</span>", "Coming Soon");
		//U.log(html2);
		//U.log("this is comSec:::::::::::::"+comSec);
	//	U.log("=="+Util.match(html2, ".*Now selling.*"));
	//	U.log("MMMMM1"+Util.matchAll(comSec+html2+pageStatus, "[\\s\\w\\W]{100}now open[\\s\\w\\W]{100}", 0));
		Status = U.getPropStatus((comSec.replace("move-in", "")+html2+pageStatus).replace("ready", "").replace("Move-In Ready", "").replaceAll("move|Move", "")
				.replace("MODEL COMING SOON", "")
				.replace("Now<br />\n" + 
						"<span>SELLING", "Now Selling")
				.replace("Model<br />\n" + 
						"<span>COMING SOON", "")
				.replace("Phase 2<br />\n" + 
						"<span>NOW SELLING", "Phase 2 Now Selling")
				.replace("<div class=\"sales-title\">Coming Soon</div></div></a> <a href", "")
				.replace("Model<br />\n\\s*<span>COMING SOON", "")
				.replace("Phase 2<br />\n\\s*<span>NOW SELLING", "Phase 2 NOW SELLING")
				.replaceAll("Our model center is now open|Model Now Open|title\">QUICK MOVE|Hours</p>\n\\s*<p>Coming|Coming Summer 2020, Cecita|Sales Office</p>\n\\s*Coming|Sales Office</p> Coming Soon!|sales-title\">Coming Soon!<|move-in tab", "").replaceAll("move|Move|MOVE", ""));
		Status=Status.replace("Close-out!","Closeout");
		
//		U.log("KKKKKKKK"+Util.matchAll(html2+pageStatus+comSec, "[\\w\\s\\W]{100}move[\\w\\s\\W]{100}", 0));
//		U.log("KKKKKKKK"+Util.matchAll(comSec+html2, "[\\w\\s\\W]{100}phase[\\w\\s\\W]{100}", 0));
		
		Status=Status.replaceAll(", Move-in-ready|Move-in-ready","");
			
			U.log("Status============="+Status);
			
		if(html2.contains("https://www.carefreehomes.com/move-in-ready/") && !html2.contains("Ready Nov/Dec</strong>")){
			Status=Status.replaceAll("Quick Move-in Homes|, Quick Move-in", "");
			if(Status.length()<4)Status="Quick Move-in Homes";
			else Status = Status+", Quick Move-in Homes";
		}
//		U.log("Status11============="+Status);
		
		Status=Status.replace("Quick Move-in Homes, Quick Move-in Homes", "Quick Move-in Homes");
		
		//=========== property type ==================
		html2 = html2.replace(", Loft, ", ", Loft homes, ");
		
		
		String Type = ALLOW_BLANK;

		html2 = html2.replaceAll("chinese-traditional|Chinese \\(Traditional\\)", "")
				.replace("personalization options to customize your new home", "personalization options to a custom-quality your new home");
		if(combinedFloorHtml!=null)
		combinedFloorHtml=combinedFloorHtml.replace("Flex Room", "FLEX Homes");
		//U.log("MMMMM1"+Util.matchAll(combinedFloorHtml, "[\\s\\w\\W]{200}Courtyard[\\s\\w\\W]{100}", 0));
		Type = U.getPropType(html2+combinedFloorHtml);
		
		String dType = ALLOW_BLANK;
		html2=html2.replace("one-and two-story", " 1 Story  2 Story ").replace("one or two-story home", "1 story  2 story");
		if(combinedFloorHtml != null)
			combinedFloorHtml = combinedFloorHtml.replaceAll("Level</div>\\s*<div class=\"col-md-6\">(\\d\\.?\\d?)<", "> $1 Story<");
		
	//	U.log("MMMMM1"+Util.matchAll( html2+combinedFloorHtml, "[\\s\\w\\W]{100}ranch[\\s\\w\\W]{100}", 0));
		dType = U.getdCommType((html2+combinedFloorHtml).replace("branch", ""));
		
		String notes = ALLOW_BLANK;
		notes = U.getnote(html2);

		
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
		String flag = "FALSE";
		
		String addSec = U.getSectionValue(html2, "Sales Office</p>", "<div style");
		addSec = addSec.replaceAll(". El Paso", ", El Paso").replaceAll(", USA", "").replace("TX, 79938", "TX 79938")
				.replace(" El Paso TX ", " El Paso, TX ").replace("El Paso, 79938", "El Paso, TX 79936 ").replace(", TX,", ", TX ");
		U.log("AddSec ::"+addSec);
		add = U.getAddress(addSec);
//		U.log("sff "+add[0]);
		
		latlng[0] = U.getSectionValue(html2, "data-markerlat=\"", "\"");
		latlng[1] = U.getSectionValue(html2, "data-markerlon=\"", "\"");
		U.log("latlng::"+Arrays.toString(latlng)); 

		if(add[0]!=ALLOW_BLANK && add[1]!=ALLOW_BLANK && add[2]!=ALLOW_BLANK && add[3]==ALLOW_BLANK ) {
			add[3]=U.getGoogleAddressWithKey(latlng)[3];
			flag="True";
		}
		U.log("add::"+Arrays.toString(add)); 
		
		if(latlng[0]==null)latlng[0]=latlng[1]=ALLOW_BLANK;
		
		if(latlng[0].length()>4 && (add[3].length()<4 || add[0].length()<4)){
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			flag ="True";
		}
		
		U.log("Address::"+Arrays.toString(add)); 
		
		if(add[0].length()<4 && latlng[0].length()<4){
			add = new String[] {"1265 Joe Battle Boulevard Building C", "El Paso", "TX", "79936"};
			latlng = new String[]  {"31.711036", "-106.278498"};
			flag = "TRUE";
			notes = "Address and LatLng Taken Contact Us Page";
		}
		
		
		if((latlng[0] == ALLOW_BLANK||latlng[0] == null) && add[0]!=null) {
			
			latlng = U.getlatlongGoogleApi(add);
			flag = "TRUE";
		}
		U.log("latlng 2::"+Arrays.toString(latlng)); 
		
		if(add[3]==ALLOW_BLANK) {
			
			String[] adds = U.getAddressGoogleApi(latlng);
			add[3] = adds[3];
			
		}
		
		// =======================Area ===================
		
		String[] area ={ALLOW_BLANK,ALLOW_BLANK};
		area=U.getSqareFeet(html2, 
				"\\d,\\d{3} SqFt|</span>\\d,\\d{3} SqFt |from \\d,\\d{3} square feet to \\d,\\d{3} square feet|size \\d,\\d+ to \\d,\\d+ square feet|sqft = \"\\d+,\\d+\"| sqft = \"\\d{3}\"|<p>(\\d,)*\\d+ SqFt ", 0);
		area[0] = (area[0] == null) ? ALLOW_BLANK : area[0];
		area[1] = (area[1] == null) ? ALLOW_BLANK : area[1];
		// ==================== Prices =================
		
		html2 = html2.replaceAll("0's", "0,000");
		comSec= comSec.replaceAll("00's", "00,000");
		String[] Prices = U.getPrices(comSec + html2, "\\$\\d,\\d+,\\d+|\\$\\d+,\\d+| price = \"\\d+,\\d+\";", 0);
		
		
		Prices[0] = (Prices[0] == null) ? ALLOW_BLANK : Prices[0];
		Prices[1] = (Prices[1] == null) ? ALLOW_BLANK : Prices[1];
//		if(commUrl.contains("https://www.carefreehomes.com/communities/utah-new-homes-arroyo-at-sienna-hills/"))Status="Arriving Spring 2020";
		Type=Type.replace("Patio Home,Covered Patio", "Covered Patio");
		add[0]=add[0].replace("12427 Stansbury Dr","12442 Stansbury").replace(" %26 ", " & ");
		//if(commUrl.contains("/horizon-town-center/"))Status="Coming Soon";//Image
		if(add[1].contains("El Paso"))add[2]="TX";
		comName = comName.replace("Painted Desert / Morningside", "Painted Desert & Morningside at Mission Ridge");
		if(commUrl.contains("https://www.carefreehomes.com/communities/tierra-del-este-81/")) Status += ", Now Selling";
		
//		if(commUrl.contains("https://www.carefreehomes.com/communities/tres-suenos"))flag="TRUE";
//	    if(commUrl.contains("https://www.carefreehomes.com/communities/desert-sands"))Status=Status+", Phase 2 Now Selling";
		
//		if(commUrl.contains("https://www.carefreehomes.com/communities/emerald-heights/"))Status=Status+ ", Now Open";
		if(Status.length()<1)Status=ALLOW_BLANK;
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(comName.replace(" &#8211; CareFree Homes", ""), commUrl, commType);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
		data.addPrice(Prices[0], Prices[1]);
		data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(area[0], area[1]);
		data.addPropertyType(Type, dType);
		data.addPropertyStatus(Status);
		data.addNotes(notes);
		count++;
		}
		j++;
	}
//}catch(Exception e) {}
//
//	}

	public String RedirectedURL(String url) throws Exception {
		URLConnection con = new URL(url).openConnection();
		//System.out.println( "orignal url: " + con.getURL() );
		con.connect();
		 //System.out.println( "connected url: " + con.getURL() );
		InputStream is = con.getInputStream();
		// System.out.println( "redirected url: " + con.getURL() );
		String RedUrl = con.getURL().toString();
		is.close();
		return RedUrl;
		
	}
}