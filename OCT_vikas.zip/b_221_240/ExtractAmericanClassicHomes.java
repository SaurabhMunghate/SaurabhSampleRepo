/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractAmericanClassicHomes extends AbstractScrapper{
	static String mainHtml;
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	
	private static String builderUrl = "https://www.americanclassichomes.com";
	public ExtractAmericanClassicHomes()
			throws Exception {
		super("American Classic Homes",builderUrl);
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("American Classic Homes");
	
		
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractAmericanClassicHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"American Classic Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);
 
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://www.americanclassichomes.com/new-homes/");
		String[] comSec=U.getValues(mainHtml,"<div class=\"card oi-map-item home-detail-card","Details</a>");
		for(String comData:comSec)
		{
			String comUrl=builderUrl+U.getSectionValue(comData, "href=\"","\"");
//			try {
				addDetails(comUrl,comData);
//			} catch (Exception e) {}
			
		}
		U.log(comSec.length);
		LOGGER.DisposeLogger();
		
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	if(!comUrl.contains("https://www.americanclassichomes.com/new-homes/wa/seattle/wallingford-spot-lots/7715/"))return;
//		if(j==9)
		
//		try{
		{
		U.log(j+"   commUrl-->"+comUrl);
		
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"------------> Repeated");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
				String html=U.getHTML(comUrl);
				U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}832[\\s\\w\\W]{30}", 0));
				html=U.removeSectionValue(html, "View All Communities</a></h5>", "<style>");
				String rem=U.getSectionValue(html, "<head>","class=\"dropdown-menu\">");

				if(rem!=null)
					html=html.replace(rem,"");
				//============================================Community name=======================================================================
//				U.log(comData);
				String communityName = U.getSectionValue(comData, "<h3 class=\"title\">", "<");
				
				communityName=communityName.replace("Seattle: ", "").replaceAll("Community|Spot Lot Homes", "");
				U.log("community Name---->"+communityName);
		//================================================Address section===================================================================
				String note="";
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				html=U.removeComments(html);
				 String addSec=U.getSectionValue(html, "[{\"address\":\"","\",");
					
				 U.log("kkkkkk"+addSec);
				 if(addSec!=null)
				 {
				 addSec=addSec.replace("Homesite #1<br>", "").replace("<br>",",");//.replace(" WA ", ", WA ");
				 if(addSec.startsWith(","))addSec=addSec.replaceFirst(",", "").trim();
				 String[] add1=addSec.split(",");
				
				 U.log(Arrays.toString(add1));
				
				 if(add1.length==3)
				 {
					 add[0]=add1[0];
					 add[1]=add1[1];
					 add1[2]=add1[2].trim();
					 if(add1[2].contains(" ")) {
						// U.log("add1[2]:::::::"+add1[2]);
					 add[3]=Util.match(add1[2],"\\d{4,}");
					 add[2]=add1[2].replace(add[3],"").trim();
					 }
				 }
				 else if(add1.length==2 && Util.match(add1[1],"\\d{4,}")!=null)
				 {
					 U.log("add1[0]:::::::"+add1[0]);
					 add[1]=add1[0];
					 add[3]=Util.match(add1[1],"\\d{4,}");
					 add[2]=add1[1].replace(add[3],"").trim();
				 }
				 }
				 add[0] = add[0].replace("Call to Tour Model", ALLOW_BLANK);
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				
		//--------------------------------------------------latlng----------------------------------------------------------------
				add[0]=add[0].trim();
				String laSec=U.getSectionValue(html, "href=\"//maps.google.com/maps?q=","\"");
				if(laSec!=null)
				{
				latlag=laSec.split(",");
				}
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				if((add[0].length()<4 || add[3]==ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK)
				{
					try {
					add=U.getAddressGoogleApi(latlag);}
					catch (Exception e) {
						if(add == null) add = U.getAddressHereApi(latlag);
					}
					
					geo="TRUE";
				}
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
				}
				
				
				
		//============================================Price and SQ.FT======================================================================
				//U.log(rem);
				String floorHtml = ALLOW_BLANK;
				String[] flooeSec = U.getValues(html, "<div class=\"card home-detail-card \"", "</ul>");
				
				for(String floor : flooeSec) {
					
					try {
						floorHtml += U.getSectionValue(U.getPageSource(builderUrl+U.getSectionValue(floor, "href=\"", "\"")),"id=\"details-anchor\">","</section>")+
								 U.getSectionValue(U.getPageSource(builderUrl+U.getSectionValue(floor, "href=\"", "\"")),"<section class=\"interior-hero large\">","</section>");
					}catch (Exception e) {
						// TODO: handle exception
					}
					
				}

				String quickHtml = ALLOW_BLANK;
				String qForm = U.getHTML("https://www.americanclassichomes.com/new-homes/available/");
				
				String[] qSec = U.getValues(qForm, "<div class=\"card oi-map-item home-detail-card", "Details</a>");
				int quickCount =0;
				int soldCount=0;
				for(String quick : qSec) {
//					U.log(quick.contains(communityName.trim()));
					if(quick.contains(communityName.trim())) {
//						U.log(">>>>>>>>>>>>");
						try {
							U.log(" q"+quickHtml);
							quickHtml += U.getSectionValue(U.getPageSource(builderUrl+U.getSectionValue(quick, "href=\"", "\"")),"<section class=\"interior-hero large\">","<section class=\"contact-form-container image\">");
//							 U.getSectionValue(U.getPageSource(builderUrl+U.getSectionValue(quick, "href=\"", "\"")),"id=\"details-anchor\">","</section>")
							if(!quickHtml.contains("Under Construction")) {
							quickCount++;
							}
							
						}catch (Exception e) {
							// TODO: handle exception
						}
//						U.log("quickCount=="+quickHtml);
					}
					
				}
				
				U.log("quic cou"+quickCount);
				ArrayList<String> sold=Util.matchAll(quickHtml, "<button class=\"spec-status\">\\s*Sold: Under Contract\\s*<", 0);
				soldCount=sold.size();
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				html=html.replaceAll("0�s|0's|0&#8217;s|0s","0,000");
				String prices[] = U.getPrices(html+comData+floorHtml+quickHtml,"From \\$\\d,\\d{3},\\d{3}|Priced At <span>\\$\\d,\\d{3},\\d{3}</span>|SOLD \\$\\d,\\d+,\\d{3}|From Mid \\$\\d+,\\d+|From \\$\\d+,\\d+,\\d+|<h4>\\$\\d+,\\d+,\\d+|<h4>\\$\\d+,\\d+<br>|from \\$\\d+,\\d+|from: \\$\\d+,\\d+", 0);
				 minPrice= (prices[0] == null) ? ALLOW_BLANK : prices[0];
				 maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				U.log(Arrays.toString(prices));
				//maxPrice=prices[1];minPrice=prices[0];
				U.log("Price--->"+minPrice+" "+maxPrice);

		//======================================================Sq.ft===========================================================================================		
				
				
				String[] sqft = U
						.getSqareFeet(
								(html+comData+floorHtml+quickHtml).replace("total of 4,090 approx", ""),
								"<i class=\"ois-ruler-angle\"></i>\\d,\\d{3}|<li aria-label=\"Square Footage Range\">\\s*<i class=\"ois-ruler-angle\"></i>\\d,\\d{3}|<li aria-label=\"Square Footage Range\">\\s*<i class=\"ois-ruler-angle\"></i>\\d,\\d{3}-\\d,\\d{3}|approx. \\d,\\d{3} square feet |\\d,\\d{3} approx. square feet|</i>\\d{1},\\d{3}-\\d{1},\\d{3}</li>|<li aria-label=\"Square Footage Range\"><i class=\"ois-ruler-angle\"></i>\\d,\\d{3}</li>",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//				U.log(">>>>>>>>>>>>"+Util.matchAll(html+comData+floorHtml+quickHtml, "[\\s\\w\\W]{30}832[\\s\\w\\W]{30}", 0));

				
		//================================================community type========================================================
				
				String communityType=U.getCommType((html+comData).replaceAll("Pine Lake [c|C]ommunity", ""));
				
		//==========================================================Property Type================================================
				if(quickHtml!=null)
					quickHtml = quickHtml.replaceAll("traditional millwork", "");
				String proptype=U.getPropType((html+floorHtml+quickHtml+quickHtml+floorHtml).replace("luxurious and spacious master suite", "").replace("suite for multi-generational", "").replace("flex space", "Flex Room").replaceAll("No HOA Dues|No HOA dues", "").replace("efficient multi-generational", ""));
//				U.log(">>>>>>>>>>>>"+Util.matchAll(html+floorHtml+quickHtml+quickHtml+floorHtml, "[\\s\\w\\W]{30}luxur[\\s\\w\\W]{30}", 0));
//				U.log(">>>>>>>>>>>>"+Util.matchAll(html+floorHtml+quickHtml+quickHtml+floorHtml, "[\\s\\w\\W]{30}multi[\\s\\w\\W]{30}", 0));
		//==================================================D-Property Type======================================================
				comData = comData.replaceAll("<li aria-label=\"Number of possible Floors\"><i class=\"ois-stairs\"></i>", " Story ");
				
				quickHtml=quickHtml.replaceAll("<li aria-label=\"Number of possible Floors\">\n" + 
						"                      <i class=\"ois-stairs\">\n" + 
						"                      </i>", "<li aria-label=\"Number of possible Floors\">Story ")
						.replaceAll("<li aria-label=\"Number of possible Floors\">Story \\s*", "<li aria-label=\"Number of possible Floors\">Story ");
				
				html =html.replaceAll("<li aria-label=\"Number of possible Floors\">\n" + 
						"                        <i class=\"ois-stairs\"></i>2", "<li aria-label=\"Number of possible Floors\"></i>2 story")
						
						.replace("two or two and one-half stories", "two stories or 2.5 stories").replaceAll("branches", "")
						.replace("Floors\"><i class=\"ois-stairs\"></i>2", "2 story").replaceAll("Number of possible 2 story|<li aria-label=\"Number of possible Floors\"><i class=\"ois-stairs\"></i>", " Story ");
				
				
				String dtype=U.getdCommType((html.replace("Story 2", "")+comData+floorHtml+quickHtml).replace("third floor", ""));//+comData+floorHtml+quickHtml);  //+comData+floorHtml+quickHtml
	
//				U.log("============"+Util.matchAll((quickHtml), "[\\s\\w\\W]{30}Story[\\s\\w\\W]{30}",0));
				//============================================note====================================================================
		
				note=U.getnote(html);
				
		//==============================================Property Status=========================================================
				String head = U.getSectionValue(html, "<div class=\"col_right\">", "</div>");
				if(head == null)head = "";
				html = html.replaceAll("Coming Soon\">|<span>Now Available</span>|Now Available for Pre-sale|Just Released for Sale|newest premium community coming soon|<h5>\\s+Now Available<br />|<h5>\\s+Now Available", "");
				html=U.removeSectionValue(html, "View Photos</span></div></div>", "<footer");
				
				String pstatus=U.getPropStatus((html+comData+mainHtml+head).replace("Now Available</a></div><div", "").replace("Coming Soon</a></div><div", "").replace("Sold<br />", "Sold Out").replaceAll("Sold: Under Contract|Quick Delivery Homes|Coming Soon\">|Quick Move-ins</span>|Quick Move-Ins Available</span>",""));
//				U.log("============"+Util.matchAll((html+comData+mainHtml+head), "[\\s\\w\\W]{30}sold[\\s\\w\\W]{30}",0));
//				U.log("============"+Util.matchAll((comData), "[\\s\\w\\W]{30}Now Available[\\s\\w\\W]{30}",0));

				
				
				U.log(quickCount+":LLLLL"+soldCount);
				//Not Required
//				if(quickHtml!=ALLOW_BLANK && quickCount>soldCount) {
//					if(pstatus==ALLOW_BLANK)
//						pstatus = "Quick Delivery Homes";
//					else
//						pstatus += ", Quick Delivery Homes";
//				}
				U.log("Status:: "+pstatus);

				if(add[2].length()>2)
				{
				add[2] = USStates.abbr(add[2]);
				}
				if(pstatus.length()==0)pstatus=ALLOW_BLANK;
				
				if(comUrl.contains("/new-homes-seattle/windermere-spot-lots"))pstatus=pstatus.replace("Coming Soon", "New Homes Coming Soon");
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
				// ------------------ No. of units ------------------------
				String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
				

					data.addUnitCount(units);
					data.addConstructionInformation(startDt, endDt);	
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note);
			}
					j++;
					
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
	}
	
//	public static String getRedirectedURLConnection(String url) throws IOException{
//		String newUrl=null;
//		URL obj = new URL(url);
//		HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
//		int status = conn.getResponseCode();
//		if (status != HttpURLConnection.HTTP_OK) {
//			if (status == HttpURLConnection.HTTP_MOVED_TEMP
//				|| status == HttpURLConnection.HTTP_MOVED_PERM
//					|| status == HttpURLConnection.HTTP_SEE_OTHER){
//				newUrl = conn.getHeaderField("Location");
//			}
//			return newUrl;
//		}
//		else
//		return url;
//
//	}

}
