/*sampada santosh*/
package com.shatam.b_221_240;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractCachetHomes extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "https://www.cachethomes.net/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractCachetHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Cachet Homes.csv", a.data()
				.printAll());
 
	}

	public ExtractCachetHomes() throws Exception {

		super("Cachet Homes", "https://www.cachethomes.net/");
		LOGGER = new CommunityLogger("Cachet Homes");
	}

	public void innerProcess() throws Exception {
		String basehtml = U.getHTML("https://www.cachethomes.net/communities/");
		String section = U.getSectionValue(basehtml,
				">FIND A HOME</a>", "<ul class=\"page-tel\">");
//		U.log(section);
		String values[] = U.getValues(section,
				"<li class=\"menu-item menu-item-type-",
				"Learn More");

		for (String value : values) {
			String url = U.getSectionValue(value, "<a href=\"", "\"");
			String name = U.getSectionValue(value, "/\">", "<img src");
			U.log("url : " + url);
			U.log("name : " + name);
			addDetails(url, name,value);

		}

	}

	public void addDetails(String url, String communityName,String value) throws Exception {
		
		if(data.communityUrlExists(url))	{
			LOGGER.AddCommunityUrl("::::::::::repeat::::::::::"+url);
			return;
		}
		
		LOGGER.AddCommunityUrl(url);
		
		String html = U.getHTML(url);
		if(!url.contains("https://www.idealhomes.com/neighborhoods/moore/abbot-lake"))return;
		
		
		// -----------adress---------//
		String geo = "True";

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		
		html = html.replace("pdf\" target=\"_blank\" rel=\"noopener", "");
		String ad=U.getSectionValue(html, "https://www.google.com/maps/dir//", "/@");
		String latLongSec=U.getSectionValue(html, "href='https://www.google.com/maps/dir//", "z/data=");
		if(ad!=null){
				ad=ad.replace("+", " ").replace(", USA", "");
				U.log(ad);
					add = U.getAddress(ad);
					U.log("address is : "+Arrays.toString(add));
					latLong[0]=Util.match(latLongSec, "\\@\\d{2}\\.\\d{2,},").replace("@", "").replace(",", "");
					latLong[1]=Util.match(latLongSec, "\\-\\d{3}\\.\\d{2,},");
					U.log(Arrays.toString(latLong));
					 geo = "False";
		}
		if(add[0]==ALLOW_BLANK&& latLong[0]==ALLOW_BLANK) {
			String add1=U.getSectionValue(html, "target='_blank' class='loc-link'>", ", USA</a>");
			if(add1!=null) {
				String ad12[]=add1.split(",");
				add[0]=ad12[0];
				add[1]=ad12[1];
				add[2]=ad12[2];
				add[3]=ALLOW_BLANK;
				U.log(Arrays.toString(add));
		}
		}
		
		if(ad==null)ad = U.getSectionValue(html,
				"target='_blank' class='loc-link'>",
				" </a></p>");
		U.log("address sec--> "+ad+"*&*&*");
		
		
		
		if(url.contains("https://www.cachethomes.net/monterey-ridge/")){
			ad = U.getSectionValue(html, "</iframe></p>", "</p>");
			ad = ad.replaceAll("<a href=\"(.*?)_blank\">|</a>", "");
			
		}
		if(url.contains("https://www.cachethomes.net/fox-haven/")){
			ad = U.getSectionValue(html, "><a href=\"https://www.google.com/maps/place/", "/@");
		}

		if (ad != null) {
			ad = ad.replace("<br />", ",").replace(" | ", ",").replace("<p style=\"text-align: center;\">", "").replace(",+", ",").replace("+", " ")
					.replaceAll("<h3 .*>.*</h3>", "");
			U.log(ad);
			if(ad.contains(",")) {
			add = U.getAddress(ad);
			U.log("address is : "+Arrays.toString(add));
			}

		}

		
		String latLongsec = U.getSectionValue(html, "<div class=\"list-group-item\" data-link='", "</div>");
		
		if (latLongsec != null && latLong[0]==ALLOW_BLANK) {
			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d+.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		if(latLongsec==null&& latLong[0]==ALLOW_BLANK) {
			latLong[0] = U.getSectionValue(html, "\"latitude\":", ",").trim();
			latLong[1] = U.getSectionValue(html, "\"longitude\":", "},").trim();
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}
		if (add[0].length() == 0) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[0] = addr[0];
			geo = "TRUE";
		}

		if (add[2].length() >2 && latLong[0].length()>4 && add[3].length()!=5) {
			U.log("vikas");
			U.log(Arrays.toString(add));
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			U.log(Arrays.toString(add));
			geo = "TRUE";
		}
		
		
		if (add[2].length() <2 && latLong[0].length()>4) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[3] = addr[3];
			geo = "TRUE";
		}
		if(add[0]==null||add[0]==ALLOW_BLANK)
		{
			add = U.getAddressGoogleApi(latLong);
			geo ="True";
			
		}
		if(latLong[0].length()<4 && add[0]!=ALLOW_BLANK)
		{
			latLong = U.getlatlongGoogleApi(add);
			geo ="True";
			
		}
		

		// ---------community type,property type,property status,derived,
		// property type---------//
		//---------Quick homes data-------------
		String allQuickSec = ALLOW_BLANK;
		if(html.contains("VIEW QUICK-MOVE HOMES &gt;</a>")||html.contains("VIEW INVENTORY HOMES &gt;</a"))
		{
//			U.log("quickUrl: "+U.getSectionValue(html, "<a class=\"btn\" href=\"", "\">VIEW INVENTORY HOMES &gt;</a>"));
			U.log("quickUrl : "+"https://www.cachethomes.net/quick-move/#"+communityName.toLowerCase().replace(" ", "-").replace("union-park", "union"));
		String quikurl=U.getSectionValue(html, "<a class=\"btn\" href=\"", "\">VIEW QUICK-MOVE HOMES &gt;</a>");
		if(quikurl==null)quikurl=U.getSectionValue(html, "<a class=\"btn\" href=\"", "\">VIEW INVENTORY HOMES &gt;</a>");
		if(quikurl==null)quikurl=U.getSectionValue(html, "<a class=\"btn btn-block\" href=\"", "\">VIEW QUICK-MOVE HOMES &gt;</a>");
//		U.log(quikurl);
		String quickhtml = U.getHTML(quikurl);
		
		String[] quickComSec = U.getValues(quickhtml, "<div class=\"rooms", "</div></form></div>");
		U.log(quickComSec.length);
		for(String quick : quickComSec){
//			U.log("--------------\n"+quick);
			if(quick.contains(communityName.toLowerCase().replace(" ", "-").replace("union-park", "union"))){
				U.log(quick);
				allQuickSec = quick;
			}
		}
		}
		
		String removePro=U.getSectionValue(html, "Available Communities</h2>", "</p>");
		if(removePro!=null) {
			html=html.replace(removePro, "");
		}
		String[] removeScript=U.getValues(html, "<script", "</script>");
		for(String rem:removeScript) {
			
				html=html.replace(rem, "");
		}
		html = html
				.replace("are in luxury custom homes", "")
				.replaceAll("Outdoor-courtyard.jpg|wigwam/luxury-townhomes/\">Luxury Townhomes</a></li>|center;\">COMING SOON|wigwam/single-family-homes/\">Single Family Homes</a></li>|wigwam/luxury-condominiums/\">Luxury Condominiums</a></li>", "");
		U.log(">>>>>>"+Util.matchAll(html, "[\\w\\s\\W]{50}now selling[\\w\\s\\W]{30}", 0));
		String removeSec=U.getSectionValue(html, " <ul id=\"menu-main-left\" cl", "<div id=\"main\">");
		String[] removeMultiSec=U.getValues(removeSec, "<li class=\"menu-item menu-i", "</strong></p>");
		for(String re:removeMultiSec) {
			if(!re.contains(url)) {
				html=html.replace(re, "");				
			}
		}
		
		allQuickSec=allQuickSec.replaceAll("<li>2-Story</li>", "2 Story,");
		String commType = U.getCommunityType(html);
		String propType = U.getPropType(html+allQuickSec);
		String dpType = U.getdCommType((html+allQuickSec).replace("Gainey Ranch\",\"McCormich Ranch\"", ""));
		String commStatus = ALLOW_BLANK;
		
		html=html.replace("Coming Soon!</p>", "").replace("status coming-soon'>", "").replace("Coming Soon Summer, 2022", "Coming Soon Summer 2022");
		commStatus=U.getPropStatus(html);
		U.log(commStatus);

		if(allQuickSec.length()>4 && !commStatus.contains("quick")){
			if(commStatus.length()<4){
				commStatus = "Quick Move In Homes";
			}
			else{
				commStatus = commStatus+", Quick Move In Homes";
			}
		}
		
		// --prices---//
		html = html.replace("$2 million", "$2,000,000").replace("0’s", "0,000").replace("1.5 million", "1,500,000 million").replace("1.6 million", "1,600,000");
		String[] price = U.getPrices(html+allQuickSec,
				"Priced at \\$\\d+,\\d+,\\d+|Priced at \\$\\d+,\\d+|Starting at \\$\\d+,\\d+,\\d+|Starting at \\$\\d+,\\d+|\\$\\d+,\\d+,\\d+|\\$\\d+,\\d+|Priced at \\$\\d+,\\d+,\\d+ ", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(html+allQuickSec, "\\d,\\d{3} sq. ft.|<li>\\d,\\d{3} Square Feet</li>|home \\d,\\d+ sq. ft|\\d+,\\d+ - \\d+,\\d+ Square| \\d+,\\d+ to \\d+ square feet |\\d+,\\d+ Square Feet|\\d,\\d{3} sq ft. on over", 0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		if(url.contains("/monterey-ridge/"))dpType=dpType+", 2 Story";
		//U.log(allQuickSec);
		// ---notes-----//

		data.addCommunity(communityName, url, commType);
		data.addAddress(U.getNoHtml(add[0]), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].replace(",", "").trim(), latLong[1].replace(",", "").trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus); 
		data.addNotes(U.getnote(html));
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);

	}

}