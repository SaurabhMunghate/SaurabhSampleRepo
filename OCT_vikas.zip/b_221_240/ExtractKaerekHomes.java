/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractKaerekHomes extends AbstractScrapper{
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;

	public ExtractKaerekHomes()	throws Exception {
		super("Kaerek Homes","https://kaerekhomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Kaerek Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractKaerekHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Kaerek Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=null;
		String mainUrl="http://kaerekhomes.com/lots/";

		for(int i=1;i<=3;i++) {
			mainHtml+=U.getHTML("https://kaerekhomes.com/lots/page/"+i+"/");
		}
		String[] comsec=U.getValues(mainHtml, "<h2 class=\"title property-title\"", "/p>");

		
		for(String sec: comsec) {
			String comUrl=U.getSectionValue(sec, "<a href=\"","\"");
			
			String name=U.getSectionValue(sec, "headline\">","</h2>");
			name=U.getSectionValue(name, ">", "<");
			U.log(name);
			String homesData=ALLOW_BLANK;

			String homehtml = U.getHTML("https://kaerekhomes.com/homes/");
			String[] homeValues = U.getValues(homehtml, "<h2 class=\"title property-title\"", "/p>");
		for(String home:homeValues) {
			if(home.contains(name)) {
				String lnk=U.getSectionValue(home, "<a class=\"continuelink\" href=\"", "\"");
				U.log(lnk);
				homesData+=U.getHTML(lnk);
				addDetails(comUrl,sec,homesData);
			}
		}
		addDetails(comUrl,sec,homesData);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData,String homes) throws Exception {
//	if(!comUrl.contains("https://kaerekhomes.com/properties/haass-farms/"))return;
//	try{
	{
		U.log(j+"   commUrl-->"+comUrl);
		
		
		if(data.communityUrlExists(comUrl))	{
			LOGGER.AddCommunityUrl("::::::::::repeat::::::::::"+comUrl);
			k++;
			return;
		}
		
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHTML(comUrl);
		
		/*String rem=U.getSectionValue(html, "<head>","$919,990");
		html=html.replace(rem,"");*/
//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "headline\">","</h2>");
		communityName=U.getSectionValue(communityName, "\">","<");
		
		U.log("community Name---->"+communityName);
		
//================================================Address section===================================================================
		String note="";
		note=U.getnote(html);
		
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		String addSec = U.getSectionValue(html, "itemprop=\"text\">", "</p>");
//		U.log(addSec);
		if(addSec != null){
			addSec = addSec.replaceAll("(.?)*<br />", "").replaceAll("\\s{2,}", "")
					.replace("&amp;", "&");
			U.log("addSec==="+addSec);
			if(addSec.contains(","))
			{
			add=U.getAddress(addSec);
			U.log(Arrays.toString(add));
			}
		}
	U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
			
//--------------------------------------------------latlng----------------------------------------------------------------
		add[0]=add[0].trim();
		String laSec=U.getSectionValue(html, "ICBM\" content=\"","\"");
		if(laSec!=null)
		{
		latlag=laSec.split(",");
		}
		
		if((add[0]==ALLOW_BLANK || add[3]==ALLOW_BLANK) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if(comUrl.contains("http://kaerekhomes.com/properties/prairie-creek-ridge/")){
//		if(add[3]==ALLOW_BLANK && latlag[0]==ALLOW_BLANK){
			add[0]="Prairie Creek Blvd";
			add[1]="Oconomowoc";
			add[2]="WI";
			add[3]="53066";
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			note="Address Taken From Community Map";
			geo="TRUE";
		}
		if(comUrl.contains("woodleaf-reserve-phase-4/")) {
			add[1]="Pewaukee";
			add[2]="WI";
			latlag =U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="True";
			note ="Address & LatLng Taken From City & State";
		}
		
		if(comUrl.contains("properties/brookdale-estates/")) {
			add[0]="Village of Menomonee Falls";
			add[1]=ALLOW_BLANK;
			add[2]="WI";
			add[3]=ALLOW_BLANK;
			latlag =U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="True";
			note ="Address & LatLng Taken From City & State";
		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		if(comUrl.contains("https://kaerekhomes.com/properties/haass-farms/"))
		{	
			add[0]=U.getSectionValue(html, "<p>Directions: Lake Five Rd north to", "</p>").trim();
			add[1]=U.getSectionValue(html, "<p>Town of ", "<br />").trim();
			add[2]=U.getSectionValue(html, "><p>Town of Lisbon<br />", "</p>").replace("Waukesha County", "WI").trim();
			add[3]=ALLOW_BLANK;
			latlag=U.getlatlongGoogleApi(add);
			String[] add1=U.getAddressGoogleApi(latlag);
			add[3]=add1[3];
			geo="TRUE";
		}
		
		
//============================================Price and SQ.FT======================================================================
			
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		html=html.replaceAll("0�s|0's|0&#8217;s|0s","0,000");
		String prices[] = U.getPrices(html+comData+homes,"price\">\\$\\d+,\\d+|Starting at \\$\\d+,\\d+|start at \\$\\d+,\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
		
//======================================================Sq.ft===========================================================================================		
		
		
		String[] sqft = U
				.getSqareFeet(
						html+comData+homes,
						"[1-9]\\d+</span> Sq Ft|[1-9],\\d+ square feet|Square Feet: \\d{4}",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
		
//================================================community type========================================================
			
		String communityType=U.getCommType(html+comData);
		
//==========================================================Property Type================================================
		
		String proptype=U.getPropType(html);
		
//==================================================D-Property Type======================================================
		
		String dtype=U.getdCommType((html+comData+homes).replaceAll("[F|f]loor", ""));

		
//==============================================Property Status=========================================================
		String pstatus=U.getPropStatus(html+comData);
		
//============================================note====================================================================
		
		if(add[2].length()>2){
		add[2] = USStates.abbr(add[2]);
		}
		communityName = communityName.replaceAll(", Addition #1$", "");
		if(comUrl.contains("https://kaerekhomes.com/properties/prairie-creek-ridge")) {
			add[0]="11600 W. Lincoln Ave";
			add[1]="West Allis";
			add[2]="WI";
			add[3]="53227";
			latlag=U.getlatlongGoogleApi(add);
			geo="True";
		}
		
		if(comUrl.contains("https://kaerekhomes.com/properties/weretta-woods/"))dtype=ALLOW_BLANK;
		U.log("commName::"+communityName);
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
	j++;
//	}catch(Exception e){}
		
	}

}