/**
 * @author Parag Humane 
 * @date 19/04/2012
 * 
 */
package com.shatam.b_221_240;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMarranoHomes extends AbstractScrapper {
	static int i=0;
	CommunityLogger LOGGER;
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractMarranoHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Marrano Marc Equity Corp.csv", a.data().printAll());
		}
	
	public ExtractMarranoHomes() throws Exception {

		super("Marrano Marc Equity Corp", "https://www.marrano.com/");
		LOGGER = new CommunityLogger("Marrano Marc Equity Corp");
	}

	@Override
	protected void innerProcess() throws Exception {
//		[Link for below method taken from region page to get lat and lng and address]
		JsonParser json = new JsonParser();
		//String jsonHtml = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway", "{\"operationName\":\"GetCommunitiesLite\",\"variables\":{\"clientName\":\"marrano\"},\"query\":\"query GetCommunitiesLite($clientName: String!, $bonafide: Boolean) {\\n  communities(clientName: $clientName, active: true, bonafide: $bonafide) {\\n    id\\n    name\\n    logo\\n    longitude\\n    latitude\\n    thumb\\n    bonafide\\n    pricing\\n    agents(clientName: $clientName) {\\n      id\\n      email\\n      phone\\n      firstName\\n      lastName\\n      __typename\\n    }\\n    cityLocation(clientName: $clientName) {\\n      id\\n      name\\n      customName\\n      stateCode\\n      metroName\\n      metroCustomName\\n      zip\\n      postCode\\n      __typename\\n    }\\n    plans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      name\\n      bedRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      bathRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      costRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      sizeRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      src\\n      siteplanType\\n      geoInfo(clientName: $clientName) {\\n        id\\n        siteplanId\\n        neLatitude\\n        neLongitude\\n        swLatitude\\n        swLongitude\\n        geoJson\\n        __typename\\n      }\\n      __typename\\n    }\\n    lots(clientName: $clientName) {\\n      id\\n      salesStatus\\n      inventory(clientName: $clientName) {\\n        id\\n        price\\n        sqft\\n        beds\\n        baths\\n        elevationId\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}");
		String jsonHtml = sendPostRequestAcceptJson("https://nexus.anewgo.com/api/graphql_gateway","{\"operationName\":\"GetCommunitiesLite\",\"variables\":{\"clientName\":\"marrano\"},\"query\":\"query GetCommunitiesLite($clientName: String!, $bonafide: Boolean) {\\n  communities(clientName: $clientName, active: true, bonafide: $bonafide) {\\n    id\\n    name\\n    logo\\n    longitude\\n    latitude\\n    thumb\\n    bonafide\\n    pricing\\n    agents(clientName: $clientName) {\\n      id\\n      email\\n      phone\\n      firstName\\n      lastName\\n      __typename\\n    }\\n    cityLocation(clientName: $clientName) {\\n      id\\n      name\\n      customName\\n      stateCode\\n      metroName\\n      metroCustomName\\n      zip\\n      postCode\\n      __typename\\n    }\\n    plans(clientName: $clientName, active: true) {\\n      id\\n      communityId\\n      name\\n      bedRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      bathRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      costRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      sizeRange(clientName: $clientName) {\\n        min\\n        max\\n        __typename\\n      }\\n      __typename\\n    }\\n    primarySiteplan(clientName: $clientName, active: true) {\\n      id\\n      src\\n      siteplanType\\n      geoInfo(clientName: $clientName) {\\n        id\\n        siteplanId\\n        neLatitude\\n        neLongitude\\n        swLatitude\\n        swLongitude\\n        geoJson\\n        __typename\\n      }\\n      __typename\\n    }\\n    lots(clientName: $clientName, activeSiteplanOnly: true) {\\n      id\\n      salesStatus\\n      inventory(clientName: $clientName) {\\n        id\\n        price\\n        sqft\\n        beds\\n        baths\\n        elevationId\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}");
		//U.log("jsonHtml: "+jsonHtml);
        
		//FileUtil.writeAllText("/home/shatam/marano_may/maranoJson.txt", jsonHtml);
		
		JsonObject objJson = (JsonObject)json.parse(jsonHtml); 
		JsonObject data = (JsonObject)(objJson.get("data"));
		JsonArray comarray = new JsonArray();		
		comarray = (JsonArray)data.getAsJsonArray("communities");
//		U.log("Total Com: "+comarray.size());
	
		String mainHtml = U.getHTML("https://www.marrano.com/");
		String secMain = U.getSectionValue(mainHtml, "Communities</a>", "Model Homes</a></li>");
		//U.log("secMain:: "+secMain);
		String[] regUrls = U.getValues(secMain, "<li class=\"menu-item menu-item-type-post_type menu-item-object-town menu-item", "</ul>");
//		U.log("regUrls.length: "+regUrls.length);
		for(String reg : regUrls){
			String regUrl = U.getSectionValue(reg, "<a href=\"", "\">");
//			U.log("regUrl: "+regUrl);
			String regHtml = U.getHTML(regUrl);
			
			String[] comSec = U.getValues(reg, "<li class=\"menu-item menu-item-type-post_type menu-item-object-community menu-item", "</a></li>");
			for(String com:comSec) {
				String comUrl = U.getSectionValue(com, "<a href=\"", "\">");
//				U.log("comUrl: "+comUrl);
				addDetails(comUrl, regHtml, comarray);
			}			
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String regHtml, JsonArray comarray) throws Exception {

		{
			String communityUrl=comUrl;
			
//		if (!communityUrl.contains("https://www.marrano.com/communities/carriage-lane/")) return;
			U.log(communityUrl);
			if (data.communityUrlExists(communityUrl)) {
				LOGGER.AddCommunityUrl(communityUrl + "---------------------------------Repeated");
				return;
			}
			LOGGER.AddCommunityUrl(communityUrl);
			
			String comHtml =  U.getHTML(communityUrl);
			
			//----Community Name-----
			String comName = ALLOW_BLANK;
			comName	= U.getSectionValue(comHtml, "<title>", " |");
			comName	= comName.replace("New Homes Available in Juniper Landing by Marrano Custom Homes", "Juniper Townhomes");
			
			if(communityUrl.contains("/communities/windstone-patio/"))		
				comName	= "Windstone Patio";
			if(communityUrl.contains("/communities/windstone-villas/"))		
				comName	= "Windstone Villas";
		
			U.log("comName::"+comName);
			comName=comName.replace("New Homes Available in Juniper Townhomes by Marrano Custom Homes","Juniper Townhomes");
			
			//-----Community address------------
			String note=ALLOW_BLANK;
			String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "FALSE";
			String[] latLng= {ALLOW_BLANK,ALLOW_BLANK} ;
			String jsonComData = ALLOW_BLANK;
			String comId=ALLOW_BLANK;
			for(int i = 0; i < comarray.size(); i++) {
				String comJson = comarray.get(i).toString();	
				String jsoncomName = U.getSectionValue(comJson, "\"name\":\"", "\",\"");
//				U.log("jsoncomName: "+jsoncomName);		
				//MATCH
				if(comName.equals(jsoncomName)) {
					//U.log("jsoncomName Matched: "+jsoncomName);
					U.log("comJson: "+comJson);
					jsonComData += comJson;
					comId=U.getSectionValue(comJson, "\"id\":", ",");
					
				}
			}
			U.log("Comm ID="+comId);
			
			String latitude = U.getSectionValue(jsonComData, "\"latitude\":", ",\"");
			String longitude = U.getSectionValue(jsonComData, "\"longitude\":", ",\"");
			latLng[0] = latitude;
			latLng[1] = longitude;
			U.log("LL"+Arrays.toString(latLng));
			String addSec=U.getSectionValue(comHtml, "<li>Model Location -", "</li>");
			if(addSec!=null) {
				addSec=U.getSectionValue(addSec, "rel=\"noopener\">", "</a>");
				if(addSec!=null)
					add =U.getAddress(addSec);
			}
			if(comName.equals("Emerald Gardens")) {
				add[0] = ALLOW_BLANK; add[1] = "Cheektowaga"; add[2] = "NY"; add[3] = ALLOW_BLANK;  
			}
			if(comName.equals("Greythorne")) {
				add[0] = ALLOW_BLANK; add[1] = "Williamsville"; add[2] = "NY"; add[3] = ALLOW_BLANK;  
			}
			
			if(add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && add[2]==ALLOW_BLANK && latLng[0]!=null) {		
				add = U.getAddressGoogleApi(latLng);
				if(add == null) 
					add = U.getAddressHereApi(latLng);
				geo = "True";
			}
			
			
			if( add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK && latLng[0] == null) {
					latLng=U.getlatlongGoogleApi(add);
					add=U.getAddressGoogleApi(latLng);
					geo="True";
			}
			
			if( (add[1] == ALLOW_BLANK && add[2] == ALLOW_BLANK && latLng[0] == null ) ||(add[1] == ALLOW_BLANK && add[2] == ALLOW_BLANK && latLng[0] == ALLOW_BLANK)) {
				String add2=U.getSectionValue(comHtml, "Community Location -", "</a>");
				String[] addArray=add2.split(","); 
				add[0]=addArray[0];
				add[1]=addArray[1];
				add[2]=addArray[2];
				add[3]=ALLOW_BLANK;
				latLng=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latLng);
				add[0]=add[0].replace("Co Rd", "County Road");
				geo="True";
			}
			

			U.log("Lat_Lng: "+Arrays.toString(latLng));
			U.log("add:"+Arrays.toString(add)+" Geo: "+geo);
			//-----------community latlngs-------------
			
		
			
			//======== Homes Data ======= [Link for below method taken from community page - Sherwood Homes]
			String jsonHomes = sendPostRequestAcceptJson2("https://nexus.anewgo.com/api/graphql_gateway", //+comName+
                   "{\"operationName\":\"GetCommunityByNameWithPlans\",\"variables\":{\"clientName\":\"marrano\",\"communityName\":\""+comName+"\"},\"query\":\"query GetCommunityByNameWithPlans($clientName: String!, $communityName: String!) {\\n  communityByName(clientName: $clientName, communityName: $communityName) {\\n    id\\n    name\\n    pricing\\n    agents(clientName: $clientName) {\\n      id\\n      email\\n      phone\\n      firstName\\n      lastName\\n      __typename\\n    }\\n    plans(clientName: $clientName) {\\n      ...PlanFields\\n      elevations(clientName: $clientName, active: true) {\\n        thumb\\n        ...ElevationFields\\n        __typename\\n      }\\n      __typename\\n    }\\n    schemes(clientName: $clientName) {\\n      id\\n      name\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment PlanFields on Plan {\\n  id\\n  displayName\\n  name\\n  communityId\\n  defaultElevationId\\n  description\\n  bed\\n  bath\\n  cost\\n  size\\n  videoUrl\\n  interactiveInteriorIds(clientName: $clientName)\\n  bedRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  bathRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  costRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  sizeRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment ElevationFields on Elevation {\\n  id\\n  mirrorElevationId\\n  mirrorRolePrimary\\n  communityId\\n  planName\\n  planDisplayName\\n  planId\\n  caption\\n  thumb\\n  bed\\n  bath\\n  size\\n  cost\\n  defaultFloor\\n  description\\n  svgMirroring\\n  garagePosition\\n  defaultGaragePosition\\n  bedRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  bathRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  costRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  sizeRange(clientName: $clientName) {\\n    min\\n    max\\n    __typename\\n  }\\n  tags(clientName: $clientName) {\\n    categoryName\\n    tagName\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");			//U.log("jsonHomes: "+jsonHomes);
		
			U.log("jsonHomes: "+jsonHomes);
			
			
			String myHomeSec=U.getSectionValue(comHtml,"<h2>Available Home Plans</h2>", "CUSTOMIZE YOUR HOME</a>");
			String homeData=ALLOW_BLANK;
			
			if(myHomeSec!=null) {
				String[] homeUrlSec=U.getValues(myHomeSec, "<div class=\"model-home-list-item-inner\">", ">");
				for(String home:homeUrlSec) {
					String homeUrl=U.getSectionValue(home, "<a href=\"/", "\"");
					U.log("hELLLO "+homeUrl);
					homeData=U.getHTML(homeUrl);
					U.log(U.getCache(homeUrl));
				}
			}
			
			//----Prices
			comHtml=comHtml.replaceAll("CONDO/VILLAS Starting \\$\\d+s</a>", "")
					.replace("Townhomes Starting $280s", "").replace("0�s", "0,000").replace("0s", "0,000").replaceAll("&nbsp;", " ").replace("e $290’s", "$290,000").replace("$280’s", "$280,000")
					.replace("pricing starting in the low $300,000,000","");
			if (comHtml.contains("Marrano_VillasAtWindstone_BannerSlider_1600x460.")) {
				comHtml=comHtml.replace("Marrano_VillasAtWindstone_BannerSlider_1600x460.", "$250,000");
			}
			String minPrice=ALLOW_BLANK,maxPrice=ALLOW_BLANK;
//			U.log(moveInContent);
//			moveInContent = moveInContent.replace("> $394</span></strong><strong><span style=\"color: #ff0000;\">,900", "> $394,000").replaceAll("CONDO/VILLAS Starting \\$\\d+s</a>", "")
//					.replace("Townhomes Starting $280s", "").replace("0s", "0,000");
			
		  //U.log(Util.matchAll(moveInContent,"[\\w\\W\\s]{40}379[\\w\\W\\s]{40}",0));
			String[] prices=U.getPrices(comHtml, "Starting \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);
			//U.log("MMMMMMMMMMM "+Util.matchAll(comHtml, "[\\w\\s\\W]{30}300,000[\\w\\s\\W]{30}", 0));
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
//			if(communityUrl.contains("https://www.marrano.com/communities/rochester/hathaways-corners/")) {
//				minPrice="$299900";
//			}
			
			U.log("min price::"+minPrice+" max price::"+maxPrice);
			
			//-----Square Feet
//			U.log("MMMMMMMMMMM "+Util.matchAll(homeData, "[\\w\\s\\W]{60}1,340[\\w\\s\\W]{60}", 0));

			String minSqFt=ALLOW_BLANK,maxSqFt=ALLOW_BLANK;
			String[] sqFt =U.getSqareFeet(comHtml+homeData, "\\d,\\d{3} square feet of living space|from \\d,\\d{3}- \\d,\\d{3} sq ft|Square Feet: \\d{4}-\\d{4}|\\d{4} � \\d{4} square feet|\\d{4} to \\d{4} square feet homes|\\d{4} – \\d{4} square feet|from \\d,\\d{3} to \\d,\\d{3} square feet|Square Feet:</span> \\d{4}\\s*-\\s*\\d{4}</li>|\\d{1},\\d{3} sq. ft.|\\d{4} Sq. Ft|\\d{4} square foot|\\d,\\d{3} square feet", 0);
			
			minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			
			U.log("minSqFt::"+minSqFt+"\tmaxSqFt::"+maxSqFt);
			
			if(comUrl.contains("/communities/juniper-townhomes/"))
				minSqFt="1340";
			//----Community Type
			String comType=ALLOW_BLANK;
//			U.log(regSec);
//			
			
			//if(regSec!= null)
			//regSec = regSec.replaceAll("18 hole golf courses|private golf clubs", "").replace(" public and prestigious private golf courses", "golf courses");
			comType = U.getCommunityType((comHtml).replaceAll("private golf clubs with nationally|golf architect|private golf courses|Ross_\\(golfer\\)", ""));
			//U.log("MMMMMMMMMMM "+Util.matchAll(regSec, "[\\w\\s\\W]{30}golf[\\w\\s\\W]{30}", 0));
			U.log("comType::"+comType+"::");
			
			//----Drop Common Section
			String remo=U.getSectionValue(comHtml, "<html","<!-- #specials -->");
			//U.log(remo);
			if(remo!=null)
			comHtml=comHtml.replace(remo,"");
//			String commonSec =U.getSectionValue(comHtml, "<header class=\"header", "</header>");
//			comHtml=comHtml.replace(commonSec, "");			
			comHtml =comHtml.replaceAll("main level&#8230|New Homes Available in |ceilings on the first level|03/single-family-lifestyle|townhouse-lifestyle", "");
			//U.log(comHtml);
			comHtml = comHtml.replaceAll("-single-family|<a href=\"https://www.marrano.com/townhomes/\">Town Homes</a></li>|Windstone Townhomes Amherst - GRAND OPENING!","");
			comHtml = comHtml.replace("Traditional 3 incl brick", "traditional Home 3 incl brick");
			comHtml = comHtml.replaceAll(" new townhouses", " new townhomes");
//			U.log(Util.matchAll(comHtml, "<li(.*?)</li", 0));
			comHtml=comHtml.replaceAll("NOW AVAILABLE</a>|Custom","").replaceAll("<li(.*?)\">|<a href(.*?)</a", "");
//			U.log(Util.matchAll(comHtml, "<li(.*?)</li", 0));
			//----Property Type
			String propType=ALLOW_BLANK;
			if(comHtml.contains("98526_Marrano_HathawaysCorners")) {
				comHtml+=" Custom ranch and two-story homes";
				U.log(" Custom ranch and two-story homes");
			}
			comHtml=comHtml.replace("Patio Home w/Traditional 3 incl brick front", "patio home and New Tradition Homes")
					.replaceAll("</a></li>\\s+Town Homes</a></li>\\s+Patio Homes</a></li>\\s+Villa Homes</a></li>\\s+Move-In Ready Homes<", "")
					.replaceAll("private and exclusive patio home community at Juniper Landing|.model-townhome-list|the background size of townhome images","")
					.replace("feature 48 condominium townhouses configured in", "feature 48 condominium configured in");
			jsonHomes = jsonHomes.replace("caption\":\"Craftsman", "Craftsman-style homes").replace("Colonial-style home", "The Colonial");
			
			propType=U.getPropType(comHtml.replace("craftsman;", "Craftsman-style homes")+jsonHomes);
			U.log("propType::"+propType);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+jsonHomes, "[\\s\\w\\W]{60}traditional[\\s\\w\\W]{60}", 0));
			//U.log(">>>>>>>>>>>>"+Util.matchAll(jsonHomes, "[\\s\\w\\W]{30}colonial[\\s\\w\\W]{30}", 0));
			//----Derived Type
			String dType=ALLOW_BLANK;
			comHtml =  comHtml.replace("second-floor ", "2 Story").replace(" first-floor", " 1 Story");
			dType=U.getdCommType(comHtml.replace("<li>Ranch floor plan", "Ranch and ")+jsonHomes);
			dType=dType.replace(",1 Story","");
			U.log("dType::"+dType);
						
			//----Property Status
//			comHtml = comHtml.replace(U.getSectionValue(comHtml, "<div id=\"specials\"><div>", "</div></div"), "");
			

			String status=ALLOW_BLANK;
			comHtml=comHtml.replaceAll("Now Available for Sales|.sold-out|loft is move|move-in-ready properties|available for sale|wide home sites available to accommodate|decorated or move-in ready home\\?|Take advantage of close-out incentives |location is now available|ost beautiful home sites available|location is now available in|GRAND OPENING - ROCHESTER|TOWNHOMES - MOVE-IN READY|=\"New Homes Available in|>New Homes Available|Move-in-ready homes now available", "");						
			//if(statusSec==null)statusSec=" ";
			status=U.getPropStatus(comHtml
					.replace("Final phase of lots are now available", "Final phase lots now available")
					.replace("15 lots left Marrano is excited to", ""));
			
			status = status.replace("Coming Soon Final Phase, Coming Soon", "Coming Soon Final Phase");
			
			U.log("status: "+status);
			//U.log("MMMMMMMMMMM "+Util.matchAll(comHtml, "[\\w\\s\\W]{20}Coming Soon[\\w\\s\\W]{20}", 0));

			//U.log(Util.matchAll(statusSec, "[\\w*\\s*]Move-in Ready[\\w*\\s*]", 0));
			status=status.replace("Grand Opening, Now Available","");
			if(status.length()==0){
				status=ALLOW_BLANK;
			}
			
			if(communityUrl.contains("https://www.marrano.com/glenbrooke") && comHtml.contains("<h2>Move-in-ready homes now available.</h2>"))
				if(status==ALLOW_BLANK)
					status = "Move-in Ready Home";
				else
					status+= ", Move-in Ready Home";
			

			U.log("status::"+status);
						
			if(add[0]==ALLOW_BLANK&&add[1]!=ALLOW_BLANK && add[2]!=ALLOW_BLANK && latLng[0]==ALLOW_BLANK){
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
				add=U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getGoogleAddressWithKey(latLng);
				geo="True";
				note ="Address And Lat-Lng Are Taken From City And State";
			}
			if (add.length!=4) {
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				
				add=U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo="True";
				note ="Address And Lat-Lng Are Taken From City And State";
			}
			if (add[0]!=ALLOW_BLANK&&latLng[0]==ALLOW_BLANK) {
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null) latLng = U.getlatlongHereApi(add);
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo="TRUE";
				
			}
			String updatedName = comName.trim();
			U.log(updatedName);//+updatedName+
			//U.log(">>>>>>>>>>>>"+Util.matchAll(planData, "[\\s\\w\\W]{30}Presale[\\s\\w\\W]{30}", 0));		
			String lotIds="";
			if(comId.length()>2) {
			
			String lotMapData = sendPostRequestAcceptJsonLotMap("https://nexus.anewgo.com/api/graphql_gateway","{\"operationName\":\"GetSiteplanLiteByCommunityId\",\"variables\":{\"clientName\":\"marrano\",\"communityId\":"+comId+"},\"query\":\"query GetSiteplanLiteByCommunityId($clientName: String!, $communityId: Int!) {\\n  activeSiteplanByCommunityId(clientName: $clientName, communityId: $communityId, master: false) {\\n    id\\n    name\\n    lotFontSize\\n    lotMetric\\n    lotWidth\\n    lotHeight\\n    master\\n    src\\n    active\\n    ...SiteplanSVGFields\\n    lotLegend(clientName: $clientName) {\\n      id\\n      code\\n      name\\n      hex\\n      __typename\\n    }\\n    ...HotspotsFields\\n    lots(clientName: $clientName) {\\n      id\\n      communityId\\n      dataName\\n      name\\n      salesStatus\\n      premium\\n      externalId\\n      address\\n      size\\n      cityName\\n      stateCode\\n      zip\\n      postCode\\n      garagePosition\\n      siteplanName(clientName: $clientName)\\n      siteplanInfo {\\n        lotId\\n        siteplanId\\n        x\\n        y\\n        __typename\\n      }\\n      __typename\\n    }\\n    subSiteplans(clientName: $clientName, active: true) {\\n      id\\n      name\\n      info(clientName: $clientName) {\\n        siteplanId\\n        thumb\\n        fontSize\\n        x\\n        y\\n        whiteLabel\\n        showsThumb\\n        __typename\\n      }\\n      lots(clientName: $clientName) {\\n        id\\n        communityId\\n        salesStatus\\n        inventory(clientName: $clientName) {\\n          id\\n          communityId\\n          lotId\\n          planId\\n          elevationId\\n          __typename\\n        }\\n        excludedPlanElevations(clientName: $clientName) {\\n          planId\\n          elevationId\\n          planName\\n          planDisplayName\\n          elevationCaption\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment HotspotsFields on Siteplan {\\n  hotspots {\\n    id\\n    siteplanId\\n    name\\n    x\\n    y\\n    description\\n    thumb\\n    assets {\\n      id\\n      listIndex\\n      src\\n      description\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\\nfragment SiteplanSVGFields on Siteplan {\\n  svg {\\n    viewBox {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    style\\n    frame {\\n      x\\n      y\\n      width\\n      height\\n      __typename\\n    }\\n    shapes {\\n      tagName\\n      attributes {\\n        className\\n        dataName\\n        x\\n        y\\n        width\\n        height\\n        transform\\n        points\\n        d\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}");
			
			//U.log("lotMapData: "+lotMapData);
		
			JsonParser parser = new JsonParser();
			
//			if(!lotMapData.contains("INTERNAL_SERVER_ERROR") && !lotMapData.contains("\"siteplan\":null")){
//				JsonObject jobj = (JsonObject)parser.parse(lotMapData);
//				lotIds = jobj.get("data").getAsJsonObject().get("siteplan").getAsJsonObject().get("lots").getAsJsonArray().size()+"";
//				U.log("lot ids="+lotIds);
//			}
			if(!lotMapData.contains("INTERNAL_SERVER_ERROR") && !lotMapData.contains("\"siteplan\":null")){
				JsonObject jobj = (JsonObject)parser.parse(lotMapData);
				lotIds = jobj.get("data").getAsJsonObject().get("activeSiteplanByCommunityId").getAsJsonObject().get("lots").getAsJsonArray().size()+"";
				U.log("lot ids="+lotIds);
				
			}
			}
			if(latLng[0]==null) {
				latLng[0]=ALLOW_BLANK;
				latLng[1]=ALLOW_BLANK;
			}
			if(lotIds.equals("0") || lotIds.length()<1)lotIds=ALLOW_BLANK; 	
			data.addCommunity(comName.replace("Windstone Villas", "Windstone"), communityUrl, comType);
			data.addAddress(StringUtils.capitalize(add[0]), add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propType, dType);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPropertyStatus(status);
			data.addNotes(note);
			data.addUnitCount(lotIds);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
		}i++;
		
//		}catch (Exception e) {}
	}
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws Exception {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
//	    try {
//	        URL url = new URL(requestUrl);
//	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//	        connection.setDoInput(true);
//	        connection.setDoOutput(true);
//	        connection.setRequestMethod("POST");
////	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
////	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
//	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
//	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36");
//	        connection.setRequestProperty("referer", "https://myhome.anewgo.com/");
//	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY0NTYyNzIwNSwiZXhwIjoxNjQ1NjcwNDA1fQ.AFIOGz2-MiOLZOEQd-nM-IecjBd5ydcuMgEpFQpxfu4");
//	        connection.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01");
//	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
//	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
//	        writer.write(payload);
//	        writer.close();
//	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
//	        String line;
//	        while ((line = br.readLine()) != null) {
//	                jsonString.append(line);
//	        }
//	        br.close();
//	        connection.disconnect();
//	    } catch (Exception e) {
//	            throw new RuntimeException(e.getMessage());
//	    }
		 try {
		        URL url = new URL(requestUrl);
		        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		        connection.setDoInput(true);
		        connection.setDoOutput(true);
		        connection.setRequestMethod("POST");
//		        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
		        connection.setRequestProperty("Accept", "*/*");
		        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY2MzkxMjAyNCwiZXhwIjoxNjYzOTU1MjI0fQ.sI20pBLVtjSaYSkmNXQWNdgK1XJ5jOx_laZct-H9JIM");
		        connection.setRequestProperty("Content-Length", "1803");
		        connection.setRequestProperty("Content-Type", "application/json");
		        connection.setRequestProperty("Origin", "https://myhome.anewgo.com");
		        connection.setRequestProperty("Referer", "https://myhome.anewgo.com/client/marrano");
//		        connection.setRequestProperty("Sec-Fetch-Dest", "empty");
//		        connection.setRequestProperty("Sec-Fetch-Mode", "cors");
//		        connection.setRequestProperty("Sec-Fetch-Site", "same-site");
		        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");

		        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
		        writer.write(payload);
		        writer.close();
		        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		        String line;
		        while ((line = br.readLine()) != null) {
		                jsonString.append(line);
		        }
		        br.close();
		        connection.disconnect();
		    } catch (Exception e) {
		            throw new RuntimeException(e.getMessage());
		    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	
	public static String sendPostRequestAcceptJson2(String requestUrl, String payload) throws Exception {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		//log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
//	        connection.setRequestProperty("ot-originaluri", "/mexico-city-mexico-restaurant-listings");
	        connection.setRequestProperty("origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("user-agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");
	        connection.setRequestProperty("referer", "https://myhome.anewgo.com/client/marrano/community/Aurora%20Mills/siteplan");
	        connection.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY2MzkxMjg2NSwiZXhwIjoxNjYzOTU2MDY1fQ.9WeYteTqs4qt4tjjy_t5hRTePlWcyl0bZjJXtqcUXeQ");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Content-Type", "application/json");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	public static String sendPostRequestAcceptJsonLotMap(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		U.log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
	        connection.setRequestProperty("authority", "nexus.anewgo.com");
	        connection.setRequestProperty("path", "/api/graphql_gateway");
//	        connection.setRequestProperty("accept-encoding", "gzip, deflate, br");

//	        connection.setRequestProperty("method", "POST");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY2MzkxMjg2NSwiZXhwIjoxNjYzOTU2MDY1fQ.9WeYteTqs4qt4tjjy_t5hRTePlWcyl0bZjJXtqcUXeQ");
//	        connection.setRequestProperty("Content-Length", "2592");
	        connection.setRequestProperty("Content-Type", "application/json");
	        connection.setRequestProperty("Origin", "https://myhome.anewgo.com");
	        connection.setRequestProperty("Referer", "https://myhome.anewgo.com/client/marrano/community/Aurora%20Mills/siteplan");
//	        connection.setRequestProperty("Sec-Fetch-Dest", "empty");
//	        connection.setRequestProperty("Sec-Fetch-Mode", "cors");
//	        connection.setRequestProperty("Sec-Fetch-Site", "same-site");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");
	        connection.setRequestProperty("accept-language", "en-US,en;q=0.9,es;q=0.8,fr;q=0.7");

	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
}

	