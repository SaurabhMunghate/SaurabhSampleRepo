/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.lang.StringEscapeUtils;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractMcCaffreyHomes extends AbstractScrapper {

	int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.mccaffreyhomes.com";

	public ExtractMcCaffreyHomes() throws Exception {
		super("McCaffrey Homes", "https://www.mccaffreyhomes.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("McCaffrey Homes");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractMcCaffreyHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "McCaffrey Homes.csv", a.data().printAll());
		U.log("Repeated-->" + k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml = U.getPageSource("https://www.mccaffreyhomes.com/new-homes");
		String[] comSec = U.getValues(mainHtml, "panel-body community-list\">", "col-xs-12 directions-mobile\"");
		for (String sec : comSec) {
			String comUrl = builderUrl + U.getSectionValue(sec, "<a href=\"", "\"");
//			try {
				addDetails(comUrl, sec);
//			} catch (Exception e) {}
			
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData) throws Exception {

//	if (!comUrl.contains("https://www.mccaffreyhomes.com/new-homes/ca/madera/ivy-tesoro-viejo"))return;
//	if (!comUrl.contains("https://www.mccaffreyhomes.com/new-homes/ca/madera/poppy-tesoro-viejo"))return;
		// if (j == 0)
//		if(!comUrl.contains("poppy-tesoro-viejo"))return;

		{
			

			U.log(j + "   commUrl-->" + comUrl);
			U.log(U.getCache(comUrl));
			
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+"::::::::::::repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getPageSource(comUrl);

			// ============================================Community
			// name=======================================================================
			String communityName = U.getSectionValue(comData, "<h4>", "</h4>");
			U.log("community Name---->" + communityName);
			String forQuickMove = null;

			// ================tab Urls====================================
			String direction = ALLOW_BLANK;
			String floorHtml = ALLOW_BLANK;
			String amenHtml = ALLOW_BLANK;
			String areaInfo = ALLOW_BLANK;
			String quickHtml = ALLOW_BLANK;
			String alltabSec = U.getSectionValue(html, "Community Overview", "</div>");
			boolean isQuickExist = true;
//			 U.log("alltabSec:::::::"+alltabSec);
			if (alltabSec != null) {
				String[] allTabUrls = U.getValues(alltabSec, "<a href=\"", "\"");

				for (String tabUrl : allTabUrls) {
					U.log("tabUrl::" + tabUrl);
					forQuickMove = tabUrl;
					if (tabUrl.contains("driving-directions")) {
						U.log("directions::" + builderUrl + tabUrl);
						direction = U.getPageSource(builderUrl + tabUrl);
					}
					if (tabUrl.contains("community-amenities")) {
						U.log("amenities::" + tabUrl);
						amenHtml = U.getPageSource(builderUrl + tabUrl);
					}
					if (tabUrl.contains("#floorplans")) {
						U.log("floorplans::" + tabUrl);
						floorHtml = U.getPageSource(comUrl + tabUrl);
					}
					if (tabUrl.contains("area-info")) {
						U.log("areaInfo::" + builderUrl + tabUrl);
						areaInfo = U.getPageSource(builderUrl + tabUrl);
					}
					if (tabUrl.contains("/move-in-ready-")) {
						U.log("Quick::" + builderUrl + tabUrl);
						quickHtml = U.getPageSource(builderUrl + tabUrl);
						if(quickHtml.contains("There are currently no move in ready homes")) {
							isQuickExist = false;
						}
					}
				}
			} else {
				U.log(">>>>>>>>DDDDDDDDD");
				direction = U.getPageSource(comUrl + "/driving-directions");
				floorHtml = U.getPageSource(comUrl + "/#floorplans");
				amenHtml = U.getPageSource(comUrl + "/community-amenities");
				areaInfo = U.getPageSource(comUrl + "/area-info");
			}

			// ================================================Address
			// section===================================================================
			String note = "";
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latlag = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			html = U.removeComments(html);

			if (direction.length() < 4 && comData.contains("Driving Directions")) {
				direction = U.getHTML(comUrl + "/driving-directions");
				
			}

			if (direction != null) {
				U.log("UUUUUUUUUUUUUUUUUU");
				// if(direction.contains("<div id=\"map_canvas\">")){
				String addSec = U.getSectionValue(direction, "Center</h3>", "<h3>");
				if (addSec == null) {
					addSec = U.getSectionValue(direction, "Sales Office</h3>", "<h3>");
				}
				if (addSec == null) {
					addSec = U.getSectionValue(direction, "<br><p>For Imformation", "<p>Directions");
				}
				if (addSec == null || addSec.isEmpty())
					addSec = U.getSectionValue(direction, "Models</h3>", "<h3>");
				
				if (addSec == null || addSec.isEmpty())
					addSec = U.getSectionValue(direction, "<p>Poppy sales office at:</p>", "</p>");
				U.log("addSec::::::::::" + addSec);
				if(addSec!=null)
				addSec=addSec.replace("Turn off Hwy 41 onto Town Center Blvd.&nbsp;&nbsp;<small>(Look for the white&nbsp;Tesoro Viejo barn &amp; tower at the intersection)</small>,Follow Town Center Blvd.&nbsp;as it curves north into the Tesoro Viejo Town Center,Continue on Town Center Blvd. past the roundabout, over the bridge and onto Treasure Hills Drive,The Models are on the left,&nbsp; just past the Ranch House Clubhouse.", "");
				if (addSec != null) {
//					U.log("addSec:::::==");
					addSec = U.getSectionValue(addSec, "<p>", "</p>");

					addSec = addSec.replaceAll("Open daily from \\d+am - \\d+pm|\\r\\n\\r\\n", "")
							.replaceAll("Near Highway 41 and Avenue 12<br />", "");
					addSec = addSec.replace("<br />\\r\\n", ",").replace("\\r\\n", "");
					U.log("::>"+addSec);
					addSec = addSec.replace("Madera CA", "Madera, CA").replace(",Open Tues-Sat 10am-6pm, Sun &amp; Mon 11am-5pm", "")
							.replace("Turn off Hwy 41 onto Town Center Blvd.&nbsp;&nbsp;<small>(Look for the white&nbsp;Tesoro Viejo barn &amp; tower at the intersection)</small>,Follow Town Center Blvd.&nbsp;as it curves north into the Tesoro Viejo Town Center,Continue on Town Center Blvd. past the roundabout, over the bridge and onto Treasure Hills Drive,The Models are on the left,&nbsp; just past the Ranch House Clubhouse.", "").replaceAll(
							",Open Daily - 11am to 6pm,\\(559\\) 353-2010|Sunday:|11am to 5pm|Monday thru Saturday:|10am to 6pm|Near Ashlan &amp; Highland Avenues,|,Call for Office Hours,|,Open Saturday - Wednesday 11am to 6pm,\\(559\\) 353-2010|,Open Mon-Sat \\d+am-\\d+pm Sun \\d+am-\\d+pm",
							"");
					add = U.getAddress(addSec);
				}
				if(comUrl.contains("/poppy-tesoro-viejo"))
				{
					 direction=U.getHTML("https://www.mccaffreyhomes.com/new-homes/ca/madera/poppy-tesoro-viejo/driving-directions");
				}
				if(comUrl.contains("/poppy-tesoro-viejo"))
				{
					String addSec1 = U.getSectionValue(direction, "<p>Poppy sales office at:</p>", "</p>");
					addSec1=U.getNoHtml(addSec1);
					addSec1=addSec1.replace("\\r\\n", "")
							.replace("&amp;", "&")
							.replace("&nbsp;", ", ");
					U.log("a::::::::::" + addSec1);
//					String latSec=U.getSectionValue(direction, "<a href=\"https://www.google.com/maps/dir/Current+Location/", "\" ");
					add = U.getAddress(addSec1);
				}
				
				
				if(add[0]==null || add[0].length()<2) {
					U.log("hello");
					addSec=U.getSectionValue(direction, "<h3>Model Homes Now Open!</h3>", "</p>");
					U.log("addSec-2====="+addSec);
					if(addSec!=null) {
						addSec=StringEscapeUtils.unescapeJava(addSec);
						addSec=addSec.replaceAll("\\&bull;|\\&nbsp;", ",").replaceAll("Madera CA", "Madera ,CA").replaceAll("<p>", "").replaceAll("Sunday:,11am to 5pm|Monday thru,Saturday:|10am to 6pm|<br />", "");
						U.log(addSec);
						add=addSec.split(",");
						U.log(Arrays.toString(add));
					}
				}
				// }
				// add[0]=add[0].replace("&amp;", "&");
			}
			
			if(comUrl.contains("https://www.mccaffreyhomes.com/new-homes/ca/madera/savanna-tesoro-viejo")) 
			{
				add[0] = "721 Harvest Drive";
				add[1] = "Madera";
				add[2] = "CA";
				add[3] = "93636";
			}
			
			if (add.length==4 && add[0]!=ALLOW_BLANK)
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			else {
				add=new String[] {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				add[0]=U.getSectionValue(direction, "\"SALESOFFICEADDRESS\":\"", "\"");
				add[1]=U.getSectionValue(direction, "\"SALESOFFICECITY\":\"", "\"");
				add[2]=U.getSectionValue(direction, "\"SALESOFFICESTATE\":\"", "\"");
				add[3]=U.getSectionValue(direction, "\"SALESOFFICEZIP\":", ",");
			} 
			if(comUrl.contains("/ca/madera/oaks-tesoro-viejo") || comUrl.contains("madera/hickory-tesoro-viejo")) {
				add[0]=ALLOW_BLANK;
			}
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			// --------------------------------------------------latlng----------------------------------------------------------------
			if(add[0]!=null)
			add[0] = add[0].trim();
			String laSec = U.getSectionValue(direction, "https://www.google.com/maps/dir", "\"");
			if (laSec != null) {
				U.log(laSec);

				latlag[0] = Util.match(laSec, "\\d{2,3}.\\d+");
				latlag[1] = Util.match(laSec, "-\\d{2,3}.\\d+");
			}
			U.log("hhhh--->" + latlag[0] + "  " + latlag[1]);

			if (add[1] != ALLOW_BLANK && latlag[0] == ALLOW_BLANK) {
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);
				geo = "TRUE";
			}
			if ((add[0] == ALLOW_BLANK || add[3] == null) && latlag[0] != ALLOW_BLANK) {
				add = U.getAddressGoogleApi(latlag);
				if(add == null)add =U.getAddressHereApi(latlag);
				geo = "TRUE";
			}
			U.log("hhhh1--->" + latlag[0] + "  " + latlag[1]);
//			if (comUrl.contains("https://www.mccaffreyhomes.com/new-homes/ca/madera/poppy-tesoro-viejo")) {
//				add[0]="Madera";
//				add[1]="CA";
//				latlag=U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latlag);
//				note="Address And Latlong Taken From City and State";
//			}

			// ===========================================================
			add[0] = add[0].replaceAll("Near Highway 41 and Avenue, 12, |Near Highway 41 and Avenue 12, |Monday thru Saturday:|10am to 6pm|<br />", "");

			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);

			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comData = comData.replaceAll("0�s|0's|0&#8217;s|0k's", "0,000");
			html = html
					.replace("00s", "00,000")
					.replaceAll("0�s|0's|0&#8217;s|0k's", "0,000")
					.replace("Anticipated from the  $400s", "Anticipated from the  $400,000");

			String prices[] = U.getPrices(html + amenHtml + comData + floorHtml + quickHtml,
					"high \\$\\d{3},\\d{3}|Anticipated from the  \\$\\d{3},\\d{3}|From the High \\$\\d{3},\\d{3}|Mid \\$\\d+,\\d+|Priced from: \\$\\d+,\\d+|The low \\$\\d+,\\d+|the Low \\$\\d+,\\d+|Priced At: \\$\\d+,\\d+|from the \\$\\d{3},\\d{3}",
					0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log("------------------"+Util.matchAll(html, "[\\w\\s\\W]{30}Anticipated from[\\w\\s\\W]{30}",0));
			
			// ======================================================Sq.ft===========================================================================================

			String[] sqft = U.getSqareFeet(html + comData + amenHtml + floorHtml,
					"\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} approx. sq. ft|\\d{4} - \\d{4} approx sq. ft.|\\d,\\d{3} - \\d+,\\d{3} approx sq. ft|\\d,\\d{3} - \\d,\\d{3} sq. ft|\\d,\\d{3} square feet|\\d,\\d{3} sq. ft",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================
			html=html.replace("1 &amp; 2 Story", " 1 Story  2 Story");
			html = html.replace("master-plan-amenities", "master plan amenities");
			String communityType = U.getCommType((html + comData + amenHtml + areaInfo)
					.replace("Valley Golf Center", "").replaceAll("Dragonfly \\w{4} Club", "dragon"));
//			U.log("MATCH CT: "+Util.matchAll(html + comData + amenHtml + areaInfo, "\\w+ Golf \\w+", 0));
			U.log("COMMUNITY TYPE: "+communityType);

			// ==========================================================Property
			// Type================================================

			// Quick Move-In Homes</a></li>

			html = html.replaceAll("without a homeowners association|model homes are now available|"
					+ "Carnelian Sold Out|" + "Jadestone Sold Out|Sold Out\\s*</h2>\\s*</a>|Sold Out\" border=", "");
			html = html
					.replaceAll("HOMEOWNERS|Homeowner|\"/homeowners\">|\"/homeowner\">|\"/homeowner/|without HOA fees|"
							+ "No HOA dues|without HOA dues", "").replaceAll("multi-generational needs", "multi-generational family");
			html = html.replace("Traditional architecture", "Traditional homes architecture")
					.replace(" luxurious master baths", "");
			html =  html.replace("Available lofts, dens ", "Available loft level, dens ")
					.replace("Garage + Loft", "Garage and loft").replace("Farmhouse, and Santa Barbara architectural styles", "Farmhouse Style Homes");
			String proptype = U.getPropType((html + comData + amenHtml+quickHtml).replaceAll("Modern Farmhouse-resized\\.jpg|Plan 2 Meadow Modern Farmhouse.jpg", ""));
//			U.log("------------------"+Util.matchAll(html, "[\\w\\s\\W]{30}Modern Farmhouse[\\w\\s\\W]{30}",0));

			// ==================================================D-Property
			// Type======================================================
//			U.log("------------------"+Util.matchAll(html + comData + amenHtml+quickHtml, "[\\w\\s\\W]{30}Modern Farmhouse[\\w\\s\\W]{30}",0));
			
			String dtype = U.getdCommType(html + floorHtml + amenHtml + comData);

			// ==============================================Property
			// Status=========================================================
			html = html.replace("Quick Move-In Homes", "").replace("New Scenic View Lots Available", "New Lots Available");
			//U.log(comData);
			String pstatus = U.getPropStatus((html + comData)
					.replaceAll("<a href=\"/move-in-ready-homes?|Quick Move|-sold-out|SOLD OUT - |Model Homes are now available for Sale|Carnelian Sold Out|Jadestone Sold Out|href=\"/quick-move-in-homes\">|"
							+ "<li><a href=\"/quick-move-in-homes\">Quick Move-In Homes</a></li>", ""));
//			U.log("KKKKKKKK"+Util.matchAll(html, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
//			U.log("KKKKKKKK"+Util.matchAll(comData, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));

			// U.log(html);

			// ============================================note====================================================================

			
			if(comUrl.contains("https://www.mccaffreyhomes.com/new-homes/ca/madera/ivy-at-riverstone")) {
				
				latlag = U.getlatlongGoogleApi(add);
				if(latlag == null) latlag = U.getlatlongHereApi(add);

				add = U.getAddressGoogleApi(latlag);
				if(add == null)add =U.getAddressHereApi(latlag);
				
				geo = "TRUE";
				
			}
			
			if(add[0] == null || add[0].length()<4 && latlag[0] != null) {
				add=U.getAddressGoogleApi(latlag);
				if(add == null)add =U.getAddressHereApi(latlag);
				geo="TRUE";
			}
			U.log("hhhhhhhhhh"+Arrays.toString(add));
			note = U.getnote(html);

			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl);
				k++;
				return;
			}
			String quickHomesPageurl = U.getSectionValue(html, "<a href=\"/move-in-ready-homes?", "\"");
			if(quickHomesPageurl!=null) {
				U.log(quickHomesPageurl+":::::::::quickurl");
			String quickHtmPage = U.getHTML("https://www.mccaffreyhomes.com/move-in-ready-homes?"+quickHomesPageurl);
//			if (html.contains("Quick Move-Ins") && !quickHtmPage.contains("There are currently no move")) 
//			{
//				if (pstatus.length() < 4) {
//					pstatus = "Quick Move-In Homes";
//
//				} else {
//					pstatus = pstatus+", Quick Move-In Homes";
//				}
//			}
			}
			if(add[2]!=null &&add[2].length()>3) 
			{
				add[2]=USStates.abbr(add[2]);
			}
			else {
				//add[2] = ALLOW_BLANK;
			}
			
			if(!isQuickExist) {
				pstatus = pstatus.replace(", Quick Move-In Homes", "");
			}
			
			//pstatus = U.getPropStatus(pstatus);
			if(comUrl.contains("madera/sananna-tesoro-viejo"))proptype = proptype+", Farmhouse Style Homes";//---from image 
			U.log("Property status::::" + pstatus);
			U.log("Property type:::::" + proptype);
			add[0]=add[0].replace("&nbsp;", "");
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			

			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);	
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);
		}
		j++;
	}

}