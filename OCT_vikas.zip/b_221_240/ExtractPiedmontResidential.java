/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractPiedmontResidential extends AbstractScrapper{
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public ExtractPiedmontResidential()
			throws Exception {
		super("Piedmont Residential","https://piedmontresidential.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Piedmont Residential");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractPiedmontResidential();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Piedmont Residential.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpChromePath();
//		ChromeOptions options = new ChromeOptions();
//		options.addExtensions(new File("/home/shatam-17/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
//		driver = new ChromeDriver(options);
		String mainHtml=U.getHTMLwithProxy("http://www.piedmontresidential.com/our-communities/");
		String avaHomes=U.getHTMLwithProxy("http://www.piedmontresidential.com/available-homes/");
		avaHomes=avaHomes.replaceAll("\\s+", " ");
		String[] availHomes=U.getValues(avaHomes, "<h2 class=\"uk-text-secondary uk-text-uppercase\"", "<div class=\"uk-width-1-1");
		U.log(availHomes.length);
		String[] comSec=U.getValues(mainHtml,"<div class=\"comm uk-margin\" ","View Community</a>");
		U.log(comSec.length);
		for(String comData:comSec)
		{
			String comUrl=U.getSectionValue(comData, "<a href=\"","\"");
			U.log(comUrl);
//			try {
				addDetails(comUrl,comData,availHomes);
//			} catch (Exception e) {}
		}
			
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData,String[] availHomes) throws Exception {
	// TODO Auto-generated method stub
//	if(j>= 1)
	{
//		if(!comUrl.contains("https://piedmontresidential.com/new-home-communities/homes-woodstock-ga-walkers-pointe/")) return;
		
		U.log(j+"   commUrl-->"+comUrl);
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"====Repeat");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHTMLwithProxy(comUrl);
		U.log(U.getCache(comUrl));	
		
		String planSec = U.getSectionValue(html, "<div id=\"plans\" class=\"uk-section uk-section-default uk-section-small\"", "</div><!-- container -->");			
		/*String rem=U.getSectionValue(html, "<head>","class=\"dropdown-menu\">");
		html=html.replace(rem,"");*/
		//============================================Community name=======================================================================
		String communityName=U.getSectionValue(comData, "<h2 class=\"uk-margin-remove uk-text-secondary\">","<");
		U.log("community Name---->"+communityName);
						
		//================================================Address section===================================================================
		String note="";
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
		html=U.removeComments(html);
		
		 String addSec=U.getSectionValue(html, "<div class=\"uk-width-3-4@m\" id=\"directions\">","</p>");
		 
		 U.log("addSec :"+addSec);
		 if(addSec!=null) {
			 addSec=U.getSectionValue(addSec, "class=\"uk-link-reset\" target=\"outside\">", "<");
			 addSec=addSec.replaceAll("<br />|</strong>","").replace(",,", ",");
			//						 U.log("===="+addSec);
			 String[] add1=addSec.split(",");
			 if(add1.length>2){
				 add[0]=add1[0];
				 add[1]=add1[1];
				 add[3]=Util.match(add1[2],"\\d{4,}");
				 if(add[3]!=null){
					 add[2]=Util.match(add1[2],"\\w{2}");//add1[2].replace(add[3],"").trim();
				 }
				 else{
					 add[2]=add1[2];
				 }
			 }else if(add1.length==2){
				 add[1]=add1[0];
				 add[3]=Util.match(add1[1],"\\d{4,}");
				 add[2]=add1[1].replace(add[3],"").trim();
			 }
		 }
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
						
		//--------------------------------------------------latlng----------------------------------------------------------------
		add[0]=add[0].trim();
		String laSec=U.getSectionValue(html, "https://www.google.com/maps/embed?pb=","\"");
		U.log(laSec);
		if(laSec!=null)
		{
			U.log(laSec);
			laSec=U.getSectionValue(laSec, "!2d","!2m");
			String[] lat1=laSec.split("!3d");
			latlag[0]=Util.match(lat1[1], "\\d{2,3}.\\d+");
			latlag[1]=Util.match(lat1[0],"-\\d{2,3}.\\d+");
		}
		if(laSec == null){
			laSec  = U.getSectionValue(html, "https://www.google.com/maps/embed/",">");
			if(laSec != null){
				laSec = U.getSectionValue(laSec, "q=", "\"");
				latlag = laSec.split(",");
			}
		}
		if(laSec == null){
			latlag[0]=U.getSectionValue(html, "data-lat=\"", "\"");
			latlag[1]=U.getSectionValue(html, "data-lng=\"", "\"");

		}
		U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);

		//===============Fetching floor plan Data===============
		String allfloorplanData =ALLOW_BLANK;
		String floorplan = U.getSectionValue(html, ">Floor Plans</h1>", "</li");
	//	U.log(floorplan);
		if(floorplan!=null) {
			ArrayList< String> availUrls = Util.matchAll(floorplan, "<a href=\"(.*?)\"", 1);
			U.log("Total Home : "+availUrls.size());
			for(String availUrl : availUrls){
				if(!availUrl.contains("http") || availUrl.contains("facebook")|| availUrl.contains("twitter")|| availUrl.contains("youtube")) continue;
				U.log("floorUrl : "+availUrl);
				try {
					String availHtml = U.getHTMLwithProxy(availUrl);
					allfloorplanData += U.getSectionValue(availHtml, "class=\"uk-container\">", "<p><strong>Available at:</strong></p>");
				}catch(Exception e){}
			}
			allfloorplanData = allfloorplanData.replace("Stunning traditional", "Stunning traditional home");
		}
		
		//===============Fetching Available Home Data===============
		String allAvailHomeData =ALLOW_BLANK;
		String avaiSec = U.getSectionValue(html, "Available Homes</h1>", "</li");
//						U.log(avaiSec);
		
		ArrayList< String> availUrls =  new ArrayList<>();
		if(avaiSec!=null) {
			availUrls.addAll(Util.matchAll(avaiSec, "<a href=\"(.*?)\"", 1));
			U.log("Total Home : "+availUrls.size());
			for(String availUrl : availUrls){
				U.log("availUrl : "+availUrl);
				try {
					String availHtml = U.getHTMLwithProxy(availUrl);
					allAvailHomeData += U.getSectionValue(availHtml, "<h1 class=\"remove-bottom\">", "Photos</h4>");	
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
			allAvailHomeData = allAvailHomeData.replace("Stunning traditional", "Stunning traditional home");
		}
		
		//===========================Price and SQ.FT==================					
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		comData=comData.replaceAll("0s|0's|0&#8217;s|0s|0’s","0,000");
//		U.log(comData);

		html=html.replace("High Shoals! New homes starting in the $190s", "");
		html=html.replaceAll("<strike>\\$\\d{3},\\d{3}</strike>", "").replaceAll("0s|0's|0&#8217;s|0s|0’s","0,000");
		String html1=U.getNoHtml(html);
		String availPrice=ALLOW_BLANK;
		for (String avail : availHomes) {
//			U.log(avail);
//							U.log(U.getSectionValue(avail, "&nbsp; ", "</h1>").equals(communityName.trim()));
			if (avail.contains(communityName.trim())) {
				availPrice=availPrice+avail;
			} 
		}//<strong>$224,810</strong>
		
//		U.log(Util.matchAll(html1+comData+availPrice+allfloorplanData, "[\\w\\s\\W]{30}\\$200[\\w\\s\\W]{30}", 0));
		
		String pricsec=U.getSectionValue(html, "<h1 class=\"uk-text-primary uk-text-center\">Floor Plans</h1>", "<div class=\"uk-section uk-section-small\">");
		String prices[] = U.getPrices((html1+comData+availPrice+allfloorplanData+pricsec+planSec).replace("$375,250", "$375,250 prices").replace("$384,720", "$384,720 pricesquick"),
				"\\$\\d{3},\\d{3} pricesquick|\\$\\d{3},\\d{3} prices|<strong>\\$\\d{3},\\d{3}</strong>|<strong>\\$\\d{3},\\d{3}|Base Price: \\$\\d+,\\d+|From the \\$\\d+,\\d+|the High \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|Mid \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|From  \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>|from High \\$\\d{3},\\d{3}</p>|  \\$\\d{3},\\d{3}  |\\$\\d{3},\\d{3}</span>", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
//		U.log(">>>>>>>>>>>commType "+Util.matchAll(html1+comData+availPrice+allfloorplanData+pricsec+planSec, "[\\w\\s\\W]{30}384[\\w\\s\\W]{90}", 0));				
//======================================================Sq.ft===========================================================================================		
		html = html.replace("Homes range from 1,927-3,005 sqft with 3-5 beds", "");
		
		String[] sqft = U.getSqareFeet((html+comData+allfloorplanData),
						"\\d,\\d{3} SqFt|</span> \\d,\\d{3} SqFt</p>|\\d,\\d{3} - \\d,\\d{3} SqFt|\\d+ SQ. FT.| \\d{4} SqFt|\\d,\\d{3} SqFt",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//		U.log(">>>>>>>>>>>commType "+Util.matchAll(html1+comData+availPrice+allfloorplanData+pricsec+planSec, "[\\w\\s\\W]{30}2,345[\\w\\s\\W]{30}", 0));
		

//================================================community type========================================================
		html=html.replace("day of golf at ", " golf, ").replace("<h2>55 +", "55+ community").replace("55 +", "55+ community");//.replace("al parks and a few golf courses. T", "");
		String communityType=U.getCommType(html+comData);
		U.log("Comm TYpe"+communityType);
		//U.log(">>>>>>>>>>>commType "+Util.matchAll(html+comData, "[\\w\\s\\W]{30}golf courses[\\w\\s\\W]{30}", 0));
//==========================================================Property Type================================================
		html =html.replaceAll("craftsman or traditional elevation|Villa Rica", "");

		String proptype=U.getPropType((html+ comData + allAvailHomeData + allfloorplanData).replaceAll(" value=\"Cottages at Browns Ridge\">Cottages at Browns Ridge</option>|Monthly HOA :|hoa\"|-HOA|target-HOA|Duplex Group \\d Release", ""));
		
//==================================================D-Property Type======================================================
		
		String dtype=U.getdCommType(html+comData+allAvailHomeData+allfloorplanData);
		
//==============================================Property Status=========================================================
		html = html.replaceAll("New Home Community Coming Soon to Dallas</p>|- Coming Soon|<span class=\"script\">Coming Soon!</span>|Coming Soon!<br|- Coming Soon!</p>|Brentwood - Coming|Coming Soon[!]*\\s*</p>|The Savannah - Coming Soon|Coming Soon, Ready|Coming Soon - Ready Oct| Coming Soon! Ready|>The Graham - Coming Soon</p>|Floorplan - Coming Soon|Move In Ready|\">Move in Ready[!]?</p>|\" /> Coming Soon</|center;\">Coming Soon|- Move In Ready[!]?</p>|\\| Move in Ready[!]?</p>|will be coming soon to Dallas GA|Move-in Ready</span><span class=\"available|Coming Soon!</p|Home - Coming Soon|center;\">Coming Soon|<p>New Plan Coming Soon!</p>|<p style=\"text-align: center;\">Coming Soon!</p>|more about the final|Move-In Homes</a>", "")
				.replaceAll("Opening! Sign", "");

		String pstatus=ALLOW_BLANK;
//		U.log(comData);
		//html=html.replace(U.getSectionValue(html, "<h1 class=\"uk-text-primary uk-text-center\">Site Plan</h1>", "<script"), "");
		
//		U.writeMyText(html);
		pstatus = U.getPropStatus((html+comData).replace("Brand New Homes in Bremen Now Selling!","New Homes Now Selling")
				.replaceAll("Quick Move-in Homes</h2>", ""));
		
			/*
			 * if(availUrls.size() > 0 && !pstatus.contains("Quick Move")){ if(pstatus ==
			 * ALLOW_BLANK) pstatus = "Quick Move-in Homes"; else if(pstatus != ALLOW_BLANK)
			 * pstatus += ", Quick Move-in Homes"; }
			 */
//============================================note====================================================================
		
		html = html.replaceAll("presale pricing and events", "");
		 note=U.getnote(html+comData);
		
//		if(comUrl.contains("/new-homes-hiram-ga-harmony-creek/"))pstatus="Basement Homes Remain";

//		U.log(""+Util.matchAll(html+comData+allAvailHomeData+allfloorplanData, "[\\s\\w\\W]{30}HOA[\\s\\w\\W]{30}", 0));
		 add[0] = add[0].toLowerCase();
		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
/*		if(comUrl.contains("http://www.piedmontresidential.com/new-home-communities/active-adult-community-jasper-ga-piedmont-village")) {
			communityType += ", 55+ Community";
			pstatus=ALLOW_BLANK;
		}
*/		
//             if(comUrl.contains("http://www.piedmontresidential.com/new-home-communities/homes-dallas-ga-creekside-landing/")) {
//            	 pstatus+=", Coming Soon";
//             }
             
             if(pstatus.contains("http://www.piedmontresidential.com/new-home-communities/homes-newnan-ga-summerlin"))
             pstatus="Final Phase Now Selling";
//             if(comUrl.contains("http://www.piedmontresidential.com/new-home-communities/homes-canton-ga-willow-oaks/"))
//            	 pstatus="Coming Late Fall 2021";
             
             
        String sitemapdata = U.getSectionValue(html,"data-mapdata=\"","\" data-height=");
        String lotIds = "";
        if(sitemapdata!=null) {
            sitemapdata = sitemapdata.replace("&quot;", "\"");
            lotIds = Util.matchAll(sitemapdata, ",\"pin\":\"", 0).size()>0? Util.matchAll(sitemapdata, ",\"pin\":\"", 0).size()+"":ALLOW_BLANK;
        }
		if(comUrl.contains("https://piedmontresidential.com/new-home-communities/homes-kennesaw-ga-prichard-park/")) {
			ArrayList<String> pins = Util.matchAll(html, "popover-icon", 0);
			U.log("Count Pins: "+pins.size());
			lotIds = String.valueOf(pins.size());
		}
        if(lotIds.length()<1)lotIds=ALLOW_BLANK;
        U.log("lotIds: "+lotIds);
        
        //------------------------------------------------------------------------------------
        
		data.addCommunity(communityName,comUrl, communityType);
		data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(pstatus.replace("Ii", "II").replace("IIi", "III"));
		data.addNotes(note.replace("Ii", "II").replace("IIi", "III")); 
		data.addUnitCount(lotIds);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
	}

}