/****
 * @author Priti
 * 2 Feb 2017
 */

package com.shatam.b_221_240;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import javax.mail.search.AddressStringTerm;
import javax.print.attribute.standard.JobImpressionsSupported;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractStyleCraftHomes extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	public int inr = 0;
	WebDriver driver=null;

	public static CommunityLogger LOGGER;
	HashMap<String, String> latLngList = new HashMap<>();

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractStyleCraftHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "StyleCraft Homes.csv", a.data().printAll());
	}

	public ExtractStyleCraftHomes() throws Exception {

		super("StyleCraft Homes", "https://stylecrafthomes.com/");
		LOGGER = new CommunityLogger("StyleCraft Homes");
	}

	public void innerProcess() throws Exception {
		
		U.setUpChromePath();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam/CRXChrome/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		
//		 Proxy proxy = new Proxy();
////		 proxy.setHttpProxy("45.145.150.50:3128");
////		 proxy.setSslProxy("138.197.209.229:3128"); 
//		 proxy.setHttpProxy("12.218.209.130:53281");
//		 proxy.setSslProxy("20.116.130.70:3128");
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//			driver = new ChromeDriver(capabilities);
//		 capabilities.setCapability("proxy", proxy);
		 driver = new ChromeDriver(capabilities);
		Thread.sleep(10000);
		
		
		
		
		
		String url = "https://stylecrafthomes.com/communities/";
		String html = U.getHTML(url);

		
		JsonParser parser = new JsonParser();
		String mainSec = U.getSectionValue(html, "window.__PRELOADED_STATE__ = ", "</script>");
		
		JsonObject json = (JsonObject) parser.parse(mainSec).getAsJsonObject().get("cloudData");
	
		JsonObject comJson = (JsonObject) json.getAsJsonObject().get("communities");
		JsonObject planJson = (JsonObject) json.getAsJsonObject().get("plans");
		JsonObject homeJson = (JsonObject) json.getAsJsonObject().get("homes");
		
		String[] comData = U.getValues(U.removeSectionValue(comJson.toString(), "\"unpublished\":[", "receivedAt\":"), "{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");
		
//		U.log("comData==="+comData.length);
		for(String comSec : comData)
			addDetails(comSec, homeJson.toString(), planJson.toString());
		

		// to fetch comSection from communities list page
//		String[] comSection = U.getValues(html, "<div id=\"community", "Learn More</a>");
//		U.log("Length::: " + comSection.length);
//		for (String cSec : comSection) {
//
//			String cUrl = U.getSectionValue(cSec, "<a href=\"", "\">");
//			String cName = U.getSectionValue(cSec, "<h4>", "</h4>");
//			cName = U.getNoHtml(cName).replace("r's", "rs").replace("Greenwich Walk Townhomes At FoxCreek",
//					"Greenwich Walk");
//
//			// cSec=U.removeSectionValue(cSec, " <ul class=\"prices hidden\">", "</ul");
//			if (cUrl != null)
//				addDetails(cUrl, cName, cSec);
//			// ;
//		}
		driver.quit();
		LOGGER.DisposeLogger();

	}

	private void addDetails(String comSec, String homeJson, String planJson) throws Exception {//String comUrl, String cName, String comSec

		// TODO ::
//		 if(j ==1)
		// try{
		{ 

			
			String comUrl = ALLOW_BLANK;
			try {
			comUrl = "https://www.stylecrafthomes.com/communities/"+U.getSectionValue(comSec, "\"addressCounty\":\"", "\"").toLowerCase().trim().replaceAll("\\s", "-")
+"/"+U.getSectionValue(comSec, "\"sharedName\":\"", "\"");
			}catch (Exception e) {}
			
			if(comUrl == ALLOW_BLANK)
				comUrl = "https://www.stylecrafthomes.com/communities/"+U.getSectionValue(comSec, "\"area\":\"", "\"").toLowerCase().trim().replaceAll("\\s", "-")
				+"/"+U.getSectionValue(comSec, "\"sharedName\":\"", "\"");
			
			U.log("\n"+j + " cUrl::::::" + comUrl);
			
			
			//====== Single Run ==============
//			if(!comUrl.contains("https://www.stylecrafthomes.com/communities/henrico/the-village-at-millers-lane"))return;
			
		//=====================
			
			
			if(comUrl.contains("https://www.stylecrafthomes.com/communities//townes-at-notting-place"))return;
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("repeated-----------------" + comUrl);
				i++;
			}
			if(comUrl.contains("https://www.stylecrafthomes.com/communities/chesterfield/wynwood-at-foxcreek")) {
				LOGGER.AddCommunityUrl("Page Not Found-----------------" + comUrl);
				
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			U.log("comSec===\n"+comSec);
			comSec=comSec.replaceAll("\"name\":\"Exterior Rendering of The Outpost at Brewers Row in Scotts Addition\"", "");
			String comHtml = U.getHTML(comUrl);

			// removing footer and recommended section
			comHtml = U.removeSectionValue(comHtml, "__PRELOADED_STATE__", "</script>");

			String joinList = U.getSectionValue(comHtml, "JOIN THE VIP LIST</h3>", "</div>");

			// -----------Com Name-------------
			
			String comName = U.getSectionValue(comSec, "\"name\":\"", "\"");
			comName = comName.replace(", Section 4", "");
			
			if(comName==null||comName==ALLOW_BLANK||comName.isEmpty()) {
				String comNameSec=U.getSectionValue(comSec, "\"modifier_email\":\"", "\"outOfCommunity\":");
			U.log("comNameSec"+comNameSec);
				
				comName=U.getSectionValue(comNameSec, "\"name\":\"", "\",");
			}

			if (comName != null)
				comName = comName.replaceAll("<.*?>", "");
//			if(comUrl.contains("https://stylecrafthomes.com/community/kennington-townhomes/"))
//				comName="Kennington Townhomes";
			
			U.log("comName::::::" + comName);

			// -----------address---&---lat-lng--------------------

			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String[] address = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] myAdd = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String geo = "False";
			String addSection = ALLOW_BLANK;

			address[0] = U.getSectionValue(comSec, "\"streetAddress\":\"", "\"");
			address[1] = U.getSectionValue(comSec, "\"addressLocality\":\"", "\"").replace("RIchmond", "Richmond");
			address[2] = U.getSectionValue(comSec, "\"addressRegion\":\"", "\"");
			address[3] = U.getSectionValue(comSec, "\"postalCode\":\"", "\"");
			
			String latSec = U.getSectionValue(comSec, "\"geoIndexed\":[", "]");
			latLng = latSec.split(",");
			latSec = latLng[0];
			latLng[0] = latLng[1];
			latLng[1] = latSec;
			U.log(Arrays.toString(address));
			U.log(Arrays.toString(latLng));
			

			if (address[0].length() < 4 && latLng[0].length() > 4) {
				address = U.getAddressGoogleApi(latLng);
				if (address == null)
					address = U.getAddressHereApi(latLng);
				geo = "TRUE";
			}
	
			address[0] = address[0].replace("Near ", "").replace("(Homesite 27)", "").replace("COMING SOON!,", "");

			// ============ Model homes ==============
			String combinedModelHtmls = ALLOW_BLANK;
			String id = U.getSectionValue(comSec, "\"_id\":\"", "\"");
			
			String[] homeSec = U.getValues(homeJson, "{\"@type\":\"", "\"type\":\"home");
			for(String home : homeSec)
				if(home.contains(id))
					combinedModelHtmls+=home;
			
			U.log("combinedModelHtmls: "+combinedModelHtmls.length());
			// --------fetch plan data---------
			String allPanData = ALLOW_BLANK;
			String[] planSec = U.getValues(planJson, "{\"@type\":\"", "\"type\":\"plan");
			for(String plan : planSec)
				if(plan.contains(id))
					allPanData+=plan;

			U.log("allPanData: "+allPanData.length());
			// -------prices-----------------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			
			comHtml = comHtml.replace(" from the upper 300s.\"", "").replace("from the upper $200s", "from the upper $200,000").replace("From the $390s", "From the $390,000").replaceAll("0s", "0,000");
			String[] price = U.getPrices(comSec + comHtml + allPanData + combinedModelHtmls,
					"from the upper \\$\\d{3},\\d{3}|from the upper \\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
//			U.log(">>>>>>>>>>>>" + Util.matchAll(comSec + comHtml + allPanData + combinedModelHtmls , "[\\s\\w\\W]{30}650000[\\s\\w\\W]{30}", 0));
			// ----------square feet-----------
			comHtml = comHtml.replaceAll("With over \\d,\\d{3} sq. ft. of interior and exterior", "");
			String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
			
			
			String[] sqFt = U.getSqareFeet(comHtml.replace("From the $250s", "From the $250,000") + comSec + combinedModelHtmls + allPanData,
					"\"sqft\":\\d+|\"sqftHigh\":\\d+|\"sqftLow\":\\d+|townhomes, with \\d,\\d{3}–\\d,\\d{3}\\+ sq.ft.|\\d,\\d{3}–\\d,\\d{3} sq\\. ft|loor plans with \\d,\\d{3}–\\d,\\d{3} square feet|From \\d{1},\\d{3} sq. ft|\\d{1},\\d{3} to over \\d{1},\\d{3} square feet|Sq. Footage: \\d+<| over \\d,\\d+ square feet|Over \\d,\\d{3} sq. ft.|\\d,\\d{3}\\+ sq. ft.|\\d,\\d{3} sq. ft.",
					0);
			minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

			U.log("minSqFt :" + minSqFt + " maxSqFt:" + maxSqFt);
			// ----square feet end


			// ------------------comunity Type---------------
			String comType = ALLOW_BLANK;
			
			String[] remConSec = U.getValues(comHtml, "{\"@context\":", "}");
			
			for(String rem : remConSec)
				comHtml = comHtml.replace(rem, "");
			

			comHtml = comHtml.replaceAll(
					"Richmond Country Club|Hermitage Country Club|Sycamore Creek Golf Course\"|Brandermill Golf Course\"|agnolia Green Golf Course|Golf Club\",\"type|Active-Adult Buyers|Stonehenge Golf & Country Club",
					"");
			
			comHtml = comHtml.replaceAll("55-plus community|redefines 55\\+ living|55\\+ Bon Air community|those 55", "ages 55+");
			
			String desc=U.getSectionValue(comHtml, "<div class=\"DetailWelcome_leadP\"", "</p>")+
					U.getSectionValue(comHtml, "Community Highlights</h3", "</ul>");
			
			comType = U.getCommunityType((desc).replace("homes for those 55+", "55+ Community"));
//			U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}55-plus community[\\w\\s\\W]{20}", 0));
			U.log("comType=="+comType);
			// ---------propType-----------
			String pType = ALLOW_BLANK;
			comHtml = comHtml.replaceAll(
					"kennington-townhomes|\"title\":\"Kennington Townhomes\"|greenwich-walk-townhomes|\"title\":\"Greenwich Walk Townhomes at FoxCreek\"|walk-townhomes-at|Apartments_|-Apartments_|adison_Cottage_CAM_v1|-townhomes|freestyle\">\\s*<h2>Greenwich Walk Townhomes|\"Greenwich Walk Townhomes|Villas at Archer Springs</option>|Villas at FoxCreek</option>|Walk Villas|>Villas|Walk Townhomes|Village<",
					"");
			comHtml = comHtml.replace("Luxury estate community", "Luxury home estate community").replaceAll("traditional down payment", "");
			if (allPanData != null)
				allPanData = allPanData.replace("Cottage</h4>", "COTTAGES").replace("Bungalow</h4>", "Bungalow Series")
						.replaceAll("Traditional</h4>|TRADITIONAL</h4>", "Traditional exterior").replace("<h4>Colonial</h4>", "Colonial")
						.replace("<h4>Craftsman</h4>", "craftsman styling")
						.replace("<h4>Farmhouse</h4>", "Farmhouse home")
						.replace("<h4>Traditional</h4>", "traditional style")
						.replace("<h4>Bungalow</h4>", "Bungalow Home")
						.replaceAll("Traditional exterior", "New Tradition Homes");
			
			String remStr = "on new apartment for young black |title\":\"Kennington Townhomes\"|kennington-townhomes|-townhomes|freestyle\">\\s*<h2>Greenwich Walk Townhomes|\"Greenwich Walk Townhomes|Villas at Archer Springs</option>|Villas at FoxCreek</option>|Walk Villas|>Villas|Walk Townhomes|Village<";

			if (combinedModelHtmls != null)
				combinedModelHtmls = combinedModelHtmls.replaceAll("<h4>COLONIAL</h4>|<h4>Colonial</h4>",
						"The Colonial");
			comSec = comSec.replace("The only detached", "detached home");
			String headLine=U.getSectionValue(comSec, "\"headline\":\"", "\"");
			
			String[] remSec = U.getValues(comSec, "{\"@type\":\"ImageObject\"", "}");
			for(String rem1 : remSec) {
				comSec=comSec.replace(rem1, "");
				comHtml=comHtml.replace(rem1, "");
			}

			remSec = U.getValues(combinedModelHtmls, "{\"@type\":\"ImageObject\"", "}");
			for(String rem1 : remSec) {
				combinedModelHtmls=combinedModelHtmls.replace(rem1, "");
			}
			remSec = U.getValues(allPanData, "{\"@type\":\"ImageObject\"", "}");
			for(String rem1 : remSec) {
				allPanData=allPanData.replace(rem1, "");
			}
			String remm =U.getSectionValue(comHtml, "window.__PRELOADED_STATE__ =", "</script>");
if(remm!=null) {
	comHtml=comHtml.replace(remm, "");
}
			comHtml=comHtml.replace("Here our trademark craftsmanship comes included", "Here our trademark craftsman styling comes included")
					.replaceAll("Clubhouse_v21.03_22_Patio_|Clubhouse_v21.03_24_Patio_1", "");


			pType = U.getPropType(comName + (comHtml + comSec + allPanData + combinedModelHtmls)
					.replaceAll("\"caption\":\"Cottage\"|HOA is not included|-townhomes|:\"Kennington Townhomes", "")
					.replaceAll(remStr
							+ "kennington-townhomes|\"title\":\"Kennington Townhomes\"|greenwich-walk-townhomes|\"title\":\"Greenwich Walk Townhomes at FoxCreek\"|walk-townhomes-at|HOA is not included|Village|Villa Park|VILLAS AT|[V|v]illa[s]* [a|A]t|villas-|\"Villas|Villas:|Village:",
							"")
					.replace("<h4>Craftsman</h4>", "craftsman styling").replace("<h4>Farmhouse</h4>", "Farmhouse home")
					.replace("<h4>Traditional</h4>", "traditional style").replace("<h4>Bungalow</h4>", "Bungalow Home")
					.replaceAll("Traditional exterior", "New Tradition Homes"));
//			U.log("mmmmmm"+Util.matchAll( comHtml , "[\\w\\s\\W]{50}flex room[\\w\\s\\W]{50}", 0));

			// -----------dType-------------
//			comHtml = comHtml.replaceAll("\\+ stories", " stories ");
//			U.log("QQQQ"+Util.matchAll(comHtml+allPanData+combinedModelHtmls  ,"[\\w\\W\\s]{500}stories[\\w\\W\\s]{500}", 0));

			allPanData = allPanData.replaceAll("1.5 Stories|\"stories\":1.5", "one-and-one-half story").replace("\"stories\":", "Story ");
			combinedModelHtmls = combinedModelHtmls.replaceAll("1.5 Stories|\"stories\":1.5", "one-and-one-half story").replace("\"stories\":", "Story ");
			String dType = ALLOW_BLANK;
//			U.log("comHtml=="+comHtml);
			dType = U.getdCommType(
					(U.getNoHtml(comHtml + comSec + allPanData + combinedModelHtmls).replaceAll("1.5 Stories|\"stories\":1.5", "one-and-one-half story").replaceAll("Branch|floor|Floor", "")));
			//

			// ----------pStatus----------
			// U.log(comSec);
			String rnSec[] = U.getValues(comSec, "<div class=\"hidden\">", "</div>");
			if (rnSec.length >= 1) {
				for (String rsec : rnSec) {
					comSec = comSec.replace(rsec, "");
				}
			}
			
			
			comSec = comSec.replaceAll("1 HOME<br />\\s*REMAINS", "1 home remains")
					.replaceAll("NOW <br />\\s*SELLING ", "Now selling")
					.replaceAll("GRAND<br />\n\\s*OPENING </div>", "GRAND OPENING </div>")
					.replaceAll("Coming Fall 2020! </li>\\s*<li> Join The VIP", "")
					.replaceAll("FINAL<br />\n\\s*HOMESITES </div>", "FINAL HOMESITES </div>")
					.replace("New Section: Coming Soon", "New Section Coming Soon")
					.replaceAll("\"status\":\"Coming Soon\"", "");
			
			if(joinList!=null)
				joinList = joinList.replace("sold out of our current section", "sold out current section");
			
			comHtml = comHtml
					.replace("sold out of our current section", "sold out current section")
					
					.replaceAll(
					"<p>Coming Soon!</p>|currently sold out of homes|kennington-townhomes\\|\"title\":\"Kennington Townhomes\"|greenwich-walk-townhomes|\"title\":\"Greenwich Walk Townhomes at FoxCreek\",|walk-townhomes-at|Model Homes and select Quick Move-In Homes for self-guided tours|community \\(Coming Soon!\\), explore|COMING SOON!<br />|ahead of the grand opening|\\. COMING SOON!</p>|Publix \\(Coming Soon\\)|[g|G]rand [o|O]pening [o|O]ffer|/quick-move-in-homes/\">Quick Move-In Homes</a>|Station is now open|has sold out|homesites sold out|Coming Soon: Single|MODEL COMING SOON|-text=\"Coming soon,|Quick Move-In Homes</a></li>| just released a new section at|INFORMATION CENTER COMING SOON:|now opening up sign-ups|Clubhouse is now open|CLUBHOUSE IS NOW OPEN|before the public Grand",
					"").replace("Now Selling: Section 4", "Now Selling Section 4")
					.replace("New Section: Coming Soon", "New Section Coming Soon").replace("NOW AVAILABLE: BASEMENT HOMESITES", "BASEMENT HOMESITES NOW AVAILABLE").replace("New Section: Coming Soon", "New Section Coming Soon").replace("Now selling our final section", "Now selling final section").replaceAll(
							"<li>Coming Summer 2020|Coming Fall 2020! </li>\\s*<li> Join The VIP|Coming-Soon_| Henrico community \\(Coming Soon|COMING SOON!<br />|Coming soon, this bark park|We've just released|\\(Coming Soon\\)|this your last",
							"");// .replace("Only two move-in-ready homes remain", "Only 2 homes remain");
			String pStatus = ALLOW_BLANK;
			comHtml=U.removeSectionValue(comHtml, "Other Nearby Communities</h3>", "Visit The Blog</a>");
//			U.log("comHtml"+comHtml);
			if(comHtml!=null) {
			comHtml=comHtml.replaceAll("King William, VA (Coming Soon!)", "");
			}else {
				comHtml=ALLOW_BLANK;
			}
			comSec=comSec.replace("(Coming Soon!)", "");
//			U.log("PPPP"+Util.matchAll(comHtml + comSec ,"[\\w\\W\\s]{50}Quick Move-in[\\w\\W\\s]{50}", 0));
  U.log("headLine== "+headLine);
			pStatus = U.getPropStatus((comHtml + comSec + joinList + headLine).replace("Basement homesites are now available", " Basement homesites now available").replace("Coming Soon — Join the VIP List", "").replace("Now Selling at The Outpost at Brewers Row", "").replace("final section of available townhomes — coming in 2022", "final section of townhomes coming in 2022").replace("NOW AVAILABLE: BASEMENT HOMESITES", "Now Available Basement Homesites").replace("VA (Coming Soon!)|amenities. Coming soon", ""));
			U.log("pStatus==="+pStatus);  //+headLine june 
			
			// image
//			 if(comUrl.contains("https://www.stylecrafthomes.com/communities/henrico/the-village-at-millers-lane"))pStatus = "Quick Move-In Home, Homesites Are Now Available, Now Selling";
			// ------------notes------------
			String notes = ALLOW_BLANK;
			notes = U.getnote(comHtml);
			// U.log(comHtml.contains("<h3>Quick Move-In Homes</h3>") &&
			// !pStatus.contains("Quick"));
			if ((comHtml.contains("<h3>Quick Move-In Homes</h3>")
					|| comHtml.contains(" <h3 id=\"homes\">Quick Move-In Home</h3>")
					|| comHtml.contains("https://stylecrafthomes.com/home/14391-orchard-vista-ln-1/"))
					&& !pStatus.contains("Quick")) {
				if (pStatus.length() < 1 || pStatus == ALLOW_BLANK) {
					pStatus = "Quick Move-In Home";
				} else {
					pStatus = pStatus + ", Quick Move-In Home";
				}
			}
			pStatus = pStatus.replaceAll("Quick Move-in Homes|Quick Move-in Home|Quick Move-in", "Quick Move-In Home")
					.replaceAll("\\d+ Quick Move-In Home", "Quick Move-In Home");
		

			if (comUrl.contains("https://stylecrafthomes.com/community/cambria-cove/"))
				pStatus = pStatus + ", Basement Homesites Available";

			if (comUrl.contains("https://stylecrafthomes.com/community/kennington-townhomes"))
				pStatus = pStatus.replace(", Grand Opening", "");
			

			pStatus = pStatus.replace("Currently Sold Out, Sold Out", "Currently Sold Out").replace("New Section Coming Winter 2021, Coming Winter 2021",
					"New Section Coming Winter 2021");
			
			if(comUrl.equals("https://www.stylecrafthomes.com/communities/king-william/kennington"))pStatus=ALLOW_BLANK;
			if(comUrl.contains("https://www.stylecrafthomes.com/communities/richmond/the-outpost-at-brewers-row"))pStatus=ALLOW_BLANK;
            if(comUrl.contains("https://www.stylecrafthomes.com/communities/chesterfield/villas-at-iron-mill"))pType=pType.replace(" Flex Homes,", "");
            
            String lotIds="";
//            try {
//          U.log(">>>>>>>>>"+U.getSectionValue(comSec, "\"interactive_community_link\":\"", "\",\""));

            if(U.getSectionValue(comSec, "\"interactive_community_link\":\"", "\",\"")!=null) {
//            	U.log("--------"+U.getSectionValue(comSec, "\"interactive_community_link\":\"", "\",\""));
	            String lotHtml = getMyHtml(U.getSectionValue(comSec, "\"interactive_community_link\":\"", "\",\""),driver);
	           U.bypassCertificate();
	           String []lotData=U.getValues(lotHtml, "<div id=\"hotspot_", "\">");
	           if(lotData.length>0) {
					lotIds=Integer.toString(lotData.length);
				}
//	            String siteMapId = U.getSectionValue(lotHtml, " data-sitemapid='", "'"); 
//	            U.log(siteMapId);
//	            if(siteMapId!=null) {
//	                U.log(U.getSectionValue(comSec, "\"interactive_community_link\":\"", "\",\""));
//	            	lotHtml = sendPostRequestAcceptJson("https://newstar.stylecrafthomes.com/NSEWeb/OLSL/SitemapLite.aspx/GetSiteMapLotIndicators", "{ProjID:'',LotNo:'',SitemapID:'"+siteMapId+"',CategoryID:'',View:'PublicView'}");
//	            	lotHtml = StringEscapeUtils.unescapeJava(lotHtml);
//	            	if(lotHtml!=null)
//	        			lotIds = Util.matchAll(lotHtml, "\\{\"LotNo\"", 0).size()>0?Util.matchAll(lotHtml, "\\{\"LotNo\"", 0).size()+"":ALLOW_BLANK;
//	            }
            }
//            }catch(Exception e) {}
            
            U.log("lotIds==="+lotIds);
			if(lotIds.length()<1)lotIds=ALLOW_BLANK;
            data.addCommunity(comName, comUrl, comType);
			data.addAddress(address[0].replaceAll(",|amp;|amp", ""), address[1].trim(), address[2].trim(),
					address[3].trim());
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(notes);
			data.addUnitCount(lotIds);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;

		//
		// }catch (Exception e) {
		// // TODO: handle exception
		// }
	}
	
	
	
	public static String getMyHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					driver.manage().deleteAllCookies();
					driver.manage().window();
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(2000);
//					((JavascriptExecutor) driver).executeScript(
//							"window.scrollBy(0,400)", ""); 
					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		U.log(requestUrl+payload);
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
//		log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
					"63.161.104.189",3128));
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
//	        connection.setRequestProperty("csrf-token", "I7lZaFQo-GLVTxyV0VKSY21DVTQHTRH3cAHM");
	        connection.setRequestProperty("Accept", "*/*");
//	        connection.setRequestProperty("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBOYW1lIjoidHJ1c3MiLCJpc1N1cGVyQ2xpZW50IjpmYWxzZSwiZmxhZ3NoaXBQcml2aWxlZ2VzIjpbIlBVQkxJQyIsIkFORVdHT19BUFBTIl0sImlhdCI6MTY0ODE5NzExOCwiZXhwIjoxNjQ4MjQwMzE4fQ.HwBV_zF0h7UyyEZ_xWwyWuJOTpFVJp3HEXqeDOpdfqw");
//	        connection.setRequestProperty("Content-Length", payload.length()+"");
	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
//	        connection.setRequestProperty("Origin", "https://newstar.stylecrafthomes.com");
//	        connection.setRequestProperty("Referer", "https://newstar.stylecrafthomes.com");
//	        connection.setRequestProperty("Sec-Fetch-Dest", "empty");
	        connection.setRequestProperty("Cache-Control", "max-age=0");
	        connection.setRequestProperty("Connection", "keep-alive");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");

	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}

}