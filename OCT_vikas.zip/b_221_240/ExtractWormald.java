/**
 * @author Upendra Singh 
 * @date 01/2017
 * 
 */
package com.shatam.b_221_240;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
//import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.omg.CosNaming.NamingContextPackage.NotEmpty;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
//import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWormald extends AbstractScrapper {
	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;

	ChromeDriver driver = null;

	public ExtractWormald() throws Exception {
		super("Wormald", "https://wormald.com/");
		// TODO Auto-generated constructor stub
		LOGGER = new CommunityLogger("Wormald");
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractWormald();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Wormald.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		// U.log(U.getCache("https://wormald.com/new-homes/"));
		//========================================================
		
		
		U.setUpChromePath();
		
		
		  ChromeOptions options = new ChromeOptions ();
		  Map<String, Object> prefs = new HashMap<String, Object>();
		  // browser setting to disable image
		    prefs.put("profile.managed_default_content_settings.images", 2);
		  options.addExtensions (new File("/home/shatam12/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
		  options.setExperimentalOption("prefs", prefs);		
//			options.addArguments("start-maximized"); 
		  DesiredCapabilities capabilities = new DesiredCapabilities ();
		  
		  capabilities.setCapability(ChromeOptions.CAPABILITY, options); 
		  driver = new ChromeDriver(capabilities); //capabilities
		  
		  
		//=============================================================== 
//		Thread.sleep(30000);

//		Proxy proxy = new Proxy();
//		proxy.setHttpProxy("34.138.225.120:8888");
//		proxy.setSslProxy("34.138.225.120:8888");
//		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
//		capabilities.setCapability(CapabilityType.PROXY, proxy);
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("start-maximized");
//		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//		driver = new ChromeDriver();

		String mainHtml = U.getHtml("https://wormald.com/new-homes/", driver);
		U.log(U.getCache("https://wormald.com/new-homes/"));
		// String mainSec=U.getSectionValue(mainHtml, "var pins =", "</script>");
		// String comSecs[]=U.getValues(mainHtml, "banner uk-text-center uk-position-top
		// uk-padding-small uk-background-blend-multiply", "Directions");
		String[] comSecs = U.getValues(mainHtml, "<div class=\"uk-card uk-card-default uk-card-small\">", "</li>");
//		U.log(comSec.length);
		U.log("comSecs.length: " + comSecs.length);
		for (String comData : comSecs) {
			String comUrl = U.getSectionValue(comData, "<a href=\"", "\">").replace("\\/", "/");
			U.log(comUrl + "\n");
			// U.log(comData);
			if (comUrl.contains("homes-for-sale"))
				continue;
			addDetails(comUrl, comData);
//			break;
		}
		//addDetails("https://wormald.com/signature-properties/","");
		U.log(comSecs.length);
		LOGGER.DisposeLogger();
		driver.quit();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	if(!comUrl.contains("https://wormald.com/new-homes/the-river-view-estates-at-wormans-mill/"))return;
//	if(j>=15)
//try
		{
		if(comUrl.contains("?page_id=")) return;
			U.log(j + "\tComUrl == " + comUrl + "\n\t" + U.getCache(comUrl));
			U.log(U.getCache(comUrl));
			

			if ( comUrl.contains("https://wormald.com/signature-properties/")|| comUrl.contains("https://wormald.com/homes-for-sale/montgomery-county-md/")
					|| comUrl.contains("https://wormald.com/homes-for-sale/fairfax-county-va/") 
					|| comUrl.contains("https://wormald.com/homes-for-sale/arlington-county-va/")) {
				LOGGER.AddCommunityUrl(comUrl + "<<---Returned");
				return;
			}
//		U.log("comData===="+comData);
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "::::::::::::repeated");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);

			String communityName = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
			String flag = "False";
			String minPrice = ALLOW_BLANK;
			String maxPrice = ALLOW_BLANK;
			String minSqf = ALLOW_BLANK;
			String maxSqf = ALLOW_BLANK;
			String floorHtml = ALLOW_BLANK;
			
//			Thread.sleep(30000);
			String html = U.getHtml(comUrl, driver);
			String mapId = U.getSectionValue(html, "<script type=\"text/javascript\">var product_line = ", ";");
//			if(mapId==null)
//				mapId = U.getSectionValue(html, "<script type=\"text/javascript\">var product_line = ", ";");
			
			String descSec =U.getSectionValue(html, "<div class=\"text-block uk-padding\">", "<h3 class=\"uk-h5 uk-margin-top uk-margin-remove-bottom\">");
			String note = U.getnote(html);
			/*
			 * String remSec = U.getSectionValue(html,
			 * "<h2 class=\"uk-h3 uk-text-center uk-margin-large-bottom\">Other Locations You Will Love</h2>"
			 * , "<footer class=\"footer\">"); if (remSec == null) remSec =
			 * U.getSectionValue(html, "Other Locations You Will&nbsp;Love</h2>",
			 * "</html>"); if (remSec != null) html = html.replace(remSec, "");
			 */

//		U.log("comData==="+comData);
			String popUp = U.getSectionValue(html, "<h1 class=\"uk-padding-large uk-h4\">", "</h1>");
			//String popUpOne = U.getSectionValue(html, "<h2 class=\"uk-modal-title\">", "</p>").replace("", "");
			U.log("popUp: "+popUp);
			
			String popSec = U.getSectionValue(html, "class=\"uk-modal-title\"", "</p>");
//			U.log(popSec);
			
			String rem = U.getSectionValue(html, "<head>", "<body");
			if (rem != null)
				html = html.replace(rem, "");
			rem = null;
			String othercomm = U.getSectionValue(html,
					"<h2 class=\"uk-text-center uk-margin-large-bottom\">Other Locations You Will", "</html>");
			if (othercomm != null)
				html = html.replace(othercomm, "");
			
			
			if (comUrl.contains("/village-center-at-wormans-mill/"))
			{
				comUrl = "https://www.livevillagecenter.com/";
				html = U.getHTML("https://www.livevillagecenter.com/");
				communityName = "Village Center at Worman’s Mill";
				add = new String[] { "2470 Merchant Street", "Frederick", "MD", "21701" };
				latLong = new String[] { "39.4544563", "-77.388183" };
				// flag = "TRUE";
				floorHtml = U.getHTML("https://www.livevillagecenter.com/floorplans.aspx");
				floorHtml = floorHtml.replace("<span class='sr-only'>to</span>", "");

			} 
//			else if (comUrl.contains("new-homes/rosehaven-manor/")) {
//				// Frederick, Maryland
//				communityName = "Rosehaven Manor";
//				add = new String[] { "", "Frederick", "MD", "" };
//				latLong = U.getGoogleLatLngWithKey(add);
//				add = U.getGoogleAddressWithKey(latLong);
//				flag = "True";
//				note = "Address and Latlong taken from city & state";
//			} 
			else {

//			
				if (comUrl.contains("https://wormald.com/new-homes/quarry-springs")) {
					communityName = "Quarry Springs";
				}
				if (comUrl.contains("https://wormald.com/new-homes/rosehaven-manor/")) {
					communityName = "Rosehaven Manor";
				}
				if (comUrl.contains("https://wormald.com/new-homes/the-french-country-collection-at-the-links/")) {
					communityName = "The French Country Collection At The Links";
				} else {
					communityName = U.getSectionValue(html, "<h1 class=\"uk-padding-large uk-h4\">", "<");//.replace("&#8217;","'").trim();
					if (communityName != null)
						communityName = communityName
						.replace("River Place Townhomes ", "River Place")
								.replace("The River View Estates at Worman’s Mill",
										"The River View Estates at Worman's Mill")
								.replaceAll(" <small class=\"hero-subtext\">Final Opportunity</small>", "");
					else if (comUrl.contains("https://wormald.com/new-homes/wild-oak/"))
						communityName = "Wild Oak";
				}
				communityName=communityName.trim();
				U.log("communityName : " + communityName);
				
				//============================================================================
				
				// Check cookie before execution
//				try {
//				String mapHtml=sendPostRequestAcceptJson("https://wormald.com/wp/wp-admin/admin-ajax.php", "action=get_map_pins&json=1");
				String mapHtml=sendPostRequestAcceptJson("https://wormald.com/wp/wp-admin/admin-ajax.php", "action=get_project_cache");

//				U.log(mapHtml);
//				String[] commData=U.getValues(mapHtml, "\"product_line\":", " \"driving_directions\":");
				String[] commData=U.getValues(mapHtml, "{\n" + 
						"      \"id\":", " }\n" + 
								"    },");
				U.log("mapId===="+mapId);
//				U.log("CommData======"+commData.length);
				for(String com_data:commData) {
					if(com_data.contains(mapId)) {
						comData+=com_data;
					}
				}
				String addsec="";
				
//				U.log("comData===="+comData);
//				JsonObject jobject = (JsonObject)new JsonParser().parse(mapHtml);
//				JsonArray jAddArray= (JsonArray)jobject.get("address_arr");
////				JsonObject jCommArray= (JsonObject)jobject.get("fields_arr");
////				U.log("jCommArray======"+jCommArray);
//				JsonObject jLatLngArray= (JsonObject)jobject.get("map_tiles");
//				
//				for(JsonElement ar:jAddArray){
//					if((ar+"").contains(mapId)) {
//						addsec=ar.getAsJsonObject().get("address")+"";
////						U.log("addsec======"+addsec);
//						addsec=addsec.replace("\"", "");
////						U.log(ar.getAsJsonObject().get("address"));
//						flag = "True";
//					}
//				}
				
				
				
//				} catch(Exception e) {}
				if(comData.contains(" uk-button-primary uk-disabled\">Sold Out</div>"))
				{
					flag = "True";
				}
				
				
				addsec=U.getSectionValue(comData, "\"address\": \"", "\",");
				
				
				//===============================================================================
				U.log("hhhhhhhhhhh  " + addsec);
////				if(comUrl.contains("https://wormald.com/new-homes/wild-oak/")) addsec = "Pooks Hill Rd, Bethesda, MD 20814";
////				if(comUrl.contains("https://wormald.com/new-homes/rosehaven-manor/")) addsec = "Pooks Hill Rd, Bethesda, MD 20814";
				if (addsec != null) {
					addsec = addsec
							.replace("Wildoak Drive<br> Bethesda MD, 20814 <p>", "Wildoak Drive, Bethesda, MD, 20814 ")
							.replace("<td>", "").replaceAll("<br>\\s*", ",").replace("Sold Out!", "").trim()
							.replaceAll(", USA|Opening July 13, 2019|Calculating Distance &hellip;|<.*?>", "");

					U.log("AddSec ==" + addsec);
//					if(comUrl.contains("https://wormald.com/new-homes/the-grand-manor-collection-at-spring-hollow/"))addsec = "2131 Regina Terrace, Clarksburg MD, 20871";
					addsec = addsec.replace(", MD", " MD,").replace(", WV", " WV,").replace(", PA", " PA,")
							.replace("Sales Office,", "");
					if (addsec.contains(Util.match(addsec, " [A-Z]{2},"))) {

						String[] tempAdd = addsec.split(",");
						U.log(Arrays.toString(tempAdd));
						if (tempAdd.length == 3) {
							add[0] = tempAdd[0];
							add[3] = tempAdd[2];
							if (add[3] != null && add[3].length() > 5) {
								add[3] = add[3].replaceAll("<.*?>|Google", "").trim();
							}
							/*
							 * U.log(tempAdd[2]+"\n"+Util.match("\\d+", tempAdd[2])); add[3] =
							 * Util.match(" \\d{5}", tempAdd[2]); if(add[3] == null) add[3] =
							 * tempAdd[2].replaceAll("(\\d{5} (.*?))", "$1");
							 */
							add[2] = tempAdd[1].substring(tempAdd[1].length() - 3, tempAdd[1].length());// Util.match(tempAdd[1],
																										// " [A-Z]{2}");
							add[1] = tempAdd[1].replaceAll(add[2], "").trim();
						}
					}
					else {
						add=U.getAddress(addsec);
					}
				}
				
				if(comUrl.contains("https://wormald.com/new-homes/bennett-preserve/"))
				{
					addsec=U.getSectionValue(html, "Sales Office</strong></small><br />", "<p>");
					addsec=addsec.replace("<br />", ", ").replace(",  Ijamsville MD,", ",  Ijamsville, MD");
					U.log("addsec======="+addsec);
					add=U.getAddress(addsec);
				}
				
//				if (comData.contains(" uk-disabled\">Sold Out</div>")) {
//					U.log(comData);
//					String cityStateSec = U.getSectionValue(comData, "Single Family Homes in ", " </div>");
//					if (cityStateSec == null)
//						cityStateSec = U.getSectionValue(comData, " Townhomes in ", "</div>");
//					String cityState[] = cityStateSec.split(",");
//					add[1] = cityState[0];
//					add[2] = cityState[1];
//					latLong = U.getlatlongGoogleApi(add);
//					add = U.getAddressGoogleApi(latLong);
//					flag = "True";
//					note = "Address and Latlong taken from city & state";
//				}
//
				if (comUrl.contains("he-river-view-estates-at-wormans-mill/")) {
					add[0] = "Mill Island";
					
				}

				U.log("Addessssss : " + Arrays.toString(add));
				String latLngSection = U.getSectionValue(html, "href=\"https://maps.google.com", ">");
//				latLngSection= jLatLngArray.get(mapId).getAsJsonObject().get("position")+"";
				U.log("==||" + latLngSection);
//				if (latLngSection != null) {
//					latLngSection = Util.match(latLngSection, "\\d{2}\\.\\d+%2C\\+-\\d{2,3}\\.\\d+");
//					if (latLngSection != null)
//						latLong = latLngSection.split("%2C\\+");
//				}
				if(latLngSection!=null ) {
				if (latLong[0] == ALLOW_BLANK || latLong[0].length() < 3 ||latLong[0]==null ) {
					latLong[0] = U.getSectionValue(latLngSection, "\"lat\":", ",");
					latLong[1] = U.getSectionValue(latLngSection, "\"lng\":", "}");
				}
				}
				if(latLong[0]==null && latLong[1]==null)
				{
					latLong[0] = U.getSectionValue(comData, "\"lat\":", ",");
					latLong[1] = U.getSectionValue(comData, "\"lng\":", ",");
				}

				if(latLngSection==null)
				{
					latLong[0] = U.getSectionValue(comData, "\"lat\":", ",");
					latLong[1] = U.getSectionValue(comData, "\"lng\":", ",");
				}
				U.log("Lat :" + latLong[0] + "\tLng :" + latLong[1]);

				if (add[1] != ALLOW_BLANK && add[2] != ALLOW_BLANK) {
					if (latLong[0] == ALLOW_BLANK || latLong[0] == null) {
						latLong = U.getlatlongGoogleApi(add);
						if (latLong == null)
							latLong = U.getlatlongHereApi(add);
						flag = "TRUE";
					}
				} else if (add[1] == ALLOW_BLANK && add[2] == ALLOW_BLANK) {
					if (latLong[0] != ALLOW_BLANK || latLong[0] != null) {
						add = U.getAddressGoogleApi(latLong);
						if (add == null)
							add = U.getAddressHereApi(latLong);
						flag = "TRUE";
					}
				}
			}

			if (comUrl.contains("the-grand-manor-collection-at-bennett-preserve/")
					)
				flag = "FALSE";
			html = html.replace("Just a few homesites remain", "Just few homesites remain");
			html = U.removeSectionValue(html, "Other Locations You Will Love</h2>", "</html>");

			if(comData.contains("</span>Directions</a>")) {
				flag = "False";
			}
			
			
			// ================== Floor Urls =====================
			String floorPlanSec = U.getSectionValue(html, "Floor Plans at This Location</h2>",
					"<div class=\"uk-section\">");

			if (floorPlanSec == null)
				floorPlanSec = U.getSectionValue(html, "Homes at This Location", "</ul>");
			
			if(html.contains("Homes Previously Available at This Location")) {
				floorPlanSec = U.getSectionValue(html, "Homes Previously Available at This Location", "uk-section other-locations\"");
//				U.log("HELLO "+floorPlanSec);
				if(floorPlanSec == null) {
					floorPlanSec = U.getSectionValue(html, "Homes Previously Available at This Location", "Customer Testimonials");
//					U.log("HELLO SEC "+floorPlanSec);
				}
			}

			String combinedFloorHtml = null;
			if (floorPlanSec != null) {
				String floorUrlSection[] = U.getValues(floorPlanSec, "<h3 class=", "</a>");

				U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
				if (floorUrlSection.length == 0)
					floorUrlSection = U.getValues(floorPlanSec, "<div class=\"uk-card-body\">", "Learn More</a>");

				U.log("floorUrlSection Length: " + floorUrlSection.length);
				for (String floorUrlSec : floorUrlSection) {
//				U.log(floorUrlSec);
					String floorUrl = U.getSectionValue(floorUrlSec, "<a href=\"", "\"");
					U.log("floorUrl --> " + floorUrl);
					
					Thread.sleep(15000);
					String _floorHtml = U.getHtml(floorUrl, driver);
					
					combinedFloorHtml = combinedFloorHtml
							+ U.getSectionValue(_floorHtml, "<div class=\"uk-section\">", "</table>")
							+ U.getSectionValue(_floorHtml, "<tbody><tr class=\"uk-text-muted\">", "</div>");
				}
			}
			String[] buildFloor = U.getValues(html, "Ready to Build</span></div>", "Learn More");
			String buildHtml = "";
			String[] quickHome = {};
			String QuickSec = U.getSectionValue(html, "Quick Move Ins</h2>", "<div class=\"uk-section\"");
			if (QuickSec == null)
				QuickSec = U.getSectionValue(html, "Homes at This Location</h2>", "<div class=\"uk-section\"");
			String[] showHome = {};
			String showHomeSec = U.getSectionValue(html, ">Showcase Homes</h2>", "<div class=\"uk-section");

			if (QuickSec != null) {
				quickHome = U.getValues(QuickSec, "<a class=\"uk-cover-container\"", "Learn More");
				for (String a : quickHome) {
					String url = U.getSectionValue(a, "<a href=\"", "\"");
					U.log("Quickhome Url : " + url);
					buildHtml += U.getHtml(url, driver).replace(" 3-level", " story 3");
				}
			}

			if (showHomeSec != null) {
				showHome = U.getValues(showHomeSec, "<a class=\"uk-cover-container\"", "Learn More");
				for (String a : showHome) {
					String url = U.getSectionValue(a, "<a href=\"", "\"");
					U.log("Quickhome Url : " + url);
					buildHtml += U.getHtml(url, driver).replace(" 3-level", " story 3");
				}
			}
			for (String string : buildFloor) {
				//remSec = null;
				String url = U.getSectionValue(string, "<a href=\"", "\"");
				U.log("buildFloor Url : " + url);
				String tempHtml = U.getHtml(url, driver);
				U.log("CACHE URL: "+U.getCache(url));
				/*
				 * remSec = U.getSectionValue(tempHtml,
				 * "<table class=\"uk-table table-info table-label-text uk-table-divider\">",
				 * "<footer class=\"footer\">"); // U.log("-->"+remSec); if (remSec != null)
				 * tempHtml = tempHtml.replace(remSec, "");
				 */
				buildHtml += tempHtml;

			}
			String homeDataSec="";
			String homeSec=U.getSectionValue(html, "Homes at This Location</h2>", "Customer Testimonials</h2>");
//			U.log("homeSec====="+homeSec);
			if(homeSec==null)
				homeSec=U.getSectionValue(html, "at This Location</h2>", "<footer class=\"footer\">");
			if(homeSec!=null)
			{
				String[] homeSection=U.getValues(homeSec, "<a class=\"uk-cover-container\"", "Learn More</a>");
				U.log("homeSec====="+homeSection.length);
				for(String homeData : homeSection) 
				{
					String homeUrl=U.getSectionValue(homeData, "href=\"", "\">");
					String homeHtml=U.getHtml(homeUrl, driver);
					homeDataSec+=U.getSectionValue(homeHtml, "<title>", "View Floor Plan")
							+U.getSectionValue(homeHtml, "<div class=\"uk-section\">", "Request Info</a>");
				}
			}
//			U.log("homeDataSec====="+homeDataSec);
			

			html = html.replace("From $1.6M-$2M", "From $1,600,000,From $2,000,000").replace("$1.24M", "$1,240,000")
					.replace(" $1.24m", " $1,240,000").replaceAll("0s|0's|0'S", "0,000").replace("$1Ms", "$1,000,000")
					.replace(" $1.38m", "$1,380,000").replace("from the $1Ms", "From the low $1,000,000")
					.replace("From the low $1.7M", "From the low $1,700,000");
			U.log("comData=="+comData);
			comData=comData.replaceAll("0s", "0,000")
					.replace("$1.7M", "$1,700,000")
					.replace("$1M", "$1,000,000")
					.replace("$1.8M", "$1,800,000")
					.replace("$2M+", "$2,000,000")
					.replace("$1.27M", "$1,270,000"); 
			// comData = comData.replaceAll("$2M", "$2,000,000");
			comData = formatMillionPrices(comData);
//			U.log(combinedFloorHtml);
			comData = comData.replaceAll("1,270,000|ingle Family Homes<br>\\$794,900<br>Frederick County", "");
			html = html.replace("2,656&nbsp;square feet", "2,656 square feet").replaceAll("\\$(\\d,)?\\d{3},\\d{3}<span class=\"strikethrough\">", "");
			String[] price = U.getPrices(html + comData,
					"From the low \\$\\d,\\d{3},\\d{3}|<strong>\\$\\d{3},\\d{3}</strong>|From \\$\\d,\\d{3},\\d{3}|Townhomes from \\$\\d{3},\\d{3}|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}",
					0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

//		U.log(Util.matchAll((floorHtml),"[\\w\\s\\W]{30}767 sq[\\w\\s\\W]{30}",0));

//		U.log(combinedFloorHtml);
			String[] sqft = U.getSqareFeet(
					(html + comData + buildHtml + floorHtml + combinedFloorHtml+homeDataSec+descSec),//.replaceAll("&nbsp;", ""),
					"\\d{3}-\\d{3} Sq.Ft.|\\d,\\d{3} - \\d,\\d{3}|\\d,\\d{3} <small class=\"uk-text-uppercase\">SQFT|\\d,\\d{3}<small class=\"uk-text-uppercase\">SQFT<|</span>\\d{3} Sq.Ft.</div>|"
					+ "<td>\\d{1},\\d{3}&nbsp;<small class|\\d,\\d{3}&nbsp;<small class=\"uk-text-uppercase\">SQFT|<td>\\d,\\d{3} - \\d,\\d{3}</td>|"
					+ "<th>SQFT</th>\\s+<td>\\d,\\d{3}&nbsp;-&nbsp;\\d,\\d{3}</td>|\\d,\\d{3}&nbsp;to \\d,\\d{3}&nbsp;square feet|SQFT</th>\\s*<td>\\d,\\d{3}\\s*-\\s*\\d,\\d{3}|"
					+ "square footage of \\d,\\d{3} – \\d,\\d{3}|Sqft_(.*?)\">\\d{3,4} - \\d{3,4}</td>|Sqft_(.*?)\">\\d{3,4}<|Base SQFT</dt><dd>\\d,\\d{3}|"
					+ "SQFT</th>\\s*<td>\\d,\\d+</td>|\"SQ. FT.\">\\d{3}|\"SQ. FT.\">\\d,\\d{3}|SQFT</th>\n" + 
					"\\d{3} Sq.Ft.</div>|<td>\\d,\\d{3} - \\d,\\d{3}</td>|\\d,\\d{3} square feet",0);
			
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];

//			if (comUrl.contains("quarry-springs/")) {
//				minSqf = "2,901";
//				//maxSqf = "3,582";
//			}

			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			U.log(Util.matchAll((html+comData+buildHtml+floorHtml + combinedFloorHtml),"[\\w\\s\\W]{30}4,284[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll((homeDataSec),"[\\w\\s\\W]{30}4,284[\\w\\s\\W]{30}",0));

			rem = "Craftsman-style clubhouse|Apartments</span>|estate-home|The Estate Home|custom-homes|Custom Homes </a>|<a class=\"uk-h3 uk-margin-remove-bottom\">Apartments</a>";
//		U.log(Util.match(buildHtml, ".*Manor Collection.*"));
			html = html.replace("New Luxury Elevator", "New Luxury home Elevator")
					.replace("luxury enclave", "luxury homes enclave")
					.replace("Rosehaven Manor", "Rosehaven Manor Homes ");

			String proptype = U.getPropType((communityName + (html + homeDataSec+comData + buildHtml).replaceAll(rem, ""))
					.replace("Authentic Modern Farmhouse", ""));
//			U.log(Util.matchAll(homeDataSec,
//					"[\\s\\w\\W]{30}luxur[\\s\\w\\W]{30}", 0));
			if (buildHtml != null) {
				buildHtml = buildHtml.replaceAll("Levels</th>\\s*<td>\\s*4 Above", "four- story");
			}
			if (combinedFloorHtml != null)
				combinedFloorHtml = combinedFloorHtml.replace("first-floor", " 1 Story")
						.replaceAll("Levels</th>\\s+<td>\\s+1 Above", " first Level")
						.replaceAll("Levels</th>\n\\s*<td>\n\\s*2 Above", " 2 story ");

			html = html.replaceAll("first floor", "");
			String dtype = U.getdCommType(
					(html + buildHtml.replaceAll("two-story box window elevations|single single-floor_plan", "")
							+ comData + combinedFloorHtml).replace("two-story box window", "")
									.replaceAll("The first floor owners’ suite is adjacent to the great room.|Levels</th>\n\\s*<td>\n\\s*2 Above", " 2 story "));

			html = html.replaceAll(
					"opportunity to live in|blend-multiply\">\\s+<span>Coming|miss the final opportunity|Only 7 homes remain for sale.\\s+\">|Dryer on inventory homes available|Just a few homesites remain|tile__banner\">Closeout|Coming soon: the|tile__banner\">Grand Opening|in 2020&nbsp;as the ",
					"");
//				.replaceAll("Quick Move Ins", "");

//		U.log(html);
//		U.log(popUp);
			if(popSec != null) {
				popSec = popSec.replace("Only One Ashcroft Home Remains", "Only One Home Remains");
			}
			
			String pstatus = U.getPropStatus((comData + html + popUp + popSec).replaceAll(
					"VERY LIMITED AVAILABILITY in our Luxury Apartment|<span>Coming Soon</span>|Homes Just Released for Sale|Homes Just Released for Sale!|During Grand Opening|\"map-infowindow-banner\\\">Coming Soon|map-infowindow-banner\\\">Coming|spectacular homes are sold out|close-out-at-crown/|CLOSE OUT AT CROWN|Selling final homesites from the community of Spring Hollow|Quick Move-Ins|quick-move-ins| Views<span class=\"br\"></span>Coming|title\">Quarry Springs Grand",
					""));
//			 U.log("MATCH: "+Util.matchAll(comData+html+popUp+popSec, "[\\s\\w\\W]{30}Only One Ashcroft Home Remains[\\s\\w\\W]{30}", 0));
			 U.log("pstatus: "+pstatus);

			U.log("Quick Homes ::" + quickHome.length);

			if (quickHome.length != 0 && !buildHtml.contains("Just Sold")) {
//				U.log("MMMMMMMMMKKKKKKKKKKKKKK");
				if (!pstatus.contains("Quick") && pstatus.length() < 4)
					pstatus = "Quick Move Ins";
				else
					pstatus = pstatus + ", Quick Move Ins";
			}

			html = html.replace("seniors 55 and over", "55 and greater.").replaceAll("country clubs within", "");
			String communityType = U.getCommunityType(html + comData);
			U.log("communityType : "+communityType);
			
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			if (comUrl.contains("https://wormald.com/new-homes/quarry-springs/"))
				communityName = "Quarry Springs";
			if (communityName.endsWith("Townhomes"))
				communityName = communityName.replace("Townhomes", "");

			add[3] = U.getNoHtml(add[3]);
			add[3] = Util.match(add[3], "\\d{5,6}");

//		if(pstatus.contains("Coming Soon") && pstatus.contains("Coming In 2021"))
//			pstatus = pstatus.replaceAll("Coming Soon", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");

//		if(pstatus.contains("Coming Soon") && pstatus.contains("Coming Late Summer 2021"))
//			pstatus = pstatus.replaceAll(", Coming Soon", "");

			if (proptype.contains("Townhouse") && proptype.contains("Townhome"))
				proptype = proptype.replaceAll("Townhouse", "").replace(", ,", ",").trim().replaceAll("^,|,$", "");
			if (comUrl.contains("https://wormald.com/new-homes/river-place-townhomes"))
				dtype = "4 Story";

			if (comUrl.contains("https://wormald.com/new-homes/bennett-preserve/"))
				dtype = "2 Story";
			
			
			/*
			 * if(comUrl.contains("https://wormald.com/new-homes/vanderbilts-on-the-green/")
			 * ) { minPrice="$514,990"; minSqf="2487"; maxSqf="2934"; }
			 */
			if (comUrl.contains("https://wormald.com/new-homes/the-georgetown-collection-at-eastchurch/")) {

				minSqf = "2,656";
//				maxSqf = "3110";
			}
//				pstatus = "5 homesites available, Coming Soon";
//				minPrice = ALLOW_BLANK;
//			}
			/*
			 * if (pstatus.equals("Sold Out")) { minPrice = ALLOW_BLANK; maxPrice =
			 * ALLOW_BLANK; }
			 */
			
			if (comUrl.contains("new-homes/the-estate-home-collection-at-crown/")) 
				proptype+=", Luxury Homes";
			if (comUrl.contains("the-grand-manor-collection-at-spring-hollow/"))
			{
				proptype="Patio Homes";
				dtype+=", 2 Story";
			}
			if (comUrl.contains("com/new-homes/the-river-view-estates-at-wormans-mill/")) 
				proptype+=", Estate-Style Homes";

			
			
			if (comUrl.contains("/the-river-view-estates-at-wormans-mill/"))
				pstatus = pstatus + ", Final Opportunity";
//        if(comUrl.contains("https://wormald.com/new-homes/wild-oak/")) note="Just Released for Sale";
			pstatus = pstatus.replace("Coming Soon, Coming Fall 2021", "Coming Fall 2021");
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), flag);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(
					pstatus.replace("Coming In 2021, Coming Summer/fall 2021, Coming Soon", "Coming Summer/fall 2021"));
			data.addNotes(note);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
//catch(Exception e){}
		j++;

	}

	// Format million price
	public static String formatMillionPrices(String html) {
		Matcher millionPrice = Pattern.compile("\\$\\d\\.\\d\\s*M", Pattern.CASE_INSENSITIVE).matcher(html);
		while (millionPrice.find()) {
			U.log(millionPrice.group());
			String floorMatch = millionPrice.group().replaceAll("\\s*M", "00,000").replace(".", ","); // $1.3 M
			html = html.replace(millionPrice.group(), floorMatch);
		} // end millionPrice
		Matcher millionPrice2 = Pattern.compile("\\$\\dM", Pattern.CASE_INSENSITIVE).matcher(html);
		while (millionPrice2.find()) {
			U.log(millionPrice2.group());
			String floorMatch = millionPrice2.group().replaceAll("M", ",000,000").replace(".", ","); // $2M
			U.log(floorMatch);
			html = html.replace(millionPrice2.group(), floorMatch);
		} // end
		Matcher millionPrice3 = Pattern.compile("\\$\\d.\\d{2}M", Pattern.CASE_INSENSITIVE).matcher(html);
		while (millionPrice3.find()) {
			U.log(millionPrice3.group());
			String floorMatch = millionPrice3.group().replaceAll("M", "0,000").replace(".", ","); // $1.56M
			U.log(floorMatch);
			html = html.replace(millionPrice3.group(), floorMatch);
		} // end
		Matcher millionPrice1 = Pattern.compile("\\$\\d\\.\\d{2}\\s*M", Pattern.CASE_INSENSITIVE).matcher(html);
		while (millionPrice1.find()) {
//			U.log(millionPrice.group());
			String floorMatch = millionPrice1.group().replaceAll("\\s*M", "00,000").replace(".", ",");
			html = html.replace(millionPrice1.group(), floorMatch);
		} //

		return html;

	}
	
	
	static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
		U.log(">>>>>>>>>>"+cacheFile);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
					"198.59.191.234",8080));
	        HttpURLConnection connection = (HttpURLConnection)url.openConnection(proxy);
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("Accept", "*/*");
	        connection.setRequestProperty("Cookie", "_fbp=fb.1.1653453323031.6840571; _uetvid=29b92e20933911ecabb195c437ed2c80; _gcl_au=1.1.404434906.1661409222; _gid=GA1.2.941085835.1661409223; _clck=1cb8wnn|1|f4b|0; PHPSESSID=c88eea5c3e360be11bbe7469b4ca915a; _clsk=1p723xa|1661410929323|24|1|m.clarity.ms/collect; cf_chl_2=1acedc17bf3eff5; cf_chl_prog=x14; cf_clearance=dUBXABlRZcLtZbiGFLkgqqML42q6ohFQ3dqSlXpRGU0-1661411367-0-150; _gat_gtag_UA_61905608_1=1; _ga_T9KDVW56VZ=GS1.1.1661409222.18.1.1661411368.0.0.0; _ga=GA1.1.569543103.1653453323; _uetsid=dcff8a40243f11ed9934cfa5ad15552c");
	        connection.setRequestProperty("Content-length", "24");
	        connection.setRequestProperty("Content-type", "application/x-www-form-urlencoded");
	        connection.setRequestProperty("Origin", "https://wormald.com");
	        connection.setRequestProperty("Referer", "https://wormald.com/new-homes/");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	
	
}