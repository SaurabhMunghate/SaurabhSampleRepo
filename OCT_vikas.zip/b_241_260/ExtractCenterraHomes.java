/**
 * @param args
 * @throws Exception
 * @author Pankaj Malode
 */
package com.shatam.b_241_260;

import java.io.FileNotFoundException;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCenterraHomes extends AbstractScrapper {
	static String BASEURL = "http://www.centerratx.com";
	CommunityLogger LOGGER;
	int counter = 0; 
	static int j = 0;
	static int k = 0;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractCenterraHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Centerra Homes.csv", a
				.data().printAll());
	}

	public ExtractCenterraHomes() throws Exception {

		super("Centerra Homes", BASEURL);
		LOGGER = new CommunityLogger("Centerra Homes");
	}

	public void innerProcess() throws Exception {

		String LLsec = ALLOW_BLANK;

		// AUSTIN
		String AustinHtml = U.getHTML(BASEURL+ "/Communities/austin-map.asp?AID=Austin");
		LLsec = U.getSectionValue(AustinHtml, "var mapData", "script>");
		AustinHtml = U.getSectionValue(AustinHtml, "class=\"mapNavHldr","div class=\"main") + "div class=\"media";
		String[] AustinVal = U.getValues(AustinHtml, "div class=\"bd",	"div class=\"media");
		String[] AusLLval = U.getValues(LLsec, "lat", "\"}");

		for (String aus : AustinVal) {
			String name = U.getSectionValue(aus, "strong>", "<");
			String url = U.getSectionValue(aus, "href=\"", "\"");
			String price = Util.match(aus, "\\$\\d+,\\d+");
			String sqft = Util.match(aus, "\\d,\\d+ Sq Ft");
			for (String aaa : AusLLval) {
				if (aaa.contains(name.trim())) {
					if (!url.contains("http"))
						url = BASEURL + url;
					if (url.contains("?cid")) {
						addType1(url, name, price, sqft, aaa, "Austin");
					} else {
						addType2(url, name, price, sqft, aaa, "Austin");
					}
				}
			}
		}

		// SAN ANTONIO

		String SanHtml = U.getHTML(BASEURL	+ "/Communities/san-antonio-map.asp?AID=SanAntonio");
		LLsec = U.getSectionValue(SanHtml, "var mapData", "script>");
		SanHtml = U.getSectionValue(SanHtml, "class=\"mapNavHldr","class=\"main") + "div class=\"media";
		String[] SanVal = U.getValues(SanHtml, "div class=\"bd","div class=\"media");
		String[] SanLLval = U.getValues(LLsec, "lat", "\"}");

		for (String san : SanVal) {
			String name = U.getSectionValue(san, "strong>", "<");
			String url = U.getSectionValue(san, "href=\"", "\"");
			String price = Util.match(san, "\\$\\d+,\\d+");
			String sqft = Util.match(san, "\\d,\\d+ Sq Ft");
			for (String sss : SanLLval) {
				if (sss.contains(name.trim())) {
					if (!url.contains("http"))
						url = BASEURL + url;
					if (url.contains("?cid")) {
						addType1(url, name, price, sqft, sss, "San-Antonio");
					} else {
						addType2(url, name, price, sqft, sss, "San-Antonio");
					}
				}
			}
		}

		LOGGER.DisposeLogger();
	}

	public void addType1(String url, String name, String price, String sqft,String LLsec, String region) throws Exception {
	//if(!url.contains("http://www.centerratx.com/communities/profile.asp?cid=1814"))return;
		{
			counter++;
			U.log(counter +region);
			String html = U.getHTML(url);
			html =U.removeComments(html);
			String HOMES = ALLOW_BLANK;
			if(html.contains("<span>Our Homes</span>")){
				HOMES = url.replace("profile", "homes");
				HOMES = U.getHTML(HOMES);
			}
			
			String FEATURES = url.replace("profile", "features");
			FEATURES = U.getHTML(FEATURES);
			FEATURES = FEATURES.replaceAll("elongated|irrigated", "");
			// ADD - LAT - LNG

			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = ALLOW_BLANK;
			U.log(LLsec);
			latlng[0] = Util.match(LLsec, "\\d{2,}.\\d{3,}");
			if (latlng[0] != null)
				LLsec = LLsec.replace(latlng[0], "");
			latlng[1] = Util.match(LLsec, "-\\d{2,}.\\d{3,}");

			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String ADD_SEC = U.getSectionValue(html, "community-address\">",
					"</div>");
			 U.log("ADD_SEC::"+ADD_SEC);
			
			geo = "FALSE";

			ADD_SEC = ADD_SEC.replace("<br/>", ",").replace("&nbsp;", ",");
			add = ADD_SEC.split(",");

			// PRICES SQFT
			html = html.replace("00’s", "00,000").replace("$250’s", "$250,000")
						.replace("3 million", "$3,000,000")
						.replace("$260s ", "$260,000").replace("$270s","$270,000").replace("320s", "320,000");
			html = html.replace("homes from the $290s ", "homes from the $290,000").replace(" from the $370s i", " from the $370,000 i");

			String[] Prices = U.getPrices(price + HOMES + html,
					"\\$\\d,\\d+,\\d+|\\$\\d+,\\d+", 0);
			if (Prices[1] == null)
				Prices[1] = ALLOW_BLANK;
			if (Prices[0] == null)
				Prices[0] = ALLOW_BLANK;

			String[] SqFt = U.getSqareFeet(sqft + html + HOMES,
							"\\d,\\d{3} square feet to just over \\d,\\d{3} square|\\d,\\d{3} square feet to just under \\d,\\d{3} square feet|\\d,\\d+ sq. ft. to over \\d,\\d+ sq. ft.|\\d,\\d+ Sq Ft|Sq.Ft.:</strong></td>\\W+<td>\\d,\\d+|Sq.Ft.:</strong></td>\\W+<td>\\W+\\d,\\d+ - \\d,\\d+|Sq.Ft.:</strong></td>\\W+<td>\\W+\\d,\\d+|over \\d{4} square feet| over \\d,\\d{3} square feet",
							0);
			if (SqFt[1] == null)
				SqFt[1] = ALLOW_BLANK;
			if (SqFt[0] == null)
				SqFt[0] = ALLOW_BLANK;
			
			//--------------each available homes data---------------------
			String[] HOMES_VAL = U.getValues(HOMES, "<h5 class=\"groupHd", "More Detail");

			String HOMESDATA = ALLOW_BLANK;
			for (String HOME_URL : HOMES_VAL) {
				//U.log("************************** 2");
				HOME_URL = U.getSectionValue(HOME_URL, "href=\"", "\"");
				U.log("::::::::::::::::::::::::"+"http://www.centerratx.com"+HOME_URL);
				String HOME_HTML = U.getHTML("http://www.centerratx.com"+HOME_URL);
				if (HOME_URL != null) {
				HOMESDATA = U.getSectionValue(HOME_HTML, "<strong>Home Type:"	, "</table>") + HOMESDATA;
				}
			}

			// TYPES
			String script = U.getSectionValue(html,"<script type=\"text/javascript\">", "</script>");
			html = html.replace(script, "");
			html = U.removeComments(html);
			// U.log(html);
			String script1 = U.getSectionValue(FEATURES,"<script type=\"text/javascript\">", "</script>");
			FEATURES = FEATURES.replace(script1, "");
			FEATURES = U.removeComments(FEATURES);
			

			FEATURES = FEATURES.replaceAll("Rancho Sienna|Catalina Ranch|Coming Soon!<br/>", "");
			html = html.replaceAll("gated section|Rancho Sienna|Catalina Ranch|Coming Soon!", "").replace("such as golf, tennis,", "such as golf course, tennis,");
			HOMES = U.removeComments(HOMES);
			HOMES = HOMES.replaceAll("Rancho Sienna|Catalina Ranch", "");
			html=html.replace("NOW SELLING IN NEW SECTIONS", "NOW SELLING NEW SECTIONS");
			String commType = U.getCommType(html + FEATURES);
			String pType = U.getPropType(html + HOMES + FEATURES+HOMESDATA);
			html = html.replace("Ranch</span></a></li>", "");
			String dPType = U.getdCommType((html + HOMES + FEATURES+name).replace("Ranch</span></a></li>", "").replace("first floor"," 1 Story ").replace("second floors"," 2 Story "));
			
			html = html.replace("New Phase Coming Fall, 2017", "New Phase Coming Fall 2017");
			String Pstatus = U.getPropStatus((html )
					.replaceAll("or 'Quick Delivery Homes' and|Quick Delivery Homes' and/or 'Models| Quick Delivery Homes<br/>|coming soon", ""));
			//--------status from homes pages------------
			if(HOMES.contains("groupHd qdHd\">Quick Delivery</h5>")){
				if(Pstatus.length()<4){
					Pstatus = "Quick Delivery Homes";
				}
				else{
					Pstatus = Pstatus +", Quick Delivery Homes";
				}
			}
			if(add[0].trim().length()==0)add[0]=ALLOW_BLANK;
			add[0]=add[0].replaceAll("Coming Soon!|Now Selling!|By Appointment Only", ALLOW_BLANK);
			if(add.length<3 ||add[0].contains(ALLOW_BLANK)){
			add = U.getAddressGoogleApi(latlng);
			geo = "true";
			}

			if (this.data.communityUrlExists(url)){
				LOGGER.AddCommunityUrl(url+"---------------------->Repeated");
				return;
			}
			U.log("Property status:::"+Pstatus);
				
			LOGGER.AddCommunityUrl(url);
			data.addCommunity(name, url, commType);
			data.addLatitudeLongitude(latlng[0], latlng[1], geo);
			data.addPrice(Prices[0], Prices[1]);
			data.addAddress(add[0], add[1], add[2].trim(), add[3].trim());
			data.addSquareFeet(SqFt[0], SqFt[1]);
			data.addPropertyType(pType, dPType);
			data.addPropertyStatus(Pstatus);
			data.addNotes(U.getnote(html));
		}
		j++;
	}

	public void addType2(String url, String name, String price, String sqft,String LLsec, String region) throws Exception {
		if(name.contains("Cibolo Canyons"))url = "http://rohomestx.com/communities/san-antonio/cibolo-canyons/";//for Cibolo Canyons communtiy
		
		if(!url.contains("http://www.centerratx.com/communities/profile.asp?cid=1814"))return;
		{
			counter++;
			//U.log(counter);
			//U.log(url);
			U.log("name::::::::::"+name);
			String commUrl = url;
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = ALLOW_BLANK;
			// U.log(LLsec);
			latlng[0] = Util.match(LLsec, "\\d{2,}.\\d{3,}");
			if (latlng[0] != null)
				LLsec = LLsec.replace(latlng[0], "");
			latlng[1] = Util.match(LLsec, "-\\d{2,}.\\d{3,}");

			String html = U.getHTML(url);
			html = U.removeComments(html);
			//U.log(html);
			//String script = U.getSectionValue(html,
				//	"<script type=\"text/javascript\">", "</script>");
			//html = html.replace(script, "");
			html = U.removeComments(html);
			// U.log(html);
			String URLS = U.getSectionValue(html, "content-box-small", "</ul>");
			if (URLS == null) {
				String loc_url = U.getSectionValue(html, url, "\"");
				url = url + loc_url;
				html = U.getHTML(url);
				URLS = U.getSectionValue(html, "content-box-small", "</ul>");
			}
			//U.log("Community Url: " + url);
			String tempUrl = url;
			String FEATURES = "";
			String fUrl="";
			try {
				if (region.contains("Austin")) {
					if (tempUrl.contains("projects")) {
						tempUrl = tempUrl.replace("projects",
								"communities/austin");
					}
					//
				} else if (region.contains("San-Antonio")) {
					if (tempUrl.contains("projects")) {
						tempUrl = tempUrl.replace("projects",
								"communities/san-antonio");
					}
				}
				
				fUrl= tempUrl + "/standard-features/";
				U.log(fUrl.replace("//standard-features/", "/standard-features/"));
				FEATURES = U.getHTML(fUrl.replace("//standard-features/", "/standard-features/"));

			} catch (Exception e) {
 
			}

			if (FEATURES == null) {
				url = url.replace("san-antonio", "communities/san-antonio");
				 fUrl=url + "/standard-features/";
				FEATURES = U.getHTML(fUrl.replace("//standard-features/", "/standard-features/"));
				U.log("furl:::::"+fUrl);
				U.log("File Not Found");
			}

			U.log("$$$$$$$$$$$$" +fUrl.replace("//standard-features/", "/standard-features/"));
			
			String script1 = U.getSectionValue(FEATURES,
					"-text/javascript\">", "</script>");
			//FEATURES = FEATURES.replace(script1, "");
			FEATURES = U.removeComments(FEATURES);

			String[] LINKS = U.getValues(URLS, "href=\"", "\"");
			String HOMES = ALLOW_BLANK;
			String AMENITIES = ALLOW_BLANK;
			for (String home : LINKS) {
				U.log("************************** 1");
				if (home.contains("amenities")) {
					U.log("amen" + home);
					AMENITIES = U.getHTML(home);
				}
				if (home.contains("available-homes")
						|| home.contains("our-homes")) {

					home = U.getHTML(home);
					if (home != null) {
						HOMES = HOMES + home;
					}
				}
			}
			String[] HOMES_VAL = U.getValues(HOMES, "<h5>", "More Detail");

			String HOMESDATA = ALLOW_BLANK;
			for (String loc : HOMES_VAL) {
				//U.log("************************** 2");
				loc = U.getSectionValue(loc, "href=\"", "\"");
				U.log("::::::::::::::::::::::::"+loc);
				loc = U.getHTML(loc);
				if (loc != null) {
					HOMESDATA = HOMESDATA + loc;
				}
			}

			String commName = U.getSectionValue(html, "<title>", "|").trim();
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			add = U.getAddressGoogleApi(latlng);
			geo = "TRUE";

			// PRICES SQFt

			String[] Prices = U.getPrices(price + html + HOMESDATA + HOMES,
					"\\$\\d{3},\\d+", 0);
			if (Prices[1] == null)
				Prices[1] = ALLOW_BLANK;

			String[] SqFt = U.getSqareFeet(sqft + html + HOMESDATA + HOMES,
					"\\d,\\d+ Sq Ft|\\d,\\d+ square feet|over \\d{4} square feet", 0);
			if (SqFt[1] == null)
				SqFt[1] = ALLOW_BLANK;

			// TYPES
			html = html.replaceAll(
					"Rancho Sienna|Catalina Ranch|elongated|irrigated", "").replace(" Golf and tennis clubs", " Golf course and tennis clubs");
			HOMESDATA = HOMESDATA.replaceAll(
					"Rancho Sienna|Catalina Ranch|elongated|irrigated", "");
			HOMES = HOMES.replaceAll(
					"Rancho Sienna|Catalina Ranch|elongated|irrigated", "");

			FEATURES = FEATURES.replaceAll(
					"Rancho Sienna|Catalina Ranch|elongated|irrigated", "");
			AMENITIES = AMENITIES.replaceAll(
					"Rancho Sienna|Catalina Ranch|elongated|irrigated", "");

			String commType = U.getCommType(html + FEATURES + AMENITIES);
			String pType = U.getPropType(html + AMENITIES + FEATURES+ HOMESDATA);
			String dPType = U.getdCommType((html + AMENITIES + FEATURES
					+ HOMESDATA + HOMES).replace("first floor"," 1 Story ").replace("second floors"," 2 Story "));
//			+ AMENITIES.replaceAll("Highland Village, Phase I � Coming Soon| — Coming Soon!<br/>| � Coming Soon|Coming Soon!<br />","") + FEATURES
			html = html.replaceAll("Phase I � Coming Soon|Quick Delivery Homes<br/>|Quick Delivery Homes' and/or 'Models|coming soon", "");
			String Pstatus = U.getPropStatus(html);

		//	pType=pType.replace("Traditional Homes,", "");
			LOGGER.AddCommunityUrl(commUrl);
			data.addCommunity(commName, commUrl, commType);
			data.addLatitudeLongitude(latlng[0], latlng[1], geo);
			data.addPrice(Prices[0], Prices[1]);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addSquareFeet(SqFt[0], SqFt[1]);
			data.addPropertyType(pType, dPType);
			data.addPropertyStatus(Pstatus);
			data.addNotes(U.getnote(html));
		}
		k++;
	}
}
