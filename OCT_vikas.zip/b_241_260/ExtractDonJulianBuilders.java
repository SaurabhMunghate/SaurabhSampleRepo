/**
 * @author Upendra Singh 
 * @date 21/01/2017
 * 
 */
package com.shatam.b_241_260;

import java.util.HashMap;

import org.apache.commons.lang3.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDonJulianBuilders extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	public ExtractDonJulianBuilders()
			throws Exception {
		super("Don Julian Builders","https://www.donjulianbuilders.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Don Julian Builders");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractDonJulianBuilders();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Don Julian Builders.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	HashMap<String, String> latList=new HashMap<>();
	WebDriver driver=null;
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		String mainHtml=U.getHtml("http://www.donjulianbuilders.com/communities",driver);
		U.log(U.getCache("http://www.donjulianbuilders.com/communities"));

		
		
		
		String json = U.getSectionValue(mainHtml, "window.__PRELOADED_STATE__ = ", "</script>");
		JsonParser parser = new JsonParser();
		JsonObject jobject = (JsonObject)parser.parse(json);
		JsonArray communities = jobject.get("cloudData").getAsJsonObject().get("communities").getAsJsonObject().get("5702bb7cf410954eb27cfa3f").getAsJsonObject().get("data").getAsJsonArray();
		U.log("Total Communities :: "+communities.size());
		for(JsonElement ele: communities) {
			JsonObject comm = (JsonObject)ele;
			
//			U.log("=================="+comm.get("area").getAsString().toLowerCase().replace(",", "").replace(" ", "-")+"/"+comm.get("sharedName").getAsString());
			String comUrl =null;
//			String area=comm.get("area").getAsString();
			String area1=comm.toString();
			if(!area1.contains("\"area\":\""))
			{
				comUrl= "https://www.donjulianbuilders.com/communities/undefined"+"/"+comm.get("sharedName").getAsString();

			}
			else {
				comUrl= "https://www.donjulianbuilders.com/communities/"+comm.get("area").getAsString().toLowerCase().replace(",", "").replace(" ", "-")+"/"+comm.get("sharedName").getAsString();

			}
//			U.log("comUrl==="+comUrl);
//			if(!comUrl.contains("null"))
						addDetails(comUrl, comm+"");
		}
		
//		driver.quit();
			LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comData) throws Exception {
		// TODO Auto-generated method stub
//	if(!comUrl.contains("https://www.donjulianbuilders.com/communities/overland-park-ks/terrybrook-farms-the-estates"))return;
		
//	try{
//		if(j>=9 && j<=13)
	{
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"::::::::Repeat::::::");
			k++;
			return;
		}
		
//		if(comUrl.contains("https://www.donjulianbuilders.com/communities/olathe-ks/cedar-creek")) {
//			LOGGER.AddCommunityUrl(comUrl+ "--------------------------- new builder");
//			return;
//		}
//		if(comUrl.contains("")) {
//			LOGGER.AddCommunityUrl(comUrl+ "--------------------------- new builder");
//			return;
//		}
		
		if(comUrl.contains("null"))return;

		
		LOGGER.AddCommunityUrl(comUrl);
		U.log("\n===============================================\n");
		U.log(j+"   commUrl-->"+comUrl);
		U.log(U.getCache(comUrl));
//		U.log(">>>>>>>"+comData);
		String html=U.getHtml(comUrl, driver);
		U.log(U.getCache(comUrl));
		html=U.removeSectionValue(html, "window.__PRELOADED_STATE__", "</script>");
		
		
		//============================================Community name=======================================================================
				String communityName=U.getSectionValue(comData, "\"com_name\":\"","\"");
		if(communityName==null)communityName=U.getSectionValue(comData, "name\":\"","\",");
		if(communityName!=null)communityName=communityName.replace("&#8217;","");
				U.log("community Name---->"+communityName);
				
//	=============================================================================================	
		
		
		String floorplan=ALLOW_BLANK;
		String plan_data=null;
		String communityMap=ALLOW_BLANK;
		String availableHome=ALLOW_BLANK;
		String comm_detailHTML=ALLOW_BLANK;
		String home_data=null;
		String mapHtml=ALLOW_BLANK;
		String mapLink=null;
		String community_info=ALLOW_BLANK;
		if(html.contains("<a target=\"_blank\" rel=\"noopener noreferrer\"")) {
			String commInfoUrlSec=U.getSectionValue(html, "<a target=\"_blank\" rel=\"noopener noreferrer\"", "btn btn-brand1 btn-arrow-white\"");
			U.log("commInfoUrlSec===="+commInfoUrlSec);
			if(commInfoUrlSec!=null) {
				String commInfoUrl=U.getSectionValue(commInfoUrlSec, "href=\"", "\"");
				U.log("commInfoUrl===="+commInfoUrl);
				
				if(commInfoUrl!=null) {
					commInfoUrl=commInfoUrl.replace("http://", "https://");
					 comm_detailHTML=U.getHTML(commInfoUrl);
					if(comm_detailHTML!=null) {
						String navigation_sec=U.getSectionValue(comm_detailHTML,"<header" , "</header>");
						if(navigation_sec==null) 
								 navigation_sec=U.getSectionValue(comm_detailHTML,"<nav role=\"navigation\"" , "Contact");
//						U.log("navigation_sec===="+navigation_sec);
						if(navigation_sec==null) 
							 navigation_sec=U.getSectionValue(comm_detailHTML,"<nav id=\"site-navigation\"" , "</nav>");
//					
						if(navigation_sec==null) 
							 navigation_sec=U.getSectionValue(comm_detailHTML,"role=\"navigation\"" , "Contact");
						
						
						
						
						if(navigation_sec!=null || commInfoUrl.contains("terrybrookfarms.com")) 
						{
							String[] urls=U.getValues(navigation_sec, "href=\"", "\"");
							
							if(commInfoUrl.contains("terrybrookfarms.com")) {
								String[] terrybrook_urls=U.getValues(comm_detailHTML, "<path d=\"M138.305 10.052v123h-123v-123h123z\"/>", ">Map");
								U.log("terrybrook_urls===="+terrybrook_urls.length);
								for(String  u : terrybrook_urls)
								{
									if(u.contains(communityName.replace("Terrybrook Farms -", "").toUpperCase().trim())) {
										comm_detailHTML=u;
//										U.log("uuuuu==="+u);
										if(u.contains("THE ESTATES</span></span>")) {
											u+="<a data-testid=\"linkElement\" href=\"https://www.terrybrookfarms.com/copy-of-stone-creek-floor-plans\" target=";
										}
										if(u.contains("THE MANOR</span></span>")) {
											u+="<a data-testid=\"linkElement\" href=\"https://www.terrybrookfarms.com/copy-of-maple-ridge-floor-plans-1\" target=";
										}
										if(u.contains("THE MANOR</span></span>")) {
											u+="<a data-testid=\"linkElement\" href=\"https://www.terrybrookfarms.com/copy-of-maple-ridge-floor-plans-1\" target=";
										}
//										U.log("terrybrook_urls==="+u);
										urls=U.getValues(u, "href=\"", "\"");
												
									}
								}
							}
							
							U.log("urls===="+urls.length);
							if(urls.length>0)
							for(String url : urls)
							{
								if(!url.contains("http")) {
									url=commInfoUrl+url;
									url=url.replace("com//", "com/");
								}
								U.log("url===="+url);
								if(url.contains("available") || url.contains("find-your-home/")) {
									U.log("available home===="+url);
									availableHome=U.getHtml(url,driver);
									if(availableHome!=null) {
										String[] homes=U.getValues(availableHome, "<div class=\"section-content relative\">", "<div id=\"");
										if(url.contains("forestridgeestateskc.com/available-homes/"))
											homes=U.getValues(availableHome, "<div class=\"wpl-column\">", "</ul>");
										if(url.contains("staleyfarmshomes"))
											homes=U.getValues(availableHome, "<h5 style=\"margin-bottom:", "<span>View Listing</span>");
										if(url.contains("overlandridge"))
											homes=U.getValues(availableHome, "<div class=\"text-box-content text \">", "<style>");
										if(homes.length==0)
											homes=U.getValues(availableHome, "<div class=\"bfg-photo-count", "<span>More<span> Details");
										U.log(" home===="+homes.length);
										if(homes.length>0) {
											for(String home : homes) {
//												U.log(" home===="+home);
												home_data+=home;
											}
										}
									}
								}
								
								if(url.contains("plat-map")|| url.contains("homesites")|| url.contains("find-your-home/shadow-woods/")) {
//									String mapLinkSec=U.getSectionValue(community_info, "<iframe id=", ">");
//									if(mapLinkSec!=null) {
//										mapLink=U.getSectionValue(mapLinkSec, "src=\"", "\"");
										U.log("mapLink-1===="+url);
										if(url!=null) {
											mapHtml=U.getHtml(url,driver);
											
//										}
									}
								}
								
								if((url.contains("community")|| url.contains("amenities") || url.contains("homeowner-information/")
										|| url.contains("find-your-home/shadow-woods/"))&& !url.contains("map") 
										|| url.contains("/about-villas-of-avalon/")
										|| url.contains("https://lochlloyd.com/real-estate/")) {
									U.log("community info===="+url);
									
									if(url.contains("map") || url.contains("homesite-map") ) {
										U.log("mapLink-2===="+url);
										String mapLinkSec=U.getSectionValue(community_info, "<iframe id=", ">");
										if(mapLinkSec!=null) {
											mapLink=U.getSectionValue(mapLinkSec, "src=\"", "\"");
											U.log("mapLink----===="+mapLink);
											if(mapLink!=null) {
												mapHtml=U.getHtml(mapLink,driver);
											}
										}
										
									}
									else {
										community_info=U.getHtml(url,driver);
									}
								}
								if(url.contains("floor-plan")|| url.contains("models")) {
									U.log("floor-plans===="+url);
									floorplan=U.getHtml(url,driver);
									if(floorplan!=null) {
//										U.log("floorplan===="+floorplan);
										floorplan=floorplan.replace(">Vew Floor Plans<", ">View Floor Plans<");
										String[] plans=U.getValues(floorplan, "<div class=\"plan", "View");
//										U.log(" plans===="+plans.length);
//										if(url.contains("bristolhighlandskc.com/floor-plans"))
										if(plans.length==0)
											plans=U.getValues(floorplan, "<section id=\"floor-plans\">", "</section>");
										
										U.log(" plans===="+plans.length);
										if(plans.length==0)
											plans=U.getValues(floorplan, "<div class=\"card-container", ">View");
										
										if(plans.length==0)
											plans=U.getValues(floorplan, "<span style=\"font-weight:bold;\">", "Images</span>");
										
										
										U.log(" plans===="+plans.length);
										if(plans.length>0) {
											for(String plan : plans) {
												if(commInfoUrl.contains("terrybrookfarms")) {
												if(plan.contains("DON JULIAN BUILDERS"))
												plan_data+=plan;
												}
												else {
													plan_data+=plan;
												}
											}
										}
									}
									
								}
								if(url.contains("map") || url.contains("/homesites")) {
									U.log("mapLink-2===="+url);
									String mapHtml1=U.getHtml(url,driver);
									String mapLinkSec=U.getSectionValue(mapHtml1, "title=\"Embedded Content\" name=\"htmlComp-iframe\" data-src=\"\"", "</iframe>");
									if(mapLinkSec==null)
										mapLinkSec=U.getSectionValue(mapHtml1, "<iframe class=\"pwgt-iframe-xL5s1rWJ\"", "</iframe>");
									if(mapLinkSec==null)
										mapLinkSec=U.getSectionValue(mapHtml1, "<iframe id=\"CHMap\" title=\"Chapel Hill Map\" ", "</iframe>");
									
									if(mapLinkSec!=null) {
										mapLink=U.getSectionValue(mapLinkSec, "src=\"", "\"");
										
										if(mapLink!=null) {
											mapLink=mapLink.replace("&amp;", "&");
											U.log("mapLink-1===="+mapLink);
											mapHtml+=U.getHtml(mapLink,driver);
//											mapHtml+=U.getHTML(mapLink);
										}
									}
//									else {
//										mapHtml=mapHtml1;
//									}
								}
								
								if(url.contains("independent-living/apartment-homes/") || url.contains("independent-living/cottages-villas/")) 
								{
									home_data=U.getHtml(url, driver);
								}
							}
							
							
						}
					}
				}
			}
		}

//		U.log("<<<<<<<<<<<< "+Util.matchAll(mapHtml,"[\\s\\w\\W]{50}<g id[\\s\\w\\W]{30}", 0));

//================================================Address section===================================================================
		
		String note=ALLOW_BLANK;
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
		String geo="FALSE";
//		U.log("<<<<<<<<<<<< "+Util.matchAll(home_data,"[\\s\\w\\W]{50}625,000[\\s\\w\\W]{30}", 0));

		String addSec=U.getSectionValue(html, "<span class=\"DetailOverview_subheading\"", "title=\"Map This Community\"");
//		addSec=U.getNoHtml(addSec);
//		U.log("addSec===="+addSec);
		if(addSec!=null)
		{
			addSec=addSec.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "").replace("&amp;", "&");
			
			String addSec1=U.getSectionValue(addSec, ">", "</span>");
//			U.log("KKKKKKKKKKKK===="+addSec1);
			add=U.getAddress(addSec1);
			String latlngSec=U.getSectionValue(addSec, "/@", "z\"");
//			U.log("LLLLLLLLLLLLL===="+latlngSec);
			if(latlngSec!=null)
			{
				latlngSec=latlngSec.replaceAll(",\\d+","");
				U.log("latlngSec===="+latlngSec);
				latlag=latlngSec.split(",");
			}
		
		}
		

		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		U.log("latlag--->"+latlag[0]+"  "+latlag[1]);
		
		
//--------------------------------------------------latlng----------------------------------------------------------------
		String latSec=latList.get(communityName.toLowerCase().trim());
		
		
		if(latlag[0].length()<3)
		{
//			latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
//			latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
//		}
//		else {
			latlag[0]=U.getSectionValue(comData, "\"com_lat\":", ",");
			latlag[1]=U.getSectionValue(comData, "\"com_lng\":", ",");
		}
		U.log("latlag-1--->"+latlag[0]+"  "+latlag[1]);
		
		
		if(add[0]==null && add[1]==null && add[2]==null && add[3]==null && latlag[0]==null && latlag[1]==null) 
		{
			add[0]=U.getSectionValue(comData, "\"com_street1\":\"","\"");
			add[1]=U.getSectionValue(comData, "\"city_name\":\"","\"");
			add[2]=U.getSectionValue(comData, "\"state_code\":\"","\",");
					if(add[2]!=null)add[2]=add[2].replace(",","");
			add[3]=U.getSectionValue(comData, "\"com_zip\":\"","\"");
			
		}
//		U.log("Address-1---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
//		U.log("latlag-1--->"+latlag[0]+"  "+latlag[1]);
		
		if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
		{
			latlag=U.getlatlongGoogleApi(add);
			if(latlag == null) latlag = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if((add[1]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if((add[1].length()<4|| add[3]==null) && latlag[0]!=ALLOW_BLANK)
		{
			add=U.getAddressGoogleApi(latlag);
			if(add == null) add = U.getAddressHereApi(latlag);
			geo="TRUE";
		}
		if((add[0]==null||add[0].length()<4) && latlag[0]!=ALLOW_BLANK)
		{
			String add1[] = U.getAddressGoogleApi(latlag);
			if(add1 == null) add1 = U.getAddressHereApi(latlag);
			add[0] = add1[0];
			geo="TRUE";
		}
		
		U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
		
		
//============================================Price and SQ.FT======================================================================
		
		String commSec=U.getSectionValue(html, "DetailDescription\" data-reactid=", "</span></p></div></div></div></div></div></div></div></div></div>");

		
		
		String url="";
		if(comUrl.contains("https://www.donjulianbuilders.com/page.php?p=3&com=22"))
		{
			url="https://www.donjulianbuilders.com/staley-farms";
		}
		else url=comUrl;
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
//		String homeHtml=U.getHtml(url+"#homes", driver);
		String homeHtml="";
		String homedata=U.getSectionValue(html, "Available Homes</h3>", "Photo Gallery</h3>");
		if(homedata!=null) {
		String[] homes=U.getValues(homedata, "<div class=\"HomeCard_media\"", "<div class=\"HomeCard_detailButton");
		if(homes.length>0) {
			for(String home_Sec: homes) {
//				U.log("home_Sec====="+home_Sec);
				String home_url="https://www.donjulianbuilders.com"+U.getSectionValue(home_Sec, "<a class=\"\" href=\"", "\" ");
				U.log("home_url=="+home_url);
				String homeHTML=U.getHTML(home_url);
				homeHtml=U.getSectionValue(homeHTML, "Specifications</h3>", "</a></div></div></div></div></div></div></div></div></div")+
						U.getSectionValue(homeHTML, "Description</h3>", "<div class=\"container DetailSection_headingWrapper\"");
				
			}
		}
		}
		
		if(home_data!=null) {
			String[] h=U.getValues(home_data, "href=\"", "\"");
			for(String hdata : h) {
				U.log("hdata=="+hdata);
				if(hdata.equals("#") || !hdata.contains("https") || !hdata.contains(".ico") || !hdata.contains(".png")
						|| !hdata.contains("?ver=") || !hdata.contains("fonts.googleapis.com")
						|| !hdata.contains(".css")|| !hdata.contains("/wp-json/")
						|| !hdata.contains("/pages/") || !hdata.contains(".php")
						|| !hdata.contains(".org/") || !hdata.contains("tel:")
						|| !hdata.contains("/careers/") || !hdata.contains("-development-center/")
						|| !hdata.contains(".pdf") || !hdata.contains("goo.gl")
						|| !hdata.contains("privacy-policy/") || !hdata.contains("goo.gl"))continue;
				U.log("hdata=="+hdata);
				homeHtml+=U.getHtml(hdata, driver);
			}
		}
		
//		U.log("planData======"+plan_data);
		
		
		String rmsec = U.getSectionValue(homeHtml, "<div ng-controller=\"HomesCtrl as homes\"", "<a href=\"/page.php?p=2\" class=\"btn\">Communities</a>");
//		U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+commSec);
		if(rmsec!=null)
		homeHtml =homeHtml.replace(rmsec, "");
		html=html.replaceAll("Price</span><span class=\"HomeCard_priceValue\" data-reactid=\"\\d+\">", "Price: ")
				.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
		comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
//		U.log(mapHtml);
		if(commSec!=null)
		commSec=commSec.replace("starting in the $700’s", "starting in the $700,000");
		community_info=community_info.replace("'s", ",000");
		if(home_data!=null)home_data=home_data.replace("’s", ",000");
		
		if(comm_detailHTML!=null)
			comm_detailHTML=comm_detailHTML
			.replace("Homes priced from the $500's", "Homes priced from the $500,000")
			.replace("Homes priced from the $500&#39;s", "Homes priced from the $500,000")
			.replace("Homes from $600-$1M+</span>", "Homes from $600,000-$1,000,000</span>")
			.replace("Homes from $600-$900K</span>", "Homes from $600,000-$900,000</span>")
			.replace("LUXURY VILLAs from $600-$900K", "LUXURY VILLAs from $600,000-$900,000")
			.replace("LUXURY VILLAs from $600-$1M+", "LUXURY VILLAs from $600,000-$1,000,000")

			.replace("Homes from $900-$2M+</span>", "Homes from $900,000-$2,000,000</span>");
		
//		U.log("comm_detailHTML==="+comm_detailHTML);
		community_info=community_info.replace("starting in the upper $800’s", "starting in the upper $800,000");
		String prices[] = U.getPrices(html+commSec+homeHtml+home_data+plan_data+community_info+comm_detailHTML,
				"\">\\$\\d{2},\\d{3}</span>|>\\$\\d{3},\\d{3}</span>|Walkout \\$\\d{3},\\d{3}</p>|Homes from \\$\\d{3},\\d{3}-\\d{3},\\d{3}|Homes from \\$\\d{3},\\d{3}-\\$\\d,\\d{3},\\d{3}|mid \\d{3},\\d{3}|<p><em>\\$\\d{3},\\d{3}|Mid \\d{3},\\d{3}|High \\d{3},\\d{3}| priced at \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|Price: \\$\\d{3},\\d{3}|the \\$\\d{3},\\d{3}|\"com_priceHigh\":\\d{6,7},|\\$\\d{1},\\d{3},\\d+|range from \\$\\d+,\\d{3} to \\$\\d+,\\d{3}|the\\s*[$]*\\d{3},\\d+|\\$\\d{3},\\d+", 0);
		
		minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		
		U.log("Price--->"+minPrice+" "+maxPrice);
//		U.log("<<<<<<<<<<<< "+Util.matchAll(comm_detailHTML,"[\\s\\w\\W]{50}\\$900[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(homeHtml+home_data,"[\\s\\w\\W]{50}\\$900[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(comm_detailHTML,"[\\s\\w\\W]{50}\\$900[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(comm_detailHTML,"[\\s\\w\\W]{50}\\$500[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(html+commSec+homeHtml+home_data+plan_data+mapHtml+community_info+comm_detailHTML,"[\\s\\w\\W]{50}\\$500[\\s\\w\\W]{30}", 0));

//======================================================Sq.ft===========================================================================================		
		html=html.replaceAll("<span class=\"CardStatsInfo\" data-reactid=\"\\d+\">", "")
				.replaceAll("</span><span class=\"CardStatsLabel\" data-reactid=\"\\d+\">SQ FT", " SQ FT")
				.replaceAll("<img src=\"/images/icon-sqft.svg\" alt=\"\" data-reactid=\"\\d+\">", "sqft");
homeHtml=homeHtml.replaceAll("<div class=\"DetailSection_tableContent\" data-reactid=\"\\d+\">", "")
.replaceAll("</div></div><div class=\"col-\\d+ pl-\\d+\" data-reactid=\"\\d+\">", " ");

if(plan_data!=null) {
	plan_data=plan_data.replaceAll("\\s*</span> SqFt.", " SqFt.");
}
		String[] sqft = U
				.getSqareFeet(
						(html+commSec+homeHtml+community_info+home_data+plan_data+comm_detailHTML+mapHtml).replaceAll("4000 Sq. Ft. Zero-Entry Swimming", ""),
						"perfectly sized at \\d{4} square feet|\\d,\\d{3} square feet|from \\d{3} to \\d,\\d{3} square feet|Living Area</td><td class=\"\">\\d,\\d{3} Ft|\\d{4} SqFt|\\d{4} sq.ft.|\\d,\\d{3} SQ FT</span>|Sq Ft \\d,\\d{3}|sqft</span>\\d,\\d{3}|\\d,\\d{3}–\\d,\\d{3} square feet|\"com_sqftLow\":\\d{4},|\"com_sqftHigh\":\\d{4},|\\d+,\\d+ sq. ft|\\d{5} SF|left\">\\d{4}</td>",
						0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("SQ.FT--->"+minSqft+" "+maxSqft);
//		U.log("<<<<<<<<<<<< "+Util.matchAll(mapHtml,"[\\s\\w\\W]{50}2,409[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(html+community_info,"[\\s\\w\\W]{50}gated[\\s\\w\\W]{30}", 0));

//================================================community type========================================================

		String communityType=U.getCommType((html+community_info).replace("nknown=polyfill&amp;flags=gated", "").replaceAll("Chapel Hill is a beautiful master planned|GatedResidenceCommunity", "").replace("Country Club Drive",""));
		U.log("communityType---->"+communityType);

//==========================================================Property Type================================================
		html = html.replace("garden cottages", "Garden-Style Living cottages")
				.replaceAll("Pool Coming Soon|Clubhouse Coming Soon|Workout Facility Coming Soon", "");
		homeHtml = homeHtml.replace("Custom Design", "Custom homes");
		String comSec= U.getSectionValue(html, "<title>", "</script>");
		
		String proptype=U.getPropType((availableHome+comSec+homeHtml+communityName+home_data+plan_data+community_info+comm_detailHTML).replace("James Engle Custom Homes", "").replace("custom designed to the tastes of a discerning", "Custom homes designed to the tastes of a discerning").replaceAll("carriage style garage|The Villas of Chapel Green",""));
//   		U.log("<<<<<<<<<<<< "+Util.matchAll(availableHome+comSec+homeHtml+communityName+home_data+plan_data+community_info+comm_detailHTML,"[\\s\\w\\W]{50}>Fleetwood Villa</a[\\s\\w\\W]{30}", 0));
//   		U.log("<<<<<<<<<<<< "+Util.matchAll(comSec,"[\\s\\w\\W]{50}- The Manor[\\s\\w\\W]{30}", 0));
		U.log("proptype---->"+proptype);
//==================================================D-Property Type======================================================
		homeHtml = U.removeSectionValue(homeHtml, "<nav class=\"filter-menu hidden\"", "</nav>");
		homeHtml = homeHtml.replace("Two Story", "2 Story").replaceAll("Stories: 1.5 Story", "1.5 Story").replace("Stories: 1.5", "1½-story").replace("Stories: 1.5 story", "1.5 Story");
		html=html.replace("1 ½-story", "1.5 Story");
		comData = comData.replace("Reverse 1.5 Story", "");
		String dtype=U.getdCommType((mapHtml+availableHome+community_info+home_data+plan_data+html+comSec+homeHtml.replaceAll("Two Story<br />|1.5 Story<br />|(f|F)loor|FLOOR","")));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(mapHtml,"[\\s\\w\\W]{50}89,000[\\s\\w\\W]{30}", 0));
		U.log("dtype---->"+dtype);
//==============================================Property Status=========================================================
//		html=html.replace("home sites that are now available","homesites now available");
//		U.log(" plan_data=====\n"+plan_data);
		community_info=community_info.replace("We also have lots available for your very own", "");
		html =  html.replace("thirty-three home sites that are now available", "Thirty Three Home Sites Now Available");
		if(comSec==null) {
			comSec=ALLOW_BLANK;
		}if(community_info==null) {
			community_info=ALLOW_BLANK;
		}if(comm_detailHTML==null) {
			comm_detailHTML=ALLOW_BLANK;
		}
		String pstatus=U.getPropStatus((html+comSec.replaceAll("Coming Soon</li>|home sites that are now available|ulian Community Coming", "")+community_info+comm_detailHTML.replace(">COMING SOON!</p></div><div", "")).replace("class=\"et_pb_slide_content\"><p>COMING SOON", "").replace("Take a look at our lots available", "")
				.replace("LOTS AVAILABLE NOW", "")
				.replace("2>New Home Sites Available Now!<", "")
				.replace("4 is now open", ""));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(html+commSec+community_info+comm_detailHTML,"[\\s\\w\\W]{50} AVAILABLE NOW[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(html+commSec+community_info+comm_detailHTML,"[\\s\\w\\W]{50}now open[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(community_info,"[\\s\\w\\W]{50}thirty three[\\s\\w\\W]{30}", 0));
//		U.log("<<<<<<<<<<<< "+Util.matchAll(comm_detailHTML,"[\\s\\w\\W]{50}thirty three[\\s\\w\\W]{30}", 0));

//============================================note====================================================================
		
		pstatus = pstatus.replace("New Phase, Coming Soon", "New Phase Coming Soon");
		
   	if(comUrl.contains("https://www.donjulianbuilders.com/villas-of-avalon"))minPrice="$600,000";
     
	pstatus=pstatus.replace("Thirty Three Home Sites Now Available, Home Sites Now Available", "Thirty Three Home Sites Now Available")
			.replaceAll("New Phase Coming, New Phase Coming Soon|New Phase Coming Soon, Coming Soon", "New Phase Coming Soon");

		U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		if(comUrl.contains("https://www.donjulianbuilders.com/terrybrook-farms-the-estates"))pstatus="Coming Soon";
		if(comUrl.contains("https://www.donjulianbuilders.com/bristol-highlands") || comUrl.contains("https://www.donjulianbuilders.com/the-woods-at-colton-lake")){
			dtype = removedUnwantedDerivedType(dtype,"1.5 Story");
		}
			if(dtype.length()==0)dtype=ALLOW_BLANK;
			
			
			
//			if( comUrl.contains("/overland-park-ks/villas-of-avalon")
//					|| comUrl.contains("/kansas-city-mo/creekside")
//					|| comUrl.contains("overland-park-ks/wilshire-hills")) 
//			{
//				if(pstatus.length()>4) {
//					pstatus+=", Coming soon";
//					
//				}
//				else
//					pstatus="Coming soon";
//			}
			
//			if(comUrl.contains("https://www.donjulianbuilders.com/communities/kansas-city-mo/creekside"))
//				dtype=dtype.replace("1.5 Story, ", "");

			
//			=======================================================================
			String lotCount=ALLOW_BLANK;
			if(mapHtml!=null) {
				String[] lotData =U.getValues(mapHtml, "<g id=\"mg", "</g>");
				if(lotData.length==0) {
					String lotSec=U.getSectionValue(community_info, "<g id=\"landmarks-active-lots\"", "</g>");
					if(lotSec!=null) {
					lotData =U.getValues(lotSec, "d=\"", ">");
					U.log("lotData.length-4=="+lotData.length);
//					U.log("lotSec=="+lotSec);
					}
					else {
						lotData =U.getValues(mapHtml, "<div class=\"et_pb_module_inner\">", "</div><div");
//						U.log("lotData.length-3=="+lotData.length);
					}
					
				}
				
				if(lotData.length==0) {
					lotData =U.getValues(mapHtml, "<g id=\"mg", "</path>");
//					U.log("lotData.length-2=="+lotData.length);
				}
				
				if(lotData.length==0) {
					lotData =U.getValues(mapHtml, "<g id=\"mg", ">");
//					U.log("lotData.length-1=="+lotData.length);
				}
				
				if(lotData.length==0 && comUrl.contains("https://www.donjulianbuilders.com/communities/lenexa-ks/bristol-highlands")) {
					String m=U.getHtml("https://platwidget.com/splat/?s=954bb72bb8d22d391654c46dd5791670", driver);
					lotData =U.getValues(m, "<g id=\"mg", ">");
					U.log("lotData.length-1=="+lotData.length);
				}
				
				if(lotData.length==0 && comUrl.contains("https://www.donjulianbuilders.com/communities/kansas-city-mo/staley-farms")) {
					lotData =U.getValues(availableHome, "<polygon class=\"imp-shape", "</polygon>");
//					U.log("lotData.length-2=="+lotData.length);
				}
				if(lotData.length==0) {
					lotData =U.getValues(community_info, "<g id=\"mg", ">/g>");
//					U.log("lotData.length-1=="+lotData.length);
				}
				
//				U.log("mapHtml=="+mapHtml);
				U.log("lotData.length=="+lotData.length);
				
				lotCount=Integer.toString(lotData.length);
			}
			
			
			if(lotCount.equals("0")) {
				lotCount=ALLOW_BLANK;
			}
			
			
			
			if(comUrl.contains("https://www.donjulianbuilders.com/communities/shawnee-ks/riverview")) {
				
				
				lotCount ="143";
				
//				U.log("lotData.length-1=="+lotData.length);
			}
			U.log("lotCount=="+lotCount);
			
			

			
//		U.log("<<<<<<<<<<<< "+Util.matchAll(mapHtml,"[\\s\\w\\W]{50}<g id=\"pw-lots[\\s\\w\\W]{30}", 0));

			
			data.addCommunity(communityName,comUrl, communityType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Thirty Three Home Sites Now Available, Now Available", "Thirty Three Home Sites Now Available"));
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
	j++;
//	}catch(Exception e){}
		
	}
	
	private String removedUnwantedDerivedType(String dType, String removedType){
		String list = "";
		for(String val : dType.split(",")){
			if(val.trim().equals(removedType))continue;
			list = (list.length() == 0) ? val : list + ", " + val;
		}
		return list;
	}

}
