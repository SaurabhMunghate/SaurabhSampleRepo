package com.shatam.b_241_260;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLandmark24HomesRealty extends AbstractScrapper {
	public int inr = 0;
	static int j = 0;
	CommunityLogger LOGGER;
	static String BASEURL = "http://www.landmark24.com/ourcommunities/";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractLandmark24HomesRealty();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Landmark 24 Homes & Realty.csv", a
				.data().printAll());

	}

	public ExtractLandmark24HomesRealty() throws Exception {

		super("Landmark 24 Homes & Realty", "http://www.landmark24.com/");
		LOGGER = new CommunityLogger("Landmark 24 Homes & Realty");
	}

	public void innerProcess() throws Exception {
		String baseHtml = U.getHTML(BASEURL);
		String section = U.getSectionValue(baseHtml,
				"LANDMARK 24 NEW HOME COMMUNITIES",
				"<div class=\"calloutContainer \">");
		String values[] = U.getValues(section,
				"<h3 class=\"xCommunityNameHeader\">", "</h3>");

		for (String value : values) {
			String url = U.getSectionValue(value, "<a href=\"", "\"");
			String name = U.getSectionValue(value, "Info\">", "</a>");
			// U.log(url);
			// U.log(name);
			addDetails(url, name);
		}

	}

	public void addDetails(String url, String communityName) throws Exception {
		url = "http://www.landmark24.com" + url;

		String html = U.getHTML(url);
		html=html.replace("5,000 sq ft Club House","");
		U.log(url);
	//if(!url.contains("http://www.landmark24.com/ourcommunities/cumberland-point/"))return;
		html = html.replace("footerAnchor", "");
		html = html.replace("RegisterAnchor", "");
		// -----------latlong-------------//
		String geo = ALLOW_BLANK;
		String latLong[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latLongsec = U.getSectionValue(html, "  data-center-latitude=",
				" data-zoom-level=\"7\"");
		if (latLongsec != null) {

			latLong[0] = Util.match(latLongsec, "\\d{2}.\\d+");
			latLong[1] = Util.match(latLongsec, "-\\d{2}.\\d+");
			U.log("latlong" + latLong[0]);
			U.log("latlong" + latLong[1]);
			geo = "FALSE";
		}

		// ------------adress-----------//
		
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		String ad = U.getSectionValue(html,
				" class=\"gaBDXClickTracking bdxApiLogEventInformation \">",
				"</a>");

		ad = ad.replace(" <span class=\"addressStreet\">", "");

		ad = ad.replace("</span>", "");
		ad = ad.replace(",", "");
		U.log(ad);
		if (ad != null) {
			String a[] = ad.split("<span class=\"addressCity\">");
			add[0] = a[0].trim();
			String adr[] = a[1].split("<span class=\"addressState\">");
			add[1] = adr[0].trim();
			String array[] = adr[1].trim().split(
					"<span class=\"addressZipCode\">");
			add[2] = array[0].trim().toUpperCase();
			add[3] = array[1].trim();
			
		}

		if (add[0].length() == 0) {
			String addr[] = U.getAddressGoogleApi(latLong);
			add[0] = addr[0];
			geo = "TRUE";
		
		}
		
		
		// U.log("add[0]" + add[0] + " add[1] " + add[1] + " add[2] " + add[2]
		// + " add[3] " + add[3]);
		html=html.replace("NEW PHASE, NOW OPEN ", "NEW PHASE NOW OPEN ");
		
		html = html.replaceAll	("marketingDescription\">\\s+Traditional", "Traditional Homes");
		// ---------community type,property type,property status,derived,
		// property type---------//
		html=html.replace("MOVE IN NOW","");
		String commType = U.getCommunityType(html);
		String propType = U.getPropType(html);
		String dpType = U.getdCommType(html);
		String commStatus = U.getPropStatus(html);
		
/*		if(html.contains("homeListings xCommunityHomesWrappercustom_available_now_homes")){
			if (commStatus.length()<3) {
				commStatus = "Homes Available Now";
			}
			else{
				commStatus = commStatus + ",Homes Available Now";
			}
		}
*/		
		// --prices---//
		String[] price = U.getPrices(html,
				"\\$\\d+,\\d+|Priced at \\$\\d+,\\d+ ", 0);
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// -----------sqreft-----------//
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U
				.getSqareFeet(
						html,
						"\\d+,\\d+ sq.ft|\\d+,\\d+ Square|\\d+,\\d+ - \\d+,\\d+ Square Feet ",
						0);

		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];

		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		// ---notes-----//

		data.addCommunity(communityName, url, commType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLong[0].trim(), latLong[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dpType);
		data.addPropertyStatus(commStatus);
		data.addNotes(U.getnote(html));

	}

}