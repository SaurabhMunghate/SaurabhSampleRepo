/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.collections.map.MultiValueMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractIveyHomes extends AbstractScrapper{

	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;
	private static String builderUrl = "https://www.iveyhomes.com";
	
	MultiValueMap plansData = new MultiValueMap();
	MultiValueMap homesData = new MultiValueMap();
	HashMap<String, String> commDatas = new HashMap<String,String>();
	
	
	public ExtractIveyHomes() throws Exception {
		super("Ivey Homes",builderUrl);
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("Ivey Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractIveyHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Ivey Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k); 

	}


	
	WebDriver driver= null;
	@Override
	protected void innerProcess() throws Exception {
		
//		U.setUpGeckoPath();
//		driver  = new FirefoxDriver();
		String mainHtml=U.getHtml("https://www.iveyhomes.com/communities",driver);
		
		
		JsonParser jparser = new JsonParser();
		String removeScript = U.getSectionValue(mainHtml, "__PRELOADED_STATE__ = ", "</script>");
		if (removeScript == null)
			removeScript = "";
		JsonObject jobj = (JsonObject) jparser.parse(removeScript).getAsJsonObject().get("cloudData");
		String redirecrSec=U.getSectionValue(removeScript, "\"redirects\":", "]");
		JsonObject commJson = (JsonObject) jobj.getAsJsonObject().get("communities");
		JsonObject planJson = (JsonObject) jobj.getAsJsonObject().get("plans");
		JsonObject homeJson = (JsonObject) jobj.getAsJsonObject().get("homes");
		JsonArray planHomes = new JsonArray();
		JsonArray homeHomes = new JsonArray();
		
		
		//plans Data
		for(Entry<String, JsonElement> entry : planJson.entrySet()) {
			if(entry.getKey().contains("recent")) continue;
			U.log(entry.getKey());
			JsonArray _planHomes = entry.getValue().getAsJsonObject().get("data").getAsJsonArray();
			U.log("Found Homes :"+_planHomes.size());
			if(_planHomes.size() > 0) {
				planHomes.addAll(_planHomes);
				break;
			}
		}

		
		//homes Data
				for(Entry<String, JsonElement> entry : homeJson.entrySet()) {
					if(entry.getKey().contains("recent")) continue;
					U.log(entry.getKey());
					JsonArray _homeHomes = entry.getValue().getAsJsonObject().get("data").getAsJsonArray();
					U.log("Found Homes :"+_homeHomes.size());
					if(_homeHomes.size() > 0) {
						homeHomes.addAll(_homeHomes);
						break;
					}
				}
		U.log("Homes plan :"+planHomes.size());
		U.log("Homes home :"+homeHomes.size());
		
		int i=0;
		String comSection[] = U.getValues(
				U.removeSectionValue(commJson.toString(), "\"unpublished\":[", "receivedAt\":"),
				"{\"@type\":\"GatedResidenceCommunity\"", "\"type\":\"community\"}");

		for (String comSec : comSection) {
			commDatas.put(U.getSectionValue(comSec, "\"sharedName\":\"", "\","), comSec);
		}
	
		
		String[] comSec=U.getValues(mainHtml, "<div class=\"CommunityCard_wrapper\"","class=\"CommunityCard_detailButton\"");
		U.log(comSec.length);
		for(String comData:comSec)
		{	
			String comUrl=builderUrl+U.getSectionValue(comData, " href=\"","\"");
			addDetails(comUrl,comData, planHomes, homeHomes);
			
		}
		
		LOGGER.DisposeLogger();
//		driver.quit();
	}

	private void addDetails(String comUrl, String comData, JsonArray planHomes, JsonArray homeHomes) throws Exception {
		// TODO Auto-generated method stub
//		if(!comUrl.contains("https://www.iveyhomes.com/communities/grovetown-ga/sinclair-at-crawford-creek"))return;
		
//		try 
//		if(j>4)
		{
		U.log("::::::::::::::::"+j+"\ncommUrl-->"+comUrl);
		
		if(data.communityUrlExists(comUrl))
		{
			LOGGER.AddCommunityUrl(comUrl+"*************Repeated*************");
			k++;
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		String html=U.getHtml(comUrl, driver);
	
		//============================================Community name=======================================================================
				String communityName=U.getSectionValue(comData, "-->","<!--").replace("&#8217;","");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				String note=ALLOW_BLANK;
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				
				String addSec=U.getSectionValue(html,"<span class=\"DetailOverview_subheading","alt=\"Map Google Pin\"");
				
				if(addSec!=null)
				{	
					String addSec2=U.getSectionValue(addSec, "\">", "</span>");
					if(addSec2!=null) {
						add=U.getAddress(addSec2);
						U.log(Arrays.toString(add));
					}
					
					
					String latSec=U.getSectionValue(addSec, "https://www.google.com/maps/place/", "/@");
					if(latSec!=null) {
						String add1[]=latSec.split(",");
							latlag[0]=add1[0];
							latlag[1]=add1[1];
							U.log(Arrays.toString(latlag));

					}					
				}
				
				if(comUrl.contains("https://www.iveyhomes.com/brighton"))
					addSec = U.getSectionValue(html, "Our Model Home is now open! Visit us at", ".&nbsp;");
				
				if(addSec!=null)
				{
					String add1[]=addSec.split(",");

					//U.log(Arrays.toString(add1));
					
					if(add1.length==3)
					{
						add = U.getAddress(addSec);
					}
				}
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		//--------------------------------------------------latlng----------------------------------------------------------------
				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
					geo="TRUE";
					U.log("yes1");
				}
				if((add[0].length()<4 || add[3]==null) && latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressGoogleApi(latlag);
					geo="TRUE";
					U.log("yes2");
				}
				if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK)
				{
					U.log("yes3");
					String[] add1=U.getAddressGoogleApi(latlag);
					if(add1 == null) add1 = U.getAddressHereApi(latlag);
					
					add[3]=add1[3];
					add1 = null;
					geo="TRUE";
					U.log("yes4");
				}
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				
					
		//============================================Price and SQ.FT======================================================================
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k|0’s","0,000").replace("$1 million","$1,000,000");
				
				comData=comData.replaceAll("0&#8217;s|0�s|0's","0,000");
//				U.log(Util.matchAll(html+comData+homeHtml+floorHtml, "[\\w\\s\\W]{50}quick[\\w\\s\\W]{50}",0));
				String prices[] = U.getPrices(comData+html,"\">\\$\\d{3},\\d{3}</span>|-->\\$\\d{3},\\d{3}<|--> - \\$\\d{3},\\d{3}<", 0);
				
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
				String[] sqft = U
						.getSqareFeet(
								html+comData,
								"\\d+,\\d+ Sq. Ft.|\\d+,\\d+ sq. ft|\\d+,\\d+ Sq.Ft.",
								0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
//				
//				String planSectionData=ALLOW_BLANK;
//				String homeSectionData=ALLOW_BLANK;
//				String[] homeSectionArray=U.getValues(html, "class=\"css-1guwbhh\"", "class=\"HomeCard_detailButton\"");
//				String[] planSectionArray=U.getValues(html, "class=\"css-1h1ykp8\"", "class=\"HomeCard_detailButton\"");
//				for(String homeS:homeSectionArray) {
//					String homeUrl=U.getSectionValue(homeS, "", "");
//				}
				//================ Homes Data
				int homesCount = 0; 
				String homesInfo = ALLOW_BLANK;
				for(JsonElement js:planHomes) {
					if(js.toString().contains(communityName)) {
						homesInfo+=js;
						homesCount++;
					}
				}				
				U.log("homesCount: "+homesCount);
				if(communityName.contains("Sinclair at")) {
					communityName="Sinclair";
				}

				U.log(communityName);
				//================ Plans Data
				int plansCount = 0; 
				String plansInfo = ALLOW_BLANK;
				int oneHome=0;		
				int planCount = 0; 
				String planInfo = ALLOW_BLANK;
				for(JsonElement js:planHomes) {
					if(js.toString().contains(communityName)) {
						planInfo+=js;
						planCount++;
					}
				}				
				U.log("planCount: "+planCount);
				
				if(communityName.contains("Sinclair")) {
					communityName="Sinclair At Crawford Creek";
				}
				
		//=============== Available Home ===================
				String combinedFloorlHtml = ALLOW_BLANK;
				int qCount=0;
				String [] floorUrls = U.getValues(html, "class=\"css-1guwbhh\"", "class=\"HomeCard_detailButton\"");
				for(String floorUrl : floorUrls){
					String innerSection=U.getSectionValue(floorUrl, "-->Status<!--", "</span>");
					if(innerSection.contains("Active")) {
						qCount++;
					}
				}
				U.log("Quick Count Status :: "+qCount);
				
				String removeScript = U.getSectionValue(html, "__PRELOADED_STATE__ = ", "</script>");
				if (removeScript != null)
					html =html.replace(removeScript, "");
				
		//================================================community type========================================================
				html=html.replaceAll("Master Plan</a>|/master-plan-map","");
				String communityType=U.getCommType(U.getNoHtml(html)+planInfo+homesInfo);
				
		//==========================================================Property Type================================================
				html = html.replaceAll("Village|Windsor Townhomes", "").replaceAll("southern traditional", "traditional homes").replace("href=\"/homes\">Quick Move-In Homes</a>", "");
//				U.log("+++++++++++"+Util.matchAll(html+comData+combinedFloorlHtml+combinedAvailHtml, "[\\w\\s\\W]{50}luxury[\\w\\s\\W]{50}", 0));

				String proptype=U.getPropType((U.getNoHtml(html)+planInfo+homesInfo)
						.replaceAll("Single|single|SINGLE", "")
						.replace("comfort, convenience, and luxury with very low maintenance.", "comfort, convenience, and luxury country living with very low maintenance.")
						.replace("luxurious Owner", ""));
				U.log("proptype===="+proptype);
		//==================================================D-Property Type======================================================
				String dtype=U.getdCommType(U.getNoHtml(html)+planInfo+homesInfo);
				U.log("dtype===="+dtype);
				
				
				String html1=U.getSectionValue(html, "<span class=\"DetailOverview_subheading", "\">Quick Move-In Homes</h3>");
		//==============================================Property Status=========================================================
				html=html.replaceAll("Community Closeout|Community Closeout Incentive", "").replace(" Premium Home sites are available", "Premium Home sites available").replaceAll("Current Close-Out Incentives Available:|playground coming in 2019|Pool Now Open|Self-Guided Tours Now Available", "");
				String pstatus=U.getPropStatus(html1);
				U.log("pstatus===="+pstatus);
			if (qCount>0) {
					if (pstatus.length()>2) {
						pstatus+=", Quick Move-in Home";
					}else {
						pstatus="Quick Move-in Home";
					}
				}
				
				communityName=communityName.replace("Eagle Eye Single Family","Eagle Eye");
	
//					if(comUrl.contains("/tillery-park"))pstatus=pstatus+", Coming Soon";
				//============================================note====================================================================
					
					
//					===========================================================================
//					U.log(Util.matchAll(html, "[\\w\\s\\W]{30}Neighborhood Layout[\\w\\s\\W]{30}", 0));
					String lotCount=ALLOW_BLANK;
					String mapHtml=ALLOW_BLANK;
						String mapLinkSec=U.getSectionValue(html, "Neighborhood Layout", "</li>");
						U.log("mapLinkSec=="+mapLinkSec);
						if(comUrl.contains("crawford-creek")) {
							mapLinkSec=U.getSectionValue(html, "Neighborhood Layout<img", "</li></ul>");
						}
						U.log("mapLinkSec-2=="+mapLinkSec);
						if(mapLinkSec!=null) {
						String[] mapLinks=U.getValues(mapLinkSec, "<a href=\"", "\"");
						U.log("mapLinkSec-2=="+mapLinks.length);
						for(String mapLink : mapLinks) {
							U.log("mapLink=="+mapLink);
						if(!mapLink.contains("https:")) 
							mapLink="https://www.iveyhomes.com"+mapLink;
						
						if(mapLink!=null) {
							
//							if(mapLink.equals("https://www.iveyhomes.com"))return;
							
							mapHtml+=U.getHtml(mapLink, driver);
						
					}
						}
//						String lotDataSec=U.getSectionValue(mapHtml, "<div class=\"im_map_container\"", "<script");
						String [] lotData=U.getValues(mapHtml, "<div class=\"im_point\"", "</div>");
						U.log("lotData=="+lotData.length);
						if(lotData.length>0) {
							lotCount=Integer.toString(lotData.length);
						}
						else
							lotCount=ALLOW_BLANK;
						
						}
						U.log("lotCount=="+lotCount);
					
					
					
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addUnitCount(lotCount);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
					
		}
		j++;
//					catch(Exception e){}
	}
}