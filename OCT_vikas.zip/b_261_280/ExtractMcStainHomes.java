/**
 * @author Upendra Singh 
 * @date 23/01/2017
 * 
 */
package com.shatam.b_261_280;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMcStainHomes extends AbstractScrapper{
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;

	public ExtractMcStainHomes()
			throws Exception {
		super("McStain Homes","www.mcstain.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("McStain Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {


		AbstractScrapper a = new ExtractMcStainHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McStain Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k); 
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		addDetails("https://www.mcstain.com/our-neighborhoods/indian-peaks-south/");
		addDetails("https://www.mcstain.com/our-neighborhoods/harvest-ridge/");
		
	}

	private void addDetails(String comUrl) throws Exception {
		// TODO Auto-generated method stub
		//if(!comUrl.contains("https://www.mcstain.com/our-neighborhoods/indian-peaks-south/"))return;
		
		
				U.log(j+"   commUrl-->"+comUrl);
						String html=U.getHTMLwithProxy(comUrl);
					
						/*String rem=U.getSectionValue(html, "<head>","class=\"dropdown-menu\">");
						html=html.replace(rem,"");*/
				//============================================Community name=======================================================================
						String communityName=U.getSectionValue(html, "<h1 class=\"ips-title\">","</h1>");
						if(communityName==null)
						{
							communityName=U.getSectionValue(html, "<h1>","</h1>");
							communityName=communityName.replace("<h1>","");
						}
						U.log("community Name---->"+communityName);
						
				//================================================Address section===================================================================
						
						String note="";
						String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
						String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
						String geo="FALSE";
					
						String addSec=U.getSectionValue(html, "LOCATION &amp; HOURS","View Map");
						U.log(addSec);
						if(addSec!=null)
						{
							addSec=U.getNoHtml(addSec);
							addSec=addSec.replace("Indian Peak South is located in Lafayette, Colorado","");
							U.log("gggg"+addSec);
							if(addSec.contains("Road"))
							{
								addSec=addSec.replace("<br />"," ");
							}
							add=U.findAddress(addSec);

						}
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
						
						if(comUrl.contains("https://www.mcstain.com/our-neighborhoods/harvest-ridge/"))
						{
						add[0]="7100 N. Broadway";
						add[1]="Denver";
						add[2]="CO";
						add[3]="80221";
						note="Address Taken From Contact";
						}
				//--------------------------------------------------latlng----------------------------------------------------------------
						String latSec=U.getSectionValue(html, "https://www.google.com/maps/embed","\"");//please cheak latlong present or not in page
						
						if(latSec!=null)
						{
							latSec=U.getSectionValue(latSec, "!2d","!3m");
							String[] lat1=latSec.split("!3d");
							latlag[0]=lat1[1];
							latlag[1]=lat1[0];
						}
						U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
						
						if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
						{
							latlag=U.getlatlongGoogleApi(add);
							
							geo="TRUE";
						}
						if((add[0]==ALLOW_BLANK || add[3]==null) && latlag[0]!=ALLOW_BLANK)
						{
							add=U.getAddressGoogleApi(latlag);
							geo="TRUE";
						}
						
						U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
						
				//============================================Price and SQ.FT======================================================================
						String classicHtml="";
						String traditionalHtml="";
						String bungalowHtml="";
					if(comUrl.contains("https://www.mcstain.com/our-neighborhoods/indian-peaks-south/"))
					{
						/*classicHtml=U.getHTML("https://www.mcstain.com/2845-twin-lakes-circle/");
						traditionalHtml=U.getHTML("https://www.mcstain.com/2841-twin-lakes-circle/");
						bungalowHtml=U.getHTML("https://www.mcstain.com/2863-cascade-creek-drive/");*/
					}
						
						String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
						String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
						
						html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
						
						String prices[] = U.getPrices(html+classicHtml+traditionalHtml+bungalowHtml,"from: \\$\\d+,\\d+| >\\$\\d{3},\\d{3}", 0);
						
						minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
						maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
						
						U.log("Price--->"+minPrice+" "+maxPrice);
						
				//======================================================Sq.ft===========================================================================================		
						String[] sqft = U
								.getSqareFeet(
										html+classicHtml+bungalowHtml+traditionalHtml,
										"\\d+,\\d+ finished",
										0);
						minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
						maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
						U.log("SQ.FT--->"+minSqft+" "+maxSqft);
						
				//================================================community type========================================================
			
						String communityType=U.getCommType(html);
						
				//==========================================================Property Type================================================
						
						String proptype=U.getPropType(html);
						
				//==================================================D-Property Type======================================================
						
						String dtype=U.getdCommType(html+traditionalHtml+classicHtml+bungalowHtml);
						
				//==============================================Property Status=========================================================
						html=html.replace("Coming Soon<","");
						String pstatus=U.getPropStatus(html);
						
				//============================================note====================================================================
						
						
						
						
						if(data.communityUrlExists(comUrl))
							{
							LOGGER.AddCommunityUrl(comUrl);
							k++;
							return;
							}
						
						U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
							data.addCommunity(communityName,comUrl, communityType);
							data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
							data.addPrice(minPrice, maxPrice);
							data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
							data.addSquareFeet(minSqft, maxSqft);
							data.addPropertyType(proptype, dtype);
							data.addPropertyStatus(pstatus);
							data.addNotes(note); 
							j++;
	}

}
