
package com.shatam.b_261_280;

import java.io.IOException;
//import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWathenCastanosHybridHomes extends AbstractScrapper {
	int i = 0;
	static int j = 0;
	String latlng[];
	static CommunityLogger LOGGER;
	WebDriver driver= null;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractWathenCastanosHybridHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Wathen Castanos Hybrid Homes.csv", a.data().printAll());
	}

	public ExtractWathenCastanosHybridHomes() throws Exception {

		super("Wathen Castanos Hybrid Homes", "https://www.wchomes.com/");
		LOGGER = new CommunityLogger("Wathen Castanos Hybrid Homes");

	}

	// ------for fetching move in ready homes data----------------
	public String callQuick(String key) throws IOException {
		key = key.trim();
		String data = "";
		key = key.replace("Creekstone", "Creekstone at The Village");
		String html = U.getHTML("https://www.wchomes.com/quick-move-in/");
		U.log(U.getCache("https://www.wchomes.com/quick-move-in/"));
		String[] add1 = U.getValues(html, "<h2><a href=\"", "Agent: <strong>");
		U.log("length:-" + add1.length);
//		 U.log("pppppppp "+key);
		for (String s : add1) {
			s = s.replace("Trillium on Grand", "Trillium On Grand");
			String com=U.getSectionValue(s, "at ", "</strong>");
//			 U.log("hhh :: "+s+"ggggg :: "+key);
			if (com.contains(key)) {//equals(key)
				// U.log("hhh "+s+"ggggg");
				data += s + ":::::::::::::::::::::::::::::::::::::::::";
			}
		}
		return data;
	}

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String url = "https://www.wchomes.com/";
		String html = U.getHTML(url);
		// U.log(html);
		String URL = ALLOW_BLANK;
		html = U.removeComments(html);
		String comUrlSection = U.getSectionValue(html, "Communities</h1>", "<li id=\"menu-item-866\"");
		comUrlSection= comUrlSection.replaceAll("menu-item-seahaven|menu-item-lafayette", "class=\"menu-item menu-item-type-custom menu-item-object-custom menu-item-");
		String[] ht3 = U.getValues(comUrlSection, "class=\"menu-item menu-item-type-custom menu-item-object-custom menu-item-", "</li>");
		
		U.log("length::" + ht3.length);
		for (int i = 0; i < ht3.length; i++) {
			 U.log("hello : "+ht3[i]);
			 String commurl = U.getSectionValue(ht3[i], "href=\"", "\"");
			
			
			
				if(ht3[i].contains("seahaven"))
				{
					U.log(ht3[i]);
					//ht3[i]=ht3[i].replace(">Sea Haven<", "");
					String Comurl=U.getSectionValue(ht3[i], "href=\"", "\"");
					U.log(commurl);
					String HTML=U.getHTML(Comurl);
					String subUrlSec=U.getSectionValue(HTML, "<a href=\"/neighborhoods\">Neighborhoods</a>", " <li class=\"has-submenu\">");
					String[] suburls=U.getValues(subUrlSec, "<a href=\"", "\"");
					{
						for(String Sub : suburls)
						{
							Sub="//www.liveseahaven.com"+Sub;
							addDetails(Sub);//jully 
						}
					}
//					U.log(subUrlSec);
				}
			
			
			if(ht3[i].contains("/community/"))
//				String url = ALLOW_BLANK;
			
			addDetails(ht3[i]);//july allowBl;amnk
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	void callAdddetails(String comm[]) throws Exception {
		for (String s : comm) {
			addDetails(s);
		}
	}

	private void addDetails(String secComm) throws Exception {
//	 try{
		{
			 U.log("sec start ::::::::::: "+secComm+"::::::::End sec");

			if (secComm.contains("buying-a-home"))
				return;
			
			if(secComm.contains("s://www.wchomes.com/community/seahaven/"))
			{
				secComm="http"+secComm;
				
					
					LOGGER.AddCommunityUrl(secComm+"=======MAin Community Url============");
					return;
				}
				
			String url = ALLOW_BLANK;
			if(secComm.contains("s://")|| secComm.contains("community/seahaven/"))
			{
			url = U.getSectionValue(secComm, "href=\"", "\"");
			U.log(">>>>>>>>>>>>>>>>>>>>>>>>"+url);
			}
			else {
							
				url="https:"+secComm;
				
			}
			U.log(":::::::::::::::::::"+"COUNT= "+j+"::::::::::::::::::::::::");

			

			if(url.equals("https://www.wchomes.com/community/westerra/")) {
				LOGGER.AddCommunityUrl("this is the main community:::::::"+url);
				return;
			}
			if(url.equals("https://www.wchomes.com/community/riverstone/")) {
				LOGGER.AddCommunityUrl("this is the main community:::::::"+url);
				return;
			}
      LOGGER.AddCommunityUrl(url);
			U.log("url :: " + url);
//			if(url.contains("/cypress/"))url="https://www.liveseahaven.com/neighborhoods/cypress";



			//TODO:SINGLE EXE
//			 if(!url.contains("https://www.wchomes.com/community/lafayette/"))return;
//			 
			 
			 
			U.log(U.getCache(url));
			String htm = U.getHtml(url,driver);
			
			String[] qkSec=U.getValues(htm, "<div class=\"qmi-slide-col-2 wc-match-heights1\">", "</span></span>");
//			U.log(qkSec.length);
			
//			U.log("SQFT"+Util.matchAll(htm,"[\\w\\W\\s]{40}3,243[\\w\\W\\s]{40}", 0));
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl("------REPEATED-------" + url);
				return;
			}
			if (htm.contains("<div class=\"scl-list\">")) {
				String[] comms = U.getValues(htm, "<td>", "</td>");
				callAdddetails(comms);
				return;
			}
			// U.log(htm);
			String commSec=ALLOW_BLANK;
			if(url.contains("/westerra")) {
				htm = htm.replaceAll("</div>\\s*</div>\\s*</div></div></div></div>", "endSec");
				String comSec[] = U.getValues(htm, "<div class=\"vc_row-full-width vc_clearfix\"></div><div id", "endSec");
				U.log(comSec.length);
				for(String sec: comSec) {
					if(sec.contains("=\"contact\""))continue;
					String urlSec[] = url.split("#");
					U.log("----"+urlSec[1]);
					if(sec.contains("=\""+urlSec[1]))commSec = sec;
					//U.log(commSec);
				}
			}
			String commName=null;
//			U.log(secComm);
			 commName = U.getSectionValue(secComm.replace(" \">", ""), "\">", "<");
			if (commName != null)
			commName = commName.replace("&raquo;", "").trim();
			else
				commName=U.getSectionValue(htm, "<title>", "| Sea Haven</title>");
				
			
			U.log("commName :" + commName + "::::");
			// commName=ALLOW_BLANK;
			if (commName == null)
				commName = U.getSectionValue(htm, "rel=\"home\"><span>", "<");
//			if (url.contains("cypress"))
//				commName = U.getSectionValue(htm, "<title>", "|");

			String note = ALLOW_BLANK;
			
			// ----------Move in ready data--------------
			String quikdata = callQuick(commName);
			//U.log("Quick data:- " + quikdata);

		
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			String geo = "False";
			String[] aa = { ALLOW_BLANK, ALLOW_BLANK };
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };

			String addSec = U.getSectionValue(htm, "<span class=\"wc-u-title\">", "</span>");
//			if (url.contains("cypress")) {
//				
//				addSec = U.getSectionValue(htm, "<a href=\"https://www.google.com/maps/place/", "</strong></p><p>");
//				if(addSec!=null) {
//				addSec = U.getSectionValue(addSec, ">", "<");
//				}
//			}
			U.log("addsec===" + addSec);
			if(addSec!=null) 
			{
				addSec = addSec.replace("&amp;", "&").replace("Imjin Parkway & Marina Heights Drive", "Imjin Parkway, Marina, CA,").replace(" | ",
					" , ").replace("Ave. Fresno,", "Ave., Fresno,").replace("Clovis CA", "Clovis, CA").replace("Madera CA", "Madera, CA");
				if (addSec.length() > 17)
				{
					add = U.getAddress(addSec);
				}
			}else {
				if(url.contains("/larkspur/") || url.contains("larkspur-at-sea-haven")) {
					add[0]="";
					add[1]="Larkspur";
					add[2]="CA";
					add[3]="";
					String latln[] = U.getGoogleLatLngWithKey(add);
					if(latln!=null) {
						lat = latln[0];
						lng = latln[1];
						add = U.getAddressGoogleApi(latln);
						if(add == null) add = U.getAddressHereApi(latln);
						geo = "True";
						note = "Address Is Calculated Using City And State";
					}
				}
				
				if(url.contains("https://www.liveseahaven.com/neighborhoods/cypress") || url.contains("cypress-at-sea-haven")) {
					add[0]="";
					add[1]="Cypress";
					add[2]="CA";
					add[3]="";
					String latln[] = U.getGoogleLatLngWithKey(add);
					if(latln!=null) {
						lat = latln[0];
						lng = latln[1];
						add = U.getAddressGoogleApi(latln);
						if(add == null) add = U.getAddressHereApi(latln);
						geo = "True";
						note = "Address Is Calculated Using City And State";
					}
				}
				
				if(url.contains("https://www.liveseahaven.com/neighborhoods/cypress")) {
					add[0]="";
					add[1]="Cypress";
					add[2]="CA";
					add[3]="";
					String latln[] = U.getGoogleLatLngWithKey(add);
					if(latln!=null) {
						lat = latln[0];
						lng = latln[1];
						add = U.getAddressGoogleApi(latln);
						if(add == null) add = U.getAddressHereApi(latln);
						geo = "True";
						note = "Address Is Calculated Using City And State";
					}
				}
				
			
				
			//	https://www.wchomes.com/community/north-artisan-place/

				
				//https://www.liveseahaven.com/neighborhoods/cypress
			}
			if(url.contains("https://www.wchomes.com/community/north-artisan-place/")) {
				add[0]="8519-8489 N Locan Ave";
				add[1]="Clovis";
				add[2]="CA";
				add[3]="93619";
				String latln[] = U.getGoogleLatLngWithKey(add);
				if(latln!=null) {
					lat = latln[0];
					lng = latln[1];
				//	add = U.getAddressGoogleApi(latln);
					geo = "True";
					//note = "Address Is Calculated using City And State";
				}
			}
			
			if(url.contains("liveseahaven")) {
				String regHtml=U.getHtml("https://www.liveseahaven.com",driver);
				U.log("path:: "+U.getCache("https://www.liveseahaven.com"));	
				String addSection=U.getSectionValue(regHtml, "Site Entrance</strong>", "target=\"_blank\"");
				if(addSection!=null) {
				String addLine=U.getSectionValue(addSection, "<br>", "<br><br><a").replace("<br>", ",");
				add=U.getAddress(addLine);
				
				lat=U.getSectionValue(addSection, "/@", ",");
				
				lng=Util.match(addSection, "\\-\\d{2,3}\\.\\d+");
				
				U.log("LTANG"+" "+lat+" "+lng);
				

			}
			}

			U.log("::::"+Arrays.toString(add));
			
			if(add[0].length()<4){
				addSec = U.getSectionValue(htm, "https://www.google.com/maps/embed?pb=", "\"");
				U.log("addSec : "+addSec);
				if(addSec!=null) {
					addSec  = U.getSectionValue(addSec, "!2s", "!");			
					if(addSec!=null) {
						addSec = addSec.replace("+", " ").replace("%2C",",");
					}
				}
				if(addSec!=null) {
					if(addSec.contains(",") )
						add = U.getAddress(addSec);					
				}
			}
			U.log(Arrays.toString(add));
			
			String latlong = U.getSectionValue(htm, "https://www.google.com/maps/embed?pb=", "\"");
			String[] ll = {};
			if(latlong==null)latlong ="";
			String lati = U.getSectionValue(latlong, "2d", "!2m");
			
			if (lati == null) {
				lati = U.getSectionValue(latlong, "2d", "!3m");
			}
			
			if (url.contains("cypress") && lat==null) {
				lati = U.getSectionValue(U.getSectionValue(htm, "<a href=\"https://www.google.com/maps/place/", "</strong></p><p>"), "!3d", "\"");
				U.log(lati);
				ll = lati.split("!4d");
				U.log(ll[0] + "  " + ll[1]);
				lat = ll[0];
				lng = ll[1];
			}else {
			if(lat==null) {	
			ll = lati.split("!3d");
			U.log(ll[0] + "  " + ll[1]);
			lat = ll[1];
			lng = ll[0];
			}
			aa[0] = lat;
			aa[1] = lng;
			}
			if (lat==ALLOW_BLANK && htm.contains("<a href=\"https://www.google.com/maps/embed")) {
				latlong = U.getSectionValue(htm, "https://www.google.com/maps/embed?", "\"");
				lat = U.getSectionValue(latlong, "3d", "!");
				lng = U.getSectionValue(latlong, "2d", "!");
			}
			String addressSec = U.getSectionValue(htm, "<a href=\"https://www.google.com/maps", "\"");
			if (addressSec != null && !url.contains("https://www.wchomes.com/community/north-artisan-place/")) {
				addressSec = U.getSectionValue(addressSec, "!2s", "!5e0");
				U.log("====" + addressSec);
				if (addressSec != null) {
					Matcher mat = Pattern.compile("\\d{5}", Pattern.CASE_INSENSITIVE).matcher(addressSec);
					while (mat.find()) {
						U.log(mat.group());
						add[3] = mat.group();
					}
					if (add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK) {
						addressSec = addressSec.replace("+", " ").replace("%2C", ",");
						add = U.getAddress(addressSec);
						U.log(Arrays.toString(add));
					}
				}
			}

			if (add[3].length() < 3 && aa[0]!=ALLOW_BLANK) {
				add = U.getAddressGoogleApi(aa);
				if(add == null) add =U.getAddressHereApi(aa);
				geo = "True";
			}
			
			if(lat==ALLOW_BLANK && add[0]!=ALLOW_BLANK) 
			{
				String latln[] = U.getGoogleLatLngWithKey(add);
				if(latln!=null) {
					lat = latln[0];
					lng = latln[1];
				//	add = U.getAddressGoogleApi(latln);
					geo = "True";
					//note = "Address Is Calculated using City And State";
				}
			}
			if(url.contains("#"))htm+=""+commSec;
			//U.log("SQFT2"+Util.matchAll(htm,"[\\w\\W\\s]{40}3,243[\\w\\W\\s]{40}", 0));
			String remsec = U.getSectionValue(htm, "<h2 class=\"font1\">Featured Listing</h2>", "</html>");
			if (remsec != null)
				htm = htm.replace(remsec, "");
		//	U.log("SQFT3"+Util.matchAll(htm,"[\\w\\W\\s]{40}3,243[\\w\\W\\s]{40}", 0));
			String remsec1 = U.getSectionValue(htm, "What is your price range", "</select>");
			//U.log("remsec1 : "+remsec1);
			if (remsec1 != null)
				htm = htm.replace(remsec1, "");

			String[] minmax = { ALLOW_BLANK, ALLOW_BLANK };

			// Price
			String homeHtml = "";
			
			String homeSec=U.getSectionValue(htm, "<div class=\"top-level-menu\">", "<div class=\"wc-u-clearfix\"></");
//			if (htm.contains("<div class=\"wc-ModelPreview--main\">")) {
//				String homeUrl[] = U.getValues(htm, "<div class=\"wc-ModelPreview--main\">", "</a>");
//				
//				for (String url1 : homeUrl) {
//					url1 = U.getSectionValue(url1, "<a href=\"", "\"");
//					U.log("Home Urls:: "+url1);
//					homeHtml = homeHtml + U.getHTML(url1);
//				}
//			}
//			if (htm.contains("<div class=\"wc-ModelPreview--main\">")) {
			if (homeSec!=null) {
				String homeUrlSec[] = U.getValues(homeSec, "<a href=\"javascript:;\">", "</ul>");
				for(String hmSec:homeUrlSec) {
					if(hmSec.contains(commName)) {
						String[] hmUrls=U.getValues(hmSec, "href=\"", "\"");
						for(String homeUrl:hmUrls) {
//							U.log("hm URL: "+homeUrl);
							homeHtml = homeHtml + U.getHTML(homeUrl);
						}
					}
				}
			}
			
			if (add[2] == null) {
				String latll[] = { ALLOW_BLANK, ALLOW_BLANK };
				latll[0] = ll[1];
				latll[1] = ll[0];
				String[] add1 = U.getAddressGoogleApi(latll);
				if(add1 == null) add1 = U.getAddressHereApi(latll);
				add[0] = add1[0];
				add[1] = add1[1];
				add[2] = add1[2];
				add[3] = add1[3];
				geo = "TRUE";
			}

			U.log(Arrays.toString(add));
			
			
			//From contact us page
			if(add[0]==ALLOW_BLANK) {
				String contactHtml=U.getHtml("https://www.liveseahaven.com/#contact", driver);
				String adSec=U.getSectionValue(contactHtml, "Site Entrance</strong><br>", "<br><br>").replace("<br>", ", ");
				add=U.getAddress(adSec);
				String latSec=U.getSectionValue(contactHtml, "Pkwy,+Marina,+CA+93933/@", ",17z/");
				U.log(latSec);
				String[] la=latSec.split(",");
				lat=la[0];
				lng=la[1];
				
			}

			htm = htm.replace("Starting From the 1.4M", "Starting From the 1,400,000").replace("&#039;s", ",000").replace("$1.1M", "STARTING FROM $1,100,000 ").replace("$300s", "$300,000").replace("00&#8217;s", "00,000").replace("STARTING FROM 1.1M", "STARTING FROM $1,100,000").replace("Starting From the 1.0M", "Starting From the $1,000,000")
					.replace("Starting From the 1.1M", "Starting From the $1,100,000")
					.replace("Starting From the 1.2M", "Starting From the 1,200,000")
					.replace("Starting From the 1.3M", "Starting From the 1,300,000").replace("0’s", "0,000");
			//U.log(htm);
//			U.log("mmmmmm"+Util.matchAll(htm, "[\\w\\s\\W]{50}617[\\w\\s\\W]{40}", 0));
//			U.log("mmmmmm"+Util.matchAll(quikdata, "[\\w\\s\\W]{50}617[\\w\\s\\W]{40}", 0));
//			U.log("mmmmmm"+Util.matchAll(homeHtml, "[\\w\\s\\W]{50}617[\\w\\s\\W]{40}", 0));

			minmax = U.getPrices(htm.replaceAll("<strike>\\$\\d{3},\\d{3}</strike>", "") + quikdata.replaceAll("<strike>\\$\\d{3},\\d{3}</strike>", "") + homeHtml.replaceAll("<strike>\\$\\d{3},\\d{3}</strike>", ""),
					"Starting From the \\d,\\d{3},\\d{3}|Starting From the \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d,\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|STARTING AT  \\$\\d,\\d{3},\\d{3}|Listing Price: \\$\\d,\\d{3},\\d{3}|STARTING FROM \\$\\d,\\d{3},\\d{3}|<div class=\"price\">\\$\\d,\\d{3},\\d{3}</div>|STARTING AT \\$\\d{3},\\d{3}|Starting (in the mid|from the) \\$\\d{3},\\d{3}|\\$\\d+,\\d+|Starting at \\$\\d{3},\\d{3}",
					0);
			minPrice = (minmax[0] != null) ? minmax[0] : ALLOW_BLANK;
			maxPrice = (minmax[1] != null) ? minmax[1] : ALLOW_BLANK;

			
			String modelData = ALLOW_BLANK;
			String modelSec = U.getSectionValue(htm, "<section class=\"neighborhood-models\" id=\"models\">", "</section>");
			if (modelSec != null) {
				String[] models = U.getValues(modelSec, "<a href=\"", "\"");
//				U.log(Arrays.toString(models));
				for (String murl : models)
					modelData += U.getHTML(murl);
				

			}
			
			// squarefeet
			
//			U.log("SQFT"+Util.matchAll(htm,"[\\w\\W\\s]{40}2,380-3,411 sq. ft.[\\w\\W\\s]{40}", 0));
//			U.log("SQFT"+Util.matchAll(quikdata,"[\\w\\W\\s]{40}2,380-3,411 sq. ft.[\\w\\W\\s]{40}", 0));
//             U.log("SQFT"+Util.matchAll(modelData,"[\\w\\W\\s]{40}2,380-3,411 sq. ft.[\\w\\W\\s]{40}", 0));

			String[] minmax1 = U.getSqareFeet(htm + quikdata+modelData,
					"\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d,\\d{3}-\\d,\\d{3} Square Feet|<strong>\\d,\\d{3} Square Feet|Square Footage \\d{4}|\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d,\\d{3}-\\d,\\d{3} square feet|\\d{4} sq ft. to \\d{4} sq ft|\\d,\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} SQUARE FEET|\\d{4} Square Feet|SQUARE FOOTAGE \\d,\\d{3}",
					
					0);
			minSqf = (minmax1[0] != null) ? minmax1[0] : ALLOW_BLANK;
			maxSqf = (minmax1[1] != null) ? minmax1[1] : ALLOW_BLANK;

			if (commName.length() > 100)
				commName = "Trillium On Grand";
			add[0]=add[0].replaceAll("%26", "&");
			commName = commName.replace("»", "");
			
			if(note!=ALLOW_BLANK) {
				String newnote =U.getnote(htm);
				if(newnote!="-")
				note = note +", "+ newnote ;
				else
					note=note;
			}else {
				note =  U.getnote(htm);
			}
			
			String remove = "<h3>Now Open</h3>\\s*<p class=\"wc|Coming Soon to Madera Ca|Quick Move-In Homes|MODEL CENTER NOW OPEN|Move In Ready|Coming Spring 2015</a>|ready to move|Move-in-ready|Move-in Ready|Move In Ready Homes|Move-in-ready|2014|Move-in Ready Home|move-in ready home";

			String rem = U.getSectionValue(htm, "<footer id=", "</body>");
			String propHtml = htm;

			String remo = U.getSectionValue(htm, "Wathen Castanos Homes", "My Neighborhood");
			if (remo != null)
				propHtml = htm.replace(remo, "");
			if (rem != null)
				propHtml = htm.replace(rem, "");
			propHtml += U.getSectionValue(htm, "<div class=\"wc-u-block wc-CommunityIntro-content\">", "<div class=\"wc-u-col wc-u-col-2 wc-CommunityIntro--photo\"");
//			U.log(U.getSectionValue(htm, "<div class=\"wc-u-block wc-CommunityIntro-content\">", "<div class=\"wc-u-col wc-u-col-2 wc-CommunityIntro--photo\""));
			propHtml = propHtml.replace("stylishly crafted plans", "Craftsman style details").replaceAll("expansive loft|den or loft", "den or loft homes ");

			// -----------Property Type--------------
			String pType = ALLOW_BLANK;

			propHtml = propHtml.replace(" The beautiful collection of estates",
					" The beautiful collection of estate-like homes")
					.replace("Available in Spanish, Tuscan and American Traditional", "Available in Spanish, Tuscan and American Traditional style home");

			pType = U.getPropType(modelData.replaceAll("courtyard|Courtyard", "")+propHtml.replace("multi-generational household", " multi-generational families"));

			// ------------Status-------------
			String Ps = ALLOW_BLANK;
			String comInfoSec = U.getSectionValue(htm, "CommunityIntro\">", "CommunityMapButton\">");
			if(comInfoSec==null)comInfoSec="";
			comInfoSec=comInfoSec.replace(">Models Opening Soon", "");
			htm = htm
//					.replace("Coming In 2022", "Coming 2022")
					.replaceAll("quick-move-in \">|quick-move-in/\">Quick Move-In Homes|url=\"/quick-move-in/|>Quick Move-In Homes</button>|alt=\"Available Quick Move|title\">Quick Move|headline\">Quick Move|alt=\"quick-move|Coming Soon to Clovis</h6>|Move In Homes|>Models Opening Soon<|copming-soon-footer|New Homes coming soon to San Luis|>Coming Soon to Riverstone</h6>", "");
			Ps = U.getPropStatus(htm.toLowerCase().replaceAll(remove.toLowerCase(), "") + comInfoSec);
//			 U.log("propHtml::::::"+Util.matchAll(propHtml, "[\\w\\s\\W]{30}crafts[\\w\\s\\W]{30}",0)+"::::::::::::::");
			U.log("quick Count :: "+qkSec.length);
			if (quikdata.contains(commName) && !Ps.contains("Move-In") || qkSec.length>0) {
				U.log("quick yes");
				if (Ps.length() < 4 ) {
					Ps = "Quick Move-In Homes";
				} else {
					Ps = Ps + ", Quick Move-In Homes";
				}
			}
			if(url.contains("/trillium-on-grand/"))Ps= "Quick Move-In Homes";
			String flrSec = U.getSectionValue(htm, "All</a></li>  ", "Lot Map</a></li>");
			String flrHtml = null;
			if (flrSec != null) {
				String flrUrl[] = U.getValues(flrSec, "<a href=\"", "\"");

				for (String fl : flrUrl) {
					fl = "http://www.wchomes.com" + fl;
					flrHtml += U.getHTML(fl);

				}
			}
//			String modelHomes=U.getSectionValue(htm, " <section class=\"neighborhood-models\" id=\"models\">", "</section>");
//			if(modelHomes!=null) {
//				String[] modelUrl=U.getValues(modelHomes, "", To)
//			}
			htm = htm.replace("One &amp; Two-Story ", " 1 story 2 story").replace("one &#8211; to three story", " 1 story 2 story 3 story ");
			htm = htm.replace(" one – to three story", " 1 story 2 story 3 story ");
			String dtype = U
					.getdCommType((modelData+htm + flrHtml).replaceAll("spacious first floor offers additional square", ""));
			
			
			htm=htm.replace("world-class golf,", "golf, and");
			String ctype = U.getCommunityType(
					htm.replaceAll("corrugated|\"Cypress will be located in the master planned communit|\"Villosa, located in the master planned community of |target=\"_self\">Master Plans</a>|master planned communities that|elongated", ""));
			U.log("CType::" + ctype);
			if(url.contains("https://wchomes.com/community/westerra/#ariette"))Ps = "Now Selling";//Img
//			if(url.contains("https://www.wchomes.com/community/artisan-place/"))
			Ps = Ps.replace("Sold-out", "Sold Out");
			
//			if(url.contains("https://wchomes.com/community/riverstone"))Ps="Coming Summer 2022";
			if(url.contains("https://www.liveseahaven.com/neighborhoods/cypress"))add[0]="Ball Rd-Walker St";
			//==========================================================================================
			

			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
//			String lot_Sec=U.getSectionValue(htm, "<svg version=", "</svg>");
//			if(lot_Sec!=null) {
				lot_data=U.getValues(htm, "<polygon class=\"imp-shape", "</polygon>");
				if(lot_data.length>0) {
				lotCount=Integer.toString(lot_data.length);
				 U.log("lotCount=="+lotCount);
//				}
			}
			
			
			
			
			
			data.addCommunity(commName, url, ctype);
			data.addLatitudeLongitude(lat.trim(), lng.trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addPropertyStatus(Ps);
			data.addPropertyType(pType, dtype);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3]);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}


		j++;
//	 }catch(Exception e){}

	}

}