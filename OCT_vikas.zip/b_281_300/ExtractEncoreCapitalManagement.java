package com.shatam.b_281_300;

/**
 * @author Rakesh Chaudhari
 * @date 08-07-2015
 * 
 */
import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractEncoreCapitalManagement extends AbstractScrapper {
	static String BASEURL = "https://cityhomes-us.com";
	CommunityLogger LOGGER;
	WebDriver driver;

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractEncoreCapitalManagement();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(
				U.getCachePath()+"Encore Capital Management - City Homes.csv", a.data()
						.printAll());
	}

	public ExtractEncoreCapitalManagement() throws Exception {

		super("Encore Capital Management - City Homes", BASEURL);
		LOGGER = new CommunityLogger("Encore Capital Management - City Homes");
	}

	public void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		String html = U
				.getHTML("https://cityhomes-us.com/communities/");
		String urls_section = U.getSectionValue(html, "<div class=\"row container-flex\">",
				"</article>");
		// U.log(urls_section);
		String community_region_url[] = U.getValues(urls_section,
				"<a href=\"", "\">");
		for (String url_name : community_region_url) {

			
			//url_name = "http://www.cityhomes-us.com" + url_name;
			if(url_name.contains("http://www.cityhomes-us.com/homes-ready-now"))continue;
			if(url_name.contains("http://www.cityhomes-us.com/homes-available-now"))continue;
			
//			try {
				addDetails(url_name);
//			} catch (Exception e) {}

		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	private String[] getPrices(String commUrl,String sec,String hhtml) throws IOException {
		U.log(sec+"this is my section");
		String html = U.getHTML(commUrl);
		String[] prices = { ALLOW_BLANK, ALLOW_BLANK };
		sec=sec.replace("'s</span>", ",000");
		html=html.replace("$1 million", " $1,000,000 ").replace("0’s","0,000").replace(" low 200s", " low $200,000");
		hhtml = hhtml.replaceAll("\\$(\\d,)?\\d{3},\\d{3}</option>", "");
		prices = U.getPrices(html+sec+hhtml,
				"<h4>\\d{6}</h4>|<h2>\\s*\\d{3},\\d{3}( to \\d{3},\\d{3})?|<h2>\\s*\\d{6} to \\d{6}|<h4>\\d,\\d{3},\\d{3}</h4>|\\$\\d{3},\\d{3}|card-price\">\\s*\\$(\\d,)?\\d{3},\\d{3}|top\">\\$\\d,\\d{3},\\d{3}|low \\$\\d{3},\\d{3}|Priced from: \\$\\s?\\d{3},\\d{3}( to \\$\\s?\\d{3},\\d{3})?|align=\"center\">\\$\\d+,\\d+|\\$\\d+,\\d+,\\d{3}|the [0-9]{3},[0-9]{3}|top\">\\$\\d+,\\d+|from the \\$\\d+,\\d+", 0);
//		U.log(Util.matchAll(hhtml, "[\\w\\s\\W]{30}$600[\\w\\s\\W]{30}", 0));
		prices[0] = (prices[0] == null) ? ALLOW_BLANK : prices[0];
		prices[1] = (prices[1] == null) ? ALLOW_BLANK : prices[1];
		U.log("prices ::"+prices[0] + "\t" +prices[1] );
		return prices;

	}

	private String[] getSqft(String commUrl,String hhtml) throws IOException {

		String html = U.getHTML(commUrl);
		String[] sqFt = { ALLOW_BLANK, ALLOW_BLANK };
		// String flowMainLink = U.getSectionValue(html, "floorplan1.aspx",
		// "\"");
		html=html.replaceAll("elevations over 1,500 ft.", "");
		sqFt = U.getSqareFeet(html+hhtml,
		// from the $400,000
				"over \\d,\\d{3} ft|\\d,\\d{3}ft|align=\"center\">\\d+,\\d+</td>|top\">\\d{1,},\\d{3}|\\d,\\d{3}&nbsp;ft<sup>", 0);

		sqFt[0] = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		sqFt[1] = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];

//		U.log(">>>>>>>>>>>"+Util.matchAll(html+hhtml, "[\\s\\w\\W]{20}1500[\\s\\w\\W]{30}", 0));

		
		return sqFt;

	}

	public String[] getAddress(String commurl) throws IOException {
		String add1[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String html = U.getHTML(commurl);

		String secAddress = U.getSectionValue(html,
				"<h2>", "</h2>");
		if(commurl.contains("https://cityhomes-us.com/communities/hatchery-crossing/"))
		{
			secAddress="Hatchery Crossing Dr, Waterford Twp, MI 48329";
			
		}
		
		if(commurl.contains("https://cityhomes-us.com/communities/auburndale/")) {
			secAddress = U.getSectionValue(html,"href=\"https://www.google.com/maps/place/","\"");
		}
		
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		if(secAddress!=null) {
			add = U.findAddress(secAddress);			
		}
	
		if(add!=null)
			return add;
		return add1;

	}

	public void addDetails(String commSec) throws Exception {

		String commUrl=commSec;
//	if (!commUrl.contains("https://cityhomes-us.com/communities/smoky-mountain-resort-pigeon-forge-gatlinburg-tn/"))return; //10/7/2017
		// ............................Community Url...........................
		U.log("Page Url: " + commUrl);
		// ...........................Community Name...........................
		//TODO : Execution For single community
//		if(!commUrl.contains("https://cityhomes-us.com/communities/auburndale/"))return; //Single Run
	
		if(data.communityUrlExists(commUrl)) {
			LOGGER.AddCommunityUrl(commUrl+"----->Repeated ");
			return;
		}
		LOGGER.AddCommunityUrl(commUrl);
//		String html = U.getHTML(commUrl);
		String html=U.getHtml(commUrl, driver);
		
		String homesInThisCommunity = null;
		String homesUrlSection = U.getSectionValue(html, "View Virtual Tour", "Homes In This Community");
		if(homesUrlSection != null){
			String homeUrl = U.getSectionValue(homesUrlSection, "href=\"../..", "\"");
			if(homeUrl != null && homeUrl.contains("/homes/")){
				if(!homeUrl.startsWith("http")) homeUrl = BASEURL + homeUrl;
				U.log(">> HomeUrl :"+homeUrl);
				
				homesInThisCommunity = U.getHTML(homeUrl);
			}
		}
		String hhtml="";
		String hsec=U.getSectionValue(html, "<a class=\"btn btn-primary btn-full-width\"","See Floor Plans");
		
		if(hsec!=null)
		{
			hsec = hsec.replaceAll("href=\"https://www.youtube|href=\"../../homes/", "");
			
			String hurlSec=U.getHTML( "https://www.cityhomes-us.com"+U.getSectionValue(hsec, "<a class=\"btn btn-primary btn-full-width\" href=\"","\""));
			
			if(hurlSec!=null)
			{
			String[] hurl = U.getValues(hurlSec, "<div class=\"card\">", "</a>");
			
		
			for(String s:hurl)
			{
				String url = U.getSectionValue(s, "<a href=\"", "\"");
				U.log("HomeUrl :"+url);
				hhtml=hhtml+U.getHTML(url);
	//			U.log(U.getCache(url));
	//			U.log("This Com Home");
				String newSec = U.getSectionValue(html, "<a class=\"btn btn-primary btn-full-width\"", "Homes In This Community");
				if(newSec==null) {continue;}
				newSec = newSec.replaceAll("href=\"https://www.youtube|", "");
				String newUrl = U.getSectionValue(newSec, "href=\"", "\">").replace("../..", "");
				if(!newUrl.startsWith("http"))
					newUrl = "https://www.cityhomes-us.com"+ newUrl;
				U.log("newUrl== "+newUrl);
				String hh = U.getHTML(newUrl);
				hhtml = hhtml+hh+"\n";
			}
		}
		}
		String floorplanurl = U.getSectionValue(html, "<a class=\"btn btn-primary btn-full-width\" href=\"/plans/", "\""); 
		if(floorplanurl!=null)
		{
			String floorHtm = U.getHTML("https://cityhomes-us.com/plans/"+floorplanurl);
			String plans[]= U.getValues(floorHtm, "<div class=\"card\">", "</h4>");
			for(String plan:plans) {
				U.log("floor plans ::"+U.getSectionValue(plan, "<a href=\"", "\""));
				String hh = U.getHTML(U.getSectionValue(plan, "<a href=\"", "\""));
				
				hhtml +=hh+"\n"; 
				if(hh.contains("loft")) {
					U.log("Found");
				}
			}
		}

		String commName = U.getSectionValue(html, "<h1>", "</h1>");
		commName.replace("Hatchery Crossing Dr","Detroit Suburbs");
		if(commUrl.contains("https://cityhomes-us.com/communities/smoky-mountain-resort-pigeon-forge-gatlinburg-tn/"))commName="Smokey Resort";
		if(commUrl.contains("https://cityhomes-us.com/communities/reunion-resort-orlando/"))commName="Reunion Resort Orlando";
		if(commUrl.contains("https://cityhomes-us.com/communities/auburndale/"))commName="Lake Ariana Beach Club";
		if(commUrl.contains("https://cityhomes-us.com/communities/hi-roc"))commName="Hi Roc";
		if(commUrl.contains("https://cityhomes-us.com/communities/north-port/"))commName="Sarasota";
		if(commUrl.contains("https://cityhomes-us.com/communities/hatchery-crossing/"))commName="Hatchery Crossing Dr";
		//if(commUrl.contains("https://cityhomes-us.com/communities/north-port/"))commName="Sarasota";
		if(commUrl.contains("https://cityhomes-us.com/communities/north-port/"))commName="North Port";
		if(commUrl.contains("https://cityhomes-us.com/communities/cape-coral/"))commName="Cape Coral";
		commName = U.getCapitalise(commName.replaceAll("Dr$|, GA| - Pigeon Forge/Gatlinburg, TN", "").toLowerCase());
		// Add
		U.log("CommName: "+commName);

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
//		String addSec=U.getSectionValue(html, "", To)
		add = getAddress(commUrl);
		// getAddress(commUrl);
		// Price

		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] prices = getPrices(commUrl,commSec,hhtml +homesInThisCommunity);
		
		minPrice = prices[0];
		maxPrice = prices[1];
		//U.log(Util.match(html,"\\$\\d,\\d{3},\\d{3}"));
		commSec=commSec.replace("'s</span>", ",000");
		U.log("commSec:::"+commSec);
		if (minPrice == ALLOW_BLANK) {
			prices = U.getPrices(html+commSec,"\\$\\d,\\d{3},\\d{3}|Priced starting at \\$\\d{3},\\d{3}|From the \\d{3},\\d{3}|from the\\s+\\$\\d+,\\d+",
					0);
//			U.log(Util.matchAll(commSec, "[\\w\\s\\W]{30}$600[\\w\\s\\W]{30}", 0));
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

		}

		
		// if()

		// Sqft

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		String sqFt[] = getSqft(commUrl,hhtml.replace("&nbsp;", "")+homesInThisCommunity);

		minSqft = sqFt[0];
		maxSqft = sqFt[1];

		
		if(add[1].length()<4)
		{
			String secAddress = U.getSectionValue(html,
					"Community Location</h4>", "<hr>");
			if(secAddress!=null) {
			secAddress=secAddress.replace("<br>",",");
			add=secAddress.split(",");
			}

			
		}
		

		String addressss="";
		if(add[1].length()<4) {
			
			addressss=U.getSectionValue(html, "<a class=\"btn btn-primary btn-map btn-full-width\" href=\"https://www.google.com/maps/place/", "\"");
			if(addressss!=null) {
				add=U.getAddress(addressss);
			}
		}
		
		
		String flag = "TRUE";
		
//		if(commUrl.contains("https://cityhomes-us.com/communities/auburndale/")) {
//			
//			add[0] = "1060 Lake Ariana Blvd";
//			add[1] = "Auburndale";
//			add[2] = "FL";
//			add[3] = "33823";
//			flag = "TRUE";
//			//From Map
////			//bcz add on map was showinfg in lake
////	
//		}
				// LatLng
	
		add[0]=add[0].replace("Lake Ariana", "Lake Ariana Blvd");
		U.log(" ddddd "+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		
		
		String mLatSec=ALLOW_BLANK;
		String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
		
		if(html.contains("driving-directions")){
			String driHtml=U.getHTML(commUrl+"/driving-directions");
			latLng[0]=U.getSectionValue(driHtml, "LATITUDE\":", ",\"");
			latLng[1]=U.getSectionValue(driHtml, "LONGITUDE\":", ",\"");
			flag="FALSE";
			U.log("latlng are ::"+Arrays.toString(latLng));
		}else {
			String latSec=U.getSectionValue(html, "<div style=\"margin-bottom:50px;\" class=\"container-text\">", "error</a></div></div></div></div></div></div></div>");
		    if(latSec!=null)
			  mLatSec=U.getSectionValue(latSec, "https://www.google.com/maps/", ">Report a map");
		    if(mLatSec!=null) {
		    String latSection=U.getSectionValue(mLatSec, "@", ",15z/") ;
		    if(latSection!=null)
		    latLng=latSection.split(",");
		    U.log("latSection"+latSection);
		    }
		}
		
		if(latLng[0]==ALLOW_BLANK || latLng[0]==null){
			latLng=U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getGoogleLatLngWithKey(add);
			flag="TRUE";
		}
		
		if(add[3].trim().length()<4 && latLng!=null)
		{
			add=U.getAddressGoogleApi(latLng);
			if(add == null) add = U.getGoogleAddressWithKey(latLng);
			flag="TRUE";
		}
		if(commUrl.contains("https://cityhomes-us.com/communities/auburndale/")) {
			latLng=U.getlatlongGoogleApi(add);
			U.log("HEllo:: "+Arrays.toString(latLng));
			flag="TRUE";
		}
		
		
		
		html=html.replaceAll("Village|class=\"dark\">Homes Available Now</a>|method=HomesAvailableNow\"", "");
		// Community Type
		String communitytype = U.getCommunityType(html.replace("masterfully designed", "").replace("An exquisite lakeside location", "An exquisite lakeside community location"));
		
		
		// Property Type
		

		hhtml = hhtml.replace("multiple families", "MULTI FAMILY").replace("loft/game", "the loft/game").replace(":[\"patio\"]", "");
//		U.log("111>>>>>>"+Util.matchAll( hhtml, "[\\s\\w\\W]{100}loft[\\s\\w\\W]{100}", 0));

		
		html=html.replace("level of luxury", "level of luxury home").replaceAll("vacation-cottages", "").replace("luxurious accomodations", "luxury living");
		String proptype = U.getPropType(((html.replace("create an estate environment", "create an Estate Residences environment")+commSec+hhtml).replace("cottages","")));
//		U.log(">>>>>>"+Util.matchAll( hhtml, "[\\s\\w\\W]{100}patio[\\s\\w\\W]{100}", 0));
		
		U.log("proptype: "+proptype);

		// Derive Prop  
		String dtype = U.getdCommType((html+commSec + hhtml).replaceAll("colonial/assets|colonial-child", ""));
		
		U.log("dtype: "+dtype);
//		U.log(">>>>>>"+Util.matchAll( hhtml, "[\\s\\w\\W]{100}patio[\\s\\w\\W]{100}", 0));

		// Status
		
		String propstatus = U.getPropStatus((html+commSec).replaceAll("Community details coming soon|Description coming soon|Sold Out</span>|Homes Ready Now</a>|HOMES READY NOW</span>",""));
		add[0]=add[0].replace(",", "");
		U.log(add[1]);
		add[1]=add[1].replace("Village of","");
		if(commUrl.contains("http://www.cityhomes-us.com/margaritaville-resort-orlando/michigan/independence-charter-township/cambridge-commons"))communitytype="Resort Style";
		if(commUrl.contains("https://cityhomes-us.com/communities/smoky-mountain-resort-pigeon-forge-gatlinburg-tn/"))communitytype="Resort Style";
	
		flag="FALSE";
		if(commUrl.contains("https://cityhomes-us.com/communities/auburndale/")) flag = "TRUE";
		// Add All
//		if(commUrl.contains("https://cityhomes-us.com/communities/reunion-resort-orlando/")) {
//			maxSqft="6482";
//		}
		
		String counting=ALLOW_BLANK;
		String startDt=ALLOW_BLANK;
		String endDt=ALLOW_BLANK;
		
		data.addCommunity(commName, commUrl, communitytype);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(proptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addNotes(ALLOW_BLANK);
		data.addUnitCount(counting);
		data.addConstructionInformation(startDt, endDt);
	}
}