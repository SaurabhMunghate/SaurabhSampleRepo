package com.shatam.b_281_300;
import java.io.File;
import java.util.Arrays;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLongLakeLimited extends AbstractScrapper {
	
	//ChromeDriver driver =null;
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractLongLakeLimited();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Long Lake Ltd.csv", a.data().printAll());
	}

	public ExtractLongLakeLimited() throws Exception {
		super("Long Lake Ltd", "https://www.longlakeltd.com/");
		LOGGER=new CommunityLogger("Long Lake Ltd");
	}


	int count = 0;

	public void innerProcess() throws Exception {
		
		//U.setUpChromePath();
//		
//		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
//		proxy.setHttpProxy("65.215.2.68:8080")
//		     .setFtpProxy("65.215.2.68:8080")
//		     .setSslProxy("65.215.2.68:8080");
//		DesiredCapabilities cap = new DesiredCapabilities();
//		cap.setCapability(CapabilityType.PROXY, proxy);
		//driver = new ChromeDriver();
		
//		U.setUpChromePath();
////		ChromeOptions options = new ChromeOptions();
////		options.addExtensions(new File("/home/shatam-45/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
//		driver = new ChromeDriver(options);
	//	Thread.sleep(3000);
		
	//	String html = U.getHTML("https://www.longlakeltd.com/neighborhoods/");
//		html = html.replace("<h6><span style=\"color: #000000;\">", "")
//				.replace("<h6>Starting", "Starting");
//		String[] comSections = U.getValues(html, "<h6", "</h6>");
//		
//		U.log("Total Communty :: " +comSections.length);
	//	int count =0 ;
//		for(String comSec : comSections){
////			U.log(comSec);
//			
//			String url = U.getSectionValue(comSec, "href=\"", "\"");
//			//if(url.contains("grand-oaks-cove"))continue ;
//			U.log(count + ":::::::::: " + url);
//			if(!url.contains("https://www.longlakeltd.com/")){
//				url = "https://www.longlakeltd.com"+url;
//			}
//			count++;
//			
//			commDetails(url,comSec);
//		//	U.log("url : "+url+"\n"+comSec);
//		}
		
		
		
		//getCommDetails(url,comSec);
	//	U.log("url : "+url+"\n"+comSec);
		
		
		String html=U.getHTML("https://www.longlakeltd.com/neighborhoods/");
		String nwHtml=U.getHTML("https://www.longlakeltd.com/neighborhoods/2/");
		nwHtml+=U.getHTML("https://www.longlakeltd.com/neighborhoods/3/");
		nwHtml=nwHtml+html;
	
		String commsec[]=U.getValues(html, "class=\"menu-item menu-item-type-post_type menu-item-object-neighborhood menu-item", "/a></li>");
		//String regSec[]=U.getValues(nwHtml, "", To)
		
		
		String series = U.getHTML("https://www.longlakeltd.com/series/briarwood/"); // From Navigation Tab "Series"
		String section = U.getSectionValue(series, "Neighborhoods featuring this series</h3>", "<div data-elementor-type=\"footer\"");
//		U.log(section);
		String luxuryCommunities[] = U.getValues(section, "<div class=\"make-column-clickable-elementor", "data-column-clickable-blank=");
			
		for(String coms:commsec) {
//		U.log(coms);
			String commurl=U.getSectionValue(coms, "href=\"", "\"");
			
//			U.log("comSec commUrl"+commurl);
			
			String commhtml=U.getHTML(commurl);
		
			for(String luxuryCommunity : luxuryCommunities){
				if(luxuryCommunity.contains(commurl)) commhtml = commhtml;//" Luxury Homes "+commhtml;
			}
		
			getCommDetails(commurl, commhtml);
		
		
		}
		
		LOGGER.DisposeLogger();
	}
		//driver.quit();
		
	
	
	int j = 0;
	//TODO ::
	public void getCommDetails(String url,String comSec) throws Exception {
//		if(j == 16)
//		try
	{
//	if(!url.contains("https://www.longlakeltd.com/neighborhood/fairpark-village/"))return;
	//	if(!url.contains("https://www.longlakeltd.com/neighborhood/vanbrooke/"))return;
	//	if(!url.contains("champions-oak"))return;
		String commUrl = url; 
		
        if (data.communityUrlExists(commUrl)){
        	LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
        	return;
        }
        LOGGER.AddCommunityUrl(commUrl);
        
		String html = U.getHTML(commUrl);
		U.log(U.getCache(commUrl));
		
		U.log("Count=: "+j);
		U.log("==>> "+url);
		
        // U.log("comSec::"+comSec);
		
		//======== Community Name=================
	
		String communityName = U.getSectionValue(comSec, "<h1 class=\"elementor-heading-title elementor-size-default\">", "<");
		if(communityName==null)communityName=U.getSectionValue(comSec, "<h4 class=\"elementor-heading-title elementor-size-default\">", "</h4>");
		communityName=communityName.replace("&#8211;", "-");
		//========== LatLng==============
		String geo = "False";
		String lat=Util.match(comSec, "data-lat=\\d+\\.\\d+");
		String lng=Util.match(comSec, "data-lng=-\\d+\\.\\d+");
		if(lat!=null) {
			lat=lat.replace("data-lat=", "");
		}
		
		if(lng!=null) {
			lng=lng.replace("data-lng=", "");
		}
		
		if(lat == null && lng == null){
			lat = U.getSectionValue(html, "data-lat='", "'");
			lng = U.getSectionValue(html, "data-lng='", "'");
		}
		if(lat==null && lng==null) {
			String latSec=U.getSectionValue(html, "lat&quot;:",",&quot;");
			if(latSec!=null)
			lat=Util.match(latSec, "\\d{2}\\.\\d{7}");
			String lngSec=U.getSectionValue(html, "lng&quot;:",",&quot;");
			if(lngSec!=null)
			lng=Util.match(lngSec, "[-]\\d{2}\\.\\d{7}");
			
			U.log("formatted lat n long iS "+lat+" "+lng);
		}
//		if(commUrl.contains("https://www.longlakeltd.com/neighborhood/champions-oak")) {
//			lat="44.564722";
//			lng="-93.326944";}
		String latlng[]= {lat,lng};
		
		U.log(lat +"           "+lng);
		//=============== address ===============
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String addsec=null;
        addsec=U.getSectionValue(comSec, "<h3 class=\"elementor-heading-title elementor-size-default\">","</h3>");
        addsec=addsec.replace("Drive Houston, Texas 77066", "Drive, Houston, Texas 77066, USA").replace(", USA","");
        U.log("1st addsec===="+addsec);
        U.log("1st addsec===="+addsec.length());

//        if((addsec.length()<30)||(addsec==null)) {
//		   addsec=U.getSectionValue(html, "<div><strong>US Post Office</strong></div>","<div><a");
//		//addsec=addsec.replaceAll("<div>|</div>","");
//		   if(addsec==null) {
//			   addsec=U.getSectionValue(html, "<div><strong>U.S. Post Office</strong></div>","<div><a");
//			}
//		U.log("2nd addsec"+addsec);
//		if(addsec!=null) {
//		addsec=addsec.replace("</div>\n<div>",",");
//		addsec=addsec.replaceAll("<div>|</div>","");
//		U.log("Formatted adrs sec2"+addsec);
//		}
//		}
		//15306 Crathie Bend Dr, Humble, TX 77346, USA
		//.contains("https://www.longlakeltd.com/neighborhood/eagle-landing")||.contains("https://www.longlakeltd.com/neighborhood/fairpark-village")||
//		if(commUrl.contains("https://www.longlakeltd.com/neighborhood/champions-oak")) {
//			add=U.getAddressGoogleApi(latlng);
//			if(add == null) add =U.getGoogleAddressWithKey(latlng);
//			geo="TRUE";
//			}
		
//		else {
			
//			addsec=addsec.replace("Texas", "TX");
//			 String []ads=addsec.split(",");
//			 add[0]=ads[0];
//			 add[1]=ads[1];
//			ads[2]= ads[2].trim();
//			 String ads1[]=ads[2].split(" ");
//			 add[2]=ads1[0];
//			 add[3]=ads1[1];
//			if(commUrl.contains(" https://www.longlakeltd.com/neighborhood/eagle-landing")) {
//			//add=U.getAddressGoogleApi(latlng);
//			add=U.getAddress(addsec);
//			latlng=U.getlatlongGoogleApi(add);
//			geo="TRUE";
//			}//date jan 2022
			if(addsec!=null)
			add=U.getAddress(addsec);
			if(commUrl.contains("https://www.longlakeltd.com/neighborhood/vanbrooke/")) {
				
				
				add[0]="32410 Hamilton Crest Court";
				add[1]="Fulshear";
				add[2]="TX";
				add[3]="77423";
//				latlng=U.getlatlongGoogleApi(add);
//				geo="True";
				
			}
			
			if(commUrl.contains("https://www.longlakeltd.com/neighborhood/marvida/")) {
				
				add[1]="Cypress";
				add[2]="TX";
				
				latlng=U.getlatlongGoogleApi(add);
				add=U.getAddressGoogleApi(latlng);
				geo="True";
				
			}
			
			
			
			add[0]=add[0].replace("2103 Avenue “G”", "2103 Avenue G");
			U.log("ADDRESSS "+add[0]+"   "+add[1]+"   "+add[2]+"   "+add[3]);
//		}
				
			//if(add!=null)
			if(lat==null|| lng==null){
				
				 latlng=U.getlatlongGoogleApi(add);
				
				lat=latlng[0];
				lng=latlng[1];
				geo="True";
				
			}
			
		//} 
//		if(commUrl.contains("https://www.longlakeltd.com/neighborhood/beacon-hill/")) {
//			add[0]="120 Firestone Court";
//			add[1]="Waller";
//			add[2]="TX";
//			add[3]="77484";
//			lat="30.0899726";
//			lng="-95.953029";
//			geo="True";
//		}
        
		//add=U.getAddressFromSec(addsec, "");
			
			
			if(add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && add[2]==ALLOW_BLANK && latlng[0]!=ALLOW_BLANK)
			{
				add=U.getAddressGoogleApi(latlng);
				geo="True";
			}
			
		
		U.log(add[0]+"   "+add[1]+"   "+add[2]+"   "+add[3]);
		U.log("Latlong "+latlng[0]+" "+latlng[1]);
		
	//	U.log("add::::"+Arrays.toString(add));
		
		//----------Remove header---------
		String remSection = U.getSectionValue(html, "<head>", "<div data-elementor-type=\"single\"");
		
		if(remSection==null)remSection = "";
		if(remSection != null){
					html = html.replace(remSection, "");
					U.log(":::::::::::remove Header Section:::::::::::");
			}
		
		
/*
		if(lat!=null) {
			lat=lat.replace("data-lat=", "");
		}
		else {
			String latla[]=U.getlatlongHereApi(add);
			lat=latla[0];
			lng=latla[1];
			geo="TRUE";
		}
		if(lng!=null) {
			lng=lng.replace("data-lng=", "");
			
		}
		else {
			String latla[]=U.getlatlongHereApi(add);
			lat=latla[0];
			lng=latla[1];
			geo="TRUE";
		}*/
		//============plans=-=========
		String homeHtml=ALLOW_BLANK;
		try {
		String planSec=U.getSectionValue(html, "<h2 class=\"elementor-heading-title elementor-size-default\">Plans</h2>","Inventory</h2>");
		if(planSec==null)planSec=U.getSectionValue(html, "<h2 class=\"elementor-heading-title elementor-size-default\">Plans</h2>","Schools</h2>");
		String[] planurl=U.getValues(planSec, "data-column-clickable=\"","\"");
		
		for (String string : planurl) {
		//	U.log("kkkkkkkkk"+string);
			if(string.length()<40)
			{
			String url1=string;
			U.log("planUrl=== "+url1);
			String planhtm = U.getHTML(url1).replace(remSection, "");
			String plansec = U.getSectionValue(planhtm, "<h1 class=\"elementor-heading-title elementor-size-default\">", "Neighborhoods featuring this plan</h3>");
			homeHtml+=plansec;
//			if(homeHtml.contains("264,990")) {
//				U.log("Found===");
//			}
			}
		}
		}
		catch(NullPointerException e) {}
		//inventroy Homes
		String homSec=U.getSectionValue(html, "<h2 class=\"elementor-heading-title elementor-size-default\">Inventory</h2>","Schools</h2>");
		if(homSec==null)homSec=U.getSectionValue(html, "<h2 class=\"elementor-heading-title elementor-size-default\">Inventory</h2>","<!--DCE VISIBILITY HIDDEN section");
		String[] hourl = {};
		if(homSec!=null) {
			hourl=U.getValues(homSec, "data-column-clickable=\"","\"");
			for (String string : hourl) {
			//	U.log("kkkkkkkkk:::"+string);
				if(string.length()>40 && string!=null)
				{
				String url1=string;
				U.log("url1=== "+url1);
	//			url1 = U.getRedirectedURL("https://www.longlakeltd.com/", url1);
				try {
				String homehtm = U.getHTML(url1).replace(remSection, "");
				String homeSec = U.getSectionValue(homehtm, "<h1 class=\"elementor-heading-title elementor-size-default\">", "<h3 class=\"elementor-heading-title elementor-size-default\">NEIGHBORHOOD</h3>");
				//U.log(homeSec);
				homeHtml+=homeSec;
				}catch(Exception e) {}
//				if(homeHtml.contains("264,990")) {
//					U.log("Found");
//				}
				}
			}
		}
		//floorplans
		
		
////		String planSec=U.getSectionValue(html, "Plans</h2>		</div>","Schools</h2>");
////		if(planSec==null)planSec=U.getSectionValue(html, "<h2 class=\"elementor-heading-title elementor-size-default\">Inventory</h2>","<!--DCE VISIBILITY HIDDEN section");
//		
//		String planHtml=ALLOW_BLANK;
//		String[] planSec=U.getValues(html, " style=\"cursor: pointer;\"","</article>");
//		if(planSec!=null) {	
//		for (String string : planSec) {
//			String planurl=U.getSectionValue(string,"clickable=\"", "\"");
//			//	U.log("kkkkkkkkk:::"+string);
////				if(string.length()>40 && string!=null)
//				{
//				String url1=string;
//				U.log("url1=== "+url1);
//	//			url1 = U.getRedirectedURL("https://www.longlakeltd.com/", url1);
//				String planhtm = U.getHTML(url1).replace(remSection, "");
//				String PlanSec = U.getSectionValue(planhtm, "<h1 class=\"elementor-heading-title elementor-size-default\">", "<h3 class=\"elementor-heading-title elementor-size-default\">NEIGHBORHOOD</h3>");
//				//U.log(homeSec);
//				planHtml+=PlanSec;
//				}
//			}
//		}
//		
//		
		//============ Prices =================
		
		
		comSec = comSec.replace("&#8217;s", "");
		homeHtml=homeHtml.replace(remSection,"");
		String minPrice =ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		//U.log(Util.matchAll(U.getNoHtml(homeHtml), "[\\w\\s\\W]{30}259,990[\\w\\s\\W]{30}", 0));
		homeHtml=homeHtml.replace("&ndash;", "�");
		html=html.replace("F.M. 1960 at Kuykendahl Rd. Homes from $231,990 to $296,990","");
		comSec=comSec.replace("F.M. 1960 at Kuykendahl Rd. Homes from $231,990 to $296,990","");
//		U.log("ppP"+Util.matchAll(comSec, "[\\s\\w\\W]{50}\\$240,000[\\s\\w\\W]{50}", 0));
		String[] Prices = U.getPrices(html.replace("0s", "0,000")+comSec+homeHtml,"<p>\\$\\d{3},\\d{3}</p>|low \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3} � \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}|from the mid-\\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|<div class=\"dce-token\">\\$\\d{3},\\d{3} &ndash; \\$\\d{3},\\d{3}</div>|class=dce-token>\\$\\d{3},\\d{3}|Starting in the \\$\\d+,\\d+|<span class=\"dce-token\">\\$\\d{3},\\d{3}</span>", 0);

		minPrice = (Prices[0] == null) ? ALLOW_BLANK : Prices[0];
		maxPrice = (Prices[1] == null) ? ALLOW_BLANK : Prices[1];
		U.log("minPrice:  " + minPrice + " maxPrice: " + maxPrice);
//		U.log(comSec);
		U.log("ppP"+Util.matchAll(homeHtml, "[\\s\\w\\W]{50}457[\\s\\w\\W]{50}", 0));

		
//		//============= SqFt ===================
//
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		html= html.replaceAll("</div></h3>\\s*</div>\\s*</div>\\s*<div class=\"elementor-element elementor-element-c089a8c elementor-widget elementor-widget-heading\" data-id=\"c089a8c\" data-element_type=\"widget\" data-widget_type=\"heading.default\">\\s*<div class=\"elementor-widget-container\">\\s*<div class=\"elementor-heading-title elementor-size-default\">SQ FT", " SQFT");
		homeHtml= homeHtml.replaceAll("</div></h3>\\s*</div>\\s*</div>\\s*<div class=\"elementor-element elementor-element-c089a8c elementor-widget elementor-widget-heading\" data-id=\"c089a8c\" data-element_type=\"widget\" data-widget_type=\"heading.default\">\\s*<div class=\"elementor-widget-container\">\\s*<div class=\"elementor-heading-title elementor-size-default\">SQ FT", " SQFT");


		String[] sqft = U.getSqareFeet(html+comSec+homeHtml,
				">\\d{4}</h3>|\"dynamic-content-for-elementor-acf \">\\d{4}</h3>|class=edc-acf>\\d{4}<|\\d{3,4} SQFT",0);
		//"<p>\\d{4} square feet</p>|<p>\\d,\\d{3} square feet</p>|Square feet:  \\d{4}|Sq. Ft.: \\d{4}|\\d,\\d{3} Sq.Ft|Base Sq. Ft.:\\s+\\d+|Sq. Ft.:\\s+\\d+<br />|Sq. Ft.: \\d{4} Beds|Sq. ft.:  \\d{3,4}|Sq. ft.:&nbsp; \\d{3,4}|<p>\\d,\\d{3} square feet", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
		
//		//=========plans
		
//		//========= Community Type ============
		html = html.replaceAll("miniature golf", "")
				.replace("features a peaceful lake view", "features a peaceful lakeside Community");
		String commType = U.getCommunityType(html);
//		
//
//		//====================== Property Status ===============
		String Status = ALLOW_BLANK;
		String remData = "<p>COMING SOON</p>|information on Beacon Hill coming soon|Splash Pad Now Open|COMING SOON!</a>|COMING SOON!\"|Cabin Day|wpb_wrapper\">\\s*<p>COMING SOON!</p>|wpb_wrapper\">\\s*<p>Coming Soon!</p>|more!! Ready|more!! ready|move in</b>|<b>ready to|Ready for Move In!|close out! only 3 homes left|CLOSE OUT!  ONLY 3 HOMES LEFT| CLOSE OUT &#8211; ONLY 2 HOMES LEFT!|Under Construction|under construction|<p>Coming soon!</p>|Grand opening photo 2|Grand-opening-photo";
		html = html.replaceAll(remData, "");
	//	U.log(Util.matchAll(html, "[\\w\\s\\W]{30}240[\\w\\s\\W]{30}",0));
		comSec=comSec.replace("\"bb_full\":\"Sold Out", "");
		//U.log(comSec);
		comSec=comSec.replace("information on Beacon Hill coming soon", "").replace("CLOSET OUT OPPORTUNITIES", "closeout opportunities")
				.replace("Cul-de-sac and oversized lots are available", "Cul-de-sac and oversized lots available");
		Status = U.getPropStatus(((comSec).replace("reational Park and Splash Pad Now Open!", "")+html.replace("New section with lake front lots open now!", "New section lake front lots open now!")).replace("now available!</p>", ""));
	//	Homesites now available
//			U.log(Util.matchAll(comSec+html, "[\\w\\s\\W]{30}now available[\\w\\s\\W]{30}",0));

		Status=Status.replace("Only A Few Homes Remain, Only A Few Homesites Remain", "Only A Few Homesites Remain");

/*		if(hourl.length> 0){
			if(Status == ALLOW_BLANK) Status = "Inventory Homes Available";
			else if(Status != ALLOW_BLANK) Status = Status + ", Inventory Homes Available";
		}*/
		
		if(Status.trim().length() < 2)
			Status=ALLOW_BLANK;
		U.log("Status ::"+Status);
		//=========== Property Type ================
		String Type = ALLOW_BLANK;
		html = html.replaceAll("</div></h3>\\s*</div>\\s*</div>\\s*<div class=\"elementor-element elementor-element-d43077b elementor-widget elementor-widget-heading\" data-id=\"d43077b\" data-element_type=\"widget\" data-widget_type=\"heading.default\">\\s*<div class=\"elementor-widget-container\">\\s*<h3 class=\"elementor-heading-title elementor-size-default\">STORY", " story");
		homeHtml = homeHtml.replaceAll("</div></h3>\\s*</div>\\s*</div>\\s*<div class=\"elementor-element elementor-element-d43077b elementor-widget elementor-widget-heading\" data-id=\"d43077b\" data-element_type=\"widget\" data-widget_type=\"heading.default\">\\s*<div class=\"elementor-widget-container\">\\s*<h3 class=\"elementor-heading-title elementor-size-default\">STORY", " story");
		html = html.replace("HOMEOWNER&#8217;S ASSOCIATION", "HOMEOWNER’S ASSOCIATION").replace("Home Owner's Association ", "HOMEOWNER’S ASSOCIATION").replaceAll("chinese-traditional|Traditional\\)\"|-traditional\"|(c|C)abin|(V|v)illage", "");
	//comSec.replace("Home Owner's Association", "Home")

		Type = U.getPropType((comSec+html+homeHtml).replaceAll("Villa Drive", ""));
		
		if(html.contains("<h2 class=\"elementor-heading-title elementor-size-default\">Home Owner's Association"))
			if(Type==ALLOW_BLANK)
				Type = "Homeowner Association";
			else if(!Type.contains("Homeowner Association"))
				Type += ", Homeowner Association";
		
		//================= Derived Community Type ===============
		String dType = ALLOW_BLANK;
		html = html.replaceAll("4 bedroom|42 inch oak|3 bedroom|Creek Ranch|creek ranch|creek-ranch|title='Montgomery Creek Ranch|title=\"montgomery creek ranch|3 br 2.5 bath|- ranch|Ranch", "");
		html = html.replaceAll("1 1/2 story|one and half story", "1.5 Story");
		
/*		String []st=U.getValues(html, "elementor-element elementor-element-fdd16d9 align-dce-center elementor-widget elementor-widget-dyncontel-acf", "</div></h3></div>");
		
		U.log(st.length);
		String sdf=null;
		for(String s:st) {
			if(s!=null) {
				s=s.replaceAll("class=edc-acf>1", "1 Story");
				s=s.replaceAll("class=edc-acf>2", "2 Story");
				s=s.replaceAll("class=edc-acf>3", "3 Story");
			}
			sdf+=s;
		}
		if(sdf == null) sdf = ALLOW_BLANK;*/
		dType = U.getdCommType(html+homeHtml.replaceAll("Pkwy N 3rd floor|history|historical|creek-ranch/|Creek Ranch|Cy-Ranch |cy-ranch|cyranch|cyranch|ranch</a>", "")+communityName);
		
		
		
//		if(communityName.contains("Ranch")) {
//			if(dType.length()<2) {
//				dType ="Ranch";
//			}else {
//				dType =dType+", Ranch";
//			}
//		}
		
		//data from image dt:24 jul 21
		//if(commUrl.contains("/neighborhood/beacon-hill/"))minPrice="$200,000";
//		//====== Notes ==============
		String notes = ALLOW_BLANK;
		notes = U.getnote(html+comSec);
        
		if(commUrl.contains("https://www.longlakeltd.com/neighborhood/champions-oak")) {Status+=", Homesites now available";}// Status+=", Homesites Now Available";}
		if(commUrl.contains("https://www.longlakeltd.com/neighborhood/eagle-landing/")) {minPrice="$240,000";}
		
		
		data.addCommunity(communityName, commUrl, commType);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace("14703 Freestone Plum Ct 14703 Freestone Plum Ct", "14703 Freestone Plum Ct").trim(), add[1].trim(), add[2].trim(), add[3].trim());
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(Type, dType);
		data.addPropertyStatus(Status);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
//	}catch(Exception e){}
	}
		j++;
	
	}
	
	
	public void commDetails(String url,String comSec) throws Exception {
//		if(j == 1)
	{
//		if(!url.contains("https://www.longlakeltd.com/montgomery-creek-ranch-postwood-homes/"))return;
		String commUrl = url;
		
        if (data.communityUrlExists(commUrl)){
        	LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
        	return;
        }
        LOGGER.AddCommunityUrl(commUrl);
        
		//commUrl = commUrl.replace("grand-oaks-cove", newChar);s
		String html = U.getHTML(commUrl);
		U.log(U.getHTML(commUrl));
		U.log(U.getCache(commUrl));
		
		U.log("Count=: "+j);
		U.log("==>> "+url);
		
		 U.log(comSec);
		
		//======== Community Name=================
		//String communityName = U.getSectionValue(html, "<h1 class=\"entry-title\">", " – ");
//		 comSec  =comSec.replace("<span style=\"color: #0000ff;\">", "").replace("&#8211; The Crossing", "The Crossing")
//				 .replace("&#8211; Cypress Green", "Cypress Green")
//				 .replaceAll("– The Reserve", "The Reserve");
		String communityName = Util.match(comSec, "<span style=\"color: #0000ff;\">(.*?) &#8211;",1);//U.getSectionValue(comSec, commUrl+"\">", " &#8211;");
		if(communityName!=null)
			communityName = communityName.replace("–", "-").replaceAll("<a style=\"color: #0000ff;\" href=\".*\">|<a href=\"https://www.longlakeltd.com/greensbrook-lake-ridge-builders/\"><span style=\"color: #0000ff;\">", "");
		U.log(communityName);
		if(communityName==null)
			communityName = Util.match(comSec,  "<a style=\"color: #0000ff;\" href=\".*\">(.*?) &#8211;",1);
		if(communityName!=null)
			communityName=U.getNoHtml(communityName);
		
		//----Community inventory price---------
		String comInventoryPrice = Util.match(html, communityName+" – (.*?)</a></h3></li>",1);
		
//		String rem=U.getSectionValue(html,"<meta charset=\"UTF-8\">","<div class=\"page-title-section\">");
//		html=html.replace(rem,"");
		//========== LatLng==============
		String geo = "False";
		String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
		String latLngSection = U.getSectionValue(html,"https://www.google.com/maps/embed?pb=", "2m3");
		U.log("ppppppppp"+latLngSection);
		if (latLngSection != null) {
					latlng[0] = U.getSectionValue(latLngSection, "!3d", "!");
					latlng[1] = U.getSectionValue(latLngSection, "!2d", "!3d");
		}
		else if(html.contains("https://www.google.com/maps/d/")){
			String mapHtml = U.getHTML(U.getSectionValue(html, "<iframe src=\"", "\""));
			latLngSection = U.getSectionValue(mapHtml, "1,1,[[null,[", "]");
			latlng = latLngSection.split(",");
			
		}
		U.log("latlng :: "+Arrays.toString(latlng));
		//=============== address ===============
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		html = html.replaceAll("</span></strong><br />|</strong> </span><br />|</span></strong><br />|</strong></span></p>|</span></strong></p>|</strong></span><span style=\"color: #000000;\">|</span></strong><br>", "</strong></span><br />");
		
		html=html.replace("Mobile", " Office ");
		//U.log(html);
		String addSec = U.getSectionValue(html, "</strong></span><br />", "Office");
		U.log("addSec :: "+addSec);
		
		if(url.contains("https://www.longlakeltd.com/balmoral-coming-soon/"))addSec = U.getSectionValue(html, "</span></strong>", "<strong>");
		//U.log(html);
		if(addSec == null)
			addSec = U.getSectionValue(html, "</strong></span><br />", "<strong>");
		U.log("MMMMMMMMMMMMMMM"+addSec);
		if(addSec == null)
			addSec = U.getSectionValue(html, "</span></strong>", "<strong>");
		U.log("SSSSSSSSSSSS"+addSec);
		if(addSec == null)
			addSec = U.getSectionValue(html, "<div class=\"clearboth\">", "Office");
		
		U.log("DDDDDDDDDDDDDD"+addSec);
		if(addSec == null)
			addSec = U.getSectionValue(html, "<p><span style=\"color: #000000;\">", "Office");
		
		if(addSec == null)
			addSec = U.getSectionValue(html, "<p><span style=\"color: #000000;\">", "Office");
		U.log("WWWWWWWWWWWWWWWW"+addSec);
		if(addSec == null)
			addSec = U.getSectionValue(html, "Builders and Briarwood Homes<br>", "<a href=");
		if(addSec == null)
			addSec = Util.match(html, "</strong>((.*?)<br>\\s*(.*?))<br>\\s*<strong>Office:",1);
		U.log("QQQQQQQQQQQQQQQQQQ"+addSec);
		if(addSec == null)
			addSec = Util.match(html.replace("<span style=\"color: #000000;\">", ""), "</span></strong>((.*?)<br>\\s*(.*?))</span><br>\\s*<strong>Office:",1);
		U.log("AAAAAAAAAAAA"+addSec);
		if(addSec == null)
			addSec = Util.match(html, "</span></strong>((.*?)<br>\\s*(.*?))<strong>&nbsp;</strong>",1);
		if(commUrl.contains("https://www.longlakeltd.com/vanbrooke-lake-ridge-builders-briarwood-homes-coming-soon/"))addSec = "5102 Indian Pine Lane,Fulshear, Texas 77441";
		
		//U.log("Sec=="+U.getSectionValue(html, "Featuring Lake Ridge Builders and Lakewood Homes", "<a href=\"https://www.google"));
		U.log("FFFFFFFFFFFF "+addSec);
		if(addSec != null){
			addSec = addSec.replaceAll("<span style=\"color: #000000;\">|<strong>|</span>|(.*?)Homes<br />", "")
					.replace("Dr,<br>", "Dr,");
		
			
			U.log("addSec=="+addSec);
			addSec=addSec.replaceAll("</strong>", "").replace("Texas", "TX").replace("(&nbsp; )<br>", ",")
					.replaceAll("<p><strong>Featuring Pride Builders<br />|aytha Curtis Sales Counselor|Featuring Pride Builders|Featuring Postwood Homes|Featuring Lake Ridge Builders|Featuring Briarwood Homes&nbsp;|Featuring Briarwood Homes and Postwood Homes|Featuring Pride Builders|Featuring Briarwood Homes and Postwood Homes|Featuring Lake Ridge Builders and Pride Builders", "");
			add =U.findAddress(addSec);
			U.log("Address is ::: "+Arrays.toString(add));
			if(add==null){
				add = new String[] {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			}
			add[1]=add[1].replace("TX City", "Texas City");
			add[0]=add[0].replaceAll("gaytha curtis sales counselor, |Gaytha Curtis Sales Counselor, , |Featuring Lake Ridge Builders","");
		}
		if(latlng[0]==null && add[0].length()>4){
			latlng = U.getBingLatLong(add);
			geo = "TRUE";
		}
		if(add[0].length()<4 && latlng[0].length()>4){
			add = U.getAddressGoogleApi(latlng);
			if(add == null)add = U.getAddressHereApi(latlng);
			geo = "TRUE";
		}
		
		if(commUrl.contains("https://www.longlakeltd.com/remington-creek-ranch/")){
			add = new String[]{"18310 W Hardy Rd","Houston","TX","77073"};
			latlng  = new String [] {"29.96772660000002","-95.390270699999"};
		}
		
		String homSec=U.getSectionValue(html, "vc_tta-tabs-list","</ul>");
		String[] hourl=U.getValues(homSec, "<a href=\"","\"");
		String homeHtml=ALLOW_BLANK;
		for (String string : hourl) {
			U.log("kkkkkkkkk"+string);
			if(string.length()<40)
			{
			String url1=commUrl+string;
		//	U.log("MMM "+url1);
//			url1 = U.getRedirectedURL("https://www.longlakeltd.com/", url1);
			homeHtml+=U.getHTML(url1);
			}
		}
		
		//----------Remove header---------
		String remSection = U.getSectionValue(html, "navbar-collapse themex-mainnavbar", "<div class=\"themex-section-top");
		if(remSection != null){
			html = html.replace(remSection, "");
			U.log(":::::::::::remove Header Section:::::::::::");
		}
		//============ Prices =================
		comSec = comSec.replace("&#8217;s", "");
		//homeHtml=homeHtml.replace(rem,"");
		html = html.replace("0s", "0,000");
		String minPrice =ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] Prices = U.getPrices(html+comSec+comInventoryPrice+homeHtml,"low \\$\\d{3},\\d{3}|from the mid-\\$\\d{3},\\d{3}|Starting in the \\$\\d+,\\d+| – \\$\\d+,\\d+|\\$\\d{3},\\d{3}</h4>", 0);

		minPrice = (Prices[0] == null) ? ALLOW_BLANK : Prices[0];
		maxPrice = (Prices[1] == null) ? ALLOW_BLANK : Prices[1];
		U.log("minPrice:  " + minPrice + " maxPrice: " + maxPrice);
		
		//============= SqFt ===================

		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		

		String[] sqft = U.getSqareFeet(html+comSec+homeHtml+comInventoryPrice+homeHtml,
				"<p>\\d{4} square feet</p>|<p>\\d,\\d{3} square feet</p>|Square feet:  \\d{4}|Sq. Ft.: \\d{4}|\\d,\\d{3} Sq.Ft|Base Sq. Ft.:\\s+\\d+|Sq. Ft.:\\s+\\d+<br />|Sq. Ft.: \\d{4} Beds|Sq. ft.:  \\d{3,4}|Sq. ft.:&nbsp; \\d{3,4}|<p>\\d,\\d{3} square feet", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
		
		
		//========= Community Type ============
		html = html.replaceAll("Cypresswood Golf|miniature golf", "");
		String commType = U.getCommunityType(html);
		

		//====================== Property Status ===============
		int inventoryHomeCount = 0;
		String inventoryHomeSec[] = U.getValues(homeHtml, "Inventory Homes</span></a></h4>", "Available Plans</span></a></h4>");
		
		if(inventoryHomeSec == null || inventoryHomeSec.length == 0)
			inventoryHomeSec = U.getValues(homeHtml, "Available Inventory</span></a></h4>", "Available Plans</span></a></h4>");
		
		if(inventoryHomeSec != null){
			for(String inv : inventoryHomeSec) {
			
			String [] inventoryUrlSection = U.getValues(inv, "<a class=\"vc_general", "</a>");
			inventoryHomeCount = inventoryUrlSection.length;
			U.log("inventoryHomeCount ::"+inventoryHomeCount);
			if(inventoryUrlSection.length>0) break;
			}
		}
		
		
		//====================== Available homes ===============
				int availableHomeCount = 0;
				String homeData = "";
				String availableHomeSec[] = U.getValues(homeHtml, "Available Plans</span></a></h4>", "Useful Information</span></a></h4>");
				
//				if(availableHomeSec == null || availableHomeSec.length == 0)
//					availableHomeSec = U.getValues(homeHtml, "Available Plans</span></a></h4>", "Useful Information</span></a></h4>");
				
			if (availableHomeSec != null) {
				for (String avl : availableHomeSec) {

					String[] availableUrlSection = U.getValues(avl, "<a class=\"vc_general", "</a>");
					availableHomeCount = availableUrlSection.length;

					if (availableHomeCount > 0) {

						for (String home : availableUrlSection) {

							String homeUrl = U.getSectionValue(home, "href=\"", "\"");

							try {
								 String hhHtml = U.getHTML(homeUrl);
								 homeData += U.getSectionValue(hhHtml, "<h1 class=\"entry-title\">", "<div class=\"tag-share-wrapper\">");
								 
							} catch (Exception e) {
								// TODO: handle exception
							}

						}
					}
					U.log("availableHomeCount ::" + availableHomeCount);
					if (availableUrlSection.length > 6)
						break;
				}
			}
		
		String Status = ALLOW_BLANK;
		String remData = "<p>COMING SOON</p>|COMING SOON!</a>|COMING SOON!\"|Cabin Day|wpb_wrapper\">\\s*<p>COMING SOON!</p>|wpb_wrapper\">\\s*<p>Coming Soon!</p>|more!! Ready|more!! ready|move in</b>|<b>ready to|Ready for Move In!|close out! only 3 homes left|CLOSE OUT!  ONLY 3 HOMES LEFT| CLOSE OUT &#8211; ONLY 2 HOMES LEFT!|Under Construction|under construction|<p>Coming soon!</p>|Grand opening photo 2|Grand-opening-photo";
		html = html.replaceAll(remData, "");
		
//		U.log(Util.match(html, ".*Coming Soon.*"));
		Status = U.getPropStatus((html+comSec));
		//U.log(Util.matchAll(comSec, "[\\w\\s\\W]{30}now open[\\w\\s\\W]{30}", 0));
		Status=Status.replace("Only A Few Homes Remain, Only A Few Homesites Remain", "Only A Few Homesites Remain");
		
		
		if(Status.trim().length() < 2)
			Status=ALLOW_BLANK;
		U.log("Status ::"+Status);
		
		if(inventoryHomeCount > 0){
			if(Status == ALLOW_BLANK) Status = "Inventory Homes Available";
			else if(Status != ALLOW_BLANK) Status = Status + ", Inventory Homes Available";
		}

		//=========== Property Type ================
		String Type = ALLOW_BLANK;
		html = html.replace("HOMEOWNER&#8217;S ASSOCIATION", "HOMEOWNER’S ASSOCIATION").replaceAll("chinese-traditional|Traditional\\)\"|-traditional\"|(c|C)abin|(V|v)illage", "");

			Type = U.getPropType(html+homeData);
		
		//================= Derived Community Type ===============
		String dType = ALLOW_BLANK;
		html = html.replaceAll("4 bedroom|42 inch oak|3 bedroom|Creek Ranch|creek ranch|creek-ranch|title='Montgomery Creek Ranch|title=\"montgomery creek ranch|3 br 2.5 bath|- ranch|Ranch", "");
		html = html.replaceAll("1 1/2 story|one and half story", "1.5 Story");
		dType = U.getdCommType(homeData+" 2 Story "+communityName+html.replaceAll("Pkwy N 3rd floor|history|historical|creek-ranch/|Creek Ranch|Cy-Ranch |cy-ranch|cyranch|cyranch|ranch</a>", ""));

		
		//====== Notes ==============
		html = html.replaceAll("now pre-selling!!!\" rel", "");
		if(latlng[0].length()<4)
		{
				latlng = U.getBingLatLong(add);
				geo="true";
		}
		
		if(commUrl.contains("https://www.longlakeltd.com/etteridge-humble-tx/")) minSqft= "2620";
		if(url.contains("https://www.longlakeltd.com/vanbrooke-lake-ridge-builders-briarwood-homes-coming-soon/"))dType = dType +", 1 Story";
		if(url.contains("https://www.longlakeltd.com/villages-of-cypress-lakes-the-reserve/"))Type = "Executive Style Homes";
		
		if(url.contains("https://www.longlakeltd.com/balmoral-coming-soon/")) { 
			add[0] = "15306 Crathie Bend Drive";
			add[2] = "TX";
			add[3] = "77346";
		}
		String notes = ALLOW_BLANK;
		notes = U.getnote(html+comSec);

        U.log(Arrays.toString(add));
        
		data.addCommunity(communityName, commUrl, commType);
		data.addLatitudeLongitude(latlng[0], latlng[1], geo);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].replace(",", ""), add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addPropertyType(Type, dType);
		data.addPropertyStatus(Status);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
	}
	j++;
	}
}