/**
 * @author Upendra Singh 
 * @date 27/01/2017
 * 
 */
package com.shatam.b_281_300;

import java.io.IOException;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMcBeeHomes extends AbstractScrapper{
	static int j=0;
	static int k=0;
	CommunityLogger LOGGER;

	public ExtractMcBeeHomes()
			throws Exception {
		super("McBee Homes","https://mcbeehomes.com");
		// TODO Auto-generated constructor stub
		LOGGER=new CommunityLogger("McBee Homes");
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a=new ExtractMcBeeHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"McBee Homes.csv", a.data().printAll());
		U.log("Total-->"+j);
		U.log("Repeated-->"+k);

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml=U.getHTML("https://mcbeehomes.com/");
		String section=U.getSectionValue(mainHtml, "<section class=\"gb-block-post-grid featuredpage aligncenter\">","</section>");
		U.log(section);
		String[] comData=U.getValues(section, "<h3 class=\"gb-block-post-grid-title\">","</h3>");
		U.log(comData.length);
		for(String com:comData)
		{	
//			U.log(city);
//			String[] comSec=U.getValues(city, "<li id=\"menu-item","</li>");
//			for(String comData:comSec)
//			{
				//U.log(comData);
				String comUrl=U.getSectionValue(com, "<a href=\"","\"");
				U.log("comUrl::::::"+comUrl);
				adddetails(comUrl,com);
//			}
				//break;
		}
		LOGGER.DisposeLogger();
	}

	private void adddetails(String comUrl, String comData) throws Exception {
//		if(!comUrl.contains("https://www.mcbeehomes.com/university-hills/"))return;
		
//	try{
	{
		U.log(j+"   commUrl-->"+comUrl);
		String html=U.getHTML(comUrl);

		//============================================Community name=======================================================================
				
				String communityName=U.getSectionValue(comData, "rel=\"bookmark\">","</a>").replace("- CLOSE OUT SPECIALS &#8211; CALL TODAY!", "");
				communityName=communityName.replace("Willow Vista Estates", "Willow Vista")
						.replace("North Oaks Estates", "North Oaks");
				U.log("community Name---->"+communityName);
				
		//================================================Address section===================================================================
				
				String note=ALLOW_BLANK;
				String addSec=U.getSectionValue(html, "https://www.google.com/maps/embed?pb","\"");
				String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
				String[] latlag={ALLOW_BLANK,ALLOW_BLANK};
				String geo="FALSE";
				
				
				U.log(addSec);
				if(addSec!=null)
				{
					String latSec=U.getSectionValue(addSec, "!2d","!3m");
					String[] ll=latSec.split("!3d");
					latlag[0]=ll[1];
					latlag[1]=ll[0];
					String addS=U.getSectionValue(addSec, "!2s", "!5e");
					U.log(addS);
					
					addS=addS.replaceAll("%2C", ",").replaceAll("%20", " ");
					U.log(addS);
					add=U.getAddress(addS);
					//Latlong
					
					//701%20Fossil%20Wood%20Dr%2C%20Fort%20Worth%2C%20TX%2076179
					
				}
				if(comUrl.contains("university-hills")){
					add[0]="2104 Pepperdine Dr";
					add[1]="Weatherford";
					add[2]="TX";
					add[3]="76088";
				}
				latlag[0]=latlag[0].replaceAll("!2m3!1f0!2f0!3f0", "");
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);

				
		//--------------------------------------------------latlng----------------------------------------------------------------
				
//				String latSec=U.getSectionValue(html, "linkd\":\"\",\"" , ",\"anim\"");
			

//				if(latSec!=null)
//				{
//					latlag[0]=Util.match(latSec,"\\d{2,3}[.]{1}\\d+");
//					latlag[1]=Util.match(latSec,"-\\d{2,3}[.]{1}\\d+");
//				}
				
				if(latlag[0].length()<4 && add[0].length()<4){
					latlag[0]=U.getSectionValue(html, "\"map_start_lat\":\"", "\""); 
					latlag[1]=U.getSectionValue(html, "\"map_start_lng\":\"", "\"");
				}
				
				if(latlag[0]!=null)
					latlag[0] = latlag[0].replaceAll("!\\dm\\d!\\df\\d!\\df\\d!\\df\\d", "");
				
				U.log("hhhh--->"+latlag[0]+"  "+latlag[1]);
				
				if(add[1]!=ALLOW_BLANK && latlag[0]==ALLOW_BLANK)
				{
					latlag=U.getlatlongGoogleApi(add);
					if(latlag == null) latlag = U.getlatlongHereApi(add);
//					latlag=U.getBingLatLong(add);
					
					geo="TRUE";
				}
				if((add[0].length()<2 ||add[2]==null)&& latlag[0]!=ALLOW_BLANK)
				{
					add=U.getAddressGoogleApi(latlag);
					if(add == null) add = U.getAddressHereApi(latlag);
					geo="TRUE";
				}
				if(add[3]==null && latlag[0]!=ALLOW_BLANK)
				{
					String[] add1 =U.getAddressGoogleApi(latlag);
					if(add1 == null) add1 = U.getAddressHereApi(latlag);
					
					add[3]=add1[3];
					add1 = null;
					geo="TRUE";
				}
				
				
				U.log("hhhh1--->"+latlag[0]+"  "+latlag[1]);
				
				
				//==================== Available Homes =====================
//				String availableHomeHtml = U.getHTML("https://mcbeehomes.com/available-homes-2/");
//				String availableSec = U.getSectionValue(html, "<div class=\"es-thumbnail\">", "</a>");
				String combinedAvailableHomes = null;
//				if(availableSec != null){
					//availableSec = availableSec.replaceAll("<a href=\"", "\"");
					String availableHomes[] = U.getValues(html, "<div class=\"es-thumbnail\">", "</ul>");
					U.log("LENGTH: "+availableHomes.length);
					for(String availableHome :  availableHomes){
//						U.log(availableHome);

						availableHome = U.getSectionValue(availableHome, "<a href=\"", "\"");
						U.log("AvailableHome: "+availableHome);
						if(availableHome.startsWith("http"))
							combinedAvailableHomes += U.getSectionValue(U.getHTML(availableHome), "<section class=\"ftco-section\">", "</section>")+
							U.getSectionValue(U.getHTML(availableHome), "<ul>", "</ul>");
					}
//				}
				
		//============================================Price and SQ.FT======================================================================
				

				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
				html=html.replaceAll("0�s|0's|0&#8217;s|0s|0k's|0k","0,000").replace("$1 million","$1,000,000");
				
				comData=comData.replaceAll("0&#8217;s|0�s|0's|0s","0,000");
				
				if(combinedAvailableHomes!=null)
					combinedAvailableHomes = combinedAvailableHomes.replaceAll("Price: </strong>\n\\s*|Price: </strong><br />\n\\s*|<strong>Price: </strong>\r\n\\s*", "Price:");
				
				String prices[] = U.getPrices(html+comData+combinedAvailableHomes,"Price: \\$ \\d{3},\\d{3}|Price:\\$ \\d{3},\\d{3}|From the \\$\\d{3},\\d+|From the \\d{3},\\d+|the low \\d{3},\\d+|price\">\\$\\d{3},\\d{3}", 0);
			
				minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
				maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
				
				U.log("Price--->"+minPrice+" "+maxPrice);
				
		//======================================================Sq.ft===========================================================================================		
				String[] sqft = U
						.getSqareFeet(
								html+comData,
								"\\d{4} Sq.Ft.",
								0);
				//"\\d{4}[.]jpg|\\d{4}[.]png|\\d{4}fp[.]jpg|\\d{4}-Floor-plan.png|\\d{4}-Tile.png|\\d{4} Floor Plan"
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("SQ.FT--->"+minSqft+" "+maxSqft);
				
	
		
		//================================================community type========================================================
	
				String communityType=U.getCommType(html+comData);
				
		//==========================================================Property Type================================================
				
				if(combinedAvailableHomes!=null)
					combinedAvailableHomes = combinedAvailableHomes.replaceAll("Floors: </strong><br />\n\\s*1", " Story 1 ");
				String proptype=U.getPropType((html+comData+combinedAvailableHomes).replace("condominium.png", ""));
				
		//==================================================D-Property Type======================================================
			String flourls[]=U.getValues(html, "<span class=\"es-read-wrap\">", "</a>");
			String fsec="",fsec1="";
			for(String fu:flourls) {
				U.log(fu);
				String furl=U.getSectionValue(fu, "<a href=\"", "\"");
				String f=U.getSectionValue(U.getHTML(furl), "<div class=\"a2a_kit es-share-wrapper\"", "<div class=\"es-tabbed\">").replace(" ", "");
				
				//U.log(f);
				fsec+=f;
				
				String floors[]=U.getValues(fsec, "<li><strong>Floors:</strong>", "</li>");
			
				for(String fl:floors) {
					
					fl=fl.replace("1", "1 Story").replace("2", "2 Story");
					fsec1+=fl;
				}
				
				
				
				
				}
		
			
				html=html.replace("Stories <span class=\"value\">", "Story ").replaceAll("The Ranch at Eagle Mountain</a>|Red Eagle Ranch</a></li>", "");
				String dtype=U.getdCommType((html.replaceAll("ranch|Ranch","")+fsec1+comData+comUrl+combinedAvailableHomes).replace("2 Floors", "2 Story").replace("1 Floors", "1 Story"));
				
		//==============================================Property Status=========================================================
				html = html.replace("Phase II  &#8211;  SOLD OUT", "Phase II SOLD OUT")
						.replaceAll("will be sold out quickly", "")
						.replace(" &#8211; ", " ").replace("University Hills- CLOSE OUT", "").replace(" <h5>(coming soon!)</h5>", "");
				html=html.replace("<p>COMING SOON", "");
				String pstatus=U.getPropStatus(html.replace("NOW SELLING &#8211; NEW PHASE", "NOW SELLING NEW PHASE")+comData).replace("Ii", "II");
//				 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}", 0));
				if(communityName.contains("Estates"))
					if(proptype==ALLOW_BLANK)
						proptype = "Estate-Style Homes";
					else
						proptype += ", Estate-Style Homes"; 
				
//				if(comUrl.contains("/location/scenic-wood/"))pstatus="Quick Move-in Homes";
//				U.log(U.getHTML(comUrl).contains("<span class=\"icon-search2\"></span>"));
		//============================================note====================================================================
				if(data.communityUrlExists(comUrl))
				{
					LOGGER.AddCommunityUrl(comUrl+"*********repeated***********");
					k++;
					return;
				}
				LOGGER.AddCommunityUrl(comUrl);
				add[2]=add[2].toUpperCase();
				add[2]=add[2].replace(",","").trim();
				
				if(comUrl.contains("estates")) {
					if(proptype==ALLOW_BLANK)proptype="Estate Style Homes";
				}
				if(comUrl.contains("https://www.mcbeehomes.com/location/crown-valley-estates/"))communityType = "Golf Course";
				
				U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
					data.addCommunity(communityName,comUrl, communityType);
					data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(),geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(proptype, dtype);
					data.addPropertyStatus(pstatus);
					data.addNotes(note); 
					data.addUnitCount(ALLOW_BLANK);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK); 
	}
	j++;
//	}catch(Exception e){}
	}

}