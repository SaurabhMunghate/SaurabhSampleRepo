package com.shatam.b_281_300;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRoyalOaksBuildingGroup extends AbstractScrapper {
	static int j=0;
	static int k=0;
	static String BASEURL = "http://www.royaloakshomes.com";
	CommunityLogger LOGGER;
	HashMap<String, String> pricceList = new HashMap<String, String>();
	static int i;
	WebDriver driver = new FirefoxDriver();;

	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractRoyalOaksBuildingGroup();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Royal Oaks Building Group.csv", a
				.data().printAll());
	}

	public ExtractRoyalOaksBuildingGroup() throws Exception {

		super("Royal Oaks Building Group", BASEURL);
		LOGGER = new CommunityLogger("Royal Oaks Building Group");
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub


		
		String baseHtml = U.getHTML(BASEURL);
		String section = U.getSectionValue(baseHtml, "class=\"nav-page-content\"><div","</a></li></ul>");
		String urlsection[] = U.getValues(section, "href=\"", "\">");
		for (String sec : urlsection) {
		//	U.log(sec);
		//	String url = U.getSectionValue(sec, "href=\"", "\"");
			String url=BASEURL+sec;
			//U.log(url);
			String html=U.getHtml(url, driver);
		
			//	U.log(html);
		//	String sec1=U.getSectionValue(html, "<div ng-controller=\"CommunitiesController\"","div><a class=\"narrow-results-btn\"");
			String[] regionName = U.getValues(html, "<h4><a","<li ng-controller=");
			String[] urls={
					"http://www.royaloakshomes.com/new-homes-raleigh/apex/rileys-pond",
					"http://www.royaloakshomes.com/new-homes-raleigh/apex/townes-at-bella-casa",
					"http://www.royaloakshomes.com/new-homes-raleigh/cary/fairview-park",
					"http://www.royaloakshomes.com/new-homes-raleigh/clayton/bristol",
					"http://www.royaloakshomes.com/new-homes-raleigh/clayton/portofino",
					"http://www.royaloakshomes.com/new-homes-raleigh/fuquay-varina/atkins-village",
					"http://www.royaloakshomes.com/new-homes-raleigh/fuquay-varina/grays-creek",
					"http://www.royaloakshomes.com/new-homes-raleigh/fuquay-varina/sonoma-springs",
					"http://www.royaloakshomes.com/new-homes-raleigh/garner/the-landing-at-heather-park",
					"http://www.royaloakshomes.com/new-homes-raleigh/holly-springs/ballentine-place",
					"http://www.royaloakshomes.com/new-homes-raleigh/knightdale/rockbridge",
					"http://www.royaloakshomes.com/new-homes-raleigh/raleigh/stonehenge-manors",
					"http://www.royaloakshomes.com/new-homes-raleigh/wendell/wendell-falls"
					};
			
			for(String s:regionName)
			{
				
				String	url1 = BASEURL +U.getSectionValue(s,"href=\"", "\"");
				U.log("url1:::"+url1);
		
		//		regionDetails(url1);
				addCommunityDetails(urls[k], s);
				k++;
			}
		}

		LOGGER.DisposeLogger();
		driver.close();
	}


		
		
	
	
	
//  ========================New Code Upendra=============================

	
	public void addCommunityDetails(String url, String sec2)throws Exception {
//	if(j==4)
		{
			//if(!url.contains("http://www.royaloakshomes.com/new-homes-raleigh/fuquay-varina/grays-creek"))return;
//			if(url.contains("http://www.royaloakshomes.com/new-homes-raleigh/apex/bella-casa-parkside"))return;
//			if(url.contains("http://www.royaloakshomes.com/new-homes-raleigh/clayton/chandlers-ridge"))return;
			U.log(U.getCache(url));
			String html = U.getHtml(url, driver);
			U.log(sec2);
//----------------------------------------------------Community Name------------------------------------------------------
//		String commName = U.getSectionValue(sec2,"\">", "</a>");
			String commName = U.getSectionValue(html, "name\":\"", "\"");
			U.log(j+"::"+commName);
			
//-------------------------------------------------Address-Section----------------------------------------------------------
			String geo="FALSE";
			String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String latlan[]={ALLOW_BLANK,ALLOW_BLANK};
			String latsec=U.getSectionValue(sec2,"http://maps.google.com/?q=","\"");
			latlan=latsec.split(",");
			add[1]=U.getSectionValue(sec2,"<span class=\"ng-binding\">","</span>");
			add[2]=U.getSectionValue(sec2, "class=\"ng-binding ng-scope\">", "</span>");
			if(html.contains("<li ng-if=\"communi.address.streetAddress\" class=\"ng-binding ng-scope\">"))
			{
				add[0]=U.getSectionValue(html,"<li ng-if=\"communi.address.streetAddress\" class=\"ng-binding ng-scope\">","<");
				add[1]=U.getSectionValue(html,"<li ng-if=\"communi.address.addressLocality\" class=\"ng-binding ng-scope\">","<");
				add[2]=U.getSectionValue(html,"communi.address.addressRegion\" class=\"ng-binding ng-scope\">","<");
				add[3]=Util.match(add[2],"\\d{4,5}");
				add[2]=add[2].replace(add[3],"").replace(",","").trim();
			}
			U.log("hello---->"+add[0]);
			if(add[0].length()<4 && latlan[0].length()>4)
			{
				add=U.getAddressGoogleApi(latlan);
				geo="TRUE";
			}
//-----------------------------------------------Price-Section--------------------------------------------------------------------
		//	html=html.replaceAll("1,379","");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		//	String homesec=ALLOW_BLANK;
			String HHtml="";
			if(j!=4)
			{
				if(html.contains("</lightbox>") && html.contains("<div class=\"lightbox\">"))
				{
					//U.log(html);
					
					String[] homesec=U.getValues(html, "</lightbox>","<div class=\"lightbox\">");	
					for(String s:homesec)
					{					
					String urlH=U.getSectionValue(s,"<a href=\"","\"");
					if(urlH==null){
						urlH=U.getSectionValue(s,"<a title=\"\" ng-href=\"","\"");
						
					}
							if(urlH!=null)
							{
							urlH =	BASEURL+urlH.replace("&amp;", "&");
							HHtml=HHtml+U.getHtml(urlH, driver);
							}
						
						U.log(urlH+"  kkk");
						//<a title="" ng-href="/page.php?p=15&amp;com=5728cea5371e2f433a7ef7b2&amp;mod=5728cece371e2f433a7ef802" href="/page.php?p=15&amp;com=5728cea5371e2f433a7ef7b2&amp;mod=5728cece371e2f433a7ef802"><h4 class="ng-binding">The Belmont</h4></a><div class
					}
					}
					
		}
			
		String moveHtml=ALLOW_BLANK;
		if(html.contains("Plan:")){
			U.log("Hello");
			String[] moveUrls =U.getValues(html, "Plan: <a href=\"", "\"");
			U.log(moveUrls.length);
			for(String moveUrl:moveUrls){
				U.log(BASEURL+moveUrl);
				moveHtml=U.getHtml(BASEURL+moveUrl, driver);
			}
		}
		
		String readyHomeHtml=ALLOW_BLANK;
		
		if(html.contains("ng-binding\"><span>Homes</span>")){
			U.log("Hello Ready");
			String[] readyUrls=U.getValues(html, "<div class=\"result-content\"><a title=\"\" ng-href=\"", "\"");
			//U.log(readyUrls[0]);
			for(String readyUrl:readyUrls){
				readyUrl=BASEURL+readyUrl.replaceAll("&amp;", "&");
				readyHomeHtml=U.getHtml(readyUrl,driver )+readyHomeHtml;
				U.log("readyUrl::"+readyUrl);
			}
		}
		
			String remove=U.getSectionValue(html, "Communities</h4>","<h3><span>Map");
			if(remove!=null)
			html=html.replace(remove,"");
			sec2=sec2.replaceAll("0s","0,000").replace("9's","9,000");
			sec2=sec2.replaceAll("s|S",",000");
			html=html.replaceAll("0’s","0,000");
			
			String[] price = U.getPrices(html+sec2,
					"From the \\$\\d+,\\d{3}|Price: \\$\\d+,\\d{3}</li>|\\$\\d+,\\d{3}</li>|Price: \\$\\d+,\\d+|from the mid \\$\\d+,\\d+|>\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log(minPrice+" "+maxPrice);
			
			
			//-----------------------------------------------Squre-Fit-Section---------------------------------------------------------------

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U
					.getSqareFeet(
							html+sec2,
							"\\d+,\\d{3} Sq Ft</li>|\\d+,\\d{3} to \\d+,\\d{3} square feet|from \\d+,\\d{3}-\\d+ sq ft|range from \\d+,\\d+-\\d+,\\d+ square feet|<br />\\d+,\\d{3} Sq Ft|2,444 Sq Ft|\\d{1},\\d+ Sq Ft|about \\d{4} to over \\d{4} square feet",
							0);
			minSqf=sqft[0];
			maxSqf=sqft[1];
			//U.log(sec2+"kk");
			U.log(minSqf+" "+maxSqf);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			//-----------------------------------------------Community-Type-----------------------------------------------------------------
		String	communitytype=U.getCommunityType(html.replaceAll("GatedResidenceCommunity", ""));
		
//-----------------------------------------------PropType--------------------------------------------------------------------------
		//+moveHtml+HHtml
		String proptype=U.getPropType(html);
		
//-----------------------------------------------D-Prop-Type------------------------------------------------------------------------
		String dtype=U.getdCommType((HHtml+html+moveHtml+readyHomeHtml).replaceAll("Ranch|ranch",""));
		
//----------------------------------------------Status--------------------------------------------------------------------------------
		String propstatus=U.getPropStatus(html.replaceAll("Move-in ready:|Quick Move-In</a>|Quick Move-In Homes</div>|Quick Move-In</div>|basement homesites available",""));
		
		if(html.contains("<span>Quick </span>")){
			if(propstatus.length()<3){
				propstatus="Quick Move-In Homes";
			}
			else{
				propstatus=propstatus+",Quick Move-In Homes";
			}
		}
			
			LOGGER.AddCommunityUrl(url);
			
			
			// adding in csv
			if(data.communityUrlExists(url))
			{
				return;
			}
			data.addCommunity(commName, url, communitytype);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latlan[0].trim(), latlan[1].trim(), geo);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(propstatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(U.getnote(html));
		}
			j++;
		}
		
}