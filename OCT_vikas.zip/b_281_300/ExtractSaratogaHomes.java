/** @Author Parag Humane
 * @Date 5/7/2013
 * @Mofify By Sawan
 * @date 23 Oct 2019
 */
package com.shatam.b_281_300;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.net.Proxy;


import javax.swing.text.html.HTML;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSaratogaHomes extends AbstractScrapper {
	// int i=0;
	public int inr = 0;
	static int j = 0;
	static ArrayList<String> latLongList = new ArrayList<String>();
	WebDriver driver = null;
	CommunityLogger LOGGER;

	private static final String builderUrl = "https://saratogahomestexas.com";
	
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractSaratogaHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Saratoga Homes.csv", a.data().printAll());
	}

	public ExtractSaratogaHomes() throws Exception {

		super("Saratoga Homes", builderUrl);
		LOGGER = new CommunityLogger("Saratoga Homes");
	}

//	static String proxyIp = "162.144.106.161";
//	static int port  = 3838;
	public void innerProcess() throws Exception {

		int count = 0;

//		U.setUpChromePath();
//		ChromeOptions options = new ChromeOptions();
//		options.addExtensions (new File("/home/shatam12/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
//		// Proxy proxy = new Proxy();
//		 DesiredCapabilities capabilities = new DesiredCapabilities();
//		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
//		 driver = new ChromeDriver(capabilities);
		 
		String html = U.getHtml(builderUrl, driver);
//		String html =getHTM(builderUrl);


		String section = U.getSectionValue(html, "Find Your Home</div>", "</ul>");
		//String [] regUrls = U.getValues(section, "<a href=\"", "\"");
		String[] regUrlSection = U.getValues(section, "<li class=\"sidebar-nav__block\">", "</a>");
		for(String regUrlSec : regUrlSection){
//			regUrlSec=regUrlSec;
			String regUrl = U.getSectionValue(regUrlSec, "href=\"", "\"");
			U.log("===============\n"+regUrlSec);
			U.log("regUrl ::"+regUrl);
			String regHtml = U.getHtml(regUrl, driver);
//			String regHtml = getHTM(regUrl);

			String[] comSections = U.getValues(regHtml, "<li class=\"grid__item regions__community animated", "</a>");
			U.log("com. Count :"+comSections.length);
			
			String regionName = U.getSectionValue(regUrlSec, "brick-link-bottom\">", "</span>");
			U.log(regionName);
//			String regionNumberSection = U.getSectionValue(regHtml, "<select name=\"selected_regions", "</select>");
//			if(regionName!=null) {
//			String regionNumber = Util.match(regionNumberSection, "<option value=\"(\\d)\">"+regionName.trim()+"</option>", 1);
			regionName=regionName.toLowerCase().replace("el paso", "el-paso");
			U.log("regionName: "+regionName);
			String quickUrl = "https://saratogahomestexas.com/regions/"+regionName+"/quick-move-ins";
			U.log("QuickUrl :"+quickUrl);
//			String quickHtml = U.getHtml(quickUrl,driver);
			String quickHtml =getHTM(quickUrl);

			quickHtml = StringEscapeUtils.unescapeJava(quickHtml);
			if(quickHtml!=null) {
				quickHtml=quickHtml.replace("&lt;", "<").replace("&gt;", ">");
			}
		//
		//	U.log(quickHtml);
			String quickHomeSection[] = U.getValues(quickHtml, "<div class=\"qmi-card__detail", "clazy-load>");//"<div class=\"cta__text\">");
			U.log(quickHomeSection.length);
			
			
			for(String comSec : comSections){
				String comUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
//				U.log("comUrl : "+comUrl);
				
				if(!comUrl.startsWith("http")) comUrl = builderUrl + comUrl;
				U.log(">>>>>>> comUrl : "+comUrl);
//				U.log("count : "+count);
//				count++;
				extractCommunityDetails(comUrl, comSec, quickHomeSection);
			}
		}
//		}
//		try{driver.quit();}catch (Exception e) {}
		LOGGER.DisposeLogger();
	}

	private static String priceRegex[] = {"Price: \\$\\d{3},\\d{3}",
			"(mid|low|upper|the) \\$\\d{3},\\d{3}",
			"price\">Price:(&nbsp;|\\s)\\$\\d{3},\\d{3}</p>|Homes from the \\$\\d{3},\\d{3}"
	};
	
	private static String sqftRegex[] = {
			"Floor plans range from \\d,\\d{3} SQ.FT- \\d,\\d{3} SQ.FT",
			"snap\">(\\d,\\d{3}\\s?-\\s?)?\\d,\\d{3} Sq\\.Ft\\.",
			"range from \\d,\\d{3} sq\\.ft\\.\\s?(-|–)\\s?\\d,\\d{3} sq\\.\\s?ft\\.|\\d,\\d{3} sq.ft. - \\d,\\d{3} sq. ft",
			"class=\"sqft\">\\d,\\d{3} Sq. Ft.</li>"
	};
	
	//TODO : Extract Community Details here
	private void extractCommunityDetails(String comUrl, String comSec, String quickHomeSection[]) throws Exception {
//	try{
//		if(j>=6)
	{
		
		U.log("Count ::"+j);
		U.log(comUrl);
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl + "----------------- Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		
//		if(!comUrl.contains("https://saratogahomestexas.com/new-home-communities/houston/rodeo-palms"))return;
		
		
//		String html = U.getHtml(comUrl,driver);
		String html = getHTM(comUrl);
//		U.log("html ::"+html);
		
		//=========== Community Name ==============
		String comName = U.getSectionValue(comSec, "community-card__title\">", "</span>");
		U.log("comName ::"+comName);
		
		//============== Note ===============
		String notes = U.getnote(html);
		
		//=========== Address ==============
		String[] add = {ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		String geo = "False";
		String addSec = U.getSectionValue(html, "<div class=\"community-contact__address-section\">", "MAP</a>");
		U.log("addSec ::"+addSec);
		
//		if(addSec != null) {
//			addSec = U.getSectionValue(addSec, "</p><br />", "<a");
//			U.log("addSec ::"+addSec);
//		}
		//exception in this community
		if(addSec.contains(" Socorro, TX 79927"))
				addSec = U.getSectionValue(html, "office at ", " or");
		
		//U.log("addSec ::"+addSec);
		if(addSec != null && addSec.contains("COMING")) {
			addSec = U.getSectionValue(html, "</p><br />", "&nbsp;&nbsp;");
			if(addSec!= null)
				addSec = addSec.replaceAll("<br />", ",");
		//	U.log("MMMMMMMMMMMM "+addSec);
		}
		if(addSec != null)
			addSec = U.getSectionValue(addSec, " center=\"", "\"");
		if(addSec != null){
			addSec = addSec.replace("12464 Chamberlain,", "12464 Chamberlain Drive,");
			add = U.getAddress(addSec);
		}
		if((add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK) || comUrl.contains("/el-paso/valley-creek")){
			addSec = U.getSectionValue(html, "Visit our sales office at", "or call");
			if(addSec != null){
				add = U.getAddress(addSec);
			}
		}

		U.log("addSec ::"+addSec);
		U.log("Add :"+Arrays.toString(add));
		
		//============= Lat-Lng ===================
		String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
		latLng[0] = U.getSectionValue(html, "latitude\":", ",");
		latLng[1] = U.getSectionValue(html, "longitude\":", "}");
		U.log("Lat-Lng ::"+latLng[0]+"\t"+latLng[1]);
		
		if(add[0] == ALLOW_BLANK && add[3] != ALLOW_BLANK && (latLng[0] != ALLOW_BLANK || latLng[0] != null)){
			String[] add1 = U.getAddressGoogleApi(latLng);
			if(add1 == null) add1 = U.getAddressHereApi(latLng);
			add[0] = add1[0];
			geo = "True";
		}
		if(comUrl.contains("/houston/townsen-landing")) geo ="True";
		
		//Distance Exceed
		if(comUrl.contains("/el-paso/valley-creek")){
			latLng = U.getlatlongGoogleApi(add);
			if(latLng == null) latLng = U.getlatlongHereApi(add);
			U.log(Arrays.toString(latLng));
		}
		
		//=========== Quick-Move In Ready ====================
		String combinedQuickHome = null;
		int quickCount = 0;
		for(String quickSec : quickHomeSection){
			String comNameOfQuickHome = Util.match(quickSec, "<a href=\"/new-home-communities/.*\">(.*?)</a>", 1);
			
			if(comNameOfQuickHome != null && comName.equalsIgnoreCase(comNameOfQuickHome.trim())){
				combinedQuickHome += quickSec;
				quickCount++;
			}
		}
		
	 //======= Quick Details ==========
		if(combinedQuickHome == null)
			combinedQuickHome = "";
		String[] quickUrls = U.getValues(combinedQuickHome, "<a href=\"tel", "class=\"cta cta--secondary");
		String quickData = "";

		for(String quickUrl : quickUrls) {
	
			try {
				String qurl = "https://saratogahomestexas.com"+U.getSectionValue(quickUrl, "href=\"", "\"");
				U.log("Quick URL:" + qurl);
				String quickHtml = U.getHtml(qurl,driver);
				quickData += U.getSectionValue(quickHtml, "<article class=\"qmi-detail__article\">", "</article>");
				
			}catch (Exception e) {
				System.out.println("Exception....");
			}
		}
		
		U.log("quickCount :::"+quickCount);
		//============ Price =====================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

		comSec = comSec.replaceAll("0s|0's", "0,000");
		html = html.replaceAll("0s|0's|0’s", "0,000");
		
		String[] price = U.getPrices(html, String.join("|", priceRegex), 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);
		//U.log(Util.matchAll(html, "[\\w\\s\\W]{30}515,950[\\w\\s\\W]{30}", 0));
		
		//=============== Sqft ===================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
//		U.log("SQDR"+Util.matchAll(comSec + html,"[\\w\\W\\s]{50}1,645[\\w\\W\\s]{50}", 0));
		String[] sqft = U.getSqareFeet(comSec + html , String.join("|", sqftRegex), 0);
		
		minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
		
		//============= Community Type ============
		html = html.replaceAll("lakeside or parkside view| lakes in the community", "lakeside community or parkside view");
//			 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}lake[\\w\\s\\W]{30}", 0));

		String comType = U.getCommunityType(html);
		
		//============ Floor Html ===============
		String combinedFloorHtmls = null;
		String[] floorUrls = U.getValues(html, "li class=\"grid__item regions__community", "</li>");
		U.log("floor plan count :"+floorUrls.length);
		for(String floorUrlSec : floorUrls){
			String floorUrl=U.getSectionValue(floorUrlSec, "href=\"", "\"");
			if(!floorUrl.startsWith("http")) floorUrl = builderUrl + floorUrl;
			U.log("floorUrl ::"+floorUrl);
//			String floorHtml = U.getHTMLwithProxy(floorUrl);

			String floorHtml = getHTM(floorUrl);

//			String floorHtml = U.getHtml(floorUrl,driver);

			combinedFloorHtmls += U.getSectionValue(floorHtml, "<div class=\"content-wrapper", "<button class=\"gallery");
		}
		//============= Property Type ==============
		html = html
				.replace("Mediterranean-style recreation center", "")
				.replaceAll("combination of traditional values", "combination of traditional style values");
		String propType = U.getPropType((html + combinedFloorHtmls+quickData).replace("flex/tech room.", "Flex Room"));
		
		//=============== Derived Property Type ===========
		String dType = U.getdCommType((html + combinedFloorHtmls+quickData).replace("two story swim-up", ""));
//		U.log(Util.matchAll(html, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll(combinedFloorHtmls, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}", 0));
//		U.log(Util.matchAll(quickData, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}", 0));

		//============= Property Status ===========
		String rem = "quick-move-ins\"|Quick Move|center=\"COMING\\+SOON%2C|We are currently|Lagoon coming|footer\">Coming|[M|m]ove(-)?[I|i]n";
		html = html.replaceAll("\\d{3}\\W Financing - USDA", "USDA 100% Financing");
		comSec= comSec.replaceAll(rem, "");
		
		String pStatus = U.getPropStatus((comSec + html)
				.replace("ooter\">Coming Soon</div>", "")
				.replaceAll("We are currently selling this community from Cielo Del Rio at|We are currently selling this community from Pueblos|/quick-move-ins|View Quick Move-ins in|item-title\">Quick Move-Ins</span>|move-in ready model", "")
				.replace(">Now Selling</em>","Now Selling"));
		if(pStatus.contains("Usda")&&pStatus==ALLOW_BLANK) pStatus = "USDA 100% Financing";
		U.log("STATUS: "+pStatus);
//		U.log("Match==="+Util.matchAll(comSec + html, "[\\w\\W\\s]{50}Currently Selling[\\w\\W\\s]{50}",0));
		
		
//		pStatus=pStatus.replace("", newChar)
		
		if(quickCount > 0 && !pStatus.contains("Quick Move")){
			if(pStatus == ALLOW_BLANK) pStatus = "Quick Move-Ins";
			else if(pStatus != ALLOW_BLANK) pStatus += ", Quick Move-Ins";
		}
		
		
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;

		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);	
		data.addCommunity(comName, comUrl, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(notes);
	}
	j++;
//	}catch(Exception e){}
	}
	
	public static String getHTM(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName =U. getCache(path);
//		deleteFile(fileName);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode =U. CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
			urlConnection.addRequestProperty("Accept-Language",
					"en-US,en;q=0.9,es;q=0.8,fr;q=0.7");
			urlConnection.addRequestProperty("Cookie", "_gcl_au=1.1.705601345.1658810691; _ga=GA1.2.1227172195.1658810691; _gid=GA1.2.105781370.1658810691; STITrackingID=5f6e1926-3ecd-476a-aaca-1a8f9e51956c; cf_clearance=6IPNNQvv4USjl36S.hCWAg927XjbgdZDmcw.9Ru67R8-1658820507-0-150; _gat_UA-39875153-1=1; XSRF-TOKEN=eyJpdiI6ImkxeCtYaDBPXC9uWTg5cUFhOHIyTGV3PT0iLCJ2YWx1ZSI6IjRkeEFlRnFGV2pGMzBPWTZsUnZQYVcwaU9TbEJuQU05OVM0c0NhUm53VHZBYUFMK0hiYWxGdGZ5eUJJaWU5Z2wiLCJtYWMiOiJmYmQzZjAyYmEwNDIwNmRhNWRiYjliNzk4Y2RiMjgzYzc2NmFiYzM2OTJmMTViM2Q5ZDEwYThkMTgyZmZjODhlIn0%3D; laravel_session=eyJpdiI6IlQzcjRYeEVYZm1hUDBKblA5MldRUEE9PSIsInZhbHVlIjoibG1mNFBrRmhmaHIrYWxBMjhDT21uMU5hbkZoanFnaFdcL0o2MXgyYVBzdVllSjNQRUc3UFVQK1diQ1FFbmJ4NFciLCJtYWMiOiI1ODYxZmU0OTEyZGM2NDJjOWNlMzNkYjA0ZjU0N2UzNWRmMDg3NTZiYTdjNWQzZmM2NjFjYThiNjM4NTdlNmVjIn0%3D; sc_is_visitor_unique=rx10851498.1658820551.5C3D869F9FE74FF69E6B657F5F88133E.3.2.1.1.1.1.1.1.1");
//			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("origin", "saratogahomestexas.com");
//			urlConnection.addRequestProperty("Connection", "keep-alive");

			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	
	
	
	
	
	
}