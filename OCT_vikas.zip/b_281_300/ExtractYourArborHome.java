package com.shatam.b_281_300;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
/**
 * @author Upendra Singh
 * @date 01-12-2018
 * 
 */
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.regexp.recompile;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.opera.core.systems.scope.protos.UmsProtos.Status;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.WinBase.STARTUPINFO;

public class ExtractYourArborHome extends AbstractScrapper 
{
	CommunityLogger LOGGER;
	static int j = 0; 
	WebDriver driver=null;
	HashMap<String, String> latLngList = new HashMap<>();

	private static final String BUILDER_URL = "https://www.yourarborhome.com";
	
	public static void main(String[] args) throws Exception 
	{
		AbstractScrapper a = new ExtractYourArborHome();
		a.process();
		
		// a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Arbor Homes.csv", a.data().printAll());

	}

	public ExtractYourArborHome() throws Exception 
	{
		super("Arbor Homes", "https://yourarborhome.com/");
		LOGGER = new CommunityLogger("Arbor Homes");
	}

	// String html = ALLOW_BLANK;
	int count = 0;

	public void innerProcess() throws Exception 
	{
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
//		String url = ALLOW_BLANK;
		String html = U.getHTML("https://yourarborhome.com/neighborhoods");
//		

		String jdata=U.getSectionValue(html, "window.__PRELOADED_STATE__ = ", "</script>");
		JsonParser parser=new JsonParser();
		
		JsonObject json = (JsonObject) parser.parse(jdata).getAsJsonObject().get("cloudData");
		JsonArray comJson = json.getAsJsonObject().get("communities").getAsJsonObject().get("572dd77c371e2f345d9c6ab5").getAsJsonObject().get("data").getAsJsonArray();
		U.log("comJson==="+comJson.size());
		for(int i=0;i<comJson.size();i++) 
		{
			String jsondata=comJson.get(i).toString();
//			U.log("jsondata===="+jsondata);
			String name=U.getSectionValue(jsondata, "\"sharedName\":\"", "\",");
			String geo=U.getSectionValue(jsondata, "\"geoIndexed\":", ",\"");

//			U.log("geo===="+geo);
			latLngList.put(name, geo);

//			break;
		}

		
				String[] comSec=U.getValues(html, "<div class=\"css-r8u669\"", "</span></div></div></div></a></div></div>");
				U.log("comSec=="+comSec.length);
				for(String com_sec : comSec) {
//					U.log("comSec=="+com_sec);
//					break;
					String Url="https://yourarborhome.com"+U.getSectionValue(com_sec,"href=\"","\" data");
//					U.log("Url=="+Url);
//					try {
						commDetails(Url,com_sec);
//					} catch (Exception e) {}
				}
//			}
//break;
//		}
		
		
		
		
		
//		commDetails("https://yourarborhome.com/neighborhood/cranbrook/", "\"guid\":{\"rendered\":\"Cranbrook\"},\"modified\":\"2020-04-21T19:57:56\",\"modified_gmt\":\"2020-04-21T19:57:56\",\"slug\":\"cranbrook\",\"status\":\"publish\",\"type\":\"neighborhood\",\"link\":\"https:\\/\\/yourarborhome.com\\/neighborhood\\/cranbrook\\/\",\"title\":{\"rendered\":\"Cranbrook\"},\"featured_media\":4915,\"template\":\"\",\"categories\":[],\"city\":[1512],\"county\":[1392],\"school_district\":[5],\"price_range\":[3186],\"yst_prominent_words\":[1757,644,637,1763,1758,645,281,651,650,663,1765,1762,278,1764,1767,1759,1760,661,1766,664],\"acf\":{\"address\":\"4987 Castamere Drive, Noblesville, IN 46062\",\"main_content\":[{\"acf_fc_layout\":\"subpage_hero\",\"background_image\":135,\"line_1_text\":\"From the $230's\",\"line_3_text\":\"Noblesville, IN\",\"class\":\"\",\"attr_id\":\"\",\"margin_top\":\"\",\"margin_bottom\":\"\",\"padding_top\":\"\",\"padding_bottom\":\"\",\"hide_on\":\"\"},{\"acf_fc_layout\":\"anchor_menu\",\"anchors\":[{\"label\":\"About\",\"target_id\":\"about_target\"},{\"label\":\"Features\",\"target_id\":\"features_target\"},{\"label\":\"Directions\",\"target_id\":\"directions_target\"},{\"label\":\"Photos\",\"target_id\":\"photos_target\"},{\"label\":\"Community Map\",\"target_id\":\"map_target\"},{\"label\":\"Floorplans\",\"target_id\":\"floorplans_target\"}],\"class\":\"\",\"attr_id\":\"\",\"margin_top\":\"\",\"margin_bottom\":\"\",\"padding_top\":\"\",\"padding_bottom\":\"\",\"hide_on\":\"\"},{\"acf_fc_layout\":\"breadcrumbs\",\"class\":\"\",\"attr_id\":\"\",\"margin_top\":\"\",\"margin_bottom\":\"\",\"padding_top\":\"\",\"padding_bottom\":\"\",\"hide_on\":\"\"},{\"acf_fc_layout\":\"community_page_content\",\"overview_one\":{\"exclude_overview_one\":false,\"anchor_id\":\"about_target\",\"media_type\":\"video\",\"image\":false,\"video\":\"inAuLkj7mfs\",\"slideshow_images\":false,\"related_text\":\"Single Family Homes in Noblesville, IN\",\"model_hours\":\"By Appointment Only.\",\"model_phone\":\"3178045053\",\"rep_image\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris.jpg\",\"hubspot_form\":\"<h4 style=\\\"color: #253b50; text-align: center;\\\">FIND YOUR DREAM HOME AT <strong>CRANBROOK<\\/strong><\\/h4>\\r\\n<p style=\\\"text-align: center;\\\">Make an appointment to view available lots at <strong>Cranbrook<\\/strong> and to find out which options and upgrades are available for your new home.<\\/p>\\r\\n<!--[if lte IE 8]>\\r\\n<script charset=\\\"utf-8\\\" type=\\\"text\\/javascript\\\" src=\\\"js.hsforms.net\\/forms\\/v2-legacy.js\\\"><\\/script>\\r\\n<![endif]-->\\r\\n<script charset=\\\"utf-8\\\" type=\\\"text\\/javascript\\\" src=\\\"https:\\/\\/js.hsforms.net\\/forms\\/v2.js\\\"><\\/script>\\r\\n<script>\\r\\nhbspt.forms.create({\\r\\nportalId: \\\"5350244\\\", \\r\\nformId: \\\"d17134b8-f5b6-4ae5-b10a-966b8e892df8\\\",\\r\\nonFormReady: function($form)  {\\r\\nString.prototype.capitalize = function() {\\r\\nreturn this.replace(\\/(?:^|\\\\s)\\\\S\\/g, function(a) { return a.toUpperCase(); });\\r\\n};\\r\\nvar url = $(location).attr('href').split('neighborhood\\/').pop();\\r\\nvar neighborhood = url.replace(new RegExp('-', 'g'),\\\" \\\").replace('\\/', '');\\r\\nvar community = neighborhood.capitalize();\\r\\n$('input[name=\\\"community\\\"]').val(community).change();\\r\\n},\\r\\ncss:\\\"\\\"\\r\\n});\\r\\n<\\/script>\"},\"overview_two\":{\"exclude_overview_two\":false,\"anchor_id\":\"features_target\",\"area_schools\":\"Hazel Dell Elementary<br \\/>\\r\\nNoblesville West Middle School<br \\/>\\r\\nNoblesville High School\",\"community_amenities\":\"Fiber Cement Siding<br \\/>\\r\\nCoach Lighting<br \\/>\\r\\nTree Lined Streets<br \\/>\\r\\nNeighborhood Landscaping\",\"surrounding_area\":\"Downtown Noblesville<br \\/>\\r\\nGrand Park <br \\/>\\r\\nDining & Entertainment\",\"description\":\"<p>With a small town feel but a location close to the city, Cranbrook is one of the best neighborhoods in Noblesville. Located on the border of Noblesville and Westfield, Cranbrook gives you north-central location-making it easy to visit picturesque downtown Noblesville, arts and shopping in Carmel, and great parks on all sides. An easy commute takes you into Indianapolis, while you enjoy the benefits of suburban living-including award-winning Noblesville schools.<\\/p>\\n\"},\"driving_directions\":{\"exclude_driving_directions\":false,\"anchor_id\":\"directions_target\",\"directions_text\":\"From the 465 loop, take SR-31 north. Take IN-32 west to Gray\\/Moontown Rd. Once you are at Moontown Rd., turn north and the community will be on the right in .10 miles. For GPS directions, you can use 17650 Moontown Rd. for accurate directions.\",\"map_embed_code\":\"<iframe style=\\\"border: 0;\\\" src=\\\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d3054.407284561052!2d-86.08837668461538!3d40.04401097941023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8814b1d7027527d7%3A0x3dde445b008f8c16!2sArbor+Homes+-+Cranbrook!5e0!3m2!1sen!2sus!4v1550609318938\\\" width=\\\"100%\\\" height=\\\"100%\\\" frameborder=\\\"0\\\" allowfullscreen=\\\"allowfullscreen\\\"><\\/iframe>\"},\"gallery\":{\"exclude_gallery_section\":false,\"anchor_id\":\"photos_target\",\"gallery_id\":\"4\"},\"iframe\":{\"exclude_iframe_section\":false,\"anchor_id\":\"map_target\",\"headline\":\"Interactive Community Map\",\"iframe_html\":\"<iframe style=\\\"border: 0px #ffffff none;\\\" src=\\\"https:\\/\\/salesarchitect.exsquared.com\\/SiteMapPreview\\/newisp?siteID=1270&communityID=15424\\\" width=\\\"100%\\\" height=\\\"700px\\\" frameborder=\\\"1\\\" marginwidth=\\\"0px\\\" marginheight=\\\"0px\\\" scrolling=\\\"no\\\"><\\/iframe>\\r\\n\\r\\n\\r\\n\"},\"available_floorplans\":{\"exclude_available_floorplans_section\":false,\"available_floorplans_anchor\":\"floorplans_target\"},\"class\":\"\",\"attr_id\":\"\",\"margin_top\":\"\",\"margin_bottom\":\"\",\"padding_top\":\"\",\"padding_bottom\":\"\",\"hide_on\":\"\"},{\"acf_fc_layout\":\"contact\",\"map_anchor\":\"\",\"contact_image\":{\"ID\":537,\"id\":537,\"title\":\"MikeMorris\",\"filename\":\"MikeMorris.jpg\",\"filesize\":2717021,\"url\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris.jpg\",\"link\":\"https:\\/\\/yourarborhome.com\\/neighborhood\\/cranbrook\\/mikemorris\\/\",\"alt\":\"\",\"author\":\"734\",\"description\":\"\",\"caption\":\"\",\"name\":\"mikemorris\",\"status\":\"inherit\",\"uploaded_to\":134,\"date\":\"2018-10-02 19:12:19\",\"modified\":\"2018-10-02 19:12:19\",\"menu_order\":0,\"mime_type\":\"image\\/jpeg\",\"type\":\"image\",\"subtype\":\"jpeg\",\"icon\":\"https:\\/\\/yourarborhome.com\\/wp-includes\\/images\\/media\\/default.png\",\"width\":2637,\"height\":2643,\"sizes\":{\"thumbnail\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-150x150.jpg\",\"thumbnail-width\":150,\"thumbnail-height\":150,\"medium\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-300x300.jpg\",\"medium-width\":300,\"medium-height\":300,\"medium_large\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-768x770.jpg\",\"medium_large-width\":768,\"medium_large-height\":770,\"large\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-1022x1024.jpg\",\"large-width\":1022,\"large-height\":1024,\"1536x1536\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris.jpg\",\"1536x1536-width\":1533,\"1536x1536-height\":1536,\"2048x2048\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris.jpg\",\"2048x2048-width\":2043,\"2048x2048-height\":2048,\"post-thumbnail\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-150x150.jpg\",\"post-thumbnail-width\":150,\"post-thumbnail-height\":150,\"hero\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-2637x980.jpg\",\"hero-width\":2637,\"hero-height\":980,\"card-image-large\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-944x371.jpg\",\"card-image-large-width\":944,\"card-image-large-height\":371,\"card-image-small\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-371x371.jpg\",\"card-image-small-width\":371,\"card-image-small-height\":371,\"contact-image\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-270x270.jpg\",\"contact-image-width\":270,\"contact-image-height\":270,\"flexible-content-background\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-2637x652.jpg\",\"flexible-content-background-width\":2637,\"flexible-content-background-height\":652,\"hero-slider\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-945x533.jpg\",\"hero-slider-width\":945,\"hero-slider-height\":533,\"floor_plan_slider\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/MikeMorris-345x285.jpg\",\"floor_plan_slider-width\":345,\"floor_plan_slider-height\":285}},\"contact_header\":\"Contact\",\"contact_body\":\"<p>Contact Your Community Sales Manager,<\\/p>\\n<p><strong>MIKE MORRIS<\\/strong>,<\\/p>\\n<p>for any questions or for more information about Cranbrook.<\\/p>\\n\",\"contact_links\":[{\"icon\":\"far fa-phone\",\"label\":\"317.804.5053\",\"link_value\":\"tel:3178045053\"},{\"icon\":\"far fa-at\",\"label\":\"EMAIL MIKE\",\"link_value\":\"mailto:MikeM@YourArborHome.com\"}],\"class\":\"\",\"attr_id\":\"questions_target\",\"margin_top\":\"\",\"margin_bottom\":\"\",\"padding_top\":\"\",\"padding_bottom\":\"\",\"hide_on\":\"\"}],\"use_coordinates\":false,\"latitude\":\"40.044158\",\"longitude\":\"-86.087133\",\"subdivision_number\":\"1.1.275\",\"use_default_leads_email\":false,\"subdivision_leads_email\":\"info@yourarborhome.com\",\"sales_office_street\":\"4987 Castamere Drive\",\"sales_office_city\":\"Noblesville\",\"sales_office_state\":\"IN\",\"sales_office_zip\":\"46060\",\"sales_office_latitude\":\"40.04421\",\"sales_office_longitude\":\"-86.0867\",\"sales_office_phone_area_code\":\"317\",\"sales_office_phone_area_prefix\":\"804\",\"sales_office_phone_area_suffix\":\"5053\",\"out_of_community\":false,\"include_in_xml_report\":true,\"city_state\":\"Noblesville, IN\",\"base_price\":\"230\",\"build_on_your_lot\":false,\"model_homes\":\"1\",\"number_of_floor_plans\":\"9\",\"quick_move_ins\":\"1\",\"subdivision_description\":\"\",\"neighborhood_gallery_images\":false,\"state\":\"indiana\"},\"city_name\":\"Noblesville\",\"city_slug\":\"noblesville\",\"county_name\":\"Hamilton\",\"county_slug\":\"hamilton\",\"school_district_name\":\"Noblesville Schools\",\"school_district_slug\":\"noblesville\",\"price_range_name\":\"From the $230's\",\"image\":\"https:\\/\\/yourarborhome.com\\/wp-content\\/uploads\\/2018\\/08\\/Cranbrook.jpg\",\"_links\":{\"self\":[{\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/neighborhood\\/134\"}],\"collection\":[{\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/neighborhood\"}],\"about\":[{\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/types\\/neighborhood\"}],\"wp:featuredmedia\":[{\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/media\\/4915\"}],\"wp:attachment\":[{\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/media?parent=134\"}],\"wp:term\":[{\"taxonomy\":\"category\",\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/categories?post=134\"},{\"taxonomy\":\"city\",\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/city?post=134\"},{\"taxonomy\":\"county\",\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/county?post=134\"},{\"taxonomy\":\"school_district\",\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/school_district?post=134\"},{\"taxonomy\":\"price_range\",\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/price_range?post=134\"},{\"taxonomy\":\"yst_prominent_words\",\"embeddable\":true,\"href\":\"https:\\/\\/yourarborhome.com\\/wp-json\\/wp\\/v2\\/yst_prominent_words?post=134\"}],\"curies\":[{\"name\":\"wp\",\"href\":\"https:\\/\\/api.w.org\\/{rel}\",\"templated\":true}]}}]");
		System.out.println(count);		
			//break;
//		driver.quit();
		LOGGER.DisposeLogger();
		
	}

	public void commDetails(String url, String comSec) throws Exception{
	//TODO : For Single Community Execution
//	try{
//	if( j>=24)
		{
		
//		if(!url.contains("https://yourarborhome.com/neighborhoods/ohio/union/concord-meadows")) return;

         if(url.contains("https://yourarborhome.com/neighborhood/briarstone/")) url = "https://yourarborhome.com/neighborhood/cherry-tree-walk/";
		 url=url.replace("https://yourarborhome.com/neighborhood/briarstone/briarstone-dr-greenwood-in-large-002-24-exterior-front-1392x1000-72dpi/","https://yourarborhome.com/neighborhood/millstone/");	
         
		
					
		U.log("\n\ncount::"+j+" ::Page: " + url);
		comSec=comSec.replaceAll("<!-- react-text: \\d+ -->| data-reactid=\"\\d+\"|<!-- /react-text -->", "");
//		U.log("comSec===="+comSec);
		String comm_name=U.getSectionValue(comSec, "<h4 class=\"CommunityCard_name d-flex flex-column\">", "<span>");
	if(comm_name!=null)
		comm_name=comm_name.toLowerCase().replace(" ", "-").replaceAll(",|&#x27;", "");
	U.log("comm_name===="+comm_name);
		
		U.log(U.getCache(url));
		if (data.communityUrlExists(url)){
			LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
			return;
		}
		if (url.contains("https://yourarborhome.com/neighborhoods/ohio/lancaster/ewing-estates")){
			LOGGER.AddCommunityUrl(url+ "---------------------------------redirect");
			return;
		}
		
		if (url.contains("https://yourarborhome.com/neighborhoods/indiana/pendleton/huntzinger-farms")){
			LOGGER.AddCommunityUrl(url+ "---------------------------------page not found");
			return;
		}
		
		if(url.contains("https://yourarborhome.com/neighborhood/cranbrook/")) return;
		
		LOGGER.AddCommunityUrl(url);
		
		//String html = U.getHTML(url);
		String html = U.getHtml(url, driver);
		html=U.removeSectionValue(html, "window.__PRELOADED_STATE__", "</script>");
		
		//String html=U.getHTMLwithProxy(url);
						     
		String communityName = U.getSectionValue(comSec,"<h4 class=\"CommunityCard_name d-flex flex-column\"", "<span");
		if(communityName!=null)communityName = communityName.replaceAll(", Destination Series", "");
		communityName=communityName
				.replace(", Arbor Series", "")
				.replace(">", "")
				.replace("Bluffs at Young&#x27;s Creek", "Bluffs at Young’s Creek")
				.replaceAll(" data-reactid=\"\\d+\">|<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
		
		U.log("Community Name::"+communityName);
		String commUrl = url;
		
//		String html2=U.getHtml("https://yourarborhome.com/neighborhoods-floorplans/neighborhoods/", driver);
//		String neghData[]=U.getValues(html2,"div class=\"cell small-12 neighborhood-card \">","VISIT COMMUNITY");
//		String MyneghData=ALLOW_BLANK;
//		for(String data:neghData) {
//		if(data.contains(communityName)) {
//			MyneghData=data;
//			//U.log("DATA"+data);
//		}
//		}
		
		
		
		
		//============= Community Type ==============
		String commType = U.getCommunityType(html+comSec);
		U.log("commType=="+commType);
		//============= address ==============
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
		String flag = "FALSE";
		
		String addrsec =U.getSectionValue(html, "<span class=\"DetailsPage_h2", "</span>");
		if(addrsec == null) addrsec =U.getSectionValue(html, "<p class=\"address\">", "</p>");
	
		U.log("addrsec==="+addrsec);
		


		if(addrsec!=null)
		{
			addrsec = addrsec
					.replaceAll("\" data-reactid=\"\\d+\">", "")
					.replace(" | ", ", ")
					
					.replace("Drive Westfield", "Drive, Westfield").replace("Drive McCordsville", "Drive, McCordsville").replace("602-500 Flint Blvd", "605 Flint Blvd").replace("Lebanon,", ",Lebanon,").replace("Drive Sheridan", "Drive, Sheridan");
			addrsec = addrsec.replace("Clinchfield Court, New ,Lebanon", "Clinchfield Court, New Lebanon");
			U.log("addrsec==="+addrsec);
			add=U.getAddress(addrsec);
			
		}else {
			 addrsec =U.getSectionValue(comSec, "\"address\":\"", "\"");
			 addrsec = addrsec
					 .replace("602-500 Flint Blvd", "605 Flint Blvd");
			 add=U.getAddress(addrsec);

		}
		add[0] = add[0].replaceAll("1117028|Maple Run Drive| and 204th St. Westfield, IN 46074|\">", "");
		
		
		U.log("Address>>"+Arrays.toString(add));
		
//		if (commUrl.contains("https://yourarborhome.com/neighborhood/maple-run/")) {
//			add[0]="698-610 IN-47";
//			add[1]="Sheridan";
//			add[2]="IN";
//			add[3]="46069";
//			flag = "True";
//			
//		}
		String latSec=U.getSectionValue(html, "\"https://www.google.com/maps/place/","\" ");
		
	
		if(latSec!=null) {
//			latSec=U.getSectionValue(latSec, "/@", "/");
			if(latSec!=null) {
				latlng[0]=Util.match(latSec, "\\d{2,3}.\\d{3,}");
				latlng[1]=Util.match(latSec, "-\\d{2,3}.\\d{3,}");
			}
		}
		U.log("latSec===="+latSec);
		
		
//		String value=latLngList.get(comm_name);
//		U.log("value===="+value);
		if(latSec==null) {
			String value=latLngList.get(comm_name);
			U.log("value===="+value);
			latlng[0]=U.getSectionValue(value, ",","]");
			latlng[1]="-"+U.getSectionValue(value, "[-",",");
		}

//		if(latSec==null && html.contains("https://www.google.com/maps/embed?")) {
//			U.log("hello");
//			latSec=U.getSectionValue(html, "https://www.google.com/maps/embed?","\"");
//			if(latSec!=null) {
//			latlng[0]=U.getSectionValue(latSec, "!3d", "!3m");
//			if(latlng[0].contains("!"))latlng[0] =U.getSectionValue(latSec, "!3d", "!2m");
//			latlng[1]=U.getSectionValue(latSec, "!2d", "!3d");
//			}
//		}

		U.log("LATLAG----"+latlng[0]+" "+latlng[1]);
		
		U.log("add[3]>>>>>>>"+add[3].length());
		if((add[3]==null|| add[3].length()<5) && latlng[0]!=ALLOW_BLANK)
		{
			
//			add[3]="";
			add[3]=U.getAddressGoogleApi(latlng)[3];
			if(add == null)add[3] = U.getAddressHereApi(latlng)[3];
			flag="TRUE";
		}
		U.log("Address>>"+Arrays.toString(add));
		U.log("flag :: "+flag);
		
		//if(latSec==null) {
		if(latlng[0]==ALLOW_BLANK && latlng[1]==ALLOW_BLANK){
			latSec=U.getSectionValue(html, "https://www.google.com/maps/place/", "z/data");
//			U.log("new latsec::::::::::::::"+latSec);

			if(latSec!=null) {
//				latSec=U.getSectionValue(latSec, "https://www.google.com/maps/place/", ",18.5");
				latlng[0]=U.getSectionValue(latSec, "/@", ",");
				latlng[1]="-"+U.getSectionValue(latSec, ",-", ",");
			}
		}
		
		if(latlng[1].contains("!3e0"))
		{
            latSec=U.getSectionValue(comSec, "<p><iframe style","</div>");
			
			latlng[0]=U.getSectionValue(comSec, "!2d", "!3e");
			latlng[1]=U.getSectionValue(comSec, "!1d", "!2d");
			
		}
		if(addrsec!=null && latSec!=null)
			flag="FALSE";
		
		
		
		if(add[1]!=ALLOW_BLANK && latlng[0]==ALLOW_BLANK)
		{
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null)latlng = U.getlatlongHereApi(add);
			flag="TRUE";
		}
		
		
		
		
		/*
		
        String dumAdd=U.getSectionValue(U.getSectionValue(html, "https://www.google.com/maps","\""), "/", "/@");
//		U.log(dumAdd);
		if(dumAdd!=null && add[3]==ALLOW_BLANK) {
		String dumpAdd[]=U.findAddress(dumAdd.replaceAll("\\+|dir//|place/", " ").replaceAll("Rd", "Road"));
		U.log(add[0]+"::::::::::"+(dumpAdd[0].trim()));
		if(add[0].trim().equals(dumpAdd[0].trim()) && add[1].trim().equals(dumpAdd[1].trim())) {
			U.log("hello");
			if(add[3]==ALLOW_BLANK) {
				U.log("helloooooooooooooooooooo");

				add[3]=dumpAdd[3];
			}
		}
		}
	*/	
		//U.log(latSec);
		
		
	//	U.log("Latlong>>"+Arrays.toString(latlng));
		
		if((add[0]==null || add[0]==ALLOW_BLANK||add[0].length()<4)&& latlng[0].length()>4) {
			add=U.getAddressGoogleApi(latlng);
			if(add == null) add =U.getAddressHereApi(latlng);
			flag="TRUE";
		}
		if((add[3]==null || add[3]==ALLOW_BLANK||add[3].length()<4)&& latlng[0].length()>4) {
			String [] add1=U.getAddressGoogleApi(latlng);
			if(add1 == null) add1 =U.getAddressHereApi(latlng);
			
			add[3]=add1[3];
			flag="TRUE";
		}
		if((latlng[0]==null||latlng[0].length()<4)&& add[1].length()>3) {
			latlng=U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			flag="TRUE";
		}

		if(url.contains("https://yourarborhome.com/neighborhood/sagebrook/"))
		{
		add[0]="6080 N Cedarwood Dr";
		add[1]="McCordsville";
		add[2]="IN";
		add[3]="46055";
		flag="FALSE"; 
		}
		
//		if(url.contains("https://yourarborhome.com/neighborhood/maple-trails/"))
//		{
//			add[0]="8304 Ambrosia Ln";
//			add[1]="Pendleton";
//			add[2]="IN";
//			add[3]="46064";
//			flag="FALSE";
//		}
		
		if(url.contains("https://yourarborhome.com/neighborhood/trails-at-grassy-creek/"))
		{
			add[0]="Bucktail Blvd";
			add[1]="Indianapolis";
			add[2]="IN";
			add[3]="46239";
			flag="FALSE";
		}
		
		
		if(url.contains("https://yourarborhome.com/neighborhood/the-preserve-at-arbor-pines/"))
		   flag="FALSE";
		
		
//		if(url.contains("/neighborhoods/ohio/dayton/tarragon-estates")) {
//			
//			add[3] = "45345"; //wrong zip given on compage
//			flag = "TRUE";
//		}
	
		//============================================= Pricess =============================================
		
		String floorHtml="";
		//String homeSec[]=U.getValues(comSec+html, "<div class=\"content\">", "<i class=\"fas fa-chevron-circle-right\"></i>");
        
//		String homeSec[]=U.getValues(html, "<div class=\"floorplan-card-container\">","<i class=\"fas fa-chevron-circle-right\">");
//	   
//		U.log("home count ::"+homeSec.length);
//		//U.log("hhh--------"+comSec);
//		for (String string : homeSec) {
//			
//			String hUrl[]=U.getValues(string, "href=\"", "\"");
//		
//			U.log("Floor URL>>>>"+hUrl[1]);
//		
//			floorHtml=floorHtml+U.getHTML(hUrl[1]);
//		}
		
/*		if(homeSec.length == 0){
			homeSec=U.getValues(html, "<div class=\"grid-x grid-margin-x grid-margin-y\">","<i class=\"fas fa-chevron-circle-right\">");
			for(String val : homeSec){
				val = val.replaceAll("<a title=\"Virtual Tour\"(.*)\">", "");
				//-U.log(val);
				
				String hUrl=U.getSectionValue(val, "\" href=\"", "\"");
				if(hUrl != null && hUrl.contains("yourarborhome")){
					U.log("Floor URL>>>>"+hUrl);
			
					floorHtml=floorHtml+U.getHTML(hUrl);
				}
			}
		}*/
		
		String plansHtml="";
		int count=0;
		String plans_sec=U.getSectionValue(html, "Plans</h2><div class=\"d-flex align-items-center\"", "<div class=\"DetailSection_headingWrapper");
//		U.log("quickHome==="+quick_sec);
		if(plans_sec!=null) {
        	String[] plans=U.getValues(plans_sec, "<div class=\"css-itif3u\"", "</span></div></div></div></a></div></div>") ;
        	U.log("total plans==="+plans.length);
        	if(plans.length>0) {
        		for(String plans_data : plans) {
        			String plansUrl="https://yourarborhome.com"+U.getSectionValue(plans_data, "<a class=\"d-flex\" href=\"", "\"");
        			U.log("plansUrl==="+plansUrl);
        			if(plansUrl!=null) {
        				plansHtml+=U.getSectionValue(U.getHTML(plansUrl), "<div class=\"PlanOverview_content\"", "<div class=\"PlanOverview_brochure \"");
//        			count++;
        			}
        		}
        		
        	}
        	
        }
		String quickHomeHtml="";
		int quickCount=0;
		String quickHtml=U.getHtml("https://yourarborhome.com/homes", driver);
		String []quickHome=U.getValues(quickHtml, "class=\"Homes_homesListItem\"", "</div></a></div></div></div>");
		U.log("quickHome.len=="+quickHome.length);
		String name=communityName.toLowerCase().replace(" ", "-");
		for(String quick_home : quickHome) {
//			U.log("quick_home=="+quick_home);
			if(quick_home.contains(communityName)) {
			String quickUrl="https://yourarborhome.com"+U.getSectionValue(quick_home, "href=\"", "\"");
			if(quickUrl!=null) {
				quickHomeHtml=U.getHtml(quickUrl, driver);
				
				//U.log(">>>>>>>>>>>>"+Util.matchAll((quickHomeHtml), "[\\s\\w\\W]{30}fall[\\s\\w\\W]{30}", 0));
				
				quickHomeHtml=U.removeSectionValue(quickHomeHtml, "window.__PRELOADED_STATE_", "</script>");
				quickHomeHtml=U.getSectionValue(quickHomeHtml, "<div class=\"HomeOverview_content\"", "</a></li></ul></div></div></div></div></div></div></div></div>")
						+"\n\n"+quick_home;
				
				if(quickHomeHtml.contains("Available August 2022") || quickHomeHtml.contains("Available This Fall") || 
						quickHomeHtml.contains("Ready This Fall") || quickHomeHtml.contains("Available Late Summer")) {
					
				} else {
					
					quickCount++;
				}
			}
			}
			
//			break;
		}
		U.log("quickCount=="+quickCount);
		
		comSec=comSec.replace("\"base_price\":\"230\"", "starting from the $230,000").replaceAll("0's|0's|0'S|0s|0S|0&#039;s|0&#039;s</h4>|0s", "0,000").replace("From the $230,000", "starting from the $230,000");
		if(html!=null)
			html=html.replaceAll("0&#039;s</h4>|0s|0’s|0&#8217;s", "0,000");
		if(floorHtml!=null)
			floorHtml=floorHtml.replaceAll("0's|0&#039;s</h4>|0s|0’s|0&#8217;s", "0,000");
//		U.log(">>>>>>>>>>>>"+Util.matchAll((floorHtml).replaceAll("\\$\\d+,\\d+\\+\\s*</option>|\"description\":\".*\"|content=\".*\"", ""), "[\\s\\w\\W]{30}\\$280[\\s\\w\\W]{30}", 0));

		html=html.replaceAll("<span style=\"display: none;\">", "");
//		U.log(">>>>>>>>>>>>"+Util.matchAll((html).replaceAll("\\$\\d+,\\d+\\+\\s*</option>|\"description\":\".*\"|content=\".*\"", ""), "[\\s\\w\\W]{30}\\$280[\\s\\w\\W]{30}", 0));

		html=html.replace("Starting At $280s", "Starting At $280,000");
		String price_sec=U.getSectionValue(html, "<span class=\"Carousel", "</span>");
		if(price_sec!=null) {price_sec=price_sec.replace("&#x27;s", "'s");
		price_sec=price_sec.replaceAll("'s", ",000");
		}
		U.log("price_sec :"+price_sec);
		String[] Prices = U.getPrices((html+comSec+floorHtml+plansHtml+quickHomeHtml+price_sec),//.replaceAll("\"description\":\"(.*)\"|content=\"(.*)\"", ""),
				">\\$\\d{3},\\d{3}</b>|From the High \\$\\d{3},\\d{3}|From the Mid \\$\\d{3},\\d{3}|From the Low \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|<strong>From the \\$\\d{3},\\d{3}</strong>|From the \\$\\d{3},\\d{3}|Starting At \\$\\d{6}|Starting At \\$\\d+,\\d+|From the \\d{3},\\d{3}|Starting in the \\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|Homes start in the \\$\\d{3},\\d{3}|starting from the \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|(S|s)tarting in the \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|Priced from \\$\\d{3},\\d{3}|Priced from\\s+\\$\\d{3},\\d{3}|<span><em>\\$\\d{3},\\d{3}",0);
		
		Prices[0] = (Prices[0] == null) ? ALLOW_BLANK : Prices[0];
		Prices[1] = (Prices[1] == null) ? ALLOW_BLANK : Prices[1];
		U.log("MinPrice :" + Prices[0] + " MaxPrice:" + Prices[1]);

		//============================================= Sq.Fit. =============================================
		
		String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
		// $407,470
		quickHomeHtml=quickHomeHtml.replaceAll("</b><!-- react-text: \\d+ -->SQ. FT.", " SQ. FT.");

		html=html.replaceAll("</b><!-- react-text: \\d+ -->SQ. FT.", " SQ. FT.");
		plansHtml=plansHtml.replaceAll("</b><!-- react-text: \\d+ -->SQ. FT.", " SQ. FT.");
		String[] sqft = U.getSqareFeet((comSec+html+floorHtml+quickHomeHtml+plansHtml).replaceAll("</b><!-- react-text: \\d+ -->", " "), "\\d,\\d{3} SQ FT|<p>\\d,\\d{3}-\\d{4} SQ. FT.</p>|<p>\\d{4}-\\d{4}</p>|\\d,\\d{3} square feet|Square Footage</p>\\s*\\n*\\s*<h4>\\d{4}|\\d,\\d{3} sq. ft", 0);
		minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//		U.log(Util.matchAll(quickHtml, "[\\w\\s\\W]{60}SQ. FT.[\\w\\s\\W]{30}", 0));
		U.log(Util.matchAll(html+comSec+floorHtml+plansHtml+quickHomeHtml, "[\\w\\s\\W]{60}SQ. FT.[\\w\\s\\W]{30}", 0));

		// ==================================== Status - Type
		String Status = ALLOW_BLANK;
	//	html = html.replaceAll("MODEL HOMES COMING", "");
		comSec = comSec.replaceAll("MODEL HOMES COMING", "");
		String sta_sec=U.getSectionValue(html, "<div class=\"CommunityOverview_lead\"", "<div class=\"CommunityOverview_modal\"");
				if(sta_sec!=null)sta_sec=sta_sec.replaceAll("quick move-in|Quick Move-In", "");

		Status=U.getPropStatus((sta_sec+comSec).replaceAll("soon you will find|COMMUNITY MODELS:</h4><ul><li><b>Cooper GRAND OPENING|new model homes are grand opening this Summer|quick-move in homes|quick move-in|Quick Move-In|Meadows at Sagebrook, is selling quickly|subdivision_status\":\"Closeout|Quick Move-In Ranch Homes Available No|Destination Floorplans & Quick Move-In Homes|our quick move-in homes|Floorplans &amp; Quick Move-In Homes|with quick move-in homes and low|Contact us today to view our nearby Now Selling |\"subdivision_status\":\"CloseOut\"|Now Selling Huntzinger Farm in Pendleton, IN from our Wyndstone Model in Fortville|Now Selling Trails|\"subdivision_status\":\"Coming|\\(Coming Soon\\)|Section two is coming soon|Homes coming soon|>COMING SOON|QUICK MOVE-IN HOMES|hours coming|range_name\":\"Now|(new|purchasing a) move-in", ""));
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(sta_sec, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{100}coming soon[\\s\\w\\W]{30}", 0));

		
		U.log("Status:::: "+Status);
		Status = Status.replaceAll(", No Quick Move-in Homes|No Quick Move-in Homes, |No Quick Move-in Homes", "");
		if(Status.trim().length() < 2) Status = ALLOW_BLANK;
		//if(U.getSectionValue(quickHtml, "<div class=\"card-container quick-move-in-card-container\">", "<footer>").toLowerCase().contains(communityName.trim().toLowerCase())) {
//			if(html.contains("<a href=\"#communityPanel2\">QUICK MOVE-IN HOMES</a>") && !html.contains("<p>No quick move-in homes are currently ")) {
//				
//				
//				if(Status.length()>4 && !Status.contains("Quick"))
//					Status=Status+", Quick Move-in Homes";
//			
//				 else Status="Quick Move-in Homes";
//				 
//			}
		
/*		U.log("Quick Home ::"+quickHomeSec.length);
		if(quickHomeSec.length > 0){
			if(Status != ALLOW_BLANK) Status=Status+", Quick Move-in Homes";
			else if(Status == ALLOW_BLANK) Status="Quick Move-in Homes";
		}*/
		//============== PropType html =====================
		String pType = ALLOW_BLANK;
		html = html.replace("Craftsman &amp; Tudor style homes", "Craftsman style details");
//		U.log(">>>>>>>>>>>>"+Util.matchAll((html+comSec), "[\\s\\w\\W]{100}quick[\\s\\w\\W]{100}", 0));

		pType = U.getPropType((html+plansHtml+comSec+quickHomeHtml+floorHtml.replaceAll("courtyard garage|-Traditional-", "")).replaceAll("Craftsman-\\d+|-(T|t)raditional|_Traditional", ""));
		//============== DriveType html =====================
		
		html = html.replaceAll("STORIES</span>\\s*<p>1</p>", "</span><p> 1 Story</p>").replaceAll("<span>STORIES</span>\n\\s*<p>2</p>", " 2 Story</p>");
		floorHtml=floorHtml.replaceAll("Stories</p>\\s*\\n*\\s*<h4>\\s*", " Story ");
		comSec=comSec.replaceAll("STORIES</span>\\s*\\n*\\s*<p>\\s*", " Story ");
		String dType = ALLOW_BLANK;
		dType = U.getdCommType((html+plansHtml+floorHtml+quickHomeHtml+comSec).replace("multi-level foyer", ""));
		
		dType = dType.replaceAll("Multi-Level, Multi-Level Foyer,", "Multi-Level Foyer,");
		
		//============== Note =====================
		String notes = ALLOW_BLANK;
		//notes = U.getnote(html);
		notes = U.getnote(comSec);
		add[0]=add[0].replace("&amp;", "&");
		
		// ============================================= End
        if(url.contains("https://yourarborhome.com/neighborhood/millstone/"))Prices[0]="$180,000";
//        if(url.contains("https://yourarborhome.com/neighborhood/maple-run/")) Prices[0]="$150,000";
        if(url.contains("https://yourarborhome.com/neighborhood/the-preserve-at-cedar-creek/") 
        		|| url.contains("https://yourarborhome.com/neighborhood/abbey-place/")) flag = "FALSE";
//        if(url.contains("https://yourarborhome.com/neighborhood/bluffs-at-youngs-creek"))Status ="Coming Soon";

		if(commUrl.contains("https://yourarborhome.com/neighborhood/riley-ridge/")) Prices[1] = "$170,000"; //is not present in comsec but avail on site
		if(url.contains("https://yourarborhome.com/neighborhood/the-retreat/"))Prices[0] = "$260,000"; 
		if(url.contains("https://yourarborhome.com/neighborhood/estes-park/"))Prices[0] = "$230,000"; 
		
        if(commUrl.contains("https://yourarborhome.com/neighborhood/maple-run/")) {
        	//Maple Run Dr, Sheridan, IN 46069, USA
        	add[0]="Maple Run Dr";
        	add[1]="Sheridan";
        	add[2]="IN";
        	add[3]="46069";
        	latlng[0]="40.1277706";
        	latlng[1]="-86.2289239";
        }
        if(commUrl.contains("neighborhood/riley-ridge/"))Status =Status.replace("Now Sold Out", "Sold Out");
        if(commUrl.contains("https://yourarborhome.com/neighborhood/estes-park"))Status="Quick Move-in Homes";
        if(commUrl.contains("https://yourarborhome.com/neighborhood/the-retreat"))Status="Quick Move-in Homes";
		//LOGGER.AddCommunityUrl(commUrl);
        
//        if(commUrl.contains("https://yourarborhome.com/neighborhoods/ohio/dayton/bartley-creek"))Status="Coming Soon";//from regn page image dt:25 june jayashree

        
        add[0]=add[0].replace("+", "&");
        
        if(quickCount>0 && !Status.contains("Quick Move-in Homes")) {
        	if(Status.length()>5) {
        		Status=Status+", Quick Move-In Homes";
        	}
        	else {
        		Status="Quick Move-In Homes";
        	}
        }

//       ===================================================================================
        String maplink=null;
       String lotcount=ALLOW_BLANK;
//        if(html.contains(">Interactive Map</h3>")) {
//        	String linkSec=U.getSectionValue(html, ">Interactive Map</h3>", "</iframe>");
//        	if(linkSec!=null) {
//        		maplink=U.getSectionValue(linkSec, "<iframe src=\"", "\"");
//        		U.log("maplink==="+maplink);
//        		String  mapHtml=U.getHtml(maplink, driver);
//        		U.log("mapHtml==="+mapHtml.length());
//        		if(mapHtml.length()>7500)
//        		lotcount=getUnits(mapHtml);
//			
//			
//			if(lotcount.equals("0")) {
//				lotcount=ALLOW_BLANK;
//			}
//			U.log("lotcount=="+lotcount);
//        	}
//        }
        
        
		data.addCommunity(communityName, commUrl, commType);
		data.addAddress(U.getNoHtml(add[0]), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latlng[0], latlng[1], flag);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(Status);
		data.addPrice(Prices[0], Prices[1]);
		data.addSquareFeet(minSqft, maxSqft);
		data.addNotes(notes); 
		data.addUnitCount(lotcount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//	}catch(Exception e){}
	}
	
	}