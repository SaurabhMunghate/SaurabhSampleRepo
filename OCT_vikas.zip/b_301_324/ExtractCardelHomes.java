/**@author Sawan
 * Date- 06-02-2017   
 */
package com.shatam.b_301_324;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCardelHomes extends AbstractScrapper {
	private static String builderUrl = "https://www.cardelhomes.com";
	private static String builderName = "Cardel Homes";
	private static String fileUrl = U.getCachePath()+"Cardel Homes.csv";
	private CommunityLogger LOGGER;
	int j = 0;
	private String propertType;
	WebDriver driver = null;
	
	public ExtractCardelHomes() throws Exception {
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper as = new  ExtractCardelHomes();
		as.process(); 
		FileUtil.writeAllText(fileUrl, as.data().printAll());	
	}
	@Override
	protected void innerProcess() throws Exception {
		
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String html = U.getHTML(builderUrl);
		String regionSec = U.getSectionValue(html, "<div class=\"map-links\">", "</div>");
		String [] regionUrls = U.getValues(regionSec, "<a href=\"", "\"");
		for(String regionUrl : regionUrls){
			if(regionUrl.contains("calgary") || regionUrl.contains("ottawa"))continue;//regions from Canada
//			U.log(builderUrl+regionUrl);
//			if(regionUrl.contains("tampa"))
		findCommunity(builderUrl+regionUrl);

		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}
	private void findCommunity(String regionUrl)throws Exception {
		U.log("========"+regionUrl);
		String html = U.getHTML(regionUrl);
		
		String [] commSections = U.getValues(html, "<div class=\"col-lg-4 col-md-6 d-flex nav-box-outer\">", "</a></div>");
		
		if(commSections==null || commSections.length==0)
			commSections = U.getValues(html, "<div class=\"col-lg-4 col-md-6 d-flex nav-box-outer\">", "Explore Community");
	
		U.log(commSections.length);
		for(String commSec : commSections){
			if(commSec.contains("href=\"#\"") || commSec.contains("Community Map") || !commSec.contains("/communities/"))continue;
			String commUrl = U.getSectionValue(commSec, "href=\"", "\"");
			U.log("========"+commUrl);

			if(!commUrl.startsWith("http")){
				
				findCommunityDetails(builderUrl+commUrl,commSec,regionUrl);
			}else{
				findCommunityDetails(commUrl,commSec,regionUrl);
			}
		}
//		findCommunityDetails("https://www.cardelhomes.com/denver/communities/lincoln-creek", "\"Lincoln Creek\" href=\"https://www.cardelhomes.com/denver/communities/lincoln-creek\"><span class=\"navtext\">Lincoln Creek</span>");
	}
	private void findCommunityDetails(String commUrl,String commSec,String regionUrl)throws Exception {
	// TODO : For Single Community Execution
//	try{

		{
			if (data.communityUrlExists(commUrl)){
				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);
			String html = U.getHTML(commUrl);
			
			if(commUrl.contains("https://www.cardelhomes.com/tampa/central-florida")){
				return;
			}
			
//			if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/bexley")) {
//				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------RETURNED");
//				return;
//			}

			//////////////////// For Single Community Execution
			
//			if(!commUrl.contains("https://www.cardelhomes.com/tampa/communities/prairie-oaks")) return;
			
			
			U.log("Count::"+j);
			U.log(commUrl);
			//========== Community Name ========================
			String commName = U.getSectionValue(commSec, "class=\"navtext\">", "</span>");
			if(commName == null) commName = U.getSectionValue(html, "comm-name text-white text-uppercase\">", "</div>");
			U.log("CommName::"+commName);
			
			
			//======================== REMOVE FEADER ========================
			
			String header = U.getSectionValue(html, "<header>", "</header>");
			
			if(header != null)
				html = html.replace(header, "");
			
			
			//=========== Community Page=============
			String comPage = U.getHTML(commUrl.replace("/"+commName.toLowerCase().trim().replace(" ", "-"), ""));
			
			String[] comPageSec = U.getValues(comPage, "class='alignnone size-full", "</h2></div>");
			
			for(String name : comPageSec) {
				
				if(name.contains(commName.toLowerCase().trim().replace(" ", "-"))) {
					commSec += name;
					break;
				}
			}
			
			
			//============= Community Urls Section =============
			String salesContactHtml = null;
			String floorPlanHtml = null;
			String modelHomeHtml = null;
			String quickHomeHtml = null;
			String specificationHtml = null;
			String amenitiesHtml = null;
			String lineUpHtml = null;
			boolean flag=false;
			String quickPossUrl =ALLOW_BLANK;
			String commUrlSec = U.getSectionValue(html, "About </a>", "<div class");
			if(commUrlSec == null) commUrlSec = U.getSectionValue(html, "<div id=\"mobilenav\"", "<h2 class=");
//			U.log(commUrlSec);
			if(commUrlSec != null){
				String [] urls = U.getValues(commUrlSec, "<a href=\"", "\"");
				for(String url : urls){
					U.log(url);
					if(!url.contains("http"))url = "http://www.cardelhomes.com"+url;
					if(url.contains("/homes") || url.contains("/floorplans"))
						floorPlanHtml = U.getHTML(url);
					if(url.contains("/amenities"))
						amenitiesHtml = U.getHTML(url);
					if(url.contains("/model-homes"))
						modelHomeHtml = U.getHTML(url);
					if( url.contains("/quick-possessions") || url.contains("/quick-move-ins"))
					{
//						U.log("----"+url);
						quickPossUrl = url;
						quickHomeHtml = U.getHTML(url);
					}
					if(url.contains("/quick-closing"))
					{
//						U.log("----"+url);
						flag=true;
						quickPossUrl = url;
						quickHomeHtml = U.getHTML(url);
					}
					if(url.contains("/home-lineup")) {
						
						lineUpHtml = U.getHTML(url);
						lineUpHtml = lineUpHtml.replace("<small>s</small>", "s").replace("0s", "0,000");
					}
					if(url.contains("/specifications") && html.contains("list-group-item \" >Specifications"))
					{	
						specificationHtml = U.getHTML(url);
					}
					if(url.contains("/sales-contact") || url.contains("/sales-manager"))
					{
						
						salesContactHtml = U.getHTML(url);
					}
				}
			}
		//	U.log("OOO"+Util.match(modelHomeHtml,"luxurious"));
			String quickData="";
			if (quickHomeHtml!=null) {
				String quickHomes[]=U.getValues(quickHomeHtml, "div class=\"col-md-4 qpcol-item element-item transition qp", "block\">View Listing</span>");
				for (String quick : quickHomes) {
					String quickUrl=U.getSectionValue(quick, "href=\"", "\"");
					U.log("QuickURl"+quickUrl);
					String htmlQuic=U.getHTML(quickUrl);
					quickData+=U.getSectionValue(htmlQuic, "<div class=\"details-header\">Details</div>", "<script>");
				}
			}
			if (floorPlanHtml!=null) {
				String plans[]=U.getValues(floorPlanHtml, "<div class=\"col-xl-4 col-lg-6\"><", "<span class=\"round-button view-");
				for (String plan : plans) {
					String planUrl=U.getSectionValue(plan, "href=\"", "\"");
					U.log("planURl"+planUrl);
					String planhtml=U.getHTML(planUrl);
					quickData+=U.getSectionValue(planhtml, "<div class=\"col-lg-6 floorplan--main-info p-0\">", "<div id=\"vr-link-modal\"");
				}
			}
			
			
			
			
//			String removeSec=U.getSectionValue(quickData, "}</script></div><style>.community-header-", "ready(function() {");
			
			
			
//			if(removeSec!=null)
//			{
//				U.log("&&&&&&&&&&&&&&&&&&");
//				quickData=quickData.replace(removeSec, " ");
//				U.log("&&&&&&&&&&&&&&&&&&");
//			}
			
			//============ Address =================================
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
			String addSec = U.getSectionValue(html, "<div class=\"contact-address\" style=\"margin-top: -15px;\">", "</div>");
			if(addSec == null && salesContactHtml != null){
				addSec = U.getSectionValue(salesContactHtml, "class='contact-address' style='margin-top: -15px;'>", "</div>");
				if(addSec==null){
					addSec = U.getSectionValue(salesContactHtml, "class=\"contact-address\" style=\"margin-top: -15px;\">", "</div>");
				}
				if(addSec==null){
					addSec = U.getSectionValue(salesContactHtml, "<div class=\"contact-address\"><strong>", "</strong>");
				}
				if(addSec==null){
					addSec = U.getSectionValue(salesContactHtml, "<div class=\"contact-address\">", "</div>");
				}
				if(addSec==null){
					addSec = U.getSectionValue(salesContactHtml, "<div class='contact-address margin-bottom-10'><strong>", "</strong>");
				}
				if(addSec==null) addSec = U.getSectionValue(salesContactHtml, "Sales Centre Location</span>", "<a target=");
				if(addSec==null) addSec = U.getSectionValue(salesContactHtml, "<span>Sales Center Location</span>", "</span> <a target=\"_blank\"");

			}
			if(addSec != null){
				addSec = addSec.replaceAll("<strong>|</strong>|<br /> | <br />| <br>", "").replaceAll("Lakewood$", "Lakewood, ,")
						.replace("Dr Apollo Beach,", "Dr, Apollo Beach,").replace("Ave. Lakewood", "Ave., Lakewood").replace("FL, ", "FL ").replace("Sun Dr Apollo Beach", "Sun Dr")
						.replace("LoopLand", "Loop, Land").replace("Pre-selling by appointment only", "").replace(",<br />", ",").replace("Call for appointment", "")
						.replaceAll("<.*?>", "").replaceAll("Now pre-selling at our Lakewood Ranch – Country Club East sales office at", "")
						.replace("Future Sales Center", "")
						.replace("Future Sales Center - Models Coming Soon", "").replace("5412 Silver Sun Dr. Apollo Beach", "5412 Silver Sun Dr., Apollo Beach");
				U.log("==="+addSec);
				if(addSec.length()>15)
				add = U.getAddress(addSec);
				U.log(Arrays.toString(add));
			}

			U.log("AddSec:\t"+addSec);
			
			//============ LatLng Section ==========================
			String latLngSec = U.getSectionValue(html, "http://maps.google.com/maps/search/", "\"");
			
//			U.log(">>>>>>>>>>>>>>>latLngSec>>>>>>>>>>>"+latLngSec);
			
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK; 
			if(latLngSec == null && salesContactHtml != null){
				latLngSec = U.getSectionValue(salesContactHtml, "http://maps.google.com/maps/search/", "\"");
			}

			if(latLngSec != null ){

				latLngSec = latLngSec.replaceAll("%2C", ",");
				String [] latLong = latLngSec.split(",");
				latLong[0]=Util.match(latLngSec, "\\d{2,3}.\\d+");
				latLong[1]=Util.match(latLngSec, "-\\d{2,3}.\\d+");
				if(latLong.length != 0)
				{
				lat = latLong[0];
				lng = latLong[1].replace("+", "");
				}
			}
			
			
			String regname=regionUrl.replace("https://www.cardelhomes.com/", "");
			if(lat==ALLOW_BLANK || lat==null) {
				String pgSrc=U.getPageSource("https://www.cardelhomes.com/"+regname+"/communities");
				if(pgSrc!=null) {
					String latlngSec=U.getSectionValue(pgSrc, " var locations = [", "];");
					U.log("latlngSec==="+latlngSec);
					if(latlngSec!=null) {
						String[] commData=U.getValues(latlngSec, "[\"", "\"]");
						U.log("commData==="+commData.length);
						if(commData.length>0) {
							for(String latData :commData) {
								String temp=commName.trim().replace(" ", "-");
								U.log("temp==="+temp);
								if(latData.contains(temp))
								{
									latlngSec=U.getSectionValue(latData, "\"https:", "\"https:");
									latData=latData.replace("\"undefined\",\"813-680-2782\",", "");
									U.log("latData==="+latData);
									lat=Util.match(latlngSec, "\\d{2}.\\d{2}\\d+");
									lng=Util.match(latlngSec, "-\\d{3}.\\d{2}\\d+");
									if(lng==null)
										lng=Util.match(latlngSec, "-\\d{2}.\\d{2}\\d+");
									U.log("lat==="+lat);
								}
							}
						}
					
					}
				}
			}
			
			U.log("Lat::"+lat+"\tLng::"+lng);
//			U.log(Arrays.toString(add));
			if(add[0] == ALLOW_BLANK || add[3] == ALLOW_BLANK){
				if(lat != ALLOW_BLANK && lng != ALLOW_BLANK){
					String [] latlng = {lat,lng};
					String addVal[] = U.getAddressGoogleApi(latlng);
					if(addVal == null) addVal = U.getAddressHereApi(latlng);
					add=addVal;
					geo = "True";
				}
			}
			if(add[0].length()>4 && lat.length()<4){
				String [] LL = U.getlatlongGoogleApi(add);
				if(LL == null) LL = U.getlatlongHereApi(add);
				lat = LL[0];
				lng = LL[1];
				geo = "TRUE";
						
			}

			if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/oakwood-reserve" )) 
			{
				lat = "28.1210853";
				lng = "-82.4319286";
				geo = "TRUE";
				add = U.getGoogleAddressWithKey(new String[] {lat,lng});
				
			}
			
			if(commUrl.contains("https://www.cardelhomes.com/denver/communities/the-ridge" )) 
			{
				lat = "39.4538333";
				lng = "-105.0793276";
				geo = "TRUE";
				add = U.getGoogleAddressWithKey(new String[] {lat,lng});
			}
//			if(commUrl.contains(""))
			if(lat!=null && lat!=ALLOW_BLANK ) {
				if(add[3]==ALLOW_BLANK)
				{
					add[3]=U.getGoogleAddressWithKey(new String[] {lat,lng})[3];
					geo = "TRUE";
				}
				
			}
			
			if(commUrl.contains("/communities/deer-creek")) {
				
				String geoData = U.getHTML("https://www.cardelhomes.com/denver/communities");
				String geoSec = U.getSectionValue(geoData, "\\/communities\\/deer-creek\",\"", ",\"https")
						.replace("\",\"", ",").replace("\"", "");
				U.log("geoSec: "+geoSec);
				
				String[] geoSplit = geoSec.split(",");
				
				lat = geoSplit[0].trim();
				lng = geoSplit[1].trim();
				
				U.log("lat: "+lat+ " lng: "+lng);
				
				add = U.getGoogleAddressWithKey(new String[] {lat,lng});
				U.log(Arrays.toString(add));
				geo = "TRUE";
			}

			//============== Sqft ===================
			html = html.replace("&#8211;", "-");
			if(lineUpHtml!=null)
			lineUpHtml = lineUpHtml.replace("&#8211;", "-");
			String sqft[] = U.getSqareFeet((html+floorPlanHtml+modelHomeHtml+quickHomeHtml+lineUpHtml)
					.replaceAll("The Lucia</h4><h5>2,442 SQ FT</h5><h5>3 Bedroom</h5><h5 class=\"pad-bottom-5\">3.5 Bath</h5><div class=\"sep-dot\"></div> <a href=\"/denver/communities/sabell/homes\"><span>Available at SaBell", "")
					.replace(header, ""),
					"\\d{1},\\d{3} SQ FT|\\d,\\d{3} - \\d,\\d{3} SQ FT|- \\d{1},\\d{3} SQ FT|from \\d,\\d{3} to \\d,\\d{3} sq ft|from \\d,\\d{3} - \\d,\\d{3} sq ft.|\\d,\\d{3} SQFT|SQ FT: \\d,\\d{3}|\\d,\\d{3}\\+ sq ft",0);
			
			
//			U.log("mmmmmm"+Util.matchAll(html+floorPlanHtml+modelHomeHtml+quickHomeHtml+lineUpHtml, "[\\w\\s\\W]{30}1,792[\\w\\s\\W]{30}", 0));
			
			String minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			String maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQFT : "+minSqft+"\t"+maxSqft);
			
			
			//=========== Price ========================
			
			Matcher mat = Pattern.compile("\\$\\d{3}s",Pattern.CASE_INSENSITIVE).matcher(html);
			while(mat.find()){
			//	U.log(mat.group());
				String priceMatch = mat.group().replace("s", ",000");  //$300s
				html = html.replace(mat.group(), priceMatch);
			}
			html =html.replace("THE 500s", "THE 500,000");
			String dropPriceSec=U.getSectionValue(html, "<h5 class=\"price-point\">", "<script>");
			if(dropPriceSec!=null){
				html=html.replace(dropPriceSec, "");
				
				if(quickHomeHtml!=null && quickHomeHtml.contains(dropPriceSec))
					quickHomeHtml=quickHomeHtml.replace(dropPriceSec, "");
				
				if(floorPlanHtml!=null && floorPlanHtml.contains(floorPlanHtml))
					floorPlanHtml=floorPlanHtml.replace(dropPriceSec, "");
			}
			
			if(quickHomeHtml != null){
				String rem  = U.getSectionValue(quickHomeHtml, "<span class=\"qp-price Sold", "<span class=\"qp-price-post");
				if(rem != null) quickHomeHtml = quickHomeHtml.replace(rem, "");
			}
			
//			html=html.replaceAll("flex-sm-column\">$800s</span>", "");
			if(header!=null)
				header = header.replaceAll("<small>s</small>", ",000").replaceAll("0s", "0,000");
			commSec=commSec.replaceAll("x-row flex-sm-column\">$500,000 </span>|>Starting from the<br><span>$500,000</span></h4>", "");
			commSec = commSec.replaceAll("<small>s</small>|s</span>", ",000");
			//U.log("SSSSSSSS"+commSec);
			
//			quickHomeHtml=quickHomeHtml.replaceAll("column\">$800s</span>", "");
			
	//		U.log("mmmmmm"+Util.matchAll(lineUpHtml, "[\\w\\s\\W]{1}826,791[\\w\\s\\W]{1}", 0));
			if(lineUpHtml!=null)
			lineUpHtml=lineUpHtml.replace("flex-row flex-sm-column\">$600,000</span> </span>", "").replaceAll("column\">$600,000</span>|<h3 class=\"\">\\$500,000</h3>|flex-row flex-sm-column\">\\$500,000</span> ", "");
			commSec=commSec.replaceAll("flex-sm-column\">\\$500,000|Starting from the<br><span>\\$500,000", "AA");
			
			String price[] = U.getPrices((html+quickHomeHtml+floorPlanHtml+modelHomeHtml+quickHomeHtml+lineUpHtml+commSec)
					.replace("dollar\">$</span>577,140</span></span> </span>", "dollar\">$577,140</span></span> </span>")
					.replace("$</span>878,966</span></span>", "$878,966</span></span>")
					.replace("flex-sm-column\">$600s</span> ", "").replaceAll("column\">$800s</span>|column\">$800,000</span>|column\">$600,000</span>|column\">$600s</span>|flex-sm-column\">$500,000", "").replace(header, "")
					.replaceAll("flex-sm-column\\\">\\$500,000|Starting from the<br><span>\\$520,000</span></h4>", ""),
					"\\$\\d{3},\\d{3}|price-number\">\\d{3},\\d{3}| FROM THE \\d{3},\\d{3}", 0);
//			U.log("mmmmmm"+Util.matchAll(html+quickHomeHtml+floorPlanHtml+modelHomeHtml+quickHomeHtml+lineUpHtml+commSec, "[\\w\\s\\W]{30}878[\\w\\s\\W]{30}", 0));
			
			//U.log("KKKKKKK"+Util.matchAll((html+quickHomeHtml+floorPlanHtml+modelHomeHtml+quickHomeHtml+lineUpHtml+commSec).replace(header, ""), "[\\s\\w\\W]{30}\\$600[\\s\\w\\W]{30}", 0));
			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("prices : "+minPrice+"\t"+maxPrice);
			
			//========= Community Type ==========================
			
			if(specificationHtml != null)
				specificationHtml = specificationHtml.replaceAll("footer-menu-title\">Single Family|title=\"Single-Family|class=\"navtext\">Single-Family|lincoln-creek\">The Villas|Villas \\+ Towns|Condos \\+ Towns", "");
				if(modelHomeHtml != null)
				modelHomeHtml = modelHomeHtml.replaceAll("ranch\"|Lakewood Ranch|craftsmanship|lakewood-ranch\">Country Club|footer-menu-title\">Single Family|title=\"Single-Family|class=\"navtext\">Single-Family|lincoln-creek\">The Villas|Villas \\+ Towns|Condos \\+ Towns", "");
			
			html = html.replaceAll("/country-club-east|community-nav-box.country-club-east|country-club-east\">|Country Club East<|Enjoy resort-style amenities and the country club lifestyle in this maintenance-free village of Lakewood Ranch|lakewood-ranch\">Country Club", "");
//			amenitiesHtml=amenitiesHtml.replaceAll("community-nav-box.country-club-east", "");
			String commType = U.getCommunityType((html+amenitiesHtml));
			
			U.log("Ctype::"+commType);
			
			//========== Derived Community Type ===================
			if(modelHomeHtml!=null){
				modelHomeHtml = modelHomeHtml.replace("First-floor Master", "1 story")
						.replace("Second-floor bonus room", "2 story bonus room").replaceAll("center\">Townhomes, Ranch-style Villas</span>|Ranch\"| Ranch</span", "");;
			}
			
			html = html
					.replaceAll("2 NEW MODELS COMING SOON!", "")
					.replaceAll("ranch\"|Lakewood Ranch", "");
			U.log("oooo"+Util.matchAll((html+modelHomeHtml+commName+quickData+commSec),"Second Floor", 0));
			
			String dType = U.getdCommType((html+modelHomeHtml+commName+quickData+commSec).replace(header, ""));
			if(commUrl.contains("https://www.cardelhomes.com/denver/communities/sabell"))dType="Ranch, 3 Story";
			if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/bexley"))dType="2 Story, 3 Story";
			//========== Property Type =================
			String singleFamilySec = U.getSectionValue(html, "<a title=\"Single-Family", "</ul>");
			//U.log(singleFamilySec);
			if(singleFamilySec != null && singleFamilySec.contains(commUrl)){  //||singleFamilySec.contains(commName)
				html = html +" Single-Family Homes";
			}

			String condoTownSec = U.getSectionValue(html, "<a title=\"Condos", "</ul>");
			if(condoTownSec != null){
				if(condoTownSec.contains(commUrl) ){  //|| condoTownSec.contains(commName)
					html = html +" Condo ";
				}
			}
			html = html.replace("footer-menu-title\" stunning Town Home", "").replaceAll("Villas \\+ Towns|Condos</li>|>Condos|title=\"Condos|Townhomes</li>|Townhomes</a>|The Villas|Multi-Family</li>|-multifamily|/multifamily|Family</li>|Family</a>|Family</span|title=\"Single|/condos/|singlefam\"></span> Single|itle\">Single|#\">Single", "");
			
//			
			html=html.replaceAll("HenleyTraditionalCottage.png|Island lots available|lakewood-\">Country Club|Villas \\+ Towns|ISLAND LOTS AVAILABLE|Condos \\+ Towns", "");//.replaceAll("\\+ Towns", "stunning Town Home design")
			
			html = html.replace("multi-generational", "multi-generational option")
					.replace("this luxurious, green community", "this luxury homes, green community");
			
			
		
			
			quickData=quickData.replaceAll("traditional|European Cottage|>Tuscan Cottage<|Tuscan Cottage Entry|TuscanCottage|TuscanCottage|-cottage-entry|European Cottage Entry|EuropeanCottage|_Mediterranean|>Traditional Cottage|>Traditional Cottag|-Mediterranean| - Mediterranean|>Mediterranean</h2>|_TradCottage_|- Traditional Cottage|Traditional", "");
			
//			U.log("mmmmmm"+Util.matchAll(quickData, "[\\w\\s\\W]{30}Traditional[\\w\\s\\W]{30}", 0));
			
			html=html.replaceAll("promos-single-family|keelcondos-floor|blackstone-condos|.townhome .|townhome-page|heading-condos|condos-page", "");
//			U.log("LLLLL"+Util.match((html+specificationHtml+modelHomeHtml+quickData),"luxurious home"));
			String propertyType = U.getPropType((html+specificationHtml+modelHomeHtml+quickData)
					.replaceAll("center\">Townhomes</span> </span> <span|flex-sm-column\">Townhomes <br class=\"d-none|promos-single-family|keelcondos-floor|blackstone-condos|.townhome .|townhome-page|heading-condos|condos-page", "")
					.replace("craftsman quality", "Craftsman style details").replace(header, "")
					.replaceAll("townhome-page|No CDD and low HOA|no HOA|lakewood-ranch|ranch\"|Lakewood Ranch|center\">Single Family, Townhomes</span>|center\">Single Family</span>|no HOA or CDD|No CDD and low HOA", "")+commSec.replaceAll("No CDD and low HOA|no HOA",""));
			
			if(commUrl.contains("https://www.cardelhomes.com/denver/communities/the-ridge"))
			{
				if(propertyType.contains("Single Family"))
				{
					propertyType=propertyType.replace("Single Family", "    ");
				}
			}
//			U.log("mmmmmm"+Util.matchAll(specificationHtml+modelHomeHtml, "[\\w\\s\\W]{30}condo[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(specificationHtml+modelHomeHtml, "[\\w\\s\\W]{30}single-family[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(specificationHtml+modelHomeHtml, "[\\w\\s\\W]{30}Townhome[\\w\\s\\W]{30}", 0));
			
			U.log("PType::"+propertyType);
		
//			U.log(Util.matchAll((html+specificationHtml+modelHomeHtml).replace(header, ""), "HOA", 0));
			
			if(propertyType.contains("Townhouse") && propertyType.contains("Townhome")){
				propertyType = propertyType.replace("Townhouse,", "");
			}
			//============ Property Status ============
			/*html = html.replaceAll("FINAL PHASE OF PRESERVE <br class=\"hidden-sm  hidden-xs\" />HOMESITES JUST RELEASED", "FINAL PHASE OF HOMESITES JUST RELEASED")
					.replace("content=\"FINAL PHASE OF PRESERVE HOMESITES JUST", "");*/
			html=html.replace("flex-sm-column\">Now Selling!</span>", "")
					.replace("h2.coming-soon", "").replace("coming-soon text-center", "")
					.replace("Waterfront, golf &#038; private lots available", "Waterfront lots available").replaceAll("Only 4 exceptional lots left", "Only 4 Lots Left").replaceAll("0\">FINAL PHASE OF PRESERVE|Island lots available|oming soon! PARKS |Coming soon!</h4>|homes now open!|About FINAL PHASE OF PRESERVE|New Model<br>coming soon|New Modelcoming soo|models coming Spring 2019|opening Summer 2018!|2 NEW MODELS COMING SOON!|<span>coming soon!</span>", "").replaceAll("Only 8 amazing lots available", "Only 8 lots available");
//	        U.log("mm"+Util.matchAll(html+ commSec, "[\\w\\s\\W]sell[\\w\\s\\W]", 0));

//			U.log(commSec);
			commSec=commSec.replaceAll("margin-top-10 m-0\">Coming Soon|>Now selling!|flex-sm-column\">Now Selling!</span>|font-weight-bold\">Now selling!</h2><h4", "");
			String propertyStatus = U.getPropStatus((html+ commSec)
					.replace("Another successful community sold out!", "Another successful sold out!")
					.replaceAll("limited-time offer|[Q|q]uick [M|m]ove|margin-top-10\">Limited opportunities remain|column\">Coming Soon</span>|class=\"coming-soon|-block\">Now Selling!</span>|premier final|Model home coming soon|Sales Center coming soon|One-acre lots available|Island lots available|>Coming Soon!</h3><h4>Nature playground", ""));
//			U.log("mmmmmm"+Util.matchAll(html, "[\\w\\s\\W]{30}Now Selling[\\w\\s\\W]{30}", 0));
//			U.log("mmmmmm"+Util.matchAll(commSec, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{1}", 0));
			U.log("propertyStatus: "+propertyStatus);
//			FileUtil.writeAllText("/home/shatam-10/Desktop/data/sectionss.txt", commSec);
			
//			if(quickPossUrl.length()>4){
//				
//				U.log("quickPossUrl===="+quickPossUrl);
//				String qhtml = (quickPossUrl.contains("quick-move")) ? U.getHTML(quickPossUrl):ALLOW_BLANK;
//				if(!qhtml.contains("We do not currently have any quick move-in homes")) {
//				String[] soldCount = U.getValues(qhtml, "<span class=\"status-bg s\">", "Sold <span>");
//				U.log(soldCount.length);
//				
//				
//				String[] saleCount = U.getValues(qhtml, "qp-price-post-info-container", "View Listing</span>");
//				U.log(saleCount.length);
//				//FileUtil.writeAllText("/home/shatam-10/Desktop/data/qhtml.txt", jsonSection);
//				
//				if(U.getHTML(quickPossUrl).contains("View Listing</span>") && quickPossUrl.contains("/quick-closing")){
//					if(propertyStatus.length()<4)propertyStatus = "Quick-Closing Home";
//					else propertyStatus = propertyStatus + ", Quick-Closing Home";
//				}
//				
//				else if(U.getHTML(quickPossUrl).contains("View Listing</span>") && saleCount.length>soldCount.length){//!U.getHTML(quickPossUrl).contains("Sold <span>")
//					if(propertyStatus.length()<4)propertyStatus = "Quick Move-ins";
//					else propertyStatus = propertyStatus + ", Quick Move-ins";
//				}}
//			}
			
			
			if(quickPossUrl.length()>4&&flag){
					propertyStatus = propertyStatus.replace("Quick-Possession Home", "Quick-Closing Home");
			}
			
			

			//U.log(html);
			//============= Notes ==================
			String notes = U.getnote(html.replace("https://maps.google.com/maps?q=Pre-selling+by+ap", "").replaceAll("Pre-selling by appointment", ""));

			
			if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/laureate-park-in-lake-nona")) {
				
					
					String addsec = "13551 Nemours Pkwy, Orlando, FL 32827";
					add = U.getAddress(addsec);
					
					String [] latlng = U.getlatlongGoogleApi(add);
					if(latlng == null) latlng = U.getlatlongHereApi(add);
					lat = latlng[0];
					lng = latlng[1];
					geo = "True";
					
					
				
			}
			
//			//3160 S. Falkenburg Rd
//			//Riverview, FL 33578
//			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
//				if(lat == ALLOW_BLANK && lng == ALLOW_BLANK){
//					add = U.getAddress("3160 S. Falkenburg Rd, Riverview, FL 33578");
//					String [] latlng = U.getlatlongGoogleApi(add);
//					if(latlng == null) latlng = U.getlatlongHereApi(add);
//					lat = latlng[0];
//					lng = latlng[1];
//					geo = "True";
//					notes = "Address & LatLng Taken From Contact Us";
//				}
//			}
			//=========== From Images ==================
			if(commUrl.contains("http://www.cardelhomes.com/denver/communities/towns/solterra")){
				minPrice = "$413,400";
				maxPrice = "$423,400";
			}
			if(commUrl.contains("http://www.cardelhomes.com/tampa/communities/lakewood-ranch"))//https://www.cardelhomes.com/denver/communities/lincoln-creek
				minPrice = "$520,000";
			if(commUrl.contains("https://www.cardelhomes.com/denver/communities/lincoln-creek")) {
				minPrice ="$500,000";//img				
			}
			
			if(commUrl.contains("http://www.cardelhomes.com/tampa/communities/bexley"))
				propertyStatus += ", Now Selling";
			//https://www.cardelhomes.com/tampa/communities/bexley

			//From Lots Map
			if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/the-preserve-at-fishhawk-ranch"))
				propertyStatus += ", Only 2 Lots Left";

			
			if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/oakwood-reserve"))propertyType = ALLOW_BLANK;
			
			if(commUrl.contains("http://www.cardelhomes.com/tampa/communities/fishhawk-ranch"))
				propertyStatus = "Last Chance, Only 3 Quick-Possession Homes Remaining";
		if(commUrl.contains("/westminster-station/")){
			propertyType="Single Family";
		}
//		if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/bexley")) {
//			
//			propertyType+=", Craftsman Style Homes, Traditional Homes, Cottage";
//		}
//		
//		if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/bexley")) {
//			propertyType+=", Craftsman Style Homes, Traditional Homes, Mediterranean Style Homes";
//			dType="2 Story";
//			maxSqft="3939";
//		}
//		if(commUrl.contains("https://www.cardelhomes.com/denver/communities/sabell")) minPrice="$600000";
		
		if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/worthington"))propertyType+=", Flex Homes";
//		if(commUrl.contains("https://www.cardelhomes.com/tampa/communities/worthington"))propertyStatus=ALLOW_BLANK;
		
		//--------------------------------------Unit Counts-------------------------------
		
			String counting=ALLOW_BLANK; String startDt=ALLOW_BLANK; String endDt=ALLOW_BLANK;
			String mapdata = ALLOW_BLANK; String totalUnits = ALLOW_BLANK; 
			
			if(html.contains(">Lot Maps<")) {
				
				String lotUrl = commUrl + "/lot-maps";
				U.log("lotUrl: "+lotUrl);
				
				if(lotUrl != null) {
					
					mapdata = U.getHtml(lotUrl, driver);
					
					if(mapdata.contains("<g id=\"lot-")) {
						
						ArrayList<String> pins = Util.matchAll(mapdata, "<g id=\"lot-\\d+\"", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}
					
					if(commUrl.contains("/communities/westminster-station")) {
						
						ArrayList<String> pins = Util.matchAll(mapdata, "<g id=\"lot-\\d+-\\d+\"", 0);
						U.log("Count Pins: "+pins.size());
						totalUnits = String.valueOf(pins.size());
					}
				}
			}
			
			
			
		//--------------------------------------------------------------------------------
			
			propertyStatus=propertyStatus.replace("Now Sold Out", "Sold Out");
			data.addCommunity(commName.trim(), commUrl, commType);
			data.addAddress(add[0].replace("2420 CLEMENT ROAD", "2420 Clement Road"), add[1].replace("LUTZ", "Lutz"), add[2].trim(), add[3]);
			data.addLatitudeLongitude(lat, lng, geo);
			data.addPropertyType(propertyType, dType);
			data.addPropertyStatus(propertyStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addNotes(notes);	
			data.addUnitCount(counting);
			data.addConstructionInformation(startDt, endDt);
			
		}j++;
//	}catch(Exception e){}
	}
}