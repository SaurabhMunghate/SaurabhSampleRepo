package com.shatam.b_301_324;

import java.util.Arrays;

/**@author Chinmay.
 * Date- 10-08-2017
 * 
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractChafinCommunities extends AbstractScrapper{
	static String builderName="Chafin Communities";
	static String builderUrl="https://www.chafincommunities.com";
	CommunityLogger logger;
	static int dupli=0;
	WebDriver driver=null;
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper abs=new ExtractChafinCommunities();
		abs.process();

		FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abs.data().printAll());
	}
	public ExtractChafinCommunities()
			throws Exception {
		super(builderName, builderUrl);
		logger=new CommunityLogger(builderName);
	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		
		String mainHtml=U.getHTML(builderUrl+"/communities/");//var newlatlng
		String mainSec=U.getSectionValue(mainHtml, "<map name='map'>", "</map>");
		//U.log(mainSec);
		String commName=ALLOW_BLANK;
		String commURL=ALLOW_BLANK;
		String[] commDATA=U.getValues(mainHtml, "communities_list_single", "grid-100 tablet-grid-100");
//		U.log(commDATA.length);
		int i=0;
		for (String community : commDATA) {
//			U.log("-------------------------------------"+i+"-------------------------------------");
			community=community.replaceAll("0's", "0,000");
			community=community+"\"";
			
			commName=U.getSectionValue(community, "data-name=\"", "\"").replace("&#8217;", "'").replace("&#8211;", "-");
			commURL=U.getSectionValue(community, "href=\"", "\"");
//			U.log(commURL);
//			U.log("URL:\t" + commURL);
//			U.log(U.getCache(commURL));
			
//			try {
				addDetails(community,commName,commURL);
//			} catch (Exception e) {}
				i++;
		}
		logger.DisposeLogger();
//		try{driver.quit();}catch (Exception e) {}
	}
	int j = 0;
	private void addDetails(String community, String commName, String commURL) throws Exception {
		//TODO ::
//		try{
		
		
//		if(!commURL.contains("https://www.chafincommunities.com/communities/georgia/hall/oakwood-georgia/silver-fox-reserve/"))return;
		
		{
		//try {
			
			U.log("\n"+"COUNT="+j+":::::::::::::::::::::::::::::::::::"+"\n");
			if (data.communityUrlExists(commURL)) {
				logger.AddCommunityUrl(commURL+"***********************repeated");
				dupli++;
				return;
			}
			if(commURL.contains("https://www.chafincommunities.com/communities/georgia/jackson/braselton-jackson-county/township-at-mulberry-park")) {
				logger.AddCommunityUrl(commURL+"========return");
				return;
			}
			
			logger.AddCommunityUrl(commURL);
			U.log("url ::"+commURL);
			String Geo="False";
			String commHTML=U.getHtml(commURL, driver);
			String commHTML1 = commHTML;
			String latLonSec="";
			U.log("community name ::  "+commName);
			commName=commName.replace("- The Enclave &#038; The Estate", "");
			if (commHTML.contains("View Map")) {
				
				latLonSec=U.getSectionValue(commHTML, " <div id=\"contact\"></div>", "View Map");
				if (latLonSec==null) {
					latLonSec=U.getSectionValue(commHTML, "class=\"fa fa-map-marker\"", "View Map");
				}
			}
			//U.log(latLonSec);
			String[] latLon={ALLOW_BLANK,ALLOW_BLANK};
			if (latLonSec!=null) {
				latLon[0]=Util.match(latLonSec, "\\d{2,3}.\\d{5}");//U.getSectionValue(latLonSec, "/dir//", ",");
				latLon[1]=Util.match(latLonSec, "-\\d{2,3}.\\d{5}");;//U.getSectionValue(latLonSec, latLon[0]+",", "\"");
			}
			
			U.log("lat "+latLon[0]+" lon "+latLon[1]);
			if(latLon[0] == null && latLon[1] == null){
				String latLongSec = U.getSectionValue(latLonSec, "sll=", "&amp;");
				latLon = latLongSec.split(",");
			}
			
			//============ Remove Nearby ==============
			String rem = U.getSectionValue(commHTML, "Nearby Communities</h2>", "View All Communities</a>");
			if(rem != null) commHTML = commHTML.replace(rem, "");
			rem = U.getSectionValue(commHTML, "<div id=\"home_featured", "Bonuses!</a></p>");
			if(rem != null) commHTML = commHTML.replace(rem, "");
			
			
			String availableHomeData="";
			String availableHomeUrl[]=null;
			String availableHomesDataSec=U.getSectionValue(commHTML, "single_community_available_homes_wrapper", "<script type=\"text/javascript\">");
			if(availableHomesDataSec != null) availableHomesDataSec = U.removeComments(availableHomesDataSec);
			if(availableHomesDataSec!=null) {
				availableHomeUrl=U.getValues(availableHomesDataSec, "href=\"", "\">");
				for (String url : availableHomeUrl) {
					if(url != null || url != "") {
						
						if(url.contains("maps.google.com/maps/dir") || url.equals("https://www.chafincommunities.com/"))continue;
						if(url.contains(".pdf") || url.endsWith("/communities/") || url.contains("data-layout=") || url.contains(" target=") || url.contains("/privacy-"))continue;
						if(url.contains("/about-us/") || url.contains("/sales-") || url.contains("class=\"") || url.contains("contact") || url.contains("/home-buying")) continue;
						if(url.contains("page_id=20") || url.contains("careers/") || url.contains("communities-new-construction-homes/") || url.contains("shop-for-a-new-home-on-line/") || url.contains("facebook") || url.contains("youtube") || url.contains("pinterest") || url.contains("/button/") || url.contains("/the-american-dream-series")) continue;
						U.log("availableHomeUrl ===="+url);
						
						
					if(url.contains("/move-in-ready-homes/?gamlsid="))
						
						
					if( !url.contains("https://www.chafincommunities.com")) {
			          availableHomeData +=U.getHTML("https://www.chafincommunities.com"+url);
					}else {
						 availableHomeData +=U.getHTML(url);
					}
				}
				//availableHomeData+=U.getSectionValue(HomeData, "<p>", "</p>");
			}
			}
			String[] price={ALLOW_BLANK,ALLOW_BLANK};
			
//			U.log(community);/////////////////////////
			
			//<span class="inv_price">$542,719</span>
			String remSec=U.getSectionValue(commHTML, "<h2>Nearby Communities</h2>", "View All Communities");
			String tempSec=U.getSectionValue(commHTML, "<small>", "</small>");
			//U.log(tempSec);
			if (remSec!=null) {
				commHTML=commHTML.replace(remSec, "");
				//U.log(commHTML);
			}
			commHTML=commHTML.replaceAll("00's's|00's|00s|00�s|0™s|00’s", "00,000");
			community=community.replaceAll("0's|0s|0’s|0's's", "0,000").replace("From High $500™s to $800™s ", "From High $500,000 to $800,000 ");
			//U.log(community);
			price=U.getPrices((commHTML+community).replaceAll("=\"(.*)?\"", ""), 
					"From th e\\$\\d{3},\\d{3}|From High \\$\\d{3},\\d{3}|<strong>\\$\\d{3},\\d{3}</strong>BASE PRICE|Mid \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}| \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3} in |From High \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|low \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|LOW \\$\\d{3},\\d{3} to Mid \\$\\d{3},\\d{3}|From Mid \\$\\d{3},\\d{3}|From the Low \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}-\\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|From the \\$\\d{3},\\d{3}( - \\$\\d{3},\\d{3})?|<span class=\"inv_price\">\\$\\d{3},\\d{3}</span>|<h2>\\$\\d{3},\\d{3}</h2>|From \\$\\d{3},\\d{3}|High \\$\\d{3},\\d{3} - \\$\\d{3},\\d{3}|From the Mid \\$\\d{3},\\d{3}|From the High \\$\\d{3},\\d{3}|Low \\$\\d{3},\\d{3}|From the \\d{3},\\d{3}", 0);
			U.log("min "+price[0]+" max "+price[1]);
			String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
//			U.log("<<<<<<<<<<<<<<<<<<< "+Util.matchAll(commHTML+community, "[\\w\\s\\W]{50}\\$354,990[\\w\\s\\W]{30}", 0));
			
			String[] address={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String addressSec=U.getSectionValue(latLonSec, "<i class=\"fa fa-map-marker\" aria-hidden=\"true\"></i>", "</span>");
			if (addressSec==null) {
				addressSec=U.getSectionValue(latLonSec, "</i>", "</span");
			}
			if (addressSec!=null) {
				//U.log(addressSec+"hello");
				U.log(addressSec);
				addressSec=addressSec.replaceAll("<br />|<br>", ",").replace("3013 GA Hwy 324/Gravel Springs Rd", "3013 GA Hwy 324");
				address=U.getAddress(addressSec);
				String[] tempadd=address[0].split(",");
				address[0]=tempadd[0].replaceAll("\\(.*\\)", "");
				U.log("Add =="+Arrays.toString(address));				
			}
			
			if (address[0]==ALLOW_BLANK||address[1]==ALLOW_BLANK||address[2]==ALLOW_BLANK||address[3]==ALLOW_BLANK||address[0]==null||address[1]==null||address[2]==null||address[3]==null) {
				if (latLon[0]!=null||latLon[0]!=ALLOW_BLANK||latLon[1]!=null||latLon[1]!=ALLOW_BLANK) {
					address=U.getAddressGoogleApi(latLon);
					if(address == null) address = U.getAddressHereApi(latLon);
					Geo="True";
				}
			}
			U.log(latLon[0]);
			if (address[0]!=null&&(latLon[0].length()==0||latLon[0]==ALLOW_BLANK||latLon[0]==null)) {
				latLon=U.getlatlongGoogleApi(address);
				if(latLon == null) latLon = U.getlatlongHereApi(address);
				Geo="True";
			}
			U.log("Street "+address[0]+" City "+address[1]+" State "+address[2]+" Zip "+address[3]);
			if (availableHomeData!=null) {
				availableHomeData=availableHomeData.replaceAll("Flowery Branch|branch|ideal home! RANCHES &amp; 2 Sto", "");
			}
//			U.log(Util.matchAll(availableHomeData, ".*RANCH.*",0));
			commHTML = commHTML.replace("</strong>STORIES</p>", " Stories");
			String dType=U.getdCommType((availableHomeData+commHTML).replace("story 4 bedroom", "story").replaceAll("First floor|First Floor|first floor", ""));
			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(availableHomeData+commHTML, "[\\s\\w\\W]{30}story[\\s\\w\\W]{30}", 0));

			
			commHTML  = commHTML.replace("golfing", "golf course").replace("elegant traditional brick", "traditional-style brick homes");
			String commType=U.getCommType((commHTML+community).replaceAll("Gated Park|Elongated|Bear™s Best Golf &amp; Country Club", ""));
			
			//Page doesn't content any square feet this just dummy
		//	String dataval[]=U.getValues(commHTML, "single_community_available_homes_listing_info", "</div>");
			///floor=============
			String floorurl=commURL+"#plans";
			String floorhtml=U.getHtml(floorurl,driver);
			
			
			
			
			String[] sqFt=U.getSqareFeet(commHTML+availableHomeData, "\\d,\\d{3} square feet|about \\d,\\d{3} sf by|square footage from \\d{4}-\\d{4}|<div>\\d{4} SQ.FT.</div>|<p>SqFt:\\s+\\d{4}</p>|SqFt:\\s+\\d{4}\\s+-\\s+\\d{4}|\\s+<p>\\d{3,4}</p>\\s+", 0);
			String minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			String maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			commHTML=commHTML.replace("New phase of Mulberry Park now open!", "New phase now open! of Mulberry Park ");
			commHTML=commHTML.replace("Traditional 2 story homes", "Traditional homes 2 story");
			commHTML = commHTML.replaceAll("upgrade and customize your home|Open Daily|OPEN DAILY|Center Opening", "");
			commHTML=U.removeSectionValue(commHTML, " <i class=\"fa fa-clock-o", "</span>");
			//U.log(commHTML);
			if (commHTML.contains("<div id=\"about\"></div>")) {
				//U.log("IDHAR HI HU");
				//U.log(U.getSectionValue(commHTML, "<div id=\"about\"></div>", "</div>"));
			}
			//===============PROPERTY TYPE=====================================
			
			commHTML=commHTML.replace("modern-farmhouse/\">Modern Farmhouse by Chafin", "");
			availableHomeData=availableHomeData.replace("modern-farmhouse/\">Modern Farmhouse by Chafin", "");

			String propType=U.getPropType((commHTML+community+availableHomeData).replace("Traditional 2 Story", "Traditional exterior 2 Story")
					.replaceAll("Clubhouse-Rear-Courtyard|ar-Courtyard-Walk-to-Outdoor-700x400|Courtyard-1333x800.jpg|ar-Courtyard-700x400.jpg|Modern Farmhouse By Chafin|townhome(s)\\.\"|carriage style garage doors|Cabin Dr|Owner's suite features luxurious ", "")); //+community+availableHomeData
//			U.log(">>>>>>>>>>>>"+Util.matchAll(commHTML, "[\\s\\w\\W]{30}Courtyard[\\s\\w\\W]{30}", 0));			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(community, "[\\s\\w\\W]{30}Courtyard[\\s\\w\\W]{30}", 0));			
//			U.log(">>>>>>>>>>>>"+Util.matchAll(availableHomeData, "[\\s\\w\\W]{30}Courtyard[\\s\\w\\W]{30}", 0));			


			//===============PROPERTY STATUS=====================================
			commHTML = commHTML.replaceAll("Opening in Spring of 2020|Opening in Spring of 2020", "Opening Spring 2020").replaceAll("/move-in-ready-homes/", "")
					.replace("Opening in Fall of 2020", "Opening Fall 2020")
					.replace("Opening in Fall of 2019", "Opening Fall 2019");
			 commHTML=commHTML.replaceAll("new amenities are now open|new amenities now open", "");
			String propStatus=U.getPropStatus((community.replaceAll("amenities now open|Move-in |amenities are now open", "")+commHTML.replace("amenities now open|amenities are now open|ComingSoon_2018_JC", "Coming Soon")
			.replaceAll("data-key=\"Coming Soon|span>Coming Soon &nbsp|data-status=\"Coming Soon|by Chafin Communities Now Selling|by Chafin Communities Now Selling</title>|Communities Now Selling\">|Communities Now Selling\" />| data-key=\"Coming Soon\"></span>Coming Soon|<p><span style=\"font-family: arial, helvetica, sans-serif;\">Sold Out!</span>|Move In Ready Homes</a>|caption\":\"Now Selling|Coming Soon! |\"description\":\"Coming Soon|Coming Soon!\\s+Holman Forest|content=\"Coming Soon|Move-in|selling out of our Model Home|Sales Center to Open late Fall 2017|over half sold |several communities now|Move-In", "")).replace("selling fast. Call", "").replaceAll("move|Move|MOVE", ""));

			

			
			if(commURL.contains("https://www.chafincommunities.com/communities/georgia/gwinnett/hoschton/holman-forest-hoschton-ga/"))
				propStatus = propStatus.replace(", Sold Out", "");
			if(commURL.contains("https://www.chafincommunities.com/communities/georgia/gwinnett/loganville-gwinnett/central-park/"))
				propStatus="Now Selling";
			if(commURL.contains("https://www.chafincommunities.com/communities/georgia/walton/loganville/enclave-at-logan-point/"))
				propStatus="Now Selling";
			if(commURL.contains("https://www.chafincommunities.com/communities/georgia/state/city/silver-fox-reserve/"))
				propStatus=ALLOW_BLANK;
			
			int q=0;
			String quickHTML="";
			for(int k=1 ;k<=6;k++) {
				quickHTML+=	U.getHTML("https://www.chafincommunities.com/move-in-ready-homes/?searchpage="+k);
				U.log(k);
			}
			int noq=0;
//			String quickHTML=U.getHTML("https://www.chafincommunities.com/move-in-ready-homes/")
//					+U.getHTML("https://www.chafincommunities.com/move-in-ready-homes/?searchpage=2")
//					+U.getHTML("https://www.chafincommunities.com/move-in-ready-homes/?searchpage=3");
			String quickData[]=U.getValues(quickHTML, "_community_available_homes_listing\"", "View Details</a>");
			U.log("quickData====="+quickData.length);
			
			int totalcn=quickData.length;
//			String[] quickArray=U.getValues(quickHTML, "<div class=\"grid-60 mobile-grid-60 grid-parent\">", "</p>");
//			for(String qSec:quickArray) {
//				if(qSec.contains("")) {
//					
//				}
//			}
			for(String quickdata :quickData ) {
				if(quickdata.contains(commName)) 
				{
					U.log("Yes");
					q++;
				}
				if(quickdata.contains("Under Contract")) { //data-status=\
					noq++;
				}
			}
			
			U.log("q Cnt "+q);
			U.log("NO Q: "+noq);
			
			if (commHTML1.contains("<h2>Available Homes</h2>") && noq<totalcn && !commHTML1.contains("See onsite agent for Current Listings</h3>")) //if (q>0)
			{
				if (propStatus.length()>2) {
					propStatus+=", Move In Ready Homes";
				}else {
					propStatus="Move In Ready Homes";
				}
			}
				
			
			if(commURL.contains("gainesville/overlook-at-marina-bay/"))propType = propType.replace(", Homeowner Association", "");//==remm

			propStatus=propStatus.replace("Now Selling, Currently Selling", "Now Selling");	
			
			address[0]=address[0].replace("3013 GA Hwy 324/Gravel Springs Rd", "3013 GA Hwy 324");

			String note=ALLOW_BLANK;
			note=	U.getnote(commHTML.replace("data-note=\"PRESALE LOT OPEN\"", "")
					.replace("data-note=\"PRESALE LOT\"", "")+community);
			
//				 U.log("ZZZZ"+Util.matchAll((commHTML+community),"[\\w\\W\\s]{40}Presale[\\w\\W\\s]{40}", 0));

			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			String [] lotData=U.getValues(commHTML, "<div class=\"siteplan_point status", "</div>");
			
			if(lotData.length>0) {
				units=Integer.toString(lotData.length);
			}
			
			
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);	
			data.addCommunity(commName, commURL, commType);
			data.addAddress(address[0], address[1], address[2], address[3]);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPrice(minPrice, maxPrice);
			data.addLatitudeLongitude(latLon[0].trim(), latLon[1].trim(), Geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(note);
		
	}
		j++;
//		}catch(Exception e){}
	}

}