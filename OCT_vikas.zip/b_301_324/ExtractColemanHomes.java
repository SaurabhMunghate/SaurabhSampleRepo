/**
 * 
 *Modification Aditya..
 @Author Name-Gourav Gujar
 */
package com.shatam.b_301_324;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.USStates;
import com.shatam.utils.Util;

public class ExtractColemanHomes extends AbstractScrapper {
	static String BASEURL = "https://www.mycolemanhome.com";
	CommunityLogger LOGGER;
	static int j=0;
	/**
	 * @param args
	 * @throws Exception
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractColemanHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Coleman Homes.csv", a.data().printAll());
	}

	public ExtractColemanHomes() throws Exception {

		super("Coleman Homes", BASEURL);
		LOGGER = new CommunityLogger("Coleman Homes");
	}

	public void innerProcess() throws Exception {
		String html = U
				.getHTML("https://www.mycolemanhome.com/idaho-communities/");
//		String urlsection = U.getSectionValue(html,
//				"tabindex=\"0\">Communities<span",
//				"Design Studio</a><");
		String urls[] = U.getValues(html, "<li class=\"floorplan-grid community\">", "</li>");
	//	LOGGER.countOfCommunity(urls.length);
		for (String url : urls) {
			
			String curl = U.getSectionValue(url, "href=\"", "\"");

			addDetails(curl,url);
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String url,String commData) throws Exception {
//		if(j>=11)
		{
			
		// .......................Community Url...........................
//https://www.mycolemanhome.com/idaho-communities/the-meadows-at-west-highlands/			
		//	if (!url.contains("https://www.mycolemanhome.com/idaho-communities/sterling-ranch"))return;
			
		if(url.contains("https://www.mycolemanhome.com/idaho-communities/the-oaks/")) {
			LOGGER.AddCommunityUrl(url + "\t*********Redirected******\t");
			return;
		}
		U.log(j+"==" + url);
		U.log("ppppppppp"+commData);
		// ......................Community Name...........................
		String html = U.getHTML(url);
		
		String dropSec=U.getSectionValue(html, "<head>", "</head>");
		html =html.replace(dropSec, "");
		
		String commName = U.getSectionValue(commData, "<h2>", "<");
		U.log(commName);
		if (this.data.communityUrlExists(url)) {
			LOGGER.AddCommunityUrl(url + "\t*********Repeated******\t");
			return;
		}
		LOGGER.AddCommunityUrl(url); 

		// ..............Community type, Property status,Derived property
		// type,Property type...........................
		String rem=U.getSectionValue(html, "getMarkerImage(name)","Sales Center</li>");
		String typeHtml=html;
		
	
		
		//========= Community type ===================
		
		html =html.replaceAll("Spurwing Golf Course|Golf Course - 10 minutes|disc golf|Purple Sage Golf Course|Lakeview Golf Course|RedHawk Golf Course", "");
		html=U.removeSectionValue(html, "<h3>What's Nearby</h3>", "</div>");
		String communitytype = U.getCommunityType(html);
		U.log(communitytype);
		
		//==================== floor plan Home ============
		String planhtml="";
		String[] plans=U.getValues(html, "<a href=\"https://www.mycolemanhome.com/floorplans", "\"");
		U.log("Floor Homes count =: "+plans.length);
		String secPlan =ALLOW_BLANK;
		for(String plan:plans){
			U.log(plan);
			planhtml=U.getHTML("https://www.mycolemanhome.com"+plan);
//			U.log(U.getSectionValue(planhtml, "<div class=\"entry-content\">", "div class=\"includes-and-options\">"));
			secPlan += U.getSectionValue(planhtml, "<div class=\"entry-content\">", "div class=\"includes-and-options\">");
		}
		//============ Quick Home Section =================

		
		String quickHtml="";
		String[] quicksUrls=U.getValues(html, "<a href=\"https://www.mycolemanhome.com/home", "\"");
		U.log("Quick Home count=: "+quicksUrls.length);
		for(String quickurl:quicksUrls)	{
			U.log("quickurl : "+quickurl);
			quickHtml+=U.getHTML("https://www.mycolemanhome.com/home"+quickurl);
			U.log("qqqq"+quickurl);
		}
		
		String modelHomes ="";
		String[] modelUrls=U.getValues(html, "a href=\"https://www.mycolemanhome.com/model-homes/", "\"");
		U.log("Quick Home count=: "+modelUrls.length);
		for(String model:modelUrls)	{
			U.log("quickurl : "+model);
			modelHomes+=U.getHTML("https://www.mycolemanhome.com/model-homes/"+model);
			U.log("qqqq"+model);
		}
		
			
		
		//===================== Derived Community Type ===============
		String dtype = U.getdCommType((html+planhtml+quickHtml+modelHomes+secPlan.replaceAll("CARRIAGE HILL NORTH", "").replaceAll("CARRIAGE HILL NORTH\">", "")+quickHtml).replaceAll("value=\".* Ranch\"|Cartwright Ranch</|Sterling Ranch</| // Sterling Ranch|// Cartwright Ranch|CartwrightRanch\":|SterlingRanch\":|Sterling Ranch Sales Center", ""));
		U.log(dtype);
		
		commData=commData.replaceAll("now-selling", "now selling");
		//========== Property Status =============
		
		typeHtml = typeHtml.replace("Just a few opportunities remain", "Just few opportunities remain").replaceAll(" community pool, coming soon| Model Homes Coming Soon|\\(Open Fall 2018\\)</li>|School</a>\\s*\\(Open Fall 201|href=\"/move-in-ready-homes/\">- Move In Ready Homes</option>|This new phase|>Move In Ready Homes</a></li>|</i>\\s+Available|<!-- Available|>View Available|Directions</h2>\\s+<p>COMING", "")
				.replace("NEW Star Middle School (Open Fall 2018)</a", "");
		String propstatus = U.getPropStatus((typeHtml+commData).replace("fully-decorated models and a wide selection of Move-In Ready homes", "").replace("Move-in Ready", "").replaceAll("homesites and Move-In Ready homes|Limited availability\\. Please call", ""));
		U.log(propstatus);
		

		// ..........................Address and Lat , Lng ..................................

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK }, lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;

		String addSec = U.getSectionValue(html, "<h2>Sales Center Directions</h2>", "<b>");
		U.log(addSec + "------");
		
		if (addSec != null) {
			addSec = U.getSectionValue(addSec, "<p>", "</p>").trim();
			geo = "FALSE";
			addSec = addSec.replaceAll("<br/>|<br />", ",").replace("Nampa", "Nampa,").replace("Nampa,,", "Nampa,");
			U.log("-------------------------------" + addSec);
			String[] addr=addSec.replaceAll("NOW SELLING! Located at the Lilac Springs Sales Center at the|SALES OFFICE &amp; DECORATED MODEL NOW OPEN!|Call for an appointment.|, Nampa Idaho 83687|\\(Can-Ada Road, south of Ustick Road, north of Cherry\\)", "").replaceAll("NOW SELLING!|COMING SOON!", "").split(",");
			U.log(Arrays.toString(addr));
			if(addr.length>2)
			{
			add[0]=addr[0].replace("&amp;", "&").trim();
			add[1]=addr[1].trim();
			add[3]=Util.match(addr[2], "\\d{5}");
			if(add[3]!=null)
			add[2]=addr[2].replace(add[3], "");
			}
		}
		U.log(Arrays.toString(add));

		String latlng_section = U.getSectionValue(html,	"center: new google.maps.LatLng", "};");
		U.log(latlng_section);
		if(latlng_section!=null) {
		lat = U.getSectionValue(latlng_section, "(", ",").trim();
		lng = U.getSectionValue(latlng_section, ",", ")").trim();
		}
		if(latlng_section==null) {
			lat = U.getSectionValue(html, "data-lat=\"", "\"");
			lng = U.getSectionValue(html, " data-lng=\"", "\"");
			if(lat==null)lat="-";
		}
		U.log(lat + "===========" + lng);
		String latlng[] = { lat, lng };

		if(latlng[0].equals("0") || latlng==null || latlng[0]==ALLOW_BLANK){
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			geo="TRUE";
		}
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
			if(latlng[0] != ALLOW_BLANK && latlng[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latlng);
				if(add == null) add = U.getAddressHereApi(latlng);
				geo="TRUE";
			}
		}
	
		// ........................Prizes ...........................
		//html = html.re
		String price[] = U.getPrices(html,
				"Starting in the \\$\\d{3},\\d{3}s|Low \\$\\d+,\\d+|<span class=\"price\">\\s*\\$\\d+,\\d+\\s*</span>|<td>\\$\\d{3},\\d{3}\\s*[*]*</td>|<h3>\\$\\d{3},\\d{3}</h3>", 0);
		String minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		String maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		U.log(minPrice);
		U.log(maxPrice);

		// ............................ square feet.....................
		String sqft[] = U.getSqareFeet(html+modelHomes,
				"\\d+,\\d+ Sq.Ft.<br />|<td>\\d{1},\\d{3}</td>|<td>\\d{4}</td>|<td>\\d,\\d+ <span|\\d,\\d+ Sq. Ft.\\s*|Starting at [0-9]{4} sq feet.|\\d{4} Square Feet|From \\d,\\d{3} SF", 0);
		String minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		String maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		String remove=U.getSectionValue(html, "<div class=\"listings community-move-in-ready-listings\">", "<head>");
		U.log("============re"+remove);
		if(add[2].trim().length()!=2)
			add[2]=USStates.abbr(add[2]);
		
		if(add[2]==null)add[2]=ALLOW_BLANK;
		U.log(add[0]+"  "+add[1]+"      "+add[2]+"     "+add[3]);
		
		
		//============= PropType =======================
		html = html.replaceAll("A premier Coleman Homes community with affordable luxury homes and prime amenities", "");
		html=html.replaceAll("carriage|Carriage|- Carriage", "").replace("- Carriage", "").replace("Carriage", "");
//U.log("secPlan:::::::::::::"+secPlan);
		String ptype=U.getPropType(html+url+quickHtml+modelHomes+secPlan.replaceAll("AT CARRIAGE HILL NORTH", ""));
		U.log("propType= "+ptype);
		
		//status from images
		if(url.contains("/the-oaks-north/") || url.contains("/cartwright-ranch/"))propstatus ="Now Selling";//image

		// Image From Region Page
		if(url.contains("/heron-river/") || url.contains("/legacy/") || url.contains("/fairhaven/"))
			propstatus = getImageStatus(propstatus, "Now Selling");
		if(url.contains("https://www.mycolemanhome.com/idaho-communities/the-meadows-at-west-highlands"))
			propstatus="Now Selling";
		if(url.contains("https://www.mycolemanhome.com/idaho-communities/sterling-ranch"))
			propstatus=ALLOW_BLANK;
		if(url.contains("https://www.mycolemanhome.com/idaho-communities/fairhaven"))
			propstatus=ALLOW_BLANK;
		// ...................adding in csv...............................
		html=html.replace("affordable luxury homes and prime amenities","");
		data.addCommunity(commName, url, communitytype);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latlng[0], latlng[1].trim(), geo);
		data.addPropertyType(ptype, dtype);
		data.addPropertyStatus(propstatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addNotes(U.getnote(html));
		}
		j++;
	}
	
	private static String getImageStatus(String pStatus, String imageStatus){
		if(pStatus == ALLOW_BLANK || pStatus.length() < 3) pStatus = imageStatus;
		else if((pStatus != ALLOW_BLANK || pStatus.length() > 3) && !pStatus.contains(imageStatus)) pStatus += ", "+imageStatus;
		return pStatus;
	}
}
