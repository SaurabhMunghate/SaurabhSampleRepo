/**@author Sawan
 * Date- 10-06-2017
 */

package com.shatam.b_301_324;

import java.util.Arrays;

import org.apache.commons.io.IOUtils;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCornerstoneCommunities extends AbstractScrapper{
	CommunityLogger LOGGER;
	int i = 0;

	public static String HOME_URL = "https://www.cornerstonecommunities.com/";

	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractCornerstoneCommunities();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Cornerstone Communities.csv", a.data()	.printAll());
	}
	
	public ExtractCornerstoneCommunities() throws Exception {
		super("Cornerstone Communities", HOME_URL);
		LOGGER = new CommunityLogger("Cornerstone Communities");
	}

	@Override
	protected void innerProcess() throws Exception {

		String html = U.getHTML(HOME_URL);
		String comSection = U.getSectionValue(html, "<h2 class=\"flip-box-heading\"", "<div class=\"fusion-clearfix\">");
		comSection = comSection.replace("back-inner\"><a", "back-inner\"><p><a")
				.replace("</a></div></div>", "</a></p>></div></div>");
//		U.log(comSection);

		
		String comUrlSections [] = U.getValues(comSection, "<p><a", "</p>");
		U.log(comUrlSections.length);
		for(String comUrlSec : comUrlSections){
			String comUrl = U.getSectionValue(comUrlSec, "href=\"", "\"");
			String comName = U.getSectionValue(comUrlSec, "class=\"propname\">", "</span>");
//			U.log(comUrl+"\t"+comName);
//			try {
				findCommunityDetails(comUrl,comName,comUrlSec);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}

	
	//TODO ::
	private void findCommunityDetails(String comUrl, String comName, String comUrlSec) throws Exception {
//		try{
//		if(i>4)
		{
		if(comUrl.contains("https://www.cornerstonecommunities.com/riverview/") 
				|| comUrl.contains("https://www.cornerstonecommunities.com/agave/")
				|| comUrl.contains("https://www.cornerstonecommunities.com/maravilla/")
				|| comUrl.contains("https://www.cornerstonecommunities.com/esperanza/"))return;//404 Page please check next time
		
			if(comUrl.contains("https://www.cornerstonecommunities.com/brisas/")) comUrl = "https://www.cornerstonecommunities.com/brisas-at-pacific-ridge/";
			if(comUrl.contains("https://www.cornerstonecommunities.com/lucero/")) comUrl = "https://www.cornerstonecommunities.com/lucero-at-pacific-ridge/";

			//Single Run			
//			if(!comUrl.contains("https://www.cornerstonecommunities.com/lucero-at-pacific-ridge/"))return;			

			
			U.log("count=="+i);
			U.log(comUrl);
			U.log(U.getCache(comUrl));	
			String html = U.getHTML(comUrl);
//			html= html.replaceAll("Town Center|TOWN CENTER", "");
		  
	//
			
			LOGGER.AddCommunityUrl(comUrl);
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			//============= Community Name =============
			U.log("comName ="+comName);

			//================= Address ======================
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String notes=ALLOW_BLANK;
			String [] latLng = {ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
			notes=U.getnote(html);
			String addressSection="";
			String latLngSection = U.getSectionValue(html, "https://www.google.com/maps", ">");
			if (comUrl.contains("/calistoga/")) {
				addressSection=U.getSectionValue(html, "<div class=\"fusion-title title fusion-title-4 fusion-sep-none fusion-title-text", "ong>");
				addressSection=U.getSectionValue(addressSection, "<p>", "<str");
				addressSection=addressSection.replace("<br />", ",");
				U.log("addddrrr: "+addressSection);
				
			}else {
					
					addressSection = U.getSectionValue(html, "Sales Manager<br />", "<strong>");
					if(comUrl.contains("/aventine/")) {
						addressSection=U.getSectionValue(html, "</div><div class=\"fusion-sep-clear\"></div>", "ong>");
						addressSection=U.getSectionValue(addressSection, "</div><div class=\"fusion-text\"><p>", "<str");
						addressSection=addressSection.replace("<br />\r\n" + 
								"(Santa Victoria Road &amp; Santa Alexia)<br />", ",");
						U.log("HHHH: "+addressSection);
					}
			}
			addressSection=addressSection!=null&&addressSection.trim().length()==0?U.getSectionValue(html, "Sales Manager<br /><strong>", "<strong>"):addressSection;
			if (comUrl.contains("/parkside")) {
				add[1]="Santee";
				add[2]="CA";
				latLng=U.getGoogleLatLngWithKey(add);
				add=U.getAddressGoogleApi(latLng);
				U.log(Arrays.toString(add)+Arrays.toString(latLng));
				geo="True";
				notes="Address taken from city and State";
			}else{
				if(addressSection==null) {
					addressSection=U.getSectionValue(html, "The Promontory</h3></div><div class=\"fusion-text\"><p>", "</p>");
					if(addressSection!=null) {
						addressSection=addressSection.replace("<br />", ", ");
					}
					U.log("inner add "+addressSection);
				}
				if(addressSection==null) {
					addressSection=U.getSectionValue(html, "Pacific Ridge</h4></div><div class=\"fusion-text\"><p>", "</p>");
					if(addressSection!=null) {
						addressSection=addressSection.replace("<br />", ", ");
					}
					U.log("inner add "+addressSection);
				}
				if(addressSection==null) {
					addressSection=U.getSectionValue(html, "\"></div><div class=\"fusion-text\"><p>", "</p>");
					if(addressSection!=null) {
						addressSection=addressSection.replace("<br />", ", ");
					}
					U.log("inner add "+addressSection);
				}

				if (addressSection==null) {
					addressSection=U.getSectionValue(html, "<strong>The Cove Realty Group</strong><br />", "<strong>");
					
					if(addressSection!=null) {
						if(addressSection.length()>300) {
							addressSection=null;
						}			
						
					}
					if (addressSection!=null)
					addressSection=addressSection.replaceAll("DRE Lic. #\\d+</p>", "");
					
					U.log("add"+addressSection);
				}
				if (addressSection==null) {
					
					addressSection=U.getSectionValue(html, "<div class=\"mceTemp\"></div>", "<strong>");
					if(addressSection!=null) {
						if(addressSection.length()>300) {
							addressSection=null;
						}			
						
					}
				}
				
				if (addressSection==null) {
					
					addressSection=U.getSectionValue(html, "</strong><br />", "<strong>");
					if(addressSection!=null) {
						if(addressSection.length()>300) {
							addressSection=null;
						}			
						
					}
				}
				
				if (addressSection==null) {
					addressSection=U.getSectionValue(html, "<p><strong>", "<strong><a href=\"mailto:");
					if(addressSection!=null) {
						if(addressSection.length()>300) {
							addressSection=null;
						}			
						
					}
					U.log(addressSection);
					if(addressSection!=null) {addressSection=addressSection.replaceAll("The Promontory is located within the award-winning Temecula School District.</strong> The desirable location is close great schools as well as the shopping, services, and entertainment offered by Murrieta Plaza, Rancho Temecula Town Center and Promenade Temecula.</p>\n" + 
							"</div><style type=\"text/css\"></style><div class=\"fusion-title title fusion-title-4 fusion-sep-none fusion-title-text fusion-title-size-three\" style=\"margin-top:0px;margin-bottom:31px;\"><h3 class=\"title-heading-left\" style=\"margin:0;\">Visit Bellevue at The Promontory</h3></div><div class=\"fusion-text\"><p>|Lic # 01948157</p>|Lic # 01890114</p>", "");}
				}
			}
			if (comUrl.contains("https://www.cornerstonecommunities.com/estancia/")) {
				addressSection= "1707 La Cumbre Avenue, Chula Vista, CA 91913";
			}
			if (comUrl.contains("https://www.cornerstonecommunities.com/cambria/")) {
				addressSection= "1432 Ortega Street, Chula Vista, CA 91913";
			}
//			 if(comUrl.contains("https://www.cornerstonecommunities.com/bellevue/")) {
//				 
//				 addressSection = U.getSectionValue(html, "Visit Bellevue at The Promontory</h3></div><div class=\"fusion-text\"><p>", "<strong>");
//			 }
			U.log(addressSection);
			if(comUrl.contains("https://www.cornerstonecommunities.com/bellevue/")){
							latLngSection = U.getSectionValue(html, "daddr=", "\">");
				latLng[0] = Util.match(latLngSection, "\\d{2,3}.\\d{5,}");
				latLng[1] = Util.match(latLngSection, "-\\d{2,3}.\\d{5,}");
				
				U.log("LatLng1 =="+Arrays.toString(latLng));
			}
			//U.log(addressSection);
			if(addressSection != null){
				addressSection = addressSection.replace(" 5496 San Roberto ", "5496 San Roberto")
						.replaceAll("Dora Josepher</strong><br />|Lori Perkins</strong><br />|Kelsey Parsapour</strong><br />", "")
						.replaceAll("Marisela Sandoval</strong><br />|Alejandra Romero</strong><br />|Kelsey Bredy</strong><br />|Dana Gaglione</strong><br />|Kelly Burnette</strong><br />|Pam Parks</strong><br />|Chloe Moreno</strong><br />|<p>|Lic # 01747843</p></div>|Lic # \\d+</p></div>|Mary Brenier</strong><br />Lic # 01349825</p></div>|Lic # 01890114</p>|Lic # 01948157", "")
						.replace("|", ",").replace("<br />", ",").replace("&amp;", "&").trim()
						.replaceAll("Judy Chung-Ferriss</strong>,|Darcy Peters", "");
				addressSection=addressSection.replaceAll("</p>\n*\\s*Lucero@cornerstonecommunities.com,\n*\\s*Ph: \\(760\\) 331-2265</p>", "");
				
				U.log("AddSec =="+addressSection);
				
				addressSection=addressSection.replace("TEMPORARILY SOLD OUT!,\n" + 
						"<span style=\"font-weight: var(--h3_typography-font-weight);\">NEXT PHASE COMING SOON!</span></strong></p></h3></div><div class=\"fusion-text\">Bellevue at The Promontory is located in the north Temecula Valley Wine Region. This unique hillside community showcases home-sites starting at 5,000 square feet – many of which will boast spectacular views of the surrounding countryside. The Promontory residents will enjoy the 100 acres of surrounding open space – including Tucalota Creek – containing numerous trails and paths for outdoor living.</p>\n" + 
						"<strong>", "");
				addressSection=addressSection.replace("Elizabeth Hunten</strong>,", "").replace("</strong>,", "");
				add = U.getAddress(addressSection);
				U.log("Add =="+Arrays.toString(add));
			}else{
				addressSection = U.getSectionValue(html, "<h3 class=\"title-heading-left\">Visit", "<a");
			
				U.log(addressSection);
				if(addressSection != null){
					addressSection = addressSection.replace("<br />", ",").replace("<p>Otay Ranch Sales Manager", "");
					if(addressSection.contains("|")||addressSection.contains("&amp;"))
						addressSection=addressSection.replace("|", ",").replace("&amp;", "&");
					addressSection=U.getSectionValue(addressSection, "<p>", "<strong>");
					U.log("AddSec ==="+addressSection);
					String[] tempadd=addressSection.split(",");
					add[0]=tempadd[0];
					add[1]=tempadd[1];
					add[2]=Util.match(tempadd[2], "\\w+");
					add[3]=Util.match(tempadd[2], "\\d+");
					U.log("Add =="+Arrays.toString(add));
				}
			}
			
			
			//============= LatLngSection =======================
			
			
			U.log(latLngSection);
			if(latLngSection != null){
				latLng[0] = Util.match(latLngSection, "\\d{2,3}.\\d{5}");
				latLng[1] = Util.match(latLngSection, "-\\d{2,3}.\\d{5}");
				U.log("LatLng2 =="+Arrays.toString(latLng));
			}
			
			
			if(comUrl.contains("https://www.cornerstonecommunities.com/laurelheights/")) {
				add[1]="Santee";
				add[2]="CA";
				add[3]="92010";
				latLng=U.getlatlongHereApi(add);
				add=U.getAddressGoogleApi(latLng);
				geo="True";
						
			}
			
			//============= Maps ==================
			/*
			 * This below case used when if communties has no address and latlng then it will find from main community
			 * This infomation is coming from map page. In which page, addresses and latlngs of main communities are present at source code.
			 * Therefore, we are taking geo code "false".
			 */
			if(add[0]==ALLOW_BLANK && add[1]==ALLOW_BLANK && add[3]==ALLOW_BLANK){
			String mapHtml = null;
			mapHtml = U.getHTML("https://www.cornerstonecommunities.com/map/");
			String mapSection = U.getSectionValue(mapHtml, "addresses:", "]");
			String mainComAddressSections [] = U.getValues(mapSection, "{\"address", "}");
			
			for(String mainComAddSec : mainComAddressSections){
				U.log("------------------");
				//U.log(mainComAddSec);
				if(mainComAddSec.contains(comName)){
					//U.log(mainComAddSec);
					U.log("mainComAddSec : "+mainComAddSec);
					
					if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
						String addSec1 = U.getSectionValue(mainComAddSec, "\":\"<br \\/>", "\",");
						if(addSec1 == null)
							addSec1 = U.getSectionValue(mainComAddSec, "\":\"", "\",");
						addSec1 = addSec1.replace("Parkway Murrieta", "Parkway, Murrieta").replace("\\n", "").replace("amp;", "")
								.replace("Road Carlsbad", "Road, Carlsbad").replace("Avenue San Diego", "Avenue, San Diego")
								.replace("ALEXIA Chula Vista", "ALEXIA, Chula Vista").replace("Oro Oceanside", "Oro, Oceanside").replace("<div class=\"mcetemp\"></div>", "")
								.replace(" | ", ", ");
						U.log("Address---"+addSec1);
						if(Util.match(addSec1, "[A-Za-z]+")!=null) {
						add = U.getAddress(addSec1.toLowerCase());
						}
						
					}
					if(latLng[0] == ALLOW_BLANK && latLng[1] == ALLOW_BLANK){
						latLng[0] = U.getSectionValue(mainComAddSec, "latitude\":\"", "\"");
						latLng[1] = U.getSectionValue(mainComAddSec, "longitude\":\"", "\"");
					}//eof if
//					if (notes.length()<2) {
//						notes="Address And Lat-Long Taken From Map Page";
//					}else {
//						notes+=", Address And Lat-Long Taken From Map Page";
//					}
				}
				geo="True";
				
			}//eof for
			
			}
			if(comUrl.contains("https://www.cornerstonecommunities.com/monterra/")){
				add[0] = "1434 Santa Victoria Road #1";
				notes = ALLOW_BLANK;
			}
			U.log(Arrays.toString(latLng));
			U.log("Add:::"+Arrays.toString(add));
			if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK){
				if(latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK){
					add = U.getAddressGoogleApi(latLng);
//					U.log("================");
					if(add == null) add = U.getAddressHereApi(latLng);
					geo = "True";
				}
			}
			if (latLng[0]==ALLOW_BLANK&&add[0]!=ALLOW_BLANK) {
				latLng=U.getlatlongGoogleApi(add);
				if(latLng == null)latLng = U.getlatlongHereApi(add);
				geo = "True";
			}
			//========= Price =================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replaceAll("0&#8217;s|0’s", "0,000");
			String[] price = U.getPrices(html, 
					"\\$\\d{1},\\d{3},\\d{3}|starting from \\$\\d{1},\\d{3},\\d{3}|Prices to range in the \\$\\d{3},\\d{3}|<li>From \\$\\d,\\d{3},\\d{3}<|FROM \\$\\d{3},\\d{3}-\\$\\d,\\d{3},\\d{3}|From \\$?\\d{3},\\d{3}<|\\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("Price =="+minPrice+"\t"+maxPrice);
			//============ Sqft ==================

			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			
			html = html.replaceAll("Garage &#8211; 1,600 sq.ft.|Garage &#8211; 1,485 sq.ft.|Garage &#8211; 1,410 sq.ft.|Garage &#8211; 1,835 sq.ft.|Garage &#8211; 1,610 sq.ft.|Garage &#8211; 1,533 sq.ft.|Bed 4/2-car Garage &#8211; 1,830 sq.ft.</p>|Bed 4/2-car Garage &#8211; 1,560 sq.ft.</p>", "");
			String[] sqft = U.getSqareFeet(html,
					"\\d,\\d{3} to \\d,\\d{3} Square Feet|\\d,\\d{3} to \\d,\\d{3} sq. ft.|featuring \\d,\\d{3} to \\d,\\d{3} square feet|From \\d,\\d{3} to \\d,\\d{3} sq. ft.|\\d,\\d{3} to \\d,\\d{3} sq\\.ft\\.|From \\d,\\d{3} to \\d,\\d{3} sq\\.ft\\.|\\d,\\d{3} to \\d,\\d{3} square foot|\\d,\\d{3} - \\d,\\d{3} sq. ft.|>\\d,\\d{3} sq.ft.<|Up to \\d,\\d{3} sq.ft.|starting at \\d,\\d{3} square feet|up to \\d,\\d{3} sq. ft.|>\\d,\\d{3} sq. ft.|\\d,\\d{3} sq.ft.</p>|to \\d,\\d{3} square feet|\\d{4}\\+ sq. ft.|featuring \\d{4}\\+ square foot", 0);
			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
//			if(comUrl.contains("https://www.cornerstonecommunities.com/tesoro/")) {
//				maxSqf="1702";
//			}
			U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
//			 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}1,410[\\w\\s\\W]{30}", 0));

			
			//============ Remove Section ====================
			html = removeScriptFromHtml(html);
			html = removeStyleFromHtml(html);
			String faqSec=U.getSectionValue(html, "<div class=\"accordian fusion-accordian\">", "Steps to Purchase</h3>");
			html =U.removeSectionValue(html, ">Please note:</strong>", "Currently our children are proposed to attend:");
			
			
			
			
			
			//========= Community Type ==============
			String comType = U.getCommunityType(html);
//			U.log(faqSec);
			//============Property Type ===============
			//data from region page
			String rgUrl = "https://www.cornerstonecommunities.com/the-promontory/"; 
			String rgHtml = U.getHTML(rgUrl);
			String section = U.getSectionValue(rgHtml, "94 two-story", "</p>");
			
			html =html.replace("Loft or Optional Bedroom", "Loft Home").replace("Coastal Tuscan", "Coastal-Style Homes")
					.replace("California Craftsman", "Craftsman-Style Homes")
					.replace("HOA dues cover maintenance","included in HOA").replace("Coastal Tuscan", "coastal communities");
			html = html.replace(">HOW MUCH ARE THE HOMEOWNER ASSOCIATION DUES?", "").replaceAll("community amenities, common areas, and recreational|HOA dues |HOW MUCH ARE THE HOMEOWNER ASSOCIATION DUES?|maravilla/\">|Maravilla|\\(Traditional\\)|coastal hills", "");
			comUrlSec=comUrlSec.replaceAll("villa</span>", "");
			U.log(comUrlSec);
			if(addressSection!=null)
			html=html.replace(addressSection, "");
			//U.log("ZZZ"+html);
//			U.log("MM"+Util.match(html, "loft"));
			String remove=U.getSectionValue(html,"<strong>The Cove Realty Group</strong><br />","<div class=\"fusion-text\">");
			if(remove!=null)
			html=html.replace(remove,"");
			
			
			
//			String[] faq=U.getValues(html, "<div class=\"fusion-panel panel-default", "</div></div></div>");
//			U.log("faq size"+faq.length);
//			for(String que:faq) {
//				html=html.replace(que, "");
//			}
			String propType = ALLOW_BLANK;
			
			if(comUrl.contains("https://www.cornerstonecommunities.com/bellevue/"))
				propType = U.getPropType(html+comUrlSec+section+faqSec);
			else
				propType = U.getPropType((html.replace("home office or flex space.", "home office or Flex Room.").replace("3 Bedrooms + Loft</li>", "3 Bedrooms with Loft </li>")+comUrlSec+faqSec).replace("HOW MUCH ARE THE HOMEOWNER ASSOCIATION DUES", "")
						.replaceAll("The HOA dues cover maintenance of the community amenities, common areas, and recreational facilities|covers maintenance of all common areas|WHAT ARE HOA DUES|HOA dues", ""));
			U.log("PTYPE: "+propType);
//			U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}common area[\\w\\s\\W]{30}", 0));
//			U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}hoa[\\w\\s\\W]{30}", 0));
			
			//============ Property Status ===============
			html =html.replaceAll("Brisas Phase 6 &amp; 7<br />\n\\s*Now Selling!", "Brisas Phase 6 & 7 Now Selling!")
					.replaceAll("Monterra Phase 2 &amp; 3<br />\n\\s*NOW SELLING!", "Monterra Phase 2 & 3 NOW SELLING!")
					.replaceAll("<li>Next Phase Coming Soon!</li>|center;\">COMING SOON!</p>|<li>COMING SOON!</li>|<li>TEMPORARILY SOLD OUT|Trailer:</strong><br />\\s*Opening Soon!</p>|Info Trailer:</strong><br />\\s* Opening Soon!</p>|center;\">COMING SOON|is planned for Summer|occur in Summer|soon.jpg|lgtitle=\"Coming|occur late Summer", "")
					.replaceAll("SOLD OUT! LAST|MODELS SOLD|<ul>\\s*<li>Sold Out</li|<li>SOLD OUT!</li>|li>SOLD OUT</li>|li>Currently Sold Out</li>|<li>Sold Out until Phase 4| projected to open Spring 2018| content=\"Coming Late 2019 |Is SOLD OUT|Models are Now|<li>Temporarily Sold", "");
			html = html.replace("Final Phase is NOW SELLING", "Final Phase NOW SELLING").replace("Phase 4 is NOW SELLING", "Phase 4 Now Selling").replace("FINAL PHASE &amp; MODEL HOMES NOW SELLING","FINAL PHASE NOW SELLING")
					.replaceAll("Brisas Phase 7<br />\\s+Now Selling!</p>", "Brisas Phase 7 Now Selling!</p>").replace("Final Brisas Phase Releasing Early 2022!", "Final Phase Releasing Early 2022");

			String propStatus = U.getPropStatus(html);
//			 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(html, "[\\w\\s\\W]{30}1,533[\\w\\s\\W]{30}", 0));
			//============ Derived Property Status ===============
			html = html.replaceAll("Rancho|OTAY RANCH</div|otay-ranch/\">OTAY RANCH</a><|Ivey Ranch|second-level-widget", "");
			String dType = U.getdCommType(html+section.replace("two-story", "2 Story"));
			if(comUrl.contains("https://www.cornerstonecommunities.com/bellevue/")) dType = "2 Story"; 
			U.log("DPTYPE: "+dType);
//			if(comUrl.contains("https://www.cornerstonecommunities.com/calistoga/")) {
//				propStatus = "Phase 8 Now Selling";
//				propStatus = U.getCapitalise(propStatus);
//			}
/*			if(comUrl.contains("https://www.cornerstonecommunities.com/cambria/")) {
				propStatus = "Phase 9 Now Selling";
				propStatus = U.getCapitalise(propStatus);
			}*/
//			if(comUrl.contains("https://www.cornerstonecommunities.com/aventine/")) {
//				propStatus = "Phase 9 Coming Soon";
//				propStatus = U.getCapitalise(propStatus);
//			}
//			if(comUrl.contains("https://www.cornerstonecommunities.com/brisas/")) {
//				propStatus = "Phase 6 & 7 Now Selling";
//				propStatus = U.getCapitalise(propStatus);
//			}
	
			
			//============Notes ===============
			add[0]=add[0].replaceAll(", \\(.*?\\)", "").replace("<div class=\"mcetemp\"></div>","").replaceAll("Kelsey Parsapour</strong>, | ", "");
			
//			if(comUrl.contains("https://www.cornerstonecommunities.com/bellevue/")) {
//				add[0]="38303 Old Creek Court";
//				//add[0]="38303 Old Creek Court";
//				//add[0]="38303 Old Creek Court";
//				//add[0]="38303 Old Creek Court";
//				}
//			if(comUrl.contains("http://www.cornerstonecommunities.com/maravilla/")) {add[0]="5496 San Roberto";}
			
//			if(comUrl.contains("https://www.cornerstonecommunities.com/acacia"))
//				propStatus=propStatus.replace("Sold Out", "Phase 8 Selling Fast");
			
			
//			if(comUrl.contains("https://www.cornerstonecommunities.com/blue-sage/"))
//				propStatus+="Phase 8 Releasing In The Spring";
			
//			if(comUrl.contains("https://www.cornerstonecommunities.com/estancia")) {
//				minPrice="$1,022,990" ;
//				maxPrice="$1,026,990";
//			}

			LOGGER.AddCommunityUrl(comUrl);
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(U.getNoHtml(add[0].trim()).trim(), add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(),geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus.replace("Opening Spring/Summer 2019", "Opening Spring/Summer 2019"));
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf, maxSqf);
			data.addNotes(notes);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
		}
		i++;
//		}catch(Exception e){}
	}

	public String removeStyleFromHtml(String html){
		String remStyles []  = U.getValues(html, "<style type=\"text/css\">", "</style>");
		for(String remStyle : remStyles)
			html = html.replace(remStyle, "");
		
		html = html.replaceAll("<style type=\"text/css\">|</style>", "");
		return html;
	}
	public String removeScriptFromHtml(String html){
		String remScripts [] = U.getValues(html, "<script type=\"text/javascript\">", "</script>");
		for(String remScript : remScripts)
			html = html.replace(remScript, "");
		
		String remScripts1 [] = U.getValues(html, "<script>", "</script>");
		for(String remScript : remScripts1)
			html = html.replace(remScript, "");
		
		String remScripts2 [] = U.getValues(html, "<script type='text/javascript'", "</script>");
		for(String remScript : remScripts2)
			html = html.replace(remScript, "");
		
		html = html.replaceAll("<script type='text/javascript'|</script>|<script>|<script type=\"text/javascript\">", "");
		return html;
	}
	public static String getHTMLwithProxy(String path) throws IOException {

		// System.setProperty("http.proxyHost", "104.130.132.119");
		// System.setProperty("http.proxyPort", "3128");
		//System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);

		//U.log("filename:::" + fileName);

		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		// int respCode = CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);
			
		{
			
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"64.124.38.140",8080));//"165.138.4.41",8080));//"198.229.231.13",8080));//"63.151.67.7",8080));//"23.225.92.19	",30022));//"216.228.69.202",32170));//"198.143.178.77",3128));//"66.82.22.79	",80)
			final URLConnection urlConnection = url.openConnection(proxy);

			// Mimic browser
			try {
				urlConnection
						.addRequestProperty("User-Agent",
								"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36");
				urlConnection
						.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
				urlConnection.addRequestProperty("Accept-Language",
						"en-GB,en-US;q=0.9,en;q=0.8");
//				urlConnection.addRequestProperty("Cache-Control", "max-age=0");
//				urlConnection.addRequestProperty("cookie", "PHPSESSID=40a52c3336cef15e99313ff02c75bb4a; _fbp=fb.1.1629984041825.700781696");
				// U.log("getlink");
				final InputStream inputStream = urlConnection.getInputStream();

				html = IOUtils.toString(inputStream);
				// final String html = toString(inputStream);
				inputStream.close();

				if (!cacheFile.exists())
					FileUtil.writeAllText(fileName, html);

				return html;
			} catch (Exception e) {
				U.log(e);

			}
			return html;
		}

	}
}