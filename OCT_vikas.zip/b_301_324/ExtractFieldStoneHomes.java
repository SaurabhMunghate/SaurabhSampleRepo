/**@modify Sawan
 * @date 2 March 2021
 * @author Pankaj Malode
 * date 10/8/2015
 */
package com.shatam.b_301_324;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFieldStoneHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	int i = 0;
	static int j = 0;
	public int inr = 0;

	private static final String BUILDER_URL = "https://www.fieldstonehomes.com";

	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new ExtractFieldStoneHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "FieldStone Homes.csv", a.data().printAll());
	}

	public ExtractFieldStoneHomes() throws Exception {

		super("FieldStone Homes", "https://www.fieldstonehomes.com");
		LOGGER = new CommunityLogger("FieldStone Homes");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://www.fieldstonehomes.com/new-homes/");
		String[] comV = U.getValues(html, "<div class=\"col-12 col-sm-6",
				"Details</a>");
		U.log(comV.length);
		String comUrl = "";
		for (String comS : comV) {
			//U.log("comS" + comS);
			comUrl = U.getSectionValue(comS, "\" href=\"", "\"");
			if (comUrl == null)
				comUrl = U.getSectionValue(comS, "<a href='", "'");
			comUrl = BUILDER_URL + comUrl;
			if (comS.contains("tetonreserve")) {
				comUrl = "https://tetonreserve.com/";
			}
			//U.log("innner com url" + comUrl);
			String comN = U.getSectionValue(comS, "lato-bold\">", "</span>");
			// U.log(name);
			addDetails(comN, comUrl, comS);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String name, String url, String sec) throws Exception {
		
//		try
		{
			// Single comm Run
//		if (!url.contains("https://tetonreserve.com/"))return;
				
			U.log("COUNT===="+j+" ::::::::::::::::::::::");
			if (url.contains("https://www.fieldstonehomes.comhttps://tetonreserve.com/"))
				return;
			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl(url + "--REPEATED");// it will append Url with timedateformat
				return;
			}
			LOGGER.AddCommunityUrl(url);
			U.log(name);
			U.log(url);
//			 U.log("========================\n"+sec+"\n=======================");
			String comhtml = U.getHTML(url);
			String cType = U.getCommType(comhtml.replaceAll("Wasatch Golf Course|Hollow Golf Course", ""));
			if (comhtml == null || comhtml.contains("<title>Page not found")) {
				LOGGER.AddCommunityUrl(url + "::::::::::::Page Not Found");
				return;
			}
			// ===============latlng AND address=====================
			String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, "UT", ALLOW_BLANK };
			String geo = "FALSE";
		//	String addSec = U.getSectionValue(comhtml, "Community Address</h5>", "</p>");
			String addSec = U.getSectionValue(comhtml, "Community Address</h5>", "</div>");
			if (addSec != null)
				addSec = addSec.replace("<p>", "").replace("<br/>", ", ").replace("<p>","").replace(" <br>", ",");
			U.log("addSec"+addSec);
			if (addSec != null) {
				addSec = U.getNoHtml(addSec);
				add = U.getAddress(addSec);
			}
			U.log("Address is  : " + Arrays.toString(add));
			//String latLngSec = U.getSectionValue(comhtml, "//maps.google.com/maps?", "Get Directions");
			String latLngSec = U.getSectionValue(comhtml, "https://www.google.com/maps/place/", "Get Directions");
			//U.log(latLngSec);
			if (latLngSec != null)
				latLngSec = Util.match(comhtml, "\\d{2}\\.\\d{2,},-\\d{3}\\.\\d{2,}");

			else
			{
				latlng[0]=U.getSectionValue(comhtml, "'latitude':", ",");
				latlng[1]=U.getSectionValue(comhtml, "'longitude':", ",");

			}
			
			U.log("latLngSec : " + latLngSec);
			if (latLngSec != null) {
				latlng = latLngSec.split(",");
			}
			if ((latlng[0] == null || latlng[0] == ALLOW_BLANK) && add[0] != null && add[0].length() > 5) {
				latlng = U.getlatlongGoogleApi(add);
				if (latlng == null)
					latlng = U.getlatlongHereApi(add);
				if (latlng == null)
					latlng = U.getNewBingLatLong(add);
				geo = "TRUE";
			}
			
			U.log("latlng is  : " + Arrays.toString(latlng));
			
			String note = U.getnote(comhtml);
			U.log(add[0] + "::::" + add[3]);

			if (add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK) {
				if (url.contains("scenic-mountain-townhomes/7490")
						|| url.contains("scenic-mountain-west-townhomes/7990")) {
					// addSec="4754 north topaz drive, Eagle Mountain, UT, 84005";
					add[0] = "4754 north topaz drive";
					add[1] = "Eagle Mountain";
					add[2] = "UT";
					add[3] = "84005";
					geo = "TRUE";
				}

				if (add[0] == ALLOW_BLANK && add[1] == ALLOW_BLANK) {
					if (url.contains("https://tetonreserve.com/")) {
						add[1] = "Victor";
						add[2] = "ID";
						latlng = U.getGoogleLatLngWithKey(add);
						add = U.getGoogleAddressWithKey(latlng);
						geo = "true";
					}
				

				else {
					String citystate = U.getSectionValue(comhtml, "<p class=\"p-0 m-0 text-uppercase mb-4\">", "<");
					String[] cs = citystate.split(",");
					U.log(Arrays.toString(cs));
					add[1] = cs[0];
					if (add[2] == ALLOW_BLANK)
						add[2] = cs[1];
					U.log(add[2]);
					latlng = U.getGoogleLatLngWithKey(add);
					add = U.getGoogleAddressWithKey(latlng);
					geo = "true";
					note = "address taken from city and state";
				}
			}
			}
			int quickCount = 0;
			String combinedQuickHtml = null;
			String quickSection = U.getSectionValue(comhtml, "Quick Delivery homes</h2>", "<h2>Community Photo");
			
			//String quickSection = U.getSectionValue(comhtml,"Quick <b>Move-Ins</b>","Neighborhood</h1>");
			if (quickSection != null) {
				String quickUrlSection[] = U.getValues(quickSection, "<div class=\"fl-photo-content",
						"temprop=\"url\">");
				for (String quickUrlSec : quickUrlSection) {
					String quickUrl = U.getSectionValue(quickUrlSec, "<a href=\"", "\"");
					U.log("quickUrl :" + quickUrl);
					
					if(quickUrlSec.contains("Available Now") || quickUrlSec.contains("Available Sep 2022")|| quickUrlSec.contains("Available Sep 2022")) {
						quickCount++;
					}
					String quickHtml = U.getHTML(quickUrl);
					combinedQuickHtml += U.getSectionValue(quickHtml, "<rs-slides>", "FLOOR PLAN LAYOUTS</span>");
					
				}
			} else {
				quickSection = U.getSectionValue(comhtml, "Quick <b>Move-Ins</b>", "Neighborhood</h1>");
				if (quickSection != null) {
					//String quickUrlSection[] = U.getValues(quickSection, "<a class=\"oi-aspect", "</a>");
					String quickUrlSection[] = U.getValues(quickSection, "<a class=\"oi-aspect four-three oi-image-click\"", "</a>");
					for (String quickUrlSec : quickUrlSection) {
						String quickUrl = U.getSectionValue(quickUrlSec, " href=\"", "\"");
						if (!quickUrl.startsWith("http"))
							quickUrl = BUILDER_URL + quickUrl;
						U.log("quickUrl :" + quickUrl);
						
						if(quickUrlSec.contains("Available Now") || quickUrlSec.contains("Available Sep 2022")|| quickUrlSec.contains("Available Sep 2022")) {
							quickCount++;
						}
						try {
							if(!quickUrl.contains("https://www.fieldstonehomes.com/new-homes/ut/south-jordan/daybreak-cascade-village/7494/11701-s-outfitter-way-473/143049/")) {
								String quickHtml = U.getHTML(quickUrl);
								combinedQuickHtml += U.getSectionValue(quickHtml, "<h1>About this <span>",
										"Download Brochure<");								
							}
						}
						catch(IOException e){}
					}

				}
			}
			
			U.log("quick count2 :" + quickCount);

			
			// ============ Floor Plans ==================
			String combinedFloorHtmls = null;
		//	String floorUrls[] = U.getValues(comhtml, "<a class=\"card-thumb\" href=\"", "\"");
			String floorUrlSec[] = U.getValues(comhtml, "<div class=\"card rounded-0\">", "<span class=\"oi-aspect-spacer\">");
			
			U.log("total floor homes ::" + floorUrlSec.length);
			for (String floorUrlS : floorUrlSec) {
				String floorUrl=U.getSectionValue(floorUrlS, "href=\"", "\"");
//				 U.log("floor Url:::"+floorUrlS);	
				
				if (!floorUrl.startsWith("http"))
					floorUrl = BUILDER_URL + floorUrl;
                U.log("floor Url:::"+floorUrl);
			//	U.log("floorUrl :" + floorUrl);
				String floorHtml = U.getHTML(floorUrl);
				if (floorHtml != null)
					combinedFloorHtmls += U.getSectionValue(floorHtml, "<h1 class=\"text-uppercase", "data-fancybox=");
			}
			// ------------Prices from reg page, community page and section from quick move
			// in page---------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comhtml = comhtml.replace("our newest single-family community in Payson, Utah. Starting in the High $300K's!", "").replace("</span><span class=\"unit\">'s", ",000");
			comhtml = comhtml.replace("</span><span class=\"value\">", "");
			comhtml = comhtml.replace("mid 200&#8217;s ", "mid $200,000 ").replace("$200's", "$200,000")
					.replace("&#8217;", "'").replaceAll("0s|0K's", "0,000");
			comhtml = comhtml.replaceAll("0's|0’s", "0,000").replace("0K’s", "0,000");
			comhtml = comhtml.replace("0’s", "0,000");
			String[] price = U.getPrices(sec + comhtml + combinedQuickHtml,
					"home starting in the lower \\$\\d{3},\\d{3}|>\\$\\d,\\d{3},\\d{3}<|from the (mid|low|high) \\$\\d+,\\d+ |from the upper \\$\\d+,\\d+|from the mid \\d+,\\d+|\\$\\d{3},\\d{3}",
					0);
			// Util.match(, )
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(sec,"[\\s\\w\\W]{30}\\$300[\\s\\w\\W]{30}", 0));
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(comhtml,"[\\s\\w\\W]{30}\\$300[\\s\\w\\W]{30}", 0));
//			 U.log(">>>>>>>>>>>>"+Util.matchAll(combinedQuickHtml,"[\\s\\w\\W]{30}683,270[\\s\\w\\W]{30}", 0));

			 
			 U.log(minPrice + " :: " + maxPrice);
			// ------------Sq feet ------
			String[] sqft = U.getSqareFeet(comhtml+combinedFloorHtmls,
					"\\d,\\d{3} Finished Sq Ft. |</div><p>\\d,\\d{3}</p></div>|range of \\d,\\d{3} to \\d,\\d{3} total square feet|\\d,\\d{3}-\\d,\\d{3} Sq. Ft.|\\d,\\d{3} Total Sq. Ft. |from \\d,\\d{3} to \\d,\\d{3} square feet|starting at \\d,\\d{3} total square feet|\\d,\\d{3} Total Sq Ft|from \\d,\\d{3}( )?-( )?\\d,\\d{3} square feet|from \\d,\\d{3} - \\d,\\d{3} square feet|\\d,\\d{3} Total Sq Ft l \\d,\\d{3} Finished Sq Ft|\\d,\\d{3} square feet|font-size: 14px;\">\\d,\\d{3} Total Sq Ft|\\d,\\d{3} sqft</span>|\\d,\\d{3} Total Sq Ft|total_sqft-2\"><span class=\"value\">\\d{4}</span>",
					0);
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			U.log("SQFT::: " + Arrays.toString(sqft));
			comhtml = comhtml.replaceAll(
					"-Farmhouse|farmhouse elevat|between a craftsman|-Craftsman|_Farmhouse|_Craftsman|Craftsman and Farmhouse Elevations",
					"").replaceAll(
							"find where we are currently|(Quick Move-(i|I)ns|QUICK MOVE-INS)</a>|Quick Delivery|either Move-in",
							"");
			String status = U.getPropStatus(comhtml
					.replaceAll("move|Move|MOVE", "")
					.replaceAll(
					"future lots are available|Pricing coming soon|Pricing coming soon. </span>|bryleefarms/\">BRYLEE FARMS &#8211; COMING SOON</a>|>GRAND OPENING HIGHLIGHTS<|COMING SOON</a></li>|Trail is currently selling|Legacy Farms New Phase Release in Spanish Fork|purchase a Quick",
					""));
			if (quickCount > 0) {
				if (status == ALLOW_BLANK)
					status = "Quick Move-Ins";
				else if (status != ALLOW_BLANK)
					status += ", Quick Move-Ins";
			}
		status=status.replace("Quick Move-in", "Quick Move-Ins");
			if (combinedFloorHtmls != null)
				combinedFloorHtmls = combinedFloorHtmls.replaceAll("Craftsman Elevation|Farmhouse Elevation", "");
			if (combinedQuickHtml != null)
				combinedQuickHtml = combinedQuickHtml.replace("FARMHOUSE EXTERIOR ELEVATION", "");
			String propertyType = U.getPropType((comhtml + combinedFloorHtmls + combinedQuickHtml).replace("Traditional, Craftsman or Transitional interior designs","Traditional Homes, Craftsman Style Home").replaceAll(
					"craftsman or farmhouse-style elevation|Farmhouse Elevation|Fieldstone Townhomes|Mountain T|-townhomes|Creek Townhome|creek-townhomes|mountain-townhomes|Arrowhead Cottages|arrowhead-cottages|mountain-townhomes|Townhomes</a>",
					""));
//			U.log("DDDDD"+Util.matchAll(comhtml + combinedFloorHtmls + combinedQuickHtml, "[\\w\\W\\s]{60}single[\\w\\W\\s]{60}", 0));

			if(propertyType.contains("Townhouses")&&propertyType.contains("Townhomes"))
				propertyType=propertyType.replaceAll("Townhouses, |, Townhouses","");
			if(propertyType.contains("Townhouse")&&propertyType.contains("Townhome"))
				propertyType=propertyType.replaceAll("Townhouse, |, Townhouse", "");
			
			
			String dtype = U.getdCommType((comhtml + combinedFloorHtmls + combinedQuickHtml)
					.replaceAll("floor|Floor|Arrowhead Ranch|arrowhead-ranch", ""));
			if (url.contains("https://www.fieldstonehomes.com/new-homes/ut/eagle-mountain/scenic-mountain-west-townhomes/7990/")) {
				latlng = U.getlatlongGoogleApi(add);
				geo = "TRUE";
			}

			if (url.contains("https://tetonreserve.com"))
				dtype = "1 Story, 2 Story";
			name = name.replaceAll("Cottages$", "");
			if (url.contains("saratoga-springs/alpine-springs/9897/") || url.contains("https://tetonreserve.com/")) {
				note="Address Taken From City And State";
			}

			
//			==========================================================================
			
			String[] lot_data=null;
			String lotCount=ALLOW_BLANK;
//			String lot_Sec=U.getSectionValue(comhtml, "usemap=\"#platmap_map\"/>", "<div class=\"sitemap-key\">");
//			if(lot_Sec!=null) {
				lot_data=U.getValues(comhtml, "<div=\"\" class=\" oi-isp-key-sold quick-filters point \"", "</div>");
				if(lot_data.length>0) {
				lotCount=Integer.toString(lot_data.length);
				 U.log("lotCount=="+lotCount);
				}
//			}
			
			
			
			
			
			data.addCommunity(name, url, cType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), geo);
			data.addPropertyType(propertyType, dtype);
			data.addPropertyStatus(status);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
		// }catch(Exception e){}
	}
}