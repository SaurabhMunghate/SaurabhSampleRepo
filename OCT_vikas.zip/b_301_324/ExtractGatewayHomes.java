/** @author Sawan
 *  @date 07/10/2017 
 */

package com.shatam.b_301_324;

import java.util.Arrays;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;

public class ExtractGatewayHomes extends AbstractScrapper {
	int i = 0;
	public int inr = 0;
	private static final String builderUrl = "http://www.gatewayhomes.com";
	WebDriver driver = null;
	public static void main(String[] ar) throws Exception {
//		System.setProperty("webdriver.chrome.driver","/home/glady/chromedriver");
		AbstractScrapper a = new ExtractGatewayHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Gateway Homes.csv", a.data().printAll());
	}

	public ExtractGatewayHomes() throws Exception {

		super("Gateway Homes", builderUrl);
	}

	public void innerProcess() throws Exception {
		
		U.setUpGeckoPath();
		driver = new FirefoxDriver(U.getFirefoxCapabilities());
		String html = U.getHTML(builderUrl);
		
		String comUrlSec = U.getSectionValue(html, "<div class=\"paragraph\">", "</div>");
		String comSecUrls[] = U.getValues(comUrlSec, "<a href=", "/a>");
		for(String comSecUrl : comSecUrls){
			String comUrl = U.getSectionValue(comSecUrl, "\"", "\"");
			String comName = U.getSectionValue(comSecUrl, ">", "<");
			findCommunityDetails(builderUrl+comUrl, comName,driver);
		}
		driver.close();
		
		try{driver.quit();}catch(SessionNotCreatedException e){}
	}


	
	private void findCommunityDetails(String comUrl,String comName,WebDriver driver)throws Exception{
	//if(i == 2)
	{	
		//if(!comUrl.contains("http://www.gatewayhomes.com/kingdom-heights.html"))return;
			U.log(i+" comURL::"+comUrl);
			
			String html = U.getHTML(comUrl);
			
			//=============== Address ==================
			String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
			String addSec = U.getSectionValue(html, "Location:</strong>", "Directions:");
			if(addSec != null){
				addSec = addSec.replaceAll("<br /><span>|<br /><br />|<span style=\".*?\">|<strong style=\".*?\">", "")
						.replace("</span>", ",").replaceAll(",&#8203;,|<br />", "").replace("Dr.Houston", "Dr., Houston");
				U.log("AddSec==="+addSec);
				add = U.getAddress(addSec);
			}
			U.log("Add:::"+Arrays.toString(add));
			//================= LatLng =================
			String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
			latLng[0] = U.getSectionValue(html, "lat=", "&");
			latLng[1] = U.getSectionValue(html, "long=", "&"); 
			U.log("LatLng=="+Arrays.toString(latLng));
			
			//============== Available Home ================
			int quickcount = 0;
			String availableUrl = U.getSectionValue(html, "<a class=\"wsite-button wsite-button-small wsite-button-normal\" href=\"", "\"");
			if(availableUrl == null)
				availableUrl = U.getSectionValue(html, "<a class=\"wsite-button wsite-button-small wsite-button-highlight\" href=\"", "\"");
			U.log("Available Url ::"+availableUrl);
			U.log(U.getCache(builderUrl+availableUrl));
			String availableHtml = null;
			if(availableUrl != null && availableUrl.contains("available"))
				availableHtml = U.getHTML(builderUrl+availableUrl);
			
			String iframeAvailableUrl = null;
			String availableHomeHtml = null;
			if(availableHtml != null)
				iframeAvailableUrl = U.getSectionValue(availableHtml, "wcustomhtml\"><iframe src=\"", "\"");
			U.log(iframeAvailableUrl);
			if(iframeAvailableUrl != null)
				availableHomeHtml = U.getHtml(iframeAvailableUrl, driver);
			
			String availableSection = null;
			String combinedAvailableHomeHtmls = null;
			if(availableHomeHtml != null){
/*				availableSection = U.getSectionValue(availableHomeHtml, "readyToBuildResults\">", "<div id=\"rtbPager\"");
				U.log(availableSection);
*/				String [] availableUrls = U.getValues(availableHomeHtml, "home-name\"><a class=\"address-plan-name\" href=\"", "\"");
				for(String homeUrl : availableUrls){
					if(homeUrl.contains("#"))continue;
					U.log("homeUrl ::"+"http://twix.newhomesource.com"+homeUrl);
					String homeHtml = U.getHTML("http://twix.newhomesource.com"+homeUrl);
					combinedAvailableHomeHtmls += U.getSectionValue(homeHtml, "class=\"hd-home-info\">", "class=\"hd-visit-us\">");
					if(!homeUrl.contains("/home/plan/")){
						quickcount++;
					}
				}
			}
			
/*			//================= Quick Move IN =============
			if(availableHomeHtml != null){
				String quickHomeSection = U.getSectionValue(availableHomeHtml, "id=\"quickMoveInResults\">", "<div id=\"qmiPager\"");
				if(quickHomeSection != null){
					String quickUrls[] = U.getValues(quickHomeSection, "home-name\"><a class=\"address-plan-name\" href=\"", "\"");
					quickcount = quickUrls.length;
					for(String quickUrl : quickUrls){
						U.log("homeUrl ::"+"http://twix.newhomesource.com"+homeUrl);
						String homeHtml = U.getHTML("http://twix.newhomesource.com"+homeUrl);
						combinedAvailableHomeHtmls += U.getSectionValue(homeHtml, "class=\"hd-home-info\">", "class=\"hd-visit-us\">");
						if(!homeUrl.contains("/home/plan/")){
							quickcount++;
						}
					}
				}
			}
*/			//=============== Price =======================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = html.replaceAll("0s|0's", "0,000");
			String[] price = U.getPrices(html+availableSection+combinedAvailableHomeHtmls,
					"From \\$\\d{3},\\d{3}|starting at \\$\\d{3},\\d{3}|mid-\\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			//================= Sqft =====================
			String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html+availableSection+combinedAvailableHomeHtmls,
							"sq-footage\">2,985 sq.ft.|\\| \\d,\\d{3} sq.ft.",
							0);
			minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			
			//U.log(html);
			
			//=============== Community Type ====================
			String comType = U.getCommunityType(html);
			
			//============= Property Type ================
			html = html.replace("Patio size may vary", "");
			String pType = U.getPropType(html+combinedAvailableHomeHtmls);
			
			//=============Property Status ==============
			String pStatus = U.getPropStatus(html);
			if(quickcount>0 && !pStatus.contains("Quick")){
				if(pStatus.length()<3){
					pStatus="Quick Move In";
				}
				else{
					pStatus = pStatus+", Quick Move In";
				}
			}
			
			//==============Derived Type ====================
			String dType = U.getdCommType(html + combinedAvailableHomeHtmls );
			
			//================== Notes ====================
			String notes = U.getnote(html);
			
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqFeet, maxSqFeet);
			data.addNotes(notes);

	}
	i++;
	}
	
}