/**@author Aditya.
 * Date- 02-06-2015
 */

package com.shatam.b_301_324;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;


import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractInsightHomes extends AbstractScrapper {
	public static String HOME_URL = "https://www.itsjustabetterhouse.com";
	static int j = 0;
	CommunityLogger LOGGER;
	public ExtractInsightHomes() throws Exception {
		super("Insight Homes", HOME_URL);
		LOGGER = new CommunityLogger("Insight Homes");
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException, Exception {

		AbstractScrapper a = new ExtractInsightHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Insight Homes.csv", a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {

	String mainUrl = "https://www.itsjustabetterhouse.com/new-homes/all/";
		String mainHtml = U.getHTML(mainUrl);

//		String comSec[] = U.getValues(commHtml, ";<a href='", "'>");
		String comSec[] = U.getValues(mainHtml, "<div "
				+ "class=\"col-md-7 col-sm-8", "<div class=\"bt trans-blue\">");
		U.log(comSec.length);
		for (String cmSecs : comSec) {
			if(cmSecs.contains("<a href=\"#\""))continue;
			U.log(U.getSectionValue(cmSecs, "<a href=\"", "\">"));
			String cmUrl=U.getSectionValue(cmSecs, "<a href=\"", "\">");
			//U.log(cmSecs);
//			U.log("cmUrl :: "+cmUrl);
			if(cmUrl==null)continue;
			
//			try {
				addComDetails(cmUrl, cmSecs);
//			} catch (Exception e) {}// Calling addComDetails
			// Method...............
			//break;
		}
		LOGGER.DisposeLogger();
	}

	private void addComDetails(String cmUrl, String cmSecs) throws Exception {
	//TODO : For Single Community Execution
//		try{
		{
		U.log("Count ::"+j);
		String geoCode = "FALSE";
		//cmSecs=U.getSectionValue(cmSecs, "<a href=\"", "\">");
		String communityUrl = cmUrl;
		//U.log(communityUrl);
		communityUrl = HOME_URL + communityUrl;
		U.log("communityUrl::"+communityUrl);
		
		if(data.communityUrlExists(communityUrl)){
			LOGGER.AddCommunityUrl(communityUrl+"::::::::::::::REPEATED");
			return;
		}
		LOGGER.AddCommunityUrl(communityUrl);

		
		
	//		===============Single Community Execution===============
//		if(!communityUrl.contains("https://www.itsjustabetterhouse.com/new-homes/de/sussex-portions-of-kent-county/build-on-your-lot-delaware/813/"))return;
//redirect to another community
		
		
		
		String communityHtml = U.getHTML(communityUrl);
//		U.log("CACHE==="+U.getCache(communityUrl));
//		U.log("CACHE==="+cmSecs);

		String communityName  =U.getSectionValue(cmSecs, "<p class=\"pseudo-h1\">",	"</p>");
		if(communityName.length()<2)
		communityName= U.getSectionValue(communityHtml, "<h1>",	"</h1>");
		
		if(communityUrl.contains("https://www.itsjustabetterhouse.com/neighborhood/Stonewater-Creek-Millsboro-Delaware"))
			communityName=communityName+" Creek";
		
		communityName = communityName.trim()
				.replace("Stoney Ridge Estates", "Stoney Ridge")
				.replace("Baylis Estates", "Baylis");
		 U.log("Community Name :::"+communityName);

		// ****************** Community Prices ****************************
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		communityHtml = communityHtml.replaceAll("text-decoration: line-through;\">\\$", "");
		
//		U.log(cmSecs);
		String[] price = U.getPrices(communityHtml+cmSecs, 
				"price\">\\$\\d,\\d{3},\\d{3}</span>|From \\$\\d,\\d{3},\\d{3}</div>|\\$\\s\\d+,\\d+|\"price\">\\$[0-9]{3},[0-9]{3}</span>|\"price\">From \\$[0-9]{3},[0-9]{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
	
		 U.log("minPrice::"+minPrice+"\tmaxPrice::"+maxPrice);
//			U.log(Util.matchAll(communityHtml, "[\\w\\s\\W]{30}1,199[\\w\\s\\W]{30}", 0));


		// ******************Community Area [SqrFeet]******************
		String sqHtml = communityHtml.replaceAll("\\$3,500|\\$15,000 - \\$20,000|at 1,800 ", "");
		String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(sqHtml, 
				"\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|\\d,\\d{3} Sq. Ft.", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		U.log("maxSqFeet :"+minSqFeet + "\tmaxSqFeet :"+maxSqFeet);
		
		// ******************Community Address************************
		String note=U.getnote(communityHtml);
		String latlng= "";String lat="",lng="";
		String latLng[]= {ALLOW_BLANK,ALLOW_BLANK};
		String latLngSec = U.getSectionValue(communityHtml, "http://maps.google.com/", "target=");
		if(latLngSec!=null) {
		 latlng = Util.match(latLngSec, "\\d+.\\d+,-\\d+.\\d+");
		 latLng = latlng.split(",");
		 lat = latLng[0].trim();
		 lng = latLng[1].trim();
		 U.log("lat::"+lat+" lng::"+lng);
		}
		
		String adds[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String addSec = U.getSectionValue(communityHtml, "<div class=\"col-md-3 col-sm-4 contact-info text-center blue-border-left\">", "<br><br>");
		U.log("addSec : "+addSec);
		
		if(addSec==null) {
			
			String addSection = U.getSectionValue(communityHtml, "info text-center blue-border-left\">", "Office Hours");
			if(addSection != null) {
				
				addSection = addSection.replace("<br/><br/><div class=\"gps_address\"><u>Alternate GPS Address</u><br/> 30672 Mount Joy Road<br/> Millsboro, DE 19966</div><br/> <u>", "")
						.replace("<br/><br/><div class=\"gps_address\"><u>Alternate GPS Address</u><br/> 517 S Bedford Street<br/> Georgetown, DE 19947</div><br/> <u>", "")
						.replaceAll("<br/><br/><div class=\"gps_address\"><u>Alternate GPS Address</u><br/> 24794 Lewes Georgetown Highway<br/> Georgetown, DE 19947</div><br/> <u>|<br/><br/> <u>|<br/><br/><div class=\"gps_address\"><u>Alternate GPS Address</u><br/> 19835 Beaver Dam Road<br/> Lewes, DE 19958</div><br/> <u>", "");
				
				U.log("addSection: "+addSection);
				
				addSec = addSection;
			}
			

		}

		if (addSec != null) {
			addSec = addSec.trim().replaceAll("<br/>\\s*", ",");
			adds = U.getAddress(addSec);
			U.log("Address=========="+Arrays.toString(adds));
			U.log("geoCode=========="+geoCode);

		}
		if(communityUrl.contains("/sussex-portions-of-kent-county/build-on-your-lot-delaware/813")|| communityUrl.contains("/select-counties/build-on-your-lot-maryland/3473/"))
		{
//			adds[0] = ALLOW_BLANK;
//			adds[1]="Sussex County";
//			adds[2]="DE";
//			latLng =U.getlatlongGoogleApi(adds);
//			if(latLng == null) latLng = U.getlatlongHereApi(adds);
//			adds=U.getAddressGoogleApi(latLng);
//			if(adds == null) adds=U.getAddressHereApi(latLng);
//			lat=latLng[0];
//			lng=latLng[1];
//			note="Address & LatLng taken from city state";
//			geoCode = "TRUE";
			latlng=U.getSectionValue(communityHtml, "<a href=\"http://maps.google.com/maps?q=", "\"");
			latLng=latlng.split(",");
			adds=U.getAddressGoogleApi(latLng);
			geoCode = "TRUE";
		}

		// Thread.sleep(100000);
		if (adds[0] == ALLOW_BLANK) {

			adds = U.getAddressGoogleApi(latLng);
			if(adds == null) adds=U.getAddressHereApi(latLng);
			adds[0] = adds[0].trim();
			adds[1] = adds[1].trim();
			adds[2] = adds[2].trim();
			geoCode = "TRUE";

		}
		//-----------plan Data-----
		String allPlanData = ALLOW_BLANK;int k=0;
		for(String planUrl : U.getValues(communityHtml, "<div class=\"bbcard ", "<div class=\"photo")){
			k++;
			planUrl = "https://www.itsjustabetterhouse.com"+U.getSectionValue(planUrl, "href=\"", "\"");
			String planHtml = U.getHTML(planUrl);
			allPlanData += U.getSectionValue(planHtml, "<div class=\"spec\"><div class=\"green-bar\">", "Get Directions");
			U.log("planUrl: "+planUrl);
//			if(k>5)break;
		}
		String rem = U.getSectionValue(communityHtml, "<html", "<body>");
		if(rem != null) communityHtml = communityHtml.replace(rem, "");

		// ******************Adding Data*******************************
		communityHtml=communityHtml.replace("mega-HOA", "provided by an HOA").replaceAll("luxury bath|Village|village|luxurious clubhouse with", "");
		communityHtml = communityHtml.replaceAll("Gathering Room Coming Soon|carriage style garage|and HOA fees|Villas at Fairway|=\"neighborhood/Villas-at-Fairway|<strong>Villas at Fairway</strong>", "");
		//U.log(communityHtml);
		communityHtml=communityHtml.replaceAll("townhouse","townhome").replace("model with loft", "with Loft ");


		String propertyType = U.getPropType((allPlanData+communityHtml).replace("Coastal Life", "coastal-style homes").replace("split plan", "split level").replaceAll("carriage style garage door|mega-HOA fees|the HOA fees would|right HOA fees",""));

		//-----Property Status---------
		// Bad Contain
		String badString =ALLOW_BLANK;
		badString = U.getSectionValue(communityHtml,
				"name=\"description\"", " <meta name=\"twitter:image");
		//U.log(communityHtml);
		communityHtml = communityHtml.replaceAll("Basements Available, Depending on Lot Choice|COMING SOON:</span><br/></span>|class=\"text-nowrap\">IS NOW OPEN!<span>|soon: the Kramer| was clean and ready to move in|<p>limited time offer, restrictions apply</p>", "")
				.replace("Wooded &amp; Pond Lots Available", "Wooded & Pond Lots Available");
		String propertyStatus = U.getPropStatus((communityHtml+cmSecs).replaceAll("Basements Available, Depending on Lot Choice", ""));
		
		if(communityHtml.contains("<h1 class=\"text-center\">Move-in Ready</h1>") && !propertyStatus.contains("Move")){
			if(propertyStatus.length()<4)propertyStatus = "Move-in Ready";
			else propertyStatus = propertyStatus+", Move-in Ready";
		}
		if(propertyStatus.contains("Limited Homesites")) propertyStatus = "Limited Homesites Available"; 
		
		//-ComType--
		communityHtml = communityHtml.replace("Quiet Resorts", "resort-quality amenities").replace("golf at Sussex Pines", "golf course at Sussex Pines");
		String communityType= U.getCommunityType(communityHtml.replace("The Peninsula is a gated, new home community", "The Peninsula is a gated community").replaceAll("masterplan|beach resorts",""));
		allPlanData  = allPlanData.replace("40 foot ", "");

		String derivedPropertyType = U.getdCommType((communityHtml+allPlanData).replaceAll("[b|B]ranch|Floor| 40-foot wide", ""));
//		U.log(Util.matchAll(allPlanData+communityHtml, "[\\w\\s\\W]{30}now open[\\w\\s\\W]{30}", 0));

		/*adds[0] = adds[0].toLowerCase().replaceAll("visit us in the community clubhouse \\(", "").replace("<strong>", "");*/
		adds[0]=adds[0].replace("&amp; ", "& ");
		//-----Add logger--------
			
		if( communityHtml.contains("<p class=\"pseudo-h1 text-center\">Move-in Ready") && !propertyStatus.contains("Quick")){
			if(propertyStatus == ALLOW_BLANK)
				propertyStatus = "Move-in Ready";
			else if(propertyStatus != ALLOW_BLANK)
				propertyStatus = propertyStatus+", Move-in Ready";
		}
		if(communityUrl.contains("new-homes/de/millsboro/reserve-at-stonewater/1092/"))communityType=communityType+", Resort Style";
		if(communityUrl.contains("https://www.itsjustabetterhouse.com/new-homes/de/millsboro/the-peninsula/1455/")) propertyStatus = ALLOW_BLANK;
		
		
		
		data.addCommunity(communityName, communityUrl, communityType);
		data.addAddress(adds[0], adds[1], adds[2], adds[3]);
		data.addLatitudeLongitude(lat, lng, geoCode);
		data.addPropertyType(propertyType, derivedPropertyType);
		data.addPropertyStatus(propertyStatus.replace("Move-in Ready, Move-in Ready", "Move-in Ready"));
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFeet, maxSqFeet);
		data.addNotes(note);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}j++;
//		}catch(Exception e){}
	}
}