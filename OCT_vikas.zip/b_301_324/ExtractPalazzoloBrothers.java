package com.shatam.b_301_324;

import java.io.File;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
public class ExtractPalazzoloBrothers extends AbstractScrapper{

	CommunityLogger LOGGER;
	private static final String builderUrl = "https://www.palazzolobrothers.com";
	private static final String builderName = "Palazzolo Brothers";
	public ExtractPalazzoloBrothers() throws Exception {
		// TODO Auto-generated constructor stub
		super(builderName, builderUrl);
		LOGGER = new CommunityLogger(builderName);
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		AbstractScrapper a = new ExtractPalazzoloBrothers();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Palazzolo Brothers.csv",a.data().printAll());
	}

	
	WebDriver driver = null;
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		//String html = U.getHTMLwithProxy(builderUrl);

		
		String [] comUrls = {"/homes/hidden-creek/", "/homes/rochester-collection/", "/homes/sterling-heights/",
				"/apartments/502-amelia/", "/apartments/oakmonte-at-mill-river/", "/apartments/the-preserves/", "/apartments/the-preserves-north/"};//"/properties/downtown-rochester","/properties/dundee-steet","/properties/oakmonte-mill-river","/properties/preserves","/properties/preserves-north"
		
		for(String comUrl : comUrls){
//			try {
				findCommunityDetails(builderUrl+comUrl);
//			} catch (Exception e) {}
		}
		
		LOGGER.DisposeLogger();
//		driver.quit();
	}
	int j = 0;
	private void findCommunityDetails(String comUrl) throws Exception {
		// TODO Auto-generated method stub
//		if(j > 3)
//		if(!comUrl.contains("https://www.palazzolobrothers.com/homes/rochester-collection/"))return;
		{
			U.log("Count =="+j);
			U.log(comUrl);
			
			if (data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHtml(comUrl, driver);
			U.log(U.getCache(comUrl));
			//=========== Community Name ===================
			String comName = U.getSectionValue(html, "aria-current=\"page\">", "<");
			
			if(comName == null)
				comName = U.getSectionValue(html, "class=\"elementor-sub-item elementor-item-active\">", "<");
			
			U.log("comName ::"+comName);
			
			//============= Address =======================
			String add[] = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			String geo = "False";
//			if(comUrl.endsWith("hidden-creek"))
//				add = U.getAddress("23 Mile Road,Macomb, MI 48042");
//			if(comUrl.endsWith("downtown-rochester"))
//				add = U.getAddress("1246 Maple Dr,Rochester, MI 48307");
//			if(comUrl.endsWith("dundee-steet"))
//				add = U.getAddress("Denise Dr, Sterling Heights, MI 48310");
//			if(comUrl.endsWith("oakmonte-mill-river"))
//				add = U.getAddress("3737 Cherry Creek Lane,Sterling Heights, MI 48314");
//			if(comUrl.contains("preserves"))
//				add = U.getAddress("3737 Cherry Creek Lane,Sterling Heights, MI 48314");
			
			U.log("Add ::"+Arrays.toString(add));
			
			//============== LatLng ================
			String [] latLng = {ALLOW_BLANK,ALLOW_BLANK};
			
			String addsec = U.getSectionValue(html, "<div class=\"elementor-text-editor elementor-clearfix\">", "</p>");
//			if(addsec == null)addsec=U.getSectionValue(html, "<i aria-hidden=\"true\" class=\"fas fa-address-card\">", "</li>");
			if(addsec!=null) {
				
//				U.log("Add: "+addsec);
				addsec = addsec.replace("<br>", ",").replace("<br />", ",")
						.replaceAll("<p>", "");
				
				if(!addsec.contains(", MI"))
					addsec = addsec.replaceAll("\\s{1,}MI", ", MI");
					
//				U.log("Add: "+addsec);
				
				if(Util.match(addsec, "\\d{5}") != null)
					add = U.getAddress(addsec);
			}
			U.log("Address: "+Arrays.toString(add));
			
			
//			if(comUrl.contains("oakmonte-at-mill-river")||comUrl.contains("hidden-creek")
//					||comUrl.contains("rochester-collection"))
//			{
//				
//				add[0] = "3737 Cherry Creek Lane";
//				add[1] = "Sterling Heights";
//				add[2] = "MI";
//				add[3] = "48314";
//				
//			}
//			if(comUrl.contains("sterling-heights")) {
//			
//			add[0] = "42500 Ryan Rd";
//			add[1] = "Sterling Heights";
//			add[2] = "MI";
//			add[3] = "48314";
//			
//			}
			
			String laturl = U.getSectionValue(html, "<iframe frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"", "\"");
			
			if(laturl == null)
				laturl = U.getSectionValue(html, "<iframe scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"", "\"");
			
			U.log("laturl ::"+laturl);
			U.log("CACHE=="+U.getCache(laturl));
			if (laturl != null) {

				String lathtml = U.getHTML(laturl);

				String latSec =U.getSectionValue(lathtml,
						"\"https://www.google.com/maps/preview/place/", "\"");
				U.log("latSec>>>>>>>>>>>>>" + latSec);
				if (latSec != null) {
					latSec ="START "+latSec;
					String addSec=U.getSectionValue(latSec, "START", ",+USA");
					if (addSec != null) {
						addSec=addSec.replace("%26", "&").replace("+", " ").replace("814 N Harding Ave", "").trim();
						U.log("addSec>>>>>>>>>>>>>" + addSec);
//						
						add=U.getAddress(addSec);
//						U.log(Arrays.toString(add));
					}
					
					latLng[0] = Util.match(latSec, "\\d{1,2}\\.\\d+");
					latLng[1] = Util.match(latSec, "-\\d{1,2}\\.\\d+");
				}
				else {
					if(!comUrl.contains("/rochester-collection/")) {
					latSec = U.getSectionValue(laturl,
							"https://maps.google.com/maps?q=", "&");
					
					latSec=latSec.replace("%2C%20", ",");
					latLng=latSec.split(",");
					U.log("new latlngSec= "+latSec);
				}
				}
			}
			if(comUrl.contains("/rochester-collection/")) {//==remm
				latLng[0]= "42.28505969999999";
				latLng[1]= "-85.43454969999999";//,"-85.43455"}
//						
			}
			
			U.log(Arrays.toString(latLng));
				
			if(latLng[0]==ALLOW_BLANK) {
				
				laturl = U.getSectionValue(html, "https://maps.google.com/maps?q=", "&");
				U.log("================================================="+laturl);
				if (laturl != null)
					latLng = laturl.split("%2C%20");
			}
			
			if(latLng[0] != ALLOW_BLANK && (add[0] == null || add[0] == ALLOW_BLANK)){
				add = U.getAddressGoogleApi(latLng);
				if(add == null) add = U.getAddressHereApi(latLng);
				geo = "True";
			}
			
			
//			if(add[0] != ALLOW_BLANK && add[3] != ALLOW_BLANK && (latLng[0] == null || latLng[0] == ALLOW_BLANK)){
//				latLng = U.getlatlongGoogleApi(add);
//				if(latLng == null) latLng = U.getlatlongHereApi(add);
//				geo = "True";
//			}
			if(comUrl.contains(".com/homes/hidden-creek/")) {
				add[3]=U.getAddressGoogleApi(latLng)[3];
				geo = "True";
			}
			U.log("Address: "+Arrays.toString(add));

			U.log("LatLng ::"+Arrays.toString(latLng));
			
			//============ Navigate Urls =================
			String floorHtml = null;
			String sitePlanHtml = null;
			String plan = null;
			String unitHtml = null;
			String pricingHtml = null;
			String amenities = null;
			String exceptionalFeat = ALLOW_BLANK;
			String navSection = U.getSectionValue(html, "<aside id=", "</aside>");
			
			//================ NAV S
			String [] navUrls = U.getValues(html, "<div class=\"elementor-button-wrapper\">", "</span>");
			for(String navUrl : navUrls){
				
				navUrl = U.getSectionValue(navUrl, "<a href=\"", "\"");
			
				U.log(navUrl);
				if(navUrl.contains("floor-plans"))
					floorHtml = U.getHtml(navUrl,driver);
				if(navUrl.contains("/site-plan"))
					sitePlanHtml = U.getHtml(navUrl,driver);
				if(navUrl.contains("/plans"))
					plan = U.getHtml(navUrl,driver);
				if(navUrl.contains("/units-available"))
					unitHtml = U.getHtml(navUrl,driver);
				if(navUrl.contains("pricing"))
					pricingHtml = U.getHtml(navUrl,driver);
				if(navUrl.contains("amenities"))
					amenities = U.getHtml(navUrl,driver);
				if(navUrl.contains("/exceptional-features"))
					exceptionalFeat = U.getHtml(navUrl,driver);
			}
			//============ Homes Url ================
			String combinedHomeHtmls = ALLOW_BLANK;
			String homeUrlSection = U.getSectionValue(html, "<table style=\"width:100%\">", "</table>");
			if(homeUrlSection == null && sitePlanHtml != null)
				homeUrlSection = U.getSectionValue(sitePlanHtml, "<table style=\"width:100%\">", "</table>");
			if(homeUrlSection == null && plan != null)
				homeUrlSection = U.getSectionValue(plan, " <table class=\"views-table", "</table>");
			
			if(homeUrlSection != null){
				String [] homeUrls = U.getValues(homeUrlSection, "<a href=\"", "\"");
				for(String homeUrl : homeUrls){
					homeUrl = builderUrl+homeUrl;
					if(homeUrl.contains(".jpg") || homeUrl.contains(".png"))continue;
					U.log("homeUrl ::"+homeUrl);
					combinedHomeHtmls += U.getHTMLwithProxy(homeUrl);
				}
			}
			if (html.contains("/renderings")) {
				combinedHomeHtmls+=U.getHTMLwithProxy(comUrl+"/renderings");
			}
			combinedHomeHtmls = combinedHomeHtmls.replaceAll("</div><div class=\"field-items\"><div class=\"field-item even\">|&nbsp;", "");
			combinedHomeHtmls = combinedHomeHtmls.replace("-item even\">Colonial", "</span>Colonial</span>");	
				
			//============== Sqft ====================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html+floorHtml+combinedHomeHtmls+plan+unitHtml+pricingHtml,
					"\\d,\\d{3} SQ. FT|\\d{3} SQ. FT|sqfootage\">\\d,\\d{3}</td>|sqfootage\">\\d{3}</td>|\\d{4} to \\d{4} sq ft|from (\\d,)?\\d{3} to \\d,\\d{3} square fee|\\d,?\\d{3} sq. ft.|Est Tot Finished:\\s?\\d,\\d{3}|Square Footage:\\d,\\d{3}|sqfootage\"\\s>\\s+\\d,\\d{3}|(\\d,)?\\d{3} SQ. FT.", 0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqft::"+minSqft+"   maxSqft::"+maxSqft);
			
			//================= Price ==============
			
			html = html.replace("0’s", "0,000").replace("00K", "00,000");
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			String[] price = U.getPrices(html.replace("starting in the $590�s", "starting in the $590,000"), 
					"in the \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}<|From: \\$\\d{3},\\d{3}", 0);
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		
			U.log("minPrice::"+minPrice+"  maxPrice::"+maxPrice);
			
			//================= Community Type ===============
			String comType = U.getCommunityType(html + amenities);
			
			//================= Derived Property Type ===============
			
			String dType = U.getdCommType((html+combinedHomeHtmls+pricingHtml+amenities+exceptionalFeat+floorHtml).replace("Gleneagle II Colonial", "The Colonial").replaceAll("Story Fitness|First Floor", ""));
			
			//==================== Property Type =================
			String propType = U.getPropType((html+combinedHomeHtmls+pricingHtml+amenities+exceptionalFeat+floorHtml)
					.replaceAll("3 Bedroom Units – Condo Style|craftsmanship|Fapartments|\"Apartments|/Apartments/|Fapartments|/apartments/|Apartments</a>|com/Apartments|Apartments</h2>|menu-apartments|href=\"/apartments|Luxurious Master Suites", ""));
			U.log("propType: "+propType);
//			U.log(">>>>>>>>>>>>>>>>>>>>> "+Util.matchAll(floorHtml, "[\\s\\w\\W]{30}Townhome[\\s\\w\\W]{30}", 0));

			
			//==================== Property Status =========================
			html = html.replaceAll("Opening Beginning of 2018|New Residential Construction Coming Fall 2018|Open on Sunday", "");
			String propStatus = U.getPropStatus(html);
			
			//=============== notes ==============
			String notes = ALLOW_BLANK;

			if(comUrl.contains("/properties/dundee-steet"))
				dType = dType.replaceAll("2 Story,|,2 Story", "");
			
			if(comUrl.contains("/properties/oakmonte-mill-river") || comUrl.contains("/properties/preserves-north")){
				if(!propType.contains("Apartment Home")){
					if(propType.length()<4l){
						propType = "Apartment Home";
					}
					else{
						propType +=",Apartment Home";
					}
				}
			}
			
			if(comName!=null)
			comName=comName.replaceAll(", Chesterfield Township", "");
		
			if(html.contains("Inventory Homes:</h3>")) {
				if(propStatus.length()<2) {
					propStatus = "Inventory Homes Available";
				}
				else {
					propStatus =propStatus+", Inventory Homes Available";
				}
			}
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(comName, comUrl, comType);
			data.addAddress(add[0], add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqft, maxSqft);
			data.addNotes(notes);
		}
		j++;
	}

}