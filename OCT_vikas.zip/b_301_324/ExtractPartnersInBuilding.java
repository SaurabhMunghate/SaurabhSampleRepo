/**@author Aditya.
 * Date- 03-06-2015
 * 
 * 
 */
package com.shatam.b_301_324;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPartnersInBuilding extends AbstractScrapper {
	public static String HOME_URL = "http://www.partnersinbuilding.com/";
	
	static int j=0;
	CommunityLogger LOGGER;
	static int i;

	public ExtractPartnersInBuilding() throws Exception {
		super("Partners In Building", HOME_URL);
		LOGGER = new CommunityLogger("Partners In Building");
	}

	public static void main(String[] args) throws Exception

	{
		AbstractScrapper a = new ExtractPartnersInBuilding();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Partners In Building.csv", a.data()
				.printAll());
		

	}

	@Override
	protected void innerProcess() throws Exception {

		String hmUrl = "http://www.partnersinbuilding.com/find-your-home";
		String hmHtml = U.getHTML(hmUrl);
		hmHtml=hmHtml.replace("class=\"menu", "\"Find");
		// U.log(commHtml);
		String comSec[] = U
				.getValues(hmHtml, "Find Your Home</a>", "title=\"Plan Search");
		// U.log(comSec[0]);
		for (String stUrl : comSec) {

			String[] locUrl = U.getValues(stUrl, "\"><a", "\"Find");
			for (String sttUrl : locUrl) {
				U.log(sttUrl);
				comSec(sttUrl);

			}
		}
		LOGGER.DisposeLogger();
	}

	public void comSec(String sttUrl) throws Exception {

		String stateUrl = U.getSectionValue(sttUrl, "href=\"/", "\" title");

		stateUrl = HOME_URL + stateUrl;
		//U.log(stateUrl);

		String regnHtml = U.getHTML(stateUrl);
	//U.log(regnHtml);
		U.log(stateUrl);
		String[] dataSec = U.getValues(regnHtml, "card-dark\">","</div>  </div>    </div>");
		U.log(dataSec[0]);
		for (String infoSecs : dataSec) {
			addComDetails(infoSecs);
		}
		
	}

	public void addComDetails(String infoSecs) throws Exception {
//		if(j==7)
		{
			String geoCode = "TRUE";
		String comInfoHtml = "";
		// ******************Community Url****************
		String communityUrl = U.getSectionValue(infoSecs, "\" href=\"",
				"\" class");
		// U.log(communityUrl);
		LOGGER.AddCommunityUrl(communityUrl);
	//	LOGGER.countOfCommunity(i);

		// ******************Community Name***************
		String communityName = U.getSectionValue(infoSecs, "community-name\">",
				"</div>");
		communityName = communityName.trim();
		U.log(communityName);

		String noData = "http://www.partnersinbuilding.com/find-your-home/greater-houston/benders-landing";
		// This url does not contain any data...

		if (communityUrl.equals(noData)) {
			U.log("  ");
		}
		if(this.data.communityUrlExists(communityUrl))return;
		String communityHtml = U.getHTML(communityUrl);

		String dataUrl = U.getSectionValue(communityHtml,
				"Available Homes\" href=\"/", "\">Available");
		// U.log(dataUrl);
		
			dataUrl = communityUrl+"/available-homes#tabs";
			comInfoHtml = U.getHTML(dataUrl);
	
		U.log(dataUrl);

		// ******************CommunityPrices****************************

		String priceSec = infoSecs.replaceAll("0s", "0,000");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
	//	priceSec = priceSec.replaceAll("\\.000", ",000");
		communityHtml=communityHtml.replace("$1 million", "$1,000,000");
		String planHtml=U.getHTML(communityUrl+"/plans-and-lots#tabs");
		String[] plansUrl=U.getValues(planHtml, "View Details\" href=\"", "\"");
		String Planshtml="";
		for(String planUrl:plansUrl)
		{
			Planshtml=Planshtml+U.getHTML(planUrl);
		}
		String price[] = U.getPrices(priceSec + comInfoHtml+communityHtml+Planshtml+planHtml, "priced from \\$\\d,\\d+,\\d+|\\$\\d,\\d+,\\d+|\\$\\d{3},\\d+", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		// U.log(minPrice);
		// U.log(maxPrice);

		// ******************Community Area****************************
		String minSqFeet = ALLOW_BLANK, maxSqFeet = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(priceSec + comInfoHtml+communityHtml+planHtml,
				"\\d,\\d+ square feet to \\d,\\d+ |Sq. Ft.:\\s\\d+-\\d+|Sq. Ft:\\s+\\d,\\d+", 0);
		minSqFeet = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
		maxSqFeet = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
		// U.log(minSqFeet);
		// U.log(maxSqFeet);

		// **************Community Address, Lat And Lng*************

		String latData = Util.match(communityHtml,
				"\\d+.\\d+\\,\"lon\":-\\d+.\\d+");
		latData = latData.replace("\"lon\":", "");
		String[] latlngData = latData.split(",");
		String lat = latlngData[0];
		String lng = latlngData[1];
		
		
		//U.log(lat);
		//U.log(lng);

		String lngData[] = { lat, lng };
		String add[] = U.getAddressGoogleApi(lngData);
		add[0] = add[0].trim();
		add[1] = add[1].trim();
		add[2] = add[2].trim();

		String addline=U.getSectionValue(communityHtml, "<div class=\"street-block\">", "Get Directions");
		if(addline!=null)
		{
		add[0]=U.getSectionValue(addline, "<div class=\"thoroughfare\">", "</div>");
		add[1]=U.getSectionValue(addline, "<span class=\"locality\">", "</span>");
		add[2]=U.getSectionValue(addline, "<span class=\"state\">", "</span>");
		add[3]=U.getSectionValue(addline, "<span class=\"postal-code\">", "</span>");
		geoCode="FALSE";
		}
		// *********************Adding data******************************
        communityHtml=communityHtml.replace("Medical Center is now open", "");
        communityHtml=communityHtml.replace("new luxury", " luxury home ");
	//	planHtml=planHtml.replace("", newChar)
		String communityType = U.getCommunityType(communityHtml);
		
		communityHtml = communityHtml.replaceAll("Village|village", "");
		String propertyType = U.getPropType(communityHtml.replace("Luxury Custom Home", "").replace("HOA Office","").replaceAll("Garden at|garden at",""));
		communityHtml=communityHtml.replaceAll("Sendera Ranch", "");
		planHtml=planHtml.replaceAll("Sendera Ranch", "");
		String derivedPropertyType = U.getdCommType((communityHtml+planHtml+comInfoHtml).replaceAll("RANCHHO|Cypress Ranch|cyranch|Canyon Ranch|Vineyard Ranch|Rancho|rancho|Ranch Road|Sendera Ranch|First Floor", "").replace("Stories: 1.5", " 1.5 Stories "));
		communityHtml=U.getNoHtml(communityHtml);
		
		communityHtml = communityHtml.replaceAll("last home site", "");
		String propertyStatus = U.getPropStatus(communityHtml);
		propertyStatus = propertyStatus.replace("out!", "out");
		propertyStatus=propertyStatus.replaceAll("close-out|Close-out|Close Out!", "Close Out");
		
		U.log(propertyStatus+"-------------");
	
		communityName=communityName.replace("&#039;", "'");
		String note=U.getnote(communityHtml+comInfoHtml);
		data.addCommunity(communityName, communityUrl, communityType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(lat, lng, geoCode);
		data.addPropertyType(propertyType, derivedPropertyType);
		data.addPropertyStatus(propertyStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFeet, maxSqFeet);
		data.addNotes(note);

	}j++;
	}

}