package com.shatam.b_301_324;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.internal.seleniumemulation.GetHtmlSource;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractPyattBuilders extends AbstractScrapper{
	static String builderName="Pyatt Builders";
	static String builderUrl="https://www.pyattbuilders.com";
	CommunityLogger LOGGER;
	
	static int dupli=0;
	
	WebDriver driver = null;
	public ExtractPyattBuilders()throws Exception {
		super(builderName, builderUrl);
		LOGGER=new CommunityLogger(builderName);
	}
	public static void main(String[] args) throws Exception {

		
		AbstractScrapper abS=new ExtractPyattBuilders();
		
		abS.process();
		FileUtil.writeAllText(U.getCachePath()+builderName+".csv", abS.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		//U.setUpChromePath();
		//driver = new ChromeDriver();

	//	U.setUpGeckoPath();
	//	driver = new FirefoxDriver();
//		U.setUpChromePath();
//		driver=new ChromeDriver();
		String mainHtml=U.getHTML(builderUrl+"/neighborhoods/");
		//U.log(mainHtml);
		//String commSec=U.getSectionValue(mainHtml, "<div class=\"neighborhood-lists\">", "<div id=\"mega-menu-2\" class=\"header-mega-menu\">");
		//U.log(commSec);
		//commSec=commSec.replaceAll("<p>&nbsp;</p>|<p></div>", "");
		
		String[] comms=U.getValues(mainHtml, "id=\"community-link", "</li>");
		U.log("comms length: "+comms.length);
		
		String commName=ALLOW_BLANK;
		String commURL=ALLOW_BLANK;
		int i=0;
		for (String commData : comms) {
			//U.log("commData: "+commData);
			
			commURL=U.getSectionValue(commData, "href=\"", "\"");
			commName=U.getSectionValue(commData, ">", "<");
			if(!commURL.startsWith("http"))
				commURL=builderUrl+commURL;
			
			U.log("commURL: "+commURL);
			U.log("commName: "+commName);
			U.log(" ");
			
			addDetails(commURL,commName);
			i++;
		}
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}
	int j = 0 ;
	//TODO ::
	
//	private void addDetails1(String comUrl, String comName ) throws Exception {
//		
//		U.log("Count =="+j);
//		U.log("comUrl ===============================================>="+comUrl);
//		
//		String html = U.getHtml(comUrl, driver);
//		U.log(U.getCache(comUrl));
//		
//		j++;
//	}
	
		private void addDetails(String comUrl, String comName ) throws Exception {
	//if(j == 2)
		{
//			if(!comUrl.contains("https://www.pyattbuilders.com/new-home-communities/lebanon-boone-county-north-west/auburn-meadows")) return;
//			if(comUrl.contains("https://www.pyattbuilders.com/search-results/?search_lat=&amp;search_lng=&amp;sort=newest&amp;search_city=&amp;search_category=45&amp;search_type=6"))return;
//			if(comUrl.contains("https://www.pyattbuilders.com/search-results/?search_lat=&amp;search_lng=&amp;sort=newest&amp;search_category=20&amp;search_type=6"))return;
//			if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/trailside-woods/"))return;
			//https://www.pyattbuilders.com/neighborhood/grove-at-legacy/
			
//		if(!comUrl.contains("https://www.pyattbuilders.com/new-home-communities/hamilton-north/grove-at-legacy")) return;
			

			U.log("Count =="+j);
			U.log("comUrl ===============================================>="+comUrl);
			
			//String html = U.getHtml(comUrl, driver);
			String html = U.getPageSource(comUrl);
			U.log(U.getCache(comUrl));
			
			//------------------FOR UNIT COUNT-------------------------
			
			String lotCount = getUnits(html, comUrl, driver);
			U.log("lotCount: "+lotCount);
			
			//-----------------QUICK COUNT FOR STATUS------------------
			int quickCount = 0;
			
			
			if(html.contains("card__callout\">Available</div>")) {
				quickCount++;
			}
			
			String quickData=ALLOW_BLANK;
			String[] quickHomesValue=U.getValues(html, "<div class=\"cms-qmi__qmis\">", "Details");
			
			for(String qSec:quickHomesValue) {
				String qUrl=U.getSectionValue(qSec, "<a href=\"", "\"");
				U.log("quick Url :: "+qUrl);
				String qDataHTml=U.getHTML("https://www.pyattbuilders.com"+qUrl);
				String SectionAvailable=U.getSectionValue(qDataHTml, "<strong class=\"qmi-info__est hide hide--phone\">", "</strong>");
				if(SectionAvailable!=null) {
					if(SectionAvailable.contains("Home is Ready to Move In") || SectionAvailable.contains("September 2022")) quickCount++;
				}
				quickData=U.getSectionValue(qDataHTml, "<main class=\"template-base\">", "<section id=\"qmiFloorplans\"");
//				U.log(quickData);
			}
			

			U.log("quickCount =============  "+quickCount);
			
			
			//================= Quick Count ======================
			String[] quickHomes = null;
			String quickSec = U.getSectionValue(html, "<h2 class=\"centered\">OUR QUICK MOVE-IN HOMES</h2>", "SEE MORE AND SEARCH HOMES</a>");
			if(quickSec!= null)
				quickHomes = U.getValues(quickSec, "<ul class=\"property-information-list\">", "</ul> ");
			
					
			String dropheadSec=U.getSectionValue(html, "<div class=\"header-main-navigation", "<div class=\"page-section background-color-3");
			if(dropheadSec!= null)
			html=html.replace(dropheadSec, "");
			String footerSec=U.getSectionValue(html, " <div class=\"page-footer-inner clearfix\">", "</html>");
			if(footerSec != null) html=html.replace(footerSec, "");

			if (data.communityUrlExists(comUrl)){
	        	LOGGER.AddCommunityUrl(comUrl+ "---------------------------------repeat");
	        	return;
	        }
	        LOGGER.AddCommunityUrl(comUrl);
	        
			//=========== Community Name ===========
			comName = comName.replaceAll("Mooresville -", "");
			U.log("comName ::==== "+comName);
			
			//=========== Notes ==================
			String notes = U.getnote(html);
			
			//============== LatLng ==================
			String latLong[] = {ALLOW_BLANK,ALLOW_BLANK};
			
			//============== Section =================
			String mainSection = U.getSectionValue(html, "</h1>", "<div class=\"clearfix\">");
//			U.log(mainSection);
			String planHtmls = null;
			
			if(mainSection != null){
				String [] planUrls = U.getValues(mainSection, "<a href=\"", "\"");
				
				for(int i = 0; i < planUrls.length; i ++){
					if(planUrls[i].startsWith("#"))continue;
					String planHtml = null;
					planUrls[i] = planUrls[i].replace("amp;", "");

					
					
					if(planUrls[i].startsWith("http")){
						planHtml = U.getHtml(planUrls[i], driver);
						
						U.log("Plan Url ---> "+planUrls[i]);
					}
					if(!planUrls[i].startsWith("http")){
						if(!planUrls[i].startsWith("/")) planUrls[i] = "/"+planUrls[i];
						planHtml = U.getHtml(builderUrl+planUrls[i], driver);
						U.log("PlanUrls : "+builderUrl+planUrls[i]);
						U.log(U.getCache(builderUrl+planUrls[i]));
					}
					
					
					//This below condition is used to find view plan url .
					//From View Plan Url, we are taking latlng from that url page.
//					if(i == 0){
//
//						String latLngSec = U.getSectionValue(planHtml, "/maps/@", "data=");
//						
//						if(latLngSec != null){
//							latLong = findLatLng(latLngSec);
//						}
//					}
					planHtmls += planHtml;
				}
			}
			if(mainSection == null){
				//String latLngSec = U.getSectionValue(html, "/maps/@", "data=");
				String latLngSec = U.getSectionValue(html, "cms-contact__directions-ctas", "target=");
				
				U.log("latLngSec : "+latLngSec);
				if(latLngSec != null)
					latLong = findLatLng(latLngSec);
			}
			
			if(latLong[0] ==ALLOW_BLANK){
				latLong[0] = U.getHtmlSection(html, "data-latitude=\"", "\"").replace("data-latitude=\"", "");
				latLong[1] = U.getHtmlSection(html, "data-longitude=\"", "\"").replace("data-longitude=\"", "");
			}
			
			U.log("LatLong : "+Arrays.toString(latLong));
			//============== Plan Section =================
			String allPlanHtml=ALLOW_BLANK;
			String planUrls[]=U.getValues(html, "https://www.pyattbuilders.com/property/","\"");
			if(planUrls.length>0) {
				for(String s:planUrls) {
				String planhtm=ALLOW_BLANK;
				planhtm=U.getHTML("https://www.pyattbuilders.com/property/"+s);
				allPlanHtml+=U.getSectionValue(planhtm, "<div class=\"property-content-block\"><p", "</p>");
				}
			}
			
			//QuickMoveIn page data
			String quickHtml=getQuickHomeData();
			U.log("CALLED");
			
			if(quickHtml !=null){
				//U.log("0000000000000000000000000000000000000000000000000000000000"+quickHtml);
				//quickHtml += U.getHTML(U.getSectionValue(quickHtml, "<div class=\"property-search-load-more\"><a class=\"button\" href=\"", "\" data-paged=\"2\""))	;
				dropheadSec=U.getSectionValue(quickHtml, "header-main-navigation", "property-search-results-count");	
				//quickHtml=quickHtml.replace(dropheadSec, "");
			}
			String quickMoveInHomesData=getQuickHomesData(comName,quickHtml);
			if(quickMoveInHomesData!=null){
			 dropheadSec=U.getSectionValue(quickMoveInHomesData, "header-main-navigation", "33 Properties were found");	
			}

			//===================== FLOORPLANS SECTION ==================================
			String floorplanData = ALLOW_BLANK;
						
			ArrayList<String> floorplansec = Util.matchAll(html, "[\\s\\w\\W]{150}card card--qmi card--floorplan[\\s\\w\\W]{50}", 0);
			//U.log("floorplansec: "+floorplansec);
						
			if(floorplansec != null) {
								
				for(String floorSec:floorplansec) {
					
					String floorurl = U.getSectionValue(floorSec, "href=\"", "\"");
					floorurl = "https://www.pyattbuilders.com" + floorurl;
					U.log("floorurl: "+floorurl);
					
					String floorHtml = U.getHtml(floorurl, driver);
					String floorDesc = U.getSectionValue(floorHtml, "cms-floorplan__title-text\">", "</header>");
					U.log("floorDesc: "+floorDesc);
					
					floorplanData += floorDesc;
					
				}
			}
			
			//============= Address ===============
			String geo = "False";
			String [] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			
//			if(html.contains("Model / Sales Center")) {
//				
//				String addSec = U.getSectionValue(html, "Model / Sales Center", "a>");
//				U.log("addSec ---- "+addSec);
//				
//				if(addSec != null) {
//					
//					String addSection = U.getSectionValue(addSec, "view Sales office in Google Map\">", "</").trim();
//
//					add = U.getAddress(addSection);
//					
//				}
//			}
//			
//			U.log("ADDRESS =========== "+Arrays.toString(add));
			
			
			if(latLong[0] != ALLOW_BLANK && latLong[1] != ALLOW_BLANK){
				add = U.getAddressGoogleApi(latLong);
				if(add == null) add = U.getAddressHereApi(latLong);
				geo = "True";
			}
			
			if(comUrl.contains("https://www.finecraftbuilders.com")){
				if(planHtmls == null)
					planHtmls = fetchFineBuilderData(comUrl);
				
				//====== LatLng======
				String latLngSec = U.getSectionValue(html, "!2d", "!2m");
				if(latLngSec != null){
					String vals[] = latLngSec.split("!3d");
					latLong[0] = vals[1];
					latLong[1] = vals[0];
				}
				//=======Address =====
				String addSec = U.getSectionValue(html, "Model Homes</h4>", "</p>");
				if(addSec != null){
					addSec = addSec.replaceAll("</strong><br>|The Cornerstone Series", "").replace("<br>", ",").replaceAll("<.*>", "");
					add = U.getAddress(addSec);
				}
			}
			
			//System.out.println(Arrays.toString(latLong)  + "-------");
			if(comUrl.contains("http://www.pyattbuilders.com/new-england-way-heritage-hills/")){
				add[0]="Treetops Boulevard";
				add[1]="Avon";
				add[2]="IN";
				add[3]="46123";
				latLong = U.getlatlongGoogleApi(add);
				if(latLong == null) latLong = U.getlatlongHereApi(add);
				geo = "TRUE";
				notes = "Address Taken From Home Plan Map";
			}
//			U.log(quickMoveInHomesData);
			//=========== Price ===============
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				
			html = html.replaceAll("0s|0k", "0,000").replace("$183s", "$183,000").replace("$233s", "$233,000").replace(".5k", ",500").replace("&#8211;", "-").replace("5s", "5,000");
			html=html.replaceAll("k</li>", ",000").replace("$390", "\\$390,000");
			String [] prices = U.getPrices(html.replace("s", ",000")+planHtmls+quickMoveInHomesData, 
					"Price: \\$\\d{3},\\d{3}\\s?(–|-)|start at \\$\\d{3},\\d{3}|property-price\">\\$\\d{3},\\d{3}|\\s?\\$\\d{3},\\d{3}|Starting at\\s+<div class=\"listPrice\">\\s+\\$\\d{6,}|Upper \\$\\d{3},\\d{3}|(S|s)tarting at \\$\\d{3},\\d{3}|FROM \\$\\d{3},\\d{3}|start at \\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}<",
					0);
			
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("prices-->"+minPrice+" "+maxPrice);
			
			//============ Sqft ==============
			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String [] sqft = U.getSqareFeet(html+planHtmls+quickMoveInHomesData, 
					"\\d,\\d{3} - \\d,\\d{3}\\s+sf|\\d,\\d{3}\\s+sf|from \\d{1},\\d{3} � \\d{1},\\d{3}|property-size\">\\d,\\d{3} SQ FT</li>|\\d,\\d+ – \\d,\\d+ square feet|\\d{4} sq ft</li>|Sq Ft: \\d,\\d{3} (–|-) \\d,\\d{3}|Sq Ft: \\d,\\d{3}\\s?–\\s?\\d,\\d{3}|</span>\\s?2652 sq ft|\\s\\d{4} sqft</h3>|Sq Ft: \\d,\\d{3}|\\d,\\d{3} SQFT</h4>|\\d,\\d{3}\\s*-\\s*\\d,\\d{3} SQ\\s*FT|from \\d,\\d{3} - \\d,\\d{3} square feet", 0);
			
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
			
			//=========== Property Type ==================
			if(planHtmls != null){

				planHtmls = planHtmls.replaceAll(">Patio</a>|Lane and Patio|the-patio-series|The Patio Series<|Farmhouse style elevation", "");
				
			}
//			U.log(Util.matchAll(html+planHtmls+quickMoveInHomesData, ".*traditional.*",0));
			String rem = "(F|f)armhouse style elevation|(T|t)raditional style elevation|(T|t)raditional-style elevation|Craftsman style elevation|Craftsman-style elevation";
/*			if(quickMoveInHomesData!=null)quickMoveInHomesData=quickMoveInHomesData.
					replaceAll("(F|f)armhouse style elevation|(T|t)raditional style elevation|Traditional-style elevation", "");
*///			html = html.replaceAll("the-patio-series|The Patio Series<", "patio homes");
			
			if(quickMoveInHomesData!=null)
				quickMoveInHomesData = quickMoveInHomesData.replace("2 separate living spaces", " Story 2 ").replace("cozy and luxurious,", " luxury Homes ").replace("One Level Design", "");
			
			String propType = U.getPropType((quickData+html+planHtmls+quickMoveInHomesData+allPlanHtml + floorplanData).replaceAll(rem, ""));
			U.log("property Type ========= "+propType);
			if((comUrl.contains("Estates")||comName.contains("Estates"))&& !propType.contains("Estates")) {
				if(propType.length()>2) {
						propType+=", Estate-Style Homes";
				}else
					propType="Estate-Style Homes";
			}
			
			//============ Property Status ==============
			
			String propStatus = ALLOW_BLANK; 	
			html = html.replaceAll("Coming Soon&quot|Quick Move|QUICK MOVE|Move-in home remaining in this|Only 2 Quick Move-in homes ", "");
			//html = U.removeSectionValue(html, "<head>", "</head>");
			propStatus = U.getPropStatus(html);
			
			U.log("Property status is:::"+propStatus);
			//U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30} [\\s\\w\\W]{30}", 0));
			
			
			U.log(">>status<<<>>>"+propStatus);
			/*if(quickHtml != null){
				U.log(quickMoveInHomesData);
				if(quickMoveInHomesData.toLowerCase().trim().contains(comName.toLowerCase().trim()) || quickHomes.length>0){
					if(!propStatus.equalsIgnoreCase("Quick Move")){
						if(propStatus != ALLOW_BLANK) propStatus +=", Quick Move-In";
						else propStatus ="Quick Move-In";
					}
				}
			}*/
			
			U.log("quickCount =============  "+quickCount);
			if(quickCount > 0) {
				
				if(propStatus == ALLOW_BLANK)
					propStatus = "Quick Move-Ins";
				else if(propStatus != ALLOW_BLANK)
					propStatus = propStatus + ", Quick Move-Ins";	
			}
			
			U.log("Final propewrty status::::::"+propStatus);
			
			//=============Community Type ==========
			String comType = ALLOW_BLANK;
			if(mainSection != null)	comType = U.getCommunityType(mainSection);
			else comType = U.getCommunityType(html);
			
			//============ Derived Property Type ============
			String dType = U.getdCommType(quickData+html+planHtmls+quickMoveInHomesData+ floorplanData);
			
			if(comUrl.contains("/meadow-lake-estates/"))propStatus=propStatus.replaceAll("Sold Out", "Section 1 Sold Out");
			if(comUrl.contains("/neighborhood/hollowbrook/"))propStatus=propStatus.replaceAll("1 Lot Remaining, Only A Few Lots Remaining, Quick Move-In", "Only A Few Lots Remaining, Quick Move-In");

			if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/thorp-farms/"))propType += ", Luxury Homes";
             if(comUrl.contains("https://www.pyattbuilders.com/neighborhood/deer-meadows"))dType="2 Story";
			U.log("Dtype ============= "+dType);
			//
			U.log(add[1].trim()+" - ");
			comName=comName.replace(add[1].trim()+" - ", "")
					.replaceAll("Franklin - ", "");
			U.log(comName);
			data.addCommunity(comName, comUrl, comType);
			data.addLatitudeLongitude(latLong[0], latLong[1], geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus);
			data.addNotes(notes);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
		
		j++;
		}
	}
	//This below function is used to find latLng from html page.
	String [] findLatLng(String latLngSec){
		String latLng [] = {ALLOW_BLANK,ALLOW_BLANK};
		Matcher mat = Pattern.compile("\\d{2}\\.\\d{3,},-\\d{2}\\.\\d{3,}",Pattern.CASE_INSENSITIVE).matcher(latLngSec);
		while(mat.find()){
			latLng = mat.group().split(",");
		}
		return latLng;
	}
	
	final String fetchFineBuilderData(String comUrl) throws Exception{

		String planHtmls = U.getHTML(comUrl+"/our-homes/");
		U.log(comUrl+"/our-homes/");
		String floorPlanSection[] = U.getValues(planHtmls, "series-card-floor-plans\">", "</ul>");
		
		for(String floorPlanSec : floorPlanSection){
			
			String [] planUrls = U.getValues(floorPlanSec, "<a href=\"", "\"");
			for(String planUrl : planUrls){
				U.log("planUrl:::::"+planUrl);
				String planHtml = U.getHTML(planUrl);
				planHtmls += U.getSectionValue(planHtml, "<h3 class", "<div id=\"footer");
			}
		}
		
		return planHtmls;
	}
	private String getQuickHomesData(String comName,String quickHtml) throws IOException{
		String html=ALLOW_BLANK;
		String quickLinkes[]=U.getValues(quickHtml, "<div class=\"item-grid-view clearfix\">", "Calculate your Mortgage");
		for(String quickSec:quickLinkes){
//			U.log(quickSec.toLowerCase().contains(comName.toLowerCase().trim()));
			if(quickSec.toLowerCase().contains(comName.toLowerCase().trim()) && !quickSec.contains("(OLD) ")){
				String quickUrl=U.getSectionValue(quickSec, "<p class=\"post-title\"><a href=\"", "\">");
				U.log("quickUrl++++"+quickUrl);
				if(quickUrl!=null && !quickSec.contains("Build Now")){
					html+=U.getSectionValue(U.getHTML(quickUrl), "<div class=\"page-section-inner\">", ">Calculate your Mortgage</span></button> ")
							+ U.getSectionValue(U.getHTML(quickUrl), "<div class=\"page-section page-section-property-single\">", "<!-- SCHEDULE A TOUR AREA -->");
				}
			}
			else
				continue;
		}
	
		return html;
	}
	public String getQuickHomeData() throws Exception{
		String Allquickdata=ALLOW_BLANK;
		String quickhtnm=U.getHTML("https://www.pyattbuilders.com/quick-move-ins/");
		
		String dropheadSec=U.getSectionValue(quickhtnm, "<html lang=\"en-US\"", "<div class=\"property-search-results-count\">");
		
		if(dropheadSec != null) quickhtnm=quickhtnm.replace(dropheadSec, "");
		
		Allquickdata+=quickhtnm;
		for(int i=2;i<6;i++) {
			if(!quickhtnm.contains(">LOAD MORE</a></div>"))break;
			else {
				U.log("https://www.pyattbuilders.com/quick-move-ins/page/"+i+"/");
				Allquickdata+=quickhtnm+U.getHTML("https://www.pyattbuilders.com/quick-move-ins/page/"+i+"/");
				dropheadSec=U.getSectionValue(Allquickdata, "<html lang=\"en-US\" ", "<div class=\"property-search-results-count\">");	
				Allquickdata=Allquickdata.replace(dropheadSec, "");

			}
		}
		return Allquickdata;
	}
	
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("<community-microsite")) {
			
			String frameSec = U.getSectionValue(html, "<community-microsite", "lots=");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				
				ArrayList<String> pins = Util.matchAll(frameSec, "latitude", 0);
				U.log("Count Pins: "+pins.size());
				totalUnits = String.valueOf(pins.size());
			}
			
		}
		return totalUnits;
	}
}