package com.shatam.b_301_324;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
import com.sun.jna.platform.win32.COM.COMUtils;

import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ExtractTraditionsofAmerica extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver = null;
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractTraditionsofAmerica();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Traditions of America.csv", a.data()
				.printAll());
	}

	public static String homeurl = "https://www.traditionsofamerica.com";

	public ExtractTraditionsofAmerica() throws Exception {
		super("Traditions of America", homeurl);
		LOGGER = new CommunityLogger("Traditions of America");
	}

	int j = 0;

	public void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver(U.getFirefoxCapabilities());	
//		
		U.setUpChromePath();
		
		ChromeOptions options = new ChromeOptions ();
		options.addExtensions (new File("/home/shatam/CRXChrome/Browsec-VPN-Free-and-Unlimited-VPN_v3.22.5.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities ();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		driver = new ChromeDriver(capabilities);

		Thread.sleep(6000);
				
		
//		U.bypassCertificate();
//		String html1 = U.getHtml("https://www.traditionsofamerica.com/find-your-home",driver);
//        U.bypassCertificate();
//        
		String html1 = U.getHTMLwithProxy("https://www.traditionsofamerica.com/find-your-home");

        
		html1 = html1.replaceAll(" </div>\\s*</div>\\s*</div>", "endSec");
		String[] comSections =U.getValues(html1, "class=\"module-communities-list-map__list-item js-map-list-item js-popup-html\">", "endSec");
		U.log(comSections.length);

		for(String comSec : comSections){
			String cUrl =U.getSectionValue(comSec, "<a href=\"", "\"");
			//U.log(cUrl);
			commDetails(cUrl, comSec,U.getSectionValue(comSec, "<a href=\"", "\""));
		}

		try{driver.quit();}catch(Exception e){}
		LOGGER.DisposeLogger();

	}
	
	

	public void commDetails(String commUrl, String comData,String dumurl) throws Exception {
	//TODO : For Single Community Execution	
//	if(!commUrl.contains("https://traditionsofamerica.com/communities/green-pond/"))return;
//		if(j >= 18)	
		{
			
			if (data.communityUrlExists(commUrl)){
				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);
            U.log("Count"+j);
			U.log("commUrl:::::::"+commUrl);
//			String html2 = U.getHtml(commUrl,driver);
//			U.bypassCertificate();
//			String html2=U.getHtml(commUrl,driver);
//			U.bypassCertificate();
			
			U.bypassCertificate();
			String html2=U.getHTMLwithProxy(commUrl);
			U.bypassCertificate();
			//U.log("PPP"+Util.match((html2), "2 Levels"));
//		U.log(comData);
	
		String commName = U.getSectionValue(comData, "<span class=\"screen-reader-text\">", "<");
		if(commUrl.contains("pinnacle-at-adams"))commName = "Pinnacle At Adams";
		
		String mapHtml = ALLOW_BLANK;
		String floorHtml = ALLOW_BLANK;
		String amenHtml = ALLOW_BLANK;
		String contactHtml = ALLOW_BLANK;
		
		//--------nav tabs------------
		String navSec = U.getSectionValue(html2, "<div class=\"SiteHeader__secondary", " </ul>");
		if(navSec !=null){
		String[] navUrls = U.getValues(navSec, "<a href=\"", "\"");
		
		for(String navUrl : navUrls){
			navUrl = "https://www.traditionsofamerica.com"+navUrl;
			U.log("navUrl====="+navUrl);
			if(navUrl.contains("contact")){
				mapHtml =  U.getHtml(navUrl, driver);
			}
//			if(navUrl.contains("floorplans")){
//				floorHtml =  U.getHtml(navUrl, driver);
//			}
			if(navUrl.contains("amenities")){
				amenHtml =  U.getHtml(navUrl, driver);
			}
			if(navUrl.contains("contact")){
				contactHtml =  U.getHtml(navUrl, driver);
			}
		}
		}
		String notes = ALLOW_BLANK;
		notes = U.getnote(html2);
		// ===========Address - Lat - long =================
		String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String[] latlng = { ALLOW_BLANK, ALLOW_BLANK };
		String flag = "False";
		String addSec = U.getSectionValue(html2, "<div class=\"heading-mini\">Address</div>", "<div class=\"heading-mini\">Hours");//U.getSectionValue(mapHtml,"<i class=\"fa fa-map-marker\" aria-hidden=\"true\"> </i>", "</li>");
		U.log("addSec11 : "+addSec);
		if(addSec != null ){
			addSec = U.getSectionValue(addSec, "target=\"_blank\">", "</a>");
			addSec = addSec.replace("<br>", ",").replace("American Way 	Downingtown", "American Way, Downingtown").replace("105 Liberty Blvd 	Canonsburg", "105 Liberty Blvd,	Canonsburg");
			//addSec = U.formatAddress(addSec);
			addSec=addSec.replace("<br />", ", "
					+ "");
					
			U.log("addSec : "+addSec);
			String[] tempAdd = U.getAddress(addSec);//addSec.split(",");
			if(tempAdd.length==4){
				add[0] = tempAdd[0].trim();
				add[1] = tempAdd[1].trim();
				add[2] = tempAdd[2].trim();
				add[3] = tempAdd[3].trim();
			}
		}
		else if(commUrl.contains("communities/chesterfield-county/")) {
			add[1] = "Richmond";
			add[2] = "VA";
			latlng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlng);
			flag="True";
					
			
		}else if(commUrl.contains("/communities/columbus-suburbs/")) {
			add[1] = "Dublin";
			add[2] = "OH";
			latlng=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlng);
			flag="True";
		}
		else{
			addSec = U.getSectionValue(html2, "<p class=\"community-bar-city-state\">", "</p>");
			if(addSec!=null) {
			String[] tempAdd = addSec.split(",");
			add[1] = tempAdd[0].trim();
			add[2] = tempAdd[1].trim();
			}
			
		}
		
		if(addSec==null&& add[0]==ALLOW_BLANK) {
			addSec=U.getSectionValue(html2, "<div class=\"heading-mini\">Address</div>","<div class=\"heading-mini\">Hours");
		    addSec=addSec.replace("target=\"_blank\">", "</a>").replace("<br>", ",");
		    if(addSec!=null) {
		    String[] tempAdd2 = U.getAddress(addSec);//addSec.split(",");
			if(tempAdd2.length==4){
				add[0] = tempAdd2[0].trim();
				add[1] = tempAdd2[1].trim();
				add[2] = tempAdd2[2].trim();
				add[3] = tempAdd2[3].trim();
			}
		    }
		}
		
		U.log("addSec : "+Arrays.toString(add));
		
		// =============== logic of address end ========================

		
		//latlng is not shown to uset
		//------Lat-Lng from community contact page----
		String latLngSec = U.getSectionValue(contactHtml, "https://maps.googleapis.com/maps/api/staticmap?key=AIzaSyBVCNuRvs3MpgVQByP52K0h4OZSKqA8hHc&amp;center=", "&amp;zoom");
		if(latLngSec!=null)
			latlng = latLngSec.split(",");
		if(latLngSec==null) {
			latLngSec = U.getSectionValue(html2, "locations: [{\"address\":", "}");
			if(latLngSec==null)
				latLngSec = U.getSectionValue(html2, "location: {", "}");
			if(latLngSec!=null) {
			latlng[0] = U.getSectionValue(latLngSec, "\"lat\":\"", "\"");
			latlng[1] = U.getSectionValue(latLngSec, "\"lng\":\"", "\"");
			}
		}
		
		U.log("latlng : "+Arrays.toString(latlng));
		
		if(add[0]!=null && latlng[0].length()<4){
			latlng = U.getlatlongGoogleApi(add);
			if(latlng == null) latlng = U.getlatlongHereApi(add);
			flag="True";
		}
		
		//lat-lng taken from reg google map
		if(commUrl.contains("/green-pond/")){
			latlng = "40.67873432,-75.30392063".split(",");
		}
		if(commUrl.contains("/south-hills/")){
			latlng = "40.29421000,-80.15186200".split(",");		
		}
		if(commUrl.contains("/dublin-suburbs/")){
			latlng = "40.09171000,-83.18746800".split(",");
		}
		if(commUrl.contains("/chesterfiled-county/")){
			latlng = "37.36719100,-77.49214900".split(",");
		}
		if(add[0] == ALLOW_BLANK && add[3] == ALLOW_BLANK && latlng[0].length() > 4){
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			flag = "True";
		}
		
//====== Quick Home ===========
		String quickHtml = U.getHtml("https://www.traditionsofamerica.com/quick-move-in-homes", driver);
		String[] quickSec = U.getValues(quickHtml, "<card class=\"card move-in-ready\"", "View Details");
		
		String quickData = "";
		int quickCount = 0;
		int soldCount = 0;
		for(String quick : quickSec) {
			
			quick =quick.replaceAll("LititzExt", "");
			if(quick.contains(commName)){
				U.log(":::::::::"+quick);
				quickData += quick;
				quickCount++;
				if(quick.contains("Sold") && !quick.contains("ng-hide"))
					soldCount++;
			}
		}
		String designerHomes[] = U.getValues(html2,"<a class=\"home-preview__link no-style\" href=\"","\"");
		for(String home : designerHomes) {
			String fHtml = U.getHtml(home, driver);
			quickData += U.getSectionValue(fHtml, "<div id=\"overview\"", "Interactive Floorplan</a>");
		}
//		U.log(quickData);
		//--------Address taken from city and state-------
		if(add[0].length()<4 && add[3].length()<4){
			add = U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			notes = "Address and Lat-Lng Taken Using City And State";
			flag = "True";
		}
		//-----Quick Move-in
		String quickHtm =ALLOW_BLANK;
		if(html2.contains(">Quick Move-In</a>")) {
			String quickUrl = commUrl+"quick-move-in";
			quickHtm = U.getHtml(quickUrl,driver);
		}
//		U.log(quickHtm);
		//==============================
		// ============= Sq - Ft - Prices ========================
		String minPrice = ALLOW_BLANK , maxPrice = ALLOW_BLANK;
		String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
		if(quickData!=null)quickData = quickData.replace("Furniture valued at $25,000 ", "")
				.replaceAll("<!---->[\\w\\s\\W]*<!---->", "");
		html2 = html2.replaceAll("Save up to \\$\\d{2},\\d{3} ", "")
				.replace("From the low $400's", "From the low $400,000");
		comData = comData.replace("From the low $400's", "From the low $400,000")
				.replace("00s", "00,000").replace("0's", "0,000");
		html2 = html2.replaceAll("00s|0's", "00,000").replace("+ Sq. Ft.</div>", " Sq. Ft.</div>")
				.replaceAll("Clubhouse: \\d,\\d{3} sq ft|\\d,\\d{3} sq\\. ft\\. Clubhouse","");
		if(floorHtml != null) floorHtml = floorHtml.replace("00s", "00,000").replaceAll("\"text\":\"\\d+,\\d+ sq\\. ft\\. Clubhouse", "");

//		U.log("MMMMMMMMMMMMMMMMMMMMMMMMMMMM "+Util.matchAll(comData+html2, "[\\s\\w\\W]{30}3,380[\\s\\w\\W]{30}", 0));
//		U.log(floorHtml);
		String[] Prices = U.getPrices(html2+comData, "\\$\\d{3},\\d{3}\\s*</div>|From the mid \\$\\d{3},\\d{3}|From the upper \\$\\d{3},\\d{3}|From the low \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}", 0);
		minPrice = (Prices[0] == null) ? ALLOW_BLANK : Prices[0];
		maxPrice = (Prices[1] == null) ? ALLOW_BLANK : Prices[1];
		U.log("minPrice: "+minPrice+"\tmaxPrice: "+maxPrice);
		String[] area = U.getSqareFeet(html2+comData+floorHtml+quickData,
				"\\d,\\d{3} - \\d,\\d{3} Sq. Ft|\\d,\\d+ - \\d,\\d+ (<br />|<br>)<span>Sq. Ft.|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|[\\d,]*\\d+ <br><span>Sq. Ft.|\\d{4} Sq. Ft.|\\d,\\d{3} Sq. Ft.", 0);
		minSqFt = (area[0] == null) ? ALLOW_BLANK : area[0];
		maxSqFt = (area[1] == null) ? ALLOW_BLANK : area[1];
		
		U.log("minSqFt: "+minSqFt+"\tmaxSqFt: "+maxSqFt);
	
		//-----------All floor plan Data---------
		String allFloorData = ALLOW_BLANK;
//		U.log("<a ng-href=\""+dumurl+"/floorplans/");
//		if(html2.contains("/floorplans")) {
			
			String[] flrUrls = U.getValues(html2, "<a class=\"floorplan-preview__link no-style\" href=\"", "\""); 
			for(String flrUrl : flrUrls){
				U.log("flrUrl : "+flrUrl);
				String fHtml = U.getHtml(flrUrl, driver);
				
				allFloorData += U.getSectionValue(fHtml, "<div class=\"hero__content\">", "Interactive Floorplan</a>");
			}
//		}
		//----------Community type---------------
		html2 = html2.replace("resort-living at", "resort-style living").replaceAll("55\\+ Live|55\\+ communities", "55+ Community");
		
				String commType = U.getCommunityType(commName + html2.replaceAll("resort-style 55 plus active adult community|hd/TOA coming soon golf course|content=\"Locust Valley is a resort-style retirement|Pittsburgh, PA \\| Active Adult Living \\| Traditions of America", ""));
				
				U.log(commType);
				
		//--------_Status-------------
				html2=  html2.replaceAll("traditionsofamerica.com/>Quick Move|Clubhouse: Now Open|Clubhouse Grand Opening<|move-in-homes\">Quick Move|quick-move-in-homes\"|TOA coming soon lifesty|-Closeout-WebBanner| Coming Soon All|TOA coming soon|coming soon lifestyle|gem is sold out|Homes Available Now</a>|One Quick Move-In", "")
						.replace("ONE Spectacular, Award-Winning Home Remains", "One Home Remains")
						.replace("New Homesites with Spectacular Views Just Released!", "New Homesites Just Released");
				
				String Status = null;
				html2=html2.replace("Clubhouse Grand Opening","").replace("CLUBHOUSE Grand Opening", "").replace("Grand Opening Great Room","").replace("Grand Opening Front Exterior", "").replace("Clubhouse: now OPEN", "");
				
//				U.log("PP"+Util.matchAll((comData+html2), "[\\w\\W\\s]{40}Now Open[\\w\\W\\s]{40}", 0));
				Status = U.getPropStatus((comData+html2).replaceAll("Now OPEN and in Full Swing|grand opening\"|Clubhouse Grand Opening|quick move|Clubhouse: Now OPEN|Quick Move-In</a></li>|Quick Move-In Homes</a>|\"community__price\">\\s*Sold Out|Model Grand Opening Coming Soon", "")); //.replace("ONE", "1")
				U.log("Status:: "+Status);
//				U.log("MMMMMMMMMMM "+Util.matchAll((comData+html2).replaceAll("traditionsofamerica.com/>Quick Move|move-in-homes\">Quick Move|quick-move-in-homes\"",""), "[\\w\\s\\W]{30}sold[\\w\\s\\W]{30}", 0));
		//----Homes Available Now-------
		String availablehTml = U.getHtml("https://www.traditionsofamerica.com/designer-model-homes", driver);	
		int availCount = 0;
		String[] availHomes = U.getValues(availablehTml, "<card class=\"card move-in-ready\"", ">View Details");//Util.matchAll(availablehTml, "<div class=\"community red\">(.*?)View Details", 1);
		U.log(availHomes.length);
/*		for(String avHomes : availHomes )
		{	//U.log(avHomes);
			
			if(avHomes.contains(commName)){
				availCount = availCount+1;	
			}
			
		}
*/		
				String Type = ALLOW_BLANK;
				String dType = ALLOW_BLANK;
	//			U.log(Util.matchAll(quickData+quickHtm,"[\\w\\s\\W]{30}coming[\\w\\s\\W]{30}",0));
				if(floorHtml!=null)floorHtml=floorHtml.replace("1 <br><span>Stories", "1 story");
				html2 = html2.replaceAll("Traditions of America|traditions|Traditions|25-story", "")
						.replace("plenty of customization opportunities", "plenty of custom homes opportunities");
				Type = U.getPropType((html2 +amenHtml+allFloorData+quickData).replace("sq ft of luxury, there’s room for even more resort-style amenities", "luxury amentities").replace("sq ft of luxury, there’s room", "sq ft of luxuries, there’s room").replace("open and traditional", "traditional exterior").replaceAll("Craftsman\\.jpg", ""));
				
//				U.log("PPP"+Util.match((html2 +allFloorData+floorHtml+quickData), "2 Levels"));
				dType = U.getdCommType((html2 +allFloorData+floorHtml+quickData).replace("1-2 Levels", "1 Story, 2 Story").replace(" <br><span>Stories</span>", " story").replaceAll("ng-src=\".*\"", ""));

				if(commUrl.contains("communities/silver-spring/"))minSqFt=ALLOW_BLANK;
//					Status = Status.replaceAll("Quick Move-in Homes,|, Quick Move-in Homes|Quick Move-in Homes", "");
			
				U.log(quickCount+":::::::"+soldCount);
				if(quickData.length()<=5) {
					Status = Status.replaceAll("Quick Move-in Homes,|, Quick Move-in Homes|Quick Move-in Homes", "");
				}
				if(Status==null ||Status.length()<3)
					Status = ALLOW_BLANK;
				if(quickCount > 0 && quickCount>soldCount){
					if(Status == ALLOW_BLANK) Status = "Quick Move-in Homes";
					else if(Status != ALLOW_BLANK && !Status.contains("Quick Move")) Status += ", Quick Move-in Homes";
				}
				Status = Status.replace("Just Released, New Lots Just Released", "New Lots Just Released");
		
//		===========================================================================================
				String lotCount=ALLOW_BLANK;
				String [] lotdata=null;
				int sum=0;
				String lotsec=U.getSectionValue(html2, "<div class=\"sitemap__lots\">", "<div class=\"sitemap__lots-content\">");
				if(lotsec!=null) {
					
					U.log("Hello 111");
					lotdata=U.getValues(lotsec, "<div class=\"sitemap__icon", ">");
					if(lotdata.length>0) {
						lotCount=Integer.toString(lotdata.length);
					}
					else
						lotCount=ALLOW_BLANK;
				}
				else {
					
					U.log("Hello 222");
					lotsec=U.getSectionValue(html2, "Community Siteplan</div>", "</iframe>");
					if(lotsec!=null && lotsec.contains("Interactive Sitemap")) {
						
						U.log("Hello mmmmm");
					String mapLink=U.getSectionValue(lotsec, "src=\"", "\"").trim();
					U.log("mapLink=="+mapLink);
					if(mapLink!=null) {
						 mapHtml=U.getHtml(mapLink, driver);
//						 Thread.sleep(30000);;
							lotdata=U.getValues(mapHtml, "<div class=\"status ng-star-inserted\">", "<toggle>");
							
							U.log("lotdata.length=="+lotdata.length);
							if(lotdata.length>0) {
								for(String lotData :lotdata ) {
									U.log("lotData=="+lotData);
									lotData=U.getNoHtml(lotData);
									
									sum+=Integer.parseInt(Util.match(lotData, "\\d+"));
								}
							}
							lotCount=Integer.toString(sum);
					}
					}
				}
				U.log("lotCount=="+lotCount);
				
		data.addCommunity(commName, commUrl, commType);
		data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
		data.addPrice(minPrice, maxPrice);
		data.addAddress(add[0].trim(), add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addPropertyType(Type, dType);
		data.addPropertyStatus(Status);
		data.addNotes(notes);
		data.addUnitCount(lotCount);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
	}
		j++;
	}
}