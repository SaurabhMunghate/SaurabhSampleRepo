/*
 * New Modification Aditya.
 */
package com.shatam.b_301_324;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.httpclient.util.EncodingUtil;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.james.mime4j.codec.EncoderUtil.Encoding;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractVanDaeleHomes extends AbstractScrapper {
	static String BASEURL = "https://www.vandaele.com";
	WebDriver driver = null;
	static int j=0;
	CommunityLogger LOGGER;
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractVanDaeleHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Van Daele Homes.csv", a.data()
				.printAll());
	}

	public ExtractVanDaeleHomes() throws Exception {

		super("Van Daele Homes", BASEURL);
		LOGGER = new CommunityLogger("Van Daele Homes");
	}

	public void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		
//		String html = U.getHTMLwithProxy("https://www.vandaele.com/");
		String html = U.getHTML("https://www.vandaele.com/");
		String qData=U.getHtml("https://www.vandaele.com/northern-california/homefinder/", driver);
		//String region = U.getSectionValue(html, "Communities</span></a><ul class=\"sub-menu\">",		"<a  href=\"#\">");
		//U.log(region);
		String regionurls[] = U.getValues(html, "<div class='fusion-megamenu-title'><a href=\"https://www.vandaele.com/", "\"");
		U.log(regionurls.length);
		for (String regionurl : regionurls) {
			U.log("regionurl::::::::;"+regionurl+":::::::::::::::::::");
			String homeFinderUrl="https://www.vandaele.com/"+regionurl+"homefinder/";
			addregionDetails(qData,regionurl,homeFinderUrl);
}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	public void addregionDetails(String qData,String regionurl,String homeFinderUrl) throws Exception {
		String regHtml = U.getHTML("https://www.vandaele.com/wp-json/wp/v2/"+regionurl+"/?per_page=100");
		U.log("https://www.vandaele.com/wp-json/wp/v2/"+regionurl+"/?per_page=100");
		regHtml = org.apache.commons.lang.StringEscapeUtils.unescapeJava(regHtml);
		//U.log(regHtml);
		U.log("FinderUrl: "+homeFinderUrl);
		
		//------REDIRECTING JULY 2022-----------------------
		if(homeFinderUrl.contains("utah/homefinder")) {
			
			String utahData = U.getHTML("https://www.vandaele.com/utah/");
			
			String[] comSections = U.getValues(utahData, "https://www.vandaele.com/utah/community/","\"");
			U.log("UTAH SECS: "+comSections.length);
			
			for(String comSec:comSections) {
				
				String url = "https://www.vandaele.com/utah/" + comSec;
				U.log("UTAH url: "+url);
				
				String cominfo = U.getHTML("https://www.vandaele.com/wp-json/wp/v2/utah/?per_page=100&exclude=5901");
				
				if(url.contains("/elevate-at-holladay-hills")) {
					
					String comData = U.getSectionValue(cominfo, "\"id\":7397", "\"_links\"");
					addCommunityDetails(url, comData, ALLOW_BLANK, qData);
				} 
				
				if(url.contains("/axis-at-north-station")) {
					
					String comData = U.getSectionValue(cominfo, "\"id\":7114", "\"_links\"");
					addCommunityDetails(url, comData, ALLOW_BLANK, qData);
				} 
				
				
				
			}
		}
		else {
			
			String comSections[] = U.getValues(regHtml,	"\"slug\":\"","\"_links\":{\"");
			U.log(comSections.length);
			for (String comSec : comSections) {
				//U.log("%%%%"+comSec);
				String url = U.getSectionValue(comSec, "\"link\":\"", "\"");
				//U.log("url::::::::::"+url);
				
				addCommunityDetails(url, comSec, homeFinderUrl,qData);
			}
		}
		

	}

	public void addCommunityDetails(String cUrl, String comData, String homeFinderurl, String qData) throws Exception {
		//TODO ::
		

//		if(!cUrl.contains("https://www.vandaele.com/northern_california/community/veranda-river-islands/"))return;
		
		
		if (data.communityUrlExists(cUrl)){
			LOGGER.AddCommunityUrl(cUrl+ "---------------------------------repeat");
			return;
		}
		LOGGER.AddCommunityUrl(cUrl);
		
		String comHtml = U.getHTML(cUrl);
		U.log("cUrl::::::::::"+cUrl);
		U.log(U.getCache(cUrl));
		String units=ALLOW_BLANK;
		int lotSize=0;
		//sitemap
				String sitemapUrl=U.getSectionValue(comHtml, "<a href=\"https://www.vandaele.com/site-plan/?post", "\" > Site Plan </a>");
				if(sitemapUrl!=null) {
					String siteMapHtml=U.getHtml("https://www.vandaele.com/site-plan/?post"+sitemapUrl, driver);
					U.log("https://www.vandaele.com/site-plan/?post"+sitemapUrl);
					U.log("Done");
					String iframeUrl=U.getSectionValue(siteMapHtml, "<iframe src=\"", "\"");
					if(iframeUrl!=null) {
						U.log(iframeUrl);
						String iframUrlData=U.getHtml(iframeUrl, driver);
						if(iframUrlData!=null) {
							String[] lotCount=U.getValues(iframUrlData, "<g id=\"lot_", "\"");
							lotSize=lotCount.length;							
						}
						
					}
				}
		if(lotSize!=0) {
			units=String.valueOf(lotSize);
		}
//		U.log(comData);///////////

		//------------community name------------------
		String comName = U.getSectionValue(comData, "title\":{\"rendered\":\"", "\"");
		U.log("comName:::::::"+comName);
		
		if(comName==null) comName = U.getSectionValue(comHtml, "<title>", "&#8211");
		U.log("comName ===== "+comName);
		
		
		
		String floorUrl= U.getSectionValue(comHtml, "<li class=\"\"><a href=\"https://www.vandaele.com/floor-plans/", "\"");
		U.log("floorUrl : "+floorUrl);
		
				
		String floordata = U.getHTML("https://www.vandaele.com/floor-plans/"+floorUrl);
		
		
//==		
		//------------------HomeFinder data by request post method----------------
				String HomeFinderHtml="";
				try {
				if(homeFinderurl.contains("southern")) {
					HomeFinderHtml=U.sendPostRequestAcceptJson("https://twix.newhomesource.com/Homes/Default", "{\"request\":{\"PartnerId\":,\"SiteUrl\":\"vandaelehomessoca\",\"State\":\"\",\"MarketIds\":\"\",\"Cities\":\"\",\"CommunityIds\":\"\",\"Type\":\"Default\",\"BrandIds\":\"\",\"Facets\":{\"NumberOfBedrooms\":-1,\"NumberOfBathrooms\":-1,\"NumberOfGarages\":-1,\"MinimumPrice\":-1,\"MaximumPrice\":-1,\"Builder\":0,\"Community\":0,\"Builders\":[4423]}}}");
				}
				else {
					HomeFinderHtml=U.sendPostRequestAcceptJson("https://twix.newhomesource.com/Homes/Default", "{\"request\":{\"PartnerId\":766,\"SiteUrl\":\"vandaelehomesnca\",\"State\":\"\",\"MarketIds\":\"\",\"Cities\":\"\",\"CommunityIds\":\"\",\"Type\":\"Default\",\"BrandIds\":\"\",\"Facets\":{\"NumberOfBedrooms\":-1,\"NumberOfBathrooms\":-1,\"NumberOfGarages\":-1,\"MinimumPrice\":-1,\"MaximumPrice\":-1,\"Builder\":0,\"Community\":0,\"Builders\":[4423]}}}");
				}
				} catch (RuntimeException e) {
					U.log(e);
				}
				
				String finderPriceSec=ALLOW_BLANK;
				if(HomeFinderHtml != null) {
					
					String[] finderSecs=U.getValues(HomeFinderHtml, "{\"ResultFacets", "},");
					U.log(finderSecs.length);
					for(String finderSec:finderSecs) {
						//U.log("finderSec: "+finderSec);
						if(finderSec.contains(comName)) {
							finderPriceSec+=finderSec;
						}
					}
					U.log("========"+finderPriceSec);
				}
				
		//------------Square Feet-------------------------
		
		String minSqFt = ALLOW_BLANK, maxSqFt = ALLOW_BLANK;
		
		String[] sqFt = U.getSqareFeet(comHtml+comData+floordata, "baths and \\d,\\d{3} square feet|approx\\. \\d,\\d{3} square feet|approximately \\d{1},\\d{3} to \\d{1},\\d{3} square feet|sf_range_[max|min]*\":\"\\d,\\d+|approximately \\d,\\d+ square feet", 0);
		
		minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		U.log("minSqFt :" + minSqFt + " maxSqFt:" + maxSqFt);
		
		//-----------Prices-------------
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		comData = comData.replace(" $900,000's", " $900,000").replace("$1 Millions", "$1,000,000 ").replace("$1.3", "$1,300,000").replace("mid $700's", "$700,000").replaceAll("\\$400s|\\$400's", "\\$400,000").replaceAll("00’s|00's", "00,000");//.replace("$900,000", "");
		//U.log("#$#$ "+comData+"#$#$");
		//U.log(comData);
		
		String sitePlanUrl = U.getSectionValue(comHtml, "https://www.vandaele.com/site-plan/", "\"");
		if(sitePlanUrl==null)sitePlanUrl="";
		String siteHtml = U.getSectionValue(U.getHTML("https://www.vandaele.com/site-plan/"+sitePlanUrl),"<div id=\"availability-list-outer\">","<!-- END availability-list -->");
		comData= comData.replace("$700s", "Mid $700,000");
		
//		U.writeMyText(comData);
		
		if(comData.contains("\"property_type\":\"SOLD OUT\"")){
			comData = comData.replaceAll("\\$(\\d,)?\\d{3},\\d{3}", "");
		}
		
		//not taken finderPriceSec because prices not found
		String[] price = U.getPrices(comHtml + comData + siteHtml, 
				"PriceRange\":\"\\$\\d,\\d{3},\\d{3}\"|PriceRange\":\"\\$\\d{3},\\d{3}\"|<h4>Price: \\$\\d,\\d{3},\\d{3}</h4>|From the Low \\$\\d{1},\\d{3},\\d{3}|Mid \\$(\\d,)?\\d{3},\\d{3}|low \\$\\d{1},\\d{3},\\d{3}|\\$\\d+,\\d+|From the \\$\\d,\\d{3},\\d{3}|pricing_info_[short|long]*\":\"\\d{3},\\d{3}\"|low \\$\\d{3},\\d{3}|(High|Mid) \\$\\d{3},\\d{3}", 0);
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
//		U.log(comData);
	  
//		U.log(Util.matchAll(comHtml + comData + siteHtml+finderPriceSec, "[\\w\\s\\W]{30}Millions[\\w\\s\\W]{20}", 0));
		
		U.log("minPrice :" + minPrice + " maxPrice:" + maxPrice);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(finderPriceSec, "[\\s\\w\\W]{30}1,050,950[\\s\\w\\W]{30}", 0));
		//-------feature data-----------
		String feaSec = ALLOW_BLANK;
		String feaUrl =U.getSectionValue(comHtml, "<li class=\"\"><a href=\"https://www.vandaele.com/features/?", "\"> Features");
		U.log("fea   "+feaUrl);
		if(feaUrl != null){
			String feaHtml = U.getHTML("https://www.vandaele.com/features/?"+feaUrl);
			//U.log(U.getCache(feaUrl));
			feaSec = U.getSectionValue(feaHtml, "<span class=\"entry-title\" ", "<div class=\"disclaimer");
			if(feaSec!=null)
			feaSec = feaSec.replace("carriage style garage doors", "");
		}
		
		//------virtual toour-----
        String nowSellingSection[] = U.getValues(comHtml, "Now Selling</span></a>", "Coming Soon</span></a>");

		String virTourSec = ALLOW_BLANK;
		String virTourUrl = Util.match(comHtml, "<h3 class=\"title-heading-center\" data-fontsize=\"22\" data-lineheight=\"27\"><a href=\"(.*?)\"",1);
		if(virTourUrl !=null){
		String virHtml = U.getHTML(virTourUrl);
		virTourSec = U.getSectionValue(virHtml, "carousel-inner feature_slider", "<!--");
		}
		//----------remove sectiom-----------
		String remFooter =U.getSectionValue(comHtml, "<footer id=\"footer\"", "</html>");
		if(remFooter!=null){
			comHtml = comHtml.replace(remFooter, "");
		}
		String remNavigation  = U.getSectionValue(comHtml, "<nav class=\"fusion-main-menu", "Toggle mobile menu\"></a>");
		if(remNavigation!=null){
			comHtml = comHtml.replace(remNavigation, "");
		} 
		
		//-----------community type--------------
		comHtml=comHtml.replace("resort-inspired recreation", "resort-class lake living");
		comData = comData.replaceAll("Porter Valley Country Club|Woodley Lakes Golf Course", "");
        String comType = U.getCommunityType(comHtml + comData ); 
        U.log("comType: "+comType);
		//-----------property type--------------------
       // U.log(comHtml);
        
   
        
        String propType = U.getPropType((comHtml + comData + feaSec).replaceAll("Patio photo|Patio image", ""));
     //   U.log("mmmmmmmmm"+Util.matchAll(comData , "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}", 0));       
        U.log("propType: "+propType);
		//U.log(comData);
		//--------derived type------------------------
        comData=comData.replaceAll("Two & Three-Story", " 2 Story and 3 Stories ").replace("New West, Spanish Colonial", "");
        
//        U.log("mmmmmm"+Util.matchAll(comData , "[\\w\\s\\W]{30}Spanish Colonial[\\w\\s\\W]{30}", 0));
        
        String dType = U.getdCommType((comHtml + comData +virTourSec).replaceAll("Floor|floor|Rancho Cucamonga", ""));
        U.log("dType: "+dType);
		//---------Status-------------------------
        
        

//        .replace("QUICK MOVE-INS NOW SELLING", " NOW SELLING")
        String remove = "PRESALE OPENING EARLY 2021|available please contact|fusion-megamenu-bullet\"></span>Now Selling</sp|Models Open - Now Selling!</div>|</span>Coming|information on our final home|Pricing coming|Rate Now|REDUCTIONS ON MOVE-|message\">MOVE-IN READY|promo\":\"MOVE-IN READY";
        comHtml= comHtml.replace("FINAL HOMES & FURNISHED MODELS NOW SELLING!", "FINAL HOMES NOW SELLING").replace("QUICK MOVE-INS NOW SELLING", " NOW SELLING").replace("QUICK MOVE-IN HOME NOW AVAILABLE", "Quick Move-In")
        		.replace("FINAL TWO HOMES NOW SELLING!", "Final Two Homes Now Selling");
        comData = comData.replace("QUICK MOVE-INS NOW SELLING", " NOW SELLING").replace("QUICK MOVE-IN HOME NOW AVAILABLE", "Quick Move-In").replaceAll("temporarily closed and only one home remains|property_type\":\"SOLD OUT", "");
        
        
        
        String propStatus = U.getPropStatus((comHtml.replace("FINAL HOMES & FURNISHED MODEL NOW SELLING", "FINAL HOMES NOW SELLING") + comData).replaceAll(remove, ""));
//       U.log("mmmmmm"+Util.matchAll(comHtml + comData , "[\\w\\s\\W]{30}NOW SELLING![\\w\\s\\W]{30}", 0));
        U.log("propStatus: "+propStatus);
        
        for(String nowSellingSec : nowSellingSection){
   //     	U.log("nowSellingSec==>"+nowSellingSec);
        	
        	if(!propStatus.contains("Now Selling") && nowSellingSec.contains(cUrl)){
        		if(propStatus == ALLOW_BLANK) propStatus = "Now Selling";
        		if(propStatus != ALLOW_BLANK) propStatus += ", Now Selling";
        		break;
        	}
        }
        
        //--------notes-----------
//        U.log(comData);
        String notes = U.getnote((comHtml + comData)
        		.replace("presales for The Lumberyard to begin early 2023", "presales begin early 2023")
        		.replace("presales in early 2023", "presales early 2023")
        		.replace("presales for The Lumberyard to begin in Fall, 2022", "presales begin in Fall 2022").replace("presales at Axis in early 2022", ""));
        U.log("notes: "+notes);
		
		//-----------------Address && latlng---------------------------
        String[] latLng = {ALLOW_BLANK,ALLOW_BLANK};
        String[] add = {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
        String geo= "FALSE";
   
        latLng[0] = U.getSectionValue(comData, "\"lat\":\"", "\"");
        latLng[1] = U.getSectionValue(comData, "\"lng\":\"", "\"");
        U.log("Latlng : " + Arrays.toString(latLng));
        
        
        String addSec = U.getSectionValue(comData, "sales_address\":\"", "\"");
        U.log("addSec : "+addSec);
    
        if(addSec != null){
        	addSec = addSec.replace("<br />", ",")
        			.replace("5374 W. South Jordan Parkway<br \\/>\\r\\nSouth Jordan", "5374 W. South Jordan Parkway, South Jordan")
        			.replaceAll("\\| Near 6th Street (and|&) Milliken Avenue", "").trim();
        	add = U.getAddress(addSec);
        }
        U.log("add : " + Arrays.toString(add));
        
        if((add[0].length()<4 || add[3].length()<4 )&& latLng[0]!=null){
        	add = U.getAddressGoogleApi(latLng);
        	if(add == null) add = U.getAddressHereApi(latLng);
        	geo = "TRUE";
        }
        
        if(latLng[0]==null && add[0].length()>4){
        	latLng = U.getlatlongGoogleApi(add);
        	if(latLng == null) latLng = U.getlatlongHereApi(add);
        	geo = "TRUE";
        }
        //if(cUrl.contains("https://www.vandaele.com/northern_california/community/latitude-at-river-islands/"))propStatus += ", Now Selling";
//        if(cUrl.contains("https://www.vandaele.com/northern_california/community/summer-house-at-river-islands/")
//        		|| cUrl.contains("https://www.vandaele.com/northern_california/community/castaway-at-river-islands/"))minPrice = ALLOW_BLANK;
//        if(cUrl.contains("https://www.vandaele.com/southern_california/community/enliven-at-the-resort"))
//        	propStatus=propStatus.replace(", Now Selling", "");
//        
//        if(cUrl.contains("https://www.vandaele.com/southern_california/community/ridgepointe-at-deerlake-ranch")) {
////        	maxPrice="$1,525,990"; //present in homefinder but no in pagesource
//        	propStatus=propStatus.replace("Coming Soon,", "");
//        	
//        }
//        if(cUrl.contains("https://www.vandaele.com/southern_california/community/alicante"))
//        	propStatus=propStatus.replace("Sold Out,", "");
        
        if(comName.contains("Resort")) {
        	if(comType.length()<1)
        		comType="Resort Style";
        	else
        		comType=comType+", Resort Style";
        }
        if(cUrl.contains("/community/the-lumberyard/")) 
        {
        	minSqFt="575";
        	maxSqFt="2,212";
        }

        comName = comName.replace("Ridgepointe at Deerlake Ranch Test", "Ridgepointe at Deerlake Ranch in Chatsworth");
		data.addCommunity(comName, cUrl, comType);
		data.addAddress(add[0].replace(",", ""), add[1], add[2].trim(), add[3]);
		data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
		data.addPropertyType(propType, dType);
		data.addPropertyStatus(propStatus);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqFt, maxSqFt);
		data.addNotes(notes);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(units);
	

	}
}