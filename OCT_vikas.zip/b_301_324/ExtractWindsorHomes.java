package com.shatam.b_301_324;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.concurrent.ConcurrentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.javascript.host.URL;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractWindsorHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	static int j = 0;
	WebDriver driver = null;
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new ExtractWindsorHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Windsor Homes.csv", a.data().printAll());
	}

	public static String homeurl = "https://www.windsorhomes.us/home";

	public ExtractWindsorHomes() throws Exception {
		super("Windsor Homes", "https://www.windsorhomes.us/");
		LOGGER = new CommunityLogger("Windsor Homes");
	}

	int a = 0;

	public void innerProcess() throws Exception {
		U.setUpChromePath();
		driver = new ChromeDriver();
		String mainUrl = homeurl.replace("/home", "/search-by-price");
//		String html = U.getHTMLwithProxy(mainUrl);
		String html = U.getHtml("https://www.windsorhomes.us/all-communities",driver);
		//U.log(U.getHTML("https://www.windsorhomes.us/all-communities"));
		//U.log(U.getPageSource("https://www.windsorhomes.us/all-communities"));

		/*String htmlSec = U.getSectionValue(html, "<div id=\"block_element\">",
				"<div id=\"footer\">");*/
		String htmlSec = U.getSectionValue(html,"<div id=\"cards_container_2020-05-28-253\"","<div class=\"dmFooterContainer\"> ");
		//htmlSec = "<div id=\"block_element\">" + htmlSec;
		String[] comSection = U.getValues(htmlSec, "<div id=\"card_comm_","Request Information</span></button>");
		
		U.log(comSection.length);
		for (String comSec : comSection) {
			a++;
		//	U.log(a);
//			 U.log("######"+loc1+"******");
			String commName = U.getSectionValue(comSec, "<span class=\"card_title \" card_spec\"=\"\">", "<");
			commName = commName.trim();
			 U.log(commName);

			String PriceSec = ALLOW_BLANK;
			String Area = ALLOW_BLANK;
			
			PriceSec = U.getSectionValue(comSec, "<div id=\"right_div\">","<br>");
			if(PriceSec!=null){
				Matcher formatPrice = Pattern.compile("\\$\\d{3}\\'s",Pattern.CASE_INSENSITIVE).matcher(PriceSec);
				while(formatPrice.find()){
				//U.log(mat.group());
				String matchPrice = formatPrice.group().replace("'s", ",000");  //$1.3 M
				PriceSec	 = PriceSec.replace(formatPrice.group(), matchPrice);
				}//end millionPrice
			
			}
				
			String[] area = U.getSqareFeet(comSec,"\\d([,\\s])?\\d{3,} to \\d{3,}\\s{1,}sq|\\d{4} to \\d{4}sq'", 0);
			Area = area[0] + " sq ft., " + area[1] + " sq ft.,";
			// U.log(area[0]+"	"+area[1]);
			
			String commUrl = U.getSectionValue(comSec, "<a href=\"", "\"");
			commUrl = homeurl.replace("/home", commUrl);
			// U.log("loc1::"+loc1);

			String Type = U.getPropType(comSec);
			// if (!commUrl.contains("https://www.windsorhomes.us/parkplace"))
//			commDetails(commName, commUrl, Type, PriceSec, Area, comSec);
			comDetails(commName, commUrl, Type, PriceSec, Area, comSec);

		}
		driver.quit();
		LOGGER.DisposeLogger();

	}

/*	public static String match(String txt, String findPattern) {

		Matcher m = Pattern.compile(findPattern, Pattern.CASE_INSENSITIVE)
				.matcher(txt);
		while (m.find()) {
			String val = txt.substring(m.start(), m.end());
			val = val.trim();

			val = val.replaceAll("\\s+", " ");
			return val;
		}
		return null;
	}*/

	//TODO ::
	//Updated
	public void comDetails(String commName, String commUrl, String Type,String PriceSec, String Area, String comSec) throws Exception {
//		if( j>=20)
		{
			
//		if(!commUrl.contains("https://www.windsorhomes.us/Detail/Community/Grayson-Park-147080"))return;
			U.log("Count :="+j);
			U.log("=="+commUrl);
			if (data.communityUrlExists(commUrl)){
				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
				return;
			}
			LOGGER.AddCommunityUrl(commUrl);

			String html = U.getHtml(commUrl, driver);
			html=U.removeSectionValue(html,"let priceRangeMapping", " }");
			
			String scripts[] = U.getValues(html,"<script","</script>");
			for(String val: scripts) {
				html=html.replace(val, "");
			}
			String descSection = U.getSectionValue(html, "Contact Information</h3>", "<div id=\"section-navigation");
			if(descSection != null) descSection = descSection.replace(" 400&#039;s's - 499&#039;s's", " $400,000 - $499,000")
					.replace("upper 200's - mid 300's", "upper $200,000 - mid $300,000").replace("0&#039;s", "0,000");
	
			
			//addsec
			String zip=ALLOW_BLANK;
			String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
			 String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
			 String flag="FALSE";
//			 String addSec=U.getSectionValue(comSec,"<div class=\"card_address card_text\">", "</span>").replaceAll("<span>","");
//			 U.log("Addr:::"+addSec);
//			 String splitAdd[]=addSec.split(",");
//			 U.log("city n state"+Arrays.toString(splitAdd));
//			 add[1]=splitAdd[0].trim();
////			 String splitadd2[]=splitAdd[1].split("\\s");
////			 add[1]=splitadd2[0];
////			 add[3]=splitadd2[1];
//			 U.log("City::::"+add[1]);
//		//	 add=U.getAddress(addSec);
//			 U.log("City::::"+(add[1]));
//			 Pattern pattern = Pattern.compile("\\d+");
//			 Matcher matcher = pattern.matcher(splitAdd[1]);
//			 while(matcher.find())
//			 {
//				 zip=matcher.group();
//				 add[3]=zip;
//				 U.log("Zip::::"+(add[3]));
//			 }
//			 String state=splitAdd[1].replaceAll("\\d+", "");
//			 add[2]=state;
//			U.log("State::::"+add[2]);
			
			
//			========================latlng============================
			String addressData=U.getPageSource("https://www.windsorhomes.us/_dm/s/rt/actions/sites/f39f0edb/collections/All%20Comms/ENGLISH");
			String []commAddSeU=U.getValues(addressData, "{\\\"uuid\\\"", "page_item_url");
			for(String addData : commAddSeU) {
				
				addData=addData.replace("\\\"", "\"");
				if(addData.contains(commUrl)) {
				U.log("addData====="+addData);
				add[0]=U.getSectionValue(addData, "\"Addr\":\"", "\",");
				add[1]=U.getSectionValue(addData, "\"City\":\"", "\",");
				add[2]=U.getSectionValue(addData, "\"State\":\"", "\",");
				add[3]=U.getSectionValue(addData, "\"Zip\":\"", "\",");
//				break;
				 U.log("Addresss:After"+Arrays.toString(add));
				}
			}
			

			String latlngSec=U.getSectionValue(html, "href=\"https://maps.google.com/maps?ll=", "&amp");
			if(latlngSec!=null) {
				U.log("latlngSec::::"+latlngSec);
				latlng=latlngSec.split(",");
			}
			if(add[0]!=ALLOW_BLANK && add[0]!=null) {
				add[0]=add[0].replaceAll("Call Builder Representative Most Similar. Optional Features Shown|Call For Appointment|Call for Appointment|Call Builder Representative|Call For Appointment Most Similar. Optional Features Shown|By Appointment Only|Call Builder Representative Most Similar. Optional Features Shown", "");
			}
			if((add[0]==null ||add[0].length()<2 ) &&add[1]!=ALLOW_BLANK && add[2]!=ALLOW_BLANK && add[3]!=ALLOW_BLANK && latlng[0]!=ALLOW_BLANK) {
				add[0]=U.getAddressGoogleApi(latlng)[0];
				flag="TRUE";
			}
			
			if(add[1]!=ALLOW_BLANK && add[2]!=ALLOW_BLANK && add[3]!=ALLOW_BLANK && latlng[0]==ALLOW_BLANK) {
				 latlng=U.getlatlongGoogleApi(add);
				 flag="TRUE";
				 U.log("Lat long:::::"+latlng);
				 add=U.getAddressGoogleApi(latlng);
				 U.log("Addresss:"+Arrays.toString(add));
			 }
			
			 
			 
//			// Huffman Mill Rd, Burlington, NC 27215, USA
//			 if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Aberdeen-151844")||commUrl.contains("https://www.windsorhomes.us/Detail/Community/Birkdale-151874")||commUrl.contains("https://www.windsorhomes.us/Detail/Community/Kernodle-Landing-147220")) {
//				 add[0]="Huffman Mill Rd";
//				 add[1]="Burlington";
//				 add[2]="NC";
//				 add[3]="27215";
//				 latlng[0]="36.0807686";
//				 latlng[1]="-79.4827759";
//				 flag="TRUE";
//						 
//			 }
//			 if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Park-Place-at-Springwood-147225")) {
//			//	 6915 US-70, Whitsett, NC 27377, USA 
//				 add[0]="6915 US-70";
//				 add[1]="Whitsett";
//				 add[2]="NC";
//				 add[3]="27377";
//				 latlng[0]="36.0764118";
//				 latlng[1]="-79.5698547";
//				 flag="TRUE";
//			 }
			if(add[0]!=null) {
				add[0]=add[0].replace("Stokesdale, NC", "");
			}
			
			if(add[0].length()>2) {
				add[0]=add[0].replace("Most Similar. Optional Features Shown", "");
			}
			if(add[0].length()<2 && add[2]!=null) {
				add[0]=U.getAddressGoogleApi(latlng)[0];
						flag="TRUE";	
			}
			 U.log("LATLNG===="+Arrays.toString(latlng));
			 U.log("Addresss:After"+Arrays.toString(add));
			 
			 String planHtml=null;
			 String quickHtml=null;
			
			  String statSec=U.getSectionValue(html, "class=\"suffix-api-text\"></span>", "dmCustomWidget");
		      String plnSec=U.getSectionValue(html, "Plans Available</b>", "<div class=\"dmRespRow");
	/*	
 
			// U.log(html);
			 String quickHomeSec[] = {};
			 quickHomeSec = U.getValues(html, "<div class=\"card_row card-row-3 \" id=\"card_row_spec_", "View Details</span></button></a></div>");
			 if(html.contains("Homes Ready to Contract") && html.contains(">View Details")) {
//				 U.log(U.getSectionValue(html, "class=\"card_header\">", ">View Details"));
//				  quickHomeSec= U.getValues(html, "class=\"card_header\">", ">View Details");
				 if(quickHomeSec!=null) {
				 for(String quick:quickHomeSec) {
				 String quickUrl=U.getSectionValue(quick,"<a class=\"card_anchor\" href=\"", "\"");
				// U.log("Quickurl::::"+quickUrl);
				 if(quickUrl.contains("tel:`+validateText(a[f.field])+`"))continue;
				 quickHtml+=U.getHtml("https://www.windsorhomes.us"+quickUrl, driver);
				 }
				 }
				
			 }
			 //U.log("Plan Section:::::"+plnSec);
			
			 String planUrlSec[]=U.getValues(html, "<div><a class=\"card_anchor\" href=\"/", "\"");
			
			 for(String planU:planUrlSec) {
			//	U.log("PlanSEc::::"+planU);
				U.log("Plan uRL:::"+("https://www.windsorhomes.us"+planU));
				String htm = U.getHtml("https://www.windsorhomes.us/"+planU, driver);
				String rmec = U.getSectionValue(htm, ">Communities To Build In</span></h3> ", "</html");
				if(rmec!=null)htm=htm.replace(rmec, "");
				planHtml+=htm;
				
			 }
			// U.log("CommSec::::"+comSec);
			 
		*/	 int quickCount=0;
			 String myQuickHtml=U.getHtml("https://www.windsorhomes.us/move-in-homes",driver);
			 U.log(U.getCache(homeurl+"/move-in-homes"));
			 String qHtml=ALLOW_BLANK;
			 String qDataSec="";
			 String quickData=ALLOW_BLANK;
			 String[] quickSec=U.getValues(myQuickHtml, "<div class=\"card_row card-row-3 \" id=\"card_row_spec_", "Request More Information");
			 for(String quickHomes:quickSec) {
				 String comNameHome=U.getSectionValue(quickHomes,"card_spec\"=\"\">", "</span>");
				 if(comNameHome.contains(commName)) {
					String quickUrl=U.getSectionValue(quickHomes, "href=\"", "\">");
					U.log("quickUrl:: "+quickUrl);
//					U.log("quickHomes==="+quickHomes);
					qHtml=U.getHtml("https://www.windsorhomes.us"+quickUrl, driver);
					 U.log("ZZZZ"+Util.matchAll((qDataSec),"[\\w\\W\\s]{40}qHtml[\\w\\W\\s]{40}", 0));
					qDataSec+=U.getHtmlSection(qHtml, "<span id=\"prefix\"", "Sales Office");
					qHtml=U.removeSectionValue(qHtml,"let priceRangeMapping", " }");
					
					quickData+=quickHomes;
					if(!quickHomes.contains("UnderContract.png") && !quickHomes.contains("SoldBanner.png"))
					{
						quickCount++;
//						U.log("quickHomes:: "+quickHomes);
					}
					
				 }		
					
			 }
			 U.log("quickCount:: "+quickCount);
			 
			 
			 String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			//
			 html=html.replace("0's", "0,000");
			 String[] price = U.getPrices(html+planHtml+PriceSec+quickHtml+qHtml+quickData,"$200,000|from the \\$\\d{3},\\d{3}|Starting At \\$\\d{3},\\d{3}|Starting at \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}",0);
			 minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			    U.log("MinPrice =="+minPrice+"\t MaxPrice=="+maxPrice);
			 
//				 U.log(Util.matchAll(quickData, "[\\w\\s\\W]{30}\\$100,000[\\w\\s\\W]{30}", 0));

			    
			    
			 html=html.replaceAll
					 ("<span id=\"suffix-text-1-1005\" class=\"suffix-api-text\">\\s*Sq. Ft.\\s*</span>", "Sq. Ft.");
			 String[] sqft = U.getSqareFeet((html+planHtml+qHtml).replace("the 7300 sq. ft. RESIDENT’S CLUB", ""),"\\d{1},\\d{3} square feet|\\d{4} Sq. Ft.|\\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3} square feet|\\d{4}-\\d{4} square feet|approximately \\d{4} to \\d,\\d{3} square feet|approximately \\d{4} to \\d{4} square feet|approximately \\d{4}-\\{4} square feet|\\d,\\d{3} - \\d,\\d{3} Sq. Ft|\\d{4} - \\d{4}</span>\\s*Sq. Ft.|class=\"api-text text-center\">\\d{4} -\\d{4}</span>|\\d,\\d{3} Sq. Ft.|approximately \\d{4} square feet",0);
			// U.log(Util.matchAll(html, "[\\w\\s\\W]{30}2,612[\\w\\s\\W]{30}", 0));
			 String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			 minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);
				
				
				String comType = U.getCommunityType(html.replaceAll("data.config.[\\w\\s\\W]\\s*", ""));
				System.out.println("Community Type==="+comType);
				String quickHtmldata = U.getPageSource("https://www.windsorhomes.us/move-in-homes");
						
				html=html.replaceAll("quick|Quick", "");
			//	U.log("ooo"+Util.matchAll((html),"[\\w\\W\\s]{40}Close[\\w\\W\\s]{40}", 0));
				html=html.replace("closeout.png", "")
						.replace("100% financing eligible with USDA", "USDA 100% Financing");
						
				comSec=comSec.replace("closeout.png", "");
		//		U.log("KKK"+Util.matchAll(html+comSec+statSec, "[\\w\\W\\s]{50}PH II, PH III[\\w\\W\\s]{50}", 0));
				String propStatus = U.getPropStatus((html+comSec+statSec).replace("Only 1 home left in Phase I &amp; II", "Only 1 home left in Phase I & II").replaceAll("3 unfinished basement homesites coming soon|comingSoonImage|X - Close Out|Coming Soon Grand Opening|C -Coming Soon|closeoutImage|IsCloseOut", ""));
			
				//	U.log("ooo"+Util.matchAll((html),"[\\w\\W\\s]{40}Closeout[\\w\\W\\s]{40}", 0));
				//	U.log("ooo"+Util.matchAll((comSec),"[\\w\\W\\s]{40}Closeout[\\w\\W\\s]{40}", 0));

				
		//	if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/The-Terraces-157192"))propStatus="Coming Soon";
			
					
			
//			String quickHome = U.getSectionValue(html, "<div class=\"card_row card-row-3 \" id=\"card_row_spec_", "View Details</span></button></a></div>");
			if(quickCount>0) {
				if(propStatus.length()<4) {
					propStatus="Quick Move-in Homes";
				}
				else {
					propStatus+=", Quick Move-in Homes";
				}
			}
			    
				if(commUrl.contains("Park-Ridge-155066"))propStatus="Coming Soon";
				if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Park-Place-at-Springwood-147225"))minSqf="1549";
			//	if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Hillsdale-Farm-West-147219"))maxSqf="3571";
				
				if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Villas-at-Oxford-Ridge-147224"))propStatus="Quick Move-in Homes"; 
				System.out.println("Property status:"+propStatus);
//				if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Williard-Place-152360")) {
//				minPrice="$300,000";
//					
//			}
		//	U.log("ZZZZ"+Util.matchAll(html+planHtml+quickHtml,"[\\w\\W\\s]{40}ranch[\\w\\W\\s]{40}", 0));
				//planHtml=planHtml.replace("Luxury Master Bath","");
				String propType = U.getPropType((qDataSec+html+planHtml+quickHtml).replace("Flex space/Loft", "loft or").replaceAll("IsCondo|CondoOrTownhome|apiText = \"Single Family\";|config.SingleFamily|Coastal Communities|Multi Family", ""));
				propType=propType.replace(", Luxury Homes", "");
				
				
				System.out.println("Property type:"+propType);
//				propStatus=propStatus.replace("Nearly Sold Out, Quick Move-in Homes", "Nearly Sold Out").replace("Coming Soon, Quick Move-in Homes", "Quick Move-In Homes").replace("Closeout, Quick Move-in Homes", "Closeout");
				String dType = U.getdCommType((html+planHtml+quickHtml).replaceAll("code-branch:|1st Floor Primary Plan|1st floor Laundry Closet|First floor Master|First floor Primary Bedroom",""));
				System.out.println("Derived type:"+dType);
				
				if(commUrl.contains("https://www.windsorhomes.us/Detail/Community/Owls-Trail-At-Calebs-Creek-147223"))propStatus=propStatus.replace("Coming Soon, Only Two Homes Left", "Only two homes left in PH II, PH III Coming Soon");
				if(commUrl.contains("Community/Summerwoods-147083"))dType="2 Story, 1 Story";
				
				//adding proptype
				String coastalType = U.getHtml("https://www.windsorhomes.us/coastal-communities",driver);
				U.log(coastalType.contains(commName+"</span>"));
				if(coastalType.contains(commName+"</span>") && !propType.contains("Coastal")) {
					if(propType.length()>3)propType=propType+", Coastal Style Homes";
					else propType="Coastal Style Homes";
				}
				
				
//				==========================================================
				
				String lotCount=ALLOW_BLANK;
				String mapUrlSec=U.getSectionValue(html, "Take a Virtual Walk-through", "target=\"_blank\"");
				if(mapUrlSec!=null) {

				String mapUrl=U.getSectionValue(mapUrlSec, "href=\"", "\"");
				if(mapUrl!=null) {
					String mapHtml=U.getHTML(mapUrl);
					if(mapHtml!=null) {
						
						String lotSection=U.getSectionValue(mapHtml, "<g id=\"Lot_Numbers\"", "</g>");
						if(lotSection!=null) {
							String[] lot_data=U.getValues(lotSection, "<text class=\"cls", "</text>");
							if(lot_data.length>0) {
								lotCount=Integer.toString(lot_data.length);
							}
						}
					}
				}
				
				}
				
				U.log("lotCount==="+lotCount);
				
				
				
			data.addCommunity(commName, commUrl, comType);
			data.addPrice(minPrice, maxPrice);
			data.addSquareFeet(minSqf,maxSqf);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus.replace("ii", "II"));
			data.addNotes(U.getnote(html+comSec));
			data.addAddress(add[0].replace("Model Coming Soon: ", ""), add[1], add[2].trim(), add[3]);
			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
            data.addUnitCount(lotCount);
		}
		j++;
	}

	//old
//	public void commDetails(String commName, String commUrl, String Type,String PriceSec, String Area, String comSec) throws Exception {
////		if(j >= 40)
//		{
//			
//		//	if(!commUrl.contains("Community/Birkdale-151874"))return;
//			
//			U.log("Count :="+j);
//			U.log("=="+commUrl);
//			//if(!commUrl.contains("https://www.windsorhomes.us/reaganpoint"))return;//No Data
////			if(commUrl.contains("http://www.windsorhomes.us/mackintoshonthelakebirkdale"))return;
//			//if(commUrl.contains("https://www.windsorhomes.us/scottsdale"))return;
//			//String html = U.getHTMLwithProxy(commUrl);
//			if (data.communityUrlExists(commUrl)){
//				LOGGER.AddCommunityUrl(commUrl+ "---------------------------------repeat");
//				return;
//			}
//			LOGGER.AddCommunityUrl(commUrl);
//
//			String html = U.getHTML(commUrl);
//			
//
//			String descSection = U.getSectionValue(html, "Contact Information</h3>", "<div id=\"section-navigation");
//			if(descSection != null) descSection = descSection.replace(" 400&#039;s's - 499&#039;s's", " $400,000 - $499,000")
//					.replace("upper 200's - mid 300's", "upper $200,000 - mid $300,000").replace("0&#039;s", "0,000");
//	
//			
//			String Infourl = "";
//			String Dirurl = "";
//			String Floplan = "";
//			String HRN = "";
//
//			String linkSec = U.getSectionValue(html,"<div id=\"section-navigation\">", "</ul>");
//			String[] links = U.getValues(linkSec, "<a href=\"", "\"");
//			for (String loc2 : links) {
////				U.log("--"+loc2);
//				if (loc2.contains("community-information"))
//					Infourl = loc2;
//				if (loc2.contains("direction"))
//					Dirurl = loc2;
//				if (loc2.contains("floorplan"))
//					Floplan = loc2;
//				if (loc2.contains("hrn"))
//					HRN = loc2;
//				
//			}
//
//			Infourl = homeurl.replace("/home", Infourl);
//			Dirurl = homeurl.replace("/home", Dirurl);
//			Floplan = homeurl.replace("/home", Floplan);
//			
//			U.log("info url "+Infourl);
//			//U.log(Floplan+"###########tanu");
//			HRN = homeurl.replace("/home", HRN);
//			Floplan = U.getHTML(Floplan);
//			String[] floor = U.getValues(Floplan, "<h2 style='margin", "See Details");
//			String floorHtml = "";
//			for(String floors : floor){
//				String floorUrl ="http://www.windsorhomes.us" + U.getSectionValue(floors, "href='", "'>");
//				floorHtml = U.getHtml(floorUrl,driver);
//			}
//			//============== Homes Ready Now Section ===========
//			U.log("home ready url:="+HRN);
//			HRN = U.getHTML(HRN);
////			String[] remove = U.getValues(HRN, "S O L D", "sq. feet");
////			for (String bbb : remove) {
////				HRN = HRN.replaceAll(bbb, "");
////			}
//			String allReadyHomesData = ALLOW_BLANK;
//			String readyHomeSec = U.getSectionValue(HRN, "<h2>Homes Ready Now</h2>", "<div id=\"section-navigation");
//			//U.log(readyHomeSec);
//			int soldreadyHomeCount = 0;
//			int readyHomeCount = 0;
//			if(readyHomeSec != null){
//				ArrayList<String> readyHomeUrls = Util.matchAll(readyHomeSec, "Garage<br>\\s*<a href=\"(.*?)\\s*\"",1);
//				readyHomeCount = readyHomeUrls.size();
//				U.log(readyHomeCount);
//				for(String readyHomeUrl : readyHomeUrls){
//					U.log("readyHomeUrl : http://www.windsorhomes.us"+readyHomeUrl);
//				String readyHomeHtml = U.getPageSource("http://www.windsorhomes.us"+readyHomeUrl);
//				if(readyHomeHtml.contains("S O L D"))soldreadyHomeCount++;
//				allReadyHomesData += U.getSectionValue(readyHomeHtml, "div id=\"box_topper\">", "Contact Us &");
//				
//				}
//				
//			}
//			//U.log(allReadyHomesData+"@@@@@@@");
//			String infoHtml = U.getHTML(Infourl);
//			infoHtml=infoHtml.replace("0's", "0,000");
//			
//		
//			String[] Prices = U.getPrices(descSection + infoHtml+PriceSec + Floplan + HRN,
//					"\\$\\d{3},\\d{3} to \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|\\$\\d{6}'s", 0);
//			Prices[0] = (Prices[0]==null) ? ALLOW_BLANK : Prices[0];
//			Prices[1] = (Prices[1]==null) ? ALLOW_BLANK : Prices[1];
//			U.log(Area);
//			
//			String[] area = U
//					.getSqareFeet(
//							comSec+Area + Floplan + HRN + infoHtml,
//							"\\d{4}-\\d{4} square feet|Square Feet:</strong> \\d{4}|\\d{4} sq. feet|<br>\\d+ sq|approximately \\d{4} to \\d,\\d{3} square feet|\\d,\\d{3} to \\d{4} square feet|\\d{4} to \\d{4}\\+ sq'|\\d{4} to over \\d{4} square feet.|\\d{4}-\\d{4} square feet|\\d{4} sq ft.|\\d{4} sq. feet|\\d{4} to \\d{4} \\+ square feet|\\d{1},\\d{3} sq ft to over \\d{1},\\d{3} sq ft",
//							0);
//			area[0] = (area[0]==null) ? ALLOW_BLANK : area[0];
//			area[1] = (area[1]==null) ? ALLOW_BLANK : area[1];
//
//			U.log("SQFT: "+Arrays.toString(area));
//			
//			infoHtml=infoHtml.replace("Resort-Style Amenities,", "");
//			String commType = U.getCommunityType(html.replace("golf and more","").replace("Golfing, volleyball,", "") + infoHtml);
//			html = html.replaceAll("Community Hours</h3><p> Coming Soon|central square coming soon|nearby community coming", "")
//					.replaceAll("\">Homes|<li>Many homes", "").replace("100% financing eligible with USDA", "USDA 100% Financing");
//			infoHtml = infoHtml.replaceAll("Coming Soon|\">Homes", "");
//			infoHtml = infoHtml.replace("(coming soon)", "");
//			infoHtml = infoHtml.replace("square coming soon", "").replace("No Homeowners association", "");
////			U.log(comSec);
//			String Status = U.getPropStatus(comSec+ html + infoHtml);
//			String notes = U.getnote(html + infoHtml);
//			
//			//U.log(infoHtml);
//			//================ Derived Community Type ================
//			String flrsec=U.getSectionValue(Floplan, "<div id=\"box_topper\">", "<div id=\"left_column\">");
//			String flrval[]=U.getValues(flrsec, "<a href='", "'>");
//			String dType="";
//			String valhtml="";
//			for(String value:flrval)
//			{
//				value="http://www.windsorhomes.us"+value;
//				U.log("value : "+value);
//				 valhtml= valhtml+U.getHtml(value,driver);	
//				
//			}
////			U.log(valhtml);
//			infoHtml=infoHtml.replaceAll("One, two, three and four story"," 1 story, 2 story, 3 story, 4 story");		
//			valhtml=valhtml.replaceAll("2nd Floor", "2-story");
//			valhtml = valhtml.replaceAll("3rd Floor|1st Floor", "");
//			U.log(valhtml.contains("two story"));
//			 dType = U.getdCommType((html + infoHtml+valhtml+allReadyHomesData).replaceAll("Floor|floor", "").replaceAll("One to three story","1 Story ,2 Story, 3 Story").replaceAll("3rd Floor Options|floor|", ""));
//			 
//			
//	//-----------------------------------------------------------address code by Upendra------------------------------------------------------
//			 String add[]={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
//			 String latlng[]={ALLOW_BLANK,ALLOW_BLANK};
//			 String flag="FALSE";
//			 U.log("dirUrl-->"+Dirurl);
//			 String dirHtml=U.getHTML(Dirurl);
//			 String addSec=U.getSectionValue(dirHtml,"https://www.google.com/maps/embed","\"");
//			 U.log("addSec:::::"+addSec);
//			 if(addSec!=null)
//			 {
//			 String aSec=U.getSectionValue(addSec, "!2s","!5e");
//			 U.log("aSec:::::"+aSec);
//			
//				 if(aSec!=null)
//				 {
//					U.log("MMMMMMM "+aSec);
//					 aSec=aSec.replace("%20%26%20"," ").replace("%20", " ").replace("%2C", ",").replace("+", " ").replace("%26", "");//.replaceAll("\\%\\d{2}", "").replace("+"," ").replace("%20%26%20", " ")
//					 aSec = aSec.replace("Brevard Rd  Payne Rd", "Brevard Rd & Payne Rd");
//					 U.log("SSSSSSSSSSS "+aSec);
//					 String[] add1=aSec.split(",");
//						 if(add1.length>2)
//						 {
//							 add[0]=add1[0];
//							 add[1]=add1[1];
//							 add[3]=Util.match(add1[2],"\\d{5}");
//							 add[2]=Util.match(add1[2],"[A-Z]{2}");
//							
//						 }
//						 if(add1.length<2)
//						 {
//							 //Address from ModelHome
//							 //dirHtml=dirHtml.replace("<h4>Open House</h4>", "<h4>Model Home</h4>");
//							 String secA=U.getSectionValue(dirHtml, "<h4>Model Home</h4>","<br><h4>");
//							 
//							 if(secA == null)
//								 secA = U.getSectionValue(dirHtml, "Community Location<br>", "<h4>");
//							 secA=secA.replace("<br><br>","").replace("%20", ",");
//							 secA=secA.replace("<br>",",");
//							 add1=secA.split(",");
//							 add[0]=add1[0];
//							 add[1]=add1[1];
//							 add[3]=Util.match(add1[2],"\\d{5}");
//							 if(add[3]!=null)
//							 {
//							 add[2]=add1[2].replace(add[3],"").trim();
//							 }
//						 }
//						 
//				
//				
//				 	}
//				 	else{
//				 		
//				 	
//					 //------address from iframe--------------
//					 String iFrameSec = U.getSectionValue(dirHtml, "<iframe src=\"", "\"");
//					 if(iFrameSec!=null){
//						 addSec = U.getSectionValue(iFrameSec, "!2s", "!");
//						 U.log("iFrameSec ::::::::::::"+iFrameSec);
//						 if(addSec!=null){
//							 addSec = addSec.replace("%2C+", ", ").replaceAll("%2C%20|%20", ",").replace("+", " ");
//							 if(addSec.contains(",NC ")){
//								 add = U.findAddress(addSec);
//							 }
//							 
//						 }
//					 }
//				 	}
//			 }
//			 
//			 if((dirHtml.contains("</h4>Community Location<br>")||dirHtml.contains("<h4>Model Home</h4") ||dirHtml.contains("<h4>Open House</h4")) && add[0].length()<4){
//				 addSec = U.getSectionValue(dirHtml, "</h4>Community Location<br>", "<br><br><h4>");
//				 if(!dirHtml.contains("</h4>Community Location<br>") || (commUrl.contains("stjamesridge")|| commUrl.contains("compasspointe")) ){
//					 addSec=U.getSectionValue(dirHtml, "<h4>Model Home</h4>", "<br><br><h4>");
//					 System.out.println("addSec"+addSec);
//					 if(addSec!=null) {
//					 addSec=addSec.replaceAll("<br>", ",").replaceAll("(just off Rambling Rd)", "");
//					 
//					 U.log("addsec-- ::"+addSec);
//					 String[]  add1=addSec.split(",");
//					 add[0]=add1[0];
//					 add[1]=add1[1];
//					 }
////					U.log(dirHtml.contains("Open House</h4>")+add[0]);
//
//				 }
//				 if(dirHtml.contains("Open House</h4>") && add[0]==ALLOW_BLANK){
//					 U.log("hello");
//					 addSec=U.getSectionValue(dirHtml, "<h4>Open House</h4>", "<br><br><h4>");
//					 System.out.println(addSec);
//					 String[]  add1=addSec.split(",");
//					 add[0]=add1[0];
//					 add[1]=add1[1];
//				 }
//				
//				 U.log("addsec ::"+addSec);
//			
//				 if(addSec != null) {
//					 addSec = addSec.replace("Kernersville NC <br>", "").replaceAll("Bonner Bridge Rd\\nBurlington, NC 27215<br>Burlington, NC 27215", "Bonner Bridge Rd, Burlington, NC 27215")
//							 .replace("<br>", ",").replaceAll("just off Rambling Rd|\\(|\\)", "");
//					 String[]  add1=addSec.split(",");
//					 U.log("addsec ::"+addSec);
//					 add[0]=add1[0];
//					 add[1]=add1[1];
//					 add[3]=Util.match(add1[2],"\\d{4,}");
//					 if(add[3]!=null)
//					 {
//						 add[2]=add1[2].replace(add[3],"").trim();
//					 }else add[2]= add1[2];
//				 }
//			 }
//			 else if(addSec== null || add[0].length()<4 || add[0] == null){
//				 addSec = U.getSectionValue(dirHtml, "<h4></h4>", "<br><br><h4>");
//				 if(addSec != null){
//					 addSec = addSec.replace("<br>", ",");
//					 add = U.getAddress(addSec);
//				 }
//			 }
//			 add[0] = add[0].replaceAll(", Holly Ridge, NC 28445", "").replace("Willard Road between Hickswood Rd and Maxine Dr", "2603 Willard Road"); //gps address
//			 
//			 
//			 U.log("Address---->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
//			
//			 
//			 //-------------latlng--------------
//			 String latSec=U.getSectionValue(dirHtml, "<h4>GPS Address","<br>");
//			 if(latSec!=null)
//			 {
//				 latlng[0]=Util.match(latSec, "\\d{2,3}[.]\\d{4,}");
//				 latlng[1]=Util.match(latSec, "-\\d{2,3}[.]\\d{4,}");
//				 U.log(""+latlng[0]+"::::::::::::"+latlng[1]);
//			 }
//			if(latlng[0]==null && latlng[1]==null){
//				 latSec = U.getSectionValue(dirHtml, "www.google.com/maps/", "\"");
//				 U.log("latSec:::::::"+latSec);
//				 String latLngVal = U.getSectionValue(latSec, "!2d", "!3m");
//				 U.log("==="+latLngVal);
//				 if(latLngVal != null){
//					 latLngVal = latLngVal.replace("!2m3!1f0!2f0!3f0", "");
//					 String [] latLng1 = latLngVal.split("!3d");
//					 latlng[0] = latLng1[1];
//					 latlng[1] = latLng1[0];
//				 }
//			 }
//			
//			if(latSec==null){
//				//------address from iframe--------------
//				latSec = U.getSectionValue(dirHtml, "<iframe src=\"", "\"");
//				U.log(latSec);
//				latlng[0] = U.getSectionValue(latSec, "!3d", "!");
//				latlng[1] = U.getSectionValue(latSec, "!2d", "!3d");
//				U.log("@@@@@@@@@@"+latlng[0]+"::::::::::::::"+latlng[1]);
//			}
//			
//			if(commUrl.contains("https://www.windsorhomes.us/mackintoshinverness")){
//				add[0] = add[3] = ALLOW_BLANK;
//				add[1] = "Burlington";
//				add[2] = "NC";
//				notes = "Address And Lat-Long Is Taken From City & State";
//			}
//			
//			
//			 if(add[1]!=null && (latlng[0]==ALLOW_BLANK || latlng[0]==null))
//				{
//					latlng=U.getlatlongGoogleApi(add);
//					if(latlng == null) latlng = U.getlatlongHereApi(add);
//					flag="TRUE";
//				}
//				if((add[0].length()<4 || add[0]==null || add[3]==null) && latlng[0]!=null)
//				{
//					add=U.getAddressGoogleApi(latlng);
//					if(add == null) add = U.getAddressHereApi(latlng);
//					flag="TRUE";
//				}
//				if((add[0]==ALLOW_BLANK || add[3]==ALLOW_BLANK) && latlng[0]!=null)
//				{
//					add=U.getAddressGoogleApi(latlng);
//					if(add == null) add = U.getAddressHereApi(latlng);
//					flag="TRUE";
//				}
//			 
//	//------------------------------------------------------------------------------------------------------------------------------------------		
//
//			
//		//============== Property Type ====================
//
//		html=html.replaceAll("Village|village|/*large- single column", "");
//	
//		infoHtml=html.replaceAll("Village|village|No Homeowners association", "");
//		comSec=html.replaceAll("Village|village|/*large- single column", "");
//		
//		U.log("__Type__ :"+Type);
//		
//		String newinfo=U.getHTML(Infourl);
//			String pType = U.getPropType((html + Type + infoHtml + comSec+newinfo+valhtml.replaceAll("luxury|Luxury","")).replaceAll("village|Village|VILLAGE|Covenants apply|Covenants, Conditions and Restrictions|Optional Deck / Patio",""));
//			if(newinfo.contains("Yes</span>"))
//			{
//				if(pType!=ALLOW_BLANK)
//				{
//					pType=pType+",Homeowner Association (HOA)";
//				}else {
//					pType="Homeowner Association (HOA)";
//				}
//			}
//			commName = commName.replaceAll("Patio Homes|Twin Homes", "");
//
//			//============= Image ==========================
///*			if(commUrl.contains("https://www.windsorhomes.us/shinnwoodtownes") || commUrl.contains("https://www.windsorhomes.us/oxfordridge")
//					||commUrl.contains("https://www.windsorhomes.us/magnoliaglen")
//					|| commUrl.contains("https://www.windsorhomes.us/loganridge")||commUrl.contains("palmettocreek")||commUrl.contains("https://www.windsorhomes.us/ambermeadows")
//					|| commUrl.contains("https://www.windsorhomes.us/ruffinsriver")||commUrl.contains("https://www.windsorhomes.us/macylakes")||
//					 commUrl.contains("/magnoliaonmain")||commUrl.contains("https://www.windsorhomes.us/mooresmill")||commUrl.contains("/permetabranch")||commUrl.contains("copperfieldglen") 
//					 ||commUrl.contains("summerfieldridge") ||commUrl.contains("summerhouse") ||commUrl.contains("kernodlelanding")||commUrl.contains("/ashcroftpark")|| commUrl.contains("reaganpoint") || commUrl.contains("saddlebrook") || commUrl.contains("/owlstrail")){
//				Status = "Now Selling";
//			}*/
//			
///*			if(commUrl.contains("https://www.windsorhomes.us/thearbors") || commUrl.contains("https://www.windsorhomes.us/warrenroad")
//					||commUrl.contains("https://www.windsorhomes.us/oakridgeroad")||commUrl.contains("summerwoods")
//					
//					){
//				Status = "Coming Soon";
//			}
//			*/
//			
//			if(commUrl.contains("http://www.windsorhomes.us/pilotbluff")) Status = "New Phase Coming";
///*			if(commUrl.contains("https://www.windsorhomes.us/stjamesridge")||commUrl.contains("briarmeade")||commUrl.contains("parkplace")|| commUrl.contains("forksofalamance")
//					){
//				Status = "New Phase";
//			}
//*/			U.log("soldreadyHomeCount : "+soldreadyHomeCount);
//			U.log("readyHomeCount : "+readyHomeCount);
//			//U.log(allReadyHomesData);
//			if(readyHomeCount > 0 && soldreadyHomeCount!=readyHomeCount){
//				if(Status == ALLOW_BLANK)
//					Status = "Homes Ready Now";
//				else if(Status != ALLOW_BLANK)
//					Status = Status+", Homes Ready Now";
//			}
////			if(commUrl.contains("https://www.windsorhomes.us/ledfordsouth"))Status="New Phase Coming Soon, "+Status;
////			if(commUrl.contains("magnoliaglen"))Status="Phase 1 Almost Sold Out, "+Status;
////			if(Status.contains("Limited Availability, Limited Opportunities,"))Status=Status.replaceAll("Limited Availability, Limited Opportunities,", "Limited Opportunities,");
////			if(commUrl.contains("https://www.windsorhomes.us/evansfield")) Status = Status+", Now Selling";
////			if(commUrl.contains("forksofalamance"))Status = Status+", Now Selling Phase 3";
//
//			Status = Status.replace("Final Opportunity, Two Homes Remain, Nearly Sold Out, 2 Homes Remaining", "Final Opportunity, Nearly Sold Out, 2 Homes Remaining")	;	
//			U.log("Property status:::"+Status);
//			add[0]= add[0].replace("NC-109  Ironwood Dr", "NC Hwy 109 and Ironwood Drive").replace("NC-801 Mocks Church Rd", "NC-801 & Mocks Church Rd").replace("NC-109 Ironwood Dr", "NC-109 & Ironwood Dr");
//			commName = commName.replace("&#039;", "'");
//			if(commUrl.contains("Community/Birkdale-151874"))Status+=", Quick Move-In Homes";
//			data.addCommunity(commName, commUrl, commType);
//			data.addPrice(Prices[0], Prices[1]);
//			data.addSquareFeet(area[0], area[1]);
//			data.addPropertyType(pType, dType);
//			data.addPropertyStatus(Status);
//			data.addNotes(notes);
//			data.addAddress(add[0], add[1], add[2].trim(), add[3]);
//			data.addLatitudeLongitude(latlng[0].trim(), latlng[1].trim(), flag);
//		}
//		j++;
//	}

}