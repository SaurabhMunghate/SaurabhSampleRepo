package com.shatam.b_301_324;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class HunterQuinnHomes extends AbstractScrapper
{
	
	CommunityLogger LOGGER;
	WebDriver driver =  null;
	//WebDriver driver = new FirefoxDriver();
	
	private static final String BUILDER_URL = "https://www.hunterquinnhomes.com";
	public HunterQuinnHomes() throws Exception
	{
		super("Hunter Quinn Homes", "https://www.hunterquinnhomes.com/");
		LOGGER = new CommunityLogger("Hunter Quinn Homes");
	}
	
	public static void main(String[] args) throws Exception
	{
		AbstractScrapper a = new HunterQuinnHomes();
		//U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Hunter Quinn Homes.csv", a.data().printAll());
	}
	
	public void innerProcess() throws Exception
	{
	
		U.setUpGeckoPath();
		 driver = new FirefoxDriver();
		 String mainHtml = U.getHTML("https://www.hunterquinnhomes.com/communities");
		 
		 String comSections[] = U.getValues(mainHtml, "<div class=\"CommunityCard_header\"", "<span class=\"CompareButton_text\"");
		 U.log(comSections.length);
		 for(String comSec : comSections){
			 String comUrl = BUILDER_URL + U.getSectionValue(comSec, "class=\"\" href=\"", "\"");
//			 U.log(comUrl);
			 //https://www.hunterquinnhomes.com/communities/scattered-lots/coastal-farmhouse-series
//https://www.hunterquinnhomes.com/communities/scattered-lots/low-country-series

			 if(comUrl.contains("https://www.hunterquinnhomes.com/communities/scattered-lots/coastal-farmhouse-series")) continue;
			 if(comUrl.contains("https://www.hunterquinnhomes.com/communities/scattered-lots/low-country-series")) continue;
			 
			 addCommunityDetails(comUrl, comSec);
		 }
		 
/*		 String removeHtml = U.getSectionValue(mainHtml, "<title>", "/smoothmenu");
		 mainHtml = mainHtml.replace(removeHtml, "");
		 //U.log("main html------>"+mainHtml);
		 String mainSec = U.getSectionValue(mainHtml, "leftCol", "/leftCol");
		 String comSection[] = U.getValues(mainSec, "<script", "</p>");
		 //U.log(comSection[0]);
		 
		 for(String comData : comSection)
		 {
			 String comUrl = BUILDER_URL +U.getSectionValue(comData, "href=\"", "\">");
			// U.log(comUrl);
			addCommunityDetails(comUrl, comData);
			 
		 }
*/	
		 driver.quit();
		 LOGGER.DisposeLogger();
	}
	
	int j = 0;
	private void addCommunityDetails(String comUrl, String comData) throws Exception{
//	try{
//		if(j>=11)
	{
		//TODO:

//		if(!comUrl.contains("https://www.hunterquinnhomes.com/communities/greenville-area/piedmont/south-park"))return;
		
		if(comUrl.contains("/undefined/build-on-your-lot"))return; //not visible on page
		if(comUrl.contains("coming-soon-to-"))return;
		
		
		  U.log(j +" community url--->"+comUrl);

		  if (comUrl.contains("https://www.hunterquinnhomes.com/communities/charleston-sc/scattered-lots/coastal-farmhouse-series")
				  || comUrl.contains("https://www.hunterquinnhomes.com/communities/undefined/undefined/charles-towne-series")
				  || comUrl.contains("https://www.hunterquinnhomes.com/communities/charleston-sc/charleston-sc/lowcountry-series")
				  || comUrl.contains("https://www.hunterquinnhomes.com/communities/charleston-sc/charleston-sc/lincolnville-series")
				  || comUrl.contains("undefined/undefined")) {
				LOGGER.AddCommunityUrl(comUrl + "\t*********Return******\t");
				return;
			}
		  
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl(comUrl + "\t*********Repeated******\t");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
		  
		String comHtml = getHtml(comUrl,driver);
/*		String removeHtml = U.getSectionValue(comHtml, "<title>", "/smoothmenu");
		comHtml = comHtml.replace(removeHtml, "");
*/		
//		U.log(comData);
		//community url
		  
		//community name
		String comName = U.getSectionValue(comData, "<h4", "</h4>");
		if(comName != null) comName = comName.replaceAll("^(.*?)>", "").replace("by Hunter Quinn", "");
		U.log("community name--->"+comName);
		 

		String remPreloadData = U.getSectionValue(comHtml, ">window.__PRELOADED_STATE__", "</body>");
		String allHomeplanData="";
		String[] allhomeplan=U.getValues(remPreloadData, "{\"from\":\"/Home-Plans/", "}");
		for(String home:allhomeplan) {
			String newUrl=comName.toLowerCase().replace(" ", "-");
			String dumurl=U.getSectionValue(home, "\"to\":\"", "\"");
			if(dumurl.contains("/plans") || !comHtml.contains("PlanCard_compareButton"))continue;
//			U.log("from json::"+"https://www.hunterquinnhomes.com/plan/"+newUrl+dumurl.replace("/plan", ""));
			String planHtml=U.getHTML("https://www.hunterquinnhomes.com/plan/"+newUrl+dumurl.replace("/plan", ""));
			String datasec=U.getSectionValue(planHtml, "in the following communities:", "Download PDF Brochure");
			if(datasec!=null && datasec.contains(comName))
//				U.log(U.getSectionValue(planHtml, "<li class=\"breadcrumb-item\"", ">Elevations<!--"));
				allHomeplanData+=U.getSectionValue(planHtml, "<li class=\"breadcrumb-item\"", ">Elevations<!--");
			
		}
		if(remPreloadData != null) comHtml = comHtml.replace(remPreloadData, "");
		remPreloadData = U.getSectionValue(comHtml, "script data-react-helmet", "</script>");
		if(remPreloadData != null) comHtml = comHtml.replace(remPreloadData, "");
		
		comHtml = U.removeComments(comHtml);
		 //community notes
		comHtml=comHtml.replaceAll("information about plan offerings, pricing, and pre-selling availability.|when pre-selling will begin", "");
		String commNotes = U.getnote(comHtml);
		U.log("community notes----->"+commNotes);
		   
			
		//community latlng
		String geo = "FALSE";
		String latLng[] = {ALLOW_BLANK, ALLOW_BLANK};
		//U.log("@#$ "+comData);
		/*if(!comData.contains(".maps.LatLng()"))
		{
			latlag = U.getSectionValue(comData, "LatLng(", ")").split("\\s|\\,\\s+|\\,");
		}
		
			latlng[0] = latlag[0];
			latlng[1] = latlag[1];*/
		String latLngSec = U.getSectionValue(comData, "www.google.com/maps/place/", "/@");
		U.log("latLngSec ==" +latLngSec);
		if(latLngSec != null){
			latLng = latLngSec.split(",");
		}
		U.log("latlang--->"+latLng[0]+" "+latLng[1]);
		
		
		//community address
		 String add[] = {ALLOW_BLANK ,ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK};
		 add[0] = U.getSectionValue(comHtml, "\"streetAddress\":\"", "\"");
		 add[1] = U.getSectionValue(comHtml, "\"addressLocality\":\"", "\"");
		 add[2] = U.getSectionValue(comHtml, "\"addressRegion\":\"", "\"");
		 add[3] = U.getSectionValue(comHtml, "\"postalCode\":\"", "\"");
		 
		 if(add[0] != null) add[0] = add[0].replace("TBD", "");
		 if(add[0]!= null && add[0].length() < 4 && add[3] != null){
			 if(latLng[0] != null){
				 String add1[] = U.getAddressGoogleApi(latLng);
				 if(add1 == null)add1 = U.getAddressHereApi(latLng);
				 add[0] = add1[0];
				 geo = "True";
			 }
		 }
/*		 if(comHtml.contains("Model "))
		 {
		    address = U.getSectionValue(comHtml, "Model Home", "/strong>");
		    if (address==null) {
		    	address = U.getSectionValue(comHtml, "<em>Model Now Open!</em></u></strong></p>", "</strong>");
			}
		    
		    if (address!=null) {
		    	address=address.replace("Road North Charleston SC", "Road, North Charleston, SC");
		    	U.log(address);
		    	
				add=U.getAddress(U.getNoHtml(address));
				U.log(Arrays.toString(add));
			}
		    if (add[0]==ALLOW_BLANK) {
		    	address = U.getSectionValue(comHtml, "<strong>Model Home Now Open!</strong>", "</strong>");
			}
		    if (address!=null) {
		    	address=address.replace("Park Drive, North Charleston SC", "Park Drive, North Charleston, SC").replace(" Lincolnville SC ", " Lincolnville, SC ");
		    	U.log(address);
		    	
				add=U.getAddress(U.getNoHtml(address));
				U.log(Arrays.toString(add));
			}
		    if(address!=null&&address.contains("1018 Lexi Court, Ladson SC 29456"))
		    {
			   add[0] = U.getSectionValue(address, ":", ",").trim();
			   String addr[] = U.getSectionValue(address, ",", "<").split("\\s");
			   add[1] = addr[1].trim();
			   add[2] = addr[2].trim();
			   add[3] = addr[3].trim();
			   geo = "False";
		    }
		    else if(add[0].length()<2)
		    {
		    	add = U.getAddressGoogleApi(latlng);
				geo = "True";
		    }}
		 
		 
		 else
		 {
			 if(comUrl.contains("http://www.hunterquinnhomes.com/HQH-Communities/Creekside-at-Horizon-Village.aspx")){
				 add = U.getAddress("Horizon Village, North Charleston, SC 29405");
				 latlng = U.getlatlongGoogleApi(add);
				 geo = "True";
				 commNotes = "Address Is Taken From Community Description";
			 }
			 else if(!comName.contains("Marshfield Plantation"))
			 {
				 add = U.getAddressGoogleApi(latlng);
				 geo = "True";
			 }
			 else
			 {
				 add[0] = "Rantowles Creek";
				 add[1] = "Charleston";
				 add[2] = "SC";
				 latlng = U.getlatlongGoogleApi(add);
				 //for zip
				 String tempAdd[] = U.getAddressGoogleApi(latlng);
				 if(tempAdd!=null)
				 {
					 add[3] = tempAdd[3];
				 }
				 geo = "True";
				 if(commNotes.contains(ALLOW_BLANK))
				 {
					 commNotes = "address and latlong taken using street name";
				 }
			 }
		}
		*/ 
		 
		 U.log("Address--->"+add[0]+" "+add[1]+" "+add[2]+" "+add[3]);
		 
			String homeHtml = " ";
			String homeSec[] = U.getValues(comHtml, "<div class=\"PlanCard_media\"", "View Detail");
			U.log("homeSec length==="+homeSec.length);
			if(homeSec.length > 0)
			for (String homeLink : homeSec) {
				String homeUrl = BUILDER_URL + U.getSectionValue(homeLink, "href=\"", "\"");
//				U.log(homeUrl);
				if(!homeUrl.contains("https"))continue;
				String homD= U.getHTML(homeUrl);
				String removeHomeHtml=null;
				if(homD!=null) {
				 removeHomeHtml = U.getSectionValue(homD, "<script>window.__PRELOADED_STATE__", "</body>");
				if(removeHomeHtml!=null)
				 homD=homD.replace(removeHomeHtml, "");
				homeHtml = homeHtml+homD;
				}
				// homeHtml =homeHtml + U.getSectionValue(homeHtml, "houseInfoBox1", "<script");
				// U.log(homeHtml);
			}
			
		String[] quickUrlSections = U.getValues(comHtml, "<div class=\"HomeCard_wrapper\"", "<span class=\"HomeCard_addressAre");
		String combinedQuickHtml = "";
		int contract = 0;
		int quickHm=quickUrlSections.length;
		for(String quickUrlSec : quickUrlSections){			 
//			U.log(quickUrlSec);
			if(quickUrlSec.contains("Under Contract")||quickUrlSec.contains("Available Within")||quickUrlSec.contains("Available 4+ Months"))
				contract++;
			String quickUrl = U.getSectionValue(quickUrlSec, " href=\"", "\"");
			quickUrl = BUILDER_URL +quickUrl;
//			U.log("quickUrl--->"+quickUrl);
			String quickHtml = getHTML(quickUrl);
			combinedQuickHtml += U.getSectionValue(quickHtml, "<h1 data-reactid", "Floor Plans</div>");
		}
			 
		 //SqFt
		 if(allHomeplanData!=null)allHomeplanData=allHomeplanData.replaceAll("</strong><br data-reactid=\"\\d+\"/><!-- react-text: \\d+ -->", " ");
		 String minSq, maxSq = ALLOW_BLANK;
		 comHtml=comHtml.replaceAll("</span><span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">", " ");
		// String sqFt[] = U.getSqareFeet(allHomeplanData, "\\d{4}\\s?-\\s?\\d{4} SQ Feet|\\d{4}", 0);
		 comData = comData.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
		 
//		 U.log(comData);
		 comHtml=comHtml.replaceAll("<!---->", "").replaceAll("<span class=\"HomeCard_iconListLabel\" data-reactid=\"\\d+\">", " ");
		 combinedQuickHtml=combinedQuickHtml.replaceAll("<br data-reactid=\"258\"/><!-- react-text: \\d+ -->", " ");
		 String sqFt[] = U.getSqareFeet((comData+comHtml+allHomeplanData+combinedQuickHtml).replace("1,720 - 3,090  SQ FT", "1,720 SQ FT").replaceAll("<!-- react-text: 259 -->SQ FT", " SQ FT"), 
				 "\\d,\\d{3} SQ FT|\\d,\\d{3} </span> SQ FT|\\d,\\d{3} to \\d,\\d{3}\\+ square feet|\\d,\\d+ - \\d,\\d+\\s+? SQ FT|\\d,\\d{3} sqft up to about \\d,\\d{3} sqft|\\d,\\d{3} sqft to about \\d,\\d{3} sqft|\\d,\\d{3} to \\d,\\d{3} square feet|\\d{4} SQFT<br />|\\d{4}\\-\\d{4} SQ Feet|\\d{4} SQ Feet|\\d,\\d{3} SQ FT|\\d,\\d{3} square feet ", 0);
		 minSq = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
		 maxSq = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
		 U.log("square feet-->"+minSq+" "+maxSq);
		
//		 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comData, "[\\w\\s\\W]{100}3,090[\\w\\s\\W]{100}", 0));
//		 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comHtml, "[\\w\\s\\W]{100}3,090[\\w\\s\\W]{100}", 0));
//         U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(allHomeplanData, "[\\w\\s\\W]{100}3,090[\\w\\s\\W]{100}", 0));
//         U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(combinedQuickHtml, "[\\w\\s\\W]{100}3,090[\\w\\s\\W]{100}", 0));

		 //price
		 String minPrice, maxPrice = ALLOW_BLANK;
		comHtml=comHtml.replace("Low $500&#x27;s", "Low $500s").replace("High $400&#x27;s", "High $400s").replace("Mid $300&#x27;s", "Mid $300s").replace("Mid $400&#x27;s", "Mid $400s");
		 
		 comHtml=comHtml.replaceAll("0s|0S", "0,000").replace("UPPER 100&#x27;s", "UPPER $100,000").replace("$100,000s,", "$100,000");
	 
		 String price[] = U.getPrices(comData+ comHtml+combinedQuickHtml+allHomeplanData, 
				 "Low \\$\\d{3},\\d{3}|FROM THE HIGH \\$\\d{3},\\d{3}|FROM THE MID \\$\\d{3},\\d{3}|class=\"PlanCard_priceValue\" data-reactid=\"\\d+\">\\$\\d{3},\\d{3}</span>|Starting at \\$\\d{3},\\d{3}|starting in the \\$\\d{3},\\d{3}|class=\"HomeCard_priceValue\" data-reactid=\"\\d+\">\\$\\d{3},\\d+</span>|the low \\$\\d{3},\\d{3}|upper \\$\\d{3},\\d{3}|<div class=\"Detail_price\" data-reactid=\"\\d+\">\\$\\d{3},\\d{3}</div>|Priced From</span><!-- react-text: \\d+ -->\\$\\d{3},\\d{3}|the mid \\$\\d{3},\\d{3}", 0);	
		 minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		 maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
		 U.log("Min price: "+minPrice+" Max Price: "+maxPrice);
	
		

		 //property type
		 homeHtml = homeHtml.replace("traditional Charleston architecture", "Traditional exterior");
//		 homeHtml = homeHtml.replaceAll(">Single Family<|/Single-Family.|Craftsman Style\"|Craftsman style elevations|-Craftsman|Craftsman\"|Craftsman Elevation|Craftsman-|-craftsman-", "");
		 comHtml=comHtml.replace("bring traditional charm", "bring traditional exterior").replace("NO HOA fees", "").replace("Luxury, location,", "luxury homes");
		 String a=(comHtml+comData+combinedQuickHtml+homeHtml).replaceAll("Farmhouse--with emphasis|Multi Family</a>|Duplex|no HOA at|alt=\\\"single family farmhouse style home|| estate agent myself |Long Needle Estates Home Owner|Long Needle Estates Home Owne", "");
		
		// U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(a, "[\\w\\s\\W]{50}craftsman[\\w\\s\\W]{30}", 0));
		 
		 String propType = U.getPropType((a));
//		 U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(a, "[\\w\\s\\W]{30}farmhouse[\\w\\s\\W]{30}", 0));
		// 

		// U.log("@#@#@# ::cobine");
		 
		 if(comUrl.contains("https://www.hunterquinnhomes.com/communities/north-charleston/tributary-at-the-park-at-rivers-edge") || comUrl.contains("/communities/summerville/alston-place")) {
			 
			 if(propType.length() >4) propType =propType +  ", Traditional Homes";
		 }
		 if(comUrl.contains("https://www.hunterquinnhomes.com/communities/summerville/limehouse-village")) {
			 
			 if(propType.length() >4) propType =propType +  ", Traditional Homes";
		 }
		 if(propType.length()>180)propType=ALLOW_BLANK;
		 U.log("property type-->"+propType);
		 
		 //property status
		 
		   comHtml = comHtml.replaceAll("[A|a]dditional [H|h]omesites [C|c]oming|Additional home sites coming soon|Additional Homesites Coming Soon", "");
		   comData = comData.replaceAll("Finished Homes Now", "");
		 
		   String propStatus = U.getPropStatus(comData+(comHtml.replaceAll("Finished Homes Now|[q|Q]uick [m|M]ove|Additional home sites now Available!", "").replace("Place- Coming Soon", "")));
//		   U.log("MMMMMMMMMMMMMMMM "+Util.matchAll(comHtml, "[\\w\\s\\W]{30}PHASE II NOW SELLING![\\w\\s\\W]{30}", 0));

		   U.log("quickHm======"+quickHm);
		   U.log("contract======"+contract);
			if(quickUrlSections.length > 0 && contract<quickUrlSections.length){
				if(propStatus.length()>1 && !propStatus.contains("Move"))
				{
					propStatus=propStatus+", Quick Move-In Homes";
				}
				else
				{
					propStatus="Quick Move-In Homes";
				}
			}
			

		   U.log("property status---->"+propStatus);
		   

			
			

			
			propType = propType.trim().replaceAll("^,", "");
			
		 //derived property
		  comHtml = comHtml.replace("multi story homes", "Multi-Level");
		  
		  if(homeHtml!=null)
			  homeHtml = homeHtml.replace("one story home", " Story 1 ");
		  
		  homeHtml=homeHtml.replace("Single and multi story homes","Single Story");
		  String dProperty = U.getdCommType(comHtml.replaceAll("Branch|branch","")+combinedQuickHtml+homeHtml.replaceAll("The second story of the Wescott features|Branch floor plan|the 3rd level bonus|Alternate second story|second story to provide|modify the two-story plan to include", ""));//.replaceAll("", "")
		  if(comUrl.contains("https://www.hunterquinnhomes.com/communities/greenville-area/anderson/midway-by-hunter-quinn"))
			  dProperty="Multi-Level, 1 Story"; 
		  U.log("derived property---:"+dProperty); 
		  
		//community Type
		  comHtml=comHtml.replace("lake living", "lakeside community");
			String comType = U.getCommType(comHtml);
			
			 if(comUrl.contains("Pine-Hill-Acres.aspx"))
			 {
				 propType = propType.replace("Homeowner Association", "");
			 }
			
			U.log("community type------>"+comType);
			//from img
			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/undefined/townes-at-valley-creek") || comUrl.contains("https://www.hunterquinnhomes.com/communities/charleston-sc/summerville/downtown-summerville")
					&& !propStatus.contains("Coming Soon")){
				if(propStatus == ALLOW_BLANK) propStatus = "Coming Soon";
				else if(propStatus != ALLOW_BLANK) propStatus += ", Coming Soon";
			}
			
//			if(comUrl.contains("http://www.hunterquinnhomes.com/HQH-Communities/The-Park-at-Rivers-Edge.aspx"))commNotes = "Pre-Selling Soon";
			comName = comName.replace(" @ ", " At ");
			
			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/summerville/the-reserve-at-pine-forest")) {
				propStatus=propStatus.replace("Coming Soon", "");
				minSq="1,900";
			}
			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/undefined/townes-at-valley-creek"))
				propStatus=propStatus.replace("Coming Soon", "");
			
			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/north-charleston/creekside-at-horizon-village"))
				minPrice="$200,000";
			
//			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/greenville-area/piedmont/south-park"))
//				propStatus="Coming Late 2021";
			
			
			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/charleston-sc/summerville/lincolnville-square"))
				propStatus=propStatus.replace("Homesites Coming Soon", "");
			
			if(comUrl.contains("https://www.hunterquinnhomes.com/communities/charleston-area/north-charleston/tributary-at-the-park-at-rivers-edge"))
				propStatus = "Phase II Now Selling";
			
			if(propStatus.length()<4) {
				propStatus=ALLOW_BLANK;
			}
			if(propType.contains(", Estate-Style Homes"))
				propType=propType.replace(", Estate-Style Homes", "");
			
			//=======site map=======
//			int lotCount=0;
//			String noOfUnits=ALLOW_BLANK;
//			if(comHtml.contains("View Site Plan")) {
//				String[] lotData=U.getValues(comHtml, "<path", "</path>");
//				lotCount=lotData.length;
//				U.log("lot count= "+lotCount);
//				noOfUnits=Integer.toString(lotCount);
//				
//				if(noOfUnits.equals("0"))
//					noOfUnits=ALLOW_BLANK;
//			}
//			U.log("Numbver Of Uniits=="+noOfUnits);
			
			data.addCommunity(comName.replace("By Hunter Quinn", ""), comUrl, comType);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addLatitudeLongitude(latLng[0], latLng[1], geo);
			data.addSquareFeet(minSq, maxSq);
			data.addPrice(minPrice, maxPrice);
			data.addPropertyType(propType, dProperty);
			data.addPropertyStatus(propStatus);
			data.addNotes(commNotes);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(ALLOW_BLANK);
		
	}
	j++;
//	}catch(Exception e){}

	}
	public String getQuickHomeData(String moveHomeCommName) throws Exception
	{
		String quickHtml=getHtml("https://www.hunterquinnhomes.com/homes",driver);
		String[] moveSection=U.getValues(quickHtml, "<div class=\"HomeCard_wrapper\">", "<div class=\"HomeCard_contentMapButton");
		
		for (String name : moveSection) {
			String moveHomeCommSection[] = U.getValues(name, "Community", "</a>");
			for (String commName : moveHomeCommSection) {
				moveHomeCommName += " <> "+commName;
//				U.log("moveHomeCommName==" + moveHomeCommName);
			}
		}
		
        return moveHomeCommName;
		
		
	}
	public static String getHTML(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);
		U.log(url);
		String html = null;

		// chk responce code

//		int respCode = CheckUrlForHTML(path);
//		 U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"181.215.130.32", 3128));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language",
					"en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			Thread.sleep(2000);
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
//		    U.log(html);

			// final String html = toString(inputStream);
			inputStream.close();
			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}

	
	private String getHtml(String url, WebDriver driver) throws IOException, InterruptedException {
		String html = null;
		String Dname = null;
//		driver.navigate().to(url);
//		driver.manage().deleteAllCookies();
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// if(respCode==200)
		{
			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					
					driver.manage().window().maximize();
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(5000);
					
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,document.body.scrollHeight)", ""); 
					
					try{
						
					WebDriverWait wait = new WebDriverWait(driver, 20);
					
					while( driver.findElements(By.xpath("//*[@id=\"homesList\"]/div[2]/div/div[2]/div[2]/button")).size() > 0) {
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"homesList\"]/div[2]/div/div[2]/div[2]/button"))));
						//Thread.sleep(2000);
						WebElement loadBtn = driver.findElement(By.xpath("//*[@id=\"homesList\"]/div[2]/div/div[2]/div[2]/button"));//--------//load more button
						loadBtn.click();
						U.log(":::::::::::::CLick Success:::::::::::::::");
						Thread.sleep(5000);

						((JavascriptExecutor) driver).executeScript("window.scrollBy(0,document.body.scrollHeight)", "");
						}
					}
					catch(Exception e){
						U.log(":::::::::::::CLick UnSuccess:::::::::::::::"+e.getMessage());
					}
					
					Thread.sleep(8000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
	}
}