package com.shatam.b_301_324;

import java.util.ArrayList;
import java.util.Arrays;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class MedallionHomesGulfCoast extends AbstractScrapper {
	public int k = 0;
	public int inr = 0;
	static int j=0;
	static String Builder_name = "Medallion Homes Gulf Coast";
	static String HOME_URL = "https://medallionhome.com";
	CommunityLogger LOGGER;
	public static void main(String[] args) throws Exception {

		AbstractScrapper a = new MedallionHomesGulfCoast();
		a.process();
		//a.data().printAll();
		FileUtil.writeAllText(U.getCachePath()+"Medallion Homes Gulf Coast.csv", a.data().printAll());
	}

	public MedallionHomesGulfCoast() throws Exception {

		super(Builder_name, HOME_URL);
		LOGGER = new CommunityLogger("Medallion Homes Gulf Coast");
	}

	public void innerProcess() throws Exception {
		String html = U.getHTML("https://medallionhome.com/");
		String htmls=U.getHTML("https://medallionhome.com/communities/");
		
		
		String region[] = U.getValues(htmls, "hproduct marketPage communityDataInformation mapFeatureItem", "View Map");
		for (String sec1 : region) {
//			U.log("==="+sec1);
			String comUrl = U.getSectionValue(sec1, "<a href=\"", "\"");
			if(!comUrl.startsWith("http")) comUrl = HOME_URL+comUrl;
			U.log(comUrl);
//			try {
				adDetails(comUrl, sec1);
//			} catch (Exception e) {}
		}
		LOGGER.DisposeLogger();
	}

	//TODO :
	public void adDetails(String url, String sec) throws Exception {
//		try{
		{
			
			
//		if(!url.contains("https://medallionhome.com/communities/legends-bay/"))return;

				
		
		U.log(j+"\tPage Url: " + url);

//		U.log(sec);
		if (data.communityUrlExists(url)){
        	LOGGER.AddCommunityUrl(url+ "---------------------------------repeat");
        	return;
        }
        LOGGER.AddCommunityUrl(url);
        
		String name=U.getSectionValue(sec, "data-community-name=\"", "\"");
		if(name != null) name = name.replaceAll(" Villas$", "");
		U.log("commName ::"+name);

		
		String commHtml = U.getHTML(url);
		commHtml=commHtml.replace("footerAnchorBackgroundColor", "");
		
		commHtml=commHtml.replace("Golf Course Rd for 3 miles.", "");
	
		U.log(U.getCache(url));	
		//=========== Homes Available Now Section =================
		String availHomeHtml=ALLOW_BLANK;
		int underContract = 0;
		int sold = 0;
		String availableHomeSec = U.getSectionValue(commHtml, "<h3 class=\"\">Move-In Ready</h3>", "<div class=\"directionsSection");
		String availableHomes [] = {};
		if(availableHomeSec != null)
			availableHomes  = U.getValues(availableHomeSec, "<li class=\"hproduct homeDataInformation", "SEE DETAILS"); 
		for(String urls:availableHomes){
			
			if(urls.contains("alt=\"Sold\">"))
				sold ++;
			
			if(urls.contains("alt=\"Under Contract\">"))
				underContract ++;
			
			String availableUrl = HOME_URL +U.getSectionValue(urls, "href=\"", "\"");
			U.log("availableUrl =="+availableUrl);
			availHomeHtml+=U.getHTML(availableUrl);
		}
		
		
		//=========== Homes Plans Now Section =================
				String plansHomesHtml=ALLOW_BLANK;
				String planHomeSec = U.getSectionValue(commHtml, "<h3 class=\"\">Plans</h3>", "<div id=\"anchorLinkHomeListTitle\">");
				String planHomes [] = {};
				if(planHomeSec != null)
					planHomes  = U.getValues(planHomeSec, "<li class=\"hproduct homeDataInformation", "SEE DETAILS"); 
				for(String urls:planHomes){
					String planUrl = HOME_URL +U.getSectionValue(urls, "href=\"", "\"");
					U.log("planUrl =="+planUrl);
					plansHomesHtml+=U.getHTML(planUrl);
				}
		

		//================== Sqft ==========================
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		
		String[] sq = U.getSqareFeet(commHtml+availHomeHtml,
				"\\d,\\d{3} - \\d,\\d{3} SQ FT|\\d{1},\\d{3} sq. ft. - \\d{1},\\d{3} sq. ft|[0-9]{3},[0-9]{3} - [0-9]{1},[0-9]{3}  Square Feet</li>|[0-9]{1},[0-9]{3} Square Feet|\\d,\\d{3} SQ FT", 0);
		minSqf = (sq[0] == null) ? ALLOW_BLANK : sq[0];
		maxSqf = (sq[1] == null) ? ALLOW_BLANK : sq[1];

		U.log("minSqf :" + minSqf + " maxSqf:" + maxSqf);

		//=================== Price ======================
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		
		if(commHtml.contains("<span>WATER VIEW LOTS AVAILABLE</span>") && url.contains("/communities/legends-bay/")) {
			String remove = U.getSectionValue(commHtml, "<span>WATER VIEW LOTS AVAILABLE</span>", "<footer id=\"siteFooter\">");
			commHtml = commHtml.replace(remove, "");
			
		}
		
		commHtml = commHtml.replaceAll("class=\"previousPrice\">\\$\\d+,\\d+,\\d+|class=\"previousPrice\">\\$\\d+,\\d+", "");
		commHtml = commHtml.replace("0s", "0,000").replace("0's+", "0,000").replace("Priced at</span> <span class=\"dealPrice\">", "Priced at")
				.replace("Starting at</span> <span class=\"dealPrice\">", "Starting at");
		String[] price = U.getPrices(sec + commHtml + availHomeHtml.replace("Starting at</span> <span class=\"dealPrice\">", "Starting at").replace("Priced at</span>", "Priced at"),
				"<p style=\"text-align: left;\">\\$<span>(\\d,)?\\d{3},\\d{3} </span>|>\\$\\d{3},\\d{3}\\s*</p>|Starting at\\$\\d+,\\d+,\\d+</span>|Starting at\\$\\d+,\\d+</span>|Priced at\\$\\d+,\\d+</span>|Priced at\\$\\d,\\d+,\\d+</span>|class=\"dealPrice\">\\$\\d+,\\d+,\\d+|Starting at \\$\\d{3},\\d{3}|Priced at \\$\\d{3},\\d{3}|from the \\$\\d{3},\\d{3}|From The \\$\\d{3},\\d{3}|Priced at \\$\\d{1},\\d{3},\\d{3}|dealPrice\">\\$\\d,\\d{3},\\d{3}", 0);

		//System.out.println(chtm1l);
		//price = U.getPrices(commHtml,"Priced at\\$404,990</span>", 0);
		
		minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
		maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
/*		if (url.contains("https://medallionhome.com/communities/hampton-lakes/")) {
			minPrice="$500,000";     //from image banner on community home page  
		}*/
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);


		//=========== Lat/lng =====================

		String lat = ALLOW_BLANK, lng = ALLOW_BLANK, geo = ALLOW_BLANK;
		lat = U.getSectionValue(commHtml, "Latitude:</span> ", "</span>");
		lng = U.getSectionValue(commHtml, "Longitude:</span> ", "</span>");
		
		U.log("lat :: "+lat +" lng::"+lng);

		//========================== Address =========================
		geo = "FALSE";
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		if(commHtml.contains("<span class=\"addressStreet\">"))
			add[0] = U.getSectionValue(commHtml, "<span class=\"addressStreet\">","<").replace(".", "").replace("5907 Redbay Boulevard, Bradenton, FL 34210", "5907 Redbay Boulevard").replaceAll("Bradenton|Model Address, |Model Address ", "");
		if(commHtml.contains("<span class=\"addressCity\">"))
			add[1] = U.getSectionValue(commHtml, "<span class=\"addressCity\">","<").replace(",", "");
		if(commHtml.contains("<span class=\"addressState\">"))
			add[2] = U.getSectionValue(commHtml, "<span class=\"addressState\">","<");
		if(commHtml.contains("<span class=\"addressZipCode\">"))
			add[3] = U.getSectionValue(commHtml, "<span class=\"addressZipCode\">","<").trim();
			
		U.log("Adress:: "+Arrays.toString(add));

		if (lat != ALLOW_BLANK && add[0] == ALLOW_BLANK) {
			String add1[] = U.getAddressGoogleApi(new String[] { lat, lng });
			if(add1 == null) add1 = U.getAddressHereApi(new String[] { lat, lng });
			add[0] = add1[0];
			geo = "TRUE";
		}
		
		//=============== Property Status ====================
		commHtml=commHtml.replaceAll("\"Grand|GRAND OPENING PRICING|two move in ready homes at your|FURNISHED MOVE IN READY HOME|Coming Soon</a>|Fire pit-COMING SOON|Now Selling!</a>|COMING SOON FEATURE HOME | Golf Course Road|Homes Available|Quick Move-In|Lots Available</h2|Move(-|\\s)In|MOVE-IN","");
		commHtml = commHtml.replaceAll("WATERFRONT LOTS AVAILABL|Available Waterfront Lots", "Waterfront Lots Available")
				.replace("Now open is Phase 1B ", "Phase 1B Now open");
		sec = sec.replace("Less then", "Less than").replace("ten", "10");
		//+commHtml
		String pStatus =U.getPropStatus((sec+ commHtml).replace("Now open is Phase 1B ","Phase 1B Now open").replaceAll("Available\">View Waterfront Lots|a>SARASOTA BAY <span>Waterfront Lots|name=\"Lots Available|closeout\\.png|class=\"tipCloseout", ""));
		U.log("pstatus =="+pStatus);
		
//		U.log("MMMMMMM "+Util.matchAll((commHtml+sec), "[\\s\\w\\W]{30}Sold out community[\\s\\w\\W]{30}", 0));
/*		pStatus=pStatus.replace("Move-in Ready,","");
		pStatus=pStatus.replace(", Move-in Ready","");
		pStatus=pStatus.replace("Move-in Ready","");
*/		
		if(pStatus.equals("New Lots Now Available, Now Available")) pStatus=pStatus.replace("New Lots Now Available, Now Available","New Lots Now Available");
		
		//=================== Image Status ========================
		if(url.contains("https://medallionhome.com/communities/the-reserve-at-twin-rivers/"))pStatus = "Final Phase";//Img
		if(url.contains("https://medallionhome.com/communities/cross-creek/")) pStatus = pStatus + ", Closeout";//Img 26 may
	//	if(url.contains("https://medallionhome.com/communities/waverley/")) pStatus=""
//U.log("============================================================= "+availableHomes.length+"\t"+underContract);
		if(availableHomes.length > underContract && availableHomes.length > sold && !pStatus.contains("Move In")){
			if(pStatus.length()>4){
				pStatus=pStatus+", Move In Ready Homes";
			}else{
				pStatus="Move In Ready Homes";
			}
		}
		
		if(sec.contains("images/closeout.png\""))
			if(!pStatus.contains("Closeout")){
				if(pStatus.length()>4){
					pStatus=pStatus+", Closeout";
				}else{
					pStatus="Closeout";
				}
			}
		
//		String chtml = U.getHTML(url);
//		if(chtml.contains("Move-In Ready</h3>")&& !pStatus.contains("Move In") && availableHomes.length>underContract){
//			if(pStatus.length()>4){
//				pStatus=pStatus+", Move In Ready Homes";
//			}else{
//				pStatus="Move In Ready Homes";
//			}
//		}
		
		
		
		//=========== note =============
		String notes=U.getnote(commHtml+sec);
		
		//============== Property Type =======================
		
		commHtml=commHtml.replaceAll("Villa Homes are also available|Single Family Homes</a>|single-family-homes|Single Family Homes are also available at Watercolor Place |\"Grand|GRAND OPENING PRICING|without the high CDD and HOA fees|Ranch High|Ranch Boulevard|Fire pit-COMING SOON!", "").replace("towns in the country", "");
		commHtml=commHtml.replace("luxury resort ambiance", "luxury living resort style ambiance");
		commHtml=commHtml.replace("custom designed", "custom home design").replace("Now open is Phase 1B", "Now open Phase 1B");
		plansHomesHtml = plansHomesHtml.replaceAll("without any CDDs or high HOAs|without the high CDD and HOA fees", "")
				.replaceAll("luxurious, and completely grand|the luxury and comfort|perfect mix of luxury,", "luxury homes");
		
		availHomeHtml = availHomeHtml.replaceAll(" luxury and comfort", "luxury homes").replaceAll("without any CDDs or high HOAs|without the high CDD and HOA fees", "");
		
		String pType = U.getPropType(sec+commHtml +availHomeHtml+plansHomesHtml+ getStoryHtml(url).replaceAll("Villa &amp|watercolor-place-villas|without the high CDD and HOA fees", ""));
//		U.log("MMMMMMMMMM "+Util.matchAll(commHtml +availHomeHtml+plansHomesHtml+ getStoryHtml(url).replaceAll("without the high CDD and HOA fees|without any CDDs or high HOAs", ""),
//				"[\\w\\s\\W]{30}villa[\\w\\s\\W]{30}", 0));

		if(add[0].length()<4) {
			String latlng[]= {lat,lng};
			add=U.getAddressGoogleApi(latlng);
			if(add == null) add = U.getAddressHereApi(latlng);
			geo="TRUE";
			
		}
		
		if(pStatus.length()==0){
			
			pStatus=ALLOW_BLANK;
		}

		if(url.contains("https://medallionhome.com/communities/palma-vista/"))add[0] = "6300 El Conquistador Parkway";

			
			
	
		
		if(url.contains("https://medallionhome.com/communities/legends-bay/")) {
			pStatus="Water View Lots Available";
			
			
		}
//		
//		if(url.contains("https://medallionhome.com/communities/lakes-of-mount-dora/")){
////			pStatus +=", New Preserve And Water View Lots Available"; //from image
//			minPrice = "$300,000"; //from image
//		}

		add[0]=add[0].replaceAll("&#39;s", "'s").replace(" W *Sales Office Located Four Miles Away in Legends Bay ", "");
//		pStatus = pStatus.replace("New Lots Now Available, Now Available", "New Lots Now Available").replace("Now Available, Move In Ready Homes, New Preserve And Water View Lots Available", "New Lots Now Available, Move In Ready Homes, New Preserve And Water View Lots Available");
		pStatus=pStatus.replace("New Lots Now Available, Now Available, Move In Ready Homes","New Lots Now Available, Move In Ready Homes");
		commHtml = commHtml.replaceAll("Gulf Coast&#39;s premier waterfront|Gulf Coast's premier waterfront community", "")
				.replace("Waterfront Lots", "Waterfront community Lots").replace("waterfront views", "waterfront community views")
				.replace(" waterfront home with", " waterfront community home with");
		String comType = U.getCommunityType(commHtml.replace("gated", "Gated Community"));
		if(url.contains("https://medallionhome.com/communities/legends-bay/")) {
			comType=comType.replace("Waterfront Community, ", "");
		}
		
		
		String dtype = U.getdCommType((commHtml+ getStoryHtml(url) + plansHomesHtml.replace("split plan offers a large Master Suite", "split-plan home offers a large Master Suite")).replaceAll("3rd floor rooftop sun deck|Anchor|Ranch Main Street",""));		
//		U.log("<<<<<<<<<<<< "+Util.matchAll(plansHomesHtml,"[\\s\\w\\W]{50}split plan offers[\\s\\w\\W]{30}", 0));
		

		data.addCommunity(name.trim(), url, comType);
		data.addAddress(add[0], add[1], add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat, lng, geo);
		data.addPropertyType(pType,dtype);
		data.addPropertyStatus(pStatus.replace("1b", "1B"));
		data.addNotes(notes);
		data.addUnitCount(ALLOW_BLANK);
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		j++;
//		}catch(Exception e){}
	}

	private String getStoryHtml(String url) throws Exception {

		String combineHtml = ALLOW_BLANK;
		String html = U.getHTML(url);

		String section = U.getSectionValue(html, "Plans Available</h3>",
				"Get Driving Directions");
		if (section != null) {
			String homeLinks[] = U.getValues(section, "href=\"/communities",
					"\">");

			for (String link : homeLinks) {
				link = "https://webarch-medallion.bhitest.com/communities"
						+ link;
//				U.log("Getting:  " + link);
				combineHtml += U.getHTML(link);
				combineHtml=combineHtml.replace("split plan", "split floor-plan");
			}
		}
		return combineHtml;

	}

}