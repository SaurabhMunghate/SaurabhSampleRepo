/** 
 * @modify Sawan
 * @date 31 Dec 2018
 * @author : Chinmay
 * @date : 22/07/2017
 */

package com.shatam.b_301_324;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import org.bouncycastle.crypto.tls.AlertLevel;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class TwilightHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	static String builderName = "Twilight Homes";
	static String builderURL = "https://twilighthomesnm.com";

	public static void main(String[] args) throws Exception {
		AbstractScrapper abs = new TwilightHomes();
		abs.process();
		FileUtil.writeAllText(U.getCachePath() +builderName + ".csv", abs.data().printAll());

	}

	public TwilightHomes() throws Exception {
		super(builderName, builderURL);
		LOGGER = new CommunityLogger(builderName);
	}

	@Override
	protected void innerProcess() throws Exception {
		String mainRegionHtml = U.getHTML(builderURL + "/communities/");

		String mainRegionUrlSection[] = U.getValues(mainRegionHtml, "home-button et_pb_bg_layout_light\"", "/a>");
		U.log(mainRegionUrlSection.length);
		for (String mainRegUrlSec : mainRegionUrlSection) {
			String regUrl = U.getSectionValue(mainRegUrlSec, "href=\"", "\">");
			U.log("regUrl :" + regUrl);

			if (!regUrl.startsWith("http")) regUrl = builderURL + regUrl;
			
/*			if (!regUrl.contains("http"))
				extractRegionCommunities(builderURL + regUrl, mainRegUrlSec);
			else
*/

			extractRegionCommunities(regUrl, mainRegUrlSec);
		}
		LOGGER.DisposeLogger();
	}

	private void extractRegionCommunities(String regUrl, String regSection) throws Exception {
		U.log("regUrl :" + regUrl);

		String regHtml = U.getHTML(regUrl);

		if (regUrl.contains("https://twilighthomesnm.com/community/")) {
		//	extractCommuntiesDetails(regUrl, regSection);
		}
		
		else {
			String section = U.getSectionValue(regHtml, "<article id", "</article>");
			String communitySections[] = U.getValues(section, "<div class=\"et_pb_text_inner\">", "More on"); //"</div>");
			U.log("communitySections==="+communitySections.length);
			for (String comSec : communitySections) {
				
				
//			U.log("comSec===\n"+comSec+"\n=========================================");
				
				comSec = comSec.replace("href=\"https://twilighthomesnm.com/community/rio-rancho", "")
						.replace("nofollow\" href=\"https://twilighthomesnm.com/\">home</a>", "");
				String comUrl = U.getSectionValue(comSec, "href=\"", "\">");
				if(comUrl!=null) {
					
					if(!comUrl.startsWith("https"))comUrl="https://twilighthomesnm.com"+comUrl;
					if(comUrl.contains("move-in-ready/"))continue;
//				U.log(comUrl);
				extractCommuntiesDetails(comUrl,comSec);
				}
			}
		}
		//extractCommuntiesDetails("https://twilighthomesnm.com/community/mariposa-urban/", "<h2>Mariposa Urban</h2>"); 
		extractCommuntiesDetails("https://twilighthomesnm.com/community/esplanade/", "<h2>Esplande</h2>"); 
		extractCommuntiesDetails("https://twilighthomesnm.com/community/joya-escondida/", "<h2>Joya Escondida</h2>");//Rio Rancho Region
		extractCommuntiesDetails("https://twilighthomesnm.com/community/cielo-azul/", "<h2>Cielo Azul</h2>");
		extractCommuntiesDetails("https://twilighthomesnm.com/community/la-potencia/", "<h2>La Potencia</h2>");
	}

	int i = 0;

	// TODO : Extract Communities Details Here
	private void extractCommuntiesDetails(String url, String comSec) throws Exception {
//	if(i >= 11)
		{
		if (!url.contains("https://twilighthomesnm.com/community/lavender-fields/"))return;
			
			if (!url.contains("/community/"))
				return;

			if (data.communityUrlExists(url)) {
				LOGGER.AddCommunityUrl("Repeated ********** " + url);
				return;
			}
			LOGGER.AddCommunityUrl(url);

			if (url.contains("https://twilighthomesnm.com/community/lavender-meadows/")) {
				
				LOGGER.AddCommunityUrl(url+"==========return===== 404 ======");
				return;
				}
			
          if (url.contains("https://twilighthomesnm.com/community/esplanade/")||url.contains("https://twilighthomesnm.com/community/joya-escondida/")||
        		  url.contains("https://twilighthomesnm.com/community/cielo-azul/")||url.contains("https://twilighthomesnm.com/community/la-potencia/")) {
				
				LOGGER.AddCommunityUrl(url+"===========Redirecting ======");
				return;
				}

			if(url.contains("community/esplanade/"))url="https://twilighthomesnm.com/community/esplanade/";
			U.log("Count: " + i + " comUrl ::" + url);
			String html = U.getHTML(url);

			// =========== Community Name =====================
//			U.log("comSec===="+comSec);
			
			String comName = U.getSectionValue(comSec.replace("<h2></h2>", ""), "<h2>", "</h2>");
			if(comName==null) {
				
				comName=U.getSectionValue(html, "<h1 class=\"series-title\">", "|");
			}
			comName=comName.replace("| Sold Out", "").replace("The M | ", "").replace("| North Valley", "").replace("| Albuquerque Heights", "");
			
			if(url.contains("community/la-mirada"))comName="La Mirada";
			comName=comName.replace("Estrella de Norte", "Estrella del Norte");
			
			if(url.contains("/community/tierra-contenta/"))comName="Tierra Contenta";
			U.log("ComName ::" + comName);

			// =============== Notes ===================
			String notes = U.getnote(html);

			// TODO :============= Lat- Lng ==============
			String geo = "False";
			String addSec = U.getSectionValue(html, "Directions to Our Model Home",
					"<div class=\"et_pb_module et_pb_text");

			String latLng[] = { ALLOW_BLANK, ALLOW_BLANK };
/*			if (addSec != null) {
				String mapUrl = U.getSectionValue(addSec, "\" href=\"", "\" target=");
				U.log("map url ::" + mapUrl);

				if (mapUrl != null && mapUrl.startsWith("https://goo.gl")) {
					String googleMapHtml = U.getHTML(mapUrl);
					// FileUtil.writeAllText("/home/glady/filename.txt", googleMapHtml);
					String latLngSection = Util.match(googleMapHtml,
							"APP_INITIALIZATION_STATE=\\[\\[\\[\\d{4}\\.\\d{3,},(-\\d{2,3}.\\d{2,},\\d{2}.\\d{2,})\\]",
							1);
					U.log(latLngSection);
					if (latLngSection != null) {
						String vals[] = latLngSection.split(",");
						if (vals[0].startsWith("-")) {
							latLng[0] = vals[1];
							latLng[1] = vals[0];
						} else
							latLng = vals;
					}
					geo="True";
				}
			}
			U.log("LatLng ::" + Arrays.toString(latLng));
*/
			// TODO :============ Address ===========================
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			U.log("Add Sec: "+addSec);
			if(addSec!=null)
			addSec=addSec.replace("2503 Parkway Ave. NE Rio Rancho, NM 87144", "2503 Parkway Ave, Rio Rancho, NM 87144"); 
			
			if (addSec != null) {
				addSec = Util.match(addSec, "target=\"_blank\">(.*?)</a>", 1);
				addSec = addSec.replaceAll("Lp. Rio", ",")
						.replace("Albuquerque 87105", "Albuquerque, NM 87105");
			}
			U.log("SSSSSSSS==="+addSec);
			
			
			if (addSec != null) {
				
				String vals[] = addSec.split(",");
				if (vals.length == 2) {
					add[0] = vals[0];
					add[3] = Util.match(vals[1], "\\d{5}");
					add[1] = vals[1].replace(add[3], "").trim();
				} else if (vals.length == 3)
					add = U.getAddress(addSec);
			}

			U.log("Add :" + Arrays.toString(add));

			if(html.contains("href=\"https://www.google.com/maps/place/")) {
				
				String addsec1=U.getSectionValue(html, "href=\"https://www.google.com/maps/place/","</div>");
				U.log(">>>>>>  "+addsec1);
				if(latLng[0].length()<5) {
					String ss=U.getSectionValue(addsec1, "@", "z/");
					if(ss!=null) {
					latLng[0]=Util.match(ss, "\\d{2}.\\d+");
					latLng[1]=Util.match(ss, "-\\d{2,3}.\\d+");
					}
					
				}
				String addsec2=U.getSectionValue(addsec1, "target=\"_blank\">","</a>");//.replace("Country Club Dr SE &amp;", "");
				if(addsec2==null) {
//					U.log("MM>>>>>>  "+addsec2);
					addsec2=U.getSectionValue(addsec1, ">","</a>");
				}
				addsec2=addsec2.replace("Country Club Dr SE &amp;", "");
				
				U.log("22>>>>>>  "+addsec2);//1
				if(add[0].length()<4){
					
					add=U.getAddress(addsec2);//1
				}
			}
			
			U.log("Address: "+Arrays.toString(add));
			if(addSec == null && (add[0]==null||add[0]==ALLOW_BLANK)) {
				String addressSection = U.getSectionValue(U.getHTML("https://twilighthomesnm.com/contact-us/"), "<div class=\"et_pb_module et_pb_text et_pb_text_1  et_pb_text_align_left et_pb_bg_layout_light\">", "<div class=\"et_pb_section et_pb_section_2 et_section_regular\" >");
				String contactAddresses[] = U.getValues(addressSection,"<div class=\"et_pb_text_inner\">","/a>");
				U.log(contactAddresses.length);
				for(String addrs:contactAddresses) {
					addrs = addrs.replace("Estrella del Norte", "Estrella de Norte");
					U.log(addrs);

					if(addrs.contains(comName.trim()))
					{	
						 U.log(addrs);
						 addSec = U.getSectionValue(addrs, "target=\"_blank\">", "<");
						 addSec = addSec.replace("Lp Rio Rancho,", "Lp, Rio Rancho,")
								 .replace("NW Albuquerque,", "NW, Albuquerque,");
						 U.log("NNNN==="+addSec);
						 
						 add = U.getAddress(addSec);
						 U.log("NNNN==="+add[3]);
						 if(add[3]==ALLOW_BLANK||add[3]==null||latLng==null) {
//							 add[3]=U.getGoogleZipFromAddressWithKey(add);
							 latLng=U.getlatlongGoogleApi(add);
							 add[3]=U.getAddressGoogleApi(latLng)[3];
							geo="TRUE";

						 }
					}

				}
			}
			
			
			if (url.contains("https://twilighthomesnm.com/community/petroglyph-estates/")) {
				add = U.getAddress("6611 Petirrojo Rd NW, Albuquerque, NM 87120");
				notes = "Address Is Taken From Community Site Image";
			}
			if (url.contains("https://twilighthomesnm.com/community/vista-entrada/")) {
				add = U.getAddress("Flame Ct NE, Rio Rancho, NM 87144");
				notes = "Address Is Taken From Community Site Image";
			}
			
			
			if (url.contains("https://twilighthomesnm.com/community/piedras-lisa/")) {
				String adds[]= {"","Bernalillo","NM",""};
				latLng=U.getlatlongGoogleApi(adds);
				if(latLng == null) latLng = U.getlatlongHereApi(adds);
//				lat=latlong[0];
//				lng=latlong[1];
				geo="TRUE";
				notes="Address Taken From Using City And State";
			}
			if (url.contains("https://twilighthomesnm.com/community/lavender-estates/")) {
				String adds[]= {"","Albuquerque","NM",""};
				latLng=U.getlatlongGoogleApi(adds);
				if(latLng == null) latLng = U.getlatlongHereApi(adds);
//				lat=latlong[0];
//				lng=latlong[1];
				geo="TRUE";
				notes="Address Taken From Using City And State";
			}
			
/*			if (url.contains("https://twilighthomesnm.com/community/tierra-del-oro/")) {
				add = U.getAddress("Northern Blvd, Rio Rancho, NM 87105");
				notes = "Address Is Taken From Community Site Image";
			}
*/			if (url.contains("https://twilighthomesnm.com/community/vista-entrada/")) {
				add = U.getAddress("Paseo Del Volcan,Rio Rancho, NM 87144");
				notes = "Address Is Taken From Community Site Image";
			}

			if (latLng[0] != ALLOW_BLANK && latLng[1] != ALLOW_BLANK) {
				
				if (add[1] == ALLOW_BLANK || add[3] == ALLOW_BLANK || add[2] == ALLOW_BLANK) {
					String add1[] = U.getAddressGoogleApi(latLng);
					if(add1 == null) add1 = U.getAddressHereApi(latLng);
					if(add[0] == ALLOW_BLANK) add[0] = add1[0];
					if(add[1] == ALLOW_BLANK) add[1] = add1[1];
					if(add[2] == ALLOW_BLANK) add[2] = add1[2];
					if(add[3] == ALLOW_BLANK) add[3] = add1[3];
					geo = "True";
				}
				
			} else {
				if (add[1] != ALLOW_BLANK && add[3] != ALLOW_BLANK) {
					latLng = U.getGoogleLatLngWithKey(add);
					geo = "True";
				}
			}

			// =========== Move In Ready Home ===================
			
			
			String moveInReadyHtml = extractMoveInReadyHomes();
			int moveInAvail=0;
			moveInReadyHtml = moveInReadyHtml.replace("<div class=\"wpl_pagination_container\">",
					"<div class=\"wpl-column\">");
			String[] moveInHomeSections = U.getValues(moveInReadyHtml, "<div class=\"wpl_prp_bot\">",
					"<div class=\"wpl-column\">");
			U.log("Total Move In Homes Count :::" + moveInHomeSections.length);
			int countOfMoveInHomes = 0;
			String combinedMoveInHomes = null;
			for (String moveInHomeSec : moveInHomeSections) {
//				U.log("moveInHomeSec=====================\n"+moveInHomeSec);
				if (moveInHomeSec != null) {
//					if (moveInHomeSec.toLowerCase().contains(comName.toLowerCase().trim()+"</h3>")) {
//						U.log(moveInHomeSec);
						String moveinUrl = U.getSectionValue(moveInHomeSec, "href=\"", "\"");
						
						String moveinHtml = U.getHTML(moveinUrl);
//						if(moveinHtml.contains("$609,153")) {
//							U.log("Found");
//						}
						String sec=U.getSectionValue(moveinHtml, "Community :", "</span>").replace("<span>", "");
//						U.log("SEC===="+sec);
//						U.log("comName===="+comName);
						
						if(comName.equals("Tierra del Oro"))
							comName="Tierra Del Oro";
						if(comName.equals(""))
							comName="Tierra Del Oro";
						if(sec.contains(comName.trim())) {
							U.log("moveinUrl==="+moveinUrl);
							moveInAvail++;
						String insideHtmlDescSec = U.getSectionValue(moveinHtml, "<div class=\"wpl-row wpl-expanded\">",
								"<span>Basic Details</span>");
						// U.log(insideHtmlDescSec);
						combinedMoveInHomes += (moveInHomeSec + insideHtmlDescSec).replace("Rancho", "");
						countOfMoveInHomes++;
						}
					}
			}
			U.log("Total Found Move in homes :" + countOfMoveInHomes);

			// =====================Floor Plans=============

			String floorSec = U.getSectionValue(html, "<h2 class=\"tax-model-heading\">Floor Plans Available","</section>");
			String allfloorHtml = "";

			if(floorSec != null){
				String[] floor = U.getValues(floorSec, "<a href=\"", "\"");
				for (String f : floor) {
					//U.log("knd"+f);
					if(f.contains("aquarius")||f.contains("aries")||f.contains("verano"))
						
					allfloorHtml += U.getHTML(f);
				}
			}

			// ========================Map Value==============

			String id = U.getSectionValue(html, "\"id\":\"", "\"");
			String mapValue = U.getHTML("https://twilighthomesnm.com/wp-admin/admin-ajax.php?action=mapdata&map=" + id);
			String[] mapSec = U.getValues(mapValue, "\"id\"", "}");
			String mapPrice = "";

			for (String p : mapSec) {

				if (p.contains(comName))
					mapPrice += p;
			}

			// ============== Square Footage ====================
			String sqFt[] = U.getSqareFeet(html + combinedMoveInHomes,
					"range from \\d{4} sq.ft to \\d{4} sq.ft.|model-square-footage\">\\d{4}|>\\d,\\d{3}<span>Sqft</span>", 0);
			String minSqFt = (sqFt[0] == null) ? ALLOW_BLANK : sqFt[0];
			String maxSqFt = (sqFt[1] == null) ? ALLOW_BLANK : sqFt[1];
			U.log("SqFt::: " +minSqFt+"   "+maxSqFt);

			// ============== Prices ===================
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			comSec =comSec.replace("$200k", "Homes from $200,000");
			html = html.replace("start from $269K", "start from $269,000");
			//U.log(comSec);
			mapPrice = mapPrice.replaceAll("\"description\":\"Homes from \\$\\d{3},\\d{3}\"", "");
			String[] price = U.getPrices((comSec + html + combinedMoveInHomes + mapPrice).replace("<span >$569,990<", "").replace("<span >$313,990<", ""),
					"Starting at \\$\\d{3},\\d{3}|start from \\$\\d{3},\\d{3}|Homes from \\$\\d{3},\\d{3}|range from \\$\\d{3},\\d{3}\\s?(-|to)\\s?\\$\\d{3},\\d{3}|<div class=\"model-price\">From \\$\\d{3},\\d{3}</div|homes from \\$\\d{3},\\d{3}|model-price\">\\$\\d{3},\\d{3}|price_box\"\\s+>\\s+<span\\s+>\\$\\d{3},\\d{3}</span>",
					0);
//			 U.log("MMMMMMMMMMM "+Util.matchAll(comSec + html + combinedMoveInHomes + mapPrice , "[\\s\\w\\W]{100}613,249[\\s\\w\\W]{100}",0));
//
//			 U.log("MMMMMMMMMMM "+Util.matchAll(combinedMoveInHomes , "[\\s\\w\\W]{100}\\$613,249[\\s\\w\\W]{100}",0));
//			 U.log("MMMMMMMMMMM "+Util.matchAll(  comSec + html + combinedMoveInHomes + mapPrice, "[\\s\\w\\W]{100}\\$413,840[\\s\\w\\W]{100}",0));

			
			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			U.log("Prices::: " + Arrays.toString(price));
			
			// TODO :============ Community Type ===========================
			html = html.replaceAll("Country Club Dr|Ana Golf|and the country club", "");
			String comType = U.getCommunityType(html);

			// TODO :============ Property Type ===========================
			html = html.replaceAll("high-end semi-custom finishes|high-end custom details", "new custom home").replaceAll("Rio Ranch|ancho|Traditional Southwest|traditional, old-fashioned neighborhood ",
					"");
//			if (allfloorHtml == null)allfloorHtml = "";
			allfloorHtml = allfloorHtml
					.replaceAll("Rio Ranch|ancho|Traditional Southwest|traditional, old-fashioned neighborhood ", "");

			if (combinedMoveInHomes == null)
				combinedMoveInHomes = "";
			combinedMoveInHomes = combinedMoveInHomes
					.replaceAll("Rio Ranch|ancho|Traditional Southwest|traditional, old-fashioned neighborhood ", "");

			String propType = U.getPropType((html + combinedMoveInHomes + allfloorHtml).replaceAll(">Twilight Luxury Homes</a>|www.twilightluxury|Loft|loft<", ""));
			// TODO :============ Derived Property Type ===========================
			html = html.replaceAll("(R|r)ancho", "");
			

			// TODO :============ Property Status ===========================
			html = html.replace("Model Home | NOW OPEN", "").replaceAll("The Model is Now Open|Our new model home is now open|This desert sanctuary community has limited homes available", "").replaceAll("This centrally located community has limited homes available|SOLD OUT</a></li>|Move-In Ready</a>|Campaign Title: Close Out |-closeouts-|Move-In|<h2>Paseo del Rio \\| Now Selling<", "") //target=\"_blank\">COMING SOON</a>
					.replaceAll("Tierra Contenta Coming Soon|Model Home \\| Coming Soon|Coming Soon \\| Floor|Coming Soon!</a></li>", "");
			comSec = comSec.replaceAll("After selling out our initial phase|<h2>Paseo del Rio \\| Now Selling<", "");
//			U.writeMyText(html + comSec);
			String propStatus = U.getPropStatus(html + comSec);

			if (countOfMoveInHomes > 0) {
//			U.log("moveInAvail="+moveInAvail);
//			if(moveInAvail>0) {
				if (propStatus != ALLOW_BLANK) {
					propStatus = propStatus + ", Move-In Ready Homes";
				} else {
					propStatus = "Move-In Ready Homes";
				}
			}
			 U.log("propStatus: "+propStatus);
			
//			if(url.contains("/community/volterra/")||url.contains("y/estrella-del-norte/"))geo="TRUE";

			
			
			
//			if(url.contains("https://twilighthomesnm.com/community/tierra-del-oro/"))propStatus="Phase I Selling Out";
//			if(url.contains("https://twilighthomesnm.com/community/mariposa-urban/")) {
//				add[2]="NM";
//				propType="Luxury Homes";
////				propStatus="Move-In Ready Homes";
//			}
			if(url.contains("https://twilighthomesnm.com/community/mountain-hawk/")) {
				add[3]="87144";
				//propStatus =propStatus+", ";
			}
			//if(url.contains("/community/mariposa/"))geo="True";
			if(url.contains("community/joya-escondida/"))minPrice="$200,000";
			if(url.contains("https://twilighthomesnm.com/community/tierra-contenta")) {comName="Tierra Contenta";}
//			if(url.contains("https://twilighthomesnm.com/community/volterra/"))propStatus="Move-In Ready Homes";

//	
//			if(url.contains("tierra-contenta")) {
//				add[0]="";
//				add[1]="Santa Fe";
//				add[2]="NM";
//				add[3]="";
//				
//				latLng=U.getlatlongGoogleApi(add);
//				add=U.getAddressGoogleApi(latLng);
//				geo="True";
//			//propStatus="Coming Soon, Limited Homes Available";
//			}
			
//			if(url.contains("mariposa-urban")) {
//				add[0]="6055 Redondo Sierra Vista NE";
//				add[1]="Rio Rancho";
//				add[2]="NM";
//				add[3]="87144";
//				
//				latLng=U.getlatlongGoogleApi(add);
//			//	add=U.getAddressGoogleApi(latLng);
//				geo="False";
//			//propStatus="Coming Soon, Limited Homes Available";
//			}
			
			
//if(url.contains("https://twilighthomesnm.com/community/mariposa-urban/")) {	propStatus="Move-In Ready Homes";}
//			if(url.contains("https://twilighthomesnm.com/community/estrella-del-norte/")) {maxPrice="$378,990";
//			comName="Estrella Del Norte";
//			
//			}
//			if(url.contains("/lavender-fields/"))propStatus="Now Selling";
//			if(url.contains("https://twilighthomesnm.com/community/estrella-del-norte/"))maxSqFt="378,990";
//			if(url.contains("https://twilighthomesnm.com/community/volterra/"))propStatus="Quickly Selling Out, "+propStatus;
			String dType = "1 Story";
if(url.contains("joya-escondida/")||url.contains("community/cielo-azul/")||url.contains("community/la-potencia/"))dType = ALLOW_BLANK;
			
			if(url.contains("https://twilighthomesnm.com/community/tierra-contenta")) {dType = ALLOW_BLANK; propStatus =propStatus.replace("Coming Soon, ", "")+", Now Selling";}
//			if(url.contains("https://twilighthomesnm.com/community/lavender-fields/")) propStatus=propStatus+", Phase I sold out, Phase II coming soon, Move in ready homes";
			
			if(url.contains("https://twilighthomesnm.com/community/tierra-contenta"))propStatus="Now Selling";
			propStatus=propStatus.replace("New Homes Coming Soon, Coming Soon", "Coming Soon");

			
			
			data.addCommunity(comName, url, comType);
			data.addAddress(add[0].replace("&amp;", "&").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addSquareFeet(minSqFt, maxSqFt);
			data.addPrice(minPrice, maxPrice);
			data.addPropertyType(propType, dType);
			data.addPropertyStatus(propStatus.replace("Ii", "II"));
			data.addNotes(notes);
			data.addUnitCount(ALLOW_BLANK);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		i++;
	}

	private String extractMoveInReadyHomes() throws Exception {
		String html = U.getHTML("https://twilighthomesnm.com/move-in-ready/");
		U.log("Urls: "+builderURL + "/move-in-ready/");
		String paginationSection = U.getSectionValue(html, "<a class=\"noHover\"", "<");
		String[] pagingUrls = U.getValues(paginationSection, "href=\"", "\"");
		for (String pagingUrl : pagingUrls) {
			if (pagingUrl.length() < 2)
				continue;
			html += U.getHTML(pagingUrl);
		}
		return html;
	}
}