/**
 * @author Pallavi
 * @date 21/8/2021
 * 
 */
package com.shatam.b_325_353;

import com.shatam.utils.CommunityLogger;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;
public class ElevateHomes extends AbstractScrapper{
	String BASEURL="https://www.elevate-homes.com";
	public ElevateHomes() throws Exception {
		super("Elevate Homes", "https://www.elevate-homes.com/");
		LOGGER = new CommunityLogger("Elevate Homes");
	}

	CommunityLogger LOGGER;

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		AbstractScrapper a = new ElevateHomes();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Elevate Homes.csv", a.data().printAll());
	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		String mainHtml = U.getHTML("https://www.elevate-homes.com/locations/?state=ALL");
		String comSecs[] = U.getValues(mainHtml, "<div class=\"row community-lis", "Learn More <i class=\"fa fa-angle-right\"");
		U.log(comSecs.length);
		for(String com: comSecs) {
			String comUrl = BASEURL+U.getSectionValue(com, "data-url=\"", "\"");
			addDetails(comUrl,com);
		}
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		U.log("Communtiy Url: "+comUrl);
		
//		if(!comUrl.contains("https://www.elevate-homes.com/communities/?id=214"))return;
		//Community Name
		LOGGER.AddCommunityUrl(comUrl);
		String comName = U.getSectionValue(com, "<h6 class=\"text-white\">", "<");
		comName =comName.toLowerCase().trim();
		U.log("Community Name: "+comName);
		
		//Html 
		String comHtm = U.getHTML(comUrl);
		
		//Address and latlong 
		String[] add={ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo = "FALSE";
		String addSec = U.getSectionValue(com, "<p>Locations: <span>", "</span></p>");
		add =U.getAddress(addSec);
		
		//latLang
		String latlong[]={ALLOW_BLANK,ALLOW_BLANK};
		latlong[0]=U.getSectionValue(comHtm, " data-coord_x = \"", "\"");
		latlong[1]=U.getSectionValue(comHtm, "data-coord_y = \"", "\"");
		
		if(add[0]==null || add[0].length()<2) {
			add = U.getAddressGoogleApi(latlong);
			geo="True";
		}
		
		U.log("Address: "+Arrays.toString(add));
		U.log("Latlng: "+Arrays.toString(latlong));
		
		//HomesData =====
		String homesData = ALLOW_BLANK;
		String allHomesData[] = U.getValues(comHtm, "<div class=\"col-lg-6 col-xl-4\">", "<i class=\"fa fa-angle-up\"");
		for(String home:allHomesData) {
			String homeurl=BASEURL+U.getSectionValue(home, "<a href=\"", "\""); 
			String homeHtm = U.getHTML(homeurl);
			homesData += U.getSectionValue(homeHtm, "<div class=\"container-fluid menu-margin\">", "INTERACTIVE FLOOR PLANS");
		}
		//quickDeliveryHomes
		String quickHomes=ALLOW_BLANK;
		String quickHomesData[] = U.getValues(comHtm, "<div class=\"row no-margin quick-delivereis-item", ">VIEW DETAILS");
		for(String home:quickHomesData) {
			home = home.replaceAll("<a href=\"/quick-deliveries\">", "");
			String homeurl=BASEURL+U.getSectionValue(home, "<a href=\"", "\"");
		//	U.log(homeurl);
			String homeHtm = U.getHTML(homeurl);
			quickHomes += U.getSectionValue(homeHtm, "<div class=\"container-fluid menu-margin\">", ">REQUEST DETAILS");
		}
		
		//Prices 
		com = com.replace("0s", "0,000");
		U.log(com);
		comHtm = comHtm.replace("0s", "0,000").replace("0S", "0,000").replace("s							</p>", ",000");
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price = U.getPrices(homesData +comHtm+com+quickHomes , 
				"THE UPPER \\$\\d+,\\d+|from the \\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}|price\">\\$\\d{3},\\d{3}|MID \\$\\d{3},\\d{3}",
				0);
		minPrice = price[0]!=null ? price[0] : ALLOW_BLANK;
		maxPrice = price[1]!=null ? price[1] : ALLOW_BLANK;
		U.log("minPrice: "+minPrice+"\tmaxPrice: "+maxPrice);
		
		//sqFt 
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft = U.getSqareFeet(homesData +comHtm+com+quickHomes, 
				"\\d,\\d{3}-\\d,\\d{3} sq. ft.|\\d,\\d{3} - \\d,\\d{3} sq. ft.|Almost \\d,\\d{3} Sq. Ft|\\d{4} Sq Ft|\\d,\\d{3} SQ FT",
				0);
		minSqf = sqft[0]!=null ? sqft[0] : ALLOW_BLANK;
		maxSqf = sqft[1]!=null ? sqft[1] : ALLOW_BLANK;
		U.log("minSqf: "+minSqf+"\t maxSqf: "+maxSqf);
		
		
		String testimonial=U.getSectionValue(comHtm, "TESTIMONIALS</h3>", "<ol class=\"carousel-indicators\">");
		if(testimonial!=null)
			comHtm=comHtm.replace(testimonial, "");
		
		//CommuntiyType
		String cType = U.getCommunityType((comHtm+com).replace(" Waterfront Park</p>", ""));
		
		U.log("cType: "+cType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comHtm+com, "[\\s\\w\\W]{30}waterfront[\\s\\w\\W]{30}", 0));
		
		//PropertyStatus
		comHtm = comHtm.replace("<b>HOMES READY NOW</b><", "");
		String comHtm1=comHtm;
		String remv=U.getSectionValue(comHtm1,"<b>FLOOR PLANS</b>","SITE PLAN");
		if(remv!=null) {
			U.log("Hello");
			comHtm1=comHtm1.replace(remv,"");
		}
		
		String propStatus = U.getPropStatus((comHtm1+com).replace("<p>Chick-Fil-A (coming soon)", "").replace("<span>Coming Soon - By Appointment</span></p>", "").replace("<span>Coming Soon - By Appointment</span>",""));
		propStatus=propStatus.replace("Quick Move-in", "Quick Move Ins");//.replace("Coming Soon Early 2022, Coming Soon", "Coming Soon Early 2022");
//		U.log("JJJJJj"+Util.matchAll(comHtm1+com,"[\\w\\W\\s]{40}coming soon[\\w\\W\\s]{40}", 0));
		
		U.log("propStatus: "+propStatus);
		
		//PropertyType
	//	U.log("JJJJJj"+Util.matchAll(homesData +comHtm+com+quickHomes,"[\\w\\W\\s]{40}Farmhouse[\\w\\W\\s]{40}", 0));
		homesData=homesData.replace("Second-Floor","");
		comHtm = comHtm.replace("Offering villas and single family new homes", "");
		String proptype =U.getPropType((homesData +comHtm+com+quickHomes).replace(" taste of luxury", " taste of luxury home").replaceAll("img_03-Virtuoso_Farmhouse-DUSK.jpg|\"IsCondo\"|_Patio_Doors_", ""));
		U.log("proptype: "+proptype);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(homesData +comHtm+com+quickHomes, "[\\s\\w\\W]{30}flex[\\s\\w\\W]{30}", 0));
		//derivedPropType
		String dproptype =U.getdCommType((homesData +comHtm+com+quickHomes).replaceAll("first floor", "story 1 "));//First-Floor
		U.log("dproptype: "+dproptype);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(homesData +comHtm+com+quickHomes, "[\\s\\w\\W]{30}floor[\\s\\w\\W]{30}", 0));
		//adding quick delivery status
		if(quickHomes.contains("<a href=\"/quick-deliveries") && !propStatus.contains("Quick")) {
			if(propStatus.length()<3)propStatus="Homes Ready Now";
			else propStatus=propStatus+", Homes Ready Now";
		}
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"------------repeated");
			return;
		}
		
		
		if(!cType.contains("55+ Community"))
		{
			if(cType.length()>0) {
				cType=cType+", 55+ Community";
			}
			else
				cType="55+ Community";
				
		}
		
		
		LOGGER.AddCommunityUrl(comUrl);
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0], add[1].trim(), add[2].trim(), add[3]);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(latlong[0].trim(), latlong[1].trim(), geo);
		data.addPropertyType(proptype, dproptype);
		data.addPropertyStatus(propStatus);
		data.addNotes(U.getnote(comHtm+com));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);
	}

}