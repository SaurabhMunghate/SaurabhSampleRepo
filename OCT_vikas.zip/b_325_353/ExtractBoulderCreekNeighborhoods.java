package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractBoulderCreekNeighborhoods extends AbstractScrapper {
	CommunityLogger LOGGER;
	public ExtractBoulderCreekNeighborhoods() throws Exception {
		super("Boulder Creek Neighborhoods", "https://livebouldercreek.com/");
		LOGGER = new CommunityLogger("Boulder Creek Neighborhoods");
	}
	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractBoulderCreekNeighborhoods();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Boulder Creek Neighborhoods.csv", a.data().printAll());

	}
	
	@Override
	protected void innerProcess() throws Exception {

		String regHtml=U.getHTML("https://livebouldercreek.com/our-neighborhoods/");
		String regSec=U.getSectionValue(regHtml, "<a href=\"/our-neighborhoods\">Explore all neighborhoods</a>", "  <li class=\"home-finder\">");
		String[] comSecs=U.getValues(regSec, " <li>", " </li>");
		U.log(comSecs.length);
			for(String comSec:comSecs) {
				//U.log(comSec);
				String commName="";
				String comurl=U.getSectionValue(comSec, "<a href=\"", "\"");
				commName=U.getSectionValue(comSec, "\">", "<");
			
				U.log(comurl+" name: "+commName);
			comSec=comSec.replaceAll("0k", "0,000").replace("5k", "5,000").replace("$1.3m", "$1,300,000");
//				try {
					addDetails(comurl,commName,comSec);
//				} catch (Exception e) {}
			}
			addDetails("https://livebouldercreek.com/homes/superior-co/rogers-farm/", "Rogers Farm", "Sold Out");
		LOGGER.DisposeLogger();

	}
	private void addDetails(String comUrl, String comName, String comSec) throws Exception {
		// TODO Execute for single community
		//when execution the programs gives an exception then plz execute it again ....  

//		if(!comUrl.contains("https://livebouldercreek.com/homes/thornton-co/riverdale-ranch-opportunities/")) return;
		
		// ----------------- Community Url-----------------------
		U.log("communityURL=====> "+comUrl);
		
		if (comUrl.contains("https://livebouldercreek.com/homes/superior-co/rogers-farm/")) {
			LOGGER.AddCommunityUrl("-------page not found-------" + comUrl);
			return;
		}

		String comHtml = U.getHTML(comUrl);
//		if(comHtml!=null)
		comHtml=U.getSectionValue(comHtml, "<div id=\"content\" class=\"content\"><main>", "<div class=\"organism popular-neighborhoods\">");
		
		// ----------------- Community Name-----------------------
		comName=comName.replace(" Opportunities", "").replaceAll("®|[i|I]n.*|\\s{2,}|\n", " ").replace("Ranch", "");
		U.log("comName=====> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		//====================================Note ======================================
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				String[] cityState= {ALLOW_BLANK,ALLOW_BLANK};
				
				if(comHtml.contains("<h4>Address</h4>")) {
				String addressSec=U.getSectionValue(comHtml, "<h4>Address</h4>", "/a>").replace("1270 Lanterns Lane<br>", "1270 Lanterns Lane").replace("<br>", ",").replace("Sold Out", "");  //.replaceAll("1270 Lanterns Lane\r\n\\s*Rock Creek,", "1270 Lanterns Lane Rock Creek,-,")
//				U.log(addressSec);
				String address=U.getSectionValue(addressSec, ">", "<");
				U.log("add: "+address);
				add=U.getAddress(address);
				latLong[0]=Util.match(addressSec, "\\d{2,3}.\\d{5,}");
				latLong[1]=Util.match(addressSec, "-\\d{2,3}.\\d{5,}");
				
				}
				else if(comHtml.contains("http://www.google.com/maps/place")) {
					//getting address from latlong
					String geoSec = U.getSectionValue(comHtml, "http://www.google.com/maps/place/", "\"");
					U.log("geoSec: "+geoSec);
					
					String[] geoSplit = geoSec.split(",");
					latLong[0] = geoSplit[0];
					latLong[1] = geoSplit[1];
					
					U.log("Latlong from here ::"+Arrays.toString(latLong));
				}
				
				
				else {
					String cityStateSec=U.getSectionValue(comHtml, " <div class=\"header\">", "</header>");
					String citystate=U.getSectionValue(cityStateSec, "<h3>", "</h3>");
					cityState=citystate.split(",");
					add[1]=cityState[0];
					add[2]=cityState[1];
					
					U.log("Address ===== ::"+Arrays.toString(add));
					
					latLong=U.getGoogleLatLngWithKey(add);
					add=U.getGoogleAddressWithKey(latLong);
					add[0]=add[0].replace("JDC", "Jdc");
					geo="True";
					note="Address taken from city and state";
				}
				if((add[1]==ALLOW_BLANK && add[2]==ALLOW_BLANK)||add[0]==ALLOW_BLANK && latLong[0]!=ALLOW_BLANK) {
					add=U.getGoogleAddressWithKey(latLong);
					geo="true";
				}
				U.log("Address ::"+Arrays.toString(add));
				U.log("Latlong ::"+Arrays.toString(latLong));
				

//				U.log("Note========>:::"+note);
				//------------------Available Home Data-----------------------
				
				String homeData="";
				String homeSec="";
				String collSec="";
				comHtml=comHtml.replace("0k<span class=\"lowercase\">", "0,000<span class=\"lowercase\">");
//				U.log(comHtml);
				String[] homeUrls= {};
				String home="";
				try {
					homeSec=U.getSectionValue(comHtml, "</div><div class=\"section tabbed-product-listings\" id=\"product-listings", "  </section>");
					
					homeSec=homeSec.replace("</div>\r\n" + 
							"    </a>\r\n" + 
							"</li>", "</div></a></li>");
//					U.log(homeSec);
					
					homeUrls=U.getValues(comHtml, "<li class=\"product-item plans\">", "</li>");
					U.log(homeUrls.length);
					int c=0;
					for(String homeCollSec:homeUrls) {
						c++;
//						
						collSec+=homeCollSec;
						String homeUrl=U.getSectionValue(homeCollSec, " <a href=\"", "\"");
						U.log(c+"== "+homeUrl);
//						homeData+=U.getHTML(homeUrl);
						homeData=U.getHTML(homeUrl);
						homeData=U.getSectionValue(homeData, "<div class=\"body\" itemprop=\"articleBody\">", "</section>").replace("$1.4m", "$1,400,000");
						home+=homeData;
//						homeData=homeData.replace("$1.4m", "$1,400,000").replace("0k</span>", "0.000</span>").replace("5k", "5,000");    //.replace(U.getSectionValue(homeData, "<div class=\"neighborhoods\">", "</div><!--neighborhoods-->")+U.getSectionValue(homeData, "<h2 id=\"\" class=\"icon icon-our-neighborhoods\">Our Neighborhoods</h2>", "<li class=\"home-finder\">"), "")
					}
					}
					catch(NullPointerException e) {}
					home=home.replace("$1.4m", "$1,400,000").replace("0k</span>", "0,000</span>").replace("5k", "5,000");
//					U.log("== "+home);
//					U.log(comSec);
					
					String quickData=ALLOW_BLANK;
					try {
					String quickUrl=U.getSectionValue(comHtml, "<ul class=\"product-listing container\">", "<div class=\"price\">");
					if(quickData!=null) {
						quickUrl=U.getSectionValue(quickUrl, "<a href=\"", "\">");
						if(quickUrl!=null) {
							quickData=U.getHTML(quickUrl);		
							quickData=U.getSectionValue(quickData, "<h1 class=\"plan-meta-name\">", " <h2>Lifestyle Features</h2>");
						}
					}
					}catch (Exception e) {
						// TODO: handle exception
					}
					if(quickData==null) {
						quickData=ALLOW_BLANK;
					}
					
					// ----------------- Community Sqft-----------------------
					String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
					String[] sqft = U.getSqareFeet(comHtml+home+collSec, "\\d+\n\\s*<div class=\"label\">SQ.FT.</div>|<span> \\d{3} sq. ft.</span>|<li>\\d{4} – \\d{4}|\\d{4} sq. ft|\\d{4} sq. ft.|<li>\\d{4} � \\d{4}", 0);
					minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
					maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
					U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
//					U.log("mmmmmm"+Util.matchAll(comHtml+home+collSec, "[\\w\\s\\W]{100}1152[\\w\\s\\W]{100}", 0));

					
					// ----------------- Community Price-----------------------
					String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
					
//					comHtml = comHtml.replace("PRICED FROM $445K", "PRICED FROM $445,000");
					comHtml=comHtml.replaceAll("Priced from $455k", "Priced from $445,000");
//					U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}\\$455[\\w\\s\\W]{100}", 0));
					String price[] = U.getPrices((comHtml.replace("k<span class=\"lowercase\">s|k", ",000")+home+comSec), "from \\$\\d+,\\d+|Priced from \\$\\d+,\\d+|price\">\n\\s*\\$\\d+,\\d+|HOMES FROM \\$\\d{3},\\d{3}|Priced at </span> \\$\\d{3},\\d{3}|from \\$\\d{3},\\d{3}\r\n\\s+</span>|<span> \\$\\d{3},\\d{3}</span>|from \\$\\d{3},\\d{3}<span class=\"lowercase\">|<span> \\$\\d{3},\\d{3}</span>|\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}</span>", 0);  //|Starting From \\$\\d{3},\\d{3}
					minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
					maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
					U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
				
//					U.log("mmmmmm"+Util.matchAll(comSec, "[\\w\\s\\W]{100}\\$455[\\w\\s\\W]{100}", 0));
				
					// ----------------- Community Data-----------------------
					String propType = ALLOW_BLANK;
					String propStatus = ALLOW_BLANK;
					String drvPropType = ALLOW_BLANK;  
					String commType = ALLOW_BLANK;
					
					//============================================ Property Type =========================================================================
					comHtml = comHtml.replace(" traditional housing ", " traditional layout ").replace("Challenge the traditional, and", "");
					propType=U.getPropType((quickData+comHtml+home).replace("Paired Patio Home", "Patio, Paired Home"));
//					U.log("mmmmmm"+Util.matchAll(quickData, "[\\w\\s\\W]{100}pair[\\w\\s\\W]{100}", 0));
					
					U.log("PType========>:::"+propType);
					
					//=========== Community Type ========================
//					comHtml=comHtml.replace("", "");
					commType = U.getCommType(comHtml);
					
					U.log("commType========>:::"+commType);
					//============================================ dProp Type =========================================================================
					drvPropType=U.getdCommType(comHtml+home+collSec);
		
					U.log("PdrvType========>:::"+drvPropType);
					
					//====================================Property Status ======================================
					comHtml=comHtml.replaceAll("<h4>Hours</h4>\\s+<p>\\s+Coming Soon", "")
							.replaceAll("class=\"product-status\">\\s*Almost Sold Out|duct-status\">\\s*Coming Soon| <div class=\"product-status\">\n\\s*Sold Out\n\\s*</div>|<div class=\"product-status\">\n\\s*Now Open|Coming soon to|<div class=\"product-status\">\r\n\\s+\\w+\\s\\w*\\s*\\w*\\s*\\w*\r\n\\s+</div>", ""); 
					
					propStatus=U.getPropStatus((comHtml+comSec).replace("<h3>Coming soon to Broomfield", "").replace("different is coming soon to the East", ""));

//					U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{50}coming soon[\\w\\s\\W]{50}", 0));
//					U.log(Util.matchAll(comSec, "[\\w\\s\\W]{30}sold[\\w\\s\\W]{30}", 0));

					if(comUrl.contains("https://livebouldercreek.com/homes/broomfield-co/baseline/"))
		
					comName="Baseline";

					U.log("PStatus========>:::"+propStatus);
//					if(comUrl.contains("bouldercreek.com/homes/denver-co/wee-cottage-at-north-end/"))add[0]="Bannock St";		
					comName=comName.replace(" wee-Cottage", "");
					// ----------------- Community Data-----------------------
					data.addCommunity(comName, comUrl, commType);
					data.addLatitudeLongitude(latLong[0], latLong[1], geo);
					data.addPrice(minPrice, maxPrice);
					data.addAddress(add[0], add[1], add[2], add[3]);
					data.addSquareFeet(minSqft, maxSqft);
					data.addPropertyType(propType, drvPropType);
					data.addPropertyStatus(propStatus);
					data.addNotes(note);	
					data.addUnitCount(ALLOW_BLANK);
					data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
				
				
				
				
	}

	

}