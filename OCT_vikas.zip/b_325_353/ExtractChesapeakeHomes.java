package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.bouncycastle.crypto.tls.AlertLevel;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractChesapeakeHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;

	public ExtractChesapeakeHomes() throws Exception {

		super("Chesapeake Homes", "https://www.cheshomes.com/");
		LOGGER = new CommunityLogger("Chesapeake Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractChesapeakeHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Chesapeake Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		
		String mainHtml=U.getHTML("https://www.cheshomes.com/");
		//String regMainSec=U.getSectionValue(mainHtml, "<ul aria-labelledby=\"dropdownone\" class=\"dropdown-menu mt-0\">", "</a></div></div></div>");
		String regMainSec=U.getSectionValue(mainHtml, "<ul aria-labelledby=\"dropdownone\" class=\"dropdown-menu mt-0\">", "</ul>");
		Set<String> s=new HashSet<String>();
		String regUrls[]=U.getValues(regMainSec, "href=\"/new-homes", "\"");
		for(String regU:regUrls) {
			s.add(regU);
		}
		
		for(String ru:s) {
			
			String regUrl="https://www.cheshomes.com/new-homes"+ru;
			U.log("regUrl ::"+regUrl);
			String regHtml=U.getHTML(regUrl);
			String comSections[]=U.getValues(regHtml, "\"col-12 col-lg-11 p-lg-0\">", "View Community");
			for(String comSec:comSections) {
				String comUrl="https://www.cheshomes.com"+U.getSectionValue(comSec, "<a href=\"", "\"");

				addDetails(comUrl, comSec);
				
			}
		}
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comUrl, String comSec) throws Exception {
		
		//TODO:
//     if(!comUrl.contains("https://www.cheshomes.com/new-homes/va/hampton/h2o/5969/")) return;

		
//		String comHtml=U.getHTML(comUrl);
		String comHtml=U.getPageSource(comUrl);
        U.log(comUrl+"========================="+j);
		
		String comName=U.getSectionValue(comSec, "<span class=\"h4\">", "</span>");
		U.log(comName);
		
		
		
		LOGGER.AddCommunityUrl(comUrl);	
		
	//================================address section================================================
		
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		comHtml=comHtml.replaceAll("<h4>\\s*Address\\s*</h4>", "<h4>Address</h4>");
		String addressSec=U.getSectionValue(comHtml, "<h4>Address</h4>", "</div>");
		U.log(addressSec);
		if(addressSec!=null) {
		addressSec=addressSec.replace("<br/>", ",");
		U.log(addressSec);
		add=U.getAddress(addressSec);
		}
		latlag[0]=U.getSectionValue(comSec, "data-latitude=\"", "\"");
		latlag[1]=U.getSectionValue(comSec, "data-longitude=\"", "\"");
		
		
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log(geo);
		
		int qcount=0, underConstr=0;
		
		String combinedData="";
		try {
			comHtml=comHtml.replaceAll("</div>\\s*</div>\\s*</a>", "endssec");
			comHtml=comHtml.replaceAll("</div>\\s*</a>\\s*</div>\\s*</div>", "endssec");

	//		U.log(comHtml);
			String floorAndQuickSection[]=U.getValues(comHtml, "<div class=\"col py-2 px-3 p-lg-2\">", "endssec");
		//	String floorAndQuickSection[]=U.getValues(comHtml, "<div class=\"col py-2 px-3 p-lg-2\">", "  </div>\n\\s*</a>\n </div>\n</div>");
			
			String quickSec=U.getSectionValue(comHtml, "<p class=\"font-weight-bold mt-4 mb-0\">", "<h3 class=\"section\">");
//			U.log(quickSec);
			String quickHomes[]=U.getValues(quickSec, "<div class=\"col py-2 px-3 p-lg-2\">", "</a>");
			if(quickHomes!=null) {
				qcount=quickHomes.length;
			}
			for(String comboData:floorAndQuickSection) {
//				U.log("Homes:  "+comboData);
				//qcount++;
				if(comboData.contains("Under Construction")||comboData.contains("Estimated Completion"))
					underConstr++;
				String dataurl = "https://www.cheshomes.com/"+U.getSectionValue(comboData, "<a href=\"", "\"");
				U.log("Homes Url "+dataurl);
				combinedData+=comboData+ U.getSectionValue(U.getHTML(dataurl) , "<section class=\"location", "<h3 class=\"section\"><u>Photos");
			}
		}
		catch(NullPointerException ne) {
			U.log(ne);
		}
		
//		String[] floorPlansLink=U.getValues(comHtml, "<div class=\"card-body text-center\">", "</span></div></div></a>");
//		U.log(floorPlansLink.length);
		String floorData=ALLOW_BLANK; 
		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/hampton/h2o/5969/")) {
				floorData=U.getHTML("https://www.cheshomes.com/new-homes/va/hampton/h2o/the-huron/89951/");			
		}
//		if(floorPlansLink.length>0) {
//			for(String floorUrlSec:floorPlansLink) {
//				String Floorurls=U.getSectionValue(floorUrlSec, " href=\"", "\">");
//				if(Floorurls!=null) {
//					U.log("Floor Urls ::"+Floorurls);
//					floorData+=U.getHTML(Floorurls)+floorUrlSec;
//				}
//			}
//		}
		
//		if(combinedData==null)combinedData=ALLOW_BLANK;
		//U.log(combinedData);
	//============================prices=============================
      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		
      String comdesc=U.getSectionValue(comHtml, "col-12 col-lg-7 col-xl-8 text-center text-lg-left", "read-more less");
      if(comdesc!=null) {
      comdesc=comdesc.replace("0's", "0,000").replace("$600s", "$600,000");
      }
      else {
    	  comdesc=ALLOW_BLANK;
      }
      
     // U.log(comSec);
    //U.log("*****"+Util.matchAll((comHtml+combinedData+comSec), "[\\w\\W\\s]{40}1,109[\\w\\W\\s]{40}", 0));
      
		prices=U.getPrices(comSec+combinedData+comdesc, "\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}|From \\$\\d{3},\\d{3}", 0);
		
		U.log(Arrays.toString(prices));
		
		//============================sqft-========================================
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		comHtml = comHtml.replace(" 7,000 sq. ft. recreation", "");
		sqft=U.getSqareFeet(floorData+comSec+combinedData+comHtml, "\\d,\\d{3} square feet|\\d,\\d{3}-\\d,\\d{3} square feet|\\d,\\d{3} - \\d,\\d{3} Sq. Ft.|up to \\d,\\d{3} square feet|>\\s*\\d,\\d{3} Sq Ft|\\d{1},\\d{3} Sq. Ft.|\"sq-ft\">\\d{1},\\d{3}", 0);
		
		U.log(Arrays.toString(sqft));
		
		
		
		String cType=U.getCommType(comHtml).replace(",Resort Style", ", Resort Style");
		U.log(cType);
		
		
		String pType=ALLOW_BLANK;
		
//		U.log(Util.matchAll(comSec+combinedData+comHtml , "[\\w\\s\\W]{10}1500[\\w\\s\\W]{10}", 0));
		pType = U.getPropType((comSec+comdesc).replaceAll("villages|Village|Farmhouse and Coastal Designs|Coastal South Carolina|Coastal Virgina","").replace("provide luxury","luxury homes").replace("with luxury upgrades", "luxury homes")+combinedData.replaceAll("– Single Family Homes|-single-family-", ""))
				.replace(",Cottage", ", Cottage")
				.replace(",Detached Home", ", Detached Home")
				.replace(",Luxury Homes", ", Luxury Homes")
				.replace(",Villas", ", Villas")
				.replace(",Courtyard Home", ", Courtyard Home")
				.replace(",Townhome", ", Townhome")
				.replace(",Patio Homes", ", Patio Homes")
				.replace(",Villas", ", Villas")
				.replace(",Courtyard Home", ", Courtyard Home")
				.replace(",Farmhouse Style Homes", ", Farmhouse Style Homes");
		U.log(Util.matchAll(comSec+comdesc+combinedData , "[\\w\\s\\W]{10}cottage[\\w\\s\\W]{10}", 0));
		if(comUrl.contains("https://www.cheshomes.com/new-homes/sc/little-river/bridgewater-waterside-village-one/7818/"))
		{
			pType="Bungalow Homes, Coastal Style Homes, Single Family, Cottage, Luxury Homes, Courtyard Home";
		}
		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/suffolk/river-club/7441/"))
		{
			pType="Loft";
		}
		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/suffolk/the-preserve-at-lake-meade/6202/"))
		{
			pType="Loft";
		}
		
		
		if(comUrl.contains("https://www.cheshomes.com/new-homes/sc/myrtle-beach/waterbridge/7454/"))
		{
			pType="Loft, Cottage, Coastal Style Homes";
		}
		if(comUrl.contains("https://www.cheshomes.com/new-homes/sc/little-river/bridgewater-waterside-village-two/5769/"))
		{
			pType="Single Family, Loft, Cottage, Townhome, Luxury Homes, Coastal Style Homes";
		}
		if(comUrl.contains("https://www.cheshomes.com/new-homes/sc/little-river/bridgewater-portside-village/5771/"))
		{
			pType="Single Family, Loft, Cottage, Luxury Homes, Coastal Style Homes";
		}
		if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/clayton/kyli-knolls/7082/")) {
			pType="Single Family, Patio Homes, Loft";
		}
		U.log("pType::::::" + pType);
		// ============================dproptype=================================
		String dType = ALLOW_BLANK;
		
		dType = U.getdCommType((comHtml+combinedData).replaceAll("[F|f]loor", "")).replace(",2 Story", ", 2 Story");;
		U.log("dType::::::" + dType);
//		U.log(Util.matchAll(comHtml+combinedData, "[\\w\\s\\W]{30}3 story[\\w\\s\\W]{30}", 0));

		// =======================propertyStatus===================================

		String pStatus = ALLOW_BLANK;
	//	U.log("*****"+Util.matchAll((comHtml+ comSec), "[\\w\\W\\s]{40}coming soon[\\w\\W\\s]{40}", 0));
		comHtml=comHtml.replace("Phase Two Coming Summer of 2021", "Phase Two Coming Summer 2021");
		pStatus = U.getPropStatus((comSec+comHtml).replaceAll("<div class=\"avail-banner\">\n\\s*Coming Soon!\n\\s*</div>", "")
				.replace("\">Limited Pre-Sell Lots Now Available!</div>", "")
				.replaceAll("limited opportunities to have a basement home|top-left\">\\s*Coming Soon|Additional Homes Coming Soon|Information Coming Summer 2021|Pricing Coming Soon!|top-left\">\\s*Now Available", ""));
	
		U.log("status:::::::" + pStatus);
		U.log(Util.matchAll(comSec+comHtml, "[\\w\\s\\W]{90}lots now[\\w\\s\\W]{90}", 0));
		
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/virginia-beach/ashville-park/6964/"))
//		{
//			pStatus="Coming Soon";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/raleigh/5401-north/5975/"))
//		{
//			pStatus="Coming Soon, Coming Early 2022";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/moyock/waterleigh/5962/"))
//		{
//			pStatus="Next Phase Coming Early 2022";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/moyock/waterleigh/5962/"))
//		{
//			pStatus=pStatus+", More Opportunities Coming Soon";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/virginia-beach/kingston-estates/5955/"))
//		{
//			pStatus="Three Opportunities Available, Quick Move-in Homes, Final Phase";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/suffolk/the-preserve-at-lake-meade/6202/"))
//		{
//			pStatus="Three Opportunities Available, Quick Move-in Homes";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/cary/shadow-creek/5974/"))
//		{
//			pStatus="Quick Move-in Homes";
//		}
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/sc/myrtle-beach/waterbridge/7454/"))
//		{
//			pStatus="Quick Move-in Homes";
//		}
		
		U.log("q count="+qcount);
		U.log("undr="+underConstr);
		pStatus=pStatus.replaceAll(", Quick Move-in Homes|, Quick Move-in|Quick Move-in|quick move-in homes|Quick Move-in Homes, |, Quick Move-in Homes|Quick Move-in Homes", "");
		
		if(qcount>underConstr) {
			if(pStatus.length()<4 && !pStatus.contains("Move-in Homes")) {
				pStatus="Quick Move-in Homes";
			 }
			else {
				pStatus=pStatus+", Quick Move-in Homes";
			}
		}
		if(pStatus.length()<=0) {
			pStatus=ALLOW_BLANK;
		}
		
		U.log("status:::::::" + pStatus);

		if (prices[0] == null)https://www.cheshomes.com/new-homes/va/virginia-beach/ashville-park/6964/
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;

		if(pStatus.contains("Quick Move-in") && !pStatus.contains("in Homes")) {
			pStatus=pStatus.replace("Quick Move-in", "Quick Move-in Homes");
		}
		if(add[0]==ALLOW_BLANK || add[0]==null) {
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		}
		if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/morrisville/myers-point/5973/")) {
			pStatus=pStatus.replace("Coming Soon, ", "");
		}
		
		if(pStatus.contains(", Homes Now Available")) pStatus = pStatus.replace(", Homes Now Available", "Homes Now Available");
		U.log("STATUS ============ " + pStatus);
		
		
		String noOfUnits=ALLOW_BLANK;
		if(comHtml.contains("Community Map")) {
			noOfUnits=getUnits(comHtml);
		}
		U.log("Number of units"+noOfUnits);
//		if(comUrl.contains("https://www.cheshomes.com/new-homes/va/virginia-beach/kingston-estates/5955/"))pStatus+=", Final Phase";
		
		//if(comUrl.contains("https://www.cheshomes.com/new-homes/nc/moyock/the-gables/5959"))pStatus="Final Opportunity Coming Soon";
		
		data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(U.getnote(comHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(noOfUnits);
		
		
		
		
		j++;
		U.log("==================================");
		
		
		
	}

	private String getUnits(String comHtml) {
		String lotData[]=U.getValues(comHtml, "<div class=\"position-absolute border rounded-circle", "</div>");
	  
		if(lotData!=null) {
		int lotCount=lotData.length;
	   String noOfUnits=Integer.toString(lotCount);
	   U.log("NO Of Units"+noOfUnits);
	   if(noOfUnits.equals("0"))
		   return ALLOW_BLANK;
	   else
		   return noOfUnits;
		}
		else
			return ALLOW_BLANK;
	}
	
	
}