package com.shatam.b_325_353;

import java.util.Arrays;
import java.util.HashSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCityVentures extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver=null;
	public ExtractCityVentures() throws Exception {

		
		super("City Ventures", "https://www.cityventures.com/");
		LOGGER = new CommunityLogger("City Ventures");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractCityVentures();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "City Ventures.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpChromePath();
		driver=new ChromeDriver();
		
//		U.setUpGeckoPath();//================
//		driver = new FirefoxDriver();//==================
		
		//HashSet <String> Ha=new HashSet<String>();
		String mainHtml=U.getHtml("https://www.cityventures.com/find-your-home/",driver);
	//	String comSections[]=U.getValues(mainHtml, "\"home-box\"", "home-box__links");
	/*	String comSections[]=U.getValues(mainHtml, "<div class=\"home-box__info\"", "home-box__links");*/
//		String northCarolina=U.getSectionValue(mainHtml, "<h4 class=\"desktop-submenu__title\">Northern California</h4>","<div style=\"justify-content: initial;\">");
//		String comSections1[]=U.getValues(northCarolina,"<div>","</div>");
//		U.log("Comm in north car"+comSections1.length);
//		String southCarolina=U.getSectionValue(mainHtml, "<h4 class=\"desktop-submenu__title\">Southern California</h4>","<h4 class=\"desktop-submenu__title\">Coming Soon</h4>");
//		String comSections2[]=U.getValues(southCarolina,"<div>","</div>");
//		U.log("Comm in south car"+comSections1.length);
//		String commingsoonCom=U.getSectionValue(mainHtml, "<h4 class=\"desktop-submenu__title\">Coming Soon</h4>","<div class=\"desktop-submenu--col3\">");
//		String comSections3[]=U.getValues(commingsoonCom,"<div>","</div>");
//		String url=ALLOW_BLANK;
//		String name=ALLOW_BLANK;
		
//		String mainSec=U.getSectionValue(mainHtml,"<div class=\"desktop-submenu__wrap\">","<div class=\"desktop-submenu--col3\">");
		String urlsN[]=U.getValues(mainHtml, "<h2 class=\"section__title text-uppercase\"","Learn More</p>");
		//String name[]=U.getValues(mainSec, "<a style=\"display:inline-block;", "a>");
		//for(String url:urls) {
		U.log("Total comm"+urlsN.length);
			for(String names:urlsN) {
				String urlSec = U.getSectionValue(names, "\">", "</h2>");
				String url= "https://www.cityventures.com"+U.getSectionValue(names, "<a class=\"section__link\" href=\"","\"");
				String name=U.getSectionValue(names, "\">", "<");
//				
//				
//				if(url==null ||  name==null)continue;
//				U.log(name+"\t--\t"+url);
//				U.log("-----------"+url);
				//U.log("---------comsec: --"+names);
				addDetails(url,name,mainHtml,names);
			}
			driver.quit();
			LOGGER.DisposeLogger();
		}
	
	//	U.log("Total comm"+urlsnName.length);
//		for(String urlName:urlsnName) {
//			String name=U.getSectionValue(urlName, "\">","</a>");
//			String url=U.getSectionValue(urlName, " href=\"","\">");
////			for(String comSec:comSections) {
////				if(comSec.contains(name)) {
////					addDetails(url,name,comSec);
////				}
//				//else
//					addDetails(url,name,mainHtml);
//			}
					
		
//		
//		for(String Sec1:comSections1) {
//			 url=U.getSectionValue(Sec1,"href=\"","\"");
//			 U.log("jjjj"+url);
//			//url="https://www.cityventures.com/"+url;
//			 name=U.getSectionValue(Sec1, "\">", "</a>");
//			 U.log("name1"+name);
//			for(String comSec:comSections) {
//				U.log("JJJJJJJJJJJJJJ");
//				U.log(comSec.contains(url));
//				if(comSec.contains(url)) {
//					U.log("Hiiiii");
//					if(url!=null&&name!=ALLOW_BLANK) {
//						U.log("Hello");
//                //   addDetails(url,name,comSec);
//                   
//					}
//				}// else
//			}  
//			if(url!=null&&name!=ALLOW_BLANK)
//			addDetails(url,name,ALLOW_BLANK);
//		}
//		for(String Sec2:comSections2) {
//			 url=U.getSectionValue(Sec2, "href=\"","\"");
//			 U.log(url);
//			//url="https://www.cityventures.com/"+url;
//			name=U.getSectionValue(Sec2, "\">", "</a>");
//			U.log("name2"+name);
//			for(String comSec:comSections) {
//				if(comSec.contains(url)) {
//					if(url!=null&&name!=ALLOW_BLANK)
//                   addDetails(url,name,comSec);
//                   //else
//				}
//				if(url!=null&&name!=ALLOW_BLANK)
//                	addDetails(url,name,ALLOW_BLANK);
//			}
//			
//		}
//		
//		for(String Sec:comSections3) {
//		       url=U.getSectionValue(Sec, "<a href=\"","\"");
//		       U.log(url);
//			//url="https://www.cityventures.com/"+url;
//			 name=U.getSectionValue(Sec, "\">", "</a>");
//			 U.log("name3"+name);
//			 if(url!=null&&name!=ALLOW_BLANK)
//			addDetails(url,name,ALLOW_BLANK);
//		}
//		
		//String comUrls[]=U.getValues(mainHtml, "<a style=\"display:inline-block;\"", "/a>");
//		for( int i=0;i<comSections.length-1;i++) {
//			
//			addDetails(comUrls[i],comSections,driver);
//		}
	//	for(String comSec:)
//		driver.quit();
//		LOGGER.DisposeLogger();
//	}
//	
//	public void addDetails(String comSec1,String []comSections,WebDriver driver) throws Exception {
	public void addDetails(String comUrl,String name,String mainHtml,String comsec) throws Exception {	
		
//	    try {
		U.log(comUrl);

		String halfUrl=comUrl;
		comUrl=comUrl;//+U.getSectionValue(comSec1, "href=\"", "\"");
		if(data.communityUrlExists(comUrl)){
			LOGGER.AddCommunityUrl(comUrl+"repeated**********");
			return;
		}
        
        		
		
//		if(comUrl.contains("https://www.cityventures.com/new-homes/ca/la-mesa/parkridge/9891/")) return;
		
		//Single run
//		if(!comUrl.contains("https://www.cityventures.com/new-homes/ca/palmdale/skyridge-at-joshua-ranch/9894/"))return;
		U.log("count==="+j);
		U.log("comUrl==="+comUrl);
		U.log("name"+name);
		name=name.replace("- ", "");
		
		U.log("comsec==="+comsec);
//		String comSec=ALLOW_BLANK;
		String comHtml=U.getHTML(comUrl);
//		name=name.replace("- Ascend","Ascend");
//		
//		if(comUrl.contains("https://www.cityventures.com/community/parkridge/")) name="La Mesa - Parkridge";
		//====================================address==================================================
		String note=U.getnote(comHtml);
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		String addSection=ALLOW_BLANK;
//		U.log("html"+comHtml.length());
//	    addSection=U.getSectionValue(comHtml, ">MODELS &amp; SALES OFFICE ADDRESS", "</p></div>");
		String addSec=U.getSectionValue(comHtml, ">MODELS &amp; SALES OFFICE ADDRESS", "</p></div>")
				.replace("</p><p>", ", ")
				.replace("By Appointment Only ", "")
				.replace(", Commerce CA", ", Commerce, CA ").replace("9873 MacArthur Bvld, Unit F", "9873 MacArthur Bvld Unit F,");
		addSec=addSec.replace(".,", ",").replace("By Appointment Only", "");
		U.log("===addSec===="+addSec);
		if(addSec!=null) {
			addSec=U.getNoHtml(addSec);
//			add=U.getAddress( addSec);
		}
		
		if(comUrl.contains("https://www.cityventures.com/community/parkridge/")) {
			addSection=U.getSectionValue(comHtml, "MODELS & SALES OFFICE ADDRESS", "/p>");
			addSec=U.getSectionValue(addSection, "<p>", "<").replace("9873 MacArthur Bvld, Unit F", "9873 MacArthur Bvld Unit F,");
			U.log(addSec);
		}
		
		if(comUrl.contains("https://www.cityventures.com/community/reserve/")) {
			add[0]="2433 Francisco Ave";
			add[1]="Santa Rosa";
			add[2]="CA";
			add[3]="95403";
		}
		
		
		
		if(comHtml.contains("lat:")) {
			
			latlag[0] = U.getSectionValue(comHtml, "lat:", ",").trim();
			latlag[1] = U.getSectionValue(comHtml, "lng:", "}").trim();
			
		}
		else {
			String latlng=U.getSectionValue(comHtml, "<a class=\"text__box\" href=\"//maps.google.com/maps?q=", "\"");
			if(latlng!=null)
			{
				latlag=latlng.split(",");
			}
		}
		add=U.getAddress(addSec);
		
		if(comUrl.contains("https://www.cityventures.com/new-homes/ca/santa-rosa/grove-village/10996/")) {
			add[1]="Santa Rosa";
			add[2]="CA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			note="Address And Latlong Taken From City And State";
			geo="TRUE";
			
		}
		
		U.log("latlag===="+Arrays.toString(latlag));
		
		if(latlag[0]==null ||latlag[0] == ALLOW_BLANK) {
			latlag=U.getlatlongGoogleApi(add);
		geo="TRUE";//secD
		}
//		if(comUrl.contains("https://www.cityventures.com/community/skyridge-at-joshua-ranch/")) {
//			add[1]="Los Angeles";
//			add[2]="CA";
//			U.log("Hello");
//			latlag=U.getlatlongGoogleApi(add);
//			U.log(Arrays.toString(latlag));
//			add=U.getAddressGoogleApi(latlag);
////			latlag[0]="34.052235";
////			latlag[1]="-118.243683";
//			geo="TRUE";
//		}
		
//		if(comUrl.contains("https://www.cityventures.com/community/rosewood/")) {
//			add[0]="5615 Jillson St";
//			add[1]="Commerce";
//			add[2]="CA";
//			add[3]="90040";
//			geo="TRUE";
//		}
//		U.log("addressSec======"+add[1].length());
		
		
		
		
		//======builder contact page 
		U.log("LLLLLLLLLLLL==="+addSec);
		String contactHtml=U.getHTML("https://www.cityventures.com/contact/");
		if(contactHtml!=null) {
			String[] addressSec=U.getValues(contactHtml, "<div class=\"box\">", "</div>");
			for(String a : addressSec) {
				if(add[0].length()<2 && add[1].length()<2) {
					if(a.contains(comUrl)) {
						U.log("addressSec======"+a);
						addSec=U.getSectionValue(a, "<a target=\"_blank\"  href=\"https://maps.google.com/?q=", "\">");
						add=U.getAddress(addSec);
					}
				}
			}
		}
				
		
		
//		U.log("LLLLLLLLLLLL==="+addSec);
		
		
		
		
		U.log("add====="+Arrays.toString(add));
		U.log("latlag===="+Arrays.toString(latlag));
		
		if(add[0].length()>2 && add[1].length()>2 && latlag[0].length()<5) {
			latlag=U.getlatlongGoogleApi(add);
			geo = "TRUE";
		}
		
		if(add[3]==ALLOW_BLANK && latlag[0]!=ALLOW_BLANK) {
			add[3]= U.getAddressGoogleApi(latlag)[3];
			geo = "TRUE";
		}
		
		
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			U.log(Util.matchAll(comsec, "[\\w\\s\\W]{30}From the \\$800[\\w\\s\\W]{30}",0));//secD=comSec

	    //  secD=secD.replace("From Low $1 Million", "$1,000,000");
	      comHtml=comHtml.replace("From Low $1 Million", "$1,000,000");
	     // U.log("SECCCCC"+comSec);
	      comsec=comsec
	    		  .replace("From the $800,000s", "From the $800,000").replace("0s", "0").replace("From the High $800,000 to Low $1 M","From the High $800,000 to Low $1,000,000" );
			prices=U.getPrices(comHtml+comsec,"From the \\$\\d{3},\\d{3}|From the High \\$\\d{3},\\d{3} to Low \\$\\d,\\d{3},\\d{3}|From The Mid \\$\\d{3},\\d{3}|From The Low \\$\\d{3},\\d{3}|From The High \\$\\d{3},\\d{3}s|From The Low \\$\\d{3},\\d{3}s|From \\$\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);//secD

			U.log(Arrays.toString(prices));
			
			//============================sqft-========================================
			
//			U.log("ComSec"+comSec);
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			//secD
			sqft=U.getSqareFeet(comHtml+comsec,"\\d{4} Sq Ft|<p>\\d,\\d{3} – \\d,\\d{3} Sq. Ft.</p>|<p>\\d,\\d{3}-\\d,\\d{3} Sq. Ft.</p>|Approx. \\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3} SQUARE FEET|Approx. \\d{1},\\d{3} – \\d{1},\\d{3} Sq. Ft|\\d{1},\\d{3} SQUARE FEET |Up to \\d,\\d{3} SQUARE FEET|\\d{1},\\d{3} - \\d{1},\\d{3} Square Feet|Up to \\d{1},\\d{3} Sq. Ft.|\\d{1},\\d{3} - \\d{1},\\d{3} Sq. Ft.", 0);
			
			
			
			U.log(Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comHtml);//secD
			U.log(cType);
			
			
			String pType=ALLOW_BLANK;
			if(comsec!=null)
				comsec=comsec.replace("HOA dues", "")
						.replace("<p>Single Family Estates</p>", "<p>Single Family Estate Residences</p>");
			
			comHtml=comHtml.replaceAll("-patio-|[O|o]ccupation", "").replace("Innovative flex spaces feature", "Innovative flex room spaces feature")
					.replace("growing families, multi-gens, and everyone", "growing families, multi-generational living, and everyone")
					.replace("technology, and classic farmhouse design in an idyllic", "technology, and classic farmhouse style design in an idyllic")
					.replace("ideal for growing families, multi-gens, and everyone in between", "ideal for growing families, multi-generation living, and everyone in between");
			
			pType = U.getPropType((comHtml+comsec));//secD

			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			comHtml=comHtml.replaceAll("Sandstone at Joshua Ranch|joshua-ranch/\"|joshua-ranch/\">|Virtual tours Joshua ranch|Joshua ranch|Joshua Ranch", "");
			dType = U.getdCommType((comHtml+comsec));//secD
		//	U.log(Util.matchAll(comSec+comHtml, "[\\w\\s\\W]{30}Ranch[\\w\\s\\W]{30}",0));//secD=comSec
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;
//            U.log("NNNNN"+Util.matchAll((comSec+comHtml),"[\\w\\W\\s]{30}Coming Soon[\\w\\W\\s]{30}",0));
			pStatus = U.getPropStatus((comsec+comHtml).replaceAll(". With quick move-in opportunities|<h2 class=\"section__title \" style=\"color:#B4B05A\">Now Open and Selling - Register to Stay in the Know.</h2>|<p>Pricing Coming Soon</p>|<p class=\"footer__box__title\">COMING SOON</p>|<h4 class=\"desktop-submenu__title\">Coming Soon</h4>|<p class=\"footer__box__title\">NOW SELLING</p>|INFO CENTER NOW OPEN|Info Center Now Open|<h4 class=\"desktop-submenu__title\">Coming Soon</h4>",""));
//			if(comSec!=ALLOW_BLANK) {
//				if(pStatus!=ALLOW_BLANK)  pStatus+=", Now Selling";
//				else pStatus="Now Selling";
//			}
//			pStatus=pStatus.replace("Coming Soon, ", "");
//			if(comUrl.contains("https://www.cityventures.com/community/edgewood-point/"))
//				pStatus="Coming Soon, Now Selling";
//			
			//
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
            
			name = name.replace("La Mesa - ", "").replace(add[1], "").replace(" — ", "");
			
			if(comUrl.contains("https://www.cityventures.com/community/stony-village")) {
				//name="Stony Village";
			add[3]="95403";
			}
			
			if(comUrl.contains("https://www.cityventures.com/community/fox-hollow/") || comUrl.contains("https://www.cityventures.com/community/reserve/"))
			{
				if(pType!=null)
				{
					pType +=", Loft";
				}
				else
					pType ="Loft";
			}
			
			name=name.replace("OaklandBlossom", "Blossom");
			
					
			LOGGER.AddCommunityUrl(comUrl);
			
			
//			=========================================================================
			
//			String mapLink_sec=U.getSectionValue(comHtml, "<iframe id=", "</iframe>") ;
//			if(mapLink_sec!=null) {
			String lotcount=ALLOW_BLANK;
			String[] lotdata=null;
				String mapLink=U.getSectionValue(comHtml, "iframe class=\"oi-aspect-target\" src=\"", "\"></iframe>") ;
				U.log("mapLink==="+mapLink);
				if(mapLink!=null) {
					String mapHtml=U.getHtml(mapLink,driver);
//					if(mapHtml!=null) {
//						String[] lotdata=U.getValues(mapHtml, "<g id=\"lot", "</g>") ;
//						if(lotdata.length>0) {
//							lotcount=Integer.toString(lotdata.length);
//
//						}
//					}
					lotcount=Util.getUnits(mapHtml);
				}
				
				if(lotcount.equals("0")) {
					lotcount=ALLOW_BLANK;
				}
				U.log("lotcount=="+lotcount);
//			}
				
			
			
			
			
			
			
			
			
			
			
			data.addCommunity(name.replace("� ", "").replace("&#x27;s", " &").toLowerCase(), comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			data.addUnitCount(lotcount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			
			
			
			j++;
			
//	}catch(Exception e) {}
	    
	}
	
	
	}

