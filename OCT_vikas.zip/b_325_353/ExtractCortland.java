package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map.Entry;

import org.bouncycastle.crypto.tls.AlertLevel;
import org.json.JSONArray;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractCortland extends AbstractScrapper {
	String BASEURL="https://cortland.com";
	String builderName="Cortland ";
	CommunityLogger LOGGER;
    WebDriver driver;


	public ExtractCortland() throws Exception {
		super("Cortland","https://cortland.com");
		
		LOGGER = new CommunityLogger("Cortland");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractCortland();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Cortland.csv", a.data().printAll());
	}


	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		
		U.setUpChromePath();
		driver=new ChromeDriver();
//		
		String mainHtml=U.getHTML("https://cortland.com");
//		String ComSection=U.getSectionValue(mainHtml, "Explore Other Cortland Apartment Communities Near You</h2>", "<div class=\"nearby-communities__nav-page-count\">");
//	    String comSecs[]=U.getValues(ComSection, "<div class=\"nearby-communities__header\">", "<span>Explore Community </span>");
//	    
//	    for(String comSec:comSecs) {
//	   //  U.log(comSec);
//	    // U.log("=========================");
//	     String comUrl=U.getSectionValue(comSec, "<span href=\"", "\"");
//	     comUrl="https://cortland.com"+comUrl;
//	     U.log("Ccom url:: "+comUrl);
//	     String comName=U.getSectionValue(comSec, "<h3 class=\"nearby-communities__name corp-heading\">", "</h3>");
//	     U.log("comBName:: "+comName);
//	     
		String mainJsonSec=U.getSectionValue(mainHtml, "<script>var rawCacheData = ", "</script>");
		JsonParser parser=new JsonParser();
		Object Obj=parser.parse(mainJsonSec);
		JsonObject commsJsonObj = (JsonObject)Obj;
		
		JsonObject properties=commsJsonObj.get("properties").getAsJsonObject();

		U.log("TOTAL:: "+properties.entrySet().size());
		
		Iterator itr=properties.entrySet().iterator();
		
		while(itr.hasNext()) {
			//U.log(itr.next());
		//	JsonObject commJsonObj = (JsonObject) itr.next();
		//	U.log(commJsonObj);
			Object object=itr.next();
			String strngobj=object.toString();
			strngobj=strngobj.replaceAll("=", ":");
		//	U.log(strngobj);
			//JsonObject commJsonObj =parser.parse(strngobj).getAsJsonObject();
			
			//String comUrl="https://cortland.com/apartments"+U.getSectionValue(strngobj, "name"", "")
				
		   String name=U.getSectionValue(strngobj, "\"name\":\"", "\"");
		   U.log("name: "+name);
		   if(name!=null) {
			   
			   name = name.replace("<sup>®</sup>", "").replaceAll(" 55\\+ Active Adult Living$", "");
			   name=U.getNoHtml(name);
		   }
		   
		   String comUrl="https://cortland.com/apartments/"+U.getSectionValue(strngobj, "\"slug\":\"", "\",");
		   U.log("ComURL:: "+comUrl);
		
//		   try {
			   addDetails(comUrl,name,strngobj, parser);
//		   } catch (Exception e) {}
		}
		
		
		
		//addDetail(comUrl,comName,comSec);
	    
	 //   }
		
		driver.quit();
		LOGGER.DisposeLogger();
	}

 int j=0;




	private void addDetails(String comUrl, String comName, String comSec, JsonParser parser) throws Exception {
		// TODO Auto-generated method stub
	
//		if(!comName.contains("Cortland West Plano")) return;
//		if(!comUrl.contains("https://cortland.com/apartments/providence-in-the-park")) return;
		U.log("Count::"+j+" comUrl::"+comUrl);
//		U.log(comSec);
	//	if(j>=50 && j<=100)
//		if(j>=180 && j<=186)
//		if(j>=170 && j<=200)
	//	if(j>=11 && j<=50)
	  if(j > 200) 	
	//	try		
		{
			
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		if(comUrl.contains("https://cortland.com/apartments/cortland-alameda-station")||comUrl.contains("https://cortland.com/apartments/highland-lake-apartments")) {
			LOGGER.AddCommunityUrl("-------Redirecting-------" + comUrl);
			return;
		}
       if(comUrl.contains("https://cortland.com/apartments/cortland-cassiobury")){
    	   LOGGER.AddCommunityUrl("-------England Address-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);

		String html=U.getHTML(comUrl);
		String comHtml = html;
		String statusFromComHtml=U.getHtmlSection(html, "<div class=\"homepage__rotator-title\">", "</div>");
		if(statusFromComHtml==null) {
			statusFromComHtml=ALLOW_BLANK;
		}
		U.log(U.getCache(comUrl));
		
		html = U.getSectionValue(html, "</head>", "</body>");
		//U.log(amenityUrl);
		//U.log(amenHtml);
		
//		U.log(""+comNAme);
		
//		String floorHtml = U.getSectionValue(html, "<script>var preload =", "</script>");
		String floorHtml = U.getSectionValue(comHtml, "<script>var preload =", "</script>");
		
		
		String[] remove = U.getValues(html, "<script>", "</script>");
		for(String rem:remove) {
			
			if(html != null) html = html.replace(rem, ""); 
				
		}
		
		
		
		
		
		
		
		
		String add[]= {ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK,ALLOW_BLANK};
		String geo="False";
		String latlong[]={ALLOW_BLANK,ALLOW_BLANK};
		
		String addSec=U.getSectionValue(html, "Find Us</span>", "</a>");
		U.log("addSec: "+addSec);
		//addSec=U.getNoHtml(addSec);
		//U.log(addSec);
		if(addSec != null) {
			addSec=addSec.replace("445 S Saulsbury St, Unit A and B", "445 S Saulsbury St,");
		}
		
		addSec=U.getNoHtml(addSec).trim();
		//U.log("1 "+addSec);
		add=U.getAddress(addSec.replace("\n", ","));
		//U.log("2 "+addSec);
		add[0] = add[0].replace(",", "").replace("Cañada", "Canada"); 
		
		U.log("ADDRESS:: "+Arrays.toString(add));
		
		String latlongSec=U.getSectionValue(html, "\"GeoCoordinates\",", "},");
		U.log(latlongSec);
		if(latlongSec!=null) {
			latlong[0]=U.getSectionValue(latlongSec, "\"latitude\":\"", "\",");
			latlong[1]=U.getSectionValue(latlongSec, "\"longitude\":\"", "\"");
		}else {
			latlong[0]=U.getSectionValue(latlongSec, "\"lat\":\"", "\",");
			latlong[1]=U.getSectionValue(latlongSec, "\"lng\":\"", "\"");
		}
		
		U.log("LatLOng:: "+Arrays.toString(latlong));
		
		//--------------- For Number of Units --------------------
		String noOfUnit = ALLOW_BLANK;
		String floorHtml2=ALLOW_BLANK;
		JsonArray homes=null;
		String homeData=ALLOW_BLANK;
	
		String floorPlanSec=U.getSectionValue(html, " data-event-label=\"Home\"", "data-event-label=\"Floor Plans\"");
//		U.log(floorPlanSec);
		
		if(floorPlanSec!=null) {
			String floorPlanUrl=U.getSectionValue(floorPlanSec, "href=\"", "\"");
			
			U.log("FLoor Plan Url:: "+floorPlanUrl);
			floorHtml2=U.getHtml(floorPlanUrl,driver);
			
			if(floorHtml2.contains("Site Map")) {
				
				homes=getUnits(floorHtml2,parser);
				if(homes!=null) {
				int lotCount=homes.size();
				noOfUnit=Integer.toString(lotCount);
				for(int i=0;i<homes.size();i++) {
					JsonObject obj2=homes.get(i).getAsJsonObject();
					 homeData+=obj2.toString();
				
				}
				}
				if(noOfUnit.equals("0"))
					noOfUnit=ALLOW_BLANK;
				
			}
			
			U.log("noOfUnit :::"+noOfUnit);
			
			
			//home data from sight map for sqfts
			
			
		}
//		if(floorHtml ==null) floorHtml = ALLOW_BLANK;
//		String remSec=U.getSectionValue(floorHtml, "Currently Unavailable Floor Plans", "<div class=\"floorplan-modal__wrapper\"");
//		if(remSec!=null)
//          floorHtml=floorHtml.replace(remSec, "");
//		
//		floorHtml = U.getSectionValue(floorHtml, "<script>var preload =", "</script>");
		
		
	
		
		/*if(floorHtml != null) {
			JsonObject property = (JsonObject) parser.parse(floorHtml);
		
			
			for(Entry<String, JsonElement> obj : property.entrySet()) {
				if(obj.getKey().equals("total_apartments")) {
					noOfUnit = obj.getValue().toString();
					break;
				}
			}
		} */
		;
		
		
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		String[] sqft= U.getSqareFeet(floorHtml+homeData, "\"display_area\":\"\\d{3} sq. ft.\"|\"display_area\":\"\\d,\\d{3} sq. ft.|\"square_feet\":\\d{3,4},", 0);	
		minSqf = sqft[0]!=null ? sqft[0] : ALLOW_BLANK;
		maxSqf = sqft[1]!=null ? sqft[1] : ALLOW_BLANK;
		U.log("minSqf: "+minSqf+"\t maxSqf: "+maxSqf);
		
//		U.log(">>>>>>>>>>>>"+Util.matchAll(floorHtml+homeData, "[\\s\\w\\W]{30}1362[\\s\\w\\W]{30}", 0));
//		FileUtil.writeAllText("/home/shatam-10/Desktop/data/html.txt", floorHtml);
		
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		String[] price=U.getPrices(floorHtml+comSec, "\\$\\d{3},\\d{3}", 0);
		
		minPrice = price[0]!=null ? price[0] : ALLOW_BLANK;
		maxPrice = price[1]!=null ? price[1] : ALLOW_BLANK;
		U.log("minPrice: "+minPrice+"\tmaxPrice: "+maxPrice);
		
		String amenitiesUrlSec=U.getSectionValue(html, "data-cta-target=\"2\">", "</span>");
		if(amenitiesUrlSec==null) {
			amenitiesUrlSec=U.getSectionValue(html,"Go Beyond Wellbeing</h2>", "</span>");
			if(amenitiesUrlSec==null) {
				amenitiesUrlSec=U.getSectionValue(html, "data-cta-target=\"1\">", "</span>");
			}
		}
		if(comUrl.contains("https://cortland.com/apartments/cortland-biltmore-place")||comUrl.contains("https://cortland.com/apartments/cortland-lakeyard-district")) {
			amenitiesUrlSec=U.getSectionValue(html, "data-cta-target=\"1\">", "</span>");
		}
	//	U.log("sEC::"+amenitiesUrlSec);
		String amenityUrl=U.getSectionValue(amenitiesUrlSec, "<a href=\"", "\" target=");
	//	U.log("RL:: "+amenityUrl);
		if(amenityUrl==null) {
			amenitiesUrlSec=U.getSectionValue(html, "data-cta-target=\"1\">", "</span>");
			 amenityUrl=U.getSectionValue(amenitiesUrlSec, "<a href=\"", "\" target=");
		}
		String amenHtml=U.getHTML(amenityUrl);
		amenHtml = U.getSectionValue(amenHtml, "</head>", "</body>");
		//U.log(amenityUrl);
		//U.log(amenHtml);
		remove = U.getValues(amenHtml, "<script>", "</script>");
		for(String rem:remove) {
			
			if(amenHtml != null) amenHtml = amenHtml.replace(rem, ""); 
				
		}
		
		html=U.getNoHtml(html);
		
		String cType = U.getCommunityType((html+comSec+amenHtml).replaceAll("name\":\"Lakefront|Lakefront [P|p]ool|Lakefront [A|a]partment|Lakefront Living at Cortland Mirror|--activeadult|label=\"55\\+ Active|>55\\+ Active Adult", ""));
		
		U.log("Comm Type"+cType);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+amenHtml, "[\\s\\w\\W]{30}Lakefront[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}Lakefront[\\s\\w\\W]{30}", 0));
		
		html = html.replaceAll(" - Coming|Salon Coming|HDTVs - Coming|Center Coming|Center\\s*-\\s*Coming|title=\"Coming|name\":\"Coming", "");
		
		comSec = comSec.replaceAll(" - Coming|Center Coming", "");
		
		String propStatus = U.getPropStatus(statusFromComHtml+html.replace("Coming this Fall!", "").replace("COMING SOON: Brand-New Fitness", "").replace("wait to see whats coming soon", "")+comSec);
		U.log("Prop Status"+propStatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(statusFromComHtml+html+comSec, "[\\s\\w\\W]{30}coming this[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}Coming Fall 2022[\\s\\w\\W]{30}", 0));
	
		String proptype =U.getPropType((html+amenHtml).replaceAll("Garden-Style Bathtubs|Creek-Villas|condolence|BallparkLofts|title=\"Industrial Loft|-lofts|Ballpark Lofts|score is the multifamily|alt=\"Luxury|content=\"Enjoy luxury|outdoor patio\"|title=\"Patio\"|[p|P]rivate [p|P]atio|[p|P]ersonal [p|P]atios", ""));
		U.log("proptype "+proptype);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}luxury apartment[\\s\\w\\W]{30}", 0));

//		U.log(">>>>>>>>>>>>"+Util.matchAll((html+amenHtml).replaceAll("title=\"Industrial Loft|-lofts|Ballpark Lofts", ""), "[\\s\\w\\W]{30}Loft[\\s\\w\\W]{30}", 0));
		
		
		if(html.contains("Explore Other Cortland Apartment Communities Near You") && html.contains("Browse Our Frisco Apartments for Rent")) {
			
			String removeit = U.getSectionValue(html, "Explore Other Cortland Apartment Communities Near You", "Browse Our Frisco Apartments for Rent");
			html = html.replace(removeit, "");
		}
		
		if(html.contains("<script src=\"https://js.adsrvr.org") && html.contains("</script>  <script>")) {
			
			String removeit = U.getSectionValue(html, "<script src=\"https://js.adsrvr.org", "</script>  <script>");
			html = html.replace(removeit, "");
		}
		
		String[] remove2 = U.getValues(html, "<script ", "</script>");
		for(String rem:remove2) {
			
			if(html != null) html = html.replace(rem, ""); 
				
		}
	
		//comSec.replace("Townhomes and Single-Story Floor", "").replace("Two-Story Fitness Center", "").replace("2-Story Fitness Cente", "").replace("story fitness center", "").replace("Two-story fitness center", "").replaceAll("-Story, 24/7|Cinco Ranch|cinco-ranch|Colonial Village|Green Valley Ranch|Story, 24/7 Fitness", "")  
		html=U.getNoHtml(html);
		String dproptype =U.getdCommType((html.replace("Two-Story Fitness Center", "").replace("Two-Story, 24\\/7 Fitness", "")+amenHtml).replaceAll("-Story, 24/7|Cinco Ranch|cinco-ranch|Colonial Village|Green Valley Ranch|name\":\"Two-|-Story Covered Parking|[f|F]loor|Walker Ranch|-Ranch|-ranch|drive to Arrowhead Ranch|Walker Ranch Apartment Homes Fitness|-ranch|[s|S]tory [F|f]itness|Cinco Ranch</h3>|[C|c]inco [R|r]anch|ranch|Ranch", ""));
		
		
		U.log("derived prop type:"+dproptype);

		U.log(">>>>>>>>>>>>"+Util.matchAll(comSec, "[\\s\\w\\W]{30}Single-Story[\\s\\w\\W]{30}", 0));
		U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}Single-Story[\\s\\w\\W]{30}", 0));
		U.log(">>>>>>>>>>>>"+Util.matchAll(amenHtml, "[\\s\\w\\W]{30}Single-Story[\\s\\w\\W]{30}", 0));
//		U.log(">>>>>>>>>>>>"+Util.matchAll(html+amenHtml, "[\\s\\w\\W]{30}colonial[\\s\\w\\W]{30}", 0));
		
		String note=U.getnote(html);
		U.log("note: "+note);
		
		
		
		
		
		
		data.addCommunity(comName, comUrl, cType);
		data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(),add[3].trim());
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addLatitudeLongitude(latlong[0], latlong[1],geo);
		data.addPrice(minPrice, maxPrice);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPropertyStatus(propStatus);
		data.addPropertyType(proptype, dproptype);
		data.addNotes(note);
		data.addUnitCount(noOfUnit);
		}
		j++;
	//	}
		//catch(Exception e) {};
}
	
	     JsonArray getUnits(String floorHtml2, JsonParser parser) throws Exception {

		  String siteMapSec = U.getSectionValue(floorHtml2, "<iframe class=\"lazy-load loaded\"", "</iframe>");
          if(siteMapSec==null)
        	  siteMapSec=U.getSectionValue(floorHtml2, "<iframe class=\"lazy-load\"", "</iframe>");
		  
		 if(siteMapSec!=null) {
			 
		  String siteMapUrl=U.getSectionValue(siteMapSec, "src=\"", "\">");
		  if(siteMapUrl==null)
			  siteMapUrl=U.getSectionValue(siteMapSec, "data-src=\"", "\"");
	    if(siteMapUrl!=null) {		
		  
		  String mapHtml=U.getHtml(siteMapUrl,driver);
		U.log("siteMapUrl :: "+siteMapUrl);
          U.log("Path: "+U.getCache(siteMapUrl));
          String siteUrlSec=U.getSectionValue(mapHtml,"window.__APP_CONFIG__ = {","}");
        //  U.log("SEC"+siteUrlSec);
          String siteUrl=U.getSectionValue(siteUrlSec, "\"href\":\"", "\"");
      //    U.log("URLLL:: "+siteUrl);
          siteUrl=siteUrl.replace("\\","");
          String siteMapHtml=U.getHTML(siteUrl);
          U.log("Path 2: "+U.getCache(siteUrl));
          
          JsonObject homeJs=(JsonObject) parser.parse(siteMapHtml);
          
          JsonArray homes=homeJs.get("data").getAsJsonObject().get("units").getAsJsonArray();
          int lotCount=homes.size();
          U.log("number of units"+lotCount);
          return homes;
	     }
	     }
       return null;   
          
         
	}
	
		

}