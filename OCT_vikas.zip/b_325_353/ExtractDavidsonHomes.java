package com.shatam.b_325_353;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import javax.management.monitor.CounterMonitorMBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractDavidsonHomes extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver;
	static int j = 0;

	public ExtractDavidsonHomes() throws Exception {

		super("Davidson Homes", "https://davidsonhomesllc.com/");
		LOGGER = new CommunityLogger("Davidson Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractDavidsonHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Davidson Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpChromePath();
//		driver =new ChromeDriver();
		ChromeOptions options = new ChromeOptions();
		options.addExtensions (new File("/home/shatam12/Downloads/Browsec-VPN-Free-and-Unlimited-VPN_v3.21.10.crx"));
		DesiredCapabilities capabilities = new DesiredCapabilities();
		 capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		 driver = new ChromeDriver(capabilities);
			Thread.sleep(10000);
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
//			Thread.sleep(2000);
		String mainHtml = U.getHTML("https://davidsonhomesllc.com/");
		
		U.log(U.getCache("https://davidsonhomesllc.com/"));

		String regUrls[] = U.getValues(mainHtml, "class=\"state-links__link\" href=\"", "\">");
		U.log("Total Regions: "+regUrls.length);
		
		for (String rsec : regUrls) {
			String regUrl = "https://davidsonhomesllc.com" + rsec;
//			U.log("regUrl: "+regUrl); 
			
			String regHtml = U.getHtml(regUrl, driver);
//			Thread.sleep(15000);
			String regSec=U.getSectionValue(regHtml, "class=\"search-results__col search-results__col--results search-results__col--results-active\"", "class=\"search-results__toggle-button search-results__togg");
			String comSections[] = U.getValues(regSec, "class=\"search-card search-card--animate search-card--community\"",
					"/p></div></div></div></div></div></a>");
			U.log("comSections.length: "+comSections.length);
			
			for (String comSec : comSections) {

				String comUrl = "https://davidsonhomesllc.com" + U.getSectionValue(comSec, "href=\"", "\">");
//				U.log("comUrl: "+comUrl);
//				try {
					addDetails(comUrl, comSec);
//				} catch (Exception e) {}

			}
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comUrl, String comSec) throws Exception {

//		try{
		
//============= SINGLE EXECUTION FROM HERE ===========		
//	 if(!comUrl.contains("https://www.holthomes.com/communities/gateway-landing-homes-for-sale-in-troutdale-or/"))return;
//		if(j>=31 && j<=40)
//		if(j>=20)
//		if(j>=3)
//			if(j>=30)
		{
		U.log("\n::::::::::::"+"COUNT = "+j+":::::::::::::\n");
		
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml = U.getHtml(comUrl, driver);
//		Thread.sleep(5000);
		String remm=U.getSectionValue(comHtml, "<h5 class=\"section__title\">Other communities", "<div class=\"footer");
		U.log(U.getCache(comUrl));
		if(remm!=null) {
			comHtml=comHtml.replace(remm, "");
		}
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
	
		// =============remove other community section

	//	String remSec = U.getSectionValue(comHtml, "OTHER COMMUNITIES", "</footer>");
		String remSec = U.getSectionValue(comHtml, "Other communities within 10 miles</h5>", "class=\"footer__button\">About US");
		if (remSec != null) {
			comHtml = comHtml.replace(remSec, "");
		}
        String rmsec[] = U.getValues(comHtml, "<script type=\"text/javascript\">", "</script>");
        for(String s:rmsec) {
        	
        	comHtml = comHtml.replace(s, "");
        }
		U.log(comUrl + "\n=========" + j);

		// ====================communityName==================

		String comName = U.getSectionValue(comHtml, "<h1 class=\"hero__title alt\">", "</h1>");
		U.log("comName: "+comName);

		// ====================address=======================

		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String addressSec = U.getSectionValue(comHtml, "<h2 class=\"hero__state\">", "</h2>");
//		U.log("addressSec: "+addressSec);
		String addSecUrls[] = U.getValues(addressSec, "/\">", "</a><span");
//		U.log("addSecUrls: "+addSecUrls.length);
		
		for(String sec:addSecUrls) {
//			U.log("sec: "+sec);
		}
		
		add[0] = ALLOW_BLANK;
		add[1] = addSecUrls[0];
		add[2] = addSecUrls[1];
		add[3] = ALLOW_BLANK;
		
		
		if(comUrl.contains("raleigh-market-area/four-oaks/beverly-place/"))
		{
//			String addressSec1 = U.getSectionValue(comHtml, "Model Address:", "</a>");
//			if(addressSec1==null)sec
			String	addressSec1 = U.getSectionValue(comHtml, "Model Address:", "</p>")
					.replace(" Four Oaks", ", Four Oaks").trim();
//			U.log("addressSec1==="+addressSec1);
//			addressSec1=U.getNoHtml(addressSec1);
			add=U.getAddress(addressSec1);
		}
		
		if(comUrl.contains("/nashville-market-area/murfreesboro/rivers-edge/"))
		{
			
			String addressSec1 = U.getSectionValue(comHtml, "Model Home Address:", "</p>");
			addressSec1=U.getNoHtml(addressSec1).replace("Murfreesboro", ", Murfreesboro");
			add=U.getAddress(addressSec1);
		}
		
//		if(comUrl.contains("/raleigh-market-area/four-oaks/beverly-place/"))
//		{
//			String addressSec1 = U.getSectionValue(comHtml, "<p>Model Address:", "</p>");
//			addressSec1=U.getNoHtml(addressSec1);
//			add=U.getAddress(addressSec1);
//		}
//		if(comUrl.contains("https://davidsonhomesllc.com/states/texas/houston-market-area/iowa-colony/sierra-vista/"))
//		{
//			add[0] = "10006 Whitney Reach Dr";
//			add[1] = "Rosharon";
//			add[2] = "TX";
//			add[3] = "77583";// from img
//		}
		
		//latlag section
		if(comHtml.contains("<a href=\"https://www.google.com/maps/dir")) {
			
			String geoSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
//			U.log("geoSec: "+geoSec);
			
			latlag = geoSec.split(",");
			U.log("LATLONG: "+Arrays.toString(latlag));
		}

		if(add[0] == ALLOW_BLANK && latlag[0] == ALLOW_BLANK) {
			
			latlag = U.getlatlongGoogleApi(add);
			add = U.getAddressGoogleApi(latlag);
			geo = "TRUE";
		}
		else if (add[0] == ALLOW_BLANK && latlag[0] != ALLOW_BLANK) {
			add = U.getAddressGoogleApi(latlag);
			geo = "TRUE";
		}
			

		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log("geo: "+geo);

		// ===================floorplansection===========================================

		String floorPlanUrl = comUrl + "#floorplan";
		U.log(floorPlanUrl);
		String floorplanHtml = U.getHTML(floorPlanUrl);
		floorplanHtml=U.removeSectionValue(floorplanHtml, "<section class=\"footer__middle\">", "</footer>");

		String remove = U.getSectionValue(floorplanHtml, "<h5 class=\"section__title\">Other communities", "</footer>");
		String allPlanData =ALLOW_BLANK;
				
		if(floorplanHtml!=null && remove!=null)floorplanHtml=floorplanHtml.replace(remove, "");
		String plans[] = U.getValues(comHtml, "<div class='properties-card__bottom'", "</a");
		for(String plan:plans) {
//			U.log(">>>>"+plan);
			String furl =U.getSectionValue(plan, "<a href=\"", "\"");
			if(furl==null)furl =U.getSectionValue(plan, "<a href=\'", "\'");
			String plan_Data= U.getHTML(furl);
			plan_Data=U.removeSectionValue(plan_Data, "<section class=\"footer__middle\">", "</footer>");
			allPlanData+=plan_Data;
//			allPlanData += U.getHTML(furl);
		}
		
		String [] myPlans=U.getValues(floorplanHtml, "<a class=\"button button--small\"", "More Details</a>");
		String allHomeData=ALLOW_BLANK;
		U.log("plans :: "+myPlans.length);
		for(String mPlan:myPlans) {
			String homeUrl=U.getSectionValue(mPlan, "href=\"", "\">");
//			U.log("home Url"+homeUrl);
			String homehtml=U.getHtml("https://davidsonhomesllc.com/"+homeUrl, driver);
			homehtml=U.removeSectionValue(homehtml, "<section class=\"footer__middle\">", "</footer>");
			
			String HomeData=U.getSectionValue(homehtml, "<main>", "</main>");
//			U.log(HomeData);
			String []removedata=U.getValues(HomeData, "<noscript", "</noscript>");
			U.log(removedata.length);
			if(removedata.length>0) {
				for(String remm1:removedata) {
					HomeData=HomeData.replace(remm1, "");
				}
				allHomeData+=HomeData;
			}
		}
		// ================= avaialable homessection

		String availHomeUrl = comUrl + "#availablehomes";
		U.log(availHomeUrl);
		String availplanHtml = U.getHTML(availHomeUrl);
		availplanHtml=U.removeSectionValue(availplanHtml, "<section class=\"footer__middle\">", "</footer>");

		 remove = U.getSectionValue(availplanHtml, "<h5 class=\"section__title\">Other communities", "</footer>");
		if(availplanHtml!=null && remove!=null )availplanHtml=availplanHtml.replace(remove, "");

//		========================================================
		int qick=0;
//		String quickSec=U.getSectionValue(comHtml, "<h5 class=\"section__title\">Quick Move-In homes", "");
		String [] quickHomes=U.getValues(comHtml, "class=\"community-gallery__status community-gallery", "More Details");
		U.log("quickHomes:: "+quickHomes.length);
		if(quickHomes.length>0) {
			for(String quickHome : quickHomes) {
				if(quickHome.contains("Move-In Ready") || quickHome.contains("Move In: June")) 
				{
					qick++;
				}
			}
		}
//		U.log("q:: "+qick);
		
		// =======================prices========================

		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		
//		U.log("KKKKk"+Util.matchAll(comHtml, "[\\w\\s\\W]{60}647,200[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(floorplanHtml, "[\\w\\s\\W]{60}647,200[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(availplanHtml, "[\\w\\s\\W]{60}647,200[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(comSec, "[\\w\\s\\W]{60}647,200[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(allHomeData, "[\\w\\s\\W]{60}647,200[\\w\\s\\W]{90}", 0));

		
		comHtml = comHtml
//				.replaceAll("$1.5Ms<!-- --> - $1.7Ms", "$1,500,000 - $1,7,00,000")
				.replaceAll("\\$1.5Ms", "\\$1,500,000")
				.replaceAll("\\$1.7Ms", "\\$1,700,000")
				.replace("offered on Conventional Conforming loans up to $647,200", "")
				.replace("&#36;", "$").replace("&#8208;", "-").replace("0s", "0,000");
//		U.log("KKKKk"+Util.matchAll(comHtml, "[\\w\\s\\W]{60}1.7M[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(comHtml, "[\\w\\s\\W]{60}1,700,000[\\w\\s\\W]{90}", 0));
		String com=U.getSectionValue(comHtml, "<section class=\"footer__middle\">", "</footer>");
		if(com!=null) {
			comHtml=comHtml.replace(com, "");
		}
		prices = U.getPrices(
				(comHtml + floorplanHtml + availplanHtml + comSec + allHomeData).replace("post_excerpt\": \"In Highland Forest, we’re offering gorgeous single-family homes starting in the high $200s", ""),
				"\\$\\d,\\d{3},\\d{3} - \\$\\d,\\d{3},\\d{3}|\\$\\d{1},\\d{3},\\d{3}|\\$\\d{3},\\d{3}|‐ \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}|high \\$\\d+,\\d+", 0);
		U.log("min "+prices[0]+" max "+prices[1]);	
		U.log(Arrays.toString(prices));

		// =================sqft==================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };

		sqft = U.getSqareFeet(comHtml + floorplanHtml + availplanHtml + comSec,
				"\">\\d{1},\\d{3}|>\\d{1},\\d{3} sq.ft<|\\d{1},\\d{3}</strong>", 0);
	
//		U.log("KKKKk"+Util.matchAll(comHtml, "[\\w\\s\\W]{60}1,849[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(floorplanHtml, "[\\w\\s\\W]{60}1,849[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll(availplanHtml, "[\\w\\s\\W]{60}1,849[\\w\\s\\W]{90}", 0));
//		U.log("KKKKk"+Util.matchAll( comSec, "[\\w\\s\\W]{60}1,849[\\w\\s\\W]{90}", 0));


		U.log(Arrays.toString(sqft));

		// ==================communitytype========================
		String cType = ALLOW_BLANK;

		String comDesc = U.getSectionValue(comHtml, "community-content__title-row", "community-content__right-half")
				+ U.getSectionValue(comHtml, "Community Features</button>", "</div>");
		comDesc=comDesc.replace("Lake features", "Lakeside Community");
	//	U.log("KKKKk"+Util.matchAll(comDesc + comSec, "[\\w\\s\\W]{60}gated[\\w\\s\\W]{90}", 0));
	//	U.log("Descri:: "+comDesc);
		cType = U.getCommType((comDesc + comSec).replaceAll("the Darden to Hasentree Golf Community", ""));

		if(comUrl.contains("https://davidsonhomesllc.com/states/alabama/huntsville-market-area/madison/laurenwood-preserve/"))
			cType="Lakeside Community";
			
			U.log("cType::::::" + cType);

		// ===================propertyType================================
		String pType = ALLOW_BLANK;
		
		pType = U.getPropType((comDesc + comSec+allPlanData+allHomeData).replaceAll("Village|village",""));
//			U.log("KKKKk"+Util.matchAll(comDesc + comSec, "[\\w\\s\\W]{60}Villa[\\w\\s\\W]{90}", 0));
//			U.log("KKKKk"+Util.matchAll(allPlanData+allHomeData, "[\\w\\s\\W]{60}Villa[\\w\\s\\W]{90}", 0));


		U.log("pType::::::" + pType);

		// ============================dproptype=================================
		String dType = ALLOW_BLANK;
		
		String comFeaturs = U.getSectionValue(comHtml, "", "");
//		U.log("SSS"+Util.matchAll(comDesc + comFeaturs + comSec+allPlanData+allHomeData,"[\\w\\W\\s]{100}10 foot ceilings on the second floor,[\\w\\W\\s]{50}",0));
		dType = U.getdCommType((comDesc + comFeaturs + comSec+allPlanData+allHomeData).replace("10 foot ceilings on the second floor", "10 foot ceilings on the second floor owner").replace("Features a media room on third level", ""));
		U.log("dType::::::" + dType);

		// =======================propertyStatus===================================

		String pStatus = ALLOW_BLANK;
//		comDesc = comDesc//.replace("quickly selling out our first phase", "quickly selling out first phase")
//				.replace("quickly selling out our first phase", "first phase selling out");
		
//		U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(comDesc, "[\\w\\s\\W]{60}Coming Soon[\\w\\s\\W]{90}", 0));
//		U.log(">>>>>>>>>>>>>>>>>>>>>>>>>>"+Util.matchAll(comSec+comDesc, "[\\w\\s\\W]{60}Coming-Soon[\\w\\s\\W]{90}", 0));

//		U.log(comDesc);
		
		comDesc = comDesc
				.replaceAll("Coming Soon:|walking trails and many more coming soon|walking trails and many more coming soon", "")
				.replace("New floor plans coming soon", "New plans coming soon")
				.replace("waterside homesite are available", "waterside homesite available").replace("Phase 2 is Now Open","Phase 2 Now Open");
		pStatus = U.getPropStatus((comDesc + comSec).replace("coming-soon", "Coming Soon").replaceAll("walking trails and many more coming soon|Acre Homesites Available|With additional quick move-in homes|After quickly selling out our first phase, we plan to build|Willow plans have limited availability|community__status--close-out'>|now selling our model home|And with quick move-in homes on t", ""));
//		
//		U.log("quick Count==="+qick);
		
		if(qick>0) {
			if(pStatus.length()>1) {
				pStatus+=", Quick Move-In Homes";
			}
			else
				pStatus="Quick Move-In Homes";
		}
		
		
//		U.log("status:::::::" + pStatus);

		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;

		String note = U.getnote(comHtml.replaceAll("XXXX MOCK LOT FOR SALES|schema.org/PreSale", ""));
		
		
		if (comUrl.contains(
				"https://davidsonhomesllc.com/states/north-carolina/raleigh-market-area/wake-forest/hasentree/")) {

			add[2] = "NC";
			add[3] = "27587";
		}
//		if (comUrl.contains("https://davidsonhomesllc.com/states/georgia/atlanta-market-area/cumming/cooper-place/"))
//			pStatus = "Phase 1 Sold Out, Phase 2 Coming Soon";// img

	
//		if(comUrl.contains("nashville-market-area/murfreesboro/rivers-edge/"))pStatus="New Phase Now Selling";
//		if(comUrl.contains("https://davidsonhomesllc.com/states/tennessee/nashville-market-area/murfreesboro/salem-landing/"))pStatus+=", New Floor Plans Coming Soon";
		if (comUrl.contains(
				"https://davidsonhomesllc.com/states/alabama/huntsville-market-area/new-market/flint-meadows/"))
			note = ALLOW_BLANK;
		
		//from image
//		if(comUrl.contains("https://davidsonhomesllc.com/states/alabama/huntsville-market-area/huntsville/jaguar-hills/")) pStatus ="New Phase Now Selling";
		if(pStatus!=null)
			pStatus = pStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		
		data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(note);
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		} 
		j++;
		
//	}	catch (Exception e) {}
	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("class=\"interactiveLot")) {
			
			ArrayList<String> pins = Util.matchAll(html, "class=\"interactiveLot", 0);
			U.log("Count Pins: "+pins.size());
			totalUnits = String.valueOf(pins.size());
			
		}
		
		return totalUnits;
	}
		
			
	
	
	

}