package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractFrontierCommunities extends AbstractScrapper {
	CommunityLogger LOGGER;
	private final static String BUILDER_URL = "https://www.fhcommunities.com";
	WebDriver driver;
	
	public ExtractFrontierCommunities() throws Exception {
		super("Frontier Communities", "https://www.fhcommunities.com/");
		LOGGER = new CommunityLogger("Frontier Communities");
	}

	@Override
	protected void innerProcess() throws Exception {
		
		U.setUpChromePath();
		driver=new ChromeDriver();
		String regHtml=U.getHTML("https://www.fhcommunities.com/communities/");
		regHtml=U.getSectionValue(regHtml, "<span class=\"fl-heading-text\">Now Selling</span>", "<footer");
//		U.log(regHtml);
		String[] comSecs=U.getValues(regHtml, "<h3 class=\"fl-heading\">", "<span class=\"fl-button-text\">");
//		U.log(">>>>>>>"+comSecs.length);
		for(String comSec:comSecs) {
//			U.log("***********\n"+comSec);
			String comurl=U.getSectionValue(comSec, "<div class=\"fl-button-wrap fl-button-width-auto fl-button-left fl-button-has-icon\">", " role=\"button\">");
			if(comurl!=null)comurl=U.getSectionValue(comurl, "href=\"", "\"");
			if(!comurl.contains("https://www.fhcommunities.com")) {
				comurl="https://www.fhcommunities.com"+comurl;
			}
			String commName=U.getSectionValue(comSec, "<span class=\"fl-heading-text\">", "<");
			U.log(comurl+" name: "+commName);
			addDetails(comurl,commName,comSec);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void addDetails(String comUrl, String comName, String comSec) throws Exception {
		// TODO Execute for single community
//		if(!comUrl.contains("https://www.fhcommunities.com/alicante/"))return;
		
		// ----------------- Community Url-----------------------
		U.log("communityURL====> "+comUrl);
		

		
		
		// ----------------- Community Name-----------------------
		U.log("comName===> "+comName);
		
		// ----------------- Community LOGGER-----------------------
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		if(comUrl.contains("https://www.fhcommunities.com/asher-ranch-iii/")) {
			comUrl="https://www.fhcommunities.com/asher-ranch/";
		}
		
		if(comUrl.contains("https://www.fhcommunities.com/stone-briar-ii/"))
			comUrl="https://www.fhcommunities.com/stone-briar/";
			
			LOGGER.AddCommunityUrl(comUrl);
		
//		U.log(comSec);
		//====================================Note ======================================
		
			String comHtml = U.getHTML(comUrl);	
		String note=ALLOW_BLANK;
		note= U.getnote(comHtml);
		
		// ----------------- Community Address-----------------------
				String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String[] latLong= {ALLOW_BLANK,ALLOW_BLANK};
				String geo="False";
				
				String addrSec=U.getSectionValue(comHtml, "<p><strong>Sales Office</strong><br />", "/a></p>");
				if(addrSec == null) addrSec=U.getSectionValue(comHtml, "<p><strong>Temporary Sales Office</strong><br />", "/a></p>");
				if(addrSec==null)addrSec = U.getSectionValue(comHtml, "<p><strong>Project Address</strong><br />", "/a></p>");
				if(addrSec==null)addrSec=U.getSectionValue(comHtml,"<p><strong>Project Address</strong></p>","/a></p>");
				if(addrSec==null)addrSec=U.getSectionValue(comHtml,"<p><strong>Sales Office</strong></p>","/a></p>");
                if(addrSec==null)addrSec=U.getSectionValue(comHtml,"<strong>Sales Office</strong><br />", "/a></p>");
				U.log("ADDSEC=="+addrSec);
				if(addrSec!=null)
				addrSec=addrSec.replace("<br />", ",");
				if(comUrl.contains("com/desert-willow-ranch/")) {
//					add=U.getAddress(U.getSectionValue(addrSec, "\">", "<"));
					addrSec=U.getNoHtml(addrSec);
					addrSec=addrSec//.replaceAll(",\n\\s*Hesperia", ", Hesperia,")
							.replace("<", "").trim();
					add=U.getAddress(addrSec);
//					U.log("ADDSEC=="+addrSec);
				}
				else{
					add=U.getAddress(U.getSectionValue(addrSec, ">", "<"));
				}
				if(add==null||add[0]==ALLOW_BLANK)
					add=U.getAddress(U.getSectionValue(addrSec,"\">", "<"));
				String mapPAgeHtm = U.getHTML(comUrl+"map-directions/");
				if(mapPAgeHtm==null)
					mapPAgeHtm = U.getHTML(comUrl+"/map-directions/");
				U.log("Address ::"+Arrays.toString(add));
				latLong[0]=Util.match(addrSec, "\\d{2,3}\\.\\d{5,}");
				latLong[1]=Util.match(addrSec, "-\\d{2,3}\\.\\d{5,}");
				
				
				if(latLong[0] == null) {
					String latSec = U.getSectionValue(mapPAgeHtm, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
					if(latSec!=null)
					latLong = latSec.split(",");
				}
//				U.log("latSec=="+addrSec);
				if(latLong[0] == null) {
					String latSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps/place/34%C2%B023'25.2%22N+117%C2%B021'18.5%22W/@", "/data");
//					U.log("latSec"+latSec);
					latLong = latSec.split(",");
				}
				
				U.log("Latlong ::"+Arrays.toString(latLong));

				if(add[0]!=null && add[0]!=ALLOW_BLANK && latLong[0]==null ) {
					latLong = U.getlatlongGoogleApi(add);
					geo ="TRUE";
					
				}
				U.log("Note=====>:::"+note);
				//------------------Plan Data-----------------------
				
				int hm=0;
				String HomeSec="";
				String hmHtml="";
				String[] HomUrls=U.getValues(comHtml, "<div class=\"fl-button-wrap fl-button-width-auto fl-button-center fl-button-has-icon\">", "<span class=\"fl-button-text\">View");
				U.log("HomUrls=="+HomUrls.length);
				for(String homeUrl:HomUrls) {
					hm++;
					homeUrl=U.getSectionValue(homeUrl, "<a href=\"", "\"");
					if(!homeUrl.startsWith("http")) homeUrl = BUILDER_URL +homeUrl;
					//homeUrl="https://www.fhcommunities.com"+homeUrl;
					//U.log(hm+"=== "+homeUrl);
					hmHtml+=U.getHTML(homeUrl);
//					HomeSec=U.getSectionValue(hmHtml, "<div style=\"padding-bottom:20px\">", "</div></div></div>");
//					U.log(HomeSec);
				}
//				U.log(HomeSec);
				// ----------------- Community Sqft-----------------------
				String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
				String[] sqft = U.getSqareFeet(comHtml,	"\\d,\\d{3} \\+ Sq Ft|\\d\\,\\d{3} to \\d\\,\\d{3} Sq. Ft", 0);
				minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
				maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
				U.log("MinSqft:  " + minSqft + " MaxSqft: " + maxSqft);
				
				// ----------------- Community Price-----------------------
				String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
				comHtml=comHtml.replace("0s", "0");
				String price[] = U.getPrices(comHtml, "High \\$\\d{3},\\d{3}|Upper \\$\\d{3},\\d{3}|From the Low \\$\\d{3}\\,\\d{3}|From the Mid \\$\\d{3}\\,\\d{3}|Starting from \\$\\d{3}\\,\\d{3}", 0);
				minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
				maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
				U.log("MinPrice:  " + minPrice + " MaxPrice: " + maxPrice);
				// ----------------- Community Data-----------------------
				String propType = ALLOW_BLANK;
				String propStatus = ALLOW_BLANK;
				String drvPropType = ALLOW_BLANK;
				String commType = ALLOW_BLANK;
				
				//============================================ Property Type =========================================================================
				comHtml=comHtml.replaceAll("No HOA|Ranch Park|alt=\"Adelanto single family home|Asher Ranch|asher-ranch|alt=\"loft|model home loft area\"", "");
				if(hmHtml!=null)hmHtml = hmHtml.replaceAll("No HOA|Asher Ranch|Ranch Park|asher-ranch|alt=\"loft", "");
			//	U.log("MMM"+Util.matchAll(comHtml+hmHtml,"[\\w\\W\\s]{50}craftsman[\\w\\W\\s]{50}", 0));
				comHtml=comHtml.replace("Visit today to experience quality craftsmanship","");
				comHtml=comHtml.replace("apartment", "");
				hmHtml=hmHtml.replace("apartment", "");
				propType=U.getPropType(comHtml+hmHtml);
	
				U.log("PType========>:::"+propType);
				
				//=========== Community Type ========================
				
				commType = U.getCommType(comHtml);
				
				U.log("commType========>:::"+commType);
				//============================================ dProp Type =========================================================================
				drvPropType=U.getdCommType(comHtml+hmHtml);
	
				U.log("PdrvType========>:::"+drvPropType);
				
				//====================================Property Status ======================================
				String remSec=U.getSectionValue(comHtml, "<span class=\"fl-heading-text\">The Plans</span>", "Model Gallery</span>");
				//U.log(remSec);
				remSec.replace("now wait", "");
				if(remSec!=null)
					comHtml=comHtml.replace(remSec, "");
				
				
//				comHtml=comHtml.replaceAll("Coming Soon! </h4>|SOLD OUT</h4>|Coming Soon!</h4>|a brand new home ready for a quick move-in", "")
//				.replace(">NEW HOMES COMING</span>", ">NEW HOMES COMING SOON</span>"); //half part is images
//			comHtml = comHtml + " Now Selling "; //from region page, all homes are now selling	
				
				comHtml=comHtml.replaceAll("Coming Soon! </h4>|SOLD OUT</h4>|Coming Soon!</h4>|a brand new home ready for a quick move-in", "")
						.replace(">NEW HOMES COMING</span>", ">NEW HOMES COMING SOON</span>"); //half part is images
					comHtml = comHtml + " Now Selling "; //from region page, all homes are now selling	
					
//					if(comHtml.contains("Sold Out")) {
//						comHtml.replace("Now Selling", "");
//					}	
//				
				propStatus=U.getPropStatus(comHtml.replaceAll("<strong>QUICK MOVE IN HOMES!</strong>|Sq Ft<br />\n\\s*Coming Soon</h4>|Temporarily Sold Out|Temporarily Sold Out", ""));
				
				propStatus = propStatus.replace("Just Released, New Homes Just Released", "New Homes Just Released").replace("Selling Fast", "New Phase Selling Fast");
				U.log("PStatus========>:::"+propStatus);
				
			//	if(comUrl.contains("https://www.fhcommunities.com/stone-briar-ii/"))propStatus=propStatus.replace(", Sold Out","");
			//	U.log("mmmmmm"+Util.matchAll(comHtml, "[\\w\\s\\W]{100}Quick Move[\\w\\s\\W]{100}", 0));
               // if(comUrl.contains("https://www.fhcommunities.com/alicante"))propStatus="New Phase Selling Fast";//frm image
//				if(comUrl.contains("https://www.fhcommunities.com/brookhaven/"))propStatus=propStatus+", Selling Fast";//frm Image
				//===================site map============
                String siteMapUrl=comUrl+"sitemap/";
                if(comUrl.contains("https://www.fhcommunities.com/stone-briar")) {
                	 siteMapUrl=comUrl+"/sitemap/";
                }
                String sitemapHtml=U.getHTML(siteMapUrl);
                int lotCount=0;
                int lotCount2=0;
                String noOfUnits=ALLOW_BLANK;
                String siteUrlSec=U.getSectionValue(sitemapHtml, "<iframe", "</iframe>");
                if(siteUrlSec!=null) {
                String siteUrl=U.getSectionValue(siteUrlSec, "src=\"", "\"");
                U.log("sITE URL "+siteUrl);
                String siteHtml=U.getHtml(siteUrl, driver);
                U.log("path::"+U.getCache(siteUrl));
                
                String[] lotData=U.getValues(siteHtml, "<div class=\"anchorshape round\"", ">");
                lotCount=lotData.length;
                
//                String lotSec2=U.getSectionValue(siteHtml, "<g class=\"lots\" id=\"lotgroup_0\">", "</svg></div><div class=\"footprints layer\"");
//                String [] lotData2=U.getValues(lotSec2, "<g id=\"g0_", "class=\"lot\">");
//                lotCount2=lotData2.length;
//                U.log("lot data 2:: "+lotCount2);
              //  noOfUnits=Integer.toString(lotCount+lotCount2);
                noOfUnits=Integer.toString(lotCount);
                }
                if(noOfUnits.equals("0"))
                	noOfUnits=ALLOW_BLANK;
                
                U.log("No of units "+noOfUnits);
                
                
                
                
                
                // ----------------- Community Data-----------------------
				data.addCommunity(comName, comUrl, commType);
				data.addLatitudeLongitude(latLong[0], latLong[1], geo);
				data.addPrice(minPrice, maxPrice);
				data.addAddress(add[0].trim(), add[1].trim(), add[2].trim(), add[3].trim());
				data.addSquareFeet(minSqft, maxSqft);
				data.addPropertyType(propType, drvPropType);
				data.addPropertyStatus(propStatus);
				data.addNotes(note);
				data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
                data.addUnitCount(noOfUnits);
				
	}

	public static void main(String[] args) throws Exception {
		AbstractScrapper a=new ExtractFrontierCommunities();
		a.process();
		FileUtil.writeAllText(U.getCachePath()+"Frontier Communities.csv", a.data().printAll());
		
	}

}
