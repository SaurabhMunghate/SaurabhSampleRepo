package com.shatam.b_325_353;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author MJS
 * @date 31/03/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHakesBrothers extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver;
	static String builderUrl = "https://www.hakesbrothers.com/";

	public ExtractHakesBrothers() throws Exception {
		super("Hakes Brothers", builderUrl);
		LOGGER = new CommunityLogger("Hakes Brothers");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractHakesBrothers();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Hakes Brothers.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpChromePath();
//		driver = new ChromeDriver();
		
		String html = U.getHTML("https://www.hakesbrothers.com/");
		String[] mainSec = U.getValues(html, " <h2 class=\"h1 card-title\">", "</a>");
		
		for(String regionUrl : mainSec) {
			
//			try {
				getCommunity(regionUrl);
//			} catch (Exception e) {}
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void getCommunity(String regionUrl) throws Exception {
		// TODO Auto-generated method stub
		
		regionUrl = U.getSectionValue(regionUrl, "<a href=\"", "\"");
		U.log("regionUrl: "+regionUrl);
		String html = U.getHTML(regionUrl);
		String[] mainSec = U.getValues(html, "<div class=\"cell community-grid__item\">", "</p>");
		//String[] mainSec = U.getValues(html, "<div class=\"cell community-grid__item\">", "<div class=\"fr-view margin-top-1\">");
		for(String main : mainSec) {
			
			String comUrl = U.getSectionValue(main, "<a href=\"", "\"");
			getDetail(comUrl, main);
		}
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//		if(!comUrl.contains("https://www.hakesbrothers.com/las-cruces/red-hawk-estates"))return;
		
		U.log("Count: " + j + "\t" + comUrl);
	//	if(j>=16)
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			
			if(comUrl.contains("https://www.hakesbrothers.com/las-cruces/trails-metro-2")) {
				LOGGER.AddCommunityUrl("==========Page Not Found================"+comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			if(!comUrl.contains("http"))
				comUrl = builderUrl+comUrl;
			
			String html = U.getHTML(comUrl);
			String mapHtml = getHtml(comUrl, driver);
			
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			units = getUnits(mapHtml, comUrl, driver);
			U.log("Total Units : "+units);
			// ---------------------------------------------------------
		
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, "<h1 class=\"card-title\"", "</h1>");
			if(communityName==null)
				communityName=U.getSectionValue(com, "<h3 class=\"h1 card-title\" style=\"line-height: 1.2;\">", "</h3>");
			
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replaceAll("&#039;|&#8217;", "'").replaceAll("(.*)?>", "").replace(" 2b Phase 3", " 2b");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			
			
			String addSection=U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "\"");
			if(addSection!=null) {
				
				addSection = addSection.replace("+", " ").replace("%2C", ",");//dt
//				addSec = addSec.replace("+", ",").replace("%2C", " ");
				add = U.getAddress(addSection);
			}
			U.log("Address11---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
			
			
			String addSec = U.getSectionValue(mapHtml, "<a href=\"https://www.google.com/maps/dir/?api=1&amp;destination=", "</a>");
		U.log("mmm"+addSec);
		if(add.length<4){
			U.log("hello");
			if(addSec!=null && addSec.contains("<span>")) {
				
				addSec = U.getSectionValue(addSec, "<span>", "</span>");
				String[] val = addSec.split(",");
				if(val.length==4) {
					
					add = U.getAddress(addSec);
				}
				if(val.length==3) {
					
					add[0] = val[0];
					add[1] = val[1];
					add[2] = val[2];
					
					latLng = U.getlatlongGoogleApi(add);
				}
				if(val.length==2) {
					
					add[0] = val[0];
					add[1] = val[1];
					
					latLng = U.getlatlongGoogleApi(add);
				}
			}
			else {
				if(!comUrl.contains("https://www.hakesbrothers.com/el-paso/summer-sky")) {
				addSec = Util.match(addSec, ".*\"");
				
				U.log("m sec"+addSec);
				if(addSec!=null) {
					
					addSec = addSec.replace("+", " ").replace("%2C", ",");//dt
//					addSec = addSec.replace("+", ",").replace("%2C", " ");
					add = U.getAddress(addSec);
				}
				
			}
			}
		}
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
		   
			
			
			latLng[0] = U.getSectionValue(com, "data-latitude=\"", "\"");
			latLng[1] = U.getSectionValue(com, "data-longitude=\"", "\"");
					
			if(latLng[0]==null||latLng[0]==ALLOW_BLANK) {

				latLng[0] = U.getSectionValue(html, "data-lat=\"", "\"");
				latLng[1] = U.getSectionValue(html, "data-lng=\"", "\"");
			}
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0]==null || add[0].length() < 4 || add[3] == null || add[3] == ALLOW_BLANK) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0]==null || add[0].length() < 4)
					add[0] = add1[0];
				if (add[3] == null || add[3] == ALLOW_BLANK)
					add[3] = add1[3];
				geo = "TRUE";
			}

			if(comUrl.contains("https://www.hakesbrothers.com/el-paso/summer-sky")) {
				latLng[0]="31.713221";
				latLng[1]="-106.20744";
				add=U.getAddressGoogleApi(latLng);
				geo="TRUE";
			}
			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//========== Move In Homes ==================================================
			String movPart = U.getSectionValue(html, "<section id=\"quick-move-in-homes\" class=\"section--block\">", "</section>");
			if(movPart==null)
				movPart = "";
			String[] movSec = U.getValues(movPart, "<article class=\"card\"", "</article>");
			
			String moveData = ALLOW_BLANK;
			for(String data : movSec){
				
					String url = U.getSectionValue(data, "<a href=\"", "\"");
					
					String mhtml = U.getSectionValue(U.getHTML(url), "<main id=\"main\" role=\"main\">", "</section>");
					moveData += mhtml;
				}
			
			//========== Floor Homes ==================================================
			
			String floorPart = U.getSectionValue(html, "<section class=\"section--block\">", "</section>");
			if(floorPart==null)
				floorPart = "";
			String[] floorSec = U.getValues(floorPart, "<article class=\"card\">", "</article>");
			String floorData = ALLOW_BLANK;
			if(floorSec!=null)
			for (String data : floorSec) {

				String url = U.getSectionValue(data, "<a href=\"", "\"");
				
				String fhtml = U.getSectionValue(U.getHTML(url), "<main id=\"main\" role=\"main\">", "</section>");
				floorData += fhtml;
			}
			

			floorSec = U.getValues(html, "<div class=\"card-section\">", "</article>");
			 floorData = ALLOW_BLANK;
			if(floorSec!=null)
			for (String data : floorSec) {

				String url = U.getSectionValue(data, "<a href=\"", "\"");
				
				String fhtml = U.getSectionValue(U.getHTML(url), "<main id=\"main\" role=\"main\">", "</section>");
				floorData += fhtml;
			}
			
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#39;s|0&#8217;s|0s|0's", "0,000").replace("&#39;s", ",000")
					.replaceAll("data-price=\"(\\d{6})", "data-price=\"$1 price") //taking prices from map available in com sections
					.replaceAll("<div class=\"fr-view margin-top-1\">\\s+<div data-aos=\"fade-zoom-in\" data-price=\"\\d{6}", ""); 
			
			html = html.replace("0s", "0,000");
			String prices[] = U.getPrices(com + html , "data-price=\"\\d{6} price|<strong class=\"h2 text-primary\">\\$\\d{3},\\d{3}</strong>|Starting at \\$\\d{3},\\d{3}|\\$\\d{3},\\d{3}\\s*</strong>", 0);
			//U.log("com: "+com);
			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];

			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log(Util.matchAll(com, "[\\w\\s\\W]{30}price[\\w\\s\\W]{30}",0));
//			U.log(Util.matchAll(html, "[\\w\\s\\W]{30}348990[\\w\\s\\W]{30}",0));
			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet((com + html).replace("from 1,630 to 2,675 square feet", ""),
					"\\d,\\d{3} to \\d,\\d{3} square feet|<strong class=\"lead\">\\d,\\d{3}</strong>|Starting at \\d,\\d{3} Square Feet",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================
			
			String communityType = U.getCommType((html + com).replaceAll("from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================
			html=html.replace("Hillside Park Estates", "Estate Residences").replace(" Mediterranean, Contemporary, and Spanish exteriors", "Mediterranean Series");
			
//			U.log("NN"+Util.matchAll((com),"[\\w\\W\\s]{50}Craftsman[\\w\\W\\s]{40}",0));
			String proptype = U.getPropType((html + com + moveData + floorData )
					.replaceAll("Hawk Estates combines|Fleet Estates offers|Mariposa Estates gives|Red Hawk Estates", "Estates homes")
					.replaceAll("maravillas|Maravillas|village|village|home craftsmanship|-Villas|Villasin", ""));
//			U.log("MMMMMMKM"+Util.matchAll(html + com + moveData + floorData , "[\\w\\s\\W]{50}villas[\\w\\s\\W]{30}", 0));
			// ==================================================D-Property
			// Type======================================================
			String dtype = U.getdCommType((html + com + moveData + floorData).replaceAll("Spanish Colonial|branch|BRANCH|(f|F)loor|2-story foyer provides ", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("Coming Soon_E_2 story|Coming-Soon|Elevation-_Coming-Soon|Elevation - Coming Soon|Elevation-_Coming Soon|Elevation _Coming Soon|Elevation Coming Soon|[Q|q]uick [M|m]ove|[M|m]ove-[I|i]n|Rendering Coming Soon|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("New Phase - Now Selling", "New Phase Now Selling").replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE");
			html=html.replace("Final Phase Release - Coming Soon", "Final Phase Release Coming Soon");
			String pstatus = U.getPropStatus((html + com).replace("Home Design Sold Out", ""));
			if(pstatus.equals("New Phase, Coming Soon, Now Selling")) {
				pstatus = "New Phase Coming Soon, Now Selling";
			}
			
			
			U.log("pstatus: "+pstatus);
//			U.log("com: "+com);
//			U.log(Util.matchAll(html + com, "[\\w\\s\\W]{10}new phase[\\w\\s\\W]{30}", 0));
			
			// ============================================note====================================================================
			 note = U.getnote(html+com);

			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "");
			
		
			
			boolean date = false;
			for (String val : movSec) {
				//U.log("L::::::::"+val);
//				if (Util.match(val, "Move-In Ready") != null || val.contains("<div class=\"h2 card-title text-white text-right\">"))
				if (Util.match(val, "Move-In Ready") != null || val.contains("June 20"))
	
					date = true;
			}
			if(date == true)
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-In Homes";
				else if(!pstatus.contains("Quick Move-In Homes")) 
					pstatus += ", Quick Move-In Homes";
			
			if(comUrl.contains("https://www.hakesbrothers.com/albuquerque/vista-entrada")||comUrl.contains(" https://www.hakesbrothers.com/albuquerque/lomas-encantadas-iii")||comUrl.contains("https://www.hakesbrothers.com/albuquerque/mountain-hawk-estates-ii"))add[3]="87144";
			if(add[3]==null)add[3]="87144";
//			if(comUrl.contains("/el-paso/emerald-park-estates"))pstatus=pstatus+", New Phase";
			//=========================================================================================================================
			communityName = communityName.replace("IIi", "III");

			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName.replace("IIi", "III"), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note.replace("Now Pre-selling, Pre-sale", "Now Pre-selling"));

		}
		j++;

	}
	
	public static String getUnits(String mapHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(mapHtml.contains("<h1 class=\"headline text-center\">Interactive Site Map</h1>") ||
				mapHtml.contains("<h2 class=\"h1 headline text-center\">Interactive Site Map</h2>")) {
			
			if(mapHtml.contains("class=\"mapplic-pin")) {
				
				ArrayList<String> pins = Util.matchAll(mapHtml, "class=\"mapplic-pin", 0);
				U.log("Count Pins: "+pins.size());
				totalUnits = String.valueOf(pins.size());
			}
		}
		
		return totalUnits;
	}
	
	// --------- PLEASE NOTE -------------------
	// The below methods are changed to get the data for the same builder with simple getHTML method and with selenium webdriver both.
	// Data for the maps will be read from filename "CacheMaps". Create folder "CacheMaps" alongside "Cache". 
	
	public static String getCachePath() {
		String Regex="CacheMaps";
		String Filename=System.getProperty("user.home");
		//U.log(Filename+"filename");
		if(Filename.contains("/")){
			Regex="/CacheMaps/";
		}
		else 
		{
			Regex="\\CacheMaps\\";
		}
		Filename=Filename.concat(Regex);
		//U.log("filename :::"+Filename);
		if(!Filename.equals(Regex))
		{
			Regex=Regex.toLowerCase();
		}
		return Filename;
	}
	

	public static String getCache(String path) throws MalformedURLException {

		String Dname = null;
		String host = new URL(path).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;

		File folder = new File(getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = getCacheFileName(path);
		fileName = getCachePath() + Dname + "/" + fileName;
		return fileName;
	}
	
	public static String getCacheFileName(String url) {

		String str = url.replaceAll("http://", "");
		str = str.replaceAll("www.", "");
		str = str.replaceAll("[^\\w]", "");
		if (str.length() > 200) {
			str = str.substring(0, 100) + str.substring(170, 190)
					+ str.length() + "-" + str.hashCode();

		}

		try {
			str = URLEncoder.encode(str, "UTF-8");
			// U.log(str);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();

		}
		return str + ".txt";
	}
	
	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = getCacheFileName(url);

		fileName = getCachePath()+ Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
					Thread.sleep(10000);
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(10000);
				//	((JavascriptExecutor) driver).executeScript(
				//			"window.scrollBy(0,400)", ""); 
					Thread.sleep(5000);
				//	U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}


}