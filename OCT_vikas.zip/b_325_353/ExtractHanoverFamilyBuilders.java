package com.shatam.b_325_353;
/**
 * @author MJS
 * @date 31/03/2021 
 * 
 */

import java.util.HashMap;

import org.apache.commons.lang.StringEscapeUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHanoverFamilyBuilders extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://www.hanoverfamilybuilders.com";
	HashMap<String, String> map = new HashMap<>();

	public ExtractHanoverFamilyBuilders() throws Exception {
		super("Hanover Family Builders", builderUrl);
		LOGGER = new CommunityLogger("Hanover Family Builders");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractHanoverFamilyBuilders();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Hanover Family Builders.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String urlHtml = U.getHtml("https://www.hanoverfamilybuilders.com/communities", driver);
		

		//String[] comUrlSec = U.getValues(urlHtml, "<div class=\"result-media ", "View on Map</a>");
		String[] comUrlSec=U.getValues(urlHtml,"<h4 class=\"result-title\">","</h4>");
		String html = U.getHTML("https://api2.mybuildercloud.com/api/v1/communities?where={%22published%22:true,%22builder%22:%225939bbce4db0481468c66ad8%22}&max_results=9999");
		String qHtml = U.getHTML("https://api2.mybuildercloud.com/api/v1/homes?where={%22published%22:true,%22builder%22:%225939bbce4db0481468c66ad8%22}&max_results=9999");
		String fHtml = U.getHTML("https://api2.mybuildercloud.com/api/v1/plans?where={%22published%22:true,%22builder%22:%225939bbce4db0481468c66ad8%22}&max_results=9999");
		
		String[] mainSec = U.getValues(html, "\"_etag\": \"", "\"uniqueName\":");
		String[] quickSec = U.getValues(qHtml, "\"_etag\": \"", "\"uniqueName\":");
		String[] flooeSec = U.getValues(fHtml, "\"_etag\": \"", "\"uniqueName\":");
		U.log("MAIN"+mainSec.length);
		U.log("Total comm"+comUrlSec.length);
		String data = ALLOW_BLANK;
		for(String main : mainSec) {
			//U.log(main);
			String id = U.getSectionValue(main, "\"_id\": \"", "\"");
			String name = U.getSectionValue(main, "\"modifier_email\":", "\"order_field\":");
			name = U.getSectionValue(name, "\"name\": \"", "\"").trim();
			data = main;
			
			if (id != null) {
				for (String floor : flooeSec)
					if (floor.contains(id))
						data += "START OF FLOOR" + floor + "END OF FLOOR";
				for (String quick : quickSec)
					if (quick.contains(id))
						data += "START OF QUICK" + quick + "END OF QUICK";
			}
			map.put(name, data);
		}
		
		for(String com : comUrlSec) {
			
			String comUrl = U.getSectionValue(com, "<a href=\"", "\"");
		//	String name = U.getSectionValue(com, "com_id:community.uniqueName, section:'overview'})\" class=\"ng-binding\">","<").trim();
			String name=U.getSectionValue(com, "class=\"ng-binding\">"," <span class=\"ng-binding\">");
//			if(name.equals("Bargrove"))
//				U.log(comUrl+"\t"+name+"\t"+map.get(name));
			
			getDetail(builderUrl+comUrl, map.get(name), name);
		}
		driver.quit();
		LOGGER.DisposeLogger();
	}


	private void getDetail(String comUrl, String com, String name) throws Exception {
		// TODO Auto-generated method stub
		
//	if(!comUrl.contains("https://www.hanoverfamilybuilders.com/communities/polk-county/legacy-landings/overview"))return;
//		
		U.log("Count: " + j + "\t" + comUrl);
		{
//			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			String html = com;
//			U.log(com);
			// ============================================Community
			// name=======================================================================
			U.log(U.getCache(comUrl));

			String communityName = name;
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'").replaceAll("(.*)?>", "");
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			String addSec = U.getSectionValue(html, "\"address\": {\"", "}");
			
			if(addSec!=null) {
				
				add[0] = U.getSectionValue(addSec, "\"streetAddress\": \"", "\"");
				add[1] = U.getSectionValue(addSec, "\"addressLocality\": \"", "\"");
				add[2] = U.getSectionValue(addSec, "\"addressRegion\": \"", "\"");
				add[3] = U.getSectionValue(addSec, "\"postalCode\": \"", "\"");
			
			}
			add[0]=add[0].replace("Missouri Ave, St Cloud, FL 34769", "Missouri Ave")
					.replace(" (Pre-Sale Model Center for Legacy Landings)", "")
					.replace("GPS Mapping:", "");
			
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
		
			String latSec = U.getSectionValue(html, "\"geoIndexed\": [", "]");
			String[] val = latSec.split(","); 
		
			latLng[0] = val[1];
			latLng[1] = val[0];
					
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0]==null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0]==null || add[0].length() < 4)
					add[0] = add1[0];
				if (add[3] == null)
					add[3] = add1[3];
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//========== Move In Homes ==================================================
			String moveData = U.getSectionValue(html, "START OF QUICK","END OF QUICK");
			
			//========== Floor Homes ==================================================
			
			String floorData = U.getSectionValue(html, "START OF FLOOR","END OF FLOOR");
			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000")
					.replace("</strong>   &#36;", " $");
			com = com.replace("display\": \"From the Low $200s\"", "").replaceAll("0&#39;s|0&#8217;s|0s|0's", "0,000").replace("&#39;s", ",000");
			
			html = html.replace("display\": \"From the Low $200,000\"", "").replace("0s", "0,000");
		//	
			//html=html.replace("", newChar)
			String prices[] = U.getPrices(com+html , "\"priceLow\": \\d+|\"priceHigh\": \\d+|From the low \\$\\d{3},\\d{3}", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
		
			String[] sqft = U.getSqareFeet(com + html,
					"\"sqft\": \\d+|\"sqftHigh\": \\d+|\"sqftLow\": \\d+",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			html=html.replace(" lakeside living", " lakeside community living");
			String communityType = U.getCommType((html + com).replaceAll("Beautiful New Waterfront Community|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			
			// ==========================================================Property
			// Type================================================

			String proptype = U.getPropType((html).replace("\"type\": \"Single Family\",", "").replaceAll("Wilshire exterior, a 2-story single-family home\"|\"type\": \"Single Family\"|single-family master baths", ""));
			//U.log(Util.matchAll(html, "[\\w\\s\\W]{30}Single[\\w\\s\\W]{30}", 0));

			// ==================================================D-Property
			// Type======================================================
			html = html.replace("\"stories\": ", " Story");
			String dtype = U.getdCommType((html).replaceAll("branch|BRANCH|(f|F)loor", "")
					+ communityName);

			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("\"price_display\": \"Coming Soon\"|coming soon to beautiful| Coming Soon to Mount|Coming Soon to Lake County|Townhomes Coming Soon|Coming Soon! For more information|Townhomes are coming soon|Coming Soon to Kissimmee", "").replaceAll("\"name\": \"New Homes Available|Now Selling New Homes in Sanford|[Q|q]uick [M|m]ove|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			if(moveData!=null)
				html = html.replace(moveData, "");
			if(floorData!=null)
				html = html.replace(floorData, "");
			U.log("SSS"+Util.matchAll(html, "[\\w\\W\\s]{50}NOW SELLING[\\w\\W\\s]{50}", 0));
			
			String pstatus = U.getPropStatus(html.replaceAll("Pre-Sales coming soon|Now Selling in Kissimmee|\"name\": \"Final Opportunities|Now Selling from Nearby Orchid Terrace|Model Sales Center Coming Soon|homes coming soon|Model - Now Open|model at Cypress Hammock is Now Open|model at Cypress Hammock is now open|Now Open! Schedule|Aerial of Phase 3, Now Selling|(Now Building)|caption\": \"New Phase 3 Homesites Available NOW", ""));
			U.log("1st property status"+pstatus);
			
			// ============================================note====================================================================
			note = U.getnote(html.replace("Now-Preselling", "Now Pre-Selling").replaceAll("PRE-SALES COMING AGAIN SOON|Pre-Sale appointments|Pre-Sales Coming Again Soon|\"hours\": \"PRE-SELLING|Pre-Sales her|Pre-Selling near Sanford", ""));

			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s", "");
			
//			if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/polk-county/williams-preserve"))pstatus="Phase 3 Closeout";
			
			//if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/osceola-county/hanover-lakes"))pstatus= "Waterfront Homesites Available, Final Opportunities";
//			if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/lake-county/ardmore-reserve"))pstatus="Phase 6 Homesites Now Selling";
//		if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/polk-county/greenfield-village"))pstatus+=", Now Selling";
			if(moveData!=null && moveData.contains("\"status\": \"Active\""))
				if(pstatus==ALLOW_BLANK)
					pstatus = "Move-In Ready Homes";
				else if(!pstatus.contains("Move-In Ready Homes")) 
					pstatus += ", Move-In Ready Homes";
			
//		if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/polk-county/orchid-terrace"))	minPrice="$262,999";
//			if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/osceola-county/overlook-reserve"))	minPrice="$299,998";
//				if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/lake-county/ardmore-reserve"))	minPrice="$332,999";
				
//			if(comUrl.contains("lake-county/preserve-at-sunrise/")) pstatus="Now Selling";
			//from image
			if(comUrl.contains("/communities/polk-county/williams-preserve/")) pstatus = "Final Opportunities, Phase 3 Closeout, Only A Few Homesites Remain";
			if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/osceola-county/overlook-reserve"))pstatus = "Final Closeout, Only A Few Remain";
			//from Region page images
			//if(comUrl.contains("/polk-county/greenfield-village/"))pstatus="Now Selling";
//			if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/lake-county/preserve-at-sunrise"))pstatus = "Phase 3 Homesites Now Selling";
//			if(comUrl.contains("communities/lake-county/lake-lincoln/") || comUrl.contains("/lake-county/trinity-lakes/"))note="Pre-Sales Begin Soon";
//			if(comUrl.contains("polk-county/legacy-landings/")) note="Pre-Sales Start Soon";
			if(comUrl.contains("polk-county/orchid-terrace/"))pstatus="Final Opportunities, Closeout";
			if(comUrl.contains("county/williams-preserve-townhomes/overview"))pstatus="Closed Out";
			if(comUrl.contains("/lake-county/sunrise-ridge"))pstatus="Now Selling";
			if(comUrl.contains("communities/polk-county/first-place/"))pstatus="Final Opportunities, "+pstatus;
			if(comUrl.contains("https://www.hanoverfamilybuilders.com/communities/lake-county/ardmore-reserve"))pstatus="Homesites Available";
			add[0]=add[0].replace("(Off-Site Sales Office at Nearby Preservation Pointe)", "");
			add[0]=StringEscapeUtils.unescapeJava(add[0]);
			add[0]=add[0].replace(" – ", "");
			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//=========================================================================================================================
			data.addCommunity(communityName, comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);

		}
		j++;

	}

}