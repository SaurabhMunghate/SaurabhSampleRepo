package com.shatam.b_325_353;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHoltHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver = null;
	public ExtractHoltHomes() throws Exception {

		
		super("Holt Homes", "https://www.holthomes.com/");
		LOGGER = new CommunityLogger("Holt Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractHoltHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Holt Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		U.setUpGeckoPath();
		driver=new FirefoxDriver();
		String mainHtml=U.getHTML("https://www.holthomes.com/");

//		String comSections[]=U.getValues(mainHtml, "<div class=\"organism image-grid-w-overlay-content\"", "</section>");
		String comSections[]=U.getValues(mainHtml, "<div class=\"item\" >", "<div class=\"molecule image\">");
		for(String comSec:comSections) {
			
			String[] comUrlSec = U.getValues(comSec, "<a href=\"", "\"");
			
			U.log(comUrlSec.length);
			for(String comUrl : comUrlSec)
				addDetails(comUrl,comSec);
		}
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comUrl, String comSec) throws Exception {
		
		if(!comUrl.contains("http"))
		comUrl="https://www.holthomes.com"+comUrl;
	
		comUrl = comUrl.replace("http:", "https:");
		U.log(comUrl);
		
		
		//TODO:
//		if(!comUrl.contains("https://www.holthomes.com/communities/gateway-landing-homes-for-sale-in-troutdale-or/")) return;
		
		
		
		if(comUrl.contains("https://lp.holthomes.com/new-homes-camas-washington-glades-green-mountain")
				||comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")
				||comUrl.contains("https://www.holthomes.com/new-home-communities-washington")||comUrl.contains("https://www.holthomes.com/new-home-communities-oregon/")) {
			
			LOGGER.AddCommunityUrl("======== returning to reg page comm is return ============"+comUrl);
			return;
		}
 
//	if(j>=15)	
	{
		if (data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl("-------Repeated-------" + comUrl);
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml=U.getHTML(comUrl);
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------
		
		
//		U.log("***********"+comHtml);
		String comName=U.getSectionValue(comHtml, "<div class=\"community-title title\">", "</div>");
		if(comName == null)
			comName=U.getSectionValue(comHtml, "<title>", "</title>");
		
		if(comName!=null)
			comName=U.getNoHtml(comName).replaceAll("New homes coming soon to| in Ridgefield, WA| in Camas, WA|Troutdale, OR", "")
			.replace("[Coming Soon]", "").replaceAll("-sherwood-oregon|Sherwood Oregon","");
		
		if(comName!=null && comName.trim().isEmpty()) {
			comName=U.getSectionValue(comHtml, "<iframe title=\"Holt Homes", "Community Map\"");
		}
		if(comName!=null)
			comName=U.getNoHtml(comName).replace("New homes at Quail Run in Eagle Point, OR", "Quail Run").replaceAll(" Homes For Sale,  - Holt Homes| Homes for Sale in Troutdale OR - Holt Homes| Homes for Sale in Lafayette OR - Holt Homes| Homes for Sale in Estacada OR - Holt Homes|Homes for Sale in Corvallis OR - Holt Homes| Homes for Sale in Happy Valley OR - Holt Homes| for Sale in Cornelius OR - Holt Homes| for Sale in Ridgefield WA - Holt Homes| for Sale in Battle Ground WA - Holt Homes|New homes coming soon to| in Ridgefield, WA| in Camas, WA|Troutdale, OR", "")
			.replace("[Coming Soon]", "").replaceAll("-sherwood-oregon|Sherwood Oregon","");
//		if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")) comName="Stones Throw";
		comName=comName
				.replace("New homes at East Mountain in Eugene, OR", "East Mountain")
				.replace("New homes at Scouters Mountain Happy Valley, OR", "Scouters Mountain").replace(" - Holt Homes", "");
		if(comName.endsWith("Homes")) comName=comName.replace("Homes", "");
		U.log("comName ::"+comName);
		
		String note=U.getnote(comHtml.replace("receive presale pricing", ""));

		//======================address===============================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		String addSec = U.getSectionValue(comHtml, "<a href=\"https://www.google.com/maps?sll", "\"");
		U.log("addSec: "+addSec);
		if(addSec == null )addSec=U.getSectionValue(comHtml, "href=\"https://www.google.com/maps/place/", "/@");
		if(addSec!=null){
			addSec = addSec.replaceAll(",\\+United\\+States", "").replace("+Camas", ", Camas").replace("+", " ");
			U.log("addSec-1: "+addSec);
			add=U.getAddress(addSec);
			}
		if(addSec!=null && addSec.contains("&amp;q=")) {
			addSec = U.getSectionValue(addSec, "&amp;q=", "&amp;z=");
			if(addSec!=null){
			addSec = addSec.replaceAll(",\\+United\\+States", "").replace("12568+SE+162nd+Ave,+Happy+Valley,+OR+97086", "12568+Southeast+162nd+Avenue,Happy+Valley,+OR,+97086").replace("+Happy+Valley",", Happy+Valley").replace("+Camas", ", Camas").replace("+", " ");
			U.log(addSec);
			add=addSec.replace("12568 Southeast 162nd Avenue Happy Valley, OR, 97086", "12568 Southeast 162nd Avenue, Happy Valley, OR, 97086").split(",");
			}
		}
		
		if(addSec==null) {
			addSec=U.getSectionValue(comHtml, "Model Home Address:</dt>"," </dd>");
			if(addSec!=null) {
				U.log("addSec-2: "+addSec);
			addSec=addSec.replace("<dd>","").replace("<br>",",");
			add=U.getAddress(addSec);
			}
		}
		
		if(addSec==null || comHtml.contains("Sales Office Info")) {
		
			U.log(Util.matchAll(comHtml, "[\\w\\W\\s]{50}Sales Office Info[\\w\\W\\s]{50}", 0));
			addSec=U.getSectionValue(comHtml,"<h3>Sales Office Info</h3>","<div class=\"button atom\">");
			if(addSec!=null) {
			addSec=addSec.replaceAll("<p>Open daily from 11:00 am &#8211; 5:00 pm</p>\n\\s*|<p>Phase 1 SOLD OUT!<br />\n\\s*Stay tuned on information regarding phase 2 release.</p>|<p>Open Daily<br />\n\\s*11:00 am – 5:00 pm</p>|<p>Open Daily 11:00 am &#8211; 5:00 pm</p>", "").trim();
				U.log("MMM"+addSec);
//			addSec=U.getSectionValue(addSec, "<p>", "</p>");
////			U.log("Add.."+addSec);
			addSec=addSec
					.replaceAll("Open daily from|Open Daily|\\d+:\\d+ am – \\d+:\\d+ pm|\\d+:\\d+ am &#\\d+; \\d+:\\d+ pm", "")
					.replace("2887 S. Nectarine St. Cornelius", "2887 S. Nectarine St., Cornelius")
					.replace("17495 SW Brookman Rd Sherwood, OR 97140","17495 SW Brookman Rd, Sherwood, OR 97140").replace("119 SW Hewitt Ave Troutdale, OR 97060", "119 SW Hewitt Ave, Troutdale, OR 97060").replace("121 17th St Lafayette, OR 97127", "121 17th St, Lafayette, OR 97127").replace("32840 SE Duus Rd.  Estacada, OR 97023", "32840 SE Duus Rd., Estacada, OR 97023").replace("2983 NW Deer Run St. Corvallis, OR 97330", "2983 NW Deer Run St., Corvallis, OR 97330").replace(" Happy Valley", ", Happy Valley").replace("1316 S Quartz Dr Cornelius, OR 97113", "1316 S Quartz Dr, Cornelius, OR 97113").replace("8847 N 5th Street Ridgefield, WA 98642", "8847 N 5th Street, Ridgefield, WA 98642").replace("1006 NE 17th Street Battle Ground, WA 98604", "1006 NE 17th Street, Battle Ground, WA 98604");
			U.log("MMM"+addSec);
			addSec=U.getNoHtml(addSec).trim();
			U.log("MMM"+addSec);
			add=U.getAddress(addSec);
			
			U.log("MYYYY aDDRESS " +Arrays.toString(add));
			}
		}
		if(addSec==null) {
			String iframeSec=U.getSectionValue(comHtml, "<iframe title=\"", "</iframe>");
			String addHtml=ALLOW_BLANK;
			String mLatSec=ALLOW_BLANK;
			String mAddresss=ALLOW_BLANK;
			if(iframeSec!=null) {
				String addUrl=U.getSectionValue(iframeSec, "src=\"", "\">");
				U.log("add URL="+addUrl);
				U.log("Cache====="+U.getCache(addUrl));
				if(addUrl!=null) {
//					U.log(")))))))))))))))");
//					addHtml=U.getHtml(addUrl, driver);
					
					mLatSec=U.getSectionValue(addUrl, "q", "amp;");
					  latlag[0]=U.getSectionValue(mLatSec,"=", ",");
					  latlag[1]=U.getSectionValue(mLatSec,",", "&");
					  
					addUrl=addUrl.replace("&amp;", "&");	
//				addHtml=U.getPageSource("https://www.google.com/maps/embed/v1/place?key=AIzaSyBbQzgt6iHPr99GNH0-Iao20QFfmwAAXp4&q=45.6439609,-122.4428724&zoom=12");
					addHtml=U.getPageSource(addUrl);
					//  add=U.getAddressGoogleApi(latlag);
              mAddresss=U.getSectionValue(addHtml, "function onEmbedLoad() {", "}").replace("null,", "");
              U.log("======"+mAddresss);
				String addressSec=U.getSectionValue(mAddresss,"[0,0,0]","[1],");
				U.log("MMMMMMMMMMMMMMMMMMM"+addressSec);
				String addLine=U.getSectionValue(addressSec, "\"],\"", ", USA\"");
				add=U.getAddress(addLine);
				U.log("My Address"+Arrays.toString(add));
				}
			}
		}
		
       if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-eagle-point")) {
			U.log("Yess");
			comName = "Eagle Point";
			add[1]="Eagle Point";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		
       if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-quail-run") || comUrl.contains("https://lp.holthomes.com/homes-for-sale-east-mountain")) {
			U.log("Yess");
//			comName = "Eagle Point";
			add[1]="Eagle Point";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		
       if(comUrl.contains("https://www.holthomes.com/communities/scouters-mountain-homes-for-sale-in-happy-valley-or/")) {
			U.log("Yess");
//			comName = "";
			add[1]="Happy Valley";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		
		if(comUrl.contains("https://lp.holthomes.com/new-homes-estacada-faraday-hills-or")) {
			
			comName = "Faraday Hills";
			add[1]="Estacada";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		
		
		
/*		else if(comUrl.contains("https://lp.holthomes.com/new-homes-troutdale-or-gateway-landing")) {
			
			comName = "Gateway Landing";
			add[1]="Troutdale";
			add[2]="OR";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			
		}*/
		
//		else if(comUrl.contains("https://lp.holthomes.com/new-homes-lafayette-hearth-at-millican-creek")) {
//			
//			comName = "The Hearth at Millican Creek";
//			add[1]="Lafayette";
//			add[2]="OR";
//			latlag=U.getlatlongGoogleApi(add);
//			add=U.getAddressGoogleApi(latlag);
//			geo="TRUE";
//			
//		}
		else if(comUrl.contains("https://lp.holthomes.com/new-homes-ridgefield-washington-greely-farms")) {
//			comName = "ridgefield-washington-greely-farms";
			add[1]="Ridgefield";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		else if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-ramble-creek-ridgefield-wa")) {
			comName = "ramble creek";
			add[1]="Ridgefield";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
/*		else if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-middlebrook-sherwood-oregon")) {
			comName = "middlebrook";
			add[1]="sherwood";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}*/
		else if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")) {
			comName="Stones-Throw";
			add[1]="Vancouver";
			add[2]="WA";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
			note = "Address & Lat-Long Taken From City & State";
		}
		

		else if(latlag[0]==ALLOW_BLANK || latlag[0]==null){
			latlag[0]=U.getSectionValue(comHtml, "\"lat\": ", ",");
	//		U.log("JJJ");
			latlag[1]=U.getSectionValue(comHtml, "\"lng\": ", "}");
			U.log(">>>>>>>lat  ::"+latlag[0]+"\tlng :"+latlag[1]);
		}
		if(latlag[0] == null && latlag[1] == null) {
			String latlngSec = U.getSectionValue(comHtml, "https://www.google.com/maps/embed/", "\"");
			if(latlngSec != null)latlngSec = Util.match(latlngSec, "\\d{2}\\.\\d{2,},-\\d{3}\\.\\d{2,}");
			if(latlngSec != null && latlngSec.contains(","))
				latlag = latlngSec.split(",");
		}
		
		if((add[0]==null||add[0]==ALLOW_BLANK) && latlag[0] != null) {	
			add=U.getAddressGoogleApi(latlag);
			U.log("LL");
			geo="TRUE";
		}

		
		add[0]=add[0].replace("NW Graham/257th & W Columbia River Hwy", "257th & W Columbia River Hwy");
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		
		
		//==========================floorplans===========================================
		
		String mainfloorUrl="https://holthomes.com/floorplans";
		String mainfloorHtml=U.getHtml(mainfloorUrl,driver);
		String floorHtml="";
		//U.log(U.getCache(mainfloorUrl));
		String floorSec=U.getSectionValue(mainfloorHtml, "<option value=\"\">Community</option>", "</select>");
		String floorJsonKey[]=U.getValues(floorSec, "value=\"", "\"");
		String floorValueOfKey[]=U.getValues(floorSec, "\">", "<");
	//	U.log(Arrays.toString(floorJsonKey));
	//	U.log(Arrays.toString(floorValueOfKey));
		for(int i=0;i<floorJsonKey.length;i++) {
			String keyUrl="https://holthomes.com/floorplans?fwp_community="+floorJsonKey[i];
			
			
			if(floorValueOfKey[i].contains(comName)) {
				String keyUrlHtml=U.getHTML(keyUrl);
				String floorUrls[]=U.getValues(keyUrlHtml, "<a href=\"https://holthomes.com/floorplans", "\">");
				for(String fu:floorUrls) {
					String floorUrl="https://holthomes.com/floorplans"+fu;
					U.log("floorUrl== "+floorUrl);
					floorHtml+=U.getHTML(floorUrl);
				}
			}
			
			
		}
		String floorSection =U.getSectionValue(comHtml, "<h2>Floor Plans</h2>", "<div class=\"anchor-target\" id=\"community-site-map\">");                    
		String[] florSec=null;
		if(floorSection!=null) {
			florSec = U.getValues(floorSection, "<div class=\"grid-item\">", "</div>"); //end </div>
		
		
		U.log("total floor= "+florSec.length);
		for(String floor : florSec) {
			
			floor = U.getSectionValue(floor, " <a href=\"", "\"");
			U.log("floor|: "+floor);
			floorHtml+=U.getHTML(floor);
		}
		}
		//========================available hoemss 
		
		String availhomesurl="https://holthomes.com/available-homes/";
		String availhtml=U.getHTML(availhomesurl);
		
		String homesurls[]=U.getValues(availhtml, "grid-item", "View Details")	;
		String availaurlhtml="";
for(String hu:homesurls) {
	//U.log(hu);
	String aurls=U.getSectionValue(hu, "href=\"", "\"");
//	U.log(aurls);
	try {
	String ahtml=U.getHTML(aurls);
	String cname=U.getSectionValue(U.getSectionValue(ahtml, "Communities:", "</div"),"<a href=\"\">","</").trim();
//	U.log("==="+cname);
//	U.log("====="+comName.trim());
	if(cname.contains(comName.trim())) {
	//	U.log("=dsfdg==="+comName);
		availaurlhtml+=ahtml;
	}
	}catch(Exception e) {}
	
	
}
		
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
	String rem=ALLOW_BLANK;
	rem=U.getSectionValue(comHtml, "All Available Homes in OR and WA", "");
	if(comHtml.contains("All Available Homes in OR and WA") && comHtml.contains("See All Homes</a>")) {
		rem=U.getSectionValue(comHtml, "All Available Homes in OR and WA", "See All Homes</a>");
		if(rem!=null) {
			comHtml=comHtml.replace(rem, "");
		}
		}
			
		
//		U.log("reMMM"+rem)}
	    
	   
			prices=U.getPrices(comHtml+floorHtml+availaurlhtml, "\\$\\d{3},\\d{3}", 0);
			
			U.log(Arrays.toString(prices));
//			 U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}\\$654[\\w\\s\\W]{30}",0));
//			 U.log(Util.matchAll(floorHtml, "[\\w\\s\\W]{30}\\$654[\\w\\s\\W]{30}",0));
//			 U.log(Util.matchAll(availaurlhtml, "[\\w\\s\\W]{30}\\$654[\\w\\s\\W]{30}",0));
			
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(comHtml+floorHtml, "\\d{4} Sq. Ft.|\\d{4}-\\d{4} SF|<dd>\\d{4}</dd>", 0);//floorHtml
			
			
			U.log(Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comHtml);
			U.log(cType);
			
			
			String pType=ALLOW_BLANK;
			pType = U.getPropType((comHtml+floorHtml+availaurlhtml).replaceAll("Villages|villages", ""));
//			 U.log(Util.matchAll(comHtml+floorHtml+availaurlhtml, "[\\w\\s\\W]{30}villa[\\w\\s\\W]{30}",0));
			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			
			dType = U.getdCommType(comHtml.replace("1 to 2-level homes", "1 Story to 2 Story")+floorHtml);
			U.log("dType::::::" + dType);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml+floorHtml, "[\\s\\w\\W]{30}1 to 2-level[\\s\\w\\W]{30}", 0));
			// =======================propertyStatus===================================
			

			String pStatus = ALLOW_BLANK;
			
			comHtml=comHtml.replace("[Coming 2023]","").replace("[Coming Soon]", "").replaceAll(">Move-In Ready<|\"Move-In Ready\"|in-ready-overview", "");
			floorHtml=floorHtml.replace("[Coming 2023]","").replace("[Coming Soon]", "").replaceAll(">Move-In Ready<|\"Move-In Ready\"|in-ready-overview", "");
			
//			comHtml=comHtml.replace("pageName: \"New homes coming", "").replaceAll("pageName: \"New homes coming", "");
			pStatus = U.getPropStatus((comHtml
					.replace("of quick move-in options", "")
					.replace("regarding phase 2 release", "").replace("New Homes Coming Soon to", "").replace("New homes coming soon to", "")+floorHtml+comSec).replaceAll("content=\"New Homes Coming|pageName: \"New homes coming", "").replaceAll("New phase of homes</strong> opening soon", "New phase opening soon").replaceAll("Homes Coming Soon to Troutdale|homes coming soon to Troutdale",""));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(comHtml, "[\\s\\w\\W]{30}new homes coming soon[\\s\\w\\W]{30}", 0));

			if(comUrl.contains("https://www.holthomes.com/communities/83/"))pStatus="Now Selling";
			if(comUrl.contains("https://www.holthomes.com/communities/laurel-woods/")) note="Now Pre-Selling";
//			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-ramble-creek-ridgefield-wa")) pStatus="Summer 2022";
			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-stones-throw-vancouver-washington")) pStatus="Coming 2023, Coming Soon";
//			if(comUrl.contains("https://lp.holthomes.com/new-homes-camas-washington-glades-green-mountain")||
//			comUrl.contains("https://lp.holthomes.com/new-homes-ridgefield-washington-greely-farms"))
//				if(pStatus==ALLOW_BLANK)
//					pStatus = "Spring 2022";// img
//					else
//						pStatus += ", Spring 2022";
			if(comUrl.contains("https://www.holthomes.com/communities/pleasant-valley-villages-homes-for-sale-in-happy-valley-or/"))pStatus=ALLOW_BLANK;
			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-ramble-creek-ridgefield-wa"))pStatus="Coming Soon";
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			
			
			
			//======================image status=================
		//	if(comUrl.contains("/communities/creekside-heights/"))pStatus="New Phase Coming Aug 2021";
//			if(comUrl.contains("communities/greely-farms/"))pStatus="Almost Sold Out";
//			if(comUrl.contains("https://holthomes.com/communities/teal-crest/")) {pStatus=pStatus+", Almost Sold Out";}
			
		
			
			
		
	//		if(comUrl.contains("/new-homes-lafayette-hearth-at-millican-creek"))pStatus="Coming July 2021, "+pStatus;
			pStatus=pStatus
					.replace("New Phase Open, New Phase Opening Soon", "New Phase Opening Soon")
					.replace("Homes Are Selling Quickly, Selling Quickly", "Homes Are Selling Quickly");
			
			//from image dt:27 jul 21
			if(comUrl.contains("https://www.holthomes.com/communities/the-glades-at-green-mountain/")) {
			pStatus+=", New Phase Coming Winter 2022";}
//			if(comUrl.contains("/pleasant-valley-villages"))pStatus="Now Selling";
			//if(comUrl.contains("/new-homes-troutdale-or-gateway-landing"))pStatus="Coming October 2021";
//			if(comUrl.contains("/communities/laurel-woods"))note="New Pre-Selling";
			if(comUrl.contains("https://www.holthomes.com/communities/east-mountain/")||
					comUrl.contains("communities/ponderosa-ridge/") ||
					comUrl.contains("/communities/faraday-hills/")) {
				pStatus="Now Selling";
			}
			if(comUrl.contains("https://holthomes.com/communities/middlebrook/")) {
				pStatus="Coming In 2022";
			}
			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-middlebrook-sherwood-oregon"))pStatus=pStatus+", Spring 2022";
//img
			
			//			if(comUrl.contains("https://holthomes.com/communities/creekside-heights/")) {
//				note="Now Pre-Selling";			
			//prices[0]="$500,960";
		//	prices[1]="$515,960";
			
		//	}
//			if(comUrl.contains("https://lp.holthomes.com/homes-for-sale-middlebrook-sherwood-oregon"))
//				pStatus+=", Coming 2022"	;		
				add[0] =add[0].replace("1011 Ne 13th St", "1011 NE 13th St");
				//if(comUrl.contains("https://www.holthomes.com/communities/83/")) note="Now Pre-Selling";	
			if(latlag[0]==null) {
				latlag[0]=ALLOW_BLANK;
				latlag[1]=ALLOW_BLANK;
			}
			if(add[0]==null ||add[0]==null ||add[1]==null ||add[2]==null ||add[3]==null ) {
				add[0]=ALLOW_BLANK;
				add[1]=ALLOW_BLANK;
				add[2]=ALLOW_BLANK;
				add[3]=ALLOW_BLANK;
				
			}
			data.addCommunity(comName.replace("&#x27;s", " &").trim(), comUrl, cType);
			data.addLatitudeLongitude(latlag[0].trim(), latlag[1].trim(), geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(U.getCapitalise(add[0].replace(",", "").toLowerCase()).trim(), add[1].trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus.replace("New Homes Coming Soon, Coming Soon", "New Homes Coming Soon"));
			data.addNotes(note);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			
			
	}
			j++;
			U.log("=================================="+j);
	
}
	public static String getUnits(String comHtml, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(comHtml.contains("class=\"interactive-site-map\"")) {
			
			String frameSec = U.getSectionValue(comHtml, "class=\"interactive-site-map\"", ">");
			U.log("frameSec: "+frameSec);
			
			if(frameSec != null) {
				frameUrl = U.getSectionValue(frameSec, "href=\"", "\""); 
				U.log("frameUrl: "+frameUrl);
				
				if(frameUrl.contains("contradovip.com")) {
					
					mapData = U.getHtml(frameUrl, driver);
					
					if(mapData.contains("<g id=\"v.1.opt.")) {
						
						ArrayList<String> lots = Util.matchAll(mapData, "<g id=\"v.1.opt.", 0);
						U.log("Count Pins: "+lots.size());
						totalUnits = String.valueOf(lots.size());
					}
					
				}
				
			}
		}
			return totalUnits;
	}
	
	
	
	
	
	
}