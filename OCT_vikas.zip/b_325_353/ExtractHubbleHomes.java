package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractHubbleHomes extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;

	public ExtractHubbleHomes() throws Exception {

		super("Hubble Homes", "https://www.hubblehomes.com/");
		LOGGER = new CommunityLogger("Hubble Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractHubbleHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Hubble Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		
		String mainHtml=U.getHTML("https://www.hubblehomes.com/new-homes");	
		String comSections[]=U.getValues(mainHtml, "item col-lg-3 col-md-4 col-sm-6 col-xs-12 text-center bottombuffersmall topbuffer", "<div class=\" itemincentivesavailablerow\">");
		//U.log(comSections.length);
		for(String comSec:comSections) {
		addDetails(comSec);
		}
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comSec) throws Exception {
		
		String comUrl="https://www.hubblehomes.com"+U.getSectionValue(comSec, "<a href=\"", "\"");
		//U.log(comUrl);
	
//		if(!comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/sunnyvale"))return;
		
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml=U.getHTML(comUrl);
		U.log(U.getCache(comUrl));
		
		String comName=U.getSectionValue(comSec, "style=\"padding-bottom:5px;\">", "</h3>");
		U.log(comName);
//		U.log("comSec===="+comSec);

		
	//======================================address=================================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String drivingDireHtm=U.getHTML(comUrl+"/driving-directions");
		
		U.log(U.getCache(comUrl+"/driving-directions"));
		
		
		
		
		String addSec=U.getSectionValue(comHtml, "Sales Center Location", "<div class=\"detaillinks\">");
		U.log("addSec=="+addSec);
		if(addSec!=null) {
			addSec=U.getSectionValue(addSec, "<br>", "<br><br>");
			if(addSec!=null) {
				addSec=addSec.replaceAll("Charlesworth Townhomes<br>", "").replace("<br>", ", ")
						.replace("ID,", ", ID")
						.replace("Sunnyvale,  15621 N Cultivar Ave", "15621 N Cultivar Ave")
						.replaceAll("Franklin Village,|Greendale Grove,|Southern Ridge, |Charlesworth,|Adams Ridge,|Temporary Sales Office at Eagle Stream,", "").trim();
			U.log("addSec=="+addSec);
			add=U.getAddress(addSec);
			}
		}
		
		
		latlag[0]=U.getSectionValue(drivingDireHtm, "\"LAT\":", ",");
		latlag[1]=U.getSectionValue(drivingDireHtm, "\"LONG\":", ",").replaceAll(" |\"", "");
		if(addSec==null) {
		add=U.getAddressGoogleApi(latlag);
		geo="TRUE";
		}
		
		U.log("Address=="+Arrays.toString(add));
		U.log("LatLong=="+Arrays.toString(latlag));
		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/caldwell/windsor-creek-east")) {
//			
//			String addSec2=U.getSectionValue(drivingDireHtm, "<strong>Community Location</strong><br>", "<br><br>");
//		   addSec2=addSec2.replace("Street", "Street,");
//		   add=U.getAddress(addSec2);
//		    U.log("AddSecc2:::"+Arrays.toString(add));
//		    if(add[3]==ALLOW_BLANK|| add[3]==null)
//		    {
//		    	add[3]=U.getAddressGoogleApi(latlag)[3];
//		    	geo="True";
//		    }
//		}
		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/kuna/greyhawk")) {
//			add[1]="Kuna";
//			add[2]="ID";
//			add[0]=U.getAddressGoogleApi(latlag)[0];
//		    add[3]=U.getAddressGoogleApi(latlag)[3];
//		    geo="True";
//		}
		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/southern-ridge")) {
//			String addSec2=U.getSectionValue(drivingDireHtm, "<strong>Community Location</strong><br>", "<br><br>");
//			   addSec2=addSec2.replace("Drive", "Drive,");
//			   add=U.getAddress(addSec2);
//			    U.log("AddSecc2:::"+Arrays.toString(add));
//			    if(add[3]==ALLOW_BLANK|| add[3]==null)
//			    {
//			    	add[3]=U.getAddressGoogleApi(latlag)[3];
//			    	geo="True";
//			    }
//		}
		U.log("Address=="+Arrays.toString(add));
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		//	U.log(comSec);
	     comSec=comSec.replace("0s", "0,000").replace("400’s ", "$400,000");
	      
			prices=U.getPrices(comSec+comHtml, ">\\$\\d{3},\\d{3}</div>|\\$\\d{3},\\d{3}", 0);
//			U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}378,990[\\w\\s\\W]{30}", 0));

			U.log("Price=="+Arrays.toString(prices));
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(comSec+comHtml, "\\d{1},\\d{3} -   \\d{1},\\d{3}|\\d{4} - \\d{4}", 0);
			
			U.log("sqft=="+Arrays.toString(sqft));
			
			
			
			String cType=U.getCommType(comHtml+comSec);
			U.log(cType);
			
			//=======================floors============================================
			
			String floorSec[]=U.getValues(comHtml, "item col-lg-3 col-md-4 col-sm-6 col-xs-12 text-center topbuffer bottombuffersmall", "</span>");
			String floorHtml="";
			String floorDesc="";
			for(String fs:floorSec) {
				String floorUrl="https://www.hubblehomes.com"+U.getSectionValue(fs, "<a href=\"", "\"");
				U.log("floorUrl=="+floorUrl);
				floorHtml=U.getHTML(floorUrl);
				if(floorHtml.contains("patio"))
					U.log("FOUND");
				floorDesc+=U.getSectionValue(floorHtml, "col-sm-6 col-xs-6", "col-md-3 col-sm-6 col-xs-6")+U.getSectionValue(floorHtml, "		<a name=\"elevations\" id=\"elevations\" class=\"anchor\"></a>", "Request Information</a></div>");
			}
			
			if(comHtml.contains("<div class=\"findahomedropdown-blue\"") && comHtml.contains("<div class=\"socialicons socialiconstopnav\">")) {
				//removing townhome
				String remove = U.getSectionValue(comHtml, "<div class=\"findahomedropdown-blue\"", "<div class=\"socialicons socialiconstopnav\">");
				
				comHtml = comHtml.replace(remove, "");
			}
			
			
			String pType=ALLOW_BLANK;
			comHtml=comHtml.replace("Patio%2D", "");
			pType = U.getPropType((comSec+comHtml+floorDesc)
					.replace("20Apartments%20", "")
					.replaceAll("%2DPatio%2D|Place Townhomes|Single-Family\\d{2}.pdf|new single-family ranch|Features Single-Family|Common Areas</p>|Included Features Multi-Family|Features Multi-Family Charlesworth.pdf", ""))
					.replace(",Multi-Family", ", Multi-Family")	.replace(",Townhome", ", Townhome")
					.replace(",Craftsman Style Homes", ", Craftsman Style Homes")
					.replace(",Patio Homes", ", Patio Homes")
					.replace(",Cottage", ", Cottage").replace(",Traditional Homes", ", Traditional Homes")
					.replace(",Apartment Homes", ", Apartment Homes");
		//	
			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
//			U.log("comSeccomSeccomSec===="+comSec);
			
			if(floorDesc!=null)floorDesc = floorDesc.replace("1.5-Story home", "one-and-one-half story");
			dType = U.getdCommType((comSec+floorDesc)).replace(",2 Story",", 2 Story").replace(",1.5 Story",", 1.5 Story");
			U.log("dType::::::" + dType);
			U.log(Util.matchAll(comSec, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0));
			// =======================propertyStatus===================================
			U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0));

			U.log(Util.matchAll(floorDesc, "[\\w\\s\\W]{30}patio[\\w\\s\\W]{30}",0));


			String pStatus = ALLOW_BLANK;

			comHtml=comHtml.replace("Phase #5 Now Available on iReserve", "Phase 5 Now Available on iReserve")
					.replace("Final phase of Silverstone coming Spring 2021", "Final phase coming Spring 2021").replaceAll("<strong>Coming this Summer:</strong><br />|<li>All Quick Move-In</li>|Hubble Homes now selling in Nampa|>Quick Move-In<|hospital coming soon|School &ndash; opening fall 2021|Visit Quick Move-In for|QUICK MOVE-IN</a>|Visit Quick Move-In Homes Pag|0 Quick Move-In|Hubble Homes coming soon", "");
			comSec=comSec.replace("Quick Move-In", "") //removing for status from homesCount
					.replaceAll("<li>All Quick Move-In</li>|>Quick Move-In<|Visit Quick Move-In for|QUICK MOVE-IN</a>|Visit Quick Move-In Homes Pag|0 Quick Move-In", "");
			pStatus = U.getPropStatus((comHtml+ comSec));
			
//			U.log(Util.matchAll(comSec+comHtml, "[\\w\\s\\W]{30}Quick Move[\\w\\s\\W]{30}",0));
			
			if(pStatus.contains("Sold Out, Current Phase Sold Out")) pStatus = pStatus.replace("Sold Out, Current Phase Sold Out", "Current Phase Sold Out");
			if(pStatus.equals("New Phase Coming Summer 2022, New Phase Coming Summer, Coming Soon")) pStatus = pStatus.replace("New Phase Coming Summer 2022, New Phase Coming Summer, Coming Soon", "New Phase Coming Summer 2022, Coming Soon");
			
		//if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/meridian/prescott-ridge"))pStatus="Coming 2022";
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/meridian/hensley-station"))pStatus="Final Phase Selling Fast, Now Selling";
		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/caldwell/windsor-creek-east"))
//			{
//			       pStatus="Final Phase Now Selling";		
//			}
		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/kuna/greyhawk"))
//		{
//			pStatus="Final Phase Now Selling";
//		}
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/covey-run"))
//				pStatus="Final Phase Selling Fast, Now Selling";	
//		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/caldwell/mason-creek"))
//		{
//			pStatus=pStatus.replace("New Phase Coming 2022, New Phase Coming 2022","New Phase Coming 2022");
//		}
//		
//		if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/middleton/crossings-at-meadow-park"))
//		{
			pStatus=pStatus.replace("New Phase Now Selling, Now Selling","New Phase Now Selling");
//		}
		
			U.log("status:::::::" + pStatus);

			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;

			
			
		//	if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/caldwell/windsor-creek-east"))add[0]="12547 Herrick Street";
//			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/meridian/hensley-station"))add[0]="462 N Black Cat Road";
			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/adams-ridge"))add[0]="17880 Sunset Ridge Ave";
			//if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/southern-ridge"))add[0]="3664 E Warm Creek Ave";
//			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/mountain-home/silverstone"))pStatus=pStatus.replace("Coming Spring 2021, Quick Move-in, Final Phase", "Final Phase Coming Spring 2021, Quick Move-in");
		    //Sttaus from images 28Aug21
		//	if(comUrl.contains("/boise-metro/middleton/crossings-at-meadow-park"))pStatus = "New Phase Coming 2022";
//		    if(comUrl.contains("/boise-metro/caldwell/windsor-creek-east"))pStatus="New Phase Coming Fall 2021";
		    if(comUrl.contains("/boise-metro/mountain-home/silverstone"))pStatus =pStatus.replace("Selling Fast,", "");
		    
		    //			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/adams-ridge")){
//				
//				pStatus="Now Available For Phase 3, Quick Move-in";
//			}
		    String commHtml=U.getHTML(comUrl);
		    String QuickSec=U.getSectionValue(commHtml, "All New Home Listings", "<div class=\"container-fluid graydivider\">");
		    if(QuickSec!=null) {
		    if(QuickSec.contains("Sorry, no homes match your criteria."))
		    {
		    	if(pStatus.length()<1)
		    	{
		    		pStatus=ALLOW_BLANK;
		    	}
		    	else
		    		pStatus=pStatus.replaceAll(", Move-in-ready|Move-in-ready",ALLOW_BLANK);
		    }
		    }
		    U.log(">>>>> pStatus: "+pStatus);
		    String quickSec=U.getSectionValue(comSec, "communityspecsquickmovein\">", "</div>").trim();
		    U.log("quickSec.length: "+quickSec.length());
		    
//		    if(!quickSec.contains("0 Quick Move-In") && !pStatus.contains("Quick Move") && quickSec.length()>0)
		    
		    //home section for status
		    String homeData = ALLOW_BLANK;
		    int homesCount = 0;
		    
		    if(comHtml.contains("<div data-mh=\"LinkName\">") && comHtml.contains("Get Info</a>")) {
		    	
		    	String[] homeSec = U.getValues(comHtml, "<div data-mh=\"LinkName\">", "Get Info</a>");
		    	
		    	for(String home:homeSec) {
		    		
		    		if(home.contains("Ready Now"))  homesCount++;
		    		
		    	}
 		    }
		    
		    U.log("homesCount: "+homesCount);
		    
		    if(homesCount > 0 && !pStatus.contains("Quick Move")) {
		    	
		    	if(pStatus.length()>2) {	
		    		pStatus=pStatus+", Quick Move-In";
		    	}
		    	else
		    		pStatus="Quick Move-In";
		    }
		    U.log("pStatus: "+pStatus);
		    if(pStatus.contains("Move-in-ready"))pStatus=pStatus.replace("Move-in-ready", "Quick Move-In Homes");
			//if(comUrl.contains("/idaho/boise-metro/kuna/greyhawk"))pStatus=pStatus.replace("Now Selling", "Now Selling Final Phase");
			
			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/covey-run"))pType="Patio Homes, Apartment Homes, Townhome, Fourplex";
			
			
			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/star/reflection-at-greendale-grove"))
				pType="Loft, Patio Homes, Cottage, Townhome, Luxury Homes";
			
//			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/boise/broadview-place"))
//				prices[0]="$300,000";
			
			if(comUrl.contains("https://www.hubblehomes.com/new-homes/idaho/boise-metro/nampa/sunnyvale"))
			pStatus=pStatus.replace("Coming In 2022, New Phase Coming In 2022,", "New Phase Coming In 2022,");
			
			pStatus=pStatus.replace("New Phase Coming Summer 2022, New Phase,", "New Phase Coming Summer 2022,");

			//========siteplan
			String noOfUnits=ALLOW_BLANK;
			if(comHtml.contains("Interactive Sitemap")) {
				U.log("Hello");
			 noOfUnits=getUnits(comUrl+"/interactive-site-plan");
		    }
			U.log("Number of Units:: "+noOfUnits);
			
			data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType.replace("1.5 Story, 5 Story", "1.5 Story"));
			data.addPropertyStatus(pStatus);
			data.addNotes(U.getnote(comHtml));
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
			data.addUnitCount(noOfUnits);
			
			
			
			
			j++;
			U.log("=================================="+j);
			
			
	}

	private String getUnits(String url) throws IOException {
		String siteMapHtml=U.getHTML(url);
		U.log("Pth:: "+U.getCache(url));
		String lotData[]=U.getValues(siteMapHtml, "<a class=\"various\"  aria-label=\"View Details for this lot\"", "</a>");
		int lotCount=lotData.length;
		 String noOfUnit=Integer.toString(lotCount);
		 if(noOfUnit.equals("0"))
			 return ALLOW_BLANK;
		 else 
			 return noOfUnit;
		
		
	}
}