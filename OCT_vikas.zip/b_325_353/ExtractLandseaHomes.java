 package com.shatam.b_325_353;
import java.util.ArrayList;
/**
 * @author MJS
 * @date 30/03/2021 
 * 
 */
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLandseaHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null;
	static String builderUrl = "https://landseahomes.com";

	public ExtractLandseaHomes() throws Exception {
		super("Landsea Homes", builderUrl);
		LOGGER = new CommunityLogger("Landsea Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractLandseaHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "Landsea Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		// TODO Auto-generated method stub
	//	String html = U.getHTML("https://landseahomes.com/");
		String[] mainSec = {"arizona-communities", "florida", "nyc-metro","northern-california","southern-california", "texas"};
		
		//	https://landseahomes.com/homefinder-results?region=nyc-metro&price=all&beds=all&type=all&qmi=false&mpc=false
		for(String regU : mainSec) {
			String regionUrl="https://landseahomes.com/homefinder-results?region="+regU+"&price=all&beds=all&type=all&qmi=false&mpc=false";
		    U.log("region Url"+regionUrl);
			//	if(!regionUrl.contains("region="))continue;
			
				getCommunity(regionUrl);
			

		}
		LOGGER.DisposeLogger();
//		driver.quit();
	}

	private void getCommunity(String regionUrl) throws Exception {
		
//		if(!regionUrl.contains("https://landseahomes.com/homefinder-results?region=arizona-communities&price=all&beds=all&type=all&qmi=false&mpc=false")) return;
		// TODO Auto-generated method stub
		//New York ⊶ Förena
		//Landsea at Ellis
		//IronRidge
		//neuhouse
		//ShadeTree
		//44
//		U.log("regionUrl==="+regionUrl);
		
		String html = U.getHTML(regionUrl);
		String[] mainSec = U.getValues(html, "<div id=\"poi", "</div>\n" + 
				"</div>");
//		U.log("main Sec comUrl.length"+mainSec.length);
		String latlngSec=U.getSectionValue(html, "var results = [", "</script>");
		LOGGER.AddRegion(regionUrl, mainSec.length);
		
		for(String main : mainSec) {
			//U.log("MAIN"+main);
			String comUrl = U.getSectionValue(main, "<a href=\"", "\"");
			
//			U.log("comUrl===="+comUrl);
			String comHtml = U.getHTML(comUrl);
			
			//U.getSectionValue(comHtml, " <h2 class=\"text-center\">Communities Near	", "<h2>Call for Information</h2>")
			
	//Using the below condition for getting data of subcomms. from comm.page.		
			if(comHtml.contains("<section id=\"communities")) {
				
				String overview = U.getSectionValue(comHtml, "<section id=\"overview\" class=\"text-center\">", "</section>");
				//neighbourhoods on community page
				String neighbourhood = U.getSectionValue(comHtml, "<section id=\"communities", "</section>");
				
				String[] subCom = U.getValues(neighbourhood, "<div class=\"community col-md-6\">", "\">Learn More");
//				U.log("SUB COM COUNT:  "+subCom.length);
				//LOGGER.AddSubRegion(comUrl, subCom.length);

				
				for(String sub : subCom) {
					
					String subcomUrl = U.getSectionValue(sub, "<a href=\"", "\"");
//					U.log("SUBCOM URL:  "+subcomUrl);
					//sub is data of sub community from comm.page
					//main is data about community from region page
					
//						getDetail(subcomUrl, main+overview+sub,"");
						getDetail(subcomUrl, overview+sub,"");
					  
					
				}
			}
			else {
//				U.log("Main URL:  "+comUrl);
				
					getDetail(comUrl, main,latlngSec);
				
				
		}
			
		}

	}

	private void getDetail(String comUrl, String com,String latlngSec) throws Exception {
		// TODO Auto-generated method stub
//		try {
//		if(!comUrl.contains("https://forenanyc.com/"))return;
//		if(!comUrl.contains("https://landseahomes.com/arizona/maricopa-county-west-valley/waddell/northern-farms/"))return;
//		if(j>=52)
//			if(j>=67)
		{
		U.log("Count: " + j + "\t" + comUrl);

	
		//Returning redirected builders
		if(comUrl.contains("hanoverfamilybuilders")) {
			LOGGER.AddCommunityUrl(comUrl+ "--------------------------- Redirected to Hanover Family Builders");
			return;
		}
		
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			// ============================================Community
			// name=======================================================================
			
			String communityName = U.getSectionValue(com, "<h2 class=\"community-title\">","<");
			if(communityName==null)
				communityName = U.getSectionValue(com,"<h3 class=\"title\">", "<");
			if(communityName==null)
				communityName = U.getSectionValue(html,"</div>\n" + 
						"                <h1>", "<");
			if(comUrl.contains("https://landseahomes.com/northern-california/landsea-at-ellis/"))communityName="Landsea At Ellis";
			if(comUrl.contains("maricopa-county-west-valley/waddell/northern-farms/"))communityName="Northern Farms";

			if(communityName!=null) {
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replace("&#8217;", "'").replace("&#8211;", "-");
			communityName=communityName.replace("Model", "");
			}
			if(communityName==null)
				communityName = U.getSectionValue(com,"data-name=\"", "\"");
			U.log("community Name---->" + communityName);
			
			//reomve Section
			String[] footerSecRemove=U.getValues(html, "<div class=\"d-flex\">", "</div></div>");
			if(footerSecRemove.length>0) {
				for(String removeSec:footerSecRemove) {
					if(!removeSec.contains(communityName)) {
						html=html.replace(removeSec, "");
					}
				}
			}
//			U.log("com---->" + com);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";
			
			
			
			
			String addSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place","/a>");
			U.log("addSec0: "+addSec);
			if (addSec == null)
				addSec = U.getSectionValue(html, "<a href=\"https://goo.gl/maps", "/a>");
			U.log("addSec1: "+addSec);
			if(addSec==null)	
				addSec=U.getSectionValue(html, "<h2>Call for Information</h2>","</a>");
			U.log("addSec2: "+addSec);
			if(addSec==null)	
				addSec=U.getSectionValue(html, "<a href=\"https://www.google.com/maps/dir","a>");
			U.log("addSec3: "+addSec);
			if(addSec==null)	
				addSec=U.getSectionValue(html, "<a href=\"https://www.google.com/maps","a>");
			U.log("addSec4: "+addSec);
			if(addSec==null)	
				addSec=U.getSectionValue(html, "Visit Today</p>","a></p>");
			
			if(comUrl.contains("el-cidro-valley-series/"))
			{
				U.log("YYYYYYYYYYYY");
				addSec=U.getSectionValue(html, "<h2>Call for Information</h2>","<br>");
			}
			
			if (addSec != null) {
				addSec = addSec.replace("/AzDDrVUThGUrzjL29\">", "rel=\"noopener\">");
				
				addSec = addSec
						.replaceAll("<br />\\s*Located at the corner of S\\. Archibald Ave\\. and Merrill Ave\\. in Ontario", "");
				addSec = U.getSectionValue(addSec.replace("<br />", ",").replace("<br>", ", "), "rel=\"noopener\">", "<");
				U.log("addSec====: "+addSec);
				if(addSec != null)
					
				add = U.getAddress(addSec);
				U.log("Address 1"+Arrays.toString(add));
				
			}
			if(add[0] != null) add[0] = add[0].replace("S. 107th Ave. &amp; W. Lower Buckeye Rd., ", "");
			
			if(add[0].contains("Cross Streets:"))
			{
				add[0]=add[0].replace("Cross Streets:", "");
			}
		
//			if(comUrl.contains("maricopa-county-west-valley/surprise/sunrise/sunrise-peak-series/"))
//			{
//				
//			}
			
			U.log("addSec1==="+addSec);
			if(addSec==null) {
				if(html.contains("<p class=\"footer__address\">")) {
				addSec=U.getSectionValue(html, "<p class=\"footer__address\">","</p>").trim();
				U.log("addSec==="+addSec);
				if(addSec!=null)
					add=U.getAddress(addSec);
				}
			}

			
			

			// --------------------------------------------------latlng----------------------------------------------------------------
			
			String latSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");
		
			if(addSec==null && latSec!=null) {
				addSec=U.getHtmlSection(latSec, "7711", "/");
				if(addSec!=null) {
					addSec=addSec.replace("+", " ").replace("/", "");
					U.log("From Lat Long :: "+addSec);
				}
				if(addSec!=null) {
					add=U.getAddress(addSec);
				}
			}
		
			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);
			if(latSec!=null) {
				
				U.log("latSec: "+latSec);
				latSec = Util.match(latSec, "\\d+\\.\\d+,-\\d+\\.\\d+");
				if(latSec!=null)
					latLng = latSec.split(",");
				U.log("1st lat long"+Arrays.toString(latLng));
				
			}
			if(latSec == null && (add[0]==null ||  add[0]==ALLOW_BLANK)){
				 
				latSec = U.getSectionValue(html, "href=\"https://www.google.com/maps/place/", "\"");
				if(latSec != null)
				 latSec = Util.match(latSec, ".*/data");
				
					
				if(latSec!=null) {
					
					U.log("AddlatSec: "+latSec);
					latSec = latSec.replace("+", " ").replace("/data", "");
					add = U.getAddress(latSec);
					U.log(Arrays.toString(add));
				}
			}
			
			
			if(latSec == null)
			{
				if(latlngSec.length()>4) {
				String [] latlngData=U.getValues(latlngSec, "{\"name\":", "\"img\":") ;
				if(latlngData.length>0)
				{
					for(String latData :latlngData) {
						if(latData.contains(communityName))
						{
							U.log("latData==="+latData);
							latLng[0]=U.getSectionValue(latData, "\"lat\":\"", "\",");
							latLng[1]=U.getSectionValue(latData, "\"lng\":\"", "\",");
						}
					}
				}
				}
			}
			String lotCount=ALLOW_BLANK;
			String[] mapData=null;
			String [] latData=null;
			String mapHtml=ALLOW_BLANK;
			String iframeLink=U.getSectionValue(html, "<iframe loading=\"lazy\" data-src=\"", "\"");
			U.log(">>>>>>>>>>>>>>"+iframeLink);
			if(iframeLink!=null)
			{
				if(iframeLink.contains("site-maps.html")) {
					mapHtml = U.getHtml(iframeLink, driver);
					String [] links=U.getValues(mapHtml, "iframe.innerHTML = '<iframe src=\"", "\"");
					U.log(">>>>>>>>>>>>>>"+links.length);
					if(links.length>0) {
						for(String linkData : links) {
							
							mapHtml+= U.getHtml(linkData, driver);
							
						}
						lotCount=	getUnits(mapHtml,latData);
					}
				}
				else {
					mapHtml = U.getHtml(iframeLink, driver);
				lotCount=	getUnits(mapHtml,latData);
				}
			
			}
			
			
			if(latLng[0]==ALLOW_BLANK&&iframeLink!=null&&!iframeLink.contains("site-maps.html")) {
				U.log(iframeLink.replace("NEXT/sp/im/?propertyID=", "focus360API/assets/")+"/VicinityMapHTML/vicinity.json");
				String mapjsonUrl=ALLOW_BLANK;//21230_A_ValleySeriesAtElCidro
				if(iframeLink.contains("VicinityMapHTML")) {
					mapjsonUrl=iframeLink.replace("NEXT/sp/im/?propertyID=", "focus360API/assets/")+"vicinity.json";
				}else {
					mapjsonUrl=iframeLink.replace("NEXT/sp/im/?propertyID=", "focus360API/assets/")+"/VicinityMapHTML/vicinity.json";
				}
				if(iframeLink.contains("21029_A_Kinbridge")||iframeLink.contains("21030_A_Hartwell"))mapjsonUrl="https://apps.focus360.com/focus360API/assets/21028_A_Townsend/VicinityMapHTML/vicinity.json";
				if(iframeLink.contains("21231_A_PeakSeriesAtElCidro"))mapjsonUrl="https://apps.focus360.com/focus360API/assets/21230_A_ValleySeriesAtElCidro/VicinityMapHTML/vicinity.json";
				String mapHtmlJson=U.getHTML(mapjsonUrl);
//				U.log(mapHtmlJson);
				latSec=U.getSectionValue(mapHtmlJson, "\"defaultLatLongStr\": \"", "\"");
				latLng=latSec.split(",");
			}
			
			
			if((latLng[0] == null || latLng[0] == ALLOW_BLANK) && (add[0]==null ||  add[0]==ALLOW_BLANK))
			{
				addSec = U.getSectionValue(com, "<div class=\"location\">", "<");
//				if(comUrl.contains("maricopa-county-west-valley/avondale/alamar/riata-at-alamar/"))
//				{
//					addSec="Avondale, AZ";
//				}
				if(addSec==null) {
					addSec = U.getSectionValue(html, "<title>", "Homes For Sale - Landsea Homes</title>");
					if(addSec!=null)
						addSec=addSec.replace("AZ", ",AZ");
				}
				if(addSec==null) {
					addSec = U.getSectionValue(html, "<div class=\"city\">", "</div>");
					if(addSec!=null) {
						if(addSec.contains("North Fontana")) {
							addSec=addSec+", CA";
						}
					}
					if(addSec!=null) {
						if(addSec.contains("Avondale")) {
							addSec=addSec+", AZ";
						}
					}
				}
				
				U.log("addSec "+addSec);
				String[] add1 = addSec.split(",");
				add[0] = ALLOW_BLANK;
				add[1] = add1[0];
				add[2] = add1[1];
				add[3] = ALLOW_BLANK;
				
				latLng = U.getlatlongGoogleApi(add);
				if(latLng!=null)
					add = U.getAddressGoogleApi(latLng);
				
				geo = "TRUE";
			}
			
			
				
					
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}
			
//			if(comUrl.contains("https://landseahomes.com/arizona/northern-farms"))add[0]="N Cortessa Pkwy";

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);
			if(add[0].contains("Cross Streets:"))
			{
				add[0]=add[0].replace("Cross Streets:", "");
			}
			
			// ============================================Price and
			// SQ.FT======================================================================
			//=========== removing improper section
			if(comUrl.contains("https://forenanyc.com")) {
				String remove = U.getSectionValue(html, "<select name=\"formdata_price_range\" id=\"price-range\"", " </select>");
				html = html.replace(remove,"");
				com = com.replace("</span> – $1,500,000<span class", "");
			}

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0'S|0's|0's|0Â’s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
					.replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0Â’s|0's", "0,000");
			
			
			
			
			html = html.replace("0s", "0,000");
//			U.log("com===="+com);
			String prices[] = U.getPrices(com + html , "<div class=\"price-number\">\\$\\d,\\d{3},\\d{3}|<p>\\s*\\$\\d,\\d{3},\\d{3} \\s*</p>|\\$\\d,\\d{3},\\d{3}</div>|\\$\\d{3},\\d{3}|– \\$\\d,\\d{3},\\d{3}|LOW \\$\\d{3},\\d{3}|FROM THE \\$\\d{3},\\d{3}|THE MID \\$\\d{3},\\d{3}|<div class=\"price-number\">\\$\\d{3},\\d{3}<span class=\"s\">s</span> â€“ \\$\\d{3},\\d{3}<|<div class=\"price-number\">\\$\\d{3},\\d{3}<span class=\"s\">s</span> â€“ \\$\\d,\\d{3},\\d{3}<|<p>\\$\\d,\\d{3},\\d{3}<br />|From the \\$\\d,\\d{3},\\d{3} Millions|Priced From:</strong> \\$\\d,\\d{3},\\d{3}|Priced From:</strong> \\$\\d{3},\\d{3}<|<div class=\"price-number\">\\$\\d{3},\\d{3}<", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			
			U.log("Price--->" + minPrice + " " + maxPrice);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(com, "[\\s\\w\\W]{30}\\$795[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}\\$795[\\s\\w\\W]{30}", 0));
			
			// ======================================================Sq.ft===========================================================================================
		
//			U.log("com========"+com);
			String[] sqft = U.getSqareFeet(com.replace(" 17 distinct floor plans ranging from 1,315 to 3,240 square feet and local attractions", "") + html,
					"\\d,\\d{3} to over \\d,\\d{3} square feet|\\d,\\d{3} – \\d,\\d{3}|\\d,\\d{3} SF \\||\\d+ SF \\||<strong>\\d{3} – \\d{1},\\d{3}</strong>|\\d{3} to \\d,\\d{3} square feet|\\d,\\d{3} to \\d,\\d{3} sq. ft. |<strong>\\d{3} â€“ \\d,\\d{3}</strong>|\\d,\\d{3} SF \\||\\d,\\d{3} to \\d,\\d{3} square feet|<div class=\"details\">\n\\s*\\d,\\d{3} â€“ \\d,\\d{3}\\s*</div>|Square Feet:</strong> \\d,\\d{3}<|<strong>\\d,\\d{3} â€“ \\d,\\d{3}</strong>",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);
//			U.log(">>>>>>>>>>>>"+Util.matchAll(com, "[\\s\\w\\W]{30}1,315[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}1,315[\\s\\w\\W]{30}", 0));
			// ================================================community
			// type========================================================
			html = html.replace("many lakefront", "Lakefront Community").replace("entry gates", "Gated Community");
			
			String communityType = U.getCommType((html + com).replaceAll("Country Club Estates</a>|country-club-estates/\"|Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""))
					.replace(",55+ Community", ", 55+ Community").replace(",Active Adult", ", Active Adult")
					.replace(",Master Planned", ", Master Planned").replace(",Resort Style", ", Resort Style")
					.replace(",Gated Community", ", Gated Community")
					.replace(",Country Club", ", Country Club");
			U.log("CTYPE: "+communityType);

			// ==========================================================Property
			// Type================================================
			html = html.replace("life luxurious", "Luxury Homes");
			String proptype = U.getPropType((html + com ).replaceAll("cypress-hammock-townhomes|Cypress Hammock Townhomes|courtyards-at-waterstone|The Courtyards at Waterstone",""))
					
					.replace(",Courtyard Home",", Courtyard Home")
					.replace(",Patio Homes",", Patio Homes")
					.replace(",Duplex",", Duplex")
					.replace(",Detached Home",", Detached Home")
					.replace(",Luxury Homes",", Luxury Homes")
					.replace(",Condominium",", Condominium")
					.replace(",Traditional Homes",", Traditional Homes").replace(",Traditional Homes",", Traditional Homes");
			
			U.log("proptype: "+proptype);
			
			// ==================================================D-Property
			// Type======================================================
			html = html.replace("air on the second-floor deck", "two story").replace("convenient second-floor", "two story");
			String dtype = U.getdCommType((html + com).replaceAll("Creek Ranch|-ranch|Deerlake Ranch|Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
					+ communityName)	.replace(",2 Story",", 2 Story").replace(",3 Story",", 3 Story")
					.replace(",Ranch",", Ranch");
			U.log("D PT: "+dtype);
			
			// ==============================================Property Status
			// =========================================================

			html = html
					.replaceAll("quick move-ins|closeout pricing|close-out pricing|actively selling|Actively Selling|Coming Soon Homebuyer", "")
					.replaceAll("Club Homes Now Available|now available in Phase 2 of St. Johns Preserve","").replaceAll("<div class=\"sold-ribbon sold-out\">SOLD OUT</div>|ready to move in summer|new phase in Bulow Creek|>Now Selling</div>|Model Home Now Selling|Sales Office is Now Open|<div class=\"status\">Coming Soon</div>|Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|<div class=\"sold-ribbon sold-out\">SOLD OUT</div>|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming|at Catalina is now|AZ new homes available", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available").replaceAll("<div class=\"status\">COMING SOON</div>|<div class=\\\"status\\\">limited availability</div>", "<div class=\"status\"></div>")
					.replaceAll("Homes Coming Soon Arizona - Rev at Eastmarcoming soon! </strong>", "</strong>")//.replaceAll("<div class=\"status\">Now Selling</div>", "now\\sselling")
					.replaceAll("Homes Coming Soon Arizona - Rev at Eastmar|This community is now selling remotely", "");
			
			com = com
					.replaceAll("Quick Move-Ins|quick move-ins|actively selling|Coming this summer, join interest list", "")
					.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("his community is now selling remotely|Model Home Now Selling|Coming soon, neuhouse", "");
			
			
			String html1=U.getSectionValue(html, "<section id=\"intro\" class=\"intro-module\">", "</section>");
			
			String pstatus = U.getPropStatus((html1 + com).replaceAll("Move|move|MOVE", "").replaceAll("two-car garage.  Available Early 2022|Temporary Sales Trailer is Opening Soon|Homes Coming Soon Arizona - Rev at Eastmark - Landsea Homes<|new parcels coming soon|class=\"status \">FINAL OPPORTUNITY</div>",""));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(com, "[\\s\\w\\W]{30}quick move-ins[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>>"+Util.matchAll(html, "[\\s\\w\\W]{30}quick move-ins[\\s\\w\\W]{30}", 0));
			
			
			if(comUrl.contains("https://landseahomes.com/florida/redtail/"))
			{
				pstatus="Quick Move-In Homes";
			}
			if(comUrl.contains("northern-california/verandah/"))pstatus="Now Selling";
			if(comUrl.contains("https://landseahomes.com/the-villages-at-north-copper-canyon/legacy-series/")) pstatus = pstatus.replace(", Coming Soon", "");
			U.log("STATUS: "+pstatus);
			
			// ============================================note====================================================================
       //if(comUrl.contains("https://landseahomes.com/northern-california/verandah/"))pstatus=pstatus.replace("Now Selling", "New TownHomes Now Selling");

			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
			
			String qHtml = U.getSectionValue(html, "<section id=\"qmis\" class=\"teaser-grid\">", "</section>");
			if(qHtml==null)
				qHtml = "";
			String[] movSec = U.getValues(qHtml, "<div class=\"grid-item", "Learn More</a>");
			U.log("STATUS-1: "+movSec.length);
			int soldCount = 0;
			for(String val : movSec)
				if(val.contains("SOLD</div>"))
					soldCount++;
			
			if(movSec!=null && movSec.length>soldCount)
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-In Homes";
				else if(!pstatus.contains("Quick Move-") ) 
					pstatus += ", Quick Move-In Homes";
			
			U.log("STATUS-1: "+pstatus);
			
			if(comUrl.contains("https://landseahomes.com/arizona/madison-square/")) {
				add[0]="22 W Washington St";
				add[1]="Phoenix";
				add[2]="AZ";
				add[3]="85004";
				
			}
			if(comUrl.contains("https://landseahomes.com/ironridge/copperleaf")) {
				add[0]="22 W Washington St";
				add[1]="Phoenix";
				add[2]="AZ";
				add[3]="85004";
				
				latLng=U.getlatlongGoogleApi(add);
				//add=U.getAddressGoogleApi(latLng);
				note="Address Taken From City And State";
				geo="TRUE";
			minPrice=ALLOW_BLANK;
			}
			if(comUrl.contains("https://forenanyc.com")) {
				communityName="Forena";
				//dtype="12 Story";
//				minSqft="782";
//				maxSqft="1659";
//				minPrice = "$1,495,000";
//				maxPrice = "$4,950,000";

			}
			
			//latlng is not present on map url, but when cursor hover on map link, it show latlng, so it take as geo False.
			//if(comUrl.contains("https://landseahomes.com/estrella/vidrio-in-estrella/"))geo = "False";  
		if(comUrl.contains("https://landseahomes.com/verrado/marketside-tercera-at-verrado")) {
			minPrice="$342,900";
			maxPrice="$489,560";
			pstatus="Quick Move-In Homes";
		}
//		if(comUrl.contains("https://212w93.com")) {maxPrice="$4,635,000"; maxSqft = "2048";}
		
		if(comUrl.contains("https://landseahomes.com/northern-california/lavender/")) 
		{
			maxSqft="2011";
		}
		if(comUrl.contains("https://landseahomes.com/verrado/skye-ridge-at-victory/")) 
		{
			pstatus="Quick Move-In Homes";

		}
		
		
				if(comUrl.contains("maricopa-county-west-valley/surprise/sunrise/sunrise-peak-series/")) 
				{
					latLng[0]="33.7291713";
					latLng[1]="-112.4252733";
				}
		
		if(comUrl.contains("/st-cloud/sky-lakes-estates/")) note ="Now Pre-Selling";
		if(comUrl.contains("https://forenanyc.com/")) dtype = "12 Story";
		
		
//		==================================================================================
		
		U.log("lotCount===="+lotCount);
		
		
		
		
		
			//=========================================================================================================================
			data.addCommunity(communityName.replace(",", ""), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim().toLowerCase(), add[1].trim().toLowerCase(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus.replace("Final Homes Now Selling, Now Selling", "Final Homes Now Selling"));
			data.addNotes(note);
			data.addUnitCount(lotCount);
			data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		}
		
//		}catch(Exception e){}
		}j++;
	}
	
public static String getUnits(String mapHtml,String[] latData) throws Exception {
		
		String totalUnits = ALLOW_BLANK;
		String mapdata = ALLOW_BLANK;
		
			
			String[] mapSec=U.getValues(mapHtml, "<div id=\"FocusSitemapSVGpanzoom\"", "<g id=\"footprints\"");
			U.log(">>>>mapSec>>>>>>>>>>"+mapSec.length);
			if(mapSec.length==0) {
				 mapSec=U.getValues(mapHtml, "<div id=\"FocusSitemapSVG", "</svg>");
			}
			U.log(">>>>mapSec>>>>>>>>>>"+mapSec.length);
			if(mapSec.length>0) {
				for(String mapData : mapSec) {
					mapdata+=mapData;
				
				}
				latData=U.getValues(mapdata, "<g id=\"lot_", "</g>");
			}
			
				totalUnits = Integer.toString(latData.length);
		
		return totalUnits;
	}
	
	
	
	
	
	
	
	
	
	

}