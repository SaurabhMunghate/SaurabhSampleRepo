package com.shatam.b_325_353;

import java.util.Arrays;

import org.openqa.selenium.WebDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractLokalhomes extends AbstractScrapper {
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver = null;

	public ExtractLokalhomes() throws Exception {

		super("Lokal Homes", "https://www.lokalhomes.com/");
		LOGGER = new CommunityLogger("Lokal Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractLokalhomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Lokal Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		String mainHtml = U.getHTML("https://www.lokalhomes.com/communities");
		String comSections[] = U.getValues(mainHtml, "mb-3 mb-lg-0", "View Details");
		for (String comSec : comSections) {

//			try {
				addDetails(comSec);
//			} catch (Exception e) {}

		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comSec) throws Exception {

		U.log("=========================" + j);
		// U.log(comSec);

		String comUrl = "https://www.lokalhomes.com" + U.getSectionValue(comSec, "href=\"", "\"");
		U.log(comUrl);

		//TODO:
//		if(!comUrl.contains("https://www.lokalhomes.com/communities/fort-collins/the-reserve-at-registry-ridge"))return;

		LOGGER.AddCommunityUrl(comUrl);
		String comHtml = U.getHTML(comUrl);
		String rmsec = U.getSectionValue(comHtml, "window.__PRELOADED_STATE__", "</html>");
		comHtml = comHtml.replace(rmsec, "");
		if(comUrl.contains("gateway-commons"))comHtml= U.getSectionValue(comHtml, "<div class=\"DetailHeader\"", "<script>window");
		U.log("comHtm: "+comHtml);
		String comName = U.getSectionValue(comSec, "alt=\"", "\"");
		U.log(comName);

		// =============================address===================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";

		String addSec = U.getSectionValue(comHtml, "col-lg-10 pr-lg-0 col-xl-8", "View on Map");

		String addSec1 = U.getSectionValue(addSec, "</strong></li></ul>", "<!-- /react-text --></li></ul>");
		addSec1 = addSec1.replaceAll(
				"<ul data-reactid=\"\\d{3}\">|<li data-reactid=\"\\d{3}\">|<ul data-reactid=\"210\">|<!-- react-text: \\d{3} -->",
				"").replace("6153 N Ceylon St, Building 1", "6153 N Ceylon St,").replaceAll("</li>|<!-- /react-text -->", ",");
		U.log(addSec1);
		addSec1 = addSec1.replace("&amp;", "&").replaceAll(",, ,|, ,|,,", ",");
		String address[] = addSec1.split(",");
		add[0] = address[0];
		add[1] = address[1];
		add[2] = address[2];
		add[3] = address[3];

		String latlagSec = U.getSectionValue(addSec, "https://www.google.com/maps", "\"");
		U.log(latlagSec);

		latlag[0] = U.getSectionValue(latlagSec, "/@", ",");
		latlag[1] = U.getSectionValue(latlagSec, ",", "/");

		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log(geo);
		// =============================available homes
		// section==================================

		String availSec[] = U.getValues(comHtml, "HomeCard_buttonWrapper d-flex justify-content-around", "View Detail");
		String availHtml = "";
		String availPrices = "";
		String availDesc = "";
		String availStorySec = "";
		String availPriceSec[] = U.getValues(comHtml, "HomeCard_priceValue", "</span>");
		for (String aSec : availSec) {
			// U.log(aSec);
			String availUrl = "https://www.lokalhomes.com/homes" + U.getSectionValue(aSec, "href=\"/homes", "\"");
			availHtml += U.getHTML(availUrl).replace(rmsec, "");
		}

		String availStorySections[] = U.getValues(availHtml, "\"DetailDescription_price\"", "text-capitalize");
		for (String as : availStorySections) {
			availStorySec += as;
		}
		String availDescSections[] = U.getValues(availHtml, "\"DetailDescription_title\"", "DetailSection text-center");
		for (String availD : availDescSections) {
			availDesc += availD;
		}
		for (String availP : availPriceSec) {
			availPrices += availP;
		}
		// ============================floor plan
		// section=============================================
		String floorSec[] = U.getValues(comHtml, "\"PlanCard_buttonWrapper\"", "View Detail");
		String floorHtml = "";
		String floorPrices = "";
		String floorSqft = "";

		String floorDesc = "";
		String floorsqftSec[] = U.getValues(comHtml, "/images/icon-sqft.svg", "SQ FT");
		String floorPriceSec[] = U.getValues(comHtml, "<div class=\"PlanCard_wrapper\"", "View Detail</a>");
		for (String fSec : floorSec) {
			String floorUrl = "https://www.lokalhomes.com" + U.getSectionValue(fSec, "href=\"", "\"");
			U.log(floorUrl);
			String floorh = U.getHTML(floorUrl);
			rmsec = U.getSectionValue(floorh, "window.__PRELOADED_STATE__", "</html>");
			String[] rmsec1 = U.getValues(floorh, "<div class=\"HomeCard", "</ul>");
			
			floorHtml += floorh.replace(rmsec, "");
			
			for(String rm : rmsec1)
				floorHtml = floorHtml.replace(rm, "");
		}
//		U.log(floorHtml);
		if(floorHtml==null)floorHtml=ALLOW_BLANK;
		String floorDesSec[] = {};
		if(floorHtml.contains("Elevations<!-- /react-text -->"))
			floorDesSec = U.getValues(floorHtml, "<ul class=\"DetailDescription_iconList\"", "Elevations<!-- /react-text -->");
		if(floorDesSec==null || floorDesSec.length<3)floorDesSec=U.getValues(floorHtml, "<div class=\"DetailHeader\"", "<h3 class=\"DetailSection_heading\"");
		for (String fDes : floorDesSec) {
			floorDesc += fDes;
		}
//		U.log("floordesc::::::::"+floorDesc);

		for (String floorP : floorPriceSec) {
			floorPrices += floorP;
		}
		for (String floorS : floorsqftSec) {
			floorSqft += floorS;
		}
		String comDesc = U.getSectionValue(comHtml, "<div class=\"DetailHeader_infoWrapper\" ", "DetailSection text-center");
		// ============================prices=============================
		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		comDesc = comDesc.replace("300s", "300,000").replace("0s", "0,000");
		prices = U.getPrices(comSec + comDesc + floorPrices + availPrices+floorDesc, "\\$\\d,\\d{3},\\d{3}|\\$\\d{3},\\d{3}", 0);

		U.log(Arrays.toString(prices));

		// ============================sqft-========================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		String sqftSec = U.getSectionValue(comHtml, "<span class=\"DetailDescription_preTitle\"", "<h3 class=\"DetailSection_heading");
		sqft = U.getSqareFeet(floorSqft+sqftSec, "\\d,\\d{3} sq ft to \\d,\\d{3} sq ft|\\d{1},\\d{3}|>\\d{1},\\d{3}<|>\\d{3}</span>", 0);

		U.log(Arrays.toString(sqft));
		String luxurySec= U.getSectionValue(comHtml, "<h3 class=\"DetailSection_heading\"", "<h3 class=\"AmenitySection_");
		if(luxurySec==null)luxurySec=ALLOW_BLANK;
		U.log(luxurySec);
		String cType = U.getCommType(comDesc + comSec);
		U.log(cType);

		String pType = ALLOW_BLANK;
		
		pType = U.getPropType(availDesc + comDesc + comSec+floorDesc+luxurySec.replace("Luxury Amenities", "luxury home"));

		U.log("pType::::::" + pType);
//		U.log(Util.matchAll(availDesc, "[\\w\\s\\W]{30}townhome[\\w\\s\\W]{30}", 0));
		// ============================dproptype=================================
		String dType = ALLOW_BLANK;

		floorDesc = floorDesc.replaceAll("1<!-- /react-text --><!-- react-text: \\d{3} --> Levels", "1 Story")
				.replaceAll("2<!-- /react-text --><!-- react-text: \\d{3} --> Levels", "2 Story").replaceAll("<!-- /react-text --><!-- react-text: \\d+ --> Stories", " Story");
		availStorySec = availStorySec.replaceAll("1<!-- /react-text --><!-- react-text: \\d{3} --> Levels", "1 Story")
				.replaceAll("2<!-- /react-text --><!-- react-text: \\d{3} --> Levels", "2 Story");

		dType = U.getdCommType((comDesc + comSec + availDesc + floorDesc+floorDesSec));

		U.log("dType::::::" + dType);
//		U.log(Util.matchAll(comDesc + comSec, "[\\w\\s\\W]{30}2 story[\\w\\s\\W]{30}",0));

		
		// =======================propertyStatus===================================

		String pStatus = ALLOW_BLANK;

		pStatus = U.getPropStatus((comDesc + comSec));
		//
		U.log("status:::::::" + pStatus);

		
		if(comUrl.contains("denver-metro/stonegate"))
			pStatus=pStatus.replace(", Coming This Winter", "");
		
		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;
		if(comUrl.contains("/denver-metro/gateway-commons")) {
				pStatus="Now Selling";
		};
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);
		data.addCommunity(comName, comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0], add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(U.getnote(comDesc));

		j++;
	}
}
