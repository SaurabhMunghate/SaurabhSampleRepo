package com.shatam.b_325_353;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author MJS
 * @date 02/04/2021 
 * 
 */
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractMcGuinnHybridHomes extends AbstractScrapper{

	static int j = 0;
	static int k = 0;
	CommunityLogger LOGGER;
	WebDriver driver = null; 
	static String builderUrl = "https://www.mcguinnhomes.com";

	public ExtractMcGuinnHybridHomes() throws Exception {
		super("McGuinn Hybrid Homes", builderUrl);
		LOGGER = new CommunityLogger("McGuinn Hybrid Homes");
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		AbstractScrapper a = new ExtractMcGuinnHybridHomes();
		// U.logDebug(true);
		a.process();
		FileUtil.writeAllText(U.getCachePath() + "McGuinn Hybrid Homes.csv", a.data().printAll());
		U.log("Total-->" + j);
		U.log("Repeated-->" + k);

	}
	
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		
		String html = U.getHtml("https://www.mcguinnhomes.com/communities",driver);
		String[] regionSec = U.getValues(html.replaceAll("<div class=\"css-41nb7q\" data-reactid=\"\\d+\">", "<div class=\"css-41nb7q\">"), "<div class=\"css-41nb7q\">", "Visit Community</a>");
		U.log(regionSec.length);
		for(String region : regionSec) {
			
			String regionUrl = U.getSectionValue(region, "href=\"", "\"");
//			try {
				getDetail(builderUrl+regionUrl, region);
//			} catch (Exception e) {}
		}
//		driver.quit();
		LOGGER.DisposeLogger();
	}

	private void getDetail(String comUrl, String com) throws Exception {
		// TODO Auto-generated method stub
		
//	if(!comUrl.contains("https://www.mcguinnhomes.com/communities/lexington-sc/kitti-wake-estates"))return;
//		if(j>3)
//		try {
		U.log("Count: " + j + "\t" + comUrl);
		{
			
			if (data.communityUrlExists(comUrl)) {
				LOGGER.AddCommunityUrl("Repeated======== " + comUrl);
				return;
			}
			if(comUrl.contains("https://www.mcguinnhomes.com/communities/columbia-sc/harbison-gro")) {
				LOGGER.AddCommunityUrl("redirecting to region page======== " + comUrl);
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
			String html = U.getHTML(comUrl);
			
			
			html = html.replaceAll("<!-- react-text: \\d+ -->|<!-- /react-text -->", "");
			String html1 = html;
			html = U.getSectionValue(html, "content=\"", "\"")+U.getSectionValue(html, "<div class=\"DetailHeader_heading\"", "</ul>")+U.getSectionValue(html, "<div class=\"DetailDescription_body\"", "</div>")+U.getSectionValue(html1, "<div class=\"PlanCard_wrapper\" ", "</div></div></div></div></div><style data-emotion-css=");
			// ============================================Community
			// name=======================================================================
			U.log(com);
			String communityName = U.getSectionValue(com, "alt=\"","\"");
			
			communityName = U.getCapitalise(communityName.toLowerCase().trim());
			communityName = communityName.replaceAll("&#x27;|&#8217;", "'");
			if(communityName.endsWith("Estates")) communityName=communityName.replace("Estates", ""); 
			U.log("community Name---->" + communityName);

			// ================================================Address
			// section===================================================================

			String note = ALLOW_BLANK;
			String[] add = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			String[] latLng = { ALLOW_BLANK, ALLOW_BLANK };
			String geo = "FALSE";

			U.log("Address---->" + add[0] + ":>" + add[1] + ":>" + add[2] + ":>" + add[3]);

			// --------------------------------------------------latlng----------------------------------------------------------------
			
			String latSec = U.getSectionValue(html, "<a href=\"https://www.google.com/maps/place/", "/");
			if(latSec!=null)
				latLng = latSec.split(",");
			
			if (latLng[0] == null || latLng[1] == null)
				latLng[0] = latLng[1] = ALLOW_BLANK;
			U.log("hhhh--->" + latLng[0] + "  " + latLng[1]);

			if (add[1] != ALLOW_BLANK && latLng[0] == ALLOW_BLANK) {
				latLng = U.getlatlongGoogleApi(add);

				geo = "TRUE";
			}

			
			if ((add[0] == null || add[0].length() < 4 || add[3] == null) && latLng[0] != ALLOW_BLANK) {
				String add1[] = U.getAddressGoogleApi(latLng);
				if (add1 == null)
					add1 = U.getAddressHereApi(latLng);
				if (add[0] == null || add[0].length() < 2)
					add = add1;
				if (add[3] == null)
					add = add1;
				geo = "TRUE";
			}

			U.log("hhhh1--->" + latLng[0] + "  " + latLng[1]);

			//====== Available Homes ================================
			String availHtml = U.getHTML("https://www.mcguinnhomes.com/homes");
			String[] homeSec = U.getValues(availHtml, "<div class=\"col-md-6 col-xl-4\"", "</section>");
			String homeData = ALLOW_BLANK;
			for(String home : homeSec) {
				if(home.toLowerCase().contains(communityName.toLowerCase())) {
				home = U.getSectionValue(home, "href=\"", "\"");
				U.log("home: "+home);
				homeData += U.getSectionValue(U.getHTML(builderUrl+home), "<div class=\"DetailDescription_body\"", "</div>");
				}
			}
			//====== Available Floor ================================
			String[] floorSec = U.getValues(html1, "<div class=\"col-lg-6 col-xl-4\"", "Details<");
			String floorData = ALLOW_BLANK;
			for(String floor : floorSec) {
				floor = U.getSectionValue(floor, "href=\"", "\"");
				U.log("floor: "+floor);
				floorData += U.getSectionValue(U.getHTML(builderUrl+floor), "<div class=\"DetailDescription_body\"", "</div>")
						+U.getSectionValue(U.getHTML(builderUrl+floor), "<div class=\"DetailHeader_infoWrapper\"", "Download Brochure");
			}			
			// ============================================Price and
			// SQ.FT======================================================================

			String minSqft = ALLOW_BLANK, maxSqft = ALLOW_BLANK;
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;

			html = html.replaceAll("0's|0's|0s|0's|0&#8217;s|0s|0k's|0k|0's", "0,000").replace("$1 million", "$1,000,000").replace("From the $1.2 Millions", "From the $1,200,000 Millions")
					.replace("High $100s", "High $100,000").replace("</strong>   &#36;", " $");
			com = com.replaceAll("0&#8217;s|0s|0's", "0,000");
			html = html.replace("0s", "0,000");
			html1 =html1.replace("High $100s", "High $100,000").replace("Mid $200s", " $200,000");
			U.log(Util.matchAll(com + html1 +homeData, "[\\w\\s\\W]{30}\\$100[\\w\\s\\W]", 0));

			String prices[] = U.getPrices(com + html1 +homeData, "Starting At High \\$\\d{3},\\d{3}|New Homes Starting At\\s*\\$\\d{3},\\d{3}|Starting At:\\s*\\$\\d{3},\\d{3}|>\\$\\d{3},\\d{3}</span>", 0);

			minPrice = (prices[0] == null) ? ALLOW_BLANK : prices[0];
			maxPrice = (prices[1] == null) ? ALLOW_BLANK : prices[1];
			U.log("Price--->" + minPrice + " " + maxPrice);

			// ======================================================Sq.ft===========================================================================================
			html = html.replaceAll("</span>\\s*<span class=\"PlanCard_iconListLabel\" data-reactid=\"\\d+\">\\s*SQ FT", " SQ FT");

			String[] sqft = U.getSqareFeet(com + html  + floorData + homeData,
					"\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d{1},\\d{3} to \\d{1},\\d{3} square feet|\\d,\\d{3}\\s*- \\d,\\d{3}\\s*SQ FT|<span class=\"PlanCard_iconListValue\">\\d,\\d{3}</span>|\\d,\\d{3} SQ FT",
					0);
			minSqft = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqft = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("SQ.FT--->" + minSqft + " " + maxSqft);

			// ================================================community
			// type========================================================

			String communityType = U.getCommType((html + com).replaceAll("Country Club Terrace|resort-style-pool|from Meadow Springs Country Club|Sleepy Hole Golf", ""));

			// ==========================================================Property
			// Type================================================

			html = html.replace("crafted homes feature Mediterranean", "crafted homes feature Mediterranean-Style Homes")
					.replace("features Mediterranean", "features Mediterranean-Style Homes")
					.replace("luxury gated townhome", "luxury homes gated townhome")
					.replace("Mediterranean and Craftsman styles", "Mediterranean-Style Homes and Craftsman styles")
					.replace("Mediterranean, Tuscan and traditionally styled exterior designs", "Mediterranean-Style Homes, Tuscan and traditionally styled exterior designs");
			String proptype = U.getPropType((html + com + floorData).replace("Wake Estates", "Estates homes"));
//			U.log(Util.matchAll(html + com + floorData, "[\\s\\w\\W]{30}Courtyard[\\s\\w\\W]{30}", 0));
//			U.log(">>>>>>>>>>>"+Util.matchAll(floorData, "[\\s\\w\\W]{30}Stories[\\s\\w\\W]{50}", 0));

			// ==================================================D-Property
			// Type======================================================
			com = com.replaceAll("Stories<br>\n\\s*<span class='enlarge'>\n\\s*1-2", " Story 1 Story 2 ")
					.replaceAll("Stories<br>\n\\s*<span class='enlarge'>\n\\s*1", " Story 1 ")
					.replaceAll("Stories<br>\n\\s*<span class='enlarge'>\n\\s*2", " Story 2 ");
			if(floorData!=null)
				floorData = floorData.replaceAll("<!-- /react-text --><!-- react-text: \\d+ -->", "")
				.replaceAll("STORIES</span> <br>\n\\s*pan class='info-data'>1</span>", " Story 1 ")
						.replaceAll("STORIES</span> <br>\n\\s*pan class='info-data'>2</span>", " Story 2 ");
			if(homeData!=null)
				homeData = homeData.replaceAll("STORIES</span> <br>\n\\s*pan class='info-data'>1</span>", " Story 1 ")
						.replaceAll("STORIES</span> <br>\n\\s*pan class='info-data'>2</span>", " Story 2 ");
			String dtype = U.getdCommType((html + com + floorData + homeData).replaceAll("Ranch Rd|anch</a>|branch|BRANCH|(f|F)loor", "")
					+ communityName);
//			U.log(">>>>>>>>>>>"+Util.matchAll(html + com + floorData+homeData, "[\\s\\w\\W]{30}Stories[\\s\\w\\W]{30}", 0));

			// ==============================================Property
			// Status=========================================================
	
			html = html.replaceAll("Quick Move|[M|m]ove-[I|i]n|slider_slide__title\">Now Open!</div>|\"Now Open!\">|Coming Soon!</a>|information coming|Course Lots|Golf Lots|Amenities are coming", "")
					.replace("Phase-II has 21 home sites available", "Phase II has 21 home sites available");
			com = com.replace("SODL OUT UNTIL NEXT PHASE" , "SOLD OUT UNTIL NEXT PHASE")
					.replaceAll("Coming soon, neuhouse", "");
			String pstatus = U.getPropStatus(html + com);
	
			// ============================================note====================================================================


			U.log("Address---->" + add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
			
			//========== Hard Code Data ==================================

			if(homeData!=null && homeData.length()>31) {
				if(pstatus==ALLOW_BLANK)
					pstatus = "Quick Move-In Homes";
				else if(!pstatus.contains("Quick Move"))
					pstatus += ", Quick Move-In Homes";
			}
			
			pstatus = pstatus.replace("New Phase Coming, Coming Soon", "New Phase Coming Soon");
			if(add[0]!=null)
				add[0] = add[0].replaceAll("!2s|", "").replace("&amp;", "&");
//			if(comUrl.contains("/communities/lexington-sc/cannon-springs")|| comUrl.contains("/communities/columbia-sc/honey-tree")|| comUrl.contains("/communities/camden-sc/kendall-lake-walk"))
//				pstatus="New Phase Coming Soon";
			//=========================================================================================================================
			// ------------------ No. of units ------------------------
			String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
			
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);
			data.addCommunity(communityName.replace(",", ""), comUrl, communityType);
			data.addLatitudeLongitude(latLng[0].trim(), latLng[1].trim(), geo);
			data.addPrice(minPrice, maxPrice);
			data.addAddress(add[0].replace(",", "").trim(), add[1].replace(",", "").trim(), add[2].trim(), add[3].trim());
			data.addSquareFeet(minSqft, maxSqft);
			data.addPropertyType(proptype, dtype);
			data.addPropertyStatus(pstatus);
			data.addNotes(note);

		}
		j++;
//		}catch(Exception e) {}
	}

}