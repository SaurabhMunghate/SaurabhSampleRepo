package com.shatam.b_325_353;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;

import org.apache.http.client.params.AllClientPNames;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRealstarHomes extends AbstractScrapper {
	CommunityLogger LOGGER;

	static int j = 0;
	WebDriver driver=null;
	public ExtractRealstarHomes() throws Exception {

		
		super("Realstar Homes", "https://gorealstar.com/");
		LOGGER = new CommunityLogger("Realstar Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractRealstarHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Realstar Homes.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
//		U.setUpGeckoPath();
//		driver = new FirefoxDriver();
		String mainHtml=U.getHTML("https://gorealstar.com");
//		String mainHtml=U.getHtml("https://gorealstar.com/", driver);
		
		//---retrive data of map from reg 
				String filedata="";
				String mapdata="";										//download file from this link 
				File f=new File(U.getCachePath()+"realstarhome_v360.kml");   //http://gorealstar.com/google-map/realstarhome_v360.kml
				 BufferedReader br = new BufferedReader(new FileReader(f)); //change the file location accordingly
				while((filedata=br.readLine())!=null) {
//					U.log("File data======"+filedata);
					mapdata+=filedata;
				}
				U.log("File data======"+mapdata);
		 	
		String mainSec=U.getSectionValue(mainHtml, "<div id=\"\" class=\"col-xs-12 col-md-5 communities-list\">", "<div class=\"moduletable\">");//U.getSectionValue(mainHtml, "Communities</h2>", "<!-- END: Articles Anywhere --");
		String comSections[]=U.getValues(mainSec, "<li><img class=\"homepage-map-reference-icon\"", "</li>");
		U.log(comSections.length);
		for(String comSec:comSections) {
			//U.log(comSec);
			addDetails(comSec,mapdata);
		}
		addDetails("><a href=\"/our-communities/hampton-park\"",mapdata);
		addDetails("><a href=\"/our-communities/park-pointe\"",mapdata);
		
//		driver.quit();
		LOGGER.DisposeLogger();
	}
	
	public void addDetails(String comSec,String mapData) throws Exception {
		
//		U.log(comSec);
		
		String comUrl="https://gorealstar.com"+U.getSectionValue(comSec, "><a href=\"", "\"");//U.getSectionValue(comSec, "<a class=\"moduleItemTitle\" href=\"", "\"");
		U.log(comUrl);
		
		//TODO:
//		if(!comUrl.contains("https://gorealstar.com/our-communities/grove-park"))return;
		
		
		LOGGER.AddCommunityUrl(comUrl);
		
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"==================repeated");
			return;
		}
		String comHtml=U.getHTML(comUrl);

		
		String comName=U.getSectionValue(comHtml, "<h1>", "</h1>").trim();
		U.log(comName);
		
		//data from map
		String mdataPriceSec="";
		String[] mDatas=U.getValues(mapData, "<Placemark>", "</Placemark>");
		U.log("mapData length: "+mDatas.length);
		String mapDataCord=ALLOW_BLANK;
		for(String mData:mDatas) {
			
			if(mData.contains(comName)) {
				mData=mData.replace("0's", "0,000");
				U.log(mData);
				mdataPriceSec=mData;
			}
//			break;
		}
		
		
		
		
		//======================address===============================================
				String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
				String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
				String geo = "FALSE";
				String note =ALLOW_BLANK;
		
		String addSec=U.getSectionValue(comHtml, "<p style=\"text-align: left;\">", "</p>");
		
		if(comUrl.contains("https://gorealstar.com/our-communities/hampton-park")) {
			addSec="119 Hampton Park Circle,Myrtle Beach, SC 29588";
		}
//		if(comUrl.contains("https://gorealstar.com/our-communities/pawleys-cove")) {
//			addSec="229 Clearwater Drive, Pawleys Island, SC 29585";
//		}
//		if(comUrl.contains("https://gorealstar.com/our-communities/cameron-woods")) {
//			addSec="6512 Adelina Ct. SW, Ocean Isle, NC 28469";
//		}

		if(addSec==null) {
			
			if(!comUrl.contains("https://gorealstar.com/our-communities/queens-cove") && !comUrl.contains("arcadia")) {
			String descSec=U.getSectionValue(comHtml, "col-xs-12 col-md-8", "</div>");
			String paras[]=U.getValues(descSec, "<p>", "</p>");
					
			try{addSec=paras[paras.length-1];}catch (Exception e) {
				// TODO: handle exception
			}
			}
		}
		if(addSec!=null) {
		addSec=addSec.replace("<span style=\"display: inline-block; width: 1em;\"></span>", ",").replace("Stars Way Little River", "Stars Way,Little River");
		
		if(comUrl.contains("https://gorealstar.com/our-communities/hampton-park")) {
			add[0]="119 Hampton Park Circle";
			add[1]="Myrtle Beach";
			add[2]="SC";
			add[3]="29588";
			
		}
		
		//	U.log(addSec);
		if(comUrl.contains("https://gorealstar.com/our-communities/queens-cove")) {
			add[0]="107 N Main St";
			add[1]="Davidson";
			add[2]="NC";
			add[3]="28117";
//			latlag=U.getlatlongGoogleApi(add);
		//	add=U.getAddressGoogleApi(latlag);
		//	addSec="";
		}
		else {
			add=U.getAddress(addSec);
		}
		}
		if(comUrl.contains("https://gorealstar.com/our-communities/arcadia")) {
			add[0]="-";
			add[1]="Myrtle Beach";
			add[2]="SC";
			add[3]="-";
			latlag=U.getlatlongGoogleApi(add);
			add=U.getAddressGoogleApi(latlag);
			geo="TRUE";
		//	addSec="";
			note ="Address and LatLng taken from City & State";
		}
		String latLngSec[]= {ALLOW_BLANK,ALLOW_BLANK};
		if(U.getSectionValue(mdataPriceSec, "<coordinates>", "</coordinates>")!=null){
		latLngSec = U.getSectionValue(mdataPriceSec, "<coordinates>", "</coordinates>").trim().split(",");
		
			latlag[0]=latLngSec[1];
			latlag[1]=latLngSec[0];
			
		}
		if(latlag[0]==null) {
			latlag=U.getlatlongGoogleApi(add);
			geo="TRUE";
		}
		add[0]=add[0].replace("843-957-7419<br />", "");
		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		//============================prices=============================
	      String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
			
	      U.log(comSec);
	    
	        String quickData = ALLOW_BLANK;
	      	String qHtml = U.getHTML("https://gorealstar.com/realtors/move-in-ready-homes");
			String[] qSec = U.getValues(qHtml, "<article class=\"row even lastItem\">", "</article>");
			for(String qData : qSec)
				if(qData.contains(comName))
					quickData += qData;
	      
			//U.log(Util.matchAll(comHtml+mdataPriceSec, "[\\w\\s\\W]{30}\\$1[\\w\\s\\W]{100}",0));

			prices=U.getPrices(quickData+comHtml+mdataPriceSec+comSec, "\\$\\d{3},\\d{3}", 0);
			
			U.log(Arrays.toString(prices));
			
			//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			
			sqft=U.getSqareFeet(quickData+comHtml+comSec, "Sq Ft: \\d,\\d{3}<|\\d{4} heated sq. ft. to \\d{4} heated sq. ft.|from \\d+ heated sq. ft. to over \\d+ heated sq. ft.|Heated Sq Ft: \\d{4}|Heated Sq Ft: \\d{1},\\d{3}|Sq Ft: \\d{4} - \\d{4}\\+|Sq Ft: \\d,\\d{3} - \\d,\\d{3}|Sq Ft: \\d{4} - \\d{4}", 0);
			
			U.log(Arrays.toString(sqft));
			
			
			comHtml=comHtml.replaceAll("challenged by world-class golf|Golfing|Golf Communities for Retirees|golf-communities-for-retirees", "");
			String cType=U.getCommType(comHtml);
			
			U.log(cType);
			
			
			String pType=ALLOW_BLANK;
			
			String fUrl = U.getSectionValue(comHtml, " href=\"https://www.lennar.com", "\"");
			if(fUrl!=null && !fUrl.contains("/Promo/"))
				mdataPriceSec+= U.getSectionValue(U.getHTML("https://www.lennar.com"+fUrl),"<div class=\"Overview_headline","Explore homes in this collection</h2>");
			
			comHtml=comHtml.replaceAll("<!--(.*)?-->|Grove Park offers Single-Family Homes|single family homes for sale|single family homes for sale,|townhomes for sale,|townhomes,|Single Family Homes – Ocean Isle Beach", "");
			pType = U.getPropType((comHtml+mdataPriceSec+comSec).replaceAll("village|<!--.*-->",""));
			U.log("pType::::::" + pType);
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			
			dType = U.getdCommType(comHtml+comSec);
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================

			String pStatus = ALLOW_BLANK;
			comHtml=comHtml.replace("New Homes<br>Coming Soon", "New Homes Coming Soon")
					.replace("\">Coming Soon", "").replaceAll("title=\"Quick Move-In Homes\"|move-in-ready-homes\" >Move-In Ready|Quick Move-In Homes</h2>|Quick Move-In Homes</span><", "");

			//
			pStatus = U.getPropStatus((comHtml+comSec).replace("Only a One Remaining Opportunity", "Only One Remaining Opportunity"));
			//
			U.log("status:::::::" + pStatus);

			
			if(comUrl.contains("https://gorealstar.com/our-communities/chatham-glenn"))pStatus=ALLOW_BLANK;
			
			if (prices[0] == null)
				prices[0] = ALLOW_BLANK;
			if (prices[1] == null)
				prices[1] = ALLOW_BLANK;
			if (sqft[0] == null)
				sqft[0] = ALLOW_BLANK;
			if (sqft[1] == null)
				sqft[1] = ALLOW_BLANK;
			
			
			
			
			if(quickData!=ALLOW_BLANK && !pStatus.contains("Quick Move")) {
				if(pStatus.length()<2) {
					pStatus ="Quick Move-In Homes";
				}else {
					pStatus = pStatus+", Quick Move-In Homes";
				}
			}
			if(comUrl.contains("https://gorealstar.com/our-communities/arcadia"))pType="Single Family";
			if(comUrl.contains("https://gorealstar.com/our-communities/cameron-woods-gardens"))pType+=", Garden Home, Multi-Family";

			pStatus=pStatus.replace("Only A Few Remaining Opportunities, Closeout, Only A Few Remain", "Only A Few Remaining Opportunities, Closeout").replace("Move-in Ready", "Quick Move in");
			note =U.getnote(comHtml);
			data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(note);
			
			
			
			
			j++;
			U.log("=================================="+j);
	}
}
