package com.shatam.b_325_353;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

import org.apache.commons.collections.map.MultiValueMap; 
import org.apache.commons.lang.StringEscapeUtils;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.gargoylesoftware.htmlunit.WebConsole.Logger;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractReliantHomes extends AbstractScrapper{
	CommunityLogger LOGGER;
WebDriver driver=null;
	static int j = 0;

	public ExtractReliantHomes() throws Exception {

		super("Reliant Homes", "https://www.relianthomes.com/");
		LOGGER = new CommunityLogger("Reliant Homes");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractReliantHomes();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Reliant Homes.csv", u.data().printAll());
		
	}

	
	@Override
	protected void innerProcess() throws Exception {
		
		long start = System.currentTimeMillis();
		// ------------------  Urls Avaialble on Region Page (Network Tab) ------------------------
		String comData =U.getHTML("https://api.mybuildercloud.com/api/v1/communities?where={%22published%22:true,%22builder%22:%22577750d4371e2f630a853b16%22}&max_results=9999");
		String homData=U.getHTML("https://api.mybuildercloud.com/api/v1/homes?where={%22published%22:true,%22builder%22:%22577750d4371e2f630a853b16%22}&max_results=9999");
//		String planData=U.getHTML("https://api.mybuildercloud.com/api/v1/plans?where={%22published%22:true,%22builder%22:%22577750d4371e2f630a853b16%22}&max_results=9999");
		JsonParser jparser = new JsonParser();
		JsonObject jobjCom = (JsonObject) jparser.parse(comData).getAsJsonObject();
		JsonArray commJson = (JsonArray) jobjCom.get("_items").getAsJsonArray();

		JsonObject jobjHome = (JsonObject) jparser.parse(homData).getAsJsonObject();
		JsonArray homeJson = (JsonArray) jobjHome.get("_items").getAsJsonArray();
		
//		JsonObject jobjPlan = (JsonObject) jparser.parse(planData).getAsJsonObject();
//		JsonArray planJson = (JsonArray) jobjHome.get("_items").getAsJsonArray();
//		
		U.log("Total Communities :: "+commJson.size());
	
		int communityCount=0;
		
		for(JsonElement comSec : commJson) {
			int homesCount=0;
			int planCount=0;
			
			String Comid=comSec.getAsJsonObject().get("_id").toString().replace("\"", "");
//			U.log("community Id :: "+Comid);
			String commName=comSec.getAsJsonObject().get("name").toString().replace("\"", "");
//			U.log("Community Name :: "+commName);	
			String homesData="";
			String plansData="";
	
			for(JsonElement homeSec: homeJson) {
				String containedId=homeSec.getAsJsonObject().get("containedIn").toString().replace("\"", "");
				if(Comid.contains(containedId)) {
					String streetName=homeSec.getAsJsonObject().get("address").getAsJsonObject().get("streetAddress").toString();
//					U.log("homes :: "+streetName);
					homesData+=homeSec;
					homesCount++;
				}
			}

//			for(JsonElement planSec: planJson) {
//				if(planSec.toString().contains(Comid)) {
//					String streetName=planSec.getAsJsonObject().get("address").getAsJsonObject().get("streetAddress").toString();
//					U.log(streetName);
//					plansData+=planSec;
//					planCount++;
//				}
//			}
//			U.log(communityCount+"Homes Count "+homesCount);
//			U.log(communityCount+"plans Count "+planCount);
			communityCount++;
			addDetails(commName.toString(),comSec, homesData.toString());//, plansData.toString()
		}
		
		
		long end = System.currentTimeMillis();
		U.log("Time taken by System "+(end-start));
		LOGGER.DisposeLogger();
		
	}

	public void addDetails(String comName, JsonElement comSec, String homesData) throws Exception {//, String plansData

		{
		//Single Run
//		if(!comName.contains("Willow Haven At Cobb")) return;
		if(comName.endsWith("Estates")) {
			comName=comName.replace("Estates", "");
		}
		U.log("comunityname=>"+comName);
		
		// ------------------ LatLong ------------------------
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String latlongSec=U.getSectionValue(comSec.toString(), "geoIndexed\":[", "],\"");
		latlag[0]=Util.match(latlongSec,",\\d{2,3}[.]{1}\\d+").replace(",", "");		
		latlag[1]=Util.match(latlongSec,"-\\d{2,3}[.]{1}\\d+");		
		U.log("latlong==>"+Arrays.toString(latlag));
		
		// ------------------ Addresses ------------------------
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		add[0]=comSec.getAsJsonObject().get("address").getAsJsonObject().get("streetAddress").toString().replace("\"", "");
		add[1]=comSec.getAsJsonObject().get("address").getAsJsonObject().get("addressLocality").toString().replace("\"", "");
		add[2]=comSec.getAsJsonObject().get("address").getAsJsonObject().get("addressRegion").toString().replace("\"", "");
		add[3]=comSec.getAsJsonObject().get("address").getAsJsonObject().get("postalCode").toString().replace("\"", "");
		geo="TRUE";
		U.log("GeoCode :: "+geo);
		U.log("Address :: "+Arrays.toString(add));

		// ------------------ communityUrl ------------------------
		String state=add[2];
		if(state.contains("SC")) {
			state="south-carolina";
		}
		else if(state.contains("GA")){
			state="georgia";
		}
		String comUrl="https://www.relianthomes.com/communities/"+state+"/"+comSec.getAsJsonObject().get("sharedName").toString().replace("\"", "");
		U.log("Comm Url :: "+comUrl);
		
		// ------------------For LoggerFile ------------------------
		if(comUrl.contains("https://www.relianthomes.com/communities/georgia/individual-home-sites-ga")) {
			LOGGER.AddCommunityUrl(comUrl+"--------------------------------- Not Proper Community   ");
			return;
		}
		if(data.communityUrlExists(comUrl)) {
			LOGGER.AddCommunityUrl(comUrl+"----------------------------------------Repeated");
			return;
		}
		LOGGER.AddCommunityUrl(comUrl);
		
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		String frameUrl="";
		int lot=0;
		if(comSec.toString().contains("zplaturl")) {
			frameUrl=comSec.getAsJsonObject().get("zplaturl").toString().replace("\"", "");
			U.log("Frame Url :"+frameUrl); 			
			String[] unitCount=U.getValues(comSec.toString(), "type\":\"Polygon", "}");
			lot=unitCount.length;
			U.log("Lot Count :"+lot);
		}
		if(lot > 0) {
			units=Integer.toString(lot);
			 
		}
		
		U.log("Total Units : "+units);
		U.log("vikas");
		U.log("vikas");
		//============================prices=============================
	    String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		prices=U.getPrices((comSec +homesData).replace("00s", "00,000"), "price\":\\d{6}|\\$\\d{3},\\d{3}|\"priceLow\":\\d{6,7}", 0);
		U.log(Arrays.toString(prices));
		if(prices[0]==null) {
			prices[0]=ALLOW_BLANK;
		}
		if(prices[1]==null) {
			prices[1]=ALLOW_BLANK;
		}
		
		//============================sqft-========================================
			String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
			sqft=U.getSqareFeet(comSec+homesData, "sqft\":\\d{4}|sqftHigh\":\\d{4}|sqftLow\":\\d{4}", 0);
			if(sqft[0]==null) {
				sqft[0]=ALLOW_BLANK;
			}
			if(sqft[1]==null) {
				sqft[1]=ALLOW_BLANK;
			}
			U.log(Arrays.toString(sqft));
			// ============================remove Section=================================
			if(homesData!=null) {
				homesData=homesData.replaceAll("Courtyard Cr|HOA Dues", "").replaceAll("Grade Traditional|\\(Traditional\\)", "");
			}
			
			// ============================communitytype=================================
			String cType=U.getCommType(comSec.toString().replaceAll("gated community offering|GatedResidenceCommunity|this gated community", "").replace("\"style\":\"Gated\"", "") +homesData);
			U.log("cType :: "+cType);
//			U.log(Util.matchAll(comSec +homesData, "[\\w\\s\\W]{30}HOA[\\w\\s\\W]{30}",0));
			
			// ============================propertytype=================================
			String pType=ALLOW_BLANK;
			pType = U.getPropType(comSec +homesData); 
			U.log("pType::::::" + pType);
			
			// ============================dproptype=================================
			String dType = ALLOW_BLANK;
			dType = U.getdCommType((comSec +homesData).replace("2-story", "2 Story").replace("1 story", "1 story").replace("stories\":2", "2 Story").replace("stories\":1", "2 Story").replace("stories\":3", "3 Story"));
			U.log("dType::::::" + dType);

			// =======================propertyStatus===================================
			String pStatus = ALLOW_BLANK;
			pStatus = U.getPropStatus((comSec.toString()));
			
			if(homesData.contains("\"status\":\"Active\"")) {
				if(pStatus == ALLOW_BLANK)
					pStatus = "Quick Move-Ins";
				else if(pStatus != ALLOW_BLANK)
					pStatus = pStatus + ", Quick Move-Ins";	
			}
			//U.log(Util.matchAll(comHtml, "[\\w\\s\\W]{30}coming soon[\\w\\s\\W]{30}",0));
			U.log("status:::::::" + pStatus);
			

			data.addCommunity(comName, comUrl, cType);
			data.addLatitudeLongitude(latlag[0], latlag[1], geo);
			data.addPrice(prices[0], prices[1]);
			data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
			data.addSquareFeet(sqft[0], sqft[1]);
			data.addPropertyType(pType, dType);
			data.addPropertyStatus(pStatus);
			data.addNotes(ALLOW_BLANK);
			data.addUnitCount(units);
			data.addConstructionInformation(startDt, endDt);

		U.log("================================"+j);
		j++;
		
		}
	}
}	

