package com.shatam.b_325_353;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractRiversideHomebuilders extends AbstractScrapper {
	CommunityLogger LOGGER;
	WebDriver driver = null;

	static int j = 0;

	public ExtractRiversideHomebuilders() throws Exception {

		super("Riverside Homebuilders", "https://www.riversidehomebuilders.com/");
		LOGGER = new CommunityLogger("Riverside Homebuilders");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractRiversideHomebuilders();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "Riverside Homebuilders.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		driver = new FirefoxDriver();
		String mainHtml = U.getHTML("https://www.riversidehomebuilders.com/communities");

		String comSections[] = U.getValues(mainHtml, "<div class=\"CommunityCard_media", "Visit Community</a>");
		 U.log(comSections.length);
		for (String comSec : comSections) {
			String comUrl = "https://www.riversidehomebuilders.com" + U.getSectionValue(comSec, "href=\"", "\"");
			U.log(comUrl);
			addDetails(comUrl, comSec);

		}
		LOGGER.DisposeLogger();
		driver.quit();
	}

	public void addDetails(String comUrl, String comSec) throws Exception {

//		if (j >=17)
		{
	 
		U.log("==================" + j);

		//U.log(comUrl);

//	 if(!comUrl.contains("https://www.riversidehomebuilders.com/communities/van-alstyne/cedar-meadows"))return;
		 
		 if (data.communityUrlExists(comUrl)) {
			 LOGGER.AddCommunityUrl(comUrl+"***********************repeated");
				return;
		 }

		LOGGER.AddCommunityUrl(comUrl);
		String comHtml = U.getHtml(comUrl,driver);
		
		// ------------------ No. of units ------------------------
		String units = ALLOW_BLANK; String startDt = ALLOW_BLANK; String endDt = ALLOW_BLANK;
		units = getUnits(comHtml, comUrl, driver);
		U.log("Total Units : "+units);
		// ---------------------------------------------------------

		String comName = U.getSectionValue(comSec, "alt=\"", "\"");
		U.log("comName=="+comName);
		
		String remove = U.getSectionValue(comHtml, "window.__PRELOADED_STATE__", "<script>");
		if(remove != null)comHtml = comHtml.replace(remove, "");
		

		// ========================addressec===================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";

		String addSec = U.getSectionValue(comHtml, "Model Info</h3>", "</div>");
		
		if(addSec!=null && !addSec.contains("By Appointment Only")) {
			
			addSec = addSec.replaceAll("<p data-reactid=\"\\d+\">", "").replaceAll("<br data-reactid=\"\\d+\">", ",").replace("--> <!--", "-->, <!--")
					.replaceAll("<!-- /react-text -->|<!-- react-text: \\d+ -->", "")
					.replace("Texas,", "TX").replace(" Tx,", " Tx")
					.replace("Anna, TX,", "Anna, TX");
			U.log("============ "+addSec);
			add = U.getAddress(addSec);
		}
		
		
		String latlagsec = U.getSectionValue(comSec, "https://www.google.com/maps", "\"");
		U.log(latlagsec);
		latlag[0] = U.getSectionValue(latlagsec, "/@", ",");
		latlag[1] = "-" + U.getSectionValue(latlagsec, ",-", "/");

		if(add[0]==ALLOW_BLANK) {
		add = U.getAddressGoogleApi(latlag);
		geo = "TRUE";
		}

		U.log(Arrays.toString(add));
		U.log(Arrays.toString(latlag));
		U.log(geo);
		

		// ===========================available
		// homes========================================
		String availhomeUrl = comUrl + "/available-homes";

		String availHomeHtml = U.getHTML(availhomeUrl);
		String availHtml = "";
		String aContent = "";

		String availPlanSec[] = U.getValues(availHomeHtml, "HomeCard_content", "View Home");
		U.log(availPlanSec.length);
		int i=0;
		for (String availContent : availPlanSec) {
			aContent += availContent;
			i++;
			String availPlanUrl = "https://www.riversidehomebuilders.com" + U.getSectionValue(availContent, "href=\"", "\"");
			U.log(availPlanUrl);
			
			
			String _availHtml  = U.getHTML(availPlanUrl);
			remove = U.getSectionValue(_availHtml, "window.__PRELOADED_STATE__", "<script>");
			if(remove != null)_availHtml = _availHtml.replace(remove, "");
			
			availHtml += _availHtml;
			if(availHtml.contains("389,900"))U.log("FOUND");
			if(i>30)break;
		}

		
		String availPriSec[]=U.getValues(availHtml, "\"DetailHeader_heading\"", "HomeLinksWrapper");
		String availPrices="";
		for(String avP:availPriSec) {
			availPrices+=avP;
		}
		// ========================floorplan
		// html================================================

		String floorHomeUrl = comUrl + "/floor-plans";
		String floorHomeHtml = U.getHTML(floorHomeUrl);
		String floorHtml = "";
		String fContent = "";
		String floorPlanSec[] = U.getValues(floorHomeHtml, "\"PlanCard_content\"", "View Plan");
		for (String floorContent : floorPlanSec) {
			fContent += floorContent;
			String floorPlanUrl = U.getSectionValue(floorContent, "href=\"", "\"");
			U.log("floorPlanUrl: "+floorPlanUrl);
			String fhtml= U.getHTML("https://www.riversidehomebuilders.com" + floorPlanUrl);
			
			remove = U.getSectionValue(fhtml, "window.__PRELOADED_STATE__", "<script>");
			if(remove != null)fhtml = fhtml.replace(remove, "");
			
			floorHtml+=U.getSectionValue(fhtml, "<div class=\"Home_aboutContent\"", "</div>")+
					U.getSectionValue(fhtml, "<h1 data-reactid=\"", "Plan Photos</h2>")+U.getSectionValue(fhtml, "<ul class=\"DetailHeader_bedsList\"", "</ul>");
		}

		String floordescsec[]=U.getValues(floorHtml, "\"HomeLinks_commplan\"", "</div>");
		String floordescsec1[]=U.getValues(floorHtml, "\"Home_aboutContent\"", "</div>");
		String floorDesc1="",floorDesc2="";
		for(String fd:floordescsec) {
			floorDesc1+=fd;
		}
		for(String fd1:floordescsec1) {
			floorDesc2+=fd1;
		}
	//	String floorPriSec[]=U.getValues(floorHtml, "", To)
		
		String commDesc = U.getSectionValue(comHtml, "\",\"description\":\"", "\"")
				+U.getSectionValue(comHtml, "><div class=\"Community_overviewSection\"", "Come Meet Us<!-- ")+ U.getSectionValue(comHtml, "<div class=\"DetailHeader_shortDescription\"", "</div>");
		String cType = ALLOW_BLANK;

		
		// ===============================price============================================
		String prices[] = { ALLOW_BLANK, ALLOW_BLANK };
		prices = U.getPrices(fContent + aContent + comSec+availPrices + commDesc.replace("0K’S", "0,000"), "\\$\\d{3},\\d{3}", 0);
//		U.log("MMMMMMMMMMM "+Util.matchAll(comSec , "[\\s\\w\\W]{30}\\$389,900[\\s\\w\\W]{50}",0));

		
		
		U.log(Arrays.toString(prices));

		// ==============================sqft================================================
		String sqft[] = { ALLOW_BLANK, ALLOW_BLANK };
		// U.log(fContent+aContent+comSec);
		String comMainDesc = U.getSectionValue(comHtml, "\"DetailHeader_bedsList\"", "Garages</b>");
		sqft = U.getSqareFeet(
				(fContent + aContent + comSec + comMainDesc+commDesc).replace("<b data-reactid=\"222\">1,930</b>", ""),
				">\\d{1},\\d{3}<|\\d,\\d{3} square feet to \\d,\\d{3} square feet|\\d,\\d{3} to more than \\d,\\d{3} square feet|\\d,\\d{3} square feet", 0);

		U.log(Arrays.toString(sqft));

		// =========================communitytype

		cType = U.getCommType(commDesc);

		// ===================propertyType================================
		String pType = ALLOW_BLANK;

		String avaDesc = "";
		String availableDesc[] = U.getValues(availHtml, "\"DetailHeader_bedsList\"", "DetailHeader_links");
		for (String avDes : availableDesc) {

			avaDesc += avDes;
		}
		String flDesc = "";
		String floorDesc[] = U.getValues(floorHtml, "\"DetailHeader_bedsList\"", "DetailHeader_links");
		
		for (String flDes : floorDesc) {

			flDesc += flDes;
		}
		commDesc = commDesc.replaceAll("has no HOA", "");
		//U.log(flDesc);
		pType = U.getPropType((commDesc+floorDesc1+floorDesc2+avaDesc).replaceAll("Craftsman, Farmhouse,", "Craftsman and Farmhouse style homes"));

		U.log("pType::::::" + pType);
		// ============================dproptype=================================
		String dType = ALLOW_BLANK;
		flDesc = flDesc.replaceAll("1</b><!-- react-text: \\d{3} -->Stories", "1 Story")
				.replaceAll(">2</b><!-- react-text: \\d{3} -->Stories", "2 Story");
		avaDesc = avaDesc.replaceAll(">1</b><!-- react-text: \\d{3} -->Stories", "1 Story")
				.replaceAll(">2</b><!-- react-text: \\d{3} -->Stories", "2 Story");
		floorHtml = floorHtml.replaceAll(">1</b><!-- react-text: \\d{3} -->Stories", "1 Story")
				.replaceAll(">2</b><!-- react-text: \\d{3} -->Stories", "2 Story");
		dType = U.getdCommType((commDesc + avaDesc + flDesc + floorHtml));
		U.log("dType::::::" + dType);
		 
		// =======================propertyStatus===================================

		String pStatus = ALLOW_BLANK;

		commDesc=commDesc.replaceAll("under construction that will be available soon|With two sold out communities in|1 ACRE HOMESITES! COMING SOON|Coming Soon in Princeton|new homes in Fort|Landing community that is Coming Soon", "");
//		U.log(comSec);

		pStatus = U.getPropStatus
				((commDesc + comSec).replace("HOMESITES-NOW SELLING", "HOMESITES NOW SELLING"));
//		U.log("kkkkkkkkkk "+Util.matchAll(commDesc , "[\\s\\w\\W]{100}soon[\\s\\w\\W]{50}", 0));
//		U.log("kkkkkkkkkk "+Util.matchAll( comSec, "[\\s\\w\\W]{100}soon[\\s\\w\\W]{50}", 0));

		U.log("status:::::::" + pStatus);

		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;

		if (comUrl.contains("https://www.riversidehomebuilders.com/communities/princeton/falcon-landing"))
			comName = "Falcon Landing";
		if(pStatus!=null)
			pStatus = pStatus.replace("New Phase Coming, New Phase Coming Soon", "New Phase Coming Soon");
		
		data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus.replace("Iii", "III").replace("Ii", "II"));
		data.addNotes(U.getnote(comHtml));
		data.addUnitCount(units);
		data.addConstructionInformation(startDt, endDt);


		}
	j++;

	}
	
	public static String getUnits(String html, String comUrl, WebDriver driver) throws Exception {
		
		String totalUnits = ALLOW_BLANK; String frameUrl = ALLOW_BLANK; String propertyID = ALLOW_BLANK; String mapLink = ALLOW_BLANK;
		String mapData = ALLOW_BLANK;
		int totalCount = 0;
		
		if(html.contains("<a href=\"https://myhome.anewgo.com")) {
			
			frameUrl = U.getSectionValue(html, "<a href=\"https://myhome.anewgo.com", "\" target");
			frameUrl = "https://myhome.anewgo.com" + frameUrl;
			U.log("frameUrl: "+frameUrl);
			
			mapData = U.getHtml(frameUrl, driver);
			
			if(mapData.contains("<text x=\"50%\" y=\"50%\"")) {
				
				ArrayList<String> pins = Util.matchAll(mapData, "<text x=\"50%\" y=\"50%\"", 0);
				U.log("Count Pins: "+pins.size());
				totalUnits = String.valueOf(pins.size());
			}
			
			
		}
		
		return totalUnits;
	}
	
	

}
