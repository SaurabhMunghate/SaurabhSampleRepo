package com.shatam.b_325_353;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.logging.impl.AvalonLogger;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;

public class ExtractSKBuilders extends AbstractScrapper{
	CommunityLogger LOGGER;

	static int j = 0;

	public ExtractSKBuilders() throws Exception {

		super("SK Builders", "https://www.builderpeople.com/");
		LOGGER = new CommunityLogger("SK Builders");
	}

	public static void main(String[] args) throws Exception {

		AbstractScrapper u = new ExtractSKBuilders();
		u.process();
		FileUtil.writeAllText(U.getCachePath() + "SK Builders.csv", u.data().printAll());

	}

	@Override
	protected void innerProcess() throws Exception {
		
		String mainHtml=U.getHTML("https://www.builderpeople.com/communities");
		
		String comSections[]=U.getValues(mainHtml, "<div class=\"CommunityCard_inner\"", "Visit Location");
		for(String comSec:comSections) {
			String comUrl="https://www.builderpeople.com"+U.getSectionValue(comSec, "href=\"", "\"");

			
			addDetails(comUrl, comSec);
		}
		LOGGER.DisposeLogger();
	}

	public void addDetails(String comUrl, String comSec) throws Exception {
	
		//U.log(j+"================");
		
//		if(!comUrl.contains("https://www.builderpeople.com/communities/piedmont/ashmore-lakes"))return;
		U.log(comUrl);
		
	
		LOGGER.AddCommunityUrl(comUrl);
		String comHtml=U.getHTML(comUrl);
		
		
		//=========================address section===========================================
		String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
		String latlag[] = { ALLOW_BLANK, ALLOW_BLANK };
		String geo = "FALSE";
		
		String addressSec=U.getSectionValue(comHtml, "row DetailDescription_info", "DetailDescription_iconList");

		U.log(addressSec);
		addressSec=addressSec.replaceAll("\"\\d{3}\"", "").replaceAll("<!-- react-text: \\d{3} -->", "<!-- react-text:-->").replaceAll("<!-- react-text:-->|<!-- /react-text -->", "");
		
		String comName=U.getSectionValue(addressSec, "<strong data-reactid=>", "</strong>").replace("O&#x27;Neal Village", "O'NEAL VILLAGE");
		U.log(comName);
		
		String addSec=U.getSectionValue(addressSec, "</li></ul><ul data-reactid=>", "</li></ul><ul data-reactid=>");
		addSec=addSec.replace("</li>", ",").replace("<li data-reactid=>", "");
		//U.log(addSec);
		
		
		add=U.getAddress(addSec);
		
		add[0]=formatStreetAddress(add[0]);
		
		
		U.log(Arrays.toString(add));
		
		
		latlag[0]=U.getSectionValue(addressSec, "/@", ",");
		latlag[1]="-"+U.getSectionValue(addressSec, ",-", "/");
		
		U.log(Arrays.toString(latlag));
		U.log(geo);
		
		
		//==============homes ==================================
		String hData="";
		String homeHtml="";
		String detailHomes = "";
		String homesData[]=U.getValues(comHtml, "\"HomeCard_inner\"", "View Detail");
		for(String hd:homesData) {
			hData+=hd;
			String homeUrls[]=U.getValues(hd, "href=\"", "\"");
			for(String hu:homeUrls) {
				String homeUrl="https://www.builderpeople.com"+hu;
				if(homeUrl.contains("comhttps") || !homeUrl.contains("homes"))continue;
				homeHtml+=U.getHTML(homeUrl);
				U.log("homeLL:::"+homeUrl);
				//U.log(U.getSectionValue(U.getHTML(homeUrl), "<div class=\"DetailHeader_infoWrapper\"", "Floor Plans<!-- /react-text --></h3>"));
				detailHomes += U.getSectionValue(U.getHTML(homeUrl), "<div class=\"DetailHeader_infoWrapper\"", "Floor Plans<!-- /react-text --></h3>");
			}
		}
		
		
		
		//=====================floor plans
		String floorData[]=U.getValues(comHtml, "<div class=\"PlanCard_content\"", "View Detail");
		String fData="";
		String planHtml="";
		
		for(String fd:floorData) {
			fData+=fd;
			String planUrls[]=U.getValues(fd, "href=\"", "\"");
			for(String pu:planUrls) {
				String planUrl="https://www.builderpeople.com"+pu;
				if(planUrl.contains("comhttps") || !planUrl.contains("/plan"))continue;
		//		U.log("planLL:::"+planUrl);
				planHtml+=U.getSectionValue(U.getHTML(planUrl),"<li class=\"DetailHeader_iconListItem","><div class=\"DetailSection text-center\" id=\"gallery\"");
			}
		}
		//===========================prices=====================================
		String prices[]= {ALLOW_BLANK,ALLOW_BLANK};
		U.log("kkkkkkkkkk "+Util.matchAll(comSec+fData+hData, "[\\s\\w\\W]{100}\\$402[\\s\\w\\W]{200}", 0));
		prices=U.getPrices(comSec+fData+hData, "\\$\\d{3},\\d{3}", 0);
		//U.log(detailHomes);
		U.log(Arrays.toString(prices));
		
		//============================sqft-========================================
		String sqft[]= {ALLOW_BLANK,ALLOW_BLANK};
		String comSqftSec=U.getSectionValue(comHtml, "\"DetailHeader_iconListValue\"", "</span>");
		U.log(comSqftSec);
		
		sqft=U.getSqareFeet(comSec+fData+hData+comSqftSec, "-->\\d{1},\\d{3}<!|>\\d{1},\\d{3}<", 0);
		
		U.log(Arrays.toString(sqft));
		
		//=========commtype=======================================================
		String commDesc=U.getSectionValue(comHtml, "\"DetailDescription_preTitle\"", "DetailSection text-center");
		if(commDesc==null)commDesc= U.getSectionValue(comHtml, "<div class=\"DetailDescription_body ", "</div>");
		String amenetiesSec[]=null;
		amenetiesSec=U.getValues(comHtml, "\"Amenities_listItem\"", "</div>");
		String amenNames="";
		for(String aSec:amenetiesSec) {
			amenNames+="/"+aSec;
		}
		U.log(amenNames);
		String headline = U.getSectionValue(comHtml, "<div class=\"DetailHeader_marketingHeadline\"", "</div>");

		String cType=U.getCommType(commDesc+amenNames);
		U.log(cType);
		
		
		String pType=ALLOW_BLANK;
		pType = U.getPropType(commDesc+amenNames+planHtml+headline+detailHomes);

		U.log("pType::::::" + pType);
		// ============================dproptype=================================
		String dType = ALLOW_BLANK;

		String availdata[]=U.getValues(homeHtml, "\"DetailDescription_price\"", "d-flex");
		String storySec1="";
		for(String avdata:availdata) {			
			storySec1+=avdata;
		}
		storySec1=storySec1.replace("<!-- /react-text --><!-- react-text: \\d+ --> Levels", " Story").replace("-->1<!-- /react-text --><!-- react-text: 219 --> Levels", "1 Story");
		
		String floordata[]=U.getValues(planHtml, "\"DetailDescription_price\"", "d-flex");
		String storySec2="";
		for(String fvdata:floordata) {
			storySec2+=fvdata;
		}
		storySec2=storySec2.replace("-->2<!-- /react-text --><!-- react-text: 219 --> Levels", "2 Story").replace("-->1<!-- /react-text --><!-- react-text: 219 --> Levels", "1 Story");
				
		dType = U.getdCommType((commDesc+storySec1+storySec2+planHtml).replaceAll("<!-- /react-text --><!-- react-text: \\d+ --> Levels", " story"));
		U.log("dType::::::" + dType);

		// =======================propertyStatus===================================
		U.log(":::::::::::::::::::"+commDesc);
		String pStatus = ALLOW_BLANK;
		pStatus = U.getPropStatus((commDesc+ comSec+headline).replace("Phase II opening projected for July 2022", "Phase II opening July 2022").replace("for a move-in ready option", "")
				.replace("Phase II opening projected for July 2022", "Phase II opening July 2022")
				.replace("Limited Home Sites Remaining", "Limited Homesites Remaining"));

		
		U.log("status:::::::" + pStatus);
//		U.log(">>>>>>>>>>>>"+Util.matchAll(commDesc+ comSec+headline, "[\\s\\w\\W]{30}[\\s\\w\\W]{30}", 0));
		
		if (prices[0] == null)
			prices[0] = ALLOW_BLANK;
		if (prices[1] == null)
			prices[1] = ALLOW_BLANK;
		if (sqft[0] == null)
			sqft[0] = ALLOW_BLANK;
		if (sqft[1] == null)
			sqft[1] = ALLOW_BLANK;
		
		if(comUrl.contains("/communities/greenville/forest-ridge"))pStatus="One Basement Home Remaining";
		comName = comName.replace(":", "").replaceAll("Cottages$", "").replace("O'NEAL VILLAGE", "O'Neal Village" + 
				"");
		data.addCommunity(comName.replace("&#x27;s", " &"), comUrl, cType);
		data.addLatitudeLongitude(latlag[0], latlag[1], geo);
		data.addPrice(prices[0], prices[1]);
		data.addAddress(add[0].replace(",", ""), add[1], add[2], add[3]);
		data.addSquareFeet(sqft[0], sqft[1]);
		data.addPropertyType(pType, dType);
		data.addPropertyStatus(pStatus);
		data.addNotes(U.getnote(comHtml));
		data.addConstructionInformation(ALLOW_BLANK, ALLOW_BLANK);
		data.addUnitCount(ALLOW_BLANK);

		U.log("==================" + j);
     
		j++;
		}
	
	
	public String formatStreetAddress(String street) {
		String[] words = street.split(" ");
  		String capital = null, wd;
  		for (String word : words) {
  			wd = word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase();
  			capital = (capital == null) ? wd : capital + " " + wd;
  		}
       street=capital;
  		
  		return street;
	}
	
	
	
}