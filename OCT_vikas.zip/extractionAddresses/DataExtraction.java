package com.shatam.extractionAddresses;

public class DataExtraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
