package com.shatam.scheduler;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.shatam.b_001_020.ExtractLennar;
import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;


public class AsynchronousTaskTest {

	final static long DAY = 24 * 60 * 60 * 1000L;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
		long initDelay  = getTimeMillis("04:00:01") - System.currentTimeMillis();
		initDelay = initDelay > 0 ? initDelay : DAY + initDelay;
		
		scheduler.schedule(
				new BuilderName(
						new ExtractLennar(), 
						"Lennar Homes"
						), initDelay, TimeUnit.MILLISECONDS);
		
		scheduler.shutdown();
	}
	
	private static long getTimeMillis(String time) {
		try {
			DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
			DateFormat dayFormat = new SimpleDateFormat("yy-MM-dd");
			Date curDate = dateFormat.parse(dayFormat.format(new Date()) + " " + time);
			return curDate.getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}

}
class BuilderName implements Runnable{
	AbstractScrapper aScrapper =  null;
	String builderName = null;
	
	BuilderName(AbstractScrapper aScrapper, String builderName){
		this.aScrapper = aScrapper;
		this.builderName = builderName;
	}
	
	@Override
	public void run() {
		try {
			aScrapper.process();
			FileUtil.writeAllText(U.getCachePath() + builderName +".csv", aScrapper.data().printAll());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}	
}


