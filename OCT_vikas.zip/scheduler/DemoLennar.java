package com.shatam.scheduler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.shatam.scrapper.AbstractScrapper;
import com.shatam.utils.CommunityLogger;
import com.shatam.utils.FileUtil;
import com.shatam.utils.U;
import com.shatam.utils.Util;


public class DemoLennar extends AbstractScrapper {
	public static ArrayList<String> comList = new ArrayList<>();
	public static ArrayList<String> repeatedList = new ArrayList<>();
	public static int repeated = 0 ;
	static CommunityLogger LOGGER;
	static WebDriver driver = null;
	
	
	public DemoLennar() throws Exception {
		super("Lennar Homes", "https://www.lennar.com/");
		LOGGER = new CommunityLogger("Lennar Homes-26-Mar-2018");
	}

	
	
	public static void main(String[] args) throws Exception {
		AbstractScrapper a = new DemoLennar();
		a.process();
	}
	@Override
	protected void innerProcess() throws Exception {
		// TODO Auto-generated method stub
		U.setUpGeckoPath();
		LOGGER = new CommunityLogger("Lennar-Logger-Demo"); 
		driver  = new FirefoxDriver();
		int myCount = 0;
		// TODO Auto-generated method stub
		String url = "https://www.lennar.com/find-a-home";
		String html = U.getHTML(url);
		String sec = U.getSectionValue(html, "Find the best Lennar home", "Find your new Lennar neighborhood");
		String[] regUrls = U.getValues(sec, "</li><li><a ", ">");
		U.log(regUrls.length);
		for(String regUrl : regUrls){
			if(regUrl.contains("https://www.candlelighthomes.com/"))continue;
			
			regUrl ="https://www.lennar.com"+ U.getSectionValue(regUrl, "href=\"", "\"");
			System.out.println("regUrl : "+regUrl);
			String regHtml = U.getHTML(regUrl);
			
			//------Check Com Count-----
			String count = U.getSectionValue(regHtml, "var OriginPOIVal = \"View ", " New Home Communities in the ");
			myCount += Integer.parseInt(count);
			
			findCommunity(regHtml);
			break;
		}
		U.log("Total Count : "+myCount);
		U.log("repeated : "+repeated);
		try {
			driver.close();
			driver.quit();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		LOGGER.DisposeLogger();
	}
	  
	private static void findCommunity(String regHtml) throws Exception {
		// TODO Auto-generated method stub
		//-----Com Urls----
		String sections = U.getSectionValue(regHtml, "<section class=\"neighsearchsoc\">", "Find your new Lennar neighborhood");
		//System.out.println(sections);
		String comSection [] = U.getValues(sections, "</li><li><a href=\"", "\">");
		U.log("comSection Count : "+comSection.length);
		
		for(String comSec: comSection){
			//System.out.println("comSec : "+comSec);
			String comUrl = "https://www.lennar.com" +comSec;
			System.out.println("comUrl : "+comUrl);
			/*String comHtml = U.getHtml(comUrl, driver);
			if(contains(comList, comUrl)){
				repeated++;
				repeatedList.add(comUrl);
				LOGGER.AddCommunityUrl(comUrl+":::::::::::::repeated:::::::::::");
				continue;
			}
			else{
				comList.add(comUrl);
				if(comHtml.contains("<h1>OOPS</h1><p>We're sorry")){
					LOGGER.AddCommunityUrl(comUrl+":::::::::::::Server Error:::::::::::");
					return;
				}
				else if(comHtml.contains("ennar.com is currently undergoing routine maintenance")){
					LOGGER.AddCommunityUrl(comUrl+":::::::::::::maintenance:::::::::::");
					return;
				}
				else{
				LOGGER.AddCommunityUrl(comUrl);
				}
			}*/
			//Add Details
			addDetails(comUrl);
		}
		
	}
	private static void addDetails(String comUrl) throws Exception {
		// TODO Auto-generated method stub
		
		String html = U.getHtml(comUrl, driver);
		
			if(data.communityUrlExists(comUrl)){
				LOGGER.AddCommunityUrl(comUrl+":::::::::::::Repeated:::::::::::");
				return;
			}	
			if(html.contains("<h1>OOPS</h1><p>We're sorry")){
				LOGGER.AddCommunityUrl(comUrl+":::::::::::::Server Error:::::::::::");
				return;
			}
			if(html.contains("ennar.com is currently undergoing routine maintenance")){
				LOGGER.AddCommunityUrl(comUrl+":::::::::::::maintenance:::::::::::");
				return;
			}
			LOGGER.AddCommunityUrl(comUrl);
			
		
			//---------Community Name--------------------
			String commName = U.getSectionValue(html,"Community Name\" content=\"", "\">");
			
			U.log("1st commNAme is here : "+ commName);
			if (commName == null) {
					commName = Util.match(html,"content=\"(.*?)\" name=\"Community Name\" ",	1);
					U.log("2nd commName :: "+commName);
			}
			//----------End Community Name---------------
			
			/*String htmlPart = U.getSectionValue(html,"<span id=\"content_2_seoLinks\"", "</span>");
			String matchValue = Util.match(html,"<span id=\"cntCom\">\\d[1-9]?+\\s+Communities", 0);
			if (matchValue != null) {
					return;
			}

			if (htmlPart != null)	return;

			for (int rept = 0; rept < 3; rept++) {
					if (html.toLowerCase().contains("unknown host")) {
							U.log("UNKNOWN HOST");
							boolean bool = false;
							String fileName = U.getCache(comUrl);
							U.log(fileName);
							File cacheFile = new File(fileName);
							if (cacheFile.exists()) {
									bool = cacheFile.delete();
									U.log("bool=" + bool);
							}
							html = U.getHtml(comUrl, driver); // PhantomIntegration.getSource(comUrl);
					}
			}*/
			
			//-------Quick Price Html-----------
			String fileName = U.getCache(comUrl).replace("lennar.com",	"lennar.comQuickkk");
			//File f = new File(fileName);

			String pricehtml = U.getHtml(comUrl, driver, true);
			pricehtml = FileUtil.readAllText(fileName);
			U.log("Price Quick File==" + fileName);
			
			//=============== Address =======================
			String[] add = new String[] { ALLOW_BLANK, ALLOW_BLANK,	ALLOW_BLANK, ALLOW_BLANK };
			String secAdd = U.getSectionValue(html,	"<span class=\"deskt-show\">", "</span>");
			U.log("secAdd *:" + secAdd);

			if (secAdd == null) {
				LOGGER.AddCommunityUrl(comUrl	+ "**********************************address section");
				secAdd = U.getSectionValue(pricehtml,	"<span class=\"deskt-show\">", "</span>");
				U.log("ADDSEC Null......"+secAdd);
			}

			secAdd = U.formatAddress(secAdd.replace("CALL FOR APPOINTMENT", ""));
			
			String[] addr = U.getAddress(secAdd);
			U.log(Arrays.toString(addr)+":::::::::::::::::::::");
			if (addr != null)
				add = addr;

			if (add[0] == ALLOW_BLANK) {
					secAdd = U.getSectionValue(secAdd,	"class=\"title13_1\">", "</div");
					U.log("secadd==" + secAdd);
					if (secAdd == null) {

					} else {
							secAdd = U.formatAddress(secAdd);
							addr = U.getAddress(secAdd);
							if (addr != null)
									add = addr;
					}
			}

			add[0] = add[0].replace("&amp;", "&");
			add[0] = add[0].toLowerCase().replaceAll("by apointment only|by appointent only|coming soon|,fl|trail er:|sold out", ALLOW_BLANK);
			add[0] = add[0].replaceAll("^davidson-|^welcome home center: |\\(.*?\\)", "");
			add[0] = add[0].toLowerCase().replaceAll("CALL FOR APPOINTMENT|model home -|model -|model home sold / call for information|please call for an appointment",ALLOW_BLANK);
			add[0] = add[0].replace(", (trail, er)", "").replace(" gps: 4016 truelove", "").replace("gps: royal glen dr", "").replace(", - mirada", "");
			add[0] = add[0].replace(".", "")	.replace("(whc location differs)", "")	.replace("(whc Trail Er)", "");
			add[0] = add[0].replace("trail, er:", "");
			U.log("===My Address ::: " + add[0]);
			add[0] = add[0].replace(", frisco, tx, 75035", "");
			U.log(">>> Street ::" + add[0] + " City ::" + add[1] + " ST ::"	+ add[2] + " Zip ::" + add[3]);
			//----------End Address--------------
			
			//=========== Lat Long ===========================
			String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
			lat = U.getSectionValue(html, "var latitude = parseFloat('", "'");
			lng = U.getSectionValue(html, "var longitude = parseFloat('", "'");
			U.log("Lat : " + lat +"\t lng : "+ lng);
			/*String lati = U.getSectionValue(html,"og:latitude\" content=\"", "\"");
			//U.log("hello");
			String longi = U.getSectionValue(html,	"og:longitude\" content=\"", "\"");

			lat = (lati != null) ? lati : ALLOW_BLANK;
			lng = (longi != null) ? longi : ALLOW_BLANK;
			if (lat != ALLOW_BLANK && lat.length() == 5)
					lat = lat + "000";

			lat = U.getSectionValue(html,"var latitude = parseFloat('", "')");
			lng = U.getSectionValue(html,"var longitude = parseFloat('", "')");

			String geo = "False";

			
			if(lat==null || lat.contains("-")){
				String tempSec=U.getSectionValue(pricehtml, "<script type=\"text/javascript\">var communityId =", "</style>");
				lat=U.getSectionValue(tempSec, "var latitude = parseFloat('", "'");
				lng=U.getSectionValue(tempSec, "var longitude = parseFloat('", "'");
			}
			U.log("Lat:" + lat + " Long:" + lng);
			if(lat==null || lat.contains("-")){
				lat=ALLOW_BLANK;
				lng=ALLOW_BLANK;
			}*/
			
			/*if(lng.equals("40.328783") && lng != null){
					lat= "40.328783";
					lng = "-74.376032";
			}*/
			/*if(lat.contains("-")){
					//only if lat contains '-'
					String temp=lat;
					lat=lng;
					lng=temp;
			}*/
			//----------End Lat-Lng--------------
			
			//------------Price---------
			String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
			html = formatMillionPrices(html); 
			String [] price = U.getPrices(html+pricehtml,	"Pricing from \\$[\\d{1},]*\\d+,\\d+[s]* - \\$[\\d{1},]*\\d+,\\d+[s]*|Price from \\$[\\d{1},]*\\d+,\\d+", 0);

			minPrice = (price[0] == null) ? ALLOW_BLANK : price[0];
			maxPrice = (price[1] == null) ? ALLOW_BLANK : price[1];
			
			U.log("minPrice : "+minPrice + "\t maxprice : "+ maxPrice);
			// ===============End Price =============================
			
			// ================= Square Feet ===========================
			String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
			String[] sqft = U.getSqareFeet(html + pricehtml,"Square footage from \\d,\\d+ to \\d,\\d+|sq-ft\">\\d,\\d+<abbr",0);

			minSqf = (sqft[0] == null) ? ALLOW_BLANK : sqft[0];
			maxSqf = (sqft[1] == null) ? ALLOW_BLANK : sqft[1];
			U.log("minSqf : "+minSqf + "\t maxSqf : "+ maxSqf);
			// =================End Square Feet ===========================
			
			//============== Property Status ======================
			String modifiedHtml = U.getSectionValue(html, "carousel masthead-detail","Latest posts from our blog,");
			
			if(modifiedHtml != null){
				}
	}


	private static  String formatMillionPrices(String html){
		Matcher millionPrice = Pattern.compile("\\$\\d\\.\\d M",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice.find()){
			//U.log(mat.group());
			String floorMatch = millionPrice.group().replace(" M", "00,000").replace(".", ",");  //$1.3 M
			html	 = html.replace(millionPrice.group(), floorMatch);
			}//end millionPrice
		return html;
	}
	public static boolean contains(ArrayList<String> arr, String item) {
	      for (String n : arr) {
	         if (n.equals(item)) {
	            return true;
	         }
	      }
	      return false;
	   }

}
