package com.shatam.scrapper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;

import com.shatam.utils.CommunityList;
import com.shatam.utils.U;
import com.shatam.utils.UnicodeDecoder;
import com.shatam.utils.Util;


public abstract class AbstractScrapper {

    protected static final String ALLOW_BLANK = "-";


    public CommunityList data() {

        return data;
    }

    protected static CommunityList data        = null;

    //public String           builderName = null;


    public AbstractScrapper(String builderName, String builderUrl) throws Exception {

        //this.builderName = builderName;
        data = new CommunityList(builderName, builderUrl);
        
    }

    static StringBuffer lockObj = new StringBuffer();


    public void process() throws Exception {

        //Only one scrapper at a time.
        synchronized (lockObj) {
            innerProcess();
        }
    }


    protected abstract void innerProcess() throws Exception;


    protected String[] extractPrices(String html) throws ParseException {

        if (html.contains("\\u0")) {
            html = UnicodeDecoder.decode(html);

        }
        html = html.toLowerCase();

        //Remove single quotes.
        html = html.replace("&#039;", "");

        //U.log("A html:" + html);

        //if (html.contains("from")) {
        if (html.contains("high ")) {
            html = html.replaceAll("00'*s", "50,000");
        }

        for (int i = 0; i < 10; i++) {
            html = html.replaceAll(i + "'*s", i + ",000");
        }

        if (html.contains("million")) {
            for (int i = 0; i < 10; i++) {
                //U.log("\\." + i + "\\s*million");
                if (html.contains("." + i + " million")) {
                    html = html.replace("." + i + " million", i + "00000");
                    //U.log("\n"+i+"] "+html);
                }
                else {
                    html = html.replaceAll(i + "\\s*million", i + "000000 ");
                }
            }
        }

        //U.log("A:"+html);

        ArrayList<String> availablePrices = Util.matchAll(html, "(\\$[0-9]{2,3},*[0-9]{3})", 1);

        if (availablePrices.size() == 0) {
            //from $1.38
            ArrayList<String> arr = Util.matchAll(html, "\\$(\\d\\.\\d{2})", 1);
            for (String pr: arr){
                availablePrices.add("$"+pr.replace(".", ",") + "0,000");
            }
        }

        
        if (availablePrices.size() == 0) {
           // U.log("B HTML :" + html);
        }
        
        if (availablePrices.size() == 1) {
            return new String[]{availablePrices.get(0), ALLOW_BLANK};
        }
        else {
            Collections.sort(availablePrices);
            return new String[]{availablePrices.get(0), availablePrices.get(availablePrices.size() - 1)};
        }
        //}

    } //extractPrices()



    protected String[] extractSqFt(String source) {

        //2,431 - 4,065 Sq. Ft.        

        source = "  " + source + " ";
        //SQ_FT = 1*[1-9],[0-9]{3}
        //SQ_FT_NO_COMMA = [0-9]{4}
        ArrayList<String> sqFt = Util.matchAll(source, "[^0-9](1*[1-9],*[0-9]{3})[^0-9]", 1);

        if (sqFt.size() == 1) {
            return new String[]{sqFt.get(0), ALLOW_BLANK};
        }
        else {
            Collections.sort(sqFt);
            return new String[]{sqFt.get(0), sqFt.get(sqFt.size() - 1)};
        }

    }


    public void setBuilderName(String name) {

        //if (name.endsWith(".") || name.endsWith(")"))
        //    name = name.substring(0, name.length() - 1);
        this.data.setBuilderName(name);
        
    }
  

    public String getBuilderName() {

        // TODO Auto-generated method stub
        return data.getBuilderName();
    }
}
