package com.shatam.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FilenameUtils;

public class CommunityLogger {
	
	private String _BuilderName ;
	
	private BufferedWriter _Writer;
	
	public String dirPath = U.getCachePath();
	
	private Date _date;
	
	private SimpleDateFormat _timeFormat;

	public CommunityLogger(String builderName) throws IOException
	{
		_BuilderName = builderName + ".txt";
		File file = new File(FilenameUtils.concat(dirPath, _BuilderName));
		_Writer = new BufferedWriter(new FileWriter(file));
		_date = new Date( );
		_timeFormat = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
	}
	
	public void AddRegion(String Region, int communityCount) throws IOException
	{
		_Writer.newLine();
		_Writer.append("Region : " + Region +" : Community Count : " +communityCount +" : Time : "+_timeFormat.format(_date));
		
	}
	public void AddSubRegion(String SubRegion, int communityCount) throws IOException
	{
		_Writer.newLine();
		_Writer.append("SubRegion : " + SubRegion +" : Community Count : " +communityCount +" : Time : "+_timeFormat.format(_date));
		
	}
	
	public void AddCommunityUrl(String url)throws Exception
	{
		_Writer.newLine();
		_Writer.append("Community Url : " + url +" : Time : "+_timeFormat.format(_date));
	}
	
	public void countOfCommunity( int communityCount) throws IOException
	{
		_Writer.newLine();
		_Writer.append(" : Community Count : " +communityCount);
		
	}
	
	public void DisposeLogger() throws IOException
	{
		_Writer.close();
	}
	
}
