/*
 * Auther - Ashish
 * Date - 6/5/15
 * Modified Date - 6/12/15
 *  
 */

package com.shatam.utils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;
import java.lang.Exception;

import au.com.bytecode.opencsv.CSVWriter;

public class CommunityMatcher {

	/**
	 * @param args
	 */
	class Builder {
		public String commName;
		public String comUrl;
		public String commType;
		public String street;
		public String city;
		public String state;
		public String zip;
		public String latitude;
		public String longitude;
		public String geo;
		public String pType;
		public String dType;
		public String pStatus;
		public String minPrice;
		public String maxPrice;
		public String minSqf;
		public String maxSqf;
		public String note;
	}

	public boolean Match(String oldFilePath, String newFilePath)
			throws Exception {
		File oldFile = new File(oldFilePath);
		File newFile = new File(newFilePath);

		if (!oldFile.exists() | !newFile.exists()) {
			throw new Exception(
					"Either OldFile Or NewFile Doesn't exist on Given path!");
		}

		// Writer

		CsvListReader oldFileReader = new CsvListReader(
				new FileReader(oldFile), CsvPreference.STANDARD_PREFERENCE);

		List<String> oldCsvRow = null;

		ArrayList<Builder> BuilderObjects = GetBuilderObjects(newFilePath);

		int newFileRowCount = BuilderObjects.size();
		// --------------Comparison Logic-----------//

		ArrayList<String[]> List = new ArrayList<String[]>();
		int count2 = 0;

		while ((oldCsvRow = oldFileReader.read()) != null) {

			if (count2 > 0) {

				Boolean flag = false;
				int oldCommunityUrlHashCode = oldCsvRow.get(4)
						.replaceAll("//", "/").trim().toLowerCase().hashCode();
				for (Builder obj : BuilderObjects) {

					int newComUrlHashCode = obj.comUrl.replaceAll("//", "/")
							.trim().toLowerCase().hashCode();
					if (oldCommunityUrlHashCode == newComUrlHashCode) {
						U.log(oldCsvRow.get(4) + " : Matching URL Found :"
								+ obj.comUrl);
						flag = true;
						break;
					}
				}

				U.log("flag :: " + flag);

				if (!flag) {
					int result = CheckUrlForHTML(oldCsvRow.get(4).trim());
					String[] dataObj = oldCsvRow.toArray(new String[oldCsvRow
							.size()]);
					dataObj[0] = "" + newFileRowCount++;
					for (int k = 5; k < oldCsvRow.size(); k++) {
						dataObj[k] = "";
					}
					// Updating Closed Status
					U.log("Status Code :: " + result);

					if (result == 200) {
						dataObj[15] = "Closed";
						dataObj[20] = "200 - This community is ACTIVE but it is not displayed Currently";
					} else if (result == 404) {
						dataObj[15] = "Closed";
						dataObj[20] = "404 - Page Not Found for this Community.";
					} else if (result == 410) {

						dataObj[15] = "Closed";
						dataObj[20] = "410 -  Resource requested is no longer available";
					} else if (result == 403) {

						dataObj[15] = "Closed";
						dataObj[20] = "403 -  The request was a valid request, but the server is refusing to respond to it";
					} else if (result == 405) {

						dataObj[15] = "Closed";
						dataObj[20] = "405 -   Method Not Allowed";
					} else if (result == 408) {

						dataObj[15] = "Closed";
						dataObj[20] = "408 -   Request Timeout";
					} else if (result == 400) {

						dataObj[15] = "Closed";
						dataObj[20] = "400 -   Bad Request";
					}
					else if (result == 302 | result == 301) {
						dataObj[15] = "Closed";
						dataObj[20] = "302|301 - This community is Redirected.";
					} else if (result == 0) {

						dataObj[15] = "Closed";
						dataObj[20] = "0- Response Code returned Error getting status code.";
					} else if (result == 500) {

						dataObj[15] = "Closed";
						dataObj[20] = "500 -  Internal Server Error";
					}
					else if(result == 307){
					dataObj[15]="Closed";
					dataObj[20]="307 - Temporary Redirect";
					}
					else if(result == 503){
					dataObj[15]="Closed";
					dataObj[20]="503 - Currently Unable To Handle";
					}
					else if(result == 524){
						dataObj[15]="Closed";
						dataObj[20]="524 - No Response";
					}
					else{
						throw new Exception("New Response Code");
					}

					List.add(dataObj);

					U.log("Here ::: " + List.size());
					if (List.size() % 100 == 0) {
						// Write Data to file here
						WriteDataToCSV(newFilePath, List);
						List = new ArrayList<String[]>();
					}
				}
			}

			count2++;

			U.log(count2);

		}

		WriteDataToCSV(newFilePath, List);
		List = new ArrayList<String[]>();
		return true;
	}

	private void WriteDataToCSV(String newFilePath, ArrayList<String[]> list)
			throws Exception {
		// TODO Auto-generated method stub
		CSVWriter FileWriter = new CSVWriter(new FileWriter(newFilePath, true));
		for (String[] dataObj : list) {
			FileWriter.writeNext(dataObj);
		}
		FileWriter.close();
	}

	/*
	 * True if Successful / False If Failed to Get HTML
	 */

	private int CheckUrlForHTML(String path) {
		// TODO Auto-generated method stub
		int respCode = 0;
		try {
			/*
			 * URL url = new URL(path);
			 * 
			 * URLConnection urlConnection = url.openConnection(); // Mimic
			 * browser urlConnection .addRequestProperty("User-Agent",
			 * "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2"
			 * ); urlConnection.addRequestProperty("Accept", "text/css,
			 */// ;q=0.1");
			/*
			 * urlConnection.addRequestProperty("Accept-Language",
			 * "en-us,en;q=0.5");
			 * urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			 * urlConnection.addRequestProperty("Connection", "keep-alive");
			 * 
			 * respCode = ((HttpURLConnection) urlConnection).getResponseCode();
			 */
			HttpHost proxy = new HttpHost("138.197.83.21",8080, "http");// Only
																		// Proxy
																		// Server(Close
																		// builder
																		// Add)

			// Only Proxy Server(Close builder Add)
			DefaultHttpClient httpclient = new DefaultHttpClient();
			//httpclient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,proxy);//for proxy
			HttpPost request1 = new HttpPost(path);
			HttpResponse response1 = httpclient.execute(request1);
			respCode = response1.getStatusLine().getStatusCode();

			/*
			 * URL u = new URL(path); HttpURLConnection huc =
			 * (HttpURLConnection) u.openConnection();
			 * huc.setRequestMethod("GET");
			 * 
			 * 
			 * U.log("A getResponseCode url:" + path);
			 * 
			 * huc.connect();
			 * 
			 * 
			 * 
			 * 
			 * respCode = huc.getResponseCode();
			 * U.log("B getResponseCode =="+respCode);
			 */
		} catch (Exception ex) {

			U.log(ex);
			return respCode;
		}
		return respCode;
	}

	/*
	 * Returns Builder Object List for Given File Name
	 */
	private ArrayList<Builder> GetBuilderObjects(String newFile)
			throws Exception {

		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		ArrayList<Builder> BuilderObjects = new ArrayList<Builder>();

		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {
				BuilderObjects.add(getBuilderObj(newCsvRow));
			}
			count++;
		}
		newFileReader.close();
		return BuilderObjects;
	}

	private Builder getBuilderObj(List<String> newCsvRow) {
		Builder obj = new Builder();
		obj.commName = newCsvRow.get(3);
		obj.comUrl = newCsvRow.get(4).trim();
		obj.commType = newCsvRow.get(5);
		obj.street = newCsvRow.get(6);
		obj.city = newCsvRow.get(7);
		obj.state = newCsvRow.get(8);
		obj.zip = newCsvRow.get(9);
		obj.latitude = newCsvRow.get(10);
		obj.longitude = newCsvRow.get(11);
		obj.geo = newCsvRow.get(12);
		obj.pType = newCsvRow.get(13);
		obj.dType = newCsvRow.get(14);
		obj.pStatus = newCsvRow.get(15);
		obj.minPrice = newCsvRow.get(16);
		obj.maxPrice = newCsvRow.get(17);
		obj.minSqf = newCsvRow.get(18);
		obj.maxSqf = newCsvRow.get(19);
		obj.note = newCsvRow.get(20);

		return obj;
	}

}