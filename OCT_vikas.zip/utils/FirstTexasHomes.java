package com.shatam.utils;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;

import com.shatam.scrapper.AbstractScrapper;

public class FirstTexasHomes extends AbstractScrapper {
int k=0;
public int inr=0;
static int i=0;
	HashMap<String, String> hm = new HashMap<String, String>();

	public static void main(String[] arg) throws Exception {

		AbstractScrapper a = new FirstTexasHomes();
		a.process();
		a.data().printAll();
		FileUtil.writeAllText("c:/cache/First Texas Homes.csv", a	.data().printAll());
		
	}

	public FirstTexasHomes() throws Exception {

		super("First Texas Homes", "http://www.firsttexashomes.com");
	}

	public void innerProcess() throws Exception {

		// Your code here
		

		String html = U.getHTML("http://www.firsttexashomes.com");
		String[] regions=U.getValues(html, "<li><a class=\"c", "</li>");
		for(String reg:regions)
		{if(i<2)
		{
			i++;
			String regUrl=U.getSectionValue(reg, "href=\"", "\"");
			regUrl="http://www.firsttexashomes.com"+regUrl;
			String regHtml=U.getHTML(regUrl);
			String[] comNames=U.getValues(regHtml, "community_name'] = \"", "\";");
			for(String commName:comNames)
			{
				commName=commName.replace("%20", " ");
				addDetail(commName);
			}
		}
		}
	}
	
	public void addDetail(String commName)throws Exception {
	{
		String commUrl="http://www.firsttexashomes.com/communities/"+commName;
		U.log("Page:" + commUrl);
		if(this.data.communityUrlExists(commUrl))return;
		String commHtml = U.getHTML(commUrl);
		
		// Addres
		String street = ALLOW_BLANK, city = ALLOW_BLANK, state = ALLOW_BLANK, zip = ALLOW_BLANK;
		//commName=commName.replace("%20", " ");
		// String section = U.getHtmlSection(html,
		// "<h3>COMMUNITY ADDRESS</h3>", "</strong><br />");

		String section = U.getSectionValue(commHtml,
				"<h3>COMMUNITY ADDRESS</h3>", "</strong></p>");
		// U.log("hhhh"+section);
		// if(section==null}{
		if (section == null)
		{
			section = U.getSectionValue(commHtml,
					"<h3>SALES CENTER ADDRESS</h3>", "</strong><br />");
		}
		// }
		// if(commUrl.contains("http://www.firsttexashomes.com/communities/Greenstone%20Estates"))
		// return;
		U.log(section);
	//	section=section.replace("<br /> Spring", "").replace("Dr. <br />", "Dr.").replace("Drive <br />","Drive");
		if (section != null) {
			String frAdd = U.formatAddress(section);
			String add[] = { ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK, ALLOW_BLANK };
			try {
			//	frAdd=frAdd.replace(", & ", "");
				U.log("ppp" + frAdd);
				add = U.findAddress(frAdd);

				street = add[0];
				city = add[1];
				state = add[2];
				zip = add[3];
			} 
			catch (java.lang.NullPointerException ex)
			{
				frAdd=frAdd.replace("Road,", "Road");
				add = frAdd.split(",");
				street = add[0].trim();
				city = add[1].trim();
				if(add[2].trim().contains(" "))
				{
					add = add[2].split(" ");
					state = add[1];
				}

				// if(add[2].length()==0)
				try 
				{
					zip = add[2];
				} 
				catch (java.lang.ArrayIndexOutOfBoundsException e)
				{
					zip = ALLOW_BLANK;
				}
			}
		}

		// Latitude and Longitude
		String lat = ALLOW_BLANK, lng = ALLOW_BLANK;
		String add[] = new String[] { "", "", state, zip };
		String latv[] = U.getSectionValue(commHtml, ".maps.LatLng(", ")").split(",");
		
		lat = latv[0];
		lng = latv[1];
	String	flag = "False";	
		
		//.maps.LatLng(
		if(zip!=ALLOW_BLANK&&lat==ALLOW_BLANK)
		{
			 latv = U.getlatlongGoogleApi(add);
			lat = latv[0];
			lng = latv[1];
			flag = "True";	
		}
		U.log("Lat:" + lat + " Long:" + lng);
	
		// Price
		String minPrice = ALLOW_BLANK, maxPrice = ALLOW_BLANK;
		int[] price = getPrice(commHtml);

		minPrice = NumberFormat.getCurrencyInstance().format(price[0])
				.replaceAll("\\.00", "");
		maxPrice = NumberFormat.getCurrencyInstance().format(price[1])
				.replaceAll("\\.00", "");

		minPrice = (price[0] != 0) ? "" + minPrice : ALLOW_BLANK;
		maxPrice = (price[1] != 0) ? "" + maxPrice : ALLOW_BLANK;
		if (minPrice == ALLOW_BLANK) {
			String priceS[] = extractPrices(commHtml);
			minPrice = priceS[0];
			maxPrice = priceS[1];
		}
		// $260's to the $270's

		commHtml = commHtml.replace("$1.5M's", "$1,500,000").replaceAll("'s|'s", ",000");
		
		String[] pric = U.getPrices(commHtml + minPrice + maxPrice,	"\\$\\d+,\\d+ to the $\\d,\\d+,\\d+|Homes from the \\$\\d+,\\d+ to the \\$\\d+,\\d+|from the \\$\\d+,\\d+|75px;\">\\$\\d+,\\d+|bold;\">\\$\\d+,\\d+|<td>\\$\\d+,\\d+", 0);
		minPrice = (pric[0] == null) ? ALLOW_BLANK : pric[0];
		maxPrice = (pric[1] == null) ? ALLOW_BLANK : pric[1];
		U.log("MinPrice :" + minPrice + " MaxPrice:" + maxPrice);

		// Square Feet
		String minSqf = ALLOW_BLANK, maxSqf = ALLOW_BLANK;
		commHtml=commHtml.replace("55px", "px");
		String[] sqf =U.getSqareFeet(commHtml, "style=\"width:px;\">\\s*(\\d+,\\d+)|<td style=\"text-align:center;\">(\\d+,\\d+)</td>", 0);// getSqareFeet(html);
	     
		
		minSqf = (sqf[0] != null) ? "" + sqf[0] : ALLOW_BLANK;
		maxSqf = (sqf[1] != null) ? "" + sqf[1] : ALLOW_BLANK;
		U.log("MIN :" + sqf[0] + " MAX :" + sqf[1]);

		// CommStatus
		String commStatus="";
		//commStatus = Util.match(commHtml,
			//	"communities\\['community_status'\\]\\s+=\\s+\"([^\"]+)\"", 1);
		commStatus = (commStatus == null) ? ALLOW_BLANK : commStatus;
		String remove="= \"Closeout|Lake Pearland is now open|\"closeout";
		String statHtml=commStatus+commHtml.replace(remove, "");
		commStatus = U.getPropStatus(statHtml.toLowerCase().replace("final%20closeout", "Final Closeout"));
		//if(commUrl.contains("http://www.firsttexashomes.com/communities/Lake%20Parks"))	commStatus="Close out";
		if((commHtml.contains("No plans were found with the current criteria")||commHtml.toLowerCase().contains("No plans were found with the current criteria".toLowerCase())))
		{
			if(commStatus.trim().length()<2)
			{
				commStatus="No Quick Move Ins Available";
			}
			else
			{
				commStatus=commStatus+",No Quick Move Ins Available";
			}
		}
		else
		{
			if(commStatus.trim().length()<2)
			{
				commStatus="Quick Move Ins Available";
			}
			else
			{
				commStatus=commStatus+",Quick Move Ins Available";
			}
		}
		commStatus=commStatus.replace("Quick Move-in,","");
		if(commHtml.contains("color: rgb(178, 0, 0);")||(commHtml.contains("<td style=\"text-align:center"))){
				commStatus=commStatus.replace("No Quick Move Ins Available", "Quick Move Ins Available");
				
		}
		U.log("commStatus " + commStatus);

		String Type = U.getCommunityType(commHtml);
		commName=commName.replace("%27", "'");
		commUrl=commUrl.replace("%27", "'");
		
		data.addCommunity(commName, commUrl, Type);
		// Property type
		String pType = ALLOW_BLANK;
		pType = U.getPropType(commHtml);
		if (city.length() == 0)
			city = ALLOW_BLANK;
		String derivedPType = ALLOW_BLANK;

		derivedPType = U.getdCommType(commHtml);
		/*if (pType == ALLOW_BLANK)
			pType = "Single Family";*/
		
		//if(commUrl.contains("http://www.firsttexashomes.com/communities/Woodbridge%20Estates")){maxSqf="4438";	}

		  commStatus=commStatus.replace("!", "");
		
		if(add[0]==ALLOW_BLANK||add[1]==ALLOW_BLANK)
		{
			add=U.getGoogleAdd(lat, lng);
		}
	
if(!zip.matches("\\d+"))zip=ALLOW_BLANK;
String addd = add[0];

if(lat==null)
{
	lat=lng=flag=ALLOW_BLANK;
}

if(lat!=ALLOW_BLANK && city==ALLOW_BLANK||zip==ALLOW_BLANK)
{
	String[] latlng={lat,lng};
	add =U.getAddressGoogleApi(latlng);
	city = add[1];
	zip = add[3];
}
		
if(lat==null||lat=="37.06")
{
	lat=lng=flag=ALLOW_BLANK;
}
add[0] = addd;

//if(state.length()>2)state="TX";
if(commUrl.contains("http://www.firsttexashomes.com/communities/Benders%20Landing%20Estates"))flag="True";
//if(commUrl.contains("http://www.firsttexashomes.com/communities/Marine%20Creek%20Ranch"))zip=ALLOW_BLANK;
street=street.replace("Call For More Information.", ALLOW_BLANK);
if(commName.toLowerCase().contains("benders landing estates"))street="Near Birnham Woods Drive";
commStatus = commStatus.replace("Closeout", "Close Out");

		data.addAddress(street, city, "TX", zip);
		data.addSquareFeet(minSqf, maxSqf);
		data.addPrice(minPrice, maxPrice);
		data.addLatitudeLongitude(lat.trim(), lng.trim(), flag);
		data.addPropertyType(pType, derivedPType);
		data.addPropertyStatus(commStatus);
		data.addNotes(ALLOW_BLANK);
	}

	}
private static int[] getSqareFeet(String code) throws IOException
{
	String htm = code;

	String section = U.getSectionValue(htm, "<div id=\"second\"",
			"<div id=\"third\"");

	ArrayList<String> sqf = Util.matchAll(htm,
			"style=\"width:55px;\">\\s*(\\d+,\\d+)|<td style=\"text-align:center;\">(\\d+,\\d+)</td>", 1);

	int[] intSqf = new int[sqf.size()];
	for (int i = 0; i < sqf.size(); i++)
	{
		intSqf[i] = Integer.valueOf(sqf.get(i).replaceAll(",", ""));
	}
	if (intSqf.length != 0) 
	{
		intSqf = U.getMaxAndMin(intSqf);
		return new int[] { intSqf[1], intSqf[0] };
	}
	return new int[] { 0, 0 };

}

private static int[] getPrice(String code) throws IOException {
	String htm = code;

	String section = U.getSectionValue(htm, "<div id=\"second\"",
			"<div id=\"third\"");

	ArrayList<String> price = Util.matchAll(htm,
			"style=\"width:75px;\">\\s*\\$(\\d+,\\d+)", 1);
	int[] intprice = new int[price.size()];
	for (int i = 0; i < price.size(); i++) {
		intprice[i] = Integer.valueOf(price.get(i).replaceAll(",", ""));
	}
	if (intprice.length != 0) {
		intprice = U.getMaxAndMin(intprice);
		return new int[] { intprice[1], intprice[0] };
	}
	return new int[] { 0, 0 };

}

}
