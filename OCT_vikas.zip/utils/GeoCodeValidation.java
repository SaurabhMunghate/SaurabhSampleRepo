package com.shatam.utils;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

public class GeoCodeValidation {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		//CreateDb();
		/*Boolean f=validationOfGeo("Seattle","WA","98194",new String[]{"47.6000525","-122.3650193"});
		U.log(f);*/
		//selectRecordsFromTable("Seattle","WA","98194");
		U.log(U.getlatlongGoogleApi(new String[]{"North Palm Beach","FL","33408"}));
	}
	private static void selectRecordsFromTable(String city,String state,String zip) throws SQLException, ClassNotFoundException, IOException {

		Connection dbConnection = null;
		PreparedStatement preparedStatement = null;

		String selectSQL = "SELECT * from GeoValidation WHERE city =? and state=? and zip=?";

		try {
			dbConnection = ConnectDatabase();
			preparedStatement = dbConnection.prepareStatement(selectSQL);
			preparedStatement.setString(1,city);
			preparedStatement.setString(2,state);
			preparedStatement.setString(3,zip);
			// execute select SQL stetement
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				String userid = rs.getString("lattitude");
				String username = rs.getString("longitude");

				System.out.println("userid : " + userid);
				System.out.println("username : " + username);

			}

		} catch (SQLException e) {

			System.out.println(e.getMessage());

		} finally {

			if (preparedStatement != null) {
				preparedStatement.close();
			}

			if (dbConnection != null) {
				dbConnection.close();
			}

		}
dbConnection.close();
	}
public static boolean validationOfGeo(String city,String state,String zip,String []latlong) throws SQLException, ClassNotFoundException, IOException
{
	String lat=null,lng = null;
	String southLat=null,southLong=null;
	String northLat=null,northLong=null;
	String zipsouthLat=null,zipSouthLong=null,zipNorthLat=null,zipNorthLong=null;
	Connection dbConnection = null;
	PreparedStatement preparedStatement = null;

	String selectSQL = "SELECT * from GeoValidation WHERE city =? and state=? and zip=?";

	try {
		dbConnection = ConnectDatabase();
		preparedStatement = dbConnection.prepareStatement(selectSQL);
		preparedStatement.setString(1,city.toLowerCase().trim());
		preparedStatement.setString(2,state.toUpperCase().trim());
		preparedStatement.setString(3,zip.trim());
		// execute select SQL stetement
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {

			 U.log("lattitude::::::::::"+rs.getString("lattitude"));
			 lat=rs.getString("lattitude");
			 lng=rs.getString("longitude");
			 southLat=rs.getString("Slattitude");
			 northLat=rs.getString("Nlattitude");
			 zipsouthLat=rs.getString("ZipSouthLat");
			 zipSouthLong=rs.getString("ZipSouthLong");
			 zipNorthLat=rs.getString("ZipNorthLat");
			 zipNorthLong=rs.getString("ZipNorthLong");
			 
					 
			
		 }
		U.log(lat+"=address="+city+"="+state+"="+zip);
		String add[]={"",city.toLowerCase().trim(),state.toUpperCase().trim(),zip.trim()};
		if(lat==null){
			String latlngs[]=U.getCoordinatesGoogleApi(add);
			String zipCoOrdinates[]=U.getCoordinatesZip(zip);
			U.log("::::::::::"+latlngs[0].trim());
			lat=latlngs[0].trim();
			lng=latlngs[1].trim();
			southLat=latlngs[2].trim();
			southLong=latlngs[3].trim();
			northLong=latlngs[5].trim();
			northLat=latlngs[4].trim();
			zipsouthLat=zipCoOrdinates[0];
			zipSouthLong=zipCoOrdinates[1];
			zipNorthLat=zipCoOrdinates[2];
			zipNorthLong=zipCoOrdinates[3];
			String sarray[]={add[1],add[2],add[3],lat,lng,northLat,northLong,southLat,southLong,zipNorthLat,zipNorthLong,zipsouthLat,zipSouthLong};
			
			addaddress(dbConnection,sarray);
		}
		//else	{
			
			
			U.log("Comparison=="+latlong[0]+"::::"+lat);
			U.log("Comparison=="+latlong[1]+"::::"+lng);
	//if(Float.parseFloat(latlong[0])<=Float.parseFloat(lat))
			if(Float.parseFloat(latlong[0]) < Float.parseFloat(northLat) && Float.parseFloat(latlong[0]) > Float.parseFloat(southLat) )
	{
				 dbConnection.close();
		return true;
	}else{
		if(Float.parseFloat(latlong[0]) <= Float.parseFloat(zipNorthLat) && Float.parseFloat(latlong[0]) >= Float.parseFloat(zipsouthLat) ){
			dbConnection.close();
			return true;
		}else{
		 dbConnection.close();
		 return false;
		}
	}
		
	//	}
	
	
		
		}
		catch (Exception e) {
		U.log(e);	

	}
		
	 dbConnection.close();
	 return false;
	 
	}

public static void addaddress(Connection conn,String add[]) throws ClassNotFoundException, IOException {
	
	try {
		
		Class.forName("org.sqlite.JDBC");

	
		Statement stat = conn.createStatement();
		
		//=====================================================================
		/*ResultSet rs = stat.executeQuery("SELECT * FROM GeoValidation");
		ResultSetMetaData rsmd = rs.getMetaData();
		String firstColumnName = rsmd.getColumnName(4);
		U.log(firstColumnName+"::"+rsmd.getColumnName(5));*/
		
		
			int count=0;
		
			// Chk weather it is present or not
			final String queryCheck = "SELECT count(*) AS rowcount from GeoValidation where lattitude=? and longitude =? and city=? and state=? and zip=?";//"SELECT count(*) AS rowcount from GeoValidation WHERE lattitude =? and longitude =? and city=? and state=? and zip=?";
			final PreparedStatement ps = conn.prepareStatement(queryCheck);
			ps.setString(1, add[4]);
			ps.setString(2, add[3]);
			ps.setString(3,add[0]);
			ps.setString(4, add[1]);
			ps.setString(5,add[2]);
			
			final ResultSet resultSet = ps.executeQuery();
			if (resultSet.next()) {
				//U.log(":::::"+resultSet.getString("lattitude"));
				count = resultSet.getInt(1);
			}
		U.log("**"+count);
			if (count == 0) {
				String sql = ("INSERT INTO GeoValidation (city,state,zip,lattitude,longitude,Nlattitude,Nlatlong,Slattitude,Slongitude,ZipNorthLat,ZipNorthLong,ZipSouthLat,ZipSouthLong)VALUES ( '"
						+ add[0]
						+ "','"
						+ add[1]
						+ "','"
						+ add[2].trim()
						+ "','"
						+ add[3].trim()
						+ "','"
						+ add[4].trim()
						+ "','"
						+ add[5].trim()
						+ "','"
						+ add[6].trim()
						+ "','"
						+ add[7].trim()
						+ "','"
						+ add[8].trim()
						+ "','"
						+ add[9].trim()
						+ "','"
						+ add[10].trim()
						+ "','"
						+ add[11].trim()
						+ "','"
						+ add[12].trim()+ "');");
						

				stat.executeUpdate(sql);
				U.log("inserting done");
stat.close();
			}
		
		conn.close();
	} catch (SQLException e) {
		U.log("Problem with connection of database===" + e);
	}
	
	
}
public static void CreateDb() throws ClassNotFoundException, IOException {
	try {

		Connection conn = ConnectDatabase();
		U.log("connection success");
		Statement stat = conn.createStatement();
		
		 String sql =
		 ("CREATE TABLE GeoValidation (ID INTEGER PRIMARY KEY AUTOINCREMENT,city,state,zip,lattitude,longitude,Nlattitude,Nlatlong,Slattitude,Slongitude,ZipNorthLat,ZipNorthLong,ZipSouthLat,ZipSouthLong);");
		 stat.executeUpdate(sql);
		 stat.close();
		 conn.close();
		 U.log("here");
		// stat.executeUpdate("CREATE table address (index INTEGER PRIMARY KEY AUTOINCREMENT,street, city,state,zip,lattitude,longitude);");
	}	 catch (SQLException e) {
				U.log("Problem with connection of database===" + e);
			}
		U.log("hello");
	}
public static Connection ConnectDatabase() throws ClassNotFoundException,
IOException, SQLException 
{
String userDir = System.getProperty("user.dir");
String dataPath = userDir + "/" + "Data/Testdb.db";
// String dir = System.getProperty("user.dir");
Class.forName("org.sqlite.JDBC");

Connection conn = DriverManager
	.getConnection("jdbc:sqlite:"+dataPath);
U.log("connection success");
return conn;

}
}
