package com.shatam.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class MakeCapitalComunityName {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		File folder=getFolderName();
		//File folder=new File("C:\\BuilderDelivery\\OUTPUT");
		String[] files=folder.list();
		
		for(String file : files){
			//U.log(file.toString());
			if(!file.contains(".csv"))
				continue;
			U.log("File :"+file);
			String output=makeCapital(folder+"\\"+file);
			U.log(output);
		}
		System.exit(0);

		 //String output=makeCapital("C:\\BuilderDelivery\\test.csv");
		// U.log(output);

	}
	
	private static File getFolderName(){
		JFileChooser dlg = new JFileChooser();
		dlg.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int result = dlg.showDialog(new JFrame(), "Open");
		if (result == JFileChooser.APPROVE_OPTION) {
			File file = dlg.getSelectedFile();
			System.out.println("Folder :"+file);
			dlg=null;
			return file;
		}
		return null;
	}

	private static String makeCapital(String csvFile) throws Exception {
		String output = null;
		BufferedReader br = null;
		String line = "", cvsSplitBy = ",", index, commName;
		StringBuilder contents = new StringBuilder();

		File folder = new File("c:\\BuilderDelivery\\OUTPUT\\");
		if (!folder.exists())
			folder.mkdirs();

		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] row = line.split(cvsSplitBy);
				if(row.length>3){
					commName = row[3];
					commName = commName.replace("\"", "");
					String[] words = commName.split(" ");
					String capital = null, wd;
					for (String word : words) {
						wd = word.substring(0, 1).toUpperCase() + word.substring(1);
						capital = (capital == null) ? wd : capital + " " + wd;
					}
					row[3] = "\"" + capital + "\"";
					U.log("comm NAME :" + row[3]);
					for (int i = 0; i < row.length; i++) {
						contents.append(row[i]).append(",");
					}
				}
				else{
					contents.append(line);
				}
				
				//contents.append(System.lineSeparator());
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		int n = csvFile.lastIndexOf("\\") + 1;
		csvFile = csvFile.substring(n);
		String outFile="C:\\BuilderDelivery\\OUTPUT\\" + csvFile;
		File outF=new File(outFile);
		FileUtil.writeAllText(outF.getAbsolutePath(),contents.toString());
		return contents.toString();
	}

}
