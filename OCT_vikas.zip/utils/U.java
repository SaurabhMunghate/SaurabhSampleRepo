package com.shatam.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;
import java.security.NoSuchAlgorithmException;

import org.apache.bcel.generic.GOTO;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;
import com.shatam.scrapper.ShatamChrome;
import com.shatam.scrapper.ShatamFirefox;
public class U {
	
	public final static void stripAll(String [] vals)
	{		
		Arrays.stream(vals).map(String::trim).toArray(unused -> vals);
	}
	
	private static final String HOME = System.getProperty("user.home") + File.separator;
	
	private static final String HARDCODED_FILES_PATH = HOME + "Harcoded Builders" +File.separator;
	/**
	 * @author priti
	 */
	public static final String MY_PHANTOMJS_PATH = System.getProperty("user.home")+File.separator+"phantomjs";
	public static final String MY_CHROME_PATH = System.getProperty("user.home")+File.separator+"chromedriver";
	public static void setUpChromePath() {
        if (SystemUtils.IS_OS_LINUX) {
            System.setProperty("webdriver.chrome.driver", MY_CHROME_PATH);
        }
        if (SystemUtils.IS_OS_WINDOWS) {
            System.setProperty("webdriver.chrome.driver", MY_CHROME_PATH+".exe");
        }
    }
	
	public static final String MY_GECKO_PATH = System.getProperty("user.home")+File.separator+"geckodriver";
	public static void setUpGeckoPath() {
        if (SystemUtils.IS_OS_LINUX) {
            System.setProperty("webdriver.gecko.driver", MY_GECKO_PATH);
        }
        if (SystemUtils.IS_OS_WINDOWS) {
            System.setProperty("webdriver.gecko.driver", MY_GECKO_PATH+".exe");
        }
        clearFirefoxConsoleLogs();
    }
	public static WebDriver headLessDriver = null;
	 //Clear selenium log from console
	public static void clearFirefoxConsoleLogs()
	{
		System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE,"true");
		System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE,System.getProperty("user.home")+File.separator+"Selenium_logs.txt");
		U.log("[::: Clear Firefox Console Logs ::::]");
	}
	public static FirefoxOptions getFirefoxOptions() {
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--headless");
        //Disable geolocation
        options.addArguments("--disable-geolocation");
        //Disable images
        options.addPreference("permissions.default.image", 2);
        //flash player
        options.addPreference("plugin.state.flash",2);
        return options;
    }
	public static FirefoxProfile getFirefoxProfile(){
		FirefoxProfile profile=new FirefoxProfile();
		profile.setPreference("permissions.default.image", 2);
		return profile;
	}
	public static FirefoxBinary getFirefoxBinary(){
		File pathToBinary=new File(System.getProperty("user.home")+File.separator+"firefox/firefox");
		FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
	return ffBinary;
	}
	public static DesiredCapabilities getFirefoxCapabilities() {
        DesiredCapabilities capabilities = DesiredCapabilities.firefox();
       // capabilities.setJavascriptEnabled(true);
        capabilities.setCapability(FirefoxOptions.FIREFOX_OPTIONS, getFirefoxOptions());
       
        return capabilities;
    }
	
	public static String getHtmlHeadlessFirefox(String url,WebDriver driver) throws IOException, InterruptedException {

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}
		// int respCode = CheckUrlForHTML(url);
		Thread.sleep(8000);
				// if(respCode==200)
				{

					if (!f.exists()) {
							BufferedWriter writer = new BufferedWriter(new FileWriter(f));
							driver.get(url);
							((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", "");
							html = driver.getPageSource();
							//U.log("Current Url : "+ driver.getCurrentUrl());
							Thread.sleep(2000);
							writer.append(html);
							writer.close();

						
					} else {
						if (f.exists()) {
							html = FileUtil.readAllText(fileName);
							U.log("Reading done");
						}
					}
					return html;
				}
		
	}// //
	
	/**
	 * @author priti
	 */
	//Format million price
	public static String formatMillionPrices(String html){
		Matcher millionPrice = Pattern.compile("\\$\\d\\.\\d M",Pattern.CASE_INSENSITIVE).matcher(html);
			while(millionPrice.find()){
			//U.log(mat.group());
			String floorMatch = millionPrice.group().replace(" M", "00,000").replace(".", ",");  //$1.3 M
			html	 = html.replace(millionPrice.group(), floorMatch);
			}//end millionPrice
		return html;
	}
	
	public static String getHardCodedPath(){		
		String Regex="Harcoded Builders";	
		String Filename=System.getProperty("user.home");		
		if(Filename.contains("/")){		
			Regex="/Harcoded Builders/";		
			}		
		else{			
			Regex="\\Harcoded Builders\\";	
			}
	Filename=Filename.concat(Regex);	
	if(!Filename.equals(Regex))	{			
		Regex=Regex.toLowerCase();		
		}		
	return Filename;	}

	public static String getNoHtml(String html) 
	{ 
		String noHtml=null; 
		noHtml = html.toString().replaceAll("\\<.*?>"," "); 
		return noHtml; 
	}
	
	public static String getCityFromZip(String zip) throws IOException {
		// http://maps.googleapis.com/maps/api/geocode/json?address=77379&sensor=true
		String html = U.getHTML("http://ziptasticapi.com/" + zip);
		String city = U.getSectionValue(html, "city\":\"", "\"");
		return city.toLowerCase();
	}
	
	public static String [] getGoogleLatLngWithKey(String add[]) throws IOException{
		String addr = add[0] + "," + add[1] + "," + add[2];
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address="
				+ URLEncoder.encode(addr, "UTF-8")+"&key=AIzaSyAeG9lLU8fWh8rWcPivHDwxLAM4ZCInpmk";
		U.log(addr);
		U.log(U.getCache(addr));
		String html = U.getHTML(addr);

		String sec = U.getSectionValue(html, "location", "status");

		String lat = U.getSectionValue(sec, "\"lat\" :", ",");
		if (lat != null)
			lat = lat.trim();
		String lng = U.getSectionValue(sec, "\"lng\" :", "}");
		if (lng != null)
			lng = lng.trim();
		String latlng[] = {"", ""};
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		if(status.trim().equals("OK")){
			latlng[0] = lat;
			latlng[1] = lng;
			return latlng;
		}else
			return latlng;
	}
	
	public static String[] getGoogleAddressWithKey(String latLng[]) throws Exception{
		
		String st = latLng[0].trim() + "," + latLng[1].trim();
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+ st;
//		String key = "AIzaSyDhsO7Ska4s4zUW_68R1n8OhRHJuZP5gm8";
		String key = "AIzaSyAeG9lLU8fWh8rWcPivHDwxLAM4ZCInpmk";

		U.log(U.getCache(addr));
		String html = U.getHTMLForGoogleApiWithKey(addr,key);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		
		if(status.trim().equals("OK")){
			String txt = U.getSectionValue(html, "formatted_address\" : \"", "\"");
			U.log("Address txt Using gmap key :: " + txt);
			if (txt != null)
				txt = txt.trim();
			txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "").replace("50 Biscayne, 50", "50");
			txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
			txt = txt
					.replaceAll(
							"Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,"+
					"|Suite CNewark, ",
							"");
			String[] add = txt.split(",");
			add[3] = Util.match(add[2], "\\d+");
			add[2] = add[2].replaceAll("\\d+", "").trim();
			return add;
		}else{
			return new String[]{"","","",""};
		}
	}
	public static String getHTMLForGoogleApiWithKey(String path,String key) throws Exception {
		path = path.replaceAll(" ", "%20");
		String fileName = U.getCache(path);
		File cacheFile = new File(fileName);
		if (cacheFile.exists()) {
			if (cacheFile.length()> 400) {
				return FileUtil.readAllText(fileName);
			}else if (cacheFile.length()<400) {
				cacheFile.delete();
			}
		}
		URL url = new URL(path+"&key="+key);
		U.log("url ::"+url.toString());
		String html = null;
		//Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("45.77.146.9", 55555));
		final URLConnection urlConnection = url.openConnection(); // proxy
		// Mimic browser
		try {
			urlConnection.addRequestProperty("User-Agent",
					"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			final InputStream inputStream = urlConnection.getInputStream();
			html = IOUtils.toString(inputStream);
			inputStream.close();
			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);
			return html;
		} catch (Exception e) {
			U.log(e);

		}
		return html;
	}
	
	/*public static String[] getAddressGoogleApi(String latlng[])throws Exception {
		String st = latlng[0].trim() + "," + latlng[1].trim();
		String add[] = {"-","-","-","-"};
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+ st;
		U.log(addr);

		U.log(U.getCache(addr));
		String html = U.getPageSource(addr);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		U.log("GMAP Address Status Without Key : "+status);
		if(!status.contains("OVER_QUERY_LIMIT") && !status.contains("REQUEST_DENIED"))
		{
			String txt = U.getSectionValue(html, "formatted_address\" : \"", "\"");
			U.log("txt:: " + txt);
			if (txt != null){ 
				txt = txt.trim();
				txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "");
				txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
				txt = txt.replaceAll("Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,"
								+"|Suite CNewark, ","");
				
				String tempAdd[] = txt.split(",");
				if(tempAdd.length == 4){
					add = tempAdd;
					add[3] = Util.match(add[2], "\\d+");
					add[2] = add[2].replaceAll("\\d+", "").trim();					
				}
				if(tempAdd.length == 3){
					if(tempAdd[2].contains("USA")){
						add[3] = Util.match(tempAdd[1], "\\d+");
						add[2] = tempAdd[1].replaceAll("\\d+", "").trim();
						add[1] = tempAdd[0];
					}
				}
				return add;
			}
			// U.log("zip:::::::"+add[3]);
		}
//		else{
//			return getGoogleAddressWithKey(latlng);
//		}
		
		else if(getGoogleAddressWithKey(latlng)!=null){
			return getGoogleAddressWithKey(latlng);
		}
		else{
		return getAddressHereApi(latlng);
		}
		
		return null;

	}*/
	
	public static String[] getAddressGoogleApi(String latlng[])throws Exception {
		String st = latlng[0].trim() + "," + latlng[1].trim();
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+ st;
		U.log(addr);
		String[] add = {"-","-","-","-"};
		U.log(U.getCache(addr));
		String html = U.getPageSource(addr);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		if(html.contains("Unknown host"))status ="Unknown host";

		U.log("GMAP Address Status Without Key : "+status);
		if(!status.contains("OVER_QUERY_LIMIT") && !status.contains("REQUEST_DENIED") && !status.contains("Unknown host"))
		{
		String txt = U.getSectionValue(html, "formatted_address\" : \"", "\"");
		U.log("txt:: " + txt);
		if(txt.contains("+")) {
			txt=U.getSectionValue(html.replace("\"formatted_address\" : \""+txt+"\",", ""), "formatted_address\" : \"", "\"");
		}
		U.log(html.contains("plus_code"));
		if (txt != null && !html.contains("plus_code")) {
			txt = txt.trim();
			txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "");
			txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
			txt = txt.replaceAll(
							"Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,",
							"");
			add = txt.split(",");
			add[3] = Util.match(add[2], "\\d+");
			add[2] = add[2].replaceAll("\\d+", "").trim();
		}
		else if(html.contains(" \"types\" : [ \"plus_code\" ]") && getGoogleAddressWithKeyUpdated(latlng)!=null) {
			return getGoogleAddressWithKeyUpdated(latlng);
		}
		// U.log("zip:::::::"+add[3]);
		return add;
		}
		else if(getGoogleAddressWithKey(latlng)!=null){
			return getGoogleAddressWithKey(latlng);
		}
		else{
		return getAddressHereApi(latlng);
		}
	}

	public static String[] getAddressGoogleApiProxy(String latlng[])
			throws IOException {
		String st = latlng[0].trim() + "," + latlng[1].trim();
		String proxy = "http://75.119.204.81:3302/gproxy?to=";

		String addr = "https://maps.googleapis.com/maps/api/geocode/json?latlng="
				+ st;
		proxy = proxy + addr;
		U.log(proxy);

		U.log(U.getCache(proxy));
		String html = U.getPageSource(proxy);

		String txt = U.getSectionValue(html, "formatted_address\" : \"", "\"");
		U.log("txt:: " + txt);
		if (txt != null)
			txt = txt.trim();
		txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "");
		txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
		txt = txt
				.replaceAll(
						"Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,",
						"");
		String[] add = txt.split(",");
		add[3] = Util.match(add[2], "\\d+");
		add[2] = add[2].replaceAll("\\d+", "").trim();
		
		// U.log(lat);
		return add;
	}

	public static String[] getlatlongGoogleApi(String add[]) throws IOException {
		String addr = add[0] + "," + add[1] + "," + add[2];
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address="
				+ URLEncoder.encode(addr, "UTF-8");
		U.log(addr);
		U.log(U.getCache(addr));
		String html = U.getHTML(addr);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		U.log("GMAP Address Status Without Key : "+status);
		if(!status.contains("OVER_QUERY_LIMIT") && !status.contains("REQUEST_DENIED"))
		{
			String sec = U.getSectionValue(html, "location", "status");
			if(sec != null){
				String lat = U.getSectionValue(sec, "\"lat\" :", ",");
				if (lat != null){
					lat = lat.trim();
					String lng = U.getSectionValue(sec, "\"lng\" :", "}");
					if (lng != null)
						lng = lng.trim();
					String latlng[] = { lat, lng };
					// U.log(lat);
					return latlng;
				}
			}
		}
		else{
			return getGoogleLatLngWithKey(add);
//			return getlatlongHereApi(add);
		}

		return null;
 
	}

	public static String[] getlatlongGoogleApiProxy(String add[])
			throws IOException {
		String proxy = "http://75.119.204.81:3301/gproxy?to=";
		String addr = add[0] + "," + add[1] + "," + add[2];
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address="// 1138
																			// Waterlyn
																			// Drive","Clayton","NC
				+ URLEncoder.encode(addr, "UTF-8");
		proxy = proxy + addr;
		U.log(proxy);
		U.log(U.getCache(proxy));
		String html = U.getHTML(proxy);
		String sec = U.getSectionValue(html, "location", "status");
		String lat = U.getSectionValue(sec, "\"lat\" :", ",");
		if (lat != null)
			lat = lat.trim();
		String lng = U.getSectionValue(sec, "\"lng\" :", "}");
		if (lng != null)
			lng = lng.trim();
		String latlng[] = { lat, lng };
		// U.log(lat);
		return latlng;
	}

	

	private static ShatamFirefox driver;
	private static HashMap<String, String> communityType = new HashMap<String, String>() {
		{
			put("lakeside views|lakefront amenity center|The Lakeside Estates|lakeside living| lake home community|Lake community|(l|L)akeside (c|C)ommunity", "Lakeside Community");
			put("lakefront living|with lake front lots open|Lakefront and wooded|Lakefront Lots|Lakefront Amenities|lake front living|lakefront property|lakefront community|Lakefront viewing|Lakefront Homesites Available", "Lakefront Community");
			put("Green Community", "Green Community");
			put("Swim Club Community|Swim community|community to swim", "Swim Community");
			
			put("Water View Home|waterfront communities|charming waterfront|waterfront lots|water-front homesites available|Premium water-front homesites|waterfront amenity|waterfront views|water front home sites|waterfront community|Waterfront community Apartments|Waterfront Homesites|area's newest waterfront community|THE WATERFRONT","Waterfront Community");

			put("Active Adult Living|active adult|active-adult |active adult|active adult|Active Adult</li>", "Active Adult");
			put("fishing, golfing|Golf Course|golf, |golf and|golf, and|<span>Golf</span>|golf memberships|golfing|golfing area|<li>Golf</li>|private golf holes|Top Golf</span>|Golf\\s+</li>| Golf Club|Golf Club</a>|Golf &amp; Country Club|Golf & Country Club| Golf Club,|Golf Club |golf course|golf courses|golf resort community|golf communities|gated golf & tennis community|Golf Course|golf courses|Golf and Country Club|Golf Community|golf &amp; country clubs|golf at six|Golf Center| TopGolf|Enjoy golf",
					"Golf Course");
			put("riverfront land|river front community|Riverfront Lots Available", "Riverfront Community");
	
			put("62\\+ community|62\\+ apartment community|62\\+ apartment communit|62 years of age and older|Active Adult (62\\+)", "62+ Community");
			
			put("55-plus community|AGE QUALIFIED  55 YEARS+|AGE QUALIFIED 55 YEARS+|active adults 55+|active adults aged 55+|ages 55+|55 + Active Adult Community|community for residents age 55 and up|55\\+Elevator Townhomes|  55+ Community | A 55 plus community|seniors 55 and over|Best 55\\+ Lifestyle| Amazing 55\\+ Lifestyle|55\\+ Age-Qualified|55\\+ Epcon Community|residents ages 55\\+|55\\+ Luxury Retirement |55\\+ Living|55\\+ lifestyle community|active adult 55\\+|55\\+ Retirement Living|55\\+ single-family|55-and-better couples|55+ living|ages 55 and up|community for those 55\\+|55 and older|active adults 55\\+|55\\+ age-restricted|55\\+ resort-class community|55\\+ gated community|\\+55 age group|Best 55\\+ Communities|55-and-better living|Active Adults aged 55 or better|55 years or better in residence|55 plus residents |55-years of age and better|55-Plus communities|55 and over gated|55 and over community|active 55-and-better lifestyle| 55-and-better community|55 and Bette|55\\+ Residents|55 and older community|55+ neighborhood|55+ community|Community 55\\+|55\\+ Active Adult|\\(55\\+\\) community|active adult \\(55\\+\\)|55\\+ age-qualified community|\\(55\\+\\) gated community|55\\+ neighborhood|55\\+ residents| 55\\+ Community|55\\+ Active|community \\(55 years \\+\\) |active adults age 55| 55\\+ buyer|55\\+ Lifestyle|Best 55\\+ Life| 55\\+ gated|<p>55\\+ Community| 55-plus community"
					+ "|55\\+ Bay Area|the 55\\+ Live Better ",
					"55+ Community");
			
			put("master-planned amenities|masterfully planned| best master-plans of |masterplanned community|Master-plan living|planned master community|Master Planned|masterfully-planned community|masterfully planned community| masterplan|Master-Planned|master-planned|master planned|master- planned|Master Plan|Master Plan|master-planned|Master Planned Community|masterplanned community|masterplans|Mastered-Planned|name\":\"MasterPlanned\"",
					"Master Planned");
			
			put("Resort-Style Amenities|resort-style amenities|resort-like community|resort-style pool|Resort-style Pool with Cabanas|resort-class lake living|resort-like activities|resort-style living|resort-style pool|Resort Lifestyle|resort inspired community|resort like style amenities|resort-type lifestyle|resort-like amenities| luxury resort|golf courses and resort |Golf and Resort|resort class amenities|Resort-style community|Golf Resort| The Resort Series|resort-inspired lifestyle|resort-like lifestyle|resort style amenities|resort-style amenities|resort pleasures|Resort Homes|Resort Pool|Resort golf course|resort community|Resort-style|Resort-Style|Resort and Golf Course|resort living|resort-style|posh resort|Resort style|resort features|Resort-style|resort style living| resort pool|resort-style|resort inspired amenity|Resort-style|Resort-style|resort amenities|resort-style amenities|Resort-Style Living|Resort and Spa|resortstyle recreation|resort-like environment|resort-inspired",
					"Resort Style");
			put(" gated|gated-community|Access Gate|Gated, Pool|Gated luxury|Private gated community|Controlled Access/Gated|Gated\\s*</p>|<br>Gated<br>|<li>Gated</li>|Gate House|gated community|gated single family|gated |Gated |Gated Community</li>|\"gated\":1,",
					"Gated Community");
			put("Country Club-Style|Country Club Community|Country Club|country-club",
					"Country Club");
			put("62+ in North Orlando|62 years of age and older|62\\+ Senior Apartment Community|aged 62 and older|age 62 and older| 62 years of age or older","62+ Community");
			
			put("63\\+ Senior Apartment Community","63+ Community");
		}
	};
	
	private static final String propStatusIgnore = "Model(s)? opening soon|Model home now selling|Final homes for sale|Model Home Now Open|Model Home now available|Model Homes Now Available|Models coming this summer|Pricing Now Available|Appointments now available|Final Balance Home Now Available|floorplan[s]* is now available|Floorplans–Now Available|Amenity Site Coming Soon|[P|p]ricing\\s*[is]*\\s*[N|n]ow [A|a]vailable|Community Garden Coming Soon|Clubhouse coming soon|Coming Soon: On-site Community|Price Coming Soon|Now Open - Two new model|Pickleball Courts coming soon|Amenity expansion coming soon|Coming Soon - Amenity|Coming Soon - Clubhouse|New Flats Coming Soon|design[s]* now available|Model[s]* coming Summer 2018|plan[s]*[ are ]*now available|floor plans now available|Model Home is Now Available|Site Plan Now Available|model home coming soon|Sales Center Opening Spring 201[8|9]|Model Homes Open Summer 2018|Model Home, now OPEN|now open for sales|Model Coming Winter 2017|tot lot coming soon|New Model\\s*Coming Soon|pre-selling out |Model home is now selling|model opening September 2017|model home now available|now open for sale|model is now available|model home is COMING SOON|model home is coming soon|New Floor Plans Just Released|now open for leasing|Now Open For Presales|Models Now Selling|New floorplan now available|Grand Opening Pricing|ONE HOME REMAINING \\(MODEL\\)|model residences now selling|New floor plans were just released|NOW OPEN - NEW MODEL|Floor Plan Coming Soon|#\">Coming Soon</a></li>|Model Home now available for purchase|Pre-Grand Opening|Preselling Now|Preselling Now|New Model - Now Selling|NEW MODELS COMING EARLY 2017|Pre-Selling Now|Model Home coming |MODELS NOW OPEN|More Info Coming Soon|Model[s]* Now Available|Models now available!|New Model Complex Now Open|Final Phase Now Preselling|join us for our Grand Opening|Center - now open|MODEL NOW OPEN|Grand Opening Prices|Model NOW Open|Model Coming Soon|Plan sold out|model homes are now open|Model Homes Now Selling|Model Coming Late 2015|Model Opening Soon|New Mode\\s*Coming Soon|school currently under construction|Grand Opening Icon|Model Home Opening Soon|Now Open Image|<!-- Quick Move-Ins -->|MODEL NOW OPEN|AREA INFORMATION COMING SOON|Price is coming soon|Sales Center Now Open|Model Home COMING SOON|Model Home Coming Soon|walking trails coming soon|Close-Out Special|Coming Soon</a> |Park Coming Soon|Models coming soon|Home Coming Soon|Model Coming Soon|Office Now Open|Home Under Construction|Model Homes Now Open|Homes Opening Soon|homes are under construction|are currently under construction|pool coming soon|home is now open|model is now open|Model Grand Opening|Home Grand Opening|Model now under construction|Clubhouse Now Open|homes under construction|Clubhouse NOW OPEN|MODEL HOME NOW OPEN|Price Is Coming Soon|Area Now Open|Lot - Now Open|Amenities coming|Park is Now Open";
	private static ArrayList<String> propStatus = new ArrayList<String>() {
		{
			
			add("New Apartments Coming \\d+");
			add(" only 1 market home remains");
//			add("\\d Wooded Homesites Remain|wooded homesites available|2 Wooded Homesites Remaining|Greenbelt Homesites Available");
//			add("Leasing Fall \\d+");
			add("3 Units Remaining");
			add("Phase 3 Coming this Summer|Coming this summer");
			add("71 home sites released in Phase 1");
			add("Opening in Fall \\d+");
			add("Opening mid 2022");
			add("New section lake front lots open now");
			add("Townhomes coming Summer 2022|Next Phase Coming Summer 2022|Future Release Coming Summer 2022|New Section Coming Summer 2022|New Lots Coming Summer \\d+|New Phase Coming Summer \\d+|Phase 2 Coming Summer \\d+|Phase Two Coming Summer \\d+|Phase 3 Coming Summer 2022|Townhomes coming Summer 2022|New townhomes coming summer 2022|Coming Summer \\d+|Phase 3 Coming Summer|Phase \\d coming Summer \\d+|Coming Summer \\d+");//Summer 2022
			add("Over 30 floor plans available");
			add("New Homesites Releasing Soon");
			add("Coming September \\d+");
			add("Only 2 basement homes remain");
			add("Water View and Oversized Lots Available");
			add("More than 60% sold");
			add("Cul-de-sac, wooded, and walkout homesites available");
			add("\\d Walkout Homesites Available");
			add("Arriving Spring \\d+");
			add("Last Remaining Home");
			add("3 Walk-out Basement Homes Remain");
			add("10 Homesites Available");
			add("Water View Homesites Available");
//			add("CUL-DE-SAC HOMESITES AVAILABLE|1 Cul-De-Sac Homesite Available|1 Wooded Cul-de-Sac Homesite Available");
			add("New Homes Coming Late 2022");
			add("Coming 2nd Quarter 2022");
			add("NEW SECTION COMING JUNE 2022");
			add("Homesite Release Coming Soon");
			add("Grand Open Fall 2022");
			add("Basement Homes Available");
			add("More Homesites Coming Winter 2022|New Phase Coming Winter 2022|Coming Winter 2022-2023|New Sites Coming Winter \\d+|Coming Winter 2021-2022|Coming Winter 2022|Coming Winter 2023");
			add("ONLY 2 LOTS REMAINING");
			add("Final 6 Opportunities");
			add("Only Four Opportunities Remaining");
			add("New Floor Plans Available");
			add("Arriving Late \\d+");
			add("Spring Move-Ins Available|Summer Move-Ins Available");
			add("Only 1 Ranch Home Remains");
			add("Last home available in Phase 3|Last Home Available");
			add("only inventory homes remain");
			add("Thirty Three Home Sites Now Available");
			add("Final Section of Homesites Now Released");
			add("Only 1 Opportunity\\s*Home Remains");
			add("Only 1 new home opportunity remains");
			add("Limited Homes Left");
			add("Opening March 31st");
			add("//d+ New homesites released in FINAL section");
			add("Final home sites released");
			add("Final Inventory Opportunities");
			add("Final Two Homes Available");
			add("next phase coming Late Fall 2022|Coming Late Fall \\d+");
			add("NEW SECTION AVAILABLE");
			add("Final Homesites Available");
			add("80 homesites available");
			add("Only 9 New Homes Remain");
			add("Homesites With Lake Views Available");
			add("homesites coming in 2022|Phase 2 coming in 2022|COMING In 2022");
			add("PREMIUM HOMESITES AVAILABLE");
			add("Coming late autumn \\d+");
			add("MORE OPPORTUNITIES AVAILABLE");
			add("Coming in BEGINNING OF 2022");
			add("Only Two Home Sites Remain");
			add("Limited-Time Offer");
			add("More homesites coming March 2022");
			add("New Home Site Released");
			add("Only 3 Grand Finale Home Sites Remain");
			add("8 Lots Remaining");
			add("ONLY 2 LAKE HOMES REMAINING");
			add("RE-OPENING SPRING 2022|Opening Spring \\d{4}");
			add("final homesites coming soon");
			add("New Addition Just Released");
			add("only basement lots remain");
			add("1 LOT REMAINS");
			add("Final Few Homes Left");
			add("Two homesites available");
			add("LIMITED BASEMENT HOMESITES|Limited Basement Homesites Remain");
			add("Wooded & Walkout Lots Remaining|\\d{1,2} Lots Remaining|ONLY \\d LOTS REMAINING?");
			add("Only \\d+ home sites left|Only \\d+ Home Sites Left");
			add("Coming Spring/Summer 2022");
			add("[Only]*\\s*3 Lots Remaining");
			add("two large homesites available|Only 18 large homesites available|Large Homesites Available");
			add("last phase released");
			add("Only 40 total opportunities available");
			add("Only 73 Sites Available");
			add("Grand Open May \\d{4}");
			add("NOW CLOSING");
			add("Available Inventory Home[s]* Only");
			add("Only a Few Basement Homesites Left in Phase 2");
			add("2 Pond-View Homesites Remaining in Current Phase");
			add("ONLY 1 LUXURY PATIO HOME REMAINS");
			add("Only one Available Home Remains");
			add("ONLY FOUR LOTS REMAINING");
			add("Phase 4 Coming Soon");
			add("PHASE I 70% Sold");
			//add("BASEMENT HOMESITES AVAILABLE");
			add("ONLY 1 INVENTORY HOME REMAINING");
			add("LAST PHASE SELLING");
			add("\\d+ New Plans Available");
			add("Last Remaining Opportunity");
			add("Phase 3 coming this spring|Coming this spring");
			add("Last Lots Released");
			add("5 final remaining opportunities");
			add("FINAL NEW HOME OPPORTUNITIES");
			add("Two homes ready now");
			add("home sites currently available");
			add("USDA ZERO DOWN FINANCING AVAILABLE");
			add("70 home-sites available");
			add("Just 1 Lot Left");
			add("only a few residences remaining");
			add("JUST 3 homes left");
			add("150 LOTS REMAINING");
			add("Phase II close to selling out");

			add("only 30 home sites");
			add("New Phase Coming Fall/Winter 2022|Fall/Winter \\d+");
			add("Only 1 Residence Available");
			
			add("ONLY 3 CHANCES LEFT");
			add("Only 7 units left");
			add("Lots are going fast");
			add("Designer Showcase Homes available");
			add("Phase II is open");
			add("Final 3 Homes");
			add("ONLY FEW REMAINING");
			add("4 Opportunities Available");
			add("Final Homes Remain");
			add("Coming end of \\d+");
			add("New Phase Now Available");
			add("last section for sale now");
			
			add("FINAL 50's Section");
			add("Lakefront and wooded homes sites available");
			add("Opening February 2022|Opening April 2022");
			add("Final Lots Released");
			add("Only 1�opportunity remains|Only one more opportunity");
			add("Walkout basements available|Finished basements available");
			add("New Homesites Coming 2023");
			add("1 Townhome Homesite Remains|Just one townhome remains");
			add("Three homes remaining in current phase|Three Homes Remaining");
			add("New Home Sites Coming Fall 2022|More Homesites Coming Fall 2022|Townhomes Coming Fall \\d+|coming late summer/Early fall|New homes coming late summer|Coming Fall 2022|NEW PHASE COMING LATE 2022|NEW PHASE COMING FALL 2022|New Section Coming Late 2022|COMING LATE SUMMER 2022|Coming late Summer|Coming Fall \\d{4}");
			add("new homesites coming 2022|Coming Soon Summer 2022|FINAL TWO OPPORTUNITIES COMING SOON|Phase 2 Coming Soon|water view homesites coming soon|Phase II Homes Coming Soon|Next Phase Coming Mid 2022|New Phase Coming Soon|Phase 9 Coming Soon|Coming Soon 2nd Quarter 2022|New Building Coming Soon|Next section coming soon|Coming Soon Fall 2022|New Phase coming soon early Fall 2022|Coming Soon Early 2023|NEW PHASE OPENING IN LATE MAY|New phase of homesites coming soon|NEW SECTION COMING SOON LATE SUMMER 2022|New Phase Coming in Summer 2022|More Lots Coming Soon|New phase homesites coming soon|More Homes Coming Soon|New plans coming soon|Coming Soon Spring \\d{4}|Coming \\d{4}/\\d{4}|New homes coming soon \\d{4}|New Section Coming Fall 2022|New phase just released|New Phase Just Released|New Phase Released|New Phase Release|New phase coming soon|New Phase Coming soon|NEW PHASE COMING SOON|FINAL HOME SELLING NOW|Final Homes Selling Soon|FINAL HOMES SELLING NOW|phase 5 homes selling now|New Phase Open Now|New Phase Now Open|New Phase Available Mid Winter|New Phase Home Sites Now Available|NEW PHASE NOW OPEN|New Phase of Homesites Available|NEW PHASE \\\\d+ NOW OPEN|New phase now available|New Phase Available|NEW PHASE NOW OPEN|NEW PHASE SELLING NOW|New Phase Homesites Available Now|New Phase Home Sites Available|New homesites coming soon in Phase Two|Next Phase Coming 2023|Coming Soon 2022|New Phase Coming March 2022|Phase II Coming 2022|Phase Two Coming Fall \\d+|New Opportunities Coming Fall \\d+|Coming in the fall of \\d+|Second Phase Coming Fall \\d+|Final Phase Coming Fall \\d+|Coming Fall of \\d+|Coming May \\d+|COMING MARCH \\d+|Coming April \\d+|new phase coming in \\d+|New Phase Coming in \\d+|New Phase Coming \\d+|Basement lots coming soon|New Homesites Coming Soon|basement homesites coming soon|Section 5 Coming 2022|PHASE TWO Coming Soon|New Lots Coming 2022|coming soon|Coming Soon|COMING SOON|Final homesite coming soon|New phase homesites coming soon|New Phases Coming 2022|Coming \\d{4}|NEW SECTION COMING SOON|New Section Coming Soon|NEW HOMESITES COMING SOON|New Section Homesites Coming Soon|Coming in late \\d+|Section \\d+ Coming Soon|Phase 2 coming in late \\d+|New Floor Plans Coming Soon|Next Phase Coming Soon|New Town Homes Coming Soon|Coming soon Spring \\d+|coming soon Winter 2019|Phase V Coming Soon|Phase II Coming Soon|NEXT PHASE COMING SOON|Phase III Coming Soon|Final Home Coming Soon|Final Release Coming Soon|New oversized home sites coming soon|New Homes Coming Soon|Phase 7 COMING SOON|Phase 2 and 3 coming soon|Final section coming soon|More Home Sites Coming Soon|Coming Soon 2017|New Designer Phase Coming Soon|COMING SOON JUNE 2017|Coming Soon- FALL 2017|MORE OPPORTUNITIES COMING SOON|NEW RELEASE COMING SOON|COMING SOON JUNE 2017|New plans & new homesites coming soon|Homesites Coming Soon|Additional phase coming soon|new homes coming soon|Coming Soon Summer 2017|Coming Soon in 2018|Coming Soon Fall 2018|New Townhomes Coming Soon|Second Phase Coming Soon|Final [P|p]hase Coming Soon|New Homes Coming Soon|PHASE 2 COMING SOON|NEW LOTS COMING SOON|New home sites coming soon|new phases coming soon|Phase 3 Coming Soon|Phase 4 Coming Soon|Phase 6 Coming Soon|Homesites Coming Soon|Coming Soon in May|Coming 2018|coming soon|Coming Soon|COMING SOON|New Section[s]* Coming Soon");
//			 add("New Phase Coming soon|coming soon|Coming Soon|COMING SOON|New Section[s]* Coming Soon");
			add("Opening in Late \\d{4}");
			add("New Homes Coming Early 2023|New Section Coming Early \\d{4}|New Lots Coming Early \\d{4}|COMING EARLY \\d+|New Homes Coming Early 2022|New phase coming early \\d+|PHASE 2 COMING EARLY 2018|New Homes Coming Early 201[8|9]|Coming Early 201[8|9]|Phase 2 coming early \\d+|New homesites coming early 2022");
			add("Only 5 homesites Remaning");
			add("Fall 2022 Limited Availability|Limited availability remains current phases|Limited availability remains in phase \\d{1}|Limited availability in Final Phase|Limited availability remains|limited availability remaining|Limited availability remain[s]*|Limited availability remains|Limited availability remains|LIMITED AVAILABILITY|FINAL HOME REMAINING|FINAL HOME REMAINS");
			add("New Home Sites Just Released");
			add("New Homes Just Released");
			add("Only 13 Remains in Current Phase");
			add("Limited Home Opportunities");
			add("LAST HOMES AVAILABLE");
//			add("Coming Late 2022");
//			 add("COMING LATE SUMMER 2022|Coming late Summer|Coming late 2022");
			add("only \\d+ lots left");
			add("ONE home is currently available");
			add("Only \\d+ New Home Lots Left");
			add("Only 2 Remaining Opportunities|Only 2 remaining");
//			add("Final Phase Releasing Early \\d+|Phase \\d Release|Final Phase Released|Final Phase Release|Final Phase Releasing Soon");
			add("Limited Homesites Available In Current Phase|Limited homesites left|Limited Homesite Release|Limited Homesites Available|Oversized Homesites Available|Limited Homesites Remaining|Limited homesites remain|LIMITED HOMESITE|Limited home sites remain|limited homesites remaining|Limitied homesites remain|Home sites limited|Limited Homes Remain|Limited Homes Remain");
			add("NEW SECTION COMING SPRING 2022|New Townhomes Coming Spring 2022|Townhomes Coming Spring 2022|Phase 11 coming Spring 2022|New Homesites Coming Spring \\d+|New Home Sites Coming Spring \\d+|New Phase Coming Spring \\d+|PHASE 2 COMING SPRING 2018|NEW HOMES COMING SPRING 2018|Phase II Coming Spring 2018|Coming Spring 2023|Coming Spring 2023");
			add("only two lots left|TWO LOTS LEFT");
			add("NOW OPEN Phase 2");
			add("Phase III lots available|pond & wooded lots & cul-de-sac lots available|wooded & cul-de-sac lots available|pond view lots and cul-de-sac lots available|cul-de-sac lots available|Riverfront Lots Available|NEW LOTS AVAILABLE NOW|Last Lots Available|Cul-de-sac and oversized lots available|Final Lots Available|Lakeview Lots Available|Pond view and cul de sac lots available|pond and wooded and cul de sac lots available|Waterfront and waterview lots available|Lots available soon|Water View Lots Available|premium lots available|few walkout lots available|Final Lots Available in Phase II|Wooded Lots Available|1 last lake view lot left|Basement Lots Available|Lake front lots available|Wooded & Pond Lots Available|Just 1 Beautiful Lake Lot Available|Only 8 lots available|LIMITED LOTS AVAILABLE|Large Lots Available|New Lake View Lots Available|Water Lots Available|Oversized Lots Available|Walkout basment lots available|New Basement Lots Available|Waterfront Lots Available|New Lake Front Lots Available|New Lake Lots Available|Limited Lake Lots Available|New Greenbelt Lots Available|Over-Sized Lots Available|Limited homes and lots available|New Lots Available|14 available lots|Only one lot available|\\d LOTS AVAILABLE|Lake Lots Available|Lakefront Lots Available|Lots Available Now|Lots Available|only \\d+ lots available|\\d{2} Lots Available now|\\d{2} Lots Available|lots available");
            add("One Cul de Sac Homesite Available");
//			add("daylight and walk out homesites available ");
//			add("Phase II Coming 2022");
//			add("New homesites now available|New Homesites Now Available|Now Selling New Homes|Phase \\d+ now available|New Section Now Selling|Homes Now Available Phase 2C|New Phase Now Selling|Now Selling Final Section|New Phase Now Open|PHASES 12 & 13 NOW OPEN|PHASE 9 NOW OPEN|New Phase Available Mid Winter|New Phase Home Sites Now Available|Homes Now Available|New Home Sites Now Selling|New Oversized Wooded Home Sites Now Selling|Lakefront and lakeview homesites are now available|Now selling in the Final Phase|Phase II Now Selling|Phase 7B NOW OPEN|Phase 4 Homes Now Available|Home Now Available|NEW PHASE NOW OPEN|NEW PHASE OPEN|New Phase of Homesites Available|Phase 2 Homesites Now Available|homesites now available|homesites now available|Phase 5 now open|Final Lots Now selling Phase I|Now Selling Phase 3|Now Selling New Phase| Selling New Phase|Final Homesites Now Selling|PHASE 3 NOW AVAILABLE|New Section Of Home Sites Now Open|New Phase Coming Fall 2021|Coming Fall 2021|New Phase Open Now|Phase II NOW OPEN|new unit now open|lakeside and bayfront homesites available|Water Front Lots Now Available|Wooded lots NOW AVAILABLE|Bay Front Lots Now Available|Large Lots Now Available|lots now available|New lots now available|New Townhomes Now Open|Now Selling Phase Three|Phase \\d now selling|Final \\d homes now available|Retreat Home Sites Now Available|Now Selling New Floorplans|waterfront lots now open|Section \\d Now Available|FINAL \\d HOMES SELLING NOW|Section 3 Now Open|Phase Two Now Selling|NEW BUILDING NOW AVAILABLE|Newest phase now open|Now Selling New Townhome|New home sites are now available|Now selling newly released home sites|Half-Acre Homes Now Available|now available Phase I|MORE OPPORTUNITIES NOW AVAILABLE|Immediate Occupancy Now Available|FINAL HOME NOW SELLING|final homes now available|Newest phase now open|Now Selling Phase 3 Homesites|NOW SELLING PHASE 5|NEW PHASE \\d+ NOW OPEN|now open and selling|New Floorplans Now Selling|Phase 2 New Home Sites & Plans Now Available|New Townhomes Now Selling|WATERFRONT LOTS NOW SELLING|final homesite now selling|Final Section Now Available|New Homesites Now Selling|FINAL HOMES SELLING NOW|Now Open & Selling|wooded homesites now available|PHASE 3 NOW SELLING|Phase III Now Available|Now selling final homesites|waterfront homes now available|Water view home sites now available|FINAL Phase Now Available|Phase 2 Home Sites Now Available|Phase 1 Now Selling|Now selling Section Two|LAST SECTION OF HOMESITES NOW AVAILABLE|Large Homesites Now Available|PREMIUM HOMESITES NOW SELLING|Final Release now available|Premium Homesites Now Available|Now Selling Phase 6|final section now open| now selling phase 4|FINAL HOMES NOW SELLING|Final Two Homes Now Selling|Phase 2 OPEN NOW|now selling newest phase|\\d+ Basement homesites available now|Finished Basement Homesites Available|\\d Finished Basement Homesites Available|Basement homesites available|Basement homesites now available|NOW SELLING PHASE 4|PHASE 3 NOW OPEN|FINAL HOME SELLING NOW|New Townhomes Now Available|LOTS NOW SELLING|TWO NEW PHASES NOW SELLING|Now Selling Section 4|homes now available |Only 2 Finale Home Sites Remain|Only Six Home Sites Remain|Now Selling Final Inventory Home|Phase 4 Now Selling|New phase now available|newest phase now available|Final Ready Homes now available|Phase IV and V now Open |PHASE II NOW OPEN|first phase now available|Now Selling FINAL \\d+ Home| Selling New Phase|Phase V now selling|New Homes Now Selling|Phase III Now Selling|Now selling new homesites|New Phase Available|Now selling third and final phase|Now Selling Phase II|NOW SELLING PHASE 1 & 2|NOW SELLING PHASE 1|New Phase Now Open|Second Phase Now Selling|Phase II now available|Phase V Now Available|Phase IV Now Available|Phase IV now open|New Homes Now Selling|Phase IV now Open|Now selling Section Two|Now Selling Sections 2 &amp; 3|Now Selling Sections 2 & 3|Now Selling New Section|Final Section Now Open|New Plans now available|New Homes now available|New Phase Now Selling|New Section Now Available|\\d*\\s*home sites now available|homesites are now available|First Section Now Selling|new section now openNew Home Sites Now Available|New Selling New Section|Phase Two - NOW SELLING|Phase 3 Now Selling|Phase 2 Now Selling|Now Selling Phase 2|New Homesites Now Open|section 2 now open|Phase III Now Open|Phase III Lots Now Open|NOW SELLING PHASE TWO|PHASE II NOW SELLING|Final Phase Now Selling|NOW SELLING FINAL PHASE|Now selling final phase|homesites now selling|Now Selling Phase IV|Now selling phases 4 and 5|Final Section Now Selling|Now Selling New Section|Final Phase Now Available|Final Home Sites Now Available|FINAL PHASE NOW OPEN|LAST HOME NOW AVAILABLE|New Homestes Now Available|Quick Move In Now Available|NEW HOME SITES ARE NOW AVAILABLE|Final Homesites Now Available|New Homesites Now Open|Phase 2 now open|Phase 2 Now Open|Only a few lots remain|Only a Few Lots Remaining|Just a Few Remain|3 Homesites Released in Final Phase|NEW PHASE NOW OPEN|NEW SECTIONS NOW OPEN|New Section Now Open|Phase 6 is now open|Phase three now open|Phase Four NOW OPEN|NOW OPEN|Now Open|Phase 4 now open|Last Section Now Open|Second Phase Now Open|NOW OPEN|Final Homes Now Selling|Final Phase Available|Opening New Phase|Phase Two Now Selling|PHASE 3 HOMES NOW SELLING|Now Selling out|Now Selling|NOW SELLING|NEW PHASE SELLING NOW|SELLING NOW|Final Homes Released"); //|Final Phase
			
			add("1 Walkout Basement Homesite Remaining|1 basement homesite remaining|1 Pond View Homesite Available");
			add("New homesites available in early 2022|Available early 2022");
			add("BASEMENT SITES AVAILABLE|New Homesites Releasing January 2022|New homesites available Fall \\d+|New Homesites Just Released|Phase 3 just released|New Home Site Just Released|1 Wooded Homesite Just Released|Phase two homesites just released|3 New Wooded Homesites Released|Final homesite just released|\\d+ New homesites released in FINAL section|Final homesites selling fast|New Wooded Home Sites Just Released|Final homesites just released|Last Phase Just Released|Final Home Sites Just Released|Wooded and walkout basement sites just released|FINAL PHASE OF PRESERVE HOMESITES JUST RELEASED|New Basement Homesites Just Released|View Homesites Just Released|FINAL PHASE JUST RELEASED|just released final phase|Final Section Just Released|New home sites released|Final home site just released|New Phase and Plan Just Released|New Section Just Released|PHASE II Homes Just Released|Phase 2 just released|New Homesite Release|New Homesites Released|Newly Released Home Sites|NEW LOTS JUST RELEASED");//|New phase just released|New Phase Just Released|New Phase Released|New Phase Release
			add("18 total homesites available");
			add("Final Few Opportunities");
			add("Phase II Final Lots now Selling|Final phase lots now available|Phases 2 and 3 selling now|New section home sites now available|Homes now available in Phase 2|Phase 2 and 3 Homes Now Available|Water View Home Sites Available|NEW SECTION NOW SELLING|Now Selling Future Phases|New Wooded Home Sites Now Available|Waterfront Lots Now Available|new phase homesites now available|Phase 2 now selling|Homes Selling Now|SECTION 2 NOW SELLING|New phase now selling|Now Selling in Phase III|NEW and FINAL PHASE NOW AVAILABLE|New Phase Now Selling|NEW PHASE NOW SELLING|Now Open And Selling|FINAL HOMES NOW SELLING|Last home now selling|New Phase Now Selling|Last Phase Now Open|Phase 2 Now Selling|Now Selling in Section 5|Wooded Cul-de-sac Home Sites Available|Section 6 Now Selling|NOW SELLING THE LAST PHASE|Only 4 Homesites Remain|newest phase now selling|Premium water-front homesites available|Limited wooded-view home sites available|Phase \\d{1} now selling|Final Phase Coming Soon|Final Phase Coming Summer \\d{4}|Brand New Plans Now Selling|Phase 8 Now Opened|Final Phase Releasing Early \\d+|Phase \\d Release|Final Phase Released|Final Phase Release|Final Phase Releasing Soon|Section 4 Now Selling|Phase II Now Selling|Phase 3 Home Sites Now Available|50 homesites now available|Now Selling New Homesites|Phase 2 Homes Now Available|Now Selling in New Section|New homesites now available|New Homesites Now Available|Now Selling New Homes|Phase \\d+ now available|New Section Now Selling|Homes Now Available Phase 2C|Now Selling Final Section|PHASES 12 & 13 NOW OPEN|PHASE 9 NOW OPEN|Homes Now Available|New Home Sites Now Selling|New Oversized Wooded Home Sites Now Selling|Lakefront and lakeview homesites are now available|Now selling in the Final Phase|Phase 7B NOW OPEN|Phase 4 Homes Now Available|Home Now Available|Phase 2 Homesites Now Available|homesites now available|Homesites now available|Phase 5 now open|Final Lots Now selling Phase I|Now Selling Phase 3|Now Selling New Phase| Selling New Phase|Final Homesites Now Selling|PHASE 3 NOW AVAILABLE|New Section Of Home Sites Now Open|Phase II NOW OPEN|new unit now open|lakeside and bayfront homesites available|Water Front Lots Now Available|Wooded lots NOW AVAILABLE|Bay Front Lots Now Available|Large Lots Now Available|lots now available|New lots now available|New Townhomes Now Open|Now Selling Phase Three|Phase \\\\d now selling|Final \\\\d homes now available|Retreat Home Sites Now Available|Now Selling New Floorplans|waterfront lots now open|Section \\\\d Now Available|FINAL \\\\d HOMES SELLING NOW|Section 3 Now Open|Phase Two Now Selling|NEW BUILDING NOW AVAILABLE|Newest phase now open|Now Selling New Townhome|New home sites are now available|Now selling newly released home sites|Half-Acre Homes Now Available|now available Phase I|MORE OPPORTUNITIES NOW AVAILABLE|Immediate Occupancy Now Available|FINAL HOME NOW SELLING|final homes now available|Newest phase now open|Now Selling Phase 3 Homesites|NOW SELLING PHASE 5|now open and selling|New Floorplans Now Selling|Phase 2 New Home Sites & Plans Now Available|New Townhomes Now Selling|WATERFRONT LOTS NOW SELLING|final homesite now selling|Final Section Now Available|New Homesites Now Selling|wooded homesites now available|PHASE 3 NOW SELLING|Phase III Now Available|Now selling final homesites|waterfront homes now available|Water view home sites now available|FINAL Phase Now Available|Phase 2 Home Sites Now Available|Phase 1 Now Selling|Now selling Section Two|LAST SECTION OF HOMESITES NOW AVAILABLE|Large Homesites Now Available|PREMIUM HOMESITES NOW SELLING|Final Release now available|Premium Homesites Now Available|Now Selling Phase 6|final section now open| now selling phase 4|Final Two Homes Now Selling|Phase 2 OPEN NOW|now selling newest phase|\\\\d+ Basement homesites available now|Finished Basement Homesites Available|\\\\d Finished Basement Homesites Available|Basement homesites available|Basement homesites now available|NOW SELLING PHASE 4|PHASE 3 NOW OPEN|New Townhomes Now Available|LOTS NOW SELLING|TWO NEW PHASES NOW SELLING|Now Selling Section 4|homes now available |Only 2 Finale Home Sites Remain|Only Six Home Sites Remain|Now Selling Final Inventory Home|Phase 4 Now Selling|newest phase now available|Final Ready Homes now available|Phase IV and V now Open |PHASE II NOW OPEN|first phase now available|Now Selling FINAL \\\\d+ Home| Selling New Phase|Phase V now selling|New Homes Now Selling|Phase III Now Selling|Now selling new homesites|Now selling third and final phase|Now Selling Phase II|NOW SELLING PHASE 1 & 2|NOW SELLING PHASE 1|New Phase Now Open|Second Phase Now Selling|Phase II now available|Phase V Now Available|Phase IV Now Available|Phase IV now open|New Homes Now Selling|Phase IV now Open|Now selling Section Two|Now Selling Sections 2 &amp; 3|Now Selling Sections 2 & 3|Now Selling New Section|Final Section Now Open|New Plans Now Available|New Plans now available|new homes now available|New Homes now available|New Section Now Available|\\\\d*\\\\s*home sites now available|homesites are now available|First Section Now Selling|new section now open|New Home Sites Now Available|New Selling New Section|Phase Two - NOW SELLING|Phase 3 Now Selling|Now Selling Phase 2|New Homesites Now Open|section 2 now open|Phase III Now Open|Phase III Lots Now Open|NOW SELLING PHASE TWO|PHASE II NOW SELLING|Final Phase Now Selling|NOW SELLING FINAL PHASE|Now selling final phase|homesites now selling|Now Selling Phase IV|Now selling phases 4 and 5|Final Section Now Selling|Now Selling New Section|Final Phase Now Available|Final Home Sites Now Available|FINAL PHASE NOW OPEN|LAST HOME NOW AVAILABLE|New Homestes Now Available|Quick Move In Now Available|NEW HOME SITES ARE NOW AVAILABLE|Final Homesites Now Available|New Homesites Now Open|Phase 2 now open|Phase 2 Now Open|Only a few lots remain|Only a Few Lots Remaining|Just a Few Remain|3 Homesites Released in Final Phase|NEW SECTIONS NOW OPEN|New Section Now Open|Phase 6 is now open|Phase three now open|Phase Four NOW OPEN|NOW OPEN|Now Open|Phase 4 now open|Last Section Now Open|Second Phase Now Open|NOW OPEN|Final Homes Now Selling|Final Phase Available|Opening New Phase|Phase Two Now Selling|PHASE 3 HOMES NOW SELLING|Now Selling out|New Phase Now Selling|Now Selling|NOW SELLING|NOW SELLING|Final Homes Released|New homesites available early 2022|Phase-II \\d+ homesites available|\\d+ Homesites remain in Phase 2|Only \\d{1} Homes Remain|Limited Homesite Release September \\d+|Only \\d+ HOMESITES REMAIN|\\d+ HOMESITES REMAIN|Only \\d+ Homes Available|\\d+ Homesites Available|Lake View Homesites Available Now|Waterfront Homesites Available|1 Wooded homesite available|One Wooded Homesite Available|Lakeview Home Sites Available|Wooded and Basement Home sites available|Limited number of larger home sites available|Basement Home sites Available Only|Lakefront and wooded homesites available|Wooded Home Sites Available|Large Home Sites Available|Basement Home sites Available|Limited Lake[front]* Homesites Available|Lakefront homesites available|Lakefront Home Sites Available|Only 10 Grand Finale Home Sites Remain|Phase One Homesites available|remaining home sites available|NEW homesites available now|NEW HOME SITES AVAILABLE NOW|New Home Sites Available|new homesites available soon|New Homesites Available|450 homesites available|Final Home Sites Available|Oversized home sites available|86 foot home sites available|Home Sites Available|new homesites available|limited home sites available|New Sites Available|only \\d+ home sites available|\\d+ home sites available|new homesites available|only five homesites available|only four homesites available|only \\d+ homesites available|Only a few homesites available|Now Available|SELLING NOW");
			add("Ready for Move-In");
			add("Selling out soon");
			add("\\d+ Cul-de-Sac Homesites Available|\\d+ Pond View Homesites Available|\\d+ Lakeview Homesites Available|\\d+ cul-de-sac homesites left|\\d+ Cul-De-Sac Homesites Remain|CUL-DE-SAC HOMESITES AVAILABLE|1 Cul-De-Sac Homesite Available|1 Wooded Cul-de-Sac Homesite Available");
			add("0 down financing available");
			add("Only a couple homes left");
			add("Only a Few Lots Left");
			add("Opening in the Fall");
//			add("Phase Two Coming Fall \\d+|New Opportunities Coming Fall \\d+|Coming in the fall of \\d+|Second Phase Coming Fall \\d+|Townhomes Coming Fall \\d+|Final Phase Coming Fall \\d+|Coming Fall of \\d+|Coming Fall \\d+|Coming May \\d+|COMING MARCH \\d+|Coming April \\d+|New Phase Coming in \\d+|New Phase Coming \\d+");
			add("New Section Opening Fall 2022|Grand next phase open early 2022|New Phase Opening Fall 2022|Re-Opening Early 2022|Phase 2 opening early 2022|open early 2022|Opening in January 2022|Opening Fall \\d+|Grand Opening in Early 2019|Opening Early \\d+|Targeted Grand Opening October \\d+|grand open spring \\d+|Opening Winter \\d+-\\d+|Opening November \\d+|Opening December \\d+|Opening Early Fall \\d+|opening mid 2017|Open Spring 201[8|9]|Opening in 2018|open in Spring 2018|Opening Spring 2018|opening Winter 2018[-2019]*|opening Fall 2018|Opening 2018");
			add("NEW PHASE RELEASING SOON");
			add("FINAL PHASE CLOSEOUT");
			add("ONLY 5 OPPORTUNITIES REMAIN");
			add("Final 5 Opportunities");
//			add("PHASE 3 NOW RELEASED|Phase II Closeout Final Opportunities|Final Opportunities 3 Homes Left|Final Opportunities in Phase 3|Final \\d Opportunities|Closeout Final Opportunities|Final Opportunity Available|FINAL OPPORTUNITIES AVAILABLE|Final Opportunities Remain|FINAL OPPORTUNITIES LEFT|only 1 FINAL Opportunity Remaining|Final Opportunities Remaining|final opportunities|FINAL OPPORTUNITIES|FINAL OPPORTUNITY|Final Opportunity|Final Opportunity|FINAL OPPORTUNITIES|Final Opportunities|Last Opportunity|Final Opportunities");
			add("FUTURE PHASE COMING SOON|Final Phase Selling Out Fast|Lots selling out|Selling out quickly|Selling Out Quickly|Nearing sellout|NEARING SELL-OUT|Selling Out Fast|Selling Out"); //Selling Out|
			add("Only 2�homesites remain");
			add("FHA/VA available");
			add("now building in Phases 2 and 3|now building in Phase \\d");
			add("Only 1 House Left");
			add("Selling out soon");
			add("New Lots Released in Final Phase|MORE LOTS RELEASED|NEW LOTS RELEASED|four lots Just released |Five large lots just released|\\d+ lots just released|\\d+ new lots released");
			add("Selling Phase V");
			add("10 Final Home Sites Left");
			add("Final \\d+ Homes Remaining");
		//	add("only one homesite remaining|Only one homesite remains|ONE homesite remaining |Only 6 new home opportunities remain");
			add("Comming End of 2022");
			add("ONLY 8 TWIN HOMES LEFT");
			add("LAST HOME LEFT");

			add("Only 1 Opportunity Remaining|Only one opportunity remaining|Only TWO Remaining Opportunities|Only \\d opportunity remains|Only 1 More Opportunities|Only ONE opportunity remains|only one opportunity remains|Only One Opportunity Remains|Just One Opportunity Remains|One Opportunity Remains|\\d opportunity remain|One opportunity remaining");			
			add("Final Opportunities Coming Late 2022|Limited Opportunties|Final opportunity coming soon|Phase 2 Final Opportunity|Final Opportunity Coming Soon|Five Final Opportunities Remain|One Final Opportunity Remains|Final Opportunity Coming Late 2022|final opportunities in first phase|PHASE 3 NOW RELEASED|Phase II Closeout Final Opportunities|Final Opportunities 3 Homes Left|Final Opportunities in Phase 3|Final \\\\d Opportunities|Closeout Final Opportunities|Final Opportunity Available|FINAL OPPORTUNITIES AVAILABLE|Final Opportunities Remain|FINAL OPPORTUNITY REMAINING|FINAL OPPORTUNITIES LEFT|only 1 FINAL Opportunity Remaining|Final Opportunities Remaining|final opportunities|ONE FINAL OPPORTUNITY|FINAL OPPORTUNITIES|FINAL OPPORTUNITY|Final Opportunity|Final Opportunity|FINAL OPPORTUNITIES|Final Opportunities|Last Opportunity|Final Opportunities|Limited Presale Opportunities Now Available|43 opportunities available|Limited opportunities in Phase IV|ONE OPPORTUNITY AVAILABLE|Only 18 Large Homesites Available|Limited opportunities remaining|Last Opportunities Remain|LAST OPPORTUNITIES|Limited Opportunities Phase IV left|Limited Opportunity Remaining|Limited opportunities left|only five homesites available|Two opportunities remain|Only 2 opportunities remain|Only \\d+ Opportunities Remain|\\d+ Opportunities Remain|Limited Opportunities Available|limited build opportunities remaining|Limited Opportunities Remain|Opportunities Limited|Limited Opportunities|LIMITED OPPORTUNITIES REMAIN|Limited Opportunities|Limited Opportunity| Final Opportunity");
			add("Only 4 homesites left");
			add("Only three opportunities remain");
			add("Only TWO opportunities available");
			add("One Quick Move-In Home Remains");
			add("ONE OPPORTUNITY LEFT");
			add("Only 6 Opportunities Left|Only \\d+ Opportunities Left|13 OPPORTUNITIES LEFT|\\d+ OPPORTUNITIES LEFT|ONLY A FEW OPPORTUNITIES REMAIN|ONLY A FEW OPPORTUNITIES LEFT|FEW OPPORTUNITIES REMAINING|FEW OPPORTUNITIES REMAIN|few opportunities left|only a few opportunities remaining");
			add("Only TWO Homesites Remain");
			add("only 21 opportunities available");
			add("ONLY 14 OPPORTUNITIES");
			add("ONLY A COUPLE OPPORTUNITIES LEFT");
			add("Only 5 homesites left");
			add("Phase 1 almost completed");
			add("Future Phases Coming Early Summer 2022");
			add("Only 2 Homes Remian");
			add("only seven homesites left");
			add("Only TWO opportunities available");
//			add("Only 1 Opportunity Remaining");
			add("Only 5 Opportunities Remaining");
			add("Only 1 Opportunity Left");
			add("4 patio home opportunities");
			add("Phase 2 is now available");
//			add("2 Wooded Homesites Remaining");
			add("PHASE TWO NOW OPEN");
//			add("Only 4 Homes Available");
			add("Phase 2 currently under construction");
			// add("New Section Now Available");
			add("LAST HOME LEFT");
			add("only 7 left");
			add("second phase homesites selling fast|Homesites selling fast|Lots are selling fast|lots selling fast|Phase 4 Home Sites Selling Fast|Phase I Selling Fast|Final phase home sites selling fast|Final Homes Selling Fast|current phase selling fast|Phase III Selling Fast|Phase 1 selling fast|New Homes Selling Fast|HOMES SELLING FAST|Final Phase Selling Fast|Selling Fast|fast selling ");
			add("Coming late Spring 2018|COMING LATE SPRING \\d+");
			add("Only 11 Sites Remain");
			//add("only 40 new homes");
			//add("Only 6 Opportunities Left|Only \\d+ Opportunities Left|13 OPPORTUNITIES LEFT");
			add("9 Opportunities left");
			add("Closing Soon");
			add("One home site remains");
			add("limited lots remaining");
			add("6 new home sites remain");
			add("Only 3 New Homes Remain");
			add("100% USDA Financing Available|USDA Loans available|USDA Rural Housing 100% financing|USDA Eligible 100% Financing|100% financing through USDA|100% financing from usda|USDA Financing Eligible|USDA Eligible Financing|USDA-Financing Eligible|USDA Eligible|USDA 100% Financing Available|USDA Financing available|100% Financing Available|100% USDA financing|USDA financing|100% Financing|100% Financing|USDA 100% Financing|100% financing|USDA Home Loan");
//			add("Only two homes remain|only two homes left|TWO HOMES REMAIN");
			add("ONLY ONE HOMESITE AVAILABLE");
			add("only 1 quick move in home remaining");
			add("New Phase Now  Open|NOW  OPEN");
			add("ONLY 1 LOT REMAINING");
			add("Only 4 Quick Move In Homes Remain");
			add("ONLY 9 HOME SITES REMAINING|Only \\d Home Sites? (Remaining|remains?)|Only three homesites remain(ing)?|(TWO|THREE) homesites remaining");
//			add("Phase-II \\d+ homesites available");
			add("Only FIVE HOMES remaining|5 Homes Remaining|Only FIVE homes remain");
			add("Only a few lots left");
			add("Grand Opening October 2022|grand opening August \\d+|Opening August \\d+|Phase 2 Opening this Summer|grand opening this Summer 2022|Phase 2 Opening this Spring|Grand Opening Coming Soon|New Phase Opening Summer 2022|OPENING SPRING/SUMMER 2022|Grand Opening late Spring 2022|Grand Opening in Spring 2022|Grand Open Spring/Summer 2022|Grand Open Summer \\d+|Grand Opening in February 2022|Grand opening March \\d+|Grand opening Spring \\d+|Grand opening September \\d+th|Phase \\d Grand Opening|Grand Opening January \\d{1,2}, 2019|NEW PHASE GRAND OPENING|Grand opening late Spring of 2018|New Phase Grand Opening Now|Grand Opening Late Summer 2018|Grand Opening of Final Phase|Grand Opening May 2018|Opening May 2018|Grand Opening April 2018|Grand Opening in May 2018|Grand Opening Phase II|Grand Opening in early 2018|Grand Opening April 7, 2018|Grand Opening early 2018|Opening early 2018|Grand opening late 2017|Grand Opening August 2018|Grand Opening October 2018|Grand Opening This Summer|Grand Opening September 2018|GRAND OPENING JUNE 18|Grand Opening Summer 2018|opening summer 2022|open Summer 2022|Open Fall 2018|Opening Summer 2018|Grand Opening March 2018|grand opening early 2018|Opening Early 2018|Grand Opening Soon|Grand Opening this fall|Opening April 2018|Opening March 2018|Grand Opening Opportunities|GRAND OPENING IN JUNE|Grand Opening|OPENING THIS SUMMER|OPENING THIS SPRING|OPENING LATE SPRING|Grand Opening");
			add("Only one lot left|ONE LOT LEFT");
			add("New phase	coming soon");
			add("only 1 house remaining");
			add("\\d+ town homes remaining");
			add("USDA Approved Financing Available");
			add("Only 1 Homesite Left|only 1 homesite left|1 Homesite Available");
			add("Only 1 Townhome Left");
//			add("Coming Winter 2021/2022|Coming Winter \\d+");
			add("Final Phases Now Selling");
			add("Last 5 Homes Remaining");
//			add("OPENING THIS SUMMER|OPENING THIS SPRING|OPENING LATE SPRING");
			add("PHASE 1 -SOLD OUT");
			add("PHASE 2 - NOW SELLING");
			add("ONLY TWO DESIGNER HOMES REMAINING");
			
			add("ONLY 2 HOMESITES LEFT");
			//add("Two Homes Left");
			add("Currently selling NEW SECTION|Currently Selling Phase 6|Currently Selling");
			//add("Opening This Summer");
			add("[Only]*\\s*\\d+ Townhomes Remaining");
			add("ONLY 2 INVENTORY HOMES REMAINING");
			add("PHASE 2 AVAILABLE HOMES|Only 2 Available Homes|Two Stunning Homes Available|Final 2 Homes Available|Only 1 Available Home Left|ONLY 2 AVAILABLE HOMES LEFT|only a few available homesites left|\\d+ Available Homesites|\\d+ Available Homes|final new homes available|New homes available now|New Homes Available|New homes available soon|\\d+ Home Available Now|\\d+ Homes Available Now|\\d+ homes available|\\d+ Homes Available|Only 1 Home Available|Last Two Homes Available|\\d+ available homesites|\\d+ homes available|Homes available now");
//			add("Final Homesites Now Selling");
			add("Opening This Winter");
			//add("Opening This Fall");
			//add("Current Phase Closeout");
			add("Final 7 Homesites Remaining");
			add("Just 1 home remains");
			add("CLOSEOUT OPPORTUNITIES");
			add("COMING THIS September");
			add("Final Phase Coming This Summer"); //|COMING THIS SUMMER");
			
			add("Only \\d+ Homesite Available");
			
			add("Only 3 \"Quick Move In\" homes remaining");
			add("Grand Closing");
			add("ONLY A FEW REMAINING LOTS|few remaining lots");
			add("100% Financing Now Available");
		//	add("Only 1 Available Home Left|ONLY 2 AVAILABLE HOMES LEFT");
//			add("PHASE 3 NOW AVAILABLE");
			add("two home sites remaining|TWO home sites remaining|two home sites remaining");
			add("Ready to move in|READY FOR MOVE IN");
			//add("Coming This Fall");
			add("Phase II Lots coming this Fall|Phase 2 coming this Fall|second phase coming this fall|Coming this Fall");
			add("Coming Later this Year");
			add("168 Homesites Released In Sections");
//			add("Phase 2 Homesites Now Available|homesites now available|homesites now available|now available");
			add("NEW 65' OVERSIZE HOMESITES NOW AVAILABLE");
			add("NEW CLASSIC HOME SITES AVAILABLE");
			add("ONLY NINE OPPORTUNITIES LEFT");
			add("29 TOWNHOMES STILL AVAILABLE");
			add("New Home Ready Now");
			add("Over 100 Homesites Sold");
			add("Only a few townhomes left");
			//add("a few homes remaining|Only a few more homesites remain");
//			add("Premium water-front homesites available");
//			add("temporarily sold out");
			add("One Remaining Home Site");
			add("Only One Remaining Opportunity");
			add("New Townhome Available");
			add("Coming in September|New Section Coming in September");
			
			add("Only TWO homesite remains");
		
			add("New Section Opening Late 2022|phase 2 opening soon|New Phase Opening Soon| Opening Soon |OPENING SOON|new section opening soon|new phase opening soon|NEW SECTION OPEN NOW");
			add("COMING MID-SUMMER 2022");
			add("Just 1 homesite available");
			add("Closing Out - Few remaining");
			add("Closeout Community|Community CLOSEOUT|closing out the final phase|Phase One Close Out|Phase 1 Closeout|Current Phase Closeout|Grand Closeout|Nearing Close-out|Phase I Close-Out|closing out soon|Closeout Community|Nearing Closeout|FINAL CLOSE OUT|Nearing Close Out|Near Close Out|ALMOST CLOSED OUT|Close Out|CLOSEOUT|Final Closeout|CLOSED-OUT|CLOSED OUT |Close-Out Special|Close Out Specials| Close-Out?|Close-out |close-out |CLOSING OUT|closing out|Close-Out");
			add("0% Down Available");
			add("Unit \\d Now Open");
			add("final home available in Phase \\d+|Final Home Available");
			add("TWO LOTS REMAIN");
			
			add("Spring of 2023|Quick Delivery Home Available|Quick Move-In Home[s]|Only 7 Town Homes Available|2 remaining quick delivery homes available|\\d+ Quick Delivery Homes Available|Quick Move-In Homes Ready Now|New Homes Ready Now|MOVE IN READY SPRING OF 2018|Move In Ready home|Only 2 Move-In Ready Homes Remain|No Quick Move In Homes|No Quick Move-In Homes|MOVE-IN READY HOMES|One Move-In Ready Home Remains|Quick Move In Homes|\\d+ Quick Move-Ins Available|\\d+ Quick Move-In Home|\\d+ Quick Move-in home|No Quick Move-Ins Available|no Quick Move-In homes available|no Move-In Ready Homes|No Move-In Ready Homes|No Move-In Ready Homes|no move-in ready homes available|\\d{1,2} Quick Move-ins? Available|Quick Move-ins? Available|No Quick Move-In homes available|Quick Move-in not Available|Move-In Ready Homes|Quick Movein not Available|No Quick Move-In|QUICK MOVE-IN HOMES|No Quick Move-In Homes|Move-In Ready Available|Move In Ready Available|move-in ready homes available|Move In Ready Homes| Move-In Ready Homes|Move-in Ready|Quick Move-In|Ready Home Available|Quick Delivery Homes|Quick Delivery Home|Quick-Move In Homes");
			
			add("Now Offering Premier Floor Plans");
			add("Ready for Sale");
			add("Not Ready for Sale");
			add("Not Ready to sale");
			add("\\d{1,2} homes already sold");
			add("Phase I currently sold out|currently sold out|Over 90% sold out|Current Phase Sold Out|Final Phase Almost Sold Out|OVER 50% SOLD|current phase sold out|first phase sold out soon|currently SOLD OUT|first phase of 20+ homesites sold out|Phase one sold out|Community Sold Out|OVER 50% SOLD OUT OF FINAL PHASE|50% Sold Out in Phase I|Only two lots remain in Phase 1|phase i and phase ii sold out|50% SOLD OUT Phase 2|Over 80% Sold Out|Phase 7 almost sold out|Phase I almost sold out|Phase I sold out quickly|Section 1 Sold Out|temporarily sold out|TEMPORARILY SOLD OUT|Phase 1A is SOLD OUT|Phase 1 currently sold out|50% sold out of final phase|PHASE 1 SOLD OUT|Phase 8 SOLD OUT|Phase 4 nearly sold|Sold out Phase I|phase one and phase two sold out|MORE THAN 70% SOLD OUT|first phase sold out|First Phase Over 75% Sold Out|Over 75% Sold|Phase 7 SOLD OUT|Current Section Sold Out|CURRENT PHASE SOLD OUT|currnetly sold out|Phase II SOLD OUT|sold out quickly|last phase sold out fast|Phase 1 nearly sold out|Lots are sold out|sold out current phase|phase 1 almost sold out|Lots Sold Out|Currently Sold Out|Currently Sold|PHASE 3 SOLD OUT|ALMOST SOLD OUT|almost sold out|Almost Sold Out|Phase I SOLD OUT|Phase I sold out|Phase I is SOLD OUT|\\d+% sold out|Temporarily Sold-Out|Sold Out|SOLD OUT|SOLD OUT|Nearly sold out|TEMPORARILY SOLD OUT|temporarily sold out|50% SOLD");
			add("actively selling new section|Actively Selling");
//			add("Phase one sold out");
			add("Last Chance Opportunities Remain|LAST CHANCE OPPORTUNITIES REMAINING|Last chance for wooded home sites|LAST CHANCE");
			add("only a few more oppportunities available");
			add("MORE THAN 290 HOMES SOLD");
			add("OVER 120 HOMES SOLD|OVER 20 HOMES SOLD|Over 40 homes sold|58 homes sold|104 Homes Sold");
			add("ONLY ONE REMAINS|ONE REMAINS|only ONE remains");

//			add("Final phase - One home remaining|Just a few homes remain|One Homesite Left|only one home left|Under 10 homes remain|Only 1 home remain[s]*|FINAL FEW HOMES REMAINING|Less than 10 homes remaining|ONLY A FEW HOMES REMAIN|\\d+ Homes Remaining|\\d+ Home Remaining|Only ONE home available|only 2 homes left|Only 1 home left|only 1 home left|ONLY ONE HOME LEFT|1 HOME LEFT|One Home Left|One Townhome Homesite Remaining|ONE homesite remaining|ONE home remaining|\\d+ Home Remaining|Only 1 Home Remaining|Only \\d Homes remaining|Only \\d+ homes remain|Only one home remains|One Home Remains|Only�\\d Homes Remains?!?|ONLY�1 HOME REMAINS!?|Only \\d homes remain|\\d+ HOMES REMAIN|Only 1 Home Remain|ONLY 1 HOMESITE REMAINS|ONLY 1 HOME REMAINS|only one home remaining|one home remaining|1 Homesite Remains");
//			add("Final phase One home remaining|Just a few homes remain|FINAL FEW HOMES REMAINING|ONLY A FEW HOMES REMAIN|Only Three New Homes Left|One Townhome Homesite Remaining|Under \\d+ homes remain|Less than \\d+ homes remaining|Only \\d+ Homes Left|only \\d homes? (left|remaining|remains?)|Only \\d Home Site (Remaining|remains?)|ONLY \\d HOMESITE REMAINS|ONLY FOUR HOMES LEFT|Only two homes (remain|left)|TWO HOMES REMAIN|Only ONE home (available|LEFT|remains|remaining)|One Home (Left|Remains|remaining)|One Homesite (Left|remaining)|\\d+ Homes? (Remaining|REMAIN|LEFT)|\\d Homesite Remains| \\d+ Home Sites (Remains?|Remaining)");
			add("Only 1 Home Remaining|Only two homes remaining|Just one home remains|14 Homes Remaining|only two homes left|Final phase One home remaining|Just a few homes remain|FINAL FEW HOMES REMAINING|ONLY A FEW HOMES REMAIN|Only Three New Homes Left|One Townhome Homesite Remaining|Less than \\d+ home sites remaining|Grand Finale Only \\d Home Sites Remain|Under \\d+ homes remain|Less than \\d+ homes remaining|Only \\d+ Homes Left|only \\d homes? (left|remaining|remains?)|ONLY \\d HOMESITE REMAINS|ONLY FOUR HOMES LEFT|Only two homes (remain|left)|TWO HOMES REMAIN|Only ONE home (available|LEFT|remains|remaining)|One Home (Left|Remains|remaining)|\\d Homesite Remains|1 Home Remaining");
//			add("Ony \\d+ Homes Left|Only Three New Homes Left|2 homes only|Only \\d+ Homes Left|only 4 homes left|only 3 homes left|4 HOMES LEFT|ONLY 3 HOMES LEFT|2 HOMES LEFT|5 Homes Left");
//			add("Less than 60 home sites remaining|Grand Finale Only 4 Home Sites Remain|only 138 home sites|\\d+ home sites remains|\\d+ home sites remaining|Only \\d+ home sites remaining|Only \\d+ home sites remain|Only 26 home sites remain|Only 2 Home Sites Remaining");
			
			add("\\d Showcase Homes? Remaining");
			add("1 HOME LEFT|Only 1 home left in Phase I & II|ONLY 1 HOME LEFT|Only 1 home remains");

			add("NEW SECTION FALL 2022");
			add("only 1 lot left");

			add("only a few homesites remaining|Only a few homesites remain|Limited Homes Available|1 walkout basement homesite available|Basement Homesite Available|One Homesite (Left|remaining)|Only a few home sites remain|few home sites remaining in phase 1|Only 1 homesite remaining|only one homesite remaining|Only one homesite remains|ONE homesite remaining |Only 6 new home opportunities remain|\\d+ FINAL HOMESITES REMAINING|ONE HOMESITE REMAINING|Only Few Homesites Remain|Only a Few Remain|Only a few remaining homes|Only a few new homes remain|ONLY 7 HOMESITES LEFT IN PHASE 7|3 remaining homesites|Only a Few Homesites Left|Only one homesite left|Only A Few Homes Left|ONLY 1 HOMESITE REMAINING|Only 1 homesite remaining|\\d+ HOMESITE remaining|1 Home Site Available|ONE home site remaining|one home site remaining|Few Homesites Remain|\\d+ HOMESITES LEFT|Last Homesite available|few home sites remain|just few homes left|Few Homes Left");
			add("USDA LOAN QUALIFIED");
//			add("final homes now available");
			
			add("Coming Summer/Fall \\d{4}");
			
			add("Walk-outs, wooded, and cul-de-sac homesites all available");
//			add("Water Front Lots Now Available|Lake front lots available|Wooded lots NOW AVAILABLE|Just 1 Beautiful Lake Lot Available|Only 8 lots available|LIMITED LOTS AVAILABLE|Large Lots Available|New Lake View Lots Available|Water Lots Available|Oversized Lots Available|Walkout basment lots available|Bay Front Lots Now Available|New Basement Lots Available|Waterfront Lots Available|New Lake Front Lots Available|New Lake Lots Available|Limited Lake Lots Available|New Greenbelt Lots Available|Over-Sized Lots Available|Limited homes and lots available|New Lots Available|14 available lots|Only one lot available|\\d LOTS AVAILABLE|Large Lots Now Available|lots now available|New lots now available|Lake Lots Available|Lots Available Now|Lots Available|only \\d+ lots available|\\d{2} Lots Available|lots available");
			add("Selling Lots Only");
			add("Just 1 Left");
			add("Only \\d Large Wooded Homesites Remaining");
			add("Lots selling quickly|Homes selling quickly|Final Phase Selling Quickly|New Homesites Selling Quickly|final phase is selling quickly|final few homes are selling quickly|Phase I homesites selling quickly|Lots selling quickly|selling quickly|Selling Quickly|Homes are selling quickly");
			add("56 Home-sites Available|only 52 sites available");
			add("Phase 3 Homes Selling");
			add("Opening Winter \\d+");
			add("only 24 townhomes available");
			add("Only 4 Townhomes Available");
			add("New Phase Coming This Winter|Coming this winter");
//			add("LAST ONE");
			add("New Floor Plan Available");
			add("\\d Market Homes Remain");
//			add("Arriving FALL \\d+");
//			add("ARRIVING EARLY 2019");
//			add("Arriving SUMMER 2019");
			add("oversize homesites available");
			add("ONLY 4 EXCEPTIONAL LOTS LEFT");
			add("Section II Open");
		}
		
	};

	public static HashMap<String, String> propTypes = new HashMap<String, String>() {

		{
			put("multi-generational bedroom|multi-generational family|multi-generational families|multi-generation living|multi-generational community|Multi-Generational Home|Multigenerational Homes|multi-gen suite| multi-generational home|personalized for a multi-generational situation|multi-gen living options|Multi-Gen Living Space|multi-generational suite|multi-generational living|multi-generational families|Multi-Gen Suites|Multi-Generational Suites|Optional Multi-Gen Suite|MultiGen Innovation|multigenerational families| multi-gen", "Multi-Gen Homes");
			
			put("executive level homes|executive home sites|Executive Apartments|executive style townhomes|Executive-level living|executive style home|Executive Home Collection|Executive Collection|Executive Series|Series:</span> Executive|executive-style homes|Executive, Single Family Homes|Executive homes|Executive homes|executive-style",
					"Executive Style Homes");
			
			put("bungalow|Bungalows|Bungalow homes|detached bungalows|Bungalow-style homes|Spanish and Bungalow","Bungalow Homes");
			
			put("flexible living|flexible spaces|flex room|Flex space|Flex Room|Flex Series|FLEX Homes|flex options","Flex Homes");
			put("Farmhouse</div>|Deerfield Farmhouse|farmhouse-style home|Farmhouse-style exteriors|Farmhouse Series|red brick Farmhouse Collection|Prairie, Farmhouse|Farmhouse-inspired architectura|farmhouse interpretive townhomes|Farms Villas|modern farmhouse|The Farmhouse|Farmhouse exterior|Farm House, Craftsman|Farmhouse architecture|Farmhouse-style residences|Modern Farmhouse style|farm\\s*house style|Farmhouse styles homes|farmhouse designs|designed Farmhouse|Farmhouses designed|Farmhouse and Ranch|Farmhouse and Ranch|farmhouse elements|Farmhouse, Craftsman|Cottage, Farmhouse|Farmhouse and Traditional|Farmhouse Style Architecture|farmhouse inspired homes|Farmhouse-style Homes| Farmhouse,|American Farmhouse|-Farmhouse | Farmhouse</a>",
					"Farmhouse Style Homes");
			put(" - The Manor|manor house|Manor[s]* at | - The Manors|Manors Collection|The Manors home|Manor - Estate home|MANOR SERIES|Manor Homesites|Manor Estates|Manor Series homes|Windsor Manor home|beautiful Manor home|Manor Home Models|Manors Homes at |Manor Homes</a>|The Manor Collection|Single Family Manor Home|Manor Homes New Home Community|Castleton Manor Community|Estate homes, Manor homes|Manor ranch designed homes|Manor Homes | Manors Homes| Manors| Manor|Colonial Manor|Manor Townhomes| Manor Homes",
					"Manor Homes");
			
			put("loft living|loft offers even|a versatile loft|sizable loft|Oversized Loft|Den/Loft|story loft option home|loft level|with Loft | a loft,? |Loft or Optional Bedroom|<li>Loft[\\*]*</li>|a loft as|and loft|the loft|lofts and|house loft|<li>Loft[s]*</li>|at Loft|loft plus|loft space|huge lof|loft-like design|loft options available|Loft in|Lofts At|The Lofts|recreational loft|large Loft| Loft</div>|, Loft,|patios. Lofts|Loft</span>|or Loft|City Lofts|loft with|Private Family Loft|<li>\\s*Loft\\s*</li>|entries, loft|, loft[s]*,|flexible loft|loft and|Loft and Bonus Room|loft, and two-car garage|expansive loft|loft-style units|open loft|Lofts At Uptown|lofts and rooftop|spacious loft|upper-level loft|Loft Designs|Loft and Terrace| lofts, and more|Loft and single-story flats|two-story lofts |2-story loft|Loft Apartment|Loft Row|loft-style apartments|Lofts at Village Walk|loft area|</span>Loft</span>| opt. loft home|Loft Home| Lofts is a|second-story loft|Upstairs [l|L]oft|loft upstairs|upstairs loft|loft, and balcony|lofts provide|Loft or Opt. Bedroom|of the Loft| and loft|Floor Loft|Floor Loft|Floor with Loft|Optional Loft|offer(ed|s) a loft|comfortable lofts| in lofts",
					"Loft");
			
			put("custom building|Custom Plan|custom designed home|custom-designed|Custom Floor Plans|Custom Amenities|Custom homes|custom-built home|collection of new semi-custom|Single family Custom Homes|custom home appeal|Custom-style living|Summit Custom Homes|James Engle Custom Homes|custom home design|custom-designed townhome|custom home sits|Beautiful custom home|stunning custom home|Custom Home Communities|luxury custom homes|single-family custom homes|customizable homes|Custom Homes in |Designer Custom Finishes|semi-custom homes|customizable designs including|Custom homes plans|semi-custom designer homes|custom-feel all-ranch homes|custom single-family homes|appointed custom homes|unique, custom, luxurious|unique custom homes|custom 2-story plan|custom designed new homes|custom design options |custom-designed lower|great custom home |& Custom Homesites| and custom homes|custom home features |your custom new home|Custom Luxury Homes Available|finest custom homes|in custom homes | custom home designs|Keystone Custom Homes| a custom home|magnificent custom homes|Custom Coastal Cottage-Style homes|new custom home| (C|c)ustom Homes?|Custom Series Homes|Custom Homes",
					"Custom Home");
			put("craftsmanship|craftsman built home|Magnolia Landing Craftsman|Craftsman-style exterior|Craftsman Style community|Craftsman style details|craftsman style trim|Craftsman-style home|Modern Craftsman|Craftsman,Traditional|craftsman styling|Craftsman-style architecture|Craftsman and Traditional|Craftsman Plus floor plans|Craftsman, Traditional|Poplar Craftsman|craftsmen style homes|Craftsman\\s*</div>|Craftsman style brand new homes|Farmhouse, Craftsman|Farm House, Craftsman|Craftsman-style home|Craftsman, and Farmhouse|craftsman-styled homes|craftsman details |craftsman style patio|Craftsman charm |Craftsman Homes|Craftsman features|Craftsman-style exterior|craftsman style facade|Craftsman Colonial|spacious Craftsman style|New Craftsman, Farmhouse|Craftsman Bungalow|craftsman-style exterior designs|crafted custom designed flat|Craftsman exterior styling|Beautiful Craftsman Home|Craftsman style new homes|Craftsman Style swim community|Craftsman and European-style homes|community of Craftsman|craftsman tradition|Craftsman style low maintenance homes|Craftsman townhomes|Craftsman New Homes|Craftsman influenced exteriors |Craftsman Style Home|Craftsman style bungalows|Craftsman cottages|Craftsman exteriors|Craftsman architecture| craftsman style two story home|Craftsman architectural styles|offers craftsman style|craftsman-style plan|Coast Design/Craftsmen Style|craftsman-style townhomes|Craftsman influenced architectural| fine craftsman details|Craftsman style homes|Craftsman-style home|Craftsman-style exteriors|craftsman-style design|Sierra Craftsman|craftsman-style single family|Craftsman-style single-family|Craftsman architectural styling|Craftsman Plus Collection| craftsman-style homes|craftsman style architecture| well-crafted homes|Craftsman, coupled|Craftsman-inspired|craftsman style crown| craftsman style trim accent|exquisite craftsman style|with craftsman exteriors|Craftsman style exterior|Craftsman Style Homes|and craftsman homes|Craftsman-style new homes|craftsman inspired detail|Craftsman design|"
					+ "elevation styles, country and craftsman|Spanish Colonial, Craftsman|craftsman-styled exterior|Craftsman-style flair|craftsman style ranch homes",
					"Craftsman Style Homes");
			put(" Kingsbury Estates| Meadow Estates| Lakeview Estates|Lexington Estates|Estates masterplanned|The Estate|luxurious estate home|luxury single family estate homes|lakeside estate|estate homes in Upper Riverside|Estates is located off|Estate Residences|Estate Style Living|traditional and estates|Manor - Estate home|- Estate home|Estates at Mill Creek|Estate Series|single-family estate properties|estate-sized lots|Single-Level Estate Home|Estate Collection|estate floorplans|new estate home|estate-caliber homes|large estate home|estate-sized home|Estates features|Estates Series community|estate style community|Estate Size Homesites|estate sized lots|estate-sized home sites|Estate Home Community|Estates Series Home|Estate & Signature Collections|luxurious estate home|luxury living estate living|Estates sized homes| estate-style living |estate style living |luxurious estate living|Estate-Sized Homes|Estate-size home|estate home featuring| Estate Series |Estate style crown |estate style lots|estate sized home sites|Estate style homes|estate-sized homes sites|sprawling estate home|The Estate Collection|Estate Homes|to estate homes|estate-like homes|Estate homes, Manor homes|single family and estate homes|Estates Custom homes|Estate-sized homesites| Estates home| estate homes |single-family estate homes|luxury estate homes |estate homesites|luxurious estate homes|Estate homes New Home|Single Family Estate Home| elegant estate residences|estate home communities| estate-style home|estate homes feature|estate series homes|estate homes situated |Estate-Style Homes|Estates homes|Valley Estates",
					"Estate-Style Homes");
			put("Two-Family home|2-Family Home|2-Family Home",
					"Two Family Homes");
			put("fully detached|Detached Patio Homes| detached villa|Detached outbuildings|detached residences|detached homes|detached condos|detached luxury single-family residences|detached three-story|detached villas|detached floorplans|Residential-Detached|detached bungalows|Detached<br>Homes|Single-Family Detached|detached single-family|detached, single-family|Single Family Detached|Detached and paired|Detached Single|dream home – detached|detached two-story homes|detached condominium|detached, two-story|detached 2 and 3-story|Detached Home|detached homes|Detached Homes|detached townhomes|detached ranch|detached home|Detached Town Homes",
					"Detached Home");
			put("luxury single family estate homes| single-family homes |Single Family Home|single and multifamily homes|Single-Family Custom Homes|Single-Family Homes| single and multi- family homes|single family home| single- and multi-family|single-family homes|Single Family Home|Single Family Homes|Single luxury family|single-family|Single-Family|SINGLE FAMILY|single family|single and multi-family|Single-Family Home |Single Family Homes|single-family home|Single Family Homes",
					"Single Family");
			put("Executive Apartments|apartments|apartment", "Apartment Homes");
			put("attention to traditional| traditional study	|Traditional-style house|Traditional Style Homes|Collection: Traditional|traditionally styled exterior designs|Traditional  single family homes|Traditional exterior|- Traditional Series|Poplar Traditional|traditional layout|traditional one-story|Traditional three-story|traditional townhome|New Tradition Homes|traditional family homes|traditional single |TRADITIONAL NEW HOME|traditional-style brick homes|Traditional, Low County|Traditions floor plan|traditional architecture|Traditional-style homes|craftsman tradition|traditional two-story style home|traditional features|Traditional, Bungalow|Craftsman,Traditional|traditional upper level|traditional home arrangement|Traditional & Craftsman style exteriors|Windsor Traditional|traditional floor plans|traditional single family|Traditional Townhomes|traditional ranch-style homes|Traditional architectural style|Traditional Ranch homes|traditionally styled homes|Traditional single family homes|traditional collection| traditional communities|Traditional Singles|traditional-series|traditional three story|traditionally-styled|features Traditional|Traditional, and|Traditional and|Traditional</li>|Traditional Family Neighborhood|<p>Traditional,|Traditional two story home|traditional home|traditional design|traditional elegance|traditional new homes|traditional homes|traditional neighborhood|Traditional Community|traditional single-family|Traditional Neighborhood Homes|mix of traditional|traditional style and|Cottage, Traditiona|Traditional, Cottage| traditional style|traditional one- and two-story homes|Traditional</div>| traditional two-story|Traditional Texas-style homes|Traditional and Cottage Collection|Traditional and Italian",
					"Traditional Homes");
			
			put("luxurious modern|luxury and comfort|new luxury|luxurious feel|air of luxury|designed for luxury|luxury coastal community|own luxurious bath|luxury every day|luxury single family estate homes|luxurious estate homes|luxurious gated community|luxurious master bedrooms|luxury 3-level townhome with all the living|luxury bedroom suites|luxuries|luxury of a private garage|luxury residential|luxurious new townhomes|luxurious lifestyle|luxurious single-family|LUXURY GARDEN HOMES|luxurious interior|luxury of home|luxurious main level|[l|L]uxurious [O|o]wner's [S|s]uite|Luxurious Interior|custom luxury|luxury master-planned|luxurious community|Luxury features|luxury design|luxurious standard features|luxury owner retreats|Luxuriously Appointed Interiors|Luxury elevator townhomes|luxurious home|luxurious collection|luxurious new Coach Home|luxury, single family|luxurious features|Luxurious Living Spaces|luxurious dream home|luxurious finishes|luxury designed homes|luxurious condominium|luxury master suites|luxuriously appointed homes|luxurious\\s+single family homes|features luxurious|luxurious maintenance|luxury owner’s suite|LUXURIOUS MASTER SUITE|luxurious amenity|luxurious townhome|luxurious options|luxurious and|LUXURY MID-RISE CONDOS|Luxurious Master Suite|luxurious Owner’s Suite|luxury of living|luxurious multi levels|luxurious owner’s suite|luxurious carriage home|luxurious single-family homes|luxurious finishes|luxury residences |Luxurious Included |luxurious owner's suites|Luxury Included|luxury and conveniences |luxurious amenities| luxury finishes| luxurious single level |luxurious master suites|luxurious estate living|new home luxury|luxury townhomes|Stylish luxury meets|warmth, luxury|Luxury Gated Community| luxury flats|Luxury Cottages|Luxury Custom Home|Luxurious new homes|luxury for buyers|luxury villa |many luxury features|luxury-inspired amenities|luxury town home|Luxurious sized Master Suites|luxury style|luxury amenities|luxury real estate community|Luxury Penthouse|luxury ranch-style homes|luxury new home|luxury rental residence|lifestyle and luxury|Luxurious Homes|luxury gated townhome|luxury gated|Luxury Retirement Community|luxury condo|luxury single| luxury living.|luxury neighborhood|new luxury plan|luxury collection|luxurious living|luxury townhomes|luxury life|AFFORDABLE LUXURY|luxury homes|luxury home|luxury patio homes|Luxury Estate Homes|homes that combine luxury|luxury gated communit|Luxury Single-Family Homes|Luxury Single Family Homes|luxury one-| luxury of 37 gated| offer luxury|luxury ranch homes|luxury community|luxury apartment|luxury detached|Luxury, garage townhomes|luxury affordable|Luxury Living|luxury townhome|Luxury Villas|luxury single|luxury paired homes|luxury resort|comfort and luxury|Luxury Towhomes"
					+"|luxury of having|Luxurious mediterranean-style|luxurious pool|Luxurious, low-maintenance living|Low-Maintenance Luxury Properties|luxury residence|offering a life of luxury|luxurious floor plan|luxurious detached villas|Luxury First-Floor|luxurious 55\\+ community|luxurious plans|luxury amentities|luxury mid-rise condo",
					"Luxury Homes");
			
			put("claasic row homes", " Claasic Row Homes");
			put("Multi-Family|MULTI FAMILY|multi\\s*-?\\s*family,|Multifamily condominiums| multi\\s*-?\\s*family |>Multi-Family |Multi family&|<li>Multi-Family</li>|Multi-Family</span>", "Multi-Family");
			put("condominium homes", "Condominium");
			put("<h1>Villas</h1|Paired Villas|The Villas|Condominium Suites, Villas|ranch Villa|Branch Villas|single family homes, villas,|and villas|attached villas|Villa</em>| Villas</th|Twin Villas|courtyard villa|villas |luxurious villa|/Villa |Villa Homes|Villas | Villa,| villa |villa-style homes|Villa</span>"
					+"| villas,",
					"Villas");
			put("largest townhome builder|Town Home Sites|stunning Town Home design| Town Home plans|townhome[s]*|<em>Triplex Townhomes|<em>Townhomes| Town Homes| - Townhomes|multi-level townhomes|multilevel townhomes|Luxury Townhomes|2-level townhome| townhomes,| Townhome | townhomes |and townhomes |townhome style| Townhomes</b>|Townhome/Condo |Townhome Condo |and townhomes.|>Townhomes<|<p>Town homes</p>| town&nbsp;home series",
					"Townhome");
			put("Single-Family", "Single Family");
			put("COTTAGES|Cottage", "Cottage");
			put("Monthly HOA covers|Approximate Monthly HOA Fees|<h2>HOA</h2>|Farms HOA|by Homeowner Association|Active Homeowner Association|HOMEOWNER’S ASSOCIATION|low HOA fees|HOA-maintained front yards|with HOA|low fee HOA|Homeowner&rsquo;s Association |HOMEOWNER ASSOCIATION DUES|Homeowners' Association|resident Homeowner Association|<strong>HOA|Place HOA|Low HOA fees|Low HOA|HOA</a></li>|by HOA| HOA | HOA |hoa |HOA Info|HOA dues|hoa dues|home owners association|Homeowners Association|HOA <span|Homeowner's Association |Homeowner's Association|Home Owners' Association|The HOA|<li>HOA|HOA</li>|&q;HOA&q;|Free HOA Dues",
					"Homeowner Association");
			
			put("COVERED PATIO,|covered porch and patio|rear covered patio|Patio-style home|Patio Home|rear patio|patio|Patio", "Patio Homes");
			
			put("finishes paired|paired-home community|paired home|Paired Townhome|paired courtyard homes|paired patio|paired home villas|Paired and single-family home|paired residences|paired villa |paired new homes|Paired Homes|paired patio homes| Paired Ranches|Paired Villa homes|paired villas|paired and single family",
					"Paired Homes");
			put("twin \\(attached\\) house|twin-style carriage homes|Twin Homes|Twin Villas|Twin Villa|Twin Home", "Twin Homes"); 
			put("Zero-Lot-Line Home", "Zero-Lot-Line Home");
//			put("Cottage", "Cottage");
			put("Row Homes|Row Houses|Rowhomes|luxury rowhome| Row Homes| row homes","Row Homes");
			put("Cabin ", "Cabin");
			put(" Courtyard| courtyard", "Courtyard Home");
			put("Multi-Family Housing Products",
					"Multi-Family Housing Products");
			put("<p>Duplex</p>|<strong>Duplexes|Duplex | Duplex", "Duplex");
			put("5 Plex", "Fiveplex");
			put("6 Plex", "Sixplex");
			put("3-plex| triplexes|Triplex |Tri-plex|tri-plex|3 Plex", "Triplex");
			put("attached fourplex|Quadraplex |4-plex|4 Plex", "Quadraplex");
			put("commons area |common&nbsp;area|common area", "Common Area");
			put("Type V - Garden|Garden-Style Living|Apartments\\s*,\\s*Garden Style|garden style apartments|Gardens Collection|garden-style apartment buildings|garden style condominium|garden style floor plans|Garden-style apartment homes|Garden –Style Apartment Homes|Garden Collection|garden-style buildings|garden-style apartments|garden style apartment |garden style homes|garden-style community |garden apartments|Garden Series|garden home|garden/patio home|Garden View Home|garden style buildings|garden courtyard|garden patios|garden patio|Garden Villas|Garden Homes", 
					"Garden Home");
			put("Apartment Flat", "Apartment Flat");
			put("carriage-style townhome|Carriage-Style Townhomes |Carriage and Cottage Collections|The Carriage Collection|carriage house|Carriage</span>|Carriage Home|carriage flats|Carriage Style|Carriage, Townhom|carriage-style homes|Carriages Collection",
					"Carriage Home");
			put("Coach Home", "Coach Home");
//			put("townhouses|Townhouse", "Townhouse");
			put("Condo-Hotel Residences", "Condo-Hotel Residences");
			put("Private Resorts", "Private Resort");
			put("Hotel Residences", "Hotel Residences");
			put("Private Residence Club (PRC)", "Private Residence Club (PRC)");
			put("Housing Cooperative (Co-Op)", "Housing Cooperative (Co-Op)");
			put("Interval Ownership", "Interval Ownership");
			put("Destination Clubs", "Destination Clubs");
			put("Land Lease", "Land Lease");
			put("Common-Interest Developments (CIDs)",
					"Common-Interest Developments (CIDs)");
			put("Covenants, Conditions and Restrictions (CCRCs)",
					"Covenants, Conditions and Restrictions (CCRCs)");
			put("mediterranean-style| Mediterranean","Mediterranean Style Homes");
//			put("coastal-style homes| coastal homes|coastal architectural|Coastal living","Coastal Style Homes");
			put("Cove at the coast|Coastal Classic|Coastal Luxury|coastal vibes|coastal lifestyle|coastal-style homes|Coastal architectural styles|Coastal and Traditional Exteriors|Coastal Contemporary design|coastal-inspired architecture|spectacular coastal setting|Coastal Classic plan|custom coastal residence|Coastal-themed community|beautiful coastal area home|Marlene Coastal|Coastal cottage|Coastal Tuscan| coastal lifestyle|coastal contemporary architecture|coastal villas| Coastal Farmhouse Series|coastal community|A Coastal Inspired|coastal cottage-style homes| coastal living| coastal homes|Coastal Farmhouse-inspired|coastal craftsman|COASTAL COLLECTION|coastal communities|COASTAL LIVING|Coastal White","Coastal Style Homes");
			put("Craftsman style details|styles such as traditional, craftsman|Craftsman and Farmhouse style homes|craftsman and farmhouse style|Craftsman and bungalow style|craftsman- style dream home|craftsman community|Craftsman Collection|Craftsman and Cottage exterior styles| Craftsman Series| traditional Craftsman-style townhome|Western Craftsman plan|Stunning craftsman exterior|Crafted Luxury|Craftsman Series Floor Plans|California Craftsman|Craftsman Floor Plans|gorgeous Craftsman style|Craftsman style ranch |Craftsman inspired details|incredible Craftsman style finishes |classic craftsman and colonial style |Craftsman Architectural Detailing|Adorable Craftsman style|fantastic craftsman style|These Craftsman style floor plans |classic craftsman design|craftsman design|craftsman style plans|Hartford Craftsman|craftman-style homes|and Craftsman|craftsman style with extensive|craftsman style trim|Craftsman</h3>|Craftsman</h4>|Craftsman, Prarie|Craftsman-style home|Spruce Craftsman|Craftsman Cottage style|Modern Craftsman|Craftsman,Traditional|craftsman styling|Craftsman-style architecture|Craftsman and Traditional|Craftsman Plus floor plans|Craftsman, Traditional|Poplar Craftsman|craftsmen style homes|Craftsman\\s*</div>|Craftsman style brand new homes|Farmhouse, Craftsman|Farm House, Craftsman|Craftsman-style home|Craftsman, and Farmhouse|craftsman-styled homes|craftsman details |craftsman style patio|desired craftsman home|Craftsman charm |Craftsman Homes|Craftsman features|Craftsman-style exterior|craftsman style facade|Craftsman Colonial|standard Craftsman style|spacious Craftsman style|New Craftsman, Farmhouse|Craftsman Bungalow|craftsman-style exterior designs|crafted custom designed flat|Craftsman exterior styling|gorgeous Craftsman Exterior|Beautiful Craftsman Home|Craftsman style new homes|Craftsman Style swim community|Craftsman and European-style homes|community of Craftsman| detailed Craftsman-|craftsman tradition|Craftsman style low maintenance homes|Craftsman townhomes|Craftsman New Homes|Craftsman influenced exteriors |Craftsman Style Home|Craftsman style bungalows|Craftsman cottages|Craftsman exteriors|Craftsman architecture| craftsman style two story home|Craftsman architectural styles|offers craftsman style|craftsman-style plan|Coast Design/Craftsmen Style|craftsman-style townhomes|Craftsman influenced architectural| fine craftsman details|Craftsman style homes|Craftsman-style home|Craftsman-style exteriors|craftsman-style design|Sierra Craftsman|craftsman-style single family|Craftsman-style single-family|Craftsman architectural styling|Craftsman Plus Collection| craftsman-style homes|craftsman style architecture| well-crafted homes|Craftsman, coupled|Craftsman-inspired|craftsman style crown|This Craftsman styled| craftsman style trim accent|exquisite craftsman style|with craftsman exteriors|Craftsman-style Sweetwater home|Craftsman style exterior|Craftsman Style Homes|and craftsman homes|Craftsman elevation",
					"Craftsman Style Homes");
			
		}
	};
	private static HashMap<String, String> commTypes = new HashMap<String, String>() {
		{
			put("single\\s*-?\\s*family", "Single Family");
			put("multi\\s*-?\\s*family", "Multi-Family Dwellings");
			put("town\\s*-?\\s*homes", "Townhomes");
			put("tower and estate residences", "Tower & Estate Residences");
			put(" condo(minium)? ", "Condominium");
			put("55_plus", "55_plus");
			put("carriage homes", "Carriage Homes");
		}
	};

	private static HashMap<String, String> dcommTypes = new HashMap<String, String>() {
		{
			//put("One Story Split","One Story Split");
			put("single level|1 Story|Story 1|Stories: 1|single-story home|One Story|1st Floor Owner's Suite|1st or 2nd floor owner's suites|first and second floor owner|One- and two-story|single- and two-story|single and two-story|1 Stories|single-level home|1-and 2-story|1 Story</h5>|one or two-story homes|<em>1-Story</em>|Story 1.00|Stories: 1.0 |single and two story homes|1 - 2 Stories|1 - 1.5 Stories|story 1 | first-floor living |1 or 2-story home|1-Story</li>|single floor living|1st and 2nd floors|Offering first floor|first floor owner|first floor living|single-floor|one or two-stories|1- or 2-story|One-Level|one level|one level living|first story|Stories\\s*\\n*\\s+1|One Level Living|one level living |1, 1.5 and 2-story|Story: 1.00|one-level living |1- and 2-story|one- & two-story|one-level homes|Single-Level|1 Story|one & two-story|one-and two-story|one and two story|1 story|Stories 1 |single level|single story|1  Story|Single- and 2-Story|1 &amp; 2 story|Stories: 1 |1 or 2 story| 1- &amp; 2-story|1- & 2-story|1 and 2-Story|single-level and two story|single-level and two story|one and two story|One &amp; two story|Story 1<|Single story|1 and 2 story|ingle &amp; two-story|Stories: 1<|one and two-story|1 & 2 story|One- and two-story|One- and two- story|one and two story|One or Two Story|1-3 Stories|one and two story|1-Stories|single-story|1 & 2-Story|single and two-story|1-2 stories|One and two-story|Stories 1 |one-story|single story|1 Story Home|1  Story Home|1-story|One Story| 1-story|single-story|1 Stories| 1 STORY|Stories:</span> 1|1�story|single- and two-story|one story| one story|One, one and half and two story|1.0 Story| 1 &amp; 2-story home|Single and 2-Level |single, two-level|1 story|One story",
					"1 Story");
			
			put("Reverse 1.5|Reverse 1½ Story|Stories: Reverse 1.5|Reverse 1.5 Story|reverse story-and-a-half homes|Reverse-one-half-Story|Reverse 1.5 Stories|Stories: Reverse 1.5|Reverse 1.5 Story|reverse 1 1/2 story", "Reverse 1.5 Story");
			
			put("1.5 &amp; 2-story|1.5 and 2-story|1 1/2 story condos|1.5 Story</li>|1.5 Story|Stories 1.5| 1.5 Story<|1.5 - 2 Stories|1 1/2 story home|1.5 story home|One-and-a-half story|Stories: 1.5 &nbsp|One and a half-story|1, 1.5 and 2-story|Stories: 1.5|1 1/2 Story|1.5-story|1.5 Stories|1-1/2- story|Story 1 1/2|1.5 story|one &amp; a half story|one & a half story|story-and-a-half|one-half story|1 ½ story|1 &frac12; story|one-and-a-half or two story|1-½ and 2-story|story and a half|1.5 Story |Story 1.5|Stories: 1.5|Stories: 1.5|story 1 - 1.5|1.5 and 2 story|1�  story|1/2 story|stories\" value=\"1.5|1.5�story|one and a half story|1 &frac12; story|one and ½ story",
					"1.5 Story");
			
			put("two and three-story|2 Story|second story loft|Stories 2|2-stories|2 Story|2nd level| 2nd story |<li>2 Story</li>|2-story homes|2 STORY</div>|2 Stories|</span>2 Story</span>|<strong>2</strong> Stories|<p>2-Story|Two-level townhomes|2 Story,|2nd Story|two-story home[s]*|<em>2-Story</em>|\\s+2-Story |2-3 Story | (t|T)wo level townhome | 2-story design |2-3 story homes |2- and 3-story |two-story home[s]*|2&nbsp;&amp; 3-story|second floor owner| 2 story| 2 story |2 - 3 Stories|two-story|2- or 3-story |2 and 3 story|2 Story</strong>|two-stories|second level |2-level luxury|second level|two-level homes| 2-Story|2 &amp; 3 story|<li>2 Stories|two to three stories|2.0 story| 2-Story|second-story|Story: 2.00|2 and 3 stories|2-level condos|Story 2|one and two story| 2 story|even\">Story 2|Stories 2|Stories: 2|two story| 2 Story|Stories:</span>2|2-Stories|Two stories|two-story|two and three story|two story |Stories 2|two- story|Second Story|two-story|Story 2.0|2  Story Home|2 stories| 2 story| 2 STORY|two-Story|[T|t]*wo-[S|s]*tory| Two-story| 2-Story|two story|Two Story| 2-story|TWO STORY|Stories:</span> 2| 2�story|two- and three-story|Stories: 2|two- to three-story|2-Story|from 2 to 3 level|(\\s|\t)2 Story(\\s*)?<br|\"2 Story|from 2 to 3 levels|&nbsp;2 - 3 Story Detached|Single and 2-Level ",
					"2 Story");

//			put("","Reverse 1.5 Story");
			
			
			put("2 1/2 story|2 1/2 Story|2.5 stories| Story 2.5", "2.5 Story");
			
			put("two and three-story|three-story|Three-story|3-4 Finished Levels|Three-to-Four story| three to four stories| three story |tri-level home|three- to four- story|Series:</span> Tri Level|3 Stories|story 3| third-story |3 Stories|three-level Carriage-Style Townhomes|3-story townhomes| 3.0 story|3 Finished Levels,|3-Level Luxury |3 levels of living|3- and 4-story|3-level townhome|3 and 4 level townhomes|3rd level|3 and 4 level|third story|3-4 story|3 and 4 story|3-level townhomes|three stories|3 story|Stories 3|Three-Story|Story 3 |Stories: 3|Stories 3|two- to three-story|three to four-story|3-Stories|three story|three-story|3 Story|story 3.0 |3-story townhomes|3-story|Three-story| 3 Stories|Stories:</span> 3|3 Story|three-story|3�story|Stories: 3|from 2 to 3 level| three levels?| 3- and 4-level home| three, two-story | 3-level| three-level|three and four-story",
					"3 Story");
			
			put("Stories: 3.5|3.5 Stories", "3.5 Story");

			put("Story 4|4 finished levels|Four Finished Levels|four levels |4 Stories|4-level home|four- story|Four story |four stories|4-level townhomes|4 finished levels|4th level bonus suites|4th level bonus suites| four level townhomes |4 level townhomes|3-4 Stories|Stories:</span>4|4-story|four-story|Stories: 4|4 level|4 Stories|4 story|Story 4|Stories 4|4�Story| 4th level| 4 &amp; 9 floor| 3- and 4-level home|four-level | 4-level ",
					"4 Story");
			
			put("five-level splits", "Five-Level Splits");
	
			put(" five-story|five-level floorplans|5-level design|5-level plans| 5th-floor |Stories:5| 5 (S|s)tory|five levels| 5-story|5 Story mid| 5 stories|>5 Story |\"5 Story", 
					"5 Story");

			put("six-story| 6 (s|S)tory|six-story| 6-story ", "6 Story");
			put("seven-story|, 7 floors| 7 (S|s)tory", "7 Story");
			put("eight-story| 8 (S|s)tory","8 Story");
			put(" nine-level |Nine stories|9th-Floor |nine-story|, 9 floors| 4 &amp; 9 floor", "9 Story");
			put(" ten-story | 10- and 12-story|a 10-story| 10-story "," 10 Story");
			
			put("Eleven-Story", "11 Story");
			put("tweleve story| 12 stories| 12-story| 12 story", "12 Story");
			put(" 14-story|Fourteen-Story"," 14 Story");
			put("top 15 floors| 15-story ","15 Story");
			put(" 16 story ", "16 Story");
			put("17-story","17 Story");
			put("18-story","18 Story");
			put("thirteen Story","13 Story");
			put("nineteen story | 19-story","19 Story");
			
			put("54th floor","54 Story");
			put("30th floor|30 floors","30 Story");
			put(" 20-story,"," 20 Story");
			put(" 21-story", "21 Story");
			put("22 Story|twenty-two_story","22 Story");
			put("25 Stories|25-story|25th-floor ", "25 Story");
			put(" 26 story |26 stories high"," 26 Story");
			put("32-story","32 Story");
			put("31 story","31 Story");
			put("33 stories ","33 Story");
			put("39 stories ","39 Story");
			
			put("40-story ","40 Story");
			put("41 stories","41 Story");
			put("45th floor |45th-floor","45 Story");
			put(" building: 46 levels","46 Story");
			put("reverse ranch","Reverse Ranch");
			
			put("multi-level foyer", "Multi-Level Foyer");
			
			put("multiple-level plans|multilevel townhomes|Multi-Level|multi-level|Multi Level|multi-story|multi-level courtyard",
					"Multi-Level");

			put("<br>Ranch<br>| ranch plan |ranch-style layout|Ranch Style|ranch condominium|Ranch & Two-Story|Ranch & 2-Story Plans|Rancher Series|ranch floor plan|ranch and two-story|1 ranch|Ranch & Smart|Ranch Plan|Ranch Style Design|Ranch floorplans|ranch-style floor plan|Ranch Elevation| Ranch architectural styles|Ranch and |Spacious ranch plans|all-ranch plan community|listing\">\\s+Ranch|Ranch Patio |ranch-style|ranch home| Ranch | ranch| ranch-style |Ranch</span>| Ranches | ranch,| Ranch|<strong>Ranch</strong>|rambler style|Rambler</p>|Modern Ranch",
					"Ranch");

			put("split design|split plan with over|split-plan home|(S|s)plit floor plan|Single Level Split Plan|split plan design|Series:</span> Split Level|split floor-plan|2-Story Bi-Level|Split Level</span>|Split-level home| a split level|Split-Level|Bi-Level|split floorplan|split plan","Split Level");
			
			put(" Colonial|Colonial style|early colonial|architectural styles like colonial|Spanish Colonial|The Colonial|Colonial and Ranch|colonial home plans|and Colonial|Colonial Homes|Colonial Revival|Ranch-, Colonial-|Colonial- and Ranch|Colonial styles|story colonial|Ranch or Colonial|ranches to colonials|Colonial Single-Family Homes|Traditional Colonial|, Colonial and|Crafts, Colonial, |Colonial Architecture|Ranch, Colonial and|Colonial inspired architecture|Colonial Village|At Colonial Charters|Colonial exterior|including Colonial| Craftsman Colonial |</span>Colonial</span>|colonial, art |Colonial settlements|Spanish colonial Reviva|, Colonial Estates|Spanish Colonial, Ranch| colonial design|Colonial\\s+</span>|Colonial Manor",
					"Colonial");
		}
	};

	public static void log(Object o) {

		System.out.println(o);
	}

	public static String getCacheFileName(String url) {

		String str = url.replaceAll("http://", "");
		str = str.replaceAll("www.", "");
		str = str.replaceAll("[^\\w]", "");
		if (str.length() > 200) {
			str = str.substring(0, 100) + str.substring(170, 190)
					+ str.length() + "-" + str.hashCode();

		}

		try {
			str = URLEncoder.encode(str, "UTF-8");
			// U.log(str);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();

		}
		return str + ".txt";
	}

	public static String getnote(String html) {
		html = html.replaceAll(" {2,} ", "");
		
		String note = "-", match;
		String pnote = "-";
		for (String item : notes) {
			// U.log(html);
			match = Util.match(html, item, 0);

			if (match != null) {
				// // U.log(html);
				// U.log("::kirti");
				html = html.toUpperCase().replace(item.toUpperCase(), "");
//				 U.log(html);
				U.log("match :" + match);
				U.log("item :" + item);
				note = U.getCapitalise(match.toLowerCase());
				if (pnote.equals("-"))
					pnote = note;
				else
					pnote = pnote + ", " + note;
			}

		}
		return pnote;
	}

	private static ArrayList<String> notes = new ArrayList<String>() {
		{
//			add("Final home(s)? for sale");
			add("Phase 2 is now for sale");
			add("PRECONSTRUCTION PRICING");
			add("Just Released for Sale");
			add("Pre-Grand Opening Pricing Now");
			add("Lot For Sale");
			add("Now Pre- Selling");
			add("Pre-Grand Opening Phase Release|Pre Grand Opening");
			add("now open for leasing");
			add("Opening for Sales in late Spring 2019|Phase 3 Now Open For Sales?|Last Phase Now Open for Sales?");
			add("pre-sale in spring/early summer of 2022");
			add("Now Pre-leasing|Pre-leasing Fall 2022|PRELEASING 2017|Now Leasing|NOW LEASING|PRE-LEASING");
			add("presales begin early 2023|presales early 2023|NEW SECTION PRE-SELLING NOW|Pre-Selling September 2022|Pre-Selling December 2022|New Phase Now Pre-Selling|Pre-Selling Spring 2023|Pre-Selling Summer 2022|presales begin in Fall 2022|Now Pre-Selling|Pre-Selling Begins Summer 2022|Pre-Selling Phase \\d|Pre-sales begin Spring 2022|Pre-sales Spring 2022|Pre-Selling early summer 2022|Pre-Selling June 2022|Pre-Sales for Phase 2|Pre-Sales Coming Soon|pre-sale in early 2022|now pre-selling|presales early 2022| Pre-Sales Coming Soon|Pre-Sales Opportunities are Sold Out|Pre-Sales|now preselling|Now Preselling|pre-sells|Pre-Selling Early 2022|Pre-sale Opportunities Available|Phase II Now Pre-Selling|Pre-Selling Fall \\d+|Now Pre-Selling Phase \\d+| PRE-SALE OPPORTUNITIES |Pre-Selling New Phase|now open for pre-sale|NEW SECTION NOW PRE-SELLING|NOW PRE-SELLING NEW PHASE|Now Pre-Selling Phase II|Preselling Fall 2017|Now Pre-Selling Phase II|NOW OPEN FOR PRESALES|Preselling Phase 4|now pre selling|Final Phase Now Preselling|Pre-Selling NOW|Now Pre-Selling|Now Pre-Selling|Now Pre-Selling|Final Phase Now Preselling|Now Preselling New Phase|Now Preselling|PRE-SELLING|PRE-SELLING|PRE-SELLING|Preselling Now|Presale|Pre-sale|Preselling|Pre Selling");
			add("pre-construction sales");
			add("100% LEASED");
			add("Phase II is now open!!");
//			add("Pre-Construction Opportunity|pre-construction prices|Pre-Construction Pricing|Pre-Construction Pricing ?|Pre Construction Pricing ?");
			add("Pre-Construction Opportunity");
			add("Now released for sale|Preselling New Phase Now");
//			add("presales early 2022");Pre-sales Spring 2022
		}
	};

	public static String getCache(String path) throws MalformedURLException {

		String Dname = null;
		String host = new URL(path).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;

		File folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = getCacheFileName(path);
		fileName = U.getCachePath() + Dname + "/" + fileName;
		return fileName;
	}

	public static String post(String urlPath,
			HashMap<String, String> customHeaders, String data)
			throws Exception {

		// ----- Do the cookies
		HashSet<String> cookies = new HashSet<String>();

		{
			if (customHeaders != null) {
				URLConnection urlConn = getConn(customHeaders.get("Referer"),
						customHeaders);
				// U.log("Getting cookies from: " +
				// customHeaders.get("Referer"));
				cookies = CookieManager.getCookies(urlConn);
			}
		}

		// Send data
		URLConnection conn = getConn(urlPath, customHeaders);
		CookieManager.setCookies(conn, cookies);

		OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
		wr.write(data);
		wr.flush();

		StringBuffer buf = new StringBuffer();
		// Get the response
		BufferedReader rd = new BufferedReader(new InputStreamReader(
				conn.getInputStream()));
		String line;
		while ((line = rd.readLine()) != null) {
			buf.append(line).append("\n");
		}
		wr.close();
		rd.close();

		String html = buf.toString();

		return html;

	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	//
	//
	//

	public static String[] getAbsoluteLinks(String[] values, String baseUrl) {

		String[] Links = new String[values.length];
		for (int i = 0; i < values.length; i++) {
			if (values[i].startsWith("http"))
				Links[i] = values[i];
			else
				Links[i] = baseUrl + values[i];
		}
		return Links;
	}

	public static String getAbsoluteLink(String value, String baseUrl) {

		String link = null;
		if (value.startsWith("http"))
			link = value;
		else
			link = baseUrl + value;

		return link;
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	// New function that mimics browser

	public static String getHtml(String url, WebDriver driver, Boolean flag)
			throws Exception {
		// WebDriver driver = new FirefoxDriver();
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;
		if (flag == true)
			folder = new File(U.getCachePath()+ Dname + "Quickkk");
		else
			folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		// fileName = "C:/cache/" + Dname + "/" + fileName;
		if (flag == true)
			fileName = U.getCachePath() + Dname + "Quickkk" + "/"
					+ fileName;
		else {
			fileName = U.getCachePath()+ Dname + "/" + fileName;
		}

		File f = new File(fileName);
		if (f.exists())
			return html = FileUtil.readAllText(fileName);
		if (!f.exists()) {

			BufferedWriter writer = new BufferedWriter(new FileWriter(f));

			driver.get(url);
			
			((JavascriptExecutor) driver).executeScript(
					"window.scrollBy(0,3000)", ""); // y value '400' can be
			
			try {
				WebElement option = null;

				option = driver.findElement(By.id("cntQMI"));//--------//*[@id="cntQMI"]
				option.click();
				Thread.sleep(3000);
				option.click();
				Thread.sleep(3000);
				U.log("::::::::::::click succusfull1:::::::::");

			} catch (Exception e) {
				U.log("click unsuccusfull1" + e.toString());
			}
			
			U.log("Current URL:::" + driver.getCurrentUrl());
			html = driver.getPageSource();
			Thread.sleep(2 * 1000);

			writer.append(html);
			writer.close();

		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}

		return html;

	}
	
	public static String getHtmlWithChromeBrowser(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new ChromeDriver();

		String html = null;
		String Dname = null;

		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())

			folder.mkdirs();
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath() + Dname + "/" + fileName;

		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		// int respCode = CheckUrlForHTML(url);

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));/*
					driver.manage()
							.addCookie(
									new Cookie("visid_incap_612201",
											"gt5WFScsSRy46ozKP+BwUyrx4FcAAAAAQUIPAAAAAADA5A7HU2IYoId7VKl8vCPR"));*/
					driver.get(url);
					Thread.sleep(5000);
					((JavascriptExecutor) driver).executeScript(
							"window.scrollBy(0,400)", ""); // y value '400' can
					// be

					// WebElement click =
					// driver.findElement(By.xpath("//*[@id=\"reset-available-homes\"]"));
					// click.click();

					Thread.sleep(2000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(2000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}


	public static String getHtml(String url, WebDriver driver) throws Exception {
		// WebDriver driver = new FirefoxDriver();

		String html = null;
		String Dname = null;
//		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
//		"50.193.36.173",8080));
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;

		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
	
		String fileName = U.getCacheFileName(url);

		fileName = U.getCachePath()+ Dname + "/" + fileName;

//		final URLConnection urlConnection = url.openConnection();
//		
		File f = new File(fileName);
		if (f.exists()) {
			return html = FileUtil.readAllText(fileName);
			// U.log("Reading done");
		}

		

		// if(respCode==200)
		{

			if (!f.exists()) {
				synchronized (driver) {

					BufferedWriter writer = new BufferedWriter(
							new FileWriter(f));
				
					driver.get(url);
					//U.log("after::::"+url);
					Thread.sleep(10000);
					((JavascriptExecutor) driver).executeScript("window.scrollBy(0,400)", ""); 
					Thread.sleep(10000);
					U.log("Current URL:::" + driver.getCurrentUrl());
					html = driver.getPageSource();
					Thread.sleep(10000);
					writer.append(html);
					writer.close();

				}
			} else {
				if (f.exists()) {
					html = FileUtil.readAllText(fileName);
					U.log("Reading done");
				}
			}
			return html;
		}
		// else{
		// return null;
		// }
	}

	
	
	
	public static String getHtml(String url, WebDriver driver, String id)
			throws Exception {
		
		String html = null;
		String Dname = null;
		String host = new URL(url).getHost();
		host = host.replace("www.", "");
		int dot = host.indexOf("/");
		Dname = (dot != -1) ? host.substring(0, dot) : host;
		File folder = null;
		folder = new File(U.getCachePath() + Dname);
		if (!folder.exists())
			folder.mkdirs();
		String fileName = U.getCacheFileName(url);
		fileName = U.getCachePath() + Dname + "/" + fileName;
		File f = new File(fileName);
		if (f.exists())
			return html = FileUtil.readAllText(fileName);
		if (!f.exists()) {
			synchronized (driver) {
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(f));
				U.log("in gethtml==" + url);
				driver.get(url);
				Thread.sleep(5000);
				Actions dragger = new Actions(driver);
				WebElement draggablePartOfScrollbar = driver.findElement(By
						.id(id));
				int numberOfPixelsToDragTheScrollbarDown = 50;
				for (int i = 10; i < 500; i = i
						+ numberOfPixelsToDragTheScrollbarDown) {
					try {
						dragger.moveToElement(draggablePartOfScrollbar)
								.click()
								.moveByOffset(0,
										numberOfPixelsToDragTheScrollbarDown)
								.release().perform();
						Thread.sleep(1000L);
					} catch (Exception e1) {
					}
				}
				U.log("Current URL:::" + driver.getCurrentUrl());
				html = driver.getPageSource();
				writer.append(html);
				writer.close();
			}
		} else {
			if (f.exists())
				html = FileUtil.readAllText(fileName);
		}
		return html;

	}

	
	public static int CheckUrlForHTML(String path) {
		// TODO Auto-generated method stub
		int respCode = 0;
		try {

			DefaultHttpClient httpclient = new DefaultHttpClient();
			HttpPost request1 = new HttpPost(path);
			HttpResponse response1 = httpclient.execute(request1);
			respCode = response1.getStatusLine().getStatusCode();
		} catch (Exception ex) {

			U.log(ex);
			return respCode;
		}
		return respCode;
	}

	public static String getHTML(String path) throws IOException {
		path = path.replaceAll(" ", "%20");
		// Thread.sleep(4000);
		String fileName = getCache(path);
//		U.log("catche :: "+fileName);

//		try {
////			System.setProperty("https.protocols", "-Dhttps.protocols=TLSv1.1,TLSv1.2");
////			System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
////			System.setProperty("http.proxyHost", "proxy.com");
//
//		}catch(Exception e){
//			U.log(" eere "+e);
//		}
		
		try {
//			U.bypassCertificate();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//		deleteFile(fileName);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code
		
		
		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.193.36.173",8080));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.115 Safari/537.36");
			urlConnection.addRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
			urlConnection.addRequestProperty("Accept-Language",
					"en-GB,en-US;q=0.9,en;q=0.8");
			urlConnection.addRequestProperty("Cookie", "cookieid=7332269; _gcl_au=1.1.1151795056.1655710519; _ga=GA1.2.241193296.1655710520; _gid=GA1.2.71378811.1655710520; _fbp=fb.1.1655710523626.413152072; CFID=12118400; CFTOKEN=9fc5e196accb115e-3184991A-FBBF-B429-0471CDC6C9907DF2; BE_CLA3=p_id%3DPAJPL68PNAN4R4P448NL46448AAAAAAAAH%26bf%3De613c2b85f6668f476cc1e40c6c9d154%26bn%3D18%26bv%3D3.44%26s_expire%3D1655894536084%26s_id%3DPAJPL68PNAN4R86A82LL46448AAAAAAAAH; lastvisit={ts '2022-06-21 05:44:19'}");
//			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}
	public static String getHTML1(String path) throws IOException {

		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = getCache(path);
		deleteFile(fileName);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		int respCode = CheckUrlForHTML(path);
		 //U.log("respCode=" + respCode);
//		 if (respCode == 200) {

		// Proxy proxy = new Proxy(Proxy.Type.HTTP, new
		// InetSocketAddress("107.151.136.218",80 ));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
				"50.206.25.104",80));
		final URLConnection urlConnection = url.openConnection();
		// Mimic browser
		try {
			urlConnection
					.addRequestProperty("User-Agent",
							"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
			urlConnection.addRequestProperty("Accept", "text/css,*/*;q=0.1");
			urlConnection.addRequestProperty("Accept-Language",
					"en-us,en;q=0.5");
			urlConnection.addRequestProperty("Cache-Control", "max-age=0");
			urlConnection.addRequestProperty("Connection", "keep-alive");
			// U.log("getlink");
			final InputStream inputStream = urlConnection.getInputStream();

			html = IOUtils.toString(inputStream);
			// final String html = toString(inputStream);
			inputStream.close();

			if (!cacheFile.exists())
				FileUtil.writeAllText(fileName, html);

			return html;
		} catch (Exception e) {
			U.log("gethtml expection: "+e);

		}
		return html;
		/*
		 * } else { return null; }
		 */

	}


	private static HttpURLConnection getConn(String urlPath,
			HashMap<String, String> customHeaders) throws IOException {

		URL url = new URL(urlPath);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.addRequestProperty("User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
		conn.addRequestProperty("Accept",
				"text/css,application/xhtml+xml,application/xml,*/*;q=0.9");
		conn.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
		conn.addRequestProperty("Cache-Control", "max-age=0");
		conn.addRequestProperty("Connection", "keep-alive");

		if (customHeaders == null || !customHeaders.containsKey("Referer")) {
			conn.addRequestProperty("Referer", "http://" + url.getHost());
		}
		if (customHeaders == null || !customHeaders.containsKey("Host")) {
			conn.addRequestProperty("Host", url.getHost());
		}

		if (customHeaders != null) {
			for (String headerName : customHeaders.keySet()) {
				conn.addRequestProperty(headerName,
						customHeaders.get(headerName));
			}
		}

		return conn;
	}// getConn

	private static String toString(InputStream inputStream) throws IOException {

		BufferedReader in = new BufferedReader(new InputStreamReader(
				inputStream));
		String line;

		StringBuilder output = new StringBuilder();
		while ((line = in.readLine()) != null) {
			output.append(line).append("\n");
		}
		in.close();
		return output.toString();
	}

	// Original Parag's code
	public static String getHTML2(String path) {

		StringBuilder output = new StringBuilder();

		try {

			URL myUrl = new URL(path);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					myUrl.openStream()));

			String line;

			while ((line = in.readLine()) != null) {
				output.append(line).append("\n");
				// System.out.println(line);
			}
			// System.out.println(line);

			in.close();

		} catch (IOException ex) {
		} finally {
		}

		return output.toString();
	}

	public static boolean isEmpty(String o) {

		return (o == null || o.trim().length() == 0);
	}

	public static String getHtmlSection(String code, String From, String To) {

		String section = null;
		int start, end;
		start = code.indexOf(From);
		if (start != -1) {
			end = code.indexOf(To, start + From.length());
			if (start < end)
				section = code.substring(start, end);
		}
		return section;
	}
	public static String removeSectionValue(String code, String From, String To) {	
		String section = null;
		int start, end;
		start = code.indexOf(From);
		if (start != -1) {
			end = code.indexOf(To, start + From.length());
			if (start < end)	
				section= code.replace(code.substring(start + From.length(), end), "");		
				//U.log("%%%%%%%%%%%%%"+"Successfully Remove Section"+"%%%%%%%%%%%%%%%%%");		
			}else 
			{		
				section= code;		
				}		
		return section;	
		}
	
	//
	public static String getSectionValue(String code, String From, String To) {

		String section = null;
		int start, end;
		start = code.indexOf(From);
		// U.log(start);
		if (start != -1) {
			end = code.indexOf(To, start + From.length());
			if (start < end)
				section = code.substring(start + From.length(), end);

		}
		return section;

	}
	
	public static String getCachePath(){
		String Regex="Cache";
		String Filename=System.getProperty("user.home");
		//U.log(Filename+"filename");
		if(Filename.contains("/")){
			Regex="/Cache/";
		}
		else 
		{
			Regex="\\Cache\\";
		}
		Filename=Filename.concat(Regex);
		//U.log("filename :::"+Filename);
		if(!Filename.equals(Regex))
		{
			Regex=Regex.toLowerCase();
		}
		return Filename;
	}	

	public static String[] getValues(String code, String From, String To) {

		ArrayList<String> al = new ArrayList<String>();
		int n = 0;
		String value = null;
		while (n != -1) {
			int start = code.indexOf(From, n);

			if (start != -1) {
				int end = code.indexOf(To, start + From.length());

				try {
					if (end != -1 && start < end && end < code.length())
						value = code.substring(start + From.length(), end);
				} catch (StringIndexOutOfBoundsException ex) {
					n = end;
					continue;
				}

				al.add(value);
				n = end;
			} else
				break;
		}

		Object ia[] = al.toArray();
		String[] values = new String[ia.length];

		for (int i = 0; i < values.length; i++)
			values[i] = ia[i].toString();

		return values;

	}

	/*public static String[] getValues(String code, String begin, String From,
			String To) {

		ArrayList<String> al = new ArrayList<String>();
		int n = 0;
		n = code.indexOf(begin, n);
		String value = null;
		while (n != -1) {
			int start = code.indexOf(From, n);

			if (start != -1) {
				int end = code.indexOf(To, start + From.length());

				try {
					if (end != -1 && start < end && end < code.length())
						value = code.substring(start + From.length(), end);
				} catch (StringIndexOutOfBoundsException ex) {
					n = end;
					continue;
				}

				al.add(value);
				n = end;
			} else
				break;
		}

		Object ia[] = al.toArray();
		String[] values = new String[ia.length];

		for (int i = 0; i < values.length; i++)
			values[i] = ia[i].toString();

		return values;

	}*/

	public static String[] toArray(ArrayList<String> list) {

		Object ia[] = list.toArray();
		String[] strValues = new String[ia.length];
		for (int i = 0; i < strValues.length; i++)
			strValues[i] = ia[i].toString();
		return strValues;
	}

	public static void printFile(String[] lines, String fileName) {

		Writer output = null;

		try {
			output = new BufferedWriter(new FileWriter(fileName, true));
			for (int i = 0; i < lines.length; i++)
				output.write(lines[i] + "\n");

			output.close();

		} catch (IOException ex) {
		} finally {
		}

	}

	public static void printFile(ArrayList<String> list, String fileName) {

		Writer output = null;

		try {
			output = new BufferedWriter(new FileWriter(fileName, true));

			for (String item : list)
				output.write(item + "\n");

			output.close();

		} catch (IOException ex) {
		} finally {
		}

	}

	public static String degToDecConverter(String str) {

		double s1, s3, s4;
		double val;
		String s2;
		s1 = Integer.parseInt(str.substring(0, str.indexOf("&deg;")));
		s2 = str.substring(str.indexOf(";"));
		s3 = Integer.parseInt(s2.substring(2, s2.indexOf("'")));
		s4 = Integer
				.parseInt(str.substring(str.length() - 3, str.indexOf("\"")));

		val = s1 + (s3 / 60) + (s4 / 3600);
		return Double.toString(val);
	}

	public static String[] getAddressFromLines(String[] lines) {

		final String BLANK = "-";
		String street = BLANK, city = BLANK, state = BLANK, zip = BLANK;
		String addStreet = "-";
		int len = lines.length;
		if (len >= 1) {
			for (int i = 0; i <= (len - 2); i++)
				addStreet = lines[i] + ",";
			street = addStreet;
			if (lines[len - 1].indexOf(",") != -1) {
				city = lines[len - 1].split(",")[0];
				String add = lines[len - 1].split(",")[1];
				add = add.trim();
				state = add.substring(0, 2).toUpperCase();
				zip = Util.match(add, "\\d{5}?", 0);
				if (zip == null)
					zip = BLANK;
			}

		}
		String[] add = { street, city, state, zip };
		return add;
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static int[] getMaxAndMin(int[] a) {

		int Max = a[0], Min = a[0];
		for (int i = 0; i < a.length; i++) {
			if (a[i] > Max)
				Max = a[i];
			else if (a[i] < Min) {
				Min = a[i];
			}
		}
		int[] arr = new int[2];
		arr[0] = Max;
		arr[1] = Min;
		return arr;
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */

	private static int[] getIntMaxMin(String code, String regExp, int group) {

		ArrayList<String> list = Util.matchAll(code, regExp, group);
		ArrayList<Integer> intList = new ArrayList<Integer>();
		int val;
		boolean isPrice = false;
		for (int i = 0; i < list.size(); i++) {
			isPrice = list.get(i).contains("$");
			String str = list.get(i).replaceAll(",|\\$", "");
			ArrayList<String> intTemp = Util.matchAll(str, "\\d{3,}", 0);
			for (String item : intTemp) {

				val = Integer.valueOf(item);
				if (isPrice && val > 20000)
					intList.add(val);
				if (!isPrice && val > 0)
					intList.add(val);

			}
		}

		int[] intVal = new int[intList.size()];
		for (int i = 0; i < intList.size(); i++) {
			intVal[i] = intList.get(i);
			// /U.log(intList.get(i))
			;
		}
		if (intVal.length != 0) {
			intVal = U.getMaxAndMin(intVal);
			if (intVal[1] == 0 && intVal[0] != 0)
				return new int[] { intVal[0], intVal[1] };
			return new int[] { intVal[1], intVal[0] };
		}
		return new int[] { 0, 0 };
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static String[] getPrices(String code, String regExp, int group) {

		int[] values = getIntMaxMin(code, regExp, group);
		// U.log(values[0]+ "  "+ values[1]);
		String minPrice = NumberFormat.getCurrencyInstance(Locale.US)
				.format(values[0]).replaceAll("\\.00", "");
		String maxPrice = NumberFormat.getCurrencyInstance(Locale.US)
				.format(values[1]).replaceAll("\\.00", "");
		// U.log(minPrice+ "  "+ maxPrice);
		minPrice = (values[0] > 20000) ? minPrice : null;
		maxPrice = (values[1] > 20000) ? maxPrice : null;
		if (maxPrice != null) {
			if (maxPrice.equals(minPrice))
				maxPrice = null;
		}
		if (minPrice == null && maxPrice != null) {
			minPrice = maxPrice;
			maxPrice = null;
		}

		return new String[] { minPrice, maxPrice };
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static String getHTML(String path, String baseUrl)
			throws IOException {

		if (baseUrl != null && !path.startsWith(baseUrl))
			return getHTML(baseUrl + path);
		else
			return getHTML(path);
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static String[] getSqareFeet(String code, String regExp, int group) {

		int[] values = getIntMaxMin(code, regExp, group);
		String minSqf = (values[0] != 0) ? "" + values[0] : null;
		String maxSqf = (values[1] != 0) ? "" + values[1] : null;

		if (maxSqf != null) {
			if (maxSqf.equals(minSqf))
				maxSqf = null;
		}

		return new String[] { minSqf, maxSqf };
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static String getPropertyTypes(String code, String regExp, int group) {

		ArrayList<String> list = Util.matchAll(code, regExp, group);
		ArrayList<String> temp = new ArrayList<String>();
		StringBuilder type = null;

		if (list.size() != 0) {
			for (String item : list) {
				item = item.trim();
				if (item.equals("�") || item.length() == 0)
					continue;
				if (!temp.contains(item)) {
					temp.add(item);
					if (type == null) {
						type = new StringBuilder();
						type.append(item);
					} else
						type.append("," + item);
				}
			}

		}

		if (type == null) {
			type = new StringBuilder();
		} else if (type.length() > 50) {
			String pType = type.toString();
			pType = pType.substring(0, 51);
			pType = Util.match(pType, "(.*?,)+", 0);
			pType = pType.substring(0, pType.length() - 1);
			type = new StringBuilder(pType);
		}
		return type.toString();
	}// /

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static String[] getGooleLatLong(String html) {

		String reg = "\\{center:\\{lat:(\\d+\\.\\d+),lng:(-\\d+\\.\\d+)";
		String reg2 = "<title>\\s*(\\d+\\.\\d+),\\s*(-\\d+\\.\\d+)";
		String match = Util.match(html, reg, 0);
		reg = (match == null) ? reg2 : reg;
		String lat = Util.match(html, reg, 1);
		String lng = Util.match(html, reg, 2);
		return new String[] { lat, lng };
	}

	public static String[] getGlatlng(String[] add) throws Exception {
		// String addr = add[0] + "+" + add[1];
		String addr = add[0] + "+" + add[1] + "+" + add[2] + "+" + add[3];
		String data = null;
		String latLong = null;
		StringBuffer input = new StringBuffer();
		String link = "https://maps.google.com/maps?daddr="
				+ URLEncoder.encode(addr, "UTF-8");

		URL url = new URL(link);

		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		BufferedReader br = new BufferedReader(new InputStreamReader(
				connection.getInputStream()));

		while ((data = br.readLine()) != null) {
			input.append(data);
		}

		String path = "E:\\google.txt";
		File file = new File(path);
		FileWriter wr = new FileWriter(file);
		wr.write(input.toString());
		int x = input.indexOf("{lat:");
		int y = input.indexOf("}", x);
		U.log("X:" + x);
		U.log("Y:" + y);

		latLong = input.substring(x, y);

		latLong = latLong.replace("{lat:", "");
		latLong = latLong.replace("lng:", "");

		String[] array = latLong.split(",");
		return array;
	}

	public static String[] getGooleLatLong(String[] add) throws IOException {

		String addr = add[0] + "+" + add[1] + "+" + add[2] + "+" + add[3];
		addr = "https://maps.google.com/maps?daddr="
				+ URLEncoder.encode(addr, "UTF-8");
		U.log(addr);
		String html = U.getHTML(addr);
		return U.getGooleLatLong(html);
	}

	public static String[] getAddress(String line) {
		String[] ad = line.split(",");

		String[] add = new String[] { "-", "-", "-", "-" };
		int n = ad.length;
		//U.log("ad length is ::"+ad.length);
		if (ad.length >= 3) {
			for (int i = 0; i < n - 2; i++)
				add[0] = (i == 0) ? ad[i].trim() : add[0] + ", " + ad[i].trim();
			add[0] = add[0].trim().replaceAll("\\d+.\\d+\\s*,\\s*-\\d+.\\d+",
					"");
			add[1] = ad[n - 2].trim();// city
			add[2] = Util.match(ad[n - 1], "\\w+", 0); // State--or-->\\w+ OR
														// [a-z\\sa-z]+
			add[2] = (add[2] == null) ? "-" : add[2].toUpperCase();
			if (add[2] == null)
				add[2] = "-";
			if (add[2].length() > 2)
				add[2] = USStates.abbr(add[2]);
			add[3] = Util.match(ad[n - 1], "\\d{5}", 0);
			if (add[3] == null)
				add[3] = "-";
		}
		for (int i = 0; i < 1; i++) {
			if (!add[i].equals("-") && add[i].length() < 3)
				add[i] = "-";
		}

		return add;
	}

	public static String[] getMapQuestAddress(String html) {

		String section = U
				.getSectionValue(html, "singleLineAddress\":\"", "\"");
		String[] add = null;
		if (section != null)
			add = U.getAddress(section);
		return add;
	}

	public static String[] getMapQuestLatLong(String html) {

		String lat = null, lng = null;
		String reg = "\"latLng\":\\{\"lng\":(-\\d+.\\d+),\"lat\":(\\d+.\\d+)";
		String reg2 = "\"latLng\":\\{\"lat\":(\\d+.\\d+),\"lng\":(-\\d+.\\d+)";
		String match = Util.match(html, reg, 0);
		if (match == null) {
			lat = Util.match(html, reg2, 1);
			lng = Util.match(html, reg2, 2);
		} else {
			lat = Util.match(html, reg, 2);
			lng = Util.match(html, reg, 1);
		}
		return new String[] { lat, lng };
	}

	public static String[] findAddress(String code) {

		String[] add = null;
		String sec = formatAddress(code);
		//U.log("sec::::"+sec);
		String regAddress = "\\d*\\s*\\w+[^,\n]+[,\n]+\\s*\\w+[\\s,]+\\w+.*?\\d{5}";
		String reg2 = "\\d+\\s*\\w+[^,\n]+[,\n]+\\s*\\w+[^,]+,\\s*\\w+\\s*\\d{5}";
		String reg4 = "\\s*\\w+[^,\n]+[,\n]+\\s*\\w+[^,]+,\\s*\\w+\\s*\\d{5}";
		String reg3 = "\\d+[^,]+,( ?\\w+){1,5},( ?\\w+)( \\d{5})?";
		String match = Util.match(sec, regAddress, 0);

		if (match == null)
			match = Util.match(sec, reg2, 0);
		if (match == null)
			match = Util.match(sec, reg3, 0);
		if (match != null)
			add = U.getAddress(match);
		if (match != null)
			match = Util.match(sec, reg4, 0);

		return add;
	}

	public static String[] getGoogleAdd(String lat, String lon)
			throws Exception {
		String glink = "https://maps.google.com/maps?q=" + lat + "," + lon;
		U.log("Visiting :" + glink);
		// WebDriver driver=new FirefoxDriver();
		// driver.get(glink);
		String htm = U.getHTML(glink);
		U.log(U.getCache(glink));
		return U.getGoogleAddress(htm);
	}

	public static String formatAddress(String code) {

		String sec = code.replaceAll("\\&nbsp;|�|&#038;|�", " ");
		sec = sec.replaceAll(" {2,}", " ");

		sec = sec.replaceAll("\\s{2,}", "");

		sec = sec.replaceAll(
				"<br>|<br[^>]+>|</p><p[^>]+>|</p>|</br>|<BR>|<BR />|<br />",
				",");

		sec = sec.replaceAll("<[^>]+>", "");

		sec = sec.replaceFirst("[^>]+>", "");
	//	 U.log("sec:"+sec);
		//Priti-----
		 
		if (sec.contains("Ave") && !sec.contains("Ave,") && !sec.contains("Avenue") && !sec.contains("Avenue,"))
			sec = sec.replace("Ave", "Ave,");
		if (sec.contains("Rd") && !sec.contains("Rd,") && !sec.contains("Rd."))
			sec = sec.replace("Rd", "Rd,");
		
		//-----------------------
		if (sec.contains("Dr.") && !sec.contains("Dr.,"))
			sec = sec.replace("Dr.", "Dr.,");
		if (sec.contains("Drive") && !sec.contains("Drive,"))
			sec = sec.replace("Drive", "Drive,");
		if (sec.contains("Trail") && !sec.contains("Trail,") && !sec.contains("Trails"))
			sec = sec.replace("Trail", "Trail,");
		if (sec.contains("Street") && !sec.contains("Street,") && !sec.contains("Street &"))
			sec = sec.replace("Street", "Street,");
		if (sec.contains("Blvd.") && !sec.contains("Blvd.,"))
			sec = sec.replace("Blvd.", "Blvd.,");
		if (sec.contains("Avenue") && !sec.contains("Avenue,"))
			sec = sec.replace("Avenue", "Avenue,");
		if (sec.contains("Road") && !sec.contains("Road,") && !sec.contains("Roads,"))
			sec = sec.replace("Road", "Road,");
		if (sec.contains("Ct") && !sec.contains("Ct,")
				&& !sec.contains("Ct. #"))
			sec = sec.replace("Ct", "Ct,");
		if (!sec.contains("Lane <") && sec.contains("Lane")
				&& !sec.contains("Lane,"))
			sec = sec.replace("Lane", "Lane,");
		if (sec.contains("land Court") && !sec.contains("land Court.,"))
			sec = sec.replace("land Court", "land Court,");
		if (sec.contains(", St.") && !sec.contains(", St.,"))
			sec = sec.replace(", St.", " St.,");
		return sec;
	}

	public static String[] getGoogleAddress(String html) throws IOException {

		String section = U.getSectionValue(html, "addr:'", "'");
		U.log("U section==" + section);
		String[] add = null;
		if (section != null) {
			add = U.getAddress(section.replaceAll("\\\\x26", "&"));
		}
		return add;
	}

	/**
	 * @author Parag Humane
	 * @param args
	 */
	public static String getPageSource(String url) throws IOException {

		String html = null;
		String fileName = U.getCache(url);
		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		WebDriver driver = new HtmlUnitDriver();

		driver.get(url);
		html = driver.getPageSource();
		if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, html);
		return html;
	}// //
	
	
	
	public static int countMatch(String reg, String text) {

		Matcher m = Pattern.compile(reg).matcher(text);
		int n = 0;
		while (m.find())
			n++;
		return n;
	}// //

	public static ArrayList<String> removeDuplicates(ArrayList<String> list) {

		HashSet<String> hs = new HashSet<String>();
		hs.addAll(list);
		list.clear();
		list.addAll(hs);
		hs = null;
		return list;
	}// ///
	public static void bypassCertificate() throws Exception {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
					throws java.security.cert.CertificateException {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
					throws java.security.cert.CertificateException {
				// TODO Auto-generated method stub
				
			}

			
		} };

		// Install the all-trusting trust manager
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};

		// Install the all-trusting host verifier
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}
	//========================================================written new code by Upendra===================================================
	static String propTypeIgnore = "[v|V]illage|[L|l]uxurious [O|o]wner(.*?)s [b|B]athroom";
	public static String getNewPropType(String html) throws Exception {
			html=getNoHtml(html);
			html = html.replaceAll("&nbsp;", " ").toLowerCase().replaceAll(propTypeIgnore.toLowerCase(), "");
			BufferedReader bufReader = new BufferedReader(new FileReader("resources/propTypes.txt"));
			String match, list = "";
			String line=bufReader.readLine();
			while (line!=null) {
				if(line.contains("\"\""))throw new Exception("Check Property File in line "+line);
				line=line.replaceAll("\"\\s*,\\s*\"", "\",\"");
				String[] proeV=line.split("\",\"");
				//log("hello:->"+proeV[0]);
				match = Util.match(html, proeV[0].replace("\"",""), 0);
				if (match != null) {
					proeV[1]=proeV[1].replace("\"", "");
		//			U.log("match::" + match);
					if (!list.contains(proeV[1])) {
						list = (list.length() == 0) ? proeV[1] : list + ", " + proeV[1];
					}
				}
				line=bufReader.readLine();
			}
			
			list = (list.length() < 4) ? "-" : list;
			bufReader.close();
			return list;
		}
		//========================================================written new code by Upendra===================================================
		private static final String dpropTypeIgnore="branch";
		public static String getNewdCommType(String html) throws Exception {
			BufferedReader bufReader = new BufferedReader(new FileReader("resources/dcommTypes.txt"));

			String match, dType = "";
			String line=bufReader.readLine();
			while (line!=null) {
				if(line.contains("\"\""))throw new Exception("Check DProperty File in line "+line);
				line=line.replaceAll("\"\\s*,\\s*\"", "\",\"");
				String[] proeV=line.split("\",\"");
				html=getNoHtml(html);
				html = html.replaceAll("&nbsp;", " ").toLowerCase().replaceAll(dpropTypeIgnore.toLowerCase(), "");
				match = Util.match(html, proeV[0].replace("\"","").trim(), 0);
				if (match != null) {
					proeV[1]=proeV[1].replace("\"", "");
					U.log("match::" + match);
					if (!dType.contains(proeV[1])) {
						dType = (dType.length() == 0) ? proeV[1] : dType + ", " + proeV[1];
					}
				}
				line=bufReader.readLine();
			}
			dType = (dType.length() < 4) ? "-" : dType;
			bufReader.close();
			return dType;
		}
		//========================================================written new code by Upendra===================================================
		public static String getNewPropStatus(String html) throws Exception {
			BufferedReader bufReader = new BufferedReader(new FileReader("resources/propStatus.txt"));
			html=getNoHtml(html);
			html = html.replaceAll(" {2,} ", "");
			html = html.replaceAll("&nbsp;", " ").toLowerCase().replaceAll(propStatusIgnore.toLowerCase(), "");
			// U.log("propstatushtml--------------------------------------"+html);
			String status = "-", match;
			String pStatus = "-";
			String line = bufReader.readLine();
			//log(line);
			while (line != null) {
				line=line.replace("\"","");
				if(line.contains("\"\""))throw new Exception("Check Property status File  in line "+line);
				match = Util.match(html, line, 0);
				if (match != null) {
					U.log("match :" + match);
					U.log("item :" + line);
					html = html.toUpperCase().replace(line.toUpperCase(), "");
					status = U.getCapitalise(match.toLowerCase());
					if (pStatus.equals("-"))
						pStatus = status;
					else
						pStatus = pStatus + ", " + status;
				}
				line = bufReader.readLine();
				
			}
			bufReader.close();
			return pStatus;
		}

	public static String getPropType(String html) {
		HashSet<String> type = new HashSet<String>();
		String match, list = "", value;
		Iterator<?> i = propTypes.entrySet().iterator();
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			value = me.getValue().toString();
			html = html.replaceAll("Cabinet|cabinet", "");
			match = Util.match(html, me.getKey().toString(), 0);
			if (match != null) {
				U.log("match::"+match+" value :: "+value);
				if (!list.contains(value)) {
					list = (list.length() == 0) ? value : list + ", " + value;
				}
			}
		}
		list = (list.length() < 4) ? "-" : list;
		return list;
	}

	public static String getPropStatus(String html) {
		html = html.replaceAll(" {2,} ", "");
		html = html.replaceAll("&nbsp;", " ").toLowerCase()
				.replaceAll(propStatusIgnore.toLowerCase(), "");
		// U.log("propstatushtml--------------------------------------"+html);
		String status = "-", match;
		String pStatus = "-";
		for (String item : propStatus) {
			// U.log(html);
			match = Util.match(html, item, 0);

			if (match != null) {
				 U.log("match::"+match);
				// U.log("::kirti");
				html = html.toUpperCase().replace(item.toUpperCase(), "");
				// U.log(html);
				U.log("item :" + item);
				status = U.getCapitalise(match.toLowerCase());
				if (pStatus.equals("-"))
					pStatus = status;
				else
					pStatus = pStatus + ", " + status;
			}

		}
		return pStatus;
	}

	public static String getCommType(String html) {

		return U.getCommunityType(html);
	}

	public static String getdCommType(String html) {

		HashSet<String> type = new HashSet<String>();
		String match, list = "", value;
		Iterator<?> i = dcommTypes.entrySet().iterator();
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			value = me.getValue().toString();
			match = Util.match(html, me.getKey().toString(), 0);
			if (match != null) {
				U.log(value+"::::::::"+match);
				if (!list.equals(value)) {
//				if (!list.contains(value)) {
					list = (list.length() == 0) ? value : list + ", " + value;
				}
			}
		}
		//U.log("list : " + list);
		list = (list.length() < 4) ? "-" : list;
		return list;
	}

	public static String getCommunityType(String html) {

		HashSet<String> type = new HashSet<String>();
		String match, list = "", value;
		Iterator<?> i = communityType.entrySet().iterator();
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			value = me.getValue().toString();
			
			match = Util.match(html, me.getKey().toString(), 0);
			if (match != null) {
				U.log("match:::"+match);
				if (!list.contains(value)) {
					list = (list.length() == 0) ? value : list + ", " + value;
				}
			}
		}
		list = (list.length() < 4) ? "-" : list;
		return list;
	}

	public static String removeComments(String html) {
		String[] values = U.getValues(html, "<!--", "-->");
		for (String item : values)
			html = html.replace(item, "");
		return html;

	}

	public static boolean isvalideLatLng1(String add[], String lat, String lng)
			throws Exception {

		// FirefoxDriver driver2;
		if (lat != "" || lat == null) {
			String link = "https://maps.google.com/maps?q=" + lat + "," + lng;
			String htm = U.getHTML(link);
			String gAdd[] = U.getGoogleAddress(htm);
			U.log(gAdd[0] + " " + gAdd[1] + " " + gAdd[2] + " " + gAdd[3]);
			if (gAdd[3].equals(add[3]))
				return true;
			else if (gAdd[1].equalsIgnoreCase(add[1])
					&& gAdd[2].equalsIgnoreCase(add[2])) {
				return true;
			}

			else {
				// http://maps.yahoo.com/place/?lat=37.71915&lon=-121.845803&q=37.71915%2C-121.845803
				link = "http://maps.yahoo.com/place/?lat=" + lat + "&lon="
						+ lng + "&q=" + lat + "," + lng;

				driver = ShatamFirefox.getInstance();

				driver.open(link);
				driver.getOne("#yucs-sprop_button").click();
				htm = driver.getHtml();

				// driver2 = new FirefoxDriver();
				// driver2.
				String url = driver.getUrl();
				U.log(url);

				URLDecoder decode = new URLDecoder();
				try {
					url = URLDecoder.decode(url, "UTF-8");
					U.log("Address:" + url);
					U.log(add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
					if (url.contains(add[1]))
						return true;
					if (url.contains(add[3]))
						return true;
				} catch (UnsupportedEncodingException ex) {
					ex.printStackTrace();
				}
				// decode.decode(url);
				// U.log(url);
				// driver.close();
			}
			return false;
			// if(gAdd[1])
		}
		return false;
	}

	public static String[] getLatLngBingMap(String add[]) throws Exception {

		String addr = add[0] + " " + add[1] + " " + add[2] + " " + add[3];
		ShatamFirefox driver1 = null;
		String bingLatLng[] = { "", "" };
		driver1 = ShatamFirefox.getInstance();
		driver1.open("http://localhost/bing.html");
		driver1.wait("#txtWhere");
		driver1.getOne("#txtWhere").sendKeys(addr);
		driver1.wait("#btn");
		driver1.getOne("#btn").click();
		String binghtml = driver1.getHtml();
		// driver.wait(1000);
		U.log(binghtml);
		String secmap = U.getSectionValue(binghtml, "<div id=\"resultsDiv\"",
				"</body>");
		bingLatLng[0] = U.getSectionValue(secmap,
				"<span id=\"span1\">Latitude:", "<br>").trim();
		bingLatLng[1] = U.getSectionValue(secmap, "<br>Longitude:", "</span>");

		U.log("lat:" + bingLatLng[0]);
		U.log("lng:" + bingLatLng[1]);
		return bingLatLng;
	}

	public static String[] getBingAddress(String lat, String lon)
			throws Exception {
		String[] addr = null;
		String htm = U
				.getHTML("http://dev.virtualearth.net/REST/v1/Locations/"
						+ lat
						+ ","
						+ lon
						+ "?o=json&jsonp=GeocodeCallback&key=Anqg-XzYo-sBPlzOWFHIcjC3F8s17P_O7L4RrevsHVg4fJk6g_eEmUBphtSn4ySg");
		String[] adds = U.getValues(htm, "formattedAddress\":\"", "\"");
		for (String item : adds) {
			addr = U.getAddress(item);
			if (addr == null || addr[0] == "-")
				continue;
			else {
				U.log("Bing Address =>  Street:" + addr[0] + " City :"
						+ addr[1] + " state :" + addr[2] + " ZIP :" + addr[3]);
				return addr;
			}

		}
		return addr;
	}

	public static String[] getBingLatLong(String[] address) throws Exception {
		String[] latLong = { null, null };
		if (address == null || address[0] == "-" || address[1] == "-"
				|| address[2] == "-")
			return latLong;
		else {
			String line = address[0] + "," + address[1] + "," + address[2]
					+ " " + address[3];
			try {
				latLong = getBingLatLong(line);
			} catch (java.io.IOException ex) {
				return latLong;
			}
		}
		return latLong;
	}

	public static String[] getBingLatLong(String addressLine) throws Exception {
		String[] latLong = new String[2];
		if (addressLine == null || addressLine.trim().length() == 0)
			return null;
		addressLine = addressLine.trim().replaceAll("\\+", " ");
		String geocodeRequest = "http://dev.virtualearth.net/REST/v1/Locations/'"
				+ addressLine
				+ "'?o=xml&key=Anqg-XzYo-sBPlzOWFHIcjC3F8s17P_O7L4RrevsHVg4fJk6g_eEmUBphtSn4ySg";
		// U.log("-----------------addressline-----------"+geocodeRequest);
		String xml = U.getHTML(geocodeRequest);
		// U.log("--------------------------xml---------------------------------"+xml);
		latLong[0] = U.getSectionValue(xml, "<Latitude>", "</Latitude>");
		latLong[1] = U.getSectionValue(xml, "<Longitude>", "</Longitude>");
		return latLong;
	}

	public static boolean isMatchedLocation(String[] add, String[] addr) {
		boolean isMatched = false;
		for (int i = 0; i < 3; i++) {
			if (add[i] == null || addr[i] == null || add[i].equals("-")
					|| addr[i].equals("-"))
				return isMatched;
		}

		if (addr[3].equals(add[3]))
			isMatched = true;
		else {
			if (addr[1].equalsIgnoreCase(add[1])
					&& addr[2].equalsIgnoreCase(add[2]))
				isMatched = true;
			else {
				if (addr[2].equalsIgnoreCase(add[2])
						&& add[3].substring(0, 3).equals(
								addr[3].substring(0, 3)))
					isMatched = true;
			}
		}
		return isMatched;
	}

	public static boolean isValidLatLong(String[] latLon, String[] add)
			throws Exception {
		boolean isValid = false;
		if (latLon == null || latLon[1] == null || add == null)
			return isValid;

		U.log("lat :" + latLon[0] + " Long :" + latLon[1]);

		if (latLon[0] == "-" || latLon[1] == "-" || add[3] == "-"
				|| add[1] == "-" || add[2] == "-")
			return isValid;

		boolean isMatched = false;
		String[] addr = null;
		addr = U.getBingAddress(latLon[0], latLon[1]);
		if (addr != null) {
			isMatched = isMatchedLocation(add, addr);
			if (isMatched)
				return true;
		}
		addr = U.getGoogleAdd(latLon[0], latLon[1]);
		isMatched = isMatchedLocation(add, addr);
		if (isMatched)
			return true;

		return isValid;
	}

	public static String getCapitalise(String line) {
		line = line.trim().replaceAll("\\s+", " ");
		String[] words = line.trim().split(" ");
		String capital = null, wd;
		for (String word : words) {
			wd = word.substring(0, 1).toUpperCase() + word.substring(1);
			capital = (capital == null) ? wd : capital + " " + wd;
		}
		return capital;
	}

	public static String[] getBuilderList() {
		String path = "C://cache//builderlist.txt";
		int nline = 212;
		String[] textData = new String[nline];
		try {
			FileReader fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			for (int i = 0; i < nline; i++) {
				textData[i] = br.readLine();
				// U.log(textData[i]);
			}
			br.close();
		} catch (Exception e) {
		}
		return textData;
	}

	public static String[] getAddressFromSec(String address, String skipLines) {

		String[] OUT = { "-", "-", "-", "-" };
		if (address != null) {
			String[] ADD = U.getZipStateCity(address);
			OUT[1] = ADD[0];
			OUT[2] = ADD[1];
			OUT[3] = ADD[2];
			String street = "-";
			// String ignore_ADD=;
			//U.log("ADD[0]::" + ADD[0]);
			if (ADD[0] != null || ADD[1] != null) {
				//U.log("ADDRESS :    " + address);
				int streetSec = -1;
				String[] addSections = U.getValues(address, ">", "<");
				int counter = 0;
				if (addSections.length > 0) {
					for (String secLoc : addSections) {
						//U.log("***&  " + secLoc);
						if (secLoc.contains("Rd") || !secLoc.contains("Draper")
								&& secLoc.contains("Dr")
								|| secLoc.contains("Blvd")
								|| secLoc.contains("Boulevard")) {
							counter++;
							//U.log("***&  secLoc 1");
							continue;
						}
						String chkSec = Util.match(secLoc, ADD[1]);
						if (chkSec != null) {
							streetSec = counter;
							break;
						}
						//U.log("ADD[0]::" + ADD[0]);
						if (ADD[0] != null)
							chkSec = Util.match(secLoc, ADD[0]);
						if (chkSec != null) {
							streetSec = counter;
							break;
						}
						counter++;
					}
				}

				//U.log("@@@  " + streetSec);

				if (streetSec == 0)
					street = addSections[0];
				if (streetSec == 1)
					street = addSections[0];
				if (streetSec == 2) {
					String find = Util.match(addSections[0] + addSections[1],
							skipLines);
					if (find != null) {
						if (!addSections[0].contains(find))
							street = addSections[0];
						if (!addSections[1].contains(find))
							street = addSections[1];
					} else // if(find==null)
					{
						street = addSections[0] + ", " + addSections[1];
					}
				}
			}
			OUT[0] = street;
		}
		return OUT;
	}

	public static String[] getZipStateCity(String addSec) { // getZipStateCity
		String[] ZSC = { "-", "-", "-" };

		String state = getState(addSec);
		//U.log("state==" + state);
		String zip = getZip(addSec, state);
		//U.log("%%%%%  :" + zip);
		if (zip != "-") {
			String ST = Util.match(zip, "\\w+");
			if (ST != "-") {
				String check = Util.match(state, ST);
				if (check == null) {
					zip = Util.match(zip, "\\w+\\W+(\\d{4,5})", 1);
					//U.log("*********" + zip);
					String Real = "\\w+\\W+" + zip;
					//U.log("Real*********" + Real);
					String stateReal = Util.match(addSec, Real);
					if (stateReal != null) {
						if (stateReal.contains("Hampshire")
								|| stateReal.contains("Jersey")
								|| stateReal.contains("Mexico")
								|| stateReal.contains("York")
								|| stateReal.contains("Carolina")
								|| stateReal.contains("Dakota")
								|| stateReal.contains("Island")
								|| stateReal.contains("Virginia")) {
							Real = "\\w+\\s\\w+\\W+" + zip;
							stateReal = Util.match(addSec, Real);
							state = Util.match(stateReal, "\\w+\\s\\w+");
							
						} else {
							state = Util.match(stateReal, "\\w+");
							
						}
					}
				}
			}
		}
		ZSC[1] = state;
		ZSC[2] = Util.match(zip, "\\d{4,5}");
		if (ZSC[2] == null)
			ZSC[2] = "-";
		String city = getCity(addSec, state);
		//U.log("********************@*" + city);
		String chkCity = city + "(.*?)<"; // \\s\\w{2}
		chkCity = Util.match(addSec, chkCity);
		if (chkCity != null) {
			String chkCity2 = chkCity.replace(city, "");
			if (chkCity2.contains("Rd") || chkCity2.contains("Dr")
					|| chkCity2.contains("Blvd")
					|| chkCity2.contains("Boulevard")
					|| chkCity2.contains("Park")) {
				String LOCaddSec = addSec.replace(chkCity, "");
				String LOCcity = getCity(LOCaddSec, state);
				U.log("POP**  :" + LOCcity);
				if (LOCcity.trim() != null && LOCcity.trim().length() > 3)
					city = LOCcity;
			}
		}
		ZSC[0] = city;
		//U.log(ZSC[0]+"::::::::::city");
		return ZSC;
	}

	private static String getState(String addSec) { // getZipStateCity
		
		String ignoreStreet = "1350 N New York St";
		addSec = addSec.replace(ignoreStreet, "");

		String state = Util
				.match(addSec,
						"Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|West Virginia|Virginia|Washington|Wisconsin|Wyoming");

		String[] sameName = { "Washington", "Maine", "Delaware", "Missouri",
				"Virginia", "Nevada", "Iowa", "Colorado" };
		//U.log("my state::"+state);
		if (state != null) {
			for (String same : sameName) {
				if (state.contains(same)) {
					addSec = addSec.replaceAll(same, "##@@");
					String LOLstate = getState(addSec);
					//U.log("LOLstate : " + LOLstate);
					if (LOLstate == null || LOLstate.length() < 3)
						state = same;
					else
						state = LOLstate;
					addSec = addSec.replace("##@@", same);
				}
			}
		}
		if (state == null) {
			state = Util.match(addSec, " [A-Z]{2} ");
		}
		if (state == null) {
			state = Util
					.match(addSec,
							"Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|West Virginia|Virginia|Washington|Wisconsin|Wyoming");
			if (state != null)
				return state;
		}

		if (state == null)
			state = "-";
		return state;
	}

	private static String getZip(String addSec, String state) { // getZipStateCity
		String match = state + "\\W+\\d{5}";
		String zip = Util.match(addSec, match);
		if (zip == null) {
			match = state + "\\W+\\d{4,5}";
			zip = Util.match(addSec, match);
		}
		if (zip == null) {
			zip = Util.match(addSec, "\\W+\\d{5}");
		}
		if (zip == null)
			zip = "-";
		return zip;
	}

	public static String getCity(String addSec, String state) { // getZipStateCity
		U.log("*#*  :" + state +": *#*");
		if (state.length() > 2)
			state = USStates.abbr(state.trim());
		U.log(state);
		// addSec=addSec.replace("766 Austin Lane", "");
		String ingoreStreet = "2820 Bellevue Way NE|2303 San Marcos|Santa Rosa Villas|8541 N. Walnut Way|208 S. Auburn Heights Lane|2228 Tracy Place|3200 Osprey Lane|Kannapolis Parkway|1350 N New York St|8500 N. Fallbrook Avenue|Woodruff Road|Hopewell Road|Old Spartanburg Road|Zebulon Road|Kailua Road|Evans Mill Road|Arnold Overlook Lane|Wellington Woods Avenue|11405 Pacey's Pond Circle|405 San Luis Obispo St|4307 Walnut Avenue|12422 Mar Vista Street";
		addSec=addSec.replaceAll(ingoreStreet, "");
		String city = "-";
		if (state.trim().contains("Alabama") || state.contains("AL")) {
			city = Util
					.match(addSec,
							"Hunstville|Montevallo|Magnolia Springs|Orange Beach|Auburn|Alabaster|Albertville|Alexander City|Anniston|Athens|Atmore|Banks|Bessemer|Birmingham|Brewton|Center Point|Cottonton|Cullman|Daleville|Daphne|Decatur|Dothan|Enterprise|Eufaula|Fairfield|Fairhope|Florence|Foley|Forestdale|Fort Payne|Gadsden|Gardendale|Grove Hill|Hartselle|Helena|Homewood|Hoover|Hueytown|Huntsville|Jackson|Jasper|Kimberly|Leeds|Lisman|Lowndesboro|McCalla|Madison|Millbrook|Mobile|Monroeville|Montgomery|Mountain Brook|Muscle Shoals|Northport|Opelika|Oxford|Ozark|Pelham|Phenix City|Prattville|Prichard|Repton|Robertsdale|Saks|Saraland|Scottsboro|Selma|Sheffield|Slocomb|Smiths|Sylacauga|Talladega|Tallassee|Theodore|Tillmans Corner|Toney|Troy|Trussville|Tuscaloosa|Tuskegee|Vestavia([,\\W])?Hills|Warrior|Calera|Pinson|Chelsea|Springville|Moody|Fultondale|Odenville|Liberty Park Area|VestaviaHills|Hazel Green|Meridianville|Owens Cross Roads|Spanish Fort|Loxley|Semmes|Gulf Shores|Summerdale|Deatsville|Wetumpka|Vance|Moundville|Vestavia-Hills|Fulton|Harvest|Margaret");
		}
		if (state.contains("Alaska") || state.contains("AK")) {
			city = Util
					.match(addSec,
							"Anchorage|College|Fairbanks|Juneau|Kodiak|Adak|Akhiok|Akiachak|Akiak|Akutan|Alakanuk|Bettles|Bethel|Big Lake|Bristol Bay|Coffman Cove|Cordova|Crow Village|Delta Junction|Dillingham|Ester|Fairbanks|Haines|Homer|Hoonah|Kenai|Ketchikan|Knik|Kotzebue|Matanuska-Susitna Borough|Nome|North Pole|Palmer|Pelican|Petsburg|Seward|Sitka|Skagway|Soldotna|Thorne Bay|Unalaska|Valdez|Wasilla|Whittier|Wrangell");
		}
		if (state.contains("Arizona") || state.contains("AZ")) {
			city = Util
					.match(addSec,
							"Barcelona|Apache Junction|Avondale|Bullhead City|Casa Grande|Casas Adobes|Catalina Foothills|Cave Creek|Chambers|Chandler|Chinle|Cottonwood-Verde Village|Douglas|Drexel Heights|Eloy|Flagstaff|Florence|Flowing Wells|Fortuna Foothills|Fountain Hills|Fredonia|Gilbert|Glendale|Globe|Goodyear|Green Valley|Heber|Holbrook|Houck|Lake Havasu City|Marana|Mayer|Mesa|Mohave Valley|New Kingman-Butler|New River|Nogales|Oro Valley|Paradise Valley|Payson|Peoria|Phoenix|Pima|Prescott Valley|Prescott|Quartzsite|Rimrock|Riviera|Sacaton|Safford|San Luis|Scottsdale|Sedona|Show Low|Sierra Vista Southeast|Sierra Vista|Sun City West|Sun City|Sun Lakes|Surprise|Tacna|Tanque Verde|Teec Nos Pos|Tempe|Tonalea|Tucson|Whiteriver|Willcox|San Tan Valley|Maricopa|Buckeye|Queen Creek|Sahuarita|Vail|Yuma|Page");
		}
		if (state.contains("Arkansas") || state.contains("AR")) {
			city = Util
					.match(addSec,
							"Amity|Arkadelphia|Atkins|Batesville|Bella Vista|Bentonville|Benton|Blytheville|Cabot|Camden|Conway|Dermott|El Dorado|Fayetteville|Forrest City|Fort Smith|Franklin|Hampton|Hardy|Harrison|Heber Springs|Hermitage|Hope|Hot Springs|Jonesboro|Little Rock|Magnolia|Malvern|Marmaduke|Marshall|Maumelle|Mountain Home|Mountain View|Newport|Norfork|North Little Rock|Oden|Ola|Paragould|Pine Bluff|Pocahontas|Rogers|Russellville|Salem|Searcy|Sherwood|Shirley|Siloam Springs|Sparkman|Springdale|Texarkana|Van Buren|Waldron|West Memphis|Wynne");
		}

		if (state.contains("California") || state.contains("CA")) {
			city = Util
					.match(addSec,
							"Arabella|Winchester|Diablo Grande|Rolling Hills Estates|Adelanto|Agoura Hills|Alameda|Alamo|Albany|Alhambra|Aliso Viejo|Alpine|Altadena|Alta|Alum Rock|Anaheim Hills|Anaheim|Angels Camp|Angwin|Antioch|Apple Valley|Aptos|Arcadia|Arcata|Arden-Arcade|Arroyo Grande|Artesia|Arvin|Ashland|Atascadero|Atwater|Auburn|Avenal|Avocado Heights|Azusa|Bakersfield|Baker|Baldwin Park|Banning|Barstow|Bass Lake|Bay Point|Baywood-Los Osos|Beaumont|Bell Gardens|Bellflower|Belmont|Benicia|Berkeley|Beverly Hills|Big Bear City|Big Creek|Blackhawk-Camino Tassajara|Bloomington|Blythe|Bonita|Bostonia|Brawley|Brea|Brentwood|Buena Park|Burbank|Burlingame|Cabazon|Calabasas|Calexico|Camarillo|Cameron Park|Campbell|Canoga Park|Capitola|Carlsbad|Carmel|Carmichael|Carpinteria|Carson|Casa de Oro-Mount Helix|Castro Valley|Cathedral City|Central Valley|Ceres|Cerritos|Chatsworth|Cherryland|Chico|Chino Hills|Chino|Chowchilla|Chula Vista|Citrus Heights|Citrus|Claremont|Clayton|Clearlake|Cloverdale|Clovis|Coachella|Coalinga|Colton|Commerce|Compton|Concord|Corcoran|Corning|Coronado|Corona|Costa Mesa|Cotati|Coto de Caza|Covina|Crescent City|Crestline|Cudahy|Culver City|Cupertino|Cypress|Daly City|Dana Point|Danville|Delano|Desert Hot Springs|Diamond Bar|Dinuba|Dixon|Downey|Duarte|Dublin|East Hemet|East Los Angeles|East Palo Alto|East San Gabriel|El Cajon|El Centro|El Cerrito|El Dorado Hills|El Monte|El Segundo|El Sobrante|Elk Grove|Encinitas|Encino|Escondido|Esparto|Eureka|Fair Oaks|Fairfield|Fallbrook|Fillmore|Florence-Graham|Florin|Folsom|Fontana|Foothill Farms|Foothill Ranch|Fort Bragg|Fortuna|Foster City|Fountain Valley|Fremont|Fresno|Fullerton|Galt|Garden Grove|Gardena|Gilroy|Glen Avon|Glendale|Glendora|Goleta|Grand Terrace|Granite Bay|Grass Valley|Greenfield|Grover Beach|Gualala|Guerneville|Hacienda Heights|Half Moon Bay|Hanford|Hawaiian Gardens|Hawthorne|Hayward|Healdsburg|Hemet|Hercules|Hermosa Beach|Hesperia|Highland|Hillsborough|Hollister|Hollywood|Homewood|Huntington Beach|Huntington Park|Imperial Beach|Indio|Inglewood|Irvine|Isla Vista|Jackson|Janesville|Junction City|Keene|King City|La Canada-Flintridge|La Crescenta-Montrose|La Habra|La Jolla|La Mesa|La Mirada|La Palma|La Presa|La Puente|La Quinta|La Riviera|La Verne|Lafayette|Laguna Beach|Laguna Hills|Laguna Niguel|Laguna Woods|Laguna|Lake Elsinore|Lake Forest|Lake Los Angeles|Lakehead|Lakeside|Lakewood|Lamont|Lancaster|Larkspur|Lathrop|Lawndale|Laytonville|Lemon Grove|Lemoore|Lennox|Lincoln|Linda|Lindsay|Live Oak|Livermore|Livingston|Lodi|Loma Linda|Lomita|Lompoc|Long Beach|Los Alamitos|Los Altos|Los Angeles|Los Banos|Los Gatos|Lynwood|Madera|Magalia|Malibu|Manhattan Beach|Manteca|Marina Del Rey|Marina|Martinez|Marysville|Maywood|McKinleyville|Menlo Park|Merced|Mill Valley|Millbrae|Milpitas|Mineral|Mira Loma|Mission Viejo|Modesto|Monrovia|Montclair|Montebello|Montecito|Monterey Park|Monterey|Moorpark|Moraga|Moreno Valley|Morgan Hill|Morro Bay|Mount Aukum|Mountain View|Murrieta|Napa|National City|Newark|Newberry Springs|Newport Beach|Nicolaus|Nipomo|Norco|North Auburn|North Fair Oaks|North Highlands|North Hollywood|Northridge|Norwalk|Novato|Oakdale|Oakland|Oakley|Oceanside|Oildale|Olivehurst|Ontario|Orangevale|Orange|Orcutt|Orinda|Orleans|Oroville|Oxnard|Pacific Grove|Pacifica|Pacoima|Palm Desert|Palm Springs|Palmdale|Palo Alto|Palos Verdes Estates|Panorama City|Paradise|Paradise, NVParamount|Parkway-South Sacramento|Parlier|Pasadena|Paso Robles|Patterson|Pedley|Perris|Petaluma|Philo|Pico Rivera|Piedmont|Pine Valley|Pinecrest|Pinole|Pioneer|Pittsburg|Placentia|Placerville|Playa Del Rey|Pleasant Hill|Pleasanton|Pomona|Port Hueneme|Porterville|Portola|Poway|Prunedale|Ramona|Rancho Cordova|Rancho Cucamonga|Rancho Mirage|Rancho Palos Verdes|Rancho San Diego|Rancho Santa Margarita|Red Bluff|Redding|Redlands|Redondo Beach|Redwood City|Redwood Estates|Reedley|Rialto|Richmond|Ridgecrest|Rio Linda|Ripon|Riverbank|Riverdale|Riverside|Rocklin|Rodeo|Rohnert Park|Rosamond|Rosemead|Rosemont|Roseville|Rossmoor|Rowland Heights|Rubidoux|Sacramento|Salida|Salinas|San Andreas|San Anselmo|San Bernardino|San Bruno|San Carlos|San Clemente|San Diego|San Dimas|San Fernando|San Francisco|San Gabriel|San Jacinto|San Jose|San Juan Capistrano|San Leandro|San Lorenzo|San Luis Obispo|San Marcos|San Marino|San Mateo|San Pablo|San Pedro|San Quentin|San Rafael|San Ramon|San Ysidro|Sanger|Santa Ana|Santa Barbara|Santa Clara|Santa Clarita|Santa Cruz|Santa Fe Springs|Santa Maria|Santa Monica|Santa Paula|Santa Rosa|Santee|Saratoga,|Sausalito|Scotts Valley|Seal Beach|Seaside|Sebastopol|Selma|Shafter|Sherman Oaks|Sierra Madre|Simi Valley|Solana Beach|Soledad|Sonora|South El Monte|South Gate|South Lake Tahoe|South Pasadena|South San Francisco|South San Jose Hills|South Whittier|South Yuba City|Spring Valley|Springville|Stanford|Stanton|Stockton|Suisun City|Sun City|Sun Valley|Sunnyvale|Susanville|Sutter Creek|Sylmar|Tamalpais-Homestead Valley|Tecate|Tehachapi|Temecula|Temple City|Thousand Oaks|Torrance|Tracy|Truckee|Tulare|Turlock|Tustin Foothills|Tustin|Twentynine Palms|Twin Bridges|Ukiah|Union City|Upland|Upper Lake|Vacaville|Valencia|Valinda|Valle Vista|Vallecito|Vallejo|Valley Springs|Van Nuys|Venice|Ventura|Victorville|View Park-Windsor Hills|Vincent|Vineyard|Visalia|Vista|Walnut Creek|Walnut Park|Walnut|Warner Springs|Wasco|Watsonville|West Carson|West Covina|West Hollywood|West Puente Valley|West Sacramento|West Whittier-Los Nietos|Westminster|Westmont|Whittier|Wildomar|Willits|Willowbrook|Wilmington|Windsor|Winter Gardens|Woodland Hills|Woodland|Yorba Linda|Yuba City|Yucaipa|Yucca Valley|Eastvale|Calimesa|Jurupa Valley|Menifee");
		}
		if (state.contains("Colorado") || state.contains("CO")) {
			city = Util
					.match(addSec,
							"Severance|Fort Lupton|Clifton|Aguilar|Alamosa|Arvada|Aspen|Aurora|Berkley|Black Forest|Boulder|Brighton|Broomfield|Buena Vista|Canon City|Castle Rock|Castlewood|Cimarron Hills|Colorado Springs|Columbine|Commerce City|Craig|Crested Butte|Crowley|Denver|Dillon|Dinosaur|Durango|Eads|Englewood|Estes Park|Fairplay|Federal Heights|Fort Carson|Fort Collins|Fort Morgan|Fountain|Glenwood Springs|Golden|Grand Junction|Greeley|Greenwood Village|Gunnison|Highlands Ranch|Hugo|Ken Caryl|Lafayette|Lakewood|Laporte|Leadville|Littleton|Longmont|Louisville|Loveland|Monte Vista|Montrose|Northglenn|Pagosa Springs|Parker|Pine|Pueblo West|Pueblo|Salida|San Luis|Security-Widefield|Sherrelwood|Southglenn|Steamboat Springs|Sterling|Thornton|Trinidad|U S A F Academy|Vail|Walden|Walsenburg|Welby|Westminster|Wheat Ridge|Windsor|Woodland Park|Centennial|Elizabeth|Firestone|Frederick|Erie|Timnath|Wellington|Lochbuie");
		}
		if (state.contains("Connecticut") || state.contains("CT")) {
			city = Util
					.match(addSec,
							"Ansonia|Avon|Berlin|Bethel|Bloomfield|Branford|Bridgeport|Bristol|Brookfield|Central Manchester|Cheshire|Clinton|Colchester|Conning Towers-Nautilus Park|Coventry|Cromwell|Danbury|Darien|Derby|East Hampton|East Hartford|East Haven|East Lyme|Ellington|Enfield|Fairfield|Farmington|Gales Ferry|Glastonbury|Granby|Greenwich|Griswold|Groton|Guilford|Hamden|Hartford|Killingly|Ledyard|Madison|Manchester|Mansfield|Meriden|Middletown|Milford|Monroe|Montville|Mystic|Naugatuck|New Britain|New Canaan|New Fairfield|New Haven|New London|New Milford|Newington|Newtown|North Branford|North Haven|Norwalk|Norwich|Old Saybrook|Orange|Plainfield|Plainville|Plymouth|Ridgefield|Rocky Hill|Seymour|Shelton|Simsbury|Somers|South Windsor|Southbury|Southington|Stafford|Stamford|Stonington|Storrs|Stratford|Suffield|Thomaston|Tolland|Torrington|Trumbull|Unionville|Vernon|Wallingford Center|Wallingford|Washington Depot|Waterbury|Waterford|Watertown|West Hartford|West Haven|Weston|Westport|Wethersfield|Willimantic|Wilton|Winchester|Windham|Windsor Locks|Windsor|Winsted|Wolcott");
		}
		if (state.contains("Delaware") || state.contains("DE")) {
			city = Util
					.match(addSec,
							"Magnolia|Frederica|Milton|Smyrna|Milford|Dagsboro|Ocean View|Frankford|Bear|Brookside|Dover|Glasgow|Hockessin|New Castle|Newark|Pike Creek|Selbyville|Wilmington|Townsend|Middletown|Fenwick Island");
		}
		if (state.contains("Florida") || state.contains("FL")) {
			city = Util
					.match(addSec,
							"Seffner|Wildwood|Port St. Joe|Southport|Mulberry|Mt. Dora|Debary|Valrico|Mims|Apollo Beach|Palm Shores|Alachua|Altamonte Springs|Apopka|Atlantic Beach|Auburndale|Aventura|Azalea Park|Bartow|Bayonet Point|Bayshore Gardens|Bellair-Meadowbrook Terrace|Belle Glade|Bellview|Bloomingdale|Boca Del Mar|Boca Raton|Bonita Springs|Boynton Beach|Bradenton Beach|Bradenton|Brandon|Brent|Brooksville|Brownsville|Bunnell|Callaway|Canal Point|Cape Coral|Carol City|Casselberry|Citrus Park|Citrus Ridge|Clearwater|Cocoa Beach|Cocoa|Coconut Creek|Conway|Cooper City|Coral Gables|Coral Springs|Coral Terrace|Country Club|Country Walk|Crestview|Cutler Ridge|Cutler|Cypress Lake|Dade City|Dania Beach|Davie|Daytona Beach|De Bary|De Funiak Springs|De Land|Deerfield Beach|Delray Beach|Deltona|Doral|Dunedin|East Lake|Edgewater|Egypt Lake-Leto|Elfers|Englewood|Ensley|Eustis|Fairview Shores|Fernandina Beach|Ferry Pass|Flagler Beach|Florida Ridge|Forest City|Fort Lauderdale|Fort Myers Beach|Fort Myers|Fort Pierce|Fleming Island|Fort Walton Beach|Fountainbleau|Fruit Cove|Fruitville|Gainesville|Gladeview|Glenvar Heights|Golden Gate|Golden Glades|Gonzalez|Greater Carrollwood|Greater Northdale|Greater Sun Center|Greenacres|Gulf Gate Estates|Gulfport|Haines City|Hallandale|Hamptons at Boca Raton|Hialeah Gardens|Hialeah|Hobe Sound|Holiday|Holly Hill|Hollywood|Homestead|Homosassa Springs|Orlando|Hosford|Hudson|Immokalee|Interlachen|Inverness|Iona|Ives Estates|Jacksonville Beach|Jacksonville|Jasmine Estates|Jensen Beach|Jupiter|Kendale Lakes|Kendall West|Kendall|Key Biscayne|Key Largo|Key West|Keystone|Kings Point|Kissimmee|Lady Lake|Lake Butler|Lake City|Lake Magdalene|Lake Mary|Lake Wales|Lake Worth Corridor|Lake Worth|Lakeland Highlands|Lakeland|Lakewood Park|Land O' Lakes|Largo|Lauderdale Lakes|Lauderhill|Leesburg|Lehigh Acres|Leisure City|Lighthouse Point|Lockhart|Longwood|Lutz|Lynn Haven|Maitland|Marathon|Marco Island|Marco|Margate|Mary Esther|Meadow Woods|Melbourne|Merritt Island|Miami Beach|Miami Lakes|Miami Shores|Miami Springs|Miami Gardens|Miami|Middleburg|Milton|Miramar|Montverde|Mount Dora|Myrtle Grove|Naples|New Port Richey|New Smyrna Beach|Niceville|Nokomis|Norland|North Fort Myers|North Lauderdale|North Miami Beach|North Miami|North Palm Beach|North Port|Oak Ridge|Oakland Park|Ocala|Ocoee|Ojus|Okeechobee|Oldsmar|Olympia Heights|Opa-Locka|Orange City|Orange Park|Ormond Beach|Oviedo|Palatka|Palm Bay|Palm Beach Gardens|Palm Beach|Palm City|Palm Coast|Palm Harbor|Palm River-Clair Mel|Palm Springs|Palm Valley|Palmetto Estates|Palmetto|Panama City|Parkland|Pembroke Pines|Pensacola|Pine Hills|Pinecrest|Pinellas Park|Pinewood|Placida|Plant City|Poinciana|Pompano Beach|Port Charlotte|Port Orange|Port Richey|Port Saint Joe|Port Salerno|Port St. John|Port St. Lucie|Princeton|Punta Gorda|Quincy|Richmond West|Riverview|Riviera Beach|Rockledge|Royal Palm Beach|Ruskin|Safety Harbor|San Carlos Park|Sandalfoot Cove|Sanderson|Sanford|Sarasota Springs|Sarasota|Scott Lake|Sebastian|Sebring|Seminole|South Bradenton|South Daytona|South Miami Heights|South Miami|South Venice|Spring Hill|Stuart|St. Augustine|St. Cloud|St. Petersburg|Summerland Key|Sunny Isles Beach|Sunrise|Sweetwater|Tallahassee|Tamarac|Tamiami|Tampa|Tarpon Springs|Temple Terrace|The Crossings|The Hammocks|Titusville|Town 'n' Country|Union Park|University Park|University|Upper Grand Lagoon|Venice|Vero Beach South|Vero Beach|Villas|Warrington|Wekiwa Springs|Wellington|West and East Lealman|West Little River|West Palm Beach|West Pensacola|Westchase|Westchester|Weston|Westwood Lakes|Wewahitchka|Wilton Manors|Winter Garden|Winter Haven|Winter Park|Winter Springs|Wright|Yulee|Yeehaw Junction|Zephyrhills|Windermere|Grand Island|Saint Cloud|Tavares|Lake Alfred|Davenport|Harmony|Clermont|Deland|Groveland|Lake Helen|West Melbourne|St. Johns|Callahan|Green Cove Springs|Saint Augustine|Beverly Beach|Freeport|Inlet Beach|Santa Rosa Beach|Panama City Beach|Point Washington|Pace|Navarre|Cantonment|Gulf Breeze|Miami Dade County|Haverhill|Port St Lucie|Osprey|Sun City Center|Thonotosassa|Trinity|Wimauma|Gibsonton|Wesley Chapel|Ellenton|Land O Lakes|St Petersburg|Viera|Jacksonville|Lakeside|Plantation|Alva,|Point Washington");
		}
		if (state.contains("Georgia") || state.contains("GA")) {
			city = Util
					.match(addSec,
							"Villa Rica|Lithia Springs|Bishop|Senoia|Stockbridge|Grayson|Austell|Bethlehem|Rex|Loganville|Grovetown|Hephzibah|Acworth|Albany|Alpharetta|Alto|Americus|Athens|Atlanta,|Augusta|Bainbridge|Belvedere Park|Brunswick|Buford|Calhoun|Candler-McAfee|Carrollton|Cartersville|Cochran|College Park|Columbus|Commerce|Conyers|Cordele|Covington|Dahlonega|Dalton|Dawson|Decatur|Demorest|Douglasville|Douglas|Druid Hills|Dublin|Duluth|Dunwoody|Dacula|East Point|Elberton|Evans|Fayetteville|Forest Park|Fort Benning South|Fort Stewart|Gainesville|Garden City|Georgetown|Griffin|Hinesville|Jonesboro|Kennesaw|Kingsland|La Grange|Lawrenceville|Lilburn|Lithonia|Mableton|Macon|Marietta|Martinez|Milledgeville|Monroe|Morrow|Moultrie|Mountain Park|Newnan|Newton|Norcross|North Atlanta|North Decatur|North Druid Hills|Panthersville|Peachtree City|Powder Springs|Redan|Reidsville|Riverdale|Rome|Roswell|Sandy Springs|Savannah|Smyrna|Snellville|Statesboro|Stone Mountain|St. Marys|St. Simons|Sugar Hill|Thomasville|Tifton|Toccoa,|Tucker|Union City|Union Point|Valdosta|Vidalia|Warner Robins|Waycross|Wilmington Island|Winder|Woodstock|Cumming|Hampton|Ellenwood|Hiram|Mcdonough|Dallas|Locust Grove|Fairburn|Flowery Branch|Canton|Suwanee|Byron|Kathleen|Perry|Guyton|Pooler|Richmond Hill");
		}
		if (state.contains("Hawaii") || state.contains("HI")) {
			city = Util
					.match(addSec,
							"Aiea|Ewa Beach|Halawa|Hanalei|Hilo|Honolulu|Kahului|Kailua Kona|Kailua|Kaneohe Station|Kaneohe|Kihei|Lahaina|Laupahoehoe|Lihue|Makakilo City|Makawao|Mililani Town|Nanakuli|Pearl City|Schofield Barracks|Wahiawa|Waianae|Wailuku|Waimalu|Waipahu|Waipio|Poipu - Koloa|Kapolei|Makakilo|Kamuela|Kona/ Kohala Coast");
		}
		if (state.contains("Idaho") || state.contains("ID")) {
			city = Util
					.match(addSec,
							"Ashton|Blackfoot|Boise|Caldwell|Cambridge|Coeur d'Alene|Cottonwood|Culdesac|Dubois|Eagle|Emmett|Fairfield|Garden City|Grace|Grangeville|Harrison|Idaho City|Idaho Falls|Lewiston|Malad City|Meridian|Moore|Moscow|Mountain Home|Nampa|North Fork|Paris|Pocatello|Post Falls|Rexburg|Rupert|Sandpoint|Shoshone|Sun Valley|Twin Falls|Wallace");
		}
		if (state.contains("Illinois") || state.contains("IL")) {
			city = Util
					.match(addSec,
							"Antioch|Yorkville|Addison|Algonquin|Alsip|Alton|Arlington Heights|Aurora|Barrington|Bartlett|Batavia|Beach Park|Beecher City|Belleville|Bellwood|Belvidere|Bensenville|Berwyn|Blandinsville|Bloomingdale|Bloomington|Blue Island|Bolingbrook|Bourbonnais|Bradley|Bridgeview|Brimfield|Brookfield|Buffalo Grove|Burbank|Burr Ridge|Cahokia|Calumet City|Canton|Carbondale|Carol Stream|Carpentersville|Cary|Centralia|Champaign|Charleston|Chicago Heights|Chicago Ridge|Chicago|Cicero|Collinsville|Country Club Hills|Crest Hill|Crestwood|Crystal Lake|Danville|Darien|Decatur|Deerfield|DeKalb|Des Plaines|Dixon|Dolton|Downers Grove|East Moline|East Peoria|East Saint Louis|East St. Louis|Edwardsville|Effingham|Elgin|Elk Grove Village|Elmhurst|Elmwood Park|Evanston|Evergreen Park|Fairview Heights|Flossmoor|Forest Park|Frankfort|Franklin Park|Freeport|Gages Lake|Galesburg|Geneva|Glen Carbon|Glen Ellyn|Glendale Heights|Glenview|Godfrey|Goodings Grove|Granite City|Grayslake|Gurnee|Hanover Park|Harvey|Hazel Crest|Herrin|Hickory Hills|Highland Park|Hillside|Hinsdale|Hoffman Estates|Homewood|Jacksonville|Joliet|Justice|Kankakee|Kewanee|La Grange Park|La Grange|Lake Forest|Lake in the Hills|Lake Zurich|Lansing|Lemont|Libertyville|Lincolnwood|Lincoln|Lindenhurst|Lisle|Lockport|Lombard|Loves Park|Lyons|Machesney Park|Macomb|Marion|Markham|Mascoutah|Matteson|Mattoon|Maywood|McHenry|Melrose Park|Midlothian|Mokena|Moline|Morris|Morton Grove|Morton|Mount Prospect|Mount Vernon|Mundelein|Murphysboro|Naperville|New Lenox|Niles|Normal|Norridge|North Aurora|North Chicago|Northbrook|Northlake|O'Fallon|Oak Forest|Oak Lawn|Oak Park|Orland Park|Oswego|Ottawa|Palatine|Palos Heights|Palos Hills|Palos Park|Park Forest|Park Ridge|Pekin|Peoria|Petersburg|Plainfield|Pontiac|Prairie Du Rocher|Prospect Heights|Quincy|Rantoul|Richton Park|River Forest|River Grove|Riverdale|Rock Island|Rockford|Rolling Meadows|Romeoville|Roselle|Round Lake Beach|Sauk Village|Schaumburg|Schiller Park|Skokie|South Elgin|South Holland|Springfield|Sterling|Streamwood|Streator|St. Charles|Summit|Swansea|Sycamore|Taylorville|Tinley Park|Urbana|Vernon Hills|Villa Park|Warrenville|Washington|Waukegan|West Chicago|Westchester|Western Springs|Westmont|Wheaton|Wheeling|Wilmette|Winnetka|Wood Dale|Wood River|Woodfield-Schaumburg|Woodridge|Woodstock|Worth|Zion|Pingree Grove|Volo|Huntley|Glencoe|Woodridge");
		}
		if (state.contains("Indiana") || state.contains("IN")) {
			city = Util
					.match(addSec,
							"Schereville|Anderson|Auburn|Bedford|Beech Grove|Birdseye|Bloomington|Brownsburg|Carmel|Chesterton|Clarksville|Columbus|Connersville|Crawfordsville|Crown Point|Dyer|Earl Park|East Chicago|Elizabethtown|Elkhart|Evansville|Fishers|Fort Wayne|Fowler|Frankfort|Franklin|Gary|Goshen|Granger|Greenfield|Greensburg|Greenwood|Griffith|Hammond|Highland|Hobart|Huntington|Indianapolis|Jasper|Jeffersonville|Kokomo|La Porte|Lafayette|Lake Station|Lawrence|Lebanon|Logansport|Lowell|Madison|Marion|Martinsville|Merrillville|Michigan City|Mishawaka|Muncie|Munster|New Albany|New Castle|New Haven|Newburgh|Noblesville|Peru|Plainfield|Portage|Portland|Princeton|Richmond|Schererville|Seymour|Shelbyville|South Bend|Speedway|Sullivan|Terre Haute|Valparaiso|Vincennes|Wabash|Warsaw|Washington|West Lafayette");
		}
		if (state.contains("Iowa") || state.contains("IA")) {
			city = Util
					.match(addSec,
							"Alden|Altoona|Amana|Ames|Ankeny|Bettendorf|Boone|Burlington|Carroll|Cedar Falls|Cedar Rapids|Charles City|Churdan|Clinton|Clive|Collins|Coralville|Council Bluffs|Davenport|Davis City|Des Moines|Dubuque|Fort Dodge|Fort Madison|Grinnell|Indianola|Iowa City|Keokuk|Logan|Manning|Marion|Marshalltown|Mason City|Mingo|Montezuma|Muscatine|New Hampton|Newton|Ocheyedan|Oskaloosa|Ottumwa|Red Oak|Sheldon|Shenandoah|Shenandoah|Sioux City|Spencer|Storm Lake|Thurman|Underwood|Union|Urbandale|Waterloo|West Des Moines");
		}
		if (state.contains("Kansas") || state.contains("KS")) {
			city = Util
					.match(addSec,
							"Alma|Arkansas City|Atchison|Beloit|Caldwell|Coffeyville|De Soto|Derby|Dodge City|El Dorado|Emporia|Enterprise|Garden City|Gardner|Great Bend|Hays|Hiawatha|Hutchinson|Junction City|Kansas City|Kingman|Lawrence|Leavenworth|Leawood|Lenexa|Liberal|Madison|Manhattan|Marysville|McPherson|Merriam|Newton|Olathe|Ottawa|Overland Park|Parsons|Phillipsburg|Pittsburg|Prairie Village|Salina|Shawnee|Topeka|Westmoreland|Wichita|Winfield");
		}
		if (state.contains("Kentucky") || state.contains("KY")) {
			city = Util
					.match(addSec,
							"Ashland|Barbourville|Bardstown|Berea|Bowling Green|Burlington|Burnside|Campbellsville|Carrollton|Covington|Danville|Elizabethtown|Erlanger|Fern Creek|Florence|Fort Campbell North|Fort Knox|Fort Thomas|Frankfort|Georgetown|Glasgow|Harlan|Henderson|Highview|Hopkinsville|Independence|Jeffersontown|La Grange|Lancaster|Lexington|London|Louisa|Louisville|Madisonville|Mayfield|Middlesborough|Murray|Newburg|Newport|Nicholasville|Okolona|Owensboro|Paducah|Pikeville|Pleasure Ridge Park|Radcliff|Richmond|Shelbyville|Shively|Somerset|Stanton|St. Matthews|Valley Station|Winchester");
		}
		if (state.contains("Louisiana") || state.contains("LA")) {
			city = Util
					.match(addSec,
							"Rayne|Abbeville|Alexandria|Angie|Baker|Bastrop|Baton Rouge|Bayou Cane|Benton|Bogalusa|Bossier City|Boyce|Broussard|Chalmette|Convent|Covington|Crowley|Denham Springs|Destrehan|Estelle|Eunice|Fort Polk South|Gray|Gonzales|Gretna|Hammond|Harvey|Houma|Iowa|Jefferson|Jennings|Kenner|La Place|Lafayette|Lake Charles|Leesville|Logansport|Luling|Mandeville|Marrero|Maurice|Meraux|Merrydale|Metairie|Minden|Monroe|Morgan City|Moss Bluff|Natchitoches|New Iberia|New Orleans|Opelousas|Pineville|Plaquemine|Raceland|Rayville|Reserve|River Ridge|Ruston|Shreveport|Slidell|Sulphur|Tallulah|Terrytown|Thibodaux|Timberlane|West Monroe|Westwego|Woodmere|Zachary|From Baton Rouge|Addis|Prairieville|Watson|Madisonville|Ponchatoula|Robert|Duson|Carencro|Youngsville");
		}
		if (state.contains("Maine") || state.contains("ME")) {
			city = Util
					.match(addSec,
							"Ashland|Auburn|Augusta|Bangor|Biddeford|Brunswick|Castine|Danforth|Falmouth|Freeport|Gorham|Greenville|Guilford|Jay|Kennebunk|Lewiston|Limestone|Machias|Orono|Portland|Princeton|Saco|Sanford|Scarborough|South Portland|Southwest Harbor|Stonington|Surry|Waterville|Westbrook|Windham|York");
		}
		if (state.contains("Maryland") || state.contains("MD")) {
			city = Util
					.match(addSec,
							"Accokeek|Edgewater|White Plains|Ijamsville|Marriottsville|Sykesville|Clarksburg|Laytonsville|Clarksville|Frankford|Millersville|Aberdeen Proving Ground|Aberdeen|Adelphi|Annapolis|Arbutus|Arnold|Aspen Hill|Ballenger Creek|Baltimore|Bel Air North|Bel Air South|Bel Air|Beltsville|Bethesda|Bowie|Brooklyn Park|Calverton|Cambridge|Camp Springs|Carney|Catonsville|Chesapeake Ranch Estates-Drum Point|Chillum|Church Hill|Clinton|Cockeysville|Colesville|College Park|Columbia|Coral Hills|Crofton|Cumberland|Damascus|Dundalk|East Riverdale|Easton|Edgewood|Eldersburg|Elkridge|Elkton|Ellicott City|Essex|Fairland|Ferndale|Forestville|Fort Washington|Frederick|Fulton|Friendly|Gaithersburg|Germantown|Glen Burnie|Glenn Dale|Greater Landover|Greater Upper Marlboro|Green Haven|Green Valley|Greenbelt|Hagerstown|Halfway|Havre de Grace|Hillcrest Heights|Hyattsville|Joppatowne|Kettering|Lake Shore|Langley Park|Lanham-Seabrook|Lansdowne-Baltimore Highlands|Laurel|Lexington Park|Linganore-Bartonsville|Lochearn|Lutherville-Timonium|Manchester|Mays Chapel|Middle River|Milford Mill|Montgomery Village|New Carrollton|North Bethesda|North Laurel|North Potomac|Ocean Pines|Odenton|Olney|Overlea|Owings Mills|Oxon Hill-Glassmanor|Parkville|Parole|Pasadena|Perry Hall|Pikesville|Potomac|Randallstown|Redland|Reisterstown|Ridgely|Riviera Beach|Rockville|Rosaryville|Rosedale|Rossville|Salisbury|Savage-Guilford|Severna Park|Severn|Silver Spring|South Gate|South Laurel|St. Charles|Suitland-Silver Hill|Takoma Park|Towson|Upper Marlboro|Waldorf|Walker Mill|Westernport|Westminster|Wheaton-Glenmont|White Oak|Woodlawn|Woodstock|New Market|Brandywine|Glenarden|Mitchellville|Cooksville|Hanover|Marriottsville");

		}
		if (state.contains("Massachusetts") || state.contains("MA")) {
			city = Util
					.match(addSec,
							"Abington|Acton|Acushnet|Agawam|Amesbury|Amherst Center|Amherst|Andover|Arlington|Ashburnham|Ashland|Athol|Attleboro|Auburn|Ayer|Barnstable Town|Bedford|Belchertown|Bellingham|Belmont|Beverly|Billerica|Boston|Bourne|Braintree|Brewster|Bridgewater|Brockton|Brookline|Burlington|Buzzards Bay|Cambridge|Canton|Carver|Centerville|Charlemont|Charlton|Chelmsford|Chelsea|Chicopee|Clinton|Concord|Dalton|Danvers|Dartmouth|Dedham|Dennis|Dracut|Dudley|Duxbury|East Bridgewater|East Longmeadow|Easthampton|Easton|Everett|Fairhaven|Fall River|Falmouth|Fitchburg|Foxborough|Framingham|Franklin|Gardner|Gloucester|Grafton|Greenfield|Groton|Hanover|Harwich|Haverhill|Hingham|Holbrook|Holden|Holliston|Holyoke|Hopkinton|Hudson|Hull|Ipswich|John Fitzgerald Kennedy|Kingston|Lawrence|Lee|Leicester|Leominster|Lexington|Longmeadow|Lowell|Ludlow|Lynnfield|Lynn|Malden|Mansfield|Marblehead|Marlborough|Marshfield|Mashpee|Maynard|Medfield|Medford|Medway|Melrose|Methuen|Middlesex Essex Gmf|Milford|Millbury|Milton|Nantucket|Natick|Needham|New Bedford|Newburyport|Newtonville|Newton|Norfolk|North Adams|North Andover|North Attleborough Center|North Dighton|North Easton|North Falmouth|North Reading|Northampton|Northborough|Northbridge|Northfield|Norton|Norwood|Orange|Oxford|Palmer|Peabody|Pembroke|Pepperell|Pittsfield|Plymouth|Quincy|Randolph|Raynham|Reading|Rehoboth|Revere|Rockland|Salem|Sandwich|Saugus|Scituate|Seekonk|Sharon|Shrewsbury|Somerset|Somerville|South Egremont|South Hadley|South Yarmouth|Southborough|Southbridge|Spencer|Springfield|Stockbridge|Stoneham|Stoughton|Sudbury|Swampscott|Swansea|Taunton|Tewksbury|Turners Falls|Tyngsborough|Uxbridge|Vineyard Haven|Wakefield|Walpole|Waltham|Wareham|Warren|Watertown|Wayland|Webster|Wellesley|West Springfield|West Upton|Westborough|Westfield|Westford|Weston|Westport|Westwood|Weymouth|Whitman|Wilbraham|Wilmington|Winchester|Winthrop|Woburn|Worcester|Wrentham|Yarmouth");
		}
		if (state.contains("Michigan") || state.contains("MI")) {
			city = Util
					.match(addSec,
							"Ada|Adrian|Algonac|Allen Park|Allendale|Alma|Alpena|Alpine|Ann Arbor|Antwerp|Attica|Auburn Hills|Bangor|Battle Creek|Bay City|Bedford|Beecher|Benton Harbor|Benton|Berkley|Berrien Springs|Beverly Hills|Big Rapids|Birmingham|Blackman|Bloomfield Hills|Bloomfield Township|Bloomfield|Brandon|Bridgeport|Brighton|Brimley|Brownstown|Buena Vista|Burton|Byron|Cadillac|Cannon|Canton|Cascade|Charlevoix|Chesterfield|Clawson|Clinton|Coldwater|Commerce|Comstock Park|Comstock|Cutlerville|Davison|De Witt|Dearborn Heights|Dearborn|Delhi|Delta|Detroit|East Grand Rapids|East Lansing|East Tawas|Eastpointe|Eckerman|Ecorse|Emmett|Escanaba|Farmington Hills|Farmington|Fenton|Ferndale|Flint|Flushing|Forest Hills|Fort Gratiot|Frankenmuth|Fraser|Frenchtown|Fruitport|Gaines|Garden City|Garfield|Genesee|Genoa|Georgetown|Grand Blanc|Grand Haven|Grand Rapids|Grandville|Grayling|Green Oak|Grosse Ile|Grosse Pointe Park|Grosse Pointe Woods|Grosse Pointe|Hamburg|Hamtramck|Harbor Springs|Harper Woods|Harrison|Hartland|Haslett|Hazel Park|Highland Park|Highland|Holland|Holly|Holt|Houghton|Howell|Huron|Independence|Inkster|Ionia|Jackson|Jenison|Kalamazoo|Kentwood|Kincheloe|Lansing|Leoni|Lincoln Park|Lincoln|Livonia|Lyon|Macomb|Madison Heights|Marquette|Marshall|Melvindale|Meridian|Midland|Milford|Minden City|Monitor|Monroe|Mount Clemens|Mount Morris|Mount Pleasant|Mundy|Muskegon Heights|Muskegon|Niles|Northview|Northville|Norton Shores|Novi|Oak Park|Oakland|Okemos|Orion|Oscoda|Oshtemo|Owosso|Oxford|Park|Pittsfield|Plainfield|Plymouth Township|Plymouth|Pontiac|Port Huron|Portage|Redford|Rhodes|Riverview|Rochester Hills|Rochester|Rockford|Romulus|Roseville|Royal Oak|Saginaw Township North|Saginaw Township South|Saginaw|Sault Ste. Marie|Scio|Shelby|South Lyon|Southfield|Southgate|Spring Lake|Springfield|Sterling Heights|Sturgis|St. Clair Shores|St. Joseph|Summit|Sumpter|Superior|Taylor|Texas|Thomas|Traverse City|Trenton|Troy|Utica|Van Buren|Vassar|Vienna|Walker|Warren|Washington|Waterford|Waverly|Wayne|West Bloomfield Township|West Bloomfield|Westland|White Lake|Whitehall|Wixom|Woodhaven|Wyandotte|Wyoming|Ypsilanti");
		}
		if (state.contains("Minnesota") || state.contains("MN")) {
			city = Util
					.match(addSec,
							"Dundas|Albert Lea|Andover|Anoka|Apple Valley|Austin|Bemidji|Blaine|Bloomington|Brainerd|Brook Park|Brooklyn Center|Brooklyn Park|Buffalo|Burnsville|Center City|Champlin|Chanhassen|Chaska|Cloquet|Columbia Heights|Cook|Coon Rapids|Cottage Grove|Cotton|Crystal|Deer River|Detroit Lakes|Duluth|Eagan|East Bethel|Eden Prairie|Edina|Elk River|Fairmont|Faribault|Farmington|Fergus Falls|Fridley|Golden Valley|Graceville|Grand Rapids|Grasston|Ham Lake|Hastings|Hibbing|Hill City|Hopkins|Howard Lake|Hugo|Hutchinson|Inver Grove Heights|Kerrick|Lakeville|Lino Lakes|Long Prairie|Mankato|Maple Grove|Maple Plain|Maplewood|Marshall|Meadowlands|Mendota Heights|Minneapolis|Minnetonka|Monticello|Moorhead|Motley|Mounds View|New Brighton|New Hope|New Ulm|North Mankato|North St. Paul|Northfield|Norwood|Oakdale|Orr|Owatonna|Plymouth|Prior Lake|Ramsey|Red Wing|Richfield|Robbinsdale|Rochester|Roosevelt|Rosemount|Roseville|Rush City|Sauk Centre|Sauk Rapids|Savage|Sebeka|Shakopee|Shevlin|Shoreview|Silver Bay|Solway|South St. Paul|Stillwater|St. Cloud|St. Louis Park|St. Paul|Vadnais Heights|Virginia|West St. Paul|White Bear Lake|White Bear|Willmar|Winona|Woodbury|Worthington|Wrenshall|Young America|Otsego|St. Michael|Minnetrista");
		}
		if (state.contains("Mississippi") || state.contains("MS")) {
			city = Util
					.match(addSec,
							"Bay Saint Louis|Biloxi|Brandon|Canton|Clarksdale|Cleveland|Clinton|Columbus|Corinth|Drew|Flora|Gautier|Greenville|Greenwood|Grenada|Gulfport|Hattiesburg|Hermanville|Horn Lake|Indianola|Jackson|Laurel|Long Beach|Madison|Magee|McComb|Meridian|Moss Point|Natchez|Ocean Springs|Olive Branch|Oxford|Pascagoula|Pearl|Picayune|Ridgeland|Rolling Fork|Southaven|Starkville|Tupelo|Vicksburg|Walls|West Point|Wiggins|Woodville|Yazoo City|D'iberville|Pass Christian");
		}
		if (state.contains("Missouri") || state.contains("MO")) {
			city = Util
					.match(addSec,
							"Moberly|Affton|Arnold|Ballwin|Bellefontaine Neighbors|Belton|Berkeley|Blue Springs|Bridgeton|Butler|Cape Girardeau|Carthage|Chesterfield|Chillicothe|Clayton|Columbia|Concord|Craig|Crestwood|Creve Coeur|Excelsior Springs|Farmington|Fenton|Ferguson|Florissant|Forest City|Fort Leonard Wood|Fulton|Gladstone|Grandview|Grant City|Hannibal|Hazelwood|Independence|Jackson|Jefferson City|Jennings|Joplin|Kansas City|Kennett|Kirksville|Kirkwood|Lake St. Louis|Lamar|Lebanon|Lee's Summit|Lemay|Liberty|Manchester|Marshall|Maryland Heights|Maryville|Maysville|Mehlville|Mexico|Neosho|Newtown|Nixa|Norborne|O' Fallon|Oakville|Osceola|Overland|Poplar Bluff|Raymore|Raytown|Rock Port|Rolla|Sedalia|Sikeston|Spanish Lake|Springfield|St. Ann|St. Charles|St. Joseph|St. Louis|St. Peters|Town and Country|Trenton|University City|Warrensburg|Washington|Webster Groves|Wentzville|West Plains|Wildwood");
		}
		if (state.contains("Montana") || state.contains("MT")) {
			city = Util
					.match(addSec,
							"Absarokee|Arlee|Ashland|Billings|Bonner|Bozeman|Broadus|Butte|Columbia Falls|Cooke City|Cut Bank|Deer Lodge|Dillon|East Helena|Fallon|Frenchtown|Glasgow|Great Falls|Hamilton|Hardin|Helena|Kalispell|Laurel|Lewistown|Miles City|Missoula|Red Lodge|Roberts|Roundup|Scobey|Toston|West Glacier|Winnett");
		}
		if (state.contains("Nebraska") || state.contains("NE")) {
			city = Util
					.match(addSec,
							"Bassett|Beatrice|Bellevue|Blair|Bruno|Chalco|Columbus|Fremont|Grand Island|Hastings|Holdrege|Kearney|La Vista|Lexington|Lincoln|Lyman|Norfolk|North Bend|North Platte|Omaha|Papillion|Scottsbluff|Sidney|South Sioux City|Valentine|Valley");
		}
		if (state.contains("Nevada") || state.contains("NV")) {
			city = Util
					.match(addSec,
							"Crystal Bay|Carson City|Henderson|Indian Springs|Jean|Pahrump|Boulder City|Elko|Enterprise|Gardnerville Ranchos|Hawthorne|Las Vegas|North Las Vegas|Reno|Searchlight|Sparks|Spring Creek|Spring Valley|Sun Valley|Sunrise Manor|Whitney|Winchester|Zephyr Cove|Alamo|Amargosa Valley|Ash Springs|Austin|Baker|Battle Mountain|Beatty|Beowawe|Blue Diamond|Boulder City|Bunkerville|Cal-Nev-Ari|Caliente|Carlin|Carson City|Cold Springs|Crystal|Crystal Bay|Dayton|Denio|Duckwater|Dyer|East|Ely|Elko|Empire|Enterprise|Eureka|Fallon|Fernley|Gabbs|Gardnervillle|Gerlach|Golden Valley|Goldfield|Goodsprings|Hawthorne|Henderson|Imlay|Incline Village|Indian Hills|Indian Springs|Jackpot|Jarbidge|Jean|Jiggs|Johnson Lane|Kingsbury|Las Vegas|Laughlin|Lemmon Valley|Logandale|Lovelock|Lund|McDermitt|McGill|Mesquite|Minden|Moapa Town|Moapa Valley|Montello|Mount Charleston|Nixon|North Las Vegas|Orovada|Overton|Owyhee|Pahrump|Panaca|Paradise|Pioche|Rachel|Reno|Round Hill Village|Round Mountain|Sandy Valley|Schurz|Searchlight|Silver Park|Silver Springs|Sloan|Smith|Spanish Springs|Sparks|Spring Creek|Spring Valley|Stateline|Summerlin South|Sun Valley|Sunrise Manor|Sutcliffe|Tonopah|Tuscarora|Verdi|Virginia City|Wadsworth|Wells|West Wendover|Winnemucca|Whitney|Winchester|Yerington|Zephyr Cove");
		}
		if (state.contains("New Hampshire") || state.contains("NH")) {
			city = Util
					.match(addSec,
							"Amherst|Bedford|Berlin|Claremont|Concord|Conway|Cornish Flat|Derry|Dover|Durham|Exeter|Goffstown|Hampton|Hanover|Hooksett|Hudson|Keene|Laconia|Lebanon|Londonderry|Madison|Manchester|Merrimack|Milford|Nashua|Pelham|Peterborough|Portsmouth|Rochester|Salem|Somersworth|Twin Mountain|Walpole|Windham|Wolfeboro");
		}
		if (state.contains("New Jersey") || state.contains("NJ")) {
			city = Util
					.match(addSec,
							"Manahawkin|Monroe Township|Evesham Township|Mount Olive|Aberdeen|Allenhurst|Asbury Park|Atlantic City|Avenel|Barclay-Kingston|Barnegat|Basking Ridge|Bayonne|Beachwood|Belleville|Bellmawr|Belmar|Bergenfield|Berkeley Heights|Berkeley|Bernards Township|Bloomfield|Bound Brook|Branchburg|Branchville|Brick|Bridgeton|Bridgewater|Brigantine|Browns Mills|Burlington|Caldwell|Camden|Carteret|Cedar Grove|Chatham|Cherry Hill Mall|Cherry Hill|Cinnaminson|City of Orange|Clark|Cliffside Park|Clifton|Clinton|Collingswood|Colonia|Colts Neck|Cranbury|Cranford|Delran|Denville|Deptford|Dover|Dumont|East Brunswick|East Hanover|East Orange|East Windsor|Eatontown|Echelon|Edison|Egg Harbor Township|Egg Harbor|Elizabeth|Elmwood Park|Englewood|Evesham|Ewing|Fair Lawn|Fairview|Florence|Fords|Fort Lee|Franklin Lakes|Franklin|Freehold|Galloway|Garfield|Glassboro|Glen Rock|Gloucester City|Gloucester|Greentree|Guttenberg|Hackensack|Hackettstown|Haddonfield|Haddon|Haledon|Hamilton|Hammonton|Hanover|Harrison|Hasbrouck Heights|Hawthorne|Hazlet|Highland Park|Hillsborough|Hillsdale|Hillside|Hoboken|Holiday City-Berkeley|Holmdel|Hopatcong|Hopewell|Howell|Irvington|Iselin|Jackson|Jefferson|Jersey City|Keansburg|Kearny|Kenilworth|Kirkwood Voorhees|Lacey|Lakehurst|Lakewood|Lawrence|Leisure Village West-Pine Lake Park|Lincoln Park|Lindenwold|Linden|Linwood|Little Egg Harbor|Little Falls|Little Ferry|Livingston|Lodi|Long Branch|Lower|Lumberton|Lyndhurst|Madison|Mahwah|Manalapan|Manchester|Mantua|Manville|Maple Shade|Maplewood|Marlboro|Marlton|Medford|Mercerville-Hamilton Square|Metuchen|Middlesex|Middletown|Middle|Millburn|Millville|Monroe|Montclair|Montgomery|Montville|Moorestown-Lenola|Moorestown|Morganville|Morristown|Morris|Mount Holly|Mount Laurel|Neptune|New Brunswick|New Milford|New Providence|Newark|North Arlington|North Bergen|North Brunswick Township|North Brunswick|North Plainfield|Nutley|Oakland|Ocean Acres|Ocean City|Ocean|Old Bridge|Orange|Palisades Park|Paramus|Parsippany-Troy Hills|Passaic|Paterson|Pemberton|Pennsauken|Pennsville|Pequannock|Perth Amboy|Phillipsburg|Pine Hill|Piscataway|Plainfield|Plainsboro|Pleasantville|Point Pleasant|Pompton Lakes|Princeton Meadows|Princeton|Rahway|Ramsey|Randolph|Raritan|Readington|Red Bank|Ridgefield Park|Ridgefield|Ridgewood|Ringwood|River Edge|Riverside|Rockaway|Roselle Park|Roselle|Roxbury|Rutherford|Saddle Brook|Sayreville|Scotch Plains|Secaucus|Somers Point|Somerset|Somerville|South Amboy|South Brunswick|South Orange Village|South Orange|South Plainfield|South River|Southampton|Sparta|Springdale|Springfield|Stafford|Succasunna-Kenvil|Summit|Teaneck|Tenafly|Tinton Falls|Toms River|Totowa|Trenton|Union City|Union|Upper|Ventnor City|Vernon|Verona|Vineland|Voorhees|Wallington|Wall|Wanaque|Wantage|Warren|Washington|Waterford|Wayne|Weehawken|West Caldwell|West Deptford|West Freehold|West Milford|West New York|West Orange|West Paterson|West Windsor|Westfield|Westwood|Williamstown|Willingboro|Winslow|Woodbridge|Woodbury|Wyckoff|Egg Harbor Township|Manchester Township");
		}
		if (state.contains("New Mexico") || state.contains("NM")) {
			city = Util
					.match(addSec,
							"Deming|Alamogordo|Albuquerque|Anthony|Artesia|Bernalillo|Carlsbad|Cloudcroft|Clovis|Cuba|Eagle Nest|Espanola|Estancia|Farmington|Gallup|Grants|Hobbs|La Mesa|Las Cruces|Las Vegas|Lordsburg|Los Alamos|Los Lunas|Moriarty|North Valley|Penasco|Peralta|Portales|Rio Rancho|Roswell|Santa Fe|Santa Rosa|Silver City|South Valley|Springer|Sunland Park|Tucumcari|Wagon Mound|Watrous");
		}
		if (state.contains("New York") || state.contains("NY")) {
			city = Util
					.match(addSec,
							"Medford|Clay|Albany|Alden|Amherst|Amsterdam|Antwerp|Arcadia|Arlington|Auburn|Aurora|Babylon|Baldwin|Batavia|Bath|Bay Shore|Beacon|Bedford|Beekman|Bellmore|Bethlehem|Bethpage|Binghamton|Blooming Grove|Brentwood|Brighton|Bronx|Brookhaven|Brooklyn|Brunswick|Buffalo|Camillus|Canandaigua|Canton|Carmel|Carthage|Catskill|Centereach|Central Islip|Cheektowaga|Chenango|Chester|Chili|Cicero|Clarence|Clarkstown|Clifton Park|Cohoes|Colonie|Commack|Copiague|Coram|Corning|Cornwall|Cortlandt|Cortland|Coxsackie|Croton-On-Hudson|De Witt|Deer Park|Depew|Dix Hills|Dobbs Ferry|Dryden|Dunkirk|East Fishkill|East Greenbush|East Hampton|East Islip|East Massapequa|East Meadow|East Northport|East Patchogue|East Rockaway|Eastchester|Elma|Elmira|Elmont|Elwood|Endicott|Endwell|Evans|Fairmount|Fallsburg|Far Rockaway|Farmingdale|Farmington|Farmingville|Fishkill|Floral Park|Flushing|Fort Drum|Franklin Square|Fredonia|Freeport|Fultonville|Fulton|Garden City|Gates-North Gates|Gates|Geddes|Geneva|Georgetown|German Flatts|Glen Cove|Glens Falls|Glenville|Gloversville|Goshen|Grand Island|Great Neck|Greece|Greenburgh|Greenlawn|Groveland|Guilderland|Halfmoon|Hamburg|Hampton Bays|Harrison|Hauppauge|Haverstraw|Hempstead|Henrietta|Hicksville|Highlands|Holbrook|Holtsville|Horseheads|Huntington Station|Huntington|Hyde Park|Irondequoit|Islip|Ithaca|Jamaica|Jamestown|Jefferson Valley-Yorktown|Jericho|Johnson City|Keeseville|Kenmore|Kent|Kings Park|Kingsbury|Kingston|Kirkland|Kiryas Joel|La Grange|Lackawanna|Lake Grove|Lake Ronkonkoma|Lancaster|Lansing|Latham|Le Ray|Levittown|Lewisboro|Lewiston|Lindenhurst|Liverpool|Lockport|Long Beach|Long Island City|Lynbrook|Lyon Mountain|Lysander|Malone|Malta|Mamakating|Mamaroneck|Manhattan|Manlius|Manorville|Massapequa Park|Massapequa|Massena|Mastic Beach|Mastic|Melville|Merrick|Middletown|Miller Place|Milton|Mineola|Monroe|Monsey|Montgomery|Moreau|Mount Pleasant|Mount Vernon|Nanuet|Nesconset|New Cassel|New Castle|New City|New Hartford|New Hyde Park|New Paltz|New Rochelle|New Windsor|New York|Newburgh|Newcomb|Niagara Falls|Niskayuna|North Amityville|North Babylon|North Bangor|North Bay Shore|North Bellmore|North Castle|North Greenbush|North Hempstead|North Lawrence|North Lindenhurst|North Massapequa|North Merrick|North New Hyde Park|North Tonawanda|North Valley Stream|North Wantagh|Oceanside|Ogdensburg|Ogden|Olean|Oneida|Oneonta|Onondaga|Orangetown|Orchard Park|Ossining|Oswego|Owego|Oyster Bay|Parma|Patchogue|Patterson|Pearl River|Peekskill|Pelham|Penfield|Perinton|Pittsford|Plainview|Plattsburgh|Pleasantville|Pomfret|Port Chester|Port Washington|Potsdam|Poughkeepsie|Putnam Valley|Queensbury|Queens|Ramapo|Red Hook|Rexford|Ridge|Riverhead|Rochester|Rockville Centre|Rocky Point|Rodman|Rome|Ronkonkoma|Roosevelt|Rotterdam|Rye|Salina|Salisbury|Saranac Lake|Saratoga Springs|Saugerties|Sayville|Scarsdale|Schenectady|Schodack|Seaford|Selden|Setauket-East Setauket|Shawangunk|Shirley|Smithtown|Somers|South Farmingdale|Southampton|Southeast|Southold|Southport|Spring Valley|Staten Island|Stephentown|Stony Brook|Stony Point|St. James|Suffern|Sullivan|Sweden|Syosset|Syracuse|Tarrytown|Terryville|Thompson|Ticonderoga|Tonawanda|Troy|Ulster|Uniondale|Union|Utica|Valley Stream|Van Buren|Vestal|Wallkill|Wantagh|Wappinger|Warwick|Watertown|Watervliet|Wawarsing|Webster|West Babylon|West Haverstraw|West Hempstead|West Islip|West Nyack|West Point|West Seneca|Westbury|Westerlo|Wheatfield|White Plains|Whitestown|Wilton|Woodmere|Wyandanch|Yonkers|Yorktown");
		}
		if (state.contains("North Carolina") || state.contains("NC")) {
			city = Util
					.match(addSec,
							"Sunset Beach|Willow Springs|Stallings|Castle Hayne|Knightdale|Supply|Holden Beach|Holly Ridge|Bolivia|Wesley Chapel|Davie|Forsyth|Marvin|Court King|Clayton|Gibsonville|Oak Ridge|Stanly|Landis|Spencer|Summerfield|Winston- Salem|Glen Lane|Elon|Pineville|Morrisville|Troutman|Locust|McLeansville|Waxhaw|Sherrills Ford|Midland|Wando|Wendell|Pfafftown|Whitsett|Albemarle|Apex|Asheboro|Asheville|Banner Elk|Boone|Burlington|Carrboro|Cary|Chapel Hill|Charlotte|Clemmons|Concord|Cornelius|Creedmoor|Durham|Denver|Dallas|Eden|Elizabeth City|Elm City|Fayetteville|Fort Bragg|Garner|Gastonia|Goldsboro|Graham|Greensboro|Greenville|Havelock|Hendersonville|Henderson|Hertford|Hickory|High Point|Haw River|Hope Mills|Huntersville|Indian Trail|Jacksonville|Kannapolis|Kernersville|Kinston|Laurinburg|Lenoir|Lexington|Lincolnton|Lumberton|Mount Holly|Masonboro|Matthews|Mount HollyMint Hill|Monroe|Mooresville|Morganton|Mount Airy|New Bern|Newton|North Wilkesboro|Piney Green|Pittsboro|Raeford|Raleigh|Reidsville|Roanoke Rapids|Rocky Mount|Rural Hall|Salisbury|Sanford|Sealevel|Shallotte|Shelby|Smithfield|Southern Pines|Southport|Statesville|Tarboro|Thomasville|Wake Forest|Wilmington|Wilson|Winston-Salem|Carolina Shores|Davidson|Belmont|Bunnlevel|Spring Lake|Winston Salem|Swansboro|Sneads Ferry|Zebulon|Leland|Hampstead|Mint Hill|Ogden");
		}
		if (state.contains("North Dakota") || state.contains("ND")) {
			city = Util
					.match(addSec,
							"Bismarck|Dickinson|Fargo|Grand Forks|Gwinner|Jamestown|Mandan|Michigan|Minot|Wahpeton|West Fargo|Williston|Mint Hill");
		}
		if (state.contains("Ohio") || state.contains("OH")) {
			city = Util
					.match(addSec,
							"Akron|Alliance|Amesville|Amherst|Ashland|Ashtabula|Athens|Aurora|Austintown|Avon Lake|Avon|Barberton|Bay Village|Beachwood|Beavercreek|Bedford Heights|Bedford|Bellefontaine|Berea|Bexley|Blue Ash|Boardman|Bowling Green|Brecksville|Bridgetown North|Broadview Heights|Brook Park|Brooklyn|Brunswick|Bucyrus|Cambridge|Canton|Celina|Centerville|Chillicothe|Cincinnati|Circleville|Clayton|Cleveland Heights|Cleveland|Columbus|Conneaut|Continental|Coshocton|Cuyahoga Falls|Dayton|Defiance|Delaware|Dover|Dublin|East Cleveland|East Liverpool|Eastlake|Elyria|Englewood|Euclid|Fairborn|Fairfield|Fairview Park|Findlay|Finneytown|Forest Park|Forestville|Fostoria|Franklin|Fremont|Gahanna|Galion|Garfield Heights|Germantown|Girard|Greenfield|Greenville|Green|Grove City|Hamilton|Hilliard|Huber Heights|Hudson|Ironton|Kent|Kettering|Lakewood|Lancaster|Landen|Langsville|Laurelville|Lebanon|Leipsic|Lima|Lorain|Loveland|Lucasville|Lyndhurst|Mansfield|Maple Heights|Marietta|Marion|Marysville|Mason|Massillon|Maumee|Mayfield Heights|Medina|Mentor|Miamisburg|Middleburg Heights|Middletown|Montgomery|Mount Vernon|Nelsonville|New Philadelphia|Newark|Niles|North Canton|North College Hill|North Olmsted|North Ridgeville|North Royalton|Northbrook|Northfield|Norton|Norwalk|Norwood|Novelty|Oregon|Oxford|Painesville|Parma Heights|Parma|Pataskala|Perrysburg|Piqua|Portsmouth|Ravenna|Rawson|Reading|Reynoldsburg|Richmond Heights|Riverside|Rocky River|Rossburg|Salem|Sandusky|Seven Hills|Shaker Heights|Sharonville|Shiloh|Sidney|Solon|South Euclid|Springboro|Springdale|Springfield|Steubenville|Stow|Streetsboro|Strongsville|Struthers|Sylvania|Tallmadge|Tiffin|Tipp City|Toledo|Trotwood|Troy|Twinsburg|University Heights|Upper Arlington|Urbana|Van Wert|Vandalia|Vermilion|Wadsworth|Warrensville Heights|Warren|Washington|West Carrollton City|Westerville|Westlake|White Oak|Whitehall|Wickliffe|Willard|Willoughby|Willowick|Wilmington|Wooster|Worthington|Xenia|Youngstown|Zanesville");
		}
		if (state.contains("Oklahoma") || state.contains("OK")) {
			city = Util
					.match(addSec,
							"Piedmont|Ada|Altus|Ardmore|Atoka|Bartlesville|Beaver|Bethany|Bixby|Broken Arrow|Chickasha|Chouteau|Claremore|Del City|Duncan|Durant|Edmond|El Reno|Elk City|Enid|Guymon|Lawton|McAlester|Miami|Midwest City|Moore|Muskogee|Mustang|Norman|Nowata|Oklahoma City|Okmulgee|Owasso|Pawhuska|Ponca City|Pryor|Sand Springs|Sapulpa|Seminole|Shawnee|Stillwater|Tahlequah|The Village|Tulsa|Wagoner|Woodward|Yukon|Choctaw");
		}
		if (state.contains("Oregon") || state.contains("OR")) {
			city = Util
					.match(addSec,
							"Clackamas|Albany|Aloha|Altamont|Arlington|Ashland|Baker|Banks|Beaverton|Bend|Burns|Canby|Cannon Beach|Cave Junction|Cedar Mill|Central Point|Chiloquin|Cloverdale|Coos Bay|Corvallis|Cottage Grove|Dallas|Eugene|Forest Grove|Four Corners|Gladstone|Grants Pass|Gresham|Hayesville|Heppner|Hermiston|Hillsboro|Jefferson|Keizer|Klamath Falls|La Grande|Lake Oswego|Lebanon|Lincoln City|Lowell|Lyons|McMinnville|Medford|Mill City|Milwaukie|Newberg|Newport|Oak Grove|Oatfield|Ontario|Oregon City|Pendleton|Portland|Prairie City|Redmond|Roseburg|Salem|Sherwood|Siletz|Silver Lake|Springfield|St. Helens|The Dalles|Tigard|Tillamook|Troutdale|Tualatin|Waldport|West Linn|Wilsonville|Woodburn|Happy Valley|Scappoose|Lancaster|Newtown Square|Bensalem");
		}
		if (state.contains("Pennsylvania") || state.contains("PA")) {
			city = Util
					.match(addSec,
							"Newtown Square|Abington|Aliquippa|Allentown|Altoona|Antrim|Ardmore|Ashville|Aston|Back Mountain|Baldwin|Beaver Springs|Beech Creek|Bellefonte|Bensalem|Berwick|Bethel Park|Bethlehem|Bloomsburg|Blue Bell|Blue Ridge Summit|Boswell|Boyers|Brentwood|Bristol|Broomall|Buckingham|Butler|Caln|Camp Hill|Carlisle|Carnot-Moon|Center|Chambersburg|Cheltenham|Chester|Chestnuthill|Coal|Coatesville|Collegeville|Colonial Park|Columbia|Concordville|Conshohocken|Coolbaugh|Cornwall|Cranberry|Creekside|Cumru|Dallas|Danville|Darby|Derry|Dover|Downingtown|Doylestown|Drexel Hill|Dry Run|Dunmore|East Goshen|East Hempfield|East Lampeter|East Norriton|East Pennsboro|Easton|Easttown|Edinboro|Elizabethtown|Elizabeth|Emmaus|Ephrata|Erie|Exeter|Exton|Fairview|Falls|Ferguson|Fernway|Fort Washington|Franconia|Franklin Park|Frenchville|Fullerton|Genesee|Gettysburg|Greene|Greensburg|Guilford|Hampden|Hampton Township|Hampton|Hanover|Harborcreek|Harleysville|Harrisburg|Harrison Township|Harrison|Hatfield|Haverford|Hazleton|Hempfield|Hermitage|Hershey|Hilltown|Holmes|Hopewell|Horsham|Hustontown|Hyndman|Indiana|Irvine|Irvona|Jeannette|Jersey Shore|Johnstown|Karthaus|King of Prussia|Kingston|Kittanning|Lake Lynn|Lancaster|Langhorne|Lansdale|Lansdowne|Lebanon|Leesport|Levittown|Limerick|Logan|Lower Allen|Lower Burrell|Lower Gwynedd|Lower Macungie|Lower Makefield|Lower Merion|Lower Moreland|Lower Paxton|Lower Pottsgrove|Lower Providence|Lower Salford|Lower Southampton|Loyalsock|Manchester|Manheim|Manor,|Marple|McCandless Township|McCandless|McKeesport|Meadville|Media|Middle Smithfield|Middletown|Mill Hall|Millcreek|Montgomeryville|Montgomery|Moon|Morrisville|Mount Jewett|Mount Lebanon|Mount Pleasant|Mountain Top|Muhlenberg|Muncy Valley|Munhall|Nanticoke|Needmore|Nether Providence Township|Nether Providence|New Britain|New Castle|New Kensington|New Wilmington|Newberry|Newtown|Norristown|North Bend|North Fayette|North Huntingdon|North Lebanon|North Middleton|North Strabane|North Union|North Versailles|North Wales|North Whitehall|Northampton|Nuangola|Oil City|Olanta|Osceola Mills|Palmer|Patton|Penn Hills|Penn|Peters|Philadelphia|Phoenixville|Pittsburgh|Pittston|Plains|Plumstead|Plum|Plymouth|Pottstown|Pottsville|Punxsutawney|Quarryville|Radnor Township|Radnor|Reading|Richland|Ridley|Robinson Township|Robinson|Ronks|Ross Township|Ross|Rostraver|Salisbury|Sandy|Scott Township|Scott|Scranton|Sewickley|Shaler Township|Shaler|Shamokin|Sharon|Shiloh|Silver Spring|Souderton|South Fayette|South Middleton|South Park Township|South Park|South Union|South Whitehall|Southampton|Spring Garden|Spring Grove|Springettsbury|Springfield|Spring|State College|Stroud|St. Marys|Sunbury|Susquehanna|Swatara|Towamencin|Tredyffrin|Trout Run|Twin Rocks|Uniontown|Unity|Upper Allen|Upper Chichester|Upper Darby|Upper Dublin|Upper Gwynedd|Upper Macungie|Upper Merion|Upper Moreland|Upper Providence Township|Upper Providence|Upper Saucon|Upper Southampton|Upper St. Clair|Uwchlan|Valley Forge|Warminster|Warrendale|Warren|Warrington|Warwick|Washington|Wayne|Weigelstown|West Bradford|West Chester|West Deer|West Goshen|West Hempfield|West Lampeter|West Manchester|West Mifflin|West Milton|West Norriton|West Whiteland|Westfield|Westtown|Whitehall|Whitemarsh|White|Whitpain|Wilkes-Barre|Wilkinsburg|Williamsport|Willistown|Willow Grove|Windsor|Woodlyn|Yeadon|York");
		}
		if (state.contains("Rhode Island") || state.contains("RI")) {
			city = Util
					.match(addSec,
							"Barrington|Bristol|Burrillville|Central Falls|Coventry|Cranston|Cumberland|East Greenwich|East Providence|Harrisville|Johnston|Lincoln|Middletown|Narragansett|Newport East|Newport|North Kingstown|North Providence|North Smithfield|Pawtucket|Portsmouth|Providence|Scituate|Smithfield|South Kingstown|Tiverton|Valley Falls|Wakefield|Warren|Warwick|West Warwick|Westerly|Woonsocket");
		}
		if (state.contains("South Carolina") || state.contains("SC")) {
			city = Util
					.match(addSec,
							"Pelzer|Johns Island|Inman|Woodruff|West Ashley|Huger|Simpsonville|Powdersville|Graniteville|Monks Corner|Pineville|Clover|Hopkins|Lyman|Boiling Springs|Wellford|Isle of Palms|Lancaster|Wando|Aiken|Anderson|Beaufort|Berea|Cayce|Charleston|Clemson|Columbia|Conway|Darlington|Dentsville|Easley|Florence|Forest Acres|Gaffney|Gantt|Georgetown|Goose Creek|Greenville|Greenwood|Greer|Hanahan|Hilton Head|Hilton Head Island|Hodges|Honea Path|Irmo|Ladson|Mauldin|Mount Pleasant|Moore|Myrtle Beach|Newberry|North Augusta|North Charleston|North Myrtle Beach|Orangeburg|Parker|Red Hill|Ridgeland|Rock Hill|Seneca|Seven Oaks|Simpsonville|Socastee|Spartanburg|St. Andrews|Summerville|Sumter|Taylors|Wade Hampton|West Columbia|Lake Wylie|Fort Mill|Indian Land|Moncks Corner|Model Homemount Pleasant|James Island|Lexington|Blythewood|Gilbert|Chapin|Elgin|Piedmont|Fountain Inn|Williamston|Duncan|Belton|Ladys Island|Bluffton|Murrells Inlet|Longs|Little River|Surfside Beach|Pawleys Island|Tega Cay|York");
		}
		if (state.contains("South Dakota") || state.contains("SD")) {
			city = Util
					.match(addSec,
							"Aberdeen|Belle Fourche|Beresford|Box Elder|Brandon|Brookings|Canton|Chamberlain|Dell Rapids|Hot Springs|Huron|Lead|Lennox|Madison|Milbank|Mitchell|North Sioux City|Pierre|Rapid City|Redfield|Sioux Falls|Sisseton|Spearfish|Sturgis|Vermillion|Watertown|Winner|Yankton");
		}
		if (state.contains("Tennessee") || state.contains("TN")) {
			city = Util
					.match(addSec,
							"Lenoir City|Pleasant View|Mascot|Corryton|Cleveland|Ardmore|Athens|Bartlett|Bloomingdale|Bolivar|Brentwood|Bristol|Brownsville|Chattanooga|Church Hill|Clarksville|Collierville|Columbia|Cookeville|Crossville|Dickson|Dyersburg|East Brainerd|East Ridge|Elgin|Elizabethton|Farragut|Franklin|Gallatin|Germantown|Goodlettsville|Greeneville|Hendersonville|Jackson|Johnson City|Kingsport|Knoxville|La Vergne|Lawrenceburg|Lebanon|Lewisburg|Madison|Martin|Maryville|McMinnville|Memphis|Middle Valley|Millington|Morristown|Mount Juliet|Mountain City|Murfreesboro|Nashville|Oak Ridge|Red Bank|Sevierville|Shelbyville|Smyrna|Sneedville|Soddy-Daisy|Springfield|Tullahoma|Union City|Cane Ridge|Spring Hill|Nolensville");
		}
		if (state.contains("Texas") || state.contains("TX")) {
			city = Util
					.match(addSec,
							"Pinehurst|Fulshear|Dripping Springs|Bee Cave|Aubrey|Red Oak|New Caney|Argyle|Hackberry|Rosharon|Haslet|Midlothian|Aledo|Lorena|Rosenburg|Spring,|Willis|Lavon|Luling|Ponder|Heath,|Nevada|Anna|Abilene|Addison|Alamo|Aldine|Alice|Allen|Alpine|Alvin|Amarillo|Anderson|Angleton|Arlington|Atascocita|Athens|Austin,|Balch Springs|Bay City|Baytown|Beaumont|Bedford|Beeville|Bellaire|Belton|Benbrook|Big Spring|Boerne|Borger|Brenham|Brownsville|Brownwood|Brushy Creek|Bryan|Burkburnett|Burleson|Canyon Lake|Carrollton|Castroville|Cedar Hill|Cedar Park|Channelview|Channing|Cinco Ranch|Cleburne|Cleveland|Cloverleaf|Clute|College Station|Colleyville|Columbus|Conroe|Converse|Coppell|Copperas Cove|Corinth|Corpus Christi|Corsicana|Cotulla|Cypress|Dallas|Deer Park|Del Rio|Denison|Denton|DeSoto|Dickinson|Donna|Dumas|Duncanville|Eagle Pass|Edinburg|El Campo|El Paso|Euless|Edgecliff Village|Farmers Branch|Flower Mound|Forest Hill|Fort Hood|Fort Worth|Freeport|Friendswood|Frisco|Gainesville|Galena Park|Galveston,|Garland|Gatesville|Georgetown|Gillett|Grand Prairie|Grapevine|Greenville|Groves|Haltom City|Harker Heights|Harlingen|Henderson|Hereford|Hewitt|Hickory Creek|Highland Village|Houston|Humble|Huntsville|Hurst|Irving|Jacinto City|Jacksonville|Jollyville|Katy,|Keller|Kenedy|Kerrville|Kilgore|Killeen|Kingsville|La Homa|La Marque|La Porte|Lake Jackson|Lancaster|Laredo|League City|Leander|Levelland|Lewisville|Lockhart|Longview|Lubbock|Lufkin|Mansfield|Marshall|McAllen|McKinney|Mercedes|Mesquite|Midland|Mineral Wells|Mission Bend|Mission|Missouri City|Mount Pleasant|Nacogdoches|Navasota|Nederland|New Braunfels|New Territory|North Richland Hills|Odessa|Orange|Palestine|Pampa|Paris|Pasadena|Pearland|Pecan Grove|Pflugerville|Pharr|Plainview|Plano|Port Arthur|Port Isabel|Port Lavaca|Port Neches|Portland|Presidio|Raymondville|Richardson|Richmond|Rio Grande City|Roanoke|Robstown|Rockwall|Rosenberg|Round Rock|Round Top|Rowlett|Saginaw|San Angelo|San Antonio|San Benito|San Elizario|San Marcos|Santa Fe|Schertz|Seagoville|Seguin|Sherman|Slaton|Snyder|Socorro|Somerville|South Houston|Southlake|Spring|Stafford|Stamford|Stephenville|Sudan|Sugar Land|Sulphur Springs|Sweetwater|Taylor|Temple|Terrell|Texarkana|Texas City|The Colony|The Woodlands|Three Rivers|Tomball|Tyler|Universal City|University Park|Uvalde|Vernon|Victoria|Vidor|Waco|Watauga|Waxahachie|Weatherford|Wells Branch|Weslaco|West Odessa|West University Place|White Settlement|Wichita Falls|Wilson|Wylie|Elgin|Manor,|Kyle|Briarcreek|Hutto|Bastrop|Sales Office For Info|Spicewood|Oak Point|Princeton|Little Elm|Josephine|Royse City|Van Alstyne|Crossroads|Melissa|Celina|Prosper|Forney|Nevada|Fate|Sachse|Lucas|Horizon City|Jarrell|Azle|Glenn Heights|Northlake|Magnolia|Manvel|Porter|Fresno|Iowa Colony|Montgomery|Cibolo|Troy|Farmersville");
		}
		if (state.contains("Utah") || state.contains("UT")) {
			city = Util
					.match(addSec,
							"Syracuse|Mapleton|Saratoga Springs|Altamont|American Fork|Blanding|Bountiful|Brigham City|Canyon Rim|Cedar City|Centerville|Clearfield|Clinton|Cottonwood Heights|Cottonwood West|Draper|East Millcreek|Farmington|Hatch|Holladay|Kamas|Kanab|Kaysville|Kearns|Layton|Lehi|Logan|Magna|Midvale|Millcreek|Monroe|Morgan|Murray|North Ogden|Ogden|Oquirrh|Orem|Park City|Payson|Pleasant Grove|Provo|Richfield|Riverton|Roy|Salt Lake City|Sandy|South Jordan|South Ogden|South Salt Lake|Spanish Fork|Springville|St. George|Taylorsville|Tooele|Vernal|West Jordan|West Valley City|Herriman|Bluffdale|South Weber|Highland|North Salt Lake|Saratoga,");
		}
		if (state.contains("Vermont") || state.contains("VT")) {
			city = Util
					.match(addSec,
							"Barton|Bennington|Brattleboro|Burlington|Canaan|Chester|Colchester|East Montpelier|Eden|Essex Junction|Essex|Fair Haven|Hartford|Middlebury|Montpelier|Morrisville|Poultney|Readsboro|Rutland|South Burlington|Townshend");
		}
		if (state.contains("Virginia") || state.contains("VA")) {
			city = Util
					.match(addSec,
							"Aldie|Alexandria|Annandale|Arlington|Bailey's Crossroads|Blacksburg|Bon Air|Bowling Green|Boydton|Bristol|Bull Run|Burke|Carrsville|Cave Spring|Centreville|Chantilly|Charlottesville|Chesapeake|Chester|Chincoteague|Christiansburg|Colonial Heights|Dale City|Danville|Dillwyn|East Highland Park|Fairfax|Falls Church|Farmville|Floyd|Stafford|Ford|Fort Hunt|Franconia|Fredericksburg|Front Royal|Glen Allen|Goochland|Groveton|Grundy|Hampton|Harrisonburg|Herndon|Highland Springs|Hollins|Hopewell|Hybla Valley|Idylwood|Jefferson|Keswick|King George|Lake Ridge|Lakeside|Laurel|Leesburg|Lincolnia|Lorton|Louisa|Lynchburg|Madison Heights|Madison|Manassas Park|Manassas|Martinsville|McLean|Meadowview|Mechanicsville|Merrifield|Middletown|Midlothian|Montclair|Montross|Mount Vernon|Newington|Newport News|Norfolk|Norton|Oak Hall|Oakton|Orange|Petersburg|Poquoson|Portsmouth|Purcellville|Quantico|Radford|Red Ash|Reston|Richmond|Roanoke|Rose Hill|Roseland|Salem|Saluda|Scottsville|Sperryville|Springfield|Staunton|Suffolk|Tazewell|Timberlake|Tuckahoe|Tysons Corner|Unionville|Vienna|Virginia Beach|Waynesboro|West Point|West Springfield|Williamsburg|Winchester|Wolf Trap|Woodbridge|Yorktown|Gainesville|Ashburn|Dumfries|Dulles|Oak Hill|Dunn Loring");
		}
		if (state.contains("Washington") || state.contains("WA")) {
			city = Util
					.match(addSec,
							"Cle Elum|Granite Falls|Bainbridge Island|Graham|Edgewood|Ridgefield|Battle Ground|Orting|Aberdeen|Alderwood Manor|Anacortes|Arlington|Auburn|Bainbridge Island|Bellevue|Bellingham|Bothell|Bow|Bremerton|Bryn Mawr-Skyway|Burien|Camano|Camas|Cascade-Fairwood|Centralia|Cottage Lake|Covington|Creston|Des Moines|Dishman|East Hill-Meridian|East Renton Highlands|East Wenatchee Bench|Edmonds|Elk Plain|Ellensburg|Enumclaw|Everett|Farmington|Federal Way|Five Corners|Fort Lewis|Hadlock|Harrington|Hunters|Inglewood-Finn Hill|Issaquah|Kelso|Kenmore|Kennewick|Kent|Kettle Falls|Kingsgate|Kirkland|Lacey|Lacrosse|Lake Forest Park|Lakebay|Lakeland North|Lakeland South|Lakewood|Lea Hill|Long Beach|Longview|Lynnwood|Maple Valley|Martha Lake|Marysville|Mercer Island|Mill Creek|Monroe|Moses Lake|Mount Vernon|Mountlake Terrace|Mukilteo|Naches|Nine Mile Falls|North Creek|North Marysville|Oak Harbor|Odessa|Olympia|Opportunity|Orchards|Othello|Paine Field-Lake Stickney|Parkland|Pasco|Picnic Point-North Lynnwood|Port Angeles|Port Orchard|Prairie Ridge|Pullman|Puyallup|Quincy|Redmond|Renton|Richland|Riverton-Boulevard Park|Rosalia|Salmon Creek|Sammamish|SeaTac|Seattle Hill-Silver Firs|Seattle,|Sequim|Shoreline|Silverdale|South Hill|Spanaway|Spokane|Sprague|Sunnyside|Tacoma|Tukwila|Tumwater|Union Hill-Novelty Hill|University Place|Valleyford|Vancouver|Vashon|Walla Walla|Wenatchee|West Lake Stevens|Lake Stevens|West Valley|White Center|Winthrop|Yakima|Woodinville|Bonney Lake|Snohomish");
		}
		if (state.contains("West Virginia") || state.contains("WV")) {
			city = Util
					.match(addSec,
							"Martinsburg|Berkeley|Aurora|Beckley|Bluefield|Burnsville|Charleston|Clarksburg|Cross Lanes|Fairmont|French Creek|Harpers Ferry|Huntington|Kingwood|Lewisburg|Martinsburg|Morgantown|Parkersburg|Paw Paw|Pineville|Princeton|Rivesville|Rock Cave|Slatyfork|South Charleston|St. Albans|Teays Valley|Vienna|Weirton|Wheeling|White Sulphur Springs");
		}
		if (state.contains("Wisconsin") || state.contains("WI")) {
			city = Util
					.match(addSec,
							"Allouez|Amery|Appleton|Ashwaubenon|Baraboo|Beaver Dam|Bellevue Town|Bellevue|Beloit|Bonduel|Brookfield|Brown Deer|Brownsville|Caledonia|Camp Douglas|Cedarburg|Chippewa Falls|Columbus|Cudahy|Dallas|De Pere|De Soto|Dodgeville|Eau Claire|Ellsworth|Ferryville|Fitchburg|Fond du Lac|Fort Atkinson|Franklin|Friendship|Germantown|Glendale|Glenwood City|Grafton|Grand Chute|Green Bay|Greendale|Greenfield|Hales Corners|Hartford|Howard|Iola|Janesville|Kaukauna|Kenosha|Krakow|La Crosse|Lena|Little Chute|Madison|Manitowoc|Marinette|Marshfield|Mason|Menasha|Menomonee Falls|Menomonie|Mequon|Merrill|Middleton|Milwaukee|Mondovi|Monroe|Mount Pleasant|Muskego|Neenah|New Berlin|New Holstein|Oak Creek|Oconomowoc|Onalaska|Oshkosh|Pewaukee|Pleasant Prairie|Plover|Port Washington|Racine|Randolph|Richfield|River Falls|Sheboygan|Shorewood|Somerset|South Milwaukee|Stevens Point|Stoughton|Sun Prairie|Superior|Two Rivers|Viola|Watertown|Waukesha|Waupun|Wausau|Wauwatosa|West Allis|West Bend|Weston|Whitefish Bay|Whitewater|Winter|Wisconsin Rapids");
		}
		if (state.contains("Wyoming") || state.contains("WY")) {
			city = Util
					.match(addSec,
							"Casper|Cheyenne|Cody|Evanston|Gillette|Green River|Laramie|Rock River|Rock Springs|Sheridan|Basin|Buffalo|Douglas|Kemmerer|Lander|Newcastle|Powell|Rawlins|Riverton|Torrington|Worland");
		}
		return city;
	}

	static String commUrl = "";

	
	public static String getHardcodedAddress(String builderName, String comUrl)
			throws Exception {
		commUrl = comUrl;
		String newFile = HARDCODED_FILES_PATH + builderName
				+ ".csv";
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {
				// U.log(newCsvRow.size());
				// builderName=newCsvRow.get(1);

				String aaa = getBuilderObj(newCsvRow);
				if (aaa != null)
					return aaa;
			}
			count++;
		}

		newFileReader.close();
		return null;
	}

	public static String getBuilderObj(List<String> newCsvRow) {

		if (commUrl.contains(newCsvRow.get(1).trim())) {
			return (newCsvRow.get(2) + "," + newCsvRow.get(3) + ","
					+ newCsvRow.get(4) + "," + newCsvRow.get(5) + ","
					+ newCsvRow.get(6) + "," + newCsvRow.get(7) + ","
					+ newCsvRow.get(8) + "," + newCsvRow.get(9) + "," + newCsvRow
						.get(13)

			);
		}
		return null;

	}

	public static String sendComment(ArrayList<String> newCsvRow)
			throws InterruptedException {
		StringBuilder sb = new StringBuilder();
		// U.log(newCsvRow.size());
		for (int i = 1; i < newCsvRow.size(); i++) {

			if (newCsvRow.get(i).trim().replace("-", "").length() < 1) {
				// U.log(i+"==="+newCsvRow.get(i).trim());
				// Thread.sleep(4000);
				switch (i) {

				case 1:
					if (sb.length() > 3)
						sb.append(",Builder Name has Blank");
					else
						sb.append("Builder Name has Blank");
					break;

				case 2:
					if (sb.length() > 3)
						sb.append(",Builder URL has Blank");
					else
						sb.append("Builder URL has Blank");
					break;

				case 3:
					if (sb.length() > 3)
						sb.append(",Community Name has Blank");
					else
						sb.append("Community Name has Blank");
					break;

				case 4:
					if (sb.length() > 3)
						sb.append(",Community URL has Blank");
					else
						sb.append("Community URL has Blank");
					break;

				case 5:
					if (sb.length() > 3)
						sb.append(",Community Type has Blank");
					else
						sb.append("Community Type has Blank");
					break;

				case 6:
					if (sb.length() > 3)
						sb.append(",Address has Blank");
					else
						sb.append("address has Blank");
					break;

				case 7:
					if (sb.length() > 3)
						sb.append(",City has Blank");
					else
						sb.append("City has Blank");
					break;

				case 8:
					if (sb.length() > 3)
						sb.append(",State has Blank");
					else
						sb.append("State has Blank");
					break;

				case 9:
					if (sb.length() > 3)
						sb.append(",Zip has Blank");
					else
						sb.append("zip has Blank");
					break;

				case 10:
					if (sb.length() > 3)
						sb.append(",Lattitude and longitude has Blank");
					else
						sb.append("Lattitude and longitude has Blank");
					break;

				case 12:
					if (sb.length() > 3)
						sb.append(",Geo code has Blank");
					else
						sb.append("Geo code has Blank");
					break;

				case 13:
					if (sb.length() > 3)
						sb.append(",Property type has Blank");
					else
						sb.append("Property type has Blank");
					break;

				case 14:
					if (sb.length() > 3)
						sb.append(",Derived property type has Blank");
					else
						sb.append("Derived property type has Blank");
					break;

				case 15:
					if (sb.length() > 3)
						sb.append(",Property Status has Blank");
					else
						sb.append("Property Status has Blank");
					break;

				case 16:
					if (sb.length() > 3)
						sb.append(",Min Price value has Blank");
					else
						sb.append("Min Price value has Blank");
					break;

				case 17:
					if (sb.length() > 3)
						sb.append(",Max Price value has Blank");
					else
						sb.append("Max Price value has Blank");
					break;

				case 18:
					if (sb.length() > 3)
						sb.append(",Min sqft value has Blank");
					else
						sb.append("Min sqft value has Blank");
					break;

				case 19:
					if (sb.length() > 3)
						sb.append(",Max sqft value has Blank");
					else
						sb.append("Max sqft value has Blank");
					break;

				default:
					break;
				}
			}
		}
		return sb.toString();
	}
	
	public static boolean isvalideLatLng(String add[], String lat, String lng)
			throws Exception {

		// ChromeDriver driver2;
		if (lat != "" || lat == null) {
			String link = "https://maps.google.com/maps?q=" + lat + "," + lng;
			String htm = U.getHTML(link);
			String gAdd[] = U.getGoogleAddress(htm);
			U.log(gAdd[0] + " " + gAdd[1] + " " + gAdd[2] + " " + gAdd[3]);
			if (gAdd[3].equals(add[3]))
				return true;
			else if (gAdd[1].equalsIgnoreCase(add[1])
					&& gAdd[2].equalsIgnoreCase(add[2])) {
				return true;
			}

			else {
				// http://maps.yahoo.com/place/?lat=37.71915&lon=-121.845803&q=37.71915%2C-121.845803
				link = "http://maps.yahoo.com/place/?lat=" + lat + "&lon="
						+ lng + "&q=" + lat + "," + lng;

				ShatamChrome driver1 = ShatamChrome.getInstance();

				driver1.open(link);
				driver1.getOne("#yucs-sprop_button").click();
				htm = driver1.getHtml();

				// driver2 = new ChromeDriver();
				// driver2.
				String url = driver.getUrl();
				U.log(url);

				URLDecoder decode = new URLDecoder();
				try {
					url = URLDecoder.decode(url, "UTF-8");
					U.log("Address:" + url);
					U.log(add[0] + " " + add[1] + " " + add[2] + " " + add[3]);
					if (url.contains(add[1]))
						return true;
					if (url.contains(add[3]))
						return true;
				} catch (UnsupportedEncodingException ex) {
					ex.printStackTrace();
				}
				// decode.decode(url);
				// U.log(url);
				// driver.close();
			}
			return false;
			// if(gAdd[1])
		}
		return false;
	}

private static HttpURLConnection getConn1(String urlPath,
			HashMap<String, String> customHeaders) throws IOException {

		URL url = new URL(urlPath);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.addRequestProperty("User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Chrome/10.0.2");
		conn.addRequestProperty("Accept",
				"text/css,application/xhtml+xml,application/xml,*/*;q=0.9");
		conn.addRequestProperty("Accept-Language", "en-us,en;q=0.5");
		conn.addRequestProperty("Cache-Control", "max-age=0");
		conn.addRequestProperty("Connection", "keep-alive");

		if (customHeaders == null || !customHeaders.containsKey("Referer")) {
			conn.addRequestProperty("Referer", "http://" + url.getHost());
		}
		if (customHeaders == null || !customHeaders.containsKey("Host")) {
			conn.addRequestProperty("Host", url.getHost());
		}

		if (customHeaders != null) {
			for (String headerName : customHeaders.keySet()) {
				conn.addRequestProperty(headerName,
						customHeaders.get(headerName));
			}
		}

		return conn;
	}// getConn


	public static String[] getLatLngBingMap1(String add[]) throws Exception {

		String addr = add[0] + " " + add[1] + " " + add[2] + " " + add[3];
		ShatamChrome driver1 = null;
		String bingLatLng[] = { "", "" };
		driver1 = ShatamChrome.getInstance();
		driver1.open("http://localhost/bing.html");
		driver1.wait("#txtWhere");
		driver1.getOne("#txtWhere").sendKeys(addr);
		driver1.wait("#btn");
		driver1.getOne("#btn").click();
		String binghtml = driver1.getHtml();
		// driver.wait(1000);
		U.log(binghtml);
		String secmap = U.getSectionValue(binghtml, "<div id=\"resultsDiv\"",
				"</body>");
		bingLatLng[0] = U.getSectionValue(secmap,
				"<span id=\"span1\">Latitude:", "<br>").trim();
		bingLatLng[1] = U.getSectionValue(secmap, "<br>Longitude:", "</span>");

		U.log("lat:" + bingLatLng[0]);
		U.log("lng:" + bingLatLng[1]);
		return bingLatLng;
	}

	public static String[] getCoordinatesGoogleApi(String add[])
			throws IOException {
		String addr = add[0].trim() + "," + add[1].trim() + "," + add[2].trim();
		addr = "https://maps.googleapis.com/maps/api/geocode/json?address="// 1138
																			// Waterlyn
																			// Drive","Clayton","NC
				+ URLEncoder.encode(addr, "UTF-8");
		U.log(addr);
		String html = U.getHTML(addr);
		String locationSec = U.getSectionValue(html, "location\" : {", "}");
		String lat = U.getSectionValue(locationSec, "\"lat\" :", ",");
		String lng = Util.match(locationSec, "lng\" : (\\-\\d+\\.\\d+)", 1);

		locationSec = U.getSectionValue(html, "northeast\" : {", "}");
		String nLat = U.getSectionValue(locationSec, "\"lat\" :", ",");
		String nLng = Util.match(locationSec, "lng\" : (\\-\\d+\\.\\d+)", 1);

		locationSec = U.getSectionValue(html, "southwest\" : {", "}");
		String sLat = U.getSectionValue(locationSec, "\"lat\" :", ",");
		String sLng = Util.match(locationSec, "lng\" : (\\-\\d+\\.\\d+)", 1);

		String latlng[] = { lat, lng, sLat, sLng, nLat, nLng };

		return latlng;
	}

	public static String[] getCoordinatesZip(String zip) throws IOException {
		// addr = add[0].trim() + "," + add[1].trim() + "," + add[2].trim();
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?address="// 1138
																					// Waterlyn
																					// Drive","Clayton","NC
				+ URLEncoder.encode(zip, "UTF-8");
		U.log(addr);
		String html = U.getHTML(addr);
		String locationSec = U.getSectionValue(html, "location\" : {", "}");
		String lat = U.getSectionValue(locationSec, "\"lat\" :", ",");
		String lng = Util.match(locationSec, "lng\" : (\\-\\d+\\.\\d+)", 1);

		locationSec = U.getSectionValue(html, "northeast\" : {", "}");
		String nLat = U.getSectionValue(locationSec, "\"lat\" :", ",");
		String nLng = Util.match(locationSec, "lng\" : (\\-\\d+\\.\\d+)", 1);

		locationSec = U.getSectionValue(html, "southwest\" : {", "}");
		String sLat = U.getSectionValue(locationSec, "\"lat\" :", ",");
		String sLng = Util.match(locationSec, "lng\" : (\\-\\d+\\.\\d+)", 1);

		String latlng[] = { sLat, sLng, nLat, nLng };

		return latlng;
	}

	public static String getHardcodedAddress1(String builderName, String comUrl)
			throws Exception {
		commUrl = comUrl;
		String newFile = HARDCODED_FILES_PATH + builderName
				+ ".csv";
		CsvListReader newFileReader = new CsvListReader(
				new FileReader(newFile), CsvPreference.STANDARD_PREFERENCE);
		List<String> newCsvRow = null;
		int count = 0;
		while ((newCsvRow = newFileReader.read()) != null) {

			if (count > 0) {
				// U.log(newCsvRow.size());
				// builderName=newCsvRow.get(1);

				String aaa = getBuilderObj(newCsvRow);
				if (aaa != null)
					return aaa;
			}
			count++;
		}

		newFileReader.close();
		return null;
	}

	
	public static String getHTMLwithProxy(String path) throws IOException {

		// System.setProperty("http.proxyHost", "104.130.132.119");
		// System.setProperty("http.proxyPort", "3128");
		//System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
		path = path.replaceAll(" ", "%20");
		// U.log(" .............."+path);
		// Thread.sleep(4000);
		String fileName = getCache(path);

		//U.log("filename:::" + fileName);

		File cacheFile = new File(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);

		URL url = new URL(path);

		String html = null;

		// chk responce code

		// int respCode = CheckUrlForHTML(path);
		// U.log("respCode=" + respCode);

		{
			
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
					"164.155.149.1",80));//"70.102.86.204", 	8080)   "68.183.98.123	",3128 
			final URLConnection urlConnection = url.openConnection(proxy);

			// Mimic browser
			try {
				urlConnection
						.addRequestProperty("User-Agent",
								"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2");
				urlConnection
						.addRequestProperty("Accept", "text/css,*/*;q=0.1");
				urlConnection.addRequestProperty("Accept-Language",
						"en-us,en;q=0.5");
				urlConnection.addRequestProperty("Cache-Control", "max-age=0");
				urlConnection.addRequestProperty("Connection", "keep-alive");
				// U.log("getlink");
				final InputStream inputStream = urlConnection.getInputStream();

				html = IOUtils.toString(inputStream);
				// final String html = toString(inputStream);
				inputStream.close();

				if (!cacheFile.exists())
					FileUtil.writeAllText(fileName, html);

				return html;
			} catch (Exception e) {
				U.log(e);

			}
			return html;
		}

	}
	public static String sendPostRequestAcceptJson(String requestUrl, String payload) throws IOException {
		String fileName=U.getCache(requestUrl+payload);
		File cacheFile = new File(fileName);
//		log(fileName);
		if (cacheFile.exists())
			return FileUtil.readAllText(fileName);
		StringBuffer jsonString = new StringBuffer();
	    try {
	        URL url = new URL(requestUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("Accept", "application/json");
	        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
//	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=\"UTF-8\"");
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
	        writer.write(payload);
	        writer.close();
	        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        String line;
	        while ((line = br.readLine()) != null) {
	                jsonString.append(line);
	        }
	        br.close();
	        connection.disconnect();
	    } catch (Exception e) {
	            throw new RuntimeException(e.getMessage());
	    }
	    if (!cacheFile.exists())
			FileUtil.writeAllText(fileName, jsonString.toString());
	    return jsonString.toString();
	}
	
	static {
	    disableSslVerification();
	}
	private static void disableSslVerification() {
	    try
	    {
	        // Create a trust manager that does not validate certificate chains
	        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
				@Override
				public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
					// TODO Auto-generated method stub
				}
				@Override
				public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
					// TODO Auto-generated method stub
				}
	        }
	        };
	        // Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (KeyManagementException e) {
	        e.printStackTrace();
	    }
	}
	public static final String hereApiID="aGa8KgrWvrUCGqoLCSL9";
	public static final String hereApiCode="Va551VVoWCaWx7JIMok8eA";
	public static String[] getlatlongHereApi(String add[]) throws IOException {
		String addr = add[0] + "," + add[1] + "," + add[2];
		addr = "https://geocoder.api.here.com/6.2/geocode.json?searchtext=" + URLEncoder.encode(addr, "UTF-8") + "&app_id=" + hereApiID + "&app_code=" + hereApiCode + "&gen=9";
		U.log(addr);
		U.log(U.getCache(addr));
		String html = U.getHTML(addr);
		String sec = U.getSectionValue(html, "\"DisplayPosition\":{", "\"NavigationPosition\":");
		if(sec == null) return null;
		
		String lat = U.getSectionValue(sec, "\"Latitude\":", ",");
		if (lat != null)
			lat = lat.trim();
		String lng = U.getSectionValue(sec, "\"Longitude\":", "}");
		if (lng != null)
			lng = lng.trim();
		String latlng[] = { lat, lng };
		// U.log(lat);
		return latlng;
		
	}
	
	public static String[] getAddressHereApi(String latlng[])throws Exception {
		String st = latlng[0].trim() + "%2C" + latlng[1].trim() + "%2C100&mode=retrieveAddresses&maxresults=1&gen=9&app_id=" + hereApiID + "&app_code=" + hereApiCode;
		String addr = "https://reverse.geocoder.api.here.com/6.2/reversegeocode.json?prox="+ st;
		U.log(addr);
		U.log(U.getCache(addr));
		String html = U.getPageSource(addr);
		String txt = U.getSectionValue(html, "\"Address\":{\"Label\":\"", "\"");
		U.log("txt:: " + txt);
		if (txt != null)
			txt = txt.trim();
		txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "");
		txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
		txt = txt.replaceAll(
						"Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,",
						"");
		String[] add = txt.split(",");
		if(add.length==5){
			String newAdd [] = {"","","",""};
			if(Util.match(add[3], "\\d{5}") != null){
				newAdd[0]=add[0]+","+add[1];
				newAdd[1] = add[2].trim();
				newAdd[3] = Util.match(add[3], "\\d+");
				newAdd[2] = add[3].replaceAll("\\d+", "").trim();
			}else{
				newAdd[0]=add[0].trim();
				newAdd[1] = add[1].trim();
				newAdd[3] = Util.match(add[2], "\\d+");
				newAdd[2] = add[2].replaceAll("\\d+", "").trim();
			}
			return newAdd;
		}else if( add.length == 3) {
			String newAdd [] = {"","","",""};
			if(add[2].contains("United States")){
				
				newAdd[3] = Util.match(add[1], "\\d+");
				newAdd[2] = add[1].replaceAll("\\d+", "").trim();
				if(newAdd[2] != null && newAdd[3] == null)
					return null;
				else if(newAdd[2] != null && newAdd[3] != null)
					newAdd[1] = add[0];			
			}
			return newAdd;
		}
		else{
			add[1]=add[1].trim();
			add[3] = Util.match(add[2], "\\d+");
			add[2] = add[2].replaceAll("\\d+", "").trim();
			return add;
		}
	}

	public static String getGoogleZipFromAddressWithKey(String inputadd[]) throws IOException {
	
		String st = inputadd[0].trim() + "," + inputadd[1].trim() + "," + inputadd[2].trim();
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?address=" + st
				+ "&key=AIzaSyDhsO7Ska4s4zUW_68R1n8OhRHJuZP5gm8";
		U.log(addr);
	
		U.log(U.getCache(addr));
		String html = U.getHTML(addr);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
	
		if (status.trim().equals("OK")) {
			String txt = U.getSectionValue(html, "formatted_address\" : \"", "\"");
			U.log("Address txt Using gmap key :: " + txt);
			if (txt != null)
				txt = txt.trim();
			txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "").replace("50 Biscayne, 50", "50");
			txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
			txt = txt.replaceAll(
					"Suite CNewark, |Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,",
					"");
			String[] add = txt.split(",");
			add[3] = Util.match(add[2], "\\d+");
			add[2] = add[2].replaceAll("\\d+", "").trim();
			return add[3];
		} else {
			return "-";
		}
	}

	public static String getRedirectedURL( String mainDomain,String url) throws IOException {
		if(!url.contains("http"))url = mainDomain+url;
	    HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
	    con.setInstanceFollowRedirects(false);
	    con.connect();
	    con.getInputStream();
	    
//	    U.log("response code : "+con.getResponseCode());
	    if (con.getResponseCode() == HttpURLConnection.HTTP_MOVED_PERM || con.getResponseCode() == HttpURLConnection.HTTP_MOVED_TEMP) {
	        String redirectUrl = con.getHeaderField("Location");
	        return getRedirectedURL(mainDomain,redirectUrl);
	    }
	    return url;
	}
	
	public static String[] getNewBingLatLong(String[] address) {
		// TODO Auto-generated method stub
		
			String[] latLong = new String[2];
			String addressLine=address[0]+","+address[1]+","+address[2]+","+address[3];
			if (addressLine == null || addressLine.trim().length() == 0)
				return null;
			addressLine = addressLine.trim().replaceAll("\\+", " ");
			String geocodeRequest = "http://dev.virtualearth.net/REST/v1/Locations/'"
					+ addressLine
					+ "'?o=xml&key=AninuaBy5n6ekoNCLHltcvwcnBGA7llKkNDBNO5XOuHNHJKAyo0BQ8jH_AhhP6Gl";
			// U.log("-----------------addressline-----------"+geocodeRequest);
			try
			{
			String xml = U.getHTML(geocodeRequest);
			// U.log("--------------------------xml---------------------------------"+xml);
			latLong[0] = U.getSectionValue(xml, "<Latitude>", "</Latitude>");
			latLong[1] = U.getSectionValue(xml, "<Longitude>", "</Longitude>");
			}catch (Exception e) {
				e.printStackTrace();
			}
			return latLong;
		
	}
	
	public static String[] getNewBingAddress(String[] latlong) {
		// TODO Auto-generated method stub
		
		String[] addr = null;
		try {
			String url = "http://dev.virtualearth.net/REST/v1/Locations/"
					+ latlong[0]
					+ ","
					+ latlong[1]
					+ "?o=json&jsonp=GeocodeCallback&key=AninuaBy5n6ekoNCLHltcvwcnBGA7llKkNDBNO5XOuHNHJKAyo0BQ8jH_AhhP6Gl";
//		U.log(url);
		U.log(U.getCache(url));
		String htm = U.getHTML(url);
		String[] adds = U.getValues(htm, "formattedAddress\":\"", "\"");
		U.log(htm);
		for (String item : adds) {
			addr = U.getAddress(item);
			if (addr == null || addr[0] == "-")
				continue;
			else {
				U.log("Bing Address =>  Street:" + addr[0] + " City :"
						+ addr[1] + " state :" + addr[2] + " ZIP :" + addr[3]);
				return addr;
			}

		}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return addr;
	}
	
	
	/// New code
	
	
	public static String[] getGoogleAddressWithKeyUpdated(String latLng[]) throws Exception{
		
		String st = latLng[0].trim() + "," + latLng[1].trim();
		String addr = "https://maps.googleapis.com/maps/api/geocode/json?latlng="+ st;
		String key = "AIzaSyAeG9lLU8fWh8rWcPivHDwxLAM4ZCInpmk";
		String[] add = {"-","-","-","-"};
		U.log("With key"+U.getCache(addr));
		String html = U.getHTMLForGoogleApiWithKey(addr,key);
		String status = U.getSectionValue(html, "status\" : \"", "\"");
		
		if(status.trim().equals("OK")){
			String addresses[] = U.getValues(html, "\"address_components\"", "\"location_type\"");
			U.log(addresses.length);
			for(String address: addresses) {	
			String txt = U.getSectionValue(address, "formatted_address\" : \"", "\"");
			U.log("Address txt Using gmap key updated:: " + txt);
			if (txt != null)
				txt = txt.trim();
			txt = txt.replaceAll("The Arden, |TPC Sugarloaf Country Club, ", "").replace("50 Biscayne, 50", "50");
			txt = txt.replaceAll("110 Neuse Harbour Boulevard, ", "");
			txt = txt
					.replaceAll(
							"Waterview Tower, |Liberty Towers, |THE DYLAN, |Cornerstone, |Roosevelt Towers Apartments, |Zenith, |The George Washington University,|Annapolis Towne Centre, |Waugh Chapel Towne Centre,|Brookstone, |Rockville Town Square Plaza, |University of Baltimore,|The Galleria at White Plains,|Reston Town Center,",
							"");
			add = txt.split(",");
			if(add.length>3) {
				add[3] = Util.match(add[2], "\\d+");
				add[2] = add[2].replaceAll("\\d+", "").trim();
				break;
			}
			if(add.length>3)break;
			}
			return add;
		}else{
			return new String[]{"","","",""};
		}
	}
	
	
	
	public static void deleteFile(String FileName) {
		File file = new File(FileName);
		if (file.delete()) {
			log("Successfully Deleted");
		}
	}
	
	
	
	public static String getStateAbbr(String state) {
		if (state.trim().contains("Alabama") || state.contains("AL")) 
				return "AL";
		if (state.contains("Alaska") || state.contains("AK")) 
			    return "AK";
		if (state.contains("Arizona") || state.contains("AZ")) 
			    return "AZ";
		if (state.contains("Arkansas") || state.contains("AR"))
			return "AR";
		
		if (state.contains("California") || state.contains("CA")) 
			return "CA";
		
		if (state.contains("Colorado") || state.contains("CO")) 
			return "CO";
		
		if (state.contains("Connecticut") || state.contains("CT")) 
			return "CT";
		if (state.contains("Delaware") || state.contains("DE")) 
			return "DE";
		if (state.contains("Florida") || state.contains("FL"))
			return "FL";
		
		if (state.contains("Georgia") || state.contains("GA")) 
			return "GA";
		if (state.contains("Hawaii") || state.contains("HI")) 
			return "HI";
		if (state.contains("Idaho") || state.contains("ID")) 
			return "ID";
		
		if (state.contains("Illinois") || state.contains("IL")) 
			return "IL";
		if (state.contains("Indiana") || state.contains("IN")) 
			return "IN";
		if (state.contains("Iowa") || state.contains("IA"))
			return "IA";
		if (state.contains("Kansas") || state.contains("KS")) 
			return "KS";
		if (state.contains("Kentucky") || state.contains("KY")) 
			return "KY";
		if (state.contains("Louisiana") || state.contains("LA")) 
			return "LA";
		if (state.contains("Maine") || state.contains("ME")) 
			return "ME";
		if (state.contains("Maryland") || state.contains("MD")) 
			return "MD";
		if (state.contains("Massachusetts") || state.contains("MA")) 
			return "MA";
		if (state.contains("Michigan") || state.contains("MI")) 
			return "MI";
		if (state.contains("Minnesota") || state.contains("MN")) 
			return "MN";
		if (state.contains("Mississippi") || state.contains("MS"))
			return "MS";
		if (state.contains("Missouri") || state.contains("MO")) 
			return "MO";
		if (state.contains("Montana") || state.contains("MT")) 
			return "MT";
		if (state.contains("Nebraska") || state.contains("NE")) 
			return "NE";
		if (state.contains("Nevada") || state.contains("NV")) 
			return "NV";
		if (state.contains("New Hampshire") || state.contains("NH"))
			return "NH";
		if (state.contains("New Jersey") || state.contains("NJ"))
			return "NJ";
		if (state.contains("New Mexico") || state.contains("NM")) 
			return "NM";
		if (state.contains("New York") || state.contains("NY"))
			return "NY";
		if (state.contains("North Carolina") || state.contains("NC"))
			return "NC";
		if (state.contains("North Dakota") || state.contains("ND")) 
			return "ND";
		if (state.contains("Ohio") || state.contains("OH")) 
			return "OH";
		if (state.contains("Oklahoma") || state.contains("OK"))
			return "OK";
		if (state.contains("Oregon") || state.contains("OR")) 
			return "OR";
		if (state.contains("Pennsylvania") || state.contains("PA")) 
			return "PA";
		if (state.contains("Rhode Island") || state.contains("RI")) 
			return "RI";
		if (state.contains("South Carolina") || state.contains("SC")) 
			return "SC";
		if (state.contains("South Dakota") || state.contains("SD")) 
			return "SD";
		if (state.contains("Tennessee") || state.contains("TN")) 
			return "TN";
		if (state.contains("Texas") || state.contains("TX"))
			return "TX";
		if (state.contains("Utah") || state.contains("UT")) 
			return "UT";
		if (state.contains("Vermont") || state.contains("VT")) 
			return "VT";
		if (state.contains("Virginia") || state.contains("VA"))
			return "VA";
		if (state.contains("Washington") || state.contains("WA")) 
			return "WA";
		if (state.contains("West Virginia") || state.contains("WV")) 
			return "WV";
		if (state.contains("Wisconsin") || state.contains("WI")) 
			return "WI";
		if (state.contains("Wyoming") || state.contains("WY")) 
			return "WY";
		else
			return null;
	}
}