package com.shatam.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


public class demo {

	/**
	 * @param args
	 */
	
		 
	 
	        
	       // dgetHtml(ftpProxy, null);
	       
	          //  driver.close();
	       
	   
	 
	    public static DesiredCapabilities addProxyCapabilities(DesiredCapabilities capability, String httpProxy, String sslProxy,
	            String ftpProxy) {
	        Proxy proxy = new Proxy();
	        proxy.setProxyType(ProxyType.MANUAL);
	        proxy.setHttpProxy(httpProxy);
	        proxy.setSslProxy(sslProxy);
	        proxy.setFtpProxy(ftpProxy);
	 
	        capability.setCapability(CapabilityType.PROXY, proxy);
	        capability.setCapability(CapabilityType.BROWSER_NAME, true);
	        return capability;
	    }


public static String dgetHtml(String url, WebDriver driver) throws Exception {
	// WebDriver driver = new FirefoxDriver();
	String httpProxy = "107.151.136.218:80";
    String sslProxy = "107.151.136.218:80";
    String ftpProxy = "107.151.136.218:80";
    DesiredCapabilities capability = new DesiredCapabilities();
    addProxyCapabilities(capability, httpProxy, sslProxy, ftpProxy);
	String html = null;
	String Dname = null;
	String host = new URL(url).getHost();
	host = host.replace("www.", "");
	int dot = host.indexOf("/");
	Dname = (dot != -1) ? host.substring(0, dot) : host;
	File folder = null;

	folder = new File("/home/sahil/Cache/" + Dname);
	if (!folder.exists())

		folder.mkdirs();
	String fileName = U.getCacheFileName(url);

	fileName = "/home/sahil/Cache/" + Dname + "/" + fileName;

	File f = new File(fileName);
	if (f.exists()) {
		return html = FileUtil.readAllText(fileName);
		// U.log("Reading done");
	}
//	int respCode = CheckUrlForHTML(url);

	// if(respCode==200)
	{

		if (!f.exists()) {
			synchronized (driver) {

				BufferedWriter writer = new BufferedWriter(
						new FileWriter(f));

				
			 
			       capability = new DesiredCapabilities();
			        addProxyCapabilities(capability, httpProxy, sslProxy, ftpProxy);
			 
			       
			             driver = new FirefoxDriver(capability);
			            driver.get(url);
			          //  driver.close();
			       
			    
			            ((JavascriptExecutor) driver).executeScript(
						"window.scrollBy(0,4000)", ""); // y value '400' can
														// be
				Thread.sleep(3000);

				// Thread.sleep(5 * 5000);
				U.log("Current URL:::" + driver.getCurrentUrl());
				html = driver.getPageSource();
				writer.append(html);
				writer.close();

			}
		} else {
			if (f.exists()) {
				html = FileUtil.readAllText(fileName);
				U.log("Reading done");
			}
		}
		return html;
	}
	// else{
	// return null;
	// }
}}
